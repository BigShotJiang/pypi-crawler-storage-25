"""The agent loop.

Single async generator. Streams text deltas, tool-call lifecycles, and
final state. Caller (the UI) consumes events and renders.

Behaviors:
- Native OpenAI tool calling.
- Read-only tool calls within a single turn execute in parallel.
- Mutating/exec tools execute sequentially after permission gate.
- Hard cap of MAX_ITERATIONS turns. 3 consecutive tool failures halts.
- Auto-compact at the 85% context threshold (delegated to caller).
"""
from __future__ import annotations

import asyncio
import json
import os
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, AsyncIterator, Awaitable, Callable

from prometheus import log
from prometheus.agent.system import build_system_prompt
from prometheus.config import FREE_MODELS_PREFERRED, Settings
from prometheus.provider.openrouter import OpenRouterClient, ToolCall
from prometheus.tools.base import (
    PermissionDenied,
    SideEffect,
    ToolContext,
    ToolError,
    ToolRegistry,
    ToolResult,
)

logger = log.get("agent.loop")


def _normalize_effort(level: str) -> str:
    """Round 185: map the wider reasoning-effort vocabulary to the
    three values OpenRouter forwards to upstream models.

    Aider exposes `low/medium/high/0`. Claude Code exposes
    `low/medium/high/xhigh/max`. Codex exposes `minimal` plus an
    `Alt+,/Alt+.` slider. Prometheus accepts the union via the
    `--reasoning-effort` flag (R183) and normalises here so a
    single per-engine code path can forward the right value.

    Returns one of: "auto" | "low" | "medium" | "high".
    """
    s = (level or "").strip().lower()
    if s in ("", "auto"):
        return "auto"
    if s in ("0", "minimal", "off", "none", "disable"):
        # Disabled effort — caller should pass low so the API still
        # accepts the request without the reasoning block.
        return "low"
    if s in ("low",):
        return "low"
    if s in ("medium", "med", "default"):
        return "medium"
    if s in ("high", "xhigh", "max", "ultrathink"):
        return "high"
    # Unknown name — fall back to auto so we don't reject silently.
    return "auto"


@dataclass
class AgentEvent:
    """Events the loop yields to the UI."""
    kind: str
    text: str | None = None
    tool_call: ToolCall | None = None
    tool_result: ToolResult | None = None
    error: str | None = None
    usage: dict[str, Any] | None = None
    iteration: int = 0
    # Round 212: structured metadata for events that need to carry
    # extra fields without abusing `text` or `usage`. First consumer
    # is `kind="compact"` events: they need to surface the pre-
    # compaction token count so the headless `compact_boundary`
    # emission can populate `compactMetadata.preTokens`. Other
    # event kinds may use this in the future.
    metadata: dict[str, Any] | None = None


@dataclass
class TurnState:
    text: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    finish_reason: str | None = None
    usage: dict[str, Any] = field(default_factory=dict)


class AgentLoop:
    def __init__(
        self,
        client: OpenRouterClient,
        registry: ToolRegistry,
        settings: Settings,
        request_approval: Callable[[str, str], Awaitable[bool]],
        notify: Callable[[str], None],
        audit: Callable[[str, dict[str, Any]], None],
        session_id: str | None = None,
    ) -> None:
        self.client = client
        self.registry = registry
        self.settings = settings
        self.request_approval = request_approval
        self.notify = notify
        self.audit = audit
        self.session_id = session_id or str(uuid.uuid4())
        self.permission_mode: str = "default"
        self.messages: list[dict[str, Any]] = []
        self.todos: list[dict[str, Any]] = []
        self.snapshots: list[dict[str, Any]] = []
        # Round 96.14: read_history MUST live on the loop, not on
        # individual ToolContext instances. Smoke 6 retest live root
        # cause: _make_ctx() returned a NEW ToolContext per iteration
        # with default_factory=set giving an empty read_history. So
        # Read in iteration N adds to set A, Edit in iteration N+1
        # checks set B (empty) → "read first" forever. The unit test
        # passed only because it shared one ctx for both calls. With
        # this attr, _make_ctx threads the persistent set through to
        # every ToolContext for the session.
        self.read_history: set[str] = set()
        # Round 160 / FM2: session-scoped "always approve" grants.
        # When a permission card lets the user approve a tool +
        # arg-fingerprint for the rest of the session, the fingerprint
        # lands here. _maybe_compact() clears this set on every
        # compaction event — Claude Code issues #32029 / #36690 showed
        # auto-compaction silently carried "always approve" decisions
        # forward, letting the agent self-approve after the user's
        # original consent was no longer in context. We never want
        # that. The compact event surfaces a notice so the user knows
        # they have to re-grant.
        self.approval_grants: set[str] = set()
        self.consecutive_failures: int = 0
        # Per-(tool, args-fingerprint, error-fingerprint) repeat counter.
        # When the same tool fails the same way 3 times in a row we
        # surface a "stuck-loop" hint to the model (issue #40453 in
        # Claude Code — users complained the agent retries identical
        # failing commands forever). Cleared per user turn.
        self._repeat_failures: dict[str, int] = {}
        # Round-39: tool-call repetition detector. Sliding window of the
        # last N (tool_name, args-hash) fingerprints. When the SAME
        # fingerprint appears `_REPEAT_LOOP_THRESHOLD` times in a row,
        # we assume the model is stuck and abort the turn with a clear
        # error. Catches the documented Claude-Code "infinite identical
        # command" pattern (issue #19699 — closed not-planned, ran for
        # hours) without false-positives on legitimate retries.
        self._recent_tool_fingerprints: list[str] = []
        self._REPEAT_LOOP_THRESHOLD: int = 4
        self._REPEAT_LOOP_WINDOW: int = 6
        # Claude-fallback escalation state. Lives on the loop so it
        # spans turns within a session; cleared on /clear or /resume.
        from prometheus.provider.router import EscalationState
        self.escalation = EscalationState()
        # Lazy-initialized Anthropic client. Created on first
        # escalation and reused; closed on session end.
        self._escalation_client: Any = None
        self.last_assistant_text: str = ""
        self.last_plan: str = ""
        # Output style controls the system-prompt suffix; defaults to brief.
        self.output_style: str = "default"
        # Thinking effort hint forwarded to OpenRouter `reasoning` param.
        # Round 185: pick up Settings.reasoning_effort (R183 field +
        # `--reasoning-effort` flag + `PROMETHEUS_REASONING_EFFORT`
        # env). Without this wiring the field was dead — every turn
        # ran with "auto" regardless of user opt-in. Map the wider
        # vocabulary (Aider low/medium/high, CC xhigh/max, Codex
        # minimal/0) to the three OpenRouter accepts.
        self.thinking_effort: str = _normalize_effort(
            getattr(settings, "reasoning_effort", "") or "auto"
        )
        # Round 98: explicit Aptitude activation requested by the
        # user via `/aptitude run <name>`. Cleared after each turn —
        # the explicit activation is one-shot.
        self.forced_aptitudes: list[str] = []

    def reset(self) -> None:
        self.messages.clear()
        self.todos.clear()
        self.snapshots.clear()
        # Round 96.14: clear read_history on /clear so a stale read
        # from the previous conversation doesn't permit edits in the
        # new one.
        self.read_history.clear()
        self.consecutive_failures = 0
        self._repeat_failures.clear()
        self._recent_tool_fingerprints.clear()
        # Round-16 P1: close the previous escalation client if any.
        # /clear used to leak the underlying httpx client (audit finding
        # #66) — the client object had no aclose path so a long-running
        # session that hit /escalate then /clear repeatedly accumulated
        # one connection pool per cycle.
        prev = getattr(self, "_escalation_client", None)
        if prev is not None:
            close = getattr(prev, "aclose", None)
            if callable(close):
                try:
                    import asyncio as _aio
                    loop = _aio.get_event_loop()
                    if loop.is_running():
                        _aio.ensure_future(close())
                    else:
                        loop.run_until_complete(close())
                except Exception:
                    pass
        self._escalation_client = None
        # Reset escalation tallies so a /clear after a few free-chain
        # failures doesn't immediately escalate the next prompt.
        from prometheus.provider.router import EscalationState
        self.escalation = EscalationState()
        self.last_assistant_text: str = ""
        self.last_plan: str = ""
        # Output style controls the system-prompt suffix; defaults to brief.
        self.output_style: str = "default"
        # Thinking effort hint forwarded to OpenRouter `reasoning` param.
        # Round 188: this is `reset()` — settings live on `self`, not
        # as a parameter. R185's `replace_all=True` Edit introduced a
        # bare `settings` reference here that crashed the moment any
        # code path called reset() (e.g. /clear). Same R183/R185 wider-
        # vocab mapping, just sourced correctly from self.
        self.thinking_effort: str = _normalize_effort(
            getattr(self.settings, "reasoning_effort", "") or "auto"
        )

    def set_permission_mode(self, mode: str) -> None:
        self.permission_mode = mode

    def system_prompt(self, user_prompt: str = "") -> str:
        return build_system_prompt(
            self.settings.workdir,
            self.registry,
            self.permission_mode,
            output_style=self.output_style,
            user_prompt=user_prompt,
            forced_aptitudes=tuple(self.forced_aptitudes),
        )

    def _ensure_system(self, user_prompt: str = "") -> None:
        # Pass the live user prompt so skill auto-invoke can match
        # against the current turn's triggers — without it, only
        # always-on (triggerless) skills load.
        sys = self.system_prompt(user_prompt)
        if not self.messages or self.messages[0].get("role") != "system":
            self.messages.insert(0, {"role": "system", "content": sys})
        else:
            self.messages[0]["content"] = sys
        # Round 98: forced aptitudes are one-shot. Clear after the
        # system prompt has been built so a `/aptitude run X` only
        # boosts the next turn, not every turn until /clear.
        if self.forced_aptitudes:
            self.forced_aptitudes = []

    def _make_ctx(self) -> ToolContext:
        # Compose request_approval with the persistent rule-set so deny
        # rules block before the picker pops up, and allow rules skip
        # the prompt entirely.
        from prometheus.safety.rules import evaluate, load_rules
        rules = load_rules(self.settings.workdir)

        async def _gated_approval(
            tool_name: str, detail: str, meta: dict | None = None,
        ) -> bool:
            # detail's first line is the short description; we already
            # send tool name as the first arg, so we re-evaluate from
            # the live args via a closure on the tool execution.
            #
            # Round-95 BUG FIX: previously this signature didn't accept
            # `meta`, so when run_bash (or any tool) called
            # ctx.request_approval(..., meta=...) Python raised
            # TypeError and the meta block was silently dropped on the
            # except branch. Approval cards rendered without their
            # cwd/risk/timeout/why fields. Now meta is properly
            # threaded through to PrometheusApp._request_approval.
            try:
                return await self.request_approval(tool_name, detail, meta)
            except TypeError:
                # Older runtime without meta support — fall back gracefully.
                return await self.request_approval(tool_name, detail)

        return ToolContext(
            workdir=self.settings.workdir,
            permission_mode=self.permission_mode,
            request_approval=_gated_approval,
            notify=self.notify,
            session_id=self.session_id,
            audit=self.audit,
            todos=self.todos,
            snapshots=self.snapshots,
            turn_tools=getattr(self, "_turn_tools", {}),
            # Round 96.14: persistent read_history across iterations.
            read_history=self.read_history,
            runtime=getattr(self, "runtime", None),
        )

    def _approx_token_load(self) -> int:
        """Cheap byte-based token estimate. ~4 bytes/token avg.

        Round-18 P1: cached. The previous implementation re-JSON-dumped
        every message on every call (architectural review #5), which
        hit O(N²) behaviour over long sessions because the call sites
        run once per turn — at 500 messages, every turn paid the cost
        of 500 dumps. Now we keep a rolling byte sum and only re-dump
        the slice that's changed since last call. The cache is
        invalidated whenever a slot is rewritten or messages is
        truncated, both detected by length+id heuristic below.
        """
        msgs = self.messages
        cache = getattr(self, "_token_load_cache", None)
        if cache is None:
            cache = {"len": 0, "head_id": None, "bytes": 0, "last_idx": -1}
            self._token_load_cache = cache
        # Detect resets / mid-list rewrites: if the list shrank or the
        # first message's id changed, recompute from scratch.
        head_id = id(msgs[0]) if msgs else None
        if (
            len(msgs) < cache["last_idx"] + 1
            or head_id != cache["head_id"]
        ):
            cache["bytes"] = sum(len(json.dumps(m, default=str)) for m in msgs)
            cache["head_id"] = head_id
            cache["last_idx"] = len(msgs) - 1
            cache["len"] = len(msgs)
            return cache["bytes"] // 4
        # Append-only fast path: only dump newly-appended slice.
        if len(msgs) > cache["last_idx"] + 1:
            for m in msgs[cache["last_idx"] + 1:]:
                cache["bytes"] += len(json.dumps(m, default=str))
            cache["last_idx"] = len(msgs) - 1
            cache["len"] = len(msgs)
        return cache["bytes"] // 4

    def _strip_media_from_messages(self) -> int:
        """Round 181 — strip_media_retry helper.

        Drop every `image_url` content block from the message
        history. Used as the recovery action for upstream errors
        of the form `unsupported_media` / `image_too_large` / "model
        does not support images" — same model class, but the
        request failed on a media constraint and a text-only retry
        is the documented Claude Code recovery.

        Returns the number of content parts that were dropped so
        the caller can decide whether the retry is worth attempting
        (no parts dropped = nothing to recover from; the original
        error wasn't actually media-related).
        """
        dropped = 0
        for msg in self.messages:
            content = msg.get("content")
            if not isinstance(content, list):
                continue
            new_parts: list[dict[str, Any]] = []
            for part in content:
                if isinstance(part, dict) and part.get("type") == "image_url":
                    dropped += 1
                    new_parts.append({
                        "type": "text",
                        "text": "[image dropped: upstream model rejected media]",
                    })
                else:
                    new_parts.append(part)
            if dropped > 0:
                msg["content"] = new_parts
        return dropped

    def _truncate_stale_tool_outputs(self, keep_last: int = 4) -> int:
        """Round-95 turn-6: shrink in-memory tool-message content for
        stale tool calls so accumulated bash/read output doesn't balloon
        agent.messages.

        Tool messages older than `keep_last` get replaced with a
        compact form:
          • run_bash with metadata → `[exit X · {duration}s · cwd=...]`
            + `$ {cmd}` + last 20 output lines
          • other huge content (>4KB) → head(1500) + ellipsis + tail(1500)

        Always preserves role/tool_call_id/name on every message so
        OpenAI's request-pairing constraint holds. Returns the number
        of messages it shrank.

        Why this lives at the loop level (not shell.py): we want to
        keep the model's IMMEDIATELY-PREVIOUS bash output at full
        fidelity (the model often needs every line to debug a
        failure), but stale outputs from 5 iterations ago contribute
        ~zero to the next-turn decision while bloating the in-memory
        message history. The user-reported HUD reading 418K context
        after a single turn was almost entirely stale-tool-output
        bloat — verified via the round-95 turn-1 /context probe.
        """
        # _compact_tool_forms is populated when run_bash results are
        # appended (see _run_loop_body below). For tools without a
        # registered compact form, we fall back to a generic head/tail
        # truncation only when the content is genuinely huge (>4KB).
        if not hasattr(self, "_compact_tool_forms"):
            self._compact_tool_forms = {}
        tool_idxs = [
            i for i, m in enumerate(self.messages)
            if isinstance(m, dict) and m.get("role") == "tool"
        ]
        if len(tool_idxs) <= keep_last:
            return 0
        n_truncated = 0
        # Indices of tool messages that should be shrunk (everything
        # except the last `keep_last`). We never touch the most recent
        # outputs — the model is still reasoning over those.
        stale_idxs = tool_idxs[:-keep_last] if keep_last > 0 else tool_idxs
        for i in stale_idxs:
            m = self.messages[i]
            tcid = m.get("tool_call_id", "")
            content = m.get("content", "")
            if not isinstance(content, str):
                continue
            compact = self._compact_tool_forms.get(tcid)
            if compact and content != compact:
                m["content"] = compact
                n_truncated += 1
                continue
            # Generic fallback: huge non-bash output (e.g. a
            # whole-file read_file at the start of a long debug
            # session). Trim to head + tail with a clear marker so
            # the model can tell it's truncated.
            if len(content) > 4000:
                head_chars = 1500
                tail_chars = 1500
                truncated_n = len(content) - head_chars - tail_chars
                m["content"] = (
                    content[:head_chars]
                    + f"\n…[{truncated_n} chars truncated for context size]…\n"
                    + content[-tail_chars:]
                )
                n_truncated += 1
        if n_truncated:
            try:
                # Reset the cached token-load estimator so the next
                # _approx_token_load call re-walks the (now shorter)
                # buffer instead of trusting its append-only sum.
                self._token_load_cache = None  # type: ignore[assignment]
            except Exception:
                pass
        return n_truncated

    @staticmethod
    def _build_immediate_compact_bash_content(
        meta: dict[str, Any], max_chars: int = 1200,
    ) -> str:
        """Round-96.1: build a model-facing compact replacement for a
        successful bash result's content.

        Why this matters: the live HUD on smoke 4 was reading 173.5K
        after a single test run. The bulk was the bash tool message
        carrying the full stdout (warning blocks + progress dots +
        success line). The model never re-reads that block — once it
        has decided "tests passed, finalize" it moves on. Storing the
        full text is pure context-pressure noise.

        The compact replacement includes everything the model needs:
            exit code, duration, cwd, command, last 5 useful lines.
        Warning blocks are summarized as "N warnings hidden".
        """
        cmd = str(meta.get("command", ""))[:200]
        cwd = str(meta.get("cwd", ""))[:120]
        exit_v = meta.get("exit", "?")
        dur = meta.get("duration_s", "?")
        last = meta.get("last_lines") or []
        try:
            from prometheus.ui.render import (
                filter_bash_output_compact, count_warning_blocks,
            )
            filtered = filter_bash_output_compact(
                [str(l)[:200] for l in last[-30:]]
            )
            n_warn = count_warning_blocks(last)
        except Exception:
            filtered = [str(l)[:200] for l in last[-5:]]
            n_warn = 0
        tail_block = "\n".join(filtered[-5:])
        warn_row = (
            f"\n[{n_warn} warning{'s' if n_warn != 1 else ''} hidden — "
            f"see audit log for full text]"
            if n_warn else ""
        )
        compact = (
            f"exit: {exit_v}\n"
            f"--- bash · {dur}s · cwd={cwd} ---\n"
            f"$ {cmd}\n"
            f"{tail_block}{warn_row}"
        )
        return compact[:max_chars]

    def _record_compact_tool_form(
        self, tool_call_id: str, tool_name: str, result: ToolResult,
    ) -> None:
        """Round-95 turn-6 / Round-96: stash a compact replacement
        string for a tool result so `_truncate_stale_tool_outputs`
        can later swap the bulky content for it without losing
        essential context.

        Round-96 made this MORE aggressive: bash compact form now uses
        the same noise-filter as the chat receipt (drops pytest
        progress dots and deprecation warning blocks) and caps at
        ~1000 chars instead of 3000. Discovery uses a discovery-key
        ("chosen_command") because the round-95-turn-7 metadata
        rename moved off `command` to avoid the bash-receipt match.
        Smoke tests showed in-memory bloat of 200K+ from accumulated
        pytest output across one user turn — this fix keeps it under
        ~10K per session.
        """
        if not tool_call_id:
            return
        if not hasattr(self, "_compact_tool_forms"):
            self._compact_tool_forms = {}
        meta = (result.metadata or {}) if isinstance(result.metadata, dict) else {}
        if tool_name == "run_bash" and "command" in meta:
            last = meta.get("last_lines") or []
            cmd = str(meta.get("command", ""))[:200]
            cwd = str(meta.get("cwd", ""))[:120]
            exit_v = meta.get("exit", "?")
            dur = meta.get("duration_s", "?")
            # Apply the same noise filter the receipt uses so the
            # in-memory record matches what the user saw — and
            # doesn't include hundreds of `.` progress chars.
            try:
                from prometheus.ui.render import filter_bash_output_compact
                filtered = filter_bash_output_compact(
                    [str(l)[:200] for l in last[-20:]]
                )
            except Exception:
                filtered = [str(l)[:200] for l in last[-5:]]
            tail_block = "\n".join(filtered[-5:])
            compact = (
                f"[bash · exit {exit_v} · {dur}s · cwd={cwd}]\n"
                f"$ {cmd}\n"
                f"{tail_block}"
            )
            # Aggressive cap: 1000 chars per stale bash message.
            self._compact_tool_forms[tool_call_id] = compact[:1000]
            return
        if tool_name == "discover_test_command":
            # Round-95 turn-7 moved discovery off the `command` key.
            chosen = meta.get("chosen_command") or meta.get("command")
            if chosen:
                self._compact_tool_forms[tool_call_id] = (
                    f"[discover_test_command → {chosen}]"
                )
                return

    async def _maybe_compact(self) -> AgentEvent | None:
        """Compact older turns when we cross the threshold.

        Triggers on EITHER condition:
          1. Token-budget pressure (>=85% of 200k nominal), or
          2. Hard message-count ceiling — 500 messages in the buffer.
             Free models have 128k–262k context so condition 1 rarely
             fires for plain chat, but tool-heavy sessions accumulate
             tool/assistant pairs fast. Without a count ceiling the
             buffer grows unbounded for users who stay in one session
             for days (Claude Code issues #21378 / #11315 / #33735 —
             15 GB / 129 GB / 18 GB leaks all started this way).

        Strategy: keep system + last 4 messages, summarize the middle into
        one synthetic system message. Free models have 128k–262k context so
        the token threshold rarely fires for normal chats — but it's
        mandatory for long debugging sessions that read large files.
        """
        approx = self._approx_token_load()
        budget = 200_000
        token_pressure = approx >= int(budget * self.settings.context_compact_threshold)
        count_pressure = len(self.messages) >= 500
        if not (token_pressure or count_pressure):
            return None
        if len(self.messages) < 8:
            return None
        # Round 176: fire PreCompact hook before truncating the
        # buffer. Hook can refuse (block compaction). Useful for
        # workflows that want to checkpoint state to disk before
        # losing the middle of the conversation.
        try:
            from prometheus.safety.hooks import run_event
            if self._hooks is not None:
                allow, msg = run_event(
                    self._hooks, "PreCompact",
                    matcher_value="",
                    payload={
                        "session_id": self.session_id,
                        "cwd": str(self.settings.workdir),
                        "message_count": len(self.messages),
                        "approx_tokens": approx,
                        "trigger": "tokens" if token_pressure else "count",
                    },
                )
                if not allow:
                    return AgentEvent(
                        kind="text",
                        text=f"compaction blocked by hook: {msg}",
                    )
        except Exception:
            pass
        head = self.messages[:1]
        tail = self.messages[-4:]
        middle = self.messages[1:-4]
        body = "\n".join(f"{m.get('role')}: {str(m.get('content',''))[:400]}" for m in middle)
        # Build a compact-specific chain — FAST_CHAIN first (these are
        # cheap, fast summarizers), then full free pool as last resort.
        # Audit P0: previous code passed only fast_model + flat
        # FREE_MODELS_PREFERRED; if fast_model was unreachable, the
        # fallback chain landed on 480B coders that were slow AND
        # might also be down. Now we try every fast model first.
        from prometheus.config import FAST_CHAIN
        compact_chain = list(dict.fromkeys(FAST_CHAIN + FREE_MODELS_PREFERRED))
        last_err: Exception | None = None
        for attempt_model in compact_chain[:4]:
            try:
                res = await self.client.collect(
                    attempt_model,
                    messages=[
                        {"role": "system", "content": "Summarize the conversation below in 6-12 lines. Preserve file paths, function names, and outstanding TODOs verbatim. No preamble."},
                        {"role": "user", "content": body},
                    ],
                    fallback_models=compact_chain,
                )
                if not (res.text or "").strip():
                    last_err = RuntimeError("empty compaction result")
                    continue
                self.messages = head + [
                    {"role": "system", "content": f"[auto-compacted {len(middle)} earlier turns]\n{res.text}"}
                ] + tail
                # Round 160 / FM2: clear all session-scoped approval
                # grants. The user's original consent was tied to the
                # context the model could see — once that context is
                # compacted away, carrying the grant forward becomes a
                # silent self-approval (Claude Code issues #32029 /
                # #36690). Force re-grant on the very next request.
                cleared = len(self.approval_grants)
                self.approval_grants.clear()
                grant_notice = (
                    f" · permissions reset ({cleared} grant"
                    f"{'s' if cleared != 1 else ''} cleared)"
                    if cleared else ""
                )
                return AgentEvent(
                    kind="compact",
                    text=f"compacted {len(middle)} → 1 message{grant_notice}",
                    metadata={
                        # Round 212: pre-compaction byte/token estimate
                        # for the headless `compact_boundary` event's
                        # `compactMetadata.preTokens` field. We pass
                        # the same `approx` we computed at the top of
                        # this method — it's a 4-byte heuristic, but
                        # it's the same number the rest of the agent
                        # uses for context budgeting, so consumers
                        # comparing successive boundaries get
                        # consistent numbers.
                        "preTokens": int(approx),
                        "messages_compacted": len(middle),
                        "trigger": "tokens" if token_pressure else "count",
                    },
                )
            except Exception as e:
                last_err = e
                continue
        logger.warning("auto-compact failed across %d models: %s",
                       len(compact_chain[:4]), last_err)
        # Surface the failure to the user via a compact-event hint —
        # silent degradation here means the next turn fights an
        # overfull context. We don't crash the loop (audit P1) but
        # the chat shows what happened.
        return AgentEvent(
            kind="compact",
            text=(
                f"⚠︎ auto-compact unavailable right now ({last_err!s}); "
                f"context may be tight. Try /compact manually if responses degrade."
            ),
        )

    @staticmethod
    def _detect_thinking_effort(text: str) -> str | None:
        """Map Claude Code's magic words to OpenRouter `reasoning.effort`.

        ultrathink / think harder / think really hard → "high"
        megathink / think deeply / think a lot         → "medium"
        think / think hard / think more                → "low"
        """
        if not text:
            return None
        low = text.lower()
        high_triggers = ("ultrathink", "think harder", "think really hard",
                         "think intensely", "think very hard")
        med_triggers  = ("megathink", "think deeply", "think a lot",
                         "think about it carefully")
        low_triggers  = ("think hard", "think more", "think it through",
                         "think step by step")
        if any(t in low for t in high_triggers):
            return "high"
        if any(t in low for t in med_triggers):
            return "medium"
        if any(t in low for t in low_triggers):
            return "low"
        # Plain "think" by itself is too generic — skip.
        return None

    async def run_multipart(
        self,
        content_parts: list[dict[str, Any]],
        model: str | None = None,
    ) -> AsyncIterator[AgentEvent]:
        """Like run() but the user message is OpenAI-multipart content
        (text + image_url parts). Used for Ctrl+V image paste."""
        # Extract a plain-text prompt for skill matching + fingerprint.
        text_only = " ".join(
            p.get("text", "") for p in content_parts if p.get("type") == "text"
        ).strip() or "(image)"
        self._ensure_system(text_only)
        self.messages.append({"role": "user", "content": content_parts})
        self._turn_tools = {}
        self._call_cache = {}
        self._hooks = None
        self._rules = None
        async for ev in self._run_loop_body(text_only, model):
            yield ev

    async def run(self, user_message: str, model: str | None = None) -> AsyncIterator[AgentEvent]:
        """Process one user message; yields events until the loop settles."""
        # Pass the user message so skills auto-load against this turn.
        self._ensure_system(user_message)
        # Round 176: fire UserPromptSubmit hook before processing the
        # prompt. Hook can refuse (non-zero exit blocks). The hook
        # set is loaded lazily here for the same reason _execute_tools
        # does so — workdir trust may not be available pre-mount.
        try:
            from prometheus.safety.hooks import load_hooks, run_event
            if self._hooks is None:
                try:
                    self._hooks = load_hooks(self.settings.workdir)
                except Exception:
                    self._hooks = None
            if self._hooks is not None:
                allow, msg = run_event(
                    self._hooks, "UserPromptSubmit",
                    matcher_value=user_message[:200],
                    payload={
                        "session_id": self.session_id,
                        "prompt": user_message,
                        "cwd": str(self.settings.workdir),
                    },
                )
                if not allow:
                    yield AgentEvent(
                        kind="error",
                        error=f"UserPromptSubmit hook blocked: {msg}",
                    )
                    return
        except Exception:
            # Hook system failure must never crash the agent loop.
            pass
        self.messages.append({"role": "user", "content": user_message})
        # Reset ledgers ONCE per user request — they need to span every
        # iteration so guards like "fetch blocked after search" work
        # even when search and fetch land in different iterations.
        self._turn_tools = {}
        self._call_cache = {}
        self._rules = None
        try:
            async for ev in self._run_loop_body(user_message, model):
                yield ev
        finally:
            # Round 176: fire Stop hook when the loop body settles
            # (success, error, or truncation — all paths). Non-blocking
            # in the sense that exit code is ignored, but if it raises
            # we swallow so the next user prompt isn't poisoned.
            try:
                from prometheus.safety.hooks import run_event
                if self._hooks is not None:
                    run_event(
                        self._hooks, "Stop",
                        matcher_value="",
                        payload={
                            "session_id": self.session_id,
                            "cwd": str(self.settings.workdir),
                        },
                    )
            except Exception:
                pass

    async def _run_loop_body(self, user_message: str, model: str | None) -> AsyncIterator[AgentEvent]:
        """Inner loop shared by run() and run_multipart(). Caller is
        responsible for pushing the user message + resetting the ledgers."""
        compact_ev = await self._maybe_compact()
        if compact_ev is not None:
            yield compact_ev
        # Role-based model routing. Plan mode wants a stronger reasoner
        # (DeepSeek R1 / GPT-OSS-120B) because the model has to construct
        # a multi-step plan with file:line references; chat-mode coding
        # uses the coder chain. The flat fallback inside provider/openrouter.py
        # rotates within whichever chain we picked. Audit P0: previously
        # every mode used `settings.model` regardless, so plan-mode users
        # got the coder model and timed out on hard reasoning.
        from prometheus.config import PLANNER_CHAIN
        chosen_model = model or self.settings.model
        chosen_chain: list[str] = list(FREE_MODELS_PREFERRED)
        if self.permission_mode == "plan" and not model:
            # In plan mode, default to planner chain unless caller forced a model.
            chosen_model = self.settings.planner_model
            # Re-rank fallbacks so planner models come first.
            seen: set[str] = set()
            chosen_chain = []
            for m in PLANNER_CHAIN + FREE_MODELS_PREFERRED:
                if m not in seen:
                    seen.add(m)
                    chosen_chain.append(m)
        # Round 216 Layer 3: CARGO smart-routing. The router lives in
        # `agent/cargo_router.py` and classifies the user prompt into
        # one of 8 categories (code_generation, debugging, code_review,
        # long_context, quick_task, explanation, data_processing,
        # general). It then recommends a category-specific free model
        # (e.g. "what time is it" → quick_task → gemini-flash-1.5:free;
        # "fix the bug" → debugging → deepseek-v3.1:free). Pre-R216 the
        # router was dead code — it was imported nowhere outside its
        # own tests. Now we run it whenever the caller did NOT pass an
        # explicit model AND the user isn't in plan mode (which has
        # its own deliberate routing). The router's pick goes to the
        # FRONT of the failover chain so it tries first; if it 404s or
        # errors, the existing rotation falls through to
        # FREE_MODELS_PREFERRED. Cap: only run CARGO when chosen_model
        # is unset OR is one of the generic alias placeholders so we
        # never override an explicit user choice (--model flag,
        # /model command, settings.json `model` field with a real
        # slug).
        if (
            not model
            and self.permission_mode != "plan"
            and (
                not chosen_model
                or chosen_model in (
                    "auto", "auto/free", "openrouter/free",
                    "openrouter/auto", "haiku", "sonnet", "opus", "best",
                )
            )
        ):
            try:
                from prometheus.agent.cargo_router import route as _cargo_route
                routing = _cargo_route(user_message or "")
                cargo_pick = routing.chosen_model
                if cargo_pick:
                    self.audit("cargo_routed", {
                        "category": str(routing.category.value),
                        "confidence": round(routing.confidence, 2),
                        "chosen_model": cargo_pick,
                        "reason": routing.reason,
                    })
                    chosen_model = cargo_pick
                    # Push CARGO pick to front of chain; fall back to
                    # FREE_MODELS_PREFERRED if the pick 404s.
                    seen2: set[str] = {cargo_pick}
                    new_chain = [cargo_pick]
                    for m_fb in chosen_chain:
                        if m_fb not in seen2:
                            seen2.add(m_fb)
                            new_chain.append(m_fb)
                    chosen_chain = new_chain
            except Exception:
                # CARGO is a best-effort optimization — never block
                # the turn on its failure. Keep the original chain.
                pass

        # ---- Claude-fallback escalation gate ----
        # Free OpenRouter models handle EVERY turn unless the gatekeeper
        # in router.should_escalate() approves an upgrade. Each Claude
        # call costs real money so we only fire when (a) the user said
        # /escalate, (b) the free chain has failed N times on this exact
        # prompt, or (c) context > 100k tokens AND opt-in flag set.
        # When escalating, we use the Anthropic client (separate provider)
        # for THIS TURN ONLY, then revert to the free chain.
        from prometheus.provider.router import (
            should_escalate,
            consume_escalate_flag,
        )
        import os as _os
        decision = should_escalate(
            self.escalation,
            user_message,
            approx_token_load=self._approx_token_load(),
            has_anthropic_key=bool(_os.getenv("ANTHROPIC_API_KEY")),
        )
        consume_escalate_flag(self.escalation)
        use_claude = decision.escalate
        if use_claude:
            # Round-15 cost-saver: BEFORE paying for an escalation,
            # run a free-chain compaction pass if context is large.
            # Compaction itself is $0 (uses the FAST_CHAIN free models)
            # but it can shrink a 60k-token transcript to a 5k summary,
            # cutting the paid call's input cost by ~90%. Only fires
            # when we're already over a meaningful threshold AND the
            # opt-out env var isn't set.
            AUTO_COMPACT_BEFORE_ESCALATE_THRESHOLD = 30_000
            if (
                _os.getenv("PROMETHEUS_AUTO_COMPACT_BEFORE_ESC", "1") != "0"
                and self._approx_token_load() >= AUTO_COMPACT_BEFORE_ESCALATE_THRESHOLD
                and len(self.messages) >= 8
            ):
                pre_compact_ev = await self._maybe_compact()
                if pre_compact_ev is not None:
                    yield pre_compact_ev
            # Lazy-init the escalation client — never imported unless
            # a turn actually needs it. Round-13: prefer the user's
            # BYOK key (set via /byok) over the pooled env-var key so
            # heavy users can bypass the shared budget cap.
            try:
                from prometheus.provider.escalate import AnthropicClient
                runtime_app = getattr(self, "runtime", None)
                user_key = None
                if runtime_app is not None:
                    user_key = getattr(getattr(runtime_app, "app", None),
                                        "_user_premium_key", None)
                need_rebuild = self._escalation_client is None or (
                    user_key and getattr(self._escalation_client, "_byok_user", False)
                    is False
                )
                if need_rebuild:
                    # Round-16 P1: close the prior client before swap so
                    # a /byok flip doesn't orphan its httpx connection
                    # pool (audit finding #67).
                    prev = self._escalation_client
                    if prev is not None:
                        close = getattr(prev, "aclose", None)
                        if callable(close):
                            try:
                                await close()
                            except Exception:
                                pass
                    self._escalation_client = AnthropicClient(api_key=user_key)
                    self._escalation_client._byok_user = bool(user_key)
                chosen_model = decision.model or "claude-haiku-4-5"
                chosen_chain = [chosen_model]
                # Audit log stores the public name AND the upstream id —
                # public name is shown to anyone who pastes the log for
                # support; upstream id stays available under the
                # `_upstream` key for power-user / developer debugging.
                from prometheus.config import public_name as _pn
                self.audit("escalate", {
                    "model": _pn(chosen_model),
                    "_upstream": chosen_model,
                    "reason": decision.reason,
                    "byok": bool(user_key),
                })
            except Exception as e:
                # Anthropic unavailable — fall back silently to free chain
                # rather than fail the turn.
                logger.warning("escalation requested but failed: %s", e)
                use_claude = False

        # Round-93: per-TaskKind tool subset is now DEFAULT-ON for
        # free-model paths. Round-92 proved this helps; we keep all
        # 15 tools for paid Claude (200K context, no need to lean).
        # Opt-out via PROMETHEUS_LEAN_TOOLS=0.
        if (
            os.getenv("PROMETHEUS_LEAN_TOOLS") != "0"
            and not use_claude  # Claude has 200K context — no need to lean
        ):
            try:
                from prometheus.provider.router import (
                    classify_query, lean_tool_names,
                )
                kind = classify_query(user_message)
                names = lean_tool_names(kind)
                lean_registry = self.registry.subset(names)
                tools = lean_registry.to_openai_tools()
                self.audit("lean_tools", {
                    "kind": kind.value, "tool_count": len(tools),
                    "names": names,
                })
            except Exception:
                tools = self.registry.to_openai_tools()
        else:
            tools = self.registry.to_openai_tools()
        # Auto-elevate reasoning effort when the user uses a Claude-Code-
        # style magic word ("ultrathink", "think hard", …). Explicit
        # /effort overrides via thinking_effort.
        if self.thinking_effort != "auto":
            effort = self.thinking_effort
        else:
            effort = self._detect_thinking_effort(user_message)

        # Round-15: per-turn USD ceiling. A single user message that
        # iterates into Premium territory shouldn't blow past the cap.
        # Default 0 = disabled. Free engines report cost=0 so this is
        # inert for free-only paths. Accumulator spans ALL iterations
        # within this user message (a single "turn" from the user's
        # perspective is many model iterations as tools fire).
        try:
            per_turn_cap = float(_os.getenv("PROMETHEUS_PER_TURN_USD_LIMIT", "0") or 0)
        except ValueError:
            per_turn_cap = 0.0
        turn_cost_usd = 0.0

        # Round-45: per-turn wall-clock budget. When a free model gets
        # stuck firing different tool calls forever (legitimate calls
        # but no convergence), the existing repetition detector won't
        # fire. This is a coarse safety net: cap total time spent on
        # ONE user message to PROMETHEUS_TURN_BUDGET_S (default 480s
        # = 8 minutes). Aborts at the iteration boundary with a clear
        # message so the user can /escalate or rephrase. Opt-out: set
        # to 0.
        import time as _time
        try:
            turn_budget_s = float(_os.getenv("PROMETHEUS_TURN_BUDGET_S", "480") or 480)
        except ValueError:
            turn_budget_s = 480.0
        turn_started_at = _time.monotonic()

        for iteration in range(1, self.settings.max_iterations + 1):
            yield AgentEvent(kind="iteration", iteration=iteration)
            # Round-95 turn-6: shrink stale tool outputs before the
            # next LLM call. Keeps the last 4 tool messages at full
            # fidelity (the model often needs them to reason about the
            # current step) and replaces older ones with compact forms
            # — exit + duration + last 20 lines for bash, or a head/tail
            # truncation for other huge outputs. Without this, a
            # session that hits run_bash repeatedly accumulates raw
            # stdout in agent.messages and the HUD shows 400K+ context
            # after just a few turns, even though most of that text is
            # never read again.
            try:
                # Round-96: tighter keep_last (2 → was 4). The chat
                # receipt already shows the most recent bash result
                # to the user; the model only needs the IMMEDIATE
                # prior tool output to reason about the next step.
                # Older outputs become metadata-only summaries.
                truncated = self._truncate_stale_tool_outputs(keep_last=2)
                if truncated:
                    self.audit("tool_output_truncated", {
                        "n_messages": truncated,
                        "iteration":  iteration,
                    })
            except Exception:
                # Truncation is a context-saver, not load-bearing —
                # any bug here is preferable to crashing the loop.
                pass
            # Round-45 stuck-loop guard: check budget BEFORE issuing
            # the next stream call so we don't pay for one more model
            # turn just to immediately abort.
            if turn_budget_s > 0:
                elapsed = _time.monotonic() - turn_started_at
                if elapsed >= turn_budget_s:
                    self.audit("turn_budget_exceeded", {
                        "elapsed_s": round(elapsed, 1),
                        "budget_s": turn_budget_s,
                        "iteration": iteration,
                    })
                    yield AgentEvent(
                        kind="error",
                        error=(
                            f"turn budget hit: {int(elapsed)}s elapsed "
                            f">= {int(turn_budget_s)}s cap. The engine "
                            f"may be looping. Try rephrasing, splitting "
                            f"the task, or /escalate. Raise the cap with "
                            f"PROMETHEUS_TURN_BUDGET_S=<seconds>."
                        ),
                        iteration=iteration,
                    )
                    return
            # Round-48: per-iteration bg-shell reminder. Matches Claude
            # Code's pattern of injecting a system-reminder into the
            # model context when a `run_in_background:true` shell is
            # alive — without this, the model fires the bg run and
            # forgets the shell exists. We append a single concise
            # tool-message before the next stream call. Skipped on
            # iteration 1 (the user's prompt is already there).
            if iteration > 1:
                try:
                    # Drop stale bg-reminders from prior iterations so
                    # context doesn't bloat (CC issue #11716/#12302 —
                    # they have this exact bug; we avoid it).
                    self.messages[:] = [
                        m for m in self.messages
                        if not m.get("_prometheus_bg_reminder")
                    ]
                    app = getattr(self, "_app_ref", None) or (
                        getattr(getattr(self, "runtime", None), "app", None)
                    )
                    bg = getattr(app, "bg_jobs", None) if app else None
                    if bg is not None and hasattr(bg, "list"):
                        alive = [j for j in bg.list() if not j.finished]
                        if alive:
                            lines = [
                                "<system-reminder>",
                                f"{len(alive)} background shell(s) still running:",
                            ]
                            for j in alive[:5]:
                                buf_len = len(getattr(j, "read_buffer", "") or "")
                                lines.append(
                                    f"  · {j.shell_id}: {j.cmd[:60]} "
                                    f"({j.elapsed}s, {buf_len} chars buffered)"
                                )
                            lines.append(
                                "Use bash_output(shell_id=...) to read new output, "
                                "kill_shell(shell_id=...) to terminate."
                            )
                            lines.append("</system-reminder>")
                            self.messages.append({
                                "role": "system",
                                "content": "\n".join(lines),
                                "_prometheus_bg_reminder": True,
                            })
                except Exception:
                    pass

            # Round-17 P1: drop image bytes from prior turns. Any user
            # message tagged `_prometheus_image_carrier` and not from
            # the *current* turn (i.e. anything before iteration's last
            # entry) is rewritten so its `image_url` parts become a
            # short text placeholder. Saves megabytes of RSS over long
            # sessions and prevents replaying the same bytes through
            # every subsequent network call.
            if iteration > 1 and self.messages:
                for m in self.messages[:-1]:
                    if not m.get("_prometheus_image_carrier"):
                        continue
                    content = m.get("content")
                    if not isinstance(content, list):
                        continue
                    new_content: list[dict[str, Any]] = []
                    swapped = False
                    for part in content:
                        if isinstance(part, dict) and part.get("type") == "image_url":
                            swapped = True
                            new_content.append({
                                "type": "text",
                                "text": "[image dropped from history; re-paste if needed]",
                            })
                        else:
                            new_content.append(part)
                    if swapped:
                        m["content"] = new_content
                        m["_prometheus_image_carrier"] = False
            turn = TurnState()
            stream_error: str | None = None
            attempt_models = [chosen_model] + [
                m for m in chosen_chain if m != chosen_model
            ]
            for attempt_idx, attempt_model in enumerate(attempt_models[:4]):
                turn = TurnState()
                stream_error = None
                emitted_any = False
                # Route this attempt to the right provider. When use_claude
                # is True, the chosen_model is a claude-* id and we call
                # Anthropic; otherwise the OpenRouter client takes it.
                # Both expose the same StreamEvent surface.
                provider_client = (
                    self._escalation_client if (use_claude and self._escalation_client)
                    else self.client
                )
                # Round-29 Track A+K: sleep-detect watchdog. Track the
                # monotonic clock at stream start and on every event.
                # If the gap between consecutive events exceeds
                # PROMETHEUS_STREAM_IDLE_S (default 300s = 5min), or
                # the absolute request age exceeds PROMETHEUS_REQUEST_MAX_S
                # (default 900s = 15min), we abort the stream and
                # surface a clear error so the loop can rotate to the
                # next model in the chain. Catches: laptop sleep
                # mid-request, gateway hangs, OS-network freezes.
                import time as _t_mc
                _stream_start = _t_mc.monotonic()
                _last_event_at = _stream_start
                # Round 208 — first live Windows-test bug: user reported
                # the agent stuck in "thinking..." for 3+ minutes after
                # two failed tool calls. The legacy 300s idle cap is too
                # forgiving for free-tier traffic where a 2min silence
                # means the call is dead. PROMETHEUS_TURN_TIMEOUT_S
                # (default 120s) is the new primary knob; the smaller of
                # the two limits wins so a user who tightens either
                # value gets the tighter behavior. When THIS knob fires
                # we emit `turn_timed_out` so debug logs surface the
                # round-208 case distinctly from the legacy idle event.
                try:
                    _turn_timeout = float(_os.getenv("PROMETHEUS_TURN_TIMEOUT_S", "120") or 120)
                except ValueError:
                    _turn_timeout = 120.0
                try:
                    _legacy_idle = float(_os.getenv("PROMETHEUS_STREAM_IDLE_S", "300") or 300)
                except ValueError:
                    _legacy_idle = 300.0
                _idle_cap = min(_turn_timeout, _legacy_idle)
                try:
                    _max_request = float(_os.getenv("PROMETHEUS_REQUEST_MAX_S", "900") or 900)
                except ValueError:
                    _max_request = 900.0
                try:
                    async for ev in provider_client.stream(
                        attempt_model,
                        self.messages,
                        tools=tools,
                        fallback_models=FREE_MODELS_PREFERRED if not use_claude else None,
                        reasoning_effort=effort,
                    ):
                        # Watchdog check on every event. Cheap; the
                        # provider's own timeouts may not catch a
                        # post-sleep monotonic-jump scenario.
                        _now = _t_mc.monotonic()
                        if _now - _last_event_at > _idle_cap:
                            _idle_s = _now - _last_event_at
                            # Distinguish: was THIS the turn-timeout cap
                            # (R208, default 120s) or the legacy idle
                            # cap? Both audit events fire for diagnostic
                            # surface; the message text reflects whichever
                            # cap actually triggered.
                            _is_turn_timeout = _turn_timeout <= _legacy_idle
                            if _is_turn_timeout:
                                stream_error = (
                                    f"turn timed out: model produced no output "
                                    f"for {int(_idle_s)}s (cap="
                                    f"{int(_turn_timeout)}s). Aborting and "
                                    f"retrying with next engine. Raise "
                                    f"PROMETHEUS_TURN_TIMEOUT_S=<seconds> if "
                                    f"the model legitimately needs longer."
                                )
                                self.audit("turn_timed_out", {
                                    "idle_s": round(_idle_s, 1),
                                    "cap_s": _turn_timeout,
                                    "model": attempt_model,
                                    "attempt": attempt_idx,
                                })
                            else:
                                stream_error = (
                                    f"stream idle for {int(_idle_s)}s "
                                    f"(cap={int(_idle_cap)}s) — likely OS sleep, "
                                    f"gateway hang, or network freeze. Aborting "
                                    f"and retrying with next engine."
                                )
                                self.audit("stream_idle_watchdog", {
                                    "idle_s": round(_idle_s, 1),
                                    "model": attempt_model,
                                    "attempt": attempt_idx,
                                })
                            break
                        if _now - _stream_start > _max_request:
                            stream_error = (
                                f"request total age {int(_now - _stream_start)}s "
                                f">= max ({int(_max_request)}s). Aborting and "
                                f"retrying with next engine."
                            )
                            self.audit("request_age_watchdog", {
                                "age_s": round(_now - _stream_start, 1),
                                "model": attempt_model,
                                "attempt": attempt_idx,
                            })
                            break
                        _last_event_at = _now
                        if ev.kind == "text" and ev.text:
                            turn.text += ev.text
                            emitted_any = True
                            yield AgentEvent(kind="text", text=ev.text, iteration=iteration)
                        elif ev.kind == "tool_call_complete" and ev.tool_call:
                            turn.tool_calls.append(ev.tool_call)
                            emitted_any = True
                            # Round-39: tool-call repetition detector.
                            # Hash (name, args_json) into a short
                            # fingerprint, push onto the sliding
                            # window, and abort if the same fingerprint
                            # filled the window. Catches stuck-loop
                            # patterns Claude Code itself doesn't guard.
                            try:
                                import hashlib as _hl
                                fp_src = (ev.tool_call.name or "") + "|" + (ev.tool_call.arguments or "")
                                fp = _hl.sha1(fp_src.encode("utf-8", "replace")).hexdigest()[:16]
                                self._recent_tool_fingerprints.append(fp)
                                if len(self._recent_tool_fingerprints) > self._REPEAT_LOOP_WINDOW:
                                    self._recent_tool_fingerprints = self._recent_tool_fingerprints[-self._REPEAT_LOOP_WINDOW:]
                                tail = self._recent_tool_fingerprints[-self._REPEAT_LOOP_THRESHOLD:]
                                if len(tail) >= self._REPEAT_LOOP_THRESHOLD and len(set(tail)) == 1:
                                    self.audit("repetition_loop_detected", {
                                        "tool": ev.tool_call.name,
                                        "consecutive_repeats": len(tail),
                                        "iteration": iteration,
                                    })
                                    self._recent_tool_fingerprints.clear()
                                    yield AgentEvent(
                                        kind="error",
                                        error=(
                                            f"stuck-loop guard: the same {ev.tool_call.name} "
                                            f"call has been issued {len(tail)} times in a row. "
                                            f"Stopping to avoid an infinite retry. Try a "
                                            f"different approach or pass new arguments."
                                        ),
                                        iteration=iteration,
                                    )
                                    return
                            except Exception:
                                pass
                            yield AgentEvent(kind="tool_call", tool_call=ev.tool_call, iteration=iteration)
                        elif ev.kind == "usage" and ev.usage:
                            turn.usage = ev.usage
                            try:
                                turn_cost_usd += float(ev.usage.get("cost", 0) or 0)
                            except (TypeError, ValueError):
                                pass
                            yield AgentEvent(kind="usage", usage=ev.usage, iteration=iteration)
                            if per_turn_cap > 0 and turn_cost_usd >= per_turn_cap:
                                self.audit("per_turn_cap_hit", {
                                    "turn_cost_usd": round(turn_cost_usd, 4),
                                    "cap_usd": per_turn_cap,
                                    "iteration": iteration,
                                })
                                yield AgentEvent(
                                    kind="error",
                                    error=(
                                        f"per-turn spend cap reached: ${turn_cost_usd:.4f} "
                                        f"≥ ${per_turn_cap:.2f}. Raise "
                                        f"PROMETHEUS_PER_TURN_USD_LIMIT or split the "
                                        f"work into smaller turns."
                                    ),
                                    iteration=iteration,
                                )
                                return
                        elif ev.kind == "done":
                            turn.finish_reason = ev.finish_reason
                        elif ev.kind == "error":
                            stream_error = ev.error
                            break
                except Exception as e:
                    logger.exception("stream failed on attempt %s", attempt_idx)
                    from prometheus.provider.openrouter import sanitize_error
                    stream_error = sanitize_error(str(e))
                # Round 181: reactive_compact_retry + strip_media_retry.
                # Two error classes that benefit from input-fixup before
                # switching models: context-length-exceeded (run
                # AutoCompact, retry same model) and unsupported-media /
                # image-too-large (drop image parts, retry same model).
                # Both fire AT MOST ONCE per turn so a chronically-bad
                # input can't loop forever — after the recovery attempt,
                # the next stream error falls through to the
                # next-model-in-chain path. Mirrors the arXiv paper's
                # documented Claude Code recovery taxonomy.
                if stream_error and not emitted_any:
                    err_lower = (stream_error or "").lower()
                    is_context_length = (
                        "context_length_exceeded" in err_lower
                        or "context too long" in err_lower
                        or "context window" in err_lower
                        or "maximum context" in err_lower
                        or "prompt is too long" in err_lower
                    )
                    is_media_error = (
                        "unsupported_media" in err_lower
                        or "media_type" in err_lower
                        or "image_too_large" in err_lower
                        or "image too large" in err_lower
                        or "vision is not" in err_lower
                        or "does not support image" in err_lower
                    )
                    if is_context_length and not getattr(
                        self, "_reactive_compact_attempted", False,
                    ):
                        self._reactive_compact_attempted = True
                        self.audit("reactive_compact_retry", {
                            "iteration": iteration,
                            "attempt": attempt_idx,
                            "error_head": stream_error[:100],
                        })
                        try:
                            # Force compaction by temporarily lowering
                            # the threshold; _maybe_compact() returns a
                            # text event when it ran. We swallow that
                            # event — the user already saw the
                            # underlying error class and the retry will
                            # surface clean output if the compacted
                            # prompt fits.
                            saved_thresh = self.settings.context_compact_threshold
                            self.settings.context_compact_threshold = 0.0
                            try:
                                _ = await self._maybe_compact()
                            finally:
                                self.settings.context_compact_threshold = saved_thresh
                        except Exception:
                            logger.exception("reactive_compact_retry helper failed")
                        stream_error = None
                        continue  # retry same model with compacted history
                    if is_media_error and not getattr(
                        self, "_strip_media_attempted", False,
                    ):
                        self._strip_media_attempted = True
                        stripped = self._strip_media_from_messages()
                        self.audit("strip_media_retry", {
                            "iteration": iteration,
                            "attempt": attempt_idx,
                            "error_head": stream_error[:100],
                            "stripped_parts": stripped,
                        })
                        if stripped > 0:
                            stream_error = None
                            continue  # retry same model without media
                # If we got nothing usable, retry on the next engine.
                if stream_error and not emitted_any and attempt_idx < 3:
                    logger.warning("retrying after error: %s", stream_error)
                    continue
                # Round 215: degenerate-output retry. When the stream
                # completed cleanly (no error) but produced text that
                # passes the degenerate-repetition guard, treat it as
                # a soft failure and rotate to the next free model in
                # the chain. Live evidence: free-tier minimax-m2.5
                # responded to "what time is it in San Diego CA now?"
                # with "San Diego time is San Diego: San Diego:" — a
                # classic noun-cycling loop. Without this guard the
                # gibberish reaches the user as the canonical answer.
                # We only fire when:
                #   - the stream actually succeeded (no stream_error)
                #   - the model produced TEXT (not tool calls) — tool
                #     work is real progress, never retried for "loop"
                #   - we have attempts left in the failover chain
                # Reset the turn so the retry doesn't accumulate the
                # bad text. Audit the rotation so debug surfaces it.
                if (
                    not stream_error
                    and turn.text
                    and not turn.tool_calls
                    and attempt_idx < 3
                ):
                    try:
                        from prometheus.agent.text_quality import (
                            is_degenerate_repetition,
                        )
                        if is_degenerate_repetition(turn.text):
                            self.audit("degenerate_text_retry", {
                                "iteration": iteration,
                                "attempt": attempt_idx,
                                "model": attempt_model,
                                "text_head": (turn.text or "")[:80],
                            })
                            turn.text = ""
                            turn.tool_calls = []
                            turn.usage = {}
                            stream_error = (
                                "degenerate output (loop pattern); "
                                "retrying on next free model"
                            )
                            emitted_any = False
                            # Round 216 Layer 4: surface the rotation
                            # as a dim user-visible message. Pre-R216
                            # the retry was silent — the user only
                            # saw a longer "thinking..." with no
                            # indication that one model bailed and
                            # another took over. The "↻ Retrying"
                            # text gets emitted as an `info` event
                            # so the TUI can render it as system
                            # chrome (dim) rather than as assistant
                            # text. A stream-json consumer also sees
                            # the audit event for the same signal.
                            try:
                                next_model = attempt_models[attempt_idx + 1]
                            except IndexError:
                                next_model = "next free model"
                            yield AgentEvent(
                                kind="info",
                                text=(
                                    f"↻ Retrying on {next_model} "
                                    f"(previous output was degenerate)"
                                ),
                                iteration=iteration,
                            )
                            continue
                    except Exception:
                        # Detector failures must never block normal
                        # finalization — fall through to the existing
                        # break path below.
                        pass
                # Either succeeded or already streamed partial output — stop retrying.
                break
            if stream_error and not turn.text and not turn.tool_calls:
                # Round-16 (deferred from round-15): tier auto-bump.
                # An auto-escalated Haiku call that burns its retry
                # budget without producing text or tool calls retries
                # ONCE on Sonnet before declaring the turn dead. Only
                # fires for the auto-Haiku path — explicit /escalate
                # (already Sonnet) and /escalate --hard (Opus) are
                # user-chosen tiers and don't auto-bump further.
                from prometheus.provider.router import (
                    DEFAULT_CLAUDE_MODEL, SONNET_CLAUDE_MODEL,
                    already_auto_bumped, mark_auto_bumped,
                )
                if (
                    use_claude
                    and chosen_model == DEFAULT_CLAUDE_MODEL
                    and self._escalation_client is not None
                    and not already_auto_bumped(self.escalation, user_message)
                ):
                    mark_auto_bumped(self.escalation, user_message)
                    self.audit("escalate_bump", {
                        "from": "claude-haiku-4-5",
                        "to": "claude-sonnet-4-6",
                        "reason": (stream_error or "")[:80],
                    })
                    self.notify(
                        f"premium tier failed; retrying on a stronger tier "
                        f"({(stream_error or '')[:60]})"
                    )
                    chosen_model = SONNET_CLAUDE_MODEL
                    turn = TurnState()
                    stream_error = None
                    try:
                        async for ev in self._escalation_client.stream(
                            chosen_model,
                            self.messages,
                            tools=tools,
                            fallback_models=None,
                            reasoning_effort=effort,
                        ):
                            if ev.kind == "text" and ev.text:
                                turn.text += ev.text
                                yield AgentEvent(kind="text", text=ev.text, iteration=iteration)
                            elif ev.kind == "tool_call_complete" and ev.tool_call:
                                turn.tool_calls.append(ev.tool_call)
                                yield AgentEvent(kind="tool_call", tool_call=ev.tool_call, iteration=iteration)
                            elif ev.kind == "usage" and ev.usage:
                                turn.usage = ev.usage
                                yield AgentEvent(kind="usage", usage=ev.usage, iteration=iteration)
                            elif ev.kind == "done":
                                turn.finish_reason = ev.finish_reason
                            elif ev.kind == "error":
                                stream_error = ev.error
                                break
                    except Exception as e:
                        from prometheus.provider.openrouter import sanitize_error
                        stream_error = sanitize_error(str(e))
                # Record this as a free-chain failure for the escalation
                # gatekeeper. If the user re-submits the same prompt,
                # the next attempt will trigger /escalate-style routing
                # to Claude (assuming ANTHROPIC_API_KEY is set).
                if stream_error and not turn.text and not turn.tool_calls:
                    if not use_claude:
                        from prometheus.provider.router import record_free_failure
                        record_free_failure(self.escalation, user_message)
                    yield AgentEvent(kind="error", error=stream_error, iteration=iteration)
                    return
            # Round 97.2: unified text-leak recovery via the
            # `leak_sanitizer.recover_tool_calls` API. Supersedes
            # the round-92 inline regex (which required `>` after
            # the tool name and missed the `<function/NAME{...}`
            # form observed in the round-97 live screenshot —
            # Groq/Llama-3.3 emits both shapes interchangeably).
            #
            # Recovery rules:
            #   * Only allowlisted tool names execute.
            #   * Args must parse as JSON.
            #   * `run_bash` with `run_in_background=true` is
            #     canonicalized to `task` (the proper background-
            #     dispatch tool).
            #   * Cap at MAX_RECOVERIES_PER_TURN per turn.
            # Refused leaks are still SUPPRESSED from the visible
            # text (the user never sees raw markup).
            if turn.text and (
                "<function" in turn.text
                or "<tool_use" in turn.text
                or "<function_calls" in turn.text
                or "[tool_call:" in turn.text
            ):
                from prometheus.agent.leak_sanitizer import (
                    recover_tool_calls,
                )
                from prometheus.provider.openrouter import (
                    ToolCall as _TC,
                )
                cleaned_text, recovery_records = recover_tool_calls(
                    turn.text,
                )
                if recovery_records:
                    # Always strip the markup from turn.text so it
                    # never reaches assistant_message storage or
                    # the UI's final-event renderer.
                    turn.text = cleaned_text.strip()
                    n_accepted = 0
                    for _i, rec in enumerate(recovery_records):
                        if rec.accepted:
                            turn.tool_calls.append(_TC(
                                id=f"recovered_{iteration}_{_i}",
                                name=rec.tool_name,
                                arguments=rec.arguments_json,
                            ))
                            n_accepted += 1
                            # Yield a one-line system warning so
                            # the UI shows what was recovered.
                            yield AgentEvent(
                                kind="text",
                                text=(
                                    f"\n_↻ recovered text-emitted "
                                    f"tool call: {rec.tool_name} · "
                                    f"{rec.leak.description}_\n"
                                ) if not rec.canonicalized_from else (
                                    f"\n_↻ recovered & canonicalized "
                                    f"{rec.canonicalized_from} → "
                                    f"{rec.tool_name}: "
                                    f"{rec.leak.description}_\n"
                                ),
                                iteration=iteration,
                            )
                        else:
                            yield AgentEvent(
                                kind="text",
                                text=(
                                    f"\n_⚠ suppressed text-emitted "
                                    f"call to {rec.tool_name!r}: "
                                    f"{rec.refused_reason}_\n"
                                ),
                                iteration=iteration,
                            )
                    self.audit("text_leak_recovered", {
                        "n_leaks": len(recovery_records),
                        "n_accepted": n_accepted,
                        "names": [
                            r.tool_name for r in recovery_records
                            if r.accepted
                        ],
                    })

            # Successful turn (or partial) — clear the failure counter
            # for this prompt so a future failure on a DIFFERENT prompt
            # doesn't trigger escalation off this prompt's history.
            if not use_claude and (turn.text or turn.tool_calls):
                from prometheus.provider.router import record_free_success
                record_free_success(self.escalation, user_message)

            # Append assistant message (with any tool calls). Pre-assign
            # fallback IDs in one pass so the tool-result phase below
            # can reference the SAME id (audit P0: previously the
            # result phase recomputed via list.index() which collided
            # when two tool calls both had id=None).
            asst_msg: dict[str, Any] = {"role": "assistant"}
            asst_msg["content"] = turn.text or None
            if turn.tool_calls:
                # Mutate the ToolCall objects in-place so any consumer
                # (snapshot, audit, message-history serializer) sees
                # the canonical id.
                for i, tc in enumerate(turn.tool_calls):
                    if not tc.id:
                        tc.id = f"call_{iteration}_{i}"
                asst_msg["tool_calls"] = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {"name": tc.name, "arguments": tc.arguments or "{}"},
                    }
                    for tc in turn.tool_calls
                ]
            self.messages.append(asst_msg)

            # If no tool calls, we're done.
            if not turn.tool_calls:
                self.last_assistant_text = turn.text or ""
                if self.permission_mode == "plan" and turn.text:
                    self.last_plan = turn.text
                yield AgentEvent(kind="final", text=turn.text, iteration=iteration)
                return

            # Execute tool calls. Read-only ones go in parallel.
            results = await self._execute_tools(turn.tool_calls)
            any_failure = False
            # Image bytes returned by read_file are bound for an
            # implicit user-message attachment AFTER all tool messages,
            # so vision models can actually SEE them. Without this they
            # rot in result.metadata and never reach the LLM.
            pending_image_parts: list[dict[str, Any]] = []
            for tc, result in zip(turn.tool_calls, results):
                yield AgentEvent(
                    kind="tool_result",
                    tool_call=tc,
                    tool_result=result,
                    iteration=iteration,
                )
                # Scrub secrets out of tool output before it reaches the
                # LLM. Catches accidental key/token leakage in bash output,
                # web-fetched pages, file reads, etc. Local-only — the
                # full output stays in the audit log for debugging.
                from prometheus.safety.secrets import redact_secrets
                cleaned, redacted = redact_secrets(result.output[:60_000])
                if redacted:
                    self.audit("redacted_secrets", {"tool": tc.name, "n": redacted})
                # Round-96.1: for SUCCESSFUL bash results, replace
                # the model-facing tool message content with the
                # compact form IMMEDIATELY (don't wait for the
                # stale-cycle truncator). The model only needs the
                # success summary + last useful lines to decide its
                # next move; the full output stays in the audit log
                # and on the live PrometheUS app's `_recent_results`
                # for /details last to surface on demand.
                #
                # We only do this for clean exit-0 bash results to
                # avoid hiding the full failure trace on errors —
                # debugging a failed test needs the raw stdout.
                content_for_model = cleaned
                meta = (result.metadata or {}) if isinstance(result.metadata, dict) else {}
                if (
                    tc.name == "run_bash"
                    and isinstance(meta.get("exit"), int)
                    and meta.get("exit") == 0
                ):
                    try:
                        compact = self._build_immediate_compact_bash_content(
                            meta, max_chars=1200,
                        )
                        if compact:
                            content_for_model = compact
                    except Exception:
                        pass
                self.messages.append({
                    "role": "tool",
                    # tc.id was canonicalized in the assistant-msg append
                    # above; safe to use directly without recomputing.
                    "tool_call_id": tc.id,
                    "name": tc.name,
                    "content": content_for_model,
                })
                # Round-95 turn-6: stash a compact form keyed by
                # tool_call_id so a future iteration's stale-output
                # sweep can replace this bulky content with a
                # metadata-only summary — without losing the
                # context the next-turn LLM call genuinely needs.
                try:
                    self._record_compact_tool_form(tc.id, tc.name, result)
                except Exception:
                    pass
                # Image metadata fan-out: read_file on a PNG/JPG/etc.
                # returns metadata={image_bytes, image_mime}. Build a
                # multipart user message after the tool replies so the
                # next model turn sees the image as a vision content
                # block. Audit P0 round-11: previously bytes lived in
                # metadata only and the model never saw them.
                meta = (result.metadata or {}) if isinstance(result.metadata, dict) else {}
                img_bytes = meta.get("image_bytes")
                img_mime = meta.get("image_mime")
                if img_bytes and img_mime:
                    import base64 as _b64
                    b64 = _b64.b64encode(img_bytes).decode("ascii")
                    pending_image_parts.append({
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:{img_mime};base64,{b64}",
                            "detail": "high",
                        },
                    })
                if result.error:
                    any_failure = True
            # Inject a synthetic user message with the image parts so
            # vision models have them in their next turn. Skip for
            # text-only models — the textual placeholder ("[Image
            # attached: ...]") in the tool message already tells the
            # model what's there if it can't see images.
            if pending_image_parts:
                # Round-17 P1: tag the image-bearing message so the next
                # iteration can swap the bytes for a placeholder. Image
                # data-URLs are 100s of KB each; replaying them on every
                # subsequent turn explodes RSS over a 12-hour session
                # (architectural review #45). The vision model only
                # needs the bytes once — once it has produced a textual
                # observation, the image's role is done.
                self.messages.append({
                    "role": "user",
                    "content": [
                        {"type": "text",
                         "text": "Here is the image content from the file you read:"},
                        *pending_image_parts,
                    ],
                    "_prometheus_image_carrier": True,
                })

            if any_failure:
                self.consecutive_failures += 1
            else:
                self.consecutive_failures = 0
            if self.consecutive_failures >= self.settings.consecutive_failure_limit:
                msg = f"3 consecutive tool failures — halting loop."
                yield AgentEvent(kind="halt", error=msg, iteration=iteration)
                return

            # Round-95 turn-4: hard fast-finalize after clear-success.
            # When this iteration had a single run_bash call that
            # returned exit 0 AND the output matches a known success
            # pattern (pytest "X passed in Ys", cargo "test result: ok",
            # etc.), don't burn another LLM turn deliberating. Compose
            # the one-line summary directly and end the turn. Without
            # this, the model spends 60-120s "thinking" after a clean
            # exit-0 with the result already in front of it. Conservative
            # contract: fires only on singleton run_bash + exit 0 +
            # success-regex hit; multi-tool chains are left alone.
            try:
                from prometheus.agent.fast_finalize import should_fast_finalize
                ff = should_fast_finalize(turn.tool_calls, results)
                if ff.fire:
                    self.audit("fast_finalize", {"reason": ff.reason, "reply": ff.reply})
                    # Append a synthetic assistant message so the
                    # session-store has the final reply, just like a
                    # normal turn.
                    self.messages.append({"role": "assistant", "content": ff.reply})
                    self.last_assistant_text = ff.reply
                    # Round-96.5: do NOT yield the text event in the
                    # default path. Smoke 4 retest showed the same
                    # result rendered THREE times: the bash receipt
                    # `result: 370 passed in 3.72s`, this synthesized
                    # assistant line, and the final activity summary
                    # `✓ Tests passed: 370 in 3.72s ...`. The receipt
                    # + the final summary already tell the user
                    # everything; the duplicate inline assistant
                    # text was pure noise. The `final` event still
                    # fires (closes the turn) and `last_assistant_text`
                    # is set so the activity_summary_line can derive
                    # its title.
                    yield AgentEvent(kind="final", text=ff.reply, iteration=iteration)
                    return
            except Exception:
                # Never let the short-circuit's own errors take down a
                # legitimate turn — fall through to the standard loop.
                pass

            # Stuck-loop detection — when the SAME (tool, args, error)
            # triple repeats >=3 times, prepend a system note so the
            # model knows to change strategy. This is the "self-aware
            # status" feature requested in Claude Code issue #40453;
            # without it, free-tier models retry identical failing
            # commands until the iteration cap is hit.
            import hashlib as _hl
            for tc, result in zip(turn.tool_calls, results):
                if not result.error:
                    continue
                fp_src = f"{tc.name}::{tc.arguments[:200]}::{(result.summary or '')[:80]}"
                fp = _hl.sha256(fp_src.encode("utf-8", "replace")).hexdigest()[:16]
                self._repeat_failures[fp] = self._repeat_failures.get(fp, 0) + 1
                # Round 208 — first live Windows-test bug: user watched
                # the agent retry `TZ="..." date` twice with the same
                # failure and stall. Threshold was 3 (so a third retry
                # had to fail before the hint dropped). Lowered to 2 so
                # the hint lands AFTER the second identical failure and
                # the model sees it BEFORE issuing a third call.
                if self._repeat_failures[fp] == 2:
                    self.audit("repeat_failure_hint", {
                        "tool": tc.name,
                        "summary": (result.summary or "")[:80],
                        "iteration": iteration,
                    })
                    self.messages.append({
                        "role": "system",
                        "content": (
                            f"You have called {tc.name} with the same arguments "
                            f"twice and got the same error each time "
                            f"({(result.summary or 'error')[:80]}). DO NOT call "
                            f"{tc.name} a third time with these arguments — that "
                            f"will fail the same way. Try a different strategy: "
                            f"change the command (e.g. on Windows use PowerShell "
                            f"natives like Get-Date / Invoke-WebRequest / winget "
                            f"instead of POSIX `date` / `curl` / `apt`), use a "
                            f"different tool, ask the user for clarification, or "
                            f"summarize what you've learned and stop."
                        ),
                    })

        # Hit the iteration cap.
        yield AgentEvent(
            kind="halt",
            error=f"max iterations ({self.settings.max_iterations}) reached",
            iteration=self.settings.max_iterations,
        )

    async def _execute_tools(self, tool_calls: list[ToolCall]) -> list[ToolResult]:
        """Run all tool calls. Read-only ones in parallel."""
        ctx = self._make_ctx()
        results: list[ToolResult | None] = [None] * len(tool_calls)

        # _turn_tools, _call_cache, _hooks, _rules are reset once per
        # user request in run() — NOT per iteration. That keeps guards
        # like "fetch blocked after search" working when the model
        # calls search in iteration 1 and fetch in iteration 2.
        ctx.turn_tools = self._turn_tools
        # Phase 1: kick off parallel READ/NETWORK tools.
        parallel_idxs: list[int] = []
        sequential_idxs: list[int] = []
        for i, tc in enumerate(tool_calls):
            tool = self.registry.get(tc.name)
            if tool is None:
                # R219: smoke #5 surfaced the model emitting `task`
                # (Claude Code's PascalCase subagent dispatcher) and
                # getting `unknown tool: task` with no recovery hint.
                # Suggest the closest registered tool name so the
                # next iteration can self-correct.
                hint = self.registry.suggest_close_match(tc.name)
                output = f"unknown tool: {tc.name}"
                if hint:
                    output += f" — did you mean: {hint}?"
                results[i] = ToolResult(
                    output=output,
                    error=True,
                    summary=f"{tc.name}(unknown)",
                )
                continue
            if tool.side_effect in (SideEffect.READ, SideEffect.NETWORK):
                parallel_idxs.append(i)
            else:
                sequential_idxs.append(i)

        async def run_one(i: int) -> None:
            # Round-96.3: bullet-proof outer wrapper. Smoke 4 retest
            # consistently surfaced "discover_test_command execution
            # failed" in the public timeline — the parallel-dispatch
            # gather-level fallback at line ~1577. That fallback only
            # fires if run_one ITSELF raises (so the gather collects a
            # BaseException from `return_exceptions=True`). The inner
            # try/except wraps `await tool.execute(...)` but NOT the
            # prologue (parsed_arguments / dedup / rule eval / hook
            # eval / ctx_for_call construction). Any exception in the
            # prologue escapes the inner try and lands in the
            # parallel-crash branch with the alarming public summary.
            #
            # The outer try/except below catches ANY escape, fills
            # results[i] with a clean ToolResult, and re-raises as a
            # NON-exception (just returns) so gather doesn't trigger
            # the parallel-crash fallback. The actual error is logged
            # via audit for /details last and disk audit log.
            try:
                await _run_one_inner(i)
            except Exception as _e:
                # Last-resort safety net.
                logger.exception(
                    "run_one outer wrapper caught escape on tool %s",
                    tool_calls[i].name if i < len(tool_calls) else "?",
                )
                try:
                    self.audit("tool_outer_crash", {
                        "tool":  tool_calls[i].name if i < len(tool_calls) else "?",
                        "error": repr(_e),
                    })
                except Exception:
                    pass
                if results[i] is None:
                    tname = (
                        tool_calls[i].name
                        if i < len(tool_calls) else "tool"
                    )
                    results[i] = ToolResult(
                        output=(
                            f"{tname} could not run: {_e!s}\n"
                            f"This is an internal PrometheUS dispatch "
                            f"hiccup, not a failure of the underlying "
                            f"command. Try a simpler approach (e.g. "
                            f"run_bash with the intended command) "
                            f"directly, or continue without this "
                            f"tool's output."
                        ),
                        error=True,
                        summary=f"{tname} could not run",
                    )

        async def _run_one_inner(i: int) -> None:
            tc = tool_calls[i]
            tool = self.registry.get(tc.name)
            if tool is None:
                return
            args = tc.parsed_arguments()
            if args.get("_parse_error"):
                results[i] = ToolResult(
                    output=f"could not parse arguments JSON: {args.get('_raw','')[:200]}",
                    error=True,
                    summary=f"{tc.name}(bad-args)",
                )
                return
            # Per-turn dedup: same tool + same args = cached result.
            # Skip dedup for tools whose effects MUST run every time
            # (run_bash side-effects, todo_write progress, ask_user_question).
            non_dedup = {"run_bash", "todo_write", "ask_user_question", "task"}
            fingerprint = ""
            if tool.name not in non_dedup:
                try:
                    fp = json.dumps(args, sort_keys=True, default=str)
                    # Defensive cap: a 10MB args payload (some models hallucinate
                    # huge JSON) shouldn't make the cache key itself huge.
                    if len(fp) > 8000:
                        import hashlib
                        fp = "sha256:" + hashlib.sha256(fp.encode()).hexdigest()
                    fingerprint = f"{tool.name}::{fp}"
                except (TypeError, ValueError):
                    fingerprint = ""
            if fingerprint and fingerprint in self._call_cache:
                cached = self._call_cache[fingerprint]
                results[i] = ToolResult(
                    output=cached.output,
                    summary=(cached.summary + " · cached") if cached.summary else "cached",
                    error=cached.error,
                    metadata=cached.metadata,
                )
                return
            # Plan mode: simulate write/exec tools — return a synthetic
            # result so the model sees what *would* happen but no disk
            # state changes. Read-only tools still run normally.
            if (
                self.permission_mode == "plan"
                and tool.side_effect in (SideEffect.WRITE, SideEffect.EXEC)
            ):
                # Round-17 plan-mode diff preview: for the file-edit
                # tools, render the actual unified diff that WOULD be
                # applied. Surfaces concrete reviewable output instead
                # of the model's args dump, so the user can decide
                # whether to switch to acceptEdits and re-run.
                preview_body = f"[plan-mode] would call {tc.name} with args: {args}"
                try:
                    if tc.name in ("edit_file", "multi_edit", "write_file"):
                        from prometheus.tools.files import _resolve, _unified_diff
                        from pathlib import Path as _Path
                        path = _resolve(self.settings.workdir, str(args.get("path", "")))
                        existed = path.exists()
                        text_before = path.read_text(encoding="utf-8", errors="replace") if existed else ""
                        text_after = text_before
                        if tc.name == "edit_file":
                            old = str(args.get("old", "")); new_s = str(args.get("new", ""))
                            ra = bool(args.get("replace_all", False))
                            if old and old in text_before:
                                text_after = (
                                    text_before.replace(old, new_s)
                                    if ra else text_before.replace(old, new_s, 1)
                                )
                        elif tc.name == "multi_edit":
                            t = text_before
                            for e in (args.get("edits") or []):
                                o = str(e.get("old", "")); n = str(e.get("new", ""))
                                ra = bool(e.get("replace_all", False))
                                if o and o in t:
                                    t = t.replace(o, n) if ra else t.replace(o, n, 1)
                            text_after = t
                        elif tc.name == "write_file":
                            text_after = str(args.get("content", ""))
                        diff = _unified_diff(text_before, text_after, _Path(str(path)).name, max_lines=80)
                        verb = "create" if not existed else "edit"
                        preview_body = (
                            f"[plan-mode preview] would {verb} {path}\n{diff}\n"
                            f"(plan mode is read-only — switch with Shift+Tab "
                            f"or `/permissions acceptEdits` then re-run to apply)"
                        )
                except Exception:
                    pass
                results[i] = ToolResult(
                    output=preview_body,
                    summary="plan-mode (preview)",
                )
                return
            # Persistent permission rules from settings.json (deny/allow/ask).
            try:
                from prometheus.safety.rules import evaluate, load_rules
                if not hasattr(self, "_rules") or self._rules is None:
                    self._rules = load_rules(self.settings.workdir)
                verdict = evaluate(self._rules, tool.name, args)
            except Exception:
                verdict = "default"
            if verdict == "deny":
                results[i] = ToolResult(
                    output=f"blocked by permission rule (settings.json deny list)",
                    error=True,
                    summary=f"{tool.name} denied (rule)",
                )
                return
            # allow → fall through and execute (no prompt)
            # ask → keep current behavior (tool's own approval gate kicks in)
            # PreToolUse hooks. Loaded once per turn for cheapness.
            try:
                from prometheus.safety.hooks import load_hooks, run_pre_tool_use, run_post_tool_use
                if not hasattr(self, "_hooks") or self._hooks is None:
                    self._hooks = load_hooks(self.settings.workdir)
                allow, msg = run_pre_tool_use(self._hooks, tool.name, args)
            except Exception:
                allow, msg = True, ""
            if not allow:
                results[i] = ToolResult(
                    output=f"hook denied: {msg}",
                    error=True,
                    summary=f"{tool.name} hook denied",
                )
                return
            # If the rule says "allow", upgrade context permission_mode for this call.
            if verdict == "allow":
                ctx_for_call = ToolContext(
                    workdir=ctx.workdir, permission_mode="acceptEdits",
                    request_approval=ctx.request_approval, notify=ctx.notify,
                    session_id=ctx.session_id, audit=ctx.audit,
                    todos=ctx.todos, snapshots=ctx.snapshots,
                    turn_tools=ctx.turn_tools,
                    # Round 96.14: must carry read_history through the
                    # upgrade or the read-before-edit guard refuses
                    # edits the user pre-allowed via a rule.
                    read_history=ctx.read_history,
                )
            else:
                ctx_for_call = ctx
            # 1.0.4 round-200 fix: pre-dispatch arg validation. The
            # free-tier minimax model dispatched `write_file({})`
            # with empty input — WriteFile correctly errored, but
            # the model then hallucinated "File created." in its
            # next turn. Catching the empty-args call here, before
            # dispatch, gives the model a compact, structured
            # error to course-correct from.
            from prometheus.tools.dispatch import validate_tool_call
            _vfail = validate_tool_call(tool, args)
            if _vfail is not None:
                results[i] = _vfail
                return
            try:
                res = await tool.execute(args, ctx_for_call)
                results[i] = res
                if fingerprint:
                    self._call_cache[fingerprint] = res
                # PostToolUse hooks (best-effort, never fails the call).
                try:
                    run_post_tool_use(self._hooks, tool.name, args, res.summary or "")
                except Exception:
                    pass
            except PermissionDenied as e:
                # Round-24 Claude-parity: stock denial message verbatim.
                # Claude Code returns "The user doesn't want to proceed
                # with this tool use" so the model interprets denial as
                # a pivot signal (ask what to do differently) rather
                # than a hard error to retry.
                results[i] = ToolResult(
                    output=(
                        "The user doesn't want to proceed with this tool use. "
                        f"Tool: {tc.name}. Reason: {e}. "
                        "Ask the user what they'd like you to do differently."
                    ),
                    error=True,
                    summary=f"{tc.name}(denied)",
                )
            except ToolError as e:
                results[i] = ToolResult(
                    output=f"tool error: {e}",
                    error=True,
                    summary=f"{tc.name}(error)",
                )
            except Exception as e:
                logger.exception("tool %s crashed", tc.name)
                results[i] = ToolResult(
                    output=f"tool crashed: {e}",
                    error=True,
                    summary=f"{tc.name}(crash)",
                )

        if parallel_idxs:
            # Round-16 P0: return_exceptions=True so one tool's unhandled
            # exception doesn't cancel the others mid-flight. `run_one`
            # already lands every error path into `results[i]` itself, so
            # any exception bubbling out here is a bug — we log it and
            # leave the slot for the post-loop None-check to backfill.
            outcomes = await asyncio.gather(
                *(run_one(i) for i in parallel_idxs),
                return_exceptions=True,
            )
            for idx, outcome in zip(parallel_idxs, outcomes):
                if isinstance(outcome, BaseException):
                    logger.exception("parallel tool %s raised %s", idx, outcome)
                    if results[idx] is None:
                        # Round-95 turn-8: public-facing summary uses
                        # commercial language ("tool execution failed")
                        # instead of the internal "parallel crash" phrase
                        # that leaked into the chat timeline on smoke 4
                        # turn-7. Technical detail still lives in the
                        # output for the model to reason over. The
                        # tool-name prefix tells the user (and the
                        # model) which call actually failed.
                        tname = tool_calls[idx].name or "tool"
                        results[idx] = ToolResult(
                            output=(
                                f"{tname} execution failed: {outcome!s}\n"
                                f"This is an internal failure of the "
                                f"PrometheUS tool dispatch — not the "
                                f"underlying command. Try a simpler "
                                f"approach (e.g. run_bash with the "
                                f"intended command directly), or "
                                f"continue without this tool's output."
                            ),
                            error=True,
                            summary=f"{tname} execution failed",
                        )
        for i in sequential_idxs:
            await run_one(i)

        # All results should be filled; mypy guard:
        return [r if r is not None else ToolResult(output="(no result)", error=True) for r in results]
