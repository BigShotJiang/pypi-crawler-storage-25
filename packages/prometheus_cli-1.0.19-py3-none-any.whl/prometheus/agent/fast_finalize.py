"""Round-95 turn-4: hard post-tool short-circuit.

When a tool result clearly indicates a complete success (e.g., pytest
"N passed in Ys"), don't burn another LLM turn deliberating. Compose a
one-line summary directly and end the turn.

Without this, the model sometimes spends 60-120s "thinking" after a
clean exit-0 with the result already in front of it. Prompt-only
guidance helps but isn't enough — the model is already deep in
reasoning by the time it sees the directive. This module gives the
agent loop a deterministic shortcut.

Conservative trigger contract:
  • Fires ONLY when the iteration had exactly ONE tool call. Multi-
    tool turns (chains of 2-4) are left alone — those need the model
    to compose a real summary.
  • Fires ONLY for run_bash with metadata.exit == 0.
  • Output must match a clear-success regex from a known runner.
  • Never fires for tools that mutate source (write_file, edit_file,
    etc.) — verification of an edit's correctness is the model's job.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

# Patterns ordered most-specific first. Each maps captured groups to
# a one-line summary template. The first match wins — return its reply.
_SUCCESS_PATTERNS: list[tuple[re.Pattern, str]] = [
    # pytest: "97 passed in 2.92s" / "5 passed, 1 skipped in 0.41s"
    (
        re.compile(
            r"(?P<n>\d+)\s+passed"
            r"(?:,\s*\d+\s+(?:skipped|deselected|warnings?|xfailed))*"
            r"\s+in\s+(?P<t>[\d.]+)s",
            re.IGNORECASE,
        ),
        "Tests passed: {n} in {t}s.",
    ),
    # node test runner / mocha / jest: "Tests:       42 passed, 42 total"
    (
        re.compile(
            r"Tests:\s+(?P<n>\d+)\s+passed",
            re.IGNORECASE,
        ),
        "Tests passed: {n}.",
    ),
    # cargo test: "test result: ok. 23 passed; 0 failed"
    (
        re.compile(
            r"test\s+result:\s+ok\.\s+(?P<n>\d+)\s+passed",
            re.IGNORECASE,
        ),
        "Tests passed: {n}.",
    ),
    # go test (-v): "PASS\nok      package    0.42s"
    (
        re.compile(
            r"^PASS\s*$.*?^ok\s+\S+\s+(?P<t>[\d.]+)s",
            re.MULTILINE | re.DOTALL,
        ),
        "Go tests passed in {t}s.",
    ),
    # generic OK / passing
    (
        re.compile(r"\ball\s+tests\s+passed\b", re.IGNORECASE),
        "All tests passed.",
    ),
    (
        re.compile(r"^\s*OK\s*$", re.MULTILINE),
        "OK.",
    ),
]


@dataclass
class FinalizeDecision:
    fire: bool
    reply: str = ""
    reason: str = ""


def should_fast_finalize(
    tool_calls: list[Any], results: list[Any],
) -> FinalizeDecision:
    """Decide whether the current iteration should short-circuit.

    Returns FinalizeDecision(fire=True, reply="...") when:
      - exactly one tool call this iteration
      - that call was run_bash
      - the result has metadata.exit == 0
      - the output matches a clear-success pattern

    Otherwise returns FinalizeDecision(fire=False) — the loop
    continues normally and the model gets to think.
    """
    if len(tool_calls) != 1 or len(results) != 1:
        return FinalizeDecision(fire=False, reason="non-singleton")
    tc = tool_calls[0]
    rr = results[0]
    if getattr(tc, "name", "") != "run_bash":
        return FinalizeDecision(fire=False, reason="not run_bash")
    meta = getattr(rr, "metadata", None) or {}
    if meta.get("exit") != 0:
        return FinalizeDecision(fire=False, reason=f"exit={meta.get('exit')!r}")
    output = getattr(rr, "output", "") or ""
    for pat, template in _SUCCESS_PATTERNS:
        m = pat.search(output)
        if m:
            try:
                reply = template.format(**m.groupdict())
            except (KeyError, IndexError):
                reply = template
            return FinalizeDecision(
                fire=True, reply=reply,
                reason=f"matched {pat.pattern[:40]!r}",
            )
    return FinalizeDecision(fire=False, reason="no success-pattern match")
