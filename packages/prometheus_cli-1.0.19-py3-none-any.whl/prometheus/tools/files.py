"""File tools: read_file, write_file, edit_file, multi_edit, glob_files, list_files."""
from __future__ import annotations

import fnmatch
import json
import os
from pathlib import Path
from typing import Any

from prometheus.tools.base import (
    PermissionDenied,
    SideEffect,
    Tool,
    ToolContext,
    ToolError,
    ToolResult,
)
from prometheus.tools.ignore import GitIgnore

# Cap how much we feed back to the model from a single read.
MAX_READ_BYTES = 256 * 1024
MAX_LINE_LEN = 2000


def _verify_syntax_after_write(path: Path, content: str) -> str | None:
    """Round-37: lightweight syntax check after a write/edit.

    Returns a one-line verification result for the agent to see, or
    None for file types we don't check. Heavy commands (npm test,
    pytest) are intentionally NOT run here — they can be slow,
    network-touching, and need user approval. We only do in-process
    syntax/parse checks that are fast and side-effect-free.

    Opt-out via PROMETHEUS_DISABLE_VERIFY=1.
    """
    if os.getenv("PROMETHEUS_DISABLE_VERIFY") == "1":
        return None
    suffix = path.suffix.lower()
    try:
        if suffix == ".py":
            import ast
            ast.parse(content, filename=str(path))
            return "verified · py syntax ok"
        if suffix == ".json":
            import json as _json
            _json.loads(content)
            return "verified · json parse ok"
        if suffix in (".yaml", ".yml"):
            try:
                import yaml  # type: ignore
            except ImportError:
                return None
            yaml.safe_load(content)
            return "verified · yaml parse ok"
        if suffix == ".toml":
            try:
                import tomllib  # py 3.11+
            except ImportError:
                return None
            tomllib.loads(content)
            return "verified · toml parse ok"
    except SyntaxError as e:
        return f"verify FAILED · syntax error line {e.lineno}: {e.msg}"
    except Exception as e:
        # JSON/YAML/TOML parse errors land here.
        return f"verify FAILED · {type(e).__name__}: {str(e)[:120]}"
    return None


def _unified_diff(old: str, new: str, name: str, max_lines: int = 40) -> str:
    """Compact unified-style preview of old → new used in approval prompts."""
    import difflib
    if old == new:
        return "(no change)"
    diff = list(difflib.unified_diff(
        old.splitlines(),
        new.splitlines(),
        fromfile=f"a/{name}",
        tofile=f"b/{name}",
        n=2,
        lineterm="",
    ))
    if not diff:
        # Pure addition (no old context).
        body = new.splitlines()
        head = ["+" + line for line in body[:max_lines]]
        if len(body) > max_lines:
            head.append(f"… (+{len(body) - max_lines} more lines)")
        return "\n".join(head)
    if len(diff) > max_lines:
        diff = diff[:max_lines] + [f"… ({len(diff) - max_lines} more diff lines)"]
    return "\n".join(diff)


def _resolve_against_read_history(
    workdir: Path,
    raw_arg: str,
    resolved_path: Path,
    read_history: set[str],
) -> Path | None:
    """Round 96.13: when an Edit/MultiEdit's resolved path isn't in
    read_history, try basename-disambiguation against the read set.

    Smoke 6 retest live failure: the agent called Read with
    `tests/test_smoke6_broken.py` (resolves under workdir → file
    exists, gets added). Then it called Edit with
    `test_smoke6_broken.py` — which `_resolve` joins to `workdir`,
    pointing at `<workdir>/test_smoke6_broken.py` (a DIFFERENT file
    that doesn't exist). The read-first guard then refused the edit
    because the resolved string didn't match what's in read_history.
    The agent re-read, re-edited, re-read again, hit max iterations.

    The fix: if the resolved path isn't in read_history but exactly
    one entry in read_history shares the same basename, use that
    canonical path instead. The user clearly meant the file they
    just read; refusing on a path-spelling mismatch is bad UX and
    actively breaks the repair loop.

    Returns the canonical resolved path on a clean basename match,
    or None if there's no unique match (caller falls back to the
    standard "read first" refusal).
    """
    target = str(resolved_path)
    if target in read_history:
        return resolved_path  # Already canonical.
    # Basename-only fallback: pick the unique read-history entry
    # whose basename matches.
    basename = Path(raw_arg).name if raw_arg else resolved_path.name
    if not basename:
        return None
    matches = [h for h in read_history if Path(h).name == basename]
    if len(matches) == 1:
        try:
            candidate = Path(matches[0])
            if candidate.exists():
                return candidate
        except (OSError, ValueError):
            pass
    return None


def _resolve(workdir: Path, p: str) -> Path:
    """Resolve a possibly-relative path under workdir.

    Behavior:
    - Empty / non-string p → workdir.
    - Relative path → joined to workdir AND confined: if `../../../etc/x`
      would escape, we re-anchor it back inside workdir to prevent the
      agent from ever reading host paths via traversal.
    - Absolute path → passed through. Power users with polyrepo / cross-
      project workflows need this; the secret-path denylist + permission
      rules gate dangerous absolute reads.
    - Symlink loops, NUL bytes, MAX_PATH overflows → never raise.
    """
    if not p or not isinstance(p, str):
        return workdir
    p = p.strip().strip('"').strip("'")
    if not p:
        return workdir
    # Reject NUL bytes — some filesystems treat them as path terminators,
    # so `/etc/passwd\x00/tmp/safe` would resolve to /etc/passwd while
    # the path-traversal confine logic looks at the full string.
    if "\x00" in p:
        return workdir
    try:
        pp = Path(p)
    except (OSError, ValueError):
        return workdir
    is_relative = not pp.is_absolute()
    if is_relative:
        pp = workdir / pp
    try:
        resolved = pp.resolve()
    except (OSError, RuntimeError):
        return pp
    # Confine relative paths inside workdir. Absolute paths (which the
    # agent had to type in full) bypass the check by design.
    if is_relative:
        try:
            workdir_resolved = workdir.resolve()
            if not str(resolved).startswith(str(workdir_resolved)):
                # The model tried to escape via .. — re-anchor at workdir.
                return workdir_resolved / Path(p).name
        except (OSError, RuntimeError):
            pass
    return resolved


def _atomic_write_text(path: Path, content: str) -> None:
    """Write atomically: temp + fsync + rename.

    Defends against the corruption class Claude Code keeps shipping
    fixes for (Issues #29250, #28809) where a crash mid-write or a
    second writer leaves partial JSON on disk.

    Round 182: when `path` already exists, capture its st_mode bits
    BEFORE the rename and re-apply them after — otherwise the temp
    file's mode (0o600 by default on POSIX) replaces the original
    permissions and an executable shell script silently loses its
    +x bit on every save. This is the same fix npm/write-file-atomic
    has had for years (issue npm/write-file-atomic#64).
    """
    import os, stat, tempfile
    path.parent.mkdir(parents=True, exist_ok=True)
    # Capture mode bits before write so the rename doesn't drop them.
    preserved_mode: int | None = None
    try:
        if path.exists():
            preserved_mode = stat.S_IMODE(path.stat().st_mode)
    except OSError:
        preserved_mode = None
    fd, tmp_path = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(content)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        os.replace(tmp_path, path)
        if preserved_mode is not None:
            try:
                os.chmod(path, preserved_mode)
            except (OSError, NotImplementedError):
                # Windows + Cygwin sometimes refuses chmod on NTFS;
                # log silently and continue rather than failing the
                # whole write for a permission-bit cosmetic issue.
                pass
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def _atomic_write_bytes(path: Path, data: bytes) -> None:
    """Round 182: byte-faithful atomic write.

    When the textio module decoded a file with a non-utf-8 codec or a
    BOM-prefixed encoding, we want the writeback to round-trip
    byte-for-byte rather than re-encoding through Python's text-mode
    layer (which can mangle CR/LF on Windows even with newline="").
    Same atomic semantics as _atomic_write_text plus mode
    preservation.
    """
    import os, stat, tempfile
    path.parent.mkdir(parents=True, exist_ok=True)
    preserved_mode: int | None = None
    try:
        if path.exists():
            preserved_mode = stat.S_IMODE(path.stat().st_mode)
    except OSError:
        preserved_mode = None
    fd, tmp_path = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        os.replace(tmp_path, path)
        if preserved_mode is not None:
            try:
                os.chmod(path, preserved_mode)
            except (OSError, NotImplementedError):
                pass
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


class _FileLock:
    """Round-17 P1: cross-platform advisory lock for read-modify-write.

    EditFile/MultiEdit do a read → modify → write sequence. Without a
    lock, two PrometheUS instances editing the same file race past
    `path.exists()` and clobber each other (architectural review #50).
    On POSIX we use `fcntl.flock`; on Windows we use `msvcrt.locking`
    against a sidecar `.path.lock` file so we never lock the file
    we're about to atomically replace (replace would fail under the
    Windows lock). Best-effort — locking failures degrade gracefully
    to no-lock behaviour, which is the pre-round-17 baseline.
    """
    def __init__(self, target: Path) -> None:
        self.target = target
        self._fh: Any = None
        self._lock_path: Path | None = None

    def __enter__(self) -> "_FileLock":
        import os, sys
        try:
            self.target.parent.mkdir(parents=True, exist_ok=True)
            self._lock_path = self.target.parent / f".{self.target.name}.lock"
            self._fh = open(self._lock_path, "a+")
            if sys.platform == "win32":
                try:
                    import msvcrt
                    # Block up to ~5 s on a contended lock.
                    for _ in range(50):
                        try:
                            msvcrt.locking(self._fh.fileno(), msvcrt.LK_NBLCK, 1)
                            break
                        except OSError:
                            import time as _t
                            _t.sleep(0.1)
                except (OSError, ImportError):
                    pass
            else:
                try:
                    import fcntl
                    fcntl.flock(self._fh.fileno(), fcntl.LOCK_EX)
                except (OSError, ImportError):
                    pass
        except Exception:
            self._fh = None
        return self

    def __exit__(self, *exc: Any) -> None:
        import sys
        fh = self._fh
        if fh is None:
            return
        try:
            if sys.platform == "win32":
                try:
                    import msvcrt
                    msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
                except (OSError, ImportError):
                    pass
            else:
                try:
                    import fcntl
                    fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
                except (OSError, ImportError):
                    pass
        finally:
            try:
                fh.close()
            except OSError:
                pass


def _normalize_edit_line_endings(file_text: str, old: str, new: str) -> tuple[str, str]:
    """Round 175: bridge LF / CRLF mismatches transparently.

    If `old` doesn't appear in the file as-is BUT the line-ending-
    flipped form does (LF → CRLF or CRLF → LF), return the flipped
    forms of both `old` and `new` so the substitution operates on
    the file's actual line-ending convention.

    Conservative — only flips when the as-is form has zero matches.
    Files containing both line-ending styles (mixed) keep the
    user-supplied form so we don't accidentally convert a portion
    of the file silently.
    """
    if not old:
        return old, new
    if old in file_text:
        return old, new
    # Try CRLF version of old.
    if "\n" in old and "\r\n" not in old:
        crlf_old = old.replace("\n", "\r\n")
        if crlf_old in file_text:
            crlf_new = new.replace("\n", "\r\n") if "\n" in new else new
            return crlf_old, crlf_new
    # Try LF version of old.
    if "\r\n" in old:
        lf_old = old.replace("\r\n", "\n")
        if lf_old in file_text:
            lf_new = new.replace("\r\n", "\n")
            return lf_old, lf_new
    # No match either way; let the upstream miss-handler take over.
    return old, new


def _truncate_lines(text: str) -> str:
    out = []
    truncated = False
    for line in text.splitlines():
        if len(line) > MAX_LINE_LEN:
            out.append(line[:MAX_LINE_LEN] + " …[line truncated]")
            truncated = True
        else:
            out.append(line)
    s = "\n".join(out)
    return s + ("\n…[lines truncated]" if truncated else "")


def _parse_page_range(spec: Any, total_pages: int) -> tuple[int, int]:
    """Round 175: parse Claude Code's `pages` parameter.

    Accepts `"3"`, `"1-5"`, `"3-"` (3 to end), `"-5"` (start to 5).
    Returns a (start_idx, end_idx_inclusive) pair, both 0-indexed.
    Falls back to (0, min(9, total - 1)) when the spec is unusable
    so default reads cap at the first 10 pages — matches the
    Claude Code default for unbounded PDF reads.

    Clamps both ends to `[0, total_pages - 1]` so an out-of-range
    request (`"100-200"` against a 5-page PDF) yields the last
    page rather than erroring.
    """
    if total_pages <= 0:
        return 0, 0
    last = total_pages - 1
    def _clamp(i: int) -> int:
        return max(0, min(last, i))
    if not spec:
        return 0, min(9, last)
    s = str(spec).strip()
    try:
        if "-" in s:
            a, b = s.split("-", 1)
            start = _clamp(int(a) - 1) if a.strip() else 0
            end = _clamp(int(b) - 1) if b.strip() else last
        else:
            start = _clamp(int(s) - 1)
            end = start
    except ValueError:
        return 0, min(9, last)
    if end < start:
        end = start
    return start, end


def _read_pdf(path: Path, pages_spec: Any) -> ToolResult:
    """Round 175: PDF text extraction. Tries pypdf, then
    pdfminer.six. Returns a clean install-hint if neither is
    installed. Output mirrors Claude Code's per-page header:

        [Page N]
        <text>
    """
    # Try pypdf first.
    pages_text: list[str] = []
    total = 0
    backend = ""
    try:
        from pypdf import PdfReader  # type: ignore
        try:
            reader = PdfReader(str(path))
        except Exception as e:
            return ToolResult(
                output=f"pdf parse failed (pypdf): {e}",
                error=True, summary="pdf parse failed",
            )
        total = len(reader.pages)
        start, end = _parse_page_range(pages_spec, total)
        for i in range(start, min(end + 1, total)):
            try:
                pages_text.append(reader.pages[i].extract_text() or "")
            except Exception:
                pages_text.append("(page extraction failed)")
        backend = "pypdf"
    except ImportError:
        try:
            from pdfminer.high_level import extract_text  # type: ignore
            from pdfminer.pdfparser import PDFParser  # type: ignore
            from pdfminer.pdfdocument import PDFDocument  # type: ignore
            with path.open("rb") as f:
                doc = PDFDocument(PDFParser(f))
                # pdfminer doesn't expose page count cleanly without
                # walking; we extract text in one pass and split by
                # form-feed (which pdfminer emits between pages).
            full = extract_text(str(path))
            chunks = full.split("\f")
            total = len(chunks)
            start, end = _parse_page_range(pages_spec, total)
            pages_text = chunks[start:min(end + 1, total)]
            backend = "pdfminer"
        except ImportError:
            return ToolResult(
                output=(
                    f"pdf reader not available — install one of:\n"
                    f"  pip install pypdf\n"
                    f"  pip install pdfminer.six\n"
                    f"then retry. (Path: {path})"
                ),
                error=True, summary="no pdf reader",
            )
    body_lines: list[str] = []
    start, _end = _parse_page_range(pages_spec, total)
    for offset_in_range, txt in enumerate(pages_text):
        page_no = start + offset_in_range + 1
        body_lines.append(f"[Page {page_no} of {total}]")
        body_lines.append((txt or "").rstrip() or "(empty page)")
        body_lines.append("")
    if not pages_text:
        return ToolResult(
            output=f"PDF has {total} page(s); requested range yielded none. "
                   f"Use `pages: \"1-{total}\"` to read all.",
            error=True, summary="empty range",
        )
    return ToolResult(
        output="\n".join(body_lines).rstrip(),
        summary=(
            f"{len(pages_text)} of {total} page"
            f"{'s' if total != 1 else ''} · {backend}"
        ),
        metadata={"path": str(path), "pdf_pages": total, "pdf_backend": backend},
    )


def _read_notebook(path: Path, *, offset: int = 1, limit: int = 2000) -> ToolResult:
    """Round 175: render a Jupyter .ipynb as `[Cell N · type]`
    blocks so the agent can reason cell-by-cell. Code cells get
    their `source`; markdown cells too. Outputs are dropped (they
    bloat context and rot fast)."""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        return ToolResult(
            output=f"notebook parse failed: {e}",
            error=True, summary="notebook parse failed",
        )
    cells = data.get("cells")
    if not isinstance(cells, list):
        return ToolResult(
            output=f"not a notebook (no `cells` array): {path}",
            error=True, summary="not a notebook",
        )
    body_lines: list[str] = []
    for i, c in enumerate(cells, 1):
        kind = str(c.get("cell_type", "?"))
        cell_id = str(c.get("id", "")).strip()
        head_extra = f" · id={cell_id}" if cell_id else ""
        head = f"[Cell {i} · {kind}{head_extra}]"
        body_lines.append(head)
        src = c.get("source", "")
        if isinstance(src, list):
            src = "".join(src)
        body_lines.append(str(src).rstrip() or "(empty)")
        body_lines.append("")
    full = "\n".join(body_lines).rstrip()
    # Apply offset/limit on the full rendered body so very long
    # notebooks page consistently with regular file reads.
    text_lines = full.splitlines()
    total = len(text_lines)
    end = min(total, max(1, offset - 1) + limit)
    slice_ = text_lines[max(0, offset - 1):end]
    numbered = "\n".join(slice_)
    more = "" if end >= total else f"\n…[{total - end} more lines]"
    return ToolResult(
        output=numbered + more,
        summary=f"{len(cells)} cell{'s' if len(cells) != 1 else ''}",
        metadata={"path": str(path), "cells": len(cells)},
    )


class ReadFile(Tool):
    name = "read_file"
    description = (
        "Read a text file from disk. Returns its content with 1-indexed line "
        "numbers. Use offset/limit to page through large files."
    )
    side_effect = SideEffect.READ
    # Round 173 / 175: schema accepts both `path` (Prometheus
    # native) and `file_path` (Claude Code shape). The R175 add
    # is `pages` — a Claude Code Read parameter for paging
    # through multi-page PDFs. Without it, a Read of a 200-page
    # PDF would either dump everything (memory blowup) or return
    # an unparseable mess.
    schema = {
        "type": "object",
        "properties": {
            "file_path": {"type": "string", "description": "absolute or workdir-relative path (preferred)"},
            "path": {"type": "string", "description": "alias for file_path"},
            "offset": {"type": "integer", "description": "starting line (1-indexed)", "default": 1},
            "limit": {"type": "integer", "description": "max lines", "default": 2000},
            "pages": {
                "type": "string",
                "description": (
                    "PDF only: page range to read, e.g. \"1-5\" or "
                    "\"3\". Required for PDFs longer than 10 pages."
                ),
            },
        },
        "required": ["file_path"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        # Round 96.28 (research-driven): show the relative path,
        # not just the basename. Claude's tool receipts read
        # `Read(src/foo.py)` (issue #19663) so the user sees folder
        # context. Normalize backslashes for cross-platform display.
        # Round 173: accept either argument name.
        p = args.get("file_path") or args.get("path", "?")
        try:
            p = str(p).replace("\\", "/")
        except Exception:
            pass
        return f"Read({p})"

    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        # Round 173: prefer file_path, fall back to path.
        raw_path = args.get("file_path") or args.get("path") or ""
        path = _resolve(ctx.workdir, str(raw_path))
        offset = max(1, int(args.get("offset", 1)))
        limit = max(1, min(5000, int(args.get("limit", 2000))))
        # Round-93: register the path in read_history at the START of
        # the read, not the end. The OpenAI tool-call protocol allows
        # the model to issue parallel calls (read+edit on the same
        # file), and read_file + edit_file run concurrently in
        # _execute_tools. If we register at the END, edit_file's
        # read-before-edit guard fires before read finishes and
        # rejects the edit indefinitely. Verified live in r93 dump
        # (bd04a20d6) on Groq Llama-3.3 — model retried 3× and the
        # agent halted on consecutive_failures.
        try:
            ctx.read_history.add(str(path))
        except Exception:
            pass
        # Secret-path denylist: refuse before opening (Claude Code Issue
        # #44868 — .env, ~/.ssh/, ~/.aws/, /proc/N/environ leaked).
        from prometheus.safety.secrets import is_secret_path
        is_secret, reason = is_secret_path(path)
        if is_secret:
            return ToolResult(
                output=(f"refused: {path} is a known secret path ({reason}). "
                        f"Add an explicit allow rule in .prometheus/settings.json "
                        f"under permissions.allow if you really need to read it."),
                error=True,
                summary="secret path refused",
            )
        if not path.exists():
            return ToolResult(output=f"path does not exist: {path}", error=True, summary="not found")
        if path.is_dir():
            return ToolResult(output=f"path is a directory: {path}", error=True, summary="path is dir")
        # Image short-circuit — when the model reads a screenshot or a
        # diagram, return it as a multimodal content block via metadata
        # so the agent loop can splice it into the user message. Falls
        # back to a textual placeholder if the active model doesn't
        # support vision (the loop's vision-capable check decides).
        IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}
        suffix = path.suffix.lower()
        if suffix in IMAGE_EXTS:
            try:
                img_bytes = path.read_bytes()
            except Exception as e:
                return ToolResult(output=f"read failed: {e}", error=True, summary="read failed")
            # Hard cap at 5 MB raw — most providers enforce ~5 MB per image.
            if len(img_bytes) > 5 * 1024 * 1024:
                return ToolResult(
                    output=f"image too large ({len(img_bytes)//1024//1024} MB > 5 MB) — "
                           f"resize or crop first",
                    error=True,
                    summary="image too large",
                )
            mime = {
                ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                ".gif": "image/gif", ".webp": "image/webp", ".bmp": "image/bmp",
            }[suffix]
            try:
                ctx.read_history.add(str(path))
            except Exception:
                pass
            return ToolResult(
                output=(
                    f"[Image attached: {path.name} · {len(img_bytes):,} bytes · {mime}]\n"
                    f"The image bytes are forwarded as a vision content block to the "
                    f"next model turn."
                ),
                summary=f"image · {len(img_bytes)//1024:,} KB",
                metadata={
                    "image_bytes": img_bytes,
                    "image_mime": mime,
                    "path": str(path),
                },
            )
        # Round 175: PDF — page-range extraction. We try `pypdf`
        # then `pdfminer.six` (both common, both pure-Python). If
        # neither is installed we surface a clean install hint
        # rather than dumping the raw bytes.
        if suffix == ".pdf":
            try:
                ctx.read_history.add(str(path))
            except Exception:
                pass
            return _read_pdf(path, args.get("pages"))
        # Round 175: Jupyter notebook reading. Claude Code's Read
        # surfaces each cell as `[Cell N · code|markdown]` so the
        # agent can reason about the structure, not just see raw
        # JSON. The NotebookEdit tool handles writes.
        if suffix == ".ipynb":
            try:
                ctx.read_history.add(str(path))
            except Exception:
                pass
            return _read_notebook(path, offset=offset, limit=limit)
        try:
            data = path.read_bytes()[:MAX_READ_BYTES]
            text = data.decode("utf-8", errors="replace")
        except Exception as e:
            return ToolResult(output=f"read failed: {e}", error=True, summary=f"Read({path.name})")
        lines = text.splitlines()
        total = len(lines)
        end = min(total, offset - 1 + limit)
        slice_ = lines[offset - 1 : end]
        numbered = "\n".join(f"{i + offset:>6}\t{_truncate_lines(line)}" for i, line in enumerate(slice_))
        more = "" if end >= total else f"\n…[{total - end} more lines]"
        # Round-24 Claude-parity: record this path so EditFile /
        # MultiEdit / ApplyPatch can refuse to edit something the
        # agent hasn't read. Stored as the resolved string path so
        # symlinks / relative-vs-absolute don't cause false negatives.
        try:
            ctx.read_history.add(str(path))
        except Exception:
            pass
        return ToolResult(
            output=numbered + more,
            summary=f"{end - (offset - 1)} lines",
            metadata={"path": str(path), "lines": total},
        )


class WriteFile(Tool):
    name = "write_file"
    description = (
        "Write or overwrite a file. Creates parent directories. Returns the "
        "path on success. Prefer edit_file for modifying existing files."
    )
    side_effect = SideEffect.WRITE
    # Round 173: schema accepts both `path` (Prometheus native) and
    # `file_path` (Claude Code shape).
    schema = {
        "type": "object",
        "properties": {
            "file_path": {"type": "string", "description": "absolute or workdir-relative path (preferred)"},
            "path": {"type": "string", "description": "alias for file_path"},
            "content": {"type": "string"},
        },
        "required": ["file_path", "content"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        # Round 96.28: relative path, not basename (Claude rhythm).
        # Round 173: accept either argument name.
        p = str(args.get("file_path") or args.get("path", "?")).replace("\\", "/")
        return f"Write({p})"

    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        if (r := ctx.plan_mode_refusal("write_file")):
            return r
        # Round 173: prefer file_path, fall back to path.
        raw_path = args.get("file_path") or args.get("path") or ""
        # Round 177: empty raw_path resolves to the workdir itself
        # (a directory). Without this gate, the subsequent
        # `path.read_bytes()` would crash with PermissionError on
        # Windows ("file is being used by another process") or
        # IsADirectoryError on POSIX. Reject explicitly with a
        # clean message so the model knows what to fix.
        if not str(raw_path).strip():
            return ToolResult(
                output="file_path is required (path to write to)",
                error=True, summary="missing file_path",
            )
        path = _resolve(ctx.workdir, str(raw_path))
        if path.exists() and path.is_dir():
            return ToolResult(
                output=f"path is a directory, not a file: {path}",
                error=True, summary="path is a dir",
            )
        content = str(args.get("content", ""))
        if ctx.permission_mode not in ("acceptEdits", "skipAll"):
            existed = path.exists()
            old = path.read_text(encoding="utf-8", errors="replace") if existed else ""
            diff_preview = _unified_diff(old, content, path.name, max_lines=40)
            detail = (
                f"{'overwrite' if existed else 'create'} {path} "
                f"({len(content)} bytes)\n{diff_preview}"
            )
            ok = await ctx.request_approval("write_file", detail)
            if not ok:
                raise PermissionDenied(f"user denied write to {path}")
        path.parent.mkdir(parents=True, exist_ok=True)
        existed = path.exists()
        before = path.read_bytes() if existed else None
        _atomic_write_text(path, content)
        ctx.audit(
            "write_file",
            {"path": str(path), "bytes": len(content.encode()), "existed": existed},
        )
        # checkpoint snapshot for /rewind
        ctx.snapshots.append({
            "kind": "write_file",
            "path": str(path),
            "before": before.decode("utf-8", "replace") if before is not None else None,
            "after": content,
        })
        verb = "updated" if existed else "created"
        # Round-37: verify-after-write. Lightweight syntax check
        # for parseable file types so the agent can self-correct
        # before declaring success.
        verify = _verify_syntax_after_write(path, content)
        verify_line = f"\n{verify}" if verify else ""
        # Verification snippet — show the first/last few lines so the
        # user (and the model) can see what actually landed without an
        # extra read_file call. Round-11 polish: skip the preview block
        # entirely for tiny files (≤6 lines AND ≤300 bytes); it just
        # bloats the receipt for trivial config edits.
        lines = content.splitlines()
        n = len(lines)
        n_bytes = len(content.encode())
        # Round-96.7 / 96.7c: descriptive receipt summary including
        # the relative path so the receipt reads as a complete
        # sentence in compact mode:
        #   ● Write(out.txt)
        #     ⎿ Wrote 12 lines to out.txt
        # Path is shown relative to the workdir when possible to keep
        # the line tight; falls back to the full path otherwise.
        try:
            rel_path = str(path.relative_to(ctx.workdir))
        except (ValueError, OSError):
            rel_path = str(path)
        rel_path = rel_path.replace("\\", "/")
        verb_word = "Wrote" if not existed else "Updated"
        receipt_summary = (
            f"{verb_word} {n} line{'s' if n != 1 else ''} to {rel_path}"
        )
        if n <= 6 and n_bytes <= 300:
            return ToolResult(
                output=f"{verb} {path} ({n_bytes} bytes, {n} line{'s' if n != 1 else ''}){verify_line}",
                summary=receipt_summary,
            )
        if n <= 12:
            preview_block = "\n".join(lines)
        else:
            head = "\n".join(lines[:6])
            tail = "\n".join(lines[-4:])
            preview_block = f"{head}\n…[{n - 10} more lines]\n{tail}"
        return ToolResult(
            output=(
                f"{verb} {path} ({n_bytes} bytes, {n} lines){verify_line}\n"
                f"--- preview ---\n{preview_block}"
            ),
            summary=receipt_summary,
        )


class EditFile(Tool):
    name = "edit_file"
    description = (
        "Replace exactly one occurrence of `old_string` with `new_string` "
        "in a file. Fails if `old_string` is not found, or appears more than "
        "once when `replace_all` is false. Use multi_edit for multiple "
        "separate edits."
    )
    side_effect = SideEffect.WRITE
    # Round 173: schema accepts both Prometheus-native names
    # (`path`, `old`, `new`) and Claude Code names
    # (`file_path`, `old_string`, `new_string`). Without this the
    # model's edit calls trained against the CC schema landed with
    # `'old' may not be empty` because Prometheus only checked
    # `args.get("old")`.
    schema = {
        "type": "object",
        "properties": {
            "file_path": {"type": "string", "description": "absolute or workdir-relative path (preferred)"},
            "path": {"type": "string", "description": "alias for file_path"},
            "old_string": {"type": "string", "description": "exact text to find (preferred)"},
            "old": {"type": "string", "description": "alias for old_string"},
            "new_string": {"type": "string", "description": "replacement text (preferred)"},
            "new": {"type": "string", "description": "alias for new_string"},
            "replace_all": {"type": "boolean", "default": False},
        },
        "required": ["file_path", "old_string", "new_string"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        # Round 96.29: `Update({path})` matches Claude's terminology
        # for an in-place edit. The internal tool name stays
        # `EditFile` (model-facing schema) — this is render-only.
        # Round 173: accept either argument name.
        p = str(args.get("file_path") or args.get("path", "?")).replace("\\", "/")
        return f"Update({p})"

    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        if (r := ctx.plan_mode_refusal("edit_file")):
            return r
        # Round 173: prefer Claude Code names; fall back to Prometheus.
        raw_arg = str(args.get("file_path") or args.get("path") or "")
        path = _resolve(ctx.workdir, raw_arg)
        old = str(
            args["old_string"] if "old_string" in args else args.get("old", "")
        )
        new = str(
            args["new_string"] if "new_string" in args else args.get("new", "")
        )
        replace_all = bool(args.get("replace_all", False))
        # Round 96.13: basename-disambiguate against read_history
        # BEFORE the existence + read-first checks. Smoke 6 retest
        # live case: agent read tests/test_smoke6_broken.py then
        # called Edit with just test_smoke6_broken.py — _resolve
        # pointed it at <workdir>/test_smoke6_broken.py, which (a)
        # didn't exist and (b) wasn't in read_history. Both checks
        # below would have refused; the basename-fallback rebinds
        # `path` to the file the agent actually meant.
        canonical = _resolve_against_read_history(
            ctx.workdir, raw_arg, path, ctx.read_history,
        )
        if canonical is not None:
            path = canonical
        if not path.exists():
            return ToolResult(output=f"file not found: {path}", error=True, summary="not found")
        if not old:
            return ToolResult(output="`old` may not be empty", error=True, summary="empty pattern")
        # Round-24 Claude-parity: read-before-edit guard. Refuses to
        # edit a file the agent hasn't Read this session, matching
        # Claude Code's `EditWithoutReadError`. Returns the same
        # actionable message so the model retries with a Read first.
        if str(path) not in ctx.read_history:
            return ToolResult(
                output=(
                    f"refused: must use the Read tool on {path} at least once "
                    f"in this session before editing. Read it first, then retry "
                    f"the edit."
                ),
                error=True,
                summary="read first",
            )
        # Round-17 P1: lock the read-modify-write critical section so
        # two concurrent PrometheUS instances editing the same file
        # can't clobber each other.
        with _FileLock(path):
            return await self._execute_locked(path, old, new, replace_all, ctx)

    async def _execute_locked(self, path: Path, old: str, new: str, replace_all: bool, ctx: ToolContext) -> ToolResult:
        # Round 175: read raw bytes and decode without universal-
        # newline translation. `Path.read_text()` collapses CRLF→LF
        # on read, and the subsequent `_atomic_write_text(newline="")`
        # writes the LF-only string back — silently corrupting
        # CRLF files. Real bug for any Windows-native file
        # (.bat, .ps1, VS solution files) and any repo with
        # `core.autocrlf=false`. read_bytes preserves the CRLF
        # in the buffer; replace operates on the literal bytes;
        # writeback keeps them intact.
        # Round 182: route the decode through textio.decode_smart so
        # UTF-8 BOM, UTF-16, and legacy single-byte codecs (cp1252 /
        # iso-8859-1) round-trip byte-for-byte. Pre-R182 this used
        # `errors="replace"` which silently mojibakes the first edit
        # of a non-UTF-8 source file (chardet#30, gemini-cli#14124,
        # claude-code#10709 — all the same class of bug).
        from prometheus.textio import decode_smart, encode_smart
        raw_bytes = path.read_bytes()
        text, _text_info = decode_smart(raw_bytes)
        # Round 175: line-ending normalization. The agent often has
        # no easy way to tell whether the file is CRLF or LF, and
        # producing exact byte-for-byte `old_string` would require
        # an extra Read each turn. If the literal `old` doesn't
        # match but the LE-flipped form does, retarget transparently.
        # `new` is flipped consistently so the rewritten chunk
        # matches the file's convention.
        old, new = _normalize_edit_line_endings(text, old, new)
        count = text.count(old)
        if count == 0:
            # Round 96.12: surface enough context for the model to
            # retry. Smoke 6 live failure: agent's first edit attempt
            # missed because the snippet drifted, the receipt said
            # only "no match", and the agent finalized instead of
            # re-reading and retrying. The new error message names
            # the next concrete steps (re-read, retry with current
            # contents, narrow context) AND echoes the first 800
            # chars of the file so a small file's full contents are
            # right there in the tool result for the next-turn LLM
            # call.
            file_preview = text[:800]
            if len(text) > 800:
                file_preview += f"\n…[{len(text) - 800} chars truncated — re-read for full contents]"
            return ToolResult(
                output=(
                    f"`old` not found in {path}.\n"
                    "The snippet you sent doesn't appear verbatim in "
                    "the file. Likely causes:\n"
                    "  • whitespace / line-ending drift\n"
                    "  • the file changed since you last read it\n"
                    "  • the snippet matches across a line break that "
                    "the source breaks differently\n"
                    "Next step: call read_file again, locate the "
                    "exact line(s) you want to change in the fresh "
                    "contents, then retry edit_file with that exact "
                    "text. For a one-line change, include enough "
                    "surrounding context to make `old` uniquely "
                    "identifiable.\n"
                    f"--- current contents of {path} ---\n"
                    f"{file_preview}"
                ),
                error=True,
                summary="no match — re-read and retry",
            )
        if count > 1 and not replace_all:
            return ToolResult(
                output=f"`old` matches {count} times; pass replace_all=true or include more context",
                error=True,
                summary=f"{count} matches · need replace_all",
            )
        new_text = text.replace(old, new) if replace_all else text.replace(old, new, 1)
        if ctx.permission_mode not in ("acceptEdits", "skipAll"):
            preview = _unified_diff(text, new_text, path.name, max_lines=40)
            detail = f"edit {path} ({count} replacement{'s' if count > 1 else ''})\n{preview}"
            ok = await ctx.request_approval("edit_file", detail)
            if not ok:
                raise PermissionDenied(f"user denied edit to {path}")
        ctx.snapshots.append({"kind": "edit_file", "path": str(path), "before": text, "after": new_text})
        # Round 182: writeback via textio so a BOM-prefixed or
        # non-UTF-8 source round-trips byte-for-byte. When the source
        # was clean utf-8 with no BOM, _text_info.encoding is "utf-8"
        # and encode_smart() emits the same bytes _atomic_write_text
        # would have — so this is a no-op for the common case.
        if _text_info.encoding == "utf-8" and not _text_info.had_bom:
            _atomic_write_text(path, new_text)
        else:
            _atomic_write_bytes(path, encode_smart(new_text, _text_info))
        n = count if replace_all else 1
        ctx.audit("edit_file", {"path": str(path), "replacements": n})
        verify = _verify_syntax_after_write(path, new_text)
        verify_line = f"\n{verify}" if verify else ""
        # Round-96.7b: descriptive summary so the receipt reads as
        # `● Edit(path) / ⎿ Replaced N occurrences` instead of the
        # legacy bare `N replacements` form.
        return ToolResult(
            output=f"edited {path} ({n} replacement{'s' if n != 1 else ''}){verify_line}",
            summary=(
                f"Replaced {n} occurrence{'s' if n != 1 else ''}"
            ),
        )


class MultiEdit(Tool):
    name = "multi_edit"
    description = (
        "Apply many sequential edits to one file in a single transaction. "
        "Each edit applies to the result of the previous one. Atomic: if "
        "any edit fails, none are written."
    )
    side_effect = SideEffect.WRITE
    # Round 174: dual-schema. Accepts both Prometheus-native names
    # (`path`, edits[].old/new) and Claude Code names (`file_path`,
    # edits[].old_string/new_string). Without this MultiEdit calls
    # from a CC-trained model would have errored on every entry.
    schema = {
        "type": "object",
        "properties": {
            "file_path": {"type": "string", "description": "absolute or workdir-relative path (preferred)"},
            "path": {"type": "string", "description": "alias for file_path"},
            "edits": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "old_string": {"type": "string", "description": "exact text to find (preferred)"},
                        "old": {"type": "string", "description": "alias for old_string"},
                        "new_string": {"type": "string", "description": "replacement text (preferred)"},
                        "new": {"type": "string", "description": "alias for new_string"},
                        "replace_all": {"type": "boolean", "default": False},
                    },
                    "required": ["old_string", "new_string"],
                },
            },
        },
        "required": ["file_path", "edits"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        # Round 96.28 / 174: relative path; accept either arg name.
        p = str(args.get("file_path") or args.get("path", "?")).replace("\\", "/")
        n = len(args.get("edits") or [])
        return f"MultiEdit({p}, {n} edit{'s' if n != 1 else ''})"

    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        if (r := ctx.plan_mode_refusal("multi_edit")):
            return r
        # Round 174: prefer file_path, fall back to path.
        raw_arg = str(args.get("file_path") or args.get("path") or "")
        path = _resolve(ctx.workdir, raw_arg)
        edits = args.get("edits") or []
        if not isinstance(edits, list) or not edits:
            return ToolResult(output="`edits` must be a non-empty array", error=True, summary="empty edits")
        # Round 96.13: basename-fallback before existence + read-first
        # checks (same flow as EditFile — see comment there).
        canonical = _resolve_against_read_history(
            ctx.workdir, raw_arg, path, ctx.read_history,
        )
        if canonical is not None:
            path = canonical
        if not path.exists():
            return ToolResult(output=f"file not found: {path}", error=True, summary="not found")
        # Round-24 Claude-parity: read-before-edit guard.
        if str(path) not in ctx.read_history:
            return ToolResult(
                output=(
                    f"refused: must use the Read tool on {path} at least once "
                    f"in this session before editing. Read it first, then retry "
                    f"the edit."
                ),
                error=True,
                summary="read first",
            )
        # Round-17 P1: same critical-section lock as EditFile.
        with _FileLock(path):
            return await self._execute_locked(path, edits, ctx)

    async def _execute_locked(self, path: Path, edits: list, ctx: ToolContext) -> ToolResult:
        # Round 175: read raw bytes to preserve CRLF line endings.
        # See EditFile._execute_locked for the full bug history.
        # Round 182: route through textio for BOM/encoding fidelity.
        from prometheus.textio import decode_smart, encode_smart
        raw_bytes = path.read_bytes()
        text, _text_info = decode_smart(raw_bytes)
        original = text
        for i, e in enumerate(edits, 1):
            # Round 174: per-edit dual-schema — prefer Claude Code
            # `old_string`/`new_string`, fall back to native `old`/`new`.
            old = str(
                e["old_string"] if "old_string" in e else e.get("old", "")
            )
            new = str(
                e["new_string"] if "new_string" in e else e.get("new", "")
            )
            ra = bool(e.get("replace_all", False))
            if not old:
                return ToolResult(output=f"edit #{i}: `old_string` empty", error=True, summary=f"edit #{i} empty")
            # Round 175: line-ending normalization, same pattern as
            # EditFile. Each edit re-checks the running `text`
            # because a previous edit could have changed which
            # line endings are present.
            old, new = _normalize_edit_line_endings(text, old, new)
            count = text.count(old)
            if count == 0:
                # Round 96.12: same retry-guidance message as Edit so
                # multi_edit's no-match path doesn't lead the model
                # to finalize early either.
                file_preview = text[:800]
                if len(text) > 800:
                    file_preview += f"\n…[{len(text) - 800} chars truncated — re-read for full contents]"
                return ToolResult(
                    output=(
                        f"edit #{i}: `old` not found in {path}.\n"
                        "The snippet doesn't match the file verbatim "
                        "(whitespace drift, file changed since last "
                        "read, or line-break boundary). Re-read with "
                        "read_file, locate the exact line(s), then "
                        "retry multi_edit (or a single edit_file) "
                        "with the fresh text.\n"
                        f"--- current contents of {path} ---\n"
                        f"{file_preview}"
                    ),
                    error=True,
                    summary=f"edit #{i} no match — re-read and retry",
                )
            if count > 1 and not ra:
                return ToolResult(
                    output=f"edit #{i}: `old` matches {count} times; set replace_all=true",
                    error=True,
                    summary=f"edit #{i} ambiguous",
                )
            text = text.replace(old, new) if ra else text.replace(old, new, 1)
        if ctx.permission_mode not in ("acceptEdits", "skipAll"):
            preview = _unified_diff(original, text, path.name, max_lines=60)
            detail = f"apply {len(edits)} edits to {path}\n{preview}"
            ok = await ctx.request_approval("multi_edit", detail)
            if not ok:
                raise PermissionDenied(f"user denied multi_edit to {path}")
        ctx.snapshots.append({"kind": "multi_edit", "path": str(path), "before": original, "after": text})
        # Round 182: byte-faithful writeback via textio for non-UTF-8
        # / BOM-prefixed sources. Same logic as EditFile.
        if _text_info.encoding == "utf-8" and not _text_info.had_bom:
            _atomic_write_text(path, text)
        else:
            _atomic_write_bytes(path, encode_smart(text, _text_info))
        ctx.audit("multi_edit", {"path": str(path), "edits": len(edits)})
        verify = _verify_syntax_after_write(path, text)
        verify_line = f"\n{verify}" if verify else ""
        # Round-96.7b: descriptive summary, same shape as Edit/Write
        # so all the file-mutating receipts read consistently.
        return ToolResult(
            output=f"applied {len(edits)} edits to {path}{verify_line}",
            summary=(
                f"Applied {len(edits)} edit{'s' if len(edits) != 1 else ''}"
            ),
        )


class GlobFiles(Tool):
    name = "glob_files"
    description = "Find files matching a glob pattern (e.g. 'src/**/*.ts'). Returns matching paths."
    side_effect = SideEffect.READ
    # Round 173: schema accepts an optional `path` (search root)
    # to match Claude Code's Glob signature. Without this, models
    # trained against Claude Code who pass `path=src/` had it
    # silently dropped — they'd get matches from the entire
    # workdir instead of the requested subtree.
    schema = {
        "type": "object",
        "properties": {
            "pattern": {"type": "string"},
            "path": {
                "type": "string",
                "description": (
                    "Optional search root (workdir-relative). "
                    "Defaults to the workdir itself."
                ),
            },
            "limit": {"type": "integer", "default": 200},
        },
        "required": ["pattern"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        return f"Glob({args.get('pattern','?')})"

    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        pattern = str(args.get("pattern", ""))
        limit = max(1, min(2000, int(args.get("limit", 200))))
        if not pattern:
            return ToolResult(output="pattern required", error=True, summary="empty pattern")
        # Round 173: resolve the optional `path` root so the glob
        # walks the requested subtree, not the whole workdir.
        search_root = ctx.workdir
        sub = str(args.get("path") or "").strip()
        if sub:
            candidate = _resolve(ctx.workdir, sub)
            try:
                # Refuse traversal outside the workdir.
                candidate_resolved = candidate.resolve()
                workdir_resolved = ctx.workdir.resolve()
                if not str(candidate_resolved).startswith(str(workdir_resolved)):
                    return ToolResult(
                        output=f"path is outside workdir: {sub}",
                        error=True, summary="path escape",
                    )
                if candidate.is_dir():
                    search_root = candidate
                else:
                    return ToolResult(
                        output=f"path is not a directory: {sub}",
                        error=True, summary="not a dir",
                    )
            except (OSError, RuntimeError):
                pass
        gi = GitIgnore.for_workdir(ctx.workdir)
        # mtime-descending sort so recently-modified files come first —
        # matches Claude Code's Glob behavior. On iterative tasks the
        # model wants "files I just edited", not alphabetical noise.
        # Files we can't stat (race-deleted etc.) sort to the end.
        def _mtime_key(p: Path) -> float:
            try:
                return -p.lstat().st_mtime
            except OSError:
                return float("inf")
        # Round-16 P0: use lstat-based filtering and reject any match that
        # resolves outside the workdir. Path.glob() follows symlinks in
        # subdirs, so a symlinked node_modules → / would otherwise list
        # the entire host filesystem. We re-check each result's resolved
        # parent against the workdir root.
        try:
            workdir_resolved = ctx.workdir.resolve()
        except (OSError, RuntimeError):
            workdir_resolved = ctx.workdir
        def _safe(p: Path) -> bool:
            try:
                if p.is_symlink():
                    return False
                if not p.is_file():
                    return False
                resolved = p.resolve()
                return str(resolved).startswith(str(workdir_resolved))
            except (OSError, RuntimeError):
                return False
        all_matches = sorted(
            (p for p in search_root.glob(pattern) if _safe(p)),
            key=_mtime_key,
        )
        paths = gi.filter(all_matches)
        skipped = len(all_matches) - len(paths)
        total = len(paths)
        # Round 173: keep paths workdir-relative (not search-root-
        # relative) so the agent sees consistent paths regardless
        # of which subtree was searched. On Windows the workdir
        # may be the 8.3 short form (`ALIENW~1`) while the glob
        # expansion is the long form (`Alienware`); both resolve
        # to the same canonical path but `Path.relative_to` does
        # a strict string-prefix check. Resolve both before
        # comparing so the relative form stays clean.
        try:
            wd_canon = ctx.workdir.resolve()
        except (OSError, RuntimeError):
            wd_canon = ctx.workdir
        out = []
        for p in paths[:limit]:
            try:
                p_canon = p.resolve()
            except (OSError, RuntimeError):
                p_canon = p
            try:
                rel = str(p_canon.relative_to(wd_canon))
            except ValueError:
                try:
                    rel = os.path.relpath(str(p_canon), str(wd_canon))
                except ValueError:
                    rel = str(p_canon)
            out.append(rel)
        more = "" if total <= limit else f"\n…[{total - limit} more]"
        suffix = f" ({skipped} ignored)" if skipped else ""
        return ToolResult(
            output=("\n".join(out) if out else "(no matches)") + more,
            summary=f"{total} match{'es' if total != 1 else ''}{suffix}",
        )


class ListFiles(Tool):
    name = "list_files"
    description = "List files and subdirectories of a directory (non-recursive)."
    side_effect = SideEffect.READ
    schema = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "default": "."},
            "show_hidden": {"type": "boolean", "default": False},
        },
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        p = str(args.get("path", "."))
        if p in ("", "."):
            p = "."
        else:
            p = p.replace("\\", "/").rstrip("/").split("/")[-1] or p
        return f"List({p})"

    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        path = _resolve(ctx.workdir, str(args.get("path", ".")))
        show_hidden = bool(args.get("show_hidden", False))
        if not path.exists():
            return ToolResult(output=f"not found: {path}", error=True, summary="not found")
        if not path.is_dir():
            return ToolResult(output=f"not a directory: {path}", error=True, summary="not a dir")
        gi = GitIgnore.for_workdir(ctx.workdir)
        entries = []
        for p in sorted(path.iterdir()):
            if not show_hidden and p.name.startswith("."):
                continue
            if gi.is_ignored(p):
                continue
            kind = "dir" if p.is_dir() else "file"
            sz = p.stat().st_size if p.is_file() else ""
            entries.append(f"{kind:<4}  {p.name}{('  ' + str(sz)) if sz != '' else ''}")
        out = "\n".join(entries) if entries else "(empty)"
        return ToolResult(output=out, summary=f"{len(entries)} entr{'ies' if len(entries) != 1 else 'y'}")
