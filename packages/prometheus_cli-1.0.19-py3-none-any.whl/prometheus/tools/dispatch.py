"""1.0.4 — pre-dispatch tool-call argument validation.

Round 200's live `prometheus -p` gauntlet caught a real free-model
failure mode that the 3,258-test unit suite did not: the LLM
dispatched ``write_file({})`` with empty input. The tool itself
correctly errored, but the agent loop fed the error back into the
context and the model then *hallucinated* "File created." in its
final reply — a confident lie about a file that did not exist.

The fix is a pre-dispatch gate. Before any tool is awaited, we
check the call's args against the tool's declared
``schema["required"]``:

  * Missing or empty (``""`` / ``None`` / ``[]`` / ``{}``) values
    fail validation.
  * Aliases honoured — many tools accept ``path`` as a synonym
    for ``file_path`` (round-174 dual-schema). The validator
    knows the canonical alias pairs so a valid call via the
    alias is not rejected.
  * Failure produces a compact ``ToolResult`` with a clear
    "Tool call rejected: X requires Y (missing). Retry with the
    required argument." message — short enough to feed back into
    the model's next turn so it can correct itself.

This module is intentionally tiny and stdlib-only. The agent loop
calls ``validate_tool_call(tool, args)`` once before awaiting the
tool and short-circuits dispatch when validation fails.
"""
from __future__ import annotations

from typing import Any, Optional

from prometheus.tools.base import Tool, ToolResult


# Round-174 dual-schema: tools that accept either name for the
# same logical argument. If the canonical (left) name is missing
# but the alias (right) is present, the call is still valid.
# Direction is canonical → alias; the validator checks both.
_ARG_ALIASES: dict[str, tuple[str, ...]] = {
    "file_path": ("path",),
    "old_string": ("old",),
    "new_string": ("new",),
}


def _is_empty(value: Any) -> bool:
    """A value satisfies a required-arg slot only if it's
    *meaningfully* present.

    Empty strings, ``None``, empty lists/dicts/tuples are treated
    as missing — the LLM emitted them but they convey no signal.
    Numeric ``0`` and boolean ``False`` are NOT empty (they are
    valid intentional arguments)."""
    if value is None:
        return True
    if isinstance(value, str) and value.strip() == "":
        return True
    if isinstance(value, (list, dict, tuple, set)) and len(value) == 0:
        return True
    return False


def _alias_satisfies(args: dict[str, Any], canonical: str) -> bool:
    """Return True iff `args` contains a non-empty value under
    any alias for `canonical`."""
    for alt in _ARG_ALIASES.get(canonical, ()):
        if alt in args and not _is_empty(args[alt]):
            return True
    return False


def validate_tool_call(
    tool: Tool, args: dict[str, Any],
) -> Optional[ToolResult]:
    """Validate ``args`` against ``tool.schema["required"]``.

    Returns ``None`` when the call is well-formed (dispatch may
    proceed). Returns a ``ToolResult`` with ``error=True`` and a
    short, model-readable error message when one or more required
    fields are missing or empty.

    Tools with no schema, or no ``required`` list, pass through
    unchanged — validation only fires when the tool itself has
    declared what it needs.
    """
    schema = getattr(tool, "schema", None)
    if not isinstance(schema, dict):
        return None
    required = schema.get("required") or []
    if not isinstance(required, (list, tuple)):
        return None
    if not isinstance(args, dict):
        return ToolResult(
            output=(
                f"Tool call rejected: {tool.name} requires a JSON "
                f"object of arguments, got {type(args).__name__}. "
                f"Retry with the documented arguments."
            ),
            error=True,
            summary=f"{tool.name} bad-args",
        )
    missing: list[str] = []
    for key in required:
        if key in args and not _is_empty(args[key]):
            continue
        # Honour alias for this canonical key.
        if _alias_satisfies(args, key):
            continue
        missing.append(key)
    if not missing:
        return None
    # Build a model-readable message. Keep it short — the LLM
    # sees this in the tool_result and decides how to retry.
    if len(missing) == 1:
        detail = f"requires `{missing[0]}` (missing)"
    else:
        joined = ", ".join(f"`{m}`" for m in missing)
        detail = f"requires {joined} (missing)"
    return ToolResult(
        output=(
            f"Tool call rejected: {tool.name} {detail}. "
            f"Retry with the required argument(s)."
        ),
        error=True,
        summary=f"{tool.name} arg-validation",
    )
