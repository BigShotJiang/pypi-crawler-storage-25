"""todo_write: a ●/◼/○ task tracker the model uses to plan multi-step work.

The list lives on ToolContext.todos and is rendered in the UI as a small
panel above the chat once 3+ items exist. Replacing the list each call is
intentional — model gets one shot per call to express the plan.

v2 features (round-10):
  - per-item `id` (stable across updates so the model can reference it)
  - per-item `blocked_by`: list of ids that must be `completed` before
    this item can flip to `in_progress`. Matches Anthropic's January 2026
    Tasks redesign — actually changes plan-execution behavior, not just
    display.
  - file-based persistence at `.prometheus/tasks/<session_id>.json` so
    /resume sees the prior plan instead of starting blank. Best-effort:
    a write failure logs and is swallowed — the in-memory list remains
    authoritative.
"""
from __future__ import annotations

import json
import re
from typing import Any

from prometheus.tools.base import SideEffect, Tool, ToolContext, ToolResult

VALID_STATUSES = {"pending", "in_progress", "completed"}
GLYPH = {"completed": "●", "in_progress": "◼", "pending": "○"}
_ID_RX = re.compile(r"^[A-Za-z0-9_.-]{1,40}$")


def _persist(ctx: ToolContext, todos: list[dict[str, Any]]) -> None:
    """Write the current task list to .prometheus/tasks/<session>.json.
    Failure is best-effort — never bubbles up. Round-11 audit P0:
    if `.prometheus` exists as a regular FILE (not a dir), mkdir
    raises FileExistsError; we now check before calling mkdir so the
    persistence is silently skipped instead of crashing."""
    try:
        prometheus_dir = ctx.workdir / ".prometheus"
        # Bail if the parent slot is occupied by a regular file.
        if prometheus_dir.exists() and not prometheus_dir.is_dir():
            return
        target_dir = prometheus_dir / "tasks"
        if target_dir.exists() and not target_dir.is_dir():
            return
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / f"{ctx.session_id}.json"
        tmp = target.with_suffix(".tmp")
        tmp.write_text(json.dumps({"todos": todos}, indent=2), encoding="utf-8")
        tmp.replace(target)
    except Exception:
        pass


def load_persisted_todos(workdir, session_id: str) -> list[dict[str, Any]]:
    """Read the persisted task list for `session_id`. Returns [] on any
    failure or absence — callers don't need to care about the cause."""
    try:
        target = workdir / ".prometheus" / "tasks" / f"{session_id}.json"
        if not target.exists():
            return []
        data = json.loads(target.read_text(encoding="utf-8"))
        todos = data.get("todos")
        return todos if isinstance(todos, list) else []
    except Exception:
        return []


class TodoWrite(Tool):
    name = "todo_write"
    description = (
        "Write or replace the session task list. Use for multi-step work "
        "(3+ steps). Each item: id (optional stable id), subject (short "
        "imperative), status (pending|in_progress|completed), and "
        "blocked_by (list of ids that must be completed first). Mark items "
        "in_progress as you start them and completed as soon as you finish "
        "— never batch updates. The list persists across /resume."
    )
    side_effect = SideEffect.WRITE
    # Round 174: dual-schema. Claude Code's TodoWrite uses
    # `content` (the imperative task title) and `activeForm`
    # (the present-continuous label shown while in-progress,
    # e.g. "Running tests"). Prometheus's native field name is
    # `subject`. Without dual-naming, every TodoWrite call from a
    # CC-trained model dropped the title and surfaced empty rows.
    # We accept both and only require ONE of them.
    schema = {
        "type": "object",
        "properties": {
            "todos": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {
                            "type": "string",
                            "description": "stable id (alphanumerics + _.-, ≤40 chars)",
                        },
                        "content": {
                            "type": "string",
                            "description": "task title in imperative form (preferred Claude Code name)",
                        },
                        "subject": {
                            "type": "string",
                            "description": "alias for content",
                        },
                        "activeForm": {
                            "type": "string",
                            "description": (
                                "present-continuous label shown while "
                                "this todo is in_progress (e.g. \"Running tests\")"
                            ),
                        },
                        "status": {
                            "type": "string",
                            "enum": ["pending", "in_progress", "completed"],
                        },
                        "blocked_by": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": (
                                "ids of items that must be `completed` "
                                "before this one can become `in_progress`"
                            ),
                        },
                    },
                    "required": ["content", "status"],
                },
            },
        },
        "required": ["todos"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        n = len(args.get("todos") or [])
        return f"TodoWrite({n} step{'s' if n != 1 else ''})"

    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        todos = args.get("todos") or []
        if not isinstance(todos, list):
            return ToolResult(output="`todos` must be an array", error=True, summary="TodoWrite")
        cleaned: list[dict[str, Any]] = []
        used_ids: set[str] = set()
        for idx, t in enumerate(todos):
            # Round 174: accept both `content` (Claude Code) and
            # `subject` (Prometheus native). `content` wins when
            # both are present.
            sub = str(t.get("content") or t.get("subject") or "").strip()
            active_form = str(t.get("activeForm") or "").strip()
            status = str(t.get("status", "pending"))
            if status not in VALID_STATUSES:
                status = "pending"
            if not sub:
                continue
            tid = str(t.get("id", "")).strip() or f"t{idx + 1}"
            if not _ID_RX.match(tid):
                tid = f"t{idx + 1}"
            # Avoid collisions — fall through to incrementing suffix.
            base = tid
            i = 2
            while tid in used_ids:
                tid = f"{base}_{i}"
                i += 1
            used_ids.add(tid)
            blocked_by_raw = t.get("blocked_by") or []
            blocked_by = [str(b) for b in blocked_by_raw if isinstance(b, str)]
            cleaned.append({
                "id": tid,
                "subject": sub,
                "status": status,
                "blocked_by": blocked_by,
                # Round 174: keep activeForm so the spinner / receipt
                # can show the present-continuous label while this
                # item is in_progress. Stored as empty string when not
                # supplied so consumers don't have to guard for None.
                "activeForm": active_form,
            })
        # Round-11 audit P0: enforce at-most-1 BEFORE blocked_by
        # validation. If the model submits 3 in_progress items, we
        # keep the first and demote the rest; THEN we check that the
        # surviving in_progress item has met its deps. The previous
        # order produced a subtle inconsistency where blocked items
        # got reverted first, then a different item was demoted by
        # the at-most-1 rule.
        warnings: list[str] = []
        seen_in_progress = False
        for t in cleaned:
            if t["status"] == "in_progress":
                if seen_in_progress:
                    t["status"] = "pending"
                    warnings.append(
                        f"  ⚠︎ '{t['subject'][:40]}' demoted to pending — "
                        f"only one task can be in_progress at a time"
                    )
                else:
                    seen_in_progress = True
        # NOW validate blocked_by — if the surviving in_progress item
        # has un-completed deps, flip it to pending too.
        status_by_id = {t["id"]: t["status"] for t in cleaned}
        for t in cleaned:
            unmet = [b for b in t["blocked_by"]
                     if b in status_by_id and status_by_id[b] != "completed"]
            if unmet and t["status"] == "in_progress":
                t["status"] = "pending"
                warnings.append(f"  ⚠︎ '{t['subject'][:40]}' has unmet deps {unmet}; reverted to pending")
        ctx.todos.clear()
        ctx.todos.extend(cleaned)
        ctx.audit("todo_write", {"count": len(cleaned)})
        _persist(ctx, cleaned)
        # Model-facing render — show id when blocked_by is non-empty so
        # the model can reference items in the next call.
        rendered_lines: list[str] = []
        for t in cleaned:
            line = f"  {GLYPH[t['status']]} {t['subject']}"
            if t["blocked_by"]:
                line += f"  (blocked by: {', '.join(t['blocked_by'])})"
            elif any(t["id"] in other["blocked_by"] for other in cleaned):
                line += f"  [id: {t['id']}]"
            rendered_lines.append(line)
        rendered = "\n".join(rendered_lines)
        out = f"updated task list ({len(cleaned)} items):\n{rendered}" if cleaned else "task list cleared"
        if warnings:
            out += "\n" + "\n".join(warnings)
        in_prog = sum(1 for t in cleaned if t["status"] == "in_progress")
        done = sum(1 for t in cleaned if t["status"] == "completed")
        return ToolResult(
            output=out,
            summary=f"{done}/{len(cleaned)} done" + (f" · {in_prog} active" if in_prog else ""),
            metadata={"todos": cleaned},
        )
