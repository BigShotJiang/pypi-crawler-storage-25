import mss
import math
import numpy as np
from scipy import ndimage
from scipy.signal import fftconvolve

from ..utils import RectTuple, DataHeader


class Match:
    """
    图像与颜色匹配类
    """
    def __init__(self):
        self.sct = mss.mss()
        self.data_header = DataHeader()
        self.max_distance = math.sqrt(255**2 * 3)  # RGB 空间最大距离 ≈ 441.67

    def clear_cache_images(self) -> None:
        """
            清空缓存图像
        """
        self.data_header.clear_cache_images()

    def load_image(self, image_path: str) -> np.ndarray:
        """
            加载图像
        Args:
            image_path (str): 图像文件路径
        Returns:
            np.ndarray: 图像的 numpy 数组表示
        """
        return self.data_header.load_image(image_path)

    def save_image(self, image: np.ndarray, image_path: str) -> None:
        """
            保存图像
        Args:
            image (np.ndarray): 图像的 numpy 数组表示
            image_path (str): 图像文件路径
        """
        return self.data_header.save_image(image, image_path)

    def screenshot(self, rect: tuple[int, int, int, int], save_path: str=None) -> np.ndarray:
        """
            截图
        Args:
            rect (tuple): 矩形区域元组，应包含 (x1, y1, x2, y2)。
            save_path (str): 截图保存路径，包含自定义文件名。
        Returns:
            np.ndarray: 截图图像的 numpy 数组表示。
        """
        rect = RectTuple(*rect)
        screen_image = self.sct.grab(rect)
        # 转换为 numpy 数组，MSS 返回 BGRA 格式需要转换
        screen_image = self.data_header.image_to_numpy(screen_image, to_rgb=True)

        if save_path is not None:
            self.data_header.save_image(screen_image, save_path)

        return screen_image

    def get_pixel_color(self, x: int, y: int, is_return_hex: bool = False) -> str | tuple:
        """
            获取屏幕坐标 (x, y) 处的颜色
        Args:
            x (int): 屏幕坐标 x 轴
            y (int): 屏幕坐标 y 轴
            is_return_hex (bool, optional): 是否返回十六进制格式字符串，默认返回 RGB 元组
        Returns:
            str | tuple: 十六进制格式字符串，如 #FFAABB 或 (r, g, b) 元组
        """
        pixel = tuple(int(c) for c in self.screenshot((x, y, x+1, y+1))[0, 0])

        if is_return_hex:   # 返回十六进制字符串
            return f"#{pixel[0]:02X}{pixel[1]:02X}{pixel[2]:02X}"
        return pixel    # 返回 RGB 元组

    def match_color(self, source_color: str | tuple, target_color: str | tuple, similarity: float = 0.8) -> tuple:
        """
            匹配颜色
        Args:
            source_color (str | tuple): 源颜色 (str: 颜色十六进制字符串， tuple: (r, g, b) | (x, y))
            target_color (str | tuple): 目标颜色 (str: 颜色十六进制字符串， tuple: (r, g, b) | (x, y))
            similarity (float): 相似度阈值，取值范围 0.0 ~ 1.0，越接近 1 越严格。默认值为 0.8。
        Returns:
            tuple: bool(True | False), float(相似度结果值)
        """
        if type(source_color) is str:
            source_color = self.data_header.hex_to_rgb(source_color)
        elif type(source_color) is tuple and len(source_color) == 2:
            source_color = self.get_pixel_color(*source_color, is_return_hex=False)

        if type(target_color) is str:
            target_color = self.data_header.hex_to_rgb(target_color)
        elif type(target_color) is tuple and len(target_color) == 2:
            target_color = self.get_pixel_color(*target_color, is_return_hex=False)

        # 计算欧几里得距离
        distance = math.sqrt(sum((a - b) ** 2 for a, b in zip(source_color, target_color)))
        score = 1 - (distance / self.max_distance)
        return score >= similarity, round(score, 3)

    def match_image(self, target_image: np.ndarray=None, rect: tuple[int, int, int, int]=None,
                    similarity: float=0.8) -> tuple[tuple, float]:
        """
            匹配图像
        Args:
            target_image (np.ndarray): 目标图像
            rect (tuple): 矩形区域元组，应包含 (x1, y1, x2, y2)
            similarity (float): 相似度阈值，默认 0.8。
        Returns:
            tuple[tuple[int, int], float]: 匹配结果元组，包含匹配位置和相似度。
        """
        # 检查参数
        if target_image is None or rect is None:
            raise ValueError("必须提供 target_image 和 rect 参数")

        # 截取屏幕区域
        rect = RectTuple(*rect)
        source_image = self.screenshot(rect)

        # 转换为 float32 精度
        source_image = np.array(source_image, dtype=np.float32)
        target_image = np.array(target_image, dtype=np.float32)

        # 调用匹配方法
        (x, y), sim = self._match_ncc(source_image, target_image, similarity)

        # 调整坐标以对应屏幕坐标
        if x is not False and y is not False:
            x, y = x + rect.x1, y + rect.y1
            return (int(x), int(y)), sim
        else:
            return (False, False), sim

    def _match_ncc(self, source_image: np.ndarray, target_image: np.ndarray,
                   similarity: float = 0.8) -> tuple[tuple, float]:
        """
        简介:
            使用 FFT 加速的归一化互相关(NCC)方法匹配图像 (灰度)，并使用边缘检测进行二次验证。

        性能参考:
            性能为 0.006秒 ~ 0.2秒 ~ 0.6秒 之间，取决于图像大小。
            0.006秒 = source_image: 300x300, target_image: 100x100
            0.2  秒 = source_image: 2560x1440, target_image: 100x100
            0.6  秒 = source_image: 2560x1440, target_image: 2460x1340
        """

        # 转灰度
        s_channel = self.data_header.rgb_to_gray(source_image)
        t_channel = self.data_header.rgb_to_gray(target_image)

        # 模板能量
        t_norm = np.linalg.norm(t_channel)
        if t_norm == 0:
            return False, 0.0

        # 计算分子：互相关 (FFT 卷积)
        numerator = fftconvolve(s_channel, np.flipud(np.fliplr(t_channel)), mode='valid')

        # 计算分母：局部能量 × 模板能量
        s_squared = fftconvolve(s_channel**2, np.ones_like(t_channel), mode='valid')
        denominator = np.sqrt(s_squared) * t_norm

        denominator[denominator == 0] = 1e-8  # 避免除零

        ncc = numerator / denominator

        # 找到最佳匹配位置
        max_sim = np.max(ncc)
        if max_sim >= similarity:
            # 左上角坐标
            y, x = np.unravel_index(np.argmax(ncc), ncc.shape)
            h, w = target_image.shape[:2]

            # 确保提取区域在源图像范围内
            if y + h <= source_image.shape[0] and x + w <= source_image.shape[1]:
                # 提取匹配区域
                matched_region = source_image[y:y+h, x:x+w]

                # 边缘检测二次验证
                target_edges = self._edge_detection(target_image)
                matched_edges = self._edge_detection(matched_region)

                # 计算边缘相似度
                edge_numerator = np.sum(target_edges * matched_edges)
                edge_denominator = np.sqrt(np.sum(target_edges**2) * np.sum(matched_edges**2))
                edge_denominator = max(edge_denominator, 1e-8)  # 避免除零
                edge_sim = edge_numerator / edge_denominator

                # 只有当边缘相似度也达到阈值时，才认为匹配成功
                if edge_sim >= similarity:
                    # 中心坐标
                    center_x = x + w // 2
                    center_y = y + h // 2
                    return (int(center_x), int(center_y)), round(float(max_sim), 3)

        return (False, False), round(float(max_sim), 3)

    def _edge_detection(self, image: np.ndarray) -> np.ndarray:
        """
        使用 Sobel 算子进行边缘检测
        """
        # 转灰度
        if len(image.shape) == 3:
            gray = self.data_header.rgb_to_gray(image)
        else:
            gray = image

        # Sobel 边缘检测
        sobel_x = ndimage.sobel(gray, axis=0, mode='constant')
        sobel_y = ndimage.sobel(gray, axis=1, mode='constant')
        edges = np.sqrt(sobel_x**2 + sobel_y**2)

        # 归一化
        edges = edges / (np.max(edges) + 1e-8)
        return edges
