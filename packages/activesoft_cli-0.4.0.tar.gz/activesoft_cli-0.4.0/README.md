# Activesoft Siga CLI

A Python SDK and CLI tool for automating interactions with the Activesoft Siga API. This tool simplifies retrieval of student data (including enrollment and presence permissions), responsible party data, class lists, and sending messages.

## Installation

Install via pip:

```bash
pip install activesoft-cli
```

Or from source:

```bash
git clone https://github.com/tsuriu/activesoft-cli.git
cd activesoft-cli
pip install .
```

## CLI Usage

The package includes a command-line interface `activesoft-cli`.

### Configuration

You can provide credentials via flags or environment variables:

- `--username` / `SIGA_USERNAME`
- `--password` / `SIGA_PASSWORD`
- `--instituicao` / `SIGA_INSTITUICAO`

The CLI automatically saves your session (cookies) to a local JSON file:
`~/.activesoft_siga_<instituicao>_<username>.json`

Subsequent commands will reuse this session, avoiding full re-authentication. If the session expires, the CLI will automatically attempt to re-login.

You can also specify a custom session path when using the SDK:
```python
client = SigaClient(..., session_path="/path/to/session.json")
```

### Commands

#### Student Management (`students`)

Lists students or retrieves complete profile details for a specific student, including associated classes (turmas) and presence management/exit permissions.

```bash
# List students (defaults to 10)
activesoft-cli students --limit 20

# Fetch complete profile for a specific student ID
# Returns a merged JSON with student data, enrollment (turmas), and presence permissions
activesoft-cli students --id 4907
```

#### Class Management (`turmas`)

Lists available classes/groups.

```bash
# List classes (defaults to 10)
activesoft-cli turmas --limit 5 --periodo 14
```

#### Responsible Parties (`responsaveis`)

Lists responsible parties or retrieves specific details.

```bash
# List responsible parties (defaults to 21)
activesoft-cli responsaveis --limit 10

# Fetch details for a specific responsible party ID
activesoft-cli responsaveis --id 10188
```

#### Messaging (`send-message`)

Sends a message through the Siga system.

```bash
activesoft-cli send-message \
  --student-id 4907 \
  --destinatario-id 13578 \
  --message "Your message here" \
  --title "Aviso"
```

#### Avatar/Photo Management (`upload-avatar`)

Uploads a new photo/avatar for a specific student.

```bash
activesoft-cli upload-avatar \
  --student-id 4907 \
  --image-path "./photos/4907.jpg"
```

#### Bulk Photo Retrieval (`bulk-fotos`)

Retrieves photo URLs (S3 links) for multiple students at once.

```bash
# Using a comma-separated list
activesoft-cli bulk-fotos --ids "104,106,107,111"

# Or using multiple ID flags
activesoft-cli bulk-fotos --id 104 --id 106 --id 107
```

## SDK Usage

You can use the `SigaClient` directly in your Python applications.

### Initialization

```python
import asyncio
import json
from activesoft_cli import SigaClient

async def main():
    # Initialize and login
    client = SigaClient(
        username="your-username", 
        password="your-password", 
        instituicao="YOUR_INSTITUTION"
    )

    async with client: # Closes session automatically
        if await client.login():
            # Get complete student profile
            aluno_detail = await client.get_aluno_detail(4907)
            aluno_info = aluno_detail.get('aluno', {})
            
            # Fetch and merge enrollment/turmas
            aluno_info['turmas'] = await client.get_aluno_turmas(4907)
            
            # Fetch and merge presence permissions
            aluno_info['gestao_presenca'] = aluno_detail.get('gestao_presenca', {})
            
            print(json.dumps(aluno_info, indent=2))

if __name__ == "__main__":
    asyncio.run(main())
```

## Requirements

- Python 3.8+
- `httpx`
- `loguru`
- `click`

## License

This project is licensed under the MIT License.
