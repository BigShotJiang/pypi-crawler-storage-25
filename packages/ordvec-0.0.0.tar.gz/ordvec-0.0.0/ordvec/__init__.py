"""ordvec — name reservation.

Training-free ordinal & sign vector quantization for compressed
nearest-neighbour retrieval. The first functional release lands alongside
the OrdVec / RankQuant paper.

Source & docs: https://github.com/Fieldnote-Echo/ordvec
"""

__version__ = "0.0.0"
