# ordvec (name reservation)

Training-free ordinal & sign vector quantization for compressed
nearest-neighbour retrieval.

This `0.0.0` release reserves the PyPI name. The first functional release
lands alongside the **OrdVec / RankQuant** paper.

Source &amp; docs: <https://github.com/Fieldnote-Echo/ordvec>
