"""cosmo-ent: Cosmopolitan builds of ent(1) as a Python package.

This package provides the ent(1) random sequence tester built with Cosmopolitan libc,
allowing entropy analysis and randomness testing across multiple platforms from a single
universal binary.

Example:
    >>> import cosmo_ent
    >>> result = cosmo_ent.run('random_data.bin')
    >>> print(result.stdout.decode())
    Entropy = 7.998814 bits per byte.
    ...

    >>> # Or use from command line:
    $ cosmo-ent random_data.bin
    Entropy = 7.998814 bits per byte.
"""

import asyncio
import platform
import subprocess
from pathlib import Path
from typing import Union, Optional

from ._version import __version__

__all__ = ["run", "run_async"]


def get_binary_path() -> Path:
    """Get the path to the ent.com binary.

    Returns:
        Path object pointing to the ent.com binary.

    Raises:
        FileNotFoundError: If the binary cannot be found.
    """
    binary_path = Path(__file__).parent / "data" / ("ent.com" if platform.system() != "Linux" else "ent.elf")
    if binary_path.exists():
        return binary_path
    raise FileNotFoundError(
        f"ent.com binary not found at {binary_path}. "
        "The package may not be properly installed."
    )


def get_pledge_path() -> Path:
    """Get the path to the pledge binary.

    Returns:
        Path object pointing to the pledge binary.

    Raises:
        FileNotFoundError: If the pledge binary cannot be found.
    """
    if platform.system() != "Linux":
        raise FileNotFoundError("pledge binary is only available on Linux systems.")

    pledge_path = Path(__file__).parent / "data" / "pledge"
    if pledge_path.exists():
        return pledge_path
    raise FileNotFoundError(
        f"pledge binary not found at {pledge_path}. "
        "The package may not be properly installed."
    )


def get_base_command(pledge: bool = True) -> list[str]:
    """Get the base command to execute the ent binary.

    Args:
        pledge: If True (default), use pledge sandboxing on Linux. Has no effect on other platforms.

    Returns:
        List of command components to execute the binary.
    """
    binary = get_binary_path()
    if platform.system() == "Windows":
        return [str(binary)]
    else:
        if platform.system() == "Linux":
            if pledge:
                pledge_binary = get_pledge_path()
                return [
                    "sh",
                    str(pledge_binary), "-V", "-p", "stdio rpath",
                    str(binary),
                ]
            else:
                return [str(binary)]
        return ["sh", str(binary)]


def run(
    *args: Union[str, Path],
    stdin: Optional[Union[str, bytes]] = None,
    capture_output: bool = True,
    check: bool = False,
    pledge: bool = True,
    **kwargs
) -> subprocess.CompletedProcess:
    """Run the ent command with the given arguments.

    Args:
        *args: Arguments to pass to the ent command (e.g., file paths, options).
        stdin: Optional input to pass to stdin (str or bytes).
        capture_output: If True, capture stdout and stderr. If False, they go to
                       the parent process streams.
        check: If True, raise CalledProcessError if the command returns non-zero.
        pledge: If True (default), use pledge sandboxing on Linux. Has no effect on other platforms.
        **kwargs: Additional keyword arguments to pass to subprocess.run().

    Returns:
        CompletedProcess instance with returncode, stdout, stderr attributes.

    Raises:
        FileNotFoundError: If the ent.com binary cannot be found.
        subprocess.CalledProcessError: If check=True and command fails.

    Example:
        >>> result = cosmo_ent.run('random.bin')
        >>> print(result.stdout.decode())

        >>> result = cosmo_ent.run('-t', 'data.bin')  # csv output
        >>> print(result.stdout.decode())

        >>> result = cosmo_ent.run('--', stdin=b'\\x00\\x01\\x02\\x03')
        >>> print(result.stdout.decode())
    """
    # Convert all args to strings
    cmd = get_base_command(pledge=pledge) + [str(arg) for arg in args]

    # Handle stdin
    stdin_input = None
    if stdin is not None:
        if isinstance(stdin, str):
            stdin_input = stdin.encode()
        else:
            stdin_input = stdin

    # Run the command
    return subprocess.run(
        cmd,
        input=stdin_input,
        capture_output=capture_output,
        check=check,
        **kwargs
    )


async def run_async(
    *args: Union[str, Path],
    stdin: Optional[Union[str, bytes]] = None,
    capture_output: bool = True,
    check: bool = False,
    pledge: bool = True,
    **kwargs
) -> subprocess.CompletedProcess:
    """Async version of run(). Run the ent command with the given arguments.

    Args:
        *args: Arguments to pass to the ent command (e.g., file paths, options).
        stdin: Optional input to pass to stdin (str or bytes).
        capture_output: If True, capture stdout and stderr. If False, they go to
                       the parent process streams.
        check: If True, raise CalledProcessError if the command returns non-zero.
        pledge: If True (default), use pledge sandboxing on Linux. Has no effect on other platforms.
        **kwargs: Additional keyword arguments to pass to asyncio.create_subprocess_exec().

    Returns:
        CompletedProcess instance with returncode, stdout, stderr attributes.

    Raises:
        FileNotFoundError: If the ent.com binary cannot be found.
        subprocess.CalledProcessError: If check=True and command fails.
    """
    cmd = get_base_command(pledge=pledge) + [str(arg) for arg in args]

    stdin_input = None
    if stdin is not None:
        if isinstance(stdin, str):
            stdin_input = stdin.encode()
        else:
            stdin_input = stdin

    stdout = asyncio.subprocess.PIPE if capture_output else None
    stderr = asyncio.subprocess.PIPE if capture_output else None

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdin=asyncio.subprocess.PIPE if stdin_input is not None else None,
        stdout=stdout,
        stderr=stderr,
        **kwargs
    )
    out, err = await proc.communicate(stdin_input)

    completed = subprocess.CompletedProcess(cmd, proc.returncode, out, err)
    if check:
        completed.check_returncode()
    return completed
