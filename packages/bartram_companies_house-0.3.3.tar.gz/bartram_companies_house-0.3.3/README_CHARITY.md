# UK Charity Commission MCP Server

Clean, structured charity register data for AI agents — via the [Model Context Protocol](https://modelcontextprotocol.io/).

<!-- mcp-name: io.github.RobertAlsop/charity-commission -->

## What this does

This MCP server gives agents access to 31 Charity Commission for England and Wales endpoints — search, details, profiles, trustees, classifications, areas of operation, financials, governance, regulatory reports, and sector statistics — with data cleaning that the raw API doesn't provide.

Charity Commission data has known quality issues: status codes are opaque single characters (`R`, `RM`), dates arrive in mixed formats (DD/MM/YYYY, datetime strings), trustee names have inconsistent casing, addresses lack normalisation, financial data has no trend analysis, and classification codes need grouping into What/Who/How categories. This server fixes those problems before the data reaches your agent.

**What the cleaning layer does:**

- **Status code mapping** — opaque codes (`R`, `RM`) mapped to human-readable labels (`Registered`, `Removed`) with removal reason decoding.
- **Date normalisation** — DD/MM/YYYY, DD/MM/YYYY HH:MM, and other formats converted to ISO 8601 across every endpoint.
- **Name normalisation** — trustee names and charity names cleaned using shared UK name utilities.
- **Address normalisation** — consistent formatting with postcode standardisation using shared UK address utilities.
- **Classification grouping** — flat classification lists grouped into structured What (100-series), Who (200-series), How (300-series) categories.
- **Financial trend calculation** — year-on-year income trends computed with percentage change, handling zero-income edge cases.
- **Government funding flagging** — charities receiving government funding automatically flagged.
- **Text cleaning** — collapsed whitespace, trimmed strings, null/empty field guarding.
- **URL normalisation** — website URLs validated and normalised.
- **Charity number normalisation** — agents can send `"  00123456  "` or `"123456"` and the server normalises to `123456`.
- **Field name aliasing** — handles both spec and live API field names transparently via `_get_first()` pattern.
- **Batch lookup tracking** — tracks which charity numbers were found and which were not.
- **Data quality annotations** — every cleaned record carries `_cleaning` metadata so agents can see what was changed and why.

## Quick start

```bash
# Install
pip install bartram-companies-house

# Set your API key (required)
export CHARITY_COMMISSION_API_KEY="your-subscription-key"

# Run the MCP server
bartram-charity
```

Or with [uvx](https://docs.astral.sh/uv/):

```bash
uvx bartram-charity
```

Register for a free API subscription key at the [Charity Commission API Portal](https://api-portal.charitycommission.gov.uk/).

### Configure with Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "charity-commission": {
      "command": "uvx",
      "args": ["bartram-charity"],
      "env": {
        "CHARITY_COMMISSION_API_KEY": "your-subscription-key"
      }
    }
  }
}
```

## Tools

| Tool | Description |
|------|-------------|
| `uk_charity_search` | Search charities by name |
| `uk_charity_lookup` | Look up a charity by registered number |
| `uk_charity_search_by_registration_date` | Find charities registered within a date range |
| `uk_charity_search_by_removal_date` | Find charities removed within a date range |
| `uk_charity_profile` | Comprehensive charity details (V2) — trustees, classifications, areas, financials |
| `uk_charity_details` | Core charity details (lightweight) |
| `uk_charity_batch_lookup` | Batch fetch multiple charities (max 20) |
| `uk_charity_trustees` | Detailed trustee information with appointment dates |
| `uk_charity_trustee_names` | Lightweight trustee name list |
| `uk_charity_classifications` | What/Who/How classification details |
| `uk_charity_areas_of_operation` | Geographic areas — countries, regions, local authorities |
| `uk_charity_contact` | Contact details — address, phone, email, website |
| `uk_charity_constituency` | Parliamentary constituency |
| `uk_charity_policies` | Governance policies |
| `uk_charity_other_regulators` | Other regulatory bodies overseeing the charity |
| `uk_charity_primary_grants` | Grant-making status |
| `uk_charity_financial_history` | 5-year financial history with trends |
| `uk_charity_annual_return` | Most recent Annual Return overview |
| `uk_charity_accounts` | Accounts and AR submission history |
| `uk_charity_assets` | Assets and liabilities balance sheet |
| `uk_charity_governing_document` | Governing document and charitable objects |
| `uk_charity_governance` | Governance summary — type, Companies House link, gift aid, land |
| `uk_charity_linked_charities` | Linked/subsidiary charities |
| `uk_charity_other_names` | Working and historical names |
| `uk_charity_registration_history` | Registration event history |
| `uk_charity_regulatory_reports` | Published regulatory reports |
| `uk_charity_cio_dissolution` | CIO dissolution notice |
| `uk_charity_sector_overview` | Overall charity sector statistics |
| `uk_charity_sector_top10` | Top 10 charities by metric |
| `uk_charity_sector_income_bands` | Sector data by income band |
| `uk_charity_sector_income_categories` | Sector data by income category |

See [SCHEMA_CHARITY.md](SCHEMA_CHARITY.md) for full parameter and response documentation.

## Example

Ask your agent: *"Tell me about the British Red Cross — who are their trustees and what's their financial trend?"*

The agent calls `uk_charity_search` with `query: "British Red Cross"`, gets charity number `220949`, then calls `uk_charity_trustees` and `uk_charity_financial_history`:

```json
{
  "data": {
    "years": [
      {
        "financial_year_end": "2023-12-31",
        "total_income": 259000000,
        "total_expenditure": 271000000,
        "income_trend_pct": -3.7,
        "government_funded": true
      }
    ],
    "financials_structured": true,
    "_cleaning": {
      "dates_normalised": true,
      "trends_calculated": true,
      "government_funding_flagged": true
    }
  },
  "metadata": {
    "source": "Charity Commission for England and Wales",
    "licence": "Open Government Licence v3",
    "endpoint": "charityfinancialhistory/220949/0",
    "cached": false,
    "attribution": "Contains public sector information licensed under the Open Government Licence v3.0. Source: Charity Commission for England and Wales."
  }
}
```

Every response includes a `metadata` envelope with source attribution, licence information, and retrieval timestamp.

## Data source

All data comes from the [Charity Commission for England and Wales API](https://api-portal.charitycommission.gov.uk/). Published as public sector information under the Open Government Licence v3.0.

## Caching

Responses are cached locally in SQLite to reduce API calls and stay within rate limits (30 requests per 10 seconds):

| Endpoint | TTL |
|----------|-----|
| Search | 5 minutes |
| Search by registration date | 5 minutes |
| Search by removal date | 5 minutes |
| Lookup | 1 hour |
| Profile | 1 hour |
| Details | 1 hour |
| Batch lookup | 1 hour |
| Trustees | 30 minutes |
| Trustee names | 30 minutes |
| Classifications | 1 hour |
| Areas of operation | 1 hour |
| Contact | 1 hour |
| Constituency | 1 hour |
| Policies | 1 hour |
| Other regulators | 1 hour |
| Primary grants | 1 hour |
| Financial history | 30 minutes |
| Annual return | 30 minutes |
| Accounts | 30 minutes |
| Assets | 30 minutes |
| Governing document | 1 hour |
| Governance | 1 hour |
| Linked charities | 1 hour |
| Other names | 1 hour |
| Registration history | 1 hour |
| Regulatory reports | 30 minutes |
| CIO dissolution | 1 hour |
| Sector overview | 1 hour |
| Sector top 10 | 30 minutes |
| Sector income bands | 1 hour |
| Sector income categories | 1 hour |

Cache is stored in `monitoring.db` by default. Set `BARTRAM_DATA_DIR` to change the location.

## Development

```bash
git clone https://github.com/RobertAlsop/bartram_foundry.git
cd bartram_foundry
uv sync --all-extras
uv run pytest bartram_charity/tests/
uv run ruff check bartram_charity/
```

## Licence

MIT

---

Built by [Bartram Foundry](https://github.com/RobertAlsop/bartram_foundry) — production-grade MCP tools for UK public data.
