"""Tests for bartram_foundry.http — retry logic with exponential backoff."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import httpx
import pytest

from bartram_foundry.http import (
    is_retryable_error,
    is_retryable_status,
    retry_request,
)


class TestIsRetryableError:
    def test_timeout_is_retryable(self) -> None:
        assert is_retryable_error(httpx.TimeoutException("timeout"))

    def test_network_error_is_retryable(self) -> None:
        assert is_retryable_error(httpx.NetworkError("connection reset"))

    def test_value_error_not_retryable(self) -> None:
        assert not is_retryable_error(ValueError("bad input"))

    def test_generic_http_error_not_retryable(self) -> None:
        # httpx.HTTPError is the base, but only Timeout and Network are retryable.
        assert not is_retryable_error(httpx.HTTPError("generic"))


class TestIsRetryableStatus:
    def test_429_retryable(self) -> None:
        assert is_retryable_status(429)

    def test_500_retryable(self) -> None:
        assert is_retryable_status(500)

    def test_502_retryable(self) -> None:
        assert is_retryable_status(502)

    def test_503_retryable(self) -> None:
        assert is_retryable_status(503)

    def test_504_retryable(self) -> None:
        assert is_retryable_status(504)

    def test_200_not_retryable(self) -> None:
        assert not is_retryable_status(200)

    def test_404_not_retryable(self) -> None:
        assert not is_retryable_status(404)

    def test_401_not_retryable(self) -> None:
        assert not is_retryable_status(401)


class TestRetryRequest:
    @patch("bartram_foundry.http.time.sleep")
    def test_succeeds_on_first_try(self, mock_sleep: MagicMock) -> None:
        func = MagicMock(return_value="ok")
        result = retry_request(func, max_retries=2)
        assert result == "ok"
        func.assert_called_once()
        mock_sleep.assert_not_called()

    @patch("bartram_foundry.http.time.sleep")
    def test_retries_on_timeout(self, mock_sleep: MagicMock) -> None:
        func = MagicMock(
            side_effect=[httpx.TimeoutException("timeout"), "ok"]
        )
        result = retry_request(func, max_retries=2, base_delay=0.1)
        assert result == "ok"
        assert func.call_count == 2
        mock_sleep.assert_called_once_with(0.1)

    @patch("bartram_foundry.http.time.sleep")
    def test_retries_on_network_error(self, mock_sleep: MagicMock) -> None:
        func = MagicMock(
            side_effect=[httpx.NetworkError("reset"), "ok"]
        )
        result = retry_request(func, max_retries=2, base_delay=0.5)
        assert result == "ok"
        assert func.call_count == 2
        mock_sleep.assert_called_once_with(0.5)

    @patch("bartram_foundry.http.time.sleep")
    def test_exponential_backoff(self, mock_sleep: MagicMock) -> None:
        func = MagicMock(
            side_effect=[
                httpx.TimeoutException("1"),
                httpx.TimeoutException("2"),
                "ok",
            ]
        )
        result = retry_request(func, max_retries=2, base_delay=1.0)
        assert result == "ok"
        assert func.call_count == 3
        # First retry: 1.0 * 2^0 = 1.0, second: 1.0 * 2^1 = 2.0
        assert mock_sleep.call_args_list[0][0][0] == 1.0
        assert mock_sleep.call_args_list[1][0][0] == 2.0

    @patch("bartram_foundry.http.time.sleep")
    def test_raises_after_max_retries(self, mock_sleep: MagicMock) -> None:
        func = MagicMock(
            side_effect=httpx.TimeoutException("timeout")
        )
        with pytest.raises(httpx.TimeoutException):
            retry_request(func, max_retries=2, base_delay=0.1)
        assert func.call_count == 3  # 1 initial + 2 retries

    @patch("bartram_foundry.http.time.sleep")
    def test_no_retry_on_non_transient_error(self, mock_sleep: MagicMock) -> None:
        func = MagicMock(side_effect=ValueError("bad"))
        with pytest.raises(ValueError):
            retry_request(func, max_retries=2)
        func.assert_called_once()
        mock_sleep.assert_not_called()

    @patch("bartram_foundry.http.time.sleep")
    def test_zero_retries(self, mock_sleep: MagicMock) -> None:
        func = MagicMock(side_effect=httpx.TimeoutException("timeout"))
        with pytest.raises(httpx.TimeoutException):
            retry_request(func, max_retries=0)
        func.assert_called_once()
        mock_sleep.assert_not_called()

    @patch("bartram_foundry.http.time.sleep")
    def test_passes_args_and_kwargs(self, mock_sleep: MagicMock) -> None:
        func = MagicMock(return_value="ok")
        retry_request(func, "a", "b", max_retries=0, key="val")
        func.assert_called_once_with("a", "b", key="val")
