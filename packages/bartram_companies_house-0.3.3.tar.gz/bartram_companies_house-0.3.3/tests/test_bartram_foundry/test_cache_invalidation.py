"""Tests for cache invalidation support."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from bartram_foundry.cache import ResponseCache

if TYPE_CHECKING:
    from pathlib import Path


@pytest.fixture
def cache(tmp_path: Path) -> ResponseCache:
    return ResponseCache(tmp_path / "test_cache.db")


class TestCacheInvalidate:
    def test_invalidate_existing_entry(self, cache: ResponseCache) -> None:
        cache.put("ch", "/company/123", {"name": "Tesco"}, ttl_seconds=3600)
        assert cache.get("ch", "/company/123") is not None
        removed = cache.invalidate("ch", "/company/123")
        assert removed is True
        assert cache.get("ch", "/company/123") is None

    def test_invalidate_missing_entry(self, cache: ResponseCache) -> None:
        removed = cache.invalidate("ch", "/company/999")
        assert removed is False

    def test_invalidate_with_params(self, cache: ResponseCache) -> None:
        params = {"q": "tesco"}
        cache.put("ch", "/search", {"results": []}, ttl_seconds=3600, params=params)
        assert cache.get("ch", "/search", params) is not None
        removed = cache.invalidate("ch", "/search", params)
        assert removed is True
        assert cache.get("ch", "/search", params) is None

    def test_invalidate_only_affects_matching_entry(self, cache: ResponseCache) -> None:
        cache.put("ch", "/company/111", {"a": 1}, ttl_seconds=3600)
        cache.put("ch", "/company/222", {"b": 2}, ttl_seconds=3600)
        cache.invalidate("ch", "/company/111")
        assert cache.get("ch", "/company/111") is None
        assert cache.get("ch", "/company/222") is not None

    def test_invalidate_respects_namespace(self, cache: ResponseCache) -> None:
        cache.put("ch", "/search", {"ch": True}, ttl_seconds=3600)
        cache.put("fca", "/search", {"fca": True}, ttl_seconds=3600)
        cache.invalidate("ch", "/search")
        assert cache.get("ch", "/search") is None
        assert cache.get("fca", "/search") is not None
