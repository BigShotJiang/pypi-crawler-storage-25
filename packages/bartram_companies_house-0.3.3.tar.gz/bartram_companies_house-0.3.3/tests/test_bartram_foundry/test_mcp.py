"""Tests for bartram_foundry.mcp — response formatting helpers."""

from __future__ import annotations

import json

from bartram_foundry.mcp import format_error, format_response


class TestFormatResponse:
    def test_basic_envelope(self) -> None:
        result = format_response(
            {"name": "Tesco"},
            source="Test API",
            licence="Test Licence",
            attribution="Test attribution",
            endpoint="/test",
        )
        parsed = json.loads(result)
        assert parsed["data"] == {"name": "Tesco"}
        assert parsed["metadata"]["source"] == "Test API"
        assert parsed["metadata"]["licence"] == "Test Licence"
        assert parsed["metadata"]["endpoint"] == "/test"
        assert parsed["metadata"]["cached"] is False
        assert parsed["metadata"]["attribution"] == "Test attribution"
        assert "retrieved_at" in parsed["metadata"]

    def test_cached_flag(self) -> None:
        result = format_response(
            {},
            source="X",
            licence="Y",
            attribution="Z",
            endpoint="/x",
            cached=True,
        )
        parsed = json.loads(result)
        assert parsed["metadata"]["cached"] is True

    def test_handles_non_serialisable_data(self) -> None:
        """The default=str fallback should handle datetime etc."""
        from datetime import datetime
        result = format_response(
            {"ts": datetime(2024, 1, 1)},
            source="X",
            licence="Y",
            attribution="Z",
            endpoint="/x",
        )
        parsed = json.loads(result)
        assert "2024" in parsed["data"]["ts"]


class TestFormatError:
    def test_basic_error(self) -> None:
        result = format_error("not_found", "Company not found", "Test attr")
        parsed = json.loads(result)
        assert parsed["error"] == "not_found"
        assert parsed["message"] == "Company not found"
        assert parsed["attribution"] == "Test attr"
        assert "status_code" not in parsed

    def test_with_status_code(self) -> None:
        result = format_error("server_error", "Oops", "X", status_code=500)
        parsed = json.loads(result)
        assert parsed["status_code"] == 500

    def test_with_extra_fields(self) -> None:
        result = format_error(
            "rate_limited", "Too fast", "X",
            extra={"retry_after": 60},
        )
        parsed = json.loads(result)
        assert parsed["retry_after"] == 60
