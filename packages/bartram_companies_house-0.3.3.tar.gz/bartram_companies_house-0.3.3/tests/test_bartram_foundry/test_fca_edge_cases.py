"""Tests for FCA clean layer edge cases — null data guards and workplace flattening."""

from __future__ import annotations

from bartram_fca.clean import (
    clean_firm,
    clean_firm_address,
    clean_firm_appointed_reps,
    clean_firm_control_functions,
    clean_firm_disciplinary_history,
    clean_firm_exclusions,
    clean_firm_individuals,
    clean_firm_names,
    clean_firm_passport_permissions,
    clean_firm_passports,
    clean_firm_permissions,
    clean_firm_regulators,
    clean_firm_requirement_investment_types,
    clean_firm_requirements,
    clean_firm_waivers,
    clean_individual,
    clean_individual_control_functions,
    clean_individual_disciplinary_history,
    clean_search_results,
    flatten_workplaces,
)


# ---------------------------------------------------------------------------
# Null data guards — every clean function should handle Data=None gracefully
# ---------------------------------------------------------------------------


class TestNullDataGuards:
    """All 19 clean functions should return a result with no_data=True when Data is None."""

    _null_data_response = {
        "Status": "FSR-API-02-01-11",
        "ResultInfo": None,
        "Message": "No Data",
        "Data": None,
    }

    def _assert_no_data(self, result: dict) -> None:
        assert "_cleaning" in result
        assert result["_cleaning"].get("no_data") is True

    def test_clean_search_results(self) -> None:
        self._assert_no_data(clean_search_results(dict(self._null_data_response)))

    def test_clean_firm(self) -> None:
        self._assert_no_data(clean_firm(dict(self._null_data_response)))

    def test_clean_firm_names(self) -> None:
        self._assert_no_data(clean_firm_names(dict(self._null_data_response)))

    def test_clean_firm_address(self) -> None:
        self._assert_no_data(clean_firm_address(dict(self._null_data_response)))

    def test_clean_firm_permissions(self) -> None:
        self._assert_no_data(clean_firm_permissions(dict(self._null_data_response)))

    def test_clean_firm_individuals(self) -> None:
        self._assert_no_data(clean_firm_individuals(dict(self._null_data_response)))

    def test_clean_firm_control_functions(self) -> None:
        self._assert_no_data(clean_firm_control_functions(dict(self._null_data_response)))

    def test_clean_firm_requirements(self) -> None:
        self._assert_no_data(clean_firm_requirements(dict(self._null_data_response)))

    def test_clean_firm_requirement_investment_types(self) -> None:
        self._assert_no_data(clean_firm_requirement_investment_types(dict(self._null_data_response)))

    def test_clean_firm_regulators(self) -> None:
        self._assert_no_data(clean_firm_regulators(dict(self._null_data_response)))

    def test_clean_firm_passports(self) -> None:
        self._assert_no_data(clean_firm_passports(dict(self._null_data_response)))

    def test_clean_firm_passport_permissions(self) -> None:
        self._assert_no_data(clean_firm_passport_permissions(dict(self._null_data_response)))

    def test_clean_firm_appointed_reps(self) -> None:
        self._assert_no_data(clean_firm_appointed_reps(dict(self._null_data_response)))

    def test_clean_firm_waivers(self) -> None:
        self._assert_no_data(clean_firm_waivers(dict(self._null_data_response)))

    def test_clean_firm_exclusions(self) -> None:
        self._assert_no_data(clean_firm_exclusions(dict(self._null_data_response)))

    def test_clean_firm_disciplinary_history(self) -> None:
        self._assert_no_data(clean_firm_disciplinary_history(dict(self._null_data_response)))

    def test_clean_individual(self) -> None:
        self._assert_no_data(clean_individual(dict(self._null_data_response)))

    def test_clean_individual_control_functions(self) -> None:
        self._assert_no_data(clean_individual_control_functions(dict(self._null_data_response)))

    def test_clean_individual_disciplinary_history(self) -> None:
        self._assert_no_data(clean_individual_disciplinary_history(dict(self._null_data_response)))


# ---------------------------------------------------------------------------
# Workplace flattening — gap handling
# ---------------------------------------------------------------------------


class TestWorkplaceFlatteningGaps:
    def test_sequential_workplaces(self) -> None:
        data = {
            "Workplace Location 1": {"location": "London"},
            "Workplace Location 2": {"location": "Manchester"},
        }
        workplaces, changed = flatten_workplaces(data)
        assert changed is True
        assert len(workplaces) == 2
        assert workplaces[0]["location"] == "London"
        assert workplaces[1]["location"] == "Manchester"
        assert "Workplace Location 1" not in data
        assert "Workplace Location 2" not in data

    def test_gap_in_numbering(self) -> None:
        """Workplace Location 3 should be collected even if 2 is missing."""
        data = {
            "Workplace Location 1": {"location": "London"},
            "Workplace Location 3": {"location": "Birmingham"},
        }
        workplaces, changed = flatten_workplaces(data)
        assert changed is True
        assert len(workplaces) == 2
        assert workplaces[0]["location"] == "London"
        assert workplaces[1]["location"] == "Birmingham"

    def test_snake_case_keys(self) -> None:
        data = {
            "workplace_location_1": {"location": "London"},
            "workplace_location_2": {"location": "Manchester"},
        }
        workplaces, changed = flatten_workplaces(data)
        assert changed is True
        assert len(workplaces) == 2

    def test_snake_case_with_gap(self) -> None:
        data = {
            "workplace_location_1": {"location": "London"},
            "workplace_location_5": {"location": "Edinburgh"},
        }
        workplaces, changed = flatten_workplaces(data)
        assert changed is True
        assert len(workplaces) == 2

    def test_string_value(self) -> None:
        data = {"Workplace Location 1": "123 High Street, London"}
        workplaces, changed = flatten_workplaces(data)
        assert changed is True
        assert len(workplaces) == 1
        assert workplaces[0]["location"] == "123 High Street, London"

    def test_no_workplaces(self) -> None:
        data = {"name": "John Smith", "status": "Active"}
        workplaces, changed = flatten_workplaces(data)
        assert changed is False
        assert len(workplaces) == 0

    def test_preserves_order(self) -> None:
        """Even with gaps, workplaces should be sorted by index."""
        data = {
            "Workplace Location 5": {"location": "Edinburgh"},
            "Workplace Location 1": {"location": "London"},
            "Workplace Location 3": {"location": "Birmingham"},
        }
        workplaces, changed = flatten_workplaces(data)
        assert changed is True
        assert [w["location"] for w in workplaces] == [
            "London", "Birmingham", "Edinburgh",
        ]

    def test_mixed_key_formats(self) -> None:
        data = {
            "Workplace Location 1": {"location": "London"},
            "workplace_location_2": {"location": "Manchester"},
        }
        workplaces, changed = flatten_workplaces(data)
        assert changed is True
        assert len(workplaces) == 2
