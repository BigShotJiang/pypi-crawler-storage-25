# UK FCA Financial Services Register MCP Server

Clean, structured UK financial regulatory data for AI agents — via the [Model Context Protocol](https://modelcontextprotocol.io/).

<!-- mcp-name: io.github.RobertAlsop/fca-register -->

## What this does

This MCP server gives agents access to 19 FCA Financial Services Register endpoints — firm search, details, names, addresses, permissions, individuals, control functions, requirements, regulators, passports, appointed representatives, waivers, exclusions, disciplinary history, and individual details/roles — with data cleaning that the raw API doesn't provide.

FCA Register data has known quality issues: dates arrive in DD/MM/YYYY format, field names are inconsistent (space-separated, CamelCase, mixed), HATEOAS links clutter responses with raw URLs instead of tool references, control function codes are opaque strings, and permissions are keyed by name rather than structured as lists. This server fixes those problems before the data reaches your agent.

**What the cleaning layer does:**

- **Date normalisation** — all DD/MM/YYYY dates converted to ISO 8601 (YYYY-MM-DD) across every endpoint.
- **Field name normalisation** — inconsistent field names (spaces, CamelCase, hyphens) converted to snake_case.
- **HATEOAS link replacement** — raw API URLs replaced with `related_endpoints` mapping to tool names agents can call directly.
- **Control function parsing** — opaque strings like `(6865)SMF7 Group Entity Senior Manager` parsed into structured `{id, code, description}` objects.
- **Permissions restructuring** — dict-keyed permissions converted to a clean list of `{permission, limitations}` objects.
- **Firm names flattening** — `Current Names` / `Previous Names` nested structure flattened into a single list with `current` flags.
- **Individual data unwrapping** — nested `Data[0]["Details"]` structure unwrapped to top-level fields.
- **Workplace flattening** — numbered `Workplace Location 1`, `Workplace Location 2` keys collapsed into a `workplaces` array.
- **Exceptional info parsing** — concatenated numbered notices split into individual items.
- **Address normalisation** — consistent formatting, postcode standardisation using shared UK address utilities.
- **Trading name splitting** — comma-separated trading names split into arrays.
- **FRN/IRN normalisation** — agents can send `FRN-122702` or `jxd01375` and the server normalises to `122702` / `JXD01375`.
- **Full pagination** — all paginated sub-resources fetched completely across all pages automatically.
- **Data quality annotations** — every cleaned record carries `_cleaning` metadata so agents can see what was changed and why.

## Quick start

```bash
# Install
pip install bartram-companies-house

# Set your API credentials (required)
export FCA_API_EMAIL="your-email"
export FCA_API_KEY="your-key"

# Run the MCP server
bartram-fca
```

Or with [uvx](https://docs.astral.sh/uv/):

```bash
uvx bartram-fca
```

Register for free API credentials at the [FCA Register](https://register.fca.org.uk/Developer/s/).

### Configure with Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "fca-register": {
      "command": "uvx",
      "args": ["bartram-fca"],
      "env": {
        "FCA_API_EMAIL": "your-email",
        "FCA_API_KEY": "your-key"
      }
    }
  }
}
```

## Tools

| Tool | Description |
|------|-------------|
| `uk_fca_search` | Search the FCA Register for firms, individuals, and regulated entities |
| `uk_fca_firm` | Get firm details — status, business type, regulatory dates, exceptional info |
| `uk_fca_firm_names` | Get brand and trading names (current and historical) |
| `uk_fca_firm_address` | Get registered address and contact details |
| `uk_fca_firm_permissions` | Get regulatory permissions with limitations |
| `uk_fca_firm_individuals` | Get all individuals associated with a firm |
| `uk_fca_firm_control_functions` | Get control function holders (SMF/CF roles) |
| `uk_fca_firm_requirements` | Get regulatory requirements |
| `uk_fca_firm_requirement_investment_types` | Get investment types for a specific requirement |
| `uk_fca_firm_regulators` | Get regulatory bodies for a firm |
| `uk_fca_firm_passports` | Get EU/EEA passporting info (largely historical post-Brexit) |
| `uk_fca_firm_passport_permissions` | Get passport permissions |
| `uk_fca_firm_appointed_reps` | Get appointed representatives (current and previous) |
| `uk_fca_firm_waivers` | Get regulatory waivers |
| `uk_fca_firm_exclusions` | Get exclusions from regulation |
| `uk_fca_firm_disciplinary_history` | Get disciplinary actions against a firm |
| `uk_fca_individual` | Get individual details — name, status, workplaces |
| `uk_fca_individual_control_functions` | Get control function roles held by an individual |
| `uk_fca_individual_disciplinary_history` | Get disciplinary actions against an individual |

See [SCHEMA_FCA.md](SCHEMA_FCA.md) for full parameter and response documentation.

## Example

Ask your agent: *"Is Barclays Bank authorised by the FCA and who holds senior management functions there?"*

The agent calls `uk_fca_search` with `query: "Barclays"`, gets FRN `122702`, then calls `uk_fca_firm` for status and `uk_fca_firm_control_functions` for SMF holders:

```json
{
  "data": {
    "current": [
      {
        "id": "6865",
        "code": "SMF7",
        "description": "Group Entity Senior Manager"
      },
      {
        "id": "6860",
        "code": "SMF17",
        "description": "Money Laundering Reporting Officer (MLRO)"
      }
    ],
    "previous": [
      {
        "id": "23603",
        "code": "CF10",
        "description": "Compliance Oversight"
      }
    ],
    "_cleaning": {
      "cf_parsed": true,
      "fields_normalised": true
    }
  },
  "metadata": {
    "source": "FCA Financial Services Register",
    "licence": "FCA Public Record",
    "endpoint": "/Firm/122702/CF",
    "attribution": "Source: FCA Financial Services Register. Contains public record data maintained by the Financial Conduct Authority."
  }
}
```

Every response includes a `metadata` envelope with source attribution, licence information, and retrieval timestamp.

## Data source

All data comes from the [FCA Financial Services Register API](https://register.fca.org.uk/Developer/s/). Published as public record data by the Financial Conduct Authority.

## Caching

Responses are cached locally in SQLite to reduce API calls and stay within rate limits (50 requests per 10 seconds):

| Endpoint | TTL |
|----------|-----|
| Search | 5 minutes |
| Firm details | 1 hour |
| Firm names | 1 hour |
| Firm address | 1 hour |
| Firm permissions | 30 minutes |
| Firm individuals | 30 minutes |
| Firm control functions | 30 minutes |
| Firm requirements | 30 minutes |
| Firm requirement investment types | 30 minutes |
| Firm regulators | 1 hour |
| Firm passports | 1 hour |
| Firm passport permissions | 1 hour |
| Firm appointed reps | 30 minutes |
| Firm waivers | 30 minutes |
| Firm exclusions | 30 minutes |
| Firm disciplinary history | 30 minutes |
| Individual | 1 hour |
| Individual control functions | 30 minutes |
| Individual disciplinary history | 30 minutes |

Cache is stored in `monitoring.db` by default. Set `BARTRAM_DATA_DIR` to change the location.

## Development

```bash
git clone https://github.com/RobertAlsop/bartram_foundry.git
cd bartram_foundry
uv sync --all-extras
uv run pytest bartram_fca/tests/
uv run ruff check bartram_fca/
```

## Licence

MIT

---

Built by [Bartram Foundry](https://github.com/RobertAlsop/bartram_foundry) — production-grade MCP tools for UK public data.
