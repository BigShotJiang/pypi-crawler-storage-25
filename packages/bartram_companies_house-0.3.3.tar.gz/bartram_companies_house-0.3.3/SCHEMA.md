# Schema Reference

Complete tool reference for the UK Companies House MCP server. Each tool follows the `access → clean → serve` pattern: raw API data is fetched, cleaned, and returned in a consistent envelope.

## Response envelope

Every successful response wraps data in this structure:

```json
{
  "data": { ... },
  "metadata": {
    "source": "Companies House Public Data API",
    "licence": "Open Government Licence v3",
    "retrieved_at": "2026-04-04T10:00:00+00:00",
    "endpoint": "/search/companies",
    "cached": false,
    "attribution": "Contains public sector information licensed under the Open Government Licence v3.0. Source: Companies House."
  }
}
```

Error responses:

```json
{
  "error": "Company not found: 99999999",
  "status_code": 404,
  "attribution": "Contains public sector information licensed under the Open Government Licence v3.0. Source: Companies House."
}
```

---

## uk_companies_house_search

Search for UK companies by name or number.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | yes | — | Company name or number to search for |
| `items_per_page` | int | no | 20 | Number of results per page (1–100) |

### Returns

`data` contains the Companies House search response with cleaned addresses. Each item includes: `title` (company name), `company_number`, `company_number_padded`, `company_status`, `company_type`, `date_of_creation`, `name_normalised`, and `address` (normalised with a `formatted` single-line version).

### Cleaning applied

- Company numbers zero-padded (`company_number_padded` field).
- Company names normalised (`name_normalised` field).
- Addresses normalised: postcode formatting, line standardisation, `formatted` single-line field added.
- Empty query rejected with a descriptive error.
- `_cleaning` annotations on each item.

### Example call

```json
{"name": "uk_companies_house_search", "arguments": {"query": "Tesco", "items_per_page": 3}}
```

---

## uk_companies_house_profile

Get the full profile of a UK company by its company number.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `company_number` | string | yes | — | Companies House number (e.g. `00445790`). Numeric values are automatically zero-padded to 8 digits. Prefixed numbers (SC, NI, OC) are uppercased. |

### Returns

`data` contains the full company profile: `company_name`, `company_number`, `company_status`, `type`, `date_of_creation`, `registered_office_address` (cleaned), `sic_codes` with `sic_descriptions` (human-readable), `accounts` (next due, last made up to), `confirmation_statement` (next due), and more.

### Cleaning applied

- Company number normalised (zero-padded, uppercased).
- Registered office address cleaned: postcode formatting, line normalisation, `formatted` field.
- SIC codes enriched with human-readable descriptions in `sic_descriptions`.
- `_cleaning` annotations documenting all changes.

### Example call

```json
{"name": "uk_companies_house_profile", "arguments": {"company_number": "445790"}}
```

Note: `445790` is automatically normalised to `00445790`.

---

## uk_companies_house_officers

Get officers (directors, secretaries, etc.) of a UK company with name deduplication.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `company_number` | string | yes | — | Companies House number. Automatically normalised. |

### Returns

`data` contains the officer list with `items` (deduplicated officer records) and `_cleaning` metadata showing original count, deduplicated count, duplicates removed, active count, and resigned count.

Each officer record includes: `name`, `officer_role`, `appointed_on`, `resigned_on` (if applicable), `nationality`, `occupation`, `country_of_residence`, `address`, and `_cleaning` annotations with entity type classification.

Deduplicated records include a `_cleaning` annotation with `duplicate_count`, `original_names`, and a human-readable `note`.

### Cleaning applied

- **Full pagination**: fetches all pages of officers, not just the first 50.
- **Name deduplication**: fuzzy matching (threshold 85/100) groups records like "SMITH, John David" and "John Smith" when they share the same role. The most recently appointed record is kept as primary.
- **Entity classification**: each officer annotated as individual, corporate, or unknown. Corporate entities misclassified as individuals are flagged.
- **Active/resigned counts**: summary counts in `_cleaning`.
- Company number normalised.

### Example call

```json
{"name": "uk_companies_house_officers", "arguments": {"company_number": "00445790"}}
```

---

## uk_companies_house_psc

Get persons with significant control (beneficial owners) of a UK company with entity classification.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `company_number` | string | yes | — | Companies House number. Automatically normalised. |

### Returns

`data` contains the PSC list with `items` and `_cleaning` summary (active/ceased counts). Each PSC record includes: `name`, `kind`, `natures_of_control` with `natures_of_control_descriptions` (human-readable), `notified_on`, `ceased_on` (if applicable), and `address`.

Each record carries a `_cleaning` annotation with `entity_type` (`individual`, `corporate`, or `unknown`), and flags for `misclassified` (corporate entity filed as individual) and `ceased`.

### Cleaning applied

- **Full pagination**: fetches all pages.
- **Entity classification**: each record annotated as individual, corporate, or unknown.
- **Misclassification detection**: flags corporate entities incorrectly filed as natural persons.
- **Nature of control interpretation**: coded values translated to human-readable descriptions.
- **Active/ceased counts**: summary counts in `_cleaning`.
- Company number normalised.

### Example call

```json
{"name": "uk_companies_house_psc", "arguments": {"company_number": "00445790"}}
```

---

## uk_companies_house_filings

Get filing history for a UK company with human-readable descriptions.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `company_number` | string | yes | — | Companies House number. Automatically normalised. |
| `category` | string | no | — | Filter by filing category. Valid values: `accounts`, `address`, `annual-return`, `capital`, `change-of-name`, `confirmation-statement`, `incorporation`, `liquidation`, `miscellaneous`, `mortgage`, `officers`, `resolution`, `restoration`, `return`. |
| `items_per_page` | int | no | — | If set, returns a single page of this size. If omitted, fetches all filings (paginated). |

### Returns

`data` contains the filing history with `items`. Each filing includes: `category`, `type`, `date`, `description` (raw code), `description_rendered` (readable text), and `description_values` (interpolated data). Each item carries `_cleaning` annotations.

### Cleaning applied

- **Full pagination** (when `items_per_page` not set): fetches all filing pages.
- **Description rendering**: converts hyphenated filing codes into readable sentences, interpolating variable values (names, dates, capital figures).
- **Category validation**: invalid categories rejected with the list of valid values.
- `_cleaning` annotations per item.
- Company number normalised.

### Example call

```json
{"name": "uk_companies_house_filings", "arguments": {"company_number": "00445790", "category": "accounts", "items_per_page": 5}}
```

---

## uk_companies_house_charges

Get charges (mortgages and security interests) registered against a UK company.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `company_number` | string | yes | — | Companies House number. Automatically normalised. |

### Returns

`data` contains the charge list with `items` and `_cleaning` summary (outstanding/satisfied/part-satisfied counts). Each charge includes: `charge_number`, `status` with `status_description` (human-readable), `created_on`, `delivered_on`, `satisfied_on` (if applicable), `persons_entitled` (normalised lender names), `particulars`, and `_cleaning` annotations.

### Cleaning applied

- **Full pagination**: fetches all pages of charges.
- **Charge status interpretation**: codes translated to human-readable descriptions.
- **Lender name normalisation**: names in `persons_entitled` cleaned.
- **Outstanding/satisfied/part-satisfied counts**: summary in `_cleaning`.
- Company number normalised.

### Example call

```json
{"name": "uk_companies_house_charges", "arguments": {"company_number": "00445790"}}
```

---

## uk_companies_house_insolvency

Get insolvency information for a UK company, including cases and practitioners.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `company_number` | string | yes | — | Companies House number. Automatically normalised. |

### Returns

`data` contains insolvency information with `cases` (each with type, dates, practitioners) and `status`. Each case includes `type` with `type_description` (human-readable), practitioners with normalised addresses.

If the company's profile indicates insolvency history but the API returns 404 (a known inconsistency), a clean empty result is returned with `_cleaning.api_404_despite_profile_flag: true`.

### Cleaning applied

- **Case type interpretation**: codes like `creditors-voluntary-liquidation` translated to descriptions.
- **Practitioner address normalisation**.
- **Graceful 404 handling**: known API inconsistency handled cleanly.
- Company number normalised.

### Example call

```json
{"name": "uk_companies_house_insolvency", "arguments": {"company_number": "03034498"}}
```

---

## uk_companies_house_officer_search

Search for officers (directors, secretaries) across all UK companies by name.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | yes | — | Officer name to search for |
| `items_per_page` | int | no | 20 | Number of results per page |

### Returns

`data` contains search results with `items`. Each officer includes: `title` (name), `date_of_birth`, `address`, `appointment_count`, `links` (containing officer ID for use with appointments endpoint), and `_cleaning` annotations with entity classification.

### Cleaning applied

- **Entity classification**: each result annotated as individual or corporate.
- **Address normalisation**.
- Empty query rejected with a descriptive error.
- `_cleaning` annotations per item.

### Example call

```json
{"name": "uk_companies_house_officer_search", "arguments": {"query": "John Smith", "items_per_page": 10}}
```

---

## uk_companies_house_officer_appointments

List all company appointments for a specific officer across all UK companies.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `officer_id` | string | yes | — | Officer ID from officer search results or officer list links |

### Returns

`data` contains the appointment list with `items` and `_cleaning` summary (active/resigned counts). Each appointment includes: `appointed_to` (company name and number, zero-padded), `officer_role`, `appointed_on`, `resigned_on` (if applicable), `address`, and `_cleaning` annotations.

### Cleaning applied

- **Full pagination**: fetches all pages of appointments.
- **Company number zero-padding** in appointed_to.
- **Active/resigned counts**: summary in `_cleaning`.
- **Address normalisation**.
- Empty officer_id rejected with a descriptive error.

### Example call

```json
{"name": "uk_companies_house_officer_appointments", "arguments": {"officer_id": "abc123def456"}}
```

---

## uk_companies_house_disqualified_officer

Check whether an officer is disqualified and get disqualification details.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `officer_id` | string | yes | — | Officer ID |
| `officer_type` | string | no | `natural` | Either `natural` or `corporate` |

### Returns

If disqualified: `data` contains disqualification records with `disqualified: true`, `disqualifications` (each with reason, start/end dates, related company names), and `_cleaning` annotations.

If not disqualified: `data` contains `disqualified: false` and `officer_id`. A 404 from the API means "not disqualified" — this is returned as a clean result, not an error.

### Cleaning applied

- **Graceful 404 handling**: API 404 converted to clean "not disqualified" result.
- **Company name normalisation** in disqualification records.
- Empty officer_id rejected with a descriptive error.
- Invalid officer_type rejected.

### Example call

```json
{"name": "uk_companies_house_disqualified_officer", "arguments": {"officer_id": "abc123def456"}}
```

---

## uk_companies_house_advanced_search

Search for UK companies with filters (status, SIC code, incorporation date, location).

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | no | — | Company name search term |
| `company_status` | string | no | — | Filter by status (e.g. `active`, `dissolved`) |
| `company_type` | string | no | — | Filter by type (e.g. `ltd`, `plc`, `llp`) |
| `sic_codes` | string | no | — | Filter by SIC code (e.g. `47110`) |
| `incorporated_from` | string | no | — | Incorporation date from (YYYY-MM-DD) |
| `incorporated_to` | string | no | — | Incorporation date to (YYYY-MM-DD) |
| `location` | string | no | — | Filter by registered address location |
| `size` | int | no | 20 | Number of results per page |
| `start_index` | int | no | 0 | Pagination offset |

At least one filter parameter must be provided.

### Returns

`data` contains search results with `items` and `total_results`. Each company includes: `company_name`, `company_number` (zero-padded), `company_status`, `company_type`, `sic_codes` with descriptions, `date_of_creation`, and `_cleaning` annotations.

### Cleaning applied

- **Company number zero-padding**.
- **SIC code descriptions** added.
- **Result count normalisation**: API's `hits` field normalised to `total_results`.
- At least one filter required — empty searches rejected.
- `_cleaning` annotations per item.

### Example call

```json
{"name": "uk_companies_house_advanced_search", "arguments": {"company_status": "active", "sic_codes": "47110", "size": 5}}
```

---

## uk_companies_house_registered_address

Get the registered office address for a UK company.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `company_number` | string | yes | — | Companies House number. Automatically normalised. |

### Returns

`data` contains the registered address with normalised fields: `address_line_1`, `address_line_2`, `care_of`, `po_box`, `locality`, `region`, `postal_code` (formatted), `country`, and `formatted` (single-line version). Includes `_cleaning` annotations.

### Cleaning applied

- **Address normalisation**: postcode formatting, title-casing, line standardisation.
- **Care-of and PO Box handling**.
- **Single-line formatted field**.
- Company number normalised.

### Example call

```json
{"name": "uk_companies_house_registered_address", "arguments": {"company_number": "00445790"}}
```

---

## Data source

All data from the [Companies House API](https://developer.company-information.service.gov.uk/). Published under the [Open Government Licence v3.0](https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/). Crown copyright.
