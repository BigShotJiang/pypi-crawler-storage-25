"""Entry point for running the Charity Commission MCP server.

Usage:
    python -m bartram_charity
    uvx bartram-charity
"""

from bartram_charity.serve import main

if __name__ == "__main__":
    main()
