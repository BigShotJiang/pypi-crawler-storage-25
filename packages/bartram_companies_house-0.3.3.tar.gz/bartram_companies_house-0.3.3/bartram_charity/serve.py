"""MCP tool definitions for Charity Commission for England and Wales — what agents call.

31 tools exposed:
- uk_charity_search: Search charities by name
- uk_charity_lookup: Look up charity by registered number
- uk_charity_search_by_registration_date: Find charities by registration date range
- uk_charity_search_by_removal_date: Find charities by removal date range
- uk_charity_profile: Comprehensive charity details (V2)
- uk_charity_details: Core charity details (lightweight)
- uk_charity_batch_lookup: Batch fetch multiple charities
- uk_charity_trustees: Detailed trustee information
- uk_charity_trustee_names: Lightweight trustee name list
- uk_charity_classifications: What/Who/How classifications
- uk_charity_areas_of_operation: Geographic areas of operation
- uk_charity_contact: Contact details
- uk_charity_constituency: Parliamentary constituency
- uk_charity_policies: Governance policies
- uk_charity_other_regulators: Other regulatory bodies
- uk_charity_primary_grants: Grant-making status
- uk_charity_financial_history: 5-year financial history
- uk_charity_annual_return: Most recent Annual Return
- uk_charity_accounts: Accounts submission history
- uk_charity_assets: Assets and liabilities
- uk_charity_governing_document: Governing document and objects
- uk_charity_governance: Governance summary
- uk_charity_linked_charities: Linked/subsidiary charities
- uk_charity_other_names: Working and historical names
- uk_charity_registration_history: Registration event history
- uk_charity_regulatory_reports: Published regulatory reports
- uk_charity_cio_dissolution: CIO dissolution notice
- uk_charity_sector_overview: Sector statistics
- uk_charity_sector_top10: Top 10 charities by metric
- uk_charity_sector_income_bands: Sector data by income band
- uk_charity_sector_income_categories: Sector data by income category
"""

from __future__ import annotations

import json
import threading
import time
from datetime import datetime, timezone
from typing import Any

from mcp.server.fastmcp import FastMCP

from bartram_charity.access import (
    AuthenticationError,
    BadRequestError,
    CharityClient,
    CharityConfig,
    CharityError,
    NotFoundError,
    RateLimitError,
    ServerError,
    validate_charity_number,
    validate_date,
)
from bartram_charity.clean import (
    clean_accounts,
    clean_annual_return,
    clean_areas_of_operation,
    clean_assets,
    clean_batch_lookup,
    clean_cio_dissolution,
    clean_classifications,
    clean_constituency,
    clean_contact,
    clean_details,
    clean_financial_history,
    clean_governance,
    clean_governing_document,
    clean_linked_charities,
    clean_lookup,
    clean_other_names,
    clean_other_regulators,
    clean_policies,
    clean_primary_grants,
    clean_profile,
    clean_registration_history,
    clean_regulatory_reports,
    clean_search_results,
    clean_sector_income_bands,
    clean_sector_income_categories,
    clean_sector_overview,
    clean_sector_top10,
    clean_trustee_names,
    clean_trustees,
)
from bartram_foundry.monitoring import MetricsStore

# ---------------------------------------------------------------------------
# Server setup
# ---------------------------------------------------------------------------

server = FastMCP(
    "bartram-charity",
    instructions=(
        "Charity Commission for England and Wales register data with "
        "cleaning and normalisation. 31 tools covering charity search, "
        "details, profiles, trustees, classifications, areas of "
        "operation, financials, governance, regulatory reports, and "
        "sector statistics. "
        "Source: Charity Commission for England and Wales. "
        "Contains public sector information licensed under the "
        "Open Government Licence v3.0."
    ),
)

_client: CharityClient | None = None
_metrics: MetricsStore | None = None
_init_lock = threading.Lock()


def _get_client() -> CharityClient:
    """Get or create the API client (lazy init, thread-safe)."""
    global _client
    if _client is None:
        with _init_lock:
            if _client is None:
                _client = CharityClient(CharityConfig.from_env())
    return _client


def _get_metrics() -> MetricsStore:
    """Get or create the metrics store (lazy init, thread-safe)."""
    global _metrics
    if _metrics is None:
        with _init_lock:
            if _metrics is None:
                _metrics = MetricsStore()
    return _metrics


# ---------------------------------------------------------------------------
# Response formatting
# ---------------------------------------------------------------------------

_ATTRIBUTION = (
    "Contains public sector information licensed under the Open "
    "Government Licence v3.0. Source: Charity Commission for "
    "England and Wales."
)


def _format_response(
    data: Any, *, endpoint: str, cached: bool = False,
) -> str:
    """Format a cleaned API response as JSON with metadata."""
    envelope = {
        "data": data,
        "metadata": {
            "source": "Charity Commission for England and Wales",
            "licence": "Open Government Licence v3",
            "retrieved_at": datetime.now(
                tz=timezone.utc,
            ).isoformat(),
            "endpoint": endpoint,
            "cached": cached,
            "attribution": _ATTRIBUTION,
        },
    }
    return json.dumps(envelope, indent=2, default=str)


def _format_error(error: CharityError) -> str:
    """Format an API error as a JSON string."""
    result: dict[str, Any] = {
        "error": _error_type(error),
        "message": str(error),
        "attribution": _ATTRIBUTION,
    }
    if error.status_code:
        result["status_code"] = error.status_code
    return json.dumps(result)


def _error_type(error: CharityError) -> str:
    """Map exception class to error type string."""
    if isinstance(error, NotFoundError):
        return "not_found"
    if isinstance(error, BadRequestError):
        return "bad_request"
    if isinstance(error, RateLimitError):
        return "rate_limited"
    if isinstance(error, AuthenticationError):
        return "auth_error"
    if isinstance(error, ServerError):
        return "server_error"
    return "error"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record(
    tool_name: str,
    start: float,
    *,
    success: bool,
    error: Exception | None = None,
) -> None:
    """Record a tool call metric."""
    duration_ms = (time.monotonic() - start) * 1000
    _get_metrics().record_call(
        tool_name,
        duration_ms,
        success=success,
        error_type=type(error).__name__ if error else None,
        error_message=str(error)[:500] if error else None,
    )


# ---------------------------------------------------------------------------
# Valid list types for sector top 10
# ---------------------------------------------------------------------------

_VALID_TOP10_TYPES = {
    "employees",
    "expenditure",
    "expenditure charitable activities",
    "expenditure growth",
    "income",
    "income growth",
    "investment gains",
    "investments",
    "overdue",
    "volunteers",
}


# ---------------------------------------------------------------------------
# Tools — Search (4)
# ---------------------------------------------------------------------------


@server.tool()
async def uk_charity_search(query: str) -> str:
    """Search for charities by name.

    Search by charity name or partial name. Returns matching
    charities with registration details and status.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    if not query or not query.strip():
        return json.dumps({
            "error": "bad_request",
            "message": "Search query is required.",
            "attribution": _ATTRIBUTION,
        })
    start = time.monotonic()
    try:
        raw, cached = _get_client().search(query.strip())
        cleaned = clean_search_results(raw)
        _record("uk_charity_search", start, success=True)
        return _format_response(
            cleaned,
            endpoint=f"searchCharityName/{query.strip()}",
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_search", start, success=False, error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_lookup(
    charity_number: str, suffix: int = 0,
) -> str:
    """Look up a specific charity by registered number.

    Fast, lightweight lookup returning core details only. Use
    uk_charity_profile for comprehensive details including
    trustees and classifications.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().lookup(num, suffix)
        cleaned = clean_lookup(raw)
        _record("uk_charity_lookup", start, success=True)
        return _format_response(
            cleaned,
            endpoint=f"charityRegNumber/{num}/{suffix}",
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_lookup", start, success=False, error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_search_by_registration_date(
    start_date: str, end_date: str,
) -> str:
    """Find charities registered within a date range.

    Both dates must be in YYYY-MM-DD format. start_date must be
    before end_date.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        sd = validate_date(start_date, "start_date")
        ed = validate_date(end_date, "end_date")
        if sd > ed:
            return json.dumps({
                "error": "bad_request",
                "message": "start_date must be before end_date.",
                "attribution": _ATTRIBUTION,
            })
        raw, cached = _get_client().search_by_registration_date(
            sd, ed,
        )
        cleaned = clean_search_results(raw)
        _record(
            "uk_charity_search_by_registration_date",
            start,
            success=True,
        )
        return _format_response(
            cleaned,
            endpoint=f"searchCharityRegDate/{sd}/{ed}",
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_search_by_registration_date",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_search_by_removal_date(
    start_date: str, end_date: str,
) -> str:
    """Find charities removed within a date range.

    Both dates must be in YYYY-MM-DD format. start_date must be
    before end_date.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        sd = validate_date(start_date, "start_date")
        ed = validate_date(end_date, "end_date")
        if sd > ed:
            return json.dumps({
                "error": "bad_request",
                "message": "start_date must be before end_date.",
                "attribution": _ATTRIBUTION,
            })
        raw, cached = _get_client().search_by_removal_date(
            sd, ed,
        )
        cleaned = clean_search_results(raw)
        _record(
            "uk_charity_search_by_removal_date",
            start,
            success=True,
        )
        return _format_response(
            cleaned,
            endpoint=f"searchCharityRemDate/{sd}/{ed}",
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_search_by_removal_date",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


# ---------------------------------------------------------------------------
# Tools — Overview (3)
# ---------------------------------------------------------------------------


@server.tool()
async def uk_charity_profile(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get comprehensive details for a charity.

    The primary detail tool. Includes trustees, classifications,
    areas of operation, contact, and financial summary in one call.
    Use uk_charity_details for a lightweight alternative.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().profile(num, suffix)
        cleaned = clean_profile(raw)
        _record("uk_charity_profile", start, success=True)
        return _format_response(
            cleaned,
            endpoint=(
                f"allcharitydetailsV2/{num}/{suffix}"
            ),
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_profile", start, success=False, error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_details(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get core details for a charity without nested data.

    Lighter weight than uk_charity_profile. Returns status, dates,
    address, contact, income/expenditure, and flags without
    trustees, classifications, or areas.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().details(num, suffix)
        cleaned = clean_details(raw)
        _record("uk_charity_details", start, success=True)
        return _format_response(
            cleaned,
            endpoint=f"charitydetails/{num}/{suffix}",
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_details", start, success=False, error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_batch_lookup(charity_numbers: str) -> str:
    """Fetch details for multiple charities in a single call.

    Provide a comma-separated list of charity numbers (max 20).
    Tracks which numbers were found and which were not.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        if not charity_numbers or not charity_numbers.strip():
            return json.dumps({
                "error": "bad_request",
                "message": (
                    "At least one charity number is required."
                ),
                "attribution": _ATTRIBUTION,
            })
        parts = [
            p.strip()
            for p in charity_numbers.split(",")
            if p.strip()
        ]
        if len(parts) > 20:
            return json.dumps({
                "error": "bad_request",
                "message": (
                    "Maximum 20 charity numbers per request."
                ),
                "attribution": _ATTRIBUTION,
            })
        nums = []
        seen: set[int] = set()
        for p in parts:
            num = validate_charity_number(p)
            if num not in seen:
                nums.append(num)
                seen.add(num)
        joined = ",".join(str(n) for n in nums)
        raw, cached = _get_client().batch_lookup(joined)
        cleaned = clean_batch_lookup(raw, nums)
        _record(
            "uk_charity_batch_lookup", start, success=True,
        )
        return _format_response(
            cleaned,
            endpoint=f"charitydetailsmulti/{joined}",
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_batch_lookup",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


# ---------------------------------------------------------------------------
# Tools — Information (9)
# ---------------------------------------------------------------------------


@server.tool()
async def uk_charity_trustees(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get detailed trustee information with appointment dates.

    Includes chair identification, appointment dates, and
    cross-references to other charities each trustee is involved
    with.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().trustees(num, suffix)
        cleaned = clean_trustees(raw)
        _record("uk_charity_trustees", start, success=True)
        return _format_response(
            cleaned,
            endpoint=(
                f"charitytrusteeinformationV2/{num}/{suffix}"
            ),
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_trustees",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_trustee_names(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get lightweight trustee name list.

    Faster than uk_charity_trustees when only names are needed.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().trustee_names(num, suffix)
        cleaned = clean_trustee_names(raw)
        _record(
            "uk_charity_trustee_names", start, success=True,
        )
        return _format_response(
            cleaned,
            endpoint=(
                f"charitytrusteenamesV2/{num}/{suffix}"
            ),
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_trustee_names",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_classifications(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get What/Who/How classification details for a charity.

    Classifications are grouped into three categories:
    What (100-series), Who (200-series), How (300-series).
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().classifications(
            num, suffix,
        )
        cleaned = clean_classifications(raw)
        _record(
            "uk_charity_classifications", start, success=True,
        )
        return _format_response(
            cleaned,
            endpoint=f"charitywhowhathow/{num}/{suffix}",
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_classifications",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_areas_of_operation(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get all geographic areas where a charity operates.

    Combines three API endpoints to return countries (with
    continents), regions, and local authorities (with metropolitan
    county and Welsh indicator).
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        client = _get_client()
        countries, c1 = client.areas_of_operation_countries(
            num, suffix,
        )
        regions, c2 = client.areas_of_operation_regions(
            num, suffix,
        )
        local_authorities, c3 = (
            client.areas_of_operation_local_authorities(
                num, suffix,
            )
        )
        cleaned = clean_areas_of_operation(
            countries, regions, local_authorities,
        )
        _record(
            "uk_charity_areas_of_operation",
            start,
            success=True,
        )
        return _format_response(
            cleaned,
            endpoint=(
                f"CharityAoOCountryContinent+"
                f"charityaooregion+"
                f"charityaoolocalauthority"
                f"/{num}/{suffix}"
            ),
            cached=c1 and c2 and c3,
        )
    except CharityError as e:
        _record(
            "uk_charity_areas_of_operation",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_contact(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get contact details for a charity.

    Returns address, phone, email, and website.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().contact(num, suffix)
        cleaned = clean_contact(raw)
        _record("uk_charity_contact", start, success=True)
        return _format_response(
            cleaned,
            endpoint=(
                f"charitycontactinformation/{num}/{suffix}"
            ),
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_contact",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_constituency(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get the parliamentary constituency of a charity.

    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().constituency(num, suffix)
        cleaned = clean_constituency(raw)
        _record(
            "uk_charity_constituency", start, success=True,
        )
        return _format_response(
            cleaned,
            endpoint=(
                f"charityconstituency/{num}/{suffix}"
            ),
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_constituency",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_policies(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get governance policies the charity has declared.

    Returns declared policies such as complaints handling, risk
    management, safeguarding, and investment policies.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().policies(num, suffix)
        cleaned = clean_policies(raw)
        _record("uk_charity_policies", start, success=True)
        return _format_response(
            cleaned,
            endpoint=(
                f"charitypolicyinformation/{num}/{suffix}"
            ),
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_policies",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_other_regulators(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get other regulatory bodies that oversee this charity.

    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().other_regulators(
            num, suffix,
        )
        cleaned = clean_other_regulators(raw)
        _record(
            "uk_charity_other_regulators",
            start,
            success=True,
        )
        return _format_response(
            cleaned,
            endpoint=(
                f"CharityOtherRegulators/{num}/{suffix}"
            ),
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_other_regulators",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_primary_grants(
    charity_number: str, suffix: int = 0,
) -> str:
    """Check whether a charity's primary purpose is grant-making.

    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().primary_grants(
            num, suffix,
        )
        cleaned = clean_primary_grants(raw)
        _record(
            "uk_charity_primary_grants", start, success=True,
        )
        return _format_response(
            cleaned,
            endpoint=f"checkprimarygrants/{num}/{suffix}",
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_primary_grants",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


# ---------------------------------------------------------------------------
# Tools — Financial (4)
# ---------------------------------------------------------------------------


@server.tool()
async def uk_charity_financial_history(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get 5-year financial history with income breakdown.

    Includes year-on-year trend calculations and government
    funding flagging.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().financial_history(
            num, suffix,
        )
        cleaned = clean_financial_history(raw)
        _record(
            "uk_charity_financial_history",
            start,
            success=True,
        )
        return _format_response(
            cleaned,
            endpoint=(
                f"charityfinancialhistory/{num}/{suffix}"
            ),
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_financial_history",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_annual_return(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get the most recent Annual Return overview.

    Includes activities, staffing, pay bands, trustee benefits,
    and financials.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().annual_return(
            num, suffix,
        )
        cleaned = clean_annual_return(raw)
        _record(
            "uk_charity_annual_return", start, success=True,
        )
        return _format_response(
            cleaned,
            endpoint=f"charityoverview/{num}/{suffix}",
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_annual_return",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_accounts(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get accounts and Annual Return submission history.

    Includes overdue flagging, qualified accounts detection, and
    suppression tracking.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().accounts(num, suffix)
        cleaned = clean_accounts(raw)
        _record(
            "uk_charity_accounts", start, success=True,
        )
        return _format_response(
            cleaned,
            endpoint=f"charityaraccounts/{num}/{suffix}",
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_accounts",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_assets(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get most recent assets and liabilities balance sheet.

    Includes net assets calculation from component values.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().assets(num, suffix)
        cleaned = clean_assets(raw)
        _record("uk_charity_assets", start, success=True)
        return _format_response(
            cleaned,
            endpoint=(
                f"charityassetsliabilities/{num}/{suffix}"
            ),
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_assets",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


# ---------------------------------------------------------------------------
# Tools — Governance (5)
# ---------------------------------------------------------------------------


@server.tool()
async def uk_charity_governing_document(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get governing document details and charitable objects.

    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().governing_document(
            num, suffix,
        )
        cleaned = clean_governing_document(raw)
        _record(
            "uk_charity_governing_document",
            start,
            success=True,
        )
        return _format_response(
            cleaned,
            endpoint=(
                f"charitygoverningdocument/{num}/{suffix}"
            ),
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_governing_document",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_governance(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get governance summary.

    Charity type, Companies House link, gift aid, land ownership.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().governance(num, suffix)
        cleaned = clean_governance(raw)
        _record(
            "uk_charity_governance", start, success=True,
        )
        return _format_response(
            cleaned,
            endpoint=(
                f"charitygovernanceinformation/{num}/{suffix}"
            ),
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_governance",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_linked_charities(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get all linked/subsidiary charities.

    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().linked_charities(
            num, suffix,
        )
        cleaned = clean_linked_charities(raw)
        _record(
            "uk_charity_linked_charities",
            start,
            success=True,
        )
        return _format_response(
            cleaned,
            endpoint=f"linkedcharities/{num}/{suffix}",
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_linked_charities",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_other_names(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get working names and historical names for a charity.

    Names are categorised into working names and previous names.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().other_names(num, suffix)
        cleaned = clean_other_names(raw)
        _record(
            "uk_charity_other_names", start, success=True,
        )
        return _format_response(
            cleaned,
            endpoint=f"charityothernames/{num}/{suffix}",
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_other_names",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_registration_history(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get the registration event history for a charity.

    Events sorted chronologically with type labelling
    (registration vs asset transfer).
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().registration_history(
            num, suffix,
        )
        cleaned = clean_registration_history(raw)
        _record(
            "uk_charity_registration_history",
            start,
            success=True,
        )
        return _format_response(
            cleaned,
            endpoint=(
                f"charityregistrationhistory/{num}/{suffix}"
            ),
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_registration_history",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


# ---------------------------------------------------------------------------
# Tools — Regulatory (2)
# ---------------------------------------------------------------------------


@server.tool()
async def uk_charity_regulatory_reports(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get published regulatory reports.

    Inquiry reports, warnings, orders, schemes.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().regulatory_reports(
            num, suffix,
        )
        cleaned = clean_regulatory_reports(raw)
        _record(
            "uk_charity_regulatory_reports",
            start,
            success=True,
        )
        return _format_response(
            cleaned,
            endpoint=(
                f"charityregulatoryreport/{num}/{suffix}"
            ),
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_regulatory_reports",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_cio_dissolution(
    charity_number: str, suffix: int = 0,
) -> str:
    """Get CIO dissolution notice details.

    For Charitable Incorporated Organisations.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        num = validate_charity_number(charity_number)
        raw, cached = _get_client().cio_dissolution(
            num, suffix,
        )
        cleaned = clean_cio_dissolution(raw)
        _record(
            "uk_charity_cio_dissolution", start, success=True,
        )
        return _format_response(
            cleaned,
            endpoint=f"ciodissolution/{num}/{suffix}",
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_cio_dissolution",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


# ---------------------------------------------------------------------------
# Tools — Sector (4)
# ---------------------------------------------------------------------------


@server.tool()
async def uk_charity_sector_overview() -> str:
    """Get overall charity sector statistics.

    Total charities, aggregate income/expenditure, staffing
    numbers.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        raw, cached = _get_client().sector_overview()
        cleaned = clean_sector_overview(raw)
        _record(
            "uk_charity_sector_overview", start, success=True,
        )
        return _format_response(
            cleaned,
            endpoint="sectoroverview",
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_sector_overview",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_sector_top10(list_type: str) -> str:
    """Get top 10 charities ranked by a specified metric.

    Valid list_type values: Employees, Expenditure, Expenditure
    charitable activities, Expenditure growth, Income, Income
    growth, Investment gains, Investments, Overdue, Volunteers.
    Data source: Charity Commission for England and Wales (OGL v3).
    """
    if not list_type or not list_type.strip():
        return json.dumps({
            "error": "bad_request",
            "message": "list_type is required.",
            "attribution": _ATTRIBUTION,
        })
    normalised = list_type.strip().lower()
    if normalised not in _VALID_TOP10_TYPES:
        return json.dumps({
            "error": "bad_request",
            "message": (
                f"Invalid list_type: '{list_type}'. "
                f"Valid values: "
                + ", ".join(sorted(_VALID_TOP10_TYPES))
            ),
            "attribution": _ATTRIBUTION,
        })
    start = time.monotonic()
    try:
        raw, cached = _get_client().sector_top10(
            list_type.strip(),
        )
        cleaned = clean_sector_top10(raw)
        _record(
            "uk_charity_sector_top10", start, success=True,
        )
        return _format_response(
            cleaned,
            endpoint=(
                f"sectordatatop10/{list_type.strip()}"
            ),
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_sector_top10",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_sector_income_bands() -> str:
    """Get charity sector data broken down by income bands.

    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        raw, cached = _get_client().sector_income_bands()
        cleaned = clean_sector_income_bands(raw)
        _record(
            "uk_charity_sector_income_bands",
            start,
            success=True,
        )
        return _format_response(
            cleaned,
            endpoint="sectorincomeband",
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_sector_income_bands",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


@server.tool()
async def uk_charity_sector_income_categories() -> str:
    """Get charity sector data broken down by income category.

    Data source: Charity Commission for England and Wales (OGL v3).
    """
    start = time.monotonic()
    try:
        raw, cached = _get_client().sector_income_categories()
        cleaned = clean_sector_income_categories(raw)
        _record(
            "uk_charity_sector_income_categories",
            start,
            success=True,
        )
        return _format_response(
            cleaned,
            endpoint="sectorincomecategory",
            cached=cached,
        )
    except CharityError as e:
        _record(
            "uk_charity_sector_income_categories",
            start,
            success=False,
            error=e,
        )
        return _format_error(e)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Run the MCP server."""
    server.run()
