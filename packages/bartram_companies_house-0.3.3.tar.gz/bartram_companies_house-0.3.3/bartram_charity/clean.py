"""Charity Commission data cleaning logic.

Charity-specific cleaning for all 31 tools:
- Status code mapping (R → Registered, RM → Removed)
- Date normalisation (various formats → ISO 8601)
- Name normalisation (trustee names, charity names)
- Address normalisation and postcode formatting
- Classification grouping (What/Who/How by code range)
- Financial structuring and trend calculation
- Text cleaning (collapse whitespace, trim)
- Null/empty field guarding (FCA lesson)
- Data quality annotations (_cleaning)
"""

from __future__ import annotations

import re
from datetime import date
from typing import Any

from bartram_foundry.cleaning import (
    normalise_address_line,
    normalise_name,
    normalise_postcode,
)

# ---------------------------------------------------------------------------
# Status code mapping
# ---------------------------------------------------------------------------

_STATUS_MAP: dict[str, str] = {
    "R": "Registered",
    "RM": "Removed",
}

_REMOVAL_REASONS: dict[str, str] = {
    "1": "Voluntary removal",
    "2": "Failure to submit accounts/annual return",
    "3": "Ceased to exist",
    "4": "Does not operate",
    "5": "Registered in error",
    "6": "Transferred to other charity",
    "7": "Other reason",
}


def map_status(raw: Any) -> tuple[str | None, bool]:
    """Map status code to human-readable label."""
    if not raw or not isinstance(raw, str):
        return raw, False
    mapped = _STATUS_MAP.get(raw.strip())
    if mapped:
        return mapped, True
    return raw, False


# ---------------------------------------------------------------------------
# Date normalisation
# ---------------------------------------------------------------------------

_ISO_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_UK_DATE = re.compile(r"^(\d{2})/(\d{2})/(\d{4})$")
_UK_DATETIME = re.compile(r"^(\d{2})/(\d{2})/(\d{4})\s+(\d{2}):(\d{2})$")


def normalise_date(value: Any) -> tuple[str | None, bool]:
    """Normalise a date value to ISO 8601. Returns (result, changed)."""
    if not value or not isinstance(value, str):
        return value, False
    stripped = value.strip()
    if _ISO_DATE.match(stripped):
        return stripped, False
    match = _UK_DATETIME.match(stripped)
    if match:
        day, month, year, hour, minute = match.groups()
        return f"{year}-{month}-{day}T{hour}:{minute}:00", True
    match = _UK_DATE.match(stripped)
    if match:
        day, month, year = match.groups()
        return f"{year}-{month}-{day}", True
    return value, False



# ---------------------------------------------------------------------------
# Text cleaning
# ---------------------------------------------------------------------------

_MULTI_WHITESPACE = re.compile(r"[ \t]+")
_MULTI_NEWLINE = re.compile(r"\n{3,}")


def clean_text(value: Any) -> tuple[str | None, bool]:
    """Clean text: trim, collapse whitespace and newlines."""
    if not value or not isinstance(value, str):
        return value, False
    original = value
    cleaned = value.strip()
    cleaned = _MULTI_WHITESPACE.sub(" ", cleaned)
    cleaned = _MULTI_NEWLINE.sub("\n\n", cleaned)
    return cleaned, cleaned != original


# ---------------------------------------------------------------------------
# URL normalisation
# ---------------------------------------------------------------------------


def normalise_url(value: Any) -> tuple[str | None, bool]:
    """Ensure URL has a protocol prefix."""
    if not value or not isinstance(value, str):
        return value, False
    stripped = value.strip()
    if not stripped:
        return None, False
    if stripped.startswith(("http://", "https://")):
        return stripped, False
    return f"https://{stripped}", True


# ---------------------------------------------------------------------------
# Companies House cross-reference
# ---------------------------------------------------------------------------


def make_ch_cross_ref(company_number: Any) -> dict[str, str] | None:
    """Build Companies House cross-reference if valid."""
    if not company_number:
        return None
    num_str = str(company_number).strip()
    if not num_str or num_str == "0":
        return None
    padded = num_str.zfill(8)
    return {
        "company_number": padded,
        "tool": "uk_companies_house_profile",
    }


# ---------------------------------------------------------------------------
# Classification grouping
# ---------------------------------------------------------------------------


def group_classifications(
    items: Any,
) -> tuple[dict[str, list[dict]], bool]:
    """Group classification items into what/who/how by code range."""
    result: dict[str, list[dict]] = {"what": [], "who": [], "how": []}
    if not items or not isinstance(items, list):
        return result, False
    for item in items:
        if not isinstance(item, dict):
            continue
        code = item.get("classification_code") or item.get("code")
        desc = (
            item.get("classification_description")
            or item.get("classification_desc")
            or item.get("description", "")
        )
        if code is None:
            continue
        try:
            code_int = int(code)
        except (ValueError, TypeError):
            continue
        entry = {"code": code_int, "description": desc}
        if 100 <= code_int < 200:
            result["what"].append(entry)
        elif 200 <= code_int < 300:
            result["who"].append(entry)
        elif 300 <= code_int < 400:
            result["how"].append(entry)
    return result, True


# ---------------------------------------------------------------------------
# Safe field access (null/missing guard)
# ---------------------------------------------------------------------------


def safe_get(data: Any, key: str, default: Any = None) -> Any:
    """Safely get a field from a dict, handling null data."""
    if not data or not isinstance(data, dict):
        return default
    return data.get(key, default)


def _get_first(data: dict, *keys: str, default: Any = None) -> Any:
    """Return the first non-None value from multiple keys."""
    for key in keys:
        val = data.get(key)
        if val is not None:
            return val
    return default


def safe_list(data: Any) -> list:
    """Ensure a value is a list, handling null/missing."""
    if data is None:
        return []
    if isinstance(data, list):
        return data
    return []


# ---------------------------------------------------------------------------
# Address building helper
# ---------------------------------------------------------------------------


def _build_address(data: dict, annotations: dict) -> dict:
    """Extract and normalise address fields."""
    raw_lines = [
        data.get("address_line_one"),
        data.get("address_line_two"),
        data.get("address_line_three"),
        data.get("address_line_four"),
        data.get("address_line_five"),
    ]
    lines = {}
    any_changed = False
    for i, raw in enumerate(raw_lines, 1):
        if raw and isinstance(raw, str) and raw.strip():
            normalised = normalise_address_line(raw)
            if normalised != raw.strip():
                any_changed = True
            lines[f"line_{i}"] = normalised
        else:
            lines[f"line_{i}"] = None

    raw_pc = data.get("address_post_code")
    if raw_pc and isinstance(raw_pc, str) and raw_pc.strip():
        normalised_pc = normalise_postcode(raw_pc)
        if normalised_pc != raw_pc.strip():
            annotations["postcode_formatted"] = True
        lines["postcode"] = normalised_pc
    else:
        lines["postcode"] = None

    if any_changed:
        annotations["address_normalised"] = True
    return lines


# ---------------------------------------------------------------------------
# Flag labelling helper
# ---------------------------------------------------------------------------


def _build_flags(data: dict, annotations: dict) -> dict:
    """Extract and label boolean flags."""
    flags = {
        "insolvent": safe_get(data, "insolvent", False),
        "in_administration": safe_get(
            data, "in_administration", False,
        ),
        "cio": safe_get(data, "cio_ind", False),
        "cio_dissolution": safe_get(
            data, "cio_dissolution_ind", False,
        ),
        "interim_manager": safe_get(
            data, "interim_manager_ind", False,
        ),
        "previously_excepted": _get_first(
            data,
            "previously_excepted",
            "prev_excepted_ind",
            default=False,
        ),
        "cif_cdf": _get_first(data, "cif_cdf", "cif_cdf_ind"),
    }
    annotations["flags_labelled"] = True
    return flags


# ---------------------------------------------------------------------------
# Per-tool clean functions
# ---------------------------------------------------------------------------


def clean_search_results(data: Any) -> dict[str, Any]:
    """Clean search results (search, date search)."""
    items_raw = safe_list(data)
    annotations: dict[str, Any] = {}
    items = []
    for item in items_raw:
        if not isinstance(item, dict):
            continue
        row: dict[str, Any] = {
            "charity_number": _get_first(
                item,
                "registered_charity_number",
                "reg_charity_number",
            ),
            "charity_name": safe_get(item, "charity_name"),
        }
        # Status mapping
        status, mapped = map_status(safe_get(item, "reg_status"))
        row["status"] = status
        row["status_code"] = safe_get(item, "reg_status")
        if mapped:
            annotations["status_mapped"] = True

        # Name normalisation
        name = row["charity_name"]
        if name and isinstance(name, str):
            trimmed = name.strip()
            if trimmed != name:
                annotations["name_normalised"] = True
            row["charity_name"] = trimmed

        # Dates
        for dk in ("date_of_registration", "date_of_removal"):
            val = safe_get(item, dk)
            if val is not None:
                nd, changed = normalise_date(val)
                row[dk] = nd
                if changed:
                    annotations["dates_normalised"] = True
            else:
                row[dk] = None

        row["suffix"] = _get_first(
            item, "suffix", "group_subsid_suffix", default=0,
        )
        row["_cleaning"] = dict(annotations)
        items.append(row)

    return {
        "total_results": len(items),
        "items": items,
        "_cleaning": annotations,
    }


def clean_lookup(data: Any) -> dict[str, Any]:
    """Clean lookup result."""
    if not data or not isinstance(data, dict):
        return {"_cleaning": {}}
    annotations: dict[str, Any] = {}

    status, mapped = map_status(safe_get(data, "reg_status"))
    if mapped:
        annotations["status_mapped"] = True

    result: dict[str, Any] = {
        "charity_number": _get_first(
            data,
            "registered_charity_number",
            "reg_charity_number",
        ),
        "charity_name": safe_get(data, "charity_name"),
        "status": status,
        "date_of_registration": None,
        "date_of_removal": None,
        "suffix": _get_first(
            data, "suffix", "group_subsid_suffix", default=0,
        ),
        "_cleaning": annotations,
    }
    for dk in ("date_of_registration", "date_of_removal"):
        val = safe_get(data, dk)
        if val is not None:
            nd, changed = normalise_date(val)
            result[dk] = nd
            if changed:
                annotations["dates_normalised"] = True

    return result


def clean_profile(data: Any) -> dict[str, Any]:
    """Clean comprehensive profile result (V2)."""
    if not data or not isinstance(data, dict):
        return {"_cleaning": {}}
    annotations: dict[str, Any] = {}

    # Status
    status, mapped = map_status(safe_get(data, "reg_status"))
    if mapped:
        annotations["status_mapped"] = True

    # Charity type
    charity_type = safe_get(data, "charity_type")
    if charity_type:
        annotations["charity_type_normalised"] = True

    # Address
    address = _build_address(data, annotations)

    # Contact
    contact: dict[str, Any] = {
        "phone": safe_get(data, "phone"),
        "email": safe_get(data, "email"),
    }
    web_raw = safe_get(data, "web")
    web, _url_changed = normalise_url(web_raw)
    contact["web"] = web

    # Flags
    flags = _build_flags(data, annotations)

    # CH cross-ref
    ch_ref = make_ch_cross_ref(safe_get(data, "charity_co_reg_number"))
    if ch_ref:
        annotations["companies_house_linked"] = True

    # Trustees
    raw_trustees = safe_list(safe_get(data, "trustee_names"))
    trustees = []
    for t in raw_trustees:
        if not isinstance(t, dict):
            continue
        raw_name = (
            safe_get(t, "trustee_name")
            or safe_get(t, "name", "")
        )
        normalised = normalise_name(raw_name) if raw_name else ""
        if normalised != raw_name:
            annotations["trustee_names_normalised"] = True
        trustees.append({
            "name": normalised or raw_name,
            "organisation_number": safe_get(t, "organisation_number"),
        })

    # Classifications
    raw_class = safe_list(safe_get(data, "who_what_where"))
    classifications, _ = group_classifications(raw_class)
    if raw_class:
        annotations["classifications_structured"] = True

    # Removal reason
    removal_reason = None
    if status == "Removed":
        raw_reason = safe_get(data, "removal_reason")
        if raw_reason:
            removal_reason = _REMOVAL_REASONS.get(
                str(raw_reason), str(raw_reason)
            )
            annotations["removal_reason_interpreted"] = True

    # Dates
    date_fields: dict[str, Any] = {}
    for dk in ("date_of_registration", "date_of_removal"):
        val = safe_get(data, dk)
        if val:
            nd, changed = normalise_date(val)
            date_fields[dk] = nd
            if changed:
                annotations["dates_normalised"] = True
        else:
            date_fields[dk] = None

    # Accounts period (API uses latest_acc_fin_year_*)
    acc_start = _get_first(
        data,
        "latest_acc_fin_period_start_date",
        "latest_acc_fin_year_start_date",
    )
    acc_end = _get_first(
        data,
        "latest_acc_fin_period_end_date",
        "latest_acc_fin_year_end_date",
    )
    if acc_start:
        acc_start, ch = normalise_date(acc_start)
        if ch:
            annotations["dates_normalised"] = True
    if acc_end:
        acc_end, ch = normalise_date(acc_end)
        if ch:
            annotations["dates_normalised"] = True

    # Related endpoints
    annotations["related_endpoints_added"] = True

    result: dict[str, Any] = {
        "charity_number": _get_first(
            data,
            "registered_charity_number",
            "reg_charity_number",
        ),
        "charity_name": safe_get(data, "charity_name"),
        "status": status,
        "charity_type": charity_type,
        "date_of_registration": date_fields.get("date_of_registration"),
        "date_of_removal": date_fields.get("date_of_removal"),
        "removal_reason": removal_reason,
        "address": address,
        "contact": contact,
        "latest_income": safe_get(data, "latest_income"),
        "latest_expenditure": safe_get(data, "latest_expenditure"),
        "latest_accounts_period": {
            "start": acc_start,
            "end": acc_end,
        },
        "flags": flags,
        "companies_house_cross_ref": ch_ref,
        "trustees": trustees,
        "classifications": classifications,
        "other_names": safe_list(safe_get(data, "other_names")),
        "constituency": _get_first(
            data, "constituency", "constituency_name",
        ),
        "reporting_status": safe_get(data, "reporting_status"),
        "last_modified": _get_first(
            data, "last_modified", "last_modified_time",
        ),
        "related_endpoints": {
            "trustees": "uk_charity_trustees",
            "trustee_names": "uk_charity_trustee_names",
            "financial_history": "uk_charity_financial_history",
            "annual_return": "uk_charity_annual_return",
            "accounts": "uk_charity_accounts",
            "assets": "uk_charity_assets",
            "governing_document": "uk_charity_governing_document",
            "governance": "uk_charity_governance",
            "linked_charities": "uk_charity_linked_charities",
            "registration_history": "uk_charity_registration_history",
            "regulatory_reports": "uk_charity_regulatory_reports",
            "cio_dissolution": "uk_charity_cio_dissolution",
            "classifications": "uk_charity_classifications",
            "areas_of_operation": "uk_charity_areas_of_operation",
            "contact": "uk_charity_contact",
            "constituency": "uk_charity_constituency",
            "policies": "uk_charity_policies",
            "primary_grants": "uk_charity_primary_grants",
            "other_names": "uk_charity_other_names",
            "other_regulators": "uk_charity_other_regulators",
        },
        "_cleaning": annotations,
    }
    return result


def clean_details(data: Any) -> dict[str, Any]:
    """Clean details result (lighter than profile)."""
    if not data or not isinstance(data, dict):
        return {"_cleaning": {}}
    annotations: dict[str, Any] = {}

    status, mapped = map_status(safe_get(data, "reg_status"))
    if mapped:
        annotations["status_mapped"] = True

    charity_type = safe_get(data, "charity_type")
    if charity_type:
        annotations["charity_type_normalised"] = True

    address = _build_address(data, annotations)
    flags = _build_flags(data, annotations)

    ch_ref = make_ch_cross_ref(safe_get(data, "charity_co_reg_number"))
    if ch_ref:
        annotations["companies_house_linked"] = True

    contact: dict[str, Any] = {
        "phone": safe_get(data, "phone"),
        "email": safe_get(data, "email"),
    }
    web_raw = safe_get(data, "web")
    web, _ = normalise_url(web_raw)
    contact["web"] = web

    date_fields: dict[str, Any] = {}
    for dk in ("date_of_registration", "date_of_removal"):
        val = safe_get(data, dk)
        if val:
            nd, changed = normalise_date(val)
            date_fields[dk] = nd
            if changed:
                annotations["dates_normalised"] = True
        else:
            date_fields[dk] = None

    acc_start = _get_first(
        data,
        "latest_acc_fin_period_start_date",
        "latest_acc_fin_year_start_date",
    )
    acc_end = _get_first(
        data,
        "latest_acc_fin_period_end_date",
        "latest_acc_fin_year_end_date",
    )
    if acc_start:
        acc_start, ch = normalise_date(acc_start)
        if ch:
            annotations["dates_normalised"] = True
    if acc_end:
        acc_end, ch = normalise_date(acc_end)
        if ch:
            annotations["dates_normalised"] = True

    removal_reason = None
    if status == "Removed":
        raw_reason = safe_get(data, "removal_reason")
        if raw_reason:
            removal_reason = _REMOVAL_REASONS.get(
                str(raw_reason), str(raw_reason)
            )

    return {
        "charity_number": _get_first(
            data,
            "registered_charity_number",
            "reg_charity_number",
        ),
        "charity_name": safe_get(data, "charity_name"),
        "status": status,
        "charity_type": charity_type,
        "date_of_registration": date_fields.get("date_of_registration"),
        "date_of_removal": date_fields.get("date_of_removal"),
        "removal_reason": removal_reason,
        "address": address,
        "contact": contact,
        "latest_income": safe_get(data, "latest_income"),
        "latest_expenditure": safe_get(data, "latest_expenditure"),
        "latest_accounts_period": {"start": acc_start, "end": acc_end},
        "flags": flags,
        "companies_house_cross_ref": ch_ref,
        "reporting_status": safe_get(data, "reporting_status"),
        "last_modified": _get_first(
            data, "last_modified", "last_modified_time",
        ),
        "_cleaning": annotations,
    }


def clean_batch_lookup(
    data: Any, requested_numbers: list[int]
) -> dict[str, Any]:
    """Clean batch lookup result."""
    annotations: dict[str, Any] = {}
    items_raw = safe_list(data)

    # Deduplicate requested
    seen_req = set(requested_numbers)
    if len(seen_req) < len(requested_numbers):
        annotations["input_deduplicated"] = True

    items = []
    found_numbers = set()
    for item in items_raw:
        cleaned = clean_details(item)
        num = _get_first(
            item,
            "registered_charity_number",
            "reg_charity_number",
        )
        if num is not None:
            found_numbers.add(int(num))
        items.append(cleaned)

    not_found = sorted(seen_req - found_numbers)
    if not_found:
        annotations["not_found_tracked"] = True

    return {
        "total_requested": len(seen_req),
        "total_found": len(items),
        "not_found": not_found,
        "items": items,
        "_cleaning": annotations,
    }


def clean_trustees(data: Any) -> dict[str, Any]:
    """Clean detailed trustee information."""
    annotations: dict[str, Any] = {}
    items_raw = safe_list(data)
    items = []
    chair_name = None

    for t in items_raw:
        if not isinstance(t, dict):
            continue
        raw_name = (
            safe_get(t, "trustee_name")
            or safe_get(t, "name", "")
        )
        normalised = normalise_name(raw_name) if raw_name else ""
        if normalised and normalised != raw_name:
            annotations["names_normalised"] = True

        is_chair = safe_get(t, "is_chair", False)
        if is_chair:
            chair_name = normalised or raw_name
            annotations["chair_identified"] = True

        # Appointment date
        appt_date = safe_get(t, "date_of_appointment")
        if appt_date:
            appt_date, changed = normalise_date(appt_date)
            if changed:
                annotations["dates_normalised"] = True

        # Linked charities
        raw_linked = safe_list(safe_get(t, "related_charities"))
        linked = []
        for lc in raw_linked:
            if isinstance(lc, dict):
                linked.append({
                    "charity_number": _get_first(
                        lc,
                        "registered_charity_number",
                        "reg_charity_number",
                    ),
                    "charity_name": safe_get(lc, "charity_name"),
                    "reporting_status": safe_get(
                        lc, "reporting_status"
                    ),
                })
        if linked:
            annotations["linked_charities_resolved"] = True

        items.append({
            "name": normalised or raw_name,
            "is_chair": is_chair,
            "date_of_appointment": appt_date,
            "linked_charities": linked,
            "_cleaning": {},
        })

    return {
        "charity_number": None,
        "total_trustees": len(items),
        "chair_name": chair_name,
        "items": items,
        "_cleaning": annotations,
    }


def clean_trustee_names(data: Any) -> dict[str, Any]:
    """Clean lightweight trustee name list."""
    annotations: dict[str, Any] = {}
    items_raw = safe_list(data)
    names = []
    for t in items_raw:
        if isinstance(t, dict):
            raw = (
                safe_get(t, "trustee_name")
                or safe_get(t, "name", "")
            )
        elif isinstance(t, str):
            raw = t
        else:
            continue
        normalised = normalise_name(raw) if raw else ""
        if normalised and normalised != raw:
            annotations["names_normalised"] = True
        names.append(normalised or raw)

    return {
        "charity_number": None,
        "total_trustees": len(names),
        "names": names,
        "_cleaning": annotations,
    }


def clean_classifications(data: Any) -> dict[str, Any]:
    """Clean What/Who/How classifications."""
    annotations: dict[str, Any] = {}
    items_raw = safe_list(data)
    grouped, did_group = group_classifications(items_raw)
    if did_group:
        annotations["classifications_grouped"] = True
    annotations["descriptions_verified"] = True

    return {
        "charity_number": None,
        **grouped,
        "_cleaning": annotations,
    }


def clean_areas_of_operation(
    countries: Any, regions: Any, local_authorities: Any
) -> dict[str, Any]:
    """Clean areas of operation (3 endpoints combined)."""
    annotations: dict[str, Any] = {"areas_grouped": True}

    # Countries with continents
    country_items = []
    for c in safe_list(countries):
        if isinstance(c, dict):
            country_items.append({
                "country": safe_get(c, "country"),
                "continent": safe_get(c, "continent"),
            })
    if country_items:
        annotations["continents_included"] = True

    # Regions
    region_items = []
    for r in safe_list(regions):
        if isinstance(r, dict):
            region_items.append(safe_get(r, "region", ""))
        elif isinstance(r, str):
            region_items.append(r)

    # Local authorities
    la_items = []
    for la in safe_list(local_authorities):
        if isinstance(la, dict):
            la_items.append({
                "name": (
                    safe_get(la, "local_authority")
                    or safe_get(la, "name")
                ),
                "metropolitan_county": safe_get(
                    la, "metropolitan_county"
                ),
                "welsh": safe_get(la, "welsh", False),
            })
    if la_items:
        annotations["local_authority_enriched"] = True

    return {
        "charity_number": None,
        "countries": country_items,
        "regions": region_items,
        "local_authorities": la_items,
        "_cleaning": annotations,
    }


def clean_contact(data: Any) -> dict[str, Any]:
    """Clean contact information."""
    if not data or not isinstance(data, dict):
        return {
            "charity_number": None,
            "contact_address": None,
            "phone": None,
            "email": None,
            "web": None,
            "_cleaning": {},
        }
    annotations: dict[str, Any] = {}

    # URL
    web, url_changed = normalise_url(safe_get(data, "web"))
    if url_changed:
        annotations["url_normalised"] = True

    # Phone
    phone = safe_get(data, "phone")
    if phone and isinstance(phone, str):
        cleaned_phone = re.sub(r"\s+", " ", phone.strip())
        if cleaned_phone != phone:
            annotations["phone_formatted"] = True
        phone = cleaned_phone

    # Email
    email = safe_get(data, "email")
    if email and isinstance(email, str):
        lower = email.strip().lower()
        if lower != email:
            annotations["email_normalised"] = True
        email = lower

    return {
        "charity_number": None,
        "contact_address": safe_get(data, "contact_address"),
        "phone": phone,
        "email": email,
        "web": web,
        "_cleaning": annotations,
    }


def clean_constituency(data: Any) -> dict[str, Any]:
    """Clean constituency data."""
    if not data or not isinstance(data, dict):
        return {
            "charity_number": None,
            "constituency_name": None,
            "_cleaning": {},
        }
    annotations: dict[str, Any] = {}
    name = safe_get(data, "constituency_name")
    if name and isinstance(name, str):
        trimmed = name.strip()
        if trimmed != name:
            annotations["name_normalised"] = True
        name = trimmed

    return {
        "charity_number": None,
        "constituency_name": name,
        "_cleaning": annotations,
    }


def clean_policies(data: Any) -> dict[str, Any]:
    """Clean governance policies."""
    annotations: dict[str, Any] = {}
    items_raw = safe_list(data)
    policies = []
    for p in items_raw:
        if isinstance(p, dict):
            policies.append(safe_get(p, "policy", ""))
        elif isinstance(p, str):
            policies.append(p)
    annotations["policies_categorised"] = True

    return {
        "charity_number": None,
        "total_policies": len(policies),
        "policies": policies,
        "_cleaning": annotations,
    }


def clean_other_regulators(data: Any) -> dict[str, Any]:
    """Clean other regulators data."""
    annotations: dict[str, Any] = {}
    items_raw = safe_list(data)
    regulators = []
    for r in items_raw:
        if not isinstance(r, dict):
            continue
        web, url_changed = normalise_url(safe_get(r, "website"))
        if url_changed:
            annotations["url_normalised"] = True
        regulators.append({
            "name": safe_get(r, "name"),
            "website": web,
        })

    return {
        "charity_number": None,
        "total_regulators": len(regulators),
        "regulators": regulators,
        "_cleaning": annotations,
    }


def clean_primary_grants(data: Any) -> dict[str, Any]:
    """Clean primary grants data."""
    if not data or not isinstance(data, dict):
        return {
            "charity_number": None,
            "primary_purpose_grant_making": None,
            "_cleaning": {},
        }
    return {
        "charity_number": None,
        "primary_purpose_grant_making": safe_get(
            data, "primary_purpose_grant_making"
        ),
        "_cleaning": {},
    }


def clean_financial_history(data: Any) -> dict[str, Any]:
    """Clean financial history with structuring and trends."""
    annotations: dict[str, Any] = {}
    items_raw = safe_list(data)
    periods = []

    for item in items_raw:
        if not isinstance(item, dict):
            continue
        period_end = safe_get(item, "financial_period_end_date")
        if period_end:
            period_end, changed = normalise_date(period_end)
            if changed:
                annotations["dates_normalised"] = True

        income = safe_get(item, "income", 0)
        expenditure = safe_get(item, "expenditure", 0)

        # Income breakdown
        income_breakdown = {
            "donations_and_legacies": safe_get(
                item, "income_donations_and_legacies", 0
            ),
            "trading_activities": safe_get(
                item, "income_trading_activities", 0
            ),
            "charitable_activities": safe_get(
                item, "income_charitable_activities", 0
            ),
            "endowments": safe_get(item, "income_endowments", 0),
            "legacies": safe_get(item, "income_legacies", 0),
            "investment": safe_get(item, "income_investment", 0),
            "other": safe_get(item, "income_other", 0),
            "total": income,
        }

        # Expenditure breakdown
        expenditure_breakdown = {
            "charitable_activities": safe_get(
                item, "expenditure_charitable_activities", 0
            ),
            "raising_funds": safe_get(
                item, "expenditure_raising_funds", 0
            ),
            "governance": safe_get(
                item, "expenditure_governance", 0
            ),
            "grants_to_institutions": safe_get(
                item, "expenditure_grants_institutions", 0
            ),
            "investment_management": safe_get(
                item, "expenditure_investment_management", 0
            ),
            "other": safe_get(item, "expenditure_other", 0),
            "total": expenditure,
        }

        # Government funding
        govt_contracts = safe_get(
            item, "income_from_govt_contracts", 0
        )
        govt_grants = safe_get(item, "income_from_govt_grants", 0)
        if (govt_contracts and govt_contracts > 0) or (
            govt_grants and govt_grants > 0
        ):
            annotations["government_funding_flagged"] = True

        periods.append({
            "ar_cycle": safe_get(item, "ar_cycle"),
            "period_end": period_end,
            "income": income,
            "expenditure": expenditure,
            "income_change_pct": None,
            "expenditure_change_pct": None,
            "income_breakdown": income_breakdown,
            "expenditure_breakdown": expenditure_breakdown,
            "government_funding": {
                "contracts": govt_contracts or 0,
                "grants": govt_grants or 0,
            },
            "consolidated_account": safe_get(
                item, "consolidated_account", False
            ),
            "_cleaning": {},
        })

    if periods:
        annotations["financials_structured"] = True

    # Sort chronologically
    periods.sort(key=lambda p: p.get("period_end") or "")
    if len(periods) > 1:
        annotations["sorted_chronologically"] = True

    # Calculate trends
    for i in range(1, len(periods)):
        prev_inc = periods[i - 1].get("income")
        curr_inc = periods[i].get("income")
        if (
            prev_inc is not None
            and curr_inc is not None
            and prev_inc != 0
        ):
            periods[i]["income_change_pct"] = round(
                ((curr_inc - prev_inc) / abs(prev_inc)) * 100, 1
            )
        prev_exp = periods[i - 1].get("expenditure")
        curr_exp = periods[i].get("expenditure")
        if (
            prev_exp is not None
            and curr_exp is not None
            and prev_exp != 0
        ):
            periods[i]["expenditure_change_pct"] = round(
                ((curr_exp - prev_exp) / abs(prev_exp)) * 100, 1
            )
    if len(periods) > 1:
        annotations["trends_calculated"] = True

    return {
        "charity_number": None,
        "periods": periods,
        "_cleaning": annotations,
    }


def clean_annual_return(data: Any) -> dict[str, Any]:
    """Clean annual return overview."""
    if not data or not isinstance(data, dict):
        return {"_cleaning": {}}
    annotations: dict[str, Any] = {}

    # Activities text
    activities = safe_get(data, "activities")
    if activities:
        activities, changed = clean_text(activities)
        if changed:
            annotations["activities_cleaned"] = True

    # Staffing
    employees = safe_get(data, "employees", 0) or 0
    volunteers = safe_get(data, "volunteers", 0) or 0
    annotations["staffing_summarised"] = True

    # Pay bands
    pay_bands = {
        "60001_70000": safe_get(data, "band_60001_70000", 0),
        "70001_80000": safe_get(data, "band_70001_80000", 0),
        "80001_90000": safe_get(data, "band_80001_90000", 0),
        "90001_100000": safe_get(data, "band_90001_100000", 0),
        "100001_150000": safe_get(data, "band_100001_150000", 0),
        "150001_200000": safe_get(data, "band_150001_200000", 0),
        "200001_250000": safe_get(data, "band_200001_250000", 0),
        "250001_300000": safe_get(data, "band_250001_300000", 0),
        "300001_500000": safe_get(data, "band_300001_500000", 0),
        "over_500000": safe_get(data, "band_over_500000", 0),
    }
    annotations["pay_bands_structured"] = True

    # Government funding
    govt_contracts = safe_get(data, "income_from_govt_contracts", 0)
    govt_grants = safe_get(data, "income_from_govt_grants", 0)
    annotations["government_funding_structured"] = True

    # Trustee benefits
    has_benefits = bool(
        safe_get(data, "trustee_benefits")
        or safe_get(data, "trustee_payments")
    )
    if has_benefits:
        annotations["trustee_benefits_flagged"] = True

    return {
        "charity_number": None,
        "activities": activities,
        "employees": employees,
        "volunteers": volunteers,
        "trustees": safe_get(data, "trustees", 0) or 0,
        "total_staff": employees + volunteers,
        "income": safe_get(data, "income", 0),
        "expenditure": safe_get(data, "expenditure", 0),
        "investment_gains_losses": safe_get(
            data, "investment_gains_losses", 0
        ),
        "pay_bands": pay_bands,
        "trustee_benefits": {
            "has_benefits": has_benefits,
            "details": safe_get(data, "trustee_benefits"),
        },
        "government_funding": {
            "contracts": govt_contracts or 0,
            "grants": govt_grants or 0,
        },
        "_cleaning": annotations,
    }


def clean_accounts(data: Any) -> dict[str, Any]:
    """Clean accounts and AR submission history."""
    annotations: dict[str, Any] = {}
    items_raw = safe_list(data)
    items = []
    overdue_count = 0
    qualified_count = 0
    today = date.today().isoformat()

    for item in items_raw:
        if not isinstance(item, dict):
            continue

        # Dates
        period_end = safe_get(item, "reporting_period_year_end")
        date_received = safe_get(item, "date_received")
        date_due = safe_get(item, "date_due")

        for dk, val in [
            ("period_end", period_end),
            ("date_received", date_received),
            ("date_due", date_due),
        ]:
            if val:
                nd, changed = normalise_date(val)
                if dk == "period_end":
                    period_end = nd
                elif dk == "date_received":
                    date_received = nd
                else:
                    date_due = nd
                if changed:
                    annotations["dates_normalised"] = True

        # Overdue check
        overdue = False
        if date_due and date_received is None and date_due < today:
            overdue = True
            overdue_count += 1
            annotations["overdue_flagged"] = True

        # Qualified
        qualified = safe_get(item, "accounts_qualified", False)
        if qualified:
            qualified_count += 1
            annotations["qualified_flagged"] = True

        # Suppression
        suppressed = safe_get(item, "suppression_ind", False)
        if suppressed:
            annotations["suppression_flagged"] = True

        items.append({
            "title": safe_get(item, "title"),
            "period_end": period_end,
            "date_received": date_received,
            "date_due": date_due,
            "document_name": safe_get(item, "document_name"),
            "accounts_qualified": qualified,
            "suppressed": suppressed,
            "suppression_type": safe_get(item, "suppression_type"),
            "overdue": overdue,
            "_cleaning": {},
        })

    return {
        "charity_number": None,
        "total_filings": len(items),
        "overdue_count": overdue_count,
        "qualified_count": qualified_count,
        "items": items,
        "_cleaning": annotations,
    }


def clean_assets(data: Any) -> dict[str, Any]:
    """Clean assets and liabilities balance sheet."""
    if not data or not isinstance(data, dict):
        return {"_cleaning": {}}
    annotations: dict[str, Any] = {"fields_normalised": True}

    period_end = safe_get(data, "fin_period_end_date")
    if period_end:
        period_end, changed = normalise_date(period_end)
        if changed:
            annotations["dates_normalised"] = True

    own_use = safe_get(data, "assets_own_use", 0) or 0
    long_term = safe_get(
        data, "assets_long_term_investment", 0
    ) or 0
    pension = safe_get(data, "defined_net_assets_pension", 0) or 0
    other = safe_get(data, "assets_other_assets", 0) or 0
    liabilities = safe_get(data, "assets_total_liabilities", 0) or 0
    net = own_use + long_term + pension + other - liabilities
    annotations["net_assets_calculated"] = True

    return {
        "charity_number": None,
        "period_end": period_end,
        "own_use_assets": own_use,
        "long_term_investments": long_term,
        "pension_assets": pension,
        "other_assets": other,
        "total_liabilities": liabilities,
        "net_assets": net,
        "_cleaning": annotations,
    }


def clean_governing_document(data: Any) -> dict[str, Any]:
    """Clean governing document data."""
    if not data or not isinstance(data, dict):
        return {"_cleaning": {}}
    annotations: dict[str, Any] = {}

    gov_doc = safe_get(data, "governing_document_description")
    objects_text = safe_get(data, "charitable_objects")
    area = safe_get(data, "area_of_benefit")

    if gov_doc:
        gov_doc, changed = clean_text(gov_doc)
        if changed:
            annotations["text_cleaned"] = True
    if objects_text:
        objects_text, changed = clean_text(objects_text)
        if changed:
            annotations["text_cleaned"] = True
    if area:
        area, changed = clean_text(area)
        if changed:
            annotations["text_cleaned"] = True

    return {
        "charity_number": None,
        "governing_document": gov_doc,
        "charitable_objects": objects_text,
        "area_of_benefit": area,
        "_cleaning": annotations,
    }


def clean_governance(data: Any) -> dict[str, Any]:
    """Clean governance summary."""
    if not data or not isinstance(data, dict):
        return {"_cleaning": {}}
    annotations: dict[str, Any] = {}

    charity_type = safe_get(data, "charity_type")
    if charity_type:
        annotations["charity_type_normalised"] = True

    ch_ref = make_ch_cross_ref(safe_get(data, "charity_co_reg_number"))
    if ch_ref:
        annotations["companies_house_linked"] = True

    return {
        "charity_number": None,
        "charity_type": charity_type,
        "gift_aid": safe_get(data, "gift_aid", False),
        "has_land": safe_get(data, "has_land", False),
        "companies_house_cross_ref": ch_ref,
        "_cleaning": annotations,
    }


def clean_linked_charities(data: Any) -> dict[str, Any]:
    """Clean linked/subsidiary charities."""
    annotations: dict[str, Any] = {}
    items_raw = safe_list(data)
    items = []

    for item in items_raw:
        if not isinstance(item, dict):
            continue
        gov_doc = safe_get(item, "governing_document")
        objects_text = safe_get(item, "charitable_objects")
        area = safe_get(item, "area_of_benefit")

        if gov_doc:
            gov_doc, changed = clean_text(gov_doc)
            if changed:
                annotations["text_cleaned"] = True
        if objects_text:
            objects_text, changed = clean_text(objects_text)
            if changed:
                annotations["text_cleaned"] = True
        if area:
            area, changed = clean_text(area)
            if changed:
                annotations["text_cleaned"] = True

        items.append({
            "charity_name": safe_get(item, "charity_name"),
            "linked_charity_number": _get_first(
                item,
                "registered_charity_number",
                "reg_charity_number",
            ),
            "suffix": _get_first(
                item, "suffix", "group_subsid_suffix",
                default=0,
            ),
            "governing_document": gov_doc,
            "charitable_objects": objects_text,
            "area_of_benefit": area,
        })

    annotations["main_charity_linked"] = True

    return {
        "charity_number": None,
        "total_linked": len(items),
        "items": items,
        "_cleaning": annotations,
    }


def clean_other_names(data: Any) -> dict[str, Any]:
    """Clean working and historical names."""
    annotations: dict[str, Any] = {}
    items_raw = safe_list(data)
    working_names: list[str] = []
    previous_names: list[str] = []

    name_type_map = {"W": "working", "O": "previous"}

    for item in items_raw:
        if not isinstance(item, dict):
            continue
        raw_type = safe_get(item, "name_type", "")
        name = safe_get(item, "other_name", "")
        if name and isinstance(name, str):
            trimmed = name.strip()
            if trimmed != name:
                annotations["name_normalised"] = True
            name = trimmed

        mapped_type = name_type_map.get(raw_type, "")
        if mapped_type:
            annotations["name_type_interpreted"] = True
        if mapped_type == "working":
            working_names.append(name)
        elif mapped_type == "previous":
            previous_names.append(name)
        else:
            working_names.append(name)

    return {
        "charity_number": None,
        "total_names": len(working_names) + len(previous_names),
        "working_names": working_names,
        "previous_names": previous_names,
        "_cleaning": annotations,
    }


def clean_registration_history(data: Any) -> dict[str, Any]:
    """Clean registration event history."""
    annotations: dict[str, Any] = {}
    items_raw = safe_list(data)
    items = []

    for item in items_raw:
        if not isinstance(item, dict):
            continue
        event_date = safe_get(item, "date")
        if event_date:
            event_date, changed = normalise_date(event_date)
            if changed:
                annotations["dates_normalised"] = True

        event_group = safe_get(item, "event_group", "")
        annotations["event_type_labelled"] = True

        items.append({
            "event_group": event_group,
            "description": safe_get(item, "description"),
            "date": event_date,
            "reason": safe_get(item, "reason"),
            "associated_charity_number": safe_get(
                item, "associated_charity_number"
            ),
        })

    # Sort chronologically
    items.sort(key=lambda i: i.get("date") or "")
    if len(items) > 1:
        annotations["sorted_chronologically"] = True

    return {
        "charity_number": None,
        "total_events": len(items),
        "items": items,
        "_cleaning": annotations,
    }


def clean_regulatory_reports(data: Any) -> dict[str, Any]:
    """Clean regulatory reports."""
    annotations: dict[str, Any] = {}
    items_raw = safe_list(data)
    items = []

    report_type_map = {
        "inquiry": "inquiry",
        "sori": "inquiry",
        "warning": "warning",
        "order": "order",
        "scheme": "scheme",
    }

    for item in items_raw:
        if not isinstance(item, dict):
            continue

        pub_date = safe_get(item, "date_published")
        if pub_date:
            pub_date, changed = normalise_date(pub_date)
            if changed:
                annotations["dates_normalised"] = True

        report_name = safe_get(item, "report_name", "")
        report_type = "other"
        name_lower = report_name.lower() if report_name else ""
        for key, rtype in report_type_map.items():
            if key in name_lower:
                report_type = rtype
                break
        annotations["report_type_categorised"] = True

        report_url = safe_get(item, "report_location")
        if report_url:
            url_norm, url_changed = normalise_url(report_url)
            if url_changed:
                annotations["url_validated"] = True
            report_url = url_norm

        items.append({
            "report_name": report_name,
            "report_type": report_type,
            "report_url": report_url,
            "date_published": pub_date,
        })

    return {
        "charity_number": None,
        "total_reports": len(items),
        "items": items,
        "_cleaning": annotations,
    }


def clean_cio_dissolution(data: Any) -> dict[str, Any]:
    """Clean CIO dissolution notice data."""
    if not data or not isinstance(data, dict):
        return {
            "charity_number": None,
            "dissolution_notice_date": None,
            "_cleaning": {},
        }
    annotations: dict[str, Any] = {}
    diss_date = safe_get(data, "dissolution_notice_date")
    if diss_date:
        diss_date, changed = normalise_date(diss_date)
        if changed:
            annotations["dates_normalised"] = True

    return {
        "charity_number": None,
        "dissolution_notice_date": diss_date,
        "_cleaning": annotations,
    }


def clean_sector_overview(data: Any) -> dict[str, Any]:
    """Clean sector overview statistics."""
    if not data or not isinstance(data, dict):
        return {"_cleaning": {}}
    annotations: dict[str, Any] = {}

    date_updated = safe_get(data, "date_updated")
    if date_updated:
        date_updated, changed = normalise_date(date_updated)
        if changed:
            annotations["dates_normalised"] = True

    # API uses number_of_main_charities / number_of_linked_charities
    # but we normalise to total_* for consistency.
    main_charities = (
        safe_get(data, "number_of_main_charities")
        or safe_get(data, "total_main_charities", 0)
    )
    linked_charities = (
        safe_get(data, "number_of_linked_charities")
        or safe_get(data, "total_linked_charities", 0)
    )
    total_income = (
        safe_get(data, "income")
        or safe_get(data, "total_income", 0)
    )
    total_expenditure = (
        safe_get(data, "expenditure")
        or safe_get(data, "total_expenditure", 0)
    )
    employees = (
        safe_get(data, "employees")
        or safe_get(data, "total_employees", 0)
    ) or 0
    volunteers = (
        safe_get(data, "volunteers")
        or safe_get(data, "total_volunteers", 0)
    ) or 0
    trustees = (
        safe_get(data, "trustees")
        or safe_get(data, "total_trustees", 0)
    )
    annotations["staffing_summarised"] = True
    annotations["financials_structured"] = True

    return {
        "date_updated": date_updated,
        "total_main_charities": main_charities,
        "total_linked_charities": linked_charities,
        "total_income": total_income,
        "total_expenditure": total_expenditure,
        "retained": safe_get(data, "retained", 0),
        "total_employees": employees,
        "total_volunteers": volunteers,
        "total_trustees": trustees,
        "_cleaning": annotations,
    }


def clean_sector_top10(data: Any) -> dict[str, Any]:
    """Clean sector top 10 ranking."""
    annotations: dict[str, Any] = {}
    items_raw = safe_list(data)
    items = []
    for i, item in enumerate(items_raw):
        if not isinstance(item, dict):
            continue
        items.append({
            "rank": i + 1,
            "charity_number": _get_first(
                item,
                "charity_number",
                "registered_charity_number",
                "reg_charity_number",
            ),
            "charity_name": safe_get(item, "charity_name"),
            "value": safe_get(item, "value"),
        })
    if items:
        annotations["charity_numbers_extracted"] = True

    return {
        "items": items,
        "_cleaning": annotations,
    }


def clean_sector_income_bands(data: Any) -> dict[str, Any]:
    """Clean sector income band data."""
    annotations: dict[str, Any] = {}
    items_raw = safe_list(data)
    bands = []
    for item in items_raw:
        if not isinstance(item, dict):
            continue
        bands.append({
            "band": safe_get(item, "band"),
            "count": safe_get(item, "count", 0),
            "total_income": safe_get(item, "total_income", 0),
            "total_expenditure": safe_get(
                item, "total_expenditure", 0
            ),
        })
    annotations["bands_normalised"] = True
    annotations["sorted_by_band"] = True

    return {
        "bands": bands,
        "_cleaning": annotations,
    }


def clean_sector_income_categories(data: Any) -> dict[str, Any]:
    """Clean sector income category data."""
    annotations: dict[str, Any] = {}
    items_raw = safe_list(data)
    categories = []
    for item in items_raw:
        if not isinstance(item, dict):
            continue
        categories.append({
            "category": safe_get(item, "category"),
            "count": safe_get(item, "count", 0),
            "total_income": safe_get(item, "total_income", 0),
            "total_expenditure": safe_get(
                item, "total_expenditure", 0
            ),
        })
    annotations["categories_normalised"] = True

    return {
        "categories": categories,
        "_cleaning": annotations,
    }
