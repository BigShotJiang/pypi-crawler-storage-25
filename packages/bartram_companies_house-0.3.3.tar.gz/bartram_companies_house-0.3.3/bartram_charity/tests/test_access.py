"""Tests for Charity Commission API client.

Uses httpx mock transport to return fixture data from real API responses.
Covers: input validation, error handling, rate limiting, caching,
and mock transport tests for representative endpoints.
"""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest

from bartram_charity.access import (
    AuthenticationError,
    BadRequestError,
    CharityClient,
    CharityConfig,
    CharityError,
    NotFoundError,
    RateLimitError,
    ServerError,
    validate_charity_number,
    validate_date,
)

FIXTURES = Path(__file__).parent / "fixtures"


def load_fixture(name: str) -> dict | list:
    """Load a JSON fixture file."""
    return json.loads((FIXTURES / name).read_text())


# ---------------------------------------------------------------------------
# Mock transport
# ---------------------------------------------------------------------------

BASE = "https://api.charitycommission.gov.uk/register/api"


class MockTransport(httpx.BaseTransport):
    """Returns canned responses for known paths, 404 for unknown."""

    def __init__(self) -> None:
        self.routes: dict[str, tuple[int, dict | list]] = {}
        self.request_log: list[httpx.Request] = []

    def add_route(
        self, path: str, fixture_name: str, status: int = 200
    ) -> None:
        self.routes[path] = (status, load_fixture(fixture_name))

    def add_json_route(
        self, path: str, data: dict | list, status: int = 200
    ) -> None:
        self.routes[path] = (status, data)

    def add_error_route(self, path: str, status: int) -> None:
        self.routes[path] = (status, {"error": "test error"})

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        self.request_log.append(request)
        path = request.url.raw_path.decode().split("?")[0]
        # Strip base URL prefix for matching
        prefix = "/register/api/"
        short = path[len(prefix):] if path.startswith(prefix) else path

        if short in self.routes:
            status, data = self.routes[short]
            return httpx.Response(status, json=data)
        if path in self.routes:
            status, data = self.routes[path]
            return httpx.Response(status, json=data)
        return httpx.Response(404, json={"error": "not found"})


def make_client(transport: MockTransport) -> CharityClient:
    """Create a client with a mock transport (caching disabled)."""
    config = CharityConfig(
        subscription_key="test-key",
        cache_enabled=False,
    )
    client = CharityClient(config)
    client._http = httpx.Client(
        transport=transport,
        base_url=config.base_url,
        headers={"Ocp-Apim-Subscription-Key": config.subscription_key},
        timeout=config.timeout,
    )
    return client


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------


class TestValidateCharityNumber:
    """Tests for charity number validation."""

    def test_valid_number(self) -> None:
        assert validate_charity_number("202918") == 202918

    def test_strips_whitespace(self) -> None:
        assert validate_charity_number("  202918  ") == 202918

    def test_strips_leading_zeros(self) -> None:
        assert validate_charity_number("00202918") == 202918

    def test_empty_string_raises(self) -> None:
        with pytest.raises(BadRequestError, match="required"):
            validate_charity_number("")

    def test_non_numeric_raises(self) -> None:
        with pytest.raises(BadRequestError, match="digits"):
            validate_charity_number("abc123")

    def test_zero_raises(self) -> None:
        with pytest.raises(BadRequestError, match="positive"):
            validate_charity_number("0")

    def test_all_zeros_raises(self) -> None:
        with pytest.raises(BadRequestError, match="positive"):
            validate_charity_number("000")

    def test_spaces_between_digits(self) -> None:
        with pytest.raises(BadRequestError, match="digits"):
            validate_charity_number("202 918")

    def test_large_number(self) -> None:
        assert validate_charity_number("1234567890") == 1234567890


class TestValidateDate:
    """Tests for date validation."""

    def test_valid_date(self) -> None:
        assert validate_date("2024-01-15", "start_date") == "2024-01-15"

    def test_strips_whitespace(self) -> None:
        assert validate_date("  2024-01-15  ", "start_date") == "2024-01-15"

    def test_empty_raises(self) -> None:
        with pytest.raises(BadRequestError, match="required"):
            validate_date("", "start_date")

    def test_wrong_format_raises(self) -> None:
        with pytest.raises(BadRequestError, match="YYYY-MM-DD"):
            validate_date("15/01/2024", "start_date")

    def test_partial_date_raises(self) -> None:
        with pytest.raises(BadRequestError, match="YYYY-MM-DD"):
            validate_date("2024-01", "end_date")

    def test_includes_field_name_in_error(self) -> None:
        with pytest.raises(BadRequestError, match="end_date"):
            validate_date("bad", "end_date")


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    """Tests for HTTP error status mapping."""

    def test_404_raises_not_found(self) -> None:
        transport = MockTransport()
        transport.add_error_route("charityRegNumber/999999/0", 404)
        client = make_client(transport)
        with pytest.raises(NotFoundError):
            client.lookup(999999)

    def test_401_raises_auth_error(self) -> None:
        transport = MockTransport()
        transport.add_error_route("charityRegNumber/202918/0", 401)
        client = make_client(transport)
        with pytest.raises(AuthenticationError):
            client.lookup(202918)

    def test_403_raises_auth_error(self) -> None:
        transport = MockTransport()
        transport.add_error_route("charityRegNumber/202918/0", 403)
        client = make_client(transport)
        with pytest.raises(AuthenticationError):
            client.lookup(202918)

    def test_429_raises_rate_limit(self) -> None:
        transport = MockTransport()
        transport.add_error_route("charityRegNumber/202918/0", 429)
        client = make_client(transport)
        with pytest.raises(RateLimitError):
            client.lookup(202918)

    def test_400_raises_bad_request(self) -> None:
        transport = MockTransport()
        transport.add_error_route("charityRegNumber/202918/0", 400)
        client = make_client(transport)
        with pytest.raises(BadRequestError):
            client.lookup(202918)

    def test_500_raises_server_error(self) -> None:
        transport = MockTransport()
        transport.add_error_route("sectoroverview", 500)
        client = make_client(transport)
        with pytest.raises(ServerError):
            client.sector_overview()

    def test_502_raises_server_error(self) -> None:
        transport = MockTransport()
        transport.add_error_route("sectoroverview", 502)
        client = make_client(transport)
        with pytest.raises(ServerError):
            client.sector_overview()

    def test_unexpected_status_raises_base_error(self) -> None:
        transport = MockTransport()
        transport.add_error_route("sectoroverview", 418)
        client = make_client(transport)
        with pytest.raises(CharityError, match="418"):
            client.sector_overview()


# ---------------------------------------------------------------------------
# Search endpoints
# ---------------------------------------------------------------------------


class TestSearch:
    """Tests for search endpoint."""

    def test_search_returns_results(self) -> None:
        transport = MockTransport()
        transport.add_route("searchCharityName/Oxfam", "search_oxfam.json")
        client = make_client(transport)
        data, cached = client.search("Oxfam")
        assert isinstance(data, list)
        assert len(data) == 2
        assert data[0]["charity_name"] == "OXFAM"
        assert cached is False

    def test_search_empty_results(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "searchCharityName/zzzznotreal", "search_empty.json"
        )
        client = make_client(transport)
        data, _cached = client.search("zzzznotreal")
        assert data == []

    def test_search_passes_query_in_path(self) -> None:
        transport = MockTransport()
        transport.add_route("searchCharityName/test", "search_empty.json")
        client = make_client(transport)
        client.search("test")
        req = transport.request_log[-1]
        assert b"searchCharityName/test" in req.url.raw_path


class TestSearchByDate:
    """Tests for date range search endpoints."""

    def test_registration_date_search(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "searchCharityRegDate/2024-01-01/2024-12-31",
            "search_oxfam.json",
        )
        client = make_client(transport)
        data, cached = client.search_by_registration_date(
            "2024-01-01", "2024-12-31"
        )
        assert isinstance(data, list)
        assert cached is False

    def test_removal_date_search(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "searchCharityRemDate/2024-01-01/2024-12-31",
            "search_empty.json",
        )
        client = make_client(transport)
        data, _cached = client.search_by_removal_date(
            "2024-01-01", "2024-12-31"
        )
        assert data == []


# ---------------------------------------------------------------------------
# Lookup / Details / Profile
# ---------------------------------------------------------------------------


class TestLookup:
    """Tests for charity lookup endpoint."""

    def test_lookup_success(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "charityRegNumber/202918/0", "lookup_202918.json"
        )
        client = make_client(transport)
        data, cached = client.lookup(202918)
        assert data["charity_name"] == "OXFAM"
        assert data["registered_charity_number"] == 202918
        assert cached is False

    def test_lookup_with_suffix(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "charityRegNumber/202918/1", "lookup_202918.json"
        )
        client = make_client(transport)
        data, _cached = client.lookup(202918, suffix=1)
        assert data["charity_name"] == "OXFAM"

    def test_lookup_not_found(self) -> None:
        transport = MockTransport()
        transport.add_error_route("charityRegNumber/999999/0", 404)
        client = make_client(transport)
        with pytest.raises(NotFoundError):
            client.lookup(999999)


class TestProfile:
    """Tests for charity profile endpoint."""

    def test_profile_success(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "allcharitydetailsV2/202918/0", "profile_202918.json"
        )
        client = make_client(transport)
        data, cached = client.profile(202918)
        assert data["charity_name"] == "OXFAM"
        assert "trustee_names" in data
        assert "who_what_where" in data
        assert cached is False


class TestDetails:
    """Tests for charity details endpoint."""

    def test_details_success(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "charitydetails/202918/0", "details_202918.json"
        )
        client = make_client(transport)
        data, cached = client.details(202918)
        assert data["charity_name"] == "OXFAM"
        assert cached is False


class TestBatchLookup:
    """Tests for batch lookup endpoint."""

    def test_batch_success(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charitydetailsmulti/202918,220949",
            [
                {"registered_charity_number": 202918, "charity_name": "OXFAM"},
                {
                    "registered_charity_number": 220949,
                    "charity_name": "BRITISH RED CROSS",
                },
            ],
        )
        client = make_client(transport)
        data, cached = client.batch_lookup("202918,220949")
        assert len(data) == 2
        assert cached is False


# ---------------------------------------------------------------------------
# Information endpoints
# ---------------------------------------------------------------------------


class TestTrustees:
    """Tests for trustee endpoints."""

    def test_trustees_success(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "charitytrusteeinformationV2/202918/0",
            "trustees_202918.json",
        )
        client = make_client(transport)
        data, _cached = client.trustees(202918)
        assert isinstance(data, list)
        assert len(data) == 2
        assert data[0]["trustee_name"] == "MRS JANE DOE OBE"

    def test_trustee_names(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charitytrusteenamesV2/202918/0",
            [
                {"trustee_name": "MRS JANE DOE OBE"},
                {"trustee_name": "MR JOHN SMITH"},
            ],
        )
        client = make_client(transport)
        data, _cached = client.trustee_names(202918)
        assert len(data) == 2


class TestClassifications:
    """Tests for classification endpoint."""

    def test_classifications_success(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charitywhowhathow/202918/0",
            [
                {"classification_code": 102, "classification_description": "Education"},
                {"classification_code": 201, "classification_description": "Children"},
            ],
        )
        client = make_client(transport)
        data, _cached = client.classifications(202918)
        assert len(data) == 2


class TestAreasOfOperation:
    """Tests for areas of operation endpoints."""

    def test_countries(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "CharityAoOCountryContinent/202918/0",
            [{"country": "United Kingdom", "continent": "Europe"}],
        )
        client = make_client(transport)
        data, _cached = client.areas_of_operation_countries(202918)
        assert len(data) == 1
        assert data[0]["country"] == "United Kingdom"

    def test_regions(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charityaooregion/202918/0",
            [{"region": "South East"}],
        )
        client = make_client(transport)
        data, _cached = client.areas_of_operation_regions(202918)
        assert len(data) == 1

    def test_local_authorities(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charityaoolocalauthority/202918/0",
            [{"local_authority": "Oxford", "metropolitan_county": None, "welsh": False}],
        )
        client = make_client(transport)
        data, _cached = client.areas_of_operation_local_authorities(202918)
        assert len(data) == 1


# ---------------------------------------------------------------------------
# Sector endpoints
# ---------------------------------------------------------------------------


class TestSectorEndpoints:
    """Tests for sector-level endpoints."""

    def test_sector_overview(self) -> None:
        transport = MockTransport()
        transport.add_route("sectoroverview", "sector_overview.json")
        client = make_client(transport)
        data, cached = client.sector_overview()
        assert data["total_main_charities"] == 170000
        assert cached is False

    def test_sector_top10(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "sectordatatop10/Income",
            [
                {"charity_number": 202918, "charity_name": "OXFAM", "value": 434500000},
            ],
        )
        client = make_client(transport)
        data, _cached = client.sector_top10("Income")
        assert len(data) == 1

    def test_sector_income_bands(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "sectorincomeband",
            [{"band": "Under 10k", "count": 50000}],
        )
        client = make_client(transport)
        data, _cached = client.sector_income_bands()
        assert len(data) == 1

    def test_sector_income_categories(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "sectorincomecategory",
            [{"category": "Education", "count": 30000}],
        )
        client = make_client(transport)
        data, _cached = client.sector_income_categories()
        assert len(data) == 1


# ---------------------------------------------------------------------------
# Other endpoints (representative coverage)
# ---------------------------------------------------------------------------


class TestOtherEndpoints:
    """Tests for remaining endpoints — representative coverage."""

    def test_contact(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charitycontactinformation/202918/0",
            {"phone": "0300 200 1300", "email": "test@test.com"},
        )
        client = make_client(transport)
        data, _ = client.contact(202918)
        assert data["phone"] == "0300 200 1300"

    def test_financial_history(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charityfinancialhistory/202918/0",
            [{"ar_cycle": "AR21", "income": 434500000}],
        )
        client = make_client(transport)
        data, _ = client.financial_history(202918)
        assert len(data) == 1

    def test_annual_return(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charityoverview/202918/0",
            {"activities": "Fighting poverty", "employees": 5400},
        )
        client = make_client(transport)
        data, _ = client.annual_return(202918)
        assert data["employees"] == 5400

    def test_accounts(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charityaraccounts/202918/0",
            [{"title": "Annual Return 2023"}],
        )
        client = make_client(transport)
        data, _ = client.accounts(202918)
        assert len(data) == 1

    def test_assets(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charityassetsliabilities/202918/0",
            {"assets_own_use": 50000000},
        )
        client = make_client(transport)
        data, _ = client.assets(202918)
        assert data["assets_own_use"] == 50000000

    def test_governing_document(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charitygoverningdocument/202918/0",
            {"governing_document_description": "Royal Charter"},
        )
        client = make_client(transport)
        data, _ = client.governing_document(202918)
        assert data["governing_document_description"] == "Royal Charter"

    def test_governance(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charitygovernanceinformation/202918/0",
            {"charity_type": "Other", "gift_aid": True},
        )
        client = make_client(transport)
        data, _ = client.governance(202918)
        assert data["gift_aid"] is True

    def test_linked_charities(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "linkedcharities/202918/0",
            [{"charity_name": "Oxfam Activities", "suffix": 1}],
        )
        client = make_client(transport)
        data, _ = client.linked_charities(202918)
        assert len(data) == 1

    def test_other_names(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charityothernames/202918/0",
            [{"other_name": "Oxfam GB", "name_type": "W"}],
        )
        client = make_client(transport)
        data, _ = client.other_names(202918)
        assert len(data) == 1

    def test_registration_history(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charityregistrationhistory/202918/0",
            [{"event_group": "Registration", "date": "01/01/1962"}],
        )
        client = make_client(transport)
        data, _ = client.registration_history(202918)
        assert len(data) == 1

    def test_regulatory_reports(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charityregulatoryreport/202918/0",
            [],
        )
        client = make_client(transport)
        data, _ = client.regulatory_reports(202918)
        assert data == []

    def test_cio_dissolution(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "ciodissolution/202918/0",
            {"dissolution_notice_date": None},
        )
        client = make_client(transport)
        data, _ = client.cio_dissolution(202918)
        assert data["dissolution_notice_date"] is None

    def test_constituency(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charityconstituency/202918/0",
            {"constituency_name": "Oxford East"},
        )
        client = make_client(transport)
        data, _ = client.constituency(202918)
        assert data["constituency_name"] == "Oxford East"

    def test_policies(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "charitypolicyinformation/202918/0",
            [{"policy": "Risk management"}],
        )
        client = make_client(transport)
        data, _ = client.policies(202918)
        assert len(data) == 1

    def test_other_regulators(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "CharityOtherRegulators/202918/0",
            [],
        )
        client = make_client(transport)
        data, _ = client.other_regulators(202918)
        assert data == []

    def test_primary_grants(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "checkprimarygrants/202918/0",
            {"primary_purpose_grant_making": False},
        )
        client = make_client(transport)
        data, _ = client.primary_grants(202918)
        assert data["primary_purpose_grant_making"] is False


# ---------------------------------------------------------------------------
# Request headers
# ---------------------------------------------------------------------------


class TestRequestHeaders:
    """Verify subscription key header is sent."""

    def test_subscription_key_header(self) -> None:
        transport = MockTransport()
        transport.add_route("sectoroverview", "sector_overview.json")
        client = make_client(transport)
        client.sector_overview()
        req = transport.request_log[-1]
        assert req.headers["ocp-apim-subscription-key"] == "test-key"
