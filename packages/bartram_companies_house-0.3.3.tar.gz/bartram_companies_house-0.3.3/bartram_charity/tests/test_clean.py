"""Tests for Charity Commission data cleaning logic.

Covers: utility functions, per-tool clean functions with known-messy data,
null/empty input handling, annotation verification.
"""

from __future__ import annotations

from bartram_charity.clean import (
    clean_accounts,
    clean_annual_return,
    clean_areas_of_operation,
    clean_assets,
    clean_batch_lookup,
    clean_cio_dissolution,
    clean_classifications,
    clean_constituency,
    clean_contact,
    clean_details,
    clean_financial_history,
    clean_governance,
    clean_governing_document,
    clean_linked_charities,
    clean_lookup,
    clean_other_names,
    clean_other_regulators,
    clean_policies,
    clean_primary_grants,
    clean_profile,
    clean_registration_history,
    clean_regulatory_reports,
    clean_search_results,
    clean_sector_income_bands,
    clean_sector_income_categories,
    clean_sector_overview,
    clean_sector_top10,
    clean_text,
    clean_trustee_names,
    clean_trustees,
    group_classifications,
    make_ch_cross_ref,
    map_status,
    normalise_date,
    normalise_url,
    safe_get,
    safe_list,
)

# ---------------------------------------------------------------------------
# Utility function tests
# ---------------------------------------------------------------------------


class TestMapStatus:
    """Tests for status code mapping."""

    def test_registered(self) -> None:
        assert map_status("R") == ("Registered", True)

    def test_removed(self) -> None:
        assert map_status("RM") == ("Removed", True)

    def test_unknown_code(self) -> None:
        assert map_status("X") == ("X", False)

    def test_none(self) -> None:
        assert map_status(None) == (None, False)

    def test_empty(self) -> None:
        assert map_status("") == ("", False)

    def test_whitespace_stripped(self) -> None:
        assert map_status(" R ") == ("Registered", True)


class TestNormaliseDate:
    """Tests for date normalisation."""

    def test_iso_passthrough(self) -> None:
        assert normalise_date("2024-01-15") == ("2024-01-15", False)

    def test_uk_date(self) -> None:
        assert normalise_date("15/01/2024") == ("2024-01-15", True)

    def test_uk_datetime(self) -> None:
        assert normalise_date("15/01/2024 14:30") == ("2024-01-15T14:30:00", True)

    def test_none(self) -> None:
        assert normalise_date(None) == (None, False)

    def test_empty(self) -> None:
        assert normalise_date("") == ("", False)

    def test_integer_input(self) -> None:
        assert normalise_date(12345) == (12345, False)


class TestCleanText:
    """Tests for text cleaning."""

    def test_collapse_whitespace(self) -> None:
        result, changed = clean_text("hello    world")
        assert result == "hello world"
        assert changed is True

    def test_trim(self) -> None:
        result, changed = clean_text("  hello  ")
        assert result == "hello"
        assert changed is True

    def test_none(self) -> None:
        assert clean_text(None) == (None, False)

    def test_collapse_newlines(self) -> None:
        result, changed = clean_text("a\n\n\n\nb")
        assert result == "a\n\nb"
        assert changed is True

    def test_no_change(self) -> None:
        result, changed = clean_text("already clean")
        assert result == "already clean"
        assert changed is False


class TestNormaliseUrl:
    """Tests for URL normalisation."""

    def test_adds_https(self) -> None:
        assert normalise_url("www.example.com") == ("https://www.example.com", True)

    def test_preserves_https(self) -> None:
        assert normalise_url("https://example.com") == ("https://example.com", False)

    def test_preserves_http(self) -> None:
        assert normalise_url("http://example.com") == ("http://example.com", False)

    def test_none(self) -> None:
        assert normalise_url(None) == (None, False)

    def test_empty_string(self) -> None:
        assert normalise_url("  ") == (None, False)


class TestGroupClassifications:
    """Tests for classification grouping."""

    def test_groups_by_range(self) -> None:
        items = [
            {"classification_code": 102, "classification_description": "Education"},
            {"classification_code": 201, "classification_description": "Children"},
            {"classification_code": 306, "classification_description": "Services"},
        ]
        result, changed = group_classifications(items)
        assert len(result["what"]) == 1
        assert len(result["who"]) == 1
        assert len(result["how"]) == 1
        assert changed is True

    def test_empty_list(self) -> None:
        result, changed = group_classifications([])
        assert result == {"what": [], "who": [], "how": []}
        assert changed is False

    def test_none(self) -> None:
        result, changed = group_classifications(None)
        assert result == {"what": [], "who": [], "how": []}
        assert changed is False

    def test_invalid_code(self) -> None:
        items = [{"classification_code": "abc", "classification_description": "Bad"}]
        result, changed = group_classifications(items)
        assert result == {"what": [], "who": [], "how": []}
        assert changed is True

    def test_alt_field_names(self) -> None:
        items = [{"code": 105, "description": "Relief of poverty"}]
        result, _ = group_classifications(items)
        assert len(result["what"]) == 1
        assert result["what"][0]["description"] == "Relief of poverty"


class TestMakeCHCrossRef:
    """Tests for Companies House cross-reference."""

    def test_valid_number(self) -> None:
        result = make_ch_cross_ref("1234567")
        assert result == {"company_number": "01234567", "tool": "uk_companies_house_profile"}

    def test_none(self) -> None:
        assert make_ch_cross_ref(None) is None

    def test_zero(self) -> None:
        assert make_ch_cross_ref("0") is None

    def test_already_padded(self) -> None:
        result = make_ch_cross_ref("01234567")
        assert result is not None
        assert result["company_number"] == "01234567"


class TestSafeGet:
    """Tests for null/missing field handling."""

    def test_existing_key(self) -> None:
        assert safe_get({"a": 1}, "a") == 1

    def test_missing_key(self) -> None:
        assert safe_get({"a": 1}, "b") is None

    def test_none_data(self) -> None:
        assert safe_get(None, "a") is None

    def test_default(self) -> None:
        assert safe_get({}, "a", 42) == 42


class TestSafeList:
    """Tests for safe list access."""

    def test_list(self) -> None:
        assert safe_list([1, 2]) == [1, 2]

    def test_none(self) -> None:
        assert safe_list(None) == []

    def test_string_returns_empty(self) -> None:
        assert safe_list("not a list") == []


# ---------------------------------------------------------------------------
# Per-tool clean function tests
# ---------------------------------------------------------------------------


class TestCleanSearchResults:
    """Tests for search result cleaning."""

    def test_basic_search(self) -> None:
        data = [
            {
                "registered_charity_number": 202918,
                "charity_name": "OXFAM",
                "reg_status": "R",
                "date_of_registration": "01/01/1962",
                "date_of_removal": None,
                "suffix": 0,
            }
        ]
        result = clean_search_results(data)
        assert result["total_results"] == 1
        item = result["items"][0]
        assert item["charity_number"] == 202918
        assert item["status"] == "Registered"
        assert item["date_of_registration"] == "1962-01-01"

    def test_empty_list(self) -> None:
        result = clean_search_results([])
        assert result["total_results"] == 0
        assert result["items"] == []

    def test_none_input(self) -> None:
        result = clean_search_results(None)
        assert result["total_results"] == 0

    def test_removed_status(self) -> None:
        data = [{"reg_status": "RM", "date_of_removal": "15/06/2020"}]
        result = clean_search_results(data)
        item = result["items"][0]
        assert item["status"] == "Removed"
        assert item["date_of_removal"] == "2020-06-15"

    def test_annotations_present(self) -> None:
        data = [{"reg_status": "R", "date_of_registration": "01/01/2000"}]
        result = clean_search_results(data)
        item = result["items"][0]
        assert item["_cleaning"]["status_mapped"] is True
        assert item["_cleaning"]["dates_normalised"] is True


class TestCleanLookup:
    """Tests for lookup cleaning."""

    def test_basic_lookup(self) -> None:
        data = {
            "registered_charity_number": 202918,
            "charity_name": "OXFAM",
            "reg_status": "R",
            "date_of_registration": "01/01/1962",
            "date_of_removal": None,
            "suffix": 0,
        }
        result = clean_lookup(data)
        assert result["charity_number"] == 202918
        assert result["status"] == "Registered"
        assert result["_cleaning"]["status_mapped"] is True

    def test_none_input(self) -> None:
        result = clean_lookup(None)
        assert result == {"_cleaning": {}}

    def test_uk_date_normalised(self) -> None:
        data = {"date_of_registration": "15/06/2018", "reg_status": "R"}
        result = clean_lookup(data)
        assert result["date_of_registration"] == "2018-06-15"


class TestCleanProfile:
    """Tests for comprehensive profile cleaning."""

    def test_full_profile(self) -> None:
        data = {
            "registered_charity_number": 202918,
            "charity_name": "OXFAM",
            "reg_status": "R",
            "charity_type": "Other",
            "date_of_registration": "01/01/1962",
            "date_of_removal": None,
            "web": "www.oxfam.org.uk",
            "phone": "0300 200 1300",
            "email": "info@oxfam.org.uk",
            "charity_co_reg_number": "612172",
            "address_line_one": "Oxfam House",
            "address_post_code": "OX4 2JY",
            "insolvent": False,
            "in_administration": False,
            "cio_ind": False,
            "latest_income": 500000000,
            "latest_expenditure": 480000000,
        }
        result = clean_profile(data)
        assert result["charity_number"] == 202918
        assert result["status"] == "Registered"
        assert result["contact"]["web"] == "https://www.oxfam.org.uk"
        assert result["companies_house_cross_ref"] is not None
        assert result["companies_house_cross_ref"]["company_number"] == "00612172"
        assert result["flags"]["insolvent"] is False
        assert "related_endpoints" in result
        assert result["_cleaning"]["status_mapped"] is True
        assert result["_cleaning"]["companies_house_linked"] is True

    def test_none_input(self) -> None:
        result = clean_profile(None)
        assert result == {"_cleaning": {}}

    def test_removed_charity_with_reason(self) -> None:
        data = {
            "reg_status": "RM",
            "removal_reason": "2",
            "date_of_removal": "01/03/2023",
        }
        result = clean_profile(data)
        assert result["status"] == "Removed"
        assert result["removal_reason"] == "Failure to submit accounts/annual return"

    def test_trustee_names_normalised(self) -> None:
        data = {
            "reg_status": "R",
            "trustee_names": [
                {"trustee_name": "MRS JANE DOE OBE", "organisation_number": 1}
            ],
        }
        result = clean_profile(data)
        assert len(result["trustees"]) == 1


class TestCleanDetails:
    """Tests for details cleaning."""

    def test_basic_details(self) -> None:
        data = {
            "registered_charity_number": 202918,
            "charity_name": "OXFAM",
            "reg_status": "R",
            "charity_type": "Other",
            "charity_co_reg_number": "612172",
            "date_of_registration": "01/01/1962",
        }
        result = clean_details(data)
        assert result["charity_number"] == 202918
        assert result["status"] == "Registered"
        assert result["companies_house_cross_ref"] is not None
        assert result["_cleaning"]["flags_labelled"] is True

    def test_none_input(self) -> None:
        result = clean_details(None)
        assert result == {"_cleaning": {}}


class TestCleanBatchLookup:
    """Tests for batch lookup cleaning."""

    def test_basic_batch(self) -> None:
        data = [
            {"registered_charity_number": 202918, "reg_status": "R"},
            {"registered_charity_number": 1014651, "reg_status": "R"},
        ]
        result = clean_batch_lookup(data, [202918, 1014651])
        assert result["total_requested"] == 2
        assert result["total_found"] == 2
        assert result["not_found"] == []

    def test_not_found_tracked(self) -> None:
        data = [{"registered_charity_number": 202918, "reg_status": "R"}]
        result = clean_batch_lookup(data, [202918, 999999])
        assert result["not_found"] == [999999]
        assert result["_cleaning"]["not_found_tracked"] is True

    def test_duplicate_requested(self) -> None:
        data = [{"registered_charity_number": 202918, "reg_status": "R"}]
        result = clean_batch_lookup(data, [202918, 202918])
        assert result["total_requested"] == 1
        assert result["_cleaning"]["input_deduplicated"] is True


class TestCleanTrustees:
    """Tests for trustee cleaning."""

    def test_with_fixture_data(self) -> None:
        data = [
            {
                "trustee_name": "MRS JANE DOE OBE",
                "organisation_number": 1,
                "is_chair": True,
                "date_of_appointment": "15/06/2018",
                "related_charities": [
                    {
                        "registered_charity_number": 1014651,
                        "charity_name": "ANOTHER CHARITY",
                        "reporting_status": "Current",
                    }
                ],
            },
            {
                "trustee_name": "MR JOHN SMITH",
                "organisation_number": 2,
                "is_chair": False,
                "date_of_appointment": "01/09/2020",
                "related_charities": [],
            },
        ]
        result = clean_trustees(data)
        assert result["total_trustees"] == 2
        assert result["chair_name"] is not None
        assert result["_cleaning"]["chair_identified"] is True
        assert result["_cleaning"]["dates_normalised"] is True
        assert result["_cleaning"]["linked_charities_resolved"] is True
        # Check date normalised
        assert result["items"][0]["date_of_appointment"] == "2018-06-15"
        assert result["items"][1]["date_of_appointment"] == "2020-09-01"

    def test_empty_list(self) -> None:
        result = clean_trustees([])
        assert result["total_trustees"] == 0
        assert result["chair_name"] is None

    def test_none_input(self) -> None:
        result = clean_trustees(None)
        assert result["total_trustees"] == 0


class TestCleanTrusteeNames:
    """Tests for trustee name list cleaning."""

    def test_dict_items(self) -> None:
        data = [
            {"trustee_name": "MRS JANE DOE"},
            {"trustee_name": "MR JOHN SMITH"},
        ]
        result = clean_trustee_names(data)
        assert result["total_trustees"] == 2
        assert len(result["names"]) == 2

    def test_none_input(self) -> None:
        result = clean_trustee_names(None)
        assert result["total_trustees"] == 0
        assert result["names"] == []


class TestCleanClassifications:
    """Tests for classification cleaning."""

    def test_grouped_correctly(self) -> None:
        data = [
            {"classification_code": 102, "classification_description": "Education"},
            {"classification_code": 201, "classification_description": "Children"},
            {"classification_code": 306, "classification_description": "Grants"},
        ]
        result = clean_classifications(data)
        assert len(result["what"]) == 1
        assert len(result["who"]) == 1
        assert len(result["how"]) == 1
        assert result["_cleaning"]["classifications_grouped"] is True

    def test_empty(self) -> None:
        result = clean_classifications([])
        assert result["what"] == []
        assert result["who"] == []
        assert result["how"] == []


class TestCleanAreasOfOperation:
    """Tests for areas of operation cleaning."""

    def test_combined_data(self) -> None:
        countries = [{"country": "United Kingdom", "continent": "Europe"}]
        regions = [{"region": "South East"}]
        local_authorities = [
            {"local_authority": "Oxford", "metropolitan_county": "Oxfordshire", "welsh": False}
        ]
        result = clean_areas_of_operation(countries, regions, local_authorities)
        assert len(result["countries"]) == 1
        assert result["countries"][0]["continent"] == "Europe"
        assert result["regions"] == ["South East"]
        assert len(result["local_authorities"]) == 1
        assert result["_cleaning"]["areas_grouped"] is True
        assert result["_cleaning"]["continents_included"] is True

    def test_all_none(self) -> None:
        result = clean_areas_of_operation(None, None, None)
        assert result["countries"] == []
        assert result["regions"] == []
        assert result["local_authorities"] == []


class TestCleanContact:
    """Tests for contact cleaning."""

    def test_url_normalised(self) -> None:
        data = {"web": "www.charity.org", "phone": " 020 1234 5678 ", "email": " INFO@CHARITY.ORG "}
        result = clean_contact(data)
        assert result["web"] == "https://www.charity.org"
        assert result["email"] == "info@charity.org"
        assert result["_cleaning"]["url_normalised"] is True
        assert result["_cleaning"]["email_normalised"] is True

    def test_none_input(self) -> None:
        result = clean_contact(None)
        assert result["web"] is None
        assert result["phone"] is None
        assert result["email"] is None


class TestCleanConstituency:
    """Tests for constituency cleaning."""

    def test_basic(self) -> None:
        data = {"constituency_name": "  Oxford East  "}
        result = clean_constituency(data)
        assert result["constituency_name"] == "Oxford East"
        assert result["_cleaning"]["name_normalised"] is True

    def test_none_input(self) -> None:
        result = clean_constituency(None)
        assert result["constituency_name"] is None


class TestCleanPolicies:
    """Tests for policies cleaning."""

    def test_dict_items(self) -> None:
        data = [{"policy": "Safeguarding"}, {"policy": "Risk management"}]
        result = clean_policies(data)
        assert result["total_policies"] == 2
        assert "Safeguarding" in result["policies"]
        assert result["_cleaning"]["policies_categorised"] is True

    def test_string_items(self) -> None:
        data = ["Safeguarding", "Risk management"]
        result = clean_policies(data)
        assert result["total_policies"] == 2

    def test_none_input(self) -> None:
        result = clean_policies(None)
        assert result["total_policies"] == 0


class TestCleanOtherRegulators:
    """Tests for other regulators cleaning."""

    def test_with_url(self) -> None:
        data = [{"name": "FCA", "website": "www.fca.org.uk"}]
        result = clean_other_regulators(data)
        assert result["total_regulators"] == 1
        assert result["regulators"][0]["website"] == "https://www.fca.org.uk"
        assert result["_cleaning"]["url_normalised"] is True

    def test_none_input(self) -> None:
        result = clean_other_regulators(None)
        assert result["total_regulators"] == 0


class TestCleanPrimaryGrants:
    """Tests for primary grants cleaning."""

    def test_grant_making(self) -> None:
        data = {"primary_purpose_grant_making": True}
        result = clean_primary_grants(data)
        assert result["primary_purpose_grant_making"] is True

    def test_none_input(self) -> None:
        result = clean_primary_grants(None)
        assert result["primary_purpose_grant_making"] is None


class TestCleanFinancialHistory:
    """Tests for financial history cleaning."""

    def test_trend_calculation(self) -> None:
        data = [
            {
                "ar_cycle": "2022",
                "financial_period_end_date": "31/03/2022",
                "income": 1000000,
                "expenditure": 900000,
            },
            {
                "ar_cycle": "2023",
                "financial_period_end_date": "31/03/2023",
                "income": 1100000,
                "expenditure": 950000,
            },
        ]
        result = clean_financial_history(data)
        assert len(result["periods"]) == 2
        assert result["periods"][0]["period_end"] == "2022-03-31"
        assert result["periods"][1]["income_change_pct"] == 10.0
        assert result["_cleaning"]["dates_normalised"] is True
        assert result["_cleaning"]["trends_calculated"] is True
        assert result["_cleaning"]["sorted_chronologically"] is True

    def test_government_funding_flagged(self) -> None:
        data = [{"income_from_govt_contracts": 50000, "income": 100000, "expenditure": 90000}]
        result = clean_financial_history(data)
        assert result["_cleaning"]["government_funding_flagged"] is True

    def test_empty(self) -> None:
        result = clean_financial_history([])
        assert result["periods"] == []

    def test_none_input(self) -> None:
        result = clean_financial_history(None)
        assert result["periods"] == []


class TestCleanAnnualReturn:
    """Tests for annual return cleaning."""

    def test_basic(self) -> None:
        data = {
            "activities": "  We help   people  ",
            "employees": 50,
            "volunteers": 200,
            "trustees": 10,
            "income": 1000000,
            "expenditure": 900000,
            "band_60001_70000": 3,
            "band_over_500000": 1,
        }
        result = clean_annual_return(data)
        assert result["activities"] == "We help people"
        assert result["total_staff"] == 250
        assert result["pay_bands"]["60001_70000"] == 3
        assert result["pay_bands"]["over_500000"] == 1
        assert result["_cleaning"]["activities_cleaned"] is True
        assert result["_cleaning"]["staffing_summarised"] is True

    def test_none_input(self) -> None:
        result = clean_annual_return(None)
        assert result == {"_cleaning": {}}

    def test_trustee_benefits(self) -> None:
        data = {"trustee_benefits": "Travel expenses"}
        result = clean_annual_return(data)
        assert result["trustee_benefits"]["has_benefits"] is True
        assert result["_cleaning"]["trustee_benefits_flagged"] is True


class TestCleanAccounts:
    """Tests for accounts cleaning."""

    def test_overdue_detection(self) -> None:
        data = [
            {
                "title": "Annual Return",
                "reporting_period_year_end": "31/03/2020",
                "date_received": None,
                "date_due": "01/01/2021",
                "accounts_qualified": False,
                "suppression_ind": False,
            }
        ]
        result = clean_accounts(data)
        assert result["total_filings"] == 1
        assert result["overdue_count"] == 1
        assert result["items"][0]["overdue"] is True
        assert result["_cleaning"]["overdue_flagged"] is True

    def test_qualified_flagged(self) -> None:
        data = [{"accounts_qualified": True}]
        result = clean_accounts(data)
        assert result["qualified_count"] == 1
        assert result["_cleaning"]["qualified_flagged"] is True

    def test_empty(self) -> None:
        result = clean_accounts([])
        assert result["total_filings"] == 0
        assert result["overdue_count"] == 0


class TestCleanAssets:
    """Tests for assets cleaning."""

    def test_net_assets_calculated(self) -> None:
        data = {
            "fin_period_end_date": "31/03/2023",
            "assets_own_use": 1000000,
            "assets_long_term_investment": 500000,
            "defined_net_assets_pension": 100000,
            "assets_other_assets": 200000,
            "assets_total_liabilities": 300000,
        }
        result = clean_assets(data)
        assert result["net_assets"] == 1500000  # 1M + 500K + 100K + 200K - 300K
        assert result["period_end"] == "2023-03-31"
        assert result["_cleaning"]["net_assets_calculated"] is True
        assert result["_cleaning"]["dates_normalised"] is True

    def test_none_input(self) -> None:
        result = clean_assets(None)
        assert result == {"_cleaning": {}}


class TestCleanGoverningDocument:
    """Tests for governing document cleaning."""

    def test_text_cleaned(self) -> None:
        data = {
            "governing_document_description": "  Trust  deed  ",
            "charitable_objects": "Relief   of   poverty",
            "area_of_benefit": "United  Kingdom",
        }
        result = clean_governing_document(data)
        assert result["governing_document"] == "Trust deed"
        assert result["charitable_objects"] == "Relief of poverty"
        assert result["area_of_benefit"] == "United Kingdom"
        assert result["_cleaning"]["text_cleaned"] is True

    def test_none_input(self) -> None:
        result = clean_governing_document(None)
        assert result == {"_cleaning": {}}


class TestCleanGovernance:
    """Tests for governance cleaning."""

    def test_with_ch_link(self) -> None:
        data = {
            "charity_type": "Charitable company",
            "gift_aid": True,
            "has_land": False,
            "charity_co_reg_number": "612172",
        }
        result = clean_governance(data)
        assert result["charity_type"] == "Charitable company"
        assert result["gift_aid"] is True
        assert result["companies_house_cross_ref"] is not None
        assert result["_cleaning"]["companies_house_linked"] is True

    def test_none_input(self) -> None:
        result = clean_governance(None)
        assert result == {"_cleaning": {}}


class TestCleanLinkedCharities:
    """Tests for linked charities cleaning."""

    def test_basic(self) -> None:
        data = [
            {
                "registered_charity_number": 202918,
                "charity_name": "OXFAM SUBSIDIARY",
                "suffix": 1,
                "governing_document": "  Constitution  ",
                "charitable_objects": "Relief of  poverty",
            }
        ]
        result = clean_linked_charities(data)
        assert result["total_linked"] == 1
        assert result["items"][0]["governing_document"] == "Constitution"
        assert result["_cleaning"]["text_cleaned"] is True

    def test_empty(self) -> None:
        result = clean_linked_charities([])
        assert result["total_linked"] == 0


class TestCleanOtherNames:
    """Tests for other names cleaning."""

    def test_working_and_previous(self) -> None:
        data = [
            {"name_type": "W", "other_name": "Oxfam GB"},
            {"name_type": "O", "other_name": "Oxford Committee for Famine Relief"},
        ]
        result = clean_other_names(data)
        assert result["total_names"] == 2
        assert "Oxfam GB" in result["working_names"]
        assert "Oxford Committee for Famine Relief" in result["previous_names"]
        assert result["_cleaning"]["name_type_interpreted"] is True

    def test_unknown_type_goes_to_working(self) -> None:
        data = [{"name_type": "Z", "other_name": "Unknown Type"}]
        result = clean_other_names(data)
        assert "Unknown Type" in result["working_names"]

    def test_none_input(self) -> None:
        result = clean_other_names(None)
        assert result["total_names"] == 0


class TestCleanRegistrationHistory:
    """Tests for registration history cleaning."""

    def test_sorted_chronologically(self) -> None:
        data = [
            {"event_group": "Registration", "date": "15/06/2020", "description": "Registered"},
            {
                "event_group": "Registration",
                "date": "01/01/1962",
                "description": "First registration",
            },
        ]
        result = clean_registration_history(data)
        assert result["total_events"] == 2
        assert result["items"][0]["date"] == "1962-01-01"
        assert result["items"][1]["date"] == "2020-06-15"
        assert result["_cleaning"]["sorted_chronologically"] is True
        assert result["_cleaning"]["dates_normalised"] is True

    def test_empty(self) -> None:
        result = clean_registration_history([])
        assert result["total_events"] == 0


class TestCleanRegulatoryReports:
    """Tests for regulatory report cleaning."""

    def test_type_categorisation(self) -> None:
        data = [
            {
                "report_name": "Statutory Inquiry Report",
                "date_published": "15/06/2023",
                "report_location": "www.gov.uk/report/123",
            },
            {
                "report_name": "Warning letter",
                "date_published": "2023-01-15",
            },
        ]
        result = clean_regulatory_reports(data)
        assert result["total_reports"] == 2
        assert result["items"][0]["report_type"] == "inquiry"
        assert result["items"][0]["report_url"] == "https://www.gov.uk/report/123"
        assert result["items"][1]["report_type"] == "warning"
        assert result["_cleaning"]["report_type_categorised"] is True

    def test_empty(self) -> None:
        result = clean_regulatory_reports([])
        assert result["total_reports"] == 0


class TestCleanCioDissolution:
    """Tests for CIO dissolution cleaning."""

    def test_with_date(self) -> None:
        data = {"dissolution_notice_date": "01/03/2024"}
        result = clean_cio_dissolution(data)
        assert result["dissolution_notice_date"] == "2024-03-01"
        assert result["_cleaning"]["dates_normalised"] is True

    def test_none_input(self) -> None:
        result = clean_cio_dissolution(None)
        assert result["dissolution_notice_date"] is None


class TestCleanSectorOverview:
    """Tests for sector overview cleaning."""

    def test_with_fixture_data(self) -> None:
        data = {
            "date_updated": "2024-03-15",
            "total_main_charities": 170000,
            "total_linked_charities": 5000,
            "total_income": 85000000000,
            "total_expenditure": 80000000000,
            "retained": 5000000000,
            "total_employees": 950000,
            "total_volunteers": 3500000,
            "total_trustees": 680000,
        }
        result = clean_sector_overview(data)
        assert result["total_main_charities"] == 170000
        assert result["total_income"] == 85000000000
        assert result["_cleaning"]["staffing_summarised"] is True
        assert result["_cleaning"]["financials_structured"] is True

    def test_none_input(self) -> None:
        result = clean_sector_overview(None)
        assert result == {"_cleaning": {}}


class TestCleanSectorTop10:
    """Tests for sector top 10 cleaning."""

    def test_ranked(self) -> None:
        data = [
            {"registered_charity_number": 202918, "charity_name": "OXFAM", "value": 500000000},
            {"registered_charity_number": 1014651, "charity_name": "ANOTHER", "value": 400000000},
        ]
        result = clean_sector_top10(data)
        assert len(result["items"]) == 2
        assert result["items"][0]["rank"] == 1
        assert result["items"][1]["rank"] == 2
        assert result["_cleaning"]["charity_numbers_extracted"] is True

    def test_empty(self) -> None:
        result = clean_sector_top10([])
        assert result["items"] == []


class TestCleanSectorIncomeBands:
    """Tests for sector income bands cleaning."""

    def test_basic(self) -> None:
        data = [
            {
                "band": "0-10000",
                "count": 50000,
                "total_income": 250000000,
                "total_expenditure": 200000000,
            },
        ]
        result = clean_sector_income_bands(data)
        assert len(result["bands"]) == 1
        assert result["bands"][0]["band"] == "0-10000"
        assert result["_cleaning"]["bands_normalised"] is True

    def test_empty(self) -> None:
        result = clean_sector_income_bands([])
        assert result["bands"] == []


class TestCleanSectorIncomeCategories:
    """Tests for sector income categories cleaning."""

    def test_basic(self) -> None:
        data = [
            {
                "category": "Education",
                "count": 10000,
                "total_income": 5000000000,
                "total_expenditure": 4500000000,
            },
        ]
        result = clean_sector_income_categories(data)
        assert len(result["categories"]) == 1
        assert result["categories"][0]["category"] == "Education"
        assert result["_cleaning"]["categories_normalised"] is True

    def test_empty(self) -> None:
        result = clean_sector_income_categories([])
        assert result["categories"] == []


# ---------------------------------------------------------------------------
# Real API field name alias tests
# ---------------------------------------------------------------------------


class TestRealApiFieldAliases:
    """Verify clean functions handle real API field names."""

    def test_search_uses_reg_charity_number(self) -> None:
        """Real API returns reg_charity_number, not registered_charity_number."""
        data = [
            {
                "reg_charity_number": 202918,
                "charity_name": "OXFAM",
                "reg_status": "R",
                "group_subsid_suffix": 0,
            }
        ]
        result = clean_search_results(data)
        assert result["items"][0]["charity_number"] == 202918
        assert result["items"][0]["suffix"] == 0

    def test_lookup_uses_reg_charity_number(self) -> None:
        data = {
            "reg_charity_number": 202918,
            "charity_name": "OXFAM",
            "reg_status": "R",
            "group_subsid_suffix": 0,
        }
        result = clean_lookup(data)
        assert result["charity_number"] == 202918
        assert result["suffix"] == 0

    def test_profile_uses_real_api_fields(self) -> None:
        data = {
            "reg_charity_number": 202918,
            "charity_name": "OXFAM",
            "reg_status": "R",
            "latest_acc_fin_year_start_date": "01/04/2022",
            "latest_acc_fin_year_end_date": "31/03/2023",
            "last_modified_time": "2024-01-15T10:30:00",
            "constituency_name": "Oxford East",
            "prev_excepted_ind": False,
            "cif_cdf_ind": None,
        }
        result = clean_profile(data)
        assert result["charity_number"] == 202918
        assert (
            result["latest_accounts_period"]["start"]
            == "2022-04-01"
        )
        assert result["last_modified"] == "2024-01-15T10:30:00"
        assert result["constituency"] == "Oxford East"
        assert result["flags"]["previously_excepted"] is False

    def test_details_uses_real_api_fields(self) -> None:
        data = {
            "reg_charity_number": 202918,
            "charity_name": "OXFAM",
            "reg_status": "R",
            "latest_acc_fin_year_start_date": "01/04/2022",
            "latest_acc_fin_year_end_date": "31/03/2023",
            "last_modified_time": "2024-01-15T10:30:00",
        }
        result = clean_details(data)
        assert result["charity_number"] == 202918
        assert result["last_modified"] == "2024-01-15T10:30:00"

    def test_trustees_uses_name_field(self) -> None:
        """Real API V2 uses 'name' not 'trustee_name'."""
        data = [
            {
                "name": "Andrew David Tivey",
                "is_chair": True,
                "date_of_appointment": "2025-11-27",
                "related_charities": [],
            }
        ]
        result = clean_trustees(data)
        assert result["total_trustees"] == 1
        assert result["chair_name"] is not None
        assert result["_cleaning"]["chair_identified"] is True

    def test_trustee_names_uses_name_field(self) -> None:
        data = [{"name": "Andrew David Tivey"}]
        result = clean_trustee_names(data)
        assert result["total_trustees"] == 1
        assert len(result["names"]) == 1

    def test_classification_desc_alias(self) -> None:
        """Real API uses classification_desc."""
        data = [
            {
                "classification_code": "105",
                "classification_desc": "Relief Of Poverty",
            }
        ]
        result = clean_classifications(data)
        assert len(result["what"]) == 1
        assert (
            result["what"][0]["description"]
            == "Relief Of Poverty"
        )

    def test_sector_overview_uses_number_of(self) -> None:
        """Real API uses number_of_main_charities."""
        data = {
            "date_updated": "2026-04-05T00:00:00",
            "number_of_main_charities": 171109.0,
            "number_of_linked_charities": 13808.0,
            "income": 106000000000.0,
            "expenditure": 105000000000.0,
            "employees": 1232309.0,
            "volunteers": 6592833.0,
            "trustees": 920774.0,
            "retained": 1043310270.0,
        }
        result = clean_sector_overview(data)
        assert result["total_main_charities"] == 171109.0
        assert result["total_linked_charities"] == 13808.0
        assert result["total_income"] == 106000000000.0
        assert result["total_employees"] == 1232309.0
        assert result["total_volunteers"] == 6592833.0
        assert result["total_trustees"] == 920774.0


# ---------------------------------------------------------------------------
# Additional edge case tests from audit
# ---------------------------------------------------------------------------


class TestFinancialHistoryEdgeCases:
    def test_single_period_no_trends(self) -> None:
        data = [{"income": 100, "expenditure": 90}]
        result = clean_financial_history(data)
        assert len(result["periods"]) == 1
        assert result["periods"][0]["income_change_pct"] is None
        assert "trends_calculated" not in result["_cleaning"]

    def test_zero_income_trend(self) -> None:
        """Zero income should not crash trend calculation."""
        data = [
            {"income": 0, "expenditure": 0},
            {"income": 100, "expenditure": 50},
        ]
        result = clean_financial_history(data)
        # prev_inc is 0, so division skipped
        assert result["periods"][1]["income_change_pct"] is None


class TestCleanSearchResultsAnnotation:
    def test_has_top_level_cleaning(self) -> None:
        data = [{"reg_status": "R"}]
        result = clean_search_results(data)
        assert "_cleaning" in result
        assert result["_cleaning"]["status_mapped"] is True


class TestCleanBatchLookupEdgeCases:
    def test_empty_data_list(self) -> None:
        result = clean_batch_lookup([], [202918])
        assert result["total_found"] == 0
        assert result["not_found"] == [202918]
