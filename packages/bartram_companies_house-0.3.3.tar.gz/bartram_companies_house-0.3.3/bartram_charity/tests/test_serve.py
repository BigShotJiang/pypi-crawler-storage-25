"""Tests for Charity Commission MCP tool definitions (serve layer).

End-to-end tests via mock transport: MCP call in, structured response out.
Covers: full access->clean->serve pipeline for each tool.
"""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest

from bartram_charity import serve
from bartram_charity.access import CharityClient, CharityConfig

FIXTURES = Path(__file__).parent / "fixtures"


def load_fixture(name: str) -> dict | list:
    """Load a JSON fixture file."""
    return json.loads((FIXTURES / name).read_text())


# ---------------------------------------------------------------------------
# Mock transport
# ---------------------------------------------------------------------------

BASE = "https://api.charitycommission.gov.uk/register/api"


class MockTransport(httpx.BaseTransport):
    """Returns canned responses for known paths, 404 for unknown."""

    def __init__(self) -> None:
        self.routes: dict[str, tuple[int, dict | list]] = {}

    def add_route(
        self, path: str, fixture_name: str, status: int = 200,
    ) -> None:
        self.routes[path] = (status, load_fixture(fixture_name))

    def add_json_route(
        self, path: str, data: dict | list, status: int = 200,
    ) -> None:
        self.routes[path] = (status, data)

    def add_error_route(self, path: str, status: int) -> None:
        self.routes[path] = (status, {"error": "test error"})

    def handle_request(
        self, request: httpx.Request,
    ) -> httpx.Response:
        path = request.url.raw_path.decode().split("?")[0]
        prefix = "/register/api/"
        short = (
            path[len(prefix):]
            if path.startswith(prefix)
            else path
        )
        if short in self.routes:
            status, data = self.routes[short]
            return httpx.Response(status, json=data)
        return httpx.Response(404, json={"error": "not found"})


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _mock_client(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path,
) -> None:
    """Inject a mock client and metrics store into the serve module."""
    transport = MockTransport()

    # Search
    transport.add_route(
        "searchCharityName/oxfam", "search_oxfam.json",
    )
    transport.add_json_route("searchCharityName/empty", [])

    # Date search
    transport.add_route(
        "searchCharityRegDate/2020-01-01/2020-12-31",
        "search_oxfam.json",
    )
    transport.add_route(
        "searchCharityRemDate/2020-01-01/2020-12-31",
        "search_oxfam.json",
    )

    # Lookup
    transport.add_route(
        "charityRegNumber/202918/0", "lookup_202918.json",
    )

    # Profile
    transport.add_route(
        "allcharitydetailsV2/202918/0", "profile_202918.json",
    )

    # Details
    transport.add_route(
        "charitydetails/202918/0", "details_202918.json",
    )

    # Batch
    transport.add_json_route(
        "charitydetailsmulti/202918",
        [load_fixture("details_202918.json")],
    )

    # Trustees
    transport.add_route(
        "charitytrusteeinformationV2/202918/0",
        "trustees_202918.json",
    )

    # Trustee names
    transport.add_json_route(
        "charitytrusteenamesV2/202918/0",
        [
            {"trustee_name": "MRS JANE DOE OBE"},
            {"trustee_name": "MR JOHN SMITH"},
        ],
    )

    # Classifications
    transport.add_json_route(
        "charitywhowhathow/202918/0",
        [
            {
                "classification_code": 102,
                "classification_description": "Education",
            },
            {
                "classification_code": 201,
                "classification_description": "Children",
            },
        ],
    )

    # Areas of operation (3 endpoints)
    transport.add_json_route(
        "CharityAoOCountryContinent/202918/0",
        [{"country": "United Kingdom", "continent": "Europe"}],
    )
    transport.add_json_route(
        "charityaooregion/202918/0",
        [{"region": "South East"}],
    )
    transport.add_json_route(
        "charityaoolocalauthority/202918/0",
        [
            {
                "local_authority": "Oxford",
                "metropolitan_county": "Oxfordshire",
                "welsh": False,
            },
        ],
    )

    # Contact
    transport.add_json_route(
        "charitycontactinformation/202918/0",
        {
            "web": "www.oxfam.org.uk",
            "phone": "0300 200 1300",
            "email": "INFO@OXFAM.ORG.UK",
        },
    )

    # Constituency
    transport.add_json_route(
        "charityconstituency/202918/0",
        {"constituency_name": "Oxford East"},
    )

    # Policies
    transport.add_json_route(
        "charitypolicyinformation/202918/0",
        [{"policy": "Safeguarding"}, {"policy": "Risk management"}],
    )

    # Other regulators
    transport.add_json_route(
        "CharityOtherRegulators/202918/0",
        [{"name": "FCA", "website": "www.fca.org.uk"}],
    )

    # Primary grants
    transport.add_json_route(
        "checkprimarygrants/202918/0",
        {"primary_purpose_grant_making": True},
    )

    # Financial history
    transport.add_json_route(
        "charityfinancialhistory/202918/0",
        [
            {
                "ar_cycle": "2023",
                "financial_period_end_date": "31/03/2023",
                "income": 434500000,
                "expenditure": 399200000,
            },
        ],
    )

    # Annual return
    transport.add_json_route(
        "charityoverview/202918/0",
        {
            "activities": "Fighting poverty",
            "employees": 5000,
            "volunteers": 30000,
            "income": 434500000,
        },
    )

    # Accounts
    transport.add_json_route(
        "charityaraccounts/202918/0",
        [
            {
                "title": "Annual Return 2023",
                "reporting_period_year_end": "31/03/2023",
                "date_received": "15/06/2023",
                "date_due": "31/01/2024",
            },
        ],
    )

    # Assets
    transport.add_json_route(
        "charityassetsliabilities/202918/0",
        {
            "fin_period_end_date": "31/03/2023",
            "assets_own_use": 50000000,
            "assets_long_term_investment": 20000000,
            "assets_total_liabilities": 30000000,
        },
    )

    # Governing document
    transport.add_json_route(
        "charitygoverningdocument/202918/0",
        {
            "governing_document_description": "Trust deed",
            "charitable_objects": "Relief of poverty",
            "area_of_benefit": "Worldwide",
        },
    )

    # Governance
    transport.add_json_route(
        "charitygovernanceinformation/202918/0",
        {
            "charity_type": "Other",
            "gift_aid": True,
            "has_land": True,
            "charity_co_reg_number": "612172",
        },
    )

    # Linked charities
    transport.add_json_route(
        "linkedcharities/202918/0",
        [
            {
                "registered_charity_number": 202918,
                "charity_name": "OXFAM SUBSIDIARY",
                "suffix": 1,
            },
        ],
    )

    # Other names
    transport.add_json_route(
        "charityothernames/202918/0",
        [
            {"name_type": "W", "other_name": "Oxfam GB"},
            {
                "name_type": "O",
                "other_name": "Oxford Committee for Famine Relief",
            },
        ],
    )

    # Registration history
    transport.add_json_route(
        "charityregistrationhistory/202918/0",
        [
            {
                "event_group": "Registration",
                "date": "01/01/1962",
                "description": "Registered",
            },
        ],
    )

    # Regulatory reports
    transport.add_json_route(
        "charityregulatoryreport/202918/0",
        [
            {
                "report_name": "Inquiry report",
                "date_published": "15/06/2023",
                "report_location": "www.gov.uk/report/123",
            },
        ],
    )

    # CIO dissolution
    transport.add_json_route(
        "ciodissolution/202918/0",
        {"dissolution_notice_date": "01/03/2024"},
    )

    # Sector
    transport.add_route(
        "sectoroverview", "sector_overview.json",
    )
    transport.add_json_route(
        "sectordatatop10/income",
        [
            {
                "registered_charity_number": 202918,
                "charity_name": "OXFAM",
                "value": 434500000,
            },
        ],
    )
    transport.add_json_route(
        "sectorincomeband",
        [
            {
                "band": "0-10000",
                "count": 50000,
                "total_income": 250000000,
            },
        ],
    )
    transport.add_json_route(
        "sectorincomecategory",
        [
            {
                "category": "Education",
                "count": 10000,
                "total_income": 5000000000,
            },
        ],
    )

    # Build client with mock transport
    config = CharityConfig(
        subscription_key="test-key", cache_enabled=False,
    )
    client = CharityClient(config)
    client._http = httpx.Client(
        transport=transport,
        base_url=config.base_url,
        headers={
            "Ocp-Apim-Subscription-Key": config.subscription_key,
        },
        timeout=config.timeout,
    )
    monkeypatch.setattr(serve, "_client", client)

    from bartram_foundry.monitoring import MetricsStore

    monkeypatch.setattr(
        serve,
        "_metrics",
        MetricsStore(db_path=str(tmp_path / "metrics.db")),
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _parse(result: str) -> dict:
    """Parse a serve function's JSON result."""
    return json.loads(result)


def _assert_envelope(parsed: dict) -> dict:
    """Assert standard response envelope and return data."""
    assert "data" in parsed
    assert "metadata" in parsed
    meta = parsed["metadata"]
    assert "source" in meta
    assert "licence" in meta
    assert "retrieved_at" in meta
    assert "endpoint" in meta
    assert "attribution" in meta
    return parsed["data"]


def _assert_error(parsed: dict, error_type: str) -> None:
    """Assert error response shape."""
    assert parsed["error"] == error_type
    assert "message" in parsed


# ---------------------------------------------------------------------------
# Server registration
# ---------------------------------------------------------------------------


class TestServerRegistration:
    """Verify the MCP server registers all 31 tools."""

    def test_server_name(self) -> None:
        assert serve.server.name == "bartram-charity"

    def test_tool_count(self) -> None:
        tools = serve.server._tool_manager.list_tools()
        assert len(tools) == 31, (
            f"Expected 31 tools, got {len(tools)}: "
            f"{[t.name for t in tools]}"
        )

    def test_expected_tool_names(self) -> None:
        tools = serve.server._tool_manager.list_tools()
        names = {t.name for t in tools}
        expected = {
            "uk_charity_search",
            "uk_charity_lookup",
            "uk_charity_search_by_registration_date",
            "uk_charity_search_by_removal_date",
            "uk_charity_profile",
            "uk_charity_details",
            "uk_charity_batch_lookup",
            "uk_charity_trustees",
            "uk_charity_trustee_names",
            "uk_charity_classifications",
            "uk_charity_areas_of_operation",
            "uk_charity_contact",
            "uk_charity_constituency",
            "uk_charity_policies",
            "uk_charity_other_regulators",
            "uk_charity_primary_grants",
            "uk_charity_financial_history",
            "uk_charity_annual_return",
            "uk_charity_accounts",
            "uk_charity_assets",
            "uk_charity_governing_document",
            "uk_charity_governance",
            "uk_charity_linked_charities",
            "uk_charity_other_names",
            "uk_charity_registration_history",
            "uk_charity_regulatory_reports",
            "uk_charity_cio_dissolution",
            "uk_charity_sector_overview",
            "uk_charity_sector_top10",
            "uk_charity_sector_income_bands",
            "uk_charity_sector_income_categories",
        }
        assert names == expected


# ---------------------------------------------------------------------------
# Search tools
# ---------------------------------------------------------------------------


class TestSearch:
    async def test_search_success(self) -> None:
        result = _parse(await serve.uk_charity_search("oxfam"))
        data = _assert_envelope(result)
        assert data["total_results"] == 2
        assert data["items"][0]["charity_number"] == 202918
        assert data["items"][0]["status"] == "Registered"

    async def test_search_empty_query(self) -> None:
        result = _parse(await serve.uk_charity_search(""))
        _assert_error(result, "bad_request")

    async def test_search_date_normalised(self) -> None:
        result = _parse(await serve.uk_charity_search("oxfam"))
        data = _assert_envelope(result)
        assert data["items"][0]["date_of_registration"] == "1962-01-01"

    async def test_search_by_registration_date(self) -> None:
        result = _parse(
            await serve.uk_charity_search_by_registration_date(
                "2020-01-01", "2020-12-31",
            ),
        )
        data = _assert_envelope(result)
        assert data["total_results"] == 2

    async def test_search_by_registration_date_invalid(self) -> None:
        result = _parse(
            await serve.uk_charity_search_by_registration_date(
                "2020-12-31", "2020-01-01",
            ),
        )
        _assert_error(result, "bad_request")

    async def test_search_by_removal_date(self) -> None:
        result = _parse(
            await serve.uk_charity_search_by_removal_date(
                "2020-01-01", "2020-12-31",
            ),
        )
        data = _assert_envelope(result)
        assert data["total_results"] == 2


# ---------------------------------------------------------------------------
# Overview tools
# ---------------------------------------------------------------------------


class TestLookup:
    async def test_lookup_success(self) -> None:
        result = _parse(
            await serve.uk_charity_lookup("202918"),
        )
        data = _assert_envelope(result)
        assert data["charity_number"] == 202918
        assert data["status"] == "Registered"
        assert data["_cleaning"]["status_mapped"] is True

    async def test_lookup_invalid_number(self) -> None:
        result = _parse(
            await serve.uk_charity_lookup("abc"),
        )
        _assert_error(result, "bad_request")


class TestProfile:
    async def test_profile_success(self) -> None:
        result = _parse(
            await serve.uk_charity_profile("202918"),
        )
        data = _assert_envelope(result)
        assert data["charity_number"] == 202918
        assert data["status"] == "Registered"
        assert data["contact"]["web"] == "https://www.oxfam.org.uk"
        assert data["companies_house_cross_ref"] is not None
        assert "related_endpoints" in data
        assert data["latest_income"] == 434500000

    async def test_profile_postcode_formatted(self) -> None:
        result = _parse(
            await serve.uk_charity_profile("202918"),
        )
        data = _assert_envelope(result)
        assert data["address"]["postcode"] is not None


class TestDetails:
    async def test_details_success(self) -> None:
        result = _parse(
            await serve.uk_charity_details("202918"),
        )
        data = _assert_envelope(result)
        assert data["charity_number"] == 202918
        assert data["flags"]["insolvent"] is False
        assert data["_cleaning"]["flags_labelled"] is True


class TestBatchLookup:
    async def test_batch_success(self) -> None:
        result = _parse(
            await serve.uk_charity_batch_lookup("202918"),
        )
        data = _assert_envelope(result)
        assert data["total_requested"] == 1
        assert data["total_found"] == 1

    async def test_batch_empty_input(self) -> None:
        result = _parse(
            await serve.uk_charity_batch_lookup(""),
        )
        _assert_error(result, "bad_request")


# ---------------------------------------------------------------------------
# Information tools
# ---------------------------------------------------------------------------


class TestTrustees:
    async def test_trustees_success(self) -> None:
        result = _parse(
            await serve.uk_charity_trustees("202918"),
        )
        data = _assert_envelope(result)
        assert data["total_trustees"] == 2
        assert data["chair_name"] is not None
        assert (
            data["_cleaning"]["chair_identified"] is True
        )
        assert (
            data["items"][0]["date_of_appointment"]
            == "2018-06-15"
        )


class TestTrusteeNames:
    async def test_trustee_names_success(self) -> None:
        result = _parse(
            await serve.uk_charity_trustee_names("202918"),
        )
        data = _assert_envelope(result)
        assert data["total_trustees"] == 2
        assert len(data["names"]) == 2


class TestClassifications:
    async def test_classifications_success(self) -> None:
        result = _parse(
            await serve.uk_charity_classifications("202918"),
        )
        data = _assert_envelope(result)
        assert len(data["what"]) == 1
        assert len(data["who"]) == 1
        assert (
            data["_cleaning"]["classifications_grouped"] is True
        )


class TestAreasOfOperation:
    async def test_areas_combined(self) -> None:
        result = _parse(
            await serve.uk_charity_areas_of_operation("202918"),
        )
        data = _assert_envelope(result)
        assert len(data["countries"]) == 1
        assert data["countries"][0]["continent"] == "Europe"
        assert data["regions"] == ["South East"]
        assert len(data["local_authorities"]) == 1
        assert data["_cleaning"]["areas_grouped"] is True


class TestContact:
    async def test_contact_normalised(self) -> None:
        result = _parse(
            await serve.uk_charity_contact("202918"),
        )
        data = _assert_envelope(result)
        assert data["web"] == "https://www.oxfam.org.uk"
        assert data["email"] == "info@oxfam.org.uk"
        assert data["_cleaning"]["url_normalised"] is True
        assert data["_cleaning"]["email_normalised"] is True


class TestConstituency:
    async def test_constituency_success(self) -> None:
        result = _parse(
            await serve.uk_charity_constituency("202918"),
        )
        data = _assert_envelope(result)
        assert data["constituency_name"] == "Oxford East"


class TestPolicies:
    async def test_policies_success(self) -> None:
        result = _parse(
            await serve.uk_charity_policies("202918"),
        )
        data = _assert_envelope(result)
        assert data["total_policies"] == 2
        assert "Safeguarding" in data["policies"]


class TestOtherRegulators:
    async def test_regulators_url_normalised(self) -> None:
        result = _parse(
            await serve.uk_charity_other_regulators("202918"),
        )
        data = _assert_envelope(result)
        assert data["total_regulators"] == 1
        assert (
            data["regulators"][0]["website"]
            == "https://www.fca.org.uk"
        )


class TestPrimaryGrants:
    async def test_primary_grants_success(self) -> None:
        result = _parse(
            await serve.uk_charity_primary_grants("202918"),
        )
        data = _assert_envelope(result)
        assert data["primary_purpose_grant_making"] is True


# ---------------------------------------------------------------------------
# Financial tools
# ---------------------------------------------------------------------------


class TestFinancialHistory:
    async def test_financial_history_success(self) -> None:
        result = _parse(
            await serve.uk_charity_financial_history("202918"),
        )
        data = _assert_envelope(result)
        assert len(data["periods"]) == 1
        assert data["periods"][0]["period_end"] == "2023-03-31"
        assert data["periods"][0]["income"] == 434500000


class TestAnnualReturn:
    async def test_annual_return_success(self) -> None:
        result = _parse(
            await serve.uk_charity_annual_return("202918"),
        )
        data = _assert_envelope(result)
        assert data["activities"] == "Fighting poverty"
        assert data["employees"] == 5000
        assert data["total_staff"] == 35000


class TestAccounts:
    async def test_accounts_success(self) -> None:
        result = _parse(
            await serve.uk_charity_accounts("202918"),
        )
        data = _assert_envelope(result)
        assert data["total_filings"] == 1
        assert (
            data["items"][0]["period_end"] == "2023-03-31"
        )


class TestAssets:
    async def test_assets_calculated(self) -> None:
        result = _parse(
            await serve.uk_charity_assets("202918"),
        )
        data = _assert_envelope(result)
        assert data["own_use_assets"] == 50000000
        assert data["net_assets"] == 40000000
        assert (
            data["_cleaning"]["net_assets_calculated"] is True
        )


# ---------------------------------------------------------------------------
# Governance tools
# ---------------------------------------------------------------------------


class TestGoverningDocument:
    async def test_governing_document_success(self) -> None:
        result = _parse(
            await serve.uk_charity_governing_document("202918"),
        )
        data = _assert_envelope(result)
        assert data["governing_document"] == "Trust deed"
        assert data["charitable_objects"] == "Relief of poverty"


class TestGovernance:
    async def test_governance_with_ch_link(self) -> None:
        result = _parse(
            await serve.uk_charity_governance("202918"),
        )
        data = _assert_envelope(result)
        assert data["gift_aid"] is True
        assert data["companies_house_cross_ref"] is not None
        assert (
            data["_cleaning"]["companies_house_linked"] is True
        )


class TestLinkedCharities:
    async def test_linked_charities_success(self) -> None:
        result = _parse(
            await serve.uk_charity_linked_charities("202918"),
        )
        data = _assert_envelope(result)
        assert data["total_linked"] == 1
        assert (
            data["items"][0]["charity_name"]
            == "OXFAM SUBSIDIARY"
        )


class TestOtherNames:
    async def test_other_names_success(self) -> None:
        result = _parse(
            await serve.uk_charity_other_names("202918"),
        )
        data = _assert_envelope(result)
        assert data["total_names"] == 2
        assert "Oxfam GB" in data["working_names"]
        assert (
            "Oxford Committee for Famine Relief"
            in data["previous_names"]
        )


class TestRegistrationHistory:
    async def test_registration_history_success(self) -> None:
        result = _parse(
            await serve.uk_charity_registration_history("202918"),
        )
        data = _assert_envelope(result)
        assert data["total_events"] == 1
        assert data["items"][0]["date"] == "1962-01-01"


# ---------------------------------------------------------------------------
# Regulatory tools
# ---------------------------------------------------------------------------


class TestRegulatoryReports:
    async def test_regulatory_reports_success(self) -> None:
        result = _parse(
            await serve.uk_charity_regulatory_reports("202918"),
        )
        data = _assert_envelope(result)
        assert data["total_reports"] == 1
        assert data["items"][0]["report_type"] == "inquiry"
        assert data["items"][0]["report_url"].startswith(
            "https://",
        )


class TestCioDissolution:
    async def test_cio_dissolution_success(self) -> None:
        result = _parse(
            await serve.uk_charity_cio_dissolution("202918"),
        )
        data = _assert_envelope(result)
        assert data["dissolution_notice_date"] == "2024-03-01"


# ---------------------------------------------------------------------------
# Sector tools
# ---------------------------------------------------------------------------


class TestSectorOverview:
    async def test_sector_overview_success(self) -> None:
        result = _parse(
            await serve.uk_charity_sector_overview(),
        )
        data = _assert_envelope(result)
        assert data["total_main_charities"] == 170000
        assert data["total_income"] == 85000000000
        assert (
            data["_cleaning"]["financials_structured"] is True
        )


class TestSectorTop10:
    async def test_sector_top10_success(self) -> None:
        result = _parse(
            await serve.uk_charity_sector_top10("income"),
        )
        data = _assert_envelope(result)
        assert len(data["items"]) == 1
        assert data["items"][0]["rank"] == 1
        assert data["items"][0]["charity_name"] == "OXFAM"

    async def test_sector_top10_invalid_type(self) -> None:
        result = _parse(
            await serve.uk_charity_sector_top10("invalid"),
        )
        _assert_error(result, "bad_request")


class TestSectorIncomeBands:
    async def test_sector_income_bands_success(self) -> None:
        result = _parse(
            await serve.uk_charity_sector_income_bands(),
        )
        data = _assert_envelope(result)
        assert len(data["bands"]) == 1
        assert data["bands"][0]["band"] == "0-10000"


class TestSectorIncomeCategories:
    async def test_income_categories_success(self) -> None:
        result = _parse(
            await serve.uk_charity_sector_income_categories(),
        )
        data = _assert_envelope(result)
        assert len(data["categories"]) == 1
        assert data["categories"][0]["category"] == "Education"


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    async def test_not_found_error(self) -> None:
        result = _parse(
            await serve.uk_charity_lookup("999999"),
        )
        _assert_error(result, "not_found")

    async def test_invalid_charity_number(self) -> None:
        result = _parse(
            await serve.uk_charity_lookup("abc"),
        )
        _assert_error(result, "bad_request")
