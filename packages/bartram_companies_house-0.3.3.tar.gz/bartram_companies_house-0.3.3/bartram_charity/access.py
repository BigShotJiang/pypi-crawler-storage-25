"""Charity Commission for England and Wales API client.

Endpoints: 31 tools covering search, overview, information, financial,
governance, regulatory, and sector data.
Auth: Ocp-Apim-Subscription-Key header (Azure API Management).
Rate limit: 30 requests per 10 seconds (conservative default).

Base URL: https://api.charitycommission.gov.uk/register/api/
"""

from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx
import yaml

from bartram_foundry.cache import ResponseCache
from bartram_foundry.http import retry_request

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_BASE_URL = "https://api.charitycommission.gov.uk/register/api/"
DEFAULT_RATE_LIMIT = 30
DEFAULT_RATE_PERIOD = 10  # seconds

_DEFAULT_CACHE_TTLS: dict[str, int] = {
    "search": 300,
    "lookup": 3600,
    "search_by_registration_date": 300,
    "search_by_removal_date": 300,
    "profile": 3600,
    "details": 3600,
    "batch_lookup": 3600,
    "trustees": 1800,
    "trustee_names": 1800,
    "classifications": 3600,
    "areas_of_operation_countries": 3600,
    "areas_of_operation_local_authorities": 3600,
    "areas_of_operation_regions": 3600,
    "contact": 3600,
    "constituency": 3600,
    "policies": 3600,
    "other_regulators": 3600,
    "primary_grants": 3600,
    "financial_history": 1800,
    "annual_return": 1800,
    "accounts": 1800,
    "assets": 1800,
    "governing_document": 3600,
    "governance": 3600,
    "linked_charities": 3600,
    "other_names": 3600,
    "registration_history": 3600,
    "regulatory_reports": 1800,
    "cio_dissolution": 3600,
    "sector_overview": 3600,
    "sector_top10": 1800,
    "sector_income_bands": 3600,
    "sector_income_categories": 3600,
}


def _load_cache_ttls() -> dict[str, int]:
    """Load cache TTLs from config.yaml if it exists."""
    config_path = Path(__file__).parent / "config.yaml"
    if config_path.exists():
        with open(config_path) as f:
            config = yaml.safe_load(f)
        return config.get("cache", {}).get("ttl_seconds", _DEFAULT_CACHE_TTLS)
    return dict(_DEFAULT_CACHE_TTLS)


@dataclass
class CharityConfig:
    """Configuration for the Charity Commission API client."""

    subscription_key: str = ""
    base_url: str = DEFAULT_BASE_URL
    rate_limit: int = DEFAULT_RATE_LIMIT
    rate_period: int = DEFAULT_RATE_PERIOD
    timeout: float = 30.0
    cache_enabled: bool = True

    @classmethod
    def from_env(cls) -> CharityConfig:
        """Create config from environment variables."""
        return cls(
            subscription_key=os.environ.get("CHARITY_COMMISSION_API_KEY", ""),
            base_url=os.environ.get("CHARITY_COMMISSION_BASE_URL", DEFAULT_BASE_URL),
            rate_limit=int(os.environ.get("CHARITY_COMMISSION_RATE_LIMIT", DEFAULT_RATE_LIMIT)),
            rate_period=int(os.environ.get("CHARITY_COMMISSION_RATE_PERIOD", DEFAULT_RATE_PERIOD)),
            timeout=float(os.environ.get("CHARITY_COMMISSION_TIMEOUT", "30.0")),
        )


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class CharityError(Exception):
    """Base exception for Charity Commission API errors."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class NotFoundError(CharityError):
    """Charity or resource not found (404)."""


class RateLimitError(CharityError):
    """Rate limit exceeded (429)."""


class AuthenticationError(CharityError):
    """Invalid or missing subscription key (401/403)."""


class ServerError(CharityError):
    """Upstream server error (5xx)."""


class BadRequestError(CharityError):
    """Invalid request parameters (400)."""


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------

_CHARITY_NUMBER_PATTERN = re.compile(r"^\d+$")


def validate_charity_number(value: str) -> int:
    """Validate and normalise a charity number.

    Strips whitespace and leading zeros, validates as positive integer.
    Returns the integer charity number.
    """
    if not value or not isinstance(value, str):
        raise BadRequestError("Charity number is required.")
    cleaned = value.strip().lstrip("0")
    if not cleaned:
        raise BadRequestError(f"Invalid charity number: '{value}'. Must be a positive integer.")
    if not _CHARITY_NUMBER_PATTERN.match(cleaned):
        raise BadRequestError(
            f"Invalid charity number: '{value}'. Must contain only digits."
        )
    num = int(cleaned)
    if num <= 0:
        raise BadRequestError(f"Invalid charity number: '{value}'. Must be a positive integer.")
    return num


def validate_date(value: str, field_name: str) -> str:
    """Validate a date string is in YYYY-MM-DD format."""
    if not value or not isinstance(value, str):
        raise BadRequestError(f"{field_name} is required.")
    value = value.strip()
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", value):
        raise BadRequestError(
            f"Invalid {field_name}: '{value}'. Expected format: YYYY-MM-DD."
        )
    return value


# ---------------------------------------------------------------------------
# Rate limiter
# ---------------------------------------------------------------------------


class _RateLimiter:
    """Token-bucket rate limiter."""

    def __init__(self, max_requests: int, period_seconds: int) -> None:
        self._max = max_requests
        self._period = period_seconds
        self._timestamps: list[float] = []

    def acquire(self) -> None:
        """Block until a request slot is available."""
        now = time.monotonic()
        cutoff = now - self._period
        self._timestamps = [t for t in self._timestamps if t > cutoff]
        if len(self._timestamps) >= self._max:
            sleep_time = self._timestamps[0] - cutoff
            if sleep_time > 0:
                time.sleep(sleep_time)
            self._timestamps = self._timestamps[1:]
        self._timestamps.append(time.monotonic())


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class CharityClient:
    """Charity Commission API client with caching, rate limiting, and retry."""

    def __init__(self, config: CharityConfig | None = None) -> None:
        self._config = config or CharityConfig.from_env()
        self._rate_limiter = _RateLimiter(
            self._config.rate_limit, self._config.rate_period
        )
        self._cache_ttls = _load_cache_ttls()
        self._cache = ResponseCache()
        self._http = httpx.Client(
            base_url=self._config.base_url,
            headers={"Ocp-Apim-Subscription-Key": self._config.subscription_key},
            timeout=self._config.timeout,
        )

    def close(self) -> None:
        """Close the HTTP client."""
        self._http.close()

    def _get(self, path: str, *, cache_key: str) -> tuple[Any, bool]:
        """Make a GET request with caching, rate limiting, and retry.

        Returns (data, cached) tuple.
        """
        if self._config.cache_enabled:
            cached = self._cache.get("charity_commission", path)
            if cached is not None:
                return cached, True

        self._rate_limiter.acquire()

        def _do_request() -> httpx.Response:
            return self._http.get(path)

        response = retry_request(_do_request)
        self._handle_status(response)
        data = response.json()
        if self._config.cache_enabled:
            ttl = self._cache_ttls.get(cache_key, 3600)
            self._cache.put(
                "charity_commission", path, data, ttl_seconds=ttl
            )
        return data, False

    def _handle_status(self, response: httpx.Response) -> None:
        """Raise appropriate exception for error status codes."""
        code = response.status_code
        if code == 200:
            return
        if code == 404:
            raise NotFoundError("Resource not found.", status_code=code)
        if code == 401 or code == 403:
            raise AuthenticationError(
                "Invalid or missing API subscription key.", status_code=code
            )
        if code == 429:
            raise RateLimitError("Rate limit exceeded.", status_code=code)
        if code == 400:
            raise BadRequestError("Bad request.", status_code=code)
        if code >= 500:
            raise ServerError(f"Server error ({code}).", status_code=code)
        raise CharityError(f"Unexpected status code: {code}.", status_code=code)

    # ------------------------------------------------------------------
    # Search endpoints (4)
    # ------------------------------------------------------------------

    def search(self, query: str) -> Any:
        """Search charities by name."""
        return self._get(
            f"searchCharityName/{query}",
            cache_key="search",
        )

    def search_by_registration_date(self, start_date: str, end_date: str) -> Any:
        """Search charities by registration date range."""
        return self._get(
            f"searchCharityRegDate/{start_date}/{end_date}",
            cache_key="search_by_registration_date",
        )

    def search_by_removal_date(self, start_date: str, end_date: str) -> Any:
        """Search charities by removal date range."""
        return self._get(
            f"searchCharityRemDate/{start_date}/{end_date}",
            cache_key="search_by_removal_date",
        )

    def lookup(self, charity_number: int, suffix: int = 0) -> Any:
        """Look up a charity by registered number."""
        return self._get(
            f"charityRegNumber/{charity_number}/{suffix}",
            cache_key="lookup",
        )

    # ------------------------------------------------------------------
    # Overview endpoints (3)
    # ------------------------------------------------------------------

    def profile(self, charity_number: int, suffix: int = 0) -> Any:
        """Get comprehensive charity details (V2 endpoint)."""
        return self._get(
            f"allcharitydetailsV2/{charity_number}/{suffix}",
            cache_key="profile",
        )

    def details(self, charity_number: int, suffix: int = 0) -> Any:
        """Get core charity details."""
        return self._get(
            f"charitydetails/{charity_number}/{suffix}",
            cache_key="details",
        )

    def batch_lookup(self, charity_numbers: str) -> Any:
        """Fetch details for multiple charities."""
        return self._get(
            f"charitydetailsmulti/{charity_numbers}",
            cache_key="batch_lookup",
        )

    # ------------------------------------------------------------------
    # Information endpoints (9)
    # ------------------------------------------------------------------

    def trustees(self, charity_number: int, suffix: int = 0) -> Any:
        """Get detailed trustee information (V2)."""
        return self._get(
            f"charitytrusteeinformationV2/{charity_number}/{suffix}",
            cache_key="trustees",
        )

    def trustee_names(self, charity_number: int, suffix: int = 0) -> Any:
        """Get trustee names only (V2)."""
        return self._get(
            f"charitytrusteenamesV2/{charity_number}/{suffix}",
            cache_key="trustee_names",
        )

    def classifications(self, charity_number: int, suffix: int = 0) -> Any:
        """Get What/Who/How classifications."""
        return self._get(
            f"charitywhowhathow/{charity_number}/{suffix}",
            cache_key="classifications",
        )

    def areas_of_operation_countries(self, charity_number: int, suffix: int = 0) -> Any:
        """Get areas of operation — countries and continents."""
        return self._get(
            f"CharityAoOCountryContinent/{charity_number}/{suffix}",
            cache_key="areas_of_operation_countries",
        )

    def areas_of_operation_local_authorities(
        self, charity_number: int, suffix: int = 0
    ) -> Any:
        """Get areas of operation — local authorities."""
        return self._get(
            f"charityaoolocalauthority/{charity_number}/{suffix}",
            cache_key="areas_of_operation_local_authorities",
        )

    def areas_of_operation_regions(self, charity_number: int, suffix: int = 0) -> Any:
        """Get areas of operation — regions."""
        return self._get(
            f"charityaooregion/{charity_number}/{suffix}",
            cache_key="areas_of_operation_regions",
        )

    def contact(self, charity_number: int, suffix: int = 0) -> Any:
        """Get contact information."""
        return self._get(
            f"charitycontactinformation/{charity_number}/{suffix}",
            cache_key="contact",
        )

    def constituency(self, charity_number: int, suffix: int = 0) -> Any:
        """Get parliamentary constituency."""
        return self._get(
            f"charityconstituency/{charity_number}/{suffix}",
            cache_key="constituency",
        )

    def policies(self, charity_number: int, suffix: int = 0) -> Any:
        """Get governance policies."""
        return self._get(
            f"charitypolicyinformation/{charity_number}/{suffix}",
            cache_key="policies",
        )

    # ------------------------------------------------------------------
    # Financial endpoints (4)
    # ------------------------------------------------------------------

    def financial_history(self, charity_number: int, suffix: int = 0) -> Any:
        """Get 5-year financial history."""
        return self._get(
            f"charityfinancialhistory/{charity_number}/{suffix}",
            cache_key="financial_history",
        )

    def annual_return(self, charity_number: int, suffix: int = 0) -> Any:
        """Get most recent Annual Return overview."""
        return self._get(
            f"charityoverview/{charity_number}/{suffix}",
            cache_key="annual_return",
        )

    def accounts(self, charity_number: int, suffix: int = 0) -> Any:
        """Get accounts and AR submission history."""
        return self._get(
            f"charityaraccounts/{charity_number}/{suffix}",
            cache_key="accounts",
        )

    def assets(self, charity_number: int, suffix: int = 0) -> Any:
        """Get assets and liabilities balance sheet."""
        return self._get(
            f"charityassetsliabilities/{charity_number}/{suffix}",
            cache_key="assets",
        )

    # ------------------------------------------------------------------
    # Governance endpoints (5)
    # ------------------------------------------------------------------

    def governing_document(self, charity_number: int, suffix: int = 0) -> Any:
        """Get governing document, charitable objects, area of benefit."""
        return self._get(
            f"charitygoverningdocument/{charity_number}/{suffix}",
            cache_key="governing_document",
        )

    def governance(self, charity_number: int, suffix: int = 0) -> Any:
        """Get governance summary."""
        return self._get(
            f"charitygovernanceinformation/{charity_number}/{suffix}",
            cache_key="governance",
        )

    def linked_charities(self, charity_number: int, suffix: int = 0) -> Any:
        """Get linked/subsidiary charities."""
        return self._get(
            f"linkedcharities/{charity_number}/{suffix}",
            cache_key="linked_charities",
        )

    def other_names(self, charity_number: int, suffix: int = 0) -> Any:
        """Get working and historical names."""
        return self._get(
            f"charityothernames/{charity_number}/{suffix}",
            cache_key="other_names",
        )

    def registration_history(self, charity_number: int, suffix: int = 0) -> Any:
        """Get registration event history."""
        return self._get(
            f"charityregistrationhistory/{charity_number}/{suffix}",
            cache_key="registration_history",
        )

    # ------------------------------------------------------------------
    # Regulatory endpoints (2)
    # ------------------------------------------------------------------

    def regulatory_reports(self, charity_number: int, suffix: int = 0) -> Any:
        """Get published regulatory reports."""
        return self._get(
            f"charityregulatoryreport/{charity_number}/{suffix}",
            cache_key="regulatory_reports",
        )

    def cio_dissolution(self, charity_number: int, suffix: int = 0) -> Any:
        """Get CIO dissolution notice."""
        return self._get(
            f"ciodissolution/{charity_number}/{suffix}",
            cache_key="cio_dissolution",
        )

    # ------------------------------------------------------------------
    # Other information endpoints
    # ------------------------------------------------------------------

    def other_regulators(self, charity_number: int, suffix: int = 0) -> Any:
        """Get other regulatory bodies overseeing this charity."""
        return self._get(
            f"CharityOtherRegulators/{charity_number}/{suffix}",
            cache_key="other_regulators",
        )

    def primary_grants(self, charity_number: int, suffix: int = 0) -> Any:
        """Check whether charity's primary purpose is grant-making."""
        return self._get(
            f"checkprimarygrants/{charity_number}/{suffix}",
            cache_key="primary_grants",
        )

    # ------------------------------------------------------------------
    # Sector endpoints (4)
    # ------------------------------------------------------------------

    def sector_overview(self) -> Any:
        """Get overall charity sector statistics."""
        return self._get("sectoroverview", cache_key="sector_overview")

    def sector_top10(self, list_type: str) -> Any:
        """Get top 10 charities by a specified metric."""
        return self._get(
            f"sectordatatop10/{list_type}",
            cache_key="sector_top10",
        )

    def sector_income_bands(self) -> Any:
        """Get sector data by income band."""
        return self._get("sectorincomeband", cache_key="sector_income_bands")

    def sector_income_categories(self) -> Any:
        """Get sector data by income category."""
        return self._get("sectorincomecategory", cache_key="sector_income_categories")
