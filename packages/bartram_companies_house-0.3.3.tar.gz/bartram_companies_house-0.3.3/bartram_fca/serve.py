"""MCP tool definitions for FCA Financial Services Register -- what agents call.

19 tools exposed:
- uk_fca_search: Search the FCA Register
- uk_fca_firm: Get firm details by FRN
- uk_fca_firm_names: Get firm brand/trading names
- uk_fca_firm_address: Get firm registered address
- uk_fca_firm_permissions: Get firm regulatory permissions
- uk_fca_firm_individuals: Get individuals at a firm
- uk_fca_firm_control_functions: Get control function holders
- uk_fca_firm_requirements: Get regulatory requirements
- uk_fca_firm_requirement_investment_types: Get investment types for a requirement
- uk_fca_firm_regulators: Get regulatory bodies for a firm
- uk_fca_firm_passports: Get EU/EEA passporting info
- uk_fca_firm_passport_permissions: Get passport permissions
- uk_fca_firm_appointed_reps: Get appointed representatives
- uk_fca_firm_waivers: Get regulatory waivers
- uk_fca_firm_exclusions: Get exclusions from regulation
- uk_fca_firm_disciplinary_history: Get disciplinary actions against a firm
- uk_fca_individual: Get individual details by IRN
- uk_fca_individual_control_functions: Get individual control function roles
- uk_fca_individual_disciplinary_history: Get disciplinary actions against an individual
"""

from __future__ import annotations

import json
import threading
import time
from datetime import datetime, timezone
from typing import Any

from mcp.server.fastmcp import FastMCP

from bartram_fca.access import (
    AuthenticationError,
    BadRequestError,
    FCAClient,
    FCAConfig,
    FCAError,
    NotFoundError,
    RateLimitError,
    ServerError,
    validate_frn,
    validate_irn,
)
from bartram_fca.clean import (
    clean_firm,
    clean_firm_address,
    clean_firm_appointed_reps,
    clean_firm_control_functions,
    clean_firm_disciplinary_history,
    clean_firm_exclusions,
    clean_firm_individuals,
    clean_firm_names,
    clean_firm_passport_permissions,
    clean_firm_passports,
    clean_firm_permissions,
    clean_firm_regulators,
    clean_firm_requirement_investment_types,
    clean_firm_requirements,
    clean_firm_waivers,
    clean_individual,
    clean_individual_control_functions,
    clean_individual_disciplinary_history,
    clean_search_results,
)
from bartram_foundry.monitoring import MetricsStore

# ---------------------------------------------------------------------------
# Server setup
# ---------------------------------------------------------------------------

server = FastMCP(
    "bartram-fca",
    instructions="FCA Financial Services Register data with cleaning and normalisation. "
    "19 tools covering firm search, details, names, addresses, permissions, "
    "individuals, control functions, requirements, regulators, passports, "
    "appointed representatives, waivers, exclusions, disciplinary history, "
    "and individual details/roles. "
    "Source: FCA Financial Services Register. Public record data.",
)

_client: FCAClient | None = None
_metrics: MetricsStore | None = None
_init_lock = threading.Lock()


def _get_client() -> FCAClient:
    """Get or create the API client (lazy initialisation, thread-safe)."""
    global _client
    if _client is None:
        with _init_lock:
            if _client is None:
                _client = FCAClient(FCAConfig.from_env())
    return _client


def _get_metrics() -> MetricsStore:
    """Get or create the metrics store (lazy initialisation, thread-safe)."""
    global _metrics
    if _metrics is None:
        with _init_lock:
            if _metrics is None:
                _metrics = MetricsStore()
    return _metrics


# ---------------------------------------------------------------------------
# Response formatting
# ---------------------------------------------------------------------------

_ATTRIBUTION = (
    "Source: FCA Financial Services Register. Contains public record data "
    "maintained by the Financial Conduct Authority."
)


def _format_response(data: Any, *, endpoint: str, cached: bool = False) -> str:
    """Format a cleaned API response as a JSON string with metadata."""
    envelope = {
        "data": data,
        "metadata": {
            "source": "FCA Financial Services Register",
            "licence": "FCA Public Record",
            "retrieved_at": datetime.now(tz=timezone.utc).isoformat(),
            "endpoint": endpoint,
            "cached": cached,
            "attribution": _ATTRIBUTION,
        },
    }
    return json.dumps(envelope, indent=2, default=str)


def _format_error(error: FCAError) -> str:
    """Format an API error as a JSON string."""
    result: dict[str, Any] = {
        "error": _error_type(error),
        "message": str(error),
        "attribution": _ATTRIBUTION,
    }
    if error.fca_status_code:
        result["fca_status_code"] = error.fca_status_code
    return json.dumps(result)


def _error_type(error: FCAError) -> str:
    """Map exception class to error type string."""
    if isinstance(error, NotFoundError):
        return "not_found"
    if isinstance(error, BadRequestError):
        return "bad_request"
    if isinstance(error, RateLimitError):
        return "rate_limited"
    if isinstance(error, AuthenticationError):
        return "auth_error"
    if isinstance(error, ServerError):
        return "server_error"
    return "error"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record(tool_name: str, start: float, *, success: bool, error: Exception | None = None) -> None:
    """Record a tool call metric."""
    duration_ms = (time.monotonic() - start) * 1000
    _get_metrics().record_call(
        tool_name,
        duration_ms,
        success=success,
        error_type=type(error).__name__ if error else None,
        error_message=str(error)[:500] if error else None,
    )


# ---------------------------------------------------------------------------
# Tools — Search (1)
# ---------------------------------------------------------------------------


@server.tool()
async def uk_fca_search(query: str, page: int = 1) -> str:
    """Search the FCA Register for firms, individuals, and regulated entities.

    Search by name, Firm Reference Number (FRN), Individual Reference Number (IRN),
    or keyword. Returns 20 results per page.
    Data source: FCA Financial Services Register (public record).
    """
    if not query or not query.strip():
        return json.dumps({
            "error": "bad_request",
            "message": "Search query is required.",
            "attribution": _ATTRIBUTION,
        })
    # Reject queries containing only special characters.
    stripped = query.strip()
    if all(c in "*'" for c in stripped):
        return json.dumps({
            "error": "bad_request",
            "message": "Query cannot contain only special characters (* or ').",
            "attribution": _ATTRIBUTION,
        })
    start = time.monotonic()
    try:
        client = _get_client()
        raw, cached = client.search(stripped, page=page)
        cleaned = clean_search_results(raw)
        result = _format_response(cleaned, endpoint="/CommonSearch", cached=cached)
        _record("uk_fca_search", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_search", start, success=False, error=exc)
        return _format_error(exc)


# ---------------------------------------------------------------------------
# Tools — Firm (15)
# ---------------------------------------------------------------------------


@server.tool()
async def uk_fca_firm(frn: str) -> str:
    """Get full details for an FCA-regulated firm by Firm Reference Number.

    Returns status, business type, regulatory dates, exceptional info,
    and links to sub-resources. FRN example: '615820'.
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        frn = validate_frn(frn)
        client = _get_client()
        raw, cached = client.get_firm(frn)
        cleaned = clean_firm(raw)
        result = _format_response(cleaned, endpoint=f"/Firm/{frn}", cached=cached)
        _record("uk_fca_firm", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_firm", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_fca_firm_names(frn: str) -> str:
    """Get brand and trading names for an FCA-regulated firm.

    Fetches all pages. Returns current and historical names.
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        frn = validate_frn(frn)
        client = _get_client()
        raw, cached = client.get_firm_names(frn)
        cleaned = clean_firm_names(raw)
        result = _format_response(cleaned, endpoint=f"/Firm/{frn}/Names", cached=cached)
        _record("uk_fca_firm_names", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_firm_names", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_fca_firm_address(frn: str) -> str:
    """Get the registered address and contact details for an FCA-regulated firm.

    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        frn = validate_frn(frn)
        client = _get_client()
        raw, cached = client.get_firm_address(frn)
        cleaned = clean_firm_address(raw)
        result = _format_response(cleaned, endpoint=f"/Firm/{frn}/Address", cached=cached)
        _record("uk_fca_firm_address", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_firm_address", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_fca_firm_permissions(frn: str) -> str:
    """Get regulatory permissions granted to an FCA-regulated firm.

    Fetches all pages — a partial permission list would be misleading.
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        frn = validate_frn(frn)
        client = _get_client()
        raw, cached = client.get_firm_permissions(frn)
        cleaned = clean_firm_permissions(raw)
        result = _format_response(cleaned, endpoint=f"/Firm/{frn}/Permissions", cached=cached)
        _record("uk_fca_firm_permissions", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_firm_permissions", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_fca_firm_individuals(frn: str) -> str:
    """Get all individuals associated with an FCA-regulated firm.

    Fetches all pages. Returns name, IRN, status, and role for each individual.
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        frn = validate_frn(frn)
        client = _get_client()
        raw, cached = client.get_firm_individuals(frn)
        cleaned = clean_firm_individuals(raw)
        result = _format_response(cleaned, endpoint=f"/Firm/{frn}/Individuals", cached=cached)
        _record("uk_fca_firm_individuals", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_firm_individuals", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_fca_firm_control_functions(frn: str) -> str:
    """Get control function holders for an FCA-regulated firm.

    Fetches all pages. Returns individuals holding controlled functions (CF roles).
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        frn = validate_frn(frn)
        client = _get_client()
        raw, cached = client.get_firm_control_functions(frn)
        cleaned = clean_firm_control_functions(raw)
        result = _format_response(cleaned, endpoint=f"/Firm/{frn}/CF", cached=cached)
        _record("uk_fca_firm_control_functions", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_firm_control_functions", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_fca_firm_requirements(frn: str) -> str:
    """Get regulatory requirements imposed on an FCA-regulated firm.

    Fetches all pages. Use requirement_reference values with
    uk_fca_firm_requirement_investment_types for drill-down.
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        frn = validate_frn(frn)
        client = _get_client()
        raw, cached = client.get_firm_requirements(frn)
        cleaned = clean_firm_requirements(raw)
        result = _format_response(cleaned, endpoint=f"/Firm/{frn}/Requirements", cached=cached)
        _record("uk_fca_firm_requirements", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_firm_requirements", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_fca_firm_requirement_investment_types(frn: str, requirement_ref: str) -> str:
    """Get investment types for a specific regulatory requirement on a firm.

    Use the requirement_reference from uk_fca_firm_requirements results.
    Fetches all pages.
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        frn = validate_frn(frn)
        requirement_ref = requirement_ref.strip()
        if not requirement_ref:
            return json.dumps({
                "error": "bad_request",
                "message": "requirement_ref is required.",
                "attribution": _ATTRIBUTION,
            })
        client = _get_client()
        raw, cached = client.get_firm_requirement_investment_types(frn, requirement_ref)
        cleaned = clean_firm_requirement_investment_types(raw)
        result = _format_response(
            cleaned,
            endpoint=f"/Firm/{frn}/Requirements/{requirement_ref}/InvestmentTypes",
            cached=cached,
        )
        _record("uk_fca_firm_requirement_investment_types", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_firm_requirement_investment_types", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_fca_firm_regulators(frn: str) -> str:
    """Get regulatory bodies associated with an FCA-regulated firm.

    Fetches all pages.
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        frn = validate_frn(frn)
        client = _get_client()
        raw, cached = client.get_firm_regulators(frn)
        cleaned = clean_firm_regulators(raw)
        result = _format_response(cleaned, endpoint=f"/Firm/{frn}/Regulators", cached=cached)
        _record("uk_fca_firm_regulators", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_firm_regulators", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_fca_firm_passports(frn: str) -> str:
    """Get EU/EEA passporting information for a firm (largely historical post-Brexit).

    Fetches all pages.
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        frn = validate_frn(frn)
        client = _get_client()
        raw, cached = client.get_firm_passports(frn)
        cleaned = clean_firm_passports(raw)
        result = _format_response(cleaned, endpoint=f"/Firm/{frn}/Passports", cached=cached)
        _record("uk_fca_firm_passports", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_firm_passports", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_fca_firm_passport_permissions(frn: str) -> str:
    """Get permissions held under a firm's EU/EEA passport.

    Note: this endpoint path is TBC and may not exist as a separate resource.
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        frn = validate_frn(frn)
        client = _get_client()
        raw, cached = client.get_firm_passport_permissions(frn)
        cleaned = clean_firm_passport_permissions(raw)
        result = _format_response(
            cleaned, endpoint=f"/Firm/{frn}/Passports/Permissions", cached=cached
        )
        _record("uk_fca_firm_passport_permissions", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_firm_passport_permissions", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_fca_firm_appointed_reps(frn: str) -> str:
    """Get appointed representatives of an FCA-regulated firm.

    Fetches all pages. Some firms have many appointed representatives.
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        frn = validate_frn(frn)
        client = _get_client()
        raw, cached = client.get_firm_appointed_reps(frn)
        cleaned = clean_firm_appointed_reps(raw)
        result = _format_response(cleaned, endpoint=f"/Firm/{frn}/AR", cached=cached)
        _record("uk_fca_firm_appointed_reps", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_firm_appointed_reps", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_fca_firm_waivers(frn: str) -> str:
    """Get regulatory waivers granted to an FCA-regulated firm.

    Fetches all pages.
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        frn = validate_frn(frn)
        client = _get_client()
        raw, cached = client.get_firm_waivers(frn)
        cleaned = clean_firm_waivers(raw)
        result = _format_response(cleaned, endpoint=f"/Firm/{frn}/Waivers", cached=cached)
        _record("uk_fca_firm_waivers", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_firm_waivers", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_fca_firm_exclusions(frn: str) -> str:
    """Get exclusions from regulation for an FCA-regulated firm.

    Fetches all pages.
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        frn = validate_frn(frn)
        client = _get_client()
        raw, cached = client.get_firm_exclusions(frn)
        cleaned = clean_firm_exclusions(raw)
        result = _format_response(cleaned, endpoint=f"/Firm/{frn}/Exclusions", cached=cached)
        _record("uk_fca_firm_exclusions", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_firm_exclusions", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_fca_firm_disciplinary_history(frn: str) -> str:
    """Get disciplinary actions taken against an FCA-regulated firm.

    Fetches all pages.
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        frn = validate_frn(frn)
        client = _get_client()
        raw, cached = client.get_firm_disciplinary_history(frn)
        cleaned = clean_firm_disciplinary_history(raw)
        result = _format_response(
            cleaned, endpoint=f"/Firm/{frn}/DisciplinaryHistory", cached=cached
        )
        _record("uk_fca_firm_disciplinary_history", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_firm_disciplinary_history", start, success=False, error=exc)
        return _format_error(exc)


# ---------------------------------------------------------------------------
# Tools — Individual (3)
# ---------------------------------------------------------------------------


@server.tool()
async def uk_fca_individual(irn: str) -> str:
    """Get details for an FCA-regulated individual by Individual Reference Number.

    Returns name, status, workplaces, and links to control functions and
    disciplinary history. IRN example: 'JXD01375'.
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        irn = validate_irn(irn)
        client = _get_client()
        raw, cached = client.get_individual(irn)
        cleaned = clean_individual(raw)
        result = _format_response(cleaned, endpoint=f"/Individuals/{irn}", cached=cached)
        _record("uk_fca_individual", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_individual", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_fca_individual_control_functions(irn: str) -> str:
    """Get control function roles held by an FCA-regulated individual.

    Fetches all pages. Returns firm name, FRN, control function, and status.
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        irn = validate_irn(irn)
        client = _get_client()
        raw, cached = client.get_individual_control_functions(irn)
        cleaned = clean_individual_control_functions(raw)
        result = _format_response(cleaned, endpoint=f"/Individuals/{irn}/CF", cached=cached)
        _record("uk_fca_individual_control_functions", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_individual_control_functions", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_fca_individual_disciplinary_history(irn: str) -> str:
    """Get disciplinary actions taken against an FCA-regulated individual.

    Fetches all pages.
    Data source: FCA Financial Services Register (public record).
    """
    start = time.monotonic()
    try:
        irn = validate_irn(irn)
        client = _get_client()
        raw, cached = client.get_individual_disciplinary_history(irn)
        cleaned = clean_individual_disciplinary_history(raw)
        result = _format_response(
            cleaned, endpoint=f"/Individuals/{irn}/DisciplinaryHistory", cached=cached
        )
        _record("uk_fca_individual_disciplinary_history", start, success=True)
        return result
    except FCAError as exc:
        _record("uk_fca_individual_disciplinary_history", start, success=False, error=exc)
        return _format_error(exc)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Run the FCA Register MCP server."""
    server.run()


if __name__ == "__main__":
    main()
