"""FCA Financial Services Register data cleaning logic.

FCA-specific cleaning for all 19 endpoints:
- Date normalisation (DD/MM/YYYY → ISO 8601)
- Field name normalisation (space-separated → snake_case)
- Pagination string → int conversion
- HATEOAS link replacement with related_endpoints
- Exceptional Info parsing (numbered notices)
- Trading name splitting (comma-separated → array)
- Workplace location flattening (numbered keys → array)
- Address normalisation and postcode formatting
- Control function code parsing (e.g. "(6865)SMF7 Group Entity Senior Manager")
- Data quality annotations (_cleaning)
"""

from __future__ import annotations

import re
from typing import Any

from bartram_foundry.cleaning import (
    normalise_address_line,
    normalise_postcode,
)

# ---------------------------------------------------------------------------
# Date normalisation (DD/MM/YYYY → ISO 8601)
# ---------------------------------------------------------------------------

_DATE_PATTERN = re.compile(r"^(\d{2})/(\d{2})/(\d{4})$")
_DATETIME_PATTERN = re.compile(r"^(\d{2})/(\d{2})/(\d{4})\s+(\d{2}):(\d{2})$")


def normalise_date(value: str) -> tuple[str, bool]:
    """Convert DD/MM/YYYY or DD/MM/YYYY HH:MM to ISO 8601. Returns (result, changed)."""
    if not value or not isinstance(value, str):
        return value, False

    match = _DATETIME_PATTERN.match(value.strip())
    if match:
        day, month, year, hour, minute = match.groups()
        return f"{year}-{month}-{day}T{hour}:{minute}:00", True

    match = _DATE_PATTERN.match(value.strip())
    if match:
        day, month, year = match.groups()
        return f"{year}-{month}-{day}", True

    return value, False


def _normalise_dates_in_dict(data: dict[str, Any]) -> bool:
    """Normalise all date-like string values in a dict. Returns True if any changed."""
    changed = False
    for key, value in list(data.items()):
        if isinstance(value, str):
            normalised, did_change = normalise_date(value)
            if did_change:
                data[key] = normalised
                changed = True
        elif isinstance(value, dict):
            if _normalise_dates_in_dict(value):
                changed = True
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict) and _normalise_dates_in_dict(item):
                    changed = True
    return changed


def _normalise_dates_in_list(items: list[Any]) -> bool:
    """Normalise dates in a list of dicts. Returns True if any changed."""
    changed = False
    for item in items:
        if isinstance(item, dict) and _normalise_dates_in_dict(item):
            changed = True
    return changed


# ---------------------------------------------------------------------------
# Field name normalisation (space-separated → snake_case)
# ---------------------------------------------------------------------------

_FIELD_NAME_SUBS = re.compile(r"[\s\-/]+")


def to_snake_case(name: str) -> str:
    """Convert a field name to snake_case."""
    # Handle CamelCase.
    name = re.sub(r"([a-z])([A-Z])", r"\1_\2", name)
    # Replace spaces, hyphens, slashes with underscores.
    name = _FIELD_NAME_SUBS.sub("_", name)
    return name.lower().strip("_")


def _normalise_field_names(data: dict[str, Any]) -> tuple[dict[str, Any], bool]:
    """Convert all keys to snake_case. Returns (new_dict, changed)."""
    new_data: dict[str, Any] = {}
    changed = False
    for key, value in data.items():
        new_key = to_snake_case(key)
        if new_key != key:
            changed = True
        if isinstance(value, dict):
            value, sub_changed = _normalise_field_names(value)
            changed = changed or sub_changed
        elif isinstance(value, list):
            new_list = []
            for item in value:
                if isinstance(item, dict):
                    item, sub_changed = _normalise_field_names(item)
                    changed = changed or sub_changed
                new_list.append(item)
            value = new_list
        new_data[new_key] = value
    return new_data, changed


# ---------------------------------------------------------------------------
# Pagination string → int conversion
# ---------------------------------------------------------------------------


def _normalise_result_info(data: dict[str, Any]) -> bool:
    """Convert ResultInfo string values to integers. Returns True if changed."""
    result_info = data.get("result_info") or data.get("ResultInfo")
    if not result_info or not isinstance(result_info, dict):
        return False
    changed = False
    for key in ("page", "per_page", "total_count"):
        snake_key = to_snake_case(key) if key in result_info else key
        for k in (key, snake_key):
            if k in result_info and isinstance(result_info[k], str):
                try:
                    result_info[k] = int(result_info[k])
                    changed = True
                except ValueError:
                    pass
    return changed


# ---------------------------------------------------------------------------
# HATEOAS link replacement
# ---------------------------------------------------------------------------

_FIRM_RELATED_ENDPOINTS: dict[str, str] = {
    "Names": "uk_fca_firm_names",
    "Name": "uk_fca_firm_names",
    "Address": "uk_fca_firm_address",
    "Individuals": "uk_fca_firm_individuals",
    "Permissions": "uk_fca_firm_permissions",
    "Requirements": "uk_fca_firm_requirements",
    "Regulators": "uk_fca_firm_regulators",
    "Passports": "uk_fca_firm_passports",
    "AR": "uk_fca_firm_appointed_reps",
    "Appointed Representative": "uk_fca_firm_appointed_reps",
    "Waivers": "uk_fca_firm_waivers",
    "Exclusions": "uk_fca_firm_exclusions",
    "DisciplinaryHistory": "uk_fca_firm_disciplinary_history",
    "CF": "uk_fca_firm_control_functions",
}

_INDIVIDUAL_RELATED_ENDPOINTS: dict[str, str] = {
    "CF": "uk_fca_individual_control_functions",
    "Current roles & activities": "uk_fca_individual_control_functions",
    "DisciplinaryHistory": "uk_fca_individual_disciplinary_history",
    "Disciplinary History": "uk_fca_individual_disciplinary_history",
}


def _replace_hateoas_links(
    data: dict[str, Any], mapping: dict[str, str]
) -> tuple[dict[str, str], bool]:
    """Extract HATEOAS links and replace with related_endpoints. Returns (endpoints, changed)."""
    endpoints: dict[str, str] = {}
    changed = False
    for key, tool_name in mapping.items():
        for data_key, value in list(data.items()):
            if isinstance(value, str) and key.lower() in data_key.lower() and "/" in value:
                snake = to_snake_case(key)
                endpoints[snake] = tool_name
                del data[data_key]
                changed = True
    return endpoints, changed


def _strip_url_fields(data: dict[str, Any]) -> bool:
    """Remove URL fields from a dict (HATEOAS links in list items). Returns True if changed."""
    changed = False
    for key in list(data.keys()):
        if key.lower() == "url" and isinstance(data[key], str) and "/" in data[key]:
            del data[key]
            changed = True
    return changed


# ---------------------------------------------------------------------------
# Exceptional Info parsing
# ---------------------------------------------------------------------------

_NUMBERED_ITEM = re.compile(r"(?:^|\s)(\d+)\.\s+")


def parse_exceptional_info(body: str) -> tuple[list[str], bool]:
    """Attempt to split numbered notices from exceptional info text.

    Returns (notices, was_parsed). If no numbered pattern, returns [body] and False.
    """
    if not body or not isinstance(body, str):
        return [body] if body else [], False

    parts = _NUMBERED_ITEM.split(body.strip())
    # parts will alternate: text-before-first-number, number, text, number, text, ...
    if len(parts) <= 1:
        return [body.strip()], False

    notices = []
    for i in range(1, len(parts), 2):
        text = parts[i + 1].strip() if i + 1 < len(parts) else ""
        if text:
            notices.append(text)

    return notices if notices else [body.strip()], bool(notices)


# ---------------------------------------------------------------------------
# Trading name splitting
# ---------------------------------------------------------------------------


def split_trading_names(value: str) -> tuple[list[str], bool]:
    """Split comma-separated trading names into a list. Returns (names, was_split)."""
    if not value or not isinstance(value, str):
        return [], False
    names = [n.strip() for n in value.split(",") if n.strip()]
    return names, len(names) > 1 or (len(names) == 1 and "," in value)


# ---------------------------------------------------------------------------
# Workplace flattening
# ---------------------------------------------------------------------------


def flatten_workplaces(data: dict[str, Any]) -> tuple[list[dict[str, Any]], bool]:
    """Flatten Workplace Location 1, Workplace Location 2, etc. into array.

    Handles gaps in numbering — scans all keys matching the pattern rather
    than stopping at the first missing number.
    """
    workplaces: list[dict[str, Any]] = []
    keys_to_remove: list[str] = []

    # Collect all workplace keys by scanning the full dict.
    workplace_keys: list[tuple[int, str]] = []
    for k in data:
        for prefix in ("Workplace Location ", "workplace_location_"):
            if k.startswith(prefix):
                suffix = k[len(prefix):]
                try:
                    idx = int(suffix)
                    workplace_keys.append((idx, k))
                except ValueError:
                    pass

    # Sort by index to maintain order.
    workplace_keys.sort(key=lambda x: x[0])

    for _, found_key in workplace_keys:
        value = data[found_key]
        if isinstance(value, dict):
            workplaces.append(value)
        elif isinstance(value, str) and value.strip():
            workplaces.append({"location": value})
        keys_to_remove.append(found_key)

    for key in keys_to_remove:
        del data[key]

    return workplaces, bool(keys_to_remove)


# ---------------------------------------------------------------------------
# Address cleaning
# ---------------------------------------------------------------------------


def clean_address_fields(data: dict[str, Any]) -> bool:
    """Normalise address fields and format postcodes. Returns True if changed."""
    changed = False
    address_keys = [k for k in data if "address" in k.lower() or "line" in k.lower()]
    for key in address_keys:
        value = data[key]
        if isinstance(value, str) and value.strip():
            normalised = normalise_address_line(value)
            if normalised != value:
                data[key] = normalised
                changed = True

    postcode_keys = [k for k in data if "postcode" in k.lower() or "post_code" in k.lower()]
    for key in postcode_keys:
        value = data[key]
        if isinstance(value, str) and value.strip():
            formatted = normalise_postcode(value)
            if formatted != value:
                data[key] = formatted
                changed = True

    return changed


# ---------------------------------------------------------------------------
# Control function code parsing
# ---------------------------------------------------------------------------

_CF_CODE_PATTERN = re.compile(r"^\((\d+)\)\s*(.+)$")


def parse_cf_code(entry: str) -> dict[str, str]:
    """Parse a CF code entry like '(6865)SMF7 Group Entity Senior Manager'.

    Returns dict with id, code, and description fields.
    """
    entry = entry.strip()
    match = _CF_CODE_PATTERN.match(entry)
    if not match:
        return {"raw": entry}

    cf_id = match.group(1)
    rest = match.group(2).strip()

    # Try to split code from description (e.g. "SMF7 Group Entity Senior Manager").
    code_match = re.match(r"^(\[?[A-Z][A-Za-z0-9 \[\]]+?\]?\s*(?:CF|SMF)\d+[a-z]?)\s+(.+)$", rest)
    if not code_match:
        # Try simpler: first token is the code.
        parts = rest.split(None, 1)
        if len(parts) == 2:
            return {"id": cf_id, "code": parts[0], "description": parts[1]}
        return {"id": cf_id, "raw": rest}

    return {"id": cf_id, "code": code_match.group(1), "description": code_match.group(2)}


def _clean_cf_entries(entries: list[str]) -> list[dict[str, str]]:
    """Parse a list of CF code strings into structured objects."""
    return [parse_cf_code(e) for e in entries if isinstance(e, str) and e.strip()]


def _clean_cf_dict(entries: dict[str, Any]) -> list[dict[str, str]]:
    """Parse a dict of CF code entries (keyed by code string) into structured objects."""
    result = []
    for key in entries:
        parsed = parse_cf_code(key)
        value = entries[key]
        if isinstance(value, dict):
            parsed.update(value)
        result.append(parsed)
    return result


# ---------------------------------------------------------------------------
# Null data guard
# ---------------------------------------------------------------------------


def _guard_null_data(data: dict[str, Any]) -> dict[str, Any] | None:
    """If Data is null/None, return a minimal cleaned response. Otherwise return None."""
    raw_data = data.get("Data") or data.get("data")
    if raw_data is None:
        result, _ = _normalise_field_names(data)
        result["_cleaning"] = {"no_data": True}
        return result
    return None


# ---------------------------------------------------------------------------
# Per-endpoint cleaning functions (19 total)
# ---------------------------------------------------------------------------


def clean_search_results(data: dict[str, Any]) -> dict[str, Any]:
    """Clean search results from /CommonSearch."""
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    _normalise_result_info(data)

    # Split trading names in items.
    items = data.get("data", data.get("results", []))
    if isinstance(items, list):
        for item in items:
            if isinstance(item, dict):
                trading = item.get("trading_name") or item.get("TradingName", "")
                if trading:
                    names, was_split = split_trading_names(trading)
                    item["trading_names"] = names
                    if was_split:
                        cleaning["trading_names_split"] = True
                    for k in ("trading_name", "TradingName"):
                        item.pop(k, None)
                _strip_url_fields(item)

    data["_cleaning"] = cleaning
    return data


def clean_firm(data: dict[str, Any]) -> dict[str, Any]:
    """Clean firm details from /Firm/{FRN}.

    Real structure: Data is a list of 1 item with HATEOAS links + fields.
    We unwrap the inner item and merge it into the top-level response.
    """
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    # Unwrap Data[0] if present (firm details are always a single-item list).
    raw_data = data.get("Data")
    if isinstance(raw_data, list) and len(raw_data) == 1 and isinstance(raw_data[0], dict):
        inner = raw_data[0]
        # Replace HATEOAS links BEFORE field normalisation (uses original key names).
        endpoints, hateoas_changed = _replace_hateoas_links(inner, _FIRM_RELATED_ENDPOINTS)
        if hateoas_changed:
            cleaning["hateoas_replaced"] = True
        # Merge inner into data, replacing the Data key.
        data.pop("Data")
        data.update(inner)
        if endpoints:
            data["related_endpoints"] = endpoints
        cleaning["data_unwrapped"] = True

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    # Parse exceptional info.
    ei_key = None
    for key in list(data.keys()):
        if "exceptional" in key.lower() and "detail" in key.lower():
            ei_key = key
            break
    if ei_key is not None:
        ei_val = data[ei_key]
        if isinstance(ei_val, list):
            # Each item may have a body to parse.
            for item in ei_val:
                if isinstance(item, dict):
                    for bk in list(item.keys()):
                        if "body" in bk.lower():
                            notices, was_parsed = parse_exceptional_info(item[bk])
                            item["notices"] = notices
                            if was_parsed:
                                cleaning["exceptional_info_parsed"] = True
                            else:
                                cleaning["exceptional_info_raw"] = True
        elif isinstance(ei_val, str):
            notices, was_parsed = parse_exceptional_info(ei_val)
            if was_parsed:
                cleaning["exceptional_info_parsed"] = True
            else:
                cleaning["exceptional_info_raw"] = True
            data[ei_key] = notices

    # Convert empty string fields to None.
    for key, value in data.items():
        if isinstance(value, str) and not value.strip():
            data[key] = None

    data["_cleaning"] = cleaning
    return data


def clean_firm_names(data: dict[str, Any]) -> dict[str, Any]:
    """Clean firm names from /Firm/{FRN}/Names.

    Real structure: Data is a list with items like:
    {"Current Names": [{"Name": ..., "Effective From": ..., "Status": ...}]}
    {"Previous Names": [...]}
    We flatten into a single names list with a current/previous flag.
    """
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    raw_data = data.get("Data")
    if isinstance(raw_data, list):
        all_names: list[dict[str, Any]] = []
        for item in raw_data:
            if isinstance(item, dict):
                for group_key, names_list in item.items():
                    if isinstance(names_list, list):
                        is_current = "current" in group_key.lower()
                        for name_rec in names_list:
                            if isinstance(name_rec, dict):
                                name_rec["current"] = is_current
                                all_names.append(name_rec)
        if all_names:
            data["Data"] = all_names
            cleaning["names_flattened"] = True

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    _normalise_result_info(data)

    data["_cleaning"] = cleaning
    return data


def clean_firm_address(data: dict[str, Any]) -> dict[str, Any]:
    """Clean firm address from /Firm/{FRN}/Address.

    Real structure: Data is a list of address items with fields like
    Address Line 1, Postcode, Town, etc.
    """
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    # Clean address fields in each item before field normalisation.
    raw_data = data.get("Data")
    if isinstance(raw_data, list):
        for item in raw_data:
            if isinstance(item, dict):
                addr_changed = clean_address_fields(item)
                if addr_changed:
                    cleaning["address_normalised"] = True
                _strip_url_fields(item)

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    data["_cleaning"] = cleaning
    return data


def clean_firm_permissions(data: dict[str, Any]) -> dict[str, Any]:
    """Clean firm permissions from /Firm/{FRN}/Permissions.

    Real structure: Data is a dict keyed by permission name, each value is
    a list of limitation dicts.
    """
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    raw_data = data.get("Data")
    if isinstance(raw_data, dict):
        # Restructure: dict-keyed permissions → list of {permission, limitations}.
        permissions_list = []
        for perm_name, limitations in raw_data.items():
            entry: dict[str, Any] = {"permission": perm_name}
            if isinstance(limitations, list):
                entry["limitations"] = limitations
            elif isinstance(limitations, dict):
                entry["limitations"] = [limitations]
            else:
                entry["limitations"] = []
            permissions_list.append(entry)
        data["Data"] = permissions_list
        cleaning["permissions_restructured"] = True

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    _normalise_result_info(data)

    data["_cleaning"] = cleaning
    return data


def clean_firm_individuals(data: dict[str, Any]) -> dict[str, Any]:
    """Clean firm individuals from /Firm/{FRN}/Individuals.

    Each item has URL (HATEOAS link), IRN, Name, Status.
    Strip URL fields and ensure IRN is prominent.
    """
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    raw_data = data.get("Data")
    if isinstance(raw_data, list):
        for item in raw_data:
            if isinstance(item, dict):
                _strip_url_fields(item)

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    _normalise_result_info(data)

    data["_cleaning"] = cleaning
    return data


def clean_firm_control_functions(data: dict[str, Any]) -> dict[str, Any]:
    """Clean firm control functions from /Firm/{FRN}/CF.

    Real structure: Data[0] has Current (list of CF code strings) and
    Previous (list of CF code strings). Parse these into structured objects.
    """
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    raw_data = data.get("Data")
    if isinstance(raw_data, list) and raw_data:
        item = raw_data[0] if isinstance(raw_data[0], dict) else {}
        current = item.get("Current", [])
        previous = item.get("Previous", [])

        parsed: dict[str, Any] = {}
        if isinstance(current, list):
            parsed["current"] = _clean_cf_entries(current)
        elif isinstance(current, dict):
            parsed["current"] = _clean_cf_dict(current)

        if isinstance(previous, list):
            parsed["previous"] = _clean_cf_entries(previous)
        elif isinstance(previous, dict):
            parsed["previous"] = _clean_cf_dict(previous)

        if parsed:
            data["Data"] = parsed
            cleaning["cf_parsed"] = True

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    _normalise_result_info(data)

    data["_cleaning"] = cleaning
    return data


def clean_firm_requirements(data: dict[str, Any]) -> dict[str, Any]:
    """Clean firm requirements from /Firm/{FRN}/Requirements."""
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    _normalise_result_info(data)

    data["_cleaning"] = cleaning
    return data


def clean_firm_requirement_investment_types(data: dict[str, Any]) -> dict[str, Any]:
    """Clean firm requirement investment types."""
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    _normalise_result_info(data)

    data["_cleaning"] = cleaning
    return data


def clean_firm_regulators(data: dict[str, Any]) -> dict[str, Any]:
    """Clean firm regulators from /Firm/{FRN}/Regulators."""
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    raw_data = data.get("Data")
    if isinstance(raw_data, list):
        for item in raw_data:
            if isinstance(item, dict):
                # Convert empty date strings to None.
                for key, value in list(item.items()):
                    if isinstance(value, str) and not value.strip():
                        item[key] = None

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    _normalise_result_info(data)

    data["_cleaning"] = cleaning
    return data


def clean_firm_passports(data: dict[str, Any]) -> dict[str, Any]:
    """Clean firm passports from /Firm/{FRN}/Passports."""
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    _normalise_result_info(data)

    data["_cleaning"] = cleaning
    return data


def clean_firm_passport_permissions(data: dict[str, Any]) -> dict[str, Any]:
    """Clean firm passport permissions."""
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    _normalise_result_info(data)

    data["_cleaning"] = cleaning
    return data


def clean_firm_appointed_reps(data: dict[str, Any]) -> dict[str, Any]:
    """Clean firm appointed representatives from /Firm/{FRN}/AR.

    Real structure: Data is a dict with CurrentAppointedRepresentatives
    and PreviousAppointedRepresentatives lists. Each item has URL, FRN,
    Principal Firm Name, dates, etc. Strip URLs and restructure.
    """
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    raw_data = data.get("Data")
    if isinstance(raw_data, dict):
        # Clean items within each list.
        for list_key in list(raw_data.keys()):
            items = raw_data[list_key]
            if isinstance(items, list):
                for item in items:
                    if isinstance(item, dict):
                        _strip_url_fields(item)

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    _normalise_result_info(data)

    data["_cleaning"] = cleaning
    return data


def clean_firm_waivers(data: dict[str, Any]) -> dict[str, Any]:
    """Clean firm waivers from /Firm/{FRN}/Waivers."""
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    _normalise_result_info(data)

    data["_cleaning"] = cleaning
    return data


def clean_firm_exclusions(data: dict[str, Any]) -> dict[str, Any]:
    """Clean firm exclusions from /Firm/{FRN}/Exclusions."""
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    _normalise_result_info(data)

    data["_cleaning"] = cleaning
    return data


def clean_firm_disciplinary_history(data: dict[str, Any]) -> dict[str, Any]:
    """Clean firm disciplinary history from /Firm/{FRN}/DisciplinaryHistory."""
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    _normalise_result_info(data)

    data["_cleaning"] = cleaning
    return data


def clean_individual(data: dict[str, Any]) -> dict[str, Any]:
    """Clean individual details from /Individuals/{IRN}.

    Real structure: Data[0]["Details"] contains the actual individual data
    with HATEOAS links and workplace locations.
    """
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    # Unwrap Data[0]["Details"] if present.
    raw_data = data.get("Data")
    if isinstance(raw_data, list) and raw_data:
        item = raw_data[0]
        if isinstance(item, dict) and "Details" in item:
            inner = item["Details"]
            if isinstance(inner, dict):
                data.pop("Data")
                data.update(inner)
                cleaning["data_unwrapped"] = True

    # Flatten workplaces before field normalisation (uses original key names).
    workplaces, wp_changed = flatten_workplaces(data)
    if wp_changed:
        data["workplaces"] = workplaces
        cleaning["workplaces_flattened"] = True

    # Replace HATEOAS links BEFORE field normalisation (uses original key names).
    endpoints, hateoas_changed = _replace_hateoas_links(data, _INDIVIDUAL_RELATED_ENDPOINTS)
    if hateoas_changed:
        data["related_endpoints"] = endpoints
        cleaning["hateoas_replaced"] = True

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    data["_cleaning"] = cleaning
    return data


def clean_individual_control_functions(data: dict[str, Any]) -> dict[str, Any]:
    """Clean individual control functions from /Individuals/{IRN}/CF.

    Real structure: Data[0] has Current and/or Previous, which may be
    lists of CF code strings or dicts keyed by CF code strings.
    """
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    raw_data = data.get("Data")
    if isinstance(raw_data, list) and raw_data:
        item = raw_data[0] if isinstance(raw_data[0], dict) else {}
        current = item.get("Current")
        previous = item.get("Previous")

        parsed: dict[str, Any] = {}
        if isinstance(current, list):
            parsed["current"] = _clean_cf_entries(current)
        elif isinstance(current, dict):
            parsed["current"] = _clean_cf_dict(current)

        if isinstance(previous, list):
            parsed["previous"] = _clean_cf_entries(previous)
        elif isinstance(previous, dict):
            parsed["previous"] = _clean_cf_dict(previous)

        if parsed:
            data["Data"] = parsed
            cleaning["cf_parsed"] = True

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    _normalise_result_info(data)

    data["_cleaning"] = cleaning
    return data


def clean_individual_disciplinary_history(data: dict[str, Any]) -> dict[str, Any]:
    """Clean individual disciplinary history from /Individuals/{IRN}/DisciplinaryHistory."""
    guarded = _guard_null_data(data)
    if guarded is not None:
        return guarded

    cleaning: dict[str, Any] = {}

    data, fields_changed = _normalise_field_names(data)
    if fields_changed:
        cleaning["fields_normalised"] = True

    dates_changed = _normalise_dates_in_dict(data)
    if dates_changed:
        cleaning["dates_normalised"] = True

    _normalise_result_info(data)

    data["_cleaning"] = cleaning
    return data
