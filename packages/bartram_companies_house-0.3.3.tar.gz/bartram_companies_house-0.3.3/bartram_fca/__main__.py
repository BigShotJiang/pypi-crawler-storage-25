"""Entry point for running the FCA Register MCP server.

Usage:
    python -m bartram_fca
    uvx bartram-fca
"""

from bartram_fca.serve import main

if __name__ == "__main__":
    main()
