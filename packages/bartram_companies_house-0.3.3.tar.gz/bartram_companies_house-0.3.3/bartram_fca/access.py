"""FCA Financial Services Register API client.

Endpoints: 19 total (1 search, 15 firm, 3 individual).
Auth: Custom headers (X-AUTH-EMAIL + X-AUTH-KEY).
Rate limit: 50 requests per 10 seconds (1-minute block on breach).

Live-validated response patterns:
- All responses have: Status, ResultInfo (may be null), Message, Data.
- Data may be: list, dict, or null.
- Firm details: Data is a list of 1 item containing HATEOAS URLs + fields.
- Sub-resources: Data is a list of items, OR a dict (permissions, AR, CF).
- Pagination uses ?pgnp=N (not ?page=N). Next page URL is in ResultInfo.Next.
- Status -00 = success, -11 = no data/not found, -21 = bad request.
"""

from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

import httpx
import yaml

from bartram_foundry.cache import ResponseCache
from bartram_foundry.http import retry_request

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_BASE_URL = "https://register.fca.org.uk/services/V0.1"
DEFAULT_RATE_LIMIT = 50
DEFAULT_RATE_PERIOD = 10  # seconds
DEFAULT_BLOCK_DURATION = 60  # seconds

_DEFAULT_CACHE_TTLS: dict[str, int] = {
    "search": 300,
    "firm": 3600,
    "firm_names": 3600,
    "firm_address": 3600,
    "firm_permissions": 1800,
    "firm_individuals": 1800,
    "firm_control_functions": 1800,
    "firm_requirements": 1800,
    "firm_requirement_investment_types": 1800,
    "firm_regulators": 3600,
    "firm_passports": 3600,
    "firm_passport_permissions": 3600,
    "firm_appointed_reps": 1800,
    "firm_waivers": 1800,
    "firm_exclusions": 1800,
    "firm_disciplinary_history": 1800,
    "individual": 3600,
    "individual_control_functions": 1800,
    "individual_disciplinary_history": 1800,
}


def _load_cache_ttls() -> dict[str, int]:
    """Load cache TTLs from config.yaml if it exists."""
    config_path = Path(__file__).parent / "config.yaml"
    if config_path.exists():
        with open(config_path) as f:
            config = yaml.safe_load(f)
        return config.get("cache", {}).get("ttl_seconds", _DEFAULT_CACHE_TTLS)
    return dict(_DEFAULT_CACHE_TTLS)


@dataclass
class FCAConfig:
    """Configuration for the FCA Register API client."""

    auth_email: str = ""
    auth_key: str = ""
    base_url: str = DEFAULT_BASE_URL
    rate_limit: int = DEFAULT_RATE_LIMIT
    rate_period: int = DEFAULT_RATE_PERIOD
    block_duration: int = DEFAULT_BLOCK_DURATION
    timeout: float = 30.0
    cache_enabled: bool = True

    @classmethod
    def from_env(cls) -> FCAConfig:
        """Create config from environment variables."""
        auth_email = (
            os.environ.get("FCA_AUTH_EMAIL", "")
            or os.environ.get("FCA_API_EMAIL", "")
        )
        auth_key = (
            os.environ.get("FCA_AUTH_KEY", "")
            or os.environ.get("FCA_API_KEY", "")
        )
        if not auth_email or not auth_key:
            msg = (
                "FCA API credentials not found. Set either FCA_API_EMAIL + FCA_API_KEY "
                "or FCA_AUTH_EMAIL + FCA_AUTH_KEY in your environment. "
                "Use 'export $(cat .env | xargs)' to load from .env. "
                "Register at https://register.fca.org.uk/Developer/s/ for credentials."
            )
            raise ValueError(msg)
        return cls(auth_email=auth_email, auth_key=auth_key)


# ---------------------------------------------------------------------------
# Rate limiter (sliding window with block detection)
# ---------------------------------------------------------------------------


@dataclass
class RateLimiter:
    """Sliding-window rate limiter with block-aware backoff.

    The FCA API imposes a 1-minute block if the rate limit is breached.
    """

    max_requests: int = DEFAULT_RATE_LIMIT
    period_seconds: int = DEFAULT_RATE_PERIOD
    block_duration: int = DEFAULT_BLOCK_DURATION
    _timestamps: list[float] = field(default_factory=list)
    _blocked_until: float = 0.0

    def wait_if_needed(self) -> None:
        """Block until a request is allowed."""
        now = time.monotonic()

        # If we're in a block period, wait it out.
        if now < self._blocked_until:
            time.sleep(self._blocked_until - now)
            now = time.monotonic()

        # Trim timestamps outside the window.
        cutoff = now - self.period_seconds
        self._timestamps = [t for t in self._timestamps if t > cutoff]

        # If at the limit, wait for the oldest to expire.
        if len(self._timestamps) >= self.max_requests:
            wait_time = self._timestamps[0] - cutoff
            if wait_time > 0:
                time.sleep(wait_time)
            self._timestamps = self._timestamps[1:]

        self._timestamps.append(time.monotonic())

    def record_block(self) -> None:
        """Record that the API has blocked us."""
        self._blocked_until = time.monotonic() + self.block_duration


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class FCAError(Exception):
    """Base error for FCA API issues."""

    def __init__(
        self, message: str, status_code: int = 0, fca_status_code: str = ""
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.fca_status_code = fca_status_code


class NotFoundError(FCAError):
    """Resource not found."""


class BadRequestError(FCAError):
    """Invalid request parameters."""


class RateLimitError(FCAError):
    """Rate limit exceeded (1-minute block)."""


class AuthenticationError(FCAError):
    """Authentication failed."""


class ServerError(FCAError):
    """FCA API server error."""


# ---------------------------------------------------------------------------
# FRN / IRN normalisation
# ---------------------------------------------------------------------------


def normalise_frn(frn: str) -> str:
    """Normalise an FCA Firm Reference Number.

    Strips whitespace and non-numeric characters.
    """
    return re.sub(r"[^0-9]", "", frn.strip())


def normalise_irn(irn: str) -> str:
    """Normalise an FCA Individual Reference Number.

    Strips whitespace and uppercases letters. IRN format: letters + digits.
    """
    return irn.strip().upper()


def validate_frn(frn: str) -> str:
    """Validate and normalise an FRN. Raises BadRequestError if invalid."""
    normalised = normalise_frn(frn)
    if not normalised:
        raise BadRequestError(
            "FRN is required. Provide a numeric Firm Reference Number."
        )
    if not normalised.isdigit():
        raise BadRequestError(f"FRN must be numeric, got: {frn!r}")
    return normalised


def validate_irn(irn: str) -> str:
    """Validate and normalise an IRN. Raises BadRequestError if invalid."""
    normalised = normalise_irn(irn)
    if not normalised:
        raise BadRequestError(
            "IRN is required. Provide an Individual Reference Number."
        )
    if not re.match(r"^[A-Z]+\d+$", normalised):
        raise BadRequestError(
            f"IRN must be letters followed by digits (e.g. 'JXD01375'), "
            f"got: {irn!r}"
        )
    return normalised


# ---------------------------------------------------------------------------
# FCA status code parsing
# ---------------------------------------------------------------------------

# FCA response Status field: FSR-API-XX-YY-ZZ where ZZ indicates outcome.
# -00 = success, -11 = no data / not found, -21 = bad request / invalid input.
_SUCCESS_SUFFIX = "-00"
_NO_DATA_SUFFIX = "-11"
_BAD_REQUEST_SUFFIX = "-21"


def _is_success(status_code: str) -> bool:
    """Check if an FCA status code indicates success."""
    return status_code.endswith(_SUCCESS_SUFFIX)


def _is_no_data(status_code: str) -> bool:
    """Check if an FCA status code means no data / not found."""
    return status_code.endswith(_NO_DATA_SUFFIX)


def _raise_for_fca_status(
    data: dict[str, Any], *, context: str = "", raise_on_no_data: bool = True
) -> None:
    """Raise appropriate error based on FCA status code.

    Args:
        data: The parsed JSON response.
        context: Description for error messages (e.g. endpoint path).
        raise_on_no_data: If True, -11 raises NotFoundError.
            If False, -11 is treated as a valid empty response (for search
            and sub-resource endpoints where "no data" is normal).
    """
    status = data.get("Status", "")
    if not status or _is_success(status):
        return

    message = data.get("Message") or f"FCA API error: {status}"
    if context:
        message = f"{context}: {message}"

    # -11: no data / not found
    if _is_no_data(status):
        if raise_on_no_data:
            raise NotFoundError(message, fca_status_code=status)
        return  # Treat as valid empty response.

    # -21: bad request / invalid input
    if status.endswith(_BAD_REQUEST_SUFFIX):
        raise BadRequestError(message, fca_status_code=status)

    # -03: rate limited (if FCA ever sends this)
    if status.endswith("-03"):
        raise RateLimitError(message, fca_status_code=status)

    # -01 in auth position: authentication error
    # (not all -01 suffixes are auth errors — only when it's the final segment)
    # For safety, treat any unrecognised non-success status as a generic error.
    raise FCAError(message, fca_status_code=status)


# ---------------------------------------------------------------------------
# API client
# ---------------------------------------------------------------------------


class FCAClient:
    """FCA Financial Services Register API client.

    Handles authentication, rate limiting, caching, pagination, and error mapping.
    """

    def __init__(self, config: FCAConfig) -> None:
        self._config = config
        self._rate_limiter = RateLimiter(
            max_requests=config.rate_limit,
            period_seconds=config.rate_period,
            block_duration=config.block_duration,
        )
        self._cache = ResponseCache()
        self._cache_ttls = _load_cache_ttls()
        self._client = httpx.Client(
            base_url=config.base_url,
            headers={
                "X-AUTH-EMAIL": config.auth_email,
                "X-AUTH-KEY": config.auth_key,
                "Content-Type": "application/json",
            },
            timeout=config.timeout,
        )

    def __enter__(self) -> FCAClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self._client.close()

    # -- Internal helpers ---------------------------------------------------

    def _get(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        *,
        raise_on_no_data: bool = True,
    ) -> dict[str, Any]:
        """Make a rate-limited GET request to the FCA API.

        Retries up to 2 times on timeouts and network errors with exponential backoff.
        """
        self._rate_limiter.wait_if_needed()

        def _do_request() -> httpx.Response:
            return self._client.get(path, params=params)

        try:
            response = retry_request(_do_request, max_retries=2, base_delay=1.0)
        except httpx.TimeoutException as exc:
            raise FCAError(f"Request timed out (after retries): {path}") from exc
        except httpx.HTTPError as exc:
            raise FCAError(f"HTTP error: {exc}") from exc

        if response.status_code == 429:
            self._rate_limiter.record_block()
            raise RateLimitError(
                "Rate limit exceeded. Blocked for 60 seconds."
            )

        if response.status_code == 401:
            raise AuthenticationError(
                "Authentication failed. Check FCA_AUTH_EMAIL and FCA_AUTH_KEY."
            )

        if response.status_code >= 500:
            raise ServerError(f"FCA server error: {response.status_code}")

        try:
            data = response.json()
        except ValueError as exc:
            raise FCAError(f"Invalid JSON response from {path}") from exc

        # FCA uses custom status codes in the JSON body, not HTTP status.
        _raise_for_fca_status(
            data, context=path, raise_on_no_data=raise_on_no_data
        )

        return data

    def _cached_get(
        self,
        path: str,
        cache_key: str,
        params: dict[str, Any] | None = None,
        *,
        raise_on_no_data: bool = True,
        force_refresh: bool = False,
    ) -> tuple[dict[str, Any], bool]:
        """GET with caching. Returns (data, from_cache).

        If force_refresh is True, bypasses the cache and fetches fresh data.
        """
        ttl = self._cache_ttls.get(cache_key, 300)
        if self._config.cache_enabled and not force_refresh:
            cached = self._cache.get("fca", path, params)
            if cached is not None:
                return cached, True
        data = self._get(path, params, raise_on_no_data=raise_on_no_data)
        if self._config.cache_enabled:
            self._cache.put(
                "fca", path, data, ttl_seconds=ttl, params=params
            )
        return data, False

    def _paginate_all(
        self,
        path: str,
        cache_key: str,
        params: dict[str, Any] | None = None,
    ) -> tuple[dict[str, Any], bool]:
        """Fetch all pages of a paginated endpoint. Cache the complete result.

        FCA uses ?pgnp=N for pagination. The Next page URL is in
        ResultInfo.Next. Sub-resource endpoints that return no data (-11)
        are treated as valid empty responses, not errors.
        """
        # Use a sentinel param to distinguish paginated cache entries.
        cache_params = dict(params or {})
        cache_params["_paginated"] = "all"
        if self._config.cache_enabled:
            cached = self._cache.get("fca", path, cache_params)
            if cached is not None:
                return cached, True

        # Fetch first page. Don't raise on -11 — empty sub-resources are normal.
        first_page = self._get(
            path, params, raise_on_no_data=False
        )

        # If no data, return as-is.
        if first_page.get("Data") is None:
            if self._config.cache_enabled:
                ttl = self._cache_ttls.get(cache_key, 300)
                self._cache.put(
                    "fca", path, first_page,
                    ttl_seconds=ttl, params=cache_params,
                )
            return first_page, False

        # Check for Next page URL in ResultInfo.
        result_info = first_page.get("ResultInfo") or {}
        next_url = result_info.get("Next")

        if not next_url:
            # Single page — cache and return.
            if self._config.cache_enabled:
                ttl = self._cache_ttls.get(cache_key, 300)
                self._cache.put(
                    "fca", path, first_page,
                    ttl_seconds=ttl, params=cache_params,
                )
            return first_page, False

        # Multi-page: collect all Data across pages.
        all_data = first_page["Data"]
        seen_pages: set[str] = set()
        max_pages = 500  # Safety valve against infinite pagination loops.

        while next_url:
            # Extract pgnp parameter from the Next URL.
            parsed = urlparse(next_url)
            qs = parse_qs(parsed.query)
            pgnp = qs.get("pgnp", [None])[0]
            if pgnp is None:
                break

            # Guard against infinite loops (same page requested twice).
            if pgnp in seen_pages:
                break
            seen_pages.add(pgnp)

            if len(seen_pages) >= max_pages:
                break

            page_params = dict(params or {})
            page_params["pgnp"] = pgnp
            page_data = self._get(
                path, page_params, raise_on_no_data=False
            )

            page_items = page_data.get("Data")
            if page_items is None:
                break

            # Merge page data.
            if isinstance(all_data, list) and isinstance(page_items, list):
                all_data.extend(page_items)
            elif isinstance(all_data, dict) and isinstance(page_items, dict):
                # Dict-style data (permissions, AR): merge keys.
                for k, v in page_items.items():
                    if k in all_data and isinstance(all_data[k], list):
                        all_data[k].extend(v if isinstance(v, list) else [v])
                    else:
                        all_data[k] = v

            # Check for next page.
            page_ri = page_data.get("ResultInfo") or {}
            next_url = page_ri.get("Next")

        # Build complete response.
        complete = dict(first_page)
        complete["Data"] = all_data
        # Update ResultInfo to reflect total fetched.
        if result_info:
            complete["ResultInfo"] = dict(result_info)
            complete["ResultInfo"].pop("Next", None)
            complete["ResultInfo"].pop("Previous", None)
            if isinstance(all_data, list):
                complete["ResultInfo"]["total_count"] = str(len(all_data))

        if self._config.cache_enabled:
            ttl = self._cache_ttls.get(cache_key, 300)
            self._cache.put(
                "fca", path, complete,
                ttl_seconds=ttl, params=cache_params,
            )

        return complete, False

    # -- Public API (19 endpoints) ------------------------------------------

    # 1. Search
    def search(
        self, query: str, page: int = 1
    ) -> tuple[dict[str, Any], bool]:
        """Search the FCA Register. Returns (data, from_cache).

        Search returning no results is a valid empty response, not an error.
        """
        return self._cached_get(
            "/CommonSearch",
            cache_key="search",
            params={"q": query},
            raise_on_no_data=False,
        )

    # 2. Firm Details
    def get_firm(self, frn: str) -> tuple[dict[str, Any], bool]:
        """Get firm details by FRN. Returns (data, from_cache)."""
        return self._cached_get(f"/Firm/{frn}", cache_key="firm")

    # 3. Firm Names
    def get_firm_names(self, frn: str) -> tuple[dict[str, Any], bool]:
        """Get firm brand/trading names. Returns (data, from_cache)."""
        return self._paginate_all(f"/Firm/{frn}/Names", cache_key="firm_names")

    # 4. Firm Address
    def get_firm_address(self, frn: str) -> tuple[dict[str, Any], bool]:
        """Get firm registered address. Returns (data, from_cache)."""
        return self._cached_get(
            f"/Firm/{frn}/Address",
            cache_key="firm_address",
            raise_on_no_data=False,
        )

    # 5. Firm Permissions
    def get_firm_permissions(
        self, frn: str
    ) -> tuple[dict[str, Any], bool]:
        """Get firm regulatory permissions. Returns (data, from_cache)."""
        return self._paginate_all(
            f"/Firm/{frn}/Permissions", cache_key="firm_permissions"
        )

    # 6. Firm Individuals
    def get_firm_individuals(
        self, frn: str
    ) -> tuple[dict[str, Any], bool]:
        """Get individuals associated with a firm. Returns (data, from_cache)."""
        return self._paginate_all(
            f"/Firm/{frn}/Individuals", cache_key="firm_individuals"
        )

    # 7. Firm Control Functions
    def get_firm_control_functions(
        self, frn: str
    ) -> tuple[dict[str, Any], bool]:
        """Get control function holders for a firm. Returns (data, from_cache)."""
        return self._paginate_all(
            f"/Firm/{frn}/CF", cache_key="firm_control_functions"
        )

    # 8. Firm Requirements
    def get_firm_requirements(
        self, frn: str
    ) -> tuple[dict[str, Any], bool]:
        """Get regulatory requirements for a firm. Returns (data, from_cache)."""
        return self._paginate_all(
            f"/Firm/{frn}/Requirements", cache_key="firm_requirements"
        )

    # 9. Firm Requirement Investment Types
    def get_firm_requirement_investment_types(
        self, frn: str, requirement_ref: str
    ) -> tuple[dict[str, Any], bool]:
        """Get investment types for a requirement. Returns (data, from_cache)."""
        return self._paginate_all(
            f"/Firm/{frn}/Requirements/{requirement_ref}/InvestmentTypes",
            cache_key="firm_requirement_investment_types",
        )

    # 10. Firm Regulators
    def get_firm_regulators(
        self, frn: str
    ) -> tuple[dict[str, Any], bool]:
        """Get regulatory bodies for a firm. Returns (data, from_cache)."""
        return self._paginate_all(
            f"/Firm/{frn}/Regulators", cache_key="firm_regulators"
        )

    # 11. Firm Passports
    def get_firm_passports(
        self, frn: str
    ) -> tuple[dict[str, Any], bool]:
        """Get EU/EEA passporting info for a firm. Returns (data, from_cache)."""
        return self._paginate_all(
            f"/Firm/{frn}/Passports", cache_key="firm_passports"
        )

    # 12. Firm Passport Permissions
    def get_firm_passport_permissions(
        self, frn: str
    ) -> tuple[dict[str, Any], bool]:
        """Get passport permissions for a firm. Returns (data, from_cache).

        Note: endpoint path TBC — may not exist as a separate resource.
        """
        return self._paginate_all(
            f"/Firm/{frn}/Passports/Permissions",
            cache_key="firm_passport_permissions",
        )

    # 13. Firm Appointed Representatives
    def get_firm_appointed_reps(
        self, frn: str
    ) -> tuple[dict[str, Any], bool]:
        """Get appointed representatives. Returns (data, from_cache)."""
        return self._paginate_all(
            f"/Firm/{frn}/AR", cache_key="firm_appointed_reps"
        )

    # 14. Firm Waivers
    def get_firm_waivers(
        self, frn: str
    ) -> tuple[dict[str, Any], bool]:
        """Get regulatory waivers for a firm. Returns (data, from_cache)."""
        return self._paginate_all(
            f"/Firm/{frn}/Waivers", cache_key="firm_waivers"
        )

    # 15. Firm Exclusions
    def get_firm_exclusions(
        self, frn: str
    ) -> tuple[dict[str, Any], bool]:
        """Get exclusions from regulation. Returns (data, from_cache)."""
        return self._paginate_all(
            f"/Firm/{frn}/Exclusions", cache_key="firm_exclusions"
        )

    # 16. Firm Disciplinary History
    def get_firm_disciplinary_history(
        self, frn: str
    ) -> tuple[dict[str, Any], bool]:
        """Get disciplinary actions against a firm. Returns (data, from_cache)."""
        return self._paginate_all(
            f"/Firm/{frn}/DisciplinaryHistory",
            cache_key="firm_disciplinary_history",
        )

    # 17. Individual Details
    def get_individual(
        self, irn: str
    ) -> tuple[dict[str, Any], bool]:
        """Get individual details by IRN. Returns (data, from_cache)."""
        return self._cached_get(
            f"/Individuals/{irn}", cache_key="individual"
        )

    # 18. Individual Control Functions
    def get_individual_control_functions(
        self, irn: str
    ) -> tuple[dict[str, Any], bool]:
        """Get control functions held by an individual. Returns (data, from_cache)."""
        return self._paginate_all(
            f"/Individuals/{irn}/CF",
            cache_key="individual_control_functions",
        )

    # 19. Individual Disciplinary History
    def get_individual_disciplinary_history(
        self, irn: str
    ) -> tuple[dict[str, Any], bool]:
        """Get disciplinary actions against an individual. Returns (data, from_cache)."""
        return self._paginate_all(
            f"/Individuals/{irn}/DisciplinaryHistory",
            cache_key="individual_disciplinary_history",
        )
