"""Tests for FCA Financial Services Register API client.

Uses httpx mock transport to return fixture data from real API responses.
Covers all 19 endpoints, error handling, pagination, and caching.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import httpx
import pytest

from bartram_fca.access import (
    AuthenticationError,
    BadRequestError,
    FCAClient,
    FCAConfig,
    FCAError,
    NotFoundError,
    RateLimitError,
    ServerError,
    normalise_frn,
    normalise_irn,
    validate_frn,
    validate_irn,
)

FIXTURES = Path(__file__).parent / "fixtures"


def load_fixture(name: str) -> dict:
    """Load a JSON fixture file."""
    return json.loads((FIXTURES / name).read_text())


# ---------------------------------------------------------------------------
# Mock transport
# ---------------------------------------------------------------------------


class MockTransport(httpx.BaseTransport):
    """Returns canned responses for known paths, 404 for unknown."""

    def __init__(self) -> None:
        self.routes: dict[str, tuple[int, dict]] = {}
        self.request_log: list[httpx.Request] = []

    PREFIX = "/services/V0.1"

    def add_route(
        self, path: str, fixture_name: str, status: int = 200
    ) -> None:
        self.routes[self.PREFIX + path] = (status, load_fixture(fixture_name))

    def add_json_route(
        self, path: str, data: dict, status: int = 200
    ) -> None:
        self.routes[self.PREFIX + path] = (status, data)

    def add_error_route(
        self, path: str, status: int, body: str = ""
    ) -> None:
        self.routes[self.PREFIX + path] = (status, {"error": body})

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        self.request_log.append(request)
        full_path = request.url.raw_path.decode()
        path = full_path.split("?")[0]
        # Check full path+query first (for paginated route overrides),
        # then fall back to path-only matching.
        if full_path in self.routes:
            status, data = self.routes[full_path]
            return httpx.Response(status, json=data)
        if path in self.routes:
            status, data = self.routes[path]
            return httpx.Response(status, json=data)
        # Return a valid FCA "no data" response for unmatched routes.
        # This prevents pagination from hanging when fixtures have Next URLs
        # pointing to pages we haven't mocked.
        return httpx.Response(200, json={
            "Status": "FSR-API-00-00-11",
            "ResultInfo": None,
            "Message": "No data found",
            "Data": None,
        })


def make_client(transport: MockTransport) -> FCAClient:
    """Create a client with a mock transport (caching disabled)."""
    config = FCAConfig(
        auth_email="test@test.com",
        auth_key="test-key",
        cache_enabled=False,
    )
    client = FCAClient(config)
    client._client = httpx.Client(
        transport=transport, base_url=config.base_url
    )
    return client


# ---------------------------------------------------------------------------
# Tests — FRN normalisation
# ---------------------------------------------------------------------------


class TestNormaliseFrn:
    def test_strips_whitespace(self) -> None:
        assert normalise_frn("  615820  ") == "615820"

    def test_strips_non_numeric(self) -> None:
        assert normalise_frn("FRN-615820") == "615820"

    def test_already_clean(self) -> None:
        assert normalise_frn("615820") == "615820"

    def test_empty(self) -> None:
        assert normalise_frn("") == ""

    def test_dashes_and_spaces(self) -> None:
        assert normalise_frn("  6158-20  ") == "615820"


class TestValidateFrn:
    def test_valid(self) -> None:
        assert validate_frn("615820") == "615820"

    def test_strips_and_validates(self) -> None:
        assert validate_frn("  FRN-615820  ") == "615820"

    def test_empty_raises(self) -> None:
        with pytest.raises(BadRequestError):
            validate_frn("")

    def test_all_letters_raises(self) -> None:
        with pytest.raises(BadRequestError):
            validate_frn("abc")


# ---------------------------------------------------------------------------
# Tests — IRN normalisation
# ---------------------------------------------------------------------------


class TestNormaliseIrn:
    def test_strips_and_uppercases(self) -> None:
        assert normalise_irn("  jxd01375  ") == "JXD01375"

    def test_already_clean(self) -> None:
        assert normalise_irn("JXD01375") == "JXD01375"


class TestValidateIrn:
    def test_valid(self) -> None:
        assert validate_irn("JXD01375") == "JXD01375"

    def test_lowercase_normalised(self) -> None:
        assert validate_irn("jxd01375") == "JXD01375"

    def test_empty_raises(self) -> None:
        with pytest.raises(BadRequestError):
            validate_irn("")

    def test_digits_only_raises(self) -> None:
        with pytest.raises(BadRequestError):
            validate_irn("12345")

    def test_letters_only_raises(self) -> None:
        with pytest.raises(BadRequestError):
            validate_irn("ABC")


# ---------------------------------------------------------------------------
# Tests — Search endpoint
# ---------------------------------------------------------------------------


class TestSearch:
    def test_search_empty_results(self) -> None:
        transport = MockTransport()
        transport.add_route("/CommonSearch", "search_barclays.json")
        client = make_client(transport)

        data, cached = client.search("Barclays")
        assert data["Status"] == "FSR-API-06-04-11"
        assert data["Data"] is None
        assert cached is False

    def test_search_passes_query_param(self) -> None:
        transport = MockTransport()
        transport.add_route("/CommonSearch", "search_barclays.json")
        client = make_client(transport)

        client.search("test query")
        req = transport.request_log[-1]
        assert b"q=test" in req.url.raw_path


# ---------------------------------------------------------------------------
# Tests — Firm endpoints
# ---------------------------------------------------------------------------


class TestGetFirm:
    def test_firm_success(self) -> None:
        transport = MockTransport()
        transport.add_route("/Firm/615820", "firm_615820.json")
        client = make_client(transport)

        data, _ = client.get_firm("615820")
        assert data["Status"].endswith("-00")
        assert isinstance(data["Data"], list)
        assert len(data["Data"]) == 1
        detail = data["Data"][0]
        assert detail["FRN"] == "615820"
        assert detail["Organisation Name"] == "A & T Exchange Ltd"

    def test_firm_not_found(self) -> None:
        transport = MockTransport()
        transport.add_route("/Firm/999999999", "firm_not_found.json")
        client = make_client(transport)

        with pytest.raises(NotFoundError) as exc_info:
            client.get_firm("999999999")
        assert exc_info.value.fca_status_code == "FSR-API-02-01-11"

    def test_firm_has_hateoas_links(self) -> None:
        transport = MockTransport()
        transport.add_route("/Firm/122702", "firm_122702.json")
        client = make_client(transport)

        data, _ = client.get_firm("122702")
        detail = data["Data"][0]
        # HATEOAS links are URLs.
        assert "https://" in detail["Name"]
        assert "https://" in detail["Individuals"]


class TestGetFirmNames:
    def test_returns_names(self) -> None:
        transport = MockTransport()
        transport.add_route("/Firm/122702/Names", "firm_names_122702.json")
        client = make_client(transport)

        data, _cached = client.get_firm_names("122702")
        assert data["Status"].endswith("-00")
        assert isinstance(data["Data"], list)


class TestGetFirmAddress:
    def test_returns_address(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/Firm/122702/Address", "firm_address_122702.json"
        )
        client = make_client(transport)

        data, _cached = client.get_firm_address("122702")
        assert data["Status"].endswith("-00")
        assert isinstance(data["Data"], list)


class TestGetFirmPermissions:
    def test_returns_permissions_dict(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/Firm/122702/Permissions", "firm_permissions_122702.json"
        )
        client = make_client(transport)

        data, _cached = client.get_firm_permissions("122702")
        assert data["Status"].endswith("-00")
        # Permissions Data is a dict keyed by permission name.
        assert isinstance(data["Data"], dict)


class TestGetFirmIndividuals:
    def test_returns_individuals(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/Firm/122702/Individuals", "firm_individuals_122702.json"
        )
        client = make_client(transport)

        data, _cached = client.get_firm_individuals("122702")
        assert data["Status"].endswith("-00")
        assert isinstance(data["Data"], list)
        assert len(data["Data"]) > 0
        assert "IRN" in data["Data"][0]


class TestGetFirmControlFunctions:
    def test_returns_cf(self) -> None:
        transport = MockTransport()
        transport.add_route("/Firm/122702/CF", "firm_cf_122702.json")
        client = make_client(transport)

        data, _cached = client.get_firm_control_functions("122702")
        assert data["Status"].endswith("-00")


class TestGetFirmRequirements:
    def test_returns_requirements(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/Firm/122702/Requirements", "firm_requirements_122702.json"
        )
        client = make_client(transport)

        data, _cached = client.get_firm_requirements("122702")
        assert data["Status"].endswith("-00")
        assert isinstance(data["Data"], list)


class TestGetFirmRegulators:
    def test_returns_regulators(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/Firm/122702/Regulators", "firm_regulators_122702.json"
        )
        client = make_client(transport)

        data, _cached = client.get_firm_regulators("122702")
        assert data["Status"].endswith("-00")
        assert isinstance(data["Data"], list)


class TestGetFirmPassports:
    def test_returns_passports(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/Firm/122702/Passports", "firm_passports_122702.json"
        )
        client = make_client(transport)

        data, _cached = client.get_firm_passports("122702")
        assert data["Status"].endswith("-00")


class TestGetFirmAppointedReps:
    def test_returns_ar_dict(self) -> None:
        transport = MockTransport()
        transport.add_route("/Firm/122702/AR", "firm_ar_122702.json")
        client = make_client(transport)

        data, _cached = client.get_firm_appointed_reps("122702")
        assert data["Status"].endswith("-00")
        # AR Data is a dict with Current/Previous keys.
        assert isinstance(data["Data"], dict)
        assert "CurrentAppointedRepresentatives" in data["Data"]


class TestGetFirmWaivers:
    def test_returns_waivers(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/Firm/122702/Waivers", "firm_waivers_122702.json"
        )
        client = make_client(transport)

        data, _cached = client.get_firm_waivers("122702")
        assert data["Status"].endswith("-00")
        assert isinstance(data["Data"], list)


class TestGetFirmExclusions:
    def test_returns_exclusions(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/Firm/122702/Exclusions", "firm_exclusions_122702.json"
        )
        client = make_client(transport)

        data, _cached = client.get_firm_exclusions("122702")
        assert data["Status"].endswith("-00")


class TestGetFirmDisciplinaryHistory:
    def test_returns_disciplinary(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/Firm/122702/DisciplinaryHistory",
            "firm_disciplinary_122702.json",
        )
        client = make_client(transport)

        data, _cached = client.get_firm_disciplinary_history("122702")
        assert data["Status"].endswith("-00")
        assert isinstance(data["Data"], list)


class TestGetFirmRequirementInvestmentTypes:
    def test_no_data_returns_null(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/Firm/122702/Requirements/REF1/InvestmentTypes",
            "firm_req_invtypes_122702.json",
        )
        client = make_client(transport)

        data, _cached = client.get_firm_requirement_investment_types(
            "122702", "REF1"
        )
        # This fixture has -11 status (no investment types) — returned as valid empty.
        assert data["Data"] is None


# ---------------------------------------------------------------------------
# Tests — Individual endpoints
# ---------------------------------------------------------------------------


class TestGetIndividual:
    def test_individual_success(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/Individuals/JXD01375", "individual_jxd01375.json"
        )
        client = make_client(transport)

        data, _cached = client.get_individual("JXD01375")
        assert data["Status"].endswith("-00")
        details = data["Data"][0]["Details"]
        assert details["IRN"] == "JXD01375"
        assert details["Full Name"] == "Julia Dubovskaya-Saunes"

    def test_individual_not_found(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/Individuals/ZZZZZZZ99999", "individual_not_found.json"
        )
        client = make_client(transport)

        with pytest.raises(NotFoundError):
            client.get_individual("ZZZZZZZ99999")

    def test_individual_has_hateoas_links(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/Individuals/JXD01375", "individual_jxd01375.json"
        )
        client = make_client(transport)

        data, _ = client.get_individual("JXD01375")
        details = data["Data"][0]["Details"]
        assert "https://" in details["Disciplinary History"]
        assert "https://" in details["Current roles & activities"]


class TestGetIndividualControlFunctions:
    def test_returns_cf(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/Individuals/JXD01375/CF", "individual_cf_jxd01375.json"
        )
        client = make_client(transport)

        data, _cached = client.get_individual_control_functions("JXD01375")
        assert data["Status"].endswith("-00")


class TestGetIndividualDisciplinaryHistory:
    def test_no_data_returns_null(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/Individuals/JXD01375/DisciplinaryHistory",
            "individual_dh_jxd01375.json",
        )
        client = make_client(transport)

        data, _cached = client.get_individual_disciplinary_history("JXD01375")
        # -11 status (no disciplinary history) — valid empty response.
        assert data["Data"] is None


# ---------------------------------------------------------------------------
# Tests — Error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_http_401_raises_auth_error(self) -> None:
        transport = MockTransport()
        transport.add_error_route("/Firm/123", 401)
        client = make_client(transport)

        with pytest.raises(AuthenticationError):
            client.get_firm("123")

    def test_http_429_raises_rate_limit(self) -> None:
        transport = MockTransport()
        transport.add_error_route("/Firm/123", 429)
        client = make_client(transport)

        with pytest.raises(RateLimitError):
            client.get_firm("123")

    def test_http_500_raises_server_error(self) -> None:
        transport = MockTransport()
        transport.add_error_route("/Firm/123", 500)
        client = make_client(transport)

        with pytest.raises(ServerError):
            client.get_firm("123")

    def test_fca_bad_request_status(self) -> None:
        transport = MockTransport()
        transport.add_json_route(
            "/CommonSearch",
            {
                "Status": "FSR-API-06-04-21",
                "ResultInfo": None,
                "Message": "Bad request. Invalid input",
                "Data": None,
            },
        )
        client = make_client(transport)

        with pytest.raises(BadRequestError) as exc_info:
            client.search("*")
        assert "FSR-API-06-04-21" in exc_info.value.fca_status_code

    def test_timeout_raises_fca_error(self) -> None:
        """Timeout raises FCAError."""

        class TimeoutTransport(httpx.BaseTransport):
            def handle_request(self, request: httpx.Request) -> httpx.Response:
                raise httpx.TimeoutException("timed out")

        config = FCAConfig(
            auth_email="t@t.com", auth_key="k", cache_enabled=False
        )
        client = FCAClient(config)
        client._client = httpx.Client(
            transport=TimeoutTransport(), base_url=config.base_url
        )

        with pytest.raises(FCAError, match="timed out"):
            client.get_firm("123")


# ---------------------------------------------------------------------------
# Tests — Pagination
# ---------------------------------------------------------------------------


class TestPagination:
    def test_single_page_no_next(self) -> None:
        """Single-page response (no Next URL) returns data as-is."""
        transport = MockTransport()
        transport.add_route(
            "/Firm/122702/Regulators", "firm_regulators_122702.json"
        )
        client = make_client(transport)

        data, _cached = client.get_firm_regulators("122702")
        assert isinstance(data["Data"], list)
        # Only one request made (no pagination).
        assert len(transport.request_log) == 1

    def test_multi_page_follows_next(self) -> None:
        """Multi-page response follows Next URLs and merges Data."""
        transport = MockTransport()

        # Page 1: has Next URL.
        page1 = {
            "Status": "FSR-API-02-05-00",
            "ResultInfo": {
                "page": "1",
                "per_page": "2",
                "total_count": "4",
                "Next": "https://register.fca.org.uk/services/V0.1"
                "/Firm/123/Individuals?pgnp=2",
            },
            "Message": "",
            "Data": [
                {"IRN": "AAA111", "Name": "Person A"},
                {"IRN": "BBB222", "Name": "Person B"},
            ],
        }
        # Page 2: no Next URL (last page).
        page2 = {
            "Status": "FSR-API-02-05-00",
            "ResultInfo": {
                "page": "2",
                "per_page": "2",
                "total_count": "4",
                "Previous": "https://register.fca.org.uk/services/V0.1"
                "/Firm/123/Individuals?pgnp=1",
            },
            "Message": "",
            "Data": [
                {"IRN": "CCC333", "Name": "Person C"},
                {"IRN": "DDD444", "Name": "Person D"},
            ],
        }

        transport.add_json_route("/Firm/123/Individuals", page1)
        # Mock transport matches on path without query params.
        # For page 2, the client sends ?pgnp=2 — same base path.
        # Our transport strips query params, so it will match the same route.
        # We need to handle this — replace route after first call.
        # Simpler: use a stateful transport.

        class PaginatedTransport(httpx.BaseTransport):
            def __init__(self) -> None:
                self.call_count = 0

            def handle_request(
                self, request: httpx.Request
            ) -> httpx.Response:
                self.call_count += 1
                if self.call_count == 1:
                    return httpx.Response(200, json=page1)
                return httpx.Response(200, json=page2)

        pt = PaginatedTransport()
        config = FCAConfig(
            auth_email="t@t.com", auth_key="k", cache_enabled=False
        )
        client = FCAClient(config)
        client._client = httpx.Client(
            transport=pt, base_url=config.base_url
        )

        data, _cached = client.get_firm_individuals("123")
        assert pt.call_count == 2
        assert len(data["Data"]) == 4
        irns = [item["IRN"] for item in data["Data"]]
        assert irns == ["AAA111", "BBB222", "CCC333", "DDD444"]
        # Next/Previous removed from ResultInfo.
        assert "Next" not in data["ResultInfo"]

    def test_empty_sub_resource_returns_null_data(self) -> None:
        """Sub-resource with -11 status returns Data: null, no error."""
        transport = MockTransport()
        transport.add_route(
            "/Individuals/JXD01375/DisciplinaryHistory",
            "individual_dh_jxd01375.json",
        )
        client = make_client(transport)

        data, _cached = client.get_individual_disciplinary_history("JXD01375")
        assert data["Data"] is None
        assert "11" in data["Status"]


# ---------------------------------------------------------------------------
# Tests — Cache behaviour
# ---------------------------------------------------------------------------


class TestCaching:
    def test_cache_hit_returns_cached(self, tmp_path: Path) -> None:
        """Second call returns cached data without hitting transport."""
        from bartram_foundry.cache import ResponseCache

        transport = MockTransport()
        transport.add_route("/Firm/615820", "firm_615820.json")

        config = FCAConfig(
            auth_email="t@t.com", auth_key="k", cache_enabled=True
        )
        client = FCAClient(config)
        client._cache = ResponseCache(db_path=str(tmp_path / "cache.db"))
        client._client = httpx.Client(
            transport=transport, base_url=config.base_url
        )

        _data1, cached1 = client.get_firm("615820")
        assert cached1 is False

        data2, cached2 = client.get_firm("615820")
        assert cached2 is True
        assert data2["Data"][0]["FRN"] == "615820"

        # Only one HTTP request was made.
        assert len(transport.request_log) == 1

    def test_cache_disabled_always_fetches(self) -> None:
        """With caching disabled, every call hits transport."""
        transport = MockTransport()
        transport.add_route("/Firm/615820", "firm_615820.json")
        client = make_client(transport)  # cache_enabled=False

        client.get_firm("615820")
        client.get_firm("615820")

        assert len(transport.request_log) == 2


# ---------------------------------------------------------------------------
# Tests — Config
# ---------------------------------------------------------------------------


class TestFCAConfig:
    def test_from_env(self) -> None:
        with patch.dict(
            "os.environ",
            {"FCA_API_EMAIL": "a@b.com", "FCA_API_KEY": "key123"},
            clear=False,
        ):
            config = FCAConfig.from_env()
            assert config.auth_email == "a@b.com"
            assert config.auth_key == "key123"

    def test_from_env_missing_raises(self) -> None:
        with (
            patch.dict("os.environ", {}, clear=True),
            pytest.raises(ValueError, match="FCA_AUTH_EMAIL"),
        ):
            FCAConfig.from_env()
