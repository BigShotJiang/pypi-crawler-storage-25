"""Tests for FCA Financial Services Register MCP tool definitions.

End-to-end tests: MCP tool call → access (mock transport) → clean → JSON response.
Covers all 19 tools.
"""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest

from bartram_fca import serve
from bartram_fca.access import FCAClient, FCAConfig

FIXTURES = Path(__file__).parent / "fixtures"


def load_fixture(name: str) -> dict:
    return json.loads((FIXTURES / name).read_text())


# ---------------------------------------------------------------------------
# Mock transport
# ---------------------------------------------------------------------------


class MockTransport(httpx.BaseTransport):
    PREFIX = "/services/V0.1"

    def __init__(self) -> None:
        self.routes: dict[str, tuple[int, dict]] = {}

    def add_route(self, path: str, fixture_name: str, status: int = 200) -> None:
        self.routes[self.PREFIX + path] = (status, load_fixture(fixture_name))

    def add_json_route(self, path: str, data: dict, status: int = 200) -> None:
        self.routes[self.PREFIX + path] = (status, data)

    def add_error_route(self, path: str, status: int) -> None:
        self.routes[self.PREFIX + path] = (status, {"error": "Not found"})

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        full_path = request.url.raw_path.decode()
        path = full_path.split("?")[0]
        if full_path in self.routes:
            status, data = self.routes[full_path]
            return httpx.Response(status, json=data)
        if path in self.routes:
            status, data = self.routes[path]
            return httpx.Response(status, json=data)
        return httpx.Response(200, json={
            "Status": "FSR-API-00-00-11",
            "ResultInfo": None,
            "Message": "No data found",
            "Data": None,
        })


# ---------------------------------------------------------------------------
# Fixtures for mock client injection
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _mock_client(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Replace the serve module's client and metrics with test instances."""
    transport = MockTransport()

    # Register routes for all fixture-backed endpoints.
    transport.add_route("/CommonSearch", "search_barclays.json")
    transport.add_route("/Firm/122702", "firm_122702.json")
    transport.add_route("/Firm/615820", "firm_615820.json")
    transport.add_route("/Firm/122702/Names", "firm_names_122702.json")
    transport.add_route("/Firm/122702/Address", "firm_address_122702.json")
    transport.add_route("/Firm/122702/Permissions", "firm_permissions_122702.json")
    transport.add_route("/Firm/122702/Individuals", "firm_individuals_122702.json")
    transport.add_route("/Firm/122702/CF", "firm_cf_122702.json")
    transport.add_route("/Firm/122702/Requirements", "firm_requirements_122702.json")
    transport.add_route(
        "/Firm/122702/Requirements/OR-0170047/InvestmentTypes",
        "firm_req_invtypes_122702.json",
    )
    transport.add_route("/Firm/122702/Regulators", "firm_regulators_122702.json")
    transport.add_route("/Firm/122702/Passports", "firm_passports_122702.json")
    transport.add_route("/Firm/122702/AR", "firm_ar_122702.json")
    transport.add_route("/Firm/122702/Waivers", "firm_waivers_122702.json")
    transport.add_route("/Firm/122702/Exclusions", "firm_exclusions_122702.json")
    transport.add_route(
        "/Firm/122702/DisciplinaryHistory", "firm_disciplinary_122702.json"
    )
    transport.add_route("/Individuals/JXD01375", "individual_jxd01375.json")
    transport.add_route("/Individuals/JXD01375/CF", "individual_cf_jxd01375.json")
    transport.add_route(
        "/Individuals/JXD01375/DisciplinaryHistory", "individual_dh_jxd01375.json"
    )

    # Not-found routes.
    transport.add_route("/Firm/999999", "firm_not_found.json")
    transport.add_route("/Individuals/ZZZZZ999", "individual_not_found.json")

    config = FCAConfig(
        auth_email="test@test.com",
        auth_key="test-key",
        cache_enabled=False,
    )
    client = FCAClient(config)
    client._client = httpx.Client(transport=transport, base_url=config.base_url)

    monkeypatch.setattr(serve, "_client", client)

    from bartram_foundry.monitoring import MetricsStore

    monkeypatch.setattr(
        serve, "_metrics", MetricsStore(db_path=str(tmp_path / "metrics.db"))
    )


def _parse(result: str) -> dict:
    """Parse a tool result JSON string."""
    return json.loads(result)


# ---------------------------------------------------------------------------
# Tests — Search
# ---------------------------------------------------------------------------


class TestUkFcaSearch:
    async def test_empty_query_returns_error(self) -> None:
        result = _parse(await serve.uk_fca_search(""))
        assert result["error"] == "bad_request"

    async def test_special_chars_rejected(self) -> None:
        result = _parse(await serve.uk_fca_search("***"))
        assert result["error"] == "bad_request"

    async def test_search_returns_envelope(self) -> None:
        result = _parse(await serve.uk_fca_search("barclays"))
        assert "data" in result
        assert "metadata" in result
        assert result["metadata"]["source"] == "FCA Financial Services Register"
        assert result["metadata"]["endpoint"] == "/CommonSearch"
        assert "attribution" in result["metadata"]

    async def test_search_data_has_cleaning(self) -> None:
        result = _parse(await serve.uk_fca_search("barclays"))
        assert "_cleaning" in result["data"]


# ---------------------------------------------------------------------------
# Tests — Firm
# ---------------------------------------------------------------------------


class TestUkFcaFirm:
    async def test_firm_returns_envelope(self) -> None:
        result = _parse(await serve.uk_fca_firm("122702"))
        assert "data" in result
        assert "metadata" in result
        assert result["metadata"]["endpoint"] == "/Firm/122702"

    async def test_firm_data_unwrapped_and_cleaned(self) -> None:
        result = _parse(await serve.uk_fca_firm("122702"))
        data = result["data"]
        assert data["_cleaning"].get("data_unwrapped") is True
        assert data["_cleaning"].get("hateoas_replaced") is True
        assert "related_endpoints" in data

    async def test_firm_frn_normalised(self) -> None:
        result = _parse(await serve.uk_fca_firm("FRN-122702"))
        assert "data" in result
        assert "error" not in result

    async def test_firm_invalid_frn(self) -> None:
        result = _parse(await serve.uk_fca_firm(""))
        assert result["error"] == "bad_request"


class TestUkFcaFirmNames:
    async def test_names_returns_envelope(self) -> None:
        result = _parse(await serve.uk_fca_firm_names("122702"))
        assert "data" in result
        assert "metadata" in result

    async def test_names_flattened(self) -> None:
        result = _parse(await serve.uk_fca_firm_names("122702"))
        cleaning = result["data"]["_cleaning"]
        assert cleaning.get("names_flattened") is True


class TestUkFcaFirmAddress:
    async def test_address_returns_envelope(self) -> None:
        result = _parse(await serve.uk_fca_firm_address("122702"))
        assert "data" in result
        assert result["metadata"]["endpoint"] == "/Firm/122702/Address"


class TestUkFcaFirmPermissions:
    async def test_permissions_restructured(self) -> None:
        result = _parse(await serve.uk_fca_firm_permissions("122702"))
        data = result["data"]
        assert data["_cleaning"].get("permissions_restructured") is True


class TestUkFcaFirmIndividuals:
    async def test_individuals_returns_data(self) -> None:
        result = _parse(await serve.uk_fca_firm_individuals("122702"))
        assert "data" in result
        data = result["data"]
        items = data.get("data", [])
        if isinstance(items, list) and items:
            assert "irn" in items[0]


class TestUkFcaFirmControlFunctions:
    async def test_cf_parsed(self) -> None:
        result = _parse(await serve.uk_fca_firm_control_functions("122702"))
        data = result["data"]
        assert data["_cleaning"].get("cf_parsed") is True


class TestUkFcaFirmRequirements:
    async def test_requirements_returns_data(self) -> None:
        result = _parse(await serve.uk_fca_firm_requirements("122702"))
        assert "data" in result
        assert result["data"]["_cleaning"].get("dates_normalised") is True


class TestUkFcaFirmRequirementInvestmentTypes:
    async def test_returns_data(self) -> None:
        result = _parse(
            await serve.uk_fca_firm_requirement_investment_types(
                "122702", "OR-0170047"
            )
        )
        assert "data" in result

    async def test_empty_ref_rejected(self) -> None:
        result = _parse(
            await serve.uk_fca_firm_requirement_investment_types("122702", "")
        )
        assert result["error"] == "bad_request"


class TestUkFcaFirmRegulators:
    async def test_regulators_returns_data(self) -> None:
        result = _parse(await serve.uk_fca_firm_regulators("122702"))
        assert "data" in result
        assert result["data"]["_cleaning"].get("dates_normalised") is True


class TestUkFcaFirmPassports:
    async def test_passports_returns_data(self) -> None:
        result = _parse(await serve.uk_fca_firm_passports("122702"))
        assert "data" in result


class TestUkFcaFirmPassportPermissions:
    async def test_returns_data(self) -> None:
        # This endpoint may return no data — just verify it doesn't crash.
        result = _parse(await serve.uk_fca_firm_passport_permissions("122702"))
        assert "data" in result or "error" in result


class TestUkFcaFirmAppointedReps:
    async def test_ar_returns_data(self) -> None:
        result = _parse(await serve.uk_fca_firm_appointed_reps("122702"))
        assert "data" in result
        assert result["data"]["_cleaning"].get("dates_normalised") is True


class TestUkFcaFirmWaivers:
    async def test_waivers_returns_data(self) -> None:
        result = _parse(await serve.uk_fca_firm_waivers("122702"))
        assert "data" in result


class TestUkFcaFirmExclusions:
    async def test_exclusions_returns_data(self) -> None:
        result = _parse(await serve.uk_fca_firm_exclusions("122702"))
        assert "data" in result


class TestUkFcaFirmDisciplinaryHistory:
    async def test_disciplinary_returns_data(self) -> None:
        result = _parse(await serve.uk_fca_firm_disciplinary_history("122702"))
        assert "data" in result


# ---------------------------------------------------------------------------
# Tests — Individual
# ---------------------------------------------------------------------------


class TestUkFcaIndividual:
    async def test_individual_returns_envelope(self) -> None:
        result = _parse(await serve.uk_fca_individual("JXD01375"))
        assert "data" in result
        assert "metadata" in result
        assert result["metadata"]["endpoint"] == "/Individuals/JXD01375"

    async def test_individual_data_unwrapped(self) -> None:
        result = _parse(await serve.uk_fca_individual("JXD01375"))
        data = result["data"]
        assert data["_cleaning"].get("data_unwrapped") is True
        assert "irn" in data
        assert "full_name" in data

    async def test_individual_hateoas_replaced(self) -> None:
        result = _parse(await serve.uk_fca_individual("JXD01375"))
        data = result["data"]
        assert data["_cleaning"].get("hateoas_replaced") is True
        assert "related_endpoints" in data

    async def test_individual_irn_normalised(self) -> None:
        result = _parse(await serve.uk_fca_individual("jxd01375"))
        assert "data" in result

    async def test_individual_invalid_irn(self) -> None:
        result = _parse(await serve.uk_fca_individual(""))
        assert result["error"] == "bad_request"


class TestUkFcaIndividualControlFunctions:
    async def test_cf_returns_data(self) -> None:
        result = _parse(
            await serve.uk_fca_individual_control_functions("JXD01375")
        )
        assert "data" in result

    async def test_cf_parsed(self) -> None:
        result = _parse(
            await serve.uk_fca_individual_control_functions("JXD01375")
        )
        data = result["data"]
        assert data["_cleaning"].get("cf_parsed") is True


class TestUkFcaIndividualDisciplinaryHistory:
    async def test_returns_data(self) -> None:
        result = _parse(
            await serve.uk_fca_individual_disciplinary_history("JXD01375")
        )
        assert "data" in result


# ---------------------------------------------------------------------------
# Tests — Error handling
# ---------------------------------------------------------------------------


class TestErrorResponses:
    async def test_not_found_firm(self) -> None:
        result = _parse(await serve.uk_fca_firm("999999"))
        # May come back as error or as data with no data flag.
        assert "data" in result or "error" in result

    async def test_metadata_always_present(self) -> None:
        result = _parse(await serve.uk_fca_firm("122702"))
        assert "metadata" in result
        assert "source" in result["metadata"]
        assert "licence" in result["metadata"]
        assert "retrieved_at" in result["metadata"]
        assert "attribution" in result["metadata"]
