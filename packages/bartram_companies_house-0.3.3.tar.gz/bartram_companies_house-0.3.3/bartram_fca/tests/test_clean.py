"""Tests for FCA Financial Services Register data cleaning logic.

Covers all 19 endpoint cleaning functions, shared utilities, and
real fixture-based tests for data transformations.
"""

from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path

from bartram_fca.clean import (
    _clean_cf_dict,
    _clean_cf_entries,
    _strip_url_fields,
    clean_firm,
    clean_firm_address,
    clean_firm_appointed_reps,
    clean_firm_control_functions,
    clean_firm_disciplinary_history,
    clean_firm_exclusions,
    clean_firm_individuals,
    clean_firm_names,
    clean_firm_passports,
    clean_firm_permissions,
    clean_firm_regulators,
    clean_firm_requirement_investment_types,
    clean_firm_requirements,
    clean_firm_waivers,
    clean_individual,
    clean_individual_control_functions,
    clean_individual_disciplinary_history,
    clean_search_results,
    flatten_workplaces,
    normalise_date,
    parse_cf_code,
    parse_exceptional_info,
    split_trading_names,
    to_snake_case,
)

FIXTURES = Path(__file__).parent / "fixtures"


def load_fixture(name: str) -> dict:
    return json.loads((FIXTURES / name).read_text())


# ---------------------------------------------------------------------------
# Date normalisation
# ---------------------------------------------------------------------------


class TestNormaliseDate:
    def test_dd_mm_yyyy(self) -> None:
        result, changed = normalise_date("15/03/2024")
        assert result == "2024-03-15"
        assert changed is True

    def test_dd_mm_yyyy_hh_mm(self) -> None:
        result, changed = normalise_date("15/03/2024 14:30")
        assert result == "2024-03-15T14:30:00"
        assert changed is True

    def test_already_iso(self) -> None:
        result, changed = normalise_date("2024-03-15")
        assert result == "2024-03-15"
        assert changed is False

    def test_empty(self) -> None:
        result, changed = normalise_date("")
        assert result == ""
        assert changed is False

    def test_none(self) -> None:
        result, changed = normalise_date(None)
        assert result is None
        assert changed is False


# ---------------------------------------------------------------------------
# Field name normalisation
# ---------------------------------------------------------------------------


class TestToSnakeCase:
    def test_space_separated(self) -> None:
        assert to_snake_case("Firm Reference Number") == "firm_reference_number"

    def test_camel_case(self) -> None:
        assert to_snake_case("FirmName") == "firm_name"

    def test_already_snake(self) -> None:
        assert to_snake_case("firm_name") == "firm_name"

    def test_hyphenated(self) -> None:
        assert to_snake_case("firm-name") == "firm_name"


# ---------------------------------------------------------------------------
# Exceptional Info parsing
# ---------------------------------------------------------------------------


class TestParseExceptionalInfo:
    def test_numbered_items(self) -> None:
        text = "1. First notice 2. Second notice 3. Third notice"
        notices, parsed = parse_exceptional_info(text)
        assert parsed is True
        assert len(notices) == 3

    def test_unparseable(self) -> None:
        text = "This is a plain caution with no numbering."
        notices, parsed = parse_exceptional_info(text)
        assert parsed is False
        assert notices == [text]

    def test_empty(self) -> None:
        notices, parsed = parse_exceptional_info("")
        assert notices == []
        assert parsed is False


# ---------------------------------------------------------------------------
# Trading name splitting
# ---------------------------------------------------------------------------


class TestSplitTradingNames:
    def test_comma_separated(self) -> None:
        names, split = split_trading_names("Acme Corp, Acme Ltd, Acme PLC")
        assert len(names) == 3
        assert split is True

    def test_single_name(self) -> None:
        names, split = split_trading_names("Acme Corp")
        assert names == ["Acme Corp"]
        assert split is False

    def test_empty(self) -> None:
        names, split = split_trading_names("")
        assert names == []
        assert split is False


# ---------------------------------------------------------------------------
# Workplace flattening
# ---------------------------------------------------------------------------


class TestFlattenWorkplaces:
    def test_multiple_workplaces(self) -> None:
        data = {
            "Name": "Test Person",
            "Workplace Location 1": {"firm_name": "Firm A", "location": "London"},
            "Workplace Location 2": {"firm_name": "Firm B", "location": "Manchester"},
        }
        workplaces, changed = flatten_workplaces(data)
        assert changed is True
        assert len(workplaces) == 2
        assert "Workplace Location 1" not in data
        assert "Workplace Location 2" not in data

    def test_no_workplaces(self) -> None:
        data = {"Name": "Test Person"}
        workplaces, changed = flatten_workplaces(data)
        assert changed is False
        assert workplaces == []


# ---------------------------------------------------------------------------
# URL stripping
# ---------------------------------------------------------------------------


class TestStripUrlFields:
    def test_removes_url(self) -> None:
        data = {"URL": "https://example.com/api/v1/resource", "Name": "Test"}
        changed = _strip_url_fields(data)
        assert changed is True
        assert "URL" not in data
        assert data["Name"] == "Test"

    def test_no_url(self) -> None:
        data = {"Name": "Test"}
        changed = _strip_url_fields(data)
        assert changed is False


# ---------------------------------------------------------------------------
# Control function code parsing
# ---------------------------------------------------------------------------


class TestParseCfCode:
    def test_smf_code(self) -> None:
        result = parse_cf_code("(6865)SMF7 Group Entity Senior Manager")
        assert result["id"] == "6865"
        assert result["code"] == "SMF7"
        assert result["description"] == "Group Entity Senior Manager"

    def test_cf_code(self) -> None:
        result = parse_cf_code("(23603)CF10 Compliance Oversight")
        assert result["id"] == "23603"
        assert result["code"] == "CF10"
        assert result["description"] == "Compliance Oversight"

    def test_bracketed_prefix(self) -> None:
        result = parse_cf_code("(23602)[FCA CF] Manager of certification employee")
        assert result["id"] == "23602"
        desc = result.get("description", result.get("raw", ""))
        assert "Manager of certification employee" in desc

    def test_unparseable(self) -> None:
        result = parse_cf_code("Something unexpected")
        assert "raw" in result

    def test_empty(self) -> None:
        result = parse_cf_code("")
        assert "raw" in result


class TestCleanCfEntries:
    def test_parses_list_of_strings(self) -> None:
        entries = [
            "(6865)SMF7 Group Entity Senior Manager",
            "(6864)SMF6 Head of Key Business Areas",
        ]
        result = _clean_cf_entries(entries)
        assert len(result) == 2
        assert result[0]["id"] == "6865"
        assert result[1]["id"] == "6864"


class TestCleanCfDict:
    def test_parses_dict_keys(self) -> None:
        entries = {
            "(2)CF30 Customer": {"some_detail": "value"},
            "(1)CF21 Investment Adviser": {},
        }
        result = _clean_cf_dict(entries)
        assert len(result) == 2
        ids = {r["id"] for r in result}
        assert "1" in ids
        assert "2" in ids


# ---------------------------------------------------------------------------
# Per-endpoint cleaning with real fixtures
# ---------------------------------------------------------------------------


class TestCleanFirmWithFixture:
    def test_firm_122702(self) -> None:
        data = deepcopy(load_fixture("firm_122702.json"))
        result = clean_firm(data)
        cleaning = result["_cleaning"]

        # Data[0] should be unwrapped into top level.
        assert cleaning.get("data_unwrapped") is True
        assert "data" not in result  # Data key renamed after unwrap
        assert cleaning.get("fields_normalised") is True

        # HATEOAS links replaced.
        assert cleaning.get("hateoas_replaced") is True
        assert "related_endpoints" in result
        endpoints = result["related_endpoints"]
        assert "names" in endpoints or "name" in endpoints

    def test_firm_615820(self) -> None:
        data = deepcopy(load_fixture("firm_615820.json"))
        result = clean_firm(data)
        assert result["_cleaning"].get("data_unwrapped") is True
        assert result["_cleaning"].get("fields_normalised") is True


class TestCleanFirmNamesWithFixture:
    def test_names_122702(self) -> None:
        data = deepcopy(load_fixture("firm_names_122702.json"))
        result = clean_firm_names(data)
        cleaning = result["_cleaning"]

        # Names should be flattened from Current/Previous structure.
        assert cleaning.get("names_flattened") is True
        items = result.get("data", [])
        assert isinstance(items, list)
        assert len(items) > 0

        # Each name should have a current flag.
        for item in items:
            assert "current" in item

        # Dates should be normalised (Effective From is DD/MM/YYYY).
        assert cleaning.get("dates_normalised") is True


class TestCleanFirmAddressWithFixture:
    def test_address_122702(self) -> None:
        data = deepcopy(load_fixture("firm_address_122702.json"))
        result = clean_firm_address(data)
        cleaning = result["_cleaning"]
        assert cleaning.get("fields_normalised") is True
        # URL fields should be stripped from items.
        items = result.get("data", [])
        if isinstance(items, list):
            for item in items:
                assert "url" not in item


class TestCleanFirmPermissionsWithFixture:
    def test_permissions_122702(self) -> None:
        data = deepcopy(load_fixture("firm_permissions_122702.json"))
        result = clean_firm_permissions(data)
        cleaning = result["_cleaning"]

        # Dict keyed by permission name → list of permission objects.
        assert cleaning.get("permissions_restructured") is True
        items = result.get("data", [])
        assert isinstance(items, list)
        assert len(items) > 0
        assert "permission" in items[0]
        assert "limitations" in items[0]


class TestCleanFirmIndividualsWithFixture:
    def test_individuals_122702(self) -> None:
        data = deepcopy(load_fixture("firm_individuals_122702.json"))
        result = clean_firm_individuals(data)
        cleaning = result["_cleaning"]
        assert cleaning.get("fields_normalised") is True

        # URL fields should be stripped from items.
        items = result.get("data", [])
        if isinstance(items, list):
            for item in items:
                assert "url" not in item
                assert "irn" in item


class TestCleanFirmControlFunctionsWithFixture:
    def test_cf_122702(self) -> None:
        data = deepcopy(load_fixture("firm_cf_122702.json"))
        result = clean_firm_control_functions(data)
        cleaning = result["_cleaning"]

        assert cleaning.get("cf_parsed") is True
        cf_data = result.get("data", {})
        assert isinstance(cf_data, dict)
        assert "current" in cf_data
        assert "previous" in cf_data
        assert isinstance(cf_data["current"], list)
        assert len(cf_data["current"]) > 0
        assert "id" in cf_data["current"][0]


class TestCleanFirmRequirementsWithFixture:
    def test_requirements_122702(self) -> None:
        data = deepcopy(load_fixture("firm_requirements_122702.json"))
        result = clean_firm_requirements(data)
        cleaning = result["_cleaning"]
        assert cleaning.get("fields_normalised") is True
        assert cleaning.get("dates_normalised") is True


class TestCleanFirmRegulatorsWithFixture:
    def test_regulators_122702(self) -> None:
        data = deepcopy(load_fixture("firm_regulators_122702.json"))
        result = clean_firm_regulators(data)
        cleaning = result["_cleaning"]
        assert cleaning.get("fields_normalised") is True
        assert cleaning.get("dates_normalised") is True


class TestCleanFirmPassportsWithFixture:
    def test_passports_122702(self) -> None:
        data = deepcopy(load_fixture("firm_passports_122702.json"))
        result = clean_firm_passports(data)
        assert "_cleaning" in result


class TestCleanFirmAppointedRepsWithFixture:
    def test_ar_122702(self) -> None:
        data = deepcopy(load_fixture("firm_ar_122702.json"))
        result = clean_firm_appointed_reps(data)
        cleaning = result["_cleaning"]
        assert cleaning.get("fields_normalised") is True
        assert cleaning.get("dates_normalised") is True

        # Data should have current/previous AR lists (field-normalised keys).
        ar_data = result.get("data", {})
        if isinstance(ar_data, dict):
            # URL fields should be stripped from AR items.
            for _key, items in ar_data.items():
                if isinstance(items, list):
                    for item in items:
                        if isinstance(item, dict):
                            assert "url" not in item


class TestCleanFirmWaiversWithFixture:
    def test_waivers_122702(self) -> None:
        data = deepcopy(load_fixture("firm_waivers_122702.json"))
        result = clean_firm_waivers(data)
        assert result["_cleaning"].get("fields_normalised") is True


class TestCleanFirmExclusionsWithFixture:
    def test_exclusions_122702(self) -> None:
        data = deepcopy(load_fixture("firm_exclusions_122702.json"))
        result = clean_firm_exclusions(data)
        assert result["_cleaning"].get("fields_normalised") is True


class TestCleanFirmDisciplinaryHistoryWithFixture:
    def test_disciplinary_122702(self) -> None:
        data = deepcopy(load_fixture("firm_disciplinary_122702.json"))
        result = clean_firm_disciplinary_history(data)
        assert result["_cleaning"].get("fields_normalised") is True


class TestCleanFirmRequirementInvestmentTypes:
    def test_no_data(self) -> None:
        data = deepcopy(load_fixture("firm_req_invtypes_122702.json"))
        result = clean_firm_requirement_investment_types(data)
        assert "_cleaning" in result


class TestCleanIndividualWithFixture:
    def test_individual_jxd01375(self) -> None:
        data = deepcopy(load_fixture("individual_jxd01375.json"))
        result = clean_individual(data)
        cleaning = result["_cleaning"]

        # Data[0]["Details"] should be unwrapped.
        assert cleaning.get("data_unwrapped") is True
        assert cleaning.get("fields_normalised") is True

        # HATEOAS links should be replaced.
        assert cleaning.get("hateoas_replaced") is True
        assert "related_endpoints" in result

        # IRN and name should be present after unwrapping.
        assert "irn" in result
        assert "full_name" in result


class TestCleanIndividualControlFunctionsWithFixture:
    def test_cf_jxd01375(self) -> None:
        data = deepcopy(load_fixture("individual_cf_jxd01375.json"))
        result = clean_individual_control_functions(data)
        cleaning = result["_cleaning"]

        assert cleaning.get("cf_parsed") is True
        cf_data = result.get("data", {})
        assert isinstance(cf_data, dict)
        assert "previous" in cf_data
        assert isinstance(cf_data["previous"], list)


class TestCleanIndividualDisciplinaryHistory:
    def test_no_data(self) -> None:
        data = deepcopy(load_fixture("individual_dh_jxd01375.json"))
        result = clean_individual_disciplinary_history(data)
        assert "_cleaning" in result


# ---------------------------------------------------------------------------
# Not-found / null Data responses
# ---------------------------------------------------------------------------


class TestCleanNotFoundResponses:
    def test_firm_not_found(self) -> None:
        data = deepcopy(load_fixture("firm_not_found.json"))
        result = clean_firm(data)
        assert "_cleaning" in result

    def test_individual_not_found(self) -> None:
        data = deepcopy(load_fixture("individual_not_found.json"))
        result = clean_individual(data)
        assert "_cleaning" in result


# ---------------------------------------------------------------------------
# Basic cleaning (minimal data, no fixtures)
# ---------------------------------------------------------------------------


class TestCleanSearchResults:
    def test_basic_cleaning(self) -> None:
        data = {"Status": "FSR-API-01-01-00", "ResultInfo": {"total_count": "5"}}
        result = clean_search_results(data)
        assert "_cleaning" in result


class TestCleanFirm:
    def test_basic_cleaning(self) -> None:
        data = {"Organisation Name": "Test Firm", "Status": "Authorised"}
        result = clean_firm(data)
        assert "_cleaning" in result
        assert "organisation_name" in result


class TestCleanIndividual:
    def test_basic_cleaning(self) -> None:
        data = {"Full Name": "John Smith", "Status": "Active"}
        result = clean_individual(data)
        assert "_cleaning" in result
        assert "full_name" in result
