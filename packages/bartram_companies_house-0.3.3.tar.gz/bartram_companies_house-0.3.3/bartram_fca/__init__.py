"""FCA Financial Services Register MCP tool — UK regulatory data with data cleaning."""

__version__ = "0.3.1"
