# Schema Reference — FCA Financial Services Register

Complete tool reference for the UK FCA Financial Services Register MCP server. Each tool follows the `access -> clean -> serve` pattern: raw API data is fetched, cleaned, and returned in a consistent envelope.

## Response envelope

Every successful response wraps data in this structure:

```json
{
  "data": { ... },
  "metadata": {
    "source": "FCA Financial Services Register",
    "licence": "FCA Public Record",
    "retrieved_at": "2026-04-04T10:00:00+00:00",
    "endpoint": "/Firm/122702",
    "cached": false,
    "attribution": "Source: FCA Financial Services Register. Contains public record data maintained by the Financial Conduct Authority."
  }
}
```

Error responses:

```json
{
  "error": "not_found",
  "message": "No data found for path /Firm/999999 (FCA status: FSR-API-02-01-11)",
  "fca_status_code": "FSR-API-02-01-11",
  "attribution": "Source: FCA Financial Services Register. Contains public record data maintained by the Financial Conduct Authority."
}
```

---

## uk_fca_search

Search the FCA Register for firms, individuals, and regulated entities.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | yes | — | Name, FRN, IRN, or keyword to search for |
| `page` | int | no | 1 | Page number (20 results per page) |

### Returns

`data` contains the FCA search response with cleaned field names and trading names split into arrays. Items include entity name, type, reference number, and status.

### Cleaning applied

- Field names normalised to snake_case.
- Dates converted from DD/MM/YYYY to ISO 8601.
- Trading names split from comma-separated string into array.
- URL fields stripped from items.
- Empty query and special-character-only queries rejected with descriptive errors.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_fca_search", "arguments": {"query": "Barclays", "page": 1}}
```

---

## uk_fca_firm

Get full details for an FCA-regulated firm by Firm Reference Number.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `frn` | string | yes | — | Firm Reference Number (e.g. `122702`). Non-numeric characters are stripped automatically. |

### Returns

`data` contains the firm's top-level details unwrapped from the API's `Data[0]` structure: `organisation_name`, `status`, `status_effective_date`, `business_type`, regulatory dates (PSD/EMD, MLRs, e-money), `exceptional_info_details` (parsed notices), and `related_endpoints` mapping sub-resource names to tool names.

### Cleaning applied

- **Data unwrapping**: `Data[0]` promoted to top level (annotated `data_unwrapped`).
- **HATEOAS replacement**: raw API URLs replaced with `related_endpoints` dict mapping to tool names.
- **Exceptional info parsing**: numbered notices split into array where pattern detected.
- **Date normalisation**: DD/MM/YYYY to ISO 8601.
- **Field name normalisation**: snake_case.
- **Empty string to null**: blank fields set to `null`.
- FRN normalised (non-numeric stripped, validated).

### Example call

```json
{"name": "uk_fca_firm", "arguments": {"frn": "122702"}}
```

Note: `FRN-122702` or `  122702  ` are automatically normalised to `122702`.

---

## uk_fca_firm_names

Get brand and trading names for an FCA-regulated firm.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `frn` | string | yes | — | Firm Reference Number. Automatically normalised. |

### Returns

`data` contains a flat list of name records, each with `name`, `status`, `effective_from`, `effective_to` (if previous), and `current` (boolean flag). The API's nested `Current Names` / `Previous Names` structure is flattened.

### Cleaning applied

- **Names flattened**: Current/Previous grouped structure merged into single list with `current` flag.
- **Full pagination**: all pages fetched.
- **Date normalisation**.
- **Field name normalisation**.

### Example call

```json
{"name": "uk_fca_firm_names", "arguments": {"frn": "122702"}}
```

---

## uk_fca_firm_address

Get the registered address and contact details for an FCA-regulated firm.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `frn` | string | yes | — | Firm Reference Number. Automatically normalised. |

### Returns

`data` contains address records with `address_line_1`, `address_line_2`, `town`, `county`, `postcode`, `country`, `phone_number`, `website_address`, and `address_type`.

### Cleaning applied

- **Address normalisation**: line standardisation, abbreviation expansion.
- **Postcode formatting**: correct UK postcode spacing.
- **URL fields stripped**.
- **Date normalisation**.
- **Field name normalisation**.

### Example call

```json
{"name": "uk_fca_firm_address", "arguments": {"frn": "122702"}}
```

---

## uk_fca_firm_permissions

Get regulatory permissions granted to an FCA-regulated firm.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `frn` | string | yes | — | Firm Reference Number. Automatically normalised. |

### Returns

`data` contains a list of permission objects, each with `permission` (name) and `limitations` (list of limitation records). The API's dict-keyed structure (permission name as key) is restructured into a clean list.

### Cleaning applied

- **Permissions restructured**: dict keyed by permission name converted to list of `{permission, limitations}` objects.
- **Full pagination**: all pages fetched.
- **Date normalisation**.
- **Field name normalisation**.

### Example call

```json
{"name": "uk_fca_firm_permissions", "arguments": {"frn": "122702"}}
```

---

## uk_fca_firm_individuals

Get all individuals associated with an FCA-regulated firm.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `frn` | string | yes | — | Firm Reference Number. Automatically normalised. |

### Returns

`data` contains individual records, each with `irn`, `name`, and `status`. Use the IRN with `uk_fca_individual` for full details.

### Cleaning applied

- **Full pagination**: all pages fetched (some firms have thousands of individuals).
- **URL fields stripped** (HATEOAS links removed from items).
- **Field name normalisation**.

### Example call

```json
{"name": "uk_fca_firm_individuals", "arguments": {"frn": "122702"}}
```

---

## uk_fca_firm_control_functions

Get control function holders for an FCA-regulated firm.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `frn` | string | yes | — | Firm Reference Number. Automatically normalised. |

### Returns

`data` contains `current` and `previous` lists of parsed control function records. Each record has `id`, `code` (e.g. `SMF7`, `CF10`), and `description` (e.g. `Group Entity Senior Manager`).

### Cleaning applied

- **CF code parsing**: opaque strings like `(6865)SMF7 Group Entity Senior Manager` parsed into `{id, code, description}`.
- **Full pagination**: all pages fetched.
- **Field name normalisation**.

### Example call

```json
{"name": "uk_fca_firm_control_functions", "arguments": {"frn": "122702"}}
```

---

## uk_fca_firm_requirements

Get regulatory requirements imposed on an FCA-regulated firm.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `frn` | string | yes | — | Firm Reference Number. Automatically normalised. |

### Returns

`data` contains requirement records with requirement text, `requirement_reference`, `effective_date`, and flags like `financial_promotions_requirement`. Use the `requirement_reference` with `uk_fca_firm_requirement_investment_types` for drill-down.

### Cleaning applied

- **Date normalisation**.
- **Field name normalisation**.

### Example call

```json
{"name": "uk_fca_firm_requirements", "arguments": {"frn": "122702"}}
```

---

## uk_fca_firm_requirement_investment_types

Get investment types for a specific regulatory requirement on a firm.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `frn` | string | yes | — | Firm Reference Number. Automatically normalised. |
| `requirement_ref` | string | yes | — | Requirement reference from `uk_fca_firm_requirements` results (e.g. `OR-0170047`). |

### Returns

`data` contains investment type records for the specified requirement.

### Cleaning applied

- **Date normalisation**.
- **Field name normalisation**.
- Empty `requirement_ref` rejected with error.

### Example call

```json
{"name": "uk_fca_firm_requirement_investment_types", "arguments": {"frn": "122702", "requirement_ref": "OR-0170047"}}
```

---

## uk_fca_firm_regulators

Get regulatory bodies associated with an FCA-regulated firm.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `frn` | string | yes | — | Firm Reference Number. Automatically normalised. |

### Returns

`data` contains regulator records with `regulator_name`, `effective_date`, and `termination_date`.

### Cleaning applied

- **Empty date strings converted to null**.
- **Date normalisation**.
- **Field name normalisation**.

### Example call

```json
{"name": "uk_fca_firm_regulators", "arguments": {"frn": "122702"}}
```

---

## uk_fca_firm_passports

Get EU/EEA passporting information for a firm (largely historical post-Brexit).

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `frn` | string | yes | — | Firm Reference Number. Automatically normalised. |

### Returns

`data` contains passport records with country, status, and dates.

### Cleaning applied

- **Date normalisation**.
- **Field name normalisation**.

### Example call

```json
{"name": "uk_fca_firm_passports", "arguments": {"frn": "122702"}}
```

---

## uk_fca_firm_passport_permissions

Get permissions held under a firm's EU/EEA passport.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `frn` | string | yes | — | Firm Reference Number. Automatically normalised. |

### Returns

`data` contains passport permission records. Note: this endpoint path is not in the FCA's HATEOAS links and may return empty for most firms.

### Example call

```json
{"name": "uk_fca_firm_passport_permissions", "arguments": {"frn": "122702"}}
```

---

## uk_fca_firm_appointed_reps

Get appointed representatives of an FCA-regulated firm.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `frn` | string | yes | — | Firm Reference Number. Automatically normalised. |

### Returns

`data` contains `current_appointed_representatives` and `previous_appointed_representatives` lists. Each record includes `frn`, `principal_firm_name`, `principal_frn`, `effective_date`, `termination_date`, and flags.

### Cleaning applied

- **URL fields stripped** from AR items.
- **Full pagination**: all pages fetched.
- **Date normalisation**.
- **Field name normalisation**.

### Example call

```json
{"name": "uk_fca_firm_appointed_reps", "arguments": {"frn": "122702"}}
```

---

## uk_fca_firm_waivers

Get regulatory waivers granted to an FCA-regulated firm.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `frn` | string | yes | — | Firm Reference Number. Automatically normalised. |

### Returns

`data` contains waiver records with `waivers_discretions` (document name), `waivers_discretions_url` (download link), and `rule_article_no`.

### Cleaning applied

- **Date normalisation**.
- **Field name normalisation**.

### Example call

```json
{"name": "uk_fca_firm_waivers", "arguments": {"frn": "122702"}}
```

---

## uk_fca_firm_exclusions

Get exclusions from regulation for an FCA-regulated firm.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `frn` | string | yes | — | Firm Reference Number. Automatically normalised. |

### Returns

`data` contains exclusion records with `psd2_exclusion_type`, `particular_exclusion_relied_upon`, and `description_of_services`.

### Cleaning applied

- **Date normalisation**.
- **Field name normalisation**.

### Example call

```json
{"name": "uk_fca_firm_exclusions", "arguments": {"frn": "122702"}}
```

---

## uk_fca_firm_disciplinary_history

Get disciplinary actions taken against an FCA-regulated firm.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `frn` | string | yes | — | Firm Reference Number. Automatically normalised. |

### Returns

`data` contains disciplinary records with action details, dates, and status.

### Cleaning applied

- **Full pagination**: all pages fetched.
- **Date normalisation**.
- **Field name normalisation**.

### Example call

```json
{"name": "uk_fca_firm_disciplinary_history", "arguments": {"frn": "122702"}}
```

---

## uk_fca_individual

Get details for an FCA-regulated individual by Individual Reference Number.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `irn` | string | yes | — | Individual Reference Number (e.g. `JXD01375`). Lowercase is automatically uppercased. Must contain both letters and digits. |

### Returns

`data` contains individual details unwrapped from the API's `Data[0]["Details"]` structure: `irn`, `full_name`, `commonly_used_name`, `status`, `workplaces` (flattened array), and `related_endpoints` mapping to control functions and disciplinary history tools.

### Cleaning applied

- **Data unwrapping**: `Data[0]["Details"]` promoted to top level.
- **HATEOAS replacement**: URL fields replaced with `related_endpoints`.
- **Workplace flattening**: numbered `Workplace Location N` keys collapsed into `workplaces` array.
- **IRN normalisation**: uppercased, whitespace stripped.
- **Date normalisation**.
- **Field name normalisation**.

### Example call

```json
{"name": "uk_fca_individual", "arguments": {"irn": "JXD01375"}}
```

Note: `jxd01375` is automatically normalised to `JXD01375`.

---

## uk_fca_individual_control_functions

Get control function roles held by an FCA-regulated individual.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `irn` | string | yes | — | Individual Reference Number. Automatically normalised. |

### Returns

`data` contains `current` and/or `previous` lists of parsed control function records, each with `id`, `code`, and `description`.

### Cleaning applied

- **CF code parsing**: same as firm CF — opaque strings parsed into structured objects.
- **Field name normalisation**.

### Example call

```json
{"name": "uk_fca_individual_control_functions", "arguments": {"irn": "JXD01375"}}
```

---

## uk_fca_individual_disciplinary_history

Get disciplinary actions taken against an FCA-regulated individual.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `irn` | string | yes | — | Individual Reference Number. Automatically normalised. |

### Returns

`data` contains disciplinary records with action details, dates, and status.

### Cleaning applied

- **Date normalisation**.
- **Field name normalisation**.

### Example call

```json
{"name": "uk_fca_individual_disciplinary_history", "arguments": {"irn": "JXD01375"}}
```

---

## Data source

All data from the [FCA Financial Services Register API](https://register.fca.org.uk/Developer/s/). Published as public record data by the Financial Conduct Authority.
