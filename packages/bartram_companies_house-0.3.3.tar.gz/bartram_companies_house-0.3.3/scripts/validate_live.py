#!/usr/bin/env python3
"""Stage 8 validation: run every tool against the live Companies House API.

Usage:
    export COMPANIES_HOUSE_API_KEY="your-key"
    python scripts/validate_live.py

Tests all 12 tools with real data and verifies output matches the Tool Spec:
- Input handling (normalisation, validation, error messages)
- Data retrieval (pagination, caching)
- Data cleaning (annotations present and correct)
- Edge cases (empty results, not found, dissolved entities)
- Response metadata (source, licence, attribution)
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bartram_companies_house import serve

# Test data — a mix of company types to exercise all code paths
TEST_COMPANY_ACTIVE = "00445790"       # Tesco PLC — active, large, has charges
TEST_COMPANY_DISSOLVED = "07813215"     # A dissolved company
TEST_COMPANY_WITH_INSOLVENCY = "03034498"  # Known insolvency history
TEST_COMPANY_SHORT_NUMBER = "445790"   # Tesco without padding
TEST_SEARCH_QUERY = "Tesco"
TEST_OFFICER_SEARCH = "Murphy"

PASS = "PASS"
FAIL = "FAIL"
SKIP = "SKIP"


class ValidationReport:
    def __init__(self) -> None:
        self.results: list[dict] = []

    def add(self, tool: str, test: str, status: str, detail: str = "") -> None:
        self.results.append({
            "tool": tool, "test": test, "status": status, "detail": detail
        })
        symbol = {"PASS": "+", "FAIL": "!", "SKIP": "-"}[status]
        print(f"  [{symbol}] {tool}: {test}" + (f" — {detail}" if detail else ""))

    def summary(self) -> None:
        total = len(self.results)
        passed = sum(1 for r in self.results if r["status"] == PASS)
        failed = sum(1 for r in self.results if r["status"] == FAIL)
        skipped = sum(1 for r in self.results if r["status"] == SKIP)
        print()
        print("=" * 60)
        print(f"  VALIDATION SUMMARY: {passed}/{total} passed, "
              f"{failed} failed, {skipped} skipped")
        print("=" * 60)
        if failed:
            print()
            print("  FAILURES:")
            for r in self.results:
                if r["status"] == FAIL:
                    print(f"    {r['tool']}: {r['test']} — {r['detail']}")
        print()


def check_metadata(parsed: dict, report: ValidationReport, tool: str) -> None:
    """Verify response metadata matches the spec."""
    meta = parsed.get("metadata", {})
    if "Companies House" not in meta.get("source", ""):
        report.add(tool, "metadata.source", FAIL, f"Got: {meta.get('source')}")
    else:
        report.add(tool, "metadata.source", PASS)

    if "Open Government Licence" not in meta.get("licence", ""):
        report.add(tool, "metadata.licence", FAIL, f"Got: {meta.get('licence')}")
    else:
        report.add(tool, "metadata.licence", PASS)

    if "Contains public sector information" not in meta.get("attribution", ""):
        report.add(tool, "metadata.attribution", FAIL)
    else:
        report.add(tool, "metadata.attribution", PASS)

    if "retrieved_at" not in meta:
        report.add(tool, "metadata.retrieved_at", FAIL)
    else:
        report.add(tool, "metadata.retrieved_at", PASS)

    if "cached" not in meta:
        report.add(tool, "metadata.cached", FAIL)
    else:
        report.add(tool, "metadata.cached", PASS)


async def validate_search(report: ValidationReport) -> None:
    tool = "uk_companies_house_search"
    print(f"\n--- {tool} ---")

    # Normal search
    result = await serve.uk_companies_house_search(TEST_SEARCH_QUERY, 5)
    parsed = json.loads(result)

    if "data" in parsed and parsed["data"].get("total_results", 0) > 0:
        report.add(tool, "returns results", PASS,
                   f"{parsed['data']['total_results']} total")
    else:
        report.add(tool, "returns results", FAIL, "No results")
        return

    # Check _cleaning annotations on items
    item = parsed["data"]["items"][0]
    if "_cleaning" in item:
        report.add(tool, "_cleaning annotations present", PASS)
    else:
        report.add(tool, "_cleaning annotations present", FAIL)

    check_metadata(parsed, report, tool)

    # Empty query validation
    result = await serve.uk_companies_house_search("", 5)
    parsed = json.loads(result)
    if "error" in parsed:
        report.add(tool, "empty query returns error", PASS)
    else:
        report.add(tool, "empty query returns error", FAIL)


async def validate_profile(report: ValidationReport) -> None:
    tool = "uk_companies_house_profile"
    print(f"\n--- {tool} ---")

    # Normal profile
    result = await serve.uk_companies_house_profile(TEST_COMPANY_ACTIVE)
    parsed = json.loads(result)

    if "data" in parsed and parsed["data"].get("company_name"):
        report.add(tool, "returns company data", PASS,
                   parsed["data"]["company_name"])
    else:
        report.add(tool, "returns company data", FAIL)
        return

    # SIC descriptions
    if parsed["data"].get("sic_descriptions"):
        report.add(tool, "SIC descriptions added", PASS)
    else:
        report.add(tool, "SIC descriptions added", FAIL)

    # _cleaning annotations
    if parsed["data"].get("_cleaning"):
        report.add(tool, "_cleaning annotations", PASS)
    else:
        report.add(tool, "_cleaning annotations", FAIL)

    # Address normalisation
    addr = parsed["data"].get("registered_office_address", {})
    if addr.get("formatted"):
        report.add(tool, "address normalised", PASS, addr["formatted"])
    else:
        report.add(tool, "address normalised", FAIL)

    check_metadata(parsed, report, tool)

    # Number padding
    result = await serve.uk_companies_house_profile(TEST_COMPANY_SHORT_NUMBER)
    parsed = json.loads(result)
    if "data" in parsed and parsed["data"].get("company_name"):
        report.add(tool, "number padding works", PASS)
    else:
        report.add(tool, "number padding works", FAIL)

    # Not found
    result = await serve.uk_companies_house_profile("99999999")
    parsed = json.loads(result)
    if "error" in parsed:
        report.add(tool, "not found returns error", PASS)
    else:
        report.add(tool, "not found returns error", FAIL)


async def validate_officers(report: ValidationReport) -> None:
    tool = "uk_companies_house_officers"
    print(f"\n--- {tool} ---")

    result = await serve.uk_companies_house_officers(TEST_COMPANY_ACTIVE)
    parsed = json.loads(result)

    if "data" in parsed and len(parsed["data"].get("items", [])) > 0:
        report.add(tool, "returns officers", PASS,
                   f"{len(parsed['data']['items'])} officers")
    else:
        report.add(tool, "returns officers", FAIL)
        return

    # Dedup metadata
    cleaning = parsed["data"].get("_cleaning", {})
    if "original_count" in cleaning:
        report.add(tool, "dedup metadata present", PASS,
                   f"original={cleaning['original_count']}, "
                   f"deduped={cleaning['deduplicated_count']}")
    else:
        report.add(tool, "dedup metadata present", FAIL)

    # Active/resigned counts
    if "active_count" in parsed["data"]:
        report.add(tool, "active/resigned counts", PASS,
                   f"active={parsed['data']['active_count']}, "
                   f"resigned={parsed['data']['resigned_count']}")
    else:
        report.add(tool, "active/resigned counts", FAIL)

    check_metadata(parsed, report, tool)


async def validate_psc(report: ValidationReport) -> None:
    tool = "uk_companies_house_psc"
    print(f"\n--- {tool} ---")

    result = await serve.uk_companies_house_psc(TEST_COMPANY_ACTIVE)
    parsed = json.loads(result)

    if "data" in parsed:
        items = parsed["data"].get("items", [])
        report.add(tool, "returns PSC data", PASS, f"{len(items)} PSCs")
    else:
        report.add(tool, "returns PSC data", FAIL)
        return

    if items:
        item = items[0]
        # Entity type
        if item.get("_cleaning", {}).get("entity_type"):
            report.add(tool, "entity type classified", PASS,
                       item["_cleaning"]["entity_type"])
        else:
            report.add(tool, "entity type classified", FAIL)

        # Nature of control descriptions
        if item.get("natures_of_control_descriptions"):
            report.add(tool, "nature of control interpreted", PASS)
        else:
            report.add(tool, "nature of control interpreted", FAIL)

    # Active/ceased counts
    if "active_count" in parsed["data"]:
        report.add(tool, "active/ceased counts", PASS)
    else:
        report.add(tool, "active/ceased counts", FAIL)

    check_metadata(parsed, report, tool)


async def validate_filings(report: ValidationReport) -> None:
    tool = "uk_companies_house_filings"
    print(f"\n--- {tool} ---")

    result = await serve.uk_companies_house_filings(TEST_COMPANY_ACTIVE)
    parsed = json.loads(result)

    items = parsed.get("data", {}).get("items", [])
    if "data" in parsed and len(items) > 0:
        total = parsed["data"].get("total_results", len(items))
        report.add(tool, "returns filings", PASS, f"{total} total")
    else:
        report.add(tool, "returns filings", FAIL)
        return

    # Description rendering
    item = parsed["data"]["items"][0]
    if item.get("description_rendered"):
        report.add(tool, "description rendered", PASS, item["description_rendered"][:60])
    else:
        report.add(tool, "description rendered", FAIL)

    # _cleaning annotations
    if item.get("_cleaning"):
        report.add(tool, "_cleaning annotations", PASS)
    else:
        report.add(tool, "_cleaning annotations", FAIL)

    check_metadata(parsed, report, tool)

    # Invalid category
    result = await serve.uk_companies_house_filings(
        TEST_COMPANY_ACTIVE, category="invalid-cat"
    )
    parsed = json.loads(result)
    if "error" in parsed:
        report.add(tool, "invalid category returns error", PASS)
    else:
        report.add(tool, "invalid category returns error", FAIL)


async def validate_charges(report: ValidationReport) -> None:
    tool = "uk_companies_house_charges"
    print(f"\n--- {tool} ---")

    result = await serve.uk_companies_house_charges(TEST_COMPANY_ACTIVE)
    parsed = json.loads(result)

    if "data" in parsed:
        items = parsed["data"].get("items", [])
        report.add(tool, "returns charges", PASS, f"{len(items)} charges")
    else:
        report.add(tool, "returns charges", FAIL)
        return

    if items:
        item = items[0]
        if item.get("status_description"):
            report.add(tool, "status interpreted", PASS, item["status_description"])
        else:
            report.add(tool, "status interpreted", FAIL)

        if item.get("_cleaning"):
            report.add(tool, "_cleaning annotations", PASS)
        else:
            report.add(tool, "_cleaning annotations", FAIL)

    # Counts
    if "outstanding_count" in parsed["data"]:
        report.add(tool, "charge counts present", PASS,
                   f"outstanding={parsed['data']['outstanding_count']}, "
                   f"satisfied={parsed['data']['satisfied_count']}")
    else:
        report.add(tool, "charge counts present", FAIL)

    check_metadata(parsed, report, tool)


async def validate_insolvency(report: ValidationReport) -> None:
    tool = "uk_companies_house_insolvency"
    print(f"\n--- {tool} ---")

    # Try a company known to have insolvency history
    result = await serve.uk_companies_house_insolvency(TEST_COMPANY_WITH_INSOLVENCY)
    parsed = json.loads(result)

    if "data" in parsed:
        cases = parsed["data"].get("cases", [])
        report.add(tool, "returns data", PASS, f"{len(cases)} cases")
    else:
        report.add(tool, "returns data", FAIL)
        return

    if cases:
        case = cases[0]
        if case.get("type_description"):
            report.add(tool, "case type interpreted", PASS, case["type_description"])
        else:
            report.add(tool, "case type interpreted", FAIL)

        if case.get("_cleaning"):
            report.add(tool, "_cleaning annotations", PASS)
        else:
            report.add(tool, "_cleaning annotations", FAIL)
    else:
        # Might be empty — known API inconsistency
        if parsed["data"].get("_cleaning", {}).get("api_404_despite_profile_flag"):
            report.add(tool, "404 handled gracefully", PASS)
        else:
            report.add(tool, "no cases found", SKIP, "Company may not have insolvency")

    check_metadata(parsed, report, tool)

    # Company without insolvency — should get empty or 404-handled result
    result = await serve.uk_companies_house_insolvency(TEST_COMPANY_ACTIVE)
    parsed = json.loads(result)
    if "data" in parsed:
        report.add(tool, "no insolvency handled", PASS)
    else:
        report.add(tool, "no insolvency handled", FAIL)


async def validate_officer_search(report: ValidationReport) -> None:
    tool = "uk_companies_house_officer_search"
    print(f"\n--- {tool} ---")

    result = await serve.uk_companies_house_officer_search(TEST_OFFICER_SEARCH, 5)
    parsed = json.loads(result)

    if "data" in parsed and parsed["data"].get("total_results", 0) > 0:
        report.add(tool, "returns results", PASS,
                   f"{parsed['data']['total_results']} total")
    else:
        report.add(tool, "returns results", FAIL)
        return

    item = parsed["data"]["items"][0]

    # Officer ID extraction
    if item.get("officer_id"):
        report.add(tool, "officer_id extracted", PASS, item["officer_id"])
    else:
        report.add(tool, "officer_id extracted", FAIL)

    # Entity classification
    if item.get("_cleaning", {}).get("entity_type"):
        report.add(tool, "entity classified", PASS,
                   item["_cleaning"]["entity_type"])
    else:
        report.add(tool, "entity classified", FAIL)

    check_metadata(parsed, report, tool)

    # Empty query
    result = await serve.uk_companies_house_officer_search("")
    parsed = json.loads(result)
    if "error" in parsed:
        report.add(tool, "empty query returns error", PASS)
    else:
        report.add(tool, "empty query returns error", FAIL)


async def validate_officer_appointments(
    report: ValidationReport, officer_id: str
) -> None:
    tool = "uk_companies_house_officer_appointments"
    print(f"\n--- {tool} ---")

    if not officer_id:
        report.add(tool, "all tests", SKIP, "No officer_id from officer search")
        return

    result = await serve.uk_companies_house_officer_appointments(officer_id)
    parsed = json.loads(result)

    if "data" in parsed and len(parsed["data"].get("items", [])) > 0:
        report.add(tool, "returns appointments", PASS,
                   f"{parsed['data']['total_results']} total")
    else:
        report.add(tool, "returns appointments", FAIL)
        return

    item = parsed["data"]["items"][0]

    # Company number padding
    co_num = item.get("appointed_to", {}).get("company_number", "")
    if len(co_num) == 8 or (not co_num.isdigit()):
        report.add(tool, "company number padded", PASS)
    else:
        report.add(tool, "company number padded", FAIL, co_num)

    # Active/resigned counts
    if "active_count" in parsed["data"]:
        report.add(tool, "active/resigned counts", PASS,
                   f"active={parsed['data']['active_count']}, "
                   f"resigned={parsed['data']['resigned_count']}")
    else:
        report.add(tool, "active/resigned counts", FAIL)

    check_metadata(parsed, report, tool)


async def validate_disqualified(report: ValidationReport) -> None:
    tool = "uk_companies_house_disqualified_officer"
    print(f"\n--- {tool} ---")

    # Non-existent officer — should return "not disqualified"
    result = await serve.uk_companies_house_disqualified_officer("nonexistent123")
    parsed = json.loads(result)
    if "data" in parsed and parsed["data"].get("disqualified") is False:
        report.add(tool, "not disqualified handled", PASS)
    else:
        report.add(tool, "not disqualified handled", FAIL)

    check_metadata(parsed, report, tool)

    # Invalid type
    result = await serve.uk_companies_house_disqualified_officer("test", "invalid")
    parsed = json.loads(result)
    if "error" in parsed:
        report.add(tool, "invalid type returns error", PASS)
    else:
        report.add(tool, "invalid type returns error", FAIL)

    # Empty ID
    result = await serve.uk_companies_house_disqualified_officer("")
    parsed = json.loads(result)
    if "error" in parsed:
        report.add(tool, "empty id returns error", PASS)
    else:
        report.add(tool, "empty id returns error", FAIL)


async def validate_advanced_search(report: ValidationReport) -> None:
    tool = "uk_companies_house_advanced_search"
    print(f"\n--- {tool} ---")

    result = await serve.uk_companies_house_advanced_search(
        company_status="active", sic_codes="47110", size=5
    )
    parsed = json.loads(result)

    if "data" in parsed and parsed["data"].get("total_results", 0) > 0:
        report.add(tool, "returns results", PASS,
                   f"{parsed['data']['total_results']} total")
    else:
        report.add(tool, "returns results", FAIL)
        return

    item = parsed["data"]["items"][0]

    # Company number padding
    if item.get("_cleaning", {}).get("company_number_padded") is not None:
        report.add(tool, "company number padding annotation", PASS)
    else:
        report.add(tool, "company number padding annotation", FAIL)

    # SIC descriptions
    if item.get("sic_descriptions"):
        report.add(tool, "SIC descriptions added", PASS)
    else:
        report.add(tool, "SIC descriptions added", FAIL)

    check_metadata(parsed, report, tool)

    # No filters
    result = await serve.uk_companies_house_advanced_search()
    parsed = json.loads(result)
    if "error" in parsed:
        report.add(tool, "no filters returns error", PASS)
    else:
        report.add(tool, "no filters returns error", FAIL)


async def validate_registered_address(report: ValidationReport) -> None:
    tool = "uk_companies_house_registered_address"
    print(f"\n--- {tool} ---")

    result = await serve.uk_companies_house_registered_address(TEST_COMPANY_ACTIVE)
    parsed = json.loads(result)

    if "data" in parsed and parsed["data"].get("postal_code"):
        report.add(tool, "returns address", PASS,
                   parsed["data"].get("formatted", ""))
    else:
        report.add(tool, "returns address", FAIL)
        return

    # Postcode formatting
    pc = parsed["data"]["postal_code"]
    if " " in pc and pc == pc.upper():
        report.add(tool, "postcode formatted", PASS, pc)
    else:
        report.add(tool, "postcode formatted", FAIL, pc)

    # Cleaning annotations
    cleaning = parsed["data"].get("_cleaning", {})
    if "address_normalised" in cleaning:
        report.add(tool, "_cleaning annotations", PASS)
    else:
        report.add(tool, "_cleaning annotations", FAIL)

    check_metadata(parsed, report, tool)

    # Not found
    result = await serve.uk_companies_house_registered_address("99999999")
    parsed = json.loads(result)
    if "error" in parsed:
        report.add(tool, "not found returns error", PASS)
    else:
        report.add(tool, "not found returns error", FAIL)


async def main() -> None:
    print("=" * 60)
    print("  STAGE 8: Live API Validation")
    print("  Testing all 12 tools against Companies House API")
    print("=" * 60)

    report = ValidationReport()

    # Validate each tool
    await validate_search(report)
    await validate_profile(report)
    await validate_officers(report)
    await validate_psc(report)
    await validate_filings(report)
    await validate_charges(report)
    await validate_insolvency(report)
    await validate_officer_search(report)

    # Get an officer_id from the search for the appointments test
    officer_id = ""
    try:
        result = await serve.uk_companies_house_officer_search(TEST_OFFICER_SEARCH, 1)
        parsed = json.loads(result)
        items = parsed.get("data", {}).get("items", [])
        if items:
            officer_id = items[0].get("officer_id", "")
    except Exception:
        pass

    await validate_officer_appointments(report, officer_id)
    await validate_disqualified(report)
    await validate_advanced_search(report)
    await validate_registered_address(report)

    report.summary()


if __name__ == "__main__":
    asyncio.run(main())
