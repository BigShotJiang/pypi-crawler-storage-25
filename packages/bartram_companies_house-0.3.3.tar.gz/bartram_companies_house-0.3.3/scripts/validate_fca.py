#!/usr/bin/env python3
"""Stage 8 validation: run every tool against the live FCA API.

Usage:
    # Credentials from .env (loaded automatically by dotenv or set manually):
    export FCA_API_EMAIL="hello@bartram.ai"
    export FCA_API_KEY="your-key"
    python scripts/validate_fca.py

Tests all 19 tools with real data and verifies output matches the Tool Spec:
- Input handling (normalisation, validation, error messages)
- Data retrieval (pagination, caching)
- Data cleaning (annotations present and correct)
- Edge cases (empty results, not found)
- Response metadata (source, licence, attribution)
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bartram_fca import serve

# Test data — Barclays (FRN 122702) is large, well-populated across sub-resources.
TEST_FRM_BARCLAYS = "122702"
TEST_FRN_SMALL = "615820"  # Smaller firm for variety.
TEST_FRN_NONEXISTENT = "999999"
TEST_FRN_UNNORMALISED = "FRN-122702"
TEST_IRN = "JXD01375"
TEST_IRN_NONEXISTENT = "ZZZZZ999"
TEST_IRN_LOWERCASE = "jxd01375"
TEST_SEARCH_QUERY = "Barclays"
TEST_REQ_REF = "OR-0170047"  # Known requirement reference for Barclays.

PASS = "PASS"
FAIL = "FAIL"
SKIP = "SKIP"


class ValidationReport:
    def __init__(self) -> None:
        self.results: list[dict] = []

    def add(self, tool: str, test: str, status: str, detail: str = "") -> None:
        self.results.append({
            "tool": tool, "test": test, "status": status, "detail": detail,
        })
        symbol = {"PASS": "+", "FAIL": "!", "SKIP": "-"}[status]
        print(f"  [{symbol}] {tool}: {test}" + (f" — {detail}" if detail else ""))

    def summary(self) -> None:
        total = len(self.results)
        passed = sum(1 for r in self.results if r["status"] == PASS)
        failed = sum(1 for r in self.results if r["status"] == FAIL)
        skipped = sum(1 for r in self.results if r["status"] == SKIP)
        print()
        print("=" * 60)
        print(f"  VALIDATION SUMMARY: {passed}/{total} passed, "
              f"{failed} failed, {skipped} skipped")
        print("=" * 60)
        if failed:
            print()
            print("  FAILURES:")
            for r in self.results:
                if r["status"] == FAIL:
                    print(f"    {r['tool']}: {r['test']} — {r['detail']}")
        print()


def check_metadata(parsed: dict, report: ValidationReport, tool: str) -> None:
    """Verify response metadata matches the spec."""
    meta = parsed.get("metadata", {})
    if "FCA" not in meta.get("source", ""):
        report.add(tool, "metadata.source", FAIL, f"Got: {meta.get('source')}")
    else:
        report.add(tool, "metadata.source", PASS)

    if meta.get("licence"):
        report.add(tool, "metadata.licence", PASS)
    else:
        report.add(tool, "metadata.licence", FAIL)

    if "FCA" in meta.get("attribution", "") or "Financial Conduct" in meta.get("attribution", ""):
        report.add(tool, "metadata.attribution", PASS)
    else:
        report.add(tool, "metadata.attribution", FAIL)

    if "retrieved_at" in meta:
        report.add(tool, "metadata.retrieved_at", PASS)
    else:
        report.add(tool, "metadata.retrieved_at", FAIL)

    if "cached" in meta:
        report.add(tool, "metadata.cached", PASS)
    else:
        report.add(tool, "metadata.cached", FAIL)


def has_cleaning(data: dict) -> bool:
    return "_cleaning" in data


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


async def validate_search(report: ValidationReport) -> None:
    tool = "uk_fca_search"
    print(f"\n--- {tool} ---")

    result = json.loads(await serve.uk_fca_search(TEST_SEARCH_QUERY))
    if "data" in result and has_cleaning(result["data"]):
        report.add(tool, "returns data with _cleaning", PASS)
    else:
        report.add(tool, "returns data with _cleaning", FAIL)
        return

    check_metadata(result, report, tool)

    # Empty query
    result = json.loads(await serve.uk_fca_search(""))
    if "error" in result:
        report.add(tool, "empty query returns error", PASS)
    else:
        report.add(tool, "empty query returns error", FAIL)

    # Special chars
    result = json.loads(await serve.uk_fca_search("***"))
    if "error" in result:
        report.add(tool, "special chars rejected", PASS)
    else:
        report.add(tool, "special chars rejected", FAIL)


# ---------------------------------------------------------------------------
# Firm details
# ---------------------------------------------------------------------------


async def validate_firm(report: ValidationReport) -> None:
    tool = "uk_fca_firm"
    print(f"\n--- {tool} ---")

    result = json.loads(await serve.uk_fca_firm(TEST_FRM_BARCLAYS))
    if "data" not in result:
        report.add(tool, "returns data", FAIL)
        return

    data = result["data"]
    cleaning = data.get("_cleaning", {})

    report.add(tool, "returns data", PASS)

    if cleaning.get("data_unwrapped"):
        report.add(tool, "Data[0] unwrapped", PASS)
    else:
        report.add(tool, "Data[0] unwrapped", FAIL)

    if cleaning.get("hateoas_replaced"):
        report.add(tool, "HATEOAS links replaced", PASS)
    else:
        report.add(tool, "HATEOAS links replaced", FAIL)

    if "related_endpoints" in data:
        report.add(tool, "related_endpoints present", PASS,
                   f"{len(data['related_endpoints'])} endpoints")
    else:
        report.add(tool, "related_endpoints present", FAIL)

    if cleaning.get("fields_normalised"):
        report.add(tool, "fields normalised", PASS)
    else:
        report.add(tool, "fields normalised", FAIL)

    check_metadata(result, report, tool)

    # FRN normalisation
    result2 = json.loads(await serve.uk_fca_firm(TEST_FRN_UNNORMALISED))
    if "data" in result2:
        report.add(tool, "FRN normalisation works", PASS)
    else:
        report.add(tool, "FRN normalisation works", FAIL)

    # Invalid FRN
    result3 = json.loads(await serve.uk_fca_firm(""))
    if "error" in result3:
        report.add(tool, "empty FRN returns error", PASS)
    else:
        report.add(tool, "empty FRN returns error", FAIL)


# ---------------------------------------------------------------------------
# Firm sub-resources
# ---------------------------------------------------------------------------


async def validate_firm_names(report: ValidationReport) -> None:
    tool = "uk_fca_firm_names"
    print(f"\n--- {tool} ---")

    result = json.loads(await serve.uk_fca_firm_names(TEST_FRM_BARCLAYS))
    if "data" not in result:
        report.add(tool, "returns data", FAIL)
        return

    data = result["data"]
    cleaning = data.get("_cleaning", {})
    report.add(tool, "returns data", PASS)

    if cleaning.get("names_flattened"):
        report.add(tool, "names flattened (Current/Previous)", PASS)
    else:
        report.add(tool, "names flattened", FAIL)

    if cleaning.get("dates_normalised"):
        report.add(tool, "dates normalised", PASS)
    else:
        report.add(tool, "dates normalised", SKIP, "May not have dates")

    check_metadata(result, report, tool)


async def validate_firm_address(report: ValidationReport) -> None:
    tool = "uk_fca_firm_address"
    print(f"\n--- {tool} ---")

    result = json.loads(await serve.uk_fca_firm_address(TEST_FRM_BARCLAYS))
    if "data" in result and has_cleaning(result["data"]):
        report.add(tool, "returns data with _cleaning", PASS)
    else:
        report.add(tool, "returns data", FAIL)

    check_metadata(result, report, tool)


async def validate_firm_permissions(report: ValidationReport) -> None:
    tool = "uk_fca_firm_permissions"
    print(f"\n--- {tool} ---")

    result = json.loads(await serve.uk_fca_firm_permissions(TEST_FRM_BARCLAYS))
    if "data" not in result:
        report.add(tool, "returns data", FAIL)
        return

    data = result["data"]
    cleaning = data.get("_cleaning", {})
    report.add(tool, "returns data", PASS)

    if cleaning.get("permissions_restructured"):
        report.add(tool, "permissions restructured", PASS)
    else:
        report.add(tool, "permissions restructured", FAIL)

    check_metadata(result, report, tool)


async def validate_firm_individuals(report: ValidationReport) -> None:
    tool = "uk_fca_firm_individuals"
    print(f"\n--- {tool} ---")

    result = json.loads(await serve.uk_fca_firm_individuals(TEST_FRM_BARCLAYS))
    if "data" in result and has_cleaning(result["data"]):
        report.add(tool, "returns data with _cleaning", PASS)
    else:
        report.add(tool, "returns data", FAIL)

    check_metadata(result, report, tool)


async def validate_firm_cf(report: ValidationReport) -> None:
    tool = "uk_fca_firm_control_functions"
    print(f"\n--- {tool} ---")

    result = json.loads(await serve.uk_fca_firm_control_functions(TEST_FRM_BARCLAYS))
    if "data" not in result:
        report.add(tool, "returns data", FAIL)
        return

    data = result["data"]
    cleaning = data.get("_cleaning", {})
    report.add(tool, "returns data", PASS)

    if cleaning.get("cf_parsed"):
        report.add(tool, "CF codes parsed", PASS)
    else:
        report.add(tool, "CF codes parsed", FAIL)

    check_metadata(result, report, tool)


async def validate_firm_requirements(report: ValidationReport) -> None:
    tool = "uk_fca_firm_requirements"
    print(f"\n--- {tool} ---")

    result = json.loads(await serve.uk_fca_firm_requirements(TEST_FRM_BARCLAYS))
    if "data" in result and has_cleaning(result["data"]):
        report.add(tool, "returns data with _cleaning", PASS)
    else:
        report.add(tool, "returns data", FAIL)

    check_metadata(result, report, tool)


async def validate_firm_req_invtypes(report: ValidationReport) -> None:
    tool = "uk_fca_firm_requirement_investment_types"
    print(f"\n--- {tool} ---")

    result = json.loads(
        await serve.uk_fca_firm_requirement_investment_types(
            TEST_FRM_BARCLAYS, TEST_REQ_REF
        )
    )
    if "data" in result:
        report.add(tool, "returns data", PASS)
    else:
        report.add(tool, "returns data", FAIL)

    check_metadata(result, report, tool)

    # Empty ref
    result2 = json.loads(
        await serve.uk_fca_firm_requirement_investment_types(TEST_FRM_BARCLAYS, "")
    )
    if "error" in result2:
        report.add(tool, "empty ref returns error", PASS)
    else:
        report.add(tool, "empty ref returns error", FAIL)


async def validate_firm_regulators(report: ValidationReport) -> None:
    tool = "uk_fca_firm_regulators"
    print(f"\n--- {tool} ---")

    result = json.loads(await serve.uk_fca_firm_regulators(TEST_FRM_BARCLAYS))
    if "data" in result and has_cleaning(result["data"]):
        report.add(tool, "returns data with _cleaning", PASS)
    else:
        report.add(tool, "returns data", FAIL)

    check_metadata(result, report, tool)


async def validate_firm_passports(report: ValidationReport) -> None:
    tool = "uk_fca_firm_passports"
    print(f"\n--- {tool} ---")

    result = json.loads(await serve.uk_fca_firm_passports(TEST_FRM_BARCLAYS))
    if "data" in result:
        report.add(tool, "returns data", PASS)
    else:
        report.add(tool, "returns data", FAIL)

    check_metadata(result, report, tool)


async def validate_firm_passport_permissions(report: ValidationReport) -> None:
    tool = "uk_fca_firm_passport_permissions"
    print(f"\n--- {tool} ---")

    result = json.loads(
        await serve.uk_fca_firm_passport_permissions(TEST_FRM_BARCLAYS)
    )
    # This endpoint may not exist — accept either data or error.
    if "data" in result or "error" in result:
        report.add(tool, "returns response", PASS)
    else:
        report.add(tool, "returns response", FAIL)


async def validate_firm_ar(report: ValidationReport) -> None:
    tool = "uk_fca_firm_appointed_reps"
    print(f"\n--- {tool} ---")

    result = json.loads(await serve.uk_fca_firm_appointed_reps(TEST_FRM_BARCLAYS))
    if "data" in result and has_cleaning(result["data"]):
        report.add(tool, "returns data with _cleaning", PASS)
    else:
        report.add(tool, "returns data", FAIL)

    check_metadata(result, report, tool)


async def validate_firm_waivers(report: ValidationReport) -> None:
    tool = "uk_fca_firm_waivers"
    print(f"\n--- {tool} ---")

    result = json.loads(await serve.uk_fca_firm_waivers(TEST_FRM_BARCLAYS))
    if "data" in result and has_cleaning(result["data"]):
        report.add(tool, "returns data with _cleaning", PASS)
    else:
        report.add(tool, "returns data", FAIL)

    check_metadata(result, report, tool)


async def validate_firm_exclusions(report: ValidationReport) -> None:
    tool = "uk_fca_firm_exclusions"
    print(f"\n--- {tool} ---")

    result = json.loads(await serve.uk_fca_firm_exclusions(TEST_FRM_BARCLAYS))
    if "data" in result and has_cleaning(result["data"]):
        report.add(tool, "returns data with _cleaning", PASS)
    else:
        report.add(tool, "returns data", FAIL)

    check_metadata(result, report, tool)


async def validate_firm_disciplinary(report: ValidationReport) -> None:
    tool = "uk_fca_firm_disciplinary_history"
    print(f"\n--- {tool} ---")

    result = json.loads(
        await serve.uk_fca_firm_disciplinary_history(TEST_FRM_BARCLAYS)
    )
    if "data" in result and has_cleaning(result["data"]):
        report.add(tool, "returns data with _cleaning", PASS)
    else:
        report.add(tool, "returns data", FAIL)

    check_metadata(result, report, tool)


# ---------------------------------------------------------------------------
# Individual
# ---------------------------------------------------------------------------


async def validate_individual(report: ValidationReport) -> None:
    tool = "uk_fca_individual"
    print(f"\n--- {tool} ---")

    result = json.loads(await serve.uk_fca_individual(TEST_IRN))
    if "data" not in result:
        report.add(tool, "returns data", FAIL)
        return

    data = result["data"]
    cleaning = data.get("_cleaning", {})
    report.add(tool, "returns data", PASS)

    if cleaning.get("data_unwrapped"):
        report.add(tool, "Data[0][Details] unwrapped", PASS)
    else:
        report.add(tool, "Data[0][Details] unwrapped", FAIL)

    if cleaning.get("hateoas_replaced"):
        report.add(tool, "HATEOAS links replaced", PASS)
    else:
        report.add(tool, "HATEOAS links replaced", FAIL)

    if "related_endpoints" in data:
        report.add(tool, "related_endpoints present", PASS)
    else:
        report.add(tool, "related_endpoints present", FAIL)

    if "irn" in data:
        report.add(tool, "IRN field present", PASS)
    else:
        report.add(tool, "IRN field present", FAIL)

    if "full_name" in data:
        report.add(tool, "full_name field present", PASS)
    else:
        report.add(tool, "full_name field present", FAIL)

    check_metadata(result, report, tool)

    # IRN normalisation (lowercase)
    result2 = json.loads(await serve.uk_fca_individual(TEST_IRN_LOWERCASE))
    if "data" in result2:
        report.add(tool, "IRN normalisation works", PASS)
    else:
        report.add(tool, "IRN normalisation works", FAIL)

    # Invalid IRN
    result3 = json.loads(await serve.uk_fca_individual(""))
    if "error" in result3:
        report.add(tool, "empty IRN returns error", PASS)
    else:
        report.add(tool, "empty IRN returns error", FAIL)


async def validate_individual_cf(report: ValidationReport) -> None:
    tool = "uk_fca_individual_control_functions"
    print(f"\n--- {tool} ---")

    result = json.loads(
        await serve.uk_fca_individual_control_functions(TEST_IRN)
    )
    if "data" in result:
        report.add(tool, "returns data", PASS)
    else:
        report.add(tool, "returns data", FAIL)

    check_metadata(result, report, tool)


async def validate_individual_disciplinary(report: ValidationReport) -> None:
    tool = "uk_fca_individual_disciplinary_history"
    print(f"\n--- {tool} ---")

    result = json.loads(
        await serve.uk_fca_individual_disciplinary_history(TEST_IRN)
    )
    if "data" in result:
        report.add(tool, "returns data", PASS)
    else:
        report.add(tool, "returns data", FAIL)

    check_metadata(result, report, tool)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


async def main() -> None:
    print("=" * 60)
    print("  STAGE 8: Live API Validation")
    print("  Testing all 19 FCA tools against the live API")
    print("=" * 60)

    report = ValidationReport()

    await validate_search(report)
    await validate_firm(report)
    await validate_firm_names(report)
    await validate_firm_address(report)
    await validate_firm_permissions(report)
    await validate_firm_individuals(report)
    await validate_firm_cf(report)
    await validate_firm_requirements(report)
    await validate_firm_req_invtypes(report)
    await validate_firm_regulators(report)
    await validate_firm_passports(report)
    await validate_firm_passport_permissions(report)
    await validate_firm_ar(report)
    await validate_firm_waivers(report)
    await validate_firm_exclusions(report)
    await validate_firm_disciplinary(report)
    await validate_individual(report)
    await validate_individual_cf(report)
    await validate_individual_disciplinary(report)

    report.summary()


if __name__ == "__main__":
    asyncio.run(main())
