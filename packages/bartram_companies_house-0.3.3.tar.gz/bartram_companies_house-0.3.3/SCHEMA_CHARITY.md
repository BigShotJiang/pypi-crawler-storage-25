# Schema Reference — Charity Commission for England and Wales

Complete tool reference for the UK Charity Commission MCP server. Each tool follows the `access -> clean -> serve` pattern: raw API data is fetched, cleaned, and returned in a consistent envelope.

## Response envelope

Every successful response wraps data in this structure:

```json
{
  "data": { ... },
  "metadata": {
    "source": "Charity Commission for England and Wales",
    "licence": "Open Government Licence v3",
    "retrieved_at": "2026-04-05T10:00:00+00:00",
    "endpoint": "charityRegNumber/220949/0",
    "cached": false,
    "attribution": "Contains public sector information licensed under the Open Government Licence v3.0. Source: Charity Commission for England and Wales."
  }
}
```

Error responses:

```json
{
  "error": "not_found",
  "message": "Resource not found.",
  "status_code": 404,
  "attribution": "Contains public sector information licensed under the Open Government Licence v3.0. Source: Charity Commission for England and Wales."
}
```

---

## uk_charity_search

Search for charities by name.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | yes | — | Charity name or partial name to search for |

### Returns

`data` contains a list of matching charities with registration details and status.

### Cleaning applied

- Status codes mapped to human-readable labels (`R` → `Registered`, `RM` → `Removed`).
- Dates normalised to ISO 8601.
- Names cleaned and normalised.
- Text fields trimmed and whitespace collapsed.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_search", "arguments": {"query": "British Red Cross"}}
```

---

## uk_charity_lookup

Look up a specific charity by registered number.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number. Leading zeros and whitespace stripped automatically. |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains core charity details including name, status, dates, address, and financial summary.

### Cleaning applied

- Charity number normalised (whitespace, leading zeros stripped).
- Status codes mapped (`R` → `Registered`).
- Dates normalised to ISO 8601.
- Address lines normalised with postcode formatting.
- URL normalised.
- Text fields cleaned.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_lookup", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_search_by_registration_date

Find charities registered within a date range.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `start_date` | string | yes | — | Start date in YYYY-MM-DD format |
| `end_date` | string | yes | — | End date in YYYY-MM-DD format |

### Returns

`data` contains matching charities registered between the two dates.

### Cleaning applied

- Same cleaning as `uk_charity_search`.
- Date range validated (start must be before end).

### Example call

```json
{"name": "uk_charity_search_by_registration_date", "arguments": {"start_date": "2024-01-01", "end_date": "2024-12-31"}}
```

---

## uk_charity_search_by_removal_date

Find charities removed within a date range.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `start_date` | string | yes | — | Start date in YYYY-MM-DD format |
| `end_date` | string | yes | — | End date in YYYY-MM-DD format |

### Returns

`data` contains charities removed between the two dates with removal reasons.

### Cleaning applied

- Same cleaning as `uk_charity_search`.
- Date range validated (start must be before end).

### Example call

```json
{"name": "uk_charity_search_by_removal_date", "arguments": {"start_date": "2024-01-01", "end_date": "2024-06-30"}}
```

---

## uk_charity_profile

Get comprehensive details for a charity (V2 endpoint).

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains the full charity profile including trustees, classifications, areas of operation, contact details, and financial summary in one call.

### Cleaning applied

- All fields from `uk_charity_lookup` cleaning.
- Trustee names normalised.
- Classifications grouped into What/Who/How.
- Financial data structured.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_profile", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_details

Get core charity details without nested data.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains status, dates, address, contact, income/expenditure, and flags without trustees, classifications, or areas.

### Cleaning applied

- Status codes mapped.
- Dates normalised to ISO 8601.
- Address normalised with postcode formatting.
- Text fields cleaned.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_details", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_batch_lookup

Fetch details for multiple charities in a single call.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_numbers` | string | yes | — | Comma-separated list of charity numbers (max 20). Duplicates removed. |

### Returns

`data` contains a `charities` list with cleaned details for each found charity, plus `requested`, `found`, and `not_found` counts.

### Cleaning applied

- Each charity number validated and normalised.
- Duplicate numbers deduplicated.
- Per-charity cleaning (status, dates, addresses).
- Missing charity numbers tracked in response.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_batch_lookup", "arguments": {"charity_numbers": "220949,1014651,202918"}}
```

---

## uk_charity_trustees

Get detailed trustee information with appointment dates.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains trustee list with names, appointment dates, chair identification, and cross-references to other charities.

### Cleaning applied

- Trustee names normalised using shared UK name utilities.
- Dates normalised to ISO 8601.
- Chair flag extracted.
- Cross-references to other charities structured.
- Field name aliasing (`name`/`trustee_name` handled).
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_trustees", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_trustee_names

Get lightweight trustee name list.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains a simple list of trustee names without appointment details. Faster than `uk_charity_trustees` when only names are needed.

### Cleaning applied

- Names normalised.
- Field name aliasing (`name`/`trustee_name` handled).
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_trustee_names", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_classifications

Get What/Who/How classification details.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains classifications grouped into three categories: What (100-series codes — purposes), Who (200-series — beneficiaries), How (300-series — methods).

### Cleaning applied

- Flat classification list grouped by code range into What/Who/How.
- Classification descriptions cleaned.
- Field name aliasing (`classification_desc`/`classification_description` handled).
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_classifications", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_areas_of_operation

Get all geographic areas where a charity operates.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains three sections: `countries` (with continent grouping), `regions`, and `local_authorities` (with metropolitan county and Welsh indicator). Combines three API endpoints into one response.

### Cleaning applied

- Three API calls merged into unified response.
- Text fields cleaned.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_areas_of_operation", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_contact

Get contact details for a charity.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains address, phone, email, and website.

### Cleaning applied

- Address lines normalised.
- Postcode formatted.
- URL normalised.
- Text fields cleaned.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_contact", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_constituency

Get the parliamentary constituency of a charity.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains the constituency name.

### Cleaning applied

- Field name aliasing (`constituency_name`/`constituency` handled).
- Text fields cleaned.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_constituency", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_policies

Get governance policies declared by a charity.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains declared policies such as complaints handling, risk management, safeguarding, and investment policies.

### Cleaning applied

- Text fields cleaned.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_policies", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_other_regulators

Get other regulatory bodies that oversee a charity.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains a list of other regulatory bodies.

### Cleaning applied

- Text fields cleaned.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_other_regulators", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_primary_grants

Check whether a charity's primary purpose is grant-making.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains the grant-making status flag.

### Cleaning applied

- Text fields cleaned.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_primary_grants", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_financial_history

Get 5-year financial history with income breakdown.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains a `years` array with per-year income, expenditure, and computed trend percentages. Includes government funding flagging.

### Cleaning applied

- Dates normalised to ISO 8601.
- Year-on-year income trends calculated with percentage change.
- Zero-income edge cases handled (uses `is not None` checks).
- Government funding flagged.
- Financial data structured into consistent format.
- Field name aliasing (`latest_acc_fin_year_*`/`latest_acc_fin_period_*` handled).
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_financial_history", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_annual_return

Get the most recent Annual Return overview.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains activities, staffing, pay bands, trustee benefits, and financials from the most recent Annual Return.

### Cleaning applied

- Dates normalised to ISO 8601.
- Text fields cleaned.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_annual_return", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_accounts

Get accounts and Annual Return submission history.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains submission history with overdue flagging, qualified accounts detection, and suppression tracking.

### Cleaning applied

- Dates normalised to ISO 8601.
- Overdue submissions flagged.
- Qualified accounts detected.
- Suppressed records tracked.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_accounts", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_assets

Get most recent assets and liabilities balance sheet.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains asset and liability components with computed net assets.

### Cleaning applied

- Net assets calculated from component values.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_assets", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_governing_document

Get governing document details and charitable objects.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains the governing document type, charitable objects, and area of benefit.

### Cleaning applied

- Text fields cleaned (single pass, no double-cleaning).
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_governing_document", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_governance

Get governance summary.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains charity type, Companies House cross-reference, gift aid status, and land ownership.

### Cleaning applied

- Companies House number cross-referenced.
- Text fields cleaned.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_governance", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_linked_charities

Get all linked/subsidiary charities.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains linked charities with their registration details.

### Cleaning applied

- Status codes mapped.
- Text fields cleaned (single pass).
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_linked_charities", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_other_names

Get working names and historical names for a charity.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains names categorised into working names and previous names.

### Cleaning applied

- Names categorised by type.
- Text fields cleaned.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_other_names", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_registration_history

Get the registration event history for a charity.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains registration events sorted chronologically with type labelling (registration vs asset transfer).

### Cleaning applied

- Dates normalised to ISO 8601.
- Events sorted chronologically.
- Event type labelled.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_registration_history", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_regulatory_reports

Get published regulatory reports.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains inquiry reports, warnings, orders, and schemes.

### Cleaning applied

- Dates normalised to ISO 8601.
- Report types labelled.
- Text fields cleaned.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_regulatory_reports", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_cio_dissolution

Get CIO dissolution notice details.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `charity_number` | string | yes | — | Registered charity number |
| `suffix` | int | no | 0 | Subsidiary suffix (0 for main charity) |

### Returns

`data` contains dissolution notice details for Charitable Incorporated Organisations.

### Cleaning applied

- Dates normalised to ISO 8601.
- Text fields cleaned.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_cio_dissolution", "arguments": {"charity_number": "220949"}}
```

---

## uk_charity_sector_overview

Get overall charity sector statistics.

### Parameters

None.

### Returns

`data` contains total charities, aggregate income/expenditure, and staffing numbers.

### Cleaning applied

- Field name aliasing (`number_of_main_charities`/`total_main_charities` handled).
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_sector_overview", "arguments": {}}
```

---

## uk_charity_sector_top10

Get top 10 charities ranked by a specified metric.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `list_type` | string | yes | — | Metric to rank by. Valid values: `employees`, `expenditure`, `expenditure charitable activities`, `expenditure growth`, `income`, `income growth`, `investment gains`, `investments`, `overdue`, `volunteers`. |

### Returns

`data` contains the top 10 charities for the specified metric.

### Cleaning applied

- `list_type` validated against allowed values (case-insensitive).
- Text fields cleaned.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_sector_top10", "arguments": {"list_type": "income"}}
```

---

## uk_charity_sector_income_bands

Get charity sector data broken down by income bands.

### Parameters

None.

### Returns

`data` contains sector statistics grouped by income band.

### Cleaning applied

- Text fields cleaned.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_sector_income_bands", "arguments": {}}
```

---

## uk_charity_sector_income_categories

Get charity sector data broken down by income category.

### Parameters

None.

### Returns

`data` contains sector statistics grouped by income category.

### Cleaning applied

- Text fields cleaned.
- `_cleaning` annotations.

### Example call

```json
{"name": "uk_charity_sector_income_categories", "arguments": {}}
```
