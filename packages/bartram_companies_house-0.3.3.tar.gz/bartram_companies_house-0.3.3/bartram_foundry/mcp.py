"""MCP response formatting helpers.

Shared response envelope construction for all MCP tool servers.
Provides consistent formatting for data responses, error responses,
and metadata across Companies House and FCA tools.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any


def format_response(
    data: Any,
    *,
    source: str,
    licence: str,
    attribution: str,
    endpoint: str,
    cached: bool = False,
) -> str:
    """Format a cleaned API response as a JSON string with metadata envelope.

    All MCP tools should use this to ensure a consistent response structure.
    """
    envelope = {
        "data": data,
        "metadata": {
            "source": source,
            "licence": licence,
            "retrieved_at": datetime.now(tz=timezone.utc).isoformat(),
            "endpoint": endpoint,
            "cached": cached,
            "attribution": attribution,
        },
    }
    return json.dumps(envelope, indent=2, default=str)


def format_error(
    error_type: str,
    message: str,
    attribution: str,
    *,
    status_code: int | None = None,
    extra: dict[str, Any] | None = None,
) -> str:
    """Format an error as a JSON string with consistent structure.

    Args:
        error_type: Short error category (e.g. "not_found", "rate_limited").
        message: Human-readable error description.
        attribution: Data source attribution string.
        status_code: Optional HTTP or API status code.
        extra: Optional additional fields to include.
    """
    result: dict[str, Any] = {
        "error": error_type,
        "message": message,
        "attribution": attribution,
    }
    if status_code is not None:
        result["status_code"] = status_code
    if extra:
        result.update(extra)
    return json.dumps(result)
