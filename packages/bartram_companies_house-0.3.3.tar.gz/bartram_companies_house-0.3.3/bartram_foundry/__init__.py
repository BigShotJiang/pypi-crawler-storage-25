"""Bartram Foundry — shared infrastructure for MCP tool production."""

__version__ = "0.3.1"
