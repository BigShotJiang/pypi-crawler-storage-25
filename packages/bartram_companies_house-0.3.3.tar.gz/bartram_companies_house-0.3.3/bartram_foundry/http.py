"""HTTP client helpers: retry with exponential backoff for transient failures.

Provides a reusable retry wrapper for government API access. Handles:
- Automatic retries with exponential backoff for timeouts and 5xx errors
- Configurable max retries and base delay
"""

from __future__ import annotations

import time
from typing import Any, Callable, TypeVar

import httpx

T = TypeVar("T")

# Transient HTTP status codes worth retrying.
_RETRYABLE_STATUS_CODES = frozenset({429, 500, 502, 503, 504})


def is_retryable_error(exc: Exception) -> bool:
    """Check if an exception represents a transient, retryable failure."""
    return isinstance(exc, (httpx.TimeoutException, httpx.NetworkError))


def is_retryable_status(status_code: int) -> bool:
    """Check if an HTTP status code indicates a transient failure."""
    return status_code in _RETRYABLE_STATUS_CODES


def retry_request(
    func: Callable[..., T],
    *args: Any,
    max_retries: int = 2,
    base_delay: float = 1.0,
    **kwargs: Any,
) -> T:
    """Execute a function with exponential backoff on transient failures.

    Retries on httpx.TimeoutException and httpx.NetworkError.
    The caller is responsible for mapping HTTP status codes to exceptions
    before this wrapper sees them (i.e., this retries on raised exceptions,
    not on response status codes).

    Args:
        func: The callable to execute.
        max_retries: Maximum number of retry attempts (0 = no retries).
        base_delay: Base delay in seconds (doubled each retry).

    Returns:
        The return value of func.

    Raises:
        The last exception if all retries are exhausted.
    """
    last_exc: Exception | None = None
    for attempt in range(1 + max_retries):
        try:
            return func(*args, **kwargs)
        except (httpx.TimeoutException, httpx.NetworkError) as exc:
            last_exc = exc
            if attempt < max_retries:
                delay = base_delay * (2 ** attempt)
                time.sleep(delay)
            else:
                raise
    # Unreachable, but keeps type checkers happy.
    raise last_exc  # type: ignore[misc]
