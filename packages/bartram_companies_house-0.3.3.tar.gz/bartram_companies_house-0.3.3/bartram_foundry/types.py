"""Shared type definitions and response schemas.

Pydantic models for common structures across tools:
- UK addresses
- Company identifiers
- Officer names
- Date ranges
- Standard MCP response envelope

Tool-specific types live in each tool's directory.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class UKAddress:
    """Normalised UK address fields."""

    address_line_1: str = ""
    address_line_2: str = ""
    locality: str = ""
    region: str = ""
    postal_code: str = ""
    country: str = ""
    care_of: str = ""
    po_box: str = ""

    @property
    def one_line(self) -> str:
        """Format as a single comma-separated line, omitting empty fields."""
        parts = [
            self.care_of,
            self.po_box,
            self.address_line_1,
            self.address_line_2,
            self.locality,
            self.region,
            self.postal_code,
            self.country,
        ]
        return ", ".join(p for p in parts if p)
