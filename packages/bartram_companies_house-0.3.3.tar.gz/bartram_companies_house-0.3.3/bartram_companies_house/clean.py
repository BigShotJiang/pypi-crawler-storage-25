"""Companies House data cleaning logic.

CH-specific cleaning for all 12 endpoints:
- Company number zero-padding
- Officer name deduplication (handle ~614K known duplicates from name variations)
- Entity misclassification detection (corporate entities filed as natural persons)
- Address normalisation for CH-specific formats
- Nature of control interpretation
- Filing description rendering
- Charge status interpretation
- Insolvency case type interpretation
- SIC code description lookup
- Data quality annotations (_cleaning)
"""

from __future__ import annotations

import re
from typing import Any

from bartram_foundry.cleaning import (
    names_match,
    normalise_address_line,
    normalise_name,
    normalise_postcode,
)

# ---------------------------------------------------------------------------
# SIC code descriptions (common codes — not exhaustive)
# ---------------------------------------------------------------------------

_SIC_DESCRIPTIONS: dict[str, str] = {
    "01110": "Growing of cereals and other crops",
    "01130": "Growing of vegetables",
    "01500": "Mixed farming",
    "10710": "Manufacture of bread",
    "41100": "Development of building projects",
    "41201": "Construction of commercial buildings",
    "41202": "Construction of domestic buildings",
    "43210": "Electrical installation",
    "43320": "Joinery installation",
    "43999": "Other specialised construction activities",
    "45111": "Sale of new cars and light motor vehicles",
    "46900": "Non-specialised wholesale trade",
    "47110": "Retail sale in non-specialised stores with food predominating",
    "47190": "Other retail sale in non-specialised stores",
    "47910": "Retail sale via mail order houses or via Internet",
    "56101": "Licensed restaurants",
    "56302": "Public houses and bars",
    "62011": "Ready-made interactive leisure and entertainment software development",
    "62012": "Business and domestic software development",
    "62020": "Information technology consultancy activities",
    "62090": "Other information technology service activities",
    "63110": "Data processing, hosting and related activities",
    "63120": "Web portals",
    "64110": "Central banking",
    "64191": "Banks",
    "64205": "Activities of financial services holding companies",
    "64209": "Activities of other holding companies n.e.c.",
    "64301": "Activities of investment trusts",
    "64921": "Credit granting by non-deposit taking finance houses",
    "66110": "Administration of financial markets",
    "66190": "Other activities auxiliary to financial services",
    "68100": "Buying and selling of own real estate",
    "68201": "Renting and operating of Housing Association real estate",
    "68209": "Other letting and operating of own or leased real estate",
    "68310": "Real estate agencies",
    "69101": "Barristers at law",
    "69102": "Solicitors",
    "69201": "Accounting and auditing activities",
    "69203": "Tax consultancy",
    "70100": "Activities of head offices",
    "70210": "Public relations and communication activities",
    "70229": "Management consultancy activities other than financial management",
    "73110": "Advertising agencies",
    "73120": "Media representation services",
    "74100": "Specialised design activities",
    "74209": "Other photographic activities",
    "74909": "Other professional, scientific and technical activities",
    "77110": "Renting and leasing of cars and light motor vehicles",
    "78109": "Other activities of employment placement agencies",
    "78200": "Temporary employment agency activities",
    "82110": "Combined office administrative service activities",
    "82990": "Other business support service activities",
    "85310": "General secondary education",
    "85320": "Technical and vocational secondary education",
    "86210": "General medical practice activities",
    "86220": "Specialist medical practice activities",
    "86900": "Other human health activities",
    "87100": "Residential nursing care activities",
    "88100": "Social work activities without accommodation for the elderly and disabled",
    "93110": "Operation of sports facilities",
    "93199": "Other sports activities",
    "96020": "Hairdressing and other beauty treatment",
    "96090": "Other service activities n.e.c.",
}


def _get_sic_description(code: str) -> str:
    """Look up a SIC code description. Returns empty string if unknown."""
    return _SIC_DESCRIPTIONS.get(code, "")


# ---------------------------------------------------------------------------
# Nature of control interpretation
# ---------------------------------------------------------------------------

_NATURE_OF_CONTROL_DESCRIPTIONS: dict[str, str] = {
    "ownership-of-shares-25-to-50-percent": "Ownership of 25% to 50% of shares",
    "ownership-of-shares-50-to-75-percent": "Ownership of 50% to 75% of shares",
    "ownership-of-shares-75-to-100-percent": "Ownership of 75% to 100% of shares",
    "ownership-of-shares-25-to-50-percent-as-trust": (
        "Ownership of 25% to 50% of shares (held as trust)"
    ),
    "ownership-of-shares-50-to-75-percent-as-trust": (
        "Ownership of 50% to 75% of shares (held as trust)"
    ),
    "ownership-of-shares-75-to-100-percent-as-trust": (
        "Ownership of 75% to 100% of shares (held as trust)"
    ),
    "ownership-of-shares-25-to-50-percent-as-firm": (
        "Ownership of 25% to 50% of shares (held as firm)"
    ),
    "ownership-of-shares-50-to-75-percent-as-firm": (
        "Ownership of 50% to 75% of shares (held as firm)"
    ),
    "ownership-of-shares-75-to-100-percent-as-firm": (
        "Ownership of 75% to 100% of shares (held as firm)"
    ),
    "voting-rights-25-to-50-percent": "Voting rights of 25% to 50%",
    "voting-rights-50-to-75-percent": "Voting rights of 50% to 75%",
    "voting-rights-75-to-100-percent": "Voting rights of 75% to 100%",
    "voting-rights-25-to-50-percent-as-trust": "Voting rights of 25% to 50% (held as trust)",
    "voting-rights-50-to-75-percent-as-trust": "Voting rights of 50% to 75% (held as trust)",
    "voting-rights-75-to-100-percent-as-trust": "Voting rights of 75% to 100% (held as trust)",
    "voting-rights-25-to-50-percent-as-firm": "Voting rights of 25% to 50% (held as firm)",
    "voting-rights-50-to-75-percent-as-firm": "Voting rights of 50% to 75% (held as firm)",
    "voting-rights-75-to-100-percent-as-firm": "Voting rights of 75% to 100% (held as firm)",
    "right-to-appoint-and-remove-directors": "Right to appoint and remove directors",
    "right-to-appoint-and-remove-directors-as-trust": (
        "Right to appoint and remove directors (held as trust)"
    ),
    "right-to-appoint-and-remove-directors-as-firm": (
        "Right to appoint and remove directors (held as firm)"
    ),
    "significant-influence-or-control": "Significant influence or control",
    "significant-influence-or-control-as-trust": "Significant influence or control (held as trust)",
    "significant-influence-or-control-as-firm": "Significant influence or control (held as firm)",
    "right-to-share-surplus-assets-25-to-50-percent-limited-liability-partnership": (
        "Right to 25%-50% of surplus assets (LLP)"
    ),
    "right-to-share-surplus-assets-50-to-75-percent-limited-liability-partnership": (
        "Right to 50%-75% of surplus assets (LLP)"
    ),
    "right-to-share-surplus-assets-75-to-100-percent-limited-liability-partnership": (
        "Right to 75%-100% of surplus assets (LLP)"
    ),
}


# ---------------------------------------------------------------------------
# Charge status interpretation
# ---------------------------------------------------------------------------

_CHARGE_STATUS_DESCRIPTIONS: dict[str, str] = {
    "outstanding": "Outstanding",
    "fully-satisfied": "Fully Satisfied",
    "part-satisfied": "Part Satisfied",
    "satisfied": "Satisfied",
}


# ---------------------------------------------------------------------------
# Insolvency case type interpretation
# ---------------------------------------------------------------------------

_INSOLVENCY_CASE_TYPES: dict[str, str] = {
    "compulsory-liquidation": "Compulsory Liquidation",
    "creditors-voluntary-liquidation": "Creditors' Voluntary Liquidation",
    "members-voluntary-liquidation": "Members' Voluntary Liquidation",
    "administration": "Administration",
    "administrative-receiver": "Administrative Receiver",
    "voluntary-arrangement": "Voluntary Arrangement",
    "company-voluntary-arrangement": "Company Voluntary Arrangement",
    "receiver-manager": "Receiver Manager",
    "in-administration": "In Administration",
    "live-proposal": "Live Proposal",
    "receivership": "Receivership",
    "foreign-insolvency": "Foreign Insolvency",
}


# ---------------------------------------------------------------------------
# Company number zero-padding
# ---------------------------------------------------------------------------


def pad_company_number(number: str) -> tuple[str, bool]:
    """Zero-pad a company number to 8 chars. Returns (padded, was_changed)."""
    if not number:
        return number, False
    stripped = number.strip()
    if stripped.isdigit():
        padded = stripped.zfill(8)
        return padded, padded != stripped
    return stripped, False


# ---------------------------------------------------------------------------
# Officer deduplication
# ---------------------------------------------------------------------------


def _officer_key(officer: dict[str, Any]) -> str:
    """Build a grouping key for an officer from role + normalised name."""
    name = normalise_name(officer.get("name", ""))
    role = officer.get("officer_role", "unknown")
    return f"{role}::{name}"


def _merge_officer_group(officers: list[dict[str, Any]]) -> dict[str, Any]:
    """Given a group of likely-duplicate officer records, produce one merged record."""
    if len(officers) == 1:
        return officers[0]

    def sort_key(o: dict[str, Any]) -> str:
        return o.get("appointed_on", "0000-00-00")

    sorted_officers = sorted(officers, key=sort_key, reverse=True)
    primary = dict(sorted_officers[0])

    primary["_cleaning"] = {
        "deduplicated": True,
        "duplicate_count": len(officers),
        "original_names": [o.get("name", "") for o in officers],
        "note": (
            f"Merged {len(officers)} records with similar names. "
            "Showing most recently appointed."
        ),
    }

    return primary


def deduplicate_officers(
    officers: list[dict[str, Any]],
    *,
    threshold: int = 85,
) -> list[dict[str, Any]]:
    """Deduplicate officer records by fuzzy name matching."""
    if not officers:
        return []

    groups: dict[str, list[dict[str, Any]]] = {}
    for officer in officers:
        key = _officer_key(officer)
        groups.setdefault(key, []).append(officer)

    merged_keys: list[list[str]] = []
    key_list = list(groups.keys())
    consumed: set[str] = set()

    for i, key_a in enumerate(key_list):
        if key_a in consumed:
            continue
        cluster = [key_a]
        for key_b in key_list[i + 1 :]:
            if key_b in consumed:
                continue
            role_a, name_a = key_a.split("::", 1)
            role_b, name_b = key_b.split("::", 1)
            if role_a == role_b and names_match(name_a, name_b, threshold=threshold):
                cluster.append(key_b)
                consumed.add(key_b)
        consumed.add(key_a)
        merged_keys.append(cluster)

    result = []
    for cluster in merged_keys:
        all_officers = []
        for key in cluster:
            all_officers.extend(groups[key])
        result.append(_merge_officer_group(all_officers))

    return result


# ---------------------------------------------------------------------------
# Entity classification (shared across officers and PSCs)
# ---------------------------------------------------------------------------

_CORPORATE_INDICATORS = [
    " LTD", " LIMITED", " PLC", " LLP", " LP",
    " INC", " CORP", " CORPORATION",
    " TRUST", " FUND", " FOUNDATION",
    " GMBH", " AG", " SA", " BV", " NV",
]


def _looks_like_corporate_entity(record: dict[str, Any]) -> bool:
    """Detect a corporate entity based on identification data or name indicators."""
    if record.get("identification"):
        return True
    name = record.get("name", "").upper()
    return any(indicator in name for indicator in _CORPORATE_INDICATORS)


# ---------------------------------------------------------------------------
# PSC cleaning
# ---------------------------------------------------------------------------

_CORPORATE_PSC_KINDS = frozenset({
    "corporate-entity-person-with-significant-control",
    "corporate-entity-beneficial-owner",
    "legal-person-person-with-significant-control",
    "legal-person-beneficial-owner",
    "super-secure-person-with-significant-control",
    "super-secure-beneficial-owner",
})

_INDIVIDUAL_PSC_KINDS = frozenset({
    "individual-person-with-significant-control",
    "individual-beneficial-owner",
})

_LEGAL_PERSON_PSC_KINDS = frozenset({
    "legal-person-person-with-significant-control",
    "legal-person-beneficial-owner",
})


def _classify_psc_entity_type(kind: str) -> str:
    """Classify a PSC record's entity type from its kind field."""
    if kind in _INDIVIDUAL_PSC_KINDS:
        return "individual"
    if kind in _LEGAL_PERSON_PSC_KINDS:
        return "legal_person"
    if kind in _CORPORATE_PSC_KINDS:
        return "corporate"
    return "unknown"


def clean_pscs(pscs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Clean PSC records: classify entities, interpret natures of control, normalise."""
    result = []
    for psc in pscs:
        cleaned = dict(psc)
        kind = psc.get("kind", "")
        annotations: dict[str, Any] = {}

        # Entity type classification
        entity_type = _classify_psc_entity_type(kind)
        annotations["entity_type"] = entity_type

        # Misclassification detection
        if kind in _INDIVIDUAL_PSC_KINDS and _looks_like_corporate_entity(psc):
            annotations["entity_misclassification"] = True
            annotations["detected_type"] = "corporate"

        # Name normalisation
        name = psc.get("name", "")
        if name:
            normalised = normalise_name(name)
            if normalised != name:
                cleaned["name"] = normalised
                annotations["name_normalised"] = True

        # Nature of control interpretation
        natures = psc.get("natures_of_control", [])
        if natures:
            descriptions = []
            for nature in natures:
                desc = _NATURE_OF_CONTROL_DESCRIPTIONS.get(nature, nature.replace("-", " ").title())
                descriptions.append(desc)
            cleaned["natures_of_control_descriptions"] = descriptions
            annotations["nature_of_control_interpreted"] = True

        # Address normalisation
        if psc.get("address"):
            cleaned["address"] = clean_address(psc["address"])
            annotations["address_normalised"] = True

        # Ceased flag
        if psc.get("ceased_on"):
            annotations["ceased"] = True

        cleaned["_cleaning"] = annotations
        result.append(cleaned)

    return result


# ---------------------------------------------------------------------------
# Address cleaning (CH-specific)
# ---------------------------------------------------------------------------


def clean_address(address: dict[str, Any]) -> dict[str, Any]:
    """Normalise a Companies House address record."""
    if not address:
        return {}

    cleaned: dict[str, Any] = {}
    changed = False

    for key in ("care_of", "po_box", "premises", "address_line_1", "address_line_2",
                "locality", "region", "country"):
        if address.get(key):
            normalised = normalise_address_line(address[key])
            if normalised != address[key]:
                changed = True
            cleaned[key] = normalised

    if address.get("postal_code"):
        normalised_pc = normalise_postcode(address["postal_code"])
        if normalised_pc != address["postal_code"]:
            changed = True
        cleaned["postal_code"] = normalised_pc

    # Build a single formatted line
    parts = []
    for key in ("premises", "address_line_1", "address_line_2", "locality", "region", "country"):
        if cleaned.get(key):
            parts.append(cleaned[key])
    if "postal_code" in cleaned:
        parts.append(cleaned["postal_code"])
    cleaned["formatted"] = ", ".join(parts)

    cleaned["_address_changed"] = changed
    return cleaned


# ---------------------------------------------------------------------------
# Filing description rendering
# ---------------------------------------------------------------------------


def render_filing_description(filing: dict[str, Any]) -> str:
    """Render a filing description from its code and values into readable text."""
    desc = filing.get("description", "")
    values = filing.get("description_values", {})

    if not desc:
        return ""

    readable = desc.replace("-", " ").capitalize()

    if values:
        parts = [readable]
        for key, value in values.items():
            if key == "capital" and isinstance(value, list):
                cap_parts = [f"{c.get('currency', '')} {c.get('figure', '')}" for c in value]
                parts.append(f"Capital: {', '.join(cap_parts)}")
            elif isinstance(value, str):
                label = key.replace("_", " ").capitalize()
                parts.append(f"{label}: {value}")
        readable = ". ".join(parts)

    return readable


# ---------------------------------------------------------------------------
# Charge status interpretation
# ---------------------------------------------------------------------------


def interpret_charge_status(status: str) -> str:
    """Map a charge status code to a human-readable description."""
    return _CHARGE_STATUS_DESCRIPTIONS.get(status, status.replace("-", " ").title())


# ---------------------------------------------------------------------------
# Insolvency case type interpretation
# ---------------------------------------------------------------------------


def interpret_insolvency_case_type(case_type: str) -> str:
    """Map an insolvency case type code to a human-readable description."""
    return _INSOLVENCY_CASE_TYPES.get(case_type, case_type.replace("-", " ").title())


# ---------------------------------------------------------------------------
# Top-level cleaning functions (called from serve.py)
# ---------------------------------------------------------------------------


def clean_search_results(response: dict[str, Any]) -> dict[str, Any]:
    """Clean company search results: pad numbers, normalise names and addresses."""
    cleaned = dict(response)
    for item in cleaned.get("items", []):
        # Company number zero-padding
        if "company_number" in item:
            padded, was_padded = pad_company_number(item["company_number"])
            item["company_number"] = padded
            item.setdefault("_cleaning", {})["company_number_padded"] = was_padded

        # Company name normalisation (trim whitespace, normalise unicode)
        title = item.get("title", "")
        if title:
            stripped = title.strip()
            if stripped != title:
                item["title"] = stripped
                item.setdefault("_cleaning", {})["name_normalised"] = True
            else:
                item.setdefault("_cleaning", {})["name_normalised"] = False

        # Address normalisation
        if "address" in item:
            item["address"] = clean_address(item["address"])
    return cleaned


def clean_company_profile(profile: dict[str, Any]) -> dict[str, Any]:
    """Clean a company profile response."""
    cleaned = dict(profile)
    annotations: dict[str, Any] = {}

    # Company number zero-padding
    if "company_number" in cleaned:
        padded, was_padded = pad_company_number(cleaned["company_number"])
        cleaned["company_number"] = padded
        annotations["company_number_padded"] = was_padded

    # Address normalisation
    if "registered_office_address" in cleaned:
        addr = clean_address(cleaned["registered_office_address"])
        annotations["address_normalised"] = addr.pop("_address_changed", False)
        cleaned["registered_office_address"] = addr

    # SIC code descriptions
    sic_codes = cleaned.get("sic_codes", [])
    if sic_codes:
        sic_descriptions = []
        for code in sic_codes:
            desc = _get_sic_description(code)
            sic_descriptions.append({"code": code, "description": desc} if desc else {"code": code})
        cleaned["sic_descriptions"] = sic_descriptions
        annotations["sic_descriptions_added"] = True

    cleaned["_cleaning"] = annotations
    return cleaned


def clean_officer_list(response: dict[str, Any], *, threshold: int = 85) -> dict[str, Any]:
    """Clean an officer list response: deduplicate, classify entities, normalise."""
    cleaned = dict(response)
    raw_items = cleaned.get("items", [])

    # Per-officer cleaning before dedup
    for item in raw_items:
        item_annotations = item.get("_cleaning", {})

        # Name normalisation
        name = item.get("name", "")
        if name:
            normalised = normalise_name(name)
            if normalised != name:
                item_annotations["name_normalised"] = True

        # Entity classification
        if _looks_like_corporate_entity(item):
            item_annotations["entity_misclassification"] = True
            item_annotations["detected_type"] = "corporate"

        # Address normalisation
        if item.get("address"):
            addr = clean_address(item["address"])
            addr.pop("_address_changed", None)
            item["address"] = addr
            item_annotations["address_normalised"] = True

        item["_cleaning"] = item_annotations

    # Deduplicate
    deduped = deduplicate_officers(raw_items, threshold=threshold)

    active_count = sum(1 for o in deduped if not o.get("resigned_on"))
    resigned_count = sum(1 for o in deduped if o.get("resigned_on"))

    cleaned["items"] = deduped
    cleaned["active_count"] = active_count
    cleaned["resigned_count"] = resigned_count
    cleaned["_cleaning"] = {
        "original_count": len(raw_items),
        "deduplicated_count": len(deduped),
        "duplicates_removed": len(raw_items) - len(deduped),
    }
    return cleaned


def clean_psc_list(response: dict[str, Any]) -> dict[str, Any]:
    """Clean a PSC list response: classify, interpret, normalise."""
    cleaned = dict(response)
    items = clean_pscs(cleaned.get("items", []))
    cleaned["items"] = items

    active_count = sum(1 for p in items if not p.get("ceased_on"))
    ceased_count = sum(1 for p in items if p.get("ceased_on"))
    cleaned["active_count"] = active_count
    cleaned["ceased_count"] = ceased_count

    return cleaned


def clean_filing_history(response: dict[str, Any]) -> dict[str, Any]:
    """Clean a filing history response: render descriptions, normalise dates."""
    cleaned = dict(response)
    for item in cleaned.get("items", []):
        rendered = render_filing_description(item)
        item["description_rendered"] = rendered
        annotations: dict[str, Any] = {}
        annotations["description_rendered"] = bool(rendered)
        if not rendered and item.get("description"):
            annotations["description_render_failed"] = True

        # Normalise dates to ISO 8601 (they should already be, but verify)
        for date_field in ("date", "action_date"):
            val = item.get(date_field, "")
            if val and re.match(r"^\d{4}-\d{2}-\d{2}$", val):
                annotations["date_normalised"] = False
            elif val:
                annotations["date_normalised"] = True

        item["_cleaning"] = annotations
    return cleaned


def clean_charges(response: dict[str, Any]) -> dict[str, Any]:
    """Clean a charges response: interpret status, normalise persons entitled, dates."""
    cleaned = dict(response)
    items = cleaned.get("items", [])

    outstanding = 0
    satisfied = 0
    part_satisfied = 0

    for item in items:
        annotations: dict[str, Any] = {}

        # Status interpretation
        status = item.get("status", "")
        if status:
            item["status_description"] = interpret_charge_status(status)
            annotations["status_interpreted"] = True

        if status == "outstanding":
            outstanding += 1
        elif status in ("fully-satisfied", "satisfied"):
            satisfied += 1
        elif status == "part-satisfied":
            part_satisfied += 1

        # Persons entitled normalisation
        persons = item.get("persons_entitled", [])
        if persons:
            normalised_persons = []
            changed = False
            for person in persons:
                if isinstance(person, dict) and "name" in person:
                    orig = person["name"]
                    norm = orig.strip().title() if orig else orig
                    if norm != orig:
                        changed = True
                    normalised_persons.append({**person, "name": norm})
                else:
                    normalised_persons.append(person)
            item["persons_entitled"] = normalised_persons
            annotations["persons_entitled_normalised"] = changed

        # Date normalisation
        date_changed = False
        for date_field in ("created_on", "delivered_on", "satisfied_on", "updated_on"):
            val = item.get(date_field, "")
            if val and not re.match(r"^\d{4}-\d{2}-\d{2}$", val):
                date_changed = True
        annotations["date_normalised"] = date_changed

        # Classification tagging
        classification = item.get("classification", {})
        if classification:
            annotations["classification_tagged"] = True

        item["_cleaning"] = annotations

    cleaned["outstanding_count"] = outstanding
    cleaned["satisfied_count"] = satisfied
    cleaned["part_satisfied_count"] = part_satisfied
    return cleaned


def clean_insolvency(response: dict[str, Any]) -> dict[str, Any]:
    """Clean an insolvency response: interpret case types, normalise practitioners."""
    cleaned = dict(response)
    cases = cleaned.get("cases", [])

    for case in cases:
        annotations: dict[str, Any] = {}

        # Case type interpretation
        case_type = case.get("type", "")
        if case_type:
            case["type_description"] = interpret_insolvency_case_type(case_type)
            annotations["case_type_interpreted"] = True

        # Practitioner name and address normalisation
        practitioners = case.get("practitioners", [])
        name_changed = False
        addr_changed = False
        for practitioner in practitioners:
            name = practitioner.get("name", "")
            if name:
                normalised = normalise_name(name)
                if normalised != name:
                    practitioner["name"] = normalised
                    name_changed = True
            if practitioner.get("address"):
                addr = clean_address(practitioner["address"])
                if addr.pop("_address_changed", False):
                    addr_changed = True
                practitioner["address"] = addr

        annotations["practitioner_name_normalised"] = name_changed
        annotations["practitioner_address_normalised"] = addr_changed

        # Date normalisation
        date_changed = False
        for date_entry in case.get("dates", []):
            val = date_entry.get("date", "")
            if val and not re.match(r"^\d{4}-\d{2}-\d{2}$", val):
                date_changed = True
        annotations["date_normalised"] = date_changed

        case["_cleaning"] = annotations

    return cleaned


def clean_officer_search(response: dict[str, Any]) -> dict[str, Any]:
    """Clean officer search results: normalise names, extract IDs, classify entities."""
    cleaned = dict(response)
    for item in cleaned.get("items", []):
        annotations: dict[str, Any] = {}

        # Name normalisation
        title = item.get("title", "")
        if title:
            normalised = normalise_name(title)
            if normalised != title:
                annotations["name_normalised"] = True
            else:
                annotations["name_normalised"] = False

        # Address normalisation
        snippet = item.get("address_snippet", "")
        if snippet:
            normalised_addr = normalise_address_line(snippet)
            if normalised_addr != snippet:
                item["address_snippet"] = normalised_addr
                annotations["address_normalised"] = True
            else:
                annotations["address_normalised"] = False

        # Entity classification
        if _looks_like_corporate_entity({"name": title}):
            annotations["entity_type"] = "corporate"
        else:
            annotations["entity_type"] = "individual"

        # Officer ID extraction from links
        links = item.get("links", {})
        self_link = ""
        if isinstance(links, dict):
            self_link = links.get("self", "")
        if self_link:
            # /officers/{id}/appointments -> extract the id
            parts = self_link.strip("/").split("/")
            if len(parts) >= 2 and parts[0] == "officers":
                item["officer_id"] = parts[1]
                annotations["officer_id_extracted"] = True

        item["_cleaning"] = annotations
    return cleaned


def clean_officer_appointments(response: dict[str, Any]) -> dict[str, Any]:
    """Clean officer appointments: pad company numbers, normalise names and addresses."""
    cleaned = dict(response)
    items = cleaned.get("items", [])

    active_count = 0
    resigned_count = 0

    for item in items:
        annotations: dict[str, Any] = {}

        # Company number zero-padding in appointed_to
        appointed_to = item.get("appointed_to", {})
        if isinstance(appointed_to, dict) and "company_number" in appointed_to:
            padded, was_padded = pad_company_number(appointed_to["company_number"])
            appointed_to["company_number"] = padded
            annotations["company_number_padded"] = was_padded

        # Name normalisation
        name = item.get("name", "")
        if name:
            normalised = normalise_name(name)
            if normalised != name:
                annotations["name_normalised"] = True
            else:
                annotations["name_normalised"] = False

        # Address normalisation
        if item.get("address"):
            addr = clean_address(item["address"])
            addr.pop("_address_changed", None)
            item["address"] = addr
            annotations["address_normalised"] = True

        # Role normalisation
        role = item.get("officer_role", "")
        if role:
            normalised_role = role.strip().lower()
            if normalised_role != role:
                item["officer_role"] = normalised_role
                annotations["role_normalised"] = True
            else:
                annotations["role_normalised"] = False

        if item.get("resigned_on"):
            resigned_count += 1
        else:
            active_count += 1

        item["_cleaning"] = annotations

    cleaned["active_count"] = active_count
    cleaned["resigned_count"] = resigned_count
    return cleaned


def clean_disqualified_officer(response: dict[str, Any]) -> dict[str, Any]:
    """Clean a disqualified officer record: normalise names, addresses, interpret reasons."""
    cleaned = dict(response)
    annotations: dict[str, Any] = {}

    # Name normalisation
    name = cleaned.get("name", "")
    if name:
        normalised = normalise_name(name)
        if normalised != name:
            cleaned["name"] = normalised
            annotations["name_normalised"] = True
        else:
            annotations["name_normalised"] = False

    # Address normalisation on each disqualification
    for disqual in cleaned.get("disqualifications", []):
        if disqual.get("address"):
            addr = clean_address(disqual["address"])
            addr.pop("_address_changed", None)
            disqual["address"] = addr
    annotations["address_normalised"] = True

    # Reason interpretation (codes vary — do best-effort rendering)
    for disqual in cleaned.get("disqualifications", []):
        reason = disqual.get("reason", {})
        if isinstance(reason, dict):
            act = reason.get("act", "")
            section = reason.get("section", "")
            if act or section:
                description = ""
                if act:
                    description = act.replace("-", " ").title()
                if section:
                    description += f" Section {section}" if description else f"Section {section}"
                reason["description"] = description
    annotations["reason_interpreted"] = True

    # Date normalisation
    date_changed = False
    for disqual in cleaned.get("disqualifications", []):
        for date_field in ("disqualified_from", "disqualified_until", "heard_on"):
            val = disqual.get(date_field, "")
            if val and not re.match(r"^\d{4}-\d{2}-\d{2}$", val):
                date_changed = True
    annotations["date_normalised"] = date_changed

    cleaned["_cleaning"] = annotations
    return cleaned


def clean_advanced_search(response: dict[str, Any]) -> dict[str, Any]:
    """Clean advanced search results: pad numbers, add SIC descriptions, normalise names."""
    cleaned = dict(response)
    # Normalise the count field — advanced search uses 'hits' not 'total_results'
    if "hits" in cleaned and "total_results" not in cleaned:
        cleaned["total_results"] = cleaned.pop("hits")
    for item in cleaned.get("items", []):
        annotations: dict[str, Any] = {}

        # Company number zero-padding
        if "company_number" in item:
            padded, was_padded = pad_company_number(item["company_number"])
            item["company_number"] = padded
            annotations["company_number_padded"] = was_padded

        # SIC code descriptions
        sic_codes = item.get("sic_codes", [])
        if sic_codes:
            sic_descriptions = []
            for code in sic_codes:
                desc = _get_sic_description(code)
                sic_descriptions.append(
                    {"code": code, "description": desc} if desc else {"code": code}
                )
            item["sic_descriptions"] = sic_descriptions
            annotations["sic_descriptions_added"] = True

        # Name normalisation
        name = item.get("company_name", "")
        if name:
            stripped = name.strip()
            if stripped != name:
                item["company_name"] = stripped
                annotations["name_normalised"] = True
            else:
                annotations["name_normalised"] = False

        item["_cleaning"] = annotations
    return cleaned


def clean_registered_address(response: dict[str, Any]) -> dict[str, Any]:
    """Clean a registered address response: normalise all fields, format postcode."""
    addr = clean_address(response)
    annotations: dict[str, Any] = {}
    annotations["address_normalised"] = addr.pop("_address_changed", False)

    # Postcode formatting check
    original_pc = response.get("postal_code", "")
    cleaned_pc = addr.get("postal_code", "")
    annotations["postcode_formatted"] = original_pc != cleaned_pc

    # Country normalisation check
    original_country = response.get("country", "")
    cleaned_country = addr.get("country", "")
    annotations["country_normalised"] = original_country != cleaned_country

    addr["_cleaning"] = annotations
    return addr
