"""MCP tool definitions for Companies House -- what agents call.

12 tools exposed:
- uk_companies_house_search: Search for companies by name
- uk_companies_house_profile: Get company details by number
- uk_companies_house_officers: Get officer records with deduplication
- uk_companies_house_psc: Get beneficial ownership data
- uk_companies_house_filings: Get filing history
- uk_companies_house_charges: Get charges (mortgages/security interests)
- uk_companies_house_insolvency: Get insolvency information
- uk_companies_house_officer_search: Search for officers by name
- uk_companies_house_officer_appointments: Get officer appointments across companies
- uk_companies_house_disqualified_officer: Check officer disqualification status
- uk_companies_house_advanced_search: Search companies with filters
- uk_companies_house_registered_address: Get registered office address
"""

from __future__ import annotations

import json
import threading
import time
from datetime import datetime, timezone
from typing import Any

from mcp.server.fastmcp import FastMCP

from bartram_companies_house.access import (
    CompaniesHouseClient,
    CompaniesHouseConfig,
    CompaniesHouseError,
    NotFoundError,
    normalise_company_number,
)
from bartram_companies_house.clean import (
    clean_advanced_search,
    clean_charges,
    clean_company_profile,
    clean_disqualified_officer,
    clean_filing_history,
    clean_insolvency,
    clean_officer_appointments,
    clean_officer_list,
    clean_officer_search,
    clean_psc_list,
    clean_registered_address,
    clean_search_results,
)
from bartram_foundry.monitoring import MetricsStore

# ---------------------------------------------------------------------------
# Server setup
# ---------------------------------------------------------------------------

server = FastMCP(
    "bartram-companies-house",
    instructions="UK Companies House data with cleaning and deduplication. "
    "12 tools covering company search, profiles, officers, PSCs, filings, "
    "charges, insolvency, officer search, appointments, disqualifications, "
    "advanced search, and registered addresses. "
    "Source: Companies House API. Licence: OGL v3.0.",
)

_client: CompaniesHouseClient | None = None
_metrics: MetricsStore | None = None
_init_lock = threading.Lock()


def _get_client() -> CompaniesHouseClient:
    """Get or create the API client (lazy initialisation, thread-safe)."""
    global _client
    if _client is None:
        with _init_lock:
            if _client is None:
                _client = CompaniesHouseClient(CompaniesHouseConfig.from_env())
    return _client


def _get_metrics() -> MetricsStore:
    """Get or create the metrics store (lazy initialisation, thread-safe)."""
    global _metrics
    if _metrics is None:
        with _init_lock:
            if _metrics is None:
                _metrics = MetricsStore()
    return _metrics


# ---------------------------------------------------------------------------
# Response formatting
# ---------------------------------------------------------------------------

_ATTRIBUTION = (
    "Contains public sector information licensed under the "
    "Open Government Licence v3.0. Source: Companies House."
)


def _format_response(data: Any, *, endpoint: str, cached: bool = False) -> str:
    """Format a cleaned API response as a JSON string with metadata."""
    envelope = {
        "data": data,
        "metadata": {
            "source": "Companies House Public Data API",
            "licence": "Open Government Licence v3",
            "retrieved_at": datetime.now(tz=timezone.utc).isoformat(),
            "endpoint": endpoint,
            "cached": cached,
            "attribution": _ATTRIBUTION,
        },
    }
    return json.dumps(envelope, indent=2, default=str)


def _format_error(error: CompaniesHouseError) -> str:
    """Format an API error as a JSON string."""
    return json.dumps({
        "error": str(error),
        "status_code": error.status_code,
        "attribution": _ATTRIBUTION,
    })


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record(tool_name: str, start: float, *, success: bool, error: Exception | None = None) -> None:
    """Record a tool call metric."""
    duration_ms = (time.monotonic() - start) * 1000
    _get_metrics().record_call(
        tool_name,
        duration_ms,
        success=success,
        error_type=type(error).__name__ if error else None,
        error_message=str(error)[:500] if error else None,
    )


# ---------------------------------------------------------------------------
# Filing categories (for validation)
# ---------------------------------------------------------------------------

_VALID_FILING_CATEGORIES = frozenset({
    "accounts", "address", "annual-return", "capital", "change-of-name",
    "confirmation-statement", "incorporation", "liquidation",
    "miscellaneous", "mortgage", "officers", "resolution",
    "restoration", "return",
})


# ---------------------------------------------------------------------------
# Tools — existing 5 (renamed to uk_companies_house_*)
# ---------------------------------------------------------------------------


@server.tool()
async def uk_companies_house_search(query: str, items_per_page: int = 20) -> str:
    """Search for UK companies by name or number.

    Returns company name, number, status, type, and incorporation date
    for each match. Company numbers are zero-padded and addresses normalised.
    Data source: Companies House (OGL v3.0).
    """
    if not query or not query.strip():
        return json.dumps({
            "error": "Search query is required. Provide a company name or number.",
            "attribution": _ATTRIBUTION,
        })
    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.search_companies(query.strip(), items_per_page=items_per_page)
        cleaned = clean_search_results(raw)
        result = _format_response(cleaned, endpoint="/search/companies")
        _record("uk_companies_house_search", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_companies_house_search", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_companies_house_profile(company_number: str) -> str:
    """Get the full profile of a UK company by its company number (e.g. '00445790').

    Returns registered address, status, SIC codes with descriptions, accounts info,
    and key dates. Addresses are normalised.
    Data source: Companies House (OGL v3.0).
    """
    company_number = normalise_company_number(company_number)
    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.get_company(company_number)
        cleaned = clean_company_profile(raw)
        result = _format_response(cleaned, endpoint=f"/company/{company_number}")
        _record("uk_companies_house_profile", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_companies_house_profile", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_companies_house_officers(company_number: str) -> str:
    """Get all officers (directors, secretaries) of a UK company.

    Fetches all pages. Includes name deduplication — flags likely duplicate
    records caused by name formatting variations. Detects corporate entities
    misclassified as individuals. Includes active/resigned counts.
    Data source: Companies House (OGL v3.0).
    """
    company_number = normalise_company_number(company_number)
    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.get_officers(company_number)
        cleaned = clean_officer_list(raw)
        result = _format_response(cleaned, endpoint=f"/company/{company_number}/officers")
        _record("uk_companies_house_officers", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_companies_house_officers", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_companies_house_psc(company_number: str) -> str:
    """Get persons with significant control (beneficial owners) of a UK company.

    Fetches all pages. Classifies each PSC as individual, corporate, or legal person.
    Interprets natures of control into human-readable descriptions. Flags corporate
    entities incorrectly filed as natural persons.
    Data source: Companies House (OGL v3.0).
    """
    company_number = normalise_company_number(company_number)
    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.get_pscs(company_number)
        cleaned = clean_psc_list(raw)
        result = _format_response(
            cleaned, endpoint=f"/company/{company_number}/persons-with-significant-control"
        )
        _record("uk_companies_house_psc", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_companies_house_psc", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_companies_house_filings(
    company_number: str,
    category: str | None = None,
    items_per_page: int | None = None,
) -> str:
    """Get filing history for a UK company with human-readable descriptions.

    If no items_per_page is specified, fetches all filings (paginated).
    Optionally filter by category (e.g. 'accounts', 'confirmation-statement').
    Data source: Companies House (OGL v3.0).
    """
    company_number = normalise_company_number(company_number)

    # Validate category if provided
    if category:
        category = category.strip()
        if category not in _VALID_FILING_CATEGORIES:
            return json.dumps({
                "error": f"Unknown filing category: '{category}'. "
                f"Valid categories: {', '.join(sorted(_VALID_FILING_CATEGORIES))}",
                "attribution": _ATTRIBUTION,
            })

    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.get_filing_history(
            company_number, category=category, items_per_page=items_per_page
        )
        cleaned = clean_filing_history(raw)
        result = _format_response(
            cleaned, endpoint=f"/company/{company_number}/filing-history"
        )
        _record("uk_companies_house_filings", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_companies_house_filings", start, success=False, error=exc)
        return _format_error(exc)


# ---------------------------------------------------------------------------
# Tools — 7 new
# ---------------------------------------------------------------------------


@server.tool()
async def uk_companies_house_charges(company_number: str) -> str:
    """Get charges (mortgages and security interests) registered against a UK company.

    Fetches all pages. Interprets charge status codes. Normalises lender names.
    Includes outstanding/satisfied/part-satisfied counts.
    Data source: Companies House (OGL v3.0).
    """
    company_number = normalise_company_number(company_number)
    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.get_charges(company_number)
        cleaned = clean_charges(raw)
        result = _format_response(
            cleaned, endpoint=f"/company/{company_number}/charges"
        )
        _record("uk_companies_house_charges", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_companies_house_charges", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_companies_house_insolvency(company_number: str) -> str:
    """Get insolvency information for a UK company, including cases and practitioners.

    Interprets case type codes into human-readable descriptions. Normalises
    practitioner names and addresses.
    Data source: Companies House (OGL v3.0).
    """
    company_number = normalise_company_number(company_number)
    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.get_insolvency(company_number)
        cleaned = clean_insolvency(raw)
        result = _format_response(
            cleaned, endpoint=f"/company/{company_number}/insolvency"
        )
        _record("uk_companies_house_insolvency", start, success=True)
        return result
    except NotFoundError:
        # Known API inconsistency: some companies with has_insolvency_history: true
        # return 404. This is a meaningful empty result, not an error.
        empty = {
            "cases": [],
            "status": [],
            "_cleaning": {"api_404_despite_profile_flag": True},
        }
        result = _format_response(
            empty, endpoint=f"/company/{company_number}/insolvency"
        )
        _record("uk_companies_house_insolvency", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_companies_house_insolvency", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_companies_house_officer_search(
    query: str,
    items_per_page: int = 20,
) -> str:
    """Search for officers (directors, secretaries) across all UK companies by name.

    Returns officer name, date of birth, address, appointment count, and officer ID
    for use with the appointments endpoint. Classifies entities as individual or corporate.
    Data source: Companies House (OGL v3.0).
    """
    if not query or not query.strip():
        return json.dumps({
            "error": "Search query is required. Provide an officer name.",
            "attribution": _ATTRIBUTION,
        })
    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.search_officers(query.strip(), items_per_page=items_per_page)
        cleaned = clean_officer_search(raw)
        result = _format_response(cleaned, endpoint="/search/officers")
        _record("uk_companies_house_officer_search", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_companies_house_officer_search", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_companies_house_officer_appointments(officer_id: str) -> str:
    """List all company appointments for a specific officer across all UK companies.

    Fetches all pages. Includes active/resigned counts. Company numbers are
    zero-padded. Use the officer_id from officer search results or officer list links.
    Data source: Companies House (OGL v3.0).
    """
    if not officer_id or not officer_id.strip():
        return json.dumps({
            "error": "officer_id is required.",
            "attribution": _ATTRIBUTION,
        })
    officer_id = officer_id.strip()
    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.get_officer_appointments(officer_id)
        cleaned = clean_officer_appointments(raw)
        result = _format_response(
            cleaned, endpoint=f"/officers/{officer_id}/appointments"
        )
        _record("uk_companies_house_officer_appointments", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_companies_house_officer_appointments", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_companies_house_disqualified_officer(
    officer_id: str,
    officer_type: str = "natural",
) -> str:
    """Check whether an officer is disqualified and get disqualification details.

    Returns disqualification records including reason, dates, and related companies.
    A 404 means the officer is NOT disqualified — this is returned as a clean
    'not disqualified' result, not an error.
    Data source: Companies House (OGL v3.0).
    """
    if not officer_id or not officer_id.strip():
        return json.dumps({
            "error": "officer_id is required.",
            "attribution": _ATTRIBUTION,
        })
    officer_id = officer_id.strip()
    officer_type = officer_type.strip().lower()
    if officer_type not in ("natural", "corporate"):
        return json.dumps({
            "error": "officer_type must be 'natural' or 'corporate'.",
            "attribution": _ATTRIBUTION,
        })

    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.get_disqualified_officer(officer_id, officer_type=officer_type)
        cleaned = clean_disqualified_officer(raw)
        cleaned["disqualified"] = True
        result = _format_response(
            cleaned,
            endpoint=f"/disqualified-officers/{officer_type}/{officer_id}",
        )
        _record("uk_companies_house_disqualified_officer", start, success=True)
        return result
    except NotFoundError:
        # Not disqualified — this is a meaningful clean result, not an error.
        not_disqualified = {
            "disqualified": False,
            "officer_id": officer_id,
        }
        result = _format_response(
            not_disqualified,
            endpoint=f"/disqualified-officers/{officer_type}/{officer_id}",
        )
        _record("uk_companies_house_disqualified_officer", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_companies_house_disqualified_officer", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_companies_house_advanced_search(
    query: str | None = None,
    company_status: str | None = None,
    company_type: str | None = None,
    sic_codes: str | None = None,
    incorporated_from: str | None = None,
    incorporated_to: str | None = None,
    location: str | None = None,
    size: int = 20,
    start_index: int = 0,
) -> str:
    """Search for UK companies with filters (status, SIC code, incorporation date, location).

    At least one filter must be provided. Single page per request — control
    pagination via start_index. Company numbers are zero-padded and SIC codes
    include human-readable descriptions.
    Data source: Companies House (OGL v3.0).
    """
    # Validate at least one filter
    has_filter = any([
        query, company_status, company_type, sic_codes,
        incorporated_from, incorporated_to, location,
    ])
    if not has_filter:
        return json.dumps({
            "error": "At least one search filter is required (query, company_status, "
            "company_type, sic_codes, incorporated_from, incorporated_to, or location).",
            "attribution": _ATTRIBUTION,
        })

    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.advanced_search(
            query=query.strip() if query else None,
            company_status=company_status.strip().lower() if company_status else None,
            company_type=company_type.strip().lower() if company_type else None,
            sic_codes=sic_codes.strip() if sic_codes else None,
            incorporated_from=incorporated_from.strip() if incorporated_from else None,
            incorporated_to=incorporated_to.strip() if incorporated_to else None,
            location=location.strip() if location else None,
            size=size,
            start_index=start_index,
        )
        cleaned = clean_advanced_search(raw)
        result = _format_response(cleaned, endpoint="/advanced-search/companies")
        _record("uk_companies_house_advanced_search", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_companies_house_advanced_search", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_companies_house_registered_address(company_number: str) -> str:
    """Get the registered office address for a UK company.

    Returns normalised address fields with correct postcode spacing.
    Includes care-of and PO Box fields where applicable.
    Data source: Companies House (OGL v3.0).
    """
    company_number = normalise_company_number(company_number)
    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.get_registered_address(company_number)
        cleaned = clean_registered_address(raw)
        result = _format_response(
            cleaned,
            endpoint=f"/company/{company_number}/registered-office-address",
        )
        _record("uk_companies_house_registered_address", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_companies_house_registered_address", start, success=False, error=exc)
        return _format_error(exc)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Run the Companies House MCP server."""
    server.run()


if __name__ == "__main__":
    main()
