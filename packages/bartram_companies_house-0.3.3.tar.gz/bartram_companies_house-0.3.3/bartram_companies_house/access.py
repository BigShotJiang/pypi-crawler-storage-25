"""Companies House API client.

Endpoints: 12 total (search, profile, officers, PSC, filings, charges,
insolvency, officer search, officer appointments, disqualified officer,
advanced search, registered address).
Auth: API key via Basic Auth (key as username, no password).
Rate limit: 600 requests per 5 minutes.
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx
import yaml

from bartram_foundry.cache import ResponseCache
from bartram_foundry.http import retry_request

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_BASE_URL = "https://api.company-information.service.gov.uk"
DEFAULT_RATE_LIMIT = 600
DEFAULT_RATE_WINDOW = 300  # seconds


_DEFAULT_CACHE_TTLS: dict[str, int] = {
    "search": 300,
    "profile": 3600,
    "officers": 1800,
    "psc": 1800,
    "filings": 1800,
    "charges": 1800,
    "insolvency": 1800,
    "officer_search": 300,
    "officer_appointments": 1800,
    "disqualified_officer": 3600,
    "advanced_search": 300,
    "registered_address": 3600,
}


def _load_cache_ttls() -> dict[str, int]:
    """Load cache TTLs from config.yaml if it exists."""
    config_path = Path(__file__).parent / "config.yaml"
    if config_path.exists():
        with open(config_path) as f:
            config = yaml.safe_load(f)
        return config.get("cache", {}).get("ttl_seconds", _DEFAULT_CACHE_TTLS)
    return dict(_DEFAULT_CACHE_TTLS)


@dataclass
class CompaniesHouseConfig:
    """Configuration for the Companies House API client."""

    api_key: str = ""
    base_url: str = DEFAULT_BASE_URL
    rate_limit: int = DEFAULT_RATE_LIMIT
    rate_window: int = DEFAULT_RATE_WINDOW
    timeout: float = 30.0
    cache_enabled: bool = True

    @classmethod
    def from_env(cls) -> CompaniesHouseConfig:
        """Create config from environment variables.

        The API key is a server-side configuration — users of the MCP tool
        do not need to provide their own key. The key is set as an environment
        variable in the deployment configuration.
        """
        api_key = os.environ.get("COMPANIES_HOUSE_API_KEY", "")
        if not api_key:
            msg = (
                "COMPANIES_HOUSE_API_KEY environment variable is not set. "
                "This is a server-side configuration — set it in the deployment environment."
            )
            raise ValueError(msg)
        return cls(api_key=api_key)


# ---------------------------------------------------------------------------
# Rate limiter (simple sliding window)
# ---------------------------------------------------------------------------


@dataclass
class RateLimiter:
    """Simple sliding-window rate limiter.

    Tracks request timestamps and sleeps if the limit would be exceeded.
    """

    max_requests: int = DEFAULT_RATE_LIMIT
    window_seconds: int = DEFAULT_RATE_WINDOW
    _timestamps: list[float] = field(default_factory=list)

    def wait_if_needed(self) -> None:
        """Block until a request slot is available."""
        now = time.monotonic()
        cutoff = now - self.window_seconds
        self._timestamps = [t for t in self._timestamps if t > cutoff]

        if len(self._timestamps) >= self.max_requests:
            sleep_time = self._timestamps[0] - cutoff
            if sleep_time > 0:
                time.sleep(sleep_time)

        self._timestamps.append(time.monotonic())


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class CompaniesHouseError(Exception):
    """Base exception for Companies House API errors."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class NotFoundError(CompaniesHouseError):
    """Resource not found (404)."""


class RateLimitError(CompaniesHouseError):
    """Rate limit exceeded (429)."""


class AuthenticationError(CompaniesHouseError):
    """Authentication failed (401/403)."""


# ---------------------------------------------------------------------------
# Input normalisation helpers
# ---------------------------------------------------------------------------


def normalise_company_number(number: str) -> str:
    """Normalise a company number to the format Companies House expects.

    Numeric-only numbers are zero-padded to 8 digits (e.g. '445790' -> '00445790').
    Prefixed numbers (SC, NI, OC, etc.) are uppercased and left as-is.
    """
    stripped = number.strip().upper()
    if stripped.isdigit():
        return stripped.zfill(8)
    return stripped


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class CompaniesHouseClient:
    """Client for the Companies House REST API.

    Usage::

        client = CompaniesHouseClient.from_env()
        results = client.search_companies("Tesco")
        profile = client.get_company("00445790")
        officers = client.get_officers("00445790")
        pscs = client.get_pscs("00445790")
        filings = client.get_filing_history("00445790")
        charges = client.get_charges("00445790")
        insolvency = client.get_insolvency("00445790")
        officer_results = client.search_officers("John Smith")
        appointments = client.get_officer_appointments("abc123")
        disqual = client.get_disqualified_officer("abc123")
        advanced = client.advanced_search(company_status="active", sic_codes="47110")
        address = client.get_registered_address("00445790")
    """

    def __init__(self, config: CompaniesHouseConfig) -> None:
        self.config = config
        self._rate_limiter = RateLimiter(
            max_requests=config.rate_limit,
            window_seconds=config.rate_window,
        )
        self._client = httpx.Client(
            base_url=config.base_url,
            auth=(config.api_key, ""),
            timeout=config.timeout,
            headers={"Accept": "application/json"},
        )
        self._cache: ResponseCache | None = None
        self._cache_ttls: dict[str, int] = {}
        if config.cache_enabled:
            self._cache = ResponseCache()
            self._cache_ttls = _load_cache_ttls()

    @classmethod
    def from_env(cls) -> CompaniesHouseClient:
        """Create a client from environment variables."""
        return cls(CompaniesHouseConfig.from_env())

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> CompaniesHouseClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    # -- internal request helper -------------------------------------------

    def _get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        """Make a GET request with rate limiting, retry, and error handling.

        Retries up to 2 times on timeouts and network errors with exponential backoff.
        """
        self._rate_limiter.wait_if_needed()

        def _do_request() -> httpx.Response:
            return self._client.get(path, params=params)

        try:
            response = retry_request(_do_request, max_retries=2, base_delay=1.0)
        except httpx.TimeoutException as exc:
            msg = f"Request to {path} timed out (after retries)"
            raise CompaniesHouseError(msg) from exc
        except httpx.HTTPError as exc:
            msg = f"HTTP error requesting {path}: {exc}"
            raise CompaniesHouseError(msg) from exc

        if response.status_code == 200:
            return response.json()

        status = response.status_code
        body = response.text

        if status == 404:
            raise NotFoundError(f"Not found: {path}", status_code=status)
        if status == 429:
            raise RateLimitError(
                f"Rate limit exceeded (retry after {response.headers.get('Retry-After', '?')}s)",
                status_code=status,
            )
        if status in (401, 403):
            raise AuthenticationError(
                f"Authentication failed ({status}): {body}",
                status_code=status,
            )

        # Retry server errors once more before giving up.
        if status >= 500:
            raise CompaniesHouseError(
                f"Server error {status}: {body}",
                status_code=status,
            )

        raise CompaniesHouseError(
            f"API error {status}: {body}",
            status_code=status,
        )

    def _cached_get(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        *,
        cache_key: str = "",
        force_refresh: bool = False,
    ) -> tuple[dict[str, Any], bool]:
        """GET with cache. Returns (response, from_cache).

        If force_refresh is True, bypasses the cache and fetches fresh data.
        """
        ttl = self._cache_ttls.get(cache_key, 0)
        if self._cache and ttl > 0 and not force_refresh:
            cached = self._cache.get("companies_house", path, params)
            if cached is not None:
                return cached, True

        result = self._get(path, params)

        if self._cache and ttl > 0:
            self._cache.put(
                "companies_house", path, result, ttl_seconds=ttl, params=params
            )

        return result, False

    def _paginate_all(
        self,
        path: str,
        *,
        items_per_page: int = 100,
        cache_key: str = "",
        extra_params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Fetch all pages of a paginated endpoint and return the merged result.

        Caches the complete result under a synthetic cache key.
        """
        cache_path = f"_paginated:{path}"
        cache_params = extra_params or {}
        if self._cache:
            ttl = self._cache_ttls.get(cache_key, 0)
            if ttl > 0:
                cached = self._cache.get("companies_house", cache_path, cache_params)
                if cached is not None:
                    return cached

        params: dict[str, Any] = {"items_per_page": items_per_page, "start_index": 0}
        if extra_params:
            params.update(extra_params)

        first_page = self._get(path, params)
        total = first_page.get("total_results", 0)
        all_items = list(first_page.get("items", []))

        fetched = len(all_items)
        while fetched < total:
            params["start_index"] = fetched
            page = self._get(path, params)
            page_items = page.get("items", [])
            if not page_items:
                break
            all_items.extend(page_items)
            fetched += len(page_items)

        first_page["items"] = all_items

        if self._cache:
            ttl = self._cache_ttls.get(cache_key, 0)
            if ttl > 0:
                self._cache.put(
                    "companies_house", cache_path, first_page,
                    ttl_seconds=ttl, params=cache_params,
                )

        return first_page

    # -- public API methods ------------------------------------------------

    def search_companies(
        self,
        query: str,
        *,
        items_per_page: int = 20,
    ) -> dict[str, Any]:
        """Search for companies by name or number.

        Single page — search is for discovery, not exhaustive listing.
        """
        params = {"q": query, "items_per_page": items_per_page}
        result, _ = self._cached_get(
            "/search/companies", params, cache_key="search"
        )
        return result

    def get_company(self, company_number: str) -> dict[str, Any]:
        """Get the full profile of a company by its number."""
        result, _ = self._cached_get(
            f"/company/{company_number}", cache_key="profile"
        )
        return result

    def get_officers(self, company_number: str) -> dict[str, Any]:
        """Get all officers for a company. Paginates to fetch complete list."""
        return self._paginate_all(
            f"/company/{company_number}/officers",
            cache_key="officers",
            extra_params={"company_number": company_number},
        )

    def get_pscs(self, company_number: str) -> dict[str, Any]:
        """Get all persons with significant control. Paginates to fetch complete list."""
        return self._paginate_all(
            f"/company/{company_number}/persons-with-significant-control",
            cache_key="psc",
            extra_params={"company_number": company_number},
        )

    def get_filing_history(
        self,
        company_number: str,
        *,
        category: str | None = None,
        items_per_page: int | None = None,
    ) -> dict[str, Any]:
        """Get filing history for a company.

        If items_per_page is provided, returns a single page.
        Otherwise paginates to fetch all filings.
        """
        extra: dict[str, Any] = {"company_number": company_number}
        if category:
            extra["category"] = category

        if items_per_page is not None:
            params: dict[str, Any] = {
                "items_per_page": items_per_page,
                "start_index": 0,
            }
            if category:
                params["category"] = category
            result, _ = self._cached_get(
                f"/company/{company_number}/filing-history",
                params,
                cache_key="filings",
            )
            return result

        return self._paginate_all(
            f"/company/{company_number}/filing-history",
            cache_key="filings",
            extra_params=extra,
        )

    def get_charges(self, company_number: str) -> dict[str, Any]:
        """Get all charges (mortgages/security interests) for a company.

        Paginates to fetch complete list.
        """
        return self._paginate_all(
            f"/company/{company_number}/charges",
            cache_key="charges",
            extra_params={"company_number": company_number},
        )

    def get_insolvency(self, company_number: str) -> dict[str, Any]:
        """Get insolvency information for a company."""
        result, _ = self._cached_get(
            f"/company/{company_number}/insolvency",
            cache_key="insolvency",
        )
        return result

    def search_officers(
        self,
        query: str,
        *,
        items_per_page: int = 20,
    ) -> dict[str, Any]:
        """Search for officers by name across all companies.

        Single page — search is for discovery.
        """
        params = {"q": query, "items_per_page": items_per_page}
        result, _ = self._cached_get(
            "/search/officers", params, cache_key="officer_search"
        )
        return result

    def get_officer_appointments(self, officer_id: str) -> dict[str, Any]:
        """Get all appointments for an officer. Paginates to fetch complete list."""
        return self._paginate_all(
            f"/officers/{officer_id}/appointments",
            cache_key="officer_appointments",
            extra_params={"officer_id": officer_id},
        )

    def get_disqualified_officer(
        self,
        officer_id: str,
        *,
        officer_type: str = "natural",
    ) -> dict[str, Any]:
        """Get disqualification details for an officer.

        Returns the disqualification record. Raises NotFoundError if the
        officer is not disqualified (which is a meaningful result, not an error —
        the serve layer handles this).
        """
        result, _ = self._cached_get(
            f"/disqualified-officers/{officer_type}/{officer_id}",
            cache_key="disqualified_officer",
        )
        return result

    def advanced_search(
        self,
        *,
        query: str | None = None,
        company_status: str | None = None,
        company_type: str | None = None,
        sic_codes: str | None = None,
        incorporated_from: str | None = None,
        incorporated_to: str | None = None,
        location: str | None = None,
        size: int = 20,
        start_index: int = 0,
    ) -> dict[str, Any]:
        """Advanced company search with filters.

        Single page per request — the agent controls pagination via start_index.
        """
        params: dict[str, Any] = {"size": size, "start_index": start_index}
        if query:
            params["q"] = query
        if company_status:
            params["company_status"] = company_status
        if company_type:
            params["company_type"] = company_type
        if sic_codes:
            params["sic_codes"] = sic_codes
        if incorporated_from:
            params["incorporated_from"] = incorporated_from
        if incorporated_to:
            params["incorporated_to"] = incorporated_to
        if location:
            params["location"] = location

        result, _ = self._cached_get(
            "/advanced-search/companies", params, cache_key="advanced_search"
        )
        return result

    def get_registered_address(self, company_number: str) -> dict[str, Any]:
        """Get the registered office address for a company."""
        result, _ = self._cached_get(
            f"/company/{company_number}/registered-office-address",
            cache_key="registered_address",
        )
        return result
