"""Tests for Companies House data cleaning logic.

Covers all 12 endpoint cleaning functions plus shared utilities.
"""

from __future__ import annotations

from bartram_companies_house.clean import (
    clean_address,
    clean_advanced_search,
    clean_charges,
    clean_company_profile,
    clean_disqualified_officer,
    clean_filing_history,
    clean_insolvency,
    clean_officer_appointments,
    clean_officer_list,
    clean_officer_search,
    clean_psc_list,
    clean_pscs,
    clean_registered_address,
    clean_search_results,
    deduplicate_officers,
    interpret_charge_status,
    interpret_insolvency_case_type,
    pad_company_number,
)

# ---------------------------------------------------------------------------
# Company number padding
# ---------------------------------------------------------------------------


class TestPadCompanyNumber:
    def test_pads_short_number(self) -> None:
        padded, changed = pad_company_number("445790")
        assert padded == "00445790"
        assert changed is True

    def test_already_padded(self) -> None:
        padded, changed = pad_company_number("00445790")
        assert padded == "00445790"
        assert changed is False

    def test_empty(self) -> None:
        padded, changed = pad_company_number("")
        assert padded == ""
        assert changed is False

    def test_prefixed_number(self) -> None:
        padded, changed = pad_company_number("SC311560")
        assert padded == "SC311560"
        assert changed is False


# ---------------------------------------------------------------------------
# Officer deduplication
# ---------------------------------------------------------------------------


class TestDeduplicateOfficers:
    def test_no_duplicates(self) -> None:
        officers = [
            {"name": "MURPHY, Ken", "officer_role": "director", "appointed_on": "2020-10-01"},
            {"name": "SMITH, Jane", "officer_role": "director", "appointed_on": "2021-05-01"},
        ]
        result = deduplicate_officers(officers)
        assert len(result) == 2

    def test_exact_duplicate_merged(self) -> None:
        officers = [
            {"name": "MURPHY, Ken", "officer_role": "director", "appointed_on": "2020-10-01"},
            {"name": "MURPHY, Ken", "officer_role": "director", "appointed_on": "2018-06-15"},
        ]
        result = deduplicate_officers(officers)
        assert len(result) == 1
        assert result[0]["_cleaning"]["deduplicated"] is True
        assert result[0]["_cleaning"]["duplicate_count"] == 2

    def test_name_variation_merged(self) -> None:
        officers = [
            {"name": "MURPHY, Ken", "officer_role": "director", "appointed_on": "2020-10-01"},
            {"name": "Mr Ken Murphy", "officer_role": "director", "appointed_on": "2018-06-15"},
        ]
        result = deduplicate_officers(officers)
        assert len(result) == 1
        assert result[0]["appointed_on"] == "2020-10-01"

    def test_different_roles_not_merged(self) -> None:
        officers = [
            {"name": "MURPHY, Ken", "officer_role": "director", "appointed_on": "2020-10-01"},
            {"name": "MURPHY, Ken", "officer_role": "secretary", "appointed_on": "2018-06-15"},
        ]
        result = deduplicate_officers(officers)
        assert len(result) == 2

    def test_empty_list(self) -> None:
        assert deduplicate_officers([]) == []

    def test_keeps_most_recent_appointment(self) -> None:
        officers = [
            {"name": "SMITH, John", "officer_role": "director", "appointed_on": "2015-01-01"},
            {"name": "Smith, John", "officer_role": "director", "appointed_on": "2022-03-15"},
            {"name": "SMITH, J", "officer_role": "director", "appointed_on": "2010-06-01"},
        ]
        result = deduplicate_officers(officers, threshold=70)
        assert len(result) == 1
        assert result[0]["appointed_on"] == "2022-03-15"


# ---------------------------------------------------------------------------
# PSC cleaning
# ---------------------------------------------------------------------------


class TestCleanPscs:
    def test_corporate_entity_typed(self) -> None:
        pscs = [
            {
                "name": "Tesco Holdings Limited",
                "kind": "corporate-entity-person-with-significant-control",
                "natures_of_control": ["ownership-of-shares-75-to-100-percent"],
            }
        ]
        result = clean_pscs(pscs)
        assert result[0]["_cleaning"]["entity_type"] == "corporate"

    def test_individual_typed(self) -> None:
        pscs = [
            {
                "name": "John Smith",
                "kind": "individual-person-with-significant-control",
                "natures_of_control": ["ownership-of-shares-25-to-50-percent"],
            }
        ]
        result = clean_pscs(pscs)
        assert result[0]["_cleaning"]["entity_type"] == "individual"

    def test_misclassified_corporate_as_individual(self) -> None:
        pscs = [
            {
                "name": "ACME HOLDINGS LIMITED",
                "kind": "individual-person-with-significant-control",
                "natures_of_control": ["ownership-of-shares-75-to-100-percent"],
            }
        ]
        result = clean_pscs(pscs)
        assert result[0]["_cleaning"]["entity_misclassification"] is True
        assert result[0]["_cleaning"]["detected_type"] == "corporate"

    def test_misclassified_with_identification_field(self) -> None:
        pscs = [
            {
                "name": "Some Entity",
                "kind": "individual-person-with-significant-control",
                "identification": {
                    "legal_authority": "Companies Act 2006",
                    "legal_form": "Limited Company",
                },
            }
        ]
        result = clean_pscs(pscs)
        assert result[0]["_cleaning"]["entity_misclassification"] is True

    def test_nature_of_control_interpreted(self) -> None:
        pscs = [
            {
                "name": "Test Corp",
                "kind": "corporate-entity-person-with-significant-control",
                "natures_of_control": ["ownership-of-shares-75-to-100-percent"],
            }
        ]
        result = clean_pscs(pscs)
        assert "natures_of_control_descriptions" in result[0]
        assert "75%" in result[0]["natures_of_control_descriptions"][0]
        assert result[0]["_cleaning"]["nature_of_control_interpreted"] is True

    def test_ceased_psc_flagged(self) -> None:
        pscs = [
            {
                "name": "John Smith",
                "kind": "individual-person-with-significant-control",
                "ceased_on": "2023-06-01",
            }
        ]
        result = clean_pscs(pscs)
        assert result[0]["_cleaning"]["ceased"] is True

    def test_unknown_kind_flagged(self) -> None:
        pscs = [{"name": "Mystery", "kind": "some-new-kind"}]
        result = clean_pscs(pscs)
        assert result[0]["_cleaning"]["entity_type"] == "unknown"


# ---------------------------------------------------------------------------
# Address cleaning
# ---------------------------------------------------------------------------


class TestCleanAddress:
    def test_normalises_postcode(self) -> None:
        address = {"postal_code": "al71ga", "address_line_1": "Kestrel Way"}
        result = clean_address(address)
        assert result["postal_code"] == "AL7 1GA"

    def test_title_cases_fields(self) -> None:
        address = {"locality": "WELWYN GARDEN CITY", "country": "UNITED KINGDOM"}
        result = clean_address(address)
        assert result["locality"] == "Welwyn Garden City"

    def test_builds_formatted_line(self) -> None:
        address = {
            "premises": "Tesco House",
            "address_line_1": "Kestrel Way",
            "locality": "Welwyn Garden City",
            "postal_code": "AL7 1GA",
        }
        result = clean_address(address)
        assert result["formatted"] == "Tesco House, Kestrel Way, Welwyn Garden City, AL7 1GA"

    def test_empty_address(self) -> None:
        assert clean_address({}) == {}
        assert clean_address(None) == {}

    def test_includes_care_of(self) -> None:
        address = {"care_of": "The Company Secretary", "address_line_1": "1 High St"}
        result = clean_address(address)
        assert result["care_of"] == "The Company Secretary"

    def test_includes_po_box(self) -> None:
        address = {"po_box": "PO Box 123", "address_line_1": "1 High St"}
        result = clean_address(address)
        assert result["po_box"] == "Po Box 123"  # title cased


# ---------------------------------------------------------------------------
# Filing description
# ---------------------------------------------------------------------------


class TestCleanFilingHistory:
    def test_renders_simple_description(self) -> None:
        response = {
            "items": [
                {
                    "description": "capital-return-purchase-own-shares",
                    "category": "capital",
                    "date": "2026-03-09",
                }
            ]
        }
        result = clean_filing_history(response)
        item = result["items"][0]
        assert "description_rendered" in item
        assert item["description_rendered"] == "Capital return purchase own shares"

    def test_renders_description_with_values(self) -> None:
        response = {
            "items": [
                {
                    "description": "termination-director-company-with-name-termination-date",
                    "description_values": {
                        "officer_name": "James Watt",
                        "termination_date": "2026-03-24",
                    },
                    "category": "officers",
                }
            ]
        }
        result = clean_filing_history(response)
        rendered = result["items"][0]["description_rendered"]
        assert "James Watt" in rendered
        assert "2026-03-24" in rendered

    def test_renders_capital_values(self) -> None:
        response = {
            "items": [
                {
                    "description": "capital-cancellation-shares",
                    "description_values": {
                        "date": "2026-01-21",
                        "capital": [{"currency": "GBP", "figure": "404,394,910.41"}],
                    },
                }
            ]
        }
        result = clean_filing_history(response)
        rendered = result["items"][0]["description_rendered"]
        assert "GBP" in rendered
        assert "404,394,910.41" in rendered

    def test_empty_description(self) -> None:
        response = {"items": [{"description": "", "category": "other"}]}
        result = clean_filing_history(response)
        assert result["items"][0]["description_rendered"] == ""

    def test_adds_cleaning_annotations(self) -> None:
        response = {
            "items": [
                {"description": "some-filing-type", "date": "2026-01-01", "category": "other"}
            ]
        }
        result = clean_filing_history(response)
        assert "_cleaning" in result["items"][0]
        assert "description_rendered" in result["items"][0]["_cleaning"]


# ---------------------------------------------------------------------------
# Charge status interpretation
# ---------------------------------------------------------------------------


class TestInterpretChargeStatus:
    def test_known_status(self) -> None:
        assert interpret_charge_status("outstanding") == "Outstanding"
        assert interpret_charge_status("fully-satisfied") == "Fully Satisfied"
        assert interpret_charge_status("part-satisfied") == "Part Satisfied"

    def test_unknown_status(self) -> None:
        result = interpret_charge_status("some-new-status")
        assert result == "Some New Status"


# ---------------------------------------------------------------------------
# Insolvency case type interpretation
# ---------------------------------------------------------------------------


class TestInterpretInsolvencyCaseType:
    def test_known_types(self) -> None:
        assert interpret_insolvency_case_type("compulsory-liquidation") == "Compulsory Liquidation"
        assert (
            interpret_insolvency_case_type("creditors-voluntary-liquidation")
            == "Creditors' Voluntary Liquidation"
        )
        assert interpret_insolvency_case_type("administration") == "Administration"

    def test_unknown_type(self) -> None:
        result = interpret_insolvency_case_type("new-type")
        assert result == "New Type"


# ---------------------------------------------------------------------------
# Charges cleaning
# ---------------------------------------------------------------------------


class TestCleanCharges:
    def test_interprets_status(self) -> None:
        response = {
            "items": [
                {"status": "outstanding", "persons_entitled": []},
                {"status": "fully-satisfied", "persons_entitled": []},
            ]
        }
        result = clean_charges(response)
        assert result["items"][0]["status_description"] == "Outstanding"
        assert result["items"][1]["status_description"] == "Fully Satisfied"

    def test_counts(self) -> None:
        response = {
            "items": [
                {"status": "outstanding", "persons_entitled": []},
                {"status": "fully-satisfied", "persons_entitled": []},
                {"status": "part-satisfied", "persons_entitled": []},
            ]
        }
        result = clean_charges(response)
        assert result["outstanding_count"] == 1
        assert result["satisfied_count"] == 1
        assert result["part_satisfied_count"] == 1

    def test_normalises_persons_entitled(self) -> None:
        response = {
            "items": [
                {
                    "status": "outstanding",
                    "persons_entitled": [{"name": "BARCLAYS BANK PLC"}],
                }
            ]
        }
        result = clean_charges(response)
        assert result["items"][0]["persons_entitled"][0]["name"] == "Barclays Bank Plc"
        assert result["items"][0]["_cleaning"]["persons_entitled_normalised"] is True


# ---------------------------------------------------------------------------
# Insolvency cleaning
# ---------------------------------------------------------------------------


class TestCleanInsolvency:
    def test_interprets_case_type(self) -> None:
        response = {
            "cases": [
                {
                    "type": "creditors-voluntary-liquidation",
                    "dates": [],
                    "practitioners": [],
                }
            ],
            "status": ["liquidation"],
        }
        result = clean_insolvency(response)
        assert result["cases"][0]["type_description"] == "Creditors' Voluntary Liquidation"
        assert result["cases"][0]["_cleaning"]["case_type_interpreted"] is True

    def test_normalises_practitioner_name(self) -> None:
        response = {
            "cases": [
                {
                    "type": "administration",
                    "dates": [],
                    "practitioners": [
                        {"name": "SMITH, John Andrew", "address": {}}
                    ],
                }
            ],
            "status": [],
        }
        result = clean_insolvency(response)
        practitioner = result["cases"][0]["practitioners"][0]
        assert practitioner["name"] == "John Andrew Smith"


# ---------------------------------------------------------------------------
# Officer search cleaning
# ---------------------------------------------------------------------------


class TestCleanOfficerSearch:
    def test_extracts_officer_id(self) -> None:
        response = {
            "items": [
                {
                    "title": "SMITH, John",
                    "links": {"self": "/officers/abc123def456/appointments"},
                }
            ]
        }
        result = clean_officer_search(response)
        assert result["items"][0]["officer_id"] == "abc123def456"
        assert result["items"][0]["_cleaning"]["officer_id_extracted"] is True

    def test_classifies_corporate_entity(self) -> None:
        response = {
            "items": [
                {
                    "title": "SMITH HOLDINGS LIMITED",
                    "links": {"self": "/officers/xyz/appointments"},
                }
            ]
        }
        result = clean_officer_search(response)
        assert result["items"][0]["_cleaning"]["entity_type"] == "corporate"

    def test_classifies_individual(self) -> None:
        response = {
            "items": [
                {
                    "title": "SMITH, John",
                    "links": {"self": "/officers/abc/appointments"},
                }
            ]
        }
        result = clean_officer_search(response)
        assert result["items"][0]["_cleaning"]["entity_type"] == "individual"


# ---------------------------------------------------------------------------
# Officer appointments cleaning
# ---------------------------------------------------------------------------


class TestCleanOfficerAppointments:
    def test_pads_company_numbers(self) -> None:
        response = {
            "items": [
                {
                    "appointed_to": {
                        "company_number": "445790",
                        "company_name": "TESCO PLC",
                        "company_status": "active",
                    },
                    "officer_role": "director",
                    "appointed_on": "2020-01-01",
                    "name": "SMITH, John",
                }
            ]
        }
        result = clean_officer_appointments(response)
        assert result["items"][0]["appointed_to"]["company_number"] == "00445790"
        assert result["items"][0]["_cleaning"]["company_number_padded"] is True

    def test_active_resigned_counts(self) -> None:
        response = {
            "items": [
                {
                    "appointed_to": {"company_number": "00000001"},
                    "officer_role": "director",
                    "name": "A",
                },
                {
                    "appointed_to": {"company_number": "00000002"},
                    "officer_role": "director",
                    "resigned_on": "2020-01-01",
                    "name": "A",
                },
            ]
        }
        result = clean_officer_appointments(response)
        assert result["active_count"] == 1
        assert result["resigned_count"] == 1


# ---------------------------------------------------------------------------
# Disqualified officer cleaning
# ---------------------------------------------------------------------------


class TestCleanDisqualifiedOfficer:
    def test_normalises_name(self) -> None:
        response = {
            "name": "BLOGGS, Joseph William",
            "disqualifications": [
                {"reason": {}, "address": {}}
            ],
        }
        result = clean_disqualified_officer(response)
        assert result["name"] == "Joseph William Bloggs"
        assert result["_cleaning"]["name_normalised"] is True

    def test_interprets_reason(self) -> None:
        response = {
            "name": "Test Person",
            "disqualifications": [
                {
                    "reason": {
                        "act": "company-directors-disqualification-act-1986",
                        "section": "6",
                    },
                    "address": {},
                }
            ],
        }
        result = clean_disqualified_officer(response)
        reason = result["disqualifications"][0]["reason"]
        assert "description" in reason
        assert "Section 6" in reason["description"]


# ---------------------------------------------------------------------------
# Advanced search cleaning
# ---------------------------------------------------------------------------


class TestCleanAdvancedSearch:
    def test_pads_company_numbers(self) -> None:
        response = {
            "items": [
                {"company_number": "445790", "company_name": "TESCO PLC", "sic_codes": ["47110"]}
            ]
        }
        result = clean_advanced_search(response)
        assert result["items"][0]["company_number"] == "00445790"
        assert result["items"][0]["_cleaning"]["company_number_padded"] is True

    def test_adds_sic_descriptions(self) -> None:
        response = {
            "items": [
                {"company_number": "00445790", "company_name": "TESCO PLC", "sic_codes": ["47110"]}
            ]
        }
        result = clean_advanced_search(response)
        assert "sic_descriptions" in result["items"][0]
        assert result["items"][0]["sic_descriptions"][0]["code"] == "47110"
        assert result["items"][0]["_cleaning"]["sic_descriptions_added"] is True


# ---------------------------------------------------------------------------
# Registered address cleaning
# ---------------------------------------------------------------------------


class TestCleanRegisteredAddress:
    def test_normalises_address(self) -> None:
        response = {
            "address_line_1": "KESTREL WAY",
            "locality": "WELWYN GARDEN CITY",
            "postal_code": "al71ga",
            "country": "UNITED KINGDOM",
        }
        result = clean_registered_address(response)
        assert result["postal_code"] == "AL7 1GA"
        assert result["_cleaning"]["postcode_formatted"] is True
        assert result["_cleaning"]["address_normalised"] is True

    def test_country_normalised(self) -> None:
        response = {
            "address_line_1": "1 High St",
            "country": "UNITED KINGDOM",
        }
        result = clean_registered_address(response)
        assert result["country"] == "United Kingdom"
        assert result["_cleaning"]["country_normalised"] is True


# ---------------------------------------------------------------------------
# Top-level cleaning functions
# ---------------------------------------------------------------------------


class TestCleanCompanyProfile:
    def test_cleans_address(self) -> None:
        profile = {
            "company_name": "TESCO PLC",
            "company_number": "00445790",
            "registered_office_address": {
                "address_line_1": "KESTREL WAY",
                "postal_code": "al71ga",
            },
            "sic_codes": ["47110"],
        }
        result = clean_company_profile(profile)
        assert result["registered_office_address"]["postal_code"] == "AL7 1GA"
        assert result["_cleaning"]["address_normalised"] is True

    def test_adds_sic_descriptions(self) -> None:
        profile = {
            "company_name": "TESCO PLC",
            "company_number": "00445790",
            "sic_codes": ["47110"],
        }
        result = clean_company_profile(profile)
        assert "sic_descriptions" in result
        assert result["sic_descriptions"][0]["code"] == "47110"
        assert "Retail" in result["sic_descriptions"][0]["description"]
        assert result["_cleaning"]["sic_descriptions_added"] is True


class TestCleanOfficerList:
    def test_adds_cleaning_metadata(self) -> None:
        response = {
            "items": [
                {"name": "MURPHY, Ken", "officer_role": "director", "appointed_on": "2020-10-01"},
                {"name": "Mr Ken Murphy", "officer_role": "director", "appointed_on": "2018-06-15"},
            ],
            "total_results": 2,
        }
        result = clean_officer_list(response)
        assert result["_cleaning"]["original_count"] == 2
        assert result["_cleaning"]["deduplicated_count"] == 1
        assert result["_cleaning"]["duplicates_removed"] == 1

    def test_includes_active_resigned_counts(self) -> None:
        response = {
            "items": [
                {"name": "MURPHY, Ken", "officer_role": "director", "appointed_on": "2020-01-01"},
                {
                    "name": "ZHANG, Wei",
                    "officer_role": "director",
                    "appointed_on": "2015-01-01",
                    "resigned_on": "2019-12-31",
                },
            ],
            "total_results": 2,
        }
        result = clean_officer_list(response)
        assert result["active_count"] == 1
        assert result["resigned_count"] == 1


class TestCleanPscList:
    def test_annotates_items(self) -> None:
        response = {
            "items": [
                {
                    "name": "Tesco Holdings Limited",
                    "kind": "corporate-entity-person-with-significant-control",
                    "natures_of_control": ["ownership-of-shares-75-to-100-percent"],
                }
            ]
        }
        result = clean_psc_list(response)
        assert "_cleaning" in result["items"][0]
        assert result["active_count"] == 1
        assert result["ceased_count"] == 0


class TestCleanSearchResults:
    def test_pads_company_numbers(self) -> None:
        response = {
            "items": [
                {"title": "TESCO PLC", "company_number": "445790"}
            ]
        }
        result = clean_search_results(response)
        assert result["items"][0]["company_number"] == "00445790"
        assert result["items"][0]["_cleaning"]["company_number_padded"] is True

    def test_normalises_addresses(self) -> None:
        response = {
            "items": [
                {
                    "title": "TESCO PLC",
                    "company_number": "00445790",
                    "address": {"postal_code": "al71ga", "locality": "WELWYN GARDEN CITY"},
                }
            ]
        }
        result = clean_search_results(response)
        assert result["items"][0]["address"]["postal_code"] == "AL7 1GA"
