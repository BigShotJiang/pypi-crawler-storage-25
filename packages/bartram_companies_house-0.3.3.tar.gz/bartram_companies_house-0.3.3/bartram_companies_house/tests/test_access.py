"""Tests for Companies House API client.

Uses httpx mock transport to return fixture data without hitting the real API.
Covers all 12 endpoints.
"""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest

from bartram_companies_house.access import (
    AuthenticationError,
    CompaniesHouseClient,
    CompaniesHouseConfig,
    NotFoundError,
    RateLimitError,
    normalise_company_number,
)

FIXTURES = Path(__file__).parent / "fixtures"


def load_fixture(name: str) -> dict:
    """Load a JSON fixture file."""
    return json.loads((FIXTURES / name).read_text())


# ---------------------------------------------------------------------------
# Mock transport
# ---------------------------------------------------------------------------


class MockTransport(httpx.BaseTransport):
    """Returns canned responses for known paths, 404 for unknown."""

    def __init__(self) -> None:
        self.routes: dict[str, tuple[int, dict]] = {}

    def add_route(self, path: str, fixture_name: str, status: int = 200) -> None:
        self.routes[path] = (status, load_fixture(fixture_name))

    def add_json_route(self, path: str, data: dict, status: int = 200) -> None:
        self.routes[path] = (status, data)

    def add_error_route(self, path: str, status: int, body: str = "") -> None:
        self.routes[path] = (status, {"error": body})

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        path = request.url.raw_path.decode().split("?")[0]
        if path in self.routes:
            status, data = self.routes[path]
            return httpx.Response(status, json=data)
        return httpx.Response(404, json={"error": "Not found"})


def make_client(transport: MockTransport) -> CompaniesHouseClient:
    """Create a client with a mock transport (caching disabled)."""
    config = CompaniesHouseConfig(api_key="test-key", cache_enabled=False)
    client = CompaniesHouseClient(config)
    client._client = httpx.Client(transport=transport, base_url=config.base_url)
    return client


# ---------------------------------------------------------------------------
# Tests — company number normalisation
# ---------------------------------------------------------------------------


class TestNormaliseCompanyNumber:
    def test_pads_numeric(self) -> None:
        assert normalise_company_number("445790") == "00445790"

    def test_already_padded(self) -> None:
        assert normalise_company_number("00445790") == "00445790"

    def test_prefix_uppercased(self) -> None:
        assert normalise_company_number("sc311560") == "SC311560"

    def test_strips_whitespace(self) -> None:
        assert normalise_company_number("  445790  ") == "00445790"


# ---------------------------------------------------------------------------
# Tests — search
# ---------------------------------------------------------------------------


class TestSearchCompanies:
    def test_search_returns_results(self) -> None:
        transport = MockTransport()
        transport.add_route("/search/companies", "search_tesco.json")
        client = make_client(transport)

        result = client.search_companies("Tesco")

        assert result["total_results"] == 356
        assert len(result["items"]) == 2
        assert result["items"][0]["company_number"] == "00445790"
        assert result["items"][0]["title"] == "TESCO PLC"

    def test_search_returns_company_status(self) -> None:
        transport = MockTransport()
        transport.add_route("/search/companies", "search_tesco.json")
        client = make_client(transport)

        result = client.search_companies("Tesco")

        assert result["items"][0]["company_status"] == "active"
        assert result["items"][1]["company_status"] == "dissolved"


# ---------------------------------------------------------------------------
# Tests — company profile
# ---------------------------------------------------------------------------


class TestGetCompany:
    def test_get_company_profile(self) -> None:
        transport = MockTransport()
        transport.add_route("/company/00445790", "company_00445790.json")
        client = make_client(transport)

        result = client.get_company("00445790")

        assert result["company_name"] == "TESCO PLC"
        assert result["company_number"] == "00445790"
        assert result["company_status"] == "active"
        assert result["type"] == "plc"
        assert result["sic_codes"] == ["47110"]

    def test_get_company_has_address(self) -> None:
        transport = MockTransport()
        transport.add_route("/company/00445790", "company_00445790.json")
        client = make_client(transport)

        result = client.get_company("00445790")
        address = result["registered_office_address"]

        assert address["postal_code"] == "AL7 1GA"
        assert "Welwyn Garden City" in address["locality"]

    def test_get_company_not_found(self) -> None:
        transport = MockTransport()
        client = make_client(transport)

        with pytest.raises(NotFoundError):
            client.get_company("99999999")


# ---------------------------------------------------------------------------
# Tests — officers
# ---------------------------------------------------------------------------


class TestGetOfficers:
    def test_get_officers_returns_list(self) -> None:
        transport = MockTransport()
        transport.add_route("/company/00445790/officers", "officers_00445790.json")
        client = make_client(transport)

        result = client.get_officers("00445790")

        assert result["total_results"] == 2
        assert len(result["items"]) == 2
        assert result["items"][0]["name"] == "MURPHY, Ken"
        assert result["items"][0]["officer_role"] == "director"


# ---------------------------------------------------------------------------
# Tests — PSCs
# ---------------------------------------------------------------------------


class TestGetPscs:
    def test_get_pscs_returns_list(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/company/00445790/persons-with-significant-control",
            "pscs_00445790.json",
        )
        client = make_client(transport)

        result = client.get_pscs("00445790")

        assert result["total_results"] == 1
        assert result["items"][0]["name"] == "Tesco Holdings Limited"

    def test_get_pscs_has_natures_of_control(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/company/00445790/persons-with-significant-control",
            "pscs_00445790.json",
        )
        client = make_client(transport)

        result = client.get_pscs("00445790")

        natures = result["items"][0]["natures_of_control"]
        assert "ownership-of-shares-75-to-100-percent" in natures


# ---------------------------------------------------------------------------
# Tests — filing history
# ---------------------------------------------------------------------------


class TestGetFilingHistory:
    def test_get_filings_returns_list(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/company/00445790/filing-history",
            "filings_00445790.json",
        )
        client = make_client(transport)

        result = client.get_filing_history("00445790")

        assert result["total_results"] == 3
        assert result["items"][0]["category"] == "accounts"


# ---------------------------------------------------------------------------
# Tests — charges (NEW)
# ---------------------------------------------------------------------------


class TestGetCharges:
    def test_get_charges_returns_list(self) -> None:
        transport = MockTransport()
        transport.add_route("/company/00445790/charges", "charges_00445790.json")
        client = make_client(transport)

        result = client.get_charges("00445790")

        assert result["total_results"] == 2
        assert len(result["items"]) == 2
        assert result["items"][0]["status"] == "fully-satisfied"
        assert result["items"][1]["status"] == "outstanding"

    def test_get_charges_has_persons_entitled(self) -> None:
        transport = MockTransport()
        transport.add_route("/company/00445790/charges", "charges_00445790.json")
        client = make_client(transport)

        result = client.get_charges("00445790")

        persons = result["items"][0]["persons_entitled"]
        assert persons[0]["name"] == "BARCLAYS BANK PLC"


# ---------------------------------------------------------------------------
# Tests — insolvency (NEW)
# ---------------------------------------------------------------------------


class TestGetInsolvency:
    def test_get_insolvency_returns_cases(self) -> None:
        transport = MockTransport()
        transport.add_route("/company/01234567/insolvency", "insolvency_01234567.json")
        client = make_client(transport)

        result = client.get_insolvency("01234567")

        assert len(result["cases"]) == 1
        assert result["cases"][0]["type"] == "creditors-voluntary-liquidation"
        assert result["status"] == ["liquidation"]

    def test_get_insolvency_not_found(self) -> None:
        transport = MockTransport()
        client = make_client(transport)

        with pytest.raises(NotFoundError):
            client.get_insolvency("99999999")


# ---------------------------------------------------------------------------
# Tests — officer search (NEW)
# ---------------------------------------------------------------------------


class TestSearchOfficers:
    def test_search_officers_returns_results(self) -> None:
        transport = MockTransport()
        transport.add_route("/search/officers", "officer_search_smith.json")
        client = make_client(transport)

        result = client.search_officers("Smith")

        assert result["total_results"] == 1542
        assert len(result["items"]) == 2
        assert result["items"][0]["title"] == "SMITH, John"

    def test_search_officers_has_links(self) -> None:
        transport = MockTransport()
        transport.add_route("/search/officers", "officer_search_smith.json")
        client = make_client(transport)

        result = client.search_officers("Smith")

        assert "/officers/" in result["items"][0]["links"]["self"]


# ---------------------------------------------------------------------------
# Tests — officer appointments (NEW)
# ---------------------------------------------------------------------------


class TestGetOfficerAppointments:
    def test_get_appointments_returns_list(self) -> None:
        transport = MockTransport()
        transport.add_route("/officers/abc123/appointments", "appointments_abc123.json")
        client = make_client(transport)

        result = client.get_officer_appointments("abc123")

        assert result["total_results"] == 3
        assert len(result["items"]) == 3
        assert result["items"][0]["appointed_to"]["company_name"] == "TESCO PLC"


# ---------------------------------------------------------------------------
# Tests — disqualified officer (NEW)
# ---------------------------------------------------------------------------


class TestGetDisqualifiedOfficer:
    def test_get_disqualified_returns_record(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/disqualified-officers/natural/xyz789",
            "disqualified_natural_xyz789.json",
        )
        client = make_client(transport)

        result = client.get_disqualified_officer("xyz789")

        assert result["name"] == "BLOGGS, Joseph William"
        assert len(result["disqualifications"]) == 1

    def test_not_disqualified_raises_not_found(self) -> None:
        transport = MockTransport()
        client = make_client(transport)

        with pytest.raises(NotFoundError):
            client.get_disqualified_officer("unknown123")


# ---------------------------------------------------------------------------
# Tests — advanced search (NEW)
# ---------------------------------------------------------------------------


class TestAdvancedSearch:
    def test_advanced_search_returns_results(self) -> None:
        transport = MockTransport()
        transport.add_route("/advanced-search/companies", "advanced_search_active.json")
        client = make_client(transport)

        result = client.advanced_search(company_status="active", sic_codes="47110")

        assert result["total_results"] == 2
        assert result["items"][0]["company_name"] == "TESCO PLC"

    def test_advanced_search_has_sic_codes(self) -> None:
        transport = MockTransport()
        transport.add_route("/advanced-search/companies", "advanced_search_active.json")
        client = make_client(transport)

        result = client.advanced_search(sic_codes="47110")

        assert result["items"][0]["sic_codes"] == ["47110"]


# ---------------------------------------------------------------------------
# Tests — registered address (NEW)
# ---------------------------------------------------------------------------


class TestGetRegisteredAddress:
    def test_get_registered_address(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/company/00445790/registered-office-address",
            "registered_address_00445790.json",
        )
        client = make_client(transport)

        result = client.get_registered_address("00445790")

        assert result["address_line_1"] == "KESTREL WAY"
        assert result["postal_code"] == "al71ga"  # raw — cleaning happens in clean.py


# ---------------------------------------------------------------------------
# Tests — error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_401_raises_auth_error(self) -> None:
        transport = MockTransport()
        transport.add_error_route("/company/00445790", 401, "Invalid API key")
        client = make_client(transport)

        with pytest.raises(AuthenticationError) as exc_info:
            client.get_company("00445790")
        assert exc_info.value.status_code == 401

    def test_403_raises_auth_error(self) -> None:
        transport = MockTransport()
        transport.add_error_route("/company/00445790", 403, "Forbidden")
        client = make_client(transport)

        with pytest.raises(AuthenticationError) as exc_info:
            client.get_company("00445790")
        assert exc_info.value.status_code == 403

    def test_429_raises_rate_limit_error(self) -> None:
        transport = MockTransport()
        transport.add_error_route("/search/companies", 429, "Rate limit exceeded")
        client = make_client(transport)

        with pytest.raises(RateLimitError) as exc_info:
            client.search_companies("test")
        assert exc_info.value.status_code == 429

    def test_404_raises_not_found(self) -> None:
        transport = MockTransport()
        client = make_client(transport)

        with pytest.raises(NotFoundError):
            client.get_company("99999999")


# ---------------------------------------------------------------------------
# Tests — config
# ---------------------------------------------------------------------------


class TestConfig:
    def test_from_env_raises_without_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("COMPANIES_HOUSE_API_KEY", raising=False)
        with pytest.raises(ValueError, match="COMPANIES_HOUSE_API_KEY"):
            CompaniesHouseConfig.from_env()

    def test_from_env_reads_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("COMPANIES_HOUSE_API_KEY", "test-key-123")
        config = CompaniesHouseConfig.from_env()
        assert config.api_key == "test-key-123"
