"""Tests for Companies House MCP tool definitions.

Tests the full access -> clean -> serve pipeline using mock HTTP transport.
Covers all 12 tools.
"""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest

from bartram_companies_house import serve
from bartram_companies_house.access import CompaniesHouseClient, CompaniesHouseConfig

FIXTURES = Path(__file__).parent / "fixtures"


def load_fixture(name: str) -> dict:
    return json.loads((FIXTURES / name).read_text())


# ---------------------------------------------------------------------------
# Mock transport
# ---------------------------------------------------------------------------


class MockTransport(httpx.BaseTransport):
    def __init__(self) -> None:
        self.routes: dict[str, tuple[int, dict]] = {}

    def add_route(self, path: str, fixture_name: str, status: int = 200) -> None:
        self.routes[path] = (status, load_fixture(fixture_name))

    def add_json_route(self, path: str, data: dict, status: int = 200) -> None:
        self.routes[path] = (status, data)

    def add_error_route(self, path: str, status: int) -> None:
        self.routes[path] = (status, {"error": "Not found"})

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        path = request.url.raw_path.decode().split("?")[0]
        if path in self.routes:
            status, data = self.routes[path]
            return httpx.Response(status, json=data)
        return httpx.Response(404, json={"error": "Not found"})


@pytest.fixture(autouse=True)
def _mock_client(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Replace the serve module's client and metrics with test instances."""
    transport = MockTransport()

    # Existing 5 endpoints
    transport.add_route("/search/companies", "search_tesco.json")
    transport.add_route("/company/00445790", "company_00445790.json")
    transport.add_route("/company/00445790/officers", "officers_00445790.json")
    transport.add_route(
        "/company/00445790/persons-with-significant-control",
        "pscs_00445790.json",
    )
    transport.add_route("/company/00445790/filing-history", "filings_00445790.json")

    # 7 new endpoints
    transport.add_route("/company/00445790/charges", "charges_00445790.json")
    transport.add_route("/company/01234567/insolvency", "insolvency_01234567.json")
    transport.add_route("/search/officers", "officer_search_smith.json")
    transport.add_route("/officers/abc123/appointments", "appointments_abc123.json")
    transport.add_route(
        "/disqualified-officers/natural/xyz789",
        "disqualified_natural_xyz789.json",
    )
    transport.add_route("/advanced-search/companies", "advanced_search_active.json")
    transport.add_route(
        "/company/00445790/registered-office-address",
        "registered_address_00445790.json",
    )

    config = CompaniesHouseConfig(api_key="test-key", cache_enabled=False)
    client = CompaniesHouseClient(config)
    client._client = httpx.Client(transport=transport, base_url=config.base_url)

    monkeypatch.setattr(serve, "_client", client)

    from bartram_foundry.monitoring import MetricsStore

    monkeypatch.setattr(serve, "_metrics", MetricsStore(tmp_path / "test_metrics.db"))


# ---------------------------------------------------------------------------
# Tests — server setup
# ---------------------------------------------------------------------------


class TestServerSetup:
    def test_server_exists(self) -> None:
        assert serve.server.name == "bartram-companies-house"


# ---------------------------------------------------------------------------
# Tests — search (renamed)
# ---------------------------------------------------------------------------


class TestSearch:
    @pytest.mark.asyncio
    async def test_search_returns_json_with_results(self) -> None:
        result = await serve.uk_companies_house_search("Tesco", 10)
        parsed = json.loads(result)
        assert "data" in parsed
        assert "metadata" in parsed
        assert parsed["data"]["total_results"] == 356

    @pytest.mark.asyncio
    async def test_search_includes_attribution(self) -> None:
        result = await serve.uk_companies_house_search("Tesco", 10)
        parsed = json.loads(result)
        assert "Open Government Licence v3" in parsed["metadata"]["licence"]
        assert "Companies House" in parsed["metadata"]["source"]
        assert "Contains public sector information" in parsed["metadata"]["attribution"]

    @pytest.mark.asyncio
    async def test_search_pads_company_numbers(self) -> None:
        result = await serve.uk_companies_house_search("Tesco", 10)
        parsed = json.loads(result)
        for item in parsed["data"]["items"]:
            assert "_cleaning" in item

    @pytest.mark.asyncio
    async def test_empty_query_returns_error(self) -> None:
        result = await serve.uk_companies_house_search("", 10)
        parsed = json.loads(result)
        assert "error" in parsed

    @pytest.mark.asyncio
    async def test_whitespace_query_returns_error(self) -> None:
        result = await serve.uk_companies_house_search("   ", 10)
        parsed = json.loads(result)
        assert "error" in parsed


# ---------------------------------------------------------------------------
# Tests — profile (renamed)
# ---------------------------------------------------------------------------


class TestProfile:
    @pytest.mark.asyncio
    async def test_profile_returns_company_data(self) -> None:
        result = await serve.uk_companies_house_profile("00445790")
        parsed = json.loads(result)
        assert parsed["data"]["company_name"] == "TESCO PLC"
        assert parsed["data"]["company_status"] == "active"

    @pytest.mark.asyncio
    async def test_profile_address_is_cleaned(self) -> None:
        result = await serve.uk_companies_house_profile("00445790")
        parsed = json.loads(result)
        address = parsed["data"]["registered_office_address"]
        assert "formatted" in address
        assert "AL7 1GA" in address["formatted"]

    @pytest.mark.asyncio
    async def test_profile_has_sic_descriptions(self) -> None:
        result = await serve.uk_companies_house_profile("00445790")
        parsed = json.loads(result)
        assert "sic_descriptions" in parsed["data"]
        assert parsed["data"]["_cleaning"]["sic_descriptions_added"] is True

    @pytest.mark.asyncio
    async def test_profile_not_found_returns_error(self) -> None:
        result = await serve.uk_companies_house_profile("99999999")
        parsed = json.loads(result)
        assert "error" in parsed
        assert parsed["status_code"] == 404

    @pytest.mark.asyncio
    async def test_unpadded_number_gets_padded(self) -> None:
        result = await serve.uk_companies_house_profile("445790")
        parsed = json.loads(result)
        assert parsed["data"]["company_name"] == "TESCO PLC"


# ---------------------------------------------------------------------------
# Tests — officers (renamed)
# ---------------------------------------------------------------------------


class TestOfficers:
    @pytest.mark.asyncio
    async def test_officers_returns_list(self) -> None:
        result = await serve.uk_companies_house_officers("00445790")
        parsed = json.loads(result)
        assert len(parsed["data"]["items"]) > 0

    @pytest.mark.asyncio
    async def test_officers_includes_cleaning_metadata(self) -> None:
        result = await serve.uk_companies_house_officers("00445790")
        parsed = json.loads(result)
        assert "_cleaning" in parsed["data"]
        assert "original_count" in parsed["data"]["_cleaning"]

    @pytest.mark.asyncio
    async def test_officers_includes_counts(self) -> None:
        result = await serve.uk_companies_house_officers("00445790")
        parsed = json.loads(result)
        assert "active_count" in parsed["data"]
        assert "resigned_count" in parsed["data"]


# ---------------------------------------------------------------------------
# Tests — PSC (renamed)
# ---------------------------------------------------------------------------


class TestPsc:
    @pytest.mark.asyncio
    async def test_psc_returns_annotated_records(self) -> None:
        result = await serve.uk_companies_house_psc("00445790")
        parsed = json.loads(result)
        items = parsed["data"]["items"]
        assert len(items) > 0
        assert "_cleaning" in items[0]

    @pytest.mark.asyncio
    async def test_psc_entity_typed(self) -> None:
        result = await serve.uk_companies_house_psc("00445790")
        parsed = json.loads(result)
        assert parsed["data"]["items"][0]["_cleaning"]["entity_type"] == "corporate"

    @pytest.mark.asyncio
    async def test_psc_nature_of_control_interpreted(self) -> None:
        result = await serve.uk_companies_house_psc("00445790")
        parsed = json.loads(result)
        assert "natures_of_control_descriptions" in parsed["data"]["items"][0]

    @pytest.mark.asyncio
    async def test_psc_includes_counts(self) -> None:
        result = await serve.uk_companies_house_psc("00445790")
        parsed = json.loads(result)
        assert "active_count" in parsed["data"]
        assert "ceased_count" in parsed["data"]


# ---------------------------------------------------------------------------
# Tests — filings (renamed)
# ---------------------------------------------------------------------------


class TestFilings:
    @pytest.mark.asyncio
    async def test_filings_returns_history(self) -> None:
        result = await serve.uk_companies_house_filings("00445790")
        parsed = json.loads(result)
        assert parsed["data"]["total_results"] == 3
        assert parsed["data"]["items"][0]["category"] == "accounts"

    @pytest.mark.asyncio
    async def test_filings_have_rendered_descriptions(self) -> None:
        result = await serve.uk_companies_house_filings("00445790")
        parsed = json.loads(result)
        for item in parsed["data"]["items"]:
            assert "description_rendered" in item

    @pytest.mark.asyncio
    async def test_filings_have_cleaning_annotations(self) -> None:
        result = await serve.uk_companies_house_filings("00445790")
        parsed = json.loads(result)
        for item in parsed["data"]["items"]:
            assert "_cleaning" in item

    @pytest.mark.asyncio
    async def test_invalid_category_returns_error(self) -> None:
        result = await serve.uk_companies_house_filings("00445790", category="invalid-cat")
        parsed = json.loads(result)
        assert "error" in parsed
        assert "Unknown filing category" in parsed["error"]


# ---------------------------------------------------------------------------
# Tests — charges (NEW)
# ---------------------------------------------------------------------------


class TestCharges:
    @pytest.mark.asyncio
    async def test_charges_returns_list(self) -> None:
        result = await serve.uk_companies_house_charges("00445790")
        parsed = json.loads(result)
        assert parsed["data"]["total_results"] == 2

    @pytest.mark.asyncio
    async def test_charges_has_status_descriptions(self) -> None:
        result = await serve.uk_companies_house_charges("00445790")
        parsed = json.loads(result)
        items = parsed["data"]["items"]
        assert items[0]["status_description"] == "Fully Satisfied"
        assert items[1]["status_description"] == "Outstanding"

    @pytest.mark.asyncio
    async def test_charges_has_counts(self) -> None:
        result = await serve.uk_companies_house_charges("00445790")
        parsed = json.loads(result)
        assert parsed["data"]["outstanding_count"] == 1
        assert parsed["data"]["satisfied_count"] == 1

    @pytest.mark.asyncio
    async def test_charges_has_metadata(self) -> None:
        result = await serve.uk_companies_house_charges("00445790")
        parsed = json.loads(result)
        assert parsed["metadata"]["endpoint"] == "/company/00445790/charges"
        assert "attribution" in parsed["metadata"]


# ---------------------------------------------------------------------------
# Tests — insolvency (NEW)
# ---------------------------------------------------------------------------


class TestInsolvency:
    @pytest.mark.asyncio
    async def test_insolvency_returns_cases(self) -> None:
        result = await serve.uk_companies_house_insolvency("01234567")
        parsed = json.loads(result)
        assert len(parsed["data"]["cases"]) == 1
        assert parsed["data"]["cases"][0]["type_description"] == "Creditors' Voluntary Liquidation"

    @pytest.mark.asyncio
    async def test_insolvency_normalises_practitioner(self) -> None:
        result = await serve.uk_companies_house_insolvency("01234567")
        parsed = json.loads(result)
        practitioner = parsed["data"]["cases"][0]["practitioners"][0]
        assert practitioner["name"] == "John Andrew Smith"

    @pytest.mark.asyncio
    async def test_insolvency_404_returns_empty(self) -> None:
        result = await serve.uk_companies_house_insolvency("99999999")
        parsed = json.loads(result)
        assert parsed["data"]["cases"] == []
        assert parsed["data"]["_cleaning"]["api_404_despite_profile_flag"] is True


# ---------------------------------------------------------------------------
# Tests — officer search (NEW)
# ---------------------------------------------------------------------------


class TestOfficerSearch:
    @pytest.mark.asyncio
    async def test_officer_search_returns_results(self) -> None:
        result = await serve.uk_companies_house_officer_search("Smith")
        parsed = json.loads(result)
        assert parsed["data"]["total_results"] == 1542
        assert len(parsed["data"]["items"]) == 2

    @pytest.mark.asyncio
    async def test_officer_search_has_officer_ids(self) -> None:
        result = await serve.uk_companies_house_officer_search("Smith")
        parsed = json.loads(result)
        assert "officer_id" in parsed["data"]["items"][0]
        assert parsed["data"]["items"][0]["_cleaning"]["officer_id_extracted"] is True

    @pytest.mark.asyncio
    async def test_officer_search_classifies_entities(self) -> None:
        result = await serve.uk_companies_house_officer_search("Smith")
        parsed = json.loads(result)
        assert parsed["data"]["items"][0]["_cleaning"]["entity_type"] == "individual"
        assert parsed["data"]["items"][1]["_cleaning"]["entity_type"] == "corporate"

    @pytest.mark.asyncio
    async def test_officer_search_empty_query_error(self) -> None:
        result = await serve.uk_companies_house_officer_search("")
        parsed = json.loads(result)
        assert "error" in parsed


# ---------------------------------------------------------------------------
# Tests — officer appointments (NEW)
# ---------------------------------------------------------------------------


class TestOfficerAppointments:
    @pytest.mark.asyncio
    async def test_appointments_returns_list(self) -> None:
        result = await serve.uk_companies_house_officer_appointments("abc123")
        parsed = json.loads(result)
        assert parsed["data"]["total_results"] == 3

    @pytest.mark.asyncio
    async def test_appointments_pads_company_numbers(self) -> None:
        result = await serve.uk_companies_house_officer_appointments("abc123")
        parsed = json.loads(result)
        # First item had "445790" which should be padded
        first = parsed["data"]["items"][0]
        assert first["appointed_to"]["company_number"] == "00445790"
        assert first["_cleaning"]["company_number_padded"] is True

    @pytest.mark.asyncio
    async def test_appointments_has_counts(self) -> None:
        result = await serve.uk_companies_house_officer_appointments("abc123")
        parsed = json.loads(result)
        assert "active_count" in parsed["data"]
        assert "resigned_count" in parsed["data"]
        assert parsed["data"]["active_count"] == 2
        assert parsed["data"]["resigned_count"] == 1

    @pytest.mark.asyncio
    async def test_appointments_empty_id_error(self) -> None:
        result = await serve.uk_companies_house_officer_appointments("")
        parsed = json.loads(result)
        assert "error" in parsed


# ---------------------------------------------------------------------------
# Tests — disqualified officer (NEW)
# ---------------------------------------------------------------------------


class TestDisqualifiedOfficer:
    @pytest.mark.asyncio
    async def test_disqualified_returns_record(self) -> None:
        result = await serve.uk_companies_house_disqualified_officer("xyz789")
        parsed = json.loads(result)
        assert parsed["data"]["disqualified"] is True
        assert len(parsed["data"]["disqualifications"]) == 1

    @pytest.mark.asyncio
    async def test_disqualified_normalises_name(self) -> None:
        result = await serve.uk_companies_house_disqualified_officer("xyz789")
        parsed = json.loads(result)
        assert parsed["data"]["name"] == "Joseph William Bloggs"

    @pytest.mark.asyncio
    async def test_not_disqualified_returns_clean_result(self) -> None:
        result = await serve.uk_companies_house_disqualified_officer("unknown123")
        parsed = json.loads(result)
        assert parsed["data"]["disqualified"] is False
        assert parsed["data"]["officer_id"] == "unknown123"

    @pytest.mark.asyncio
    async def test_invalid_officer_type_error(self) -> None:
        result = await serve.uk_companies_house_disqualified_officer("xyz789", "invalid")
        parsed = json.loads(result)
        assert "error" in parsed

    @pytest.mark.asyncio
    async def test_empty_id_error(self) -> None:
        result = await serve.uk_companies_house_disqualified_officer("")
        parsed = json.loads(result)
        assert "error" in parsed


# ---------------------------------------------------------------------------
# Tests — advanced search (NEW)
# ---------------------------------------------------------------------------


class TestAdvancedSearch:
    @pytest.mark.asyncio
    async def test_advanced_search_returns_results(self) -> None:
        result = await serve.uk_companies_house_advanced_search(company_status="active")
        parsed = json.loads(result)
        assert parsed["data"]["total_results"] == 2

    @pytest.mark.asyncio
    async def test_advanced_search_pads_numbers(self) -> None:
        result = await serve.uk_companies_house_advanced_search(sic_codes="47110")
        parsed = json.loads(result)
        first = parsed["data"]["items"][0]
        assert first["company_number"] == "00445790"

    @pytest.mark.asyncio
    async def test_advanced_search_has_sic_descriptions(self) -> None:
        result = await serve.uk_companies_house_advanced_search(company_status="active")
        parsed = json.loads(result)
        assert "sic_descriptions" in parsed["data"]["items"][0]

    @pytest.mark.asyncio
    async def test_advanced_search_no_filters_error(self) -> None:
        result = await serve.uk_companies_house_advanced_search()
        parsed = json.loads(result)
        assert "error" in parsed
        assert "At least one" in parsed["error"]


# ---------------------------------------------------------------------------
# Tests — registered address (NEW)
# ---------------------------------------------------------------------------


class TestRegisteredAddress:
    @pytest.mark.asyncio
    async def test_registered_address_normalised(self) -> None:
        result = await serve.uk_companies_house_registered_address("00445790")
        parsed = json.loads(result)
        assert parsed["data"]["postal_code"] == "AL7 1GA"
        assert parsed["data"]["_cleaning"]["postcode_formatted"] is True

    @pytest.mark.asyncio
    async def test_registered_address_has_metadata(self) -> None:
        result = await serve.uk_companies_house_registered_address("00445790")
        parsed = json.loads(result)
        assert (
            parsed["metadata"]["endpoint"]
            == "/company/00445790/registered-office-address"
        )

    @pytest.mark.asyncio
    async def test_registered_address_not_found(self) -> None:
        result = await serve.uk_companies_house_registered_address("99999999")
        parsed = json.loads(result)
        assert "error" in parsed


# ---------------------------------------------------------------------------
# Tests — response metadata
# ---------------------------------------------------------------------------


class TestResponseMetadata:
    @pytest.mark.asyncio
    async def test_all_responses_have_attribution(self) -> None:
        result = await serve.uk_companies_house_profile("00445790")
        parsed = json.loads(result)
        assert "Contains public sector information" in parsed["metadata"]["attribution"]
        assert "Open Government Licence v3.0" in parsed["metadata"]["attribution"]
        assert "Companies House" in parsed["metadata"]["attribution"]

    @pytest.mark.asyncio
    async def test_response_has_cached_field(self) -> None:
        result = await serve.uk_companies_house_profile("00445790")
        parsed = json.loads(result)
        assert "cached" in parsed["metadata"]

    @pytest.mark.asyncio
    async def test_error_has_attribution(self) -> None:
        result = await serve.uk_companies_house_profile("99999999")
        parsed = json.loads(result)
        assert "attribution" in parsed
