# Copyright The OpenTelemetry Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
GenAI Utils for OpenTelemetry Python

这个包提供了阿里云定制的 GenAI 工具，用于简化大模型应用的可观测性集成。

主要功能：
- 提供标准化的 GenAI 数据类型
- 支持两种遥测模式：Span+Attributes 和 Span+Events
- 提供灵活的配置选项
- 遵循阿里云扩展的语义约定

基本用法：
    from sdk.opentelemetry import trace
    from sdk.util.genai import GenAITelemetry
    from sdk.util.genai.data import LLMRequestAttributes, LLMResponseAttributes, GenAITelemetryOptions
    from sdk.util.genai.messages import InputMessages, OutputMessages
    
    # 创建配置选项
    options = GenAITelemetryOptions(
        capture_message_content=True,
        message_mode="event"
    )
    
    # 创建 telemetry 实例
    telemetry = GenAITelemetry(options=options)
    
    # 创建外部 span
    tracer = trace.get_tracer("example")
    with tracer.start_as_current_span("llm_call") as span:
        # 记录 LLM 输入
        request_info = LLMRequestAttributes(provider_name="openai", operation_name="chat")
        input_messages = InputMessages()
        telemetry.trace_llm_start(span, request_info, input_messages)
        
        # 执行 LLM 调用...
        
        # 记录 LLM 响应
        output_messages = OutputMessages()
        response_info = LLMResponseAttributes(provider_name="openai", operation_name="chat")
        telemetry.trace_llm_end(span, request_info, output_messages, response_info)
"""

from ctyun.opentelemetry.sdk.util.genai.api import GenAITelemetry
from ctyun.opentelemetry.sdk.util.genai.data import (
    LLMRequestAttributes, 
    LLMResponseAttributes,
    EmbeddingRequestAttributes,
    EmbeddingResponseAttributes,
    RerankerRequestAttributes,
    RerankerResponseAttributes,
    ToolRequestAttributes,
    ToolResponseAttributes,
)
from ctyun.opentelemetry.sdk.util.genai.options import GenAITelemetryOptions
from ctyun.opentelemetry.sdk.util.genai.messages import (
    InputMessages, 
    OutputMessages,
    InputDocuments,
    OutputDocuments,
    Document,
    RankedDocument,
)
from ctyun.opentelemetry.sdk.util.genai.version import __version__

__all__ = [
    "GenAITelemetry",
    "LLMRequestAttributes", 
    "LLMResponseAttributes",
    "EmbeddingRequestAttributes",
    "EmbeddingResponseAttributes",
    "RerankerRequestAttributes",
    "RerankerResponseAttributes",
    "ToolRequestAttributes",
    "ToolResponseAttributes",
    "GenAITelemetryOptions",
    "InputMessages",
    "OutputMessages",
    "InputDocuments",
    "OutputDocuments",
    "Document",
    "RankedDocument",
    "__version__",
]