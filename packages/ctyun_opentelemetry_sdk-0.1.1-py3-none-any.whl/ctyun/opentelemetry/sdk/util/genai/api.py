# Copyright The OpenTelemetry Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
核心 API

提供 GenAI 工具的主要接口，包括 Telemetry 实例的创建和管理。
"""

import json
import time
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple, Union

from aliyun.sdk.extension.arms import _log as arms_log
from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.util.genai.data import (AttributeValue, EmbeddingRequestAttributes,
                                    EmbeddingResponseAttributes,
                                    LLMRequestAttributes,
                                    LLMResponseAttributes,
                                    RerankerRequestAttributes,
                                    RerankerResponseAttributes,
                                    ToolRequestAttributes,
                                    ToolResponseAttributes)
from aliyun.opentelemetry import _logs, metrics, trace
from aliyun.opentelemetry._logs import SeverityNumber
from aliyun.opentelemetry.trace import Span
from aliyun.opentelemetry.util.genai.types import Base64Blob, Blob, Uri

if TYPE_CHECKING:
    from ctyun.opentelemetry.sdk.extension.arms.uploader import Uploader, PreUploader

from ctyun.opentelemetry.sdk.semconv.trace_v2 import LLMAttributes, RerankerAttributes
from .messages import (InputDocuments, InputMessages,
                                        OutputDocuments, OutputMessages,
                                        SystemInstructions, ToolDefinitions)
from .options import GenAITelemetryOptions
from .version import __version__

logger = getLogger(__name__)
class GenAITelemetry:
    """
    GenAI Telemetry 工具类
    
    提供生成式 AI 应用的核心遥测功能：
    1. 创建标准命名的 span
    2. 设置开始阶段的属性
    3. 设置结束阶段的属性
    
    不涉及上下文管理，让调用方完全控制 span 的生命周期和上下文设置。
    """

    def __init__(
        self,
        instrumentation_name: str = "aliyun.util.genai",
        instrumentation_version: str = __version__,
        options: Optional[GenAITelemetryOptions] = None,
        tracer_provider: Optional[trace.TracerProvider] = None,
        meter_provider: Optional[metrics.MeterProvider] = None,
        logger_provider: Optional[_logs.LoggerProvider] = None,
        event_logger_provider: Optional[_logs.LoggerProvider] = None,
        uploader: Optional["Uploader"] = None,
        pre_uploader: Optional["PreUploader"] = None,
    ):
        self._options = options or GenAITelemetryOptions()

        self._tracer = (tracer_provider or trace.get_tracer_provider()).get_tracer(
            instrumenting_module_name=instrumentation_name,
            instrumenting_library_version=instrumentation_version,
        )
        self._meter_provider = meter_provider

        if self._options.should_use_events():
            effective_logger_provider = event_logger_provider or logger_provider or arms_log.get_genai_logger_provider()
            self._logger = effective_logger_provider.get_logger(
                name=instrumentation_name,
                version=instrumentation_version,
            )
        else:
            self._logger = None
        self._uploader: Optional[Uploader] = uploader
        self._pre_uploader: Optional[PreUploader] = pre_uploader

    def _has_uploader(self) -> bool:
        """检查 uploader 和 pre_uploader 是否都可用"""
        return self._uploader is not None and self._pre_uploader is not None

    def _has_multimodal_data(self, messages) -> bool:
        """
        检测消息中是否包含未分离的多模态数据
        
        Args:
            messages: 输入或输出消息
            
        Returns:
            True 如果存在 Base64Blob/Blob/Uri，否则 False
        """
        if not messages or not hasattr(messages, 'messages'):
            return False
        
        for msg in messages.messages:
            for part in msg.parts:
                if isinstance(part, (Base64Blob, Blob, Uri)):
                    return True
        return False

    def _separate_and_upload(
        self,
        span: Span,
        input_messages: Optional[InputMessages] = None,
        output_messages: Optional[OutputMessages] = None,
    ) -> None:
        """
        分离多模态数据并提交上传
        
        会直接修改 messages 中的 parts，将 Base64Blob/Blob 替换为 Uri。
        
        Args:
            span: 当前 Span（用于获取 span_context 和 start_time）
            input_messages: 输入消息（可选）
            output_messages: 输出消息（可选）
        """
        # 获取 span 上下文和开始时间
        # span.start_time 是 ReadableSpan 的公开 @property，返回 _start_time
        span_context = span.get_span_context() if span else None
        start_time_ns = span.start_time if span and hasattr(span, 'start_time') else time.time_ns()
        
        try:
            # 调用 pre_upload 进行分离（会直接修改 messages）
            # pre_upload 接收 List，需要传入 .messages
            input_list = input_messages.messages if input_messages else None
            output_list = output_messages.messages if output_messages else None
            upload_items = self._pre_uploader.pre_upload(
                span_context,
                start_time_ns,
                input_list,
                output_list,
            )
            
            # 提交异步上传
            for item in upload_items:
                self._uploader.upload(item)
        except Exception as e:
            logger.warning(f"Failed to separate and upload multi-modal data: {e}")
            pass

    def _generate_llm_span_name(self, request_info: LLMRequestAttributes) -> str:
        """
        生成 LLM span 名称，格式: {gen_ai.operation.name} {gen_ai.request.model}
        """
        operation_name = "unknown_operation"
        if request_info.operation_name:
            if hasattr(request_info.operation_name, 'value'):
                operation_name = request_info.operation_name.value
            else:
                operation_name = str(request_info.operation_name)

        model_name = request_info.request_model or "unknown_model"
        return f"{operation_name} {model_name}"

    def _generate_embedding_span_name(self, request_info: EmbeddingRequestAttributes) -> str:
        """
        生成 Embedding span 名称，格式: {gen_ai.operation.name} {gen_ai.request.model}
        """
        operation_name = "unknown_operation"
        if request_info.operation_name:
            if hasattr(request_info.operation_name, 'value'):
                operation_name = request_info.operation_name.value
            else:
                operation_name = str(request_info.operation_name)

        model_name = request_info.request_model or "unknown_model"
        return f"{operation_name} {model_name}"

    def _generate_tool_span_name(self, request_info: ToolRequestAttributes) -> str:
        """
        生成 Tool span 名称，格式: execute_tool {gen_ai.tool.name}
        """
        tool_name = request_info.tool_name or "unknown_tool"
        return f"execute_tool {tool_name}"

    def _generate_reranker_span_name(self, request_info: RerankerRequestAttributes) -> str:
        """
        生成 Reranker span 名称，格式: rerank {reranker.model_name}
        """
        model_name = request_info.model_name or "unknown_model"
        return f"rerank {model_name}"

    def create_llm_span(self, request_info: LLMRequestAttributes) -> Span:
        """
        创建 LLM span（不设置属性，不管理上下文）
        
        Args:
            request_info: LLM 请求信息，用于生成 span 名称
            
        Returns:
            新创建的 span，调用方负责所有后续管理
        """
        span_name = self._generate_llm_span_name(request_info)
        return self._tracer.start_span(span_name)

    def set_llm_start_attributes(
        self,
        span: Span,
        request_info: LLMRequestAttributes,
        input_messages: InputMessages,
        system_instructions: Optional[SystemInstructions] = None,
        tool_definitions: Optional[ToolDefinitions] = None,
    ) -> None:
        """
        在指定 span 上设置 LLM 开始属性
        
        Args:
            span: 目标 span
            request_info: LLM 请求信息
            input_messages: 输入消息
            system_instructions: 系统指令（可选）
            tool_definitions: 工具定义（可选）
        """
        self._apply_llm_start_attributes(span, request_info, input_messages, system_instructions, tool_definitions)

    def _apply_llm_start_attributes(
        self,
        span: Span,
        request_info: LLMRequestAttributes,
        input_messages: InputMessages,
        system_instructions: Optional[SystemInstructions] = None,
        tool_definitions: Optional[ToolDefinitions] = None,
    ) -> None:
        """
        应用 LLM 开始阶段的属性到 span
        """
        span_attributes = request_info.get_span_attributes()
        for key, value in span_attributes.items():
            span.set_attribute(key, value)

        # 记录 input attributes
        if not self._options.should_use_events() and self._options.should_capture_content():
            self._record_input_as_attributes(span, input_messages, system_instructions, tool_definitions)

    def set_llm_end_attributes(
        self,
        span: Span,
        request_info: LLMRequestAttributes,
        input_messages: InputMessages,
        response_info: Optional[LLMResponseAttributes] = None,
        output_messages: Optional[OutputMessages] = None,
        system_instructions: Optional[SystemInstructions] = None,
        tool_definitions: Optional[ToolDefinitions] = None,
    ) -> None:
        """
        在指定 span 上设置 LLM 结束属性
        
        Args:
            span: 目标 span
            request_info: LLM 请求信息
            input_messages: 输入消息
            response_info: LLM 响应信息（可选）
            output_messages: 输出消息（可选）
            system_instructions: 系统指令（可选）
            tool_definitions: 工具定义（可选）
        """
        if response_info:
            span_attributes = response_info.get_span_attributes()
            for key, value in span_attributes.items():
                span.set_attribute(key, value)

        if self._options.should_capture_content():
            if self._options.should_use_events():
                self._record_input_output_as_event(span, request_info, input_messages, response_info, output_messages, system_instructions, tool_definitions)
            else:
                self._record_output_as_attributes(span, output_messages)

        # 提取并设置多模态资源
        input_multimodal_metadata, output_multimodal_metadata = _extract_multimodal_metadata(input_messages, output_messages)
        if input_multimodal_metadata:
            span.set_attribute(
                LLMAttributes.GEN_AI_INPUT_MULTIMODAL_METADATA,
                _safe_json_dumps(input_multimodal_metadata)
            )
        if output_multimodal_metadata:
            span.set_attribute(
                LLMAttributes.GEN_AI_OUTPUT_MULTIMODAL_METADATA,
                _safe_json_dumps(output_multimodal_metadata)
            )

    def create_embedding_span(self, request_info: EmbeddingRequestAttributes) -> Span:
        """
        创建 Embedding span（不设置属性，不管理上下文）
        
        Args:
            request_info: Embedding 请求信息，用于生成 span 名称
            
        Returns:
            新创建的 span，调用方负责所有后续管理
        """
        span_name = self._generate_embedding_span_name(request_info)
        return self._tracer.start_span(span_name)

    def set_embedding_start_attributes(
        self,
        span: Span,
        request_info: EmbeddingRequestAttributes,
        input_messages: Optional[InputMessages] = None,
    ) -> None:
        """
        在指定 span 上设置 Embedding 开始属性
        
        Args:
            span: 目标 span
            request_info: Embedding 请求信息
            input_messages: 输入消息列表（使用 InputMessages.messages，每个消息的 role 为 user）
        """
        self._apply_embedding_start_attributes(span, request_info, input_messages)

    def _apply_embedding_start_attributes(
        self,
        span: Span,
        request_info: EmbeddingRequestAttributes,
        input_messages: Optional[InputMessages] = None,
    ) -> None:
        """
        应用 Embedding 开始阶段的属性到 span
        """
        span_attributes = request_info.get_span_attributes()
        for key, value in span_attributes.items():
            span.set_attribute(key, value)

        # 记录 input attributes
        if not self._options.should_use_events() and self._options.should_capture_content():
            self._record_embedding_input_as_attributes(span, input_messages)

    def set_embedding_end_attributes(
        self,
        span: Span,
        request_info: EmbeddingRequestAttributes,
        input_messages: Optional[InputMessages] = None,
        response_info: Optional[EmbeddingResponseAttributes] = None,
    ) -> None:
        """
        在指定 span 上设置 Embedding 结束属性
        
        Args:
            span: 目标 span
            request_info: Embedding 请求信息
            input_messages: 输入消息列表（使用 InputMessages.messages，每个消息的 role 为 user）
            response_info: Embedding 响应信息（可选）
        """
        if response_info:
            span_attributes = response_info.get_span_attributes()
            for key, value in span_attributes.items():
                span.set_attribute(key, value)

        if self._options.should_capture_content():
            if self._options.should_use_events():
                self._record_embedding_input_as_event(span, request_info, input_messages, response_info)

    def create_tool_span(self, request_info: ToolRequestAttributes) -> Span:
        """
        创建 Tool span（不设置属性，不管理上下文）
        
        Args:
            request_info: Tool 请求信息，用于生成 span 名称
            
        Returns:
            新创建的 span，调用方负责所有后续管理
        """
        span_name = self._generate_tool_span_name(request_info)
        return self._tracer.start_span(span_name)

    def set_tool_start_attributes(
        self,
        span: Span,
        request_info: ToolRequestAttributes,
    ) -> None:
        """
        在指定 span 上设置 Tool 开始属性
        
        Args:
            span: 目标 span
            request_info: Tool 请求信息
        """
        self._apply_tool_start_attributes(span, request_info)

    def _apply_tool_start_attributes(
        self,
        span: Span,
        request_info: ToolRequestAttributes,
    ) -> None:
        """
        应用 Tool 开始阶段的属性到 span
        """
        span_attributes = request_info.get_span_attributes()
        for key, value in span_attributes.items():
            span.set_attribute(key, value)

    def set_tool_end_attributes(
        self,
        span: Span,
        request_info: ToolRequestAttributes,
        response_info: Optional[ToolResponseAttributes] = None,
    ) -> None:
        """
        在指定 span 上设置 Tool 结束属性
        
        Args:
            span: 目标 span
            request_info: Tool 请求信息
            response_info: Tool 响应信息（可选）
        """
        if response_info:
            span_attributes = response_info.get_span_attributes()
            for key, value in span_attributes.items():
                span.set_attribute(key, value)

    def create_reranker_span(self, request_info: RerankerRequestAttributes) -> Span:
        """
        创建 Reranker span（不设置属性，不管理上下文）
        
        Args:
            request_info: Reranker 请求信息，用于生成 span 名称
            
        Returns:
            新创建的 span，调用方负责所有后续管理
        """
        span_name = self._generate_reranker_span_name(request_info)
        return self._tracer.start_span(span_name)

    def set_reranker_start_attributes(
        self,
        span: Span,
        request_info: RerankerRequestAttributes,
        input_documents: Optional[InputDocuments] = None,
    ) -> None:
        """
        在指定 span 上设置 Reranker 开始属性
        
        Args:
            span: 目标 span
            request_info: Reranker 请求信息
            input_documents: 输入文档列表（可选）
        """
        self._apply_reranker_start_attributes(span, request_info, input_documents)

    def _apply_reranker_start_attributes(
        self,
        span: Span,
        request_info: RerankerRequestAttributes,
        input_documents: Optional[InputDocuments] = None,
    ) -> None:
        """
        应用 Reranker 开始阶段的属性到 span
        """
        span_attributes = request_info.get_span_attributes()
        for key, value in span_attributes.items():
            span.set_attribute(key, value)

        # 记录输入文档
        if self._options.should_capture_content() and input_documents and len(input_documents.documents) > 0:
            processed_documents = input_documents.to_serializable_object(self._options.truncate_tool)
            span.set_attribute(RerankerAttributes.RERANKER_INPUT_DOCUMENT, _safe_json_dumps(processed_documents))

    def set_reranker_end_attributes(
        self,
        span: Span,
        request_info: RerankerRequestAttributes,
        response_info: Optional[RerankerResponseAttributes] = None,
        output_documents: Optional[OutputDocuments] = None,
    ) -> None:
        """
        在指定 span 上设置 Reranker 结束属性
        
        Args:
            span: 目标 span
            request_info: Reranker 请求信息
            response_info: Reranker 响应信息（可选）
            output_documents: 输出文档列表（可选）
        """
        if response_info:
            span_attributes = response_info.get_span_attributes()
            for key, value in span_attributes.items():
                span.set_attribute(key, value)

        # 记录输出文档
        if self._options.should_capture_content() and output_documents and len(output_documents.documents) > 0:
            processed_documents = output_documents.to_serializable_object(self._options.truncate_tool)
            span.set_attribute(RerankerAttributes.RERANKER_OUTPUT_DOCUMENT, _safe_json_dumps(processed_documents))

    # LLM 相关方法

    def _record_input_output_as_event(
        self,
        span: Span,
        request_info: LLMRequestAttributes,
        input_messages: InputMessages,
        response_info: Optional[LLMResponseAttributes] = None,
        output_messages: Optional[OutputMessages] = None,
        system_instructions: Optional[SystemInstructions] = None,
        tool_definitions: Optional[ToolDefinitions] = None,
    ) -> None:
        """
        将输入和输出消息作为一个事件记录
        """
        if not self._logger:
            return

        # 序列化前检测并分离多模态数据
        # 先检查 uploader 可用性（O(1)），再遍历检测多模态数据
        if self._has_uploader():
            has_input_multimodal = self._has_multimodal_data(input_messages)
            has_output_multimodal = self._has_multimodal_data(output_messages)
            
            if has_input_multimodal or has_output_multimodal:
                self._separate_and_upload(
                    span,
                    input_messages=input_messages if has_input_multimodal else None,
                    output_messages=output_messages if has_output_multimodal else None,
                )

        if span is not None and span.get_span_context() is not None:
            trace_id = trace.format_trace_id(span.get_span_context().trace_id)
            span_id = trace.format_span_id(span.get_span_context().span_id)
            trace_flags = repr(span.get_span_context().trace_flags)
        else:
            trace_id = None
            span_id = None
            trace_flags = None

        # for LLM event
        event_attributes: dict[str, AttributeValue] = {
            "event.name": "gen_ai.client.inference.operation.details",
        }

        if request_info:
            event_attributes.update(request_info.get_event_attributes())

        if response_info:
            event_attributes.update(response_info.get_event_attributes())

        if input_messages and len(input_messages.messages) > 0:
            processed_input_messages = input_messages.to_serializable_object(self._options.truncate_tool)
            event_attributes[LLMAttributes.GEN_AI_INPUT_MESSAGES] = _safe_json_dumps(processed_input_messages)

        if output_messages and len(output_messages.messages) > 0:
            processed_output_messages = output_messages.to_serializable_object(self._options.truncate_tool)
            event_attributes[LLMAttributes.GEN_AI_OUTPUT_MESSAGES] = _safe_json_dumps(processed_output_messages)

        if system_instructions and len(system_instructions.parts) > 0:
            processed_system_instructions = system_instructions.to_serializable_object(self._options.truncate_tool)
            event_attributes[LLMAttributes.GEN_AI_SYSTEM_INSTRUCTIONS] = _safe_json_dumps(processed_system_instructions)

        if tool_definitions and len(tool_definitions.definitions) > 0:
            processed_tool_definitions = tool_definitions.to_serializable_object()
            event_attributes[LLMAttributes.GEN_AI_TOOL_DEFINITIONS] = _safe_json_dumps(processed_tool_definitions)

        self._logger.emit(
            _logs.LogRecord(
                timestamp=int(time.time() * 1e9),
                observed_timestamp=int(time.time() * 1e9),
                trace_id=trace_id,
                span_id=span_id,
                trace_flags=trace_flags,
                severity_number=SeverityNumber.UNSPECIFIED,
                body=None,
                attributes=event_attributes
            )
        )

    def _record_input_as_attributes(
        self, 
        span: Span, 
        input_messages: InputMessages,
        system_instructions: Optional[SystemInstructions] = None,
        tool_definitions: Optional[ToolDefinitions] = None,
    ) -> None:
        """
        将输入消息、系统指令和工具定义作为 span 属性记录
        """
        # 序列化前检测并分离多模态数据
        if self._has_uploader() and self._has_multimodal_data(input_messages):
            self._separate_and_upload(span, input_messages=input_messages)
        
        if input_messages and len(input_messages.messages) > 0:
            processed_messages = input_messages.to_serializable_object(self._options.truncate_tool)
            span.set_attribute(LLMAttributes.GEN_AI_INPUT_MESSAGES, _safe_json_dumps(processed_messages))

        if system_instructions and len(system_instructions.parts) > 0:
            instructions_dict = system_instructions.to_serializable_object(self._options.truncate_tool)
            span.set_attribute(LLMAttributes.GEN_AI_SYSTEM_INSTRUCTIONS, _safe_json_dumps(instructions_dict))

        if tool_definitions and len(tool_definitions.definitions) > 0:
            tools_dict = tool_definitions.to_serializable_object()
            span.set_attribute(LLMAttributes.GEN_AI_TOOL_DEFINITIONS, _safe_json_dumps(tools_dict))

    def _record_output_as_attributes(self, span: Span, output_messages: Optional[OutputMessages] = None) -> None:
        """
        将输出消息作为 span 属性记录
        """
        if not output_messages:
            return
        
        # 序列化前检测并分离多模态数据
        if self._has_uploader() and self._has_multimodal_data(output_messages):
            self._separate_and_upload(span, output_messages=output_messages)
        
        processed_messages = output_messages.to_serializable_object(self._options.truncate_tool)
        messages_json = _safe_json_dumps(processed_messages)
        span.set_attribute(LLMAttributes.GEN_AI_OUTPUT_MESSAGES, messages_json)

    # Embedding 相关方法

    def _record_embedding_input_as_attributes(
        self, 
        span: Span, 
        input_messages: Optional[InputMessages] = None,
    ) -> None:
        """
        将 embedding 输入文本作为 span 属性记录
        
        Args:
            span: 目标 span
            input_messages: 输入消息列表（使用 InputMessages.messages，每个消息的 role 为 user）
        """
        # 序列化前检测并分离多模态数据
        if self._has_uploader() and self._has_multimodal_data(input_messages):
            self._separate_and_upload(span, input_messages=input_messages)
        
        if input_messages and len(input_messages.messages) > 0:
            processed_messages = input_messages.to_serializable_object(self._options.truncate_tool)
            span.set_attribute(LLMAttributes.GEN_AI_INPUT_MESSAGES, _safe_json_dumps(processed_messages))

    def _record_embedding_input_as_event(
        self,
        span: Span,
        request_info: EmbeddingRequestAttributes,
        input_messages: Optional[InputMessages] = None,
        response_info: Optional[EmbeddingResponseAttributes] = None,
    ) -> None:
        """
        将 embedding 输入输出作为事件记录
        
        Args:
            span: 目标 span
            request_info: Embedding 请求信息
            input_messages: 输入消息列表（使用 InputMessages.messages，每个消息的 role 为 user）
            response_info: Embedding 响应信息
        """
        if not self._logger:
            return

        # 序列化前检测并分离多模态数据
        if self._has_uploader() and self._has_multimodal_data(input_messages):
            self._separate_and_upload(span, input_messages=input_messages)

        if span is not None and span.get_span_context() is not None:
            trace_id = trace.format_trace_id(span.get_span_context().trace_id)
            span_id = trace.format_span_id(span.get_span_context().span_id)
            trace_flags = repr(span.get_span_context().trace_flags)
        else:
            trace_id = None
            span_id = None
            trace_flags = None

        # for Embedding event
        event_attributes: dict[str, AttributeValue] = {
            "event.name": "gen_ai.client.embedding.operation.details",
        }

        if request_info:
            event_attributes.update(request_info.get_event_attributes())

        if response_info:
            event_attributes.update(response_info.get_event_attributes())

        if input_messages and len(input_messages.messages) > 0:
            processed_messages = input_messages.to_serializable_object(self._options.truncate_tool)
            event_attributes[LLMAttributes.GEN_AI_INPUT_MESSAGES] = _safe_json_dumps(processed_messages)

        self._logger.emit(
            _logs.LogRecord(
                timestamp=int(time.time() * 1e9),
                observed_timestamp=int(time.time() * 1e9),
                trace_id=trace_id,
                span_id=span_id,
                trace_flags=trace_flags,
                severity_number=SeverityNumber.UNSPECIFIED,
                body=None,
                attributes=event_attributes
            )
        )

def _safe_json_dumps(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, separators=(',', ':'))


def _extract_uri_metadata_from_messages(messages:Union[InputMessages, OutputMessages, None]) -> List[Dict[str, str]]:
    """
    从消息列表中提取 Uri 元数据的辅助函数
    
    Args:
        messages: InputMessages 或 OutputMessages 对象
        
    Returns:
        元数据列表，每个元素格式为:
        {"type": "uri", "mime_type": "image/jpeg", "uri": "sls://...", "modality": "image"}
    """
    metadata: List[Dict[str, str]] = []
    if not messages or not messages.messages:
        return metadata
    for msg in messages.messages:
        if not msg.parts:
            continue
        for part in msg.parts:
            if isinstance(part, Uri):
                metadata.append({
                    "type": "uri",
                    "mime_type": part.mime_type,
                    "uri": part.uri,
                    "modality": part.modality,
                })
    return metadata


def _extract_multimodal_metadata(
    input_messages: Optional[InputMessages],
    output_messages: Optional[OutputMessages],
) -> Tuple[List[Dict[str, str]], List[Dict[str, str]]]:
    """
    从消息中提取多模态元数据（仅 Uri 类型）
    
    只有在执行了 separate_multimodal_data_and_upload 后，消息中的多模态数据
    才会被替换为 Uri，此时才需要记录 gen_ai.input.multimodal_metadata 和 gen_ai.output.multimodal_metadata。
    
    Args:
        input_messages: 输入消息
        output_messages: 输出消息
        
    Returns:
        多模态元数据列表，每个元素格式为:
        {"type": "uri", "mime_type": "image/jpeg", "uri": "sls://...", "modality": "image"}
    """
    return (
        _extract_uri_metadata_from_messages(input_messages),
        _extract_uri_metadata_from_messages(output_messages),
    )

def _is_data_url(url: str) -> bool:
    return url.startswith("data:") and "," in url

def _parse_data_url(url: str) -> Tuple[str, str]:
    header, b64 = url.split(",", 1)
    mime_part = header[5:]
    if ";" in mime_part:
        mime, _ = mime_part.split(";", 1)
    else:
        mime = mime_part
    return mime, b64
