# limon-sdk

The library provides integration with the limon service.

## Install

```shell
pip install limon
```

## Example

```python
import limon

limon.init("<your token>")
```
