from typing import TYPE_CHECKING

from . import metrics
from .config import Config, DEFAULT_RELEASE, DEFAULT_METRICS_EXPORT_INTERVAL
from .errors import SdkNotInitializedError

if TYPE_CHECKING:
    from typing import Optional

__config: "Optional[Config]" = None


def init(
    sdk_token: str,
    *,
    collector: str,
    release: str = DEFAULT_RELEASE,
    debug: bool = False,
    enable_metrics: bool = True,
    enable_system_metrics: bool = True,
    metrics_export_interval_millis: int = DEFAULT_METRICS_EXPORT_INTERVAL,
):
    """Initialization of the library and all necessary resources."""

    global __config

    __config = Config(
        sdk_token=sdk_token,
        collector=collector,
        release=release,
        debug=debug,
        metrics_enabled=enable_metrics,
        system_metrics_enabled=enable_metrics and enable_system_metrics,
        metrics_export_interval_millis=metrics_export_interval_millis,
    )

    if enable_metrics:
        metrics.setup()


def cleanup():
    """Clearing all resources used by the library."""

    global __config

    if __config:
        __config = None


def get_config() -> "Config":
    """Get the config instance used by the library."""

    if __config is None:
        raise SdkNotInitializedError()

    return __config
