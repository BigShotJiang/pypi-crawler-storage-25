from dataclasses import dataclass

DEFAULT_RELEASE = "unknown"
DEFAULT_METRICS_EXPORT_INTERVAL = 60_000


@dataclass(init=True, slots=True)
class Config:
    sdk_token: str
    collector: str
    release: str
    debug: bool
    metrics_enabled: bool
    system_metrics_enabled: bool
    metrics_export_interval_millis: int
