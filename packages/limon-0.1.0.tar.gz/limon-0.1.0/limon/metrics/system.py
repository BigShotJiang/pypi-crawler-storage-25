from typing import TYPE_CHECKING

import psutil
from opentelemetry import metrics
from opentelemetry.metrics import Observation

if TYPE_CHECKING:
    from typing import Iterable


class Sysinfo:
    """Collecting system metrics such as CPU and RAM."""

    @staticmethod
    def cpu_observable(
        _: "metrics.CallbackOptions",
    ) -> "Iterable[Observation]":
        """CPU load in percentage across all cores."""

        for core, percentage in enumerate(
            psutil.cpu_percent(interval=None, percpu=True)
        ):
            yield Observation(value=float(percentage), attributes={"core": core})

    @staticmethod
    def memory_usage_observable(
        _: "metrics.CallbackOptions",
    ) -> "Iterable[Observation]":
        """Amount of used RAM in bytes."""

        yield Observation(value=psutil.virtual_memory().used)

    @staticmethod
    def memory_total_observable(
        _: "metrics.CallbackOptions",
    ) -> "Iterable[Observation]":
        """Amount of total RAM in bytes."""

        yield Observation(value=psutil.virtual_memory().total)
