from importlib.metadata import version

from opentelemetry import metrics
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
from opentelemetry.sdk.resources import Resource


def setup():
    from ..core import get_config

    config = get_config()

    resource = Resource.create(
        {
            "service.release": config.release,
            "telemetry.sdk.name": "limon",
            "telemetry.sdk.language": "python",
            "telemetry.sdk.version": version("limon"),
        }
    )

    exporter = OTLPMetricExporter(
        endpoint=config.collector,
        headers={"authorization": f"Bearer {config.sdk_token}"},
    )

    reader = PeriodicExportingMetricReader(
        exporter, export_interval_millis=config.metrics_export_interval_millis
    )

    metrics.set_meter_provider(
        MeterProvider(resource=resource, metric_readers=[reader])
    )

    if config.system_metrics_enabled:
        from .system import Sysinfo

        meter = metrics.get_meter("limon.runtime")
        meter.create_observable_gauge(
            "system.cpu.usage",
            callbacks=[Sysinfo.cpu_observable],
            unit="%",
            description="CPU load in percentage across all cores",
        )
        meter.create_observable_gauge(
            "system.memory.usage",
            callbacks=[Sysinfo.memory_usage_observable],
            unit="By",
            description="Amount of used RAM in bytes",
        )
        meter.create_observable_gauge(
            "system.memory.total",
            callbacks=[Sysinfo.memory_total_observable],
            unit="By",
            description="Amount of total RAM in bytes",
        )
