"""
Limon is a lightweight observability toolkit.

The library provides primitives for integrating observability into
projects by creating abstractions over opentelemetry.

It is designed to be minimal, easy to integrate, and flexible enough
to plug into existing infrastructure.

Example:

    >>> import limon
    >>> limon.init("<your token>")
"""

from . import errors
from .core import init

__version__ = "0.1.0"
__all__ = (
    "errors",
    "init",
)
