class Error(Exception):
    message = "limon sdk error"


class SdkNotInitializedError(Error, RuntimeError):
    message = "SDK not initialized, please call limon.init('<your token>')."
