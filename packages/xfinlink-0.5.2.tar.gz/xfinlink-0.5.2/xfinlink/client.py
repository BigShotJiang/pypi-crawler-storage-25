"""HTTP client for the xfinlink API.

    import xfinlink as xfl
    df = xfl.prices("AAPL", start="2020-01-01", end="2024-12-31")
    df = xfl.fundamentals("AAPL", period_type="annual")
"""
from __future__ import annotations

import httpx
import pandas as pd

API_BASE = "https://api.xfinlink.com"
_TIMEOUT = 30.0


def set_api_base(url: str) -> None:
    """Override the API base URL. Useful for local testing."""
    global API_BASE
    API_BASE = url.rstrip("/")


def _request(endpoint: str, params: dict) -> dict:
    """GET with automatic cursor-based pagination."""
    from xfinlink import __version__

    headers = {"User-Agent": f"xfinlink-python/{__version__}"}
    all_data: list = []
    meta: dict = {}

    while True:
        resp = httpx.get(
            f"{API_BASE}/v1/{endpoint}",
            params=params,
            headers=headers,
            timeout=_TIMEOUT,
        )

        if resp.status_code == 404:
            body = resp.json()
            raise ValueError(body.get("detail", body.get("error", "Not found")))
        if 400 <= resp.status_code < 500:
            body = resp.json()
            raise ValueError(body.get("detail", body.get("error", str(resp.status_code))))
        if resp.status_code >= 500:
            raise RuntimeError(f"API error {resp.status_code}: {resp.text}")

        body = resp.json()
        all_data.extend(body["data"])
        meta = body.get("meta", {})

        if not meta.get("has_more") or not meta.get("next_cursor"):
            break

        params = dict(params)
        params["cursor"] = meta["next_cursor"]

    meta["count"] = len(all_data)
    meta["has_more"] = False
    meta["next_cursor"] = None
    return {"data": all_data, "meta": meta}


def _request_single(endpoint: str, params: dict) -> dict:
    """GET without pagination (for endpoints that don't paginate)."""
    from xfinlink import __version__

    headers = {"User-Agent": f"xfinlink-python/{__version__}"}
    resp = httpx.get(
        f"{API_BASE}/v1/{endpoint}",
        params=params,
        headers=headers,
        timeout=_TIMEOUT,
    )

    if resp.status_code == 404:
        body = resp.json()
        raise ValueError(body.get("detail", body.get("error", "Not found")))
    if 400 <= resp.status_code < 500:
        body = resp.json()
        raise ValueError(body.get("detail", body.get("error", str(resp.status_code))))
    if resp.status_code >= 500:
        raise RuntimeError(f"API error {resp.status_code}: {resp.text}")

    return resp.json()


def status() -> dict:
    """Check API health. Returns dict with status, version, and table counts."""
    from xfinlink import __version__

    resp = httpx.get(
        f"{API_BASE}/v1/status",
        headers={"User-Agent": f"xfinlink-python/{__version__}"},
        timeout=_TIMEOUT,
    )
    resp.raise_for_status()
    return resp.json()


def prices(
    ticker: str | list[str],
    start: str | None = None,
    end: str | None = None,
    fields: list[str] | str | None = None,
    adjust: str = "split",
    limit: int = 5000,
) -> pd.DataFrame:
    """Get historical price data.

    Args:
        ticker: Single ticker ("AAPL") or list (["AAPL", "MSFT"]).
        start: Start date (YYYY-MM-DD).
        end: End date (YYYY-MM-DD).
        fields: Specific fields to return (default: all).
        adjust: "split" (default) or "none".
        limit: Rows per API page (default/max: 5000).

    Returns:
        DataFrame with date, open, high, low, close, volume, etc.

    Examples:
        >>> df = xfl.prices("AAPL", start="2024-01-01", end="2024-12-31")
        >>> df = xfl.prices(["AAPL", "MSFT"], start="2024-01-01")
        >>> df = xfl.prices("GM", start="2008-01-01", end="2012-12-31")
    """
    if isinstance(fields, str):
        fields = [fields]
    ticker_str = ",".join(ticker) if isinstance(ticker, list) else ticker
    params: dict = {"limit": limit, "adjust": adjust}
    if start:
        params["start"] = start
    if end:
        params["end"] = end
    if fields:
        params["fields"] = ",".join(fields)

    result = _request(f"prices/{ticker_str}", params)

    if not result["data"]:
        return pd.DataFrame()

    df = pd.DataFrame(result["data"])
    if "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values(["ticker", "date"]).reset_index(drop=True)
    if "date" in df.columns:
        df = df.set_index("date")
    return df


def fundamentals(
    ticker: str | list[str],
    start: str | None = None,
    end: str | None = None,
    period_type: str = "all",
    version: str = "restated",
    fields: list[str] | str | None = None,
    period_only: bool = False,
    limit: int = 5000,
) -> pd.DataFrame:
    """Get financial statement data.

    Args:
        ticker: Single ticker ("AAPL") or list (["AAPL", "MSFT"]).
        start: Start date for period_end (YYYY-MM-DD).
        end: End date for period_end (YYYY-MM-DD).
        period_type: "quarterly", "annual", or "all" (default).
        version: "restated" (default), "original", or "all".
        fields: Specific fields. E.g. ["revenue", "net_income"].
        period_only: De-cumulate YTD cash flows to single-quarter values.
        limit: Rows per API page (default/max: 5000).

    Returns:
        DataFrame with period_end, revenue, net_income, total_assets, etc.

    Examples:
        >>> df = xfl.fundamentals("AAPL", period_type="annual")
        >>> df = xfl.fundamentals("AAPL", fields=["revenue", "net_income"])
        >>> df = xfl.fundamentals(["AAPL", "MSFT"], period_type="annual", start="2020-01-01")
    """
    if isinstance(fields, str):
        fields = [fields]
    ticker_str = ",".join(ticker) if isinstance(ticker, list) else ticker
    params: dict = {"limit": limit, "period_type": period_type, "version": version}
    if start:
        params["start"] = start
    if end:
        params["end"] = end
    if fields:
        params["fields"] = ",".join(fields)
    if period_only:
        params["period_only"] = "true"

    result = _request(f"fundamentals/{ticker_str}", params)

    if not result["data"]:
        return pd.DataFrame()

    df = pd.DataFrame(result["data"])
    if "period_end" in df.columns:
        df["period_end"] = pd.to_datetime(df["period_end"])
    if "filing_date" in df.columns:
        df["filing_date"] = pd.to_datetime(df["filing_date"])
    df = df.sort_values(["ticker", "period_end"]).reset_index(drop=True)
    if "period_end" in df.columns:
        df = df.set_index("period_end")
    return df


def resolve(
    ticker: str | list[str],
    include: list[str] | None = None,
) -> dict:
    """Get entity resolution and history for a ticker.

    Args:
        ticker: Single ticker ("GM") or list (["GM", "AAPL"]).
        include: Sections to include: ["events", "index", "classifications"].
                 Default: all sections.

    Returns:
        Dict with entity history, corporate events, index membership,
        and classifications grouped by ticker.

    Examples:
        >>> info = xfl.resolve("GM")
        >>> info["data"]["GM"]["entities"]
        >>> info = xfl.resolve("AAPL", include=["classifications"])
    """
    ticker_str = ",".join(ticker) if isinstance(ticker, list) else ticker
    params: dict = {}
    if include:
        params["include"] = ",".join(include)
    return _request_single(f"resolve/{ticker_str}", params)


def llm_context() -> str:
    """Return LLM context block for vibe coding with xfinlink."""
    text = """\
# xfinlink — Free US Financial Data API
Base URL: https://api.xfinlink.com
No API key required.

IMPORTANT: Read this entire file before writing any xfinlink code.

## Endpoints

GET /v1/prices/{ticker}?start=YYYY-MM-DD&end=YYYY-MM-DD
GET /v1/fundamentals/{ticker}?period_type=annual|quarterly&start=YYYY-MM-DD&end=YYYY-MM-DD
GET /v1/resolve/{ticker}?include=events,classifications,index

Multi-ticker: /v1/prices/AAPL,MSFT,GOOGL

## Python Client

pip install xfinlink

import xfinlink as xfl
df = xfl.prices("AAPL", start="2024-01-01", end="2024-12-31")
df = xfl.fundamentals("AAPL", period_type="annual")
info = xfl.resolve("GM")

prices() and fundamentals() return pandas DataFrames with DatetimeIndex.
fields parameter accepts a string or list: fields="close" or fields=["close","volume"]

## Example Output

xfl.prices("AAPL", start="2025-01-02", end="2025-01-02", fields=["close","volume"])
→ DataFrame with DatetimeIndex:
            entity_id ticker entity_name            gics_sector   close    volume
date
2025-01-02          1   AAPL   Apple Inc  Information Technology  243.85  55740700

xfl.fundamentals("AAPL", period_type="annual", fields=["revenue","net_income","eps_diluted"])
→ DataFrame with DatetimeIndex:
            entity_id ticker entity_name            gics_sector  revenue  net_income  eps_diluted
period_end
2024-09-28          1   AAPL   Apple Inc  Information Technology   391035       93736         6.08

## CRITICAL: Units and Scale

- All monetary fields (revenue, net_income, total_assets, operating_cash_flow, etc.): float, MILLIONS USD
- eps_basic, eps_diluted, dividends_per_share: float, dollars per share (NOT millions)
- shares_outstanding, weighted_avg_shares_basic, weighted_avg_shares_diluted: float, MILLIONS (in fundamentals)
- shares_outstanding in PRICES endpoint: int, raw share count (NOT millions)
- return_daily: float, decimal (0.05 = 5%, NOT 5)
- volume: int, raw shares traded
- sic, naics: str (NOT numeric)

## Prices Fields (12)
open (float, USD), high (float, USD), low (float, USD), close (float, USD), adj_close (float, USD), volume (int, shares), return_daily (float, decimal), shares_outstanding (int, raw count), exchange_code (str), split_ratio (float), dividend (float, USD)
Plus structural: entity_id (int), ticker (str), entity_name (str), gics_sector (str)

## Fundamentals Fields (129) — all float in $M unless noted

Income Statement: revenue, cost_of_revenue, cost_of_goods_sold, gross_profit, operating_income, net_income, ebitda, ebit, interest_expense, interest_income, income_tax_expense, research_and_development, selling_general_admin, selling_and_marketing, general_and_admin, stock_based_compensation, depreciation_amortization, depreciation, amortization_intangibles, depletion, restructuring_charges, impairment_charges, provision_for_credit_losses, gain_loss_on_sale_of_assets, operating_expenses_total, pretax_income, other_operating_expenses, other_non_operating_income, income_from_equity_method_investments, income_from_discontinued_operations, minority_interest_income, net_income_attributable_to_parent, preferred_dividends, net_income_available_to_common, comprehensive_income

Per-share (float, $/share): eps_basic, eps_diluted, dividends_per_share

Balance Sheet: cash_and_equivalents, restricted_cash, marketable_securities, short_term_investments, cash_and_short_term_investments, accounts_receivable, contract_assets, inventory, prepaid_expenses, other_current_assets, current_assets_total, property_plant_equipment_gross, accumulated_depreciation, property_plant_equipment_net, operating_lease_assets, finance_lease_assets, long_term_investments, equity_method_investments, goodwill, intangible_assets, deferred_tax_assets, other_noncurrent_assets, total_assets, accounts_payable, short_term_debt, current_portion_long_term_debt, operating_lease_liabilities_current, finance_lease_liabilities_current, deferred_revenue_current, accrued_liabilities, other_current_liabilities, current_liabilities_total, long_term_debt, operating_lease_liabilities_noncurrent, finance_lease_liabilities_noncurrent, deferred_revenue_noncurrent, deferred_tax_liabilities, pension_liabilities, insurance_loss_reserves, other_noncurrent_liabilities, total_liabilities, total_debt, common_stock_value, preferred_equity, additional_paid_in_capital, retained_earnings, treasury_stock, accumulated_other_comprehensive_income, total_equity, minority_interest, total_equity_including_minority

Cash Flow: net_income_cf, depreciation_amortization_cf, stock_based_compensation_cf, deferred_income_taxes, change_in_accounts_receivable, change_in_inventory, change_in_accounts_payable, change_in_working_capital, other_operating_activities, operating_cash_flow, capital_expenditures, acquisitions_net, proceeds_from_divestitures, purchases_of_investments, sales_of_investments, other_investing_activities, investing_cash_flow, long_term_debt_issuance, long_term_debt_repayment, short_term_debt_proceeds, short_term_debt_repayments, finance_lease_principal_payments, share_issuance, share_repurchases, dividends_paid, dividends_paid_common, other_financing_activities, financing_cash_flow, cash_taxes_paid, cash_interest_paid, effect_of_exchange_rate_on_cash, net_change_in_cash, free_cash_flow

Shares (float, millions): shares_outstanding, common_shares_issued, weighted_avg_shares_basic, weighted_avg_shares_diluted, treasury_shares

Metadata (str): sic, naics

## Gotchas — READ CAREFULLY

1. ONE TICKER CAN MAP TO MULTIPLE ENTITIES. Tickers are recycled. When a company goes bankrupt, gets acquired, or delists, its ticker can be reassigned to a completely different company. Always call xfl.resolve(ticker) first to check how many entities exist. Never assume one ticker = one company. Examples: GM (pre/post bankruptcy), DELL (Dell Inc / Dell Technologies).

2. QUARTERLY CASH FLOWS ARE CUMULATIVE, NOT SINGLE-QUARTER. Quarterly operating_cash_flow, investing_cash_flow, financing_cash_flow and all sub-items are year-to-date sums (Q1, Q1+Q2, Q1+Q2+Q3, full year), following SEC reporting convention. To get single-quarter values, subtract the prior quarter's YTD or use period_only=true parameter. This does NOT apply to income statement or balance sheet fields.

3. ALL MONETARY FIELDS ARE ALREADY SCALED. Revenue, net_income, total_assets, and all monetary fundamentals fields are in MILLIONS USD. Do NOT multiply by 1,000,000. EPS and dividends_per_share are in raw dollars per share. Shares fields in fundamentals are in MILLIONS. shares_outstanding in PRICES is raw count (NOT millions).

4. PRICE FIELDS AND FUNDAMENTALS FIELDS ARE ON DIFFERENT BASES. All price fields (open, high, low, close, adj_close) are retroactively adjusted for every stock split that occurred after that date. All fundamentals fields (eps_diluted, dividends_per_share, shares_outstanding, etc.) are as-reported at filing time with NO split adjustment. Do NOT combine them for ratios (P/E, P/B, P/S, dividend yield, market cap from price × shares, etc.) unless you are certain no stock split occurred between the reporting date and today. Safe approach: only combine prices and fundamentals from periods after the company's most recent stock split.

## Rate Limits
300 requests/hour, 200 unique tickers/day, 5-year date range max per request."""
    print(text)
    try:
        import pyperclip
        pyperclip.copy(text)
    except ImportError:
        pass
    return text
