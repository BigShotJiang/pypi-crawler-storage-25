"""Database engine + session factory for xfinlink.

Default: SQLite at ~/.xfinlink/xfinlink.db. No server, no setup.

Advanced (optional): set the DATABASE_URL environment variable to any
SQLAlchemy URL to point xfinlink at a different database. Most users will
never need this.
"""
from __future__ import annotations

import os
from pathlib import Path

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

XFINLINK_HOME = Path(os.environ.get("XFINLINK_HOME", Path.home() / ".xfinlink"))
XFINLINK_HOME.mkdir(parents=True, exist_ok=True)

DEFAULT_SQLITE_PATH = XFINLINK_HOME / "xfinlink.db"
DEFAULT_SQLITE_URL = f"sqlite:///{DEFAULT_SQLITE_PATH}"

DATABASE_URL = os.environ.get("DATABASE_URL") or DEFAULT_SQLITE_URL
IS_SQLITE = DATABASE_URL.startswith("sqlite")

_engine_kwargs: dict = {"future": True}
if IS_SQLITE:
    _engine_kwargs["connect_args"] = {"check_same_thread": False}

engine: Engine = create_engine(DATABASE_URL, **_engine_kwargs)

if IS_SQLITE:
    @event.listens_for(engine, "connect")
    def _sqlite_pragmas(dbapi_conn, _record):
        cur = dbapi_conn.cursor()
        cur.execute("PRAGMA foreign_keys=ON")
        cur.execute("PRAGMA journal_mode=WAL")
        cur.close()

SessionLocal: sessionmaker[Session] = sessionmaker(
    bind=engine, autoflush=False, expire_on_commit=False
)


def sqlite_db_path() -> Path | None:
    """Return the SQLite file path if we're on SQLite, else None."""
    if not IS_SQLITE:
        return None
    return Path(DATABASE_URL.replace("sqlite:///", "", 1))


def create_all() -> None:
    """Create all tables on the current engine (idempotent)."""
    from xfinlink.models import Base

    Base.metadata.create_all(engine)
