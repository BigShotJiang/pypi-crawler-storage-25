"""Panel validation and correction for pandas DataFrames.

Researchers merge financial panels keyed by ticker + date. Because tickers
are recycled (GM pre/post-2009 bankruptcy; FB before Meta rebrand), naive
merges stitch unrelated entities into one row-group. These functions walk
the DataFrame row-by-row, resolve each identifier as-of the row's date, and
either report issues or return a corrected copy with per-row entity columns.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime
from typing import Any

import pandas as pd

from xfinlink._db_check import check_db_ready
from xfinlink.db import SessionLocal
from xfinlink.resolver import core as _core
from xfinlink.resolver.core import ResolvedEntity


@dataclass
class ValidationReport:
    summary: str
    issues: pd.DataFrame
    coverage: dict[str, int]
    is_clean: bool


def _norm_id(v: Any) -> str | None:
    if v is None:
        return None
    if isinstance(v, float) and pd.isna(v):
        return None
    s = str(v).strip()
    return s or None


def _norm_date(v: Any) -> date | None:
    if v is None:
        return None
    if isinstance(v, float) and pd.isna(v):
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    if isinstance(v, pd.Timestamp):
        if pd.isna(v):
            return None
        return v.date()
    if isinstance(v, str):
        s = v.strip()
        if not s:
            return None
        return datetime.strptime(s[:10], "%Y-%m-%d").date()
    try:
        ts = pd.Timestamp(v)
        if pd.isna(ts):
            return None
        return ts.date()
    except Exception:  # noqa: BLE001
        return None


def _try_resolve(session, id_type: str, id_value: str, as_of: date | None):
    try:
        return _core.resolve(session, id_type, id_value, as_of)
    except ValueError:
        return None


def _classify(
    idx,
    iv: str | None,
    d: date | None,
    id_type: str,
    cache_any: dict,
    cache_dated: dict,
) -> dict:
    info = {"idx": idx, "id": iv, "date": d, "flag": "not_found", "detail": "", "entity": None}

    if not iv:
        info["detail"] = "empty id value"
        return info

    r_any = cache_any.get(iv)
    if r_any is None:
        info["detail"] = "invalid id value"
        return info

    if d is not None:
        r_dated = cache_dated.get((iv, d))
        if r_dated is None:
            info["detail"] = "invalid id value"
            return info
        if r_dated.not_found:
            if r_any.not_found:
                info["detail"] = f"{id_type}={iv} not found"
                return info
            info["flag"] = "outside_validity"
            info["detail"] = (
                f"{id_type}={iv} exists but not valid on {d.isoformat()}"
            )
            info["entity"] = r_any.matches[0] if r_any.matches else None
            return info
        if r_dated.ambiguous:
            info["flag"] = "ambiguous"
            names = ", ".join(m.canonical_name for m in r_dated.matches)
            info["detail"] = f"{r_dated.match_count} matches on {d.isoformat()}: {names}"
            info["entity"] = r_dated.matches[0]
            return info
        info["flag"] = "ok"
        info["entity"] = r_dated.matches[0]
        return info

    if r_any.not_found:
        info["detail"] = f"{id_type}={iv} not found"
        return info
    if r_any.ambiguous:
        info["flag"] = "ambiguous"
        names = ", ".join(m.canonical_name for m in r_any.matches)
        info["detail"] = f"{r_any.match_count} matches (undated): {names}"
        info["entity"] = r_any.matches[0]
        return info
    info["flag"] = "ok"
    info["entity"] = r_any.matches[0]
    return info


def _analyze(
    df: pd.DataFrame,
    id_column: str,
    date_column: str | None,
    id_type: str,
) -> list[dict]:
    check_db_ready()

    if id_column not in df.columns:
        raise ValueError(f"id_column {id_column!r} not in DataFrame columns")
    if date_column is not None and date_column not in df.columns:
        raise ValueError(f"date_column {date_column!r} not in DataFrame columns")

    rows: list[tuple] = []
    for idx, r in df.iterrows():
        iv = _norm_id(r[id_column])
        d = _norm_date(r[date_column]) if date_column else None
        rows.append((idx, iv, d))

    ids_all = {iv for _, iv, _ in rows if iv}
    pairs_dated = {(iv, d) for _, iv, d in rows if iv and d is not None}

    with SessionLocal() as s:
        cache_any = {iv: _try_resolve(s, id_type, iv, None) for iv in ids_all}
        cache_dated = {
            (iv, d): _try_resolve(s, id_type, iv, d) for iv, d in pairs_dated
        }

    infos = [_classify(idx, iv, d, id_type, cache_any, cache_dated) for idx, iv, d in rows]

    # Second pass: if a ticker's rows in this panel reference more than
    # one distinct entity (across ok, ambiguous, and outside_validity
    # classifications), every annotated row for that ticker is part of
    # a silent stitching bug — flip them to wrong_entity. We read from
    # the resolver caches directly so we see *all* candidate entities
    # per row, not just the primary.
    span: dict[str, set[int]] = defaultdict(set)
    for _, iv, d in rows:
        if not iv:
            continue
        matches: list = []
        if d is not None:
            r_dated = cache_dated.get((iv, d))
            if r_dated and not r_dated.not_found:
                matches = list(r_dated.matches)
        if not matches:
            r_any = cache_any.get(iv)
            if r_any and not r_any.not_found:
                matches = list(r_any.matches)
        for m in matches:
            span[iv].add(m.entity_id)
    for i in infos:
        if i["entity"] is None:
            continue
        if len(span[i["id"]]) > 1:
            i["flag"] = "wrong_entity"
            i["detail"] = (
                f"{id_type}={i['id']} spans {len(span[i['id']])} entities in this "
                f"panel; row assigned to {i['entity'].canonical_name}"
            )
    return infos


def _pick(entity: ResolvedEntity, id_type: str, as_of: date | None) -> str | None:
    candidates = [i for i in entity.identifiers if i.id_type == id_type]
    if not candidates:
        return None
    candidates.sort(
        key=lambda i: (
            0 if i.valid_to is None else 1,
            -(i.valid_from.toordinal() if i.valid_from else 0),
        )
    )
    return candidates[0].id_value


def validate_dataframe(
    df: pd.DataFrame,
    id_column: str,
    date_column: str | None = None,
    id_type: str = "ticker",
) -> ValidationReport:
    """Scan a DataFrame and report rows whose identifier doesn't match."""
    infos = _analyze(df, id_column, date_column, id_type)

    clean = sum(1 for i in infos if i["flag"] == "ok")
    issues = [i for i in infos if i["flag"] != "ok"]
    issues_df = pd.DataFrame(
        [
            {
                "_row_index": i["idx"],
                "_id_value": i["id"],
                "_date": i["date"],
                "_issue_type": i["flag"],
                "_issue_detail": i["detail"],
            }
            for i in issues
        ]
    )

    coverage: dict[str, int] = {}
    for i in infos:
        e = i["entity"]
        if e is not None:
            coverage[e.canonical_name] = coverage.get(e.canonical_name, 0) + 1

    summary = (
        f"{len(infos)} rows checked. {clean} clean. {len(issues)} issues found."
    )
    return ValidationReport(
        summary=summary,
        issues=issues_df,
        coverage=coverage,
        is_clean=len(issues) == 0,
    )


def fix_dataframe(
    df: pd.DataFrame,
    id_column: str,
    date_column: str | None = None,
    id_type: str = "ticker",
) -> pd.DataFrame:
    """Return a copy of df with per-row entity columns and a flag."""
    infos = _analyze(df, id_column, date_column, id_type)

    out = df.copy()
    for col in ("_entity_id", "_canonical_name", "_permno", "_gvkey", "_cik"):
        out[col] = pd.NA
    out["_xfinlink_flag"] = "ok"
    out["_xfinlink_detail"] = ""

    for i in infos:
        out.at[i["idx"], "_xfinlink_flag"] = i["flag"]
        out.at[i["idx"], "_xfinlink_detail"] = i["detail"]
        e = i["entity"]
        if e is None:
            continue
        out.at[i["idx"], "_entity_id"] = e.entity_id
        out.at[i["idx"], "_canonical_name"] = e.canonical_name
        out.at[i["idx"], "_permno"] = _pick(e, "permno", i["date"])
        out.at[i["idx"], "_gvkey"] = _pick(e, "gvkey", i["date"])
        out.at[i["idx"], "_cik"] = _pick(e, "cik", i["date"])
    return out
