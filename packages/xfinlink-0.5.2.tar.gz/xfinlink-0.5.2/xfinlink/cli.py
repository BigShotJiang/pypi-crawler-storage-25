"""xfinlink CLI — resolve, validate, fix, and enrich identifier data."""
from __future__ import annotations

import os
from datetime import date as _date_cls
from pathlib import Path

import pandas as pd
import typer
from rich.console import Console
from rich.table import Table
from sqlalchemy import func, select

from xfinlink._db_check import auto_setup
from xfinlink.db import SessionLocal, sqlite_db_path
from xfinlink.models import (
    CorporateEvent,
    Entity,
    Identifier,
    IdType,
    IngestionLog,
    Source,
)

_MIN_DATE = _date_cls.min

app = typer.Typer(
    name="xfinlink",
    help="xfinlink: financial entity identifier resolution.",
    no_args_is_help=True,
)
console = Console()

_license_checked = False


@app.callback()
def _startup() -> None:
    global _license_checked
    if _license_checked:
        return
    _license_checked = True
    from xfinlink.license import TRIAL_NOTICE, check_license

    status = check_license()
    if status.is_trial:
        console.print(f"[dim]{TRIAL_NOTICE}[/dim]")


def _header(text_: str) -> None:
    console.rule(f"[bold cyan]{text_}[/bold cyan]")


@app.command("rebuild-edgar")
def rebuild_edgar_cmd() -> None:
    """Reinstall the bundled EDGAR snapshot into ~/.xfinlink/xfinlink.db.

    Overwrites the existing local database. Most users will never need this —
    the initial install extracts the snapshot automatically on first use.
    """
    _header("xfinlink rebuild-edgar")
    auto_setup(force=True)
    with SessionLocal() as s:
        n_e = s.scalar(select(func.count()).select_from(Entity)) or 0
        n_i = s.scalar(select(func.count()).select_from(Identifier)) or 0
    console.print(f"[green]✓ EDGAR snapshot installed.[/green]")
    console.print(f"  Entities:    {n_e:,}")
    console.print(f"  Identifiers: {n_i:,}")


@app.command("enrich")
def enrich_cmd(
    wrds: bool = typer.Option(False, "--wrds", help="Pull PERMNO/GVKEY/IBES data from WRDS."),
    wrds_username: str = typer.Option(
        None,
        "--wrds-username",
        help="WRDS account username (defaults to WRDS_USERNAME env var, then a prompt).",
    ),
) -> None:
    """Pull WRDS data (PERMNO, GVKEY, CCM linking, IBES) into the local DB.

    Requires a WRDS account. Install the optional dependency first:

        pip install xfinlink[wrds]
    """
    if not wrds:
        console.print("[yellow]Nothing to enrich — pass --wrds to pull WRDS data.[/yellow]")
        raise typer.Exit(code=0)

    try:
        import wrds as _wrds  # noqa: F401
    except ImportError:
        console.print(
            "[red]The `wrds` package is not installed.[/red]\n"
            "[cyan]Run:[/cyan] pip install xfinlink[wrds]"
        )
        raise typer.Exit(code=1) from None

    username = wrds_username or os.environ.get("WRDS_USERNAME")
    if not username:
        username = typer.prompt("WRDS username")
    os.environ["WRDS_USERNAME"] = username

    auto_setup()

    steps: list[tuple[str, list[str], str]] = [
        ("CCM",       [Source.CCM],       "xfinlink.ingestion.wrds_ccm"),
        ("CRSP",      [Source.CRSP],      "xfinlink.ingestion.wrds_crsp"),
        ("Compustat", [Source.COMPUSTAT], "xfinlink.ingestion.wrds_compustat"),
        ("IBES",      [Source.IBES],      "xfinlink.ingestion.wrds_ibes"),
        ("Corporate events", ["crsp_events"], "xfinlink.ingestion.corporate_events"),
    ]
    import importlib

    for label, _sources, module_path in steps:
        _header(f"Running: {label}")
        try:
            mod = importlib.import_module(module_path)
            mod.main()
            console.print(f"[green]✓ {label} complete[/green]")
        except Exception as exc:  # noqa: BLE001
            console.print(f"[bold red]✗ {label} failed:[/bold red] {exc}")
            raise typer.Exit(code=1) from exc

    _print_summary()


def _print_summary() -> None:
    with SessionLocal() as s:
        n_e = s.scalar(select(func.count()).select_from(Entity))
        n_i = s.scalar(select(func.count()).select_from(Identifier))
        n_c = s.scalar(select(func.count()).select_from(CorporateEvent))
    _header("Summary")
    console.print(f"  Entities:         {n_e or 0:,}")
    console.print(f"  Identifiers:      {n_i or 0:,}")
    console.print(f"  Corporate events: {n_c or 0:,}")


@app.command()
def status() -> None:
    """Print DB counts, identifier coverage, and ingestion history."""
    auto_setup()
    id_types = [
        v
        for k, v in vars(IdType).items()
        if not k.startswith("_") and isinstance(v, str)
    ]
    with SessionLocal() as s:
        n_entities = s.scalar(select(func.count()).select_from(Entity)) or 0
        n_ids = s.scalar(select(func.count()).select_from(Identifier)) or 0
        n_events = s.scalar(select(func.count()).select_from(CorporateEvent)) or 0
        last_built = s.scalar(select(func.max(IngestionLog.completed_at)))
        sources_run = [
            row[0]
            for row in s.execute(
                select(IngestionLog.source)
                .distinct()
                .order_by(IngestionLog.source)
            ).all()
        ]
        coverage: dict[str, int] = {}
        for t in id_types:
            coverage[t] = (
                s.scalar(
                    select(func.count(func.distinct(Identifier.entity_id)))
                    .where(Identifier.id_type == t)
                )
                or 0
            )
        source_counts: dict[str, int] = {}
        for src, count in s.execute(
            select(Identifier.source, func.count()).group_by(Identifier.source)
        ).all():
            source_counts[src] = count

    _header("xfinlink status")
    db_path = sqlite_db_path()
    if db_path and db_path.exists():
        size_mb = db_path.stat().st_size / 1024 / 1024
        console.print(f"  Database:         {db_path} ({size_mb:.2f} MB)")
    console.print(f"  Entities:         {n_entities:,}")
    console.print(f"  Identifiers:      {n_ids:,}")
    console.print(f"  Corporate events: {n_events:,}")
    console.print(f"  Last enrich:      {last_built or '(never)'}")
    console.print(
        f"  Sources run:      {', '.join(sources_run) or '(EDGAR snapshot only)'}"
    )

    edgar_n = source_counts.get(Source.EDGAR, 0)
    wrds_sources = (Source.CRSP, Source.COMPUSTAT, Source.CCM, Source.IBES)
    wrds_n = sum(source_counts.get(s, 0) for s in wrds_sources)
    _header("Data breakdown")
    console.print(f"  EDGAR:            {edgar_n:,} identifiers")
    if wrds_n == 0:
        console.print("  WRDS:             not enriched (run `xfinlink enrich --wrds`)")
    else:
        console.print(f"  WRDS:             {wrds_n:,} identifiers")

    tbl = Table(title="Identifier coverage (distinct entities per id_type)")
    tbl.add_column("id_type")
    tbl.add_column("entities", justify="right")
    tbl.add_column("% of entities", justify="right")
    for t in sorted(coverage, key=lambda k: -coverage[k]):
        if coverage[t] == 0:
            continue
        pct = (coverage[t] / n_entities * 100) if n_entities else 0.0
        tbl.add_row(t, f"{coverage[t]:,}", f"{pct:5.1f}%")
    console.print(tbl)


@app.command("resolve")
def resolve_cmd(
    id_type: str = typer.Argument(..., help="Identifier type (ticker, gvkey, cik, cusip_8, cusip_9, permno, ...)."),
    id_value: str = typer.Argument(..., help="Identifier value."),
    as_of: str = typer.Option(
        None, "--date", help="As-of date (YYYY-MM-DD). Omitted = current."
    ),
) -> None:
    """Resolve an identifier to an entity + all its linked identifiers."""
    from xfinlink import resolve as _api_resolve

    try:
        result = _api_resolve(id_type, id_value, as_of_date=as_of)
    except RuntimeError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from exc
    except (ValueError, TypeError) as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=2) from exc

    if result.not_found:
        console.print(
            f"[yellow]Not found:[/yellow] {id_type}={id_value}"
            + (f" as of {as_of}" if as_of else "")
        )
        return

    if result.ambiguous:
        console.print(
            f"[yellow]Ambiguous:[/yellow] {result.match_count} matches for "
            f"{id_type}={id_value}"
            + (f" as of {as_of}" if as_of else "")
        )

    for match in result.matches:
        _header(
            f"{match.canonical_name}  "
            f"(entity_id={match.entity_id}, type={match.entity_type})"
        )
        tbl = Table()
        tbl.add_column("id_type")
        tbl.add_column("id_value")
        tbl.add_column("source")
        tbl.add_column("valid_from")
        tbl.add_column("valid_to")
        tbl.add_column("exchange")
        for ident in sorted(
            match.identifiers,
            key=lambda i: (i.id_type, i.valid_from or _MIN_DATE),
        ):
            tbl.add_row(
                ident.id_type,
                ident.id_value,
                ident.source or "",
                str(ident.valid_from) if ident.valid_from else "",
                str(ident.valid_to) if ident.valid_to else "",
                ident.exchange or "",
            )
        console.print(tbl)


@app.command("mcp")
def mcp_cmd() -> None:
    """Start the xfinlink MCP server (stdio) for AI agents."""
    from xfinlink.mcp_server.server import run as _run

    console.print(
        "[green]xfinlink MCP server running.[/green] Connect your AI agent."
    )
    _run()


@app.command("serve")
def serve_cmd(
    port: int = typer.Option(8000, "--port", help="Port to bind on localhost."),
    host: str = typer.Option("127.0.0.1", "--host", help="Host to bind."),
) -> None:
    """Start the local HTTP API server (FastAPI + uvicorn)."""
    import uvicorn

    auto_setup()
    console.print(f"[green]xfinlink running at[/green] http://{host}:{port}")
    console.print(f"[cyan]API docs at[/cyan] http://{host}:{port}/docs")
    uvicorn.run("xfinlink.api.main:app", host=host, port=port, log_level="info")


def _read_df(path: Path) -> pd.DataFrame:
    if path.suffix in (".parquet", ".pq"):
        return pd.read_parquet(path)
    return pd.read_csv(path)


@app.command("validate")
def validate_cmd(
    file_path: Path = typer.Argument(..., exists=True, readable=True),
    id_column: str = typer.Option(..., "--id-column"),
    date_column: str = typer.Option(None, "--date-column"),
    id_type: str = typer.Option("ticker", "--id-type"),
) -> None:
    """Validate identifiers in a CSV/Parquet panel file."""
    from xfinlink import validate_dataframe as _validate

    try:
        df = _read_df(file_path)
        report = _validate(df, id_column, date_column=date_column, id_type=id_type)
    except RuntimeError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from exc
    except (ValueError, TypeError) as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=2) from exc

    console.print(report.summary)
    if report.coverage:
        tbl = Table(title="Coverage (entity → row count)")
        tbl.add_column("canonical_name")
        tbl.add_column("rows", justify="right")
        for name, n in sorted(report.coverage.items(), key=lambda kv: -kv[1]):
            tbl.add_row(name, str(n))
        console.print(tbl)
    if not report.is_clean:
        out = Path("xfinlink_validation_report.csv")
        report.issues.to_csv(out, index=False)
        console.print(f"[yellow]Issues written to {out}[/yellow]")


@app.command("fix")
def fix_cmd(
    file_path: Path = typer.Argument(..., exists=True, readable=True),
    id_column: str = typer.Option(..., "--id-column"),
    date_column: str = typer.Option(None, "--date-column"),
    id_type: str = typer.Option("ticker", "--id-type"),
    output: Path = typer.Option(None, "--output"),
) -> None:
    """Resolve identifiers row-by-row and write a corrected file."""
    from xfinlink import fix_dataframe as _fix

    try:
        df = _read_df(file_path)
        fixed = _fix(df, id_column, date_column=date_column, id_type=id_type)
    except RuntimeError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from exc
    except (ValueError, TypeError) as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=2) from exc

    if output is None:
        output = file_path.with_name(f"{file_path.stem}_fixed.csv")
    if output.suffix in (".parquet", ".pq"):
        fixed.to_parquet(output, index=False)
    else:
        fixed.to_csv(output, index=False)

    counts = fixed["_xfinlink_flag"].value_counts().to_dict()
    console.print(f"Wrote {len(fixed)} rows to {output}")
    for flag, count in counts.items():
        console.print(f"  {flag}: {count}")


if __name__ == "__main__":
    app()
