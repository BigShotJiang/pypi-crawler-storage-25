"""Shared DB-readiness check with automatic one-time SQLite setup.

On first use, if the default SQLite database is missing or empty, this
module extracts a bundled EDGAR snapshot into ~/.xfinlink/xfinlink.db so
`pip install xfinlink` works with zero setup.
"""
from __future__ import annotations

import gzip
import shutil
import sys
from importlib.resources import files
from pathlib import Path

from sqlalchemy import func, select
from sqlalchemy.exc import OperationalError

from xfinlink.db import IS_SQLITE, SessionLocal, create_all, sqlite_db_path
from xfinlink.models import Entity

BUNDLE_RESOURCE = "data/edgar_bundle.db.gz"
EDGAR_BUNDLE_URL = ""  # filled in if bundle is hosted rather than packaged

_setup_done = False


def _has_bundled_snapshot() -> bool:
    try:
        return (files("xfinlink") / BUNDLE_RESOURCE).is_file()
    except (FileNotFoundError, ModuleNotFoundError):
        return False


def _extract_bundled_snapshot(dest: Path) -> bool:
    if not _has_bundled_snapshot():
        return False
    print("Setting up xfinlink database (one-time setup)...", file=sys.stderr)
    src = files("xfinlink") / BUNDLE_RESOURCE
    dest.parent.mkdir(parents=True, exist_ok=True)
    with src.open("rb") as fin, gzip.GzipFile(fileobj=fin) as gz, open(dest, "wb") as fout:
        shutil.copyfileobj(gz, fout)
    print(f"  database ready at {dest}", file=sys.stderr)
    return True


def _download_snapshot(dest: Path) -> bool:
    if not EDGAR_BUNDLE_URL:
        return False
    import httpx

    print("Downloading xfinlink EDGAR snapshot (one-time setup)...", file=sys.stderr)
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    with httpx.stream("GET", EDGAR_BUNDLE_URL, follow_redirects=True) as r:
        r.raise_for_status()
        total = int(r.headers.get("Content-Length", 0))
        downloaded = 0
        with open(tmp, "wb") as fout:
            for chunk in r.iter_bytes():
                fout.write(chunk)
                downloaded += len(chunk)
                if total:
                    pct = downloaded * 100 // total
                    print(f"\r  {pct:3d}% ({downloaded:,}/{total:,} bytes)", end="", file=sys.stderr)
        print(file=sys.stderr)
    with gzip.open(tmp, "rb") as gz, open(dest, "wb") as fout:
        shutil.copyfileobj(gz, fout)
    tmp.unlink(missing_ok=True)
    print(f"  database ready at {dest}", file=sys.stderr)
    return True


def _entity_count() -> int | None:
    try:
        with SessionLocal() as s:
            return s.scalar(select(func.count()).select_from(Entity)) or 0
    except OperationalError:
        return None


def auto_setup(force: bool = False) -> None:
    """Populate the default SQLite DB if missing/empty. Safe to call repeatedly."""
    global _setup_done
    if _setup_done and not force:
        return
    if not IS_SQLITE:
        _setup_done = True
        return

    db_path = sqlite_db_path()
    if db_path is None:
        _setup_done = True
        return

    needs_install = force or not db_path.exists() or db_path.stat().st_size == 0
    if not needs_install:
        n = _entity_count()
        if n:
            _setup_done = True
            return
        needs_install = True

    if force and db_path.exists():
        db_path.unlink()

    installed = _extract_bundled_snapshot(db_path) or _download_snapshot(db_path)
    if not installed:
        # No bundle and no URL — create an empty schema so the user can
        # enrich with WRDS from scratch.
        create_all()

    _setup_done = True


def check_db_ready() -> None:
    auto_setup()
    n = _entity_count()
    if n is None:
        raise RuntimeError(
            "xfinlink database could not be opened. "
            "Try `xfinlink rebuild-edgar` to reinstall the EDGAR snapshot."
        )
    if not n:
        raise RuntimeError(
            "xfinlink database is empty. "
            "Run `xfinlink rebuild-edgar` to install the EDGAR snapshot, "
            "or `xfinlink enrich --wrds` to populate from WRDS."
        )
