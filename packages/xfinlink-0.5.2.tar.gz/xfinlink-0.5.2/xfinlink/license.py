"""Lightweight license check — trial mode by default.

Runs once at CLI startup. Trial mode allows 500 resolutions per session and
enables every feature; a non-empty `~/.xfinlink/license.key` file activates
full mode. A real license server will replace the file check later.
"""
from __future__ import annotations

from pathlib import Path

LICENSE_PATH = Path.home() / ".xfinlink" / "license.key"
TRIAL_RESOLUTION_LIMIT = 500
TRIAL_NOTICE = (
    f"xfinlink trial mode ({TRIAL_RESOLUTION_LIMIT} resolutions/session). "
    "Get a license at https://xfinlink.io"
)


class LicenseStatus:
    def __init__(self, licensed: bool, key_path: Path, trial_limit: int):
        self.licensed = licensed
        self.key_path = key_path
        self.trial_limit = trial_limit

    @property
    def is_trial(self) -> bool:
        return not self.licensed


def check_license() -> LicenseStatus:
    try:
        if LICENSE_PATH.exists() and LICENSE_PATH.read_text().strip():
            return LicenseStatus(True, LICENSE_PATH, TRIAL_RESOLUTION_LIMIT)
    except OSError:
        pass
    return LicenseStatus(False, LICENSE_PATH, TRIAL_RESOLUTION_LIMIT)
