"""SQLAlchemy 2.0 models for the xFinLink entity-resolution database."""
from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import (
    Boolean,
    Date,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class IdType:
    PERMNO = "permno"
    PERMCO = "permco"
    GVKEY = "gvkey"
    CIK = "cik"
    CUSIP_8 = "cusip_8"
    CUSIP_9 = "cusip_9"
    TICKER = "ticker"
    ISIN = "isin"
    IBES_TICKER = "ibes_ticker"
    EIN = "ein"
    LEI = "lei"
    FIGI = "figi"


class Source:
    CCM = "ccm"
    CRSP = "crsp"
    COMPUSTAT = "compustat"
    EDGAR = "edgar"
    IBES = "ibes"
    DERIVED = "derived"
    OPENFIGI = "openfigi"
    MANUAL = "manual"


class Entity(Base):
    __tablename__ = "entities"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    canonical_name: Mapped[str] = mapped_column(String(255), nullable=False)
    entity_type: Mapped[str] = mapped_column(String(50), nullable=False, server_default="corporation")
    country: Mapped[str] = mapped_column(String(10), nullable=False, server_default="US")
    sic_code: Mapped[str | None] = mapped_column(String(4), nullable=True)
    naics_code: Mapped[str | None] = mapped_column(String(6), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now(), nullable=False
    )

    identifiers: Mapped[list["Identifier"]] = relationship(
        back_populates="entity", cascade="all, delete-orphan"
    )


class Identifier(Base):
    __tablename__ = "identifiers"
    __table_args__ = (
        UniqueConstraint("entity_id", "id_type", "id_value", "valid_from", name="uq_identifier_scope"),
        Index("ix_identifiers_type_value", "id_type", "id_value"),
        Index("ix_identifiers_entity_id", "entity_id"),
        Index("ix_identifiers_validity", "valid_from", "valid_to"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    entity_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("entities.id", ondelete="CASCADE"), nullable=False
    )
    id_type: Mapped[str] = mapped_column(String(20), nullable=False)
    id_value: Mapped[str] = mapped_column(String(50), nullable=False)
    source: Mapped[str] = mapped_column(String(50), nullable=False)
    valid_from: Mapped[date | None] = mapped_column(Date, nullable=True)
    valid_to: Mapped[date | None] = mapped_column(Date, nullable=True)
    exchange: Mapped[str | None] = mapped_column(String(20), nullable=True)
    share_class: Mapped[str | None] = mapped_column(String(10), nullable=True)
    confidence: Mapped[float] = mapped_column(Float, nullable=False, server_default="1.0")
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)

    entity: Mapped["Entity"] = relationship(back_populates="identifiers")


class CorporateEvent(Base):
    __tablename__ = "corporate_events"
    __table_args__ = (
        Index("ix_corporate_events_predecessor", "predecessor_entity_id"),
        Index("ix_corporate_events_successor", "successor_entity_id"),
        Index("ix_corporate_events_date", "event_date"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    event_type: Mapped[str] = mapped_column(String(50), nullable=False)
    event_date: Mapped[date] = mapped_column(Date, nullable=False)
    predecessor_entity_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("entities.id", ondelete="SET NULL"), nullable=True
    )
    successor_entity_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("entities.id", ondelete="SET NULL"), nullable=True
    )
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    source: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class ApiKey(Base):
    __tablename__ = "api_keys"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    key_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    user_email: Mapped[str] = mapped_column(String(255), nullable=False)
    tier: Mapped[str] = mapped_column(String(20), nullable=False, server_default="free")
    daily_limit: Mapped[int] = mapped_column(Integer, nullable=False, server_default="100")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="true")
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class UsageLog(Base):
    __tablename__ = "usage_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    api_key_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("api_keys.id", ondelete="SET NULL"), nullable=True
    )
    endpoint: Mapped[str | None] = mapped_column(String(100), nullable=True)
    identifiers_resolved: Mapped[int | None] = mapped_column(Integer, nullable=True)
    response_time_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


class IngestionLog(Base):
    __tablename__ = "ingestion_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source: Mapped[str] = mapped_column(String(50), nullable=False)
    ingestion_type: Mapped[str | None] = mapped_column(String(50), nullable=True)
    records_processed: Mapped[int | None] = mapped_column(Integer, nullable=True)
    records_added: Mapped[int | None] = mapped_column(Integer, nullable=True)
    records_updated: Mapped[int | None] = mapped_column(Integer, nullable=True)
    errors: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
