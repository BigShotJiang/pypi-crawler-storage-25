"""High-level server enumeration with Rich progress display."""

from __future__ import annotations

from rich.console import Console

from mcpfang.discovery.client import MCPClient
from mcpfang.reporting.models import DiscoveryResult

console = Console()


async def run_discovery(
    endpoint: str,
    transport: str = "sse",
    headers: dict[str, str] | None = None,
) -> DiscoveryResult:
    """Connect to an MCP server and enumerate its capabilities.

    Displays Rich progress output during discovery.
    """
    client = MCPClient(endpoint, transport, headers=headers)

    console.print("  ▸ Connecting to MCP server...", end="")
    try:
        result = await client.discover()
        console.print("                    [green]✓[/green]")
    except Exception as e:
        console.print("                    [red]✗[/red]")
        raise ConnectionError(f"Failed to connect to {endpoint}: {e}") from e

    console.print(f"  ▸ Discovering tools ({len(result.tools)} found)", end="")
    console.print("                    [green]✓[/green]")

    console.print(f"  ▸ Discovering resources ({len(result.resources)} found)", end="")
    console.print("               [green]✓[/green]")

    return result
