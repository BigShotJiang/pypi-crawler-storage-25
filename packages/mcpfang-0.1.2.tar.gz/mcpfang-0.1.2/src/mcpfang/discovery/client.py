"""MCP client wrapper for connecting to MCP servers."""

from __future__ import annotations

import asyncio
import shlex
from contextlib import asynccontextmanager
from typing import AsyncIterator

from mcp import ClientSession, StdioServerParameters
from mcp.client.sse import sse_client
from mcp.client.stdio import stdio_client
from mcp.client.streamable_http import streamablehttp_client

from mcpfang.reporting.models import DiscoveryResult, ToolInfo, ResourceInfo


class MCPClient:
    """Wrapper around the MCP Python SDK for server interaction."""

    def __init__(self, endpoint: str, transport: str = "sse", headers: dict[str, str] | None = None) -> None:
        self.endpoint = endpoint
        self.transport = transport
        self.headers = headers or {}
        self._session: ClientSession | None = None

    @asynccontextmanager
    async def connect(self) -> AsyncIterator[ClientSession]:
        """Connect to the MCP server and yield the session."""
        if self.transport == "stdio":
            parts = shlex.split(self.endpoint)
            server_params = StdioServerParameters(
                command=parts[0],
                args=parts[1:] if len(parts) > 1 else [],
            )
            # Use a wrapper to force-kill the stdio process on cleanup timeout
            cm = stdio_client(server_params)
            transport = await cm.__aenter__()
            read_stream, write_stream = transport
            try:
                async with ClientSession(read_stream, write_stream) as session:
                    await session.initialize()
                    self._session = session
                    try:
                        yield session
                    finally:
                        self._session = None
            finally:
                try:
                    async with asyncio.timeout(5):
                        await cm.__aexit__(None, None, None)
                except (TimeoutError, Exception):
                    pass  # Force exit if cleanup hangs

        elif self.transport == "sse":
            async with sse_client(self.endpoint, headers=self.headers or None) as (read_stream, write_stream):
                async with ClientSession(read_stream, write_stream) as session:
                    await session.initialize()
                    self._session = session
                    try:
                        yield session
                    finally:
                        self._session = None

        elif self.transport == "streamable-http":
            async with streamablehttp_client(self.endpoint, headers=self.headers or None) as (read_stream, write_stream, _):
                async with ClientSession(read_stream, write_stream) as session:
                    await session.initialize()
                    self._session = session
                    try:
                        yield session
                    finally:
                        self._session = None
        else:
            raise ValueError(f"Unsupported transport: {self.transport}. Use 'stdio', 'sse', or 'streamable-http'.")

    async def discover(self) -> DiscoveryResult:
        """Connect and enumerate all tools, resources, and prompts."""
        async with self.connect() as session:
            return await enumerate_server(session, self.endpoint)

    async def call_tool(self, session: ClientSession, name: str, arguments: dict, timeout: float = 30.0) -> str:
        """Call a tool on the connected MCP server and return the text result."""
        try:
            result = await asyncio.wait_for(session.call_tool(name, arguments), timeout=timeout)
        except asyncio.TimeoutError:
            return f"[TIMEOUT] Tool '{name}' did not respond within {timeout}s"
        # Extract text from content blocks
        parts = []
        for block in result.content:
            if hasattr(block, "text"):
                parts.append(block.text)
        return "\n".join(parts)


async def enumerate_server(session: ClientSession, endpoint: str) -> DiscoveryResult:
    """Enumerate tools, resources, and prompts from an active session."""
    discovery = DiscoveryResult(endpoint=endpoint)

    # Fetch tools
    tools_result = await session.list_tools()
    for tool in tools_result.tools:
        discovery.tools.append(ToolInfo(
            name=tool.name,
            description=tool.description or "",
            input_schema=tool.inputSchema if hasattr(tool, "inputSchema") else {},
        ))

    # Fetch resources (may not be supported by all servers)
    try:
        resources_result = await session.list_resources()
        for resource in resources_result.resources:
            discovery.resources.append(ResourceInfo(
                uri=str(resource.uri),
                name=resource.name,
                description=resource.description or "",
                mime_type=resource.mimeType or "" if hasattr(resource, "mimeType") else "",
            ))
    except Exception:
        pass  # Resources are optional

    return discovery
