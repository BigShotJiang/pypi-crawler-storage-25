"""MCPFang CLI — Typer-based command-line interface."""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from mcpfang import __version__

def _parse_headers(raw: list[str]) -> dict[str, str]:
    """Parse 'Key: Value' header strings into a dict."""
    headers: dict[str, str] = {}
    for h in raw:
        if ":" in h:
            key, _, value = h.partition(":")
            headers[key.strip()] = value.strip()
    return headers


app = typer.Typer(
    name="mcpfang",
    help="AI-powered MCP server security scanner.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
console = Console()


def version_callback(value: bool) -> None:
    if value:
        console.print(f"[bold cyan]MCPFang[/bold cyan] v{__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-V",
        help="Show version and exit.",
        callback=version_callback,
        is_eager=True,
    ),
) -> None:
    """MCPFang — AI-powered MCP server security scanner."""


@app.command()
def scan(
    endpoint: str = typer.Argument(..., help="MCP server endpoint URL, or command for stdio transport (e.g. 'npx -y @modelcontextprotocol/server-everything')"),
    provider: str = typer.Option("anthropic", "--provider", "-p", help="LLM provider name"),
    model: str = typer.Option("claude-sonnet-4-20250514", "--model", "-m", help="Model to use"),
    transport: str = typer.Option("sse", "--transport", "-t", help="MCP transport (stdio, sse, streamable-http)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format (table, json, sarif)"),
    output_file: Optional[str] = typer.Option(None, "--file", "-f", help="Write report to file"),
    config: Optional[str] = typer.Option(None, "--config", "-c", help="Path to mcpfang.yaml"),
    playbooks: Optional[str] = typer.Option(None, "--playbooks", help="Comma-separated playbook names"),
    max_steps: int = typer.Option(10, "--max-steps", help="Max steps per playbook"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be sent without calling LLM"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output"),
    sandbox: bool = typer.Option(False, "--sandbox", help="Run MCP server inside Docker sandbox (isolated network, limited resources)"),
    api_key: Optional[str] = typer.Option(None, "--api-key", help="LLM API key (prefer env var)"),
    base_url: Optional[str] = typer.Option(None, "--base-url", help="Custom LLM API base URL"),
    header: list[str] = typer.Option([], "--header", "-H", help="HTTP header for MCP connection as 'Key: Value' (repeatable)"),
) -> None:
    """Scan an MCP server for security vulnerabilities."""
    cli_headers = _parse_headers(header)
    asyncio.run(_scan(
        endpoint=endpoint,
        provider=provider,
        model=model,
        transport=transport,
        output_format=output,
        output_file=output_file,
        config_path=config,
        playbook_names=playbooks,
        max_steps=max_steps,
        dry_run=dry_run,
        verbose=verbose,
        sandbox=sandbox,
        api_key=api_key,
        base_url=base_url,
        cli_headers=cli_headers,
    ))


async def _scan(
    endpoint: str,
    provider: str,
    model: str,
    transport: str,
    output_format: str,
    output_file: str | None,
    config_path: str | None,
    playbook_names: str | None,
    max_steps: int,
    dry_run: bool,
    verbose: bool,
    sandbox: bool,
    api_key: str | None,
    base_url: str | None,
    cli_headers: dict[str, str] | None = None,
) -> None:
    """Async scan implementation."""
    from mcpfang.config import load_config
    from mcpfang.discovery.client import MCPClient
    from mcpfang.discovery.enumerator import run_discovery
    from mcpfang.providers.httpx_provider import create_provider
    from mcpfang.agents.context import build_attack_context
    from mcpfang.agents.runner import run_playbook
    from mcpfang.playbooks.registry import _ensure_loaded, get_playbook, get_all_playbooks
    from mcpfang.reporting.models import ScanResult, Finding, TokenUsage
    from mcpfang.reporting.console_reporter import print_banner, print_summary, print_findings_detail

    # Load config (CLI args override config file)
    cfg = load_config(Path(config_path) if config_path else None)

    # Merge headers: config + CLI (CLI wins on conflict)
    if cli_headers:
        cfg.target.headers = {**cfg.target.headers, **cli_headers}

    # CLI overrides
    target_endpoint = endpoint or cfg.target.endpoint
    if not target_endpoint:
        console.print("[red]Error:[/red] No endpoint specified. Provide an endpoint argument or set it in mcpfang.yaml.")
        raise typer.Exit(1)

    llm_provider = provider or cfg.provider.name
    llm_model = model or cfg.provider.model
    llm_base_url = base_url or cfg.provider.base_url
    scan_transport = transport or cfg.target.transport

    # Initialize scan result
    scan_result = ScanResult(
        target=target_endpoint,
        provider_name=llm_provider,
        model_name=llm_model,
    )

    print_banner(target_endpoint, llm_provider, llm_model)
    console.print()

    # Sandbox check
    if sandbox:
        from mcpfang.sandbox.manager import SandboxManager
        sandbox_mgr = SandboxManager()
        if await sandbox_mgr.is_available():
            console.print("  ▸ Docker sandbox enabled                    [green]✓[/green]")
        else:
            console.print("[red]Error:[/red] --sandbox requires Docker. Ensure Docker is running.")
            raise typer.Exit(1)
    else:
        if verbose:
            console.print("  [dim]▸ Sandbox disabled (use --sandbox for isolated execution)[/dim]")

    # Phase 1: Discovery
    try:
        discovery = await run_discovery(target_endpoint, scan_transport, headers=cfg.target.headers)
        scan_result.discovery = discovery
    except ConnectionError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)

    mcp_client = MCPClient(target_endpoint, scan_transport, headers=cfg.target.headers)

    if not discovery.tools:
        console.print("[yellow]Warning:[/yellow] No tools found on the server. Nothing to scan.")
        raise typer.Exit(0)

    # Phase 1.5: Static analysis (no LLM needed)
    from mcpfang.analysis.static import run_static_analysis

    console.print("  ▸ Running static analysis...", end="")
    static_result = run_static_analysis(discovery)
    static_count = len(static_result.findings)
    if static_count > 0:
        console.print(f"              {static_count} findings [yellow]⚠[/yellow]")
    else:
        console.print(f"              [green]✓[/green]")

    # Add static findings to scan result
    from mcpfang.reporting.models import PlaybookResult
    if static_result.findings:
        scan_result.playbook_results.append(PlaybookResult(
            playbook_name="static_analysis",
            findings=static_result.findings,
        ))

    # Phase 1.6: Hidden surface fuzzing (probing only — no LLM yet)
    from mcpfang.discovery.fuzzer import run_fuzzer, probes_to_candidates, materialize_findings_without_llm

    fuzzer_result = None
    console.print("  ▸ Probing for hidden surfaces...", end="")
    try:
        async with mcp_client.connect() as session:
            fuzzer_result = await run_fuzzer(session, discovery)

        console.print(
            f"           {fuzzer_result.probes_responded} responses collected"
        )
        if verbose and fuzzer_result.probes_sent > 0:
            console.print(
                f"    Probes: {fuzzer_result.probes_sent} sent, "
                f"{fuzzer_result.probes_responded} responded, "
                f"{len(fuzzer_result.errors)} errors"
            )
            if fuzzer_result.errors and verbose:
                for err in fuzzer_result.errors[:5]:
                    console.print(f"    [dim]{err}[/dim]")
                if len(fuzzer_result.errors) > 5:
                    console.print(f"    [dim]... and {len(fuzzer_result.errors) - 5} more[/dim]")
    except Exception as e:
        console.print(f"           [yellow]⚠[/yellow]")
        if verbose:
            console.print(f"    [dim]Fuzzer failed: {e}[/dim]")

    # Resolve API key (needed for domain analysis and playbooks)
    from mcpfang.utils.credentials import get_api_key

    resolved_key = get_api_key(llm_provider, explicit_key=api_key or cfg.provider.api_key)

    # Ollama/LM Studio don't need API keys
    if not resolved_key and llm_provider not in ("ollama", "lmstudio"):
        env_var = f"{llm_provider.upper()}_API_KEY"
        console.print(
            f"[red]Error:[/red] No API key found for '{llm_provider}'.\n"
            f"  Set {env_var} env var, or run: mcpfang auth set {llm_provider}"
        )
        raise typer.Exit(1)

    # Initialize LLM provider
    llm = create_provider(
        provider=llm_provider,
        model=llm_model,
        api_key=resolved_key,
        base_url=llm_base_url,
        max_tokens=cfg.provider.max_tokens,
        temperature=cfg.provider.temperature,
        delay_ms=cfg.scan.llm_delay_ms,
        max_retries=cfg.scan.max_retries,
        retry_base_delay_ms=cfg.scan.retry_base_delay_ms,
    )

    # Phase 2: Domain analysis (LLM understands what the server does)
    from mcpfang.analysis.domain import run_domain_analysis

    console.print("  ▸ Running domain analysis...", end="")
    try:
        domain_report = await run_domain_analysis(
            discovery=discovery,
            provider=llm,
            user_domain=cfg.context.domain,
            user_sensitive_data=cfg.context.sensitive_data,
            user_business_rules=cfg.context.business_rules,
        )
        domain_tokens = TokenUsage(llm.last_usage.input_tokens, llm.last_usage.output_tokens)
        console.print(f"          [green]✓[/green]")
        console.print(f"    {domain_report.format_summary()}")
    except Exception as e:
        domain_report = None
        domain_tokens = TokenUsage()
        console.print(f"          [yellow]⚠[/yellow]")
        if verbose:
            console.print(f"    [dim]Domain analysis failed: {e}[/dim]")

    # Build attack context with domain report
    attack_context = build_attack_context(
        discovery=discovery,
        domain=cfg.context.domain,
        sensitive_data=cfg.context.sensitive_data,
        business_rules=cfg.context.business_rules,
        max_steps=max_steps,
        domain_report=domain_report,
    )

    # Phase 3: Resolve playbooks
    _ensure_loaded()

    if playbook_names:
        selected_names = [n.strip() for n in playbook_names.split(",")]
        selected_playbooks = [get_playbook(n) for n in selected_names]
    else:
        selected_playbooks = get_all_playbooks()

    if not selected_playbooks:
        console.print("[yellow]Warning:[/yellow] No playbooks available.")
        raise typer.Exit(0)

    # Dry run — show domain analysis + playbook prompts
    if dry_run:
        from mcpfang.agents.runner import TOOL_CALL_INSTRUCTION
        from rich.panel import Panel

        console.print()
        if domain_report:
            console.print(Panel(
                domain_report.format_for_prompt(),
                title="Domain Analysis Result",
                border_style="green",
            ))
            console.print()

        console.print("[yellow][DRY RUN][/yellow] Would send the following to the LLM:")
        console.print(f"  Provider: {llm_provider}")
        console.print(f"  Model: {llm_model}")
        console.print(f"  Tools discovered: {len(discovery.tools)}")
        console.print(f"  Playbooks: {len(selected_playbooks)}")
        console.print()

        truncate_at = None if verbose else 2000

        for i, pb in enumerate(selected_playbooks, 1):
            name_display = pb.name.replace("_", " ").title()
            system_prompt = pb.get_system_prompt(attack_context) + "\n\n" + TOOL_CALL_INSTRUCTION
            initial_message = pb.get_initial_message(attack_context)

            if truncate_at and len(system_prompt) > truncate_at:
                prompt_display = system_prompt[:truncate_at] + "..."
            else:
                prompt_display = system_prompt

            console.print(Panel(
                f"[bold]System Prompt[/bold] ({len(system_prompt)} chars):\n"
                f"[dim]{prompt_display}[/dim]\n\n"
                f"[bold]Initial Message[/bold]:\n"
                f"{initial_message}",
                title=f"[{i}/{len(selected_playbooks)}] {name_display} — {', '.join(pb.cwe_ids)}",
                border_style="yellow",
            ))
            console.print()

        if not verbose:
            console.print("[dim]Prompts truncated at 2000 chars. Use --verbose for full output.[/dim]")
        console.print("[yellow]1 API call was made (domain analysis). No playbook calls.[/yellow]")
        raise typer.Exit(0)

    console.print()
    console.print("  ▸ Running playbooks...")

    for i, pb in enumerate(selected_playbooks, 1):
        total = len(selected_playbooks)
        name_display = pb.name.replace("_", " ").title()
        if verbose:
            console.print(f"    [{i}/{total}] {name_display}")
        else:
            console.print(f"    [{i}/{total}] {name_display:<35}", end="")

        try:
            pb_result = await run_playbook(pb, attack_context, llm, mcp_client, verbose=verbose)
        except BaseException as e:
            if isinstance(e, KeyboardInterrupt):
                raise
            # Ensure even crashed playbooks get recorded
            from mcpfang.reporting.models import PlaybookResult as PBResult
            pb_result = PBResult(playbook_name=pb.name, error=f"{type(e).__name__}: {e}")

        scan_result.playbook_results.append(pb_result)

        count = len(pb_result.findings)
        prefix = "    " if verbose else " "
        if pb_result.error:
            console.print(f"{prefix}[red]ERROR[/red]")
            if verbose:
                console.print(f"          {pb_result.error}")
        elif count == 0:
            console.print(f"{prefix}{count} findings   [green]✓[/green]")
        else:
            console.print(f"{prefix}{count} findings   [yellow]⚠[/yellow]")

    # --- Save raw scan result (before evaluation) ---
    # Add fuzzer raw findings to get the "before evaluation" snapshot
    from mcpfang.reporting.models import Severity, FindingCategory
    from collections import defaultdict

    raw_scan_result = ScanResult(
        target=scan_result.target,
        started_at=scan_result.started_at,
        discovery=scan_result.discovery,
        provider_name=scan_result.provider_name,
        model_name=scan_result.model_name,
        domain_analysis_tokens=domain_tokens,
    )
    # Copy static analysis results
    for pr in scan_result.playbook_results:
        if pr.playbook_name == "static_analysis":
            raw_scan_result.playbook_results.append(pr)

    # Add raw fuzzer findings (unfiltered)
    if fuzzer_result and fuzzer_result.raw_probes:
        materialize_findings_without_llm(fuzzer_result)
        if fuzzer_result.findings:
            raw_scan_result.playbook_results.append(PlaybookResult(
                playbook_name="hidden_surface_fuzzer",
                findings=list(fuzzer_result.findings),
            ))
        # Reset for evaluation phase
        fuzzer_result.findings = []

    # Add raw playbook findings (unfiltered)
    for pr in scan_result.playbook_results:
        if pr.playbook_name != "static_analysis":
            raw_scan_result.playbook_results.append(pr)

    raw_scan_result.finished_at = datetime.now(timezone.utc)

    # Phase 4: Unified response evaluation
    from mcpfang.analysis.evaluator import evaluate_candidates
    from mcpfang.agents.runner import findings_to_candidates

    console.print()
    console.print("  ▸ Validating findings with LLM...", end="")

    # Collect ALL candidates: fuzzer probes + playbook findings
    all_candidates = []

    # Fuzzer candidates
    if fuzzer_result and fuzzer_result.raw_probes:
        fuzzer_candidates = probes_to_candidates(fuzzer_result, discovery)
        all_candidates.extend(fuzzer_candidates)

    # Playbook candidates (findings from all playbooks excluding static_analysis)
    playbook_findings = []
    for pr in scan_result.playbook_results:
        if pr.playbook_name == "static_analysis":
            continue
        playbook_findings.extend(pr.findings)

    if playbook_findings:
        pb_candidates = findings_to_candidates(playbook_findings, discovery)
        all_candidates.extend(pb_candidates)

    evaluation_error: str | None = None
    eval_tokens = TokenUsage()

    if all_candidates:
        try:
            verdicts, eval_tokens = await evaluate_candidates(all_candidates, llm, domain_report)

            confirmed_findings = []
            rejected_count = 0
            review_count = 0

            for candidate, verdict in zip(all_candidates, verdicts):
                if verdict.verdict == "false_positive":
                    rejected_count += 1
                    continue

                if verdict.verdict == "needs_review":
                    review_count += 1

                if candidate.original_finding:
                    finding = candidate.original_finding
                else:
                    try:
                        sev = Severity(verdict.severity)
                    except ValueError:
                        sev = Severity.MEDIUM
                    finding = Finding(
                        id="",
                        title=candidate.claimed_title,
                        description=candidate.action,
                        severity=sev,
                        category=FindingCategory.HIDDEN_SURFACE,
                        tool_name=candidate.tool_name,
                        playbook=candidate.source,
                        cwe_ids=["CWE-912"],
                        proof_of_concept=f"{candidate.action} -> {candidate.response[:300]}",
                        remediation="",
                    )

                # Apply evaluator verdict
                try:
                    finding.severity = Severity(verdict.severity)
                except ValueError:
                    pass
                if verdict.refined_title:
                    finding.title = verdict.refined_title
                if verdict.reasoning:
                    finding.description = f"{finding.description}\n\nEvaluator: {verdict.reasoning}"

                confirmed_findings.append(finding)

            # Dedup BEFORE building scan result
            from mcpfang.analysis.evaluator import deduplicate_findings
            pre_dedup = len(confirmed_findings)
            confirmed_findings, dedup_tokens = await deduplicate_findings(confirmed_findings, llm, discovery)
            eval_tokens += dedup_tokens
            dedup_removed = pre_dedup - len(confirmed_findings)

            # Build evaluated scan result — static results + confirmed only
            # Preserve token usage from original playbook results
            original_token_usage = {pr.playbook_name: pr.token_usage for pr in scan_result.playbook_results}
            static_results = [pr for pr in scan_result.playbook_results if pr.playbook_name == "static_analysis"]
            scan_result.playbook_results = list(static_results)

            by_source: dict[str, list[Finding]] = defaultdict(list)
            for f in confirmed_findings:
                by_source[f.playbook].append(f)

            prefix_map = {
                "fuzzer": "FUZ", "command_injection": "INJ", "path_traversal": "PTR",
                "tool_poisoning": "POI", "auth_bypass": "AUT", "input_validation": "VAL",
                "intent_flow_subversion": "IFS", "context_injection": "CTX",
                "resource_probing": "RSC",
            }
            for source, findings_list in by_source.items():
                prefix = prefix_map.get(source, "FND")
                for i, f in enumerate(findings_list, 1):
                    f.id = f"{prefix}-{i:03d}"
                pb_name = source if source != "fuzzer" else "hidden_surface_fuzzer"
                scan_result.playbook_results.append(PlaybookResult(
                    playbook_name=pb_name,
                    findings=findings_list,
                    token_usage=original_token_usage.get(source, TokenUsage()),
                ))

            if fuzzer_result:
                confirmed_tool_names = {
                    f.tool_name for f in confirmed_findings
                    if f.playbook == "fuzzer" and f.tool_name not in ("(resource)", "(method)")
                }
                fuzzer_result.hidden_tools = [
                    t for t in fuzzer_result.hidden_tools if t.name in confirmed_tool_names
                ]
                if fuzzer_result.hidden_tools:
                    discovery.tools.extend(fuzzer_result.hidden_tools)

            total_confirmed = len(confirmed_findings)
            if total_confirmed > 0:
                dedup_note = f", {dedup_removed} deduplicated" if dedup_removed else ""
                console.print(f"    {total_confirmed} confirmed, {rejected_count} rejected{dedup_note} [yellow]⚠[/yellow]")
            else:
                console.print(f"    all clear ({rejected_count} rejected) [green]✓[/green]")

            if verbose:
                console.print(
                    f"    Evaluator: {total_confirmed} confirmed, "
                    f"{rejected_count} false positives, "
                    f"{dedup_removed} duplicates merged, "
                    f"{review_count} needs review"
                )

        except Exception as e:
            evaluation_error = str(e)
            console.print(f"    [red]✗ evaluation failed[/red]")
            console.print(f"    [red]Error: {evaluation_error}[/red]")

            # Evaluation failed — still run dedup on raw playbook findings
            console.print(f"    Running dedup on unvalidated findings...")
            from mcpfang.analysis.evaluator import deduplicate_findings
            raw_findings = []
            for pr in scan_result.playbook_results:
                if pr.playbook_name != "static_analysis":
                    raw_findings.extend(pr.findings)
            if raw_findings:
                pre_dedup = len(raw_findings)
                raw_findings, dedup_tokens = await deduplicate_findings(raw_findings, llm, discovery)
                eval_tokens += dedup_tokens
                dedup_removed = pre_dedup - len(raw_findings)
                console.print(f"    {len(raw_findings)} after dedup ({dedup_removed} removed) [yellow]⚠[/yellow]")

                # Rebuild playbook results with deduped findings
                original_token_usage = {pr.playbook_name: pr.token_usage for pr in scan_result.playbook_results}
                static_results = [pr for pr in scan_result.playbook_results if pr.playbook_name == "static_analysis"]
                scan_result.playbook_results = list(static_results)

                by_source: dict[str, list[Finding]] = defaultdict(list)
                for f in raw_findings:
                    by_source[f.playbook].append(f)

                prefix_map = {
                    "fuzzer": "FUZ", "command_injection": "INJ", "path_traversal": "PTR",
                    "tool_poisoning": "POI", "auth_bypass": "AUT", "input_validation": "VAL",
                    "intent_flow_subversion": "IFS", "context_injection": "CTX",
                    "resource_probing": "RSC",
                }
                for source, findings_list in by_source.items():
                    prefix = prefix_map.get(source, "FND")
                    for i, f in enumerate(findings_list, 1):
                        f.id = f"{prefix}-{i:03d}"
                    pb_name = source if source != "fuzzer" else "hidden_surface_fuzzer"
                    scan_result.playbook_results.append(PlaybookResult(
                        playbook_name=pb_name,
                        findings=findings_list,
                        token_usage=original_token_usage.get(source, TokenUsage()),
                    ))
    else:
        console.print(f"    no candidates [green]✓[/green]")

    # Attach token usage to scan result
    scan_result.domain_analysis_tokens = domain_tokens
    scan_result.evaluation_tokens = eval_tokens

    scan_result.finished_at = datetime.now(timezone.utc)

    # --- Report LLM provider errors ---
    if hasattr(llm, "errors") and llm.errors:
        console.print()
        console.print("  [bold yellow]⚠ LLM API errors encountered during scan:[/bold yellow]")
        from mcpfang.providers.httpx_provider import ProviderError
        error_summary: dict[int, int] = {}
        for err in llm.errors:
            error_summary[err.status_code] = error_summary.get(err.status_code, 0) + 1
        for code, count in sorted(error_summary.items()):
            label = {429: "Rate Limited", 403: "Forbidden", 402: "Payment Required",
                     500: "Server Error", 502: "Bad Gateway", 503: "Service Unavailable"}.get(code, f"HTTP {code}")
            console.print(f"    {label} ({code}): {count} occurrence(s)")
            if code == 429:
                console.print(f"      [dim]Tip: increase scan.llm_delay_ms in mcpfang.yaml (current: {cfg.scan.llm_delay_ms}ms)[/dim]")
            elif code == 402:
                console.print(f"      [dim]Tip: your LLM provider account may need credits[/dim]")
            elif code == 403:
                console.print(f"      [dim]Tip: check your API key permissions[/dim]")

        exhausted = [e for e in llm.errors if e.exhausted]
        if exhausted:
            console.print(f"    [red]{len(exhausted)} request(s) failed after {cfg.scan.max_retries} retries[/red]")

    # Phase 5: Reports
    console.print()

    # Show evaluated results (primary)
    print_summary(scan_result)
    print_findings_detail(scan_result)

    # Show token usage breakdown
    from mcpfang.reporting.console_reporter import print_token_usage
    print_token_usage(scan_result)

    if evaluation_error:
        console.print(f"  [bold red]⚠ Evaluation failed — above results are UNVALIDATED[/bold red]")
        console.print(f"  [red]  Error: {evaluation_error}[/red]")
        console.print()

    # Write output files
    if output_format == "json" or (output_file and output_file.endswith(".json")):
        from mcpfang.reporting.json_reporter import write_json_report

        out_path = output_file or "mcpfang-report.json"

        # Write raw (unfiltered) report
        raw_path = out_path.replace(".json", ".raw.json")
        write_json_report(raw_scan_result, raw_path)

        # Write evaluated (filtered) report
        write_json_report(scan_result, out_path)

        console.print(f"  [bold]Evaluated report:[/bold] ./{out_path}")
        console.print(f"  [dim]Raw report (before evaluation):[/dim] ./{raw_path}")

    elif output_format == "sarif" or (output_file and output_file.endswith(".sarif")):
        from mcpfang.reporting.sarif_reporter import write_sarif_report

        out_path = output_file or "mcpfang-report.sarif"
        write_sarif_report(scan_result, out_path)
        console.print(f"  SARIF report: ./{out_path}")

    console.print()

    # Exit code for CI/CD
    if cfg.output.ci_exit_code and scan_result.all_findings:
        raise typer.Exit(1)


@app.command()
def inspect(
    endpoint: str = typer.Argument(..., help="MCP server endpoint URL or command for stdio"),
    transport: str = typer.Option("sse", "--transport", "-t", help="MCP transport (stdio, sse, streamable-http)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format"),
    header: list[str] = typer.Option([], "--header", "-H", help="HTTP header as 'Key: Value' (repeatable)"),
) -> None:
    """Inspect an MCP server (discovery only, no attacks)."""
    headers = _parse_headers(header)
    asyncio.run(_inspect(endpoint, transport, output, headers))


async def _inspect(endpoint: str, transport: str, output_format: str, headers: dict[str, str] | None = None) -> None:
    """Async inspect implementation."""
    from mcpfang.discovery.enumerator import run_discovery

    console.print(f"[bold cyan]MCPFang[/bold cyan] — Inspecting {endpoint}")
    console.print()

    try:
        discovery = await run_discovery(endpoint, transport, headers=headers)
    except ConnectionError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)

    # Tools table
    if discovery.tools:
        table = Table(title="Tools", show_lines=True)
        table.add_column("Name", style="bold")
        table.add_column("Description")
        table.add_column("Parameters")

        for tool in discovery.tools:
            params = ""
            if tool.input_schema:
                props = tool.input_schema.get("properties", {})
                required = tool.input_schema.get("required", [])
                parts = []
                for name, info in props.items():
                    req = " *" if name in required else ""
                    parts.append(f"{name}: {info.get('type', 'any')}{req}")
                params = "\n".join(parts)

            table.add_row(tool.name, tool.description, params)

        console.print(table)

    # Resources table
    if discovery.resources:
        console.print()
        table = Table(title="Resources", show_lines=True)
        table.add_column("URI", style="bold")
        table.add_column("Name")
        table.add_column("Description")

        for res in discovery.resources:
            table.add_row(res.uri, res.name, res.description)

        console.print(table)

    if not discovery.tools and not discovery.resources:
        console.print("[yellow]No tools or resources found.[/yellow]")


@app.command(name="playbooks")
def list_playbooks() -> None:
    """List available attack playbooks."""
    from mcpfang.playbooks.registry import _ensure_loaded, get_all_playbooks

    _ensure_loaded()
    all_pb = get_all_playbooks()

    if not all_pb:
        console.print("[yellow]No playbooks available.[/yellow]")
        return

    table = Table(title="Available Playbooks")
    table.add_column("Name", style="bold")
    table.add_column("Category")
    table.add_column("Severity")
    table.add_column("CWE IDs")
    table.add_column("Description")

    for pb in all_pb:
        table.add_row(
            pb.name,
            pb.category,
            pb.severity_default,
            ", ".join(pb.cwe_ids),
            pb.description,
        )

    console.print(table)


@app.command(name="config")
def config_init(
    action: str = typer.Argument("init", help="Action: init"),
) -> None:
    """Initialize mcpfang.yaml configuration file."""
    if action != "init":
        console.print(f"[red]Unknown action:[/red] {action}. Use 'init'.")
        raise typer.Exit(1)

    config_path = Path("mcpfang.yaml")
    if config_path.exists():
        console.print("[yellow]mcpfang.yaml already exists.[/yellow]")
        raise typer.Exit(0)

    template = """\
# MCPFang Configuration
# See: https://github.com/mcpfang/mcpfang

# --- LLM Provider ---
# Supported: anthropic, openai, ollama, openrouter, lmstudio
# Or any OpenAI-compatible endpoint via base_url
provider:
  name: anthropic
  model: claude-sonnet-4-20250514
  # api_key: set via ANTHROPIC_API_KEY env var (or paste here)
  # base_url: null               # custom API endpoint (auto-detected per provider)
  max_tokens: 4096               # max response tokens per LLM call
  temperature: 0.4               # 0.0 = deterministic, 1.0 = creative (0.4 recommended)
  # timeout: 120                 # seconds per LLM request

# --- Scan Target ---
target:
  endpoint: ""                   # URL for sse/streamable-http, or command for stdio
  transport: sse                 # stdio | sse | streamable-http
  headers: {}                    # e.g. {Authorization: "Bearer token123"}

# --- Domain Context (helps AI understand your server) ---
context:
  domain: ""                     # e.g. "e-commerce", "healthcare", "fintech"
  sensitive_data: []             # e.g. ["credit card tokens", "user addresses"]
  business_rules: []             # e.g. ["sellers must not see buyer address"]

# --- Scan Settings ---
scan:
  playbooks:
    - command_injection
    - path_traversal
    - tool_poisoning
    - auth_bypass
    - input_validation
    - intent_flow_subversion
    - context_injection
  max_steps_per_playbook: 10     # max agent steps per playbook
  timeout_seconds: 300           # total scan timeout
  llm_delay_ms: 500             # delay between LLM API calls (ms)
  mcp_delay_ms: 100             # delay between MCP tool calls (ms)
  max_retries: 3                # max retries on 429/5xx
  retry_base_delay_ms: 2000     # base delay for exponential backoff (ms)

# --- Output ---
output:
  format: table                  # table | json | sarif
  severity_threshold: low        # minimum severity to report: low | medium | high | critical
  ci_exit_code: true             # exit 1 if findings found (for CI/CD)
"""
    config_path.write_text(template, encoding="utf-8")
    console.print(f"[green]✓[/green] Created {config_path}")


@app.command()
def auth(
    action: str = typer.Argument(..., help="Action: set or show"),
    provider: str = typer.Argument(..., help="Provider name (anthropic, openai, ollama, etc.)"),
    method: str = typer.Option("config", "--method", help="Storage method: config or keychain"),
) -> None:
    """Manage API keys for LLM providers."""
    from mcpfang.utils.credentials import store_api_key, get_api_key, PROVIDER_ENV_VARS

    if action == "set":
        api_key = typer.prompt("Enter API key", hide_input=True)
        store_api_key(provider, api_key, method=method)

    elif action == "show":
        key = get_api_key(provider)
        if key:
            masked = key[:8] + "..." + key[-4:] if len(key) > 12 else "****"
            console.print(f"[green]✓[/green] {provider}: {masked}")
        else:
            env_var = PROVIDER_ENV_VARS.get(provider, f"{provider.upper()}_API_KEY")
            console.print(
                f"[yellow]No API key found for '{provider}'.[/yellow]\n"
                f"  Set via: export {env_var}=sk-...\n"
                f"  Or run:  mcpfang auth set {provider}"
            )
    else:
        console.print(f"[red]Unknown action:[/red] {action}. Use 'set' or 'show'.")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
