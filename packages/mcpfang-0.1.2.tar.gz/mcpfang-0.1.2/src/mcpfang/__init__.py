"""MCPFang — AI-powered MCP server security scanner."""

__version__ = "0.1.2"
