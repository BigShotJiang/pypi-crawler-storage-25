# -*- coding: utf-8 -*-
"""
Horus Paper Trading Bot
========================
بوت تداول ورقي يستخدم بيانات Horus Flow Intelligence الحية
لاتخاذ قرارات تداول ذكية بناءً على الـ orderflow المؤسسي.

Usage:
    export RAPIDAPI_KEY="your_key"
    python paper_trading_bot.py

© 2026 Built with Horus Flow Intelligence
"""
import os
import sys
import json
import asyncio
import time
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import Optional

import httpx

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.layout import Layout
    from rich.live import Live
    from rich.text import Text
    HAS_RICH = True
except ImportError:
    HAS_RICH = False

# ─── Configuration ────────────────────────────────────────
RAPIDAPI_HOST = "horus-flow-intelligence.p.rapidapi.com"
RAPIDAPI_BASE_URL = f"https://{RAPIDAPI_HOST}"
RAPIDAPI_KEY = os.environ.get("RAPIDAPI_KEY", "")

HEADERS = {
    "x-rapidapi-key": RAPIDAPI_KEY,
    "x-rapidapi-host": RAPIDAPI_HOST,
}

# ─── Bot Settings ─────────────────────────────────────────
INITIAL_CAPITAL = 10_000.0          # رأس المال الابتدائي
SYMBOLS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "BNBUSDT"]
POLL_INTERVAL = 15                  # ثواني بين كل فحص
MAX_POSITION_PCT = 0.25             # أقصى نسبة من رأس المال لكل صفقة
STOP_LOSS_PCT = 0.02                # وقف خسارة 2%
TAKE_PROFIT_PCT = 0.04              # جني أرباح 4%
MIN_CONFIDENCE = 0.70               # أقل ثقة لفتح صفقة


# ─── Data Classes ─────────────────────────────────────────
@dataclass
class Trade:
    symbol: str
    side: str               # "BUY" or "SELL"
    entry_price: float
    quantity: float
    entry_time: str
    signal: str
    confidence: float
    exit_price: Optional[float] = None
    exit_time: Optional[str] = None
    exit_reason: Optional[str] = None
    pnl: float = 0.0

    def to_dict(self):
        return {
            "symbol": self.symbol,
            "side": self.side,
            "entry_price": self.entry_price,
            "quantity": self.quantity,
            "entry_time": self.entry_time,
            "signal": self.signal,
            "confidence": self.confidence,
            "exit_price": self.exit_price,
            "exit_time": self.exit_time,
            "exit_reason": self.exit_reason,
            "pnl": round(self.pnl, 2),
        }


@dataclass
class Position:
    symbol: str
    side: str
    entry_price: float
    quantity: float
    entry_time: str
    signal: str
    confidence: float
    current_price: float = 0.0

    @property
    def unrealized_pnl(self) -> float:
        if self.side == "BUY":
            return (self.current_price - self.entry_price) * self.quantity
        else:
            return (self.entry_price - self.current_price) * self.quantity

    @property
    def pnl_pct(self) -> float:
        if self.entry_price == 0:
            return 0.0
        if self.side == "BUY":
            return ((self.current_price - self.entry_price) / self.entry_price) * 100
        else:
            return ((self.entry_price - self.current_price) / self.entry_price) * 100


@dataclass
class Portfolio:
    cash: float = INITIAL_CAPITAL
    positions: dict = field(default_factory=dict)   # symbol -> Position
    trade_history: list = field(default_factory=list)
    total_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0

    @property
    def total_value(self) -> float:
        positions_value = sum(
            p.current_price * p.quantity for p in self.positions.values()
        )
        return self.cash + positions_value

    @property
    def total_pnl(self) -> float:
        return self.total_value - INITIAL_CAPITAL

    @property
    def total_pnl_pct(self) -> float:
        return (self.total_pnl / INITIAL_CAPITAL) * 100

    @property
    def win_rate(self) -> float:
        if self.total_trades == 0:
            return 0.0
        return (self.winning_trades / self.total_trades) * 100


# ─── API Helper ───────────────────────────────────────────
async def fetch_flow(symbol: str) -> dict:
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            resp = await client.get(
                f"{RAPIDAPI_BASE_URL}/v1/flow/crypto/{symbol}",
                headers=HEADERS,
            )
            if resp.status_code == 200:
                return resp.json()
            return {"error": True, "symbol": symbol, "status": resp.status_code}
        except Exception as e:
            return {"error": True, "symbol": symbol, "detail": str(e)}


SYMBOL_TO_COINGECKO = {
    "BTCUSDT": "bitcoin",
    "ETHUSDT": "ethereum",
    "SOLUSDT": "solana",
    "XRPUSDT": "ripple",
    "BNBUSDT": "binancecoin",
    "DOGEUSDT": "dogecoin",
    "ADAUSDT": "cardano",
    "AVAXUSDT": "avalanche-2",
    "DOTUSDT": "polkadot",
    "LINKUSDT": "chainlink",
}

_price_cache: dict = {}
_price_cache_time: float = 0


async def fetch_all_prices(symbols: list) -> dict:
    """Fetch real-time prices from CoinGecko public API."""
    global _price_cache, _price_cache_time

    # Cache for 10 seconds to avoid rate limiting
    if time.time() - _price_cache_time < 10 and _price_cache:
        return {sym: _price_cache.get(sym, 0.0) for sym in symbols}

    ids = ",".join(SYMBOL_TO_COINGECKO.get(s, "") for s in symbols if SYMBOL_TO_COINGECKO.get(s))
    async with httpx.AsyncClient(timeout=8.0) as client:
        try:
            resp = await client.get(
                f"https://api.coingecko.com/api/v3/simple/price?ids={ids}&vs_currencies=usd"
            )
            if resp.status_code == 200:
                data = resp.json()
                result = {}
                for sym in symbols:
                    cg_id = SYMBOL_TO_COINGECKO.get(sym, "")
                    if cg_id and cg_id in data:
                        result[sym] = float(data[cg_id]["usd"])
                    else:
                        result[sym] = _price_cache.get(sym, 0.0)
                _price_cache = result
                _price_cache_time = time.time()
                return result
        except Exception:
            pass

    if _price_cache:
        return {sym: _price_cache.get(sym, 0.0) for sym in symbols}
    return {sym: 0.0 for sym in symbols}


async def fetch_all_flows(symbols: list) -> list:
    tasks = [fetch_flow(sym) for sym in symbols]
    return await asyncio.gather(*tasks)


# ─── Signal Processing ───────────────────────────────────
def analyze_signal(data: dict) -> dict:
    """
    Analyze Horus flow data and return trading decision.
    Returns: {"action": "BUY"|"SELL"|"CLOSE"|"HOLD", "reason": str, ...}
    """
    if data.get("error"):
        return {"action": "HOLD", "reason": "بيانات غير متاحة"}

    symbol = data.get("symbol", "???")
    signal = data.get("signal", "NEUTRAL")
    confidence = data.get("confidence", 0)
    risk = data.get("risk", "MEDIUM")
    market_state = data.get("market_state", "UNKNOWN")
    metrics = data.get("metrics", {})

    bid_ask_ratio = metrics.get("bid_ask_ratio", 1.0)
    buy_sell_ratio = metrics.get("buy_sell_ratio", 1.0)
    delta_5s = metrics.get("delta_5s", 0)
    delta_30s = metrics.get("delta_30s", 0)
    whale_activity = metrics.get("whale_activity", False)
    delta_accel = metrics.get("delta_accel", 0)
    flags = metrics.get("flags", [])
    wall_side = metrics.get("wall_side")
    refill_ratio = metrics.get("refill_ratio", 1.0)

    # ─── Emergency Signals (Close immediately) ─────
    if signal in ["EMERGENCY_DUMP", "BAILOUT", "LIQUIDITY_EVENT"]:
        return {
            "action": "CLOSE_ALL",
            "reason": f"إشارة طوارئ: {signal} (ثقة: {confidence})",
            "signal": signal,
            "confidence": confidence,
            "risk": "EXTREME",
        }

    # ─── Strong Sell Signals ─────
    if signal in ["INSTITUTIONAL_DISTRIBUTION", "STRONG_SELL_PRESSURE"]:
        if confidence >= MIN_CONFIDENCE:
            # Check for spoofing traps
            has_trap = any("TRAP" in f for f in flags)
            has_spoofing = any("SPOOFING" in f for f in flags)

            if has_trap or has_spoofing:
                return {
                    "action": "SELL",
                    "reason": f"توزيع مؤسسي + كشف Spoofing | {signal}",
                    "signal": signal,
                    "confidence": confidence,
                    "risk": risk,
                    "size_factor": min(confidence, 0.95),
                }
            return {
                "action": "SELL",
                "reason": f"ضغط بيع مؤسسي قوي | {signal}",
                "signal": signal,
                "confidence": confidence,
                "risk": risk,
                "size_factor": confidence * 0.8,
            }

    # ─── Sell Pressure ─────
    if signal == "SELL_PRESSURE" and confidence >= MIN_CONFIDENCE:
        return {
            "action": "SELL",
            "reason": f"ضغط بيع | delta_5s: {delta_5s:.0f}",
            "signal": signal,
            "confidence": confidence,
            "risk": risk,
            "size_factor": confidence * 0.6,
        }

    # ─── Strong Buy Signals ─────
    if signal in ["STRONG_BUY_PRESSURE", "INSTITUTIONAL_ACCUMULATION"]:
        if confidence >= MIN_CONFIDENCE:
            return {
                "action": "BUY",
                "reason": f"تجميع مؤسسي | {signal}",
                "signal": signal,
                "confidence": confidence,
                "risk": risk,
                "size_factor": min(confidence, 0.95),
            }

    # ─── Buy Pressure ─────
    if signal == "BUY_PRESSURE" and confidence >= MIN_CONFIDENCE:
        if buy_sell_ratio > 1.5 and delta_5s > 0:
            return {
                "action": "BUY",
                "reason": f"ضغط شراء قوي | buy_sell_ratio: {buy_sell_ratio:.2f}",
                "signal": signal,
                "confidence": confidence,
                "risk": risk,
                "size_factor": confidence * 0.6,
            }

    # ─── Whale Detection with Delta Confirmation ─────
    if whale_activity and delta_accel > 2.0 and confidence >= 0.8:
        if delta_5s > 0:
            return {
                "action": "BUY",
                "reason": f"نشاط حيتان + تسارع شراء {delta_accel:.1f}x",
                "signal": signal,
                "confidence": confidence,
                "risk": risk,
                "size_factor": 0.5,
            }
        elif delta_5s < 0:
            return {
                "action": "SELL",
                "reason": f"نشاط حيتان + تسارع بيع {delta_accel:.1f}x",
                "signal": signal,
                "confidence": confidence,
                "risk": risk,
                "size_factor": 0.5,
            }

    # ─── Default: Hold ─────
    return {
        "action": "HOLD",
        "reason": f"لا إشارة واضحة | {signal} (ثقة: {confidence})",
        "signal": signal,
        "confidence": confidence,
        "risk": risk,
    }


# ─── Trading Engine ──────────────────────────────────────
class PaperTradingBot:
    def __init__(self):
        self.portfolio = Portfolio()
        self.console = Console() if HAS_RICH else None
        self.log_lines = []
        self.cycle_count = 0
        self.last_signals = {}
        self.live_prices = {}
        self.start_time = datetime.now(timezone.utc)

    def log(self, msg: str):
        timestamp = datetime.now(timezone.utc).strftime("%H:%M:%S")
        line = f"[{timestamp}] {msg}"
        self.log_lines.append(line)
        if len(self.log_lines) > 50:
            self.log_lines = self.log_lines[-50:]
        if not HAS_RICH:
            print(line)

    async def get_live_prices(self) -> dict:
        """Fetch real-time prices from Binance."""
        prices = await fetch_all_prices(SYMBOLS)
        self.live_prices = prices
        return prices

    def open_position(self, symbol: str, side: str, price: float,
                      signal: str, confidence: float, size_factor: float = 1.0):
        if symbol in self.portfolio.positions:
            self.log(f"⚠️ {symbol}: صفقة مفتوحة بالفعل — تخطي")
            return

        # Position sizing
        max_allocation = self.portfolio.cash * MAX_POSITION_PCT
        allocation = max_allocation * size_factor
        allocation = min(allocation, self.portfolio.cash * 0.95)

        if allocation < 10:
            self.log(f"⚠️ {symbol}: رأس مال غير كافٍ (${self.portfolio.cash:.2f})")
            return

        quantity = allocation / price
        self.portfolio.cash -= allocation

        pos = Position(
            symbol=symbol,
            side=side,
            entry_price=price,
            quantity=quantity,
            entry_time=datetime.now(timezone.utc).isoformat(),
            signal=signal,
            confidence=confidence,
            current_price=price,
        )
        self.portfolio.positions[symbol] = pos

        side_ar = "شراء 🟢" if side == "BUY" else "بيع 🔴"
        self.log(
            f"📌 فتح صفقة {side_ar} | {symbol} | "
            f"السعر: ${price:,.2f} | الكمية: {quantity:.6f} | "
            f"القيمة: ${allocation:,.2f} | الإشارة: {signal}"
        )

    def close_position(self, symbol: str, price: float, reason: str):
        if symbol not in self.portfolio.positions:
            return

        pos = self.portfolio.positions[symbol]
        pos.current_price = price

        pnl = pos.unrealized_pnl
        proceeds = price * pos.quantity
        self.portfolio.cash += proceeds

        trade = Trade(
            symbol=symbol,
            side=pos.side,
            entry_price=pos.entry_price,
            quantity=pos.quantity,
            entry_time=pos.entry_time,
            signal=pos.signal,
            confidence=pos.confidence,
            exit_price=price,
            exit_time=datetime.now(timezone.utc).isoformat(),
            exit_reason=reason,
            pnl=pnl,
        )
        self.portfolio.trade_history.append(trade)
        self.portfolio.total_trades += 1
        if pnl > 0:
            self.portfolio.winning_trades += 1
        elif pnl < 0:
            self.portfolio.losing_trades += 1

        pnl_emoji = "✅" if pnl >= 0 else "❌"
        self.log(
            f"{pnl_emoji} إغلاق {symbol} | P&L: ${pnl:+,.2f} ({pos.pnl_pct:+.2f}%) | "
            f"السبب: {reason}"
        )

        del self.portfolio.positions[symbol]

    def check_stop_loss_take_profit(self, symbol: str, current_price: float):
        if symbol not in self.portfolio.positions:
            return

        pos = self.portfolio.positions[symbol]
        pos.current_price = current_price

        if pos.side == "BUY":
            loss_pct = (current_price - pos.entry_price) / pos.entry_price
            if loss_pct <= -STOP_LOSS_PCT:
                self.close_position(symbol, current_price, f"وقف خسارة ({loss_pct*100:.1f}%)")
            elif loss_pct >= TAKE_PROFIT_PCT:
                self.close_position(symbol, current_price, f"جني أرباح ({loss_pct*100:.1f}%)")
        else:  # SELL (short)
            loss_pct = (pos.entry_price - current_price) / pos.entry_price
            if loss_pct <= -STOP_LOSS_PCT:
                self.close_position(symbol, current_price, f"وقف خسارة ({loss_pct*100:.1f}%)")
            elif loss_pct >= TAKE_PROFIT_PCT:
                self.close_position(symbol, current_price, f"جني أرباح ({loss_pct*100:.1f}%)")

    async def process_cycle(self):
        self.cycle_count += 1
        self.log(f"── دورة #{self.cycle_count} ──────────────────────")

        # Fetch flows and prices in parallel
        flows, prices = await asyncio.gather(
            fetch_all_flows(SYMBOLS),
            fetch_all_prices(SYMBOLS),
        )
        self.live_prices = prices

        for data in flows:
            if data.get("error"):
                symbol = data.get("symbol", "???")
                self.log(f"⚠️ {symbol}: بيانات غير متاحة")
                continue

            symbol = data["symbol"]
            price = prices.get(symbol, 0.0)
            if price <= 0:
                self.log(f"⚠️ {symbol}: سعر غير متاح من Binance")
                continue
            decision = analyze_signal(data)

            self.last_signals[symbol] = {
                "signal": data.get("signal"),
                "confidence": data.get("confidence"),
                "risk": data.get("risk"),
                "action": decision["action"],
                "reason": decision["reason"],
            }

            # Update existing position prices
            if symbol in self.portfolio.positions:
                self.portfolio.positions[symbol].current_price = price
                self.check_stop_loss_take_profit(symbol, price)

            # Execute trading logic
            action = decision["action"]

            if action == "CLOSE_ALL":
                self.log(f"🚨 {symbol}: {decision['reason']}")
                if symbol in self.portfolio.positions:
                    self.close_position(symbol, price, decision["reason"])

            elif action == "BUY":
                if symbol not in self.portfolio.positions:
                    self.log(f"📊 {symbol}: {decision['reason']}")
                    self.open_position(
                        symbol, "BUY", price,
                        decision.get("signal", ""),
                        decision.get("confidence", 0),
                        decision.get("size_factor", 0.5),
                    )
                elif self.portfolio.positions[symbol].side == "SELL":
                    self.close_position(symbol, price, "انعكاس إشارة → شراء")
                    self.open_position(
                        symbol, "BUY", price,
                        decision.get("signal", ""),
                        decision.get("confidence", 0),
                        decision.get("size_factor", 0.5),
                    )

            elif action == "SELL":
                if symbol not in self.portfolio.positions:
                    self.log(f"📊 {symbol}: {decision['reason']}")
                    self.open_position(
                        symbol, "SELL", price,
                        decision.get("signal", ""),
                        decision.get("confidence", 0),
                        decision.get("size_factor", 0.5),
                    )
                elif self.portfolio.positions[symbol].side == "BUY":
                    self.close_position(symbol, price, "انعكاس إشارة → بيع")
                    self.open_position(
                        symbol, "SELL", price,
                        decision.get("signal", ""),
                        decision.get("confidence", 0),
                        decision.get("size_factor", 0.5),
                    )

    def render_dashboard(self) -> str:
        if not HAS_RICH:
            return self._render_plain()

        console = Console(width=120, force_terminal=True)
        from io import StringIO
        buf = StringIO()
        c = Console(file=buf, width=120, force_terminal=True)

        # Header
        elapsed = datetime.now(timezone.utc) - self.start_time
        hours, rem = divmod(int(elapsed.total_seconds()), 3600)
        mins, secs = divmod(rem, 60)

        c.print(Panel(
            f"[bold cyan]HORUS PAPER TRADING BOT[/bold cyan]  |  "
            f"الدورة: #{self.cycle_count}  |  "
            f"الوقت: {hours:02d}:{mins:02d}:{secs:02d}  |  "
            f"الفحص كل {POLL_INTERVAL} ثانية",
            style="bold white on blue",
        ))

        # Portfolio Summary
        pnl_color = "green" if self.portfolio.total_pnl >= 0 else "red"
        summary_table = Table(title="📊 ملخص المحفظة", show_header=True, header_style="bold magenta")
        summary_table.add_column("رأس المال", justify="center")
        summary_table.add_column("القيمة الإجمالية", justify="center")
        summary_table.add_column("P&L", justify="center")
        summary_table.add_column("P&L %", justify="center")
        summary_table.add_column("الصفقات", justify="center")
        summary_table.add_column("نسبة الفوز", justify="center")
        summary_table.add_row(
            f"${INITIAL_CAPITAL:,.2f}",
            f"${self.portfolio.total_value:,.2f}",
            f"[{pnl_color}]${self.portfolio.total_pnl:+,.2f}[/{pnl_color}]",
            f"[{pnl_color}]{self.portfolio.total_pnl_pct:+.2f}%[/{pnl_color}]",
            f"{self.portfolio.total_trades}",
            f"{self.portfolio.win_rate:.0f}%",
        )
        c.print(summary_table)

        # Open Positions
        if self.portfolio.positions:
            pos_table = Table(title="📌 الصفقات المفتوحة", show_header=True, header_style="bold yellow")
            pos_table.add_column("العملة", justify="center")
            pos_table.add_column("الاتجاه", justify="center")
            pos_table.add_column("سعر الدخول", justify="right")
            pos_table.add_column("السعر الحالي", justify="right")
            pos_table.add_column("الكمية", justify="right")
            pos_table.add_column("P&L", justify="right")
            pos_table.add_column("الإشارة", justify="center")

            for sym, pos in self.portfolio.positions.items():
                pnl_c = "green" if pos.unrealized_pnl >= 0 else "red"
                side_display = "🟢 شراء" if pos.side == "BUY" else "🔴 بيع"
                pos_table.add_row(
                    sym,
                    side_display,
                    f"${pos.entry_price:,.2f}",
                    f"${pos.current_price:,.2f}",
                    f"{pos.quantity:.6f}",
                    f"[{pnl_c}]${pos.unrealized_pnl:+,.2f} ({pos.pnl_pct:+.2f}%)[/{pnl_c}]",
                    pos.signal,
                )
            c.print(pos_table)

        # Live Signals
        if self.last_signals:
            sig_table = Table(title="📡 إشارات Horus الحية", show_header=True, header_style="bold cyan")
            sig_table.add_column("العملة", justify="center")
            sig_table.add_column("الإشارة", justify="center")
            sig_table.add_column("الثقة", justify="center")
            sig_table.add_column("المخاطرة", justify="center")
            sig_table.add_column("القرار", justify="center")
            sig_table.add_column("السبب", justify="left")

            signal_colors = {
                "BUY_PRESSURE": "green",
                "STRONG_BUY_PRESSURE": "bold green",
                "INSTITUTIONAL_ACCUMULATION": "bold green",
                "SELL_PRESSURE": "red",
                "STRONG_SELL_PRESSURE": "bold red",
                "INSTITUTIONAL_DISTRIBUTION": "bold red",
                "LIQUIDITY_EVENT": "bold red on white",
                "NEUTRAL": "yellow",
            }

            for sym, info in self.last_signals.items():
                sig = info["signal"]
                sig_color = signal_colors.get(sig, "white")
                risk_color = {"LOW": "green", "MEDIUM": "yellow", "HIGH": "red", "EXTREME": "bold red"}.get(
                    info["risk"], "white"
                )
                action_color = {"BUY": "green", "SELL": "red", "HOLD": "yellow", "CLOSE_ALL": "bold red"}.get(
                    info["action"], "white"
                )
                sig_table.add_row(
                    sym,
                    f"[{sig_color}]{sig}[/{sig_color}]",
                    f"{info['confidence']:.2f}",
                    f"[{risk_color}]{info['risk']}[/{risk_color}]",
                    f"[{action_color}]{info['action']}[/{action_color}]",
                    info["reason"][:60],
                )
            c.print(sig_table)

        # Recent Trade History
        if self.portfolio.trade_history:
            hist_table = Table(title="📜 آخر الصفقات", show_header=True, header_style="bold white")
            hist_table.add_column("العملة", justify="center")
            hist_table.add_column("الاتجاه", justify="center")
            hist_table.add_column("الدخول", justify="right")
            hist_table.add_column("الخروج", justify="right")
            hist_table.add_column("P&L", justify="right")
            hist_table.add_column("السبب", justify="left")

            for trade in self.portfolio.trade_history[-5:]:
                pnl_c = "green" if trade.pnl >= 0 else "red"
                side_d = "🟢" if trade.side == "BUY" else "🔴"
                hist_table.add_row(
                    trade.symbol,
                    side_d,
                    f"${trade.entry_price:,.2f}",
                    f"${trade.exit_price:,.2f}" if trade.exit_price else "-",
                    f"[{pnl_c}]${trade.pnl:+,.2f}[/{pnl_c}]",
                    trade.exit_reason or "-",
                )
            c.print(hist_table)

        # Activity Log
        c.print(Panel(
            "\n".join(self.log_lines[-10:]),
            title="📋 سجل النشاط",
            style="dim",
        ))

        c.print(f"\n[dim]النقد المتاح: ${self.portfolio.cash:,.2f} | "
                f"اضغط Ctrl+C للإيقاف[/dim]")

        return buf.getvalue()

    def _render_plain(self) -> str:
        lines = []
        lines.append("=" * 70)
        lines.append(f"  HORUS PAPER TRADING BOT | Cycle #{self.cycle_count}")
        lines.append("=" * 70)
        lines.append(f"  Capital: ${INITIAL_CAPITAL:,.2f} | "
                      f"Value: ${self.portfolio.total_value:,.2f} | "
                      f"P&L: ${self.portfolio.total_pnl:+,.2f} ({self.portfolio.total_pnl_pct:+.2f}%)")
        lines.append(f"  Trades: {self.portfolio.total_trades} | "
                      f"Win Rate: {self.portfolio.win_rate:.0f}% | "
                      f"Cash: ${self.portfolio.cash:,.2f}")
        lines.append("-" * 70)

        if self.portfolio.positions:
            lines.append("  OPEN POSITIONS:")
            for sym, pos in self.portfolio.positions.items():
                side = "BUY" if pos.side == "BUY" else "SELL"
                lines.append(f"    {sym} | {side} | Entry: ${pos.entry_price:,.2f} | "
                              f"P&L: ${pos.unrealized_pnl:+,.2f}")

        if self.last_signals:
            lines.append("  SIGNALS:")
            for sym, info in self.last_signals.items():
                lines.append(f"    {sym}: {info['signal']} (conf: {info['confidence']:.2f}) → {info['action']}")

        lines.append("-" * 70)
        for line in self.log_lines[-8:]:
            lines.append(f"  {line}")
        lines.append("=" * 70)
        return "\n".join(lines)

    def save_state(self):
        state = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "cycle": self.cycle_count,
            "portfolio": {
                "cash": round(self.portfolio.cash, 2),
                "total_value": round(self.portfolio.total_value, 2),
                "total_pnl": round(self.portfolio.total_pnl, 2),
                "total_trades": self.portfolio.total_trades,
                "winning_trades": self.portfolio.winning_trades,
                "losing_trades": self.portfolio.losing_trades,
                "win_rate": round(self.portfolio.win_rate, 1),
            },
            "open_positions": {
                sym: {
                    "side": p.side,
                    "entry_price": p.entry_price,
                    "current_price": p.current_price,
                    "quantity": p.quantity,
                    "unrealized_pnl": round(p.unrealized_pnl, 2),
                }
                for sym, p in self.portfolio.positions.items()
            },
            "trade_history": [t.to_dict() for t in self.portfolio.trade_history],
        }
        with open("/home/ubuntu/horus-flow-mcp/paper_trades.json", "w") as f:
            json.dump(state, f, indent=2, ensure_ascii=False)

    async def run(self):
        self.log("🦅 Horus Paper Trading Bot — بدء التشغيل...")
        self.log(f"💰 رأس المال: ${INITIAL_CAPITAL:,.2f}")
        self.log(f"📊 العملات: {', '.join(SYMBOLS)}")
        self.log(f"⏱️ فترة الفحص: {POLL_INTERVAL} ثانية")
        self.log(f"🎯 أقل ثقة: {MIN_CONFIDENCE} | وقف خسارة: {STOP_LOSS_PCT*100}% | جني أرباح: {TAKE_PROFIT_PCT*100}%")
        self.log("")

        if HAS_RICH:
            with Live(self.render_dashboard(), refresh_per_second=0.5, console=self.console) as live:
                try:
                    while True:
                        await self.process_cycle()
                        self.save_state()
                        live.update(self.render_dashboard())
                        await asyncio.sleep(POLL_INTERVAL)
                except KeyboardInterrupt:
                    self.log("🛑 تم إيقاف البوت")
                    self.save_state()
        else:
            try:
                while True:
                    await self.process_cycle()
                    self.save_state()
                    print("\033c" + self.render_dashboard())
                    await asyncio.sleep(POLL_INTERVAL)
            except KeyboardInterrupt:
                self.log("🛑 تم إيقاف البوت")
                self.save_state()

        # Final summary
        print("\n" + "=" * 60)
        print("  📊 ملخص الجلسة النهائي")
        print("=" * 60)
        print(f"  إجمالي الصفقات: {self.portfolio.total_trades}")
        print(f"  الرابحة: {self.portfolio.winning_trades} | الخاسرة: {self.portfolio.losing_trades}")
        print(f"  نسبة الفوز: {self.portfolio.win_rate:.0f}%")
        print(f"  P&L: ${self.portfolio.total_pnl:+,.2f} ({self.portfolio.total_pnl_pct:+.2f}%)")
        print(f"  القيمة النهائية: ${self.portfolio.total_value:,.2f}")
        print("=" * 60)


# ─── Entry Point ──────────────────────────────────────────
if __name__ == "__main__":
    if not RAPIDAPI_KEY:
        print("❌ RAPIDAPI_KEY مطلوب. قم بتعيينه:")
        print("   export RAPIDAPI_KEY='your_key'")
        sys.exit(1)

    bot = PaperTradingBot()
    asyncio.run(bot.run())
