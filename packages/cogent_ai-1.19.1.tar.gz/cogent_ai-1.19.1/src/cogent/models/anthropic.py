"""
Anthropic models for Cogent.

Supports Claude models with Extended Thinking and Adaptive Thinking for complex reasoning tasks.

Usage:
    from cogent.models.anthropic import AnthropicChat

    # Standard usage
    llm = AnthropicChat()  # Uses claude-sonnet-4-6 by default
    response = await llm.ainvoke([{"role": "user", "content": "Hello!"}])

    # Adaptive thinking (recommended for claude-opus-4-6 and claude-sonnet-4-6)
    llm = AnthropicChat(model="claude-opus-4-6").with_adaptive_thinking(effort="high")
    response = await llm.ainvoke([{"role": "user", "content": "Solve this complex problem..."}])
    print(response.thinking)
    print(response.content)

    # Manual Extended Thinking (all thinking-capable models)
    llm = AnthropicChat(
        model="claude-sonnet-4-5-20250929",
        thinking_budget=16000,
    )
    response = await llm.ainvoke([{"role": "user", "content": "Solve this complex problem..."}])
    print(response.thinking)  # Access thinking content
    print(response.content)   # Access final response

    # Structured outputs (output_config / responses API)
    llm = AnthropicChat(output_schema={"type": "object", "properties": {"answer": {"type": "string"}}})
    response = await llm.ainvoke([{"role": "user", "content": "What is 2+2? Return JSON."}])

Models:
    Claude 4.6 series (latest, adaptive thinking):
    - claude-opus-4-6:         adaptive thinking, 1M context, 128k output
    - claude-sonnet-4-6:       adaptive + manual thinking, 1M context, 64k output

    Claude 4.5 series:
    - claude-opus-4-5-20251101:   manual thinking, 200k context
    - claude-sonnet-4-5-20250929: manual thinking, 200k context
    - claude-haiku-4-5-20251001:  manual thinking, 200k context

    Legacy thinking models:
    - claude-opus-4-20250514, claude-sonnet-4-20250514
    - claude-3-7-sonnet-20250219, claude-3-5-sonnet-20241022
"""

from __future__ import annotations

import time
import uuid
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any

from cogent.core.messages import MessageMetadata, TokenUsage
from cogent.models.base import (
    AIMessage,
    BaseChatModel,
    convert_messages,
    normalize_input,
)

# Models that support Extended Thinking (manual budget_tokens mode)
THINKING_MODELS = {
    # Claude 4.6 series — also support adaptive thinking
    "claude-opus-4-6",
    "claude-sonnet-4-6",
    # Claude 4.5 series
    "claude-opus-4-5-20251101",
    "claude-sonnet-4-5-20250929",
    "claude-haiku-4-5-20251001",
    # Claude 4.1
    "claude-opus-4-1-20250805",
    # Claude 4 (May 2025)
    "claude-opus-4-20250514",
    "claude-opus-4-0",
    "claude-sonnet-4-20250514",
    "claude-sonnet-4-0",
    # Claude 3.7
    "claude-3-7-sonnet-20250219",
    "claude-3-7-sonnet",
    # Claude 3.5 (some versions)
    "claude-3-5-sonnet-20241022",
}

# Models that support adaptive thinking (thinking.type: "adaptive").
# budget_tokens is deprecated on these models; use effort instead.
ADAPTIVE_THINKING_MODELS = {
    "claude-opus-4-6",
    "claude-sonnet-4-6",
}

# Models where the effort parameter is supported via output_config.effort.
EFFORT_MODELS = {
    "claude-opus-4-6",
    "claude-sonnet-4-6",
    "claude-opus-4-5-20251101",
}

# Structured outputs (output_config.format) are supported on these models.
STRUCTURED_OUTPUT_MODELS = {
    "claude-opus-4-6",
    "claude-sonnet-4-6",
    "claude-opus-4-5-20251101",
    "claude-sonnet-4-5-20250929",
    "claude-haiku-4-5-20251001",
}


def _messages_to_anthropic(
    messages: list[dict[str, Any]],
) -> tuple[str | None, list[dict[str, Any]]]:
    """Convert messages to Anthropic format, extracting system message."""
    system = None
    anthropic_messages = []

    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content", "")

        if role == "system":
            system = content
        elif role == "user":
            anthropic_messages.append({"role": "user", "content": content})
        elif role == "assistant":
            tool_calls = msg.get("tool_calls", [])
            if tool_calls:
                # Anthropic uses content blocks for tool use
                content_blocks = []
                if content:
                    content_blocks.append({"type": "text", "text": content})
                for tc in tool_calls:
                    content_blocks.append(
                        {
                            "type": "tool_use",
                            "id": tc.get("id", ""),
                            "name": tc.get(
                                "name", tc.get("function", {}).get("name", "")
                            ),
                            "input": tc.get(
                                "args", tc.get("function", {}).get("arguments", {})
                            ),
                        }
                    )
                anthropic_messages.append(
                    {"role": "assistant", "content": content_blocks}
                )
            else:
                anthropic_messages.append({"role": "assistant", "content": content})
        elif role == "tool":
            anthropic_messages.append(
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": msg.get("tool_call_id", ""),
                            "content": content,
                        }
                    ],
                }
            )

    return system, anthropic_messages


_ANTHROPIC_UNSUPPORTED_FIELDS = frozenset({"$defs", "$ref", "$schema", "$id", "title"})


def _resolve_refs(schema: dict[str, Any], defs: dict[str, Any]) -> dict[str, Any]:
    """Inline $ref references using the $defs map (single-level resolution)."""
    if "$ref" in schema:
        ref = schema["$ref"]
        # JSON Schema $ref like "#/$defs/MyModel"
        if ref.startswith("#/$defs/"):
            name = ref[len("#/$defs/") :]
            resolved = defs.get(name, {})
            # Merge any sibling keys (e.g. description) into the resolved schema
            merged = {**resolved}
            for k, v in schema.items():
                if k != "$ref":
                    merged[k] = v
            return _clean_schema_for_anthropic(merged, defs)
        # Unknown $ref — drop it
        return {}
    return schema


def _clean_schema_for_anthropic(
    schema: dict[str, Any], defs: dict[str, Any] | None = None
) -> dict[str, Any]:
    """Recursively clean a JSON Schema for Anthropic compatibility.

    Strips Pydantic v2 extras ($defs, $ref, title, $schema, $id) and inlines
    $ref references so the schema is fully resolved before sending to the API.
    """
    if not isinstance(schema, dict):
        return schema

    if defs is None:
        defs = schema.get("$defs", {})

    # Resolve $ref first
    if "$ref" in schema:
        schema = _resolve_refs(schema, defs)
        if not schema:
            return {}

    result: dict[str, Any] = {}
    for key, value in schema.items():
        if key in _ANTHROPIC_UNSUPPORTED_FIELDS:
            continue
        if key == "properties" and isinstance(value, dict):
            result["properties"] = {
                k: _clean_schema_for_anthropic(v, defs) for k, v in value.items()
            }
        elif key == "items" and isinstance(value, dict):
            result["items"] = _clean_schema_for_anthropic(value, defs)
        elif key in ("anyOf", "oneOf", "allOf") and isinstance(value, list):
            result[key] = [
                _clean_schema_for_anthropic(s, defs)
                for s in value
                if isinstance(s, dict)
            ]
        elif key == "additionalProperties" and isinstance(value, dict):
            result["additionalProperties"] = _clean_schema_for_anthropic(value, defs)
        else:
            result[key] = value
    return result


def _tools_to_anthropic(tools: list[Any]) -> list[dict[str, Any]]:
    """Convert tools to Anthropic format.

    Anthropic requires input_schema to be a proper JSON Schema object
    with {"type": "object", "properties": {...}}.
    """
    anthropic_tools = []
    for tool in tools:
        if hasattr(tool, "to_dict"):
            # Use the canonical to_dict() which produces proper JSON Schema.
            openai_fmt = tool.to_dict()
            func = openai_fmt.get("function", {})
            params = func.get("parameters", {}) or {}
            if "type" not in params:
                params = {"type": "object", "properties": params}
            params = _clean_schema_for_anthropic(params)
            params.setdefault(
                "type", "object"
            )  # Anthropic requires type:object in input_schema
            anthropic_tools.append(
                {
                    "name": func["name"],
                    "description": func.get("description", ""),
                    "input_schema": params,
                }
            )
        elif hasattr(tool, "name") and hasattr(tool, "description"):
            schema = getattr(tool, "args_schema", None)
            # Resolve Pydantic model → JSON Schema dict
            if schema is not None and hasattr(schema, "model_json_schema"):
                schema = schema.model_json_schema()
            elif schema is not None and hasattr(schema, "schema"):
                schema = schema.schema()
            if not isinstance(schema, dict) or not schema:
                schema = {"type": "object", "properties": {}}
            elif "type" not in schema and "properties" not in schema:
                # Flat dict format: {"param": {"type": "string"}}
                schema = {
                    "type": "object",
                    "properties": schema,
                    "required": list(schema.keys()),
                }
            elif "type" not in schema:
                schema = {"type": "object", **schema}
            schema = _clean_schema_for_anthropic(schema)
            schema.setdefault(
                "type", "object"
            )  # Anthropic requires type:object in input_schema
            anthropic_tools.append(
                {
                    "name": tool.name,
                    "description": tool.description or "",
                    "input_schema": schema,
                }
            )
        elif isinstance(tool, dict):
            # Handle OpenAI format
            if "function" in tool:
                func = tool["function"]
                params = func.get("parameters", {}) or {}
                if "type" not in params:
                    params = {"type": "object", "properties": params}
                params = _clean_schema_for_anthropic(params)
                params.setdefault(
                    "type", "object"
                )  # Anthropic requires type:object in input_schema
                anthropic_tools.append(
                    {
                        "name": func["name"],
                        "description": func.get("description", ""),
                        "input_schema": params,
                    }
                )
            else:
                anthropic_tools.append(tool)
    return anthropic_tools


def _parse_response(response: Any, include_thinking: bool = False) -> AIMessage:
    """Parse Anthropic response into AIMessage with metadata.

    Args:
        response: Anthropic API response.
        include_thinking: Whether to include thinking blocks in response.

    Returns:
        AIMessage with content, tool_calls, thinking (if enabled), and metadata.
        When stop_reason is ``"refusal"``, finish_reason is set to ``"refusal"``
        and the response content may be empty or contain a short refusal message.
    """
    from cogent.core.messages import MessageMetadata, TokenUsage

    content = ""
    thinking = ""
    thinking_signature = None
    tool_calls = []

    for block in response.content:
        if block.type == "thinking":
            # Extended thinking block
            thinking += block.thinking
            if hasattr(block, "signature"):
                thinking_signature = block.signature
        elif block.type == "text":
            content += block.text
        elif block.type == "tool_use":
            tool_calls.append(
                {
                    "id": block.id,
                    "name": block.name,
                    "args": block.input,
                }
            )

    # Thinking tokens are billed as part of output_tokens; there is no separate
    # field in the Usage response for them as of SDK 0.86.
    reasoning_tokens = None

    metadata = MessageMetadata(
        model=response.model,
        tokens=TokenUsage(
            prompt_tokens=response.usage.input_tokens
            if hasattr(response.usage, "input_tokens")
            else 0,
            completion_tokens=response.usage.output_tokens
            if hasattr(response.usage, "output_tokens")
            else 0,
            total_tokens=(response.usage.input_tokens + response.usage.output_tokens)
            if hasattr(response.usage, "input_tokens")
            else 0,
            reasoning_tokens=reasoning_tokens,
        )
        if hasattr(response, "usage") and response.usage
        else None,
        finish_reason=response.stop_reason
        if hasattr(response, "stop_reason")
        else None,
        response_id=response.id if hasattr(response, "id") else None,
    )

    # Create AIMessage with thinking if present
    msg = AIMessage(
        content=content,
        tool_calls=tool_calls,
        metadata=metadata,
    )

    # Add thinking as attribute if present
    if thinking and include_thinking:
        msg.thinking = thinking
        if thinking_signature:
            msg.thinking_signature = thinking_signature

    return msg


@dataclass
class AnthropicChat(BaseChatModel):
    """Anthropic chat model with Extended Thinking and Adaptive Thinking support.

    High-performance chat model using Anthropic SDK directly.
    Supports Claude 4.6, Claude 4.5, Claude 3.7, and other Anthropic models.

    **Adaptive thinking** (recommended for claude-opus-4-6 and claude-sonnet-4-6):
        Use ``with_adaptive_thinking()`` or set ``adaptive_thinking=True``.
        Claude dynamically determines when and how much to think.

    **Extended thinking** (manual budget): Set ``thinking_budget`` to a token count.
        Still supported on all thinking-capable models but deprecated on 4.6 series.

    **Structured outputs** (responses API): Set ``output_schema`` to a JSON Schema dict.
        Claude guarantees structurally valid JSON matching the schema.

    Example:
        from cogent.models.anthropic import AnthropicChat

        # Simple usage
        llm = AnthropicChat()  # Uses claude-sonnet-4-6 by default
        response = await llm.ainvoke([{"role": "user", "content": "Hello!"}])

        # Adaptive thinking (claude-opus-4-6 or claude-sonnet-4-6)
        llm = AnthropicChat(model="claude-opus-4-6").with_adaptive_thinking()
        response = await llm.ainvoke("Solve this complex problem...")
        print(response.thinking)
        print(response.content)

        # With effort level (controls token spend)
        llm = AnthropicChat(model="claude-opus-4-6\", effort=\"medium\")

        # Structured outputs
        schema = {\"type\": \"object\", \"properties\": {\"answer\": {\"type\": \"string\"}}}
        llm = AnthropicChat(output_schema=schema)

        # With tools
        llm = AnthropicChat().bind_tools([search_tool, calc_tool])
        response = await llm.ainvoke(messages)

        # Streaming (includes thinking chunks when enabled)
        async for chunk in llm.astream(messages):
            print(chunk.content, end=\"\")

    Attributes:
        model: Model name (default: claude-sonnet-4-6).
        thinking_budget: Token budget for manual Extended Thinking. Minimum 1024.
            Deprecated on claude-opus-4-6 and claude-sonnet-4-6 — prefer adaptive_thinking.
        adaptive_thinking: Enable adaptive thinking mode (claude-opus-4-6 / sonnet-4-6 only).
        effort: Effort level for output_config: \"max\" | \"high\" | \"medium\" | \"low\".
            \"max\" is Opus 4.6 only. Controls token spend and thinking depth.
        thinking_display: How thinking content is returned: \"summarized\" (default) | \"omitted\".
            \"omitted\" reduces streaming latency; you're still billed for full thinking tokens.
        output_schema: JSON Schema dict for structured outputs via output_config.format.
            Guarantees valid JSON matching the schema on supported models.
        temperature: Only used when thinking is disabled (0.0-2.0).
            Extended Thinking requires temperature=1 (set automatically).
    """

    model: str = "claude-sonnet-4-6"
    thinking_budget: int | None = field(default=None)
    adaptive_thinking: bool = field(default=False)
    effort: str | None = field(default=None)
    thinking_display: str | None = field(default=None)
    output_schema: dict[str, Any] | None = field(default=None)

    # Internal state
    _include_thinking_in_response: bool = field(default=True, repr=False)

    def _init_client(self) -> None:
        """Initialize Anthropic clients."""
        try:
            from anthropic import Anthropic, AsyncAnthropic
        except ImportError:
            raise ImportError(
                "anthropic package required. Install with: uv add anthropic"
            ) from None

        from cogent.config import get_api_key

        api_key = get_api_key("anthropic", self.api_key)

        kwargs: dict[str, Any] = {
            "timeout": self.timeout,
            "max_retries": self.max_retries,
        }
        if api_key:
            kwargs["api_key"] = api_key

        self._client = Anthropic(**kwargs)
        self._async_client = AsyncAnthropic(**kwargs)

    def bind_tools(
        self,
        tools: list[Any],
        *,
        parallel_tool_calls: bool = True,
    ) -> AnthropicChat:
        """Bind tools to the model."""
        self._ensure_initialized()

        new_model = AnthropicChat(
            model=self.model,
            temperature=self.temperature,
            max_tokens=self.max_tokens or 4096,  # Anthropic requires max_tokens
            api_key=self.api_key,
            timeout=self.timeout,
            max_retries=self.max_retries,
            thinking_budget=self.thinking_budget,
            adaptive_thinking=self.adaptive_thinking,
            effort=self.effort,
            thinking_display=self.thinking_display,
            output_schema=self.output_schema,
        )
        new_model._tools = tools
        new_model._parallel_tool_calls = parallel_tool_calls
        new_model._include_thinking_in_response = self._include_thinking_in_response
        new_model._client = self._client
        new_model._async_client = self._async_client
        new_model._initialized = True
        return new_model

    def with_thinking(
        self,
        budget: int = 16000,
        *,
        include_in_response: bool = True,
        display: str | None = None,
    ) -> AnthropicChat:
        """Enable manual Extended Thinking with a fixed token budget.

        Extended Thinking allows the model to reason through complex problems
        before providing a response, significantly improving accuracy.

        For claude-opus-4-6 and claude-sonnet-4-6, prefer ``with_adaptive_thinking()``
        as ``budget_tokens`` is deprecated on those models.

        Args:
            budget: Token budget for thinking (minimum 1024, recommended 10000-32000).
            include_in_response: Whether to include thinking in response (default True).
            display: How to return thinking content: ``"summarized"`` (default) or
                ``"omitted"`` (faster streaming TTFT, still billed for full tokens).

        Returns:
            New AnthropicChat instance with thinking enabled.

        Example:
            llm = AnthropicChat(model="claude-sonnet-4-5-20250929").with_thinking(budget=16000)
            response = await llm.ainvoke("What's 127 * 893?")
            print(response.thinking)
            print(response.content)

        Note:
            - Extended Thinking requires temperature=1 (set automatically)
            - Minimum budget is 1024 tokens
            - Supported on Claude 4, Claude 3.7 Sonnet, Claude 3.5 Sonnet (20241022+)
            - On claude-opus-4-6 / claude-sonnet-4-6, use with_adaptive_thinking() instead
        """
        if budget < 1024:
            raise ValueError("thinking_budget must be at least 1024 tokens")

        self._ensure_initialized()

        new_model = AnthropicChat(
            model=self.model,
            temperature=self.temperature,
            max_tokens=self.max_tokens or 16000,  # Higher default for thinking
            api_key=self.api_key,
            timeout=self.timeout,
            max_retries=self.max_retries,
            thinking_budget=budget,
            thinking_display=display,
        )
        new_model._tools = getattr(self, "_tools", [])
        new_model._parallel_tool_calls = getattr(self, "_parallel_tool_calls", True)
        new_model._include_thinking_in_response = include_in_response
        new_model._client = self._client
        new_model._async_client = self._async_client
        new_model._initialized = True
        return new_model

    def with_adaptive_thinking(
        self,
        effort: str | None = None,
        *,
        include_in_response: bool = True,
        display: str | None = None,
    ) -> AnthropicChat:
        """Enable adaptive thinking mode (claude-opus-4-6 / claude-sonnet-4-6 only).

        In adaptive mode Claude dynamically decides when and how much to think
        based on request complexity. This is the recommended replacement for
        manual ``budget_tokens`` on the 4.6 model series.

        Adaptive thinking automatically enables interleaved thinking (thinking
        between tool calls), which is especially effective for agentic workflows.

        Args:
            effort: Thinking depth guidance: ``"max"`` | ``"high"`` (default) |
                ``"medium"`` | ``"low"``. ``"max"`` is Opus 4.6 only.
            include_in_response: Whether to include thinking in response (default True).
            display: How to return thinking content: ``"summarized"`` (default) or
                ``"omitted"`` (faster streaming TTFT, still billed for full tokens).

        Returns:
            New AnthropicChat instance with adaptive thinking enabled.

        Example:
            llm = AnthropicChat(model="claude-opus-4-6").with_adaptive_thinking()
            response = await llm.ainvoke("Solve this hard math problem")
            print(response.thinking)

            # Lower effort for speed/cost trade-off
            llm = AnthropicChat(model="claude-sonnet-4-6").with_adaptive_thinking(effort="medium")
        """
        self._ensure_initialized()

        new_model = AnthropicChat(
            model=self.model,
            temperature=self.temperature,
            max_tokens=self.max_tokens or 16000,
            api_key=self.api_key,
            timeout=self.timeout,
            max_retries=self.max_retries,
            adaptive_thinking=True,
            effort=effort,
            thinking_display=display,
        )
        new_model._tools = getattr(self, "_tools", [])
        new_model._parallel_tool_calls = getattr(self, "_parallel_tool_calls", True)
        new_model._include_thinking_in_response = include_in_response
        new_model._client = self._client
        new_model._async_client = self._async_client
        new_model._initialized = True
        return new_model

    def invoke(self, messages: str | list[dict[str, Any]] | list[Any]) -> AIMessage:
        """Invoke synchronously.

        Args:
            messages: Can be a string, list of dicts, or list of message objects.
        """
        self._ensure_initialized()
        response = self._client.messages.create(
            **self._build_request(normalize_input(messages))
        )
        return _parse_response(
            response,
            include_thinking=self._include_thinking_in_response
            and (self.thinking_budget is not None or self.adaptive_thinking),
        )

    async def ainvoke(
        self, messages: str | list[dict[str, Any]] | list[Any]
    ) -> AIMessage:
        """Invoke asynchronously.

        Args:
            messages: Can be a string, list of dicts, or list of message objects.
        """
        self._ensure_initialized()
        response = await self._async_client.messages.create(
            **self._build_request(normalize_input(messages))
        )
        return _parse_response(
            response,
            include_thinking=self._include_thinking_in_response
            and (self.thinking_budget is not None or self.adaptive_thinking),
        )

    async def astream(
        self, messages: str | list[dict[str, Any]] | list[Any]
    ) -> AsyncIterator[AIMessage]:
        """Stream response asynchronously with metadata.

        When Extended Thinking is enabled, yields thinking chunks first,
        followed by text chunks. Each chunk has appropriate metadata.

        Args:
            messages: Can be a string, list of dicts, or list of message objects.

        Yields:
            AIMessage objects with incremental content and metadata.
            - If thinking enabled: thinking chunks have `is_thinking=True` in metadata
            - Final chunk has complete token usage
        """
        self._ensure_initialized()
        kwargs = self._build_request(normalize_input(messages))

        start_time = time.time()
        chunk_metadata: dict[str, Any] = {
            "id": None,
            "model": None,
            "finish_reason": None,
            "usage": None,
        }
        accumulated_thinking = ""

        async with self._async_client.messages.stream(**kwargs) as stream:
            # Handle raw events for thinking support
            async for event in stream:
                # Update metadata from message snapshots
                if hasattr(stream, "current_message_snapshot"):
                    msg = stream.current_message_snapshot
                    if hasattr(msg, "id") and msg.id:
                        chunk_metadata["id"] = msg.id
                    if hasattr(msg, "model") and msg.model:
                        chunk_metadata["model"] = msg.model
                    if hasattr(msg, "stop_reason") and msg.stop_reason:
                        chunk_metadata["finish_reason"] = msg.stop_reason
                    if hasattr(msg, "usage") and msg.usage:
                        chunk_metadata["usage"] = msg.usage

                # Handle different event types
                event_type = getattr(event, "type", None)

                # Thinking delta (Extended Thinking)
                if event_type == "content_block_delta":
                    delta = getattr(event, "delta", None)
                    if delta:
                        delta_type = getattr(delta, "type", None)

                        # Thinking content
                        if delta_type == "thinking_delta":
                            thinking_text = getattr(delta, "thinking", "")
                            if thinking_text and self._include_thinking_in_response:
                                accumulated_thinking += thinking_text
                                metadata = MessageMetadata(
                                    id=str(uuid.uuid4()),
                                    timestamp=time.time(),
                                    model=chunk_metadata.get("model"),
                                    tokens=None,
                                    finish_reason=None,
                                    response_id=chunk_metadata.get("id"),
                                    duration=time.time() - start_time,
                                    is_thinking=True,  # Mark as thinking chunk
                                )
                                msg = AIMessage(content="", metadata=metadata)
                                msg.thinking = thinking_text
                                yield msg

                        # Regular text content
                        elif delta_type == "text_delta":
                            text = getattr(delta, "text", "")
                            if text:
                                metadata = MessageMetadata(
                                    id=str(uuid.uuid4()),
                                    timestamp=time.time(),
                                    model=chunk_metadata.get("model"),
                                    tokens=None,
                                    finish_reason=chunk_metadata.get("finish_reason"),
                                    response_id=chunk_metadata.get("id"),
                                    duration=time.time() - start_time,
                                )
                                yield AIMessage(content=text, metadata=metadata)

            # Yield final metadata chunk with complete usage
            if hasattr(stream, "current_message_snapshot"):
                msg = stream.current_message_snapshot
                if hasattr(msg, "usage") and msg.usage:
                    final_metadata = MessageMetadata(
                        id=str(uuid.uuid4()),
                        timestamp=time.time(),
                        model=chunk_metadata.get("model"),
                        tokens=TokenUsage(
                            prompt_tokens=msg.usage.input_tokens,
                            completion_tokens=msg.usage.output_tokens,
                            total_tokens=msg.usage.input_tokens
                            + msg.usage.output_tokens,
                        ),
                        finish_reason=chunk_metadata.get("finish_reason"),
                        response_id=chunk_metadata.get("id"),
                        duration=time.time() - start_time,
                    )
                    final_msg = AIMessage(content="", metadata=final_metadata)
                    if accumulated_thinking and self._include_thinking_in_response:
                        final_msg.thinking = accumulated_thinking
                    yield final_msg

    def _build_request(
        self, messages: list[dict[str, Any]] | list[Any]
    ) -> dict[str, Any]:
        """Build API request with Extended Thinking and Adaptive Thinking support."""
        # Convert to standard format first
        formatted = convert_messages(messages)
        system, anthropic_messages = _messages_to_anthropic(formatted)

        kwargs: dict[str, Any] = {
            "model": self.model,
            "messages": anthropic_messages,
            "max_tokens": self.max_tokens or 4096,  # Anthropic requires max_tokens
        }

        thinking_enabled = self.adaptive_thinking or self.thinking_budget is not None

        if self.adaptive_thinking:
            # Adaptive thinking: Claude 4.6 series only
            # thinking.type = "adaptive", effort goes in output_config
            if self.model not in ADAPTIVE_THINKING_MODELS and not any(
                self.model.startswith(p)
                for p in ("claude-opus-4-6", "claude-sonnet-4-6")
            ):
                raise ValueError(
                    f"Adaptive thinking is only supported on {sorted(ADAPTIVE_THINKING_MODELS)}. "
                    f"Model {self.model!r} does not support it. "
                    "Use with_thinking() for manual budget-based thinking on older models."
                )
            thinking_cfg: dict[str, Any] = {"type": "adaptive"}
            if self.thinking_display:
                thinking_cfg["display"] = self.thinking_display
            kwargs["thinking"] = thinking_cfg
            # max_tokens must exceed typical thinking allocation
            if kwargs["max_tokens"] < 16000:
                kwargs["max_tokens"] = 16000
            # Adaptive thinking requires temperature=1
            kwargs["temperature"] = 1

        elif self.thinking_budget is not None:
            # Manual Extended Thinking (budget_tokens mode)
            if self.model not in THINKING_MODELS:
                is_thinking_model = any(
                    self.model.startswith(prefix)
                    for prefix in (
                        "claude-opus-4",
                        "claude-sonnet-4",
                        "claude-haiku-4",
                        "claude-3-7-sonnet",
                        "claude-3-5-sonnet-2024",
                    )
                )
                if not is_thinking_model:
                    raise ValueError(
                        f"Model {self.model!r} does not support Extended Thinking. "
                        "Use claude-opus-4-*, claude-sonnet-4-*, or claude-3-7-sonnet-*"
                    )

            # max_tokens must exceed thinking_budget (Anthropic requirement)
            if kwargs["max_tokens"] <= self.thinking_budget:
                kwargs["max_tokens"] = self.thinking_budget + 1024

            thinking_cfg = {
                "type": "enabled",
                "budget_tokens": self.thinking_budget,
            }
            if self.thinking_display:
                thinking_cfg["display"] = self.thinking_display
            kwargs["thinking"] = thinking_cfg
            # Extended Thinking requires temperature=1 (Anthropic enforces this)
            kwargs["temperature"] = 1

        else:
            # Normal mode - use specified temperature
            kwargs["temperature"] = self.temperature

        # output_config: effort and/or structured output schema
        output_config: dict[str, Any] = {}
        if self.effort:
            output_config["effort"] = self.effort
        if self.output_schema:
            clean_schema = _clean_schema_for_anthropic(self.output_schema)
            output_config["format"] = {
                "type": "json_schema",
                "schema": clean_schema,
            }
        if output_config:
            kwargs["output_config"] = output_config

        if system:
            kwargs["system"] = system
        if self._tools:
            kwargs["tools"] = _tools_to_anthropic(self._tools)
            kwargs["tool_choice"] = {
                "type": "auto",
                "disable_parallel_tool_use": not self._parallel_tool_calls,
            }
        return kwargs
