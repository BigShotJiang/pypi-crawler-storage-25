"""
Custom OpenAI-compatible models for Cogent.

Supports any OpenAI-compatible API endpoint like:
- vLLM
- LiteLLM
- LocalAI
- Together AI
- Anyscale
- Custom deployments

Usage:
    from cogent.models.custom import CustomChat, CustomEmbedding

    # vLLM endpoint
    llm = CustomChat(
        base_url="http://localhost:8000/v1",
        model="meta-llama/Llama-3.2-3B-Instruct",
    )

    # Together AI
    llm = CustomChat(
        base_url="https://api.together.xyz/v1",
        api_key="your-key",
        model="meta-llama/Llama-3.2-3B-Instruct-Turbo",
    )
"""

from __future__ import annotations

import os
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

from cogent.core.messages import (
    EmbeddingMetadata,
    EmbeddingResult,
    MessageMetadata,
    TokenUsage,
)
from cogent.models.base import (
    AIMessage,
    BaseChatModel,
    BaseEmbedding,
    normalize_input,
)


def _format_tools(tools: list[Any]) -> list[dict[str, Any]]:
    """Convert tools to API format."""
    formatted = []
    for tool in tools:
        if hasattr(tool, "to_dict"):
            formatted.append(tool.to_dict())
        elif hasattr(tool, "to_openai"):  # backward compat
            formatted.append(tool.to_openai())
        elif hasattr(tool, "name") and hasattr(tool, "description"):
            schema = getattr(tool, "args_schema", {}) or {}
            formatted.append(
                {
                    "type": "function",
                    "function": {
                        "name": tool.name,
                        "description": tool.description or "",
                        "parameters": schema,
                    },
                }
            )
        elif isinstance(tool, dict):
            formatted.append(tool)
    return formatted


def _parse_response(response: Any) -> AIMessage:
    """Parse OpenAI-compatible response into AIMessage with metadata."""

    choice = response.choices[0]
    message = choice.message

    tool_calls = []
    if message.tool_calls:
        for tc in message.tool_calls:
            args = tc.function.arguments
            if isinstance(args, str):
                args = __import__("json").loads(args)
            tool_calls.append(
                {
                    "id": tc.id,
                    "name": tc.function.name,
                    "args": args,
                }
            )

    metadata = MessageMetadata(
        model=response.model if hasattr(response, "model") else None,
        tokens=TokenUsage(
            prompt_tokens=response.usage.prompt_tokens
            if hasattr(response, "usage") and response.usage
            else 0,
            completion_tokens=response.usage.completion_tokens
            if hasattr(response, "usage") and response.usage
            else 0,
            total_tokens=response.usage.total_tokens
            if hasattr(response, "usage") and response.usage
            else 0,
        )
        if hasattr(response, "usage") and response.usage
        else None,
        finish_reason=choice.finish_reason
        if hasattr(choice, "finish_reason")
        else None,
        response_id=response.id if hasattr(response, "id") else None,
    )

    return AIMessage(
        content=message.content or "",
        tool_calls=tool_calls,
        metadata=metadata,
    )


@dataclass
class CustomChat(BaseChatModel):
    """Custom OpenAI-compatible chat model.

    Use with any API that implements the OpenAI chat completions format.

    Example:
        from cogent.models.custom import CustomChat

        # vLLM locally
        llm = CustomChat(
            base_url="http://localhost:8000/v1",
            model="meta-llama/Llama-3.2-3B-Instruct",
        )

        # Together AI
        llm = CustomChat(
            base_url="https://api.together.xyz/v1",
            api_key=os.environ["TOGETHER_API_KEY"],
            model="meta-llama/Llama-3.2-3B-Instruct-Turbo",
        )

        # LiteLLM proxy
        llm = CustomChat(
            base_url="http://localhost:4000/v1",
            model="gpt-5.4",  # Route to configured backend
        )

        # Anyscale
        llm = CustomChat(
            base_url="https://api.endpoints.anyscale.com/v1",
            api_key="your-key",
            model="meta-llama/Llama-3-8b-chat-hf",
        )

        response = await llm.ainvoke([{"role": "user", "content": "Hello!"}])
    """

    model: str = "gpt-3.5-turbo"  # Default, should be overridden
    base_url: str = "http://localhost:8000/v1"

    def _init_client(self) -> None:
        """Initialize OpenAI-compatible client."""
        try:
            from openai import AsyncOpenAI, OpenAI
        except ImportError:
            raise ImportError(
                "openai package required. Install with: uv add openai"
            ) from None

        # Support various env var patterns
        api_key = self.api_key
        if not api_key:
            for env_var in ["CUSTOM_API_KEY", "OPENAI_API_KEY", "API_KEY"]:
                api_key = os.environ.get(env_var)
                if api_key:
                    break

        # Some endpoints don't need API key
        if not api_key:
            api_key = "not-needed"

        self._client = OpenAI(
            base_url=self.base_url,
            api_key=api_key,
            timeout=self.timeout,
            max_retries=self.max_retries,
        )
        self._async_client = AsyncOpenAI(
            base_url=self.base_url,
            api_key=api_key,
            timeout=self.timeout,
            max_retries=self.max_retries,
        )

    def bind_tools(
        self,
        tools: list[Any],
        *,
        parallel_tool_calls: bool = True,
    ) -> CustomChat:
        """Bind tools to the model."""
        self._ensure_initialized()

        new_model = CustomChat(
            model=self.model,
            base_url=self.base_url,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            api_key=self.api_key,
            timeout=self.timeout,
            max_retries=self.max_retries,
        )
        new_model._tools = tools
        new_model._parallel_tool_calls = parallel_tool_calls
        new_model._client = self._client
        new_model._async_client = self._async_client
        new_model._initialized = True
        return new_model

    def invoke(self, messages: str | list[dict[str, Any]] | list[Any]) -> AIMessage:
        """Invoke synchronously.

        Args:
            messages: Can be a string, list of dicts, or list of message objects.
        """
        self._ensure_initialized()
        response = self._client.chat.completions.create(
            **self._build_request(normalize_input(messages))
        )
        return _parse_response(response)

    async def ainvoke(
        self, messages: str | list[dict[str, Any]] | list[Any]
    ) -> AIMessage:
        """Invoke asynchronously.

        Args:
            messages: Can be a string, list of dicts, or list of message objects.
        """
        self._ensure_initialized()
        response = await self._async_client.chat.completions.create(
            **self._build_request(normalize_input(messages))
        )
        return _parse_response(response)

    async def astream(self, messages: list[dict[str, Any]]) -> AsyncIterator[AIMessage]:
        """Stream response asynchronously."""
        self._ensure_initialized()
        kwargs = self._build_request(messages)
        kwargs["stream"] = True

        async for chunk in await self._async_client.chat.completions.create(**kwargs):
            if chunk.choices and chunk.choices[0].delta.content:
                yield AIMessage(content=chunk.choices[0].delta.content)

    def _build_request(
        self, messages: list[dict[str, Any]] | list[Any]
    ) -> dict[str, Any]:
        """Build API request.

        Args:
            messages: List of messages - can be dicts or BaseMessage objects.

        Returns:
            Dict of API request parameters.
        """
        from cogent.core.messages import BaseMessage

        # Convert message objects to dicts if needed
        formatted_messages = []
        for msg in messages:
            if isinstance(msg, dict):
                formatted_messages.append(msg)
            elif isinstance(msg, BaseMessage):
                formatted_messages.append(msg.to_dict())
            else:
                # Try to use to_dict() method if available
                if hasattr(msg, "to_dict"):
                    formatted_messages.append(msg.to_dict())
                elif hasattr(msg, "to_openai"):  # backward compat
                    formatted_messages.append(msg.to_openai())
                else:
                    raise TypeError(f"Unsupported message type: {type(msg)}")

        kwargs: dict[str, Any] = {
            "model": self.model,
            "messages": formatted_messages,
            "temperature": self.temperature,
        }
        if self.max_tokens:
            kwargs["max_tokens"] = self.max_tokens
        if self._tools:
            kwargs["tools"] = _format_tools(self._tools)
            kwargs["parallel_tool_calls"] = self._parallel_tool_calls
        return kwargs


@dataclass
class CustomEmbedding(BaseEmbedding):
    """Custom OpenAI-compatible embedding model.

    Use with any API that implements the OpenAI embeddings format.

    Example:
        from cogent.models.custom import CustomEmbedding

        # vLLM embedding
        embedder = CustomEmbedding(
            base_url="http://localhost:8000/v1",
            model="BAAI/bge-small-en-v1.5",
        )

        # Together AI
        embedder = CustomEmbedding(
            base_url="https://api.together.xyz/v1",
            api_key="your-key",
            model="togethercomputer/m2-bert-80M-8k-retrieval",
        )

        result = await embedder.embed(["Hello", "World"])
    """

    model: str = "text-embedding-3-small"
    base_url: str = "http://localhost:8000/v1"

    def _init_client(self) -> None:
        """Initialize OpenAI-compatible client."""
        try:
            from openai import AsyncOpenAI, OpenAI
        except ImportError:
            raise ImportError(
                "openai package required. Install with: uv add openai"
            ) from None

        api_key = self.api_key
        if not api_key:
            for env_var in ["CUSTOM_API_KEY", "OPENAI_API_KEY", "API_KEY"]:
                api_key = os.environ.get(env_var)
                if api_key:
                    break

        if not api_key:
            api_key = "not-needed"

        self._client = OpenAI(
            base_url=self.base_url,
            api_key=api_key,
            timeout=self.timeout,
            max_retries=self.max_retries,
        )
        self._async_client = AsyncOpenAI(
            base_url=self.base_url,
            api_key=api_key,
            timeout=self.timeout,
            max_retries=self.max_retries,
        )

    async def embed(self, texts: str | list[str]) -> EmbeddingResult:
        """Embed texts asynchronously with metadata.

        Args:
            texts: A single string or list of strings to embed.

        Returns:
            EmbeddingResult with embeddings and metadata.
        """
        self._ensure_initialized()
        import asyncio
        import time

        from cogent.core.messages import (
            EmbeddingResult,
        )

        # Normalize input
        texts_list = [texts] if isinstance(texts, str) else texts

        start_time = time.time()
        total_prompt_tokens = 0
        model_name = None

        async def embed_batch(
            batch: list[str],
        ) -> tuple[list[list[float]], int, str | None]:
            response = await self._async_client.embeddings.create(
                model=self.model,
                input=batch,
            )
            sorted_data = sorted(response.data, key=lambda x: x.index)
            embeddings = [d.embedding for d in sorted_data]
            tokens = (
                response.usage.prompt_tokens
                if hasattr(response, "usage") and response.usage
                else 0
            )
            model = response.model if hasattr(response, "model") else None
            return embeddings, tokens, model

        batches = [
            texts_list[i : i + self.batch_size]
            for i in range(0, len(texts_list), self.batch_size)
        ]
        results = await asyncio.gather(*[embed_batch(b) for b in batches])

        all_embeddings: list[list[float]] = []
        for batch_embeddings, tokens, model in results:
            all_embeddings.extend(batch_embeddings)
            total_prompt_tokens += tokens
            if model:
                model_name = model

        metadata = EmbeddingMetadata(
            model=model_name or self.model,
            tokens=TokenUsage(
                prompt_tokens=total_prompt_tokens,
                completion_tokens=0,
                total_tokens=total_prompt_tokens,
            )
            if total_prompt_tokens > 0
            else None,
            duration=time.time() - start_time,
            dimensions=len(all_embeddings[0]) if all_embeddings else None,
            num_texts=len(texts_list),
        )

        return EmbeddingResult(embeddings=all_embeddings, metadata=metadata)
