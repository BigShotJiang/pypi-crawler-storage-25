"""
OpenRouter models for Cogent.

OpenRouter is a unified API gateway that routes requests to 200+ models from
OpenAI, Anthropic, Google, Meta, Mistral, and others, all via a single
OpenAI-compatible endpoint.

Usage:
    from cogent.models.openrouter import OpenRouterChat

    # Basic usage
    llm = OpenRouterChat(model="openai/gpt-4o")
    response = await llm.ainvoke([{"role": "user", "content": "Hello!"}])

    # Free tier
    llm = OpenRouterChat(model="meta-llama/llama-3.1-8b-instruct:free")

    # With app-identification headers (recommended)
    llm = OpenRouterChat(
        model="anthropic/claude-sonnet-4.5",
        site_url="https://myapp.example.com",
        site_name="My App",
    )

    # Provider routing — pin to cheapest, highest-throughput, or specific backend
    llm = OpenRouterChat(
        model="openai/gpt-4o",
        provider={"sort": "throughput"},          # or "latency" / "price"
    )
    llm = OpenRouterChat(
        model="anthropic/claude-sonnet-4.5",
        provider={"order": ["anthropic"], "allow_fallbacks": False},
    )
    llm = OpenRouterChat(
        model="meta-llama/llama-3.3-70b-instruct",
        provider={"quantizations": ["fp8"], "data_collection": "deny"},
    )

    # Model fallbacks — try claude first, fall back to gpt-4o
    llm = OpenRouterChat(
        model="anthropic/claude-sonnet-4.5",
        fallback_models=["openai/gpt-4o", "google/gemini-2.5-flash"],
    )

    # Plugins — web search, response-healing (auto-fix malformed JSON)
    llm = OpenRouterChat(
        model="openai/gpt-4o",
        plugins=[{"id": "web", "max_results": 5}],
    )
    llm = OpenRouterChat(
        model="openai/gpt-4o",
        plugins=[{"id": "response-healing"}],     # pairs with structured output
    )

    # Reasoning control
    llm = OpenRouterChat(model="deepseek/deepseek-v3.2", reasoning_exclude=True)
    llm = OpenRouterChat(model="anthropic/claude-3.7-sonnet", reasoning_max_tokens=2000)
    llm = OpenRouterChat(model="openai/o3-mini", reasoning_effort="low", reasoning_exclude=True)
    llm = OpenRouterChat(model="openai/o3-mini", reasoning_effort="none")  # disable thinking

    # Anthropic beta features (fine-grained tool streaming, interleaved thinking)
    llm = OpenRouterChat(
        model="anthropic/claude-sonnet-4.5",
        anthropic_beta="fine-grained-tool-streaming-2025-05-14",
    )
    # Strict tool use (validates tool parameters against schema)
    llm = OpenRouterChat(
        model="anthropic/claude-sonnet-4.5",
        anthropic_beta="structured-outputs-2025-11-13",
    )

    # Tools with tool_choice
    llm = OpenRouterChat(model="openai/gpt-4o").bind_tools(
        [search_tool],
        tool_choice="required",   # force the model to call a tool
    )

    # Sampling parameters
    llm = OpenRouterChat(
        model="openai/gpt-4o",
        top_p=0.9,
        frequency_penalty=0.1,
        seed=42,
    )

    # Streaming (tool calls are assembled and yielded in the final chunk)
    async for chunk in llm.astream(messages):
        if chunk.content:
            print(chunk.content, end="")
        if chunk.tool_calls:
            handle_tool_calls(chunk.tool_calls)

Model naming convention:
    OpenRouter models use "{provider}/{model-name}" format, e.g.:
    - openai/gpt-4o
    - openai/gpt-4o-mini
    - anthropic/claude-sonnet-4.5
    - anthropic/claude-3-haiku
    - google/gemini-2.5-flash-preview-05-20
    - meta-llama/llama-3.3-70b-instruct
    - meta-llama/llama-3.1-8b-instruct:free   (free tier)
    - meta-llama/llama-3.1-8b-instruct:nitro  (throughput-sorted)
    - meta-llama/llama-3.1-8b-instruct:floor  (price-sorted)
    - meta-llama/llama-3.1-8b-instruct:free:online  (free + web search)
    - mistralai/mistral-7b-instruct:free       (free tier)
    - deepseek/deepseek-chat
    - qwen/qwen-2.5-72b-instruct
    - openrouter/auto                           (auto-routes to best model)

Full model list at: https://openrouter.ai/models
"""

from __future__ import annotations

import contextlib
import json
import time
import uuid
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any, Literal

from cogent.core.messages import MessageMetadata, TokenUsage
from cogent.models.base import AIMessage, BaseChatModel, normalize_input

OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"


def _format_tools(tools: list[Any]) -> list[dict[str, Any]]:
    """Convert tools to OpenAI-compatible API format."""
    formatted = []
    for tool in tools:
        if hasattr(tool, "to_dict"):
            formatted.append(tool.to_dict())
        elif hasattr(tool, "to_openai"):
            formatted.append(tool.to_openai())
        elif hasattr(tool, "name") and hasattr(tool, "description"):
            schema = getattr(tool, "args_schema", None) or {}
            if not isinstance(schema, dict) or not schema:
                schema = {"type": "object", "properties": {}}
            elif "type" not in schema and "properties" not in schema:
                schema = {
                    "type": "object",
                    "properties": schema,
                    "required": list(schema.keys()),
                }
            elif "type" not in schema:
                schema = {"type": "object", **schema}
            formatted.append(
                {
                    "type": "function",
                    "function": {
                        "name": tool.name,
                        "description": tool.description or "",
                        "parameters": schema,
                    },
                }
            )
        elif isinstance(tool, dict):
            formatted.append(tool)
    return formatted


def _convert_messages(messages: list[Any]) -> list[dict[str, Any]]:
    """Convert messages to dict format.

    Handles both dict messages and message objects (SystemMessage, HumanMessage, etc.).
    """
    result = []
    for msg in messages:
        if isinstance(msg, dict):
            result.append(msg)
            continue

        if hasattr(msg, "to_dict"):
            result.append(msg.to_dict())
            continue

        if hasattr(msg, "to_openai"):
            result.append(msg.to_openai())
            continue

        if hasattr(msg, "role") and hasattr(msg, "content"):
            msg_dict: dict[str, Any] = {
                "role": msg.role,
                "content": msg.content or "",
            }
            if hasattr(msg, "tool_calls") and msg.tool_calls:
                msg_dict["tool_calls"] = [
                    {
                        "id": tc.get("id", f"call_{i}")
                        if isinstance(tc, dict)
                        else getattr(tc, "id", f"call_{i}"),
                        "type": "function",
                        "function": {
                            "name": tc.get("name", "")
                            if isinstance(tc, dict)
                            else getattr(tc, "name", ""),
                            "arguments": __import__("json").dumps(
                                tc.get("args", {})
                                if isinstance(tc, dict)
                                else getattr(tc, "args", {})
                            ),
                        },
                    }
                    for i, tc in enumerate(msg.tool_calls)
                ]
            if hasattr(msg, "tool_call_id") and msg.tool_call_id:
                msg_dict["tool_call_id"] = msg.tool_call_id
            if hasattr(msg, "name") and msg.name:
                msg_dict["name"] = msg.name
            result.append(msg_dict)
            continue

        result.append({"role": "user", "content": str(msg)})

    return result


def _parse_response(response: Any) -> AIMessage:
    """Parse OpenRouter (OpenAI-compatible) response into AIMessage."""
    choice = response.choices[0]
    message = choice.message

    tool_calls = []
    if hasattr(message, "tool_calls") and message.tool_calls:
        for tc in message.tool_calls:
            args = tc.function.arguments
            if isinstance(args, str):
                with contextlib.suppress(ValueError, AttributeError):
                    args = json.loads(args)
            tool_calls.append(
                {
                    "id": tc.id,
                    "name": tc.function.name,
                    "args": args,
                }
            )

    usage = getattr(response, "usage", None)
    tokens: TokenUsage | None = None
    cost: float | None = None
    if usage:
        ptd = getattr(usage, "prompt_tokens_details", None)
        ctd = getattr(usage, "completion_tokens_details", None)
        tokens = TokenUsage(
            prompt_tokens=getattr(usage, "prompt_tokens", 0),
            completion_tokens=getattr(usage, "completion_tokens", 0),
            total_tokens=getattr(usage, "total_tokens", 0),
            reasoning_tokens=getattr(ctd, "reasoning_tokens", None) if ctd else None,
            cached_tokens=getattr(ptd, "cached_tokens", None) if ptd else None,
            cache_write_tokens=getattr(ptd, "cache_write_tokens", None)
            if ptd
            else None,
        )
        cost = getattr(usage, "cost", None)

    metadata = MessageMetadata(
        model=getattr(response, "model", None),
        tokens=tokens,
        finish_reason=getattr(choice, "finish_reason", None),
        native_finish_reason=getattr(choice, "native_finish_reason", None),
        response_id=getattr(response, "id", None),
        cost=cost,
    )

    msg = AIMessage(
        content=message.content or "",
        tool_calls=tool_calls,
        metadata=metadata,
    )
    # Reasoning content — returned by models like deepseek/deepseek-r1 when
    # OpenRouter surfaces their chain-of-thought via the ``reasoning`` field.
    reasoning_text = getattr(message, "reasoning", None) or getattr(
        message, "reasoning_content", None
    )
    if reasoning_text:
        msg.thinking = reasoning_text
    return msg


@dataclass
class OpenRouterChat(BaseChatModel):
    """OpenRouter chat model.

    Routes requests to 200+ models from OpenAI, Anthropic, Google, Meta,
    Mistral, and others through a single OpenAI-compatible endpoint.

    Model names use "{provider}/{model}" format (e.g. "openai/gpt-4o").
    Append ``:free`` for free-tier variants, ``:nitro`` to sort by throughput,
    ``:floor`` to sort by price, or ``:online`` to enable web search.

    Key parameters beyond the base class:
        site_url / site_name: App-identification headers shown on openrouter.ai.
        provider: Dict of provider-routing preferences (order, sort, only,
            ignore, quantizations, data_collection, zdr, max_price, etc.).
        fallback_models: Ordered list of fallback model slugs tried when the
            primary model fails (sent as ``models`` in the request body).
        plugins: List of OpenRouter plugin dicts to activate per request (web
            search, file-parser, response-healing, context-compression).
        anthropic_beta: One or more Anthropic beta feature header values
            (fine-grained tool streaming, interleaved thinking, strict tool use).
        top_p / top_k / frequency_penalty / presence_penalty / repetition_penalty
        / min_p / top_a / seed / stop / logit_bias / logprobs / top_logprobs
        / prediction / verbosity: Sampling parameters forwarded to the model.
        user: Stable end-user ID for abuse detection.

    Example:
        from cogent.models.openrouter import OpenRouterChat

        llm = OpenRouterChat(model="openai/gpt-4o-mini")

        # Route to the highest-throughput backend, fall back to gpt-4o
        llm = OpenRouterChat(
            model="anthropic/claude-sonnet-4.5",
            provider={"sort": "throughput"},
            fallback_models=["openai/gpt-4o"],
        )

        # Web search + response healing for structured output
        llm = OpenRouterChat(
            model="openai/gpt-4o",
            plugins=[{"id": "web"}, {"id": "response-healing"}],
        )

        # Force a tool call
        llm = OpenRouterChat(model="openai/gpt-4o").bind_tools(
            [my_tool], tool_choice="required"
        )

        # Anthropic strict tool use via beta header
        llm = OpenRouterChat(
            model="anthropic/claude-sonnet-4.5",
            anthropic_beta="structured-outputs-2025-11-13",
        )

        response = await llm.ainvoke([{"role": "user", "content": "Hello!"}])

    Full model list: https://openrouter.ai/models
    """

    model: str = "openai/gpt-4o-mini"
    site_url: str | None = field(default=None, repr=False)
    site_name: str | None = field(default=None, repr=False)

    # --- Sampling parameters ---
    top_p: float | None = field(default=None, repr=False)
    top_k: int | None = field(default=None, repr=False)
    frequency_penalty: float | None = field(default=None, repr=False)
    presence_penalty: float | None = field(default=None, repr=False)
    repetition_penalty: float | None = field(default=None, repr=False)
    min_p: float | None = field(default=None, repr=False)
    top_a: float | None = field(default=None, repr=False)
    seed: int | None = field(default=None, repr=False)
    stop: str | list[str] | None = field(default=None, repr=False)
    logit_bias: dict[int, float] | None = field(default=None, repr=False)
    logprobs: bool | None = field(default=None, repr=False)
    top_logprobs: int | None = field(default=None, repr=False)
    prediction: dict[str, str] | None = field(default=None, repr=False)
    verbosity: str | None = field(
        default=None, repr=False
    )  # "low", "medium", "high", "max"

    # --- OpenRouter routing ---
    provider: dict[str, Any] | None = field(default=None, repr=False)
    """Provider preferences (order, sort, only, ignore, quantizations, etc.).
    See https://openrouter.ai/docs/features/provider-routing."""
    fallback_models: list[str] | None = field(default=None, repr=False)
    """Ordered list of fallback model slugs tried when the primary model fails.
    Sent as the ``models`` field in the request body."""
    plugins: list[dict[str, Any]] | None = field(default=None, repr=False)
    """OpenRouter plugins to activate (e.g. web search, response-healing).
    See https://openrouter.ai/docs/guides/features/plugins."""

    # --- Identity / privacy ---
    user: str | None = field(default=None, repr=False)
    """Stable end-user identifier for abuse detection (passed as ``user`` in the body)."""

    # --- Anthropic beta features ---
    anthropic_beta: str | list[str] | None = field(default=None, repr=False)
    """One or more Anthropic beta feature flags sent via ``x-anthropic-beta`` header.
    E.g. ``"fine-grained-tool-streaming-2025-05-14"`` or
    ``["interleaved-thinking-2025-05-14", "structured-outputs-2025-11-13"]``."""

    # --- Debug (streaming only) ---
    debug: dict[str, Any] | None = field(default=None, repr=False)
    """Debug options, e.g. ``{"echo_upstream_body": True}`` (streaming only)."""

    # --- Reasoning ---
    reasoning_effort: (
        Literal["xhigh", "high", "medium", "low", "minimal", "none"] | None
    ) = field(default=None, repr=False)
    """Effort level for reasoning/thinking tokens.  Supported by OpenAI o-series, Grok,
    and Gemini 3 models (mapped to ``thinkingLevel``).  Use ``"none"`` to disable
    thinking entirely on models that reason by default.
    See https://openrouter.ai/docs/guides/best-practices/reasoning-tokens"""

    reasoning_max_tokens: int | None = field(default=None, repr=False)
    """Maximum number of tokens to allocate for reasoning.  Supported by Anthropic
    models (passed as ``thinking.budget_tokens``) and some Qwen and Gemini 2.5 models.
    Cannot be combined with ``reasoning_effort``."""

    reasoning_exclude: bool = field(default=False, repr=False)
    """When ``True`` the model still reasons internally but reasoning tokens are not
    returned in the response.  Compatible with both ``reasoning_effort`` and
    ``reasoning_max_tokens``."""

    # Private: set via bind_tools()
    _tool_choice: str | dict[str, Any] | None = field(default=None, repr=False)

    def _init_client(self) -> None:
        """Initialize OpenRouter client using OpenAI-compatible API."""
        try:
            from openai import AsyncOpenAI, OpenAI
        except ImportError:
            raise ImportError(
                "openai package required. Install with: uv add openai"
            ) from None

        from cogent.config import get_api_key

        api_key = get_api_key("openrouter", self.api_key)
        if not api_key:
            raise ValueError(
                "OpenRouter API key required. Set OPENROUTER_API_KEY environment "
                "variable or pass api_key parameter."
            )

        # Build optional app-identification headers (recommended by OpenRouter)
        default_headers: dict[str, str] = {}
        if self.site_url:
            default_headers["HTTP-Referer"] = self.site_url
        if self.site_name:
            default_headers["X-Title"] = self.site_name

        self._client = OpenAI(
            base_url=OPENROUTER_BASE_URL,
            api_key=api_key,
            timeout=self.timeout,
            max_retries=self.max_retries,
            default_headers=default_headers or None,
        )
        self._async_client = AsyncOpenAI(
            base_url=OPENROUTER_BASE_URL,
            api_key=api_key,
            timeout=self.timeout,
            max_retries=self.max_retries,
            default_headers=default_headers or None,
        )

    def bind_tools(
        self,
        tools: list[Any],
        *,
        parallel_tool_calls: bool = True,
        tool_choice: str | dict[str, Any] | None = None,
    ) -> OpenRouterChat:
        """Bind tools to the model.

        Args:
            tools: List of tools to bind.
            parallel_tool_calls: Allow the model to call multiple tools
                simultaneously. Defaults to True.
            tool_choice: Which tool the model must call. One of ``"auto"``
                (default), ``"none"``, ``"required"``, or a specific dict
                ``{"type": "function", "function": {"name": "fn_name"}}``.
        """
        self._ensure_initialized()

        new_model = OpenRouterChat(
            model=self.model,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            api_key=self.api_key,
            timeout=self.timeout,
            max_retries=self.max_retries,
            site_url=self.site_url,
            site_name=self.site_name,
            top_p=self.top_p,
            top_k=self.top_k,
            frequency_penalty=self.frequency_penalty,
            presence_penalty=self.presence_penalty,
            repetition_penalty=self.repetition_penalty,
            min_p=self.min_p,
            top_a=self.top_a,
            seed=self.seed,
            stop=self.stop,
            logit_bias=self.logit_bias,
            logprobs=self.logprobs,
            top_logprobs=self.top_logprobs,
            prediction=self.prediction,
            verbosity=self.verbosity,
            provider=self.provider,
            fallback_models=self.fallback_models,
            plugins=self.plugins,
            user=self.user,
            anthropic_beta=self.anthropic_beta,
            debug=self.debug,
        )
        new_model._tools = tools
        new_model._parallel_tool_calls = parallel_tool_calls
        new_model._tool_choice = tool_choice
        new_model._client = self._client
        new_model._async_client = self._async_client
        new_model._initialized = True
        return new_model

    def with_json_mode(self) -> OpenRouterChat:
        """Return a copy of this model with JSON mode enabled.

        Sets ``response_format: {"type": "json_object"}`` on the request,
        constraining output to valid JSON. This is the recommended way to
        request structured output from OpenRouter-routed models.

        Returns:
            A new ``OpenRouterChat`` instance configured for JSON output.
        """
        self._ensure_initialized()

        new_model = OpenRouterChat(
            model=self.model,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            api_key=self.api_key,
            timeout=self.timeout,
            max_retries=self.max_retries,
            site_url=self.site_url,
            site_name=self.site_name,
            top_p=self.top_p,
            top_k=self.top_k,
            frequency_penalty=self.frequency_penalty,
            presence_penalty=self.presence_penalty,
            repetition_penalty=self.repetition_penalty,
            min_p=self.min_p,
            top_a=self.top_a,
            seed=self.seed,
            stop=self.stop,
            logit_bias=self.logit_bias,
            logprobs=self.logprobs,
            top_logprobs=self.top_logprobs,
            prediction=self.prediction,
            verbosity=self.verbosity,
            provider=self.provider,
            fallback_models=self.fallback_models,
            plugins=self.plugins,
            user=self.user,
            anthropic_beta=self.anthropic_beta,
            debug=self.debug,
        )
        new_model._tools = getattr(self, "_tools", [])
        new_model._parallel_tool_calls = getattr(self, "_parallel_tool_calls", True)
        new_model._tool_choice = getattr(self, "_tool_choice", None)
        new_model._response_format = {"type": "json_object"}
        new_model._client = self._client
        new_model._async_client = self._async_client
        new_model._initialized = True
        return new_model

    def invoke(self, messages: str | list[dict[str, Any]] | list[Any]) -> AIMessage:
        """Invoke synchronously.

        Args:
            messages: Can be a string, list of dicts, or list of message objects.
        """
        self._ensure_initialized()
        messages = normalize_input(messages)
        kwargs = self._build_request(messages)
        response = self._client.chat.completions.create(**kwargs)
        return _parse_response(response)

    async def ainvoke(
        self, messages: str | list[dict[str, Any]] | list[Any]
    ) -> AIMessage:
        """Invoke asynchronously.

        Args:
            messages: Can be a string, list of dicts, or list of message objects.
        """
        self._ensure_initialized()
        messages = normalize_input(messages)
        kwargs = self._build_request(messages)
        response = await self._async_client.chat.completions.create(**kwargs)
        return _parse_response(response)

    async def astream(
        self, messages: str | list[dict[str, Any]] | list[Any]
    ) -> AsyncIterator[AIMessage]:
        """Stream response asynchronously with metadata.

        Yields:
            AIMessage objects with incremental content and metadata.
            When the model uses tools, a final AIMessage carrying
            ``tool_calls`` is yielded alongside the usage-metadata chunk.
        """
        self._ensure_initialized()
        messages = normalize_input(messages)
        kwargs = self._build_request(messages)
        kwargs["stream"] = True
        kwargs["stream_options"] = {"include_usage": True}

        start_time = time.time()
        chunk_metadata: dict[str, Any] = {
            "id": None,
            "model": None,
            "finish_reason": None,
            "native_finish_reason": None,
            "usage": None,
        }
        # Accumulate partial tool-call argument fragments keyed by index.
        pending_tool_calls: dict[int, dict[str, Any]] = {}

        stream = await self._async_client.chat.completions.create(**kwargs)
        accumulated_reasoning: list[str] = []

        async for chunk in stream:
            if chunk.id:
                chunk_metadata["id"] = chunk.id
            if chunk.model:
                chunk_metadata["model"] = chunk.model

            if chunk.choices:
                choice = chunk.choices[0]
                if choice.finish_reason:
                    chunk_metadata["finish_reason"] = choice.finish_reason
                    nr = getattr(choice, "native_finish_reason", None)
                    if nr:
                        chunk_metadata["native_finish_reason"] = nr

                # Accumulate tool-call delta fragments.
                delta_tcs = getattr(choice.delta, "tool_calls", None)
                if delta_tcs:
                    for tc_delta in delta_tcs:
                        idx = tc_delta.index
                        if idx not in pending_tool_calls:
                            pending_tool_calls[idx] = {
                                "id": tc_delta.id or "",
                                "name": (tc_delta.function.name or "")
                                if tc_delta.function
                                else "",
                                "args_str": "",
                            }
                        else:
                            if tc_delta.id:
                                pending_tool_calls[idx]["id"] = tc_delta.id
                            if tc_delta.function:
                                if tc_delta.function.name:
                                    pending_tool_calls[idx]["name"] += (
                                        tc_delta.function.name
                                    )
                                if tc_delta.function.arguments:
                                    pending_tool_calls[idx]["args_str"] += (
                                        tc_delta.function.arguments
                                    )

                # Stream reasoning tokens (OpenRouter surfaces these on delta.reasoning)
                reasoning_delta = getattr(choice.delta, "reasoning", None)
                if reasoning_delta:
                    accumulated_reasoning.append(reasoning_delta)
                    yield AIMessage(
                        content=reasoning_delta,
                        metadata=MessageMetadata(
                            id=str(uuid.uuid4()),
                            timestamp=time.time(),
                            model=chunk_metadata["model"],
                            tokens=None,
                            finish_reason=None,
                            response_id=chunk_metadata["id"],
                            duration=time.time() - start_time,
                            is_thinking=True,
                        ),
                    )

                if choice.delta.content:
                    yield AIMessage(
                        content=choice.delta.content,
                        metadata=MessageMetadata(
                            id=str(uuid.uuid4()),
                            timestamp=time.time(),
                            model=chunk_metadata["model"],
                            tokens=None,
                            finish_reason=chunk_metadata.get("finish_reason"),
                            native_finish_reason=chunk_metadata.get(
                                "native_finish_reason"
                            ),
                            response_id=chunk_metadata["id"],
                            duration=time.time() - start_time,
                        ),
                    )

            if hasattr(chunk, "usage") and chunk.usage:
                usage = chunk.usage
                ptd = getattr(usage, "prompt_tokens_details", None)
                ctd = getattr(usage, "completion_tokens_details", None)
                tokens = TokenUsage(
                    prompt_tokens=getattr(usage, "prompt_tokens", 0),
                    completion_tokens=getattr(usage, "completion_tokens", 0),
                    total_tokens=getattr(usage, "total_tokens", 0),
                    reasoning_tokens=getattr(ctd, "reasoning_tokens", None)
                    if ctd
                    else None,
                    cached_tokens=getattr(ptd, "cached_tokens", None) if ptd else None,
                    cache_write_tokens=getattr(ptd, "cache_write_tokens", None)
                    if ptd
                    else None,
                )
                cost: float | None = getattr(usage, "cost", None)
                metadata = MessageMetadata(
                    id=str(uuid.uuid4()),
                    timestamp=time.time(),
                    model=chunk_metadata["model"],
                    tokens=tokens,
                    finish_reason=chunk_metadata["finish_reason"],
                    native_finish_reason=chunk_metadata.get("native_finish_reason"),
                    response_id=chunk_metadata["id"],
                    duration=time.time() - start_time,
                    cost=cost,
                )
                # Assemble any accumulated tool calls.
                assembled: list[dict[str, Any]] = []
                for k in sorted(pending_tool_calls.keys()):
                    tc = pending_tool_calls[k]
                    args_str = tc["args_str"]
                    try:
                        args: Any = json.loads(args_str) if args_str else {}
                    except ValueError:
                        args = args_str
                    assembled.append({"id": tc["id"], "name": tc["name"], "args": args})
                final_msg = AIMessage(
                    content="",
                    tool_calls=assembled,
                    metadata=metadata,
                )
                if accumulated_reasoning:
                    final_msg.thinking = "".join(accumulated_reasoning)
                yield final_msg

    def _build_request(self, messages: list[Any]) -> dict[str, Any]:
        """Build API request, converting messages to dict format."""
        converted_messages = _convert_messages(messages)

        kwargs: dict[str, Any] = {
            "model": self.model,
            "messages": converted_messages,
        }

        # --- Standard OpenAI-compatible params ---
        if self.temperature is not None:
            kwargs["temperature"] = self.temperature
        if self.max_tokens:
            kwargs["max_tokens"] = self.max_tokens
        if self.top_p is not None:
            kwargs["top_p"] = self.top_p
        if self.frequency_penalty is not None:
            kwargs["frequency_penalty"] = self.frequency_penalty
        if self.presence_penalty is not None:
            kwargs["presence_penalty"] = self.presence_penalty
        if self.seed is not None:
            kwargs["seed"] = self.seed
        if self.stop is not None:
            kwargs["stop"] = self.stop
        if self.logit_bias is not None:
            kwargs["logit_bias"] = self.logit_bias
        if self.logprobs is not None:
            kwargs["logprobs"] = self.logprobs
        if self.top_logprobs is not None:
            kwargs["top_logprobs"] = self.top_logprobs
        if self.prediction is not None:
            kwargs["prediction"] = self.prediction
        if self.user:
            kwargs["user"] = self.user

        # --- Tool calling ---
        if self._tools:
            kwargs["tools"] = _format_tools(self._tools)
            # Only send parallel_tool_calls when disabling it.
            # Sending True can cause errors on models that don't support this param.
            if not self._parallel_tool_calls:
                kwargs["parallel_tool_calls"] = False
            if self._tool_choice is not None:
                kwargs["tool_choice"] = self._tool_choice

        # --- Structured output ---
        if hasattr(self, "_response_format") and self._response_format:
            kwargs["response_format"] = self._response_format

        # --- OpenRouter-specific extra_body fields ---
        # top_k, repetition_penalty, min_p, top_a, verbosity are not standard
        # OpenAI params and must travel via extra_body.
        extra_body: dict[str, Any] = {}
        if self.top_k is not None:
            extra_body["top_k"] = self.top_k
        if self.repetition_penalty is not None:
            extra_body["repetition_penalty"] = self.repetition_penalty
        if self.min_p is not None:
            extra_body["min_p"] = self.min_p
        if self.top_a is not None:
            extra_body["top_a"] = self.top_a
        if self.verbosity is not None:
            extra_body["verbosity"] = self.verbosity
        if self.provider is not None:
            extra_body["provider"] = self.provider
        if self.fallback_models:
            extra_body["models"] = self.fallback_models
        if self.plugins:
            extra_body["plugins"] = self.plugins
        if self.debug:
            extra_body["debug"] = self.debug
        reasoning_body: dict[str, Any] = {}
        if self.reasoning_effort is not None:
            reasoning_body["effort"] = self.reasoning_effort
        if self.reasoning_max_tokens is not None:
            reasoning_body["max_tokens"] = self.reasoning_max_tokens
        if self.reasoning_exclude:
            reasoning_body["exclude"] = True
        if reasoning_body:
            extra_body["reasoning"] = reasoning_body
        if extra_body:
            kwargs["extra_body"] = extra_body

        # --- Anthropic beta feature headers ---
        if self.anthropic_beta:
            beta_val = (
                self.anthropic_beta
                if isinstance(self.anthropic_beta, str)
                else ",".join(self.anthropic_beta)
            )
            kwargs["extra_headers"] = {"x-anthropic-beta": beta_val}

        return kwargs
