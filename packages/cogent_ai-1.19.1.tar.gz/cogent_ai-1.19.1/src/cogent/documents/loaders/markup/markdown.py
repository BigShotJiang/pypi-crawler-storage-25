"""Markdown file loader."""

from __future__ import annotations

from pathlib import Path
from typing import ClassVar

from cogent.core import Document
from cogent.documents.loaders.base import BaseLoader


class MarkdownLoader(BaseLoader):
    """Loader for Markdown files.

    Supports .md and .markdown files.
    Optionally extracts YAML frontmatter into metadata.

    Example:
        >>> loader = MarkdownLoader()
        >>> docs = await loader.load(Path("README.md"))
        >>> print(docs[0].metadata.get("title"))  # From frontmatter
    """

    supported_extensions: ClassVar[list[str]] = [".md", ".markdown"]

    def __init__(
        self,
        encoding: str = "utf-8",
        extract_frontmatter: bool = True,
    ) -> None:
        """Initialize the loader.

        Args:
            encoding: Text encoding.
            extract_frontmatter: Whether to parse YAML frontmatter.
        """
        super().__init__(encoding)
        self.extract_frontmatter = extract_frontmatter

    async def load(self, path: str | Path, **kwargs: object) -> list[Document]:
        """Load a Markdown file.

        Args:
            path: Path to the Markdown file (str or Path).
            **kwargs: Optional 'encoding' to override default.

        Returns:
            List containing a single Document.
        """
        path = Path(path)
        encoding = kwargs.get("encoding", self.encoding)
        content = path.read_text(encoding=encoding)
        metadata: dict[str, object] = {}

        # Extract YAML frontmatter if present
        if self.extract_frontmatter and content.startswith("---"):
            content, metadata = self._extract_frontmatter(content)

        return [self._create_document(content, path, **metadata)]

    def _extract_frontmatter(self, content: str) -> tuple[str, dict[str, object]]:
        """Extract YAML frontmatter from content.

        Args:
            content: Full document content starting with ---.

        Returns:
            Tuple of (content without frontmatter, frontmatter dict).
        """
        parts = content.split("---", 2)
        if len(parts) < 3:
            return content, {}

        frontmatter_text = parts[1].strip()
        remaining_content = parts[2].strip()

        # Parse simple key: value frontmatter
        metadata: dict[str, object] = {}
        for line in frontmatter_text.split("\n"):
            if ":" in line:
                key, value = line.split(":", 1)
                key = key.strip()
                value = value.strip()

                # Handle quoted strings
                if (value.startswith('"') and value.endswith('"')) or (
                    value.startswith("'") and value.endswith("'")
                ):
                    value = value[1:-1]

                # Handle lists (simple single-line format)
                if value.startswith("[") and value.endswith("]"):
                    value = [v.strip().strip("\"'") for v in value[1:-1].split(",")]

                metadata[key] = value

        return remaining_content, metadata


__all__ = ["MarkdownLoader"]
