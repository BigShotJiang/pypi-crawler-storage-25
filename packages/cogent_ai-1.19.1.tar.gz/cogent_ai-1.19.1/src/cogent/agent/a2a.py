"""A2A (Agent2Agent) remote agent adapter.

Wraps a remote A2A-protocol server as an AgentLike so it can be passed
directly to ``subagents=[...]`` alongside local Agent instances.

Requires the optional ``a2a`` extra::

    uv add "cogent-ai[a2a]"

Example::

    from cogent import Agent
    from cogent.agent.a2a import A2AAgent

    remote = A2AAgent(
        url="http://remote-service/a2a",
        name="analyst",
        description="Remote financial analyst agent",
    )

    coordinator = Agent(
        name="coordinator",
        model="gpt4",
        subagents=[local_writer, remote],
    )
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from cogent.core.context import RunContext
    from cogent.core.response import Response


@dataclass(frozen=True)
class _A2AAgentConfig:
    """Minimal config object satisfying the AgentLike.config contract."""

    name: str
    description: str
    returns: Any = None


class A2AAgent:
    """Remote A2A agent adapter.

    Wraps an A2A-protocol HTTP endpoint so it can participate in cogent's
    subagent delegation system.  The remote agent is called via the
    ``a2a-sdk`` async client; the result is wrapped in a cogent ``Response``
    so the registry and callers see a uniform interface.

    Args:
        url: Base URL of the remote A2A agent (e.g. ``"http://svc/a2a"``).
        name: Logical name used as the tool name in the coordinator's LLM.
        description: Short description surfaced to the coordinator LLM.
        timeout: HTTP timeout in seconds (default 60).
        headers: Extra headers to include in every request.

    Example::

        agent = A2AAgent(
            url="http://analyst-svc/a2a",
            name="analyst",
            description="Specialist for financial data analysis",
        )
    """

    def __init__(
        self,
        url: str,
        *,
        name: str,
        description: str = "",
        timeout: float = 60.0,
        headers: dict[str, str] | None = None,
        returns: type | dict | None = None,
    ) -> None:
        self._url = url
        self._timeout = timeout
        self._headers = headers or {}
        self.config = _A2AAgentConfig(
            name=name, description=description, returns=returns
        )

    async def run(
        self,
        task: str,
        *,
        context: RunContext | None = None,  # accepted but not forwarded
        returns: type
        | dict
        | None = None,  # per-call override; falls back to self.config.returns
        **kwargs: Any,
    ) -> Response:
        """Delegate a task to the remote A2A agent.

        Args:
            task: The task string to send to the remote agent.
            context: Ignored — RunContext is internal to cogent and not
                forwarded over the wire.
            returns: Schema to parse the remote response into.  Overrides the
                instance-level ``returns`` set at construction time.  Supports
                the same types as a local :class:`~cogent.agent.base.Agent`:
                Pydantic models, dataclasses, TypedDicts, and JSON Schema dicts.

        Returns:
            A cogent Response wrapping the remote agent's reply.  When
            *returns* is provided the ``content`` field holds a
            :class:`~cogent.agent.output.StructuredResult`; otherwise it is a
            plain string.

        Raises:
            ImportError: If ``a2a-sdk`` is not installed.
            RuntimeError: If the remote agent returns an error.
        """
        try:
            import httpx
            from a2a.client import (
                A2ACardResolver,
                ClientConfig,
                ClientFactory,
                create_text_message_object,
            )
            from a2a.types import Message, TaskState
        except ImportError as exc:
            raise ImportError(
                "A2AAgent requires the 'a2a' extra: uv add 'cogent-ai[a2a]'"
            ) from exc

        from cogent.core.response import Response, ResponseMetadata

        start = time.monotonic()

        async with httpx.AsyncClient(
            headers=self._headers,
            timeout=self._timeout,
        ) as http:
            # Resolve the AgentCard from the server, then build a typed client.
            resolver = A2ACardResolver(http, self._url)
            card = await resolver.get_agent_card()

            factory = ClientFactory(ClientConfig(httpx_client=http))
            client = factory.create(card)

            message = create_text_message_object(content=task)
            content = ""
            async for event in client.send_message(message):
                # Skip intermediate SSE working events — only accept the final
                # completed/failed/canceled state so we get the full response.
                if isinstance(event, tuple):
                    task_obj, _update = event
                    state = getattr(getattr(task_obj, "status", None), "state", None)
                    terminal = {
                        TaskState.completed,
                        TaskState.failed,
                        TaskState.canceled,
                    }
                    if state not in terminal:
                        continue
                content = _extract_text(event)
                if content:
                    break

        duration = time.monotonic() - start

        # Resolve active schema: per-call kwarg takes priority over instance default.
        active_schema = returns if returns is not None else self.config.returns

        metadata = ResponseMetadata(
            agent=self.config.name,
            model="a2a-remote",
            duration=duration,
        )

        if active_schema is not None and content:
            from cogent.agent.output import (
                StructuredResult,
                validate_and_parse,
                OutputValidationError,
            )

            try:
                data = validate_and_parse(content, active_schema)
                structured: StructuredResult = StructuredResult(
                    data=data,
                    valid=True,
                    attempts=1,
                )
            except OutputValidationError as exc:
                structured = StructuredResult(
                    data=None,
                    raw=content,
                    valid=False,
                    error=str(exc),
                    attempts=1,
                )
            return Response(content=structured, metadata=metadata)

        return Response(content=content, metadata=metadata)

    def __repr__(self) -> str:
        return f"A2AAgent(name={self.config.name!r}, url={self._url!r})"


def _extract_text(event: Any) -> str:
    """Best-effort extraction of text content from an A2A client event or Message."""
    try:
        from a2a.types import Message

        # New SDK API: send_message yields Message objects or (Task, event) tuples.
        if isinstance(event, Message):
            return " ".join(
                part.root.text for part in event.parts if hasattr(part.root, "text")
            )
        # ClientEvent = tuple[Task, TaskStatusUpdateEvent | TaskArtifactUpdateEvent | None]
        if isinstance(event, tuple):
            task, _update = event
            # Primary path: completed task status carries the agent reply.
            msg = getattr(getattr(task, "status", None), "message", None)
            if msg and msg.parts:
                return " ".join(
                    part.root.text for part in msg.parts if hasattr(part.root, "text")
                )
            # Fallback: artifact parts (some servers use artifacts instead).
            artifacts = getattr(task, "artifacts", None) or []
            for artifact in artifacts:
                text = " ".join(
                    part.root.text
                    for part in (artifact.parts or [])
                    if hasattr(part.root, "text")
                )
                if text:
                    return text
    except Exception:  # noqa: BLE001
        pass
    return str(event)
