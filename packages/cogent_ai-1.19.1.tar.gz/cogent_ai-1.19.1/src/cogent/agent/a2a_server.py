"""A2A server — expose a cogent Agent as an A2A-protocol HTTP endpoint.

Any external A2A client (including :class:`~cogent.agent.a2a.A2AAgent`) can
call a cogent agent once it is served with this module.

Requires the ``a2a`` extra (which includes the ``http-server`` dependency)::

    uv add "cogent-ai[a2a]"

Low-level usage (full control)::

    from cogent.agent.a2a_server import A2AServer

    server = A2AServer(agent, port=10002)
    server.run()                        # blocking

    # or mount the ASGI app into an existing FastAPI application:
    existing_app.mount("/a2a", server.app)

Mid-level usage::

    from cogent.agent.a2a_server import serve_agent
    import asyncio

    asyncio.run(serve_agent(agent, port=10002))

High-level usage (recommended for simple scripts)::

    agent.serve(port=10002)
"""

from __future__ import annotations

import asyncio
import uuid
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from cogent.agent.base import Agent


# ---------------------------------------------------------------------------
# Internal executor bridge
# ---------------------------------------------------------------------------


class _AgentExecutor:
    """Bridges an A2A :class:`RequestContext` to a cogent :class:`Agent`.

    Implements ``a2a.server.agent_execution.AgentExecutor``.  Kept private;
    users interact through :class:`A2AServer` or :func:`serve_agent`.
    """

    def __init__(self, agent: Agent, *, streaming: bool = True) -> None:
        self._agent = agent
        self._streaming = streaming

    async def execute(self, context: Any, event_queue: Any) -> None:  # noqa: ANN401
        """Run the cogent agent and publish the result to *event_queue*."""
        try:
            from a2a.types import (
                Message,
                Part,
                Role,
                TaskState,
                TaskStatus,
                TaskStatusUpdateEvent,
                TextPart,
            )
        except ImportError as exc:
            raise ImportError(
                "A2AServer requires the 'a2a' extra: uv add 'cogent-ai[a2a]'"
            ) from exc

        from cogent.core.context import RunContext

        task = context.get_user_input()

        # Bridge A2A context identifiers into cogent RunContext so that
        # observability (tracing, lineage) works end-to-end.
        run_context = RunContext(
            run_id=context.task_id or str(uuid.uuid4()),
            metadata={
                "a2a_context_id": context.context_id or "",
                "a2a_task_id": context.task_id or "",
            },
        )

        if self._streaming:
            await self._execute_streaming(
                context,
                event_queue,
                task,
                run_context,
                TaskState,
                TaskStatus,
                TaskStatusUpdateEvent,
                Message,
                Part,
                Role,
                TextPart,
            )
        else:
            await self._execute_batch(
                context,
                event_queue,
                task,
                run_context,
                TaskState,
                TaskStatus,
                TaskStatusUpdateEvent,
                Message,
                Part,
                Role,
                TextPart,
            )

    async def _execute_batch(
        self,
        context: Any,
        event_queue: Any,
        task: str,
        run_context: Any,
        TaskState: Any,  # noqa: N803
        TaskStatus: Any,  # noqa: N803
        TaskStatusUpdateEvent: Any,  # noqa: N803
        Message: Any,  # noqa: N803
        Part: Any,
        Role: Any,
        TextPart: Any,
    ) -> None:
        """Single-shot execution — emit one final event when done."""
        try:
            response = await self._agent.run(task, context=run_context)
            content = response.content
            # Structured output: serialize the parsed data as JSON so the
            # calling A2AAgent can deserialize it back into a typed model.
            from cogent.agent.output import StructuredResult

            if (
                isinstance(content, StructuredResult)
                and content.valid
                and content.data is not None
            ):
                data = content.data
                if hasattr(data, "model_dump_json"):
                    text = data.model_dump_json()
                else:
                    import dataclasses
                    import json as _json

                    text = _json.dumps(
                        dataclasses.asdict(data)
                        if dataclasses.is_dataclass(data)
                        else vars(data)
                    )
            elif isinstance(content, str):
                text = content
            else:
                text = str(content)
            state = TaskState.completed
        except Exception as exc:  # noqa: BLE001
            text = f"Agent error: {exc}"
            state = TaskState.failed

        message = Message(
            role=Role.agent,
            message_id=str(uuid.uuid4()),
            task_id=context.task_id,
            context_id=context.context_id,
            parts=[Part(root=TextPart(text=text))],
        )
        await event_queue.enqueue_event(
            TaskStatusUpdateEvent(
                task_id=context.task_id,
                context_id=context.context_id,
                final=True,
                status=TaskStatus(state=state, message=message),
            )
        )

    async def _execute_streaming(
        self,
        context: Any,
        event_queue: Any,
        task: str,
        run_context: Any,
        TaskState: Any,  # noqa: N803
        TaskStatus: Any,  # noqa: N803
        TaskStatusUpdateEvent: Any,  # noqa: N803
        Message: Any,  # noqa: N803
        Part: Any,
        Role: Any,
        TextPart: Any,
    ) -> None:
        """Streaming execution — emit incremental token events then a final event."""
        from cogent.agent.streaming import StreamTraceType

        accumulated = ""
        state = TaskState.completed
        try:
            async for event in self._agent.stream_events(
                task,
                correlation_id=context.task_id,
                include_tools=True,
            ):
                if event.type == StreamTraceType.TOKEN and event.content:
                    accumulated += event.content
                    # Emit an incremental working update for each token chunk.
                    await event_queue.enqueue_event(
                        TaskStatusUpdateEvent(
                            task_id=context.task_id,
                            context_id=context.context_id,
                            final=False,
                            status=TaskStatus(
                                state=TaskState.working,
                                message=Message(
                                    role=Role.agent,
                                    message_id=str(uuid.uuid4()),
                                    task_id=context.task_id,
                                    context_id=context.context_id,
                                    parts=[Part(root=TextPart(text=event.content))],
                                ),
                            ),
                        )
                    )
                elif event.type == StreamTraceType.ERROR:
                    accumulated = event.error or "Agent error"
                    state = TaskState.failed
        except Exception as exc:  # noqa: BLE001
            accumulated = f"Agent error: {exc}"
            state = TaskState.failed

        # Emit the final event with the complete accumulated text.
        final_text = accumulated or "(no response)"
        await event_queue.enqueue_event(
            TaskStatusUpdateEvent(
                task_id=context.task_id,
                context_id=context.context_id,
                final=True,
                status=TaskStatus(
                    state=state,
                    message=Message(
                        role=Role.agent,
                        message_id=str(uuid.uuid4()),
                        task_id=context.task_id,
                        context_id=context.context_id,
                        parts=[Part(root=TextPart(text=final_text))],
                    ),
                ),
            )
        )

    async def cancel(self, context: Any, event_queue: Any) -> None:  # noqa: ANN401
        """Acknowledge a cancellation request."""
        try:
            from a2a.types import TaskState, TaskStatus, TaskStatusUpdateEvent
        except ImportError:
            return

        await event_queue.enqueue_event(
            TaskStatusUpdateEvent(
                task_id=context.task_id,
                context_id=context.context_id,
                final=True,
                status=TaskStatus(state=TaskState.canceled),
            )
        )


# ---------------------------------------------------------------------------
# A2AServer
# ---------------------------------------------------------------------------


class ServerGroup:
    """A collection of background :class:`A2AServer` instances.

    Returned by :meth:`A2AServer.start_many`.  Call :meth:`stop_all` when
    you are done.
    """

    def __init__(self, servers: "list[A2AServer]") -> None:
        self._servers = servers

    async def stop_all(self) -> None:
        """Stop all servers concurrently."""
        await asyncio.gather(*(s.stop() for s in self._servers))

    def __iter__(self):
        return iter(self._servers)

    def __len__(self) -> int:
        return len(self._servers)


class A2AServer:
    """Expose a cogent :class:`~cogent.agent.base.Agent` as an A2A HTTP server.

    Builds an ``A2AFastAPIApplication`` backed by the agent, derives an
    ``AgentCard`` from the agent's configuration, and optionally starts a
    uvicorn server.

    Args:
        agent: The cogent agent to serve.
        host: Bind address (default ``"0.0.0.0"``).
        port: TCP port (default ``10000``).
        url: Public base URL written into the ``AgentCard`` (e.g.
            ``"http://my-host:10000"``).  When omitted,
            ``http://{host}:{port}`` is used.
        version: Version string written into the ``AgentCard``
            (default ``"1.0"``).
        skills: Additional :class:`a2a.types.AgentSkill` declarations.
            A default skill is always derived from the agent's name and
            description; this list extends it.
        task_store: Where to persist A2A tasks.

            - ``None`` (default) — in-memory; tasks are lost on restart.
            - ``str`` — SQLAlchemy async database URL (e.g.
              ``"sqlite+aiosqlite:///tasks.db"`` or
              ``"postgresql+asyncpg://user:pass@host/db"``).  The table
              is created automatically on first use.  Requires the
              corresponding SQLAlchemy driver (``aiosqlite``,
              ``asyncpg``, etc.) to be installed.
            - ``TaskStore`` instance — bring your own implementation.
        streaming: When ``True`` (default) the executor emits incremental
            SSE token events during agent execution so callers receive live
            output.  Set to ``False`` to emit a single final event instead.
        push_notifications: When ``True``, enable A2A push-notification
            webhooks.  Clients may register a callback URL via
            ``tasks/pushNotification/set``; the server will POST task-status
            updates to that URL as the task progresses.  Defaults to
            ``False``.
        security_schemes: Optional mapping of scheme name →
            :class:`a2a.types.SecurityScheme` written into the
            ``AgentCard``.  Follows the OpenAPI 3.0 Security Scheme Object
            (API key, HTTP bearer, OAuth2, etc.).
        security: Optional list of security requirement objects applied to
            all interactions, following the OpenAPI 3.0 Security Requirement
            Object format (e.g. ``[{"api-key": []}]``).

    Example::

        from cogent import Agent
        from cogent.agent.a2a_server import A2AServer

        agent = Agent(name="analyst", model="gpt-5.4", instructions="...")

        # Persistent SQLite task store
        A2AServer(agent, port=10002, task_store="sqlite+aiosqlite:///tasks.db").run()

        # Mount into existing FastAPI app
        existing_app.mount("/a2a", A2AServer(agent, port=10002).app)
    """

    def __init__(
        self,
        agent: Agent,
        *,
        host: str = "0.0.0.0",
        port: int = 10000,
        url: str | None = None,
        version: str = "1.0",
        skills: list[Any] | None = None,
        task_store: Any | str | None = None,
        streaming: bool = True,
        push_notifications: bool = False,
        security_schemes: dict[str, Any] | None = None,
        security: list[dict[str, list[str]]] | None = None,
    ) -> None:
        self._agent = agent
        self._host = host
        self._port = port
        self._url = url or f"http://{host}:{port}"
        self._version = version
        self._extra_skills = skills or []
        self._task_store_arg = task_store
        self._streaming = streaming
        self._push_notifications = push_notifications
        self._security_schemes = security_schemes
        self._security = security
        self._app: Any | None = None
        self._task_store: Any | None = None  # resolved lazily
        self._push_httpx_client: Any | None = None  # owned when push_notifications=True

    # ------------------------------------------------------------------
    # Public properties
    # ------------------------------------------------------------------

    @property
    def app(self) -> Any:
        """The underlying FastAPI ASGI application.

        Builds and caches the app on first access.  Mount it into an
        existing FastAPI instance with ``parent.mount("/a2a", server.app)``.
        """
        if self._app is None:
            self._app = self._build_app()
        return self._app

    def agent_card(self) -> Any:
        """Build and return the :class:`a2a.types.AgentCard` for this agent.

        The card is derived from the agent's ``config.name`` and
        ``config.description``.  Override by passing ``skills=`` to the
        constructor.
        """
        try:
            from a2a.types import AgentCapabilities, AgentCard, AgentSkill
        except ImportError as exc:
            raise ImportError(
                "A2AServer requires the 'a2a' extra: uv add 'cogent-ai[a2a]'"
            ) from exc

        default_skill = AgentSkill(
            id=self._agent.config.name.lower().replace(" ", "_"),
            name=self._agent.config.name,
            description=self._agent.config.description
            or f"{self._agent.config.name} agent",
            tags=[self._agent.config.name.lower()],
            input_modes=["text/plain"],
            output_modes=["text/plain"],
        )

        kwargs: dict[str, Any] = {}
        if self._security_schemes is not None:
            kwargs["security_schemes"] = self._security_schemes
        if self._security is not None:
            kwargs["security"] = self._security

        return AgentCard(
            name=self._agent.config.name,
            description=self._agent.config.description
            or f"{self._agent.config.name} agent",
            url=self._url,
            version=self._version,
            capabilities=AgentCapabilities(
                streaming=self._streaming or None,
                push_notifications=self._push_notifications or None,
            ),
            default_input_modes=["text/plain"],
            default_output_modes=["text/plain"],
            skills=[default_skill, *self._extra_skills],
            **kwargs,
        )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self, *, background: bool = True) -> "A2AServer":
        """Start the server.

        Args:
            background: When ``True`` (default) the server is launched as a
                background task, the method returns ``self`` as soon as the
                port is bound and accepting connections, and you are
                responsible for calling :meth:`stop` when done.
                When ``False`` this coroutine blocks until the server is
                stopped — suitable for ``__main__`` scripts.

        Returns:
            ``self``, so you can chain ``await server.start()``.

        Example — explicit background lifecycle::

            analyst = await A2AServer(agent1, port=10001).start()
            writer  = await A2AServer(agent2, port=10002).start()

            # ... do work ...

            await analyst.stop()
            await writer.stop()
        """
        try:
            import uvicorn
        except ImportError as exc:
            raise ImportError(
                "A2AServer requires uvicorn. Install the 'a2a' extra: "
                "uv add 'cogent-ai[a2a]'"
            ) from exc

        await self._ensure_task_store_ready()

        if background:
            config = uvicorn.Config(
                app=self.app,
                host=self._host,
                port=self._port,
                log_level="warning",
            )
            self._uvicorn_server = uvicorn.Server(config)
            self._server_task = asyncio.create_task(self._uvicorn_server.serve())
            while not self._uvicorn_server.started:
                await asyncio.sleep(0.05)
            return self
        else:
            config = uvicorn.Config(
                app=self.app,
                host=self._host,
                port=self._port,
                log_level="info",
            )
            self._uvicorn_server = uvicorn.Server(config)
            await self._uvicorn_server.serve()
            return self

    async def stop(self) -> None:
        """Stop a background server started with ``start(background=True)``.

        Safe to call even if the server is not running.
        """
        if not hasattr(self, "_uvicorn_server"):
            return
        self._uvicorn_server.should_exit = True
        if hasattr(self, "_server_task"):
            await self._server_task
        if self._push_httpx_client is not None:
            await self._push_httpx_client.aclose()
            self._push_httpx_client = None

    def run(self) -> None:
        """Start the server synchronously (blocks until stopped).

        Equivalent to ``asyncio.run(server.start())``.  Intended for use in
        ``__main__`` blocks and scripts.
        """
        asyncio.run(self.start(background=False))

    @classmethod
    async def start_many(
        cls,
        *servers: "tuple[Agent, int] | A2AServer",
    ) -> "ServerGroup":
        """Start multiple A2A servers concurrently and return a :class:`ServerGroup`.

        Each entry can be either a ready-made ``A2AServer`` instance or a
        ``(agent, port)`` tuple (uses all other defaults).

        Example::

            group = await A2AServer.start_many(
                (analyst,    10001),
                (researcher, 10002),
                (writer,     10003),
            )

            # ... do work ...

            await group.stop_all()
        """
        instances: list[A2AServer] = []
        for entry in servers:
            if isinstance(entry, A2AServer):
                instances.append(entry)
            else:
                agent, port = entry
                instances.append(cls(agent, port=port))

        await asyncio.gather(*(s.start(background=True) for s in instances))
        return ServerGroup(instances)

    async def __aenter__(self) -> "A2AServer":
        return await self.start(background=True)

    async def __aexit__(self, *_: object) -> None:
        await self.stop()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _build_app(self) -> Any:
        try:
            from a2a.server.apps import A2AFastAPIApplication
            from a2a.server.request_handlers import DefaultRequestHandler
            from a2a.server.tasks import InMemoryTaskStore
        except ImportError as exc:
            raise ImportError(
                "A2AServer requires the 'a2a' extra: uv add 'cogent-ai[a2a]'"
            ) from exc

        if self._task_store is None:
            self._task_store = self._make_task_store(InMemoryTaskStore)

        push_config_store = None
        push_sender = None
        if self._push_notifications:
            push_config_store, push_sender = self._make_push_notification_handler()

        executor = _AgentExecutor(self._agent, streaming=self._streaming)
        handler = DefaultRequestHandler(
            agent_executor=executor,
            task_store=self._task_store,
            push_config_store=push_config_store,
            push_sender=push_sender,
        )
        return A2AFastAPIApplication(
            agent_card=self.agent_card(),
            http_handler=handler,
        ).build()

    def _make_push_notification_handler(self) -> tuple[Any, Any]:
        """Create push notification config store and sender."""
        try:
            import httpx

            from a2a.server.tasks import (
                BasePushNotificationSender,
                InMemoryPushNotificationConfigStore,
            )
        except ImportError as exc:
            raise ImportError(
                "Push notifications require the 'a2a' extra: uv add 'cogent-ai[a2a]'"
            ) from exc

        config_store = InMemoryPushNotificationConfigStore()
        self._push_httpx_client = httpx.AsyncClient()
        sender = BasePushNotificationSender(
            httpx_client=self._push_httpx_client,
            config_store=config_store,
        )
        return config_store, sender

    def _make_task_store(self, InMemoryTaskStore: Any) -> Any:  # noqa: N803
        """Instantiate (but do not initialise) the task store."""
        arg = self._task_store_arg
        if arg is None:
            return InMemoryTaskStore()
        if isinstance(arg, str):
            try:
                from sqlalchemy.ext.asyncio import create_async_engine

                from a2a.server.tasks import DatabaseTaskStore
            except ImportError as exc:
                raise ImportError(
                    "A database task_store URL requires sqlalchemy and an async "
                    "driver (e.g. aiosqlite for SQLite, asyncpg for PostgreSQL). "
                    "Install with: uv add sqlalchemy aiosqlite"
                ) from exc
            engine = create_async_engine(arg)
            return DatabaseTaskStore(engine, create_table=True)
        # Assume it is already a TaskStore instance.
        return arg

    async def _ensure_task_store_ready(self) -> None:
        """Initialise a database-backed task store (creates tables if needed)."""
        # .app access triggers _build_app which populates self._task_store
        _ = self.app
        if hasattr(self._task_store, "initialize"):
            await self._task_store.initialize()

    def __repr__(self) -> str:
        return f"A2AServer(agent={self._agent.config.name!r}, url={self._url!r})"


# ---------------------------------------------------------------------------
# Convenience function
# ---------------------------------------------------------------------------


async def serve_agent(
    agent: Agent,
    *,
    host: str = "0.0.0.0",
    port: int = 10000,
    url: str | None = None,
    version: str = "1.0",
    task_store: Any | str | None = None,
    streaming: bool = True,
    push_notifications: bool = False,
    security_schemes: dict[str, Any] | None = None,
    security: list[dict[str, list[str]]] | None = None,
) -> None:
    """Start an A2A server for a cogent agent.

    Coroutine that blocks until the server is stopped.  Suitable for use
    with ``asyncio.run()`` or inside an existing async entrypoint.

    Args:
        agent: The cogent agent to serve.
        host: Bind address (default ``"0.0.0.0"``).
        port: TCP port (default ``10000``).
        url: Public base URL for the ``AgentCard``.  Defaults to
            ``http://{host}:{port}``.
        version: Version string for the ``AgentCard`` (default ``"1.0"``).
        task_store: ``None`` (in-memory), a SQLAlchemy async URL string, or
            a :class:`a2a.server.tasks.TaskStore` instance.
        streaming: Emit incremental SSE token events (default ``True``).
        push_notifications: Enable webhook push-notification callbacks
            (default ``False``).
        security_schemes: Optional mapping of scheme name to
            :class:`a2a.types.SecurityScheme` for the ``AgentCard``.
        security: Optional list of security requirement objects for the
            ``AgentCard``.

    Example::

        import asyncio
        from cogent.agent.a2a_server import serve_agent

        asyncio.run(serve_agent(agent, port=10002))

        # With persistent SQLite task store and push notifications:
        asyncio.run(serve_agent(
            agent,
            port=10002,
            task_store="sqlite+aiosqlite:///tasks.db",
            push_notifications=True,
        ))
    """
    server = A2AServer(
        agent,
        host=host,
        port=port,
        url=url,
        version=version,
        task_store=task_store,
        streaming=streaming,
        push_notifications=push_notifications,
        security_schemes=security_schemes,
        security=security,
    )
    await server.start()
