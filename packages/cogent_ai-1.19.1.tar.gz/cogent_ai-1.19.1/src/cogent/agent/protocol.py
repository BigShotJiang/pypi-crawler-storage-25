"""Protocol definitions for agent interoperability.

Defines AgentLike — a structural protocol satisfied by both local Agent
instances and remote adapters such as A2AAgent.  Any object that exposes a
``config`` attribute (with ``.name`` and ``.description``) and an async
``run()`` method can participate in the subagent system.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

if TYPE_CHECKING:
    from cogent.core.context import RunContext
    from cogent.core.response import Response


@runtime_checkable
class AgentLike(Protocol):
    """Structural protocol for objects usable as subagents.

    Satisfied by local ``Agent`` instances and remote adapters (e.g.
    ``A2AAgent``).  The protocol intentionally stays minimal so that
    lightweight adapters are easy to write.

    Required attributes:
        config: An object with ``.name: str`` and ``.description: str``.

    Required methods:
        run: Async callable accepting a task string and returning a Response.
    """

    @property
    def config(self) -> Any:
        """Agent configuration exposing at minimum ``.name`` and ``.description``."""
        ...

    async def run(
        self,
        task: str,
        *,
        context: RunContext | None = None,
        returns: type | dict | None = None,
        **kwargs: Any,
    ) -> Response:
        """Execute a task and return a Response."""
        ...
