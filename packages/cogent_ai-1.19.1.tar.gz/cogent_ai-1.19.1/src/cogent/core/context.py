"""
RunContext - Invocation-scoped context for agents.

RunContext provides dependency injection for tools and interceptors,
allowing typed data to be passed at invocation time without global state.

Example:
    from dataclasses import dataclass
    from cogent import Agent, RunContext, tool

    @dataclass
    class AppContext(RunContext):
        user_id: str
        db: Database
        api_key: str

    @tool
    def get_user_data(ctx: RunContext) -> str:
        '''Get data for the current user.'''
        user = ctx.db.get_user(ctx.user_id)
        return f"User: {user.name}"

    agent = Agent(name="assistant", model=model, tools=[get_user_data])

    result = await agent.run(
        "Get my profile data",
        context=AppContext(user_id="123", db=db, api_key=key),
    )
"""

from __future__ import annotations

from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from cogent.agent.base import Agent

# Module-level ContextVar that holds the run_id of the currently-executing
# agent.  When a child agent starts (e.g. a subagent) it reads this value as
# its own parent_run_id, ensuring the observability lineage chain is preserved
# even when no user-provided context is in play.  Each Agent sets this at the
# start of run() and resets it (via token) in the finally block so sequential
# subagent calls each see the correct parent run_id.
_LINEAGE_CV: ContextVar[str | None] = ContextVar("cogent_lineage_run_id", default=None)


@dataclass
class RunContext:
    """Base class for invocation-scoped context.

    Subclass this to define typed context data that will be available
    to tools and interceptors during agent execution.

    The context is:
    - Passed to agent.run() at invocation time
    - Available to interceptors via InterceptContext.run_context
    - Available to tools that declare a `ctx: RunContext` parameter
    - Immutable during execution (create new instance to change)

    Attributes:
        query: The original user query that initiated execution.
            Auto-populated by the framework on first agent.run() call.
            Preserved across agent delegations for task lineage tracking.
        run_id: Stable ID for the current agent invocation.
            Auto-populated by the framework when not provided.
        parent_run_id: Optional parent invocation ID for nested/subagent flows.
        metadata: Optional dict for untyped extension data.
        agent: Internal reference to the executing agent (set by executor).

    Example:
        @dataclass
        class MyContext(RunContext):
            user_id: str
            session_id: str
            permissions: list[str] = field(default_factory=list)

            def has_permission(self, perm: str) -> bool:
                return perm in self.permissions

        # Use in tool
        @tool
        def admin_action(action: str, ctx: RunContext) -> str:
            '''Perform admin action. Requires admin permission.'''
            if not ctx.has_permission("admin"):
                return "Permission denied"
            return f"Performed: {action}"
    """

    query: str = field(default="", repr=False)
    run_id: str = field(default="", repr=False)
    parent_run_id: str | None = field(default=None, repr=False)
    metadata: dict[str, Any] = field(default_factory=dict)
    agent: Agent | None = field(default=None, repr=False, init=False)
    # Internal flag — True when this context was auto-created by the framework
    # (i.e. the caller passed context=None).  SubagentRegistry uses this to
    # decide whether to pass None or a delegated context to sub-agents.
    _synthetic: bool = field(default=False, repr=False, init=False)

    def get[T](self, key: str, default: T | None = None) -> T | None:
        """Get a metadata value by key.

        Args:
            key: The metadata key.
            default: Default value if key not found.

        Returns:
            The value or default.
        """
        return self.metadata.get(key, default)

    def with_metadata(self, **kwargs: Any) -> RunContext:
        """Create a new context with additional metadata.

        This does not modify the current context.

        Args:
            **kwargs: Metadata to add.

        Returns:
            New RunContext with merged metadata.
        """
        new_metadata = {**self.metadata, **kwargs}
        # Create a copy with updated metadata
        # This works for subclasses too via __class__
        import copy

        new_ctx = copy.copy(self)
        new_ctx.metadata = new_metadata
        return new_ctx

    def with_lineage(
        self,
        *,
        run_id: str,
        parent_run_id: str | None = None,
    ) -> RunContext:
        """Create a new context with updated lineage fields."""
        import copy

        new_ctx = copy.copy(self)
        new_ctx.run_id = run_id
        new_ctx.parent_run_id = parent_run_id
        new_ctx.metadata = {**self.metadata, "run_id": run_id}
        if parent_run_id is not None:
            new_ctx.metadata["parent_run_id"] = parent_run_id
        return new_ctx


# Default empty context for when none is provided
EMPTY_CONTEXT = RunContext()


__all__ = [
    "RunContext",
    "EMPTY_CONTEXT",
    "_LINEAGE_CV",
]
