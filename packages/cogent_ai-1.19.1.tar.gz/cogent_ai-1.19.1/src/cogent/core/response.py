"""Unified Response Protocol.

This module provides the core types for the unified response protocol used
throughout Cogent. All agent operations (run, think, etc.) return a
Response[T] object that contains the result plus rich metadata.

The Response[T] generic container ensures:
- Type safety for response content
- Consistent metadata access (tokens, timing, model info)
- Tool call tracking
- Event integration
- Standardized error handling
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    pass


@dataclass
class TokenUsage:
    """Token usage information from model execution.

    Attributes:
        prompt_tokens: Tokens in the prompt/input
        completion_tokens: Tokens in the completion/output
        total_tokens: Sum of prompt and completion tokens
        reasoning_tokens: Tokens used for reasoning/thinking (if available)
    """

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    reasoning_tokens: int | None = None

    def to_dict(self) -> dict[str, int | None]:
        """Convert to dictionary for serialization."""
        result = {
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
        }
        if self.reasoning_tokens is not None:
            result["reasoning_tokens"] = self.reasoning_tokens
        return result


@dataclass
class ToolCall:
    """Information about a tool invocation.

    Attributes:
        tool_name: Name of the tool that was called
        arguments: Arguments passed to the tool
        result: Result returned by the tool
        duration: Execution time in seconds
        success: Whether the call succeeded
        error: Error message if call failed
    """

    tool_name: str
    arguments: dict[str, Any]
    result: Any
    duration: float
    success: bool
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "tool_name": self.tool_name,
            "arguments": self.arguments,
            "result": self.result,
            "duration": self.duration,
            "success": self.success,
            "error": self.error,
        }


@dataclass
class ErrorInfo:
    """Error information from failed execution.

    Attributes:
        message: Human-readable error message
        type: Error type/category
        traceback: Stack trace (if available)
    """

    message: str
    type: str
    traceback: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "message": self.message,
            "type": self.type,
            "traceback": self.traceback,
        }


@dataclass
class ResponseMetadata:
    """Consistent metadata across all responses.

    Attributes:
        agent: Name of the agent that generated response
        model: Model name/identifier used (if applicable)
        tokens: Token usage information
        duration: Execution duration in seconds
        timestamp: Unix timestamp of response creation (machine-readable)
        timestamp_iso: ISO 8601 formatted timestamp (human-readable)
        correlation_id: ID linking related operations
        trace_id: ID for distributed tracing
        delegation_chain: List of subagent delegations with metadata
    """

    agent: str
    model: str | None = None
    tokens: TokenUsage | None = None
    duration: float = 0.0
    timestamp: float = field(default_factory=time.time)
    timestamp_iso: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    correlation_id: str | None = None
    trace_id: str | None = None
    delegation_chain: list[dict[str, Any]] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        result = {
            "agent": self.agent,
            "model": self.model,
            "tokens": self.tokens.to_dict() if self.tokens else None,
            "duration": self.duration,
            "timestamp": self.timestamp,
            "timestamp_iso": self.timestamp_iso,
            "correlation_id": self.correlation_id,
            "trace_id": self.trace_id,
        }
        if self.delegation_chain is not None:
            result["delegation_chain"] = self.delegation_chain
        return result


@dataclass
class Response[T]:
    """Unified response container for all agent/tool operations.

    This is the canonical response type used throughout Cogent:
    - Agent.run() returns Response[T]
    - Agent.think() returns Response[str]
    - Tools return Response[ToolResult]
    - A2A delegation returns Response[Any]

    Attributes:
        content: The actual response data (generic over type)
        metadata: Consistent metadata (tokens, timing, model, etc)
        tool_calls: List of tool invocations during execution
        events: Events emitted during execution
        messages: Full conversation history (system, user, assistant, tool messages)
        error: Error information if execution failed
        subagent_responses: Responses from delegated subagents (for metadata aggregation)

    Examples:
        # Basic usage
        response = await agent.run("task")
        result = response.content
        tokens = response.metadata.tokens.total_tokens

        # Type-safe unwrap
        result = response.unwrap()  # Raises if error

        # Convert to event
        event = response.to_event("task.done", agent.name)

        # Check success
        if response.success:
            print(f"Used {response.metadata.tokens.total_tokens} tokens")

        # Inspect conversation
        for msg in response.messages:
            print(f"{msg.role}: {msg.content[:100]}")

        # Access subagent data
        if response.subagent_responses:
            for sub_resp in response.subagent_responses:
                print(f"Subagent {sub_resp.metadata.agent}: {sub_resp.metadata.tokens.total_tokens} tokens")
    """

    content: T
    metadata: ResponseMetadata
    tool_calls: list[ToolCall] = field(default_factory=list)
    events: list[Any] = field(default_factory=list)  # Will be list[Event] at runtime
    messages: list[Any] = field(
        default_factory=list
    )  # Will be list[BaseMessage] at runtime
    error: ErrorInfo | None = None
    subagent_responses: list[Response] | None = None

    @property
    def success(self) -> bool:
        """Whether execution succeeded (no error)."""
        return self.error is None

    def events_of(self, pattern: str) -> list[Any]:
        """Return captured events matching a type pattern (supports glob, e.g. 'tool.*')."""
        import fnmatch

        return [e for e in self.events if fnmatch.fnmatch(e.type, pattern)]

    def unwrap(self) -> T:
        """Get content or raise error if failed.

        Returns:
            The content value

        Raises:
            ResponseError: If response contains an error
        """
        if self.error:
            raise ResponseError(self.error.message, response=self)
        return self.content

    # REMOVED: to_event method - cogent.events module removed
    # def to_event(self, name: str, source: str) -> Event:
    #     """Convert response to event with full metadata.
    #
    #     Args:
    #         name: Event name (e.g., "task.done")
    #         source: Event source (e.g., agent name)
    #
    #     Returns:
    #         Event with response data and metadata
    #     """
    #     from cogent.events import Event
    #
    #     return Event(
    #         name=name,
    #         source=source,
    #         data={
    #             "content": self.content,
    #             "metadata": self.metadata.to_dict(),
    #             "tool_calls": [tc.to_dict() for tc in self.tool_calls],
    #             "success": self.success,
    #         },
    #         correlation_id=self.metadata.correlation_id,
    #         metadata=self.metadata.to_dict(),
    #     )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        result = {
            "content": self.content,
            "metadata": self.metadata.to_dict(),
            "tool_calls": [tc.to_dict() for tc in self.tool_calls],
            "events": [e.to_dict() for e in self.events],
            "messages": [
                m.to_dict() if hasattr(m, "to_dict") else str(m) for m in self.messages
            ],
            "error": self.error.to_dict() if self.error else None,
            "success": self.success,
        }
        if self.subagent_responses is not None:
            result["subagent_responses"] = [
                sr.to_dict() for sr in self.subagent_responses
            ]
        return result


class ResponseError(Exception):
    """Exception raised when unwrapping a failed Response.

    Attributes:
        response: The original Response object that failed
    """

    def __init__(self, message: str, response: Response) -> None:
        """Initialize ResponseError.

        Args:
            message: Error message
            response: The original Response object
        """
        super().__init__(message)
        self.response = response
