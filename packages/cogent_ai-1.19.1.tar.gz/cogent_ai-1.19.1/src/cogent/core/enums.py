"""
Enums for Cogent - defines status types and roles.
"""

from enum import IntEnum, StrEnum


class TaskStatus(StrEnum):
    """Task lifecycle states."""

    PENDING = "pending"
    SCHEDULED = "scheduled"
    BLOCKED = "blocked"
    RUNNING = "running"
    SPAWNING = "spawning"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

    def is_terminal(self) -> bool:
        """Check if this status is a terminal state."""
        return self in (TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED)

    def is_active(self) -> bool:
        """Check if this status indicates active work."""
        return self in (TaskStatus.RUNNING, TaskStatus.SPAWNING)


class AgentStatus(StrEnum):
    """Agent lifecycle states."""

    IDLE = "idle"
    THINKING = "thinking"
    ACTING = "acting"
    WAITING = "waiting"
    ERROR = "error"
    OFFLINE = "offline"

    def is_available(self) -> bool:
        """Check if agent can accept new work."""
        return self == AgentStatus.IDLE

    def is_working(self) -> bool:
        """Check if agent is currently working."""
        return self in (AgentStatus.THINKING, AgentStatus.ACTING)


class Priority(IntEnum):
    """Task priority levels."""

    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4

    def __lt__(self, other: "Priority") -> bool:
        if isinstance(other, Priority):
            return self.value < other.value
        return NotImplemented

    def __le__(self, other: "Priority") -> bool:
        if isinstance(other, Priority):
            return self.value <= other.value
        return NotImplemented

    def __gt__(self, other: "Priority") -> bool:
        if isinstance(other, Priority):
            return self.value > other.value
        return NotImplemented

    def __ge__(self, other: "Priority") -> bool:
        if isinstance(other, Priority):
            return self.value >= other.value
        return NotImplemented


class AgentRole(StrEnum):
    """
    Agent roles define CAPABILITIES, not job titles.

    Each role is a combination of three core capabilities:
    - can_finish: Can end the flow with FINAL ANSWER
    - can_delegate: Can assign/route work to other agents
    - can_use_tools: Can call external tools

    ┌─────────────┬────────────┬──────────────┬───────────────┐
    │ Role        │ can_finish │ can_delegate │ can_use_tools │
    ├─────────────┼────────────┼──────────────┼───────────────┤
    │ WORKER      │     ❌     │      ❌      │      ✅       │
    │ SUPERVISOR  │     ✅     │      ✅      │      ❌       │
    │ AUTONOMOUS  │     ✅     │      ❌      │      ✅       │
    │ REVIEWER    │     ✅     │      ❌      │      ❌       │
    └─────────────┴────────────┴──────────────┴───────────────┘

    Usage Guide:
    ─────────────
    WORKER: The doer. Executes tasks, uses tools, reports results.
            Cannot finish the flow - must pass work to someone who can.
            Example: Researcher gathering data, Analyst running queries

    SUPERVISOR: The manager. Delegates work, reviews results, decides.
                Can finish the flow. Does NOT use tools directly.
                Example: Team lead, Project manager, Director

    AUTONOMOUS: The solo expert. Works independently, uses tools, decides.
                Can finish the flow. Perfect for single-agent flows.
                Example: Assistant, Solo analyst, Independent researcher

    REVIEWER: The gatekeeper. Reviews work, approves or rejects.
              Can finish (approve) but doesn't do work or delegate.
              Example: QA reviewer, Editor, Validator

    Topology Patterns:
    ──────────────────
    Pipeline:     WORKER → WORKER → REVIEWER
    Supervisor:   SUPERVISOR ↔ [WORKER, WORKER, WORKER]
    Mesh:         [WORKER, WORKER] ↔ SUPERVISOR (as lead)
    Single:       AUTONOMOUS
    Review:       WORKER → REVIEWER
    """

    # Core roles - just 4, each with distinct capabilities
    WORKER = "worker"
    SUPERVISOR = "supervisor"
    AUTONOMOUS = "autonomous"
    REVIEWER = "reviewer"

    def can_finish(self) -> bool:
        """Check if this role can end the flow with FINAL ANSWER."""
        return _ROLE_CAPABILITIES[self]["can_finish"]

    def can_delegate(self) -> bool:
        """Check if this role can assign/route work to other agents."""
        return _ROLE_CAPABILITIES[self]["can_delegate"]

    def can_use_tools(self) -> bool:
        """Check if this role can call external tools."""
        return _ROLE_CAPABILITIES[self]["can_use_tools"]


# =============================================================================
# Role Capabilities - THE source of truth for what each role can do
# =============================================================================

_ROLE_CAPABILITIES: dict[AgentRole, dict[str, bool]] = {
    AgentRole.WORKER: {
        "can_finish": False,
        "can_delegate": False,
        "can_use_tools": True,
    },
    AgentRole.SUPERVISOR: {
        "can_finish": True,
        "can_delegate": True,
        "can_use_tools": False,
    },
    AgentRole.AUTONOMOUS: {
        "can_finish": True,
        "can_delegate": False,
        "can_use_tools": True,
    },
    AgentRole.REVIEWER: {
        "can_finish": True,
        "can_delegate": False,
        "can_use_tools": False,
    },
}


def get_role_capabilities(role: AgentRole) -> dict[str, bool]:
    """Get capabilities for a role."""
    return _ROLE_CAPABILITIES.get(role, _ROLE_CAPABILITIES[AgentRole.AUTONOMOUS])
