"""
Grouping Console Sink - Decision-tree rendering for tool calls.

Buffers tool events per run and flushes them as an indented tree once
all terminal events (result / error / escalated) arrive.  Keying by
run_id means multiple concurrent agent runs sharing one Observer never
corrupt each other's buffers.
"""

from __future__ import annotations

import re as _re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, TextIO

from cogent.observability.sinks.console import ConsoleSink

if TYPE_CHECKING:
    from cogent.observability.core.event import Event


_TOOL_TERMINAL_ACTIONS: frozenset[str] = frozenset({"result", "error", "escalated"})


@dataclass
class _DecisionState:
    """Mutable state for one in-flight decision tree."""

    buffer: str  # Formatted decision header line
    expected: int  # Terminal events still awaited
    call_buffers: dict[str, str] = field(default_factory=dict)


class GroupingConsoleSink(ConsoleSink):
    """
    Console sink that renders parallel tool calls as a decision tree.

    Each ``llm.tool_decision`` event starts a new tree.  Subsequent
    ``tool.*`` events are buffered under that tree and flushed as one
    block when all terminal (result / error / escalated) events arrive.

    State is keyed by ``run_id`` (taken from ``event.correlation_id``)
    so concurrent agent runs on the same Observer never interfere.

    Example output::

        [FXBot] [tool-decision]
          get_exchange_rate {base='EUR', quote='USD'}
            [tool-result] {base='EUR', quote='USD', rate=1.082}
          get_exchange_rate {base='GBP', quote='USD'}
            [tool-result] {base='GBP', quote='USD', rate=1.271}
    """

    def __init__(
        self,
        stream: TextIO | None = None,
        *,
        auto_newline: bool = True,
    ) -> None:
        super().__init__(stream=stream, auto_newline=auto_newline)
        # Per-run decision state, keyed by run_id (correlation_id)
        self._decisions: dict[str, _DecisionState] = {}

    # ------------------------------------------------------------------
    # Public override
    # ------------------------------------------------------------------

    def handle_event(self, event: Event, output: str) -> None:
        """Route event into grouping logic or fall back to plain write."""
        run_key = event.correlation_id or event.get("run_id") or "_"

        if event.type == "llm.tool_decision":
            self._start_decision(run_key, event, output)
        elif event.category == "tool":
            self._handle_tool(run_key, event, output)
        else:
            self.write(output)

    # ------------------------------------------------------------------
    # Decision-tree management
    # ------------------------------------------------------------------

    def _start_decision(self, run_key: str, event: Event, output: str) -> None:
        """Open a new decision tree, flushing any incomplete predecessor."""
        if run_key in self._decisions:
            self._flush(run_key)

        header = output.split("\n")[0].rstrip()
        tools = event.get("tools_selected") or []
        expected = len(tools) if isinstance(tools, list) else 0

        if expected == 0:
            # No calls expected — print header immediately
            self.write(header)
            return

        self._decisions[run_key] = _DecisionState(buffer=header, expected=expected)

    def _handle_tool(self, run_key: str, event: Event, output: str) -> None:
        """Attach a tool event as a branch of the current decision tree."""
        output = output.rstrip("\n")
        state = self._decisions.get(run_key)

        if state is None:
            # No buffered decision — print as-is
            self.write(output)
            return

        action = event.action
        call_id = str(event.get("call_id") or "")
        tool_name = str(event.get("tool_name") or event.get("tool") or "")

        if action == "called":
            state.call_buffers[call_id] = self._as_call_line(output)

        elif action in _TOOL_TERMINAL_ACTIONS:
            cont = self._as_continuation(output, tool_name)
            if call_id in state.call_buffers:
                state.call_buffers[call_id] += "\n" + cont
            else:
                # Orphan terminal (no preceding call) — create a branch
                state.call_buffers[call_id] = cont
            state.expected -= 1
            if state.expected <= 0:
                self._flush(run_key)

        else:
            # tool.retry or future mid-flight events — append to branch
            cont = self._as_continuation(output, tool_name)
            if call_id in state.call_buffers:
                state.call_buffers[call_id] += "\n" + cont
            # If no branch started yet (shouldn't happen), drop silently

    def _flush(self, run_key: str) -> None:
        """Flush the complete decision tree for run_key to the stream."""
        state = self._decisions.pop(run_key, None)
        if state is None:
            return
        lines = [state.buffer]
        for branch in state.call_buffers.values():
            for ln in branch.split("\n"):
                lines.append("  " + ln)
        self.write("\n".join(lines))

    # ------------------------------------------------------------------
    # String helpers (operate on pre-formatted ANSI strings)
    # ------------------------------------------------------------------

    @staticmethod
    def _as_call_line(raw: str) -> str:
        """Extract the body line (tool name + args) from a tool.called block."""
        lines = raw.split("\n")
        return lines[1].strip() if len(lines) > 1 else ""

    @staticmethod
    def _as_continuation(raw: str, tool_name: str = "") -> str:
        """Strip agent prefix, call ID, and tool name; collapse body to one line."""
        lines = raw.split("\n")
        m = _re.search(r"(\[tool-[a-z]+\].*)", lines[0])
        first = m.group(1) if m else lines[0].lstrip()
        # Strip dim-wrapped 8-hex call ID (any ANSI dim escape)
        first = _re.sub(r"\s*\x1b\[[0-9;]*m[0-9a-f]{8}\x1b\[0m\s*", " ", first)
        # Strip ANSI-styled tool name using the known tool_name string
        if tool_name:
            escaped = _re.escape(tool_name)
            first = _re.sub(
                r"\s*(?:\x1b\[[0-9;]*m)?" + escaped + r"(?:\x1b\[0m)?\s*", "", first
            ).rstrip()
        body_parts = [ln.strip() for ln in lines[1:] if ln.strip()]
        if body_parts:
            first = first + " " + " ".join(body_parts)
        return first
