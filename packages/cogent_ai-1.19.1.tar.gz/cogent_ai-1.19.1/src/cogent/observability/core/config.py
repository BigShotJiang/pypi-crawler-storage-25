"""
Configuration for Observability v2.

Minimal, composable configuration that avoids the 25+ field explosion of v1.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import TYPE_CHECKING, Literal, TextIO

if TYPE_CHECKING:
    pass


class Level(IntEnum):
    """
    Observability levels.

    Each level includes all events from lower levels plus additional detail.

    Attributes:
        OFF: No output
        PROGRESS: Agent lifecycle, tool calls, and final responses
        DEBUG: PROGRESS plus LLM internals (requests, responses, token usage)
        TRACE: Reserved for future fine-grained instrumentation
    """

    OFF = 0
    PROGRESS = 1
    DEBUG = 2
    TRACE = 3

    @classmethod
    def from_string(cls, value: str) -> Level:
        """
        Parse level from string.

        Accepts: "off", "progress", "debug", "trace"
        """
        name = value.lower().strip()
        try:
            return cls[name.upper()]
        except KeyError:
            valid = [e.name.lower() for e in cls]
            raise ValueError(
                f"Invalid level '{value}'. Valid levels: {', '.join(valid)}"
            ) from None


# ---------------------------------------------------------------------------
# ANSI primitives (duplicated here to avoid importing from the formatter layer)
# ---------------------------------------------------------------------------
_RESET = "\033[0m"
_BOLD = "\033[1m"
_DIM = "\033[2m"
_ITALIC = "\033[3m"
_RED = "\033[31m"
_GREEN = "\033[32m"
_YELLOW = "\033[33m"
_BLUE = "\033[34m"
_MAGENTA = "\033[35m"
_CYAN = "\033[36m"


@dataclass
class Theme:
    """
    Color/style palette for console output.

    Each field is the raw ANSI prefix applied to the matching semantic role.
    Set a field to ``""`` to suppress color for that role.

    Use ``THEMES`` to select a built-in theme by name, or supply your own.

    Example::

        from cogent.observability import Observer
        from cogent.observability.core.config import Theme

        my_theme = Theme(agent="\033[34m", tool="\033[36m")  # blue agent, cyan tool
        observer = Observer(level="progress", theme=my_theme)
    """

    agent: str = _BOLD + _MAGENTA
    """Style for agent names."""

    tool: str = _YELLOW
    """Style for tool names."""

    success: str = _GREEN
    """Style for success labels and durations."""

    error: str = _RED
    """Style for error labels and messages."""

    warning: str = _YELLOW
    """Style for warning / retry labels."""

    info: str = _CYAN
    """Style for neutral info labels (tool-call, tool-decision, etc.)."""

    dim: str = _DIM
    """Style for de-emphasised text (IDs, secondary metadata)."""

    bold: str = _BOLD
    """Style for bold text."""

    italic: str = _ITALIC + _DIM
    """Style for italic/dim text (LLM reasoning, thinking previews)."""


# ---------------------------------------------------------------------------
# Built-in themes
# ---------------------------------------------------------------------------

THEMES: dict[str, Theme] = {
    "default": Theme(),
    # No hue — bold/dim structure only.  Safe for CI, pipes, and log files.
    "monochrome": Theme(
        agent=_BOLD,
        tool=_BOLD,
        success=_BOLD,
        error=_BOLD,
        warning=_BOLD,
        info="",
        dim=_DIM,
        bold=_BOLD,
        italic=_ITALIC + _DIM,
    ),
    # Cooler palette — blue agent, cyan tool, less aggressive than default.
    "subtle": Theme(
        agent=_BOLD + _BLUE,
        tool=_CYAN,
        success=_GREEN,
        error=_RED,
        warning=_YELLOW,
        info=_BLUE,
        dim=_DIM,
        bold=_BOLD,
        italic=_ITALIC + _DIM,
    ),
    # Everything muted — good for background or secondary agents.
    "minimal": Theme(
        agent=_DIM + _CYAN,
        tool=_DIM,
        success=_DIM + _GREEN,
        error=_RED,
        warning=_DIM + _YELLOW,
        info=_DIM,
        dim=_DIM,
        bold=_DIM,
        italic=_DIM,
    ),
}

ThemeName = Literal["default", "monochrome", "subtle", "minimal"]


def resolve_theme(theme: str | Theme) -> Theme:
    """Resolve a theme name string to a ``Theme`` instance."""
    if isinstance(theme, Theme):
        return theme
    name = theme.lower().strip()
    if name not in THEMES:
        valid = ", ".join(THEMES.keys())
        raise ValueError(f"Unknown theme '{theme}'. Valid themes: {valid}")
    return THEMES[name]


@dataclass
class FormatConfig:
    """
    Configuration for event formatting.

    Controls how events are rendered to strings.
    """

    use_colors: bool = True
    """Use ANSI color codes in output."""

    show_timestamps: bool = False
    """Show timestamps in output."""

    show_duration: bool = True
    """Show operation duration."""

    show_trace_ids: bool = False
    """Show correlation IDs."""

    truncate: int = 0
    """Max chars for content (0 = no limit)."""

    indent: str = "  "
    """Indentation string."""

    theme: Theme = field(default_factory=Theme)
    """Color/style palette.  Use ``THEMES`` or supply a custom ``Theme``."""


@dataclass
class ObserverConfig:
    """
    Configuration for the Observer.

    Minimal config that composes other configs rather than
    having 25+ fields like v1.
    """

    level: Level = Level.PROGRESS
    """Minimum level for events to be processed."""

    format: FormatConfig = field(default_factory=FormatConfig)
    """Formatting configuration."""

    stream: TextIO | None = None
    """Output stream (None = stderr)."""

    # Filters - glob patterns for event types
    include: list[str] | None = None
    """Only include events matching these patterns (None = all)."""

    exclude: list[str] | None = None
    """Exclude events matching these patterns."""

    @classmethod
    def from_level(cls, level: Level | str) -> ObserverConfig:
        """
        Create config from a level with sensible defaults.

        Args:
            level: Level enum or string name

        Returns:
            Config with appropriate settings for the level
        """
        if isinstance(level, str):
            level = Level.from_string(level)

        # Level-specific defaults
        format_config = FormatConfig()

        if level >= Level.DEBUG:
            format_config.show_timestamps = True
            format_config.show_trace_ids = True
            format_config.truncate = 0  # No truncation at debug+

        return cls(level=level, format=format_config)


PRESETS: dict[str, ObserverConfig] = {
    "off": ObserverConfig(level=Level.OFF),
    "progress": ObserverConfig(level=Level.PROGRESS),
    "debug": ObserverConfig(
        level=Level.DEBUG,
        format=FormatConfig(
            show_timestamps=True,
            show_duration=True,
            show_trace_ids=True,
            truncate=0,
        ),
    ),
    "trace": ObserverConfig(
        level=Level.TRACE,
        format=FormatConfig(
            show_timestamps=True,
            show_duration=True,
            show_trace_ids=True,
            truncate=0,
        ),
    ),
}


def get_preset(name: str) -> ObserverConfig:
    """
    Get a preset configuration by name.

    Args:
        name: Preset name (off, progress, debug, trace)

    Returns:
        ObserverConfig for the preset

    Raises:
        ValueError: If preset name is not recognized
    """
    name = name.lower().strip()
    if name not in PRESETS:
        valid = ", ".join(PRESETS.keys())
        raise ValueError(f"Unknown preset '{name}'. Valid presets: {valid}")
    return PRESETS[name]
