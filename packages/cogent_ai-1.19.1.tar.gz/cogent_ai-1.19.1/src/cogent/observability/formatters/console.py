"""
Console Formatters - Rich console output for events.

Provides formatters for common event categories with colored,
human-readable output.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from cogent.observability.formatters.base import BaseFormatter

if TYPE_CHECKING:
    from cogent.observability.core.config import FormatConfig, Theme
    from cogent.observability.core.event import Event


# ANSI color codes
class Colors:
    """ANSI escape codes for terminal colors."""

    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    ITALIC = "\033[3m"

    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"


class Styler:
    """Applies theme colors based on config."""

    def __init__(self, use_colors: bool = True, theme: Theme | None = None) -> None:
        self.use_colors = use_colors
        if theme is None:
            from cogent.observability.core.config import Theme as _Theme

            self._theme = _Theme()
        else:
            self._theme = theme

    def _wrap(self, text: str, style: str) -> str:
        if not self.use_colors or not style:
            return text
        return style + text + Colors.RESET

    def agent(self, text: str) -> str:
        return self._wrap(text, self._theme.agent)

    def tool(self, text: str) -> str:
        return self._wrap(text, self._theme.tool)

    def success(self, text: str) -> str:
        return self._wrap(text, self._theme.success)

    def error(self, text: str) -> str:
        return self._wrap(text, self._theme.error)

    def warning(self, text: str) -> str:
        return self._wrap(text, self._theme.warning)

    def info(self, text: str) -> str:
        return self._wrap(text, self._theme.info)

    def dim(self, text: str) -> str:
        return self._wrap(text, self._theme.dim)

    def bold(self, text: str) -> str:
        return self._wrap(text, self._theme.bold)

    def content(self, text: str) -> str:
        """Default terminal color for readable body content."""
        return text

    def italic(self, text: str) -> str:
        """Italic dim — for LLM reasoning and thinking text."""
        return self._wrap(text, self._theme.italic)


class AgentFormatter(BaseFormatter):
    """Formats agent.* events."""

    patterns = ["agent.*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = Styler(config.use_colors, config.theme)
        agent_name = event.get("agent_name", "Agent")
        formatted_name = self.format_name(agent_name)

        action = event.action

        if action == "invoked":
            task = event.get("task", "")
            run_id = event.correlation_id or ""
            run_id_str = f" {s.dim(run_id[:8])}" if run_id else ""
            if task:
                task = str(task).replace("\n", " ")
                if config.truncate:
                    task = self.truncate(task, config.truncate)
                return f"{s.agent(formatted_name)} {s.info(self._label('user', 'input'))}{run_id_str}\n  {s.content(task)}"
            return None

        elif action == "thinking":
            return None

        elif action == "reasoning":
            thought = event.get("thought_preview", "")
            if thought:
                if config.truncate:
                    thought = self.truncate(thought, config.truncate)
                return f"{s.agent(formatted_name)} {s.dim(self._label('agent', 'reasoning'))}\n  {s.italic(thought)}"
            return (
                f"{s.agent(formatted_name)} {s.dim(self._label('agent', 'reasoning'))}"
            )

        elif action == "acting":
            return f"{s.agent(formatted_name)} {s.dim(self._label('agent', 'acting'))}"

        elif action == "responded":
            duration_str = ""
            if config.show_duration and "duration_ms" in event.data:
                duration_str = f" ({self.format_duration(event.data['duration_ms'])})"

            # Token info
            tokens = event.get("tokens", {})
            token_str = ""
            if tokens and tokens.get("total"):
                total = tokens["total"]
                token_str = f" • {s.dim(f'{total} tokens')}"

            # Final response preview
            response_str = ""
            preview = event.get("response_preview") or event.get("response", "")
            if preview:
                preview = str(preview)
                # Unwrap StructuredResult — show only the .data repr
                if preview.startswith("StructuredResult("):
                    try:
                        from cogent.agent.output import StructuredResult

                        raw = event.get("response")
                        if isinstance(raw, StructuredResult):
                            preview = repr(raw.data)
                    except Exception:
                        pass
                preview = preview.replace("\n", " ")
                if config.truncate:
                    preview = self.truncate(preview, config.truncate)
                response_str = f"\n  {s.content(preview)}"

            duration_part = s.success(duration_str) if duration_str else ""
            return f"{s.agent(formatted_name)} {s.success(self._label('agent', 'completed'))}{duration_part}{token_str}{response_str}"

        elif action == "error":
            error = event.get("error", "Unknown error")
            return f"{s.agent(formatted_name)} {s.error(self._label('agent', 'error'))}\n  {s.error(str(error))}"

        # Default for unknown agent actions
        return f"{s.agent(formatted_name)} {s.dim(self._label('agent', action))}"


class ToolFormatter(BaseFormatter):
    """Formats tool.* and subagent.* events."""

    patterns = ["tool.*", "subagent.*"]

    def _name_prefix(self, event: Event, is_subagent: bool) -> str:  # noqa: ARG002
        """Return 'a2a://' or 'mcp://' prefix, or empty string."""
        if is_subagent and event.get("subagent_type") == "a2a":
            return "a2a://"
        if not is_subagent:
            src = str(event.get("tool_source", ""))
            if src.startswith("mcp"):
                return "mcp://"
        return ""

    def _name_address(self, event: Event, is_subagent: bool) -> str:
        """Return '@host:port' or '@servername' suffix, or empty string."""
        if is_subagent and event.get("subagent_type") == "a2a":
            url = event.get("subagent_url", "")
            if url:
                from urllib.parse import urlparse

                netloc = urlparse(str(url)).netloc
                return f"@{netloc}"
        if not is_subagent:
            src = str(event.get("tool_source", ""))
            if src.startswith("mcp:"):
                return f"@{src[4:]}"
        return ""

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = Styler(config.use_colors, config.theme)
        is_subagent_event = event.category == "subagent"
        name_key = "subagent_name" if is_subagent_event else "tool_name"
        fallback_key = "subagent" if is_subagent_event else "tool"
        tool_name = event.get(name_key, event.get(fallback_key, event.category))
        agent_name = event.get("agent_name", "")
        call_id = event.get("call_id", "")

        # Short ID for display (first 8 chars)
        short_id = call_id[:8] if call_id else ""

        agent_prefix = f"{s.agent(self.format_name(agent_name))} " if agent_name else ""
        action = event.action

        if action == "called":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            if is_subagent_event:
                task = event.get("task")
                body = ""
                if task:
                    task_preview = str(task).replace("\n", " ")
                    if config.truncate:
                        task_preview = self.truncate(task_preview, config.truncate)
                    body = f"\n  {s.tool(self._name_prefix(event, is_subagent_event) + tool_name + self._name_address(event, is_subagent_event))} {s.content(task_preview)}"
                else:
                    body = f"\n  {s.tool(self._name_prefix(event, is_subagent_event) + tool_name + self._name_address(event, is_subagent_event))}"
                label = self._label("subagent", "call")
                return f"{agent_prefix}{s.info(label)} {id_str}{body}"
            else:
                args = event.get("args", {})
                args_str = ""
                if args:
                    args_parts = [f"{k}={v!r}" for k, v in args.items()]
                    args_preview = "{" + ", ".join(args_parts) + "}"
                    if config.truncate:
                        args_preview = self.truncate(args_preview, config.truncate)
                    args_str = f" {s.content(args_preview)}"
                display_name = (
                    self._name_prefix(event, is_subagent_event)
                    + tool_name
                    + self._name_address(event, is_subagent_event)
                )
                label = self._label("tool", "call")
                return f"{agent_prefix}{s.info(label)} {id_str.rstrip()}\n  {s.tool(display_name)}{args_str}"

        elif action == "result":
            duration_str = ""
            if config.show_duration and "duration_ms" in event.data:
                duration_str = f" ({self.format_duration(event.data['duration_ms'])})"

            id_str = f"{s.dim(short_id)} " if short_id else ""
            result = event.get("result_preview", str(event.get("result", "")))
            result_str = ""
            if result:
                result = str(result).replace("\n", " ")
                if config.truncate:
                    result = self.truncate(result, config.truncate)
                # Try to format dict-like results nicely
                result_formatted = self._format_result(result)
                result_str = f"\n  {s.content(result_formatted)}"

            label = (
                self._label("subagent", "result")
                if is_subagent_event
                else self._label("tool", "result")
            )
            display_name = (
                self._name_prefix(event, is_subagent_event)
                + tool_name
                + self._name_address(event, is_subagent_event)
            )
            duration_part = s.success(duration_str) if duration_str else ""
            return f"{agent_prefix}{s.success(label)} {id_str}{s.tool(display_name)}{duration_part}{result_str}"

        elif action == "retry":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            error = event.get("error", "Unknown error")
            error_type = event.get("error_type")
            attempt = event.get("attempt")
            max_retries = event.get("max_retries")
            attempt_str = (
                f" {s.dim(f'(retry {attempt}/{max_retries})')}"
                if attempt and max_retries
                else ""
            )
            error_body = f"{error_type}: {error}" if error_type else str(error)
            display_name = (
                self._name_prefix(event, is_subagent_event)
                + tool_name
                + self._name_address(event, is_subagent_event)
            )
            return f"{agent_prefix}{s.error(self._label('tool', 'error'))}{attempt_str} {id_str}{s.tool(display_name)}\n  {s.error(error_body)}"

        elif action == "error":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            error = event.get("error", "Unknown error")
            error_type = event.get("error_type")
            error_body = f"{error_type}: {error}" if error_type else str(error)
            label = (
                self._label("subagent", "error")
                if is_subagent_event
                else self._label("tool", "error")
            )
            display_name = (
                self._name_prefix(event, is_subagent_event)
                + tool_name
                + self._name_address(event, is_subagent_event)
            )
            return f"{agent_prefix}{s.error(label)} {id_str}{s.tool(display_name)}\n  {s.error(error_body)}"

        elif action == "escalated":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            error = event.get("error", "Unknown error")
            error_type = event.get("error_type")
            error_body = f"{error_type}: {error}" if error_type else str(error)
            display_name = (
                self._name_prefix(event, is_subagent_event)
                + tool_name
                + self._name_address(event, is_subagent_event)
            )
            label = self._label("tool", "escalated")
            badge = s.dim("(→ agent)")
            return (
                f"{agent_prefix}{s.warning(label)} {badge} {id_str}{s.tool(display_name)}\n"
                f"  {s.dim(error_body)}"
            )

        return f"{agent_prefix}{s.dim(self._label(event.category, action))} {s.tool(tool_name)}"

    def _format_result(self, result: str) -> str:
        """Format result value, handling dict-like strings."""
        import ast

        # Try to parse as Python literal (dict, list, etc.)
        try:
            parsed = ast.literal_eval(result)
            if isinstance(parsed, dict):
                # Format as {key='value', ...}
                parts = [f"{k}={v!r}" for k, v in parsed.items()]
                return "{" + ", ".join(parts) + "}"
            elif isinstance(parsed, (list, tuple)):
                return repr(parsed)
            else:
                return repr(parsed)
        except (ValueError, SyntaxError):
            # Not a Python literal, return as quoted string
            return repr(result)


class TaskFormatter(BaseFormatter):
    """Formats task.* events."""

    patterns = ["task.*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = Styler(config.use_colors, config.theme)
        action = event.action

        if action == "started":
            task = event.get("task_name", event.get("task", "task"))
            task = str(task)
            if config.truncate:
                task = self.truncate(task, config.truncate)
            return f"{s.success(self._label('task', 'started'))} {task}"

        elif action == "completed":
            duration_str = ""
            if config.show_duration and "duration_ms" in event.data:
                duration_str = f" ({self.format_duration(event.data['duration_ms'])})"
            duration_part = s.success(duration_str) if duration_str else ""
            return f"{s.success(self._label('task', 'completed'))}{duration_part}"

        elif action == "failed":
            error = event.get("error", "Unknown error")
            error = str(error)
            if config.truncate:
                error = self.truncate(error, config.truncate)
            return f"{s.error(self._label('task', 'failed'))}\n  {s.error(error)}"

        return f"{s.dim(self._label('task', action))}"


class LLMFormatter(BaseFormatter):
    """Formats llm.* events with thinking/reasoning display."""

    patterns = ["llm.*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = Styler(config.use_colors, config.theme)
        agent_name = event.get("agent_name", "LLM")
        formatted_name = self.format_name(agent_name)
        action = event.action

        if action == "request":
            model = event.get("model", "")
            msg_count = event.get("message_count", 0)
            tools = event.get("tools_available", [])
            tools_str = f" • {len(tools)} tools" if tools else ""
            return f"{s.agent(formatted_name)} {s.dim(self._label('request'))} {s.dim(model)} ({msg_count} msgs){s.dim(tools_str)}"

        elif action == "response":
            duration_str = ""
            if config.show_duration and "duration_ms" in event.data:
                duration_str = f" ({self.format_duration(event.data['duration_ms'])})"

            # Token info with reasoning breakdown
            tokens = event.get("tokens", {})
            token_str = self._format_tokens(tokens, s)

            # Thinking summary
            thinking_preview = event.get("thinking_preview", "")
            thinking_str = ""
            if thinking_preview:
                preview = thinking_preview
                if config.truncate:
                    preview = self.truncate(preview, config.truncate)
                thinking_str = f"\n  {s.dim('[thinking]')} {s.italic(preview)}"

            # Tool calls
            has_tools = event.get("has_tool_calls", False)
            finish_str = f" → {s.tool('tool_calls')}" if has_tools else ""

            duration_part = s.success(duration_str) if duration_str else ""
            return f"{s.agent(formatted_name)} {s.success(self._label('response'))}{duration_part}{token_str}{finish_str}{thinking_str}"

        elif action == "thinking":
            # Dedicated thinking event
            thinking_content = event.get("thinking", event.get("content", ""))
            thinking_tokens = event.get("thinking_tokens", 0)

            tokens_str = f" ({thinking_tokens} tokens)" if thinking_tokens else ""

            if thinking_content:
                preview = thinking_content
                if config.truncate:
                    preview = self.truncate(preview, config.truncate)
                return f"{s.agent(formatted_name)} {s.info(self._label('thinking'))}{s.dim(tokens_str)}\n  {s.italic(preview)}"
            elif thinking_tokens:
                # OpenAI o-series: has reasoning tokens but no exposed content
                return f"{s.agent(formatted_name)} {s.info(self._label('reasoning'))}{s.dim(tokens_str)} {s.dim('(content not exposed)')}"
            return f"{s.agent(formatted_name)} {s.info(self._label('thinking'))}"

        elif action == "tool_decision":
            tools = event.get("tools_selected", [])
            subagents = event.get("subagents_selected", [])
            regular_tools = event.get("regular_tools_selected", [])
            reasoning = event.get("reasoning", "")

            # Determine label and collect all tool names for body
            has_subagents = bool(subagents)
            has_tools = bool(regular_tools)
            if has_subagents and has_tools:
                label = self._label("tool-decision")
            elif has_subagents:
                label = self._label("subagent-decision")
            else:
                label = self._label("tool-decision")

            all_names: list[str] = list(subagents) + list(regular_tools) or tools
            if len(all_names) > 5:
                all_names = all_names[:5] + [f"... (+{len(all_names) - 5})"]
            tools_body = f"\n  {s.content(', '.join(all_names))}" if all_names else ""

            reason_str = ""
            if reasoning:
                reason_text = reasoning.strip()
                if config.truncate:
                    reason_text = self.truncate(reason_text, config.truncate)
                reason_str = f"\n  {s.italic(reason_text)}"

            return f"{s.agent(formatted_name)} {s.info(label)}{tools_body}{reason_str}"

        return f"{s.agent(formatted_name)} {s.dim(self._label(action))}"

    def _format_tokens(self, tokens: dict, s: Styler) -> str:
        """Format token usage with reasoning breakdown."""
        if not tokens:
            return ""

        parts = []

        # Total tokens
        total = tokens.get("total", tokens.get("total_tokens", 0))
        if total:
            parts.append(f"{total} tokens")

        # Prompt/completion breakdown
        prompt = tokens.get("prompt", tokens.get("prompt_tokens", 0))
        completion = tokens.get("completion", tokens.get("completion_tokens", 0))
        if prompt or completion:
            parts.append(f"in={prompt}/out={completion}")

        # Reasoning/thinking tokens
        reasoning = tokens.get("reasoning", tokens.get("reasoning_tokens", 0))
        if reasoning:
            parts.append(f"reasoning={reasoning}")

        if parts:
            return f" • {s.dim(' '.join(parts))}"
        return ""


class StreamFormatter(BaseFormatter):
    """Formats stream.* events."""

    patterns = ["stream.*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = Styler(config.use_colors, config.theme)
        agent_name = event.get("agent_name", "Agent")
        formatted_name = self.format_name(agent_name)
        action = event.action

        if action == "start":
            model = event.get("model", "")
            model_str = f" {s.dim(f'({model})')}" if model else ""
            return f"{s.agent(formatted_name)} {s.info(self._label('stream', 'start'))}{model_str}"

        elif action == "token":
            return None

        elif action == "end":
            duration_str = ""
            if config.show_duration and "duration_ms" in event.data:
                ms = event.data["duration_ms"]
                token_count = event.get("token_count", 0)
                if token_count > 0 and ms > 0:
                    tok_per_sec = token_count / (ms / 1000)
                    duration_str = f" ({ms / 1000:.1f}s, {tok_per_sec:.0f} tok/s)"
                else:
                    duration_str = f" ({self.format_duration(ms)})"
            duration_part = s.success(duration_str) if duration_str else ""
            return f"{s.agent(formatted_name)} {s.success(self._label('stream', 'end'))}{duration_part}"

        elif action == "error":
            error = event.get("error", "Stream error")
            return f"{s.agent(formatted_name)} {s.error(self._label('stream', 'error'))}\n  {s.error(str(error))}"

        return None


class OutputFormatter(BaseFormatter):
    """Formats output.* events.

    `output.generated` is primarily useful for capture, export, and downstream
    subscriptions. The console already shows the final completion line via
    `agent.responded`, so we suppress this event in human-readable terminal
    output to avoid duplicate noise.
    """

    patterns = ["output.generated"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        _ = event
        _ = config
        return None


class DefaultFormatter(BaseFormatter):
    """Fallback formatter for unhandled events."""

    patterns = ["*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = Styler(config.use_colors)
        data_preview = str(event.data)[:80] if event.data else ""
        return f"{s.dim(event.type)} {s.dim(data_preview)}"
