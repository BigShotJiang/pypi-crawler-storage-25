# Changelog

## 5.0.0 (2026-04-18)

Managed-first SDK release for browser and native runtimes.

### Breaking Changes

- Repositioned browser and native realtime around the managed backend websocket transport for Standard / Pro / Pro+ models
- Deprecated the legacy local Moonshine-lite realtime path from the primary recommended flow; it remains available only as a fallback path for now
- Updated release line to `5.x` in lockstep across Python, Node.js, Browser, and native packages

### Changes

- Added backend-signed realtime websocket ticket flow for browser-safe managed sessions
- Added browser managed realtime transport with partial / refined / final_result handling and VAD-gated upload
- Added Chrome extension and widget foundations on top of the shared Web SDK runtime
- Added extension smoke coverage for popup bootstrap, validation, and content-script insertion

## 4.0.0 (2026-04-06)

Native runtime quality release that changes batch and realtime transcript behavior at the same public API surface.

### Breaking Changes

- Changed native batch decode behavior to use bounded decode-only context padding around VAD spans
- Changed native realtime decode behavior to use the same bounded decode-only context padding with retained pre-context in the audio window
- As a result, transcript text and segment text may differ from `3.0.0` for the same input audio even when API calls are unchanged
- `3.0.0` should be treated as deprecated for production use because of the known boundary-sensitivity issue in native decoding

### Changes

- Reduced boundary-induced truncation in batch transcription by expanding decode windows without changing public segment timestamps
- Applied the same strategy to realtime decoding so batch and realtime share the same boundary mitigation approach
- Added `genshi auth login --browser` with WorkOS PKCE + localhost callback and backend `/api/cli/auth/authorize` / `/exchange`
- Added CLI-side tests for PKCE / callback parsing and backend tests for browser auth key issuance
- Added unit coverage for bounded overlap decode windows in both batch and realtime paths
- Documented the investigation and mitigation in `docs/architecture/native-stt-boundary-sensitivity.md`

## 3.0.0 (2026-04-03)

Batch and realtime public SDK response shape now follows a Whisper-like `segments` model.

### Breaking Changes

- Removed public `raw_text` from Python, Node.js, and Browser SDK results and realtime events
- Changed public `segments` from `string[]` to timestamped segment objects `{ id, start, end, text }`
- Made `segments` the single public source of truth; `text` remains the joined convenience field
- Aligned Browser batch with native batch by running local VAD segmentation before correction

## 2.0.0 (2026-04-02)

Realtime SDK v2 release.

### Changes

- Changed realtime `push()` to local VAD + local STT only; it no longer waits for correction HTTP
- Added background batched refinement with `effort: "normal" | "high"`
- Added polling-based `drain_events()` / `drainEvents()` APIs for `refined` and `error` events
- Replaced realtime event shape from `sentence` to `partial | refined | error`
- Added batched `segments[]` correction support to `POST /v1/transcribe`
- Bumped Python, Node, Browser, and native package versions in lockstep for the breaking realtime API

## 1.0.2 (2026-03-17)

Compatibility release for the production API domain split.

### Changes

- Switched SDK default API origin to `https://api.genshi.ai`
- Prepared Cloudflare compatibility routing so legacy `https://works.genshi.ai/v1/*` traffic can be forwarded during migration
- Intended production runtime configuration now keeps one Fly machine warm to reduce first-request latency

## 1.0.1 (2026-03-12)

Metadata-only maintenance release.

### Changes

- Clarified public package metadata for closed-source distribution
- Removed misleading public `repository` links from npm package metadata
- Added public `Releases` and `Changelog` links to PyPI package metadata
- Added landing-page README and changelog to the public release repository

## 1.0.0 (2026-03-06)

Initial production release.

### Features
- Batch transcription via `client.transcribe(audio)` (Python / Node.js / Browser)
- Realtime streaming via `client.stream()` / `client.realtime()` with push-based audio input
- Built-in Silero VAD for voice activity detection
- Encrypted on-device STT model (fp16 ONNX) with Rust native runtime
- Platform-specific native extensions: macOS ARM64, Linux x64, Windows x64
- Browser SDK (`@genshiai/stt-web`) with ONNX Runtime Web + Transformers.js
- Domain-specific transcription support (medical, general)

### Packages
- `genshiai-stt` (PyPI) — Python SDK
- `genshiai-stt-native` (PyPI) — Python native extension (platform wheels)
- `@genshiai/stt` (npm) — Node.js SDK
- `@genshiai/stt-native-{platform}` (npm) — Node.js native addons
- `@genshiai/stt-web` (npm) — Browser SDK
