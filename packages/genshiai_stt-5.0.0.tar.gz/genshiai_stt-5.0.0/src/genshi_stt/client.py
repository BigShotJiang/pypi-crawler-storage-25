"""Rust-first GENSHI STT client wrappers."""

from __future__ import annotations

from pathlib import Path
from typing import Union
import asyncio
import json

import numpy as np

from genshi_stt.audio import decode_audio_input_to_pcm16, get_pcm16_duration_seconds
from genshi_stt.engine import DEFAULT_LOCAL_MODEL_DTYPE
from genshi_stt.transcriber import RealtimeSession, TranscriptionResult, TranscriptionSegment


_NATIVE_CLIENT_CLS = None
_DEFAULT_LANGUAGE = "ja-JP"
_DEFAULT_DOMAIN = "general"
_MODEL_ALIASES = {
    "lite": "genshi-stt-v1-lite",
    "genshi-stt-v1-lite": "genshi-stt-v1-lite",
    "standard": "genshi-stt-v1-standard",
    "genshi-stt-v1-standard": "genshi-stt-v1-standard",
    "pro": "genshi-stt-v1-pro",
    "genshi-stt-v1-pro": "genshi-stt-v1-pro",
    "pro+": "genshi-stt-v1-pro-plus",
    "pro-plus": "genshi-stt-v1-pro-plus",
    "pro_plus": "genshi-stt-v1-pro-plus",
    "genshi-stt-v1-pro-plus": "genshi-stt-v1-pro-plus",
}

try:
    from genshi_stt_native import RustGenshiSttClient as _RUST_NATIVE_CLIENT  # type: ignore

    _NATIVE_CLIENT_CLS = _RUST_NATIVE_CLIENT
except Exception:
    _NATIVE_CLIENT_CLS = None


class GenshiSTTClient:
    """High-accuracy transcription client powered by Rust native SDK core."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.genshi.ai",
        *,
        timeout: float = 120.0,
        secure: bool = False,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.secure = secure
        if _NATIVE_CLIENT_CLS is None:
            raise RuntimeError(
                "genshi_stt_native is required. "
                "Install a wheel that includes the Rust native module."
            )
        self._native = _NATIVE_CLIENT_CLS(api_key, self.base_url, timeout, secure)

    async def transcribe(
        self,
        input_data: Union[str, bytes, np.ndarray, Path],
        *,
        model: str,
        domain: str = _DEFAULT_DOMAIN,
        language: str = _DEFAULT_LANGUAGE,
        dictionary_ids: list[str] | None = None,
        dictionaries: str | None = None,
        audio_duration_seconds: float | None = None,
        local_model_dir: str | None = None,
        local_model_dtype: str = DEFAULT_LOCAL_MODEL_DTYPE,
    ) -> TranscriptionResult:
        """Transcribe audio and return the final text."""
        del local_model_dir
        if local_model_dtype != DEFAULT_LOCAL_MODEL_DTYPE:
            raise ValueError(f"only dtype={DEFAULT_LOCAL_MODEL_DTYPE!r} is supported")

        pcm16 = decode_audio_input_to_pcm16(input_data)
        normalized_model = _normalize_model(model)
        normalized_dictionary_ids = _normalize_dictionary_ids(dictionary_ids)
        normalized_dictionaries = _normalize_dictionary_selection(dictionaries)
        _assert_supported_processing_profile(
            model=normalized_model,
            domain=domain,
            dictionary_ids=normalized_dictionary_ids,
            dictionaries=normalized_dictionaries,
        )
        payload = await _run_blocking(
            self._native.transcribe_audio_sync,
            pcm16,
            normalized_model,
            domain,
            language,
            audio_duration_seconds or get_pcm16_duration_seconds(pcm16),
            normalized_dictionary_ids,
            normalized_dictionaries,
        )
        return _result_from_payload(json.loads(payload))

    def realtime(
        self,
        *,
        model: str,
        domain: str = _DEFAULT_DOMAIN,
        language: str = _DEFAULT_LANGUAGE,
        dictionary_ids: list[str] | None = None,
        dictionaries: str | None = None,
        context_window_size: int = 5,
        effort: str = "normal",
        local_model_dir: str | None = None,
        local_model_dtype: str = DEFAULT_LOCAL_MODEL_DTYPE,
    ) -> RealtimeSession:
        """Create a realtime transcription session."""
        del local_model_dir
        if local_model_dtype != DEFAULT_LOCAL_MODEL_DTYPE:
            raise ValueError(f"only dtype={DEFAULT_LOCAL_MODEL_DTYPE!r} is supported")

        normalized_model = _normalize_model(model)
        normalized_dictionary_ids = _normalize_dictionary_ids(dictionary_ids)
        normalized_dictionaries = _normalize_dictionary_selection(dictionaries)
        _assert_supported_processing_profile(
            model=normalized_model,
            domain=domain,
            dictionary_ids=normalized_dictionary_ids,
            dictionaries=normalized_dictionaries,
        )

        native_session = self._native.realtime(
            normalized_model,
            domain,
            language,
            max(1, context_window_size),
            normalized_dictionary_ids,
            normalized_dictionaries,
            effort,
        )
        return RealtimeSession(native_session=native_session)

    def stream(
        self,
        *,
        model: str,
        domain: str = _DEFAULT_DOMAIN,
        language: str = _DEFAULT_LANGUAGE,
        dictionary_ids: list[str] | None = None,
        dictionaries: str | None = None,
        context_window_size: int = 5,
        effort: str = "normal",
        local_model_dir: str | None = None,
        local_model_dtype: str = DEFAULT_LOCAL_MODEL_DTYPE,
    ) -> RealtimeSession:
        return self.realtime(
            model=model,
            domain=domain,
            language=language,
            dictionary_ids=dictionary_ids,
            dictionaries=dictionaries,
            context_window_size=context_window_size,
            effort=effort,
            local_model_dir=local_model_dir,
            local_model_dtype=local_model_dtype,
        )

    async def close(self) -> None:
        await _run_blocking(self._native.close)

    async def __aenter__(self) -> "GenshiSTTClient":
        return self

    async def __aexit__(self, *args) -> None:
        await self.close()


async def _run_blocking(func, *args):
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, lambda: func(*args))


def _result_from_payload(payload: dict) -> TranscriptionResult:
    text = str(payload.get("text", "")).strip()
    segments = _segments_from_payload(payload.get("segments"))
    return TranscriptionResult(
        text=text or "".join(segment.text for segment in segments),
        processing_time_ms=int(payload.get("processing_time_ms", 0) or 0),
        segments=segments,
    )


def _segments_from_payload(raw_segments: object) -> list[TranscriptionSegment]:
    if not isinstance(raw_segments, list):
        return []

    segments: list[TranscriptionSegment] = []
    for index, raw_segment in enumerate(raw_segments):
        payload = raw_segment if isinstance(raw_segment, dict) else {}
        segments.append(
            TranscriptionSegment(
                id=int(payload.get("id", index) or index),
                start=float(payload.get("start", 0) or 0),
                end=float(payload.get("end", 0) or 0),
                text=str(payload.get("text", "")).strip(),
            )
        )
    return segments


def _normalize_model(model: str) -> str:
    normalized = str(model or "").strip().lower()
    if not normalized:
        raise ValueError("model is required")
    resolved = _MODEL_ALIASES.get(normalized)
    if resolved is None:
        raise ValueError(
            "model must be one of: genshi-stt-v1-lite, genshi-stt-v1-standard, genshi-stt-v1-pro, genshi-stt-v1-pro-plus"
        )
    return resolved


def _normalize_dictionary_ids(dictionary_ids: list[str] | None) -> list[str] | None:
    if not dictionary_ids:
        return None
    normalized = []
    for raw_value in dictionary_ids:
        value = str(raw_value).strip()
        if value and value not in normalized:
            normalized.append(value)
    return normalized or None


def _normalize_dictionary_selection(dictionaries: str | None) -> str | None:
    if dictionaries is None:
        return None
    normalized = str(dictionaries).strip().lower()
    if not normalized:
        return None
    if normalized != "bound":
        raise ValueError('dictionaries must be "bound" when provided')
    return "bound"


def _assert_supported_processing_profile(
    *,
    model: str,
    domain: str,
    dictionary_ids: list[str] | None,
    dictionaries: str | None,
) -> None:
    normalized_domain = str(domain).strip().lower()
    has_domain = bool(normalized_domain and normalized_domain != _DEFAULT_DOMAIN)
    uses_bound_dictionaries = dictionaries == "bound"
    has_dictionary_selection = bool(dictionary_ids) or uses_bound_dictionaries

    if dictionary_ids and uses_bound_dictionaries:
        raise ValueError('dictionary_ids and dictionaries="bound" are mutually exclusive')

    if model in {"genshi-stt-v1-lite", "genshi-stt-v1-standard"}:
        if has_domain:
            raise ValueError(f"{model} does not support domain selection")
        if has_dictionary_selection:
            raise ValueError(f"{model} does not support dictionaries")
        return

    if model == "genshi-stt-v1-pro":
        if not has_domain:
            raise ValueError("genshi-stt-v1-pro requires a non-general domain")
        if has_dictionary_selection:
            raise ValueError("genshi-stt-v1-pro does not support dictionaries")
        return

    if model == "genshi-stt-v1-pro-plus" and not has_dictionary_selection:
        raise ValueError('genshi-stt-v1-pro-plus requires dictionary_ids or dictionaries="bound"')
