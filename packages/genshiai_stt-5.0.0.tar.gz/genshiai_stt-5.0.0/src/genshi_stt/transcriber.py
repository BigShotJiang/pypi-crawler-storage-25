"""Realtime transcription primitives backed by the Rust native runtime."""

from __future__ import annotations

from dataclasses import dataclass, field
import asyncio
import json
import warnings


@dataclass
class TranscriptionEvent:
    """Event emitted during realtime transcription."""

    text: str
    index: int | None = None
    processing_time_ms: int = 0
    type: str = "partial"
    error: str | None = None


@dataclass
class TranscriptionSegment:
    """Timestamped segment of a transcription result."""

    id: int
    start: float
    end: float
    text: str


@dataclass
class TranscriptionResult:
    """Result of a transcription operation."""

    text: str
    processing_time_ms: int = 0
    segments: list[TranscriptionSegment] = field(default_factory=list)


class RealtimeSession:
    """Thin async wrapper around the Rust realtime session."""

    def __init__(self, *, native_session) -> None:
        self._native = native_session
        self._closed = False
        self._has_activity = False

    async def __aenter__(self) -> "RealtimeSession":
        return self

    async def __aexit__(self, *args) -> None:
        if not self._closed:
            await self.finalize()

    async def push(
        self,
        pcm16_chunk: bytes,
        *,
        audio_duration_seconds: float | None = None,
    ) -> list[TranscriptionEvent]:
        return await self.push_audio(
            pcm16_chunk,
            audio_duration_seconds=audio_duration_seconds,
        )

    async def push_audio(
        self,
        pcm16_chunk: bytes,
        *,
        audio_duration_seconds: float | None = None,
    ) -> list[TranscriptionEvent]:
        payload = await _run_blocking(
            self._native.push_audio_sync,
            pcm16_chunk,
            audio_duration_seconds,
        )
        self._has_activity = True
        events = _parse_json_payload(payload)
        return [_event_from_payload(item) for item in events]

    async def finalize(
        self,
        *,
        audio_duration_seconds: float | None = None,
    ) -> TranscriptionResult:
        payload = await _run_blocking(
            self._native.finalize_sync,
            audio_duration_seconds,
        )
        self._closed = True
        return _result_from_payload(_parse_json_payload(payload))

    async def drain_events(self) -> list[TranscriptionEvent]:
        payload = await _run_blocking(self._native.drain_events_sync)
        events = _parse_json_payload(payload)
        return [_event_from_payload(item) for item in events]

    async def end(
        self,
        *,
        audio_duration_seconds: float | None = None,
    ) -> TranscriptionResult:
        return await self.finalize(audio_duration_seconds=audio_duration_seconds)

    async def close(self) -> None:
        if self._closed:
            return
        if not self._has_activity:
            await _run_blocking(self._native.close)
            self._closed = True
            return

        try:
            await self.finalize()
        except Exception:
            warnings.warn(
                "RealtimeSession.close() failed to finalize automatically; call await session.finalize() to handle finalize errors, or session.abort() to force-abort.",
                stacklevel=2,
            )
            await _run_blocking(self._native.close)
            self._closed = True
            return

    async def abort(self) -> None:
        if self._closed:
            return
        if self._has_activity:
            warnings.warn(
                "RealtimeSession.abort() skips finalize() and should be used only for intentional aborts.",
                stacklevel=2,
            )
        native_abort = getattr(self._native, "abort", None)
        await _run_blocking(native_abort if callable(native_abort) else self._native.close)
        self._closed = True

    @property
    def text(self) -> str:
        return str(self._native.text())

    @property
    def sentences(self) -> list[str]:
        values = self._native.sentences()
        return [str(item) for item in values]


StreamSession = RealtimeSession


async def _run_blocking(func, *args):
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, lambda: func(*args))


def _parse_json_payload(payload: str):
    return json.loads(payload)


def _result_from_payload(payload: dict) -> TranscriptionResult:
    text = str(payload.get("text", "")).strip()
    segments = _segments_from_payload(payload.get("segments"))
    return TranscriptionResult(
        text=text or "".join(segment.text for segment in segments),
        processing_time_ms=int(payload.get("processing_time_ms", 0) or 0),
        segments=segments,
    )


def _event_from_payload(payload: dict) -> TranscriptionEvent:
    text = str(payload.get("text", "")).strip()
    index = payload.get("index")
    return TranscriptionEvent(
        text=text,
        index=int(index) if index is not None else None,
        processing_time_ms=int(payload.get("processing_time_ms", 0) or 0),
        type=str(payload.get("type", "partial")),
        error=str(payload.get("error")) if payload.get("error") is not None else None,
    )


def _segments_from_payload(raw_segments: object) -> list[TranscriptionSegment]:
    if not isinstance(raw_segments, list):
        return []

    segments: list[TranscriptionSegment] = []
    for index, raw_segment in enumerate(raw_segments):
        payload = raw_segment if isinstance(raw_segment, dict) else {}
        segments.append(
            TranscriptionSegment(
                id=int(payload.get("id", index) or index),
                start=float(payload.get("start", 0) or 0),
                end=float(payload.get("end", 0) or 0),
                text=str(payload.get("text", "")).strip(),
            )
        )
    return segments
