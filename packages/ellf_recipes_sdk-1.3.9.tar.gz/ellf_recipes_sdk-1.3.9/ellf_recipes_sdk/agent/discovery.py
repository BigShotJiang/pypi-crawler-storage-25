"""Server discovery: find Prodigy servers for tasks assigned to this agent.

The agent doesn't receive task URLs directly. Instead it queries PAM
for its related tasks and resolves each task's Prodigy server URL.

Task URLs follow the path-based convention:
  ``https://{broker_address}/tasks/{task_id}``
"""

from __future__ import annotations

import logging
from typing import cast
from urllib.parse import quote
from uuid import UUID

import httpx

from ellf_pam_sdk.client.full_client import Client
from ellf_pam_sdk.models import AgentDetail
from ellf_pam_sdk.recipe_client import Settings
from ellf_pam_sdk.url import URL

from .client import ServerAuth

TASKS_PATH_SEGMENT = "tasks"

logger = logging.getLogger(__name__)


async def discover_servers() -> list[ServerAuth]:
    """Query PAM for tasks assigned to this agent and return their server URLs."""
    settings = Settings()
    if not settings.is_valid():
        missing = [
            name
            for name, value in {
                "ELLF_PAM_BOOTSTRAP_TOKEN": settings.pam_bootstrap_token,
                "ELLF_PAM_HOST": settings.pam_host,
                "ELLF_JOB_ID": settings.job_id,
                "ELLF_EXECUTION_ID": settings.execution_id,
                "ELLF_CLUSTER_ID": settings.cluster_id,
            }.items()
            if not value
        ]
        raise RuntimeError(
            f"Missing ELLF_* environment variables: {', '.join(missing)} "
            "— is this running on the cluster?"
        )
    pam = await Client.from_job_token(settings.pam_host, settings.job_token)
    agent = cast(AgentDetail, await pam.agent.read_async(id=settings.job_id))
    task_ids: list[UUID] = agent.related_tasks
    if not task_ids:
        logger.info("Agent has no related tasks.")
        return []
    cluster = await pam.cluster.read_async(id=settings.cluster_id)
    if settings.has_cluster_auth():
        broker_token = await _exchange_cluster_bootstrap_token(
            broker_host=settings.broker_host,
            cluster_bootstrap_token=settings.cluster_bootstrap_token,
        )
    else:
        broker_token = await _get_cluster_token(
            pam_host=settings.pam_host,
            broker_address=cluster.address,
            pam_access_token=pam.access_token,
        )
    urls: list[ServerAuth] = []
    for task_id in task_ids:
        url = _task_url(cluster.address, task_id)
        try:
            login_url = await _task_login_url(
                broker_address=cluster.address,
                broker_token=broker_token,
                task_id=task_id,
            )
        except httpx.ReadTimeout:
            logger.warning(
                "Skipping task %s for agent discovery: cluster prodigy-login timed out",
                task_id,
            )
            continue
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code in {404, 503}:
                logger.warning(
                    "Skipping task %s for agent discovery: cluster prodigy-login returned %s",
                    task_id,
                    exc.response.status_code,
                )
                continue
            raise
        urls.append(ServerAuth(base_url=url, login_url=login_url))
    return urls


def _task_url(broker_address: str, task_id: UUID) -> str:
    """Build the task URL using the path-based convention."""
    return f"{URL.parse(broker_address)}/{TASKS_PATH_SEGMENT}/{task_id}"


async def _get_cluster_token(
    *,
    pam_host: str,
    broker_address: str,
    pam_access_token: str,
) -> str:
    async with httpx.AsyncClient(timeout=30.0) as http:
        response = await http.post(
            f"{URL.parse(pam_host)}/api/v1/cluster/token",
            headers={"Authorization": f"Bearer {pam_access_token}"},
            json={"address": URL.parse(broker_address)},
        )
        response.raise_for_status()
        pam_cluster_token = response.json()["access_token"]
        exchange = await http.post(
            f"{URL.parse(broker_address)}/api/v1/token/exchange",
            json={"token": pam_cluster_token},
        )
        exchange.raise_for_status()
        return exchange.json()["access_token"]


async def _exchange_cluster_bootstrap_token(
    *,
    broker_host: str,
    cluster_bootstrap_token: str,
) -> str:
    # broker_host may already include a scheme (e.g. the in-cluster
    # http://ellf-broker.ellf:8080).
    base = URL.parse(broker_host)
    async with httpx.AsyncClient(timeout=30.0) as http:
        exchange = await http.post(
            f"{base}/api/v1/token/exchange",
            json={"token": cluster_bootstrap_token},
        )
        exchange.raise_for_status()
        return exchange.json()["access_token"]


async def _task_login_url(
    *,
    broker_address: str,
    broker_token: str,
    task_id: UUID,
) -> str:
    async with httpx.AsyncClient(timeout=30.0) as http:
        response = await http.get(
            f"{URL.parse(broker_address)}/api/v1/jobs/prodigy-login",
            headers={"Authorization": f"Bearer {broker_token}"},
            params={"task_id": str(task_id), "wait_for_route": "false"},
        )
        response.raise_for_status()
        payload = response.json()
    task_url = str(payload["task_url"]).rstrip("/")
    login_token = quote(str(payload["login_token"]), safe="")
    return f"{task_url}/login?login_token={login_token}"
