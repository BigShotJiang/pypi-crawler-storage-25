from __future__ import annotations

import hashlib
import html
import json
import os
import platform
import shutil
import subprocess
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path
from typing import Any


SCHEMA_VERSION = "benchci.evidence.v1"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_file(path: str | Path | None) -> str | None:
    if path is None:
        return None
    p = Path(path).expanduser()
    if not p.exists() or not p.is_file():
        return None

    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _run_git(args: list[str], cwd: Path) -> str | None:
    try:
        p = subprocess.run(
            ["git", *args],
            cwd=str(cwd),
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=2.0,
            check=False,
        )
        if p.returncode != 0:
            return None
        value = (p.stdout or "").strip()
        return value or None
    except Exception:
        return None


def collect_git_metadata(cwd: str | Path | None = None) -> dict[str, Any]:
    root = Path(cwd or Path.cwd()).expanduser().resolve()
    commit = _run_git(["rev-parse", "HEAD"], root)
    branch = _run_git(["rev-parse", "--abbrev-ref", "HEAD"], root)
    remote = _run_git(["config", "--get", "remote.origin.url"], root)
    dirty = _run_git(["status", "--porcelain"], root)

    return {
        "git_commit": commit,
        "git_branch": branch,
        "git_remote": remote,
        "git_dirty": bool(dirty) if dirty is not None else None,
    }


def collect_ci_metadata() -> dict[str, Any]:
    env = os.environ

    provider: str | None = None
    job_url: str | None = None

    if env.get("GITHUB_ACTIONS"):
        provider = "github_actions"
        server = env.get("GITHUB_SERVER_URL", "https://github.com")
        repo = env.get("GITHUB_REPOSITORY")
        run_id = env.get("GITHUB_RUN_ID")
        if repo and run_id:
            job_url = f"{server}/{repo}/actions/runs/{run_id}"
    elif env.get("GITLAB_CI"):
        provider = "gitlab_ci"
        job_url = env.get("CI_JOB_URL") or env.get("CI_PIPELINE_URL")
    elif env.get("CIRCLECI"):
        provider = "circleci"
        job_url = env.get("CIRCLE_BUILD_URL")
    elif env.get("BUILDKITE"):
        provider = "buildkite"
        job_url = env.get("BUILDKITE_BUILD_URL")
    elif env.get("JENKINS_URL"):
        provider = "jenkins"
        job_url = env.get("BUILD_URL")
    elif env.get("TF_BUILD"):
        provider = "azure_pipelines"
        job_url = env.get("SYSTEM_TEAMFOUNDATIONCOLLECTIONURI")
    elif env.get("CI"):
        provider = "generic_ci"

    return {
        "ci_provider": provider,
        "ci_job_url": job_url,
        "ci_run_id": env.get("GITHUB_RUN_ID") or env.get("CI_PIPELINE_ID") or env.get("BUILD_ID") or env.get("BUILD_NUMBER"),
        "ci_job_id": env.get("GITHUB_JOB") or env.get("CI_JOB_ID") or env.get("CIRCLE_JOB") or env.get("BUILDKITE_JOB_ID"),
    }


def collect_environment_metadata() -> dict[str, Any]:
    try:
        benchci_version = metadata.version("benchci")
    except Exception:
        benchci_version = "unknown"

    return {
        "benchci_version": benchci_version,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "system": platform.system(),
        "machine": platform.machine(),
        "node": platform.node(),
        "cwd": str(Path.cwd()),
    }


def copy_input_snapshots(
    *,
    out_dir: str | Path,
    bench_path: str | Path,
    suite_path: str | Path,
) -> dict[str, str]:
    out = Path(out_dir).expanduser().resolve()
    inputs_dir = out / "inputs"
    inputs_dir.mkdir(parents=True, exist_ok=True)

    snapshots: dict[str, str] = {}
    for key, src, name in (
        ("bench_yaml", bench_path, "bench.yaml"),
        ("suite_yaml", suite_path, "suite.yaml"),
    ):
        try:
            src_path = Path(src).expanduser().resolve()
            dst = inputs_dir / name
            shutil.copy2(src_path, dst)
            snapshots[key] = str(dst.resolve())
        except Exception:
            # Evidence generation must not break a hardware run.
            continue

    return snapshots


def list_artifact_files(out_dir: str | Path) -> list[str]:
    root = Path(out_dir).expanduser().resolve()
    if not root.exists():
        return []
    files: list[str] = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            try:
                files.append(str(p.relative_to(root)))
            except Exception:
                files.append(str(p))
    return files




def build_artifact_manifest(out_dir: str | Path) -> dict[str, Any]:
    """Build an integrity manifest for files produced by a BenchCI run.

    The manifest is deliberately independent from evidence.json. It lets a QA
    reviewer verify that logs, results, evidence, and input snapshots were not
    silently changed after the run artifacts were generated.
    """
    root = Path(out_dir).expanduser().resolve()
    artifacts: list[dict[str, Any]] = []

    for rel in list_artifact_files(root):
        if rel == "manifest.json":
            continue
        path = root / rel
        if not path.is_file():
            continue
        try:
            size = path.stat().st_size
        except Exception:
            size = None
        artifacts.append(
            {
                "path": rel,
                "sha256": sha256_file(path),
                "size_bytes": size,
            }
        )

    return {
        "schema_version": "benchci.artifact_manifest.v1",
        "generated_at": utc_now(),
        "root_dir": str(root),
        "artifact_count": len(artifacts),
        "artifacts": artifacts,
    }

def _as_unique_strings(values: Any) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    if not values:
        return result
    if isinstance(values, str):
        values = [values]
    if not isinstance(values, (list, tuple, set)):
        return result
    for value in values:
        text = str(value).strip()
        if not text or text in seen:
            continue
        seen.add(text)
        result.append(text)
    return result


def _merge_unique(*groups: Any) -> list[str]:
    merged: list[str] = []
    seen: set[str] = set()
    for group in groups:
        for item in _as_unique_strings(group):
            if item in seen:
                continue
            seen.add(item)
            merged.append(item)
    return merged


def build_traceability_report(suite_cfg: Any, test_results: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    """Build a traceability block from SuiteConfig metadata and per-test results."""
    suite_meta = getattr(suite_cfg, "suite", None)
    result_by_name: dict[str, dict[str, Any]] = {}
    for result in test_results or []:
        name = str(result.get("name") or "")
        if name:
            result_by_name[name] = result

    suite_requirement_ids = _as_unique_strings(getattr(suite_meta, "requirement_ids", []))
    suite_risk_ids = _as_unique_strings(getattr(suite_meta, "risk_ids", []))
    suite_tags = _as_unique_strings(getattr(suite_meta, "tags", []))

    tests: list[dict[str, Any]] = []
    requirement_ids = list(suite_requirement_ids)
    risk_ids = list(suite_risk_ids)
    tags = list(suite_tags)
    test_case_ids: list[str] = []

    for test in getattr(suite_cfg, "tests", []) or []:
        name = str(getattr(test, "name", ""))
        result = result_by_name.get(name, {})
        test_requirement_ids = _as_unique_strings(getattr(test, "requirement_ids", []))
        test_risk_ids = _as_unique_strings(getattr(test, "risk_ids", []))
        test_tags = _as_unique_strings(getattr(test, "tags", []))
        test_case_id = getattr(test, "test_case_id", None)
        test_case_id = str(test_case_id).strip() if test_case_id else None

        requirement_ids = _merge_unique(requirement_ids, test_requirement_ids)
        risk_ids = _merge_unique(risk_ids, test_risk_ids)
        tags = _merge_unique(tags, test_tags)
        if test_case_id:
            test_case_ids = _merge_unique(test_case_ids, [test_case_id])

        tests.append(
            {
                "name": name,
                "status": "passed" if result.get("passed") is True else "failed" if result.get("passed") is False else "not_run",
                "passed": result.get("passed"),
                "duration_s": result.get("duration_s"),
                "test_case_id": test_case_id,
                "requirement_ids": test_requirement_ids,
                "risk_ids": test_risk_ids,
                "tags": test_tags,
                "failure_category": (result.get("failure") or {}).get("category") if isinstance(result.get("failure"), dict) else None,
                "failure_title": (result.get("failure") or {}).get("title") if isinstance(result.get("failure"), dict) else None,
            }
        )

    return {
        "suite": {
            "name": getattr(suite_meta, "name", None),
            "version": getattr(suite_meta, "version", None),
            "release_id": getattr(suite_meta, "release_id", None),
            "description": getattr(suite_meta, "description", None),
            "requirement_ids": suite_requirement_ids,
            "risk_ids": suite_risk_ids,
            "tags": suite_tags,
        },
        "requirement_ids": requirement_ids,
        "test_case_ids": test_case_ids,
        "risk_ids": risk_ids,
        "tags": tags,
        "tests": tests,
    }


def _escape(value: Any) -> str:
    if value is None or value == "":
        return "—"
    return html.escape(str(value))


def _short(value: Any, length: int = 14) -> str:
    text = str(value or "")
    if not text:
        return "—"
    return text[:length]


def _chips(values: Any) -> str:
    items = _as_unique_strings(values)
    if not items:
        return '<span class="muted">—</span>'
    return "".join(f'<span class="chip">{_escape(item)}</span>' for item in items)


def render_evidence_html(evidence: dict[str, Any]) -> str:
    """Render a self-contained human-readable evidence report."""
    run = evidence.get("run") or {}
    bench = evidence.get("bench") or {}
    suite = evidence.get("suite") or {}
    firmware = evidence.get("firmware") or {}
    source = evidence.get("source") or {}
    ci = evidence.get("ci") or {}
    result = evidence.get("result") or {}
    trace = evidence.get("traceability") or {}
    artifacts = evidence.get("artifacts") or {}
    failure = result.get("failure") if isinstance(result.get("failure"), dict) else None

    tests_rows = []
    for test in trace.get("tests") or []:
        status = test.get("status") or "not_run"
        status_class = "pass" if status == "passed" else "fail" if status == "failed" else "neutral"
        tests_rows.append(
            "<tr>"
            f"<td>{_escape(test.get('name'))}</td>"
            f"<td><span class='status {status_class}'>{_escape(status)}</span></td>"
            f"<td>{_escape(test.get('test_case_id'))}</td>"
            f"<td>{_chips(test.get('requirement_ids'))}</td>"
            f"<td>{_chips(test.get('risk_ids'))}</td>"
            f"<td>{_chips(test.get('tags'))}</td>"
            "</tr>"
        )
    if not tests_rows:
        tests_rows.append("<tr><td colspan='6' class='muted'>No test traceability metadata was provided.</td></tr>")

    artifact_items = "".join(f"<li><code>{_escape(path)}</code></li>" for path in artifacts.get("files", [])[:200])
    if not artifact_items:
        artifact_items = "<li class='muted'>No artifact files listed.</li>"

    measurements = evidence.get("measurements") or []
    measurement_rows = []
    for item in measurements[:200]:
        measurement_rows.append(
            "<tr>"
            f"<td>{_escape(item.get('name'))}</td>"
            f"<td>{_escape(item.get('resource'))}</td>"
            f"<td><strong>{_escape(item.get('value'))}</strong></td>"
            f"<td>{_escape(item.get('unit'))}</td>"
            f"<td>{_escape(item.get('quantity'))}</td>"
            "</tr>"
        )
    if not measurement_rows:
        measurement_rows.append("<tr><td colspan='5' class='muted'>No measurements were recorded.</td></tr>")

    failure_html = ""
    if failure:
        suggestions = "".join(f"<li>{_escape(item)}</li>" for item in failure.get("suggestions", []) or [])
        failure_html = f"""
        <section class="card failure">
          <h2>Failure Details</h2>
          <div class="kv"><span>Category</span><strong>{_escape(failure.get('category'))}</strong></div>
          <div class="kv"><span>Title</span><strong>{_escape(failure.get('title'))}</strong></div>
          <p>{_escape(failure.get('message'))}</p>
          <p class="muted">{_escape(failure.get('explanation'))}</p>
          <h3>Suggested checks</h3>
          <ul>{suggestions or '<li class="muted">No suggestions recorded.</li>'}</ul>
        </section>
        """

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>BenchCI Evidence Report - {_escape(run.get('run_id') or suite.get('name'))}</title>
  <style>
    :root {{ color-scheme: dark; --bg:#0b0b0f; --panel:#15151c; --border:#2a2a35; --text:#f4f4f5; --muted:#a1a1aa; --ok:#6ee7b7; --bad:#fda4af; --warn:#fcd34d; }}
    body {{ margin:0; font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background:var(--bg); color:var(--text); }}
    main {{ max-width:1100px; margin:0 auto; padding:32px; }}
    header {{ margin-bottom:24px; }}
    h1 {{ margin:0 0 8px; font-size:32px; }} h2 {{ margin:0 0 16px; }} h3 {{ margin:18px 0 8px; }}
    .muted {{ color:var(--muted); }} .mono, code {{ font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }}
    .grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:16px; }}
    .card {{ background:var(--panel); border:1px solid var(--border); border-radius:18px; padding:20px; margin-bottom:16px; }}
    .kv {{ display:flex; justify-content:space-between; gap:16px; border-top:1px solid var(--border); padding:10px 0; }} .kv:first-of-type {{ border-top:0; }}
    .kv span {{ color:var(--muted); }} .kv strong {{ text-align:right; overflow-wrap:anywhere; }}
    .status {{ display:inline-block; border-radius:999px; padding:4px 10px; font-weight:700; }} .pass {{ color:var(--ok); background:rgba(16,185,129,.12); }} .fail {{ color:var(--bad); background:rgba(244,63,94,.12); }} .neutral {{ color:var(--warn); background:rgba(245,158,11,.12); }}
    .chip {{ display:inline-block; border:1px solid var(--border); border-radius:999px; padding:3px 8px; margin:2px; background:#101016; }}
    table {{ width:100%; border-collapse:collapse; }} th,td {{ text-align:left; border-top:1px solid var(--border); padding:10px 8px; vertical-align:top; }} th {{ color:var(--muted); }}
    ul {{ margin:8px 0 0; padding-left:20px; }} li {{ margin:4px 0; }} .failure {{ border-color:rgba(244,63,94,.35); }}
  </style>
</head>
<body>
<main>
  <header>
    <div class="muted">BenchCI Evidence Report</div>
    <h1>{_escape(suite.get('name'))}</h1>
    <div class="muted">Generated at {_escape(evidence.get('generated_at'))}</div>
  </header>

  <section class="grid">
    <div class="card"><h2>Run Summary</h2><div class="kv"><span>Run ID</span><strong class="mono">{_escape(run.get('run_id'))}</strong></div><div class="kv"><span>Status</span><strong>{_escape(run.get('status'))}</strong></div><div class="kv"><span>Started</span><strong>{_escape(run.get('started_at'))}</strong></div><div class="kv"><span>Finished</span><strong>{_escape(run.get('finished_at'))}</strong></div><div class="kv"><span>Duration</span><strong>{_escape(run.get('duration_s'))}s</strong></div></div>
    <div class="card"><h2>Firmware / Source</h2><div class="kv"><span>Firmware</span><strong>{_escape(firmware.get('filename'))}</strong></div><div class="kv"><span>SHA256</span><strong class="mono">{_escape(_short(firmware.get('sha256'), 24))}</strong></div><div class="kv"><span>Git commit</span><strong class="mono">{_escape(_short(source.get('git_commit')))}</strong></div><div class="kv"><span>Branch</span><strong>{_escape(source.get('git_branch'))}</strong></div><div class="kv"><span>CI</span><strong>{_escape(ci.get('ci_provider'))}</strong></div></div>
    <div class="card"><h2>Bench / Suite</h2><div class="kv"><span>Bench</span><strong>{_escape(bench.get('name') or bench.get('bench_id'))}</strong></div><div class="kv"><span>Bench hash</span><strong class="mono">{_escape(_short(bench.get('config_sha256'), 24))}</strong></div><div class="kv"><span>Suite version</span><strong>{_escape((trace.get('suite') or {}).get('version'))}</strong></div><div class="kv"><span>Release</span><strong>{_escape((trace.get('suite') or {}).get('release_id'))}</strong></div><div class="kv"><span>Suite hash</span><strong class="mono">{_escape(_short(suite.get('sha256'), 24))}</strong></div></div>
  </section>

  <section class="card">
    <h2>Traceability</h2>
    <div class="kv"><span>Requirements</span><strong>{_chips(trace.get('requirement_ids'))}</strong></div>
    <div class="kv"><span>Test cases</span><strong>{_chips(trace.get('test_case_ids'))}</strong></div>
    <div class="kv"><span>Risks</span><strong>{_chips(trace.get('risk_ids'))}</strong></div>
    <div class="kv"><span>Tags</span><strong>{_chips(trace.get('tags'))}</strong></div>
  </section>

  <section class="card">
    <h2>Test Results</h2>
    <table><thead><tr><th>Test</th><th>Status</th><th>Test case</th><th>Requirements</th><th>Risks</th><th>Tags</th></tr></thead><tbody>{''.join(tests_rows)}</tbody></table>
  </section>

  {failure_html}

  <section class="card">
    <h2>Measurements & Metrics</h2>
    <table>
      <thead><tr><th>Name</th><th>Resource</th><th>Value</th><th>Unit</th><th>Quantity</th></tr></thead>
      <tbody>{''.join(measurement_rows)}</tbody>
    </table>
  </section>

  <section class="card">
    <h2>Artifacts</h2>
    <p class="muted">The artifact ZIP contains evidence.json, metadata.json, results.json, manifest.json, input snapshots, and logs.</p>
    <ul>{artifact_items}</ul>
  </section>
</main>
</body>
</html>"""



def _dict_or_empty(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _merge_non_empty(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in override.items():
        if value is not None and value != "":
            merged[key] = value
    return merged


def _normalize_evidence_context(evidence_context: dict[str, Any] | None) -> dict[str, dict[str, Any]]:
    """Normalize CI-submitted evidence context into source/ci/environment blocks.

    Cloud runs are submitted from a CI runner but executed on a hardware Agent.
    This helper lets the Agent-generated evidence prefer the submitter's Git/CI
    metadata while still keeping locally collected Agent environment metadata.
    """
    ctx = evidence_context if isinstance(evidence_context, dict) else {}
    source = _dict_or_empty(ctx.get("source"))
    ci = _dict_or_empty(ctx.get("ci"))
    environment = _dict_or_empty(ctx.get("environment"))

    # Also support a flat payload for backward compatibility.
    for key in ("git_commit", "git_branch", "git_remote", "git_dirty"):
        if key in ctx and key not in source:
            source[key] = ctx.get(key)
    for key in ("ci_provider", "ci_job_url", "ci_run_id", "ci_job_id"):
        if key in ctx and key not in ci:
            ci[key] = ctx.get(key)

    return {
        "source": source,
        "ci": ci,
        "environment": environment,
    }

def build_evidence_report(
    *,
    bench_path: str | Path,
    suite_path: str | Path,
    artifact_path: str | Path | None,
    out_dir: str | Path,
    bench_name: str,
    suite_name: str,
    run_mode: str = "local",
    run_id: str | None = None,
    status: str = "running",
    started_at: str | None = None,
    finished_at: str | None = None,
    duration_s: float | None = None,
    summary: dict[str, Any] | None = None,
    failure: dict[str, Any] | None = None,
    assigned_bench_id: str | None = None,
    assigned_agent_id: str | None = None,
    snapshots: dict[str, str] | None = None,
    suite_cfg: Any | None = None,
    test_results: list[dict[str, Any]] | None = None,
    metrics: dict[str, Any] | None = None,
    measurements: list[dict[str, Any]] | None = None,
    evidence_context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    bench_file = Path(bench_path).expanduser().resolve()
    suite_file = Path(suite_path).expanduser().resolve()
    artifact_file = Path(artifact_path).expanduser().resolve() if artifact_path else None

    git = collect_git_metadata(Path.cwd())
    ci = collect_ci_metadata()
    env = collect_environment_metadata()

    submitted_context = _normalize_evidence_context(evidence_context)
    git = _merge_non_empty(git, submitted_context["source"])
    ci = _merge_non_empty(ci, submitted_context["ci"])
    env = _merge_non_empty(env, submitted_context["environment"])
    if evidence_context:
        env.setdefault("evidence_context_source", "cloud_submitter")

    return {
        "schema_version": SCHEMA_VERSION,
        "generated_at": utc_now(),
        "run": {
            "run_id": run_id,
            "mode": run_mode,
            "status": status,
            "started_at": started_at,
            "finished_at": finished_at,
            "duration_s": duration_s,
        },
        "workspace": {},
        "bench": {
            "name": bench_name,
            "bench_id": assigned_bench_id,
            "agent_id": assigned_agent_id,
            "config_path": str(bench_file),
            "config_sha256": sha256_file(bench_file),
            "snapshot_path": (snapshots or {}).get("bench_yaml"),
        },
        "suite": {
            "name": suite_name,
            "version": getattr(getattr(suite_cfg, "suite", None), "version", None) if suite_cfg is not None else None,
            "release_id": getattr(getattr(suite_cfg, "suite", None), "release_id", None) if suite_cfg is not None else None,
            "path": str(suite_file),
            "sha256": sha256_file(suite_file),
            "snapshot_path": (snapshots or {}).get("suite_yaml"),
        },
        "firmware": {
            "filename": artifact_file.name if artifact_file else None,
            "path": str(artifact_file) if artifact_file else None,
            "sha256": sha256_file(artifact_file),
        },
        "source": git,
        "ci": ci,
        "environment": env,
        "result": {
            "status": status,
            "summary": summary or {},
            "failure_category": failure.get("category") if isinstance(failure, dict) else None,
            "failure_title": failure.get("title") if isinstance(failure, dict) else None,
            "failure": failure,
            "metrics": metrics or {},
            "measurements": measurements or [],
        },
        "metrics": metrics or {},
        "measurements": measurements or [],
        "traceability": build_traceability_report(suite_cfg, test_results) if suite_cfg is not None else {},
        "artifacts": {
            "root_dir": str(Path(out_dir).expanduser().resolve()),
            "files": list_artifact_files(out_dir),
        },
    }


def finalize_evidence_report(
    evidence: dict[str, Any],
    *,
    out_dir: str | Path,
    status: str,
    finished_at: str | None,
    duration_s: float | None,
    summary: dict[str, Any],
    failure: dict[str, Any] | None = None,
    suite_cfg: Any | None = None,
    test_results: list[dict[str, Any]] | None = None,
    metrics: dict[str, Any] | None = None,
    measurements: list[dict[str, Any]] | None = None,
    evidence_context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    evidence["generated_at"] = utc_now()
    evidence.setdefault("run", {})["status"] = status
    evidence["run"]["finished_at"] = finished_at
    evidence["run"]["duration_s"] = duration_s
    evidence.setdefault("result", {})["status"] = status
    evidence["result"]["summary"] = summary
    evidence["result"]["failure_category"] = failure.get("category") if isinstance(failure, dict) else None
    evidence["result"]["failure_title"] = failure.get("title") if isinstance(failure, dict) else None
    evidence["result"]["failure"] = failure
    evidence["result"]["metrics"] = metrics or {}
    evidence["result"]["measurements"] = measurements or []
    evidence["metrics"] = metrics or {}
    evidence["measurements"] = measurements or []
    if suite_cfg is not None:
        evidence["traceability"] = build_traceability_report(suite_cfg, test_results)
    evidence["artifacts"] = {
        "root_dir": str(Path(out_dir).expanduser().resolve()),
        "files": list_artifact_files(out_dir),
    }
    return evidence


def write_evidence_files(out_dir: str | Path, evidence: dict[str, Any]) -> dict[str, str]:
    out = Path(out_dir).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)

    evidence_json = out / "evidence.json"
    metadata_json = out / "metadata.json"
    evidence_html = out / "evidence.html"

    evidence_json.write_text(json.dumps(evidence, indent=2, sort_keys=True), encoding="utf-8")
    evidence_html.write_text(render_evidence_html(evidence), encoding="utf-8")

    metadata = {
        "schema_version": evidence.get("schema_version"),
        "generated_at": evidence.get("generated_at"),
        "run": evidence.get("run"),
        "bench": evidence.get("bench"),
        "suite": evidence.get("suite"),
        "firmware": evidence.get("firmware"),
        "source": evidence.get("source"),
        "ci": evidence.get("ci"),
        "environment": evidence.get("environment"),
        "traceability": evidence.get("traceability"),
        "metrics": evidence.get("metrics"),
        "measurements": evidence.get("measurements"),
    }
    metadata_json.write_text(json.dumps(metadata, indent=2, sort_keys=True), encoding="utf-8")

    manifest_json = out / "manifest.json"
    manifest = build_artifact_manifest(out)
    manifest_json.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")

    return {
        "evidence_json": str(evidence_json.resolve()),
        "metadata_json": str(metadata_json.resolve()),
        "evidence_html": str(evidence_html.resolve()),
        "manifest_json": str(manifest_json.resolve()),
    }
