from __future__ import annotations

import hashlib
import json
import os
import platform
import socket
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from benchci.config.bench import BenchConfig
from benchci.config.suite import SuiteConfig


SCHEMA_VERSION = "benchci.resource_locks.v1"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _default_lock_dir() -> Path:
    override = os.getenv("BENCHCI_LOCK_DIR", "").strip()
    if override:
        return Path(override).expanduser().resolve()
    return (Path.home() / ".benchci" / "locks").expanduser().resolve()


def _safe_slug(value: str, *, max_len: int = 48) -> str:
    chars: list[str] = []
    for ch in value.lower():
        if ch.isalnum():
            chars.append(ch)
        elif ch in {"-", "_", "."}:
            chars.append(ch)
        else:
            chars.append("-")
    slug = "".join(chars).strip("-") or "resource"
    while "--" in slug:
        slug = slug.replace("--", "-")
    return slug[:max_len].strip("-") or "resource"


def _stable_key_hash(key: str) -> str:
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]


def _resolve_node_name(bench: BenchConfig, explicit_node: str | None) -> str:
    if explicit_node:
        if explicit_node not in bench.nodes:
            known = ", ".join(sorted(bench.nodes.keys())) or "<none>"
            raise RuntimeError(f"Unknown node '{explicit_node}'. Known nodes: {known}")
        return explicit_node

    default_node = bench.defaults.node if bench.defaults else None
    if default_node:
        if default_node not in bench.nodes:
            known = ", ".join(sorted(bench.nodes.keys())) or "<none>"
            raise RuntimeError(f"bench.defaults.node is '{default_node}', but known nodes are: {known}")
        return default_node

    raise RuntimeError("Step does not define a node and bench.defaults.node is not set")


@dataclass(frozen=True)
class ResourceLockSpec:
    key: str
    display_name: str
    category: str
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "display_name": self.display_name,
            "category": self.category,
            "details": self.details,
        }


class ResourceLockError(RuntimeError):
    def __init__(self, spec: ResourceLockSpec, lock_path: Path, owner: dict[str, Any] | None = None):
        self.spec = spec
        self.lock_path = lock_path
        self.owner = owner or {}
        owner_label = self.owner.get("run_id") or self.owner.get("pid") or "another process"
        super().__init__(
            "BenchCI resource is locked by another run.\n"
            f"Resource: {spec.display_name}\n"
            f"Category: {spec.category}\n"
            f"Lock file: {lock_path}\n"
            f"Current owner: {owner_label}\n"
            "Wait for the other run to finish, or remove the stale lock only if you are sure no run is using the hardware."
        )


class _FileLock:
    def __init__(self, spec: ResourceLockSpec, lock_dir: Path, owner_payload: dict[str, Any]):
        self.spec = spec
        self.lock_dir = lock_dir
        self.owner_payload = owner_payload
        self.path = self._path_for_spec(spec)
        self._file = None

    def _path_for_spec(self, spec: ResourceLockSpec) -> Path:
        filename = f"{_safe_slug(spec.category)}-{_safe_slug(spec.display_name)}-{_stable_key_hash(spec.key)}.lock"
        return self.lock_dir / filename

    def acquire(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        f = self.path.open("a+", encoding="utf-8")
        try:
            _lock_file_nonblocking(f)
        except BlockingIOError:
            owner = _read_owner_payload(f)
            try:
                f.close()
            finally:
                self._file = None
            raise ResourceLockError(self.spec, self.path, owner)

        self._file = f
        _write_owner_payload(f, self.owner_payload)

    def release(self) -> None:
        if self._file is None:
            return
        f = self._file
        self._file = None
        try:
            try:
                f.seek(0)
                f.truncate(0)
            except Exception:
                pass
            _unlock_file(f)
        finally:
            try:
                f.close()
            except Exception:
                pass


class ResourceLockSet:
    """Acquire multiple resource locks in stable order and release them together."""

    def __init__(
        self,
        specs: list[ResourceLockSpec],
        *,
        run_id: str | None = None,
        lock_dir: str | Path | None = None,
        enabled: bool | None = None,
    ):
        deduped: dict[str, ResourceLockSpec] = {}
        for spec in specs:
            deduped.setdefault(spec.key, spec)
        self.specs = sorted(deduped.values(), key=lambda s: s.key)
        self.lock_dir = Path(lock_dir).expanduser().resolve() if lock_dir is not None else _default_lock_dir()
        self.run_id = run_id
        if enabled is None:
            self.enabled = os.getenv("BENCHCI_DISABLE_RESOURCE_LOCKS", "").strip().lower() not in {"1", "true", "yes", "on"}
        else:
            self.enabled = enabled
        self._locks: list[_FileLock] = []

    def acquire(self) -> dict[str, Any]:
        payload = {
            "schema_version": SCHEMA_VERSION,
            "run_id": self.run_id,
            "pid": os.getpid(),
            "hostname": socket.gethostname(),
            "platform": platform.platform(),
            "created_at": _utc_now(),
            "lock_count": len(self.specs),
        }

        if not self.enabled:
            return {
                "enabled": False,
                "lock_dir": str(self.lock_dir),
                "locks": [s.to_dict() for s in self.specs],
            }

        acquired: list[_FileLock] = []
        try:
            for spec in self.specs:
                lock = _FileLock(
                    spec,
                    self.lock_dir,
                    {
                        **payload,
                        "resource": spec.to_dict(),
                    },
                )
                lock.acquire()
                acquired.append(lock)
            self._locks = acquired
        except Exception:
            for lock in reversed(acquired):
                try:
                    lock.release()
                except Exception:
                    pass
            self._locks = []
            raise

        return {
            "enabled": True,
            "lock_dir": str(self.lock_dir),
            "locks": [
                {
                    **lock.spec.to_dict(),
                    "lock_path": str(lock.path),
                }
                for lock in self._locks
            ],
        }

    def release(self) -> None:
        for lock in reversed(self._locks):
            try:
                lock.release()
            except Exception:
                pass
        self._locks = []

    def __enter__(self) -> "ResourceLockSet":
        self.acquire()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.release()


def _lock_file_nonblocking(f) -> None:
    if os.name == "nt":
        import msvcrt  # type: ignore

        try:
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError as exc:
            raise BlockingIOError(str(exc)) from exc
        return

    import fcntl  # type: ignore

    try:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise
    except OSError as exc:
        raise BlockingIOError(str(exc)) from exc


def _unlock_file(f) -> None:
    if os.name == "nt":
        import msvcrt  # type: ignore

        try:
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
        except Exception:
            pass
        return

    import fcntl  # type: ignore

    try:
        fcntl.flock(f.fileno(), fcntl.LOCK_UN)
    except Exception:
        pass


def _read_owner_payload(f) -> dict[str, Any] | None:
    try:
        f.seek(0)
        text = f.read().strip()
        if not text:
            return None
        payload = json.loads(text)
        return payload if isinstance(payload, dict) else None
    except Exception:
        return None


def _write_owner_payload(f, payload: dict[str, Any]) -> None:
    f.seek(0)
    f.truncate(0)
    f.write(json.dumps(payload, indent=2, sort_keys=True))
    f.write("\n")
    f.flush()
    try:
        os.fsync(f.fileno())
    except Exception:
        pass


def collect_required_resource_locks(
    bench: BenchConfig,
    suite: SuiteConfig,
    *,
    skip_flash: bool = False,
) -> list[ResourceLockSpec]:
    specs: dict[str, ResourceLockSpec] = {}

    def add(key: str, display: str, category: str, **details: Any) -> None:
        specs.setdefault(
            key,
            ResourceLockSpec(
                key=key,
                display_name=display,
                category=category,
                details={k: v for k, v in details.items() if v is not None},
            ),
        )

    def add_transport(node_name: str, transport_name: str) -> None:
        node = bench.nodes[node_name]
        transport = node.transports[transport_name]
        backend = getattr(transport, "backend", type(transport).__name__)
        if hasattr(transport, "port") and backend in {"uart", "modbus_rtu"}:
            port = str(getattr(transport, "port"))
            add(
                f"serial:{port}",
                port,
                "serial_transport",
                node=node_name,
                transport=transport_name,
                backend=backend,
            )
            return
        if backend == "modbus_tcp":
            host = str(getattr(transport, "host", ""))
            port = str(getattr(transport, "port", ""))
            add(
                f"tcp:{host}:{port}",
                f"{host}:{port}",
                "network_transport",
                node=node_name,
                transport=transport_name,
                backend=backend,
            )
            return
        if backend == "can":
            iface = str(getattr(transport, "interface", ""))
            add(
                f"can:{iface}",
                iface,
                "can_transport",
                node=node_name,
                transport=transport_name,
                backend=backend,
            )
            return
        add(
            f"transport:{node_name}:{transport_name}",
            f"{node_name}.{transport_name}",
            "transport",
            node=node_name,
            transport=transport_name,
            backend=backend,
        )

    def add_flash_or_reset(node_name: str, *, reason: str) -> None:
        node = bench.nodes[node_name]
        flash = node.flash
        if flash is None:
            return
        backend = getattr(flash, "backend", "unknown")
        if backend == "esptool":
            port = str(getattr(flash, "port", ""))
            if port:
                add(
                    f"serial:{port}",
                    port,
                    "flash_serial",
                    node=node_name,
                    backend=backend,
                    reason=reason,
                )
            return
        if backend == "cubeprog":
            port = str(getattr(flash, "port", "SWD"))
            serial = getattr(flash, "serial", None) or "default"
            add(
                f"debugger:cubeprog:{port}:{serial}",
                f"STM32CubeProgrammer {port} {serial}",
                "debug_probe",
                node=node_name,
                backend=backend,
                reason=reason,
            )
            return
        if backend == "jlink":
            serial = getattr(flash, "serial", None) or "default"
            device = getattr(flash, "device", "unknown")
            add(
                f"debugger:jlink:{serial}:{device}",
                f"J-Link {serial} {device}",
                "debug_probe",
                node=node_name,
                backend=backend,
                reason=reason,
            )
            return
        if backend == "openocd":
            serial = getattr(flash, "probe_serial", None) or getattr(flash, "probe_serial_cmd", None)
            if serial:
                key = f"debugger:openocd:{serial}"
                display = f"OpenOCD probe {serial}"
            else:
                interface_cfg = getattr(flash, "interface_cfg", "")
                target_cfg = getattr(flash, "target_cfg", "")
                key = f"debugger:openocd:{interface_cfg}:{target_cfg}"
                display = f"OpenOCD {interface_cfg} {target_cfg}"
            add(
                key,
                display,
                "debug_probe",
                node=node_name,
                backend=backend,
                reason=reason,
            )
            return
        add(
            f"flash:{node_name}:{backend}",
            f"{node_name} flash backend {backend}",
            "flash",
            node=node_name,
            backend=backend,
            reason=reason,
        )

    def add_gpio_node(node_name: str) -> None:
        node = bench.nodes[node_name]
        for line_name, cfg in node.gpio.items():
            backend = getattr(cfg, "backend", "unknown")
            if backend == "local_gpio":
                chip = str(getattr(cfg, "chip", ""))
                line = str(getattr(cfg, "line", ""))
                add(
                    f"gpio:local:{chip}:{line}",
                    f"{chip} line {line}",
                    "gpio_line",
                    node=node_name,
                    line=line_name,
                    backend=backend,
                    chip=chip,
                    channel=line,
                )
            elif backend == "remote_gpio":
                host = str(getattr(cfg, "host", ""))
                port = str(getattr(cfg, "port", ""))
                chip = str(getattr(cfg, "chip", ""))
                line = str(getattr(cfg, "line", ""))
                add(
                    f"gpio:remote:{host}:{port}:{chip}:{line}",
                    f"remote GPIO {host}:{port} {chip} line {line}",
                    "gpio_line",
                    node=node_name,
                    line=line_name,
                    backend=backend,
                    host=host,
                    port=port,
                    chip=chip,
                    channel=line,
                )
            elif backend == "mock_gpio":
                channel = str(getattr(cfg, "channel", ""))
                add(
                    f"gpio:mock:{node_name}:{channel}",
                    f"mock GPIO {node_name} channel {channel}",
                    "gpio_line",
                    node=node_name,
                    line=line_name,
                    backend=backend,
                    channel=channel,
                )

    def add_power_resource(resource_name: str) -> None:
        resource = bench.resources[resource_name]
        driver = resource.driver
        driver_type = getattr(driver, "type", "unknown")
        if driver_type == "gpio_power":
            chip = str(getattr(driver, "chip", ""))
            for outlet, line in getattr(driver, "outlets", {}).items():
                add(
                    f"gpio:local:{chip}:{line}",
                    f"{chip} line {line}",
                    "power_gpio_line",
                    resource=resource_name,
                    outlet=outlet,
                    driver_type=driver_type,
                    chip=chip,
                    channel=line,
                )
            return
        if driver_type == "usb_relay_serial":
            port = str(getattr(driver, "port", ""))
            if port:
                add(
                    f"serial:{port}",
                    port,
                    "power_serial_relay",
                    resource=resource_name,
                    driver_type=driver_type,
                )
            return
        if driver_type == "http_relay":
            on_url = str(getattr(driver, "on_url", ""))
            off_url = str(getattr(driver, "off_url", ""))
            add(
                f"http_relay:{on_url}:{off_url}",
                f"HTTP relay {resource_name}",
                "power_http_relay",
                resource=resource_name,
                driver_type=driver_type,
            )
            return
        add(
            f"power:{resource_name}",
            resource_name,
            "power_resource",
            resource=resource_name,
            driver_type=driver_type,
        )

    def add_measurement_resource(resource_name: str) -> None:
        resource = bench.resources[resource_name]
        driver = resource.driver
        driver_type = getattr(driver, "type", "unknown")
        if driver_type == "http_measurement":
            url = str(getattr(driver, "url", ""))
            add(
                f"http_measurement:{url}",
                f"HTTP measurement {resource_name}",
                "measurement_http",
                resource=resource_name,
                driver_type=driver_type,
                url=url,
            )
            return
        add(
            f"measurement:{resource_name}",
            resource_name,
            "measurement_resource",
            resource=resource_name,
            driver_type=driver_type,
        )

    required_nodes: set[str] = set()

    for test in suite.tests:
        for step in test.steps:
            if hasattr(step, "flash"):
                node_name = _resolve_node_name(bench, step.flash.node)
                required_nodes.add(node_name)
                if not skip_flash:
                    add_flash_or_reset(node_name, reason="flash")
            elif hasattr(step, "reset"):
                node_name = _resolve_node_name(bench, step.reset.node)
                required_nodes.add(node_name)
                reset_method = getattr(bench.nodes[node_name].reset, "method", "none")
                if reset_method != "none":
                    add_flash_or_reset(node_name, reason="reset")
            elif hasattr(step, "send_uart"):
                node_name = _resolve_node_name(bench, step.send_uart.node)
                required_nodes.add(node_name)
                add_transport(node_name, step.send_uart.transport)
            elif hasattr(step, "expect_uart"):
                node_name = _resolve_node_name(bench, step.expect_uart.node)
                required_nodes.add(node_name)
                add_transport(node_name, step.expect_uart.transport)
            elif hasattr(step, "modbus_read_holding_registers"):
                node_name = _resolve_node_name(bench, step.modbus_read_holding_registers.node)
                required_nodes.add(node_name)
                add_transport(node_name, step.modbus_read_holding_registers.transport)
            elif hasattr(step, "modbus_write_single_register"):
                node_name = _resolve_node_name(bench, step.modbus_write_single_register.node)
                required_nodes.add(node_name)
                add_transport(node_name, step.modbus_write_single_register.transport)
            elif hasattr(step, "modbus_read_coils"):
                node_name = _resolve_node_name(bench, step.modbus_read_coils.node)
                required_nodes.add(node_name)
                add_transport(node_name, step.modbus_read_coils.transport)
            elif hasattr(step, "modbus_write_single_coil"):
                node_name = _resolve_node_name(bench, step.modbus_write_single_coil.node)
                required_nodes.add(node_name)
                add_transport(node_name, step.modbus_write_single_coil.transport)
            elif hasattr(step, "gpio_set"):
                required_nodes.add(_resolve_node_name(bench, step.gpio_set.node))
            elif hasattr(step, "gpio_get"):
                required_nodes.add(_resolve_node_name(bench, step.gpio_get.node))
            elif hasattr(step, "gpio_expect"):
                required_nodes.add(_resolve_node_name(bench, step.gpio_expect.node))
            elif hasattr(step, "gpio_wait_edge"):
                required_nodes.add(_resolve_node_name(bench, step.gpio_wait_edge.node))
            elif hasattr(step, "power_set"):
                add_power_resource(step.power_set.resource)
            elif hasattr(step, "power_cycle"):
                add_power_resource(step.power_cycle.resource)
            elif hasattr(step, "power_expect"):
                add_power_resource(step.power_expect.resource)
            elif hasattr(step, "measure"):
                add_measurement_resource(step.measure.resource)
            elif hasattr(step, "send_can"):
                node_name = _resolve_node_name(bench, step.send_can.node)
                required_nodes.add(node_name)
                add_transport(node_name, step.send_can.transport)
            elif hasattr(step, "expect_can"):
                node_name = _resolve_node_name(bench, step.expect_can.node)
                required_nodes.add(node_name)
                add_transport(node_name, step.expect_can.transport)

    # The current runner starts a GPIO manager for every required node that has GPIO,
    # so lock all declared GPIO lines on those nodes, not only lines referenced by GPIO steps.
    for node_name in sorted(required_nodes):
        if bench.nodes[node_name].gpio:
            add_gpio_node(node_name)

    return sorted(specs.values(), key=lambda s: s.key)
