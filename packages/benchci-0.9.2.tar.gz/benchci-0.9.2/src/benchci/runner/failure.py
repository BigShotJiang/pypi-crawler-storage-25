from __future__ import annotations

from typing import Any

FailureSource = str

FAILURE_CATEGORY_SOURCE: dict[str, FailureSource] = {
    "FLASH_FAILED": "bench_infrastructure",
    "FLASH_TOOL_UNAVAILABLE": "bench_infrastructure",
    "ARTIFACT_ERROR": "configuration",

    "UART_EXPECTATION_FAILED": "firmware",
    "UART_FAILED": "bench_infrastructure",
    "MODBUS_EXPECTATION_FAILED": "firmware",
    "CAN_EXPECTATION_FAILED": "firmware",
    "CAN_FAILED": "bench_infrastructure",

    "GPIO_EXPECTATION_FAILED": "firmware",
    "GPIO_LINE_UNREACHABLE": "bench_infrastructure",
    
    "POWER_READBACK_UNAVAILABLE": "bench_infrastructure",
    "POWER_CONTROL_FAILED": "bench_infrastructure",
    "POWER_RESOURCE_UNAVAILABLE": "bench_infrastructure",

    "MEASUREMENT_ASSERTION_FAILED": "firmware",
    "MEASUREMENT_FAILED": "bench_infrastructure",
    "MEASUREMENT_RESOURCE_UNAVAILABLE": "bench_infrastructure",

    "TRANSPORT_OPEN_FAILED": "bench_infrastructure",
    "BENCH_SELF_TEST_FAILED": "bench_infrastructure",
    "RESOURCE_LOCKED": "bench_infrastructure",

    "CONFIG_ERROR": "configuration",
    "CONFIG_WARNING": "configuration",

    "STEP_TIMEOUT": "unknown",
    "UNKNOWN_ERROR": "unknown",
}


def failure_source_for_category(category: str | None) -> FailureSource:
    if not category:
        return "unknown"
    return FAILURE_CATEGORY_SOURCE.get(category, "unknown")


class BenchCIFailure(RuntimeError):
    """Structured BenchCI failure that can be shown in CLI, artifacts, and UI."""

    def __init__(self, failure: dict[str, Any]):
        self.failure = failure
        super().__init__(failure_summary_text(failure))


def _unique(items: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        if item in seen:
            continue
        seen.add(item)
        result.append(item)
    return result


def classify_failure(message: str, *, step_type: str | None = None) -> dict[str, Any]:
    text = (message or "").lower()
    step = (step_type or "").lower()

    if "resource is locked" in text or "resource lock" in text or "locked by another run" in text:
        return {
            "category": "RESOURCE_LOCKED",
            "title": "Bench resource is locked",
            "explanation": "Another BenchCI run is currently using one of the hardware resources needed by this run.",
            "suggestions": [
                "Wait for the other run to finish and retry.",
                "Check the lock owner and run ID shown in the error message.",
                "Only remove a stale lock if you are sure no BenchCI process is still using the hardware.",
            ],
        }

    if step == "flash" or "flash" in text or "openocd" in text or "stm32_programmer" in text or "jlink" in text or "esptool" in text or "hardware tool command failed" in text:
        return {
            "category": "FLASH_FAILED",
            "title": "Flashing failed",
            "explanation": "BenchCI could not program or reset the target using the configured flashing backend.",
            "suggestions": [
                "Check that the debug probe is connected and visible to the machine running the agent.",
                "Check that the target board is powered and not held in reset.",
                "Verify the flash backend settings in bench.yaml, including probe serial, target, interface, and port.",
                "Open the flash log artifact for the hardware-tool output.",
            ],
        }

    if "artifact" in text and ("not found" in text or "missing" in text or "required" in text or "unsupported" in text):
        return {
            "category": "ARTIFACT_ERROR",
            "title": "Firmware artifact problem",
            "explanation": "BenchCI could not use the firmware artifact required by the run.",
            "suggestions": [
                "Check the --artifact path or the artifact path configured in bench.yaml.",
                "Make sure the file exists on the machine running the command or agent.",
                "Use a supported firmware type for the selected flash backend, such as .elf, .hex, or .bin where supported.",
            ],
        }

    if step in {"expect_uart", "send_uart"} or "uart" in text or "serial" in text:
        return {
            "category": "UART_EXPECTATION_FAILED" if "expect" in step or "timed out" in text else "UART_FAILED",
            "title": "UART expectation failed" if "expect" in step or "timed out" in text else "UART communication failed",
            "explanation": "BenchCI did not observe the expected UART output or could not communicate over the configured serial transport.",
            "suggestions": [
                "Check that the UART port in bench.yaml matches the correct device on this machine.",
                "Check baud rate, wiring, TX/RX direction, and common ground.",
                "Confirm that the firmware prints the expected text after flash/reset.",
                "Open the transport log artifact to see the last UART data captured by BenchCI.",
            ],
        }

    if step.startswith("modbus") or "modbus" in text:
        return {
            "category": "MODBUS_EXPECTATION_FAILED",
            "title": "Modbus expectation failed",
            "explanation": "BenchCI did not receive the expected Modbus response from the device under test.",
            "suggestions": [
                "Check the configured Modbus transport, slave ID, baud rate, parity, and address.",
                "Verify RS485 A/B wiring and termination if using Modbus RTU.",
                "Open the transport log artifact for request/response details.",
            ],
        }

    if step.startswith("gpio") or "gpio" in text:
        return {
            "category": "GPIO_EXPECTATION_FAILED",
            "title": "GPIO expectation failed",
            "explanation": "BenchCI did not observe the expected GPIO state or edge.",
            "suggestions": [
                "Check GPIO chip and line numbers in bench.yaml.",
                "Check active_high, pull-up/pull-down bias, and wiring.",
                "Run benchci doctor on the agent machine to inspect local GPIO support.",
                "Open the GPIO log artifact for observed values.",
            ],
        }

    if step in {"power_set", "power_cycle", "power_expect"} or "power" in text or "relay" in text:
        return {
            "category": "POWER_CONTROL_FAILED",
            "title": "Power control failed",
            "explanation": "BenchCI could not control the configured power resource or relay.",
            "suggestions": [
                "Check that the relay/power device is connected to the agent machine.",
                "Verify the resource name, outlet name, serial port, and relay model in bench.yaml.",
                "Open the power log artifact for driver-specific details.",
                "If this is power_expect, verify the backend supports state readback or tracked state.",
            ],
        }

    if step in {"measure", "assert_metric"} or "measurement" in text or "metric" in text:
        return {
            "category": "MEASUREMENT_ASSERTION_FAILED" if step in {"measure", "assert_metric"} else "MEASUREMENT_FAILED",
            "title": "Measurement assertion failed" if step in {"measure", "assert_metric"} else "Measurement failed",
            "explanation": "BenchCI could not read the configured measurement resource or the measured value did not satisfy the suite assertion.",
            "suggestions": [
                "Check the measurement resource name and driver settings in bench.yaml.",
                "Check expected thresholds, units, and tolerance in suite.yaml.",
                "For HTTP/SCPI-backed measurements, verify the lab controller or instrument is reachable from the agent machine.",
                "Open the measurement log artifact for the raw measured value and backend-specific details.",
            ],
        }

    if step in {"expect_can", "send_can"} or "can" in text:
        return {
            "category": "CAN_EXPECTATION_FAILED" if "expect" in step else "CAN_FAILED",
            "title": "CAN expectation failed" if "expect" in step else "CAN communication failed",
            "explanation": "BenchCI did not observe the expected CAN frame or could not use the configured CAN interface.",
            "suggestions": [
                "Check the CAN interface name and bitrate in bench.yaml.",
                "Check CAN transceiver wiring, termination, and bus power.",
                "Open the CAN transport log artifact for observed frames.",
            ],
        }

    if "unknown node" in text or "does not define" in text or "bench.defaults" in text or "unsupported step" in text or "validation" in text:
        return {
            "category": "CONFIG_ERROR",
            "title": "Bench or suite configuration problem",
            "explanation": "BenchCI found an inconsistency between bench.yaml and suite.yaml before or during execution.",
            "suggestions": [
                "Run benchci validate --bench bench.yaml --suite suite.yaml before running the suite.",
                "Check node names, transport names, GPIO line names, power resource names, and required defaults.",
                "Compare the failing step with the names defined in bench.yaml.",
            ],
        }

    if "timeout" in text or "timed out" in text:
        return {
            "category": "STEP_TIMEOUT",
            "title": "Step timed out",
            "explanation": "A suite step did not complete within the configured timeout.",
            "suggestions": [
                "Increase within_ms if the device legitimately needs more time.",
                "Check that the device is powered, flashed, and running the expected firmware.",
                "Open the relevant transport/GPIO/power/measurement log artifact for the last observed state.",
            ],
        }

    return {
        "category": "UNKNOWN_ERROR",
        "title": "Run failed",
        "explanation": "BenchCI could not map this failure to a more specific category yet.",
        "suggestions": [
            "Open results.json and the related log artifacts for raw details.",
            "Run benchci doctor on the machine connected to the hardware.",
            "Check bench.yaml and suite.yaml with benchci validate.",
        ],
    }


def build_failure(
    *,
    message: str,
    category: str | None = None,
    source: str | None = None,
    title: str | None = None,
    explanation: str | None = None,
    suggestions: list[str] | None = None,
    test_name: str | None = None,
    test_index: int | None = None,
    step_index: int | None = None,
    steps_total: int | None = None,
    step_type: str | None = None,
    node_name: str | None = None,
    transport_name: str | None = None,
    artifacts: dict[str, Any] | None = None,
    details: dict[str, Any] | None = None,
    raw_error: str | None = None,
) -> dict[str, Any]:
    classified = classify_failure(message, step_type=step_type)
    failure = {
        "category": category or classified["category"],
        "source": source or failure_source_for_category(category or classified["category"]),
        "title": title or classified["title"],
        "message": message,
        "explanation": explanation or classified["explanation"],
        "suggestions": _unique(list(suggestions or []) + list(classified.get("suggestions", []))),
        "failed_step": {
            "test_name": test_name,
            "test_index": test_index,
            "step_index": step_index,
            "steps_total": steps_total,
            "step_type": step_type,
            "node_name": node_name,
            "transport_name": transport_name,
        },
        "artifacts": artifacts or {},
        "details": details or {},
        "raw_error": raw_error or message,
    }
    failure["failed_step"] = {k: v for k, v in failure["failed_step"].items() if v is not None}
    failure["details"] = {k: v for k, v in failure["details"].items() if v is not None and v != ""}
    return failure


def failure_summary_text(failure: dict[str, Any] | None) -> str:
    if not failure:
        return "Run failed"
    title = str(failure.get("title") or "Run failed")
    msg = str(failure.get("message") or "").strip()
    if msg and msg != title:
        return f"{title}: {msg}"
    return title
