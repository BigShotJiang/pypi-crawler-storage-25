from __future__ import annotations

from pathlib import Path
from typing import Annotated, Literal, Union

import yaml
from pydantic import BaseModel, Field, model_validator


# =========================
# Bench metadata / defaults
# =========================

class BenchMeta(BaseModel):
    """Top-level bench metadata."""
    name: str = Field(..., description="Human-friendly bench name.")
    description: str | None = Field(None, description="Optional bench description.")


class TimeoutDefaults(BaseModel):
    """Default timeout values that suite steps may inherit."""
    within_ms: int | None = Field(
        None,
        gt=0,
        description="Default timeout in milliseconds for wait/expect operations.",
    )


class BenchDefaults(BaseModel):
    """Optional defaults used by suites/runners."""
    node: str | None = Field(
        None,
        description="Default node name used when a suite step omits node.",
    )
    timeouts: TimeoutDefaults | None = Field(
        None,
        description="Optional default timeout values.",
    )


class ArtifactConfig(BaseModel):
    """Artifact output configuration."""
    root_dir: str = Field(
        "benchci-results",
        description="Root directory where run artifacts are written.",
    )
    per_node_dirs: bool = Field(
        True,
        description="If true, write artifacts into separate per-node subdirectories.",
    )


# =========================
# Flashing configuration
# =========================

class FlashBase(BaseModel):
    """Base model for flashing configuration."""
    backend: str
    artifact: str | None = Field(
        None,
        description="Optional default firmware artifact path for this node.",
    )


class FlashOpenOCD(FlashBase):
    """OpenOCD flashing backend configuration."""
    backend: Literal["openocd"] = "openocd"

    interface_cfg: str = Field(
        ...,
        description="OpenOCD interface cfg, e.g. 'interface/stlink.cfg' or 'interface/jlink.cfg'",
    )
    target_cfg: str = Field(
        ...,
        description="OpenOCD target cfg, e.g. 'target/stm32f4x.cfg' or 'target/stm32wlx.cfg'",
    )
    extra_args: list[str] = Field(
        default_factory=list,
        description="Extra arguments appended to the openocd command (advanced use).",
    )
    adapter_speed_khz: int | None = Field(
        None,
        description="SWD/JTAG adapter speed in kHz (optional).",
    )
    probe_serial: str | None = Field(
        None,
        description="Probe serial number (default behavior uses OpenOCD 'hla_serial <SN>').",
    )
    probe_serial_cmd: str | None = Field(
        None,
        description="Advanced: full OpenOCD command to select probe serial (e.g. 'jlink serial 12345678').",
    )


class FlashCubeProg(FlashBase):
    """STM32CubeProgrammer CLI flashing backend configuration."""
    backend: Literal["cubeprog"] = "cubeprog"

    port: str = Field("SWD", description="Connection port (e.g. SWD or USB).")
    serial: str | None = Field(None, description="Optional ST-Link serial number.")


class FlashJLink(FlashBase):
    """SEGGER J-Link flashing backend configuration."""
    backend: Literal["jlink"] = "jlink"

    device: str = Field(
        ...,
        description="Target MCU name understood by JLinkExe, e.g. STM32F407VG.",
    )
    interface: Literal["SWD", "JTAG"] = Field("SWD", description="Debug interface.")
    speed_khz: int = Field(4000, description="J-Link speed in kHz.")
    serial: str | None = Field(None, description="Optional J-Link serial number.")


class FlashEspTool(FlashBase):
    """ESP32/ESP-family flashing backend via esptool.py."""
    backend: Literal["esptool"] = "esptool"

    port: str = Field(..., description="Serial device path used for flashing.")
    baud: int = Field(921600, description="Flashing baud rate.")
    chip: str | None = Field(
        None,
        description="Optional chip name, e.g. esp32, esp32s3.",
    )
    offset: str = Field(
        "0x10000",
        description="Default flash offset when writing a single app image.",
    )
    extra_args: list[str] = Field(
        default_factory=list,
        description="Extra arguments appended to esptool.py.",
    )


FlashConfig = Annotated[
    Union[FlashOpenOCD, FlashCubeProg, FlashJLink, FlashEspTool],
    Field(discriminator="backend"),
]


# =========================
# Reset configuration
# =========================

class ResetConfig(BaseModel):
    """How BenchCI should reset the node between steps/tests."""
    method: Literal["openocd", "cubeprog", "jlink", "esptool", "none"] = Field(
        "none",
        description="Reset strategy: 'openocd', 'cubeprog', 'jlink', 'esptool', or 'none'.",
    )


# =========================
# Transport configuration
# =========================

class TransportBase(BaseModel):
    """Base model for communication transport configuration."""
    backend: str


class TransportUart(TransportBase):
    """UART text transport configuration."""
    backend: Literal["uart"] = "uart"

    port: str = Field(..., description="Serial device path (e.g. /dev/ttyUSB0 or COM3).")
    baud: int = Field(115200, description="UART baud rate.")
    timeout_ms: int = Field(100, description="Read timeout in milliseconds used by the test runner.")


class TransportModbusRtu(TransportBase):
    """Modbus RTU transport configuration."""
    backend: Literal["modbus_rtu"] = "modbus_rtu"

    port: str = Field(..., description="RS485/serial device path (e.g. /dev/ttyUSB0 or COM3).")
    baud: int = Field(9600, description="Modbus RTU baud rate.")
    timeout_ms: int = Field(500, description="Modbus request timeout in milliseconds.")
    default_slave: int = Field(1, ge=1, le=247, description="Default Modbus slave/unit ID.")


class TransportModbusTcp(TransportBase):
    """Modbus TCP transport configuration."""
    backend: Literal["modbus_tcp"] = "modbus_tcp"

    host: str = Field(..., description="Target host or IP address (e.g. 192.168.1.50).")
    port: int = Field(502, ge=1, le=65535, description="Modbus TCP port.")
    timeout_ms: int = Field(1000, description="Modbus request timeout in milliseconds.")
    default_slave: int = Field(1, ge=1, le=247, description="Default Modbus slave/unit ID.")


class TransportCan(TransportBase):
    """CAN transport configuration."""
    backend: Literal["can"] = "can"

    interface: str = Field(..., description="CAN interface name, e.g. can0, can1, vcan0.")
    bitrate: int = Field(..., gt=0, description="CAN bitrate in bits per second.")
    timeout_ms: int = Field(500, description="Receive timeout in milliseconds.")


TransportConfig = Annotated[
    Union[TransportUart, TransportModbusRtu, TransportModbusTcp, TransportCan],
    Field(discriminator="backend"),
]


# =========================
# GPIO configuration
# =========================

class GpioBase(BaseModel):
    """Base model for GPIO line configuration."""
    backend: str
    direction: Literal["input", "output"] = Field(
        ...,
        description="GPIO line direction.",
    )
    active_high: bool = Field(
        True,
        description="If true, logical true maps to physical high. If false, logical true maps to physical low.",
    )
    bias: Literal["disabled", "pull_up", "pull_down"] | None = Field(
        None,
        description="Optional GPIO bias configuration for supported input-capable backends.",
    )
    edge: Literal["rising", "falling", "both"] | None = Field(
        None,
        description="Optional edge detection mode for supported input-capable backends.",
    )


class GpioMock(GpioBase):
    """Mock GPIO backend used for development and testing."""
    backend: Literal["mock_gpio"] = "mock_gpio"
    channel: int = Field(..., ge=0, description="Mock GPIO channel number.")


class GpioLocal(GpioBase):
    """Linux local GPIO backend using gpiochip character device."""
    backend: Literal["local_gpio"] = "local_gpio"
    chip: str = Field(
        ...,
        description="GPIO chip device path, e.g. /dev/gpiochip0.",
    )
    line: int = Field(
        ...,
        ge=0,
        description="GPIO line number within the selected chip.",
    )


class GpioRemote(GpioBase):
    """Remote Linux GPIO backend served by a BenchCI-compatible GPIO service."""
    backend: Literal["remote_gpio"] = "remote_gpio"
    host: str = Field(
        ...,
        description="Remote GPIO host or IP address, e.g. 192.168.1.60.",
    )
    port: int = Field(
        8090,
        ge=1,
        le=65535,
        description="Remote GPIO service port.",
    )
    token_env: str = Field(
        ...,
        description="Environment variable name containing the remote GPIO access token.",
    )
    chip: str = Field(
        ...,
        description="Remote GPIO chip device path, e.g. /dev/gpiochip0.",
    )
    line: int = Field(
        ...,
        ge=0,
        description="GPIO line number within the selected remote chip.",
    )


GpioConfig = Annotated[
    Union[GpioMock, GpioLocal, GpioRemote],
    Field(discriminator="backend"),
]


# =========================
# Bench resources
# =========================

class ResourceDriverBase(BaseModel):
    """Base model for shared bench-level resource drivers.

    BenchCI keeps suite steps vendor-neutral: tests call high-level actions such
    as power_set/power_cycle while the driver hides whether the actual hardware
    is a GPIO relay, USB relay, HTTP relay, SCPI supply, or a mock controller.
    """
    type: str


class ResourceDriverScpi(ResourceDriverBase):
    """Generic SCPI instrument resource.

    This is intentionally generic and can later be used by measurement/power
    supply drivers without changing suite syntax.
    """
    type: Literal["scpi"] = "scpi"
    address: str = Field(..., description="SCPI resource address, e.g. tcp://192.168.1.50:5025")
    timeout_ms: int = Field(1000, gt=0, description="SCPI command timeout in milliseconds.")


class ResourceDriverScpiMeasurement(ResourceDriverBase):
    """Measurement resource backed by a SCPI query.

    Supports:
      - TCP socket SCPI, e.g. tcp://192.168.1.50:5025
      - Serial/RS232 SCPI, e.g. serial:///dev/ttyUSB0 or serial://COM3
      - VISA/USBTMC SCPI, e.g. USB0::0x1234::0x5678::INSTR
    """
    type: Literal["scpi_measurement"] = "scpi_measurement"

    address: str = Field(
        ...,
        description=(
            "SCPI address. Examples: tcp://192.168.1.50:5025, "
            "serial:///dev/ttyUSB0, serial://COM3, USB0::0x1234::0x5678::INSTR"
        ),
    )
    query: str = Field(
        ...,
        min_length=1,
        description="SCPI query used to read the measurement, e.g. MEAS:CURR?",
    )
    quantity: str = Field(
        "generic",
        description="Measured quantity, e.g. current, voltage, temperature.",
    )
    unit: str | None = Field(
        None,
        description="Measurement unit, e.g. A, V, C, ms.",
    )
    timeout_ms: int = Field(
        1000,
        gt=0,
        description="SCPI command timeout in milliseconds.",
    )

    # Serial/RS232 options. Ignored for TCP and VISA addresses.
    baudrate: int = Field(9600, gt=0, description="Serial baud rate.")
    bytesize: int = Field(8, ge=5, le=8, description="Serial byte size.")
    parity: Literal["N", "E", "O", "M", "S"] = Field("N", description="Serial parity.")
    stopbits: float = Field(1, description="Serial stop bits, usually 1, 1.5, or 2.")

    write_termination: str = Field(
        "\n",
        description="Termination appended to SCPI commands.",
    )
    read_termination: str = Field(
        "\n",
        description="Expected response termination.",
    )


class ResourceDriverScpiPowerSupplyMeasurement(ResourceDriverBase):
    """Power-supply measurement resource backed by common SCPI readback queries.

    This higher-level driver maps common power-supply quantities to conservative
    SCPI readback queries while reusing the same TCP, serial/RS232, and
    VISA/USBTMC transport support as scpi_measurement.

    Vendor/model presets are intentionally limited to readback queries in
    v0.8.0. They do not perform output control, setpoint control, protection
    configuration, or model discovery.
    """
    type: Literal["scpi_power_supply_measurement"] = "scpi_power_supply_measurement"

    address: str = Field(
        ...,
        description=(
            "SCPI address. Examples: tcp://192.168.1.50:5025, "
            "serial:///dev/ttyUSB0, serial://COM3, USB0::0x1234::0x5678::INSTR"
        ),
    )
    preset: Literal[
        "generic",
        "owon_sp",
        "rigol_dp_basic",
        "keysight_basic",
        "keysight_e36300_basic",
    ] = Field(
        "generic",
        description=(
            "Conservative SCPI power-supply readback preset. Supported in v0.8.0: "
            "generic, owon_sp, rigol_dp_basic, keysight_basic, keysight_e36300_basic."
        ),
    )
    quantity: Literal["current", "voltage"] = Field(
        ...,
        description="Power-supply quantity to read. Supported in v0.8.0: current or voltage.",
    )
    unit: str | None = Field(
        None,
        description="Optional unit override. Defaults to A for current and V for voltage.",
    )
    channel: int | None = Field(
        None,
        ge=1,
        description=(
            "Optional logical power-supply channel number. The generic v0.8.0 "
            "driver records this value as metadata; vendor presets add "
            "model-specific channel-selection behavior."
        ),
    )
    timeout_ms: int = Field(
        1000,
        gt=0,
        description="SCPI command timeout in milliseconds.",
    )

    # Serial/RS232 options. Ignored for TCP and VISA addresses.
    baudrate: int = Field(9600, gt=0, description="Serial baud rate.")
    bytesize: int = Field(8, ge=5, le=8, description="Serial byte size.")
    parity: Literal["N", "E", "O", "M", "S"] = Field("N", description="Serial parity.")
    stopbits: float = Field(1, description="Serial stop bits, usually 1, 1.5, or 2.")

    write_termination: str = Field(
        "\n",
        description="Termination appended to SCPI commands.",
    )
    read_termination: str = Field(
        "\n",
        description="Expected response termination.",
    )


class ResourceDriverGpio(ResourceDriverBase):
    """Legacy generic GPIO resource placeholder.

    Prefer ResourceDriverGpioPower for power control because it includes outlet
    names, active-high mapping, and settle delays.
    """
    type: Literal["gpio"] = "gpio"
    chip: str = Field(..., description="GPIO chip device path used by the resource controller.")


class ResourceDriverMockPower(ResourceDriverBase):
    """In-memory power controller for dry-runs, demos, and tests."""
    type: Literal["mock_power"] = "mock_power"
    outlets: dict[str, bool] = Field(
        default_factory=lambda: {"main": False},
        min_length=1,
        description="Logical outlet name -> initial state mapping.",
    )
    on_settle_ms: int = Field(0, ge=0, description="Delay after turning power on.")
    off_settle_ms: int = Field(0, ge=0, description="Delay after turning power off.")


class ResourceDriverGpioPower(ResourceDriverBase):
    """Power control through local Linux GPIO lines.

    This is the recommended first-class backend for Raspberry Pi based benches
    that drive relays, MOSFETs, or load switches.
    """
    type: Literal["gpio_power"] = "gpio_power"
    chip: str = Field(..., description="GPIO chip device path, e.g. /dev/gpiochip0.")
    outlets: dict[str, int] = Field(
        ...,
        min_length=1,
        description="Logical outlet name -> GPIO line number mapping.",
    )
    active_high: bool = Field(
        True,
        description="If true, logical ON drives the GPIO high; if false, logical ON drives it low.",
    )
    initial_state: bool | None = Field(
        None,
        description="Optional state applied on controller start. Omit to leave the line unchanged.",
    )
    on_settle_ms: int = Field(1000, ge=0, description="Delay after turning power on.")
    off_settle_ms: int = Field(250, ge=0, description="Delay after turning power off.")


class ResourceDriverHttpRelay(ResourceDriverBase):
    """Power control through simple HTTP relay/lab-controller endpoints.

    The URL templates may contain {outlet}, {channel}, {state}, and {value}.
    Example:
      on_url:  http://relay.local/relay/{channel}/on
      off_url: http://relay.local/relay/{channel}/off
    """
    type: Literal["http_relay"] = "http_relay"
    outlets: dict[str, str] = Field(
        ...,
        min_length=1,
        description="Logical outlet name -> backend channel/identifier mapping.",
    )
    on_url: str = Field(..., description="HTTP URL template used to turn an outlet on.")
    off_url: str = Field(..., description="HTTP URL template used to turn an outlet off.")
    get_url: str | None = Field(None, description="Optional HTTP URL template used to read outlet state.")
    method: Literal["GET", "POST", "PUT"] = Field("GET", description="HTTP method for on/off commands.")
    headers: dict[str, str] = Field(default_factory=dict, description="Optional static HTTP headers.")
    timeout_ms: int = Field(2000, gt=0, description="HTTP timeout in milliseconds.")
    on_values: list[str] = Field(
        default_factory=lambda: ["1", "true", "on", "closed", "enabled"],
        description="Response values interpreted as ON when get_url is used.",
    )
    off_values: list[str] = Field(
        default_factory=lambda: ["0", "false", "off", "open", "disabled"],
        description="Response values interpreted as OFF when get_url is used.",
    )
    on_settle_ms: int = Field(1000, ge=0, description="Delay after turning power on.")
    off_settle_ms: int = Field(250, ge=0, description="Delay after turning power off.")




class ResourceDriverMockMeasurement(ResourceDriverBase):
    """Deterministic measurement resource for demos, tests, and CI dry-runs."""
    type: Literal["mock_measurement"] = "mock_measurement"
    quantity: str = Field(
        "generic",
        description="Measured quantity, e.g. current, voltage, temperature, latency.",
    )
    value: float = Field(..., description="Measurement value returned by this mock resource.")
    unit: str | None = Field(None, description="Measurement unit, e.g. A, V, C, ms.")


class ResourceDriverHttpMeasurement(ResourceDriverBase):
    """Measurement resource backed by a simple HTTP lab-controller endpoint.

    This is useful for custom lab controllers and vendor adapters that can expose
    readings through a stable HTTP API while BenchCI keeps the suite syntax
    vendor-neutral.
    """
    type: Literal["http_measurement"] = "http_measurement"
    quantity: str = Field(
        "generic",
        description="Measured quantity, e.g. current, voltage, temperature, latency.",
    )
    url: str = Field(..., description="HTTP endpoint returning a number or JSON object with a value field.")
    unit: str | None = Field(None, description="Default unit if the response does not include one.")
    value_field: str = Field("value", description="JSON field containing the numeric measurement value.")
    unit_field: str | None = Field("unit", description="Optional JSON field containing the unit.")
    headers: dict[str, str] = Field(default_factory=dict, description="Optional static HTTP headers.")
    timeout_ms: int = Field(2000, gt=0, description="HTTP timeout in milliseconds.")


class ResourceDriverUsbRelaySerialBase(ResourceDriverBase):
    """Base config for vendor-specific USB relay modules controlled over serial.

    The public BenchCI action remains power_set/power_cycle; this driver only
    describes the low-level adapter that performs the command.
    """
    type: Literal["usb_relay_serial"] = "usb_relay_serial"
    vendor: str
    model: str
    port: str = Field(..., description="Serial device path for the relay module, e.g. /dev/ttyUSB0 or COM3.")
    baud: int = Field(9600, gt=0, description="Serial baud rate used by the relay module.")
    timeout_ms: int = Field(500, gt=0, description="Serial command timeout in milliseconds.")
    outlets: dict[str, str] = Field(
        default_factory=dict,
        min_length=1,
        description="Logical outlet name -> driver channel/identifier mapping.",
    )
    on_settle_ms: int = Field(1000, ge=0, description="Delay after turning power on.")
    off_settle_ms: int = Field(250, ge=0, description="Delay after turning power off.")



class ResourceDriverUsbRelaySerialCommandMap(ResourceDriverUsbRelaySerialBase):
    """Generic serial relay controlled by per-channel hex command maps.

    This gives BenchCI broad vendor coverage without hard-coding every cheap
    relay board in core. For production-quality support, a popular model can
    later be promoted into a named protocol class.
    """
    type: Literal["usb_relay_serial"] = "usb_relay_serial"
    vendor: Literal["generic"] = "generic"
    model: Literal["command_map"] = "command_map"
    on_commands: dict[str, str] = Field(
        ...,
        min_length=1,
        description="Driver channel -> hex command bytes for ON.",
    )
    off_commands: dict[str, str] = Field(
        ...,
        min_length=1,
        description="Driver channel -> hex command bytes for OFF.",
    )
    get_commands: dict[str, str] = Field(
        default_factory=dict,
        description="Optional driver channel -> hex command bytes for state readback.",
    )
    on_response_values: list[str] = Field(
        default_factory=lambda: ["1", "01", "on", "true"],
        description="Optional response values interpreted as ON for state readback.",
    )
    off_response_values: list[str] = Field(
        default_factory=lambda: ["0", "00", "off", "false"],
        description="Optional response values interpreted as OFF for state readback.",
    )

    @model_validator(mode="after")
    def _validate_commands_cover_outlets(self) -> "ResourceDriverUsbRelaySerialCommandMap":
        channels = set(self.outlets.values())
        missing_on = sorted(ch for ch in channels if ch not in self.on_commands)
        missing_off = sorted(ch for ch in channels if ch not in self.off_commands)
        problems: list[str] = []
        if missing_on:
            problems.append(f"missing on_commands for channels: {missing_on}")
        if missing_off:
            problems.append(f"missing off_commands for channels: {missing_off}")
        if problems:
            raise ValueError("Invalid command_map relay configuration: " + "; ".join(problems))
        return self


ResourceDriverConfig = Union[
    ResourceDriverScpi,
    ResourceDriverScpiMeasurement,
    ResourceDriverScpiPowerSupplyMeasurement,
    ResourceDriverGpio,
    ResourceDriverMockPower,
    ResourceDriverGpioPower,
    ResourceDriverHttpRelay,
    ResourceDriverMockMeasurement,
    ResourceDriverHttpMeasurement,
    ResourceDriverUsbRelaySerialCommandMap,
]


class ResourceConfig(BaseModel):
    """Shared bench-level resource.

    kind is intentionally high-level (for example: power_controller,
    relay_controller, power_supply). driver.type/model describe the actual
    hardware adapter behind that high-level resource.
    """
    kind: str = Field(..., description="Resource kind, e.g. power_supply, relay_controller, power_controller.")
    driver: ResourceDriverConfig

# =========================
# Node / Bench configuration
# =========================

class NodeConfig(BaseModel):
    """A named participant in the bench workflow.

    A node can be a DUT, helper MCU, simulator peer, gateway, etc.
    """
    kind: str = Field(..., description="Node kind, e.g. mcu, simulator, gateway.")
    role: str | None = Field(None, description="Optional semantic role, e.g. primary, helper.")
    flash: FlashConfig | None = Field(None, description="Optional flashing backend for this node.")
    reset: ResetConfig = Field(default_factory=ResetConfig, description="Reset configuration for this node.")
    transports: dict[str, TransportConfig] = Field(
        default_factory=dict,
        description="Named transports available on this node.",
    )
    gpio: dict[str, GpioConfig] = Field(
        default_factory=dict,
        description="Optional named GPIO lines available on this node.",
    )
    tags: list[str] = Field(default_factory=list, description="Optional node tags.")

    @model_validator(mode="after")
    def _validate_unique_content(self) -> "NodeConfig":
        if self.flash is None and not self.transports and not self.gpio:
            raise ValueError(
                "node must define at least one of: flash, transports, gpio"
            )
        return self


class BenchConfig(BaseModel):
    """Top-level bench configuration.

    This describes the whole bench: named nodes, their flashing/reset behavior,
    transports, GPIO, optional shared resources, and artifact settings.
    """
    version: str = Field(..., description="Bench config schema version.")
    bench: BenchMeta = Field(..., description="Bench metadata.")
    defaults: BenchDefaults | None = Field(None, description="Optional bench defaults.")
    nodes: dict[str, NodeConfig] = Field(
        ...,
        min_length=1,
        description="Named nodes available in this bench.",
    )
    resources: dict[str, ResourceConfig] = Field(
        default_factory=dict,
        description="Optional shared bench-level resources.",
    )
    artifacts: ArtifactConfig = Field(
        default_factory=ArtifactConfig,
        description="Artifact output configuration.",
    )

    @model_validator(mode="after")
    def _validate_defaults(self) -> "BenchConfig":
        if self.defaults and self.defaults.node:
            if self.defaults.node not in self.nodes:
                raise ValueError(
                    f"defaults.node='{self.defaults.node}' does not exist in nodes"
                )
        return self


def get_bench_warnings(cfg: BenchConfig) -> list[str]:
    """Return non-fatal warnings about potentially confusing combinations."""
    warns: list[str] = []

    for node_name, node_cfg in cfg.nodes.items():
        flash_backend = getattr(node_cfg.flash, "backend", None) if node_cfg.flash else None
        reset_method = getattr(node_cfg.reset, "method", "none")

        if (
            reset_method in ("openocd", "cubeprog", "jlink", "esptool")
            and flash_backend
            and reset_method != flash_backend
        ):
            if flash_backend == "cubeprog" and reset_method == "openocd":
                warns.append(
                    f"Node '{node_name}': CubeProgrammer flashing selected, but reset uses OpenOCD. "
                    "Ensure both tools are installed or align reset.method with flash.backend."
                )
            elif flash_backend == "openocd" and reset_method == "cubeprog":
                warns.append(
                    f"Node '{node_name}': OpenOCD flashing selected, but reset uses STM32_Programmer_CLI. "
                    "Ensure both tools are installed or align reset.method with flash.backend."
                )
            elif flash_backend == "jlink" and reset_method != "jlink":
                warns.append(
                    f"Node '{node_name}': J-Link flashing selected, but reset uses a different backend. "
                    "Ensure the selected reset tool is installed and intended."
                )
            elif flash_backend == "esptool" and reset_method != "esptool":
                warns.append(
                    f"Node '{node_name}': esptool flashing selected, but reset uses a different backend. "
                    "Ensure the selected reset method is intentional."
                )
            else:
                warns.append(
                    f"Node '{node_name}': reset.method is '{reset_method}' but flash.backend is '{flash_backend}'. "
                    "Ensure the required tool is installed on the bench machine."
                )

        for line_name, gpio_cfg in node_cfg.gpio.items():
            if gpio_cfg.direction == "output":
                if gpio_cfg.bias is not None:
                    warns.append(
                        f"Node '{node_name}', GPIO line '{line_name}' is configured as output but also defines "
                        f"bias='{gpio_cfg.bias}'. Bias is typically only relevant for input lines."
                    )
                if gpio_cfg.edge is not None:
                    warns.append(
                        f"Node '{node_name}', GPIO line '{line_name}' is configured as output but also defines "
                        f"edge='{gpio_cfg.edge}'. Edge detection is only relevant for input lines."
                    )

            if getattr(gpio_cfg, "backend", None) == "remote_gpio":
                token_env = getattr(gpio_cfg, "token_env", "")
                if not token_env.strip():
                    warns.append(
                        f"Node '{node_name}', GPIO line '{line_name}' uses remote_gpio but token_env is empty."
                    )

    for resource_name, resource_cfg in cfg.resources.items():
        driver = resource_cfg.driver
        driver_type = getattr(driver, "type", "")
        if driver_type.endswith("_power") or driver_type in {"http_relay", "usb_relay_serial"}:
            if resource_cfg.kind not in {"power_controller", "relay_controller", "power_supply"}:
                warns.append(
                    f"Resource '{resource_name}' uses power-capable driver '{driver_type}' but kind is "
                    f"'{resource_cfg.kind}'. Consider kind: power_controller."
                )
        if driver_type.endswith("_measurement"):
            if resource_cfg.kind not in {"measurement", "meter", "instrument"}:
                warns.append(
                    f"Resource '{resource_name}' uses measurement driver '{driver_type}' but kind is "
                    f"'{resource_cfg.kind}'. Consider kind: measurement."
                )

    return warns


def load_bench_config(path: str | Path) -> BenchConfig:
    """Load and validate a bench YAML file."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    return BenchConfig.model_validate(data)