from __future__ import annotations

from typing import Any

import httpx


def _normalize_base_url(api_base_url: str) -> str:
    return api_base_url.rstrip("/")


def _headers(access_token: str | None = None, workspace_id: str | None = None) -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if access_token:
        headers["Authorization"] = f"Bearer {access_token}"
    if workspace_id:
        headers["X-BenchCI-Workspace"] = workspace_id
    return headers


def _extract_error_detail(response: httpx.Response) -> str | None:
    try:
        body = response.json()
        detail = body.get("detail")
        if isinstance(detail, str) and detail.strip():
            return detail.strip()
        if isinstance(detail, list):
            return "Request validation failed. Please check your input."
    except Exception:
        pass
    return None


def _raise_http_error_with_context(exc: httpx.HTTPStatusError) -> None:
    status = exc.response.status_code
    detail = _extract_error_detail(exc.response)

    if detail:
        raise RuntimeError(detail)

    if status == 400:
        raise RuntimeError("Request was invalid. Please check your input.")
    if status == 401:
        raise RuntimeError("Authentication failed. Please run 'benchci login' again.")
    if status == 403:
        raise RuntimeError("You do not have permission to perform this action.")
    if status == 404:
        raise RuntimeError("Requested resource was not found.")
    if status == 409:
        raise RuntimeError("This action conflicts with the current BenchCI state.")
    if status == 422:
        raise RuntimeError("Request validation failed. Please check your input.")
    if status == 429:
        raise RuntimeError("Too many requests. Please try again shortly.")
    if status >= 500:
        raise RuntimeError("BenchCI service is temporarily unavailable. Please try again later.")

    raise RuntimeError(f"Request failed with HTTP {status}.")


def _request_json(
    method: str,
    url: str,
    *,
    headers: dict[str, str] | None = None,
    json: dict[str, Any] | None = None,
) -> dict[str, Any]:
    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.request(method, url, headers=headers, json=json)
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc)
    except httpx.TimeoutException:
        raise RuntimeError("BenchCI service did not respond in time. Please try again.")
    except httpx.NetworkError:
        raise RuntimeError("Could not connect to BenchCI service. Please check your internet connection.")
    except httpx.HTTPError:
        raise RuntimeError("BenchCI request failed. Please try again.")
    except ValueError:
        raise RuntimeError("BenchCI service returned an unreadable response. Please try again.")


def register_user(
    *,
    api_base_url: str,
    email: str,
    password: str,
    workspace_name: str,
    display_name: str | None = None,
) -> dict[str, Any]:
    base = _normalize_base_url(api_base_url)
    return _request_json(
        "POST",
        f"{base}/v1/auth/register",
        headers=_headers(),
        json={
            "email": email,
            "password": password,
            "workspace_name": workspace_name,
            "display_name": display_name,
        },
    )


def login_user(
    *,
    api_base_url: str,
    email: str,
    password: str,
    machine_id: str,
    machine_name: str | None = None,
    workspace_id: str | None = None,
    is_ci: bool = False,
) -> dict[str, Any]:
    base = _normalize_base_url(api_base_url)
    return _request_json(
        "POST",
        f"{base}/v1/auth/cli/login",
        headers=_headers(),
        json={
            "email": email,
            "password": password,
            "machine_id": machine_id,
            "machine_name": machine_name,
            "workspace_id": workspace_id,
            "is_ci": is_ci, 
        },
    )


def refresh_user_session(
    *,
    api_base_url: str,
    refresh_token: str,
    machine_id: str,
) -> dict[str, Any]:
    base = _normalize_base_url(api_base_url)
    return _request_json(
        "POST",
        f"{base}/v1/auth/cli/refresh",
        headers=_headers(),
        json={"refresh_token": refresh_token, "machine_id": machine_id},
    )


def logout_user(
    *,
    api_base_url: str,
    refresh_token: str,
    machine_id: str,
) -> dict[str, Any]:
    base = _normalize_base_url(api_base_url)
    return _request_json(
        "POST",
        f"{base}/v1/auth/cli/logout",
        headers=_headers(),
        json={"refresh_token": refresh_token, "machine_id": machine_id},
    )


def get_me(*, api_base_url: str, access_token: str, workspace_id: str | None = None) -> dict[str, Any]:
    base = _normalize_base_url(api_base_url)
    return _request_json(
        "GET",
        f"{base}/v1/auth/me",
        headers=_headers(access_token, workspace_id),
    )


def list_workspaces(*, api_base_url: str, access_token: str) -> dict[str, Any]:
    base = _normalize_base_url(api_base_url)
    return _request_json(
        "GET",
        f"{base}/v1/auth/workspaces",
        headers=_headers(access_token),
    )