from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import typer
from pydantic import ValidationError

from benchci.config.bench import BenchConfig, get_bench_warnings, load_bench_config
from benchci.config.suite import SuiteConfig, load_suite_config
from benchci.diagnostics.schema import DiagnosticCheck, derive_health_status, summarize_health


VALIDATE_SCHEMA_VERSION = "benchci.validate.v1"

POWER_DRIVER_TYPES = {
    "mock_power",
    "gpio_power",
    "http_relay",
    "usb_relay_serial",
}

MEASUREMENT_DRIVER_TYPES = {
    "mock_measurement",
    "http_measurement",
    "scpi_measurement",
    "scpi_power_supply_measurement",
}

TRANSPORT_BACKENDS_BY_ACTION = {
    "send_uart": {"uart"},
    "expect_uart": {"uart"},
    "modbus_read_holding_registers": {"modbus_rtu", "modbus_tcp"},
    "modbus_write_single_register": {"modbus_rtu", "modbus_tcp"},
    "modbus_read_coils": {"modbus_rtu", "modbus_tcp"},
    "modbus_write_single_coil": {"modbus_rtu", "modbus_tcp"},
    "send_can": {"can"},
    "expect_can": {"can"},
}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


@dataclass
class ValidationReport:
    checked_at: str
    bench_path: str | None
    suite_path: str | None
    checks: list[DiagnosticCheck]
    bench_name: str | None = None
    suite_name: str | None = None
    schema_version: str = VALIDATE_SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        checks = [c.to_dict() for c in self.checks]
        passed = sum(1 for c in self.checks if c.status == "pass")
        warnings = sum(1 for c in self.checks if c.status == "warn")
        failed = sum(1 for c in self.checks if c.status == "fail")
        skipped = sum(1 for c in self.checks if c.status == "skip")
        health_status = derive_health_status(self.checks)

        return {
            "schema_version": self.schema_version,
            "tool": "benchci",
            "command": "validate",
            "checked_at": self.checked_at,
            "bench": {
                "name": self.bench_name,
                "path": self.bench_path,
            } if self.bench_path else None,
            "suite": {
                "name": self.suite_name,
                "path": self.suite_path,
            } if self.suite_path else None,
            "status": "valid" if health_status in {"healthy", "degraded"} else "invalid",
            "health_status": health_status,
            "summary": summarize_health(health_status, self.checks).replace("Bench", "Configuration"),
            "counts": {
                "passed": passed,
                "warnings": warnings,
                "failed": failed,
                "skipped": skipped,
                "total": len(self.checks),
            },
            "checks": checks,
        }


def _check_id(prefix: str, *parts: object) -> str:
    raw = ".".join(str(p) for p in (prefix, *parts) if p is not None and str(p) != "")
    return raw.replace(" ", "_")


def _driver_type(resource_cfg: Any) -> str | None:
    driver = getattr(resource_cfg, "driver", None)
    return getattr(driver, "type", None)


def _resource_outlets(resource_cfg: Any) -> dict[str, Any]:
    driver = getattr(resource_cfg, "driver", None)
    outlets = getattr(driver, "outlets", None)
    return dict(outlets or {})


def _step_type(step: Any) -> str:
    # Keep this list aligned with benchci.config.suite.StepModel.
    names = [
        "sleep_ms",
        "flash",
        "reset",
        "send_uart",
        "expect_uart",
        "modbus_read_holding_registers",
        "modbus_write_single_register",
        "modbus_read_coils",
        "modbus_write_single_coil",
        "gpio_set",
        "gpio_get",
        "gpio_expect",
        "gpio_wait_edge",
        "power_set",
        "power_cycle",
        "power_expect",
        "measure",
        "assert_metric",
        "send_can",
        "expect_can",
    ]
    for name in names:
        if hasattr(step, name):
            return name
    return type(step).__name__


def _node_name_for_step(step: Any) -> str | None:
    action = _step_type(step)
    payload = getattr(step, action, None)
    return getattr(payload, "node", None)


def _transport_name_for_step(step: Any) -> str | None:
    action = _step_type(step)
    payload = getattr(step, action, None)
    return getattr(payload, "transport", None)


def _resolve_node_name(bench: BenchConfig, explicit_node: str | None) -> tuple[str | None, DiagnosticCheck | None]:
    if explicit_node:
        if explicit_node in bench.nodes:
            return explicit_node, None
        known = ", ".join(sorted(bench.nodes.keys())) or "<none>"
        return None, DiagnosticCheck(
            id="suite.node.unknown",
            title="Unknown node reference",
            status="fail",
            severity="critical",
            category="CONFIG_ERROR",
            source="configuration",
            message=f"Suite references unknown node '{explicit_node}'. Known nodes: {known}.",
            suggested_fix="Update the suite step node name or add the node to bench.yaml.",
            required=True,
            details={"node": explicit_node, "known_nodes": sorted(bench.nodes.keys())},
        )

    default_node = bench.defaults.node if bench.defaults else None
    if default_node and default_node in bench.nodes:
        return default_node, None

    return None, DiagnosticCheck(
        id="suite.node.default_missing",
        title="Missing node reference",
        status="fail",
        severity="critical",
        category="CONFIG_ERROR",
        source="configuration",
        message="Suite step does not define a node and bench.defaults.node is not set.",
        suggested_fix="Set the step node explicitly or define defaults.node in bench.yaml.",
        required=True,
    )


def _check_load_bench(bench_path: str | Path) -> tuple[BenchConfig | None, list[DiagnosticCheck]]:
    path = Path(bench_path).expanduser().resolve()
    checks: list[DiagnosticCheck] = []
    try:
        bench = load_bench_config(path)
        checks.append(
            DiagnosticCheck(
                id="bench_yaml_loaded",
                title="bench.yaml loaded",
                status="pass",
                severity="info",
                source="configuration",
                message=f"Loaded bench '{bench.bench.name}'.",
                required=True,
                details={
                    "path": str(path),
                    "bench_name": bench.bench.name,
                    "node_count": len(bench.nodes),
                    "resource_count": len(bench.resources),
                },
            )
        )
        return bench, checks
    except FileNotFoundError:
        checks.append(
            DiagnosticCheck(
                id="bench_yaml_exists",
                title="bench.yaml exists",
                status="fail",
                severity="critical",
                category="CONFIG_ERROR",
                source="configuration",
                message=f"Bench config file does not exist: {path}",
                suggested_fix="Pass a valid bench.yaml path with --bench.",
                required=True,
            )
        )
    except ValidationError as exc:
        checks.append(
            DiagnosticCheck(
                id="bench_yaml_valid",
                title="bench.yaml schema validation",
                status="fail",
                severity="critical",
                category="CONFIG_ERROR",
                source="configuration",
                message="bench.yaml failed schema validation.",
                suggested_fix="Fix the Pydantic/YAML validation error and retry.",
                required=True,
                details={"error": str(exc)},
            )
        )
    except Exception as exc:
        checks.append(
            DiagnosticCheck(
                id="bench_yaml_load",
                title="bench.yaml load",
                status="fail",
                severity="critical",
                category="CONFIG_ERROR",
                source="configuration",
                message=f"Could not load bench.yaml: {exc}",
                suggested_fix="Check YAML syntax and file permissions.",
                required=True,
                details={"error_type": type(exc).__name__},
            )
        )
    return None, checks


def _check_load_suite(suite_path: str | Path) -> tuple[SuiteConfig | None, list[DiagnosticCheck]]:
    path = Path(suite_path).expanduser().resolve()
    checks: list[DiagnosticCheck] = []
    try:
        suite = load_suite_config(path)
        step_count = sum(len(test.steps) for test in suite.tests)
        checks.append(
            DiagnosticCheck(
                id="suite_yaml_loaded",
                title="suite.yaml loaded",
                status="pass",
                severity="info",
                source="configuration",
                message=f"Loaded suite '{suite.suite.name}'.",
                required=True,
                details={
                    "path": str(path),
                    "suite_name": suite.suite.name,
                    "test_count": len(suite.tests),
                    "step_count": step_count,
                },
            )
        )
        if not suite.tests:
            checks.append(
                DiagnosticCheck(
                    id="suite.tests.empty",
                    title="Suite has no tests",
                    status="warn",
                    severity="warning",
                    category="CONFIG_WARNING",
                    source="configuration",
                    message="suite.yaml loaded, but it does not define any tests.",
                    suggested_fix="Add at least one test case before using this suite in CI.",
                    required=False,
                )
            )
        return suite, checks
    except FileNotFoundError:
        checks.append(
            DiagnosticCheck(
                id="suite_yaml_exists",
                title="suite.yaml exists",
                status="fail",
                severity="critical",
                category="CONFIG_ERROR",
                source="configuration",
                message=f"Suite config file does not exist: {path}",
                suggested_fix="Pass a valid suite.yaml path with --suite.",
                required=True,
            )
        )
    except ValidationError as exc:
        checks.append(
            DiagnosticCheck(
                id="suite_yaml_valid",
                title="suite.yaml schema validation",
                status="fail",
                severity="critical",
                category="CONFIG_ERROR",
                source="configuration",
                message="suite.yaml failed schema validation.",
                suggested_fix="Fix the Pydantic/YAML validation error and retry.",
                required=True,
                details={"error": str(exc)},
            )
        )
    except Exception as exc:
        checks.append(
            DiagnosticCheck(
                id="suite_yaml_load",
                title="suite.yaml load",
                status="fail",
                severity="critical",
                category="CONFIG_ERROR",
                source="configuration",
                message=f"Could not load suite.yaml: {exc}",
                suggested_fix="Check YAML syntax and file permissions.",
                required=True,
                details={"error_type": type(exc).__name__},
            )
        )
    return None, checks


def _bench_summary_checks(bench: BenchConfig) -> list[DiagnosticCheck]:
    checks: list[DiagnosticCheck] = []

    default_node = bench.defaults.node if bench.defaults else None
    if default_node:
        checks.append(
            DiagnosticCheck(
                id="bench.defaults.node",
                title="Default node",
                status="pass",
                severity="info",
                source="configuration",
                message=f"Default node is '{default_node}'.",
                required=False,
                details={"default_node": default_node},
            )
        )
    else:
        checks.append(
            DiagnosticCheck(
                id="bench.defaults.node",
                title="Default node",
                status="warn",
                severity="warning",
                category="CONFIG_WARNING",
                source="configuration",
                message="bench.defaults.node is not set.",
                suggested_fix="Set defaults.node if most suite steps target the same node.",
                required=False,
            )
        )

    for node_name, node_cfg in bench.nodes.items():
        checks.append(
            DiagnosticCheck(
                id=_check_id("bench.node", node_name),
                title=f"Node '{node_name}'",
                status="pass",
                severity="info",
                source="configuration",
                message=(
                    f"kind={node_cfg.kind}, transports={len(node_cfg.transports)}, "
                    f"gpio={len(node_cfg.gpio)}, flash={'yes' if node_cfg.flash else 'no'}"
                ),
                required=True,
                details={
                    "node": node_name,
                    "kind": node_cfg.kind,
                    "transport_names": sorted(node_cfg.transports.keys()),
                    "gpio_lines": sorted(node_cfg.gpio.keys()),
                    "has_flash": node_cfg.flash is not None,
                },
            )
        )

    for idx, warning in enumerate(get_bench_warnings(bench), start=1):
        checks.append(
            DiagnosticCheck(
                id=f"bench.warning.{idx}",
                title="Bench configuration warning",
                status="warn",
                severity="warning",
                category="CONFIG_WARNING",
                source="configuration",
                message=warning,
                suggested_fix="Review bench.yaml and align the configuration with the intended hardware setup.",
                required=False,
            )
        )

    return checks


def _suite_summary_checks(suite: SuiteConfig) -> list[DiagnosticCheck]:
    step_count = sum(len(test.steps) for test in suite.tests)
    action_counts: dict[str, int] = {}
    for test in suite.tests:
        for step in test.steps:
            action = _step_type(step)
            action_counts[action] = action_counts.get(action, 0) + 1

    return [
        DiagnosticCheck(
            id="suite.summary",
            title="Suite summary",
            status="pass",
            severity="info",
            source="configuration",
            message=f"Suite has {len(suite.tests)} test(s) and {step_count} step(s).",
            required=True,
            details={
                "test_count": len(suite.tests),
                "step_count": step_count,
                "action_counts": dict(sorted(action_counts.items())),
            },
        )
    ]


def _check_transport_reference(
    bench: BenchConfig,
    *,
    test_name: str,
    test_index: int,
    step_index: int,
    action: str,
    node_name: str,
    transport_name: str,
) -> DiagnosticCheck:
    node_cfg = bench.nodes[node_name]
    cfg = node_cfg.transports.get(transport_name)
    if cfg is None:
        known = ", ".join(sorted(node_cfg.transports.keys())) or "<none>"
        return DiagnosticCheck(
            id=_check_id("suite.step", test_index, step_index, "transport"),
            title="Unknown transport reference",
            status="fail",
            severity="critical",
            category="CONFIG_ERROR",
            source="configuration",
            message=(
                f"Test '{test_name}' step {step_index + 1} uses {action} on "
                f"'{node_name}.{transport_name}', but that node defines transports: {known}."
            ),
            suggested_fix="Update the suite transport name or add the transport to the node in bench.yaml.",
            required=True,
            details={
                "test": test_name,
                "test_index": test_index,
                "step_index": step_index,
                "action": action,
                "node": node_name,
                "transport": transport_name,
                "known_transports": sorted(node_cfg.transports.keys()),
            },
        )

    allowed = TRANSPORT_BACKENDS_BY_ACTION[action]
    if cfg.backend not in allowed:
        return DiagnosticCheck(
            id=_check_id("suite.step", test_index, step_index, "transport_backend"),
            title="Transport backend mismatch",
            status="fail",
            severity="critical",
            category="CONFIG_ERROR",
            source="configuration",
            message=(
                f"Test '{test_name}' step {step_index + 1} uses {action} on "
                f"'{node_name}.{transport_name}', but backend is '{cfg.backend}', expected one of {sorted(allowed)}."
            ),
            suggested_fix="Use a transport backend compatible with the suite action or change the suite action.",
            required=True,
            details={
                "test": test_name,
                "step_index": step_index,
                "action": action,
                "node": node_name,
                "transport": transport_name,
                "backend": cfg.backend,
                "expected_backends": sorted(allowed),
            },
        )

    return DiagnosticCheck(
        id=_check_id("suite.step", test_index, step_index, "transport"),
        title="Transport reference",
        status="pass",
        severity="info",
        source="configuration",
        message=f"{action} uses '{node_name}.{transport_name}' with backend '{cfg.backend}'.",
        required=True,
        details={
            "test": test_name,
            "step_index": step_index,
            "action": action,
            "node": node_name,
            "transport": transport_name,
            "backend": cfg.backend,
        },
    )


def _check_gpio_reference(
    bench: BenchConfig,
    *,
    test_name: str,
    test_index: int,
    step_index: int,
    action: str,
    node_name: str,
    line_name: str,
) -> DiagnosticCheck:
    node_cfg = bench.nodes[node_name]
    line_cfg = node_cfg.gpio.get(line_name)
    if line_cfg is None:
        known = ", ".join(sorted(node_cfg.gpio.keys())) or "<none>"
        return DiagnosticCheck(
            id=_check_id("suite.step", test_index, step_index, "gpio"),
            title="Unknown GPIO line reference",
            status="fail",
            severity="critical",
            category="CONFIG_ERROR",
            source="configuration",
            message=(
                f"Test '{test_name}' step {step_index + 1} uses {action} on line '{line_name}' "
                f"for node '{node_name}', but that node defines lines: {known}."
            ),
            suggested_fix="Update the GPIO line name in suite.yaml or add it under node.gpio in bench.yaml.",
            required=True,
            details={
                "test": test_name,
                "step_index": step_index,
                "action": action,
                "node": node_name,
                "line": line_name,
                "known_lines": sorted(node_cfg.gpio.keys()),
            },
        )

    required_direction = "output" if action == "gpio_set" else "input"
    direction = getattr(line_cfg, "direction", None)
    if direction != required_direction:
        return DiagnosticCheck(
            id=_check_id("suite.step", test_index, step_index, "gpio_direction"),
            title="GPIO direction mismatch",
            status="fail",
            severity="critical",
            category="CONFIG_ERROR",
            source="configuration",
            message=(
                f"Test '{test_name}' step {step_index + 1} uses {action} on "
                f"'{node_name}.{line_name}', but the line is configured as '{direction}', expected '{required_direction}'."
            ),
            suggested_fix="Change the GPIO line direction in bench.yaml or use an action compatible with the direction.",
            required=True,
            details={
                "test": test_name,
                "step_index": step_index,
                "action": action,
                "node": node_name,
                "line": line_name,
                "direction": direction,
                "expected_direction": required_direction,
            },
        )

    return DiagnosticCheck(
        id=_check_id("suite.step", test_index, step_index, "gpio"),
        title="GPIO reference",
        status="pass",
        severity="info",
        source="configuration",
        message=f"{action} uses GPIO line '{node_name}.{line_name}' as {direction}.",
        required=True,
        details={
            "test": test_name,
            "step_index": step_index,
            "action": action,
            "node": node_name,
            "line": line_name,
            "direction": direction,
        },
    )


def _check_power_reference(
    bench: BenchConfig,
    *,
    test_name: str,
    test_index: int,
    step_index: int,
    action: str,
    resource_name: str,
    outlet_name: str,
) -> list[DiagnosticCheck]:
    checks: list[DiagnosticCheck] = []
    resource = bench.resources.get(resource_name)
    if resource is None:
        known = ", ".join(sorted(bench.resources.keys())) or "<none>"
        return [
            DiagnosticCheck(
                id=_check_id("suite.step", test_index, step_index, "power_resource"),
                title="Unknown power resource reference",
                status="fail",
                severity="critical",
                category="CONFIG_ERROR",
                source="configuration",
                message=(
                    f"Test '{test_name}' step {step_index + 1} uses {action} on resource '{resource_name}', "
                    f"but bench.resources defines: {known}."
                ),
                suggested_fix="Update the power resource name in suite.yaml or add it under resources in bench.yaml.",
                required=True,
                details={
                    "test": test_name,
                    "step_index": step_index,
                    "action": action,
                    "resource": resource_name,
                    "known_resources": sorted(bench.resources.keys()),
                },
            )
        ]

    driver_type = _driver_type(resource)
    if driver_type not in POWER_DRIVER_TYPES:
        return [
            DiagnosticCheck(
                id=_check_id("suite.step", test_index, step_index, "power_driver"),
                title="Power resource driver mismatch",
                status="fail",
                severity="critical",
                category="CONFIG_ERROR",
                source="configuration",
                message=(
                    f"Test '{test_name}' step {step_index + 1} uses {action} on resource '{resource_name}', "
                    f"but driver type is '{driver_type}', expected a power-capable driver."
                ),
                suggested_fix="Use a power driver such as mock_power, gpio_power, http_relay, or usb_relay_serial.",
                required=True,
                details={
                    "test": test_name,
                    "step_index": step_index,
                    "action": action,
                    "resource": resource_name,
                    "driver_type": driver_type,
                    "expected_driver_types": sorted(POWER_DRIVER_TYPES),
                },
            )
        ]

    outlets = _resource_outlets(resource)
    if outlet_name not in outlets:
        known = ", ".join(sorted(outlets.keys())) or "<none>"
        return [
            DiagnosticCheck(
                id=_check_id("suite.step", test_index, step_index, "power_outlet"),
                title="Unknown power outlet reference",
                status="fail",
                severity="critical",
                category="CONFIG_ERROR",
                source="configuration",
                message=(
                    f"Test '{test_name}' step {step_index + 1} uses outlet '{outlet_name}' on resource '{resource_name}', "
                    f"but that resource defines outlets: {known}."
                ),
                suggested_fix="Update the outlet name in suite.yaml or add it to the resource driver outlets in bench.yaml.",
                required=True,
                details={
                    "test": test_name,
                    "step_index": step_index,
                    "action": action,
                    "resource": resource_name,
                    "outlet": outlet_name,
                    "known_outlets": sorted(outlets.keys()),
                },
            )
        ]

    checks.append(
        DiagnosticCheck(
            id=_check_id("suite.step", test_index, step_index, "power"),
            title="Power reference",
            status="pass",
            severity="info",
            source="configuration",
            message=f"{action} uses resource '{resource_name}' outlet '{outlet_name}' with driver '{driver_type}'.",
            required=True,
            details={
                "test": test_name,
                "step_index": step_index,
                "action": action,
                "resource": resource_name,
                "outlet": outlet_name,
                "driver_type": driver_type,
            },
        )
    )

    if action == "power_expect":
        driver = getattr(resource, "driver", None)
        if driver_type == "http_relay" and not getattr(driver, "get_url", None):
            checks.append(
                DiagnosticCheck(
                    id=_check_id("suite.step", test_index, step_index, "power_readback"),
                    title="Power readback may be unavailable",
                    status="warn",
                    severity="warning",
                    category="POWER_READBACK_UNAVAILABLE",
                    source="bench_infrastructure",
                    message=(
                        f"power_expect uses HTTP relay resource '{resource_name}', but get_url is not configured. "
                        "Readback may fall back to tracked state only."
                    ),
                    suggested_fix="Configure get_url for reliable power_expect checks, or avoid power_expect with this backend.",
                    required=False,
                    details={"resource": resource_name, "driver_type": driver_type},
                )
            )
        if driver_type == "usb_relay_serial":
            channel = outlets.get(outlet_name)
            get_commands = getattr(driver, "get_commands", {}) or {}
            if channel not in get_commands:
                checks.append(
                    DiagnosticCheck(
                        id=_check_id("suite.step", test_index, step_index, "power_readback"),
                        title="Power readback may be unavailable",
                        status="warn",
                        severity="warning",
                        category="POWER_READBACK_UNAVAILABLE",
                        source="bench_infrastructure",
                        message=(
                            f"power_expect uses USB relay resource '{resource_name}' outlet '{outlet_name}', "
                            f"but no get_command is configured for channel '{channel}'."
                        ),
                        suggested_fix="Add get_commands/readback response values or avoid power_expect with this outlet.",
                        required=False,
                        details={"resource": resource_name, "outlet": outlet_name, "channel": channel},
                    )
                )

    return checks


def _check_measurement_reference(
    bench: BenchConfig,
    *,
    test_name: str,
    test_index: int,
    step_index: int,
    resource_name: str,
) -> DiagnosticCheck:
    resource = bench.resources.get(resource_name)
    if resource is None:
        known = ", ".join(sorted(bench.resources.keys())) or "<none>"
        return DiagnosticCheck(
            id=_check_id("suite.step", test_index, step_index, "measurement_resource"),
            title="Unknown measurement resource reference",
            status="fail",
            severity="critical",
            category="CONFIG_ERROR",
            source="configuration",
            message=(
                f"Test '{test_name}' step {step_index + 1} uses measure on resource '{resource_name}', "
                f"but bench.resources defines: {known}."
            ),
            suggested_fix="Update the measurement resource name in suite.yaml or add it under resources in bench.yaml.",
            required=True,
            details={
                "test": test_name,
                "step_index": step_index,
                "resource": resource_name,
                "known_resources": sorted(bench.resources.keys()),
            },
        )

    driver_type = _driver_type(resource)
    if driver_type not in MEASUREMENT_DRIVER_TYPES:
        return DiagnosticCheck(
            id=_check_id("suite.step", test_index, step_index, "measurement_driver"),
            title="Measurement resource driver mismatch",
            status="fail",
            severity="critical",
            category="CONFIG_ERROR",
            source="configuration",
            message=(
                f"Test '{test_name}' step {step_index + 1} uses measure on resource '{resource_name}', "
                f"but driver type is '{driver_type}', expected a measurement-capable driver."
            ),
            suggested_fix="Use mock_measurement or http_measurement for measure steps.",
            required=True,
            details={
                "test": test_name,
                "step_index": step_index,
                "resource": resource_name,
                "driver_type": driver_type,
                "expected_driver_types": sorted(MEASUREMENT_DRIVER_TYPES),
            },
        )

    if getattr(resource, "kind", None) != "measurement":
        return DiagnosticCheck(
            id=_check_id("suite.step", test_index, step_index, "measurement_kind"),
            title="Measurement resource kind mismatch",
            status="fail",
            severity="critical",
            category="CONFIG_ERROR",
            source="configuration",
            message=(
                f"Test '{test_name}' step {step_index + 1} uses measure on resource '{resource_name}', "
                f"but resource kind is '{getattr(resource, 'kind', None)}', expected 'measurement'."
            ),
            suggested_fix="Set the resource kind to 'measurement' or update the runner validation policy.",
            required=True,
            details={
                "test": test_name,
                "step_index": step_index,
                "resource": resource_name,
                "kind": getattr(resource, "kind", None),
                "driver_type": driver_type,
            },
        )

    return DiagnosticCheck(
        id=_check_id("suite.step", test_index, step_index, "measurement"),
        title="Measurement reference",
        status="pass",
        severity="info",
        source="configuration",
        message=f"measure uses resource '{resource_name}' with driver '{driver_type}'.",
        required=True,
        details={
            "test": test_name,
            "step_index": step_index,
            "resource": resource_name,
            "driver_type": driver_type,
        },
    )


def _cross_validate_suite_against_bench(bench: BenchConfig, suite: SuiteConfig) -> list[DiagnosticCheck]:
    checks: list[DiagnosticCheck] = []

    for test_index, test in enumerate(suite.tests):
        recorded_metrics: set[str] = set()

        if not test.steps:
            checks.append(
                DiagnosticCheck(
                    id=_check_id("suite.test", test_index, "steps"),
                    title="Test has no steps",
                    status="warn",
                    severity="warning",
                    category="CONFIG_WARNING",
                    source="configuration",
                    message=f"Test '{test.name}' has no steps.",
                    suggested_fix="Add at least one step or remove the empty test.",
                    required=False,
                    details={"test": test.name, "test_index": test_index},
                )
            )
            continue

        for step_index, step in enumerate(test.steps):
            action = _step_type(step)
            if action == "sleep_ms":
                continue

            if action == "assert_metric":
                metric_name = step.assert_metric.name
                if metric_name not in recorded_metrics:
                    checks.append(
                        DiagnosticCheck(
                            id=_check_id("suite.step", test_index, step_index, "metric"),
                            title="Unknown metric reference",
                            status="fail",
                            severity="critical",
                            category="CONFIG_ERROR",
                            source="configuration",
                            message=(
                                f"Test '{test.name}' step {step_index + 1} asserts metric '{metric_name}', "
                                "but no earlier measure step records that metric in this test."
                            ),
                            suggested_fix="Add a measure step with record_as before assert_metric, or fix the metric name.",
                            required=True,
                            details={
                                "test": test.name,
                                "step_index": step_index,
                                "metric": metric_name,
                                "known_metrics": sorted(recorded_metrics),
                            },
                        )
                    )
                else:
                    checks.append(
                        DiagnosticCheck(
                            id=_check_id("suite.step", test_index, step_index, "metric"),
                            title="Metric reference",
                            status="pass",
                            severity="info",
                            source="configuration",
                            message=f"assert_metric references previously recorded metric '{metric_name}'.",
                            required=True,
                            details={"test": test.name, "step_index": step_index, "metric": metric_name},
                        )
                    )
                continue

            node_name = _node_name_for_step(step)
            transport_name = _transport_name_for_step(step)

            if action in {"flash", "reset", "send_uart", "expect_uart", "modbus_read_holding_registers", "modbus_write_single_register", "modbus_read_coils", "modbus_write_single_coil", "gpio_set", "gpio_get", "gpio_expect", "gpio_wait_edge", "send_can", "expect_can"}:
                resolved_node, node_error = _resolve_node_name(bench, node_name)
                if node_error is not None:
                    node_error.id = _check_id("suite.step", test_index, step_index, "node")
                    node_error.details.update({"test": test.name, "test_index": test_index, "step_index": step_index, "action": action})
                    checks.append(node_error)
                    continue
                assert resolved_node is not None

                if action == "flash":
                    node_cfg = bench.nodes[resolved_node]
                    if node_cfg.flash is None:
                        checks.append(
                            DiagnosticCheck(
                                id=_check_id("suite.step", test_index, step_index, "flash"),
                                title="Missing flash backend",
                                status="fail",
                                severity="critical",
                                category="CONFIG_ERROR",
                                source="configuration",
                                message=f"Test '{test.name}' step {step_index + 1} uses flash on node '{resolved_node}', but that node does not define a flash backend.",
                                suggested_fix="Add node.flash in bench.yaml or remove the flash step.",
                                required=True,
                                details={"test": test.name, "step_index": step_index, "node": resolved_node},
                            )
                        )
                    else:
                        artifact = step.flash.artifact or getattr(node_cfg.flash, "artifact", None)
                        checks.append(
                            DiagnosticCheck(
                                id=_check_id("suite.step", test_index, step_index, "flash"),
                                title="Flash reference",
                                status="pass" if artifact else "warn",
                                severity="info" if artifact else "warning",
                                category=None if artifact else "CONFIG_WARNING",
                                source="configuration",
                                message=(
                                    f"flash uses node '{resolved_node}' backend '{node_cfg.flash.backend}'."
                                    if artifact else
                                    f"flash uses node '{resolved_node}' backend '{node_cfg.flash.backend}', but no artifact is configured in the step or node. The run must provide --artifact."
                                ),
                                suggested_fix=None if artifact else "Pass --artifact at run time or set node.flash.artifact in bench.yaml.",
                                required=False if artifact else False,
                                details={
                                    "test": test.name,
                                    "step_index": step_index,
                                    "node": resolved_node,
                                    "backend": node_cfg.flash.backend,
                                    "artifact_source": "step" if step.flash.artifact else "node" if getattr(node_cfg.flash, "artifact", None) else None,
                                },
                            )
                        )
                    continue

                if action == "reset":
                    checks.append(
                        DiagnosticCheck(
                            id=_check_id("suite.step", test_index, step_index, "reset"),
                            title="Reset reference",
                            status="pass",
                            severity="info",
                            source="configuration",
                            message=f"reset uses node '{resolved_node}'.",
                            required=True,
                            details={"test": test.name, "step_index": step_index, "node": resolved_node},
                        )
                    )
                    continue

                if action in TRANSPORT_BACKENDS_BY_ACTION:
                    checks.append(
                        _check_transport_reference(
                            bench,
                            test_name=test.name,
                            test_index=test_index,
                            step_index=step_index,
                            action=action,
                            node_name=resolved_node,
                            transport_name=str(transport_name),
                        )
                    )
                    continue

                if action.startswith("gpio_"):
                    payload = getattr(step, action)
                    checks.append(
                        _check_gpio_reference(
                            bench,
                            test_name=test.name,
                            test_index=test_index,
                            step_index=step_index,
                            action=action,
                            node_name=resolved_node,
                            line_name=payload.line,
                        )
                    )
                    continue

            if action in {"power_set", "power_cycle", "power_expect"}:
                payload = getattr(step, action)
                checks.extend(
                    _check_power_reference(
                        bench,
                        test_name=test.name,
                        test_index=test_index,
                        step_index=step_index,
                        action=action,
                        resource_name=payload.resource,
                        outlet_name=payload.outlet,
                    )
                )
                continue

            if action == "measure":
                checks.append(
                    _check_measurement_reference(
                        bench,
                        test_name=test.name,
                        test_index=test_index,
                        step_index=step_index,
                        resource_name=step.measure.resource,
                    )
                )
                if step.measure.record_as:
                    recorded_metrics.add(step.measure.record_as)
                continue

            checks.append(
                DiagnosticCheck(
                    id=_check_id("suite.step", test_index, step_index, "unsupported"),
                    title="Unsupported step model",
                    status="fail",
                    severity="critical",
                    category="CONFIG_ERROR",
                    source="configuration",
                    message=f"Unsupported step model in suite parsing: {type(step).__name__}",
                    suggested_fix="Update BenchCI or remove the unsupported step.",
                    required=True,
                    details={"test": test.name, "step_index": step_index, "action": action},
                )
            )

    return checks


def build_validation_report(
    *,
    bench_path: str | Path | None = None,
    suite_path: str | Path | None = None,
) -> ValidationReport:
    checks: list[DiagnosticCheck] = []
    bench: BenchConfig | None = None
    suite: SuiteConfig | None = None

    if bench_path:
        bench, bench_checks = _check_load_bench(bench_path)
        checks.extend(bench_checks)
        if bench is not None:
            checks.extend(_bench_summary_checks(bench))

    if suite_path:
        suite, suite_checks = _check_load_suite(suite_path)
        checks.extend(suite_checks)
        if suite is not None:
            checks.extend(_suite_summary_checks(suite))

    if bench is not None and suite is not None:
        checks.extend(_cross_validate_suite_against_bench(bench, suite))
    elif suite is not None and bench is None:
        checks.append(
            DiagnosticCheck(
                id="cross_validation.skipped",
                title="Bench/suite cross-validation skipped",
                status="skip",
                severity="info",
                source="configuration",
                message="Only suite.yaml was provided, so node/transport/GPIO/resource references were not checked against a bench.",
                required=False,
            )
        )
    elif bench is not None and suite is None:
        checks.append(
            DiagnosticCheck(
                id="cross_validation.skipped",
                title="Bench/suite cross-validation skipped",
                status="skip",
                severity="info",
                source="configuration",
                message="Only bench.yaml was provided, so suite step references were not checked.",
                required=False,
            )
        )

    return ValidationReport(
        checked_at=_utc_now(),
        bench_path=str(Path(bench_path).expanduser().resolve()) if bench_path else None,
        suite_path=str(Path(suite_path).expanduser().resolve()) if suite_path else None,
        bench_name=bench.bench.name if bench else None,
        suite_name=suite.suite.name if suite else None,
        checks=checks,
    )


def render_human_report(report: ValidationReport) -> str:
    payload = report.to_dict()
    lines: list[str] = []
    lines.append("=" * 72)
    lines.append("BENCHCI VALIDATION")
    lines.append("=" * 72)
    if payload.get("bench"):
        bench = payload["bench"] or {}
        lines.append(f"Bench: {bench.get('name') or '—'}")
        lines.append(f"Bench path: {bench.get('path')}")
    if payload.get("suite"):
        suite = payload["suite"] or {}
        lines.append(f"Suite: {suite.get('name') or '—'}")
        lines.append(f"Suite path: {suite.get('path')}")
    lines.append(f"Status: {payload['status']}")
    lines.append(f"Health: {payload['health_status']}")
    lines.append(f"Summary: {payload['summary']}")
    lines.append("")

    for check in payload["checks"]:
        status = check["status"].upper()
        title = check["title"]
        message = check.get("message") or ""
        lines.append(f"[{status:4}] {title}")
        if message:
            lines.append(f"       {message}")
        if check.get("category"):
            lines.append(f"       category: {check['category']}")
        if check.get("suggested_fix"):
            lines.append(f"       suggested fix: {check['suggested_fix']}")
        lines.append("")

    counts = payload["counts"]
    lines.append(
        f"Summary: {counts['passed']} passed, "
        f"{counts['warnings']} warnings, "
        f"{counts['failed']} failed, "
        f"{counts['skipped']} skipped"
    )
    return "\n".join(lines)


def run_validate(
    *,
    bench_path: str | Path | None = None,
    suite_path: str | Path | None = None,
    output_path: str | Path | None = None,
    json_output: bool = False,
) -> int:
    report = build_validation_report(bench_path=bench_path, suite_path=suite_path)
    payload = report.to_dict()

    if output_path:
        out = Path(output_path).expanduser().resolve()
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    if json_output:
        typer.echo(json.dumps(payload, indent=2))
    else:
        typer.echo(render_human_report(report))
        if output_path:
            typer.echo("")
            typer.echo(f"[INFO] Validation JSON saved to: {Path(output_path).expanduser().resolve()}")

    return 0 if payload["status"] == "valid" else 1
