from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import typer

from benchci.config.bench import BenchConfig, load_bench_config
from benchci.config.suite import SuiteConfig, load_suite_config
from benchci.diagnostics.validate import build_validation_report


PLAN_SCHEMA_VERSION = "benchci.dry_run_plan.v1"

TRANSPORT_BACKENDS_BY_ACTION = {
    "send_uart": {"uart"},
    "expect_uart": {"uart"},
    "modbus_read_holding_registers": {"modbus_rtu", "modbus_tcp"},
    "modbus_write_single_register": {"modbus_rtu", "modbus_tcp"},
    "modbus_read_coils": {"modbus_rtu", "modbus_tcp"},
    "modbus_write_single_coil": {"modbus_rtu", "modbus_tcp"},
    "send_can": {"can"},
    "expect_can": {"can"},
}

POWER_DRIVER_TYPES = {
    "mock_power",
    "gpio_power",
    "http_relay",
    "usb_relay_serial",
}

MEASUREMENT_DRIVER_TYPES = {
    "mock_measurement",
    "http_measurement",
}


@dataclass
class PlannedStep:
    index: int
    test_name: str
    test_index: int
    step_index: int
    action: str
    summary: str
    skipped: bool = False
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "index": self.index,
            "test_name": self.test_name,
            "test_index": self.test_index,
            "step_index": self.step_index,
            "action": self.action,
            "summary": self.summary,
            "skipped": self.skipped,
            "details": self.details,
        }


@dataclass
class DryRunPlanReport:
    checked_at: str
    bench_path: str
    suite_path: str
    bench_name: str
    suite_name: str
    execution_mode: str
    skip_flash: bool
    artifact_override: str | None
    validation: dict[str, Any]
    steps: list[PlannedStep]
    resources: dict[str, Any]
    schema_version: str = PLAN_SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        step_dicts = [s.to_dict() for s in self.steps]
        skipped = sum(1 for s in self.steps if s.skipped)
        return {
            "schema_version": self.schema_version,
            "tool": "benchci",
            "command": "run --dry-run-plan",
            "checked_at": self.checked_at,
            "bench": {
                "name": self.bench_name,
                "path": self.bench_path,
            },
            "suite": {
                "name": self.suite_name,
                "path": self.suite_path,
            },
            "execution_mode": self.execution_mode,
            "run_options": {
                "skip_flash": self.skip_flash,
                "artifact_override": self.artifact_override,
            },
            "status": "ready" if self.validation.get("status") == "valid" else "invalid",
            "summary": {
                "step_count": len(self.steps),
                "skipped_step_count": skipped,
                "executable_step_count": len(self.steps) - skipped,
                "flash_enabled": not self.skip_flash,
            },
            "resources": self.resources,
            "validation": self.validation,
            "steps": step_dicts,
        }


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _driver_type(resource_cfg: Any) -> str | None:
    driver = getattr(resource_cfg, "driver", None)
    return getattr(driver, "type", None)


def _resource_outlets(resource_cfg: Any) -> dict[str, Any]:
    driver = getattr(resource_cfg, "driver", None)
    return dict(getattr(driver, "outlets", None) or {})


def _step_type(step: Any) -> str:
    names = [
        "sleep_ms",
        "flash",
        "reset",
        "send_uart",
        "expect_uart",
        "modbus_read_holding_registers",
        "modbus_write_single_register",
        "modbus_read_coils",
        "modbus_write_single_coil",
        "gpio_set",
        "gpio_get",
        "gpio_expect",
        "gpio_wait_edge",
        "power_set",
        "power_cycle",
        "power_expect",
        "measure",
        "assert_metric",
        "send_can",
        "expect_can",
    ]
    for name in names:
        if hasattr(step, name):
            return name
    return type(step).__name__


def _resolve_node_name(bench: BenchConfig, explicit_node: str | None) -> str:
    if explicit_node:
        if explicit_node in bench.nodes:
            return explicit_node
        return explicit_node

    default_node = bench.defaults.node if bench.defaults else None
    return default_node or "<missing>"


def _resolve_flash_artifact(
    *,
    cli_artifact: str | Path | None,
    node_cfg: Any,
    step_artifact_override: str | None,
) -> str | None:
    if step_artifact_override:
        return str(Path(step_artifact_override).expanduser())
    if cli_artifact is not None:
        return str(Path(cli_artifact).expanduser())
    if getattr(node_cfg, "flash", None) is not None:
        node_artifact = getattr(node_cfg.flash, "artifact", None)
        if node_artifact:
            return str(Path(node_artifact).expanduser())
    return None


def _transport_backend(bench: BenchConfig, node_name: str, transport_name: str | None) -> str | None:
    node_cfg = bench.nodes.get(node_name)
    if not node_cfg or not transport_name:
        return None
    transport_cfg = node_cfg.transports.get(transport_name)
    return getattr(transport_cfg, "backend", None) if transport_cfg else None


def _metric_assertions(payload: Any) -> dict[str, Any]:
    fields = [
        "expect_less_than",
        "expect_less_than_or_equal",
        "expect_greater_than",
        "expect_greater_than_or_equal",
        "expect_equal",
        "tolerance",
    ]
    data: dict[str, Any] = {}
    for field_name in fields:
        value = getattr(payload, field_name, None)
        if value is not None:
            data[field_name] = value
    return data


def _step_timeout_ms(bench: BenchConfig, payload: Any) -> int | None:
    explicit = getattr(payload, "within_ms", None)
    if explicit is not None:
        return explicit
    if bench.defaults and bench.defaults.timeouts:
        return bench.defaults.timeouts.within_ms
    return None


def _plan_step(
    *,
    bench: BenchConfig,
    test_name: str,
    test_index: int,
    step_index: int,
    global_index: int,
    step: Any,
    artifact_path: str | Path | None,
    skip_flash: bool,
) -> PlannedStep:
    action = _step_type(step)

    if action == "sleep_ms":
        duration_ms = getattr(step, "sleep_ms")
        return PlannedStep(
            index=global_index,
            test_name=test_name,
            test_index=test_index,
            step_index=step_index,
            action=action,
            summary=f"Sleep for {duration_ms} ms.",
            details={"duration_ms": duration_ms},
        )

    payload = getattr(step, action, None)

    if action == "flash":
        node_name = _resolve_node_name(bench, getattr(payload, "node", None))
        node_cfg = bench.nodes.get(node_name)
        flash_cfg = getattr(node_cfg, "flash", None) if node_cfg else None
        backend = getattr(flash_cfg, "backend", None) if flash_cfg else None
        artifact = _resolve_flash_artifact(
            cli_artifact=artifact_path,
            node_cfg=node_cfg,
            step_artifact_override=getattr(payload, "artifact", None),
        ) if node_cfg else None
        return PlannedStep(
            index=global_index,
            test_name=test_name,
            test_index=test_index,
            step_index=step_index,
            action=action,
            summary=(
                f"Flash node '{node_name}' with {backend or 'unknown backend'}"
                + (" (skipped by --skip-flash)." if skip_flash else ".")
            ),
            skipped=skip_flash,
            details={
                "node": node_name,
                "flash_backend": backend,
                "artifact": artifact,
                "artifact_source": (
                    "step" if getattr(payload, "artifact", None)
                    else "cli" if artifact_path
                    else "node_default" if artifact
                    else None
                ),
            },
        )

    if action == "reset":
        node_name = _resolve_node_name(bench, getattr(payload, "node", None))
        node_cfg = bench.nodes.get(node_name)
        method = getattr(getattr(node_cfg, "reset", None), "method", None) if node_cfg else None
        return PlannedStep(
            index=global_index,
            test_name=test_name,
            test_index=test_index,
            step_index=step_index,
            action=action,
            summary=f"Reset node '{node_name}' using method '{method or 'unknown'}'.",
            details={"node": node_name, "reset_method": method},
        )

    if action in TRANSPORT_BACKENDS_BY_ACTION:
        node_name = _resolve_node_name(bench, getattr(payload, "node", None))
        transport_name = getattr(payload, "transport", None)
        backend = _transport_backend(bench, node_name, transport_name)
        details: dict[str, Any] = {
            "node": node_name,
            "transport": transport_name,
            "transport_backend": backend,
        }
        timeout_ms = _step_timeout_ms(bench, payload)
        if timeout_ms is not None and action.startswith("expect"):
            details["timeout_ms"] = timeout_ms
        if action.startswith("modbus"):
            details.update({
                "slave": getattr(payload, "slave", None),
                "address": getattr(payload, "address", None),
            })
            if hasattr(payload, "count"):
                details["count"] = getattr(payload, "count")
        if action in {"send_can", "expect_can"}:
            frame = getattr(payload, "frame", None)
            if frame is not None:
                details["frame"] = {
                    "id": getattr(frame, "id", None),
                    "extended": getattr(frame, "extended", None),
                    "data": getattr(frame, "data", None),
                }
        return PlannedStep(
            index=global_index,
            test_name=test_name,
            test_index=test_index,
            step_index=step_index,
            action=action,
            summary=f"Use {backend or 'unknown'} transport '{transport_name}' on node '{node_name}'.",
            details=details,
        )

    if action in {"gpio_set", "gpio_get", "gpio_expect", "gpio_wait_edge"}:
        node_name = _resolve_node_name(bench, getattr(payload, "node", None))
        line_name = getattr(payload, "line", None)
        node_cfg = bench.nodes.get(node_name)
        line_cfg = node_cfg.gpio.get(line_name) if node_cfg and line_name else None
        details = {
            "node": node_name,
            "line": line_name,
            "line_direction": getattr(line_cfg, "direction", None),
            "line_backend": getattr(line_cfg, "backend", None),
        }
        if hasattr(payload, "value"):
            details["value"] = getattr(payload, "value")
        if hasattr(payload, "expect"):
            details["expect"] = getattr(payload, "expect")
        if hasattr(payload, "edge"):
            details["edge"] = getattr(payload, "edge")
        timeout_ms = _step_timeout_ms(bench, payload)
        if timeout_ms is not None:
            details["timeout_ms"] = timeout_ms
        return PlannedStep(
            index=global_index,
            test_name=test_name,
            test_index=test_index,
            step_index=step_index,
            action=action,
            summary=f"GPIO {action.replace('gpio_', '')} on line '{line_name}' of node '{node_name}'.",
            details=details,
        )

    if action in {"power_set", "power_cycle", "power_expect"}:
        resource_name = getattr(payload, "resource", None)
        outlet = getattr(payload, "outlet", None)
        resource_cfg = bench.resources.get(resource_name) if resource_name else None
        details = {
            "resource": resource_name,
            "outlet": outlet,
            "driver_type": _driver_type(resource_cfg) if resource_cfg else None,
        }
        if hasattr(payload, "state"):
            details["state"] = getattr(payload, "state")
        if hasattr(payload, "off_ms"):
            details["off_ms"] = getattr(payload, "off_ms")
        if hasattr(payload, "on_settle_ms"):
            details["on_settle_ms"] = getattr(payload, "on_settle_ms")
        return PlannedStep(
            index=global_index,
            test_name=test_name,
            test_index=test_index,
            step_index=step_index,
            action=action,
            summary=f"Power action '{action}' on {resource_name}.{outlet}.",
            details=details,
        )

    if action == "measure":
        resource_name = getattr(payload, "resource", None)
        resource_cfg = bench.resources.get(resource_name) if resource_name else None
        details = {
            "resource": resource_name,
            "driver_type": _driver_type(resource_cfg) if resource_cfg else None,
            "record_as": getattr(payload, "record_as", None),
            "unit": getattr(payload, "unit", None),
            "assertions": _metric_assertions(payload),
        }
        return PlannedStep(
            index=global_index,
            test_name=test_name,
            test_index=test_index,
            step_index=step_index,
            action=action,
            summary=f"Measure resource '{resource_name}'.",
            details=details,
        )

    if action == "assert_metric":
        metric_name = getattr(payload, "name", None)
        return PlannedStep(
            index=global_index,
            test_name=test_name,
            test_index=test_index,
            step_index=step_index,
            action=action,
            summary=f"Assert recorded metric '{metric_name}'.",
            details={"metric": metric_name, "assertions": _metric_assertions(payload)},
        )

    return PlannedStep(
        index=global_index,
        test_name=test_name,
        test_index=test_index,
        step_index=step_index,
        action=action,
        summary=f"Unsupported or unknown step action '{action}'.",
        details={},
    )


def _collect_plan_resources(bench: BenchConfig, steps: list[PlannedStep]) -> dict[str, Any]:
    nodes: set[str] = set()
    transports: set[str] = set()
    gpio_lines: set[str] = set()
    power_outlets: set[str] = set()
    measurement_resources: set[str] = set()
    metrics_recorded: set[str] = set()
    metrics_asserted: set[str] = set()

    for step in steps:
        d = step.details
        node = d.get("node")
        if node and node != "<missing>":
            nodes.add(str(node))
        transport = d.get("transport")
        if node and transport:
            transports.add(f"{node}.{transport}")
        line = d.get("line")
        if node and line:
            gpio_lines.add(f"{node}.{line}")
        resource = d.get("resource")
        outlet = d.get("outlet")
        if step.action.startswith("power") and resource and outlet:
            power_outlets.add(f"{resource}.{outlet}")
        if step.action == "measure" and resource:
            measurement_resources.add(str(resource))
        record_as = d.get("record_as")
        if record_as:
            metrics_recorded.add(str(record_as))
        metric = d.get("metric")
        if metric:
            metrics_asserted.add(str(metric))

    declared_power_resources = []
    declared_measurement_resources = []
    for name, resource_cfg in bench.resources.items():
        driver_type = _driver_type(resource_cfg)
        if driver_type in POWER_DRIVER_TYPES:
            declared_power_resources.append({
                "name": name,
                "kind": getattr(resource_cfg, "kind", None),
                "driver_type": driver_type,
                "outlets": sorted(_resource_outlets(resource_cfg).keys()),
            })
        elif driver_type in MEASUREMENT_DRIVER_TYPES:
            declared_measurement_resources.append({
                "name": name,
                "kind": getattr(resource_cfg, "kind", None),
                "driver_type": driver_type,
            })

    return {
        "nodes_used": sorted(nodes),
        "transports_used": sorted(transports),
        "gpio_lines_used": sorted(gpio_lines),
        "power_outlets_used": sorted(power_outlets),
        "measurement_resources_used": sorted(measurement_resources),
        "metrics_recorded": sorted(metrics_recorded),
        "metrics_asserted": sorted(metrics_asserted),
        "declared_power_resources": declared_power_resources,
        "declared_measurement_resources": declared_measurement_resources,
    }


def build_dry_run_plan(
    *,
    bench_path: str | Path,
    suite_path: str | Path,
    artifact_path: str | Path | None = None,
    skip_flash: bool = False,
    execution_mode: str = "local",
) -> DryRunPlanReport:
    bench_resolved = str(Path(bench_path).expanduser().resolve())
    suite_resolved = str(Path(suite_path).expanduser().resolve())
    validation_report = build_validation_report(bench_path=bench_path, suite_path=suite_path)
    validation_payload = validation_report.to_dict()

    bench = load_bench_config(bench_path)
    suite = load_suite_config(suite_path)

    steps: list[PlannedStep] = []
    global_index = 1
    for test_index, test in enumerate(suite.tests, start=1):
        for step_index, step in enumerate(test.steps, start=1):
            steps.append(
                _plan_step(
                    bench=bench,
                    test_name=test.name,
                    test_index=test_index,
                    step_index=step_index,
                    global_index=global_index,
                    step=step,
                    artifact_path=artifact_path,
                    skip_flash=skip_flash,
                )
            )
            global_index += 1

    resources = _collect_plan_resources(bench, steps)

    return DryRunPlanReport(
        checked_at=_utc_now(),
        bench_path=bench_resolved,
        suite_path=suite_resolved,
        bench_name=bench.bench.name,
        suite_name=suite.suite.name,
        execution_mode=execution_mode,
        skip_flash=skip_flash,
        artifact_override=str(Path(artifact_path).expanduser()) if artifact_path else None,
        validation=validation_payload,
        steps=steps,
        resources=resources,
    )


def _format_list(items: list[str]) -> str:
    return ", ".join(items) if items else "—"


def render_human_plan(report: DryRunPlanReport) -> str:
    payload = report.to_dict()
    lines: list[str] = []
    lines.append("=" * 72)
    lines.append("BENCHCI DRY-RUN EXECUTION PLAN")
    lines.append("=" * 72)
    lines.append(f"Bench: {payload['bench']['name']}")
    lines.append(f"Bench path: {payload['bench']['path']}")
    lines.append(f"Suite: {payload['suite']['name']}")
    lines.append(f"Suite path: {payload['suite']['path']}")
    lines.append(f"Execution mode: {payload['execution_mode']}")
    lines.append(f"Validation: {payload['validation'].get('status')} ({payload['validation'].get('health_status')})")
    lines.append(f"Flash: {'skipped' if payload['run_options']['skip_flash'] else 'enabled'}")
    lines.append(f"Artifact override: {payload['run_options']['artifact_override'] or '—'}")
    lines.append(f"Steps: {payload['summary']['step_count']} total, {payload['summary']['skipped_step_count']} skipped")
    lines.append("")

    validation_counts = payload["validation"].get("counts") or {}
    if payload["validation"].get("status") != "valid":
        lines.append("Validation issues must be fixed before this run can execute reliably:")
        for check in payload["validation"].get("checks", []):
            if check.get("status") == "fail":
                lines.append(f"[FAIL] {check.get('title')}: {check.get('message')}")
        lines.append("")
    elif validation_counts.get("warnings", 0):
        lines.append(f"Validation warnings: {validation_counts.get('warnings')} warning(s).")
        lines.append("")

    for step in payload["steps"]:
        marker = "SKIP" if step.get("skipped") else "PLAN"
        lines.append(f"[{marker}] {step['index']}. {step['action']}  ({step['test_name']} step {step['step_index']})")
        lines.append(f"       {step['summary']}")
        details = step.get("details") or {}
        for key, value in details.items():
            if value is None or value == "":
                continue
            lines.append(f"       {key}: {value}")
        lines.append("")

    resources = payload["resources"]
    lines.append("Summary:")
    lines.append(f"  nodes used: {_format_list(resources.get('nodes_used', []))}")
    lines.append(f"  transports used: {_format_list(resources.get('transports_used', []))}")
    lines.append(f"  GPIO lines used: {_format_list(resources.get('gpio_lines_used', []))}")
    lines.append(f"  power outlets used: {_format_list(resources.get('power_outlets_used', []))}")
    lines.append(f"  measurement resources used: {_format_list(resources.get('measurement_resources_used', []))}")
    lines.append(f"  metrics recorded: {_format_list(resources.get('metrics_recorded', []))}")
    lines.append(f"  metrics asserted: {_format_list(resources.get('metrics_asserted', []))}")
    return "\n".join(lines)


def run_dry_run_plan(
    *,
    bench_path: str | Path,
    suite_path: str | Path,
    artifact_path: str | Path | None = None,
    skip_flash: bool = False,
    execution_mode: str = "local",
    output_path: str | Path | None = None,
    json_output: bool = False,
) -> int:
    report = build_dry_run_plan(
        bench_path=bench_path,
        suite_path=suite_path,
        artifact_path=artifact_path,
        skip_flash=skip_flash,
        execution_mode=execution_mode,
    )
    payload = report.to_dict()

    if output_path:
        out = Path(output_path).expanduser().resolve()
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    if json_output:
        typer.echo(json.dumps(payload, indent=2))
    else:
        typer.echo(render_human_plan(report))
        if output_path:
            typer.echo("")
            typer.echo(f"[INFO] Dry-run plan JSON saved to: {Path(output_path).expanduser().resolve()}")

    return 0 if payload["status"] == "ready" else 1
