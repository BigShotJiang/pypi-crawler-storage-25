from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal


HealthStatus = Literal["unknown", "healthy", "degraded", "failing"]
CheckStatus = Literal["pass", "warn", "fail", "skip"]
CheckSeverity = Literal["info", "warning", "error", "critical"]

FailureSource = Literal[
    "firmware",
    "test_logic",
    "bench_infrastructure",
    "agent_cloud",
    "configuration",
    "unknown",
]


DIAGNOSTIC_SCHEMA_VERSION = "benchci.diagnostics.v1"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


@dataclass
class DiagnosticCheck:
    id: str
    title: str
    status: CheckStatus
    severity: CheckSeverity = "info"
    category: str | None = None
    source: FailureSource = "unknown"
    message: str = ""
    suggested_fix: str | None = None
    required: bool = True
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "id": self.id,
            "title": self.title,
            "status": self.status,
            "severity": self.severity,
            "category": self.category,
            "source": self.source,
            "message": self.message,
            "suggested_fix": self.suggested_fix,
            "required": self.required,
            "details": self.details,
        }
        return {k: v for k, v in payload.items() if v is not None and v != ""}


@dataclass
class BenchSelfTestReport:
    bench_name: str | None
    bench_path: str
    checked_at: str
    health_status: HealthStatus
    summary: str
    checks: list[DiagnosticCheck]
    schema_version: str = DIAGNOSTIC_SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        checks = [c.to_dict() for c in self.checks]
        passed = sum(1 for c in self.checks if c.status == "pass")
        warnings = sum(1 for c in self.checks if c.status == "warn")
        failed = sum(1 for c in self.checks if c.status == "fail")
        skipped = sum(1 for c in self.checks if c.status == "skip")

        return {
            "schema_version": self.schema_version,
            "tool": "benchci",
            "command": "bench self-test",
            "checked_at": self.checked_at,
            "bench": {
                "name": self.bench_name,
                "path": self.bench_path,
            },
            "health_status": self.health_status,
            "summary": self.summary,
            "counts": {
                "passed": passed,
                "warnings": warnings,
                "failed": failed,
                "skipped": skipped,
                "total": len(self.checks),
            },
            "checks": checks,
        }


def derive_health_status(checks: list[DiagnosticCheck]) -> HealthStatus:
    required_failures = [
        c for c in checks
        if c.required and c.status == "fail" and c.severity in {"error", "critical"}
    ]
    if required_failures:
        return "failing"

    warnings_or_optional_failures = [
        c for c in checks
        if c.status in {"warn", "fail"}
    ]
    if warnings_or_optional_failures:
        return "degraded"

    if not checks:
        return "unknown"

    return "healthy"


def summarize_health(status: HealthStatus, checks: list[DiagnosticCheck]) -> str:
    failed = sum(1 for c in checks if c.status == "fail")
    warnings = sum(1 for c in checks if c.status == "warn")

    if status == "healthy":
        return "Bench infrastructure looks healthy."
    if status == "degraded":
        return f"Bench is usable but has {warnings} warning(s) or optional issue(s)."
    if status == "failing":
        return f"Bench has {failed} failing required check(s)."
    return "Bench health is unknown."