from __future__ import annotations

import json
import os
import platform
import shutil
import tempfile
import typer

from pathlib import Path
from typing import Any
from pydantic import ValidationError
from benchci.gpio.factory import create_gpio_manager
from benchci.power.power import create_power_manager
from benchci.measurement.measurement import create_measurement_manager
from benchci.transport.factory import create_transport
from benchci.config.bench import (
    BenchConfig,
    TransportCan,
    TransportModbusRtu,
    TransportUart,
    get_bench_warnings,
    load_bench_config,
)
from benchci.diagnostics.schema import (
    BenchSelfTestReport,
    DiagnosticCheck,
    derive_health_status,
    summarize_health,
    utc_now,
)

def _diagnostic_log_path(root: Path, *parts: str) -> Path:
    safe_parts = [str(p).replace("/", "_").replace("\\", "_") for p in parts]
    return root.joinpath(*safe_parts)

def _append_self_test_log(path: Path, message: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(f"{utc_now()} {message}\n")

def _check_transport_open(
    bench: BenchConfig,
    node_name: str,
    transport_name: str,
    log_root: Path,
) -> DiagnosticCheck:
    log_path = _diagnostic_log_path(
        log_root,
        "nodes",
        node_name,
        f"transport-{transport_name}.log",
    )

    transport = None
    try:
        _append_self_test_log(
            log_path,
            f"SELF_TEST_START node={node_name} transport={transport_name}",
        )

        transport = create_transport(
            bench=bench,
            node_name=node_name,
            transport_name=transport_name,
            log_path=log_path,
        )

        _append_self_test_log(
            log_path,
            f"OPEN_ATTEMPT node={node_name} transport={transport_name}",
        )

        transport.start()

        _append_self_test_log(
            log_path,
            f"OPEN_OK node={node_name} transport={transport_name}",
        )

        return DiagnosticCheck(
            id=f"node.{node_name}.transport.{transport_name}.open",
            title=f"Open transport '{transport_name}' on node '{node_name}'",
            status="pass",
            severity="info",
            source="bench_infrastructure",
            message="Transport opened successfully.",
            required=True,
            details={
                "node": node_name,
                "transport": transport_name,
                "log_path": str(log_path),
            },
        )
    except Exception as exc:
        _append_self_test_log(
            log_path,
            f"OPEN_FAILED node={node_name} transport={transport_name} error_type={type(exc).__name__} error={exc}",
        )

        return DiagnosticCheck(
            id=f"node.{node_name}.transport.{transport_name}.open",
            title=f"Open transport '{transport_name}' on node '{node_name}'",
            status="fail",
            severity="critical",
            category="TRANSPORT_OPEN_FAILED",
            source="bench_infrastructure",
            message=f"Failed to open transport: {exc}",
            suggested_fix="Check the configured port/interface, cable connection, permissions, and whether another process is using the transport.",
            required=True,
            details={
                "node": node_name,
                "transport": transport_name,
                "error_type": type(exc).__name__,
                "log_path": str(log_path),
            },
        )
    finally:
        if transport is not None:
            try:
                transport.stop()
                _append_self_test_log(
                    log_path,
                    f"CLOSE_OK node={node_name} transport={transport_name}",
                )
            except Exception as exc:
                _append_self_test_log(
                    log_path,
                    f"CLOSE_FAILED node={node_name} transport={transport_name} error_type={type(exc).__name__} error={exc}",
                )



def _check_gpio_manager_start(
    bench: BenchConfig,
    node_name: str,
    log_root: Path,
    *,
    read_inputs: bool,
) -> list[DiagnosticCheck]:
    log_path = _diagnostic_log_path(log_root, "nodes", node_name, "gpio.log")
    checks: list[DiagnosticCheck] = []
    manager = None

    try:
        _append_self_test_log(
            log_path,
            f"SELF_TEST_START node={node_name} gpio=true read_inputs={read_inputs}",
        )

        manager = create_gpio_manager(
            bench=bench,
            node_name=node_name,
            log_path=log_path,
        )

        if manager is None:
            _append_self_test_log(log_path, f"SKIP node={node_name} reason=no_gpio_lines")
            return [
                DiagnosticCheck(
                    id=f"node.{node_name}.gpio.start",
                    title=f"GPIO manager for node '{node_name}'",
                    status="skip",
                    severity="info",
                    source="configuration",
                    message="Node does not define GPIO lines.",
                    required=False,
                    details={"node": node_name, "log_path": str(log_path)},
                )
            ]

        _append_self_test_log(log_path, f"START_ATTEMPT node={node_name}")
        manager.start()
        _append_self_test_log(
            log_path,
            f"START_OK node={node_name} lines={manager.line_names()}",
        )

        checks.append(
            DiagnosticCheck(
                id=f"node.{node_name}.gpio.start",
                title=f"Start GPIO manager for node '{node_name}'",
                status="pass",
                severity="info",
                source="bench_infrastructure",
                message="GPIO manager started successfully.",
                required=True,
                details={
                    "node": node_name,
                    "lines": manager.line_names(),
                    "log_path": str(log_path),
                },
            )
        )

        node_cfg = bench.nodes[node_name]

        if read_inputs:
            for line_name in manager.line_names():
                line_cfg = node_cfg.gpio.get(line_name)
                direction = getattr(line_cfg, "direction", None)

                if direction != "input":
                    _append_self_test_log(
                        log_path,
                        f"GPIO_READ_SKIP node={node_name} line={line_name} direction={direction} reason=not_input",
                    )
                    checks.append(
                        DiagnosticCheck(
                            id=f"node.{node_name}.gpio.{line_name}.read",
                            title=f"Read GPIO line '{line_name}' on node '{node_name}'",
                            status="skip",
                            severity="info",
                            source="bench_infrastructure",
                            message="Output GPIO lines are not driven or read by self-test.",
                            required=False,
                            details={
                                "node": node_name,
                                "line": line_name,
                                "direction": direction,
                                "log_path": str(log_path),
                            },
                        )
                    )
                    continue

                try:
                    _append_self_test_log(
                        log_path,
                        f"GPIO_READ_ATTEMPT node={node_name} line={line_name}",
                    )
                    value = manager.get_logical_value(line_name)
                    _append_self_test_log(
                        log_path,
                        f"GPIO_READ_OK node={node_name} line={line_name} value={value}",
                    )
                    checks.append(
                        DiagnosticCheck(
                            id=f"node.{node_name}.gpio.{line_name}.read",
                            title=f"Read GPIO input '{line_name}' on node '{node_name}'",
                            status="pass",
                            severity="info",
                            source="bench_infrastructure",
                            message=f"GPIO input read successfully: {value}",
                            required=True,
                            details={
                                "node": node_name,
                                "line": line_name,
                                "value": value,
                                "direction": direction,
                                "log_path": str(log_path),
                            },
                        )
                    )
                except Exception as exc:
                    _append_self_test_log(
                        log_path,
                        f"GPIO_READ_FAILED node={node_name} line={line_name} error_type={type(exc).__name__} error={exc}",
                    )
                    checks.append(
                        DiagnosticCheck(
                            id=f"node.{node_name}.gpio.{line_name}.read",
                            title=f"Read GPIO input '{line_name}' on node '{node_name}'",
                            status="fail",
                            severity="critical",
                            category="GPIO_LINE_UNREACHABLE",
                            source="bench_infrastructure",
                            message=f"Failed to read GPIO input: {exc}",
                            suggested_fix="Check GPIO chip path, line number, permissions, pin direction, and whether another process owns the line.",
                            required=True,
                            details={
                                "node": node_name,
                                "line": line_name,
                                "error_type": type(exc).__name__,
                                "log_path": str(log_path),
                            },
                        )
                    )

        return checks

    except Exception as exc:
        _append_self_test_log(
            log_path,
            f"START_FAILED node={node_name} error_type={type(exc).__name__} error={exc}",
        )
        return [
            DiagnosticCheck(
                id=f"node.{node_name}.gpio.start",
                title=f"Start GPIO manager for node '{node_name}'",
                status="fail",
                severity="critical",
                category="GPIO_LINE_UNREACHABLE",
                source="bench_infrastructure",
                message=f"Failed to start GPIO manager: {exc}",
                suggested_fix="Check GPIO backend config, gpiochip path, remote GPIO token, permissions, and duplicate line usage.",
                required=True,
                details={
                    "node": node_name,
                    "error_type": type(exc).__name__,
                    "log_path": str(log_path),
                },
            )
        ]
    finally:
        if manager is not None:
            try:
                manager.stop()
                _append_self_test_log(log_path, f"STOP_OK node={node_name}")
            except Exception as exc:
                _append_self_test_log(
                    log_path,
                    f"STOP_FAILED node={node_name} error_type={type(exc).__name__} error={exc}",
                )

def _is_power_resource(resource_cfg: Any) -> bool:
    driver = getattr(resource_cfg, "driver", None)
    return getattr(driver, "type", None) in {
        "mock_power",
        "gpio_power",
        "http_relay",
        "usb_relay_serial",
    }


def _is_measurement_resource(resource_cfg: Any) -> bool:
    driver = getattr(resource_cfg, "driver", None)
    return getattr(driver, "type", None) in {
        "mock_measurement",
        "http_measurement",
    }



def _check_power_resource_open(
    bench: BenchConfig,
    resource_name: str,
    log_root: Path,
    *,
    read_inputs: bool,
) -> list[DiagnosticCheck]:
    log_path = _diagnostic_log_path(
        log_root,
        "resources",
        resource_name,
        "power.log",
    )
    checks: list[DiagnosticCheck] = []
    manager = None

    try:
        _append_self_test_log(
            log_path,
            f"SELF_TEST_START resource={resource_name} type=power read_inputs={read_inputs}",
        )

        manager = create_power_manager(
            bench=bench,
            resource_name=resource_name,
            log_path=log_path,
        )

        _append_self_test_log(log_path, f"START_ATTEMPT resource={resource_name}")
        manager.start()

        outlets = manager.outlet_names()
        _append_self_test_log(
            log_path,
            f"START_OK resource={resource_name} outlets={outlets}",
        )

        checks.append(
            DiagnosticCheck(
                id=f"resource.{resource_name}.power.start",
                title=f"Start power resource '{resource_name}'",
                status="pass",
                severity="info",
                source="bench_infrastructure",
                message="Power resource started successfully.",
                required=True,
                details={
                    "resource": resource_name,
                    "outlets": outlets,
                    "log_path": str(log_path),
                },
            )
        )

        if read_inputs:
            for outlet in outlets:
                try:
                    _append_self_test_log(
                        log_path,
                        f"POWER_READ_ATTEMPT resource={resource_name} outlet={outlet}",
                    )
                    state = manager.get_state(outlet)
                    _append_self_test_log(
                        log_path,
                        f"POWER_READ_OK resource={resource_name} outlet={outlet} state={state}",
                    )
                    if state is None:
                        checks.append(
                            DiagnosticCheck(
                                id=f"resource.{resource_name}.power.{outlet}.read",
                                title=f"Read power outlet '{outlet}' on resource '{resource_name}'",
                                status="warn",
                                severity="warning",
                                category="POWER_READBACK_UNAVAILABLE",
                                source="bench_infrastructure",
                                message="Power outlet does not support reliable state readback.",
                                suggested_fix="This is okay for simple relay backends. Use a backend with readback if power_expect is required.",
                                required=False,
                                details={
                                    "resource": resource_name,
                                    "outlet": outlet,
                                    "state": None,
                                    "log_path": str(log_path),
                                },
                            )
                        )
                    else:
                        checks.append(
                            DiagnosticCheck(
                                id=f"resource.{resource_name}.power.{outlet}.read",
                                title=f"Read power outlet '{outlet}' on resource '{resource_name}'",
                                status="pass",
                                severity="info",
                                source="bench_infrastructure",
                                message=f"Power outlet read successfully: {state}",
                                required=False,
                                details={
                                    "resource": resource_name,
                                    "outlet": outlet,
                                    "state": state,
                                    "log_path": str(log_path),
                                },
                            )
                        )
                except Exception as exc:
                    _append_self_test_log(
                        log_path,
                        f"POWER_READ_FAILED resource={resource_name} outlet={outlet} error_type={type(exc).__name__} error={exc}",
                    )
                    checks.append(
                        DiagnosticCheck(
                            id=f"resource.{resource_name}.power.{outlet}.read",
                            title=f"Read power outlet '{outlet}' on resource '{resource_name}'",
                            status="fail",
                            severity="critical",
                            category="POWER_RESOURCE_UNAVAILABLE",
                            source="bench_infrastructure",
                            message=f"Failed to read power outlet state: {exc}",
                            suggested_fix="Check relay/controller connection, configured outlet name, HTTP endpoint, serial port, GPIO permissions, or backend driver settings.",
                            required=True,
                            details={
                                "resource": resource_name,
                                "outlet": outlet,
                                "error_type": type(exc).__name__,
                                "log_path": str(log_path),
                            },
                        )
                    )

        return checks

    except Exception as exc:
        _append_self_test_log(
            log_path,
            f"START_FAILED resource={resource_name} error_type={type(exc).__name__} error={exc}",
        )
        return [
            DiagnosticCheck(
                id=f"resource.{resource_name}.power.start",
                title=f"Start power resource '{resource_name}'",
                status="fail",
                severity="critical",
                category="POWER_RESOURCE_UNAVAILABLE",
                source="bench_infrastructure",
                message=f"Failed to start power resource: {exc}",
                suggested_fix="Check power resource driver settings, GPIO chip, relay serial port, HTTP endpoint, permissions, and whether another process owns the resource.",
                required=True,
                details={
                    "resource": resource_name,
                    "error_type": type(exc).__name__,
                    "log_path": str(log_path),
                },
            )
        ]
    finally:
        if manager is not None:
            try:
                manager.stop()
                _append_self_test_log(log_path, f"STOP_OK resource={resource_name}")
            except Exception as exc:
                _append_self_test_log(
                    log_path,
                    f"STOP_FAILED resource={resource_name} error_type={type(exc).__name__} error={exc}",
                )


def _check_measurement_resource_open(
    bench: BenchConfig,
    resource_name: str,
    log_root: Path,
    *,
    read_measurements: bool,
) -> list[DiagnosticCheck]:
    log_path = _diagnostic_log_path(
        log_root,
        "resources",
        resource_name,
        "measurement.log",
    )
    checks: list[DiagnosticCheck] = []
    manager = None

    try:
        _append_self_test_log(
            log_path,
            f"SELF_TEST_START resource={resource_name} type=measurement read_measurements={read_measurements}",
        )

        manager = create_measurement_manager(
            bench=bench,
            resource_name=resource_name,
            log_path=log_path,
        )

        _append_self_test_log(log_path, f"START_ATTEMPT resource={resource_name}")
        manager.start()
        _append_self_test_log(log_path, f"START_OK resource={resource_name}")

        checks.append(
            DiagnosticCheck(
                id=f"resource.{resource_name}.measurement.start",
                title=f"Start measurement resource '{resource_name}'",
                status="pass",
                severity="info",
                source="bench_infrastructure",
                message="Measurement resource started successfully.",
                required=True,
                details={
                    "resource": resource_name,
                    "log_path": str(log_path),
                },
            )
        )

        if read_measurements:
            try:
                _append_self_test_log(log_path, f"MEASURE_ATTEMPT resource={resource_name}")
                measurement = manager.measure()
                _append_self_test_log(
                    log_path,
                    f"MEASURE_OK resource={resource_name} measurement={json.dumps(measurement, sort_keys=True)}",
                )
                checks.append(
                    DiagnosticCheck(
                        id=f"resource.{resource_name}.measurement.read",
                        title=f"Read measurement resource '{resource_name}'",
                        status="pass",
                        severity="info",
                        source="bench_infrastructure",
                        message="Measurement read successfully.",
                        required=False,
                        details={
                            "resource": resource_name,
                            "measurement": measurement,
                            "log_path": str(log_path),
                        },
                    )
                )
            except Exception as exc:
                _append_self_test_log(
                    log_path,
                    f"MEASURE_FAILED resource={resource_name} error_type={type(exc).__name__} error={exc}",
                )
                checks.append(
                    DiagnosticCheck(
                        id=f"resource.{resource_name}.measurement.read",
                        title=f"Read measurement resource '{resource_name}'",
                        status="fail",
                        severity="critical",
                        category="MEASUREMENT_RESOURCE_UNAVAILABLE",
                        source="bench_infrastructure",
                        message=f"Failed to read measurement resource: {exc}",
                        suggested_fix="Check measurement controller endpoint, response format, value field, timeout, and instrument connectivity.",
                        required=True,
                        details={
                            "resource": resource_name,
                            "error_type": type(exc).__name__,
                            "log_path": str(log_path),
                        },
                    )
                )

        return checks

    except Exception as exc:
        _append_self_test_log(
            log_path,
            f"START_FAILED resource={resource_name} error_type={type(exc).__name__} error={exc}",
        )
        return [
            DiagnosticCheck(
                id=f"resource.{resource_name}.measurement.start",
                title=f"Start measurement resource '{resource_name}'",
                status="fail",
                severity="critical",
                category="MEASUREMENT_RESOURCE_UNAVAILABLE",
                source="bench_infrastructure",
                message=f"Failed to start measurement resource: {exc}",
                suggested_fix="Check measurement resource driver settings, endpoint, permissions, and backend dependencies.",
                required=True,
                details={
                    "resource": resource_name,
                    "error_type": type(exc).__name__,
                    "log_path": str(log_path),
                },
            )
        ]
    finally:
        if manager is not None:
            try:
                manager.stop()
                _append_self_test_log(log_path, f"STOP_OK resource={resource_name}")
            except Exception as exc:
                _append_self_test_log(
                    log_path,
                    f"STOP_FAILED resource={resource_name} error_type={type(exc).__name__} error={exc}",
                )

def _run_hardware_open_checks(
    bench: BenchConfig,
    *,
    log_root: Path,
    read_inputs: bool,
    read_measurements: bool,
) -> list[DiagnosticCheck]:
    checks: list[DiagnosticCheck] = []

    for node_name, node_cfg in bench.nodes.items():
        for transport_name in node_cfg.transports.keys():
            checks.append(
                _check_transport_open(
                    bench=bench,
                    node_name=node_name,
                    transport_name=transport_name,
                    log_root=log_root,
                )
            )

        if node_cfg.gpio:
            checks.extend(
                _check_gpio_manager_start(
                    bench=bench,
                    node_name=node_name,
                    log_root=log_root,
                    read_inputs=read_inputs,
                )
            )

    for resource_name, resource_cfg in bench.resources.items():
        if _is_power_resource(resource_cfg):
            checks.extend(
                _check_power_resource_open(
                    bench=bench,
                    resource_name=resource_name,
                    log_root=log_root,
                    read_inputs=read_inputs,
                )
            )
        elif _is_measurement_resource(resource_cfg):
            checks.extend(
                _check_measurement_resource_open(
                    bench=bench,
                    resource_name=resource_name,
                    log_root=log_root,
                    read_measurements=read_measurements,
                )
            )

    return checks

def _path_exists(path: str) -> bool:
    try:
        return Path(path).expanduser().exists()
    except Exception:
        return False


def _is_probably_serial_path(path: str) -> bool:
    if platform.system().lower() == "windows":
        return path.upper().startswith("COM")
    return path.startswith("/dev/")


def _tool_for_flash_backend(backend: str) -> str | None:
    return {
        "openocd": "openocd",
        "cubeprog": "STM32_Programmer_CLI",
        "jlink": "JLinkExe",
        "esptool": "esptool.py",
    }.get(backend)


def _tool_for_reset_method(method: str) -> str | None:
    if method == "none":
        return None
    return _tool_for_flash_backend(method)


def _check_yaml_loaded(bench: BenchConfig, bench_path: Path) -> DiagnosticCheck:
    return DiagnosticCheck(
        id="bench_yaml_loaded",
        title="bench.yaml loaded",
        status="pass",
        severity="info",
        source="configuration",
        message=f"Loaded bench '{bench.bench.name}' from {bench_path}.",
        required=True,
        details={
            "bench_name": bench.bench.name,
            "node_count": len(bench.nodes),
            "resource_count": len(bench.resources),
        },
    )


def _check_bench_warnings(bench: BenchConfig) -> list[DiagnosticCheck]:
    checks: list[DiagnosticCheck] = []

    for idx, warning in enumerate(get_bench_warnings(bench), start=1):
        checks.append(
            DiagnosticCheck(
                id=f"bench_warning_{idx}",
                title="Bench configuration warning",
                status="warn",
                severity="warning",
                category="CONFIG_WARNING",
                source="configuration",
                message=warning,
                suggested_fix="Review bench.yaml and align the configuration with the intended hardware setup.",
                required=False,
            )
        )

    return checks


def _check_default_node(bench: BenchConfig) -> DiagnosticCheck:
    default_node = bench.defaults.node if bench.defaults else None

    if not default_node:
        return DiagnosticCheck(
            id="default_node",
            title="Default node",
            status="warn",
            severity="warning",
            category="CONFIG_WARNING",
            source="configuration",
            message="bench.defaults.node is not set.",
            suggested_fix="Set defaults.node if most suite steps target the same node.",
            required=False,
        )

    return DiagnosticCheck(
        id="default_node",
        title="Default node",
        status="pass",
        severity="info",
        source="configuration",
        message=f"Default node is '{default_node}'.",
        required=False,
        details={"default_node": default_node},
    )


def _check_flash_tool(node_name: str, backend: str) -> DiagnosticCheck:
    tool = _tool_for_flash_backend(backend)

    if not tool:
        return DiagnosticCheck(
            id=f"node.{node_name}.flash.backend",
            title=f"Flash backend for node '{node_name}'",
            status="fail",
            severity="critical",
            category="CONFIG_ERROR",
            source="configuration",
            message=f"Unsupported flash backend: {backend}",
            suggested_fix="Use a supported flash backend: openocd, cubeprog, jlink, or esptool.",
            required=True,
            details={"node": node_name, "backend": backend},
        )

    path = shutil.which(tool)
    if not path:
        return DiagnosticCheck(
            id=f"node.{node_name}.flash.tool",
            title=f"Flash tool for node '{node_name}'",
            status="fail",
            severity="critical",
            category="FLASH_TOOL_UNAVAILABLE",
            source="bench_infrastructure",
            message=f"Required flash tool '{tool}' was not found in PATH.",
            suggested_fix=f"Install '{tool}' on the bench/agent machine or update bench.yaml to use the correct backend.",
            required=True,
            details={"node": node_name, "backend": backend, "tool": tool},
        )

    return DiagnosticCheck(
        id=f"node.{node_name}.flash.tool",
        title=f"Flash tool for node '{node_name}'",
        status="pass",
        severity="info",
        source="bench_infrastructure",
        message=f"Found flash tool '{tool}'.",
        required=True,
        details={"node": node_name, "backend": backend, "tool": tool, "path": path},
    )


def _check_reset_tool(node_name: str, method: str) -> DiagnosticCheck:
    tool = _tool_for_reset_method(method)

    if method == "none":
        return DiagnosticCheck(
            id=f"node.{node_name}.reset",
            title=f"Reset method for node '{node_name}'",
            status="skip",
            severity="info",
            source="configuration",
            message="Reset method is 'none'.",
            required=False,
            details={"node": node_name, "method": method},
        )

    if not tool:
        return DiagnosticCheck(
            id=f"node.{node_name}.reset",
            title=f"Reset method for node '{node_name}'",
            status="fail",
            severity="critical",
            category="CONFIG_ERROR",
            source="configuration",
            message=f"Unsupported reset method: {method}",
            suggested_fix="Use a supported reset method or set reset.method: none.",
            required=True,
            details={"node": node_name, "method": method},
        )

    path = shutil.which(tool)
    if not path:
        return DiagnosticCheck(
            id=f"node.{node_name}.reset.tool",
            title=f"Reset tool for node '{node_name}'",
            status="fail",
            severity="critical",
            category="FLASH_TOOL_UNAVAILABLE",
            source="bench_infrastructure",
            message=f"Required reset tool '{tool}' was not found in PATH.",
            suggested_fix=f"Install '{tool}' or change reset.method in bench.yaml.",
            required=True,
            details={"node": node_name, "method": method, "tool": tool},
        )

    return DiagnosticCheck(
        id=f"node.{node_name}.reset.tool",
        title=f"Reset tool for node '{node_name}'",
        status="pass",
        severity="info",
        source="bench_infrastructure",
        message=f"Found reset tool '{tool}'.",
        required=True,
        details={"node": node_name, "method": method, "tool": tool, "path": path},
    )


def _check_transport(node_name: str, transport_name: str, transport: Any) -> DiagnosticCheck:
    if isinstance(transport, (TransportUart, TransportModbusRtu)):
        port = transport.port
        if _is_probably_serial_path(port) and not _path_exists(port):
            return DiagnosticCheck(
                id=f"node.{node_name}.transport.{transport_name}",
                title=f"Transport '{transport_name}' on node '{node_name}'",
                status="fail",
                severity="critical",
                category="TRANSPORT_OPEN_FAILED",
                source="bench_infrastructure",
                message=f"Serial port '{port}' does not exist.",
                suggested_fix="Check USB connection, udev/device name, or update the port in bench.yaml.",
                required=True,
                details={
                    "node": node_name,
                    "transport": transport_name,
                    "backend": transport.backend,
                    "port": port,
                },
            )

        return DiagnosticCheck(
            id=f"node.{node_name}.transport.{transport_name}",
            title=f"Transport '{transport_name}' on node '{node_name}'",
            status="pass",
            severity="info",
            source="bench_infrastructure",
            message=f"Transport is configured with port '{port}'.",
            required=True,
            details={
                "node": node_name,
                "transport": transport_name,
                "backend": transport.backend,
                "port": port,
            },
        )

    if isinstance(transport, TransportCan):
        iface = transport.interface
        if platform.system().lower() == "linux":
            sys_path = Path("/sys/class/net") / iface
            if not sys_path.exists():
                return DiagnosticCheck(
                    id=f"node.{node_name}.transport.{transport_name}",
                    title=f"CAN transport '{transport_name}' on node '{node_name}'",
                    status="fail",
                    severity="critical",
                    category="TRANSPORT_OPEN_FAILED",
                    source="bench_infrastructure",
                    message=f"CAN interface '{iface}' was not found.",
                    suggested_fix="Create/configure the SocketCAN interface, then retry self-test.",
                    required=True,
                    details={
                        "node": node_name,
                        "transport": transport_name,
                        "backend": transport.backend,
                        "interface": iface,
                    },
                )

        return DiagnosticCheck(
            id=f"node.{node_name}.transport.{transport_name}",
            title=f"CAN transport '{transport_name}' on node '{node_name}'",
            status="pass",
            severity="info",
            source="bench_infrastructure",
            message=f"CAN transport is configured with interface '{iface}'.",
            required=True,
            details={
                "node": node_name,
                "transport": transport_name,
                "backend": transport.backend,
                "interface": iface,
            },
        )

    return DiagnosticCheck(
        id=f"node.{node_name}.transport.{transport_name}",
        title=f"Transport '{transport_name}' on node '{node_name}'",
        status="warn",
        severity="warning",
        category="CONFIG_WARNING",
        source="configuration",
        message=f"Unknown transport type: {type(transport).__name__}",
        suggested_fix="Check the transport backend in bench.yaml.",
        required=False,
        details={"node": node_name, "transport": transport_name},
    )


def _check_gpio(node_name: str, line_name: str, gpio_cfg: Any) -> DiagnosticCheck:
    backend = getattr(gpio_cfg, "backend", "unknown")

    if backend == "local_gpio":
        chip = getattr(gpio_cfg, "chip", "")
        if chip and not Path(chip).exists():
            return DiagnosticCheck(
                id=f"node.{node_name}.gpio.{line_name}",
                title=f"GPIO line '{line_name}' on node '{node_name}'",
                status="fail",
                severity="critical",
                category="GPIO_LINE_UNREACHABLE",
                source="bench_infrastructure",
                message=f"GPIO chip '{chip}' does not exist.",
                suggested_fix="Check the gpiochip path in bench.yaml and verify the device is exposed on the agent machine.",
                required=True,
                details={
                    "node": node_name,
                    "line_name": line_name,
                    "backend": backend,
                    "chip": chip,
                    "line": getattr(gpio_cfg, "line", None),
                    "direction": getattr(gpio_cfg, "direction", None),
                },
            )

    if backend == "remote_gpio":
        token_env = str(getattr(gpio_cfg, "token_env", "") or "")
        if token_env and not os.getenv(token_env):
            return DiagnosticCheck(
                id=f"node.{node_name}.gpio.{line_name}.token",
                title=f"Remote GPIO token for '{line_name}'",
                status="fail",
                severity="critical",
                category="GPIO_LINE_UNREACHABLE",
                source="bench_infrastructure",
                message=f"Environment variable '{token_env}' is not set.",
                suggested_fix=f"Set {token_env} on the agent machine or update bench.yaml.",
                required=True,
                details={
                    "node": node_name,
                    "line_name": line_name,
                    "backend": backend,
                    "token_env": token_env,
                },
            )

    return DiagnosticCheck(
        id=f"node.{node_name}.gpio.{line_name}",
        title=f"GPIO line '{line_name}' on node '{node_name}'",
        status="pass",
        severity="info",
        source="bench_infrastructure",
        message="GPIO line is configured.",
        required=True,
        details={
            "node": node_name,
            "line_name": line_name,
            "backend": backend,
            "direction": getattr(gpio_cfg, "direction", None),
            "active_high": getattr(gpio_cfg, "active_high", None),
            "chip": getattr(gpio_cfg, "chip", None),
            "line": getattr(gpio_cfg, "line", None),
        },
    )


def _check_resource(resource_name: str, resource_cfg: Any) -> DiagnosticCheck:
    driver = getattr(resource_cfg, "driver", None)
    driver_type = getattr(driver, "type", "unknown")

    return DiagnosticCheck(
        id=f"resource.{resource_name}",
        title=f"Resource '{resource_name}'",
        status="pass",
        severity="info",
        source="bench_infrastructure",
        message=f"Resource is configured with driver '{driver_type}'.",
        required=True,
        details={
            "resource": resource_name,
            "kind": getattr(resource_cfg, "kind", None),
            "driver_type": driver_type,
        },
    )


def build_bench_self_test_report(
    bench_path: str | Path,
    *,
    open_hardware: bool = False,
    read_inputs: bool = False,
    read_measurements: bool = False,
    log_dir: str | Path | None = None,
) -> BenchSelfTestReport:
    path = Path(bench_path).expanduser().resolve()
    checks: list[DiagnosticCheck] = []

    try:
        bench = load_bench_config(path)
    except FileNotFoundError:
        checks.append(
            DiagnosticCheck(
                id="bench_yaml_exists",
                title="bench.yaml exists",
                status="fail",
                severity="critical",
                category="CONFIG_ERROR",
                source="configuration",
                message=f"Bench config file does not exist: {path}",
                suggested_fix="Pass a valid bench.yaml path with --bench.",
                required=True,
            )
        )
        status = derive_health_status(checks)
        return BenchSelfTestReport(
            bench_name=None,
            bench_path=str(path),
            checked_at=utc_now(),
            health_status=status,
            summary=summarize_health(status, checks),
            checks=checks,
        )
    except ValidationError as exc:
        checks.append(
            DiagnosticCheck(
                id="bench_yaml_valid",
                title="bench.yaml validation",
                status="fail",
                severity="critical",
                category="CONFIG_ERROR",
                source="configuration",
                message="bench.yaml failed schema validation.",
                suggested_fix="Fix the validation errors reported by Pydantic/YAML and retry.",
                required=True,
                details={"error": str(exc)},
            )
        )
        status = derive_health_status(checks)
        return BenchSelfTestReport(
            bench_name=None,
            bench_path=str(path),
            checked_at=utc_now(),
            health_status=status,
            summary=summarize_health(status, checks),
            checks=checks,
        )
    except Exception as exc:
        checks.append(
            DiagnosticCheck(
                id="bench_yaml_load",
                title="bench.yaml load",
                status="fail",
                severity="critical",
                category="CONFIG_ERROR",
                source="configuration",
                message=f"Could not load bench.yaml: {exc}",
                suggested_fix="Check YAML syntax and file permissions.",
                required=True,
                details={"error_type": type(exc).__name__},
            )
        )
        status = derive_health_status(checks)
        return BenchSelfTestReport(
            bench_name=None,
            bench_path=str(path),
            checked_at=utc_now(),
            health_status=status,
            summary=summarize_health(status, checks),
            checks=checks,
        )

    checks.append(_check_yaml_loaded(bench, path))
    checks.append(_check_default_node(bench))
    checks.extend(_check_bench_warnings(bench))

    for node_name, node_cfg in bench.nodes.items():
        if node_cfg.flash:
            checks.append(_check_flash_tool(node_name, getattr(node_cfg.flash, "backend", "")))

        reset_method = getattr(node_cfg.reset, "method", "none")
        checks.append(_check_reset_tool(node_name, reset_method))

        for transport_name, transport in node_cfg.transports.items():
            checks.append(_check_transport(node_name, transport_name, transport))

        for line_name, gpio_cfg in node_cfg.gpio.items():
            checks.append(_check_gpio(node_name, line_name, gpio_cfg))

    for resource_name, resource_cfg in bench.resources.items():
        checks.append(_check_resource(resource_name, resource_cfg))

    if open_hardware:
        if log_dir is None:
            root = Path(tempfile.mkdtemp(prefix="benchci-self-test-"))
        else:
            root = Path(log_dir).expanduser().resolve()
            root.mkdir(parents=True, exist_ok=True)

        _append_self_test_log(
            root / "self-test.log",
            f"HARDWARE_OPEN_MODE bench={bench.bench.name} read_inputs={read_inputs} read_measurements={read_measurements}",
        )

        checks.append(
            DiagnosticCheck(
                id="hardware_open_mode",
                title="Hardware open checks",
                status="pass",
                severity="info",
                source="bench_infrastructure",
                message="Hardware open checks are enabled. BenchCI will open configured transports/resources, but will not flash, reset, toggle relays, or drive GPIO outputs.",
                required=False,
                details={
                    "log_dir": str(root),
                    "read_inputs": read_inputs,
                    "read_measurements": read_measurements,
                },
            )
        )

        checks.extend(
            _run_hardware_open_checks(
                bench,
                log_root=root,
                read_inputs=read_inputs,
                read_measurements=read_measurements,
            )
        )

    status = derive_health_status(checks)
    return BenchSelfTestReport(
        bench_name=bench.bench.name,
        bench_path=str(path),
        checked_at=utc_now(),
        health_status=status,
        summary=summarize_health(status, checks),
        checks=checks,
    )


def render_human_report(report: BenchSelfTestReport) -> str:
    payload = report.to_dict()
    lines: list[str] = []

    lines.append("=" * 72)
    lines.append("BENCHCI BENCH SELF-TEST")
    lines.append("=" * 72)
    lines.append(f"Bench: {payload['bench'].get('name') or '—'}")
    lines.append(f"Path: {payload['bench'].get('path')}")
    lines.append(f"Health: {payload['health_status']}")
    lines.append(f"Summary: {payload['summary']}")
    lines.append("")

    for check in payload["checks"]:
        status = check["status"].upper()
        title = check["title"]
        message = check.get("message") or ""
        lines.append(f"[{status:4}] {title}")
        if message:
            lines.append(f"       {message}")
        if check.get("category"):
            lines.append(f"       category: {check['category']}")
        if check.get("source"):
            lines.append(f"       source: {check['source']}")
        if check.get("suggested_fix"):
            lines.append(f"       suggested fix: {check['suggested_fix']}")
        lines.append("")

    counts = payload["counts"]
    lines.append(
        f"Summary: {counts['passed']} passed, "
        f"{counts['warnings']} warnings, "
        f"{counts['failed']} failed, "
        f"{counts['skipped']} skipped"
    )

    return "\n".join(lines)


def run_bench_self_test(
    *,
    bench_path: str | Path,
    output_path: str | Path = "bench-self-test.json",
    json_output: bool = False,
    open_hardware: bool = False,
    read_inputs: bool = False,
    read_measurements: bool = False,
    log_dir: str | Path | None = None,
) -> int:
    report = build_bench_self_test_report(
        bench_path,
        open_hardware=open_hardware,
        read_inputs=read_inputs,
        read_measurements=read_measurements,
        log_dir=log_dir,
    )
    payload = report.to_dict()

    out = Path(output_path).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    if open_hardware:
        resolved_log_dir = None
        hardware_check = next(
            (check for check in payload.get("checks", []) if check.get("id") == "hardware_open_mode"),
            None,
        )
        if isinstance(hardware_check, dict):
            details = hardware_check.get("details")
            if isinstance(details, dict):
                resolved_log_dir = details.get("log_dir")
        if resolved_log_dir:
            summary_path = Path(str(resolved_log_dir)).expanduser().resolve() / "self-test-summary.json"
            summary_path.parent.mkdir(parents=True, exist_ok=True)
            summary_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    if json_output:
        typer.echo(json.dumps(payload, indent=2))
    else:
        typer.echo(render_human_report(report))
        typer.echo("")
        typer.echo(f"[INFO] Self-test JSON saved to: {out}")
        if open_hardware:
            hardware_check = next(
                (check for check in payload.get("checks", []) if check.get("id") == "hardware_open_mode"),
                None,
            )
            details = hardware_check.get("details") if isinstance(hardware_check, dict) else None
            if isinstance(details, dict) and details.get("log_dir"):
                typer.echo(f"[INFO] Self-test logs saved to: {details['log_dir']}")

    return 0 if report.health_status in {"healthy", "degraded"} else 1