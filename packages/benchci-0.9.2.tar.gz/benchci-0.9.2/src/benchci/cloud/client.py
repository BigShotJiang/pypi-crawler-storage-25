from __future__ import annotations

import base64
import json
import time
from pathlib import Path
from typing import Any, Callable

import httpx


def _normalize_base_url(base_url: str) -> str:
    return base_url.rstrip("/")


def _build_headers(access_token: str | None = None, workspace_id: str | None = None) -> dict[str, str]:
    headers: dict[str, str] = {}
    if access_token:
        headers["Authorization"] = f"Bearer {access_token}"
    if workspace_id:
        headers["X-BenchCI-Workspace"] = workspace_id
    return headers


def _extract_error_detail(response: httpx.Response) -> str | None:
    try:
        body = response.json()
        detail = body.get("detail") or body.get("error")
        if isinstance(detail, str) and detail.strip():
            return detail.strip()
        if isinstance(detail, list):
            return "Request validation failed. Please check your input."
    except Exception:
        pass
    return None


def _raise_http_error_with_context(exc: httpx.HTTPStatusError, action: str) -> None:
    status = exc.response.status_code
    detail = _extract_error_detail(exc.response)

    if detail:
        raise RuntimeError(detail)

    if status == 400:
        raise RuntimeError("Request was invalid. Please check your input.")
    if status == 401:
        raise RuntimeError("Authentication failed. Please run 'benchci login' again.")
    if status == 403:
        raise RuntimeError("You do not have permission to perform this action.")
    if status == 404:
        raise RuntimeError("Requested resource was not found.")
    if status == 409:
        raise RuntimeError("This action conflicts with the current BenchCI state.")
    if status == 422:
        raise RuntimeError("Request validation failed. Please check your input.")
    if status == 429:
        raise RuntimeError("Too many requests. Please try again shortly.")
    if status >= 500:
        raise RuntimeError("BenchCI service is temporarily unavailable. Please try again later.")

    raise RuntimeError(f"{action} failed.")

def list_benches(api_base_url: str, access_token: str, workspace_id: str | None = None, timeout_s: float = 15.0) -> list[dict[str, Any]]:
    api_base_url = _normalize_base_url(api_base_url)
    headers = _build_headers(access_token, workspace_id)

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.get(f"{api_base_url}/v1/cloud/benches", headers=headers)
            response.raise_for_status()
            data = response.json()
            if not isinstance(data, list):
                raise RuntimeError("Backend returned an unexpected bench list payload")
            return data
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, "Listing cloud benches")
    except httpx.HTTPError as exc:
        raise RuntimeError("Listing cloud benches failed.")
    except ValueError:
        raise RuntimeError("Backend returned an unreadable response while listing benches.")


def get_bench(api_base_url: str, bench_id: str, access_token: str, workspace_id: str | None = None, timeout_s: float = 15.0) -> dict[str, Any]:
    api_base_url = _normalize_base_url(api_base_url)
    headers = _build_headers(access_token, workspace_id)

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.get(f"{api_base_url}/v1/cloud/benches/{bench_id}", headers=headers)
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, f"Fetching cloud bench '{bench_id}'")
    except httpx.HTTPError as exc:
        raise RuntimeError("Fetching cloud bench failed.")
    except ValueError:
        raise RuntimeError("Backend returned an unreadable response while fetching bench.")


def submit_cloud_run(
    api_base_url: str,
    access_token: str,
    suite_path: str | Path,
    artifact_path: str | Path | None = None,
    *,
    bench_id: str | None = None,
    requirements: dict[str, Any] | None = None,
    skip_flash: bool = False,
    verbose: bool = False,
    evidence_context: dict[str, Any] | None = None,
    workspace_id: str | None = None,
    timeout_s: float = 60.0,
) -> dict[str, Any]:
    api_base_url = _normalize_base_url(api_base_url)
    headers = _build_headers(access_token, workspace_id)
    headers["Content-Type"] = "application/json"

    suite_file = Path(suite_path).expanduser().resolve()
    if not suite_file.exists():
        raise RuntimeError("Suite file was not found.")

    artifact_file = Path(artifact_path).expanduser().resolve() if artifact_path else None
    if not skip_flash:
        if artifact_file is None:
            raise RuntimeError("Artifact path is required for cloud runs unless --skip-flash is used.")
        if not artifact_file.exists():
            raise RuntimeError("Artifact file was not found.")

    payload: dict[str, Any] = {
        "suite_yaml": suite_file.read_text(encoding="utf-8"),
        "skip_flash": skip_flash,
        "verbose": verbose,
    }

    if bench_id:
        payload["bench_id"] = bench_id
    if requirements:
        payload["requirements"] = requirements
    if evidence_context:
        payload["evidence_context"] = evidence_context

    if artifact_file is not None:
        payload["artifact_filename"] = artifact_file.name
        payload["artifact_base64"] = base64.b64encode(artifact_file.read_bytes()).decode("ascii")

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.post(
                f"{api_base_url}/v1/cloud/runs",
                content=json.dumps(payload),
                headers=headers,
            )
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, "Submitting cloud run")
    except httpx.HTTPError as exc:
        raise RuntimeError("Submitting cloud run failed.")
    except ValueError:
        raise RuntimeError("Backend returned an unreadable response while submitting run. Please try again.")


def list_runs(api_base_url: str, access_token: str, workspace_id: str | None = None, timeout_s: float = 15.0) -> list[dict[str, Any]]:
    api_base_url = _normalize_base_url(api_base_url)
    headers = _build_headers(access_token, workspace_id)

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.get(f"{api_base_url}/v1/cloud/runs", headers=headers)
            response.raise_for_status()
            data = response.json()
            if isinstance(data, list):
                return data
            if isinstance(data, dict) and "runs" in data:
                return data["runs"]
            raise RuntimeError("Backend returned an unexpected cloud run list payload")
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, "Listing cloud runs")
    except httpx.HTTPError as exc:
        raise RuntimeError("Listing cloud runs failed.")
    except ValueError:
        raise RuntimeError("Backend returned an unreadable response while listing runs.")


def get_run(api_base_url: str, run_id: str, access_token: str, workspace_id: str | None = None, timeout_s: float = 15.0) -> dict[str, Any]:
    api_base_url = _normalize_base_url(api_base_url)
    headers = _build_headers(access_token, workspace_id)

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.get(f"{api_base_url}/v1/cloud/runs/{run_id}", headers=headers)
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, f"Fetching cloud run '{run_id}'")
    except httpx.HTTPError as exc:
        raise RuntimeError("Fetching cloud run failed.")
    except ValueError:
        raise RuntimeError(f"Backend returned an unreadable response while fetching run '{run_id}'.")


def get_run_events(api_base_url: str, run_id: str, access_token: str, workspace_id: str | None = None, timeout_s: float = 15.0) -> dict[str, Any]:
    api_base_url = _normalize_base_url(api_base_url)
    headers = _build_headers(access_token, workspace_id)

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.get(f"{api_base_url}/v1/cloud/runs/{run_id}/events", headers=headers)
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, f"Fetching cloud run events for '{run_id}'")
    except httpx.HTTPError as exc:
        raise RuntimeError("Fetching cloud run events failed.")
    except ValueError:
        raise RuntimeError(f"Backend returned an unreadable response while fetching events for run '{run_id}'.")


def wait_run(
    api_base_url: str,
    run_id: str,
    access_token: str,
    *,
    workspace_id: str | None = None,
    poll_interval_s: float = 1.0,
    timeout_s: float = 1800.0,
    on_update: Callable[[dict[str, Any]], Any] | None = None,
    on_event: Callable[[dict[str, Any]], Any] | None = None,
) -> dict[str, Any]:
    start = time.time()
    last_status_key: tuple[Any, ...] | None = None
    seen_events = 0
    terminal_states = {"done", "failed"}

    while True:
        status = get_run(api_base_url, run_id, access_token, workspace_id=workspace_id)
        status_key = (
            status.get("status"),
            status.get("exit_code"),
            status.get("error"),
            status.get("started_at"),
            status.get("finished_at"),
            status.get("assigned_agent_id"),
            status.get("assigned_bench_id"),
        )

        if status_key != last_status_key:
            last_status_key = status_key
            if on_update is not None:
                on_update(status)

        events_payload = get_run_events(api_base_url, run_id, access_token, workspace_id=workspace_id)
        events = list(events_payload.get("events", []))
        if seen_events < len(events):
            for event in events[seen_events:]:
                if on_event is not None:
                    on_event(event)
            seen_events = len(events)

        if status.get("status") in terminal_states:
            return status

        if time.time() - start > timeout_s:
            raise TimeoutError(f"Timed out waiting for cloud run '{run_id}' after {timeout_s:.1f}s")

        time.sleep(poll_interval_s)


def download_artifacts(
    api_base_url: str,
    run_id: str,
    access_token: str,
    out_zip_path: str | Path,
    workspace_id: str | None = None,
    timeout_s: float = 120.0,
) -> Path:
    api_base_url = _normalize_base_url(api_base_url)
    out_path = Path(out_zip_path).expanduser().resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    headers = _build_headers(access_token, workspace_id)

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.get(f"{api_base_url}/v1/cloud/runs/{run_id}/artifacts.zip", headers=headers)
            response.raise_for_status()
            out_path.write_bytes(response.content)
            return out_path
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, f"Downloading cloud artifacts for '{run_id}'")
    except httpx.HTTPError as exc:
        raise RuntimeError("Downloading cloud artifacts failed.")


def create_bundle(
    api_base_url: str,
    access_token: str,
    name: str,
    run_ids: list[str],
    *,
    version: str | None = None,
    description: str | None = None,
    workspace_id: str | None = None,
    timeout_s: float = 120.0,
) -> dict[str, Any]:
    api_base_url = _normalize_base_url(api_base_url)
    headers = _build_headers(access_token, workspace_id)
    headers["Content-Type"] = "application/json"

    payload: dict[str, Any] = {"name": name, "run_ids": run_ids}
    if version:
        payload["version"] = version
    if description:
        payload["description"] = description

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.post(
                f"{api_base_url}/v1/cloud/releases",
                content=json.dumps(payload),
                headers=headers,
            )
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, "Creating release bundle")
    except httpx.HTTPError as exc:
        raise RuntimeError("Creating release bundle failed.")
    except ValueError:
        raise RuntimeError("Backend returned an unreadable response while creating release bundle.")


def list_bundles(
    api_base_url: str,
    access_token: str,
    workspace_id: str | None = None,
    timeout_s: float = 15.0,
) -> dict[str, Any]:
    api_base_url = _normalize_base_url(api_base_url)
    headers = _build_headers(access_token, workspace_id)

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.get(f"{api_base_url}/v1/cloud/releases", headers=headers)
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, "Listing release bundles")
    except httpx.HTTPError as exc:
        raise RuntimeError("Listing release bundles failed.")
    except ValueError:
        raise RuntimeError("Backend returned an unreadable response while listing release bundles.")


def get_bundle(
    api_base_url: str,
    bundle_id: str,
    access_token: str,
    workspace_id: str | None = None,
    timeout_s: float = 15.0,
) -> dict[str, Any]:
    api_base_url = _normalize_base_url(api_base_url)
    headers = _build_headers(access_token, workspace_id)

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.get(f"{api_base_url}/v1/cloud/releases/{bundle_id}", headers=headers)
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, f"Fetching release bundle '{bundle_id}'")
    except httpx.HTTPError as exc:
        raise RuntimeError("Fetching release bundle failed.")
    except ValueError:
        raise RuntimeError("Backend returned an unreadable response while fetching release bundle.")


def download_bundle(
    api_base_url: str,
    bundle_id: str,
    access_token: str,
    out_zip_path: str | Path,
    workspace_id: str | None = None,
    timeout_s: float = 120.0,
) -> Path:
    api_base_url = _normalize_base_url(api_base_url)
    out_path = Path(out_zip_path).expanduser().resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    headers = _build_headers(access_token, workspace_id)

    try:
        with httpx.Client(timeout=timeout_s) as client:
            response = client.get(
                f"{api_base_url}/v1/cloud/releases/{bundle_id}/download",
                headers=headers,
            )
            response.raise_for_status()
            out_path.write_bytes(response.content)
            return out_path
    except httpx.HTTPStatusError as exc:
        _raise_http_error_with_context(exc, f"Downloading release bundle '{bundle_id}'")
    except httpx.HTTPError as exc:
        raise RuntimeError("Downloading release bundle failed.")
