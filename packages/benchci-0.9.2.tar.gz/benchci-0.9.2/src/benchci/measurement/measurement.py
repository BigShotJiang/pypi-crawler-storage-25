from __future__ import annotations

import json
import re
import socket
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib import request as urlrequest
from urllib.parse import urlparse

from benchci.config.bench import (
    BenchConfig,
    ResourceConfig,
    ResourceDriverHttpMeasurement,
    ResourceDriverMockMeasurement,
    ResourceDriverScpiMeasurement,
    ResourceDriverScpiPowerSupplyMeasurement,
)


_FLOAT_RE = re.compile(
    r"[-+]?(?:(?:\d+(?:\.\d*)?)|(?:\.\d+))(?:[eE][-+]?\d+)?"
)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _duration_ms(started_monotonic: float) -> int:
    return int(round((time.monotonic() - started_monotonic) * 1000.0))


def _short_transaction_id() -> str:
    return uuid.uuid4().hex[:12]


def _truncate(value: object, limit: int = 500) -> str:
    text = str(value)
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "…"


def _json_dumps(payload: dict[str, Any]) -> str:
    return json.dumps(payload, sort_keys=True, default=str)


def _parse_first_float(text: str) -> float:
    match = _FLOAT_RE.search(text.strip())
    if not match:
        raise RuntimeError(f"SCPI response did not contain a numeric value: {text!r}")
    return float(match.group(0))


def _power_supply_channel_token(channel: int | None) -> str | None:
    if channel is None:
        return None
    return f"CH{int(channel)}"


def _power_supply_query_for_quantity(
    quantity: str,
    *,
    preset: str = "generic",
    channel: int | None = None,
) -> str:
    """Return a conservative SCPI readback query for a power supply preset.

    Presets in v0.8.0 intentionally cover measurement readback only. They do
    not imply full model support, output control, setpoint control, or channel
    discovery.
    """
    normalized_quantity = str(quantity or "").strip().lower()
    normalized_preset = str(preset or "generic").strip().lower()
    channel_token = _power_supply_channel_token(channel)

    if normalized_quantity not in {"current", "voltage"}:
        raise RuntimeError(
            f"Unsupported SCPI power supply measurement quantity {quantity!r}. "
            "Supported quantities are current and voltage."
        )

    if normalized_preset in {"generic", "owon_sp"}:
        if normalized_quantity == "current":
            return "MEAS:CURR?"
        return "MEAS:VOLT?"

    if normalized_preset == "rigol_dp_basic":
        if normalized_quantity == "current":
            return f":MEAS:CURR? {channel_token}" if channel_token else ":MEAS:CURR?"
        return f":MEAS:VOLT? {channel_token}" if channel_token else ":MEAS:VOLT?"

    if normalized_preset in {"keysight_basic", "keysight_e36300_basic"}:
        if normalized_quantity == "current":
            return f"MEAS:CURR? {channel_token}" if channel_token else "MEAS:CURR?"
        return f"MEAS:VOLT? {channel_token}" if channel_token else "MEAS:VOLT?"

    raise RuntimeError(
        f"Unsupported SCPI power supply preset {preset!r}. Supported presets are: "
        "generic, owon_sp, rigol_dp_basic, keysight_basic, keysight_e36300_basic."
    )


def _default_unit_for_power_supply_quantity(quantity: str) -> str | None:
    normalized = str(quantity or "").strip().lower()
    if normalized == "current":
        return "A"
    if normalized == "voltage":
        return "V"
    return None


class _LogMixin:
    _log_path: Path | None

    def _log(self, message: str) -> None:
        if self._log_path is None:
            return
        self._log_path.parent.mkdir(parents=True, exist_ok=True)
        with self._log_path.open("a", encoding="utf-8") as f:
            f.write(f"{_utc_now()} {message}\n")

    def _log_event(self, event: str, **fields: object) -> None:
        rendered_fields = " ".join(
            f"{key}={value!r}" for key, value in fields.items() if value is not None
        )
        if rendered_fields:
            self._log(f"{event} {rendered_fields}")
        else:
            self._log(event)


class MeasurementController:
    """Abstract bench-level measurement controller.

    Suite files ask BenchCI to measure a named resource. Concrete controllers
    hide whether the value comes from a mock, HTTP lab controller, SCPI supply,
    USB meter, oscilloscope, or another vendor-specific instrument.
    """

    def start(self) -> None:
        pass

    def stop(self) -> None:
        pass

    def measure(self) -> dict[str, Any]:
        raise NotImplementedError


class MockMeasurementController(_LogMixin, MeasurementController):
    """Deterministic measurement backend for tests, demos, and CI dry-runs."""

    def __init__(self, resource_name: str, cfg: ResourceConfig, log_path: Path | None = None):
        if not isinstance(cfg.driver, ResourceDriverMockMeasurement):
            raise RuntimeError("MockMeasurementController requires ResourceDriverMockMeasurement")
        self._resource_name = resource_name
        self._driver = cfg.driver
        self._log_path = log_path

    def start(self) -> None:
        self._log_event(
            "MOCK_MEASUREMENT_START",
            resource=self._resource_name,
            value=self._driver.value,
            unit=self._driver.unit,
        )

    def stop(self) -> None:
        self._log_event("MOCK_MEASUREMENT_STOP", resource=self._resource_name)

    def measure(self) -> dict[str, Any]:
        payload = {
            "resource": self._resource_name,
            "value": float(self._driver.value),
            "unit": self._driver.unit,
            "quantity": self._driver.quantity,
            "timestamp": _utc_now(),
            "backend": self._driver.type,
        }
        self._log_event("MOCK_MEASURE", payload=_json_dumps(payload))
        return payload


class HttpMeasurementController(_LogMixin, MeasurementController):
    """Measurement backend for simple HTTP lab controllers.

    The endpoint may return a plain number, or JSON such as:
      {"value": 0.042, "unit": "A"}
    """

    def __init__(self, resource_name: str, cfg: ResourceConfig, log_path: Path | None = None):
        if not isinstance(cfg.driver, ResourceDriverHttpMeasurement):
            raise RuntimeError("HttpMeasurementController requires ResourceDriverHttpMeasurement")
        self._resource_name = resource_name
        self._driver = cfg.driver
        self._log_path = log_path

    def _request(self) -> str:
        req = urlrequest.Request(self._driver.url, method="GET")
        for key, value in self._driver.headers.items():
            req.add_header(key, value)
        started = time.monotonic()
        self._log_event(
            "HTTP_MEASURE_TX",
            resource=self._resource_name,
            url=self._driver.url,
            timeout_ms=self._driver.timeout_ms,
        )
        try:
            with urlrequest.urlopen(req, timeout=self._driver.timeout_ms / 1000.0) as resp:
                body = resp.read(4096).decode("utf-8", errors="replace")
                self._log_event(
                    "HTTP_MEASURE_RX",
                    resource=self._resource_name,
                    status=getattr(resp, "status", None),
                    duration_ms=_duration_ms(started),
                    body=_truncate(body, 300),
                )
                return body
        except Exception as exc:
            self._log_event(
                "HTTP_MEASURE_ERROR",
                resource=self._resource_name,
                duration_ms=_duration_ms(started),
                error_type=type(exc).__name__,
                error=_truncate(exc, 300),
            )
            raise RuntimeError("HTTP measurement request failed.")

    def _extract_value(self, body: str) -> tuple[float, str | None]:
        text = body.strip()
        try:
            parsed = json.loads(text)
        except Exception:
            return float(text), None

        if isinstance(parsed, (int, float)):
            return float(parsed), None

        if isinstance(parsed, dict):
            raw_value = parsed.get(self._driver.value_field)
            raw_unit = parsed.get(self._driver.unit_field) if self._driver.unit_field else None
            if raw_value is None:
                raise RuntimeError(
                    f"HTTP measurement response did not contain value field '{self._driver.value_field}'."
                )
            return float(raw_value), str(raw_unit) if raw_unit is not None else None

        raise RuntimeError("HTTP measurement response must be a number or JSON object.")

    def measure(self) -> dict[str, Any]:
        value, observed_unit = self._extract_value(self._request())
        payload = {
            "resource": self._resource_name,
            "value": value,
            "unit": observed_unit or self._driver.unit,
            "quantity": self._driver.quantity,
            "timestamp": _utc_now(),
            "backend": self._driver.type,
        }
        self._log_event("HTTP_MEASURE", payload=_json_dumps(payload))
        return payload


class ScpiMeasurementController(_LogMixin, MeasurementController):
    """Measurement backend for SCPI instruments over TCP, serial, or VISA/USB."""

    def __init__(self, resource_name: str, cfg: ResourceConfig, log_path: Path | None = None):
        if not isinstance(
            cfg.driver,
            (ResourceDriverScpiMeasurement, ResourceDriverScpiPowerSupplyMeasurement),
        ):
            raise RuntimeError(
                "ScpiMeasurementController requires ResourceDriverScpiMeasurement "
                "or ResourceDriverScpiPowerSupplyMeasurement"
            )
        self._resource_name = resource_name
        self._driver = cfg.driver
        self._log_path = log_path

    def _preset(self) -> str | None:
        return getattr(self._driver, "preset", None)

    def _query_text(self) -> str:
        if isinstance(self._driver, ResourceDriverScpiPowerSupplyMeasurement):
            return _power_supply_query_for_quantity(
                self._driver.quantity,
                preset=self._driver.preset,
                channel=self._driver.channel,
            )
        return self._driver.query

    def _quantity(self) -> str:
        return self._driver.quantity

    def _unit(self) -> str | None:
        if isinstance(self._driver, ResourceDriverScpiPowerSupplyMeasurement):
            return self._driver.unit or _default_unit_for_power_supply_quantity(self._driver.quantity)
        return self._driver.unit

    def _channel(self) -> int | None:
        return getattr(self._driver, "channel", None)

    def _query_source(self) -> str:
        if isinstance(self._driver, ResourceDriverScpiPowerSupplyMeasurement):
            return f"power_supply_preset:{self._driver.preset}"
        return "configured_query"

    def start(self) -> None:
        self._log_event(
            "SCPI_MEASUREMENT_START",
            resource=self._resource_name,
            backend=self._driver.type,
            address=self._driver.address,
            query=self._query_text(),
            query_source=self._query_source(),
            preset=self._preset(),
            quantity=self._quantity(),
            unit=self._unit(),
            channel=self._channel(),
            timeout_ms=self._driver.timeout_ms,
        )

    def stop(self) -> None:
        self._log_event("SCPI_MEASUREMENT_STOP", resource=self._resource_name)

    def _query_tcp(self, transaction_id: str) -> str:
        parsed = urlparse(self._driver.address)
        host = parsed.hostname
        port = parsed.port

        if not host or not port:
            raise RuntimeError(
                f"Invalid TCP SCPI address '{self._driver.address}'. Expected tcp://host:port"
            )

        timeout_s = self._driver.timeout_ms / 1000.0
        query = self._query_text()
        command = query + self._driver.write_termination
        started = time.monotonic()

        self._log_event(
            "SCPI_TCP_CONNECT_BEGIN",
            tx=transaction_id,
            resource=self._resource_name,
            host=host,
            port=port,
            timeout_ms=self._driver.timeout_ms,
        )

        try:
            with socket.create_connection((host, port), timeout=timeout_s) as sock:
                sock.settimeout(timeout_s)
                self._log_event(
                    "SCPI_TCP_CONNECT_OK",
                    tx=transaction_id,
                    resource=self._resource_name,
                    duration_ms=_duration_ms(started),
                )
                self._log_event(
                    "SCPI_TX",
                    tx=transaction_id,
                    resource=self._resource_name,
                    transport="tcp",
                    query=query,
                    query_source=self._query_source(),
                    preset=self._preset(),
                    channel=self._channel(),
                    write_termination=repr(self._driver.write_termination),
                )
                sock.sendall(command.encode("utf-8"))

                chunks: list[bytes] = []
                read_termination = self._driver.read_termination.encode("utf-8")

                while True:
                    chunk = sock.recv(4096)
                    if not chunk:
                        break
                    chunks.append(chunk)
                    if read_termination and read_termination in b"".join(chunks):
                        break

                raw_bytes = b"".join(chunks)
                raw = raw_bytes.decode("utf-8", errors="replace")
                self._log_event(
                    "SCPI_RX",
                    tx=transaction_id,
                    resource=self._resource_name,
                    transport="tcp",
                    duration_ms=_duration_ms(started),
                    bytes=len(raw_bytes),
                    raw=_truncate(raw, 500),
                )
                return raw

        except TimeoutError as exc:
            self._log_event(
                "SCPI_ERROR",
                tx=transaction_id,
                resource=self._resource_name,
                transport="tcp",
                stage="query",
                duration_ms=_duration_ms(started),
                error_type=type(exc).__name__,
                error=_truncate(exc, 300),
            )
            raise RuntimeError("TCP SCPI measurement timed out.")
        except OSError as exc:
            self._log_event(
                "SCPI_ERROR",
                tx=transaction_id,
                resource=self._resource_name,
                transport="tcp",
                stage="query",
                duration_ms=_duration_ms(started),
                error_type=type(exc).__name__,
                error=_truncate(exc, 300),
            )
            raise RuntimeError("TCP SCPI measurement request failed.")
        finally:
            self._log_event(
                "SCPI_TCP_CLOSED",
                tx=transaction_id,
                resource=self._resource_name,
                duration_ms=_duration_ms(started),
            )

    def _serial_port_from_address(self) -> str:
        address = self._driver.address

        if address.startswith("serial:///"):
            return address[len("serial://") :]

        if address.lower().startswith("serial://"):
            return address[len("serial://") :]

        raise RuntimeError(
            f"Invalid serial SCPI address '{address}'. Expected serial:///dev/ttyUSB0 or serial://COM3"
        )

    def _query_serial(self, transaction_id: str) -> str:
        try:
            import serial
        except ImportError:
            raise RuntimeError("Serial SCPI requires pyserial. Install BenchCI with serial support.")

        port = self._serial_port_from_address()
        timeout_s = self._driver.timeout_ms / 1000.0
        query = self._query_text()
        started = time.monotonic()

        self._log_event(
            "SCPI_SERIAL_OPEN_BEGIN",
            tx=transaction_id,
            resource=self._resource_name,
            port=port,
            baudrate=self._driver.baudrate,
            bytesize=self._driver.bytesize,
            parity=self._driver.parity,
            stopbits=self._driver.stopbits,
            timeout_ms=self._driver.timeout_ms,
        )

        try:
            with serial.Serial(
                port=port,
                baudrate=self._driver.baudrate,
                bytesize=self._driver.bytesize,
                parity=self._driver.parity,
                stopbits=self._driver.stopbits,
                timeout=timeout_s,
                write_timeout=timeout_s,
            ) as ser:
                self._log_event(
                    "SCPI_SERIAL_OPEN_OK",
                    tx=transaction_id,
                    resource=self._resource_name,
                    duration_ms=_duration_ms(started),
                )
                ser.reset_input_buffer()
                self._log_event(
                    "SCPI_TX",
                    tx=transaction_id,
                    resource=self._resource_name,
                    transport="serial",
                    query=query,
                    query_source=self._query_source(),
                    preset=self._preset(),
                    channel=self._channel(),
                    write_termination=repr(self._driver.write_termination),
                )
                ser.write((query + self._driver.write_termination).encode("utf-8"))
                ser.flush()
                raw_bytes = ser.readline()
                raw = raw_bytes.decode("utf-8", errors="replace")
                self._log_event(
                    "SCPI_RX",
                    tx=transaction_id,
                    resource=self._resource_name,
                    transport="serial",
                    duration_ms=_duration_ms(started),
                    bytes=len(raw_bytes),
                    raw=_truncate(raw, 500),
                )
                return raw

        except Exception as exc:
            self._log_event(
                "SCPI_ERROR",
                tx=transaction_id,
                resource=self._resource_name,
                transport="serial",
                stage="query",
                duration_ms=_duration_ms(started),
                error_type=type(exc).__name__,
                error=_truncate(exc, 300),
            )
            raise RuntimeError("Serial SCPI measurement request failed.")
        finally:
            self._log_event(
                "SCPI_SERIAL_CLOSED",
                tx=transaction_id,
                resource=self._resource_name,
                duration_ms=_duration_ms(started),
            )

    def _query_visa(self, transaction_id: str) -> str:
        try:
            import pyvisa
        except ImportError:
            raise RuntimeError(
                "USB/VISA SCPI requires pyvisa. Install BenchCI with the scpi extra."
            )

        timeout_ms = int(self._driver.timeout_ms)
        address = self._driver.address
        query = self._query_text()
        started = time.monotonic()

        self._log_event(
            "SCPI_VISA_OPEN_BEGIN",
            tx=transaction_id,
            resource=self._resource_name,
            address=address,
            timeout_ms=timeout_ms,
        )

        rm = None
        inst = None
        try:
            rm = pyvisa.ResourceManager()
            inst = rm.open_resource(address)
            self._log_event(
                "SCPI_VISA_OPEN_OK",
                tx=transaction_id,
                resource=self._resource_name,
                duration_ms=_duration_ms(started),
            )
            inst.timeout = timeout_ms
            if hasattr(inst, "write_termination"):
                inst.write_termination = self._driver.write_termination
            if hasattr(inst, "read_termination"):
                inst.read_termination = self._driver.read_termination

            self._log_event(
                "SCPI_TX",
                tx=transaction_id,
                resource=self._resource_name,
                transport="visa",
                query=query,
                query_source=self._query_source(),
                channel=self._channel(),
                write_termination=repr(self._driver.write_termination),
                read_termination=repr(self._driver.read_termination),
            )
            raw = str(inst.query(query))
            self._log_event(
                "SCPI_RX",
                tx=transaction_id,
                resource=self._resource_name,
                transport="visa",
                duration_ms=_duration_ms(started),
                bytes=len(raw.encode("utf-8", errors="replace")),
                raw=_truncate(raw, 500),
            )
            return raw

        except Exception as exc:
            self._log_event(
                "SCPI_ERROR",
                tx=transaction_id,
                resource=self._resource_name,
                transport="visa",
                stage="query",
                duration_ms=_duration_ms(started),
                error_type=type(exc).__name__,
                error=_truncate(exc, 300),
            )
            raise RuntimeError("USB/VISA SCPI measurement request failed.")
        finally:
            if inst is not None:
                try:
                    inst.close()
                except Exception as exc:
                    self._log_event(
                        "SCPI_VISA_CLOSE_WARNING",
                        tx=transaction_id,
                        resource=self._resource_name,
                        error_type=type(exc).__name__,
                        error=_truncate(exc, 300),
                    )
            if rm is not None:
                try:
                    rm.close()
                except Exception as exc:
                    self._log_event(
                        "SCPI_VISA_RESOURCE_MANAGER_CLOSE_WARNING",
                        tx=transaction_id,
                        resource=self._resource_name,
                        error_type=type(exc).__name__,
                        error=_truncate(exc, 300),
                    )
            self._log_event(
                "SCPI_VISA_CLOSED",
                tx=transaction_id,
                resource=self._resource_name,
                duration_ms=_duration_ms(started),
            )

    def _query(self, transaction_id: str) -> tuple[str, str]:
        address = self._driver.address.strip()
        lower = address.lower()

        if lower.startswith("tcp://"):
            return self._query_tcp(transaction_id), "tcp"

        if lower.startswith("serial://"):
            return self._query_serial(transaction_id), "serial"

        # VISA resource strings commonly look like:
        #   USB0::0x1234::0x5678::INSTR
        #   USB::0x1234::0x5678::INSTR
        #   TCPIP0::192.168.1.50::INSTR
        #   ASRL/dev/ttyUSB0::INSTR
        #   ASRL3::INSTR
        if (
            lower.startswith("usb")
            or lower.startswith("tcpip")
            or lower.startswith("asrl")
            or "::" in address
        ):
            return self._query_visa(transaction_id), "visa"

        raise RuntimeError(
            f"Unsupported SCPI address '{address}'. "
            "Supported forms: tcp://host:port, serial:///dev/ttyUSB0, serial://COM3, or VISA resource strings."
        )

    def measure(self) -> dict[str, Any]:
        transaction_id = _short_transaction_id()
        started = time.monotonic()
        query = self._query_text()
        unit = self._unit()
        quantity = self._quantity()
        channel = self._channel()

        self._log_event(
            "SCPI_MEASURE_BEGIN",
            tx=transaction_id,
            resource=self._resource_name,
            backend=self._driver.type,
            address=self._driver.address,
            query=query,
            query_source=self._query_source(),
            quantity=quantity,
            unit=unit,
            channel=channel,
        )

        try:
            raw_response, transport = self._query(transaction_id)
            value = _parse_first_float(raw_response)
            self._log_event(
                "SCPI_PARSE_OK",
                tx=transaction_id,
                resource=self._resource_name,
                value=value,
                unit=unit,
                quantity=quantity,
                channel=channel,
            )

            payload = {
                "resource": self._resource_name,
                "value": value,
                "unit": unit,
                "quantity": quantity,
                "timestamp": _utc_now(),
                "backend": self._driver.type,
                "transport": transport,
                "address": self._driver.address,
                "query": query,
                "query_source": self._query_source(),
                "preset": self._preset(),
                "raw_response": raw_response,
            }
            if channel is not None:
                payload["channel"] = channel
            self._log_event(
                "SCPI_MEASURE_END",
                tx=transaction_id,
                resource=self._resource_name,
                status="ok",
                duration_ms=_duration_ms(started),
                payload=_json_dumps(payload),
            )
            return payload

        except Exception as exc:
            self._log_event(
                "SCPI_MEASURE_END",
                tx=transaction_id,
                resource=self._resource_name,
                status="error",
                duration_ms=_duration_ms(started),
                error_type=type(exc).__name__,
                error=_truncate(exc, 300),
            )
            raise


class MeasurementManager:
    def __init__(self, controller: MeasurementController):
        self._controller = controller

    def start(self) -> None:
        self._controller.start()

    def stop(self) -> None:
        self._controller.stop()

    def measure(self) -> dict[str, Any]:
        return self._controller.measure()


def create_measurement_manager(bench: BenchConfig, resource_name: str, log_path: Path | None = None) -> MeasurementManager:
    cfg = bench.resources.get(resource_name)
    if cfg is None:
        known = ", ".join(sorted(bench.resources.keys())) or "<none>"
        raise RuntimeError(f"Unknown bench resource '{resource_name}'. Known resources: {known}")

    driver = cfg.driver
    if isinstance(driver, ResourceDriverMockMeasurement):
        return MeasurementManager(MockMeasurementController(resource_name, cfg, log_path))
    if isinstance(driver, ResourceDriverHttpMeasurement):
        return MeasurementManager(HttpMeasurementController(resource_name, cfg, log_path))
    if isinstance(driver, (ResourceDriverScpiMeasurement, ResourceDriverScpiPowerSupplyMeasurement)):
        return MeasurementManager(ScpiMeasurementController(resource_name, cfg, log_path))

    raise RuntimeError(
        f"Resource '{resource_name}' is not a supported measurement driver. "
        "Supported measurement driver types are mock_measurement, http_measurement, "
        "scpi_measurement, and scpi_power_supply_measurement."
    )
