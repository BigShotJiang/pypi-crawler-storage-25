from __future__ import annotations

import json
import os
import traceback
from pathlib import Path
from typing import Any

from benchci.diagnostics.bench_self_test import build_bench_self_test_report
from benchci.diagnostics.schema import utc_now


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name, "").strip().lower()
    if raw in {"1", "true", "yes", "on"}:
        return True
    if raw in {"0", "false", "no", "off"}:
        return False
    return default


def agent_self_test_options() -> dict[str, bool]:
    """Return agent-side self-test options.

    Defaults are intentionally non-destructive:
    - hardware interfaces are opened/closed by default;
    - GPIO outputs, relays, reset, flash, and command transports are not touched;
    - input/readback and measurement reads are opt-in.
    """

    return {
        "open_hardware": _env_bool("BENCHCI_AGENT_SELF_TEST_OPEN_HARDWARE", True),
        "read_inputs": _env_bool("BENCHCI_AGENT_SELF_TEST_READ_INPUTS", False),
        "read_measurements": _env_bool("BENCHCI_AGENT_SELF_TEST_READ_MEASUREMENTS", False),
    }


def agent_self_test_enabled() -> bool:
    return _env_bool("BENCHCI_AGENT_SELF_TEST_ON_STARTUP", True)


def compact_health_from_report(payload: dict[str, Any]) -> dict[str, Any]:
    """Create a compact bench health payload suitable for agent APIs and cloud sync."""

    checks = payload.get("checks") if isinstance(payload.get("checks"), list) else []
    failing_checks = [c for c in checks if isinstance(c, dict) and c.get("status") == "fail"]
    warning_checks = [c for c in checks if isinstance(c, dict) and c.get("status") == "warn"]

    def _compact_check(check: dict[str, Any]) -> dict[str, Any]:
        return {
            k: v
            for k, v in {
                "id": check.get("id"),
                "title": check.get("title"),
                "status": check.get("status"),
                "severity": check.get("severity"),
                "category": check.get("category"),
                "source": check.get("source"),
                "message": check.get("message"),
                "suggested_fix": check.get("suggested_fix"),
            }.items()
            if v is not None and v != ""
        }

    return {
        "schema_version": payload.get("schema_version"),
        "status": payload.get("health_status", "unknown"),
        "checked_at": payload.get("checked_at"),
        "summary": payload.get("summary"),
        "counts": payload.get("counts") or {},
        "failing_checks": [_compact_check(c) for c in failing_checks[:8]],
        "warning_checks": [_compact_check(c) for c in warning_checks[:8]],
    }


def unknown_health(*, reason: str = "Bench health has not been checked yet.") -> dict[str, Any]:
    return {
        "schema_version": "benchci.diagnostics.v1",
        "status": "unknown",
        "checked_at": None,
        "summary": reason,
        "counts": {"passed": 0, "warnings": 0, "failed": 0, "skipped": 0, "total": 0},
        "failing_checks": [],
        "warning_checks": [],
    }


def failing_health_from_exception(exc: Exception, *, bench_path: str | Path | None = None) -> dict[str, Any]:
    return {
        "schema_version": "benchci.diagnostics.v1",
        "status": "failing",
        "checked_at": utc_now(),
        "summary": f"Agent self-test failed before producing a report: {exc}",
        "counts": {"passed": 0, "warnings": 0, "failed": 1, "skipped": 0, "total": 1},
        "failing_checks": [
            {
                "id": "agent_self_test_exception",
                "title": "Agent bench self-test exception",
                "status": "fail",
                "severity": "critical",
                "category": "BENCH_SELF_TEST_FAILED",
                "source": "agent_cloud",
                "message": str(exc),
                "suggested_fix": "Check the bench file path, bench.yaml syntax, permissions, and agent logs.",
            }
        ],
        "warning_checks": [],
        "details": {
            "bench_path": str(bench_path) if bench_path is not None else None,
            "error_type": type(exc).__name__,
            "traceback": traceback.format_exc(limit=6),
        },
    }


def run_agent_bench_self_test(
    *,
    bench_id: str,
    bench_path: str | Path,
    log_root: str | Path,
    open_hardware: bool,
    read_inputs: bool = False,
    read_measurements: bool = False,
) -> dict[str, Any]:
    """Run the shared bench self-test and return compact/full health payloads."""

    bench_path = Path(bench_path).expanduser().resolve()
    log_dir = Path(log_root).expanduser().resolve() / bench_id
    log_dir.mkdir(parents=True, exist_ok=True)

    try:
        report = build_bench_self_test_report(
            bench_path,
            open_hardware=open_hardware,
            read_inputs=read_inputs,
            read_measurements=read_measurements,
            log_dir=log_dir,
        )
        full = report.to_dict()
        full_path = log_dir / "self-test-summary.json"
        full_path.write_text(json.dumps(full, indent=2), encoding="utf-8")
        compact = compact_health_from_report(full)
        compact["log_dir"] = str(log_dir)
        compact["report_path"] = str(full_path)
        compact["bench_id"] = bench_id
        compact["bench_path"] = str(bench_path)
        compact["options"] = {
            "open_hardware": open_hardware,
            "read_inputs": read_inputs,
            "read_measurements": read_measurements,
        }
        return {"health": compact, "report": full}
    except Exception as exc:
        health = failing_health_from_exception(exc, bench_path=bench_path)
        health["log_dir"] = str(log_dir)
        health["bench_id"] = bench_id
        health["bench_path"] = str(bench_path)
        health["options"] = {
            "open_hardware": open_hardware,
            "read_inputs": read_inputs,
            "read_measurements": read_measurements,
        }
        return {"health": health, "report": None}


def health_status_counts(health_by_bench: dict[str, dict[str, Any]]) -> dict[str, int]:
    counts = {"healthy": 0, "degraded": 0, "failing": 0, "unknown": 0}
    for health in health_by_bench.values():
        status = str(health.get("status") or "unknown")
        counts[status if status in counts else "unknown"] += 1
    return counts
