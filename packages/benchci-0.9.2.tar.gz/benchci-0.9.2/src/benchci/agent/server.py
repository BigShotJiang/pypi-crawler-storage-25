from __future__ import annotations

import asyncio
import base64
import json
import os
import shutil
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal, Optional

from fastapi import Body, Depends, FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field

from benchci.agent.config import load_agent_config, resolve_registered_benches
from benchci.agent.models import RegisteredRunRequest, RunEvent, RunRecord
from benchci.agent.registry import BenchRegistry
from benchci.agent.scheduler import RunScheduler
from benchci.agent.state import AgentStateStore
from benchci.gpio.local_gpio import LocalGpioController, LocalGpioLineConfig
from benchci.runner.failure import failure_summary_text
from benchci.runner.local import run_local
from benchci.agent.health import (
    agent_self_test_enabled,
    agent_self_test_options,
    health_status_counts,
    run_agent_bench_self_test,
    unknown_health,
)


MAX_BENCH_YAML_BYTES = 256 * 1024
MAX_SUITE_YAML_BYTES = 256 * 1024
MAX_ARTIFACT_BYTES = 200 * 1024 * 1024


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


@dataclass
class GpioSessionRecord:
    session_id: str
    chip: str
    controller: LocalGpioController


def verify_token(authorization: str | None = Header(default=None)) -> None:
    """Verify bearer token used to access the BenchCI agent."""
    expected = os.getenv("BENCHCI_AGENT_TOKEN")

    # Development-only mode: if no token is configured, allow access.
    # Production deployments should always set BENCHCI_AGENT_TOKEN.
    if not expected:
        return

    if not authorization:
        raise HTTPException(status_code=401, detail="Missing Authorization header")

    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Authorization header must use Bearer token")

    token = authorization.split(" ", 1)[1].strip()
    if token != expected:
        raise HTTPException(status_code=403, detail="Invalid token")


def _json_error(status_code: int, message: str) -> JSONResponse:
    return JSONResponse(status_code=status_code, content={"error": message})


def _load_results_failure(results_dir: Path) -> dict | None:
    results_json = results_dir / "results.json"
    if not results_json.exists():
        return None
    try:
        payload = json.loads(results_json.read_text(encoding="utf-8"))
    except Exception:
        return None

    failure = payload.get("failure")
    if isinstance(failure, dict):
        return failure

    for test in payload.get("tests", []) or []:
        if isinstance(test, dict) and not test.get("passed") and isinstance(test.get("failure"), dict):
            return test["failure"]
    return None


def _load_results_evidence(results_dir: Path) -> dict | None:
    evidence_json = results_dir / "evidence.json"
    if evidence_json.exists():
        try:
            payload = json.loads(evidence_json.read_text(encoding="utf-8"))
            if isinstance(payload, dict):
                return payload
        except Exception:
            pass

    results_json = results_dir / "results.json"
    if not results_json.exists():
        return None
    try:
        payload = json.loads(results_json.read_text(encoding="utf-8"))
    except Exception:
        return None

    evidence = payload.get("evidence")
    return evidence if isinstance(evidence, dict) else None


def _evidence_summary_for_event(evidence: dict | None) -> dict:
    if not evidence:
        return {}

    firmware = evidence.get("firmware") if isinstance(evidence.get("firmware"), dict) else {}
    source = evidence.get("source") if isinstance(evidence.get("source"), dict) else {}
    bench = evidence.get("bench") if isinstance(evidence.get("bench"), dict) else {}
    suite = evidence.get("suite") if isinstance(evidence.get("suite"), dict) else {}
    metrics = evidence.get("metrics") if isinstance(evidence.get("metrics"), dict) else {}
    measurements = evidence.get("measurements") if isinstance(evidence.get("measurements"), list) else []

    return {
        "metrics_count": len(metrics),
        "measurement_count": len(measurements),
        "metric_names": sorted(str(k) for k in metrics.keys())[:20],
        "firmware_sha256": firmware.get("sha256"),
        "firmware_filename": firmware.get("filename"),
        "git_commit": source.get("git_commit"),
        "git_branch": source.get("git_branch"),
        "ci_provider": source.get("ci_provider"),
        "ci_job_url": source.get("ci_job_url"),
        "bench_id": bench.get("bench_id"),
        "bench_config_sha256": bench.get("config_sha256"),
        "suite_name": suite.get("name"),
        "suite_sha256": suite.get("sha256"),
    }


def _require_yaml_filename(filename: str | None, label: str) -> None:
    if not filename:
        raise HTTPException(status_code=400, detail=f"{label} filename is missing")

    suffix = Path(filename).suffix.lower()
    if suffix not in (".yaml", ".yml"):
        raise HTTPException(status_code=400, detail=f"{label} must be a .yaml or .yml file")


def _require_artifact_filename(filename: str | None) -> str:
    if not filename:
        raise HTTPException(status_code=400, detail="artifact filename is missing")

    safe_name = Path(filename).name
    suffix = Path(safe_name).suffix.lower()
    if suffix not in (".elf", ".hex", ".bin"):
        raise HTTPException(status_code=400, detail="artifact must be a .elf, .hex, or .bin file")
    return safe_name


async def _read_limited(upload: UploadFile, max_bytes: int, label: str) -> bytes:
    data = await upload.read()
    if len(data) > max_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"{label} exceeds maximum allowed size of {max_bytes} bytes",
        )
    return data


class GpioRemoteLineConfigModel(BaseModel):
    direction: Literal["input", "output"]
    bias: Literal["disabled", "pull_up", "pull_down"] | None = None
    edge: Literal["rising", "falling", "both"] | None = None


class GpioSessionStartRequest(BaseModel):
    chip: str = Field(..., description="GPIO chip path, e.g. /dev/gpiochip0")
    lines: dict[str, GpioRemoteLineConfigModel] = Field(
        ...,
        description="Per-line GPIO config keyed by channel number as string",
    )


class GpioSessionStartResponse(BaseModel):
    session_id: str


class GpioSessionStopRequest(BaseModel):
    session_id: str


class GpioSetRequest(BaseModel):
    session_id: str
    channel: int
    value: bool


class GpioGetRequest(BaseModel):
    session_id: str
    channel: int


class GpioGetResponse(BaseModel):
    value: bool


class GpioWaitValueRequest(BaseModel):
    session_id: str
    channel: int
    value: bool
    timeout_ms: int = Field(..., ge=0)


class GpioWaitEdgeRequest(BaseModel):
    session_id: str
    channel: int
    edge: Literal["rising", "falling", "both"]
    timeout_ms: int = Field(..., ge=0)


class GpioWaitResponse(BaseModel):
    matched: bool


def create_app(
    work_dir: Path | None = None,
    agent_config_path: Path | None = None,
) -> FastAPI:
    """Create and configure a BenchCI Agent v2 application.

    Features:
    - registered benches via agent.yaml
    - uploaded bench mode for backward compatibility
    - per-bench scheduling/locking
    - in-memory run state and events
    - remote GPIO endpoints
    """
    app = FastAPI(
        title="BenchCI Agent",
        version="0.2.0",
        description="BenchCI remote execution and bench platform agent.",
    )

    base_dir = (work_dir or (Path.home() / "benchci-agent-results")).expanduser().resolve()
    runs_dir = base_dir / "runs"
    runs_dir.mkdir(parents=True, exist_ok=True)

    gpio_logs_dir = base_dir / "gpio-sessions"
    gpio_logs_dir.mkdir(parents=True, exist_ok=True)

    config_path = (
        agent_config_path
        or os.getenv("BENCHCI_AGENT_CONFIG")
        or str(base_dir / "agent.yaml")
    )
    config_path = Path(config_path).expanduser().resolve()

    registry: BenchRegistry | None = None
    agent_id = "standalone-agent"
    agent_name = "BenchCI Agent"

    if config_path.exists():
        cfg = load_agent_config(config_path)
        records = resolve_registered_benches(cfg)
        registry = BenchRegistry.from_records(cfg.agent.id, records)
        agent_id = cfg.agent.id
        agent_name = cfg.agent.name or cfg.agent.id

    scheduler = RunScheduler()
    state = AgentStateStore()
    bench_health_by_id: dict[str, dict] = {}
    bench_health_reports_by_id: dict[str, dict | None] = {}
    bench_health_log_dir = base_dir / "bench-health"
    bench_health_log_dir.mkdir(parents=True, exist_ok=True)

    if registry is not None:
        for bench_id in registry.list_ids():
            scheduler.ensure_bench(bench_id)
            state.current_run_by_bench.setdefault(bench_id, None)
            bench_health_by_id.setdefault(
                bench_id,
                unknown_health(reason="Agent startup self-test has not run yet."),
            )
            bench_health_reports_by_id.setdefault(bench_id, None)

    gpio_sessions: dict[str, GpioSessionRecord] = {}
    gpio_sessions_lock = asyncio.Lock()

    def _zip_dir(src_dir: Path, zip_path: Path) -> Path:
        """Create a ZIP archive from a directory and return the final zip path."""
        zip_path = zip_path.expanduser().resolve()
        if zip_path.suffix.lower() == ".zip":
            base_name = zip_path.with_suffix("")
        else:
            base_name = zip_path
            zip_path = zip_path.with_suffix(".zip")

        shutil.make_archive(str(base_name), "zip", root_dir=str(src_dir))
        return zip_path

    def _append_event(
        run_id: str,
        event_type: str,
        message: str | None = None,
        data: dict | None = None,
    ) -> None:
        state.append_event(
            run_id,
            RunEvent(
                timestamp=_utc_now(),
                event_type=event_type,
                message=message,
                data=data or {},
            ),
        )

    def _get_gpio_session_or_404(session_id: str) -> GpioSessionRecord:
        rec = gpio_sessions.get(session_id)
        if rec is None:
            raise HTTPException(status_code=404, detail="GPIO session not found")
        return rec

    def _bench_status_map() -> dict[str, str]:
        result: dict[str, str] = {}
        if registry is None:
            return result

        for bench_id in registry.list_ids():
            current_run = state.current_run_by_bench.get(bench_id)
            result[bench_id] = "busy" if current_run else "idle"
        return result

    def _bench_health_payload(bench_id: str) -> dict:
        return bench_health_by_id.get(
            bench_id,
            unknown_health(reason="Bench health is not available for this bench."),
        )

    def _run_one_registered_bench_health_check(bench_id: str) -> None:
        if registry is None:
            return
        rec = registry.get(bench_id)
        if rec is None:
            bench_health_by_id[bench_id] = unknown_health(reason="Bench is no longer registered on this agent.")
            bench_health_reports_by_id[bench_id] = None
            return

        options = agent_self_test_options()
        result = run_agent_bench_self_test(
            bench_id=bench_id,
            bench_path=rec.bench_file,
            log_root=bench_health_log_dir,
            open_hardware=options["open_hardware"],
            read_inputs=options["read_inputs"],
            read_measurements=options["read_measurements"],
        )
        bench_health_by_id[bench_id] = result["health"]
        bench_health_reports_by_id[bench_id] = result.get("report")

    def _run_registered_bench_health_checks() -> None:
        if registry is None:
            return
        if not agent_self_test_enabled():
            for bench_id in registry.list_ids():
                bench_health_by_id[bench_id] = unknown_health(
                    reason="Agent startup self-test is disabled by BENCHCI_AGENT_SELF_TEST_ON_STARTUP."
                )
                bench_health_reports_by_id[bench_id] = None
            return

        for bench_id in registry.list_ids():
            _run_one_registered_bench_health_check(bench_id)

    async def _worker_loop() -> None:
        """Background worker that processes queued runs."""
        while True:
            scheduled = await scheduler.next_run()
            run_id = scheduled.run_id
            bench_id = scheduled.bench_id
            rec = state.get_run(run_id)

            if rec is None:
                scheduler.task_done()
                continue

            if bench_id is None:
                uploaded_lock_id = "__uploaded__"
                scheduler.ensure_bench(uploaded_lock_id)
                lock = scheduler.bench_lock(uploaded_lock_id)
            else:
                lock = scheduler.bench_lock(bench_id)

            async with lock:
                if bench_id is not None:
                    state.set_bench_current_run(bench_id, run_id)

                rec.status = "preparing"
                rec.error = None
                rec.exit_code = None
                rec.started_at = _utc_now()
                rec.finished_at = None
                rec.current_test = None
                rec.current_step = None
                _append_event(run_id, "run.preparing", f"Preparing run {run_id}")

                try:
                    run_dir = Path(rec.run_dir) if rec.run_dir else (runs_dir / run_id)
                    results_dir = run_dir / "results"
                    rec.result_dir = str(results_dir.resolve())

                    bench_path = run_dir / "bench.yaml"
                    suite_path = run_dir / "suite.yaml"

                    artifact_path: str | None = None
                    if not rec.skip_flash:
                        if not rec.artifact_relpath:
                            raise RuntimeError(
                                "Internal agent error: artifact_relpath missing for non-skip-flash run"
                            )
                        resolved_artifact = (run_dir / rec.artifact_relpath).resolve()
                        if not resolved_artifact.exists():
                            raise RuntimeError(
                                f"Artifact file is missing for run '{run_id}': {resolved_artifact}"
                            )
                        artifact_path = str(resolved_artifact)

                    def _event_cb(event: dict) -> None:
                        event_type = str(event.get("event_type", "run.event"))
                        message = event.get("message")
                        data = dict(event.get("data", {}) or {})

                        current_test = data.get("test_name")
                        current_step = data.get("step_type")

                        if current_test is not None:
                            rec.current_test = str(current_test)
                        if current_step is not None:
                            rec.current_step = str(current_step)

                        _append_event(
                            run_id=run_id,
                            event_type=event_type,
                            message=message if isinstance(message, str) else None,
                            data=data,
                        )

                    rec.status = "running"
                    _append_event(run_id, "run.started", f"Run {run_id} started")

                    exit_code = await asyncio.to_thread(
                        run_local,
                        bench_path=str(bench_path),
                        suite_path=str(suite_path),
                        artifact_path=artifact_path,
                        skip_flash=rec.skip_flash,
                        out_dir=results_dir,
                        event_cb=_event_cb,
                        verbose=rec.verbose,
                    )

                    rec.exit_code = int(exit_code)
                    rec.status = "uploading_artifacts"
                    _append_event(run_id, "run.uploading_artifacts", "Packaging artifacts")

                    rec.finished_at = _utc_now()
                    evidence = _load_results_evidence(results_dir)
                    if rec.exit_code == 0:
                        rec.status = "done"
                        _append_event(
                            run_id,
                            "run.finished",
                            f"Run {run_id} finished",
                            {"exit_code": rec.exit_code, "evidence": _evidence_summary_for_event(evidence)},
                        )
                    else:
                        rec.status = "failed"
                        failure = _load_results_failure(results_dir)
                        rec.error = failure_summary_text(failure) if failure else f"Run exited with non-zero exit code: {rec.exit_code}"
                        _append_event(
                            run_id,
                            "run.failed",
                            rec.error,
                            (
                                {
                                    "exit_code": rec.exit_code,
                                    "failure": failure,
                                    "evidence": _evidence_summary_for_event(evidence),
                                }
                                if failure
                                else {"exit_code": rec.exit_code, "evidence": _evidence_summary_for_event(evidence)}
                            ),
                        )

                except Exception as exc:
                    failure = None
                    evidence = None
                    try:
                        result_path = Path(rec.result_dir) if rec.result_dir else None
                        failure = _load_results_failure(result_path) if result_path else None
                        evidence = _load_results_evidence(result_path) if result_path else None
                    except Exception:
                        failure = None
                        evidence = None
                    rec.error = failure_summary_text(failure) if failure else "Run failed during agent execution."
                    rec.finished_at = _utc_now()
                    rec.status = "failed"
                    _append_event(
                        run_id,
                        "run.failed",
                        rec.error,
                        (
                            {"failure": failure, "evidence": _evidence_summary_for_event(evidence)}
                            if failure
                            else {"evidence": _evidence_summary_for_event(evidence)}
                        ),
                    )

                finally:
                    if bench_id is not None:
                        state.set_bench_current_run(bench_id, None)
                    rec.current_step = None

            scheduler.task_done()

    @app.on_event("startup")
    async def _startup() -> None:
        await asyncio.to_thread(_run_registered_bench_health_checks)
        app.state.worker_task = asyncio.create_task(_worker_loop())

    @app.on_event("shutdown")
    async def _shutdown() -> None:
        task = getattr(app.state, "worker_task", None)
        if task is not None:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass

        async with gpio_sessions_lock:
            sessions = list(gpio_sessions.values())
            gpio_sessions.clear()

        for rec in sessions:
            try:
                rec.controller.stop()
            except Exception:
                pass

    @app.get("/health")
    def health() -> dict:
        """Health check endpoint."""
        benches_count = len(registry.list_ids()) if registry is not None else 0

        return {
            "ok": True,
            "service": "benchci-agent",
            "version": app.version,
            "agent_id": agent_id,
            "agent_name": agent_name,
            "time_utc": _utc_now(),
            "queue_depth": scheduler.queue_depth(),
            "auth_enabled": bool(os.getenv("BENCHCI_AGENT_TOKEN")),
            "active_gpio_sessions": len(gpio_sessions),
            "registered_benches": benches_count,
            "registered_mode": registry is not None,
            "agent_config_path": str(config_path) if config_path.exists() else None,
            "bench_health": health_status_counts(bench_health_by_id),
        }

    @app.get("/v1/benches")
    def list_benches(_auth: None = Depends(verify_token)):
        """List all registered benches on this agent."""
        if registry is None:
            return []

        summaries = registry.list_summaries(
            bench_status=_bench_status_map(),
            current_run_by_bench=state.current_run_by_bench,
        )
        payloads = []
        for summary in summaries:
            item = summary.model_dump()
            bench_id = str(item.get("bench_id") or "")
            item["health"] = _bench_health_payload(bench_id)
            item["health_status"] = item["health"].get("status")
            item["health_checked_at"] = item["health"].get("checked_at")
            item["health_summary"] = item["health"].get("summary")
            payloads.append(item)
        return payloads

    @app.get("/v1/benches/{bench_id}")
    def get_bench(
        bench_id: str,
        _auth: None = Depends(verify_token),
    ):
        """Return details for one registered bench."""
        if registry is None:
            return _json_error(404, "this agent has no registered benches")

        rec = registry.get(bench_id)
        if rec is None:
            return _json_error(404, "bench not found")

        summary = registry.to_summary(
            rec,
            status=_bench_status_map().get(bench_id, "idle"),
            current_run_id=state.current_run_by_bench.get(bench_id),
        )
        payload = summary.model_dump()
        payload["bench_file"] = rec.bench_file
        payload["node_names"] = sorted(rec.bench.nodes.keys())
        payload["health"] = _bench_health_payload(bench_id)
        payload["health_status"] = payload["health"].get("status")
        payload["health_checked_at"] = payload["health"].get("checked_at")
        payload["health_summary"] = payload["health"].get("summary")
        return payload

    @app.get("/v1/benches/{bench_id}/health")
    def get_bench_health(
        bench_id: str,
        include_report: bool = False,
        _auth: None = Depends(verify_token),
    ):
        """Return the latest agent-side self-test health for one registered bench."""
        if registry is None:
            return _json_error(404, "this agent has no registered benches")
        if registry.get(bench_id) is None:
            return _json_error(404, "bench not found")
        payload = {
            "bench_id": bench_id,
            "health": _bench_health_payload(bench_id),
        }
        if include_report:
            payload["report"] = bench_health_reports_by_id.get(bench_id)
        return payload

    @app.post("/v1/benches/{bench_id}/health/refresh")
    async def refresh_bench_health(
        bench_id: str,
        _auth: None = Depends(verify_token),
    ):
        """Re-run the non-destructive agent-side self-test for one registered bench."""
        if registry is None:
            return _json_error(404, "this agent has no registered benches")
        if registry.get(bench_id) is None:
            return _json_error(404, "bench not found")
        current_run = state.current_run_by_bench.get(bench_id)
        if current_run:
            return _json_error(409, f"bench is busy with run {current_run}")
        await asyncio.to_thread(_run_one_registered_bench_health_check, bench_id)
        return {
            "bench_id": bench_id,
            "health": _bench_health_payload(bench_id),
        }

    @app.post("/v1/runs")
    async def create_run_upload(
        _auth: None = Depends(verify_token),
        bench_yaml: UploadFile = File(...),
        suite_yaml: UploadFile = File(...),
        artifact: Optional[UploadFile] = File(None),
        skip_flash: bool = Form(False),
        verbose: bool = Form(False),
    ):
        """Create a run in uploaded-bench mode (backward compatible)."""
        _require_yaml_filename(bench_yaml.filename, "bench_yaml")
        _require_yaml_filename(suite_yaml.filename, "suite_yaml")

        bench_bytes = await _read_limited(bench_yaml, MAX_BENCH_YAML_BYTES, "bench_yaml")
        suite_bytes = await _read_limited(suite_yaml, MAX_SUITE_YAML_BYTES, "suite_yaml")

        artifact_bytes: bytes | None = None
        artifact_relpath: str | None = None

        if not skip_flash:
            if artifact is None:
                return _json_error(400, "artifact is required unless skip_flash=true")

            artifact_relpath = _require_artifact_filename(artifact.filename)
            artifact_bytes = await _read_limited(artifact, MAX_ARTIFACT_BYTES, "artifact")
        else:
            if artifact is not None:
                await artifact.read()

        run_id = uuid.uuid4().hex[:12]
        run_dir = runs_dir / run_id
        run_dir.mkdir(parents=True, exist_ok=True)

        (run_dir / "bench.yaml").write_bytes(bench_bytes)
        (run_dir / "suite.yaml").write_bytes(suite_bytes)

        if artifact_bytes is not None and artifact_relpath is not None:
            (run_dir / artifact_relpath).write_bytes(artifact_bytes)

        rec = RunRecord(
            run_id=run_id,
            status="queued",
            mode="uploaded",
            bench_id=None,
            skip_flash=skip_flash,
            verbose=verbose,
            artifact_relpath=artifact_relpath,
            run_dir=str(run_dir.resolve()),
            result_dir=None,
            created_at=_utc_now(),
        )
        state.create_run(rec)
        _append_event(run_id, "run.queued", "Run queued in uploaded-bench mode")

        await scheduler.submit(run_id=run_id, bench_id=None)

        return {
            "run_id": rec.run_id,
            "status": rec.status,
            "mode": rec.mode,
            "queue_depth": scheduler.queue_depth(),
            "created_at": rec.created_at,
        }

    @app.post("/v1/runs/json")
    async def create_run_registered(
        req: RegisteredRunRequest = Body(...),
        _auth: None = Depends(verify_token),
    ):
        """Create a run against a registered bench using JSON request mode."""
        if registry is None:
            return _json_error(400, "this agent is not configured with registered benches")

        bench_rec = registry.get(req.bench_id)
        if bench_rec is None:
            return _json_error(404, f"bench not found: {req.bench_id}")

        artifact_bytes: bytes | None = None
        artifact_relpath: str | None = None

        if req.skip_flash:
            artifact_relpath = None
        else:
            if not req.artifact_base64:
                return _json_error(
                    400,
                    "registered-bench runs require an uploaded artifact unless skip_flash=true",
                )

            chosen_name = req.artifact_relpath or req.artifact_filename
            artifact_relpath = _require_artifact_filename(chosen_name)

            try:
                artifact_bytes = base64.b64decode(req.artifact_base64, validate=True)
            except Exception:
                return _json_error(400, "artifact_base64 is not valid base64")

            if len(artifact_bytes) > MAX_ARTIFACT_BYTES:
                return _json_error(
                    413,
                    f"artifact exceeds maximum allowed size of {MAX_ARTIFACT_BYTES} bytes",
                )

        run_id = uuid.uuid4().hex[:12]
        run_dir = runs_dir / run_id
        run_dir.mkdir(parents=True, exist_ok=True)

        shutil.copy2(bench_rec.bench_file, run_dir / "bench.yaml")
        (run_dir / "suite.yaml").write_text(req.suite_yaml, encoding="utf-8")

        if artifact_bytes is not None and artifact_relpath is not None:
            (run_dir / artifact_relpath).write_bytes(artifact_bytes)

        rec = RunRecord(
            run_id=run_id,
            status="queued",
            mode="registered",
            bench_id=req.bench_id,
            skip_flash=req.skip_flash,
            verbose=req.verbose,
            artifact_relpath=artifact_relpath,
            run_dir=str(run_dir.resolve()),
            result_dir=None,
            created_at=_utc_now(),
        )
        state.create_run(rec)
        _append_event(
            run_id,
            "run.queued",
            f"Run queued for registered bench '{req.bench_id}'",
            {"bench_id": req.bench_id},
        )

        await scheduler.submit(run_id=run_id, bench_id=req.bench_id)

        return {
            "run_id": rec.run_id,
            "status": rec.status,
            "mode": rec.mode,
            "bench_id": rec.bench_id,
            "queue_depth": scheduler.queue_depth(),
            "created_at": rec.created_at,
        }

    @app.get("/v1/runs/{run_id}")
    def get_run(
        run_id: str,
        _auth: None = Depends(verify_token),
    ):
        """Return current metadata for a run."""
        rec = state.get_run(run_id)
        if rec is None:
            return _json_error(404, "run not found")

        return state.run_to_response(rec, scheduler.queue_depth()).model_dump()

    @app.get("/v1/runs/{run_id}/events")
    def get_run_events(
        run_id: str,
        _auth: None = Depends(verify_token),
    ):
        """Return structured events emitted during the run lifecycle."""
        rec = state.get_run(run_id)
        if rec is None:
            return _json_error(404, "run not found")

        return {
            "run_id": rec.run_id,
            "status": rec.status,
            "events": [e.model_dump() for e in rec.events],
        }

    @app.get("/v1/runs/{run_id}/artifacts.zip")
    def get_artifacts(
        run_id: str,
        _auth: None = Depends(verify_token),
    ):
        """Download result artifacts for a completed run."""
        rec = state.get_run(run_id)
        if rec is None:
            return _json_error(404, "run not found")

        if rec.status in ("queued", "preparing", "running", "uploading_artifacts"):
            return _json_error(409, f"run not finished: current status is '{rec.status}'")

        if not rec.result_dir:
            return _json_error(404, "no artifacts available for this run")

        src_dir = Path(rec.result_dir)
        if not src_dir.exists():
            return _json_error(404, "results directory is missing")

        zip_path = _zip_dir(src_dir, runs_dir / run_id / "artifacts.zip")

        return FileResponse(
            path=str(zip_path),
            media_type="application/zip",
            filename=f"benchci_{run_id}_artifacts.zip",
        )

    @app.post("/v1/gpio/session/start", response_model=GpioSessionStartResponse)
    async def gpio_session_start(
        req: GpioSessionStartRequest,
        _auth: None = Depends(verify_token),
    ):
        """Create a remote GPIO session on this agent machine."""
        line_configs: dict[int, LocalGpioLineConfig] = {}

        for channel_str, cfg in req.lines.items():
            try:
                channel = int(channel_str)
            except ValueError as exc:
                raise HTTPException(
                    status_code=400,
                    detail="GPIO channel key must be an integer string.",
                )

            line_configs[channel] = LocalGpioLineConfig(
                channel=channel,
                direction=cfg.direction,
                bias=cfg.bias,
                edge=cfg.edge,
            )

        session_id = uuid.uuid4().hex
        log_path = gpio_logs_dir / f"{session_id}.log"

        controller = LocalGpioController(
            chip_path=req.chip,
            line_configs=line_configs,
            log_path=log_path,
        )

        try:
            controller.start()
        except Exception as exc:
            raise HTTPException(
                status_code=500,
                detail="Failed to start GPIO session.",
            )

        rec = GpioSessionRecord(
            session_id=session_id,
            chip=req.chip,
            controller=controller,
        )

        async with gpio_sessions_lock:
            gpio_sessions[session_id] = rec

        return GpioSessionStartResponse(session_id=session_id)

    @app.post("/v1/gpio/session/stop")
    async def gpio_session_stop(
        req: GpioSessionStopRequest,
        _auth: None = Depends(verify_token),
    ):
        """Stop and remove a remote GPIO session."""
        async with gpio_sessions_lock:
            rec = gpio_sessions.pop(req.session_id, None)

        if rec is None:
            return _json_error(404, "GPIO session not found")

        try:
            rec.controller.stop()
        except Exception as exc:
            raise HTTPException(
                status_code=500,
                detail="Failed to stop GPIO session.",
            )

        return {"ok": True}

    @app.post("/v1/gpio/set")
    async def gpio_set(
        req: GpioSetRequest,
        _auth: None = Depends(verify_token),
    ):
        """Drive a GPIO line to a physical value."""
        rec = _get_gpio_session_or_404(req.session_id)

        try:
            rec.controller.set_value(req.channel, req.value)
        except Exception as exc:
            raise HTTPException(
                status_code=500,
                detail="GPIO set failed.",
            )

        return {"ok": True}

    @app.post("/v1/gpio/get", response_model=GpioGetResponse)
    async def gpio_get(
        req: GpioGetRequest,
        _auth: None = Depends(verify_token),
    ):
        """Read a GPIO line's physical value."""
        rec = _get_gpio_session_or_404(req.session_id)

        try:
            value = rec.controller.get_value(req.channel)
        except Exception as exc:
            raise HTTPException(
                status_code=500,
                detail="GPIO get failed.",
            )

        return GpioGetResponse(value=value)

    @app.post("/v1/gpio/wait_value", response_model=GpioWaitResponse)
    async def gpio_wait_value(
        req: GpioWaitValueRequest,
        _auth: None = Depends(verify_token),
    ):
        """Wait until a GPIO line reaches the requested physical value."""
        rec = _get_gpio_session_or_404(req.session_id)

        try:
            matched = rec.controller.wait_for_value(
                req.channel,
                req.value,
                req.timeout_ms,
            )
        except Exception as exc:
            raise HTTPException(
                status_code=500,
                detail="GPIO wait_value failed.",
            )

        return GpioWaitResponse(matched=matched)

    @app.post("/v1/gpio/wait_edge", response_model=GpioWaitResponse)
    async def gpio_wait_edge(
        req: GpioWaitEdgeRequest,
        _auth: None = Depends(verify_token),
    ):
        """Wait until an edge is observed on a GPIO line."""
        rec = _get_gpio_session_or_404(req.session_id)

        try:
            matched = rec.controller.wait_for_edge(
                req.channel,
                req.edge,
                req.timeout_ms,
            )
        except Exception as exc:
            raise HTTPException(
                status_code=500,
                detail="GPIO wait_edge failed.",
            )

        return GpioWaitResponse(matched=matched)

    return app
