from __future__ import annotations

import os
import platform
import socket
import uuid
from importlib import metadata
from pathlib import Path
from typing import Any

import httpx


def _normalize_base_url(base_url: str) -> str:
    return base_url.rstrip("/")


def _benchci_dir() -> Path:
    return Path.home() / ".benchci"


def _machine_id_path() -> Path:
    return _benchci_dir() / "machine_id"


def get_or_create_machine_id() -> str:
    """Return a stable local machine id used to bind cloud-agent tokens.

    The value is stored under ~/.benchci/machine_id so it survives reboots and
    hostname changes. BENCHCI_MACHINE_ID can override it for containerized or
    controlled deployments.
    """
    override = os.getenv("BENCHCI_MACHINE_ID", "").strip()
    if override:
        return override

    path = _machine_id_path()
    try:
        if path.exists():
            existing = path.read_text(encoding="utf-8").strip()
            if existing:
                return existing
    except OSError:
        pass

    value = "benchci_machine_" + uuid.uuid4().hex
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(value + "\n", encoding="utf-8")
    except OSError:
        # Last-resort fallback. This is less ideal because it may change if the
        # host changes, but it still gives the backend an identity to compare.
        value = "benchci_machine_" + uuid.uuid5(
            uuid.NAMESPACE_DNS,
            f"{platform.node()}:{socket.gethostname()}:{uuid.getnode()}",
        ).hex
    return value


def get_machine_name() -> str:
    override = os.getenv("BENCHCI_MACHINE_NAME", "").strip()
    return override or platform.node() or socket.gethostname() or "unknown-machine"


def get_agent_version() -> str:
    try:
        return metadata.version("benchci")
    except Exception:
        return "unknown"


def _build_headers(
    agent_token: str,
    *,
    machine_id: str | None = None,
    machine_name: str | None = None,
    agent_version: str | None = None,
) -> dict[str, str]:
    headers = {"Authorization": f"Bearer {agent_token}"}
    resolved_machine_id = machine_id or get_or_create_machine_id()
    resolved_machine_name = machine_name or get_machine_name()
    resolved_agent_version = agent_version or get_agent_version()

    if resolved_machine_id:
        headers["X-BenchCI-Machine-Id"] = resolved_machine_id
        headers["X-BenchCI-Agent-Machine-ID"] = resolved_machine_id
    if resolved_machine_name:
        headers["X-BenchCI-Machine-Name"] = resolved_machine_name
        headers["X-BenchCI-Agent-Machine-Name"] = resolved_machine_name
    if resolved_agent_version:
        headers["X-BenchCI-Agent-Version"] = resolved_agent_version
    return headers


def _extract_error_detail(response: httpx.Response) -> str | None:
    try:
        body = response.json()
        detail = body.get("detail") or body.get("error")
        if isinstance(detail, str) and detail.strip():
            return detail.strip()
        if isinstance(detail, list):
            return "Request validation failed. Please check your input."
    except Exception:
        pass
    return None


def _raise_http_error_with_context(exc: httpx.HTTPStatusError, action: str) -> None:
    status = exc.response.status_code
    detail = _extract_error_detail(exc.response)

    if detail:
        lower = detail.lower()
        if status in {403, 409} and "machine" in lower and "token" in lower:
            raise RuntimeError(
                f"{detail}\n"
                "This agent token appears to be bound to a different machine. "
                "Create a new agent token for this machine or revoke/regenerate the existing token from the BenchCI dashboard."
            )
        raise RuntimeError(detail)

    if status == 400:
        raise RuntimeError("Request was invalid. Please check your input.")
    if status == 401:
        raise RuntimeError("Agent authentication failed. Check the agent token.")
    if status == 403:
        raise RuntimeError(
            "Agent is not allowed to perform this action. The token may be revoked, "
            "attached to another workspace, or bound to another machine."
        )
    if status == 404:
        raise RuntimeError("Requested agent resource was not found.")
    if status == 409:
        raise RuntimeError(
            "This action conflicts with the current BenchCI state. The agent token may already be bound to another machine."
        )
    if status == 422:
        raise RuntimeError("Request validation failed. Please check your input.")
    if status == 429:
        raise RuntimeError("Too many requests. Please try again shortly.")
    if status >= 500:
        raise RuntimeError("BenchCI service is temporarily unavailable. Please try again later.")

    raise RuntimeError(f"{action} failed.")


class CloudClient:
    def __init__(
        self,
        base_url: str,
        agent_token: str,
        timeout_s: float = 30.0,
        *,
        machine_id: str | None = None,
        machine_name: str | None = None,
        agent_version: str | None = None,
    ):
        self.base_url = _normalize_base_url(base_url)
        self.agent_token = agent_token
        self.timeout_s = timeout_s
        self.machine_id = machine_id or get_or_create_machine_id()
        self.machine_name = machine_name or get_machine_name()
        self.agent_version = agent_version or get_agent_version()

    def _headers(self) -> dict[str, str]:
        return _build_headers(
            self.agent_token,
            machine_id=self.machine_id,
            machine_name=self.machine_name,
            agent_version=self.agent_version,
        )

    def heartbeat(self, *, agent_name: str | None = None, endpoint_url: str | None = None, region: str | None = None, labels: list[str] | None = None) -> dict[str, Any]:
        payload = {
            "agent_name": agent_name,
            "endpoint_url": endpoint_url,
            "region": region,
            "labels": labels or [],
        }

        try:
            with httpx.Client(timeout=self.timeout_s) as client:
                response = client.post(f"{self.base_url}/v1/agents/heartbeat", headers=self._headers(), json=payload)
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as exc:
            _raise_http_error_with_context(exc, "Sending agent heartbeat")
        except httpx.HTTPError:
            raise RuntimeError("Sending agent heartbeat failed.")

    def sync_benches(self, benches: list[dict[str, Any]]) -> dict[str, Any]:
        try:
            with httpx.Client(timeout=self.timeout_s) as client:
                response = client.post(f"{self.base_url}/v1/agents/benches/sync", headers=self._headers(), json={"benches": benches})
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as exc:
            _raise_http_error_with_context(exc, "Syncing benches to backend")
        except httpx.HTTPError:
            raise RuntimeError("Syncing benches to backend failed.")

    def get_assignment(self) -> dict[str, Any] | None:
        try:
            with httpx.Client(timeout=self.timeout_s) as client:
                response = client.get(f"{self.base_url}/v1/agents/assignments/next", headers=self._headers())
                response.raise_for_status()
                payload = response.json()
                return payload.get("assignment")
        except httpx.HTTPStatusError as exc:
            _raise_http_error_with_context(exc, "Polling next assignment")
        except httpx.HTTPError:
            raise RuntimeError("Polling next assignment failed.")

    def send_events(self, run_id: str, events: list[dict[str, Any]]) -> dict[str, Any]:
        try:
            with httpx.Client(timeout=self.timeout_s) as client:
                response = client.post(f"{self.base_url}/v1/agents/runs/{run_id}/events", headers=self._headers(), json={"events": events})
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as exc:
            _raise_http_error_with_context(exc, f"Sending events for run '{run_id}'")
        except httpx.HTTPError:
            raise RuntimeError("Sending run events failed.")

    def complete_run(
        self,
        run_id: str,
        *,
        status: str,
        exit_code: int | None = None,
        error: str | None = None,
        started_at: str | None = None,
        finished_at: str | None = None,
        failure: dict[str, Any] | None = None,
        evidence: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "status": status,
            "exit_code": exit_code,
            "error": error,
            "started_at": started_at,
            "finished_at": finished_at,
        }
        if failure is not None:
            payload["failure"] = failure
        if evidence is not None:
            payload["evidence"] = evidence
        try:
            with httpx.Client(timeout=self.timeout_s) as client:
                response = client.post(f"{self.base_url}/v1/agents/runs/{run_id}/complete", headers=self._headers(), json=payload)
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as exc:
            _raise_http_error_with_context(exc, f"Completing run '{run_id}'")
        except httpx.HTTPError:
            raise RuntimeError("Completing run failed.")

    def upload_artifacts(self, run_id: str, zip_path: str | Path) -> dict[str, Any]:
        zip_file = Path(zip_path).expanduser().resolve()
        if not zip_file.exists():
            raise RuntimeError("Artifact ZIP file was not found.")

        try:
            with httpx.Client(timeout=120.0) as client:
                with zip_file.open("rb") as f:
                    files = {"artifact_zip": (zip_file.name, f, "application/zip")}
                    response = client.post(f"{self.base_url}/v1/agents/runs/{run_id}/artifacts", headers=self._headers(), files=files)
                    response.raise_for_status()
                    return response.json()
        except httpx.HTTPStatusError as exc:
            _raise_http_error_with_context(exc, f"Uploading artifacts for run '{run_id}'")
        except httpx.HTTPError:
            raise RuntimeError("Uploading artifacts failed.")
