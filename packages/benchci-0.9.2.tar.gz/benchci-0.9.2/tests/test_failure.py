"""Tests for benchci.runner.failure — pure classification logic, no hardware needed."""
from __future__ import annotations

import pytest
from benchci.runner.failure import (
    BenchCIFailure,
    build_failure,
    classify_failure,
    failure_source_for_category,
    failure_summary_text,
)


# ---------------------------------------------------------------------------
# classify_failure
# ---------------------------------------------------------------------------

class TestClassifyFailure:
    def test_flash_keyword_in_message(self):
        r = classify_failure("openocd failed to flash target")
        assert r["category"] == "FLASH_FAILED"

    def test_flash_step_type(self):
        r = classify_failure("command exited non-zero", step_type="flash")
        assert r["category"] == "FLASH_FAILED"

    def test_uart_expect_step(self):
        r = classify_failure("timed out waiting", step_type="expect_uart")
        assert r["category"] == "UART_EXPECTATION_FAILED"

    def test_uart_send_step(self):
        r = classify_failure("serial port error", step_type="send_uart")
        assert r["category"] == "UART_FAILED"

    def test_modbus_step(self):
        r = classify_failure("register mismatch", step_type="modbus_read_holding_registers")
        assert r["category"] == "MODBUS_EXPECTATION_FAILED"

    def test_gpio_step(self):
        r = classify_failure("line 3 was low", step_type="gpio_get")
        assert r["category"] == "GPIO_EXPECTATION_FAILED"

    def test_can_expect_step(self):
        r = classify_failure("frame not received", step_type="expect_can")
        assert r["category"] == "CAN_EXPECTATION_FAILED"

    def test_can_failed_step(self):
        r = classify_failure("interface error", step_type="send_can")
        assert r["category"] == "CAN_FAILED"

    def test_timeout_in_message(self):
        r = classify_failure("step timed out after 5000 ms")
        assert r["category"] == "STEP_TIMEOUT"

    def test_resource_locked(self):
        r = classify_failure("resource is locked by another run")
        assert r["category"] == "RESOURCE_LOCKED"

    def test_config_error_validation(self):
        r = classify_failure("validation failed: unknown node 'node0'")
        assert r["category"] == "CONFIG_ERROR"

    def test_artifact_not_found(self):
        r = classify_failure("artifact not found at the specified path")
        assert r["category"] == "ARTIFACT_ERROR"

    def test_measurement_step(self):
        r = classify_failure("value out of range", step_type="measure")
        assert r["category"] == "MEASUREMENT_ASSERTION_FAILED"

    def test_power_step(self):
        r = classify_failure("relay did not respond", step_type="power_set")
        assert r["category"] == "POWER_CONTROL_FAILED"

    def test_unknown_fallback(self):
        r = classify_failure("something completely unexpected happened")
        assert r["category"] == "UNKNOWN_ERROR"

    def test_result_has_required_keys(self):
        r = classify_failure("some error")
        for key in ("category", "title", "explanation", "suggestions"):
            assert key in r
        assert isinstance(r["suggestions"], list)


# ---------------------------------------------------------------------------
# failure_source_for_category
# ---------------------------------------------------------------------------

class TestFailureSource:
    def test_flash_is_bench_infrastructure(self):
        assert failure_source_for_category("FLASH_FAILED") == "bench_infrastructure"

    def test_uart_expectation_is_firmware(self):
        assert failure_source_for_category("UART_EXPECTATION_FAILED") == "firmware"

    def test_config_error_is_configuration(self):
        assert failure_source_for_category("CONFIG_ERROR") == "configuration"

    def test_none_returns_unknown(self):
        assert failure_source_for_category(None) == "unknown"

    def test_unmapped_returns_unknown(self):
        assert failure_source_for_category("MADE_UP_CATEGORY") == "unknown"


# ---------------------------------------------------------------------------
# build_failure
# ---------------------------------------------------------------------------

class TestBuildFailure:
    def test_minimal(self):
        f = build_failure(message="something went wrong")
        assert f["message"] == "something went wrong"
        assert "category" in f
        assert "source" in f
        assert "title" in f
        assert "suggestions" in f
        assert "failed_step" in f

    def test_category_override(self):
        f = build_failure(message="timeout", category="FLASH_FAILED")
        assert f["category"] == "FLASH_FAILED"
        assert f["source"] == "bench_infrastructure"

    def test_custom_title_kept(self):
        f = build_failure(message="err", title="Custom Title")
        assert f["title"] == "Custom Title"

    def test_suggestions_deduplication(self):
        extra = ["Check the board"]
        f = build_failure(message="flash failed", suggestions=extra, step_type="flash")
        # dedup: "Check the board" should appear only once even if flash suggestions overlap
        assert f["suggestions"].count("Check the board") == 1

    def test_failed_step_populated(self):
        f = build_failure(
            message="err",
            step_type="flash",
            test_name="boot_test",
            test_index=0,
            step_index=2,
        )
        assert f["failed_step"]["step_type"] == "flash"
        assert f["failed_step"]["test_name"] == "boot_test"

    def test_none_values_stripped_from_failed_step(self):
        f = build_failure(message="err")
        assert None not in f["failed_step"].values()


# ---------------------------------------------------------------------------
# failure_summary_text
# ---------------------------------------------------------------------------

class TestFailureSummaryText:
    def test_none_returns_default(self):
        assert failure_summary_text(None) == "Run failed"

    def test_empty_dict(self):
        assert failure_summary_text({}) == "Run failed"

    def test_title_only(self):
        assert failure_summary_text({"title": "Flashing failed"}) == "Flashing failed"

    def test_title_and_different_message(self):
        text = failure_summary_text({"title": "UART failed", "message": "port /dev/ttyUSB0 not found"})
        assert "UART failed" in text
        assert "/dev/ttyUSB0" in text

    def test_title_and_same_message(self):
        text = failure_summary_text({"title": "Flash failed", "message": "Flash failed"})
        assert text == "Flash failed"


# ---------------------------------------------------------------------------
# BenchCIFailure exception
# ---------------------------------------------------------------------------

class TestBenchCIFailure:
    def test_str_representation(self):
        f = build_failure(message="UART timed out", step_type="expect_uart")
        exc = BenchCIFailure(f)
        assert "UART" in str(exc)

    def test_failure_attribute(self):
        f = build_failure(message="err")
        exc = BenchCIFailure(f)
        assert exc.failure is f
