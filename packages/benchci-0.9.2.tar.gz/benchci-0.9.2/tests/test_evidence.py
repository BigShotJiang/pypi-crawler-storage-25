"""Tests for benchci.runner.evidence — pure functions, no hardware needed."""
from __future__ import annotations

import hashlib
import json
import tempfile
from pathlib import Path

import pytest
from benchci.runner.evidence import (
    build_artifact_manifest,
    build_traceability_report,
    collect_ci_metadata,
    sha256_file,
)


# ---------------------------------------------------------------------------
# sha256_file
# ---------------------------------------------------------------------------

class TestSha256File:
    def test_known_hash(self, tmp_path):
        f = tmp_path / "data.bin"
        f.write_bytes(b"hello world")
        expected = hashlib.sha256(b"hello world").hexdigest()
        assert sha256_file(f) == expected

    def test_none_input(self):
        assert sha256_file(None) is None

    def test_missing_file(self, tmp_path):
        assert sha256_file(tmp_path / "ghost.bin") is None

    def test_directory_returns_none(self, tmp_path):
        assert sha256_file(tmp_path) is None

    def test_empty_file(self, tmp_path):
        f = tmp_path / "empty.bin"
        f.write_bytes(b"")
        expected = hashlib.sha256(b"").hexdigest()
        assert sha256_file(f) == expected


# ---------------------------------------------------------------------------
# build_artifact_manifest
# ---------------------------------------------------------------------------

class TestBuildArtifactManifest:
    def _make_output_dir(self, tmp_path: Path) -> Path:
        out = tmp_path / "benchci-results" / "run-001"
        out.mkdir(parents=True)
        (out / "results.json").write_text(json.dumps({"ok": True}))
        (out / "evidence.json").write_text(json.dumps({"schema": "v1"}))
        (out / "transport_node0.log").write_text("boot ok\n")
        return out

    def test_manifest_has_schema_version(self, tmp_path):
        out = self._make_output_dir(tmp_path)
        m = build_artifact_manifest(out)
        assert "schema_version" in m

    def test_manifest_has_artifacts_list(self, tmp_path):
        out = self._make_output_dir(tmp_path)
        m = build_artifact_manifest(out)
        assert "artifacts" in m
        assert len(m["artifacts"]) >= 3

    def test_each_artifact_has_sha256(self, tmp_path):
        out = self._make_output_dir(tmp_path)
        m = build_artifact_manifest(out)
        for entry in m["artifacts"]:
            assert "sha256" in entry
            assert len(entry["sha256"]) == 64

    def test_empty_dir(self, tmp_path):
        out = tmp_path / "empty_run"
        out.mkdir()
        m = build_artifact_manifest(out)
        assert "artifacts" in m
        assert m["artifacts"] == []

    def test_artifact_count_matches(self, tmp_path):
        out = self._make_output_dir(tmp_path)
        m = build_artifact_manifest(out)
        assert m["artifact_count"] == len(m["artifacts"])


# ---------------------------------------------------------------------------
# collect_ci_metadata
# ---------------------------------------------------------------------------

class TestCollectCiMetadata:
    def test_returns_dict(self):
        meta = collect_ci_metadata()
        assert isinstance(meta, dict)

    def test_ci_provider_key_exists(self):
        meta = collect_ci_metadata()
        assert "ci_provider" in meta

    def test_no_provider_outside_ci(self, monkeypatch):
        for var in ("GITHUB_ACTIONS", "GITLAB_CI", "CIRCLECI", "JENKINS_URL", "BUILDKITE", "TF_BUILD", "CI"):
            monkeypatch.delenv(var, raising=False)
        meta = collect_ci_metadata()
        assert meta.get("ci_provider") is None

    def test_github_actions_detected(self, monkeypatch):
        monkeypatch.setenv("GITHUB_ACTIONS", "true")
        monkeypatch.setenv("GITHUB_SHA", "abc123")
        monkeypatch.setenv("GITHUB_REF_NAME", "main")
        meta = collect_ci_metadata()
        assert meta.get("ci_provider") == "github_actions"

    def test_gitlab_ci_detected(self, monkeypatch):
        monkeypatch.setenv("GITLAB_CI", "true")
        monkeypatch.setenv("CI_COMMIT_SHA", "def456")
        monkeypatch.setenv("CI_COMMIT_REF_NAME", "main")
        meta = collect_ci_metadata()
        assert meta.get("ci_provider") == "gitlab_ci"


# ---------------------------------------------------------------------------
# build_traceability_report
# ---------------------------------------------------------------------------

class TestBuildTraceabilityReport:
    def _minimal_suite(self):
        from benchci.config.suite import SuiteConfig
        import yaml
        suite_yaml = textwrap.dedent("""\
            version: "1"
            suite:
              name: test-suite
            tests:
              - name: boot
                steps:
                  - sleep_ms: 500
            """)
        return SuiteConfig.model_validate(yaml.safe_load(suite_yaml))

    def test_returns_dict(self):
        import textwrap
        self._minimal_suite  # pre-check
        from benchci.config.suite import SuiteConfig
        import yaml, textwrap
        data = yaml.safe_load(textwrap.dedent("""\
            version: "1"
            suite:
              name: test-suite
            tests:
              - name: boot
                steps:
                  - sleep_ms: 500
        """))
        suite = SuiteConfig.model_validate(data)
        report = build_traceability_report(suite)
        assert isinstance(report, dict)

    def test_has_requirement_ids(self):
        from benchci.config.suite import SuiteConfig
        import yaml, textwrap
        data = yaml.safe_load(textwrap.dedent("""\
            version: "1"
            suite:
              name: test-suite
            tests:
              - name: boot
                steps:
                  - sleep_ms: 500
        """))
        suite = SuiteConfig.model_validate(data)
        report = build_traceability_report(suite)
        assert "requirement_ids" in report

    def test_has_test_case_ids(self):
        from benchci.config.suite import SuiteConfig
        import yaml, textwrap
        data = yaml.safe_load(textwrap.dedent("""\
            version: "1"
            suite:
              name: test-suite
            tests:
              - name: boot
                steps:
                  - sleep_ms: 500
        """))
        suite = SuiteConfig.model_validate(data)
        report = build_traceability_report(suite)
        assert "test_case_ids" in report

    def test_requirement_ids_collected_from_suite(self):
        from benchci.config.suite import SuiteConfig
        import yaml, textwrap
        data = yaml.safe_load(textwrap.dedent("""\
            version: "1"
            suite:
              name: test-suite
              requirement_ids:
                - REQ-001
                - REQ-002
            tests:
              - name: boot
                steps:
                  - sleep_ms: 500
        """))
        suite = SuiteConfig.model_validate(data)
        report = build_traceability_report(suite)
        assert "REQ-001" in report["requirement_ids"]
        assert "REQ-002" in report["requirement_ids"]
