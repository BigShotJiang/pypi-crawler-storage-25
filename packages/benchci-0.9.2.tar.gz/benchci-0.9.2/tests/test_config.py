"""Tests for benchci.config — bench.yaml and suite.yaml parsing, no hardware needed."""
from __future__ import annotations

import textwrap

import pytest
import yaml
from pydantic import ValidationError

from benchci.config.bench import BenchConfig
from benchci.config.suite import SuiteConfig


# ---------------------------------------------------------------------------
# Real YAML structure (nodes dict, not list; suite/bench meta blocks)
# ---------------------------------------------------------------------------

MINIMAL_BENCH_YAML = textwrap.dedent("""\
    version: "1"
    bench:
      name: test-bench
    nodes:
      node0:
        kind: mcu
        flash:
          backend: esptool
          port: /dev/ttyUSB0
        transports:
          console:
            backend: uart
            port: /dev/ttyUSB0
            baud: 115200
    """)

MINIMAL_SUITE_YAML = textwrap.dedent("""\
    version: "1"
    suite:
      name: boot-test
    tests:
      - name: firmware-boots
        steps:
          - flash:
              node: node0
          - expect_uart:
              node: node0
              transport: console
              contains: "BOOT OK"
              within_ms: 5000
    """)

SLEEP_SUITE_YAML = textwrap.dedent("""\
    version: "1"
    suite:
      name: sleep-suite
    tests:
      - name: just-sleep
        steps:
          - sleep_ms: 500
    """)

MULTI_STEP_SUITE_YAML = textwrap.dedent("""\
    version: "1"
    suite:
      name: multi-step
    tests:
      - name: t1
        steps:
          - sleep_ms: 100
          - send_uart:
              node: node0
              transport: console
              data: "ping\\n"
          - expect_uart:
              node: node0
              transport: console
              contains: "pong"
              within_ms: 2000
    """)

TRACEABLE_SUITE_YAML = textwrap.dedent("""\
    version: "1"
    suite:
      name: traceable-suite
      requirement_ids:
        - REQ-001
        - REQ-002
      risk_ids:
        - RISK-001
    tests:
      - name: boot
        test_case_id: TC-001
        requirement_ids:
          - REQ-001
        steps:
          - sleep_ms: 100
    """)


# ---------------------------------------------------------------------------
# BenchConfig parsing
# ---------------------------------------------------------------------------

class TestBenchConfigParsing:
    def test_minimal_valid(self):
        cfg = BenchConfig.model_validate(yaml.safe_load(MINIMAL_BENCH_YAML))
        assert cfg.bench.name == "test-bench"
        assert "node0" in cfg.nodes

    def test_node_kind(self):
        cfg = BenchConfig.model_validate(yaml.safe_load(MINIMAL_BENCH_YAML))
        assert cfg.nodes["node0"].kind == "mcu"

    def test_node_has_transport(self):
        cfg = BenchConfig.model_validate(yaml.safe_load(MINIMAL_BENCH_YAML))
        assert "console" in cfg.nodes["node0"].transports

    def test_uart_transport_fields(self):
        cfg = BenchConfig.model_validate(yaml.safe_load(MINIMAL_BENCH_YAML))
        t = cfg.nodes["node0"].transports["console"]
        assert t.port == "/dev/ttyUSB0"

    def test_flash_backend(self):
        cfg = BenchConfig.model_validate(yaml.safe_load(MINIMAL_BENCH_YAML))
        assert cfg.nodes["node0"].flash.backend == "esptool"

    def test_missing_version_raises(self):
        data = yaml.safe_load(MINIMAL_BENCH_YAML)
        del data["version"]
        with pytest.raises((ValidationError, KeyError, TypeError, Exception)):
            BenchConfig.model_validate(data)

    def test_multiple_nodes(self):
        data = yaml.safe_load(MINIMAL_BENCH_YAML)
        data["nodes"]["node1"] = {
            "kind": "mcu",
            "flash": {"backend": "esptool", "port": "/dev/ttyUSB1"},
            "transports": {"console": {"backend": "uart", "port": "/dev/ttyUSB1", "baud": 9600}},
        }
        cfg = BenchConfig.model_validate(data)
        assert len(cfg.nodes) == 2
        assert "node1" in cfg.nodes

    def test_defaults_node_must_exist(self):
        data = yaml.safe_load(MINIMAL_BENCH_YAML)
        data["defaults"] = {"node": "nonexistent-node"}
        with pytest.raises((ValidationError, ValueError)):
            BenchConfig.model_validate(data)

    def test_defaults_valid_node(self):
        data = yaml.safe_load(MINIMAL_BENCH_YAML)
        data["defaults"] = {"node": "node0"}
        cfg = BenchConfig.model_validate(data)
        assert cfg.defaults.node == "node0"

    def test_gpio_in_node(self):
        data = yaml.safe_load(MINIMAL_BENCH_YAML)
        data["nodes"]["node0"]["gpio"] = {
            "reset_pin": {"backend": "mock_gpio", "direction": "output", "channel": 0}
        }
        cfg = BenchConfig.model_validate(data)
        assert "reset_pin" in cfg.nodes["node0"].gpio


# ---------------------------------------------------------------------------
# SuiteConfig parsing
# ---------------------------------------------------------------------------

class TestSuiteConfigParsing:
    def test_minimal_valid(self):
        cfg = SuiteConfig.model_validate(yaml.safe_load(MINIMAL_SUITE_YAML))
        assert cfg.suite.name == "boot-test"
        assert len(cfg.tests) == 1

    def test_test_name(self):
        cfg = SuiteConfig.model_validate(yaml.safe_load(MINIMAL_SUITE_YAML))
        assert cfg.tests[0].name == "firmware-boots"

    def test_steps_parsed(self):
        cfg = SuiteConfig.model_validate(yaml.safe_load(MINIMAL_SUITE_YAML))
        assert len(cfg.tests[0].steps) == 2

    def test_sleep_suite_parses(self):
        cfg = SuiteConfig.model_validate(yaml.safe_load(SLEEP_SUITE_YAML))
        assert cfg.tests[0].name == "just-sleep"
        assert len(cfg.tests[0].steps) == 1

    def test_multi_step_suite(self):
        cfg = SuiteConfig.model_validate(yaml.safe_load(MULTI_STEP_SUITE_YAML))
        assert len(cfg.tests[0].steps) == 3

    def test_missing_tests_ok_empty(self):
        data = yaml.safe_load(SLEEP_SUITE_YAML)
        data["tests"] = []
        cfg = SuiteConfig.model_validate(data)
        assert cfg.tests == []

    def test_traceability_fields_suite_level(self):
        cfg = SuiteConfig.model_validate(yaml.safe_load(TRACEABLE_SUITE_YAML))
        assert "REQ-001" in cfg.suite.requirement_ids
        assert "REQ-002" in cfg.suite.requirement_ids
        assert "RISK-001" in cfg.suite.risk_ids

    def test_traceability_fields_test_level(self):
        cfg = SuiteConfig.model_validate(yaml.safe_load(TRACEABLE_SUITE_YAML))
        test = cfg.tests[0]
        assert test.test_case_id == "TC-001"
        assert "REQ-001" in test.requirement_ids

    def test_multiple_tests(self):
        data = yaml.safe_load(SLEEP_SUITE_YAML)
        data["tests"].append({"name": "second-test", "steps": [{"sleep_ms": 100}]})
        cfg = SuiteConfig.model_validate(data)
        assert len(cfg.tests) == 2

    def test_missing_version_raises(self):
        data = yaml.safe_load(MINIMAL_SUITE_YAML)
        del data["version"]
        with pytest.raises((ValidationError, KeyError, TypeError, Exception)):
            SuiteConfig.model_validate(data)
