MODULUS_BASE_URL = "https://unkeyapi.modulus.so"
MODULUS_INDEX_URL = f"{MODULUS_BASE_URL}/v1/index/inventory"
MODULUS_API_KEY_VERIFY_URL = f"{MODULUS_BASE_URL}/v1/auth/apikey/verify"
