# LoyalLedger: Omnichannel Loyalty & Ledger System

**LoyalLedger** is an immutable ledger for tracking customer loyalty points, cashbacks, and rewards across physical stores and online platforms.

Developed by **Alireza Aminzadeh** ([@syeedalireza](https://github.com/syeedalireza)).

## Architecture
- **Event Store:** EventStoreDB / PostgreSQL
- **API:** FastAPI, Pydantic
- **Pattern:** Event Sourcing, CQRS, Immutable Ledger

*(Technical implementation pending in next iteration)*
