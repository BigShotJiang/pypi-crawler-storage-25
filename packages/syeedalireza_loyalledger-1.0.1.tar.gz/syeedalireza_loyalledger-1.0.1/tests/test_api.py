import pytest
from httpx import AsyncClient, ASGITransport
from src.main import app, event_store
import pytest_asyncio

@pytest_asyncio.fixture
async def async_client():
    # Clear in-memory store before each test
    event_store.clear()
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client

@pytest.mark.asyncio
async def test_earn_and_redeem_points(async_client):
    # 1. Earn 100 points
    res1 = await async_client.post("/api/v1/ledger/events", json={
        "user_id": "user1", "event_type": "EARN", "points": 100, "reason": "signup"
    })
    assert res1.status_code == 200
    
    # 2. Check balance
    res2 = await async_client.get("/api/v1/ledger/balance/user1")
    assert res2.json()["balance"] == 100
    
    # 3. Redeem 40 points
    res3 = await async_client.post("/api/v1/ledger/events", json={
        "user_id": "user1", "event_type": "REDEEM", "points": 40, "reason": "discount"
    })
    assert res3.status_code == 200
    
    # 4. Check final balance
    res4 = await async_client.get("/api/v1/ledger/balance/user1")
    assert res4.json()["balance"] == 60

@pytest.mark.asyncio
async def test_insufficient_points(async_client):
    res = await async_client.post("/api/v1/ledger/events", json={
        "user_id": "user2", "event_type": "REDEEM", "points": 50, "reason": "discount"
    })
    assert res.status_code == 400
    assert "Insufficient" in res.json()["detail"]