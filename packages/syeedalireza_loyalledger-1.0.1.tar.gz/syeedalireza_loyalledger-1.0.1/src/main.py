from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
import uuid
import time

app = FastAPI(
    title="LoyalLedger API",
    description="Event Sourced Omnichannel Loyalty System",
    version="1.0.0"
)

class PointEvent(BaseModel):
    user_id: str
    event_type: str # "EARN" or "REDEEM"
    points: int
    reason: str

# In-memory store simulating an Event Store for demonstration
# In production, this would be EventStoreDB or PostgreSQL
event_store = []

@app.get("/health", tags=["System"])
async def health_check():
    return {"status": "healthy"}

@app.post("/api/v1/ledger/events", tags=["Ledger"])
async def append_event(event: PointEvent):
    """
    Append an immutable event to the ledger.
    """
    if event.points <= 0:
        raise HTTPException(status_code=400, detail="Points must be positive")
        
    # Validation for REDEEM
    if event.event_type == "REDEEM":
        current_balance = calculate_balance(event.user_id)
        if current_balance < event.points:
            raise HTTPException(status_code=400, detail="Insufficient points balance")

    ledger_entry = {
        "event_id": str(uuid.uuid4()),
        "timestamp": int(time.time()),
        "user_id": event.user_id,
        "event_type": event.event_type,
        "points": event.points,
        "reason": event.reason
    }
    
    event_store.append(ledger_entry)
    return {"status": "success", "event_id": ledger_entry["event_id"]}

def calculate_balance(user_id: str) -> int:
    """
    Rebuild the current state (balance) by replaying all events for a user.
    This is the core concept of Event Sourcing.
    """
    balance = 0
    for event in event_store:
        if event["user_id"] == user_id:
            if event["event_type"] == "EARN":
                balance += event["points"]
            elif event["event_type"] == "REDEEM":
                balance -= event["points"]
    return balance

@app.get("/api/v1/ledger/balance/{user_id}", tags=["Ledger"])
async def get_balance(user_id: str):
    """Get current point balance by replaying events."""
    balance = calculate_balance(user_id)
    return {"user_id": user_id, "balance": balance}