"""Evidence-pack reader + lightweight summaries.

``read_case_study_evidence`` deserializes ``{run_dir}/evidence_pack.json``
into a typed :class:`EvidencePack`. The JSON shape mirrors
``dataclasses.asdict(pack)`` so a pack written by Stage A1 can round-trip
through this loader without bespoke serializers.

``summarize_run`` and ``list_open_questions`` are mechanical text helpers
the ReAct agent uses as prompt context; they make no LLM calls.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from ml4t.agent.schemas import (
    BacktestSummary,
    CostSummary,
    Determinism,
    DiagnosticNote,
    EvidencePack,
    HoldoutMetrics,
    LineageSummary,
    MethodologyWarning,
    ModelRunSummary,
    RobustnessSummary,
    Severity,
    SignalSummary,
    TriageEntry,
    ValidationDesign,
    ValidationMetrics,
)

__all__ = ["read_case_study_evidence", "summarize_run", "list_open_questions"]


EVIDENCE_PACK_FILENAME = "evidence_pack.json"


def read_case_study_evidence(run_dir: Path | str) -> EvidencePack:
    """Read ``{run_dir}/evidence_pack.json`` into a typed EvidencePack.

    Raises ``FileNotFoundError`` if the file is missing and ``ValueError``
    if the JSON shape is incompatible with the schema.
    """
    path = Path(run_dir) / EVIDENCE_PACK_FILENAME
    if not path.is_file():
        raise FileNotFoundError(f"no evidence pack at {path}")
    with path.open("r", encoding="utf-8") as fh:
        data = json.load(fh)
    if not isinstance(data, dict):
        raise ValueError(f"{path}: expected JSON object, got {type(data).__name__}")
    return _pack_from_dict(data)


def summarize_run(pack: EvidencePack) -> str:
    """Return a short multi-line text summary suitable for prompt context."""
    val = pack.validation
    sig = val.signal
    n_models = len(val.model_runs)
    n_backtests = len(val.backtests)
    n_warn = sum(1 for w in pack.warnings if w.severity in (Severity.BLOCKING, Severity.MATERIAL))
    holdout_status = "sealed" if pack.holdout is None else "OPEN"
    lines = [
        f"case_study={pack.case_study} line_id={pack.line_id} parent_run_id={pack.parent_run_id}",
        f"objective: {pack.objective}",
        f"label={pack.primary_label} horizon={pack.horizon} cadence={pack.cadence}",
        f"validation: {n_models} model runs, {n_backtests} backtests; signal best="
        f"{sig.best_family}/{sig.best_config} mean_ic={sig.best_mean_ic:.4f} "
        f"t={sig.ic_t_stat:.2f}",
        f"costs: {pack.costs.per_leg_bps_low:.1f}-{pack.costs.per_leg_bps_high:.1f} "
        f"bps ({pack.costs.cost_class})",
        f"holdout: {holdout_status}",
        f"methodology warnings (blocking|material): {n_warn}",
    ]
    return "\n".join(lines)


def list_open_questions(pack: EvidencePack) -> list[str]:
    """Mechanical question list from warnings + absent baselines.

    The agent treats these as candidate hypotheses for the next iteration;
    ranking and selection happen in the proposals tool.
    """
    questions: list[str] = []
    for warning in pack.warnings:
        if warning.severity in (Severity.BLOCKING, Severity.MATERIAL):
            questions.append(
                f"resolve {warning.severity.name.lower()} warning [{warning.code}]: "
                f"{warning.message}"
            )
    families = {r.family for r in pack.validation.model_runs}
    if "linear" not in families:
        questions.append("does the simplest viable linear baseline survive?")
    if "gbm" not in families:
        questions.append("does a gbm baseline materially beat the linear one?")
    if not pack.validation.robustness.regime_breakdown_available:
        questions.append("do regime interactions help, or is the edge regime-fragile?")
    if pack.validation.signal.ic_t_stat < 2.0:
        questions.append("is the signal strong enough to survive Bonferroni at k>1?")
    return questions


# --- private deserializer ---------------------------------------------------


def _pack_from_dict(data: dict[str, Any]) -> EvidencePack:
    try:
        return EvidencePack(
            case_study=str(data["case_study"]),
            objective=str(data["objective"]),
            primary_label=str(data["primary_label"]),
            horizon=str(data["horizon"]),
            cadence=str(data["cadence"]),
            parent_run_id=str(data["parent_run_id"]),
            line_id=str(data["line_id"]),
            validation_design=_validation_design(data["validation_design"]),
            validation=_validation_metrics(data["validation"]),
            holdout=_holdout(data.get("holdout")),
            costs=_cost_summary(data["costs"]),
            lineage=_lineage(data["lineage"]),
            warnings=tuple(_warning(w) for w in data.get("warnings", [])),
            diagnostics=tuple(_diagnostic(d) for d in data.get("diagnostics", [])),
            triage=_triage(data.get("triage")),
            preset_registry=_preset_registry(data.get("preset_registry")),
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"malformed EvidencePack JSON: {exc}") from exc


def _triage(value: Any) -> tuple[TriageEntry, ...] | None:
    """Deserialize the optional triage ledger.

    ``None`` (or missing) means the runner has not exposed the triage
    contract; an empty list means triage ran with no entries.
    """
    if value is None:
        return None
    if not isinstance(value, list):
        raise ValueError(f"triage: expected list or null, got {type(value).__name__}")
    return tuple(_triage_entry(entry) for entry in value)


def _triage_entry(d: dict[str, Any]) -> TriageEntry:
    return TriageEntry(
        feature_name=str(d["feature_name"]),
        status=str(d["status"]),
        reason=str(d["reason"]),
        severity=Severity(d["severity"]),
    )


def _preset_registry(value: Any) -> frozenset[str] | None:
    """Deserialize the optional preset registry.

    ``None`` (or missing) means the runner has not exposed a registry; an
    empty list/iterable becomes an empty frozenset (every list[str] preset
    override will be refused by `validate_plan`).
    """
    if value is None:
        return None
    if isinstance(value, str) or not hasattr(value, "__iter__"):
        raise ValueError(
            f"preset_registry: expected iterable of strings or null, got {type(value).__name__}"
        )
    return frozenset(str(name) for name in value)


def _validation_design(d: dict[str, Any]) -> ValidationDesign:
    return ValidationDesign(
        n_splits=int(d["n_splits"]),
        train_size=str(d["train_size"]),
        val_size=str(d["val_size"]),
        holdout_start=str(d["holdout_start"]),
        holdout_end=str(d["holdout_end"]),
        embargo_days=_optional_int(d.get("embargo_days")),
        purge_days=_optional_int(d.get("purge_days")),
        fold_calendar_id=str(d["fold_calendar_id"]),
    )


def _validation_metrics(d: dict[str, Any]) -> ValidationMetrics:
    return ValidationMetrics(
        model_runs=tuple(_model_run(m) for m in d["model_runs"]),
        signal=_signal(d["signal"]),
        backtests=tuple(_backtest(b) for b in d["backtests"]),
        robustness=_robustness(d["robustness"]),
    )


def _holdout(d: dict[str, Any] | None) -> HoldoutMetrics | None:
    if d is None:
        return None
    return HoldoutMetrics(
        model_runs=tuple(_model_run(m) for m in d["model_runs"]),
        signal=_signal(d["signal"]),
        backtests=tuple(_backtest(b) for b in d["backtests"]),
    )


def _model_run(d: dict[str, Any]) -> ModelRunSummary:
    return ModelRunSummary(
        family=str(d["family"]),
        config_name=str(d["config_name"]),
        label=str(d["label"]),
        mean_fold_ic=float(d["mean_fold_ic"]),
        fold_ic_std=float(d["fold_ic_std"]),
        fold_sharpe_mean=_optional_float(d.get("fold_sharpe_mean")),
        fold_sharpe_std=_optional_float(d.get("fold_sharpe_std")),
        n_folds=int(d["n_folds"]),
    )


def _signal(d: dict[str, Any]) -> SignalSummary:
    return SignalSummary(
        best_family=str(d["best_family"]),
        best_config=str(d["best_config"]),
        best_mean_ic=float(d["best_mean_ic"]),
        ic_t_stat=float(d["ic_t_stat"]),
        horizons_tested=tuple(str(h) for h in d["horizons_tested"]),
    )


def _backtest(d: dict[str, Any]) -> BacktestSummary:
    return BacktestSummary(
        config_id=str(d["config_id"]),
        family=str(d["family"]),
        gross_sharpe=float(d["gross_sharpe"]),
        net_sharpe=float(d["net_sharpe"]),
        max_drawdown=float(d["max_drawdown"]),
        mean_monthly_turnover=float(d["mean_monthly_turnover"]),
        edge_to_cost_ratio=float(d["edge_to_cost_ratio"]),
    )


def _cost_summary(d: dict[str, Any]) -> CostSummary:
    return CostSummary(
        per_leg_bps_low=float(d["per_leg_bps_low"]),
        per_leg_bps_high=float(d["per_leg_bps_high"]),
        cost_class=str(d["cost_class"]),
        components=tuple(str(c) for c in d["components"]),
    )


def _robustness(d: dict[str, Any]) -> RobustnessSummary:
    return RobustnessSummary(
        fold_sharpe_dispersion=float(d["fold_sharpe_dispersion"]),
        regime_breakdown_available=bool(d["regime_breakdown_available"]),
        seed_variance_estimate=_optional_float(d.get("seed_variance_estimate")),
    )


def _lineage(d: dict[str, Any]) -> LineageSummary:
    # package_versions is stored as a plain dict, not MappingProxyType:
    # asdict() can't deepcopy a mappingproxy on CPython 3.14. The dataclass
    # field type is Mapping[str, str], which accepts either.
    versions = d.get("package_versions") or {}
    if not isinstance(versions, Mapping):
        raise ValueError("lineage.package_versions must be a mapping")
    return LineageSummary(
        git_sha=str(d["git_sha"]),
        data_snapshot_id=str(d["data_snapshot_id"]),
        config_hash=str(d["config_hash"]),
        package_versions={str(k): str(v) for k, v in dict(versions).items()},
    )


def _warning(d: dict[str, Any]) -> MethodologyWarning:
    return MethodologyWarning(
        code=str(d["code"]),
        message=str(d["message"]),
        severity=_severity(d["severity"]),
        determinism=_determinism(d["determinism"]),
        triggering_artifact=str(d["triggering_artifact"]),
        triggering_field=_optional_str(d.get("triggering_field")),
    )


def _diagnostic(d: dict[str, Any]) -> DiagnosticNote:
    return DiagnosticNote(
        code=str(d["code"]),
        message=str(d["message"]),
        triggering_artifact=str(d["triggering_artifact"]),
    )


def _severity(value: Any) -> Severity:
    if isinstance(value, Severity):
        return value
    return Severity(str(value))


def _determinism(value: Any) -> Determinism:
    if isinstance(value, Determinism):
        return value
    return Determinism(str(value))


def _optional_int(value: Any) -> int | None:
    return None if value is None else int(value)


def _optional_float(value: Any) -> float | None:
    return None if value is None else float(value)


def _optional_str(value: Any) -> str | None:
    return None if value is None else str(value)
