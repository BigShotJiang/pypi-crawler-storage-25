"""Handoff tool: emit a markdown experiment-spec for a downstream coding agent.

The v0.1 agent does not execute experiments. When an iteration is
approved, the agent writes a self-contained markdown file describing the
experiment so a coding agent (or human) can implement and run it. This
keeps the v0.1 surface tight while leaving room for v0.6 supervisor work.
"""

from __future__ import annotations

from pathlib import Path
from textwrap import indent

from ml4t.agent.schemas import ConfigPatch, ExperimentPlan

__all__ = ["write_experiment_spec_for_coding_agent", "render_experiment_spec"]


def write_experiment_spec_for_coding_agent(plan: ExperimentPlan, out_path: Path | str) -> Path:
    """Render ``plan`` to markdown and write it to ``out_path``.

    Returns the resolved Path that was written. Parent directories must
    already exist; we do not implicitly mkdir.
    """
    out = Path(out_path)
    if not out.parent.is_dir():
        raise FileNotFoundError(f"parent directory does not exist: {out.parent}")
    out.write_text(render_experiment_spec(plan), encoding="utf-8")
    return out


def render_experiment_spec(plan: ExperimentPlan) -> str:
    """Pure markdown renderer (no I/O). Useful in tests and dry-runs."""
    crit = plan.delta_criterion
    parts: list[str] = [
        f"# Experiment {plan.experiment_id}",
        "",
        f"**Template**: `{plan.template_id}`",
        f"**Parent run**: `{plan.parent_run_id}`",
        f"**Comparison target**: `{plan.comparison_target_id}`",
        "",
        "## Question",
        "",
        plan.question,
        "",
        "## Hypothesis",
        "",
        plan.hypothesis,
        "",
        "## Rationale",
        "",
        plan.rationale,
        "",
        "## Config patches",
        "",
    ]
    if plan.config_patches:
        for p in plan.config_patches:
            parts.append(_render_patch(p))
    else:
        parts.append("_(none)_")

    parts += [
        "",
        "## Stages to invoke",
        "",
    ]
    if plan.stage_invocations:
        for inv in plan.stage_invocations:
            parts.append(f"- `{inv.script}`")
    else:
        parts.append("_(none)_")

    parts += [
        "",
        "## Expected artifacts",
        "",
    ]
    if plan.expected_artifacts:
        for art in plan.expected_artifacts:
            parts.append(f"- `{art.relative_path}` (schema `{art.schema_id}`)")
    else:
        parts.append("_(none)_")

    parts += [
        "",
        "## Delta criterion",
        "",
        f"- primary metric: `{crit.primary_metric}` ({crit.metric_kind})",
        f"- direction: {crit.direction}",
        f"- support threshold: {crit.support_threshold}",
        f"- reject threshold: {crit.reject_threshold}",
        f"- noise floor: {crit.noise_floor_method}",
        f"- base alpha: {crit.base_alpha}, bonferroni k={crit.bonferroni_k} → "
        f"adjusted alpha={crit.adjusted_alpha:g}",
        "",
    ]
    return "\n".join(parts) + "\n"


def _render_patch(patch: ConfigPatch) -> str:
    yaml_path = ".".join(patch.yaml_path)
    body = (
        f"- path: `{patch.path_template}`\n"
        f"  yaml: `{yaml_path}`\n"
        f"  new_value: `{patch.new_value!r}`"
    )
    return indent(body, "")
