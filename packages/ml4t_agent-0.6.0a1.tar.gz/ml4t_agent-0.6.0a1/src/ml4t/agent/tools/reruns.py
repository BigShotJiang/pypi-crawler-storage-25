"""Bounded-rerun tools.

Real reruns require the case-study runner (ml4t-data + ml4t-engineer +
ml4t-backtest stages). For v0.x we ship the *contracts*: each rerun tool
reads a fixture artifact from the run directory and returns a typed
result record. This makes the tools unit-testable end-to-end and keeps
the agent loop wired to the real contracts; the v0.6 executor swaps the
fixture path for a live runner call.

v0.1 — T-C1: ``run_cost_sensitivity`` → ``CostSummary``.
v0.2 — T-A2: ``run_lineage_recheck`` → ``LineageRecheckResult``.
v0.2 — T-M1: ``run_narrow_gbm_search`` → ``NarrowGbmResult``.
"""

from __future__ import annotations

import json
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from ml4t.agent.schemas import (
    CostSummary,
    LineageRecheckResult,
    ModelRunSummary,
    NarrowGbmResult,
)

__all__ = [
    "run_cost_sensitivity",
    "run_lineage_recheck",
    "run_narrow_gbm_search",
]


COST_SENSITIVITY_FILENAME = "cost_sensitivity.json"
LINEAGE_RECHECK_FILENAME = "lineage_recheck.json"
NARROW_GBM_FILENAME = "narrow_gbm_search.json"


def run_cost_sensitivity(
    run_dir: Path | str,
    *,
    cost_bps_range: tuple[float, float],
) -> CostSummary:
    """Read the run-dir's cost-sensitivity artifact, return a typed CostSummary.

    Parameters
    ----------
    run_dir
        Directory containing ``cost_sensitivity.json`` (a mapping with
        ``cost_class`` and ``components``).
    cost_bps_range
        ``(low, high)`` in basis points. The returned CostSummary uses
        these as the per-leg range; T-C1 typically supplies a stricter
        upper bound than the parent run.

    Raises
    ------
    FileNotFoundError, ValueError
        Standard surface for malformed or missing fixtures.
    """
    low, high = cost_bps_range
    if low < 0 or high < 0:
        raise ValueError(f"cost_bps_range entries must be >= 0, got {cost_bps_range}")
    if low > high:
        raise ValueError(f"cost_bps_range low > high: {cost_bps_range}")

    path = Path(run_dir) / COST_SENSITIVITY_FILENAME
    if not path.is_file():
        raise FileNotFoundError(f"no cost-sensitivity fixture at {path}")
    with path.open("r", encoding="utf-8") as fh:
        data = json.load(fh)
    if not isinstance(data, dict):
        raise ValueError(f"{path}: expected JSON object, got {type(data).__name__}")

    return _build_cost_summary(data, low=low, high=high)


def _build_cost_summary(data: dict[str, Any], *, low: float, high: float) -> CostSummary:
    try:
        cost_class = str(data["cost_class"])
        components = tuple(str(c) for c in data["components"])
    except (KeyError, TypeError) as exc:
        raise ValueError(f"malformed cost_sensitivity payload: {exc}") from exc
    return CostSummary(
        per_leg_bps_low=low,
        per_leg_bps_high=high,
        cost_class=cost_class,
        components=components,
    )


def run_lineage_recheck(
    run_dir: Path | str,
    *,
    parent_baseline: ModelRunSummary,
) -> LineageRecheckResult:
    """T-A2 rerun: HEAD-rebuild of the strongest parent baseline.

    Reads ``lineage_recheck.json`` from ``run_dir`` and returns a
    :class:`LineageRecheckResult` carrying the rerun's IC plus lineage
    receipts. ``parent_baseline`` is threaded through unchanged so the
    delta evaluator can compute ``mean_fold_ic_after - parent_baseline.
    mean_fold_ic`` (or, for T-A2's absolute criterion, compare
    ``mean_fold_ic_after`` directly against the parent's level minus
    tolerance).

    Fixture schema::

        {
          "mean_fold_ic_after": float,
          "fold_ic_after": [float, ...],
          "git_sha_at_rerun": str,
          "package_versions_at_rerun": {str: str, ...}
        }
    """

    path = Path(run_dir) / LINEAGE_RECHECK_FILENAME
    if not path.is_file():
        raise FileNotFoundError(f"no lineage-recheck fixture at {path}")
    with path.open("r", encoding="utf-8") as fh:
        data = json.load(fh)
    if not isinstance(data, dict):
        raise ValueError(f"{path}: expected JSON object, got {type(data).__name__}")

    try:
        mean_after = float(data["mean_fold_ic_after"])
        fold_after = tuple(float(v) for v in data["fold_ic_after"])
        git_sha = str(data["git_sha_at_rerun"])
        raw_versions = data["package_versions_at_rerun"]
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"{path}: malformed lineage_recheck payload: {exc}") from exc
    if not isinstance(raw_versions, dict):
        raise ValueError(f"{path}: package_versions_at_rerun must be an object")
    versions = {str(k): str(v) for k, v in raw_versions.items()}

    return LineageRecheckResult(
        parent_baseline=parent_baseline,
        mean_fold_ic_after=mean_after,
        fold_ic_after=fold_after,
        git_sha_at_rerun=git_sha,
        package_versions_at_rerun=versions,
    )


def run_narrow_gbm_search(
    run_dir: Path | str,
    *,
    presets_to_try: Sequence[str],
    baseline_within_family: ModelRunSummary,
) -> NarrowGbmResult:
    """T-M1 rerun: retrain a narrowed list of GBM presets.

    Reads ``narrow_gbm_search.json`` from ``run_dir``. The fixture lists
    one ``ModelRunSummary``-shaped record per preset; the tool keeps only
    the records whose ``config_name`` appears in ``presets_to_try`` (an
    audit on the runner: spurious records for unrequested presets are
    dropped, missing requested presets surface as a ValueError).

    Fixture schema::

        {
          "runs": [
            {"family": "gbm", "config_name": str, "label": str,
             "mean_fold_ic": float, "fold_ic_std": float,
             "fold_sharpe_mean": float | null,
             "fold_sharpe_std": float | null,
             "n_folds": int},
            ...
          ]
        }
    """

    presets = tuple(presets_to_try)
    if not presets:
        raise ValueError("presets_to_try must be non-empty")
    if baseline_within_family.family != "gbm":
        raise ValueError(
            f"baseline_within_family.family must be 'gbm', got {baseline_within_family.family!r}"
        )

    path = Path(run_dir) / NARROW_GBM_FILENAME
    if not path.is_file():
        raise FileNotFoundError(f"no narrow-gbm fixture at {path}")
    with path.open("r", encoding="utf-8") as fh:
        data = json.load(fh)
    if not isinstance(data, dict) or "runs" not in data:
        raise ValueError(f"{path}: expected an object with a 'runs' key")
    raw_runs = data["runs"]
    if not isinstance(raw_runs, list):
        raise ValueError(f"{path}: 'runs' must be a list")

    by_name: dict[str, ModelRunSummary] = {}
    for entry in raw_runs:
        run = _build_model_run_summary(entry, source=str(path))
        if run.config_name in presets:
            by_name[run.config_name] = run

    missing = [p for p in presets if p not in by_name]
    if missing:
        raise ValueError(f"{path}: missing run records for presets {missing}")

    narrowed = tuple(by_name[name] for name in presets)
    return NarrowGbmResult(
        baseline_within_family=baseline_within_family,
        narrowed_runs=narrowed,
        presets_tried=presets,
    )


def _build_model_run_summary(entry: Any, *, source: str) -> ModelRunSummary:
    if not isinstance(entry, dict):
        raise ValueError(f"{source}: each run entry must be an object")
    try:
        family = str(entry["family"])
        config_name = str(entry["config_name"])
        label = str(entry["label"])
        mean_fold_ic = float(entry["mean_fold_ic"])
        fold_ic_std = float(entry["fold_ic_std"])
        n_folds = int(entry["n_folds"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"{source}: malformed run entry: {exc}") from exc
    fold_sharpe_mean = entry.get("fold_sharpe_mean")
    fold_sharpe_std = entry.get("fold_sharpe_std")
    return ModelRunSummary(
        family=family,
        config_name=config_name,
        label=label,
        mean_fold_ic=mean_fold_ic,
        fold_ic_std=fold_ic_std,
        fold_sharpe_mean=None if fold_sharpe_mean is None else float(fold_sharpe_mean),
        fold_sharpe_std=None if fold_sharpe_std is None else float(fold_sharpe_std),
        n_folds=n_folds,
    )
