"""LLM adapter Protocol + plain-data message types.

The agent code calls ``client.complete_with_schema(messages, json_schema)``
and expects a JSON-shaped dict back. Everything else (rate limits,
prompt caching, retries) is the concrete impl's responsibility. The
agent never imports a vendor SDK directly.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol, runtime_checkable

__all__ = ["Message", "LLMResponse", "LLMClient", "Role"]


Role = Literal["system", "user", "assistant"]


@dataclass(frozen=True, slots=True)
class Message:
    """One chat-style message. ``cacheable`` flags content the concrete
    impl is permitted to mark as cache-eligible (Anthropic prompt caching,
    OpenAI cache hints, etc.). The mock and the Protocol are unaware of
    cache semantics."""

    role: Role
    content: str
    cacheable: bool = False


@dataclass(frozen=True, slots=True)
class LLMResponse:
    """Parsed JSON-schema response + provenance.

    ``data`` is the deserialized JSON object the schema requested.
    ``raw`` is the verbatim string the model returned (for tracing).
    ``usage`` is a vendor-neutral mapping (e.g. ``input_tokens``,
    ``output_tokens``); empty for mocks.
    """

    data: Mapping[str, Any]
    raw: str
    usage: Mapping[str, int] = field(default_factory=dict)


@runtime_checkable
class LLMClient(Protocol):
    """Provider-agnostic chat surface.

    Implementations must:
    - return a :class:`LLMResponse` whose ``data`` validates against
      ``json_schema`` (the impl is responsible for re-prompting on
      malformed output, or raising).
    - be deterministic when ``temperature == 0`` (or document why not).
    """

    def complete_with_schema(
        self,
        messages: Sequence[Message],
        json_schema: Mapping[str, Any],
        *,
        max_tokens: int = 1024,
        temperature: float | None = 0.0,
    ) -> LLMResponse: ...
