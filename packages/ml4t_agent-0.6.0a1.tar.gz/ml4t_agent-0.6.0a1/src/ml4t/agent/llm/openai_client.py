"""OpenAI concrete impl of LLMClient.

JSON-schema enforcement via OpenAI Structured Outputs: we pass
``response_format={"type": "json_schema", "json_schema": {...}}`` on the
``chat.completions.create`` call. The model is forced to emit a JSON
object that validates against the schema, and we parse the assistant
message's ``content`` field directly.

Two production-relevant deviations from the obvious defaults, both
diagnosed by the v0.5.0 falsification spike (see plan-31a):

1. ``strict`` defaults to ``False``. OpenAI's strict mode rejects any
   schema that does not fully specify every field's type, and the
   proposer schema deliberately leaves ``new_value`` open
   (``{}``) because its type varies per template. Strict-mode-eligible
   schemas can opt in via ``strict=True``.
2. ``max_tokens`` defaults to ``8192``. For gpt-5-class models the
   ``reasoning_tokens`` count against ``max_completion_tokens``; the
   v0.5 spike showed a 2048 budget produces empty completions
   (``finish_reason="length"``). When that does happen we raise
   :class:`OpenAIBudgetExhaustedError` so callers can react explicitly
   instead of getting a ``ValueError`` about empty content.

Prompt caching is automatic on OpenAI for prompts above the cache
threshold (no per-call flag needed, unlike Anthropic). The
``cacheable`` flag on individual messages is a no-op for this provider
but is preserved on the wire to keep the Protocol provider-agnostic.

The ``openai`` SDK is an optional dependency (``[llm-openai]`` /
``[llm]`` extras). This module raises a clear ImportError at import
time if the SDK is missing.
"""

from __future__ import annotations

import json
import os
from collections.abc import Mapping, Sequence
from typing import Any

try:
    import openai  # noqa: F401
except ImportError as _exc:  # pragma: no cover - exercised only when extra missing
    raise ImportError(
        "OpenAIClient requires the 'openai' SDK. "
        "Install with: uv pip install 'ml4t-agent[llm-openai]'"
    ) from _exc

from .base import LLMResponse, Message

__all__ = ["OpenAIBudgetExhaustedError", "OpenAIClient"]

DEFAULT_MODEL = "gpt-5-mini"
DEFAULT_SCHEMA_NAME = "structured_response"
DEFAULT_MAX_TOKENS = 8192


class OpenAIBudgetExhaustedError(RuntimeError):
    """Raised when the API returns an empty completion with finish_reason='length'.

    For gpt-5-class models the model's reasoning tokens count against
    ``max_completion_tokens``. When the budget is exhausted before any
    user-visible content is emitted, ``content`` is empty and
    ``finish_reason`` is ``"length"``. Callers should retry with a
    larger ``max_tokens``.
    """


class OpenAIClient:
    """LLMClient backed by the OpenAI Chat Completions API.

    Parameters
    ----------
    model
        Model id. Default is ``gpt-5-mini`` — cheap, fast, and adequate
        for the JSON-schema-bounded proposer prompt. Pass ``model="gpt-5"``
        to swap to the flagship.
    api_key
        Optional override for ``OPENAI_API_KEY``.
    schema_name
        ``json_schema.name`` field sent to the API. Used by OpenAI for
        telemetry only; default ``structured_response``.
    strict
        Default ``strict`` value passed to OpenAI's structured outputs.
        Defaults to ``False`` because the proposer schema includes a
        deliberately untyped ``new_value`` field. Per-call override is
        available via ``complete_with_schema(strict=...)``.
    """

    def __init__(
        self,
        *,
        model: str = DEFAULT_MODEL,
        api_key: str | None = None,
        schema_name: str = DEFAULT_SCHEMA_NAME,
        strict: bool = False,
    ) -> None:
        key = api_key or os.environ.get("OPENAI_API_KEY")
        if not key:
            raise RuntimeError("OPENAI_API_KEY not set; pass api_key= or set the env var")
        self._client = openai.OpenAI(api_key=key)
        self._model = model
        self._schema_name = schema_name
        self._default_strict = strict

    def complete_with_schema(
        self,
        messages: Sequence[Message],
        json_schema: Mapping[str, Any],
        *,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        temperature: float | None = 0.0,
        strict: bool | None = None,
    ) -> LLMResponse:
        api_messages = [{"role": m.role, "content": m.content} for m in messages]
        effective_strict = self._default_strict if strict is None else strict
        response_format: dict[str, Any] = {
            "type": "json_schema",
            "json_schema": {
                "name": self._schema_name,
                "schema": dict(json_schema),
                "strict": effective_strict,
            },
        }
        kwargs: dict[str, Any] = {
            "model": self._model,
            "messages": api_messages,
            "max_completion_tokens": max_tokens,
            "response_format": response_format,
        }
        if temperature is not None:
            kwargs["temperature"] = temperature

        create: Any = self._client.chat.completions.create
        response = create(**kwargs)
        return self._parse(response, max_tokens=max_tokens)

    def _parse(self, response: Any, *, max_tokens: int) -> LLMResponse:
        choices = getattr(response, "choices", None) or []
        if not choices:
            raise ValueError("OpenAI response had no choices")
        choice = choices[0]
        finish_reason = getattr(choice, "finish_reason", None)
        message = getattr(choice, "message", None)
        if message is None:
            raise ValueError("OpenAI choice had no message")
        raw = getattr(message, "content", None)
        if not isinstance(raw, str) or not raw:
            if finish_reason == "length":
                raise OpenAIBudgetExhaustedError(
                    f"OpenAI returned empty content with finish_reason='length' "
                    f"(max_completion_tokens={max_tokens}). For gpt-5-class models "
                    f"reasoning_tokens count against this budget; retry with a "
                    f"larger max_tokens."
                )
            raise ValueError(
                f"OpenAI assistant message had no string content (finish_reason={finish_reason!r})"
            )
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"OpenAI response was not valid JSON: {exc}") from exc
        if not isinstance(data, dict):
            raise ValueError(f"OpenAI response was not a JSON object: {type(data).__name__}")
        return LLMResponse(data=data, raw=raw, usage=self._usage(response))

    @staticmethod
    def _usage(response: Any) -> dict[str, int]:
        usage = getattr(response, "usage", None)
        if usage is None:
            return {}
        out: dict[str, int] = {}
        for attr in (
            "prompt_tokens",
            "completion_tokens",
            "total_tokens",
        ):
            value = getattr(usage, attr, None)
            if isinstance(value, int):
                out[attr] = value
        # Cached tokens (OpenAI prompt caching) live under a nested
        # `prompt_tokens_details.cached_tokens` field. Surface as a flat
        # `cached_tokens` for parity with other providers.
        details = getattr(usage, "prompt_tokens_details", None)
        cached = getattr(details, "cached_tokens", None) if details is not None else None
        if isinstance(cached, int):
            out["cached_tokens"] = cached
        return out
