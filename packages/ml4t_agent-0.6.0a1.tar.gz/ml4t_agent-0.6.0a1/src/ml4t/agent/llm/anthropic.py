"""Anthropic concrete impl of LLMClient.

JSON-schema enforcement via tool use: we register a single tool whose
``input_schema`` is the caller-supplied schema, then force the model to
invoke it via ``tool_choice``. The tool's ``input`` payload is the JSON
object the agent wants.

Prompt caching: the system message and tool schema are marked with
``cache_control: {"type": "ephemeral"}``. The first call populates the
cache; subsequent calls within Anthropic's TTL hit it.

The ``anthropic`` SDK is an optional dependency (``[llm]`` extra). This
module raises a clear ImportError at import time if the SDK is missing,
so callers know to ``uv pip install 'ml4t-agent[llm]'``.
"""

from __future__ import annotations

import json
import os
from collections.abc import Mapping, Sequence
from typing import Any

try:
    import anthropic  # noqa: F401
except ImportError as _exc:  # pragma: no cover - exercised only when extra missing
    raise ImportError(
        "AnthropicClient requires the 'anthropic' SDK. "
        "Install with: uv pip install 'ml4t-agent[llm]'"
    ) from _exc

from .base import LLMResponse, Message

__all__ = ["AnthropicClient"]

DEFAULT_MODEL = "claude-opus-4-7"
DEFAULT_TOOL_NAME = "emit_structured_response"


class AnthropicClient:
    """LLMClient backed by the Anthropic Messages API.

    Parameters
    ----------
    model
        Model id. Default is the latest Opus.
    api_key
        Optional override for ``ANTHROPIC_API_KEY``.
    enable_caching
        Mark the system block + tool schema as ``cache_control: ephemeral``.
        Default ``True``.
    tool_name
        Name of the synthetic tool whose ``input`` carries the JSON payload.
    """

    def __init__(
        self,
        *,
        model: str = DEFAULT_MODEL,
        api_key: str | None = None,
        enable_caching: bool = True,
        tool_name: str = DEFAULT_TOOL_NAME,
    ) -> None:
        key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            raise RuntimeError("ANTHROPIC_API_KEY not set; pass api_key= or set the env var")
        self._client = anthropic.Anthropic(api_key=key)
        self._model = model
        self._enable_caching = enable_caching
        self._tool_name = tool_name

    def complete_with_schema(
        self,
        messages: Sequence[Message],
        json_schema: Mapping[str, Any],
        *,
        max_tokens: int = 1024,
        temperature: float | None = 0.0,
    ) -> LLMResponse:
        # `temperature=None` skips the parameter entirely. Required for
        # extended-thinking models (e.g. Opus 4.7) where the API rejects it.
        system_blocks, chat_messages = self._partition(messages)
        tool: dict[str, Any] = {
            "name": self._tool_name,
            "description": "Emit the structured response demanded by the schema.",
            "input_schema": dict(json_schema),
        }
        if self._enable_caching:
            tool["cache_control"] = {"type": "ephemeral"}

        # The anthropic SDK uses very specific TypedDict unions for system/
        # tools/tool_choice. We pass plain dicts (matching the JSON shape the
        # API actually accepts) and bypass the static overload via Any.
        create: Any = self._client.messages.create
        response = create(
            model=self._model,
            max_tokens=max_tokens,
            temperature=temperature if temperature is not None else anthropic.NOT_GIVEN,
            system=system_blocks if system_blocks else anthropic.NOT_GIVEN,
            tools=[tool],
            tool_choice={"type": "tool", "name": self._tool_name},
            messages=chat_messages,
        )
        return self._parse(response)

    def _partition(
        self, messages: Sequence[Message]
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        system_blocks: list[dict[str, Any]] = []
        chat: list[dict[str, Any]] = []
        for m in messages:
            if m.role == "system":
                block: dict[str, Any] = {"type": "text", "text": m.content}
                if self._enable_caching and m.cacheable:
                    block["cache_control"] = {"type": "ephemeral"}
                system_blocks.append(block)
            else:
                chat.append({"role": m.role, "content": m.content})
        return system_blocks, chat

    def _parse(self, response: Any) -> LLMResponse:
        for block in response.content:
            if getattr(block, "type", None) == "tool_use":
                data = block.input
                raw = json.dumps(data) if isinstance(data, dict) else str(data)
                if not isinstance(data, dict):
                    raise ValueError(f"tool_use input was not a JSON object: {type(data).__name__}")
                usage = self._usage(response)
                return LLMResponse(data=data, raw=raw, usage=usage)
        raise ValueError("Anthropic response had no tool_use block; did tool_choice misfire?")

    @staticmethod
    def _usage(response: Any) -> dict[str, int]:
        usage = getattr(response, "usage", None)
        if usage is None:
            return {}
        out: dict[str, int] = {}
        for attr in (
            "input_tokens",
            "output_tokens",
            "cache_creation_input_tokens",
            "cache_read_input_tokens",
        ):
            value = getattr(usage, attr, None)
            if isinstance(value, int):
                out[attr] = value
        return out
