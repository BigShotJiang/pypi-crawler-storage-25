"""Google Gemini concrete impl of LLMClient.

JSON-schema enforcement via Google's structured-output config:
``response_mime_type="application/json"`` plus ``response_schema=<schema>``
on the generation config. The model is forced to emit JSON that
validates against the schema; we parse the response's ``.text`` field.

System prompts are passed via ``system_instruction`` on the config (not
as a chat message — Gemini distinguishes the two). User and assistant
turns map to ``contents`` with roles ``user`` and ``model``.

Implicit prompt caching: Gemini 2.5 caches prompts above a per-model
threshold (``gemini-2.5-flash`` ~1024 input tokens, ``gemini-2.5-pro``
~2048). The proposer prompt (system + EvidencePack + schema) clears
that bar; no per-call flag is needed.

The ``google-genai`` SDK is an optional dependency (``[llm-google]`` /
``[llm]`` extras). This module raises a clear ImportError at import
time if the SDK is missing.
"""

from __future__ import annotations

import json
import os
from collections.abc import Mapping, Sequence
from typing import Any

try:
    from google import genai  # noqa: F401
    from google.genai import types as _genai_types  # noqa: F401
except ImportError as _exc:  # pragma: no cover - exercised only when extra missing
    raise ImportError(
        "GoogleClient requires the 'google-genai' SDK. "
        "Install with: uv pip install 'ml4t-agent[llm-google]'"
    ) from _exc

from .base import LLMResponse, Message

__all__ = ["GoogleClient"]

DEFAULT_MODEL = "gemini-2.5-flash"


class GoogleClient:
    """LLMClient backed by Google's GenerativeAI SDK (google-genai).

    Parameters
    ----------
    model
        Model id. Default is ``gemini-2.5-flash`` — cheap, fast, and
        adequate for the JSON-schema-bounded proposer prompt. Pass
        ``model="gemini-2.5-pro"`` to swap to the flagship.
    api_key
        Optional override for ``GOOGLE_API_KEY`` (also accepts
        ``GEMINI_API_KEY``).
    """

    def __init__(
        self,
        *,
        model: str = DEFAULT_MODEL,
        api_key: str | None = None,
    ) -> None:
        key = api_key or os.environ.get("GOOGLE_API_KEY") or os.environ.get("GEMINI_API_KEY")
        if not key:
            raise RuntimeError(
                "GOOGLE_API_KEY (or GEMINI_API_KEY) not set; pass api_key= or set the env var"
            )
        self._client = genai.Client(api_key=key)
        self._model = model

    def complete_with_schema(
        self,
        messages: Sequence[Message],
        json_schema: Mapping[str, Any],
        *,
        max_tokens: int = 1024,
        temperature: float | None = 0.0,
    ) -> LLMResponse:
        system_text, contents = self._partition(messages)
        config: dict[str, Any] = {
            "response_mime_type": "application/json",
            "response_schema": dict(json_schema),
            "max_output_tokens": max_tokens,
        }
        if system_text:
            config["system_instruction"] = system_text
        if temperature is not None:
            config["temperature"] = temperature

        generate: Any = self._client.models.generate_content
        response = generate(
            model=self._model,
            contents=contents,
            config=config,
        )
        return self._parse(response)

    @staticmethod
    def _partition(messages: Sequence[Message]) -> tuple[str, list[dict[str, Any]]]:
        """Split system messages out and translate role names.

        Gemini uses ``user`` and ``model`` for chat roles; an ``assistant``
        message becomes ``model``. Multiple system messages concatenate
        into a single ``system_instruction`` (Gemini accepts only one).
        """
        system_parts: list[str] = []
        contents: list[dict[str, Any]] = []
        for m in messages:
            if m.role == "system":
                system_parts.append(m.content)
            else:
                role = "model" if m.role == "assistant" else "user"
                contents.append({"role": role, "parts": [{"text": m.content}]})
        return "\n\n".join(system_parts), contents

    def _parse(self, response: Any) -> LLMResponse:
        raw = getattr(response, "text", None)
        if not isinstance(raw, str) or not raw:
            raise ValueError("Google response had no string text")
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Google response was not valid JSON: {exc}") from exc
        if not isinstance(data, dict):
            raise ValueError(f"Google response was not a JSON object: {type(data).__name__}")
        return LLMResponse(data=data, raw=raw, usage=self._usage(response))

    @staticmethod
    def _usage(response: Any) -> dict[str, int]:
        meta = getattr(response, "usage_metadata", None)
        if meta is None:
            return {}
        out: dict[str, int] = {}
        for src, dst in (
            ("prompt_token_count", "prompt_tokens"),
            ("candidates_token_count", "completion_tokens"),
            ("total_token_count", "total_tokens"),
            ("cached_content_token_count", "cached_tokens"),
        ):
            value = getattr(meta, src, None)
            if isinstance(value, int):
                out[dst] = value
        return out
