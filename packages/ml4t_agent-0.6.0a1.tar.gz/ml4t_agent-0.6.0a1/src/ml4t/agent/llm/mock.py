"""Deterministic recorder/replay client used in tests and notebooks.

Two modes:

- **Replay (default)**: a dict ``{cache_key: LLMResponse}`` is supplied at
  construction; ``complete_with_schema`` looks up the recorded response
  by hash of (messages + json_schema + sampling params). Missing keys
  raise ``MockReplayMissError`` so tests never silently fall through to
  a real network call.
- **Record**: pass ``record_to=path``. The client computes the cache key
  for each call, looks up a user-supplied ``responder`` (or the existing
  recording), and writes the merged dictionary back to disk on each
  call. The recording file is JSON; ``load_recording`` reconstructs
  the replay dict.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Callable, Mapping, Sequence
from dataclasses import asdict
from pathlib import Path
from typing import Any

from .base import LLMResponse, Message

__all__ = [
    "MockLLMClient",
    "MockReplayMissError",
    "load_recording",
    "save_recording",
    "compute_cache_key",
]


class MockReplayMissError(KeyError):
    """Raised when no recorded response exists for the given call."""


Responder = Callable[[Sequence[Message], Mapping[str, Any]], LLMResponse]


class MockLLMClient:
    """In-memory replay (or record-to-disk) implementation of LLMClient."""

    def __init__(
        self,
        recordings: Mapping[str, LLMResponse] | None = None,
        *,
        responder: Responder | None = None,
        record_to: Path | str | None = None,
    ) -> None:
        if responder is None and recordings is None:
            raise ValueError("must supply recordings or a responder (or both)")
        self._recordings: dict[str, LLMResponse] = dict(recordings or {})
        self._responder = responder
        self._record_path = Path(record_to) if record_to is not None else None
        self.calls: list[tuple[str, LLMResponse]] = []

    def complete_with_schema(
        self,
        messages: Sequence[Message],
        json_schema: Mapping[str, Any],
        *,
        max_tokens: int = 1024,
        temperature: float | None = 0.0,
    ) -> LLMResponse:
        key = compute_cache_key(messages, json_schema, max_tokens, temperature)
        response = self._recordings.get(key)
        if response is None:
            if self._responder is None:
                raise MockReplayMissError(
                    f"no recorded response for key {key} and no responder supplied"
                )
            response = self._responder(messages, json_schema)
            self._recordings[key] = response
            if self._record_path is not None:
                save_recording(self._recordings, self._record_path)
        self.calls.append((key, response))
        return response


def compute_cache_key(
    messages: Sequence[Message],
    json_schema: Mapping[str, Any],
    max_tokens: int,
    temperature: float | None,
) -> str:
    """Stable hash of the request inputs."""
    payload = {
        "messages": [
            {"role": m.role, "content": m.content, "cacheable": m.cacheable} for m in messages
        ],
        "json_schema": _canon(json_schema),
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


def save_recording(recordings: Mapping[str, LLMResponse], path: Path | str) -> None:
    out = Path(path)
    payload = {key: asdict(resp) for key, resp in recordings.items()}
    out.write_text(
        json.dumps(payload, sort_keys=True, indent=2),
        encoding="utf-8",
    )


def load_recording(path: Path | str) -> dict[str, LLMResponse]:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError(f"{path}: expected JSON object")
    out: dict[str, LLMResponse] = {}
    for key, entry in raw.items():
        try:
            out[str(key)] = LLMResponse(
                data=entry["data"],
                raw=str(entry["raw"]),
                usage={str(k): int(v) for k, v in (entry.get("usage") or {}).items()},
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"{path}: malformed recording for {key!r}: {exc}") from exc
    return out


def _canon(obj: Any) -> Any:
    """JSON-canonicalize: dict keys sorted, lists preserved."""
    if isinstance(obj, Mapping):
        return {str(k): _canon(obj[k]) for k in sorted(obj, key=str)}
    if isinstance(obj, list | tuple):
        return [_canon(v) for v in obj]
    return obj
