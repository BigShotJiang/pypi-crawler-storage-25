# ml4t.agent Package

Package-level navigation for the public `ml4t-agent` surface. The repo
root `AGENTS.md` covers install + quick start; this page indexes the
per-subpackage navigation files.

## Main modules

| File | Lines | Purpose |
|------|-------|---------|
| `__init__.py` | 37 | v0.1 public exports (schemas, tools, agents, LLM adapter) |
| `tracing.py` | 84 | `AgentTraceStep`, `AgentRun`, `trace_to_json`, `trace_from_json` |

## Subpackages

| Directory | Purpose | AGENTS |
|-----------|---------|--------|
| `schemas/` | Round-2 typed dataclasses (5-file split) | [schemas/AGENTS.md](schemas/AGENTS.md) |
| `tools/` | Bounded tool functions (evidence, proposals, reruns, handoff) | [tools/AGENTS.md](tools/AGENTS.md) |
| `agents/` | `ResearchReviewAgent` ReAct loop | [agents/AGENTS.md](agents/AGENTS.md) |
| `llm/` | Provider-agnostic LLM adapter (`base`, `mock`, opt-in `anthropic`) | [llm/AGENTS.md](llm/AGENTS.md) |
| `discipline/` | `ml4t-diagnostic` wrappers (Bonferroni; DSR/PBO in v0.2) | [discipline/AGENTS.md](discipline/AGENTS.md) |
| `_benchmark/` | **Archived** v0.5/v0.6 scaffolding (private; not part of v0.1 surface) | [_benchmark/AGENTS.md](_benchmark/AGENTS.md) |
