# discipline/ — Reuse `ml4t-diagnostic` primitives

Thin wrappers over `ml4t.diagnostic`. The diagnostic library is the
source of truth for Holm-Bonferroni, the Deflated Sharpe Ratio, and the
Probability of Backtest Overfitting; this package adapts those
array-shaped APIs to the plan-shaped call sites the agent uses.

## Files

| File | Lines | Purpose |
|------|-------|---------|
| `bonferroni.py` | 84 | `bonferroni_alpha_for_iteration(alpha, k)`, `validate_iteration_alpha` — k-th iteration alpha for a research line |

## Why a wrapper

`ml4t.diagnostic.evaluation.stats.false_discovery_rate.holm_bonferroni`
operates on p-value arrays. The agent's call site is plan-shaped: stamp
`bonferroni_k = line_state.iteration_index` onto every plan, then
verify the criterion's `adjusted_alpha` matches the wrapper's output.
The wrapper keeps the call site readable without forking the math.

DSR / PBO wrappers are scheduled for v0.2 alongside the template
catalogue expansion.
