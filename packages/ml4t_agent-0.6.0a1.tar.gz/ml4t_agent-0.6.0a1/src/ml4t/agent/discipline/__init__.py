"""Loop-discipline policy helpers (multiple-comparisons, etc.).

See ``plans/27_loop_discipline_policy.md``.
"""

from .bonferroni import (
    bonferroni_alpha_for_iteration,
    holm_bonferroni,
    validate_iteration_alpha,
)

__all__ = [
    "bonferroni_alpha_for_iteration",
    "holm_bonferroni",
    "validate_iteration_alpha",
]
