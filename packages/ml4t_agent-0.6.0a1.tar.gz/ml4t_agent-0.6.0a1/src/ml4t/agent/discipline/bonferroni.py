"""Bonferroni alpha schedule for the iteration loop.

The agent's research-line iteration tightens the per-iteration confidence
interval as ``alpha / k`` where ``k`` is the 1-based iteration index. This
module owns that one-line policy and a defensive validator that the
``IterationPlan`` agrees with its ``LineState`` on the schedule.

The full p-value step-down procedure (``holm_bonferroni``) lives in
``ml4t.diagnostic``; it is re-exported here so call sites that want the
diagnostic primitive can import it from a single discipline namespace.

See ``plans/27_loop_discipline_policy.md`` §3.3 for the math and motivation.
"""

from __future__ import annotations

from ml4t.diagnostic.evaluation.stats.false_discovery_rate import holm_bonferroni

from ml4t.agent.schemas import IterationPlan, PlanValidationError

__all__ = [
    "bonferroni_alpha_for_iteration",
    "holm_bonferroni",
    "validate_iteration_alpha",
]


def bonferroni_alpha_for_iteration(alpha: float, k: int) -> float:
    """Return the Bonferroni-adjusted alpha for the k-th iteration.

    Parameters
    ----------
    alpha
        Base significance level. Must be in ``(0, 1)``.
    k
        1-based iteration index. Must be ``>= 1``.

    Returns
    -------
    float
        ``alpha`` when ``k == 1``; otherwise ``alpha / k``.
    """
    if not 0.0 < alpha < 1.0:
        raise ValueError(f"alpha must be in (0, 1), got {alpha}")
    if k < 1:
        raise ValueError(f"k must be >= 1, got {k}")
    return alpha if k == 1 else alpha / k


def validate_iteration_alpha(plan: IterationPlan) -> None:
    """Verify the IterationPlan's alpha schedule is internally consistent.

    Each ``ExperimentPlan.delta_criterion`` in ``plan.plans`` must agree with
    ``plan.line_state`` on:

    - ``bonferroni_k == line_state.iteration_index``
    - ``base_alpha   == line_state.base_alpha``
    - ``adjusted_alpha == bonferroni_alpha_for_iteration(base_alpha, k)``

    Raises
    ------
    PlanValidationError
        On the first disagreement found.
    """
    line = plan.line_state
    expected = bonferroni_alpha_for_iteration(line.base_alpha, line.iteration_index)
    for ep in plan.plans:
        crit = ep.delta_criterion
        if crit.bonferroni_k != line.iteration_index:
            raise PlanValidationError(
                f"experiment {ep.experiment_id}: bonferroni_k="
                f"{crit.bonferroni_k} != line_state.iteration_index="
                f"{line.iteration_index}"
            )
        if crit.base_alpha != line.base_alpha:
            raise PlanValidationError(
                f"experiment {ep.experiment_id}: base_alpha="
                f"{crit.base_alpha} != line_state.base_alpha="
                f"{line.base_alpha}"
            )
        if crit.adjusted_alpha != expected:
            raise PlanValidationError(
                f"experiment {ep.experiment_id}: adjusted_alpha="
                f"{crit.adjusted_alpha} != expected={expected}"
            )
