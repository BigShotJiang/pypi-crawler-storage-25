"""Deterministic post-construction audit of an :class:`ExperimentPlan`.

The single load-bearing piece of v0.5 (per plan-31 §v0.5.1, branch D —
the v0.5.0 falsification spike found K=0 substantive errors against
gpt-5-mini, so the LLM ``ReviewerAgent`` was dropped and ``validate_plan``
is the entire deterministic gate). Five refusal kinds, all evaluable in
pure Python from a ``(plan, template, pack)`` triple.

Distinct from :func:`ml4t.agent.schemas.validate_plan` (which raises
``PlanValidationError`` on *structural* contract violations against a
template). This function returns refusals — it does not raise — because
the multi-agent loop wants to *report* refusals (and short-circuit the
LLM reviewer that is no longer there) rather than abort.

Refusal kinds, evaluated in order:

1. :attr:`RefusalKind.PREDICATE_MISMATCH` — re-run every
   ``template.preconditions`` predicate against the pack and flag any
   that return False or raise ``PredicateUnavailable``.
2. :attr:`RefusalKind.MISSING_RECEIPT` — for every methodology warning
   whose ``code`` is referenced in the plan's ``rationale``, the
   rationale must also reference the warning's ``triggering_artifact``
   (or ``triggering_field``).
3. :attr:`RefusalKind.THRESHOLD_DRIFT` — for templates that anchor
   their delta thresholds to a pack value (currently T-A2, anchored to
   ``signal.best_mean_ic``), re-derive the expected thresholds from the
   pack and refuse if the plan's drifted by > tolerance.
4. :attr:`RefusalKind.BONFERRONI_OVER_BUDGET` — discipline-policy
   floor: ``adjusted_alpha < BONFERRONI_FLOOR`` means the line has
   burned its multiple-comparisons budget.
5. :attr:`RefusalKind.PRESET_REGISTRY_RECEIPT` — preset-name lookup
   on every ``list[str]`` override at a preset-naming yaml path. The
   check is a no-op when ``pack.preset_registry`` is absent (the v0.6
   runner contract has not yet wired it), so this does not regress
   T-M1 / T-F1 in fixture mode. When the registry is present, every
   preset name not in the registry generates a refusal — the
   spike-surfaced "cheap proposers confabulate plausible-looking but
   nonexistent preset names" error class is then caught
   deterministically.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Final

from ml4t.agent.schemas import (
    PREDICATES,
    EvidencePack,
    ExperimentPlan,
    ExperimentTemplate,
    PredicateUnavailable,
    Refusal,
    RefusalKind,
)

__all__ = [
    "validate_plan",
    "BONFERRONI_FLOOR",
    "THRESHOLD_DRIFT_TOLERANCE",
    "PRESET_REGISTRY_YAML_PATHS",
]

# Discipline-policy floor on adjusted alpha. With base_alpha=0.05 this
# permits up to bonferroni_k=10 before refusal; beyond k=10 the line
# has consumed its multiple-comparisons budget and should stop rather
# than propose another iteration. The number is intentionally
# conservative — if the user wants a longer line, they raise the floor.
BONFERRONI_FLOOR: Final[float] = 0.005

# ±10% tolerance on pack-anchored thresholds (T-A2). Plan-31 §v0.5
# specifies this default.
THRESHOLD_DRIFT_TOLERANCE: Final[float] = 0.10

# yaml_paths whose `list[str]` overrides reference preset names that
# must exist in a runner-side registry. Extend as new preset-naming
# templates ship.
PRESET_REGISTRY_YAML_PATHS: Final[frozenset[tuple[str, ...]]] = frozenset(
    {
        ("gbm",),  # T-M1's GBM preset list
    }
)

# Keys on `pack.validation.signal` that templates may anchor thresholds
# to. Extending the audit means adding the (template_id → anchor) entry
# in `_THRESHOLD_ANCHORS` below.
_THRESHOLD_ANCHORS: Final[Mapping[str, tuple[str, float, float]]] = {
    # template_id → (anchor field path, support offset, reject offset)
    "T-A2": ("validation.signal.best_mean_ic", -0.002, -0.010),
}


def validate_plan(
    plan: ExperimentPlan,
    template: ExperimentTemplate,
    pack: EvidencePack,
) -> tuple[Refusal, ...]:
    """Deterministic semantic audit. Returns the refusals; never raises.

    Empty tuple = the plan is coherent with the pack. One or more
    refusals = the plan is structurally valid (it already passed
    :func:`ml4t.agent.schemas.validate_plan`) but fails one or more
    coherence checks against the pack it claims to act on.
    """

    refusals: list[Refusal] = []
    refusals.extend(_check_predicates(template, pack))
    refusals.extend(_check_receipts(plan, pack))
    refusals.extend(_check_threshold_drift(plan, template, pack))
    refusals.extend(_check_bonferroni_budget(plan))
    refusals.extend(_check_preset_registry(plan, template, pack))
    return tuple(refusals)


# --- 1. predicate mismatch --------------------------------------------------


def _check_predicates(
    template: ExperimentTemplate,
    pack: EvidencePack,
) -> list[Refusal]:
    out: list[Refusal] = []
    for i, name in enumerate(template.preconditions):
        predicate = PREDICATES.get(name)
        if predicate is None:
            out.append(
                Refusal(
                    kind=RefusalKind.PREDICATE_MISMATCH,
                    message=(
                        f"template references unknown predicate {name!r}; "
                        "PREDICATES registry has no entry"
                    ),
                    field_path=f"template.preconditions[{i}]",
                    cited_evidence=(),
                )
            )
            continue
        try:
            ok = predicate(pack)
        except PredicateUnavailable as exc:
            out.append(
                Refusal(
                    kind=RefusalKind.PREDICATE_MISMATCH,
                    message=(
                        f"predicate {name!r} unavailable on pack: {exc}; "
                        "the proposer claimed eligibility but the pack does "
                        "not expose the artefact this predicate needs"
                    ),
                    field_path=f"template.preconditions[{i}]:{name}",
                    cited_evidence=(),
                )
            )
            continue
        if not ok:
            out.append(
                Refusal(
                    kind=RefusalKind.PREDICATE_MISMATCH,
                    message=(
                        f"predicate {name!r} re-evaluated to False on the "
                        "current pack; the proposer's eligibility claim is "
                        "stale or based on a different pack snapshot"
                    ),
                    field_path=f"template.preconditions[{i}]:{name}",
                    cited_evidence=(),
                )
            )
    return out


# --- 2. missing receipt -----------------------------------------------------


def _check_receipts(plan: ExperimentPlan, pack: EvidencePack) -> list[Refusal]:
    """Every warning code cited in the rationale must also have its
    triggering_artifact (or triggering_field) cited.

    Substring match. Both are freetext citations; this is the cheapest
    deterministic check that catches "name-drops a warning code without
    saying which artefact backs it" — the most common failure mode the
    chapter calls out for confabulation guards.
    """

    rationale = plan.rationale
    out: list[Refusal] = []
    for i, w in enumerate(pack.warnings):
        if w.code not in rationale:
            continue
        artifact_cited = w.triggering_artifact in rationale
        field_cited = w.triggering_field is not None and w.triggering_field in rationale
        if not (artifact_cited or field_cited):
            backings: list[str] = [w.triggering_artifact]
            if w.triggering_field:
                backings.append(w.triggering_field)
            out.append(
                Refusal(
                    kind=RefusalKind.MISSING_RECEIPT,
                    message=(
                        f"rationale cites warning {w.code!r} but does not "
                        f"reference its receipt; expected one of "
                        f"{backings!r} to appear verbatim in rationale"
                    ),
                    field_path="rationale",
                    cited_evidence=(f"warnings[{i}].triggering_artifact",),
                )
            )
    return out


# --- 3. threshold drift -----------------------------------------------------


def _check_threshold_drift(
    plan: ExperimentPlan,
    template: ExperimentTemplate,
    pack: EvidencePack,
) -> list[Refusal]:
    anchor = _THRESHOLD_ANCHORS.get(template.template_id)
    if anchor is None:
        return []  # template doesn't anchor to pack values
    field_path, support_offset, reject_offset = anchor
    anchor_value = _resolve_pack_path(pack, field_path)
    if anchor_value is None:
        return []  # anchor field absent — covered by predicate check
    expected_support = anchor_value + support_offset
    expected_reject = anchor_value + reject_offset

    out: list[Refusal] = []
    actual_support = plan.delta_criterion.support_threshold
    actual_reject = plan.delta_criterion.reject_threshold
    if not _within_tolerance(actual_support, expected_support):
        out.append(
            Refusal(
                kind=RefusalKind.THRESHOLD_DRIFT,
                message=(
                    f"delta_criterion.support_threshold={actual_support:.6f} "
                    f"drifted from re-derived value {expected_support:.6f} "
                    f"(anchor={field_path}={anchor_value:.6f}, "
                    f"offset={support_offset:+.6f}, "
                    f"tolerance=±{THRESHOLD_DRIFT_TOLERANCE:.0%})"
                ),
                field_path="delta_criterion.support_threshold",
                cited_evidence=(field_path,),
            )
        )
    if not _within_tolerance(actual_reject, expected_reject):
        out.append(
            Refusal(
                kind=RefusalKind.THRESHOLD_DRIFT,
                message=(
                    f"delta_criterion.reject_threshold={actual_reject:.6f} "
                    f"drifted from re-derived value {expected_reject:.6f} "
                    f"(anchor={field_path}={anchor_value:.6f}, "
                    f"offset={reject_offset:+.6f}, "
                    f"tolerance=±{THRESHOLD_DRIFT_TOLERANCE:.0%})"
                ),
                field_path="delta_criterion.reject_threshold",
                cited_evidence=(field_path,),
            )
        )
    return out


def _within_tolerance(actual: float, expected: float) -> bool:
    if abs(expected) < 1e-9:
        # Anchor near zero: fall back to absolute tolerance to avoid
        # division by ~0; tolerance scales as a fraction of base_alpha
        # (0.05 * 0.10 = 0.005), the same magnitude as the relative
        # tolerance at typical IC values.
        return abs(actual - expected) <= 0.005
    return abs(actual - expected) <= THRESHOLD_DRIFT_TOLERANCE * abs(expected)


def _resolve_pack_path(pack: EvidencePack, dotted: str) -> float | None:
    """Resolve a dotted path like ``validation.signal.best_mean_ic`` against
    the pack. Returns the float value, or None if any segment is missing."""
    obj: object = pack
    for segment in dotted.split("."):
        obj = getattr(obj, segment, None)
        if obj is None:
            return None
    if isinstance(obj, int | float) and not isinstance(obj, bool):
        return float(obj)
    return None


# --- 4. bonferroni budget ---------------------------------------------------


def _check_bonferroni_budget(plan: ExperimentPlan) -> list[Refusal]:
    adjusted = plan.delta_criterion.adjusted_alpha
    if adjusted < BONFERRONI_FLOOR:
        return [
            Refusal(
                kind=RefusalKind.BONFERRONI_OVER_BUDGET,
                message=(
                    f"adjusted_alpha={adjusted:.5f} below floor "
                    f"{BONFERRONI_FLOOR} (bonferroni_k="
                    f"{plan.delta_criterion.bonferroni_k}, base_alpha="
                    f"{plan.delta_criterion.base_alpha}); the line has "
                    "consumed its multiple-comparisons budget"
                ),
                field_path="delta_criterion.bonferroni_k",
                cited_evidence=(),
            )
        ]
    return []


# --- 5. preset-registry receipt ---------------------------------------------


def _check_preset_registry(
    plan: ExperimentPlan,
    template: ExperimentTemplate,
    pack: EvidencePack,
) -> list[Refusal]:
    """Refuse `list[str]` overrides at preset-naming yaml paths whose
    values are not in the runner's registry.

    The registry lives on the pack as ``pack.preset_registry`` (typed as
    ``frozenset[str] | None`` since v0.6). When ``None`` (the runner did
    not expose a registry) the check is a no-op — we do not refuse plans
    that would have been valid in v0.4 just because the runner has not
    yet shipped the receipt. When the registry is present, each preset
    name not in the registry generates a refusal.
    """

    registry = pack.preset_registry
    if registry is None:
        return []  # runner has not exposed a registry on this pack
    out: list[Refusal] = []
    spec_index = {(s.path_template, s.yaml_path): s for s in template.allowed_overrides}
    for i, patch in enumerate(plan.config_patches):
        if patch.yaml_path not in PRESET_REGISTRY_YAML_PATHS:
            continue
        spec = spec_index.get((patch.path_template, patch.yaml_path))
        if spec is None or spec.value_type != "list[str]":
            continue
        if not isinstance(patch.new_value, list | tuple):
            continue  # structural validator already covered this
        unknown = [
            name for name in patch.new_value if isinstance(name, str) and name not in registry
        ]
        if unknown:
            out.append(
                Refusal(
                    kind=RefusalKind.PRESET_REGISTRY_RECEIPT,
                    message=(
                        f"config_patches[{i}].new_value cites preset names "
                        f"not in the runner registry: {unknown!r}"
                    ),
                    field_path=f"config_patches[{i}].new_value",
                    cited_evidence=("preset_registry",),
                )
            )
    return out
