# agents/ — ReAct loop

The single-agent ReAct loop that drives one iteration of a research
line. v0.1 ships exactly one agent class; v0.6 will add a supervisor
that orchestrates multiple instances.

## Files

| File | Lines | Purpose |
|------|-------|---------|
| `single.py` | 366 | `ResearchReviewAgent` — five-step ReAct loop, mock-mode default |

## Loop steps

1. **read evidence** — `read_case_study_evidence` returns the typed `EvidencePack`
2. **propose** — `propose_experiments` (LLM-bounded; JSON-schema-validated)
3. **rerun** — `run_cost_sensitivity` against the selected proposal (skipped if no eligible plan)
4. **evaluate** — `recommend_decision` over the typed `DeltaReview`
5. **decide** — emit `ResearchNote` with the recommended `Decision`

The loop short-circuits at step 1 if any `BLOCKING` warning is on the
pack — the LLM is never called.

## Trace

Every step is recorded on an `AgentTraceStep`, and the full `AgentRun` is
exposed at `agent.last_run` for inspection. `trace_to_json` /
`trace_from_json` (in `tracing.py`) round-trip the run for archive.
