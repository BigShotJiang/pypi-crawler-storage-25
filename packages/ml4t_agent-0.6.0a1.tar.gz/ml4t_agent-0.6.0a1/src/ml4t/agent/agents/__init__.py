"""Closed-loop agents that consume tools + the LLM adapter."""

from .multi import MultiAgentResult, run_proposer_with_validation
from .single import DELTA_REVIEW_FILENAME, ResearchReviewAgent
from .validate_plan import (
    BONFERRONI_FLOOR,
    PRESET_REGISTRY_YAML_PATHS,
    THRESHOLD_DRIFT_TOLERANCE,
    validate_plan,
)

__all__ = [
    "ResearchReviewAgent",
    "DELTA_REVIEW_FILENAME",
    "validate_plan",
    "BONFERRONI_FLOOR",
    "THRESHOLD_DRIFT_TOLERANCE",
    "PRESET_REGISTRY_YAML_PATHS",
    "MultiAgentResult",
    "run_proposer_with_validation",
]
