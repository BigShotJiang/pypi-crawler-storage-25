"""Multi-agent composition: proposer → deterministic validate_plan.

Per plan-31 §v0.5.1 branch D (after the v0.5.0 falsification spike
returned K=0 substantive errors against gpt-5-mini), the v0.5
multi-agent loop is the proposer wired to the deterministic validator
— no LLM reviewer in the chain. The chapter narrative defends the
*architecture* (proposer + deterministic gate) and explicitly cites
the spike as the falsification that justified dropping the reviewer.

The function returns *both* the accepted plans and the per-experiment
refusals so callers can log the deterministic verdicts (the chapter
beat about "we caught the spike's preset-name confabulation
deterministically" needs the refusals visible to the runner).
"""

from __future__ import annotations

from collections.abc import Sequence

from ml4t.agent.llm import LLMClient
from ml4t.agent.schemas import (
    EvidencePack,
    ExperimentPlan,
    ExperimentTemplate,
    LineState,
    Refusal,
)
from ml4t.agent.tools import default_templates, propose_experiments

from .validate_plan import validate_plan

__all__ = ["MultiAgentResult", "run_proposer_with_validation"]


class MultiAgentResult:
    """Return type for :func:`run_proposer_with_validation`.

    Plain class (not a dataclass) so the public API is two attribute
    accesses — ``result.accepted`` and ``result.refusals`` — without
    callers having to remember tuple-unpacking order. ``__iter__`` lets
    callers do ``accepted, refusals = result`` if they prefer the
    tuple form.
    """

    __slots__ = ("accepted", "refusals")

    def __init__(
        self,
        accepted: tuple[ExperimentPlan, ...],
        refusals: tuple[tuple[ExperimentPlan, tuple[Refusal, ...]], ...],
    ) -> None:
        self.accepted = accepted
        self.refusals = refusals

    def __iter__(self):
        yield self.accepted
        yield self.refusals

    def __repr__(self) -> str:  # pragma: no cover - convenience
        return f"MultiAgentResult(accepted={len(self.accepted)}, refused={len(self.refusals)})"


def run_proposer_with_validation(
    evidence: EvidencePack,
    *,
    llm: LLMClient,
    line_state: LineState,
    templates: Sequence[ExperimentTemplate] | None = None,
    parent_run_id: str | None = None,
    max_proposals: int = 4,
    temperature: float | None = 0.0,
) -> MultiAgentResult:
    """Run the proposer, then deterministically validate every plan.

    The proposer call (one LLM round-trip) is unchanged from
    :func:`ml4t.agent.tools.propose_experiments`. After it returns, each
    plan is audited by :func:`validate_plan` against the same
    ``EvidencePack`` and its template. Plans whose audit returns an empty
    refusal tuple appear in ``result.accepted``; plans that produce one
    or more refusals appear in ``result.refusals`` paired with the
    refusal tuple.

    The function never makes a *second* LLM call (no reviewer step) —
    the spike result justifies that omission and the chapter narrative
    documents it. If a future fixture or proposer combination motivates
    revisiting the reviewer, re-run the spike harness in
    ``tests/agents/spike/`` against that surface first.
    """

    catalogue = tuple(templates) if templates is not None else default_templates(evidence)
    plans = propose_experiments(
        evidence,
        llm=llm,
        line_state=line_state,
        templates=catalogue,
        parent_run_id=parent_run_id,
        max_proposals=max_proposals,
        temperature=temperature,
    )
    by_template = {t.template_id: t for t in catalogue}

    accepted: list[ExperimentPlan] = []
    refused: list[tuple[ExperimentPlan, tuple[Refusal, ...]]] = []
    for plan in plans:
        template = by_template.get(plan.template_id)
        if template is None:  # pragma: no cover - propose_experiments guards
            continue
        refusals = validate_plan(plan, template, evidence)
        if refusals:
            refused.append((plan, refusals))
        else:
            accepted.append(plan)
    return MultiAgentResult(tuple(accepted), tuple(refused))
