"""Load ETF benchmark definitions from ML4T case-study configs."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .contracts import ActionManifest, BranchSpec, EnvironmentManifest
from .io import read_payload


class CaseStudyConfigError(ValueError):
    """Raised when the ETF case-study contract is incomplete or inconsistent."""


@dataclass(frozen=True, slots=True)
class BenchmarkDefinition:
    """Normalized ETF benchmark definition derived from case-study configs."""

    environment: EnvironmentManifest
    action_manifest: ActionManifest
    canonical_branch: BranchSpec
    setup_version: str
    primary_label: str
    case_study_root: Path


def load_etf_benchmark(case_study_root: str | Path) -> BenchmarkDefinition:
    """Load the normalized ETF benchmark contract from a case-study directory."""
    root = Path(case_study_root)
    config_dir = root / "config"
    setup = read_payload(config_dir / "setup.yaml")
    cv_config = read_payload(config_dir / "cv_config.json")
    training_primary = read_payload(config_dir / "training" / "fwd_ret_21d.yaml")

    strategy_id = str(setup.get("strategy_id", ""))
    if strategy_id != "etfs":
        raise CaseStudyConfigError(f"expected strategy_id 'etfs', got {strategy_id!r}")

    labels = dict(setup.get("labels") or {})
    evaluation = dict(setup.get("evaluation") or {})
    mapping = dict(setup.get("mapping") or {})
    primary_label = str(labels.get("primary", ""))
    variants = tuple(str(item) for item in labels.get("variants", []) or [])
    allowed_labels = (primary_label, *variants)
    if not primary_label or primary_label != "fwd_ret_21d":
        raise CaseStudyConfigError("expected primary ETF label 'fwd_ret_21d'")

    _require_training_bundle(training_primary, "linear", ("ols", "ridge_a0.1"))
    _require_training_bundle(training_primary, "gbm", ("default_mse", "default_huber"))
    _require_training_bundle(training_primary, "tabular_dl", ("tabm_s",))
    _require_training_bundle(training_primary, "latent_factors", ("pca",))

    setup_version = str(setup.get("setup_version", "v1"))
    environment = EnvironmentManifest(
        environment_id="etf_daily_v0",
        manifest_version=setup_version,
        holdout_start=_required_str(evaluation, "holdout_start"),
        holdout_end=_required_str(evaluation, "holdout_end"),
        allowed_labels=allowed_labels,
        allowed_feature_regimes=("financial_only", "financial_plus_temporal"),
        allowed_model_bundles=(
            "linear_baseline",
            "gbm_default",
            "tabular_dl_small",
            "latent_factor_pca",
        ),
        allowed_top_n=(5, 10, 15),
        weighting_scheme=_required_str(mapping, "sizing"),
    )
    action_manifest = ActionManifest(
        manifest_version=setup_version,
        allowed_labels=environment.allowed_labels,
        allowed_feature_regimes=environment.allowed_feature_regimes,
        allowed_model_bundles=environment.allowed_model_bundles,
        allowed_top_n=environment.allowed_top_n,
        allowed_weighting_schemes=(environment.weighting_scheme,),
    )
    canonical_branch = BranchSpec(
        label=primary_label,
        feature_regime="financial_only",
        model_bundle="linear_baseline",
        top_n=10,
        weighting_scheme=environment.weighting_scheme,
        created_reason="canonical_reference_branch",
    )

    _validate_cv_contract(cv_config)

    return BenchmarkDefinition(
        environment=environment,
        action_manifest=action_manifest,
        canonical_branch=canonical_branch,
        setup_version=setup_version,
        primary_label=primary_label,
        case_study_root=root,
    )


def _required_str(mapping: dict[str, object], key: str) -> str:
    value = mapping.get(key)
    if value is None or str(value) == "":
        raise CaseStudyConfigError(f"missing required field: {key}")
    return str(value)


def _require_training_bundle(
    training_menu: dict[str, object],
    family: str,
    presets: tuple[str, ...],
) -> None:
    raw_available = training_menu.get(family)
    if isinstance(raw_available, list | tuple):
        available = tuple(str(item) for item in raw_available)
    else:
        available = ()
    missing = [preset for preset in presets if preset not in available]
    if missing:
        missing_text = ", ".join(missing)
        raise CaseStudyConfigError(f"training family {family!r} missing presets: {missing_text}")


def _validate_cv_contract(cv_config: dict[str, object]) -> None:
    expected = {
        "n_splits": 8,
        "train_size": "10Y",
        "test_size": "1Y",
        "embargo_td": "P21D",
        "label_horizon": "P21D",
        "calendar_id": "NYSE",
    }
    for key, value in expected.items():
        observed = cv_config.get(key)
        if observed != value:
            raise CaseStudyConfigError(
                f"unexpected cv_config[{key!r}]={observed!r}; expected {value!r}"
            )


__all__ = ["BenchmarkDefinition", "CaseStudyConfigError", "load_etf_benchmark"]
