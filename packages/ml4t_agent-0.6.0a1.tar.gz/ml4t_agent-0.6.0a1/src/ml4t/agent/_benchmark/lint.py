"""Mechanical methodology lint for ETF benchmark trial state."""

from __future__ import annotations

from dataclasses import dataclass

from .contracts import LintReport, LintRuleResult, TrialState
from .policy import AutonomyPolicy, PolicyViolation
from .trace import TraceValidator


@dataclass(frozen=True, slots=True)
class BenchmarkLinter:
    """Run the minimal v0 methodology checks against trial state."""

    policy: AutonomyPolicy
    version: str = "v0"
    trace_validator: TraceValidator = TraceValidator()

    def run(self, state: TrialState) -> LintReport:
        results = (
            self._as_of_and_leakage(state),
            self._cv_contract(state),
            self._holdout_access(state),
            self._cost_attachment(state),
            self._metadata_completeness(state),
            self._branch_policy(state),
            self._submission_envelope_readiness(state),
        )
        status = "pass" if all(result.status == "pass" for result in results) else "fail"
        return LintReport(
            lint_run_id=f"lint:{self.version}:{state.context.trial_id}",
            status=status,
            rules_run=tuple(result.rule_id for result in results),
            results=results,
        )

    def _as_of_and_leakage(self, state: TrialState) -> LintRuleResult:
        return self._result(
            rule_id="rule_1",
            ok=state.as_of_valid,
            message="as-of contract valid" if state.as_of_valid else "as-of or leakage violation",
        )

    def _cv_contract(self, state: TrialState) -> LintRuleResult:
        return self._result(
            rule_id="rule_2",
            ok=state.cv_contract_valid,
            message="cv contract valid" if state.cv_contract_valid else "cv contract violation",
        )

    def _holdout_access(self, state: TrialState) -> LintRuleResult:
        ok = not state.prior_holdout_access
        return self._result(
            rule_id="rule_3",
            ok=ok,
            message="no prior holdout access"
            if ok
            else "holdout access detected before submission",
        )

    def _cost_attachment(self, state: TrialState) -> LintRuleResult:
        return self._result(
            rule_id="rule_4",
            ok=state.cost_contract_valid,
            message="cost contract valid" if state.cost_contract_valid else "cost contract missing",
        )

    def _metadata_completeness(self, state: TrialState) -> LintRuleResult:
        required_values = (
            state.context.environment_version,
            state.context.action_manifest_version,
            state.context.autonomy_policy_version,
            state.context.stats_protocol_version,
            state.context.runtime_id,
            state.context.model_id,
            state.context.model_version,
            state.context.docs_pack_id,
        )
        ok = state.context.benchmark_seed >= 0 and all(bool(value) for value in required_values)
        return self._result(
            rule_id="rule_5",
            ok=ok,
            message="metadata complete" if ok else "required reproducibility metadata missing",
        )

    def _branch_policy(self, state: TrialState) -> LintRuleResult:
        try:
            self.policy.validate_trial_state(state)
        except PolicyViolation as exc:
            return self._result(
                rule_id="rule_6",
                ok=False,
                message=str(exc),
            )
        return self._result(rule_id="rule_6", ok=True, message="branch policy valid")

    def _submission_envelope_readiness(self, state: TrialState) -> LintRuleResult:
        trace_validation = self.trace_validator.validate(state)
        required_artifacts = {
            "TrialContext",
            "EnvironmentSpec",
            "ActionMenu",
            "BranchSpec",
            "ModelRun",
            "CVResult",
            "BacktestResult",
        }
        missing = sorted(required_artifacts - set(state.emitted_artifact_types))
        ok = (
            trace_validation.valid
            and state.trace_valid
            and not missing
            and state.final_branch_id is not None
        )
        message = "submission envelope valid"
        if not trace_validation.valid:
            message = trace_validation.reason or "trace invalid"
        elif not state.trace_valid:
            message = "trace invalid"
        elif missing:
            message = f"missing required artifacts: {', '.join(missing)}"
        elif state.final_branch_id is None:
            message = "missing final branch selection"
        return self._result(
            rule_id="rule_7",
            ok=ok,
            message=message,
        )

    def _result(self, rule_id: str, ok: bool, message: str) -> LintRuleResult:
        return LintRuleResult(
            rule_id=rule_id,
            status="pass" if ok else "fail",
            severity="error",
            message=message,
        )


__all__ = ["BenchmarkLinter"]
