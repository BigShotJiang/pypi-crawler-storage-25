"""Methodology-delta evaluation between unconstrained and constrained runs."""

from __future__ import annotations

from dataclasses import dataclass

from .contracts import (
    BenchmarkTask,
    FailureExpectation,
    LintReport,
    MethodologyFailureMode,
    TrialState,
)


def _rule_failed(report: LintReport | None, rule_id: str) -> bool:
    if report is None:
        return False
    return any(result.rule_id == rule_id and result.status == "fail" for result in report.results)


def _observed(expectation: FailureExpectation, state: TrialState) -> bool:
    if any(_rule_failed(state.lint_report, rule_id) for rule_id in expectation.harness_rule_ids):
        return True

    match expectation.failure_mode:
        case MethodologyFailureMode.FULL_SAMPLE_PREPROCESSING:
            return not state.as_of_valid
        case MethodologyFailureMode.FOLD_BOUNDARY_VIOLATION:
            return not state.cv_contract_valid
        case MethodologyFailureMode.THRESHOLD_PROVENANCE_ERROR:
            return not state.as_of_valid
        case MethodologyFailureMode.PURGING_EMBARGO_VIOLATION:
            return not state.cv_contract_valid
        case MethodologyFailureMode.HOLDOUT_MISUSE:
            return state.prior_holdout_access
        case MethodologyFailureMode.ARTIFACT_LINEAGE_GAP:
            return not state.trace_valid
        case MethodologyFailureMode.UNTRACKED_BRANCH_CHANGE:
            return not state.trace_valid
        case MethodologyFailureMode.RANDOM_SEED_MISSING:
            return False


@dataclass(frozen=True, slots=True)
class FailureDeltaObservation:
    """Observed status for one expected failure mode across two run conditions."""

    expectation: FailureExpectation
    observed_in_unconstrained: bool
    observed_in_constrained: bool

    @property
    def prevented_by_harness(self) -> bool:
        return self.observed_in_unconstrained and not self.observed_in_constrained


@dataclass(frozen=True, slots=True)
class MethodologyDeltaReport:
    """Summary of the methodology delta on one benchmark task."""

    task_id: str
    delta_id: str
    valid_comparison: bool
    unconstrained_failure_count: int
    constrained_failure_count: int
    prevented_failure_count: int
    residual_failure_count: int
    observations: tuple[FailureDeltaObservation, ...]
    summary: str


def evaluate_methodology_delta(
    task: BenchmarkTask,
    unconstrained_state: TrialState,
    constrained_state: TrialState,
) -> MethodologyDeltaReport:
    """Compare methodology failures across unconstrained and constrained runs."""
    observations = tuple(
        FailureDeltaObservation(
            expectation=expectation,
            observed_in_unconstrained=_observed(expectation, unconstrained_state),
            observed_in_constrained=_observed(expectation, constrained_state),
        )
        for expectation in task.methodology_delta_spec.expectations
    )
    unconstrained_failure_count = sum(item.observed_in_unconstrained for item in observations)
    constrained_failure_count = sum(item.observed_in_constrained for item in observations)
    prevented_failure_count = sum(item.prevented_by_harness for item in observations)
    residual_failure_count = sum(
        item.observed_in_unconstrained and item.observed_in_constrained for item in observations
    )
    valid_comparison = (
        unconstrained_state.context.docs_pack_id == constrained_state.context.docs_pack_id
    )
    summary = (
        f"prevented {prevented_failure_count} of {unconstrained_failure_count} expected "
        f"methodology failures"
    )
    return MethodologyDeltaReport(
        task_id=task.task_id,
        delta_id=task.methodology_delta_spec.delta_id,
        valid_comparison=valid_comparison,
        unconstrained_failure_count=unconstrained_failure_count,
        constrained_failure_count=constrained_failure_count,
        prevented_failure_count=prevented_failure_count,
        residual_failure_count=residual_failure_count,
        observations=observations,
        summary=summary,
    )


__all__ = [
    "FailureDeltaObservation",
    "MethodologyDeltaReport",
    "evaluate_methodology_delta",
]
