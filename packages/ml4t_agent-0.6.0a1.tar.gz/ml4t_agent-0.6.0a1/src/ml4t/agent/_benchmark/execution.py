"""Thin integration adapters for reusable ML4T execution surfaces."""

from __future__ import annotations

from dataclasses import dataclass
from importlib import import_module
from typing import Any


class ExecutionAdapterError(ImportError):
    """Raised when an expected ML4T execution surface is unavailable."""


def _load_attr(module_name: str, attr_name: str) -> Any:
    try:
        module = import_module(module_name)
    except ImportError as exc:
        raise ExecutionAdapterError(f"could not import {module_name}") from exc
    try:
        return getattr(module, attr_name)
    except AttributeError as exc:
        raise ExecutionAdapterError(f"{module_name} has no attribute {attr_name}") from exc


@dataclass(frozen=True, slots=True)
class Ml4tExecutionAdapters:
    """Minimal library-bound execution surfaces used by the benchmark harness."""

    def compute_features(self, data: Any, features: Any) -> Any:
        compute_features = _load_attr("ml4t.engineer", "compute_features")
        return compute_features(data, features)

    def validated_cross_val_score(
        self,
        estimator: Any,
        X: Any,
        y: Any,
        *,
        config: Any,
        groups: Any | None = None,
        sample_weight: Any | None = None,
    ) -> Any:
        validated_cross_val_score = _load_attr("ml4t.diagnostic", "validated_cross_val_score")
        return validated_cross_val_score(
            estimator,
            X,
            y,
            config=config,
            groups=groups,
            sample_weight=sample_weight,
        )

    def run_case_study_backtest(self, **kwargs: Any) -> Any:
        run_backtest = _load_attr("case_studies.utils.backtest_runner", "run_backtest")
        return run_backtest(**kwargs)


__all__ = ["ExecutionAdapterError", "Ml4tExecutionAdapters"]
