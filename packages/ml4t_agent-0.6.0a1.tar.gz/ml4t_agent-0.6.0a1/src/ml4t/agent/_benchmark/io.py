"""Low-level payload I/O for agent benchmark configs."""

from __future__ import annotations

import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any

import yaml


def read_payload(path_or_mapping: str | Path | Mapping[str, Any]) -> dict[str, Any]:
    """Load YAML or JSON payloads into a mutable dict."""
    if isinstance(path_or_mapping, Mapping):
        return {str(key): value for key, value in path_or_mapping.items()}

    path = Path(path_or_mapping)
    with path.open() as handle:
        if path.suffix.lower() == ".json":
            data = json.load(handle)
        else:
            data = yaml.safe_load(handle)
    return dict(data or {})


__all__ = ["read_payload"]
