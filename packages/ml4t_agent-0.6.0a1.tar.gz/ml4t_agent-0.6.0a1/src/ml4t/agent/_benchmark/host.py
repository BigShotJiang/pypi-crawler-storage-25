"""Typed host-adapter protocol for execution engines."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol

from .contracts import AutonomyLevel, HostAdapterSpec


@dataclass(frozen=True, slots=True)
class HostRunRequest:
    """One benchmark task invocation handed to an execution host."""

    pack_id: str
    task_id: str
    trial_id: str
    prompt_brief: str
    docs_pack_id: str
    document_refs: tuple[str, ...]
    skill_refs: tuple[str, ...]
    working_directory: str
    autonomy_level: AutonomyLevel
    selectable_surfaces: tuple[str, ...]
    sealed_surfaces: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class HostRunResult:
    """Normalized host response captured by the benchmark harness."""

    adapter_id: str
    trial_id: str
    success: bool
    summary: str
    emitted_artifact_types: tuple[str, ...] = ()
    observed_branch_hashes: tuple[str, ...] = ()
    trace_ref: str | None = None
    raw_output_ref: str | None = None
    metadata: dict[str, object] = field(default_factory=dict)


class AgentHostAdapter(Protocol):
    """Protocol implemented by benchmark execution hosts."""

    spec: HostAdapterSpec

    def run(self, request: HostRunRequest) -> HostRunResult:
        """Execute one benchmark task and return a normalized result."""


@dataclass(frozen=True, slots=True)
class ReplayHostAdapter:
    """Small test double for host-adapter integration."""

    spec: HostAdapterSpec
    result: HostRunResult

    def run(self, request: HostRunRequest) -> HostRunResult:
        if request.trial_id != self.result.trial_id:
            return HostRunResult(
                adapter_id=self.spec.adapter_id,
                trial_id=request.trial_id,
                success=False,
                summary="trial_id_mismatch",
            )
        return self.result


__all__ = [
    "AgentHostAdapter",
    "HostRunRequest",
    "HostRunResult",
    "ReplayHostAdapter",
]
