"""Case-study runtime adapters for ETF benchmark execution."""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path

from .contracts import BranchSpec
from .loader import BenchmarkDefinition


@dataclass(frozen=True, slots=True)
class CaseStudyArtifactInventory:
    """Resolved on-disk artifacts for a branch inside one ETF case study."""

    label_path: Path
    feature_paths: tuple[Path, ...]
    training_config_path: Path
    backtest_config_path: Path
    registry_db_path: Path

    def existing_artifact_types(self) -> frozenset[str]:
        artifact_types = {"TrialContext", "EnvironmentSpec", "ActionMenu", "BranchSpec"}
        if self.label_path.exists():
            artifact_types.add("LabelSpec")
        if all(path.exists() for path in self.feature_paths):
            artifact_types.add("FeatureSet")
        if self.training_config_path.exists():
            artifact_types.add("ModelRun")
            artifact_types.add("CVResult")
        if self.backtest_config_path.exists():
            artifact_types.add("BacktestResult")
        return frozenset(artifact_types)


@dataclass(frozen=True, slots=True)
class CaseStudyStageResult:
    """Subprocess-backed stage execution record."""

    stage_id: str
    command: tuple[str, ...]
    returncode: int
    stdout: str
    stderr: str

    @property
    def ok(self) -> bool:
        return self.returncode == 0


@dataclass(frozen=True, slots=True)
class ETFCaseStudyRuntime:
    """Bridge from benchmark branches to ETF case-study files and scripts."""

    definition: BenchmarkDefinition
    repo_root: Path

    @classmethod
    def from_definition(
        cls,
        definition: BenchmarkDefinition,
        *,
        repo_root: str | Path | None = None,
    ) -> ETFCaseStudyRuntime:
        case_study_root = definition.case_study_root.resolve()
        resolved_repo_root = Path(repo_root).resolve() if repo_root else case_study_root.parents[2]
        return cls(definition=definition, repo_root=resolved_repo_root)

    def artifact_inventory(self, branch: BranchSpec) -> CaseStudyArtifactInventory:
        root = self.definition.case_study_root
        feature_paths = [root / "features" / "financial.parquet"]
        if branch.feature_regime == "financial_plus_temporal":
            feature_paths.append(root / "features" / "model_based.parquet")
        return CaseStudyArtifactInventory(
            label_path=root / "labels" / f"{branch.label}.parquet",
            feature_paths=tuple(feature_paths),
            training_config_path=root / "config" / "training" / f"{branch.label}.yaml",
            backtest_config_path=root / "config" / "backtest" / "base.yaml",
            registry_db_path=root / "run_log" / "registry.db",
        )

    def workflow_scripts_for_branch(self, branch: BranchSpec) -> tuple[str, ...]:
        scripts = ["01_setup.py", "02_labels.py", "03_financial_features.py"]
        if branch.feature_regime == "financial_plus_temporal":
            scripts.append("04_model_based_features.py")
        scripts.extend(self._model_scripts(branch))
        scripts.append("14_backtest.py")
        return tuple(scripts)

    def run_stage(
        self,
        stage_script: str,
        *,
        extra_args: tuple[str, ...] = (),
        timeout_seconds: int | None = None,
    ) -> CaseStudyStageResult:
        case_study_rel = self.definition.case_study_root.resolve().relative_to(self.repo_root)
        script_rel = case_study_rel / stage_script
        command = ("uv", "run", "python", str(script_rel), *extra_args)
        completed = subprocess.run(
            command,
            cwd=self.repo_root,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
        return CaseStudyStageResult(
            stage_id=stage_script,
            command=command,
            returncode=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
        )

    def _model_scripts(self, branch: BranchSpec) -> tuple[str, ...]:
        bundle_to_scripts = {
            "linear_baseline": ("06_linear.py",),
            "gbm_default": ("07_gbm.py",),
            "tabular_dl_small": ("08_tabular_dl.py",),
            "latent_factor_pca": ("11a_pca.py",),
        }
        try:
            return bundle_to_scripts[branch.model_bundle]
        except KeyError as exc:
            raise ValueError(f"unsupported model bundle: {branch.model_bundle}") from exc


__all__ = ["CaseStudyArtifactInventory", "CaseStudyStageResult", "ETFCaseStudyRuntime"]
