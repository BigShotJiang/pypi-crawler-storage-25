# _benchmark/ — Archived scaffolding (v0.5 / v0.6 promotion)

Earlier ambition: a research-to-production benchmark, kill-test,
sealed-submission gateway, host adapter, lint, and replay harness. ~4,900
LOC across 17 source files and 14 test files. Dropped from
`ml4t.agent.__all__` in the v0.1 cut so the public surface stays small;
preserved here for promotion in v0.5 (cross-case-study sweep) and v0.6
(coding-agent supervisor).

## Public guarantee

**Nothing in this directory is part of the v0.1 public API.** Imports
from `ml4t.agent._benchmark` are unsupported. The leading underscore is
the public-API gate.

## Files

| Module | Promotion target |
|--------|-----------------|
| `benchmark.py`, `comparison.py`, `delta.py`, `loader.py`, `reporting.py` | v0.5 — cross-case-study sweep |
| `kill_test.py` (729 lines) | v0.5 — research-to-production benchmark |
| `gateway.py`, `policy.py`, `runtime.py`, `host.py`, `harness.py`, `execution.py`, `lint.py` | v0.6 — coding-agent supervisor |
| `contracts.py`, `trace.py`, `io.py` | shared utilities; promote with their consumers |

## CLI

`ml4t-agent-kill-test` resolves to `ml4t.agent._benchmark.kill_test:main`.
It still works in v0.1 but is a private operator tool until promotion.

## Tests

Existing tests under `tests/_benchmark/` remain green; they pin the
behaviour while the surface waits for promotion.
