"""Trial and cell-level reporting helpers for benchmark runs."""

from __future__ import annotations

from dataclasses import dataclass
from statistics import median

from .contracts import SubmissionReceipt, TrialState


@dataclass(frozen=True, slots=True)
class TrialReport:
    """One-trial benchmark summary compatible with the statistical protocol."""

    trial_id: str
    cell_id: str
    benchmark_seed: int
    autonomy_level: str
    valid_submission: bool
    lint_pass: bool
    trace_valid: bool
    branch_count: int
    repair_count: int
    final_branch_id: str | None
    initial_validation_utility: float | None
    final_validation_utility: float | None
    delta_initial_to_final_validation: float | None
    submission_id: str | None
    rejected_reason: str | None


@dataclass(frozen=True, slots=True)
class CellSummary:
    """Small operational summary across a cell's trial reports."""

    cell_id: str
    trial_count: int
    valid_submission_rate: float
    lint_pass_rate: float
    trace_valid_rate: float
    median_branch_count: float
    median_repair_count: float


def build_trial_report(
    state: TrialState,
    receipt: SubmissionReceipt | None = None,
) -> TrialReport:
    sorted_branches = list(state.branches)
    initial_validation = sorted_branches[0].validation_utility if sorted_branches else None
    final_branch = state.branch_by_id(state.final_branch_id) if state.final_branch_id else None
    final_validation = final_branch.validation_utility if final_branch is not None else None
    delta = None
    if initial_validation is not None and final_validation is not None:
        delta = final_validation - initial_validation

    return TrialReport(
        trial_id=state.context.trial_id,
        cell_id=state.context.cell_id,
        benchmark_seed=state.context.benchmark_seed,
        autonomy_level=state.context.autonomy_level.value,
        valid_submission=receipt.accepted if receipt is not None else False,
        lint_pass=state.lint_report.is_passing if state.lint_report is not None else False,
        trace_valid=state.trace_valid,
        branch_count=state.branch_count(),
        repair_count=sum(branch.repair_count for branch in state.branches),
        final_branch_id=state.final_branch_id,
        initial_validation_utility=initial_validation,
        final_validation_utility=final_validation,
        delta_initial_to_final_validation=delta,
        submission_id=receipt.submission_id if receipt is not None else None,
        rejected_reason=receipt.rejected_reason if receipt is not None else None,
    )


def summarize_cell(reports: list[TrialReport]) -> CellSummary:
    if not reports:
        raise ValueError("reports must not be empty")

    trial_count = len(reports)
    return CellSummary(
        cell_id=reports[0].cell_id,
        trial_count=trial_count,
        valid_submission_rate=sum(report.valid_submission for report in reports) / trial_count,
        lint_pass_rate=sum(report.lint_pass for report in reports) / trial_count,
        trace_valid_rate=sum(report.trace_valid for report in reports) / trial_count,
        median_branch_count=float(median(report.branch_count for report in reports)),
        median_repair_count=float(median(report.repair_count for report in reports)),
    )


__all__ = ["CellSummary", "TrialReport", "build_trial_report", "summarize_cell"]
