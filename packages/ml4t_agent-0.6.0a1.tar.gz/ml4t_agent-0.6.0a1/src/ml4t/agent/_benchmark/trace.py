"""Mechanical trace validation for ETF benchmark trials."""

from __future__ import annotations

from dataclasses import dataclass

from .contracts import TraceEventType, TrialState


@dataclass(frozen=True, slots=True)
class TraceValidationResult:
    """Trace validity result with a concrete failure reason when invalid."""

    valid: bool
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class TraceValidator:
    """Validate minimal event-sequence invariants for benchmark traces."""

    def validate(self, state: TrialState) -> TraceValidationResult:
        events = state.events
        if not events:
            return TraceValidationResult(False, "trace has no events")
        if events[0].event_type != TraceEventType.TRIAL_STARTED:
            return TraceValidationResult(False, "trace must begin with trial_started")

        created_branch_ids = {
            event.branch_id for event in events if event.event_type == TraceEventType.BRANCH_CREATED
        }
        expected_branch_ids = {branch.branch_id for branch in state.branches}
        if not expected_branch_ids.issubset(created_branch_ids):
            return TraceValidationResult(False, "missing branch_created event")

        if state.final_branch_id is not None:
            final_events = [
                event
                for event in events
                if event.event_type == TraceEventType.BRANCH_SELECTED_FINAL
                and event.branch_id == state.final_branch_id
            ]
            if not final_events:
                return TraceValidationResult(False, "missing final branch selection event")

        if state.submission_attempt_count > 0:
            event_types = [event.event_type for event in events]
            if TraceEventType.SUBMISSION_ATTEMPTED not in event_types:
                return TraceValidationResult(False, "missing submission_attempted event")
            if TraceEventType.SUBMISSION_RESULT not in event_types:
                return TraceValidationResult(False, "missing submission_result event")
            if events[-1].event_type != TraceEventType.TRIAL_COMPLETED:
                return TraceValidationResult(False, "submitted trial must end with trial_completed")

        return TraceValidationResult(True)


__all__ = ["TraceValidationResult", "TraceValidator"]
