"""Sealed submission gateway validation."""

from __future__ import annotations

import json
from dataclasses import dataclass
from hashlib import sha256

from .contracts import SubmissionReceipt, SubmissionRequest, TrialState
from .policy import AutonomyPolicy, PolicyViolation


def _submission_id(trial_id: str, branch_id: str, attempt_count: int) -> str:
    payload = json.dumps(
        {"trial_id": trial_id, "branch_id": branch_id, "attempt_count": attempt_count},
        sort_keys=True,
        separators=(",", ":"),
    )
    return sha256(payload.encode("utf-8")).hexdigest()[:16]


@dataclass(frozen=True, slots=True)
class SubmissionGateway:
    """Single entry point for holdout evaluation eligibility."""

    policy: AutonomyPolicy

    def submit(
        self,
        request: SubmissionRequest,
        state: TrialState,
        holdout_metrics: dict[str, float] | None = None,
    ) -> SubmissionReceipt:
        rejected_reason = self._rejection_reason(request, state)
        accepted = rejected_reason is None
        return SubmissionReceipt(
            submission_id=_submission_id(
                request.trial_id,
                request.branch_id,
                state.submission_attempt_count + 1,
            ),
            trial_id=request.trial_id,
            branch_id=request.branch_id,
            accepted=accepted,
            rejected_reason=rejected_reason,
            holdout_release_status="released" if accepted else "withheld",
            holdout_metrics_if_released=holdout_metrics or {} if accepted else {},
        )

    def _rejection_reason(self, request: SubmissionRequest, state: TrialState) -> str | None:
        if request.trial_id != state.context.trial_id:
            return "trial_id_mismatch"
        if state.submission_attempt_count > 0:
            return "submission_already_consumed"
        if state.prior_holdout_access:
            return "prior_holdout_access_detected"
        if not state.trace_valid:
            return "trace_invalid"

        try:
            self.policy.validate_trial_state(state)
        except PolicyViolation as exc:
            return str(exc)

        branch = state.branch_by_id(request.branch_id)
        if branch is None:
            return "unknown_branch_id"
        if branch.branch_spec.branch_hash() != request.branch_spec_hash:
            return "branch_hash_mismatch"
        if state.final_branch_id != request.branch_id:
            return "submitted_branch_is_not_final_branch"
        if state.lint_report is None:
            return "missing_lint_report"
        if state.lint_report.lint_run_id != request.lint_run_id:
            return "lint_run_id_mismatch"
        if not state.lint_report.is_passing:
            return "lint_failed"

        missing_artifacts = set(request.required_artifact_types) - set(state.emitted_artifact_types)
        if missing_artifacts:
            return f"missing_artifacts:{','.join(sorted(missing_artifacts))}"
        return None


__all__ = ["SubmissionGateway"]
