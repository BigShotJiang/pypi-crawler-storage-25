"""Minimal paired ETF kill test for a real coding-agent host."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import time
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field, replace
from enum import StrEnum
from pathlib import Path
from typing import Any

from .benchmark import build_default_etf_benchmark_pack, build_host_run_request
from .comparison import BenchmarkComparisonReport, build_benchmark_comparison
from .contracts import (
    AutonomyLevel,
    BenchmarkPack,
    BenchmarkTask,
    BranchSpec,
    HostAdapterSpec,
    SubmissionReceipt,
    TrialState,
)
from .harness import ETFBenchmarkHarness
from .host import AgentHostAdapter, HostRunRequest, HostRunResult
from .loader import BenchmarkDefinition, load_etf_benchmark
from .reporting import TrialReport
from .runtime import ETFCaseStudyRuntime

PROMPT_FILE_NAME = "PROMPT.md"
RESULT_FILE_NAME = "ml4t_host_result.json"
STDOUT_FILE_NAME = "claude_stdout.log"
STDERR_FILE_NAME = "claude_stderr.log"
EXIT_CODE_FILE_NAME = "claude_exit_code.txt"
STAGE_MANIFEST_FILE_NAME = "ml4t_stage_manifest.json"
HOST_MANAGED_FILE_NAMES = (
    PROMPT_FILE_NAME,
    RESULT_FILE_NAME,
    STDOUT_FILE_NAME,
    STDERR_FILE_NAME,
    EXIT_CODE_FILE_NAME,
    STAGE_MANIFEST_FILE_NAME,
)

STRIPPED_CASE_STUDY_DIRS = (
    "run_log",
    "results",
    "models",
    "figures",
    "labels",
    "features",
    "evaluation",
)

RAW_BASELINE_BRIEF = (
    "Use the ETF case-study repo and the referenced docs to execute the canonical ETF research "
    "workflow and produce one final research submission attempt."
)
CONSTRAINED_BRIEF = (
    "Operate inside the ETF research contract, execute only the canonical validity workflow, "
    "and produce one final submission attempt without violating holdout, CV, or artifact rules."
)


class BenchmarkCondition(StrEnum):
    RAW = "raw"
    CONSTRAINED = "constrained"


@dataclass(frozen=True, slots=True)
class KillTestTrialResult:
    condition: BenchmarkCondition
    state: TrialState
    receipt: SubmissionReceipt
    report: TrialReport
    host_result: HostRunResult
    workdir: Path


@dataclass(frozen=True, slots=True)
class KillTestPairResult:
    raw: KillTestTrialResult
    constrained: KillTestTrialResult
    comparison: BenchmarkComparisonReport


@dataclass(frozen=True, slots=True)
class StageManifest:
    source_repo_root: str
    staged_repo_root: str
    case_study_root: str
    stripped_case_study_dirs: tuple[str, ...]
    allowed_output_roots: tuple[str, ...]
    copied_roots: tuple[str, ...]
    static_protocol_refs: tuple[str, ...]
    result_file_name: str = RESULT_FILE_NAME

    def to_dict(self) -> dict[str, object]:
        return {
            "source_repo_root": self.source_repo_root,
            "staged_repo_root": self.staged_repo_root,
            "case_study_root": self.case_study_root,
            "stripped_case_study_dirs": list(self.stripped_case_study_dirs),
            "allowed_output_roots": list(self.allowed_output_roots),
            "copied_roots": list(self.copied_roots),
            "static_protocol_refs": list(self.static_protocol_refs),
            "result_file_name": self.result_file_name,
        }


@dataclass(frozen=True, slots=True)
class ClaudeCodeHeadlessAdapter:
    spec: HostAdapterSpec
    claude_bin: str = "claude"
    timeout_seconds: int = 1800
    extra_flags: tuple[str, ...] = ()
    env_overrides: dict[str, str] = field(default_factory=dict)
    skip_permissions: bool = True

    def run(self, request: HostRunRequest) -> HostRunResult:
        workdir = Path(request.working_directory)
        workdir.mkdir(parents=True, exist_ok=True)
        baseline_snapshot = _snapshot_workspace(workdir)
        prompt_path = workdir / PROMPT_FILE_NAME
        prompt_path.write_text(request.prompt_brief, encoding="utf-8")

        command = [self.claude_bin, "--print"]
        if self.skip_permissions:
            command.append("--dangerously-skip-permissions")
        command.extend(self.extra_flags)
        command.append(f"@{prompt_path.name}")

        process_env = os.environ.copy()
        process_env.update(self.env_overrides)

        start = time.perf_counter()
        try:
            completed = subprocess.run(
                command,
                cwd=workdir,
                env=process_env,
                capture_output=True,
                text=True,
                timeout=self.timeout_seconds,
                check=False,
            )
        except FileNotFoundError as exc:
            elapsed = time.perf_counter() - start
            _write_text(workdir / STDERR_FILE_NAME, str(exc))
            _write_text(workdir / EXIT_CODE_FILE_NAME, "127")
            return _host_result_from_capture(
                request=request,
                spec=self.spec,
                workdir=workdir,
                exit_code=127,
                stdout="",
                stderr=str(exc),
                elapsed_seconds=elapsed,
                summary=f"{self.claude_bin}_not_found",
            )
        except subprocess.TimeoutExpired as exc:
            elapsed = time.perf_counter() - start
            stdout = _decode_output(exc.stdout)
            stderr = _decode_output(exc.stderr)
            _write_text(workdir / STDOUT_FILE_NAME, stdout)
            _write_text(workdir / STDERR_FILE_NAME, stderr)
            _write_text(workdir / EXIT_CODE_FILE_NAME, "124")
            return _host_result_from_capture(
                request=request,
                spec=self.spec,
                workdir=workdir,
                exit_code=124,
                stdout=stdout,
                stderr=stderr,
                elapsed_seconds=elapsed,
                summary="timeout",
            )

        elapsed = time.perf_counter() - start
        _write_text(workdir / STDOUT_FILE_NAME, completed.stdout)
        _write_text(workdir / STDERR_FILE_NAME, completed.stderr)
        _write_text(workdir / EXIT_CODE_FILE_NAME, str(completed.returncode))
        unexpected_write_paths = _detect_unexpected_writes(workdir, baseline_snapshot)
        return _host_result_from_capture(
            request=request,
            spec=self.spec,
            workdir=workdir,
            exit_code=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
            elapsed_seconds=elapsed,
            summary="completed" if completed.returncode == 0 else f"exit_{completed.returncode}",
            unexpected_write_paths=unexpected_write_paths,
        )


def build_condition_prompt(
    request: HostRunRequest,
    *,
    task: BenchmarkTask,
    branch: BranchSpec,
    branch_hash: str,
    condition: BenchmarkCondition,
    source_repo_root: Path,
    staged_repo_root: Path,
    workflow_scripts: Sequence[str],
) -> str:
    document_refs = "\n".join(
        f"- {_remap_document_ref(Path(ref), source_repo_root, staged_repo_root)}"
        for ref in request.document_refs
    )
    artifact_types = "\n".join(
        f"- {artifact_type}" for artifact_type in task.required_artifact_types
    )
    selectable = _render_items(request.selectable_surfaces) or "- none"
    sealed = _render_items(request.sealed_surfaces) or "- none"
    workflow = "\n".join(f"- {script}" for script in workflow_scripts)
    objective = RAW_BASELINE_BRIEF if condition == BenchmarkCondition.RAW else CONSTRAINED_BRIEF

    condition_block = (
        "Condition-specific rules:\n"
        "- You have ordinary repo access and the shared instructions below.\n"
        "- Use your own judgment to complete the canonical workflow.\n"
        "- Do not assume any hidden benchmark rules beyond the referenced docs.\n"
        if condition == BenchmarkCondition.RAW
        else "Condition-specific rules:\n"
        "- Treat the canonical branch below as fixed for this L1 run.\n"
        "- Do not inspect or release holdout results before the final submission attempt.\n"
        "- Keep the fixed environment and sealed surfaces untouched.\n"
        f"{sealed}\n"
    )

    return (
        "# ETF Kill Test\n\n"
        f"Objective:\n{objective}\n\n"
        "Working assumptions shared across both conditions:\n"
        "- Work only inside this staged repo copy.\n"
        "- Prefer existing Python scripts over notebooks.\n"
        "- Construct the workflow outputs in this staged workspace.\n"
        "- Do not fabricate missing outputs. If blocked, say so explicitly.\n"
        f"- Before exiting, write `{RESULT_FILE_NAME}` at the repo root.\n\n"
        f"Working directory: {request.working_directory}\n"
        f"Autonomy level: {request.autonomy_level.value}\n"
        f"Task: {task.task_id}\n\n"
        "Canonical branch for this run:\n"
        f"- branch_hash: {branch_hash}\n"
        f"- label: {branch.label}\n"
        f"- feature_regime: {branch.feature_regime}\n"
        f"- model_bundle: {branch.model_bundle}\n"
        f"- top_n: {branch.top_n}\n"
        f"- weighting_scheme: {branch.weighting_scheme}\n\n"
        "Expected workflow scripts for this branch:\n"
        f"{workflow}\n\n"
        "Reference docs:\n"
        f"{document_refs}\n\n"
        "Required artifact types for an admissible submission:\n"
        f"{artifact_types}\n\n"
        "Selectable surfaces for this run:\n"
        f"{selectable}\n\n"
        f"{condition_block}\n"
        "Result file contract:\n"
        f"- Write JSON to `{RESULT_FILE_NAME}`.\n"
        "- Include these keys exactly:\n"
        '  - "summary": short plain-English outcome summary\n'
        '  - "emitted_artifact_types": list[str]\n'
        '  - "observed_branch_hashes": list[str]\n'
        '  - "prior_holdout_access": bool\n'
        '  - "as_of_valid": bool\n'
        '  - "cv_contract_valid": bool\n'
        '  - "cost_contract_valid": bool\n'
        '  - "trace_valid": bool\n'
        '  - "notes": list[str]\n'
        "- If you are unsure about a validity flag, set it to false and explain why in notes.\n"
    )


def run_kill_test_trial(
    definition: BenchmarkDefinition,
    *,
    condition: BenchmarkCondition,
    trial_id: str,
    benchmark_seed: int,
    model_id: str,
    model_version: str,
    runs_root: str | Path,
    adapter: AgentHostAdapter,
    pack: BenchmarkPack | None = None,
) -> KillTestTrialResult:
    active_pack = pack or build_default_etf_benchmark_pack(definition)
    task = active_pack.tasks[0]
    harness = ETFBenchmarkHarness.from_definition(definition)
    runtime = ETFCaseStudyRuntime.from_definition(
        definition, repo_root=definition.case_study_root.parents[1]
    )
    state = harness.new_trial(
        trial_id=trial_id,
        cell_id=f"{task.task_id}:{condition.value}",
        trace_id=f"trace:{trial_id}",
        benchmark_seed=benchmark_seed,
        runtime_id=active_pack.host_adapter.adapter_id,
        model_id=model_id,
        model_version=model_version,
        docs_pack_id=active_pack.docs_pack.docs_pack_id,
        autonomy_level=AutonomyLevel.VALIDITY_EXECUTION,
    )
    branch = state.branches[0]
    branch_hash = branch.branch_spec.branch_hash()
    trial_root = Path(runs_root) / trial_id
    staged_repo_root, staged_case_root = stage_case_study_repo(definition, trial_root)
    state = harness.attach_artifacts(state, "BranchSpec")
    workflow_scripts = runtime.workflow_scripts_for_branch(branch.branch_spec)

    request = build_host_run_request(
        active_pack,
        task,
        state,
        policy=harness.policy,
        working_directory=str(staged_repo_root),
    )
    prompt = build_condition_prompt(
        request,
        task=task,
        branch=branch.branch_spec,
        branch_hash=branch_hash,
        condition=condition,
        source_repo_root=definition.case_study_root.parents[1],
        staged_repo_root=staged_repo_root,
        workflow_scripts=workflow_scripts,
    )
    request = replace(request, prompt_brief=prompt)
    state = harness.record_host_run_request(state, request)
    result = adapter.run(request)
    state = harness.record_host_run_result(state, result)
    state = _apply_host_observations(state, result, expected_branch_hash=branch_hash)
    state, receipt, report = harness.submit(state)
    return KillTestTrialResult(
        condition=condition,
        state=state,
        receipt=receipt,
        report=report,
        host_result=result,
        workdir=staged_repo_root,
    )


def run_kill_test_pair(
    definition: BenchmarkDefinition,
    *,
    benchmark_seed: int,
    model_id: str,
    model_version: str,
    runs_root: str | Path,
    adapter: AgentHostAdapter,
    raw_trial_id: str = "raw_trial",
    constrained_trial_id: str = "constrained_trial",
) -> KillTestPairResult:
    pack = build_default_etf_benchmark_pack(definition)
    raw = run_kill_test_trial(
        definition,
        condition=BenchmarkCondition.RAW,
        trial_id=raw_trial_id,
        benchmark_seed=benchmark_seed,
        model_id=model_id,
        model_version=model_version,
        runs_root=runs_root,
        adapter=adapter,
        pack=pack,
    )
    constrained = run_kill_test_trial(
        definition,
        condition=BenchmarkCondition.CONSTRAINED,
        trial_id=constrained_trial_id,
        benchmark_seed=benchmark_seed,
        model_id=model_id,
        model_version=model_version,
        runs_root=runs_root,
        adapter=adapter,
        pack=pack,
    )
    comparison = build_benchmark_comparison(
        pack,
        pack.tasks[0],
        raw.state,
        constrained.state,
        unconstrained_receipt=raw.receipt,
        constrained_receipt=constrained.receipt,
    )
    return KillTestPairResult(raw=raw, constrained=constrained, comparison=comparison)


def stage_case_study_repo(
    definition: BenchmarkDefinition,
    trial_root: str | Path,
) -> tuple[Path, Path]:
    trial_path = Path(trial_root)
    staged_repo_root = trial_path / "repo"
    staged_case_root = staged_repo_root / "case_studies" / definition.case_study_root.name
    if staged_repo_root.exists():
        raise FileExistsError(f"staged repo already exists: {staged_repo_root}")

    source_repo_root = definition.case_study_root.parents[1]
    _copy_if_exists(source_repo_root / "pyproject.toml", staged_repo_root / "pyproject.toml")
    _copy_if_exists(source_repo_root / "uv.lock", staged_repo_root / "uv.lock")
    _copy_tree(
        source_repo_root / "case_studies" / "utils",
        staged_repo_root / "case_studies" / "utils",
    )
    _copy_tree(source_repo_root / "utils", staged_repo_root / "utils")
    _stage_data_package(source_repo_root, staged_repo_root)
    _copy_tree(
        definition.case_study_root,
        staged_case_root,
        ignore=shutil.ignore_patterns(
            "__pycache__",
            "*.pyc",
            "*.ipynb",
            ".ipynb_checkpoints",
            *STRIPPED_CASE_STUDY_DIRS,
        ),
    )
    for name in STRIPPED_CASE_STUDY_DIRS:
        (staged_case_root / name).mkdir(parents=True, exist_ok=True)
    _write_stage_manifest(
        StageManifest(
            source_repo_root=str(source_repo_root),
            staged_repo_root=str(staged_repo_root),
            case_study_root=str(staged_case_root),
            stripped_case_study_dirs=STRIPPED_CASE_STUDY_DIRS,
            allowed_output_roots=tuple(
                str(staged_case_root / name) for name in STRIPPED_CASE_STUDY_DIRS
            ),
            copied_roots=(
                str(staged_repo_root / "pyproject.toml"),
                str(staged_repo_root / "uv.lock"),
                str(staged_repo_root / "case_studies" / "utils"),
                str(staged_repo_root / "utils"),
                str(staged_repo_root / "data"),
                str(staged_case_root),
            ),
            static_protocol_refs=(
                str(staged_case_root / "config" / "setup.yaml"),
                str(staged_case_root / "config" / "training" / f"{definition.primary_label}.yaml"),
                str(staged_case_root / "config" / "cv_config.json"),
                str(staged_case_root / "README.md"),
            ),
        ),
        staged_repo_root / STAGE_MANIFEST_FILE_NAME,
    )
    return staged_repo_root, staged_case_root


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case-study-root", required=True)
    parser.add_argument("--runs-root", required=True)
    parser.add_argument("--benchmark-seed", type=int, default=1)
    parser.add_argument("--model-id", default="claude_code")
    parser.add_argument("--model-version", default="default")
    parser.add_argument("--claude-bin", default="claude")
    parser.add_argument("--timeout-seconds", type=int, default=1800)
    parser.add_argument("--model-flag")
    parser.add_argument("--raw-trial-id", default="raw_trial")
    parser.add_argument("--constrained-trial-id", default="constrained_trial")
    parser.add_argument(
        "--condition",
        choices=("pair", BenchmarkCondition.RAW.value, BenchmarkCondition.CONSTRAINED.value),
        default="pair",
    )
    args = parser.parse_args(argv)

    extra_flags = ("--model", args.model_flag) if args.model_flag else ()
    definition = load_etf_benchmark(args.case_study_root)
    pack = build_default_etf_benchmark_pack(definition)
    adapter = ClaudeCodeHeadlessAdapter(
        spec=pack.host_adapter,
        claude_bin=args.claude_bin,
        timeout_seconds=args.timeout_seconds,
        extra_flags=extra_flags,
    )
    if args.condition == "pair":
        result = run_kill_test_pair(
            definition,
            benchmark_seed=args.benchmark_seed,
            model_id=args.model_id,
            model_version=args.model_version,
            runs_root=args.runs_root,
            adapter=adapter,
            raw_trial_id=args.raw_trial_id,
            constrained_trial_id=args.constrained_trial_id,
        )
        print(result.comparison.headline)
        print(result.comparison.methodology_delta.summary)
        return 0

    condition = BenchmarkCondition(args.condition)
    trial_id = (
        args.raw_trial_id if condition == BenchmarkCondition.RAW else args.constrained_trial_id
    )
    result = run_kill_test_trial(
        definition,
        condition=condition,
        trial_id=trial_id,
        benchmark_seed=args.benchmark_seed,
        model_id=args.model_id,
        model_version=args.model_version,
        runs_root=args.runs_root,
        adapter=adapter,
    )
    print(
        f"{condition.value}: host_success={result.host_result.success} "
        f"valid_submission={result.report.valid_submission} "
        f"trace_valid={result.report.trace_valid}"
    )
    if result.receipt.rejected_reason:
        print(f"rejected_reason={result.receipt.rejected_reason}")
    return 0


def _apply_host_observations(
    state: TrialState,
    result: HostRunResult,
    *,
    expected_branch_hash: str,
) -> TrialState:
    metadata = result.metadata
    observed_hashes = tuple(str(item) for item in result.observed_branch_hashes)
    trace_valid = bool(metadata.get("trace_valid", result.success))
    if observed_hashes and expected_branch_hash not in observed_hashes:
        trace_valid = False

    return replace(
        state,
        prior_holdout_access=bool(metadata.get("prior_holdout_access", False)),
        as_of_valid=bool(metadata.get("as_of_valid", True)),
        cv_contract_valid=bool(metadata.get("cv_contract_valid", True)),
        cost_contract_valid=bool(metadata.get("cost_contract_valid", True)),
        trace_valid=trace_valid,
    )


def _copy_if_exists(source: Path, destination: Path) -> None:
    if not source.exists():
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def _copy_tree(source: Path, destination: Path, ignore: Any = None) -> None:
    if not source.exists():
        return
    shutil.copytree(source, destination, ignore=ignore, dirs_exist_ok=True)


def _stage_data_package(source_repo_root: Path, staged_repo_root: Path) -> None:
    data_root = staged_repo_root / "data"
    data_root.mkdir(parents=True, exist_ok=True)
    (data_root / "__init__.py").write_text(
        "from data.etfs.loader import list_etfs, load_etfs\n"
        "from data.exceptions import DataNotFoundError, DownloadError, MissingDependencyError\n"
        "\n"
        "__all__ = [\n"
        '    "list_etfs",\n'
        '    "load_etfs",\n'
        '    "DataNotFoundError",\n'
        '    "DownloadError",\n'
        '    "MissingDependencyError",\n'
        "]\n",
        encoding="utf-8",
    )
    _copy_if_exists(source_repo_root / "data" / "exceptions.py", data_root / "exceptions.py")
    _copy_tree(
        source_repo_root / "data" / "etfs",
        data_root / "etfs",
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.ipynb"),
    )


def _host_result_from_capture(
    *,
    request: HostRunRequest,
    spec: HostAdapterSpec,
    workdir: Path,
    exit_code: int,
    stdout: str,
    stderr: str,
    elapsed_seconds: float,
    summary: str,
    unexpected_write_paths: tuple[str, ...] = (),
) -> HostRunResult:
    payload_path = workdir / RESULT_FILE_NAME
    payload = _read_result_payload(payload_path)
    metadata: dict[str, object] = {
        "exit_code": exit_code,
        "wall_seconds": elapsed_seconds,
        "result_payload_present": payload is not None,
        "stdout_bytes": len(stdout.encode("utf-8")),
        "stderr_bytes": len(stderr.encode("utf-8")),
        "stage_manifest_ref": str(workdir / STAGE_MANIFEST_FILE_NAME),
    }
    for key in (
        "prior_holdout_access",
        "as_of_valid",
        "cv_contract_valid",
        "cost_contract_valid",
        "trace_valid",
        "notes",
    ):
        if payload is not None and key in payload:
            metadata[key] = payload[key]
    emitted_artifact_types = _read_str_list(payload, "emitted_artifact_types")
    observed_branch_hashes = _read_str_list(payload, "observed_branch_hashes")
    payload_summary = str(payload.get("summary", "")).strip() if payload is not None else ""
    if payload is None:
        metadata["trace_valid"] = False
    if unexpected_write_paths:
        metadata["unexpected_write_paths"] = list(unexpected_write_paths)
        metadata["trace_valid"] = False
    return HostRunResult(
        adapter_id=spec.adapter_id,
        trial_id=request.trial_id,
        success=exit_code == 0,
        summary=payload_summary or summary,
        emitted_artifact_types=emitted_artifact_types,
        observed_branch_hashes=observed_branch_hashes,
        trace_ref=str(payload_path) if payload is not None else None,
        raw_output_ref=str(workdir / STDOUT_FILE_NAME),
        metadata=metadata,
    )


def _read_result_payload(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {"summary": "invalid_result_payload", "trace_valid": False}


def _read_str_list(payload: Mapping[str, Any] | None, key: str) -> tuple[str, ...]:
    if payload is None:
        return ()
    raw_value = payload.get(key)
    if not isinstance(raw_value, list):
        return ()
    return tuple(str(item) for item in raw_value)


def _remap_document_ref(ref: Path, source_repo_root: Path, staged_repo_root: Path) -> str:
    if ref.is_absolute() and ref.is_relative_to(source_repo_root):
        return str(staged_repo_root / ref.relative_to(source_repo_root))
    return str(ref)


def _render_items(items: Sequence[str]) -> str:
    return "\n".join(f"- {item}" for item in items)


def _decode_output(value: bytes | str | None) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value or ""


def _write_text(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def _snapshot_workspace(root: Path) -> dict[str, tuple[int, int]]:
    snapshot: dict[str, tuple[int, int]] = {}
    for path in root.rglob("*"):
        if path.is_file():
            stat = path.stat()
            snapshot[str(path.relative_to(root))] = (stat.st_size, stat.st_mtime_ns)
    return snapshot


def _detect_unexpected_writes(
    workdir: Path,
    baseline_snapshot: Mapping[str, tuple[int, int]],
) -> tuple[str, ...]:
    manifest_path = workdir / STAGE_MANIFEST_FILE_NAME
    if not manifest_path.exists():
        return ()
    manifest = read_stage_manifest(manifest_path)
    allowed_roots = tuple(Path(root).resolve() for root in manifest.allowed_output_roots)
    current_snapshot = _snapshot_workspace(workdir)
    unexpected: list[str] = []
    for rel_path, fingerprint in current_snapshot.items():
        if rel_path in HOST_MANAGED_FILE_NAMES:
            continue
        if baseline_snapshot.get(rel_path) == fingerprint:
            continue
        absolute_path = (workdir / rel_path).resolve()
        if any(absolute_path.is_relative_to(root) for root in allowed_roots):
            continue
        unexpected.append(rel_path)
    return tuple(sorted(unexpected))


def _write_stage_manifest(manifest: StageManifest, path: Path) -> None:
    path.write_text(json.dumps(manifest.to_dict(), indent=2, sort_keys=True), encoding="utf-8")


def read_stage_manifest(path: str | Path) -> StageManifest:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    return StageManifest(
        source_repo_root=str(payload["source_repo_root"]),
        staged_repo_root=str(payload["staged_repo_root"]),
        case_study_root=str(payload["case_study_root"]),
        stripped_case_study_dirs=tuple(str(item) for item in payload["stripped_case_study_dirs"]),
        allowed_output_roots=tuple(str(item) for item in payload["allowed_output_roots"]),
        copied_roots=tuple(str(item) for item in payload["copied_roots"]),
        static_protocol_refs=tuple(str(item) for item in payload["static_protocol_refs"]),
        result_file_name=str(payload.get("result_file_name", RESULT_FILE_NAME)),
    )


__all__ = [
    "BenchmarkCondition",
    "ClaudeCodeHeadlessAdapter",
    "KillTestPairResult",
    "KillTestTrialResult",
    "STAGE_MANIFEST_FILE_NAME",
    "StageManifest",
    "build_condition_prompt",
    "read_stage_manifest",
    "run_kill_test_pair",
    "run_kill_test_trial",
    "stage_case_study_repo",
]
