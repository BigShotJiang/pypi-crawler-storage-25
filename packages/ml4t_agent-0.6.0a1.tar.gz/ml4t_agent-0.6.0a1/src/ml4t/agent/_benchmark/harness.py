"""Minimal ETF benchmark harness composed from the contract primitives."""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import TYPE_CHECKING

from .contracts import (
    AutonomyLevel,
    BranchSpec,
    BranchTrace,
    SubmissionReceipt,
    SubmissionRequest,
    TraceEvent,
    TraceEventType,
    TrialContext,
    TrialState,
)
from .gateway import SubmissionGateway
from .host import HostRunRequest, HostRunResult
from .lint import BenchmarkLinter
from .loader import BenchmarkDefinition
from .policy import AutonomyPolicy
from .reporting import TrialReport, build_trial_report

if TYPE_CHECKING:
    from .runtime import ETFCaseStudyRuntime


def _branch_id(branch_spec: BranchSpec) -> str:
    return f"branch:{branch_spec.branch_hash()[:12]}"


def _append_event(
    state: TrialState,
    event_type: TraceEventType,
    *,
    branch_id: str | None = None,
    workflow_step: str | None = None,
    status: str = "ok",
    detail: dict[str, object] | None = None,
) -> TrialState:
    event = TraceEvent(
        event_id=f"evt:{len(state.events) + 1}",
        event_type=event_type,
        trial_id=state.context.trial_id,
        trace_id=state.context.trace_id,
        branch_id=branch_id,
        workflow_step=workflow_step,
        status=status,
        detail=detail or {},
    )
    return replace(state, events=(*state.events, event))


@dataclass(frozen=True, slots=True)
class ETFBenchmarkHarness:
    """Thin composition layer for ETF benchmark trial lifecycle."""

    definition: BenchmarkDefinition
    policy: AutonomyPolicy
    linter: BenchmarkLinter
    gateway: SubmissionGateway

    @classmethod
    def from_definition(
        cls,
        definition: BenchmarkDefinition,
        policy: AutonomyPolicy | None = None,
    ) -> ETFBenchmarkHarness:
        active_policy = policy or AutonomyPolicy()
        return cls(
            definition=definition,
            policy=active_policy,
            linter=BenchmarkLinter(policy=active_policy),
            gateway=SubmissionGateway(policy=active_policy),
        )

    def new_trial(
        self,
        *,
        trial_id: str,
        cell_id: str,
        trace_id: str,
        benchmark_seed: int,
        runtime_id: str,
        model_id: str,
        model_version: str,
        docs_pack_id: str,
        autonomy_level: AutonomyLevel,
    ) -> TrialState:
        context = TrialContext(
            trial_id=trial_id,
            cell_id=cell_id,
            trace_id=trace_id,
            benchmark_seed=benchmark_seed,
            environment_id=self.definition.environment.environment_id,
            environment_version=self.definition.environment.manifest_version,
            action_manifest_version=self.definition.action_manifest.manifest_version,
            autonomy_policy_version=self.policy.version,
            stats_protocol_version="v1",
            runtime_id=runtime_id,
            model_id=model_id,
            model_version=model_version,
            docs_pack_id=docs_pack_id,
            autonomy_level=autonomy_level,
        )
        state = TrialState(
            context=context,
            environment=self.definition.environment,
            action_manifest=self.definition.action_manifest,
            branches=(),
            final_branch_id=None,
            emitted_artifact_types=frozenset({"TrialContext", "EnvironmentSpec", "ActionMenu"}),
        )
        state = _append_event(state, TraceEventType.TRIAL_STARTED, workflow_step="trial")
        if autonomy_level in {
            AutonomyLevel.DETERMINISTIC_BASELINE,
            AutonomyLevel.VALIDITY_EXECUTION,
        }:
            state = self.add_branch(
                state,
                self.definition.canonical_branch,
                committed=autonomy_level == AutonomyLevel.DETERMINISTIC_BASELINE,
            )
            state = self.select_final_branch(state, state.branches[0].branch_id)
        return state

    def add_branch(
        self,
        state: TrialState,
        branch_spec: BranchSpec,
        *,
        committed: bool = False,
        validation_utility: float | None = None,
    ) -> TrialState:
        self.policy.validate_branch_spec(
            state.context.autonomy_level,
            branch_spec,
            state.action_manifest,
        )
        branch = BranchTrace(
            branch_id=_branch_id(branch_spec),
            branch_spec=branch_spec,
            committed=committed,
            validation_observed=validation_utility is not None,
            validation_utility=validation_utility,
        )
        next_state = replace(state, branches=(*state.branches, branch))
        self.policy.validate_trial_state(next_state)
        next_state = _append_event(
            next_state,
            TraceEventType.BRANCH_CREATED,
            branch_id=branch.branch_id,
            workflow_step="branch",
            detail={"branch_hash": branch.branch_spec.branch_hash()},
        )
        if committed:
            next_state = _append_event(
                next_state,
                TraceEventType.BRANCH_COMMITTED,
                branch_id=branch.branch_id,
                workflow_step="branch",
            )
        if validation_utility is not None:
            next_state = _append_event(
                next_state,
                TraceEventType.VALIDATION_RESULT_OBSERVED,
                branch_id=branch.branch_id,
                workflow_step="validation",
                detail={"validation_utility": validation_utility},
            )
        return next_state

    def observe_validation(
        self,
        state: TrialState,
        branch_id: str,
        validation_utility: float,
    ) -> TrialState:
        branches = tuple(
            replace(
                branch,
                validation_observed=True,
                validation_utility=validation_utility,
            )
            if branch.branch_id == branch_id
            else branch
            for branch in state.branches
        )
        next_state = replace(state, branches=branches)
        return _append_event(
            next_state,
            TraceEventType.VALIDATION_RESULT_OBSERVED,
            branch_id=branch_id,
            workflow_step="validation",
            detail={"validation_utility": validation_utility},
        )

    def record_repair(self, state: TrialState, branch_id: str, count: int = 1) -> TrialState:
        branches = tuple(
            replace(branch, repair_count=branch.repair_count + count)
            if branch.branch_id == branch_id
            else branch
            for branch in state.branches
        )
        next_state = replace(state, branches=branches)
        self.policy.validate_trial_state(next_state)
        return _append_event(
            next_state,
            TraceEventType.REPAIR_ATTEMPTED,
            branch_id=branch_id,
            workflow_step="repair",
            detail={"count": count},
        )

    def select_final_branch(self, state: TrialState, branch_id: str) -> TrialState:
        if state.branch_by_id(branch_id) is None:
            raise ValueError(f"unknown branch_id: {branch_id}")
        next_state = replace(state, final_branch_id=branch_id)
        return _append_event(
            next_state,
            TraceEventType.BRANCH_SELECTED_FINAL,
            branch_id=branch_id,
            workflow_step="selection",
        )

    def attach_artifacts(self, state: TrialState, *artifact_types: str) -> TrialState:
        return replace(
            state, emitted_artifact_types=state.emitted_artifact_types.union(artifact_types)
        )

    def attach_case_study_inventory(
        self,
        state: TrialState,
        runtime: ETFCaseStudyRuntime,
        *,
        branch_id: str | None = None,
    ) -> TrialState:
        target_branch_id = branch_id or state.final_branch_id
        if target_branch_id is None:
            raise ValueError("branch_id or final_branch_id is required")
        branch = state.branch_by_id(target_branch_id)
        if branch is None:
            raise ValueError(f"unknown branch_id: {target_branch_id}")
        inventory = runtime.artifact_inventory(branch.branch_spec)
        return self.attach_artifacts(state, *sorted(inventory.existing_artifact_types()))

    def run_lint(self, state: TrialState) -> TrialState:
        return replace(state, lint_report=self.linter.run(state))

    def record_host_run_request(self, state: TrialState, request: HostRunRequest) -> TrialState:
        if request.trial_id != state.context.trial_id:
            raise ValueError("host run request trial_id does not match trial state")
        return _append_event(
            state,
            TraceEventType.HOST_RUN_REQUESTED,
            workflow_step="host_execution",
            detail={
                "task_id": request.task_id,
                "docs_pack_id": request.docs_pack_id,
                "autonomy_level": request.autonomy_level.value,
            },
        )

    def record_host_run_result(self, state: TrialState, result: HostRunResult) -> TrialState:
        if result.trial_id != state.context.trial_id:
            raise ValueError("host run result trial_id does not match trial state")
        next_state = replace(
            state,
            emitted_artifact_types=state.emitted_artifact_types.union(
                result.emitted_artifact_types
            ),
        )
        next_state = _append_event(
            next_state,
            TraceEventType.HOST_RUN_RESULT_CAPTURED,
            workflow_step="host_execution",
            status="ok" if result.success else "error",
            detail={
                "adapter_id": result.adapter_id,
                "summary": result.summary,
                "observed_branch_hashes": result.observed_branch_hashes,
                "trace_ref": result.trace_ref,
                "raw_output_ref": result.raw_output_ref,
            },
        )
        if not result.success:
            next_state = _append_event(
                next_state,
                TraceEventType.ERROR,
                workflow_step="host_execution",
                status="error",
                detail={"adapter_id": result.adapter_id, "summary": result.summary},
            )
        return next_state

    def submit(
        self,
        state: TrialState,
        *,
        holdout_metrics: dict[str, float] | None = None,
    ) -> tuple[TrialState, SubmissionReceipt, TrialReport]:
        if state.final_branch_id is None:
            raise ValueError("final branch must be selected before submission")
        linted_state = self.run_lint(state) if state.lint_report is None else state
        linted_state = replace(
            linted_state,
            emitted_artifact_types=linted_state.emitted_artifact_types.union({"LintReport"}),
        )
        final_branch_id = linted_state.final_branch_id
        if final_branch_id is None:
            raise ValueError("final branch must be selected before submission")
        final_branch = linted_state.branch_by_id(final_branch_id)
        if final_branch is None:
            raise ValueError(f"unknown final branch: {final_branch_id}")
        request = SubmissionRequest(
            trial_id=linted_state.context.trial_id,
            branch_id=final_branch.branch_id,
            branch_spec_hash=final_branch.branch_spec.branch_hash(),
            lint_run_id=linted_state.lint_report.lint_run_id if linted_state.lint_report else "",
            required_artifact_types=(
                "TrialContext",
                "EnvironmentSpec",
                "ActionMenu",
                "BranchSpec",
                "ModelRun",
                "CVResult",
                "BacktestResult",
                "LintReport",
            ),
        )
        linted_state = _append_event(
            linted_state,
            TraceEventType.SUBMISSION_ATTEMPTED,
            branch_id=final_branch.branch_id,
            workflow_step="submission",
        )
        receipt = self.gateway.submit(request, linted_state, holdout_metrics=holdout_metrics)
        submitted_state = replace(
            linted_state,
            submission_attempt_count=linted_state.submission_attempt_count + 1,
        )
        submitted_state = _append_event(
            submitted_state,
            TraceEventType.SUBMISSION_RESULT,
            branch_id=final_branch.branch_id,
            workflow_step="submission",
            status="ok" if receipt.accepted else "error",
            detail={"accepted": receipt.accepted},
        )
        submitted_state = _append_event(
            submitted_state,
            TraceEventType.TRIAL_COMPLETED,
            workflow_step="trial",
            status="ok" if receipt.accepted else "error",
        )
        report = build_trial_report(submitted_state, receipt)
        return submitted_state, receipt, report


__all__ = ["ETFBenchmarkHarness"]
