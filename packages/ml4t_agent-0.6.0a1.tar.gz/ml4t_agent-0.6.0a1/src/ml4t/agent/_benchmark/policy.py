"""Autonomy-level policy helpers for the ETF benchmark."""

from __future__ import annotations

from dataclasses import dataclass

from .contracts import ActionManifest, AutonomyLevel, BranchSpec, TrialState


class PolicyViolation(ValueError):
    """Raised when a branch or trial violates the autonomy policy."""


@dataclass(frozen=True, slots=True)
class AutonomyPolicy:
    """Minimal policy engine matching the v0 benchmark contract."""

    version: str = "v0"
    level_3_branch_budget: int = 5
    per_step_repair_budget: int = 2
    per_branch_repair_budget: int = 6

    def branch_budget(self, level: AutonomyLevel) -> int:
        if level in {AutonomyLevel.DETERMINISTIC_BASELINE, AutonomyLevel.VALIDITY_EXECUTION}:
            return 1
        if level == AutonomyLevel.COMMIT_BEFORE_FEEDBACK:
            return 1
        return self.level_3_branch_budget

    def selectable_fields(self, level: AutonomyLevel) -> frozenset[str]:
        if level in {AutonomyLevel.DETERMINISTIC_BASELINE, AutonomyLevel.VALIDITY_EXECUTION}:
            return frozenset()
        if level == AutonomyLevel.COMMIT_BEFORE_FEEDBACK:
            return frozenset({"label", "feature_regime", "model_bundle"})
        return frozenset({"label", "feature_regime", "model_bundle", "top_n"})

    def validate_branch_spec(
        self,
        level: AutonomyLevel,
        branch: BranchSpec,
        action_manifest: ActionManifest,
    ) -> None:
        if branch.label not in action_manifest.allowed_labels:
            raise PolicyViolation(f"invalid label: {branch.label}")
        if branch.feature_regime not in action_manifest.allowed_feature_regimes:
            raise PolicyViolation(f"invalid feature regime: {branch.feature_regime}")
        if branch.model_bundle not in action_manifest.allowed_model_bundles:
            raise PolicyViolation(f"invalid model bundle: {branch.model_bundle}")
        if branch.weighting_scheme not in action_manifest.allowed_weighting_schemes:
            raise PolicyViolation(f"invalid weighting scheme: {branch.weighting_scheme}")
        if branch.top_n not in action_manifest.allowed_top_n:
            raise PolicyViolation(f"invalid top_n: {branch.top_n}")

        selectable = self.selectable_fields(level)
        if "top_n" not in selectable and branch.top_n != 10:
            raise PolicyViolation(f"top_n is fixed at 10 for {level.value}")
        if "label" not in selectable and branch.label != "fwd_ret_21d":
            raise PolicyViolation(f"label is fixed for {level.value}")
        if "feature_regime" not in selectable and branch.feature_regime != "financial_only":
            raise PolicyViolation(f"feature_regime is fixed for {level.value}")
        if "model_bundle" not in selectable and branch.model_bundle != "linear_baseline":
            raise PolicyViolation(f"model_bundle is fixed for {level.value}")

    def validate_trial_state(self, state: TrialState) -> None:
        level = state.context.autonomy_level
        budget = self.branch_budget(level)
        if state.branch_count() > budget:
            raise PolicyViolation(
                f"branch budget exceeded for {level.value}: {state.branch_count()} > {budget}"
            )

        if level == AutonomyLevel.COMMIT_BEFORE_FEEDBACK:
            if state.branch_count() != 1:
                raise PolicyViolation("level 2 must execute exactly one substantive branch")
            branch = state.branches[0]
            if not branch.committed:
                raise PolicyViolation("level 2 requires a committed branch before feedback")
            if branch.validation_observed and state.final_branch_id != branch.branch_id:
                raise PolicyViolation("level 2 final branch must match the committed branch")

        for branch in state.branches:
            if branch.repair_count > self.per_branch_repair_budget:
                raise PolicyViolation(
                    f"branch {branch.branch_id} exceeded repair budget: "
                    f"{branch.repair_count} > {self.per_branch_repair_budget}"
                )
            self.validate_branch_spec(level, branch.branch_spec, state.action_manifest)


__all__ = ["AutonomyPolicy", "PolicyViolation"]
