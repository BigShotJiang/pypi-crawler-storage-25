"""Public benchmark-pack builders for the ETF v0 proof."""

from __future__ import annotations

from dataclasses import dataclass

from .contracts import (
    BenchmarkPack,
    BenchmarkTask,
    DocsPack,
    FailureExpectation,
    HostAdapterSpec,
    MethodologyDeltaSpec,
    MethodologyFailureMode,
    TrialState,
    WorkflowSurfacePolicy,
)
from .host import HostRunRequest
from .loader import BenchmarkDefinition
from .policy import AutonomyPolicy


@dataclass(frozen=True, slots=True)
class ETFBenchmarkPackBuilder:
    """Build the default public ETF benchmark pack."""

    definition: BenchmarkDefinition
    pack_version: str = "v0"

    def build(self) -> BenchmarkPack:
        return BenchmarkPack(
            pack_id="etf_research_benchmark_pack",
            pack_version=self.pack_version,
            environment_id=self.definition.environment.environment_id,
            docs_pack=self._docs_pack(),
            host_adapter=self._host_adapter(),
            tasks=(self._task(),),
        )

    def _docs_pack(self) -> DocsPack:
        root = self.definition.case_study_root
        return DocsPack(
            docs_pack_id="etf_docs_pack_v0",
            manifest_version=self.definition.setup_version,
            document_refs=(
                str(root / "config" / "setup.yaml"),
                str(root / "config" / "training" / f"{self.definition.primary_label}.yaml"),
                str(root / "config" / "cv_config.json"),
                str(root / "config" / "backtest" / "base.yaml"),
                str(root / "README.md"),
            ),
            skill_refs=(
                "ml4t-lookahead-bias",
                "ml4t-purging-embargo",
                "ml4t-walk-forward-cv",
                "ml4t-case-study-development",
            ),
        )

    def _host_adapter(self) -> HostAdapterSpec:
        return HostAdapterSpec(
            adapter_id="claude_code_headless",
            adapter_version="v0",
            host_family="coding_agent_host",
            invocation_mode="headless",
            host_responsibilities=(
                "llm_loop",
                "tool_invocation",
                "code_editing",
                "subagent_management",
                "session_interaction",
            ),
            harness_responsibilities=(
                "environment_contract",
                "allowed_action_surface",
                "artifact_identity",
                "trace_semantics",
                "methodology_lint",
                "submission_gates",
                "reporting",
            ),
        )

    def _task(self) -> BenchmarkTask:
        return BenchmarkTask(
            task_id="etf_contract_execution_and_selection",
            title="Operate inside the ETF research contract and produce one valid submission",
            prompt_brief=(
                "Use the ETF case-study contract to run a valid research workflow, choose only "
                "among the allowed branch options, and submit one final candidate without "
                "violating holdout, CV, or artifact rules."
            ),
            workflow_surface_policy=WorkflowSurfacePolicy(
                fixed_surfaces=(
                    "environment_definition",
                    "cv_protocol",
                    "cost_model",
                    "execution_semantics",
                    "holdout_window",
                    "artifact_schema",
                    "trace_schema",
                ),
                selectable_surfaces=(
                    "label",
                    "feature_regime",
                    "model_bundle",
                    "top_n",
                ),
                editable_surfaces=(
                    "branch_selection",
                    "repair_actions",
                    "submission_choice",
                ),
                sealed_surfaces=(
                    "holdout_data",
                    "benchmark_definition",
                    "hidden_evaluation_logic",
                    "submission_gateway",
                ),
            ),
            required_artifact_types=(
                "TrialContext",
                "EnvironmentSpec",
                "ActionMenu",
                "BranchSpec",
                "ModelRun",
                "CVResult",
                "BacktestResult",
                "LintReport",
            ),
            methodology_delta_spec=MethodologyDeltaSpec(
                delta_id="etf_methodology_delta_v0",
                title="Visible methodology delta between unconstrained and constrained ETF runs",
                expectations=(
                    FailureExpectation(
                        failure_mode=MethodologyFailureMode.FULL_SAMPLE_PREPROCESSING,
                        unconstrained_signal="as_of_valid false or rule_1 fail",
                        harness_rule_ids=("rule_1",),
                        expected_artifact_effects=("LintReport",),
                        expected_trace_effects=("submission_blocked",),
                    ),
                    FailureExpectation(
                        failure_mode=MethodologyFailureMode.FOLD_BOUNDARY_VIOLATION,
                        unconstrained_signal="cv_contract_valid false or rule_2 fail",
                        harness_rule_ids=("rule_2",),
                        expected_artifact_effects=("LintReport",),
                        expected_trace_effects=("submission_blocked",),
                    ),
                    FailureExpectation(
                        failure_mode=MethodologyFailureMode.HOLDOUT_MISUSE,
                        unconstrained_signal="prior_holdout_access true or rule_3 fail",
                        harness_rule_ids=("rule_3",),
                        expected_artifact_effects=("LintReport",),
                        expected_trace_effects=("holdout_release_withheld",),
                    ),
                    FailureExpectation(
                        failure_mode=MethodologyFailureMode.ARTIFACT_LINEAGE_GAP,
                        unconstrained_signal="trace invalid or rule_7 fail",
                        harness_rule_ids=("rule_7",),
                        expected_artifact_effects=("LintReport",),
                        expected_trace_effects=("submission_blocked",),
                    ),
                ),
            ),
        )


def build_default_etf_benchmark_pack(definition: BenchmarkDefinition) -> BenchmarkPack:
    """Build the public ETF v0 benchmark pack from a normalized definition."""
    return ETFBenchmarkPackBuilder(definition).build()


def build_host_run_request(
    pack: BenchmarkPack,
    task: BenchmarkTask,
    state: TrialState,
    *,
    policy: AutonomyPolicy,
    working_directory: str,
) -> HostRunRequest:
    """Translate a benchmark task plus trial state into a host invocation request."""
    return HostRunRequest(
        pack_id=pack.pack_id,
        task_id=task.task_id,
        trial_id=state.context.trial_id,
        prompt_brief=task.prompt_brief,
        docs_pack_id=pack.docs_pack.docs_pack_id,
        document_refs=pack.docs_pack.document_refs,
        skill_refs=pack.docs_pack.skill_refs,
        working_directory=working_directory,
        autonomy_level=state.context.autonomy_level,
        selectable_surfaces=tuple(sorted(policy.selectable_fields(state.context.autonomy_level))),
        sealed_surfaces=task.workflow_surface_policy.sealed_surfaces,
    )


__all__ = [
    "ETFBenchmarkPackBuilder",
    "build_default_etf_benchmark_pack",
    "build_host_run_request",
]
