"""Typed benchmark contracts for the ETF autonomy benchmark."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from hashlib import sha256
from typing import Any


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _json_value(value: Any) -> Any:
    if isinstance(value, StrEnum):
        return value.value
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, tuple):
        return [_json_value(item) for item in value]
    if isinstance(value, list):
        return [_json_value(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _json_value(item) for key, item in value.items()}
    return value


class AutonomyLevel(StrEnum):
    """Autonomy rungs for the ETF benchmark."""

    DETERMINISTIC_BASELINE = "level_0_deterministic_baseline"
    VALIDITY_EXECUTION = "level_1_validity_execution"
    COMMIT_BEFORE_FEEDBACK = "level_2_commit_before_feedback"
    ITERATE_ON_FEEDBACK = "level_3_iterate_on_feedback"


class TraceEventType(StrEnum):
    """Event types required for policy and reporting."""

    TRIAL_STARTED = "trial_started"
    TRIAL_COMPLETED = "trial_completed"
    BRANCH_CREATED = "branch_created"
    BRANCH_COMMITTED = "branch_committed"
    BRANCH_SELECTED_FINAL = "branch_selected_final"
    VALIDATION_RESULT_OBSERVED = "validation_result_observed"
    REPAIR_ATTEMPTED = "repair_attempted"
    HOST_RUN_REQUESTED = "host_run_requested"
    HOST_RUN_RESULT_CAPTURED = "host_run_result_captured"
    SUBMISSION_ATTEMPTED = "submission_attempted"
    SUBMISSION_RESULT = "submission_result"
    ERROR = "error"


class MethodologyFailureMode(StrEnum):
    """Methodology failures the benchmark aims to surface or block."""

    RANDOM_SEED_MISSING = "random_seed_missing"
    FULL_SAMPLE_PREPROCESSING = "full_sample_preprocessing"
    FOLD_BOUNDARY_VIOLATION = "fold_boundary_violation"
    THRESHOLD_PROVENANCE_ERROR = "threshold_provenance_error"
    PURGING_EMBARGO_VIOLATION = "purging_embargo_violation"
    HOLDOUT_MISUSE = "holdout_misuse"
    ARTIFACT_LINEAGE_GAP = "artifact_lineage_gap"
    UNTRACKED_BRANCH_CHANGE = "untracked_branch_change"


@dataclass(frozen=True, slots=True)
class EnvironmentManifest:
    """Fixed benchmark environment contract."""

    environment_id: str
    manifest_version: str
    holdout_start: str
    holdout_end: str
    allowed_labels: tuple[str, ...]
    allowed_feature_regimes: tuple[str, ...]
    allowed_model_bundles: tuple[str, ...]
    allowed_top_n: tuple[int, ...] = (10,)
    weighting_scheme: str = "equal_weight"


@dataclass(frozen=True, slots=True)
class ActionManifest:
    """Normalized selectable action surface exposed to the agent."""

    manifest_version: str
    allowed_labels: tuple[str, ...]
    allowed_feature_regimes: tuple[str, ...]
    allowed_model_bundles: tuple[str, ...]
    allowed_top_n: tuple[int, ...] = (5, 10, 15)
    allowed_weighting_schemes: tuple[str, ...] = ("equal_weight",)


@dataclass(frozen=True, slots=True)
class DocsPack:
    """Fixed documentation and skills surface exposed to comparable runs."""

    docs_pack_id: str
    manifest_version: str
    document_refs: tuple[str, ...]
    skill_refs: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class HostAdapterSpec:
    """Public host integration contract for one execution engine."""

    adapter_id: str
    adapter_version: str
    host_family: str
    invocation_mode: str
    host_responsibilities: tuple[str, ...]
    harness_responsibilities: tuple[str, ...]
    supports_headless: bool = True
    supports_subagents: bool = True


@dataclass(frozen=True, slots=True)
class WorkflowSurfacePolicy:
    """What is fixed, selectable, editable, and sealed for one benchmark task."""

    fixed_surfaces: tuple[str, ...]
    selectable_surfaces: tuple[str, ...]
    editable_surfaces: tuple[str, ...]
    sealed_surfaces: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class BranchSpec:
    """Substantive research branch identity."""

    label: str
    feature_regime: str
    model_bundle: str
    top_n: int = 10
    weighting_scheme: str = "equal_weight"
    parent_branch_id: str | None = None
    created_reason: str | None = None

    def payload(self) -> dict[str, Any]:
        return {
            "label": self.label,
            "feature_regime": self.feature_regime,
            "model_bundle": self.model_bundle,
            "top_n": self.top_n,
            "weighting_scheme": self.weighting_scheme,
            "parent_branch_id": self.parent_branch_id,
            "created_reason": self.created_reason,
        }

    def branch_hash(self) -> str:
        canonical = json.dumps(self.payload(), sort_keys=True, separators=(",", ":"))
        return sha256(canonical.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class FailureExpectation:
    """Expected methodology delta for one failure mode on one task."""

    failure_mode: MethodologyFailureMode
    unconstrained_signal: str
    harness_rule_ids: tuple[str, ...]
    expected_artifact_effects: tuple[str, ...] = ()
    expected_trace_effects: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class MethodologyDeltaSpec:
    """Expected observable difference between unconstrained and constrained runs."""

    delta_id: str
    title: str
    expectations: tuple[FailureExpectation, ...]


@dataclass(frozen=True, slots=True)
class BenchmarkTask:
    """One benchmark task inside a domain pack."""

    task_id: str
    title: str
    prompt_brief: str
    workflow_surface_policy: WorkflowSurfacePolicy
    required_artifact_types: tuple[str, ...]
    methodology_delta_spec: MethodologyDeltaSpec


@dataclass(frozen=True, slots=True)
class BenchmarkPack:
    """Pack-level benchmark definition exposed publicly by the library."""

    pack_id: str
    pack_version: str
    environment_id: str
    docs_pack: DocsPack
    host_adapter: HostAdapterSpec
    tasks: tuple[BenchmarkTask, ...]

    def task_by_id(self, task_id: str) -> BenchmarkTask | None:
        return next((task for task in self.tasks if task.task_id == task_id), None)


@dataclass(frozen=True, slots=True)
class TrialContext:
    """Trial-root metadata used for reporting and enforcement."""

    trial_id: str
    cell_id: str
    trace_id: str
    benchmark_seed: int
    environment_id: str
    environment_version: str
    action_manifest_version: str
    autonomy_policy_version: str
    stats_protocol_version: str
    runtime_id: str
    model_id: str
    model_version: str
    docs_pack_id: str
    autonomy_level: AutonomyLevel
    started_at: datetime = field(default_factory=_utc_now)
    ended_at: datetime | None = None
    status: str = "running"


@dataclass(frozen=True, slots=True)
class TraceEvent:
    """Minimal event shape for audit and policy checks."""

    event_id: str
    event_type: TraceEventType
    trial_id: str
    trace_id: str
    timestamp: datetime = field(default_factory=_utc_now)
    branch_id: str | None = None
    workflow_step: str | None = None
    status: str = "ok"
    detail: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class BranchTrace:
    """Trial-local branch execution summary."""

    branch_id: str
    branch_spec: BranchSpec
    committed: bool = False
    validation_observed: bool = False
    repair_count: int = 0
    validation_utility: float | None = None


@dataclass(frozen=True, slots=True)
class LintRuleResult:
    """Single lint rule outcome."""

    rule_id: str
    status: str
    severity: str
    message: str
    artifact_refs: tuple[str, ...] = ()
    trace_refs: tuple[str, ...] = ()

    @property
    def blocking(self) -> bool:
        return self.severity == "error" and self.status == "fail"


@dataclass(frozen=True, slots=True)
class LintReport:
    """Pre-submission methodology audit result."""

    lint_run_id: str
    status: str
    rules_run: tuple[str, ...]
    results: tuple[LintRuleResult, ...]

    @property
    def is_passing(self) -> bool:
        return self.status == "pass" and not any(result.blocking for result in self.results)


@dataclass(frozen=True, slots=True)
class SubmissionRequest:
    """Gateway submission request."""

    trial_id: str
    branch_id: str
    branch_spec_hash: str
    lint_run_id: str
    required_artifact_types: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class SubmissionReceipt:
    """Gateway response and durable submission record."""

    submission_id: str
    trial_id: str
    branch_id: str
    accepted: bool
    rejected_reason: str | None
    holdout_release_status: str
    holdout_metrics_if_released: dict[str, float] = field(default_factory=dict)
    created_at: datetime = field(default_factory=_utc_now)


@dataclass(frozen=True, slots=True)
class TrialState:
    """Execution state exposed to the submission gateway."""

    context: TrialContext
    environment: EnvironmentManifest
    action_manifest: ActionManifest
    branches: tuple[BranchTrace, ...]
    final_branch_id: str | None
    submission_attempt_count: int = 0
    prior_holdout_access: bool = False
    trace_valid: bool = True
    as_of_valid: bool = True
    cv_contract_valid: bool = True
    cost_contract_valid: bool = True
    emitted_artifact_types: frozenset[str] = field(default_factory=frozenset)
    lint_report: LintReport | None = None
    events: tuple[TraceEvent, ...] = ()

    def branch_by_id(self, branch_id: str) -> BranchTrace | None:
        return next((branch for branch in self.branches if branch.branch_id == branch_id), None)

    def branch_count(self) -> int:
        return len(self.branches)

    def event_count(self, event_type: TraceEventType) -> int:
        return sum(event.event_type == event_type for event in self.events)

    def to_dict(self) -> dict[str, Any]:
        return _json_value(asdict(self))


__all__ = [
    "BenchmarkPack",
    "BenchmarkTask",
    "ActionManifest",
    "AutonomyLevel",
    "BranchSpec",
    "BranchTrace",
    "DocsPack",
    "EnvironmentManifest",
    "FailureExpectation",
    "HostAdapterSpec",
    "LintReport",
    "LintRuleResult",
    "MethodologyDeltaSpec",
    "MethodologyFailureMode",
    "SubmissionReceipt",
    "SubmissionRequest",
    "TraceEvent",
    "TraceEventType",
    "TrialContext",
    "TrialState",
    "WorkflowSurfacePolicy",
]
