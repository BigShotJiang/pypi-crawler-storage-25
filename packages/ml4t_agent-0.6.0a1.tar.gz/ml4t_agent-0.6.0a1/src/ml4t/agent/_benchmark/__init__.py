"""Core benchmark contracts for the ML4T agent runtime."""

from .benchmark import (
    ETFBenchmarkPackBuilder,
    build_default_etf_benchmark_pack,
    build_host_run_request,
)
from .comparison import BenchmarkComparisonReport, build_benchmark_comparison
from .contracts import (
    ActionManifest,
    AutonomyLevel,
    BenchmarkPack,
    BenchmarkTask,
    BranchSpec,
    BranchTrace,
    DocsPack,
    EnvironmentManifest,
    FailureExpectation,
    HostAdapterSpec,
    LintReport,
    LintRuleResult,
    MethodologyDeltaSpec,
    MethodologyFailureMode,
    SubmissionReceipt,
    SubmissionRequest,
    TraceEvent,
    TraceEventType,
    TrialContext,
    TrialState,
    WorkflowSurfacePolicy,
)
from .delta import FailureDeltaObservation, MethodologyDeltaReport, evaluate_methodology_delta
from .execution import ExecutionAdapterError, Ml4tExecutionAdapters
from .gateway import SubmissionGateway
from .harness import ETFBenchmarkHarness
from .host import AgentHostAdapter, HostRunRequest, HostRunResult, ReplayHostAdapter
from .kill_test import (
    STAGE_MANIFEST_FILE_NAME,
    BenchmarkCondition,
    ClaudeCodeHeadlessAdapter,
    KillTestPairResult,
    KillTestTrialResult,
    StageManifest,
    build_condition_prompt,
    read_stage_manifest,
    run_kill_test_pair,
    run_kill_test_trial,
    stage_case_study_repo,
)
from .lint import BenchmarkLinter
from .loader import BenchmarkDefinition, CaseStudyConfigError, load_etf_benchmark
from .policy import AutonomyPolicy, PolicyViolation
from .reporting import CellSummary, TrialReport, build_trial_report, summarize_cell
from .runtime import (
    CaseStudyArtifactInventory,
    CaseStudyStageResult,
    ETFCaseStudyRuntime,
)
from .trace import TraceValidationResult, TraceValidator

__version__ = "0.1.0"

__all__ = [
    "ActionManifest",
    "AutonomyLevel",
    "AutonomyPolicy",
    "BenchmarkDefinition",
    "BenchmarkComparisonReport",
    "BenchmarkPack",
    "BenchmarkTask",
    "BenchmarkLinter",
    "BranchSpec",
    "BranchTrace",
    "CaseStudyConfigError",
    "CaseStudyArtifactInventory",
    "CaseStudyStageResult",
    "BenchmarkCondition",
    "ClaudeCodeHeadlessAdapter",
    "DocsPack",
    "EnvironmentManifest",
    "ExecutionAdapterError",
    "ETFBenchmarkPackBuilder",
    "ETFBenchmarkHarness",
    "ETFCaseStudyRuntime",
    "FailureDeltaObservation",
    "FailureExpectation",
    "HostRunRequest",
    "HostRunResult",
    "ReplayHostAdapter",
    "AgentHostAdapter",
    "HostAdapterSpec",
    "LintReport",
    "LintRuleResult",
    "KillTestPairResult",
    "KillTestTrialResult",
    "PolicyViolation",
    "STAGE_MANIFEST_FILE_NAME",
    "StageManifest",
    "SubmissionGateway",
    "SubmissionReceipt",
    "SubmissionRequest",
    "CellSummary",
    "MethodologyDeltaReport",
    "MethodologyDeltaSpec",
    "MethodologyFailureMode",
    "Ml4tExecutionAdapters",
    "TraceValidationResult",
    "TraceValidator",
    "TraceEvent",
    "TraceEventType",
    "TrialContext",
    "TrialReport",
    "TrialState",
    "WorkflowSurfacePolicy",
    "build_trial_report",
    "build_benchmark_comparison",
    "build_condition_prompt",
    "build_default_etf_benchmark_pack",
    "build_host_run_request",
    "evaluate_methodology_delta",
    "load_etf_benchmark",
    "read_stage_manifest",
    "run_kill_test_pair",
    "run_kill_test_trial",
    "stage_case_study_repo",
    "summarize_cell",
]
