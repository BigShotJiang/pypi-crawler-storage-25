"""High-level comparison summary for benchmark demo outputs."""

from __future__ import annotations

from dataclasses import dataclass

from .contracts import BenchmarkPack, BenchmarkTask, SubmissionReceipt, TrialState
from .delta import MethodologyDeltaReport, evaluate_methodology_delta
from .reporting import TrialReport, build_trial_report


@dataclass(frozen=True, slots=True)
class BenchmarkComparisonReport:
    """One task-level comparison between unconstrained and constrained runs."""

    pack_id: str
    task_id: str
    host_adapter_id: str
    unconstrained_report: TrialReport
    constrained_report: TrialReport
    methodology_delta: MethodologyDeltaReport
    headline: str


def build_benchmark_comparison(
    pack: BenchmarkPack,
    task: BenchmarkTask,
    unconstrained_state: TrialState,
    constrained_state: TrialState,
    *,
    unconstrained_receipt: SubmissionReceipt | None = None,
    constrained_receipt: SubmissionReceipt | None = None,
) -> BenchmarkComparisonReport:
    """Build a compact benchmark comparison for one task and host."""
    unconstrained_report = build_trial_report(unconstrained_state, unconstrained_receipt)
    constrained_report = build_trial_report(constrained_state, constrained_receipt)
    methodology_delta = evaluate_methodology_delta(task, unconstrained_state, constrained_state)
    headline = (
        f"{pack.host_adapter.adapter_id}: prevented "
        f"{methodology_delta.prevented_failure_count} methodology failures on {task.task_id}"
    )
    return BenchmarkComparisonReport(
        pack_id=pack.pack_id,
        task_id=task.task_id,
        host_adapter_id=pack.host_adapter.adapter_id,
        unconstrained_report=unconstrained_report,
        constrained_report=constrained_report,
        methodology_delta=methodology_delta,
        headline=headline,
    )


__all__ = ["BenchmarkComparisonReport", "build_benchmark_comparison"]
