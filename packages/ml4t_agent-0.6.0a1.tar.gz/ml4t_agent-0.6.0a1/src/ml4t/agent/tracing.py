"""Minimal agent-trace artifact for the ReAct loop.

A ``ReAct`` agent produces a sequence of (thought, action, observation)
steps. ``AgentTrace`` is the per-step record; ``AgentRun`` bundles the
ordered trace with run-level identifiers. Both round-trip to JSON so a
notebook can persist a session and replay it from disk without depending
on the agent runtime.

The design is deliberately framework-agnostic: ``inputs``/``outputs``/
``llm_raw`` are free-form strings or JSON-serializable mappings. The
typed schemas live in ``ml4t.agent.schemas``; the trace is the
provenance log around them.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import asdict, dataclass, field
from typing import Any

__all__ = ["AgentTrace", "AgentRun", "trace_to_json", "trace_from_json"]


@dataclass(frozen=True, slots=True)
class AgentTrace:
    """One step in an agent's ReAct loop."""

    step: int
    action: str
    tool_name: str | None = None
    inputs: Mapping[str, Any] | None = None
    outputs: Mapping[str, Any] | None = None
    llm_raw: str | None = None
    timestamp: str | None = None  # ISO-8601, set by the runtime


@dataclass(frozen=True, slots=True)
class AgentRun:
    """A complete agent session: ordered traces + final artifact."""

    run_id: str
    agent_id: str
    traces: tuple[AgentTrace, ...] = field(default_factory=tuple)
    final_artifact: Mapping[str, Any] | None = None


def trace_to_json(run: AgentRun) -> str:
    """Serialize an ``AgentRun`` (with traces) to a JSON string."""
    payload = {
        "run_id": run.run_id,
        "agent_id": run.agent_id,
        "traces": [asdict(t) for t in run.traces],
        "final_artifact": (dict(run.final_artifact) if run.final_artifact is not None else None),
    }
    return json.dumps(payload, sort_keys=True, default=str)


def trace_from_json(s: str) -> AgentRun:
    """Inverse of :func:`trace_to_json`. Raises ``ValueError`` on bad input."""
    raw = json.loads(s)
    if not isinstance(raw, dict):
        raise ValueError("expected JSON object at top level")
    try:
        traces = tuple(
            AgentTrace(
                step=int(t["step"]),
                action=str(t["action"]),
                tool_name=t.get("tool_name"),
                inputs=t.get("inputs"),
                outputs=t.get("outputs"),
                llm_raw=t.get("llm_raw"),
                timestamp=t.get("timestamp"),
            )
            for t in raw.get("traces", [])
        )
    except (KeyError, TypeError) as exc:
        raise ValueError(f"malformed trace entry: {exc}") from exc
    return AgentRun(
        run_id=str(raw["run_id"]),
        agent_id=str(raw["agent_id"]),
        traces=traces,
        final_artifact=raw.get("final_artifact"),
    )
