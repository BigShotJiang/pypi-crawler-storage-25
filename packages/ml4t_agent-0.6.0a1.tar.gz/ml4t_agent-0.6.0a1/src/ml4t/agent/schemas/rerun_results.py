"""Typed result records for the bounded-rerun tools.

Each rerun tool returns a typed dataclass that the delta evaluator can
consume directly. Kept separate from `evidence.py` because rerun results
are *outputs* of the experiment, not summaries of the parent run; and
separate from `delta.py` because they precede the delta review.

For v0.2 the rerun tools read fixture artifacts (no live runner). The
result records are therefore simple value objects parametrized by what
the test fixture supplies; the delta evaluator does the actual
combining-rule arithmetic against `DeltaCriterion`.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass

from .evidence import ModelRunSummary

__all__ = ["LineageRecheckResult", "NarrowGbmResult"]


@dataclass(frozen=True)
class LineageRecheckResult:
    """T-A2 rerun result: a HEAD-rebuild of the strongest parent baseline.

    `mean_fold_ic_after` is compared against the parent's `best_mean_ic`
    via T-A2's absolute-level `DeltaCriterion`. `fold_ic_after` is the
    per-fold IC series so simple-bootstrap intervals can be computed at
    Stage D. The lineage receipts (`git_sha_at_rerun`,
    `package_versions_at_rerun`) make any reproduction gap auditable.
    """

    parent_baseline: ModelRunSummary
    mean_fold_ic_after: float
    fold_ic_after: tuple[float, ...]
    git_sha_at_rerun: str
    package_versions_at_rerun: Mapping[str, str]


@dataclass(frozen=True)
class NarrowGbmResult:
    """T-M1 rerun result: a narrowed list of GBM presets, retrained.

    `narrowed_runs` is the per-preset `ModelRunSummary` set from the
    narrowed search; `baseline_within_family` is the parent's strongest
    GBM run at the same labels. The delta evaluator computes
    ``mean_fold_ic_within_family_delta = max(narrowed.mean_fold_ic) -
    baseline.mean_fold_ic`` and feeds it into T-M1's `DeltaCriterion`
    (`metric_kind="delta"`, `direction="higher_is_better"`).
    """

    baseline_within_family: ModelRunSummary
    narrowed_runs: tuple[ModelRunSummary, ...]
    presets_tried: tuple[str, ...]

    @property
    def best_within_family(self) -> ModelRunSummary:
        if not self.narrowed_runs:
            raise ValueError("NarrowGbmResult.narrowed_runs is empty")
        return max(self.narrowed_runs, key=lambda r: r.mean_fold_ic)

    @property
    def mean_fold_ic_within_family_delta(self) -> float:
        return self.best_within_family.mean_fold_ic - self.baseline_within_family.mean_fold_ic
