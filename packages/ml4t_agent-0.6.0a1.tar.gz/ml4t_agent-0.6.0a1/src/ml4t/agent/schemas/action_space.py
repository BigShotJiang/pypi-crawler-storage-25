"""Action-space schema: ExperimentTemplate, ConfigPatch, OverrideSpec, etc.

Defines the bounded surface the planner can act on. `PlanValidationError` is
declared here (not in `validation.py`) because `OverrideSpec.validate_value`
raises it; `validation.py` re-exports it to preserve the round-2 import path.

`IterationPlan` lives here (rather than in `workflow.py`) so the schemas DAG
stays acyclic — `IterationPlan` references `ExperimentPlan`, defined here.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

from .delta import DeltaCriterion
from .evidence import PREDICATES, EvidencePack, PredicateUnavailable
from .workflow import IterationCategory, LineState, Severity, TemplateMaturity

# Path templates the planner is permitted to address.
PathTemplate = Literal[
    "config/setup.yaml",
    "config/training/{label}.yaml",
    "case_studies/config/{family}/{config_name}.yaml",
    "config/cv_config.json",
]


ValueTypeName = Literal[
    "int",
    "float",
    "bool",
    "str",
    "list[str]",
    "tuple[float, float]",
]


# Tokens that, if they appear in a yaml_path component, mean the patch is
# touching the holdout boundary. Forbidden during normal iteration.
HOLDOUT_FORBIDDEN_TOKENS: frozenset[str] = frozenset({"holdout_start", "holdout_end", "holdout"})


class PlanValidationError(ValueError):
    """Raised when an ExperimentPlan violates its template contract."""


@dataclass(frozen=True)
class OverrideSpec:
    """Declared by an ExperimentTemplate. Says exactly what overrides are
    legal, against which file template, and what value shape is allowed.

    Replaces the round-1 design where a template carried example
    `ConfigPatch` instances and `ConfigPatch.new_value` was `Any`.
    """

    path_template: PathTemplate
    yaml_path: tuple[str, ...]
    value_type: ValueTypeName
    allowed_values: tuple[Any, ...] | None = None
    min_value: float | None = None
    max_value: float | None = None
    length: int | None = None
    direction: Literal["narrower_only", "wider_only", "any"] = "any"
    description: str = ""

    def validate_value(self, value: Any) -> None:
        """Raise PlanValidationError if `value` does not satisfy this spec."""

        kind = self.value_type
        if kind == "int":
            if not isinstance(value, int) or isinstance(value, bool):
                raise PlanValidationError(
                    f"override {self.yaml_path}: expected int, got {type(value).__name__}"
                )
        elif kind == "float":
            if not isinstance(value, int | float) or isinstance(value, bool):
                raise PlanValidationError(
                    f"override {self.yaml_path}: expected float, got {type(value).__name__}"
                )
        elif kind == "bool":
            if not isinstance(value, bool):
                raise PlanValidationError(
                    f"override {self.yaml_path}: expected bool, got {type(value).__name__}"
                )
        elif kind == "str":
            if not isinstance(value, str):
                raise PlanValidationError(
                    f"override {self.yaml_path}: expected str, got {type(value).__name__}"
                )
        elif kind == "list[str]":
            if not (isinstance(value, list | tuple) and all(isinstance(v, str) for v in value)):
                raise PlanValidationError(f"override {self.yaml_path}: expected list[str]")
            if self.length is not None and len(value) != self.length:
                raise PlanValidationError(
                    f"override {self.yaml_path}: expected length {self.length}"
                )
        elif kind == "tuple[float, float]":
            if not (
                isinstance(value, list | tuple)
                and len(value) == 2
                and all(isinstance(v, int | float) and not isinstance(v, bool) for v in value)
            ):
                raise PlanValidationError(
                    f"override {self.yaml_path}: expected tuple[float, float]"
                )
            lo, hi = float(value[0]), float(value[1])
            if lo > hi:
                raise PlanValidationError(
                    f"override {self.yaml_path}: tuple bounds inverted: ({lo}, {hi})"
                )
        else:  # pragma: no cover
            raise PlanValidationError(f"unknown value_type {kind!r}")

        if self.allowed_values is not None and value not in self.allowed_values:
            raise PlanValidationError(
                f"override {self.yaml_path}: value {value!r} not in {self.allowed_values!r}"
            )
        if isinstance(value, int | float) and not isinstance(value, bool):
            if self.min_value is not None and value < self.min_value:
                raise PlanValidationError(
                    f"override {self.yaml_path}: value {value} < min {self.min_value}"
                )
            if self.max_value is not None and value > self.max_value:
                raise PlanValidationError(
                    f"override {self.yaml_path}: value {value} > max {self.max_value}"
                )


@dataclass(frozen=True)
class ConfigPatch:
    """A concrete patch on a plan. Renders the path template with variables.
    `path_template` and `yaml_path` together must match exactly one
    `OverrideSpec` declared by the template; `new_value` is validated against
    that spec at plan-validation time."""

    path_template: PathTemplate
    path_variables: tuple[tuple[str, str], ...]  # immutable mapping
    yaml_path: tuple[str, ...]
    new_value: Any  # validated against the matching OverrideSpec

    @property
    def rendered_path(self) -> str:
        return self.path_template.format(**dict(self.path_variables))


@dataclass(frozen=True)
class StageInvocation:
    script: str
    case_study: str = "etfs"
    env: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True)
class ArtifactContract:
    relative_path: str
    schema_id: str
    required: bool = True


@dataclass(frozen=True)
class ExperimentTemplate:
    template_id: str
    category: IterationCategory
    maturity: TemplateMaturity
    question: str
    preconditions: tuple[str, ...]
    forbidden_when: tuple[Severity, ...]
    allowed_overrides: tuple[OverrideSpec, ...]
    forbidden_paths: tuple[tuple[str, ...], ...]
    stage_invocations: tuple[StageInvocation, ...]  # exact ordered sequence
    expected_artifacts: tuple[ArtifactContract, ...]
    delta_criterion_template: DeltaCriterion
    expected_information_value: float  # primary ranking key, in [0, 1]
    relative_cost: float  # tiebreaker (lower is cheaper), in [0, 1]

    def __post_init__(self) -> None:
        if not 0.0 <= self.expected_information_value <= 1.0:
            raise ValueError(
                "expected_information_value must be in [0, 1]; "
                f"got {self.expected_information_value}"
            )
        if not 0.0 <= self.relative_cost <= 1.0:
            raise ValueError(f"relative_cost must be in [0, 1]; got {self.relative_cost}")

    def is_eligible(self, pack: EvidencePack) -> tuple[bool, str]:
        for w in pack.warnings:
            if w.severity in self.forbidden_when:
                return False, f"forbidden_when:{w.severity.value}:{w.code}"
        for name in self.preconditions:
            predicate = PREDICATES.get(name)
            if predicate is None:
                return False, f"unknown_predicate:{name}"
            try:
                ok = predicate(pack)
            except PredicateUnavailable as exc:
                return False, f"unavailable:{name}:{exc}"
            if not ok:
                return False, f"precondition_failed:{name}"
        return True, "ok"


@dataclass(frozen=True)
class ExperimentPlan:
    experiment_id: str
    template_id: str
    parent_run_id: str
    comparison_target_id: str
    config_patches: tuple[ConfigPatch, ...]
    stage_invocations: tuple[StageInvocation, ...]
    expected_artifacts: tuple[ArtifactContract, ...]
    delta_criterion: DeltaCriterion
    question: str
    hypothesis: str
    rationale: str


@dataclass(frozen=True)
class IterationPlan:
    plans: tuple[ExperimentPlan, ...]
    line_state: LineState
