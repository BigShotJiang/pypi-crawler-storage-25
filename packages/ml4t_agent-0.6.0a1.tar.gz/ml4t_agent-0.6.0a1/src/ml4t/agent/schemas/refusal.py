"""Refusal schema — output of the deterministic ``validate_plan`` audit.

A `Refusal` is what the deterministic post-construction validator emits
when an `ExperimentPlan` fails one of the five checks documented in
plan-31 §v0.5.1 (branch D, after the v0.5.0 falsification spike).
Distinct from `PlanValidationError` (raised by
:mod:`ml4t.agent.schemas.validation` for *structural* contract
violations against a template); a `Refusal` is the *semantic* coherence
check between a structurally-valid plan and the EvidencePack it claims
to act on.

The chapter narrative explicitly relies on the deterministic-vs-LLM
split: every `RefusalKind` listed here is checkable in pure Python from
a `(plan, template, pack)` triple, with no LLM call.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

__all__ = ["RefusalKind", "Refusal"]


class RefusalKind(str, Enum):
    """Why ``validate_plan`` refused a structurally-valid proposal.

    Five kinds, all deterministic. Listed in the order ``validate_plan``
    evaluates them — earlier kinds short-circuit later ones to keep
    refusal messages focused on the proximate cause.
    """

    PREDICATE_MISMATCH = "predicate_mismatch"
    """A template precondition predicate, re-evaluated against the
    pack, is False or raises ``PredicateUnavailable``. The proposer
    claimed the template was eligible; the pack disagrees."""

    MISSING_RECEIPT = "missing_receipt"
    """The plan's ``rationale`` text references a methodology warning
    by code without also referencing the warning's ``triggering_artifact``
    (or ``triggering_field``). Citing a warning without grounding it in
    the artefact that produced it is a confabulation guard."""

    THRESHOLD_DRIFT = "threshold_drift"
    """A delta-criterion threshold that the template anchors to a pack
    value (e.g. T-A2 anchors to ``signal.best_mean_ic``) drifted from
    the re-derived value by more than the configured tolerance
    (default ±10%). Catches the case where the proposer used a stale
    pack snapshot or hand-edited a threshold."""

    BONFERRONI_OVER_BUDGET = "bonferroni_over_budget"
    """The plan's adjusted alpha (after Bonferroni correction) is below
    the discipline-policy floor. With ``adjusted_alpha = base_alpha /
    bonferroni_k`` this triggers when ``bonferroni_k`` has grown so
    large that no test could practically clear support — the line has
    burned its multiple-comparisons budget and should stop, not propose
    another iteration."""

    PRESET_REGISTRY_RECEIPT = "preset_registry_receipt"
    """A ``ConfigPatch`` whose ``value_type=="list[str]"`` cites preset
    names (e.g. T-M1's GBM preset list, T-F1's feature exclusion list)
    that are not present in the runner's preset registry. Surfaced by
    the v0.5.0 spike: cheap proposers confabulate plausible-looking but
    nonexistent preset names. Until the v0.6 runner contract exposes
    the registry on the pack, the predicate is unavailable; on packs
    where the registry is exposed, this is an exact lookup."""


@dataclass(frozen=True)
class Refusal:
    """One refusal verdict from ``validate_plan``.

    A plan accepted by ``validate_plan`` returns an empty tuple of
    refusals; a refused plan returns one or more (the validator does not
    short-circuit *across* kinds — every kind that fires is reported,
    so the proposer can address all causes in one revision).

    Fields:
        kind: which of the five refusal kinds fired.
        message: human-readable explanation, including the specific
            field value that triggered the refusal.
        field_path: dotted path into the plan or pack identifying the
            field at fault (e.g. ``"delta_criterion.support_threshold"``,
            ``"config_patches[0].new_value"``,
            ``"preconditions[0]:gbm_dispersion_large"``). ``None`` when
            the refusal is about the plan as a whole.
        cited_evidence: tuple of pack-field paths the refusal grounds
            itself in (e.g. ``("validation.signal.best_mean_ic",)``).
            Empty when the refusal is purely structural.
    """

    kind: RefusalKind
    message: str
    field_path: str | None
    cited_evidence: tuple[str, ...] = ()
