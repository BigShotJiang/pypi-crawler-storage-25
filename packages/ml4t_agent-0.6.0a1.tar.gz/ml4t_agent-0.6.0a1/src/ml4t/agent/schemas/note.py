"""ResearchNote — the v0.1 agent's terminal artifact.

A ``ResearchNote`` records what the research-line concluded for one
iteration: which proposals were generated, which one (if any) was
evaluated, the resulting :class:`DeltaReview`, and the deterministic
:class:`Decision` from ``recommend_decision``. It is the contract a
downstream coding agent (v0.6) or a human reviewer reads.

This module sits below ``action_space``, ``delta`` and ``workflow`` in
the schemas DAG; it imports from all three.
"""

from __future__ import annotations

from dataclasses import dataclass

from .action_space import ExperimentPlan
from .delta import DeltaReview
from .workflow import Decision

__all__ = ["ResearchNote"]


@dataclass(frozen=True)
class ResearchNote:
    """Terminal output of a single :class:`ResearchReviewAgent` run.

    Fields capture the loop in order: identifiers (line / iteration /
    parent), free-text summary, the proposal set the planner produced,
    which one (if any) was evaluated, the typed delta review, the
    final decision, and any open questions the agent could not close.
    """

    line_id: str
    iteration_index: int
    parent_run_id: str
    case_study: str
    objective: str
    summary: str
    proposals: tuple[ExperimentPlan, ...]
    selected_experiment_id: str | None
    delta_review: DeltaReview | None
    decision: Decision
    rationale: str
    open_questions: tuple[str, ...] = ()
