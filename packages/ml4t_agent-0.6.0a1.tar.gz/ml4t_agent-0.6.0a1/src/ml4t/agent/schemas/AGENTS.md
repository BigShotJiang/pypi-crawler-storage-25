# schemas/ — Round-2 typed schemas

Five-file split of the round-2 dataclass surface. Every typed artefact the
agent consumes or produces is declared here; nothing in this package
imports from `tools/`, `agents/`, or `llm/`.

## Files

| File | Lines | Purpose |
|------|-------|---------|
| `workflow.py` | 132 | Enums + workflow-state structs (`Decision`, `Severity`, `LineState`, `WorkflowSpec`, `Finding`, `ResearchEvidenceReview`, `ExecutionRecord`) |
| `evidence.py` | 350 | `EvidencePack` and its summary components (`MethodologyWarning`, `DiagnosticNote`, `TriageEntry`); predicates over packs (`PredicateUnavailable`); `feature_triage_has_stop` evaluates `pack.triage` (v0.4); `pack.preset_registry: frozenset[str] | None` exposes the runner's authoritative preset list to `validate_plan` (v0.6) |
| `delta.py` | 182 | `DeltaCriterion`, `DeltaReview`, `recommend_decision` (deterministic decision rule) |
| `action_space.py` | 221 | `OverrideSpec`, `ConfigPatch`, `StageInvocation`, `ArtifactContract`, `ExperimentTemplate`, `ExperimentPlan`, `IterationPlan`, `PlanValidationError` |
| `note.py` | 45 | `ResearchNote` (the agent's terminal artefact) |
| `validation.py` | 133 | `validate_plan(plan, template, pack, line_state)` — single entry-point validator |

## Design notes

- Every schema is a frozen dataclass; mutability is opt-in via `replace()`.
- Enums use `(str, Enum)` (not `StrEnum`) so `str(Decision.STOP_RESEARCH_LINE)`
  remains `"Decision.STOP_RESEARCH_LINE"` while equality with the bare string
  still holds. `UP042` is suppressed in `pyproject.toml` for this reason.
- `PlanValidationError` is the one error class the validator raises;
  callers either `try/except` it or trust `validate_plan` to gate.
- `recommend_decision` is a pure function of `(delta_review, evidence_review,
  line_state)` — no LLM, no I/O. This is what makes the loop replayable
  across model swaps.
