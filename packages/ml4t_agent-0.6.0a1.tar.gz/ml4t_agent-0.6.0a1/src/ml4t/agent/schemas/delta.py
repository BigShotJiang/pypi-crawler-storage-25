"""Delta criterion / outcome and the deterministic decision rule.

`DeltaCriterion` is pre-registered, frozen at plan creation. `DeltaReview`
captures the post-rerun verdict. `recommend_decision` is the deterministic
loop-discipline §6 rule that turns a research-evidence review and a delta
review into the next workflow Decision.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Literal

from .workflow import (
    Decision,
    DeltaOutcome,
    LineState,
    ResearchEvidenceReview,
    Severity,
)


@dataclass(frozen=True)
class DeltaCriterion:
    """Pre-registered, frozen at plan creation.

    Bonferroni adjusts the *confidence level* used when constructing the
    interval (`adjusted_alpha = base_alpha / k`); the economic thresholds
    (`support_threshold`, `reject_threshold`) are fixed at plan creation and
    do not change with iteration count.

    `metric_kind` distinguishes:
    - "delta": primary_metric is a delta (after - before)
    - "absolute": primary_metric is the post-rerun absolute level (used by
      survival templates like T-C1, where the question is "does it clear an
      economic floor under stricter assumptions?")

    The combining rule in `evaluate(...)` applies the same way in both cases:
    the caller is responsible for passing the appropriate point estimate and
    interval bounds.
    """

    primary_metric: str
    metric_kind: Literal["delta", "absolute"]
    support_threshold: float
    reject_threshold: float
    direction: Literal["higher_is_better", "lower_is_better"]
    noise_floor_method: Literal[
        "hac_newey_west_21d",
        "block_bootstrap_21d",
        "simple_bootstrap",
    ]
    base_alpha: float = 0.05
    bonferroni_k: int = 1

    @property
    def adjusted_alpha(self) -> float:
        if self.bonferroni_k <= 1:
            return self.base_alpha
        return self.base_alpha / self.bonferroni_k

    @property
    def adjusted_confidence_level(self) -> float:
        return 1.0 - self.adjusted_alpha

    def evaluate(
        self,
        point_estimate: float,
        interval_low: float,
        interval_high: float,
    ) -> DeltaOutcome:
        """Combining rule.

        Caller constructs `(interval_low, interval_high)` at the *adjusted*
        confidence level (Bonferroni applied). The economic thresholds are
        fixed.

        higher_is_better:
            supported    if interval_low  >= support_threshold
            contradicted if interval_high <= reject_threshold
            inconclusive otherwise

        lower_is_better:
            supported    if interval_high <= support_threshold
            contradicted if interval_low  >= reject_threshold
            inconclusive otherwise

        Note: with a wider (more conservative) CI as k grows, both
        `interval_low` and `interval_high` move outward, so it becomes harder
        to clear `support_threshold` and harder to clear `reject_threshold` in
        the contradictory direction. This is the intended behavior of a
        multiple-comparisons correction.
        """

        if interval_low > interval_high:
            raise ValueError("interval_low must be <= interval_high")
        if self.direction == "higher_is_better":
            if interval_low >= self.support_threshold:
                return DeltaOutcome.SUPPORTED
            if interval_high <= self.reject_threshold:
                return DeltaOutcome.CONTRADICTED
            return DeltaOutcome.INCONCLUSIVE
        # lower_is_better
        if interval_high <= self.support_threshold:
            return DeltaOutcome.SUPPORTED
        if interval_low >= self.reject_threshold:
            return DeltaOutcome.CONTRADICTED
        return DeltaOutcome.INCONCLUSIVE


@dataclass(frozen=True)
class DeltaReview:
    experiment_id: str
    primary_metric: str
    metric_kind: Literal["delta", "absolute"]
    before: float
    after: float
    point_estimate: float  # delta when metric_kind=="delta", else == after
    interval_low: float
    interval_high: float
    fold_deltas: tuple[float, ...]
    cost_sensitivity: tuple[tuple[float, float], ...]  # (cost_bps, net_metric) pairs
    regime_breakdown: Mapping[str, float] = field(default_factory=lambda: MappingProxyType({}))
    outcome: DeltaOutcome = DeltaOutcome.INCONCLUSIVE
    recommendation: Decision = Decision.ITERATE_OFFLINE
    rationale: str = ""


# --- Decision table ----------------------------------------------------------


def recommend_decision(
    review: ResearchEvidenceReview | None,
    delta: DeltaReview | None,
    line_state: LineState,
    consecutive_inconclusive: int,
    audits_consumed: int,
) -> Decision:
    """Deterministic decision rule (loop-discipline §6).

    Inputs are typed artifacts; no LLM is involved. The order of checks below
    is the order specified in the policy: blocking findings first, hard stops
    second, delta outcomes third, budget last.
    """

    # 1. Blocking finding -> audit_required (highest priority)
    if review is not None:
        for finding in review.findings:
            if finding.severity is Severity.BLOCKING:
                return Decision.AUDIT_REQUIRED

    # 2. Delta is invalid -> audit_required
    if delta is not None and delta.outcome is DeltaOutcome.INVALID:
        return Decision.AUDIT_REQUIRED

    # 3. Delta is contradicted -> stop unless we are inside an audit cycle
    if delta is not None and delta.outcome is DeltaOutcome.CONTRADICTED:
        return Decision.STOP_RESEARCH_LINE

    # 4. Audit budget exhausted -> stop (audit-trap escape)
    if audits_consumed >= line_state.max_iterations:
        return Decision.STOP_RESEARCH_LINE

    # 5. Two consecutive inconclusive deltas -> stop
    if consecutive_inconclusive >= 2:
        return Decision.STOP_RESEARCH_LINE

    # 6. Iteration budget reached -> stop
    if line_state.iteration_index >= line_state.max_iterations:
        return Decision.STOP_RESEARCH_LINE

    # 7. Supported delta and the line is mature
    #    (mature = iteration_index >= 2 and at least one supported outcome)
    if delta is not None and delta.outcome is DeltaOutcome.SUPPORTED:
        if line_state.iteration_index >= 2:
            return Decision.ADVANCE_TO_HOLDOUT_REVIEW
        return Decision.ITERATE_OFFLINE

    # 8. Default: another iteration is justified
    return Decision.ITERATE_OFFLINE
