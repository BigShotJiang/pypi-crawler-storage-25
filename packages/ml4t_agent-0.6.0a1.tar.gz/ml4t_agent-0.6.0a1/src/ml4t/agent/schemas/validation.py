"""Plan validation logic.

`PlanValidationError` is defined in :mod:`ml4t.agent.schemas.action_space`
(because `OverrideSpec.validate_value` raises it) and re-exported here to
preserve the round-2 import path `from ml4t.agent.schemas import
PlanValidationError`.
"""

from __future__ import annotations

from .action_space import (
    HOLDOUT_FORBIDDEN_TOKENS,
    ExperimentPlan,
    ExperimentTemplate,
    OverrideSpec,
    PlanValidationError,
)
from .evidence import EvidencePack
from .workflow import LineState

__all__ = ["PlanValidationError", "validate_plan"]


def validate_plan(
    plan: ExperimentPlan,
    template: ExperimentTemplate,
    pack: EvidencePack,
    line_state: LineState,
) -> None:
    """Stage C precondition. Raises PlanValidationError on any violation.

    Enforces:
    - template/plan ID consistency
    - template eligibility against the current EvidencePack (including the
      structural holdout seal)
    - every ConfigPatch has a matching OverrideSpec, value-validated
    - no patch path is in `template.forbidden_paths`
    - no patch path touches the holdout boundary
    - stage invocations exactly equal the template's, in order
    - plan.expected_artifacts is a superset of template.expected_artifacts
    - delta_criterion.primary_metric matches the template
    - delta_criterion.bonferroni_k equals line_state.iteration_index
    - delta_criterion.base_alpha equals line_state.base_alpha
    - line_state.iteration_index is within the budget
    """

    # 1. ID consistency
    if plan.template_id != template.template_id:
        raise PlanValidationError(
            f"plan.template_id={plan.template_id!r} does not match "
            f"template.template_id={template.template_id!r}"
        )

    # 2. Holdout-seal must hold (structural)
    if pack.holdout is not None:
        raise PlanValidationError(
            "EvidencePack.holdout is populated; iterations cannot proceed. "
            "The line must transition through advance_to_holdout_review."
        )

    # 3. Iteration budget
    if line_state.iteration_index < 1:
        raise PlanValidationError("line_state.iteration_index must be >= 1")
    if line_state.iteration_index > line_state.max_iterations:
        raise PlanValidationError(
            f"line iteration index {line_state.iteration_index} exceeds "
            f"max_iterations {line_state.max_iterations}"
        )

    # 4. Template eligibility
    eligible, reason = template.is_eligible(pack)
    if not eligible:
        raise PlanValidationError(f"template not eligible: {reason}")

    # 5. Patch <-> OverrideSpec pairing and value validation
    spec_index: dict[tuple[str, tuple[str, ...]], OverrideSpec] = {
        (s.path_template, s.yaml_path): s for s in template.allowed_overrides
    }
    forbidden_paths = set(template.forbidden_paths)
    for patch in plan.config_patches:
        key = (patch.path_template, patch.yaml_path)
        if key not in spec_index:
            raise PlanValidationError(
                f"patch {key} has no matching OverrideSpec on template {template.template_id!r}"
            )
        if patch.yaml_path in forbidden_paths:
            raise PlanValidationError(
                f"patch path {patch.yaml_path} is in template.forbidden_paths"
            )
        if any(token in patch.yaml_path for token in HOLDOUT_FORBIDDEN_TOKENS):
            raise PlanValidationError(f"patch path {patch.yaml_path} touches holdout boundary")
        spec_index[key].validate_value(patch.new_value)

    # 6. Stage invocations: exact ordered match
    if tuple(plan.stage_invocations) != tuple(template.stage_invocations):
        raise PlanValidationError(
            "plan.stage_invocations must exactly equal "
            "template.stage_invocations (same scripts, same order)"
        )

    # 7. Artifact contract: plan must include all template artifacts
    template_artifacts = {a.relative_path for a in template.expected_artifacts}
    plan_artifacts = {a.relative_path for a in plan.expected_artifacts}
    if not template_artifacts.issubset(plan_artifacts):
        missing = template_artifacts - plan_artifacts
        raise PlanValidationError(
            f"plan.expected_artifacts missing required template artifacts: {sorted(missing)}"
        )

    # 8. DeltaCriterion: primary_metric must match the template
    if plan.delta_criterion.primary_metric != template.delta_criterion_template.primary_metric:
        raise PlanValidationError(
            "plan.delta_criterion.primary_metric must match "
            "template.delta_criterion_template.primary_metric"
        )
    if plan.delta_criterion.metric_kind != template.delta_criterion_template.metric_kind:
        raise PlanValidationError("plan.delta_criterion.metric_kind must match the template")
    if plan.delta_criterion.direction != template.delta_criterion_template.direction:
        raise PlanValidationError("plan.delta_criterion.direction must match the template")

    # 9. bonferroni_k must equal the line's iteration index
    if plan.delta_criterion.bonferroni_k != line_state.iteration_index:
        raise PlanValidationError(
            f"delta_criterion.bonferroni_k={plan.delta_criterion.bonferroni_k} "
            f"must equal line_state.iteration_index={line_state.iteration_index}"
        )
    if plan.delta_criterion.base_alpha != line_state.base_alpha:
        raise PlanValidationError(
            f"delta_criterion.base_alpha={plan.delta_criterion.base_alpha} "
            f"must equal line_state.base_alpha={line_state.base_alpha}"
        )
    if plan.delta_criterion.bonferroni_k < 1:
        raise PlanValidationError("delta_criterion.bonferroni_k must be >= 1")
