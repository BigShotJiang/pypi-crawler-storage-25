"""Workflow-level enums and artifacts for the ml4t research-loop schema.

Holds the enums shared across schema modules plus the workflow-spec /
review / line-state / execution-record dataclasses. No imports from peer
schema modules — this is the root of the schemas DAG.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum
from typing import Literal

# --- Enumerations ------------------------------------------------------------


class IterationCategory(str, Enum):
    MODEL = "model_focused"
    FEATURE = "feature_focused"
    RISK = "risk_portfolio"
    COST = "cost_execution"
    AUDIT = "audit"


class Severity(str, Enum):
    """Severity for methodology findings.

    `INFORMATIONAL` is intentionally absent; benign metadata observations live
    on `DiagnosticNote`, not `MethodologyWarning`.
    """

    BLOCKING = "blocking"
    MATERIAL = "material"
    WARNING = "warning"


class Determinism(str, Enum):
    """Whether a deterministic check can be evaluated from on-disk artifacts
    (`ARITHMETIC`) or relies on a runner contract assertion (`RUNNER_CONTRACT`).
    Stage A1 reports both classes but only `ARITHMETIC` is computable today;
    `RUNNER_CONTRACT` checks fire only when the runner emits the corresponding
    receipt."""

    ARITHMETIC = "arithmetic"
    RUNNER_CONTRACT = "runner_contract"


class DeltaOutcome(str, Enum):
    SUPPORTED = "supported"
    CONTRADICTED = "contradicted"
    INCONCLUSIVE = "inconclusive"
    INVALID = "invalid"


class Decision(str, Enum):
    AUDIT_REQUIRED = "audit_required"
    ITERATE_OFFLINE = "iterate_offline"
    STOP_RESEARCH_LINE = "stop_research_line"
    ADVANCE_TO_HOLDOUT_REVIEW = "advance_to_holdout_review"


class TemplateMaturity(str, Enum):
    CONCRETE = "concrete"  # config seam confirmed against runner
    CANDIDATE = "candidate"  # config seam unconfirmed; v0 implementation deferred


# --- Workflow artifacts ------------------------------------------------------


@dataclass(frozen=True)
class WorkflowSpec:
    objective: str
    case_study: str
    universe_size: int
    primary_label: str
    cadence: str
    execution_delay: str
    holdout_window: str
    validation_design: str
    cost_assumption: str
    constraints: tuple[str, ...] = ()
    acceptance_gates: tuple[str, ...] = ()


@dataclass(frozen=True)
class Finding:
    area: Literal["validity", "signal", "modeling", "strategy_translation", "robustness"]
    severity: Severity
    summary: str
    cited_fields: tuple[str, ...]
    actions: tuple[str, ...] = ()


@dataclass(frozen=True)
class ResearchEvidenceReview:
    decision: Decision
    findings: tuple[Finding, ...]
    open_questions: tuple[str, ...]
    supporting_template_ids: tuple[str, ...]


@dataclass(frozen=True)
class LineState:
    """State of the research line at plan-creation time. `iteration_index` is
    1-based: this plan is the k-th iteration. `bonferroni_k` on the plan's
    DeltaCriterion must equal `iteration_index`.
    """

    line_id: str
    iteration_index: int
    max_iterations: int = 5
    base_alpha: float = 0.05


@dataclass(frozen=True)
class ExecutionRecord:
    experiment_id: str
    parent_run_id: str
    comparison_target_id: str
    git_sha: str
    package_versions: Mapping[str, str]
    data_snapshot_id: str
    config_hash: str
    config_patch_yaml: str
    seeds: Mapping[str, int]
    cli_invocations: tuple[str, ...]
    artifact_paths: tuple[str, ...]
    artifact_checksums: Mapping[str, str]
    wall_clock_seconds: float
    status: Literal["success", "failed", "partial"]
    error: str | None = None
