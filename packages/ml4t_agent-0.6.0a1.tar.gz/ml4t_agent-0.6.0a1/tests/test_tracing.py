"""Round-trip + edge-case tests for the AgentTrace artifact."""

from __future__ import annotations

import json

import pytest

from ml4t.agent.tracing import AgentRun, AgentTrace, trace_from_json, trace_to_json


def _sample_run() -> AgentRun:
    return AgentRun(
        run_id="r1",
        agent_id="research-reviewer",
        traces=(
            AgentTrace(step=1, action="thought", llm_raw="I should fetch evidence."),
            AgentTrace(
                step=2,
                action="tool_call",
                tool_name="evidence.fetch",
                inputs={"line_id": "L1"},
                outputs={"summary_id": "EP-3"},
                timestamp="2026-05-01T23:30:00Z",
            ),
            AgentTrace(step=3, action="final"),
        ),
        final_artifact={"decision": "iterate_offline", "confidence": 0.62},
    )


def test_roundtrip_preserves_all_fields():
    run = _sample_run()
    restored = trace_from_json(trace_to_json(run))
    assert restored == run


def test_roundtrip_via_json_module_compatible():
    run = _sample_run()
    payload = trace_to_json(run)
    parsed = json.loads(payload)
    assert parsed["run_id"] == "r1"
    assert parsed["agent_id"] == "research-reviewer"
    assert len(parsed["traces"]) == 3
    assert parsed["final_artifact"]["decision"] == "iterate_offline"


def test_roundtrip_with_empty_traces_and_no_artifact():
    run = AgentRun(run_id="r2", agent_id="a")
    restored = trace_from_json(trace_to_json(run))
    assert restored == run
    assert restored.traces == ()
    assert restored.final_artifact is None


def test_from_json_rejects_non_object():
    with pytest.raises(ValueError, match="JSON object"):
        trace_from_json("[]")


def test_from_json_rejects_malformed_trace():
    with pytest.raises(ValueError, match="malformed trace entry"):
        trace_from_json('{"run_id": "r", "agent_id": "a", "traces": [{"action": "x"}]}')


def test_traces_are_immutable():
    """Frozen dataclasses raise FrozenInstanceError on assignment.

    Use ``dataclasses.replace`` for mutation; runtime FrozenInstanceError
    inherits from AttributeError so callers can also catch the latter.
    """
    from dataclasses import FrozenInstanceError, replace

    trace = AgentTrace(step=1, action="thought")
    bumped = replace(trace, step=2)
    assert bumped.step == 2 and trace.step == 1
    assert issubclass(FrozenInstanceError, AttributeError)
