"""v0.2 proposer tests — T-A2 and T-M1.

Each test wires a `MockLLMClient` to return a hand-written proposal,
confirms the eligible-set arithmetic on a tailored EvidencePack, and
asserts the proposer constructs a valid plan that round-trips through
`validate_plan`.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import replace
from typing import Any

import pytest

from ml4t.agent.llm import LLMResponse, Message, MockLLMClient
from ml4t.agent.schemas import (
    Determinism,
    EvidencePack,
    LineState,
    MethodologyWarning,
    ModelRunSummary,
    PlanValidationError,
    Severity,
    ValidationMetrics,
    validate_plan,
)
from ml4t.agent.tools.proposals import (
    build_ta2_template,
    build_tm1_template,
    default_templates,
    propose_experiments,
)


@pytest.fixture
def line_state() -> LineState:
    return LineState(line_id="L-1", iteration_index=1, base_alpha=0.05)


def _make_responder(proposals: list[dict[str, Any]]):
    def responder(_messages: Sequence[Message], _schema: Mapping[str, Any]) -> LLMResponse:
        payload = {"proposals": proposals}
        return LLMResponse(data=payload, raw=str(payload))

    return responder


# --- T-A2 fixtures ----------------------------------------------------------


def _ta2_proposal(experiment_id: str = "E-ta2-1") -> dict[str, Any]:
    return {
        "experiment_id": experiment_id,
        "template_id": "T-A2",
        "comparison_target_id": "strat-gbm",
        "hypothesis": "rerun reproduces parent IC within 0.002",
        "rationale": (
            "warnings cite a config_hash mismatch indicating a lineage gap; "
            "rerun the strongest baseline at HEAD"
        ),
        "config_patches": [],
    }


@pytest.fixture
def lineage_pack(sample_pack: EvidencePack) -> EvidencePack:
    """Replace the MATERIAL leak warning with a lineage-citing finding."""

    lineage_warning = MethodologyWarning(
        code="LINEAGE_CONFIG_HASH_MISMATCH",
        message="parent_run config_hash does not match HEAD",
        severity=Severity.MATERIAL,
        determinism=Determinism.ARITHMETIC,
        triggering_artifact="lineage/receipts.json",
        triggering_field="config_hash",
    )
    return replace(sample_pack, warnings=(lineage_warning,))


def test_ta2_eligible_when_lineage_warning_present(
    lineage_pack: EvidencePack,
    line_state: LineState,
) -> None:
    llm = MockLLMClient(responder=_make_responder([_ta2_proposal()]))
    plans = propose_experiments(lineage_pack, llm=llm, line_state=line_state)
    assert [p.template_id for p in plans] == ["T-A2"]
    plan = plans[0]
    assert plan.config_patches == ()
    assert plan.delta_criterion.primary_metric == "mean_fold_ic"
    assert plan.delta_criterion.metric_kind == "absolute"


def test_ta2_thresholds_anchored_to_parent_best_ic(
    lineage_pack: EvidencePack,
    line_state: LineState,
) -> None:
    llm = MockLLMClient(responder=_make_responder([_ta2_proposal()]))
    plans = propose_experiments(lineage_pack, llm=llm, line_state=line_state)
    plan = plans[0]
    best_ic = lineage_pack.validation.signal.best_mean_ic
    assert plan.delta_criterion.support_threshold == pytest.approx(best_ic - 0.002)
    assert plan.delta_criterion.reject_threshold == pytest.approx(best_ic - 0.010)


def test_ta2_plan_round_trips_validation(
    lineage_pack: EvidencePack,
    line_state: LineState,
) -> None:
    llm = MockLLMClient(responder=_make_responder([_ta2_proposal()]))
    plans = propose_experiments(lineage_pack, llm=llm, line_state=line_state)
    plan = plans[0]
    template = build_ta2_template(
        best_mean_ic_prior=lineage_pack.validation.signal.best_mean_ic,
        family=lineage_pack.validation.signal.best_family,
    )
    validate_plan(plan, template, lineage_pack, line_state)


def test_ta2_ineligible_when_warning_does_not_cite_lineage(
    sample_pack: EvidencePack,
    line_state: LineState,
) -> None:
    """The default sample_pack has a MATERIAL leak warning, not a lineage
    warning — T-A2 should be ineligible."""

    llm = MockLLMClient(responder=_make_responder([_ta2_proposal()]))
    plans = propose_experiments(sample_pack, llm=llm, line_state=line_state)
    # MATERIAL severity makes T-C1 and T-M1 also ineligible (forbidden_when),
    # so the catalogue collapses to nothing for `sample_pack`. Eligibility is
    # the structural seal — proposals from an ineligible LLM call short-circuit
    # earlier in propose_experiments.
    assert plans == []


# --- T-M1 fixtures ----------------------------------------------------------


def _tm1_proposal(
    experiment_id: str = "E-tm1-1",
    *,
    label: str = "ret_5d",
    presets: tuple[str, ...] = ("gbm_shallow", "gbm_balanced"),
) -> dict[str, Any]:
    return {
        "experiment_id": experiment_id,
        "template_id": "T-M1",
        "comparison_target_id": "strat-gbm",
        "hypothesis": "tighter neighborhood improves within-family IC by >=0.005",
        "rationale": (
            "GBM family is strongest on signal but fold-IC dispersion is "
            "large; narrow the preset list"
        ),
        "config_patches": [
            {
                "path_template": "config/training/{label}.yaml",
                "path_variables": {"label": label},
                "yaml_path": ["gbm"],
                "new_value": list(presets),
            }
        ],
    }


@pytest.fixture
def gbm_dispersion_pack(sample_pack: EvidencePack) -> EvidencePack:
    """Clean validity (no MATERIAL/BLOCKING) and a GBM run with fold-IC
    std large enough to satisfy `gbm_dispersion_large` (>= 0.5 * mean_fold_ic).
    """

    high_dispersion_gbm = ModelRunSummary(
        family="gbm",
        config_name="lgb_d6",
        label="ret_5d",
        mean_fold_ic=0.024,
        fold_ic_std=0.020,  # 0.020 / 0.024 ≈ 0.83 → large
        fold_sharpe_mean=0.55,
        fold_sharpe_std=0.30,
        n_folds=8,
    )
    runs = tuple(
        high_dispersion_gbm if r.family == "gbm" else r for r in sample_pack.validation.model_runs
    )
    new_metrics = ValidationMetrics(
        model_runs=runs,
        signal=replace(sample_pack.validation.signal, best_family="gbm"),
        backtests=sample_pack.validation.backtests,
        robustness=sample_pack.validation.robustness,
    )
    return replace(sample_pack, warnings=(), validation=new_metrics)


def test_tm1_eligible_when_gbm_dispersion_large(
    gbm_dispersion_pack: EvidencePack,
    line_state: LineState,
) -> None:
    llm = MockLLMClient(responder=_make_responder([_tm1_proposal()]))
    plans = propose_experiments(gbm_dispersion_pack, llm=llm, line_state=line_state)
    assert [p.template_id for p in plans] == ["T-M1"]
    plan = plans[0]
    assert plan.config_patches[0].yaml_path == ("gbm",)
    assert plan.config_patches[0].new_value == ["gbm_shallow", "gbm_balanced"]
    assert plan.delta_criterion.primary_metric == "mean_fold_ic_within_family"
    assert plan.delta_criterion.metric_kind == "delta"


def test_tm1_plan_round_trips_validation(
    gbm_dispersion_pack: EvidencePack,
    line_state: LineState,
) -> None:
    llm = MockLLMClient(responder=_make_responder([_tm1_proposal()]))
    plans = propose_experiments(gbm_dispersion_pack, llm=llm, line_state=line_state)
    plan = plans[0]
    validate_plan(plan, build_tm1_template(), gbm_dispersion_pack, line_state)


def test_tm1_ineligible_when_dispersion_small(
    sample_pack: EvidencePack,
    line_state: LineState,
) -> None:
    """sample_pack's GBM has fold_ic_std=0.012, mean_fold_ic=0.024 →
    0.012 / 0.024 = 0.5 exactly, which `>=` accepts. Force a smaller
    std so the predicate evaluates to False — and verify that an LLM
    proposal referencing the ineligible template raises rather than
    silently dropping (the documented contract: the JSON-schema enum is
    built from `eligible`, so an out-of-set template_id is a malformed
    proposal)."""

    smaller_std_runs = tuple(
        replace(r, fold_ic_std=0.005) if r.family == "gbm" else r
        for r in sample_pack.validation.model_runs
    )
    new_metrics = replace(sample_pack.validation, model_runs=smaller_std_runs)
    pack = replace(sample_pack, warnings=(), validation=new_metrics)

    llm = MockLLMClient(responder=_make_responder([_tm1_proposal()]))
    with pytest.raises(PlanValidationError, match="T-M1"):
        propose_experiments(pack, llm=llm, line_state=line_state)


def test_tm1_invalid_value_type_rejected(
    gbm_dispersion_pack: EvidencePack,
    line_state: LineState,
) -> None:
    bad = _tm1_proposal()
    bad["config_patches"][0]["new_value"] = "gbm_shallow"  # not list[str]
    llm = MockLLMClient(responder=_make_responder([bad]))
    with pytest.raises(PlanValidationError):
        propose_experiments(gbm_dispersion_pack, llm=llm, line_state=line_state)


# --- multi-eligibility ranking ---------------------------------------------


def test_multi_eligible_pack_returns_multiple_templates(
    line_state: LineState,
    sample_pack: EvidencePack,
) -> None:
    """Build a pack that satisfies both T-A2 (lineage warning) and T-M1
    (clean GBM dispersion) — but mutually exclusive: T-A2 needs a
    BLOCKING/MATERIAL lineage warning while T-M1 forbids any
    BLOCKING/MATERIAL warning. So at most one should be eligible per
    pack — T-A2 alone in this fixture."""

    lineage_warning = MethodologyWarning(
        code="LINEAGE_PACKAGE_VERSIONS_DRIFT",
        message="ml4t-engineer version drift between parent and HEAD",
        severity=Severity.MATERIAL,
        determinism=Determinism.ARITHMETIC,
        triggering_artifact="lineage/receipts.json",
        triggering_field="package_versions",
    )
    pack = replace(sample_pack, warnings=(lineage_warning,))
    catalogue = default_templates(evidence=pack)
    eligible_ids = {t.template_id for t in catalogue if t.is_eligible(pack)[0]}
    # MATERIAL severity blocks T-C1 (forbidden_when=BLOCKING is OK but the
    # eligibility uses has_clean_validity which fails on MATERIAL too) and
    # T-M1 (forbidden_when includes MATERIAL); only T-A2 remains.
    assert eligible_ids == {"T-A2"}
