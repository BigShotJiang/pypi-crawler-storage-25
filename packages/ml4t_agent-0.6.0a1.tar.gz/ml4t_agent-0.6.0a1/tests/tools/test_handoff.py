"""Tests for the experiment-spec markdown emitter."""

from __future__ import annotations

from pathlib import Path

import pytest

from ml4t.agent.schemas import (
    ArtifactContract,
    ConfigPatch,
    DeltaCriterion,
    ExperimentPlan,
    StageInvocation,
)
from ml4t.agent.tools.handoff import (
    render_experiment_spec,
    write_experiment_spec_for_coding_agent,
)


def _plan() -> ExperimentPlan:
    return ExperimentPlan(
        experiment_id="E-tc1-1",
        template_id="T-C1",
        parent_run_id="P-1",
        comparison_target_id="bench",
        config_patches=(
            ConfigPatch(
                path_template="config/setup.yaml",
                path_variables=(),
                yaml_path=("costs", "per_leg_cost_bps_range"),
                new_value=[15.0, 25.0],
            ),
        ),
        stage_invocations=(
            StageInvocation(script="16_costs.py"),
            StageInvocation(script="14_backtest.py"),
        ),
        expected_artifacts=(
            ArtifactContract(
                relative_path="results/strategy_assessment.json",
                schema_id="strategy_assessment_v1",
            ),
        ),
        delta_criterion=DeltaCriterion(
            primary_metric="edge_to_cost_ratio_after",
            metric_kind="absolute",
            support_threshold=1.0,
            reject_threshold=1.0,
            direction="higher_is_better",
            noise_floor_method="simple_bootstrap",
            base_alpha=0.05,
            bonferroni_k=2,
        ),
        question="Does the apparent net edge survive cost realism?",
        hypothesis="net edge >= 1.0x at upper-bound costs",
        rationale="cites validation.backtests[strat-gbm].edge_to_cost_ratio=1.6",
    )


def test_render_contains_all_sections():
    md = render_experiment_spec(_plan())
    for section in (
        "# Experiment E-tc1-1",
        "**Template**: `T-C1`",
        "## Question",
        "## Hypothesis",
        "## Rationale",
        "## Config patches",
        "## Stages to invoke",
        "## Expected artifacts",
        "## Delta criterion",
        "16_costs.py",
        "results/strategy_assessment.json",
        "edge_to_cost_ratio_after",
        "bonferroni k=2",
        "adjusted alpha=0.025",
    ):
        assert section in md, section


def test_render_handles_empty_collections():
    from dataclasses import replace

    plan = replace(
        _plan(),
        config_patches=(),
        stage_invocations=(),
        expected_artifacts=(),
    )
    md = render_experiment_spec(plan)
    assert md.count("_(none)_") == 3


def test_write_emits_file(tmp_path: Path):
    out = tmp_path / "spec.md"
    written = write_experiment_spec_for_coding_agent(_plan(), out)
    assert written == out
    assert out.is_file()
    content = out.read_text(encoding="utf-8")
    assert content.startswith("# Experiment E-tc1-1")
    assert content.endswith("\n")


def test_write_rejects_missing_parent(tmp_path: Path):
    out = tmp_path / "missing_subdir" / "spec.md"
    with pytest.raises(FileNotFoundError, match="parent directory"):
        write_experiment_spec_for_coding_agent(_plan(), out)
