"""Tests for the cost-sensitivity rerun tool."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from ml4t.agent.tools.reruns import run_cost_sensitivity


def test_returns_typed_summary_with_requested_bounds(run_dir: Path):
    summary = run_cost_sensitivity(run_dir, cost_bps_range=(15.0, 25.0))
    assert summary.per_leg_bps_low == 15.0
    assert summary.per_leg_bps_high == 25.0
    assert summary.cost_class == "liquid_etf_blend"
    assert summary.components == ("commission", "spread", "impact")


def test_missing_fixture_raises(tmp_path: Path):
    with pytest.raises(FileNotFoundError, match="cost-sensitivity"):
        run_cost_sensitivity(tmp_path, cost_bps_range=(0.0, 1.0))


def test_rejects_negative_range(run_dir: Path):
    with pytest.raises(ValueError, match=">= 0"):
        run_cost_sensitivity(run_dir, cost_bps_range=(-1.0, 5.0))


def test_rejects_inverted_range(run_dir: Path):
    with pytest.raises(ValueError, match="low > high"):
        run_cost_sensitivity(run_dir, cost_bps_range=(10.0, 5.0))


def test_rejects_non_object_payload(tmp_path: Path):
    (tmp_path / "cost_sensitivity.json").write_text("[]", encoding="utf-8")
    with pytest.raises(ValueError, match="expected JSON object"):
        run_cost_sensitivity(tmp_path, cost_bps_range=(0.0, 1.0))


def test_rejects_malformed_payload(tmp_path: Path):
    (tmp_path / "cost_sensitivity.json").write_text(
        json.dumps({"cost_class": "x"}), encoding="utf-8"
    )
    with pytest.raises(ValueError, match="malformed cost_sensitivity"):
        run_cost_sensitivity(tmp_path, cost_bps_range=(0.0, 1.0))
