"""v0.4 proposer tests — T-F1 (drop_stop_features).

Mirrors the v0.2 proposer-test pattern: wire a `MockLLMClient` to return
a hand-written T-F1 proposal, confirm the eligible-set arithmetic on a
tailored EvidencePack with triage entries, and assert the proposer
constructs a valid plan that round-trips through `validate_plan`.

The v0.6 runner contract that populates `pack.triage` is not in scope
here; v0.4 ships fixture-mode T-F1 only. Real packs leave
`triage=None` and the eligibility predicate raises
`PredicateUnavailable`.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import replace
from typing import Any

import pytest

from ml4t.agent.llm import LLMResponse, Message, MockLLMClient
from ml4t.agent.schemas import (
    EvidencePack,
    LineState,
    PlanValidationError,
    Severity,
    TriageEntry,
    validate_plan,
)
from ml4t.agent.tools.proposals import (
    build_tf1_template,
    default_templates,
    propose_experiments,
)


@pytest.fixture
def line_state() -> LineState:
    return LineState(line_id="L-1", iteration_index=1, base_alpha=0.05)


def _make_responder(proposals: list[dict[str, Any]]):
    def responder(_messages: Sequence[Message], _schema: Mapping[str, Any]) -> LLMResponse:
        payload = {"proposals": proposals}
        return LLMResponse(data=payload, raw=str(payload))

    return responder


# --- T-F1 fixtures ----------------------------------------------------------


def _stop(name: str, severity: Severity = Severity.MATERIAL) -> TriageEntry:
    return TriageEntry(
        feature_name=name,
        status="STOP",
        reason="suspect timestamp; possible look-ahead",
        severity=severity,
    )


def _tf1_proposal(
    *,
    experiment_id: str = "E-tf1-1",
    label: str = "ret_5d",
    excluded: tuple[str, ...] = ("regime_x", "lookahead_pe"),
) -> dict[str, Any]:
    return {
        "experiment_id": experiment_id,
        "template_id": "T-F1",
        "comparison_target_id": "strat-gbm",
        "hypothesis": "excluding STOP-flagged features tightens within-family IC by >=0.005",
        "rationale": (
            "two STOP entries in triage cite leak/timestamp risk on the strongest "
            "baseline; drop them and rerun"
        ),
        "config_patches": [
            {
                "path_template": "config/training/{label}.yaml",
                "path_variables": {"label": label},
                "yaml_path": ["features", "exclude"],
                "new_value": list(excluded),
            }
        ],
    }


@pytest.fixture
def tf1_pack(sample_pack: EvidencePack) -> EvidencePack:
    """Clean validity (no MATERIAL/BLOCKING warnings) and triage rows
    containing two STOP-grade entries — satisfies both `has_clean_validity`
    and `feature_triage_has_stop`."""

    return replace(
        sample_pack,
        warnings=(),
        triage=(_stop("regime_x"), _stop("lookahead_pe", severity=Severity.BLOCKING)),
    )


# --- eligibility / proposer ------------------------------------------------


def test_tf1_eligible_when_stop_entries_present(
    tf1_pack: EvidencePack,
    line_state: LineState,
) -> None:
    llm = MockLLMClient(responder=_make_responder([_tf1_proposal()]))
    plans = propose_experiments(tf1_pack, llm=llm, line_state=line_state)
    assert [p.template_id for p in plans] == ["T-F1"]
    plan = plans[0]
    assert plan.config_patches[0].yaml_path == ("features", "exclude")
    assert plan.config_patches[0].new_value == ["regime_x", "lookahead_pe"]
    assert plan.delta_criterion.primary_metric == "mean_fold_ic_within_family"
    assert plan.delta_criterion.metric_kind == "delta"


def test_tf1_plan_round_trips_validation(
    tf1_pack: EvidencePack,
    line_state: LineState,
) -> None:
    llm = MockLLMClient(responder=_make_responder([_tf1_proposal()]))
    plans = propose_experiments(tf1_pack, llm=llm, line_state=line_state)
    plan = plans[0]
    family = tf1_pack.validation.signal.best_family
    validate_plan(plan, build_tf1_template(family=family), tf1_pack, line_state)


def test_tf1_ineligible_on_default_pack(
    sample_pack: EvidencePack,
    line_state: LineState,
) -> None:
    """Default `sample_pack` has `triage=None` → predicate raises
    PredicateUnavailable → T-F1 ineligible. Sample_pack also carries a
    MATERIAL warning, which independently makes T-C1, T-M1, T-F1 ineligible
    via has_clean_validity. With no eligible templates, the LLM is never
    called and `propose_experiments` returns [] — same contract as in v0.2.
    """

    pack = sample_pack  # warnings present, triage None
    plans = propose_experiments(
        pack,
        llm=MockLLMClient(responder=_make_responder([_tf1_proposal()])),
        line_state=line_state,
    )
    assert plans == []


def test_tf1_ineligible_when_only_warning_severity_stops(
    sample_pack: EvidencePack,
    line_state: LineState,
) -> None:
    """STOP entries at WARNING severity do not gate T-F1. Verify the
    proposer rejects an out-of-set T-F1 proposal rather than silently
    dropping it (mirrors the T-M1 contract)."""

    pack = replace(
        sample_pack,
        warnings=(),
        triage=(_stop("noisy_x", severity=Severity.WARNING),),
    )
    llm = MockLLMClient(responder=_make_responder([_tf1_proposal()]))
    with pytest.raises(PlanValidationError, match="T-F1"):
        propose_experiments(pack, llm=llm, line_state=line_state)


def test_tf1_invalid_value_type_rejected(
    tf1_pack: EvidencePack,
    line_state: LineState,
) -> None:
    bad = _tf1_proposal()
    bad["config_patches"][0]["new_value"] = "regime_x"  # not list[str]
    llm = MockLLMClient(responder=_make_responder([bad]))
    with pytest.raises(PlanValidationError):
        propose_experiments(tf1_pack, llm=llm, line_state=line_state)


def test_default_catalogue_includes_tf1(tf1_pack: EvidencePack) -> None:
    """When given a tf1-eligible pack, `default_templates` includes T-F1
    with a family-parametrized stage list matching the parent's best family."""

    catalogue = default_templates(evidence=tf1_pack)
    tf1 = next(t for t in catalogue if t.template_id == "T-F1")
    assert tf1.stage_invocations[0].script == "07_gbm.py"  # gbm in sample_pack
