"""v0.2 rerun-tool tests — `run_lineage_recheck` + `run_narrow_gbm_search`."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from ml4t.agent.schemas import ModelRunSummary
from ml4t.agent.tools.reruns import (
    LINEAGE_RECHECK_FILENAME,
    NARROW_GBM_FILENAME,
    run_lineage_recheck,
    run_narrow_gbm_search,
)


@pytest.fixture
def parent_baseline() -> ModelRunSummary:
    return ModelRunSummary(
        family="gbm",
        config_name="lgb_d6",
        label="ret_5d",
        mean_fold_ic=0.024,
        fold_ic_std=0.012,
        fold_sharpe_mean=0.55,
        fold_sharpe_std=0.20,
        n_folds=8,
    )


# --- run_lineage_recheck ----------------------------------------------------


def _write_lineage_fixture(run_dir: Path, **overrides: object) -> None:
    payload: dict[str, object] = {
        "mean_fold_ic_after": 0.023,
        "fold_ic_after": [0.020, 0.025, 0.022, 0.025, 0.023, 0.024, 0.020, 0.025],
        "git_sha_at_rerun": "abc1234",
        "package_versions_at_rerun": {
            "ml4t-data": "0.1.0a6",
            "ml4t-engineer": "0.1.0b1",
        },
    }
    payload.update(overrides)
    (run_dir / LINEAGE_RECHECK_FILENAME).write_text(json.dumps(payload), encoding="utf-8")


def test_lineage_recheck_returns_typed_result(
    tmp_path: Path, parent_baseline: ModelRunSummary
) -> None:
    _write_lineage_fixture(tmp_path)
    result = run_lineage_recheck(tmp_path, parent_baseline=parent_baseline)
    assert result.parent_baseline is parent_baseline
    assert result.mean_fold_ic_after == pytest.approx(0.023)
    assert len(result.fold_ic_after) == 8
    assert result.git_sha_at_rerun == "abc1234"
    assert result.package_versions_at_rerun["ml4t-engineer"] == "0.1.0b1"


def test_lineage_recheck_missing_fixture_raises(
    tmp_path: Path, parent_baseline: ModelRunSummary
) -> None:
    with pytest.raises(FileNotFoundError, match="lineage-recheck"):
        run_lineage_recheck(tmp_path, parent_baseline=parent_baseline)


def test_lineage_recheck_rejects_non_object_payload(
    tmp_path: Path, parent_baseline: ModelRunSummary
) -> None:
    (tmp_path / LINEAGE_RECHECK_FILENAME).write_text("[]", encoding="utf-8")
    with pytest.raises(ValueError, match="expected JSON object"):
        run_lineage_recheck(tmp_path, parent_baseline=parent_baseline)


def test_lineage_recheck_rejects_malformed_payload(
    tmp_path: Path, parent_baseline: ModelRunSummary
) -> None:
    (tmp_path / LINEAGE_RECHECK_FILENAME).write_text(
        json.dumps({"mean_fold_ic_after": 0.0}), encoding="utf-8"
    )
    with pytest.raises(ValueError, match="malformed lineage_recheck"):
        run_lineage_recheck(tmp_path, parent_baseline=parent_baseline)


def test_lineage_recheck_rejects_non_object_versions(
    tmp_path: Path, parent_baseline: ModelRunSummary
) -> None:
    _write_lineage_fixture(tmp_path, package_versions_at_rerun=["a", "b"])
    with pytest.raises(ValueError, match="package_versions_at_rerun"):
        run_lineage_recheck(tmp_path, parent_baseline=parent_baseline)


# --- run_narrow_gbm_search --------------------------------------------------


def _gbm_run(config_name: str, *, mean_ic: float = 0.025, std: float = 0.010) -> dict[str, object]:
    return {
        "family": "gbm",
        "config_name": config_name,
        "label": "ret_5d",
        "mean_fold_ic": mean_ic,
        "fold_ic_std": std,
        "fold_sharpe_mean": 0.55,
        "fold_sharpe_std": 0.20,
        "n_folds": 8,
    }


def _write_narrow_fixture(run_dir: Path, runs: list[dict[str, object]]) -> None:
    (run_dir / NARROW_GBM_FILENAME).write_text(json.dumps({"runs": runs}), encoding="utf-8")


def test_narrow_gbm_search_returns_typed_result(
    tmp_path: Path, parent_baseline: ModelRunSummary
) -> None:
    _write_narrow_fixture(
        tmp_path,
        [
            _gbm_run("gbm_shallow", mean_ic=0.026),
            _gbm_run("gbm_balanced", mean_ic=0.029),
            _gbm_run("gbm_deep", mean_ic=0.022),  # not in presets_to_try
        ],
    )
    result = run_narrow_gbm_search(
        tmp_path,
        presets_to_try=("gbm_shallow", "gbm_balanced"),
        baseline_within_family=parent_baseline,
    )
    assert result.presets_tried == ("gbm_shallow", "gbm_balanced")
    assert tuple(r.config_name for r in result.narrowed_runs) == (
        "gbm_shallow",
        "gbm_balanced",
    )
    assert result.best_within_family.config_name == "gbm_balanced"
    assert result.mean_fold_ic_within_family_delta == pytest.approx(0.005)


def test_narrow_gbm_search_drops_extra_records(
    tmp_path: Path, parent_baseline: ModelRunSummary
) -> None:
    """The runner is allowed to emit records for unrequested presets;
    the tool drops them silently rather than failing."""

    _write_narrow_fixture(
        tmp_path,
        [_gbm_run("gbm_shallow"), _gbm_run("gbm_balanced"), _gbm_run("gbm_extra")],
    )
    result = run_narrow_gbm_search(
        tmp_path,
        presets_to_try=("gbm_shallow", "gbm_balanced"),
        baseline_within_family=parent_baseline,
    )
    assert "gbm_extra" not in (r.config_name for r in result.narrowed_runs)


def test_narrow_gbm_search_missing_preset_raises(
    tmp_path: Path, parent_baseline: ModelRunSummary
) -> None:
    _write_narrow_fixture(tmp_path, [_gbm_run("gbm_shallow")])
    with pytest.raises(ValueError, match="missing run records"):
        run_narrow_gbm_search(
            tmp_path,
            presets_to_try=("gbm_shallow", "gbm_balanced"),
            baseline_within_family=parent_baseline,
        )


def test_narrow_gbm_search_empty_presets_rejected(
    tmp_path: Path, parent_baseline: ModelRunSummary
) -> None:
    with pytest.raises(ValueError, match="non-empty"):
        run_narrow_gbm_search(
            tmp_path,
            presets_to_try=(),
            baseline_within_family=parent_baseline,
        )


def test_narrow_gbm_search_non_gbm_baseline_rejected(
    tmp_path: Path,
) -> None:
    linear_baseline = ModelRunSummary(
        family="linear",
        config_name="ridge_l2",
        label="ret_5d",
        mean_fold_ic=0.018,
        fold_ic_std=0.009,
        fold_sharpe_mean=0.42,
        fold_sharpe_std=0.18,
        n_folds=8,
    )
    with pytest.raises(ValueError, match="must be 'gbm'"):
        run_narrow_gbm_search(
            tmp_path,
            presets_to_try=("gbm_shallow",),
            baseline_within_family=linear_baseline,
        )


def test_narrow_gbm_search_missing_fixture_raises(
    tmp_path: Path, parent_baseline: ModelRunSummary
) -> None:
    with pytest.raises(FileNotFoundError, match="narrow-gbm"):
        run_narrow_gbm_search(
            tmp_path,
            presets_to_try=("gbm_shallow",),
            baseline_within_family=parent_baseline,
        )


def test_narrow_gbm_search_rejects_missing_runs_key(
    tmp_path: Path, parent_baseline: ModelRunSummary
) -> None:
    (tmp_path / NARROW_GBM_FILENAME).write_text(json.dumps({}), encoding="utf-8")
    with pytest.raises(ValueError, match="'runs' key"):
        run_narrow_gbm_search(
            tmp_path,
            presets_to_try=("gbm_shallow",),
            baseline_within_family=parent_baseline,
        )


def test_narrow_gbm_search_rejects_malformed_run_entry(
    tmp_path: Path, parent_baseline: ModelRunSummary
) -> None:
    bad = _gbm_run("gbm_shallow")
    del bad["mean_fold_ic"]
    _write_narrow_fixture(tmp_path, [bad])
    with pytest.raises(ValueError, match="malformed run entry"):
        run_narrow_gbm_search(
            tmp_path,
            presets_to_try=("gbm_shallow",),
            baseline_within_family=parent_baseline,
        )
