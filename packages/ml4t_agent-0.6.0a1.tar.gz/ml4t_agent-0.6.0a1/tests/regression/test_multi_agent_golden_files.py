"""Plan-31 §v0.5.1 — multi-agent golden-file regression suite.

The chain is ``proposer → validate_plan`` (no LLM reviewer; v0.5.0
spike branch D). Each scenario serializes the
:class:`MultiAgentResult` produced by
:func:`run_proposer_with_validation` to canonical JSON and compares
against a checked-in golden under ``golden_multi_agent/``.

Set ``UPDATE_GOLDENS=1`` to regenerate.

Scenarios:

- ``multi_happy`` — clean validity + T-M1 with an in-spec preset list;
  the plan passes ``validate_plan`` and lands in ``accepted``.
- ``multi_validate_plan_rejects`` — T-A2 plan whose rationale name-drops
  a warning code without citing the triggering artifact; the plan
  produces a MISSING_RECEIPT refusal and lands in ``refusals``.

Both goldens lock the JSON shape of ``MultiAgentResult.accepted`` and
``MultiAgentResult.refusals`` so a refactor that drops or renames
fields trips loudly.
"""

from __future__ import annotations

import json
import os
from collections.abc import Mapping, Sequence
from dataclasses import replace
from pathlib import Path
from typing import Any

import pytest

from ml4t.agent.agents import run_proposer_with_validation
from ml4t.agent.llm import LLMResponse, Message, MockLLMClient
from ml4t.agent.schemas import (
    Determinism,
    EvidencePack,
    LineState,
    MethodologyWarning,
    ModelRunSummary,
    Severity,
    ValidationMetrics,
)
from ml4t.agent.tools import (
    build_ta2_template,
    build_tm1_template,
)

GOLDEN_DIR = Path(__file__).parent / "golden_multi_agent"
UPDATE_FLAG = "UPDATE_GOLDENS"


def _make_mock_llm(payload: dict[str, Any]) -> MockLLMClient:
    def responder(_m: Sequence[Message], _s: Mapping[str, Any]) -> LLMResponse:
        return LLMResponse(data={"proposals": [payload]}, raw=str(payload))

    return MockLLMClient(responder=responder)


def _to_jsonable(value: Any) -> Any:
    from dataclasses import fields as dc_fields
    from dataclasses import is_dataclass
    from enum import Enum
    from types import MappingProxyType

    if is_dataclass(value) and not isinstance(value, type):
        return {f.name: _to_jsonable(getattr(value, f.name)) for f in dc_fields(value)}
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, MappingProxyType | dict):
        return {str(k): _to_jsonable(v) for k, v in value.items()}
    if isinstance(value, list | tuple):
        return [_to_jsonable(v) for v in value]
    return value


def _result_to_canonical_json(result) -> str:
    payload = {
        "accepted": [_to_jsonable(p) for p in result.accepted],
        "refusals": [
            {
                "plan": _to_jsonable(plan),
                "refusals": [_to_jsonable(r) for r in refusals],
            }
            for plan, refusals in result.refusals
        ],
    }
    return json.dumps(payload, indent=2, sort_keys=True, default=str)


def _assert_matches_golden(name: str, payload: str) -> None:
    GOLDEN_DIR.mkdir(parents=True, exist_ok=True)
    path = GOLDEN_DIR / f"{name}.json"
    if os.environ.get(UPDATE_FLAG):
        path.write_text(payload + "\n", encoding="utf-8")
        return
    if not path.is_file():
        pytest.fail(
            f"missing golden file {path}; regenerate with {UPDATE_FLAG}=1 "
            "and review the diff before committing"
        )
    expected = path.read_text(encoding="utf-8").rstrip("\n")
    actual = payload.rstrip("\n")
    if actual != expected:
        pytest.fail(
            f"golden mismatch for {name}; regenerate with {UPDATE_FLAG}=1 "
            "and review the diff before committing"
        )


# --- Pack constructors -----------------------------------------------------


def _gbm_dispersion_pack(sample: EvidencePack) -> EvidencePack:
    high_dispersion_gbm = ModelRunSummary(
        family="gbm",
        config_name="lgb_d6",
        label="ret_5d",
        mean_fold_ic=0.024,
        fold_ic_std=0.020,
        fold_sharpe_mean=0.55,
        fold_sharpe_std=0.30,
        n_folds=8,
    )
    runs = tuple(
        high_dispersion_gbm if r.family == "gbm" else r for r in sample.validation.model_runs
    )
    new_metrics = ValidationMetrics(
        model_runs=runs,
        signal=replace(sample.validation.signal, best_family="gbm"),
        backtests=sample.validation.backtests,
        robustness=sample.validation.robustness,
    )
    return replace(sample, warnings=(), validation=new_metrics)


def _lineage_pack(sample: EvidencePack) -> EvidencePack:
    return replace(
        sample,
        warnings=(
            MethodologyWarning(
                code="LINEAGE_CONFIG_HASH_MISMATCH",
                message="parent_run config_hash does not match HEAD",
                severity=Severity.MATERIAL,
                determinism=Determinism.ARITHMETIC,
                triggering_artifact="lineage/receipts.json",
                triggering_field="config_hash",
            ),
        ),
    )


# --- Scenarios -------------------------------------------------------------


def test_multi_happy(sample_pack: EvidencePack) -> None:
    pack = _gbm_dispersion_pack(sample_pack)
    llm = _make_mock_llm(
        {
            "experiment_id": "E-tm1-1",
            "template_id": "T-M1",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "tighter neighborhood improves within-family IC",
            "rationale": (
                "GBM family is strongest on signal but fold-IC dispersion "
                "is large; narrow the preset list"
            ),
            "config_patches": [
                {
                    "path_template": "config/training/{label}.yaml",
                    "path_variables": {"label": "ret_5d"},
                    "yaml_path": ["gbm"],
                    "new_value": ["lgb_d6"],
                }
            ],
        }
    )
    result = run_proposer_with_validation(
        pack,
        llm=llm,
        line_state=LineState(line_id="L-1", iteration_index=1, base_alpha=0.05),
        templates=(build_tm1_template(),),
    )
    _assert_matches_golden("multi_happy", _result_to_canonical_json(result))


def test_multi_validate_plan_rejects(sample_pack: EvidencePack) -> None:
    pack = _lineage_pack(sample_pack)
    template = build_ta2_template(
        best_mean_ic_prior=pack.validation.signal.best_mean_ic,
        family=pack.validation.signal.best_family,
    )
    llm = _make_mock_llm(
        {
            "experiment_id": "E-ta2-1",
            "template_id": "T-A2",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "rerun reproduces parent IC within tolerance",
            # Cites warning code but not its triggering_artifact or
            # triggering_field — MISSING_RECEIPT refusal expected.
            "rationale": (
                "the LINEAGE_CONFIG_HASH_MISMATCH warning indicates we "
                "should rerun the strongest baseline at HEAD"
            ),
            "config_patches": [],
        }
    )
    result = run_proposer_with_validation(
        pack,
        llm=llm,
        line_state=LineState(line_id="L-1", iteration_index=1, base_alpha=0.05),
        templates=(template,),
    )
    _assert_matches_golden("multi_validate_plan_rejects", _result_to_canonical_json(result))
