"""Plan-30 layer 3 — public-API surface freeze.

Snapshots `ml4t.agent.__all__`, the public schema dataclasses' field
sets, and the tools' top-level exports. Any change to these surfaces
requires a deliberate update to this file — the diff catches accidental
renames, removals, or new public symbols that should ship with a
version bump.

When a public surface change is intentional, edit the expected sets
below in the same PR that lands the change. The test message points
operators here.
"""

from __future__ import annotations

from dataclasses import fields, is_dataclass

import ml4t.agent
import ml4t.agent.llm
import ml4t.agent.schemas
import ml4t.agent.tools

# --- Top-level package -----------------------------------------------------


_EXPECTED_TOP_LEVEL = frozenset(
    {
        "EvidencePack",
        "ResearchNote",
        "ExperimentTemplate",
        "ResearchReviewAgent",
        "Refusal",
        "RefusalKind",
        "read_case_study_evidence",
        "summarize_run",
        "propose_experiments",
        "run_cost_sensitivity",
        "write_experiment_spec_for_coding_agent",
        "LLMClient",
        "MockLLMClient",
    }
)


def test_top_level_all_is_frozen() -> None:
    assert frozenset(ml4t.agent.__all__) == _EXPECTED_TOP_LEVEL, (
        "ml4t.agent.__all__ changed. Update tests/regression/test_public_api_freeze.py "
        "in the same PR if the change is deliberate."
    )


# --- ml4t.agent.schemas ----------------------------------------------------


_EXPECTED_SCHEMAS = frozenset(
    {
        # workflow
        "IterationCategory",
        "Severity",
        "Determinism",
        "DeltaOutcome",
        "Decision",
        "TemplateMaturity",
        "WorkflowSpec",
        "Finding",
        "ResearchEvidenceReview",
        "LineState",
        "ExecutionRecord",
        # evidence
        "ValidationDesign",
        "ModelRunSummary",
        "SignalSummary",
        "BacktestSummary",
        "CostSummary",
        "RobustnessSummary",
        "LineageSummary",
        "MethodologyWarning",
        "DiagnosticNote",
        "TriageEntry",
        "ValidationMetrics",
        "HoldoutMetrics",
        "EvidencePack",
        "PredicateUnavailable",
        "PREDICATES",
        "has_clean_validity",
        "methodology_warning_present",
        "methodology_warning_cites_lineage",
        "gbm_baseline_present",
        "linear_baseline_present",
        "gbm_dispersion_large",
        "signal_positive_net_weak",
        "turnover_high",
        "regime_features_available",
        "feature_triage_has_stop",
        "holdout_sealed",
        # delta
        "DeltaCriterion",
        "DeltaReview",
        "recommend_decision",
        # note
        "ResearchNote",
        # refusal
        "RefusalKind",
        "Refusal",
        # rerun_results
        "LineageRecheckResult",
        "NarrowGbmResult",
        # action_space
        "PathTemplate",
        "ValueTypeName",
        "HOLDOUT_FORBIDDEN_TOKENS",
        "PlanValidationError",
        "OverrideSpec",
        "ConfigPatch",
        "StageInvocation",
        "ArtifactContract",
        "ExperimentTemplate",
        "ExperimentPlan",
        "IterationPlan",
        # validation
        "validate_plan",
    }
)


def test_schemas_all_is_frozen() -> None:
    assert frozenset(ml4t.agent.schemas.__all__) == _EXPECTED_SCHEMAS, (
        "ml4t.agent.schemas.__all__ changed. Update the freeze in "
        "tests/regression/test_public_api_freeze.py if deliberate."
    )


# --- ml4t.agent.tools ------------------------------------------------------


_EXPECTED_TOOLS = frozenset(
    {
        "read_case_study_evidence",
        "summarize_run",
        "list_open_questions",
        "propose_experiments",
        "default_templates",
        "build_tc1_template",
        "build_ta2_template",
        "build_tm1_template",
        "build_tf1_template",
        "run_cost_sensitivity",
        "run_lineage_recheck",
        "run_narrow_gbm_search",
        "write_experiment_spec_for_coding_agent",
        "render_experiment_spec",
    }
)


def test_tools_all_is_frozen() -> None:
    assert frozenset(ml4t.agent.tools.__all__) == _EXPECTED_TOOLS


# --- Dataclass field freeze ------------------------------------------------


_EXPECTED_DATACLASS_FIELDS: dict[str, frozenset[str]] = {
    "EvidencePack": frozenset(
        {
            "case_study",
            "objective",
            "primary_label",
            "horizon",
            "cadence",
            "parent_run_id",
            "line_id",
            "validation_design",
            "validation",
            "holdout",
            "costs",
            "lineage",
            "warnings",
            "diagnostics",
            "triage",
            "preset_registry",
        }
    ),
    "ExperimentTemplate": frozenset(
        {
            "template_id",
            "category",
            "maturity",
            "question",
            "preconditions",
            "forbidden_when",
            "allowed_overrides",
            "forbidden_paths",
            "stage_invocations",
            "expected_artifacts",
            "delta_criterion_template",
            "expected_information_value",
            "relative_cost",
        }
    ),
    "ExperimentPlan": frozenset(
        {
            "experiment_id",
            "template_id",
            "parent_run_id",
            "comparison_target_id",
            "config_patches",
            "stage_invocations",
            "expected_artifacts",
            "delta_criterion",
            "question",
            "hypothesis",
            "rationale",
        }
    ),
    "DeltaCriterion": frozenset(
        {
            "primary_metric",
            "metric_kind",
            "support_threshold",
            "reject_threshold",
            "direction",
            "noise_floor_method",
            "base_alpha",
            "bonferroni_k",
        }
    ),
    "DeltaReview": frozenset(
        {
            "experiment_id",
            "primary_metric",
            "metric_kind",
            "before",
            "after",
            "point_estimate",
            "interval_low",
            "interval_high",
            "fold_deltas",
            "cost_sensitivity",
            "regime_breakdown",
            "outcome",
            "recommendation",
            "rationale",
        }
    ),
    "LineState": frozenset({"line_id", "iteration_index", "max_iterations", "base_alpha"}),
    "LineageRecheckResult": frozenset(
        {
            "parent_baseline",
            "mean_fold_ic_after",
            "fold_ic_after",
            "git_sha_at_rerun",
            "package_versions_at_rerun",
        }
    ),
    "NarrowGbmResult": frozenset({"baseline_within_family", "narrowed_runs", "presets_tried"}),
    "Refusal": frozenset({"kind", "message", "field_path", "cited_evidence"}),
}


def test_public_dataclass_fields_are_frozen() -> None:
    for name, expected in _EXPECTED_DATACLASS_FIELDS.items():
        cls = getattr(ml4t.agent.schemas, name)
        assert is_dataclass(cls), f"{name} is no longer a dataclass"
        actual = frozenset(f.name for f in fields(cls))
        assert actual == expected, (
            f"{name} field set changed: missing={sorted(expected - actual)} "
            f"unexpected={sorted(actual - expected)}. Update freeze if deliberate."
        )
