"""Plan-30 layer 1 — `ResearchNote` golden-file regression suite.

Each scenario builds a deterministic run-dir fixture, runs the agent
end-to-end with a hand-written proposal, and serializes the resulting
`ResearchNote` to canonical JSON. The serialized form is compared
against a checked-in golden file under `golden_research_notes/`.

Set ``UPDATE_GOLDENS=1`` in the environment to overwrite the golden
files; the test then asserts the new file matches itself (a soft pass)
so CI cannot accidentally rewrite goldens. Local regeneration is
explicit::

    UPDATE_GOLDENS=1 uv run pytest tests/regression/test_research_note_golden_files.py

Scenarios:

- ``tc1_happy`` — clean validity + supported T-C1 delta. Locks the v0.1
  baseline so v0.2 catalogue work cannot silently regress it.
- ``ta2_lineage`` — MATERIAL lineage warning + supported T-A2 delta.
- ``tm1_dispersion`` — clean validity + large GBM dispersion + supported
  T-M1 delta.
- ``eligibility_seal`` — BLOCKING warning collapses the eligible set;
  the agent emits an empty-proposal note and stops the line.
"""

from __future__ import annotations

import json
import os
from collections.abc import Mapping, Sequence
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any  # noqa: F401  # used in _to_jsonable signature

import pytest

from ml4t.agent.agents import DELTA_REVIEW_FILENAME, ResearchReviewAgent
from ml4t.agent.llm import LLMResponse, Message, MockLLMClient
from ml4t.agent.schemas import (
    Determinism,
    EvidencePack,
    LineState,
    MethodologyWarning,
    ModelRunSummary,
    ResearchNote,
    Severity,
    ValidationMetrics,
)
from ml4t.agent.tools.reruns import LINEAGE_RECHECK_FILENAME, NARROW_GBM_FILENAME

GOLDEN_DIR = Path(__file__).parent / "golden_research_notes"
UPDATE_FLAG = "UPDATE_GOLDENS"


def _make_mock_llm(payload: dict[str, Any] | None) -> MockLLMClient:
    def responder(_m: Sequence[Message], _s: Mapping[str, Any]) -> LLMResponse:
        body = {"proposals": [payload] if payload is not None else []}
        return LLMResponse(data=body, raw=str(body))

    return MockLLMClient(responder=responder)


def _to_jsonable(value: Any) -> Any:
    """Recursive dataclass / mapping / sequence walker.

    Avoids ``dataclasses.asdict`` because the schemas use
    ``MappingProxyType`` for read-only mappings (``DeltaReview.
    regime_breakdown``), which CPython 3.14's deepcopy refuses to copy.
    The walker handles the same shapes asdict supports plus enums.
    """

    from dataclasses import fields as dc_fields
    from dataclasses import is_dataclass
    from enum import Enum
    from types import MappingProxyType

    if is_dataclass(value) and not isinstance(value, type):
        return {f.name: _to_jsonable(getattr(value, f.name)) for f in dc_fields(value)}
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, MappingProxyType | dict):
        return {str(k): _to_jsonable(v) for k, v in value.items()}
    if isinstance(value, list | tuple):
        return [_to_jsonable(v) for v in value]
    return value


def _note_to_canonical_json(note: ResearchNote) -> str:
    """Dataclass → sorted-key JSON, suitable for diffing on disk."""

    return json.dumps(_to_jsonable(note), indent=2, sort_keys=True, default=str)


def _assert_matches_golden(name: str, payload: str) -> None:
    GOLDEN_DIR.mkdir(parents=True, exist_ok=True)
    path = GOLDEN_DIR / f"{name}.json"
    if os.environ.get(UPDATE_FLAG):
        path.write_text(payload + "\n", encoding="utf-8")
        return
    if not path.is_file():
        pytest.fail(
            f"missing golden file {path}; regenerate with {UPDATE_FLAG}=1 "
            f"and review the diff before committing"
        )
    expected = path.read_text(encoding="utf-8").rstrip("\n")
    actual = payload.rstrip("\n")
    if actual != expected:
        pytest.fail(
            f"golden mismatch for {name}; regenerate with {UPDATE_FLAG}=1 "
            f"and review the diff before committing"
        )


# --- Pack constructors -----------------------------------------------------


def _clean_pack(sample: EvidencePack) -> EvidencePack:
    return replace(sample, warnings=())


def _lineage_pack(sample: EvidencePack) -> EvidencePack:
    return replace(
        sample,
        warnings=(
            MethodologyWarning(
                code="LINEAGE_CONFIG_HASH_MISMATCH",
                message="parent_run config_hash does not match HEAD",
                severity=Severity.MATERIAL,
                determinism=Determinism.ARITHMETIC,
                triggering_artifact="lineage/receipts.json",
                triggering_field="config_hash",
            ),
        ),
    )


def _gbm_dispersion_pack(sample: EvidencePack) -> EvidencePack:
    high_dispersion_gbm = ModelRunSummary(
        family="gbm",
        config_name="lgb_d6",
        label="ret_5d",
        mean_fold_ic=0.024,
        fold_ic_std=0.020,
        fold_sharpe_mean=0.55,
        fold_sharpe_std=0.30,
        n_folds=8,
    )
    runs = tuple(
        high_dispersion_gbm if r.family == "gbm" else r for r in sample.validation.model_runs
    )
    new_metrics = ValidationMetrics(
        model_runs=runs,
        signal=replace(sample.validation.signal, best_family="gbm"),
        backtests=sample.validation.backtests,
        robustness=sample.validation.robustness,
    )
    return replace(sample, warnings=(), validation=new_metrics)


def _blocking_pack(sample: EvidencePack) -> EvidencePack:
    return replace(
        sample,
        warnings=(
            MethodologyWarning(
                code="HOLDOUT_TOUCHED",
                message="holdout window read during validation rerun",
                severity=Severity.BLOCKING,
                determinism=Determinism.ARITHMETIC,
                triggering_artifact="evaluation/audit.parquet",
                triggering_field="holdout_start",
            ),
        ),
    )


# --- Run-dir helpers -------------------------------------------------------


def _write_pack(run_dir: Path, pack: EvidencePack) -> None:
    (run_dir / "evidence_pack.json").write_text(
        json.dumps(asdict(pack), default=str), encoding="utf-8"
    )


def _write_cost_sensitivity(run_dir: Path) -> None:
    (run_dir / "cost_sensitivity.json").write_text(
        json.dumps(
            {
                "cost_class": "liquid_etf_blend",
                "components": ["commission", "spread", "impact"],
            }
        ),
        encoding="utf-8",
    )


def _write_lineage_artifact(run_dir: Path) -> None:
    (run_dir / LINEAGE_RECHECK_FILENAME).write_text(
        json.dumps(
            {
                "mean_fold_ic_after": 0.023,
                "fold_ic_after": [0.023, 0.024, 0.022, 0.025],
                "git_sha_at_rerun": "abc1234",
                "package_versions_at_rerun": {"ml4t-engineer": "0.1.0b1"},
            }
        ),
        encoding="utf-8",
    )


def _write_narrow_gbm_artifact(run_dir: Path) -> None:
    (run_dir / NARROW_GBM_FILENAME).write_text(
        json.dumps(
            {
                "runs": [
                    {
                        "family": "gbm",
                        "config_name": "gbm_shallow",
                        "label": "ret_5d",
                        "mean_fold_ic": 0.026,
                        "fold_ic_std": 0.011,
                        "fold_sharpe_mean": 0.58,
                        "fold_sharpe_std": 0.18,
                        "n_folds": 8,
                    },
                    {
                        "family": "gbm",
                        "config_name": "gbm_balanced",
                        "label": "ret_5d",
                        "mean_fold_ic": 0.029,
                        "fold_ic_std": 0.010,
                        "fold_sharpe_mean": 0.62,
                        "fold_sharpe_std": 0.16,
                        "n_folds": 8,
                    },
                ]
            }
        ),
        encoding="utf-8",
    )


def _write_delta_review(
    run_dir: Path,
    template_id: str,
    *,
    outcome: str,
    primary_metric: str,
    metric_kind: str,
    point_estimate: float,
    interval_low: float,
    interval_high: float,
    before: float,
    after: float,
    fold_deltas: tuple[float, ...] = (),
) -> None:
    payload = {
        "experiment_id": f"E-{template_id.lower().replace('-', '')}-1",
        "primary_metric": primary_metric,
        "metric_kind": metric_kind,
        "before": before,
        "after": after,
        "point_estimate": point_estimate,
        "interval_low": interval_low,
        "interval_high": interval_high,
        "fold_deltas": list(fold_deltas),
        "cost_sensitivity": [],
        "outcome": outcome,
        "recommendation": "iterate_offline",
        "rationale": f"{template_id} delta review",
    }
    (run_dir / DELTA_REVIEW_FILENAME.format(template_id=template_id)).write_text(
        json.dumps(payload), encoding="utf-8"
    )


# --- Proposal payloads (deterministic) -------------------------------------


_TC1_PROPOSAL = {
    "experiment_id": "E-tc1-1",
    "template_id": "T-C1",
    "comparison_target_id": "strat-gbm",
    "hypothesis": "net edge >= 1.0x at 25 bps upper bound",
    "rationale": "validation.backtests[strat-gbm] survives stricter cost",
    "config_patches": [
        {
            "path_template": "config/setup.yaml",
            "path_variables": {},
            "yaml_path": ["costs", "per_leg_cost_bps_range"],
            "new_value": [15.0, 25.0],
        }
    ],
}

_TA2_PROPOSAL = {
    "experiment_id": "E-ta2-1",
    "template_id": "T-A2",
    "comparison_target_id": "strat-gbm",
    "hypothesis": "rerun reproduces parent IC within tolerance",
    "rationale": "lineage warning cites config_hash mismatch",
    "config_patches": [],
}

_TM1_PROPOSAL = {
    "experiment_id": "E-tm1-1",
    "template_id": "T-M1",
    "comparison_target_id": "strat-gbm",
    "hypothesis": "narrowed GBM list improves within-family IC by >=0.005",
    "rationale": "GBM dispersion is large; concentrate the preset list",
    "config_patches": [
        {
            "path_template": "config/training/{label}.yaml",
            "path_variables": {"label": "ret_5d"},
            "yaml_path": ["gbm"],
            "new_value": ["gbm_shallow", "gbm_balanced"],
        }
    ],
}


# --- Tests -----------------------------------------------------------------


@pytest.fixture
def line_state() -> LineState:
    return LineState(line_id="L-1", iteration_index=1, base_alpha=0.05)


def test_golden_tc1_happy(tmp_path: Path, sample_pack: EvidencePack, line_state: LineState) -> None:
    pack = _clean_pack(sample_pack)
    _write_pack(tmp_path, pack)
    _write_cost_sensitivity(tmp_path)
    _write_delta_review(
        tmp_path,
        "T-C1",
        outcome="supported",
        primary_metric="edge_to_cost_ratio_after",
        metric_kind="absolute",
        point_estimate=1.32,
        interval_low=1.10,
        interval_high=1.55,
        before=1.6,
        after=1.32,
        fold_deltas=(-0.30, -0.25, -0.28, -0.32),
    )
    agent = ResearchReviewAgent(_make_mock_llm(_TC1_PROPOSAL), line_state=line_state)
    note = agent.run(tmp_path)
    _assert_matches_golden("tc1_happy", _note_to_canonical_json(note))


def test_golden_ta2_lineage(
    tmp_path: Path, sample_pack: EvidencePack, line_state: LineState
) -> None:
    pack = _lineage_pack(sample_pack)
    _write_pack(tmp_path, pack)
    _write_lineage_artifact(tmp_path)
    best_ic = pack.validation.signal.best_mean_ic
    _write_delta_review(
        tmp_path,
        "T-A2",
        outcome="supported",
        primary_metric="mean_fold_ic",
        metric_kind="absolute",
        point_estimate=best_ic - 0.001,
        interval_low=best_ic - 0.001,
        interval_high=best_ic + 0.001,
        before=best_ic,
        after=best_ic - 0.001,
    )
    agent = ResearchReviewAgent(_make_mock_llm(_TA2_PROPOSAL), line_state=line_state)
    note = agent.run(tmp_path)
    _assert_matches_golden("ta2_lineage", _note_to_canonical_json(note))


def test_golden_tm1_dispersion(
    tmp_path: Path, sample_pack: EvidencePack, line_state: LineState
) -> None:
    pack = _gbm_dispersion_pack(sample_pack)
    _write_pack(tmp_path, pack)
    _write_narrow_gbm_artifact(tmp_path)
    _write_delta_review(
        tmp_path,
        "T-M1",
        outcome="supported",
        primary_metric="mean_fold_ic_within_family",
        metric_kind="delta",
        point_estimate=0.006,
        interval_low=0.006,
        interval_high=0.008,
        before=0.024,
        after=0.030,
    )
    agent = ResearchReviewAgent(_make_mock_llm(_TM1_PROPOSAL), line_state=line_state)
    note = agent.run(tmp_path)
    _assert_matches_golden("tm1_dispersion", _note_to_canonical_json(note))


def test_golden_eligibility_seal(
    tmp_path: Path, sample_pack: EvidencePack, line_state: LineState
) -> None:
    pack = _blocking_pack(sample_pack)
    _write_pack(tmp_path, pack)
    # No rerun or delta artifact — none should be reached.
    agent = ResearchReviewAgent(_make_mock_llm(None), line_state=line_state)
    note = agent.run(tmp_path)
    _assert_matches_golden("eligibility_seal", _note_to_canonical_json(note))
