"""Live OpenAI API smoke test (plan-31 §v0.6).

Mirrors the Anthropic structure in ``tests/test_live_real_llm.py``: a
``propose_experiments`` call against a cheap default model
(``gpt-5-mini``) and a full ``ResearchReviewAgent`` loop. Skipped unless
``OPENAI_API_KEY`` is available (env var or ``.env`` at the package
root).

Two calls per run:

1. ``propose_experiments`` against **gpt-5-mini** — wiring + JSON-schema
   constraint at low cost. Exercises the v0.6 OpenAIClient defaults
   (``strict=False`` + ``max_tokens=8192``) end-to-end against the
   proposer schema; the v0.5.0 spike proved both deviations are
   load-bearing for live execution.
2. Full ``ResearchReviewAgent.run`` against **gpt-5-mini** — end-to-end
   prompt → typed plan → ResearchNote.

Estimated total cost: <$0.05 (gpt-5-mini is ~12× cheaper than
Sonnet 4.6 input and ~7× cheaper output).
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any

import pytest

# --- .env autoload ---------------------------------------------------------

_PKG_ROOT = Path(__file__).resolve().parent.parent


def _load_dotenv(path: Path) -> None:
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


_load_dotenv(_PKG_ROOT / ".env")


# --- Marker + skip ---------------------------------------------------------

pytestmark = [
    pytest.mark.live,
    pytest.mark.skipif(
        not os.environ.get("OPENAI_API_KEY"),
        reason="OPENAI_API_KEY not set; live OpenAI smoke test skipped",
    ),
]


# --- Fixtures --------------------------------------------------------------


@pytest.fixture
def line_state():
    from ml4t.agent.schemas import LineState

    return LineState(line_id="L-1", iteration_index=1, base_alpha=0.05)


@pytest.fixture
def clean_pack(sample_pack):
    return replace(sample_pack, warnings=())


@pytest.fixture
def clean_run_dir(tmp_path: Path, clean_pack) -> Path:
    """Run-dir with clean evidence pack + supported delta_review."""
    from ml4t.agent.agents import DELTA_REVIEW_FILENAME

    (tmp_path / "evidence_pack.json").write_text(
        json.dumps(asdict(clean_pack), default=str), encoding="utf-8"
    )
    (tmp_path / "cost_sensitivity.json").write_text(
        json.dumps(
            {
                "cost_class": "liquid_etf_blend",
                "components": ["commission", "spread", "impact"],
            }
        ),
        encoding="utf-8",
    )
    review: dict[str, Any] = {
        "experiment_id": "E-tc1-1",
        "primary_metric": "edge_to_cost_ratio_after",
        "metric_kind": "absolute",
        "before": 1.6,
        "after": 1.32,
        "point_estimate": 1.32,
        "interval_low": 1.10,
        "interval_high": 1.55,
        "fold_deltas": [-0.30, -0.25, -0.28, -0.32],
        "cost_sensitivity": [[15.0, 1.55], [25.0, 1.32]],
        "outcome": "supported",
        "recommendation": "iterate_offline",
        "rationale": "edge survives the 25bps stress test",
    }
    (tmp_path / DELTA_REVIEW_FILENAME.format(template_id="T-C1")).write_text(
        json.dumps(review), encoding="utf-8"
    )
    return tmp_path


def _assert_valid_plan(plan, *, clean_pack, line_state) -> None:
    """Schema-level invariants every live response must satisfy.

    The catalogue may return any eligible template; look up the template
    by ``plan.template_id`` rather than hard-coding T-C1.
    """
    from ml4t.agent.schemas import validate_plan
    from ml4t.agent.tools import default_templates

    templates_by_id = {t.template_id: t for t in default_templates(clean_pack)}
    template = templates_by_id.get(plan.template_id)
    assert template is not None, f"unknown template_id={plan.template_id!r}"
    validate_plan(plan, template, clean_pack, line_state)
    assert plan.delta_criterion.bonferroni_k == line_state.iteration_index
    assert plan.config_patches  # at least one patch


# --- Tests -----------------------------------------------------------------


def test_propose_experiments_gpt5_mini(clean_pack, line_state, capsys):
    """gpt-5-mini: cheap wiring + JSON-schema constraint check.

    gpt-5-mini rejects ``temperature`` overrides; opt out with
    ``temperature=None``.
    """
    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.tools import propose_experiments

    client = OpenAIClient(model="gpt-5-mini")
    plans = propose_experiments(clean_pack, llm=client, line_state=line_state, temperature=None)

    assert len(plans) >= 1
    for plan in plans:
        _assert_valid_plan(plan, clean_pack=clean_pack, line_state=line_state)

    with capsys.disabled():
        print(
            f"\n[live] propose_experiments / gpt-5-mini → {len(plans)} plan(s); "
            f"first.experiment_id={plans[0].experiment_id!r} "
            f"first.rationale={plans[0].rationale[:80]!r}…"
        )


def test_full_agent_loop_gpt5_mini(clean_run_dir, line_state, capsys):
    """End-to-end ReAct loop with gpt-5-mini."""
    from ml4t.agent.agents import ResearchReviewAgent
    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.schemas import Decision, ResearchNote

    client = OpenAIClient(model="gpt-5-mini")
    agent = ResearchReviewAgent(client, line_state=line_state, propose_temperature=None)
    note = agent.run(clean_run_dir)

    assert isinstance(note, ResearchNote)
    assert note.line_id == line_state.line_id
    assert note.iteration_index == line_state.iteration_index
    assert note.proposals, "live LLM must produce at least one proposal"
    assert note.selected_experiment_id is not None
    assert note.decision is Decision.ITERATE_OFFLINE
    assert agent.last_run is not None
    actions = [t.action for t in agent.last_run.traces]
    assert actions[:2] == ["read_evidence", "propose"]
    assert actions[-1] == "decide"

    with capsys.disabled():
        print(
            f"\n[live] full agent / gpt-5-mini → "
            f"decision={note.decision.value} "
            f"selected={note.selected_experiment_id!r} "
            f"n_proposals={len(note.proposals)} "
            f"n_traces={len(agent.last_run.traces)}"
        )
