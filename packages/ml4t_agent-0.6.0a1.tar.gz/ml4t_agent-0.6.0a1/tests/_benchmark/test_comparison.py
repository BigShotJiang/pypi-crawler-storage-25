from __future__ import annotations

import json
from dataclasses import replace

from ml4t.agent._benchmark import (
    AutonomyLevel,
    ETFBenchmarkHarness,
    SubmissionReceipt,
    build_benchmark_comparison,
    build_default_etf_benchmark_pack,
    load_etf_benchmark,
)


def _benchmark_definition(tmp_path):
    config_dir = tmp_path / "config"
    training_dir = config_dir / "training"
    backtest_dir = config_dir / "backtest"
    training_dir.mkdir(parents=True)
    backtest_dir.mkdir(parents=True)
    (config_dir / "setup.yaml").write_text(
        "\n".join(
            [
                "strategy_id: etfs",
                "setup_version: v1",
                "mapping:",
                "  sizing: equal_weight",
                "labels:",
                "  primary: fwd_ret_21d",
                "  variants:",
                "    - fwd_ret_5d",
                "evaluation:",
                "  holdout_start: '2024-01-01'",
                "  holdout_end: '2025-12-31'",
            ]
        )
        + "\n"
    )
    (training_dir / "fwd_ret_21d.yaml").write_text(
        "\n".join(
            [
                "linear:",
                "  - ols",
                "  - ridge_a0.1",
                "gbm:",
                "  - default_mse",
                "  - default_huber",
                "tabular_dl:",
                "  - tabm_s",
                "latent_factors:",
                "  - pca",
            ]
        )
        + "\n"
    )
    (config_dir / "cv_config.json").write_text(
        json.dumps(
            {
                "n_splits": 8,
                "train_size": "10Y",
                "test_size": "1Y",
                "embargo_td": "P21D",
                "label_horizon": "P21D",
                "calendar_id": "NYSE",
            }
        )
    )
    (backtest_dir / "base.yaml").write_text("execution:\n  execution_price: open\n")
    (tmp_path / "README.md").write_text("# ETF case study\n")
    return load_etf_benchmark(tmp_path)


def test_build_benchmark_comparison_highlights_delta(tmp_path) -> None:
    definition = _benchmark_definition(tmp_path)
    pack = build_default_etf_benchmark_pack(definition)
    harness = ETFBenchmarkHarness.from_definition(definition)
    unconstrained = harness.new_trial(
        trial_id="trial-u",
        cell_id="cell-1",
        trace_id="trace-u",
        benchmark_seed=1,
        runtime_id="plain_python",
        model_id="frontier-model",
        model_version="1",
        docs_pack_id=pack.docs_pack.docs_pack_id,
        autonomy_level=AutonomyLevel.VALIDITY_EXECUTION,
    )
    constrained = harness.new_trial(
        trial_id="trial-c",
        cell_id="cell-1",
        trace_id="trace-c",
        benchmark_seed=1,
        runtime_id="plain_python",
        model_id="frontier-model",
        model_version="1",
        docs_pack_id=pack.docs_pack.docs_pack_id,
        autonomy_level=AutonomyLevel.VALIDITY_EXECUTION,
    )
    unconstrained = harness.attach_artifacts(
        unconstrained,
        "BranchSpec",
        "ModelRun",
        "CVResult",
        "BacktestResult",
    )
    constrained = harness.attach_artifacts(
        constrained,
        "BranchSpec",
        "ModelRun",
        "CVResult",
        "BacktestResult",
    )
    unconstrained = harness.select_final_branch(unconstrained, unconstrained.branches[0].branch_id)
    constrained = harness.select_final_branch(constrained, constrained.branches[0].branch_id)
    unconstrained = harness.run_lint(
        replace(unconstrained, prior_holdout_access=True, cv_contract_valid=False)
    )
    constrained = harness.run_lint(constrained)

    comparison = build_benchmark_comparison(
        pack,
        pack.tasks[0],
        unconstrained,
        constrained,
        unconstrained_receipt=SubmissionReceipt(
            submission_id="sub-u",
            trial_id="trial-u",
            branch_id=unconstrained.final_branch_id or "",
            accepted=False,
            rejected_reason="holdout_access",
            holdout_release_status="withheld",
        ),
        constrained_receipt=SubmissionReceipt(
            submission_id="sub-c",
            trial_id="trial-c",
            branch_id=constrained.final_branch_id or "",
            accepted=True,
            rejected_reason=None,
            holdout_release_status="released",
        ),
    )

    assert comparison.methodology_delta.prevented_failure_count >= 2
    assert pack.host_adapter.adapter_id in comparison.headline
