from __future__ import annotations

import json

from ml4t.agent._benchmark import (
    MethodologyFailureMode,
    build_default_etf_benchmark_pack,
    load_etf_benchmark,
)


def _benchmark_definition(tmp_path):
    config_dir = tmp_path / "config"
    training_dir = config_dir / "training"
    backtest_dir = config_dir / "backtest"
    training_dir.mkdir(parents=True)
    backtest_dir.mkdir(parents=True)
    (config_dir / "setup.yaml").write_text(
        "\n".join(
            [
                "strategy_id: etfs",
                "setup_version: v1",
                "mapping:",
                "  sizing: equal_weight",
                "labels:",
                "  primary: fwd_ret_21d",
                "  variants:",
                "    - fwd_ret_5d",
                "evaluation:",
                "  holdout_start: '2024-01-01'",
                "  holdout_end: '2025-12-31'",
            ]
        )
        + "\n"
    )
    (training_dir / "fwd_ret_21d.yaml").write_text(
        "\n".join(
            [
                "linear:",
                "  - ols",
                "  - ridge_a0.1",
                "gbm:",
                "  - default_mse",
                "  - default_huber",
                "tabular_dl:",
                "  - tabm_s",
                "latent_factors:",
                "  - pca",
            ]
        )
        + "\n"
    )
    (config_dir / "cv_config.json").write_text(
        json.dumps(
            {
                "n_splits": 8,
                "train_size": "10Y",
                "test_size": "1Y",
                "embargo_td": "P21D",
                "label_horizon": "P21D",
                "calendar_id": "NYSE",
            }
        )
    )
    (backtest_dir / "base.yaml").write_text("execution:\n  execution_price: open\n")
    (tmp_path / "README.md").write_text("# ETF case study\n")
    return load_etf_benchmark(tmp_path)


def test_build_default_etf_benchmark_pack(tmp_path) -> None:
    definition = _benchmark_definition(tmp_path)

    pack = build_default_etf_benchmark_pack(definition)

    assert pack.pack_id == "etf_research_benchmark_pack"
    assert pack.docs_pack.docs_pack_id == "etf_docs_pack_v0"
    assert pack.host_adapter.adapter_id == "claude_code_headless"
    assert len(pack.tasks) == 1
    task = pack.tasks[0]
    assert task.task_id == "etf_contract_execution_and_selection"
    assert "holdout_window" in task.workflow_surface_policy.fixed_surfaces
    assert "model_bundle" in task.workflow_surface_policy.selectable_surfaces
    assert any(
        expectation.failure_mode == MethodologyFailureMode.HOLDOUT_MISUSE
        for expectation in task.methodology_delta_spec.expectations
    )
