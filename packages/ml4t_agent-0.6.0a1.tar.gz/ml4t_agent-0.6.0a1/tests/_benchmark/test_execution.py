from __future__ import annotations

import sys
from types import ModuleType
from typing import Any, cast

from ml4t.agent._benchmark import ExecutionAdapterError, Ml4tExecutionAdapters


def test_execution_adapters_dispatch_to_available_modules(monkeypatch) -> None:
    engineer = ModuleType("ml4t.engineer")
    diagnostic = ModuleType("ml4t.diagnostic")
    backtest_runner = ModuleType("case_studies.utils.backtest_runner")

    cast(Any, engineer).compute_features = lambda data, features: ("features", data, features)
    cast(Any, diagnostic).validated_cross_val_score = lambda estimator, X, y, **kwargs: (
        "cv",
        estimator,
        X,
        y,
        kwargs["config"],
    )
    cast(Any, backtest_runner).run_backtest = lambda **kwargs: ("backtest", kwargs["case_study"])

    monkeypatch.setitem(sys.modules, "ml4t.engineer", engineer)
    monkeypatch.setitem(sys.modules, "ml4t.diagnostic", diagnostic)
    monkeypatch.setitem(sys.modules, "case_studies.utils.backtest_runner", backtest_runner)

    adapters = Ml4tExecutionAdapters()

    assert adapters.compute_features("data", ["rsi"]) == ("features", "data", ["rsi"])
    assert adapters.validated_cross_val_score("est", "X", "y", config="cfg") == (
        "cv",
        "est",
        "X",
        "y",
        "cfg",
    )
    assert adapters.run_case_study_backtest(case_study="etfs") == ("backtest", "etfs")


def test_execution_adapters_raise_clear_error_when_module_missing(monkeypatch) -> None:
    def _fail(name: str) -> ModuleType:
        raise ImportError(f"simulated: {name} not installed")

    monkeypatch.setattr("ml4t.agent._benchmark.execution.import_module", _fail)

    adapters = Ml4tExecutionAdapters()

    try:
        adapters.compute_features("data", ["rsi"])
    except ExecutionAdapterError as exc:
        assert "ml4t.engineer" in str(exc)
    else:
        raise AssertionError("expected ExecutionAdapterError")
