from __future__ import annotations

from ml4t.agent._benchmark import (
    ActionManifest,
    AutonomyLevel,
    BenchmarkTask,
    EnvironmentManifest,
    FailureExpectation,
    MethodologyDeltaSpec,
    MethodologyFailureMode,
    TrialContext,
    TrialState,
    WorkflowSurfacePolicy,
    evaluate_methodology_delta,
)


def _task() -> BenchmarkTask:
    return BenchmarkTask(
        task_id="task-1",
        title="Task",
        prompt_brief="Do the workflow correctly.",
        workflow_surface_policy=WorkflowSurfacePolicy(
            fixed_surfaces=("holdout_window",),
            selectable_surfaces=("label",),
            editable_surfaces=("repair_actions",),
            sealed_surfaces=("holdout_data",),
        ),
        required_artifact_types=("TrialContext", "LintReport"),
        methodology_delta_spec=MethodologyDeltaSpec(
            delta_id="delta-1",
            title="Delta",
            expectations=(
                FailureExpectation(
                    failure_mode=MethodologyFailureMode.HOLDOUT_MISUSE,
                    unconstrained_signal="prior_holdout_access true or rule_3 fail",
                    harness_rule_ids=("rule_3",),
                ),
                FailureExpectation(
                    failure_mode=MethodologyFailureMode.FOLD_BOUNDARY_VIOLATION,
                    unconstrained_signal="cv_contract_valid false or rule_2 fail",
                    harness_rule_ids=("rule_2",),
                ),
            ),
        ),
    )


def _environment() -> EnvironmentManifest:
    return EnvironmentManifest(
        environment_id="etf_daily_v0",
        manifest_version="v1",
        holdout_start="2024-01-01",
        holdout_end="2025-12-31",
        allowed_labels=("fwd_ret_21d",),
        allowed_feature_regimes=("financial_only",),
        allowed_model_bundles=("linear_baseline",),
    )


def _action_manifest() -> ActionManifest:
    return ActionManifest(
        manifest_version="v1",
        allowed_labels=("fwd_ret_21d",),
        allowed_feature_regimes=("financial_only",),
        allowed_model_bundles=("linear_baseline",),
    )


def _context(trial_id: str) -> TrialContext:
    return TrialContext(
        trial_id=trial_id,
        cell_id="cell-1",
        trace_id=f"trace-{trial_id}",
        benchmark_seed=1,
        environment_id="etf_daily_v0",
        environment_version="v1",
        action_manifest_version="v1",
        autonomy_policy_version="v0",
        stats_protocol_version="v1",
        runtime_id="plain_python",
        model_id="frontier-model",
        model_version="1",
        docs_pack_id="docs-v1",
        autonomy_level=AutonomyLevel.VALIDITY_EXECUTION,
    )


def test_methodology_delta_report_counts_prevented_failures() -> None:
    unconstrained = TrialState(
        context=_context("trial-a"),
        environment=_environment(),
        action_manifest=_action_manifest(),
        branches=(),
        final_branch_id=None,
        prior_holdout_access=True,
        cv_contract_valid=False,
    )
    constrained = TrialState(
        context=_context("trial-b"),
        environment=_environment(),
        action_manifest=_action_manifest(),
        branches=(),
        final_branch_id=None,
        prior_holdout_access=False,
        cv_contract_valid=True,
    )

    report = evaluate_methodology_delta(_task(), unconstrained, constrained)

    assert report.valid_comparison is True
    assert report.unconstrained_failure_count == 2
    assert report.constrained_failure_count == 0
    assert report.prevented_failure_count == 2
    assert report.residual_failure_count == 0
    assert "prevented 2 of 2" in report.summary
