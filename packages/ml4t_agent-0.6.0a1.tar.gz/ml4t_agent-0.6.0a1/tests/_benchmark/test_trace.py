from ml4t.agent._benchmark import (
    ActionManifest,
    AutonomyLevel,
    BranchSpec,
    BranchTrace,
    EnvironmentManifest,
    TraceEvent,
    TraceEventType,
    TraceValidator,
    TrialContext,
    TrialState,
)


def _environment() -> EnvironmentManifest:
    return EnvironmentManifest(
        environment_id="etf_daily_v0",
        manifest_version="v1",
        holdout_start="2024-01-01",
        holdout_end="2025-12-31",
        allowed_labels=("fwd_ret_21d", "fwd_ret_5d"),
        allowed_feature_regimes=("financial_only", "financial_plus_temporal"),
        allowed_model_bundles=("linear_baseline", "gbm_default", "tabular_dl_small"),
        allowed_top_n=(5, 10, 15),
    )


def _action_manifest() -> ActionManifest:
    return ActionManifest(
        manifest_version="v1",
        allowed_labels=("fwd_ret_21d", "fwd_ret_5d"),
        allowed_feature_regimes=("financial_only", "financial_plus_temporal"),
        allowed_model_bundles=("linear_baseline", "gbm_default", "tabular_dl_small"),
    )


def _context() -> TrialContext:
    return TrialContext(
        trial_id="trial-1",
        cell_id="cell-1",
        trace_id="trace-1",
        benchmark_seed=7,
        environment_id="etf_daily_v0",
        environment_version="v1",
        action_manifest_version="v1",
        autonomy_policy_version="v0",
        stats_protocol_version="v1",
        runtime_id="plain_python",
        model_id="frontier-model",
        model_version="1",
        docs_pack_id="docs-v1",
        autonomy_level=AutonomyLevel.COMMIT_BEFORE_FEEDBACK,
    )


def test_trace_validator_accepts_minimal_valid_pre_submission_trace() -> None:
    branch = BranchTrace(
        branch_id="branch-1",
        branch_spec=BranchSpec(
            label="fwd_ret_21d",
            feature_regime="financial_only",
            model_bundle="linear_baseline",
        ),
        committed=True,
    )
    state = TrialState(
        context=_context(),
        environment=_environment(),
        action_manifest=_action_manifest(),
        branches=(branch,),
        final_branch_id="branch-1",
        events=(
            TraceEvent(
                event_id="evt:1",
                event_type=TraceEventType.TRIAL_STARTED,
                trial_id="trial-1",
                trace_id="trace-1",
            ),
            TraceEvent(
                event_id="evt:2",
                event_type=TraceEventType.BRANCH_CREATED,
                trial_id="trial-1",
                trace_id="trace-1",
                branch_id="branch-1",
            ),
            TraceEvent(
                event_id="evt:3",
                event_type=TraceEventType.BRANCH_SELECTED_FINAL,
                trial_id="trial-1",
                trace_id="trace-1",
                branch_id="branch-1",
            ),
        ),
    )

    result = TraceValidator().validate(state)

    assert result.valid is True


def test_trace_validator_rejects_missing_branch_created_event() -> None:
    branch = BranchTrace(
        branch_id="branch-1",
        branch_spec=BranchSpec(
            label="fwd_ret_21d",
            feature_regime="financial_only",
            model_bundle="linear_baseline",
        ),
        committed=True,
    )
    state = TrialState(
        context=_context(),
        environment=_environment(),
        action_manifest=_action_manifest(),
        branches=(branch,),
        final_branch_id="branch-1",
        events=(
            TraceEvent(
                event_id="evt:1",
                event_type=TraceEventType.TRIAL_STARTED,
                trial_id="trial-1",
                trace_id="trace-1",
            ),
            TraceEvent(
                event_id="evt:2",
                event_type=TraceEventType.BRANCH_SELECTED_FINAL,
                trial_id="trial-1",
                trace_id="trace-1",
                branch_id="branch-1",
            ),
        ),
    )

    result = TraceValidator().validate(state)

    assert result.valid is False
    assert result.reason == "missing branch_created event"
