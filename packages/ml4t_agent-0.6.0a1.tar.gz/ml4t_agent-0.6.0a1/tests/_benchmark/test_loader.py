from __future__ import annotations

import json

from ml4t.agent._benchmark import load_etf_benchmark


def test_load_etf_benchmark_derives_normalized_contract(tmp_path) -> None:
    config_dir = tmp_path / "config"
    training_dir = config_dir / "training"
    training_dir.mkdir(parents=True)
    (config_dir / "setup.yaml").write_text(
        "\n".join(
            [
                "strategy_id: etfs",
                "setup_version: v1",
                "mapping:",
                "  sizing: equal_weight",
                "labels:",
                "  primary: fwd_ret_21d",
                "  variants:",
                "    - fwd_ret_5d",
                "evaluation:",
                "  holdout_start: '2024-01-01'",
                "  holdout_end: '2025-12-31'",
            ]
        )
        + "\n"
    )
    (training_dir / "fwd_ret_21d.yaml").write_text(
        "\n".join(
            [
                "linear:",
                "  - ols",
                "  - ridge_a0.1",
                "gbm:",
                "  - default_mse",
                "  - default_huber",
                "tabular_dl:",
                "  - tabm_s",
                "latent_factors:",
                "  - pca",
            ]
        )
        + "\n"
    )
    (config_dir / "cv_config.json").write_text(
        json.dumps(
            {
                "n_splits": 8,
                "train_size": "10Y",
                "test_size": "1Y",
                "embargo_td": "P21D",
                "label_horizon": "P21D",
                "calendar_id": "NYSE",
            }
        )
    )

    definition = load_etf_benchmark(tmp_path)

    assert definition.environment.environment_id == "etf_daily_v0"
    assert definition.action_manifest.allowed_model_bundles == (
        "linear_baseline",
        "gbm_default",
        "tabular_dl_small",
        "latent_factor_pca",
    )
    assert definition.canonical_branch.label == "fwd_ret_21d"
    assert definition.canonical_branch.model_bundle == "linear_baseline"
