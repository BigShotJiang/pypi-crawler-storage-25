from __future__ import annotations

import json
import subprocess
from pathlib import Path

from ml4t.agent._benchmark import (
    STAGE_MANIFEST_FILE_NAME,
    AutonomyLevel,
    BenchmarkCondition,
    ClaudeCodeHeadlessAdapter,
    HostRunRequest,
    HostRunResult,
    build_condition_prompt,
    build_default_etf_benchmark_pack,
    build_host_run_request,
    load_etf_benchmark,
    read_stage_manifest,
    run_kill_test_trial,
    stage_case_study_repo,
)
from ml4t.agent._benchmark.harness import ETFBenchmarkHarness
from ml4t.agent._benchmark.kill_test import main


def _repo_fixture(tmp_path: Path) -> tuple[Path, Path]:
    repo_root = tmp_path / "repo"
    case_root = repo_root / "case_studies" / "etfs"
    config_dir = case_root / "config"
    training_dir = config_dir / "training"
    backtest_dir = config_dir / "backtest"
    training_dir.mkdir(parents=True)
    backtest_dir.mkdir(parents=True)
    (repo_root / "case_studies" / "utils").mkdir(parents=True)
    (repo_root / "utils").mkdir(parents=True)
    (repo_root / "data" / "etfs" / "market").mkdir(parents=True)
    (repo_root / "pyproject.toml").write_text("[project]\nname='ml4t-code'\n", encoding="utf-8")
    (repo_root / "uv.lock").write_text("", encoding="utf-8")
    (repo_root / "case_studies" / "utils" / "__init__.py").write_text("", encoding="utf-8")
    (repo_root / "utils" / "__init__.py").write_text("", encoding="utf-8")
    (repo_root / "utils" / "paths.py").write_text(
        "from pathlib import Path\n"
        "def get_case_study_dir(case_study_id: str) -> Path:\n"
        "    return Path(__file__).resolve().parents[1] / 'case_studies' / case_study_id\n",
        encoding="utf-8",
    )
    (repo_root / "data" / "__init__.py").write_text(
        "from data.etfs.loader import load_etfs, list_etfs\n",
        encoding="utf-8",
    )
    (repo_root / "data" / "exceptions.py").write_text(
        "class DataNotFoundError(FileNotFoundError):\n"
        "    pass\n"
        "class DownloadError(RuntimeError):\n"
        "    pass\n"
        "class MissingDependencyError(ImportError):\n"
        "    pass\n",
        encoding="utf-8",
    )
    (repo_root / "data" / "etfs" / "README.md").write_text("ETF data\n", encoding="utf-8")
    (repo_root / "data" / "etfs" / "loader.py").write_text(
        "def list_etfs() -> list[str]:\n"
        "    return ['SPY']\n"
        "def load_etfs(*args, **kwargs):\n"
        "    return None\n",
        encoding="utf-8",
    )
    (repo_root / "data" / "etfs" / "market" / "config.yaml").write_text("{}", encoding="utf-8")
    (case_root / "README.md").write_text("# ETF case study\n", encoding="utf-8")
    for script in (
        "01_setup.py",
        "02_labels.py",
        "03_financial_features.py",
        "06_linear.py",
        "14_backtest.py",
    ):
        (case_root / script).write_text("print('ok')\n", encoding="utf-8")
    (config_dir / "setup.yaml").write_text(
        "\n".join(
            [
                "strategy_id: etfs",
                "setup_version: v1",
                "mapping:",
                "  sizing: equal_weight",
                "labels:",
                "  primary: fwd_ret_21d",
                "  variants:",
                "    - fwd_ret_5d",
                "evaluation:",
                "  holdout_start: '2024-01-01'",
                "  holdout_end: '2025-12-31'",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    (training_dir / "fwd_ret_21d.yaml").write_text(
        "\n".join(
            [
                "linear:",
                "  - ols",
                "  - ridge_a0.1",
                "gbm:",
                "  - default_mse",
                "  - default_huber",
                "tabular_dl:",
                "  - tabm_s",
                "latent_factors:",
                "  - pca",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    (config_dir / "cv_config.json").write_text(
        json.dumps(
            {
                "n_splits": 8,
                "train_size": "10Y",
                "test_size": "1Y",
                "embargo_td": "P21D",
                "label_horizon": "P21D",
                "calendar_id": "NYSE",
            }
        ),
        encoding="utf-8",
    )
    (backtest_dir / "base.yaml").write_text(
        "execution:\n  execution_price: open\n", encoding="utf-8"
    )
    (case_root / "labels").mkdir()
    (case_root / "labels" / "stale.txt").write_text("stale\n", encoding="utf-8")
    (case_root / "features").mkdir()
    (case_root / "models").mkdir()
    (case_root / "results").mkdir()
    (case_root / "run_log").mkdir()
    (case_root / "evaluation").mkdir()
    return repo_root, case_root


def test_stage_case_study_repo_strips_derived_outputs(tmp_path: Path) -> None:
    _, case_root = _repo_fixture(tmp_path)
    definition = load_etf_benchmark(case_root)

    staged_repo_root, staged_case_root = stage_case_study_repo(definition, tmp_path / "trial")

    assert staged_repo_root.exists()
    assert (staged_case_root / "01_setup.py").exists()
    assert (staged_case_root / "labels").is_dir()
    assert not any((staged_case_root / "labels").iterdir())
    assert not any((staged_case_root / "features").iterdir())
    assert not any((staged_case_root / "run_log").iterdir())
    manifest = read_stage_manifest(staged_repo_root / STAGE_MANIFEST_FILE_NAME)
    assert manifest.case_study_root == str(staged_case_root)
    assert "run_log" in manifest.stripped_case_study_dirs
    assert str(staged_case_root / "results") in manifest.allowed_output_roots
    assert str(staged_case_root / "config" / "setup.yaml") in manifest.static_protocol_refs


def test_build_condition_prompt_separates_raw_and_constrained(tmp_path: Path) -> None:
    _, case_root = _repo_fixture(tmp_path)
    definition = load_etf_benchmark(case_root)
    pack = build_default_etf_benchmark_pack(definition)
    harness = ETFBenchmarkHarness.from_definition(definition)
    state = harness.new_trial(
        trial_id="trial-1",
        cell_id="cell-1",
        trace_id="trace-1",
        benchmark_seed=1,
        runtime_id="plain_python",
        model_id="frontier-model",
        model_version="1",
        docs_pack_id=pack.docs_pack.docs_pack_id,
        autonomy_level=AutonomyLevel.VALIDITY_EXECUTION,
    )
    request = build_host_run_request(
        pack,
        pack.tasks[0],
        state,
        policy=harness.policy,
        working_directory=str(tmp_path / "workdir"),
    )
    branch = state.branches[0].branch_spec

    raw_prompt = build_condition_prompt(
        request,
        task=pack.tasks[0],
        branch=branch,
        branch_hash=branch.branch_hash(),
        condition=BenchmarkCondition.RAW,
        source_repo_root=case_root.parents[1],
        staged_repo_root=tmp_path / "staged",
        workflow_scripts=("01_setup.py", "02_labels.py"),
    )
    constrained_prompt = build_condition_prompt(
        request,
        task=pack.tasks[0],
        branch=branch,
        branch_hash=branch.branch_hash(),
        condition=BenchmarkCondition.CONSTRAINED,
        source_repo_root=case_root.parents[1],
        staged_repo_root=tmp_path / "staged",
        workflow_scripts=("01_setup.py", "02_labels.py"),
    )

    assert "ordinary repo access" in raw_prompt
    assert "holdout results before the final submission attempt" in constrained_prompt
    assert "Construct the workflow outputs" in raw_prompt
    assert "01_setup.py" in constrained_prompt


def test_claude_adapter_reads_result_payload(monkeypatch, tmp_path: Path) -> None:
    _, case_root = _repo_fixture(tmp_path / "src")
    definition = load_etf_benchmark(case_root)
    workdir, _ = stage_case_study_repo(definition, tmp_path / "trial")
    request = HostRunRequest(
        pack_id="pack-1",
        task_id="task-1",
        trial_id="trial-1",
        prompt_brief="do the thing",
        docs_pack_id="docs-1",
        document_refs=(),
        skill_refs=(),
        working_directory=str(workdir),
        autonomy_level=AutonomyLevel.VALIDITY_EXECUTION,
        selectable_surfaces=(),
        sealed_surfaces=(),
    )

    def fake_run(command, cwd, env, capture_output, text, timeout, check):
        Path(cwd, "ml4t_host_result.json").write_text(
            json.dumps(
                {
                    "summary": "ok",
                    "emitted_artifact_types": ["ModelRun", "CVResult", "BacktestResult"],
                    "observed_branch_hashes": ["branch-hash"],
                    "prior_holdout_access": False,
                    "as_of_valid": True,
                    "cv_contract_valid": True,
                    "cost_contract_valid": True,
                    "trace_valid": True,
                    "notes": ["clean"],
                }
            ),
            encoding="utf-8",
        )
        Path(cwd, "case_studies", "etfs", "results", "submission.json").write_text(
            "{}",
            encoding="utf-8",
        )
        return subprocess.CompletedProcess(command, 0, "stdout", "")

    monkeypatch.setattr(subprocess, "run", fake_run)
    adapter = ClaudeCodeHeadlessAdapter(
        spec=build_default_etf_benchmark_pack(definition).host_adapter
    )

    result = adapter.run(request)

    assert result.success is True
    assert result.summary == "ok"
    assert result.emitted_artifact_types == ("ModelRun", "CVResult", "BacktestResult")
    assert result.metadata["trace_valid"] is True


def test_claude_adapter_flags_unexpected_writes(monkeypatch, tmp_path: Path) -> None:
    _, case_root = _repo_fixture(tmp_path / "src")
    definition = load_etf_benchmark(case_root)
    workdir, _ = stage_case_study_repo(definition, tmp_path / "trial")
    request = HostRunRequest(
        pack_id="pack-1",
        task_id="task-1",
        trial_id="trial-1",
        prompt_brief="do the thing",
        docs_pack_id="docs-1",
        document_refs=(),
        skill_refs=(),
        working_directory=str(workdir),
        autonomy_level=AutonomyLevel.VALIDITY_EXECUTION,
        selectable_surfaces=(),
        sealed_surfaces=(),
    )

    def fake_run(command, cwd, env, capture_output, text, timeout, check):
        Path(cwd, "ml4t_host_result.json").write_text(
            json.dumps(
                {
                    "summary": "ok",
                    "emitted_artifact_types": ["ModelRun"],
                    "observed_branch_hashes": ["branch-hash"],
                    "prior_holdout_access": False,
                    "as_of_valid": True,
                    "cv_contract_valid": True,
                    "cost_contract_valid": True,
                    "trace_valid": True,
                    "notes": [],
                }
            ),
            encoding="utf-8",
        )
        Path(cwd, "case_studies", "etfs", "01_setup.py").write_text(
            "print('mutated')\n", encoding="utf-8"
        )
        return subprocess.CompletedProcess(command, 0, "stdout", "")

    monkeypatch.setattr(subprocess, "run", fake_run)
    adapter = ClaudeCodeHeadlessAdapter(
        spec=build_default_etf_benchmark_pack(definition).host_adapter
    )

    result = adapter.run(request)

    assert result.metadata["trace_valid"] is False
    assert result.metadata["unexpected_write_paths"] == ["case_studies/etfs/01_setup.py"]


def test_run_kill_test_trial_uses_host_emitted_artifacts(tmp_path: Path) -> None:
    _, case_root = _repo_fixture(tmp_path)
    definition = load_etf_benchmark(case_root)
    pack = build_default_etf_benchmark_pack(definition)

    class StubAdapter:
        spec = pack.host_adapter

        def run(self, request: HostRunRequest) -> HostRunResult:
            return HostRunResult(
                adapter_id=self.spec.adapter_id,
                trial_id=request.trial_id,
                success=True,
                summary="completed",
                emitted_artifact_types=("ModelRun", "CVResult", "BacktestResult"),
                metadata={
                    "prior_holdout_access": False,
                    "as_of_valid": True,
                    "cv_contract_valid": True,
                    "cost_contract_valid": True,
                    "trace_valid": True,
                },
            )

    result = run_kill_test_trial(
        definition,
        condition=BenchmarkCondition.CONSTRAINED,
        trial_id="trial-1",
        benchmark_seed=1,
        model_id="frontier-model",
        model_version="1",
        runs_root=tmp_path / "runs",
        adapter=StubAdapter(),
        pack=pack,
    )

    assert result.receipt.accepted is True
    assert result.report.valid_submission is True
    assert "BranchSpec" in result.state.emitted_artifact_types
    assert "ModelRun" in result.state.emitted_artifact_types


def test_kill_test_main_supports_single_condition(monkeypatch, tmp_path: Path, capsys) -> None:
    _, case_root = _repo_fixture(tmp_path)

    class StubAdapter:
        def __init__(self, *args, **kwargs) -> None:
            pass

        def run(self, request: HostRunRequest) -> HostRunResult:
            return HostRunResult(
                adapter_id="claude_code_headless",
                trial_id=request.trial_id,
                success=True,
                summary="completed",
                emitted_artifact_types=("ModelRun", "CVResult", "BacktestResult"),
                metadata={
                    "prior_holdout_access": False,
                    "as_of_valid": True,
                    "cv_contract_valid": True,
                    "cost_contract_valid": True,
                    "trace_valid": True,
                },
            )

    monkeypatch.setattr("ml4t.agent._benchmark.kill_test.ClaudeCodeHeadlessAdapter", StubAdapter)

    exit_code = main(
        [
            "--case-study-root",
            str(case_root),
            "--runs-root",
            str(tmp_path / "runs"),
            "--condition",
            "constrained",
        ]
    )

    captured = capsys.readouterr()
    assert exit_code == 0
    assert "constrained: host_success=True valid_submission=True trace_valid=True" in captured.out
