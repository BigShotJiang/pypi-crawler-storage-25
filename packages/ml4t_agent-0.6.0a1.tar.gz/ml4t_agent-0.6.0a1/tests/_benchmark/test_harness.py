from __future__ import annotations

import json

from ml4t.agent._benchmark import (
    AutonomyLevel,
    BranchSpec,
    ETFBenchmarkHarness,
    ETFCaseStudyRuntime,
    TraceEventType,
    load_etf_benchmark,
)


def _benchmark_definition(tmp_path):
    config_dir = tmp_path / "config"
    training_dir = config_dir / "training"
    training_dir.mkdir(parents=True)
    (config_dir / "setup.yaml").write_text(
        "\n".join(
            [
                "strategy_id: etfs",
                "setup_version: v1",
                "mapping:",
                "  sizing: equal_weight",
                "labels:",
                "  primary: fwd_ret_21d",
                "  variants:",
                "    - fwd_ret_5d",
                "evaluation:",
                "  holdout_start: '2024-01-01'",
                "  holdout_end: '2025-12-31'",
            ]
        )
        + "\n"
    )
    (training_dir / "fwd_ret_21d.yaml").write_text(
        "\n".join(
            [
                "linear:",
                "  - ols",
                "  - ridge_a0.1",
                "gbm:",
                "  - default_mse",
                "  - default_huber",
                "tabular_dl:",
                "  - tabm_s",
                "latent_factors:",
                "  - pca",
            ]
        )
        + "\n"
    )
    (config_dir / "cv_config.json").write_text(
        json.dumps(
            {
                "n_splits": 8,
                "train_size": "10Y",
                "test_size": "1Y",
                "embargo_td": "P21D",
                "label_horizon": "P21D",
                "calendar_id": "NYSE",
            }
        )
    )
    return load_etf_benchmark(tmp_path)


def test_level_1_trial_uses_canonical_branch(tmp_path) -> None:
    harness = ETFBenchmarkHarness.from_definition(_benchmark_definition(tmp_path))

    state = harness.new_trial(
        trial_id="trial-1",
        cell_id="cell-1",
        trace_id="trace-1",
        benchmark_seed=1,
        runtime_id="plain_python",
        model_id="frontier-model",
        model_version="1",
        docs_pack_id="docs-v1",
        autonomy_level=AutonomyLevel.VALIDITY_EXECUTION,
    )

    assert len(state.branches) == 1
    assert state.branches[0].branch_spec.model_bundle == "linear_baseline"
    assert state.final_branch_id == state.branches[0].branch_id


def test_level_3_trial_can_branch_and_submit(tmp_path) -> None:
    harness = ETFBenchmarkHarness.from_definition(_benchmark_definition(tmp_path))
    runtime = ETFCaseStudyRuntime.from_definition(harness.definition, repo_root=tmp_path)
    state = harness.new_trial(
        trial_id="trial-2",
        cell_id="cell-1",
        trace_id="trace-2",
        benchmark_seed=2,
        runtime_id="plain_python",
        model_id="frontier-model",
        model_version="1",
        docs_pack_id="docs-v1",
        autonomy_level=AutonomyLevel.ITERATE_ON_FEEDBACK,
    )
    state = harness.add_branch(
        state,
        BranchSpec(
            label="fwd_ret_21d",
            feature_regime="financial_only",
            model_bundle="linear_baseline",
            top_n=10,
        ),
        validation_utility=0.4,
    )
    state = harness.add_branch(
        state,
        BranchSpec(
            label="fwd_ret_21d",
            feature_regime="financial_plus_temporal",
            model_bundle="gbm_default",
            top_n=15,
            parent_branch_id=state.branches[0].branch_id,
        ),
        validation_utility=0.8,
    )
    labels_dir = tmp_path / "labels"
    features_dir = tmp_path / "features"
    backtest_dir = tmp_path / "config" / "backtest"
    run_log_dir = tmp_path / "run_log"
    labels_dir.mkdir(exist_ok=True)
    features_dir.mkdir(exist_ok=True)
    backtest_dir.mkdir(parents=True, exist_ok=True)
    run_log_dir.mkdir(exist_ok=True)
    (labels_dir / "fwd_ret_21d.parquet").write_text("")
    (features_dir / "financial.parquet").write_text("")
    (features_dir / "model_based.parquet").write_text("")
    (backtest_dir / "base.yaml").write_text("execution:\n  execution_price: open\n")
    (run_log_dir / "registry.db").write_text("")
    state = harness.attach_case_study_inventory(
        state, runtime, branch_id=state.branches[1].branch_id
    )
    state = harness.select_final_branch(state, state.branches[1].branch_id)

    submitted_state, receipt, report = harness.submit(
        state,
        holdout_metrics={"net_sharpe": 1.1},
    )

    assert submitted_state.submission_attempt_count == 1
    assert receipt.accepted is True
    assert report.valid_submission is True
    assert report.delta_initial_to_final_validation == 0.4
    assert submitted_state.events[0].event_type == TraceEventType.TRIAL_STARTED
    assert submitted_state.events[-1].event_type == TraceEventType.TRIAL_COMPLETED
