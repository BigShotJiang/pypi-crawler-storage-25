from ml4t.agent._benchmark import (
    ActionManifest,
    AutonomyLevel,
    AutonomyPolicy,
    BranchSpec,
    BranchTrace,
    EnvironmentManifest,
    LintReport,
    LintRuleResult,
    SubmissionGateway,
    SubmissionRequest,
    TrialContext,
    TrialState,
)


def _environment() -> EnvironmentManifest:
    return EnvironmentManifest(
        environment_id="etf_daily_v0",
        manifest_version="v1",
        holdout_start="2024-01-01",
        holdout_end="2025-12-31",
        allowed_labels=("fwd_ret_21d", "fwd_ret_5d"),
        allowed_feature_regimes=("financial_only", "financial_plus_temporal"),
        allowed_model_bundles=("linear_baseline", "gbm_default", "tabular_dl_small"),
        allowed_top_n=(5, 10, 15),
    )


def _action_manifest() -> ActionManifest:
    return ActionManifest(
        manifest_version="v1",
        allowed_labels=("fwd_ret_21d", "fwd_ret_5d"),
        allowed_feature_regimes=("financial_only", "financial_plus_temporal"),
        allowed_model_bundles=("linear_baseline", "gbm_default", "tabular_dl_small"),
    )


def _context(level: AutonomyLevel) -> TrialContext:
    return TrialContext(
        trial_id="trial-1",
        cell_id="cell-1",
        trace_id="trace-1",
        benchmark_seed=7,
        environment_id="etf_daily_v0",
        environment_version="v1",
        action_manifest_version="v1",
        autonomy_policy_version="v0",
        stats_protocol_version="v1",
        runtime_id="plain_python",
        model_id="frontier-model",
        model_version="1",
        docs_pack_id="docs-v1",
        autonomy_level=level,
    )


def _passing_lint() -> LintReport:
    return LintReport(
        lint_run_id="lint-1",
        status="pass",
        rules_run=("rule_1",),
        results=(
            LintRuleResult(
                rule_id="rule_1",
                status="pass",
                severity="error",
                message="ok",
            ),
        ),
    )


def _trial_state(level: AutonomyLevel = AutonomyLevel.COMMIT_BEFORE_FEEDBACK) -> TrialState:
    branch = BranchTrace(
        branch_id="branch-1",
        branch_spec=BranchSpec(
            label="fwd_ret_21d",
            feature_regime="financial_only",
            model_bundle="linear_baseline",
        ),
        committed=True,
        validation_observed=True,
    )
    return TrialState(
        context=_context(level),
        environment=_environment(),
        action_manifest=_action_manifest(),
        branches=(branch,),
        final_branch_id="branch-1",
        emitted_artifact_types=frozenset(
            {
                "TrialContext",
                "EnvironmentSpec",
                "ActionMenu",
                "BranchSpec",
                "ModelRun",
                "CVResult",
                "BacktestResult",
                "LintReport",
            }
        ),
        lint_report=_passing_lint(),
    )


def test_gateway_accepts_valid_submission() -> None:
    gateway = SubmissionGateway(policy=AutonomyPolicy())
    state = _trial_state()
    request = SubmissionRequest(
        trial_id="trial-1",
        branch_id="branch-1",
        branch_spec_hash=state.branches[0].branch_spec.branch_hash(),
        lint_run_id="lint-1",
        required_artifact_types=(
            "TrialContext",
            "EnvironmentSpec",
            "ActionMenu",
            "BranchSpec",
            "ModelRun",
            "CVResult",
            "BacktestResult",
            "LintReport",
        ),
    )

    receipt = gateway.submit(request, state, holdout_metrics={"net_sharpe": 1.2})

    assert receipt.accepted is True
    assert receipt.holdout_release_status == "released"
    assert receipt.holdout_metrics_if_released["net_sharpe"] == 1.2


def test_gateway_rejects_missing_lint() -> None:
    gateway = SubmissionGateway(policy=AutonomyPolicy())
    state = _trial_state()
    state = TrialState(
        context=state.context,
        environment=state.environment,
        action_manifest=state.action_manifest,
        branches=state.branches,
        final_branch_id=state.final_branch_id,
        emitted_artifact_types=state.emitted_artifact_types,
        lint_report=None,
    )
    request = SubmissionRequest(
        trial_id="trial-1",
        branch_id="branch-1",
        branch_spec_hash=state.branches[0].branch_spec.branch_hash(),
        lint_run_id="lint-1",
        required_artifact_types=("TrialContext",),
    )

    receipt = gateway.submit(request, state)

    assert receipt.accepted is False
    assert receipt.rejected_reason == "missing_lint_report"


def test_gateway_rejects_reused_submission_slot() -> None:
    gateway = SubmissionGateway(policy=AutonomyPolicy())
    state = _trial_state()
    state = TrialState(
        context=state.context,
        environment=state.environment,
        action_manifest=state.action_manifest,
        branches=state.branches,
        final_branch_id=state.final_branch_id,
        submission_attempt_count=1,
        emitted_artifact_types=state.emitted_artifact_types,
        lint_report=state.lint_report,
    )
    request = SubmissionRequest(
        trial_id="trial-1",
        branch_id="branch-1",
        branch_spec_hash=state.branches[0].branch_spec.branch_hash(),
        lint_run_id="lint-1",
        required_artifact_types=("TrialContext",),
    )

    receipt = gateway.submit(request, state)

    assert receipt.accepted is False
    assert receipt.rejected_reason == "submission_already_consumed"
