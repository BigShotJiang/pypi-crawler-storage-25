from ml4t.agent._benchmark import (
    ActionManifest,
    AutonomyLevel,
    BranchSpec,
    BranchTrace,
    EnvironmentManifest,
    LintReport,
    LintRuleResult,
    SubmissionReceipt,
    TrialContext,
    TrialState,
    build_trial_report,
    summarize_cell,
)


def _environment() -> EnvironmentManifest:
    return EnvironmentManifest(
        environment_id="etf_daily_v0",
        manifest_version="v1",
        holdout_start="2024-01-01",
        holdout_end="2025-12-31",
        allowed_labels=("fwd_ret_21d", "fwd_ret_5d"),
        allowed_feature_regimes=("financial_only", "financial_plus_temporal"),
        allowed_model_bundles=("linear_baseline", "gbm_default", "tabular_dl_small"),
        allowed_top_n=(5, 10, 15),
    )


def _action_manifest() -> ActionManifest:
    return ActionManifest(
        manifest_version="v1",
        allowed_labels=("fwd_ret_21d", "fwd_ret_5d"),
        allowed_feature_regimes=("financial_only", "financial_plus_temporal"),
        allowed_model_bundles=("linear_baseline", "gbm_default", "tabular_dl_small"),
    )


def _context(seed: int, level: AutonomyLevel) -> TrialContext:
    return TrialContext(
        trial_id=f"trial-{seed}",
        cell_id="cell-1",
        trace_id=f"trace-{seed}",
        benchmark_seed=seed,
        environment_id="etf_daily_v0",
        environment_version="v1",
        action_manifest_version="v1",
        autonomy_policy_version="v0",
        stats_protocol_version="v1",
        runtime_id="plain_python",
        model_id="frontier-model",
        model_version="1",
        docs_pack_id="docs-v1",
        autonomy_level=level,
    )


def _lint() -> LintReport:
    return LintReport(
        lint_run_id="lint-1",
        status="pass",
        rules_run=("rule_1",),
        results=(
            LintRuleResult(
                rule_id="rule_1",
                status="pass",
                severity="error",
                message="ok",
            ),
        ),
    )


def test_build_trial_report_captures_level_3_delta() -> None:
    branches = (
        BranchTrace(
            branch_id="branch-1",
            branch_spec=BranchSpec(
                label="fwd_ret_21d",
                feature_regime="financial_only",
                model_bundle="linear_baseline",
            ),
            committed=True,
            validation_observed=True,
            repair_count=1,
            validation_utility=0.4,
        ),
        BranchTrace(
            branch_id="branch-2",
            branch_spec=BranchSpec(
                label="fwd_ret_21d",
                feature_regime="financial_plus_temporal",
                model_bundle="gbm_default",
                parent_branch_id="branch-1",
            ),
            validation_observed=True,
            repair_count=2,
            validation_utility=0.9,
        ),
    )
    state = TrialState(
        context=_context(7, AutonomyLevel.ITERATE_ON_FEEDBACK),
        environment=_environment(),
        action_manifest=_action_manifest(),
        branches=branches,
        final_branch_id="branch-2",
        lint_report=_lint(),
    )
    receipt = SubmissionReceipt(
        submission_id="submission-1",
        trial_id="trial-7",
        branch_id="branch-2",
        accepted=True,
        rejected_reason=None,
        holdout_release_status="released",
    )

    report = build_trial_report(state, receipt)

    assert report.valid_submission is True
    assert report.repair_count == 3
    assert report.delta_initial_to_final_validation == 0.5


def test_summarize_cell_aggregates_operational_rates() -> None:
    base_state = TrialState(
        context=_context(1, AutonomyLevel.COMMIT_BEFORE_FEEDBACK),
        environment=_environment(),
        action_manifest=_action_manifest(),
        branches=(
            BranchTrace(
                branch_id="branch-1",
                branch_spec=BranchSpec(
                    label="fwd_ret_21d",
                    feature_regime="financial_only",
                    model_bundle="linear_baseline",
                ),
                committed=True,
            ),
        ),
        final_branch_id="branch-1",
        lint_report=_lint(),
    )
    report_1 = build_trial_report(
        base_state,
        SubmissionReceipt(
            submission_id="submission-1",
            trial_id="trial-1",
            branch_id="branch-1",
            accepted=True,
            rejected_reason=None,
            holdout_release_status="released",
        ),
    )
    report_2 = build_trial_report(
        TrialState(
            context=_context(2, AutonomyLevel.COMMIT_BEFORE_FEEDBACK),
            environment=_environment(),
            action_manifest=_action_manifest(),
            branches=base_state.branches,
            final_branch_id="branch-1",
            lint_report=None,
            trace_valid=False,
        )
    )

    summary = summarize_cell([report_1, report_2])

    assert summary.trial_count == 2
    assert summary.valid_submission_rate == 0.5
    assert summary.lint_pass_rate == 0.5
    assert summary.trace_valid_rate == 0.5
