from __future__ import annotations

import json

from ml4t.agent._benchmark import (
    AutonomyLevel,
    AutonomyPolicy,
    HostRunResult,
    ReplayHostAdapter,
    TraceEventType,
    build_default_etf_benchmark_pack,
    build_host_run_request,
    load_etf_benchmark,
)
from ml4t.agent._benchmark.harness import ETFBenchmarkHarness


def _benchmark_definition(tmp_path):
    config_dir = tmp_path / "config"
    training_dir = config_dir / "training"
    backtest_dir = config_dir / "backtest"
    training_dir.mkdir(parents=True)
    backtest_dir.mkdir(parents=True)
    (config_dir / "setup.yaml").write_text(
        "\n".join(
            [
                "strategy_id: etfs",
                "setup_version: v1",
                "mapping:",
                "  sizing: equal_weight",
                "labels:",
                "  primary: fwd_ret_21d",
                "  variants:",
                "    - fwd_ret_5d",
                "evaluation:",
                "  holdout_start: '2024-01-01'",
                "  holdout_end: '2025-12-31'",
            ]
        )
        + "\n"
    )
    (training_dir / "fwd_ret_21d.yaml").write_text(
        "\n".join(
            [
                "linear:",
                "  - ols",
                "  - ridge_a0.1",
                "gbm:",
                "  - default_mse",
                "  - default_huber",
                "tabular_dl:",
                "  - tabm_s",
                "latent_factors:",
                "  - pca",
            ]
        )
        + "\n"
    )
    (config_dir / "cv_config.json").write_text(
        json.dumps(
            {
                "n_splits": 8,
                "train_size": "10Y",
                "test_size": "1Y",
                "embargo_td": "P21D",
                "label_horizon": "P21D",
                "calendar_id": "NYSE",
            }
        )
    )
    (backtest_dir / "base.yaml").write_text("execution:\n  execution_price: open\n")
    (tmp_path / "README.md").write_text("# ETF case study\n")
    return load_etf_benchmark(tmp_path)


def test_build_host_run_request_uses_pack_and_policy(tmp_path) -> None:
    definition = _benchmark_definition(tmp_path)
    pack = build_default_etf_benchmark_pack(definition)
    harness = ETFBenchmarkHarness.from_definition(definition)
    state = harness.new_trial(
        trial_id="trial-1",
        cell_id="cell-1",
        trace_id="trace-1",
        benchmark_seed=1,
        runtime_id="plain_python",
        model_id="frontier-model",
        model_version="1",
        docs_pack_id=pack.docs_pack.docs_pack_id,
        autonomy_level=AutonomyLevel.COMMIT_BEFORE_FEEDBACK,
    )

    request = build_host_run_request(
        pack,
        pack.tasks[0],
        state,
        policy=AutonomyPolicy(),
        working_directory="/tmp/etf-task",
    )

    assert request.pack_id == pack.pack_id
    assert request.task_id == pack.tasks[0].task_id
    assert request.docs_pack_id == pack.docs_pack.docs_pack_id
    assert request.selectable_surfaces == ("feature_regime", "label", "model_bundle")
    assert "holdout_data" in request.sealed_surfaces


def test_replay_host_adapter_returns_result_for_matching_trial(tmp_path) -> None:
    definition = _benchmark_definition(tmp_path)
    pack = build_default_etf_benchmark_pack(definition)
    harness = ETFBenchmarkHarness.from_definition(definition)
    state = harness.new_trial(
        trial_id="trial-7",
        cell_id="cell-1",
        trace_id="trace-7",
        benchmark_seed=7,
        runtime_id="plain_python",
        model_id="frontier-model",
        model_version="1",
        docs_pack_id=pack.docs_pack.docs_pack_id,
        autonomy_level=AutonomyLevel.VALIDITY_EXECUTION,
    )
    request = build_host_run_request(
        pack,
        pack.tasks[0],
        state,
        policy=AutonomyPolicy(),
        working_directory="/tmp/etf-task",
    )
    adapter = ReplayHostAdapter(
        spec=pack.host_adapter,
        result=HostRunResult(
            adapter_id=pack.host_adapter.adapter_id,
            trial_id="trial-7",
            success=True,
            summary="ok",
        ),
    )

    result = adapter.run(request)

    assert result.success is True
    assert result.trial_id == "trial-7"


def test_harness_records_host_request_and_result(tmp_path) -> None:
    definition = _benchmark_definition(tmp_path)
    pack = build_default_etf_benchmark_pack(definition)
    harness = ETFBenchmarkHarness.from_definition(definition)
    state = harness.new_trial(
        trial_id="trial-9",
        cell_id="cell-1",
        trace_id="trace-9",
        benchmark_seed=9,
        runtime_id="plain_python",
        model_id="frontier-model",
        model_version="1",
        docs_pack_id=pack.docs_pack.docs_pack_id,
        autonomy_level=AutonomyLevel.VALIDITY_EXECUTION,
    )
    request = build_host_run_request(
        pack,
        pack.tasks[0],
        state,
        policy=AutonomyPolicy(),
        working_directory="/tmp/etf-task",
    )
    state = harness.record_host_run_request(state, request)
    state = harness.record_host_run_result(
        state,
        HostRunResult(
            adapter_id=pack.host_adapter.adapter_id,
            trial_id="trial-9",
            success=True,
            summary="completed",
            emitted_artifact_types=("ModelRun", "CVResult"),
            observed_branch_hashes=(state.branches[0].branch_spec.branch_hash(),),
            trace_ref="/tmp/trace.json",
        ),
    )

    assert "ModelRun" in state.emitted_artifact_types
    assert state.events[-1].event_type == TraceEventType.HOST_RUN_RESULT_CAPTURED
