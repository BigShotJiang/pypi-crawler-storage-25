from __future__ import annotations

import json

from ml4t.agent._benchmark import BranchSpec, ETFCaseStudyRuntime, load_etf_benchmark


def _benchmark_definition(tmp_path):
    config_dir = tmp_path / "config"
    training_dir = config_dir / "training"
    backtest_dir = config_dir / "backtest"
    labels_dir = tmp_path / "labels"
    features_dir = tmp_path / "features"
    run_log_dir = tmp_path / "run_log"
    training_dir.mkdir(parents=True)
    backtest_dir.mkdir(parents=True)
    labels_dir.mkdir()
    features_dir.mkdir()
    run_log_dir.mkdir()
    (config_dir / "setup.yaml").write_text(
        "\n".join(
            [
                "strategy_id: etfs",
                "setup_version: v1",
                "mapping:",
                "  sizing: equal_weight",
                "labels:",
                "  primary: fwd_ret_21d",
                "  variants:",
                "    - fwd_ret_5d",
                "evaluation:",
                "  holdout_start: '2024-01-01'",
                "  holdout_end: '2025-12-31'",
            ]
        )
        + "\n"
    )
    (training_dir / "fwd_ret_21d.yaml").write_text(
        "\n".join(
            [
                "linear:",
                "  - ols",
                "  - ridge_a0.1",
                "gbm:",
                "  - default_mse",
                "  - default_huber",
                "tabular_dl:",
                "  - tabm_s",
                "latent_factors:",
                "  - pca",
            ]
        )
        + "\n"
    )
    (config_dir / "cv_config.json").write_text(
        json.dumps(
            {
                "n_splits": 8,
                "train_size": "10Y",
                "test_size": "1Y",
                "embargo_td": "P21D",
                "label_horizon": "P21D",
                "calendar_id": "NYSE",
            }
        )
    )
    (backtest_dir / "base.yaml").write_text("execution:\n  execution_price: open\n")
    (labels_dir / "fwd_ret_21d.parquet").write_text("")
    (features_dir / "financial.parquet").write_text("")
    (features_dir / "model_based.parquet").write_text("")
    (run_log_dir / "registry.db").write_text("")
    return load_etf_benchmark(tmp_path)


def test_runtime_resolves_inventory_for_temporal_branch(tmp_path) -> None:
    runtime = ETFCaseStudyRuntime.from_definition(
        _benchmark_definition(tmp_path), repo_root=tmp_path
    )
    branch = BranchSpec(
        label="fwd_ret_21d",
        feature_regime="financial_plus_temporal",
        model_bundle="gbm_default",
        top_n=15,
    )

    inventory = runtime.artifact_inventory(branch)

    assert inventory.label_path.name == "fwd_ret_21d.parquet"
    assert [path.name for path in inventory.feature_paths] == [
        "financial.parquet",
        "model_based.parquet",
    ]
    assert "FeatureSet" in inventory.existing_artifact_types()


def test_runtime_maps_branch_to_expected_scripts(tmp_path) -> None:
    runtime = ETFCaseStudyRuntime.from_definition(
        _benchmark_definition(tmp_path), repo_root=tmp_path
    )
    branch = BranchSpec(
        label="fwd_ret_21d",
        feature_regime="financial_plus_temporal",
        model_bundle="latent_factor_pca",
        top_n=10,
    )

    scripts = runtime.workflow_scripts_for_branch(branch)

    assert scripts[:3] == ("01_setup.py", "02_labels.py", "03_financial_features.py")
    assert "04_model_based_features.py" in scripts
    assert "11a_pca.py" in scripts
    assert scripts[-1] == "14_backtest.py"
