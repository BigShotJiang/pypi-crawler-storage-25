from ml4t.agent._benchmark import (
    ActionManifest,
    AutonomyLevel,
    AutonomyPolicy,
    BranchSpec,
    BranchTrace,
    EnvironmentManifest,
    TrialContext,
    TrialState,
)


def _environment() -> EnvironmentManifest:
    return EnvironmentManifest(
        environment_id="etf_daily_v0",
        manifest_version="v1",
        holdout_start="2024-01-01",
        holdout_end="2025-12-31",
        allowed_labels=("fwd_ret_21d", "fwd_ret_5d"),
        allowed_feature_regimes=("financial_only", "financial_plus_temporal"),
        allowed_model_bundles=("linear_baseline", "gbm_default", "tabular_dl_small"),
        allowed_top_n=(5, 10, 15),
    )


def _action_manifest() -> ActionManifest:
    return ActionManifest(
        manifest_version="v1",
        allowed_labels=("fwd_ret_21d", "fwd_ret_5d"),
        allowed_feature_regimes=("financial_only", "financial_plus_temporal"),
        allowed_model_bundles=("linear_baseline", "gbm_default", "tabular_dl_small"),
    )


def _context(level: AutonomyLevel) -> TrialContext:
    return TrialContext(
        trial_id="trial-1",
        cell_id="cell-1",
        trace_id="trace-1",
        benchmark_seed=7,
        environment_id="etf_daily_v0",
        environment_version="v1",
        action_manifest_version="v1",
        autonomy_policy_version="v0",
        stats_protocol_version="v1",
        runtime_id="plain_python",
        model_id="frontier-model",
        model_version="1",
        docs_pack_id="docs-v1",
        autonomy_level=level,
    )


def test_branch_hash_is_stable() -> None:
    branch = BranchSpec(
        label="fwd_ret_21d",
        feature_regime="financial_only",
        model_bundle="linear_baseline",
    )
    assert branch.branch_hash() == branch.branch_hash()


def test_level_2_rejects_non_default_top_n() -> None:
    policy = AutonomyPolicy()
    branch = BranchSpec(
        label="fwd_ret_21d",
        feature_regime="financial_only",
        model_bundle="linear_baseline",
        top_n=15,
    )

    try:
        policy.validate_branch_spec(
            AutonomyLevel.COMMIT_BEFORE_FEEDBACK,
            branch,
            _action_manifest(),
        )
    except ValueError as exc:
        assert "top_n is fixed" in str(exc)
    else:
        raise AssertionError("expected policy violation")


def test_level_3_allows_top_n_tuning() -> None:
    policy = AutonomyPolicy()
    branch = BranchSpec(
        label="fwd_ret_21d",
        feature_regime="financial_only",
        model_bundle="linear_baseline",
        top_n=15,
    )

    policy.validate_branch_spec(
        AutonomyLevel.ITERATE_ON_FEEDBACK,
        branch,
        _action_manifest(),
    )


def test_level_2_requires_single_committed_branch() -> None:
    policy = AutonomyPolicy()
    branch = BranchTrace(
        branch_id="branch-1",
        branch_spec=BranchSpec(
            label="fwd_ret_21d",
            feature_regime="financial_only",
            model_bundle="linear_baseline",
        ),
        committed=False,
    )
    state = TrialState(
        context=_context(AutonomyLevel.COMMIT_BEFORE_FEEDBACK),
        environment=_environment(),
        action_manifest=_action_manifest(),
        branches=(branch,),
        final_branch_id="branch-1",
    )

    try:
        policy.validate_trial_state(state)
    except ValueError as exc:
        assert "committed branch" in str(exc)
    else:
        raise AssertionError("expected policy violation")
