"""Shared fixtures: a synthetic EvidencePack + run-dir."""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

import pytest

from ml4t.agent.schemas import (
    BacktestSummary,
    CostSummary,
    Determinism,
    EvidencePack,
    LineageSummary,
    MethodologyWarning,
    ModelRunSummary,
    RobustnessSummary,
    Severity,
    SignalSummary,
    ValidationDesign,
    ValidationMetrics,
)


@pytest.fixture
def sample_pack() -> EvidencePack:
    return EvidencePack(
        case_study="etfs",
        objective="weekly long/short on US sector ETFs",
        primary_label="ret_5d",
        horizon="5d",
        cadence="weekly",
        parent_run_id="P-1",
        line_id="L-1",
        validation_design=ValidationDesign(
            n_splits=8,
            train_size="36m",
            val_size="3m",
            holdout_start="2024-01-01",
            holdout_end="2025-12-31",
            embargo_days=5,
            purge_days=2,
            fold_calendar_id="cal:abc",
        ),
        validation=ValidationMetrics(
            model_runs=(
                ModelRunSummary(
                    family="linear",
                    config_name="ridge_l2",
                    label="ret_5d",
                    mean_fold_ic=0.018,
                    fold_ic_std=0.009,
                    fold_sharpe_mean=0.42,
                    fold_sharpe_std=0.18,
                    n_folds=8,
                ),
                ModelRunSummary(
                    family="gbm",
                    config_name="lgb_d6",
                    label="ret_5d",
                    mean_fold_ic=0.024,
                    fold_ic_std=0.012,
                    fold_sharpe_mean=0.55,
                    fold_sharpe_std=0.20,
                    n_folds=8,
                ),
            ),
            signal=SignalSummary(
                best_family="gbm",
                best_config="lgb_d6",
                best_mean_ic=0.024,
                ic_t_stat=2.6,
                horizons_tested=("1d", "5d", "21d"),
            ),
            backtests=(
                BacktestSummary(
                    config_id="bench",
                    family="benchmark",
                    gross_sharpe=0.40,
                    net_sharpe=0.30,
                    max_drawdown=-0.12,
                    mean_monthly_turnover=0.05,
                    edge_to_cost_ratio=2.0,
                ),
                BacktestSummary(
                    config_id="strat-gbm",
                    family="gbm",
                    gross_sharpe=0.95,
                    net_sharpe=0.60,
                    max_drawdown=-0.18,
                    mean_monthly_turnover=0.22,
                    edge_to_cost_ratio=1.6,
                ),
            ),
            robustness=RobustnessSummary(
                fold_sharpe_dispersion=0.18,
                regime_breakdown_available=True,
                seed_variance_estimate=0.03,
            ),
        ),
        holdout=None,
        costs=CostSummary(
            per_leg_bps_low=8.0,
            per_leg_bps_high=20.0,
            cost_class="liquid_etf_blend",
            components=("commission", "spread", "impact"),
        ),
        lineage=LineageSummary(
            git_sha="abc1234",
            data_snapshot_id="snap-2025-12-31",
            config_hash="cfg-9f",
            package_versions={"ml4t-data": "0.1.0a6", "ml4t-engineer": "0.1.0b1"},
        ),
        warnings=(
            MethodologyWarning(
                code="LEAK_RISK",
                message="suspect feature timestamp on `regime_x`",
                severity=Severity.MATERIAL,
                determinism=Determinism.ARITHMETIC,
                triggering_artifact="diagnostics/feature_audit.parquet",
                triggering_field="regime_x.timestamp",
            ),
        ),
        diagnostics=(),
    )


@pytest.fixture
def run_dir(tmp_path: Path, sample_pack: EvidencePack) -> Path:
    """Tmp dir containing evidence_pack.json + cost_sensitivity.json."""
    (tmp_path / "evidence_pack.json").write_text(
        json.dumps(asdict(sample_pack), default=str), encoding="utf-8"
    )
    (tmp_path / "cost_sensitivity.json").write_text(
        json.dumps(
            {
                "cost_class": "liquid_etf_blend",
                "components": ["commission", "spread", "impact"],
            }
        ),
        encoding="utf-8",
    )
    return tmp_path
