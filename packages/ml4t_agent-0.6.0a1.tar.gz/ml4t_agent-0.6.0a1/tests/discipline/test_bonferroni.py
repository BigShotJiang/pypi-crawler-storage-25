"""Smoke tests for the Bonferroni alpha schedule + IterationPlan validator."""

from __future__ import annotations

import pytest

from ml4t.agent.discipline import (
    bonferroni_alpha_for_iteration,
    holm_bonferroni,
    validate_iteration_alpha,
)
from ml4t.agent.schemas import (
    ArtifactContract,
    ConfigPatch,
    DeltaCriterion,
    ExperimentPlan,
    IterationPlan,
    LineState,
    PlanValidationError,
    StageInvocation,
)


def _criterion(*, base_alpha: float = 0.05, k: int = 1) -> DeltaCriterion:
    return DeltaCriterion(
        primary_metric="net_sharpe_delta",
        metric_kind="delta",
        support_threshold=0.10,
        reject_threshold=0.0,
        direction="higher_is_better",
        noise_floor_method="block_bootstrap_21d",
        base_alpha=base_alpha,
        bonferroni_k=k,
    )


def _experiment_plan(
    *, experiment_id: str = "E1", base_alpha: float = 0.05, k: int = 1
) -> ExperimentPlan:
    return ExperimentPlan(
        experiment_id=experiment_id,
        template_id="T-C1",
        parent_run_id="P1",
        comparison_target_id="bench",
        config_patches=(
            ConfigPatch(
                path_template="config/setup.yaml",
                path_variables=(),
                yaml_path=("costs", "per_leg_cost_bps_range"),
                new_value=[15.0, 25.0],
            ),
        ),
        stage_invocations=(StageInvocation(script="14_backtest.py"),),
        expected_artifacts=(
            ArtifactContract(
                relative_path="results/strategy_assessment.json",
                schema_id="strategy_assessment_v1",
            ),
        ),
        delta_criterion=_criterion(base_alpha=base_alpha, k=k),
        question="q",
        hypothesis="h",
        rationale="r",
    )


# --- bonferroni_alpha_for_iteration -----------------------------------------


def test_alpha_unchanged_at_k_eq_1():
    assert bonferroni_alpha_for_iteration(0.05, 1) == 0.05


def test_alpha_divides_by_k():
    assert bonferroni_alpha_for_iteration(0.05, 4) == pytest.approx(0.0125)
    assert bonferroni_alpha_for_iteration(0.10, 5) == pytest.approx(0.02)


def test_alpha_shrinks_monotonically():
    series = [bonferroni_alpha_for_iteration(0.05, k) for k in range(1, 6)]
    for prev, nxt in zip(series, series[1:]):
        assert nxt < prev


def test_alpha_rejects_out_of_range():
    with pytest.raises(ValueError, match="alpha must be in"):
        bonferroni_alpha_for_iteration(0.0, 1)
    with pytest.raises(ValueError, match="alpha must be in"):
        bonferroni_alpha_for_iteration(1.0, 1)


def test_alpha_rejects_zero_k():
    with pytest.raises(ValueError, match="k must be >= 1"):
        bonferroni_alpha_for_iteration(0.05, 0)


def test_alpha_matches_delta_criterion_property():
    """Wrapper agrees with DeltaCriterion.adjusted_alpha for k=1..5."""
    for k in range(1, 6):
        crit = _criterion(k=k)
        assert crit.adjusted_alpha == bonferroni_alpha_for_iteration(0.05, k)


# --- validate_iteration_alpha -----------------------------------------------


def test_validate_passes_on_consistent_plan():
    line = LineState(line_id="L1", iteration_index=3)
    plan = IterationPlan(plans=(_experiment_plan(experiment_id="E1", k=3),), line_state=line)
    validate_iteration_alpha(plan)  # no raise


def test_validate_passes_with_multiple_experiments():
    line = LineState(line_id="L1", iteration_index=2)
    plan = IterationPlan(
        plans=(
            _experiment_plan(experiment_id="E1", k=2),
            _experiment_plan(experiment_id="E2", k=2),
        ),
        line_state=line,
    )
    validate_iteration_alpha(plan)


def test_validate_rejects_mismatched_k():
    line = LineState(line_id="L1", iteration_index=3)
    plan = IterationPlan(plans=(_experiment_plan(experiment_id="E1", k=2),), line_state=line)
    with pytest.raises(PlanValidationError, match="bonferroni_k"):
        validate_iteration_alpha(plan)


def test_validate_rejects_mismatched_base_alpha():
    line = LineState(line_id="L1", iteration_index=1, base_alpha=0.05)
    plan = IterationPlan(
        plans=(_experiment_plan(experiment_id="E1", base_alpha=0.10, k=1),),
        line_state=line,
    )
    with pytest.raises(PlanValidationError, match="base_alpha"):
        validate_iteration_alpha(plan)


# --- holm_bonferroni re-export ----------------------------------------------


def test_holm_bonferroni_reexported_and_callable():
    result = holm_bonferroni([0.001, 0.01, 0.5], alpha=0.05)
    assert result["n_rejected"] == 2
    assert result["rejected"] == [True, True, False]
