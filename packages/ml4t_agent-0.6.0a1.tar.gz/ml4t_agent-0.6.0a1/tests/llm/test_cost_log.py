"""Tests for the per-call cost estimator.

Live tests are skipped in CI; the estimator itself is exercised here so
rate-table regressions are caught even when the live path doesn't run.
"""

from __future__ import annotations

import pytest


def test_estimate_anthropic_known_model_no_cache(cost_estimator):
    # 3000 in, 600 out, no cache → 3000*3 + 600*15 = 9000 + 9000 = $0.018
    cost = cost_estimator(
        "anthropic",
        "claude-sonnet-4-6",
        {"input_tokens": 3000, "output_tokens": 600},
    )
    assert cost == pytest.approx(0.018, rel=1e-6)


def test_estimate_openai_uses_cached_discount(cost_estimator):
    # 3000 prompt, 1500 cached, 600 out
    # uncached input = 1500 * 0.25 = $0.000375
    # cached input  = 1500 * 0.025 = $0.0000375
    # completion    = 600  * 2.00 = $0.0012
    cost = cost_estimator(
        "openai",
        "gpt-5-mini",
        {"prompt_tokens": 3000, "cached_tokens": 1500, "completion_tokens": 600},
    )
    assert cost == pytest.approx(0.0016125, abs=1e-6)


def test_estimate_google_known_model(cost_estimator):
    cost = cost_estimator(
        "google",
        "gemini-2.5-flash",
        {"prompt_tokens": 3000, "completion_tokens": 600},
    )
    # 3000 * 0.30 + 600 * 2.50 = 900 + 1500 = 2400 micro-USD = $0.0024
    assert cost == pytest.approx(0.0024, rel=1e-6)


def test_estimate_unknown_model_returns_none(cost_estimator):
    assert cost_estimator("openai", "gpt-7-quantum", {"prompt_tokens": 1}) is None


def test_log_cost_appends_record(tmp_path, monkeypatch, cost_logger):
    log_path = tmp_path / "cost_log.jsonl"
    monkeypatch.delenv("ML4T_AGENT_DISABLE_COST_LOG", raising=False)
    cost = cost_logger(
        "openai",
        "gpt-5-mini",
        {"prompt_tokens": 100, "completion_tokens": 50},
        log_path=log_path,
    )
    assert cost is not None
    contents = log_path.read_text(encoding="utf-8").strip().splitlines()
    assert len(contents) == 1
    assert "openai" in contents[0]
    assert "gpt-5-mini" in contents[0]


def test_log_cost_raises_on_ceiling_breach(tmp_path, monkeypatch, cost_logger):
    log_path = tmp_path / "cost_log.jsonl"
    monkeypatch.delenv("ML4T_AGENT_DISABLE_COST_LOG", raising=False)
    # gpt-5 standard input is $1.25/Mtok, output $10/Mtok.
    # 50000 prompt + 5000 completion = 0.0625 + 0.05 = $0.1125 → over $0.05
    with pytest.raises(AssertionError, match="ceiling"):
        cost_logger(
            "openai",
            "gpt-5",
            {"prompt_tokens": 50000, "completion_tokens": 5000},
            log_path=log_path,
        )


def test_per_run_ceiling_is_published_value(cost_logger, tmp_path, monkeypatch):
    """A trivial-cost call must succeed; a $0.06 call must trip the ceiling.

    Encodes the published ceiling indirectly so the test fails if the
    threshold value drifts.
    """
    monkeypatch.delenv("ML4T_AGENT_DISABLE_COST_LOG", raising=False)
    # 40000 prompt + 4000 completion at gpt-5 rates = $0.05 + $0.04 = $0.09
    with pytest.raises(AssertionError, match=r"\$0\.05 ceiling"):
        cost_logger(
            "openai",
            "gpt-5",
            {"prompt_tokens": 40000, "completion_tokens": 4000},
            log_path=tmp_path / "cost_log.jsonl",
        )


def test_log_cost_disabled_via_env(tmp_path, monkeypatch, cost_logger):
    log_path = tmp_path / "cost_log.jsonl"
    monkeypatch.setenv("ML4T_AGENT_DISABLE_COST_LOG", "1")
    cost_logger(
        "openai",
        "gpt-5-mini",
        {"prompt_tokens": 10, "completion_tokens": 1},
        log_path=log_path,
    )
    assert not log_path.exists()
