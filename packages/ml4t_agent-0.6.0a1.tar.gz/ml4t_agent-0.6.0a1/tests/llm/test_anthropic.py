"""Anthropic concrete impl tests.

The full impl is exercised against a fake SDK to verify wiring (system
caching, tool_choice, response parsing) without needing an API key. A
separate live test is skipped unless ANTHROPIC_API_KEY is set.
"""

from __future__ import annotations

import os
import sys
from types import ModuleType, SimpleNamespace
from typing import Any

import pytest


@pytest.fixture
def fake_anthropic(monkeypatch):
    """Replace the ``anthropic`` SDK with a configurable fake."""
    captured: dict[str, Any] = {}

    def fake_create(**kwargs):
        captured["kwargs"] = kwargs
        # Return a tool_use block with the input dict the test arms.
        tool_use = SimpleNamespace(type="tool_use", input={"answer": "fake"})
        usage = SimpleNamespace(input_tokens=10, output_tokens=3)
        return SimpleNamespace(content=[tool_use], usage=usage)

    class FakeAnthropic:
        def __init__(self, api_key: str) -> None:
            captured["api_key"] = api_key
            self.messages = SimpleNamespace(create=fake_create)

    fake_module = ModuleType("anthropic")
    setattr(fake_module, "Anthropic", FakeAnthropic)  # noqa: B010
    setattr(fake_module, "NOT_GIVEN", object())  # noqa: B010

    monkeypatch.setitem(sys.modules, "anthropic", fake_module)
    monkeypatch.delitem(sys.modules, "ml4t.agent.llm.anthropic", raising=False)
    return captured


def test_anthropic_client_partitions_system_and_caches(fake_anthropic):
    from ml4t.agent.llm import AnthropicClient
    from ml4t.agent.llm.base import Message

    client = AnthropicClient(api_key="fake-key")
    response = client.complete_with_schema(
        [
            Message(role="system", content="rules", cacheable=True),
            Message(role="user", content="hello"),
        ],
        {"type": "object", "properties": {"answer": {"type": "string"}}},
    )

    kwargs = fake_anthropic["kwargs"]
    assert fake_anthropic["api_key"] == "fake-key"
    assert kwargs["model"] == "claude-opus-4-7"
    assert kwargs["tool_choice"] == {"type": "tool", "name": "emit_structured_response"}
    assert kwargs["system"] == [
        {"type": "text", "text": "rules", "cache_control": {"type": "ephemeral"}}
    ]
    assert kwargs["messages"] == [{"role": "user", "content": "hello"}]
    assert kwargs["tools"][0]["cache_control"] == {"type": "ephemeral"}
    assert response.data == {"answer": "fake"}
    assert response.usage == {"input_tokens": 10, "output_tokens": 3}


def test_anthropic_client_disables_cache_when_requested(fake_anthropic):
    from ml4t.agent.llm import AnthropicClient
    from ml4t.agent.llm.base import Message

    client = AnthropicClient(api_key="fake-key", enable_caching=False)
    client.complete_with_schema(
        [Message(role="system", content="rules", cacheable=True)],
        {"type": "object"},
    )
    kwargs = fake_anthropic["kwargs"]
    assert kwargs["system"] == [{"type": "text", "text": "rules"}]
    assert "cache_control" not in kwargs["tools"][0]


def test_anthropic_client_omits_system_when_none(fake_anthropic):
    from ml4t.agent.llm import AnthropicClient
    from ml4t.agent.llm.base import Message

    client = AnthropicClient(api_key="fake-key")
    client.complete_with_schema(
        [Message(role="user", content="hi")],
        {"type": "object"},
    )
    sentinel = getattr(sys.modules["anthropic"], "NOT_GIVEN")  # noqa: B009
    assert fake_anthropic["kwargs"]["system"] is sentinel


def test_anthropic_client_raises_without_key(fake_anthropic, monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    from ml4t.agent.llm import AnthropicClient

    with pytest.raises(RuntimeError, match="ANTHROPIC_API_KEY"):
        AnthropicClient()


def test_anthropic_client_rejects_non_object_input(monkeypatch):
    """If tool_use.input isn't a dict, parser raises a clear error."""
    from types import ModuleType, SimpleNamespace

    class FakeAnthropic:
        def __init__(self, api_key: str):
            self.messages = SimpleNamespace(
                create=lambda **kwargs: SimpleNamespace(
                    content=[SimpleNamespace(type="tool_use", input="not-a-dict")],
                    usage=None,
                )
            )

    fake_module = ModuleType("anthropic")
    setattr(fake_module, "Anthropic", FakeAnthropic)  # noqa: B010
    setattr(fake_module, "NOT_GIVEN", object())  # noqa: B010
    monkeypatch.setitem(sys.modules, "anthropic", fake_module)
    monkeypatch.delitem(sys.modules, "ml4t.agent.llm.anthropic", raising=False)

    from ml4t.agent.llm import AnthropicClient
    from ml4t.agent.llm.base import Message

    client = AnthropicClient(api_key="fake-key")
    with pytest.raises(ValueError, match="not a JSON object"):
        client.complete_with_schema([Message(role="user", content="x")], {"type": "object"})


# --- Live test (skipped without API key) -------------------------------------


@pytest.mark.skipif(
    not os.environ.get("ANTHROPIC_API_KEY"),
    reason="ANTHROPIC_API_KEY not set; skipping live Anthropic test",
)
def test_anthropic_client_live_smoke():  # pragma: no cover - network
    from ml4t.agent.llm import AnthropicClient
    from ml4t.agent.llm.base import Message

    client = AnthropicClient()
    response = client.complete_with_schema(
        [Message(role="user", content="Reply with answer='hello'.")],
        {
            "type": "object",
            "properties": {"answer": {"type": "string"}},
            "required": ["answer"],
        },
        max_tokens=64,
    )
    assert "answer" in response.data
