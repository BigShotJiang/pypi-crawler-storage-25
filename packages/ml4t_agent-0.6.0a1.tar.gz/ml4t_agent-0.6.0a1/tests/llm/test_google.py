"""Google Gemini concrete impl tests.

Wiring is exercised against a fake SDK to verify config construction
(response_schema, system_instruction, role translation), JSON parsing,
and usage extraction without needing an API key. The live test is gated
on ``GOOGLE_API_KEY`` and the ``live`` marker.
"""

from __future__ import annotations

import json
import os
import sys
from types import ModuleType, SimpleNamespace
from typing import Any

import pytest


@pytest.fixture
def fake_google(monkeypatch):
    """Replace the ``google.genai`` SDK with a configurable fake."""
    captured: dict[str, Any] = {}

    def fake_generate(**kwargs):
        captured["kwargs"] = kwargs
        usage_metadata = SimpleNamespace(
            prompt_token_count=12,
            candidates_token_count=4,
            total_token_count=16,
            cached_content_token_count=3,
        )
        return SimpleNamespace(
            text=json.dumps({"answer": "fake"}),
            usage_metadata=usage_metadata,
        )

    class FakeClient:
        def __init__(self, api_key: str) -> None:
            captured["api_key"] = api_key
            self.models = SimpleNamespace(generate_content=fake_generate)

    fake_genai = ModuleType("google.genai")
    setattr(fake_genai, "Client", FakeClient)  # noqa: B010
    fake_types = ModuleType("google.genai.types")
    setattr(fake_genai, "types", fake_types)  # noqa: B010

    fake_google_pkg = ModuleType("google")
    setattr(fake_google_pkg, "genai", fake_genai)  # noqa: B010

    monkeypatch.setitem(sys.modules, "google", fake_google_pkg)
    monkeypatch.setitem(sys.modules, "google.genai", fake_genai)
    monkeypatch.setitem(sys.modules, "google.genai.types", fake_types)
    monkeypatch.delitem(sys.modules, "ml4t.agent.llm.google_client", raising=False)
    return captured


def test_google_client_partitions_system_and_translates_roles(fake_google):
    from ml4t.agent.llm import GoogleClient
    from ml4t.agent.llm.base import Message

    client = GoogleClient(api_key="fake-key")
    schema = {
        "type": "object",
        "properties": {"answer": {"type": "string"}},
        "required": ["answer"],
    }
    response = client.complete_with_schema(
        [
            Message(role="system", content="rules"),
            Message(role="user", content="hello"),
            Message(role="assistant", content="hi"),
            Message(role="user", content="again"),
        ],
        schema,
    )

    kwargs = fake_google["kwargs"]
    assert fake_google["api_key"] == "fake-key"
    assert kwargs["model"] == "gemini-2.5-flash"
    assert kwargs["contents"] == [
        {"role": "user", "parts": [{"text": "hello"}]},
        {"role": "model", "parts": [{"text": "hi"}]},
        {"role": "user", "parts": [{"text": "again"}]},
    ]
    cfg = kwargs["config"]
    assert cfg["response_mime_type"] == "application/json"
    assert cfg["response_schema"] == schema
    assert cfg["system_instruction"] == "rules"
    assert cfg["max_output_tokens"] == 1024
    assert cfg["temperature"] == 0.0
    assert response.data == {"answer": "fake"}
    assert response.usage == {
        "prompt_tokens": 12,
        "completion_tokens": 4,
        "total_tokens": 16,
        "cached_tokens": 3,
    }


def test_google_client_concatenates_multiple_system_messages(fake_google):
    from ml4t.agent.llm import GoogleClient
    from ml4t.agent.llm.base import Message

    client = GoogleClient(api_key="fake-key")
    client.complete_with_schema(
        [
            Message(role="system", content="rule one"),
            Message(role="system", content="rule two"),
            Message(role="user", content="hi"),
        ],
        {"type": "object"},
    )
    assert fake_google["kwargs"]["config"]["system_instruction"] == "rule one\n\nrule two"


def test_google_client_omits_system_instruction_when_none(fake_google):
    from ml4t.agent.llm import GoogleClient
    from ml4t.agent.llm.base import Message

    client = GoogleClient(api_key="fake-key")
    client.complete_with_schema(
        [Message(role="user", content="hi")],
        {"type": "object"},
    )
    assert "system_instruction" not in fake_google["kwargs"]["config"]


def test_google_client_omits_temperature_when_none(fake_google):
    from ml4t.agent.llm import GoogleClient
    from ml4t.agent.llm.base import Message

    client = GoogleClient(api_key="fake-key")
    client.complete_with_schema(
        [Message(role="user", content="hi")],
        {"type": "object"},
        temperature=None,
    )
    assert "temperature" not in fake_google["kwargs"]["config"]


def test_google_client_respects_custom_model(fake_google):
    from ml4t.agent.llm import GoogleClient
    from ml4t.agent.llm.base import Message

    client = GoogleClient(api_key="fake-key", model="gemini-2.5-pro")
    client.complete_with_schema(
        [Message(role="user", content="hi")],
        {"type": "object"},
    )
    assert fake_google["kwargs"]["model"] == "gemini-2.5-pro"


def test_google_client_raises_without_key(fake_google, monkeypatch):
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    from ml4t.agent.llm import GoogleClient

    with pytest.raises(RuntimeError, match="GOOGLE_API_KEY"):
        GoogleClient()


def test_google_client_uses_gemini_api_key_fallback(fake_google, monkeypatch):
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
    monkeypatch.setenv("GEMINI_API_KEY", "via-gemini")
    from ml4t.agent.llm import GoogleClient
    from ml4t.agent.llm.base import Message

    client = GoogleClient()
    client.complete_with_schema([Message(role="user", content="x")], {"type": "object"})
    assert fake_google["api_key"] == "via-gemini"


def test_google_client_rejects_non_object_payload(monkeypatch):
    from types import ModuleType, SimpleNamespace

    class FakeClient:
        def __init__(self, api_key: str):
            self.models = SimpleNamespace(
                generate_content=lambda **kwargs: SimpleNamespace(
                    text="[1, 2]",
                    usage_metadata=None,
                ),
            )

    fake_genai = ModuleType("google.genai")
    setattr(fake_genai, "Client", FakeClient)  # noqa: B010
    fake_types = ModuleType("google.genai.types")
    setattr(fake_genai, "types", fake_types)  # noqa: B010
    fake_google_pkg = ModuleType("google")
    setattr(fake_google_pkg, "genai", fake_genai)  # noqa: B010

    monkeypatch.setitem(sys.modules, "google", fake_google_pkg)
    monkeypatch.setitem(sys.modules, "google.genai", fake_genai)
    monkeypatch.setitem(sys.modules, "google.genai.types", fake_types)
    monkeypatch.delitem(sys.modules, "ml4t.agent.llm.google_client", raising=False)

    from ml4t.agent.llm import GoogleClient
    from ml4t.agent.llm.base import Message

    client = GoogleClient(api_key="fake-key")
    with pytest.raises(ValueError, match="not a JSON object"):
        client.complete_with_schema([Message(role="user", content="x")], {"type": "object"})


def test_google_client_rejects_invalid_json(monkeypatch):
    from types import ModuleType, SimpleNamespace

    class FakeClient:
        def __init__(self, api_key: str):
            self.models = SimpleNamespace(
                generate_content=lambda **kwargs: SimpleNamespace(
                    text="not-json{",
                    usage_metadata=None,
                ),
            )

    fake_genai = ModuleType("google.genai")
    setattr(fake_genai, "Client", FakeClient)  # noqa: B010
    fake_types = ModuleType("google.genai.types")
    setattr(fake_genai, "types", fake_types)  # noqa: B010
    fake_google_pkg = ModuleType("google")
    setattr(fake_google_pkg, "genai", fake_genai)  # noqa: B010

    monkeypatch.setitem(sys.modules, "google", fake_google_pkg)
    monkeypatch.setitem(sys.modules, "google.genai", fake_genai)
    monkeypatch.setitem(sys.modules, "google.genai.types", fake_types)
    monkeypatch.delitem(sys.modules, "ml4t.agent.llm.google_client", raising=False)

    from ml4t.agent.llm import GoogleClient
    from ml4t.agent.llm.base import Message

    client = GoogleClient(api_key="fake-key")
    with pytest.raises(ValueError, match="not valid JSON"):
        client.complete_with_schema([Message(role="user", content="x")], {"type": "object"})


def test_google_client_satisfies_protocol(fake_google):
    from ml4t.agent.llm import GoogleClient, LLMClient

    client = GoogleClient(api_key="fake-key")
    assert isinstance(client, LLMClient)


# --- Live test (skipped without API key) -------------------------------------


@pytest.mark.live
@pytest.mark.skipif(
    not (os.environ.get("GOOGLE_API_KEY") or os.environ.get("GEMINI_API_KEY")),
    reason="GOOGLE_API_KEY/GEMINI_API_KEY not set; skipping live Google test",
)
def test_google_client_live_smoke(cost_logger):  # pragma: no cover - network
    from ml4t.agent.llm import GoogleClient
    from ml4t.agent.llm.base import Message

    client = GoogleClient()
    response = client.complete_with_schema(
        [Message(role="user", content="Reply with answer='hello'.")],
        {
            "type": "object",
            "properties": {"answer": {"type": "string"}},
            "required": ["answer"],
        },
        max_tokens=64,
    )
    assert "answer" in response.data
    cost_logger("google", "gemini-2.5-flash", response.usage)
