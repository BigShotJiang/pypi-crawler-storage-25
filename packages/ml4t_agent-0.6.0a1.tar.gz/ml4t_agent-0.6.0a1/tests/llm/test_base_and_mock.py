"""Protocol contract + mock recorder tests."""

from __future__ import annotations

from pathlib import Path

import pytest

from ml4t.agent.llm import LLMClient, LLMResponse, Message, MockLLMClient
from ml4t.agent.llm.mock import (
    MockReplayMissError,
    compute_cache_key,
    load_recording,
    save_recording,
)


def _schema() -> dict:
    return {
        "type": "object",
        "properties": {"answer": {"type": "string"}},
        "required": ["answer"],
    }


def _messages() -> list[Message]:
    return [
        Message(role="system", content="You are concise.", cacheable=True),
        Message(role="user", content="Say hi."),
    ]


# --- Protocol contract -------------------------------------------------------


def test_mock_satisfies_llmclient_protocol():
    client = MockLLMClient(
        responder=lambda msgs, schema: LLMResponse(data={"answer": "hi"}, raw="{}")
    )
    assert isinstance(client, LLMClient)


def test_protocol_check_rejects_unrelated_object():
    assert not isinstance(object(), LLMClient)


# --- Mock replay -------------------------------------------------------------


def test_mock_replays_recorded_response():
    key = compute_cache_key(_messages(), _schema(), 1024, 0.0)
    canned = LLMResponse(data={"answer": "ok"}, raw='{"answer": "ok"}')
    client = MockLLMClient({key: canned})
    response = client.complete_with_schema(_messages(), _schema())
    assert response is canned
    assert client.calls == [(key, canned)]


def test_mock_responder_records_on_miss(tmp_path: Path):
    record_path = tmp_path / "recording.json"
    counter = {"n": 0}

    def responder(msgs, schema):
        counter["n"] += 1
        return LLMResponse(data={"answer": f"v{counter['n']}"}, raw="raw")

    client = MockLLMClient(responder=responder, record_to=record_path)
    first = client.complete_with_schema(_messages(), _schema())
    second = client.complete_with_schema(_messages(), _schema())  # cache hit
    assert first is second  # same key, no second responder call
    assert counter["n"] == 1
    assert record_path.is_file()
    restored = load_recording(record_path)
    assert len(restored) == 1
    assert next(iter(restored.values())).data == {"answer": "v1"}


def test_mock_replay_miss_raises():
    client = MockLLMClient({})
    with pytest.raises(MockReplayMissError, match="no recorded response"):
        client.complete_with_schema(_messages(), _schema())


def test_mock_requires_recordings_or_responder():
    with pytest.raises(ValueError, match="recordings or a responder"):
        MockLLMClient()


# --- Cache key stability -----------------------------------------------------


def test_cache_key_stable_under_dict_reordering():
    schema_a = {"type": "object", "properties": {"a": {"type": "string"}}}
    schema_b = {"properties": {"a": {"type": "string"}}, "type": "object"}
    assert compute_cache_key([], schema_a, 1, 0.0) == compute_cache_key([], schema_b, 1, 0.0)


def test_cache_key_changes_with_temperature():
    k1 = compute_cache_key(_messages(), _schema(), 1024, 0.0)
    k2 = compute_cache_key(_messages(), _schema(), 1024, 0.7)
    assert k1 != k2


# --- Recording round-trip ----------------------------------------------------


def test_recording_roundtrip(tmp_path: Path):
    key = compute_cache_key(_messages(), _schema(), 1024, 0.0)
    original = {key: LLMResponse(data={"answer": "ok"}, raw="r", usage={"input_tokens": 5})}
    path = tmp_path / "rec.json"
    save_recording(original, path)
    restored = load_recording(path)
    assert set(restored) == set(original)
    assert restored[key].data == {"answer": "ok"}
    assert restored[key].usage == {"input_tokens": 5}


def test_recording_rejects_malformed(tmp_path: Path):
    path = tmp_path / "rec.json"
    path.write_text('{"k": {"raw": "x"}}', encoding="utf-8")  # missing data
    with pytest.raises(ValueError, match="malformed recording"):
        load_recording(path)
