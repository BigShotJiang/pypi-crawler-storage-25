"""Shared fixtures for LLM provider tests.

The cost-logger fixture exposes ``estimate_cost_usd`` / ``log_cost`` /
``PER_RUN_COST_CEILING_USD`` / ``RATES_PER_MTOK`` so live tests can
record token usage without a relative import (which ``ty`` doesn't
resolve under ``tests/``).
"""

from __future__ import annotations

import json
import os
import time
from collections.abc import Mapping
from pathlib import Path

import pytest

PER_RUN_COST_CEILING_USD = 0.05

# USD per 1,000,000 tokens. Manually maintained — refresh quarterly.
# Cached input gets the discounted rate where the provider publishes
# one; otherwise the standard input rate applies.
RATES_PER_MTOK: dict[tuple[str, str], dict[str, float]] = {
    ("anthropic", "claude-sonnet-4-6"): {
        "input": 3.0,
        "output": 15.0,
        "cached_input": 0.30,
    },
    ("anthropic", "claude-opus-4-7"): {
        "input": 15.0,
        "output": 75.0,
        "cached_input": 1.50,
    },
    ("openai", "gpt-5-mini"): {
        "input": 0.25,
        "output": 2.00,
        "cached_input": 0.025,
    },
    ("openai", "gpt-5"): {
        "input": 1.25,
        "output": 10.00,
        "cached_input": 0.125,
    },
    ("google", "gemini-2.5-flash"): {
        "input": 0.30,
        "output": 2.50,
        "cached_input": 0.075,
    },
    ("google", "gemini-2.5-pro"): {
        "input": 1.25,
        "output": 10.00,
        "cached_input": 0.31,
    },
}

DEFAULT_LOG_PATH = Path(__file__).with_name("cost_log.jsonl")


def estimate_cost_usd(provider: str, model: str, usage: Mapping[str, int]) -> float | None:
    rates = RATES_PER_MTOK.get((provider, model))
    if rates is None:
        return None
    prompt = int(usage.get("prompt_tokens") or usage.get("input_tokens") or 0)
    completion = int(usage.get("completion_tokens") or usage.get("output_tokens") or 0)
    cached = int(usage.get("cached_tokens") or usage.get("cache_read_input_tokens") or 0)
    uncached = max(prompt - cached, 0)
    cost = (
        uncached * rates["input"]
        + cached * rates.get("cached_input", rates["input"])
        + completion * rates["output"]
    ) / 1_000_000
    return round(cost, 6)


def log_cost(
    provider: str,
    model: str,
    usage: Mapping[str, int],
    *,
    log_path: Path | None = None,
) -> float | None:
    cost = estimate_cost_usd(provider, model, usage)
    record = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "provider": provider,
        "model": model,
        "usage": dict(usage),
        "estimated_usd": cost,
    }
    target = log_path or DEFAULT_LOG_PATH
    if not os.environ.get("ML4T_AGENT_DISABLE_COST_LOG"):
        with target.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, sort_keys=True) + "\n")
    if cost is not None and cost > PER_RUN_COST_CEILING_USD:
        raise AssertionError(
            f"{provider}/{model} live call estimated at ${cost:.4f}, "
            f"exceeds ${PER_RUN_COST_CEILING_USD:.2f} ceiling. "
            f"Investigate token usage or refresh RATES_PER_MTOK."
        )
    return cost


@pytest.fixture
def cost_logger():
    """Return ``log_cost`` bound to the default cost-log file."""
    return log_cost


@pytest.fixture
def cost_estimator():
    """Return ``estimate_cost_usd`` for unit testing the rate table."""
    return estimate_cost_usd
