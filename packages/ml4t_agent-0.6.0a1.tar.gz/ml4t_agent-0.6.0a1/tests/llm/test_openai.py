"""OpenAI concrete impl tests.

Wiring is exercised against a fake SDK to verify response_format
construction, JSON parsing, and usage extraction without needing an
API key. The live test is gated on ``OPENAI_API_KEY`` and the ``live``
marker.
"""

from __future__ import annotations

import json
import os
import sys
from types import ModuleType, SimpleNamespace
from typing import Any

import pytest


@pytest.fixture
def fake_openai(monkeypatch):
    """Replace the ``openai`` SDK with a configurable fake."""
    captured: dict[str, Any] = {}

    def fake_create(**kwargs):
        captured["kwargs"] = kwargs
        message = SimpleNamespace(content=json.dumps({"answer": "fake"}))
        choice = SimpleNamespace(message=message)
        usage = SimpleNamespace(
            prompt_tokens=11,
            completion_tokens=5,
            total_tokens=16,
            prompt_tokens_details=SimpleNamespace(cached_tokens=4),
        )
        return SimpleNamespace(choices=[choice], usage=usage)

    class FakeOpenAI:
        def __init__(self, api_key: str) -> None:
            captured["api_key"] = api_key
            self.chat = SimpleNamespace(
                completions=SimpleNamespace(create=fake_create),
            )

    fake_module = ModuleType("openai")
    setattr(fake_module, "OpenAI", FakeOpenAI)  # noqa: B010

    monkeypatch.setitem(sys.modules, "openai", fake_module)
    monkeypatch.delitem(sys.modules, "ml4t.agent.llm.openai_client", raising=False)
    return captured


def test_openai_client_sends_response_format_and_messages(fake_openai):
    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key")
    schema = {
        "type": "object",
        "properties": {"answer": {"type": "string"}},
        "required": ["answer"],
    }
    response = client.complete_with_schema(
        [
            Message(role="system", content="rules"),
            Message(role="user", content="hello"),
        ],
        schema,
    )

    kwargs = fake_openai["kwargs"]
    assert fake_openai["api_key"] == "fake-key"
    assert kwargs["model"] == "gpt-5-mini"
    assert kwargs["messages"] == [
        {"role": "system", "content": "rules"},
        {"role": "user", "content": "hello"},
    ]
    assert kwargs["max_completion_tokens"] == 8192
    assert kwargs["response_format"] == {
        "type": "json_schema",
        "json_schema": {
            "name": "structured_response",
            "schema": schema,
            "strict": False,
        },
    }
    assert kwargs["temperature"] == 0.0
    assert response.data == {"answer": "fake"}
    assert response.usage == {
        "prompt_tokens": 11,
        "completion_tokens": 5,
        "total_tokens": 16,
        "cached_tokens": 4,
    }


def test_openai_client_omits_temperature_when_none(fake_openai):
    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key")
    client.complete_with_schema(
        [Message(role="user", content="hi")],
        {"type": "object"},
        temperature=None,
    )
    assert "temperature" not in fake_openai["kwargs"]


def test_openai_client_respects_custom_model(fake_openai):
    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key", model="gpt-5")
    client.complete_with_schema(
        [Message(role="user", content="hi")],
        {"type": "object"},
    )
    assert fake_openai["kwargs"]["model"] == "gpt-5"


def test_openai_client_raises_without_key(fake_openai, monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    from ml4t.agent.llm import OpenAIClient

    with pytest.raises(RuntimeError, match="OPENAI_API_KEY"):
        OpenAIClient()


def test_openai_client_rejects_non_object_payload(monkeypatch):
    """If the assistant returns a JSON value that isn't an object, raise."""
    from types import ModuleType, SimpleNamespace

    class FakeOpenAI:
        def __init__(self, api_key: str):
            self.chat = SimpleNamespace(
                completions=SimpleNamespace(
                    create=lambda **kwargs: SimpleNamespace(
                        choices=[SimpleNamespace(message=SimpleNamespace(content="[1, 2]"))],
                        usage=None,
                    ),
                ),
            )

    fake_module = ModuleType("openai")
    setattr(fake_module, "OpenAI", FakeOpenAI)  # noqa: B010
    monkeypatch.setitem(sys.modules, "openai", fake_module)
    monkeypatch.delitem(sys.modules, "ml4t.agent.llm.openai_client", raising=False)

    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key")
    with pytest.raises(ValueError, match="not a JSON object"):
        client.complete_with_schema([Message(role="user", content="x")], {"type": "object"})


def test_openai_client_rejects_invalid_json(monkeypatch):
    from types import ModuleType, SimpleNamespace

    class FakeOpenAI:
        def __init__(self, api_key: str):
            self.chat = SimpleNamespace(
                completions=SimpleNamespace(
                    create=lambda **kwargs: SimpleNamespace(
                        choices=[SimpleNamespace(message=SimpleNamespace(content="not-json{"))],
                        usage=None,
                    ),
                ),
            )

    fake_module = ModuleType("openai")
    setattr(fake_module, "OpenAI", FakeOpenAI)  # noqa: B010
    monkeypatch.setitem(sys.modules, "openai", fake_module)
    monkeypatch.delitem(sys.modules, "ml4t.agent.llm.openai_client", raising=False)

    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key")
    with pytest.raises(ValueError, match="not valid JSON"):
        client.complete_with_schema([Message(role="user", content="x")], {"type": "object"})


def test_openai_client_rejects_empty_choices(monkeypatch):
    from types import ModuleType, SimpleNamespace

    class FakeOpenAI:
        def __init__(self, api_key: str):
            self.chat = SimpleNamespace(
                completions=SimpleNamespace(
                    create=lambda **kwargs: SimpleNamespace(choices=[], usage=None),
                ),
            )

    fake_module = ModuleType("openai")
    setattr(fake_module, "OpenAI", FakeOpenAI)  # noqa: B010
    monkeypatch.setitem(sys.modules, "openai", fake_module)
    monkeypatch.delitem(sys.modules, "ml4t.agent.llm.openai_client", raising=False)

    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key")
    with pytest.raises(ValueError, match="no choices"):
        client.complete_with_schema([Message(role="user", content="x")], {"type": "object"})


def test_openai_client_satisfies_protocol(fake_openai):
    from ml4t.agent.llm import LLMClient, OpenAIClient

    client = OpenAIClient(api_key="fake-key")
    assert isinstance(client, LLMClient)


def test_openai_client_strict_opt_in_at_construction(fake_openai):
    """``strict=True`` at construction flips the default for every call."""
    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key", strict=True)
    client.complete_with_schema(
        [Message(role="user", content="hi")],
        {"type": "object"},
    )
    assert fake_openai["kwargs"]["response_format"]["json_schema"]["strict"] is True


def test_openai_client_strict_per_call_override(fake_openai):
    """Per-call ``strict=True`` overrides the constructor default."""
    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key")  # default strict=False
    client.complete_with_schema(
        [Message(role="user", content="hi")],
        {"type": "object"},
        strict=True,
    )
    assert fake_openai["kwargs"]["response_format"]["json_schema"]["strict"] is True


def test_openai_client_max_tokens_override(fake_openai):
    """Custom ``max_tokens`` survives to ``max_completion_tokens``."""
    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key")
    client.complete_with_schema(
        [Message(role="user", content="hi")],
        {"type": "object"},
        max_tokens=2048,
    )
    assert fake_openai["kwargs"]["max_completion_tokens"] == 2048


def test_openai_client_raises_budget_exhausted_on_length(monkeypatch):
    """finish_reason='length' with empty content surfaces a typed error."""
    from types import ModuleType, SimpleNamespace

    class FakeOpenAI:
        def __init__(self, api_key: str):
            self.chat = SimpleNamespace(
                completions=SimpleNamespace(
                    create=lambda **kwargs: SimpleNamespace(
                        choices=[
                            SimpleNamespace(
                                message=SimpleNamespace(content=""),
                                finish_reason="length",
                            )
                        ],
                        usage=None,
                    ),
                ),
            )

    fake_module = ModuleType("openai")
    setattr(fake_module, "OpenAI", FakeOpenAI)  # noqa: B010
    monkeypatch.setitem(sys.modules, "openai", fake_module)
    monkeypatch.delitem(sys.modules, "ml4t.agent.llm.openai_client", raising=False)

    from ml4t.agent.llm import OpenAIBudgetExhaustedError, OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key")
    with pytest.raises(OpenAIBudgetExhaustedError, match="max_completion_tokens=8192"):
        client.complete_with_schema(
            [Message(role="user", content="x")],
            {"type": "object"},
        )


def test_openai_client_empty_content_non_length_raises_value_error(monkeypatch):
    """Empty content with a non-length finish_reason still raises ValueError."""
    from types import ModuleType, SimpleNamespace

    class FakeOpenAI:
        def __init__(self, api_key: str):
            self.chat = SimpleNamespace(
                completions=SimpleNamespace(
                    create=lambda **kwargs: SimpleNamespace(
                        choices=[
                            SimpleNamespace(
                                message=SimpleNamespace(content=""),
                                finish_reason="stop",
                            )
                        ],
                        usage=None,
                    ),
                ),
            )

    fake_module = ModuleType("openai")
    setattr(fake_module, "OpenAI", FakeOpenAI)  # noqa: B010
    monkeypatch.setitem(sys.modules, "openai", fake_module)
    monkeypatch.delitem(sys.modules, "ml4t.agent.llm.openai_client", raising=False)

    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient(api_key="fake-key")
    with pytest.raises(ValueError, match="finish_reason='stop'"):
        client.complete_with_schema(
            [Message(role="user", content="x")],
            {"type": "object"},
        )


@pytest.mark.xfail(
    reason=(
        "Proposer response schema deliberately leaves config_patches[*].new_value "
        "untyped (`{}`) because it varies per template. OpenAI strict mode rejects "
        "schemas that are not fully type-specified; this xfail documents the "
        "incompatibility — see plan-31a v0.5.0 spike. Remove if/when the proposer "
        "schema is rewritten to be strict-compliant."
    ),
    strict=True,
)
def test_proposer_schema_is_strict_compliant():
    """Sentinel test: proposer schema would fail OpenAI strict-mode validation."""
    from ml4t.agent.tools.proposals import _build_response_schema, default_templates

    schema = _build_response_schema(default_templates(), max_proposals=4)

    # Heuristic for OpenAI strict-compliance: every "object" must declare
    # additionalProperties=False AND no property may use the empty schema {}.
    def _walk(node):
        if isinstance(node, dict):
            if node.get("type") == "object":
                assert node.get("additionalProperties") is False, (
                    "strict mode requires additionalProperties=False on every object"
                )
            for value in node.values():
                _walk(value)
            # Any field with an empty schema (`{}`) is non-strict.
            assert node != {}, "strict mode rejects empty-schema (`{}`) fields"
        elif isinstance(node, list):
            for item in node:
                _walk(item)

    _walk(schema)


# --- Live test (skipped without API key) -------------------------------------


@pytest.mark.live
@pytest.mark.skipif(
    not os.environ.get("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY not set; skipping live OpenAI test",
)
def test_openai_client_live_smoke(cost_logger):  # pragma: no cover - network
    from ml4t.agent.llm import OpenAIClient
    from ml4t.agent.llm.base import Message

    client = OpenAIClient()
    response = client.complete_with_schema(
        [Message(role="user", content="Reply with answer='hello'.")],
        {
            "type": "object",
            "properties": {"answer": {"type": "string"}},
            "required": ["answer"],
            "additionalProperties": False,
        },
        max_tokens=64,
    )
    assert "answer" in response.data
    cost_logger("openai", "gpt-5-mini", response.usage)
