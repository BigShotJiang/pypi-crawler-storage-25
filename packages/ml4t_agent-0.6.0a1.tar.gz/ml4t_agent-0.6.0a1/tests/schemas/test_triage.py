"""TriageEntry + `feature_triage_has_stop` predicate semantics (v0.4).

The runner-contract that populates `EvidencePack.triage` lands in v0.6;
until then real packs leave `triage=None` and the predicate raises
`PredicateUnavailable`. These tests pin the three-state semantics
(``None`` → unavailable, ``()`` → False, non-empty → evaluate) and
the severity gate (only BLOCKING/MATERIAL STOP entries gate T-F1).
"""

from __future__ import annotations

from dataclasses import replace

import pytest

from ml4t.agent.schemas import (
    PREDICATES,
    EvidencePack,
    PredicateUnavailable,
    Severity,
    TriageEntry,
)


def _stop(name: str = "regime_x", severity: Severity = Severity.MATERIAL) -> TriageEntry:
    return TriageEntry(
        feature_name=name,
        status="STOP",
        reason="suspect timestamp; possible look-ahead",
        severity=severity,
    )


def _go(name: str = "rsi_14") -> TriageEntry:
    return TriageEntry(
        feature_name=name,
        status="GO",
        reason="standard momentum indicator",
        severity=Severity.WARNING,
    )


def test_triage_default_is_none(sample_pack: EvidencePack) -> None:
    """Backward-compat: existing fixtures don't set triage; default is None."""

    assert sample_pack.triage is None


def test_predicate_unavailable_when_triage_is_none(sample_pack: EvidencePack) -> None:
    """`triage=None` means the runner has not exposed the contract."""

    with pytest.raises(PredicateUnavailable):
        PREDICATES["feature_triage_has_stop"](sample_pack)


def test_predicate_false_when_triage_empty(sample_pack: EvidencePack) -> None:
    """Empty tuple is a real "ran-and-found-no-stops" verdict, not unavailable."""

    pack = replace(sample_pack, triage=())
    assert PREDICATES["feature_triage_has_stop"](pack) is False


def test_predicate_false_when_only_go_entries(sample_pack: EvidencePack) -> None:
    pack = replace(sample_pack, triage=(_go("rsi_14"), _go("macd_12_26_9")))
    assert PREDICATES["feature_triage_has_stop"](pack) is False


def test_predicate_true_when_material_stop_present(sample_pack: EvidencePack) -> None:
    pack = replace(sample_pack, triage=(_go("rsi_14"), _stop("regime_x")))
    assert PREDICATES["feature_triage_has_stop"](pack) is True


def test_predicate_true_when_blocking_stop_present(sample_pack: EvidencePack) -> None:
    pack = replace(sample_pack, triage=(_stop("leak_pe", severity=Severity.BLOCKING),))
    assert PREDICATES["feature_triage_has_stop"](pack) is True


def test_predicate_false_when_only_warning_stop(sample_pack: EvidencePack) -> None:
    """A STOP entry at WARNING severity does not gate T-F1 — mirrors the
    BLOCKING/MATERIAL gating convention used elsewhere (e.g.
    `methodology_warning_cites_lineage`)."""

    pack = replace(sample_pack, triage=(_stop("noisy_x", severity=Severity.WARNING),))
    assert PREDICATES["feature_triage_has_stop"](pack) is False


def test_review_status_does_not_gate(sample_pack: EvidencePack) -> None:
    """REVIEW entries are not actionable for T-F1 — only STOP triggers exclusion."""

    review = TriageEntry(
        feature_name="ambiguous_x",
        status="REVIEW",
        reason="manual inspection required",
        severity=Severity.MATERIAL,
    )
    pack = replace(sample_pack, triage=(review,))
    assert PREDICATES["feature_triage_has_stop"](pack) is False
