"""Round-2 reviewer-driven smoke tests for `agent_ml4t_schemas.py`.

These exercise the proof points required by `gpt-03.md` and `opus-03.md`:

- Bonferroni adjusts alpha downward as iterations accumulate (sign correct)
- Stage D combining rule supports/contradicts/inconclusive on point + interval
- T-C1 survival framing: absolute floor at 1.0
- ConfigPatch values rejected when not matching the OverrideSpec
- Forbidden-patch matrix: holdout paths, illegal value, ineligible template,
  wrong stage invocation, missing artifact, bonferroni drift
- Predicates raise on missing artifacts (distinct from returning False)
- Holdout seal is structural (pack.holdout is None), not self-reported
"""

from __future__ import annotations

from dataclasses import replace
from types import MappingProxyType

import pytest

from ml4t.agent.schemas import (
    PREDICATES,
    ArtifactContract,
    BacktestSummary,
    ConfigPatch,
    CostSummary,
    Decision,
    DeltaCriterion,
    DeltaOutcome,
    Determinism,
    EvidencePack,
    ExperimentPlan,
    ExperimentTemplate,
    Finding,
    HoldoutMetrics,
    IterationCategory,
    LineageSummary,
    LineState,
    MethodologyWarning,
    ModelRunSummary,
    OverrideSpec,
    PlanValidationError,
    PredicateUnavailable,
    ResearchEvidenceReview,
    RobustnessSummary,
    Severity,
    SignalSummary,
    StageInvocation,
    TemplateMaturity,
    ValidationDesign,
    ValidationMetrics,
    recommend_decision,
    validate_plan,
)

# --- Fixtures ----------------------------------------------------------------


def _design() -> ValidationDesign:
    return ValidationDesign(
        n_splits=8,
        train_size="10Y",
        val_size="1Y",
        holdout_start="2024-01-01",
        holdout_end="2025-12-31",
        embargo_days=21,
        purge_days=21,
        fold_calendar_id="etf_2014_2023_v1",
    )


def _costs() -> CostSummary:
    return CostSummary(
        per_leg_bps_low=5.0,
        per_leg_bps_high=15.0,
        cost_class="moderate",
        components=("commission", "spread"),
    )


def _lineage() -> LineageSummary:
    return LineageSummary(
        git_sha="deadbeef",
        data_snapshot_id="snap-2024",
        config_hash="abc123",
        package_versions=MappingProxyType({"polars": "1.0", "lightgbm": "4.3"}),
    )


def _validation_clean() -> ValidationMetrics:
    return ValidationMetrics(
        model_runs=(
            ModelRunSummary(
                family="gbm",
                config_name="g1",
                label="fwd_ret_21d",
                mean_fold_ic=0.025,
                fold_ic_std=0.010,
                fold_sharpe_mean=0.6,
                fold_sharpe_std=0.2,
                n_folds=8,
            ),
        ),
        signal=SignalSummary(
            best_family="gbm",
            best_config="g1",
            best_mean_ic=0.025,
            ic_t_stat=2.5,
            horizons_tested=("21d",),
        ),
        backtests=(
            BacktestSummary(
                config_id="bench",
                family="benchmark",
                gross_sharpe=0.40,
                net_sharpe=0.35,
                max_drawdown=-0.10,
                mean_monthly_turnover=0.05,
                edge_to_cost_ratio=2.0,
            ),
            BacktestSummary(
                config_id="strat-gbm",
                family="gbm",
                gross_sharpe=0.90,
                net_sharpe=0.55,
                max_drawdown=-0.15,
                mean_monthly_turnover=0.45,
                edge_to_cost_ratio=1.6,
            ),
        ),
        robustness=RobustnessSummary(
            fold_sharpe_dispersion=0.6,
            regime_breakdown_available=True,
            seed_variance_estimate=0.02,
        ),
    )


def _pack(holdout: HoldoutMetrics | None = None, warnings: tuple = ()) -> EvidencePack:
    return EvidencePack(
        case_study="etfs",
        objective="post-baseline iteration",
        primary_label="fwd_ret_21d",
        horizon="21d",
        cadence="monthly",
        parent_run_id="P1",
        line_id="L1",
        validation_design=_design(),
        validation=_validation_clean(),
        holdout=holdout,
        costs=_costs(),
        lineage=_lineage(),
        warnings=warnings,
    )


def _tc1_spec() -> OverrideSpec:
    return OverrideSpec(
        path_template="config/setup.yaml",
        yaml_path=("costs", "per_leg_cost_bps_range"),
        value_type="tuple[float, float]",
        min_value=0.0,
        max_value=100.0,
        description="upper bound for stricter cost rerun",
    )


def _tc1_criterion(k: int = 1) -> DeltaCriterion:
    return DeltaCriterion(
        primary_metric="edge_to_cost_ratio_after",
        metric_kind="absolute",
        support_threshold=1.0,
        reject_threshold=1.0,
        direction="higher_is_better",
        noise_floor_method="simple_bootstrap",
        base_alpha=0.05,
        bonferroni_k=k,
    )


def _tc1_template() -> ExperimentTemplate:
    return ExperimentTemplate(
        template_id="T-C1",
        category=IterationCategory.COST,
        maturity=TemplateMaturity.CONCRETE,
        question="Does the apparent net edge survive cost realism at the upper bound?",
        preconditions=("has_clean_validity",),
        forbidden_when=(Severity.BLOCKING,),
        allowed_overrides=(_tc1_spec(),),
        forbidden_paths=(("evaluation", "holdout_start"), ("labels",)),
        stage_invocations=(
            StageInvocation(script="16_costs.py"),
            StageInvocation(script="14_backtest.py"),
            StageInvocation(script="18_strategy_analysis.py"),
        ),
        expected_artifacts=(
            ArtifactContract(
                relative_path="results/strategy_assessment.json",
                schema_id="strategy_assessment_v1",
            ),
        ),
        delta_criterion_template=_tc1_criterion(k=1),
        expected_information_value=0.6,
        relative_cost=0.1,
    )


def _tc1_plan(
    template: ExperimentTemplate,
    *,
    bonferroni_k: int = 1,
    new_value=(15.0, 25.0),
    yaml_path: tuple[str, ...] = ("costs", "per_leg_cost_bps_range"),
    stage_invocations=None,
) -> ExperimentPlan:
    return ExperimentPlan(
        experiment_id="E-tc1-1",
        template_id="T-C1",
        parent_run_id="P1",
        comparison_target_id="bench",
        config_patches=(
            ConfigPatch(
                path_template="config/setup.yaml",
                path_variables=(),
                yaml_path=yaml_path,
                new_value=list(new_value) if isinstance(new_value, tuple) else new_value,
            ),
        ),
        stage_invocations=stage_invocations or template.stage_invocations,
        expected_artifacts=template.expected_artifacts,
        delta_criterion=_tc1_criterion(k=bonferroni_k),
        question=template.question,
        hypothesis="net edge >= 1.0x at upper-bound costs",
        rationale="cites validation.backtests[strat-gbm].edge_to_cost_ratio=1.6",
    )


# --- Bonferroni sign ---------------------------------------------------------


def test_bonferroni_alpha_shrinks_with_k():
    c1 = _tc1_criterion(k=1)
    c4 = _tc1_criterion(k=4)
    assert c1.adjusted_alpha == 0.05
    assert c4.adjusted_alpha == pytest.approx(0.0125)
    assert c4.adjusted_alpha < c1.adjusted_alpha
    assert c4.adjusted_confidence_level > c1.adjusted_confidence_level


def test_bonferroni_makes_support_harder_at_higher_k():
    """A wider CI (constructed at adjusted alpha) is harder to clear the
    support threshold. We simulate this directly by passing wider intervals
    at higher k; the Stage D engine will produce the wider CI when k > 1."""

    crit = DeltaCriterion(
        primary_metric="net_sharpe_delta",
        metric_kind="delta",
        support_threshold=0.10,
        reject_threshold=0.0,
        direction="higher_is_better",
        noise_floor_method="block_bootstrap_21d",
        base_alpha=0.05,
        bonferroni_k=1,
    )
    crit_k4 = replace(crit, bonferroni_k=4)
    # k=1, narrow CI: clears support
    assert crit.evaluate(0.155, 0.11, 0.20) == DeltaOutcome.SUPPORTED
    # k=4, wider CI: same point estimate, no longer clears support
    assert crit_k4.evaluate(0.155, 0.08, 0.23) == DeltaOutcome.INCONCLUSIVE


# --- Stage D combining rule --------------------------------------------------


def test_stage_d_combining_rule_higher_is_better():
    crit = _tc1_criterion(k=1)
    assert crit.evaluate(1.4, 1.1, 1.7) == DeltaOutcome.SUPPORTED
    assert crit.evaluate(0.6, 0.3, 0.9) == DeltaOutcome.CONTRADICTED
    assert crit.evaluate(1.05, 0.85, 1.30) == DeltaOutcome.INCONCLUSIVE


def test_stage_d_combining_rule_lower_is_better():
    crit = DeltaCriterion(
        primary_metric="fold_sharpe_dispersion",
        metric_kind="delta",
        support_threshold=-0.20,
        reject_threshold=0.05,
        direction="lower_is_better",
        noise_floor_method="block_bootstrap_21d",
    )
    # interval entirely <= -0.20 -> supported
    assert crit.evaluate(-0.30, -0.45, -0.21) == DeltaOutcome.SUPPORTED
    # interval entirely >= +0.05 -> contradicted
    assert crit.evaluate(+0.10, +0.06, +0.20) == DeltaOutcome.CONTRADICTED
    # straddles -> inconclusive
    assert crit.evaluate(-0.10, -0.30, +0.10) == DeltaOutcome.INCONCLUSIVE


def test_evaluate_rejects_inverted_interval():
    crit = _tc1_criterion(k=1)
    with pytest.raises(ValueError):
        crit.evaluate(1.0, 1.5, 0.5)


# --- T-C1 survival framing ---------------------------------------------------


def test_tc1_survival_passes_when_lower_ci_clears_floor():
    """T-C1 asks: does net edge survive stricter costs? Survival is encoded
    as `interval_low >= 1.0` on the post-rerun absolute level."""

    crit = _tc1_criterion(k=1)
    assert crit.metric_kind == "absolute"
    assert crit.evaluate(1.4, 1.1, 1.7) == DeltaOutcome.SUPPORTED


def test_tc1_survival_fails_when_upper_ci_below_floor():
    crit = _tc1_criterion(k=1)
    assert crit.evaluate(0.7, 0.5, 0.95) == DeltaOutcome.CONTRADICTED


# --- OverrideSpec value validation -------------------------------------------


@pytest.mark.parametrize(
    "bad",
    [
        "banana",
        [500, -20],  # inverted bounds
        [0, 0, 0],  # wrong cardinality
        (5, "x"),  # mixed type
    ],
)
def test_override_spec_rejects_malformed_values(bad):
    spec = _tc1_spec()
    with pytest.raises(PlanValidationError):
        spec.validate_value(bad)


def test_override_spec_accepts_valid_value():
    _tc1_spec().validate_value([15.0, 25.0])


# --- Predicates raise on missing artifacts -----------------------------------


def test_signal_positive_net_weak_raises_when_no_benchmark():
    pack = replace(
        _pack(),
        validation=replace(
            _pack().validation,
            backtests=tuple(b for b in _pack().validation.backtests if b.family != "benchmark"),
        ),
    )
    with pytest.raises(PredicateUnavailable):
        PREDICATES["signal_positive_net_weak"](pack)


def test_signal_positive_net_weak_returns_false_when_evaluable():
    """Strong-IC, strong-strategy case: predicate can evaluate and the
    condition is False (strategy beats benchmark net Sharpe)."""

    pack = _pack()
    assert PREDICATES["signal_positive_net_weak"](pack) is False


def test_predicate_unavailable_distinct_from_false():
    pack_no_benchmark = replace(
        _pack(),
        validation=replace(
            _pack().validation,
            backtests=(
                BacktestSummary(
                    config_id="strat-gbm",
                    family="gbm",
                    gross_sharpe=0.9,
                    net_sharpe=0.55,
                    max_drawdown=-0.15,
                    mean_monthly_turnover=0.45,
                    edge_to_cost_ratio=1.6,
                ),
            ),
        ),
    )
    template = _tc1_template()
    template_with_signal_check = replace(
        template, preconditions=("has_clean_validity", "signal_positive_net_weak")
    )
    eligible, reason = template_with_signal_check.is_eligible(pack_no_benchmark)
    assert eligible is False
    assert reason.startswith("unavailable:signal_positive_net_weak"), reason


# --- Structural holdout seal -------------------------------------------------


def test_holdout_sealed_predicate_is_structural():
    assert PREDICATES["holdout_sealed"](_pack()) is True
    populated = replace(
        _pack(),
        holdout=HoldoutMetrics(
            model_runs=_validation_clean().model_runs,
            signal=_validation_clean().signal,
            backtests=_validation_clean().backtests,
        ),
    )
    assert PREDICATES["holdout_sealed"](populated) is False


def test_validate_plan_rejects_iteration_when_holdout_populated():
    template = _tc1_template()
    plan = _tc1_plan(template)
    populated = replace(
        _pack(),
        holdout=HoldoutMetrics(
            model_runs=_validation_clean().model_runs,
            signal=_validation_clean().signal,
            backtests=_validation_clean().backtests,
        ),
    )
    line = LineState(line_id="L1", iteration_index=1)
    with pytest.raises(PlanValidationError, match="holdout is populated"):
        validate_plan(plan, template, populated, line)


# --- validate_plan: full forbidden-patch matrix ------------------------------


def test_validate_plan_accepts_clean_plan():
    template = _tc1_template()
    plan = _tc1_plan(template)
    line = LineState(line_id="L1", iteration_index=1)
    validate_plan(plan, template, _pack(), line)


def test_validate_plan_rejects_illegal_value():
    template = _tc1_template()
    plan = _tc1_plan(template, new_value="banana")
    line = LineState(line_id="L1", iteration_index=1)
    with pytest.raises(PlanValidationError):
        validate_plan(plan, template, _pack(), line)


def test_validate_plan_rejects_holdout_touching_path():
    template = _tc1_template()
    bad_plan = ExperimentPlan(
        experiment_id="E-bad",
        template_id="T-C1",
        parent_run_id="P1",
        comparison_target_id="bench",
        config_patches=(
            ConfigPatch(
                path_template="config/setup.yaml",
                path_variables=(),
                yaml_path=("evaluation", "holdout_start"),
                new_value="2025-01-01",
            ),
        ),
        stage_invocations=template.stage_invocations,
        expected_artifacts=template.expected_artifacts,
        delta_criterion=_tc1_criterion(k=1),
        question=template.question,
        hypothesis="x",
        rationale="x",
    )
    line = LineState(line_id="L1", iteration_index=1)
    with pytest.raises(PlanValidationError):
        validate_plan(bad_plan, template, _pack(), line)


def test_validate_plan_rejects_stage_tampering():
    template = _tc1_template()
    plan = _tc1_plan(template, stage_invocations=(StageInvocation(script="16_costs.py"),))
    line = LineState(line_id="L1", iteration_index=1)
    with pytest.raises(PlanValidationError, match="stage_invocations"):
        validate_plan(plan, template, _pack(), line)


def test_validate_plan_rejects_bonferroni_k_drift():
    template = _tc1_template()
    plan = _tc1_plan(template, bonferroni_k=3)
    line = LineState(line_id="L1", iteration_index=1)
    with pytest.raises(PlanValidationError, match="bonferroni_k"):
        validate_plan(plan, template, _pack(), line)


def test_validate_plan_rejects_ineligible_template_via_blocking_warning():
    template = _tc1_template()
    plan = _tc1_plan(template)
    blocking = MethodologyWarning(
        code="EMBARGO_MISSING",
        message="overlapping forward returns with no embargo",
        severity=Severity.BLOCKING,
        determinism=Determinism.ARITHMETIC,
        triggering_artifact="config/setup.yaml",
        triggering_field="evaluation.embargo_days",
    )
    pack = _pack(warnings=(blocking,))
    line = LineState(line_id="L1", iteration_index=1)
    with pytest.raises(PlanValidationError, match="not eligible"):
        validate_plan(plan, template, pack, line)


def test_validate_plan_rejects_iteration_beyond_budget():
    template = _tc1_template()
    plan = _tc1_plan(template, bonferroni_k=6)
    line = LineState(line_id="L1", iteration_index=6, max_iterations=5)
    with pytest.raises(PlanValidationError, match="exceeds"):
        validate_plan(plan, template, _pack(), line)


def test_validate_plan_rejects_missing_artifact_contract():
    template = _tc1_template()
    plan = ExperimentPlan(
        experiment_id="E-x",
        template_id="T-C1",
        parent_run_id="P1",
        comparison_target_id="bench",
        config_patches=(
            ConfigPatch(
                path_template="config/setup.yaml",
                path_variables=(),
                yaml_path=("costs", "per_leg_cost_bps_range"),
                new_value=[15.0, 25.0],
            ),
        ),
        stage_invocations=template.stage_invocations,
        expected_artifacts=(),  # empty: missing the required template artifact
        delta_criterion=_tc1_criterion(k=1),
        question=template.question,
        hypothesis="x",
        rationale="x",
    )
    line = LineState(line_id="L1", iteration_index=1)
    with pytest.raises(PlanValidationError, match="missing required template artifacts"):
        validate_plan(plan, template, _pack(), line)


# --- Decision table ----------------------------------------------------------


def test_decision_blocking_finding_routes_to_audit():
    review = ResearchEvidenceReview(
        decision=Decision.AUDIT_REQUIRED,
        findings=(
            Finding(
                area="validity",
                severity=Severity.BLOCKING,
                summary="overlap",
                cited_fields=("validation_design.embargo_days",),
            ),
        ),
        open_questions=(),
        supporting_template_ids=(),
    )
    line = LineState(line_id="L1", iteration_index=1)
    assert recommend_decision(review, None, line, 0, 0) == Decision.AUDIT_REQUIRED


def test_decision_iteration_budget_reached_stops_line():
    line = LineState(line_id="L1", iteration_index=5, max_iterations=5)
    assert recommend_decision(None, None, line, 0, 0) == Decision.STOP_RESEARCH_LINE


def test_decision_audit_budget_consumed_stops_line():
    line = LineState(line_id="L1", iteration_index=2, max_iterations=5)
    assert recommend_decision(None, None, line, 0, 5) == Decision.STOP_RESEARCH_LINE


def test_decision_two_inconclusive_stops_line():
    line = LineState(line_id="L1", iteration_index=3, max_iterations=5)
    assert recommend_decision(None, None, line, 2, 0) == Decision.STOP_RESEARCH_LINE


def test_decision_supported_at_iter1_continues():
    """Single supported delta at iteration 1 is not yet mature for holdout."""

    from ml4t.agent.schemas import DeltaReview

    line = LineState(line_id="L1", iteration_index=1, max_iterations=5)
    delta = DeltaReview(
        experiment_id="E1",
        primary_metric="edge_to_cost_ratio_after",
        metric_kind="absolute",
        before=2.0,
        after=1.4,
        point_estimate=1.4,
        interval_low=1.1,
        interval_high=1.7,
        fold_deltas=(),
        cost_sensitivity=(),
        outcome=DeltaOutcome.SUPPORTED,
    )
    assert recommend_decision(None, delta, line, 0, 0) == Decision.ITERATE_OFFLINE


def test_decision_supported_at_iter2_advances_to_holdout():
    from ml4t.agent.schemas import DeltaReview

    line = LineState(line_id="L1", iteration_index=2, max_iterations=5)
    delta = DeltaReview(
        experiment_id="E2",
        primary_metric="edge_to_cost_ratio_after",
        metric_kind="absolute",
        before=2.0,
        after=1.4,
        point_estimate=1.4,
        interval_low=1.1,
        interval_high=1.7,
        fold_deltas=(),
        cost_sensitivity=(),
        outcome=DeltaOutcome.SUPPORTED,
    )
    assert recommend_decision(None, delta, line, 0, 0) == Decision.ADVANCE_TO_HOLDOUT_REVIEW


def test_decision_contradicted_stops_line():
    from ml4t.agent.schemas import DeltaReview

    line = LineState(line_id="L1", iteration_index=2, max_iterations=5)
    delta = DeltaReview(
        experiment_id="E2",
        primary_metric="edge_to_cost_ratio_after",
        metric_kind="absolute",
        before=2.0,
        after=0.6,
        point_estimate=0.6,
        interval_low=0.4,
        interval_high=0.85,
        fold_deltas=(),
        cost_sensitivity=(),
        outcome=DeltaOutcome.CONTRADICTED,
    )
    assert recommend_decision(None, delta, line, 0, 0) == Decision.STOP_RESEARCH_LINE


# --- Severity model ----------------------------------------------------------


def test_severity_no_informational_value():
    """`INFORMATIONAL` was removed; benign metadata mismatches go to
    `DiagnosticNote` so they do not pollute methodology severity."""

    assert {s.value for s in Severity} == {"blocking", "material", "warning"}


def test_methodology_warning_requires_determinism_class():
    """Every MethodologyWarning declares whether it is computable from
    on-disk artifacts (`ARITHMETIC`) or a runner-contract assertion."""

    w = MethodologyWarning(
        code="FOLD_DISPERSION_HIGH",
        message="fold_sharpe_std > 0.5 * |mean|",
        severity=Severity.MATERIAL,
        determinism=Determinism.ARITHMETIC,
        triggering_artifact="model_runs",
        triggering_field="fold_sharpe_std",
    )
    assert w.determinism is Determinism.ARITHMETIC


# --- Template maturity -------------------------------------------------------


def test_template_maturity_is_first_class():
    assert TemplateMaturity.CONCRETE.value == "concrete"
    assert TemplateMaturity.CANDIDATE.value == "candidate"
    template = _tc1_template()
    assert template.maturity is TemplateMaturity.CONCRETE
