"""End-to-end smoke test wiring agent + tools + tracing + handoff together.

The unit tests in ``tests/agents/test_single.py`` cover the loop branches
in isolation. This file exercises the *cross-module* contracts that
plan 28 promises but no single unit test verifies:

1. A full run feeds a typed ExperimentPlan into the coding-agent handoff
   without re-parsing.
2. Iterating the line advances the bonferroni denominator on every
   produced plan.
3. The full AgentRun (with populated traces and final_artifact) survives
   a JSON round-trip.
4. validate_plan is the gate that protects discipline: a plan with the
   wrong bonferroni_k must be rejected end-to-end.
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any

import pytest

from ml4t.agent.agents import DELTA_REVIEW_FILENAME, ResearchReviewAgent
from ml4t.agent.discipline import bonferroni_alpha_for_iteration
from ml4t.agent.llm import LLMResponse, Message, MockLLMClient
from ml4t.agent.schemas import (
    Decision,
    EvidencePack,
    LineState,
    PlanValidationError,
    ResearchNote,
    validate_plan,
)
from ml4t.agent.tools import (
    build_tc1_template,
    render_experiment_spec,
    write_experiment_spec_for_coding_agent,
)
from ml4t.agent.tracing import trace_from_json, trace_to_json

SUPPORTED_REVIEW: dict[str, Any] = {
    "experiment_id": "E-tc1-1",
    "primary_metric": "edge_to_cost_ratio_after",
    "metric_kind": "absolute",
    "before": 1.6,
    "after": 1.32,
    "point_estimate": 1.32,
    "interval_low": 1.10,
    "interval_high": 1.55,
    "fold_deltas": [-0.30, -0.25, -0.28, -0.32],
    "cost_sensitivity": [[15.0, 1.55], [25.0, 1.32]],
    "outcome": "supported",
    "recommendation": "iterate_offline",
    "rationale": "edge survives the 25bps stress test",
}


def _proposal_payload(experiment_id: str = "E-tc1-1") -> dict[str, Any]:
    return {
        "experiment_id": experiment_id,
        "template_id": "T-C1",
        "comparison_target_id": "strat-gbm",
        "hypothesis": "net edge >= 1.0x at 25 bps upper bound",
        "rationale": "stricter cost bound tests survival floor",
        "config_patches": [
            {
                "path_template": "config/setup.yaml",
                "path_variables": {},
                "yaml_path": ["costs", "per_leg_cost_bps_range"],
                "new_value": [15.0, 25.0],
            }
        ],
    }


def _mock_llm(payloads: Sequence[dict[str, Any]] | None = None) -> MockLLMClient:
    body_payloads = list(payloads) if payloads is not None else [_proposal_payload()]

    def responder(_m: Sequence[Message], _s: Mapping[str, Any]) -> LLMResponse:
        body = {"proposals": body_payloads}
        return LLMResponse(data=body, raw=str(body))

    return MockLLMClient(responder=responder)


@pytest.fixture
def clean_pack(sample_pack: EvidencePack) -> EvidencePack:
    return replace(sample_pack, warnings=())


@pytest.fixture
def clean_run(tmp_path: Path, clean_pack: EvidencePack) -> Path:
    """A run-dir with no methodology warnings and a delta_review artifact."""
    (tmp_path / "evidence_pack.json").write_text(
        json.dumps(asdict(clean_pack), default=str), encoding="utf-8"
    )
    (tmp_path / "cost_sensitivity.json").write_text(
        json.dumps(
            {"cost_class": "liquid_etf_blend", "components": ["commission", "spread", "impact"]}
        ),
        encoding="utf-8",
    )
    (tmp_path / DELTA_REVIEW_FILENAME.format(template_id="T-C1")).write_text(
        json.dumps(SUPPORTED_REVIEW), encoding="utf-8"
    )
    return tmp_path


def test_full_pipeline_feeds_handoff_without_reparsing(clean_run: Path, tmp_path: Path) -> None:
    line = LineState(line_id="L-1", iteration_index=1, base_alpha=0.05)
    agent = ResearchReviewAgent(_mock_llm(), line_state=line)

    note = agent.run(clean_run)

    assert isinstance(note, ResearchNote)
    plan = note.proposals[0]
    spec_path = tmp_path / "spec.md"
    written = write_experiment_spec_for_coding_agent(plan, spec_path)

    assert written == spec_path
    body = spec_path.read_text(encoding="utf-8")
    assert plan.experiment_id in body
    assert plan.template_id in body
    assert "## Config patches" in body
    assert "costs.per_leg_cost_bps_range" in body
    assert "## Delta criterion" in body
    assert body == render_experiment_spec(plan)


def test_iteration_advances_bonferroni_denominator(
    clean_run: Path, clean_pack: EvidencePack
) -> None:
    """Plan 28 §6: bonferroni_k must equal line_state.iteration_index."""

    base_alpha = 0.05
    template = build_tc1_template()

    for iteration in (1, 2, 3):
        line = LineState(line_id="L-1", iteration_index=iteration, base_alpha=base_alpha)
        agent = ResearchReviewAgent(_mock_llm(), line_state=line)
        note = agent.run(clean_run)

        plan = note.proposals[0]
        crit = plan.delta_criterion
        assert crit.bonferroni_k == iteration
        assert crit.adjusted_alpha == pytest.approx(
            bonferroni_alpha_for_iteration(base_alpha, iteration)
        )
        # validate_plan is the schema-level gate; it must accept agent output.
        validate_plan(plan, template=template, pack=clean_pack, line_state=line)


def test_agent_run_json_round_trip_preserves_traces(clean_run: Path) -> None:
    line = LineState(line_id="L-1", iteration_index=1, base_alpha=0.05)
    agent = ResearchReviewAgent(_mock_llm(), line_state=line)
    agent.run(clean_run)
    assert agent.last_run is not None

    payload = trace_to_json(agent.last_run)
    restored = trace_from_json(payload)

    assert restored.run_id == agent.last_run.run_id
    assert restored.agent_id == agent.last_run.agent_id
    assert len(restored.traces) == len(agent.last_run.traces)
    original_actions = [t.action for t in agent.last_run.traces]
    restored_actions = [t.action for t in restored.traces]
    assert restored_actions == original_actions
    assert restored.final_artifact == agent.last_run.final_artifact


def test_validate_plan_rejects_wrong_bonferroni_k(
    clean_run: Path, clean_pack: EvidencePack
) -> None:
    """If a plan ever escapes with the wrong bonferroni_k, the schema gate
    must catch it before the coding agent ever sees it."""

    template = build_tc1_template()
    line = LineState(line_id="L-1", iteration_index=2, base_alpha=0.05)
    agent = ResearchReviewAgent(_mock_llm(), line_state=line)
    note = agent.run(clean_run)
    plan = note.proposals[0]
    assert plan.delta_criterion.bonferroni_k == 2
    # Sanity: plan validates against its own line state.
    validate_plan(plan, template=template, pack=clean_pack, line_state=line)

    # Same plan, different line state -> mismatch must be rejected.
    other_line = LineState(line_id="L-1", iteration_index=3, base_alpha=0.05)
    with pytest.raises(PlanValidationError, match="bonferroni_k"):
        validate_plan(plan, template=template, pack=clean_pack, line_state=other_line)


def test_decision_advances_to_holdout_after_two_supported_iterations(clean_run: Path) -> None:
    """The line-maturity contract: iteration 1 stays offline, iteration 2
    with a supported delta advances to holdout review. This is the
    multi-step claim the chapter prose will lean on."""

    line_iter1 = LineState(line_id="L-1", iteration_index=1, base_alpha=0.05)
    note_iter1 = ResearchReviewAgent(_mock_llm(), line_state=line_iter1).run(clean_run)
    assert note_iter1.decision is Decision.ITERATE_OFFLINE

    line_iter2 = LineState(line_id="L-1", iteration_index=2, base_alpha=0.05)
    note_iter2 = ResearchReviewAgent(_mock_llm(), line_state=line_iter2).run(clean_run)
    assert note_iter2.decision is Decision.ADVANCE_TO_HOLDOUT_REVIEW
    # Both iterations must reference the same parent run lineage.
    assert note_iter1.parent_run_id == note_iter2.parent_run_id == "P-1"
