"""End-to-end tests for the v0.2 catalogue paths through ResearchReviewAgent.

Mirrors `test_single.py`'s structure but exercises the T-A2 (lineage
recheck) and T-M1 (narrow GBM search) branches of the agent's rerun
dispatch and ensures the resulting `ResearchNote` carries the right
template_id and decision.
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any

import pytest

from ml4t.agent.agents import DELTA_REVIEW_FILENAME, ResearchReviewAgent
from ml4t.agent.llm import LLMResponse, Message, MockLLMClient
from ml4t.agent.schemas import (
    Decision,
    DeltaOutcome,
    Determinism,
    EvidencePack,
    LineState,
    MethodologyWarning,
    ModelRunSummary,
    Severity,
    ValidationMetrics,
)
from ml4t.agent.tools.reruns import LINEAGE_RECHECK_FILENAME, NARROW_GBM_FILENAME

# `_ta2_proposal_payload` and `_tm1_proposal_payload` come from this file's
# sibling `conftest.py` indirectly via re-import, but they're private helpers
# — we replicate them locally to keep the test self-contained and readable.


def _make_mock_llm(payload: dict[str, Any]) -> MockLLMClient:
    def responder(_m: Sequence[Message], _s: Mapping[str, Any]) -> LLMResponse:
        body = {"proposals": [payload]}
        return LLMResponse(data=body, raw=str(body))

    return MockLLMClient(responder=responder)


def _ta2_proposal() -> dict[str, Any]:
    return {
        "experiment_id": "E-ta2-1",
        "template_id": "T-A2",
        "comparison_target_id": "strat-gbm",
        "hypothesis": "rerun reproduces parent IC within tolerance",
        "rationale": "lineage warning cites config_hash mismatch",
        "config_patches": [],
    }


def _tm1_proposal() -> dict[str, Any]:
    return {
        "experiment_id": "E-tm1-1",
        "template_id": "T-M1",
        "comparison_target_id": "strat-gbm",
        "hypothesis": "narrowed GBM list improves within-family IC by >=0.005",
        "rationale": "GBM dispersion is large; concentrate the preset list",
        "config_patches": [
            {
                "path_template": "config/training/{label}.yaml",
                "path_variables": {"label": "ret_5d"},
                "yaml_path": ["gbm"],
                "new_value": ["gbm_shallow", "gbm_balanced"],
            }
        ],
    }


# --- Pack fixtures ----------------------------------------------------------


@pytest.fixture
def lineage_pack(sample_pack: EvidencePack) -> EvidencePack:
    """sample_pack with a MATERIAL lineage warning — T-A2 eligible."""

    return replace(
        sample_pack,
        warnings=(
            MethodologyWarning(
                code="LINEAGE_CONFIG_HASH_MISMATCH",
                message="parent_run config_hash does not match HEAD",
                severity=Severity.MATERIAL,
                determinism=Determinism.ARITHMETIC,
                triggering_artifact="lineage/receipts.json",
                triggering_field="config_hash",
            ),
        ),
    )


@pytest.fixture
def gbm_dispersion_pack(sample_pack: EvidencePack) -> EvidencePack:
    high_dispersion_gbm = ModelRunSummary(
        family="gbm",
        config_name="lgb_d6",
        label="ret_5d",
        mean_fold_ic=0.024,
        fold_ic_std=0.020,
        fold_sharpe_mean=0.55,
        fold_sharpe_std=0.30,
        n_folds=8,
    )
    runs = tuple(
        high_dispersion_gbm if r.family == "gbm" else r for r in sample_pack.validation.model_runs
    )
    new_metrics = ValidationMetrics(
        model_runs=runs,
        signal=replace(sample_pack.validation.signal, best_family="gbm"),
        backtests=sample_pack.validation.backtests,
        robustness=sample_pack.validation.robustness,
    )
    return replace(sample_pack, warnings=(), validation=new_metrics)


# --- Run-dir fixtures -------------------------------------------------------


def _write_pack(run_dir: Path, pack: EvidencePack) -> None:
    (run_dir / "evidence_pack.json").write_text(
        json.dumps(asdict(pack), default=str), encoding="utf-8"
    )


def _write_lineage_artifact(run_dir: Path) -> None:
    (run_dir / LINEAGE_RECHECK_FILENAME).write_text(
        json.dumps(
            {
                "mean_fold_ic_after": 0.023,
                "fold_ic_after": [0.023, 0.024, 0.022, 0.025],
                "git_sha_at_rerun": "abc1234",
                "package_versions_at_rerun": {"ml4t-engineer": "0.1.0b1"},
            }
        ),
        encoding="utf-8",
    )


def _write_narrow_gbm_artifact(run_dir: Path) -> None:
    (run_dir / NARROW_GBM_FILENAME).write_text(
        json.dumps(
            {
                "runs": [
                    {
                        "family": "gbm",
                        "config_name": "gbm_shallow",
                        "label": "ret_5d",
                        "mean_fold_ic": 0.026,
                        "fold_ic_std": 0.011,
                        "fold_sharpe_mean": 0.58,
                        "fold_sharpe_std": 0.18,
                        "n_folds": 8,
                    },
                    {
                        "family": "gbm",
                        "config_name": "gbm_balanced",
                        "label": "ret_5d",
                        "mean_fold_ic": 0.029,
                        "fold_ic_std": 0.010,
                        "fold_sharpe_mean": 0.62,
                        "fold_sharpe_std": 0.16,
                        "n_folds": 8,
                    },
                ]
            }
        ),
        encoding="utf-8",
    )


def _write_delta_review(
    run_dir: Path,
    template_id: str,
    *,
    outcome: str,
    primary_metric: str,
    metric_kind: str,
    point_estimate: float,
    interval_low: float,
    interval_high: float,
    before: float = 0.024,
    after: float | None = None,
) -> None:
    after_value = after if after is not None else point_estimate
    payload = {
        "experiment_id": f"E-{template_id.lower().replace('-', '')}-1",
        "primary_metric": primary_metric,
        "metric_kind": metric_kind,
        "before": before,
        "after": after_value,
        "point_estimate": point_estimate,
        "interval_low": interval_low,
        "interval_high": interval_high,
        "fold_deltas": [point_estimate, point_estimate, point_estimate],
        "cost_sensitivity": [],
        "outcome": outcome,
        "recommendation": "iterate_offline",
        "rationale": f"{template_id} delta review",
    }
    (run_dir / DELTA_REVIEW_FILENAME.format(template_id=template_id)).write_text(
        json.dumps(payload), encoding="utf-8"
    )


# --- T-A2 agent loop --------------------------------------------------------


def test_ta2_full_loop_supported(
    tmp_path: Path, lineage_pack: EvidencePack, line_state: LineState
) -> None:
    _write_pack(tmp_path, lineage_pack)
    _write_lineage_artifact(tmp_path)
    best_ic = lineage_pack.validation.signal.best_mean_ic
    _write_delta_review(
        tmp_path,
        "T-A2",
        outcome="supported",
        primary_metric="mean_fold_ic",
        metric_kind="absolute",
        point_estimate=best_ic - 0.001,
        interval_low=best_ic - 0.001,
        interval_high=best_ic + 0.001,
        before=best_ic,
    )

    agent = ResearchReviewAgent(_make_mock_llm(_ta2_proposal()), line_state=line_state)
    note = agent.run(tmp_path)
    assert note.selected_experiment_id == "E-ta2-1"
    assert note.proposals[0].template_id == "T-A2"
    assert note.delta_review is not None
    assert note.delta_review.outcome is DeltaOutcome.SUPPORTED
    # iteration 1 + supported -> ITERATE_OFFLINE (line not yet mature)
    assert note.decision is Decision.ITERATE_OFFLINE


def test_ta2_rerun_step_records_lineage_receipt(
    tmp_path: Path, lineage_pack: EvidencePack, line_state: LineState
) -> None:
    _write_pack(tmp_path, lineage_pack)
    _write_lineage_artifact(tmp_path)

    agent = ResearchReviewAgent(_make_mock_llm(_ta2_proposal()), line_state=line_state)
    agent.run(tmp_path)
    assert agent.last_run is not None
    rerun_traces = [t for t in agent.last_run.traces if t.action == "rerun"]
    assert len(rerun_traces) == 1
    assert rerun_traces[0].tool_name == "run_lineage_recheck"
    assert rerun_traces[0].outputs is not None
    assert rerun_traces[0].outputs["git_sha_at_rerun"] == "abc1234"


def test_ta2_skips_rerun_when_fixture_missing(
    tmp_path: Path, lineage_pack: EvidencePack, line_state: LineState
) -> None:
    """No `lineage_recheck.json` → the agent records no rerun trace and
    proceeds to evaluate (no delta artifact either → ITERATE_OFFLINE).
    Defensive: a fixture-missing condition shouldn't crash the loop in
    v0.2 since reruns are still optional."""

    _write_pack(tmp_path, lineage_pack)
    agent = ResearchReviewAgent(_make_mock_llm(_ta2_proposal()), line_state=line_state)
    note = agent.run(tmp_path)
    assert agent.last_run is not None
    actions = [t.action for t in agent.last_run.traces]
    assert "rerun" not in actions
    assert note.decision is Decision.ITERATE_OFFLINE


# --- T-M1 agent loop --------------------------------------------------------


def test_tm1_full_loop_supported(
    tmp_path: Path, gbm_dispersion_pack: EvidencePack, line_state: LineState
) -> None:
    _write_pack(tmp_path, gbm_dispersion_pack)
    _write_narrow_gbm_artifact(tmp_path)
    _write_delta_review(
        tmp_path,
        "T-M1",
        outcome="supported",
        primary_metric="mean_fold_ic_within_family",
        metric_kind="delta",
        point_estimate=0.006,
        interval_low=0.006,
        interval_high=0.008,
        before=0.024,
        after=0.030,
    )

    agent = ResearchReviewAgent(_make_mock_llm(_tm1_proposal()), line_state=line_state)
    note = agent.run(tmp_path)
    assert note.selected_experiment_id == "E-tm1-1"
    assert note.proposals[0].template_id == "T-M1"
    assert note.delta_review is not None
    assert note.delta_review.outcome is DeltaOutcome.SUPPORTED
    assert note.decision is Decision.ITERATE_OFFLINE


def test_tm1_rerun_step_records_within_family_delta(
    tmp_path: Path, gbm_dispersion_pack: EvidencePack, line_state: LineState
) -> None:
    _write_pack(tmp_path, gbm_dispersion_pack)
    _write_narrow_gbm_artifact(tmp_path)

    agent = ResearchReviewAgent(_make_mock_llm(_tm1_proposal()), line_state=line_state)
    agent.run(tmp_path)
    assert agent.last_run is not None
    rerun = next(t for t in agent.last_run.traces if t.action == "rerun")
    assert rerun.tool_name == "run_narrow_gbm_search"
    assert rerun.outputs is not None
    assert rerun.outputs["best_within_family_config"] == "gbm_balanced"
    assert rerun.outputs["mean_fold_ic_within_family_delta"] == pytest.approx(0.005)


def test_tm1_contradicted_stops_the_line(
    tmp_path: Path, gbm_dispersion_pack: EvidencePack, line_state: LineState
) -> None:
    _write_pack(tmp_path, gbm_dispersion_pack)
    _write_narrow_gbm_artifact(tmp_path)
    _write_delta_review(
        tmp_path,
        "T-M1",
        outcome="contradicted",
        primary_metric="mean_fold_ic_within_family",
        metric_kind="delta",
        point_estimate=-0.005,
        interval_low=-0.008,
        interval_high=-0.004,
        before=0.024,
        after=0.019,
    )

    agent = ResearchReviewAgent(_make_mock_llm(_tm1_proposal()), line_state=line_state)
    note = agent.run(tmp_path)
    assert note.delta_review is not None
    assert note.delta_review.outcome is DeltaOutcome.CONTRADICTED
    assert note.decision is Decision.STOP_RESEARCH_LINE
