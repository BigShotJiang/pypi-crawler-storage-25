"""End-to-end tests for the v0.1 ResearchReviewAgent."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from ml4t.agent.agents import DELTA_REVIEW_FILENAME, ResearchReviewAgent
from ml4t.agent.schemas import (
    Decision,
    DeltaOutcome,
    EvidencePack,
    LineState,
    ResearchNote,
)


def _write_review(run_dir: Path, payload: dict[str, Any]) -> None:
    (run_dir / DELTA_REVIEW_FILENAME.format(template_id="T-C1")).write_text(
        json.dumps(payload), encoding="utf-8"
    )


def test_full_loop_produces_research_note(
    clean_run_dir: Path,
    line_state: LineState,
    supported_review: dict[str, Any],
    make_mock_llm,
):
    _write_review(clean_run_dir, supported_review)
    agent = ResearchReviewAgent(make_mock_llm(), line_state=line_state)
    note = agent.run(clean_run_dir)
    assert isinstance(note, ResearchNote)
    assert note.line_id == "L-1"
    assert note.iteration_index == 1
    assert len(note.proposals) == 1
    assert note.selected_experiment_id == "E-tc1-1"
    assert note.delta_review is not None
    assert note.delta_review.outcome is DeltaOutcome.SUPPORTED
    # iteration_index=1 + supported -> ITERATE_OFFLINE (line not yet mature)
    assert note.decision is Decision.ITERATE_OFFLINE
    assert note.summary.startswith("case_study=etfs")


def test_supported_at_iteration_2_advances_to_holdout(
    clean_run_dir: Path,
    supported_review: dict[str, Any],
    make_mock_llm,
):
    _write_review(clean_run_dir, supported_review)
    line = LineState(line_id="L-1", iteration_index=2, base_alpha=0.05)
    agent = ResearchReviewAgent(make_mock_llm(), line_state=line)
    note = agent.run(clean_run_dir)
    assert note.decision is Decision.ADVANCE_TO_HOLDOUT_REVIEW


def test_contradicted_stops_the_line(
    clean_run_dir: Path,
    line_state: LineState,
    supported_review: dict[str, Any],
    make_mock_llm,
):
    review = dict(supported_review)
    review.update(
        outcome="contradicted",
        point_estimate=0.6,
        after=0.6,
        interval_low=0.3,
        interval_high=0.9,
    )
    _write_review(clean_run_dir, review)
    agent = ResearchReviewAgent(make_mock_llm(), line_state=line_state)
    note = agent.run(clean_run_dir)
    assert note.delta_review is not None
    assert note.delta_review.outcome is DeltaOutcome.CONTRADICTED
    assert note.decision is Decision.STOP_RESEARCH_LINE


def test_missing_delta_review_iterates_offline(
    clean_run_dir: Path, line_state: LineState, make_mock_llm
):
    # No delta_review file written.
    agent = ResearchReviewAgent(make_mock_llm(), line_state=line_state)
    note = agent.run(clean_run_dir)
    assert note.delta_review is None
    assert note.decision is Decision.ITERATE_OFFLINE
    assert note.selected_experiment_id == "E-tc1-1"
    assert any("delta-review artifact missing" in q for q in note.open_questions)


def test_no_eligible_template_stops_the_line(run_dir: Path, line_state: LineState, make_mock_llm):
    # `run_dir` has the MATERIAL warning -> T-C1 ineligible.
    agent = ResearchReviewAgent(make_mock_llm(), line_state=line_state)
    note = agent.run(run_dir)
    assert note.proposals == ()
    assert note.selected_experiment_id is None
    assert note.delta_review is None
    assert note.decision is Decision.STOP_RESEARCH_LINE
    assert "no template was eligible" in note.rationale


def test_trace_records_each_step(
    clean_run_dir: Path,
    line_state: LineState,
    supported_review: dict[str, Any],
    make_mock_llm,
):
    _write_review(clean_run_dir, supported_review)
    agent = ResearchReviewAgent(make_mock_llm(), line_state=line_state)
    agent.run(clean_run_dir)
    assert agent.last_run is not None
    actions = [t.action for t in agent.last_run.traces]
    assert actions == ["read_evidence", "propose", "rerun", "evaluate", "decide"]
    # Steps are 1-based and monotonic.
    assert [t.step for t in agent.last_run.traces] == [1, 2, 3, 4, 5]


def test_max_steps_below_minimum_raises(line_state: LineState, make_mock_llm):
    with pytest.raises(ValueError, match="max_steps"):
        ResearchReviewAgent(make_mock_llm(), line_state=line_state, max_steps=3)


def test_research_note_carries_typed_artefacts(
    clean_run_dir: Path,
    line_state: LineState,
    supported_review: dict[str, Any],
    make_mock_llm,
):
    """The note must expose the proposal + delta as typed dataclasses so a
    downstream coding agent can act on them without re-parsing."""
    _write_review(clean_run_dir, supported_review)
    agent = ResearchReviewAgent(make_mock_llm(), line_state=line_state)
    note = agent.run(clean_run_dir)
    plan = note.proposals[0]
    assert plan.template_id == "T-C1"
    assert plan.config_patches[0].yaml_path == ("costs", "per_leg_cost_bps_range")
    assert note.delta_review is not None
    assert note.delta_review.experiment_id == "E-tc1-1"
    assert note.delta_review.primary_metric == "edge_to_cost_ratio_after"


def test_evidence_summary_in_note_matches_summarize_run(
    clean_run_dir: Path,
    clean_pack: EvidencePack,
    line_state: LineState,
    supported_review: dict[str, Any],
    make_mock_llm,
):
    from ml4t.agent.tools import summarize_run

    _write_review(clean_run_dir, supported_review)
    agent = ResearchReviewAgent(make_mock_llm(), line_state=line_state)
    note = agent.run(clean_run_dir)
    assert note.summary == summarize_run(clean_pack)
