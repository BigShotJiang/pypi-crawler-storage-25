"""Multi-agent composition: ``run_proposer_with_validation``.

Per plan-31 §v0.5.1 branch D: the chain is ``proposer → validate_plan``,
no LLM reviewer. These tests pin the contract:

1. Happy path — accepted plans pass through, refusals tuple is empty.
2. Deterministic refusal — a plan that fails ``validate_plan`` lands in
   ``result.refusals``, not ``result.accepted``, and no reviewer LLM is
   called (the chain has only one LLM call: the proposer).
3. Single-LLM-call discipline — the responder counts how many times the
   LLM was invoked, asserting the chain stays at one call regardless of
   how many refusals fire.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import replace
from typing import Any

from ml4t.agent.agents import MultiAgentResult, run_proposer_with_validation
from ml4t.agent.llm import LLMResponse, Message, MockLLMClient
from ml4t.agent.schemas import (
    Determinism,
    EvidencePack,
    LineState,
    MethodologyWarning,
    ModelRunSummary,
    RefusalKind,
    Severity,
    ValidationMetrics,
)
from ml4t.agent.tools import (
    build_ta2_template,
    build_tc1_template,
    build_tm1_template,
)

# --- fixtures --------------------------------------------------------------


def _line_state() -> LineState:
    return LineState(line_id="L-1", iteration_index=1, base_alpha=0.05)


def _gbm_dispersion_pack(sample_pack: EvidencePack) -> EvidencePack:
    high_disp = ModelRunSummary(
        family="gbm",
        config_name="lgb_d6",
        label="ret_5d",
        mean_fold_ic=0.024,
        fold_ic_std=0.020,
        fold_sharpe_mean=0.55,
        fold_sharpe_std=0.30,
        n_folds=8,
    )
    runs = tuple(high_disp if r.family == "gbm" else r for r in sample_pack.validation.model_runs)
    return replace(
        sample_pack,
        warnings=(),
        validation=ValidationMetrics(
            model_runs=runs,
            signal=replace(sample_pack.validation.signal, best_family="gbm"),
            backtests=sample_pack.validation.backtests,
            robustness=sample_pack.validation.robustness,
        ),
    )


class _CountingResponder:
    """LLM responder that records how many times it was called.

    Lets the test assert the multi-agent loop makes exactly one LLM call
    (no reviewer round-trip).
    """

    def __init__(self, payload: dict[str, Any]) -> None:
        self.payload = payload
        self.calls: list[tuple[Sequence[Message], Mapping[str, Any]]] = []

    def __call__(self, messages: Sequence[Message], schema: Mapping[str, Any]) -> LLMResponse:
        self.calls.append((messages, schema))
        return LLMResponse(data={"proposals": [self.payload]}, raw=str(self.payload))


# --- happy path ------------------------------------------------------------


def test_happy_path_tm1_accepts_plan(sample_pack: EvidencePack) -> None:
    pack = _gbm_dispersion_pack(sample_pack)
    responder = _CountingResponder(
        {
            "experiment_id": "E-tm1-1",
            "template_id": "T-M1",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "narrow",
            "rationale": "narrow",
            "config_patches": [
                {
                    "path_template": "config/training/{label}.yaml",
                    "path_variables": {"label": "ret_5d"},
                    "yaml_path": ["gbm"],
                    "new_value": ["lgb_d6"],
                }
            ],
        }
    )
    result = run_proposer_with_validation(
        pack,
        llm=MockLLMClient(responder=responder),
        line_state=_line_state(),
        templates=(build_tm1_template(),),
    )
    assert isinstance(result, MultiAgentResult)
    assert len(result.accepted) == 1
    assert result.accepted[0].experiment_id == "E-tm1-1"
    assert result.refusals == ()
    assert len(responder.calls) == 1, "exactly one LLM round-trip — no reviewer"


def test_iteration_unpacking_returns_accepted_then_refusals(
    sample_pack: EvidencePack,
) -> None:
    """``accepted, refusals = result`` must work."""
    pack = _gbm_dispersion_pack(sample_pack)
    responder = _CountingResponder(
        {
            "experiment_id": "E-tm1-1",
            "template_id": "T-M1",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "narrow",
            "rationale": "narrow",
            "config_patches": [
                {
                    "path_template": "config/training/{label}.yaml",
                    "path_variables": {"label": "ret_5d"},
                    "yaml_path": ["gbm"],
                    "new_value": ["lgb_d6"],
                }
            ],
        }
    )
    accepted, refusals = run_proposer_with_validation(
        pack,
        llm=MockLLMClient(responder=responder),
        line_state=_line_state(),
        templates=(build_tm1_template(),),
    )
    assert len(accepted) == 1
    assert refusals == ()


# --- refusal path ----------------------------------------------------------


def test_missing_receipt_routes_plan_to_refusals(
    sample_pack: EvidencePack,
) -> None:
    """A T-A2 plan whose rationale cites a warning code without the
    triggering_artifact should land in refusals, not accepted."""
    warning = MethodologyWarning(
        code="LINEAGE_CONFIG_HASH_MISMATCH",
        message="parent_run config_hash mismatch",
        severity=Severity.MATERIAL,
        determinism=Determinism.ARITHMETIC,
        triggering_artifact="lineage/receipts.json",
        triggering_field="config_hash",
    )
    pack = replace(sample_pack, warnings=(warning,))
    responder = _CountingResponder(
        {
            "experiment_id": "E-ta2-1",
            "template_id": "T-A2",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "rerun reproduces parent IC",
            # Cites the warning code only — no artifact, no field.
            "rationale": "LINEAGE_CONFIG_HASH_MISMATCH means we should rerun",
            "config_patches": [],
        }
    )
    template = build_ta2_template(
        best_mean_ic_prior=pack.validation.signal.best_mean_ic,
        family=pack.validation.signal.best_family,
    )
    result = run_proposer_with_validation(
        pack,
        llm=MockLLMClient(responder=responder),
        line_state=_line_state(),
        templates=(template,),
    )
    assert result.accepted == ()
    assert len(result.refusals) == 1
    plan, refusals = result.refusals[0]
    assert plan.experiment_id == "E-ta2-1"
    assert RefusalKind.MISSING_RECEIPT in {r.kind for r in refusals}
    assert len(responder.calls) == 1, (
        "deterministic refusal must short-circuit any reviewer LLM call"
    )


def test_no_eligible_template_returns_empty_result(
    sample_pack: EvidencePack,
) -> None:
    """When the proposer returns zero plans (no eligible template), the
    result is empty in both fields and the LLM was not called at all
    (propose_experiments short-circuits before the LLM round-trip)."""
    # sample_pack has a MATERIAL warning that makes T-C1 ineligible.
    responder = _CountingResponder(
        {
            "experiment_id": "E-tc1-1",
            "template_id": "T-C1",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "edge survives",
            "rationale": "stricter cost bound",
            "config_patches": [],
        }
    )
    result = run_proposer_with_validation(
        sample_pack,
        llm=MockLLMClient(responder=responder),
        line_state=_line_state(),
        templates=(build_tc1_template(),),
    )
    assert result.accepted == ()
    assert result.refusals == ()
    assert responder.calls == []


def test_default_catalogue_used_when_templates_omitted(
    sample_pack: EvidencePack,
) -> None:
    """When `templates=` is omitted, the default catalogue is built from
    the pack — same fallback as the underlying ``propose_experiments``."""
    pack = replace(sample_pack, warnings=())
    responder = _CountingResponder(
        {
            "experiment_id": "E-tc1-1",
            "template_id": "T-C1",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "edge survives at upper bound",
            "rationale": "stricter cost bound",
            "config_patches": [
                {
                    "path_template": "config/setup.yaml",
                    "path_variables": {},
                    "yaml_path": ["costs", "per_leg_cost_bps_range"],
                    "new_value": [15.0, 25.0],
                }
            ],
        }
    )
    result = run_proposer_with_validation(
        pack,
        llm=MockLLMClient(responder=responder),
        line_state=_line_state(),
    )
    assert len(result.accepted) == 1
    assert result.refusals == ()
