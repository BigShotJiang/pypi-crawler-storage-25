"""v0.5.0 falsification spike — run the T-M1 proposer 30× and record outputs.

Plan-31 §v0.5.0 gating task. See
``~/ml4t/libraries/ml4t-agent-dev/plans/31a_v0_5_0_spike_results.md`` for
the rubric and decision rule. This script is throwaway scaffolding; it
does not ship as a public entry point.

Usage::

    cd ~/ml4t/libraries/ml4t-agent
    OPENAI_API_KEY=... uv run python tests/agents/spike/run_proposer_spike.py

Reads ``.env`` from the package root if present. Writes:

- ``tests/agents/spike/v0_5_fixture_pack.json`` (frozen fixture snapshot)
- ``tests/agents/spike/v0_5_proposer_error_rates.jsonl`` (one row per run)

Cost cap: refuses to run if any single call's estimated cost exceeds
``$0.05``. Aggregate budget for 30 calls is ~$0.05 in practice.
"""

from __future__ import annotations

import json
import os
import sys
import time
from collections.abc import Mapping, Sequence
from dataclasses import asdict
from pathlib import Path
from typing import Any

# --- env autoload (mirrors tests/test_live_real_llm.py) ---------------------

PKG_ROOT = Path(__file__).resolve().parents[3]
SPIKE_DIR = Path(__file__).resolve().parent
FIXTURE_PATH = SPIKE_DIR / "v0_5_fixture_pack.json"
JSONL_PATH = SPIKE_DIR / "v0_5_proposer_error_rates.jsonl"

N_RUNS = 30
# §v0.5.0 specifies temperature=0.3, but gpt-5-mini's API rejects any
# value other than the model default (1.0) with
# "Unsupported value: 'temperature' does not support 0.3". We pass
# `None` (OpenAIClient skips the parameter) so the model uses its
# default temperature. This deviation is recorded in the spike memo.
# Higher temperature widens the output distribution → if anything it
# makes the falsification test harder for the reviewer (more
# variation, more error opportunities), not easier.
TEMPERATURE: float | None = None
MODEL = "gpt-5-mini"
PER_CALL_COST_CEILING_USD = 0.05
TOTAL_BUDGET_USD = 0.50

# OpenAI gpt-5-mini USD per 1,000,000 tokens (mirrors tests/llm/conftest.py).
RATES_PER_MTOK_GPT5_MINI = {"input": 0.25, "output": 2.00, "cached_input": 0.025}


def _load_dotenv(path: Path) -> None:
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_dotenv(PKG_ROOT / ".env")


# --- fixture builder --------------------------------------------------------


def build_gbm_dispersion_pack() -> Any:
    """Programmatic copy of `gbm_dispersion_pack` from tests/tools/test_proposals_v02.py."""
    from ml4t.agent.schemas import (
        BacktestSummary,
        CostSummary,
        Determinism,  # noqa: F401  (kept for documentation; pack has warnings=())
        EvidencePack,
        LineageSummary,
        ModelRunSummary,
        RobustnessSummary,
        SignalSummary,
        ValidationDesign,
        ValidationMetrics,
    )

    high_dispersion_gbm = ModelRunSummary(
        family="gbm",
        config_name="lgb_d6",
        label="ret_5d",
        mean_fold_ic=0.024,
        fold_ic_std=0.020,  # 0.020 / 0.024 ≈ 0.83 → satisfies gbm_dispersion_large
        fold_sharpe_mean=0.55,
        fold_sharpe_std=0.30,
        n_folds=8,
    )
    linear_baseline = ModelRunSummary(
        family="linear",
        config_name="ridge_l2",
        label="ret_5d",
        mean_fold_ic=0.018,
        fold_ic_std=0.009,
        fold_sharpe_mean=0.42,
        fold_sharpe_std=0.18,
        n_folds=8,
    )

    return EvidencePack(
        case_study="etfs",
        objective="weekly long/short on US sector ETFs",
        primary_label="ret_5d",
        horizon="5d",
        cadence="weekly",
        parent_run_id="P-1",
        line_id="L-1",
        validation_design=ValidationDesign(
            n_splits=8,
            train_size="36m",
            val_size="3m",
            holdout_start="2024-01-01",
            holdout_end="2025-12-31",
            embargo_days=5,
            purge_days=2,
            fold_calendar_id="cal:abc",
        ),
        validation=ValidationMetrics(
            model_runs=(linear_baseline, high_dispersion_gbm),
            signal=SignalSummary(
                best_family="gbm",
                best_config="lgb_d6",
                best_mean_ic=0.024,
                ic_t_stat=2.6,
                horizons_tested=("1d", "5d", "21d"),
            ),
            backtests=(
                BacktestSummary(
                    config_id="bench",
                    family="benchmark",
                    gross_sharpe=0.40,
                    net_sharpe=0.30,
                    max_drawdown=-0.12,
                    mean_monthly_turnover=0.05,
                    edge_to_cost_ratio=2.0,
                ),
                BacktestSummary(
                    config_id="strat-gbm",
                    family="gbm",
                    gross_sharpe=0.95,
                    net_sharpe=0.60,
                    max_drawdown=-0.18,
                    mean_monthly_turnover=0.22,
                    edge_to_cost_ratio=1.6,
                ),
            ),
            robustness=RobustnessSummary(
                fold_sharpe_dispersion=0.30,
                regime_breakdown_available=True,
                seed_variance_estimate=0.03,
            ),
        ),
        holdout=None,
        costs=CostSummary(
            per_leg_bps_low=8.0,
            per_leg_bps_high=20.0,
            cost_class="liquid_etf_blend",
            components=("commission", "spread", "impact"),
        ),
        lineage=LineageSummary(
            git_sha="abc1234",
            data_snapshot_id="snap-2025-12-31",
            config_hash="cfg-9f",
            package_versions={"ml4t-data": "0.1.0a6", "ml4t-engineer": "0.1.0b1"},
        ),
        warnings=(),
        diagnostics=(),
    )


def estimate_cost_usd(usage: Mapping[str, int]) -> float:
    prompt = int(usage.get("prompt_tokens") or usage.get("input_tokens") or 0)
    completion = int(usage.get("completion_tokens") or usage.get("output_tokens") or 0)
    cached = int(usage.get("cached_tokens") or 0)
    uncached = max(prompt - cached, 0)
    return round(
        (
            uncached * RATES_PER_MTOK_GPT5_MINI["input"]
            + cached * RATES_PER_MTOK_GPT5_MINI["cached_input"]
            + completion * RATES_PER_MTOK_GPT5_MINI["output"]
        )
        / 1_000_000,
        6,
    )


# --- recording wrapper ------------------------------------------------------


class RecordingOpenAIClient:
    """LLMClient-compatible adapter that bypasses OpenAIClient.

    We do not use the in-tree ``OpenAIClient`` directly because it sets
    ``strict=True`` on the response_format, and OpenAI strict mode
    rejects the proposer's response schema (the ``new_value`` field is
    deliberately untyped because it varies per template). Sending
    ``strict=False`` is the only path to live execution against
    gpt-5-mini today; the underlying mismatch is recorded as a v0.6
    follow-up and fixed in ``OpenAIClient`` rather than here.

    Behaviour:
    1. Appends a ``# run_index=k`` line to the last user message so each
       call has a unique tail token (defeats trivial prompt-cache short-
       circuits and gives a per-call axis of variation).
    2. Captures the messages-as-sent and the raw response into
       ``self.last_call`` for the spike-recording layer to read.
    """

    def __init__(self, *, model: str, run_index: int) -> None:
        import openai

        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY not set")
        self._client = openai.OpenAI(api_key=api_key)
        self._model = model
        self._run_index = run_index
        self.last_call: dict[str, Any] = {}

    def complete_with_schema(
        self,
        messages: Sequence[Any],
        json_schema: Mapping[str, Any],
        *,
        max_tokens: int = 1024,
        temperature: float | None = 0.0,
    ) -> Any:
        from ml4t.agent.llm import LLMResponse, Message

        mutated: list[Message] = []
        for i, m in enumerate(messages):
            if i == len(messages) - 1 and m.role == "user":
                mutated.append(
                    Message(
                        role=m.role,
                        content=f"{m.content}\n\n# run_index={self._run_index}",
                        cacheable=m.cacheable,
                    )
                )
            else:
                mutated.append(m)

        # Capture messages BEFORE the API call so error records still
        # show what was sent.
        self.last_call = {
            "messages_in": [
                {"role": m.role, "content": m.content, "cacheable": m.cacheable} for m in mutated
            ],
            "raw_response": None,
            "usage": {},
        }

        api_messages = [{"role": m.role, "content": m.content} for m in mutated]
        response_format: dict[str, Any] = {
            "type": "json_schema",
            "json_schema": {
                "name": "structured_response",
                "schema": dict(json_schema),
                "strict": False,
            },
        }
        # gpt-5-mini's reasoning_tokens count against max_completion_tokens.
        # The proposer's default 2048 is enough for visible output but can
        # be exhausted by reasoning. Bump aggressively for the spike.
        kwargs: dict[str, Any] = {
            "model": self._model,
            "messages": api_messages,
            "max_completion_tokens": max(max_tokens, 8192),
            "response_format": response_format,
        }
        if temperature is not None:
            kwargs["temperature"] = temperature

        api_response = self._client.chat.completions.create(**kwargs)
        choice = api_response.choices[0]
        message = choice.message
        raw = message.content or ""
        if not raw:
            raise ValueError(
                "OpenAI assistant message had no string content "
                f"(finish_reason={choice.finish_reason})"
            )
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"OpenAI response was not valid JSON: {exc}") from exc

        usage_obj = api_response.usage
        usage: dict[str, int] = {}
        if usage_obj is not None:
            for attr in ("prompt_tokens", "completion_tokens", "total_tokens"):
                v = getattr(usage_obj, attr, None)
                if isinstance(v, int):
                    usage[attr] = v
            details = getattr(usage_obj, "prompt_tokens_details", None)
            cached = getattr(details, "cached_tokens", None) if details else None
            if isinstance(cached, int):
                usage["cached_tokens"] = cached

        self.last_call["raw_response"] = raw
        self.last_call["usage"] = usage
        return LLMResponse(data=data, raw=raw, usage=usage)


# --- main loop --------------------------------------------------------------


def main() -> int:
    if not os.environ.get("OPENAI_API_KEY"):
        print("ERROR: OPENAI_API_KEY not set (looked in env and .env)", file=sys.stderr)
        return 2

    from ml4t.agent.schemas import LineState, PlanValidationError
    from ml4t.agent.tools import build_tm1_template, propose_experiments

    pack = build_gbm_dispersion_pack()
    line_state = LineState(line_id="L-1", iteration_index=1, base_alpha=0.05)

    # Snapshot the fixture for reproducibility.
    FIXTURE_PATH.write_text(
        json.dumps(asdict(pack), default=str, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    print(f"[setup] frozen fixture → {FIXTURE_PATH}")

    # Sanity: T-M1 must be eligible on this pack.
    tm1 = build_tm1_template()
    eligible, reasons = tm1.is_eligible(pack)
    if not eligible:
        print(
            f"ERROR: T-M1 not eligible on the snapshot pack: {reasons}",
            file=sys.stderr,
        )
        return 3
    print(f"[setup] T-M1 eligible: {reasons}")

    # Truncate the JSONL up front — full re-run, no append-on-rerun.
    JSONL_PATH.write_text("", encoding="utf-8")

    total_cost = 0.0
    counts = {"plan": 0, "schema_reject": 0, "error": 0}

    for k in range(1, N_RUNS + 1):
        client = RecordingOpenAIClient(model=MODEL, run_index=k)
        record: dict[str, Any] = {
            "run_index": k,
            "model": MODEL,
            "temperature": TEMPERATURE,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        try:
            plans = propose_experiments(
                pack,
                llm=client,
                line_state=line_state,
                templates=(tm1,),
                temperature=TEMPERATURE,
            )
            record.update(
                client.last_call
                | {
                    "schema_validation_status": "ok",
                    "n_plans": len(plans),
                    "parsed_proposal": (
                        {
                            "experiment_id": plans[0].experiment_id,
                            "template_id": plans[0].template_id,
                            "comparison_target_id": plans[0].comparison_target_id,
                            "hypothesis": plans[0].hypothesis,
                            "rationale": plans[0].rationale,
                            "config_patches": [
                                {
                                    "path_template": p.path_template,
                                    "path_variables": list(p.path_variables),
                                    "yaml_path": list(p.yaml_path),
                                    "new_value": p.new_value,
                                }
                                for p in plans[0].config_patches
                            ],
                        }
                        if plans
                        else None
                    ),
                }
            )
            counts["plan"] += 1
        except PlanValidationError as exc:
            record.update(
                client.last_call
                | {
                    "schema_validation_status": "schema_reject",
                    "parsed_proposal": None,
                    "error": f"PlanValidationError: {exc}",
                }
            )
            counts["schema_reject"] += 1
        except Exception as exc:  # transient API / parsing
            record.update(
                client.last_call
                | {
                    "schema_validation_status": "error",
                    "parsed_proposal": None,
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )
            counts["error"] += 1

        usage = record.get("usage") or {}
        cost = estimate_cost_usd(usage) if usage else 0.0
        record["estimated_usd"] = cost
        total_cost += cost

        if cost > PER_CALL_COST_CEILING_USD:
            print(
                f"ABORT: run {k} estimated cost ${cost:.4f} > "
                f"${PER_CALL_COST_CEILING_USD:.2f} per-call ceiling",
                file=sys.stderr,
            )
            return 4
        if total_cost > TOTAL_BUDGET_USD:
            print(
                f"ABORT: cumulative cost ${total_cost:.4f} > "
                f"${TOTAL_BUDGET_USD:.2f} total spike budget",
                file=sys.stderr,
            )
            return 5

        with JSONL_PATH.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, default=str) + "\n")

        print(
            f"[run {k:02d}/{N_RUNS}] "
            f"status={record['schema_validation_status']} "
            f"usage={usage.get('prompt_tokens', '?')}+{usage.get('completion_tokens', '?')} "
            f"cost=${cost:.5f} "
            f"cum=${total_cost:.4f}"
        )

    print()
    print("=" * 70)
    print(f"Spike complete. {N_RUNS} runs.")
    print(
        f"  plans: {counts['plan']}  schema_reject: {counts['schema_reject']}  error: {counts['error']}"
    )
    print(f"  total estimated cost: ${total_cost:.4f}")
    print(f"  output: {JSONL_PATH}")
    print(f"  fixture: {FIXTURE_PATH}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
