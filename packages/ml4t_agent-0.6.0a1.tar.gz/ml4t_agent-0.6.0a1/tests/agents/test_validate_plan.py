"""Deterministic ``validate_plan`` audit — per-refusal-kind tests.

One test per :class:`RefusalKind` (predicate mismatch, missing receipt,
threshold drift, Bonferroni over-budget, preset registry receipt) plus
the happy-path approve case for each currently-shipped template.

These tests are **pure Python** — no LLM mocks, no I/O, no fixtures
loaded from disk. They construct plans + packs in-memory so a refusal
classifier change shows up as exactly one failing assertion per kind.
"""

from __future__ import annotations

from dataclasses import replace

from ml4t.agent.agents import (
    BONFERRONI_FLOOR,
    validate_plan,
)
from ml4t.agent.llm import LLMResponse, MockLLMClient
from ml4t.agent.schemas import (
    ConfigPatch,
    Determinism,
    EvidencePack,
    ExperimentPlan,
    LineState,
    MethodologyWarning,
    RefusalKind,
    Severity,
)
from ml4t.agent.tools import (
    build_ta2_template,
    build_tc1_template,
    build_tf1_template,
    build_tm1_template,
    propose_experiments,
)

# --- helpers ---------------------------------------------------------------


def _make_responder(payload):
    def responder(_messages, _schema):
        return LLMResponse(data={"proposals": [payload]}, raw=str(payload))

    return responder


def _line_state() -> LineState:
    return LineState(line_id="L-1", iteration_index=1, base_alpha=0.05)


def _gbm_dispersion_pack(sample_pack: EvidencePack) -> EvidencePack:
    """Same shape as tests/tools/test_proposals_v02.py::gbm_dispersion_pack."""
    from ml4t.agent.schemas import ModelRunSummary, ValidationMetrics

    high_disp = ModelRunSummary(
        family="gbm",
        config_name="lgb_d6",
        label="ret_5d",
        mean_fold_ic=0.024,
        fold_ic_std=0.020,
        fold_sharpe_mean=0.55,
        fold_sharpe_std=0.30,
        n_folds=8,
    )
    runs = tuple(high_disp if r.family == "gbm" else r for r in sample_pack.validation.model_runs)
    metrics = ValidationMetrics(
        model_runs=runs,
        signal=replace(sample_pack.validation.signal, best_family="gbm"),
        backtests=sample_pack.validation.backtests,
        robustness=sample_pack.validation.robustness,
    )
    return replace(sample_pack, warnings=(), validation=metrics)


def _lineage_pack(sample_pack: EvidencePack) -> EvidencePack:
    """sample_pack with the MATERIAL leak warning replaced by a lineage one."""
    w = MethodologyWarning(
        code="LINEAGE_CONFIG_HASH_MISMATCH",
        message="parent_run config_hash does not match HEAD",
        severity=Severity.MATERIAL,
        determinism=Determinism.ARITHMETIC,
        triggering_artifact="lineage/receipts.json",
        triggering_field="config_hash",
    )
    return replace(sample_pack, warnings=(w,))


def _propose_one(pack: EvidencePack, template, payload) -> ExperimentPlan:
    """Run propose_experiments end-to-end against a fixed mock and return
    the single resulting plan. Lets tests use the real plan-construction
    path rather than hand-building ExperimentPlan instances."""
    plans = propose_experiments(
        pack,
        llm=MockLLMClient(responder=_make_responder(payload)),
        line_state=_line_state(),
        templates=(template,),
    )
    assert len(plans) == 1
    return plans[0]


# --- happy paths -----------------------------------------------------------


def test_happy_path_tm1_returns_no_refusals(sample_pack: EvidencePack) -> None:
    pack = _gbm_dispersion_pack(sample_pack)
    template = build_tm1_template()
    plan = _propose_one(
        pack,
        template,
        {
            "experiment_id": "E-tm1-1",
            "template_id": "T-M1",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "narrow",
            "rationale": "narrow",
            "config_patches": [
                {
                    "path_template": "config/training/{label}.yaml",
                    "path_variables": {"label": "ret_5d"},
                    "yaml_path": ["gbm"],
                    "new_value": ["lgb_d6"],
                }
            ],
        },
    )
    assert validate_plan(plan, template, pack) == ()


def test_happy_path_tc1_returns_no_refusals(sample_pack: EvidencePack) -> None:
    pack = replace(sample_pack, warnings=())
    template = build_tc1_template()
    plan = _propose_one(
        pack,
        template,
        {
            "experiment_id": "E-tc1-1",
            "template_id": "T-C1",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "edge survives",
            "rationale": "stricter cost bound",
            "config_patches": [
                {
                    "path_template": "config/setup.yaml",
                    "path_variables": {},
                    "yaml_path": ["costs", "per_leg_cost_bps_range"],
                    "new_value": [15.0, 25.0],
                }
            ],
        },
    )
    assert validate_plan(plan, template, pack) == ()


def test_happy_path_ta2_returns_no_refusals(sample_pack: EvidencePack) -> None:
    pack = _lineage_pack(sample_pack)
    template = build_ta2_template(
        best_mean_ic_prior=pack.validation.signal.best_mean_ic,
        family=pack.validation.signal.best_family,
    )
    plan = _propose_one(
        pack,
        template,
        {
            "experiment_id": "E-ta2-1",
            "template_id": "T-A2",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "rerun reproduces parent IC",
            "rationale": (
                "warning LINEAGE_CONFIG_HASH_MISMATCH cited in lineage/receipts.json — rerun needed"
            ),
            "config_patches": [],
        },
    )
    assert validate_plan(plan, template, pack) == ()


# --- 1. predicate mismatch -------------------------------------------------


def test_predicate_mismatch_when_predicate_now_returns_false(
    sample_pack: EvidencePack,
) -> None:
    """A T-M1 plan built against a high-dispersion pack should refuse if the
    pack's GBM dispersion is then collapsed below the predicate threshold —
    i.e. the proposer's eligibility claim is stale."""
    pack = _gbm_dispersion_pack(sample_pack)
    template = build_tm1_template()
    plan = _propose_one(
        pack,
        template,
        {
            "experiment_id": "E-tm1-1",
            "template_id": "T-M1",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "narrow",
            "rationale": "narrow",
            "config_patches": [
                {
                    "path_template": "config/training/{label}.yaml",
                    "path_variables": {"label": "ret_5d"},
                    "yaml_path": ["gbm"],
                    "new_value": ["lgb_d6"],
                }
            ],
        },
    )
    # Re-evaluate against a degraded pack (smaller GBM fold-IC std).
    from ml4t.agent.schemas import ValidationMetrics

    smaller = tuple(
        replace(r, fold_ic_std=0.005) if r.family == "gbm" else r
        for r in pack.validation.model_runs
    )
    degraded = replace(
        pack,
        validation=ValidationMetrics(
            model_runs=smaller,
            signal=pack.validation.signal,
            backtests=pack.validation.backtests,
            robustness=pack.validation.robustness,
        ),
    )
    refusals = validate_plan(plan, template, degraded)
    kinds = {r.kind for r in refusals}
    assert RefusalKind.PREDICATE_MISMATCH in kinds
    assert any("gbm_dispersion_large" in (r.field_path or "") for r in refusals)


def test_predicate_unavailable_yields_predicate_mismatch_refusal(
    sample_pack: EvidencePack,
) -> None:
    """T-F1's `feature_triage_has_stop` raises PredicateUnavailable when
    triage is None. The audit should surface that as a predicate-mismatch
    refusal rather than silently passing."""
    pack = replace(sample_pack, warnings=(), triage=None)
    template = build_tf1_template(family=pack.validation.signal.best_family)
    # Hand-build an ExperimentPlan since propose_experiments would refuse
    # to construct one (template is ineligible).

    delta = replace(template.delta_criterion_template, bonferroni_k=1)
    plan = ExperimentPlan(
        experiment_id="E-tf1-1",
        template_id="T-F1",
        parent_run_id="P-1",
        comparison_target_id="strat-gbm",
        config_patches=(
            ConfigPatch(
                path_template="config/training/{label}.yaml",
                path_variables=(("label", "ret_5d"),),
                yaml_path=("features", "exclude"),
                new_value=["regime_x"],
            ),
        ),
        stage_invocations=template.stage_invocations,
        expected_artifacts=template.expected_artifacts,
        delta_criterion=delta,
        question=template.question,
        hypothesis="exclude broken features",
        rationale="exclude features audit flagged",
    )
    refusals = validate_plan(plan, template, pack)
    kinds = {r.kind for r in refusals}
    assert RefusalKind.PREDICATE_MISMATCH in kinds
    assert any("feature_triage_has_stop" in (r.field_path or "") for r in refusals)


# --- 2. missing receipt ----------------------------------------------------


def test_missing_receipt_when_warning_code_cited_without_artifact(
    sample_pack: EvidencePack,
) -> None:
    pack = _lineage_pack(sample_pack)
    template = build_ta2_template(
        best_mean_ic_prior=pack.validation.signal.best_mean_ic,
        family=pack.validation.signal.best_family,
    )
    plan = _propose_one(
        pack,
        template,
        {
            "experiment_id": "E-ta2-1",
            "template_id": "T-A2",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "rerun reproduces parent IC",
            "rationale": (
                # Cites the warning code, but neither the artifact nor the
                # triggering_field — should refuse with MISSING_RECEIPT.
                "the LINEAGE_CONFIG_HASH_MISMATCH warning means we should rerun"
            ),
            "config_patches": [],
        },
    )
    refusals = validate_plan(plan, template, pack)
    kinds = {r.kind for r in refusals}
    assert RefusalKind.MISSING_RECEIPT in kinds


def test_missing_receipt_satisfied_by_triggering_field(
    sample_pack: EvidencePack,
) -> None:
    """Citing the triggering_field is enough — the receipt does not have to
    be the artifact path."""
    pack = _lineage_pack(sample_pack)
    template = build_ta2_template(
        best_mean_ic_prior=pack.validation.signal.best_mean_ic,
        family=pack.validation.signal.best_family,
    )
    plan = _propose_one(
        pack,
        template,
        {
            "experiment_id": "E-ta2-1",
            "template_id": "T-A2",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "rerun reproduces parent IC",
            "rationale": ("LINEAGE_CONFIG_HASH_MISMATCH cited config_hash drift; rerun"),
            "config_patches": [],
        },
    )
    refusals = validate_plan(plan, template, pack)
    assert RefusalKind.MISSING_RECEIPT not in {r.kind for r in refusals}


# --- 3. threshold drift ----------------------------------------------------


def test_threshold_drift_when_t_a2_thresholds_diverge_from_pack(
    sample_pack: EvidencePack,
) -> None:
    pack = _lineage_pack(sample_pack)
    template = build_ta2_template(
        best_mean_ic_prior=pack.validation.signal.best_mean_ic,
        family=pack.validation.signal.best_family,
    )
    plan = _propose_one(
        pack,
        template,
        {
            "experiment_id": "E-ta2-1",
            "template_id": "T-A2",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "rerun reproduces parent IC",
            "rationale": ("LINEAGE_CONFIG_HASH_MISMATCH cited lineage/receipts.json"),
            "config_patches": [],
        },
    )
    # Forge a plan whose support_threshold drifted by way more than 10%.
    drifted = replace(
        plan,
        delta_criterion=replace(
            plan.delta_criterion,
            support_threshold=plan.delta_criterion.support_threshold + 0.05,
        ),
    )
    refusals = validate_plan(drifted, template, pack)
    kinds = {r.kind for r in refusals}
    assert RefusalKind.THRESHOLD_DRIFT in kinds
    assert any(r.field_path == "delta_criterion.support_threshold" for r in refusals)


def test_threshold_drift_no_op_for_non_anchored_template(
    sample_pack: EvidencePack,
) -> None:
    """T-C1 thresholds are not pack-anchored — drift check should be a
    no-op even if we contrive an unusual delta criterion."""
    pack = replace(sample_pack, warnings=())
    template = build_tc1_template()
    plan = _propose_one(
        pack,
        template,
        {
            "experiment_id": "E-tc1-1",
            "template_id": "T-C1",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "edge survives",
            "rationale": "stricter cost bound",
            "config_patches": [
                {
                    "path_template": "config/setup.yaml",
                    "path_variables": {},
                    "yaml_path": ["costs", "per_leg_cost_bps_range"],
                    "new_value": [15.0, 25.0],
                }
            ],
        },
    )
    refusals = validate_plan(plan, template, pack)
    assert RefusalKind.THRESHOLD_DRIFT not in {r.kind for r in refusals}


# --- 4. Bonferroni over budget ---------------------------------------------


def test_bonferroni_over_budget_when_adjusted_alpha_below_floor(
    sample_pack: EvidencePack,
) -> None:
    pack = replace(sample_pack, warnings=())
    template = build_tc1_template()
    plan = _propose_one(
        pack,
        template,
        {
            "experiment_id": "E-tc1-1",
            "template_id": "T-C1",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "edge survives",
            "rationale": "stricter cost bound",
            "config_patches": [
                {
                    "path_template": "config/setup.yaml",
                    "path_variables": {},
                    "yaml_path": ["costs", "per_leg_cost_bps_range"],
                    "new_value": [15.0, 25.0],
                }
            ],
        },
    )
    # bonferroni_k = base_alpha / FLOOR + 1 forces adjusted_alpha < FLOOR.
    too_many_k = int(plan.delta_criterion.base_alpha / BONFERRONI_FLOOR) + 1
    over = replace(plan, delta_criterion=replace(plan.delta_criterion, bonferroni_k=too_many_k))
    refusals = validate_plan(over, template, pack)
    kinds = {r.kind for r in refusals}
    assert RefusalKind.BONFERRONI_OVER_BUDGET in kinds


def test_bonferroni_at_floor_does_not_refuse(sample_pack: EvidencePack) -> None:
    pack = replace(sample_pack, warnings=())
    template = build_tc1_template()
    plan = _propose_one(
        pack,
        template,
        {
            "experiment_id": "E-tc1-1",
            "template_id": "T-C1",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "edge survives",
            "rationale": "stricter cost bound",
            "config_patches": [
                {
                    "path_template": "config/setup.yaml",
                    "path_variables": {},
                    "yaml_path": ["costs", "per_leg_cost_bps_range"],
                    "new_value": [15.0, 25.0],
                }
            ],
        },
    )
    refusals = validate_plan(plan, template, pack)
    assert RefusalKind.BONFERRONI_OVER_BUDGET not in {r.kind for r in refusals}


# --- 5. preset registry receipt --------------------------------------------


def test_preset_registry_receipt_no_op_when_registry_absent(
    sample_pack: EvidencePack,
) -> None:
    """Until v0.6 wires `pack.preset_registry`, the receipt check is a no-op
    so existing T-M1 plans are not regressed."""
    pack = _gbm_dispersion_pack(sample_pack)
    template = build_tm1_template()
    plan = _propose_one(
        pack,
        template,
        {
            "experiment_id": "E-tm1-1",
            "template_id": "T-M1",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "narrow",
            "rationale": "narrow",
            "config_patches": [
                {
                    "path_template": "config/training/{label}.yaml",
                    "path_variables": {"label": "ret_5d"},
                    "yaml_path": ["gbm"],
                    # Hallucinated preset name (the spike's actual finding) —
                    # but registry is None, so refusal does not fire.
                    "new_value": ["gbm_d6"],
                }
            ],
        },
    )
    refusals = validate_plan(plan, template, pack)
    assert RefusalKind.PRESET_REGISTRY_RECEIPT not in {r.kind for r in refusals}


def test_preset_registry_receipt_fires_when_registry_present_and_unknown(
    sample_pack: EvidencePack,
) -> None:
    """v0.6: pack carries a preset_registry field and the proposer
    references a name not in it."""
    base_pack = _gbm_dispersion_pack(sample_pack)
    pack = replace(base_pack, preset_registry=frozenset({"lgb_d6", "lgb_d3"}))
    template = build_tm1_template()
    plan = _propose_one(
        pack,
        template,
        {
            "experiment_id": "E-tm1-1",
            "template_id": "T-M1",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "narrow",
            "rationale": "narrow",
            "config_patches": [
                {
                    "path_template": "config/training/{label}.yaml",
                    "path_variables": {"label": "ret_5d"},
                    "yaml_path": ["gbm"],
                    "new_value": ["gbm_d6"],  # not in registry
                }
            ],
        },
    )
    refusals = validate_plan(plan, template, pack)
    kinds = {r.kind for r in refusals}
    assert RefusalKind.PRESET_REGISTRY_RECEIPT in kinds
    assert any("gbm_d6" in r.message for r in refusals)


def test_preset_registry_receipt_silent_when_registry_present_and_known(
    sample_pack: EvidencePack,
) -> None:
    base_pack = _gbm_dispersion_pack(sample_pack)
    pack = replace(base_pack, preset_registry=frozenset({"lgb_d6", "lgb_d3"}))
    template = build_tm1_template()
    plan = _propose_one(
        pack,
        template,
        {
            "experiment_id": "E-tm1-1",
            "template_id": "T-M1",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "narrow",
            "rationale": "narrow",
            "config_patches": [
                {
                    "path_template": "config/training/{label}.yaml",
                    "path_variables": {"label": "ret_5d"},
                    "yaml_path": ["gbm"],
                    "new_value": ["lgb_d6"],
                }
            ],
        },
    )
    refusals = validate_plan(plan, template, pack)
    assert RefusalKind.PRESET_REGISTRY_RECEIPT not in {r.kind for r in refusals}


# --- multi-refusal aggregation ---------------------------------------------


def test_validate_plan_aggregates_multiple_refusals(sample_pack: EvidencePack) -> None:
    """A single plan that fails two checks should receive both refusals
    (no short-circuit across kinds)."""
    pack = _lineage_pack(sample_pack)
    template = build_ta2_template(
        best_mean_ic_prior=pack.validation.signal.best_mean_ic,
        family=pack.validation.signal.best_family,
    )
    plan = _propose_one(
        pack,
        template,
        {
            "experiment_id": "E-ta2-1",
            "template_id": "T-A2",
            "comparison_target_id": "strat-gbm",
            "hypothesis": "rerun reproduces parent IC",
            "rationale": "LINEAGE_CONFIG_HASH_MISMATCH",  # missing receipt
            "config_patches": [],
        },
    )
    drifted = replace(
        plan,
        delta_criterion=replace(
            plan.delta_criterion,
            support_threshold=plan.delta_criterion.support_threshold + 0.05,
            bonferroni_k=int(0.05 / BONFERRONI_FLOOR) + 1,
        ),
    )
    refusals = validate_plan(drifted, template, pack)
    kinds = {r.kind for r in refusals}
    assert RefusalKind.MISSING_RECEIPT in kinds
    assert RefusalKind.THRESHOLD_DRIFT in kinds
    assert RefusalKind.BONFERRONI_OVER_BUDGET in kinds
