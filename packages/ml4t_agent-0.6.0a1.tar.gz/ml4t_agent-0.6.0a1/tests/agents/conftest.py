"""Reuse the tools/conftest fixtures for the agent loop."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any

import pytest

from ml4t.agent.llm import LLMResponse, Message, MockLLMClient
from ml4t.agent.schemas import EvidencePack, LineState

# `sample_pack` + `run_dir` come from the top-level tests/conftest.py.


def _tc1_proposal_payload(experiment_id: str = "E-tc1-1") -> dict[str, Any]:
    return {
        "experiment_id": experiment_id,
        "template_id": "T-C1",
        "comparison_target_id": "strat-gbm",
        "hypothesis": "net edge >= 1.0x at 25 bps upper bound",
        "rationale": (
            "validation.backtests[strat-gbm].edge_to_cost_ratio=1.6; "
            "stricter cost bound tests survival floor"
        ),
        "config_patches": [
            {
                "path_template": "config/setup.yaml",
                "path_variables": {},
                "yaml_path": ["costs", "per_leg_cost_bps_range"],
                "new_value": [15.0, 25.0],
            }
        ],
    }


def _ta2_proposal_payload(experiment_id: str = "E-ta2-1") -> dict[str, Any]:
    """Hand-written T-A2 proposal: pure rerun, empty config_patches.

    The lineage finding cited in `rationale` should be present on the
    EvidencePack used in the test (severity BLOCKING/MATERIAL, code
    containing ``"lineage"`` or ``"reproducibility"``, or
    ``triggering_field`` referencing a `LineageSummary` field).
    """
    return {
        "experiment_id": experiment_id,
        "template_id": "T-A2",
        "comparison_target_id": "strat-gbm",
        "hypothesis": ("rerun at HEAD reproduces the parent's mean_fold_ic within 0.002"),
        "rationale": (
            "warnings cite a lineage gap (config_hash mismatch); rerun the "
            "best baseline at HEAD to confirm the cited IC is reproducible"
        ),
        "config_patches": [],
    }


def _tm1_proposal_payload(
    experiment_id: str = "E-tm1-1",
    *,
    label: str = "fwd_ret_21d",
    presets: tuple[str, ...] = ("gbm_shallow", "gbm_balanced"),
) -> dict[str, Any]:
    """Hand-written T-M1 proposal: narrow GBM list[str] override."""
    return {
        "experiment_id": experiment_id,
        "template_id": "T-M1",
        "comparison_target_id": "strat-gbm",
        "hypothesis": ("tighter neighborhood improves mean_fold_ic_within_family by >=0.005"),
        "rationale": (
            "GBM family is strongest on signal but fold-IC dispersion is "
            "large; narrow the preset list to the best two configs"
        ),
        "config_patches": [
            {
                "path_template": "config/training/{label}.yaml",
                "path_variables": {"label": label},
                "yaml_path": ["gbm"],
                "new_value": list(presets),
            }
        ],
    }


@pytest.fixture
def line_state() -> LineState:
    return LineState(line_id="L-1", iteration_index=1, base_alpha=0.05)


@pytest.fixture
def clean_pack(sample_pack: EvidencePack) -> EvidencePack:
    return replace(sample_pack, warnings=())


@pytest.fixture
def clean_run_dir(tmp_path: Path, clean_pack: EvidencePack) -> Path:
    """Run-dir variant whose evidence pack has no methodology warnings."""
    (tmp_path / "evidence_pack.json").write_text(
        json.dumps(asdict(clean_pack), default=str), encoding="utf-8"
    )
    (tmp_path / "cost_sensitivity.json").write_text(
        json.dumps(
            {
                "cost_class": "liquid_etf_blend",
                "components": ["commission", "spread", "impact"],
            }
        ),
        encoding="utf-8",
    )
    return tmp_path


@pytest.fixture
def supported_review() -> dict[str, Any]:
    return {
        "experiment_id": "E-tc1-1",
        "primary_metric": "edge_to_cost_ratio_after",
        "metric_kind": "absolute",
        "before": 1.6,
        "after": 1.32,
        "point_estimate": 1.32,
        "interval_low": 1.10,
        "interval_high": 1.55,
        "fold_deltas": [-0.30, -0.25, -0.28, -0.32],
        "cost_sensitivity": [[15.0, 1.55], [25.0, 1.32]],
        "outcome": "supported",
        "recommendation": "iterate_offline",
        "rationale": "edge survives the 25bps stress test",
    }


@pytest.fixture
def make_mock_llm():
    """Factory: build a MockLLMClient that replies with the given proposals."""

    def _factory(
        proposals: Sequence[dict[str, Any]] | None = None,
    ) -> MockLLMClient:
        payload = list(proposals) if proposals is not None else [_tc1_proposal_payload()]

        def responder(_m: Sequence[Message], _s: Mapping[str, Any]) -> LLMResponse:
            body = {"proposals": payload}
            return LLMResponse(data=body, raw=str(body))

        return MockLLMClient(responder=responder)

    return _factory
