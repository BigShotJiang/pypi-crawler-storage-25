"""`EmailChannel` -- Resend-backed inbound/outbound email channel for Zeno.

Owns the HTTP inbound plumbing (Starlette router + uvicorn server), the
outbound REST client, and the bounded queue that bridges push-style webhook
events into Zeno's pull-style `receive()` iterator. Outbound routing uses
`OutgoingMessage.reply_to_thread_key`, which the turn worker's StreamBuffer
populates automatically from the inbound `IncomingMessage.thread_key`.

Lifecycle:
  * `start()` allocates an httpx.AsyncClient, builds a ResendClient, wires the
    router, and runs uvicorn in a background task. Binding to port 0 is
    supported for tests via the `bound_port` property.
  * `stop()` asks uvicorn to exit, awaits the serve task, and closes the httpx
    client.
  * Both are idempotent.

Testing seams:
  * `_transport` -- optional `httpx.MockTransport` injected into the
    `AsyncClient` so tests can observe outbound requests without a network.
  * `_base_url` -- override Resend's base URL (also exercised by tests).
"""

from __future__ import annotations

import asyncio
import collections
import logging
from collections.abc import AsyncIterator, MutableMapping
from dataclasses import dataclass, field
from typing import Any

import httpx
import uvicorn
from zeno.channels.email.outbound import (
    EmailBackendError,
    EmailEnvelope,
    build_reply_headers,
    new_message_id,
    subject_for_reply,
    wrap_html,
)
from zeno.channels.email.resend_client import ResendClient
from zeno.channels.email.router import build_router
from zeno.channels.email.state import EmailThreadState
from zeno.channels.messages import IncomingMessage, OutgoingMessage
from zeno.channels.protocol import Capabilities

_log = logging.getLogger("zeno.channels.email")

_DEFAULT_BASE_URL = "https://api.resend.com"
_QUEUE_MAX = 64


class ChannelError(RuntimeError):
    """Raised on EmailChannel lifecycle or transport errors."""


# ---------------------------------------------------------------------------
# Thread-state proxy — routes router writes through eviction logic
# ---------------------------------------------------------------------------


class _ThreadStateProxy(MutableMapping[str, EmailThreadState]):
    """MutableMapping adapter that routes __setitem__ through the channel's
    LRU eviction helper so the router can write `thread_state[key] = state`
    without knowing anything about cap enforcement.
    """

    def __init__(self, channel: EmailChannel) -> None:
        self._channel = channel

    # ---- MutableMapping interface ------------------------------------------

    def __getitem__(self, key: str) -> EmailThreadState:
        return self._channel._thread_state[key]

    def __setitem__(self, key: str, value: EmailThreadState) -> None:
        self._channel._record_thread_state(key, value)

    def __delitem__(self, key: str) -> None:
        del self._channel._thread_state[key]

    def __iter__(self) -> Any:
        return iter(self._channel._thread_state)

    def __len__(self) -> int:
        return len(self._channel._thread_state)


# ---------------------------------------------------------------------------
# EmailChannel
# ---------------------------------------------------------------------------


@dataclass
class EmailChannel:
    """Resend email channel. Implements `zeno.channels.protocol.Channel`."""

    api_key: str = field(repr=False)
    signing_secret: str = field(repr=False)
    from_address: str
    allowed_senders: tuple[str, ...]
    host: str = "127.0.0.1"
    port: int = 8080
    webhook_path: str = "/webhook"
    name: str = "email"
    thread_state_cap: int = 10_000

    _transport: httpx.MockTransport | None = None
    _base_url: str = _DEFAULT_BASE_URL

    # Private fields — not part of the constructor, not shown in repr.
    _capabilities: Capabilities = field(
        default_factory=lambda: Capabilities(
            supports_threading=True,
            supports_images=False,
        ),
        init=False,
        repr=False,
    )
    _queue: asyncio.Queue[IncomingMessage] = field(init=False, repr=False)
    _thread_state: collections.OrderedDict[str, EmailThreadState] = field(init=False, repr=False)
    _allowlist: frozenset[str] = field(init=False, repr=False)
    _from_domain: str = field(init=False, repr=False)
    _http: httpx.AsyncClient | None = field(default=None, init=False, repr=False)
    _client: ResendClient | None = field(default=None, init=False, repr=False)
    _server: uvicorn.Server | None = field(default=None, init=False, repr=False)
    _serve_task: asyncio.Task[None] | None = field(default=None, init=False, repr=False)
    _started: bool = field(default=False, init=False, repr=False)
    _stopped: bool = field(default=False, init=False, repr=False)

    def __post_init__(self) -> None:
        self._queue = asyncio.Queue(maxsize=_QUEUE_MAX)
        self._thread_state = collections.OrderedDict()
        self._allowlist = frozenset(s.strip().lower() for s in self.allowed_senders)
        # Extract domain from from_address: everything after '@'.
        at = self.from_address.find("@")
        self._from_domain = self.from_address[at + 1 :] if at >= 0 else self.from_address

    # -----------------------------------------------------------------------
    # LRU eviction helper
    # -----------------------------------------------------------------------

    def _record_thread_state(self, key: str, state: EmailThreadState) -> None:
        """Insert or update *key* in the LRU cache with eviction.

        - If *key* exists: move to end (most-recently-used position).
        - If at cap and *key* is new: evict LRU (popitem(last=False)).
        - Insert.
        """
        if key in self._thread_state:
            del self._thread_state[key]
        elif len(self._thread_state) >= self.thread_state_cap:
            self._thread_state.popitem(last=False)
        self._thread_state[key] = state

    # -----------------------------------------------------------------------
    # Protocol properties
    # -----------------------------------------------------------------------

    @property
    def capabilities(self) -> Capabilities:
        return self._capabilities

    @property
    def bound_port(self) -> int:
        """Actual port uvicorn bound to (useful when `port=0`)."""
        if self._server is None or not self._server.servers:
            raise ChannelError("EmailChannel: bound_port before start()")
        sockets = self._server.servers[0].sockets
        if not sockets:
            raise ChannelError("EmailChannel: no bound sockets")
        return int(sockets[0].getsockname()[1])

    # -----------------------------------------------------------------------
    # Lifecycle
    # -----------------------------------------------------------------------

    async def start(self) -> None:
        if self._started:
            return
        if not self.allowed_senders:
            raise ValueError("EmailChannel: allowed_senders must be non-empty")

        self._http = httpx.AsyncClient(
            transport=self._transport,
            base_url=self._base_url,
        )
        self._client = ResendClient(
            http=self._http,
            api_key=self.api_key,
            base_url=self._base_url,
        )
        proxy = _ThreadStateProxy(self)
        router = build_router(
            queue=self._queue,
            thread_state=proxy,
            client=self._client,
            signing_secret=self.signing_secret,
            allowed_senders=self._allowlist,
            webhook_path=self.webhook_path,
        )

        config = uvicorn.Config(
            app=router,
            host=self.host,
            port=self.port,
            log_level="warning",
            access_log=False,
            lifespan="off",
        )
        self._server = uvicorn.Server(config)
        self._serve_task = asyncio.create_task(self._server.serve())

        while not self._server.started:
            await asyncio.sleep(0.01)

        self._started = True
        self._stopped = False
        _log.info(
            "EmailChannel started host=%s port=%d path=%s",
            self.host,
            self.bound_port,
            self.webhook_path,
        )

    async def stop(self) -> None:
        if self._stopped or not self._started:
            self._stopped = True
            return
        self._stopped = True

        if self._server is not None:
            self._server.should_exit = True
        if self._serve_task is not None:
            try:
                await asyncio.wait_for(self._serve_task, timeout=5.0)
            except TimeoutError:
                self._serve_task.cancel()
        if self._http is not None:
            await self._http.aclose()

    # -----------------------------------------------------------------------
    # Send
    # -----------------------------------------------------------------------

    async def send(self, message: OutgoingMessage) -> None:
        if self._stopped or not self._started:
            raise ChannelError("EmailChannel: send() before start() or after stop()")
        if not message.reply_to_thread_key:
            raise ChannelError("EmailChannel: send() requires reply_to_thread_key (recipient)")
        assert self._client is not None  # guarded by _started

        key = message.reply_to_thread_key
        state = self._thread_state.get(key)
        if state is not None:
            self._thread_state.move_to_end(key)

        subject = subject_for_reply(state, fallback="from zeno")

        if state is not None:
            headers = build_reply_headers(state, self._from_domain, max_references=50)
        else:
            headers = {"Message-ID": new_message_id(self._from_domain)}

        envelope = EmailEnvelope(
            to=key,
            from_address=self.from_address,
            subject=subject,
            text=message.text or "",
            html=wrap_html(message.text or ""),
            headers=headers,
            attachments=tuple(message.attachments or ()),
        )

        try:
            await self._client.send(envelope)
        except EmailBackendError as exc:
            raise ChannelError(str(exc)) from exc

    # -----------------------------------------------------------------------
    # Receive / inbound_put
    # -----------------------------------------------------------------------

    async def inbound_put(self, message: IncomingMessage) -> None:
        """Enqueue a synthetic message onto the receive() path.

        Used by zeno-scheduler to inject proactive messages without a real
        webhook delivery.
        """
        await self._queue.put(message)

    async def receive(self) -> AsyncIterator[IncomingMessage]:
        while not self._stopped:
            try:
                msg = await asyncio.wait_for(self._queue.get(), timeout=0.5)
            except TimeoutError:
                continue
            yield msg
