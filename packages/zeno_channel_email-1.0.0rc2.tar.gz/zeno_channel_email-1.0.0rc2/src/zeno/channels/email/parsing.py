"""Email inbound payload parsing — two-phase translation to Zeno types.

Phase 1 — ``parse_webhook_metadata(payload)``:
    Consumes the Resend ``email.received`` webhook body (JSON dict).  Returns a
    ``WebhookMetadata`` (envelope fields only) or a ``RejectionReason`` sentinel.
    Used by the router for the early allowlist check *before* the
    ``GET /emails/received/{email_id}`` call.

Phase 2 — ``parse_content(meta, retrieved)``:
    Consumes a ``WebhookMetadata`` (from phase 1) plus the JSON dict returned by
    ``GET /emails/received/{email_id}``.  Returns an ``(IncomingMessage,
    EmailThreadState)`` tuple or a ``RejectionReason`` sentinel.

Both functions are pure (no I/O, no side effects).
"""

from __future__ import annotations

import email.utils
import html.parser
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

from zeno.channels.email.state import EmailThreadState, WebhookMetadata
from zeno.channels.messages import IncomingMessage


class RejectionReason(StrEnum):
    """Why the router dropped a webhook payload or retrieved content."""

    WRONG_EVENT_TYPE = "wrong_event_type"
    MISSING_FROM = "missing_from"
    MISSING_EMAIL_ID = "missing_email_id"
    EMPTY = "empty"
    INVALID_PAYLOAD = "invalid_payload"


# ---------------------------------------------------------------------------
# HTML tag-stripping helper (stdlib only — no beautifulsoup4)
# ---------------------------------------------------------------------------


class _TagStripper(html.parser.HTMLParser):
    """Minimal HTMLParser subclass that collects non-tag character data."""

    def __init__(self) -> None:
        super().__init__()
        self._parts: list[str] = []

    def handle_data(self, data: str) -> None:  # noqa: D102
        self._parts.append(data)

    def get_text(self) -> str:
        """Return all character data joined and whitespace-collapsed."""
        raw = " ".join(self._parts)
        # Collapse runs of whitespace to a single space and strip ends.
        return " ".join(raw.split())


def _strip_html(html_body: str) -> str:
    stripper = _TagStripper()
    stripper.feed(html_body)
    return stripper.get_text()


# ---------------------------------------------------------------------------
# Phase 1: webhook metadata
# ---------------------------------------------------------------------------


def parse_webhook_metadata(payload: dict[str, Any]) -> WebhookMetadata | RejectionReason:
    """Parse a Resend ``email.received`` webhook body into ``WebhookMetadata``.

    ``from_addr`` is extracted with ``email.utils.parseaddr`` so that
    display-name injection like ``"attacker@evil.com" <victim@good.com>``
    cannot smuggle a foreign address as the sender — only the bracketed
    address is returned.

    Returns a ``RejectionReason`` on any structural or semantic problem;
    never raises.
    """
    if not isinstance(payload, dict):
        return RejectionReason.INVALID_PAYLOAD

    data = payload.get("data")
    if not isinstance(data, dict):
        return RejectionReason.INVALID_PAYLOAD

    event_type = payload.get("type", "")
    if event_type != "email.received":
        return RejectionReason.WRONG_EVENT_TYPE

    # email_id is required.
    email_id = data.get("email_id")
    if not email_id or not isinstance(email_id, str):
        return RejectionReason.MISSING_EMAIL_ID

    # from is required; parse with stdlib to defeat display-name injection.
    raw_from = data.get("from")
    if not raw_from or not isinstance(raw_from, str):
        return RejectionReason.MISSING_FROM

    _display, addr = email.utils.parseaddr(raw_from)
    from_addr = addr.strip().lower()
    if not from_addr:
        return RejectionReason.MISSING_FROM

    # subject is optional.
    subject_raw = data.get("subject")
    subject: str | None = str(subject_raw).strip() if subject_raw is not None else None
    if subject is not None and not subject:
        subject = None

    return WebhookMetadata(from_addr=from_addr, email_id=email_id, subject=subject)


# ---------------------------------------------------------------------------
# Phase 2: content parsing
# ---------------------------------------------------------------------------


def _extract_references(retrieved: dict[str, Any]) -> tuple[str, ...]:
    """Return the RFC-5322 References chain as a tuple of message-id tokens.

    Probe order (most-canonical first):
    1. ``retrieved["headers"]["References"]``   — space-separated token list
    2. ``retrieved["references"]``               — top-level fallback (payload variance)
    3. ``retrieved["headers"]["In-Reply-To"]``  — single entry
    4. ``retrieved["in_reply_to"]``              — top-level fallback

    New threads (all four missing / empty) → empty tuple.
    """
    headers: dict[str, Any] = {}
    if isinstance(retrieved.get("headers"), dict):
        headers = retrieved["headers"]

    # --- References ---------------------------------------------------------
    refs_raw: str | None = None
    if "References" in headers and isinstance(headers["References"], str):
        refs_raw = headers["References"].strip()
    elif "references" in retrieved and isinstance(retrieved["references"], str):
        refs_raw = retrieved["references"].strip()

    if refs_raw:
        return tuple(refs_raw.split())

    # --- In-Reply-To --------------------------------------------------------
    irt_raw: str | None = None
    if "In-Reply-To" in headers and isinstance(headers["In-Reply-To"], str):
        irt_raw = headers["In-Reply-To"].strip()
    elif "in_reply_to" in retrieved and isinstance(retrieved["in_reply_to"], str):
        irt_raw = retrieved["in_reply_to"].strip()

    if irt_raw:
        return (irt_raw,)

    return ()


def parse_content(
    meta: WebhookMetadata, retrieved: dict[str, Any]
) -> tuple[IncomingMessage, EmailThreadState] | RejectionReason:
    """Parse a ``GET /emails/received/{id}`` response into an ``IncomingMessage``.

    ``meta`` is the ``WebhookMetadata`` produced by ``parse_webhook_metadata``.
    ``retrieved`` is the raw JSON dict from Resend's retrieve-received-email API.

    Prefer ``text`` body; fall back to stripped HTML.  Empty after fallback →
    ``RejectionReason.EMPTY``.  Attachments in ``retrieved`` are silently ignored
    per R10.
    """
    # --- Body extraction ----------------------------------------------------
    text_body = retrieved.get("text") or ""
    if isinstance(text_body, str):
        text_body = text_body.strip()

    if not text_body:
        html_body = retrieved.get("html") or ""
        if isinstance(html_body, str):
            text_body = _strip_html(html_body)

    if not text_body:
        return RejectionReason.EMPTY

    # --- Thread state -------------------------------------------------------
    last_message_id: str = str(retrieved.get("message_id") or "").strip()
    references = _extract_references(retrieved)

    subject_raw = retrieved.get("subject")
    thread_subject: str | None = str(subject_raw).strip() if subject_raw is not None else None
    # Prefer the subject from the retrieved payload; fall back to webhook meta.
    if not thread_subject:
        thread_subject = meta.subject

    thread_state = EmailThreadState(
        last_message_id=last_message_id,
        references=references,
        subject=thread_subject,
    )

    # --- IncomingMessage metadata -------------------------------------------
    in_reply_to: str | None = None
    headers: dict[str, Any] = {}
    if isinstance(retrieved.get("headers"), dict):
        headers = retrieved["headers"]
    if "In-Reply-To" in headers and isinstance(headers["In-Reply-To"], str):
        in_reply_to = headers["In-Reply-To"].strip() or None
    elif "in_reply_to" in retrieved and isinstance(retrieved["in_reply_to"], str):
        in_reply_to = retrieved["in_reply_to"].strip() or None

    email_metadata: dict[str, Any] = {
        "email": {
            "email_id": meta.email_id,
            "message_id": last_message_id,
            "in_reply_to": in_reply_to,
            "references": list(references),
            "subject": thread_subject,
        }
    }

    incoming = IncomingMessage(
        user_id=meta.from_addr,
        thread_key=meta.from_addr,
        text=text_body,
        received_at=datetime.now(UTC),
        attachments=[],
        blocks=[],
        metadata=email_metadata,
    )

    return incoming, thread_state
