"""EmailOutbound protocol, EmailEnvelope, EmailBackendError, and RFC-5322 header math.

Pure functions in this module:
  - ``new_message_id`` — generate a unique RFC-5322 Message-ID.
  - ``build_reply_headers`` — build In-Reply-To / References / Message-ID for a reply,
    capping the References chain at ``max_references`` entries to prevent DoS from
    attacker-crafted inbounds with very long Reference chains.
  - ``wrap_html`` — minimal HTML wrap around a plaintext body.
  - ``subject_for_reply`` — produce a "Re: …" subject, avoiding double-prefix.
"""

from __future__ import annotations

import html
import uuid
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Protocol, runtime_checkable

from zeno.channels.messages import Attachment

if TYPE_CHECKING:
    from zeno.channels.email.state import EmailThreadState


class EmailBackendError(Exception):
    """Raised by EmailOutbound implementations on non-2xx or transport errors."""


@dataclass(frozen=True, slots=True)
class EmailEnvelope:
    """All fields needed to send one email via an EmailOutbound implementation."""

    to: str
    from_address: str
    subject: str
    text: str
    html: str
    headers: dict[str, str] = field(default_factory=dict)
    attachments: tuple[Attachment, ...] = field(default_factory=tuple)


@runtime_checkable
class EmailOutbound(Protocol):
    """Pluggable outbound email backend.  Implementations must be async-safe."""

    async def send(self, envelope: EmailEnvelope) -> None:
        """Send *envelope*.  Raises ``EmailBackendError`` on failure."""
        ...


# ---------------------------------------------------------------------------
# Header math
# ---------------------------------------------------------------------------


def new_message_id(domain: str) -> str:
    """Return a unique RFC-5322 Message-ID token ``<{uuid4.hex}@{domain}>``."""
    return f"<{uuid.uuid4().hex}@{domain}>"


def build_reply_headers(
    state: EmailThreadState,
    from_domain: str,
    *,
    max_references: int = 50,
) -> dict[str, str]:
    """Build reply headers for an outbound email.

    Returns a dict with ``Message-ID`` and ``In-Reply-To`` always present.
    ``References`` is included only when *state.references* is non-empty.

    The References chain is capped at *max_references* entries.  When the
    incoming chain exceeds the cap the function retains index 0 (the thread root)
    plus the most-recent tail entries so that thread root identity is preserved
    while bounding output size.
    """
    result: dict[str, str] = {}

    result["Message-ID"] = new_message_id(from_domain)
    result["In-Reply-To"] = state.last_message_id

    all_refs = list(state.references) + [state.last_message_id]

    if state.references:
        # Cap: keep root (index 0) + most-recent tail.
        if len(all_refs) > max_references:
            root = all_refs[0]
            tail = all_refs[-(max_references - 1) :]
            capped = [root] + tail
        else:
            capped = all_refs
        result["References"] = " ".join(capped)

    return result


def wrap_html(plaintext: str) -> str:
    """Wrap *plaintext* in a minimal HTML shell so line breaks render in email clients.

    Uses a ``<pre>`` element with a sensible font-family so the body renders
    as plain text but with correct line-break semantics in Gmail and Outlook.
    The text is HTML-escaped to prevent injection.
    """
    escaped = html.escape(plaintext)
    return (
        "<html><body>"
        '<pre style="font-family: sans-serif; white-space: pre-wrap; word-wrap: break-word;">'
        f"{escaped}"
        "</pre>"
        "</body></html>"
    )


def subject_for_reply(state: EmailThreadState | None, fallback: str) -> str:
    """Return the subject to use for an outbound reply.

    - If *state* is ``None`` → *fallback*.
    - If ``state.subject`` already starts with ``Re:`` (case-insensitive) → return as-is.
    - Otherwise → prepend ``"Re: "``.
    - If ``state.subject`` is ``None`` → *fallback*.
    """
    if state is None or state.subject is None:
        return fallback
    if state.subject.lower().startswith("re:"):
        return state.subject
    return f"Re: {state.subject}"
