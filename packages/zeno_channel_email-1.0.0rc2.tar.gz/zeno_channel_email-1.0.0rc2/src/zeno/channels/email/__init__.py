"""zeno-channel-email — Resend-backed email channel for Zeno."""

from zeno.channels.email.channel import ChannelError, EmailChannel
from zeno.channels.email.outbound import EmailBackendError, EmailEnvelope, EmailOutbound

__all__ = [
    "ChannelError",
    "EmailBackendError",
    "EmailChannel",
    "EmailEnvelope",
    "EmailOutbound",
]
