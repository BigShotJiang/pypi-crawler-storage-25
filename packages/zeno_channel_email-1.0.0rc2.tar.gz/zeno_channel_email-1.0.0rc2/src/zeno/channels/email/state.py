"""Email-specific state dataclasses for inbound thread tracking and webhook metadata."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class EmailThreadState:
    """RFC-5322 threading state extracted from an inbound email.

    Stored per-sender on the channel's in-memory cache; used by ``send()`` to
    produce correct ``In-Reply-To`` / ``References`` headers on outbound replies.
    Lost on channel restart — the next inbound from the same sender repopulates it.
    """

    last_message_id: str
    references: tuple[str, ...]
    subject: str | None


@dataclass(frozen=True, slots=True)
class WebhookMetadata:
    """Metadata extracted from a Resend ``email.received`` webhook body.

    The webhook carries only envelope-level fields; full body and RFC-5322
    headers require a follow-up ``GET /emails/received/{email_id}`` call.
    ``from_addr`` is always lower-cased and stripped.
    """

    from_addr: str
    email_id: str
    subject: str | None
