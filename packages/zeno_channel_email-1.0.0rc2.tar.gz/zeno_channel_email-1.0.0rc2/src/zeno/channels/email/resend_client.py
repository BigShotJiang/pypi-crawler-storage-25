"""Thin httpx wrapper over Resend's REST API.

Two endpoints:
  - ``POST /emails`` — send an outbound email.  Raises ``EmailBackendError`` on
    non-2xx or transport error.
  - ``GET /emails/received/{email_id}`` — fetch the full parsed inbound email
    (body + RFC-5322 headers).  Raises ``EmailBackendError`` on non-2xx or
    transport error.

The client does NOT own its ``httpx.AsyncClient``; the channel creates and closes
it alongside the rest of its lifecycle.  No internal retry — Zeno's
``on_send_failure`` policy handles that at the core layer.
"""

from __future__ import annotations

import base64
import logging
from typing import Any

import httpx
from zeno.channels.email.outbound import EmailBackendError, EmailEnvelope
from zeno.channels.messages import Attachment

_log = logging.getLogger("zeno.channels.email")

_MAX_BODY_LOG = 500


class ResendClient:
    """Low-level Resend REST client.  Owned and lifecycled by the channel.

    ``api_key`` is excluded from ``__repr__`` to prevent accidental secret
    exposure in tracebacks and log lines.
    """

    def __init__(
        self,
        http: httpx.AsyncClient,
        api_key: str,
        base_url: str = "https://api.resend.com",
    ) -> None:
        self._http = http
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._headers: dict[str, str] = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

    def __repr__(self) -> str:
        return f"ResendClient(base_url={self._base_url!r})"

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _serialize_attachment(att: Attachment) -> dict[str, Any]:
        """Convert an ``Attachment`` to Resend's attachment payload shape."""
        payload: dict[str, Any] = {}
        if att.filename is not None:
            payload["filename"] = att.filename
        if att.url is not None:
            payload["path"] = att.url
        elif att.data is not None:
            payload["content"] = base64.b64encode(att.data).decode()
        if att.mime_type is not None:
            payload["content_type"] = att.mime_type
        return payload

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def send(self, envelope: EmailEnvelope) -> None:
        """POST *envelope* to ``/emails``.

        Raises ``EmailBackendError`` on non-2xx responses or httpx transport
        errors.
        """
        body: dict[str, Any] = {
            "from": envelope.from_address,
            "to": [envelope.to],
            "subject": envelope.subject,
            "text": envelope.text,
            "html": envelope.html,
            "headers": envelope.headers,
        }
        if envelope.attachments:
            body["attachments"] = [self._serialize_attachment(a) for a in envelope.attachments]

        url = f"{self._base_url}/emails"
        try:
            resp = await self._http.post(url, json=body, headers=self._headers)
        except httpx.TransportError as exc:
            raise EmailBackendError(f"transport: {exc}") from exc

        if not (200 <= resp.status_code < 300):
            raise EmailBackendError(
                f"POST /emails {resp.status_code}: {resp.text[:_MAX_BODY_LOG]!r}"
            )

    async def fetch_received(self, email_id: str) -> dict[str, Any]:
        """GET ``/emails/received/{email_id}``.

        Returns the full parsed JSON dict for ``parse_content`` to consume.
        Raises ``EmailBackendError`` on non-2xx responses or httpx transport
        errors.
        """
        url = f"{self._base_url}/emails/received/{email_id}"
        try:
            resp = await self._http.get(url, headers=self._headers)
        except httpx.TransportError as exc:
            raise EmailBackendError(f"transport: {exc}") from exc

        if not (200 <= resp.status_code < 300):
            raise EmailBackendError(
                f"GET /emails/received/{email_id} {resp.status_code}: {resp.text[:_MAX_BODY_LOG]!r}"
            )

        return resp.json()  # type: ignore[no-any-return]
