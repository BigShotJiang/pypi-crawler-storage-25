"""Starlette router backing `EmailChannel`'s Resend webhook.

One POST route:
  1. Verify Svix HMAC signature (401 on bad/missing sig, 200 on stale).
  2. Parse JSON body.
  3. Parse webhook metadata (event type, from_addr, email_id).
  4. Apply sender allowlist.
  5. Fetch full inbound email via ResendClient.
  6. Parse content into IncomingMessage + EmailThreadState.
  7. Register thread state (BEFORE enqueue so the turn worker never races).
  8. Enqueue with timeout.

Response policy:
  * 401 only on bad/missing Svix signature — every other rejection returns 200
    so Resend does not retry and so the 401 audit signal stays meaningful.
  * Stale-but-valid timestamp returns 200 (avoids leaking "signature was valid").

The router is a pure factory; it owns no state beyond what the caller passes in.
Lifecycle (uvicorn, httpx client) lives on the channel.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from collections.abc import Callable, Iterable, MutableMapping

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import Response
from starlette.routing import Route
from zeno.channels.email.outbound import EmailBackendError
from zeno.channels.email.parsing import RejectionReason, parse_content, parse_webhook_metadata
from zeno.channels.email.resend_client import ResendClient
from zeno.channels.email.signing import build_signed_content, verify
from zeno.channels.email.state import EmailThreadState
from zeno.channels.messages import IncomingMessage

logger = logging.getLogger(__name__)


def build_router(
    *,
    queue: asyncio.Queue[IncomingMessage],
    thread_state: MutableMapping[str, EmailThreadState],
    client: ResendClient,
    signing_secret: str,
    allowed_senders: Iterable[str],
    webhook_path: str = "/webhook",
    enqueue_timeout: float = 1.0,
    max_sig_age: float = 300.0,
    now: Callable[[], float] | None = None,
) -> Starlette:
    """Build the Starlette app that receives Resend inbound webhooks."""
    allowlist: frozenset[str] = frozenset(s.strip().lower() for s in allowed_senders)
    _now: Callable[[], float] = now if now is not None else time.time

    async def handle(request: Request) -> Response:  # noqa: C901  (complexity is the spec)
        # ------------------------------------------------------------------
        # Step 1: Read raw body
        # ------------------------------------------------------------------
        raw_body = await request.body()

        # ------------------------------------------------------------------
        # Step 2: Signature verification
        #
        # We need to distinguish *stale* (valid sig, outside window) from
        # *bad/missing* (invalid sig or missing headers).  The low-level
        # `signing.verify` + header extraction lets us do this without
        # re-implementing HMAC; we replicate the header presence check, then
        # check timestamp freshness, then check HMAC — each case handled
        # separately.
        # ------------------------------------------------------------------
        svix_id = request.headers.get("svix-id")
        svix_timestamp = request.headers.get("svix-timestamp")
        svix_signature = request.headers.get("svix-signature")

        if not svix_id or not svix_timestamp or svix_signature is None:
            logger.warning("event=missing_headers from=n/a email_id=n/a")
            return Response(status_code=401)

        try:
            ts = int(svix_timestamp)
        except ValueError:
            logger.warning("event=malformed_timestamp from=n/a email_id=n/a")
            return Response(status_code=401)

        age = abs(_now() - ts)
        if age > max_sig_age:
            # Timestamp is outside the window — check HMAC anyway so we can
            # distinguish "stale valid" from "stale forged" without logging
            # the signature.
            signed_content = build_signed_content(svix_id, svix_timestamp, raw_body)
            try:
                sig_valid = verify(signed_content, svix_signature, signing_secret)
            except ValueError:
                logger.warning("event=bad_signature from=n/a email_id=n/a")
                return Response(status_code=401)
            if sig_valid:
                logger.warning("event=stale_timestamp from=n/a email_id=n/a")
                return Response(status_code=200)
            else:
                logger.warning("event=bad_signature from=n/a email_id=n/a")
                return Response(status_code=401)

        # Timestamp is fresh — now verify HMAC.
        signed_content = build_signed_content(svix_id, svix_timestamp, raw_body)
        try:
            sig_valid = verify(signed_content, svix_signature, signing_secret)
        except ValueError:
            logger.warning("event=bad_signature from=n/a email_id=n/a")
            return Response(status_code=401)

        if not sig_valid:
            logger.warning("event=bad_signature from=n/a email_id=n/a")
            return Response(status_code=401)

        # ------------------------------------------------------------------
        # Step 3: Parse JSON
        # ------------------------------------------------------------------
        try:
            body = json.loads(raw_body) if raw_body else {}
        except json.JSONDecodeError:
            logger.warning("event=malformed_json from=n/a email_id=n/a")
            return Response(status_code=200)

        # ------------------------------------------------------------------
        # Step 4: Parse webhook metadata
        # ------------------------------------------------------------------
        meta_or_reason = parse_webhook_metadata(body)
        if isinstance(meta_or_reason, RejectionReason):
            logger.warning("event=%s from=n/a email_id=n/a", meta_or_reason.value)
            return Response(status_code=200)

        meta = meta_or_reason

        # ------------------------------------------------------------------
        # Step 5: Sender allowlist
        # ------------------------------------------------------------------
        if meta.from_addr not in allowlist:
            logger.warning(
                "event=sender_not_allowed from=%s email_id=%s",
                meta.from_addr,
                meta.email_id,
            )
            return Response(status_code=200)

        # ------------------------------------------------------------------
        # Step 6: Fetch full inbound email
        # ------------------------------------------------------------------
        try:
            retrieved = await client.fetch_received(meta.email_id)
        except EmailBackendError as exc:
            logger.warning(
                "event=fetch_failed from=%s email_id=%s error=%s",
                meta.from_addr,
                meta.email_id,
                exc,
            )
            return Response(status_code=200)

        # ------------------------------------------------------------------
        # Step 7: Parse content
        # ------------------------------------------------------------------
        parsed_or_reason = parse_content(meta, retrieved)
        if isinstance(parsed_or_reason, RejectionReason):
            logger.warning(
                "event=%s from=%s email_id=%s",
                parsed_or_reason.value,
                meta.from_addr,
                meta.email_id,
            )
            return Response(status_code=200)

        incoming, state = parsed_or_reason

        # ------------------------------------------------------------------
        # Step 8: Register thread state BEFORE enqueue
        # ------------------------------------------------------------------
        thread_state[incoming.user_id] = state

        # ------------------------------------------------------------------
        # Step 9: Enqueue
        # ------------------------------------------------------------------
        try:
            await asyncio.wait_for(queue.put(incoming), timeout=enqueue_timeout)
        except TimeoutError:
            logger.warning(
                "event=queue_full from=%s email_id=%s",
                meta.from_addr,
                meta.email_id,
            )
            return Response(status_code=200)

        # ------------------------------------------------------------------
        # Step 10: Success
        # ------------------------------------------------------------------
        return Response(status_code=200)

    return Starlette(routes=[Route(webhook_path, handle, methods=["POST"])])
