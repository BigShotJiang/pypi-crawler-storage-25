"""Svix HMAC-SHA256 webhook signature verification for Resend inbound events.

Resend signs incoming webhooks via Svix. The signed content is formed by
concatenating the `svix-id`, `svix-timestamp`, and raw request body with
period delimiters: `{svix-id}.{svix-timestamp}.{raw_body}`. The signing key
is the base64-encoded portion of the `whsec_<base64key>` secret (the prefix
may be absent, in which case the entire value is treated as raw base64). The
`svix-signature` header carries one or more space-delimited `v1,<base64sig>`
tokens; the request is authentic if any `v1` token matches an HMAC-SHA256 of
the signed content under the decoded key. Timestamp freshness is enforced
via a configurable `max_age` window (default 300 s) to prevent replay attacks.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import time
from collections.abc import Callable, Mapping

_WHSEC_PREFIX = "whsec_"


def _decode_secret(secret: str) -> bytes:
    """Decode a Svix webhook secret to raw bytes.

    Accepts both `whsec_<base64>` and bare base64 forms.
    Raises ValueError on malformed base64.
    """
    raw = secret.removeprefix(_WHSEC_PREFIX)
    try:
        return base64.b64decode(raw)
    except Exception as exc:
        raise ValueError(f"invalid whsec: {exc}") from exc


def build_signed_content(svix_id: str, svix_timestamp: str, raw_body: bytes) -> bytes:
    """Return the Svix signed-content bytes: `{svix_id}.{svix_timestamp}.{raw_body}`."""
    return svix_id.encode() + b"." + svix_timestamp.encode() + b"." + raw_body


def verify(signed_content: bytes, signatures: str, secret: str) -> bool:
    """Return True iff at least one `v1,…` token in *signatures* is valid.

    *secret* must be a `whsec_<base64>` string or bare base64.
    Raises ValueError if *secret* cannot be base64-decoded.
    """
    key = _decode_secret(secret)

    expected_mac = hmac.new(key, signed_content, hashlib.sha256).digest()
    expected_b64 = base64.b64encode(expected_mac)

    v1_tokens = [tok.split(",", 1)[1] for tok in signatures.split() if tok.startswith("v1,")]
    if not v1_tokens:
        return False

    verified = False
    for candidate in v1_tokens:
        try:
            candidate_bytes = base64.b64decode(candidate)
        except Exception:
            continue
        if hmac.compare_digest(expected_b64, base64.b64encode(candidate_bytes)):
            verified = True
            break

    return verified


def verify_request(
    headers: Mapping[str, str],
    raw_body: bytes,
    secret: str,
    *,
    max_age: float = 300.0,
    now: Callable[[], float] = time.time,
) -> bool:
    """Verify a Svix-signed HTTP request end-to-end.

    Checks that `svix-id`, `svix-timestamp`, and `svix-signature` are all
    present, that the timestamp is within *max_age* seconds of *now*, and
    that at least one `v1` signature token is valid.

    Raises ValueError if *secret* is malformed (propagated from `verify`).
    Returns False for any missing header, stale/future timestamp, or bad sig.
    """
    svix_id = headers.get("svix-id")
    svix_timestamp = headers.get("svix-timestamp")
    svix_signature = headers.get("svix-signature")

    if not svix_id or not svix_timestamp or svix_signature is None:
        return False

    try:
        ts = int(svix_timestamp)
    except ValueError:
        return False

    if abs(now() - ts) > max_age:
        return False

    signed_content = build_signed_content(svix_id, svix_timestamp, raw_body)
    return verify(signed_content, svix_signature, secret)
