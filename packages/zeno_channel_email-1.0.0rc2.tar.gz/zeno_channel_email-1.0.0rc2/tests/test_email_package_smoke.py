"""Package smoke test — verifies the namespace package resolves."""

from __future__ import annotations


def test_package_imports() -> None:
    import zeno.channels.email  # noqa: F401
