"""Tests for EmailOutbound protocol, EmailEnvelope, and pure header-math helpers.

Header-math tests are co-located here (rather than a separate test_headers.py)
because they exercise the same module.  ``test_headers.py`` is therefore not
created; this file covers the full test_headers.py test matrix.
"""

from __future__ import annotations

import re

from zeno.channels.email.outbound import (
    EmailBackendError,
    EmailEnvelope,
    EmailOutbound,
    build_reply_headers,
    new_message_id,
    subject_for_reply,
    wrap_html,
)
from zeno.channels.email.resend_client import ResendClient
from zeno.channels.email.state import EmailThreadState

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def make_state(
    last_message_id: str = "<last@x>",
    references: tuple[str, ...] = (),
    subject: str | None = "Hello",
) -> EmailThreadState:
    return EmailThreadState(
        last_message_id=last_message_id,
        references=references,
        subject=subject,
    )


# ---------------------------------------------------------------------------
# Protocol isinstance check
# ---------------------------------------------------------------------------


def test_resend_client_satisfies_email_outbound(tmp_path: object) -> None:
    """ResendClient must satisfy the EmailOutbound runtime-checkable Protocol."""
    import httpx

    client = ResendClient(http=httpx.AsyncClient(), api_key="re_test")
    assert isinstance(client, EmailOutbound)


# ---------------------------------------------------------------------------
# new_message_id
# ---------------------------------------------------------------------------


def test_new_message_id_format() -> None:
    mid = new_message_id("example.com")
    assert re.fullmatch(r"<[0-9a-f]{32}@example\.com>", mid), f"unexpected: {mid!r}"


def test_new_message_id_unique() -> None:
    a = new_message_id("example.com")
    b = new_message_id("example.com")
    assert a != b


# ---------------------------------------------------------------------------
# build_reply_headers
# ---------------------------------------------------------------------------


def test_build_reply_headers_with_references() -> None:
    state = make_state(last_message_id="<b@x>", references=("<a@x>",))
    headers = build_reply_headers(state, "example.com")

    assert headers["In-Reply-To"] == "<b@x>"
    assert headers["References"] == "<a@x> <b@x>"
    assert "Message-ID" in headers
    assert re.fullmatch(r"<[0-9a-f]{32}@example\.com>", headers["Message-ID"])


def test_build_reply_headers_empty_references() -> None:
    """New thread: References key must be OMITTED; In-Reply-To still set."""
    state = make_state(last_message_id="<last@x>", references=())
    headers = build_reply_headers(state, "example.com")

    assert headers["In-Reply-To"] == "<last@x>"
    assert "References" not in headers
    assert "Message-ID" in headers


def test_build_reply_headers_caps_at_max_references() -> None:
    """A 200-entry References chain must be capped at the default 50 entries."""
    refs = tuple(f"<msg{i}@x>" for i in range(200))
    state = make_state(last_message_id="<msg200@x>", references=refs)
    headers = build_reply_headers(state, "example.com", max_references=50)

    emitted = headers["References"].split()
    assert len(emitted) <= 50
    # Thread root preserved
    assert emitted[0] == refs[0]
    # Most-recent (last_message_id) preserved
    assert emitted[-1] == "<msg200@x>"


def test_build_reply_headers_long_single_reference_still_emitted() -> None:
    """Entry count cap, not byte-size cap.  A single very long ref still passes."""
    long_ref = "<" + "a" * 2000 + "@example.com>"
    state = make_state(last_message_id="<last@x>", references=(long_ref,))
    headers = build_reply_headers(state, "example.com")
    assert long_ref in headers["References"]


# ---------------------------------------------------------------------------
# wrap_html
# ---------------------------------------------------------------------------


def test_wrap_html_contains_content() -> None:
    out = wrap_html("hello\nworld")
    assert "hello" in out
    assert "world" in out


def test_wrap_html_is_valid_html_shell() -> None:
    out = wrap_html("hello\nworld")
    assert "<html>" in out
    assert "<body>" in out
    assert "</body>" in out
    assert "</html>" in out


def test_wrap_html_escapes_html_characters() -> None:
    out = wrap_html("<script>alert('xss')</script>")
    assert "<script>" not in out
    assert "&lt;script&gt;" in out


def test_wrap_html_preserves_line_break_semantics() -> None:
    """The <pre> element or explicit <br> must be present to preserve newlines."""
    out = wrap_html("line1\nline2")
    assert "<pre" in out or "<br" in out


# ---------------------------------------------------------------------------
# subject_for_reply
# ---------------------------------------------------------------------------


def test_subject_for_reply_none_state() -> None:
    assert subject_for_reply(None, "Update") == "Update"


def test_subject_for_reply_already_re() -> None:
    state = make_state(subject="Re: hi")
    assert subject_for_reply(state, "fallback") == "Re: hi"


def test_subject_for_reply_already_re_case_insensitive() -> None:
    state = make_state(subject="RE: hi")
    assert subject_for_reply(state, "fallback") == "RE: hi"


def test_subject_for_reply_adds_re_prefix() -> None:
    state = make_state(subject="hi")
    assert subject_for_reply(state, "fallback") == "Re: hi"


def test_subject_for_reply_none_subject_uses_fallback() -> None:
    state = make_state(subject=None)
    assert subject_for_reply(state, "fallback") == "fallback"


# ---------------------------------------------------------------------------
# EmailBackendError is an Exception
# ---------------------------------------------------------------------------


def test_email_backend_error_is_exception() -> None:
    err = EmailBackendError("boom")
    assert isinstance(err, Exception)
    assert str(err) == "boom"


# ---------------------------------------------------------------------------
# EmailEnvelope defaults
# ---------------------------------------------------------------------------


def test_email_envelope_defaults() -> None:
    env = EmailEnvelope(
        to="a@b.com",
        from_address="c@d.com",
        subject="hi",
        text="body",
        html="<b>body</b>",
    )
    assert env.headers == {}
    assert env.attachments == ()
