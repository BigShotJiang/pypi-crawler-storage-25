"""Tests for zeno.channels.email.signing — Svix HMAC-SHA256 verification."""

from __future__ import annotations

import base64
import hashlib
import hmac as _hmac

import pytest
from zeno.channels.email.signing import (
    build_signed_content,
    verify,
    verify_request,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SECRET_BYTES = b"super-secret-key-for-testing-1234"
_WHSEC = "whsec_" + base64.b64encode(_SECRET_BYTES).decode()
_WHSEC_NO_PREFIX = base64.b64encode(_SECRET_BYTES).decode()

_SVIX_ID = "msg_2abc"
_SVIX_TIMESTAMP = "1700000000"
_RAW_BODY = b'{"type":"email.received","data":{"email_id":"em_xyz"}}'


def _make_sig(secret_bytes: bytes, signed: bytes) -> str:
    """Compute a valid v1 Svix signature string."""
    mac = _hmac.new(secret_bytes, signed, hashlib.sha256).digest()
    return "v1," + base64.b64encode(mac).decode()


def _signed() -> bytes:
    return build_signed_content(_SVIX_ID, _SVIX_TIMESTAMP, _RAW_BODY)


def _valid_sig() -> str:
    return _make_sig(_SECRET_BYTES, _signed())


# ---------------------------------------------------------------------------
# build_signed_content
# ---------------------------------------------------------------------------


def test_build_signed_content_format() -> None:
    content = build_signed_content("id1", "ts1", b"body")
    assert content == b"id1.ts1.body"


# ---------------------------------------------------------------------------
# verify — happy paths
# ---------------------------------------------------------------------------


def test_verify_valid_signature_returns_true() -> None:
    sig = _valid_sig()
    assert verify(_signed(), sig, _WHSEC) is True


def test_verify_multiple_v1_sigs_one_valid_returns_true() -> None:
    valid = _valid_sig()
    sigs = "v1,AAAA== " + valid + " v1,BBBB=="
    assert verify(_signed(), sigs, _WHSEC) is True


def test_verify_secret_without_whsec_prefix_accepted() -> None:
    sig = _valid_sig()
    assert verify(_signed(), sig, _WHSEC_NO_PREFIX) is True


def test_verify_extra_whitespace_in_header_accepted() -> None:
    sig = "  " + _valid_sig() + "  "
    assert verify(_signed(), sig, _WHSEC) is True


# ---------------------------------------------------------------------------
# verify — error paths
# ---------------------------------------------------------------------------


def test_verify_empty_signature_header_returns_false() -> None:
    assert verify(_signed(), "", _WHSEC) is False


def test_verify_only_v2_tokens_returns_false() -> None:
    sigs = "v2,AAAA== v2,BBBB=="
    assert verify(_signed(), sigs, _WHSEC) is False


def test_verify_tampered_body_returns_false() -> None:
    tampered = build_signed_content(_SVIX_ID, _SVIX_TIMESTAMP, b"tampered-body")
    sig = _valid_sig()
    assert verify(tampered, sig, _WHSEC) is False


def test_verify_wrong_secret_returns_false() -> None:
    wrong_secret = "whsec_" + base64.b64encode(b"wrong-secret-key-12345678").decode()
    sig = _valid_sig()
    assert verify(_signed(), sig, wrong_secret) is False


def test_verify_invalid_base64_secret_raises_value_error() -> None:
    with pytest.raises(ValueError, match="invalid whsec"):
        verify(_signed(), _valid_sig(), "whsec_!!!notbase64!!!")


def test_verify_invalid_base64_secret_no_prefix_raises_value_error() -> None:
    with pytest.raises(ValueError, match="invalid whsec"):
        verify(_signed(), _valid_sig(), "!!!notbase64!!!")


# ---------------------------------------------------------------------------
# verify_request — replay / timestamp defense
# ---------------------------------------------------------------------------

_FIXED_NOW = float(_SVIX_TIMESTAMP)


def _headers_for_request(
    sig: str | None = None,
    svix_id: str = _SVIX_ID,
    svix_timestamp: str = _SVIX_TIMESTAMP,
) -> dict[str, str]:
    """Build the minimal Svix request headers dict."""
    h: dict[str, str] = {
        "svix-id": svix_id,
        "svix-timestamp": svix_timestamp,
    }
    if sig is not None:
        h["svix-signature"] = sig
    return h


def _build_sig_for(svix_id: str, svix_timestamp: str, body: bytes) -> str:
    signed = build_signed_content(svix_id, svix_timestamp, body)
    return _make_sig(_SECRET_BYTES, signed)


def test_verify_request_valid_within_window() -> None:
    sig = _build_sig_for(_SVIX_ID, _SVIX_TIMESTAMP, _RAW_BODY)
    headers = _headers_for_request(sig)
    # now == timestamp → delta is 0, well within 300s
    assert verify_request(headers, _RAW_BODY, _WHSEC, now=lambda: _FIXED_NOW) is True


def test_verify_request_within_window_slightly_in_past() -> None:
    sig = _build_sig_for(_SVIX_ID, _SVIX_TIMESTAMP, _RAW_BODY)
    headers = _headers_for_request(sig)
    # 299s in the future relative to timestamp
    assert verify_request(headers, _RAW_BODY, _WHSEC, now=lambda: _FIXED_NOW + 299.0) is True


def test_verify_request_within_window_slightly_in_future() -> None:
    sig = _build_sig_for(_SVIX_ID, _SVIX_TIMESTAMP, _RAW_BODY)
    headers = _headers_for_request(sig)
    # timestamp 299s ahead of now
    assert verify_request(headers, _RAW_BODY, _WHSEC, now=lambda: _FIXED_NOW - 299.0) is True


def test_verify_request_timestamp_too_old_returns_false() -> None:
    sig = _build_sig_for(_SVIX_ID, _SVIX_TIMESTAMP, _RAW_BODY)
    headers = _headers_for_request(sig)
    # now is 301s past the timestamp
    assert verify_request(headers, _RAW_BODY, _WHSEC, now=lambda: _FIXED_NOW + 301.0) is False


def test_verify_request_timestamp_too_far_future_returns_false() -> None:
    sig = _build_sig_for(_SVIX_ID, _SVIX_TIMESTAMP, _RAW_BODY)
    headers = _headers_for_request(sig)
    # timestamp is 301s ahead of now → replay from the future
    assert verify_request(headers, _RAW_BODY, _WHSEC, now=lambda: _FIXED_NOW - 301.0) is False


def test_verify_request_missing_signature_header_returns_false() -> None:
    # no svix-signature key at all
    headers = _headers_for_request(sig=None)
    assert verify_request(headers, _RAW_BODY, _WHSEC, now=lambda: _FIXED_NOW) is False


def test_verify_request_missing_svix_id_returns_false() -> None:
    sig = _build_sig_for(_SVIX_ID, _SVIX_TIMESTAMP, _RAW_BODY)
    headers = {
        "svix-timestamp": _SVIX_TIMESTAMP,
        "svix-signature": sig,
    }
    assert verify_request(headers, _RAW_BODY, _WHSEC, now=lambda: _FIXED_NOW) is False


def test_verify_request_missing_svix_timestamp_returns_false() -> None:
    sig = _build_sig_for(_SVIX_ID, _SVIX_TIMESTAMP, _RAW_BODY)
    headers = {
        "svix-id": _SVIX_ID,
        "svix-signature": sig,
    }
    assert verify_request(headers, _RAW_BODY, _WHSEC, now=lambda: _FIXED_NOW) is False


def test_verify_request_invalid_secret_propagates_value_error() -> None:
    sig = _build_sig_for(_SVIX_ID, _SVIX_TIMESTAMP, _RAW_BODY)
    headers = _headers_for_request(sig)
    with pytest.raises(ValueError, match="invalid whsec"):
        verify_request(headers, _RAW_BODY, "whsec_!!!bad!!!", now=lambda: _FIXED_NOW)
