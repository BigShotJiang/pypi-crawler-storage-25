"""Tests for EmailChannel.inbound_put — scheduler injection path.

Trivial: verify that inbound_put puts messages onto the internal _queue and
that receive() subsequently yields them. The HTTP server startup is mocked
out so no real uvicorn/network activity occurs.
"""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime

import httpx
import pytest
from zeno.channels.email.channel import EmailChannel
from zeno.channels.messages import IncomingMessage


def _msg(text: str = "scheduled trigger") -> IncomingMessage:
    return IncomingMessage(
        user_id="alice@example.com",
        text=text,
        received_at=datetime(2026, 4, 24, 12, 0, 0, tzinfo=UTC),
        thread_key="alice@example.com",
    )


def _make_channel() -> EmailChannel:
    """Construct an EmailChannel without starting uvicorn."""
    return EmailChannel(
        api_key="test-api-key",
        signing_secret="whsec_dGVzdA==",
        from_address="zeno@outbound.example.com",
        allowed_senders=("alice@example.com",),
        _transport=httpx.MockTransport(lambda req: httpx.Response(200)),
    )


async def test_inbound_put_enqueues_message() -> None:
    """inbound_put places the message onto the internal _queue."""
    ch = _make_channel()
    msg = _msg()
    await ch.inbound_put(msg)
    assert ch._queue.qsize() == 1
    assert ch._queue.get_nowait() is msg


async def test_inbound_put_multiple_messages_fifo() -> None:
    """Multiple inbound_put calls queue messages in FIFO order."""
    ch = _make_channel()
    msgs = [_msg(f"msg-{i}") for i in range(3)]
    for m in msgs:
        await ch.inbound_put(m)

    retrieved = [ch._queue.get_nowait() for _ in range(3)]
    assert [m.text for m in retrieved] == ["msg-0", "msg-1", "msg-2"]


async def test_receive_yields_injected_message(monkeypatch: pytest.MonkeyPatch) -> None:
    """receive() yields a message placed via inbound_put without real webhook."""
    ch = _make_channel()

    # Inject the message before iterating receive.
    msg = _msg("hello from scheduler")
    await ch.inbound_put(msg)

    # Mark channel as started so receive() runs (it checks _stopped).
    ch._started = True

    received: list[IncomingMessage] = []

    async def _collect() -> None:
        async for m in ch.receive():
            received.append(m)
            ch._stopped = True  # stop after first message

    await asyncio.wait_for(_collect(), timeout=2.0)

    assert len(received) == 1
    assert received[0].text == "hello from scheduler"
    assert received[0].thread_key == "alice@example.com"
