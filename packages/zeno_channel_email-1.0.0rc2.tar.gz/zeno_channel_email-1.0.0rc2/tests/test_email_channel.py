"""End-to-end tests for EmailChannel — live uvicorn + real HTTP."""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import time
import uuid
from typing import Any

import httpx
import pytest
from zeno.channels.email.channel import ChannelError, EmailChannel
from zeno.channels.email.state import EmailThreadState
from zeno.channels.messages import OutgoingMessage
from zeno.channels.protocol import Channel

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SECRET = "whsec_dGVzdHNlY3JldGZvcnRlc3Rpbmcx"  # base64("testsecretfortesting1")
ALLOWED_SENDER = "alice@example.com"
FROM_ADDRESS = "zeno@outbound.example.com"
EMAIL_ID = "em_abc123"


# ---------------------------------------------------------------------------
# Signing helper
# ---------------------------------------------------------------------------


def _decode_secret(secret: str) -> bytes:
    raw = secret.removeprefix("whsec_")
    return base64.b64decode(raw)


def make_signed_headers(
    body_bytes: bytes,
    *,
    secret: str,
    timestamp: int | None = None,
) -> dict[str, str]:
    """Build fresh svix headers signed with the real HMAC-SHA256 algorithm."""
    svix_id = f"msg_{uuid.uuid4().hex}"
    ts = timestamp if timestamp is not None else int(time.time())
    svix_timestamp = str(ts)

    signed_content = svix_id.encode() + b"." + svix_timestamp.encode() + b"." + body_bytes
    key = _decode_secret(secret)
    mac = hmac.new(key, signed_content, hashlib.sha256).digest()
    sig_b64 = base64.b64encode(mac).decode()

    return {
        "svix-id": svix_id,
        "svix-timestamp": svix_timestamp,
        "svix-signature": f"v1,{sig_b64}",
    }


# ---------------------------------------------------------------------------
# Canned payloads
# ---------------------------------------------------------------------------

_INBOUND_MSG_ID = "<original@example.com>"
_INBOUND_REFS = "<root@example.com>"

_WEBHOOK_BODY: dict[str, Any] = {
    "type": "email.received",
    "data": {
        "email_id": EMAIL_ID,
        "from": ALLOWED_SENDER,
        "subject": "Hello Zeno",
    },
}

_RETRIEVED_EMAIL: dict[str, Any] = {
    "text": "Hello from Alice",
    "message_id": _INBOUND_MSG_ID,
    "subject": "Hello Zeno",
    "headers": {
        "Message-ID": _INBOUND_MSG_ID,
        "References": _INBOUND_REFS,
    },
}


# ---------------------------------------------------------------------------
# Channel factory
# ---------------------------------------------------------------------------


def _make_channel(
    *,
    transport: httpx.MockTransport,
    allowed: tuple[str, ...] = (ALLOWED_SENDER,),
    thread_state_cap: int = 10_000,
) -> EmailChannel:
    return EmailChannel(
        api_key="test-api-key",
        signing_secret=SECRET,
        from_address=FROM_ADDRESS,
        allowed_senders=allowed,
        host="127.0.0.1",
        port=0,
        webhook_path="/webhook",
        thread_state_cap=thread_state_cap,
        _transport=transport,
        _base_url="https://api.resend.com",
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_email_channel_satisfies_protocol() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(200))
    ch = _make_channel(transport=transport)
    assert isinstance(ch, Channel)


def test_capabilities_threading_true_images_false() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(200))
    ch = _make_channel(transport=transport)
    caps = ch.capabilities
    assert caps.supports_threading is True
    assert caps.supports_images is False


async def test_start_stop_idempotent() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(200))
    ch = _make_channel(transport=transport)
    await ch.start()
    await ch.start()  # no-op second call
    await ch.stop()
    await ch.stop()  # no-op second call


async def test_end_to_end_webhook_to_send() -> None:
    """Full round-trip: signed webhook → receive() → send() → check reply headers."""
    captured_send: dict[str, Any] = {}

    def handle(request: httpx.Request) -> httpx.Response:
        if request.method == "GET" and "/emails/received/" in str(request.url):
            return httpx.Response(200, json=_RETRIEVED_EMAIL)
        if request.method == "POST" and str(request.url).endswith("/emails"):
            captured_send["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "sent_001"})
        return httpx.Response(404)

    transport = httpx.MockTransport(handle)
    ch = _make_channel(transport=transport)
    await ch.start()
    try:
        port = ch.bound_port
        body_bytes = json.dumps(_WEBHOOK_BODY).encode()
        sig_headers = make_signed_headers(body_bytes, secret=SECRET)

        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"http://127.0.0.1:{port}/webhook",
                content=body_bytes,
                headers={**sig_headers, "content-type": "application/json"},
            )
        assert resp.status_code == 200

        # Collect one IncomingMessage from receive().
        async def _first() -> Any:
            async for msg in ch.receive():
                return msg
            return None

        msg = await asyncio.wait_for(_first(), timeout=3.0)
        assert msg is not None
        assert msg.user_id == ALLOWED_SENDER
        assert msg.thread_key == ALLOWED_SENDER
        assert msg.text == "Hello from Alice"

        # Send a reply — should produce In-Reply-To + References.
        await ch.send(OutgoingMessage(text="hello", reply_to_thread_key=msg.user_id))

        assert "body" in captured_send, "POST /emails was not called"
        sent_headers: dict[str, str] = captured_send["body"].get("headers", {})
        assert sent_headers.get("In-Reply-To") == _INBOUND_MSG_ID
        refs = sent_headers.get("References", "")
        assert _INBOUND_REFS in refs
        assert _INBOUND_MSG_ID in refs
    finally:
        await ch.stop()


async def test_send_before_start_raises_channel_error() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(200))
    ch = _make_channel(transport=transport)
    with pytest.raises(ChannelError):
        await ch.send(OutgoingMessage(text="hi", reply_to_thread_key=ALLOWED_SENDER))


async def test_send_after_stop_raises_channel_error() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(200))
    ch = _make_channel(transport=transport)
    await ch.start()
    await ch.stop()
    with pytest.raises(ChannelError):
        await ch.send(OutgoingMessage(text="hi", reply_to_thread_key=ALLOWED_SENDER))


async def test_send_without_reply_to_thread_key_raises_channel_error() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(200))
    ch = _make_channel(transport=transport)
    await ch.start()
    try:
        with pytest.raises(ChannelError):
            await ch.send(OutgoingMessage(text="hi"))
    finally:
        await ch.stop()


async def test_send_with_unknown_thread_key_sends_fresh_message_id_no_in_reply_to() -> None:
    """Cache miss → only Message-ID header, no In-Reply-To or References."""
    captured: dict[str, Any] = {}

    def handle(request: httpx.Request) -> httpx.Response:
        if request.method == "POST":
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "sent_002"})
        return httpx.Response(404)

    transport = httpx.MockTransport(handle)
    ch = _make_channel(transport=transport)
    await ch.start()
    try:
        await ch.send(
            OutgoingMessage(text="fresh start", reply_to_thread_key="unknown@example.com")
        )
        sent_headers: dict[str, str] = captured["body"].get("headers", {})
        assert "Message-ID" in sent_headers
        assert "In-Reply-To" not in sent_headers
        assert "References" not in sent_headers
    finally:
        await ch.stop()


async def test_sequential_inbounds_from_same_sender_overwrite_state() -> None:
    """Second inbound from same sender replaces the cached thread state."""
    second_msg_id = "<second@example.com>"
    call_count = 0

    def handle(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        if request.method == "GET" and "/emails/received/" in str(request.url):
            call_count += 1
            if call_count == 1:
                return httpx.Response(
                    200,
                    json={
                        "text": "first message",
                        "message_id": "<first@example.com>",
                        "subject": "Thread",
                        "headers": {},
                    },
                )
            return httpx.Response(
                200,
                json={
                    "text": "second message",
                    "message_id": second_msg_id,
                    "subject": "Thread",
                    "headers": {"references": "<first@example.com>"},
                },
            )
        if request.method == "POST" and str(request.url).endswith("/emails"):
            return httpx.Response(200, json={"id": "sent_003"})
        return httpx.Response(404)

    transport = httpx.MockTransport(handle)
    ch = _make_channel(transport=transport)
    await ch.start()
    try:
        port = ch.bound_port

        async def _send_webhook() -> None:
            body_bytes = json.dumps(_WEBHOOK_BODY).encode()
            sig_headers = make_signed_headers(body_bytes, secret=SECRET)
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"http://127.0.0.1:{port}/webhook",
                    content=body_bytes,
                    headers={**sig_headers, "content-type": "application/json"},
                )

        # Two inbound webhooks from the same sender.
        await _send_webhook()
        await _send_webhook()

        # Drain both messages from the queue.
        async def _drain(n: int) -> list[Any]:
            results = []
            async for msg in ch.receive():
                results.append(msg)
                if len(results) >= n:
                    break
            return results

        await asyncio.wait_for(_drain(2), timeout=3.0)

        # The cached state should reflect the second inbound.
        state = ch._thread_state.get(ALLOWED_SENDER)
        assert state is not None
        assert state.last_message_id == second_msg_id
    finally:
        await ch.stop()


def test_repr_does_not_contain_api_key_or_signing_secret() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(200))
    ch = EmailChannel(
        api_key="NEVER_LEAK_ME_abc123",
        signing_secret="ALSO_SECRET_xyz789",
        from_address=FROM_ADDRESS,
        allowed_senders=(ALLOWED_SENDER,),
        _transport=transport,
    )
    r = repr(ch)
    assert "NEVER_LEAK_ME_abc123" not in r
    assert "ALSO_SECRET_xyz789" not in r


def test_thread_state_cap_evicts_lru() -> None:
    """With cap=3, inserting a 4th key evicts the oldest."""
    transport = httpx.MockTransport(lambda r: httpx.Response(200))
    ch = _make_channel(transport=transport, thread_state_cap=3)

    def _state(mid: str) -> EmailThreadState:
        return EmailThreadState(last_message_id=mid, references=(), subject=None)

    ch._record_thread_state("a@e.com", _state("<a>"))
    ch._record_thread_state("b@e.com", _state("<b>"))
    ch._record_thread_state("c@e.com", _state("<c>"))
    ch._record_thread_state("d@e.com", _state("<d>"))  # evicts a@e.com

    assert len(ch._thread_state) == 3
    assert "a@e.com" not in ch._thread_state
    assert "b@e.com" in ch._thread_state
    assert "c@e.com" in ch._thread_state
    assert "d@e.com" in ch._thread_state


def test_repeated_inbound_same_sender_no_accumulation() -> None:
    """Overwriting the same key multiple times keeps cache size at 1."""
    transport = httpx.MockTransport(lambda r: httpx.Response(200))
    ch = _make_channel(transport=transport, thread_state_cap=10)

    def _state(mid: str) -> EmailThreadState:
        return EmailThreadState(last_message_id=mid, references=(), subject=None)

    ch._record_thread_state("alice@e.com", _state("<1>"))
    ch._record_thread_state("alice@e.com", _state("<2>"))
    ch._record_thread_state("alice@e.com", _state("<3>"))

    assert len(ch._thread_state) == 1
    assert ch._thread_state["alice@e.com"].last_message_id == "<3>"
