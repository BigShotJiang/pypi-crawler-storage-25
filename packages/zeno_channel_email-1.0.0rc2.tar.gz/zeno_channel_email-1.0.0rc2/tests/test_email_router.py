"""Tests for the Starlette router that backs EmailChannel's Resend webhook."""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import logging
import uuid
from typing import Any

import httpx
import pytest
from starlette.testclient import TestClient
from zeno.channels.email.resend_client import ResendClient
from zeno.channels.email.router import build_router
from zeno.channels.email.state import EmailThreadState
from zeno.channels.messages import IncomingMessage

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SECRET = "whsec_dGVzdHNlY3JldGZvcnRlc3Rpbmcx"  # base64("testsecretfortesting1")
ALLOWED_SENDER = "alice@example.com"
EMAIL_ID = "em_abc123"

# Fixed timestamp used in all deterministic tests.
FIXED_TS = 1_700_000_000
FIXED_NOW: float = float(FIXED_TS)


# ---------------------------------------------------------------------------
# Signing helper (uses the real signing primitives)
# ---------------------------------------------------------------------------


def _decode_secret(secret: str) -> bytes:
    raw = secret.removeprefix("whsec_")
    return base64.b64decode(raw)


def make_signed_headers(
    body_bytes: bytes,
    *,
    secret: str,
    timestamp: int | None = None,
) -> dict[str, str]:
    """Build `svix-id`, `svix-timestamp`, `svix-signature` headers.

    Uses the same HMAC-SHA256 logic as the real Svix implementation so
    we exercise the full verification chain without reimplementing it in
    a different way.
    """
    svix_id = f"msg_{uuid.uuid4().hex}"
    ts = timestamp if timestamp is not None else FIXED_TS
    svix_timestamp = str(ts)

    signed_content = svix_id.encode() + b"." + svix_timestamp.encode() + b"." + body_bytes
    key = _decode_secret(secret)
    mac = hmac.new(key, signed_content, hashlib.sha256).digest()
    sig_b64 = base64.b64encode(mac).decode()

    return {
        "svix-id": svix_id,
        "svix-timestamp": svix_timestamp,
        "svix-signature": f"v1,{sig_b64}",
    }


# ---------------------------------------------------------------------------
# Canned webhook payload + retrieved-email response
# ---------------------------------------------------------------------------


def _webhook_payload(**overrides: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "type": "email.received",
        "data": {
            "email_id": EMAIL_ID,
            "from": ALLOWED_SENDER,
            "subject": "Hello",
        },
    }
    base.update(overrides)
    return base


def _retrieved_email(**overrides: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "text": "Hello from Alice",
        "message_id": "<msg1@example.com>",
        "subject": "Hello",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_client(
    *,
    secret: str = SECRET,
    allowed: list[str] | None = None,
    http_handler: Any = None,
    queue_maxsize: int = 16,
    enqueue_timeout: float = 1.0,
) -> tuple[
    TestClient, asyncio.Queue[IncomingMessage], dict[str, EmailThreadState], list[httpx.Request]
]:
    """Build a fully wired TestClient + queue + state dict + request recorder."""
    queue: asyncio.Queue[IncomingMessage] = asyncio.Queue(maxsize=queue_maxsize)
    state: dict[str, EmailThreadState] = {}
    seen_requests: list[httpx.Request] = []

    def default_handler(request: httpx.Request) -> httpx.Response:
        seen_requests.append(request)
        return httpx.Response(200, json=_retrieved_email())

    handler = http_handler if http_handler is not None else default_handler

    http = httpx.AsyncClient(
        transport=httpx.MockTransport(handler),
        base_url="https://api.resend.com",
    )
    resend = ResendClient(http=http, api_key="test-key")
    senders = allowed if allowed is not None else [ALLOWED_SENDER]
    router = build_router(
        queue=queue,
        thread_state=state,
        client=resend,
        signing_secret=secret,
        allowed_senders=senders,
        webhook_path="/webhook",
        enqueue_timeout=enqueue_timeout,
        now=lambda: FIXED_NOW,
    )
    return TestClient(router), queue, state, seen_requests


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_happy_path_valid_signed_allowlisted_event_fetched_enqueued() -> None:
    client, queue, state, seen = _make_client()
    body_bytes = json.dumps(_webhook_payload()).encode()
    headers = make_signed_headers(body_bytes, secret=SECRET, timestamp=FIXED_TS)
    r = client.post("/webhook", content=body_bytes, headers=headers)
    assert r.status_code == 200
    assert queue.qsize() == 1
    assert len(state) == 1
    msg = queue.get_nowait()
    assert msg.user_id == ALLOWED_SENDER
    # fetch_received was called once
    assert len([req for req in seen if "received" in str(req.url)]) == 1


def test_bad_signature_returns_401_no_fetch_no_enqueue() -> None:
    client, queue, state, seen = _make_client()
    body_bytes = json.dumps(_webhook_payload()).encode()
    # Use wrong secret for signing
    bad_secret = "whsec_YmFkc2VjcmV0YmFkc2VjcmV0YmFkMDE="
    headers = make_signed_headers(body_bytes, secret=bad_secret, timestamp=FIXED_TS)
    r = client.post("/webhook", content=body_bytes, headers=headers)
    assert r.status_code == 401
    assert queue.empty()
    assert len(state) == 0
    assert len(seen) == 0


def test_missing_svix_headers_returns_401() -> None:
    client, queue, state, seen = _make_client()
    body_bytes = json.dumps(_webhook_payload()).encode()
    # No svix-* headers at all
    r = client.post("/webhook", content=body_bytes)
    assert r.status_code == 401
    assert queue.empty()
    assert len(seen) == 0


def test_stale_but_valid_timestamp_returns_200_no_fetch() -> None:
    # Use a timestamp that is 400 seconds old (outside 300s default window).
    stale_ts = FIXED_TS - 400
    client, queue, state, seen = _make_client()
    body_bytes = json.dumps(_webhook_payload()).encode()
    headers = make_signed_headers(body_bytes, secret=SECRET, timestamp=stale_ts)
    r = client.post("/webhook", content=body_bytes, headers=headers)
    assert r.status_code == 200
    assert queue.empty()
    assert len(state) == 0
    assert len(seen) == 0


def test_malformed_json_body_returns_200_no_fetch() -> None:
    client, queue, state, seen = _make_client()
    body_bytes = b"{not valid json"
    headers = make_signed_headers(body_bytes, secret=SECRET, timestamp=FIXED_TS)
    r = client.post("/webhook", content=body_bytes, headers=headers)
    assert r.status_code == 200
    assert queue.empty()
    assert len(seen) == 0


def test_non_received_event_type_returns_200_no_fetch() -> None:
    client, queue, state, seen = _make_client()
    payload = _webhook_payload()
    payload["type"] = "email.delivered"
    body_bytes = json.dumps(payload).encode()
    headers = make_signed_headers(body_bytes, secret=SECRET, timestamp=FIXED_TS)
    r = client.post("/webhook", content=body_bytes, headers=headers)
    assert r.status_code == 200
    assert queue.empty()
    assert len(state) == 0
    assert len(seen) == 0


def test_sender_not_in_allowlist_returns_200_no_fetch() -> None:
    client, queue, state, seen = _make_client()
    payload = _webhook_payload()
    payload["data"]["from"] = "stranger@evil.com"
    body_bytes = json.dumps(payload).encode()
    headers = make_signed_headers(body_bytes, secret=SECRET, timestamp=FIXED_TS)
    r = client.post("/webhook", content=body_bytes, headers=headers)
    assert r.status_code == 200
    assert queue.empty()
    assert len(state) == 0
    assert len(seen) == 0


def test_allowlist_case_normalization() -> None:
    # Channel constructed with mixed-case sender, webhook arrives with different case.
    client, queue, state, seen = _make_client(allowed=["Alice@Example.COM"])
    payload = _webhook_payload()
    payload["data"]["from"] = "ALICE@example.com"
    body_bytes = json.dumps(payload).encode()
    headers = make_signed_headers(body_bytes, secret=SECRET, timestamp=FIXED_TS)
    r = client.post("/webhook", content=body_bytes, headers=headers)
    assert r.status_code == 200
    assert queue.qsize() == 1


def test_fetch_received_backend_error_returns_200() -> None:
    def error_handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(500, text="Internal Server Error")

    client, queue, state, seen = _make_client(http_handler=error_handler)
    body_bytes = json.dumps(_webhook_payload()).encode()
    headers = make_signed_headers(body_bytes, secret=SECRET, timestamp=FIXED_TS)
    r = client.post("/webhook", content=body_bytes, headers=headers)
    assert r.status_code == 200
    assert queue.empty()
    assert len(state) == 0


def test_queue_full_logs_event_queue_full_returns_200(caplog: pytest.LogCaptureFixture) -> None:
    # maxsize=0 means unlimited in Python asyncio — use maxsize=1 and pre-fill it.
    queue: asyncio.Queue[IncomingMessage] = asyncio.Queue(maxsize=1)
    state: dict[str, EmailThreadState] = {}
    seen: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        return httpx.Response(200, json=_retrieved_email())

    http = httpx.AsyncClient(
        transport=httpx.MockTransport(handler),
        base_url="https://api.resend.com",
    )
    resend = ResendClient(http=http, api_key="test-key")
    router = build_router(
        queue=queue,
        thread_state=state,
        client=resend,
        signing_secret=SECRET,
        allowed_senders=[ALLOWED_SENDER],
        webhook_path="/webhook",
        enqueue_timeout=0.05,
        now=lambda: FIXED_NOW,
    )
    tc = TestClient(router)

    # Fill the queue first.
    body_bytes = json.dumps(_webhook_payload()).encode()
    headers1 = make_signed_headers(body_bytes, secret=SECRET, timestamp=FIXED_TS)
    r1 = tc.post("/webhook", content=body_bytes, headers=headers1)
    assert r1.status_code == 200
    assert queue.qsize() == 1

    # Second request should hit the full queue.
    with caplog.at_level(logging.WARNING, logger="zeno.channels.email.router"):
        headers2 = make_signed_headers(body_bytes, secret=SECRET, timestamp=FIXED_TS)
        r2 = tc.post("/webhook", content=body_bytes, headers=headers2)
    assert r2.status_code == 200
    assert any("event=queue_full" in rec.message for rec in caplog.records)


def test_thread_state_registered_before_enqueue() -> None:
    """State must be populated in thread_state before queue.put is called."""
    state: dict[str, EmailThreadState] = {}
    observed_state_at_put: dict[str, EmailThreadState] = {}

    class ObservingQueue(asyncio.Queue[IncomingMessage]):
        async def put(self, item: IncomingMessage) -> None:
            # Snapshot thread_state at the moment put is called.
            observed_state_at_put.update(state)
            await super().put(item)

    queue: ObservingQueue = ObservingQueue(maxsize=16)
    seen: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        return httpx.Response(200, json=_retrieved_email())

    http = httpx.AsyncClient(
        transport=httpx.MockTransport(handler),
        base_url="https://api.resend.com",
    )
    resend = ResendClient(http=http, api_key="test-key")
    router = build_router(
        queue=queue,
        thread_state=state,
        client=resend,
        signing_secret=SECRET,
        allowed_senders=[ALLOWED_SENDER],
        webhook_path="/webhook",
        now=lambda: FIXED_NOW,
    )
    tc = TestClient(router)

    body_bytes = json.dumps(_webhook_payload()).encode()
    headers = make_signed_headers(body_bytes, secret=SECRET, timestamp=FIXED_TS)
    r = tc.post("/webhook", content=body_bytes, headers=headers)
    assert r.status_code == 200
    # thread_state was already populated when put was called
    assert len(observed_state_at_put) == 1
    assert ALLOWED_SENDER in observed_state_at_put


def test_warning_logs_never_contain_raw_body_or_signature_header(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Rejection log lines must not contain the raw body bytes or svix-signature value."""
    client, queue, state, _ = _make_client()

    # Build a body with identifiable content
    body_payload = _webhook_payload()
    body_payload["data"]["from"] = "stranger@attacker.com"  # will be rejected at allowlist
    body_bytes = json.dumps(body_payload).encode()

    _bad_secret = "whsec_YmFkc2VjcmV0YmFkc2VjcmV0YmFkMDE="
    bad_sig_headers = make_signed_headers(
        body_bytes,
        secret=_bad_secret,
        timestamp=FIXED_TS,
    )
    sig_value = bad_sig_headers["svix-signature"]

    with caplog.at_level(logging.WARNING, logger="zeno.channels.email.router"):
        # Bad signature path
        client.post("/webhook", content=body_bytes, headers=bad_sig_headers)

        # Allowlist reject path (valid sig, rejected sender)
        valid_headers = make_signed_headers(body_bytes, secret=SECRET, timestamp=FIXED_TS)
        client.post("/webhook", content=body_bytes, headers=valid_headers)

        # Malformed JSON path
        junk = b"definitelynotjson{{"
        junk_headers = make_signed_headers(junk, secret=SECRET, timestamp=FIXED_TS)
        client.post("/webhook", content=junk, headers=junk_headers)

    raw_body_str = body_bytes.decode(errors="replace")
    for rec in caplog.records:
        assert raw_body_str not in rec.message, f"raw body leaked in log: {rec.message!r}"
        assert sig_value not in rec.message, f"svix-signature leaked in log: {rec.message!r}"
