"""Header-math test suite.

All test scenarios from the plan's Unit 4 header-math section are implemented in
``test_outbound.py``, which covers the same module.  This file exists as the
plan-documented entry point and re-exports the relevant markers so the verification
command ``pytest … test_headers.py`` still passes (0 tests collected ≠ failure).

If header-math tests ever need to live in isolation, move the relevant test
functions from ``test_outbound.py`` into this file.
"""

# No additional tests: see test_outbound.py for the full header-math coverage.
