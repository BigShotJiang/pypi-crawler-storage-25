"""Tests for zeno.channels.email.parsing — two-phase inbound parsing."""

from __future__ import annotations

from typing import Any

from zeno.channels.email.parsing import RejectionReason, parse_content, parse_webhook_metadata
from zeno.channels.email.state import WebhookMetadata

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _valid_webhook(
    *,
    from_addr: str = '"Alice" <alice@example.com>',
    email_id: str = "em_abc",
    subject: str | None = "hi",
    event_type: str = "email.received",
) -> dict[str, Any]:
    data: dict[str, Any] = {"email_id": email_id, "from": from_addr}
    if subject is not None:
        data["subject"] = subject
    return {"type": event_type, "data": data}


def _valid_retrieved(
    *,
    text: str | None = "Hello world",
    html: str | None = None,
    message_id: str = "<msg123@mail.example.com>",
    subject: str | None = "hi",
    references: str | None = None,
    in_reply_to: str | None = None,
    top_level_references: str | None = None,
    top_level_in_reply_to: str | None = None,
    include_attachments: bool = False,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "message_id": message_id,
        "subject": subject,
    }
    if text is not None:
        payload["text"] = text
    if html is not None:
        payload["html"] = html

    headers: dict[str, str] = {}
    if references is not None:
        headers["References"] = references
    if in_reply_to is not None:
        headers["In-Reply-To"] = in_reply_to
    if headers:
        payload["headers"] = headers

    if top_level_references is not None:
        payload["references"] = top_level_references
    if top_level_in_reply_to is not None:
        payload["in_reply_to"] = top_level_in_reply_to

    if include_attachments:
        payload["attachments"] = [{"filename": "photo.jpg", "content": "base64data=="}]

    return payload


def _meta() -> WebhookMetadata:
    return WebhookMetadata(from_addr="alice@example.com", email_id="em_abc", subject="hi")


# ===========================================================================
# parse_webhook_metadata
# ===========================================================================


class TestParseWebhookMetadataHappy:
    def test_valid_payload_returns_webhook_metadata(self) -> None:
        payload = _valid_webhook(from_addr="alice@example.com", email_id="em_abc", subject="hi")
        result = parse_webhook_metadata(payload)
        assert isinstance(result, WebhookMetadata)
        assert result.from_addr == "alice@example.com"
        assert result.email_id == "em_abc"
        assert result.subject == "hi"

    def test_display_name_with_angle_brackets_extracts_addr(self) -> None:
        """``"Alice" <alice@example.com>`` → only ``alice@example.com``."""
        payload = _valid_webhook(from_addr='"Alice" <alice@example.com>')
        result = parse_webhook_metadata(payload)
        assert isinstance(result, WebhookMetadata)
        assert result.from_addr == "alice@example.com"

    def test_uppercase_address_normalised_to_lowercase(self) -> None:
        payload = _valid_webhook(from_addr="ALICE@EXAMPLE.COM")
        result = parse_webhook_metadata(payload)
        assert isinstance(result, WebhookMetadata)
        assert result.from_addr == "alice@example.com"

    def test_subject_is_optional(self) -> None:
        payload: dict[str, Any] = {
            "type": "email.received",
            "data": {"email_id": "em_1", "from": "a@b.com"},
        }
        result = parse_webhook_metadata(payload)
        assert isinstance(result, WebhookMetadata)
        assert result.subject is None

    def test_subject_none_in_helper(self) -> None:
        payload = _valid_webhook(subject=None)
        result = parse_webhook_metadata(payload)
        assert isinstance(result, WebhookMetadata)
        assert result.subject is None


class TestParseWebhookMetadataSecurity:
    def test_display_name_injection_returns_bracketed_addr(self) -> None:
        """``"alice@evil.com" <alice@good.com>`` must return ``alice@good.com``."""
        payload = _valid_webhook(from_addr='"alice@evil.com" <alice@good.com>')
        result = parse_webhook_metadata(payload)
        assert isinstance(result, WebhookMetadata)
        assert result.from_addr == "alice@good.com"
        assert "evil" not in result.from_addr


class TestParseWebhookMetadataRejections:
    def test_wrong_event_type(self) -> None:
        payload = _valid_webhook(event_type="email.delivered")
        assert parse_webhook_metadata(payload) == RejectionReason.WRONG_EVENT_TYPE

    def test_missing_email_id(self) -> None:
        payload: dict[str, Any] = {"type": "email.received", "data": {"from": "a@b.com"}}
        assert parse_webhook_metadata(payload) == RejectionReason.MISSING_EMAIL_ID

    def test_empty_email_id(self) -> None:
        payload: dict[str, Any] = {
            "type": "email.received",
            "data": {"email_id": "", "from": "a@b.com"},
        }
        assert parse_webhook_metadata(payload) == RejectionReason.MISSING_EMAIL_ID

    def test_missing_from(self) -> None:
        payload: dict[str, Any] = {"type": "email.received", "data": {"email_id": "em_1"}}
        assert parse_webhook_metadata(payload) == RejectionReason.MISSING_FROM

    def test_from_parses_to_empty_string(self) -> None:
        """A From value that ``parseaddr`` returns as empty address → MISSING_FROM."""
        payload = _valid_webhook(from_addr="Not An Email At All <<<")
        result = parse_webhook_metadata(payload)
        assert result == RejectionReason.MISSING_FROM

    def test_payload_not_dict_returns_invalid_payload(self) -> None:
        assert parse_webhook_metadata("not a dict") == RejectionReason.INVALID_PAYLOAD  # type: ignore[arg-type]

    def test_payload_none_returns_invalid_payload(self) -> None:
        assert parse_webhook_metadata(None) == RejectionReason.INVALID_PAYLOAD  # type: ignore[arg-type]

    def test_payload_list_returns_invalid_payload(self) -> None:
        assert parse_webhook_metadata([]) == RejectionReason.INVALID_PAYLOAD  # type: ignore[arg-type]

    def test_missing_data_key_returns_invalid_payload(self) -> None:
        assert parse_webhook_metadata({"type": "email.received"}) == RejectionReason.INVALID_PAYLOAD

    def test_data_not_dict_returns_invalid_payload(self) -> None:
        payload: dict[str, Any] = {"type": "email.received", "data": "wrong"}
        assert parse_webhook_metadata(payload) == RejectionReason.INVALID_PAYLOAD


# ===========================================================================
# parse_content
# ===========================================================================


class TestParseContentHappy:
    def test_text_body_returned_verbatim(self) -> None:
        meta = _meta()
        retrieved = _valid_retrieved(text="Hello from Alice")
        result = parse_content(meta, retrieved)
        assert not isinstance(result, RejectionReason)
        incoming, _state = result
        assert incoming.text == "Hello from Alice"

    def test_html_only_tags_stripped(self) -> None:
        meta = _meta()
        retrieved = _valid_retrieved(
            text=None,
            html="<p>Hello <b>world</b></p>",
        )
        result = parse_content(meta, retrieved)
        assert not isinstance(result, RejectionReason)
        incoming, _state = result
        assert "Hello" in incoming.text
        assert "world" in incoming.text
        assert "<" not in incoming.text

    def test_html_whitespace_collapsed(self) -> None:
        meta = _meta()
        retrieved = _valid_retrieved(
            text=None,
            html="<p>  Lots   of  \n  whitespace  </p>",
        )
        result = parse_content(meta, retrieved)
        assert not isinstance(result, RejectionReason)
        incoming, _state = result
        assert "  " not in incoming.text  # no double spaces

    def test_user_id_and_thread_key_from_from_addr(self) -> None:
        meta = _meta()
        retrieved = _valid_retrieved()
        result = parse_content(meta, retrieved)
        assert not isinstance(result, RejectionReason)
        incoming, _state = result
        assert incoming.user_id == "alice@example.com"
        assert incoming.thread_key == "alice@example.com"

    def test_incoming_message_metadata_shape(self) -> None:
        meta = _meta()
        retrieved = _valid_retrieved(
            message_id="<msg123@mail.example.com>",
            references="<a@x> <b@x>",
        )
        result = parse_content(meta, retrieved)
        assert not isinstance(result, RejectionReason)
        incoming, _state = result
        email_meta = incoming.metadata["email"]
        assert email_meta["email_id"] == "em_abc"
        assert email_meta["message_id"] == "<msg123@mail.example.com>"
        assert email_meta["references"] == ["<a@x>", "<b@x>"]

    def test_received_at_is_set(self) -> None:
        from datetime import UTC

        meta = _meta()
        retrieved = _valid_retrieved()
        result = parse_content(meta, retrieved)
        assert not isinstance(result, RejectionReason)
        incoming, _ = result
        assert incoming.received_at.tzinfo == UTC

    def test_attachments_ignored(self) -> None:
        """Attachments in retrieved payload must NOT appear on IncomingMessage."""
        meta = _meta()
        retrieved = _valid_retrieved(include_attachments=True)
        result = parse_content(meta, retrieved)
        assert not isinstance(result, RejectionReason)
        incoming, _state = result
        assert incoming.attachments == []


class TestParseContentThreadState:
    def test_references_header_parsed(self) -> None:
        meta = _meta()
        retrieved = _valid_retrieved(references="<a@x> <b@x>")
        result = parse_content(meta, retrieved)
        assert not isinstance(result, RejectionReason)
        _incoming, state = result
        assert state.references == ("<a@x>", "<b@x>")

    def test_in_reply_to_only_becomes_single_reference(self) -> None:
        meta = _meta()
        retrieved = _valid_retrieved(in_reply_to="<root@x>")
        result = parse_content(meta, retrieved)
        assert not isinstance(result, RejectionReason)
        _incoming, state = result
        assert state.references == ("<root@x>",)

    def test_new_thread_empty_references(self) -> None:
        meta = _meta()
        retrieved = _valid_retrieved()  # no references or in_reply_to
        result = parse_content(meta, retrieved)
        assert not isinstance(result, RejectionReason)
        _incoming, state = result
        assert state.references == ()

    def test_references_under_headers_dict(self) -> None:
        """References nested under ``retrieved["headers"]`` must resolve."""
        meta = _meta()
        retrieved = _valid_retrieved(references="<a@x> <b@x>")
        result = parse_content(meta, retrieved)
        assert not isinstance(result, RejectionReason)
        _incoming, state = result
        assert state.references == ("<a@x>", "<b@x>")

    def test_references_at_top_level_fallback(self) -> None:
        """References at ``retrieved["references"]`` (top-level) must resolve."""
        meta = _meta()
        retrieved = _valid_retrieved(top_level_references="<c@x> <d@x>")
        result = parse_content(meta, retrieved)
        assert not isinstance(result, RejectionReason)
        _incoming, state = result
        assert state.references == ("<c@x>", "<d@x>")

    def test_in_reply_to_top_level_fallback(self) -> None:
        """In-Reply-To at top level ``retrieved["in_reply_to"]`` must resolve."""
        meta = _meta()
        retrieved = _valid_retrieved(top_level_in_reply_to="<root2@x>")
        result = parse_content(meta, retrieved)
        assert not isinstance(result, RejectionReason)
        _incoming, state = result
        assert state.references == ("<root2@x>",)

    def test_headers_references_takes_precedence_over_top_level(self) -> None:
        """``headers["References"]`` wins over top-level ``references`` key."""
        meta = _meta()
        retrieved = _valid_retrieved(
            references="<header@x>",
            top_level_references="<toplevel@x>",
        )
        result = parse_content(meta, retrieved)
        assert not isinstance(result, RejectionReason)
        _incoming, state = result
        assert state.references == ("<header@x>",)

    def test_last_message_id_stored(self) -> None:
        meta = _meta()
        retrieved = _valid_retrieved(message_id="<unique-msg@example.com>")
        result = parse_content(meta, retrieved)
        assert not isinstance(result, RejectionReason)
        _incoming, state = result
        assert state.last_message_id == "<unique-msg@example.com>"

    def test_200_references_all_stored(self) -> None:
        """Parser stores all 200 entries; outbound cap happens in Unit 4."""
        meta = _meta()
        refs = " ".join(f"<msg{i}@x>" for i in range(200))
        retrieved = _valid_retrieved(references=refs)
        result = parse_content(meta, retrieved)
        assert not isinstance(result, RejectionReason)
        _incoming, state = result
        assert len(state.references) == 200


class TestParseContentRejections:
    def test_empty_text_and_empty_html_returns_empty(self) -> None:
        meta = _meta()
        retrieved = _valid_retrieved(text="", html="")
        assert parse_content(meta, retrieved) == RejectionReason.EMPTY

    def test_none_text_and_none_html_returns_empty(self) -> None:
        meta = _meta()
        retrieved: dict[str, Any] = {"message_id": "<x>"}
        assert parse_content(meta, retrieved) == RejectionReason.EMPTY

    def test_html_with_only_tags_returns_empty(self) -> None:
        """HTML that strips to whitespace only is treated as empty."""
        meta = _meta()
        retrieved = _valid_retrieved(text=None, html="<p>   </p><br/>")
        assert parse_content(meta, retrieved) == RejectionReason.EMPTY
