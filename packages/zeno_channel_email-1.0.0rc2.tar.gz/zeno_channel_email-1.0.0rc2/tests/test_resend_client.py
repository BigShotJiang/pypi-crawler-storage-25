"""Tests for ResendClient — send + fetch_received, using httpx.MockTransport."""

from __future__ import annotations

import base64
import json
from typing import Any

import httpx
import pytest
from zeno.channels.email.outbound import EmailBackendError, EmailEnvelope, EmailOutbound
from zeno.channels.email.resend_client import ResendClient
from zeno.channels.messages import Attachment

# ---------------------------------------------------------------------------
# MockTransport helpers
# ---------------------------------------------------------------------------


def _make_transport(
    status: int,
    body: dict[str, Any] | str,
    *,
    capture: list[httpx.Request] | None = None,
) -> httpx.MockTransport:
    """Return a MockTransport that replies with *status* and *body* for every request."""
    if isinstance(body, dict):
        raw = json.dumps(body).encode()
        ct = "application/json"
    else:
        raw = body.encode()
        ct = "text/plain"

    def handler(request: httpx.Request) -> httpx.Response:
        if capture is not None:
            capture.append(request)
        return httpx.Response(status, content=raw, headers={"content-type": ct})

    return httpx.MockTransport(handler)


def _make_client(
    status: int = 200,
    body: dict[str, Any] | str = "",
    *,
    capture: list[httpx.Request] | None = None,
) -> ResendClient:
    transport = _make_transport(status, body, capture=capture)
    http = httpx.AsyncClient(transport=transport)
    return ResendClient(http=http, api_key="re_secret_key")


def _basic_envelope(**kwargs: Any) -> EmailEnvelope:
    defaults: dict[str, Any] = dict(
        to="to@example.com",
        from_address="from@example.com",
        subject="Hello",
        text="plain text",
        html="<b>html</b>",
    )
    defaults.update(kwargs)
    return EmailEnvelope(**defaults)


# ---------------------------------------------------------------------------
# Protocol
# ---------------------------------------------------------------------------


def test_isinstance_email_outbound() -> None:
    client = _make_client()
    assert isinstance(client, EmailOutbound)


# ---------------------------------------------------------------------------
# send() — happy path
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_send_posts_to_correct_url() -> None:
    captured: list[httpx.Request] = []
    client = _make_client(200, {"id": "abc"}, capture=captured)
    await client.send(_basic_envelope())

    assert len(captured) == 1
    assert captured[0].method == "POST"
    assert str(captured[0].url) == "https://api.resend.com/emails"


@pytest.mark.asyncio
async def test_send_json_body_shape() -> None:
    captured: list[httpx.Request] = []
    client = _make_client(200, {"id": "abc"}, capture=captured)
    envelope = _basic_envelope()
    await client.send(envelope)

    payload = json.loads(captured[0].content)
    assert payload["from"] == envelope.from_address
    assert payload["to"] == [envelope.to]
    assert payload["subject"] == envelope.subject
    assert payload["text"] == envelope.text
    assert payload["html"] == envelope.html
    assert payload["headers"] == {}


@pytest.mark.asyncio
async def test_send_authorization_header() -> None:
    captured: list[httpx.Request] = []
    client = _make_client(200, {"id": "abc"}, capture=captured)
    await client.send(_basic_envelope())

    assert captured[0].headers["Authorization"] == "Bearer re_secret_key"


@pytest.mark.asyncio
async def test_send_returns_none_on_200() -> None:
    client = _make_client(200, {"id": "abc"})
    await client.send(_basic_envelope())


# ---------------------------------------------------------------------------
# send() — error paths
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_send_422_raises_email_backend_error() -> None:
    client = _make_client(422, {"message": "validation error"})
    with pytest.raises(EmailBackendError) as exc_info:
        await client.send(_basic_envelope())
    assert "422" in str(exc_info.value)
    assert "POST /emails" in str(exc_info.value)


@pytest.mark.asyncio
async def test_send_500_raises_email_backend_error() -> None:
    client = _make_client(500, "internal server error")
    with pytest.raises(EmailBackendError):
        await client.send(_basic_envelope())


@pytest.mark.asyncio
async def test_send_transport_error_raises_email_backend_error() -> None:
    def failing_handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("connection refused")

    http = httpx.AsyncClient(transport=httpx.MockTransport(failing_handler))
    client = ResendClient(http=http, api_key="re_test")
    with pytest.raises(EmailBackendError) as exc_info:
        await client.send(_basic_envelope())
    assert "transport" in str(exc_info.value).lower()
    assert exc_info.value.__cause__ is not None


# ---------------------------------------------------------------------------
# send() — attachments
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_send_attachment_with_url_becomes_path() -> None:
    captured: list[httpx.Request] = []
    client = _make_client(200, {"id": "abc"}, capture=captured)
    att = Attachment(kind="file", url="https://example.com/file.pdf", filename="file.pdf")
    envelope = _basic_envelope(attachments=(att,))
    await client.send(envelope)

    payload = json.loads(captured[0].content)
    assert payload["attachments"][0]["path"] == "https://example.com/file.pdf"
    assert payload["attachments"][0]["filename"] == "file.pdf"


@pytest.mark.asyncio
async def test_send_attachment_with_data_becomes_base64_content() -> None:
    captured: list[httpx.Request] = []
    client = _make_client(200, {"id": "abc"}, capture=captured)
    raw_data = b"binary data here"
    att = Attachment(kind="file", data=raw_data, filename="data.bin")
    envelope = _basic_envelope(attachments=(att,))
    await client.send(envelope)

    payload = json.loads(captured[0].content)
    assert payload["attachments"][0]["content"] == base64.b64encode(raw_data).decode()
    assert payload["attachments"][0]["filename"] == "data.bin"


@pytest.mark.asyncio
async def test_send_no_attachments_key_when_empty() -> None:
    captured: list[httpx.Request] = []
    client = _make_client(200, {"id": "abc"}, capture=captured)
    await client.send(_basic_envelope())

    payload = json.loads(captured[0].content)
    assert "attachments" not in payload


# ---------------------------------------------------------------------------
# Security: repr must not leak api_key
# ---------------------------------------------------------------------------


def test_repr_does_not_contain_api_key() -> None:
    client = _make_client()
    assert "re_secret_key" not in repr(client)


# ---------------------------------------------------------------------------
# fetch_received() — happy path
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_fetch_received_returns_json_dict() -> None:
    expected = {"id": "em_abc", "text": "Hello", "subject": "Hi"}
    client = _make_client(200, expected)
    result = await client.fetch_received("em_abc")
    assert result == expected


@pytest.mark.asyncio
async def test_fetch_received_gets_correct_url() -> None:
    captured: list[httpx.Request] = []
    client = _make_client(200, {"id": "em_abc"}, capture=captured)
    await client.fetch_received("em_abc")

    assert len(captured) == 1
    assert captured[0].method == "GET"
    assert "/emails/received/em_abc" in str(captured[0].url)


@pytest.mark.asyncio
async def test_fetch_received_sends_authorization() -> None:
    captured: list[httpx.Request] = []
    client = _make_client(200, {"id": "em_abc"}, capture=captured)
    await client.fetch_received("em_abc")

    assert captured[0].headers["Authorization"] == "Bearer re_secret_key"


# ---------------------------------------------------------------------------
# fetch_received() — error paths
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_fetch_received_404_raises_email_backend_error() -> None:
    client = _make_client(404, {"message": "not found"})
    with pytest.raises(EmailBackendError) as exc_info:
        await client.fetch_received("em_missing")
    assert "404" in str(exc_info.value)


@pytest.mark.asyncio
async def test_fetch_received_transport_error_raises_email_backend_error() -> None:
    def failing_handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("connection refused")

    http = httpx.AsyncClient(transport=httpx.MockTransport(failing_handler))
    client = ResendClient(http=http, api_key="re_test")
    with pytest.raises(EmailBackendError) as exc_info:
        await client.fetch_received("em_abc")
    assert exc_info.value.__cause__ is not None
