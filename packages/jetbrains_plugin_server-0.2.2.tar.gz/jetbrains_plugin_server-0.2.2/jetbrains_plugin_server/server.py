import logging
from typing import Annotated

from apscheduler.schedulers.background import BackgroundScheduler

from jetbrains_plugin_server.config import ASSETS_DIR, FAST_API_OFFLINE
from jetbrains_plugin_server.homepage import get_homepage
from jetbrains_plugin_server.model.catalog import CatalogSchema

if FAST_API_OFFLINE:
    from fastapi_offline import FastAPIOffline as FastAPI
else:
    from fastapi import FastAPI  # type: ignore

from fastapi.responses import HTMLResponse, Response

from jetbrains_plugin_server.api import packages
from jetbrains_plugin_server.model.data_listing import DataListing
from jetbrains_plugin_server.model.errors import add_error_handler
from jetbrains_plugin_server.plugin_catalog import get_plugin_catalog
from jetbrains_plugin_server.plugin_model import get_plugins
from jetbrains_plugin_server.to_xml import to_xml

LOG = logging.getLogger(__name__)


def create_plugin_server(dl: DataListing, download_url_root: str, refresh_every_seconds: int = -1):
    catalog = CatalogSchema(data_listing=dl)
    catalog.build()

    app = FastAPI()
    add_error_handler(app)
    app.include_router(packages.router)

    if isinstance(refresh_every_seconds, int) and refresh_every_seconds > 0:
        refresh_every_seconds = max(60, refresh_every_seconds)
        scheduler = BackgroundScheduler()
        scheduler.add_job(catalog.build, 'interval', seconds=refresh_every_seconds)
        scheduler.start()

    @app.get("/")
    def get_plugins_route(build: Annotated[
        str, "IDE build number to filter the available plugins and return only the compatible ones"] = ""):
        if not build:
            return HTMLResponse(content=get_homepage())

        LOG.debug("Request with build=%s", build)
        result = get_plugins(build)
        return Response(content=to_xml(result, download_url_root), media_type="application/xml")

    @app.get("/cache")
    def get_cache_route():
        return get_plugin_catalog()

    @app.get("/assets/{filename}")
    def get_asset_route(filename):
        return Response(
            content=ASSETS_DIR.joinpath(filename).read_bytes(),
        )

    return app
