import json
import logging

from jetbrains_plugin_server.config import PLUGIN_PROD_DATA, PLUGIN_TEST_DATA, is_test_mode
from jetbrains_plugin_server.model.catalog import CatalogOutputSchema

LOG = logging.getLogger(__name__)


def get_plugin_catalog() -> CatalogOutputSchema:
    LOG.info("load catalog from file")
    if is_test_mode():
        catalog_path = PLUGIN_TEST_DATA
    else:
        catalog_path = PLUGIN_PROD_DATA
    return CatalogOutputSchema.model_validate(json.loads(catalog_path.read_text()))
