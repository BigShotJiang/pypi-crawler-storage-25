import markdown
from fastapi import APIRouter
from fastapi.responses import HTMLResponse

from jetbrains_plugin_server.model.plugin import PluginSchema
from jetbrains_plugin_server.plugin_catalog import get_plugin_catalog

router = APIRouter(
    prefix="/packages",
)


@router.get("")
def get_packages_route():
    catalog = get_plugin_catalog()
    md = "# Packages\n"
    md += "\n".join(
        f"- [{p.name}](/packages/{p.versions[0].plugin_id}) ({len(p.versions)} versions)" if p.versions else f"- {p.name} -- no versions"
        for p in sorted(catalog.plugins, key=lambda pl: pl.name)
    )
    md += "\n\n [Previous page](/)"
    return HTMLResponse(content=markdown.markdown(md))


@router.get("/{plugin_id}")
def get_package_route(plugin_id: str):
    catalog = get_plugin_catalog()
    plugin: PluginSchema = next(p for p in catalog.plugins if p.versions and p.versions[0].plugin_id == plugin_id)
    md = f"# Package '{plugin.name}'\n"
    md += "\n".join(
        f"- {v.version} compatible with IDE version in `[{v.specs.since_build} ; {v.specs.until_build}]`"
        for v in sorted(plugin.versions, key=lambda ve: ve.specs.since_build_semver, reverse=True)
    )
    md += "\n\n [Previous page](/packages)"
    return HTMLResponse(content=markdown.markdown(md))
