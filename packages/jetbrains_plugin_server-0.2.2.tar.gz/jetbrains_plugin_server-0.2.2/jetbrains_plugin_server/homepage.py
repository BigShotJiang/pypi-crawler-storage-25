import re
from importlib.metadata import PackageNotFoundError, metadata
from pathlib import Path

import markdown

HTML_PREFIX = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Jetbrains Plugin Server</title>
    <link rel="shortcut icon" href="/assets/jetbrains_favicon.ico" type="image/x-icon" sizes="16x16 32x32">
    <link href="/assets/pygments.css" rel="stylesheet" type="text/css">
</head>
<body>
"""

HTML_SUFFIX = """
</body>
</html>
"""


def get_homepage() -> str:
    md = "# Jetbrains plugin server"
    try:
        mdt = metadata("jetbrains-plugin-server")
        md += " v" + mdt["version"] + "\n\n"
        md += mdt["description"]
    except PackageNotFoundError:
        pass

    md = re.sub(r"- `(/[^`]*)`", r"- [`\1`](\1)", md)
    return HTML_PREFIX + markdown.markdown(md, extensions=["fenced_code", "codehilite"]) + HTML_SUFFIX
