"""PrBodyBuilder: composes rich PR body with evidence + AC + DoD checklist."""

from __future__ import annotations

from pathlib import Path

from sendsprint.models import Sprint, SprintItem
from sendsprint.models.reports import StepReport


def _evidence_for_repo(steps: list[StepReport], repo: str) -> list[str]:
    lines: list[str] = []
    for s in steps:
        if s.repo != repo:
            continue
        for ev in s.evidence:
            mark = "✓" if ev.passed else "✗"
            loc = f" — `{ev.path}`" if ev.path else ""
            lines.append(f"- {mark} [{ev.kind}] {ev.title}{loc}")
    return lines


def _findings_for_repo(steps: list[StepReport], repo: str) -> list[str]:
    lines: list[str] = []
    for s in steps:
        if s.repo != repo:
            continue
        for f in s.findings:
            where = f"{f.file}:{f.line}" if f.file and f.line else (f.file or "—")
            lines.append(f"- [{f.severity}] `{f.rule}` @ {where} — {f.message}")
    return lines


def _step_status_table(steps: list[StepReport], repo: str) -> str:
    rows = [
        f"| {s.step} | {s.name} | {s.status} | {(s.message or '')[:80]} |"
        for s in steps
        if s.repo == repo or s.repo is None
    ]
    if not rows:
        return "_(no steps recorded)_"
    header = "| # | Step | Status | Message |\n|---|------|--------|---------|"
    return header + "\n" + "\n".join(rows)


def _item_lines(items: list[SprintItem]) -> str:
    if not items:
        return "_(no items in scope)_"
    return "\n".join(
        f"- `{i.key}` — {i.title} ({i.type}, {i.status})"
        + (f" → {i.source_url}" if i.source_url else "")
        for i in items
    )


class PrBodyBuilder:
    """Compose PR markdown body with sprint context + evidence + DoD."""

    def __init__(self, repo_root: Path) -> None:
        self.repo_root = Path(repo_root)

    def build(
        self,
        sprint: Sprint,
        repo_name: str,
        steps: list[StepReport],
        sprint_slug: str | None = None,
    ) -> str:
        evidence = _evidence_for_repo(steps, repo_name)
        findings = _findings_for_repo(steps, repo_name)
        status_table = _step_status_table(steps, repo_name)
        items_block = _item_lines(sprint.items)
        slug = sprint_slug or f"sprint-{sprint.id}"
        evidence_block = "\n".join(evidence) if evidence else "_(no evidence captured)_"
        findings_block = "\n".join(findings) if findings else "_(none)_"

        return f"""## Summary

Automated PR for sprint `{sprint.name}` ({sprint.source}).

- Sprint ID: `{sprint.id}`
- Source: `{sprint.source}` via transport `{sprint.transport}`
- Items in scope: {len(sprint.items)}
- Repo: `{repo_name}`

## Sprint items

{items_block}

## Step report

{status_table}

## Evidence

{evidence_block}

## Security findings (flag-only, ADR-005)

{findings_block}

## Definition of Done

- [ ] Sprint specs imported under `.specs/sprints/{slug}/`
- [ ] Lint green
- [ ] Unit tests green
- [ ] E2E Playwright green with screenshots/traces
- [ ] Coverage diff >= 80%
- [ ] Security scan: zero findings or accepted exceptions documented
- [ ] CHANGELOG updated if release-relevant
- [ ] ADR opened if architectural decision

## Links

- Sprint spec: `.specs/sprints/{slug}/SPRINT.md`
- DoD workflow: `.github/workflows/dod.yml`
- Source sprint: {sprint.name}
"""
