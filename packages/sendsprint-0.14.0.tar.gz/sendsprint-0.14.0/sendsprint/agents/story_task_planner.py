"""StoryTaskPlanner: expands User Stories without child tasks into delivery tasks."""

from __future__ import annotations

from datetime import UTC, datetime

from sendsprint.models import Link, Sprint, SprintItem
from sendsprint.models.reports import StepReport
from sendsprint.models.workspace import WorkspaceConfig

FRONT_REPO_ROLES = {"front", "mobile"}
BACK_REPO_ROLES = {"api", "back", "lib"}
ADO_TASK_PARENT_TYPES = {"Story", "Bug"}
FRONT_KEYWORDS = {
    "front",
    "frontend",
    "ui",
    "tela",
    "web",
    "componente",
    "layout",
    "modal",
    "botao",
    "botão",
    "formulario",
    "formulário",
    "grid",
}
BACK_KEYWORDS = {
    "api",
    "back",
    "backend",
    "endpoint",
    "servico",
    "serviço",
    "controller",
    "database",
    "banco",
    "query",
    "integracao",
    "integração",
    "contrato",
}


def plan_story_tasks(
    sprint: Sprint,
    workspace: WorkspaceConfig | None = None,
) -> tuple[Sprint, StepReport]:
    """Create front/back task items for stories that have no child tasks.

    The generated tasks are in-memory SprintItems with ``parent_key`` pointing to the
    source story and labels ``scope:front`` / ``scope:back`` so SprintFlow can route
    them to compatible repositories.
    """
    step = StepReport(
        step=2,
        name="plan-story-tasks",
        status="running",
        started_at=datetime.now(UTC),
    )

    sprint, normalized = normalize_azure_backlog_hierarchy(sprint)
    child_parent_keys = {
        item.parent_key
        for item in sprint.items
        if item.type in {"Task", "Subtask"} and item.parent_key
    }
    planned: list[SprintItem] = []

    for item in sprint.items:
        planned.append(item)
        if item.type != "Story":
            continue
        if item.key in child_parent_keys or item.id in child_parent_keys:
            continue

        for scope in _scopes_for_story(workspace):
            planned.append(_task_from_story(item, scope))

    created = len(planned) - len(sprint.items)
    step.status = "ok" if created else "skipped"
    step.message = (
        f"created {created} front/back task(s) from stories without child tasks"
        if created
        else "no stories required synthetic front/back tasks"
    )
    if normalized:
        step.message = f"{step.message}; normalized {normalized} invalid Azure hierarchy link(s)"
    step.finished_at = datetime.now(UTC)
    return sprint.model_copy(update={"items": planned}), step


def normalize_azure_backlog_hierarchy(sprint: Sprint) -> tuple[Sprint, int]:
    """Convert invalid Azure Task parent links into Related links.

    Azure DevOps backlogs can reject same-category hierarchy links, for example
    Issue -> Task in the Agile process. Tasks are kept deliverable but no longer
    treated as children when the local parent item type is not allowed.
    """
    if sprint.source != "azuredevops":
        return sprint, 0

    by_key = {item.key: item for item in sprint.items}
    by_id = {item.id: item for item in sprint.items}
    items: list[SprintItem] = []
    normalized = 0

    for item in sprint.items:
        if item.type not in {"Task", "Subtask"} or not item.parent_key:
            items.append(item)
            continue

        parent = by_key.get(item.parent_key) or by_id.get(item.parent_key)
        if parent is None or parent.type in ADO_TASK_PARENT_TYPES:
            items.append(item)
            continue

        related_key = parent.key or parent.id
        links = list(item.links)
        if not any(link.type == "Related" and link.target_key == related_key for link in links):
            links.append(
                Link(
                    type="Related",
                    target_key=related_key,
                    target_url=parent.source_url,
                )
            )
        items.append(item.model_copy(update={"parent_key": None, "links": links}))
        normalized += 1

    if not normalized:
        return sprint, 0
    return sprint.model_copy(update={"items": items}), normalized


def item_matches_repo(item: SprintItem, repo_role: str | None) -> bool:
    """Return whether a planned item should run against a repo role."""
    if repo_role is None:
        return True
    scopes = {label.split(":", 1)[1] for label in item.labels if label.startswith("scope:")}
    if not scopes:
        scopes = infer_item_scopes(item)
    if not scopes:
        return True
    if repo_role in FRONT_REPO_ROLES and "front" in scopes:
        return True
    return repo_role in BACK_REPO_ROLES and "back" in scopes


def infer_item_scopes(item: SprintItem) -> set[str]:
    """Infer front/back routing from item text when explicit labels are missing."""
    text = " ".join(
        part
        for part in [
            item.title,
            item.description or "",
            item.acceptance_criteria or "",
            " ".join(item.labels),
        ]
        if part
    ).lower()
    scopes: set[str] = set()
    if any(keyword in text for keyword in FRONT_KEYWORDS):
        scopes.add("front")
    if any(keyword in text for keyword in BACK_KEYWORDS):
        scopes.add("back")
    return scopes


def delivery_items(sprint: Sprint) -> list[SprintItem]:
    """Skip parent stories that already have child tasks planned or imported."""
    parents_with_tasks = {
        item.parent_key
        for item in sprint.items
        if item.type in {"Task", "Subtask"} and item.parent_key
    }
    return [
        item
        for item in sprint.items
        if not (
            item.type == "Story"
            and (item.key in parents_with_tasks or item.id in parents_with_tasks)
        )
    ]


def _scopes_for_story(workspace: WorkspaceConfig | None) -> list[str]:
    if not workspace or not workspace.repos:
        return ["front", "back"]

    roles = {repo.role for repo in workspace.repos}
    scopes: list[str] = []
    if roles & FRONT_REPO_ROLES:
        scopes.append("front")
    if roles & BACK_REPO_ROLES:
        scopes.append("back")
    return scopes or ["front", "back"]


def _task_from_story(story: SprintItem, scope: str) -> SprintItem:
    suffix = scope.upper()
    label = "Front" if scope == "front" else "Back"
    parent = story.key or story.id
    description = "\n\n".join(
        part
        for part in [
            f"Generated from User Story {parent}.",
            f"Scope: {label}.",
            story.description,
        ]
        if part
    )
    labels = [*story.labels, "auto:generated", f"scope:{scope}"]

    return SprintItem(
        id=f"{story.id}-{scope}",
        key=f"{parent}-{suffix}",
        type="Task",
        title=f"{label}: {story.title}",
        description=description,
        status=story.status,
        assignee=story.assignee,
        assignee_email=story.assignee_email,
        assignee_account_id=story.assignee_account_id,
        assignee_descriptor=story.assignee_descriptor,
        parent_key=parent,
        labels=labels,
        links=story.links,
        comments=story.comments,
        attachments=story.attachments,
        acceptance_criteria=story.acceptance_criteria,
        created_at=story.created_at,
        updated_at=story.updated_at,
        source_url=story.source_url,
    )
