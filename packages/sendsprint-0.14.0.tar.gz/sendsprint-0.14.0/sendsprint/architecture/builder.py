"""Build minimal architecture docs when missing, then re-inspect for score."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from pydantic import BaseModel, Field

from ..tech import TechFingerprint, detect_tech
from .mapper import ArchitectureMapper

DEFAULT_THRESHOLD = 0.6


class ArchitectureBuildResult(BaseModel):
    repo_path: str
    repo_name: str
    created_files: list[str] = Field(default_factory=list)
    skipped_files: list[str] = Field(default_factory=list)
    fingerprint: TechFingerprint
    final_score: float = 0.0
    is_mapped: bool = False
    threshold: float = DEFAULT_THRESHOLD


def build_architecture(
    repo_path: str | Path,
    *,
    fingerprint: TechFingerprint | None = None,
    repo_name: str | None = None,
    threshold: float = DEFAULT_THRESHOLD,
) -> ArchitectureBuildResult:
    """Generate architecture docs in repo_path when missing, re-score, return result."""
    repo = Path(repo_path).expanduser().resolve()
    if not repo.exists():
        raise FileNotFoundError(f"repo path not found: {repo}")

    fp = fingerprint or detect_tech(repo)
    name = repo_name or repo.name

    created: list[str] = []
    skipped: list[str] = []

    _write_if_missing(repo / "README.md", _readme(name, fp), created, skipped)
    _write_if_missing(repo / "ARCHITECTURE.md", _architecture_md(name, fp), created, skipped)
    _write_if_missing(
        repo / "docs" / "architecture" / "overview.md",
        _overview(name, fp),
        created,
        skipped,
    )
    _write_if_missing(
        repo / "docs" / "adr" / "0001-initial.md",
        _adr(name, fp),
        created,
        skipped,
    )
    _write_if_missing(
        repo / "docs" / "dependencies.md",
        _dependencies(name, fp),
        created,
        skipped,
    )
    _write_if_missing(
        repo / "docs" / "deploy.md",
        _deploy(name, fp),
        created,
        skipped,
    )

    report = ArchitectureMapper().inspect(repo)
    return ArchitectureBuildResult(
        repo_path=str(repo),
        repo_name=name,
        created_files=created,
        skipped_files=skipped,
        fingerprint=fp,
        final_score=report.score,
        is_mapped=report.score >= threshold,
        threshold=threshold,
    )


def _write_if_missing(path: Path, content: str, created: list[str], skipped: list[str]) -> None:
    if path.exists():
        skipped.append(str(path))
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    created.append(str(path))


def _now_iso() -> str:
    return datetime.now(tz=UTC).isoformat(timespec="seconds")


def _techs_line(fp: TechFingerprint) -> str:
    return ", ".join(fp.techs) if fp.techs else "n/a"


def _roles_line(fp: TechFingerprint) -> str:
    return ", ".join(fp.roles) if fp.roles else "other"


def _pms_line(fp: TechFingerprint) -> str:
    return ", ".join(fp.package_managers) if fp.package_managers else "n/a"


def _signals_block(fp: TechFingerprint) -> str:
    if not fp.signals:
        return "_no signals detected_"
    lines = [f"- `{marker}` -> **{tech}**" for marker, tech in fp.signals.items()]
    return "\n".join(lines)


def _readme(name: str, fp: TechFingerprint) -> str:
    return f"""# {name}

Auto-generated baseline README ({_now_iso()}).

## Stack

- Roles: {_roles_line(fp)}
- Technologies: {_techs_line(fp)}
- Package managers: {_pms_line(fp)}

## Quick start

Replace this section with project-specific run / build / test instructions.

## Architecture

See [`ARCHITECTURE.md`](ARCHITECTURE.md) and
[`docs/architecture/overview.md`](docs/architecture/overview.md).

## ADRs

See [`docs/adr/`](docs/adr/).
"""


def _architecture_md(name: str, fp: TechFingerprint) -> str:
    return f"""# Architecture - {name}

Auto-generated baseline ({_now_iso()}).
Update this file as the architecture evolves.

## Roles

{_roles_line(fp)}

## Technologies

{_techs_line(fp)}

## Package managers

{_pms_line(fp)}

## Detection signals

{_signals_block(fp)}

## High-level diagram

```
[ Client ] -> [ Frontend ] -> [ Backend / API ] -> [ Database / External services ]
```

Replace the ASCII diagram above with C4 / Mermaid / PlantUML once the real topology is known.

## Key modules

- _to be documented_

## Cross-cutting concerns

- Security
- Observability
- CI/CD
- Testing strategy

## Related docs

- [`docs/architecture/overview.md`](docs/architecture/overview.md)
- [`docs/adr/`](docs/adr/)
- [`docs/dependencies.md`](docs/dependencies.md)
- [`docs/deploy.md`](docs/deploy.md)
"""


def _overview(name: str, fp: TechFingerprint) -> str:
    return f"""# Architecture overview - {name}

Auto-generated ({_now_iso()}).

## Detected stack

- Roles: {_roles_line(fp)}
- Technologies: {_techs_line(fp)}
- Package managers: {_pms_line(fp)}

## Layers

| Layer | Responsibility | Implementation |
|---|---|---|
| Presentation | UI / API surface | _to be documented_ |
| Application | Use cases | _to be documented_ |
| Domain | Business rules | _to be documented_ |
| Infrastructure | Persistence, external services | _to be documented_ |

## Data flows

Document the main user / system flows here, ideally as numbered sequence diagrams.

## Open questions

- _list_
"""


def _adr(name: str, fp: TechFingerprint) -> str:
    return f"""# ADR-0001: Initial architecture baseline

- Status: Accepted
- Date: {_now_iso()}
- Project: {name}

## Context

This ADR records the initial architecture baseline detected while
bootstrapping documentation for the project. It is intentionally minimal so the team
can extend or replace it as decisions are made explicit.

## Decision

Adopt the following baseline:

- Roles: {_roles_line(fp)}
- Technologies: {_techs_line(fp)}
- Package managers: {_pms_line(fp)}

## Consequences

- Future ADRs in `docs/adr/` MUST reference and refine this baseline.
- Significant deviations require a new ADR (numbered `0002+`).

## Detection signals

{_signals_block(fp)}
"""


def _dependencies(name: str, fp: TechFingerprint) -> str:
    return f"""# Dependencies - {name}

Auto-generated ({_now_iso()}).

## External services

- _list third-party APIs, queues, databases, identity providers, etc._

## Internal modules

- _list internal libraries and shared modules_

## Package managers in use

{_pms_line(fp)}

## Detection signals

{_signals_block(fp)}

## Dependency graph

Replace with a real graph (e.g. SVG/PNG export from `madge`, `dependency-cruiser`,
`pydeps`, or any equivalent tool) once available.
"""


def _deploy(name: str, fp: TechFingerprint) -> str:
    return f"""# Deployment topology - {name}

Auto-generated ({_now_iso()}).

## Environments

| Environment | URL | Provider | Notes |
|---|---|---|---|
| dev | _tbd_ | _tbd_ | _tbd_ |
| staging | _tbd_ | _tbd_ | _tbd_ |
| prod | _tbd_ | _tbd_ | _tbd_ |

## Pipelines

- CI: _tbd_
- CD: _tbd_

## Infrastructure

- Runtime: {_techs_line(fp)}
- Roles: {_roles_line(fp)}

Document VPC / cluster / namespace / region constraints here.
"""
