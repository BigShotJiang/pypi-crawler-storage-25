# siliq

Universal client for the [Siliq Compute Bazaar](https://siliq.io) — invoke any encrypted compute service with one SDK.

## Install

```bash
pip install siliq            # Core (browse, invoke HTTP services)
pip install siliq[fhe]       # + FHE encrypted compute (koa-fhe)
pip install siliq[payment]   # + x402 USDC payment signing
pip install siliq[all]       # Everything
```

## Usage

```python
from siliq import Client

c = Client()

# Browse the bazaar
services = c.browse(category="encrypted-compute")
for s in services:
    print(f"{s.name}: ${s.pricing.per_invocation}/call [{s.trust_tier}]")

# Invoke a service (FHE — encrypted end-to-end)
result = c.invoke("encrypted-compare", x=85, y=80)
print(result.data)  # {"greater": True}

# Invoke by agent ID
result = c.invoke(21648, x=85, y=80)
```

## CLI

```bash
siliq browse                                    # All services (JSON)
siliq browse --category encrypted-compute       # Filter by category
siliq info encrypted-compare                    # Service details
siliq invoke encrypted-compare --x 85 --y 80   # Invoke (FHE)
siliq health encrypted-compare                  # Endpoint health
siliq verify encrypted-compare --queries 5      # Trap query verification
```

Zero-install via uvx:
```bash
uvx siliq browse
uvx siliq invoke encrypted-compare --x 85 --y 80
```

## Trust Tiers

Every service carries a verifiable trust badge:

| Tier | Guarantee |
|------|-----------|
| **FHE Native** | Data never decrypted — mathematical proof |
| **TEE Verified** | Hardware enclave — attestation on-chain |
| **Staked** | Creator staked USDC — economic guarantee |
| **Community** | 1000+ invocations, zero fraud proofs |
| **Unverified** | New listing — no verification |

## License

MIT
