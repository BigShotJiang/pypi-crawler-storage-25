"""Siliq SDK types — service info, invocation results, etc."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ServicePricing:
    per_invocation: float
    currency: str = "USDC"
    chain: str = "base"
    payment_protocol: str = "x402"
    recipient_address: str = ""


@dataclass(frozen=True)
class ServiceInfo:
    agent_id: int
    name: str
    description: str
    category: str
    endpoint: str
    pricing: ServicePricing
    trust_tier: str
    latency_ms: int
    creator: str = ""
    creator_handle: str = ""
    input_schema: dict = field(default_factory=dict)
    output_schema: dict = field(default_factory=dict)
    health_endpoint: str | None = None
    url: str = ""

    @classmethod
    def from_api(cls, data: dict) -> ServiceInfo:
        pricing_data = data.get("pricing", {})
        return cls(
            agent_id=data.get("agentId", 0),
            name=data.get("name", ""),
            description=data.get("description", ""),
            category=data.get("category", ""),
            endpoint=data.get("endpoint", ""),
            pricing=ServicePricing(
                per_invocation=pricing_data.get("perInvocation", 0),
                currency=pricing_data.get("currency", "USDC"),
                chain=pricing_data.get("chain", "base"),
                payment_protocol=pricing_data.get("paymentProtocol", "x402"),
                recipient_address=pricing_data.get("recipientAddress", ""),
            ),
            trust_tier=data.get("trustTier", "unverified"),
            latency_ms=data.get("latencyMs", 0),
            creator=data.get("creator", ""),
            creator_handle=data.get("creatorHandle", data.get("author", "")),
            input_schema=data.get("inputSchema", {}),
            output_schema=data.get("outputSchema", {}),
            health_endpoint=data.get("healthEndpoint"),
            url=data.get("url", ""),
        )


@dataclass(frozen=True)
class InvokeResult:
    data: dict
    cost_usd: float
    latency_ms: float
    service_name: str
    trust_tier: str
    success: bool = True
    error: str | None = None


@dataclass(frozen=True)
class HealthResult:
    status: str  # "online" | "offline" | "error"
    latency_ms: float | None = None
    detail: str = ""


@dataclass(frozen=True)
class VerifyResult:
    passed: bool
    queries: int
    failures: int = 0
    detail: str = ""
