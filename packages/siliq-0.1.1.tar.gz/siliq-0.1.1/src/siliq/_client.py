"""Siliq universal client — one SDK for any compute service on the bazaar."""

from __future__ import annotations

from ._discovery import ServiceCatalog
from ._payment import create_payment_headers
from ._transport import check_health
from ._types import HealthResult, InvokeResult, ServiceInfo, VerifyResult
from ._adapters._http import HTTPAdapter
from ._adapters._fhe import FHEAdapter


class Client:
    """Universal client for the Siliq Compute Bazaar.

    Usage::

        from siliq import Client
        c = Client()
        services = c.browse(category="encrypted-compute")
        result = c.invoke("encrypted-compare", x=85, y=80)
    """

    def __init__(
        self,
        *,
        private_key: str | None = None,
        payment_proof: str | None = None,
        api_url: str = "https://siliq.io",
        cache_ttl: int = 300,
    ):
        self._private_key = private_key
        self._payment_proof = payment_proof
        self._catalog = ServiceCatalog(api_url=api_url, cache_ttl=cache_ttl)
        self._http_adapter = HTTPAdapter()
        self._fhe_adapter: FHEAdapter | None = None

    def _get_fhe_adapter(self) -> FHEAdapter:
        if self._fhe_adapter is None:
            self._fhe_adapter = FHEAdapter(
                payment_proof=self._payment_proof,
            )
        return self._fhe_adapter

    # ── Discovery ──────────────────────────────────────────────────────

    def browse(
        self,
        *,
        category: str | None = None,
        max_price: float | None = None,
        trust_tier: str | None = None,
        query: str | None = None,
    ) -> list[ServiceInfo]:
        """Browse the bazaar with optional filters."""
        return self._catalog.browse(
            category=category,
            max_price=max_price,
            trust_tier=trust_tier,
            query=query,
        )

    def get_service(self, name_or_id: str | int) -> ServiceInfo | None:
        """Look up a service by name or agent ID."""
        return self._catalog.get_service(name_or_id)

    # ── Invocation ─────────────────────────────────────────────────────

    def invoke(self, service: str | int, **kwargs) -> InvokeResult:
        """Invoke a service by name or agent ID.

        For FHE services, handles key generation, encryption, and decryption
        automatically. For HTTP services, sends JSON with x402 payment.

        Args:
            service: Service name (fuzzy match) or agent ID (int).
            **kwargs: Input parameters matching the service's input schema.

        Returns:
            InvokeResult with data, cost, latency, and trust tier.
        """
        svc = self._catalog.get_service(service)
        if svc is None:
            return InvokeResult(
                data={},
                cost_usd=0,
                latency_ms=0,
                service_name=str(service),
                trust_tier="unknown",
                success=False,
                error=f"Service not found: {service}",
            )

        payment_headers = create_payment_headers(
            amount_usdc=svc.pricing.per_invocation,
            recipient=svc.pricing.recipient_address,
            private_key=self._private_key,
            payment_proof=self._payment_proof,
        )

        if svc.trust_tier == "fhe-native":
            return self._get_fhe_adapter().invoke(svc, kwargs, payment_headers)
        else:
            return self._http_adapter.invoke(svc, kwargs, payment_headers)

    # ── Health ─────────────────────────────────────────────────────────

    def health(self, service: str | int) -> HealthResult:
        """Check if a service endpoint is responding."""
        svc = self._catalog.get_service(service)
        if svc is None:
            return HealthResult(status="error", detail=f"Service not found: {service}")

        url = svc.health_endpoint or svc.endpoint
        ok, ms = check_health(url)
        return HealthResult(
            status="online" if ok else "offline",
            latency_ms=ms,
        )

    # ── FHE-specific ───────────────────────────────────────────────────

    def warm_up(self, services: list[str]) -> None:
        """Pre-generate FHE keys for the named services (background)."""
        self._get_fhe_adapter().warm_up(services)

    @property
    def ready(self) -> dict[str, bool]:
        """Check which FHE circuits have keys ready."""
        return self._get_fhe_adapter().ready

    # ── Integrity ──────────────────────────────────────────────────────

    def verify(self, service: str | int, n_queries: int = 5) -> VerifyResult:
        """Run trap queries to verify service integrity (FHE only)."""
        svc = self._catalog.get_service(service)
        if svc is None:
            return VerifyResult(passed=False, queries=0, detail=f"Service not found: {service}")

        if svc.trust_tier != "fhe-native":
            return VerifyResult(
                passed=True, queries=0,
                detail="Non-FHE services don't support trap query verification",
            )

        try:
            client = self._get_fhe_adapter()._get_client()
            # Map service name to circuit
            from ._adapters._fhe import _get_circuit
            circuit = _get_circuit(svc.name)
            if not circuit or circuit not in ("add", "multiply", "threshold"):
                return VerifyResult(
                    passed=True, queries=0,
                    detail=f"Integrity verification not available for circuit: {circuit}",
                )

            result = client.verify_integrity(circuit, n_queries)
            return VerifyResult(
                passed=result.passed,
                queries=result.queries,
                failures=len([p for p in result.proofs if not p.passed]) if hasattr(result, "proofs") else 0,
            )
        except Exception as e:
            return VerifyResult(passed=False, queries=0, detail=str(e))
