"""Siliq CLI — browse and invoke compute services from the terminal.

All output is JSON for agent consumption.
Exit code 0 = success, 1 = error.

Usage:
    siliq browse [--category X] [--max-price X] [--trust X] [--query X]
    siliq info <service>
    siliq health <service>
    siliq invoke <service> [--key value ...]
    siliq verify <service> [--queries N]
"""

from __future__ import annotations

import json
import sys
from dataclasses import asdict


def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help", "help"):
        print(__doc__.strip())
        sys.exit(0)

    command = args[0]
    rest = args[1:]

    from ._client import Client

    # Parse --key value pairs from remaining args
    opts: dict[str, str] = {}
    positional: list[str] = []
    i = 0
    while i < len(rest):
        if rest[i].startswith("--"):
            key = rest[i][2:].replace("-", "_")
            if i + 1 < len(rest) and not rest[i + 1].startswith("--"):
                opts[key] = rest[i + 1]
                i += 2
            else:
                opts[key] = "true"
                i += 1
        else:
            positional.append(rest[i])
            i += 1

    private_key = opts.pop("wallet", opts.pop("private_key", None))
    api_url = opts.pop("api_url", opts.pop("api", "https://siliq.io"))

    client = Client(private_key=private_key, api_url=api_url)

    try:
        if command == "browse":
            services = client.browse(
                category=opts.get("category"),
                max_price=float(opts["max_price"]) if "max_price" in opts else None,
                trust_tier=opts.get("trust"),
                query=opts.get("query", opts.get("q")),
            )
            _output([_service_summary(s) for s in services])

        elif command == "info":
            if not positional:
                _error("Usage: siliq info <service-name-or-id>")
            svc = client.get_service(_parse_id(positional[0]))
            if svc is None:
                _error(f"Service not found: {positional[0]}")
            _output(asdict(svc))

        elif command == "health":
            if not positional:
                _error("Usage: siliq health <service-name-or-id>")
            result = client.health(_parse_id(positional[0]))
            _output(asdict(result))

        elif command == "invoke":
            if not positional:
                _error("Usage: siliq invoke <service> --param value ...")
            service_ref = _parse_id(positional[0])
            # Remaining opts are kwargs for the service
            invoke_kwargs = {}
            for k, v in opts.items():
                # Try to parse as number
                try:
                    invoke_kwargs[k] = int(v)
                except ValueError:
                    try:
                        invoke_kwargs[k] = float(v)
                    except ValueError:
                        invoke_kwargs[k] = v

            result = client.invoke(service_ref, **invoke_kwargs)
            _output(asdict(result))
            if not result.success:
                sys.exit(1)

        elif command == "verify":
            if not positional:
                _error("Usage: siliq verify <service> [--queries N]")
            n = int(opts.get("queries", "5"))
            result = client.verify(_parse_id(positional[0]), n_queries=n)
            _output(asdict(result))
            if not result.passed:
                sys.exit(1)

        else:
            _error(f"Unknown command: {command}. Try: browse, info, health, invoke, verify")

    except KeyboardInterrupt:
        sys.exit(130)
    except Exception as e:
        _error(str(e))


def _parse_id(s: str) -> str | int:
    try:
        return int(s)
    except ValueError:
        return s


def _service_summary(s) -> dict:
    return {
        "agent_id": s.agent_id,
        "name": s.name,
        "category": s.category,
        "price_per_call": s.pricing.per_invocation,
        "trust_tier": s.trust_tier,
        "latency_ms": s.latency_ms,
        "url": s.url or f"https://siliq.io/service/{s.agent_id}",
    }


def _output(data):
    print(json.dumps(data, indent=2, default=str))


def _error(msg: str):
    print(json.dumps({"error": msg}), file=sys.stderr)
    sys.exit(1)


if __name__ == "__main__":
    main()
