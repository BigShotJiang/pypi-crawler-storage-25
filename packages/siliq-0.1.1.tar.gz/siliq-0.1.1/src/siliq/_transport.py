"""Stdlib-only HTTP transport — no external dependencies."""

from __future__ import annotations

import json
import urllib.request
import urllib.error
from typing import Any


_UA = "siliq-sdk/0.1.0"


def get_json(url: str, *, timeout: float = 15) -> Any:
    req = urllib.request.Request(url, headers={"Accept": "application/json", "User-Agent": _UA})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read())


def post_json(
    url: str,
    body: dict,
    *,
    headers: dict[str, str] | None = None,
    timeout: float = 30,
) -> Any:
    data = json.dumps(body).encode()
    hdrs = {"Content-Type": "application/json", "Accept": "application/json", "User-Agent": _UA}
    if headers:
        hdrs.update(headers)
    req = urllib.request.Request(url, data=data, headers=hdrs, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read())


def check_health(url: str, *, timeout: float = 5) -> tuple[bool, float]:
    """Returns (is_healthy, latency_ms)."""
    import time

    t0 = time.monotonic()
    try:
        data = get_json(url, timeout=timeout)
        ms = (time.monotonic() - t0) * 1000
        status = data.get("status", "") if isinstance(data, dict) else ""
        return status in ("ok", "online", "healthy"), ms
    except Exception:
        ms = (time.monotonic() - t0) * 1000
        return False, ms
