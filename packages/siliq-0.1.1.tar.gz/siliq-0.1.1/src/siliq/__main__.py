"""Allow `python -m siliq` invocation."""
from ._cli import main

main()
