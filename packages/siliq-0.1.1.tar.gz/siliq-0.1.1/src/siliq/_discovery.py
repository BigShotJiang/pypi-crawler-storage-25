"""Service catalog discovery from the Siliq API."""

from __future__ import annotations

import time
from typing import Any

from ._transport import get_json
from ._types import ServiceInfo


class ServiceCatalog:
    def __init__(self, api_url: str = "https://siliq.io", cache_ttl: int = 300):
        self._api_url = api_url.rstrip("/")
        self._cache_ttl = cache_ttl
        self._cache: list[ServiceInfo] = []
        self._cache_time: float = 0

    def _fetch(self) -> list[ServiceInfo]:
        now = time.monotonic()
        if self._cache and (now - self._cache_time) < self._cache_ttl:
            return self._cache

        try:
            data = get_json(f"{self._api_url}/api/agents")
            services_raw = data.get("services", data.get("agents", []))
            self._cache = [ServiceInfo.from_api(s) for s in services_raw]
            self._cache_time = now
        except Exception:
            if not self._cache:
                self._cache = []
        return self._cache

    def browse(
        self,
        *,
        category: str | None = None,
        max_price: float | None = None,
        trust_tier: str | None = None,
        query: str | None = None,
    ) -> list[ServiceInfo]:
        services = self._fetch()
        if category:
            services = [s for s in services if s.category == category]
        if max_price is not None:
            services = [s for s in services if s.pricing.per_invocation <= max_price]
        if trust_tier:
            services = [s for s in services if s.trust_tier == trust_tier]
        if query:
            q = query.lower()
            services = [
                s for s in services
                if q in s.name.lower() or q in s.description.lower()
            ]
        return services

    def get_service(self, name_or_id: str | int) -> ServiceInfo | None:
        services = self._fetch()
        if isinstance(name_or_id, int):
            return next((s for s in services if s.agent_id == name_or_id), None)
        # Fuzzy name match: exact, then contains
        name_lower = name_or_id.lower().replace("-", " ").replace("_", " ")
        for s in services:
            if s.name.lower() == name_lower:
                return s
        for s in services:
            if name_lower in s.name.lower().replace("-", " "):
                return s
        return None
