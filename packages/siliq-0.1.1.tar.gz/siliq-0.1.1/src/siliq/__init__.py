"""Siliq — Universal client for the Compute Bazaar.

Usage::

    from siliq import Client
    c = Client()
    services = c.browse(category="encrypted-compute")
    result = c.invoke("encrypted-compare", x=85, y=80)
"""

from ._client import Client
from ._types import InvokeResult, ServiceInfo, HealthResult, VerifyResult

__all__ = ["Client", "InvokeResult", "ServiceInfo", "HealthResult", "VerifyResult"]
__version__ = "0.1.1"
