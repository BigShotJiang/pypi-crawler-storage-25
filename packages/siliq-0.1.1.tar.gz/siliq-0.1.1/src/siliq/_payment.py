"""x402 payment handling for Siliq services.

Payment flow:
1. Service requires x402 → returns 402 with X-Payment-Request header
2. Client signs USDC transfer on Base
3. Client retries with X-Payment-Proof header

For now, this module provides the payment proof header construction.
Actual on-chain USDC transfer requires eth-account (optional dep).
"""

from __future__ import annotations

import base64
import json
import time


def create_payment_headers(
    *,
    amount_usdc: float,
    recipient: str,
    private_key: str | None = None,
    payment_proof: str | None = None,
) -> dict[str, str]:
    """Build x402 payment headers for a service invocation.

    If payment_proof is provided directly, use it.
    If private_key is provided, sign a USDC transfer (requires eth-account).
    If neither, return empty headers (service must be free).
    """
    if payment_proof:
        return {"X-Payment-Proof": payment_proof}

    if amount_usdc <= 0:
        return {}

    if private_key:
        return _sign_payment(amount_usdc, recipient, private_key)

    # No payment method available
    return {}


def _sign_payment(amount_usdc: float, recipient: str, private_key: str) -> dict[str, str]:
    """Sign a USDC transfer on Base. Requires eth-account."""
    try:
        from eth_account import Account
    except ImportError:
        raise ImportError(
            "x402 payment requires eth-account. Install with: pip install siliq[payment]"
        )

    # Construct payment proof (simplified x402 flow)
    # In production, this would create and submit a real USDC transfer on Base
    # For now, create a signed attestation that can be verified by the gateway
    account = Account.from_key(private_key)
    amount_units = int(amount_usdc * 1_000_000)  # 6 decimals

    payload = {
        "from": account.address,
        "to": recipient,
        "amount": amount_units,
        "currency": "USDC",
        "chain": "base",
        "timestamp": int(time.time()),
    }

    message = json.dumps(payload, sort_keys=True)
    signed = account.sign_message(
        signable_message=_encode_defunct(message)
    )

    proof = base64.b64encode(json.dumps({
        **payload,
        "signature": signed.signature.hex(),
    }).encode()).decode()

    return {"X-Payment-Proof": proof}


def _encode_defunct(text: str):
    """Create an EIP-191 signable message."""
    from eth_account.messages import encode_defunct
    return encode_defunct(text=text)
