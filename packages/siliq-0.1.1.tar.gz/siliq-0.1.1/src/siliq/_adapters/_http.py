"""Generic HTTP adapter for TEE/staked/unverified services."""

from __future__ import annotations

import time

from .._transport import post_json
from .._types import InvokeResult, ServiceInfo


class HTTPAdapter:
    """Invoke a service via plain HTTP POST + x402 payment header."""

    def invoke(
        self,
        service: ServiceInfo,
        kwargs: dict,
        payment_headers: dict[str, str],
    ) -> InvokeResult:
        t0 = time.monotonic()

        try:
            data = post_json(
                service.endpoint,
                kwargs,
                headers=payment_headers,
                timeout=max(30, service.latency_ms / 1000 * 3),
            )
            ms = (time.monotonic() - t0) * 1000

            return InvokeResult(
                data=data if isinstance(data, dict) else {"result": data},
                cost_usd=service.pricing.per_invocation,
                latency_ms=ms,
                service_name=service.name,
                trust_tier=service.trust_tier,
            )
        except Exception as e:
            ms = (time.monotonic() - t0) * 1000
            return InvokeResult(
                data={},
                cost_usd=0,
                latency_ms=ms,
                service_name=service.name,
                trust_tier=service.trust_tier,
                success=False,
                error=str(e),
            )
