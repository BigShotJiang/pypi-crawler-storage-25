"""FHE adapter — wraps koa-fhe for encrypted compute services."""

from __future__ import annotations

import time

from .._types import InvokeResult, ServiceInfo

# Circuit name mapping: service name → koa-fhe method
_CIRCUIT_MAP = {
    "encrypted compare": "compare",
    "encrypted addition": "add",
    "encrypted multiply": "multiply",
    "encrypted rigidity scorer": "measure_rigidity",
    "encrypted schedule analyzer": "analyze_schedule",
}


def _get_circuit(service_name: str) -> str | None:
    return _CIRCUIT_MAP.get(service_name.lower())


class FHEAdapter:
    """Invoke FHE services via koa-fhe Client."""

    def __init__(self, payment_proof: str | None = None):
        self._payment_proof = payment_proof
        self._clients: dict[str, object] = {}

    def _get_client(self, service_endpoint: str = "http://127.0.0.1:3410"):
        # Derive the FHE server URL from the service endpoint
        # e.g., "https://compute.siliq.io/fhe/threshold" → "https://compute.siliq.io/fhe"
        # koa-fhe Client appends /health, /client-specs/:circuit, /evaluate/:circuit
        from urllib.parse import urlparse
        parsed = urlparse(service_endpoint)
        # Strip the circuit name from the path to get the FHE base
        # /fhe/threshold → /fhe, /fhe/add → /fhe
        path_parts = parsed.path.rstrip("/").rsplit("/", 1)
        base_path = path_parts[0] if len(path_parts) > 1 else ""
        server = f"{parsed.scheme}://{parsed.netloc}{base_path}"

        if server not in self._clients:
            try:
                from koa_fhe import Client
            except ImportError:
                raise ImportError(
                    "FHE services require koa-fhe. Install with: pip install siliq[fhe]"
                )
            # Install global opener with proper User-Agent to avoid Cloudflare 1010
            import urllib.request
            opener = urllib.request.build_opener()
            opener.addheaders = [("User-Agent", "siliq-sdk/0.1.0")]
            urllib.request.install_opener(opener)

            self._clients[server] = Client(
                server=server,
                payment_proof=self._payment_proof,
            )
        return self._clients[server]

    def invoke(
        self,
        service: ServiceInfo,
        kwargs: dict,
        payment_headers: dict[str, str],
    ) -> InvokeResult:
        client = self._get_client(service.endpoint)
        circuit = _get_circuit(service.name)
        t0 = time.monotonic()

        try:
            if circuit == "compare":
                result = client.compare(int(kwargs["x"]), int(kwargs["y"]))
                data = {"greater": result.greater}
            elif circuit == "add":
                result = client.add(int(kwargs["x"]), int(kwargs["y"]))
                data = {"value": result.value}
            elif circuit == "multiply":
                result = client.multiply(int(kwargs["x"]), int(kwargs["y"]))
                data = {"value": result.value}
            elif circuit == "measure_rigidity":
                old = kwargs.get("old_schedule", kwargs.get("old", []))
                new = kwargs.get("new_schedule", kwargs.get("new", []))
                result = client.measure_rigidity(list(old), list(new))
                data = {
                    "hamming_distance": result.hamming_distance,
                    "rigidity_score": result.rigidity_score,
                }
            elif circuit == "analyze_schedule":
                old = kwargs.get("old_schedule", kwargs.get("old", []))
                new = kwargs.get("new_schedule", kwargs.get("new", []))
                result = client.analyze_schedule(list(old), list(new))
                data = {
                    "objective": result.objective,
                    "rigidity_score": result.rigidity_score,
                }
            else:
                return InvokeResult(
                    data={},
                    cost_usd=0,
                    latency_ms=(time.monotonic() - t0) * 1000,
                    service_name=service.name,
                    trust_tier=service.trust_tier,
                    success=False,
                    error=f"Unknown FHE circuit for service: {service.name}",
                )

            ms = (time.monotonic() - t0) * 1000
            return InvokeResult(
                data=data,
                cost_usd=service.pricing.per_invocation,
                latency_ms=ms,
                service_name=service.name,
                trust_tier=service.trust_tier,
            )
        except Exception as e:
            ms = (time.monotonic() - t0) * 1000
            return InvokeResult(
                data={},
                cost_usd=0,
                latency_ms=ms,
                service_name=service.name,
                trust_tier=service.trust_tier,
                success=False,
                error=str(e),
            )

    def warm_up(self, circuits: list[str], server: str = "https://compute.siliq.io") -> None:
        client = self._get_client(server)
        client.warm_up(circuits)

    @property
    def ready(self) -> dict[str, bool]:
        if not self._clients:
            return {}
        # Return ready state from the first connected client
        client = next(iter(self._clients.values()))
        return client.ready
