# outworx-hooks

Lightweight webhook monitoring SDK for Python -- know exactly when your webhooks break.

Works with FastAPI, Flask, and Django. Monitor everything from your dashboard at [hooks.outworx.io](https://hooks.outworx.io).

## Installation

```bash
pip install outworx-hooks
```

## Quick Start

### 1. Initialize

Add your API key once at app startup, or set the `OUTWORX_HOOKS_API_KEY` environment variable.

```python
import outworx_hooks

outworx_hooks.init(api_key="your-api-key")
```

Or via environment variable:

```bash
OUTWORX_HOOKS_API_KEY=your-api-key
```

### 2. Wrap Your Webhook Handler

#### FastAPI

```python
from fastapi import FastAPI
from outworx_hooks.integrations.fastapi import OutworxHooksMiddleware
from outworx_hooks import TrackOptions

app = FastAPI()

app.add_middleware(
    OutworxHooksMiddleware,
    options=TrackOptions(provider="stripe", event_type_field="type")
)

@app.post("/webhooks/stripe")
async def handle_webhook():
    # ... process webhook
    return {"status": "ok"}
```

#### Flask

```python
from flask import Flask
from outworx_hooks.integrations.flask import with_webhook_monitoring
from outworx_hooks import TrackOptions

app = Flask(__name__)

@app.route("/webhooks/stripe", methods=["POST"])
@with_webhook_monitoring(TrackOptions(provider="stripe", event_type_field="type"))
def handle_webhook():
    # ... process webhook
    return {"status": "ok"}
```

#### Django

Add the middleware to your `MIDDLEWARE` setting:

```python
# settings.py
MIDDLEWARE = [
    ...
    'outworx_hooks.integrations.django.OutworxHooksMiddleware',
]

OUTWORX_HOOKS_OPTIONS = {
    'provider': 'stripe',
    'event_type_field': 'type',
    'capture_body': True
}
```

## Configuration

```python
import outworx_hooks

outworx_hooks.init(
    api_key="your-api-key",
    endpoint="https://hooks.outworx.io/api/ingest", # default
    debug=True, # log events to console
    timeout=3000, # HTTP timeout in ms
    on_error=lambda err: print(err), # error callback
)
```

## Track Options

Each adapter accepts `TrackOptions`:

| Option            | Type          | Default | Description                                         |
| ----------------- | ------------- | ------- | --------------------------------------------------- |
| `provider`        | `str`         | --      | Webhook provider name (e.g., "stripe", "shopify")   |
| `event_type_header` | `str`       | --      | Header name to extract event type from              |
| `event_type_field` | `str`        | --      | Body field to extract event type from (e.g., "type") |
| `capture_body`     | `bool`       | `False` | Capture response body (disabled by default)         |
| `capture_headers`  | `bool`       | `True`  | Capture request headers (sensitive ones redacted)   |
| `metadata`         | `dict`       | --      | Custom metadata attached to every event             |

## Dashboard

View your webhook activity at [hooks.outworx.io](https://hooks.outworx.io).

## License

Business Source License 1.1 — see [LICENSE](./LICENSE) for full text.

Free to use in production with the Outworx Hooks service. You may not use this
SDK or any derivative work to offer a hosted webhook monitoring, analytics, or
alerting service that competes with Outworx. The license converts to Apache
2.0 on 2030-04-17.

For commercial licensing inquiries, contact licensing@outworx.io.
