from dataclasses import dataclass, field
from typing import Optional, Dict, Any, Callable

@dataclass
class WebhookEventPayload:
    provider: str
    status_code: int
    success: bool
    duration_ms: int
    payload_size: int
    timestamp: str  # ISO 8601
    event_type: Optional[str] = None
    request_headers: Optional[Dict[str, str]] = None
    response_body: Optional[str] = None
    signature_valid: Optional[bool] = None
    error_message: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    source_url: Optional[str] = None

@dataclass
class OutworxHooksConfig:
    api_key: str
    endpoint: str = "https://hooks.outworx.io/api/ingest"
    debug: bool = False
    timeout: int = 3000
    on_error: Optional[Callable[[Exception], None]] = None

@dataclass
class TrackOptions:
    provider: str
    event_type_header: Optional[str] = None
    event_type_field: Optional[str] = None
    capture_body: bool = False
    capture_headers: bool = True
    metadata: Optional[Dict[str, Any]] = None
    signature_valid: Optional[bool] = None
