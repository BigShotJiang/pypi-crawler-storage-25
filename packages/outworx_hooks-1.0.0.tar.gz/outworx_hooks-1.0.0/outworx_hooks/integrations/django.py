import time
from typing import Optional
from django.conf import settings
from ..core import capture_webhook_event
from ..types import TrackOptions

class OutworxHooksMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        self.options = getattr(settings, 'OUTWORX_HOOKS_OPTIONS', None)

    def __call__(self, request):
        if not self.options:
            return self.get_response(request)

        start_time = time.time()
        
        # Read request info
        request_headers = {k: v for k, v in request.headers.items()}
        request_body = None
        
        if self.options.get('capture_body', False):
            try:
                if request.content_type == 'application/json':
                    import json
                    request_body = json.loads(request.body)
                else:
                    request_body = request.body.decode('utf-8', errors='ignore')
            except:
                pass

        try:
            response = self.get_response(request)
            
            duration_ms = int((time.time() - start_time) * 1000)
            
            # Construct options from dict if it was provided as dict in settings
            track_options = TrackOptions(**self.options) if isinstance(self.options, dict) else self.options

            capture_webhook_event(
                options=track_options,
                request_headers=request_headers,
                request_body=request_body,
                status_code=response.status_code,
                duration_ms=duration_ms,
                source_url=request.build_absolute_uri()
            )
            
            return response
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            track_options = TrackOptions(**self.options) if isinstance(self.options, dict) else self.options
            
            capture_webhook_event(
                options=track_options,
                request_headers=request_headers,
                request_body=request_body,
                status_code=500,
                duration_ms=duration_ms,
                error_message=str(e),
                source_url=request.build_absolute_uri()
            )
            raise e
