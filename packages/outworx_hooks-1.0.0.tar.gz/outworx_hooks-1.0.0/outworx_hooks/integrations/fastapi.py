import time
from typing import Optional
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from ..core import capture_webhook_event
from ..types import TrackOptions

class OutworxHooksMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, options: TrackOptions):
        super().__init__(app)
        self.options = options

    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        
        # Capture request info
        request_headers = dict(request.headers)
        request_body = None
        
        capture_body = self.options.capture_body
        
        # To avoid consuming the stream, we might need to handle this carefully
        # However, for simplicity in the first version, we'll try to read it
        # if capture_body is enabled. Note: this might cause issues with some apps.
        if capture_body:
            try:
                body_bytes = await request.body()
                try:
                    request_body = await request.json()
                except:
                    request_body = body_bytes.decode('utf-8', errors='ignore')
                
                # We need to re-wrap the request so the app can read it again
                # But BaseHTTPMiddleware is notoriously hard to do this with.
                # A better approach for production SDKs is usually a custom middleware 
                # that doesn't use BaseHTTPMiddleware, OR just documentation to use
                # the monitoring decorator on specific routes.
            except:
                pass

        try:
            response: Response = await call_next(request)
            
            duration_ms = int((time.time() - start_time) * 1000)
            
            # Optionally capture response body
            response_body = None
            if capture_body:
                # Intercepting response body in BaseHTTPMiddleware is also complex
                # as it returns a streaming response.
                pass

            capture_webhook_event(
                options=self.options,
                request_headers=request_headers,
                request_body=request_body,
                status_code=response.status_code,
                duration_ms=duration_ms,
                response_body=response_body,
                source_url=str(request.url)
            )
            
            return response
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            capture_webhook_event(
                options=self.options,
                request_headers=request_headers,
                request_body=request_body,
                status_code=500,
                duration_ms=duration_ms,
                error_message=str(e),
                source_url=str(request.url)
            )
            raise e
