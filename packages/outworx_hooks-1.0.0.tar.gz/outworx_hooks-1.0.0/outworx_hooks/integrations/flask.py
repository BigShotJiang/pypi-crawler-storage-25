import time
import functools
from flask import request, g
from ..core import capture_webhook_event
from ..types import TrackOptions

def with_webhook_monitoring(options: TrackOptions):
    def decorator(f):
        @functools.wraps(f)
        def decorated_function(*args, **kwargs):
            start_time = time.time()
            
            # Flask makes it easy to read headers and body
            request_headers = dict(request.headers)
            request_body = None
            
            if options.capture_body:
                try:
                    request_body = request.get_json(silent=True) or request.get_data(as_text=True)
                except:
                    pass

            try:
                response = f(*args, **kwargs)
                
                duration_ms = int((time.time() - start_time) * 1000)
                
                # Check if it's a tuple (response, status_code, ...)
                status_code = 200
                if isinstance(response, tuple):
                    if len(response) > 1:
                        status_code = response[1]
                elif hasattr(response, 'status_code'):
                    status_code = response.status_code

                response_body = None
                if options.capture_body and hasattr(response, 'get_data'):
                    try:
                        response_body = response.get_data(as_text=True)
                    except:
                        pass

                capture_webhook_event(
                    options=options,
                    request_headers=request_headers,
                    request_body=request_body,
                    status_code=status_code,
                    duration_ms=duration_ms,
                    response_body=response_body,
                    source_url=request.url
                )
                
                return response
            except Exception as e:
                duration_ms = int((time.time() - start_time) * 1000)
                capture_webhook_event(
                    options=options,
                    request_headers=request_headers,
                    request_body=request_body,
                    status_code=500,
                    duration_ms=duration_ms,
                    error_message=str(e),
                    source_url=request.url
                )
                raise e
        return decorated_function
    return decorator
