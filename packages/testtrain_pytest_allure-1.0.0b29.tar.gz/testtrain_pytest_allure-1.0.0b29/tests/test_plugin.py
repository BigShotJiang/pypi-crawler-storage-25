"""Tests for the testtrain-pytest-allure plugin using pytester."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest


class ParameterStub:
    def __init__(self, name, value, mode=None):
        self.name = name
        self.value = value
        self.mode = mode


# ---------------------------------------------------------------------------
# ⚡ Unit tests for internal helpers
# ---------------------------------------------------------------------------


def test_ms_to_iso_converts_correctly():
    """⚡ _ms_to_iso converts millisecond timestamps to ISO-8601 UTC strings."""
    from testtrain_pytest_allure.plugin import _ms_to_iso

    result = _ms_to_iso(0)
    assert result == "1970-01-01T00:00:00.000Z"

    result = _ms_to_iso(1_000)
    assert result == "1970-01-01T00:00:01.000Z"


def test_ms_to_iso_returns_none_for_none():
    """⚡ _ms_to_iso returns None when given None."""
    from testtrain_pytest_allure.plugin import _ms_to_iso

    assert _ms_to_iso(None) is None


def test_map_parameters_basic():
    """⚡ _map_parameters maps name/value pairs to dicts."""
    from testtrain_pytest_allure.plugin import _map_parameters

    result = _map_parameters(
        [ParameterStub("browser", "chrome"), ParameterStub("os", "linux")]
    )
    assert result == [
        {"name": "browser", "value": "chrome"},
        {"name": "os", "value": "linux"},
    ]


def test_map_parameters_with_masked_mode():
    """⚡ _map_parameters preserves the 'masked' mode on parameters."""
    from testtrain_pytest_allure.plugin import _map_parameters

    result = _map_parameters([ParameterStub("password", "secret", mode="masked")])
    assert result == [{"name": "password", "value": "secret", "mode": "masked"}]


def test_map_parameters_empty_returns_none():
    """⚡ _map_parameters returns None for an empty list."""
    from testtrain_pytest_allure.plugin import _map_parameters

    assert _map_parameters([]) is None


def test_status_mapping():
    """⚡ Allure statuses are correctly mapped to Testtrain states."""
    from testtrain_pytest_allure.plugin import _STATUS_MAP

    assert _STATUS_MAP["passed"] == "passed"
    assert _STATUS_MAP["failed"] == "failed"
    assert _STATUS_MAP["broken"] == "failed"
    assert _STATUS_MAP["skipped"] == "skipped"
    assert _STATUS_MAP[None] == "failed"


def test_map_result_basic():
    """⚡ _map_result maps a basic passed TestResult to the Testtrain payload schema."""
    from allure_commons.model2 import Label, Status, TestResult

    from testtrain_pytest_allure.plugin import _map_result

    r = TestResult()
    r.name = "test_login"
    r.fullName = "tests.test_auth#test_login"
    r.labels = [Label(name="package", value="tests.test_auth")]
    r.status = Status.PASSED
    r.start = 0
    r.stop = 1000

    item = _map_result(r, run_id="abc-123", attachments_store={})

    assert item["testrunId"] == "abc-123"
    assert item["name"] == "test_login"
    assert item["nodeId"] == "tests/test_auth.py::test_login"
    assert item["state"] == "passed"
    assert item["duration"] == 1000
    assert item["startedAt"] == "1970-01-01T00:00:00.000Z"
    assert item["finishedAt"] == "1970-01-01T00:00:01.000Z"


def test_map_result_builds_class_based_pytest_node_id():
    """⚡ _map_result reconstructs pytest nodeids for class-based tests."""
    from allure_commons.model2 import Label, Status, TestResult

    from testtrain_pytest_allure.plugin import _map_result

    r = TestResult()
    r.name = "Human title"
    r.fullName = (
        "tests.aircraft.bla.create.create_test.TestCreateBla#test_bla_more_than_30"
    )
    r.labels = [
        Label(name="package", value="tests.aircraft.bla.create.create_test"),
        Label(name="subSuite", value="TestCreateBla"),
    ]
    r.status = Status.PASSED

    item = _map_result(r, run_id="abc-123", attachments_store={})

    assert (
        item["nodeId"]
        == "tests/aircraft/bla/create/create_test.py::TestCreateBla::test_bla_more_than_30"
    )


def test_map_result_supports_legacy_dotted_full_name():
    """⚡ _map_result still normalizes dotted fullName variants when package is known."""
    from allure_commons.model2 import Label, Status, TestResult

    from testtrain_pytest_allure.plugin import _map_result

    r = TestResult()
    r.name = "test_login"
    r.fullName = "tests.test_auth.test_login"
    r.labels = [Label(name="package", value="tests.test_auth")]
    r.status = Status.PASSED

    item = _map_result(r, run_id="abc-123", attachments_store={})

    assert item["nodeId"] == "tests/test_auth.py::test_login"


def test_map_result_adds_parameter_suffix_to_node_id():
    """⚡ _map_result appends parametrization data to nodeId when needed."""
    from allure_commons.model2 import Label, Status, TestResult

    from testtrain_pytest_allure.plugin import _map_result

    r = TestResult()
    r.name = "test_parametrized"
    r.fullName = "tests.test_auth#test_parametrized"
    # Simulate pytest setting the canonical nodeid via label
    r.labels = [
        Label(name="package", value="tests.test_auth"),
        Label(
            name="pytest_nodeid",
            value="tests/test_auth.py::test_parametrized[value=42]",
        ),
    ]
    r.status = Status.PASSED

    item = _map_result(r, run_id="abc-123", attachments_store={})

    assert item["nodeId"] == "tests/test_auth.py::test_parametrized[value=42]"


def test_map_result_adds_parameter_suffix_for_multiple_parameters():
    """⚡ _map_result preserves a provided multi-parameter pytest_nodeid unchanged."""
    from allure_commons.model2 import Label, Status, TestResult

    from testtrain_pytest_allure.plugin import _map_result

    r = TestResult()
    r.name = "test_parametrized"
    r.fullName = "tests.test_auth#test_parametrized"
    r.labels = [
        Label(name="package", value="tests.test_auth"),
        Label(
            name="pytest_nodeid", value="tests/test_auth.py::test_parametrized[x=1,y=2]"
        ),
    ]
    r.status = Status.PASSED

    item = _map_result(r, run_id="abc-123", attachments_store={})

    assert item["nodeId"] == "tests/test_auth.py::test_parametrized[x=1,y=2]"


def test_map_result_does_not_duplicate_existing_parameter_suffix():
    """⚡ _map_result keeps existing parameterized pytest nodeids unchanged."""
    from allure_commons.model2 import Label, Status, TestResult

    from testtrain_pytest_allure.plugin import _map_result

    r = TestResult()
    r.name = "test_parametrized[value=42]"
    r.fullName = "tests.test_auth.py::test_parametrized[value=42]"
    r.labels = [
        Label(name="package", value="tests.test_auth"),
        Label(
            name="pytest_nodeid",
            value="tests/test_auth.py::test_parametrized[value=42]",
        ),
    ]
    r.status = Status.PASSED

    item = _map_result(r, run_id="abc-123", attachments_store={})

    assert item["nodeId"] == "tests/test_auth.py::test_parametrized[value=42]"


def test_map_result_broken_maps_to_failed():
    """⚡ _map_result maps allure 'broken' status to Testtrain 'failed' state."""
    from allure_commons.model2 import Status, TestResult

    from testtrain_pytest_allure.plugin import _map_result

    r = TestResult()
    r.name = "test_broken"
    r.status = Status.BROKEN

    item = _map_result(r, run_id="abc-123", attachments_store={})
    assert item["state"] == "failed"


def test_map_result_includes_output_from_status_details():
    """⚡ _map_result includes failure message and trace in output field."""
    from allure_commons.model2 import Status, StatusDetails, TestResult

    from testtrain_pytest_allure.plugin import _map_result

    r = TestResult()
    r.name = "test_fail"
    r.status = Status.FAILED
    r.statusDetails = StatusDetails(
        message="AssertionError: expected True", trace="Traceback..."
    )

    item = _map_result(r, run_id="abc-123", attachments_store={})
    assert "AssertionError: expected True" in item["output"]
    assert "Traceback..." in item["output"]


def test_map_result_includes_defects_from_issue_links():
    """⚡ _map_result maps allure 'issue' links to defects."""
    from allure_commons.model2 import Link, Status, TestResult

    from testtrain_pytest_allure.plugin import _map_result

    r = TestResult()
    r.name = "test_defect"
    r.status = Status.FAILED
    r.links = [Link(type="issue", url="https://jira.example.com/PROJ-1", name="PROJ-1")]

    item = _map_result(r, run_id="abc-123", attachments_store={})
    assert item["defects"] == [
        {"url": "https://jira.example.com/PROJ-1", "name": "PROJ-1"}
    ]


def test_map_result_includes_defect_without_name():
    """⚡ _map_result maps allure 'issue' links without name as url-only defects."""
    from allure_commons.model2 import Link, Status, TestResult

    from testtrain_pytest_allure.plugin import _map_result

    r = TestResult()
    r.name = "test_defect_url_only"
    r.status = Status.FAILED
    r.links = [Link(type="issue", url="https://jira.example.com/PROJ-3")]

    item = _map_result(r, run_id="abc-123", attachments_store={})
    assert item["defects"] == [{"url": "https://jira.example.com/PROJ-3"}]


def test_map_result_skips_issue_links_without_url():
    """⚡ _map_result skips allure 'issue' links that have no URL."""
    from allure_commons.model2 import Link, Status, TestResult

    from testtrain_pytest_allure.plugin import _map_result

    r = TestResult()
    r.name = "test_defect_no_url"
    r.status = Status.FAILED
    r.links = [Link(type="issue", name="PROJ-2")]

    item = _map_result(r, run_id="abc-123", attachments_store={})
    assert "defects" not in item


def test_map_result_includes_non_issue_links_in_test_links():
    """⚡ _map_result maps non-issue links into generic test links."""
    from allure_commons.model2 import Link, Status, TestResult

    from testtrain_pytest_allure.plugin import _map_result

    r = TestResult()
    r.name = "test"
    r.status = Status.PASSED
    r.links = [
        Link(type="link", url="https://docs.example.com", name="Docs"),
        Link(type="defect", url="https://jira.example.com/BUG-1", name="BUG-1"),
    ]

    item = _map_result(r, run_id="abc-123", attachments_store={})
    assert "defects" not in item
    assert item["links"] == [
        "https://docs.example.com",
        "https://jira.example.com/BUG-1",
    ]


def test_map_result_keeps_issue_links_out_of_test_links():
    """⚡ _map_result does not duplicate issue links into generic test links."""
    from allure_commons.model2 import Link, Status, TestResult

    from testtrain_pytest_allure.plugin import _map_result

    r = TestResult()
    r.name = "test"
    r.status = Status.FAILED
    r.links = [
        Link(type="issue", url="https://jira.example.com/PROJ-1", name="PROJ-1"),
        Link(type="link", url="https://docs.example.com", name="Docs"),
    ]

    item = _map_result(r, run_id="abc-123", attachments_store={})
    assert item["defects"] == [
        {"url": "https://jira.example.com/PROJ-1", "name": "PROJ-1"}
    ]
    assert item["links"] == ["https://docs.example.com"]


def test_map_result_deduplicates_non_issue_links():
    """⚡ _map_result deduplicates repeated non-issue links while preserving order."""
    from allure_commons.model2 import Link, Status, TestResult

    from testtrain_pytest_allure.plugin import _map_result

    r = TestResult()
    r.name = "test"
    r.status = Status.PASSED
    r.links = [
        Link(type="link", url="https://docs.example.com", name="Docs"),
        Link(type="link", url="https://docs.example.com", name="Docs again"),
        Link(type="tms", url="https://cases.example.com/TC-1", name="TC-1"),
    ]

    item = _map_result(r, run_id="abc-123", attachments_store={})
    assert item["links"] == [
        "https://docs.example.com",
        "https://cases.example.com/TC-1",
    ]


def test_map_result_includes_allure_tags():
    """⚡ _map_result maps allure tag labels to Testtrain tags."""
    from allure_commons.model2 import Label, Status, TestResult

    from testtrain_pytest_allure.plugin import _map_result

    r = TestResult()
    r.name = "test_tags"
    r.status = Status.PASSED
    r.labels = [
        Label(name="tag", value="smoke"),
        Label(name="tag", value="api"),
        Label(name="tag", value="smoke"),
    ]

    item = _map_result(r, run_id="abc-123", attachments_store={})
    assert item["tags"] == ["smoke", "api"]


def test_collect_all_attachment_refs_recursive():
    """⚡ _collect_all_attachment_refs traverses nested steps to collect all refs."""
    from testtrain_pytest_allure.plugin import _collect_all_attachment_refs

    payload = {
        "name": "test",
        "attachments": [{"field": "att1"}],
        "steps": [
            {
                "name": "step1",
                "attachments": [{"field": "att2"}],
                "steps": [{"name": "nested", "attachments": [{"field": "att3"}]}],
            }
        ],
    }
    refs = _collect_all_attachment_refs(payload)
    fields = [r["field"] for r in refs]
    assert "att1" in fields
    assert "att2" in fields
    assert "att3" in fields


# ---------------------------------------------------------------------------
# 🧪 Integration tests using pytester
# ---------------------------------------------------------------------------


pytest_plugins = ["pytester"]


def _make_test_file(state: str = "pass") -> str:
    """Generate a test file that passes or fails."""
    if state == "pass":
        return "def test_example(): assert True"
    elif state == "fail":
        return "def test_example(): assert False"
    elif state == "skip":
        return "import pytest\ndef test_example(): pytest.skip('skipped')"
    return "def test_example(): assert True"


def _fake_response(status_code: int = 202, json_data: dict | None = None) -> MagicMock:
    mock = MagicMock()
    mock.status_code = status_code
    mock.text = json.dumps(json_data or {"message": "Queued"})
    mock.json.return_value = json_data or {"message": "Queued"}
    return mock


def test_plugin_does_not_activate_without_options(pytester):
    """🧪 Plugin is a no-op when no --testtrain-* options are given."""
    pytester.makepyfile(_make_test_file("pass"))
    result = pytester.runpytest()
    result.assert_outcomes(passed=1)


def test_plugin_sends_passed_result(pytester):
    """🧪 Plugin sends a passed test result to the Testtrain API."""
    pytester.makepyfile(
        """
        import allure

        @allure.title("Login test")
        def test_login():
            with allure.step("Open browser"):
                pass
            assert True
        """
    )

    with patch("testtrain_pytest_allure.plugin.requests.post") as mock_post:
        mock_post.return_value = _fake_response(202)
        result = pytester.runpytest(
            "--alluredir=allure-results",
            "--testtrain-url=http://localhost:3000",
            "--testtrain-auth-token=token123",
            "--testtrain-run-id=00000000-0000-0000-0000-000000000001",
        )

    result.assert_outcomes(passed=1)
    mock_post.assert_called_once()
    call_kwargs = mock_post.call_args

    # Should have sent JSON (no attachments)
    assert call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
    sent = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
    assert sent["tests"][0]["state"] == "passed"
    assert sent["tests"][0]["testrunId"] == "00000000-0000-0000-0000-000000000001"


def test_plugin_sends_failed_result(pytester):
    """🧪 Plugin sends a failed test result to the Testtrain API."""
    pytester.makepyfile("def test_fail(): assert False, 'intentional failure'")

    with patch("testtrain_pytest_allure.plugin.requests.post") as mock_post:
        mock_post.return_value = _fake_response(202)
        result = pytester.runpytest(
            "--alluredir=allure-results",
            "--testtrain-url=http://localhost:3000",
            "--testtrain-auth-token=token123",
            "--testtrain-run-id=00000000-0000-0000-0000-000000000001",
        )

    result.assert_outcomes(failed=1)
    sent = mock_post.call_args.kwargs.get("json") or mock_post.call_args[1].get("json")
    assert sent["tests"][0]["state"] == "failed"


def test_plugin_sends_skipped_result(pytester):
    """🧪 Plugin sends a skipped test result to the Testtrain API."""
    pytester.makepyfile(
        """
        import pytest
        def test_skip():
            pytest.skip("not implemented yet")
        """
    )

    with patch("testtrain_pytest_allure.plugin.requests.post") as mock_post:
        mock_post.return_value = _fake_response(202)
        result = pytester.runpytest(
            "--alluredir=allure-results",
            "--testtrain-url=http://localhost:3000",
            "--testtrain-auth-token=token123",
            "--testtrain-run-id=00000000-0000-0000-0000-000000000001",
        )

    result.assert_outcomes(skipped=1)
    sent = mock_post.call_args.kwargs.get("json") or mock_post.call_args[1].get("json")
    assert sent["tests"][0]["state"] == "skipped"


def test_plugin_retries_on_server_error(pytester):
    """🧪 Plugin retries up to MAX_RETRIES times on 5xx responses."""
    pytester.makepyfile("def test_example(): assert True")

    responses = [_fake_response(500), _fake_response(500), _fake_response(202)]

    with patch("testtrain_pytest_allure.plugin.requests.post", side_effect=responses):
        with patch("testtrain_pytest_allure.plugin.time.sleep"):
            result = pytester.runpytest(
                "--alluredir=allure-results",
                "--testtrain-url=http://localhost:3000",
                "--testtrain-auth-token=token123",
                "--testtrain-run-id=00000000-0000-0000-0000-000000000001",
            )

    # Session should succeed (third attempt worked)
    result.assert_outcomes(passed=1)


def test_plugin_stops_session_after_all_retries_fail(pytester):
    """🧪 Plugin stops the test session after all retries are exhausted."""
    pytester.makepyfile(
        """
        def test_first(): assert True
        def test_second(): assert True
        def test_third(): assert True
        """
    )

    with patch(
        "testtrain_pytest_allure.plugin.requests.post",
        return_value=_fake_response(500),
    ):
        with patch("testtrain_pytest_allure.plugin.time.sleep"):
            result = pytester.runpytest(
                "--alluredir=allure-results",
                "--testtrain-url=http://localhost:3000",
                "--testtrain-auth-token=token123",
                "--testtrain-run-id=00000000-0000-0000-0000-000000000001",
            )

    # Session should have been aborted — not all 3 tests ran
    assert result.ret != 0


def test_plugin_stops_session_gracefully_with_xdist(pytester):
    """🧪 Plugin aborts cleanly under xdist after a send failure."""
    pytest.importorskip("xdist")

    pytester.makeconftest(
        """
        import requests

        def pytest_configure(config):
            class Resp:
                status_code = 500
                text = "server error"

            def fake_post(*args, **kwargs):
                return Resp()

            requests.post = fake_post
        """
    )
    pytester.makepyfile(
        """
        def test_first(): assert True
        def test_second(): assert True
        def test_third(): assert True
        """
    )

    result = pytester.runpytest(
        "-n",
        "2",
        "--alluredir=allure-results",
        "--testtrain-url=http://localhost:3000",
        "--testtrain-auth-token=token123",
        "--testtrain-run-id=00000000-0000-0000-0000-000000000001",
    )

    assert result.ret != 0
    assert result.ret != 3
    assert "INTERNALERROR" not in result.stdout.str()


def test_plugin_does_not_retry_on_4xx(pytester):
    """🧪 Plugin does not retry on 4xx client errors."""
    pytester.makepyfile("def test_example(): assert True")

    with patch(
        "testtrain_pytest_allure.plugin.requests.post",
        return_value=_fake_response(401),
    ) as mock_post:
        with patch("testtrain_pytest_allure.plugin.time.sleep") as mock_sleep:
            pytester.runpytest(
                "--alluredir=allure-results",
                "--testtrain-url=http://localhost:3000",
                "--testtrain-auth-token=bad-token",
                "--testtrain-run-id=00000000-0000-0000-0000-000000000001",
            )

    assert mock_post.call_count == 1
    mock_sleep.assert_not_called()


def test_send_with_retries_returns_4xx_failure_detail():
    """⚡ _send_with_retries returns the last 4xx response detail."""
    from testtrain_pytest_allure.plugin import _send_with_retries

    with patch(
        "testtrain_pytest_allure.plugin.requests.post",
        return_value=_fake_response(401, {"error": "bad token"}),
    ):
        ok, detail = _send_with_retries(
            "http://localhost:3000",
            "bad-token",
            {"name": "test"},
            {},
            {},
        )

    assert ok is False
    assert detail is not None
    assert "HTTP 401" in detail


def test_send_with_retries_returns_network_failure_detail():
    """⚡ _send_with_retries returns the last network exception detail."""
    from requests import ConnectionError

    from testtrain_pytest_allure.plugin import _send_with_retries

    with patch(
        "testtrain_pytest_allure.plugin.requests.post",
        side_effect=ConnectionError("connection reset"),
    ):
        with patch("testtrain_pytest_allure.plugin.time.sleep"):
            ok, detail = _send_with_retries(
                "http://localhost:3000",
                "token123",
                {"name": "test"},
                {},
                {},
            )

    assert ok is False
    assert detail == "ConnectionError: connection reset"


def test_plugin_includes_allure_steps(pytester):
    """🧪 Plugin maps allure steps into the Testtrain payload."""
    pytester.makepyfile(
        """
        import allure

        def test_with_steps():
            with allure.step("Step one"):
                pass
            with allure.step("Step two"):
                pass
        """
    )

    with patch("testtrain_pytest_allure.plugin.requests.post") as mock_post:
        mock_post.return_value = _fake_response(202)
        result = pytester.runpytest(
            "--alluredir=allure-results",
            "--testtrain-url=http://localhost:3000",
            "--testtrain-auth-token=token123",
            "--testtrain-run-id=00000000-0000-0000-0000-000000000001",
        )

    result.assert_outcomes(passed=1)
    sent = mock_post.call_args.kwargs.get("json") or mock_post.call_args[1].get("json")
    steps = sent["tests"][0].get("steps", [])
    assert len(steps) == 2
    assert steps[0]["name"] == "Step one"
    assert steps[1]["name"] == "Step two"


def test_plugin_includes_allure_parameters(pytester):
    """🧪 Plugin maps pytest parametrize values into the Testtrain payload."""
    pytester.makepyfile(
        """
        import pytest

        @pytest.mark.parametrize("value", [42])
        def test_parametrized(value):
            assert value == 42
        """
    )

    with patch("testtrain_pytest_allure.plugin.requests.post") as mock_post:
        mock_post.return_value = _fake_response(202)
        result = pytester.runpytest(
            "--alluredir=allure-results",
            "--testtrain-url=http://localhost:3000",
            "--testtrain-auth-token=token123",
            "--testtrain-run-id=00000000-0000-0000-0000-000000000001",
        )

    result.assert_outcomes(passed=1)
    sent = mock_post.call_args.kwargs.get("json") or mock_post.call_args[1].get("json")
    params = sent["tests"][0].get("parameters", [])
    assert any(p["name"] == "value" and p["value"] == "42" for p in params)


def test_plugin_includes_allure_tags(pytester):
    """🧪 Plugin maps allure tags into the Testtrain payload."""
    pytester.makepyfile(
        """
        import allure

        @allure.tag("smoke", "payments")
        def test_with_tags():
            allure.dynamic.tag("critical")
            assert True
        """
    )

    with patch("testtrain_pytest_allure.plugin.requests.post") as mock_post:
        mock_post.return_value = _fake_response(202)
        result = pytester.runpytest(
            "--alluredir=allure-results",
            "--testtrain-url=http://localhost:3000",
            "--testtrain-auth-token=token123",
            "--testtrain-run-id=00000000-0000-0000-0000-000000000001",
        )

    result.assert_outcomes(passed=1)
    sent = mock_post.call_args.kwargs.get("json") or mock_post.call_args[1].get("json")
    assert set(sent["tests"][0].get("tags", [])) == {"smoke", "payments", "critical"}


def test_plugin_parametrized_cases_have_distinct_node_ids(pytester):
    """🧪 Parametrized test cases are reported as separate tests, not retries."""
    pytester.makepyfile(
        """
        import pytest

        @pytest.mark.parametrize("value", [1, 2])
        def test_parametrized(value):
            assert value in (1, 2)
        """
    )

    with patch("testtrain_pytest_allure.plugin.requests.post") as mock_post:
        mock_post.return_value = _fake_response(202)
        result = pytester.runpytest(
            "--alluredir=allure-results",
            "--testtrain-url=http://localhost:3000",
            "--testtrain-auth-token=token123",
            "--testtrain-run-id=00000000-0000-0000-0000-000000000001",
        )

    result.assert_outcomes(passed=2)
    assert mock_post.call_count == 2

    payloads = [
        call.kwargs.get("json") or call[2].get("json")
        for call in mock_post.call_args_list
    ]
    node_ids = [payload["tests"][0]["nodeId"] for payload in payloads]
    assert {node_id.split("::", 1)[1] for node_id in node_ids} == {
        "test_parametrized[1]",
        "test_parametrized[2]",
    }


def test_plugin_sends_attachment_via_multipart(pytester):
    """🧪 Plugin sends inline attachments as multipart form-data."""
    pytester.makepyfile(
        """
        import allure

        def test_with_attachment():
            allure.attach(
                "hello logs",
                name="test.log",
                attachment_type=allure.attachment_type.TEXT,
            )
        """
    )

    with patch("testtrain_pytest_allure.plugin.requests.post") as mock_post:
        mock_post.return_value = _fake_response(202)
        result = pytester.runpytest(
            "--alluredir=allure-results",
            "--testtrain-url=http://localhost:3000",
            "--testtrain-auth-token=token123",
            "--testtrain-run-id=00000000-0000-0000-0000-000000000001",
        )

    result.assert_outcomes(passed=1)
    mock_post.assert_called_once()

    # Multipart call uses 'files=' not 'json='
    call_kwargs = mock_post.call_args
    files = call_kwargs.kwargs.get("files") or call_kwargs[1].get("files")
    assert files is not None, "Expected multipart upload but got JSON request"

    # The 'meta' part should be present
    field_names = [f[0] for f in files]
    assert "meta" in field_names
