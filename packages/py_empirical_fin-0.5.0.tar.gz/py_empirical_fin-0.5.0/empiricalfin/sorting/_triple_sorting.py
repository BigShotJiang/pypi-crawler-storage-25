from ._utils import ew_ret, vw_ret, remove_items, decimal, asterisk, qcut_with_exception
from ._renders import HtmlRenderer, DocxRenderer
from ._double_sorting import MainTable, StrategyTable

import pandas as pd
import numpy as np
import statsmodels.api as sm

from IPython.display import display, HTML


def nw_ttest(df, ret, maxlags, model_cols=[]):
    '''
    newey-west robust t test
    '''
    res_dict = {}

    dependent = df[ret]

    if model_cols:
        independent = sm.add_constant(df[model_cols])
    else:
        independent = pd.Series(np.ones_like(dependent),
                                index=dependent.index, name="const")

    ols_model = sm.OLS(dependent, independent, missing="drop")

    if not maxlags:
        T = ols_model.nobs
        maxlags = int(4 * ((T / 100) ** (2 / 9)))

    reg_res = ols_model.fit(cov_type="HAC",
                            cov_kwds={'maxlags': maxlags}, kernel="bartlett")

    res_dict["mean"] = reg_res.params["const"]
    res_dict["tstats"] = reg_res.tvalues["const"]
    res_dict["pvalue"] = reg_res.pvalues["const"]

    return pd.Series(res_dict)


# sorting approach
class TripleSorting(object):
    def __init__(self, data, sortbys, nqs, date, ret, mkt_cap):
        """
        Three-variable sequential portfolio sorting.

        Parameters
        ----------
        data : pd.DataFrame
            Panel data with at least the columns for sortbys, ret, mkt_cap, and date.
        sortbys : list of str, length 3
            Names of the three sorting variables, e.g. ["X", "Y", "Z"].
            Sorting order: X first, then Y conditional on X, then Z conditional on X and Y.
        nqs : list, length 3
            Number of quantile groups (int) or explicit breakpoints (list) for each variable,
            e.g. [3, 5, 5].
        date : str
            Name of the date column.
        ret : str
            Name of the return column.
        mkt_cap : str
            Name of the market-cap column (used for value-weighted returns).
        """
        self.sortbys = sortbys
        self.nqs = nqs

        self.date = date
        self.ret = ret
        self.mkt_cap = mkt_cap

        columns = sortbys + [mkt_cap]
        self.data = data.dropna(subset=columns)
        self.data = self.data.reset_index(drop=True)

        self.data.index.name = "index"
        self.q_ret_name = "q_ret"

    def sorting(self, groupby, sortby, nq):
        # the smaller the label, the smaller the quantile
        n_groups = nq if isinstance(nq, int) else len(nq) - 1
        labels = list(range(1, n_groups + 1))

        groups = self.data.groupby(groupby, observed=False)
        quantiles = groups[sortby].apply(lambda x: qcut_with_exception(x, q=nq, labels=labels))

        quantiles = quantiles.reset_index(level=-1)
        quantiles = quantiles.reset_index(drop=True).set_index("index")
        return quantiles

    def quantile_return(self, groupby, vw):
        if vw:
            ret_func = vw_ret
        else:
            ret_func = ew_ret

        groups = self.data.groupby(groupby, observed=False)
        quantile_ret = groups.apply(lambda x: ret_func(data=x,
                                                       ret_col=self.ret,
                                                       mkt_cap_col=self.mkt_cap))
        quantile_ret.name = self.q_ret_name
        quantile_ret = quantile_ret.reset_index()
        return quantile_ret

    def sequential(self, vw=False):
        """
        Sequential three-variable sorting: X → Y → Z.

        Step 1: Sort by X within each date group.
        Step 2: Sort by Y within each (date, X-group) cell.
        Step 3: Sort by Z within each (date, X-group, Y-group) cell.
        Step 4: Compute portfolio returns for each (date, X-group, Y-group, Z-group) cell.

        Parameters
        ----------
        vw : bool, default False
            If True, use value-weighted returns; otherwise equal-weighted.

        Returns
        -------
        TripleSortingResults
        """
        sortby1, sortby2, sortby3 = self.sortbys
        name1 = sortby1 + "_q"
        name2 = sortby2 + "_q"
        name3 = sortby3 + "_q"
        nq1, nq2, nq3 = self.nqs

        groupby = [self.date]

        # sorting by variable 1
        self.data[name1] = self.sorting(groupby, sortby1, nq1)
        groupby.append(name1)
        # sorting by variable 2, sequentially conditional on variable 1
        self.data[name2] = self.sorting(groupby, sortby2, nq2)
        groupby.append(name2)
        # sorting by variable 3, sequentially conditional on variables 1 and 2
        self.data[name3] = self.sorting(groupby, sortby3, nq3)
        groupby.append(name3)

        # portfolio return for each sorting group
        quantile_ret = self.quantile_return(groupby, vw=vw)
        quantile_ret = quantile_ret.rename(columns={
            name1: sortby1,
            name2: sortby2,
            name3: sortby3,
        })

        # wrap up results
        notes = [f"Sequential sorting: {sortby1} → {sortby2} → {sortby3}"]
        results = TripleSortingResults(quantile_ret, self.q_ret_name,
                                       self.date, self.sortbys, notes)
        return results


# results wrapper
class TripleSortingResults(object):
    def __init__(self, quantile_ret, qret, date, sortbys, init_notes=[]):
        """
        Parameters
        ----------
        quantile_ret : pd.DataFrame
            Columns: [date, sortby1, sortby2, sortby3, qret]
        qret : str
            Name of the portfolio return column.
        date : str
            Name of the date column.
        sortbys : list of str, length 3
            [X, Y, Z] — the three sorting variable names.
        init_notes : list of str
            Initial footnotes for all tables.
        """
        self.res = quantile_ret
        self.notes = init_notes
        self.sortbys = sortbys
        self.qret = qret
        self.date = date

        self.sortby_x = sortbys[0]
        self.sortbys_yz = sortbys[1:]          # [Y, Z]
        self.x_groups = sorted(quantile_ret[self.sortby_x].dropna().unique())

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _inline_render(self, htmls):
        container = '<div style="display:flex;">'
        for html in htmls:
            container += '<div style="margin-right: 20px;">'
            container += html
            container += '</div>'
        container += '</div>'
        return container

    def _make_table_for_x(self, x_val, rf_df, rf, alpha_models,
                          layout, strategies, raw_ret, **kwargs):
        """
        For a given X-group value, build MainTable and the two StrategyTables
        (for Y and Z) using the same classes as DoubleSorting.
        """
        subset = self.res[self.res[self.sortby_x] == x_val].copy()

        sortby_y, sortby_z = self.sortbys_yz

        main = MainTable(subset, self.qret, rf_df, rf,
                         self.date, self.sortbys_yz,
                         layout=layout, raw_ret=raw_ret, **kwargs)

        if layout == "default":
            orientation_y = "horizontal"
            orientation_z = "vertical"
        elif layout == "reverse":
            orientation_y = "vertical"
            orientation_z = "horizontal"
        else:
            raise ValueError("Valid layout parameter: 'default' or 'reverse'")

        strategy_y = StrategyTable(
            qret_df=subset, qret=self.qret, date=self.date,
            sortby_strategy=sortby_y, sortby_other=sortby_z,
            alpha_models=alpha_models,
            orientation=orientation_y, strategy=strategies[0],
            rf_df=rf_df, rf=rf, **kwargs,
        )

        strategy_z = StrategyTable(
            qret_df=subset, qret=self.qret, date=self.date,
            sortby_strategy=sortby_z, sortby_other=sortby_y,
            alpha_models=alpha_models,
            orientation=orientation_z, strategy=strategies[1],
            rf_df=rf_df, rf=rf, **kwargs,
        )

        return main, strategy_y, strategy_z

    def _html_render_for_x(self, x_val, main, strategy_y, strategy_z,
                           layout, x_notes):
        """Render one X-group block to HTML and display it."""
        # Section header
        header = (
            f'<p style="font-weight:bold; font-size:14px; margin-top:16px;">'
            f'{self.sortby_x} = {x_val}</p>'
        )
        display(HTML(header))

        main_render = HtmlRenderer(main.means, main.tstats,
                                   main.hhead, main.vhead, x_notes)
        main_html = main_render.render()

        render_y = HtmlRenderer(strategy_y.means, strategy_y.tstats,
                                strategy_y.hhead, strategy_y.vhead,
                                strategy_y.notes)
        strategy_y_html = render_y.render()

        render_z = HtmlRenderer(strategy_z.means, strategy_z.tstats,
                                strategy_z.hhead, strategy_z.vhead,
                                strategy_z.notes)
        strategy_z_html = render_z.render()

        if layout == "default":
            html1 = self._inline_render([main_html, strategy_z_html])
            html2 = strategy_y_html
        else:  # reverse
            html1 = self._inline_render([main_html, strategy_y_html])
            html2 = strategy_z_html

        display(HTML(html1))
        display(HTML(html2))

    def _docx_save(self, tables_by_x, output_path, x_notes_by_x):
        """Save all X-group tables to a single Word document."""
        from ._renders import DocxRenderer

        doc = None
        for x_val, (main, strategy_y, strategy_z) in tables_by_x.items():
            x_notes = x_notes_by_x[x_val]

            # Main table
            main_docx = DocxRenderer(main.means, main.tstats,
                                     main.hhead, main.vhead,
                                     [f"{self.sortby_x} = {x_val}"] + x_notes,
                                     doc=doc)
            doc = main_docx.render()

            # Strategy Y table
            sy_docx = DocxRenderer(strategy_y.means, strategy_y.tstats,
                                   strategy_y.hhead, strategy_y.vhead,
                                   strategy_y.notes, doc=doc)
            doc = sy_docx.render()

            # Strategy Z table
            sz_docx = DocxRenderer(strategy_z.means, strategy_z.tstats,
                                   strategy_z.hhead, strategy_z.vhead,
                                   strategy_z.notes, doc=doc)
            doc = sz_docx.render()

        doc.save(output_path)
        print(f"\n\nFile saved at {output_path}")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def summary(self, rf_df, rf, alpha_models, layout="default",
                strategies=["HML", "HML"], raw_ret=False, output_path=None,
                **kwargs):
        """
        Display triple-sorting results as one Y-Z double-sorting table per X group.

        Parameters
        ----------
        rf_df : pd.DataFrame
            DataFrame with date column and risk-free rate column.
        rf : str
            Name of the risk-free rate column in rf_df.
        alpha_models : list of pd.DataFrame
            Each DataFrame is a pricing model (e.g. FF3, CH3) with date column and factor columns.
        layout : str, default "default"
            "default" — Y on rows, Z on columns in MainTable.
            "reverse" — Z on rows, Y on columns in MainTable.
        strategies : list of str, length 2, default ["HML", "HML"]
            Strategy ("HML" or "LMH") for [Y, Z] respectively.
        raw_ret : bool, default False
            If True, show raw return in MainTable instead of excess return.
        output_path : str or None
            If provided, save all tables to a Word (.docx) file at this path.
        **kwargs
            show_t, show_stars, show_t_strategy, show_stars_strategy,
            mean_decimal, t_decimal, nw_maxlags, pct_sign, etc.
        """
        ret_note = ("The above table reports raw return"
                    if raw_ret
                    else "The above table reports excess return rather than raw return")

        tables_by_x = {}
        x_notes_by_x = {}

        for x_val in self.x_groups:
            main, strategy_y, strategy_z = self._make_table_for_x(
                x_val, rf_df, rf, alpha_models, layout, strategies, raw_ret, **kwargs
            )
            x_notes = self.notes + [ret_note]

            self._html_render_for_x(x_val, main, strategy_y, strategy_z,
                                    layout, x_notes)

            tables_by_x[x_val] = (main, strategy_y, strategy_z)
            x_notes_by_x[x_val] = x_notes

        if output_path:
            self._docx_save(tables_by_x, output_path, x_notes_by_x)
