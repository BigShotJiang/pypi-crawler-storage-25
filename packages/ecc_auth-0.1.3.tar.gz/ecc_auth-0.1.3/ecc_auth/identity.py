"""AuthIdentity：跨所有 ECC 项目统一的 claims 契约。"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class AuthIdentity:
    """从 Keycloak claims 规范化得到的用户身份。

    这是共享契约：所有 ECC 项目都将 Keycloak claims 映射到该结构。
    字段命名与身份契约文档（docs/02-identity-contract.md）保持一致。
    """

    external_auth_id: str  # 对应 Keycloak `sub`
    email: str | None
    display_name: str  # 回退顺序：name > preferred_username > email > sub
    username: str  # 回退顺序：preferred_username > email > sub
    email_verified: bool = False
    given_name: str | None = None
    family_name: str | None = None

    @classmethod
    def from_claims(cls, claims: dict) -> AuthIdentity:
        """从 Keycloak token claims 或 userinfo 构建 AuthIdentity。"""
        sub = claims["sub"]
        email = claims.get("email")
        preferred_username = claims.get("preferred_username")
        name = claims.get("name")

        # display_name 的回退链路：name > preferred_username > email > sub
        display_name = name or preferred_username or email or sub
        username = preferred_username or email or sub

        return cls(
            external_auth_id=sub,
            email=email,
            display_name=display_name,
            username=username,
            email_verified=claims.get("email_verified", False),
            given_name=claims.get("given_name"),
            family_name=claims.get("family_name"),
        )
