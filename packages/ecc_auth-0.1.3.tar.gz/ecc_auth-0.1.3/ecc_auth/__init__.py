"""ecc-auth：面向 ECC 项目的共享 Keycloak OIDC 认证 SDK。"""

from ecc_auth.config import KeycloakConfig
from ecc_auth.dependencies import (
    get_current_user,
    get_current_user_optional,
    init_dependencies,
)
from ecc_auth.identity import AuthIdentity
from ecc_auth.middleware import AuthSessionMiddleware
from ecc_auth.session import RefreshTokenHandler
from ecc_auth.routes import create_auth_router
from ecc_auth.jwks import verify_access_token

__all__ = [
    "KeycloakConfig",
    "AuthIdentity",
    "AuthSessionMiddleware",
    "create_auth_router",
    "init_dependencies",
    "get_current_user",
    "get_current_user_optional",
    "RefreshTokenHandler",
    "verify_access_token",
]
