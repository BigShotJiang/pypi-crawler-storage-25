"""供认证路由与依赖共用的会话解析辅助逻辑。"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

import httpx
import jwt
from fastapi import HTTPException

from ecc_auth.client import refresh_token as refresh_token_request
from ecc_auth.config import KeycloakConfig
from ecc_auth.identity import AuthIdentity
from ecc_auth.jwks import verify_access_token

NOT_AUTHENTICATED_DETAIL = "Not authenticated"
SESSION_EXPIRED_DETAIL = "Session expired"
LOGGED_OUT_DETAIL = "Logged out"
AUTH_UNAVAILABLE_DETAIL = "Authentication service unavailable"

RefreshTokenHandler = Callable[[KeycloakConfig, str], Awaitable[dict[str, Any]]]


@dataclass(frozen=True)
class SessionResolution:
    """认证后的身份信息，以及可选的刷新后 token 载荷。"""

    identity: AuthIdentity
    token_data: dict[str, Any] | None = None


def should_clear_token_cookies(exc: HTTPException) -> bool:
    """识别应当清理认证 Cookie 的终态认证失败。"""

    return exc.status_code == 401 and exc.detail in {
        LOGGED_OUT_DETAIL,
        SESSION_EXPIRED_DETAIL,
    }


async def resolve_identity_from_cookies(
    config: KeycloakConfig,
    *,
    access_token: str | None,
    refresh_token: str | None,
    logout_marker: str | None,
    refresh_token_handler: RefreshTokenHandler | None = None,
) -> SessionResolution:
    """使用共享的“JWKS 优先”流程解析当前身份。"""

    if logout_marker:
        raise HTTPException(status_code=401, detail=LOGGED_OUT_DETAIL)

    if not access_token and not refresh_token:
        raise HTTPException(status_code=401, detail=NOT_AUTHENTICATED_DETAIL)

    if access_token:
        try:
            claims = await verify_access_token(access_token, config)
            return SessionResolution(identity=AuthIdentity.from_claims(claims))
        except jwt.InvalidTokenError:
            pass
        except Exception as exc:
            raise HTTPException(
                status_code=503, detail=AUTH_UNAVAILABLE_DETAIL
            ) from exc

    if not refresh_token:
        raise HTTPException(status_code=401, detail=SESSION_EXPIRED_DETAIL)

    return await _resolve_via_refresh(
        config, refresh_token, refresh_token_handler=refresh_token_handler
    )


async def _resolve_via_refresh(
    config: KeycloakConfig,
    refresh_token: str,
    *,
    refresh_token_handler: RefreshTokenHandler | None = None,
) -> SessionResolution:
    token_data = await request_token_refresh(
        config,
        refresh_token,
        refresh_token_handler=refresh_token_handler,
    )
    validated_token_data = await validate_refreshed_token_data(config, token_data)

    return SessionResolution(
        identity=AuthIdentity.from_claims(validated_token_data["claims"]),
        token_data=token_data,
    )


async def validate_refreshed_token_data(
    config: KeycloakConfig,
    token_data: dict[str, Any],
) -> dict[str, Any]:
    """在持久化前校验刚刷新得到的 access token。"""

    try:
        claims = await verify_access_token(token_data["access_token"], config)
    except jwt.InvalidTokenError as exc:
        raise HTTPException(status_code=401, detail=SESSION_EXPIRED_DETAIL) from exc
    except Exception as exc:
        raise HTTPException(status_code=503, detail=AUTH_UNAVAILABLE_DETAIL) from exc

    return token_data | {"claims": claims}


async def request_token_refresh(
    config: KeycloakConfig,
    refresh_token: str,
    *,
    refresh_token_handler: RefreshTokenHandler | None = None,
) -> dict[str, Any]:
    request_refresh_token = refresh_token_handler or refresh_token_request
    try:
        return await request_refresh_token(config, refresh_token)
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code >= 500:
            raise HTTPException(
                status_code=503, detail=AUTH_UNAVAILABLE_DETAIL
            ) from exc
        raise HTTPException(status_code=401, detail=SESSION_EXPIRED_DETAIL) from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=503, detail=AUTH_UNAVAILABLE_DETAIL) from exc
    except Exception as exc:
        raise HTTPException(status_code=503, detail=AUTH_UNAVAILABLE_DETAIL) from exc
