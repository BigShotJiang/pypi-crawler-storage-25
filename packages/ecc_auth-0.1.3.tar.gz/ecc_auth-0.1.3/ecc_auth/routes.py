"""FastAPI 认证路由：一行挂载 login/callback/me/refresh/logout。"""

from __future__ import annotations

import base64
import inspect
import json
import logging
import secrets
from collections.abc import Awaitable, Callable
from typing import Any
from urllib.parse import quote, urlsplit

import httpx
from fastapi import APIRouter, Cookie, HTTPException, Request
from fastapi.responses import JSONResponse, RedirectResponse

from ecc_auth.callback_errors import (
    CALLBACK_ERROR_CSRF_MISMATCH,
    CALLBACK_ERROR_INVALID_STATE,
    CALLBACK_ERROR_MISSING_CODE,
    CALLBACK_ERROR_MISSING_PKCE,
    CALLBACK_ERROR_MISSING_STATE,
    CALLBACK_ERROR_USER_SYNC_FAILED,
    CallbackError,
    build_callback_error_response,
    classify_callback_exchange_error,
    classify_callback_verification_error,
    describe_original_error,
)
from ecc_auth.client import (
    build_authorization_url,
    exchange_code_for_token,
    fetch_user_info,
)
from ecc_auth.config import KeycloakConfig
from ecc_auth.cookies import (
    clear_logout_marker,
    clear_temporary_auth_cookies,
    clear_token_cookies,
    get_public_origin,
    is_https,
    set_logout_marker,
    set_temporary_auth_cookies,
    set_token_cookies,
)
from ecc_auth.identity import AuthIdentity
from ecc_auth.middleware import (
    apply_queued_session_cookies,
    queue_session_cookie_clear,
    queue_session_refresh,
)
from ecc_auth.session import (
    LOGGED_OUT_DETAIL,
    NOT_AUTHENTICATED_DETAIL,
    RefreshTokenHandler,
    request_token_refresh,
    resolve_identity_from_cookies,
    should_clear_token_cookies,
    validate_refreshed_token_data,
)

logger = logging.getLogger(__name__)

# 可选应用回调的类型定义
AuthCallbackResult = Awaitable[Any] | Any
OnUserAuthenticated = Callable[[AuthIdentity], AuthCallbackResult] | None
LoadCurrentUser = Callable[[AuthIdentity], AuthCallbackResult] | None


def _generate_nonce() -> str:
    """生成用于 CSRF 防护的随机 nonce。"""
    return secrets.token_urlsafe(32)


def _get_request_origin(request: Request) -> str:
    """尽力推导对外可见的应用 origin。

    在开发代理场景（如 localhost:3000）优先使用浏览器侧 Origin/Referer，
    其次回退到后端请求中的 forwarded/host 头。
    """
    for header in ("origin", "referer"):
        value = request.headers.get(header)
        if not value:
            continue
        parsed = urlsplit(value)
        if parsed.scheme in ("http", "https") and parsed.netloc:
            return f"{parsed.scheme}://{parsed.netloc}"
    return get_public_origin(request)


def _encode_auth_state(nonce: str, return_to: str, origin: str) -> str:
    """将登录 state 编码为 URL 安全的 base64 JSON 字符串。"""
    payload = json.dumps({"nonce": nonce, "return_to": return_to, "origin": origin})
    return base64.urlsafe_b64encode(payload.encode()).decode()


def _decode_auth_state(state: str) -> dict | None:
    """解码 auth state，失败或结构不符合预期时返回 None。"""
    try:
        payload = base64.urlsafe_b64decode(state.encode())
        decoded = json.loads(payload)
    except Exception:
        return None
    return decoded if isinstance(decoded, dict) else None


def _normalize_return_to(return_to: str) -> str:
    """确保 return_to 为相对路径，防止开放重定向。"""
    if not return_to or not return_to.startswith("/"):
        return "/"
    return return_to


async def _invoke_callback(
    callback: Callable[[AuthIdentity], AuthCallbackResult], identity: AuthIdentity
) -> Any:
    result = callback(identity)
    if inspect.isawaitable(result):
        return await result
    return result


async def _build_me_payload(
    identity: AuthIdentity, load_current_user: LoadCurrentUser
) -> dict[str, Any]:
    user = _identity_to_dict(identity)
    if load_current_user is not None:
        user = await _invoke_callback(load_current_user, identity)
    return {"user": user}


def create_auth_router(
    config: KeycloakConfig,
    *,
    on_user_authenticated: OnUserAuthenticated = None,
    load_current_user: LoadCurrentUser = None,
    default_return_to: str = "/",
    refresh_token_handler: RefreshTokenHandler | None = None,
) -> APIRouter:
    """创建包含标准 Keycloak OIDC 端点的 FastAPI 路由。

    会注册 5 个端点：
    - GET  /login    — 跳转到 Keycloak
    - GET  /callback — 处理 Keycloak 回调并写入 Cookie
    - GET  /me       — 返回当前用户身份
    - POST /refresh  — 刷新 access token
    - POST /logout   — 清理 Cookie 并返回 Keycloak 登出 URL

    参数：
        config: Keycloak 配置。
        on_user_authenticated: 登录成功后可选回调（携带 AuthIdentity），
            常用于用户 upsert 逻辑。
        load_current_user: /me 的可选回调，用于把 AuthIdentity 映射为
            应用自定义用户 DTO。
        default_return_to: 登录后默认跳转路径。
        refresh_token_handler: 可选的 refresh token 传输实现覆盖，
            适用于需要重试或埋点的应用场景。
    """
    router = APIRouter(tags=["auth"])

    @router.get("/login")
    async def login(
        request: Request,
        return_to: str | None = None,
    ) -> RedirectResponse:
        """使用 Authlib 发现机制 + PKCE 发起 Keycloak 登录流程。"""
        resolved_return_to = _normalize_return_to(return_to or default_return_to)
        nonce = _generate_nonce()
        app_origin = _get_request_origin(request)
        state = _encode_auth_state(
            nonce=nonce,
            return_to=resolved_return_to,
            origin=app_origin,
        )

        redirect_uri = f"{app_origin}/api/auth/callback"
        authorization = await build_authorization_url(
            config,
            redirect_uri=redirect_uri,
            state=state,
            nonce=nonce,
        )

        response = RedirectResponse(url=authorization["url"], status_code=302)
        set_temporary_auth_cookies(
            response,
            code_verifier=authorization["code_verifier"],
            csrf_nonce=nonce,
            secure=is_https(request),
        )
        clear_logout_marker(response, secure=is_https(request))
        logger.info("Login initiated, redirecting to Keycloak")
        return response

    @router.get("/callback")
    async def callback(
        request: Request,
        code: str | None = None,
        state: str | None = None,
        pkce_verifier: str | None = Cookie(default=None),
        csrf_nonce: str | None = Cookie(default=None),
    ) -> RedirectResponse:
        """处理 Keycloak 回调：交换授权码并写入 token Cookie。"""
        fallback_origin = get_public_origin(request)
        error_base = f"{fallback_origin}/?error="

        try:
            if not state:
                raise CallbackError(CALLBACK_ERROR_MISSING_STATE)

            state_payload = _decode_auth_state(state)
            if state_payload is None:
                raise CallbackError(CALLBACK_ERROR_INVALID_STATE)

            if not code:
                raise CallbackError(CALLBACK_ERROR_MISSING_CODE)

            if not csrf_nonce or csrf_nonce != state_payload.get("nonce"):
                raise CallbackError(CALLBACK_ERROR_CSRF_MISMATCH)

            if not pkce_verifier:
                raise CallbackError(CALLBACK_ERROR_MISSING_PKCE)

            app_origin = state_payload.get("origin") or fallback_origin
            error_base = f"{app_origin}/?error="
            secure = is_https(request)

            redirect_uri = f"{app_origin}/api/auth/callback"
            token_data = await exchange_code_for_token(
                config,
                code=code,
                redirect_uri=redirect_uri,
                code_verifier=pkce_verifier,
            )

            access_token = token_data["access_token"]
            refresh_token_value = token_data["refresh_token"]
            id_token = token_data.get("id_token", "")
            expires_in = token_data.get("expires_in", 300)
            refresh_expires_in = token_data.get("refresh_expires_in", 1800)

            # 如有配置，调用用户同步回调。这里刻意使用 Keycloak
            # /userinfo 解析身份，而不是本地 JWT 时间校验：登录 callback
            # 应由 Keycloak 判断刚签发的 token 是否可用，避免服务端本机
            # 时钟偏差把正常登录误判为 token_not_yet_valid。
            if on_user_authenticated:
                try:
                    user_info = await fetch_user_info(config, access_token)
                    identity = AuthIdentity.from_claims(user_info)
                except Exception as exc:
                    logger.exception("回调阶段通过 userinfo 校验 token 失败")
                    raise CallbackError(
                        classify_callback_verification_error(exc)
                    ) from exc

                try:
                    await _invoke_callback(on_user_authenticated, identity)
                except Exception as exc:
                    logger.exception("回调阶段同步用户失败")
                    raise CallbackError(CALLBACK_ERROR_USER_SYNC_FAILED) from exc

            return_to = _normalize_return_to(
                state_payload.get("return_to", default_return_to)
            )
            response = RedirectResponse(url=f"{app_origin}{return_to}", status_code=302)

            set_token_cookies(
                response,
                access_token=access_token,
                refresh_token=refresh_token_value,
                id_token=id_token,
                expires_in=expires_in,
                refresh_expires_in=refresh_expires_in,
                secure=secure,
            )
            clear_logout_marker(response, secure=secure)
            clear_temporary_auth_cookies(response, secure=secure)

            logger.info("Login successful")
            return response

        except CallbackError as exc:
            return build_callback_error_response(
                request,
                error_base=error_base,
                error_code=exc.error_code,
                original_error=exc.__cause__,
            )
        except Exception as exc:
            if isinstance(exc, httpx.HTTPStatusError):
                logger.exception(
                    "Token exchange failed: %s",
                    describe_original_error(exc),
                )
            elif isinstance(exc, httpx.HTTPError):
                logger.exception("Callback failed due to upstream request error")
            else:
                logger.exception("Callback failed")
            return build_callback_error_response(
                request,
                error_base=error_base,
                error_code=classify_callback_exchange_error(exc),
                original_error=exc,
            )

    @router.get("/me")
    async def me(
        request: Request,
        kc_access_token: str | None = Cookie(default=None),
        kc_refresh_token: str | None = Cookie(default=None),
        kc_logout_marker: str | None = Cookie(default=None),
    ) -> JSONResponse:
        """从 access token（JWKS 校验）返回当前用户身份。"""
        try:
            resolution = await resolve_identity_from_cookies(
                config,
                access_token=kc_access_token,
                refresh_token=kc_refresh_token,
                logout_marker=kc_logout_marker,
                refresh_token_handler=refresh_token_handler,
            )
        except HTTPException as exc:
            if should_clear_token_cookies(exc):
                queue_session_cookie_clear(request)
                response = JSONResponse(
                    {"detail": exc.detail}, status_code=exc.status_code
                )
                apply_queued_session_cookies(request, response)
                return response
            raise

        if resolution.token_data is not None:
            queue_session_refresh(request, resolution.token_data)
        response = JSONResponse(
            await _build_me_payload(resolution.identity, load_current_user)
        )
        if resolution.token_data is not None:
            apply_queued_session_cookies(request, response)
        return response

    @router.post("/refresh")
    async def refresh(
        request: Request,
        kc_refresh_token: str | None = Cookie(default=None),
        kc_logout_marker: str | None = Cookie(default=None),
    ) -> JSONResponse:
        """刷新 access token。"""
        if kc_logout_marker:
            queue_session_cookie_clear(request)
            response = JSONResponse({"detail": LOGGED_OUT_DETAIL}, status_code=401)
            apply_queued_session_cookies(request, response)
            return response

        if not kc_refresh_token:
            raise HTTPException(status_code=401, detail=NOT_AUTHENTICATED_DETAIL)

        try:
            token_data = await request_token_refresh(
                config,
                kc_refresh_token,
                refresh_token_handler=refresh_token_handler,
            )
            await validate_refreshed_token_data(config, token_data)
            response = JSONResponse({"ok": True})
            queue_session_refresh(request, token_data)
            apply_queued_session_cookies(request, response)
            return response
        except HTTPException as exc:
            if should_clear_token_cookies(exc):
                queue_session_cookie_clear(request)
                response = JSONResponse(
                    {"detail": exc.detail}, status_code=exc.status_code
                )
                apply_queued_session_cookies(request, response)
                return response
            raise

    @router.post("/logout")
    async def logout(
        request: Request,
        kc_id_token: str | None = Cookie(default=None),
    ) -> JSONResponse:
        """登出：清理 Cookie 并返回 Keycloak 登出 URL。"""
        secure = is_https(request)
        post_logout_redirect = f"{_get_request_origin(request)}/"
        logout_url = (
            f"{config.end_session_endpoint}"
            f"?post_logout_redirect_uri={quote(post_logout_redirect)}"
            f"&client_id={quote(config.client_id)}"
        )
        if kc_id_token:
            logout_url += f"&id_token_hint={kc_id_token}"

        response = JSONResponse({"logoutUrl": logout_url})
        set_logout_marker(response, secure=secure)
        clear_token_cookies(response, secure=secure)
        clear_temporary_auth_cookies(response, secure=secure)
        logger.info("Logout successful")
        return response

    return router


def _identity_to_dict(identity: AuthIdentity) -> dict:
    """将 AuthIdentity 转为可 JSON 序列化的字典。"""
    return {
        "externalAuthId": identity.external_auth_id,
        "email": identity.email,
        "displayName": identity.display_name,
        "username": identity.username,
        "emailVerified": identity.email_verified,
        "givenName": identity.given_name,
        "familyName": identity.family_name,
    }
