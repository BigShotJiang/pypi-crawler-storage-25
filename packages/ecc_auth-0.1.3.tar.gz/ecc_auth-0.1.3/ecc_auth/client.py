"""基于 Authlib 的 OIDC 客户端辅助函数。"""

from __future__ import annotations

import ssl
from typing import TYPE_CHECKING

import httpx
from authlib.integrations.starlette_client import OAuth
from authlib.integrations.starlette_client.apps import StarletteOAuth2App

if TYPE_CHECKING:
    from ecc_auth.config import KeycloakConfig


def _build_httpx_kwargs(config: "KeycloakConfig") -> dict:
    """构建 Keycloak 请求共用的 httpx 参数。

    - `trust_env=False` 可避免意外使用 shell/系统代理设置。
    - 当 KEYCLOAK_TLS_INSECURE=true 时，会放宽 `verify`，用于测试环境。
    """
    httpx_kwargs: dict = {
        "trust_env": False,
        "timeout": 20.0,
    }

    if config.tls_insecure:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        httpx_kwargs["verify"] = ctx

    return httpx_kwargs


def create_oauth(config: KeycloakConfig) -> OAuth:
    """创建一个已配置 Keycloak 参数的 Authlib OAuth 实例。

    Authlib 会通过 starlette_client 集成自动处理 PKCE、state、nonce
    以及授权码交换。

    这里刻意注册了显式 OIDC 端点，而不是在每次登录时依赖
    动态发现（`server_metadata_url`）。在当前测试环境里，发现接口
    偶发不稳定，会导致 `/api/auth/login` 在跳转到 Keycloak 之前就失败。
    """
    oauth = OAuth()
    httpx_kwargs = _build_httpx_kwargs(config)

    oauth.register(
        name="keycloak",
        client_id=config.client_id,
        client_secret=config.client_secret,
        authorize_url=config.authorization_endpoint,
        access_token_url=config.token_endpoint,
        api_base_url=config.issuer,
        client_kwargs={
            "scope": "openid profile email",
            "code_challenge_method": "S256",
            **httpx_kwargs,
        },
    )
    return oauth


def create_keycloak_client(config: KeycloakConfig) -> StarletteOAuth2App:
    """创建可复用的 Authlib Keycloak 客户端。"""
    client = create_oauth(config).create_client("keycloak")
    if client is None:
        raise RuntimeError("Failed to initialize Keycloak OAuth client")
    return client


async def build_authorization_url(
    config: KeycloakConfig,
    *,
    redirect_uri: str,
    state: str,
    nonce: str,
) -> dict:
    """通过 Authlib 发现机制 + PKCE 构建登录跳转 URL。"""
    client = create_keycloak_client(config)
    authorization = await client.create_authorization_url(
        redirect_uri=redirect_uri,
        state=state,
        nonce=nonce,
    )
    return {
        "url": authorization["url"],
        "state": authorization["state"],
        "code_verifier": authorization["code_verifier"],
    }


async def exchange_code_for_token(
    config: KeycloakConfig,
    *,
    code: str,
    redirect_uri: str,
    code_verifier: str,
) -> dict:
    """通过 Authlib 使用授权码换取 token。"""
    client = create_keycloak_client(config)
    return await client.fetch_access_token(
        redirect_uri=redirect_uri,
        code=code,
        code_verifier=code_verifier,
    )


async def fetch_user_info(config: KeycloakConfig, access_token: str) -> dict:
    """从 Keycloak userinfo 端点获取当前用户信息。

    这样 callback 阶段由 Keycloak 判断刚换回来的 token 是否可用，
    避免本服务用本机时间校验 ``iat``/``nbf``，把正常登录误判成
    token_not_yet_valid。
    """
    async with httpx.AsyncClient(**_build_httpx_kwargs(config)) as client:
        resp = await client.get(
            config.userinfo_endpoint,
            headers={"Authorization": f"Bearer {access_token}"},
        )
        resp.raise_for_status()
        return resp.json()


async def refresh_token(config: KeycloakConfig, refresh_token_value: str) -> dict:
    """通过 Keycloak 的 token 端点刷新 access token。

    Authlib 的 starlette_client 没有直接暴露 refresh 方法，
    因此这里通过 httpx 手动调用 token 端点。

    返回原始 token 响应字典，常见键包括：
    access_token、refresh_token、id_token、expires_in、refresh_expires_in 等。
    """
    async with httpx.AsyncClient(**_build_httpx_kwargs(config)) as client:
        resp = await client.post(
            config.token_endpoint,
            data={
                "grant_type": "refresh_token",
                "client_id": config.client_id,
                "client_secret": config.client_secret,
                "refresh_token": refresh_token_value,
            },
        )
        resp.raise_for_status()
        return resp.json()
