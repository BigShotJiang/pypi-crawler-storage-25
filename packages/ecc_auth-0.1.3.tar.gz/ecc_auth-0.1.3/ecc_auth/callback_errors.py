"""认证回调错误码与响应辅助函数。"""

from __future__ import annotations

import logging
import re
from urllib.parse import quote

import httpx
import jwt
from fastapi import Request
from fastapi.responses import RedirectResponse

from ecc_auth.cookies import clear_temporary_auth_cookies, is_https

logger = logging.getLogger(__name__)

CALLBACK_ERROR_MISSING_STATE = "missing_state"
CALLBACK_ERROR_INVALID_STATE = "invalid_state"
CALLBACK_ERROR_MISSING_CODE = "missing_code"
CALLBACK_ERROR_CSRF_MISMATCH = "csrf_mismatch"
CALLBACK_ERROR_MISSING_PKCE = "missing_pkce"
CALLBACK_ERROR_TOKEN_EXCHANGE_FAILED = "token_exchange_failed"
CALLBACK_ERROR_UPSTREAM_FAILED = "callback_upstream_failed"
CALLBACK_ERROR_TOKEN_NOT_YET_VALID = "token_not_yet_valid"
CALLBACK_ERROR_TOKEN_VALIDATION_FAILED = "token_validation_failed"
CALLBACK_ERROR_TOKEN_VERIFICATION_UNAVAILABLE = "token_verification_unavailable"
CALLBACK_ERROR_USER_SYNC_FAILED = "user_sync_failed"
CALLBACK_ERROR_UNKNOWN = "callback_failed"

_SENSITIVE_FIELD_PATTERN = re.compile(
    r'(?i)("?(?:access_token|refresh_token|id_token|code|state|code_verifier|pkce_verifier|client_secret)"?\s*[:=]\s*)'  # noqa: E501
    r'("[^"\s]+"|[^,\s&}]+)'
)


class CallbackError(Exception):
    """用稳定的用户可见错误码中断 callback 处理。"""

    def __init__(self, error_code: str):
        super().__init__(error_code)
        self.error_code = error_code


def _redact_sensitive_values(value: str) -> str:
    """遮蔽错误文本中可能包含的认证凭据字段。"""
    return _SENSITIVE_FIELD_PATTERN.sub(r"\1<redacted>", value)


def _truncate(value: str, *, limit: int = 1000) -> str:
    """限制单条日志里的上游响应体长度，避免错误页过大刷屏。"""
    if len(value) <= limit:
        return value
    return f"{value[:limit]}...<truncated {len(value) - limit} chars>"


def describe_original_error(exc: BaseException | None) -> str:
    """格式化原始异常，供 callback 错误日志排查使用。

    这里会保留异常类型、异常消息、HTTP 状态码和上游响应体摘要，
    但会遮蔽 token、code、state、client_secret 等敏感字段。
    """
    if exc is None:
        return "无原始异常"

    parts = [f"type={type(exc).__name__}", f"message={_redact_sensitive_values(str(exc))}"]
    if isinstance(exc, httpx.HTTPStatusError):
        response_text = _redact_sensitive_values(exc.response.text)
        parts.append(f"status_code={exc.response.status_code}")
        parts.append(f"response_body={_truncate(response_text)}")
    return " ".join(parts)


def build_callback_error_response(
    request: Request,
    *,
    error_base: str,
    error_code: str,
    original_error: BaseException | None = None,
) -> RedirectResponse:
    """携带稳定错误码把浏览器重定向回应用入口。"""
    target_url = f"{error_base}{quote(error_code)}"
    logger.warning(
        "认证回调失败，使用稳定错误码重定向：error_code=%s path=%s original_error=%s",
        error_code,
        request.url.path,
        describe_original_error(original_error),
    )
    response = RedirectResponse(
        url=target_url,
        status_code=302,
    )
    clear_temporary_auth_cookies(response, secure=is_https(request))
    return response


def classify_callback_verification_error(exc: Exception) -> str:
    """将 callback 身份校验失败归一化为稳定错误码。"""
    if isinstance(exc, httpx.HTTPStatusError):
        if exc.response.status_code >= 500:
            return CALLBACK_ERROR_TOKEN_VERIFICATION_UNAVAILABLE
        return CALLBACK_ERROR_TOKEN_VALIDATION_FAILED
    if isinstance(exc, httpx.HTTPError):
        return CALLBACK_ERROR_TOKEN_VERIFICATION_UNAVAILABLE
    if isinstance(exc, jwt.ImmatureSignatureError):
        return CALLBACK_ERROR_TOKEN_NOT_YET_VALID
    if isinstance(exc, jwt.InvalidTokenError):
        return CALLBACK_ERROR_TOKEN_VALIDATION_FAILED
    return CALLBACK_ERROR_TOKEN_VERIFICATION_UNAVAILABLE


def classify_callback_exchange_error(exc: Exception) -> str:
    """将 callback 上游传输失败归一化为稳定错误码。"""
    if isinstance(exc, httpx.HTTPStatusError):
        return CALLBACK_ERROR_TOKEN_EXCHANGE_FAILED
    if isinstance(exc, httpx.HTTPError):
        return CALLBACK_ERROR_UPSTREAM_FAILED
    return CALLBACK_ERROR_UNKNOWN
