"""认证相关 FastAPI 依赖，可直接替代手写的 get_current_user。"""

from __future__ import annotations

from typing import TYPE_CHECKING

from fastapi import Cookie, HTTPException, Request

from ecc_auth.identity import AuthIdentity
from ecc_auth.middleware import queue_session_cookie_clear, queue_session_refresh
from ecc_auth.session import (
    RefreshTokenHandler,
    resolve_identity_from_cookies,
    should_clear_token_cookies,
)

if TYPE_CHECKING:
    from ecc_auth.config import KeycloakConfig

# 模块级配置引用，由 init_dependencies() 设置
_config: KeycloakConfig | None = None
_refresh_token_handler: RefreshTokenHandler | None = None


def init_dependencies(
    config: KeycloakConfig,
    *,
    refresh_token_handler: RefreshTokenHandler | None = None,
) -> None:
    """使用 KeycloakConfig 初始化依赖模块。

    在应用启动时、使用 get_current_user / get_current_user_optional 前调用一次。
    通常在创建 auth router 后立即执行：

        app.add_middleware(AuthSessionMiddleware)
        config = KeycloakConfig()
        init_dependencies(config)
    """
    global _config, _refresh_token_handler
    _config = config
    _refresh_token_handler = refresh_token_handler


def _get_config() -> KeycloakConfig:
    if _config is None:
        raise RuntimeError(
            "ecc_auth dependencies not initialized. "
            "Call ecc_auth.init_dependencies(config) at app startup."
        )
    return _config

"""
适用于必须登录的接口，未登录时直接抛出 401
"""
async def get_current_user(
    request: Request,
    kc_access_token: str | None = Cookie(default=None),
    kc_refresh_token: str | None = Cookie(default=None),
    kc_logout_marker: str | None = Cookie(default=None),
) -> AuthIdentity:
    """FastAPI 依赖：从认证 Cookie 解析当前用户。

    与 `/api/auth/me` 共用同一套“JWKS 优先、refresh 回退”的决策核心，
    但不直接修改 Cookie，也不构造前端特定的响应结构。
    """
    config = _get_config()
    try:
        resolution = await resolve_identity_from_cookies(
            config,
            access_token=kc_access_token,
            refresh_token=kc_refresh_token,
            logout_marker=kc_logout_marker,
            refresh_token_handler=_refresh_token_handler,
        )
    except HTTPException as exc:
        if should_clear_token_cookies(exc):
            queue_session_cookie_clear(request)
        raise

    if resolution.token_data is not None:
        queue_session_refresh(request, resolution.token_data)
    return resolution.identity

"""
适用于可匿名访问，但登录后可返回更多信息
401 会被转换为 None，其他异常会正常抛出
"""
async def get_current_user_optional(
    request: Request,
    kc_access_token: str | None = Cookie(default=None),
    kc_refresh_token: str | None = Cookie(default=None),
    kc_logout_marker: str | None = Cookie(default=None),
) -> AuthIdentity | None:
    """FastAPI 依赖：解析当前用户，未认证时返回 None。"""
    try:
        return await get_current_user(
            request=request,
            kc_access_token=kc_access_token,
            kc_refresh_token=kc_refresh_token,
            kc_logout_marker=kc_logout_marker,
        )
    except HTTPException as exc:
        if exc.status_code == 401:
            return None
        raise
