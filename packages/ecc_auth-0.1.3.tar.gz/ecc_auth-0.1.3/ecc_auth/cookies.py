"""Keycloak token 存储相关的 Cookie 工具函数。

约定：所有认证 Cookie 统一使用 kc_* 前缀。
- kc_access_token  (httponly) — Keycloak access token
- kc_refresh_token (httponly) — Keycloak refresh token
- kc_id_token      (httponly) — Keycloak ID token
- kc_expires_at    (前端可读) — token 过期时间戳
"""

from __future__ import annotations

import time

from starlette.requests import HTTPConnection, Request
from starlette.responses import Response

# Cookie 名称
ACCESS_TOKEN = "kc_access_token"
REFRESH_TOKEN = "kc_refresh_token"
ID_TOKEN = "kc_id_token"
EXPIRES_AT = "kc_expires_at"
LOGOUT_MARKER = "kc_logout_marker"

# 登录流程临时 Cookie
PKCE_VERIFIER = "pkce_verifier"
CSRF_NONCE = "csrf_nonce"


def is_https(request: HTTPConnection) -> bool:
    """根据请求协议或 X-Forwarded-Proto 头判断是否为 HTTPS。"""
    if request.url.scheme == "https":
        return True
    forwarded = request.headers.get("x-forwarded-proto", "")
    return forwarded.lower() == "https"


def get_public_origin(request: Request) -> str:
    """从请求头推导对外可访问的 origin。"""
    host = request.headers.get("x-forwarded-host") or request.headers.get(
        "host", "localhost"
    )
    scheme = "https" if is_https(request) else "http"
    return f"{scheme}://{host}"


def set_token_cookies(
    response: Response,
    *,
    access_token: str,
    refresh_token: str,
    id_token: str,
    expires_in: int,
    refresh_expires_in: int,
    secure: bool,
) -> None:
    """将所有 kc_* Cookie 写入响应。"""
    response.set_cookie(
        ACCESS_TOKEN,
        access_token,
        max_age=expires_in,
        path="/",
        httponly=True,
        secure=secure,
        samesite="lax",
    )
    response.set_cookie(
        REFRESH_TOKEN,
        refresh_token,
        max_age=refresh_expires_in,
        path="/",
        httponly=True,
        secure=secure,
        samesite="lax",
    )
    response.set_cookie(
        ID_TOKEN,
        id_token,
        max_age=refresh_expires_in,
        path="/",
        httponly=True,
        secure=secure,
        samesite="lax",
    )

    # kc_expires_at 允许前端 JS 读取（不设置 httponly）以便做过期检查。
    # 这里使用毫秒时间戳，与现有前端消费方式保持一致。
    expires_at = str(int(time.time() * 1000) + expires_in * 1000)
    response.set_cookie(
        EXPIRES_AT,
        expires_at,
        max_age=expires_in,
        path="/",
        httponly=False,
        secure=secure,
        samesite="lax",
    )


def clear_token_cookies(response: Response, *, secure: bool) -> None:
    """删除所有 kc_* Cookie。"""
    for name in (ACCESS_TOKEN, REFRESH_TOKEN, ID_TOKEN, EXPIRES_AT):
        response.delete_cookie(name, path="/", secure=secure, samesite="lax")


def set_logout_marker(response: Response, *, secure: bool, max_age: int = 600) -> None:
    """写入显式登出标记，直到下一次登录开始前都视为已登出。"""
    response.set_cookie(
        LOGOUT_MARKER,
        "1",
        max_age=max_age,
        path="/",
        httponly=True,
        secure=secure,
        samesite="lax",
    )


def clear_logout_marker(response: Response, *, secure: bool) -> None:
    """删除显式登出标记。"""
    response.delete_cookie(LOGOUT_MARKER, path="/", secure=secure, samesite="lax")


def set_temporary_auth_cookies(
    response: Response,
    *,
    code_verifier: str,
    csrf_nonce: str,
    secure: bool,
) -> None:
    """为 PKCE + CSRF 登录流程写入短期有效 Cookie。"""
    response.set_cookie(
        PKCE_VERIFIER,
        code_verifier,
        path="/",
        httponly=True,
        secure=secure,
        samesite="lax",
        max_age=600,
    )
    response.set_cookie(
        CSRF_NONCE,
        csrf_nonce,
        path="/",
        httponly=True,
        secure=secure,
        samesite="lax",
        max_age=600,
    )


def clear_temporary_auth_cookies(response: Response, *, secure: bool) -> None:
    """回调完成后删除 PKCE + CSRF Cookie。"""
    for name in (PKCE_VERIFIER, CSRF_NONCE):
        response.delete_cookie(name, path="/", secure=secure, samesite="lax")
