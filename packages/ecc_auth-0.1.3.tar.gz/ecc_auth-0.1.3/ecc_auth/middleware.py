"""用于跨路由类型持久化认证 Cookie 的中间件与辅助函数。"""

from __future__ import annotations

from typing import Any

from starlette._utils import is_async_callable
from starlette.concurrency import run_in_threadpool
from starlette.middleware.errors import ServerErrorMiddleware
from starlette.requests import HTTPConnection
from starlette.requests import Request
from starlette.responses import PlainTextResponse, Response
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from ecc_auth.cookies import clear_token_cookies, is_https, set_token_cookies

_TOKEN_DATA_ATTR = "_ecc_auth_token_data"
_CLEAR_COOKIES_ATTR = "_ecc_auth_clear_token_cookies"


def queue_session_refresh(request: Request, token_data: dict[str, Any]) -> None:
    """将刷新后的 token Cookie 写入动作排队到最终响应。"""

    setattr(request.state, _TOKEN_DATA_ATTR, token_data)
    setattr(request.state, _CLEAR_COOKIES_ATTR, False)


def queue_session_cookie_clear(request: Request) -> None:
    """将认证 Cookie 清理动作排队到最终响应。"""

    setattr(request.state, _TOKEN_DATA_ATTR, None)
    setattr(request.state, _CLEAR_COOKIES_ATTR, True)


def apply_queued_session_cookies(request: HTTPConnection, response: Response) -> None:
    """把已排队的认证 Cookie 变更应用到实际响应对象。"""

    token_data = getattr(request.state, _TOKEN_DATA_ATTR, None)
    clear_cookies = bool(getattr(request.state, _CLEAR_COOKIES_ATTR, False))
    secure = is_https(request)

    if clear_cookies:
        clear_token_cookies(response, secure=secure)
        setattr(request.state, _CLEAR_COOKIES_ATTR, False)

    if token_data is not None:
        set_token_cookies(
            response,
            access_token=token_data["access_token"],
            refresh_token=token_data["refresh_token"],
            id_token=token_data.get("id_token", ""),
            expires_in=token_data.get("expires_in", 300),
            refresh_expires_in=token_data.get("refresh_expires_in", 1800),
            secure=secure,
        )
        setattr(request.state, _TOKEN_DATA_ATTR, None)


class AuthSessionMiddleware:
    """将已排队的认证 Cookie 变更落到成功或错误响应上。"""

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        request = Request(scope, receive=receive, send=send)
        response_started = False

        async def send_with_queued_cookies(message: Message) -> None:
            nonlocal response_started

            if message["type"] == "http.response.start":
                message = self._apply_cookies_to_message(request, message)
                response_started = True

            await send(message)

        try:
            await self.app(scope, receive, send_with_queued_cookies)
        except Exception as exc:
            if not response_started:
                response = await self._build_error_response(request, exc)
                apply_queued_session_cookies(request, response)
                await response(scope, receive, send)
            raise

    def _apply_cookies_to_message(self, request: Request, message: Message) -> Message:
        response = Response(status_code=message["status"])
        response.raw_headers = list(message["headers"])
        apply_queued_session_cookies(request, response)
        return {**message, "headers": response.raw_headers}

    async def _build_error_response(self, request: Request, exc: Exception) -> Response:
        debug = getattr(request.app, "debug", False)
        error_handler = None

        for key, value in getattr(request.app, "exception_handlers", {}).items():
            if key in (500, Exception):
                error_handler = value

        if debug:
            return ServerErrorMiddleware(
                self.app, handler=error_handler, debug=True
            ).debug_response(request, exc)

        if error_handler is None:
            return PlainTextResponse("Internal Server Error", status_code=500)

        if is_async_callable(error_handler):
            return await error_handler(request, exc)
        return await run_in_threadpool(error_handler, request, exc)
