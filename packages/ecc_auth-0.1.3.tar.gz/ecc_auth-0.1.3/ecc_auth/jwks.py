"""基于 JWKS 的本地 token 校验：单请求零网络开销。"""

from __future__ import annotations

import ssl
import time
from typing import TYPE_CHECKING, Any

import jwt
from jwt import PyJWKClient, PyJWKClientError

if TYPE_CHECKING:
    from ecc_auth.config import KeycloakConfig

# 模块级缓存：config.jwks_uri -> (PyJWKClient, created_at)
_jwk_clients: dict[str, tuple[PyJWKClient, float]] = {}

# 缓存 TTL：1 小时（JWKS key 很少轮转）
_CACHE_TTL = 3600


def _get_jwk_client(config: KeycloakConfig) -> PyJWKClient:
    """获取或创建给定配置对应的缓存 PyJWKClient。"""
    uri = config.jwks_uri
    now = time.monotonic()

    cached = _jwk_clients.get(uri)
    if cached and (now - cached[1]) < _CACHE_TTL:
        return cached[0]

    # PyJWKClient 内部会做 key 缓存，遇到未知 kid 会重新拉取
    ssl_context: ssl.SSLContext | None = None
    if config.tls_insecure:
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE

    client = PyJWKClient(uri, cache_keys=True, ssl_context=ssl_context)
    _jwk_clients[uri] = (client, now)
    return client


async def verify_access_token(
    token: str,
    config: KeycloakConfig,
    *,
    audience: str | None = None,
) -> dict[str, Any]:
    """使用 JWKS 本地校验 Keycloak access token。

    该方案用本地 JWT 校验替代了每次请求都调用 /userinfo：
    - 0ms 网络开销（相比 /userinfo 常见 50-200ms）
    - Keycloak 短暂不可用时，不影响已签发 token 的校验
    - 公钥会被缓存，并在遇到未知 kid 时自动刷新

    Args:
        token: 原始 JWT access token 字符串。
        config: Keycloak 配置。
        audience: 期望的 audience claim。若为 None，则不校验 audience
                  （Keycloak access token 不一定总带 aud）。

    Returns:
        解码后的 JWT claims 字典。

    Raises:
        jwt.InvalidTokenError: token 无效、过期或不受信任时抛出。
    """
    jwk_client = _get_jwk_client(config)

    try:
        signing_key = jwk_client.get_signing_key_from_jwt(token)
    except PyJWKClientError:
        # 未知 kid：强制重新拉取并重试一次
        _jwk_clients.pop(config.jwks_uri, None)
        jwk_client = _get_jwk_client(config)
        signing_key = jwk_client.get_signing_key_from_jwt(token)

    decode_options: dict[str, Any] = {
        "algorithms": ["RS256"],
        "issuer": config.issuer,
    }
    if audience:
        decode_options["audience"] = audience
    else:
        decode_options["options"] = {"verify_aud": False}

    return jwt.decode(
        token,
        signing_key.key,
        **decode_options,
    )
