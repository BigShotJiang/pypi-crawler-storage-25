"""从环境变量读取 Keycloak 配置。"""

from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass(frozen=True)
class KeycloakConfig:
    """Keycloak OIDC 配置。

    默认从环境变量读取，但所有字段都可以通过构造参数覆盖。
    """

    url: str = field(default_factory=lambda: os.environ["KEYCLOAK_URL"])
    realm: str = field(default_factory=lambda: os.environ["KEYCLOAK_REALM"])
    client_id: str = field(default_factory=lambda: os.environ["KEYCLOAK_CLIENT_ID"])
    client_secret: str = field(
        default_factory=lambda: os.environ["KEYCLOAK_CLIENT_SECRET"]
    )
    tls_insecure: bool = field(
        default_factory=lambda: (
            os.environ.get("KEYCLOAK_TLS_INSECURE", "false").lower() == "true"
        )
    )

    @property
    def issuer(self) -> str:
        return f"{self.url}/realms/{self.realm}"

    @property
    def discovery_url(self) -> str:
        return f"{self.issuer}/.well-known/openid-configuration"

    @property
    def jwks_uri(self) -> str:
        return f"{self.issuer}/protocol/openid-connect/certs"

    @property
    def token_endpoint(self) -> str:
        return f"{self.issuer}/protocol/openid-connect/token"

    @property
    def authorization_endpoint(self) -> str:
        return f"{self.issuer}/protocol/openid-connect/auth"

    @property
    def userinfo_endpoint(self) -> str:
        return f"{self.issuer}/protocol/openid-connect/userinfo"

    @property
    def end_session_endpoint(self) -> str:
        return f"{self.issuer}/protocol/openid-connect/logout"
