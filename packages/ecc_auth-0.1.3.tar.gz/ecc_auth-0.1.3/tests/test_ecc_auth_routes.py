from __future__ import annotations

import base64
import logging
import time
from collections.abc import Callable
from http.cookies import SimpleCookie
from typing import Any, cast
from unittest.mock import AsyncMock, patch

import httpx
import jwt
from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient
from starlette.responses import JSONResponse, Response as StarletteResponse, StreamingResponse

from ecc_auth import AuthSessionMiddleware, get_current_user, get_current_user_optional, init_dependencies
from ecc_auth.config import KeycloakConfig
from ecc_auth.cookies import EXPIRES_AT, LOGOUT_MARKER, set_token_cookies
from ecc_auth.routes import _decode_auth_state, create_auth_router


def _set_cookie_header_values(response: httpx.Response | StarletteResponse) -> list[str]:
    headers: Any = response.headers
    get_list = getattr(headers, "get_list", None)
    if get_list is not None:
        return list(get_list("set-cookie"))
    return list(cast(Any, headers).getlist("set-cookie"))


def _make_config() -> KeycloakConfig:
    return KeycloakConfig(
        url="https://keycloak.example.com",
        realm="ecc",
        client_id="client-id",
        client_secret="client-secret",
        tls_insecure=False,
    )


def _make_client(
    *,
    on_user_authenticated: Callable | None = None,
    load_current_user: Callable | None = None,
    refresh_token_handler: Callable | None = None,
    raise_server_exceptions: bool = True,
) -> TestClient:
    config = _make_config()
    init_dependencies(config, refresh_token_handler=refresh_token_handler)
    app = FastAPI()
    app.add_middleware(AuthSessionMiddleware)
    app.include_router(
        create_auth_router(
            config,
            on_user_authenticated=on_user_authenticated,
            load_current_user=load_current_user,
            refresh_token_handler=refresh_token_handler,
        ),
        prefix="/api/auth",
    )

    @app.get("/protected")
    async def protected_route(identity=Depends(get_current_user)):
        return {
            "sub": identity.external_auth_id,
            "displayName": identity.display_name,
        }

    @app.get("/protected-optional")
    async def protected_optional_route(identity=Depends(get_current_user_optional)):
        return {"identityIsNone": identity is None}

    @app.get("/protected-json")
    async def protected_json_route(identity=Depends(get_current_user)):
        return JSONResponse(
            {
                "sub": identity.external_auth_id,
                "displayName": identity.display_name,
            }
        )

    @app.get("/protected-stream")
    async def protected_stream_route(identity=Depends(get_current_user)):
        return StreamingResponse(
            iter([identity.external_auth_id]),
            media_type="text/plain",
        )

    @app.get("/protected-crash")
    async def protected_crash_route(identity=Depends(get_current_user)):
        raise RuntimeError(f"boom for {identity.external_auth_id}")

    return TestClient(app, raise_server_exceptions=raise_server_exceptions)


def _cookie_value(response: httpx.Response | StarletteResponse, name: str) -> str:
    cookie = SimpleCookie()
    for header in _set_cookie_header_values(response):
        cookie.load(header)
    return cookie[name].value


def _cookie_headers(response: httpx.Response | StarletteResponse) -> list[str]:
    return _set_cookie_header_values(response)


def _encode_callback_state(
    *,
    nonce: str = "csrf-nonce",
    return_to: str = "/workspace",
    origin: str = "http://testserver",
) -> str:
    from ecc_auth.routes import _encode_auth_state

    return _encode_auth_state(nonce=nonce, return_to=return_to, origin=origin)


def test_init_dependencies_is_exported_from_package_root() -> None:
    assert callable(init_dependencies)


def test_set_token_cookies_uses_millisecond_expiry() -> None:
    response = StarletteResponse()
    before_ms = int(time.time() * 1000)

    set_token_cookies(
        response,
        access_token="access-token",
        refresh_token="refresh-token",
        id_token="id-token",
        expires_in=300,
        refresh_expires_in=1800,
        secure=False,
    )

    expires_at = int(_cookie_value(response, EXPIRES_AT))
    assert expires_at >= before_ms + 300_000 - 2_000
    assert expires_at <= before_ms + 300_000 + 2_000
    assert expires_at > 1_000_000_000_000


def test_login_uses_return_to_query_param() -> None:
    client = _make_client()
    authorization_mock = AsyncMock(
        return_value={
            "url": "https://keycloak.example.com/authorize",
            "state": "opaque-state",
            "code_verifier": "pkce-verifier",
        }
    )

    with patch("ecc_auth.routes.build_authorization_url", authorization_mock):
        response = client.get(
            "/api/auth/login",
            params={"return_to": "/snake"},
            follow_redirects=False,
        )

    assert response.status_code == 302
    await_args = authorization_mock.await_args
    assert await_args is not None
    state = await_args.kwargs["state"]
    assert _decode_auth_state(state) == {
        "nonce": response.cookies["csrf_nonce"],
        "return_to": "/snake",
        "origin": "http://testserver",
    }
    assert response.cookies["pkce_verifier"] == "pkce-verifier"


def test_callback_rejects_non_object_state_as_invalid_state() -> None:
    client = _make_client(on_user_authenticated=AsyncMock())
    non_object_state = base64.urlsafe_b64encode(b"[]").decode()

    client.cookies.set("pkce_verifier", "pkce-verifier")
    client.cookies.set("csrf_nonce", "csrf-nonce")
    response = client.get(
        "/api/auth/callback",
        params={"code": "auth-code", "state": non_object_state},
        follow_redirects=False,
    )

    assert response.status_code == 302
    assert response.headers["location"] == "http://testserver/?error=invalid_state"


def test_callback_uses_keycloak_userinfo_instead_of_local_jwt_time_validation() -> None:
    on_user_authenticated = AsyncMock()
    client = _make_client(on_user_authenticated=on_user_authenticated)
    userinfo_mock = AsyncMock(
        return_value={
            "sub": "kc-sub",
            "name": "Alice",
            "preferred_username": "alice",
            "email": "alice@example.com",
            "email_verified": True,
        }
    )

    with (
        patch(
            "ecc_auth.routes.exchange_code_for_token",
            AsyncMock(
                return_value={
                    "access_token": "fresh-access-token",
                    "refresh_token": "refresh-token",
                    "id_token": "id-token",
                    "expires_in": 300,
                    "refresh_expires_in": 1800,
                }
            ),
        ),
        patch("ecc_auth.routes.fetch_user_info", userinfo_mock),
    ):
        client.cookies.set("pkce_verifier", "pkce-verifier")
        client.cookies.set("csrf_nonce", "csrf-nonce")
        response = client.get(
            "/api/auth/callback",
            params={
                "code": "auth-code",
                "state": _encode_callback_state(),
            },
            follow_redirects=False,
        )

    assert response.status_code == 302
    assert response.headers["location"] == "http://testserver/workspace"
    assert response.cookies["kc_access_token"] == "fresh-access-token"
    userinfo_mock.assert_awaited_once_with(_make_config(), "fresh-access-token")
    on_user_authenticated.assert_awaited_once()
    await_args = on_user_authenticated.await_args
    assert await_args is not None
    identity = await_args.args[0]
    assert identity.external_auth_id == "kc-sub"


def test_callback_returns_token_validation_failed_for_invalid_tokens() -> None:
    on_user_authenticated = AsyncMock()
    client = _make_client(on_user_authenticated=on_user_authenticated)
    request = httpx.Request("GET", "https://keycloak.example.com/userinfo")
    upstream_response = httpx.Response(status_code=401, request=request)

    with (
        patch(
            "ecc_auth.routes.exchange_code_for_token",
            AsyncMock(
                return_value={
                    "access_token": "invalid-access-token",
                    "refresh_token": "refresh-token",
                    "id_token": "id-token",
                    "expires_in": 300,
                    "refresh_expires_in": 1800,
                }
            ),
        ),
        patch(
            "ecc_auth.routes.fetch_user_info",
            AsyncMock(
                side_effect=httpx.HTTPStatusError(
                    "userinfo rejected token",
                    request=request,
                    response=upstream_response,
                )
            ),
        ),
    ):
        client.cookies.set("pkce_verifier", "pkce-verifier")
        client.cookies.set("csrf_nonce", "csrf-nonce")
        response = client.get(
            "/api/auth/callback",
            params={
                "code": "auth-code",
                "state": _encode_callback_state(),
            },
            follow_redirects=False,
        )

    assert response.status_code == 302
    assert response.headers["location"] == "http://testserver/?error=token_validation_failed"
    on_user_authenticated.assert_not_awaited()


def test_callback_token_exchange_error_log_redacts_raw_response_body(caplog) -> None:
    client = _make_client(on_user_authenticated=AsyncMock())
    request = httpx.Request("POST", "https://keycloak.example.com/token")
    upstream_response = httpx.Response(
        status_code=400,
        text='{"error":"invalid_grant","access_token":"secret-token","code":"secret-code"}',
        request=request,
    )

    with (
        caplog.at_level(logging.WARNING, logger="ecc_auth.callback_errors"),
        caplog.at_level(logging.ERROR, logger="ecc_auth.routes"),
        patch(
            "ecc_auth.routes.exchange_code_for_token",
            AsyncMock(
                side_effect=httpx.HTTPStatusError(
                    "token exchange rejected",
                    request=request,
                    response=upstream_response,
                )
            ),
        ),
    ):
        client.cookies.set("pkce_verifier", "pkce-verifier")
        client.cookies.set("csrf_nonce", "csrf-nonce")
        response = client.get(
            "/api/auth/callback",
            params={"code": "auth-code", "state": _encode_callback_state()},
            follow_redirects=False,
        )

    assert response.status_code == 302
    assert response.headers["location"] == "http://testserver/?error=token_exchange_failed"
    assert "token exchange rejected" in caplog.text
    assert "invalid_grant" in caplog.text
    assert "secret-token" not in caplog.text
    assert "secret-code" not in caplog.text
    assert "<redacted>" in caplog.text


def test_callback_returns_token_verification_unavailable_for_userinfo_outage(
    caplog,
) -> None:
    on_user_authenticated = AsyncMock()
    client = _make_client(on_user_authenticated=on_user_authenticated)
    request = httpx.Request("GET", "https://keycloak.example.com/userinfo")
    upstream_response = httpx.Response(
        status_code=503,
        text='{"error":"temporarily_unavailable","access_token":"secret-access-token"}',
        request=request,
    )

    with (
        caplog.at_level(logging.WARNING, logger="ecc_auth.callback_errors"),
        patch(
            "ecc_auth.routes.exchange_code_for_token",
            AsyncMock(
                return_value={
                    "access_token": "access-token",
                    "refresh_token": "refresh-token",
                    "id_token": "id-token",
                    "expires_in": 300,
                    "refresh_expires_in": 1800,
                }
            ),
        ),
        patch(
            "ecc_auth.routes.fetch_user_info",
            AsyncMock(
                side_effect=httpx.HTTPStatusError(
                    "userinfo unavailable",
                    request=request,
                    response=upstream_response,
                )
            ),
        ),
    ):
        client.cookies.set("pkce_verifier", "pkce-verifier")
        client.cookies.set("csrf_nonce", "csrf-nonce")
        response = client.get(
            "/api/auth/callback",
            params={
                "code": "auth-code",
                "state": _encode_callback_state(),
            },
            follow_redirects=False,
        )

    assert response.status_code == 302
    assert (
        response.headers["location"]
        == "http://testserver/?error=token_verification_unavailable"
    )
    assert "token_verification_unavailable" in caplog.text
    assert "type=HTTPStatusError" in caplog.text
    assert "status_code=503" in caplog.text
    assert "temporarily_unavailable" in caplog.text
    assert "secret-access-token" not in caplog.text
    assert '<redacted>' in caplog.text
    on_user_authenticated.assert_not_awaited()


def test_callback_missing_state_returns_stable_error_and_logs(caplog) -> None:
    client = _make_client(on_user_authenticated=AsyncMock())

    with caplog.at_level(logging.WARNING, logger="ecc_auth.callback_errors"):
        response = client.get(
            "/api/auth/callback",
            params={"code": "auth-code"},
            follow_redirects=False,
        )

    assert response.status_code == 302
    assert response.headers["location"] == "http://testserver/?error=missing_state"
    assert "missing_state" in caplog.text
    assert "original_error=无原始异常" in caplog.text


def test_callback_returns_user_sync_failed_when_consumer_callback_crashes() -> None:
    on_user_authenticated = AsyncMock(side_effect=RuntimeError("db down"))
    client = _make_client(on_user_authenticated=on_user_authenticated)

    with (
        patch(
            "ecc_auth.routes.exchange_code_for_token",
            AsyncMock(
                return_value={
                    "access_token": "valid-access-token",
                    "refresh_token": "refresh-token",
                    "id_token": "id-token",
                    "expires_in": 300,
                    "refresh_expires_in": 1800,
                }
            ),
        ),
        patch(
            "ecc_auth.routes.fetch_user_info",
            AsyncMock(
                return_value={
                    "sub": "kc-sub",
                    "name": "Alice",
                    "preferred_username": "alice",
                    "email": "alice@example.com",
                    "email_verified": True,
                }
            ),
        ),
    ):
        client.cookies.set("pkce_verifier", "pkce-verifier")
        client.cookies.set("csrf_nonce", "csrf-nonce")
        response = client.get(
            "/api/auth/callback",
            params={
                "code": "auth-code",
                "state": _encode_callback_state(),
            },
            follow_redirects=False,
        )

    assert response.status_code == 302
    assert response.headers["location"] == "http://testserver/?error=user_sync_failed"
    on_user_authenticated.assert_awaited_once()


def test_me_uses_hydrator_and_refresh_fallback() -> None:
    async def load_current_user(identity):
        return {
            "id": 123,
            "externalAuthId": identity.external_auth_id,
            "displayName": identity.display_name,
            "profile": {"profileCompleted": True},
        }

    client = _make_client(load_current_user=load_current_user)
    verify_mock = AsyncMock(
        side_effect=[
            jwt.ExpiredSignatureError("expired"),
            {
                "sub": "kc-sub",
                "name": "Alice",
                "preferred_username": "alice",
                "email": "alice@example.com",
                "email_verified": True,
            },
        ]
    )
    refresh_mock = AsyncMock(
        return_value={
            "access_token": "new-access-token",
            "refresh_token": "new-refresh-token",
            "id_token": "id-token",
            "expires_in": 300,
            "refresh_expires_in": 1800,
        }
    )

    with (
        patch("ecc_auth.session.verify_access_token", verify_mock),
        patch("ecc_auth.session.refresh_token_request", refresh_mock),
    ):
        client.cookies.set("kc_access_token", "expired-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/api/auth/me")

    assert response.status_code == 200
    assert response.json() == {
        "user": {
            "id": 123,
            "externalAuthId": "kc-sub",
            "displayName": "Alice",
            "profile": {"profileCompleted": True},
        }
    }
    refresh_mock.assert_awaited_once()
    assert int(response.cookies[EXPIRES_AT]) > 1_000_000_000_000


def test_me_persists_rotated_cookies_when_hydrator_crashes() -> None:
    async def load_current_user(_identity):
        raise RuntimeError("db down after refresh")

    client = _make_client(
        load_current_user=load_current_user,
        raise_server_exceptions=False,
    )
    verify_mock = AsyncMock(
        side_effect=[
            jwt.ExpiredSignatureError("expired"),
            {
                "sub": "kc-sub",
                "name": "Alice",
                "preferred_username": "alice",
                "email": "alice@example.com",
                "email_verified": True,
            },
        ]
    )
    refresh_mock = AsyncMock(
        return_value={
            "access_token": "new-access-token",
            "refresh_token": "new-refresh-token",
            "id_token": "id-token",
            "expires_in": 300,
            "refresh_expires_in": 1800,
        }
    )

    with (
        patch("ecc_auth.session.verify_access_token", verify_mock),
        patch("ecc_auth.session.refresh_token_request", refresh_mock),
    ):
        client.cookies.set("kc_access_token", "expired-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/api/auth/me")

    assert response.status_code == 500
    cookie_headers = _cookie_headers(response)
    assert any(header.startswith("kc_access_token=new-access-token") for header in cookie_headers)
    assert any(header.startswith("kc_refresh_token=new-refresh-token") for header in cookie_headers)


def test_refresh_returns_503_when_keycloak_is_unavailable() -> None:
    client = _make_client()
    request = httpx.Request("POST", "https://keycloak.example.com/token")
    response = httpx.Response(status_code=503, request=request)

    with patch(
        "ecc_auth.session.refresh_token_request",
        AsyncMock(side_effect=httpx.HTTPStatusError("upstream down", request=request, response=response)),
    ):
        client.cookies.set("kc_refresh_token", "refresh-token")
        result = client.post("/api/auth/refresh")

    assert result.status_code == 503
    assert result.json() == {"detail": "Authentication service unavailable"}


def test_refresh_returns_session_expired_on_terminal_refresh_failure() -> None:
    client = _make_client()
    request = httpx.Request("POST", "https://keycloak.example.com/token")
    response = httpx.Response(status_code=401, request=request)

    with patch(
        "ecc_auth.session.refresh_token_request",
        AsyncMock(side_effect=httpx.HTTPStatusError("expired", request=request, response=response)),
    ):
        client.cookies.set("kc_refresh_token", "refresh-token")
        result = client.post("/api/auth/refresh")

    assert result.status_code == 401
    assert result.json() == {"detail": "Session expired"}


def test_refresh_clears_cookies_when_refreshed_access_token_is_invalid() -> None:
    client = _make_client()
    verify_mock = AsyncMock(side_effect=jwt.InvalidTokenError("invalid refreshed token"))
    refresh_mock = AsyncMock(
        return_value={
            "access_token": "bad-access-token",
            "refresh_token": "new-refresh-token",
            "id_token": "id-token",
            "expires_in": 300,
            "refresh_expires_in": 1800,
        }
    )

    with (
        patch("ecc_auth.session.verify_access_token", verify_mock),
        patch("ecc_auth.session.refresh_token_request", refresh_mock),
    ):
        client.cookies.set("kc_refresh_token", "refresh-token")
        result = client.post("/api/auth/refresh")

    assert result.status_code == 401
    assert result.json() == {"detail": "Session expired"}
    cookie_headers = _cookie_headers(result)
    assert any(header.startswith("kc_access_token=") for header in cookie_headers)
    assert any(header.startswith("kc_refresh_token=") for header in cookie_headers)


def test_refresh_uses_refresh_token_handler_override() -> None:
    refresh_handler = AsyncMock(
        return_value={
            "access_token": "handler-access-token",
            "refresh_token": "handler-refresh-token",
            "id_token": "id-token",
            "expires_in": 300,
            "refresh_expires_in": 1800,
        }
    )
    client = _make_client(refresh_token_handler=refresh_handler)

    with patch(
        "ecc_auth.session.verify_access_token",
        AsyncMock(
            return_value={
                "sub": "kc-sub",
                "name": "Alice",
                "preferred_username": "alice",
                "email": "alice@example.com",
                "email_verified": True,
            }
        ),
    ):
        client.cookies.set("kc_refresh_token", "refresh-token")
        result = client.post("/api/auth/refresh")

    assert result.status_code == 200
    assert result.json() == {"ok": True}
    assert result.cookies["kc_access_token"] == "handler-access-token"
    refresh_handler.assert_awaited_once()


def test_logout_sets_marker_cookie() -> None:
    client = _make_client()
    client.cookies.set("kc_id_token", "id-token")

    response = client.post("/api/auth/logout")

    assert response.status_code == 200
    assert _cookie_value(response, LOGOUT_MARKER) == "1"
    assert response.json()["logoutUrl"].startswith("https://keycloak.example.com/realms/ecc/protocol/openid-connect/logout")


def test_me_skips_refresh_when_logout_marker_is_present() -> None:
    client = _make_client()
    refresh_mock = AsyncMock()

    with patch("ecc_auth.session.refresh_token_request", refresh_mock):
        client.cookies.set("kc_access_token", "stale-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        client.cookies.set(LOGOUT_MARKER, "1")
        response = client.get("/api/auth/me")

    assert response.status_code == 401
    assert response.json() == {"detail": "Logged out"}
    refresh_mock.assert_not_awaited()


def test_refresh_skips_upstream_call_when_logout_marker_is_present() -> None:
    client = _make_client()
    refresh_mock = AsyncMock()

    with patch("ecc_auth.session.refresh_token_request", refresh_mock):
        client.cookies.set("kc_refresh_token", "refresh-token")
        client.cookies.set(LOGOUT_MARKER, "1")
        response = client.post("/api/auth/refresh")

    assert response.status_code == 401
    assert response.json() == {"detail": "Logged out"}
    refresh_mock.assert_not_awaited()


def test_me_returns_503_without_refresh_on_runtime_verifier_failure() -> None:
    client = _make_client()
    verify_mock = AsyncMock(side_effect=RuntimeError("jwks cache unavailable"))
    refresh_mock = AsyncMock()

    with (
        patch("ecc_auth.session.verify_access_token", verify_mock),
        patch("ecc_auth.session.refresh_token_request", refresh_mock),
    ):
        client.cookies.set("kc_access_token", "stale-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/api/auth/me")

    assert response.status_code == 503
    assert response.json() == {"detail": "Authentication service unavailable"}
    refresh_mock.assert_not_awaited()


def test_dependency_uses_refresh_fallback() -> None:
    client = _make_client()
    verify_mock = AsyncMock(
        side_effect=[
            jwt.ExpiredSignatureError("expired"),
            {
                "sub": "kc-sub",
                "name": "Alice",
                "preferred_username": "alice",
                "email": "alice@example.com",
                "email_verified": True,
            },
        ]
    )
    refresh_mock = AsyncMock(
        return_value={
            "access_token": "new-access-token",
            "refresh_token": "new-refresh-token",
            "id_token": "id-token",
            "expires_in": 300,
            "refresh_expires_in": 1800,
        }
    )

    with (
        patch("ecc_auth.session.verify_access_token", verify_mock),
        patch("ecc_auth.session.refresh_token_request", refresh_mock),
    ):
        client.cookies.set("kc_access_token", "expired-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/protected")

    assert response.status_code == 200
    assert response.json() == {"sub": "kc-sub", "displayName": "Alice"}
    refresh_mock.assert_awaited_once()
    assert response.cookies["kc_access_token"] == "new-access-token"
    assert response.cookies["kc_refresh_token"] == "new-refresh-token"


def test_dependency_refresh_persists_cookies_for_jsonresponse_routes() -> None:
    client = _make_client()
    verify_mock = AsyncMock(
        side_effect=[
            jwt.ExpiredSignatureError("expired"),
            {
                "sub": "kc-sub",
                "name": "Alice",
                "preferred_username": "alice",
                "email": "alice@example.com",
                "email_verified": True,
            },
        ]
    )
    refresh_mock = AsyncMock(
        return_value={
            "access_token": "json-access-token",
            "refresh_token": "json-refresh-token",
            "id_token": "id-token",
            "expires_in": 300,
            "refresh_expires_in": 1800,
        }
    )

    with (
        patch("ecc_auth.session.verify_access_token", verify_mock),
        patch("ecc_auth.session.refresh_token_request", refresh_mock),
    ):
        client.cookies.set("kc_access_token", "expired-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/protected-json")

    assert response.status_code == 200
    assert response.json() == {"sub": "kc-sub", "displayName": "Alice"}
    assert response.cookies["kc_access_token"] == "json-access-token"
    assert response.cookies["kc_refresh_token"] == "json-refresh-token"


def test_dependency_refresh_persists_cookies_for_streaming_routes() -> None:
    client = _make_client()
    verify_mock = AsyncMock(
        side_effect=[
            jwt.ExpiredSignatureError("expired"),
            {
                "sub": "kc-sub",
                "name": "Alice",
                "preferred_username": "alice",
                "email": "alice@example.com",
                "email_verified": True,
            },
        ]
    )
    refresh_mock = AsyncMock(
        return_value={
            "access_token": "stream-access-token",
            "refresh_token": "stream-refresh-token",
            "id_token": "id-token",
            "expires_in": 300,
            "refresh_expires_in": 1800,
        }
    )

    with (
        patch("ecc_auth.session.verify_access_token", verify_mock),
        patch("ecc_auth.session.refresh_token_request", refresh_mock),
    ):
        client.cookies.set("kc_access_token", "expired-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/protected-stream")

    assert response.status_code == 200
    assert response.text == "kc-sub"
    assert response.cookies["kc_access_token"] == "stream-access-token"
    assert response.cookies["kc_refresh_token"] == "stream-refresh-token"


def test_dependency_refresh_persists_cookies_when_route_crashes() -> None:
    client = _make_client(raise_server_exceptions=False)
    verify_mock = AsyncMock(
        side_effect=[
            jwt.ExpiredSignatureError("expired"),
            {
                "sub": "kc-sub",
                "name": "Alice",
                "preferred_username": "alice",
                "email": "alice@example.com",
                "email_verified": True,
            },
        ]
    )
    refresh_mock = AsyncMock(
        return_value={
            "access_token": "crash-access-token",
            "refresh_token": "crash-refresh-token",
            "id_token": "id-token",
            "expires_in": 300,
            "refresh_expires_in": 1800,
        }
    )

    with (
        patch("ecc_auth.session.verify_access_token", verify_mock),
        patch("ecc_auth.session.refresh_token_request", refresh_mock),
    ):
        client.cookies.set("kc_access_token", "expired-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/protected-crash")

    assert response.status_code == 500
    cookie_headers = _cookie_headers(response)
    assert any(header.startswith("kc_access_token=crash-access-token") for header in cookie_headers)
    assert any(header.startswith("kc_refresh_token=crash-refresh-token") for header in cookie_headers)


def test_me_uses_refresh_token_handler_override() -> None:
    refresh_handler = AsyncMock(
        return_value={
            "access_token": "handler-access-token",
            "refresh_token": "handler-refresh-token",
            "id_token": "id-token",
            "expires_in": 300,
            "refresh_expires_in": 1800,
        }
    )
    client = _make_client(refresh_token_handler=refresh_handler)
    verify_mock = AsyncMock(
        side_effect=[
            jwt.ExpiredSignatureError("expired"),
            {
                "sub": "kc-sub",
                "name": "Alice",
                "preferred_username": "alice",
                "email": "alice@example.com",
                "email_verified": True,
            },
        ]
    )

    with patch("ecc_auth.session.verify_access_token", verify_mock):
        client.cookies.set("kc_access_token", "expired-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/api/auth/me")

    assert response.status_code == 200
    assert response.json()["user"]["externalAuthId"] == "kc-sub"
    refresh_handler.assert_awaited_once()


def test_dependency_uses_refresh_token_handler_override() -> None:
    refresh_handler = AsyncMock(
        return_value={
            "access_token": "handler-access-token",
            "refresh_token": "handler-refresh-token",
            "id_token": "id-token",
            "expires_in": 300,
            "refresh_expires_in": 1800,
        }
    )
    client = _make_client(refresh_token_handler=refresh_handler)
    verify_mock = AsyncMock(
        side_effect=[
            jwt.ExpiredSignatureError("expired"),
            {
                "sub": "kc-sub",
                "name": "Alice",
                "preferred_username": "alice",
                "email": "alice@example.com",
                "email_verified": True,
            },
        ]
    )

    with patch("ecc_auth.session.verify_access_token", verify_mock):
        client.cookies.set("kc_access_token", "expired-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/protected")

    assert response.status_code == 200
    assert response.json() == {"sub": "kc-sub", "displayName": "Alice"}
    refresh_handler.assert_awaited_once()


def test_dependency_requires_authentication_without_cookies() -> None:
    client = _make_client()

    response = client.get("/protected")

    assert response.status_code == 401
    assert response.json() == {"detail": "Not authenticated"}


def test_optional_dependency_returns_none_when_not_authenticated() -> None:
    client = _make_client()

    response = client.get("/protected-optional")

    assert response.status_code == 200
    assert response.json() == {"identityIsNone": True}


def test_optional_dependency_returns_none_and_clears_stale_cookies() -> None:
    client = _make_client()
    verify_mock = AsyncMock(side_effect=jwt.ExpiredSignatureError("expired"))

    with patch("ecc_auth.session.verify_access_token", verify_mock):
        client.cookies.set("kc_access_token", "expired-access-token")
        response = client.get("/protected-optional")

    assert response.status_code == 200
    assert response.json() == {"identityIsNone": True}
    cookie_headers = _cookie_headers(response)
    assert any(header.startswith("kc_access_token=") for header in cookie_headers)


def test_dependency_skips_refresh_when_logout_marker_is_present() -> None:
    client = _make_client()
    refresh_mock = AsyncMock()

    with patch("ecc_auth.session.refresh_token_request", refresh_mock):
        client.cookies.set("kc_access_token", "stale-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        client.cookies.set(LOGOUT_MARKER, "1")
        response = client.get("/protected")

    assert response.status_code == 401
    assert response.json() == {"detail": "Logged out"}
    refresh_mock.assert_not_awaited()
    cookie_headers = _cookie_headers(response)
    assert any(header.startswith("kc_access_token=") for header in cookie_headers)
    assert any(header.startswith("kc_refresh_token=") for header in cookie_headers)


def test_dependency_returns_503_without_refresh_on_runtime_verifier_failure() -> None:
    client = _make_client()
    verify_mock = AsyncMock(side_effect=RuntimeError("jwks unavailable"))
    refresh_mock = AsyncMock()

    with (
        patch("ecc_auth.session.verify_access_token", verify_mock),
        patch("ecc_auth.session.refresh_token_request", refresh_mock),
    ):
        client.cookies.set("kc_access_token", "stale-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/protected")

    assert response.status_code == 503
    assert response.json() == {"detail": "Authentication service unavailable"}
    refresh_mock.assert_not_awaited()


def test_optional_dependency_propagates_runtime_verifier_failure() -> None:
    client = _make_client()
    verify_mock = AsyncMock(side_effect=RuntimeError("jwks unavailable"))
    refresh_mock = AsyncMock()

    with (
        patch("ecc_auth.session.verify_access_token", verify_mock),
        patch("ecc_auth.session.refresh_token_request", refresh_mock),
    ):
        client.cookies.set("kc_access_token", "stale-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/protected-optional")

    assert response.status_code == 503
    assert response.json() == {"detail": "Authentication service unavailable"}
    refresh_mock.assert_not_awaited()


def test_me_clears_cookies_when_refreshed_access_token_is_invalid() -> None:
    client = _make_client()
    verify_mock = AsyncMock(
        side_effect=[
            jwt.ExpiredSignatureError("expired"),
            jwt.InvalidTokenError("invalid refreshed token"),
        ]
    )
    refresh_mock = AsyncMock(
        return_value={
            "access_token": "bad-access-token",
            "refresh_token": "new-refresh-token",
            "id_token": "id-token",
            "expires_in": 300,
            "refresh_expires_in": 1800,
        }
    )

    with (
        patch("ecc_auth.session.verify_access_token", verify_mock),
        patch("ecc_auth.session.refresh_token_request", refresh_mock),
    ):
        client.cookies.set("kc_access_token", "expired-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/api/auth/me")

    assert response.status_code == 401
    assert response.json() == {"detail": "Session expired"}
    cookie_headers = _cookie_headers(response)
    assert any(header.startswith("kc_access_token=") for header in cookie_headers)
    assert any(header.startswith("kc_refresh_token=") for header in cookie_headers)


def test_dependency_clears_cookies_when_refreshed_access_token_is_invalid() -> None:
    client = _make_client()
    verify_mock = AsyncMock(
        side_effect=[
            jwt.ExpiredSignatureError("expired"),
            jwt.InvalidTokenError("invalid refreshed token"),
        ]
    )
    refresh_mock = AsyncMock(
        return_value={
            "access_token": "bad-access-token",
            "refresh_token": "new-refresh-token",
            "id_token": "id-token",
            "expires_in": 300,
            "refresh_expires_in": 1800,
        }
    )

    with (
        patch("ecc_auth.session.verify_access_token", verify_mock),
        patch("ecc_auth.session.refresh_token_request", refresh_mock),
    ):
        client.cookies.set("kc_access_token", "expired-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/protected")

    assert response.status_code == 401
    assert response.json() == {"detail": "Session expired"}
    cookie_headers = _cookie_headers(response)
    assert any(header.startswith("kc_access_token=") for header in cookie_headers)
    assert any(header.startswith("kc_refresh_token=") for header in cookie_headers)


def test_refresh_returns_503_when_refresh_token_handler_crashes() -> None:
    refresh_handler = AsyncMock(side_effect=RuntimeError("boom"))
    client = _make_client(refresh_token_handler=refresh_handler)

    client.cookies.set("kc_refresh_token", "refresh-token")
    result = client.post("/api/auth/refresh")

    assert result.status_code == 503
    assert result.json() == {"detail": "Authentication service unavailable"}


def test_dependency_returns_session_expired_on_terminal_refresh_failure() -> None:
    client = _make_client()
    verify_mock = AsyncMock(side_effect=jwt.ExpiredSignatureError("expired"))
    request = httpx.Request("POST", "https://keycloak.example.com/token")
    upstream_response = httpx.Response(status_code=401, request=request)
    refresh_mock = AsyncMock(
        side_effect=httpx.HTTPStatusError(
            "refresh expired",
            request=request,
            response=upstream_response,
        )
    )

    with (
        patch("ecc_auth.session.verify_access_token", verify_mock),
        patch("ecc_auth.session.refresh_token_request", refresh_mock),
    ):
        client.cookies.set("kc_access_token", "expired-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/protected")

    assert response.status_code == 401
    assert response.json() == {"detail": "Session expired"}


def test_optional_dependency_propagates_terminal_refresh_failure() -> None:
    client = _make_client()
    verify_mock = AsyncMock(side_effect=jwt.ExpiredSignatureError("expired"))
    request = httpx.Request("POST", "https://keycloak.example.com/token")
    upstream_response = httpx.Response(status_code=401, request=request)
    refresh_mock = AsyncMock(
        side_effect=httpx.HTTPStatusError(
            "refresh expired",
            request=request,
            response=upstream_response,
        )
    )

    with (
        patch("ecc_auth.session.verify_access_token", verify_mock),
        patch("ecc_auth.session.refresh_token_request", refresh_mock),
    ):
        client.cookies.set("kc_access_token", "expired-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/protected-optional")

    assert response.status_code == 200
    assert response.json() == {"identityIsNone": True}
    cookie_headers = _cookie_headers(response)
    assert any(header.startswith("kc_access_token=") for header in cookie_headers)
    assert any(header.startswith("kc_refresh_token=") for header in cookie_headers)


def test_dependency_returns_503_when_refresh_service_is_unavailable() -> None:
    client = _make_client()
    verify_mock = AsyncMock(side_effect=jwt.ExpiredSignatureError("expired"))
    request = httpx.Request("POST", "https://keycloak.example.com/token")
    upstream_response = httpx.Response(status_code=503, request=request)
    refresh_mock = AsyncMock(
        side_effect=httpx.HTTPStatusError(
            "upstream down",
            request=request,
            response=upstream_response,
        )
    )

    with (
        patch("ecc_auth.session.verify_access_token", verify_mock),
        patch("ecc_auth.session.refresh_token_request", refresh_mock),
    ):
        client.cookies.set("kc_access_token", "expired-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/protected")

    assert response.status_code == 503
    assert response.json() == {"detail": "Authentication service unavailable"}
