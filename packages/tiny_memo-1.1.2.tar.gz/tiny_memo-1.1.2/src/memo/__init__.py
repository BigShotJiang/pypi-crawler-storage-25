# Memo package initialization
