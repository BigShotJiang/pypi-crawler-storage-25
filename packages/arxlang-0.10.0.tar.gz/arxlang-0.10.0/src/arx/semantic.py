"""
title: Semantic analysis module.
"""
