"""Batched concurrent ingestion (RLM-1e).

Provides ``ingest_batch()`` which runs multiple items through the pipeline
concurrently using ``asyncio.TaskGroup`` + ``Semaphore`` + ``to_thread``.

Thread safety: each task calls ``ingest()`` via ``to_thread()``.  Known
shared-state races (cache fills, FalkorDB writes) are benign — see
``docs/features/RLM-1e/design.md`` for the full analysis.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass
from typing import Any, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from smartmemory.smart_memory import SmartMemory

logger = logging.getLogger(__name__)

# Max retries for rate-limit (429) errors
_MAX_RATE_LIMIT_RETRIES = 3
_INITIAL_BACKOFF_S = 1.0


def _clear_last_fields(memory: "SmartMemory") -> None:
    """Reset all _last_* ingest state to None/empty.

    Called before and after batch to ensure these fields don't hold
    nondeterministic results from concurrent workers.
    """
    memory._last_trajectory = None
    memory._last_token_summary = None
    memory._last_entities = []
    memory._last_relations = []
    memory._last_procedure_match = None
    memory._last_ontology_version = ""
    memory._last_ontology_registry_id = ""
    memory._last_unresolved_entities = []
    memory._last_constraint_violations = []


@dataclass
class BatchIngestResult:
    """Result for a single item in a batch ingest."""

    item_id: Optional[str] = None
    error: Optional[str] = None
    duration_ms: float = 0.0
    queued: Optional[bool] = None  # Set when sync=False (async ingest)

    @property
    def ok(self) -> bool:
        return self.error is None


@dataclass
class BatchMetrics:
    """Aggregate metrics for a batch ingest run."""

    total_items: int = 0
    succeeded: int = 0
    failed: int = 0
    total_duration_ms: float = 0.0
    items_per_second: float = 0.0
    max_concurrent_used: int = 0
    rate_limit_hits: int = 0

    def to_dict(self) -> dict:
        return {
            "total_items": self.total_items,
            "succeeded": self.succeeded,
            "failed": self.failed,
            "total_duration_ms": round(self.total_duration_ms, 2),
            "items_per_second": round(self.items_per_second, 2),
            "max_concurrent_used": self.max_concurrent_used,
            "rate_limit_hits": self.rate_limit_hits,
        }


@dataclass
class BatchIngestResponse:
    """Full response from ingest_batch including results and metrics."""

    results: List[BatchIngestResult]
    metrics: BatchMetrics


async def ingest_batch(
    memory: "SmartMemory",
    items: list,
    max_concurrent: int = 8,
    **ingest_kwargs: Any,
) -> BatchIngestResponse:
    """Ingest multiple items concurrently.

    Each item runs through the full ``ingest()`` pipeline in a separate
    thread via ``asyncio.to_thread()``.  Concurrency is capped by a
    ``Semaphore(max_concurrent)``.

    All keyword arguments are forwarded to ``ingest()`` per item (context,
    pipeline_config, extract_decisions, extract_reasoning, adapter_name,
    converter_name, extractor_name, enricher_names, conversation_context,
    sync, auto_challenge).

    Args:
        memory: SmartMemory instance (shared across threads).
        items: List of items to ingest (str, dict, or MemoryItem).
        max_concurrent: Maximum concurrent LLM calls (default 8).
        **ingest_kwargs: Forwarded to ``memory.ingest()`` per item.

    Returns:
        ``BatchIngestResponse`` with results list and aggregate metrics.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent}")
    if not items:
        _clear_last_fields(memory)
        return BatchIngestResponse(results=[], metrics=BatchMetrics())

    # Clear all _last_* fields before any work — they are undefined during
    # batch (multiple concurrent ingest() calls race on these).
    _clear_last_fields(memory)

    # Pre-create the pipeline runner on the main thread to avoid
    # concurrent _create_pipeline_runner() races.
    if memory._pipeline_runner is None:
        memory._pipeline_runner = memory._create_pipeline_runner()

    semaphore = asyncio.Semaphore(max_concurrent)
    results: List[BatchIngestResult] = [BatchIngestResult() for _ in items]

    # Metrics tracking (thread-safe via atomic int operations)
    import threading

    _lock = threading.Lock()
    _rate_limit_hits = [0]
    _max_active = [0]
    _active = [0]

    batch_t0 = time.perf_counter()

    async def _ingest_one(index: int, item: Any) -> None:
        t0 = time.perf_counter()
        retries = 0
        backoff = _INITIAL_BACKOFF_S

        while True:
            should_retry = False
            async with semaphore:
                with _lock:
                    _active[0] += 1
                    _max_active[0] = max(_max_active[0], _active[0])
                try:
                    result = await asyncio.to_thread(memory.ingest, item, **ingest_kwargs)
                    elapsed = (time.perf_counter() - t0) * 1000.0

                    # ingest() returns str (sync) or dict (async)
                    if isinstance(result, dict):
                        item_id = result.get("item_id")
                        queued = result.get("queued")
                    else:
                        item_id = str(result) if result else None
                        queued = None

                    results[index] = BatchIngestResult(
                        item_id=item_id, duration_ms=round(elapsed, 2), queued=queued,
                    )
                    return
                except Exception as exc:
                    # Check for rate-limit errors (429)
                    is_rate_limit = "429" in str(exc) or "rate" in str(exc).lower()
                    if is_rate_limit and retries < _MAX_RATE_LIMIT_RETRIES:
                        retries += 1
                        with _lock:
                            _rate_limit_hits[0] += 1
                        logger.warning(
                            "RLM-1e: Rate limit hit for item %d, retry %d/%d after %.1fs",
                            index,
                            retries,
                            _MAX_RATE_LIMIT_RETRIES,
                            backoff,
                        )
                        should_retry = True
                    else:
                        elapsed = (time.perf_counter() - t0) * 1000.0
                        results[index] = BatchIngestResult(error=str(exc), duration_ms=round(elapsed, 2))
                        return
                finally:
                    with _lock:
                        _active[0] -= 1

            if not should_retry:
                return

            # Rate-limit backoff (outside semaphore — don't starve ready work)
            await asyncio.sleep(backoff)
            backoff *= 2.0

    try:
        async with asyncio.TaskGroup() as tg:
            for i, item in enumerate(items):
                tg.create_task(_ingest_one(i, item))
    finally:
        # Clear _last_* — workers repopulated them nondeterministically.
        # Runs on success, failure, or cancellation.
        _clear_last_fields(memory)

    # Build aggregate metrics
    batch_elapsed = (time.perf_counter() - batch_t0) * 1000.0
    succeeded = sum(1 for r in results if r.ok)
    failed = sum(1 for r in results if not r.ok)
    items_per_second = (len(items) / (batch_elapsed / 1000.0)) if batch_elapsed > 0 else 0.0

    metrics = BatchMetrics(
        total_items=len(items),
        succeeded=succeeded,
        failed=failed,
        total_duration_ms=round(batch_elapsed, 2),
        items_per_second=round(items_per_second, 2),
        max_concurrent_used=_max_active[0],
        rate_limit_hits=_rate_limit_hits[0],
    )

    return BatchIngestResponse(results=results, metrics=metrics)
