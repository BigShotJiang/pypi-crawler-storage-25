"""Cross-query Reciprocal Rank Fusion for multi-query result merging."""

from typing import List, Optional


def rrf_merge(
    result_lists: List[list],
    top_k: int,
    rrf_k: int = 60,
    weights: Optional[List[float]] = None,
) -> list:
    """Merge multiple ranked result lists using Reciprocal Rank Fusion.

    Args:
        result_lists: List of result lists, each sorted by relevance.
        top_k: Maximum number of results to return.
        rrf_k: RRF constant (default 60, matching VectorStore.search).
        weights: Per-channel weight multipliers (CORE-SEARCH-2a). Index i
            multiplies channel i's RRF contribution. None means equal
            weights (backward compatible with existing callers).

    Returns:
        Merged and re-ranked list of results, deduplicated by item_id.
    """
    if weights is None:
        weights = [1.0] * len(result_lists)

    scores: dict = {}
    items: dict = {}

    for i, result_list in enumerate(result_lists):
        w = weights[i] if i < len(weights) else 1.0
        for rank, item in enumerate(result_list, 1):
            item_id = getattr(item, "item_id", id(item))
            scores[item_id] = scores.get(item_id, 0.0) + w * (1.0 / (rrf_k + rank))
            if item_id not in items:
                items[item_id] = item

    sorted_ids = sorted(scores, key=lambda x: scores[x], reverse=True)
    return [items[iid] for iid in sorted_ids[:top_k]]
