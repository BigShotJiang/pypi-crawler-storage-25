"""Recall profile re-ranking (CORE-MULTI-AGENT-1 Phase 3).

Applies per-agent memory type weight multipliers to search results,
enabling different agents to get different rankings from the same
knowledge base. Default profile (empty/None) preserves current behavior.

Recall profiles are dicts with optional keys:
    memory_type_weights: dict[str, float]  — multipliers per memory type (default 1.0)

channel_weights support is deferred until CORE-SEARCH-2 Phase 3 delivers
named channel attribution. When available, channel_weights will multiply
per-channel scores before RRF fusion (profile weights * channel weights).

Example profile for a "skeptical" agent that favors decisions and procedures:
    {"memory_type_weights": {"decision": 2.0, "procedural": 1.5, "episodic": 0.5}}
"""

from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


def apply_recall_profile(
    results: list[Any],
    profile: Optional[dict],
) -> list[Any]:
    """Re-rank search results by applying recall profile weights.

    Args:
        results: Search results (MemoryItem instances with .memory_type and optional score).
        profile: Recall profile dict with optional memory_type_weights.
                 None or empty dict = no-op (preserves original ranking).

    Returns:
        Re-ranked results list. Original list is not mutated.
    """
    if not profile or not results:
        return results

    weights = profile.get("memory_type_weights")
    if not weights:
        return results

    def score_key(item: Any) -> float:
        memory_type = getattr(item, "memory_type", None) or ""
        multiplier = weights.get(memory_type, 1.0)
        # Use existing score if available, otherwise use position-based score
        base_score = getattr(item, "score", None)
        if base_score is None:
            base_score = 1.0
        return base_score * multiplier

    return sorted(results, key=score_key, reverse=True)
