"""Sweep scorer — identify optimal parameter values (SWEEP-1a).

Scores sweep results by finding the parameter value that maximizes
the primary metric with minimal regression on secondary metrics.
"""

from __future__ import annotations

import logging
from typing import List

from smartmemory.sweep.result import SweepResult

logger = logging.getLogger(__name__)

# Metrics where lower values are better
_LOWER_IS_BETTER = {"duration_ms", "rejected_count", "violation_count", "error_count", "error_rate"}


class SweepScorer:
    """Score sweep results and identify optimal parameter values."""

    def score(self, result: SweepResult) -> SweepResult:
        """Compute recommendation from sweep results.

        Strategy: find the value that maximizes the primary metric
        (first metric in alphabetical order if not specified, or the
        metric_name from SweepParamConfig). If multiple values tie,
        prefer the one closest to the current value.

        Mutates and returns the same SweepResult with recommendation fields set.
        """
        if not result.values_tested:
            return result

        # Determine primary metric
        all_metrics = set()
        for vm in result.values_tested:
            all_metrics.update(vm.metrics.keys())

        if not all_metrics:
            return result

        # Use caller-specified metric if set and available, otherwise auto-detect
        if result.primary_metric and result.primary_metric in all_metrics:
            primary = result.primary_metric
        elif "entity_count" in all_metrics:
            primary = "entity_count"
        else:
            primary = sorted(all_metrics)[0]

        # Write back the primary metric actually used (for persisted output)
        result.primary_metric = primary

        higher = result.higher_is_better

        # Filter out variants with no successful replays (empty metrics = failed)
        scorable = [(i, vm) for i, vm in enumerate(result.values_tested) if vm.metrics]
        if not scorable:
            return result

        # Find best value for primary metric (direction-aware)
        best_idx = -1
        best_primary = -float("inf") if higher else float("inf")
        for i, vm in scorable:
            val = vm.metrics.get(primary, 0.0)
            is_better = val > best_primary if higher else val < best_primary
            is_tie = abs(val - best_primary) < 1e-9
            # On tie, prefer value closest to current
            if is_better or (is_tie and best_idx >= 0 and abs(vm.value - result.current_value) < abs(result.values_tested[best_idx].value - result.current_value)):
                best_primary = val
                best_idx = i

        if best_idx < 0:
            return result

        best = result.values_tested[best_idx]
        result.recommended_value = best.value

        # Compute improvement vs current value (direction-aware)
        current_vm = None
        for vm in result.values_tested:
            if abs(vm.value - result.current_value) < 0.0001:
                current_vm = vm
                break

        if current_vm and current_vm.metrics.get(primary, 0.0) != 0:
            current_primary = current_vm.metrics[primary]
            if higher:
                result.improvement_pct = round(((best_primary - current_primary) / abs(current_primary)) * 100, 2)
            else:
                # For lower-is-better, reduction is improvement
                result.improvement_pct = round(((current_primary - best_primary) / abs(current_primary)) * 100, 2)
        else:
            result.improvement_pct = 0.0

        # Compute Pareto frontier
        result.pareto_indices = self._pareto_frontier(result.values_tested)

        # Build tradeoff narrative
        result.tradeoff_narrative = self._build_narrative(
            result,
            primary,
            best_idx,
        )

        return result

    def _pareto_frontier(self, points: list) -> List[int]:
        """Return indices of Pareto-optimal points.

        A point is Pareto-optimal if no other point dominates it
        on ALL metrics simultaneously.
        """
        if not points:
            return []

        # Collect all metric names
        all_keys = set()
        for p in points:
            all_keys.update(p.metrics.keys())
        keys = sorted(all_keys)

        if not keys:
            return list(range(len(points)))

        def _is_better_or_eq(val_j: float, val_i: float, metric: str) -> bool:
            """Direction-aware comparison: j is at least as good as i."""
            if metric in _LOWER_IS_BETTER:
                return val_j <= val_i
            return val_j >= val_i

        def _is_strictly_better(val_j: float, val_i: float, metric: str) -> bool:
            """Direction-aware strict comparison: j is better than i."""
            if metric in _LOWER_IS_BETTER:
                return val_j < val_i
            return val_j > val_i

        pareto: List[int] = []
        for i, pi in enumerate(points):
            if not pi.metrics:  # skip failed variants
                continue
            dominated = False
            for j, pj in enumerate(points):
                if i == j or not pj.metrics:
                    continue
                # Check if j dominates i (j >= i on all, j > i on at least one)
                all_geq = all(_is_better_or_eq(pj.metrics.get(k, 0), pi.metrics.get(k, 0), k) for k in keys)
                any_gt = any(_is_strictly_better(pj.metrics.get(k, 0), pi.metrics.get(k, 0), k) for k in keys)
                if all_geq and any_gt:
                    dominated = True
                    break
            if not dominated:
                pareto.append(i)

        return pareto

    def _build_narrative(
        self,
        result: SweepResult,
        primary: str,
        best_idx: int,
    ) -> str:
        """Build a human-readable tradeoff narrative."""
        best = result.values_tested[best_idx]
        parts = [f"Best {primary}={best.metrics.get(primary, 0):.2f} at {best.value:.3f}"]

        if result.improvement_pct != 0.0:
            direction = "improvement" if result.improvement_pct > 0 else "regression"
            parts.append(f"({result.improvement_pct:+.1f}% {direction} vs current {result.current_value:.3f})")

        # Note any regressions on secondary metrics
        if len(result.values_tested) > 1:
            current_vm = None
            for vm in result.values_tested:
                if abs(vm.value - result.current_value) < 0.0001:
                    current_vm = vm
                    break

            if current_vm and current_vm.metrics:
                regressions = []
                for key in sorted(best.metrics.keys()):
                    if key == primary or key not in current_vm.metrics:
                        continue
                    curr = current_vm.metrics[key]
                    rec = best.metrics.get(key, 0)
                    # Direction-aware regression detection (>5% worse or any increase from zero)
                    if key in _LOWER_IS_BETTER:
                        if curr == 0 and rec > 0:  # any increase from zero baseline
                            regressions.append(f"{key} {curr:.2f}→{rec:.2f}")
                        elif curr > 0 and rec > curr * 1.05:  # increased by >5%
                            regressions.append(f"{key} {curr:.2f}→{rec:.2f}")
                    else:
                        if curr > 0 and rec < curr * 0.95:  # decreased by >5%
                            regressions.append(f"{key} {curr:.2f}→{rec:.2f}")
                if regressions:
                    parts.append(f"Regressions: {', '.join(regressions)}")

        return ". ".join(parts) + "."
