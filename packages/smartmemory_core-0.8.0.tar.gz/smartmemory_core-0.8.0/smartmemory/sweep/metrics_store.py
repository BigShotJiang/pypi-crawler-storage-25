"""Persistent metrics store for pipeline sweep analysis (SWEEP-1a).

Snapshots Redis aggregation buckets from MetricsConsumer into SQLite
for 30-day retention.  Redis buckets expire after 24h; this store
preserves them for long-term parameter analysis.

Pattern follows ``smartmemory/grounding/sqlite_store.py``:
WAL mode, threading lock, ``_create_tables()``.
"""

from __future__ import annotations

import logging
import sqlite3
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from smartmemory.pipeline.metrics_consumer import MetricsConsumer

logger = logging.getLogger(__name__)

# Metric field names emitted by MetricsConsumer._parse_stage_bucket
_STAGE_METRIC_FIELDS = (
    "count",
    "avg_latency_ms",
    "p95_latency_ms",
    "error_count",
    "error_rate",
    "total_entities",
    "total_relations",
)


class SweepMetricsStore:
    """SQLite store for pipeline metrics history (30-day retention)."""

    def __init__(self, db_path: str | Path):
        self._db_path = str(db_path)
        self._lock = threading.Lock()
        Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.row_factory = sqlite3.Row
        self._create_tables()

    def _create_tables(self) -> None:
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS pipeline_metrics_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                stage_name TEXT NOT NULL,
                metric_name TEXT NOT NULL,
                value REAL NOT NULL,
                bucket_ts REAL NOT NULL,
                UNIQUE(stage_name, metric_name, bucket_ts)
            );
            CREATE INDEX IF NOT EXISTS idx_metrics_stage_ts
                ON pipeline_metrics_history(stage_name, metric_name, bucket_ts);
        """)

    def flush_from_redis(self, consumer: "MetricsConsumer", hours: int = 24) -> int:
        """Read Redis aggregation buckets and persist to SQLite.

        Uses ``consumer.get_aggregated("stage", hours)`` which returns
        flat derived records.  Each record's metric fields are stored
        as separate rows.

        Returns:
            Number of rows upserted.
        """
        # Drain pending stream events into aggregation buckets first
        try:
            consumer.run()
        except Exception:
            logger.debug("SWEEP-1a: MetricsConsumer.run() failed (non-fatal)")

        records = consumer.get_aggregated("stage", hours=hours)
        if not records:
            return 0

        rows_to_upsert: list[tuple] = []
        for record in records:
            stage = record.get("stage", "")
            ts_str = record.get("timestamp", "")
            if not stage or not ts_str:
                continue

            # Convert ISO timestamp to epoch
            try:
                dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                bucket_ts = dt.timestamp()
            except (ValueError, TypeError):
                continue

            for field_name in _STAGE_METRIC_FIELDS:
                value = record.get(field_name)
                if value is not None:
                    rows_to_upsert.append((stage, field_name, float(value), bucket_ts))

        if not rows_to_upsert:
            return 0

        with self._lock:
            self._conn.executemany(
                """INSERT OR REPLACE INTO pipeline_metrics_history
                   (stage_name, metric_name, value, bucket_ts)
                   VALUES (?, ?, ?, ?)""",
                rows_to_upsert,
            )
            self._conn.commit()

        return len(rows_to_upsert)

    def query(
        self,
        stage: Optional[str] = None,
        metric: Optional[str] = None,
        start: Optional[float] = None,
        end: Optional[float] = None,
    ) -> List[Dict[str, Any]]:
        """Query metric history.

        Returns:
            List of {stage_name, metric_name, value, bucket_ts} dicts.
        """
        conditions: list[str] = []
        params: list[Any] = []

        if stage:
            conditions.append("stage_name = ?")
            params.append(stage)
        if metric:
            conditions.append("metric_name = ?")
            params.append(metric)
        if start is not None:
            conditions.append("bucket_ts >= ?")
            params.append(start)
        if end is not None:
            conditions.append("bucket_ts <= ?")
            params.append(end)

        where = f" WHERE {' AND '.join(conditions)}" if conditions else ""
        sql = f"SELECT stage_name, metric_name, value, bucket_ts FROM pipeline_metrics_history{where} ORDER BY bucket_ts ASC"

        cursor = self._conn.execute(sql, params)
        return [dict(row) for row in cursor.fetchall()]

    def cleanup(self, retention_days: int = 30) -> int:
        """Delete rows older than retention_days.

        Returns:
            Number of rows deleted.
        """
        cutoff = time.time() - (retention_days * 86400)
        with self._lock:
            cursor = self._conn.execute(
                "DELETE FROM pipeline_metrics_history WHERE bucket_ts < ?",
                (cutoff,),
            )
            self._conn.commit()
            return cursor.rowcount

    def close(self) -> None:
        """Close the SQLite connection."""
        self._conn.close()
