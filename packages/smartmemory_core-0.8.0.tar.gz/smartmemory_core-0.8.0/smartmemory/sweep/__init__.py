"""Pipeline parameter sweep — measure and optimize config parameters (SWEEP-1a)."""
