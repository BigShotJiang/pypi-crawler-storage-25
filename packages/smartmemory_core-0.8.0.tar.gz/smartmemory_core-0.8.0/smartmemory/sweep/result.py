"""Sweep result dataclasses (SWEEP-1a)."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class SweepValueMetrics:
    """Metrics collected at a single parameter value."""

    value: float
    metrics: Dict[str, float] = field(default_factory=dict)
    sample_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "value": self.value,
            "metrics": self.metrics,
            "sample_count": self.sample_count,
        }


@dataclass
class SweepResult:
    """Result of a single-parameter sweep."""

    parameter_path: str = ""
    primary_metric: str = ""  # metric to optimize (empty = auto-detect)
    higher_is_better: bool = True  # False for duration_ms, rejected_count, etc.
    current_value: float = 0.0
    values_tested: List[SweepValueMetrics] = field(default_factory=list)
    recommended_value: Optional[float] = None
    improvement_pct: float = 0.0
    tradeoff_narrative: str = ""
    pareto_indices: List[int] = field(default_factory=list)
    started_at: str = ""
    completed_at: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "parameter_path": self.parameter_path,
            "primary_metric": self.primary_metric,
            "higher_is_better": self.higher_is_better,
            "current_value": self.current_value,
            "values_tested": [v.to_dict() for v in self.values_tested],
            "recommended_value": self.recommended_value,
            "improvement_pct": round(self.improvement_pct, 2),
            "tradeoff_narrative": self.tradeoff_narrative,
            "pareto_indices": self.pareto_indices,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
        }

    def to_jsonl_line(self) -> str:
        """Single JSON line for JSONL output."""
        return json.dumps(self.to_dict(), separators=(",", ":"))

    def to_report(self) -> str:
        """Human-readable report string."""
        lines = [
            f"Parameter: {self.parameter_path}",
            f"Current value: {self.current_value}",
            f"Values tested: {len(self.values_tested)}",
        ]
        if self.recommended_value is not None:
            lines.append(f"Recommended: {self.recommended_value} ({self.improvement_pct:+.1f}%)")
        if self.tradeoff_narrative:
            lines.append(f"Tradeoff: {self.tradeoff_narrative}")

        lines.append("")
        lines.append(f"{'Value':>8}  {'Samples':>7}  Metrics")
        lines.append("-" * 60)
        for vm in self.values_tested:
            metrics_str = ", ".join(f"{k}={v:.2f}" for k, v in sorted(vm.metrics.items()))
            marker = " *" if vm.value == self.recommended_value else ""
            lines.append(f"{vm.value:>8.3f}  {vm.sample_count:>7}  {metrics_str}{marker}")

        return "\n".join(lines)
