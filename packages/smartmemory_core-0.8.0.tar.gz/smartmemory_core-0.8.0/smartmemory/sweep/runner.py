"""Sweep runner — replays recent items with varied pipeline config (SWEEP-1a).

For each parameter value in the sweep range, constructs a PipelineConfig
variant, replays sample items through the pipeline in preview mode (no
storage side-effects), and collects output metrics.
"""

from __future__ import annotations

import copy
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, TYPE_CHECKING

from smartmemory.pipeline.config import PipelineConfig
from smartmemory.pipeline.state import PipelineState
from smartmemory.sweep.config import SweepConfig
from smartmemory.sweep.result import SweepResult, SweepValueMetrics

if TYPE_CHECKING:
    from smartmemory.pipeline.runner import PipelineRunner

logger = logging.getLogger(__name__)


def _get_param(config: PipelineConfig, dot_path: str) -> Any:
    """Get a nested parameter value by dot-path.

    E.g. ``_get_param(config, "extraction.constrain.confidence_threshold")``
    returns ``config.extraction.constrain.confidence_threshold``.
    """
    obj = config
    for part in dot_path.split("."):
        obj = getattr(obj, part)
    return obj


def _set_param(config: PipelineConfig, dot_path: str, value: Any) -> None:
    """Set a nested parameter value by dot-path.

    E.g. ``_set_param(config, "extraction.constrain.confidence_threshold", 0.6)``
    sets ``config.extraction.constrain.confidence_threshold = 0.6``.

    Raises ``AttributeError`` if the path is invalid.
    """
    parts = dot_path.split(".")
    obj = config
    for part in parts[:-1]:
        obj = getattr(obj, part)
    setattr(obj, parts[-1], value)


def _collect_metrics(state: PipelineState) -> Dict[str, float]:
    """Extract downstream metrics from a completed pipeline state."""
    return {
        "entity_count": float(len(state.entities or [])),
        "relation_count": float(len(state.relations or [])),
        "rejected_count": float(len(state.rejected or [])),
        "duration_ms": sum(state.stage_timings.values()),
        "link_count": float(len(state.links or {})),
        "violation_count": float(len(state.constraint_violations or [])),
    }


def _arange(start: float, stop: float, step: float) -> List[float]:
    """Generate float range values, inclusive of start, up to but not exceeding stop."""
    if step <= 0:
        raise ValueError(f"step must be positive, got {step}")
    if start > stop:
        raise ValueError(f"range_min ({start}) must be <= range_max ({stop})")
    values = []
    v = start
    while v <= stop + step * 0.001:  # small epsilon for float rounding
        values.append(round(v, 10))
        v += step
    return values


class SweepRunner:
    """Run single-parameter sweeps by replaying items through the pipeline."""

    def __init__(self, pipeline_runner: "PipelineRunner"):
        self._runner = pipeline_runner

    def run(self, config: SweepConfig, sample_texts: List[str]) -> SweepResult:
        """Run a single-parameter sweep.

        Args:
            config: Sweep configuration (Phase 1: single param).
            sample_texts: Text content of recent items to replay.

        Returns:
            SweepResult with per-value metrics.
        """
        if not config.params:
            raise ValueError("SweepConfig.params must contain at least one parameter")

        param = config.params[0]  # Phase 1: single parameter
        # Enforce sample_size from config
        sample_texts = sample_texts[: config.sample_size]
        # Use default() as baseline for current_value (production config)
        default_config = PipelineConfig.default()
        current_value = _get_param(default_config, param.parameter_path)
        # Sweep in preview mode (no storage side-effects)
        base_config = PipelineConfig.preview()
        values = _arange(param.range_min, param.range_max, param.step)

        started_at = datetime.now(timezone.utc).isoformat()
        values_tested: List[SweepValueMetrics] = []

        for value in values:
            variant = copy.deepcopy(base_config)
            _set_param(variant, param.parameter_path, value)

            # Replay all samples with this variant
            sample_metrics: List[Dict[str, float]] = []
            for text in sample_texts:
                try:
                    state = self._runner.run(text, variant)
                    sample_metrics.append(_collect_metrics(state))
                except Exception as exc:
                    logger.warning(
                        "SWEEP-1a: Sample replay failed for %s=%.4f: %s",
                        param.parameter_path,
                        value,
                        exc,
                    )

            # Average metrics across samples
            if sample_metrics:
                avg_metrics: Dict[str, float] = {}
                for key in sample_metrics[0]:
                    avg_metrics[key] = round(sum(m[key] for m in sample_metrics) / len(sample_metrics), 4)
            else:
                avg_metrics = {}

            values_tested.append(
                SweepValueMetrics(
                    value=value,
                    metrics=avg_metrics,
                    sample_count=len(sample_metrics),
                )
            )

        return SweepResult(
            parameter_path=param.parameter_path,
            primary_metric=param.metric_name,
            higher_is_better=param.higher_is_better,
            current_value=float(current_value),
            values_tested=values_tested,
            started_at=started_at,
            completed_at=datetime.now(timezone.utc).isoformat(),
        )
