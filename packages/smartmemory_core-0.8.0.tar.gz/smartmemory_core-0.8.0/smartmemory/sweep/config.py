"""Sweep configuration dataclasses (SWEEP-1a)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class SweepParamConfig:
    """Configuration for sweeping a single parameter."""

    parameter_path: str  # dot-notation, e.g. "extraction.constrain.confidence_threshold"
    range_min: float
    range_max: float
    step: float
    metric_name: str = ""  # downstream metric to optimize (e.g. "entity_count")
    higher_is_better: bool = True  # False for duration_ms, rejected_count, violation_count


@dataclass
class SweepConfig:
    """Top-level sweep configuration."""

    params: List[SweepParamConfig] = field(default_factory=list)
    sample_size: int = 50
