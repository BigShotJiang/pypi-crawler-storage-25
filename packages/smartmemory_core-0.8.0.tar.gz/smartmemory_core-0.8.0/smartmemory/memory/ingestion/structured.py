"""Structured ingestion protocol and handler registry (CORE-STRUCT-1).

Provides the StructuredHandler protocol for schema-mapped data ingestion
and a thread-safe registry for handler lookup and index management.
"""

from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING, Dict, Optional, Protocol, runtime_checkable

from smartmemory.models.ingestion_strategy import IngestionStrategy

if TYPE_CHECKING:
    from smartmemory.graph.backends.backend import SmartGraphBackend
    from smartmemory.models.memory_item import MemoryItem

logger = logging.getLogger(__name__)


@runtime_checkable
class StructuredHandler(Protocol):
    """Protocol for structured data handlers.

    Each handler knows how to validate, convert, declare edges and indexes
    for a specific schema type. Structural subtyping — no inheritance required.
    """

    strategy: IngestionStrategy
    schema_name: str
    embed: Optional[bool]  # None = defer to strategy default; True/False = override

    def validate(self, data: dict) -> bool:
        """Validate input data against handler's schema. Return True if valid."""
        ...

    def to_memory_item(self, data: dict) -> MemoryItem:
        """Convert validated data to a MemoryItem."""
        ...

    def get_edges(self, data: dict, item_id: str) -> list[tuple[str, str, str, dict]]:
        """Return edges to create: [(source_id, target_id, edge_type, properties), ...]."""
        ...

    def get_indexes(self) -> list[str]:
        """Return SQL DDL statements for typed indexes (IF NOT EXISTS)."""
        ...


class StructuredHandlerRegistry:
    """Thread-safe registry for structured data handlers.

    Handlers are registered by schema name. Index creation is tracked
    per (schema_name, backend_id) to support multiple backends and test isolation.
    """

    def __init__(self) -> None:
        self._handlers: Dict[str, StructuredHandler] = {}
        self._indexes_created: set[tuple[str, int]] = set()
        self._lock = threading.RLock()
        self._register_defaults()

    def _register_defaults(self) -> None:
        """Register built-in handlers (CORE-STRUCT-1 Phase 1b/1c, CORE-GAPS-2)."""
        import importlib

        _defaults = [
            ("decision", "smartmemory.memory.ingestion.handlers.decision", "DecisionHandler"),
            ("tool_call", "smartmemory.memory.ingestion.handlers.tool_call", "ToolCallHandler"),
            ("plan_task", "smartmemory.memory.ingestion.handlers.plan_task", "PlanTaskHandler"),
            ("conversation_turn", "smartmemory.memory.ingestion.handlers.conversation_turn", "ConversationTurnHandler"),
            ("hook_capture", "smartmemory.memory.ingestion.handlers.hook_capture", "HookCaptureHandler"),
            ("seed_item", "smartmemory.memory.ingestion.handlers.seed_item", "SeedItemHandler"),
            ("code_entity", "smartmemory.memory.ingestion.handlers.code_entity", "CodeEntityHandler"),
            ("plan", "smartmemory.memory.ingestion.handlers.plan", "PlanHandler"),
            ("anchor", "smartmemory.memory.ingestion.handlers.anchor", "AnchorHandler"),
            ("document", "smartmemory.memory.ingestion.handlers.document", "DocumentHandler"),
        ]
        for schema_name, module_path, class_name in _defaults:
            try:
                mod = importlib.import_module(module_path)
                handler_cls = getattr(mod, class_name)
                self.register(schema_name, handler_cls())
            except Exception as e:
                logger.debug(f"Structured handler '{schema_name}' not available: {e}")

    def register(self, schema_name: str, handler: StructuredHandler) -> None:
        """Register a handler for a schema name."""
        with self._lock:
            if schema_name in self._handlers:
                logger.warning(f"Structured handler '{schema_name}' already registered, overwriting")
            self._handlers[schema_name] = handler
            logger.info(f"Registered structured handler: {schema_name} (strategy={handler.strategy.value})")

    def get(self, schema_name: str) -> StructuredHandler:
        """Get handler by schema name. Raises KeyError if not registered."""
        with self._lock:
            if schema_name not in self._handlers:
                available = ", ".join(sorted(self._handlers.keys())) or "(none)"
                raise KeyError(
                    f"No structured handler registered for schema '{schema_name}'. Available schemas: {available}"
                )
            return self._handlers[schema_name]

    def ensure_indexes(self, schema_name: str, backend: SmartGraphBackend) -> None:
        """Create handler-declared indexes on the given backend. Idempotent."""
        cache_key = (schema_name, id(backend))
        with self._lock:
            if cache_key in self._indexes_created:
                return
            handler = self._handlers.get(schema_name)
            if handler is None:
                return
            indexes = handler.get_indexes()
            if indexes:
                backend.ensure_indexes(indexes)
                logger.debug(f"Created {len(indexes)} indexes for schema '{schema_name}'")
            self._indexes_created.add(cache_key)

    def reset_index_cache(self) -> None:
        """Clear the index creation cache. For tests with fresh databases."""
        with self._lock:
            self._indexes_created.clear()

    @property
    def schemas(self) -> list[str]:
        """List registered schema names."""
        with self._lock:
            return sorted(self._handlers.keys())


# Module-level singleton
_REGISTRY: Optional[StructuredHandlerRegistry] = None
_REGISTRY_LOCK = threading.Lock()


def get_structured_registry() -> StructuredHandlerRegistry:
    """Get the global structured handler registry (created on first call)."""
    global _REGISTRY
    if _REGISTRY is None:
        with _REGISTRY_LOCK:
            if _REGISTRY is None:
                _REGISTRY = StructuredHandlerRegistry()
    return _REGISTRY


def reset_structured_registry() -> None:
    """Reset the global registry. For tests."""
    global _REGISTRY
    with _REGISTRY_LOCK:
        _REGISTRY = None
