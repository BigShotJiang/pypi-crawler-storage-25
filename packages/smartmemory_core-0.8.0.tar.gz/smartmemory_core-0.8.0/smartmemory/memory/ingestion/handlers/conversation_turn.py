"""ConversationTurnHandler — structured ingestion for conversation replay (CORE-STRUCT-1 Phase 1b).

Strategy: APPEND — high-volume session replay data.
"""

from __future__ import annotations

from typing import Optional

from smartmemory.models.ingestion_strategy import IngestionStrategy
from smartmemory.models.memory_item import MemoryItem


class ConversationTurnHandler:
    """Structured handler for conversation turn records."""

    strategy = IngestionStrategy.APPEND
    schema_name = "conversation_turn"
    embed: Optional[bool] = None

    def validate(self, data: dict) -> bool:
        """Require content and role."""
        content = data.get("content")
        role = data.get("role")
        return (
            isinstance(content, str)
            and len(content.strip()) > 0
            and isinstance(role, str)
            and role in ("user", "assistant", "system")
        )

    def to_memory_item(self, data: dict) -> MemoryItem:
        return MemoryItem(
            content=data["content"],
            memory_type="conversation_turn",
            metadata={
                "role": data["role"],
                "session_id": data.get("session_id"),
                "turn_index": data.get("turn_index"),
            },
        )

    def get_edges(self, data: dict, item_id: str) -> list[tuple[str, str, str, dict]]:
        return []

    def get_indexes(self) -> list[str]:
        return [
            "CREATE INDEX IF NOT EXISTS idx_conversation_turn_session "
            "ON nodes(json_extract(properties, '$.session_id')) WHERE memory_type='conversation_turn'",
            "CREATE INDEX IF NOT EXISTS idx_conversation_turn_role "
            "ON nodes(json_extract(properties, '$.role')) WHERE memory_type='conversation_turn'",
        ]
