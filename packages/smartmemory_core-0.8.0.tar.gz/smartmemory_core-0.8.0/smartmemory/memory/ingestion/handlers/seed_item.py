"""SeedItemHandler — structured ingestion for seed pack items (CORE-STRUCT-1 Phase 1b).

Strategy: FULL — seed pack items are user-facing reference knowledge that needs embedding.
Sets reference=True (CORE-PROPS-1 Phase 6: pack content is reference data).
"""

from __future__ import annotations

from typing import Optional

from smartmemory.models.ingestion_strategy import IngestionStrategy
from smartmemory.models.memory_item import MemoryItem


class SeedItemHandler:
    """Structured handler for seed pack item records."""

    strategy = IngestionStrategy.FULL
    schema_name = "seed_item"
    embed: Optional[bool] = None  # defer to FULL default (embed)

    def validate(self, data: dict) -> bool:
        """Require content."""
        content = data.get("content")
        return isinstance(content, str) and len(content.strip()) > 0

    def to_memory_item(self, data: dict) -> MemoryItem:
        meta = dict(data.get("metadata", {}))
        meta["reference"] = True  # CORE-PROPS-1 Phase 6: pack content is reference data
        return MemoryItem(
            content=data["content"],
            memory_type=data.get("memory_type", "semantic"),
            reference=True,
            metadata=meta,
        )

    def get_edges(self, data: dict, item_id: str) -> list[tuple[str, str, str, dict]]:
        return []

    def get_indexes(self) -> list[str]:
        return []
