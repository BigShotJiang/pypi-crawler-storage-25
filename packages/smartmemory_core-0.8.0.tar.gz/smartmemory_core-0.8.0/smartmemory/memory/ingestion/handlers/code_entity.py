"""CodeEntityHandler — structured ingestion for code entities (CORE-STRUCT-1 Phase 1c).

Strategy: INDEXED with embed=True — code entities are queried by typed fields
(entity_type, file_path, repo) and also benefit from semantic search via embedding.

Coexists with CodeIndexer (bulk repo indexing). This handler provides a single-entity
path via ingest_structured() for incremental updates.
"""

from __future__ import annotations

from smartmemory.models.ingestion_strategy import IngestionStrategy
from smartmemory.models.memory_item import MemoryItem

# Valid entity types matching CodeEntity model (code/models.py:17)
_VALID_ENTITY_TYPES = frozenset({"module", "class", "function", "route", "test"})


class CodeEntityHandler:
    """Structured handler for individual code entity records."""

    strategy = IngestionStrategy.INDEXED
    schema_name = "code_entity"
    embed: bool = True  # Override INDEXED default — code entities get embeddings

    def validate(self, data: dict) -> bool:
        """Require name, entity_type (valid), file_path, line_number (int), repo."""
        return (
            isinstance(data.get("name"), str)
            and len(data["name"].strip()) > 0
            and isinstance(data.get("entity_type"), str)
            and data["entity_type"] in _VALID_ENTITY_TYPES
            and isinstance(data.get("file_path"), str)
            and len(data["file_path"].strip()) > 0
            and isinstance(data.get("line_number"), int)
            and isinstance(data.get("repo"), str)
            and len(data["repo"].strip()) > 0
        )

    def to_memory_item(self, data: dict) -> MemoryItem:
        """Convert code entity data to MemoryItem.

        Produces the same node schema as CodeEntity.to_properties() (code/models.py:35-60).
        Deterministic item_id matches CodeEntity.item_id (code/models.py:31-33).
        """
        # Deterministic ID: code::{repo}::{file_path}::{name}
        item_id = f"code::{data['repo']}::{data['file_path']}::{data['name']}"

        metadata: dict = {
            "entity_type": data["entity_type"],
            "file_path": data["file_path"],
            "line_number": data["line_number"],
            "repo": data["repo"],
        }
        if data.get("docstring"):
            metadata["docstring"] = data["docstring"][:500]
        if data.get("decorators"):
            metadata["decorators"] = ",".join(data["decorators"])
        if data.get("bases"):
            metadata["bases"] = ",".join(data["bases"])
        if data.get("http_method"):
            metadata["http_method"] = data["http_method"]
        if data.get("http_path"):
            metadata["http_path"] = data["http_path"]
        if data.get("commit_hash"):
            metadata["commit_hash"] = data["commit_hash"]
        if data.get("indexed_at"):
            metadata["indexed_at"] = data["indexed_at"]

        return MemoryItem(
            content=data["name"],
            memory_type="code",
            item_id=item_id,
            metadata=metadata,
        )

    def get_edges(self, data: dict, item_id: str) -> list[tuple[str, str, str, dict]]:
        """Pass through caller-provided edges.

        Unlike CodeIndexer which resolves cross-file calls via SymbolTable,
        the handler trusts the caller to provide resolved edge IDs.
        """
        edges: list[tuple[str, str, str, dict]] = []
        for edge in data.get("edges", []):
            if not isinstance(edge, dict):
                continue
            source = edge.get("source_id", item_id)
            target = edge.get("target_id", item_id)
            rel_type = edge.get("relation_type", "DEFINES")
            props = edge.get("properties", {})
            edges.append((source, target, rel_type, props))
        return edges

    def get_indexes(self) -> list[str]:
        """Typed indexes for code entity queries."""
        return [
            "CREATE INDEX IF NOT EXISTS idx_code_entity_type "
            "ON nodes(json_extract(properties, '$.entity_type')) WHERE memory_type='code'",
            "CREATE INDEX IF NOT EXISTS idx_code_repo "
            "ON nodes(json_extract(properties, '$.repo')) WHERE memory_type='code'",
            "CREATE INDEX IF NOT EXISTS idx_code_file_path "
            "ON nodes(json_extract(properties, '$.file_path')) WHERE memory_type='code'",
        ]
