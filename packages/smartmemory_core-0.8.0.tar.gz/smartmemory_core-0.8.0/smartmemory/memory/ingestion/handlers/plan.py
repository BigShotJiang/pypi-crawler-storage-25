"""PlanHandler — structured ingestion for plan containers (CORE-GAPS-2 Phase 1).

Strategy: INDEXED — plans queried by status, plan_id. No embedding.
Plan containers link to plan_task nodes via shared plan_id field.
"""

from __future__ import annotations

from typing import Optional
from uuid import uuid4

from smartmemory.models.ingestion_strategy import IngestionStrategy
from smartmemory.models.memory_item import MemoryItem


class PlanHandler:
    """Structured handler for plan container records."""

    strategy = IngestionStrategy.INDEXED
    schema_name = "plan"
    embed: Optional[bool] = None

    def validate(self, data: dict) -> bool:
        """Require non-empty content (plan title)."""
        content = data.get("content")
        return isinstance(content, str) and len(content.strip()) > 0

    def to_memory_item(self, data: dict) -> MemoryItem:
        plan_id = data.get("plan_id") or f"plan_{uuid4().hex[:12]}"
        return MemoryItem(
            content=data["content"],
            memory_type="plan",
            item_id=plan_id,
            metadata={
                "plan_id": plan_id,
                "status": data.get("status", "active"),
                "total_tasks": data.get("total_tasks", 0),
                "completed_tasks": data.get("completed_tasks", 0),
                "context": data.get("context", ""),
                "created_by": data.get("created_by", ""),
            },
        )

    def get_edges(self, data: dict, item_id: str) -> list[tuple[str, str, str, dict]]:
        return []

    def get_indexes(self) -> list[str]:
        return [
            "CREATE INDEX IF NOT EXISTS idx_plan_status "
            "ON nodes(json_extract(properties, '$.status')) WHERE memory_type='plan'",
            "CREATE INDEX IF NOT EXISTS idx_plan_plan_id "
            "ON nodes(json_extract(properties, '$.plan_id')) WHERE memory_type='plan'",
        ]
