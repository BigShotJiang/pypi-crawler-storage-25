"""Structured ingestion handlers (CORE-STRUCT-1 Phase 1b/1c/2, CORE-GAPS-2).

Each handler implements the StructuredHandler protocol for a specific schema type.
"""

from smartmemory.memory.ingestion.handlers.code_entity import CodeEntityHandler
from smartmemory.memory.ingestion.handlers.conversation_turn import ConversationTurnHandler
from smartmemory.memory.ingestion.handlers.decision import DecisionHandler
from smartmemory.memory.ingestion.handlers.document import DocumentHandler
from smartmemory.memory.ingestion.handlers.hook_capture import HookCaptureHandler
from smartmemory.memory.ingestion.handlers.plan import PlanHandler
from smartmemory.memory.ingestion.handlers.plan_task import PlanTaskHandler
from smartmemory.memory.ingestion.handlers.seed_item import SeedItemHandler
from smartmemory.memory.ingestion.handlers.tool_call import ToolCallHandler

__all__ = [
    "CodeEntityHandler",
    "ConversationTurnHandler",
    "DecisionHandler",
    "DocumentHandler",
    "HookCaptureHandler",
    "PlanHandler",
    "PlanTaskHandler",
    "SeedItemHandler",
    "ToolCallHandler",
]
