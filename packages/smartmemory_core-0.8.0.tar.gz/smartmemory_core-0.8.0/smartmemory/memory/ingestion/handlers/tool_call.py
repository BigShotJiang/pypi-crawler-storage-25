"""ToolCallHandler — structured ingestion for tool call telemetry (CORE-STRUCT-1 Phase 1b).

Strategy: APPEND — high-volume telemetry, searchable by recency and tool name only.
"""

from __future__ import annotations

from typing import Optional

from smartmemory.models.ingestion_strategy import IngestionStrategy
from smartmemory.models.memory_item import MemoryItem


class ToolCallHandler:
    """Structured handler for tool call records."""

    strategy = IngestionStrategy.APPEND
    schema_name = "tool_call"
    embed: Optional[bool] = None

    def validate(self, data: dict) -> bool:
        """Require tool_name."""
        return isinstance(data.get("tool_name"), str) and len(data["tool_name"].strip()) > 0

    def to_memory_item(self, data: dict) -> MemoryItem:
        content = data.get("result", "") or f"tool_call:{data['tool_name']}"
        return MemoryItem(
            content=content,
            memory_type="tool_call",
            metadata={
                "tool_name": data["tool_name"],
                "args": data.get("args", {}),
                "success": data.get("success", True),
                "duration_ms": data.get("duration_ms"),
                "session_id": data.get("session_id"),
            },
        )

    def get_edges(self, data: dict, item_id: str) -> list[tuple[str, str, str, dict]]:
        return []

    def get_indexes(self) -> list[str]:
        return [
            "CREATE INDEX IF NOT EXISTS idx_tool_call_name "
            "ON nodes(json_extract(properties, '$.tool_name')) WHERE memory_type='tool_call'",
        ]
