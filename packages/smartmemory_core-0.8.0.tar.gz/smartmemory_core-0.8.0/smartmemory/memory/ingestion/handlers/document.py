"""DocumentHandler — structured ingestion for document content (CORE-STRUCT-1 Phase 2).

Strategy: FULL — documents are user-facing knowledge that needs embedding for search.
Accepts pre-parsed document content with optional metadata (title, author, source,
file_type, page_count). Callers handle file I/O and parsing; this handler handles
storage, embedding, and indexing.

For large documents, callers should chunk content before calling ingest_structured()
multiple times with the same source_url to link chunks. The existing chunking utilities
in smartmemory/utils/chunking.py can be used for this.
"""

from __future__ import annotations

from typing import Optional

from smartmemory.models.ingestion_strategy import IngestionStrategy
from smartmemory.models.memory_item import MemoryItem


class DocumentHandler:
    """Structured handler for document records."""

    strategy = IngestionStrategy.FULL
    schema_name = "document"
    embed: Optional[bool] = None  # defer to FULL default (embed)

    def validate(self, data: dict) -> bool:
        """Require non-empty content."""
        content = data.get("content")
        return isinstance(content, str) and len(content.strip()) > 0

    def to_memory_item(self, data: dict) -> MemoryItem:
        # Pass through caller metadata first, then overlay known fields (known fields win)
        meta: dict = {}
        if data.get("metadata"):
            meta.update(data["metadata"])

        # Document metadata — set after passthrough so known fields are never overwritten
        if data.get("title"):
            meta["title"] = data["title"]
        if data.get("author"):
            meta["author"] = data["author"]
        if data.get("source_url"):
            meta["source_url"] = data["source_url"]
        if data.get("file_type"):
            meta["file_type"] = data["file_type"]
        if data.get("page_count") is not None:
            meta["page_count"] = data["page_count"]
        if data.get("section"):
            meta["section"] = data["section"]
        if data.get("chunk_index") is not None:
            meta["chunk_index"] = data["chunk_index"]
            meta["total_chunks"] = data.get("total_chunks", 1)

        return MemoryItem(
            content=data["content"],
            memory_type="document",
            metadata=meta,
            origin=data.get("origin", "structured:document"),
        )

    def get_edges(self, data: dict, item_id: str) -> list[tuple[str, str, str, dict]]:
        """Create PART_OF edge if this is a chunk of a larger document."""
        edges = []
        parent_id = data.get("parent_document_id")
        if parent_id:
            edges.append((
                item_id,
                parent_id,
                "PART_OF",
                {"origin": "structured:document", "confidence": 1.0},
            ))
        return edges

    def get_indexes(self) -> list[str]:
        return [
            "CREATE INDEX IF NOT EXISTS idx_document_file_type ON nodes(json_extract(properties, '$.file_type'))",
            "CREATE INDEX IF NOT EXISTS idx_document_source_url ON nodes(json_extract(properties, '$.source_url'))",
        ]
