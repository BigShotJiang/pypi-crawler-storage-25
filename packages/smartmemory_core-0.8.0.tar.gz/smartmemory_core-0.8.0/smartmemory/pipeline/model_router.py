"""Stage-based model routing for the pipeline (RLM-1d).

PipelineModelRouter maps pipeline stage names to LLM model identifiers.
The runner sets a contextvar before each stage execution; call_llm()
reads it as part of its model resolution chain.

Precedence (highest to lowest):
    1. Explicit ``model=`` param in call_llm()
    2. Router mapping for the current stage (this module)
    3. Config section lookup
    4. get_default_model() env-var fallback
"""

from __future__ import annotations

import contextvars
import logging
import os
from dataclasses import dataclass, field
from typing import ClassVar, Dict, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Contextvar — set by PipelineRunner._execute_stage(), read by call_llm()
# ---------------------------------------------------------------------------

_current_stage_model: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "_current_stage_model", default=None
)


def get_routed_model() -> Optional[str]:
    """Return the model routed for the currently executing pipeline stage.

    Returns None when called outside a pipeline stage execution context
    or when no router is configured for the current stage.
    """
    return _current_stage_model.get()


# ---------------------------------------------------------------------------
# PipelineModelRouter
# ---------------------------------------------------------------------------


@dataclass
class PipelineModelRouter:
    """Maps pipeline stage names to LLM model identifiers.

    Usage::

        # Preset (auto-detects provider from env):
        router = PipelineModelRouter.balanced()
        memory = SmartMemory(model_router=router)

        # Explicit mapping:
        router = PipelineModelRouter(stage_models={"llm_extract": "gpt-4o"})
        memory = SmartMemory(model_router=router)
    """

    stage_models: Dict[str, str] = field(default_factory=dict)
    default: Optional[str] = None

    def get(self, stage_name: str) -> Optional[str]:
        """Return the model for *stage_name*, falling back to *default*."""
        return self.stage_models.get(stage_name, self.default)

    # ------------------------------------------------------------------ #
    # Provider-aware tier resolution
    # ------------------------------------------------------------------ #

    # Tier definitions per provider.
    #   "fast"    = cheapest / lowest-latency
    #   "mid"     = mid-tier (default-class)
    #   "quality" = best available
    PROVIDER_TIERS: ClassVar[Dict[str, Dict[str, str]]] = {
        "openai": {
            "fast": "gpt-4o-mini",
            "mid": "gpt-4o-mini",
            "quality": "gpt-4o",
        },
        "groq": {
            "fast": "llama-3.1-8b-instant",
            "mid": "llama-3.3-70b-versatile",
            "quality": "llama-3.3-70b-versatile",
        },
        "anthropic": {
            "fast": "claude-3-5-haiku-latest",
            "mid": "claude-3-5-haiku-latest",
            "quality": "claude-3-5-sonnet-latest",
        },
        "gemini": {
            "fast": "gemini-2.0-flash-lite",
            "mid": "gemini-2.0-flash",
            "quality": "gemini-2.5-pro",
        },
    }

    @staticmethod
    def _detect_provider() -> str:
        """Detect active LLM provider from environment variables.

        Priority mirrors ``get_default_model()`` in ``utils/llm.py``:
        1. Explicit model env var → infer provider from model name
        2. Provider-specific API keys → first match wins
        3. Fallback → ``"openai"``

        Note: this intentionally covers more providers (Anthropic, Gemini)
        than ``get_default_model()`` which only auto-detects OpenAI and Groq.
        Presets can route ``llm_extract`` to a provider that non-routed stages
        don't use — this is intentional since the router is an explicit opt-in.
        """
        if m := os.getenv("SMARTMEMORY_LLM_MODEL"):
            if "llama" in m or "mixtral" in m:
                return "groq"
            if "claude" in m:
                return "anthropic"
            if "gemini" in m:
                return "gemini"
            return "openai"
        if os.getenv("GROQ_API_KEY"):
            return "groq"
        if os.getenv("ANTHROPIC_API_KEY"):
            return "anthropic"
        # Only check GEMINI_API_KEY — call_llm() does not accept GOOGLE_API_KEY
        # for Gemini models (it checks GEMINI_API_KEY at llm.py:124).
        if os.getenv("GEMINI_API_KEY"):
            return "gemini"
        return "openai"

    @classmethod
    def _resolve_tier(cls, tier: str) -> str:
        """Resolve a tier name to a concrete model for the active provider."""
        provider = cls._detect_provider()
        tiers = cls.PROVIDER_TIERS.get(provider, cls.PROVIDER_TIERS["openai"])
        return tiers.get(tier, tiers["mid"])

    # ------------------------------------------------------------------ #
    # Presets
    #
    # Phase 1: default=None so only explicitly mapped stages are routed.
    # This prevents accidental routing of stages like reasoning_detect
    # that pass provider-specific API keys alongside a falsey model.
    # ------------------------------------------------------------------ #

    @classmethod
    def cost_optimized(cls) -> PipelineModelRouter:
        """Cheapest model for extraction. Best for high-volume ingestion."""
        fast = cls._resolve_tier("fast")
        return cls(stage_models={"llm_extract": fast})

    @classmethod
    def quality_optimized(cls) -> PipelineModelRouter:
        """Best model for extraction. Best for critical knowledge."""
        quality = cls._resolve_tier("quality")
        return cls(stage_models={"llm_extract": quality})

    @classmethod
    def balanced(cls) -> PipelineModelRouter:
        """Mid-tier model for extraction. Good cost/quality trade-off."""
        mid = cls._resolve_tier("mid")
        return cls(stage_models={"llm_extract": mid})
