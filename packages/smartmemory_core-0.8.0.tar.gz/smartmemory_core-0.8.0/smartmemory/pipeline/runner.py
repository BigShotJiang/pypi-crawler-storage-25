"""PipelineRunner — orchestrates StageCommands through a Transport.

Supports full run, breakpoints (run_to), resumption (run_from),
rollback (undo_to), and per-stage retry with configurable failure modes.
"""

from __future__ import annotations

import logging
import time
from dataclasses import replace
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from smartmemory.observability.tracing import trace_span
from smartmemory.pipeline.config import PipelineConfig
from smartmemory.pipeline.protocol import StageCommand
from smartmemory.pipeline.state import PipelineState
from smartmemory.pipeline.token_tracker import PipelineTokenTracker
from smartmemory.pipeline.model_router import _current_stage_model
from smartmemory.pipeline.trajectory import (
    PipelineTrajectory,
    StageTrace,
    TrajectoryWriter,
    summarize_input,
    summarize_output,
)
from smartmemory.pipeline.transport import InProcessTransport, Transport

logger = logging.getLogger(__name__)


def _entity_name(entity: Any, index: int) -> str:
    """Extract display name from an entity (MemoryItem or dict)."""
    if hasattr(entity, "metadata") and isinstance(getattr(entity, "metadata", None), dict):
        name = entity.metadata.get("name")
        if name:
            return name
    if isinstance(entity, dict):
        return entity.get("name", f"entity_{index}")
    return getattr(entity, "name", f"entity_{index}")


class PipelineRunner:
    """Execute an ordered list of StageCommands."""

    def __init__(
        self,
        stages: List[StageCommand],
        transport: Optional[Transport] = None,
    ):
        self.stages = stages
        self.transport: Transport = transport or InProcessTransport()

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    def run(
        self,
        text: str,
        config: PipelineConfig,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> PipelineState:
        """Execute the full pipeline."""
        meta = metadata or {}
        tracker = PipelineTokenTracker(
            workspace_id=config.workspace_id,
            profile_name=config.profile_name,
        )
        state = PipelineState(
            text=text,
            raw_metadata=meta,
            mode=config.mode,
            workspace_id=config.workspace_id,
            started_at=datetime.now(timezone.utc),
            token_tracker=tracker,
            memory_type=meta.get("memory_type") or None,
        )
        return self._run_stages(state, config, self.stages)

    def run_to(
        self,
        text: str,
        config: PipelineConfig,
        stop_after: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> PipelineState:
        """Execute until (and including) the named stage, then stop."""
        meta = metadata or {}
        tracker = PipelineTokenTracker(
            workspace_id=config.workspace_id,
            profile_name=config.profile_name,
        )
        state = PipelineState(
            text=text,
            raw_metadata=meta,
            mode=config.mode,
            workspace_id=config.workspace_id,
            started_at=datetime.now(timezone.utc),
            token_tracker=tracker,
            memory_type=meta.get("memory_type") or None,
        )
        stages = self._stages_up_to(stop_after)
        return self._run_stages(state, config, stages)

    def run_from(
        self,
        state: PipelineState,
        config: PipelineConfig,
        start_from: Optional[str] = None,
        stop_after: Optional[str] = None,
    ) -> PipelineState:
        """Resume from a checkpoint.

        If *start_from* is ``None``, auto-detects the next stage from
        ``state.stage_history``.
        """
        if start_from is None:
            start_from = self._next_stage_name(state)
            if start_from is None:
                return state  # all stages already completed

        # Ensure a live tracker exists (deserialized checkpoints have None).
        if not isinstance(state.token_tracker, PipelineTokenTracker):
            tracker = PipelineTokenTracker(
                workspace_id=config.workspace_id,
                profile_name=config.profile_name,
            )
            state = replace(state, token_tracker=tracker)

        stages = self._stages_from(start_from, stop_after)
        return self._run_stages(state, config, stages)

    def undo_to(self, state: PipelineState, target: str) -> PipelineState:
        """Roll back stages in reverse until *target* (exclusive)."""
        history = list(state.stage_history)
        if target not in history:
            raise ValueError(f"Stage '{target}' not in history: {history}")

        target_idx = history.index(target)
        to_undo = history[target_idx + 1 :]

        stage_map = {s.name: s for s in self.stages}
        for stage_name in reversed(to_undo):
            stage = stage_map.get(stage_name)
            if stage is None:
                logger.warning("Cannot undo unknown stage '%s'", stage_name)
                continue
            state = stage.undo(state)
            state = replace(state, stage_history=[h for h in state.stage_history if h != stage_name])

        return state

    # ------------------------------------------------------------------ #
    # Internals
    # ------------------------------------------------------------------ #

    def _run_stages(
        self,
        state: PipelineState,
        config: PipelineConfig,
        stages: List[StageCommand],
    ) -> PipelineState:
        # RLM-1a: Initialize trajectory if enabled
        if config.trajectory.enabled and state.trajectory is None:
            state = replace(
                state,
                trajectory=PipelineTrajectory(
                    pipeline_profile=config.profile_name,
                    workspace_id=config.workspace_id,
                    started_at=datetime.now(timezone.utc).isoformat(),
                ),
            )

        for stage in stages:
            state = self._execute_stage(stage, state, config)
        state = replace(
            state,
            completed_at=datetime.now(timezone.utc),
        )

        # RLM-1a: Finalize trajectory and optionally write JSONL
        if state.trajectory is not None:
            state.trajectory.finalize(state)
            if config.trajectory.log_dir:
                try:
                    TrajectoryWriter(config.trajectory.log_dir).write(state.trajectory)
                except Exception as exc:
                    logger.warning("RLM-1a: Failed to write trajectory JSONL: %s", exc)

        return state

    def _execute_stage(
        self,
        stage: StageCommand,
        state: PipelineState,
        config: PipelineConfig,
    ) -> PipelineState:
        """Execute a single stage with retry logic.

        Uses per-stage retry policy from ``config.stage_retry_policies`` if set,
        otherwise falls back to the global ``config.retry``.
        """
        # Resolve retry parameters: per-stage policy takes precedence
        stage_policy = config.stage_retry_policies.get(stage.name)
        if stage_policy:
            max_retries = stage_policy.max_retries
            backoff = stage_policy.backoff_seconds
            backoff_multiplier = stage_policy.backoff_multiplier
            on_failure = stage_policy.on_failure
        else:
            max_retries = config.retry.max_retries
            backoff = config.retry.backoff_seconds
            backoff_multiplier = 2.0
            on_failure = config.retry.on_failure

        # RLM-1a: Capture pre-stage state for trajectory
        trajectory = state.trajectory
        _input_summary: Dict[str, Any] = {}
        if trajectory is not None and config.trajectory.enabled:
            _input_summary = summarize_input(stage.name, state)

        # RLM-1d: Set routed model contextvar for this stage
        _routed_model = config.model_router.get(stage.name) if config.model_router else None
        _router_token = _current_stage_model.set(_routed_model)
        try:
            return self._execute_stage_inner(
                stage, state, config, max_retries, backoff, backoff_multiplier,
                on_failure, trajectory, _input_summary,
            )
        finally:
            _current_stage_model.reset(_router_token)

    def _execute_stage_inner(
        self,
        stage: StageCommand,
        state: PipelineState,
        config: PipelineConfig,
        max_retries: int,
        backoff: float,
        backoff_multiplier: float,
        on_failure: str,
        trajectory,
        _input_summary: Dict[str, Any],
    ) -> PipelineState:
        """Inner execution with retry loop — extracted for RLM-1d contextvar wrapping."""
        last_exc: Optional[Exception] = None
        _stage_t0 = time.perf_counter()  # RLM-1a: track total wall-clock across retries
        for attempt in range(max_retries + 1):
            try:
                span_attrs = {
                    "memory_id": getattr(state, "item_id", None) or state.raw_metadata.get("run_id", ""),
                    "attempt": attempt + 1,
                }
                with trace_span(f"pipeline.{stage.name}", span_attrs) as span:
                    t0 = time.perf_counter()
                    new_state = self.transport.execute(stage, state, config)
                    elapsed = (time.perf_counter() - t0) * 1000.0
                    span.attributes["transport_ms"] = elapsed
                    span.attributes["entity_count"] = len(getattr(new_state, "entities", []) or [])
                    span.attributes["relation_count"] = len(getattr(new_state, "relations", []) or [])

                # CORE-MULTI-AGENT-1: Emit coordination events for multi-agent subscriptions
                self._emit_coordination_event(stage.name, state, new_state)

                # RLM-1a: Record successful stage trace
                if trajectory is not None:
                    _model = None
                    _prompt = 0
                    _completion = 0
                    _cost = 0.0
                    if new_state.token_tracker:
                        _stage_records = [
                            rec for (s, rec) in new_state.token_tracker._spent
                            if s == stage.name
                        ]
                        if _stage_records:
                            _model = _stage_records[-1].model
                            _prompt = sum(r.prompt_tokens for r in _stage_records)
                            _completion = sum(r.completion_tokens for r in _stage_records)
                            _cost = PipelineTokenTracker._estimate_cost(
                                [(stage.name, r) for r in _stage_records]
                            )
                    _output_summary = summarize_output(stage.name, state, new_state)
                    # Use total wall-clock when retries occurred (includes
                    # failed attempts + backoff), else just this attempt's elapsed
                    _trace_ms = (time.perf_counter() - _stage_t0) * 1000.0 if attempt > 0 else elapsed
                    trajectory.record_stage(StageTrace(
                        name=stage.name,
                        duration_ms=_trace_ms,
                        status="ok",
                        input_summary=_input_summary,
                        output_summary=_output_summary,
                        model=_model,
                        prompt_tokens=_prompt,
                        completion_tokens=_completion,
                        cost_usd=_cost,
                        attempt=attempt + 1,
                    ))

                # Use total wall-clock for stage_timings when retries occurred
                _timing_ms = (time.perf_counter() - _stage_t0) * 1000.0 if attempt > 0 else elapsed
                new_state = replace(
                    new_state,
                    stage_history=[*new_state.stage_history, stage.name],
                    stage_timings={**new_state.stage_timings, stage.name: _timing_ms},
                )
                return new_state
            except Exception as exc:
                last_exc = exc
                if attempt < max_retries:
                    logger.warning(
                        "Stage '%s' failed (attempt %d/%d): %s — retrying in %.1fs",
                        stage.name,
                        attempt + 1,
                        max_retries + 1,
                        exc,
                        backoff,
                    )
                    time.sleep(backoff)
                    backoff *= backoff_multiplier

        # All retries exhausted — undo partial work
        try:
            state = stage.undo(state)
        except Exception as undo_exc:
            logger.warning("Undo for stage '%s' failed: %s", stage.name, undo_exc)

        # RLM-1a: Record failed/skipped stage in trajectory
        _status = "skipped" if on_failure == "skip" else "failed"
        if trajectory is not None:
            _failed_elapsed = (time.perf_counter() - _stage_t0) * 1000.0
            trajectory.record_stage(StageTrace(
                name=stage.name,
                duration_ms=_failed_elapsed,
                status=_status,
                input_summary=_input_summary,
                output_summary={},
                attempt=max_retries + 1,
            ))

        if on_failure == "skip":
            logger.warning("Stage '%s' failed after %d attempts — skipping", stage.name, max_retries + 1)
            return replace(
                state,
                stage_history=[*state.stage_history, f"{stage.name}:skipped"],
            )

        # RLM-1a: On abort, finalize trajectory and write JSONL before raising
        if trajectory is not None:
            trajectory.finalize(state)
            if config.trajectory.log_dir:
                try:
                    TrajectoryWriter(config.trajectory.log_dir).write(trajectory)
                except Exception:
                    pass  # best-effort — don't mask the real error

        raise RuntimeError(f"Stage '{stage.name}' failed after {max_retries + 1} attempts") from last_exc

    # ------------------------------------------------------------------ #
    # Coordination events (CORE-MULTI-AGENT-1)
    # ------------------------------------------------------------------ #

    def _emit_coordination_event(
        self,
        stage_name: str,
        pre_state: PipelineState,
        post_state: PipelineState,
    ) -> None:
        """Emit semantic coordination events after pipeline stages complete.

        These are distinct from trace spans -- they describe what happened to
        the knowledge graph, not how long a function took.
        """
        try:
            from smartmemory.observability.events import emit_event
        except Exception:
            return

        workspace_id = post_state.workspace_id or ""
        source_agent_id = post_state.raw_metadata.get("source_agent_id", "")
        tenant_id = post_state.raw_metadata.get("tenant_id", "")

        try:
            if stage_name == "store" and post_state.item_id:
                entities_payload = [
                    {"name": _entity_name(e, i), "type": getattr(e, "entity_type", "ENTITY")}
                    for i, e in enumerate(post_state.entities or [])
                ]
                emit_event(
                    event_type="memory.stored",
                    component="pipeline",
                    operation="store",
                    data={
                        "node_id": post_state.item_id,
                        "memory_type": post_state.memory_type or "semantic",
                        "content_preview": (post_state.resolved_text or post_state.text or "")[:200],
                        "entities": entities_payload,
                        "relations": [],
                        "source_agent_id": source_agent_id,
                        "workspace_id": workspace_id,
                        "tenant_id": tenant_id,
                    },
                )

            elif stage_name == "link":
                links = post_state.links or {}
                for link_key, link_data in links.items():
                    if isinstance(link_data, dict):
                        target_id = link_data.get("target_id", "")
                        real_edge_type = link_data.get("edge_type", link_key)
                    else:
                        target_id = str(link_data)
                        real_edge_type = link_key
                    emit_event(
                        event_type="memory.linked",
                        component="pipeline",
                        operation="link",
                        data={
                            "source_id": post_state.item_id or "",
                            "target_id": target_id,
                            "edge_type": real_edge_type,
                            "source_agent_id": source_agent_id,
                            "workspace_id": workspace_id,
                            "tenant_id": tenant_id,
                        },
                    )

            elif stage_name == "enrich" and post_state.enrichments:
                for enrichment_type, enrichment_data in post_state.enrichments.items():
                    if enrichment_data:
                        emit_event(
                            event_type="memory.enriched",
                            component="pipeline",
                            operation="enrich",
                            data={
                                "node_id": post_state.item_id or "",
                                "enrichment_type": enrichment_type,
                                "source_agent_id": source_agent_id,
                                "workspace_id": workspace_id,
                                "tenant_id": tenant_id,
                            },
                        )
        except Exception as exc:
            logger.debug("Coordination event emission failed (non-fatal): %s", exc)

    # ------------------------------------------------------------------ #
    # Stage selection helpers
    # ------------------------------------------------------------------ #

    def _stages_up_to(self, stop_after: str) -> List[StageCommand]:
        result = []
        for s in self.stages:
            result.append(s)
            if s.name == stop_after:
                return result
        raise ValueError(f"Stage '{stop_after}' not found in pipeline stages")

    def _stages_from(self, start_from: str, stop_after: Optional[str] = None) -> List[StageCommand]:
        result = []
        started = False
        for s in self.stages:
            if s.name == start_from:
                started = True
            if started:
                result.append(s)
            if stop_after and s.name == stop_after:
                break
        if not started:
            raise ValueError(f"Stage '{start_from}' not found in pipeline stages")
        return result

    def _next_stage_name(self, state: PipelineState) -> Optional[str]:
        """Determine the next stage to run based on history."""
        completed = set(state.stage_history)
        for stage in self.stages:
            if stage.name not in completed:
                return stage.name
        return None
