"""Pipeline trajectory logging (RLM-1a).

Per-item JSONL trajectory recording of every pipeline stage: what ran,
what it produced, timing, LLM calls (with token counts and costs), and
entity/relation extraction decisions.  Enables debugging "why did this
item get wrong entities?" by tracing exactly which stage made the bad
decision.

Trajectory is attached to ``PipelineState`` as a mutable accumulator
(same pattern as ``PipelineTokenTracker``).
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from smartmemory.pipeline.state import PipelineState

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------ #
# Data models
# ------------------------------------------------------------------ #


@dataclass
class StageTrace:
    """Trace record for a single pipeline stage execution."""

    name: str
    duration_ms: float
    status: str  # "ok" | "skipped" | "failed"
    input_summary: Dict[str, Any] = field(default_factory=dict)
    output_summary: Dict[str, Any] = field(default_factory=dict)
    model: Optional[str] = None
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cost_usd: float = 0.0
    attempt: int = 1

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "duration_ms": round(self.duration_ms, 2),
            "status": self.status,
            "input_summary": self.input_summary,
            "output_summary": self.output_summary,
            "model": self.model,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "cost_usd": round(self.cost_usd, 8),
            "attempt": self.attempt,
        }


@dataclass
class PipelineTrajectory:
    """Complete trajectory of a pipeline execution."""

    item_id: Optional[str] = None
    pipeline_profile: str = "default"
    stages: List[StageTrace] = field(default_factory=list)
    total_duration_ms: float = 0.0
    total_tokens: int = 0
    total_cost_usd: float = 0.0
    started_at: str = ""
    completed_at: str = ""
    workspace_id: Optional[str] = None

    def record_stage(self, trace: StageTrace) -> None:
        """Append a stage trace record."""
        self.stages.append(trace)

    def finalize(self, state: "PipelineState") -> None:
        """Compute totals from recorded stages.

        Sets ``completed_at`` to now if ``state.completed_at`` is None
        (abort path).  Computes ``total_duration_ms`` from sum of stage
        durations, ``total_tokens`` and ``total_cost_usd`` from stage sums.
        Sets ``item_id`` from state if available.
        """
        self.item_id = state.item_id
        self.total_duration_ms = sum(s.duration_ms for s in self.stages)
        self.total_tokens = sum(s.prompt_tokens + s.completion_tokens for s in self.stages)
        self.total_cost_usd = sum(s.cost_usd for s in self.stages)

        if state.completed_at is not None:
            self.completed_at = state.completed_at.isoformat()
        else:
            self.completed_at = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "item_id": self.item_id,
            "pipeline_profile": self.pipeline_profile,
            "stages": [s.to_dict() for s in self.stages],
            "total_duration_ms": round(self.total_duration_ms, 2),
            "total_tokens": self.total_tokens,
            "total_cost_usd": round(self.total_cost_usd, 8),
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "workspace_id": self.workspace_id,
        }


# ------------------------------------------------------------------ #
# JSONL writer
# ------------------------------------------------------------------ #


class TrajectoryWriter:
    """Writes pipeline trajectories to daily-rotated JSONL files."""

    def __init__(self, log_dir: str | Path):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)

    def write(self, trajectory: PipelineTrajectory) -> Path:
        """Append one trajectory as a single JSON line.

        File: ``{log_dir}/trajectories-YYYY-MM-DD.jsonl``
        """
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        path = self.log_dir / f"trajectories-{today}.jsonl"
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(trajectory.to_dict(), separators=(",", ":")) + "\n")
        return path


# ------------------------------------------------------------------ #
# State summarization
# ------------------------------------------------------------------ #


def summarize_input(stage_name: str, state: "PipelineState") -> Dict[str, Any]:
    """Extract counts and flags from state before a stage runs."""
    text = state.resolved_text or state.text or ""

    if stage_name == "classify":
        return {"text_len": len(text), "memory_type": state.memory_type}

    if stage_name == "coreference":
        return {"text_len": len(text)}

    if stage_name == "simplify":
        return {"text_len": len(state.resolved_text or state.text or "")}

    if stage_name in ("entity_ruler", "llm_extract", "reasoning_detect"):
        return {"sentence_count": len(state.simplified_sentences)}

    if stage_name == "ontology_constrain":
        return {
            "ruler_entity_count": len(state.ruler_entities),
            "llm_entity_count": len(state.llm_entities),
            "llm_relation_count": len(state.llm_relations),
        }

    if stage_name == "store":
        return {
            "entity_count": len(state.entities),
            "relation_count": len(state.relations),
        }

    if stage_name == "compact":
        return {"item_id": state.item_id}

    if stage_name == "link":
        return {"item_id": state.item_id}

    if stage_name == "enrich":
        return {"item_id": state.item_id}

    if stage_name == "ground":
        return {"entity_count": len(state.entities)}

    if stage_name == "evolve":
        return {"item_id": state.item_id}

    return {}


def summarize_output(
    stage_name: str,
    pre_state: "PipelineState",
    post_state: "PipelineState",
) -> Dict[str, Any]:
    """Diff state after a stage to produce output summary."""

    if stage_name == "classify":
        return {"classified_types": list(post_state.classified_types)}

    if stage_name == "coreference":
        return {
            "resolved_text_len": len(post_state.resolved_text or ""),
            "changed": (post_state.resolved_text or "") != (pre_state.text or ""),
        }

    if stage_name == "simplify":
        return {"sentence_count": len(post_state.simplified_sentences)}

    if stage_name == "entity_ruler":
        return {"ruler_entity_count": len(post_state.ruler_entities)}

    if stage_name == "llm_extract":
        return {
            "llm_entity_count": len(post_state.llm_entities),
            "llm_relation_count": len(post_state.llm_relations),
            "extraction_status": post_state.extraction_status,
        }

    if stage_name == "reasoning_detect":
        return {"has_reasoning_trace": post_state.reasoning_trace is not None}

    if stage_name == "ontology_constrain":
        return {
            "entity_count": len(post_state.entities),
            "relation_count": len(post_state.relations),
            "rejected_count": len(post_state.rejected),
            "violation_count": len(post_state.constraint_violations),
        }

    if stage_name == "store":
        return {
            "item_id": post_state.item_id,
            "entity_id_count": len(post_state.entity_ids),
        }

    if stage_name == "compact":
        # Count how many fields were compacted (nullified)
        compacted = 0
        for field_name in ("simplified_sentences", "classified_types", "ruler_entities",
                           "llm_entities", "llm_relations", "promotion_candidates",
                           "rejected", "extraction_status"):
            pre_val = getattr(pre_state, field_name, None)
            post_val = getattr(post_state, field_name, None)
            if pre_val and not post_val:
                compacted += 1
        return {"fields_compacted": compacted}

    if stage_name == "link":
        return {"link_count": len(post_state.links)}

    if stage_name == "enrich":
        return {"enrichment_types": sorted(post_state.enrichments.keys())}

    if stage_name == "ground":
        # Count entities that gained grounding (have wikidata QID)
        grounded = 0
        for e in post_state.entities:
            if isinstance(e, dict):
                if e.get("qid"):
                    grounded += 1
            elif hasattr(e, "qid") and getattr(e, "qid", None):
                grounded += 1
        return {"grounded_count": grounded}

    if stage_name == "evolve":
        return {"evolution_types": sorted(post_state.evolutions.keys())}

    return {}
