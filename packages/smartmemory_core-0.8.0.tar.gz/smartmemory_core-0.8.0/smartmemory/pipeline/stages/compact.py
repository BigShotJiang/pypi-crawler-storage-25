"""Pipeline context compaction stage (RLM-1b).

Deterministic compaction checkpoint that strips intermediate pipeline
state fields after ``store`` has consumed them.  Reduces memory pressure
during concurrent bulk ingestion (RLM-1e).

Two compaction levels:
- **standard**: drops 6 extraction intermediates (ruler_entities, llm_entities,
  llm_relations, simplified_sentences, classified_types, promotion_candidates)
- **aggressive**: standard + rejected, extraction_status
"""

from __future__ import annotations

import logging
from dataclasses import replace
from typing import TYPE_CHECKING

from smartmemory.pipeline.protocol import StageCommand

if TYPE_CHECKING:
    from smartmemory.pipeline.config import PipelineConfig
    from smartmemory.pipeline.state import PipelineState

logger = logging.getLogger(__name__)

# Fields dropped at each compaction level
_STANDARD_FIELDS = {
    "simplified_sentences": [],
    "classified_types": [],
    "ruler_entities": [],
    "llm_entities": [],
    "llm_relations": [],
    "promotion_candidates": [],
}

_AGGRESSIVE_FIELDS = {
    **_STANDARD_FIELDS,
    "rejected": [],
    "extraction_status": None,
}


class CompactionStage(StageCommand):
    """Strip intermediate pipeline state fields after store."""

    name = "compact"

    def execute(self, state: "PipelineState", config: "PipelineConfig") -> "PipelineState":
        if not config.compaction.enabled:
            return state

        level = config.compaction.level

        if level == "none":
            return state

        if level == "aggressive":
            fields = _AGGRESSIVE_FIELDS
        else:
            fields = _STANDARD_FIELDS

        # Save compacted fields to _context for undo support (in-process only;
        # _context is not serialized by to_dict/from_dict).
        pre_compact = {k: getattr(state, k) for k in fields}
        ctx = dict(state._context)
        ctx["pre_compact"] = pre_compact

        return replace(state, _context=ctx, **fields)

    def undo(self, state: "PipelineState") -> "PipelineState":
        """Restore compacted fields from _context if available."""
        pre_compact = state._context.get("pre_compact")
        if not pre_compact:
            return state
        ctx = dict(state._context)
        ctx.pop("pre_compact", None)
        return replace(state, _context=ctx, **pre_compact)
