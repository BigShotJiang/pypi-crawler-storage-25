"""Data models for CORE-GAPS-1 anchor drift detection."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class DriftReport:
    """Result of comparing an anchor against recent outputs."""

    anchor_id: str
    anchor_content: str
    drift_score: float  # 0.0 = aligned, 1.0 = fully drifted
    missing_keywords: list[str]
    severity: str  # "none" | "mild" | "significant" | "critical"
