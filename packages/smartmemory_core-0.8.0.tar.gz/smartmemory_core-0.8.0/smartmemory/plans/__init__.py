"""Plan memory management and failure journal (CORE-GAPS-2).

Provides PlanManager for plan lifecycle, PlanQueries for retrieval,
and FailureJournal for agent error recovery.
"""

from smartmemory.plans.failure_journal import FailureJournal
from smartmemory.plans.manager import PlanManager
from smartmemory.plans.queries import PlanQueries

__all__ = ["FailureJournal", "PlanManager", "PlanQueries"]
