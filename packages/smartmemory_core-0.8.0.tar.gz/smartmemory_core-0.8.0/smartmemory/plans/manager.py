"""Plan lifecycle manager (CORE-GAPS-2 Phase 1).

Manages plan creation, task status tracking, completion, and failure.
Follows DecisionManager pattern (decisions/manager.py).

Usage:
    manager = PlanManager(smart_memory)
    result = manager.create("Auth redesign", tasks=[
        {"content": "Design JWT schema", "depends_on": []},
        {"content": "Implement token service", "depends_on": []},
    ])
    manager.update_task(result["plan_id"], result["task_ids"][0], "complete")
    manager.complete(result["plan_id"])
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any
from uuid import uuid4

from smartmemory.plans.queries import PlanQueries

VALID_TASK_STATUSES = {"pending", "in_progress", "complete", "blocked"}

if TYPE_CHECKING:
    from smartmemory.smart_memory import SmartMemory

logger = logging.getLogger(__name__)


class PlanManager:
    """Manage plan lifecycle — creation, task tracking, completion."""

    def __init__(self, memory: SmartMemory) -> None:
        self.memory = memory
        self.queries = PlanQueries(memory)

    def create(
        self,
        title: str,
        tasks: list[dict[str, Any]] | None = None,
        context: str = "",
        created_by: str = "",
    ) -> dict[str, Any]:
        """Create a plan container with optional task nodes.

        Args:
            title: Plan title/description.
            tasks: List of task dicts, each with "content" (required),
                   "depends_on" (optional list of task indices or IDs),
                   and "task_index" (optional).
            context: Why this plan was created.
            created_by: Session/agent that created it.

        Returns:
            Dict with "plan_id" and "task_ids".
        """
        tasks = tasks or []
        plan_id = f"plan_{uuid4().hex[:12]}"

        # Create plan container with task count known upfront
        self.memory.ingest_structured(
            {
                "content": title,
                "plan_id": plan_id,
                "context": context,
                "created_by": created_by,
                "total_tasks": len(tasks),
            },
            schema="plan",
        )

        # Create task nodes (two-pass: create first, then resolve index-based deps)
        task_ids = []
        raw_depends: list[list] = []
        for i, task_data in enumerate(tasks):
            task_content = task_data.get("content", "")
            raw_depends.append(task_data.get("depends_on", []))
            task_index = task_data.get("task_index", i)

            task_id = self.memory.ingest_structured(
                {
                    "content": task_content,
                    "plan_id": plan_id,
                    "status": "pending",
                    "depends_on": [],  # placeholder — resolved below
                    "task_index": task_index,
                },
                schema="plan_task",
            )
            task_ids.append(task_id)

        # Resolve depends_on: integer indices → actual task IDs, strings pass through
        for i, deps in enumerate(raw_depends):
            if not deps:
                continue
            resolved = []
            for dep in deps:
                if isinstance(dep, int) and 0 <= dep < len(task_ids):
                    resolved.append(task_ids[dep])
                else:
                    resolved.append(str(dep))  # assume it's a task ID string
            self.memory.update_properties(task_ids[i], {"depends_on": resolved})

        logger.info("Created plan %s with %d tasks", plan_id, len(tasks))
        return {"plan_id": plan_id, "task_ids": task_ids}

    def get(self, plan_id: str) -> dict[str, Any] | None:
        """Get plan container with all tasks."""
        return self.queries.get_plan_with_tasks(plan_id)

    def update_task(self, plan_id: str, task_id: str, status: str) -> None:
        """Update a task's status and recompute plan completion.

        Args:
            plan_id: Plan container ID.
            task_id: Task node ID.
            status: One of pending, in_progress, complete, blocked.

        Raises:
            ValueError: If status is not a valid task status.
        """
        if status not in VALID_TASK_STATUSES:
            raise ValueError(f"Invalid task status '{status}'. Must be one of: {sorted(VALID_TASK_STATUSES)}")
        self.memory.update_properties(task_id, {"status": status})
        self._recompute_completion(plan_id)

    def get_active(self) -> list[dict[str, Any]]:
        """Get all plans with status='active'."""
        return self.queries.get_active_plans()

    def get_next_tasks(self, plan_id: str) -> list[dict[str, Any]]:
        """Get pending tasks whose dependencies are all complete."""
        return self.queries.get_next_tasks(plan_id)

    def get_blocked_tasks(self, plan_id: str) -> list[dict[str, Any]]:
        """Get tasks with incomplete dependencies."""
        return self.queries.get_blocked_tasks(plan_id)

    def complete(self, plan_id: str, graduate: bool = False) -> str | None:
        """Mark plan as completed.

        Args:
            plan_id: Plan container ID.
            graduate: If True, create a decision record from the plan
                      with DERIVED_FROM edge back to plan_id.

        Returns:
            Decision ID if graduated, None otherwise.
        """
        self.memory.update_properties(plan_id, {"status": "completed"})
        logger.info("Completed plan %s (graduate=%s)", plan_id, graduate)

        if graduate:
            # Relies on DecisionHandler creating DERIVED_FROM edges from evidence_ids
            plan = self.queries.get_plan(plan_id)
            if plan:
                try:
                    decision_id = self.memory.ingest_structured(
                        {
                            "content": f"Plan completed: {plan.get('content', '')}",
                            "decision_type": "choice",
                            "source_type": "imported",
                            "evidence_ids": [plan_id],
                        },
                        schema="decision",
                    )
                    logger.info("Graduated plan %s to decision %s", plan_id, decision_id)
                    return decision_id
                except Exception as e:
                    logger.warning("Failed to graduate plan %s to decision: %s", plan_id, e)

        return None

    def fail(self, plan_id: str, reason: str) -> None:
        """Mark plan as failed with reason."""
        self.memory.update_properties(plan_id, {"status": "failed", "failure_reason": reason})
        logger.info("Failed plan %s: %s", plan_id, reason)

    def _recompute_completion(self, plan_id: str) -> None:
        """Recompute completed_tasks count on plan container."""
        tasks = self.queries.get_tasks_for_plan(plan_id)
        completed = sum(1 for t in tasks if t.get("status") == "complete")
        total = len(tasks)
        self.memory.update_properties(plan_id, {"completed_tasks": completed, "total_tasks": total})
