"""Failure journal for agent error recovery (CORE-GAPS-2 Phase 2).

Stores failures as episodic memories with origin=failure:agent provenance.
Enables check-before-retry to break retry loops across sessions.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

from smartmemory.models.memory_item import MemoryItem

if TYPE_CHECKING:
    from smartmemory.smart_memory import SmartMemory

logger = logging.getLogger(__name__)


class FailureJournal:
    """Log and query agent failures to prevent retry loops."""

    def __init__(self, memory: SmartMemory) -> None:
        self.memory = memory

    def log(
        self,
        error_type: str,
        content: str,
        context: str,
        plan_id: str | None = None,
        task_id: str | None = None,
        attempted_fix: str | None = None,
        resolution: str | None = None,
    ) -> str:
        """Store failure as episodic memory with origin=failure:agent.

        Uses add() not ingest() — stores + embeds without full pipeline overhead.
        Episodic type = FULL strategy = gets embedding for semantic search.

        Returns:
            item_id of the stored failure.
        """
        metadata: dict[str, Any] = {
            "error_type": error_type,
            "error_context": context,
            "origin": "failure:agent",
        }
        if plan_id:
            metadata["plan_id"] = plan_id
        if task_id:
            metadata["task_id"] = task_id
        if attempted_fix:
            metadata["attempted_fix"] = attempted_fix
        if resolution:
            metadata["resolution"] = resolution

        item = MemoryItem(
            content=content,
            memory_type="episodic",
            origin="failure:agent",
            metadata=metadata,
        )
        item_id = self.memory.add(item)
        logger.info("Logged failure %s: %s (%s)", item_id, error_type, context[:80])
        return item_id

    def check_before_retry(self, error_type: str, context: str, top_k: int = 3) -> list[dict[str, Any]]:
        """Search for matching past failures by error context.

        Two-pass: semantic search on context finds similar failures,
        then post-filter by error_type and origin prefix.

        Returns:
            List of failure dicts with resolution, attempted_fix, etc.
        """
        try:
            results = self.memory.search(query=context, memory_type="episodic", top_k=top_k * 3)
        except Exception as e:
            logger.warning("Failure search failed: %s", e)
            return []

        matches: list[dict[str, Any]] = []
        for item in results:
            meta = getattr(item, "metadata", {}) or {}
            # Filter: must be a failure with matching error_type
            origin = meta.get("origin", "") or getattr(item, "origin", "")
            if not origin.startswith("failure:"):
                continue
            if meta.get("error_type") != error_type:
                continue

            matches.append(
                {
                    "item_id": getattr(item, "item_id", None),
                    "content": getattr(item, "content", ""),
                    "error_type": meta.get("error_type"),
                    "error_context": meta.get("error_context"),
                    "resolution": meta.get("resolution"),
                    "attempted_fix": meta.get("attempted_fix"),
                    "plan_id": meta.get("plan_id"),
                    "task_id": meta.get("task_id"),
                }
            )
            if len(matches) >= top_k:
                break

        return matches

    def get_failures_for_plan(self, plan_id: str) -> list[dict[str, Any]]:
        """All failures linked to a plan via metadata.plan_id."""
        from smartmemory.graph.backends.sqlite import SQLiteBackend

        backend = self.memory._graph.backend
        if isinstance(backend, SQLiteBackend):
            with backend._lock:
                cursor = backend._conn.execute(
                    "SELECT item_id, properties FROM nodes "
                    "WHERE memory_type = 'episodic' "
                    "AND json_extract(properties, '$.origin') = 'failure:agent' "
                    "AND json_extract(properties, '$.plan_id') = ?",
                    (plan_id,),
                )
                rows = cursor.fetchall()
            return [self._to_failure_dict(row) for row in rows]

        # FalkorDB fallback — search + post-filter
        logger.warning("Failure plan query on non-SQLite backend — using search fallback")
        try:
            results = self.memory.search(query="failure error", memory_type="episodic", top_k=100)
        except Exception as e:
            logger.warning("Failure plan search fallback failed (returning empty): %s", e)
            return []
        return [
            self._to_failure_dict_from_item(item)
            for item in results
            if (getattr(item, "metadata", {}) or {}).get("plan_id") == plan_id
            and (getattr(item, "metadata", {}) or {}).get("origin", "").startswith("failure:")
        ]

    def _to_failure_dict(self, row: tuple) -> dict[str, Any]:
        """Convert raw SQLite (item_id, properties_json) row to failure dict."""
        props = json.loads(row[1])
        return {
            "item_id": row[0],
            "content": props.get("content", ""),
            "error_type": props.get("error_type"),
            "error_context": props.get("error_context"),
            "resolution": props.get("resolution"),
            "attempted_fix": props.get("attempted_fix"),
            "plan_id": props.get("plan_id"),
            "task_id": props.get("task_id"),
        }

    def _to_failure_dict_from_item(self, item: Any) -> dict[str, Any]:
        """Convert MemoryItem to failure dict."""
        meta = getattr(item, "metadata", {}) or {}
        return {
            "item_id": getattr(item, "item_id", None),
            "content": getattr(item, "content", ""),
            "error_type": meta.get("error_type"),
            "error_context": meta.get("error_context"),
            "resolution": meta.get("resolution"),
            "attempted_fix": meta.get("attempted_fix"),
            "plan_id": meta.get("plan_id"),
            "task_id": meta.get("task_id"),
        }
