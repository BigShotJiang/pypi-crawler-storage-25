from __future__ import annotations
import os
from pathlib import Path
import subprocess
from.auth_session import load_cli_config
LOCAL_COMPOSE_PROJECT_FILE='.gv-compose-project'
def normalize_api_url(value:str)->str:
	A=value.strip()
	if not A:raise ValueError('API URL cannot be empty.')
	if not A.startswith(('http://','https://')):raise ValueError('API URL must start with http:// or https://.')
	return A.rstrip('/')
def _repo_root()->Path:
	B=Path(__file__).resolve()
	for A in B.parents:
		if(A/LOCAL_COMPOSE_PROJECT_FILE).is_file()or(A/'docker-compose.yml').is_file():return A
	return B.parents[2]
def _stored_compose_project_name()->str|None:
	A=_repo_root()/LOCAL_COMPOSE_PROJECT_FILE
	try:B=A.read_text(encoding='utf-8').strip()
	except OSError:return
	return B or None
def _compose_env_candidates()->list[dict[str,str]|None]:
	C=os.getenv('COMPOSE_PROJECT_NAME','').strip();D=_stored_compose_project_name();B:list[dict[str,str]|None]=[]
	if C:A=os.environ.copy();A['COMPOSE_PROJECT_NAME']=C;B.append(A)
	elif D:A=os.environ.copy();A['COMPOSE_PROJECT_NAME']=D;B.append(A)
	B.append(None);return B
def _parse_compose_port_output(output:str)->str|None:
	D=[A.strip()for A in output.splitlines()if A.strip()]
	if not D:return
	B=D[0]
	if B.startswith('['):E,E,A=B.rpartition(':');return f"http://127.0.0.1:{A}"
	F,G,A=B.rpartition(':')
	if G and A.isdigit():
		C=F or'127.0.0.1'
		if C in{'0.0.0.0','::','[::]'}:C='127.0.0.1'
		return f"http://{C}:{A}"
def discover_local_api_url()->str|None:
	A=os.getenv('GV_API_URL','').strip()
	if A:return normalize_api_url(A)
	for C in _compose_env_candidates():
		try:D=subprocess.run(['docker','compose','port','api','8787'],check=True,capture_output=True,text=True,env=C)
		except(FileNotFoundError,subprocess.CalledProcessError):continue
		B=_parse_compose_port_output(D.stdout)
		if B is not None:return B
def resolve_api_url()->str:
	B=os.getenv('GV_API_URL','').strip()
	if B:return normalize_api_url(B)
	D=load_cli_config();A=D.get('api_url')
	if isinstance(A,str)and A.strip():return normalize_api_url(A)
	C=discover_local_api_url()
	if C:return C
	raise RuntimeError('Could not determine the control plane URL. Set GV_API_URL, run `gv config set-api-url <url>`, or run from the local repo with docker compose up.')