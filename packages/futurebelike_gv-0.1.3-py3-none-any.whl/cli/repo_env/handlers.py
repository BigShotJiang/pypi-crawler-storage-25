from __future__ import annotations
import json as json_lib
from dataclasses import dataclass
from typing import Any
import click
from..repo_add.classify import classify
from.client import delete_json,get_json,post_json
from.format import build_opencode_session_url,preview_value,render_table,short_id
from.resolve import list_repos,resolve_repo
@dataclass(frozen=True)
class TargetEnvInfo:id:str;url:str|None;vm_user:str|None
def _echo_target(repo_name:str,repo_id:str)->None:click.echo(f"Repo: {repo_name} ({short_id(repo_id)})")
def _list_target_envs()->dict[str,TargetEnvInfo]:
	G=get_json('/v1/envs');B=G.get('envs')
	if not isinstance(B,list):return{}
	C:dict[str,TargetEnvInfo]={}
	for A in B:
		if not isinstance(A,dict)or'id'not in A:continue
		D=str(A['id']);E=A.get('url');F=A.get('opencodeUsername');C[D]=TargetEnvInfo(id=D,url=str(E)if E else None,vm_user=str(F)if F else None)
	return C
def handle_repo_list(json_out:bool)->int:
	A=list_repos();B=_list_target_envs()
	if json_out:click.echo(json_lib.dumps([{'id':A.id,'owner':A.git_owner,'name':A.name,'gitRemoteUrl':A.git_remote_url,'localPath':A.local_path,'targetEnvId':A.target_env_id,'activeBranch':A.active_branch,'defaultBranch':A.default_branch,'envVarCount':A.env_var_count,'secretCount':A.secret_count,'syncStatus':A.sync_status,'syncStep':A.sync_step,'syncErrorMessage':A.sync_error_message,'opencodeSessionUrl':build_opencode_session_url(B[A.target_env_id].url,B[A.target_env_id].vm_user,A.name)if A.target_env_id and A.target_env_id in B else None}for A in A],indent=2));return 0
	if not A:click.echo('No repos registered. Run `gv repo add <dir>` to register one.');return 0
	C=[[short_id(A.id),A.git_owner or'-',A.name,A.local_path,A.active_branch or'-',f"{A.env_var_count} ({A.secret_count} secret)",A.sync_status,A.sync_step,build_opencode_session_url(B[A.target_env_id].url,B[A.target_env_id].vm_user,A.name)if A.target_env_id and A.target_env_id in B else'-']for A in A];click.echo(render_table(C,['ID','OWNER','NAME','LOCAL_PATH','BRANCH','ENV_VARS','STATUS','STEP','OPEN_URL']));return 0
def handle_env_list(repo:str|None,reveal:bool,json_out:bool)->int:
	C=reveal;B=resolve_repo(repo);D=get_json(f"/v1/repos/{B.id}/env-vars");A:list[dict[str,Any]]=D.get('envVars')or[]
	if json_out:
		if not C:A=[{**A,'value':'********'if A.get('isSecret')else A.get('value')}for A in A]
		click.echo(json_lib.dumps({'repo':B.name,'envVars':A},indent=2));return 0
	_echo_target(B.name,B.id)
	if not A:click.echo('No env vars captured yet.');return 0
	E=sorted(A,key=lambda v:(0 if v.get('isSecret')else 1,str(v.get('key',''))));F=[['secret'if A.get('isSecret')else'plain',str(A.get('key','')),str(A.get('sourcePath','')),preview_value(str(A.get('value','')),bool(A.get('isSecret')),reveal=C)]for A in E];click.echo(render_table(F,['TYPE','KEY','SOURCE','VALUE']));return 0
def _parse_assignment(assignment:str)->tuple[str,str]:
	B=assignment
	if'='not in B:raise RuntimeError(f"Expected KEY=VALUE, got {B!r}. Example: FEATURE_X=on")
	A,C=B.split('=',1);A=A.strip()
	if not A:raise RuntimeError('Env var key cannot be empty.')
	return A,C
def handle_env_add(repo:str|None,assignment:str,source:str,mark_secret:bool|None)->int:D=mark_secret;C=source;A,E=_parse_assignment(assignment);F=classify(A,E)if D is None else D;B=resolve_repo(repo);_echo_target(B.name,B.id);post_json(f"/v1/repos/{B.id}/env-vars",{'key':A,'value':E,'sourcePath':C,'isSecret':F});G='secret'if F else'plain';click.echo(f"Saved {A} as {G} in {C}.");return 0
def handle_env_rm(repo:str|None,key:str,source:str|None,yes:bool)->int:
	C=key;A=source;B=resolve_repo(repo);_echo_target(B.name,B.id);D=f" (source: {A})"if A else''
	if not yes and not click.confirm(f"Remove {C}{D} from {B.name}?",default=False):click.echo('Aborted.');return 0
	E={'sourcePath':A}if A else None;F=delete_json(f"/v1/repos/{B.id}/env-vars/{C}",params=E);G=int(F.get('deleted',0));click.echo(f"Removed {G} row(s) for {C}.");return 0