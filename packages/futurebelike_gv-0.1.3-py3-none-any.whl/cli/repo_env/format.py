from __future__ import annotations
import base64,re
_GIT_REMOTE_RE=re.compile('\n    ^\n    (?:                                 # scheme / user@host prefix (all optional)\n        (?:https?|ssh|git)://[^/]+/\n      | [^@\\s:]+@[^:/\\s]+:\n      | [^:/\\s]+:                       # bare `host:` (old-style ssh)\n    )?\n    (?P<owner>[^/\\s]+)                  # owner / org / user\n    /\n    (?P<name>[^/\\s]+?)                  # repo name\n    (?:\\.git)?                          # optional .git suffix\n    /?$\n    ',re.VERBOSE)
_GITHUB_REMOTE_RE=re.compile('\n    ^\n    (?:\n        git@github\\.com:\n      | ssh://git@github\\.com/\n      | https://github\\.com/\n    )\n    (?P<owner>[^/\\s]+)\n    /\n    (?P<name>[^/\\s]+?)\n    (?:\\.git)?\n    /?$\n    ',re.VERBOSE|re.IGNORECASE)
def parse_git_owner(remote_url:str|None)->str|None:
	A=remote_url
	if not A:return
	B=_GIT_REMOTE_RE.match(A.strip());return B.group('owner')if B else None
def normalize_github_remote_to_https(remote_url:str|None)->str|None:
	A=remote_url
	if not A:return
	B=_GITHUB_REMOTE_RE.match(A.strip())
	if not B:return A
	return f"https://github.com/{B.group("owner")}/{B.group("name")}.git"
def build_opencode_session_url(env_url:str|None,vm_user:str|None,repo_name:str)->str|None:
	C=repo_name;B=vm_user;A=env_url
	if not A or not B or not C:return
	D=f"/home/{B}/workspace/{C}";E=base64.b64encode(D.encode('utf-8')).decode('ascii').rstrip('=');return f"{A.rstrip("/")}/{E}/session"
def preview_value(value:str,is_secret:bool,*,reveal:bool=False)->str:
	A=value
	if is_secret and not reveal:return'********'
	if len(A)>40:return A[:37]+'...'
	return A
def short_id(full_id:str,length:int=8)->str:return full_id[:length]
def render_table(rows:list[list[str]],headers:list[str])->str:
	C=headers;A=[len(A)for A in C]
	for F in rows:
		for(D,G)in enumerate(F):A[D]=max(A[D],len(G))
	def B(row:list[str])->str:return'  '.join(C.ljust(A[B])for(B,C)in enumerate(row)).rstrip()
	E=[B(C),B(['-'*A for A in A])];E.extend(B(A)for A in rows);return'\n'.join(E)