from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from.client import get_json
from.format import parse_git_owner
@dataclass(frozen=True)
class RepoRef:
	id:str;owner_user_id:str|None;name:str;local_path:str;target_env_id:str|None;git_remote_url:str|None;active_branch:str|None;default_branch:str|None;env_var_count:int;secret_count:int;sync_status:str;sync_step:str;sync_error_message:str|None
	@classmethod
	def from_payload(E,payload:dict[str,Any])->'RepoRef':A=payload;B=A.get('ownerUserId');C=A.get('targetEnvId');D=A.get('syncErrorMessage');return E(id=str(A['id']),owner_user_id=str(B)if B else None,name=str(A['name']),local_path=str(A['localPath']),target_env_id=str(C)if C else None,git_remote_url=A.get('gitRemoteUrl'),active_branch=A.get('activeBranch'),default_branch=A.get('defaultBranch'),env_var_count=int(A.get('envVarCount',0)or 0),secret_count=int(A.get('secretCount',0)or 0),sync_status=str(A.get('syncStatus')or'pending'),sync_step=str(A.get('syncStep')or'queued'),sync_error_message=str(D)if D else None)
	@property
	def git_owner(self)->str|None:return parse_git_owner(self.git_remote_url)
class AmbiguousRepoError(RuntimeError):
	def __init__(A,flag:str,matches:list[RepoRef])->None:B=matches;A.flag=flag;A.matches=B;C='\n'.join(f"  {A.id[:8]}  {A.name}  ({A.local_path})"for A in B);super().__init__(f"--repo {flag!r} matches multiple repos; re-run with an ID:\n{C}")
def list_repos()->list[RepoRef]:
	B=get_json('/v1/repos');A=B.get('repos',[])
	if not isinstance(A,list):raise RuntimeError('Control plane returned an invalid repo list response.')
	return[RepoRef.from_payload(A)for A in A if isinstance(A,dict)]
def resolve_repo(repo_flag:str|None)->RepoRef:
	F=repo_flag;B=list_repos()
	if not B:raise RuntimeError("You haven't registered any repos yet. Run `gv repo add <dir>` first.")
	if F:
		A=F.strip();G=[B for B in B if B.id==A]
		if G:return G[0]
		if len(A)>=4:
			C=[B for B in B if B.id.startswith(A)]
			if len(C)==1:return C[0]
			if len(C)>1:raise AmbiguousRepoError(A,C)
		D=[B for B in B if B.name==A]
		if len(D)==1:return D[0]
		if len(D)>1:raise AmbiguousRepoError(A,D)
		raise RuntimeError(f"No repo matches --repo {A!r}. Run `gv repo list` to see your repos.")
	H=str(Path.cwd().resolve());E=[A for A in B if A.local_path==H]
	if len(E)==1:return E[0]
	if not E:raise RuntimeError('No repo registered at this path. Pass --repo ID_OR_NAME, or run `gv repo add .` from the repo root.')
	raise AmbiguousRepoError(H,E)