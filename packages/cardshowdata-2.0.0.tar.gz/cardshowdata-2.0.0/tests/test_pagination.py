"""Tests for pagination containers and auto-paging iterators."""

import httpx
import pytest
import respx

from cardshowdata import CardShowData, AsyncCardShowData, OffsetPage, CursorPage


USAGE_OK = {"account": {}, "rate_limit": {}, "daily": {}, "monthly": {}, "billing": {}}

# Fixtures for card search (offset) and catalog products (cursor)

CARDS_PAGE_1 = {
    "data": [{"id": "1", "name": "Card 1"}, {"id": "2", "name": "Card 2"}],
    "pagination": {
        "page": 1, "page_size": 2, "total_count": 5, "total_pages": 3,
        "next_href": "/v1/cards?page=2&page_size=2", "prev_href": None,
    },
}
CARDS_PAGE_2 = {
    "data": [{"id": "3", "name": "Card 3"}, {"id": "4", "name": "Card 4"}],
    "pagination": {
        "page": 2, "page_size": 2, "total_count": 5, "total_pages": 3,
        "next_href": "/v1/cards?page=3&page_size=2", "prev_href": "/v1/cards?page=1&page_size=2",
    },
}
CARDS_PAGE_3 = {
    "data": [{"id": "5", "name": "Card 5"}],
    "pagination": {
        "page": 3, "page_size": 2, "total_count": 5, "total_pages": 3,
        "next_href": None, "prev_href": "/v1/cards?page=2&page_size=2",
    },
}

PRODUCTS_PAGE_1 = {
    "items": [
        {"csd_product_id": "aaa", "tcg_slug": "pk", "is_active": True},
        {"csd_product_id": "bbb", "tcg_slug": "pk", "is_active": True},
    ],
    "next_cursor": "cursor_abc",
    "count": 4,
}
PRODUCTS_PAGE_2 = {
    "items": [
        {"csd_product_id": "ccc", "tcg_slug": "pk", "is_active": True},
        {"csd_product_id": "ddd", "tcg_slug": "pk", "is_active": True},
    ],
    "next_cursor": None,
    "count": 4,
}


class TestOffsetPage:
    def test_has_next_true(self, mock_api, client):
        mock_api.get("/v1/cards").mock(return_value=httpx.Response(200, json=CARDS_PAGE_1))
        page = client.cards.search(page=1, page_size=2)
        assert page.has_next() is True
        assert page.pagination.total_count == 5
        assert page.pagination.total_pages == 3
        assert len(page.data) == 2

    def test_has_next_false_on_last_page(self, mock_api, client):
        mock_api.get("/v1/cards").mock(return_value=httpx.Response(200, json=CARDS_PAGE_3))
        page = client.cards.search(page=3, page_size=2)
        assert page.has_next() is False

    def test_auto_paging_iterator(self, mock_api, client):
        route = mock_api.get("/v1/cards")
        route.side_effect = [
            httpx.Response(200, json=CARDS_PAGE_1),
            httpx.Response(200, json=CARDS_PAGE_2),
            httpx.Response(200, json=CARDS_PAGE_3),
        ]
        names = [card.name for card in client.cards.search_all(page_size=2)]
        assert names == ["Card 1", "Card 2", "Card 3", "Card 4", "Card 5"]
        assert route.call_count == 3

    @pytest.mark.asyncio
    async def test_async_auto_paging_iterator(self, mock_api):
        route = mock_api.get("/v1/cards")
        route.side_effect = [
            httpx.Response(200, json=CARDS_PAGE_1),
            httpx.Response(200, json=CARDS_PAGE_2),
            httpx.Response(200, json=CARDS_PAGE_3),
        ]
        ac = AsyncCardShowData(api_key="test_key_123")
        names = []
        async for card in ac.cards.search_all(page_size=2):
            names.append(card.name)
        assert names == ["Card 1", "Card 2", "Card 3", "Card 4", "Card 5"]
        await ac.close()


class TestCursorPage:
    def test_has_next_true(self, mock_api, client):
        mock_api.get("/v1/catalog/pk/products").mock(
            return_value=httpx.Response(200, json=PRODUCTS_PAGE_1)
        )
        page = client.catalog.list_products("pk")
        assert page.has_next() is True
        assert page.next_cursor == "cursor_abc"
        assert len(page.items) == 2

    def test_has_next_false(self, mock_api, client):
        mock_api.get("/v1/catalog/pk/products").mock(
            return_value=httpx.Response(200, json=PRODUCTS_PAGE_2)
        )
        page = client.catalog.list_products("pk")
        assert page.has_next() is False

    def test_auto_paging_iterator(self, mock_api, client):
        route = mock_api.get("/v1/catalog/pk/products")
        route.side_effect = [
            httpx.Response(200, json=PRODUCTS_PAGE_1),
            httpx.Response(200, json=PRODUCTS_PAGE_2),
        ]
        ids = [p.csd_product_id for p in client.catalog.list_products_all("pk")]
        assert ids == ["aaa", "bbb", "ccc", "ddd"]
        assert route.call_count == 2

    @pytest.mark.asyncio
    async def test_async_auto_paging_iterator(self, mock_api):
        route = mock_api.get("/v1/catalog/pk/products")
        route.side_effect = [
            httpx.Response(200, json=PRODUCTS_PAGE_1),
            httpx.Response(200, json=PRODUCTS_PAGE_2),
        ]
        ac = AsyncCardShowData(api_key="test_key_123")
        ids = []
        async for p in ac.catalog.list_products_all("pk"):
            ids.append(p.csd_product_id)
        assert ids == ["aaa", "bbb", "ccc", "ddd"]
        await ac.close()
