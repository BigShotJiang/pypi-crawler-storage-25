"""Tests for the unified error envelope parsing in the Python SDK.

The API returns every 4xx/5xx in a single shape:

    {"error": {"type", "code", "message", "status", "request_id", "doc_url", "details"}}

These tests verify the SDK surfaces all of those fields on the raised
exception, mapped to the right subclass by status code.
"""

from __future__ import annotations

import httpx
import pytest

from cardshowdata import (
    ApiError,
    AuthenticationError,
    CardShowDataError,
    ConflictError,
    NotFoundError,
    PermissionError,
    RateLimitError,
    ValidationError,
)
from cardshowdata._exceptions import CSDError
from cardshowdata._client import _map_error


def _envelope_response(
    status: int,
    code: str,
    message: str,
    type_: str,
    *,
    details: dict | None = None,
    request_id: str = "req_test_abc",
    extra_headers: dict[str, str] | None = None,
) -> httpx.Response:
    headers = {"X-Request-Id": request_id}
    if extra_headers:
        headers.update(extra_headers)
    body = {
        "error": {
            "type": type_,
            "code": code,
            "message": message,
            "status": status,
            "request_id": request_id,
            "doc_url": f"https://cardshowdata.com/docs/errors/{code}",
        }
    }
    if details is not None:
        body["error"]["details"] = details
    # httpx.Response needs a request to have URL — give it a stub.
    return httpx.Response(
        status,
        json=body,
        headers=headers,
        request=httpx.Request("GET", "https://api.cardshowdata.com/v1/test"),
    )


class TestEnvelopeParsing:
    def test_401_maps_to_authentication_error_with_all_fields(self):
        response = _envelope_response(
            401, "invalid_api_key", "The API key provided is not valid.", "auth_error"
        )
        err = _map_error(response)
        assert isinstance(err, AuthenticationError)
        assert err.status_code == 401
        assert err.code == "invalid_api_key"
        assert err.request_id == "req_test_abc"
        assert err.doc_url == "https://cardshowdata.com/docs/errors/invalid_api_key"
        assert "not valid" in str(err)

    def test_403_tier_upgrade_surfaces_details(self):
        response = _envelope_response(
            403,
            "tier_upgrade_required",
            "Your Free plan doesn't include this.",
            "permission_error",
            details={"tier": "free", "missing_entitlements": ["pricing.graded"]},
        )
        err = _map_error(response)
        assert isinstance(err, PermissionError)
        assert err.code == "tier_upgrade_required"
        assert err.details["tier"] == "free"
        assert err.details["missing_entitlements"] == ["pricing.graded"]

    def test_404_product_not_found(self):
        response = _envelope_response(
            404, "product_not_found", "No product exists.", "not_found_error"
        )
        err = _map_error(response)
        assert isinstance(err, NotFoundError)
        assert err.code == "product_not_found"

    def test_409_conflict(self):
        response = _envelope_response(
            409, "duplicate_resource", "Already exists.", "conflict_error"
        )
        err = _map_error(response)
        assert isinstance(err, ConflictError)
        assert err.code == "duplicate_resource"

    def test_422_validation_exposes_field_errors(self):
        field_errors = [
            {
                "field": "body.sales[0].price_cents",
                "code": "missing",
                "message": "Field required",
                "received": None,
            }
        ]
        response = _envelope_response(
            422,
            "validation_failed",
            "Request validation failed for 1 field(s).",
            "validation_error",
            details={"field_errors": field_errors},
        )
        err = _map_error(response)
        assert isinstance(err, ValidationError)
        assert err.code == "validation_failed"
        assert err.field_errors == field_errors

    def test_429_rate_limit_reads_retry_after_header_first(self):
        response = _envelope_response(
            429,
            "rate_limit_exceeded",
            "Your plan rate limit was exceeded.",
            "rate_limit_error",
            details={"tier": "starter", "limit": 120, "retry_after_seconds": 30},
            extra_headers={
                "Retry-After": "42",
                "X-RateLimit-Limit": "120",
                "X-RateLimit-Remaining": "0",
                "X-RateLimit-Reset": "1234567890",
            },
        )
        err = _map_error(response)
        assert isinstance(err, RateLimitError)
        assert err.retry_after == 42.0  # header wins over details and reset
        assert err.limit == 120
        assert err.remaining == 0
        assert err.code == "rate_limit_exceeded"

    def test_429_rate_limit_falls_back_to_details_retry_after(self):
        response = _envelope_response(
            429,
            "rate_limit_exceeded",
            "msg",
            "rate_limit_error",
            details={"retry_after_seconds": 17},
        )
        err = _map_error(response)
        assert isinstance(err, RateLimitError)
        assert err.retry_after == 17.0

    def test_5xx_maps_to_api_error(self):
        response = _envelope_response(
            503, "dataset_not_published", "Dataset not yet published.", "upstream_error"
        )
        err = _map_error(response)
        assert isinstance(err, ApiError)
        assert err.code == "dataset_not_published"
        assert err.status_code == 503

    def test_legacy_detail_shape_still_parses(self):
        # If a caller is pinned behind a proxy running an older API, we still
        # extract the message from the old {"detail": "..."} shape.
        response = httpx.Response(
            404,
            json={"detail": "Not found"},
            request=httpx.Request("GET", "https://api.cardshowdata.com/v1/test"),
        )
        err = _map_error(response)
        assert isinstance(err, NotFoundError)
        assert "Not found" in str(err)
        # Envelope fields are None/empty when the legacy shape is used.
        assert err.code is None
        assert err.details == {}

    def test_non_json_body_falls_back_to_text(self):
        response = httpx.Response(
            500,
            text="upstream proxy lol",
            request=httpx.Request("GET", "https://api.cardshowdata.com/v1/test"),
        )
        err = _map_error(response)
        assert isinstance(err, ApiError)
        assert "upstream proxy" in str(err)


class TestErrorClassHierarchy:
    def test_csd_error_alias_exported(self):
        # Convenience alias so users can `from cardshowdata import CSDError`.
        from cardshowdata import CSDError as Exported
        assert Exported is CSDError
        assert Exported is CardShowDataError

    def test_new_classes_inherit_from_base(self):
        assert issubclass(ConflictError, CardShowDataError)
        assert issubclass(ValidationError, CardShowDataError)

    def test_validation_error_field_errors_is_always_a_list(self):
        err = ValidationError("bad")
        assert err.field_errors == []
        err2 = ValidationError("bad", details={"field_errors": [{"field": "x"}]})
        assert err2.field_errors == [{"field": "x"}]
