"""Tests for HTTP client, auth, headers, retry, rate limiting, and errors."""

import os
import time

import httpx
import pytest
import respx

from cardshowdata import (
    ApiError,
    AsyncCardShowData,
    AuthenticationError,
    CardShowData,
    CardShowDataError,
    NotFoundError,
    PermissionError,
    RateLimitError,
)
from cardshowdata._version import __version__


# ── Auth & Headers ──────────────────────────────────────────────────

class TestAuth:
    def test_sends_api_key_header(self, mock_api, client):
        route = mock_api.get("/v1/usage").mock(
            return_value=httpx.Response(200, json={"account": {}, "rate_limit": {}, "daily": {}, "monthly": {}, "billing": {}})
        )
        client.usage.get()
        assert route.calls[0].request.headers["x-api-key"] == "test_key_123"

    def test_sends_user_agent(self, mock_api, client):
        route = mock_api.get("/v1/usage").mock(
            return_value=httpx.Response(200, json={"account": {}, "rate_limit": {}, "daily": {}, "monthly": {}, "billing": {}})
        )
        client.usage.get()
        assert f"cardshowdata-python/{__version__}" in route.calls[0].request.headers["user-agent"]

    def test_reads_env_var(self, mock_api, monkeypatch):
        monkeypatch.setenv("CSD_API_KEY", "env_key_456")
        c = CardShowData()
        route = mock_api.get("/v1/usage").mock(
            return_value=httpx.Response(200, json={"account": {}, "rate_limit": {}, "daily": {}, "monthly": {}, "billing": {}})
        )
        c.usage.get()
        assert route.calls[0].request.headers["x-api-key"] == "env_key_456"
        c.close()

    def test_raises_without_key(self, monkeypatch):
        monkeypatch.delenv("CSD_API_KEY", raising=False)
        with pytest.raises(AuthenticationError, match="No API key"):
            CardShowData()

    def test_respects_custom_base_url(self):
        with respx.mock(base_url="https://custom.example.com") as m:
            m.get("/v1/usage").mock(
                return_value=httpx.Response(200, json={"account": {}, "rate_limit": {}, "daily": {}, "monthly": {}, "billing": {}})
            )
            c = CardShowData(api_key="k", base_url="https://custom.example.com")
            c.usage.get()
            c.close()

    def test_context_manager(self, mock_api):
        mock_api.get("/v1/usage").mock(
            return_value=httpx.Response(200, json={"account": {}, "rate_limit": {}, "daily": {}, "monthly": {}, "billing": {}})
        )
        with CardShowData(api_key="test_key_123") as c:
            c.usage.get()

    @pytest.mark.asyncio
    async def test_async_context_manager(self, mock_api):
        mock_api.get("/v1/usage").mock(
            return_value=httpx.Response(200, json={"account": {}, "rate_limit": {}, "daily": {}, "monthly": {}, "billing": {}})
        )
        async with AsyncCardShowData(api_key="test_key_123") as c:
            await c.usage.get()


# ── Error Mapping ───────────────────────────────────────────────────

class TestErrors:
    def test_401_authentication_error(self, mock_api, client):
        mock_api.get("/v1/usage").mock(
            return_value=httpx.Response(401, json={"detail": "Invalid API key"})
        )
        with pytest.raises(AuthenticationError, match="Invalid API key") as exc_info:
            client.usage.get()
        assert exc_info.value.status_code == 401

    def test_403_permission_error(self, mock_api, client):
        mock_api.get("/v1/pricing/abc").mock(
            return_value=httpx.Response(403, json={"detail": "Entitlement required: pricing.single"})
        )
        with pytest.raises(PermissionError) as exc_info:
            client.pricing.get("abc")
        assert exc_info.value.status_code == 403

    def test_404_not_found_error(self, mock_api, client):
        mock_api.get("/v1/cards/nonexistent").mock(
            return_value=httpx.Response(404, json={"detail": "Card not found"})
        )
        with pytest.raises(NotFoundError, match="Card not found") as exc_info:
            client.cards.get("nonexistent")
        assert exc_info.value.status_code == 404

    def test_429_rate_limit_error(self, mock_api, client):
        reset_ts = int(time.time()) + 30
        mock_api.get("/v1/usage").mock(
            return_value=httpx.Response(
                429,
                json={"detail": "Rate limit exceeded"},
                headers={
                    "x-ratelimit-limit": "60",
                    "x-ratelimit-remaining": "0",
                    "x-ratelimit-reset": str(reset_ts),
                },
            )
        )
        # Disable retries for this test
        client._http._max_retries = 0
        with pytest.raises(RateLimitError) as exc_info:
            client.usage.get()
        err = exc_info.value
        assert err.status_code == 429
        assert err.limit == 60
        assert err.remaining == 0
        assert err.reset == reset_ts
        assert err.retry_after is not None and err.retry_after >= 0

    def test_500_api_error(self, mock_api, client):
        mock_api.get("/v1/usage").mock(
            return_value=httpx.Response(500, json={"detail": "Internal server error"})
        )
        client._http._max_retries = 0
        with pytest.raises(ApiError) as exc_info:
            client.usage.get()
        assert exc_info.value.status_code == 500

    def test_malformed_json(self, mock_api, client):
        mock_api.get("/v1/usage").mock(
            return_value=httpx.Response(500, text="not json")
        )
        client._http._max_retries = 0
        with pytest.raises(ApiError, match="not json"):
            client.usage.get()

    def test_all_errors_inherit_from_base(self):
        assert issubclass(AuthenticationError, CardShowDataError)
        assert issubclass(PermissionError, CardShowDataError)
        assert issubclass(NotFoundError, CardShowDataError)
        assert issubclass(RateLimitError, CardShowDataError)
        assert issubclass(ApiError, CardShowDataError)

    def test_all_errors_have_status_code(self):
        assert AuthenticationError().status_code == 401
        assert PermissionError().status_code == 403
        assert NotFoundError().status_code == 404
        assert RateLimitError().status_code == 429
        assert ApiError("err", status_code=503).status_code == 503


# ── Retry Logic ─────────────────────────────────────────────────────

class TestRetry:
    def test_retries_429(self, mock_api, client):
        route = mock_api.get("/v1/usage")
        route.side_effect = [
            httpx.Response(429, json={"detail": "Rate limit"}, headers={"x-ratelimit-reset": "0"}),
            httpx.Response(200, json={"account": {}, "rate_limit": {}, "daily": {}, "monthly": {}, "billing": {}}),
        ]
        result = client.usage.get()
        assert route.call_count == 2

    def test_retries_500(self, mock_api, client):
        route = mock_api.get("/v1/usage")
        route.side_effect = [
            httpx.Response(500, json={"detail": "Error"}),
            httpx.Response(200, json={"account": {}, "rate_limit": {}, "daily": {}, "monthly": {}, "billing": {}}),
        ]
        result = client.usage.get()
        assert route.call_count == 2

    def test_retries_502(self, mock_api, client):
        route = mock_api.get("/v1/usage")
        route.side_effect = [
            httpx.Response(502, json={"detail": "Bad gateway"}),
            httpx.Response(200, json={"account": {}, "rate_limit": {}, "daily": {}, "monthly": {}, "billing": {}}),
        ]
        client.usage.get()
        assert route.call_count == 2

    def test_retries_503(self, mock_api, client):
        route = mock_api.get("/v1/usage")
        route.side_effect = [
            httpx.Response(503, json={"detail": "Unavailable"}),
            httpx.Response(200, json={"account": {}, "rate_limit": {}, "daily": {}, "monthly": {}, "billing": {}}),
        ]
        client.usage.get()
        assert route.call_count == 2

    def test_no_retry_on_400(self, mock_api, client):
        route = mock_api.get("/v1/cards/x")
        route.mock(return_value=httpx.Response(400, json={"detail": "Bad request"}))
        with pytest.raises(ApiError):
            client.cards.get("x")
        assert route.call_count == 1

    def test_no_retry_on_401(self, mock_api, client):
        route = mock_api.get("/v1/usage")
        route.mock(return_value=httpx.Response(401, json={"detail": "Unauthorized"}))
        with pytest.raises(AuthenticationError):
            client.usage.get()
        assert route.call_count == 1

    def test_no_retry_on_403(self, mock_api, client):
        route = mock_api.get("/v1/pricing/abc")
        route.mock(return_value=httpx.Response(403, json={"detail": "Forbidden"}))
        with pytest.raises(PermissionError):
            client.pricing.get("abc")
        assert route.call_count == 1

    def test_no_retry_on_404(self, mock_api, client):
        route = mock_api.get("/v1/cards/missing")
        route.mock(return_value=httpx.Response(404, json={"detail": "Not found"}))
        with pytest.raises(NotFoundError):
            client.cards.get("missing")
        assert route.call_count == 1

    def test_gives_up_after_max_retries(self, mock_api, client):
        route = mock_api.get("/v1/usage")
        route.mock(return_value=httpx.Response(500, json={"detail": "Error"}))
        with pytest.raises(ApiError):
            client.usage.get()
        assert route.call_count == 4  # 1 initial + 3 retries


# ── Rate Limit Tracking ────────────────────────────────────────────

class TestRateLimit:
    def test_updates_after_response(self, mock_api, client):
        mock_api.get("/v1/usage").mock(
            return_value=httpx.Response(
                200,
                json={"account": {}, "rate_limit": {}, "daily": {}, "monthly": {}, "billing": {}},
                headers={
                    "x-ratelimit-limit": "120",
                    "x-ratelimit-remaining": "119",
                    "x-ratelimit-reset": "1700000000",
                },
            )
        )
        client.usage.get()
        assert client.rate_limit.limit == 120
        assert client.rate_limit.remaining == 119
        assert client.rate_limit.reset == 1700000000
