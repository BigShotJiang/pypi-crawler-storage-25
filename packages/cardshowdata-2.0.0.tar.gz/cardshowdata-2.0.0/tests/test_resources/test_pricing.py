"""Tests for the Pricing resource."""

import httpx
import pytest

from cardshowdata import AsyncCardShowData


PRICING_RESPONSE = {
    "product_id": "aaaa-bbbb-cccc",
    "as_of_date": "2026-04-12",
    "variants": [
        {
            "subtype": "normal",
            "market_price_cents": 4500,
            "direct_low_price_cents": 4200,
            "loose_price_cents": None,
            "retail_loose_sell_cents": None,
            "fair_value_cents": 4300,
            "spread_cents": 200,
            "recommended_list_price_cents": 5500,
            "lifecycle_state": "stable",
            "confidence": 0.9,
        },
        {
            "subtype": "holofoil",
            "market_price_cents": 12500,
            "direct_low_price_cents": 11000,
            "loose_price_cents": None,
            "retail_loose_sell_cents": None,
            "fair_value_cents": 12000,
            "spread_cents": 500,
            "recommended_list_price_cents": 15000,
            "lifecycle_state": "declining",
            "confidence": 0.95,
        },
    ],
}

HISTORY_RESPONSE = {
    "product_id": "abc",
    "variants": [
        {
            "subtype": "normal",
            "history": [
                {"as_of_date": "2026-04-12", "market_price_cents": 4500, "fair_value_cents": 4300, "spread_cents": 200, "lifecycle_state": "stable", "confidence": 0.9},
                {"as_of_date": "2026-04-11", "market_price_cents": 4400, "fair_value_cents": 4200, "spread_cents": 200, "lifecycle_state": "stable", "confidence": 0.9},
            ],
        },
        {
            "subtype": "holofoil",
            "history": [
                {"as_of_date": "2026-04-12", "market_price_cents": 12500, "fair_value_cents": 12000, "spread_cents": 500, "lifecycle_state": "declining", "confidence": 0.95},
            ],
        },
    ],
}


class TestPricing:
    def test_get(self, mock_api, client):
        mock_api.get("/v1/pricing/aaaa-bbbb-cccc").mock(
            return_value=httpx.Response(200, json=PRICING_RESPONSE)
        )
        price = client.pricing.get("aaaa-bbbb-cccc")
        assert price.product_id == "aaaa-bbbb-cccc"
        assert len(price.variants) == 2
        assert [v.subtype for v in price.variants] == ["normal", "holofoil"]
        holo = price.variants[1]
        assert holo.market_price_cents == 12500
        assert holo.fair_value_cents == 12000
        assert holo.confidence == 0.95
        assert holo.lifecycle_state == "declining"

    def test_bulk(self, mock_api, client):
        route = mock_api.post("/v1/pricing/bulk").mock(
            return_value=httpx.Response(200, json=[PRICING_RESPONSE, PRICING_RESPONSE])
        )
        results = client.pricing.bulk(["uuid1", "uuid2"])
        assert len(results) == 2
        assert all(len(r.variants) == 2 for r in results)
        body = route.calls[0].request.read()
        assert b'"product_ids"' in body

    def test_bulk_with_date(self, mock_api, client):
        route = mock_api.post("/v1/pricing/bulk").mock(
            return_value=httpx.Response(200, json=[PRICING_RESPONSE])
        )
        client.pricing.bulk(["uuid1"], date="2026-01-01")
        body = route.calls[0].request.read()
        assert b'"date"' in body
        assert b'"2026-01-01"' in body

    def test_history(self, mock_api, client):
        route = mock_api.get("/v1/pricing/history/abc").mock(
            return_value=httpx.Response(200, json=HISTORY_RESPONSE)
        )
        result = client.pricing.history("abc", days=90)
        assert result.product_id == "abc"
        assert len(result.variants) == 2
        normal = result.variants[0]
        assert normal.subtype == "normal"
        assert len(normal.history) == 2
        assert normal.history[0].market_price_cents == 4500
        assert "days=90" in str(route.calls[0].request.url)

    def test_changes(self, mock_api, client):
        mock_api.get("/v1/pricing/changes").mock(
            return_value=httpx.Response(200, json={
                "items": [{
                    "csd_product_id": "abc",
                    "subtype": "holofoil",
                    "pretty_id": "pk_bs_004",
                    "tcg_slug": "pk",
                    "old_price_cents": 100,
                    "new_price_cents": 200,
                    "pct_change": 100.0,
                    "snapshot_date": "2026-04-12",
                }],
                "next_cursor": "cursor_xyz",
                "count": 1,
            })
        )
        page = client.pricing.changes(since="2026-04-07T00:00:00Z")
        assert page.has_next() is True
        assert page.items[0].pct_change == 100.0
        assert page.items[0].subtype == "holofoil"

    def test_changes_all_auto_pages(self, mock_api, client):
        route = mock_api.get("/v1/pricing/changes")
        route.side_effect = [
            httpx.Response(200, json={
                "items": [{"csd_product_id": "a", "subtype": "normal", "pct_change": 10}],
                "next_cursor": "c1", "count": 2,
            }),
            httpx.Response(200, json={
                "items": [{"csd_product_id": "b", "subtype": "holofoil", "pct_change": 20}],
                "next_cursor": None, "count": 2,
            }),
        ]
        ids = [(c.csd_product_id, c.subtype) for c in client.pricing.changes_all(since="2026-04-07T00:00:00Z")]
        assert ids == [("a", "normal"), ("b", "holofoil")]
        assert route.call_count == 2

    @pytest.mark.asyncio
    async def test_async_get(self, mock_api):
        mock_api.get("/v1/pricing/abc").mock(
            return_value=httpx.Response(200, json=PRICING_RESPONSE)
        )
        async with AsyncCardShowData(api_key="test_key_123") as c:
            price = await c.pricing.get("abc")
            assert len(price.variants) == 2
            assert price.variants[1].market_price_cents == 12500
