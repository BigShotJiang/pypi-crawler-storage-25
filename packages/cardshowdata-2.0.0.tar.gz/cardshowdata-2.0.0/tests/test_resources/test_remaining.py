"""Tests for Grading, Lifecycle, Usage, Sales, Feedback, and Onboarding resources."""

import httpx
import pytest

from cardshowdata import AsyncCardShowData


GRADING_RESPONSE = {
    "csd_product_id": "abc-123",
    "snapshot_date": "2026-04-12",
    "source": "pricecharting",
    "prices": [
        {"grader": "PSA", "grade": "10", "price_type": "high", "price_cents": 50000},
        {"grader": "PSA", "grade": "10", "price_type": "median", "price_cents": 45000},
        {"grader": "PSA", "grade": "10", "price_type": "low", "price_cents": 40000},
    ],
    "high_cents": 50000,
    "median_cents": 45000,
    "low_cents": 40000,
    "recommended_list_price_cents": 48000,
}

LIFECYCLE_RESPONSE = {
    "csd_product_id": "abc-123",
    "group_id": 456,
    "variants": [
        {
            "subtype": "normal",
            "first_seen_date": "2023-01-15",
            "last_seen_date": "2026-04-12",
            "peak_price_cents": 4200,
            "peak_date": "2024-02-10",
            "peak_day_since_first_seen": 391,
            "decay_half_life_days": 240.0,
        },
        {
            "subtype": "holofoil",
            "first_seen_date": "2023-01-15",
            "last_seen_date": "2026-04-12",
            "peak_price_cents": 95000,
            "peak_date": "2024-06-30",
            "peak_day_since_first_seen": 532,
            "decay_half_life_days": 180.5,
        },
    ],
}

USAGE_RESPONSE = {
    "account": {"account_id": "acct_1", "account_name": "Test", "account_type": "sandbox", "account_tier": "free"},
    "rate_limit": {"limit_per_minute": 10, "used_this_minute": 2, "remaining_this_minute": 8, "reset_at": 1700000060},
    "daily": {"calls_today": 50, "daily_limit": 5000, "remaining_today": 4950},
    "monthly": {"period": "2026-04", "calls_this_month": 500, "included_calls": None, "remaining_included": None, "overage_calls": 0, "overage_cents": 0, "overage_cap_cents": None, "per_call_overage_cents": None},
    "billing": {"base_price_cents": 0, "overage_cents": 0, "total_due_cents": 0},
}


class TestGrading:
    def test_get(self, mock_api, client):
        mock_api.get("/v1/grading/abc-123").mock(
            return_value=httpx.Response(200, json=GRADING_RESPONSE)
        )
        grading = client.grading.get("abc-123")
        assert grading.csd_product_id == "abc-123"
        assert len(grading.prices) == 3
        assert grading.prices[0].grader == "PSA"
        assert grading.prices[0].price_cents == 50000
        assert grading.high_cents == 50000
        assert grading.median_cents == 45000

    def test_get_with_params(self, mock_api, client):
        route = mock_api.get("/v1/grading/abc-123").mock(
            return_value=httpx.Response(200, json=GRADING_RESPONSE)
        )
        client.grading.get("abc-123", grader="psa", cert="12345")
        url = str(route.calls[0].request.url)
        assert "grader=psa" in url
        assert "cert=12345" in url

    def test_history(self, mock_api, client):
        route = mock_api.get("/v1/grading/history/abc-123").mock(
            return_value=httpx.Response(200, json=[GRADING_RESPONSE])
        )
        results = client.grading.history("abc-123", grader="psa", days=30)
        assert len(results) == 1
        url = str(route.calls[0].request.url)
        assert "days=30" in url

    def test_changes(self, mock_api, client):
        mock_api.get("/v1/grading/changes").mock(
            return_value=httpx.Response(200, json={
                "items": [{"csd_product_id": "abc", "pretty_id": "pk_bs_004", "tcg_slug": "pk", "snapshot_date": "2026-04-12", "price_count": 3}],
                "next_cursor": None, "count": 1,
            })
        )
        page = client.grading.changes(since="2026-04-07T00:00:00Z")
        assert page.items[0].price_count == 3

    def test_changes_all(self, mock_api, client):
        route = mock_api.get("/v1/grading/changes")
        route.side_effect = [
            httpx.Response(200, json={"items": [{"csd_product_id": "a"}], "next_cursor": "c1", "count": 2}),
            httpx.Response(200, json={"items": [{"csd_product_id": "b"}], "next_cursor": None, "count": 2}),
        ]
        ids = [c.csd_product_id for c in client.grading.changes_all(since="2026-04-01")]
        assert ids == ["a", "b"]


class TestLifecycle:
    def test_get(self, mock_api, client):
        mock_api.get("/v1/lifecycle/abc-123").mock(
            return_value=httpx.Response(200, json=LIFECYCLE_RESPONSE)
        )
        lc = client.lifecycle.get("abc-123")
        assert lc.csd_product_id == "abc-123"
        assert len(lc.variants) == 2
        holo = next(v for v in lc.variants if v.subtype == "holofoil")
        assert holo.peak_price_cents == 95000
        assert holo.decay_half_life_days == 180.5
        assert holo.first_seen_date == "2023-01-15"

    @pytest.mark.asyncio
    async def test_async_get(self, mock_api):
        mock_api.get("/v1/lifecycle/abc-123").mock(
            return_value=httpx.Response(200, json=LIFECYCLE_RESPONSE)
        )
        async with AsyncCardShowData(api_key="test_key_123") as c:
            lc = await c.lifecycle.get("abc-123")
            assert len(lc.variants) == 2
            assert any(v.peak_price_cents == 95000 for v in lc.variants)


class TestUsage:
    def test_get(self, mock_api, client):
        mock_api.get("/v1/usage").mock(
            return_value=httpx.Response(200, json=USAGE_RESPONSE)
        )
        usage = client.usage.get()
        assert usage.account["account_type"] == "sandbox"
        assert usage.daily["calls_today"] == 50
        assert usage.billing["total_due_cents"] == 0


class TestSales:
    def test_submit(self, mock_api, client):
        route = mock_api.post("/v1/sales").mock(
            return_value=httpx.Response(200, json={
                "sale_id": "sale_1", "csd_product_id": "abc", "status": "accepted", "verification_status": "pending",
            })
        )
        result = client.sales.submit(pretty_id="pk_bs_004", price_cents=4500000)
        assert result.sale_id == "sale_1"
        assert result.status == "accepted"

    def test_submit_batch(self, mock_api, client):
        route = mock_api.post("/v1/sales/batch").mock(
            return_value=httpx.Response(200, json={
                "accepted": 2, "rejected": 0,
                "results": [
                    {"index": 0, "status": "accepted", "sale_id": "s1", "csd_product_id": "a", "verification_status": "ok"},
                    {"index": 1, "status": "accepted", "sale_id": "s2", "csd_product_id": "b", "verification_status": "ok"},
                ],
            })
        )
        batch = client.sales.submit_batch([
            {"pretty_id": "pk_bs_004", "price_cents": 100},
            {"pretty_id": "pk_bs_005", "price_cents": 200},
        ])
        assert batch.accepted == 2
        assert batch.rejected == 0
        assert len(batch.results) == 2

    def test_submit_csv(self, mock_api, client):
        import io
        route = mock_api.post("/v1/sales/csv").mock(
            return_value=httpx.Response(200, json={"accepted": 1, "rejected": 0, "results": []})
        )
        csv_file = io.BytesIO(b"pretty_id,price_cents\npk_bs_004,100\n")
        batch = client.sales.submit_csv(csv_file)
        assert batch.accepted == 1


class TestFeedback:
    def test_submit(self, mock_api, client):
        route = mock_api.post("/v1/feedback").mock(
            return_value=httpx.Response(200, json={"status": "received"})
        )
        result = client.feedback.submit(email="user@test.com", message="Great API!")
        assert result["status"] == "received"
        body = route.calls[0].request.read()
        assert b'"message"' in body
        assert b'"email"' in body


class TestOnboarding:
    def test_quickstart(self, mock_api, client):
        mock_api.get("/v1/onboarding/quickstart").mock(
            return_value=httpx.Response(200, json={
                "account": {"account_id": "acct_1"},
                "tcgs": [{"tcg_slug": "pk"}],
                "sample_card": {"pretty_id": "pk_bs_004"},
                "quickstart_steps": [],
            })
        )
        qs = client.onboarding.quickstart()
        assert qs["account"]["account_id"] == "acct_1"
