import pytest
import respx

from cardshowdata import CardShowData, AsyncCardShowData


@pytest.fixture
def mock_api():
    with respx.mock(base_url="https://api.cardshowdata.com") as mock:
        yield mock


@pytest.fixture
def client(mock_api):
    c = CardShowData(api_key="test_key_123")
    yield c
    c.close()


@pytest.fixture
def async_client(mock_api):
    return AsyncCardShowData(api_key="test_key_123")
