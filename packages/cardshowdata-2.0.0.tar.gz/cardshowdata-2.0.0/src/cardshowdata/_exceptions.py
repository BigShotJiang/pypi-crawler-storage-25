"""Exception hierarchy for the CardShowData SDK.

The CardShowData API returns every 4xx/5xx response in a unified envelope::

    {
      "error": {
        "type":       "rate_limit_error",
        "code":       "rate_limit_exceeded",
        "message":    "Your Starter plan allows 120 requests/minute.",
        "status":     429,
        "request_id": "req_01HXYZ...",
        "doc_url":    "https://cardshowdata.com/docs/errors/rate_limit_exceeded",
        "details":    { "tier": "starter", "limit": 120, ... }
      }
    }

Every SDK exception exposes these fields (``.code``, ``.request_id``,
``.doc_url``, ``.details``) so callers can branch on ``err.code`` — the
stable, versioned contract — instead of string-matching messages.
"""

from __future__ import annotations

from typing import Any, Mapping


class CardShowDataError(Exception):
    """Base exception for all CardShowData SDK errors.

    Attributes mirror the canonical ``error`` envelope. All are optional so
    this class also represents errors raised before we have a response
    (network timeouts, DNS failures, etc.).
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        code: str | None = None,
        request_id: str | None = None,
        doc_url: str | None = None,
        details: Mapping[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.request_id = request_id
        self.doc_url = doc_url
        self.details: dict[str, Any] = dict(details) if details else {}

    def __str__(self) -> str:  # pragma: no cover - cosmetic
        base = super().__str__()
        suffix_parts = []
        if self.code:
            suffix_parts.append(f"code={self.code}")
        if self.request_id:
            suffix_parts.append(f"request_id={self.request_id}")
        if suffix_parts:
            return f"{base} ({', '.join(suffix_parts)})"
        return base


class AuthenticationError(CardShowDataError):
    """Raised on 401 — missing, invalid, or malformed API key.

    Codes: ``missing_api_key``, ``invalid_api_key``, ``malformed_api_key``,
    ``internal_key_required``.
    """

    def __init__(self, message: str = "Invalid or missing API key", **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 401)
        super().__init__(message, **kwargs)


class PermissionError(CardShowDataError):
    """Raised on 403 — inactive key/account, or tier-gated feature.

    Codes: ``api_key_inactive``, ``account_inactive``, ``tier_upgrade_required``,
    ``feature_not_in_tier``, ``account_type_not_allowed``, ``subscription_required``.
    """

    def __init__(self, message: str = "Permission denied", **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 403)
        super().__init__(message, **kwargs)


class NotFoundError(CardShowDataError):
    """Raised on 404 — resource does not exist.

    Codes: ``product_not_found``, ``card_not_found``, ``cert_not_found``,
    ``webhook_not_found``, ``resource_not_found``, ``population_not_linked``, ...
    """

    def __init__(self, message: str = "Resource not found", **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 404)
        super().__init__(message, **kwargs)


class ConflictError(CardShowDataError):
    """Raised on 409 — resource already exists or state conflict.

    Codes: ``duplicate_resource``, ``conflict``.
    """

    def __init__(self, message: str = "Conflict", **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 409)
        super().__init__(message, **kwargs)


class ValidationError(CardShowDataError):
    """Raised on 422 — request body failed validation.

    Inspect ``err.details['field_errors']`` for per-field
    ``{field, code, message, received}`` entries.
    """

    def __init__(self, message: str = "Validation failed", **kwargs: Any) -> None:
        kwargs.setdefault("status_code", 422)
        super().__init__(message, **kwargs)

    @property
    def field_errors(self) -> list[dict[str, Any]]:
        """Convenience accessor for the per-field validation details."""
        value = self.details.get("field_errors") if self.details else None
        return list(value) if isinstance(value, list) else []


class RateLimitError(CardShowDataError):
    """Raised on 429 — per-minute, daily, monthly, or overage cap limits hit.

    Codes: ``rate_limit_exceeded``, ``daily_limit_exceeded``,
    ``monthly_limit_exceeded``, ``overage_cap_reached``, ``refresh_limit_exceeded``.

    Always retryable. Honor ``retry_after`` (seconds) before retrying.
    """

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        *,
        retry_after: float | None = None,
        limit: int | None = None,
        remaining: int | None = None,
        reset: int | None = None,
        **kwargs: Any,
    ) -> None:
        kwargs.setdefault("status_code", 429)
        super().__init__(message, **kwargs)
        self.retry_after = retry_after
        self.limit = limit
        self.remaining = remaining
        self.reset = reset


class ApiError(CardShowDataError):
    """Raised on 5xx, network failures, or any other unexpected error.

    Codes for 5xx: ``internal_error``, ``dataset_not_published``,
    ``service_unavailable``, ``stripe_unavailable``, ``upstream_failed``,
    ``population_refresh_failed``, ``cert_lookup_failed``.
    """

    pass


# Alias for discoverability. Some users will reach for CSDError naturally.
CSDError = CardShowDataError
