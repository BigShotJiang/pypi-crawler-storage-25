"""Low-level HTTP client wrappers around httpx with retry, error mapping, and rate-limit tracking."""

from __future__ import annotations

import os
import random
import time
from dataclasses import dataclass, field
from typing import Any

import httpx

from ._exceptions import (
    ApiError,
    AuthenticationError,
    CardShowDataError,
    ConflictError,
    NotFoundError,
    PermissionError,
    RateLimitError,
    ValidationError,
)
from ._version import __version__

_DEFAULT_BASE_URL = "https://api.cardshowdata.com"
_DEFAULT_TIMEOUT = 30
_DEFAULT_MAX_RETRIES = 3
_RETRYABLE_STATUS_CODES = {429, 500, 502, 503}


@dataclass
class RateLimitInfo:
    """Snapshot of the most recent rate-limit headers."""

    limit: int | None = None
    remaining: int | None = None
    reset: int | None = None


def _parse_error_envelope(response: httpx.Response) -> dict[str, Any]:
    """Pull the canonical error envelope out of a 4xx/5xx response.

    Returns a dict with keys ``message``, ``code``, ``request_id``, ``doc_url``,
    ``details``. Any field may be ``None``/``{}`` if not present (e.g. if the
    server returned a non-envelope body or bare text).
    """
    envelope: dict[str, Any] = {
        "message": None,
        "code": None,
        "request_id": response.headers.get("x-request-id"),
        "doc_url": None,
        "details": {},
    }
    try:
        body = response.json()
    except Exception:
        envelope["message"] = response.text or f"HTTP {response.status_code}"
        return envelope

    if isinstance(body, dict):
        err = body.get("error")
        if isinstance(err, dict):
            envelope["message"] = str(err.get("message") or "") or f"HTTP {response.status_code}"
            envelope["code"] = err.get("code")
            envelope["request_id"] = err.get("request_id") or envelope["request_id"]
            envelope["doc_url"] = err.get("doc_url")
            details = err.get("details")
            if isinstance(details, dict):
                envelope["details"] = details
            return envelope
        # Legacy shape: {"detail": "..."}
        if "detail" in body:
            envelope["message"] = str(body["detail"])
            return envelope

    envelope["message"] = response.text or f"HTTP {response.status_code}"
    return envelope


def _map_error(response: httpx.Response) -> CardShowDataError:
    env = _parse_error_envelope(response)
    status = response.status_code
    message = env["message"] or f"HTTP {status}"
    base_kwargs: dict[str, Any] = {
        "status_code": status,
        "code": env["code"],
        "request_id": env["request_id"],
        "doc_url": env["doc_url"],
        "details": env["details"],
    }

    if status == 401:
        return AuthenticationError(message, **base_kwargs)
    if status == 403:
        return PermissionError(message, **base_kwargs)
    if status == 404:
        return NotFoundError(message, **base_kwargs)
    if status == 409:
        return ConflictError(message, **base_kwargs)
    if status == 422:
        return ValidationError(message, **base_kwargs)
    if status == 429:
        limit = _int_header(response, "x-ratelimit-limit")
        remaining = _int_header(response, "x-ratelimit-remaining")
        reset = _int_header(response, "x-ratelimit-reset")
        # Prefer Retry-After header (seconds), fall back to details, then
        # derive from x-ratelimit-reset unix timestamp.
        retry_after: float | None = None
        retry_header = response.headers.get("retry-after")
        if retry_header is not None:
            try:
                retry_after = float(retry_header)
            except ValueError:
                retry_after = None
        if retry_after is None:
            raw = env["details"].get("retry_after_seconds") if env["details"] else None
            if isinstance(raw, (int, float)):
                retry_after = float(raw)
        if retry_after is None and reset is not None:
            retry_after = max(0.0, reset - time.time())
        return RateLimitError(
            message,
            retry_after=retry_after,
            limit=limit,
            remaining=remaining,
            reset=reset,
            **base_kwargs,
        )
    return ApiError(message, **base_kwargs)


def _int_header(response: httpx.Response, name: str) -> int | None:
    val = response.headers.get(name)
    if val is None:
        return None
    try:
        return int(val)
    except ValueError:
        return None


def _backoff_wait(attempt: int, response: httpx.Response | None) -> float:
    """Calculate wait time with jitter for retries."""
    if response is not None and response.status_code == 429:
        reset = _int_header(response, "x-ratelimit-reset")
        if reset is not None:
            wait = max(0, reset - time.time()) + random.uniform(0.1, 0.5)
            return wait
    base = min(2**attempt, 8)
    return base + random.uniform(0, base * 0.5)


def _resolve_api_key(api_key: str | None) -> str:
    key = api_key or os.environ.get("CSD_API_KEY")
    if not key:
        raise AuthenticationError("No API key provided. Pass api_key or set CSD_API_KEY env var.")
    return key


def _build_headers(api_key: str) -> dict[str, str]:
    return {
        "X-API-Key": api_key,
        "User-Agent": f"cardshowdata-python/{__version__}",
        "Accept": "application/json",
    }


def _update_rate_limit(rate_limit: RateLimitInfo, response: httpx.Response) -> None:
    rate_limit.limit = _int_header(response, "x-ratelimit-limit") or rate_limit.limit
    rate_limit.remaining = _int_header(response, "x-ratelimit-remaining")
    rate_limit.reset = _int_header(response, "x-ratelimit-reset") or rate_limit.reset


class SyncHttpClient:
    """Synchronous HTTP client with retry logic."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
    ) -> None:
        self._api_key = _resolve_api_key(api_key)
        self._max_retries = max_retries
        self.rate_limit = RateLimitInfo()
        self._client = httpx.Client(
            base_url=base_url,
            headers=_build_headers(self._api_key),
            timeout=timeout,
        )

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any = None,
        data: Any = None,
        files: Any = None,
        raw_response: bool = False,
    ) -> Any:
        last_exc: Exception | None = None
        last_response: httpx.Response | None = None

        for attempt in range(self._max_retries + 1):
            if attempt > 0 and last_response is not None:
                wait = _backoff_wait(attempt - 1, last_response)
                time.sleep(wait)

            try:
                response = self._client.request(
                    method, path, params=params, json=json, data=data, files=files
                )
            except httpx.TimeoutException as e:
                last_exc = ApiError(f"Request timed out: {e}", status_code=None)
                last_response = None
                if attempt < self._max_retries:
                    continue
                raise last_exc from e

            _update_rate_limit(self.rate_limit, response)

            if response.status_code < 400:
                if raw_response:
                    return response
                return response.json()

            if response.status_code in _RETRYABLE_STATUS_CODES and attempt < self._max_retries:
                last_response = response
                last_exc = _map_error(response)
                continue

            raise _map_error(response)

        raise last_exc  # type: ignore[misc]

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> SyncHttpClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class AsyncHttpClient:
    """Asynchronous HTTP client with retry logic."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
    ) -> None:
        self._api_key = _resolve_api_key(api_key)
        self._max_retries = max_retries
        self.rate_limit = RateLimitInfo()
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers=_build_headers(self._api_key),
            timeout=timeout,
        )

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any = None,
        data: Any = None,
        files: Any = None,
        raw_response: bool = False,
    ) -> Any:
        import asyncio

        last_exc: Exception | None = None
        last_response: httpx.Response | None = None

        for attempt in range(self._max_retries + 1):
            if attempt > 0 and last_response is not None:
                wait = _backoff_wait(attempt - 1, last_response)
                await asyncio.sleep(wait)

            try:
                response = await self._client.request(
                    method, path, params=params, json=json, data=data, files=files
                )
            except httpx.TimeoutException as e:
                last_exc = ApiError(f"Request timed out: {e}", status_code=None)
                last_response = None
                if attempt < self._max_retries:
                    continue
                raise last_exc from e

            _update_rate_limit(self.rate_limit, response)

            if response.status_code < 400:
                if raw_response:
                    return response
                return response.json()

            if response.status_code in _RETRYABLE_STATUS_CODES and attempt < self._max_retries:
                last_response = response
                last_exc = _map_error(response)
                continue

            raise _map_error(response)

        raise last_exc  # type: ignore[misc]

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> AsyncHttpClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
