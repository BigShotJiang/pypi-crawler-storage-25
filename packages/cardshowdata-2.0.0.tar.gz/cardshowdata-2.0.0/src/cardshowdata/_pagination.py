"""Pagination containers and auto-paging iterators."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, AsyncIterator, Callable, Coroutine, Generic, Iterator, TypeVar

T = TypeVar("T")


@dataclass
class Pagination:
    """Offset-based pagination metadata."""

    page: int
    page_size: int
    total_count: int
    total_pages: int
    next_href: str | None
    prev_href: str | None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Pagination:
        return cls(
            page=data["page"],
            page_size=data["page_size"],
            total_count=data["total_count"],
            total_pages=data["total_pages"],
            next_href=data.get("next_href"),
            prev_href=data.get("prev_href"),
        )


@dataclass
class OffsetPage(Generic[T]):
    """A single page of offset-paginated results."""

    data: list[T]
    pagination: Pagination

    def has_next(self) -> bool:
        return self.pagination.page < self.pagination.total_pages


@dataclass
class CursorPage(Generic[T]):
    """A single page of cursor-paginated results."""

    items: list[T]
    next_cursor: str | None
    count: int

    def has_next(self) -> bool:
        return self.next_cursor is not None


class SyncOffsetIterator(Generic[T]):
    """Auto-paging iterator for offset-paginated endpoints."""

    def __init__(
        self,
        fetch_page: Callable[..., OffsetPage[T]],
        kwargs: dict[str, Any],
    ) -> None:
        self._fetch_page = fetch_page
        self._kwargs = kwargs
        self._current_page: OffsetPage[T] | None = None
        self._index = 0

    def __iter__(self) -> Iterator[T]:
        return self

    def __next__(self) -> T:
        while True:
            if self._current_page is None:
                self._current_page = self._fetch_page(**self._kwargs)
                self._index = 0

            if self._index < len(self._current_page.data):
                item = self._current_page.data[self._index]
                self._index += 1
                return item

            if not self._current_page.has_next():
                raise StopIteration

            self._kwargs["page"] = self._current_page.pagination.page + 1
            self._current_page = None


class AsyncOffsetIterator(Generic[T]):
    """Auto-paging async iterator for offset-paginated endpoints."""

    def __init__(
        self,
        fetch_page: Callable[..., Coroutine[Any, Any, OffsetPage[T]]],
        kwargs: dict[str, Any],
    ) -> None:
        self._fetch_page = fetch_page
        self._kwargs = kwargs
        self._current_page: OffsetPage[T] | None = None
        self._index = 0

    def __aiter__(self) -> AsyncIterator[T]:
        return self

    async def __anext__(self) -> T:
        while True:
            if self._current_page is None:
                self._current_page = await self._fetch_page(**self._kwargs)
                self._index = 0

            if self._index < len(self._current_page.data):
                item = self._current_page.data[self._index]
                self._index += 1
                return item

            if not self._current_page.has_next():
                raise StopAsyncIteration

            self._kwargs["page"] = self._current_page.pagination.page + 1
            self._current_page = None


class SyncCursorIterator(Generic[T]):
    """Auto-paging iterator for cursor-paginated endpoints."""

    def __init__(
        self,
        fetch_page: Callable[..., CursorPage[T]],
        kwargs: dict[str, Any],
    ) -> None:
        self._fetch_page = fetch_page
        self._kwargs = kwargs
        self._current_page: CursorPage[T] | None = None
        self._index = 0

    def __iter__(self) -> Iterator[T]:
        return self

    def __next__(self) -> T:
        while True:
            if self._current_page is None:
                self._current_page = self._fetch_page(**self._kwargs)
                self._index = 0

            if self._index < len(self._current_page.items):
                item = self._current_page.items[self._index]
                self._index += 1
                return item

            if not self._current_page.has_next():
                raise StopIteration

            self._kwargs["cursor"] = self._current_page.next_cursor
            self._current_page = None


class AsyncCursorIterator(Generic[T]):
    """Auto-paging async iterator for cursor-paginated endpoints."""

    def __init__(
        self,
        fetch_page: Callable[..., Coroutine[Any, Any, CursorPage[T]]],
        kwargs: dict[str, Any],
    ) -> None:
        self._fetch_page = fetch_page
        self._kwargs = kwargs
        self._current_page: CursorPage[T] | None = None
        self._index = 0

    def __aiter__(self) -> AsyncIterator[T]:
        return self

    async def __anext__(self) -> T:
        while True:
            if self._current_page is None:
                self._current_page = await self._fetch_page(**self._kwargs)
                self._index = 0

            if self._index < len(self._current_page.items):
                item = self._current_page.items[self._index]
                self._index += 1
                return item

            if not self._current_page.has_next():
                raise StopAsyncIteration

            self._kwargs["cursor"] = self._current_page.next_cursor
            self._current_page = None
