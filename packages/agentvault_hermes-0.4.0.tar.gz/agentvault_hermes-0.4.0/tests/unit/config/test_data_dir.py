"""Unit tests for core/config/data_dir.py — profile-aware path resolution."""
from __future__ import annotations

import os
from pathlib import Path

import pytest

from agentvault_hermes.core.config.data_dir import (
    ensure_data_dir,
    hermes_config_path,
    resolve_data_dir,
    resolve_hermes_home,
)


def test_resolve_hermes_home_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("HERMES_HOME", raising=False)
    assert resolve_hermes_home() == Path(os.path.expanduser("~")) / ".hermes"


def test_resolve_hermes_home_from_env(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("HERMES_HOME", str(tmp_path / "custom"))
    assert resolve_hermes_home() == tmp_path / "custom"


def test_resolve_hermes_home_named_profile(monkeypatch: pytest.MonkeyPatch) -> None:
    # An explicit profile beats HERMES_HOME.
    monkeypatch.setenv("HERMES_HOME", "/should/be/ignored")
    expected = Path(os.path.expanduser("~")) / ".hermes" / "profiles" / "work"
    assert resolve_hermes_home("work") == expected


def test_resolve_hermes_home_rejects_path_traversal() -> None:
    with pytest.raises(ValueError):
        resolve_hermes_home("../escape")


def test_resolve_hermes_home_rejects_trailing_newline() -> None:
    with pytest.raises(ValueError):
        resolve_hermes_home("valid\n")


def test_resolve_hermes_home_empty_env_falls_through_to_default(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("HERMES_HOME", "")
    assert resolve_hermes_home() == Path(os.path.expanduser("~")) / ".hermes"


def test_hermes_config_path_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("HERMES_HOME", raising=False)
    assert hermes_config_path() == Path(os.path.expanduser("~")) / ".hermes" / "config.yaml"


def test_hermes_config_path_named_profile() -> None:
    expected = (
        Path(os.path.expanduser("~")) / ".hermes" / "profiles" / "work" / "config.yaml"
    )
    assert hermes_config_path("work") == expected


def test_resolve_data_dir_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("HERMES_HOME", raising=False)
    monkeypatch.delenv("AGENTVAULT_HERMES_DATA_DIR", raising=False)
    assert resolve_data_dir() == Path(os.path.expanduser("~")) / ".hermes" / "agentvault"


def test_resolve_data_dir_named_profile() -> None:
    expected = (
        Path(os.path.expanduser("~")) / ".hermes" / "profiles" / "work" / "agentvault"
    )
    assert resolve_data_dir("work") == expected


def test_resolve_data_dir_env_override_applies_only_without_profile(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setenv("AGENTVAULT_HERMES_DATA_DIR", str(tmp_path / "ovr"))
    # No profile → override honored.
    assert resolve_data_dir() == tmp_path / "ovr"
    # Explicit profile → override ignored, profile path wins (config + state stay consistent).
    assert resolve_data_dir("work") == (
        Path(os.path.expanduser("~")) / ".hermes" / "profiles" / "work" / "agentvault"
    )


def test_ensure_data_dir_creates_with_secure_mode(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setenv("AGENTVAULT_HERMES_DATA_DIR", str(tmp_path / "d"))
    path = ensure_data_dir()
    assert path.is_dir()
    if os.name == "posix":
        assert (path.stat().st_mode & 0o777) == 0o700


def test_ensure_data_dir_idempotent(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("AGENTVAULT_HERMES_DATA_DIR", str(tmp_path / "d"))
    ensure_data_dir()
    ensure_data_dir()  # must not raise
