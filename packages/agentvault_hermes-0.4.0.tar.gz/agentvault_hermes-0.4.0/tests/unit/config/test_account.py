"""Unit tests for core/config/account.py — profile config resolution."""
from __future__ import annotations

import os
from pathlib import Path

import pytest

from agentvault_hermes.core.config import ProfileConfig, resolve_profile


def test_resolve_profile_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("HERMES_HOME", raising=False)
    monkeypatch.delenv("AGENTVAULT_HERMES_DATA_DIR", raising=False)
    monkeypatch.delenv("AGENTVAULT_HERMES_API_URL", raising=False)
    monkeypatch.delenv("AGENTVAULT_HERMES_AGENT_NAME", raising=False)
    monkeypatch.delenv("AGENTVAULT_HERMES_HTTP_PORT", raising=False)
    cfg = resolve_profile(None)
    assert isinstance(cfg, ProfileConfig)
    assert cfg.profile is None
    assert cfg.data_dir == Path(os.path.expanduser("~")) / ".hermes" / "agentvault"
    assert cfg.api_url == "https://api.agentvault.chat"
    assert cfg.agent_name is None
    assert cfg.http_port == 18790


def test_resolve_profile_named(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("HERMES_HOME", raising=False)
    monkeypatch.delenv("AGENTVAULT_HERMES_HTTP_PORT", raising=False)
    cfg = resolve_profile("work")
    assert cfg.profile == "work"
    assert cfg.data_dir == (
        Path(os.path.expanduser("~")) / ".hermes" / "profiles" / "work" / "agentvault"
    )


def test_resolve_profile_reads_env_overrides(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("AGENTVAULT_HERMES_HTTP_PORT", raising=False)
    monkeypatch.setenv("AGENTVAULT_HERMES_API_URL", "https://example.test")
    monkeypatch.setenv("AGENTVAULT_HERMES_AGENT_NAME", "Cortina")
    cfg = resolve_profile("work")
    assert cfg.api_url == "https://example.test"
    assert cfg.agent_name == "Cortina"


def test_resolve_profile_rejects_bad_name(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("AGENTVAULT_HERMES_HTTP_PORT", raising=False)
    with pytest.raises(ValueError):
        resolve_profile("../escape")


@pytest.mark.parametrize("bad_port", ["not-a-number", "", "abc"])
def test_resolve_profile_rejects_non_integer_port(
    bad_port: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("AGENTVAULT_HERMES_HTTP_PORT", bad_port)
    with pytest.raises(ValueError, match="must be an integer"):
        resolve_profile(None)


@pytest.mark.parametrize("bad_port", ["0", "-1", "65536", "99999"])
def test_resolve_profile_rejects_out_of_range_port(
    bad_port: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("AGENTVAULT_HERMES_HTTP_PORT", bad_port)
    with pytest.raises(ValueError, match="out of range"):
        resolve_profile(None)


@pytest.mark.parametrize("good_port", ["1", "18790", "65535"])
def test_resolve_profile_accepts_valid_port(
    good_port: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("AGENTVAULT_HERMES_HTTP_PORT", good_port)
    cfg = resolve_profile(None)
    assert cfg.http_port == int(good_port)
