"""Unit tests for the legacy-layout migration."""
from __future__ import annotations

from pathlib import Path

import pytest

from agentvault_hermes.core.config.migration import migrate_legacy_layout


def _av_root(home: Path) -> Path:
    return home / ".hermes" / "agentvault"


def test_noop_when_new_layout_exists(fake_hermes_home: Path) -> None:
    av = _av_root(fake_hermes_home)
    av.mkdir(parents=True)
    (av / "state.json").write_text("{}", encoding="utf-8")
    legacy = av / "default"
    legacy.mkdir()
    (legacy / "state.json").write_text("{}", encoding="utf-8")

    migrate_legacy_layout()  # must not touch anything

    assert (av / "state.json").exists()
    assert (legacy / "state.json").exists()  # legacy left for a human (no clobber)


def test_migrates_default_account(fake_hermes_home: Path) -> None:
    av = _av_root(fake_hermes_home)
    legacy = av / "default"
    legacy.mkdir(parents=True)
    (legacy / "state.json").write_text('{"v":1}', encoding="utf-8")
    (legacy / "conversations").mkdir()
    (legacy / "conversations" / "c1.json").write_text("{}", encoding="utf-8")

    migrate_legacy_layout()

    assert (av / "state.json").read_text(encoding="utf-8") == '{"v":1}'
    assert (av / "conversations" / "c1.json").exists()
    assert not legacy.exists()  # empty legacy dir removed


def test_noop_when_nothing_to_migrate(fake_hermes_home: Path) -> None:
    migrate_legacy_layout()  # no ~/.hermes/agentvault at all — must not raise


def test_non_default_account_left_in_place(fake_hermes_home: Path) -> None:
    av = _av_root(fake_hermes_home)
    legacy_default = av / "default"
    legacy_default.mkdir(parents=True)
    (legacy_default / "state.json").write_text('{"v":1}', encoding="utf-8")
    stray = av / "alice"
    stray.mkdir()
    (stray / "state.json").write_text('{"v":1}', encoding="utf-8")

    migrate_legacy_layout()

    assert (av / "state.json").exists()           # default migrated up
    assert (stray / "state.json").exists()        # non-default untouched


def test_migration_skips_existing_dest_item(fake_hermes_home: Path) -> None:
    """If a destination already exists during the move loop, skip + warn (no clobber)."""
    av = _av_root(fake_hermes_home)
    legacy = av / "default"
    legacy.mkdir(parents=True)
    (legacy / "state.json").write_text('{"v":1,"src":"legacy"}', encoding="utf-8")
    (legacy / "conversations").mkdir()
    (legacy / "conversations" / "c1.json").write_text("legacy", encoding="utf-8")
    # Pre-existing collision at the destination (conversations/ already there):
    (av / "conversations").mkdir()
    (av / "conversations" / "c1.json").write_text("preexisting", encoding="utf-8")

    migrate_legacy_layout()

    # state.json migrates up (no collision).
    assert (av / "state.json").read_text(encoding="utf-8") == '{"v":1,"src":"legacy"}'
    # conversations/ collision → migration skipped that item, preexisting preserved.
    assert (av / "conversations" / "c1.json").read_text(encoding="utf-8") == "preexisting"
    # legacy/conversations still has its original because shutil.move was skipped
    assert (legacy / "conversations" / "c1.json").read_text(encoding="utf-8") == "legacy"
    # legacy/ itself wasn't removed (rmdir would fail, caught by OSError handler).
    assert legacy.exists()


def test_migration_continues_on_move_oserror(
    fake_hermes_home: Path,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """OSError during shutil.move is logged and the loop continues."""
    import shutil

    av = _av_root(fake_hermes_home)
    legacy = av / "default"
    legacy.mkdir(parents=True)
    (legacy / "state.json").write_text("{}", encoding="utf-8")
    (legacy / "other.txt").write_text("payload", encoding="utf-8")

    def boom(src: str, dst: str) -> str:
        raise PermissionError(f"denied: {src} → {dst}")

    monkeypatch.setattr(shutil, "move", boom)

    with caplog.at_level("WARNING"):
        migrate_legacy_layout()  # must not raise

    assert any("could not move" in r.message for r in caplog.records)
