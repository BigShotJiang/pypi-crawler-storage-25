"""Stage-2-scoped unit tests for the SecureChannel KP-publish plumbing.

Plan: ``docs/plans/2026-05-10-hermes-phase3-welcome-support-implementation.md``
§3.3 (Seam A + Seam B + state additions + lifecycle invariants P11/P15/P16/P21/P26)
+ §5.3 (test list).

These tests cover Stage 2's surface only:

- Constructor takes ``device_keys`` + ``device_id`` (P11).
- ``_ensure_pending_key_package`` publishes once, is idempotent on re-call,
  and re-runs after the bundle has been cleared.
- ``start()`` runs publish + first-pull synchronously before spawning the
  demux loop and re-raises with proper teardown on publish failure.
- ``_kp_publish_lock`` serializes concurrent republish attempts (P16).
- ``stop()`` and ``_schedule_reconnect()`` cancel an in-flight republish
  task BEFORE the next-cycle work (P21).
- ``start()`` bounds its wait on ``_kp_publish_lock`` with a 30s timeout
  and loud-fails with RuntimeError on a wedged prior holder (P26).

Out-of-scope (Stage 3+):

- The ``mls_delivery`` demux branch and ``_pull_delivery_queue`` body —
  this stage ships a no-op stub. Tests that depend on the branch
  (``test_initial_setup_complete_blocks_demux_pull``,
  ``test_demux_pull_branch_unblocks_on_start_failure``) are picked up
  in Stage 3.
- ``handle_mls_welcome`` and republish trigger wiring — Stage 4.

The KP-publish call goes through an ad-hoc ``RestClient`` constructed
inside ``_ensure_pending_key_package`` (plan defect: SecureChannel was
not previously wired with a RestClient; we follow the existing
cli/setup + cli/doctor pattern). We mock the call by patching the
``RestClient`` symbol that ``secure_channel`` imports lazily; the
patched factory returns an async-context-manager whose
``publish_key_package`` is an ``AsyncMock``.
"""
from __future__ import annotations

import asyncio
import types
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncIterator, Optional
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID

import pytest

from agentvault_hermes.channel import secure_channel as sc_module
from agentvault_hermes.channel.secure_channel import SecureChannel


# ---------------------------------------------------------------------------
# Test fixtures
# ---------------------------------------------------------------------------


_FAKE_DEVICE_ID = UUID("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
_FAKE_GROUP_ID_BYTES = UUID("01234567-89ab-cdef-0123-456789abcdef").bytes


def _fake_signing_keypair() -> Any:
    """Stand-in for ``SigningKeypair`` — Stage 2 plumbing only inspects
    the object reference, so a SimpleNamespace with the two byte fields
    is sufficient. Real key generation lives in
    ``MlsGroupState(device_keys=..., device_id=...).generate_key_package()``,
    which we mock at the class level."""
    return types.SimpleNamespace(
        public_key=b"\x01" * 32,
        private_key=b"\x02" * 32,
    )


class _FakeRelay:
    """Async-mocked Relay with the attributes Stage-2 KP-publish reads.

    ``rest_base_url`` + ``device_jwt`` are read by
    ``_ensure_pending_key_package`` to build the ad-hoc RestClient.
    """

    def __init__(self) -> None:
        self.rest_base_url = "http://test.invalid"
        self.device_jwt = "test-jwt"
        self.device_id = "device-1"
        self.connect = AsyncMock()
        self.disconnect = AsyncMock()
        self.send_message = AsyncMock()
        self.send_pong = AsyncMock()
        # Default: receive_messages never yields; demux task parks. Tests
        # that exercise the demux explicitly override this. A queue
        # sentinel keeps the AsyncIterator contract intact.
        self._inbound: asyncio.Queue[Optional[Any]] = asyncio.Queue()

    async def receive_messages(self) -> AsyncIterator[Any]:
        while True:
            item = await self._inbound.get()
            if item is None:
                return
            yield item

    async def shutdown_inbound(self) -> None:
        await self._inbound.put(None)


@pytest.fixture
def relay() -> _FakeRelay:
    return _FakeRelay()


@pytest.fixture
def stub_inbox(monkeypatch: pytest.MonkeyPatch) -> dict[str, AsyncMock]:
    """Inject a stand-in ``agentvault_hermes.channel.inbox`` so ``_demux_loop``
    can import it lazily without WS-30's real module being present."""
    from dataclasses import dataclass

    handle_mls = AsyncMock(return_value=None)
    handle_dr = AsyncMock(return_value=None)
    handle_welcome = AsyncMock()
    stub = types.ModuleType("agentvault_hermes.channel.inbox")
    stub.handle_message_mls = handle_mls  # type: ignore[attr-defined]
    stub.handle_message_dr = handle_dr  # type: ignore[attr-defined]
    stub.handle_mls_welcome = handle_welcome  # type: ignore[attr-defined]

    @dataclass(frozen=True)
    class _WelcomeOutcome:
        joined: bool
        drop: bool
        routing_key: Optional[str] = None

    stub.WelcomeOutcome = _WelcomeOutcome  # type: ignore[attr-defined]
    handle_welcome.return_value = _WelcomeOutcome(joined=False, drop=True)

    import sys

    monkeypatch.setitem(sys.modules, "agentvault_hermes.channel.inbox", stub)
    return {
        "handle_message_mls": handle_mls,
        "handle_message_dr": handle_dr,
        "handle_mls_welcome": handle_welcome,
    }


def _make_channel(
    relay: _FakeRelay,
    tmp_path: Path,
) -> SecureChannel:
    return SecureChannel(
        relay=relay,  # type: ignore[arg-type]
        mls_states={},
        on_inbound=AsyncMock(),
        data_dir=tmp_path,
        device_keys=_fake_signing_keypair(),
        device_id=_FAKE_DEVICE_ID,
        agent_name="hermes-test",
        account_id="acct-test",
    )


def _patch_mls_group_state(
    monkeypatch: pytest.MonkeyPatch,
    *,
    kp_bytes: bytes = b"\xaa\xbb\xcc",
) -> MagicMock:
    """Patch ``MlsGroupState`` (resolved inside ``_ensure_pending_key_package``)
    so it doesn't try to spin up the real mls_rs_uniffi runtime.

    Returns the constructor mock so tests can assert call counts /
    inspect each instantiated state.
    """
    instance = MagicMock(name="MlsGroupStateInstance")
    instance.generate_key_package.return_value = kp_bytes
    instance.group_id = _FAKE_GROUP_ID_BYTES
    instance.is_initialized = False
    constructor = MagicMock(name="MlsGroupStateCtor", return_value=instance)
    # _ensure_pending_key_package does:
    #   from agentvault_hermes.crypto.mls_group import MlsGroupState
    # We patch the symbol on the source module so the lazy import
    # resolves to our mock.
    import agentvault_hermes.crypto.mls_group as mls_group_module

    monkeypatch.setattr(mls_group_module, "MlsGroupState", constructor)
    return constructor


def _patch_rest_client(
    monkeypatch: pytest.MonkeyPatch,
    *,
    publish_side_effect: Any = None,
    publish_return: Any = None,
) -> AsyncMock:
    """Patch ``RestClient`` (resolved inside ``_ensure_pending_key_package``)
    so the test can drive the publish_key_package call without a real
    HTTP round-trip.

    Returns the publish_key_package AsyncMock so tests can assert call
    args / count / serialization.
    """
    publish_mock = AsyncMock(
        side_effect=publish_side_effect,
        return_value=publish_return or {"id": "kp-1", "device_id": str(_FAKE_DEVICE_ID)},
    )
    # Stage 3: ``_pull_delivery_queue`` also constructs an ad-hoc RestClient
    # via the same factory; stub the pull/ack/nack endpoints to no-ops so
    # Stage 2 tests that exercise the synchronous on-connect pull don't
    # blow up on a missing AsyncMock attribute. Tests that need to assert
    # pull/ack semantics live in test_pull_delivery_queue.py.
    pull_mock = AsyncMock(return_value=[])
    ack_mock = AsyncMock(return_value=0)
    nack_mock = AsyncMock(return_value=None)

    @asynccontextmanager
    async def _ctx(*args: Any, **kwargs: Any) -> AsyncIterator[Any]:
        client = MagicMock(name="FakeRestClient")
        client.publish_key_package = publish_mock
        client.pull_mls_delivery = pull_mock
        client.ack_mls_delivery = ack_mock
        client.nack_mls_delivery = nack_mock
        yield client

    fake_factory = MagicMock(name="RestClientFactory", side_effect=_ctx)

    import agentvault_hermes.core.transport.rest_client as rest_client_module

    monkeypatch.setattr(rest_client_module, "RestClient", fake_factory)
    return publish_mock


# ---------------------------------------------------------------------------
# Constructor (P11)
# ---------------------------------------------------------------------------


async def test_secure_channel_constructor_takes_device_keys(
    relay: _FakeRelay,
    tmp_path: Path,
) -> None:
    """P11: ``device_keys`` and ``device_id`` are required keyword-only args."""
    with pytest.raises(TypeError, match="device_keys"):
        SecureChannel(
            relay=relay,  # type: ignore[arg-type]
            mls_states={},
            on_inbound=AsyncMock(),
            data_dir=tmp_path,
            device_id=_FAKE_DEVICE_ID,  # device_keys missing
            agent_name="hermes-test",
            account_id="acct-test",
        )

    with pytest.raises(TypeError, match="device_id"):
        SecureChannel(
            relay=relay,  # type: ignore[arg-type]
            mls_states={},
            on_inbound=AsyncMock(),
            data_dir=tmp_path,
            device_keys=_fake_signing_keypair(),  # device_id missing
            agent_name="hermes-test",
            account_id="acct-test",
        )

    # Sanity: both present → no error.
    ch = _make_channel(relay, tmp_path)
    assert ch._device_id == _FAKE_DEVICE_ID
    assert ch._pending_kp_state is None
    assert ch._republish_task is None


# ---------------------------------------------------------------------------
# start() KP-publish flow (Seam A + Seam B)
# ---------------------------------------------------------------------------


async def test_start_publishes_key_package(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``start()`` calls ``RestClient.publish_key_package`` exactly once
    with the hex-encoded KP bytes, then populates ``_pending_kp_state``."""
    ctor = _patch_mls_group_state(monkeypatch, kp_bytes=b"\xde\xad\xbe\xef")
    publish = _patch_rest_client(monkeypatch)

    ch = _make_channel(relay, tmp_path)
    try:
        await ch.start()
    finally:
        await relay.shutdown_inbound()
        await ch.stop()

    publish.assert_awaited_once_with("deadbeef")
    ctor.assert_called_once()
    assert ch._pending_kp_state is ctor.return_value
    assert ch._initial_setup_complete.is_set()


async def test_start_skips_publish_on_reconnect_when_bundle_pending(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Seam A guard: when ``_pending_kp_state`` is already populated (e.g.
    a reconnect that hasn't been preceded by a successful Welcome), a
    second ``start()`` MUST NOT republish."""
    _patch_mls_group_state(monkeypatch)
    publish = _patch_rest_client(monkeypatch)

    ch = _make_channel(relay, tmp_path)
    await ch.start()
    await ch.stop()  # tear down so we can call start() again cleanly
    assert publish.await_count == 1

    # Second start without clearing _pending_kp_state.
    await ch.start()
    try:
        assert publish.await_count == 1, (
            "publish_key_package called twice — Seam A guard regressed"
        )
    finally:
        await relay.shutdown_inbound()
        await ch.stop()


async def test_start_publishes_again_after_successful_join(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Simulate post-Welcome clear (Stage 4 will do this from
    ``handle_mls_welcome``). After ``_pending_kp_state = None``, the
    next ``start()`` republishes."""
    _patch_mls_group_state(monkeypatch)
    publish = _patch_rest_client(monkeypatch)

    ch = _make_channel(relay, tmp_path)
    await ch.start()
    await ch.stop()
    assert publish.await_count == 1

    # Simulate a successful Welcome that consumed the bundle.
    ch._pending_kp_state = None

    await ch.start()
    try:
        assert publish.await_count == 2
    finally:
        await relay.shutdown_inbound()
        await ch.stop()


async def test_start_raises_on_publish_failure(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """P5 loud-fail: if ``publish_key_package`` raises, ``start()`` re-raises
    after teardown. ``_initial_setup_complete`` MUST still be set on the
    way out (P15) so a parked demux from a prior reconnect can wake."""
    _patch_mls_group_state(monkeypatch)
    boom = RuntimeError("backend rejected KP")
    _patch_rest_client(monkeypatch, publish_side_effect=boom)

    ch = _make_channel(relay, tmp_path)
    with pytest.raises(RuntimeError, match="backend rejected KP"):
        await ch.start()

    # P15 invariant: event was set on the failure path.
    assert ch._initial_setup_complete.is_set()
    # _pending_kp_state still None — failed publish must not commit.
    assert ch._pending_kp_state is None
    # No background tasks were spawned past the publish failure.
    assert len(ch._background_tasks) == 0
    # _kp_publish_lock was released even on failure (the finally-block).
    assert not ch._kp_publish_lock.locked()


async def test_pull_on_connect_runs_synchronously_in_start(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``start()`` MUST run ``_pull_delivery_queue`` BEFORE spawning the
    demux loop. This guarantees a queued Welcome is processed before the
    ``mls_delivery`` ping demux branch (Stage 3) ever fires.

    We assert by recording the call order: the pull happens before
    ``_spawn`` is first invoked (which is what kicks off the demux task).
    """
    _patch_mls_group_state(monkeypatch)
    _patch_rest_client(monkeypatch)

    call_order: list[str] = []

    original_pull = SecureChannel._pull_delivery_queue
    original_spawn = SecureChannel._spawn

    async def recording_pull(self: SecureChannel) -> None:
        call_order.append("pull")
        return await original_pull(self)

    def recording_spawn(self: SecureChannel, coro: Any) -> None:
        call_order.append("spawn")
        return original_spawn(self, coro)

    monkeypatch.setattr(SecureChannel, "_pull_delivery_queue", recording_pull)
    monkeypatch.setattr(SecureChannel, "_spawn", recording_spawn)

    ch = _make_channel(relay, tmp_path)
    try:
        await ch.start()
    finally:
        await relay.shutdown_inbound()
        await ch.stop()

    # Pull happens at least once BEFORE the first spawn.
    assert "pull" in call_order
    assert "spawn" in call_order
    assert call_order.index("pull") < call_order.index("spawn"), (
        f"pull must precede spawn; observed order: {call_order}"
    )


# ---------------------------------------------------------------------------
# _kp_publish_lock serialization (P16)
# ---------------------------------------------------------------------------


async def test_kp_publish_lock_serializes_concurrent_republishes(
    relay: _FakeRelay,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """P16: two ``_ensure_pending_key_package`` calls invoked concurrently
    (each clearing ``_pending_kp_state`` to bypass the Seam A guard) MUST
    NOT execute their publish_key_package calls in parallel — the
    ``_kp_publish_lock`` serializes them.

    We use a slow-mocked publish (held for 100ms) and assert the second
    call's start time is >= 100ms after the first call's start time.
    """
    _patch_mls_group_state(monkeypatch)

    publish_starts: list[float] = []

    async def slow_publish(kp_hex: str) -> dict[str, Any]:
        publish_starts.append(asyncio.get_event_loop().time())
        await asyncio.sleep(0.1)
        return {"id": "kp", "device_id": str(_FAKE_DEVICE_ID)}

    _patch_rest_client(monkeypatch, publish_side_effect=slow_publish)

    ch = _make_channel(relay, tmp_path)

    async def one_publish() -> None:
        # Each task must clear _pending_kp_state under the lock-free
        # window, otherwise Seam A's guard short-circuits the second
        # call. We do it BEFORE _ensure_pending_key_package so both
        # calls actually attempt to publish.
        ch._pending_kp_state = None
        async with ch._kp_publish_lock:
            ch._pending_kp_state = None
            # Inline the publish path under the lock — Stage 4's real
            # flow does the same: the fire-and-forget task is the
            # acquirer.
            from agentvault_hermes.core.transport.rest_client import RestClient
            from agentvault_hermes.crypto.mls_group import MlsGroupState

            state = MlsGroupState(
                device_keys=ch._device_keys,
                device_id=ch._device_id,
            )
            kp_bytes = state.generate_key_package()
            async with RestClient(
                base_url=relay.rest_base_url,
                device_jwt=relay.device_jwt,
            ) as client:
                await client.publish_key_package(kp_bytes.hex())
            ch._pending_kp_state = state

    await asyncio.gather(one_publish(), one_publish())

    assert len(publish_starts) == 2
    delta = publish_starts[1] - publish_starts[0]
    # Allow a tiny jitter floor; the slow publish holds 100ms so the
    # delta must be >= ~95ms in any reasonable scheduler.
    assert delta >= 0.09, (
        f"publish calls overlapped — lock did not serialize. delta={delta:.3f}s"
    )


# ---------------------------------------------------------------------------
# stop() / reconnect cancel-and-wait (P21)
# ---------------------------------------------------------------------------


async def test_stop_cancels_in_flight_republish_task(
    relay: _FakeRelay,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """P21 (stop): an in-flight ``_republish_task`` MUST be cancelled
    cleanly during ``stop()``. The 2s shielded-await bound prevents a
    wedged task from blocking stop() indefinitely."""
    _patch_mls_group_state(monkeypatch)

    cancelled_event = asyncio.Event()

    async def hanging_publish(kp_hex: str) -> dict[str, Any]:
        try:
            await asyncio.sleep(60)  # would never finish on its own
        except asyncio.CancelledError:
            cancelled_event.set()
            raise
        return {"id": "kp", "device_id": str(_FAKE_DEVICE_ID)}

    _patch_rest_client(monkeypatch, publish_side_effect=hanging_publish)

    ch = _make_channel(relay, tmp_path)
    # Spawn a republish task by calling _ensure_pending_key_package
    # under a manually-allocated task — mirrors Stage 4's fire-and-forget
    # scheduling.
    ch._republish_task = asyncio.create_task(ch._ensure_pending_key_package())
    # Yield once so the task actually starts running.
    await asyncio.sleep(0)

    # stop() must complete in well under the 2s P21 timeout because the
    # hanging publish honors CancelledError immediately.
    await asyncio.wait_for(ch.stop(), timeout=3.0)

    assert ch._republish_task is None
    # The task itself was cancelled.
    assert cancelled_event.is_set()


async def test_republish_task_cancelled_on_reconnect(
    relay: _FakeRelay,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """P21 (reconnect): an in-flight ``_republish_task`` MUST be cancelled
    BEFORE the new socket opens. Otherwise the task holds
    ``_kp_publish_lock`` across the reconnect and the next ``start()``
    would block for the full P26 timeout window.

    We verify by observing call ordering: the cancel happens before
    ``Relay.disconnect`` / ``Relay.connect`` on the reconnect path, and
    after the reconnect the lock is acquirable (i.e. nothing is wedged).
    """
    _patch_mls_group_state(monkeypatch)

    publish_started = asyncio.Event()
    cancelled_event = asyncio.Event()

    async def hanging_publish(kp_hex: str) -> dict[str, Any]:
        publish_started.set()
        try:
            await asyncio.sleep(60)
        except asyncio.CancelledError:
            cancelled_event.set()
            raise
        return {"id": "kp", "device_id": str(_FAKE_DEVICE_ID)}

    _patch_rest_client(monkeypatch, publish_side_effect=hanging_publish)

    ch = _make_channel(relay, tmp_path)

    # Stage a fake "in-flight" republish task.
    ch._republish_task = asyncio.create_task(ch._ensure_pending_key_package())
    await publish_started.wait()  # ensure it got into the publish call

    # Capture the order in which Relay.connect / disconnect fire after
    # the cancel. _schedule_reconnect calls cancel-task → disconnect →
    # connect.
    relay.connect.reset_mock()
    relay.disconnect.reset_mock()

    await ch._schedule_reconnect()

    # P21: prior task is cancelled.
    assert cancelled_event.is_set()
    assert ch._republish_task is None

    # The lock is releasable immediately — we can acquire it without
    # hitting the 30s P26 timeout. Use a short wait_for to enforce.
    await asyncio.wait_for(ch._kp_publish_lock.acquire(), timeout=1.0)
    ch._kp_publish_lock.release()

    # Disconnect+connect both ran on the reconnect path.
    relay.disconnect.assert_awaited()
    relay.connect.assert_awaited()


# ---------------------------------------------------------------------------
# P26 timeout on _kp_publish_lock acquire
# ---------------------------------------------------------------------------


async def test_start_acquires_kp_publish_lock_with_timeout(
    relay: _FakeRelay,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """P26: if a prior holder of ``_kp_publish_lock`` is wedged, ``start()``
    MUST loud-fail with ``RuntimeError`` after the bounded timeout
    rather than waiting indefinitely.

    We monkeypatch ``_KP_PUBLISH_LOCK_START_TIMEOUT_SECONDS`` to 0.1s
    for test speed; the production constant is 30s.
    """
    _patch_mls_group_state(monkeypatch)
    _patch_rest_client(monkeypatch)

    monkeypatch.setattr(
        sc_module, "_KP_PUBLISH_LOCK_START_TIMEOUT_SECONDS", 0.1
    )

    ch = _make_channel(relay, tmp_path)

    # Pre-acquire the lock from a fixture-style holder, simulating a
    # wedged prior republish.
    await ch._kp_publish_lock.acquire()

    try:
        with pytest.raises(RuntimeError, match="wedged"):
            await ch.start()
    finally:
        ch._kp_publish_lock.release()


__all__: list[str] = []
