"""Unit test: send() emits an a2a_message_mls envelope for an A2A channel."""
from __future__ import annotations

import uuid
from pathlib import Path
from unittest.mock import AsyncMock

import nacl.signing
import pytest

from agentvault_hermes.channel.secure_channel import SecureChannel
from agentvault_hermes.crypto import MlsGroupState, SigningKeypair

_A2A_CHANNEL_ID = "11111111-1111-1111-1111-111111111111"


def _keys() -> SigningKeypair:
    sk = nacl.signing.SigningKey.generate()
    return SigningKeypair(public_key=bytes(sk.verify_key), private_key=bytes(sk))


@pytest.mark.asyncio
async def test_send_to_a2a_channel_emits_a2a_envelope(tmp_path: Path) -> None:
    relay = AsyncMock(name="relay")
    relay.rest_base_url = "http://test"
    relay.device_jwt = "jwt"

    # A real, joined MLS group keyed by the a2a_channel_id.
    device_id = uuid.uuid4()
    group = MlsGroupState(device_keys=_keys(), device_id=device_id)
    group.create_group(b"\x42" * 16)
    mls_states = {_A2A_CHANNEL_ID: group}

    ch = SecureChannel(
        relay=relay, mls_states=mls_states, on_inbound=AsyncMock(),
        data_dir=tmp_path, device_keys=_keys(), device_id=device_id,
        agent_name="test-agent", account_id="acct-1",
    )
    # Register the channel so send() detects it as A2A.
    ch._a2a_registry.record_welcome(
        _A2A_CHANNEL_ID, "22222222-2222-2222-2222-222222222222"
    )

    await ch.send(conversation_id=_A2A_CHANNEL_ID, plaintext=b"on it")

    relay.send_message.assert_awaited()
    assert relay.send_message.await_args.kwargs["a2a_channel_id"] == _A2A_CHANNEL_ID
