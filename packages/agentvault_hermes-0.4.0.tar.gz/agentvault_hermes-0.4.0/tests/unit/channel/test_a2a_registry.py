"""Unit tests for channel/a2a_registry.py."""
from __future__ import annotations

from pathlib import Path

from agentvault_hermes.channel.a2a_registry import (
    A2AChannelRegistry,
    A2AParticipant,
)

_CHANNEL_ID = "11111111-1111-1111-1111-111111111111"
_GROUP_ID = "22222222-2222-2222-2222-222222222222"
_PEER_HUB = "33333333-3333-3333-3333-333333333333"
_PEER2_HUB = "44444444-4444-4444-4444-444444444444"


def _event_payload() -> dict:
    return {
        "a2a_channel_id": _CHANNEL_ID,
        "conversation_id": "conv-1",
        "role": "member",
        "topic": "ship the launch",
        "participants": [
            {"hub_id": _PEER_HUB, "hub_address": "hub://alice", "status": "active"},
        ],
    }


def test_upsert_from_event_populates_entry() -> None:
    r = A2AChannelRegistry()
    entry = r.upsert_from_event(_event_payload())
    assert entry.a2a_channel_id == _CHANNEL_ID
    assert entry.conversation_id == "conv-1"
    assert entry.role == "member"
    assert entry.topic == "ship the launch"
    assert entry.participants[_PEER_HUB].hub_address == "hub://alice"
    assert entry.mls_group_id is None
    assert r.get(_CHANNEL_ID) is entry


def test_upsert_from_poll_is_an_event_merge() -> None:
    r = A2AChannelRegistry()
    entry = r.upsert_from_poll(_event_payload())
    assert entry.a2a_channel_id == _CHANNEL_ID
    assert set(entry.participants) == {_PEER_HUB}


def test_record_welcome_creates_minimal_entry() -> None:
    r = A2AChannelRegistry()
    entry = r.record_welcome(_CHANNEL_ID, _GROUP_ID)
    assert entry.mls_group_id == _GROUP_ID
    assert entry.conversation_id is None
    assert entry.participants == {}


def test_merge_welcome_then_event_keeps_both() -> None:
    r = A2AChannelRegistry()
    r.record_welcome(_CHANNEL_ID, _GROUP_ID)
    r.upsert_from_event(_event_payload())
    entry = r.get(_CHANNEL_ID)
    assert entry is not None
    assert entry.mls_group_id == _GROUP_ID          # welcome value preserved
    assert entry.topic == "ship the launch"          # event value applied


def test_merge_event_then_welcome_keeps_both() -> None:
    r = A2AChannelRegistry()
    r.upsert_from_event(_event_payload())
    r.record_welcome(_CHANNEL_ID, _GROUP_ID)
    entry = r.get(_CHANNEL_ID)
    assert entry is not None
    assert entry.topic == "ship the launch"          # event value preserved
    assert entry.mls_group_id == _GROUP_ID           # welcome value applied


def test_update_participant_changes_status() -> None:
    r = A2AChannelRegistry()
    r.upsert_from_event(_event_payload())
    r.update_participant(_CHANNEL_ID, _PEER_HUB, "left")
    entry = r.get(_CHANNEL_ID)
    assert entry is not None
    assert entry.participants[_PEER_HUB].status == "left"


def test_update_participant_adds_unknown_peer() -> None:
    r = A2AChannelRegistry()
    r.upsert_from_event(_event_payload())
    r.update_participant(_CHANNEL_ID, _PEER2_HUB, "active")
    entry = r.get(_CHANNEL_ID)
    assert entry is not None
    assert entry.participants[_PEER2_HUB].status == "active"


def test_update_participant_unknown_channel_is_noop() -> None:
    r = A2AChannelRegistry()
    r.update_participant("no-such-channel", _PEER_HUB, "left")  # must not raise


def test_set_role() -> None:
    r = A2AChannelRegistry()
    r.upsert_from_event(_event_payload())
    r.set_role(_CHANNEL_ID, "creator")
    entry = r.get(_CHANNEL_ID)
    assert entry is not None
    assert entry.role == "creator"


def test_remove() -> None:
    r = A2AChannelRegistry()
    r.upsert_from_event(_event_payload())
    r.remove(_CHANNEL_ID)
    assert r.get(_CHANNEL_ID) is None
    r.remove(_CHANNEL_ID)  # idempotent — must not raise


def test_resolve_by_group_id() -> None:
    r = A2AChannelRegistry()
    r.record_welcome(_CHANNEL_ID, _GROUP_ID)
    assert r.resolve_by_group_id(_GROUP_ID) is r.get(_CHANNEL_ID)
    assert r.resolve_by_group_id("no-such-group") is None


def test_save_then_load_round_trips(tmp_path: Path) -> None:
    r = A2AChannelRegistry()
    r.upsert_from_event(_event_payload())
    r.record_welcome(_CHANNEL_ID, _GROUP_ID)
    r.save(tmp_path)
    assert (tmp_path / "a2a_channels.json").exists()

    r2 = A2AChannelRegistry()
    r2.load(tmp_path)
    entry = r2.get(_CHANNEL_ID)
    assert entry is not None
    assert entry.topic == "ship the launch"
    assert entry.mls_group_id == _GROUP_ID
    assert entry.participants[_PEER_HUB] == A2AParticipant(
        hub_id=_PEER_HUB, hub_address="hub://alice", status="active"
    )


def test_load_missing_file_is_empty(tmp_path: Path) -> None:
    r = A2AChannelRegistry()
    r.load(tmp_path)
    assert r.all() == []


def test_load_malformed_file_does_not_raise(tmp_path: Path) -> None:
    (tmp_path / "a2a_channels.json").write_text("{not json", encoding="utf-8")
    r = A2AChannelRegistry()
    r.load(tmp_path)  # must not raise
    assert r.all() == []


def test_load_valid_json_wrong_shape_does_not_raise(tmp_path: Path) -> None:
    (tmp_path / "a2a_channels.json").write_text("[1, 2, 3]", encoding="utf-8")
    r = A2AChannelRegistry()
    r.load(tmp_path)  # must not raise
    assert r.all() == []


# --- Slice B new fields: creator_device_id + pending_kp_hub_ids -------------

def test_entry_has_creator_device_id_field_defaulting_to_none() -> None:
    """A2AChannelEntry.creator_device_id is None until found_a2a_group sets it."""
    from agentvault_hermes.channel.a2a_registry import A2AChannelEntry

    entry = A2AChannelEntry(a2a_channel_id="ch-1")
    assert entry.creator_device_id is None


def test_entry_has_pending_kp_hub_ids_field_defaulting_to_empty() -> None:
    """A2AChannelEntry.pending_kp_hub_ids is an empty list until founder marks missing."""
    from agentvault_hermes.channel.a2a_registry import A2AChannelEntry

    entry = A2AChannelEntry(a2a_channel_id="ch-1")
    assert entry.pending_kp_hub_ids == []


def test_creator_device_id_round_trips_through_save_load(tmp_path: Path) -> None:
    """Saving + loading the registry preserves creator_device_id."""
    from agentvault_hermes.channel.a2a_registry import (
        A2AChannelEntry,
        A2AChannelRegistry,
    )

    reg = A2AChannelRegistry()
    entry = A2AChannelEntry(
        a2a_channel_id="ch-1",
        role="creator",
        creator_device_id="device-abc",
    )
    reg._channels[entry.a2a_channel_id] = entry
    reg.save(tmp_path)

    loaded = A2AChannelRegistry()
    loaded.load(tmp_path)
    assert loaded.get("ch-1") is not None
    assert loaded.get("ch-1").creator_device_id == "device-abc"


def test_pending_kp_hub_ids_round_trips_through_save_load(tmp_path: Path) -> None:
    """Saving + loading the registry preserves pending_kp_hub_ids."""
    from agentvault_hermes.channel.a2a_registry import (
        A2AChannelEntry,
        A2AChannelRegistry,
    )

    reg = A2AChannelRegistry()
    entry = A2AChannelEntry(
        a2a_channel_id="ch-1",
        pending_kp_hub_ids=["hub-a", "hub-b"],
    )
    reg._channels[entry.a2a_channel_id] = entry
    reg.save(tmp_path)

    loaded = A2AChannelRegistry()
    loaded.load(tmp_path)
    assert loaded.get("ch-1") is not None
    assert loaded.get("ch-1").pending_kp_hub_ids == ["hub-a", "hub-b"]


def test_pending_kp_hub_ids_default_factory_independent_per_entry() -> None:
    """Two A2AChannelEntry instances must NOT share the same list (classic
    mutable default footgun). Mutating one entry's list must not bleed into
    the other."""
    from agentvault_hermes.channel.a2a_registry import A2AChannelEntry

    a = A2AChannelEntry(a2a_channel_id="ch-a")
    b = A2AChannelEntry(a2a_channel_id="ch-b")
    a.pending_kp_hub_ids.append("hub-a")
    assert b.pending_kp_hub_ids == [], (
        "A2AChannelEntry.pending_kp_hub_ids must use field(default_factory=list); "
        "shared mutable default would leak hub-a into entry b"
    )
