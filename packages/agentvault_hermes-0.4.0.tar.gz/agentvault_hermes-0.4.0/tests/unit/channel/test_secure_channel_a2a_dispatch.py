"""Unit test: _dispatch_inbound surfaces A2A messages with no mention gate."""
from __future__ import annotations

import uuid
from pathlib import Path
from unittest.mock import AsyncMock

import nacl.signing
import pytest

from agentvault_hermes.channel.inbox import InboundMessage
from agentvault_hermes.channel.secure_channel import SecureChannel
from agentvault_hermes.crypto import SigningKeypair

_A2A_CHANNEL_ID = "11111111-1111-1111-1111-111111111111"


def _keys() -> SigningKeypair:
    sk = nacl.signing.SigningKey.generate()
    return SigningKeypair(public_key=bytes(sk.verify_key), private_key=bytes(sk))


@pytest.mark.asyncio
async def test_dispatch_inbound_surfaces_a2a_message(tmp_path: Path) -> None:
    received: list[InboundMessage] = []

    async def on_inbound(msg: InboundMessage) -> None:
        received.append(msg)

    relay = AsyncMock(name="relay")
    relay.rest_base_url = "http://test"
    relay.device_jwt = "jwt"
    ch = SecureChannel(
        relay=relay, mls_states={}, on_inbound=on_inbound, data_dir=tmp_path,
        device_keys=_keys(), device_id=uuid.uuid4(), agent_name="test-agent",
        account_id="acct-1",
    )
    msg = InboundMessage(
        conversation_id="conv-1",
        plaintext="hello from peer",
        sender_device_id="peer-device",
        server_message_id="m-1",
        message_type="text",
        is_handshake=False,
        a2a_channel_id=_A2A_CHANNEL_ID,
        from_hub_address="hub://alice",
    )
    await ch._dispatch_inbound(msg)

    assert len(received) == 1
    assert received[0].a2a_channel_id == _A2A_CHANNEL_ID
    assert received[0].from_hub_address == "hub://alice"
    assert received[0].plaintext == "hello from peer"  # no [sender]: rewrite
