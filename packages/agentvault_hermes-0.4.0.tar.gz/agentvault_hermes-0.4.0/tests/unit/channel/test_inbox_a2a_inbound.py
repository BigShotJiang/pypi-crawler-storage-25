"""Unit tests for A2A fields on InboundMessage."""
from __future__ import annotations

import dataclasses

from agentvault_hermes.channel.inbox import InboundMessage


def test_inbound_message_has_a2a_fields() -> None:
    fields = {f.name for f in dataclasses.fields(InboundMessage)}
    assert "a2a_channel_id" in fields
    assert "from_hub_address" in fields


def test_inbound_message_a2a_fields_default_none() -> None:
    fields = {f.name: f for f in dataclasses.fields(InboundMessage)}
    assert fields["a2a_channel_id"].default is None
    assert fields["from_hub_address"].default is None
