"""Unit tests for WSEventRegistry.

Targets >=95% coverage on event_registry.py per the Phase 4a PR-1 spec.
"""
from __future__ import annotations

import asyncio
import logging
from unittest.mock import AsyncMock

import pytest

from agentvault_hermes.channel.event_registry import (
    WSEventRegistry,
)


def test_registry_init_is_empty() -> None:
    """A fresh registry has no registered handlers."""
    registry = WSEventRegistry()
    assert registry._handlers == {}


def test_register_adds_handler() -> None:
    """register() stores the handler under its event_type key."""
    registry = WSEventRegistry()
    handler = AsyncMock()
    registry.register("ping", handler)
    assert registry._handlers["ping"] is handler


def test_register_raises_on_double_register() -> None:
    """register() raises ValueError when an event_type is already registered.

    Fail-fast for handler-collision bugs at startup, not at runtime.
    """
    registry = WSEventRegistry()
    registry.register("ping", AsyncMock())
    with pytest.raises(ValueError, match="event_type='ping'"):
        registry.register("ping", AsyncMock())


@pytest.mark.asyncio
async def test_dispatch_routes_to_registered_handler() -> None:
    """dispatch() awaits the handler registered under the event_type."""
    from agentvault_hermes.channel.outbox import WireEnvelope

    registry = WSEventRegistry()
    handler = AsyncMock()
    registry.register("ping", handler)

    envelope = WireEnvelope(event="ping", data={})
    await registry.dispatch("ping", envelope)

    handler.assert_awaited_once_with(envelope)


@pytest.mark.asyncio
async def test_dispatch_unknown_event_logs_debug(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """dispatch() with unrecognized event_type logs DEBUG and returns."""
    from agentvault_hermes.channel.outbox import WireEnvelope

    registry = WSEventRegistry()
    envelope = WireEnvelope(event="never_registered", data={})

    with caplog.at_level(
        logging.DEBUG, logger="agentvault_hermes.channel.event_registry"
    ):
        await registry.dispatch("never_registered", envelope)

    assert any(
        "Unknown WS event" in record.message and record.levelno == logging.DEBUG
        for record in caplog.records
    )


@pytest.mark.asyncio
async def test_dispatch_catches_handler_exception_logs_warn(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """dispatch() catches any Exception from a handler, logs WARN with
    event_type and a BLAKE2b-8 payload hash, and returns.
    """
    import re

    from agentvault_hermes.channel.outbox import WireEnvelope

    async def broken_handler(envelope: WireEnvelope) -> None:
        raise RuntimeError("simulated bug")

    registry = WSEventRegistry()
    registry.register("ping", broken_handler)

    envelope = WireEnvelope(event="ping", data={"foo": "bar"})

    with caplog.at_level(
        logging.WARNING, logger="agentvault_hermes.channel.event_registry"
    ):
        await registry.dispatch("ping", envelope)

    warn_records = [r for r in caplog.records if r.levelno == logging.WARNING]
    assert len(warn_records) == 1
    msg = warn_records[0].getMessage()
    assert "event_type='ping'" in msg or "event_type=ping" in msg
    assert "payload_hash=" in msg
    hash_match = re.search(r"payload_hash=([0-9a-f]+)", msg)
    assert hash_match is not None
    assert len(hash_match.group(1)) == 8


@pytest.mark.asyncio
async def test_dispatch_propagates_cancelled_error(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """dispatch() must propagate asyncio.CancelledError so stop()/teardown
    works. Must NOT log it (CancelledError is normal control flow).
    """
    from agentvault_hermes.channel.outbox import WireEnvelope

    async def cancelling_handler(envelope: WireEnvelope) -> None:
        raise asyncio.CancelledError()

    registry = WSEventRegistry()
    registry.register("ping", cancelling_handler)

    envelope = WireEnvelope(event="ping", data={})

    with caplog.at_level(
        logging.WARNING, logger="agentvault_hermes.channel.event_registry"
    ):
        with pytest.raises(asyncio.CancelledError):
            await registry.dispatch("ping", envelope)

    warn_records = [r for r in caplog.records if r.levelno == logging.WARNING]
    assert warn_records == [], "CancelledError must not produce a WARN log"


@pytest.mark.asyncio
async def test_dispatch_logs_unhashable_when_payload_cannot_hash(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """If _hash_payload fails (non-serializable envelope.data), dispatch
    must still log WARN and absorb the original handler exception.

    Defects this guards against: _hash_payload raising from inside the
    except-block, replacing the original handler traceback and re-breaking
    the demux loop the registry exists to protect.
    """
    from agentvault_hermes.channel.outbox import WireEnvelope

    async def broken_handler(envelope: "WireEnvelope") -> None:
        raise RuntimeError("simulated bug")

    registry = WSEventRegistry()
    registry.register("ping", broken_handler)

    # bytes are not JSON-serializable and default=str on bytes produces a
    # repr — not exactly unhashable; the more reliable trigger is a recursive
    # dict.
    recursive: dict[str, object] = {}
    recursive["self"] = recursive
    envelope = WireEnvelope(event="ping", data=recursive)

    with caplog.at_level(logging.WARNING, logger="agentvault_hermes.channel.event_registry"):
        await registry.dispatch("ping", envelope)  # must NOT raise

    warn_records = [r for r in caplog.records if r.levelno == logging.WARNING]
    assert len(warn_records) == 1
    msg = warn_records[0].getMessage()
    assert "payload_hash=unhashable" in msg


@pytest.mark.asyncio
async def test_dispatch_safe_under_concurrent_calls(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Multiple concurrent dispatch() calls must each invoke their handlers
    independently. One raising must not affect the other."""
    from agentvault_hermes.channel.outbox import WireEnvelope

    good_handler = AsyncMock()

    async def bad_handler(envelope: "WireEnvelope") -> None:
        raise RuntimeError("simulated bug")

    registry = WSEventRegistry()
    registry.register("good", good_handler)
    registry.register("bad", bad_handler)

    env_good = WireEnvelope(event="good", data={})
    env_bad = WireEnvelope(event="bad", data={})

    with caplog.at_level(logging.WARNING, logger="agentvault_hermes.channel.event_registry"):
        await asyncio.gather(
            registry.dispatch("good", env_good),
            registry.dispatch("bad", env_bad),
        )

    good_handler.assert_awaited_once_with(env_good)
    warn_records = [r for r in caplog.records if r.levelno == logging.WARNING]
    assert len(warn_records) == 1
    assert "event_type='bad'" in warn_records[0].getMessage()


def test_payload_hash_deterministic() -> None:
    """Same envelope content produces the same hash; key order doesn't matter."""
    from agentvault_hermes.channel.event_registry import _hash_payload
    from agentvault_hermes.channel.outbox import WireEnvelope

    env_a = WireEnvelope(event="ping", data={"a": 1, "b": 2})
    env_b = WireEnvelope(event="ping", data={"b": 2, "a": 1})
    env_c = WireEnvelope(event="ping", data={"a": 1, "b": 3})

    assert _hash_payload(env_a) == _hash_payload(env_b)
    assert _hash_payload(env_a) != _hash_payload(env_c)


def test_payload_hash_length_is_eight_hex_chars() -> None:
    """digest_size=4 → 4 bytes → 8 hex chars."""
    from agentvault_hermes.channel.event_registry import _hash_payload
    from agentvault_hermes.channel.outbox import WireEnvelope

    h = _hash_payload(WireEnvelope(event="ping", data={"x": 1}))
    assert len(h) == 8
    assert all(c in "0123456789abcdef" for c in h)


def test_registered_event_types_returns_registered_set() -> None:
    """``registered_event_types()`` exposes the current set of event_type
    strings without leaking the underlying mutable dict.

    Public introspection surface — future operator-debug endpoints and
    the integration regression guard at
    ``test_secure_channel.py::test_secure_channel_registers_all_five_event_handlers``
    both call this method instead of reaching into the private
    ``_handlers`` dict.
    """
    registry = WSEventRegistry()
    assert registry.registered_event_types() == set()

    registry.register("ping", AsyncMock())
    registry.register("error", AsyncMock())
    assert registry.registered_event_types() == {"ping", "error"}

    # Returned set is a fresh copy — mutating it must not affect the
    # registry's internal state.
    snapshot = registry.registered_event_types()
    snapshot.add("forged")
    assert registry.registered_event_types() == {"ping", "error"}
