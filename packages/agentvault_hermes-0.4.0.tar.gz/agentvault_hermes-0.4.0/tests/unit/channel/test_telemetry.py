"""Unit tests for the MlsTelemetryEmitter and its types.

Spec: docs/superpowers/specs/2026-05-14-hermes-phase4b-mls-telemetry-and-ui-design.md (PR-4b-A1)
"""
from __future__ import annotations

import logging
from typing import Any

import pytest

from agentvault_hermes.channel.telemetry import (
    MlsTelemetryEmitter,
    MlsTelemetryEvent,
    MlsTelemetryEventType,
    TelemetrySender,
)


class _RecordingSender:
    """In-memory TelemetrySender double for tests."""

    def __init__(self) -> None:
        self.sent: list[dict[str, Any]] = []
        self.raise_on_send: BaseException | None = None

    async def send(self, envelope: dict[str, Any]) -> None:
        if self.raise_on_send is not None:
            raise self.raise_on_send
        self.sent.append(envelope)


@pytest.mark.asyncio
async def test_emit_sends_envelope_with_correct_shape() -> None:
    sender = _RecordingSender()
    emitter = MlsTelemetryEmitter(sender)

    await emitter.emit(
        MlsTelemetryEvent(
            event=MlsTelemetryEventType.COLD_START_FAIL,
            group_id="abc123",
            context={"step": "request_welcome", "scan_run_id": 7},
        )
    )

    assert sender.sent == [
        {
            "event": "telemetry.mls",
            "data": {
                "event": "cold_start_fail",
                "group_id": "abc123",
                "context": {"step": "request_welcome", "scan_run_id": 7},
            },
        }
    ]


@pytest.mark.asyncio
async def test_emit_allows_null_group_id_for_scan_level_events() -> None:
    sender = _RecordingSender()
    emitter = MlsTelemetryEmitter(sender)

    await emitter.emit(
        MlsTelemetryEvent(
            event=MlsTelemetryEventType.COLD_START_PERSISTENCE_FAIL,
            group_id=None,
            context={"scan_run_id": 3},
        )
    )

    assert sender.sent[0]["data"]["group_id"] is None


@pytest.mark.asyncio
async def test_emit_absorbs_sender_failure_with_warn_log(
    caplog: pytest.LogCaptureFixture,
) -> None:
    sender = _RecordingSender()
    sender.raise_on_send = RuntimeError("boom")
    emitter = MlsTelemetryEmitter(sender)

    with caplog.at_level(logging.WARNING, logger="agentvault_hermes.channel.telemetry"):
        await emitter.emit(
            MlsTelemetryEvent(
                event=MlsTelemetryEventType.JOINED,
                group_id="g1",
                context={},
            )
        )

    assert any("telemetry_emit_failed" in r.message for r in caplog.records)
    # event must not propagate
    assert sender.sent == []


@pytest.mark.asyncio
async def test_emit_propagates_cancelled_error_for_caller_cancellation() -> None:
    """When the caller's task is cancelled mid-await, emit must NOT absorb
    CancelledError — it must propagate so asyncio cooperative cancellation
    works. This is the inverse of the failure-absorption contract for
    regular Exceptions.
    """
    import asyncio

    sender_started = asyncio.Event()
    release_sender = asyncio.Event()

    class _SuspendingSender:
        async def send(self, envelope: dict[str, Any]) -> None:
            sender_started.set()
            await release_sender.wait()  # suspended until released

    emitter = MlsTelemetryEmitter(_SuspendingSender())

    async def _runner() -> None:
        await emitter.emit(
            MlsTelemetryEvent(
                event=MlsTelemetryEventType.JOINED,
                group_id="g1",
                context={},
            )
        )

    task = asyncio.create_task(_runner())
    await sender_started.wait()
    task.cancel()

    with pytest.raises(asyncio.CancelledError):
        await task

    assert task.cancelled()


@pytest.mark.asyncio
async def test_emit_does_not_absorb_keyboard_interrupt() -> None:
    """BaseException-derived exceptions (KeyboardInterrupt, SystemExit) must
    propagate. Absorbing them would mean Ctrl+C is silently dropped if it
    happens to arrive while telemetry is mid-flight."""
    sender = _RecordingSender()
    sender.raise_on_send = KeyboardInterrupt()
    emitter = MlsTelemetryEmitter(sender)

    with pytest.raises(KeyboardInterrupt):
        await emitter.emit(
            MlsTelemetryEvent(
                event=MlsTelemetryEventType.JOINED,
                group_id="g1",
                context={},
            )
        )


def test_event_dataclass_is_frozen() -> None:
    ev = MlsTelemetryEvent(
        event=MlsTelemetryEventType.JOINED,
        group_id="g1",
        context={},
    )
    with pytest.raises((AttributeError, TypeError)):
        # frozen=True dataclass — attribute assignment must fail
        ev.group_id = "different"  # type: ignore[misc]


def test_every_event_type_has_string_value_matching_lowercase_name() -> None:
    """Closed-enum contract: enum value must equal lowercase-name verbatim.
    The TS side mirrors these literal strings; drift here breaks the
    backend Pydantic Literal."""
    for member in MlsTelemetryEventType:
        assert member.value == member.name.lower()


def test_protocol_classes_can_be_constructed_as_typing_check() -> None:
    """TelemetrySender is a Protocol; _RecordingSender must satisfy it
    structurally without a runtime check. This test exists to catch
    a regression where someone marks the Protocol runtime_checkable
    and our duck-typed test fails."""
    sender: TelemetrySender = _RecordingSender()
    assert callable(getattr(sender, "send", None))


@pytest.mark.parametrize(
    "event_type",
    list(MlsTelemetryEventType),
)
@pytest.mark.asyncio
async def test_every_enum_value_round_trips_through_emit(
    event_type: MlsTelemetryEventType,
) -> None:
    """Sanity-check that every enum value emits a well-formed envelope.
    Guards against future enum drift between value and emitter serialization."""
    sender = _RecordingSender()
    emitter = MlsTelemetryEmitter(sender)

    await emitter.emit(
        MlsTelemetryEvent(
            event=event_type,
            group_id="g1",
            context={},
        )
    )
    assert sender.sent[0]["data"]["event"] == event_type.value


@pytest.mark.asyncio
async def test_emit_defensive_copies_context_so_post_emit_mutation_is_safe() -> None:
    """The MlsTelemetryEvent dataclass is frozen=True (no rebinding), but
    its context dict is mutable. Emit must defensively copy so that a caller
    mutating the dict after emit cannot corrupt the in-flight envelope."""
    sender = _RecordingSender()
    emitter = MlsTelemetryEmitter(sender)

    ctx: dict[str, str | int] = {"step": "start", "scan_run_id": 1}
    event = MlsTelemetryEvent(
        event=MlsTelemetryEventType.COLD_START_RECOVERING,
        group_id="g1",
        context=ctx,
    )
    await emitter.emit(event)

    # Mutate the caller-held dict — the recorded envelope must remain unchanged.
    ctx["step"] = "mutated"
    ctx["new_key"] = "added"

    assert sender.sent[0]["data"]["context"] == {"step": "start", "scan_run_id": 1}
