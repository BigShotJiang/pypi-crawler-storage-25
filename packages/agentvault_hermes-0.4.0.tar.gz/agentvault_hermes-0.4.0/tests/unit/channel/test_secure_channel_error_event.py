"""Regression tests for the ``event_type == "error"`` demux branch.

action_item #177: before this handler, backend rejection frames (e.g. bad
group_id, bad payload hex, rate limit) were silently dropped by the
``else: logger.debug(...)`` catch-all, masking deterministic protocol
mismatches. The WARNING handler surfaces them in normal operator log views.

These tests use the same canonical helpers as
``tests/unit/channel/test_pull_delivery_queue.py``:
- ``_make_channel`` / ``_FakeRelay`` / ``stub_inbox`` / ``_patch_rest_client``
- ``relay.push_inbound`` to feed frames through the real demux loop
- ``caplog`` for log assertions
- a subsequent ping frame to prove the loop continued after the error branch
"""
from __future__ import annotations

import asyncio
import logging
import types
from dataclasses import dataclass
from pathlib import Path
from typing import Any, AsyncIterator, Optional
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID

import pytest

from agentvault_hermes.channel.outbox import WireEnvelope
from agentvault_hermes.channel.secure_channel import SecureChannel


# ---------------------------------------------------------------------------
# Shared test helpers (mirrors test_pull_delivery_queue.py exactly)
# ---------------------------------------------------------------------------

_FAKE_DEVICE_ID = UUID("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
_FAKE_DEVICE_ID_STR = str(_FAKE_DEVICE_ID)
_FAKE_GROUP_ID_BYTES = UUID("01234567-89ab-cdef-0123-456789abcdef").bytes


def _fake_signing_keypair() -> Any:
    return types.SimpleNamespace(
        public_key=b"\x01" * 32,
        private_key=b"\x02" * 32,
    )


class _FakeRelay:
    def __init__(self) -> None:
        self.rest_base_url = "http://test.invalid"
        self.device_jwt = "test-jwt"
        self.device_id = _FAKE_DEVICE_ID_STR
        self.connect = AsyncMock()
        self.disconnect = AsyncMock()
        self.send_message = AsyncMock()
        self.send_pong = AsyncMock()
        self._inbound: asyncio.Queue[Optional[Any]] = asyncio.Queue()

    async def receive_messages(self) -> AsyncIterator[Any]:
        while True:
            item = await self._inbound.get()
            if item is None:
                return
            yield item

    async def push_inbound(self, env: Any) -> None:
        await self._inbound.put(env)

    async def shutdown_inbound(self) -> None:
        await self._inbound.put(None)


@pytest.fixture
def relay() -> _FakeRelay:
    return _FakeRelay()


@pytest.fixture
def stub_inbox(monkeypatch: pytest.MonkeyPatch) -> dict[str, AsyncMock]:
    handle_mls = AsyncMock(return_value=None)
    handle_dr = AsyncMock(return_value=None)
    handle_welcome = AsyncMock()

    @dataclass(frozen=True)
    class _WelcomeOutcome:
        joined: bool
        drop: bool
        routing_key: Optional[str] = None

    handle_welcome.return_value = _WelcomeOutcome(joined=False, drop=True)

    stub = types.ModuleType("agentvault_hermes.channel.inbox")
    stub.handle_message_mls = handle_mls  # type: ignore[attr-defined]
    stub.handle_message_dr = handle_dr  # type: ignore[attr-defined]
    stub.handle_mls_welcome = handle_welcome  # type: ignore[attr-defined]
    stub.WelcomeOutcome = _WelcomeOutcome  # type: ignore[attr-defined]

    import sys

    monkeypatch.setitem(sys.modules, "agentvault_hermes.channel.inbox", stub)
    return {
        "handle_message_mls": handle_mls,
        "handle_message_dr": handle_dr,
        "handle_mls_welcome": handle_welcome,
        "WelcomeOutcome": _WelcomeOutcome,  # type: ignore[dict-item]
    }


def _patch_rest_client(
    monkeypatch: pytest.MonkeyPatch,
    *,
    pull_return: Optional[list[dict[str, Any]]] = None,
) -> dict[str, AsyncMock]:
    from contextlib import asynccontextmanager

    publish_mock = AsyncMock(
        return_value={"id": "kp-1", "device_id": _FAKE_DEVICE_ID_STR}
    )
    pull_mock = AsyncMock(
        return_value=pull_return if pull_return is not None else []
    )
    ack_mock = AsyncMock(return_value=0)
    nack_mock = AsyncMock(return_value=None)

    @asynccontextmanager
    async def _ctx(*args: Any, **kwargs: Any) -> AsyncIterator[Any]:
        client = MagicMock(name="FakeRestClient")
        client.publish_key_package = publish_mock
        client.pull_mls_delivery = pull_mock
        client.ack_mls_delivery = ack_mock
        client.nack_mls_delivery = nack_mock
        yield client

    fake_factory = MagicMock(name="RestClientFactory", side_effect=_ctx)
    import agentvault_hermes.core.transport.rest_client as rest_client_module

    monkeypatch.setattr(rest_client_module, "RestClient", fake_factory)
    return {"publish": publish_mock, "pull": pull_mock, "ack": ack_mock}


def _patch_mls_group_state(monkeypatch: pytest.MonkeyPatch) -> MagicMock:
    instance = MagicMock(name="MlsGroupStateInstance")
    instance.generate_key_package.return_value = b"\xde\xad\xbe\xef"
    instance.group_id = _FAKE_GROUP_ID_BYTES
    instance.is_initialized = False
    constructor = MagicMock(name="MlsGroupStateCtor", return_value=instance)
    import agentvault_hermes.crypto.mls_group as mls_group_module

    monkeypatch.setattr(mls_group_module, "MlsGroupState", constructor)
    return constructor


def _make_channel(relay: _FakeRelay, tmp_path: Path) -> SecureChannel:
    return SecureChannel(
        relay=relay,  # type: ignore[arg-type]
        mls_states={},
        on_inbound=AsyncMock(),
        data_dir=tmp_path,
        device_keys=_fake_signing_keypair(),
        device_id=_FAKE_DEVICE_ID,
        agent_name="hermes-test",
        account_id="acct-test",
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


async def test_error_event_logs_warning(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Demux ``{event:'error', data:{detail:'...'}}`` → WARNING log line
    containing the detail string from the envelope data.

    action_item #177: before this handler, the frame fell into the
    ``else: logger.debug(...)`` catch-all and was silently dropped.
    """
    _patch_mls_group_state(monkeypatch)
    _patch_rest_client(monkeypatch, pull_return=[])

    ch = _make_channel(relay, tmp_path)
    await ch.start()

    with caplog.at_level(
        logging.WARNING,
        logger="agentvault_hermes.channel.secure_channel",
    ):
        await relay.push_inbound(
            WireEnvelope(
                event="error",
                data={"detail": "group_id not found"},
            )
        )
        await asyncio.sleep(0.05)

    assert any(
        "group_id not found" in record.message
        for record in caplog.records
        if record.levelno == logging.WARNING
    ), (
        "Expected WARNING log containing 'group_id not found'; "
        f"got: {[r.message for r in caplog.records]}"
    )

    await relay.shutdown_inbound()
    await ch.stop()


async def test_error_event_loop_continues(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """After the error frame, the demux loop MUST continue processing
    subsequent frames (the ``continue`` keyword keeps the loop alive).

    We send [error_envelope, ping_envelope] and verify that:
    - The error frame fires the WARNING (proved by the previous test)
    - The ping frame's send_pong is still called (loop did not abort)
    """
    _patch_mls_group_state(monkeypatch)
    _patch_rest_client(monkeypatch, pull_return=[])

    ch = _make_channel(relay, tmp_path)
    await ch.start()

    await relay.push_inbound(
        WireEnvelope(event="error", data={"detail": "rate limited"})
    )
    await relay.push_inbound(WireEnvelope(event="ping", data={}))
    await asyncio.sleep(0.05)

    # send_pong must have been called for the ping frame that followed the error.
    relay.send_pong.assert_awaited()

    await relay.shutdown_inbound()
    await ch.stop()


async def test_error_event_no_detail_key(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Error frame with empty data dict → WARNING log still fires with
    the ``<no detail>`` sentinel rather than KeyError."""
    _patch_mls_group_state(monkeypatch)
    _patch_rest_client(monkeypatch, pull_return=[])

    ch = _make_channel(relay, tmp_path)
    await ch.start()

    with caplog.at_level(
        logging.WARNING,
        logger="agentvault_hermes.channel.secure_channel",
    ):
        await relay.push_inbound(
            WireEnvelope(event="error", data={})
        )
        await asyncio.sleep(0.05)

    assert any(
        "<no detail>" in record.message
        for record in caplog.records
        if record.levelno == logging.WARNING
    ), (
        "Expected WARNING log containing '<no detail>'; "
        f"got: {[r.message for r in caplog.records]}"
    )

    await relay.shutdown_inbound()
    await ch.stop()


@pytest.mark.asyncio
async def test_error_event_data_none(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Error frame with data=None → envelope.data or {} guard is exercised.

    Pins the `or {}` one-character guard against future regressions so a
    developer cannot accidentally remove it and cause an AttributeError
    ('NoneType' object has no attribute 'get').
    """
    _patch_mls_group_state(monkeypatch)
    _patch_rest_client(monkeypatch, pull_return=[])

    ch = _make_channel(relay, tmp_path)
    await ch.start()

    with caplog.at_level(
        logging.WARNING,
        logger="agentvault_hermes.channel.secure_channel",
    ):
        await relay.push_inbound(WireEnvelope(event="error", data=None))
        await asyncio.sleep(0.05)

    assert any(
        "<no detail>" in record.message
        for record in caplog.records
        if record.levelno == logging.WARNING
    ), (
        "Expected WARNING log containing '<no detail>' for data=None case; "
        f"got: {[r.message for r in caplog.records]}"
    )

    await relay.shutdown_inbound()
    await ch.stop()


# Module exports — keep namespace tidy for grep tooling.
__all__: list[str] = []
