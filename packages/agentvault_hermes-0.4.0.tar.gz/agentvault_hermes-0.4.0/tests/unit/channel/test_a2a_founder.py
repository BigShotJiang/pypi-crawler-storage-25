"""Unit tests for channel/a2a_founder.py primitives.

These pin the two extracted primitives (``_batch_fetch_keypackages``,
``_add_members_and_send_welcomes``) so Slice C's dynamic-add path can call
them in isolation without re-implementing the logic. See the design doc
``docs/superpowers/specs/2026-05-24-hermes-a2a-creator-slice-b-design.md``
§4 (B-compat hard rule).

Note on hub_id -> device_id resolution: the WS payload for
``a2a_channel_approved`` carries ``device_id`` per-participant (see backend
``app/api/v1/a2a_channels.py:344``), so the founder reads
``participant.device_id`` directly rather than going through a separate
resolver. Participants without ``device_id`` are skipped and reported as
pending.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from agentvault_hermes.channel.a2a_founder import A2AFounder
from agentvault_hermes.channel.a2a_registry import A2AParticipant


def _p(
    hub_id: str,
    *,
    status: str = "invited",
    device_id: str | None = None,
) -> A2AParticipant:
    return A2AParticipant(
        hub_id=hub_id,
        hub_address=f"{hub_id}.hub",
        status=status,
        device_id=device_id if device_id is not None else f"dev-{hub_id.split('-')[-1]}",
    )


def _founder(
    *,
    rest_client: MagicMock | None = None,
    relay: MagicMock | None = None,
    own_hub_id: str = "hub-self",
    own_device_id: str = "dev-self",
    registry: object | None = None,
    create_mls_state: object | None = None,
    persist_mls_state: object | None = None,
    save_registry: object | None = None,
) -> A2AFounder:
    """Build an A2AFounder with sensible mock defaults for primitive tests."""
    return A2AFounder(
        rest_client=rest_client or MagicMock(),
        relay=relay or MagicMock(send_json=AsyncMock()),
        own_hub_id=own_hub_id,
        own_device_id=own_device_id,
        registry=registry if registry is not None else MagicMock(),
        create_mls_state=create_mls_state or MagicMock(),
        persist_mls_state=persist_mls_state or AsyncMock(),
        save_registry=save_registry or MagicMock(),
    )


# --- _batch_fetch_keypackages ----------------------------------------------


@pytest.mark.asyncio
async def test_batch_fetch_keypackages_skips_self_hub() -> None:
    """The founder must never fetch a KeyPackage for itself."""
    from agentvault_hermes.core.transport.rest_client import KeyPackageBatchResult

    rest = MagicMock()
    rest.batch_fetch_key_packages = AsyncMock(
        return_value=KeyPackageBatchResult(available={}, missing=[])
    )

    founder = _founder(
        rest_client=rest, own_hub_id="hub-self", own_device_id="dev-self"
    )

    participants = [
        _p("hub-self", device_id="dev-self"),
        _p("hub-a", device_id="dev-a"),
        _p("hub-b", device_id="dev-b"),
    ]
    await founder._batch_fetch_keypackages(participants)

    rest.batch_fetch_key_packages.assert_awaited_once()
    call_kwargs = rest.batch_fetch_key_packages.await_args.kwargs
    assert "dev-self" not in call_kwargs["device_ids"], (
        "founder must skip its own hub when batching KP fetches"
    )
    assert sorted(call_kwargs["device_ids"]) == ["dev-a", "dev-b"]


@pytest.mark.asyncio
async def test_batch_fetch_keypackages_returns_available_and_missing_hubs() -> None:
    """Returns (available_kps_by_hub_id, missing_hub_ids) — caller-friendly shape."""
    from agentvault_hermes.core.transport.rest_client import KeyPackageBatchResult

    rest = MagicMock()
    rest.batch_fetch_key_packages = AsyncMock(
        return_value=KeyPackageBatchResult(
            available={"dev-a": b"\xde\xad", "dev-b": b"\xbe\xef"},
            missing=["dev-c"],
        )
    )

    founder = _founder(rest_client=rest)

    participants = [
        _p("hub-a", device_id="dev-a"),
        _p("hub-b", device_id="dev-b"),
        _p("hub-c", device_id="dev-c"),
    ]
    available, missing = await founder._batch_fetch_keypackages(participants)

    assert available == {"hub-a": b"\xde\xad", "hub-b": b"\xbe\xef"}
    assert missing == ["hub-c"]


@pytest.mark.asyncio
async def test_batch_fetch_keypackages_filters_inactive_and_left_participants() -> None:
    """Per OC parity: only invited or active participants are queried."""
    from agentvault_hermes.core.transport.rest_client import KeyPackageBatchResult

    rest = MagicMock()
    rest.batch_fetch_key_packages = AsyncMock(
        return_value=KeyPackageBatchResult(available={}, missing=[])
    )

    founder = _founder(rest_client=rest)

    participants = [
        _p("hub-a", status="invited", device_id="dev-a"),
        _p("hub-b", status="active", device_id="dev-b"),
        _p("hub-c", status="left", device_id="dev-c"),
        _p("hub-d", status="removed", device_id="dev-d"),
    ]
    await founder._batch_fetch_keypackages(participants)

    call_kwargs = rest.batch_fetch_key_packages.await_args.kwargs
    assert sorted(call_kwargs["device_ids"]) == ["dev-a", "dev-b"], (
        "left/removed participants must be excluded from the fetch"
    )


@pytest.mark.asyncio
async def test_batch_fetch_keypackages_missing_device_id_marks_pending() -> None:
    """A participant without device_id (legacy payload) is reported as pending —
    we can't fetch a KP without a device_id, so the founder can't include them."""
    from agentvault_hermes.core.transport.rest_client import KeyPackageBatchResult

    rest = MagicMock()
    rest.batch_fetch_key_packages = AsyncMock(
        return_value=KeyPackageBatchResult(
            available={"dev-a": b"\xaa"}, missing=[]
        )
    )

    founder = _founder(rest_client=rest)

    participants = [
        _p("hub-a", device_id="dev-a"),
        A2AParticipant(
            hub_id="hub-noid", hub_address="x.hub", status="invited", device_id=None
        ),
    ]
    available, missing = await founder._batch_fetch_keypackages(participants)

    assert available == {"hub-a": b"\xaa"}
    assert missing == ["hub-noid"]


# --- _add_members_and_send_welcomes ---------------------------------------


@pytest.mark.asyncio
async def test_add_members_and_send_welcomes_one_commit_one_welcome_blob() -> None:
    """Hermes's ``MlsGroupState.add_members`` takes a list and returns ONE commit
    and ONE welcome blob covering all adds. The primitive sends the welcome
    via N WS events (one per target hub_id) because the backend's
    ``mls_welcome`` event handler is single-target."""
    relay = MagicMock()
    relay.send_json = AsyncMock()

    mls_state = MagicMock()
    add_result = MagicMock()
    add_result.commit = b"commit-bytes"
    add_result.welcome = b"welcome-bytes"
    mls_state.add_members = MagicMock(return_value=add_result)
    mls_state.epoch = 1

    founder = _founder(relay=relay)

    available = {"hub-a": b"\xaa", "hub-b": b"\xbb"}
    hub_to_device_id = {"hub-a": "dev-a", "hub-b": "dev-b"}
    await founder._add_members_and_send_welcomes(
        mls_state=mls_state,
        group_id="grp-1",
        a2a_channel_id="ch-1",
        kp_by_hub_id=available,
        hub_to_device_id=hub_to_device_id,
    )

    # add_members called ONCE with both KPs.
    mls_state.add_members.assert_called_once()
    actual_kps = mls_state.add_members.call_args.args[0]
    assert sorted(actual_kps) == sorted([b"\xaa", b"\xbb"])

    # send_json called THREE times: 1 commit + 2 welcomes.
    assert relay.send_json.await_count == 3
    sent_events = [c.args[0]["event"] for c in relay.send_json.await_args_list]
    assert sent_events.count("mls_commit") == 1
    assert sent_events.count("mls_welcome") == 2

    # Welcomes carry both target_device_id (load-bearing per backend
    # ws.py:1235) and target_hub_id (observability).
    welcome_calls = [
        c for c in relay.send_json.await_args_list
        if c.args[0]["event"] == "mls_welcome"
    ]
    target_device_ids = sorted(c.args[0]["data"]["target_device_id"] for c in welcome_calls)
    assert target_device_ids == ["dev-a", "dev-b"]
    target_hub_ids = sorted(c.args[0]["data"]["target_hub_id"] for c in welcome_calls)
    assert target_hub_ids == ["hub-a", "hub-b"]
    for c in welcome_calls:
        assert c.args[0]["data"]["payload"] == b"welcome-bytes".hex()

    # Commit carries group_id, epoch, payload (verified against
    # backend ws.py:1171-1184).
    commit_call = next(
        c for c in relay.send_json.await_args_list
        if c.args[0]["event"] == "mls_commit"
    )
    assert commit_call.args[0]["data"]["group_id"] == "grp-1"
    assert commit_call.args[0]["data"]["epoch"] == 1
    assert commit_call.args[0]["data"]["payload"] == b"commit-bytes".hex()

    # Every event must carry a2a_channel_id for plugin-side observability.
    for call in relay.send_json.await_args_list:
        payload = call.args[0]
        assert payload["data"]["a2a_channel_id"] == "ch-1", (
            f"event {payload['event']} missing a2a_channel_id"
        )


@pytest.mark.asyncio
async def test_add_members_and_send_welcomes_skips_when_no_kps() -> None:
    """Empty kp_by_hub_id → no MLS state change, no WS events."""
    relay = MagicMock()
    relay.send_json = AsyncMock()
    mls_state = MagicMock()

    founder = _founder(relay=relay)

    await founder._add_members_and_send_welcomes(
        mls_state=mls_state,
        group_id="grp-1",
        a2a_channel_id="ch-1",
        kp_by_hub_id={},
    )

    mls_state.add_members.assert_not_called()
    relay.send_json.assert_not_awaited()


# --- found_a2a_group orchestrator -----------------------------------------


def _seed_creator_entry(
    *,
    channel_id: str = "ch-1",
    participants: list[A2AParticipant] | None = None,
):
    """Build a registry pre-populated with one creator-role entry."""
    from agentvault_hermes.channel.a2a_registry import (
        A2AChannelEntry,
        A2AChannelRegistry,
    )

    if participants is None:
        participants = [_p("hub-a", device_id="dev-a")]
    registry = A2AChannelRegistry()
    entry = A2AChannelEntry(
        a2a_channel_id=channel_id,
        role="creator",
        participants={p.hub_id: p for p in participants},
    )
    registry._channels[entry.a2a_channel_id] = entry
    return registry, entry


@pytest.mark.asyncio
async def test_found_a2a_group_happy_path_calls_init_then_adds_members() -> None:
    """End-to-end primitive composition: backend init, MLS create, batch add,
    Welcomes, persist state, update registry with mls_group_id + creator marker."""
    from agentvault_hermes.core.transport.rest_client import KeyPackageBatchResult

    rest = MagicMock()
    rest.batch_fetch_key_packages = AsyncMock(
        return_value=KeyPackageBatchResult(
            available={"dev-a": b"\xaa", "dev-b": b"\xbb"},
            missing=[],
        )
    )
    rest.init_a2a_mls_group = AsyncMock(return_value="grp-99")

    relay = MagicMock()
    relay.send_json = AsyncMock()

    add_result = MagicMock()
    add_result.commit = b"commit"
    add_result.welcome = b"welcome"

    mls_state = MagicMock()
    mls_state.add_members = MagicMock(return_value=add_result)

    create_mls_state = MagicMock(return_value=mls_state)

    # Order tracker for the persist-before-Welcome invariant.
    events: list[str] = []
    persist_mls_state = AsyncMock(
        side_effect=lambda *_a, **_kw: events.append("persist")
    )
    relay.send_json = AsyncMock(
        side_effect=lambda payload: events.append(payload["event"])
    )

    registry, entry = _seed_creator_entry(
        participants=[
            _p("hub-a", device_id="dev-a"),
            _p("hub-b", device_id="dev-b"),
        ]
    )
    save_registry = MagicMock()

    founder = _founder(
        rest_client=rest,
        relay=relay,
        registry=registry,
        create_mls_state=create_mls_state,
        persist_mls_state=persist_mls_state,
        save_registry=save_registry,
    )

    await founder.found_a2a_group("ch-1", list(entry.participants.values()))

    # Backend init called with hub->device-resolved member ids (including self).
    rest.init_a2a_mls_group.assert_awaited_once()
    init_kwargs = rest.init_a2a_mls_group.await_args.kwargs
    assert init_kwargs["channel_id"] == "ch-1"
    assert sorted(init_kwargs["member_device_ids"]) == sorted(
        ["dev-self", "dev-a", "dev-b"]
    )

    # MLS state created and create_group called with backend-assigned group_id.
    create_mls_state.assert_called_once()
    mls_state.create_group.assert_called_once_with(b"grp-99")

    # Members added in ONE commit, Welcomes dispatched per target.
    mls_state.add_members.assert_called_once()
    actual_kps = mls_state.add_members.call_args.args[0]
    assert sorted(actual_kps) == sorted([b"\xaa", b"\xbb"])
    welcome_events = [
        c for c in relay.send_json.await_args_list
        if c.args[0]["event"] == "mls_welcome"
    ]
    assert len(welcome_events) == 2

    # Persist ordering invariant: persist BEFORE the first Welcome dispatch.
    assert "persist" in events
    first_persist_idx = events.index("persist")
    first_welcome_idx = next(
        (i for i, e in enumerate(events) if e == "mls_welcome"),
        len(events),
    )
    assert first_persist_idx < first_welcome_idx, (
        f"persist must precede first mls_welcome; events order = {events}"
    )

    # Registry updated with mls_group_id + creator marker + cleared pending.
    updated = registry.get("ch-1")
    assert updated is not None
    assert updated.mls_group_id == "grp-99"
    assert updated.creator_device_id == "dev-self"
    assert updated.pending_kp_hub_ids == []
    save_registry.assert_called()


@pytest.mark.asyncio
async def test_found_a2a_group_partial_fetch_marks_pending_kp_hub_ids() -> None:
    """When KP batch returns some missing, found proceeds with what's available
    and records the missing hubs for reconcile-retry later."""
    from agentvault_hermes.core.transport.rest_client import KeyPackageBatchResult

    rest = MagicMock()
    rest.batch_fetch_key_packages = AsyncMock(
        return_value=KeyPackageBatchResult(
            available={"dev-a": b"\xaa"}, missing=["dev-b"]
        )
    )
    rest.init_a2a_mls_group = AsyncMock(return_value="grp-99")

    relay = MagicMock()
    relay.send_json = AsyncMock()

    add_result = MagicMock()
    add_result.commit = b"c"
    add_result.welcome = b"w"
    mls_state = MagicMock()
    mls_state.add_members = MagicMock(return_value=add_result)

    registry, entry = _seed_creator_entry(
        participants=[
            _p("hub-a", device_id="dev-a"),
            _p("hub-b", device_id="dev-b"),
        ]
    )

    founder = _founder(
        rest_client=rest,
        relay=relay,
        registry=registry,
        create_mls_state=MagicMock(return_value=mls_state),
    )

    await founder.found_a2a_group("ch-1", list(entry.participants.values()))

    updated = registry.get("ch-1")
    assert updated is not None
    assert updated.mls_group_id == "grp-99"
    assert updated.pending_kp_hub_ids == ["hub-b"]
    welcome_events = [
        c for c in relay.send_json.await_args_list
        if c.args[0]["event"] == "mls_welcome"
    ]
    assert len(welcome_events) == 1


@pytest.mark.asyncio
async def test_found_a2a_group_all_kps_missing_skips_backend_init() -> None:
    """If we can't fetch KPs for ANY participant, don't bother calling backend
    init — leave channel with mls_group_id=None and pending_kp_hub_ids populated
    so reconcile retries on next connect."""
    from agentvault_hermes.core.transport.rest_client import KeyPackageBatchResult

    rest = MagicMock()
    rest.batch_fetch_key_packages = AsyncMock(
        return_value=KeyPackageBatchResult(available={}, missing=["dev-a"])
    )
    rest.init_a2a_mls_group = AsyncMock(return_value="should-not-be-called")

    registry, entry = _seed_creator_entry(
        participants=[_p("hub-a", device_id="dev-a")]
    )

    founder = _founder(
        rest_client=rest,
        registry=registry,
    )

    await founder.found_a2a_group("ch-1", list(entry.participants.values()))

    rest.init_a2a_mls_group.assert_not_awaited()
    updated = registry.get("ch-1")
    assert updated is not None
    assert updated.mls_group_id is None
    assert updated.pending_kp_hub_ids == ["hub-a"]


@pytest.mark.asyncio
async def test_found_a2a_group_is_idempotent_when_backend_returns_existing_group() -> None:
    """Second call for the same channel finds the same group_id (backend's
    get_mls_group_by_a2a existing-check) and updates registry accordingly."""
    from agentvault_hermes.core.transport.rest_client import KeyPackageBatchResult

    rest = MagicMock()
    rest.batch_fetch_key_packages = AsyncMock(
        return_value=KeyPackageBatchResult(available={"dev-a": b"\xaa"}, missing=[])
    )
    rest.init_a2a_mls_group = AsyncMock(return_value="grp-existing")

    relay = MagicMock()
    relay.send_json = AsyncMock()

    add_result = MagicMock()
    add_result.commit = b"c"
    add_result.welcome = b"w"

    # Two distinct MlsGroupState mocks (one per founding attempt; the second
    # MUST be a fresh instance because create_group raises on re-init).
    mls_state_1 = MagicMock()
    mls_state_1.add_members = MagicMock(return_value=add_result)
    mls_state_2 = MagicMock()
    mls_state_2.add_members = MagicMock(return_value=add_result)
    create_mls_state = MagicMock(side_effect=[mls_state_1, mls_state_2])

    registry, entry = _seed_creator_entry(
        participants=[_p("hub-a", device_id="dev-a")]
    )

    founder = _founder(
        rest_client=rest,
        relay=relay,
        registry=registry,
        create_mls_state=create_mls_state,
    )

    await founder.found_a2a_group("ch-1", list(entry.participants.values()))
    first_group_id = registry.get("ch-1").mls_group_id

    await founder.found_a2a_group("ch-1", list(entry.participants.values()))
    second_group_id = registry.get("ch-1").mls_group_id

    assert first_group_id == "grp-existing"
    assert second_group_id == "grp-existing"
    assert rest.init_a2a_mls_group.await_count == 2


@pytest.mark.asyncio
async def test_found_a2a_group_unknown_channel_is_noop() -> None:
    """If the registry has no entry for the channel id (lifecycle race), the
    founder logs and returns rather than crashing."""
    from agentvault_hermes.channel.a2a_registry import A2AChannelRegistry

    rest = MagicMock()
    rest.batch_fetch_key_packages = AsyncMock()
    rest.init_a2a_mls_group = AsyncMock()

    registry = A2AChannelRegistry()  # empty
    founder = _founder(rest_client=rest, registry=registry)

    await founder.found_a2a_group("ch-missing", [])

    rest.init_a2a_mls_group.assert_not_awaited()
