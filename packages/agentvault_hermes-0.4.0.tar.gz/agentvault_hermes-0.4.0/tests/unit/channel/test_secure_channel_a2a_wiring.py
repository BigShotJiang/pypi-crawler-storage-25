"""Unit test: SecureChannel registers A2A WS events and owns the registry."""
from __future__ import annotations

import uuid
from pathlib import Path
from unittest.mock import AsyncMock

import nacl.signing

from agentvault_hermes.channel.a2a_registry import A2AChannelRegistry
from agentvault_hermes.channel.secure_channel import SecureChannel
from agentvault_hermes.crypto import SigningKeypair

_A2A_EVENTS = {
    "a2a_message_mls",
    "a2a_channel_invited",
    "a2a_channel_approved",
    "a2a_channel_rejected",
    "a2a_channel_revoked",
    "a2a_participant_joined",
    "a2a_participant_left",
    "a2a_participant_removed",
    "a2a_agent_removed",
    "a2a_creator_transferred",
    # Slice B addition — stub handler registered now so Slice C is body-only.
    "a2a_invite_pending",
}


def _keys() -> SigningKeypair:
    sk = nacl.signing.SigningKey.generate()
    return SigningKeypair(public_key=bytes(sk.verify_key), private_key=bytes(sk))


def _channel(tmp_path: Path) -> SecureChannel:
    relay = AsyncMock(name="relay")
    relay.rest_base_url = "http://test"
    relay.device_jwt = "jwt"
    return SecureChannel(
        relay=relay,
        mls_states={},
        on_inbound=AsyncMock(),
        data_dir=tmp_path,
        device_keys=_keys(),
        device_id=uuid.uuid4(),
        agent_name="test-agent",
        account_id="acct-1",
    )


def test_secure_channel_registers_all_a2a_events(tmp_path: Path) -> None:
    ch = _channel(tmp_path)
    registered = ch._event_registry.registered_event_types()
    assert _A2A_EVENTS.issubset(registered)


def test_secure_channel_owns_an_a2a_registry(tmp_path: Path) -> None:
    ch = _channel(tmp_path)
    assert isinstance(ch._a2a_registry, A2AChannelRegistry)


def test_secure_channel_constructs_a2a_founder_and_passes_it_to_lifecycle(
    tmp_path: Path,
) -> None:
    """SecureChannel must instantiate A2AFounder + pass it to A2ALifecycleHandler
    so role=creator on a2a_channel_approved actually invokes the founder."""
    from agentvault_hermes.channel.a2a_founder import A2AFounder

    ch = _channel(tmp_path)
    assert isinstance(ch._a2a_founder, A2AFounder)
    # The lifecycle handler's founder callback must be wired to the founder's
    # found_a2a_group bound method.
    bound = ch._a2a_lifecycle._found_a2a_group
    assert bound is not None
    # Bound method equality is identity on the function + instance.
    assert bound == ch._a2a_founder.found_a2a_group
