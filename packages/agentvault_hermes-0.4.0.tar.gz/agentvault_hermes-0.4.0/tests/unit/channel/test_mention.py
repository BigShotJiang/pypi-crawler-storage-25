"""Unit tests for ``agentvault_hermes.channel.mention``.

Plan ref: ``docs/plans/2026-05-10-hermes-phase3-implementation.md`` §10.7.
The module under test is a verbatim translation of OC
``packages/plugin/src/openclaw-entry.ts:140-206``. These tests reproduce
the OC test cases at ``packages/plugin/src/__tests__/mention-filter.test.ts``
to enforce byte-equal semantics.
"""
from __future__ import annotations

import pytest

from agentvault_hermes.channel.mention import (
    parse_mentions,
    should_process_room_message,
    strip_mentions,
)


# ---------------------------------------------------------------------------
# parse_mentions
# ---------------------------------------------------------------------------


def test_parse_mentions_extracts_single_mention() -> None:
    """Source: OC mention-filter.test.ts:9-11."""
    assert parse_mentions("@Cortina hello") == ["cortina"]


def test_parse_mentions_extracts_multiple_mentions() -> None:
    """Source: OC mention-filter.test.ts:13-18."""
    assert parse_mentions("@Cortina @Markus hi") == ["cortina", "markus"]


def test_parse_mentions_returns_empty_when_no_mentions() -> None:
    """Source: OC mention-filter.test.ts:20-22."""
    assert parse_mentions("hello world") == []


def test_parse_mentions_handles_at_all_and_at_everyone() -> None:
    """Source: OC mention-filter.test.ts:24-27."""
    assert parse_mentions("@all do this") == ["all"]
    assert parse_mentions("@everyone do this") == ["everyone"]


def test_parse_mentions_is_case_insensitive() -> None:
    """Source: OC mention-filter.test.ts:29-31."""
    assert parse_mentions("@CORTINA hello") == ["cortina"]


def test_parse_mentions_handles_mention_at_end_of_text() -> None:
    """Source: OC mention-filter.test.ts:33-35."""
    assert parse_mentions("hey @Cortina") == ["cortina"]


def test_parse_mentions_handles_email_like_pattern() -> None:
    """Source: OC mention-filter.test.ts:37-39. ``user@example.com`` →
    ``["example"]`` (matches at word boundary)."""
    assert parse_mentions("user@example.com") == ["example"]


def test_parse_mentions_simple_at_word() -> None:
    """Common case from plan §10.7: ``"hello @bob"`` → ``["bob"]``."""
    assert parse_mentions("hello @bob") == ["bob"]


def test_parse_mentions_at_all_please_review() -> None:
    """Common case from plan §10.7: ``"@all please review"`` → ``["all"]``."""
    assert parse_mentions("@all please review") == ["all"]


def test_parse_mentions_no_mentions_here() -> None:
    """Common case from plan §10.7: ``"no mentions here"`` → ``[]``."""
    assert parse_mentions("no mentions here") == []


def test_parse_mentions_lowercased_multi() -> None:
    """Plan §10.7: ``parse_mentions("@bob @alice")`` → ``["bob", "alice"]``."""
    assert parse_mentions("@bob @alice") == ["bob", "alice"]


def test_parse_mentions_case_insensitive_multi() -> None:
    """Plan §10.7: ``parse_mentions("@Bob @ALICE")`` → ``["bob", "alice"]``."""
    assert parse_mentions("@Bob @ALICE") == ["bob", "alice"]


# ---------------------------------------------------------------------------
# should_process_room_message
# ---------------------------------------------------------------------------


def test_should_process_owner_no_mentions_returns_true() -> None:
    """Source: OC mention-filter.test.ts:44-51 — broadcast from human."""
    assert should_process_room_message("hello world", "Cortina", "cortina") is True
    assert (
        should_process_room_message("hello world", "Cortina", "cortina", False)
        is True
    )


def test_should_process_agent_name_mentioned_returns_true() -> None:
    """Source: OC mention-filter.test.ts:53-57."""
    assert should_process_room_message("@Cortina hello", "Cortina", "cortina") is True


def test_should_process_different_agent_mentioned_returns_false() -> None:
    """Source: OC mention-filter.test.ts:59-63."""
    assert (
        should_process_room_message("@Markus hello", "Cortina", "cortina") is False
    )


def test_should_process_case_insensitive_match() -> None:
    """Source: OC mention-filter.test.ts:65-72."""
    assert should_process_room_message("@cortina hello", "Cortina", "cortina") is True
    assert should_process_room_message("@CORTINA hello", "Cortina", "cortina") is True


def test_should_process_match_by_account_id() -> None:
    """Source: OC mention-filter.test.ts:74-78."""
    assert (
        should_process_room_message("@myagent hello", "My Agent", "myagent") is True
    )


def test_should_process_match_first_word_of_multi_word_name() -> None:
    """Source: OC mention-filter.test.ts:80-88."""
    assert (
        should_process_room_message(
            "@Markus hello", "Markus (Coder)", "markus--coder-"
        )
        is True
    )


def test_should_process_at_all_returns_true() -> None:
    """Source: OC mention-filter.test.ts:90-94."""
    assert should_process_room_message("@all hello", "Cortina", "cortina") is True


def test_should_process_at_everyone_returns_true() -> None:
    """Source: OC mention-filter.test.ts:96-100."""
    assert (
        should_process_room_message("@everyone hello", "Cortina", "cortina") is True
    )


def test_should_process_multi_mention_includes_this_agent_returns_true() -> None:
    """Source: OC mention-filter.test.ts:102-110."""
    assert (
        should_process_room_message(
            "@Cortina @Markus hello", "Cortina", "cortina"
        )
        is True
    )


def test_should_process_multi_mention_excludes_this_agent_returns_false() -> None:
    """Source: OC mention-filter.test.ts:112-120."""
    assert (
        should_process_room_message("@Cortina @Markus hello", "Atlas", "atlas")
        is False
    )


def test_should_process_agent_sender_no_mentions_returns_false() -> None:
    """Source: OC mention-filter.test.ts:123-127 — loop prevention."""
    assert (
        should_process_room_message("hello world", "Cortina", "cortina", True)
        is False
    )


def test_should_process_agent_sender_this_agent_mentioned_returns_true() -> None:
    """Source: OC mention-filter.test.ts:129-133."""
    assert (
        should_process_room_message(
            "@Cortina what do you think?", "Cortina", "cortina", True
        )
        is True
    )


def test_should_process_agent_sender_other_agent_mentioned_returns_false() -> None:
    """Source: OC mention-filter.test.ts:135-139."""
    assert (
        should_process_room_message(
            "@Markus what do you think?", "Cortina", "cortina", True
        )
        is False
    )


def test_should_process_agent_sender_at_all_returns_true() -> None:
    """Source: OC mention-filter.test.ts:141-145 — agent broadcast OK."""
    assert (
        should_process_room_message(
            "@all status update", "Cortina", "cortina", True
        )
        is True
    )


def test_should_process_agent_sender_at_everyone_returns_true() -> None:
    """Source: OC mention-filter.test.ts:147-151."""
    assert (
        should_process_room_message(
            "@everyone check this", "Cortina", "cortina", True
        )
        is True
    )


# ---------------------------------------------------------------------------
# strip_mentions
# ---------------------------------------------------------------------------


def test_strip_mentions_removes_matching_agent_mention() -> None:
    """Source: OC mention-filter.test.ts:155-159."""
    assert strip_mentions("@Cortina hello", "Cortina", "cortina") == "hello"


def test_strip_mentions_removes_at_all() -> None:
    """Source: OC mention-filter.test.ts:161-163."""
    assert strip_mentions("@all hello", "Cortina", "cortina") == "hello"


def test_strip_mentions_removes_at_everyone() -> None:
    """Source: OC mention-filter.test.ts:165-169."""
    assert strip_mentions("@everyone hello", "Cortina", "cortina") == "hello"


def test_strip_mentions_preserves_other_agent_mentions() -> None:
    """Source: OC mention-filter.test.ts:171-175."""
    assert (
        strip_mentions("@Cortina @Markus hello", "Cortina", "cortina")
        == "@Markus hello"
    )


def test_strip_mentions_handles_mention_at_end_of_text() -> None:
    """Source: OC mention-filter.test.ts:177-181."""
    assert strip_mentions("hello @Cortina", "Cortina", "cortina") == "hello"


def test_strip_mentions_returns_original_when_no_matching_mentions() -> None:
    """Source: OC mention-filter.test.ts:183-187."""
    assert strip_mentions("hello world", "Cortina", "cortina") == "hello world"


def test_strip_mentions_strips_via_first_word_of_multi_word_name() -> None:
    """Source: OC mention-filter.test.ts:189-193."""
    assert (
        strip_mentions("@Markus hello", "Markus (Coder)", "markus--coder-")
        == "hello"
    )


# ---------------------------------------------------------------------------
# Cross-cutting edge cases
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "text,expected",
    [
        ("", []),
        ("@", []),  # no word chars after @
        ("@@@bob", ["bob"]),  # leading @ chars are punctuation
        ("@bob_42", ["bob_42"]),  # underscores + digits are word chars
    ],
)
def test_parse_mentions_edge_cases(text: str, expected: list[str]) -> None:
    """Edge cases not in OC's test suite but covered by the regex spec."""
    assert parse_mentions(text) == expected
