"""Stage-3-scoped unit tests for ``SecureChannel._pull_delivery_queue``.

Plan: ``docs/plans/2026-05-10-hermes-phase3-welcome-support-implementation.md``
§3.3 (``_pull_delivery_queue`` body + ``mls_delivery`` demux branch) + §5.6
(test list).

These tests cover Stage 3's surface only:

- Empty pull → no ack/nack issued.
- Priority sort: welcome=0, commit=1, application=2, then created_at ASC.
- Batched ack at end of pull.
- ``commit`` rows log-and-ack-and-drop (P12 — no ``process_commit`` call).
- Re-entrant guard via ``_delivery_pulling``.
- Own-echo skip (sender_device_id == own).
- Unknown ``message_type`` → log + ack (don't dead-letter).
- ``mls_delivery`` demux branch awaits ``_initial_setup_complete`` then
  pulls (P2).
- ``_stop_event`` post-wake skip (P15) — demux uses ``continue`` not
  ``return`` (P22) so the loop stays alive on reconnect.
- A subsequent non-``mls_delivery`` frame still dispatches after a P15
  skip (P22 regression guard).
- ``_initial_setup_complete`` blocks demux pull until publish completes
  (P2).
- ``_initial_setup_complete`` event-set-on-failure unblocks parked demux
  (P15).

Out-of-scope (Stage 4+):

- Welcome handler real flow — Stage 3 stub returns
  ``WelcomeOutcome(joined=False, drop=True)`` and the caller acks.
- Fire-and-forget republish scheduling on ``joined=True`` — Stage 4
  wires this into ``_pull_delivery_queue``'s welcome branch.
- ``test_welcome_join_triggers_fire_and_forget_republish`` — Stage 4.
- ``test_application_message_does_not_trigger_republish`` — Stage 4.
"""
from __future__ import annotations

import asyncio
import logging
import types
from contextlib import asynccontextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, AsyncIterator, Optional
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID

import pytest

from agentvault_hermes.channel.outbox import WireEnvelope
from agentvault_hermes.channel.secure_channel import SecureChannel


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


_FAKE_DEVICE_ID = UUID("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
_FAKE_DEVICE_ID_STR = str(_FAKE_DEVICE_ID)
_FAKE_GROUP_ID_BYTES = UUID("01234567-89ab-cdef-0123-456789abcdef").bytes
_OTHER_DEVICE_ID = "bbbbbbbb-cccc-dddd-eeee-ffffffffffff"


def _fake_signing_keypair() -> Any:
    return types.SimpleNamespace(
        public_key=b"\x01" * 32,
        private_key=b"\x02" * 32,
    )


class _FakeRelay:
    def __init__(self) -> None:
        self.rest_base_url = "http://test.invalid"
        self.device_jwt = "test-jwt"
        self.device_id = _FAKE_DEVICE_ID_STR
        self.connect = AsyncMock()
        self.disconnect = AsyncMock()
        self.send_message = AsyncMock()
        self.send_pong = AsyncMock()
        self._inbound: asyncio.Queue[Optional[Any]] = asyncio.Queue()

    async def receive_messages(self) -> AsyncIterator[Any]:
        while True:
            item = await self._inbound.get()
            if item is None:
                return
            yield item

    async def push_inbound(self, env: Any) -> None:
        await self._inbound.put(env)

    async def shutdown_inbound(self) -> None:
        await self._inbound.put(None)


@pytest.fixture
def relay() -> _FakeRelay:
    return _FakeRelay()


@pytest.fixture
def stub_inbox(monkeypatch: pytest.MonkeyPatch) -> dict[str, AsyncMock]:
    """Inject a ``channel.inbox`` stub with all 3 handlers + WelcomeOutcome.

    The stub's ``handle_mls_welcome`` defaults to the Stage-3 stub
    behavior (``WelcomeOutcome(joined=False, drop=True)``); tests can
    override per-call via ``side_effect``.
    """
    handle_mls = AsyncMock(return_value=None)
    handle_dr = AsyncMock(return_value=None)
    handle_welcome = AsyncMock()

    @dataclass(frozen=True)
    class _WelcomeOutcome:
        joined: bool
        drop: bool
        routing_key: Optional[str] = None

    handle_welcome.return_value = _WelcomeOutcome(joined=False, drop=True)

    stub = types.ModuleType("agentvault_hermes.channel.inbox")
    stub.handle_message_mls = handle_mls  # type: ignore[attr-defined]
    stub.handle_message_dr = handle_dr  # type: ignore[attr-defined]
    stub.handle_mls_welcome = handle_welcome  # type: ignore[attr-defined]
    stub.WelcomeOutcome = _WelcomeOutcome  # type: ignore[attr-defined]

    import sys

    monkeypatch.setitem(sys.modules, "agentvault_hermes.channel.inbox", stub)
    return {
        "handle_message_mls": handle_mls,
        "handle_message_dr": handle_dr,
        "handle_mls_welcome": handle_welcome,
        "WelcomeOutcome": _WelcomeOutcome,  # type: ignore[dict-item]
    }


def _patch_rest_client(
    monkeypatch: pytest.MonkeyPatch,
    *,
    pull_return: Optional[list[dict[str, Any]]] = None,
    pull_side_effect: Any = None,
    ack_return: int = 0,
) -> dict[str, AsyncMock]:
    """Patch ``RestClient`` for the pull/ack path.

    Returns the dict of {publish, pull, ack, nack} AsyncMocks for tests
    to assert call args / count.
    """
    publish_mock = AsyncMock(
        return_value={"id": "kp-1", "device_id": _FAKE_DEVICE_ID_STR}
    )
    pull_mock = AsyncMock(
        return_value=pull_return if pull_return is not None else [],
        side_effect=pull_side_effect,
    )
    ack_mock = AsyncMock(return_value=ack_return)
    nack_mock = AsyncMock(return_value=None)

    @asynccontextmanager
    async def _ctx(*args: Any, **kwargs: Any) -> AsyncIterator[Any]:
        client = MagicMock(name="FakeRestClient")
        client.publish_key_package = publish_mock
        client.pull_mls_delivery = pull_mock
        client.ack_mls_delivery = ack_mock
        client.nack_mls_delivery = nack_mock
        yield client

    fake_factory = MagicMock(name="RestClientFactory", side_effect=_ctx)

    import agentvault_hermes.core.transport.rest_client as rest_client_module

    monkeypatch.setattr(rest_client_module, "RestClient", fake_factory)
    return {
        "publish": publish_mock,
        "pull": pull_mock,
        "ack": ack_mock,
        "nack": nack_mock,
    }


def _patch_mls_group_state(monkeypatch: pytest.MonkeyPatch) -> MagicMock:
    instance = MagicMock(name="MlsGroupStateInstance")
    instance.generate_key_package.return_value = b"\xde\xad\xbe\xef"
    instance.group_id = _FAKE_GROUP_ID_BYTES
    instance.is_initialized = False
    constructor = MagicMock(name="MlsGroupStateCtor", return_value=instance)
    import agentvault_hermes.crypto.mls_group as mls_group_module

    monkeypatch.setattr(mls_group_module, "MlsGroupState", constructor)
    return constructor


def _make_channel(relay: _FakeRelay, tmp_path: Path) -> SecureChannel:
    return SecureChannel(
        relay=relay,  # type: ignore[arg-type]
        mls_states={},
        on_inbound=AsyncMock(),
        data_dir=tmp_path,
        device_keys=_fake_signing_keypair(),
        device_id=_FAKE_DEVICE_ID,
        agent_name="hermes-test",
        account_id="acct-test",
    )


def _make_row(
    *,
    queue_id: str,
    message_type: str,
    sender_device_id: str = _OTHER_DEVICE_ID,
    created_at: str = "2026-05-10T00:00:00Z",
    payload: str = "deadbeef",
    group_id: str = "11111111-1111-1111-1111-111111111111",
    conversation_id: Optional[str] = "22222222-2222-2222-2222-222222222222",
) -> dict[str, Any]:
    return {
        "queue_id": queue_id,
        "message_id": f"msg-{queue_id}",
        "group_id": group_id,
        "message_type": message_type,
        "sender_device_id": sender_device_id,
        "epoch": 0,
        "payload": payload,
        "room_id": None,
        "conversation_id": conversation_id,
        "a2a_channel_id": None,
        "conversation_group_id": None,
        "created_at": created_at,
    }


# ---------------------------------------------------------------------------
# Pull mechanics
# ---------------------------------------------------------------------------


async def test_empty_queue_noop(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Empty pull → no ack issued, no handler calls."""
    _patch_mls_group_state(monkeypatch)
    rest = _patch_rest_client(monkeypatch, pull_return=[])

    ch = _make_channel(relay, tmp_path)
    await ch._pull_delivery_queue()

    rest["pull"].assert_awaited_once_with(_FAKE_DEVICE_ID_STR)
    rest["ack"].assert_not_awaited()
    rest["nack"].assert_not_awaited()
    stub_inbox["handle_mls_welcome"].assert_not_awaited()
    stub_inbox["handle_message_mls"].assert_not_awaited()


async def test_ordered_processing(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Rows arrive in (application, commit, welcome) order; agent
    processes welcome first (sort=0), then commit (1, via handle_message_mls),
    then application (2). Verified by call-order observation on the stubs."""
    _patch_mls_group_state(monkeypatch)
    call_order: list[str] = []

    async def welcome_side_effect(**_: Any) -> Any:
        call_order.append("welcome")
        return stub_inbox["WelcomeOutcome"](joined=False, drop=True)  # type: ignore[operator]

    call_seq: list[str] = []

    async def mls_side_effect(*args: Any, **kwargs: Any) -> Any:
        # Both commit (sort=1) and application (sort=2) now go through
        # handle_message_mls (action #234). Distinguish by the envelope
        # event field, which is set to "message_mls" for both row types.
        # We rely on call order instead — first call is commit, second is app.
        call_seq.append("mls_call")
        call_order.append("application")
        return None

    stub_inbox["handle_mls_welcome"].side_effect = welcome_side_effect
    stub_inbox["handle_message_mls"].side_effect = mls_side_effect

    rows = [
        _make_row(queue_id="q-app", message_type="application", created_at="2026-05-10T00:00:01Z"),
        _make_row(queue_id="q-commit", message_type="commit", created_at="2026-05-10T00:00:02Z"),
        _make_row(queue_id="q-welcome", message_type="welcome", created_at="2026-05-10T00:00:03Z"),
    ]
    rest = _patch_rest_client(monkeypatch, pull_return=rows)

    ch = _make_channel(relay, tmp_path)
    await ch._pull_delivery_queue()

    # Welcome first (sort=0), then commit + application both via
    # handle_message_mls (sort=1 and sort=2) → 3 entries total.
    assert call_order == ["welcome", "application", "application"], (
        f"unexpected dispatch order: {call_order}"
    )
    # All 3 acked in batch.
    rest["ack"].assert_awaited_once()
    args, _kwargs = rest["ack"].call_args
    assert set(args[0]) == {"q-welcome", "q-commit", "q-app"}
    assert args[1] == _FAKE_DEVICE_ID_STR


async def test_ack_after_each_success(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """All rows succeed → batched ack with all queue_ids in one call."""
    _patch_mls_group_state(monkeypatch)
    rows = [
        _make_row(queue_id="q1", message_type="commit"),
        _make_row(queue_id="q2", message_type="commit"),
        _make_row(queue_id="q3", message_type="commit"),
    ]
    rest = _patch_rest_client(monkeypatch, pull_return=rows)

    ch = _make_channel(relay, tmp_path)
    await ch._pull_delivery_queue()

    rest["ack"].assert_awaited_once()
    args, _ = rest["ack"].call_args
    assert sorted(args[0]) == ["q1", "q2", "q3"]


async def test_commit_row_decrypts_via_handle_message_mls(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """action #234: commit rows are now decrypted via handle_message_mls
    (epoch advanced) and acked — no longer ack-dropped with a warning.
    ``handle_mls_welcome`` is still untouched."""
    _patch_mls_group_state(monkeypatch)
    rows = [_make_row(queue_id="q-commit", message_type="commit")]
    rest = _patch_rest_client(monkeypatch, pull_return=rows)

    ch = _make_channel(relay, tmp_path)
    await ch._pull_delivery_queue()

    rest["ack"].assert_awaited_once()
    args, _ = rest["ack"].call_args
    assert args[0] == ["q-commit"]
    # Commit goes through handle_message_mls now (action #234).
    stub_inbox["handle_message_mls"].assert_awaited_once()
    # Welcome handler untouched.
    stub_inbox["handle_mls_welcome"].assert_not_awaited()


async def test_re_entrant_pull_guarded(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Two concurrent ``_pull_delivery_queue`` invocations → second NOOPs
    (no extra HTTP round-trip). The re-entrant guard protects against
    ping-driven + on-connect + future-heartbeat all firing at once."""
    _patch_mls_group_state(monkeypatch)
    pull_started = asyncio.Event()
    pull_release = asyncio.Event()

    async def slow_pull(device_id: str) -> list[dict[str, Any]]:
        pull_started.set()
        await pull_release.wait()
        return []

    rest = _patch_rest_client(monkeypatch, pull_side_effect=slow_pull)

    ch = _make_channel(relay, tmp_path)

    first = asyncio.create_task(ch._pull_delivery_queue())
    await pull_started.wait()
    # First is mid-flight; fire a second.
    second = asyncio.create_task(ch._pull_delivery_queue())
    await asyncio.sleep(0)  # let it run

    # Second must have already returned (re-entrant guard).
    assert second.done()
    pull_release.set()
    await first

    # Only ONE pull was issued.
    assert rest["pull"].await_count == 1


async def test_own_echo_acked_without_processing(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Row whose ``sender_device_id`` matches our own → ack without
    invoking any inbox handler."""
    _patch_mls_group_state(monkeypatch)
    rows = [
        _make_row(
            queue_id="q-own",
            message_type="application",
            sender_device_id=_FAKE_DEVICE_ID_STR,  # OUR own
        ),
    ]
    rest = _patch_rest_client(monkeypatch, pull_return=rows)

    ch = _make_channel(relay, tmp_path)
    await ch._pull_delivery_queue()

    rest["ack"].assert_awaited_once()
    args, _ = rest["ack"].call_args
    assert args[0] == ["q-own"]
    stub_inbox["handle_message_mls"].assert_not_awaited()


async def test_unknown_message_type_acks(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Unknown ``message_type`` → log warning + ack (don't dead-letter)."""
    _patch_mls_group_state(monkeypatch)
    rows = [_make_row(queue_id="q-weird", message_type="future_format")]
    rest = _patch_rest_client(monkeypatch, pull_return=rows)

    ch = _make_channel(relay, tmp_path)
    with caplog.at_level(
        logging.WARNING,
        logger="agentvault_hermes.channel.secure_channel",
    ):
        await ch._pull_delivery_queue()

    rest["ack"].assert_awaited_once()
    args, _ = rest["ack"].call_args
    assert args[0] == ["q-weird"]
    assert any(
        "unknown message_type" in record.message
        for record in caplog.records
    )


# ---------------------------------------------------------------------------
# mls_delivery demux branch (Seam D)
# ---------------------------------------------------------------------------


async def test_pull_on_mls_delivery_ping(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Demux ``{event:'mls_delivery'}`` ping → ``_pull_delivery_queue`` runs
    AFTER ``_initial_setup_complete`` is set."""
    _patch_mls_group_state(monkeypatch)
    rest = _patch_rest_client(monkeypatch, pull_return=[])

    ch = _make_channel(relay, tmp_path)
    await ch.start()  # publishes KP, sets event, runs first (empty) pull
    pull_count_after_start = rest["pull"].await_count

    # Push the mls_delivery ping.
    await relay.push_inbound(
        WireEnvelope(event="mls_delivery", data={"count": 1})
    )
    # Yield to let the demux dispatch.
    await asyncio.sleep(0.05)

    # The branch fired a second pull.
    assert rest["pull"].await_count == pull_count_after_start + 1

    await relay.shutdown_inbound()
    await ch.stop()


async def test_pull_branch_skips_when_stop_event_set(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """P15: if ``_stop_event`` is set when demux wakes from
    ``_initial_setup_complete.wait()``, the branch MUST skip the pull
    (no Relay round-trip on a torn-down channel)."""
    _patch_mls_group_state(monkeypatch)
    rest = _patch_rest_client(monkeypatch, pull_return=[])

    ch = _make_channel(relay, tmp_path)
    await ch.start()
    pull_count_after_start = rest["pull"].await_count

    # Simulate the start-failure recovery state (P15).
    ch._stop_event.set()
    await relay.push_inbound(
        WireEnvelope(event="mls_delivery", data={"count": 1})
    )
    await asyncio.sleep(0.05)

    # No new pull was issued — branch saw stop_event and continue'd.
    assert rest["pull"].await_count == pull_count_after_start

    # Cleanup: clear stop_event so stop()/shutdown_inbound work cleanly.
    ch._stop_event.clear()
    await relay.shutdown_inbound()
    await ch.stop()


def test_pull_branch_keeps_loop_alive_after_skip() -> None:
    """P22: the Seam D ``mls_delivery`` skip path must NOT permanently
    kill the demux task on stop. Pre-PR-1 the inline ``_demux_loop`` branch
    used ``continue``; PR-1 (Phase 4a) extracted the branch into
    ``SecureChannel._handle_mls_delivery`` and dispatch via
    ``WSEventRegistry``. Under registry dispatch, ``return`` from the
    extracted handler is equivalent to the original ``continue`` — control
    falls back to the demux loop's ``async for`` iteration.

    The runtime distinction (loop stays alive vs. silently dies) is hard
    to observe in isolation because the demux loop has an outer
    ``if self._stop_event.is_set(): break`` that fires on the first
    envelope after stop — P22 is defense-in-depth for the narrow window
    where stop_event flips AFTER the branch's ``wait()`` returns but
    BEFORE the iteration's stop-event re-check.

    We assert the source of ``_handle_mls_delivery`` contains the
    post-wait stop-event guard. Catches an implementer who deletes
    the guard or swaps to ``raise`` / ``sys.exit`` while refactoring
    without realizing the liveness implication. The P22 reference is
    asserted via the method docstring to preserve operator-grep contract.
    """
    import inspect

    source = inspect.getsource(SecureChannel._handle_mls_delivery)
    # Post-wait stop-event guard is present. ``return`` is the registry-
    # dispatch equivalent of the inline ``continue`` (see method
    # docstring).
    assert "if self._stop_event.is_set():" in source, (
        "Seam D mls_delivery stop-event guard missing — handler may "
        "fire _pull_delivery_queue on a stopped channel"
    )
    assert "return" in source, (
        "Seam D mls_delivery skip-on-stop must use `return` (registry-"
        "dispatch equivalent of the pre-PR-1 inline `continue`); found:"
        f"\n{source}"
    )
    # P22 reference preserved in the docstring — operators grepping for
    # the invariant tag still find the relevant code site.
    assert "P22" in source, (
        "P22 reference missing from _handle_mls_delivery — refactoring "
        "drift loosened the load-bearing invariant"
    )


async def test_handle_mls_delivery_skips_pull_when_stop_event_set(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Behavioral regression guard for DA finding #3 (Cluster 3, PR-1,
    Phase 4a). Complement to ``test_pull_branch_keeps_loop_alive_after_skip``
    (source-string guard) — exercises the actual code path and asserts
    ``_pull_delivery_queue`` is NOT awaited when ``_stop_event`` is set
    after ``_initial_setup_complete`` wakes the handler.
    """
    _patch_mls_group_state(monkeypatch)
    _patch_rest_client(monkeypatch, pull_return=[])

    ch = _make_channel(relay, tmp_path)

    # Pre-conditions: initial setup is "complete" so the wait() returns
    # immediately, and stop_event is set so the post-wait guard fires.
    # ORDER MATTERS: setting _initial_setup_complete after _stop_event
    # would also work because both events are evaluated independently,
    # but the realistic runtime sequence is (1) setup completes, (2) stop
    # is requested mid-flight, (3) handler is scheduled — so we mirror
    # that.
    ch._initial_setup_complete.set()
    ch._stop_event.set()

    # Mock the pull method to detect any accidental call. Replacing the
    # bound method on the instance bypasses the descriptor mechanism:
    # ``self._pull_delivery_queue()`` performs attribute lookup on the
    # instance first, finding our AsyncMock before the class method.
    # (The pull path is independently neutralized by ``_patch_rest_client``
    # at the transport layer; this instance-level mock is solely to spy
    # on the handler's call decision.)
    pull_spy = AsyncMock()
    ch._pull_delivery_queue = pull_spy  # type: ignore[method-assign]

    # Wrap the wait() coroutine so we can prove the handler actually got
    # past _initial_setup_complete.wait() before hitting the stop_event
    # guard. Without this assertion, a hypothetical refactor that short-
    # circuits BEFORE the wait would still pass `pull_spy.assert_not_awaited`
    # — a false-positive against the named regression contract
    # (DA #3, Cluster 4 follow-up). With it, we prove necessary AND
    # sufficient: we cleared the wait, then hit the stop check, then
    # returned without pulling.
    original_wait = ch._initial_setup_complete.wait
    wait_spy = AsyncMock(wraps=original_wait)
    ch._initial_setup_complete.wait = wait_spy  # type: ignore[method-assign]

    envelope = WireEnvelope(event="mls_delivery", data={})
    await ch._handle_mls_delivery(envelope)

    wait_spy.assert_awaited_once()  # proves we got past the wait
    pull_spy.assert_not_awaited()  # proves the stop-check then fired


# ---------------------------------------------------------------------------
# initial_setup_complete event (P2 + P15)
# ---------------------------------------------------------------------------


async def test_initial_setup_complete_blocks_demux_pull(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """P2: a ``mls_delivery`` ping that arrives DURING ``start()``'s
    publish step MUST wait for ``_initial_setup_complete`` before
    triggering a pull. We simulate by holding the publish, observing
    that a ping queued during the hold doesn't fire a pull until the
    publish completes.
    """
    _patch_mls_group_state(monkeypatch)

    publish_release = asyncio.Event()

    async def slow_publish(kp_hex: str) -> dict[str, Any]:
        await publish_release.wait()
        return {"id": "kp", "device_id": _FAKE_DEVICE_ID_STR}

    rest = _patch_rest_client(monkeypatch, pull_return=[])
    rest["publish"].side_effect = slow_publish

    ch = _make_channel(relay, tmp_path)
    start_task = asyncio.create_task(ch.start())
    # Yield so start() reaches the publish step + spawns the demux.
    await asyncio.sleep(0.01)
    # Wait, demux isn't spawned until publish completes (Stage 2 order).
    # So we can't push a frame for the demux to see yet. Instead, verify
    # that _initial_setup_complete is NOT set during the publish hold.
    assert not ch._initial_setup_complete.is_set()
    # And no spurious pull happened.
    assert rest["pull"].await_count == 0

    # Release publish — start() proceeds to first-pull (synchronous) and
    # then sets the event in the else branch.
    publish_release.set()
    await start_task

    assert ch._initial_setup_complete.is_set()
    # Exactly one pull (from start()'s synchronous first-pull).
    assert rest["pull"].await_count == 1

    await relay.shutdown_inbound()
    await ch.stop()


async def test_demux_pull_branch_unblocks_on_start_failure(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """P15: if ``start()`` raises during publish/pull, the
    ``_initial_setup_complete`` event MUST still be set (in the
    ``except`` block) so a parked demux from a prior reconnect cycle
    can wake and observe ``_stop_event``.

    We simulate by parking a coroutine on
    ``ch._initial_setup_complete.wait()`` BEFORE calling ``start()``, then
    making ``start()`` raise during publish, and asserting the parked
    coroutine wakes."""
    _patch_mls_group_state(monkeypatch)

    boom = RuntimeError("backend rejected KP")
    rest = _patch_rest_client(monkeypatch)
    rest["publish"].side_effect = boom

    ch = _make_channel(relay, tmp_path)

    parked_unblocked = asyncio.Event()

    async def parked_task() -> None:
        await ch._initial_setup_complete.wait()
        parked_unblocked.set()

    parker = asyncio.create_task(parked_task())
    await asyncio.sleep(0)  # let parker park

    # Now start() raises; P15 invariant says event is set on raise.
    with pytest.raises(RuntimeError, match="backend rejected KP"):
        await ch.start()

    # Parked coro woke up — event was set in start()'s except block.
    await asyncio.wait_for(parked_unblocked.wait(), timeout=1.0)
    parker.cancel()
    try:
        await parker
    except asyncio.CancelledError:
        pass


# ---------------------------------------------------------------------------
# Stage 4 wiring: fire-and-forget republish on welcome join (P3 + P16 + P21)
# ---------------------------------------------------------------------------


async def test_welcome_join_triggers_fire_and_forget_republish(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """P3 + P16: a welcome row whose handler returns joined=True causes
    _pull_delivery_queue to schedule a background task on _republish_task
    and proceed to the next row WITHOUT awaiting the republish completion.
    """
    _patch_mls_group_state(monkeypatch)

    # Override stub welcome to return joined=True.
    welcome_outcome = stub_inbox["WelcomeOutcome"]  # type: ignore[index]
    stub_inbox["handle_mls_welcome"].return_value = welcome_outcome(  # type: ignore[operator]
        joined=True, drop=False, routing_key="conv-1"
    )

    # Slow publish so the fire-and-forget task is observably non-awaited.
    publish_blocked = asyncio.Event()
    publish_release = asyncio.Event()

    async def slow_publish(kp_hex: str) -> dict[str, Any]:
        publish_blocked.set()
        await publish_release.wait()
        return {"id": "kp", "device_id": _FAKE_DEVICE_ID_STR}

    rows = [
        _make_row(queue_id="q-w1", message_type="welcome"),
        _make_row(queue_id="q-app1", message_type="application"),
    ]
    rest = _patch_rest_client(monkeypatch, pull_return=rows)
    rest["publish"].side_effect = slow_publish

    ch = _make_channel(relay, tmp_path)
    # Pre-populate _pending_kp_state so _ensure_pending_key_package can
    # be cleared and re-fired in the republish path.
    ch._pending_kp_state = MagicMock()

    await ch._pull_delivery_queue()

    # Republish task was scheduled.
    assert ch._republish_task is not None
    # The pull-queue did NOT await republish — it's still running
    # (the slow publish hasn't been released).
    assert not ch._republish_task.done(), (
        "republish was awaited synchronously — must be fire-and-forget"
    )
    # Both rows acked despite republish being mid-flight.
    rest["ack"].assert_awaited_once()
    args, _ = rest["ack"].call_args
    assert set(args[0]) == {"q-w1", "q-app1"}

    # Cleanup: cancel the republish task to avoid asyncio.UnreleasedResource warnings.
    ch._republish_task.cancel()
    try:
        await ch._republish_task
    except (asyncio.CancelledError, BaseException):
        pass


async def test_application_message_does_not_trigger_republish(
    relay: _FakeRelay,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Only welcome→joined=True triggers republish. Application rows do not."""
    _patch_mls_group_state(monkeypatch)
    rows = [_make_row(queue_id="q-app", message_type="application")]
    _patch_rest_client(monkeypatch, pull_return=rows)

    ch = _make_channel(relay, tmp_path)
    await ch._pull_delivery_queue()

    assert ch._republish_task is None


# Module exports — keep namespace tidy for grep tooling.
__all__: list[str] = []
