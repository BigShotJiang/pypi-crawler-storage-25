"""Lifecycle handler tests for Slice B creator branch + bundled fast-path fix.

See ``docs/superpowers/specs/2026-05-24-hermes-a2a-creator-slice-b-design.md``
§5.3 (lifecycle wiring + bundled Slice A fast-path fix).
"""
from __future__ import annotations

import logging
from pathlib import Path
from unittest.mock import AsyncMock

import pytest

from agentvault_hermes.channel.a2a_lifecycle import A2ALifecycleHandler
from agentvault_hermes.channel.a2a_registry import A2AChannelRegistry
from agentvault_hermes.channel.outbox import WireEnvelope


def _handler(
    tmp_path: Path,
    *,
    ensure_kp: AsyncMock | None = None,
    drop_mls: AsyncMock | None = None,
    request_welcome: AsyncMock | None = None,
    found_a2a_group: AsyncMock | None = None,
) -> tuple[A2ALifecycleHandler, dict]:
    ensure_kp = ensure_kp or AsyncMock(name="ensure_key_package")
    drop_mls = drop_mls or AsyncMock(name="drop_channel_mls")
    request_welcome = request_welcome or AsyncMock(name="request_welcome")
    found_a2a_group = found_a2a_group or AsyncMock(name="found_a2a_group")
    registry = A2AChannelRegistry()

    handler = A2ALifecycleHandler(
        registry,
        tmp_path,
        own_hub_id="hub-self",
        ensure_key_package=ensure_kp,
        drop_channel_mls=drop_mls,
        request_welcome=request_welcome,
        found_a2a_group=found_a2a_group,
    )
    return handler, {
        "registry": registry,
        "ensure_kp": ensure_kp,
        "drop_mls": drop_mls,
        "request_welcome": request_welcome,
        "found_a2a_group": found_a2a_group,
    }


@pytest.mark.asyncio
async def test_handle_channel_approved_creator_role_invokes_found_a2a_group(
    tmp_path: Path,
) -> None:
    """role==creator must route to the founder, NOT the member KP-publish path."""
    handler, mocks = _handler(tmp_path)
    envelope = WireEnvelope(
        event="a2a_channel_approved",
        data={
            "channel_id": "ch-1",
            "role": "creator",
            "participants": [
                {
                    "hub_id": "hub-peer",
                    "hub_address": "peer.hub",
                    "status": "invited",
                    "device_id": "dev-peer",
                },
            ],
        },
    )

    await handler.handle_channel_approved(envelope)

    mocks["found_a2a_group"].assert_awaited_once()
    call = mocks["found_a2a_group"].await_args
    assert call.args[0] == "ch-1"
    # participants from registry, not just from event — handler must
    # upsert + then read back.
    participants = call.args[1]
    assert any(p.hub_id == "hub-peer" for p in participants)
    # Member path NOT taken.
    mocks["ensure_kp"].assert_not_awaited()
    mocks["request_welcome"].assert_not_awaited()


@pytest.mark.asyncio
async def test_handle_channel_approved_member_role_still_uses_existing_path(
    tmp_path: Path,
) -> None:
    """Regression guard for Slice A: role==member (or missing role, defaulting
    to member) takes the existing publish-KP path AND now also requests a
    Welcome (bundled fast-path fix)."""
    handler, mocks = _handler(tmp_path)
    envelope = WireEnvelope(
        event="a2a_channel_approved",
        data={"channel_id": "ch-1", "role": "member"},
    )

    await handler.handle_channel_approved(envelope)

    mocks["ensure_kp"].assert_awaited_once()
    mocks["request_welcome"].assert_awaited_once_with("ch-1")
    mocks["found_a2a_group"].assert_not_awaited()


@pytest.mark.asyncio
async def test_handle_channel_approved_no_role_defaults_to_member(
    tmp_path: Path,
) -> None:
    """Defensive: payload without role still takes member path (no crash)."""
    handler, mocks = _handler(tmp_path)
    envelope = WireEnvelope(
        event="a2a_channel_approved",
        data={"channel_id": "ch-1"},
    )

    await handler.handle_channel_approved(envelope)

    mocks["ensure_kp"].assert_awaited_once()
    mocks["request_welcome"].assert_awaited_once_with("ch-1")
    mocks["found_a2a_group"].assert_not_awaited()


@pytest.mark.asyncio
async def test_handle_channel_invited_now_requests_welcome_immediately(
    tmp_path: Path,
) -> None:
    """Bundled fast-path fix (spec §5.3.b): on_invited must call
    request_welcome immediately, not wait for next reconnect."""
    handler, mocks = _handler(tmp_path)
    envelope = WireEnvelope(
        event="a2a_channel_invited",
        data={"channel_id": "ch-1", "role": "member"},
    )

    await handler.handle_channel_invited(envelope)

    mocks["ensure_kp"].assert_awaited_once()
    mocks["request_welcome"].assert_awaited_once_with("ch-1")


@pytest.mark.asyncio
async def test_handle_invite_pending_logs_and_noops(
    tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    """Slice C stub: the handler is registered (event isn't dropped at dispatch),
    but the body just logs at INFO and returns. No KP fetch, no found, no MLS."""
    handler, mocks = _handler(tmp_path)
    envelope = WireEnvelope(
        event="a2a_invite_pending",
        data={"channel_id": "ch-1", "device_id": "dev-new"},
    )

    with caplog.at_level(
        logging.INFO, logger="agentvault_hermes.channel.a2a_lifecycle"
    ):
        await handler.handle_invite_pending(envelope)

    assert any(
        "a2a_invite_pending" in r.message and "Slice C" in r.message
        for r in caplog.records
    )
    mocks["found_a2a_group"].assert_not_awaited()
    mocks["ensure_kp"].assert_not_awaited()


@pytest.mark.asyncio
async def test_handle_channel_approved_creator_role_with_no_founder_logs_warning(
    tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    """Defensive: if found_a2a_group wasn't wired (Slice-A-only construction),
    role=creator logs a warning and returns instead of crashing."""
    handler, mocks = _handler(tmp_path, found_a2a_group=None)
    # Re-construct handler WITHOUT the founder callback.
    registry = A2AChannelRegistry()
    bare_handler = A2ALifecycleHandler(
        registry,
        tmp_path,
        own_hub_id="hub-self",
        ensure_key_package=AsyncMock(),
        drop_channel_mls=AsyncMock(),
        request_welcome=AsyncMock(),
        # found_a2a_group intentionally omitted
    )
    envelope = WireEnvelope(
        event="a2a_channel_approved",
        data={"channel_id": "ch-1", "role": "creator"},
    )

    with caplog.at_level(
        logging.WARNING, logger="agentvault_hermes.channel.a2a_lifecycle"
    ):
        await bare_handler.handle_channel_approved(envelope)

    assert any(
        "creator" in r.message and "no founder" in r.message
        for r in caplog.records
    )
