"""Unit test: _resolve_state routes A2A messages by a2a_channel_id."""
from __future__ import annotations

from unittest.mock import MagicMock

from agentvault_hermes.channel.inbox import _resolve_state

_A2A_CHANNEL_ID = "11111111-1111-1111-1111-111111111111"


def test_resolve_state_routes_by_a2a_channel_id() -> None:
    state = MagicMock(name="MlsGroupState")
    state.is_initialized = True
    mls_states = {_A2A_CHANNEL_ID: state}
    data = {"a2a_channel_id": _A2A_CHANNEL_ID, "group_id": "ignored"}
    # _resolve_state returns (state_key, state) per the real signature.
    key, resolved = _resolve_state(data, mls_states, {})
    assert key == _A2A_CHANNEL_ID
    assert resolved is state


def test_resolve_state_a2a_miss_returns_none_or_falls_through() -> None:
    # An a2a_channel_id not present in mls_states must not raise; it falls
    # through to the other keys (here: nothing matches) -> (None, None).
    data = {"a2a_channel_id": "no-such-channel"}
    assert _resolve_state(data, {}, {}) == (None, None)
