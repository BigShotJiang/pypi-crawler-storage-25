"""SecureChannel wires MlsTelemetryEmitter at construction.

Spec: docs/superpowers/specs/2026-05-14-hermes-phase4b-mls-telemetry-and-ui-design.md (PR-4b-A1, Task 2)

This test pair guards the structural contract that every SecureChannel
instance has a `self._telemetry: MlsTelemetryEmitter` bound to a sender that
forwards through `relay.send_json`. Subsequent tasks (Tasks 3-5) will add
emit call sites; if the emitter binding is ever swapped for a no-op sender,
the second test fails before the emit-site tests can run.
"""
from __future__ import annotations

import types
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID

import pytest

from agentvault_hermes.channel.secure_channel import SecureChannel
from agentvault_hermes.channel.telemetry import (
    MlsTelemetryEmitter,
    MlsTelemetryEvent,
    MlsTelemetryEventType,
)
from agentvault_hermes.core.transport.relay import Relay


_FAKE_DEVICE_ID = UUID("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")


def _fake_signing_keypair() -> Any:
    """Stand-in for ``SigningKeypair``; mirrors the helper in test_secure_channel.py."""
    return types.SimpleNamespace(
        public_key=b"\x00" * 32,
        private_key=b"\x00" * 32,
    )


def _build_secure_channel(tmp_path: Path) -> SecureChannel:
    """Construct a SecureChannel with a MagicMock(spec=Relay) whose
    ``send_json`` is an AsyncMock recorder.

    Using ``MagicMock(spec=Relay)`` raises AttributeError if construction
    code ever reaches outside Relay's public surface — that's our drift
    protection. ``send_json`` is overridden to ``AsyncMock`` because
    ``MagicMock(spec=...)`` introspects the spec but does not auto-async-ify
    coroutine methods.
    """
    relay = MagicMock(spec=Relay)
    relay.send_json = AsyncMock()
    return SecureChannel(
        relay=relay,
        mls_states={},
        on_inbound=AsyncMock(),
        data_dir=tmp_path,
        device_keys=_fake_signing_keypair(),
        device_id=_FAKE_DEVICE_ID,
        agent_name="hermes-test",
        account_id="acct-test",
    )


def test_secure_channel_constructs_telemetry_emitter(tmp_path: Path) -> None:
    """Every SecureChannel instance has a _telemetry: MlsTelemetryEmitter."""
    sc = _build_secure_channel(tmp_path)
    assert isinstance(sc._telemetry, MlsTelemetryEmitter)


@pytest.mark.asyncio
async def test_telemetry_sender_uses_relay_send_json(tmp_path: Path) -> None:
    """Verifies the emitter, when invoked, routes through `relay.send_json`
    with the documented envelope shape. The actual call-site coverage from
    inside SecureChannel methods lands in Tasks 3-5.
    """
    sc = _build_secure_channel(tmp_path)
    relay = sc._relay  # MagicMock(spec=Relay); send_json is an AsyncMock

    await sc._telemetry.emit(
        MlsTelemetryEvent(
            event=MlsTelemetryEventType.JOINED,
            group_id="grp1",
            context={},
        )
    )

    sent_envelopes = [call.args[0] for call in relay.send_json.call_args_list]
    assert any(
        env.get("event") == "telemetry.mls" and env["data"]["event"] == "joined"
        for env in sent_envelopes
    )


# ---------- Task 3: cold-start emit sites ----------


def _telemetry_events(relay: Any) -> list[dict[str, Any]]:
    """Pull the .data field out of every telemetry.mls envelope the
    relay's send_json was called with."""
    return [
        call.args[0]["data"]
        for call in relay.send_json.call_args_list
        if call.args and call.args[0].get("event") == "telemetry.mls"
    ]


async def _async_noop(*_args: Any, **_kwargs: Any) -> None:
    return None


@pytest.mark.asyncio
async def test_cold_start_persistence_fail_emits_event(tmp_path: Path) -> None:
    sc = _build_secure_channel(tmp_path)
    # Force the iterator to raise
    sc._iter_known_groups = lambda: (_ for _ in ()).throw(RuntimeError("db down"))  # type: ignore[method-assign]

    await sc._cold_start_scan()

    events = _telemetry_events(sc._relay)
    assert any(
        e["event"] == "cold_start_persistence_fail"
        and e["group_id"] is None
        and "scan_run_id" in e["context"]
        for e in events
    ), f"persistence_fail not found in {events!r}"


@pytest.mark.asyncio
async def test_cold_start_fail_emits_per_group(tmp_path: Path) -> None:
    sc = _build_secure_channel(tmp_path)
    from agentvault_hermes.channel.secure_channel import KnownGroup

    sc._iter_known_groups = lambda: iter([  # type: ignore[method-assign]
        KnownGroup(
            group_id="grp-A",
            group_type="1to1",
            last_epoch=None,
            since_ts=None,
            has_local_state=False,
        )
    ])

    async def _raises(group_id: str) -> None:
        raise RuntimeError("post failed")

    sc._cold_start_recover_single_group = _raises  # type: ignore[method-assign]

    await sc._cold_start_scan()

    events = _telemetry_events(sc._relay)
    assert any(
        e["event"] == "cold_start_fail"
        and e["group_id"] == "grp-A"
        and e["context"]["step"] == "request_welcome"
        and "scan_run_id" in e["context"]
        and e["context"]["error_class"] == "RuntimeError"
        for e in events
    ), f"cold_start_fail not found in {events!r}"


@pytest.mark.asyncio
async def test_cold_start_abort_emits_on_threshold(tmp_path: Path) -> None:
    sc = _build_secure_channel(tmp_path)
    sc._consecutive_failures_threshold = 1  # trip on first fail
    from agentvault_hermes.channel.secure_channel import KnownGroup

    sc._iter_known_groups = lambda: iter([  # type: ignore[method-assign]
        KnownGroup("grp-A", "1to1", None, None, False),
    ])

    async def _raises(group_id: str) -> None:
        raise RuntimeError("post failed")

    sc._cold_start_recover_single_group = _raises  # type: ignore[method-assign]

    await sc._cold_start_scan()

    events = _telemetry_events(sc._relay)
    assert any(
        e["event"] == "cold_start_abort"
        and e["context"]["reason"] == "consecutive_failures"
        and e["context"]["threshold"] == 1
        and "scan_run_id" in e["context"]
        for e in events
    ), f"cold_start_abort not found in {events!r}"


@pytest.mark.asyncio
async def test_cold_start_recovering_emits_at_start_of_recover_single_group(
    tmp_path: Path,
) -> None:
    sc = _build_secure_channel(tmp_path)
    # Short-circuit the wrapper's internal calls so it runs to completion
    # without touching real state.
    sc._try_acquire_welcome_inflight = lambda group_id: True  # type: ignore[method-assign]
    sc._clear_welcome_request_inflight = lambda group_id: None  # type: ignore[method-assign]
    sc._ensure_pending_key_package = _async_noop  # type: ignore[method-assign]

    # `_fire_request_welcome` reads relay.rest_base_url/device_jwt/device_id
    # as kwargs at call-time; set them on the MagicMock(spec=Relay) so the
    # downstream call can construct without AttributeError after the emit.
    sc._relay.rest_base_url = "https://example.invalid"
    sc._relay.device_jwt = "jwt"
    sc._relay.device_id = _FAKE_DEVICE_ID

    # Patch the lazy-imported _fire_request_welcome to no-op
    import agentvault_hermes.channel.inbox as inbox_mod
    original = inbox_mod._fire_request_welcome
    inbox_mod._fire_request_welcome = _async_noop  # type: ignore[assignment]

    try:
        await sc._cold_start_recover_single_group("grp-A")
    finally:
        inbox_mod._fire_request_welcome = original  # type: ignore[assignment]

    events = _telemetry_events(sc._relay)
    assert any(
        e["event"] == "cold_start_recovering" and e["group_id"] == "grp-A"
        for e in events
    ), f"cold_start_recovering not found in {events!r}"


# ---------- Task 4: sync + welcome-handler emit sites ----------


@pytest.mark.asyncio
async def test_sync_response_rejoin_fail_emits_event(tmp_path: Path) -> None:
    sc = _build_secure_channel(tmp_path)
    sc._known_group_ids = frozenset({"grp-A"})

    async def _raises(group_id: str) -> None:
        raise RuntimeError("boom")

    sc._cold_start_recover_single_group = _raises  # type: ignore[method-assign]

    from agentvault_hermes.channel.outbox import WireEnvelope

    env = WireEnvelope(
        event="mls_sync_response",
        data={"group_id": "grp-A", "action": "rejoin"},
    )
    await sc._handle_mls_sync_response(env)

    events = _telemetry_events(sc._relay)
    assert any(
        e["event"] == "sync_response_rejoin_fail"
        and e["group_id"] == "grp-A"
        and e["context"]["error_class"] == "RuntimeError"
        for e in events
    ), f"sync_response_rejoin_fail not found in {events!r}"


@pytest.mark.asyncio
async def test_welcome_requested_invalid_emits_event(tmp_path: Path) -> None:
    sc = _build_secure_channel(tmp_path)
    from agentvault_hermes.channel.outbox import WireEnvelope

    # Missing/empty group_id triggers the invalid path
    env = WireEnvelope(
        event="mls_welcome_requested",
        data={"group_id": ""},
    )
    await sc._handle_mls_welcome_requested(env)

    events = _telemetry_events(sc._relay)
    assert any(
        e["event"] == "welcome_requested_invalid"
        and e["group_id"] is None
        and e["context"]["reason"] == "missing_group_id"
        for e in events
    ), f"welcome_requested_invalid not found in {events!r}"


@pytest.mark.asyncio
async def test_welcome_request_skipped_emits_event(tmp_path: Path) -> None:
    sc = _build_secure_channel(tmp_path)
    # Pre-populate inflight slot so the acquire fails
    sc._mark_welcome_request_inflight("grp-A")

    await sc._cold_start_recover_single_group("grp-A")

    events = _telemetry_events(sc._relay)
    assert any(
        e["event"] == "welcome_request_skipped"
        and e["group_id"] == "grp-A"
        and e["context"]["reason"] == "inflight"
        for e in events
    ), f"welcome_request_skipped not found in {events!r}"


@pytest.mark.asyncio
async def test_sync_abort_iterator_failed_emits_event(tmp_path: Path) -> None:
    sc = _build_secure_channel(tmp_path)
    sc._iter_known_groups = lambda: (_ for _ in ()).throw(RuntimeError("db"))  # type: ignore[method-assign]

    await sc._send_initial_sync()

    events = _telemetry_events(sc._relay)
    assert any(
        e["event"] == "sync_abort"
        and e["group_id"] is None
        and e["context"]["reason"] == "iterator_failed"
        and "sync_run_id" in e["context"]
        for e in events
    ), f"sync_abort iterator_failed not found in {events!r}"


def _telemetry_events_from_mock(mock: Any) -> list[dict[str, Any]]:
    """Variant of ``_telemetry_events`` that reads from an AsyncMock directly,
    used when ``relay.send_json`` has been reassigned to a wrapper function
    that delegates to the original AsyncMock."""
    return [
        call.args[0]["data"]
        for call in mock.call_args_list
        if call.args and call.args[0].get("event") == "telemetry.mls"
    ]


@pytest.mark.asyncio
async def test_sync_emit_fail_emits_event(tmp_path: Path) -> None:
    sc = _build_secure_channel(tmp_path)
    relay = sc._relay
    # Make send_json raise ONLY for mls_sync; allow telemetry envelopes through
    original = relay.send_json  # the AsyncMock; we read its call_args_list later

    async def _selective(env: dict[str, Any]) -> None:
        if env.get("event") == "mls_sync":
            raise RuntimeError("network down")
        await original(env)

    relay.send_json = _selective  # type: ignore[assignment]

    from agentvault_hermes.channel.secure_channel import KnownGroup
    sc._iter_known_groups = lambda: iter([  # type: ignore[method-assign]
        KnownGroup("grp-A", "1to1", None, None, True),  # has_local_state=True drives the send path
    ])

    await sc._send_initial_sync()

    # Read directly from the original AsyncMock — relay.send_json is now `_selective`
    events = _telemetry_events_from_mock(original)
    assert any(
        e["event"] == "sync_emit_fail"
        and e["group_id"] == "grp-A"
        and e["context"]["error_class"] == "RuntimeError"
        and "sync_run_id" in e["context"]
        for e in events
    ), f"sync_emit_fail not found in {events!r}"


@pytest.mark.asyncio
async def test_sync_abort_consecutive_failures_emits_event(tmp_path: Path) -> None:
    sc = _build_secure_channel(tmp_path)
    sc._consecutive_failures_threshold = 1
    relay = sc._relay
    original = relay.send_json

    async def _selective(env: dict[str, Any]) -> None:
        if env.get("event") == "mls_sync":
            raise RuntimeError("network down")
        await original(env)

    relay.send_json = _selective  # type: ignore[assignment]

    from agentvault_hermes.channel.secure_channel import KnownGroup
    sc._iter_known_groups = lambda: iter([  # type: ignore[method-assign]
        KnownGroup("grp-A", "1to1", None, None, True),
    ])

    await sc._send_initial_sync()

    events = _telemetry_events_from_mock(original)
    assert any(
        e["event"] == "sync_abort"
        and e["context"]["reason"] == "consecutive_failures"
        and e["context"]["threshold"] == 1
        for e in events
    ), f"sync_abort consecutive_failures not found in {events!r}"
