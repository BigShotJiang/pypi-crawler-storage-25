"""Unit tests for channel/a2a_lifecycle.py."""
from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

from agentvault_hermes.channel.a2a_lifecycle import A2ALifecycleHandler
from agentvault_hermes.channel.a2a_registry import A2AChannelRegistry
from agentvault_hermes.channel.outbox import WireEnvelope

_CHANNEL_ID = "11111111-1111-1111-1111-111111111111"
_OWN_HUB = "99999999-9999-9999-9999-999999999999"
_PEER_HUB = "33333333-3333-3333-3333-333333333333"


def _handler(tmp_path: Path) -> tuple[A2ALifecycleHandler, A2AChannelRegistry,
                                       AsyncMock, AsyncMock, AsyncMock]:
    registry = A2AChannelRegistry()
    ensure_kp = AsyncMock(name="ensure_key_package")
    drop_mls = AsyncMock(name="drop_channel_mls")
    request_welcome = AsyncMock(name="request_welcome")
    handler = A2ALifecycleHandler(
        registry,
        tmp_path,
        own_hub_id=_OWN_HUB,
        ensure_key_package=ensure_kp,
        drop_channel_mls=drop_mls,
        request_welcome=request_welcome,
    )
    return handler, registry, ensure_kp, drop_mls, request_welcome


def _seed(registry: A2AChannelRegistry) -> None:
    registry.upsert_from_event({
        "channel_id": _CHANNEL_ID,
        "conversation_id": "conv-1",
        "role": "member",
        "participants": [
            {"hub_id": _PEER_HUB, "hub_address": "hub://alice", "status": "active"},
        ],
    })


@pytest.mark.asyncio
async def test_channel_revoked_removes_entry(tmp_path: Path) -> None:
    handler, registry, *_ = _handler(tmp_path)
    _seed(registry)
    await handler.handle_channel_revoked(
        WireEnvelope(event="a2a_channel_revoked", data={"channel_id": _CHANNEL_ID})
    )
    assert registry.get(_CHANNEL_ID) is None


@pytest.mark.asyncio
async def test_channel_rejected_removes_pending_entry(tmp_path: Path) -> None:
    handler, registry, *_ = _handler(tmp_path)
    _seed(registry)
    await handler.handle_channel_rejected(
        WireEnvelope(event="a2a_channel_rejected", data={"channel_id": _CHANNEL_ID})
    )
    assert registry.get(_CHANNEL_ID) is None


@pytest.mark.asyncio
async def test_participant_joined_marks_active(tmp_path: Path) -> None:
    handler, registry, *_ = _handler(tmp_path)
    _seed(registry)
    await handler.handle_participant_joined(WireEnvelope(
        event="a2a_participant_joined",
        data={"channel_id": _CHANNEL_ID, "hub_id": "55555555-5555-5555-5555-555555555555"},
    ))
    entry = registry.get(_CHANNEL_ID)
    assert entry is not None
    assert entry.participants[
        "55555555-5555-5555-5555-555555555555"
    ].status == "active"


@pytest.mark.asyncio
async def test_participant_left_marks_left(tmp_path: Path) -> None:
    handler, registry, *_ = _handler(tmp_path)
    _seed(registry)
    await handler.handle_participant_left(WireEnvelope(
        event="a2a_participant_left",
        data={"channel_id": _CHANNEL_ID, "hub_id": _PEER_HUB},
    ))
    entry = registry.get(_CHANNEL_ID)
    assert entry is not None
    assert entry.participants[_PEER_HUB].status == "left"


@pytest.mark.asyncio
async def test_participant_removed_marks_removed(tmp_path: Path) -> None:
    handler, registry, *_ = _handler(tmp_path)
    _seed(registry)
    await handler.handle_participant_removed(WireEnvelope(
        event="a2a_participant_removed",
        data={"channel_id": _CHANNEL_ID, "hub_id": _PEER_HUB},
    ))
    entry = registry.get(_CHANNEL_ID)
    assert entry is not None
    assert entry.participants[_PEER_HUB].status == "removed"


@pytest.mark.asyncio
async def test_agent_removed_cleans_registry_and_mls(tmp_path: Path) -> None:
    handler, registry, _ensure, drop_mls, _rw = _handler(tmp_path)
    _seed(registry)
    await handler.handle_agent_removed(
        WireEnvelope(event="a2a_agent_removed", data={"channel_id": _CHANNEL_ID})
    )
    assert registry.get(_CHANNEL_ID) is None
    drop_mls.assert_awaited_once_with(_CHANNEL_ID)


@pytest.mark.asyncio
async def test_creator_transferred_to_us_sets_creator_role(tmp_path: Path) -> None:
    handler, registry, *_ = _handler(tmp_path)
    _seed(registry)
    await handler.handle_creator_transferred(WireEnvelope(
        event="a2a_creator_transferred",
        data={"channel_id": _CHANNEL_ID, "new_creator_hub_id": _OWN_HUB},
    ))
    entry = registry.get(_CHANNEL_ID)
    assert entry is not None
    assert entry.role == "creator"


@pytest.mark.asyncio
async def test_creator_transferred_to_other_sets_member_role(tmp_path: Path) -> None:
    handler, registry, *_ = _handler(tmp_path)
    _seed(registry)
    registry.set_role(_CHANNEL_ID, "creator")
    await handler.handle_creator_transferred(WireEnvelope(
        event="a2a_creator_transferred",
        data={"channel_id": _CHANNEL_ID, "new_creator_hub_id": _PEER_HUB},
    ))
    entry = registry.get(_CHANNEL_ID)
    assert entry is not None
    assert entry.role == "member"


@pytest.mark.asyncio
async def test_channel_invited_upserts_and_publishes_kp(tmp_path: Path) -> None:
    # Bundled Slice B fast-path fix (spec §5.3.b): handle_channel_invited now
    # also calls request_welcome immediately so the member joins in the same
    # connection cycle rather than waiting for reconnect.
    handler, registry, ensure_kp, _drop, request_welcome = _handler(tmp_path)
    await handler.handle_channel_invited(WireEnvelope(
        event="a2a_channel_invited",
        data={
            "channel_id": _CHANNEL_ID,
            "conversation_id": "conv-1",
            "participants": [
                {"hub_id": _PEER_HUB, "hub_address": "hub://alice", "status": "active"},
            ],
        },
    ))
    entry = registry.get(_CHANNEL_ID)
    assert entry is not None
    assert entry.role == "member"
    ensure_kp.assert_awaited_once()
    request_welcome.assert_awaited_once_with(_CHANNEL_ID)


@pytest.mark.asyncio
async def test_channel_approved_upserts_and_publishes_kp(tmp_path: Path) -> None:
    # Bundled Slice B fast-path fix (spec §5.3.b): member-role
    # handle_channel_approved now also calls request_welcome immediately.
    handler, registry, ensure_kp, _drop, request_welcome = _handler(tmp_path)
    await handler.handle_channel_approved(WireEnvelope(
        event="a2a_channel_approved",
        data={"channel_id": _CHANNEL_ID, "conversation_id": "conv-1"},
    ))
    assert registry.get(_CHANNEL_ID) is not None
    ensure_kp.assert_awaited_once()
    request_welcome.assert_awaited_once_with(_CHANNEL_ID)


@pytest.mark.asyncio
async def test_invited_then_approved_keeps_single_publish_idempotent(
    tmp_path: Path,
) -> None:
    # ensure_key_package is idempotent in production (_ensure_pending_key_package
    # guards on _pending_kp_state). The handler calls it once per event; the
    # idempotency lives in the callee, so both events calling it is correct.
    handler, registry, ensure_kp, _drop, request_welcome = _handler(tmp_path)
    payload = {"channel_id": _CHANNEL_ID, "conversation_id": "conv-1"}
    await handler.handle_channel_invited(
        WireEnvelope(event="a2a_channel_invited", data=payload)
    )
    await handler.handle_channel_approved(
        WireEnvelope(event="a2a_channel_approved", data=payload)
    )
    assert ensure_kp.await_count == 2  # callee dedupes; handler always calls
    # Bundled Slice B fast-path fix: each event now also asks for a Welcome.
    assert request_welcome.await_count == 2
    assert registry.get(_CHANNEL_ID) is not None
