"""Unit tests for the group_id length-discriminated decode in
handle_mls_welcome (inbox.py:537-560).

action_item #177 — AV-web (and OC) encode the MLS group_id as the
UTF-8 of the UUID-string (36 bytes), not the 16-byte UUID binary form.
inbox.py used to mishandle this by falling back to .hex(), producing
a 72-char "fake hex UUID" that the backend rejects. This file pins
the correct behavior for both supported sizes plus the defensive
fallback.

Spec: docs/superpowers/specs/2026-05-12-hermes-inbox-group-id-utf8-fix-design.md
"""
from __future__ import annotations

import asyncio
from typing import Any, Optional
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID

import pytest

from agentvault_hermes.channel.inbox import handle_mls_welcome
from agentvault_hermes.channel.outbox import WireEnvelope


_OWN_DEVICE_ID = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
_OTHER_DEVICE_ID = "bbbbbbbb-cccc-dddd-eeee-ffffffffffff"
_CONV_ID = "22222222-2222-2222-2222-222222222222"
_GROUP_UUID = UUID("01234567-89ab-cdef-0123-456789abcdef")
_GROUP_ID_STR = str(_GROUP_UUID)


def _welcome_envelope(
    *,
    sender_device_id: str = _OTHER_DEVICE_ID,
    conversation_id: Optional[str] = _CONV_ID,
    payload: str = "deadbeef",
    group_id: str = _GROUP_ID_STR,
) -> WireEnvelope:
    return WireEnvelope(
        event="message_mls",
        data={
            "sender_device_id": sender_device_id,
            "conversation_id": conversation_id,
            "payload": payload,
            "group_id": group_id,
        },
    )


def _make_pending_kp_state(group_id_bytes: bytes) -> MagicMock:
    """Build a MagicMock pending_kp_state whose .group_id returns the
    given bytes after join_from_welcome runs.

    Mirrors the post-join shape used by test_inbox_mls_welcome.py — the
    pending_kp_state is in-memory and is_initialized goes False→True
    inside join_from_welcome.
    """
    state = MagicMock()
    state.is_initialized = False
    state.group_id = group_id_bytes

    def _join_side_effect(_welcome_bytes: bytes) -> None:
        state.is_initialized = True

    state.join_from_welcome = MagicMock(side_effect=_join_side_effect)
    return state


@pytest.mark.asyncio
async def test_group_id_16_bytes_decoded_as_uuid_string():
    """16-byte group_id → str(UUID(bytes=...))."""
    state = _make_pending_kp_state(_GROUP_UUID.bytes)
    conv_to_group_id: dict[str, str] = {}
    mls_states: dict[str, Any] = {}

    persist_state = AsyncMock()
    clear_pending = MagicMock()
    conv_send_locks: dict[str, asyncio.Lock] = {}

    outcome = await handle_mls_welcome(
        _welcome_envelope(),
        mls_states,
        own_device_id=_OWN_DEVICE_ID,
        pending_kp_state=state,
        conv_to_group_id=conv_to_group_id,
        send_locks=conv_send_locks,
        persist_state=persist_state,
        clear_pending_kp_state=clear_pending,
    )

    assert outcome.joined is True
    assert conv_to_group_id[_CONV_ID] == _GROUP_ID_STR
    # CRITICAL: not the hex blob form
    assert conv_to_group_id[_CONV_ID] != _GROUP_UUID.bytes.hex()


@pytest.mark.asyncio
async def test_group_id_36_bytes_utf8_uuid_string_decoded():
    """36-byte group_id (UTF-8 of UUID string, AV-web/OC parity) →
    decoded as ASCII to the same UUID string."""
    utf8_bytes = _GROUP_ID_STR.encode("ascii")
    assert len(utf8_bytes) == 36

    state = _make_pending_kp_state(utf8_bytes)
    conv_to_group_id: dict[str, str] = {}
    mls_states: dict[str, Any] = {}

    outcome = await handle_mls_welcome(
        _welcome_envelope(),
        mls_states,
        own_device_id=_OWN_DEVICE_ID,
        pending_kp_state=state,
        conv_to_group_id=conv_to_group_id,
        send_locks={},
        persist_state=AsyncMock(),
        clear_pending_kp_state=MagicMock(),
    )

    assert outcome.joined is True
    # The fix: 36-byte UTF-8 must decode to the proper UUID string,
    # NOT the .hex() fallback (which would be 72 chars of hex-of-bytes).
    assert conv_to_group_id[_CONV_ID] == _GROUP_ID_STR
    # Regression guard: the old code path produced .hex() of the UTF-8
    # bytes (72 chars). Explicitly rule that out so this test fails
    # loudly if the fix is ever regressed.
    assert conv_to_group_id[_CONV_ID] != _GROUP_ID_STR.encode("ascii").hex()
    assert len(conv_to_group_id[_CONV_ID]) == 36


@pytest.mark.asyncio
async def test_group_id_unexpected_length_falls_back_to_hex(caplog):
    """Defensive fallback: an unexpected-length group_id (not 16, not
    36) falls through to .hex(). Mirrors OC's permissive treatment.
    Should not be reached for normal AV-web interop."""
    weird_bytes = b"\x01\x02\x03\x04\x05\x06\x07\x08"  # 8 bytes
    state = _make_pending_kp_state(weird_bytes)
    conv_to_group_id: dict[str, str] = {}
    mls_states: dict[str, Any] = {}

    outcome = await handle_mls_welcome(
        _welcome_envelope(),
        mls_states,
        own_device_id=_OWN_DEVICE_ID,
        pending_kp_state=state,
        conv_to_group_id=conv_to_group_id,
        send_locks={},
        persist_state=AsyncMock(),
        clear_pending_kp_state=MagicMock(),
    )

    assert outcome.joined is True
    assert conv_to_group_id[_CONV_ID] == weird_bytes.hex()
