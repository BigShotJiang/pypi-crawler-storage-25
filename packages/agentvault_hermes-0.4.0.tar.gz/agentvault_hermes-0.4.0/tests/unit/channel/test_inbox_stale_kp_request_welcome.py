"""Unit tests for the new helpers added in inbox.py for action_item #161
PR 2 (Hermes send side).

_is_stale_kp_error: predicate over Exception messages — returns True when
the message indicates an mls-rs "key package not found" or similar
KP-missing-on-receiver error.

_fire_request_welcome: fire-and-forget async helper that POSTs to
/api/v1/mls/groups/{group_id}/request-welcome. Logs success at INFO,
failure at WARNING (does not raise).

Task 2: catch-block integration with handle_mls_welcome — the
TestHandleMlsWelcomeStaleKpIntegration class below covers the three
conditional paths added to the MLS_WELCOME_PERMANENT_FAILURE except block.

Mock strategy: patch both _fire_request_welcome and asyncio.create_task
so the assertion is decoupled from scheduling internals and gives cleaner
test code. The plan §"When in over your head" note endorsed this approach.

Spec: docs/superpowers/specs/2026-05-12-mls-request-welcome-1to1-design.md
"""
from __future__ import annotations

import logging
from unittest.mock import AsyncMock, MagicMock, patch
import uuid as _uuid_mod

import pytest

from agentvault_hermes.channel.inbox import (
    _fire_request_welcome,
    _is_stale_kp_error,
    handle_mls_welcome,
)
from agentvault_hermes.channel.outbox import WireEnvelope


class TestIsStaleKpError:
    def test_returns_true_for_key_package_not_found(self):
        exc = Exception("A mls-rs error occurred: key package not found, unable to process")
        assert _is_stale_kp_error(exc) is True

    def test_returns_true_for_no_key_package(self):
        exc = Exception("no key package available for this welcome")
        assert _is_stale_kp_error(exc) is True

    def test_returns_true_case_insensitive(self):
        exc = Exception("KEY PACKAGE NOT FOUND")
        assert _is_stale_kp_error(exc) is True

    def test_returns_false_for_unrelated_mls_error(self):
        exc = Exception("ratchet error: framing mismatch")
        assert _is_stale_kp_error(exc) is False

    def test_returns_false_for_empty_message(self):
        exc = Exception("")
        assert _is_stale_kp_error(exc) is False


class TestFireRequestWelcome:
    @pytest.mark.asyncio
    async def test_happy_path_posts_and_logs_info(self, caplog):
        """RestClient.post called with correct URL + body; INFO log line."""
        with caplog.at_level(logging.INFO, logger="agentvault_hermes.channel.inbox"):
            with patch(
                "agentvault_hermes.core.transport.rest_client.RestClient"
            ) as RestClientMock:
                mock_instance = AsyncMock()
                mock_instance.__aenter__.return_value = mock_instance
                mock_instance.__aexit__.return_value = None
                mock_instance.post = AsyncMock(return_value=None)
                RestClientMock.return_value = mock_instance

                await _fire_request_welcome(
                    rest_base_url="https://api.example.test",
                    device_jwt="jwt-xyz",
                    group_id="d861a90b-8767-49a5-b9ce-7e9db3af2138",
                    own_device_id="00acd57f-375e-414f-8a06-e179c4c6cb77",
                )

                # RestClient instantiated with correct base_url + JWT
                RestClientMock.assert_called_once_with(
                    base_url="https://api.example.test",
                    device_jwt="jwt-xyz",
                )
                # .post invoked with the right path + payload
                mock_instance.post.assert_awaited_once_with(
                    "/api/v1/mls/groups/d861a90b-8767-49a5-b9ce-7e9db3af2138/request-welcome",
                    json={"device_id": "00acd57f-375e-414f-8a06-e179c4c6cb77"},
                )
        # INFO log surface
        info_logs = [r for r in caplog.records if r.levelno == logging.INFO]
        assert any("request_welcome fired upstream" in r.getMessage() for r in info_logs)

    @pytest.mark.asyncio
    async def test_post_failure_logs_warning_does_not_raise(self, caplog):
        """If RestClient.post raises, the exception is caught + logged at
        WARNING. The function does NOT re-raise — fire-and-forget contract."""
        with caplog.at_level(logging.WARNING, logger="agentvault_hermes.channel.inbox"):
            with patch(
                "agentvault_hermes.core.transport.rest_client.RestClient"
            ) as RestClientMock:
                mock_instance = AsyncMock()
                mock_instance.__aenter__.return_value = mock_instance
                mock_instance.__aexit__.return_value = None
                mock_instance.post = AsyncMock(side_effect=RuntimeError("connection refused"))
                RestClientMock.return_value = mock_instance

                # Must not raise.
                await _fire_request_welcome(
                    rest_base_url="https://api.example.test",
                    device_jwt="jwt-xyz",
                    group_id="d861a90b-8767-49a5-b9ce-7e9db3af2138",
                    own_device_id="00acd57f-375e-414f-8a06-e179c4c6cb77",
                )

        warn_logs = [r for r in caplog.records if r.levelno == logging.WARNING]
        assert any(
            "request_welcome upstream call failed" in r.getMessage()
            and "connection refused" in r.getMessage()
            for r in warn_logs
        ), "WARNING message must include both prefix and exception detail"


# ---------------------------------------------------------------------------
# Integration helpers (shared fixtures for TestHandleMlsWelcomeStaleKpIntegration)
# ---------------------------------------------------------------------------

_OWN_DEVICE_ID = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
_OTHER_DEVICE_ID = "bbbbbbbb-cccc-dddd-eeee-ffffffffffff"
_CONV_ID = "22222222-2222-2222-2222-222222222222"
_GROUP_ID_STR = "01234567-89ab-cdef-0123-456789abcdef"

# The 16-byte UUID bytes form that pending_kp_state.group_id returns
# post-join (mirrors test_inbox_mls_welcome._GROUP_ID_BYTES).
_GROUP_ID_BYTES = _uuid_mod.UUID(_GROUP_ID_STR).bytes


def _stale_kp_envelope() -> WireEnvelope:
    """Minimal wire envelope that routes to _CONV_ID via conversation_id."""
    return WireEnvelope(
        event="message_mls",
        data={
            "queue_id": "q-stale-kp-1",
            "message_id": "m-stale-1",
            "group_id": _GROUP_ID_STR,
            "message_type": "welcome",
            "sender_device_id": _OTHER_DEVICE_ID,
            "epoch": 0,
            "payload": "deadbeef",
            "room_id": None,
            "conversation_id": _CONV_ID,
            "conversation_group_id": None,
            "a2a_channel_id": None,
            "created_at": "2026-05-12T00:00:00Z",
        },
    )


def _make_kp_state_raising(exc: Exception) -> MagicMock:
    """MlsGroupState stub whose join_from_welcome always raises exc."""
    state = MagicMock(name="PendingKpState")
    state.is_initialized = False
    state.group_id = _GROUP_ID_BYTES

    def _join(welcome_bytes: bytes) -> None:
        raise exc

    state.join_from_welcome.side_effect = _join
    return state


# ---------------------------------------------------------------------------
# Task 2: catch-block integration tests
# ---------------------------------------------------------------------------


class TestHandleMlsWelcomeStaleKpIntegration:
    """The MLS_WELCOME_PERMANENT_FAILURE catch block fires
    _fire_request_welcome only when the failure indicates stale KP."""

    @pytest.mark.asyncio
    async def test_stale_kp_failure_schedules_request_welcome(self):
        """join_from_welcome raises "key package not found" AND rest params
        are provided → asyncio.create_task is called (fire-and-forget) AND
        outcome is (joined=False, drop=True).

        Mock strategy: patch _fire_request_welcome directly so the assertion
        is decoupled from asyncio scheduling internals. asyncio.create_task
        wraps the coroutine; we verify the coroutine factory was called by
        asserting _fire_request_welcome was called with the expected kwargs.
        """
        stale_exc = Exception(
            "A mls-rs error occurred: key package not found, unable to process"
        )
        pending = _make_kp_state_raising(stale_exc)

        with patch(
            "agentvault_hermes.channel.inbox._fire_request_welcome",
            new_callable=AsyncMock,
        ) as mock_fire:
            # asyncio.create_task(coro) needs the coro to be awaitable;
            # we also patch create_task so no actual background task runs.
            with patch("agentvault_hermes.channel.inbox.asyncio.create_task") as mock_create_task:
                outcome = await handle_mls_welcome(
                    envelope=_stale_kp_envelope(),
                    mls_states={},
                    pending_kp_state=pending,
                    own_device_id=_OWN_DEVICE_ID,
                    conv_to_group_id={},
                    send_locks={},
                    persist_state=AsyncMock(),
                    clear_pending_kp_state=MagicMock(),
                    rest_base_url="https://api.agentvault.chat",
                    device_jwt="jwt-test",
                )

        assert outcome.joined is False
        assert outcome.drop is True
        # _fire_request_welcome must have been called (to produce the
        # coroutine passed to create_task).
        mock_fire.assert_called_once_with(
            rest_base_url="https://api.agentvault.chat",
            device_jwt="jwt-test",
            group_id=_GROUP_ID_STR,
            own_device_id=_OWN_DEVICE_ID,
        )
        mock_create_task.assert_called_once()

    @pytest.mark.asyncio
    async def test_non_kp_failure_does_not_schedule_request_welcome(self):
        """join_from_welcome raises an unrelated error → asyncio.create_task
        NOT called → outcome is (joined=False, drop=True)."""
        unrelated_exc = RuntimeError("ratchet error: framing mismatch")
        pending = _make_kp_state_raising(unrelated_exc)

        with patch(
            "agentvault_hermes.channel.inbox._fire_request_welcome",
            new_callable=AsyncMock,
        ) as mock_fire:
            with patch("agentvault_hermes.channel.inbox.asyncio.create_task") as mock_create_task:
                outcome = await handle_mls_welcome(
                    envelope=_stale_kp_envelope(),
                    mls_states={},
                    pending_kp_state=pending,
                    own_device_id=_OWN_DEVICE_ID,
                    conv_to_group_id={},
                    send_locks={},
                    persist_state=AsyncMock(),
                    clear_pending_kp_state=MagicMock(),
                    rest_base_url="https://api.agentvault.chat",
                    device_jwt="jwt-test",
                )

        assert outcome.joined is False
        assert outcome.drop is True
        mock_fire.assert_not_called()
        mock_create_task.assert_not_called()

    @pytest.mark.asyncio
    async def test_stale_kp_failure_without_rest_params_does_not_schedule(self):
        """join_from_welcome raises stale-KP error BUT rest_base_url /
        device_jwt are None (graceful degradation: tests that don't pass
        them, or old callers) → asyncio.create_task NOT called →
        outcome is (joined=False, drop=True)."""
        stale_exc = Exception(
            "A mls-rs error occurred: key package not found, unable to process"
        )
        pending = _make_kp_state_raising(stale_exc)

        with patch(
            "agentvault_hermes.channel.inbox._fire_request_welcome",
            new_callable=AsyncMock,
        ) as mock_fire:
            with patch("agentvault_hermes.channel.inbox.asyncio.create_task") as mock_create_task:
                outcome = await handle_mls_welcome(
                    envelope=_stale_kp_envelope(),
                    mls_states={},
                    pending_kp_state=pending,
                    own_device_id=_OWN_DEVICE_ID,
                    conv_to_group_id={},
                    send_locks={},
                    persist_state=AsyncMock(),
                    clear_pending_kp_state=MagicMock(),
                    # Deliberately omit rest_base_url and device_jwt
                    # (they default to None).
                )

        assert outcome.joined is False
        assert outcome.drop is True
        mock_fire.assert_not_called()
        mock_create_task.assert_not_called()

    @pytest.mark.asyncio
    async def test_stale_kp_failure_with_empty_group_id_does_not_schedule(self):
        """Defensive: if the envelope's group_id is empty string (fallback
        from data.get('group_id') or ''), skip the request_welcome — there
        is no group to ask about. Still acks the row."""
        stale_exc = Exception(
            "A mls-rs error occurred: key package not found, unable to process"
        )
        pending = _make_kp_state_raising(stale_exc)

        # Construct envelope with group_id omitted so the production fallback
        # to "" at line ~500 (group_id = data.get("group_id") or "") kicks in.
        envelope = _stale_kp_envelope()
        del envelope.data["group_id"]  # Remove group_id; fallback produces ""

        with patch(
            "agentvault_hermes.channel.inbox._fire_request_welcome",
            new_callable=AsyncMock,
        ) as mock_fire:
            with patch("agentvault_hermes.channel.inbox.asyncio.create_task") as mock_create_task:
                outcome = await handle_mls_welcome(
                    envelope=envelope,
                    mls_states={},
                    pending_kp_state=pending,
                    own_device_id=_OWN_DEVICE_ID,
                    conv_to_group_id={},
                    send_locks={},
                    persist_state=AsyncMock(),
                    clear_pending_kp_state=MagicMock(),
                    rest_base_url="https://api.agentvault.chat",
                    device_jwt="jwt-test",
                )

        assert outcome.joined is False
        assert outcome.drop is True
        # _fire_request_welcome must NOT be called when group_id is empty string.
        mock_fire.assert_not_called()
        mock_create_task.assert_not_called()

    @pytest.mark.asyncio
    async def test_stale_kp_uses_welcome_request_callable_when_provided(self):
        """When ``welcome_request_callable`` is provided, stale-KP recovery
        invokes it instead of the module-level ``_fire_request_welcome``.
        PR-3, Phase 4a inflight-dedup contract integration: the
        orchestrator passes ``_cold_start_recover_single_group`` and the
        inbox routes the stale-KP recovery through the same dedup path
        used by the cold-start scan."""
        import asyncio as _asyncio

        stale_exc = Exception(
            "A mls-rs error occurred: key package not found, unable to process"
        )
        pending = _make_kp_state_raising(stale_exc)

        callable_spy = AsyncMock()

        with patch(
            "agentvault_hermes.channel.inbox._fire_request_welcome",
            new_callable=AsyncMock,
        ) as mock_fire:
            outcome = await handle_mls_welcome(
                envelope=_stale_kp_envelope(),
                mls_states={},
                pending_kp_state=pending,
                own_device_id=_OWN_DEVICE_ID,
                conv_to_group_id={},
                send_locks={},
                persist_state=AsyncMock(),
                clear_pending_kp_state=MagicMock(),
                # rest_base_url + device_jwt also populated to prove the
                # callable takes precedence over the fallback.
                rest_base_url="https://api.agentvault.chat",
                device_jwt="jwt-test",
                welcome_request_callable=callable_spy,
            )
            # Allow the asyncio.create_task to schedule + run.
            await _asyncio.sleep(0)

        assert outcome.joined is False
        assert outcome.drop is True
        callable_spy.assert_awaited_once_with(_GROUP_ID_STR)
        mock_fire.assert_not_called()
