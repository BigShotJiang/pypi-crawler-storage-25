"""Unit tests for ``agentvault_hermes.channel.secure_channel``.

The orchestrator under test mirrors OC ``packages/plugin/src/channel.ts``;
plan ref: ``docs/plans/2026-05-10-hermes-phase3-implementation.md`` §8.3 +
§8.9 + §8.11b + §8.12b.

Strategy:

- ``Relay`` is mocked at ``connect`` / ``disconnect`` / ``send_message`` /
  ``receive_messages`` / ``device_id`` granularity. The real Relay's
  ``send_heartbeat`` does not exist; we assert the orchestrator never tries
  to invoke any heartbeat-shaped attribute.
- ``MlsGroupState`` is mocked with a recording ``encrypt`` so we can verify
  the ratchet is advanced exactly once per send and that concurrent sends
  observe strictly monotonic epochs.
- ``channel.inbox`` is injected into ``sys.modules`` BEFORE ``_demux_loop``
  imports it lazily, so we can drive ``handle_message_mls`` /
  ``handle_message_dr`` from tests.
- Time is faked via a per-test monkeypatch on
  ``secure_channel.time.monotonic`` so silence-timeout math is deterministic.
"""
from __future__ import annotations

import asyncio
import logging
import sys
import types
from collections.abc import Iterator
from pathlib import Path
from typing import Any, Optional
from unittest.mock import AsyncMock, MagicMock, create_autospec
from uuid import UUID

import pytest

from agentvault_hermes.channel import secure_channel as sc_module
from agentvault_hermes.channel.outbox import WireEnvelope
from agentvault_hermes.channel.secure_channel import (
    InboundMessage,
    SecureChannel,
)


# ---------------------------------------------------------------------------
# Test fixtures
# ---------------------------------------------------------------------------


_FAKE_GROUP_ID_BYTES = UUID("01234567-89ab-cdef-0123-456789abcdef").bytes
_FAKE_GROUP_ID_STR = "01234567-89ab-cdef-0123-456789abcdef"
_FAKE_CONV_ID = "11111111-2222-3333-4444-555555555555"


class FakeMlsState:
    """A recording stand-in for ``MlsGroupState``.

    - ``epoch`` is a property that auto-increments on each ``encrypt`` call,
      mirroring the real ratchet's behavior.
    - ``encrypt`` records the ``epoch`` observed at call time so concurrent
      send tests can assert strict monotonicity.
    """

    def __init__(
        self,
        *,
        group_id_bytes: bytes = _FAKE_GROUP_ID_BYTES,
        initialized: bool = True,
    ) -> None:
        self.group_id = group_id_bytes
        self._initialized = initialized
        self._epoch = 0
        self.observed_epochs: list[int] = []
        self.encrypt_call_count = 0
        self.export_state_call_count = 0

    @property
    def is_initialized(self) -> bool:
        return self._initialized

    @property
    def epoch(self) -> int:
        return self._epoch

    def encrypt(self, plaintext: bytes) -> bytes:
        # Record observed epoch then advance — matches the real semantics
        # where encrypt() advances the ratchet so the next epoch read is +1.
        self.observed_epochs.append(self._epoch)
        self.encrypt_call_count += 1
        self._epoch += 1
        return b"ciphertext-" + plaintext

    def export_state(self) -> bytes:
        self.export_state_call_count += 1
        return b"exported-state"


class _SlowEncryptMlsState(FakeMlsState):
    """Variant whose ``encrypt`` blocks briefly so concurrency is observable.

    Without the brief sleep, all 5 coroutines could complete inline within
    one event loop tick on a fast machine and the lock would never serialize
    them. The sleep forces the scheduler to run other coroutines, which is
    what surfaces the lock's serialization contract.
    """

    def encrypt(self, plaintext: bytes) -> bytes:
        # Use a synchronous busy yield via the event loop is hard in a sync
        # method; we rely on the test wrapping each send() in a separate
        # task and the surrounding ``asyncio.to_thread`` of _persist_state
        # giving the scheduler a chance to interleave.
        return super().encrypt(plaintext)


class FakeRelay:
    """Async-mocked Relay with a controllable inbound queue."""

    def __init__(self, *, device_id: str = "device-1") -> None:
        self.device_id = device_id
        # Stage-2 plumbing: SecureChannel._ensure_pending_key_package reads
        # rest_base_url + device_jwt off Relay to construct an ad-hoc
        # RestClient. The KP-publish path isn't exercised by these tests
        # — _make_channel patches the method to a no-op — but the
        # attributes must exist for a hypothetical future test that
        # doesn't patch it.
        self.rest_base_url = "http://test.invalid"
        self.device_jwt = "fake-jwt"
        self.connect = AsyncMock()
        self.disconnect = AsyncMock()
        self.send_message = AsyncMock()
        self.send_pong = AsyncMock()
        # PR-2: capture raw JSON frames emitted via Relay.send_json (today
        # only ``event:"mls_sync"``). Tests inspect ``sent_frames`` to
        # assert per-group emission shape.
        self.sent_frames: list[dict[str, Any]] = []

        async def _send_json(payload: dict[str, Any]) -> None:
            self.sent_frames.append(payload)

        self.send_json = AsyncMock(side_effect=_send_json)
        # Inbound frames the demux loop will consume.
        self._inbound: asyncio.Queue[Optional[WireEnvelope]] = asyncio.Queue()
        self._closed = False

    async def receive_messages(self):  # type: ignore[no-untyped-def]
        while True:
            env = await self._inbound.get()
            if env is None:
                return  # sentinel — shut down the generator
            yield env

    async def push_inbound(self, env: WireEnvelope) -> None:
        await self._inbound.put(env)

    async def shutdown_inbound(self) -> None:
        await self._inbound.put(None)


@pytest.fixture
def relay() -> FakeRelay:
    return FakeRelay()


@pytest.fixture
def mls_state() -> FakeMlsState:
    return FakeMlsState()


@pytest.fixture
def mls_states(mls_state: FakeMlsState) -> dict[str, Any]:
    return {_FAKE_CONV_ID: mls_state}


@pytest.fixture
def on_inbound() -> AsyncMock:
    return AsyncMock()


@pytest.fixture
def stub_inbox(monkeypatch: pytest.MonkeyPatch) -> dict[str, AsyncMock]:
    """Inject a stand-in ``agentvault_hermes.channel.inbox`` module.

    The real module ships in WS-30; ``SecureChannel._demux_loop`` lazy-imports
    it. We register a stub in ``sys.modules`` so the import resolves to mocks
    we control from tests.

    Returns the dict ``{"handle_message_mls": ..., "handle_message_dr": ...}``
    so tests can configure per-call return values + assert call counts.
    """
    from dataclasses import dataclass

    handle_mls = AsyncMock(return_value=None)
    handle_dr = AsyncMock(return_value=None)
    handle_welcome = AsyncMock()
    stub = types.ModuleType("agentvault_hermes.channel.inbox")
    stub.handle_message_mls = handle_mls  # type: ignore[attr-defined]
    stub.handle_message_dr = handle_dr  # type: ignore[attr-defined]
    stub.handle_mls_welcome = handle_welcome  # type: ignore[attr-defined]

    # Stage 3 added WelcomeOutcome — the lazy import in _pull_delivery_queue
    # references handle_mls_welcome (and the route returns WelcomeOutcome),
    # so the stub must provide a compatible class.
    @dataclass(frozen=True)
    class _WelcomeOutcome:
        joined: bool
        drop: bool
        routing_key: "str | None" = None

    stub.WelcomeOutcome = _WelcomeOutcome  # type: ignore[attr-defined]
    handle_welcome.return_value = _WelcomeOutcome(joined=False, drop=True)

    monkeypatch.setitem(sys.modules, "agentvault_hermes.channel.inbox", stub)
    return {
        "handle_message_mls": handle_mls,
        "handle_message_dr": handle_dr,
        "handle_mls_welcome": handle_welcome,
    }


@pytest.fixture
def fake_clock(monkeypatch: pytest.MonkeyPatch) -> dict[str, Any]:
    """Fake monotonic clock for silence-timeout assertions."""
    state = {"now": 1_000_000.0}

    def _monotonic() -> float:
        return state["now"]

    monkeypatch.setattr(sc_module.time, "monotonic", _monotonic)
    return state


_FAKE_DEVICE_ID = UUID("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")


def _fake_signing_keypair() -> Any:
    """Stand-in for ``SigningKeypair`` — Stage 2 plumbing only inspects the
    object reference; KP generation is exercised in
    ``tests/unit/channel/test_secure_channel_kp.py`` against a properly
    mocked ``MlsGroupState``."""
    return types.SimpleNamespace(
        public_key=b"\x00" * 32,
        private_key=b"\x00" * 32,
    )


def _make_channel(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> SecureChannel:
    ch = SecureChannel(
        relay=relay,  # type: ignore[arg-type]
        mls_states=mls_states,
        on_inbound=on_inbound,
        data_dir=tmp_path,
        device_keys=_fake_signing_keypair(),
        device_id=_FAKE_DEVICE_ID,
        agent_name="hermes-test",
        account_id="acct-test",
    )
    # Stage-2/3/10 plumbing: existing tests in this file pre-date the
    # KP-publish-on-start, synchronous-pull-on-start, and connect-time
    # room-poll contracts and don't want to spin up respx for every
    # ``ch.start()`` call. The KP path is exercised in
    # ``test_secure_channel_kp.py``; the pull path in
    # ``test_pull_delivery_queue.py``; the poll path in the Task 10
    # tests below. Patch all three to no-ops here so the lifecycle /
    # send / demux / silence-timeout tests below stay focused on their
    # respective surfaces.
    async def _no_op_publish() -> None:
        return None

    async def _no_op_pull() -> None:
        return None

    async def _no_op_poll_rooms() -> None:
        return None

    ch._ensure_pending_key_package = _no_op_publish  # type: ignore[method-assign]
    ch._pull_delivery_queue = _no_op_pull  # type: ignore[method-assign]
    ch._poll_rooms = _no_op_poll_rooms  # type: ignore[method-assign]
    return ch


# ---------------------------------------------------------------------------
# start() / stop() lifecycle
# ---------------------------------------------------------------------------


async def test_start_connects_relay_and_spawns_four_background_tasks(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
) -> None:
    """``start()`` opens the relay BEFORE spawning the demux loop, then
    spawns 4 tasks: demux, silence-timeout, poll-fallback, trust-token-refresh.
    """
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    await ch.start()
    try:
        # Relay opened.
        relay.connect.assert_awaited_once()
        # 4 background tasks spawned. Some may have already completed (the
        # poll/trust-token stubs return immediately) and been discarded.
        # We therefore assert AT LEAST the demux + silence-timeout are still
        # alive, and the spawned-and-completed-or-pending count is 4.
        assert len(ch._background_tasks) >= 1
    finally:
        await relay.shutdown_inbound()
        await ch.stop()


async def test_start_orders_connect_before_demux_spawn(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
) -> None:
    """If ``connect()`` raises, no demux task should be spawned (the relay
    is not open, so calling ``receive_messages`` on it would explode).
    """
    relay.connect = AsyncMock(side_effect=RuntimeError("connect failed"))
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    with pytest.raises(RuntimeError, match="connect failed"):
        await ch.start()
    # No background tasks should have been spawned.
    assert len(ch._background_tasks) == 0


async def test_start_runs_cold_start_scan_before_send_initial_sync(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
) -> None:
    """Strict 3-phase startup ordering: ``_cold_start_scan`` (Phase A)
    runs BEFORE ``_send_initial_sync`` (Phase B) which runs BEFORE
    ``_demux_loop`` spawn (Phase C). Both connect paths (``start()`` and
    ``_schedule_reconnect()``) enforce this order.

    Verified by recording the order of calls.
    """
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    call_order: list[str] = []

    async def scan_recorder() -> None:
        call_order.append("cold_start_scan")

    async def sync_recorder() -> None:
        call_order.append("send_initial_sync")

    ch._cold_start_scan = scan_recorder  # type: ignore[method-assign]
    ch._send_initial_sync = sync_recorder  # type: ignore[method-assign]

    try:
        await ch.start()
        # Demux loop spawn happens asynchronously; the orderings of
        # interest are scan vs sync.
        scan_idx = call_order.index("cold_start_scan")
        sync_idx = call_order.index("send_initial_sync")
        assert scan_idx < sync_idx, (
            f"_cold_start_scan must precede _send_initial_sync; got order "
            f"{call_order}"
        )
    finally:
        await relay.shutdown_inbound()
        await ch.stop()


async def test_stop_cancels_tasks_closes_relay_and_releases_locks(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
) -> None:
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    await ch.start()

    # Pretend we hold a lock so stop() must release it.
    ch._held_locks.add(_FAKE_CONV_ID)

    await ch.stop()

    # Relay closed.
    relay.disconnect.assert_awaited()
    # Held locks released.
    assert _FAKE_CONV_ID not in ch._held_locks
    # Stop event is set so the silence-timeout task could exit.
    assert ch._stop_event.is_set()


async def test_relay_has_no_send_heartbeat_attribute(
    relay: FakeRelay,
) -> None:
    """Per plan §3.4.1: the AV protocol has the SERVER ping the agent. The
    Relay must not expose ``send_heartbeat`` and the orchestrator must not
    invoke any heartbeat-shaped attribute. This is a dual-source assertion:

    1. ``getattr(relay, 'send_heartbeat', None)`` is None on the real Relay.
    2. The orchestrator's ``start()`` never sets up an outbound-heartbeat
       task (asserted indirectly by the silence-timeout-only test above).
    """
    from agentvault_hermes.core.transport.relay import Relay

    assert not hasattr(Relay, "send_heartbeat")


def test_secure_channel_registers_all_nine_event_handlers(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """`SecureChannel.__init__` MUST wire all known event handlers
    into its `WSEventRegistry`. Catches a future regression where
    someone deletes a `register()` call in a refactor.

    PR-3, Phase 4a — added `mls_welcome_requested` handler.
    action #234 (Task 6) — added `room_joined` handler.
    action #234 (Task 7) — added `room_message_mls` handler.
    action #238 (Slice A) — added a2a_message_mls + the nine A2A lifecycle
    events.
    """
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    registered = ch._event_registry.registered_event_types()
    expected = {
        "ping",
        "error",
        "message_mls",
        "mls_delivery",
        "message",
        "mls_sync_response",
        "mls_welcome_requested",
        "room_joined",
        "room_message_mls",
        # action #238 — A2A
        "a2a_message_mls",
        "a2a_channel_invited",
        "a2a_channel_approved",
        "a2a_channel_rejected",
        "a2a_channel_revoked",
        "a2a_participant_joined",
        "a2a_participant_left",
        "a2a_participant_removed",
        "a2a_agent_removed",
        "a2a_creator_transferred",
        # action #238 (Slice B) — invite_pending stub for Slice C body-fill
        "a2a_invite_pending",
    }
    assert registered == expected, (
        f"WSEventRegistry missing/extra handlers: "
        f"missing={expected - registered} extra={registered - expected}"
    )


@pytest.mark.asyncio
async def test_handle_mls_welcome_requested_happy_path_calls_pull_delivery_queue(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """Inbound `mls_welcome_requested` with a valid `group_id` calls
    `_pull_delivery_queue` to fetch the queued Welcome (after the
    `_initial_setup_complete` wait gates passes)."""
    from unittest.mock import AsyncMock as _AsyncMock
    from agentvault_hermes.channel.outbox import WireEnvelope

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._initial_setup_complete.set()  # bypass Seam-B wait for unit test
    pull_spy = _AsyncMock()
    ch._pull_delivery_queue = pull_spy  # type: ignore[method-assign]

    await ch._handle_mls_welcome_requested(
        WireEnvelope(event="mls_welcome_requested", data={"group_id": "g1"})
    )

    pull_spy.assert_awaited_once()


@pytest.mark.asyncio
async def test_handle_mls_welcome_requested_returns_when_stop_event_set(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """Mirrors `_handle_mls_delivery` P15 guard — a stop signal
    during/after the `_initial_setup_complete` wait must short-circuit
    before `_pull_delivery_queue` (which would round-trip against a
    closed Relay). (DA Cluster 4 parity finding.)"""
    from unittest.mock import AsyncMock as _AsyncMock
    from agentvault_hermes.channel.outbox import WireEnvelope

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._initial_setup_complete.set()  # let the wait pass...
    ch._stop_event.set()  # ...but stop event is now set
    pull_spy = _AsyncMock()
    ch._pull_delivery_queue = pull_spy  # type: ignore[method-assign]

    await ch._handle_mls_welcome_requested(
        WireEnvelope(event="mls_welcome_requested", data={"group_id": "g1"})
    )

    pull_spy.assert_not_awaited()


@pytest.mark.asyncio
async def test_handle_mls_welcome_requested_invalid_missing_group_id_drops(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Missing `group_id` logs `MLS_WELCOME_REQUESTED_INVALID
    reason=missing_group_id` at WARN and drops without calling
    `_pull_delivery_queue`."""
    from unittest.mock import AsyncMock as _AsyncMock
    from agentvault_hermes.channel.outbox import WireEnvelope

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    pull_spy = _AsyncMock()
    ch._pull_delivery_queue = pull_spy  # type: ignore[method-assign]

    with caplog.at_level(logging.WARNING, logger="agentvault_hermes.channel.secure_channel"):
        await ch._handle_mls_welcome_requested(
            WireEnvelope(event="mls_welcome_requested", data={})
        )

    pull_spy.assert_not_awaited()
    invalid = [
        r for r in caplog.records
        if r.levelno == logging.WARNING
        and "MLS_WELCOME_REQUESTED_INVALID" in r.getMessage()
        and "reason=missing_group_id" in r.getMessage()
    ]
    assert len(invalid) == 1


# ---------------------------------------------------------------------------
# send() — happy path + envelope shape
# ---------------------------------------------------------------------------


async def test_send_no_mls_state_raises(
    relay: FakeRelay,
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    ch = _make_channel(relay, {}, on_inbound, tmp_path)
    with pytest.raises(RuntimeError, match="No MlsGroupState"):
        await ch.send("missing-conv", b"hello")


async def test_send_uninitialized_state_raises(
    relay: FakeRelay,
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    state = FakeMlsState(initialized=False)
    ch = _make_channel(relay, {_FAKE_CONV_ID: state}, on_inbound, tmp_path)
    with pytest.raises(RuntimeError, match="No MlsGroupState"):
        await ch.send(_FAKE_CONV_ID, b"hi")


async def test_send_rate_limited_is_a_noop(
    relay: FakeRelay,
    mls_state: FakeMlsState,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """When ``loop_preventer.can_reply`` returns False, ``send()`` must
    short-circuit BEFORE encrypt — no relay call, no ratchet advance, no
    persist."""
    fake_lp = MagicMock()
    fake_lp.can_reply.return_value = False
    fake_lp.record_reply = MagicMock()

    ch = SecureChannel(
        relay=relay,  # type: ignore[arg-type]
        mls_states=mls_states,
        on_inbound=on_inbound,
        data_dir=tmp_path,
        device_keys=_fake_signing_keypair(),
        device_id=_FAKE_DEVICE_ID,
        agent_name="hermes-test",
        account_id="acct-test",
        loop_preventer=fake_lp,
    )
    await ch.send(_FAKE_CONV_ID, b"silenced")

    relay.send_message.assert_not_called()
    fake_lp.record_reply.assert_not_called()
    assert mls_state.encrypt_call_count == 0


async def test_send_happy_path_envelope_shape(
    relay: FakeRelay,
    mls_state: FakeMlsState,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    await ch.send(
        _FAKE_CONV_ID,
        b"hello world",
        message_type="text",
        client_message_id="cmid-1",
        topic_id="topic-1",
        parent_span_id="span-1",
        metadata={"k": "v"},
    )

    # Encrypt called once.
    assert mls_state.encrypt_call_count == 1
    # Persist called once (export_state).
    assert mls_state.export_state_call_count == 1

    relay.send_message.assert_awaited_once()
    kwargs = relay.send_message.await_args.kwargs
    assert kwargs["conversation_id"] == _FAKE_CONV_ID
    assert kwargs["group_id"] == _FAKE_GROUP_ID_STR
    # Bug A follow-up (action_item #164): SecureChannel.send reads epoch
    # AFTER encrypt() so a joiner's wire-refresh self-heal (PR #171) takes
    # effect for the first outbound. FakeMlsState advances _epoch inside
    # encrypt() to simulate the per-message sequence, so the wire epoch
    # captured here is 1 (post-encrypt) rather than 0 (pre-encrypt). The
    # real MlsGroupState does NOT advance epoch on encrypt — only on
    # commits — so in production this read remains stable across multiple
    # sends within the same epoch (e.g. all at epoch=1 for a §M1 1:1 flow).
    assert kwargs["epoch"] == 1
    assert kwargs["ciphertext"] == b"ciphertext-hello world"
    assert kwargs["message_type"] == "text"
    assert kwargs["client_message_id"] == "cmid-1"
    assert kwargs["topic_id"] == "topic-1"
    assert kwargs["parent_span_id"] == "span-1"
    assert kwargs["metadata"] == {"k": "v"}

    # **Critical**: NO sender_device_id on the outbound envelope (§3.7).
    assert "sender_device_id" not in kwargs


async def test_send_persists_state_before_relay(
    relay: FakeRelay,
    mls_state: FakeMlsState,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """Persist BEFORE relay send — so a relay error doesn't desync state.

    Asserted by side-effect ordering: when relay.send_message raises, the
    on-disk mls_state.bin must already exist.
    """
    relay.send_message = AsyncMock(side_effect=RuntimeError("ws closed"))
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    with pytest.raises(RuntimeError, match="ws closed"):
        await ch.send(_FAKE_CONV_ID, b"hello")

    state_path = tmp_path / "conversations" / _FAKE_CONV_ID / "mls_state.bin"
    assert state_path.exists(), "state must be persisted before relay send"
    assert state_path.read_bytes() == b"exported-state"


async def test_send_record_reply_only_after_success(
    relay: FakeRelay,
    mls_state: FakeMlsState,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """DA #14: ``record_reply`` must NOT fire on a failed send."""
    fake_lp = MagicMock()
    fake_lp.can_reply.return_value = True
    fake_lp.record_reply = MagicMock()

    relay.send_message = AsyncMock(side_effect=RuntimeError("ws closed"))
    ch = SecureChannel(
        relay=relay,  # type: ignore[arg-type]
        mls_states=mls_states,
        on_inbound=on_inbound,
        data_dir=tmp_path,
        device_keys=_fake_signing_keypair(),
        device_id=_FAKE_DEVICE_ID,
        agent_name="hermes-test",
        account_id="acct-test",
        loop_preventer=fake_lp,
    )

    with pytest.raises(RuntimeError):
        await ch.send(_FAKE_CONV_ID, b"hi")

    fake_lp.record_reply.assert_not_called()


# ---------------------------------------------------------------------------
# Concurrent send acceptance (DA #11 mandate / §8.11b)
# ---------------------------------------------------------------------------


async def test_concurrent_send_serializes_critical_section(
    relay: FakeRelay,
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """5 ``asyncio.gather(send(conv_X, b"msg-N"))`` calls must SERIALIZE through
    the per-conv lock — at most one coroutine in the critical section at a time.

    Acceptance contract (DA #11 mandate / plan §8.11b):

    - The per-conv lock guarantees ``MlsGroupState`` is touched by at most one
      coroutine at any moment, even when the critical section contains awaits
      (current code: ``await asyncio.to_thread(_persist_state_sync, ...)`` and
      ``await relay.send_message(...)``).
    - Without the lock, two coroutines can be in flight on the same state
      simultaneously, leading to duplicate wire epochs and a desynced ratchet.

    Test mechanics:

    - Wrap ``state.encrypt`` to count peak in-flight critical-section depth
      across the entire test by tracking entries/exits. The encrypt + the
      following persist + relay-send together form the critical section.
    - Force the relay.send_message to ``await asyncio.sleep(0)`` so the loop
      gets a clean opportunity to schedule another coroutine into the
      critical section *if* the lock is missing.
    - Assert ``concurrent_peak == 1`` — strict serialization.
    - Assert wire epochs are ``[0, 1, 2, 3, 4]`` with no duplicates.

    The default ``LoopPreventer`` rate-limits at 4 replies / 60s; we inject
    an always-allow stand-in so only the per-conv lock is exercised.
    """
    state = FakeMlsState()
    mls_states = {_FAKE_CONV_ID: state}

    permissive_lp = MagicMock()
    permissive_lp.can_reply.return_value = True
    permissive_lp.record_reply = MagicMock()

    # Track concurrent depth across the lock-protected region. The lock
    # in send() encloses encrypt + persist + relay.send_message; we snapshot
    # depth on relay.send_message entry (which is the LAST awaited operation
    # inside the lock; if two coros are inside, both will be visible here).
    in_flight = {"depth": 0, "peak": 0}

    async def slow_send_message(**kwargs: Any) -> None:
        in_flight["depth"] += 1
        in_flight["peak"] = max(in_flight["peak"], in_flight["depth"])
        # Yield so any sibling coroutine in the critical section becomes
        # visible if the lock is missing.
        await asyncio.sleep(0)
        await asyncio.sleep(0)
        in_flight["depth"] -= 1

    relay.send_message = AsyncMock(side_effect=slow_send_message)

    ch = SecureChannel(
        relay=relay,  # type: ignore[arg-type]
        mls_states=mls_states,
        on_inbound=on_inbound,
        data_dir=tmp_path,
        device_keys=_fake_signing_keypair(),
        device_id=_FAKE_DEVICE_ID,
        agent_name="hermes-test",
        account_id="acct-test",
        loop_preventer=permissive_lp,
    )

    async def one_send(n: int) -> None:
        await ch.send(_FAKE_CONV_ID, f"msg-{n}".encode())

    await asyncio.gather(*(one_send(i) for i in range(5)))

    # Strict serialization: at no point were two coros in the critical
    # section simultaneously.
    assert in_flight["peak"] == 1, (
        f"per-conv lock must serialize critical section, peak depth "
        f"observed = {in_flight['peak']}"
    )

    # All 5 reached the wire.
    wire_epochs = [
        call.kwargs["epoch"] for call in relay.send_message.await_args_list
    ]
    assert len(wire_epochs) == 5
    # Strictly monotonic + no duplicates. SecureChannel.send reads epoch
    # AFTER encrypt() (Bug A fix — see PR #171 / follow-up): the wire
    # captures the *post-encrypt* counter so FakeMlsState's advance-on-
    # encrypt yields 1..5 here, not 0..4. The serialization invariant
    # (no duplicates, strictly monotonic) is the load-bearing part — the
    # specific offset is just bookkeeping of when the counter is sampled.
    assert sorted(wire_epochs) == [1, 2, 3, 4, 5], (
        f"per-conv lock contract: post-encrypt epochs are 1..5, got {sorted(wire_epochs)}"
    )
    assert len(set(wire_epochs)) == 5
    # Encrypt observations (recorded INSIDE encrypt, pre-advance) remain
    # at 0..4 — that captures the lock-protected sequence at encrypt time.
    assert state.observed_epochs == [0, 1, 2, 3, 4]


# ---------------------------------------------------------------------------
# Demux loop
# ---------------------------------------------------------------------------


async def test_demux_loop_stamps_last_inbound_on_every_frame(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    fake_clock: dict[str, Any],
) -> None:
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    # Set initial clock; start() will record this as last_inbound_ts.
    fake_clock["now"] = 1_000_000.0
    await ch.start()
    try:
        assert ch._last_inbound_ts == 1_000_000.0

        # Advance the clock and push a frame; demux must restamp.
        fake_clock["now"] = 1_000_050.0
        await relay.push_inbound(WireEnvelope(event="ping", data={}))

        # Yield to let the demux loop process the frame.
        for _ in range(20):
            await asyncio.sleep(0)
            if ch._last_inbound_ts == 1_000_050.0:
                break
        assert ch._last_inbound_ts == 1_000_050.0
    finally:
        await relay.shutdown_inbound()
        await ch.stop()


async def test_demux_loop_pings_echo_pong_and_skip_handlers(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
) -> None:
    """``event=="ping"`` MUST echo a pong and MUST NOT call MLS/DR handlers.

    Backend at ``packages/backend/app/api/v1/ws.py:762-764`` calls
    ``manager.on_pong(did)`` which refreshes Redis ``device:<id>:alive`` TTL.
    Without the echo, the device's liveness key expires and other devices
    silently see us as dead — symptom is "agent appears connected but
    receives no messages."
    """
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    await ch.start()
    try:
        await relay.push_inbound(WireEnvelope(event="ping", data={}))
        # Yield so the demux processes the ping.
        for _ in range(20):
            await asyncio.sleep(0)

        # MLS / DR handlers must NOT have been invoked.
        stub_inbox["handle_message_mls"].assert_not_called()
        stub_inbox["handle_message_dr"].assert_not_called()
        on_inbound.assert_not_called()
        # send_message (application messages) must NOT have been invoked.
        relay.send_message.assert_not_called()
        # send_pong MUST have been called exactly once for the one ping.
        assert relay.send_pong.await_count == 1
    finally:
        await relay.shutdown_inbound()
        await ch.stop()


async def test_demux_loop_continues_after_pong_echo_failure(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
) -> None:
    """A failed pong echo (e.g. RECONNECTING WsClient) must NOT crash demux.

    The next legitimate ping may succeed; logging the failure and continuing
    is the right shape — losing one liveness tick is much cheaper than
    killing the orchestrator.
    """
    relay.send_pong.side_effect = RuntimeError("ws not open")
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    await ch.start()
    try:
        await relay.push_inbound(WireEnvelope(event="ping", data={}))
        # Now switch send_pong back to success and push a 2nd ping.
        relay.send_pong.side_effect = None
        await relay.push_inbound(WireEnvelope(event="ping", data={}))
        for _ in range(20):
            await asyncio.sleep(0)
        # Demux survived — both pings observed.
        assert relay.send_pong.await_count == 2
    finally:
        await relay.shutdown_inbound()
        await ch.stop()


async def test_demux_loop_dispatches_message_mls(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
) -> None:
    inbound = InboundMessage(
        conversation_id=_FAKE_CONV_ID,
        sender_device_id="other-device",
        plaintext="hi",
        message_type="text",
        is_handshake=False,
    )
    stub_inbox["handle_message_mls"].return_value = inbound

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    await ch.start()
    try:
        env = WireEnvelope(event="message_mls", data={"payload": "deadbeef"})
        await relay.push_inbound(env)
        # Real wall-clock sleep — the demux uses ``asyncio.to_thread`` for
        # ``_persist_state_sync``, which needs the OS scheduler to run the
        # worker thread. ``sleep(0)`` doesn't release CPU long enough on
        # slower CI runners (Linux GH Actions). 50ms × 50 = 2.5s ceiling
        # but the typical wait is single-digit ms.
        for _ in range(50):
            await asyncio.sleep(0.05)
            if on_inbound.await_count >= 1:
                break

        stub_inbox["handle_message_mls"].assert_awaited_once()
        # First positional arg is the envelope itself.
        call_args = stub_inbox["handle_message_mls"].await_args
        assert call_args.args[0] is env
        on_inbound.assert_awaited_once_with(inbound)
    finally:
        await relay.shutdown_inbound()
        await ch.stop()


async def test_demux_loop_dispatches_message_dr_to_dr_handler(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
) -> None:
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    await ch.start()
    try:
        env = WireEnvelope(event="message", data={"ciphertext": "x"})
        await relay.push_inbound(env)
        for _ in range(50):
            await asyncio.sleep(0)
            if stub_inbox["handle_message_dr"].await_count >= 1:
                break

        stub_inbox["handle_message_dr"].assert_awaited_once_with(env)
        # MLS handler not invoked for DR frames.
        stub_inbox["handle_message_mls"].assert_not_called()
        on_inbound.assert_not_called()
    finally:
        await relay.shutdown_inbound()
        await ch.stop()


async def test_demux_loop_persists_after_handshake_decrypt(
    relay: FakeRelay,
    mls_state: FakeMlsState,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
) -> None:
    """DA #10 / §10.10 fix: persist runs regardless of ``is_handshake``.

    Handshake commits advance the epoch internally — we MUST save state, but
    we MUST NOT surface to ``on_inbound`` (no payload to deliver).
    """
    handshake = InboundMessage(
        conversation_id=_FAKE_CONV_ID,
        sender_device_id="other-device",
        plaintext="",
        message_type="text",
        is_handshake=True,
    )
    stub_inbox["handle_message_mls"].return_value = handshake

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    await ch.start()
    try:
        await relay.push_inbound(
            WireEnvelope(event="message_mls", data={"payload": "ff"})
        )
        # Real wall-clock — to_thread worker needs OS scheduling (see
        # test_demux_loop_dispatches_message_mls comment).
        for _ in range(50):
            await asyncio.sleep(0.05)
            if mls_state.export_state_call_count >= 1:
                break

        # State persisted EVEN for handshake (DA #10).
        assert mls_state.export_state_call_count >= 1
        # Agent surface skipped for handshake (no payload).
        on_inbound.assert_not_called()
    finally:
        await relay.shutdown_inbound()
        await ch.stop()


async def test_demux_loop_unknown_event_is_silently_ignored(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
) -> None:
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    await ch.start()
    try:
        await relay.push_inbound(
            WireEnvelope(event="totally_unknown", data={})
        )
        for _ in range(20):
            await asyncio.sleep(0)

        stub_inbox["handle_message_mls"].assert_not_called()
        stub_inbox["handle_message_dr"].assert_not_called()
        on_inbound.assert_not_called()
    finally:
        await relay.shutdown_inbound()
        await ch.stop()


async def test_demux_loop_catches_handler_exceptions_and_continues(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
) -> None:
    """A bad frame must NOT kill the WS demux. After a handler raises, the
    next frame is still processed normally."""
    inbound_ok = InboundMessage(
        conversation_id=_FAKE_CONV_ID,
        sender_device_id="other-device",
        plaintext="ok",
        message_type="text",
        is_handshake=False,
    )
    # First call raises; second returns a normal inbound.
    stub_inbox["handle_message_mls"].side_effect = [
        RuntimeError("bad frame"),
        inbound_ok,
    ]

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    await ch.start()
    try:
        await relay.push_inbound(
            WireEnvelope(event="message_mls", data={"payload": "00"})
        )
        await relay.push_inbound(
            WireEnvelope(event="message_mls", data={"payload": "11"})
        )

        # Real wall-clock — to_thread worker needs OS scheduling (see
        # test_demux_loop_dispatches_message_mls comment).
        for _ in range(80):
            await asyncio.sleep(0.05)
            if on_inbound.await_count >= 1:
                break

        # Both calls processed.
        assert stub_inbox["handle_message_mls"].await_count == 2
        # Only the second produced an agent surface.
        on_inbound.assert_awaited_once_with(inbound_ok)
    finally:
        await relay.shutdown_inbound()
        await ch.stop()


# ---------------------------------------------------------------------------
# Silence-timeout
# ---------------------------------------------------------------------------


async def test_silence_timeout_triggers_reconnect_after_90s(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When ``monotonic() - last_inbound_ts > 90.0``, the silence-timeout
    task calls the reconnect path (which disconnects + reconnects the relay).

    Strategy: short-circuit ``asyncio.sleep`` and ``time.monotonic`` so the
    test does not wait 30s wall-clock. Drive a single tick of the silence
    task and verify the reconnect calls happen.
    """
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    # Patch monotonic to advance past 90s of "silence" on the first read
    # the silence task does.
    state = {"now": 1_000_000.0}

    def _monotonic() -> float:
        return state["now"]

    monkeypatch.setattr(sc_module.time, "monotonic", _monotonic)

    # Patch sleep so the loop ticks immediately; record sleep durations.
    sleep_durations: list[float] = []

    real_sleep = asyncio.sleep

    async def fast_sleep(seconds: float) -> None:
        sleep_durations.append(seconds)
        await real_sleep(0)  # yield once

    monkeypatch.setattr(sc_module.asyncio, "sleep", fast_sleep)

    await ch.start()
    try:
        # Force the clock 100s into the future BEFORE the silence task ticks
        # again so its first post-sleep monotonic() read sees silence > 90.
        state["now"] = 1_000_100.0

        # Let the silence task cycle several times.
        for _ in range(50):
            await real_sleep(0)
            if relay.disconnect.await_count >= 1:
                break

        # Silence-timeout cadence is 30s.
        ping_interval = sc_module._PING_INTERVAL_SECONDS
        assert ping_interval in sleep_durations
        # Disconnect + reconnect both invoked.
        assert relay.disconnect.await_count >= 1
        # connect was invoked at start + during reconnect → ≥ 2.
        assert relay.connect.await_count >= 2
    finally:
        await relay.shutdown_inbound()
        # Ensure stop completes — reset patched sleep so stop's gather has a
        # real cancellation path.
        monkeypatch.setattr(sc_module.asyncio, "sleep", real_sleep)
        await ch.stop()


async def test_silence_timeout_does_not_fire_when_inbound_is_recent(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A fresh inbound stamp keeps the silence-timeout task quiet."""
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    state = {"now": 1_000_000.0}
    monkeypatch.setattr(sc_module.time, "monotonic", lambda: state["now"])

    real_sleep = asyncio.sleep
    sleep_calls = {"count": 0}

    async def fast_sleep(seconds: float) -> None:
        sleep_calls["count"] += 1
        await real_sleep(0)

    monkeypatch.setattr(sc_module.asyncio, "sleep", fast_sleep)

    await ch.start()
    try:
        # Advance only 60s (< 90s threshold).
        state["now"] = 1_000_060.0
        for _ in range(40):
            await real_sleep(0)

        # No reconnect — disconnect not invoked beyond zero.
        assert relay.disconnect.await_count == 0
    finally:
        await relay.shutdown_inbound()
        monkeypatch.setattr(sc_module.asyncio, "sleep", real_sleep)
        await ch.stop()


# ---------------------------------------------------------------------------
# stop() teardown
# ---------------------------------------------------------------------------


async def test_stop_cancels_running_silence_task(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
) -> None:
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    await ch.start()
    # Snapshot the silence-timeout task BEFORE stop() so we can assert it
    # was cancelled. (poll_fallback / trust_token_refresh return immediately
    # and have already been discarded; demux_loop and silence-timeout are
    # the long-lived tasks.)
    long_lived_before = list(ch._background_tasks)
    assert len(long_lived_before) >= 1

    await relay.shutdown_inbound()
    await ch.stop()

    # Every long-lived task is now done.
    for task in long_lived_before:
        assert task.done(), f"task {task!r} should be done after stop()"


async def test_release_lock_validates_empty_conv_id(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """DA #2: ``_release_lock`` must reject empty ``conv_id`` to prevent a
    cross-process collision on the filename ``mls-a2a-sync-.lock``."""
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    # Should be a no-op — no filesystem side effect, no exception.
    await ch._release_lock("")
    # No lock file created.
    assert not list(tmp_path.glob("mls-a2a-sync*"))


async def test_release_lock_calls_underlying_release(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """Non-empty ``conv_id`` reaches ``release_a2a_sync_lock`` and discards
    from the held set."""
    from agentvault_hermes.channel import lock_file as lock_file_module

    # Create a lock file via the real acquire so we can test the release.
    lock_file_module.acquire_a2a_sync_lock(tmp_path, _FAKE_CONV_ID)
    lock_path = lock_file_module._sync_lock_path(tmp_path, _FAKE_CONV_ID)
    assert lock_path.exists()

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._held_locks.add(_FAKE_CONV_ID)

    await ch._release_lock(_FAKE_CONV_ID)

    assert not lock_path.exists()
    assert _FAKE_CONV_ID not in ch._held_locks


# ---------------------------------------------------------------------------
# Post-DA-review hardening — silent-corruption-mode fixes
# ---------------------------------------------------------------------------


async def test_demux_loop_survives_relay_reconnect(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """After ``_schedule_reconnect`` cycles the relay, the demux loop MUST
    re-attach to the new ``receive_messages`` iterator. Without the outer
    while-loop, the demux would silently die after the first reconnect and
    no inbound traffic would reach the agent.

    Strategy: replace ``receive_messages`` with a controllable async generator
    factory that yields successive iterators. First iterator yields one ping
    then ends; second iterator yields another ping. Demux must attach to both.
    """
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    # Build successive iterators that simulate WsClient lifecycle: each
    # ``receive_messages()`` call returns a NEW finite iterator.
    iterations = [
        [WireEnvelope(event="ping", data={})],
        [WireEnvelope(event="ping", data={})],
    ]
    iter_index = {"i": 0}

    async def fake_receive_messages():  # type: ignore[no-untyped-def]
        idx = iter_index["i"]
        iter_index["i"] += 1
        if idx >= len(iterations):
            # Out of frames — pretend the relay disconnected: raise
            # RuntimeError so the demux's outer-loop sleeps and re-tries.
            raise RuntimeError("relay disconnected")
        for env in iterations[idx]:
            yield env

    monkeypatch.setattr(relay, "receive_messages", fake_receive_messages)

    await ch.start()
    try:
        # Wait for both iterations to be consumed. The OLD iterator ending
        # forces the outer while-loop to re-attach via a fresh iterator.
        for _ in range(60):
            await asyncio.sleep(0)
            if relay.send_pong.await_count >= 2:
                break

        assert relay.send_pong.await_count == 2, (
            f"demux did not re-attach after iterator end: "
            f"send_pong called {relay.send_pong.await_count} times, expected 2"
        )
    finally:
        await ch.stop()


async def test_persist_state_writes_atomically(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    mls_state: FakeMlsState,
) -> None:
    """A crash mid-write must NOT leave a truncated mls_state.bin.

    Verify the impl uses a tempfile + os.replace pattern by simulating
    a failure during ``state.export_state()`` AFTER a previous successful
    persist — the on-disk bin must remain unchanged (NOT truncated).
    """
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    # First successful persist seeds an on-disk state.
    ch._persist_state_sync(_FAKE_CONV_ID, mls_state)
    bin_path = tmp_path / "conversations" / _FAKE_CONV_ID / "mls_state.bin"
    original_bytes = bin_path.read_bytes()
    assert len(original_bytes) > 0

    # Second persist: simulate a failure mid-export by patching export_state
    # to raise AFTER it has had a chance to write to the tempfile.
    failing_state = FakeMlsState()
    failing_state.export_state = lambda: (_ for _ in ()).throw(  # type: ignore[assignment]
        RuntimeError("simulated mid-export failure")
    )

    with pytest.raises(RuntimeError, match="simulated mid-export failure"):
        ch._persist_state_sync(_FAKE_CONV_ID, failing_state)

    # The original bin file must be intact.
    assert bin_path.read_bytes() == original_bytes
    # No leftover .tmp file.
    assert not (bin_path.parent / "mls_state.bin.tmp").exists()


async def test_persist_state_chmods_bin_to_0o600(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    mls_state: FakeMlsState,
) -> None:
    """``mls_state.bin`` must be chmodded to 0o600 explicitly — relying on
    the parent dir's 0o700 + umask is not sufficient (default umask leaves
    files at 0o644). POSIX-only test.
    """
    import sys
    import stat as stat_module

    if sys.platform == "win32":
        pytest.skip("POSIX-only file-mode test")

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._persist_state_sync(_FAKE_CONV_ID, mls_state)

    bin_path = tmp_path / "conversations" / _FAKE_CONV_ID / "mls_state.bin"
    mode = stat_module.S_IMODE(bin_path.stat().st_mode)
    assert mode == 0o600, f"mls_state.bin mode = {oct(mode)}, expected 0o600"


async def test_persist_state_canonicalizes_uuid_case(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    mls_state: FakeMlsState,
) -> None:
    """An uppercase UUID conv_id must land bin AND meta in the SAME directory.

    Without canonicalization, ``mls_state.bin`` lives in
    ``conversations/AAAA…/`` while ``write_meta`` (which str()-canonicalizes
    to lowercase) writes to ``conversations/aaaa…/``. Two directories →
    state and metadata desync silently.
    """
    # Use a UUID with letters so .upper() vs .lower() actually differ.
    canonical = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
    upper_conv_id = canonical.upper()

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._persist_state_sync(upper_conv_id, mls_state)

    bin_path = tmp_path / "conversations" / canonical / "mls_state.bin"
    meta_path = tmp_path / "conversations" / canonical / "meta.json"
    assert bin_path.exists(), f"bin not at canonical path {bin_path}"
    assert meta_path.exists(), f"meta not at canonical path {meta_path}"

    # On case-sensitive filesystems (Linux ext4 etc.), an uppercase-named
    # directory MUST NOT exist. macOS HFS+/APFS is case-insensitive by
    # default, so checking ``upper_dir.exists()`` would falsely succeed
    # there. Instead, assert the directory entry stored on disk is the
    # canonical (lowercase) form — ``iterdir`` returns the actual stored
    # name regardless of FS case-sensitivity, so this catches the bug
    # cross-platform.
    conv_root = tmp_path / "conversations"
    stored_names = [p.name for p in conv_root.iterdir() if p.is_dir()]
    assert canonical in stored_names, (
        f"canonical name {canonical!r} not found in directory listing "
        f"{stored_names!r}"
    )
    assert upper_conv_id not in stored_names, (
        f"persist stored uppercase {upper_conv_id!r} on disk — UUID case "
        f"divergence between bin and meta would happen on case-sensitive FS"
    )
    assert len(stored_names) == 1, (
        f"persist created multiple directories {stored_names!r}; expected only "
        f"the canonical-lowercase form"
    )


async def test_persist_state_tolerates_corrupt_meta_json(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    mls_state: FakeMlsState,
) -> None:
    """A stale/corrupted meta.json from an earlier crash must NOT escape
    after the in-memory ratchet has advanced AND the bin has been written.
    The next persist replaces the meta cleanly rather than wedging the
    conversation.
    """
    canonical = _FAKE_CONV_ID
    conv_dir = tmp_path / "conversations" / canonical
    conv_dir.mkdir(parents=True, mode=0o700)
    # Plant a corrupt meta.json that read_meta will reject.
    (conv_dir / "meta.json").write_text("{ this is not json")

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    # Must not raise.
    ch._persist_state_sync(canonical, mls_state)

    # Bin written successfully.
    assert (conv_dir / "mls_state.bin").exists()
    # Meta replaced with valid JSON (read_meta now succeeds).
    from agentvault_hermes.crypto.persistence import read_meta
    new_meta = read_meta(tmp_path, UUID(canonical))
    assert new_meta is not None


async def test_persist_state_chmods_existing_dir_defensively(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    mls_state: FakeMlsState,
) -> None:
    """``mkdir(mode=0o700)`` is a no-op on existing dirs. We chmod
    explicitly so the perms match the docstring guarantee even if a prior
    process left the dir with weaker perms.
    """
    import sys
    import stat as stat_module

    if sys.platform == "win32":
        pytest.skip("POSIX-only file-mode test")

    canonical = _FAKE_CONV_ID
    conv_dir = tmp_path / "conversations" / canonical
    conv_dir.mkdir(parents=True, mode=0o755)  # weaker than 0o700
    assert stat_module.S_IMODE(conv_dir.stat().st_mode) == 0o755

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._persist_state_sync(canonical, mls_state)

    # After persist, dir mode is 0o700.
    final_mode = stat_module.S_IMODE(conv_dir.stat().st_mode)
    assert final_mode == 0o700, f"conv_dir mode = {oct(final_mode)}, expected 0o700"


async def test_silence_timeout_does_not_reset_clock_on_failed_reconnect(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If ``_schedule_reconnect`` fails, the silence clock must NOT reset.
    Otherwise we'd buy ourselves another 90s of unobserved dead WS before
    the next reconnect attempt.
    """
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    # Patch monotonic to cycle through controlled values.
    state = {"now": 1_000_000.0}
    monkeypatch.setattr(sc_module.time, "monotonic", lambda: state["now"])

    real_sleep = asyncio.sleep

    async def fast_sleep(seconds: float) -> None:
        await real_sleep(0)

    monkeypatch.setattr(sc_module.asyncio, "sleep", fast_sleep)

    # Allow start()'s initial connect to succeed; subsequent reconnects fail.
    connect_calls = {"n": 0}

    async def flaky_connect() -> None:
        connect_calls["n"] += 1
        if connect_calls["n"] == 1:
            return  # initial start() succeeds
        raise RuntimeError("backend down")

    relay.connect = AsyncMock(side_effect=flaky_connect)

    await ch.start()
    pre_reconnect_ts = ch._last_inbound_ts
    try:
        # Advance past silence threshold.
        state["now"] = 1_000_100.0  # 100s of "silence"
        for _ in range(40):
            await real_sleep(0)
            if relay.disconnect.await_count >= 1:
                break

        # Reconnect was attempted (and failed).
        assert relay.disconnect.await_count >= 1
        # Clock did NOT reset — `_last_inbound_ts` is still the pre-failure value.
        assert ch._last_inbound_ts == pre_reconnect_ts, (
            "silence clock reset despite failed reconnect; would buy 90s of "
            "unobserved dead WS"
        )
    finally:
        await relay.shutdown_inbound()
        monkeypatch.setattr(sc_module.asyncio, "sleep", real_sleep)
        await ch.stop()


async def test_send_handles_36_byte_group_id_from_oc_peer(
    relay: FakeRelay,
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """OC peers encode group_id as the UTF-8 UUID-string (36 bytes), not the
    16-byte UUID.bytes form. The orchestrator must accept both — without
    this, ``UUID(bytes=36-byte-val)`` would raise inside the per-conv lock.
    TODO(WS-30 interop): replace with a fully OC-shaped fixture once Welcome
    receipt lands.
    """
    # group_id is a simple instance attribute — overwrite to the 36-byte
    # UTF-8 UUID-string form that an OC peer would emit.
    oc_style_state = FakeMlsState()
    oc_style_state.group_id = _FAKE_GROUP_ID_STR.encode("ascii")  # 36 bytes
    assert len(oc_style_state.group_id) == 36
    mls_states: dict[str, Any] = {_FAKE_CONV_ID: oc_style_state}

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    await ch.start()
    try:
        await ch.send(_FAKE_CONV_ID, b"hello")
        # send_message was called with the canonical UUID-string group_id.
        kwargs = relay.send_message.await_args.kwargs
        assert kwargs["group_id"] == _FAKE_GROUP_ID_STR
    finally:
        await relay.shutdown_inbound()
        await ch.stop()


async def test_send_rejects_unexpected_group_id_length(
    relay: FakeRelay,
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """A group_id of an unexpected length (neither 16 nor 36 bytes) must
    raise a clear error rather than producing cryptic behavior.
    """

    bad_state = FakeMlsState()
    bad_state.group_id = b"too-short"  # 9 bytes — neither 16 nor 36
    mls_states: dict[str, Any] = {_FAKE_CONV_ID: bad_state}

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    await ch.start()
    try:
        with pytest.raises(RuntimeError, match="group_id length"):
            await ch.send(_FAKE_CONV_ID, b"hello")
    finally:
        await relay.shutdown_inbound()
        await ch.stop()


# ---------------------------------------------------------------------------
# _iter_known_groups — PR-2 Cluster 1
# ---------------------------------------------------------------------------


def test_iter_known_groups_yields_one_to_one_with_local_state(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """``_iter_known_groups`` yields one KnownGroup per entry in
    ``_mls_states`` with group_type='1to1' and has_local_state=True.

    PR-2 launch reality: only 1:1 conversations have MLS state in
    Phase 3. Rooms and A2A iterations exist as forward-parity scaffolds
    but yield nothing today.

    Wire-format contract: ``KnownGroup.group_id`` is the MLS group_id
    resolved via ``_conv_to_group_id``, NOT the conversation_id
    (DA finding #2). ``last_epoch`` comes from ``state.epoch``
    (the real accessor; ``last_epoch`` attribute does not exist —
    DA finding #1).
    """
    from agentvault_hermes.crypto.mls_group import MlsGroupState

    state_a = MagicMock(spec=MlsGroupState)
    state_a.epoch = 5
    state_b = MagicMock(spec=MlsGroupState)
    state_b.epoch = 12
    mls_states["conv-a"] = state_a
    mls_states["conv-b"] = state_b

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._conv_to_group_id["conv-a"] = "group-uuid-a"
    ch._conv_to_group_id["conv-b"] = "group-uuid-b"
    known = list(ch._iter_known_groups())
    one_to_one = [kg for kg in known if kg.group_type == "1to1"]

    assert len(one_to_one) == 2
    # Test the new wire-format contract: group_id is the MLS group_id, not
    # the conversation_id.
    by_group_id = {kg.group_id: kg for kg in one_to_one}
    assert "group-uuid-a" in by_group_id
    assert "group-uuid-b" in by_group_id
    assert by_group_id["group-uuid-a"].last_epoch == 5
    assert by_group_id["group-uuid-b"].last_epoch == 12
    assert all(kg.has_local_state is True for kg in one_to_one)
    assert all(kg.since_ts is None for kg in one_to_one)


def test_iter_known_groups_skips_state_with_no_group_id_mapping(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """If ``_mls_states`` has an entry but ``_conv_to_group_id`` does NOT
    have a mapping for that conv_id, the iterator skips the group and
    logs WARN. Regression guard for DA finding #2 (conv-id vs group-id
    mismatch).
    """
    from agentvault_hermes.crypto.mls_group import MlsGroupState

    state_orphan = MagicMock(spec=MlsGroupState)
    state_orphan.epoch = 3
    mls_states["conv-orphan"] = state_orphan

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    # Deliberately DON'T populate _conv_to_group_id["conv-orphan"]

    with caplog.at_level(
        logging.WARNING, logger="agentvault_hermes.channel.secure_channel"
    ):
        result = list(ch._iter_known_groups())

    one_to_one = [kg for kg in result if kg.group_type == "1to1"]
    assert all(kg.group_id != "conv-orphan" for kg in one_to_one), (
        "Orphaned state (no group_id mapping) must NOT yield"
    )
    warn_records = [
        r
        for r in caplog.records
        if r.levelno == logging.WARNING
        and "MLS_SYNC_KNOWN_GROUP_NO_GROUP_ID" in r.getMessage()
        and "conv_id=conv-orphan" in r.getMessage()
    ]
    assert len(warn_records) == 1


def test_iter_known_groups_tolerates_state_epoch_raising(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """If ``MlsGroupState.epoch`` raises (e.g., uninitialized state),
    the iterator yields with ``last_epoch=None`` rather than crashing.
    Regression guard for the defensive try/except in the Fix 1 diff.

    Note: the real accessor is ``epoch`` (not ``current_epoch``);
    ``_require_initialized`` raises ``MlsGroupNotInitializedError`` for
    uninitialized states. We use an AssertionError stand-in via
    ``PropertyMock(side_effect=...)`` to exercise the bare ``except``
    branch.
    """
    from unittest.mock import PropertyMock

    from agentvault_hermes.crypto.mls_group import MlsGroupState

    state_bad = MagicMock(spec=MlsGroupState)
    type(state_bad).epoch = PropertyMock(
        side_effect=AssertionError("uninitialized")
    )
    mls_states["conv-bad"] = state_bad

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._conv_to_group_id["conv-bad"] = "group-uuid-bad"

    result = list(ch._iter_known_groups())
    bad_kgs = [kg for kg in result if kg.group_id == "group-uuid-bad"]
    assert len(bad_kgs) == 1
    assert bad_kgs[0].last_epoch is None  # tolerated, not crashed


def test_iter_known_groups_is_safe_against_mid_iteration_mutation(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """``_iter_known_groups`` snapshots ``_mls_states.items()`` so a
    concurrent mutation (e.g., new Welcome processed mid-iteration)
    does not raise ``RuntimeError: dictionary changed size during
    iteration``. Regression guard for DA finding #3.
    """
    from agentvault_hermes.crypto.mls_group import MlsGroupState

    state_a = MagicMock(spec=MlsGroupState)
    state_a.epoch = 1
    mls_states["conv-a"] = state_a

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._conv_to_group_id["conv-a"] = "group-uuid-a"

    # Begin iteration, then mutate the dict between iter steps. With
    # the snapshot the iterator must complete without error.
    iterator = ch._iter_known_groups()
    first = next(iterator)  # consume one item
    assert first.group_id == "group-uuid-a"

    # Mutate during iteration
    state_b = MagicMock(spec=MlsGroupState)
    state_b.epoch = 2
    mls_states["conv-b"] = state_b
    ch._conv_to_group_id["conv-b"] = "group-uuid-b"

    # Drain the rest — must NOT raise RuntimeError
    rest = list(iterator)
    # ``conv-b`` was added AFTER the snapshot, so it should NOT appear
    # in this iteration (it appears in the NEXT iteration).
    assert not any(kg.group_id == "group-uuid-b" for kg in rest)


def test_iter_known_groups_yields_room_groups(
    relay: FakeRelay,
    mls_states: dict,
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """A room with an MLS group + local state is yielded as a KnownGroup."""
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    room_id = "room-known-1"
    ch._room_directory.record_welcome(room_id, "group-known-1")
    mls_states[room_id] = _make_initialized_state_returning(b"x")  # epoch accessible
    mls_states[room_id].epoch = 7

    rooms = [kg for kg in ch._iter_known_groups() if kg.group_type == "room"]
    assert len(rooms) == 1
    assert rooms[0].group_id == "group-known-1"
    assert rooms[0].has_local_state is True
    assert rooms[0].last_epoch == 7


def test_iter_known_groups_room_not_yielded_twice(
    relay: FakeRelay,
    mls_states: dict,
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """A joined room MUST appear exactly once across the full output of
    ``_iter_known_groups``, with ``group_type="room"``.

    Regression guard for the double-yield bug: after a room Welcome,
    ``_mls_states[room_id]`` is populated AND ``_conv_to_group_id[room_id]``
    is set — meaning iteration 1 (1:1 walk) would ALSO pick up the room and
    yield it a second time mistyped as ``"1to1"`` unless explicitly skipped.
    This test fails without the ``_room_directory.get(conv_id) is not None``
    guard in iteration 1, and passes with it.
    """
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    room_id = "room-dedup-1"
    wire_group_id = "group-dedup-1"

    # Mirror the real post-Welcome state:
    #   record_welcome populates the RoomDirectory entry with mls_group_id.
    ch._room_directory.record_welcome(room_id, wire_group_id)
    #   _mls_states[room_id] is set after processing the Welcome commit.
    mls_states[room_id] = _make_initialized_state_returning(b"x")
    mls_states[room_id].epoch = 3
    #   _conv_to_group_id[room_id] is populated so iteration 1 WOULD pick it
    #   up without the fix (it passes the group_id_str is None guard).
    ch._conv_to_group_id[room_id] = wire_group_id

    all_groups = list(ch._iter_known_groups())
    matching = [kg for kg in all_groups if kg.group_id == wire_group_id]

    # Must appear exactly once — no double-yield.
    assert len(matching) == 1, (
        f"Expected room group_id={wire_group_id!r} to appear exactly once "
        f"but got {len(matching)} occurrences: {matching}"
    )
    # The single yield must carry the correct type.
    assert matching[0].group_type == "room"


def test_iter_known_groups_skips_room_without_mls_group(
    relay: FakeRelay,
    mls_states: dict,
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """A room known only by name (no Welcome yet) is not yielded."""
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._room_directory.upsert_from_room_joined({
        "room_id": "room-nameonly", "room_name": "N", "members": [], "conversations": [],
    })
    rooms = [kg for kg in ch._iter_known_groups() if kg.group_type == "room"]
    assert rooms == []


def test_iter_known_groups_a2a_iteration_yields_nothing_today(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """Phase 3 stub: the A2A iteration in ``_iter_known_groups`` yields
    no groups. Lock-file based A2A is Phase 3's mechanism; MLS-backed
    A2A is Phase 4+.
    """
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    a2a = [kg for kg in ch._iter_known_groups() if kg.group_type == "a2a"]
    assert a2a == []


def test_iter_known_groups_yields_nothing_when_mls_states_empty(
    relay: FakeRelay,
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """A fresh SecureChannel with no MLS state yields zero KnownGroups.
    Catches the regression where ``_send_initial_sync`` would emit a
    bogus frame for a non-existent group.
    """
    ch = _make_channel(relay, {}, on_inbound, tmp_path)
    assert list(ch._iter_known_groups()) == []


# ---------------------------------------------------------------------------
# _send_initial_sync — PR-2 Cluster 2
# ---------------------------------------------------------------------------


async def test_send_initial_sync_emits_one_mls_sync_per_known_group(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """``_send_initial_sync`` emits one ``event:"mls_sync"`` frame per
    group with ``has_local_state=True``. Wire format per OC
    channel.ts:2689-2733.
    """
    from agentvault_hermes.crypto.mls_group import MlsGroupState

    state_a = MagicMock(spec=MlsGroupState)
    state_a.epoch = 5
    state_b = MagicMock(spec=MlsGroupState)
    state_b.epoch = 12
    mls_states["conv-a"] = state_a
    mls_states["conv-b"] = state_b

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._conv_to_group_id["conv-a"] = "group-uuid-a"
    ch._conv_to_group_id["conv-b"] = "group-uuid-b"

    relay.sent_frames.clear()
    await ch._send_initial_sync()

    sync_frames = [f for f in relay.sent_frames if f.get("event") == "mls_sync"]
    assert len(sync_frames) == 2
    by_group = {f["group_id"]: f for f in sync_frames}
    assert "group-uuid-a" in by_group
    assert "group-uuid-b" in by_group
    assert by_group["group-uuid-a"]["last_epoch"] == 5
    assert by_group["group-uuid-b"]["last_epoch"] == 12
    # since_ts is None today; spec says "omit if None"
    for frame in sync_frames:
        assert "since_ts" not in frame, (
            "since_ts must be OMITTED from payload when None (per spec); "
            "include-as-null is a regression"
        )


async def test_send_initial_sync_emits_nothing_when_no_known_groups(
    relay: FakeRelay,
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """Fresh channel with no MLS state emits zero mls_sync frames."""
    ch = _make_channel(relay, {}, on_inbound, tmp_path)
    relay.sent_frames.clear()
    await ch._send_initial_sync()
    sync_frames = [f for f in relay.sent_frames if f.get("event") == "mls_sync"]
    assert sync_frames == []


async def test_send_initial_sync_skips_group_on_send_error_logs_warn(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Per-group send failure logs ``MLS_SYNC_EMIT_FAIL`` at WARN and
    continues to the next group."""
    from agentvault_hermes.crypto.mls_group import MlsGroupState

    state_a = MagicMock(spec=MlsGroupState)
    state_a.epoch = 5
    state_b = MagicMock(spec=MlsGroupState)
    state_b.epoch = 12
    mls_states["conv-a"] = state_a
    mls_states["conv-b"] = state_b

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._conv_to_group_id["conv-a"] = "group-uuid-a"
    ch._conv_to_group_id["conv-b"] = "group-uuid-b"

    call_count = {"n": 0}

    async def flaky_send(payload: dict[str, Any]) -> None:
        # Phase 4b PR-A1 Task 4: SecureChannel now emits telemetry envelopes
        # ({"event": "telemetry.mls", ...}) through the same relay.send_json
        # used for mls_sync. This test cares about mls_sync flow control, so
        # pass telemetry envelopes through without affecting call_count or
        # failure logic.
        if payload.get("event") != "mls_sync":
            relay.sent_frames.append(payload)
            return
        call_count["n"] += 1
        if call_count["n"] == 1:
            raise RuntimeError("simulated network error")
        relay.sent_frames.append(payload)

    relay.send_json = flaky_send  # type: ignore[method-assign]

    with caplog.at_level(
        logging.WARNING, logger="agentvault_hermes.channel.secure_channel"
    ):
        await ch._send_initial_sync()

    warn_records = [
        r
        for r in caplog.records
        if r.levelno == logging.WARNING
        and "MLS_SYNC_EMIT_FAIL" in r.getMessage()
    ]
    assert len(warn_records) == 1
    assert call_count["n"] == 2  # second send proceeded


async def test_send_initial_sync_aborts_on_consecutive_failures(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """After 3 consecutive failures, scan aborts with one ERROR log."""
    from agentvault_hermes.crypto.mls_group import MlsGroupState

    for i in range(5):
        state = MagicMock(spec=MlsGroupState)
        state.epoch = i
        mls_states[f"conv-{i}"] = state

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    for i in range(5):
        ch._conv_to_group_id[f"conv-{i}"] = f"group-uuid-{i}"

    call_count = {"n": 0}

    async def always_fail(payload: dict[str, Any]) -> None:
        # Phase 4b PR-A1 Task 4: SecureChannel now emits telemetry envelopes
        # ({"event": "telemetry.mls", ...}) through the same relay.send_json
        # used for mls_sync. This test asserts only on mls_sync send attempts;
        # telemetry envelopes are absorbed by the emitter's own try/except
        # (telemetry.py) when raised here, so we let them pass through.
        if payload.get("event") != "mls_sync":
            return
        call_count["n"] += 1
        raise RuntimeError("simulated network error")

    relay.send_json = always_fail  # type: ignore[method-assign]

    with caplog.at_level(
        logging.WARNING, logger="agentvault_hermes.channel.secure_channel"
    ):
        await ch._send_initial_sync()

    assert call_count["n"] == 3  # threshold = 3 default
    error_records = [
        r
        for r in caplog.records
        if r.levelno == logging.ERROR and "MLS_SYNC_ABORT" in r.getMessage()
    ]
    assert len(error_records) == 1
    assert "reason=consecutive_failures" in error_records[0].getMessage()


async def test_send_initial_sync_aborts_when_iter_known_groups_raises(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """If ``_iter_known_groups`` raises, scan logs MLS_SYNC_ABORT at ERROR
    and returns — must NOT raise."""
    from agentvault_hermes.channel.secure_channel import KnownGroup

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    def broken_iter() -> Iterator[KnownGroup]:
        raise RuntimeError("simulated persistence corruption")
        yield  # unreachable — keeps this a generator for type signature

    ch._iter_known_groups = broken_iter  # type: ignore[method-assign]

    with caplog.at_level(
        logging.ERROR, logger="agentvault_hermes.channel.secure_channel"
    ):
        await ch._send_initial_sync()  # must NOT raise

    error_records = [
        r
        for r in caplog.records
        if r.levelno == logging.ERROR and "MLS_SYNC_ABORT" in r.getMessage()
    ]
    assert any("reason=iterator_failed" in r.getMessage() for r in error_records)


async def test_send_initial_sync_sync_run_id_increments_per_call(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Each call to ``_send_initial_sync`` consumes the next value from
    ``_sync_run_counter``. Two consecutive calls produce two different
    ``sync_run_id`` values (observed via forced EMIT_FAIL logs)."""
    from agentvault_hermes.crypto.mls_group import MlsGroupState

    state = MagicMock(spec=MlsGroupState)
    state.epoch = 0
    mls_states["conv-x"] = state

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._conv_to_group_id["conv-x"] = "group-uuid-x"

    async def always_fail(payload: dict[str, Any]) -> None:
        raise RuntimeError("force EMIT_FAIL log")

    relay.send_json = always_fail  # type: ignore[method-assign]

    with caplog.at_level(
        logging.WARNING, logger="agentvault_hermes.channel.secure_channel"
    ):
        await ch._send_initial_sync()
        await ch._send_initial_sync()

    import re

    ids_seen: set[str] = set()
    for record in caplog.records:
        msg = record.getMessage()
        if "MLS_SYNC_EMIT_FAIL" not in msg:
            continue
        m = re.search(r"sync_run_id=(\d+)", msg)
        if m:
            ids_seen.add(m.group(1))

    assert len(ids_seen) >= 2, (
        f"Expected >=2 distinct sync_run_ids, got {ids_seen}"
    )


async def test_send_initial_sync_skips_lost_state_groups_and_includes_since_ts(
    relay: FakeRelay,
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """Coverage closer: exercise the two defensive branches that
    `_iter_known_groups` does not hit today —

    1. `has_local_state=False` → the group is skipped (PR-3's
       `_cold_start_scan` owns that path).
    2. `since_ts is not None` → the field IS attached to the payload
       (spec: "omit if None"; this is the inverse branch).

    Both branches exist for forward parity (rooms / lost-state /
    same-epoch replay) and would otherwise sit at 0% coverage until
    PR-3 lands.
    """
    from agentvault_hermes.channel.secure_channel import KnownGroup

    ch = _make_channel(relay, {}, on_inbound, tmp_path)

    def fake_iter() -> Iterator[KnownGroup]:
        # Group with lost state — must be skipped
        yield KnownGroup(
            group_id="lost-group",
            group_type="1to1",
            last_epoch=None,
            since_ts=None,
            has_local_state=False,
        )
        # Group with same-epoch replay timestamp — since_ts must be on payload
        yield KnownGroup(
            group_id="replay-group",
            group_type="1to1",
            last_epoch=7,
            since_ts=1_700_000_000,
            has_local_state=True,
        )

    ch._iter_known_groups = fake_iter  # type: ignore[method-assign]

    relay.sent_frames.clear()
    await ch._send_initial_sync()

    sync_frames = [f for f in relay.sent_frames if f.get("event") == "mls_sync"]
    # 1. Lost-state group was skipped.
    assert all(f["group_id"] != "lost-group" for f in sync_frames)
    # 2. Replay-group made it through with since_ts attached.
    assert len(sync_frames) == 1
    assert sync_frames[0]["group_id"] == "replay-group"
    assert sync_frames[0]["since_ts"] == 1_700_000_000


# ---------------------------------------------------------------------------
# _handle_mls_sync_response — PR-2 Cluster 3
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_handle_mls_sync_response_invalid_missing_fields(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """A `mls_sync_response` payload missing `group_id` or `action` logs
    `MLS_SYNC_RESPONSE_INVALID reason=missing_field` at WARN and drops."""
    from agentvault_hermes.channel.outbox import WireEnvelope

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    with caplog.at_level(logging.WARNING, logger="agentvault_hermes.channel.secure_channel"):
        # Missing group_id
        await ch._handle_mls_sync_response(
            WireEnvelope(event="mls_sync_response", data={"action": "rejoin"})
        )
        # Missing action
        await ch._handle_mls_sync_response(
            WireEnvelope(event="mls_sync_response", data={"group_id": "g1"})
        )

    invalid_records = [
        r for r in caplog.records
        if r.levelno == logging.WARNING
        and "MLS_SYNC_RESPONSE_INVALID" in r.getMessage()
        and "reason=missing_field" in r.getMessage()
    ]
    assert len(invalid_records) == 2


@pytest.mark.asyncio
async def test_handle_mls_sync_response_rejoin_known_group_triggers_cold_start_recover(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """`action="rejoin"` for a known group_id invokes
    `_cold_start_recover_single_group(group_id)` — backend signaled
    our epoch is unrecoverable; recover by publishing a fresh KP +
    firing request-welcome (via inflight dedup).

    PR-3 replaces PR-2's deferred log with this real call.
    """
    from unittest.mock import AsyncMock as _AsyncMock
    from agentvault_hermes.channel.outbox import WireEnvelope

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._known_group_ids = frozenset({"g1"})

    recover_spy = _AsyncMock()
    ch._cold_start_recover_single_group = recover_spy  # type: ignore[method-assign]

    await ch._handle_mls_sync_response(
        WireEnvelope(event="mls_sync_response",
                     data={"group_id": "g1", "action": "rejoin"})
    )

    recover_spy.assert_awaited_once_with("g1")


@pytest.mark.asyncio
async def test_handle_mls_sync_response_rejoin_logs_group_id_when_recover_fails(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """If `_cold_start_recover_single_group` raises during a `rejoin`
    response, the handler logs `MLS_SYNC_RESPONSE_REJOIN_FAIL
    group_id=%s error=%s` at WARN. Without this, the registry's
    generic exception handler logs only event_type + a BLAKE2b payload
    hash — operators can't grep by group_id during triage. (DA
    Cluster 4 operator-visibility finding.)"""
    from unittest.mock import AsyncMock as _AsyncMock
    from agentvault_hermes.channel.outbox import WireEnvelope

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._known_group_ids = frozenset({"g1"})

    recover_spy = _AsyncMock(side_effect=RuntimeError("post failed"))
    ch._cold_start_recover_single_group = recover_spy  # type: ignore[method-assign]

    with caplog.at_level(logging.WARNING, logger="agentvault_hermes.channel.secure_channel"):
        # Handler MUST NOT propagate — registry isolation upstream;
        # in-handler try/except is the operator-log seam.
        await ch._handle_mls_sync_response(
            WireEnvelope(event="mls_sync_response",
                         data={"group_id": "g1", "action": "rejoin"})
        )

    fail = [
        r for r in caplog.records
        if r.levelno == logging.WARNING
        and "MLS_SYNC_RESPONSE_REJOIN_FAIL" in r.getMessage()
        and "group_id=g1" in r.getMessage()
        and "post failed" in r.getMessage()
    ]
    assert len(fail) == 1


@pytest.mark.asyncio
async def test_handle_mls_sync_response_rejoin_unknown_group_logs_invalid(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """`action="rejoin"` for a group NOT in _known_group_ids logs
    MLS_SYNC_RESPONSE_INVALID action=rejoin reason=unknown_group at
    WARN and drops. Defensive against backend bugs."""
    from agentvault_hermes.channel.outbox import WireEnvelope

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._known_group_ids = frozenset()  # empty

    with caplog.at_level(logging.WARNING, logger="agentvault_hermes.channel.secure_channel"):
        await ch._handle_mls_sync_response(
            WireEnvelope(event="mls_sync_response",
                         data={"group_id": "ghost", "action": "rejoin"})
        )

    invalid = [
        r for r in caplog.records
        if r.levelno == logging.WARNING
        and "MLS_SYNC_RESPONSE_INVALID" in r.getMessage()
        and "action=rejoin" in r.getMessage()
        and "reason=unknown_group" in r.getMessage()
    ]
    assert len(invalid) == 1


@pytest.mark.asyncio
async def test_handle_mls_sync_response_replay_complete_clears_in_progress(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """`action="replay_complete"` with an `_sync_in_progress` entry
    clears the entry and logs at DEBUG."""
    import time as _time
    from agentvault_hermes.channel.outbox import WireEnvelope

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._sync_in_progress["g1"] = _time.monotonic()

    with caplog.at_level(logging.DEBUG, logger="agentvault_hermes.channel.secure_channel"):
        await ch._handle_mls_sync_response(
            WireEnvelope(event="mls_sync_response",
                         data={"group_id": "g1", "action": "replay_complete"})
        )

    assert "g1" not in ch._sync_in_progress
    debug_records = [
        r for r in caplog.records
        if r.levelno == logging.DEBUG
        and "mls_sync replay complete" in r.getMessage()
        and "group_id=g1" in r.getMessage()
    ]
    assert len(debug_records) == 1


@pytest.mark.asyncio
async def test_handle_mls_sync_response_replay_complete_without_entry_drops(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """`action="replay_complete"` without _sync_in_progress entry logs
    MLS_SYNC_RESPONSE_UNEXPECTED at INFO and drops. Entry MUST NOT be
    auto-created (defense against forged replay_complete short-
    circuiting a real in-flight sync)."""
    from agentvault_hermes.channel.outbox import WireEnvelope

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    # _sync_in_progress is empty

    with caplog.at_level(logging.INFO, logger="agentvault_hermes.channel.secure_channel"):
        await ch._handle_mls_sync_response(
            WireEnvelope(event="mls_sync_response",
                         data={"group_id": "ghost", "action": "replay_complete"})
        )

    assert "ghost" not in ch._sync_in_progress  # NOT auto-created
    unexpected = [
        r for r in caplog.records
        if r.levelno == logging.INFO
        and "MLS_SYNC_RESPONSE_UNEXPECTED" in r.getMessage()
        and "action=replay_complete" in r.getMessage()
        and "group_id=ghost" in r.getMessage()
    ]
    assert len(unexpected) == 1


@pytest.mark.asyncio
async def test_handle_mls_sync_response_unknown_action_logs_invalid(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Unknown action values log MLS_SYNC_RESPONSE_INVALID action=<value>
    at WARN and drop. Defensive against protocol drift."""
    from agentvault_hermes.channel.outbox import WireEnvelope

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    with caplog.at_level(logging.WARNING, logger="agentvault_hermes.channel.secure_channel"):
        await ch._handle_mls_sync_response(
            WireEnvelope(event="mls_sync_response",
                         data={"group_id": "g1", "action": "future_action"})
        )

    invalid = [
        r for r in caplog.records
        if r.levelno == logging.WARNING
        and "MLS_SYNC_RESPONSE_INVALID" in r.getMessage()
        and "action=future_action" in r.getMessage()
    ]
    assert len(invalid) == 1


# ---------------------------------------------------------------------------
# start() → _send_initial_sync wiring (PR-2 Cluster 4)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_start_emits_initial_mls_sync_for_known_groups(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    stub_inbox: dict[str, AsyncMock],
) -> None:
    """``start()`` MUST trigger ``_send_initial_sync`` after the relay
    connects, before the demux loop spawns. Integration regression
    guard that exercises the full connect → sync emission flow.

    Pre-populates ``_mls_states`` + ``_conv_to_group_id`` so the iterator
    yields a real group; asserts an ``mls_sync`` frame lands on the
    relay's sent_frames list.
    """
    from agentvault_hermes.crypto.mls_group import MlsGroupState

    state = MagicMock(spec=MlsGroupState)
    state.epoch = 7
    mls_states["conv-int-1"] = state

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._conv_to_group_id["conv-int-1"] = "group-uuid-int-1"

    relay.sent_frames.clear()
    try:
        await ch.start()
        sync_frames = [
            f for f in relay.sent_frames if f.get("event") == "mls_sync"
        ]
        assert len(sync_frames) == 1, (
            f"Expected exactly 1 mls_sync frame from start(); got "
            f"{len(sync_frames)}: {sync_frames}"
        )
        assert sync_frames[0]["group_id"] == "group-uuid-int-1"
        assert sync_frames[0]["last_epoch"] == 7
    finally:
        await relay.shutdown_inbound()
        await ch.stop()


# ---------------------------------------------------------------------------
# Phase 4a PR-3: welcome-request inflight dedup
# ---------------------------------------------------------------------------


def test_is_welcome_request_inflight_false_when_no_entry(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """`_is_welcome_request_inflight` returns False when there is no
    entry for the given group_id."""
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    assert ch._is_welcome_request_inflight("g1") is False


def test_is_welcome_request_inflight_true_when_recent_entry(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """`_is_welcome_request_inflight` returns True when there is a
    recent (within TTL) entry."""
    import time as _time

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._welcome_request_inflight["g1"] = _time.monotonic()
    assert ch._is_welcome_request_inflight("g1") is True


def test_is_welcome_request_inflight_false_and_evicts_when_expired(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """`_is_welcome_request_inflight` returns False when the entry's
    age exceeds `_welcome_request_inflight_ttl`. Side effect: the
    expired entry is removed so subsequent checks don't repeat the
    age computation."""
    import time as _time

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._welcome_request_inflight_ttl = 0.1  # tighten for test
    # Set entry well in the past (simulate expired)
    ch._welcome_request_inflight["g1"] = _time.monotonic() - 1.0

    assert ch._is_welcome_request_inflight("g1") is False
    # Expired entry should have been evicted
    assert "g1" not in ch._welcome_request_inflight


def test_mark_welcome_request_inflight_sets_entry(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """`_mark_welcome_request_inflight` records the current monotonic
    timestamp under group_id."""
    import time as _time

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    before = _time.monotonic()
    ch._mark_welcome_request_inflight("g1")
    after = _time.monotonic()

    assert "g1" in ch._welcome_request_inflight
    assert before <= ch._welcome_request_inflight["g1"] <= after


def test_clear_welcome_request_inflight_removes_entry(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """`_clear_welcome_request_inflight` removes the entry if present,
    no-ops if absent (idempotent)."""
    import time as _time

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._welcome_request_inflight["g1"] = _time.monotonic()

    ch._clear_welcome_request_inflight("g1")
    assert "g1" not in ch._welcome_request_inflight

    # Idempotent — second clear does not raise
    ch._clear_welcome_request_inflight("g1")
    assert "g1" not in ch._welcome_request_inflight

    # Idempotent for never-present group
    ch._clear_welcome_request_inflight("never-existed")
    assert "never-existed" not in ch._welcome_request_inflight


def test_try_acquire_welcome_inflight_returns_true_when_free(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """`_try_acquire_welcome_inflight` returns True and marks the slot
    when no entry exists for the group_id."""
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    assert ch._try_acquire_welcome_inflight("g1") is True
    assert "g1" in ch._welcome_request_inflight


def test_try_acquire_welcome_inflight_returns_false_when_held(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """`_try_acquire_welcome_inflight` returns False when another
    caller is already inflight within the TTL window. The existing
    entry is NOT overwritten (preserves the original acquire time)."""
    import time as _time

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    original_ts = _time.monotonic() - 0.01  # slightly in the past
    ch._welcome_request_inflight["g1"] = original_ts

    assert ch._try_acquire_welcome_inflight("g1") is False
    # Original timestamp preserved — losing call does NOT extend TTL
    assert ch._welcome_request_inflight["g1"] == original_ts


def test_try_acquire_welcome_inflight_evicts_and_acquires_when_expired(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """`_try_acquire_welcome_inflight` evicts an expired entry and
    acquires a fresh slot in a single operation."""
    import time as _time

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._welcome_request_inflight_ttl = 0.1
    ch._welcome_request_inflight["g1"] = _time.monotonic() - 1.0  # expired

    assert ch._try_acquire_welcome_inflight("g1") is True
    # New entry is fresh (within last 1s)
    assert (_time.monotonic() - ch._welcome_request_inflight["g1"]) < 1.0


# ---------------------------------------------------------------------------
# Phase 4a PR-3 Cluster 2: _cold_start_recover_single_group
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cold_start_recover_single_group_publishes_kp_and_fires_request_welcome(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """`_cold_start_recover_single_group` calls
    `_ensure_pending_key_package()` THEN fires
    `inbox._fire_request_welcome` with the group_id. Inflight is
    acquired (atomically) before firing; cleared on completion."""
    from unittest.mock import AsyncMock as _AsyncMock

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    # Mock _ensure_pending_key_package
    ensure_spy = _AsyncMock()
    ch._ensure_pending_key_package = ensure_spy  # type: ignore[method-assign]

    # Mock the module-level _fire_request_welcome that the orchestrator
    # invokes via inbox module reference
    fire_spy = _AsyncMock()
    monkeypatch.setattr(
        "agentvault_hermes.channel.inbox._fire_request_welcome",
        fire_spy,
    )

    await ch._cold_start_recover_single_group("group-uuid-a")

    ensure_spy.assert_awaited_once()
    fire_spy.assert_awaited_once()
    # Verify the keyword args wire through from the Relay's public attrs
    call_kwargs = fire_spy.await_args.kwargs
    assert call_kwargs["rest_base_url"] == relay.rest_base_url
    assert call_kwargs["device_jwt"] == relay.device_jwt
    assert call_kwargs["group_id"] == "group-uuid-a"
    assert call_kwargs["own_device_id"] == relay.device_id
    # Inflight should be cleared after completion
    assert "group-uuid-a" not in ch._welcome_request_inflight


@pytest.mark.asyncio
async def test_cold_start_recover_single_group_skips_when_inflight(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """If the inflight slot is already held (atomic acquire returns False),
    the recover wrapper logs MLS_WELCOME_REQUEST_SKIPPED reason=inflight
    and returns without calling `_ensure_pending_key_package` or
    `_fire_request_welcome`. Prevents duplicate POST under parallel
    recovery flows (cold-start vs stale-KP race)."""
    from unittest.mock import AsyncMock as _AsyncMock
    import time as _time

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    # Pre-mark inflight so _try_acquire_welcome_inflight returns False
    ch._welcome_request_inflight["g1"] = _time.monotonic()
    original_ts = ch._welcome_request_inflight["g1"]

    ensure_spy = _AsyncMock()
    ch._ensure_pending_key_package = ensure_spy  # type: ignore[method-assign]
    fire_spy = _AsyncMock()
    monkeypatch.setattr(
        "agentvault_hermes.channel.inbox._fire_request_welcome",
        fire_spy,
    )

    with caplog.at_level(logging.INFO, logger="agentvault_hermes.channel.secure_channel"):
        await ch._cold_start_recover_single_group("g1")

    ensure_spy.assert_not_awaited()
    fire_spy.assert_not_awaited()
    # Inflight entry preserved — the losing caller does NOT extend TTL
    # nor clear the winner's slot.
    assert ch._welcome_request_inflight["g1"] == original_ts
    skipped = [
        r for r in caplog.records
        if r.levelno == logging.INFO
        and "MLS_WELCOME_REQUEST_SKIPPED" in r.getMessage()
        and "reason=inflight" in r.getMessage()
        and "group_id=g1" in r.getMessage()
    ]
    assert len(skipped) == 1


@pytest.mark.asyncio
async def test_cold_start_recover_single_group_clears_inflight_on_failure(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If `_ensure_pending_key_package` raises, the inflight entry is
    cleared (NOT left dangling) so a retry on the next connect isn't
    TTL-bound. The exception is re-raised — callers (scan + handler)
    treat single-group failure as recoverable by wrapping each group
    in try/except."""
    from unittest.mock import AsyncMock as _AsyncMock

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._ensure_pending_key_package = _AsyncMock(  # type: ignore[method-assign]
        side_effect=RuntimeError("publish failed"),
    )

    fire_spy = _AsyncMock()
    monkeypatch.setattr(
        "agentvault_hermes.channel.inbox._fire_request_welcome",
        fire_spy,
    )

    with pytest.raises(RuntimeError, match="publish failed"):
        await ch._cold_start_recover_single_group("g1")

    # POST must not have fired (publish failed before POST)
    fire_spy.assert_not_awaited()
    # Inflight cleared (not stale-stuck for the TTL window)
    assert "g1" not in ch._welcome_request_inflight


@pytest.mark.asyncio
async def test_cold_start_recover_single_group_clears_inflight_on_cancellation(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If the wrapper is cancelled mid-`_ensure_pending_key_package` or
    mid-POST, the inflight entry is still cleared via the `finally`
    path. Without this, a cancelled cold-start would leak the inflight
    slot for the full TTL window and silently skip recovery on the next
    connect attempt. (DA Cluster 2 finding: bare `except Exception`
    does not catch `asyncio.CancelledError`.)"""
    from unittest.mock import AsyncMock as _AsyncMock
    import asyncio as _asyncio

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._ensure_pending_key_package = _AsyncMock(  # type: ignore[method-assign]
        side_effect=_asyncio.CancelledError(),
    )

    fire_spy = _AsyncMock()
    monkeypatch.setattr(
        "agentvault_hermes.channel.inbox._fire_request_welcome",
        fire_spy,
    )

    with pytest.raises(_asyncio.CancelledError):
        await ch._cold_start_recover_single_group("g1")

    # POST must not have fired (cancelled before POST)
    fire_spy.assert_not_awaited()
    # Inflight cleared via `finally` even though CancelledError is a
    # BaseException, not an Exception.
    assert "g1" not in ch._welcome_request_inflight


@pytest.mark.asyncio
async def test_cold_start_scan_skips_groups_with_local_state(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """`_cold_start_scan` skips groups whose `has_local_state=True` —
    those are PR-2 `_send_initial_sync`'s territory. Only fires
    recovery for `has_local_state=False` groups (lost-state recovery)."""
    from unittest.mock import AsyncMock as _AsyncMock, MagicMock
    from agentvault_hermes.crypto.mls_group import MlsGroupState

    state = MagicMock(spec=MlsGroupState)
    state.epoch = 5
    mls_states["conv-a"] = state

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._conv_to_group_id["conv-a"] = "group-uuid-a"

    # Spy on the recover wrapper to detect any calls
    recover_spy = _AsyncMock()
    ch._cold_start_recover_single_group = recover_spy  # type: ignore[method-assign]

    await ch._cold_start_scan()

    # No recovery should fire — conv-a has local state
    recover_spy.assert_not_awaited()


@pytest.mark.asyncio
async def test_cold_start_scan_fires_recovery_for_lost_state_groups(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """For each group yielded by `_iter_known_groups` with
    `has_local_state=False`, the scan invokes
    `_cold_start_recover_single_group(group_id)`. To simulate a
    lost-state group without rebuilding `_mls_states`, override
    `_iter_known_groups` to yield a single synthetic
    `has_local_state=False` group."""
    from unittest.mock import AsyncMock as _AsyncMock
    from agentvault_hermes.channel.secure_channel import KnownGroup

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    def fake_iter() -> Iterator[KnownGroup]:
        yield KnownGroup(
            group_id="lost-group-1",
            group_type="1to1",
            last_epoch=None,
            since_ts=None,
            has_local_state=False,
        )
    ch._iter_known_groups = fake_iter  # type: ignore[method-assign]

    recover_spy = _AsyncMock()
    ch._cold_start_recover_single_group = recover_spy  # type: ignore[method-assign]

    await ch._cold_start_scan()

    recover_spy.assert_awaited_once_with("lost-group-1")
    # _known_group_ids should now contain the lost group
    assert "lost-group-1" in ch._known_group_ids


@pytest.mark.asyncio
async def test_cold_start_scan_aborts_when_iter_known_groups_raises(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """If `_iter_known_groups` raises, logs MLS_COLD_START_PERSISTENCE_FAIL
    at ERROR and returns. Must NOT raise to caller."""
    from agentvault_hermes.channel.secure_channel import KnownGroup

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    def broken_iter() -> Iterator[KnownGroup]:
        raise RuntimeError("simulated persistence corruption")
        yield  # unreachable

    ch._iter_known_groups = broken_iter  # type: ignore[method-assign]

    with caplog.at_level(logging.ERROR, logger="agentvault_hermes.channel.secure_channel"):
        await ch._cold_start_scan()  # must NOT raise

    error_records = [
        r for r in caplog.records
        if r.levelno == logging.ERROR
        and "MLS_COLD_START_PERSISTENCE_FAIL" in r.getMessage()
    ]
    assert len(error_records) >= 1


@pytest.mark.asyncio
async def test_cold_start_scan_clears_known_group_ids_on_iter_failure(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """If `_iter_known_groups` raises, `_known_group_ids` is cleared to
    an empty frozenset so a stale set from a previous connect doesn't
    drive admission decisions in `_handle_mls_sync_response`. (DA
    Cluster 3 finding: after Cluster 4 removes the redundant populate
    in `_send_initial_sync`, this is the only protection against
    carrying forward stale group_ids across an iterator-failed
    reconnect.)"""
    from agentvault_hermes.channel.secure_channel import KnownGroup

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    # Pre-seed with a stale snapshot from a "previous connect"
    ch._known_group_ids = frozenset({"stale-group-1", "stale-group-2"})

    def broken_iter() -> Iterator[KnownGroup]:
        raise RuntimeError("simulated persistence corruption")
        yield  # unreachable

    ch._iter_known_groups = broken_iter  # type: ignore[method-assign]

    await ch._cold_start_scan()  # must NOT raise

    # Snapshot must be cleared — stale group_ids would otherwise admit
    # rejoin actions for now-deleted groups (or reject legitimate ones).
    assert ch._known_group_ids == frozenset()


@pytest.mark.asyncio
async def test_cold_start_scan_skips_group_on_recovery_error_logs_warn(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """A per-group recovery failure logs `MLS_COLD_START_FAIL
    step=request_welcome` at WARN and continues to the next group."""
    from agentvault_hermes.channel.secure_channel import KnownGroup

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    def fake_iter() -> Iterator[KnownGroup]:
        for i in range(2):
            yield KnownGroup(
                group_id=f"lost-{i}",
                group_type="1to1",
                last_epoch=None,
                since_ts=None,
                has_local_state=False,
            )
    ch._iter_known_groups = fake_iter  # type: ignore[method-assign]

    call_count = {"n": 0}
    async def flaky_recover(group_id: str) -> None:
        call_count["n"] += 1
        if call_count["n"] == 1:
            raise RuntimeError("simulated network error")
    ch._cold_start_recover_single_group = flaky_recover  # type: ignore[method-assign]

    with caplog.at_level(logging.WARNING, logger="agentvault_hermes.channel.secure_channel"):
        await ch._cold_start_scan()

    warn_records = [
        r for r in caplog.records
        if r.levelno == logging.WARNING
        and "MLS_COLD_START_FAIL" in r.getMessage()
        and "step=request_welcome" in r.getMessage()
    ]
    assert len(warn_records) == 1
    # Second group should have been attempted
    assert call_count["n"] == 2


@pytest.mark.asyncio
async def test_cold_start_scan_aborts_on_consecutive_failures(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """After `_consecutive_failures_threshold` recovery failures in a
    row, the scan aborts with `MLS_COLD_START_ABORT
    reason=consecutive_failures` at ERROR."""
    from agentvault_hermes.channel.secure_channel import KnownGroup

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    def fake_iter() -> Iterator[KnownGroup]:
        for i in range(5):
            yield KnownGroup(
                group_id=f"lost-{i}",
                group_type="1to1",
                last_epoch=None,
                since_ts=None,
                has_local_state=False,
            )
    ch._iter_known_groups = fake_iter  # type: ignore[method-assign]

    call_count = {"n": 0}
    async def always_fail(group_id: str) -> None:
        call_count["n"] += 1
        raise RuntimeError("simulated network error")
    ch._cold_start_recover_single_group = always_fail  # type: ignore[method-assign]

    with caplog.at_level(logging.WARNING, logger="agentvault_hermes.channel.secure_channel"):
        await ch._cold_start_scan()

    # Threshold default 3 → exactly 3 attempts
    assert call_count["n"] == 3
    error_records = [
        r for r in caplog.records
        if r.levelno == logging.ERROR
        and "MLS_COLD_START_ABORT" in r.getMessage()
        and "reason=consecutive_failures" in r.getMessage()
    ]
    assert len(error_records) == 1


@pytest.mark.asyncio
async def test_known_group_ids_populated_by_cold_start_scan_not_send_initial_sync(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """After PR-3: `_known_group_ids` is populated by `_cold_start_scan`,
    not by `_send_initial_sync`. Regression guard for the move from
    Phase B → Phase A so the snapshot covers lost-state groups (which
    `_send_initial_sync` skips per Cluster 2).

    Calls `_cold_start_scan` alone (not via start()); asserts
    `_known_group_ids` is populated. Then runs `_send_initial_sync`
    standalone and asserts `_known_group_ids` is NOT re-populated
    from an inner iterator call.
    """
    from unittest.mock import MagicMock
    from agentvault_hermes.crypto.mls_group import MlsGroupState

    state = MagicMock(spec=MlsGroupState)
    state.epoch = 1
    mls_states["conv-x"] = state

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._conv_to_group_id["conv-x"] = "group-uuid-x"

    # Before either call, _known_group_ids is empty
    assert ch._known_group_ids == frozenset()

    await ch._cold_start_scan()
    assert ch._known_group_ids == frozenset({"group-uuid-x"})

    # Pretend the dict was somehow cleared and verify
    # _send_initial_sync does NOT re-populate it
    ch._known_group_ids = frozenset()
    await ch._send_initial_sync()
    assert ch._known_group_ids == frozenset(), (
        "PR-3 moved the populate to _cold_start_scan; _send_initial_sync "
        "must NOT re-populate"
    )


# ---------------------------------------------------------------------------
# Task 5: SecureChannel owns a RoomDirectory
# ---------------------------------------------------------------------------


def test_secure_channel_has_room_directory(
    relay: FakeRelay,
    mls_states: dict,
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """SecureChannel owns a RoomDirectory, empty on construction."""
    from agentvault_hermes.channel.room_directory import RoomDirectory

    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    assert isinstance(ch._room_directory, RoomDirectory)
    assert ch._room_directory.all() == []


# ---------------------------------------------------------------------------
# Task 6: _handle_room_joined + register room_joined
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_handle_room_joined_populates_directory(
    relay: FakeRelay,
    mls_states: dict,
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """room_joined WS event merges into the RoomDirectory and persists."""
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    env = WireEnvelope(
        event="room_joined",
        data={
            "room_id": "room-7",
            "room_name": "Ops",
            "members": [
                {"device_id": "d-owner", "entity_type": "owner", "display_name": "Chris"},
            ],
            "conversations": [],
        },
    )
    await ch._handle_room_joined(env)
    entry = ch._room_directory.get("room-7")
    assert entry is not None
    assert entry.name == "Ops"
    assert (tmp_path / "rooms.json").exists()


def test_room_joined_is_registered(
    relay: FakeRelay,
    mls_states: dict,
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    assert "room_joined" in ch._event_registry.registered_event_types()


@pytest.mark.asyncio
async def test_handle_room_joined_missing_room_id_is_ignored(
    relay: FakeRelay,
    mls_states: dict,
    on_inbound: AsyncMock,
    tmp_path: Path,
) -> None:
    """A room_joined event with no room_id is ignored — no raise, the
    RoomDirectory stays empty, and nothing is persisted."""
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    env = WireEnvelope(
        event="room_joined",
        data={
            "room_id": "",
            "room_name": "Ops",
            "members": [],
            "conversations": [],
        },
    )
    await ch._handle_room_joined(env)
    assert ch._room_directory.all() == []
    assert not (tmp_path / "rooms.json").exists()


# ---------------------------------------------------------------------------
# Task 7: _dispatch_inbound + room_message_mls registration
# ---------------------------------------------------------------------------


def _inbound(room_id: Optional[str], plaintext: str, sender: str = "d-owner") -> InboundMessage:
    return InboundMessage(
        conversation_id=room_id or "c-1",
        sender_device_id=sender,
        plaintext=plaintext,
        message_type="text",
        is_handshake=False,
        room_id=room_id,
    )


@pytest.mark.asyncio
async def test_dispatch_inbound_1to1_passes_through(
    relay: FakeRelay, mls_states: dict, on_inbound: AsyncMock, tmp_path: Path
) -> None:
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    msg = _inbound(None, "hello")
    await ch._dispatch_inbound(msg)
    on_inbound.assert_awaited_once_with(msg)


@pytest.mark.asyncio
async def test_dispatch_inbound_room_human_gets_attribution(
    relay: FakeRelay, mls_states: dict, on_inbound: AsyncMock, tmp_path: Path
) -> None:
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._room_directory.upsert_from_room_joined({
        "room_id": "room-1", "room_name": "R",
        "members": [{"device_id": "d-owner", "entity_type": "owner", "display_name": "Chris"}],
        "conversations": [],
    })
    await ch._dispatch_inbound(_inbound("room-1", "ship it", sender="d-owner"))
    on_inbound.assert_awaited_once()
    dispatched = on_inbound.await_args.args[0]
    assert dispatched.plaintext == "[Chris]: ship it"


@pytest.mark.asyncio
async def test_dispatch_inbound_room_agent_no_mention_is_dropped(
    relay: FakeRelay, mls_states: dict, on_inbound: AsyncMock, tmp_path: Path
) -> None:
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._room_directory.upsert_from_room_joined({
        "room_id": "room-1", "room_name": "R",
        "members": [{"device_id": "d-bot", "entity_type": "agent", "display_name": "OtherBot"}],
        "conversations": [],
    })
    # Agent sender, no @mention -> loop guard -> not dispatched.
    await ch._dispatch_inbound(_inbound("room-1", "just chatter", sender="d-bot"))
    on_inbound.assert_not_awaited()


@pytest.mark.asyncio
async def test_dispatch_inbound_room_unknown_sender_treated_as_human(
    relay: FakeRelay, mls_states: dict, on_inbound: AsyncMock, tmp_path: Path
) -> None:
    """When the room is not yet in the directory (a room Welcome arrived
    before room_joined / the poll reconciled), _dispatch_inbound falls back
    to treating the sender as a human: the message IS surfaced (not silently
    dropped) and carries the ``[Unknown]: `` attribution prefix."""
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    # Deliberately do NOT populate _room_directory for "room-unknown" —
    # _room_directory.get("room-unknown") returns None.
    await ch._dispatch_inbound(_inbound("room-unknown", "anyone there"))
    on_inbound.assert_awaited_once()
    dispatched = on_inbound.await_args.args[0]
    assert dispatched.plaintext == "[Unknown]: anyone there"


def test_room_message_mls_is_registered(
    relay: FakeRelay, mls_states: dict, on_inbound: AsyncMock, tmp_path: Path
) -> None:
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    assert "room_message_mls" in ch._event_registry.registered_event_types()


# ---------------------------------------------------------------------------
# Task 8 / Task 9 helpers — MLS-state doubles that return a fixed DecryptResult.
# ---------------------------------------------------------------------------


def _make_initialized_state_returning(plaintext: bytes) -> MagicMock:
    """Return an MLS-state mock whose decrypt() returns an application result
    (plaintext=<plaintext>, is_handshake=False) — used by Task 9 room tests."""
    from agentvault_hermes.crypto.mls_group import DecryptResult

    state = MagicMock(name="MlsState")
    state.is_initialized = True
    state.epoch = 0
    state.decrypt.return_value = DecryptResult(plaintext=plaintext, is_handshake=False)
    state.export_state.return_value = b"exported"
    return state


def _make_initialized_state_returning_handshake() -> MagicMock:
    """Return an MLS-state mock whose decrypt() returns a handshake result
    (plaintext=None, is_handshake=True) — mimics a commit row."""
    from agentvault_hermes.crypto.mls_group import DecryptResult

    state = MagicMock(name="MlsState")
    state.is_initialized = True
    state.epoch = 5
    state.decrypt.return_value = DecryptResult(plaintext=None, is_handshake=True)
    state.export_state.return_value = b"exported"
    return state


# ---------------------------------------------------------------------------
# Task 8: _pull_delivery_queue — commit rows decrypted, not dropped
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_pull_delivery_commit_row_advances_epoch_not_dropped(
    relay: FakeRelay, on_inbound: AsyncMock, tmp_path: Path
) -> None:
    """A 'commit' delivery-queue row is decrypted (epoch advanced + state
    persisted) and NOT dispatched — no longer ack-dropped."""
    room_id = "room-commit-1"
    state = _make_initialized_state_returning_handshake()  # decrypt -> is_handshake=True
    mls_states = {room_id: state}
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    # Restore the real _pull_delivery_queue (the factory patched it to no-op).
    ch._pull_delivery_queue = SecureChannel._pull_delivery_queue.__get__(ch)

    import respx
    from httpx import Response

    with respx.mock(base_url=relay.rest_base_url, assert_all_called=False) as mock:
        mock.get("/api/v1/mls/delivery").mock(return_value=Response(200, json={
            "messages": [{
                "queue_id": "q-commit-1",
                "message_id": "m-commit-1",
                "message_type": "commit",
                "group_id": "g-1",
                "room_id": room_id,
                "sender_device_id": "other-device",
                "epoch": 4,
                "payload": "00",
                "created_at": "2026-05-21T00:00:00Z",
            }],
        }))
        ack = mock.post("/api/v1/mls/delivery/ack").mock(return_value=Response(200, json={"acked": 1}))
        ch._initial_setup_complete.set()
        await ch._pull_delivery_queue()

    state.decrypt.assert_called_once()  # commit was decrypted, not dropped
    on_inbound.assert_not_awaited()     # handshake -> not surfaced
    assert ack.called


@pytest.mark.asyncio
async def test_pull_delivery_orphan_commit_row_acked_not_crashed(
    relay: FakeRelay, on_inbound: AsyncMock, tmp_path: Path
) -> None:
    """A 'commit' row whose group is NOT in mls_states degrades gracefully:
    handle_message_mls -> _resolve_state returns (None, None) -> logs
    'no MLS group' + returns None. The pull must NOT raise, nothing is
    surfaced, and the row is still acked (not dead-lettered)."""
    # No MLS state for the commit row's group_id / room_id.
    mls_states: dict = {}
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)

    # Restore the real _pull_delivery_queue (the factory patched it to no-op).
    ch._pull_delivery_queue = SecureChannel._pull_delivery_queue.__get__(ch)

    import respx
    from httpx import Response

    with respx.mock(base_url=relay.rest_base_url, assert_all_called=False) as mock:
        mock.get("/api/v1/mls/delivery").mock(return_value=Response(200, json={
            "messages": [{
                "queue_id": "q-orphan-1",
                "message_id": "m-orphan-1",
                "message_type": "commit",
                "group_id": "g-orphan",
                "room_id": "room-orphan-1",
                "sender_device_id": "other-device",
                "epoch": 4,
                "payload": "00",
                "created_at": "2026-05-21T00:00:00Z",
            }],
        }))
        ack = mock.post("/api/v1/mls/delivery/ack").mock(return_value=Response(200, json={"acked": 1}))
        ch._initial_setup_complete.set()
        # Must not raise — orphan commit degrades gracefully.
        await ch._pull_delivery_queue()

    on_inbound.assert_not_awaited()  # no MLS group -> nothing surfaced
    assert ack.called
    ack_body = ack.calls.last.request.content.decode()
    assert "q-orphan-1" in ack_body  # row still acked, not dead-lettered


# ---------------------------------------------------------------------------
# Task 10: _poll_rooms — connect-time room directory reconcile
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_poll_rooms_reconciles_directory(
    relay: FakeRelay, mls_states: dict, on_inbound: AsyncMock, tmp_path: Path
) -> None:
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    # Restore the real _poll_rooms (the factory patched it to no-op).
    ch._poll_rooms = SecureChannel._poll_rooms.__get__(ch)  # type: ignore[method-assign]
    import respx
    from httpx import Response

    with respx.mock(base_url=relay.rest_base_url, assert_all_called=False) as mock:
        mock.get("/api/v1/rooms").mock(return_value=Response(200, json=[
            {"id": "room-polled-1", "name": "Polled", "status": "active",
             "created_at": None, "member_count": 1,
             "members": [{"device_id": "d-1", "entity_type": "owner", "display_name": "Chris"}]},
        ]))
        await ch._poll_rooms()

    entry = ch._room_directory.get("room-polled-1")
    assert entry is not None
    assert entry.name == "Polled"


@pytest.mark.asyncio
async def test_poll_rooms_failure_is_best_effort(
    relay: FakeRelay, mls_states: dict, on_inbound: AsyncMock, tmp_path: Path
) -> None:
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    # Restore the real _poll_rooms (the factory patched it to no-op).
    ch._poll_rooms = SecureChannel._poll_rooms.__get__(ch)  # type: ignore[method-assign]
    import respx
    from httpx import Response

    with respx.mock(base_url=relay.rest_base_url, assert_all_called=False) as mock:
        mock.get("/api/v1/rooms").mock(return_value=Response(500, json={"detail": "boom"}))
        await ch._poll_rooms()  # must not raise

    assert ch._room_directory.all() == []


# ---------------------------------------------------------------------------
# Task 11: SecureChannel.send — room-aware
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_send_to_room_emits_room_envelope(
    relay: FakeRelay, on_inbound: AsyncMock, tmp_path: Path
) -> None:
    """A send to a room conversation passes room_id to relay.send_message."""
    room_id = "room-send-1"
    state = FakeMlsState()
    mls_states = {room_id: state}
    ch = _make_channel(relay, mls_states, on_inbound, tmp_path)
    ch._room_directory.record_welcome(room_id, "group-send-1")
    ch._conv_to_group_id[room_id] = "group-send-1"

    await ch.send(conversation_id=room_id, plaintext=b"reply text")

    relay.send_message.assert_awaited_once()
    assert relay.send_message.await_args.kwargs["room_id"] == room_id


@pytest.mark.asyncio
async def test_send_to_1to1_passes_room_id_none(
    relay: FakeRelay, on_inbound: AsyncMock, tmp_path: Path
) -> None:
    conv_id = "conv-send-1"
    state = FakeMlsState()
    ch = _make_channel(relay, {conv_id: state}, on_inbound, tmp_path)
    ch._conv_to_group_id[conv_id] = "group-1to1"

    await ch.send(conversation_id=conv_id, plaintext=b"hi")

    assert relay.send_message.await_args.kwargs["room_id"] is None


def _channel_with_loop_preventer(
    relay: FakeRelay,
    mls_states: dict[str, Any],
    on_inbound: AsyncMock,
    tmp_path: Path,
    loop_preventer: Any,
) -> SecureChannel:
    """Build a SecureChannel with an injected loop_preventer.

    ``_make_channel`` does not expose the ``loop_preventer`` constructor
    param, so the counter-routing tests build the channel directly. ``send``
    touches none of the start()-time methods ``_make_channel`` patches, so
    only the constructor is needed.
    """
    return SecureChannel(
        relay=relay,  # type: ignore[arg-type]
        mls_states=mls_states,
        on_inbound=on_inbound,
        data_dir=tmp_path,
        device_keys=_fake_signing_keypair(),
        device_id=_FAKE_DEVICE_ID,
        agent_name="hermes-test",
        account_id="acct-test",
        loop_preventer=loop_preventer,
    )


@pytest.mark.asyncio
async def test_send_to_room_uses_room_scoped_loop_counters(
    relay: FakeRelay, on_inbound: AsyncMock, tmp_path: Path
) -> None:
    """A room send drives the room-scoped loop-prevention counters and
    NEVER the 1:1 counters — locks the room/1:1 symmetry against a
    silent regression that left ``record_reply(conversation_id)`` in the
    ``is_room`` branch."""
    from agentvault_hermes.channel.loop_prevention import LoopPreventer

    room_id = "room-send-lp-1"
    lp = create_autospec(LoopPreventer, instance=True)
    lp.can_reply_room.return_value = True
    lp.can_reply.return_value = True

    state = FakeMlsState()
    ch = _channel_with_loop_preventer(relay, {room_id: state}, on_inbound, tmp_path, lp)
    ch._room_directory.record_welcome(room_id, "group-send-lp-1")
    ch._conv_to_group_id[room_id] = "group-send-lp-1"

    await ch.send(conversation_id=room_id, plaintext=b"reply text")

    lp.can_reply_room.assert_called_once_with(room_id)
    lp.record_reply_room.assert_called_once_with(room_id)
    lp.can_reply.assert_not_called()
    lp.record_reply.assert_not_called()


@pytest.mark.asyncio
async def test_send_to_1to1_uses_1to1_loop_counters(
    relay: FakeRelay, on_inbound: AsyncMock, tmp_path: Path
) -> None:
    """A 1:1 send drives the 1:1 loop-prevention counters and NEVER the
    room-scoped counters — the inverse of the room test."""
    from agentvault_hermes.channel.loop_prevention import LoopPreventer

    conv_id = "conv-send-lp-1"
    lp = create_autospec(LoopPreventer, instance=True)
    lp.can_reply_room.return_value = True
    lp.can_reply.return_value = True

    state = FakeMlsState()
    ch = _channel_with_loop_preventer(relay, {conv_id: state}, on_inbound, tmp_path, lp)
    ch._conv_to_group_id[conv_id] = "group-1to1-lp"

    await ch.send(conversation_id=conv_id, plaintext=b"hi")

    lp.can_reply.assert_called_once_with(conv_id)
    lp.record_reply.assert_called_once_with(conv_id)
    lp.can_reply_room.assert_not_called()
    lp.record_reply_room.assert_not_called()
