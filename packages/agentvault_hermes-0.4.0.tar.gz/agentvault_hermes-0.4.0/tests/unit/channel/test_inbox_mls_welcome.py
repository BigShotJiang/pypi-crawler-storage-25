"""Stage-4-scoped unit tests for ``inbox.handle_mls_welcome``.

Plan: ``docs/plans/2026-05-10-hermes-phase3-welcome-support-implementation.md``
§3.4 (handle_mls_welcome flow) + §5.4 (test list).

Covers:

- Happy path: in-memory bundle → join_from_welcome → mls_states populated
  → persist callback awaited → clear_pending_kp_state callback fired →
  WelcomeOutcome(joined=True).
- P6 idempotency: already-initialized state still gets ack (drop=True).
- P7 ack-not-nack on join_from_welcome raise.
- P7 + P14 MLS_WELCOME_PERMANENT_FAILURE marker on generic exception.
- Own-echo filter (sender == own).
- A2A routing → drop=True (A2A is a separate phase).
- Room routing → joins (action #234).
- No pending_kp_state → ack-and-log (KP lost across restart).
- Invalid hex payload → ack+drop.
- conv_to_group_id mismatch → log warn + ack+drop without overwrite.
- conv_to_group_id match (re-join same group) → no-op write, proceed.
- Per-conv lock held through persist callback (P8).
- Handler signature does NOT take ensure_pending_key_package (P16 — caller
  handles republish scheduling).
"""
from __future__ import annotations

import asyncio
import inspect
import logging
from typing import Any, Optional
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID

import pytest

from agentvault_hermes.channel.inbox import WelcomeOutcome, handle_mls_welcome
from agentvault_hermes.channel.outbox import WireEnvelope
from agentvault_hermes.crypto.mls_group import MlsGroupAlreadyInitializedError


_OWN_DEVICE_ID = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
_OTHER_DEVICE_ID = "bbbbbbbb-cccc-dddd-eeee-ffffffffffff"
_CONV_ID = "22222222-2222-2222-2222-222222222222"
_GROUP_UUID = UUID("01234567-89ab-cdef-0123-456789abcdef")
_GROUP_ID_BYTES = _GROUP_UUID.bytes
_GROUP_ID_STR = str(_GROUP_UUID)


def _welcome_envelope(
    *,
    sender_device_id: str = _OTHER_DEVICE_ID,
    conversation_id: Optional[str] = _CONV_ID,
    conversation_group_id: Optional[str] = None,
    room_id: Optional[str] = None,
    a2a_channel_id: Optional[str] = None,
    payload: str = "deadbeef",
    group_id: str = _GROUP_ID_STR,
) -> WireEnvelope:
    return WireEnvelope(
        event="message_mls",
        data={
            "queue_id": "q-welcome-1",
            "message_id": "m1",
            "group_id": group_id,
            "message_type": "welcome",
            "sender_device_id": sender_device_id,
            "epoch": 0,
            "payload": payload,
            "room_id": room_id,
            "conversation_id": conversation_id,
            "a2a_channel_id": a2a_channel_id,
            "conversation_group_id": conversation_group_id,
            "created_at": "2026-05-10T00:00:00Z",
        },
    )


def _make_pending_kp_state(
    *,
    join_side_effect: Any = None,
    is_initialized_after_join: bool = True,
    group_id_bytes: bytes = _GROUP_ID_BYTES,
) -> MagicMock:
    """Stand-in for ``MlsGroupState``.

    ``is_initialized`` flips True after ``join_from_welcome`` is called
    (mirrors the real wrapper's behavior). ``group_id`` is the post-join
    bytes form. ``join_side_effect`` lets a test inject a raise.
    """
    state = MagicMock(name="PendingKpState")
    state.is_initialized = False
    state.group_id = group_id_bytes

    def _join(welcome_bytes: bytes) -> None:
        if join_side_effect is not None:
            if isinstance(join_side_effect, Exception):
                raise join_side_effect
            raise join_side_effect()
        state.is_initialized = is_initialized_after_join

    state.join_from_welcome.side_effect = _join
    return state


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


async def test_happy_path_inmemory_bundle() -> None:
    """Welcome with in-memory bundle → join, persist, clear, joined=True."""
    pending = _make_pending_kp_state()
    mls_states: dict[str, Any] = {}
    conv_to_group_id: dict[str, str] = {}
    send_locks: dict[str, asyncio.Lock] = {}
    persist_state = AsyncMock()
    clear_kp = MagicMock()

    outcome = await handle_mls_welcome(
        envelope=_welcome_envelope(),
        mls_states=mls_states,
        pending_kp_state=pending,
        own_device_id=_OWN_DEVICE_ID,
        conv_to_group_id=conv_to_group_id,
        send_locks=send_locks,
        persist_state=persist_state,
        clear_pending_kp_state=clear_kp,
    )

    assert outcome.joined is True
    assert outcome.drop is False
    assert outcome.routing_key == _CONV_ID
    pending.join_from_welcome.assert_called_once()
    assert mls_states[_CONV_ID] is pending
    assert conv_to_group_id[_CONV_ID] == _GROUP_ID_STR
    persist_state.assert_awaited_once()
    args, _ = persist_state.call_args
    assert args == (_CONV_ID, pending)
    clear_kp.assert_called_once()


async def test_happy_path_uses_conversation_group_id_when_present() -> None:
    """conversation_group_id takes precedence over conversation_id (shared
    1:1 group post-PR-X)."""
    pending = _make_pending_kp_state()
    mls_states: dict[str, Any] = {}
    persist_state = AsyncMock()
    clear_kp = MagicMock()

    outcome = await handle_mls_welcome(
        envelope=_welcome_envelope(
            conversation_id=_CONV_ID,
            conversation_group_id="33333333-3333-3333-3333-333333333333",
        ),
        mls_states=mls_states,
        pending_kp_state=pending,
        own_device_id=_OWN_DEVICE_ID,
        conv_to_group_id={},
        send_locks={},
        persist_state=persist_state,
        clear_pending_kp_state=clear_kp,
    )

    assert outcome.routing_key == "33333333-3333-3333-3333-333333333333"
    assert "33333333-3333-3333-3333-333333333333" in mls_states
    assert _CONV_ID not in mls_states


# ---------------------------------------------------------------------------
# Filters
# ---------------------------------------------------------------------------


async def test_own_echo_filtered() -> None:
    pending = _make_pending_kp_state()
    persist_state = AsyncMock()
    clear_kp = MagicMock()

    outcome = await handle_mls_welcome(
        envelope=_welcome_envelope(sender_device_id=_OWN_DEVICE_ID),
        mls_states={},
        pending_kp_state=pending,
        own_device_id=_OWN_DEVICE_ID,
        conv_to_group_id={},
        send_locks={},
        persist_state=persist_state,
        clear_pending_kp_state=clear_kp,
    )

    assert outcome.joined is False
    assert outcome.drop is True
    pending.join_from_welcome.assert_not_called()
    persist_state.assert_not_awaited()
    clear_kp.assert_not_called()


async def test_room_welcome_accepted() -> None:
    """A Welcome carrying room_id is joined (no longer dropped). The MLS
    state is keyed by room_id. Mirrors test_happy_path_inmemory_bundle's
    join post-conditions for the room path."""
    pending = _make_pending_kp_state()
    mls_states: dict[str, Any] = {}
    conv_to_group_id: dict[str, str] = {}
    persist_state = AsyncMock()
    clear_kp = MagicMock()

    outcome = await handle_mls_welcome(
        envelope=_welcome_envelope(room_id="room-1", conversation_id=None),
        mls_states=mls_states,
        pending_kp_state=pending,
        own_device_id=_OWN_DEVICE_ID,
        conv_to_group_id=conv_to_group_id,
        send_locks={},
        persist_state=persist_state,
        clear_pending_kp_state=clear_kp,
    )

    assert outcome.joined is True
    assert outcome.drop is False
    assert outcome.routing_key == "room-1"
    pending.join_from_welcome.assert_called_once()
    assert mls_states["room-1"] is pending
    assert conv_to_group_id["room-1"] == _GROUP_ID_STR
    persist_state.assert_awaited_once()
    args, _ = persist_state.call_args
    assert args == ("room-1", pending)
    clear_kp.assert_called_once()


async def test_a2a_routing_joins_by_a2a_channel_id() -> None:
    """action #238: an A2A Welcome is no longer drop-guarded; it joins via
    the same path rooms / 1:1 use, keyed by a2a_channel_id."""
    pending = _make_pending_kp_state()
    mls_states: dict[str, Any] = {}
    outcome = await handle_mls_welcome(
        envelope=_welcome_envelope(
            a2a_channel_id="a2a-1", conversation_id=None
        ),
        mls_states=mls_states,
        pending_kp_state=pending,
        own_device_id=_OWN_DEVICE_ID,
        conv_to_group_id={},
        send_locks={},
        persist_state=AsyncMock(),
        clear_pending_kp_state=MagicMock(),
    )
    assert outcome.joined is True
    assert outcome.drop is False
    assert outcome.routing_key == "a2a-1"
    pending.join_from_welcome.assert_called_once()
    assert mls_states["a2a-1"] is pending


async def test_no_routing_key_logs_and_drops(caplog: pytest.LogCaptureFixture) -> None:
    pending = _make_pending_kp_state()
    with caplog.at_level(logging.WARNING, logger="agentvault_hermes.channel.inbox"):
        outcome = await handle_mls_welcome(
            envelope=_welcome_envelope(
                conversation_id=None, conversation_group_id=None
            ),
            mls_states={},
            pending_kp_state=pending,
            own_device_id=_OWN_DEVICE_ID,
            conv_to_group_id={},
            send_locks={},
            persist_state=AsyncMock(),
            clear_pending_kp_state=MagicMock(),
        )
    assert outcome.drop is True
    assert outcome.joined is False
    pending.join_from_welcome.assert_not_called()
    assert any(
        "no a2a_channel_id or room_id or conversation_group_id or "
        "conversation_id" in r.message
        for r in caplog.records
    )


# ---------------------------------------------------------------------------
# Idempotency (P6)
# ---------------------------------------------------------------------------


async def test_idempotent_welcome_still_acks() -> None:
    """P6: a duplicate Welcome (state already initialized for this routing
    key) returns drop=True so the caller acks. Without this, a re-delivered
    Welcome row recycles forever."""
    existing_state = MagicMock()
    existing_state.is_initialized = True
    pending = _make_pending_kp_state()
    persist_state = AsyncMock()
    clear_kp = MagicMock()

    outcome = await handle_mls_welcome(
        envelope=_welcome_envelope(),
        mls_states={_CONV_ID: existing_state},
        pending_kp_state=pending,
        own_device_id=_OWN_DEVICE_ID,
        conv_to_group_id={},
        send_locks={},
        persist_state=persist_state,
        clear_pending_kp_state=clear_kp,
    )

    assert outcome == WelcomeOutcome(joined=False, drop=True, routing_key=_CONV_ID)
    pending.join_from_welcome.assert_not_called()
    persist_state.assert_not_awaited()
    clear_kp.assert_not_called()


# ---------------------------------------------------------------------------
# No bundle / payload errors
# ---------------------------------------------------------------------------


async def test_no_bundle_logs_permanent_failure_and_drops(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """pending_kp_state=None → P14 MLS_WELCOME_PERMANENT_FAILURE marker
    + ack-and-drop. Defends against the cross-restart KP-loss case."""
    with caplog.at_level(logging.ERROR, logger="agentvault_hermes.channel.inbox"):
        outcome = await handle_mls_welcome(
            envelope=_welcome_envelope(),
            mls_states={},
            pending_kp_state=None,
            own_device_id=_OWN_DEVICE_ID,
            conv_to_group_id={},
            send_locks={},
            persist_state=AsyncMock(),
            clear_pending_kp_state=MagicMock(),
        )
    assert outcome.drop is True
    assert outcome.joined is False
    assert any(
        "MLS_WELCOME_PERMANENT_FAILURE" in r.message for r in caplog.records
    )


async def test_invalid_hex_payload_drops(caplog: pytest.LogCaptureFixture) -> None:
    pending = _make_pending_kp_state()
    with caplog.at_level(logging.WARNING, logger="agentvault_hermes.channel.inbox"):
        outcome = await handle_mls_welcome(
            envelope=_welcome_envelope(payload="not-hex-zz"),
            mls_states={},
            pending_kp_state=pending,
            own_device_id=_OWN_DEVICE_ID,
            conv_to_group_id={},
            send_locks={},
            persist_state=AsyncMock(),
            clear_pending_kp_state=MagicMock(),
        )
    assert outcome.drop is True
    assert outcome.joined is False
    pending.join_from_welcome.assert_not_called()
    assert any("invalid hex payload" in r.message for r in caplog.records)


async def test_empty_payload_drops() -> None:
    pending = _make_pending_kp_state()
    outcome = await handle_mls_welcome(
        envelope=_welcome_envelope(payload=""),
        mls_states={},
        pending_kp_state=pending,
        own_device_id=_OWN_DEVICE_ID,
        conv_to_group_id={},
        send_locks={},
        persist_state=AsyncMock(),
        clear_pending_kp_state=MagicMock(),
    )
    assert outcome.drop is True
    pending.join_from_welcome.assert_not_called()


# ---------------------------------------------------------------------------
# join_from_welcome exceptions (P7 + P14)
# ---------------------------------------------------------------------------


async def test_already_initialized_acks_and_drops(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """MlsGroupAlreadyInitializedError → DEBUG log + ack+drop (no
    PERMANENT_FAILURE marker because this is concurrent-join, not a
    permanent error)."""
    pending = _make_pending_kp_state(
        join_side_effect=MlsGroupAlreadyInitializedError("dup")
    )
    with caplog.at_level(logging.ERROR, logger="agentvault_hermes.channel.inbox"):
        outcome = await handle_mls_welcome(
            envelope=_welcome_envelope(),
            mls_states={},
            pending_kp_state=pending,
            own_device_id=_OWN_DEVICE_ID,
            conv_to_group_id={},
            send_locks={},
            persist_state=AsyncMock(),
            clear_pending_kp_state=MagicMock(),
        )
    assert outcome.drop is True
    assert outcome.joined is False
    # NO permanent-failure marker for this benign duplicate.
    assert not any(
        "MLS_WELCOME_PERMANENT_FAILURE" in r.message for r in caplog.records
    )


async def test_join_failure_acks_not_nacks(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """P7: a generic decrypt failure during join → ack-not-nack with
    PERMANENT_FAILURE marker. 5 nacks would dead-letter; the row is lost
    regardless, so don't amplify load."""
    pending = _make_pending_kp_state(
        join_side_effect=RuntimeError("decrypt failed")
    )
    with caplog.at_level(logging.ERROR, logger="agentvault_hermes.channel.inbox"):
        outcome = await handle_mls_welcome(
            envelope=_welcome_envelope(),
            mls_states={},
            pending_kp_state=pending,
            own_device_id=_OWN_DEVICE_ID,
            conv_to_group_id={},
            send_locks={},
            persist_state=AsyncMock(),
            clear_pending_kp_state=MagicMock(),
        )
    assert outcome.drop is True
    assert outcome.joined is False


async def test_join_failure_logs_permanent_failure_marker(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """P14: the literal substring ``MLS_WELCOME_PERMANENT_FAILURE`` is
    grep-able in the ERROR log. Operator-visibility contract — Phase 4
    will replace with structured telemetry per action_item #157."""
    pending = _make_pending_kp_state(
        join_side_effect=RuntimeError("decrypt failed")
    )
    with caplog.at_level(logging.ERROR, logger="agentvault_hermes.channel.inbox"):
        await handle_mls_welcome(
            envelope=_welcome_envelope(),
            mls_states={},
            pending_kp_state=pending,
            own_device_id=_OWN_DEVICE_ID,
            conv_to_group_id={},
            send_locks={},
            persist_state=AsyncMock(),
            clear_pending_kp_state=MagicMock(),
        )

    relevant = [
        r for r in caplog.records
        if "MLS_WELCOME_PERMANENT_FAILURE" in r.message
    ]
    assert relevant, "PERMANENT_FAILURE marker missing from ERROR log"
    msg = relevant[0].message
    # Structured fields per plan §3.4 step 9.
    assert "exc_type=RuntimeError" in msg
    assert f"group_id={_GROUP_ID_STR[:8]}" in msg
    assert f"routing_key={_CONV_ID[:8]}" in msg
    assert "decrypt failed" in msg


# ---------------------------------------------------------------------------
# conv_to_group_id consistency (P9)
# ---------------------------------------------------------------------------


async def test_conv_to_group_id_mismatch_aborts_join(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """P9: pre-existing conv_to_group_id with a DIFFERENT group_id → log
    WARN + ack+drop without overwrite. We have no recovery path for
    re-keyed groups in Phase 3."""
    pending = _make_pending_kp_state()
    persist_state = AsyncMock()
    clear_kp = MagicMock()
    other_group_str = "ffffffff-ffff-ffff-ffff-ffffffffffff"
    conv_to_group = {_CONV_ID: other_group_str}

    with caplog.at_level(logging.WARNING, logger="agentvault_hermes.channel.inbox"):
        outcome = await handle_mls_welcome(
            envelope=_welcome_envelope(),
            mls_states={},
            pending_kp_state=pending,
            own_device_id=_OWN_DEVICE_ID,
            conv_to_group_id=conv_to_group,
            send_locks={},
            persist_state=persist_state,
            clear_pending_kp_state=clear_kp,
        )

    assert outcome.drop is True
    assert outcome.joined is False
    # NOT overwritten.
    assert conv_to_group[_CONV_ID] == other_group_str
    persist_state.assert_not_awaited()
    clear_kp.assert_not_called()
    assert any(
        "conv_to_group_id mismatch" in r.message for r in caplog.records
    )


async def test_conv_to_group_id_match_is_noop() -> None:
    """P9: pre-existing conv_to_group_id with the SAME group_id → no-op
    write (re-join of the same group). Defensive but should not fire
    post-step-5 idempotency."""
    pending = _make_pending_kp_state()
    persist_state = AsyncMock()
    clear_kp = MagicMock()
    # Pre-populate the SAME group_id_str the join will produce.
    conv_to_group = {_CONV_ID: _GROUP_ID_STR}

    outcome = await handle_mls_welcome(
        envelope=_welcome_envelope(),
        mls_states={},
        pending_kp_state=pending,
        own_device_id=_OWN_DEVICE_ID,
        conv_to_group_id=conv_to_group,
        send_locks={},
        persist_state=persist_state,
        clear_pending_kp_state=clear_kp,
    )

    assert outcome.joined is True
    assert conv_to_group[_CONV_ID] == _GROUP_ID_STR
    persist_state.assert_awaited_once()
    clear_kp.assert_called_once()


# ---------------------------------------------------------------------------
# Per-conv lock invariant (P8)
# ---------------------------------------------------------------------------


async def test_welcome_holds_per_conv_lock_through_persist() -> None:
    """P8 + P25: handler acquires send_locks[routing_key] BEFORE the first
    mls_states mutation and holds it THROUGH persist_state callback
    completion + clear_pending_kp_state.

    Concurrent decrypt-during-Welcome race is action_item #156
    (handle_message_mls lock-acquisition fix); this test only verifies
    the Welcome-side lock invariant in isolation. We do NOT call
    handle_message_mls here — that would surface the unfixed race as a
    test flake and is out of scope for this PR.
    """
    pending = _make_pending_kp_state()
    send_locks: dict[str, asyncio.Lock] = {}

    persist_observed_lock_held = asyncio.Event()
    persist_proceed = asyncio.Event()

    async def slow_persist(conv_id: str, state: Any) -> None:
        # By the time persist runs, the handler must hold the lock.
        lock = send_locks[_CONV_ID]
        assert lock.locked(), "send_locks[key] must be held during persist"
        persist_observed_lock_held.set()
        await persist_proceed.wait()

    handler_task = asyncio.create_task(
        handle_mls_welcome(
            envelope=_welcome_envelope(),
            mls_states={},
            pending_kp_state=pending,
            own_device_id=_OWN_DEVICE_ID,
            conv_to_group_id={},
            send_locks=send_locks,
            persist_state=slow_persist,
            clear_pending_kp_state=MagicMock(),
        )
    )

    # Wait until persist starts; lock should now be held.
    await asyncio.wait_for(persist_observed_lock_held.wait(), timeout=2.0)

    # Probe: try acquiring with a tiny timeout — must time out (lock IS held).
    lock = send_locks[_CONV_ID]
    with pytest.raises(asyncio.TimeoutError):
        await asyncio.wait_for(lock.acquire(), timeout=0.05)

    # Release persist — handler completes, lock should be released.
    persist_proceed.set()
    outcome = await handler_task
    assert outcome.joined is True
    assert not lock.locked()


# ---------------------------------------------------------------------------
# P16: caller, not handler, schedules republish
# ---------------------------------------------------------------------------


def test_handler_does_not_call_ensure_pending_key_package_directly() -> None:
    """P16: the handler signature does NOT take an
    ``ensure_pending_key_package`` callback. The caller
    (_pull_delivery_queue) reads WelcomeOutcome.joined and schedules
    fire-and-forget republish. Lock-ordering invariant P24 depends on
    this — see docstring on _pull_delivery_queue."""
    sig = inspect.signature(handle_mls_welcome)
    param_names = set(sig.parameters)
    assert "ensure_pending_key_package" not in param_names, (
        "handle_mls_welcome must not take ensure_pending_key_package — "
        "the caller schedules fire-and-forget republish per P16+P24"
    )
    # Accept exactly the documented set (give-or-take).
    expected_subset = {
        "envelope",
        "mls_states",
        "pending_kp_state",
        "own_device_id",
        "conv_to_group_id",
        "send_locks",
        "persist_state",
        "clear_pending_kp_state",
    }
    assert expected_subset.issubset(param_names), (
        f"handle_mls_welcome signature drift: missing {expected_subset - param_names}"
    )


__all__: list[str] = []
