"""Unit tests for ``agentvault_hermes.channel.outbox``.

Verifies the outbound ``message_mls`` envelope is byte-shape-identical to
the OC TypeScript producer at ``packages/plugin/src/channel.ts:665-689``
and that the AV backend reader at ``packages/backend/app/api/v1/ws.py:1063-1082``
will accept the result.

Plan reference: §4.2 + §13.4 of
``docs/plans/2026-05-10-hermes-phase3-implementation.md``.
"""
from __future__ import annotations

import json

import pytest

from agentvault_hermes.channel.outbox import (
    WireEnvelope,
    make_outbound_mls_envelope,
)


# ---------------------------------------------------------------------------
# Constructor: minimal-args envelope
# ---------------------------------------------------------------------------


def test_minimal_envelope_event_is_message_mls() -> None:
    env = make_outbound_mls_envelope(
        conversation_id="conv-1",
        group_id="grp-1",
        epoch=0,
        ciphertext=b"\x00\x01\x02",
    )
    assert env.event == "message_mls"


def test_required_fields_always_present() -> None:
    """`group_id` and `epoch` MUST be in `data` — backend rejects messages
    missing either (`ws.py:1067`)."""
    env = make_outbound_mls_envelope(
        conversation_id="conv-1",
        group_id="grp-1",
        epoch=42,
        ciphertext=b"hello",
    )
    assert "conversation_id" in env.data
    assert "group_id" in env.data
    assert "epoch" in env.data
    assert "payload" in env.data
    assert "message_type" in env.data
    assert env.data["conversation_id"] == "conv-1"
    assert env.data["group_id"] == "grp-1"
    assert env.data["epoch"] == 42
    assert env.data["message_type"] == "text"


def test_no_sender_device_id() -> None:
    """`sender_device_id` is NEVER on outbound MLS — backend stamps it from
    the authenticated session per `ws.py:1063-1082`."""
    env = make_outbound_mls_envelope(
        conversation_id="conv-1",
        group_id="grp-1",
        epoch=1,
        ciphertext=b"x",
    )
    assert "sender_device_id" not in env.data


# ---------------------------------------------------------------------------
# Payload encoding: hex, NOT base64
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "ciphertext",
    [
        b"",
        b"\x00",
        b"\xff",
        b"hello world",
        b"\x00\x01\x02\x03\x04\x05",
        bytes(range(256)),  # full byte range
    ],
)
def test_payload_is_hex_encoded(ciphertext: bytes) -> None:
    """`payload` is `ciphertext.hex()` per OC `channel.ts:669`. Backend
    decodes via `bytes.fromhex` per `ws.py:1076`."""
    env = make_outbound_mls_envelope(
        conversation_id="c",
        group_id="g",
        epoch=0,
        ciphertext=ciphertext,
    )
    payload_field = env.data["payload"]
    assert isinstance(payload_field, str)
    # Lowercase per Python `bytes.hex()` contract.
    assert payload_field == ciphertext.hex()
    assert payload_field == payload_field.lower()
    # Round-trip via the same decoder the backend uses.
    assert bytes.fromhex(payload_field) == ciphertext


def test_payload_is_not_base64() -> None:
    """Regression guard against the spike's broken FakeWire shape."""
    env = make_outbound_mls_envelope(
        conversation_id="c",
        group_id="g",
        epoch=0,
        ciphertext=b"\xde\xad\xbe\xef",
    )
    # base64 of \xde\xad\xbe\xef would be '3q2+7w==' — make sure that's not
    # what we're emitting.
    assert env.data["payload"] == "deadbeef"
    assert "==" not in env.data["payload"]


def test_hex_round_trip_with_full_byte_range() -> None:
    """`bytes.fromhex(env.data["payload"]) == ciphertext` for all 256 byte
    values — closes the §13.4 edge case."""
    ct = bytes(range(256))
    env = make_outbound_mls_envelope(
        conversation_id="c", group_id="g", epoch=0, ciphertext=ct
    )
    assert bytes.fromhex(env.data["payload"]) == ct


def test_hex_case_sensitivity_round_trip() -> None:
    """`bytes.hex()` is lowercase. `bytes.fromhex` accepts upper/lower —
    pin both directions to avoid future flakes (DA bullet #2)."""
    ct = b"\xab\xcd\xef"
    env = make_outbound_mls_envelope(
        conversation_id="c", group_id="g", epoch=0, ciphertext=ct
    )
    assert env.data["payload"] == "abcdef"  # lowercase
    # Backend `bytes.fromhex` would also accept the uppercase form.
    assert bytes.fromhex(env.data["payload"].upper()) == ct


# ---------------------------------------------------------------------------
# Optional fields: §4.2 default behavior
# ---------------------------------------------------------------------------


def test_optional_unconditional_fields_default_to_none() -> None:
    """Plan §4.2 emits ``topic_id``, ``client_message_id``,
    ``parent_span_id``, ``metadata`` UNCONDITIONALLY with None defaults
    (channel.ts:670-677 sends them too even when undefined). ``priority``
    is the OC-parity exception: OC at channel.ts:562 resolves to
    ``"normal"`` before building the envelope, so the default emitted on
    the wire is the string ``"normal"``, not None. The §13.4 spec calls
    for pinning the exact behavior; we pin both."""
    env = make_outbound_mls_envelope(
        conversation_id="c", group_id="g", epoch=0, ciphertext=b""
    )
    for key in ("topic_id", "client_message_id",
                "parent_span_id", "metadata"):
        assert key in env.data, f"{key} should be present even when None"
        assert env.data[key] is None, f"{key} should be None by default"
    # priority is a string (OC parity: channel.ts:562 defaults to "normal")
    assert env.data["priority"] == "normal", (
        "priority must default to 'normal' to match OC peers; emitting null "
        "would produce a different DB row at backend ws.py:2041"
    )


def test_optional_unconditional_fields_pass_through() -> None:
    env = make_outbound_mls_envelope(
        conversation_id="c",
        group_id="g",
        epoch=0,
        ciphertext=b"x",
        topic_id="topic-7",
        client_message_id="cmsg-3",
        priority="high",
        parent_span_id="span-99",
        metadata={"foo": "bar", "scan_status": "ok"},
    )
    assert env.data["topic_id"] == "topic-7"
    assert env.data["client_message_id"] == "cmsg-3"
    assert env.data["priority"] == "high"
    assert env.data["parent_span_id"] == "span-99"
    assert env.data["metadata"] == {"foo": "bar", "scan_status": "ok"}


def test_hub_fields_absent_when_falsy() -> None:
    """`hub_address` and `sender_hub_id` are CONDITIONALLY emitted (only
    when truthy) per OC `channel.ts:679-684`. Default = absent."""
    env = make_outbound_mls_envelope(
        conversation_id="c", group_id="g", epoch=0, ciphertext=b""
    )
    assert "hub_address" not in env.data
    assert "sender_hub_id" not in env.data


def test_hub_fields_present_when_truthy() -> None:
    env = make_outbound_mls_envelope(
        conversation_id="c",
        group_id="g",
        epoch=0,
        ciphertext=b"",
        hub_address="https://hub.example.com",
        sender_hub_id="hub-7",
    )
    assert env.data["hub_address"] == "https://hub.example.com"
    assert env.data["sender_hub_id"] == "hub-7"


def test_hub_fields_skipped_when_empty_string() -> None:
    """OC uses truthy guard (`if (this._persisted?.hubAddress)`); empty
    string is falsy in JS too, so we mirror Python truthiness."""
    env = make_outbound_mls_envelope(
        conversation_id="c",
        group_id="g",
        epoch=0,
        ciphertext=b"",
        hub_address="",
        sender_hub_id="",
    )
    assert "hub_address" not in env.data
    assert "sender_hub_id" not in env.data


# ---------------------------------------------------------------------------
# JSON round-trip
# ---------------------------------------------------------------------------


def test_json_round_trip_basic() -> None:
    env = make_outbound_mls_envelope(
        conversation_id="conv-1",
        group_id="grp-1",
        epoch=7,
        ciphertext=b"hello",
    )
    raw = env.to_json()
    parsed = WireEnvelope.from_json(raw)
    assert parsed == env
    assert parsed.event == "message_mls"
    assert parsed.data == env.data


def test_json_round_trip_with_all_fields() -> None:
    env = make_outbound_mls_envelope(
        conversation_id="c",
        group_id="g",
        epoch=99,
        ciphertext=bytes(range(64)),
        topic_id="t",
        client_message_id="cm",
        message_type="file",
        priority="low",
        parent_span_id="ps",
        metadata={"k": "v"},
        hub_address="https://h",
        sender_hub_id="sh",
    )
    parsed = WireEnvelope.from_json(env.to_json())
    assert parsed == env


def test_json_round_trip_non_ascii_metadata() -> None:
    """DA bullet #1: pin `to_json` non-ASCII behavior. We use
    `json.dumps` defaults (`ensure_ascii=True`), which escapes non-ASCII
    as `\\uXXXX`. Round-trip is lossless either way."""
    env = make_outbound_mls_envelope(
        conversation_id="c",
        group_id="g",
        epoch=0,
        ciphertext=b"x",
        metadata={"emoji": "rocket-emoji-here", "kanji": "日本語"},
    )
    raw = env.to_json()
    # ensure_ascii=True default escapes non-ASCII as \uXXXX
    assert "\\u" in raw  # kanji escaped
    # Round-trip preserves unicode losslessly
    parsed = WireEnvelope.from_json(raw)
    assert parsed.data["metadata"]["kanji"] == "日本語"


def test_to_json_is_valid_json_object_with_event_and_data() -> None:
    env = make_outbound_mls_envelope(
        conversation_id="c", group_id="g", epoch=0, ciphertext=b"a"
    )
    raw = env.to_json()
    parsed = json.loads(raw)
    assert isinstance(parsed, dict)
    assert set(parsed.keys()) == {"event", "data"}


# ---------------------------------------------------------------------------
# from_json error handling
# ---------------------------------------------------------------------------


def test_from_json_raises_on_malformed_json() -> None:
    with pytest.raises(json.JSONDecodeError):
        WireEnvelope.from_json("{not json")


def test_from_json_raises_on_non_object() -> None:
    """DA bullet #3: `data` is a list, not an object."""
    with pytest.raises(TypeError, match="JSON object"):
        WireEnvelope.from_json("[1, 2, 3]")


def test_from_json_raises_keyerror_on_missing_event() -> None:
    """DA bullet #3: missing `event` key. We surface KeyError verbatim
    rather than wrapping — callers that want lenient parsing should
    validate first (per §4.2 docstring)."""
    with pytest.raises(KeyError):
        WireEnvelope.from_json('{"data": {}}')


def test_from_json_raises_keyerror_on_missing_data() -> None:
    with pytest.raises(KeyError):
        WireEnvelope.from_json('{"event": "message_mls"}')


def test_from_json_raises_on_non_dict_data() -> None:
    """DA #4: top-level non-dict guard was already in place; this pins
    the symmetric guard for `data` so a peer sending
    ``{"event":"message_mls","data":"oops"}`` fails fast with a clear
    error instead of `WireEnvelope(data="oops")` crashing downstream."""
    with pytest.raises(TypeError, match="'data' as object"):
        WireEnvelope.from_json('{"event": "message_mls", "data": "oops"}')
    with pytest.raises(TypeError, match="'data' as object"):
        WireEnvelope.from_json('{"event": "message_mls", "data": [1, 2, 3]}')


# ---------------------------------------------------------------------------
# Numeric epoch behavior
# ---------------------------------------------------------------------------


def test_epoch_large_int_round_trip() -> None:
    """DA bullet #4: epoch beyond 2**53 loses precision on JS-side OC.
    Document the assumption: Python carries arbitrary precision through
    JSON, the bug only manifests on the JS reader. We don't guard."""
    big_epoch = 2**53 + 1  # 9007199254740993, beyond JS Number.MAX_SAFE_INTEGER
    env = make_outbound_mls_envelope(
        conversation_id="c", group_id="g", epoch=big_epoch, ciphertext=b""
    )
    parsed = WireEnvelope.from_json(env.to_json())
    assert parsed.data["epoch"] == big_epoch


def test_epoch_zero_round_trip() -> None:
    """Epoch 0 is the pre-init state. OC at `channel.ts:660` guards
    against epoch == 0 before sending — but the envelope module itself
    must round-trip 0 cleanly if a caller forces it."""
    env = make_outbound_mls_envelope(
        conversation_id="c", group_id="g", epoch=0, ciphertext=b""
    )
    assert env.data["epoch"] == 0
    parsed = WireEnvelope.from_json(env.to_json())
    assert parsed.data["epoch"] == 0


# ---------------------------------------------------------------------------
# Task 4: room_message_mls envelope (action #234)
# ---------------------------------------------------------------------------


def test_default_envelope_is_message_mls() -> None:
    env = make_outbound_mls_envelope(
        conversation_id="c-1", group_id="g-1", epoch=3, ciphertext=b"\x01\x02"
    )
    assert env.event == "message_mls"
    assert "room_id" not in env.data


def test_room_envelope_has_room_event_and_room_id() -> None:
    env = make_outbound_mls_envelope(
        conversation_id="r-1",
        group_id="g-1",
        epoch=3,
        ciphertext=b"\x01\x02",
        event="room_message_mls",
        room_id="r-1",
    )
    assert env.event == "room_message_mls"
    assert env.data["room_id"] == "r-1"
    assert env.data["payload"] == "0102"
