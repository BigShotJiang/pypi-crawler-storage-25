"""Unit tests for ``agentvault_hermes.channel.inbox``.

Plan ref: ``docs/plans/2026-05-10-hermes-phase3-implementation.md`` §10.6
(post-patch). The module under test mirrors OC
``packages/plugin/src/channel.ts:3407-3486`` (``_handleMessageMLS``).

Strategy:

- ``MlsGroupState`` is mocked with a recording ``FakeMlsState`` whose
  ``decrypt`` returns a configurable ``DecryptResult``-shaped object.
- The module-level ``_seen_ids`` cache is reset between tests via an
  autouse fixture so dedup state from one test doesn't bleed into the
  next.
- Each test exercises one branch of the contract; the test names map
  1:1 to the bullets in plan §10.6.
"""
from __future__ import annotations

import asyncio
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any, Optional

import pytest

from agentvault_hermes.channel import inbox as inbox_module
from agentvault_hermes.channel.inbox import (
    _SEEN_CACHE_MAX,
    _resolve_state,
    handle_message_dr,
    handle_message_mls,
)
from agentvault_hermes.channel.outbox import WireEnvelope
from agentvault_hermes.channel.secure_channel import InboundMessage


# ---------------------------------------------------------------------------
# Test doubles
# ---------------------------------------------------------------------------


@dataclass
class _DecryptResult:
    """Mirror of ``crypto.mls_group.DecryptResult``."""

    plaintext: Optional[bytes]
    is_handshake: bool


class FakeMlsState:
    """Recording stand-in for ``MlsGroupState``.

    ``decrypt`` returns whatever is queued via ``queue_decrypt`` — a single
    DecryptResult or a callable that raises. Tests use this to drive the
    handshake / plaintext / failure branches without exercising the real
    mls-rs ratchet.
    """

    def __init__(self, *, initialized: bool = True) -> None:
        self._initialized = initialized
        self._next_result: _DecryptResult | Exception | None = None
        self.decrypt_calls: list[bytes] = []

    @property
    def is_initialized(self) -> bool:
        return self._initialized

    def queue_decrypt_plaintext(self, plaintext: bytes) -> None:
        self._next_result = _DecryptResult(plaintext=plaintext, is_handshake=False)

    def queue_decrypt_handshake(self) -> None:
        self._next_result = _DecryptResult(plaintext=None, is_handshake=True)

    def queue_decrypt_raises(self, exc: Exception) -> None:
        self._next_result = exc

    def decrypt(self, ciphertext: bytes) -> _DecryptResult:
        self.decrypt_calls.append(ciphertext)
        if isinstance(self._next_result, Exception):
            raise self._next_result
        if self._next_result is None:
            raise RuntimeError(
                "FakeMlsState.decrypt called without a queued result; "
                "tests must call queue_decrypt_* before driving inbox"
            )
        return self._next_result


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clear_seen_ids() -> None:
    """Reset module-level dedup state between tests."""
    inbox_module._seen_ids.clear()


@pytest.fixture
def own_device_id() -> str:
    return "device-self"


@pytest.fixture
def state() -> FakeMlsState:
    return FakeMlsState()


def _make_envelope(**data: Any) -> WireEnvelope:
    """Build a ``message_mls`` envelope from kwargs (just the data dict)."""
    return WireEnvelope(event="message_mls", data=dict(data))


# ---------------------------------------------------------------------------
# handle_message_mls — happy path
# ---------------------------------------------------------------------------


async def test_happy_path_returns_inbound_message_with_decoded_plaintext(
    state: FakeMlsState, own_device_id: str
) -> None:
    """A fresh peer plaintext frame → ``InboundMessage`` with
    ``is_handshake=False`` and the decrypted plaintext as a UTF-8 string.
    """
    state.queue_decrypt_plaintext(b"hello world")
    envelope = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"\x01\x02".hex(),
        message_type="text",
        client_message_id="cmsg-1",
        message_id="srv-1",
        created_at="2026-05-10T00:00:00Z",
        topic_id="topic-1",
        parent_span_id="span-1",
    )
    mls_states: dict[str, Any] = {"conv-A": state}

    inbound = await handle_message_mls(envelope, mls_states, own_device_id)

    assert isinstance(inbound, InboundMessage)
    assert inbound.conversation_id == "conv-A"
    assert inbound.sender_device_id == "device-peer"
    assert inbound.plaintext == "hello world"
    assert inbound.message_type == "text"
    assert inbound.is_handshake is False
    assert inbound.server_message_id == "srv-1"
    assert inbound.created_at == "2026-05-10T00:00:00Z"
    assert inbound.topic_id == "topic-1"
    assert inbound.parent_span_id == "span-1"
    # Verify ciphertext was decoded from hex correctly.
    assert state.decrypt_calls == [b"\x01\x02"]


# ---------------------------------------------------------------------------
# Echo filter
# ---------------------------------------------------------------------------


async def test_echo_filter_drops_own_messages(
    state: FakeMlsState, own_device_id: str
) -> None:
    """``sender_device_id == own_device_id`` → ``None`` (skip own echo)."""
    envelope = _make_envelope(
        conversation_id="conv-A",
        sender_device_id=own_device_id,  # OUR device — should be filtered
        payload=b"x".hex(),
        client_message_id="cmsg-echo",
    )
    mls_states: dict[str, Any] = {"conv-A": state}

    result = await handle_message_mls(envelope, mls_states, own_device_id)

    assert result is None
    # decrypt MUST NOT have been called for an echo.
    assert state.decrypt_calls == []


# ---------------------------------------------------------------------------
# Dedup
# ---------------------------------------------------------------------------


async def test_dedup_same_client_message_id_returns_none_second_time(
    own_device_id: str,
) -> None:
    """Same ``client_message_id`` twice → second call returns ``None``."""
    state = FakeMlsState()
    state.queue_decrypt_plaintext(b"first")
    envelope = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"\x00".hex(),
        client_message_id="cmsg-dup",
    )
    mls_states: dict[str, Any] = {"conv-A": state}

    first = await handle_message_mls(envelope, mls_states, own_device_id)
    assert first is not None
    assert first.plaintext == "first"

    # Second call with the SAME client_message_id — we don't queue another
    # decrypt result because dedup should short-circuit BEFORE decrypt.
    second = await handle_message_mls(envelope, mls_states, own_device_id)
    assert second is None
    # Decrypt MUST have been called only once (dedup short-circuits before).
    assert len(state.decrypt_calls) == 1


async def test_dedup_lru_eviction_allows_oldest_msg_id_to_be_re_added(
    own_device_id: str,
) -> None:
    """After cache > 5000, the oldest msg_id should be evictable.

    We use a smaller cap by patching ``_SEEN_CACHE_MAX`` for test speed —
    or rather, we drive the cache past the cap directly and verify
    ``popitem(last=False)`` evicted the oldest entry.
    """
    state = FakeMlsState()
    mls_states: dict[str, Any] = {"conv-A": state}

    # Drive the cache to capacity + 1 by sending capacity+1 unique
    # messages with distinct client_message_ids.
    for i in range(_SEEN_CACHE_MAX + 1):
        state.queue_decrypt_plaintext(b"x")
        envelope = _make_envelope(
            conversation_id="conv-A",
            sender_device_id="device-peer",
            payload=b"\x00".hex(),
            client_message_id=f"cmsg-{i}",
        )
        await handle_message_mls(envelope, mls_states, own_device_id)

    # The oldest entry (cmsg-0) MUST have been evicted.
    seen = inbox_module._seen_ids["conv-A"]
    assert "cmsg-0" not in seen
    assert "cmsg-1" in seen  # second-oldest should still be present
    assert len(seen) == _SEEN_CACHE_MAX


async def test_dedup_lru_touch_moves_known_id_to_end(own_device_id: str) -> None:
    """Re-receiving a known msg_id moves it to end-of-OrderedDict.

    Verified by peeking at private ``_seen_ids`` after the second call.
    """
    state = FakeMlsState()
    state.queue_decrypt_plaintext(b"a")
    state.queue_decrypt_plaintext(b"b")  # queued for next non-dup call

    mls_states: dict[str, Any] = {"conv-A": state}

    env_a = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"\x01".hex(),
        client_message_id="cmsg-A",
    )
    env_b = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"\x02".hex(),
        client_message_id="cmsg-B",
    )

    await handle_message_mls(env_a, mls_states, own_device_id)
    await handle_message_mls(env_b, mls_states, own_device_id)
    seen = inbox_module._seen_ids["conv-A"]
    assert list(seen.keys()) == ["cmsg-A", "cmsg-B"]

    # Re-receive cmsg-A; LRU touch should move it to the END.
    # No decrypt result needs to be queued because dedup short-circuits.
    await handle_message_mls(env_a, mls_states, own_device_id)
    assert list(seen.keys()) == ["cmsg-B", "cmsg-A"]


# ---------------------------------------------------------------------------
# Multi-key routing
# ---------------------------------------------------------------------------


async def test_routing_conversation_group_id_lookup_hit(own_device_id: str) -> None:
    """``conversation_group_id`` resolves first when present."""
    state = FakeMlsState()
    state.queue_decrypt_plaintext(b"hi")
    envelope = _make_envelope(
        conversation_group_id="grp-shared",
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"\x00".hex(),
        client_message_id="cmsg-1",
    )
    # State registered under conv_group_id, NOT conv_id.
    mls_states: dict[str, Any] = {"grp-shared": state}

    inbound = await handle_message_mls(envelope, mls_states, own_device_id)

    assert inbound is not None
    assert inbound.conversation_id == "grp-shared"


async def test_routing_conversation_id_fallback(own_device_id: str) -> None:
    """``conversation_id`` resolves when ``conversation_group_id`` is absent."""
    state = FakeMlsState()
    state.queue_decrypt_plaintext(b"hi")
    envelope = _make_envelope(
        conversation_id="conv-only",
        sender_device_id="device-peer",
        payload=b"\x00".hex(),
        client_message_id="cmsg-1",
    )
    mls_states: dict[str, Any] = {"conv-only": state}

    inbound = await handle_message_mls(envelope, mls_states, own_device_id)

    assert inbound is not None
    assert inbound.conversation_id == "conv-only"


async def test_routing_group_id_reverse_lookup(own_device_id: str) -> None:
    """``group_id`` reverse-lookup via ``conv_to_group_id`` resolves the conv."""
    state = FakeMlsState()
    state.queue_decrypt_plaintext(b"hi")
    envelope = _make_envelope(
        # No conversation_group_id, no conversation_id; just group_id.
        group_id="grp-X",
        sender_device_id="device-peer",
        payload=b"\x00".hex(),
        client_message_id="cmsg-1",
    )
    mls_states: dict[str, Any] = {"conv-A": state}
    conv_to_group_id = {"conv-A": "grp-X"}

    inbound = await handle_message_mls(
        envelope, mls_states, own_device_id, conv_to_group_id=conv_to_group_id
    )

    assert inbound is not None
    assert inbound.conversation_id == "conv-A"


async def test_routing_no_match_returns_none_with_warning(
    own_device_id: str, caplog: pytest.LogCaptureFixture
) -> None:
    """All three branches miss → ``None`` + warning logged with id fragments."""
    envelope = _make_envelope(
        conversation_group_id="cg-unknown-1234567890",
        conversation_id="ci-unknown-abcdef",
        group_id="gi-unknown-fedcba",
        sender_device_id="device-peer",
        payload=b"\x00".hex(),
        client_message_id="cmsg-1",
    )
    mls_states: dict[str, Any] = {}  # empty — no key matches

    with caplog.at_level("WARNING", logger="agentvault_hermes.channel.inbox"):
        result = await handle_message_mls(envelope, mls_states, own_device_id)

    assert result is None
    # Warning should mention the truncated cg/conv/group fragments.
    assert any("no MLS group" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# Payload validation
# ---------------------------------------------------------------------------


async def test_missing_payload_returns_none_with_warning(
    state: FakeMlsState, own_device_id: str, caplog: pytest.LogCaptureFixture
) -> None:
    """Missing ``payload`` → ``None`` + warning."""
    envelope = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        # no payload
        client_message_id="cmsg-1",
    )
    mls_states: dict[str, Any] = {"conv-A": state}

    with caplog.at_level("WARNING", logger="agentvault_hermes.channel.inbox"):
        result = await handle_message_mls(envelope, mls_states, own_device_id)

    assert result is None
    assert any("missing payload" in r.message for r in caplog.records)


async def test_bad_hex_payload_returns_none_with_warning(
    state: FakeMlsState, own_device_id: str, caplog: pytest.LogCaptureFixture
) -> None:
    """Invalid hex (e.g. ``"not-hex!"``) → ``None`` + warning."""
    envelope = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload="not-hex!",
        client_message_id="cmsg-1",
    )
    mls_states: dict[str, Any] = {"conv-A": state}

    with caplog.at_level("WARNING", logger="agentvault_hermes.channel.inbox"):
        result = await handle_message_mls(envelope, mls_states, own_device_id)

    assert result is None
    assert any("invalid hex payload" in r.message for r in caplog.records)
    # decrypt MUST NOT have been called for unparseable hex.
    assert state.decrypt_calls == []


# ---------------------------------------------------------------------------
# Decrypt failure
# ---------------------------------------------------------------------------


async def test_decrypt_failure_returns_none_with_warning(
    own_device_id: str, caplog: pytest.LogCaptureFixture
) -> None:
    """``state.decrypt`` raising → ``None`` + warning (loop must not crash)."""
    state = FakeMlsState()
    state.queue_decrypt_raises(RuntimeError("bad MAC"))
    envelope = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"\x00".hex(),
        client_message_id="cmsg-1",
    )
    mls_states: dict[str, Any] = {"conv-A": state}

    with caplog.at_level("WARNING", logger="agentvault_hermes.channel.inbox"):
        result = await handle_message_mls(envelope, mls_states, own_device_id)

    assert result is None
    assert any("MLS decrypt failed" in r.message for r in caplog.records)


async def test_decrypt_failure_does_not_poison_dedup_cache(
    own_device_id: str,
) -> None:
    """Regression — DA WS-30 finding #1.

    If decrypt fails for ``msg_id=X``, ``X`` MUST NOT be recorded in the
    dedup cache. Otherwise a subsequent re-delivery of the same ``msg_id``
    is silently dropped and the message is permanently lost.

    Scenario:

    1. Send ``msg_id=cmsg-retry`` with a payload that fails to decrypt → ``None``.
    2. Verify ``cmsg-retry`` is NOT in ``_seen_ids["conv-A"]``.
    3. Send the SAME ``msg_id`` again with a payload that decrypts cleanly →
       returns a real ``InboundMessage`` (i.e. NOT short-circuited by dedup).
    """
    state = FakeMlsState()
    mls_states: dict[str, Any] = {"conv-A": state}
    envelope = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"\x00".hex(),
        client_message_id="cmsg-retry",
    )

    # First attempt — decrypt fails.
    state.queue_decrypt_raises(RuntimeError("transient bad MAC"))
    first = await handle_message_mls(envelope, mls_states, own_device_id)
    assert first is None
    # Cache must NOT contain cmsg-retry — it would poison future re-deliveries.
    assert (
        "cmsg-retry" not in inbox_module._seen_ids.get("conv-A", {})
    ), "decrypt failure poisoned the dedup cache (DA WS-30 #1 regression)"

    # Second attempt — same msg_id, decrypt now succeeds.
    state.queue_decrypt_plaintext(b"the real message")
    second = await handle_message_mls(envelope, mls_states, own_device_id)
    assert second is not None, "resend after decrypt failure was silently dedup-dropped"
    assert second.plaintext == "the real message"
    # NOW the cache should contain cmsg-retry (post-success record).
    assert "cmsg-retry" in inbox_module._seen_ids["conv-A"]


async def test_plaintext_none_on_non_handshake_raises_runtime_error(
    own_device_id: str,
) -> None:
    """Regression — DA WS-30 finding #2.

    A ``DecryptResult`` with ``plaintext=None`` AND ``is_handshake=False``
    is a contract violation in ``MlsGroupState``. The check MUST be an
    explicit ``raise`` rather than ``assert`` so it survives ``python -O``
    (asserts are stripped under -O).
    """
    state = FakeMlsState()
    # Manually construct a contract-violating DecryptResult: plaintext=None
    # AND is_handshake=False. The fake's queue_decrypt_* helpers don't allow
    # this combination, so we set _next_result directly.
    state._next_result = _DecryptResult(plaintext=None, is_handshake=False)
    envelope = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"\x00".hex(),
        client_message_id="cmsg-bad",
    )
    mls_states: dict[str, Any] = {"conv-A": state}

    with pytest.raises(RuntimeError, match="contract violation"):
        await handle_message_mls(envelope, mls_states, own_device_id)


# ---------------------------------------------------------------------------
# Handshake
# ---------------------------------------------------------------------------


async def test_handshake_message_returns_inbound_with_is_handshake_true(
    own_device_id: str,
) -> None:
    """Handshake → ``InboundMessage(is_handshake=True, plaintext="")``.

    The orchestrator uses this to persist post-decrypt state; it does NOT
    surface to the agent (orchestrator-side guard). Verified in
    ``test_secure_channel.py``.
    """
    state = FakeMlsState()
    state.queue_decrypt_handshake()
    envelope = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"\x00".hex(),
        client_message_id="cmsg-handshake",
        message_id="srv-handshake",
        created_at="2026-05-10T01:00:00Z",
        topic_id="topic-X",
        parent_span_id="span-X",
    )
    mls_states: dict[str, Any] = {"conv-A": state}

    inbound = await handle_message_mls(envelope, mls_states, own_device_id)

    assert inbound is not None
    assert inbound.is_handshake is True
    assert inbound.plaintext == ""
    assert inbound.message_type == "handshake"
    assert inbound.conversation_id == "conv-A"
    assert inbound.sender_device_id == "device-peer"
    # Pass-through fields preserved.
    assert inbound.server_message_id == "srv-handshake"
    assert inbound.created_at == "2026-05-10T01:00:00Z"
    assert inbound.topic_id == "topic-X"
    assert inbound.parent_span_id == "span-X"


# ---------------------------------------------------------------------------
# DR fallback stub
# ---------------------------------------------------------------------------


async def test_handle_message_dr_logs_and_returns_none(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """``handle_message_dr`` is a Phase 3 stub — logs ``INFO`` and returns ``None``."""
    envelope = WireEnvelope(
        event="message", data={"conversation_id": "conv-DR-12345"}
    )

    with caplog.at_level("INFO", logger="agentvault_hermes.channel.inbox"):
        result = await handle_message_dr(envelope)

    assert result is None
    assert any("DR fallback" in r.message for r in caplog.records)


async def test_handle_message_dr_handles_non_string_conversation_id(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """``conversation_id`` not a string → log uses ``"<unknown>"`` placeholder."""
    envelope = WireEnvelope(event="message", data={"conversation_id": 12345})

    with caplog.at_level("INFO", logger="agentvault_hermes.channel.inbox"):
        result = await handle_message_dr(envelope)

    assert result is None
    assert any("DR fallback" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# send_locks parameter (action_item #156 — serialize decrypt against send)
# ---------------------------------------------------------------------------


async def test_send_locks_creates_lock_lazily_on_first_call(
    state: FakeMlsState, own_device_id: str
) -> None:
    """First call with ``send_locks={}`` lazy-creates an ``asyncio.Lock``
    keyed by the resolved ``conv_id_for_callers`` (same shape as
    ``send()``'s lock-creation pattern at ``secure_channel.py:390``).
    """
    state.queue_decrypt_plaintext(b"payload")
    envelope = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"x".hex(),
        client_message_id="cmsg-lock-1",
    )
    mls_states: dict[str, Any] = {"conv-A": state}
    send_locks: dict[str, asyncio.Lock] = {}

    inbound = await handle_message_mls(
        envelope, mls_states, own_device_id, send_locks=send_locks
    )

    assert inbound is not None  # decrypt happened under lock
    assert "conv-A" in send_locks
    assert isinstance(send_locks["conv-A"], asyncio.Lock)
    # Lock was released — next acquirer wouldn't block.
    assert not send_locks["conv-A"].locked()


async def test_send_locks_reuses_lock_across_calls(
    own_device_id: str,
) -> None:
    """Second call on the same conv reuses the SAME ``asyncio.Lock``
    instance. Critical: send() and demux must share the same lock object
    to actually serialize; a per-call fresh lock would be useless.
    """
    state = FakeMlsState()
    state.queue_decrypt_plaintext(b"first")
    envelope1 = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"x".hex(),
        client_message_id="cmsg-r1",
    )
    mls_states: dict[str, Any] = {"conv-A": state}
    send_locks: dict[str, asyncio.Lock] = {}

    await handle_message_mls(
        envelope1, mls_states, own_device_id, send_locks=send_locks
    )
    first_lock = send_locks["conv-A"]

    state.queue_decrypt_plaintext(b"second")
    envelope2 = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"y".hex(),
        client_message_id="cmsg-r2",
    )
    await handle_message_mls(
        envelope2, mls_states, own_device_id, send_locks=send_locks
    )

    # Same Lock instance — not a fresh one per call.
    assert send_locks["conv-A"] is first_lock


async def test_send_locks_omitted_runs_unlocked(
    state: FakeMlsState, own_device_id: str
) -> None:
    """When ``send_locks`` is omitted (None), the function runs without
    acquiring any lock — backward-compat for the 20+ existing test
    callers that don't exercise concurrency.
    """
    state.queue_decrypt_plaintext(b"unlocked")
    envelope = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"x".hex(),
        client_message_id="cmsg-unlocked",
    )
    mls_states: dict[str, Any] = {"conv-A": state}

    # No send_locks kwarg — must succeed.
    inbound = await handle_message_mls(envelope, mls_states, own_device_id)
    assert inbound is not None
    assert inbound.plaintext == "unlocked"


async def test_send_locks_held_during_decrypt(own_device_id: str) -> None:
    """Lock IS held while ``state.decrypt`` runs. Critical to the action
    #156 contract — if the lock were acquired-then-released before
    decrypt, a concurrent ``send()`` could still mutate the Rust state
    in parallel.

    Uses an instrumented FakeMlsState whose decrypt asserts the lock is
    locked at the moment decrypt is invoked.
    """
    send_locks: dict[str, asyncio.Lock] = {}

    class LockObserverState(FakeMlsState):
        def __init__(self) -> None:
            super().__init__()
            self.decrypt_saw_lock_held: bool = False

        def decrypt(self, ciphertext: bytes):  # type: ignore[override]
            # The function should have acquired send_locks["conv-A"] before
            # calling us. Verify the lock is held at decrypt time.
            lock = send_locks.get("conv-A")
            self.decrypt_saw_lock_held = lock is not None and lock.locked()
            return super().decrypt(ciphertext)

    state = LockObserverState()
    state.queue_decrypt_plaintext(b"under-lock")
    envelope = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"x".hex(),
        client_message_id="cmsg-observer",
    )
    mls_states: dict[str, Any] = {"conv-A": state}

    inbound = await handle_message_mls(
        envelope, mls_states, own_device_id, send_locks=send_locks
    )

    assert inbound is not None
    assert state.decrypt_saw_lock_held, (
        "state.decrypt ran without the per-conv send_lock held; "
        "concurrent send() could race the Rust state machine"
    )


async def test_handle_message_mls_blocks_when_send_lock_already_held(
    state: FakeMlsState, own_device_id: str
) -> None:
    """If a concurrent ``send()`` is holding ``send_locks[conv]``,
    ``handle_message_mls`` MUST block on lock acquisition rather than
    racing into ``state.decrypt`` while the Rust state machine is being
    mutated by ``state.encrypt``. Releasing the lock unblocks the demux.

    Models the real race action #156 was filed for: send() takes the lock
    in ``secure_channel.py:403``, demux arrives via the WS frame loop and
    must wait until send releases.
    """
    send_locks: dict[str, asyncio.Lock] = {}

    # Pre-acquire the lock as if send() were currently inside its
    # ``async with lock:`` block (mid-encrypt).
    held_lock = asyncio.Lock()
    send_locks["conv-A"] = held_lock
    await held_lock.acquire()

    state.queue_decrypt_plaintext(b"after-wait")
    envelope = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"x".hex(),
        client_message_id="cmsg-blocks",
    )
    mls_states: dict[str, Any] = {"conv-A": state}

    # Launch handle_message_mls — it should park on lock acquisition.
    task = asyncio.create_task(
        handle_message_mls(
            envelope, mls_states, own_device_id, send_locks=send_locks
        )
    )

    # Yield a few times so the task gets a chance to reach the
    # ``async with lock_ctx:`` line.
    for _ in range(5):
        await asyncio.sleep(0)

    # Critical assertion: the task is still pending — blocked on the lock.
    # ``state.decrypt`` has NOT been called yet (the function is parked
    # before it). If the lock were ignored, the task would have completed
    # and decrypt_calls would contain the ciphertext.
    assert not task.done(), (
        "handle_message_mls did not block on the held lock; "
        "concurrent send() could race state.decrypt"
    )
    assert state.decrypt_calls == [], (
        "state.decrypt ran while the per-conv send_lock was held by a "
        "simulated concurrent send()"
    )

    # Release the held lock — the simulated send() finished.
    held_lock.release()

    # Now the task should complete promptly.
    inbound = await asyncio.wait_for(task, timeout=1.0)
    assert inbound is not None
    assert inbound.plaintext == "after-wait"
    assert state.decrypt_calls == [b"x"]
    # Lock back to released state.
    assert not held_lock.locked()


async def test_decrypt_failure_releases_send_lock(
    own_device_id: str,
) -> None:
    """A decrypt exception MUST release the per-conv lock (via
    ``async with`` cleanup) — a stuck lock would deadlock all subsequent
    sends and demuxes on that conversation forever.
    """
    state = FakeMlsState()
    state.queue_decrypt_raises(RuntimeError("synthetic decrypt failure"))
    envelope = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"x".hex(),
        client_message_id="cmsg-fail",
    )
    mls_states: dict[str, Any] = {"conv-A": state}
    send_locks: dict[str, asyncio.Lock] = {}

    # First call — decrypt raises, function returns None (errors absorbed).
    result = await handle_message_mls(
        envelope, mls_states, own_device_id, send_locks=send_locks
    )

    assert result is None
    # The lock was created but then released on exception.
    assert "conv-A" in send_locks
    assert not send_locks["conv-A"].locked(), (
        "decrypt exception did not release the lock — subsequent operations "
        "on conv-A would deadlock"
    )

    # Sanity: a follow-up successful call still works (lock is reusable).
    state.queue_decrypt_plaintext(b"recovered")
    envelope2 = _make_envelope(
        conversation_id="conv-A",
        sender_device_id="device-peer",
        payload=b"y".hex(),
        client_message_id="cmsg-recover",
    )
    recovered = await handle_message_mls(
        envelope2, mls_states, own_device_id, send_locks=send_locks
    )
    assert recovered is not None
    assert recovered.plaintext == "recovered"


# ---------------------------------------------------------------------------
# _resolve_state direct unit tests (covers all three branches + edge cases)
# ---------------------------------------------------------------------------


def test_resolve_state_uninitialized_state_falls_through() -> None:
    """An uninitialized state in ``mls_states`` MUST NOT short-circuit
    — the resolver should fall through to the next branch.
    """
    uninit = FakeMlsState(initialized=False)
    init = FakeMlsState(initialized=True)
    mls_states: dict[str, Any] = {"conv-A": uninit, "grp-X": init}
    data = {
        "conversation_id": "conv-A",  # uninit — should fall through
        "group_id": "grp-X",  # initialized — should resolve
    }
    conv_to_group_id = {"grp-X": "grp-X"}

    key, state = _resolve_state(data, mls_states, conv_to_group_id)

    # Falls through conv_id (uninit) and group_id reverse-lookup hits grp-X.
    assert key == "grp-X"
    assert state is init


def test_resolve_state_no_match_returns_pair_of_none() -> None:
    """All three branches miss → ``(None, None)``."""
    data = {
        "conversation_group_id": "cg",
        "conversation_id": "ci",
        "group_id": "gi",
    }

    key, state = _resolve_state(data, {}, {})

    assert key is None
    assert state is None


# ---------------------------------------------------------------------------
# Module-level cache contract
# ---------------------------------------------------------------------------


def test_seen_ids_is_module_level_dict() -> None:
    """``_seen_ids`` is a module-level ``dict`` of per-conv ``OrderedDict``s.

    Documents the cache shape so a future refactor can't silently change it.
    """
    assert isinstance(inbox_module._seen_ids, dict)
    # Items should be OrderedDicts when populated.
    inbox_module._seen_ids["test-conv"] = OrderedDict()
    assert isinstance(inbox_module._seen_ids["test-conv"], OrderedDict)


# ---------------------------------------------------------------------------
# Room routing
# ---------------------------------------------------------------------------


class TestRoomRouting:
    """Room messages route by room_id and carry it on InboundMessage."""

    async def test_message_routes_by_room_id(self) -> None:
        # A room application frame carries room_id and NO conversation_id /
        # conversation_group_id. The MLS state is keyed by room_id.
        room_id = "55555555-5555-5555-5555-555555555555"
        state = FakeMlsState()
        state.queue_decrypt_plaintext(b"hello room")
        mls_states: dict[str, Any] = {room_id: state}
        env = WireEnvelope(
            event="room_message_mls",
            data={
                "room_id": room_id,
                "group_id": "g-1",
                "sender_device_id": "other-device",
                "message_id": "m-room-1",
                "message_type": "text",
                "payload": "00",
            },
        )
        inbound = await handle_message_mls(env, mls_states, own_device_id="me")
        assert inbound is not None
        assert inbound.conversation_id == room_id
        assert inbound.room_id == room_id
        assert inbound.plaintext == "hello room"

    async def test_one_to_one_message_has_room_id_none(self) -> None:
        conv_id = "66666666-6666-6666-6666-666666666666"
        state = FakeMlsState()
        state.queue_decrypt_plaintext(b"hi")
        env = WireEnvelope(
            event="message_mls",
            data={
                "conversation_id": conv_id,
                "group_id": "g-2",
                "sender_device_id": "other-device",
                "message_id": "m-1to1-1",
                "message_type": "text",
                "payload": "00",
            },
        )
        mls_states: dict[str, Any] = {conv_id: state}
        inbound = await handle_message_mls(env, mls_states, own_device_id="me")
        assert inbound is not None
        assert inbound.room_id is None

    async def test_room_id_wins_over_initialized_conversation_id(self) -> None:
        """Routing-precedence contract: when a frame carries BOTH room_id and
        conversation_id and BOTH resolve to initialized MLS states, room_id is
        authoritative. Locks ``_resolve_state`` branch order against a future
        reordering regression.
        """
        room_id = "77777777-7777-7777-7777-777777777777"
        conv_id = "88888888-8888-8888-8888-888888888888"
        room_state = FakeMlsState()
        room_state.queue_decrypt_plaintext(b"from room")
        conv_state = FakeMlsState()
        conv_state.queue_decrypt_plaintext(b"from conv")
        mls_states: dict[str, Any] = {room_id: room_state, conv_id: conv_state}
        env = WireEnvelope(
            event="room_message_mls",
            data={
                "room_id": room_id,
                "conversation_id": conv_id,
                "group_id": "g-3",
                "sender_device_id": "other-device",
                "message_id": "m-room-precedence",
                "message_type": "text",
                "payload": "00",
            },
        )
        inbound = await handle_message_mls(env, mls_states, own_device_id="me")
        assert inbound is not None
        # Resolved to the ROOM state, not the conversation_id state.
        assert inbound.conversation_id == room_id
        assert inbound.room_id == room_id
        assert inbound.plaintext == "from room"
        # The conversation_id-keyed state must NOT have been decrypted.
        assert room_state.decrypt_calls == [b"\x00"]
        assert conv_state.decrypt_calls == []
