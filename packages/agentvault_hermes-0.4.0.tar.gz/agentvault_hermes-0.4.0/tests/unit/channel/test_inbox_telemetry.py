"""Tests for telemetry emit sites in inbox.handle_mls_welcome.

Spec: docs/superpowers/specs/2026-05-14-hermes-phase4b-mls-telemetry-and-ui-design.md (PR-4b-A1, Task 5)

Three emit sites:
  1. WELCOME_PERMANENT_FAILURE when pending_kp_state is None
  2. WELCOME_PERMANENT_FAILURE when join_from_welcome raises
  3. JOINED on successful welcome-join

Helpers (envelope + pending KP factory) are replicated locally per the
Task 2 minimal-relay pattern — kept test files independent so a failure
here doesn't entangle with test_inbox_mls_welcome.py.
"""
from __future__ import annotations

import asyncio
from typing import Any, Optional
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID

from agentvault_hermes.channel.inbox import handle_mls_welcome
from agentvault_hermes.channel.outbox import WireEnvelope
from agentvault_hermes.channel.telemetry import MlsTelemetryEmitter


_OWN_DEVICE_ID = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
_OTHER_DEVICE_ID = "bbbbbbbb-cccc-dddd-eeee-ffffffffffff"
_CONV_ID = "22222222-2222-2222-2222-222222222222"
_GROUP_UUID = UUID("01234567-89ab-cdef-0123-456789abcdef")
_GROUP_ID_BYTES = _GROUP_UUID.bytes
_GROUP_ID_STR = str(_GROUP_UUID)


class _RecordingSender:
    """In-memory TelemetrySender double for tests."""

    def __init__(self) -> None:
        self.sent: list[dict[str, Any]] = []

    async def send(self, envelope: dict[str, Any]) -> None:
        self.sent.append(envelope)


def _events(sender: _RecordingSender) -> list[dict[str, Any]]:
    """Pull the .data field out of every telemetry.mls envelope."""
    return [
        env["data"]
        for env in sender.sent
        if env.get("event") == "telemetry.mls"
    ]


def _welcome_envelope(
    *,
    sender_device_id: str = _OTHER_DEVICE_ID,
    conversation_id: Optional[str] = _CONV_ID,
    conversation_group_id: Optional[str] = None,
    payload: str = "deadbeef",
    group_id: str = _GROUP_ID_STR,
) -> WireEnvelope:
    return WireEnvelope(
        event="message_mls",
        data={
            "queue_id": "q-welcome-1",
            "message_id": "m1",
            "group_id": group_id,
            "message_type": "welcome",
            "sender_device_id": sender_device_id,
            "epoch": 0,
            "payload": payload,
            "room_id": None,
            "conversation_id": conversation_id,
            "a2a_channel_id": None,
            "conversation_group_id": conversation_group_id,
            "created_at": "2026-05-14T00:00:00Z",
        },
    )


def _make_pending_kp_state(
    *,
    join_side_effect: Any = None,
    group_id_bytes: bytes = _GROUP_ID_BYTES,
) -> MagicMock:
    """Stand-in for ``MlsGroupState``.

    Mirrors the helper in ``test_inbox_mls_welcome.py``. ``is_initialized``
    flips True after ``join_from_welcome`` is called.
    """
    state = MagicMock(name="PendingKpState")
    state.is_initialized = False
    state.group_id = group_id_bytes

    def _join(welcome_bytes: bytes) -> None:
        if join_side_effect is not None:
            if isinstance(join_side_effect, Exception):
                raise join_side_effect
            raise join_side_effect()
        state.is_initialized = True

    state.join_from_welcome.side_effect = _join
    return state


# ---------------------------------------------------------------------------
# Emit site 1: WELCOME_PERMANENT_FAILURE when pending_kp_state is None
# ---------------------------------------------------------------------------


async def test_pending_kp_none_emits_welcome_permanent_failure() -> None:
    sender = _RecordingSender()
    emitter = MlsTelemetryEmitter(sender)

    outcome = await handle_mls_welcome(
        envelope=_welcome_envelope(),
        mls_states={},
        pending_kp_state=None,
        own_device_id=_OWN_DEVICE_ID,
        conv_to_group_id={},
        send_locks={},
        persist_state=AsyncMock(),
        clear_pending_kp_state=MagicMock(),
        telemetry=emitter,
    )

    assert outcome.joined is False
    assert outcome.drop is True

    events = _events(sender)
    assert len(events) == 1
    assert events[0]["event"] == "welcome_permanent_failure"
    assert events[0]["group_id"] == _GROUP_ID_STR
    assert events[0]["context"] == {"reason": "pending_kp_state_none"}


# ---------------------------------------------------------------------------
# Emit site 2: WELCOME_PERMANENT_FAILURE when join_from_welcome raises
# ---------------------------------------------------------------------------


async def test_join_from_welcome_raised_emits_welcome_permanent_failure() -> None:
    sender = _RecordingSender()
    emitter = MlsTelemetryEmitter(sender)
    pending = _make_pending_kp_state(
        join_side_effect=ValueError("boom"),
    )

    outcome = await handle_mls_welcome(
        envelope=_welcome_envelope(),
        mls_states={},
        pending_kp_state=pending,
        own_device_id=_OWN_DEVICE_ID,
        conv_to_group_id={},
        send_locks={},
        persist_state=AsyncMock(),
        clear_pending_kp_state=MagicMock(),
        telemetry=emitter,
    )

    assert outcome.joined is False
    assert outcome.drop is True

    events = _events(sender)
    assert len(events) == 1
    assert events[0]["event"] == "welcome_permanent_failure"
    assert events[0]["group_id"] == _GROUP_ID_STR
    assert events[0]["context"] == {
        "reason": "join_from_welcome_raised",
        "error_class": "ValueError",
    }


# ---------------------------------------------------------------------------
# Emit site 3: JOINED on successful welcome-join
# ---------------------------------------------------------------------------


async def test_successful_welcome_emits_joined() -> None:
    sender = _RecordingSender()
    emitter = MlsTelemetryEmitter(sender)
    pending = _make_pending_kp_state()
    mls_states: dict[str, Any] = {}
    conv_to_group_id: dict[str, str] = {}
    send_locks: dict[str, asyncio.Lock] = {}
    persist_state = AsyncMock()
    clear_kp = MagicMock()

    outcome = await handle_mls_welcome(
        envelope=_welcome_envelope(),
        mls_states=mls_states,
        pending_kp_state=pending,
        own_device_id=_OWN_DEVICE_ID,
        conv_to_group_id=conv_to_group_id,
        send_locks=send_locks,
        persist_state=persist_state,
        clear_pending_kp_state=clear_kp,
        telemetry=emitter,
    )

    assert outcome.joined is True
    assert outcome.drop is False
    assert outcome.routing_key == _CONV_ID

    events = _events(sender)
    assert len(events) == 1
    assert events[0]["event"] == "joined"
    # The canonicalized post-join group_id_str (UUID-string) is emitted —
    # this comes from MlsGroupState.group_id (bytes) → UUID(bytes=...).
    assert events[0]["group_id"] == _GROUP_ID_STR
    assert events[0]["context"] == {}


# ---------------------------------------------------------------------------
# Idempotent-drop: no emit when the welcome row references a group we've
# already joined (DA M2 fix-pass)
# ---------------------------------------------------------------------------


async def test_idempotent_drop_emits_nothing() -> None:
    """When the welcome row references an already-joined routing_key, the
    handler short-circuits with WelcomeOutcome(joined=False, drop=True, ...)
    before reaching any emit site. No telemetry should fire — duplicates must
    not inflate the JOINED counter on AV-web.

    The idempotent check in ``handle_mls_welcome`` lives at the
    ``mls_states[routing_key].is_initialized`` lookup (inbox.py:535-541).
    ``routing_key`` resolves from ``conversation_group_id`` or
    ``conversation_id`` — here we seed ``mls_states`` keyed by
    ``_CONV_ID`` (the conversation_id the envelope helper sets).
    """
    sender = _RecordingSender()
    emitter = MlsTelemetryEmitter(sender)

    pending = _make_pending_kp_state()
    # Pre-existing initialized state on the same routing_key — triggers the
    # idempotent short-circuit at inbox.py:535-541.
    existing_state = _make_pending_kp_state()
    existing_state.is_initialized = True

    outcome = await handle_mls_welcome(
        envelope=_welcome_envelope(),
        mls_states={_CONV_ID: existing_state},
        pending_kp_state=pending,
        own_device_id=_OWN_DEVICE_ID,
        conv_to_group_id={},
        send_locks={},
        persist_state=AsyncMock(),
        clear_pending_kp_state=MagicMock(),
        telemetry=emitter,
    )

    assert outcome.drop is True
    assert outcome.joined is False
    assert _events(sender) == []


# ---------------------------------------------------------------------------
# Emit-failure isolation: a raising sender does not break the welcome flow
# (DA M3 fix-pass — load-bearing promise: telemetry MUST NEVER break MLS)
# ---------------------------------------------------------------------------


async def test_emit_failure_does_not_affect_welcome_outcome() -> None:
    """The MlsTelemetryEmitter absorbs sender exceptions (per
    telemetry.py:_RecordingSender contract). Verify at the integration
    level that handle_mls_welcome returns joined=True even when the
    sender raises during the JOINED emit. This is the load-bearing
    promise of the telemetry design: telemetry MUST NEVER break the
    MLS flow.
    """

    class _RaisingSender:
        async def send(self, envelope: dict[str, Any]) -> None:
            raise RuntimeError("WS down mid-emit")

    emitter = MlsTelemetryEmitter(_RaisingSender())

    pending = _make_pending_kp_state()
    outcome = await handle_mls_welcome(
        envelope=_welcome_envelope(),
        mls_states={},
        pending_kp_state=pending,
        own_device_id=_OWN_DEVICE_ID,
        conv_to_group_id={},
        send_locks={},
        persist_state=AsyncMock(),
        clear_pending_kp_state=MagicMock(),
        telemetry=emitter,
    )

    assert outcome.joined is True
    assert outcome.drop is False
