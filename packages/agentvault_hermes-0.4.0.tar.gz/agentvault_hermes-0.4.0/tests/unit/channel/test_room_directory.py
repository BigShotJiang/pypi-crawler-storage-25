"""Unit tests for channel/room_directory.py."""
from __future__ import annotations

from pathlib import Path

from agentvault_hermes.channel.room_directory import (
    RoomDirectory,
    RoomMember,
)

_ROOM_ID = "11111111-1111-1111-1111-111111111111"
_GROUP_ID = "22222222-2222-2222-2222-222222222222"
_OWNER_DID = "33333333-3333-3333-3333-333333333333"
_AGENT_DID = "44444444-4444-4444-4444-444444444444"


def _room_joined_payload() -> dict:
    return {
        "room_id": _ROOM_ID,
        "room_name": "Launch Room",
        "members": [
            {"device_id": _OWNER_DID, "entity_type": "owner", "display_name": "Chris"},
            {"device_id": _AGENT_DID, "entity_type": "agent", "display_name": "Cortina"},
        ],
        "conversations": [{"id": "c-1", "participant_a": _OWNER_DID, "participant_b": _AGENT_DID}],
    }


def _poll_item() -> dict:
    return {
        "id": _ROOM_ID,
        "name": "Launch Room",
        "status": "active",
        "created_at": "2026-05-21T00:00:00Z",
        "member_count": 2,
        "members": [
            {"device_id": _OWNER_DID, "entity_type": "owner", "display_name": "Chris"},
            {"device_id": _AGENT_DID, "entity_type": "agent", "display_name": "Cortina"},
        ],
    }


def test_upsert_from_room_joined_populates_entry() -> None:
    d = RoomDirectory()
    entry = d.upsert_from_room_joined(_room_joined_payload())
    assert entry.room_id == _ROOM_ID
    assert entry.name == "Launch Room"
    assert entry.conversation_ids == ["c-1"]
    assert entry.members[_OWNER_DID].is_agent is False
    assert entry.members[_AGENT_DID].is_agent is True
    assert d.get(_ROOM_ID) is entry


def test_upsert_from_poll_populates_entry() -> None:
    d = RoomDirectory()
    entry = d.upsert_from_poll(_poll_item())
    assert entry.room_id == _ROOM_ID
    assert entry.name == "Launch Room"
    assert set(entry.members) == {_OWNER_DID, _AGENT_DID}


def test_record_welcome_creates_minimal_entry() -> None:
    d = RoomDirectory()
    entry = d.record_welcome(_ROOM_ID, _GROUP_ID)
    assert entry.room_id == _ROOM_ID
    assert entry.mls_group_id == _GROUP_ID
    assert entry.name is None
    assert entry.members == {}


def test_merge_welcome_then_room_joined_keeps_both() -> None:
    d = RoomDirectory()
    d.record_welcome(_ROOM_ID, _GROUP_ID)
    d.upsert_from_room_joined(_room_joined_payload())
    entry = d.get(_ROOM_ID)
    assert entry is not None
    assert entry.mls_group_id == _GROUP_ID  # welcome value preserved
    assert entry.name == "Launch Room"  # room_joined value applied


def test_merge_room_joined_then_welcome_keeps_both() -> None:
    d = RoomDirectory()
    d.upsert_from_room_joined(_room_joined_payload())
    d.record_welcome(_ROOM_ID, _GROUP_ID)
    entry = d.get(_ROOM_ID)
    assert entry is not None
    assert entry.name == "Launch Room"  # room_joined value preserved
    assert entry.mls_group_id == _GROUP_ID  # welcome value applied


def test_resolve_by_group_id() -> None:
    d = RoomDirectory()
    d.record_welcome(_ROOM_ID, _GROUP_ID)
    assert d.resolve_by_group_id(_GROUP_ID) is d.get(_ROOM_ID)
    assert d.resolve_by_group_id("no-such-group") is None


def test_save_then_load_round_trips(tmp_path: Path) -> None:
    d = RoomDirectory()
    d.upsert_from_room_joined(_room_joined_payload())
    d.record_welcome(_ROOM_ID, _GROUP_ID)
    d.save(tmp_path)
    assert (tmp_path / "rooms.json").exists()

    d2 = RoomDirectory()
    d2.load(tmp_path)
    entry = d2.get(_ROOM_ID)
    assert entry is not None
    assert entry.name == "Launch Room"
    assert entry.mls_group_id == _GROUP_ID
    assert entry.members[_AGENT_DID] == RoomMember(
        device_id=_AGENT_DID, display_name="Cortina", is_agent=True
    )


def test_load_missing_file_is_empty(tmp_path: Path) -> None:
    d = RoomDirectory()
    d.load(tmp_path)  # no rooms.json
    assert d.all() == []


def test_load_malformed_file_does_not_raise(tmp_path: Path) -> None:
    (tmp_path / "rooms.json").write_text("{not json", encoding="utf-8")
    d = RoomDirectory()
    d.load(tmp_path)  # must not raise
    assert d.all() == []


def test_load_valid_json_wrong_shape_does_not_raise(tmp_path: Path) -> None:
    # Valid JSON whose top level is a list, not an object.
    (tmp_path / "rooms.json").write_text("[1, 2, 3]", encoding="utf-8")
    d = RoomDirectory()
    d.load(tmp_path)  # must not raise
    assert d.all() == []


def test_empty_poll_does_not_wipe_existing_members() -> None:
    d = RoomDirectory()
    d.upsert_from_room_joined(_room_joined_payload())
    # A poll item for the same room carrying no members must NOT clobber
    # the members already discovered via room_joined.
    d.upsert_from_poll(
        {
            "id": _ROOM_ID,
            "name": "Launch Room",
            "status": "active",
            "created_at": "2026-05-21T00:00:00Z",
            "member_count": 0,
            "members": [],
        }
    )
    entry = d.get(_ROOM_ID)
    assert entry is not None
    assert set(entry.members) == {_OWNER_DID, _AGENT_DID}
