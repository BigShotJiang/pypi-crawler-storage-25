"""Unit tests for ``agentvault_hermes.channel.lock_file``.

Source under test mirrors ``packages/plugin/src/mls-state.ts:8-68``.
Plan ref: ``docs/plans/2026-05-10-hermes-phase3-implementation.md`` §8.8.
"""
from __future__ import annotations

import json
import os
import stat
import sys
import threading
from pathlib import Path

import pytest

from agentvault_hermes.channel import lock_file as lock_file_module
from agentvault_hermes.channel.lock_file import (
    _SAFE_RE,
    _SYNC_LOCK_STALE_SECONDS,
    _sync_lock_path,
    acquire_a2a_sync_lock,
    release_a2a_sync_lock,
)


# ---------------------------------------------------------------------------
# Constants & path resolution
# ---------------------------------------------------------------------------


def test_constants_match_oc_byte_exact() -> None:
    """OC constants at mls-state.ts:4-7.

    FILE_MODE = 0o600
    DIR_MODE = 0o700
    SYNC_LOCK_STALE_MS = 5 * 60 * 1000  (300 seconds)
    Safe-name regex: /[^a-zA-Z0-9_-]/g
    """
    assert lock_file_module._FILE_MODE == 0o600
    assert lock_file_module._DIR_MODE == 0o700
    assert _SYNC_LOCK_STALE_SECONDS == 300.0
    assert _SAFE_RE.pattern == r"[^a-zA-Z0-9_-]"


def test_sync_lock_path_sanitizes_unsafe_chars(tmp_path: Path) -> None:
    """``/``, ``.``, ``!`` all collapse to ``_`` per the regex
    ``[^a-zA-Z0-9_-]``. Input ``"abc/../def!"`` has 5 unsafe chars
    in positions ``/``, ``.``, ``.``, ``/``, ``!`` — the first 4 between
    ``abc`` and ``def`` (yielding ``abc____def``) and the last one after
    ``def`` (yielding ``abc____def_``). The trailing ``.lock`` is the
    filename suffix.
    """
    p = _sync_lock_path(tmp_path, "abc/../def!")
    expected = "mls-a2a-sync-abc____def_.lock"
    assert p.name == expected


def test_sync_lock_path_keeps_safe_chars(tmp_path: Path) -> None:
    """Allowed: a-z A-Z 0-9 _ -"""
    p = _sync_lock_path(tmp_path, "Conv-123_abc")
    assert p.name == "mls-a2a-sync-Conv-123_abc.lock"


def test_sync_lock_path_uuid_pattern(tmp_path: Path) -> None:
    """UUIDs contain hyphens; hyphens are allowed → no rewriting."""
    uid = "550e8400-e29b-41d4-a716-446655440000"
    p = _sync_lock_path(tmp_path, uid)
    assert p.name == f"mls-a2a-sync-{uid}.lock"


# ---------------------------------------------------------------------------
# Acquire / release happy paths
# ---------------------------------------------------------------------------


def test_acquire_on_empty_dir_returns_true(tmp_path: Path) -> None:
    assert acquire_a2a_sync_lock(tmp_path, "ch1") is True
    lock_path = _sync_lock_path(tmp_path, "ch1")
    assert lock_path.exists()


def test_acquire_writes_payload_with_pid_and_timestamp(tmp_path: Path) -> None:
    assert acquire_a2a_sync_lock(tmp_path, "ch1") is True
    raw = _sync_lock_path(tmp_path, "ch1").read_text(encoding="utf-8")
    parsed = json.loads(raw)
    assert isinstance(parsed["pid"], int)
    assert parsed["pid"] == os.getpid()
    assert isinstance(parsed["timestamp"], (int, float))


@pytest.mark.skipif(
    sys.platform == "win32",
    reason="POSIX file-mode bits are not meaningful on Windows",
)
def test_acquire_creates_lock_with_mode_0o600(tmp_path: Path) -> None:
    """OC mls-state.ts:32 specifies ``mode: FILE_MODE`` (0o600)."""
    acquire_a2a_sync_lock(tmp_path, "ch1")
    lock_path = _sync_lock_path(tmp_path, "ch1")
    mode = stat.S_IMODE(lock_path.stat().st_mode)
    assert mode == 0o600


def test_re_acquire_while_held_returns_false(tmp_path: Path) -> None:
    assert acquire_a2a_sync_lock(tmp_path, "ch1") is True
    assert acquire_a2a_sync_lock(tmp_path, "ch1") is False


def test_release_then_re_acquire(tmp_path: Path) -> None:
    assert acquire_a2a_sync_lock(tmp_path, "ch1") is True
    release_a2a_sync_lock(tmp_path, "ch1")
    assert acquire_a2a_sync_lock(tmp_path, "ch1") is True


def test_release_is_idempotent(tmp_path: Path) -> None:
    """Calling release twice must not raise."""
    acquire_a2a_sync_lock(tmp_path, "ch1")
    release_a2a_sync_lock(tmp_path, "ch1")
    # Second call — file no longer exists; must be silent.
    release_a2a_sync_lock(tmp_path, "ch1")


def test_release_when_never_acquired_is_noop(tmp_path: Path) -> None:
    release_a2a_sync_lock(tmp_path, "never-existed")


def test_distinct_channels_are_independent_locks(tmp_path: Path) -> None:
    assert acquire_a2a_sync_lock(tmp_path, "ch1") is True
    assert acquire_a2a_sync_lock(tmp_path, "ch2") is True
    # Both held independently; ch1 still locked
    assert acquire_a2a_sync_lock(tmp_path, "ch1") is False
    assert acquire_a2a_sync_lock(tmp_path, "ch2") is False


# ---------------------------------------------------------------------------
# Stale-lock cleanup
# ---------------------------------------------------------------------------


def test_stale_lock_is_cleaned_up_and_reacquired(tmp_path: Path) -> None:
    """Write a lock with epoch-0 timestamp (ancient) — acquire must
    detect it as stale, unlink, and re-create.
    """
    lock_path = _sync_lock_path(tmp_path, "ch1")
    tmp_path.mkdir(parents=True, exist_ok=True)
    lock_path.write_text(
        json.dumps({"pid": 99999, "timestamp": 0.0}),
        encoding="utf-8",
    )
    # Acquire should succeed by stealing the stale lock
    assert acquire_a2a_sync_lock(tmp_path, "ch1") is True
    # The new payload must contain OUR pid + a current-ish timestamp
    parsed = json.loads(lock_path.read_text(encoding="utf-8"))
    assert parsed["pid"] == os.getpid()
    assert parsed["timestamp"] > 0


def test_fresh_lock_not_stolen(tmp_path: Path) -> None:
    """A lock written "now-ish" must NOT be stolen — staleness threshold
    is 5 minutes (300s).
    """
    import time as _time

    lock_path = _sync_lock_path(tmp_path, "ch1")
    tmp_path.mkdir(parents=True, exist_ok=True)
    lock_path.write_text(
        json.dumps({"pid": 99999, "timestamp": _time.time() - 60.0}),  # 1min old
        encoding="utf-8",
    )
    # Acquire must return False — lock is held by someone else and fresh.
    assert acquire_a2a_sync_lock(tmp_path, "ch1") is False


def test_lock_with_unparseable_json_treated_as_held(tmp_path: Path) -> None:
    """If the lock file content is corrupt, OC treats the lock as held
    (mls-state.ts:50-52). Hermes mirrors this — return False.
    """
    lock_path = _sync_lock_path(tmp_path, "ch1")
    tmp_path.mkdir(parents=True, exist_ok=True)
    lock_path.write_text("not-json-at-all", encoding="utf-8")
    assert acquire_a2a_sync_lock(tmp_path, "ch1") is False


def test_lock_with_missing_timestamp_treated_as_held(tmp_path: Path) -> None:
    """Lock JSON exists but no ``timestamp`` field — OC's ``typeof`` check
    fails so we fall through to the held branch. Hermes mirrors.
    """
    lock_path = _sync_lock_path(tmp_path, "ch1")
    tmp_path.mkdir(parents=True, exist_ok=True)
    lock_path.write_text(json.dumps({"pid": 1234}), encoding="utf-8")
    assert acquire_a2a_sync_lock(tmp_path, "ch1") is False


# ---------------------------------------------------------------------------
# Directory creation
# ---------------------------------------------------------------------------


def test_acquire_creates_missing_data_dir(tmp_path: Path) -> None:
    target = tmp_path / "nested" / "data"
    assert not target.exists()
    assert acquire_a2a_sync_lock(target, "ch1") is True
    assert target.is_dir()


@pytest.mark.skipif(
    sys.platform == "win32",
    reason="POSIX file-mode bits are not meaningful on Windows",
)
def test_acquire_creates_data_dir_with_mode_0o700(tmp_path: Path) -> None:
    """OC mls-state.ts:28 specifies ``mode: DIR_MODE`` (0o700)."""
    target = tmp_path / "fresh-dir"
    acquire_a2a_sync_lock(target, "ch1")
    mode = stat.S_IMODE(target.stat().st_mode)
    assert mode == 0o700


# ---------------------------------------------------------------------------
# Concurrent access
# ---------------------------------------------------------------------------


def test_concurrent_acquire_only_one_wins(tmp_path: Path) -> None:
    """Many threads racing to acquire the same channel lock — exactly
    one returns True. Tests the atomicity of the O_CREAT|O_EXCL primitive.

    OS-level guarantees: ``os.open(O_CREAT|O_EXCL)`` is atomic w.r.t.
    concurrent racers on POSIX. On Windows, Python's open emulates the
    same semantics. This test directly exercises that contract.
    """
    n_threads = 20
    results: list[bool] = []
    results_lock = threading.Lock()
    barrier = threading.Barrier(n_threads)

    def attempt() -> None:
        barrier.wait()
        ok = acquire_a2a_sync_lock(tmp_path, "race-channel")
        with results_lock:
            results.append(ok)

    threads = [threading.Thread(target=attempt) for _ in range(n_threads)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    # Exactly one True; the rest False.
    assert results.count(True) == 1
    assert results.count(False) == n_threads - 1
