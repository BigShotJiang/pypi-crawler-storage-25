"""Unit test: an A2A Welcome is no longer ack-dropped by the guard.

This pins the guard's removal. The full A2A Welcome -> join is exercised by
the integration test (Task 13); here we assert only that an a2a_channel_id
Welcome is NOT short-circuited to drop=True before the join path runs.
"""
from __future__ import annotations

import inspect

from agentvault_hermes.channel import inbox


def test_no_a2a_channel_id_drop_guard_in_handle_mls_welcome() -> None:
    src = inspect.getsource(inbox.handle_mls_welcome)
    # The deliberate out-of-scope ack+drop guard must be gone.
    assert "a2a_channel_id set; out of scope" not in src
