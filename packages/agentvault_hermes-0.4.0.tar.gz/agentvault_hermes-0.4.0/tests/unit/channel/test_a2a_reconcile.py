"""Unit tests for the A2A connect-time reconciliation recovery routine."""
from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

from agentvault_hermes.channel.a2a_lifecycle import A2ALifecycleHandler
from agentvault_hermes.channel.a2a_registry import A2AChannelRegistry

_CHANNEL_ID = "11111111-1111-1111-1111-111111111111"


def _handler(tmp_path: Path) -> tuple[A2ALifecycleHandler, A2AChannelRegistry,
                                      AsyncMock, AsyncMock]:
    registry = A2AChannelRegistry()
    ensure_kp = AsyncMock(name="ensure_key_package")
    request_welcome = AsyncMock(name="request_welcome")
    handler = A2ALifecycleHandler(
        registry, tmp_path, own_hub_id="own",
        ensure_key_package=ensure_kp,
        drop_channel_mls=AsyncMock(),
        request_welcome=request_welcome,
    )
    return handler, registry, ensure_kp, request_welcome


@pytest.mark.asyncio
async def test_recover_unjoined_channel_publishes_kp_and_requests_welcome(
    tmp_path: Path,
) -> None:
    handler, registry, ensure_kp, request_welcome = _handler(tmp_path)
    entry = registry.upsert_from_event({"channel_id": _CHANNEL_ID})
    assert entry.mls_group_id is None
    await handler.recover_unjoined_channel(entry)
    ensure_kp.assert_awaited_once()
    request_welcome.assert_awaited_once_with(_CHANNEL_ID)


@pytest.mark.asyncio
async def test_recover_skips_already_joined_channel(tmp_path: Path) -> None:
    handler, registry, ensure_kp, request_welcome = _handler(tmp_path)
    entry = registry.record_welcome(_CHANNEL_ID, "group-1")  # joined
    await handler.recover_unjoined_channel(entry)
    ensure_kp.assert_not_awaited()
    request_welcome.assert_not_awaited()


# --- Slice B: creator-role reconcile branch ----------------------------


def _handler_with_founder(
    tmp_path: Path,
) -> tuple[
    A2ALifecycleHandler, A2AChannelRegistry, AsyncMock, AsyncMock, AsyncMock
]:
    """Variant of _handler that also wires found_a2a_group (Slice B)."""
    registry = A2AChannelRegistry()
    ensure_kp = AsyncMock(name="ensure_key_package")
    request_welcome = AsyncMock(name="request_welcome")
    found_a2a_group = AsyncMock(name="found_a2a_group")
    handler = A2ALifecycleHandler(
        registry,
        tmp_path,
        own_hub_id="own",
        ensure_key_package=ensure_kp,
        drop_channel_mls=AsyncMock(),
        request_welcome=request_welcome,
        found_a2a_group=found_a2a_group,
    )
    return handler, registry, ensure_kp, request_welcome, found_a2a_group


@pytest.mark.asyncio
async def test_recover_creator_role_with_null_group_invokes_founder(
    tmp_path: Path,
) -> None:
    """Reconcile path for restart-recovery: a creator-role channel without
    mls_group_id triggers found_a2a_group, not request_welcome.

    Spec §5.4: ``_reconcile_a2a_channels`` -> ``recover_unjoined_channel``
    branches on role.
    """
    handler, registry, ensure_kp, request_welcome, found = _handler_with_founder(
        tmp_path
    )
    entry = registry.upsert_from_event({"channel_id": _CHANNEL_ID, "role": "creator"})
    assert entry.role == "creator"
    assert entry.mls_group_id is None

    await handler.recover_unjoined_channel(entry)

    found.assert_awaited_once()
    found.assert_awaited_with(_CHANNEL_ID, list(entry.participants.values()))
    # Slice A member-path NOT taken.
    ensure_kp.assert_not_awaited()
    request_welcome.assert_not_awaited()


@pytest.mark.asyncio
async def test_recover_member_role_with_null_group_still_requests_welcome(
    tmp_path: Path,
) -> None:
    """Slice A regression: member-role entries still go to request_welcome."""
    handler, registry, ensure_kp, request_welcome, found = _handler_with_founder(
        tmp_path
    )
    entry = registry.upsert_from_event({"channel_id": _CHANNEL_ID, "role": "member"})

    await handler.recover_unjoined_channel(entry)

    found.assert_not_awaited()
    ensure_kp.assert_awaited_once()
    request_welcome.assert_awaited_once_with(_CHANNEL_ID)


@pytest.mark.asyncio
async def test_recover_creator_role_with_set_group_skipped(
    tmp_path: Path,
) -> None:
    """Channels with mls_group_id already set are not re-founded."""
    handler, registry, ensure_kp, request_welcome, found = _handler_with_founder(
        tmp_path
    )
    entry = registry.upsert_from_event({"channel_id": _CHANNEL_ID, "role": "creator"})
    entry.mls_group_id = "grp-xyz"

    await handler.recover_unjoined_channel(entry)

    found.assert_not_awaited()
    ensure_kp.assert_not_awaited()
    request_welcome.assert_not_awaited()


@pytest.mark.asyncio
async def test_recover_creator_role_without_founder_wired_logs_and_skips(
    tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    """Defensive: Slice-A-only construction (no found_a2a_group) — creator
    entries log a warning and skip rather than falling back to the member
    path."""
    import logging

    handler, registry, ensure_kp, request_welcome = _handler(tmp_path)
    entry = registry.upsert_from_event({"channel_id": _CHANNEL_ID, "role": "creator"})

    with caplog.at_level(
        logging.WARNING, logger="agentvault_hermes.channel.a2a_lifecycle"
    ):
        await handler.recover_unjoined_channel(entry)

    assert any(
        "creator" in r.message and "no founder" in r.message for r in caplog.records
    )
    # Critically: we must NOT fall through to the member-path here — the
    # member path would publish a KP and request a Welcome from ourselves,
    # which is a no-op at best and a confusing log line at worst.
    ensure_kp.assert_not_awaited()
    request_welcome.assert_not_awaited()
