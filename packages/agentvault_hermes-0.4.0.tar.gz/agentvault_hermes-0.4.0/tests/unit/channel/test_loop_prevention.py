"""Unit tests for ``agentvault_hermes.channel.loop_prevention``.

Reproduces the OC table from ``packages/plugin/src/openclaw-entry.ts:37-88``.
Plan ref: ``docs/plans/2026-05-10-hermes-phase3-implementation.md`` §8.7.

Time is faked via a per-test ``FakeClock`` injected with monkeypatch on
``agentvault_hermes.channel.loop_prevention.time.monotonic`` so we never
sleep in tests and the sliding-window math is deterministic.
"""
from __future__ import annotations

import pytest

from agentvault_hermes.channel import loop_prevention as lp_module
from agentvault_hermes.channel.loop_prevention import (
    LOOP_COOLDOWN_SECONDS,
    LOOP_MAX_REPLIES_PER_WINDOW,
    LOOP_WINDOW_SECONDS,
    LoopPreventer,
)


class FakeClock:
    """Manually-advanced clock; replaces ``time.monotonic``."""

    def __init__(self, start: float = 1_000_000.0) -> None:
        self.now = start

    def __call__(self) -> float:
        return self.now

    def advance(self, seconds: float) -> None:
        self.now += seconds


@pytest.fixture
def clock(monkeypatch: pytest.MonkeyPatch) -> FakeClock:
    fake = FakeClock()
    # Patch the bound name in the module's `time` reference. The module
    # calls `time.monotonic()` (not a re-imported function), so we patch
    # the underlying attribute on the stdlib `time` module that the
    # module's `time` symbol points at.
    monkeypatch.setattr(lp_module.time, "monotonic", fake)
    return fake


# ---------------------------------------------------------------------------
# Constants — assert byte-exact OC parity
# ---------------------------------------------------------------------------


def test_constants_match_oc_byte_exact() -> None:
    """OC constants at openclaw-entry.ts:41-43.

    LOOP_MAX_REPLIES_PER_WINDOW = 4
    LOOP_WINDOW_MS = 60_000   (60s)
    LOOP_COOLDOWN_MS = 120_000 (120s)
    """
    assert LOOP_MAX_REPLIES_PER_WINDOW == 4
    assert LOOP_WINDOW_SECONDS == 60.0
    assert LOOP_COOLDOWN_SECONDS == 120.0


# ---------------------------------------------------------------------------
# Sliding-window allowance
# ---------------------------------------------------------------------------


def test_initial_state_allows_reply(clock: FakeClock) -> None:
    lp = LoopPreventer()
    assert lp.can_reply("key1") is True


def test_first_four_replies_allowed_within_window(clock: FakeClock) -> None:
    lp = LoopPreventer()
    for _ in range(4):
        assert lp.can_reply("key1") is True
        lp.record_reply("key1")
        clock.advance(1.0)  # 1s between replies
    # After 4 replies in ~3s, the next can_reply must say False
    assert lp.can_reply("key1") is False


def test_fifth_reply_blocked_and_enters_cooldown(clock: FakeClock) -> None:
    lp = LoopPreventer()
    for _ in range(LOOP_MAX_REPLIES_PER_WINDOW):
        lp.record_reply("key1")
        clock.advance(0.5)
    # Hit limit
    assert lp.can_reply("key1") is False
    # Cooldown begins NOW; must remain False until LOOP_COOLDOWN_SECONDS pass
    clock.advance(60.0)  # halfway through the cooldown
    assert lp.can_reply("key1") is False


def test_cooldown_clears_after_full_duration(clock: FakeClock) -> None:
    lp = LoopPreventer()
    for _ in range(LOOP_MAX_REPLIES_PER_WINDOW):
        lp.record_reply("key1")
    # Trigger cooldown by exceeding limit
    assert lp.can_reply("key1") is False
    # Advance past cooldown end
    clock.advance(LOOP_COOLDOWN_SECONDS + 0.001)
    assert lp.can_reply("key1") is True


def test_old_replies_drop_out_of_window(clock: FakeClock) -> None:
    """Five replies spread over 70s: oldest is >60s in the past, so only
    4 are within the sliding window — 5th can_reply is allowed.
    """
    lp = LoopPreventer()
    # First reply at t=0
    lp.record_reply("key1")
    # Advance 21s, second reply at t=21
    clock.advance(21.0)
    lp.record_reply("key1")
    # Advance 21s, third reply at t=42
    clock.advance(21.0)
    lp.record_reply("key1")
    # Advance 21s, fourth reply at t=63
    # (the t=0 one is now 63s old, drops out of 60s window)
    clock.advance(21.0)
    lp.record_reply("key1")
    # Advance 7s: fifth reply at t=70 — should still be allowed because
    # the t=0 entry is dropped, leaving only 3 recent + this candidate < 4.
    clock.advance(7.0)
    assert lp.can_reply("key1") is True


# ---------------------------------------------------------------------------
# Per-key independence
# ---------------------------------------------------------------------------


def test_distinct_keys_are_independent(clock: FakeClock) -> None:
    lp = LoopPreventer()
    for _ in range(LOOP_MAX_REPLIES_PER_WINDOW):
        lp.record_reply("key1")
    # key1 is now blocked
    assert lp.can_reply("key1") is False
    # key2 must remain unaffected
    assert lp.can_reply("key2") is True


def test_a2a_and_room_helpers_are_namespaced(clock: FakeClock) -> None:
    """``can_reply_a2a("foo")`` must be independent of
    ``can_reply_room("foo")`` because the keys are
    ``"a2a:foo"`` vs ``"room:foo"``.
    """
    lp = LoopPreventer()
    for _ in range(LOOP_MAX_REPLIES_PER_WINDOW):
        lp.record_reply_a2a("foo")
    # a2a:foo is blocked
    assert lp.can_reply_a2a("foo") is False
    # room:foo must NOT be affected
    assert lp.can_reply_room("foo") is True


def test_a2a_helper_prefixes_with_a2a(clock: FakeClock) -> None:
    """``record_reply_a2a("c")`` must register under key ``"a2a:c"``
    such that ``can_reply("a2a:c")`` reports the same state.
    """
    lp = LoopPreventer()
    for _ in range(LOOP_MAX_REPLIES_PER_WINDOW):
        lp.record_reply_a2a("conv1")
    assert lp.can_reply("a2a:conv1") is False


def test_room_helper_prefixes_with_room(clock: FakeClock) -> None:
    lp = LoopPreventer()
    for _ in range(LOOP_MAX_REPLIES_PER_WINDOW):
        lp.record_reply_room("rm1")
    assert lp.can_reply("room:rm1") is False


# ---------------------------------------------------------------------------
# Internal state hygiene
# ---------------------------------------------------------------------------


def test_record_reply_prunes_old_timestamps(clock: FakeClock) -> None:
    """``record_reply`` should retain only timestamps within the window
    so the per-key list never grows unboundedly. After 100 replies
    each spaced 1s apart, the list should hold ~LOOP_WINDOW_SECONDS
    entries (60), not 100.
    """
    lp = LoopPreventer()
    for _ in range(100):
        lp.record_reply("k")
        clock.advance(1.0)
    timestamps = lp._reply_timestamps["k"]  # noqa: SLF001 — internal probe is intentional
    # All retained timestamps must be within the window of "now" (after the
    # final advance). Since `record_reply` prunes during its own call, the
    # final call's 'now' was right after the last advance — but we
    # advanced one more time after the final record_reply, so the bound
    # is 60s relative to the final record_reply's `now`.
    assert len(timestamps) <= LOOP_WINDOW_SECONDS + 1


def test_cooldown_clears_timestamps(clock: FakeClock) -> None:
    """When the limit is hit, ``can_reply`` resets ``_reply_timestamps[key]``
    to ``[]`` per OC openclaw-entry.ts:63. Verify directly.
    """
    lp = LoopPreventer()
    for _ in range(LOOP_MAX_REPLIES_PER_WINDOW):
        lp.record_reply("k")
    # This call triggers cooldown and clears the list
    assert lp.can_reply("k") is False
    assert lp._reply_timestamps["k"] == []  # noqa: SLF001


# ---------------------------------------------------------------------------
# Cooldown does not require record_reply to trigger — only can_reply
# ---------------------------------------------------------------------------


def test_can_reply_does_not_record(clock: FakeClock) -> None:
    """A True from ``can_reply`` must NOT record a reply. Only
    ``record_reply`` records.
    """
    lp = LoopPreventer()
    for _ in range(100):
        assert lp.can_reply("k") is True  # never records
    # Still no replies recorded — a subsequent record_reply + can_reply
    # cycle should behave as if fresh.
    lp.record_reply("k")
    assert lp.can_reply("k") is True
