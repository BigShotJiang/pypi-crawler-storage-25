"""Tests for device key generation."""
from __future__ import annotations

from nacl import signing

from agentvault_hermes.core.identity.device import (
    DeviceKeys,
    generate_device_keys,
)


def test_generate_returns_three_distinct_keys():
    keys = generate_device_keys()
    assert isinstance(keys, DeviceKeys)
    assert keys.signing_secret != keys.x25519_secret
    assert keys.signing_secret != keys.mls_init_secret
    assert keys.x25519_secret != keys.mls_init_secret


def test_signing_key_is_ed25519_32_bytes():
    keys = generate_device_keys()
    assert len(keys.signing_secret) == 32
    assert len(keys.signing_public) == 32


def test_x25519_key_is_32_bytes():
    keys = generate_device_keys()
    assert len(keys.x25519_secret) == 32
    assert len(keys.x25519_public) == 32


def test_mls_init_key_is_32_bytes():
    keys = generate_device_keys()
    assert len(keys.mls_init_secret) == 32
    assert len(keys.mls_init_public) == 32


def test_signing_key_round_trip():
    keys = generate_device_keys()
    sk = signing.SigningKey(keys.signing_secret)
    msg = b"verify me"
    signature = sk.sign(msg)
    sk.verify_key.verify(signature.message, signature.signature)


def test_each_call_produces_unique_keys():
    a = generate_device_keys()
    b = generate_device_keys()
    assert a.signing_secret != b.signing_secret
    assert a.x25519_secret != b.x25519_secret
    assert a.mls_init_secret != b.mls_init_secret
