"""Tests for the enrollment payload builder.

The AV backend's POST /api/v1/enroll verifies an Ed25519 self-signature
over the identity public key. These tests assert the payload shape +
that backend-style verification passes.
"""
from __future__ import annotations


from agentvault_hermes.core.identity.device import generate_device_keys
from agentvault_hermes.core.identity.enrollment_payload import (
    build_enrollment_payload,
    verify_proof_of_possession,
)


def test_payload_has_required_fields():
    keys = generate_device_keys()
    payload = build_enrollment_payload(keys, invite_token="av_inv_test")

    assert payload["invite_token"] == "av_inv_test"
    assert "identity_public_key" in payload
    assert "ephemeral_public_key" in payload
    assert "proof_of_possession" in payload


def test_pubkeys_are_hex_encoded_32_bytes():
    keys = generate_device_keys()
    payload = build_enrollment_payload(keys, invite_token="t")

    assert len(payload["identity_public_key"]) == 64
    assert len(payload["ephemeral_public_key"]) == 64
    assert len(payload["proof_of_possession"]) == 128

    bytes.fromhex(payload["identity_public_key"])
    bytes.fromhex(payload["ephemeral_public_key"])
    bytes.fromhex(payload["proof_of_possession"])


def test_identity_matches_signing_pubkey():
    """identity_public_key must be the Ed25519 signing public key."""
    keys = generate_device_keys()
    payload = build_enrollment_payload(keys, invite_token="t")

    assert bytes.fromhex(payload["identity_public_key"]) == keys.signing_public


def test_ephemeral_matches_x25519_pubkey():
    """ephemeral_public_key must be the X25519 ratchet public key."""
    keys = generate_device_keys()
    payload = build_enrollment_payload(keys, invite_token="t")

    assert bytes.fromhex(payload["ephemeral_public_key"]) == keys.x25519_public


def test_proof_verifies_against_identity_pubkey():
    """The backend's verify call must succeed: verify(identity_pubkey, sig)."""
    keys = generate_device_keys()
    payload = build_enrollment_payload(keys, invite_token="t")

    assert verify_proof_of_possession(payload) is True


def test_proof_fails_with_tampered_identity_pubkey():
    keys = generate_device_keys()
    payload = build_enrollment_payload(keys, invite_token="t")

    tampered = dict(payload)
    tampered["identity_public_key"] = "0" * len(payload["identity_public_key"])
    assert verify_proof_of_possession(tampered) is False


def test_proof_fails_with_wrong_signing_key():
    """Signing the identity pubkey of A with B's private key must not verify."""
    keys_a = generate_device_keys()
    keys_b = generate_device_keys()
    payload = build_enrollment_payload(keys_a, invite_token="t")

    tampered = dict(payload)
    tampered["identity_public_key"] = keys_b.signing_public.hex()
    assert verify_proof_of_possession(tampered) is False


def test_platform_optional():
    keys = generate_device_keys()

    no_platform = build_enrollment_payload(keys, invite_token="t")
    assert "platform" not in no_platform

    with_platform = build_enrollment_payload(keys, invite_token="t", platform="hermes-1.0")
    assert with_platform["platform"] == "hermes-1.0"
