"""Tests for state.json persistence."""
from __future__ import annotations

import os
import stat
from pathlib import Path

import pytest

from agentvault_hermes.core.identity.credentials import (
    PersistedState,
    load_state,
    save_state,
)
from agentvault_hermes.core.identity.device import generate_device_keys


def test_load_returns_none_when_no_file(tmp_data_dir: Path):
    assert load_state(tmp_data_dir) is None


def test_save_then_load_round_trip(tmp_data_dir: Path):
    keys = generate_device_keys()
    state = PersistedState(
        device_id="dev_abc123",
        tenant_id="tenant_xyz789",
        device_jwt="ey.jwt.token",
        device_keys=keys,
    )
    save_state(tmp_data_dir, state)

    loaded = load_state(tmp_data_dir)
    assert loaded is not None
    assert loaded.device_id == state.device_id
    assert loaded.tenant_id == state.tenant_id
    assert loaded.device_jwt == state.device_jwt
    assert loaded.device_keys.signing_secret == keys.signing_secret
    assert loaded.device_keys.signing_public == keys.signing_public


def test_state_file_has_secure_mode(tmp_data_dir: Path):
    keys = generate_device_keys()
    state = PersistedState(
        device_id="dev_test",
        tenant_id="tenant_test",
        device_jwt="jwt",
        device_keys=keys,
    )
    save_state(tmp_data_dir, state)

    state_file = tmp_data_dir / "state.json"
    assert state_file.exists()

    if os.name == "posix":
        mode = stat.S_IMODE(state_file.stat().st_mode)
        assert mode == 0o600, f"state.json mode is {oct(mode)}, expected 0o600"


def test_save_overwrites_existing(tmp_data_dir: Path):
    keys1 = generate_device_keys()
    state1 = PersistedState(
        device_id="dev_first",
        tenant_id="tenant_first",
        device_jwt="jwt1",
        device_keys=keys1,
    )
    save_state(tmp_data_dir, state1)

    keys2 = generate_device_keys()
    state2 = PersistedState(
        device_id="dev_second",
        tenant_id="tenant_second",
        device_jwt="jwt2",
        device_keys=keys2,
    )
    save_state(tmp_data_dir, state2)

    loaded = load_state(tmp_data_dir)
    assert loaded is not None
    assert loaded.device_id == "dev_second"


def test_load_corrupt_file_raises(tmp_data_dir: Path):
    state_file = tmp_data_dir / "state.json"
    tmp_data_dir.mkdir(parents=True, exist_ok=True)
    state_file.write_text("not valid json {")

    with pytest.raises(ValueError, match="state.json"):
        load_state(tmp_data_dir)


def test_save_creates_data_dir_if_missing(tmp_data_dir: Path):
    nested = tmp_data_dir / "deep" / "nested"
    keys = generate_device_keys()
    state = PersistedState(
        device_id="dev_test",
        tenant_id="tenant_test",
        device_jwt="jwt",
        device_keys=keys,
    )
    save_state(nested, state)
    assert nested.exists()
    assert (nested / "state.json").exists()
