"""Unit tests for setup's 'seed from default profile' step.

A new named profile is functionally useless without (a) a `model:` block in
its config.yaml and (b) API keys in its .env. Real Hermes 0.13.0's
`hermes profile create` writes neither, and our `_modify_hermes_config`
only writes AV-plugin entries. So `setup --profile <name>` leaves the
customer staring at HTTP 400 ("No models provided") or a hung gateway.

These tests pin the seeding behaviour that closes that gap by copying
both pieces forward from the default profile.
"""
from __future__ import annotations

import os
import stat
from pathlib import Path

from ruamel.yaml import YAML

from agentvault_hermes.cli.setup import _seed_profile_from_default


def _write_yaml(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    YAML().dump(payload, path.open("w"))


def test_seed_is_noop_for_default_profile(
    fake_hermes_home: Path,
) -> None:
    """profile=None means the *source* — nothing to copy."""
    result = _seed_profile_from_default(None)

    assert result == {"model_copied": False, "env_copied": False}


def test_seed_skips_when_default_config_absent(
    fake_hermes_home: Path,
) -> None:
    """No default config.yaml → no-op (graceful, not an error)."""
    profile_dir = fake_hermes_home / ".hermes" / "profiles" / "work"
    profile_dir.mkdir(parents=True)
    (profile_dir / "config.yaml").write_text("{}\n", encoding="utf-8")

    result = _seed_profile_from_default("work")

    assert result["model_copied"] is False


def test_seed_copies_model_block_when_profile_lacks_one(
    fake_hermes_home: Path,
) -> None:
    """Default has model → profile (without model) gets it copied in."""
    default_cfg = fake_hermes_home / ".hermes" / "config.yaml"
    _write_yaml(
        default_cfg,
        {
            "model": {
                "default": "nvidia/nemotron-3-super-120b-a12b:free",
                "provider": "openrouter",
                "base_url": "https://openrouter.ai/api/v1",
                "api_mode": "chat_completions",
            },
            # noise that should NOT bleed into the profile config
            "display": {"personality": "kawaii"},
        },
    )
    profile_cfg = fake_hermes_home / ".hermes" / "profiles" / "work" / "config.yaml"
    _write_yaml(profile_cfg, {})

    result = _seed_profile_from_default("work")

    assert result["model_copied"] is True
    loaded = YAML().load(profile_cfg.read_text())
    assert loaded["model"]["default"] == "nvidia/nemotron-3-super-120b-a12b:free"
    assert loaded["model"]["provider"] == "openrouter"
    # Only the model block is copied — unrelated default-profile keys MUST NOT leak.
    assert "display" not in loaded


def test_seed_preserves_existing_model_in_profile(
    fake_hermes_home: Path,
) -> None:
    """A profile that already chose a model is not silently overwritten."""
    default_cfg = fake_hermes_home / ".hermes" / "config.yaml"
    _write_yaml(default_cfg, {"model": {"default": "default-model", "provider": "openrouter"}})
    profile_cfg = fake_hermes_home / ".hermes" / "profiles" / "work" / "config.yaml"
    _write_yaml(profile_cfg, {"model": {"default": "custom-model", "provider": "openrouter"}})

    result = _seed_profile_from_default("work")

    assert result["model_copied"] is False
    loaded = YAML().load(profile_cfg.read_text())
    assert loaded["model"]["default"] == "custom-model"


def test_seed_preserves_plugin_entries_in_profile(
    fake_hermes_home: Path,
) -> None:
    """If _modify_hermes_config ran first (or runs later), seeding must merge cleanly."""
    default_cfg = fake_hermes_home / ".hermes" / "config.yaml"
    _write_yaml(default_cfg, {"model": {"default": "m", "provider": "openrouter"}})

    profile_cfg = fake_hermes_home / ".hermes" / "profiles" / "work" / "config.yaml"
    _write_yaml(
        profile_cfg,
        {
            "mcp_servers": {"agentvault": {"command": "agentvault-hermes", "args": ["serve"]}},
            "plugins": {"enabled": ["agentvault"]},
            "gateway": {"platforms": {"agentvault": {"enabled": True}}},
        },
    )

    _seed_profile_from_default("work")

    loaded = YAML().load(profile_cfg.read_text())
    # plugin entries survived intact
    assert loaded["plugins"]["enabled"] == ["agentvault"]
    assert loaded["gateway"]["platforms"]["agentvault"]["enabled"] is True
    assert loaded["mcp_servers"]["agentvault"]["command"] == "agentvault-hermes"
    # model block was added alongside
    assert loaded["model"]["default"] == "m"


def test_seed_copies_env_when_profile_env_absent(
    fake_hermes_home: Path,
) -> None:
    """Default .env exists, profile .env doesn't → copy verbatim."""
    default_env = fake_hermes_home / ".hermes" / ".env"
    default_env.parent.mkdir(parents=True, exist_ok=True)
    default_env.write_text(
        "OPENROUTER_API_KEY=sk-fake-1\nDEEPSEEK_API_KEY=sk-fake-2\n",
        encoding="utf-8",
    )
    profile_dir = fake_hermes_home / ".hermes" / "profiles" / "work"
    profile_dir.mkdir(parents=True)
    (profile_dir / "config.yaml").write_text("{}\n", encoding="utf-8")

    result = _seed_profile_from_default("work")

    assert result["env_copied"] is True
    profile_env = profile_dir / ".env"
    assert profile_env.exists()
    assert profile_env.read_text(encoding="utf-8") == (
        "OPENROUTER_API_KEY=sk-fake-1\nDEEPSEEK_API_KEY=sk-fake-2\n"
    )


def test_seed_does_not_overwrite_existing_env(
    fake_hermes_home: Path,
) -> None:
    """Customer may have already set keys for this profile — don't clobber them."""
    default_env = fake_hermes_home / ".hermes" / ".env"
    default_env.parent.mkdir(parents=True, exist_ok=True)
    default_env.write_text("OPENROUTER_API_KEY=default\n", encoding="utf-8")

    profile_dir = fake_hermes_home / ".hermes" / "profiles" / "work"
    profile_dir.mkdir(parents=True)
    (profile_dir / "config.yaml").write_text("{}\n", encoding="utf-8")
    (profile_dir / ".env").write_text("OPENROUTER_API_KEY=custom\n", encoding="utf-8")

    result = _seed_profile_from_default("work")

    assert result["env_copied"] is False
    assert (profile_dir / ".env").read_text(encoding="utf-8") == "OPENROUTER_API_KEY=custom\n"


def test_seed_skips_env_when_default_env_absent(
    fake_hermes_home: Path,
) -> None:
    """No default .env → no-op, no error."""
    default_cfg = fake_hermes_home / ".hermes" / "config.yaml"
    _write_yaml(default_cfg, {"model": {"default": "m", "provider": "openrouter"}})

    profile_dir = fake_hermes_home / ".hermes" / "profiles" / "work"
    profile_dir.mkdir(parents=True)
    (profile_dir / "config.yaml").write_text("{}\n", encoding="utf-8")

    result = _seed_profile_from_default("work")

    assert result["env_copied"] is False
    assert not (profile_dir / ".env").exists()


def test_seed_env_preserves_owner_only_permissions(
    fake_hermes_home: Path,
) -> None:
    """The default .env is chmod 600 in the wild; the copy must inherit that."""
    default_env = fake_hermes_home / ".hermes" / ".env"
    default_env.parent.mkdir(parents=True, exist_ok=True)
    default_env.write_text("OPENROUTER_API_KEY=sk\n", encoding="utf-8")
    os.chmod(default_env, 0o600)

    profile_dir = fake_hermes_home / ".hermes" / "profiles" / "work"
    profile_dir.mkdir(parents=True)
    (profile_dir / "config.yaml").write_text("{}\n", encoding="utf-8")

    _seed_profile_from_default("work")

    profile_env = profile_dir / ".env"
    mode = stat.S_IMODE(profile_env.stat().st_mode)
    # Group + other bits must be off — credentials must not leak to other accounts.
    assert mode & 0o077 == 0, f"profile .env mode {oct(mode)} exposes credentials"


def test_seed_with_no_default_anything_is_silent_noop(
    fake_hermes_home: Path,
) -> None:
    """First-ever profile setup with nothing configured anywhere — no crash."""
    profile_dir = fake_hermes_home / ".hermes" / "profiles" / "work"
    profile_dir.mkdir(parents=True)
    (profile_dir / "config.yaml").write_text("{}\n", encoding="utf-8")

    result = _seed_profile_from_default("work")

    assert result == {"model_copied": False, "env_copied": False}
