"""Unit test: the CLI exposes --profile on setup and doctor."""
from __future__ import annotations

from typing import Any

import pytest
from click.testing import CliRunner

from agentvault_hermes.cli.__main__ import cli


def test_setup_help_has_profile_not_account() -> None:
    out = CliRunner().invoke(cli, ["setup", "--help"]).output
    assert "--profile" in out
    assert "--account" not in out


def test_doctor_help_has_profile() -> None:
    out = CliRunner().invoke(cli, ["doctor", "--help"]).output
    assert "--profile" in out
    assert "--account" not in out


def test_setup_accepts_profile_argument(monkeypatch: pytest.MonkeyPatch) -> None:
    """`setup --profile work --token=x` runs the body without TypeError.

    Regression: the body invokes ``run_setup(token=..., profile=...)``. If
    that kwarg ever desyncs from the CLI flag rename, this test catches it
    (the ``--help`` tests cannot — they short-circuit before the body runs).
    """
    from agentvault_hermes.cli import __main__ as main_module
    from agentvault_hermes.cli.setup import SetupResult

    received: dict[str, Any] = {}

    async def fake_run_setup(token: str, profile: str | None = None) -> SetupResult:
        received["token"] = token
        received["profile"] = profile
        return SetupResult(success=True, device_id="dev_x", tenant_id="ten_x")

    monkeypatch.setattr(main_module, "run_setup", fake_run_setup)

    result = CliRunner().invoke(
        cli, ["setup", "--token", "av_tok_x", "--profile", "work"]
    )
    assert result.exit_code == 0, result.output
    assert received.get("profile") == "work"
    assert received.get("token") == "av_tok_x"


def test_doctor_accepts_profile_argument(monkeypatch: pytest.MonkeyPatch) -> None:
    """`doctor --profile work` runs the body without TypeError.

    Regression: the CLI body invokes ``run_doctor(profile=...)``. If the
    kwarg name ever desyncs from the CLI flag rename, this test catches it
    (the ``--help`` tests cannot — they short-circuit before the body runs).

    The fake mirrors the real ``run_doctor`` signature (``profile=None``)
    so a kwarg-name mismatch raises ``TypeError`` here exactly as it would
    against the real function.
    """
    from agentvault_hermes.cli import __main__ as main_module
    from agentvault_hermes.cli.doctor import DoctorResult

    received: dict[str, Any] = {}

    async def fake_run_doctor(profile: str | None = None) -> DoctorResult:
        received["profile"] = profile
        return DoctorResult()  # checks={} -> all_green=True -> no sys.exit

    monkeypatch.setattr(main_module, "run_doctor", fake_run_doctor)

    result = CliRunner().invoke(cli, ["doctor", "--profile", "work"])
    assert result.exit_code == 0, result.output
    # The profile value must round-trip through the profile kwarg.
    assert "work" in received.values()
