"""Unit tests for setup's 'ensure Hermes profile exists' step."""
from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from agentvault_hermes.cli.setup import ensure_profile_exists


def test_skips_create_when_profile_dir_exists(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    (fake_hermes_home / ".hermes" / "profiles" / "work").mkdir(parents=True)
    called = MagicMock()
    monkeypatch.setattr(subprocess, "run", called)

    ensure_profile_exists("work")

    called.assert_not_called()


def test_runs_hermes_profile_create_when_missing(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    # Side effect: simulate real Hermes 0.13.0 creating the profile dir
    # (but NOT config.yaml — the production code seeds that itself).
    def fake_run(args, **kwargs):  # type: ignore[no-untyped-def]
        (fake_hermes_home / ".hermes" / "profiles" / "work").mkdir(
            parents=True, exist_ok=True
        )
        return subprocess.CompletedProcess(args, 0, "", "")
    run = MagicMock(side_effect=fake_run)
    monkeypatch.setattr(subprocess, "run", run)

    ensure_profile_exists("work")

    run.assert_called_once()
    args = run.call_args[0][0]
    assert args[:3] == ["hermes", "profile", "create"]
    assert args[3] == "work"
    # Pin the kwargs so a future drop of text=True doesn't silently make
    # result.stderr a bytes object that explodes at .strip() in the error path.
    kwargs = run.call_args[1]
    assert kwargs.get("capture_output") is True
    assert kwargs.get("text") is True


def test_raises_clear_error_when_create_fails(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    run = MagicMock(
        return_value=subprocess.CompletedProcess([], 1, "", "unknown command 'profile'")
    )
    monkeypatch.setattr(subprocess, "run", run)

    with pytest.raises(RuntimeError, match="profile"):
        ensure_profile_exists("work")


def test_noop_for_default_profile() -> None:
    # profile=None → default profile, nothing to create.
    ensure_profile_exists(None)  # must not raise, must not shell out


def test_raises_runtime_error_when_hermes_not_on_path(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """`hermes` missing from PATH → RuntimeError (not raw FileNotFoundError)."""
    def boom(*args, **kwargs):
        raise FileNotFoundError("hermes")
    monkeypatch.setattr(subprocess, "run", boom)

    with pytest.raises(RuntimeError, match="not found on PATH"):
        ensure_profile_exists("work")


def test_rejects_invalid_profile_name() -> None:
    """Invalid profile names propagate ValueError from resolve_hermes_home."""
    with pytest.raises(ValueError):
        ensure_profile_exists("../escape")


def test_ensure_profile_exists_seeds_empty_config_when_hermes_did_not(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Hermes 0.13.0's `profile create` doesn't create config.yaml — we must fill the gap.

    Regression guard: live smoke on Hermes 0.13.0 showed `hermes profile create
    <name>` only writes SOUL.md and a few empty subdirs. Our _check_environment
    requires config.yaml to exist, so ensure_profile_exists must seed it.
    """
    def fake_run(args, **kwargs):  # type: ignore[no-untyped-def]
        if (
            isinstance(args, list)
            and len(args) >= 4
            and args[:3] == ["hermes", "profile", "create"]
        ):
            # Real Hermes 0.13.0: creates the profile dir BUT NOT config.yaml.
            (fake_hermes_home / ".hermes" / "profiles" / args[3]).mkdir(
                parents=True, exist_ok=True
            )
            return subprocess.CompletedProcess(args, 0, "", "")
        return subprocess.CompletedProcess(args, 0, "", "")
    monkeypatch.setattr(subprocess, "run", fake_run)

    ensure_profile_exists("work")

    config = fake_hermes_home / ".hermes" / "profiles" / "work" / "config.yaml"
    assert config.exists(), (
        "ensure_profile_exists must seed an empty config.yaml when Hermes doesn't"
    )
    assert config.read_text(encoding="utf-8") == "{}\n"


def test_ensure_profile_exists_does_not_overwrite_existing_config(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """If a future Hermes version DOES create config.yaml, we must not clobber it."""
    existing_yaml = "# user-authored or Hermes-authored config\nfoo: bar\n"

    def fake_run(args, **kwargs):  # type: ignore[no-untyped-def]
        if (
            isinstance(args, list)
            and len(args) >= 4
            and args[:3] == ["hermes", "profile", "create"]
        ):
            profile_dir = fake_hermes_home / ".hermes" / "profiles" / args[3]
            profile_dir.mkdir(parents=True, exist_ok=True)
            (profile_dir / "config.yaml").write_text(existing_yaml, encoding="utf-8")
            return subprocess.CompletedProcess(args, 0, "", "")
        return subprocess.CompletedProcess(args, 0, "", "")
    monkeypatch.setattr(subprocess, "run", fake_run)

    ensure_profile_exists("work")

    config = fake_hermes_home / ".hermes" / "profiles" / "work" / "config.yaml"
    assert config.read_text(encoding="utf-8") == existing_yaml, (
        "ensure_profile_exists must NOT overwrite a Hermes-authored config.yaml"
    )
