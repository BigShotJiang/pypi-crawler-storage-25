"""Unit test: _modify_hermes_config writes profile-model config keys.

Covers both the profile-model contract (no account_id, no env vars) and the
merge/preservation guarantees ported forward from the pre-refactor
test_setup_flow.py. These guard the most subtle prior DA findings (e.g. the
nanosecond-resolution backup filename) so a future refactor can't silently
regress them.
"""
from __future__ import annotations

from pathlib import Path

from ruamel.yaml import YAML

from agentvault_hermes.cli.setup import _modify_hermes_config


def test_modify_writes_no_account_keys(tmp_path: Path) -> None:
    config_path = tmp_path / "config.yaml"
    config_path.write_text("{}\n", encoding="utf-8")

    _modify_hermes_config(config_path)

    loaded = YAML().load(config_path.read_text())
    assert loaded["plugins"]["enabled"] == ["agentvault"]
    assert loaded["gateway"]["platforms"]["agentvault"]["enabled"] is True
    # account model is gone:
    assert "account_id" not in loaded["gateway"]["platforms"]["agentvault"]
    assert "AGENTVAULT_HERMES_ACCOUNT" not in (
        loaded["mcp_servers"]["agentvault"].get("env") or {}
    )


def test_modify_is_idempotent_across_reruns(tmp_path: Path) -> None:
    """A second _modify_hermes_config call on the same file produces no duplicate writes."""
    config_path = tmp_path / "config.yaml"
    config_path.write_text("{}\n", encoding="utf-8")

    _modify_hermes_config(config_path)
    first = config_path.read_text(encoding="utf-8")
    _modify_hermes_config(config_path)
    second = config_path.read_text(encoding="utf-8")

    assert first == second, "second call diverged from the first"

    # And a structural sanity check — no duplicate "agentvault" in plugins.enabled.
    loaded = YAML().load(second)
    assert loaded["plugins"]["enabled"].count("agentvault") == 1


def test_modify_preserves_existing_mcp_servers(tmp_path: Path) -> None:
    """An existing mcp_servers.<other> entry must survive alongside agentvault."""
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "mcp_servers:\n"
        "  foo:\n"
        "    command: foo-bin\n"
        "    args: [run]\n",
        encoding="utf-8",
    )

    _modify_hermes_config(config_path)

    loaded = YAML().load(config_path.read_text())
    assert loaded["mcp_servers"]["foo"]["command"] == "foo-bin"
    assert list(loaded["mcp_servers"]["foo"]["args"]) == ["run"]
    assert "agentvault" in loaded["mcp_servers"]


def test_modify_appends_to_existing_plugins_enabled(tmp_path: Path) -> None:
    """`plugins.enabled: [bar]` must become `[bar, agentvault]` — never overwrite."""
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "plugins:\n  enabled:\n    - bar\n",
        encoding="utf-8",
    )

    _modify_hermes_config(config_path)

    loaded = YAML().load(config_path.read_text())
    assert list(loaded["plugins"]["enabled"]) == ["bar", "agentvault"]


def test_modify_preserves_existing_gateway_platforms(tmp_path: Path) -> None:
    """An existing gateway.platforms.<other> entry must survive alongside agentvault."""
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "gateway:\n"
        "  platforms:\n"
        "    foo:\n"
        "      enabled: true\n",
        encoding="utf-8",
    )

    _modify_hermes_config(config_path)

    loaded = YAML().load(config_path.read_text())
    assert loaded["gateway"]["platforms"]["foo"]["enabled"] is True
    assert loaded["gateway"]["platforms"]["agentvault"]["enabled"] is True


def test_modify_preserves_yaml_comments(tmp_path: Path) -> None:
    """ruamel.yaml round-trips comments — verify against a representative fixture."""
    original = (
        "# top-level hermes config\n"
        "mcp_servers:\n"
        "  # existing entry\n"
        "  foo:\n"
        "    command: foo-bin\n"
    )
    config_path = tmp_path / "config.yaml"
    config_path.write_text(original, encoding="utf-8")

    _modify_hermes_config(config_path)

    new_text = config_path.read_text(encoding="utf-8")
    assert "# top-level hermes config" in new_text
    assert "# existing entry" in new_text


def test_modify_writes_backup(tmp_path: Path) -> None:
    """A timestamped backup of the pre-modification config must be written."""
    config_path = tmp_path / "config.yaml"
    original = "# pre-existing config\n"
    config_path.write_text(original, encoding="utf-8")

    _modify_hermes_config(config_path)

    backups = list(tmp_path.glob("config.yaml.backup-*"))
    assert len(backups) == 1, f"expected exactly 1 backup, got {len(backups)}: {backups}"
    assert backups[0].read_text(encoding="utf-8") == original


def test_modify_backup_filenames_unique_on_fast_reruns(tmp_path: Path) -> None:
    """Regression — DA WS-32+35 CRITICAL-1.

    The backup filename must include sub-second resolution so two
    sequential calls within the same wall-clock second don't overwrite
    the first backup with the now-modified config. Idempotent re-runs
    AND fast tests both hit this.
    """
    config_path = tmp_path / "config.yaml"
    config_path.write_text("{}\n", encoding="utf-8")

    _modify_hermes_config(config_path)
    _modify_hermes_config(config_path)

    backups = sorted(tmp_path.glob("config.yaml.backup-*"))
    assert len(backups) == 2, (
        f"expected 2 distinct backups, got {len(backups)}: {backups}"
    )
    # The two backups should have different names (nanosecond-resolution).
    assert backups[0].name != backups[1].name
    # And different content — the first backup is the original empty config,
    # the second is what was on disk after the first call (already modified).
    assert backups[0].read_text(encoding="utf-8") != backups[1].read_text(encoding="utf-8"), (
        "second backup overwrote the first — DA CRITICAL-1 regression"
    )
