"""Layer 1: run_setup must refuse with a friendly error when Hermes is
not installed — no state file write, no Hermes config write, non-zero
SetupResult. The pre-flight is the FIRST step ([1/9]) so it correctly
fires for the canonical "no Hermes installed" case."""
from __future__ import annotations

from pathlib import Path

import pytest

from agentvault_hermes.cli.setup import run_setup
from agentvault_hermes.core.detection.hermes import HermesDetectionResult


@pytest.mark.asyncio
async def test_run_setup_refuses_when_hermes_not_installed(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.delenv("HERMES_INSTALL_DIR", raising=False)
    monkeypatch.setenv("PATH", str(tmp_path))  # no hermes on PATH

    def _absent() -> HermesDetectionResult:
        return HermesDetectionResult(
            detected=False, tier=4,
            reason="no Hermes installation detected", install_dir=None,
        )
    monkeypatch.setattr(
        "agentvault_hermes.cli.setup.detect_hermes_install", _absent
    )

    result = await run_setup(token="av_tok_fake_value_for_test", profile=None)

    assert result.success is False
    assert result.error is not None
    assert "Hermes is not installed" in result.error
    assert "github.com/NousResearch/hermes-agent" in result.error
    assert "agentvault-hermes setup" in result.error

    # Canonical "no Hermes installed" state: NEITHER the AV-side state.json
    # NOR ~/.hermes/config.yaml should exist.
    av_state_root = home / ".hermes" / "agentvault"
    assert not av_state_root.exists() or not any(av_state_root.rglob("state.json"))
    assert not (home / ".hermes" / "config.yaml").exists()


@pytest.mark.asyncio
async def test_run_setup_rejects_invalid_profile_name(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """An invalid ``--profile`` value (path traversal, whitespace, etc.) must
    produce a clean SetupResult, not an unhandled ValueError traceback.

    The profile name is validated inside ``resolve_hermes_home``, which is
    reached at step [2/9] via ``ensure_profile_exists -> resolve_hermes_home``
    before ``_check_environment`` runs. Bypass the Hermes-detection pre-flight
    so we exercise the validation path itself.
    """
    def _present() -> HermesDetectionResult:
        return HermesDetectionResult(
            detected=True, tier=1,
            reason="hermes binary on PATH", install_dir=None,
        )
    monkeypatch.setattr(
        "agentvault_hermes.cli.setup.detect_hermes_install", _present
    )

    result = await run_setup(token="av_tok_fake_value_for_test", profile="../escape")

    assert result.success is False
    assert result.error is not None
    assert "invalid profile" in result.error.lower()
