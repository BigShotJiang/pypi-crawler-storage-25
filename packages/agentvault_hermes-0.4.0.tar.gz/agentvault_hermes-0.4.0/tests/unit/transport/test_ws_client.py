"""Tests for the WebSocket client.

Uses an in-process echo server fixture — these are integration-shaped unit
tests that exercise the reconnect logic against a real socket without
needing the AV backend.
"""
from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

import pytest

from agentvault_hermes.core.transport.ws_client import (
    WsClient,
    WsClientState,
)


@asynccontextmanager
async def _echo_server() -> AsyncGenerator[str, None]:
    """Spin up an asyncio-based WebSocket echo server. Yields the ws:// URL."""
    from aiohttp import web, WSMsgType

    async def handler(request):
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                await ws.send_str(msg.data)
        return ws

    app = web.Application()
    app.router.add_get("/", handler)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]
    try:
        yield f"ws://127.0.0.1:{port}/"
    finally:
        await runner.cleanup()


@pytest.mark.asyncio
async def test_send_receive_text_round_trip():
    async with _echo_server() as url:
        client = WsClient(url=url, device_jwt="test-jwt")
        async with client:
            await client.send_json({"hello": "world"})
            received = await asyncio.wait_for(client.receive_json(), timeout=5.0)
            assert received == {"hello": "world"}


@pytest.mark.asyncio
async def test_jwt_appended_as_query_param():
    """AV backend expects the JWT in ?token=... per the design pattern."""
    captured_url = []

    from aiohttp import web

    async def handler(request):
        captured_url.append(str(request.url))
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        return ws

    app = web.Application()
    app.router.add_get("/", handler)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]
    try:
        url = f"ws://127.0.0.1:{port}/"
        client = WsClient(url=url, device_jwt="my-jwt-value")
        async with client:
            pass

        assert captured_url, "handler never received a request"
        assert "token=my-jwt-value" in captured_url[0]
    finally:
        await runner.cleanup()


@pytest.mark.asyncio
async def test_device_id_appended_as_query_param():
    """Regression — without ``?device_id=<uuid>`` the AV backend WS handler
    falls into the owner-device branch (``ws.py:355``) and the agent
    never receives ``message_mls`` events for its own conversations.
    """
    captured_url = []

    from aiohttp import web

    async def handler(request):
        captured_url.append(str(request.url))
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        return ws

    app = web.Application()
    app.router.add_get("/", handler)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]
    try:
        url = f"ws://127.0.0.1:{port}/"
        device_id = "11111111-1111-1111-1111-111111111111"
        client = WsClient(url=url, device_jwt="jwt-x", device_id=device_id)
        async with client:
            pass

        assert captured_url
        assert "token=jwt-x" in captured_url[0]
        assert f"device_id={device_id}" in captured_url[0]
    finally:
        await runner.cleanup()


@pytest.mark.asyncio
async def test_device_id_omitted_when_none():
    """``device_id=None`` (default) means the param is NOT in the URL.

    Belt-and-braces against a future change that always-includes the param
    and silently sends ``device_id=None`` as a literal string.
    """
    captured_url = []

    from aiohttp import web

    async def handler(request):
        captured_url.append(str(request.url))
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        return ws

    app = web.Application()
    app.router.add_get("/", handler)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]
    try:
        url = f"ws://127.0.0.1:{port}/"
        client = WsClient(url=url, device_jwt="jwt-x")  # no device_id
        async with client:
            pass

        assert captured_url
        assert "token=jwt-x" in captured_url[0]
        assert "device_id" not in captured_url[0]
    finally:
        await runner.cleanup()


@pytest.mark.asyncio
async def test_state_transitions():
    async with _echo_server() as url:
        client = WsClient(url=url, device_jwt="test-jwt")
        assert client.state == WsClientState.CLOSED
        async with client:
            assert client.state == WsClientState.OPEN
        assert client.state == WsClientState.CLOSED


@pytest.mark.asyncio
async def test_send_when_closed_raises():
    client = WsClient(url="ws://nope", device_jwt="test-jwt")
    with pytest.raises(RuntimeError, match="not open"):
        await client.send_json({"x": 1})
