"""Tests for ``Relay.connect`` / ``disconnect`` / ``send_message``.

These are unit tests against a mock ``WsClient`` — no real socket. The
real-socket round-trip is already covered by
``test_ws_client.py::test_send_receive_text_round_trip``; here we
verify Relay's contract:

- envelope shape exactly matches §3.7 (=OC ``channel.ts:660-690``);
- ``payload`` is hex-encoded (NOT base64);
- ``group_id`` and ``epoch`` are always present (REQUIRED by backend
  ``ws.py:1067``);
- ``sender_device_id`` is NOT on the outbound envelope (backend stamps it);
- ``connect`` / ``disconnect`` are idempotent;
- ``send_message`` raises ``RuntimeError`` when not connected;
- ``Relay`` exposes no ``send_heartbeat`` method (server-pings-agent
  protocol — see §3.4.1 + ``channel.ts:205-210``).
"""
from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from agentvault_hermes.core.transport import relay as relay_module
from agentvault_hermes.core.transport.relay import Relay


# ---------------------------------------------------------------------------
# Mock helpers
# ---------------------------------------------------------------------------


def _install_mock_ws_client(monkeypatch: pytest.MonkeyPatch) -> dict[str, Any]:
    """Patch ``relay_module.WsClient`` with a recording mock.

    Returns a dict with:
        - ``constructor`` (MagicMock): records ``WsClient(...)`` args.
        - ``instance`` (MagicMock): the fake instance returned.
        - ``aenter`` / ``aexit`` / ``send_json`` (AsyncMock): per-call mocks.
        - ``sent`` (list[dict]): payloads passed to ``send_json``.
    """
    sent: list[dict[str, Any]] = []

    instance = MagicMock(name="WsClientInstance")
    instance.__aenter__ = AsyncMock(return_value=instance)
    instance.__aexit__ = AsyncMock(return_value=None)

    async def _record_send(payload: dict[str, Any]) -> None:
        sent.append(payload)

    instance.send_json = AsyncMock(side_effect=_record_send)

    constructor = MagicMock(name="WsClientConstructor", return_value=instance)
    monkeypatch.setattr(relay_module, "WsClient", constructor)

    return {
        "constructor": constructor,
        "instance": instance,
        "aenter": instance.__aenter__,
        "aexit": instance.__aexit__,
        "send_json": instance.send_json,
        "sent": sent,
    }


def _make_relay() -> Relay:
    return Relay(
        rest_base_url="https://api.example.com",
        ws_url="wss://api.example.com/ws",
        device_jwt="test-jwt",
        device_id="dev_xyz",
    )


# ---------------------------------------------------------------------------
# connect / disconnect lifecycle
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_connect_opens_ws_with_url_and_jwt(monkeypatch: pytest.MonkeyPatch):
    mocks = _install_mock_ws_client(monkeypatch)
    relay = _make_relay()

    await relay.connect()

    mocks["constructor"].assert_called_once_with(
        url="wss://api.example.com/ws",
        device_jwt="test-jwt",
        device_id="dev_xyz",
    )
    mocks["aenter"].assert_awaited_once()
    mocks["aexit"].assert_not_awaited()


@pytest.mark.asyncio
async def test_disconnect_closes_ws(monkeypatch: pytest.MonkeyPatch):
    mocks = _install_mock_ws_client(monkeypatch)
    relay = _make_relay()

    await relay.connect()
    await relay.disconnect()

    mocks["aexit"].assert_awaited_once()


@pytest.mark.asyncio
async def test_connect_is_idempotent(monkeypatch: pytest.MonkeyPatch):
    """A second ``connect()`` call is a no-op; a single WsClient is constructed."""
    mocks = _install_mock_ws_client(monkeypatch)
    relay = _make_relay()

    await relay.connect()
    await relay.connect()

    assert mocks["constructor"].call_count == 1
    assert mocks["aenter"].await_count == 1


@pytest.mark.asyncio
async def test_disconnect_is_idempotent(monkeypatch: pytest.MonkeyPatch):
    """A second ``disconnect()`` call is a no-op; ``__aexit__`` is awaited only once."""
    mocks = _install_mock_ws_client(monkeypatch)
    relay = _make_relay()

    await relay.connect()
    await relay.disconnect()
    await relay.disconnect()

    assert mocks["aexit"].await_count == 1


@pytest.mark.asyncio
async def test_disconnect_without_connect_is_noop(monkeypatch: pytest.MonkeyPatch):
    mocks = _install_mock_ws_client(monkeypatch)
    relay = _make_relay()

    # Should not raise and should not construct a WsClient.
    await relay.disconnect()

    mocks["constructor"].assert_not_called()
    mocks["aexit"].assert_not_awaited()


# ---------------------------------------------------------------------------
# send_message — error paths
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_send_message_raises_when_not_connected(monkeypatch: pytest.MonkeyPatch):
    _install_mock_ws_client(monkeypatch)
    relay = _make_relay()

    with pytest.raises(RuntimeError, match="not connected"):
        await relay.send_message(
            conversation_id="conv_1",
            group_id="grp_1",
            epoch=0,
            ciphertext=b"\x00\x01",
        )


@pytest.mark.asyncio
async def test_send_message_after_disconnect_raises(monkeypatch: pytest.MonkeyPatch):
    _install_mock_ws_client(monkeypatch)
    relay = _make_relay()

    await relay.connect()
    await relay.disconnect()

    with pytest.raises(RuntimeError, match="not connected"):
        await relay.send_message(
            conversation_id="conv_1",
            group_id="grp_1",
            epoch=0,
            ciphertext=b"\xff",
        )


# ---------------------------------------------------------------------------
# send_message — happy path + envelope shape (§3.7)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_send_message_happy_path_emits_message_mls_envelope(
    monkeypatch: pytest.MonkeyPatch,
):
    """The exact ``{event:"message_mls", data:{…}}`` shape per §3.7."""
    mocks = _install_mock_ws_client(monkeypatch)
    relay = _make_relay()
    ciphertext = b"\x00\x01\x02\xff\xfe\xfd"

    await relay.connect()
    await relay.send_message(
        conversation_id="conv_abc",
        group_id="grp_123",
        epoch=42,
        ciphertext=ciphertext,
    )

    mocks["send_json"].assert_awaited_once()
    out = mocks["sent"][0]

    assert out["event"] == "message_mls"
    data = out["data"]
    assert data["conversation_id"] == "conv_abc"
    assert data["group_id"] == "grp_123"
    assert data["epoch"] == 42
    # payload is hex-encoded ciphertext, NOT base64.
    assert data["payload"] == ciphertext.hex()
    assert bytes.fromhex(data["payload"]) == ciphertext
    # message_type defaults to "text" (OC ``channel.ts:670``).
    assert data["message_type"] == "text"


@pytest.mark.asyncio
async def test_send_message_payload_is_hex_round_trips_extremes(
    monkeypatch: pytest.MonkeyPatch,
):
    """Per Devils-Advocate brief: 0x00 + 0xFF must round-trip without mojibake.

    Lowercase-hex is what OC emits (``Buffer.from(...).toString('hex')``);
    backend ``bytes.fromhex`` accepts both cases but parity matters.
    """
    mocks = _install_mock_ws_client(monkeypatch)
    relay = _make_relay()
    ciphertext = bytes(range(256))  # every byte 0x00..0xFF

    await relay.connect()
    await relay.send_message(
        conversation_id="conv_a",
        group_id="grp_a",
        epoch=1,
        ciphertext=ciphertext,
    )

    out = mocks["sent"][0]
    payload_hex: str = out["data"]["payload"]
    assert payload_hex == ciphertext.hex()
    assert payload_hex == payload_hex.lower(), "OC emits lowercase hex (channel.ts:669)"
    assert bytes.fromhex(payload_hex) == ciphertext


@pytest.mark.asyncio
async def test_send_message_omits_sender_device_id(monkeypatch: pytest.MonkeyPatch):
    """``sender_device_id`` MUST NOT appear on outbound MLS data.

    Backend stamps it from the authenticated session
    (``packages/backend/app/api/v1/ws.py:1063-1082``); emitting it on
    the outbound envelope diverges from OC parity and is silently
    ignored. The test enforces the absence so a future regression that
    ``data["sender_device_id"] = self.device_id`` is caught.
    """
    mocks = _install_mock_ws_client(monkeypatch)
    relay = _make_relay()

    await relay.connect()
    await relay.send_message(
        conversation_id="c",
        group_id="g",
        epoch=0,
        ciphertext=b"x",
    )

    out = mocks["sent"][0]
    assert "sender_device_id" not in out["data"]


@pytest.mark.asyncio
async def test_send_message_required_fields_always_present(
    monkeypatch: pytest.MonkeyPatch,
):
    """``group_id`` + ``epoch`` are REQUIRED by backend ``ws.py:1067``."""
    mocks = _install_mock_ws_client(monkeypatch)
    relay = _make_relay()

    await relay.connect()
    await relay.send_message(
        conversation_id="c",
        group_id="g",
        epoch=0,
        ciphertext=b"\xab",
    )

    data = mocks["sent"][0]["data"]
    assert "conversation_id" in data
    assert "group_id" in data
    assert "epoch" in data
    assert "payload" in data
    assert "message_type" in data


# ---------------------------------------------------------------------------
# send_message — optional fields round-trip
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_send_message_optional_fields_default_to_none(
    monkeypatch: pytest.MonkeyPatch,
):
    """Optional fields are ALWAYS emitted (matching OC ``channel.ts:670-677``).

    Per WS-33 ``make_outbound_mls_envelope``: ``topic_id``,
    ``client_message_id``, ``parent_span_id``, ``metadata`` are emitted
    as ``null`` when the caller doesn't override; ``priority`` defaults
    to ``"normal"``. ``hub_address`` / ``sender_hub_id`` are emitted
    only when truthy.
    """
    mocks = _install_mock_ws_client(monkeypatch)
    relay = _make_relay()

    await relay.connect()
    await relay.send_message(
        conversation_id="c",
        group_id="g",
        epoch=0,
        ciphertext=b"x",
    )

    data = mocks["sent"][0]["data"]
    assert data["topic_id"] is None
    assert data["client_message_id"] is None
    assert data["parent_span_id"] is None
    assert data["metadata"] is None
    # priority is filled by outbox default (OC ``channel.ts:562``).
    assert data["priority"] == "normal"
    # Federation fields are absent unless truthy.
    assert "hub_address" not in data
    assert "sender_hub_id" not in data


@pytest.mark.asyncio
async def test_send_message_optional_fields_pass_through_when_set(
    monkeypatch: pytest.MonkeyPatch,
):
    mocks = _install_mock_ws_client(monkeypatch)
    relay = _make_relay()

    metadata = {"trace_id": "trc_1", "k": "v"}
    await relay.connect()
    await relay.send_message(
        conversation_id="c",
        group_id="g",
        epoch=7,
        ciphertext=b"\xde\xad\xbe\xef",
        message_type="file",
        client_message_id="cmsg_1",
        topic_id="top_1",
        parent_span_id="span_1",
        metadata=metadata,
        hub_address="https://hub.example",
        sender_hub_id="hub_42",
    )

    data = mocks["sent"][0]["data"]
    assert data["message_type"] == "file"
    assert data["client_message_id"] == "cmsg_1"
    assert data["topic_id"] == "top_1"
    assert data["parent_span_id"] == "span_1"
    assert data["metadata"] == metadata
    assert data["hub_address"] == "https://hub.example"
    assert data["sender_hub_id"] == "hub_42"


# ---------------------------------------------------------------------------
# Heartbeat policy — guard against future regressions
# ---------------------------------------------------------------------------


def test_relay_has_no_send_heartbeat_method():
    """OC ``channel.ts:205-210`` shows the SERVER pings the AGENT.

    Adding an outbound ``send_heartbeat`` would invert OC parity and
    serve no purpose — the agent watches for inbound silence in
    ``SecureChannel._silence_timeout_task`` (WS-28b). This test guards
    against accidental re-introduction.
    """
    assert not hasattr(Relay, "send_heartbeat")


@pytest.mark.asyncio
async def test_send_pong_emits_pong_event_on_open_ws(monkeypatch: pytest.MonkeyPatch):
    """``send_pong`` echoes ``{"event": "pong"}`` so the backend's
    ``manager.on_pong(did)`` refreshes the Redis ``device:<id>:alive`` TTL.

    Backend handler: ``packages/backend/app/api/v1/ws.py:762-764``. Without
    this echo, the device's liveness key expires, ``manager.is_alive``
    returns False, and other devices' MLS-delivery pings silently drop.
    """
    mocks = _install_mock_ws_client(monkeypatch)
    relay = _make_relay()

    await relay.connect()
    await relay.send_pong()

    mocks["send_json"].assert_awaited_with({"event": "pong"})


@pytest.mark.asyncio
async def test_send_pong_raises_when_not_connected(monkeypatch: pytest.MonkeyPatch):
    """Calling ``send_pong`` before ``connect`` (or after ``disconnect``)
    must raise ``RuntimeError`` so the demux loop's outer try/except can
    log and continue rather than silently swallowing on a closed WS.
    """
    _install_mock_ws_client(monkeypatch)
    relay = _make_relay()

    with pytest.raises(RuntimeError, match="not connected"):
        await relay.send_pong()


# NOTE: the WS-30 stub-guard test has been removed; the real
# ``receive_messages`` implementation is exercised in ``test_relay_receive.py``.
