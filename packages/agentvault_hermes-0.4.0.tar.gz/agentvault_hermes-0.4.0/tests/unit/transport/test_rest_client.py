"""Tests for the REST client wrapper around httpx.AsyncClient.

Uses respx to mock HTTP responses without a live backend.
"""
from __future__ import annotations

import pytest
import respx

from agentvault_hermes.core.transport.rest_client import (
    RestClient,
    RestClientError,
)


@pytest.mark.asyncio
async def test_get_with_jwt_sets_authorization_header():
    async with respx.mock(base_url="https://api.example.com") as mock:
        mock.get("/v1/test").respond(json={"ok": True})

        client = RestClient(
            base_url="https://api.example.com",
            device_jwt="ey.device.jwt",
        )
        async with client:
            data = await client.get("/v1/test")

        assert data == {"ok": True}
        assert mock.calls[0].request.headers["authorization"] == "Bearer ey.device.jwt"


@pytest.mark.asyncio
async def test_post_json_sets_content_type():
    async with respx.mock(base_url="https://api.example.com") as mock:
        mock.post("/v1/devices").respond(json={"device_id": "dev_123"})

        client = RestClient(base_url="https://api.example.com")
        async with client:
            data = await client.post("/v1/devices", json={"name": "alice"})

        assert data == {"device_id": "dev_123"}
        request = mock.calls[0].request
        assert request.headers["content-type"] == "application/json"


@pytest.mark.asyncio
async def test_4xx_raises_rest_client_error_with_status_and_body():
    async with respx.mock(base_url="https://api.example.com") as mock:
        mock.post("/v1/enroll").respond(
            status_code=400,
            json={"detail": "invalid token"},
        )

        client = RestClient(base_url="https://api.example.com")
        async with client:
            with pytest.raises(RestClientError) as exc_info:
                await client.post("/v1/enroll", json={})

        assert exc_info.value.status_code == 400
        assert "invalid token" in str(exc_info.value)


@pytest.mark.asyncio
async def test_5xx_raises_rest_client_error():
    async with respx.mock(base_url="https://api.example.com") as mock:
        mock.get("/v1/test").respond(status_code=503)

        client = RestClient(base_url="https://api.example.com")
        async with client:
            with pytest.raises(RestClientError) as exc_info:
                await client.get("/v1/test")

        assert exc_info.value.status_code == 503


@pytest.mark.asyncio
async def test_no_jwt_omits_authorization_header():
    async with respx.mock(base_url="https://api.example.com") as mock:
        mock.get("/v1/public").respond(json={"ok": True})

        client = RestClient(base_url="https://api.example.com")
        async with client:
            await client.get("/v1/public")

        assert "authorization" not in mock.calls[0].request.headers


@pytest.mark.asyncio
async def test_user_agent_includes_package_version():
    async with respx.mock(base_url="https://api.example.com") as mock:
        mock.get("/v1/test").respond(json={"ok": True})

        client = RestClient(base_url="https://api.example.com")
        async with client:
            await client.get("/v1/test")

        ua = mock.calls[0].request.headers["user-agent"]
        assert "agentvault-hermes" in ua


@pytest.mark.asyncio
async def test_context_manager_closes_underlying_client():
    client = RestClient(base_url="https://api.example.com")
    async with client:
        assert client._closed is False
    assert client._closed is True


# --- Slice B: batch KP fetch + A2A MLS group init --------------------------

# Backend (packages/backend/app/api/v1/mls.py:67):
#   GET /api/v1/mls/key-packages/batch?device_ids=uuid1,uuid2
#   response: {str(device_uuid): kp_hex_str, ...}  — flat dict
#
# Backend (packages/backend/app/api/v1/mls.py:214):
#   POST /api/v1/mls/a2a/{channel_id}/init
#   body: {"member_device_ids": [uuid, ...]}
#   response: MLSGroupResponse {"group_id": <uuid>, "current_epoch": int, "member_device_ids": [...]}


@pytest.mark.asyncio
async def test_batch_fetch_key_packages_returns_device_to_kp_map():
    """RestClient.batch_fetch_key_packages returns available/missing split.

    Backend's GET response is a flat ``{device_id: kp_hex}`` dict; devices the
    backend has no KP for are absent from the response and reported in
    ``missing``.
    """
    async with respx.mock(base_url="https://api.test") as mock:
        mock.get("/api/v1/mls/key-packages/batch").respond(
            json={
                "dev-a": "deadbeef",
                "dev-b": "feedface",
            },
        )
        async with RestClient(base_url="https://api.test", device_jwt="t") as c:
            result = await c.batch_fetch_key_packages(
                device_ids=["dev-a", "dev-b", "dev-c"]
            )

        assert result.available == {
            "dev-a": bytes.fromhex("deadbeef"),
            "dev-b": bytes.fromhex("feedface"),
        }
        assert result.missing == ["dev-c"]

        # Query string is comma-separated per backend's Query(..., str) param.
        call = mock.calls[0]
        assert "device_ids=" in str(call.request.url)


@pytest.mark.asyncio
async def test_batch_fetch_key_packages_returns_empty_available_when_all_missing():
    """No KeyPackages at all → available={}, missing=[all]."""
    async with respx.mock(base_url="https://api.test") as mock:
        mock.get("/api/v1/mls/key-packages/batch").respond(json={})
        async with RestClient(base_url="https://api.test", device_jwt="t") as c:
            result = await c.batch_fetch_key_packages(device_ids=["dev-a"])

    assert result.available == {}
    assert result.missing == ["dev-a"]


@pytest.mark.asyncio
async def test_batch_fetch_key_packages_empty_input_returns_empty_result():
    """Defensive: caller passes empty list → no HTTP call, empty result."""
    async with respx.mock(base_url="https://api.test", assert_all_called=False) as mock:
        # Route registered but should NOT be called.
        route = mock.get("/api/v1/mls/key-packages/batch").respond(json={})
        async with RestClient(base_url="https://api.test", device_jwt="t") as c:
            result = await c.batch_fetch_key_packages(device_ids=[])

        assert result.available == {}
        assert result.missing == []
        assert not route.called


@pytest.mark.asyncio
async def test_init_a2a_mls_group_returns_group_id():
    """RestClient.init_a2a_mls_group returns the backend-assigned group_id."""
    async with respx.mock(base_url="https://api.test") as mock:
        mock.post("/api/v1/mls/a2a/ch-1/init").respond(
            json={
                "group_id": "grp-99",
                "current_epoch": 0,
                "member_device_ids": ["dev-self", "dev-a"],
            },
        )
        async with RestClient(base_url="https://api.test", device_jwt="t") as c:
            group_id = await c.init_a2a_mls_group(
                channel_id="ch-1",
                member_device_ids=["dev-self", "dev-a"],
            )

    assert group_id == "grp-99"


@pytest.mark.asyncio
async def test_init_a2a_mls_group_is_idempotent_returns_existing():
    """If the backend returns an existing group (idempotent init), we use its id."""
    async with respx.mock(base_url="https://api.test") as mock:
        mock.post("/api/v1/mls/a2a/ch-1/init").respond(
            json={
                "group_id": "grp-existing",
                "current_epoch": 3,
                "member_device_ids": ["dev-self"],
            },
        )
        async with RestClient(base_url="https://api.test", device_jwt="t") as c:
            group_id = await c.init_a2a_mls_group(
                channel_id="ch-1", member_device_ids=["dev-self"]
            )

    assert group_id == "grp-existing"
