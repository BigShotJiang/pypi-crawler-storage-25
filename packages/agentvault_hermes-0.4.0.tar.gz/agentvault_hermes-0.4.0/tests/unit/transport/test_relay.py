"""Tests for the relay construction surface.

Phase 3 (WS-29) made ``Relay`` hold a real ``WsClient`` and added a 4th
required ``device_id`` arg to the constructor. The Phase-1 stub test
that asserted ``send_message`` raises ``NotImplementedError`` has been
deleted — that behavior is no longer the contract. End-to-end send
behavior is exercised in ``test_relay_send.py``.
"""
from __future__ import annotations

import pytest

from agentvault_hermes.core.transport.relay import Relay


@pytest.mark.asyncio
async def test_relay_constructs_with_required_args():
    relay = Relay(
        rest_base_url="https://api.example.com",
        ws_url="wss://api.example.com/ws",
        device_jwt="test-jwt",
        device_id="dev_abc123",
    )
    assert relay.rest_base_url == "https://api.example.com"
    assert relay.ws_url == "wss://api.example.com/ws"
    assert relay.device_jwt == "test-jwt"
    assert relay.device_id == "dev_abc123"
