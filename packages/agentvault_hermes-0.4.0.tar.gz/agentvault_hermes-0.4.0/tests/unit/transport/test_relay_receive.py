"""Tests for ``Relay.receive_messages``.

WS-30 — drops the ``NotImplementedError`` stub and yields typed
``WireEnvelope`` instances over the WebSocket.

Plan ref: ``docs/plans/2026-05-10-hermes-phase3-implementation.md`` §10.5
+ §10.8.

Strategy:

- Mock ``WsClient`` with a controllable ``receive_json`` queue.
- Drive ``Relay.receive_messages`` as an async generator and assert the
  yielded shapes.
- Malformed frames must skip-and-continue; WS errors must propagate.

PEP 479 footnote: an async generator that raises ``StopAsyncIteration``
internally surfaces ``RuntimeError`` to its caller, so the tests use a
dedicated ``_EndOfStream`` exception as the "end of mock stream" sentinel
rather than ``StopAsyncIteration``.
"""
from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from agentvault_hermes.channel.outbox import WireEnvelope
from agentvault_hermes.core.transport import relay as relay_module
from agentvault_hermes.core.transport.relay import Relay


class _EndOfStream(Exception):
    """Sentinel raised by the mock ``receive_json`` to terminate the async
    generator deterministically.

    PEP 479: ``StopAsyncIteration`` raised inside an async generator surfaces
    as ``RuntimeError`` to the caller. Using a dedicated subclass avoids that
    pitfall and makes the test's intent obvious in the failure trace.
    """


# ---------------------------------------------------------------------------
# Mock helpers
# ---------------------------------------------------------------------------


def _install_mock_ws_client(
    monkeypatch: pytest.MonkeyPatch,
    *,
    receive_side_effect: Any = None,
) -> dict[str, Any]:
    """Patch ``relay_module.WsClient`` with a recording mock.

    ``receive_side_effect`` configures ``receive_json``: a list of return
    values (yielded one per call) or an exception (raised on first call).
    """
    instance = MagicMock(name="WsClientInstance")
    instance.__aenter__ = AsyncMock(return_value=instance)
    instance.__aexit__ = AsyncMock(return_value=None)

    if receive_side_effect is None:
        instance.receive_json = AsyncMock()
    elif isinstance(receive_side_effect, Exception) or (
        isinstance(receive_side_effect, type)
        and issubclass(receive_side_effect, BaseException)
    ):
        instance.receive_json = AsyncMock(side_effect=receive_side_effect)
    else:
        instance.receive_json = AsyncMock(side_effect=list(receive_side_effect))

    instance.send_json = AsyncMock()

    constructor = MagicMock(name="WsClientConstructor", return_value=instance)
    monkeypatch.setattr(relay_module, "WsClient", constructor)

    return {
        "constructor": constructor,
        "instance": instance,
        "receive_json": instance.receive_json,
    }


def _make_relay() -> Relay:
    return Relay(
        rest_base_url="https://api.example.com",
        ws_url="wss://api.example.com/ws",
        device_jwt="test-jwt",
        device_id="dev_recv",
    )


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_receive_messages_yields_three_envelopes(
    monkeypatch: pytest.MonkeyPatch,
):
    """Three frames in → three ``WireEnvelope``s out, content-preserved."""
    frames = [
        {"event": "message_mls", "data": {"conversation_id": "c1", "payload": "00"}},
        {"event": "ping", "data": {}},
        {"event": "message", "data": {"conversation_id": "c2"}},
    ]
    # After the three valid frames, surface a sentinel exception so the
    # generator terminates cleanly for the test rather than hanging on a
    # 4th await.
    side_effects = list(frames) + [_EndOfStream("end")]
    _install_mock_ws_client(monkeypatch, receive_side_effect=side_effects)

    relay = _make_relay()
    await relay.connect()

    yielded: list[WireEnvelope] = []
    with pytest.raises(_EndOfStream):
        async for envelope in relay.receive_messages():
            yielded.append(envelope)

    assert len(yielded) == 3
    assert all(isinstance(e, WireEnvelope) for e in yielded)
    assert yielded[0].event == "message_mls"
    assert yielded[0].data == {"conversation_id": "c1", "payload": "00"}
    assert yielded[1].event == "ping"
    assert yielded[1].data == {}
    assert yielded[2].event == "message"
    assert yielded[2].data == {"conversation_id": "c2"}


# ---------------------------------------------------------------------------
# Malformed frames
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_receive_messages_skips_malformed_frame_missing_event(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
):
    """A frame missing ``event`` is logged-and-skipped; the next frame yields."""
    frames = [
        {"data": {"x": 1}},  # missing "event"
        {"event": "ping", "data": {}},  # valid, must yield
        _EndOfStream("end"),
    ]
    _install_mock_ws_client(monkeypatch, receive_side_effect=frames)

    relay = _make_relay()
    await relay.connect()

    yielded: list[WireEnvelope] = []
    with caplog.at_level(
        "WARNING", logger="agentvault_hermes.core.transport.relay"
    ):
        with pytest.raises(_EndOfStream):
            async for envelope in relay.receive_messages():
                yielded.append(envelope)

    assert len(yielded) == 1
    assert yielded[0].event == "ping"
    assert any("malformed WS frame" in r.message for r in caplog.records)


@pytest.mark.asyncio
async def test_receive_messages_accepts_ping_without_data_field(
    monkeypatch: pytest.MonkeyPatch,
):
    """Regression — §M1 wire-shape gap.

    The AV backend sends ``{"event": "ping"}`` with NO ``data`` field
    (``packages/backend/app/services/ws_manager.py:636``). Earlier the
    parser required ``data`` as a key and dropped the ping as malformed,
    so the agent never echoed pong; the backend's heartbeat liveness
    keeper then closed the WS with ``NORMAL_CLOSURE``. Caught during
    §M1 manual smoke test.
    """
    frames = [
        {"event": "ping"},  # NO data field — backend's actual wire shape
        {"event": "ping", "data": {}},  # explicit empty data — also valid
        _EndOfStream("end"),
    ]
    _install_mock_ws_client(monkeypatch, receive_side_effect=frames)

    relay = _make_relay()
    await relay.connect()

    yielded: list[WireEnvelope] = []
    with pytest.raises(_EndOfStream):
        async for envelope in relay.receive_messages():
            yielded.append(envelope)

    assert len(yielded) == 2
    # Both frames yielded a WireEnvelope with event="ping" and a dict data.
    for env in yielded:
        assert env.event == "ping"
        assert env.data == {}


@pytest.mark.asyncio
async def test_receive_messages_skips_frame_with_non_dict_data(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
):
    """A frame whose ``data`` is not a dict is skipped (defensive guard).

    The OC peer always sends ``data: {...}``; if a malformed peer or a
    server-side bug ever sends ``data: "string"`` or ``data: [1, 2]``,
    we don't want the demux loop to crash.
    """
    frames = [
        {"event": "message_mls", "data": "not-a-dict"},
        {"event": "ping", "data": {}},  # valid
        _EndOfStream("end"),
    ]
    _install_mock_ws_client(monkeypatch, receive_side_effect=frames)

    relay = _make_relay()
    await relay.connect()

    yielded: list[WireEnvelope] = []
    with caplog.at_level(
        "WARNING", logger="agentvault_hermes.core.transport.relay"
    ):
        with pytest.raises(_EndOfStream):
            async for envelope in relay.receive_messages():
                yielded.append(envelope)

    assert len(yielded) == 1
    assert yielded[0].event == "ping"
    assert any("not a dict" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# WS error propagation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_receive_messages_propagates_ws_error(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
):
    """A WS-level error raised by ``receive_json`` propagates verbatim.

    The demux loop in ``SecureChannel`` decides whether to reconnect;
    Relay just re-raises so the loop sees the exception type.
    """
    _install_mock_ws_client(
        monkeypatch, receive_side_effect=ConnectionError("socket dead")
    )

    relay = _make_relay()
    await relay.connect()

    with caplog.at_level(
        "WARNING", logger="agentvault_hermes.core.transport.relay"
    ):
        with pytest.raises(ConnectionError, match="socket dead"):
            async for _ in relay.receive_messages():
                pass

    # Should have logged the error before re-raising.
    assert any("WS receive error" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# Connection state
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_receive_messages_raises_when_not_connected(
    monkeypatch: pytest.MonkeyPatch,
):
    """Calling ``receive_messages`` before ``connect`` (or after ``disconnect``)
    must raise ``RuntimeError`` immediately on the first ``__anext__``.
    """
    _install_mock_ws_client(monkeypatch)
    relay = _make_relay()

    gen = relay.receive_messages()
    with pytest.raises(RuntimeError, match="not connected"):
        await gen.__anext__()


@pytest.mark.asyncio
async def test_receive_messages_raises_after_disconnect(
    monkeypatch: pytest.MonkeyPatch,
):
    """After ``disconnect``, a fresh ``receive_messages`` call raises."""
    _install_mock_ws_client(monkeypatch)
    relay = _make_relay()

    await relay.connect()
    await relay.disconnect()

    gen = relay.receive_messages()
    with pytest.raises(RuntimeError, match="not connected"):
        await gen.__anext__()
