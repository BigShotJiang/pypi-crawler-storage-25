"""Tests for the agentvault plugin's register(ctx) entry point.

The plugin's ``__init__.py`` imports ``adapter.py``, which imports
``gateway.platforms.base`` etc. at module level. Tests patch ``sys.modules``
BEFORE importing the plugin so the imports resolve to mocks.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest

# Shared gateway-runtime mocks (DA WS-34 MAJOR-1). Single source of truth
# for the ``BasePlatformAdapter`` / ``MessageEvent`` / ``SessionSource`` /
# ``SendResult`` / ``Platform`` stand-ins.
from tests._fixtures.gateway_runtime import install_gateway_mocks

install_gateway_mocks()

# Now safe to import the plugin module.
from agentvault_hermes.plugins.agentvault import (  # noqa: E402
    _adapter_factory,
    _check_av_configured,
    register,
)


# --- FakePluginContext ------------------------------------------------------

class FakePluginContext:
    """Stand-in for the real Hermes PluginContext (hermes_cli/plugins.py:472)."""

    def __init__(self) -> None:
        self.register_platform = MagicMock()


# --- tests ------------------------------------------------------------------


def test_register_calls_register_platform_with_expected_kwargs() -> None:
    ctx = FakePluginContext()
    register(ctx)
    assert ctx.register_platform.call_count == 1
    kwargs = ctx.register_platform.call_args.kwargs
    assert kwargs["name"] == "agentvault"
    assert kwargs["label"] == "AgentVault"
    assert callable(kwargs["adapter_factory"])
    assert callable(kwargs["check_fn"])
    # emoji + install_hint flow through **entry_kwargs to PlatformEntry.
    assert kwargs.get("emoji")
    assert kwargs.get("install_hint")


def test_check_av_configured_no_root_returns_false(
    fake_hermes_home: Path,
) -> None:
    assert _check_av_configured() is False


def test_check_av_configured_empty_root_returns_false(
    fake_hermes_home: Path,
) -> None:
    (fake_hermes_home / ".hermes" / "agentvault").mkdir(parents=True)
    assert _check_av_configured() is False


def test_check_av_configured_with_state_returns_true(
    fake_hermes_home: Path,
) -> None:
    data_dir = fake_hermes_home / ".hermes" / "agentvault"
    data_dir.mkdir(parents=True)
    (data_dir / "state.json").write_text("{}", encoding="utf-8")
    assert _check_av_configured() is True


def test_check_av_configured_legacy_default_path_returns_true(
    fake_hermes_home: Path,
) -> None:
    """An un-migrated pre-feature install should still be recognized."""
    legacy = fake_hermes_home / ".hermes" / "agentvault" / "default"
    legacy.mkdir(parents=True)
    (legacy / "state.json").write_text("{}", encoding="utf-8")
    assert _check_av_configured() is True


def test_adapter_factory_returns_agentvault_adapter() -> None:
    """Smoke-test that the factory builds an AgentVaultAdapter instance.

    The factory reads no account/profile selector from ``cfg`` anymore —
    the runtime resolves the active profile via ``HERMES_HOME`` (Task 9).
    """
    from agentvault_hermes.plugins.agentvault.adapter import AgentVaultAdapter

    cfg = MagicMock()
    cfg.extra = {}
    adapter = _adapter_factory(cfg)
    assert isinstance(adapter, AgentVaultAdapter)


def test_check_av_configured_no_state_json_in_data_dir_returns_false(
    fake_hermes_home: Path,
) -> None:
    """Regression — DA WS-31 M4.

    `_check_av_configured` runs during Hermes' plugin-discovery bootstrap;
    it must never raise. An existing data-dir root without a ``state.json``
    file (e.g. partially-initialized install) returns False so Hermes
    surfaces the install_hint instead of bombing inside ``connect()``.
    """
    av_root = fake_hermes_home / ".hermes" / "agentvault"
    av_root.mkdir(parents=True)
    # No state.json written — neither new-layout nor legacy path exists.
    assert _check_av_configured() is False


def test_check_av_configured_swallows_oserror_from_exists(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A PermissionError from .exists() must not crash plugin discovery.

    `Path.exists()` calls `os.stat()` internally and raises `PermissionError`
    on permission-denied parent directories (confirmed on macOS Python 3.12).
    Hermes' platform-discovery loop would crash on an unhandled exception
    here, so the function must swallow OSError → False.
    """

    def boom(_self: Path) -> Any:
        raise PermissionError("denied")

    monkeypatch.setattr(Path, "exists", boom)
    # Must not raise:
    assert _check_av_configured() is False
