"""Tests for AgentVaultAdapter.

Strategy:
- Mock the Hermes runtime (``gateway.platforms.base``, ``gateway.config``,
  ``gateway.session``) via ``sys.modules`` patching BEFORE importing the
  adapter module.
- Mock the heavy SecureChannel/Relay/MlsGroupState collaborators so each
  test stays a unit test (no real WS, no real crypto state on disk).

Test surface (per plan §11.8):
- ``__init__`` passes ``config`` + ``Platform("agentvault")`` to super; no
  ``account_id`` concept — the runtime resolves state via HERMES_HOME.
- ``connect()`` returns False when no state.json.
- ``connect()`` happy path hydrates MLS states, builds Relay+SecureChannel,
  seeds the conv→group_id cache, and starts the channel.
- ``send()`` not connected → SendResult(success=False).
- ``send()`` happy path → SecureChannel.send called with bytes-encoded text.
- ``disconnect()`` stops SecureChannel.
- ``_on_inbound`` builds a MessageEvent + delegates to message_handler.
"""
from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# Shared gateway-runtime mocks (DA WS-34 MAJOR-1). Both test_adapter.py and
# test_phase3_demo.py install the SAME fakes from the SAME source so a future
# field added to one ``MessageEvent`` shape can't silently leave the other
# test running against a stale stand-in.
from tests._fixtures.gateway_runtime import install_gateway_mocks

install_gateway_mocks()


# Module under test — imported AFTER the mocks are installed.
from agentvault_hermes.core.config import ProfileConfig  # noqa: E402
from agentvault_hermes.plugins.agentvault import adapter as adapter_module  # noqa: E402
from agentvault_hermes.plugins.agentvault.adapter import AgentVaultAdapter  # noqa: E402


# --- helpers ---------------------------------------------------------------


def _make_persisted_state() -> Any:
    """Build a fake PersistedState with the fields the adapter touches."""
    keys = SimpleNamespace(
        signing_secret=b"\x00" * 32,
        signing_public=b"\x01" * 32,
    )
    return SimpleNamespace(
        device_id="11111111-1111-1111-1111-111111111111",
        device_jwt="ey-fake-jwt",
        device_keys=keys,
        tenant_id="22222222-2222-2222-2222-222222222222",
    )


def _make_config(extra_account_id: Any = None, top_account_id: Any = None) -> Any:
    """Construct a fake PlatformConfig-like object.

    ``extra_account_id`` and ``top_account_id`` are historical noise from when
    the adapter read ``cfg.extra.account_id`` / ``cfg.account_id``. The adapter
    no longer reads either field (HERMES_HOME is the source of truth), but the
    parameters are left here so call sites that pass values remain valid.
    """
    cfg = MagicMock()
    if extra_account_id is None:
        cfg.extra = {}
    else:
        cfg.extra = {"account_id": extra_account_id}
    if top_account_id is not None:
        cfg.account_id = top_account_id
    else:
        # Make sure getattr(cfg, "account_id", None) returns None.
        del cfg.account_id
    return cfg


# --- __init__ tests --------------------------------------------------------


def test_init_calls_super_with_platform_and_config() -> None:
    cfg = _make_config()
    adapter = AgentVaultAdapter(cfg)
    # super().__init__ stores both onto the instance.
    assert adapter.config is cfg
    # platform is the SimpleNamespace returned by the mocked Platform().
    assert getattr(adapter.platform, "value") == "agentvault"
    # Platform("agentvault") was called.
    assert adapter_module.Platform.call_args.args == ("agentvault",)


# --- connect() tests --------------------------------------------------------


@pytest.mark.asyncio
async def test_connect_returns_false_when_no_state(tmp_path: Path) -> None:
    cfg = _make_config()
    adapter = AgentVaultAdapter(cfg)

    fake_profile_cfg = ProfileConfig(
        profile=None,
        data_dir=tmp_path,
        api_url="https://example.com",
        agent_name=None,
        http_port=18790,
    )
    with (
        patch.object(adapter_module, "migrate_legacy_layout"),
        patch.object(adapter_module, "resolve_profile", return_value=fake_profile_cfg),
        patch.object(adapter_module, "load_state", return_value=None),
    ):
        ok = await adapter.connect()
    assert ok is False
    assert adapter._secure_channel is None


@pytest.mark.asyncio
async def test_connect_happy_path_starts_secure_channel(tmp_path: Path) -> None:
    cfg = _make_config()
    adapter = AgentVaultAdapter(cfg)
    fake_state = _make_persisted_state()

    fake_profile_cfg = ProfileConfig(
        profile=None,
        data_dir=tmp_path,
        api_url="https://api.example.com",
        agent_name="hermes-bot",
        http_port=18790,
    )

    # SecureChannel mock: needs an awaitable .start() and a private
    # _conv_to_group_id dict the adapter writes into.
    fake_channel_instance = MagicMock()
    fake_channel_instance.start = AsyncMock()
    fake_channel_instance.stop = AsyncMock()
    fake_channel_instance._conv_to_group_id = {}
    secure_channel_ctor = MagicMock(return_value=fake_channel_instance)

    relay_ctor = MagicMock()

    with (
        patch.object(adapter_module, "migrate_legacy_layout"),
        patch.object(adapter_module, "resolve_profile", return_value=fake_profile_cfg),
        patch.object(adapter_module, "load_state", return_value=fake_state),
        patch.object(adapter_module, "list_conversations", return_value=[]),
        patch.object(adapter_module, "Relay", relay_ctor),
        patch.object(adapter_module, "SecureChannel", secure_channel_ctor),
    ):
        ok = await adapter.connect()

    assert ok is True
    fake_channel_instance.start.assert_awaited_once()
    # WS URL derived from api_url.
    relay_kwargs = relay_ctor.call_args.kwargs
    assert relay_kwargs["rest_base_url"] == "https://api.example.com"
    assert relay_kwargs["ws_url"] == "wss://api.example.com/api/v1/ws"
    assert relay_kwargs["device_jwt"] == "ey-fake-jwt"
    # SecureChannel got the live mls_states dict + the bound _on_inbound.
    sc_kwargs = secure_channel_ctor.call_args.kwargs
    assert sc_kwargs["mls_states"] is adapter._mls_states
    assert sc_kwargs["account_id"] == "default"  # profile=None → "default"
    assert sc_kwargs["agent_name"] == "hermes-bot"
    # Adapter exposes the live channel after connect.
    assert adapter._secure_channel is fake_channel_instance


@pytest.mark.asyncio
async def test_connect_seeds_conv_to_group_id_for_hydrated_states(
    tmp_path: Path,
) -> None:
    cfg = _make_config()
    adapter = AgentVaultAdapter(cfg)
    fake_state = _make_persisted_state()

    fake_profile_cfg = ProfileConfig(
        profile=None,
        data_dir=tmp_path,
        api_url="https://api.example.com",
        agent_name="hermes-bot",
        http_port=18790,
    )

    # Build one fake conversation on disk so import_state has a file to read.
    conv_id = "33333333-3333-3333-3333-333333333333"
    conv_dir = tmp_path / "conversations" / conv_id
    conv_dir.mkdir(parents=True)
    (conv_dir / "mls_state.bin").write_bytes(b"\x00\x01\x02")

    fake_meta = SimpleNamespace()
    # ConversationMeta.conversation_id is a uuid.UUID — easier to use a real one.
    import uuid as _uuid
    fake_meta.conversation_id = _uuid.UUID(conv_id)

    fake_mls_state = MagicMock()
    fake_mls_state.import_state = MagicMock()
    fake_mls_state.group_id = _uuid.UUID(conv_id).bytes  # 16-byte path
    mls_ctor = MagicMock(return_value=fake_mls_state)

    fake_channel_instance = MagicMock()
    fake_channel_instance.start = AsyncMock()
    fake_channel_instance._conv_to_group_id = {}
    secure_channel_ctor = MagicMock(return_value=fake_channel_instance)

    with (
        patch.object(adapter_module, "migrate_legacy_layout"),
        patch.object(adapter_module, "resolve_profile", return_value=fake_profile_cfg),
        patch.object(adapter_module, "load_state", return_value=fake_state),
        patch.object(adapter_module, "list_conversations", return_value=[fake_meta]),
        patch.object(adapter_module, "MlsGroupState", mls_ctor),
        patch.object(adapter_module, "Relay", MagicMock()),
        patch.object(adapter_module, "SecureChannel", secure_channel_ctor),
    ):
        ok = await adapter.connect()

    assert ok is True
    # Hydrated MLS state went into the in-memory dict.
    assert conv_id in adapter._mls_states
    fake_mls_state.import_state.assert_called_once_with(b"\x00\x01\x02")
    # conv→group_id seeded on the secure channel.
    assert fake_channel_instance._conv_to_group_id[conv_id] == conv_id


# --- send() tests -----------------------------------------------------------


@pytest.mark.asyncio
async def test_send_returns_failure_when_not_connected() -> None:
    adapter = AgentVaultAdapter(_make_config())
    result = await adapter.send("conv-id", "hello")
    assert result.success is False
    assert "not connected" in (result.error or "").lower()


@pytest.mark.asyncio
async def test_send_calls_secure_channel_with_utf8_bytes() -> None:
    adapter = AgentVaultAdapter(_make_config())
    fake_channel = MagicMock()
    fake_channel.send = AsyncMock()
    adapter._secure_channel = fake_channel

    result = await adapter.send("conv-1", "héllo")  # non-ASCII to verify utf-8

    fake_channel.send.assert_awaited_once_with(
        conversation_id="conv-1",
        plaintext="héllo".encode("utf-8"),
    )
    assert result.success is True


@pytest.mark.asyncio
async def test_send_returns_retryable_failure_on_exception() -> None:
    adapter = AgentVaultAdapter(_make_config())
    fake_channel = MagicMock()
    fake_channel.send = AsyncMock(side_effect=RuntimeError("relay down"))
    adapter._secure_channel = fake_channel

    result = await adapter.send("conv-1", "hi")
    assert result.success is False
    assert result.retryable is True
    assert "relay down" in (result.error or "")


# --- disconnect() tests -----------------------------------------------------


@pytest.mark.asyncio
async def test_disconnect_stops_secure_channel() -> None:
    adapter = AgentVaultAdapter(_make_config())
    fake_channel = MagicMock()
    fake_channel.stop = AsyncMock()
    adapter._secure_channel = fake_channel

    await adapter.disconnect()
    fake_channel.stop.assert_awaited_once()
    assert adapter._secure_channel is None


@pytest.mark.asyncio
async def test_disconnect_when_not_connected_is_noop() -> None:
    adapter = AgentVaultAdapter(_make_config())
    await adapter.disconnect()  # must not raise


# --- get_chat_info ---------------------------------------------------------


@pytest.mark.asyncio
async def test_get_chat_info_returns_name_and_dm_type() -> None:
    """``BasePlatformAdapter.get_chat_info`` is abstract — Phase 3 returns
    ``{name, type="dm"}`` since all conversations are 1:1.

    Regression — without this method, ``Can't instantiate abstract class
    AgentVaultAdapter with abstract method get_chat_info`` blocks gateway
    startup (caught during §M1 manual verification).
    """
    adapter = AgentVaultAdapter(_make_config())
    info = await adapter.get_chat_info("conv-xyz")
    assert info == {"name": "conv-xyz", "type": "dm"}


# --- _on_inbound tests ------------------------------------------------------


@pytest.mark.asyncio
async def test_on_inbound_builds_message_event_and_calls_handler() -> None:
    adapter = AgentVaultAdapter(_make_config())
    handler = AsyncMock()
    adapter._message_handler = handler

    inbound = SimpleNamespace(
        conversation_id="conv-xyz",
        sender_device_id="device-abc",
        plaintext="hi there",
        message_type="text",
        is_handshake=False,
        server_message_id="srv-9",
        created_at=None,
        topic_id=None,
        parent_span_id=None,
        room_id=None,
        a2a_channel_id=None,
    )
    await adapter._on_inbound(inbound)

    handler.assert_awaited_once()
    event = handler.await_args.args[0]
    assert event.text == "hi there"
    assert event.message_type == adapter_module.MessageType.TEXT
    # Source matches the adapter's own platform identity.
    assert event.source.platform is adapter.platform
    assert event.source.chat_id == "conv-xyz"
    assert event.source.chat_type == "dm"
    assert event.source.user_id == "device-abc"
    assert event.message_id == "srv-9"


@pytest.mark.asyncio
async def test_on_inbound_drops_message_when_no_handler_set() -> None:
    adapter = AgentVaultAdapter(_make_config())
    adapter._message_handler = None
    inbound = SimpleNamespace(
        conversation_id="conv-xyz",
        sender_device_id="dev",
        plaintext="hi",
        message_type="text",
        is_handshake=False,
        server_message_id=None,
        created_at=None,
        topic_id=None,
        parent_span_id=None,
    )
    # Must not raise.
    await adapter._on_inbound(inbound)


@pytest.mark.asyncio
async def test_on_inbound_dispatches_via_handle_message_not_message_handler_directly() -> None:
    """ROOT-CAUSE regression for Bug B (action_item #163, §M1 blocker).

    The adapter MUST dispatch inbound messages via ``self.handle_message``,
    NOT ``self._message_handler`` directly. The base class's
    ``handle_message`` spawns ``_process_message_background`` which both
    invokes the message handler AND dispatches the returned response via
    ``_send_with_retry → adapter.send``. Calling ``_message_handler``
    directly skips the dispatch step, so the agent's reply is silently
    discarded — the original §M1 Bug B symptom: 100% of LLM-success
    responses disappeared after the first batch.

    Mirrors IRC's plugins/platforms/irc/adapter.py:508 dispatch pattern.
    """
    adapter = AgentVaultAdapter(_make_config())
    # Patch BOTH dispatch surfaces so we can prove ONLY ``handle_message``
    # is invoked. If the adapter regresses to calling _message_handler
    # directly, _message_handler.await_count > 0 and handle_message
    # .await_count == 0, which fails the assertions below.
    direct_handler = AsyncMock()
    adapter._message_handler = direct_handler
    adapter.handle_message = AsyncMock()  # type: ignore[method-assign]
    inbound = SimpleNamespace(
        conversation_id="conv-xyz",
        sender_device_id="dev-peer",
        plaintext="hello hermes",
        message_type="text",
        is_handshake=False,
        server_message_id="srv-1",
        created_at=None,
        topic_id=None,
        parent_span_id=None,
        room_id=None,
        a2a_channel_id=None,
    )
    await adapter._on_inbound(inbound)
    # Bug-B regression assertions: dispatch goes through handle_message,
    # NOT _message_handler.
    adapter.handle_message.assert_awaited_once()
    direct_handler.assert_not_awaited()
    # And the event passed to handle_message has the right shape.
    event = adapter.handle_message.await_args.args[0]
    assert event.text == "hello hermes"
    assert event.source.chat_id == "conv-xyz"
    assert event.source.user_id == "dev-peer"


@pytest.mark.asyncio
async def test_on_inbound_filters_handshake_messages() -> None:
    """Regression — DA WS-31 M5.

    SecureChannel._demux_loop already filters is_handshake before invoking
    on_inbound (channel/secure_channel.py:443-444). This is defense-in-depth:
    if that contract regresses, the adapter must NOT forward MLS Commit /
    Proposal / Welcome frames to the LLM as empty-text messages.
    """
    adapter = AgentVaultAdapter(_make_config())
    handler = AsyncMock()
    adapter._message_handler = handler
    inbound = SimpleNamespace(
        conversation_id="conv-xyz",
        sender_device_id="dev-peer",
        plaintext="",
        message_type="handshake",
        is_handshake=True,  # KEY — this is what the filter must catch.
        server_message_id="srv-handshake",
        created_at=None,
        topic_id=None,
        parent_span_id=None,
    )
    await adapter._on_inbound(inbound)
    handler.assert_not_awaited()


# --- Task 12: room chat typing -----------------------------------------------


@pytest.mark.asyncio
async def test_on_inbound_room_message_sets_room_chat_type() -> None:
    """A room InboundMessage produces a SessionSource with chat_type='room'
    and chat_id=room_id."""
    from agentvault_hermes.channel.secure_channel import InboundMessage

    adapter = AgentVaultAdapter(_make_config())

    captured = {}

    async def _capture(event):
        captured["chat_type"] = event.source.chat_type
        captured["chat_id"] = event.source.chat_id

    adapter.handle_message = _capture  # type: ignore[method-assign]
    adapter._message_handler = object()  # non-None so _on_inbound proceeds

    await adapter._on_inbound(InboundMessage(
        conversation_id="room-9",
        sender_device_id="d-1",
        plaintext="[Chris]: hi",
        message_type="text",
        is_handshake=False,
        room_id="room-9",
    ))
    assert captured["chat_type"] == "room"
    assert captured["chat_id"] == "room-9"


@pytest.mark.asyncio
async def test_on_inbound_dm_message_keeps_dm_chat_type() -> None:
    """A 1:1 InboundMessage (room_id=None) still produces chat_type='dm'."""
    from agentvault_hermes.channel.secure_channel import InboundMessage

    adapter = AgentVaultAdapter(_make_config())

    captured = {}

    async def _capture(event):
        captured["chat_type"] = event.source.chat_type
        captured["chat_id"] = event.source.chat_id

    adapter.handle_message = _capture  # type: ignore[method-assign]
    adapter._message_handler = object()  # non-None so _on_inbound proceeds

    await adapter._on_inbound(InboundMessage(
        conversation_id="conv-dm-1",
        sender_device_id="d-1",
        plaintext="hello",
        message_type="text",
        is_handshake=False,
        room_id=None,
    ))
    assert captured["chat_type"] == "dm"
    assert captured["chat_id"] == "conv-dm-1"


@pytest.mark.asyncio
async def test_get_chat_info_returns_room_type_for_known_room() -> None:
    """get_chat_info returns type='room' and the room name for a room_id
    that the SecureChannel's RoomDirectory knows about."""
    from agentvault_hermes.channel.room_directory import RoomEntry

    adapter = AgentVaultAdapter(_make_config())

    # Install a fake SecureChannel with a real-enough _room_directory stub.
    fake_entry = RoomEntry(room_id="room-42", name="Launch Room")
    fake_dir = MagicMock()
    fake_dir.get = MagicMock(return_value=fake_entry)
    fake_a2a = MagicMock()
    fake_a2a.get = MagicMock(return_value=None)  # action #238 — not an A2A channel
    fake_channel = MagicMock()
    fake_channel._room_directory = fake_dir
    fake_channel._a2a_registry = fake_a2a
    adapter._secure_channel = fake_channel

    info = await adapter.get_chat_info("room-42")
    assert info["type"] == "room"
    assert info["name"] == "Launch Room"


@pytest.mark.asyncio
async def test_get_chat_info_falls_back_to_dm_for_unknown_chat() -> None:
    """get_chat_info returns type='dm' when the chat_id is not in the RoomDirectory."""
    adapter = AgentVaultAdapter(_make_config())

    fake_dir = MagicMock()
    fake_dir.get = MagicMock(return_value=None)
    fake_a2a = MagicMock()
    fake_a2a.get = MagicMock(return_value=None)  # action #238 — also not A2A
    fake_channel = MagicMock()
    fake_channel._room_directory = fake_dir
    fake_channel._a2a_registry = fake_a2a
    adapter._secure_channel = fake_channel

    info = await adapter.get_chat_info("conv-not-a-room")
    assert info["type"] == "dm"
    assert info["name"] == "conv-not-a-room"


@pytest.mark.asyncio
async def test_get_chat_info_falls_back_to_dm_when_no_secure_channel() -> None:
    """get_chat_info returns type='dm' when _secure_channel is None (not connected)."""
    adapter = AgentVaultAdapter(_make_config())
    # _secure_channel is None by default (not connected)
    assert adapter._secure_channel is None

    info = await adapter.get_chat_info("conv-xyz")
    assert info == {"name": "conv-xyz", "type": "dm"}


# --- DA WS-31 regressions: connect() rollback + idempotency -----------------


@pytest.mark.asyncio
async def test_connect_rolls_back_secure_channel_when_start_raises(
    tmp_path: Path,
) -> None:
    """Regression — DA WS-31 C1.

    If ``SecureChannel.start()`` raises (relay timeout, auth reject, demux
    setup error), the adapter must call ``stop()`` on the partially-built
    channel and clear ``_secure_channel`` BEFORE re-raising. Otherwise the
    WS + 4 background tasks leak and Hermes won't necessarily call
    disconnect() on a connect() that raised.
    """

    cfg = _make_config()
    adapter = AgentVaultAdapter(cfg)
    fake_state = _make_persisted_state()
    fake_profile_cfg = ProfileConfig(
        profile=None,
        data_dir=tmp_path,
        api_url="https://api.example.com",
        agent_name=None,
        http_port=18790,
    )

    fake_channel_instance = MagicMock()
    fake_channel_instance.start = AsyncMock(side_effect=RuntimeError("WS handshake failed"))
    fake_channel_instance.stop = AsyncMock()
    fake_channel_instance._conv_to_group_id = {}
    secure_channel_ctor = MagicMock(return_value=fake_channel_instance)

    with (
        patch.object(adapter_module, "migrate_legacy_layout"),
        patch.object(adapter_module, "resolve_profile", return_value=fake_profile_cfg),
        patch.object(adapter_module, "load_state", return_value=fake_state),
        patch.object(adapter_module, "list_conversations", return_value=[]),
        patch.object(adapter_module, "Relay", MagicMock()),
        patch.object(adapter_module, "SecureChannel", secure_channel_ctor),
        pytest.raises(RuntimeError, match="WS handshake failed"),
    ):
        await adapter.connect()

    # The half-built channel was torn down before the exception escaped.
    fake_channel_instance.stop.assert_awaited_once()
    # And the slot is None so a subsequent connect() won't double-stop.
    assert adapter._secure_channel is None


@pytest.mark.asyncio
async def test_connect_is_idempotent_tears_down_previous_channel(
    tmp_path: Path,
) -> None:
    """Regression — DA WS-31 C2.

    Calling ``connect()`` twice (Hermes reconnect / supervisor flap) must
    NOT leak the previous SecureChannel. The previous channel + WS + tasks
    must be stopped, and ``_mls_states`` must be cleared so the rebuild
    reads fresh from disk (otherwise stale MLS state from a previous
    session bleeds into the new one).
    """

    cfg = _make_config()
    adapter = AgentVaultAdapter(cfg)
    fake_state = _make_persisted_state()
    fake_profile_cfg = ProfileConfig(
        profile=None,
        data_dir=tmp_path,
        api_url="https://api.example.com",
        agent_name=None,
        http_port=18790,
    )

    # First channel — happy connect.
    first_channel = MagicMock()
    first_channel.start = AsyncMock()
    first_channel.stop = AsyncMock()
    first_channel._conv_to_group_id = {}

    # Second channel — built on the second connect() call.
    second_channel = MagicMock()
    second_channel.start = AsyncMock()
    second_channel.stop = AsyncMock()
    second_channel._conv_to_group_id = {}

    secure_channel_ctor = MagicMock(side_effect=[first_channel, second_channel])

    with (
        patch.object(adapter_module, "migrate_legacy_layout"),
        patch.object(adapter_module, "resolve_profile", return_value=fake_profile_cfg),
        patch.object(adapter_module, "load_state", return_value=fake_state),
        patch.object(adapter_module, "list_conversations", return_value=[]),
        patch.object(adapter_module, "Relay", MagicMock()),
        patch.object(adapter_module, "SecureChannel", secure_channel_ctor),
    ):
        ok1 = await adapter.connect()
        # Seed a stale entry to verify _mls_states is cleared on re-connect.
        adapter._mls_states["stale-conv"] = MagicMock()
        ok2 = await adapter.connect()

    assert ok1 is True
    assert ok2 is True
    # Previous channel was stopped before the second connect built a new one.
    first_channel.stop.assert_awaited_once()
    second_channel.start.assert_awaited_once()
    # Adapter now points at the second channel, not the first.
    assert adapter._secure_channel is second_channel
    # Stale dict entry was cleared at the top of the second connect().
    assert "stale-conv" not in adapter._mls_states


# --- DA WS-31 M2: specific exception types in _hydrate_mls_states ----------


@pytest.mark.asyncio
async def test_hydrate_logs_error_and_skips_corrupt_state_blob(
    tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    """Corrupt mls_state.bin → ValueError on import → logged at ERROR + skipped.

    Tightened from bare Exception so KeyboardInterrupt / programmer errors
    surface; ValueError covers corrupt TLV / bad bytes; OSError covers disk
    read failures; RuntimeError covers MlsGroupState contract violations.
    """

    cfg = _make_config()
    adapter = AgentVaultAdapter(cfg)
    fake_state = _make_persisted_state()
    fake_profile_cfg = ProfileConfig(
        profile=None,
        data_dir=tmp_path,
        api_url="https://api.example.com",
        agent_name=None,
        http_port=18790,
    )

    import uuid as _uuid

    # Build a "bad" conversation on disk.
    bad_conv_id = "44444444-4444-4444-4444-444444444444"
    bad_conv_dir = tmp_path / "conversations" / bad_conv_id
    bad_conv_dir.mkdir(parents=True)
    (bad_conv_dir / "mls_state.bin").write_bytes(b"\xff" * 16)
    bad_meta = SimpleNamespace(conversation_id=_uuid.UUID(bad_conv_id))

    # Build a "good" conversation on disk so we can verify the bad one is
    # skipped without breaking the good one.
    good_conv_id = "55555555-5555-5555-5555-555555555555"
    good_conv_dir = tmp_path / "conversations" / good_conv_id
    good_conv_dir.mkdir(parents=True)
    (good_conv_dir / "mls_state.bin").write_bytes(b"\x01" * 16)
    good_meta = SimpleNamespace(conversation_id=_uuid.UUID(good_conv_id))

    # MlsGroupState ctor returns a state whose import_state raises ValueError
    # for the bad blob and succeeds for the good one.
    call_count = {"n": 0}

    def _mls_factory(**kwargs: Any) -> MagicMock:
        call_count["n"] += 1
        instance = MagicMock()
        if call_count["n"] == 1:
            instance.import_state = MagicMock(side_effect=ValueError("corrupt TLV"))
        else:
            instance.import_state = MagicMock()
            instance.group_id = _uuid.UUID(good_conv_id).bytes
        return instance

    fake_channel = MagicMock()
    fake_channel.start = AsyncMock()
    fake_channel._conv_to_group_id = {}

    with (
        patch.object(adapter_module, "migrate_legacy_layout"),
        patch.object(adapter_module, "resolve_profile", return_value=fake_profile_cfg),
        patch.object(adapter_module, "load_state", return_value=fake_state),
        patch.object(
            adapter_module,
            "list_conversations",
            return_value=[bad_meta, good_meta],
        ),
        patch.object(adapter_module, "MlsGroupState", side_effect=_mls_factory),
        patch.object(adapter_module, "Relay", MagicMock()),
        patch.object(adapter_module, "SecureChannel", MagicMock(return_value=fake_channel)),
        caplog.at_level("ERROR", logger="agentvault_hermes.plugins.agentvault.adapter"),
    ):
        ok = await adapter.connect()

    assert ok is True
    # Bad conv skipped, good conv loaded.
    assert bad_conv_id not in adapter._mls_states
    assert good_conv_id in adapter._mls_states
    # ERROR-level log (not WARNING) so the user actually sees it.
    assert any(
        "Failed to hydrate MLS state" in r.message and r.levelname == "ERROR"
        for r in caplog.records
    )
