"""Unit test: the AV adapter reports chat_type 'a2a' for A2A conversations."""
from __future__ import annotations

import inspect

from agentvault_hermes.plugins.agentvault import adapter as adapter_mod


def test_on_inbound_sets_a2a_chat_type() -> None:
    src = inspect.getsource(adapter_mod.AgentVaultAdapter._on_inbound)
    assert '"a2a"' in src or "'a2a'" in src


def test_get_chat_info_handles_a2a() -> None:
    src = inspect.getsource(adapter_mod.AgentVaultAdapter.get_chat_info)
    assert '"a2a"' in src or "'a2a'" in src
