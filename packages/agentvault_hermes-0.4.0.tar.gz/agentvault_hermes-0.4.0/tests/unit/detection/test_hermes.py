"""Tests for the 4-tier Hermes install detection cascade.

Per the Layer 1 spec, the cascade is (highest priority first):
  Tier 1: HERMES_INSTALL_DIR env var set AND points at an existing dir
  Tier 2: ~/.hermes/hermes-agent/ exists
  Tier 3: `which hermes` returns success
  Tier 4: nothing detected
"""
from __future__ import annotations

from pathlib import Path

import pytest

from agentvault_hermes.core.detection.hermes import (
    HermesDetectionResult,
    detect_hermes_install,
)


def _mk_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    return home


def test_tier1_env_override(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    _mk_home(tmp_path, monkeypatch)
    custom = tmp_path / "custom-hermes"
    custom.mkdir()
    monkeypatch.setenv("HERMES_INSTALL_DIR", str(custom))
    monkeypatch.setenv("PATH", str(tmp_path))

    result = detect_hermes_install()
    assert isinstance(result, HermesDetectionResult)
    assert result.detected is True
    assert result.tier == 1
    assert result.install_dir == custom
    assert "HERMES_INSTALL_DIR" in result.reason


def test_tier2_default_install_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    home = _mk_home(tmp_path, monkeypatch)
    (home / ".hermes" / "hermes-agent").mkdir(parents=True)
    monkeypatch.delenv("HERMES_INSTALL_DIR", raising=False)
    monkeypatch.setenv("PATH", str(tmp_path))

    result = detect_hermes_install()
    assert result.detected is True
    assert result.tier == 2
    assert result.install_dir == home / ".hermes" / "hermes-agent"


def test_tier3_binary_on_path(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    _mk_home(tmp_path, monkeypatch)
    monkeypatch.delenv("HERMES_INSTALL_DIR", raising=False)

    fake_path_dir = tmp_path / "fake-path"
    fake_path_dir.mkdir()
    fake_hermes = fake_path_dir / "hermes"
    fake_hermes.write_text("#!/bin/sh\necho 'fake hermes'\n")
    fake_hermes.chmod(0o755)
    monkeypatch.setenv("PATH", str(fake_path_dir))

    result = detect_hermes_install()
    assert result.detected is True
    assert result.tier == 3
    assert result.install_dir is None
    assert "PATH" in result.reason


def test_tier4_no_detection(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    _mk_home(tmp_path, monkeypatch)
    monkeypatch.delenv("HERMES_INSTALL_DIR", raising=False)
    monkeypatch.setenv("PATH", str(tmp_path))

    result = detect_hermes_install()
    assert result.detected is False
    assert result.tier == 4
    assert result.install_dir is None
    assert "no hermes" in result.reason.lower()


def test_env_override_with_nonexistent_dir_falls_through(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    """If HERMES_INSTALL_DIR points at a non-existent path, ignore it
    and fall through to lower tiers."""
    home = _mk_home(tmp_path, monkeypatch)
    (home / ".hermes" / "hermes-agent").mkdir(parents=True)
    monkeypatch.setenv("HERMES_INSTALL_DIR", str(tmp_path / "does-not-exist"))
    monkeypatch.setenv("PATH", str(tmp_path))

    result = detect_hermes_install()
    assert result.detected is True
    assert result.tier == 2


def test_cascade_prefers_tier1_over_tier2(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    home = _mk_home(tmp_path, monkeypatch)
    (home / ".hermes" / "hermes-agent").mkdir(parents=True)
    custom = tmp_path / "custom-hermes"
    custom.mkdir()
    monkeypatch.setenv("HERMES_INSTALL_DIR", str(custom))
    monkeypatch.setenv("PATH", str(tmp_path))

    result = detect_hermes_install()
    assert result.tier == 1
    assert result.install_dir == custom
