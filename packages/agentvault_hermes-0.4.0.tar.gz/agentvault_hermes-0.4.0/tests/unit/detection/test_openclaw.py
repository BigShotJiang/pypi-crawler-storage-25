"""Tests for the 4-tier OpenClaw install detection cascade.

Per the design doc (Q11), the cascade is:
  Tier 1: ~/.openclaw/agentvault/ exists       → port 18791
  Tier 2: ~/.openclaw/ exists                  → port 18791
  Tier 3: `which openclaw` returns success     → port 18791
  Tier 4: nothing detected                     → port 18790
"""
from __future__ import annotations

from pathlib import Path

import pytest

from agentvault_hermes.core.detection.openclaw import (
    DetectionResult,
    detect_openclaw_install,
)


def _mk_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    return home


def test_tier1_av_plugin_dir_exists(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    home = _mk_home(tmp_path, monkeypatch)
    (home / ".openclaw" / "agentvault").mkdir(parents=True)

    result = detect_openclaw_install()
    assert isinstance(result, DetectionResult)
    assert result.recommended_port == 18791
    assert result.tier == 1
    assert "agentvault plugin" in result.reason.lower()


def test_tier2_oc_dir_only(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    home = _mk_home(tmp_path, monkeypatch)
    (home / ".openclaw").mkdir()

    result = detect_openclaw_install()
    assert result.recommended_port == 18791
    assert result.tier == 2


def test_tier3_binary_on_path(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    _mk_home(tmp_path, monkeypatch)

    fake_path_dir = tmp_path / "fake-path"
    fake_path_dir.mkdir()
    fake_oc_bin = fake_path_dir / "openclaw"
    fake_oc_bin.write_text("#!/bin/sh\necho 'fake openclaw'\n")
    fake_oc_bin.chmod(0o755)

    monkeypatch.setenv("PATH", str(fake_path_dir))

    result = detect_openclaw_install()
    assert result.recommended_port == 18791
    assert result.tier == 3


def test_tier4_no_detection(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    _mk_home(tmp_path, monkeypatch)
    monkeypatch.setenv("PATH", str(tmp_path))  # empty PATH directory

    result = detect_openclaw_install()
    assert result.recommended_port == 18790
    assert result.tier == 4
    assert "no openclaw" in result.reason.lower()


def test_cascade_prefers_tier1_over_tier2(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    home = _mk_home(tmp_path, monkeypatch)
    (home / ".openclaw" / "agentvault").mkdir(parents=True)

    result = detect_openclaw_install()
    assert result.tier == 1  # specific match wins


def test_cascade_prefers_tier2_over_tier3(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    home = _mk_home(tmp_path, monkeypatch)
    (home / ".openclaw").mkdir()

    fake_path_dir = tmp_path / "fake-path"
    fake_path_dir.mkdir()
    fake_oc_bin = fake_path_dir / "openclaw"
    fake_oc_bin.write_text("#!/bin/sh\necho 'fake'\n")
    fake_oc_bin.chmod(0o755)
    monkeypatch.setenv("PATH", str(fake_path_dir))

    result = detect_openclaw_install()
    assert result.tier == 2  # filesystem match wins over PATH match
