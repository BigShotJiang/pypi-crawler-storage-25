"""Tests for the MLS convenience methods on RestClient.

Stage 1 of the Hermes Phase 3 MLS Welcome support work-stream
(see docs/plans/2026-05-10-hermes-phase3-welcome-support-implementation.md
§3.1 + §5.1).

Uses respx to mock HTTP responses without a live backend.
"""

from __future__ import annotations

import logging
from urllib.parse import parse_qs, urlparse

import pytest
import respx

from agentvault_hermes.core.transport.rest_client import (
    RestClient,
    RestClientError,
)


@pytest.mark.asyncio
async def test_publish_key_package_happy_path() -> None:
    async with respx.mock(base_url="https://api.example.com") as mock:
        route = mock.post("/api/v1/mls/key-packages").respond(
            json={"id": "11111111-1111-1111-1111-111111111111", "device_id": "dev-uuid"},
        )

        client = RestClient(
            base_url="https://api.example.com",
            device_jwt="ey.device.jwt",
        )
        async with client:
            data = await client.publish_key_package("deadbeef")

        assert data == {
            "id": "11111111-1111-1111-1111-111111111111",
            "device_id": "dev-uuid",
        }
        assert route.called
        request = mock.calls[0].request
        assert request.url.path == "/api/v1/mls/key-packages"
        assert request.headers["authorization"] == "Bearer ey.device.jwt"

        body = request.read().decode()
        assert '"key_package":"deadbeef"' in body or '"key_package": "deadbeef"' in body
        # device_id MUST NOT be present in the body — Hermes uses device-JWT auth
        # and the backend resolves device_id from the token (mls.py:58).
        assert '"device_id"' not in body


@pytest.mark.asyncio
async def test_publish_key_package_4xx() -> None:
    async with respx.mock(base_url="https://api.example.com") as mock:
        mock.post("/api/v1/mls/key-packages").respond(
            status_code=400,
            json={"detail": "invalid key_package hex"},
        )

        client = RestClient(
            base_url="https://api.example.com",
            device_jwt="ey.device.jwt",
        )
        async with client:
            with pytest.raises(RestClientError) as exc_info:
                await client.publish_key_package("deadbeef")

        assert exc_info.value.status_code == 400
        assert "invalid key_package hex" in exc_info.value.body


@pytest.mark.asyncio
async def test_publish_key_package_empty_hex_raises() -> None:
    client = RestClient(base_url="https://api.example.com")
    async with client:
        with pytest.raises(ValueError):
            await client.publish_key_package("")


@pytest.mark.asyncio
async def test_pull_mls_delivery_happy_path() -> None:
    device_uuid = "22222222-2222-2222-2222-222222222222"
    rows = [
        {"queue_id": "q1", "message_type": "welcome", "payload": "aa"},
        {"queue_id": "q2", "message_type": "commit", "payload": "bb"},
        {"queue_id": "q3", "message_type": "application", "payload": "cc"},
    ]

    async with respx.mock(base_url="https://api.example.com") as mock:
        mock.get("/api/v1/mls/delivery").respond(json={"messages": rows})

        client = RestClient(
            base_url="https://api.example.com",
            device_jwt="ey.device.jwt",
        )
        async with client:
            result = await client.pull_mls_delivery(device_uuid)

        # Helper unwraps the envelope — returns the list, not the dict.
        assert result == rows
        assert isinstance(result, list)

        request = mock.calls[0].request
        assert request.url.path == "/api/v1/mls/delivery"
        query = parse_qs(urlparse(str(request.url)).query)
        assert query.get("device_id") == [device_uuid]


@pytest.mark.asyncio
async def test_pull_mls_delivery_empty() -> None:
    async with respx.mock(base_url="https://api.example.com") as mock:
        mock.get("/api/v1/mls/delivery").respond(json={"messages": []})

        client = RestClient(base_url="https://api.example.com")
        async with client:
            result = await client.pull_mls_delivery("dev-uuid")

        assert result == []


@pytest.mark.asyncio
async def test_pull_mls_delivery_null_messages() -> None:
    # DA finding (Stage 1 review): backend may emit `{"messages": null}` instead
    # of `{"messages": []}`. The helper must coerce to [] rather than return None
    # and crash downstream `for msg in messages:` with TypeError.
    async with respx.mock(base_url="https://api.example.com") as mock:
        mock.get("/api/v1/mls/delivery").respond(json={"messages": None})

        client = RestClient(base_url="https://api.example.com")
        async with client:
            result = await client.pull_mls_delivery("dev-uuid")

        assert result == []
        assert isinstance(result, list)


@pytest.mark.asyncio
async def test_ack_returns_count() -> None:
    async with respx.mock(base_url="https://api.example.com") as mock:
        mock.post("/api/v1/mls/delivery/ack").respond(json={"acked": 3})

        client = RestClient(base_url="https://api.example.com")
        async with client:
            count = await client.ack_mls_delivery(["q1", "q2", "q3"], "dev-uuid")

        assert count == 3


@pytest.mark.asyncio
async def test_ack_empty_queue_ids_raises() -> None:
    client = RestClient(base_url="https://api.example.com")
    async with client:
        with pytest.raises(ValueError):
            await client.ack_mls_delivery([], "dev-uuid")


@pytest.mark.asyncio
async def test_nack_best_effort_swallows_5xx(
    caplog: pytest.LogCaptureFixture,
) -> None:
    async with respx.mock(base_url="https://api.example.com") as mock:
        mock.post("/api/v1/mls/delivery/nack").respond(
            status_code=500,
            json={"detail": "internal error"},
        )

        client = RestClient(base_url="https://api.example.com")
        with caplog.at_level(
            logging.WARNING,
            logger="agentvault_hermes.core.transport.rest_client",
        ):
            async with client:
                # Must NOT raise — best-effort per §3.1.
                await client.nack_mls_delivery(["q1"])

        assert any(
            "nack_mls_delivery best-effort failure" in record.message for record in caplog.records
        )
