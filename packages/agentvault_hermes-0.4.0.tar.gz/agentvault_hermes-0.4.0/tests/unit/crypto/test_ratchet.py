"""Tests for crypto.ratchet — Double Ratchet implementation.

Reference: packages/crypto/src/ratchet.ts. Port must produce byte-identical
output for the same inputs; recorded-vector verification in WS-24.
"""
from __future__ import annotations

import os

import pytest

from agentvault_hermes.crypto.ratchet import (
    CHAIN_KEY_SEED,
    HEADER_KEY_SEED,
    MAX_SKIP,
    MSG_KEY_SEED,
    DoubleRatchet,
    EncryptedMessage,
    RatchetHeader,
    RatchetTelemetryEvent,
    SigningKeypair,
    _dh,
    _generate_dh_keypair,
    _kdf_chain_key,
    _kdf_root_key,
    _serialize_header,
    _sign_header,
    _verify_header_signature,
)


# --- Constants ---

def test_max_skip_is_1000():
    assert MAX_SKIP == 1000


def test_kdf_seeds_match_oc():
    """The single-byte seeds are domain separators; must match OC byte-exactly."""
    assert CHAIN_KEY_SEED == b"\x01"
    assert MSG_KEY_SEED == b"\x02"
    assert HEADER_KEY_SEED == b"\x03"


# --- KDF chain ---

def test_kdf_chain_key_returns_three_distinct_32_byte_outputs():
    chain_key = os.urandom(32)
    next_chain, msg_key, header_key = _kdf_chain_key(chain_key)
    assert len(next_chain) == 32
    assert len(msg_key) == 32
    assert len(header_key) == 32
    assert next_chain != msg_key
    assert next_chain != header_key
    assert msg_key != header_key


def test_kdf_chain_key_deterministic():
    chain_key = os.urandom(32)
    a = _kdf_chain_key(chain_key)
    b = _kdf_chain_key(chain_key)
    assert a == b


# --- KDF root ---

def test_kdf_root_key_returns_root_and_chain():
    root = os.urandom(32)
    dh = os.urandom(32)
    new_root, new_chain = _kdf_root_key(root, dh)
    assert len(new_root) == 32
    assert len(new_chain) == 32
    assert new_root != new_chain


def test_kdf_root_key_advances_root():
    root = os.urandom(32)
    dh = os.urandom(32)
    new_root, _ = _kdf_root_key(root, dh)
    assert new_root != root


# --- DH keypair + DH op ---

def test_generate_dh_keypair_returns_32_byte_pair():
    kp = _generate_dh_keypair()
    assert len(kp.public_key) == 32
    assert len(kp.private_key) == 32


def test_generate_dh_keypair_unique_each_call():
    a = _generate_dh_keypair()
    b = _generate_dh_keypair()
    assert a.private_key != b.private_key
    assert a.public_key != b.public_key


def test_dh_produces_shared_secret():
    a = _generate_dh_keypair()
    b = _generate_dh_keypair()
    s_ab = _dh(a.private_key, b.public_key)
    s_ba = _dh(b.private_key, a.public_key)
    assert s_ab == s_ba
    assert len(s_ab) == 32


# --- Header serialization + signing ---

def test_serialize_header_deterministic():
    header = RatchetHeader(
        dh_public_key=os.urandom(32),
        previous_chain_length=5,
        message_number=12,
    )
    a = _serialize_header(header)
    b = _serialize_header(header)
    assert a == b


def test_serialize_header_differs_for_different_input():
    h1 = RatchetHeader(dh_public_key=os.urandom(32), previous_chain_length=0, message_number=0)
    h2 = RatchetHeader(dh_public_key=os.urandom(32), previous_chain_length=0, message_number=0)
    assert _serialize_header(h1) != _serialize_header(h2)


def test_sign_and_verify_header_round_trip():
    from nacl import signing as nacl_signing
    sk = nacl_signing.SigningKey.generate()
    keypair = SigningKeypair(public_key=bytes(sk.verify_key), private_key=bytes(sk))
    header = RatchetHeader(
        dh_public_key=os.urandom(32),
        previous_chain_length=0,
        message_number=0,
    )
    sig = _sign_header(keypair, header)
    assert _verify_header_signature(keypair.public_key, header, sig) is True


def test_verify_header_signature_fails_for_tampered_header():
    from nacl import signing as nacl_signing
    sk = nacl_signing.SigningKey.generate()
    keypair = SigningKeypair(public_key=bytes(sk.verify_key), private_key=bytes(sk))
    header = RatchetHeader(
        dh_public_key=os.urandom(32),
        previous_chain_length=0,
        message_number=0,
    )
    sig = _sign_header(keypair, header)
    tampered = RatchetHeader(
        dh_public_key=header.dh_public_key,
        previous_chain_length=999,  # changed
        message_number=header.message_number,
    )
    assert _verify_header_signature(keypair.public_key, tampered, sig) is False


# --- DoubleRatchet init + serialize/deserialize ---

def _signing_keypair() -> SigningKeypair:
    from nacl import signing as nacl_signing
    sk = nacl_signing.SigningKey.generate()
    return SigningKeypair(public_key=bytes(sk.verify_key), private_key=bytes(sk))


def test_init_initiator_creates_ratchet_with_sending_chain_seeded_from_shared_secret():
    """OC's initSender (ratchet.ts:129-150): rootKey = sendingChain.chainKey =
    sharedSecret; dhReceivingPublicKey = None; receivingChain = None.

    The DH ratchet step is lazy — performed in encrypt() when the first
    outbound message is sent (or in decrypt() on first inbound).
    """
    shared_secret = os.urandom(32)
    my_signing = _signing_keypair()
    peer_signing_pub = bytes(_signing_keypair().public_key)

    rt = DoubleRatchet.init_initiator(
        shared_secret=shared_secret,
        identity_keypair=my_signing,
        peer_identity_public_key=peer_signing_pub,
    )
    # Per OC: sending chain populated, receiving chain None
    assert rt._state.sending_chain is not None
    assert rt._state.sending_chain.chain_key == shared_secret
    assert rt._state.sending_chain.message_number == 0
    assert rt._state.receiving_chain is None
    # Per OC: rootKey = sharedSecret (no DH performed yet)
    assert rt._state.root_key == shared_secret
    # Per OC: dhReceivingPublicKey starts None
    assert rt._state.dh_receiving_public_key is None


def test_init_receiver_creates_ratchet_with_receiving_chain_seeded_from_shared_secret():
    """OC's initReceiver (ratchet.ts:152-173): rootKey = receivingChain.chainKey
    = sharedSecret; sendingChain = None; dhReceivingPublicKey = None.

    The first inbound message uses the receiving chain seeded from the shared
    secret; the DH ratchet bootstraps lazily.
    """
    shared_secret = os.urandom(32)
    my_signing = _signing_keypair()
    peer_signing_pub = bytes(_signing_keypair().public_key)

    rt = DoubleRatchet.init_receiver(
        shared_secret=shared_secret,
        identity_keypair=my_signing,
        peer_identity_public_key=peer_signing_pub,
    )
    # Per OC: receiving chain populated, sending chain None
    assert rt._state.receiving_chain is not None
    assert rt._state.receiving_chain.chain_key == shared_secret
    assert rt._state.receiving_chain.message_number == 0
    assert rt._state.sending_chain is None
    # Per OC: rootKey = sharedSecret
    assert rt._state.root_key == shared_secret
    # Per OC: dhReceivingPublicKey starts None
    assert rt._state.dh_receiving_public_key is None


def test_init_initiator_and_receiver_produce_compatible_root_keys():
    """OC: both sides initialize root_key = shared_secret. No DH advance until
    the first message exchange. Therefore the post-init root keys must match."""
    shared = os.urandom(32)

    rt_init = DoubleRatchet.init_initiator(
        shared_secret=shared,
        identity_keypair=_signing_keypair(),
        peer_identity_public_key=bytes(_signing_keypair().public_key),
    )
    rt_recv = DoubleRatchet.init_receiver(
        shared_secret=shared,
        identity_keypair=_signing_keypair(),
        peer_identity_public_key=bytes(_signing_keypair().public_key),
    )
    assert rt_init._state.root_key == rt_recv._state.root_key == shared


def test_init_works_without_peer_identity_public_key():
    """OC's peerIdentityPublicKey is optional. Verify the Python port allows
    None (which signals header-signature verification skipped)."""
    shared = os.urandom(32)
    rt = DoubleRatchet.init_initiator(
        shared_secret=shared,
        identity_keypair=_signing_keypair(),
        peer_identity_public_key=None,
    )
    assert rt._state.peer_identity_public_key is None


def test_serialize_returns_string():
    rt = DoubleRatchet.init_initiator(
        shared_secret=os.urandom(32),
        identity_keypair=_signing_keypair(),
        peer_identity_public_key=bytes(_signing_keypair().public_key),
    )
    data = rt.serialize()
    assert isinstance(data, str)
    assert len(data) > 100  # contains hex-encoded keys + JSON structure


def test_deserialize_round_trip():
    rt1 = DoubleRatchet.init_initiator(
        shared_secret=os.urandom(32),
        identity_keypair=_signing_keypair(),
        peer_identity_public_key=bytes(_signing_keypair().public_key),
    )
    serialized = rt1.serialize()
    rt2 = DoubleRatchet.deserialize(serialized)
    assert rt1._state.root_key == rt2._state.root_key
    assert rt1._state.dh_sending_keypair == rt2._state.dh_sending_keypair
    assert rt1._state.dh_receiving_public_key == rt2._state.dh_receiving_public_key
    assert rt1._state.identity_keypair == rt2._state.identity_keypair
    assert rt1._state.peer_identity_public_key == rt2._state.peer_identity_public_key
    assert rt1._state.previous_sending_chain_length == rt2._state.previous_sending_chain_length
    # Sending chain field equality
    assert rt1._state.sending_chain is not None
    assert rt2._state.sending_chain is not None
    assert rt1._state.sending_chain.chain_key == rt2._state.sending_chain.chain_key
    assert rt1._state.sending_chain.message_number == rt2._state.sending_chain.message_number
    # Receiving chain on initiator is None
    assert rt1._state.receiving_chain is None
    assert rt2._state.receiving_chain is None


def test_deserialize_rejects_corrupt_input():
    with pytest.raises(ValueError):
        DoubleRatchet.deserialize("not valid json {")


# --- DoubleRatchet.encrypt (v1, unencrypted header) ---

def _initiator() -> DoubleRatchet:
    """Helper: build an initiator-mode ratchet with a fresh shared secret."""
    return DoubleRatchet.init_initiator(
        shared_secret=os.urandom(32),
        identity_keypair=_signing_keypair(),
        peer_identity_public_key=bytes(_signing_keypair().public_key),
    )


def test_encrypt_returns_encrypted_message():
    rt = _initiator()
    msg = rt.encrypt(b"hello world")
    assert isinstance(msg, EncryptedMessage)
    assert isinstance(msg.ciphertext, bytes)
    assert len(msg.ciphertext) > 0
    assert len(msg.nonce) == 24  # XChaCha20 nonce
    assert len(msg.header_signature) == 64  # Ed25519 signature
    assert msg.envelope_version is None  # v1: header in clear


def test_encrypt_advances_message_number():
    rt = _initiator()
    m1 = rt.encrypt(b"first")
    m2 = rt.encrypt(b"second")
    m3 = rt.encrypt(b"third")
    assert m1.header.message_number == 0
    assert m2.header.message_number == 1
    assert m3.header.message_number == 2


def test_encrypt_each_message_has_fresh_nonce():
    rt = _initiator()
    nonces = {rt.encrypt(b"x").nonce for _ in range(20)}
    assert len(nonces) == 20  # all unique


def test_encrypt_header_signature_verifies():
    my_signing = _signing_keypair()
    rt = DoubleRatchet.init_initiator(
        shared_secret=os.urandom(32),
        identity_keypair=my_signing,
        peer_identity_public_key=bytes(_signing_keypair().public_key),
    )
    msg = rt.encrypt(b"hello")
    assert _verify_header_signature(my_signing.public_key, msg.header, msg.header_signature) is True


def test_encrypt_in_receiver_mode_lazy_bootstraps_sending_chain():
    """OC's encrypt() does NOT raise in receiver mode; it lazy-bootstraps the sending
    chain from root_key via dhRatchetSend() (ratchet.ts:175-179 + 435-461). The
    resulting messages won't decrypt on the initiator side until DH ratchet steps
    sync — but encrypt itself succeeds.
    """
    rt = DoubleRatchet.init_receiver(
        shared_secret=os.urandom(32),
        identity_keypair=_signing_keypair(),
        peer_identity_public_key=bytes(_signing_keypair().public_key),
    )
    assert rt._state.sending_chain is None
    msg = rt.encrypt(b"hello")
    assert isinstance(msg, EncryptedMessage)
    # Sending chain is now populated (lazy bootstrap)
    assert rt._state.sending_chain is not None
    assert rt._state.sending_chain.message_number == 1  # advanced past this message


def test_encrypt_telemetry_hook_fires():
    rt = _initiator()
    captured: list[dict] = []
    rt.on_encrypt = lambda event: captured.append(event)
    rt.encrypt(b"msg-1")
    rt.encrypt(b"msg-2")
    assert len(captured) == 2
    assert captured[0]["message_number"] == 0
    assert captured[1]["message_number"] == 1


# --- DoubleRatchet.decrypt (v1) ---

def _setup_pair() -> tuple[DoubleRatchet, DoubleRatchet]:
    """Create a matched (initiator, receiver) ratchet pair sharing X3DH secret.

    Both sides use the SAME shared_secret (the X3DH-derived secret). Each side
    has its own identity keypair, and each knows the other's identity public key.
    """
    shared = os.urandom(32)
    init_signing = _signing_keypair()
    recv_signing = _signing_keypair()

    rt_init = DoubleRatchet.init_initiator(
        shared_secret=shared,
        identity_keypair=init_signing,
        peer_identity_public_key=recv_signing.public_key,
    )
    rt_recv = DoubleRatchet.init_receiver(
        shared_secret=shared,
        identity_keypair=recv_signing,
        peer_identity_public_key=init_signing.public_key,
    )
    return rt_init, rt_recv


def test_decrypt_round_trip_single_message():
    rt_a, rt_b = _setup_pair()
    msg = rt_a.encrypt(b"hello")
    pt = rt_b.decrypt(msg)
    assert pt == b"hello"


def test_decrypt_5_messages_in_order():
    rt_a, rt_b = _setup_pair()
    for i in range(5):
        msg = rt_a.encrypt(f"msg-{i}".encode())
        assert rt_b.decrypt(msg) == f"msg-{i}".encode()


def test_decrypt_out_of_order_skipped_messages():
    """A → B sends 5 messages; B receives 4, 0, 2, 1, 3 (delivery scrambled)."""
    rt_a, rt_b = _setup_pair()
    msgs = [rt_a.encrypt(f"msg-{i}".encode()) for i in range(5)]
    out_of_order = [4, 0, 2, 1, 3]
    for idx in out_of_order:
        assert rt_b.decrypt(msgs[idx]) == f"msg-{idx}".encode()


def test_decrypt_dh_ratchet_step_when_peer_replies():
    """A→B, B→A, A→B verifies the bidirectional DH ratchet."""
    rt_a, rt_b = _setup_pair()
    m1 = rt_a.encrypt(b"hi")
    assert rt_b.decrypt(m1) == b"hi"

    m2 = rt_b.encrypt(b"hi back")
    assert rt_a.decrypt(m2) == b"hi back"

    m3 = rt_a.encrypt(b"how are you")
    assert rt_b.decrypt(m3) == b"how are you"


def test_decrypt_rejects_invalid_signature():
    rt_a, rt_b = _setup_pair()
    msg = rt_a.encrypt(b"hello")
    # Tamper the signature
    msg.header_signature = b"\x00" * 64
    with pytest.raises(ValueError, match="signature"):
        rt_b.decrypt(msg)


def test_decrypt_rejects_skip_above_max():
    """Sending more than MAX_SKIP messages without a delivery should refuse."""
    rt_a, rt_b = _setup_pair()
    # Encrypt MAX_SKIP + 5 messages on A's side; B has seen none
    msgs = [rt_a.encrypt(f"m{i}".encode()) for i in range(MAX_SKIP + 5)]
    # Try to decrypt the very last (would require skipping > MAX_SKIP keys)
    with pytest.raises(ValueError, match="skip"):
        rt_b.decrypt(msgs[MAX_SKIP + 4])


def test_decrypt_telemetry_hook_fires():
    rt_a, rt_b = _setup_pair()
    captured: list[dict] = []
    rt_b.on_decrypt = lambda event: captured.append(event)
    rt_b.decrypt(rt_a.encrypt(b"hello"))
    assert len(captured) == 1
    assert "ciphertext_size" in captured[0]


# --- DoubleRatchet — v2 (header encryption) envelope ---

def test_v2_encrypt_sets_envelope_version_and_encrypted_header():
    rt = DoubleRatchet.init_initiator(
        shared_secret=os.urandom(32),
        identity_keypair=_signing_keypair(),
        peer_identity_public_key=bytes(_signing_keypair().public_key),
    )
    msg = rt.encrypt(b"hello", header_encryption=True)
    assert msg.envelope_version == "2.0.0"
    assert msg.encrypted_header is not None
    assert msg.header_nonce is not None
    assert len(msg.header_nonce) == 24


def test_v2_round_trip_single_message():
    rt_a, rt_b = _setup_pair()
    msg = rt_a.encrypt(b"hello v2", header_encryption=True)
    pt = rt_b.decrypt(msg)
    assert pt == b"hello v2"


def test_v2_5_messages_in_order():
    rt_a, rt_b = _setup_pair()
    for i in range(5):
        msg = rt_a.encrypt(f"v2-{i}".encode(), header_encryption=True)
        assert rt_b.decrypt(msg) == f"v2-{i}".encode()


def test_v2_out_of_order_with_skipped_header_keys():
    rt_a, rt_b = _setup_pair()
    msgs = [rt_a.encrypt(f"v2-{i}".encode(), header_encryption=True) for i in range(5)]
    for idx in [4, 0, 2, 1, 3]:
        assert rt_b.decrypt(msgs[idx]) == f"v2-{idx}".encode()


def test_v2_bidirectional_with_dh_ratchet():
    rt_a, rt_b = _setup_pair()
    m1 = rt_a.encrypt(b"a1", header_encryption=True)
    assert rt_b.decrypt(m1) == b"a1"
    m2 = rt_b.encrypt(b"b1", header_encryption=True)
    assert rt_a.decrypt(m2) == b"b1"
    m3 = rt_a.encrypt(b"a2", header_encryption=True)
    assert rt_b.decrypt(m3) == b"a2"


def test_v2_serialize_round_trip_preserves_envelope_version():
    rt = DoubleRatchet.init_initiator(
        shared_secret=os.urandom(32),
        identity_keypair=_signing_keypair(),
        peer_identity_public_key=bytes(_signing_keypair().public_key),
    )
    rt.encrypt(b"warmup", header_encryption=True)
    serialized = rt.serialize()
    rt2 = DoubleRatchet.deserialize(serialized)
    msg = rt2.encrypt(b"after restore", header_encryption=True)
    assert msg.envelope_version == "2.0.0"


# --- V1 sanity tests (Item 2) ---

def test_v1_ciphertext_differs_from_plaintext():
    rt = _initiator()
    plaintext = b"hello world"
    msg = rt.encrypt(plaintext)
    assert msg.ciphertext != plaintext


def test_v1_ciphertext_includes_mac_overhead():
    """XChaCha20-Poly1305 adds a 16-byte MAC tag."""
    rt = _initiator()
    plaintext = b"hello"
    msg = rt.encrypt(plaintext)
    assert len(msg.ciphertext) >= len(plaintext) + 16


def test_v1_two_ratchets_same_secret_produce_distinct_ciphertexts():
    """Independent DH keypairs + random nonces guarantee distinct ciphertexts even
    when both sides use the same shared_secret."""
    shared = os.urandom(32)
    rt_a = DoubleRatchet.init_initiator(
        shared_secret=shared,
        identity_keypair=_signing_keypair(),
        peer_identity_public_key=bytes(_signing_keypair().public_key),
    )
    rt_b = DoubleRatchet.init_initiator(
        shared_secret=shared,
        identity_keypair=_signing_keypair(),
        peer_identity_public_key=bytes(_signing_keypair().public_key),
    )
    msg_a = rt_a.encrypt(b"same plaintext")
    msg_b = rt_b.encrypt(b"same plaintext")
    assert msg_a.ciphertext != msg_b.ciphertext


# --- V1 telemetry hook coverage (Item 3) ---

def test_v1_decrypt_telemetry_hook_fires_via_skipped_keys_path():
    rt_a, rt_b = _setup_pair()
    # First, send 3 messages from a, but only deliver msg[2] to b first to force the skipped path
    msgs = [rt_a.encrypt(f"m{i}".encode()) for i in range(3)]
    captured: list[RatchetTelemetryEvent] = []
    rt_b.on_decrypt = lambda event: captured.append(event)
    rt_b.decrypt(msgs[2])  # late path, fires hook (case A → skip 0..1 → advance to 2)
    rt_b.decrypt(msgs[0])  # skipped-keys path
    rt_b.decrypt(msgs[1])  # skipped-keys path
    assert len(captured) == 3
    assert {e["message_number"] for e in captured} == {0, 1, 2}


def test_v1_decrypt_telemetry_hook_fires_via_branch_b_shortcut():
    """Initiator decrypts the very first reply message from a fresh receiver
    via the case-B root_key-derived shortcut. Hook must fire."""
    rt_a, rt_b = _setup_pair()
    rt_b.decrypt(rt_a.encrypt(b"hello"))   # advance b past case A
    m_reply = rt_b.encrypt(b"hi back")     # b's first reply triggers DH ratchet
    captured: list[RatchetTelemetryEvent] = []
    rt_a.on_decrypt = lambda event: captured.append(event)
    rt_a.decrypt(m_reply)                   # initiator-side; case B branch
    assert len(captured) == 1
    assert captured[0]["envelope_version"] is None


# --- V2 case-B fall-through (Item 4) ---

def test_v2_case_b_header_decrypt_failure_falls_through_to_dh_ratchet():
    """If V2 header decrypt with test_header_key fails, decrypt() must fall
    through to _dh_ratchet_receive (matching V1 fall-through behavior)."""
    rt_a, rt_b = _setup_pair()
    # rt_a sends message 0 to rt_b → branch A populates rt_b's dh_receiving_public_key
    rt_b.decrypt(rt_a.encrypt(b"setup"))
    # rt_b sends a V2 reply → triggers DH ratchet on rt_a's side via case B
    reply = rt_b.encrypt(b"reply v2", header_encryption=True)
    pt = rt_a.decrypt(reply)
    assert pt == b"reply v2"
    # Confirm rt_a actually advanced its receiving chain via _dh_ratchet_receive
    # (vs case-B shortcut commit) — receiving_chain must now be set
    assert rt_a._state.receiving_chain is not None


# --- V2 negative tests (Item 5) ---

def test_v2_decrypt_rejects_tampered_encrypted_header():
    rt_a, rt_b = _setup_pair()
    msg = rt_a.encrypt(b"hello v2", header_encryption=True)
    assert msg.encrypted_header is not None
    msg.encrypted_header = b"\x00" * len(msg.encrypted_header)
    with pytest.raises(ValueError, match="V2 header decryption failed"):
        rt_b.decrypt(msg)


def test_v2_decrypt_rejects_tampered_ciphertext():
    rt_a, rt_b = _setup_pair()
    msg = rt_a.encrypt(b"hello v2", header_encryption=True)
    msg.ciphertext = b"\x00" * len(msg.ciphertext)
    with pytest.raises(ValueError, match="V2 decryption failed"):
        rt_b.decrypt(msg)


def test_v2_decrypt_rejects_tampered_header_nonce():
    rt_a, rt_b = _setup_pair()
    msg = rt_a.encrypt(b"hello v2", header_encryption=True)
    assert msg.header_nonce is not None
    msg.header_nonce = b"\x00" * 24
    with pytest.raises(ValueError, match="V2 header decryption failed"):
        rt_b.decrypt(msg)


# --- V2 case-(c) DH ratchet receive (Item 6) ---

def test_v2_case_c_dh_ratchet_receive_with_v2_envelope():
    """A→B, B→A, A→B' (new DH key) — final A→B' on rt_b exercises case (c)
    DH-key-changed branch in V2 mode."""
    rt_a, rt_b = _setup_pair()
    rt_b.decrypt(rt_a.encrypt(b"hi", header_encryption=True))
    rt_a.decrypt(rt_b.encrypt(b"hi back", header_encryption=True))
    # Now rt_a does another DH ratchet send (its receiving chain was advanced in last step)
    m3 = rt_a.encrypt(b"after ratchet", header_encryption=True)
    # rt_b sees a NEW dh_public_key on m3 (rt_a generated fresh DH in _dh_ratchet_receive)
    assert m3.header.dh_public_key != rt_b._state.dh_receiving_public_key
    pt = rt_b.decrypt(m3)
    assert pt == b"after ratchet"


# --- WS-20.2 carryovers (Item 7) ---

def test_serialize_deserialize_round_trip_receiver_mode():
    rt = DoubleRatchet.init_receiver(
        shared_secret=os.urandom(32),
        identity_keypair=_signing_keypair(),
        peer_identity_public_key=bytes(_signing_keypair().public_key),
    )
    serialized = rt.serialize()
    rt2 = DoubleRatchet.deserialize(serialized)
    assert rt2._state.receiving_chain is not None
    assert rt._state.receiving_chain is not None
    assert rt._state.receiving_chain.chain_key == rt2._state.receiving_chain.chain_key
    assert rt._state.sending_chain is None
    assert rt2._state.sending_chain is None


def test_serialize_round_trip_of_round_trip_byte_equality():
    """rt → serialize → deserialize → serialize must produce byte-identical JSON."""
    rt1 = DoubleRatchet.init_initiator(
        shared_secret=os.urandom(32),
        identity_keypair=_signing_keypair(),
        peer_identity_public_key=bytes(_signing_keypair().public_key),
    )
    s1 = rt1.serialize()
    rt2 = DoubleRatchet.deserialize(s1)
    s2 = rt2.serialize()
    assert s1 == s2


@pytest.mark.parametrize("corrupt_payload,error_match", [
    ('{"version": 2, "rootKey": "00", "sendingChain": null, "receivingChain": null, "dhSendingKeypair": {"publicKey": "00", "privateKey": "00"}, "dhReceivingPublicKey": null, "identityKeypair": {"publicKey": "00", "privateKey": "00"}, "peerIdentityPublicKey": null, "previousSendingChainLength": 0, "skippedKeys": []}', "version"),
    ('{"version": 1, "sendingChain": null, "receivingChain": null, "dhSendingKeypair": {"publicKey": "00", "privateKey": "00"}, "dhReceivingPublicKey": null, "identityKeypair": {"publicKey": "00", "privateKey": "00"}, "peerIdentityPublicKey": null, "previousSendingChainLength": 0, "skippedKeys": []}', "rootKey"),
    ('{"version": 1, "rootKey": "00", "sendingChain": null, "receivingChain": null, "dhReceivingPublicKey": null, "identityKeypair": {"publicKey": "00", "privateKey": "00"}, "peerIdentityPublicKey": null, "previousSendingChainLength": 0, "skippedKeys": []}', "dhSendingKeypair"),
    ('{"version": 1, "rootKey": "not-hex!", "sendingChain": null, "receivingChain": null, "dhSendingKeypair": {"publicKey": "00", "privateKey": "00"}, "dhReceivingPublicKey": null, "identityKeypair": {"publicKey": "00", "privateKey": "00"}, "peerIdentityPublicKey": null, "previousSendingChainLength": 0, "skippedKeys": []}', ".*"),  # any error OK; wrong hex
    ('[]', ".*"),  # top-level array — any error OK
])
def test_deserialize_rejects_corrupt_input_matrix(corrupt_payload, error_match):
    with pytest.raises((ValueError, KeyError, TypeError), match=error_match):
        DoubleRatchet.deserialize(corrupt_payload)
