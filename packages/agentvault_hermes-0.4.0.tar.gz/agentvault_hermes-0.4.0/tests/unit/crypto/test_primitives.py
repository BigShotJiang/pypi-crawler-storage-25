"""Tests for crypto.primitives shared utilities."""
from __future__ import annotations

import os

import pytest
from nacl import bindings as nacl_bindings
from nacl import signing as nacl_signing

from agentvault_hermes.crypto.primitives import (
    blake2b_256,
    ed25519_to_x25519_public,
    ed25519_to_x25519_secret,
    hkdf,
    xchacha20_decrypt,
    xchacha20_encrypt,
)


# --- XChaCha20-Poly1305 ---

def test_xchacha20_round_trip():
    key = os.urandom(32)
    nonce = os.urandom(24)
    plaintext = b"hello world"
    ct = xchacha20_encrypt(plaintext, key, nonce)
    pt = xchacha20_decrypt(ct, key, nonce)
    assert pt == plaintext


def test_xchacha20_with_associated_data():
    key = os.urandom(32)
    nonce = os.urandom(24)
    plaintext = b"hello"
    ad = b"context"
    ct = xchacha20_encrypt(plaintext, key, nonce, ad)
    pt = xchacha20_decrypt(ct, key, nonce, ad)
    assert pt == plaintext


def test_xchacha20_wrong_ad_fails():
    key = os.urandom(32)
    nonce = os.urandom(24)
    ct = xchacha20_encrypt(b"hello", key, nonce, b"context-A")
    with pytest.raises(Exception):
        xchacha20_decrypt(ct, key, nonce, b"context-B")


def test_xchacha20_wrong_key_fails():
    key1 = os.urandom(32)
    key2 = os.urandom(32)
    nonce = os.urandom(24)
    ct = xchacha20_encrypt(b"hello", key1, nonce)
    with pytest.raises(Exception):
        xchacha20_decrypt(ct, key2, nonce)


def test_xchacha20_validates_key_length():
    with pytest.raises(ValueError, match="32 bytes"):
        xchacha20_encrypt(b"x", b"too short", os.urandom(24))


def test_xchacha20_validates_nonce_length():
    with pytest.raises(ValueError, match="24 bytes"):
        xchacha20_encrypt(b"x", os.urandom(32), b"too short")


# --- BLAKE2b-256 ---

def test_blake2b_256_returns_32_bytes():
    assert len(blake2b_256(b"hello")) == 32


def test_blake2b_256_deterministic():
    assert blake2b_256(b"hello") == blake2b_256(b"hello")


def test_blake2b_256_different_inputs_different_outputs():
    assert blake2b_256(b"hello") != blake2b_256(b"world")


# --- Ed25519 ↔ X25519 conversion ---

def test_ed25519_to_x25519_public_returns_32_bytes():
    sk = nacl_signing.SigningKey.generate()
    pk = bytes(sk.verify_key)
    x_pk = ed25519_to_x25519_public(pk)
    assert len(x_pk) == 32


def test_ed25519_to_x25519_secret_returns_32_bytes():
    sk = nacl_signing.SigningKey.generate()
    seed = bytes(sk)
    x_sk = ed25519_to_x25519_secret(seed)
    assert len(x_sk) == 32


def test_ed25519_x25519_pair_does_dh_correctly():
    """Convert two Ed25519 keys to X25519, do DH, verify both sides agree."""
    sk1_seed = bytes(nacl_signing.SigningKey.generate())
    pk1 = bytes(nacl_signing.SigningKey(sk1_seed).verify_key)
    sk2_seed = bytes(nacl_signing.SigningKey.generate())
    pk2 = bytes(nacl_signing.SigningKey(sk2_seed).verify_key)

    x_sk1 = ed25519_to_x25519_secret(sk1_seed)
    x_pk1 = ed25519_to_x25519_public(pk1)
    x_sk2 = ed25519_to_x25519_secret(sk2_seed)
    x_pk2 = ed25519_to_x25519_public(pk2)

    shared1 = nacl_bindings.crypto_scalarmult(x_sk1, x_pk2)
    shared2 = nacl_bindings.crypto_scalarmult(x_sk2, x_pk1)
    assert shared1 == shared2


# --- HKDF-SHA256 ---

def test_hkdf_returns_requested_length():
    out = hkdf(b"input", b"info", 64)
    assert len(out) == 64


def test_hkdf_deterministic():
    a = hkdf(b"input", b"info", 32, salt=b"salt")
    b = hkdf(b"input", b"info", 32, salt=b"salt")
    assert a == b


def test_hkdf_different_info_different_output():
    a = hkdf(b"input", b"info-A", 32)
    b = hkdf(b"input", b"info-B", 32)
    assert a != b


def test_hkdf_known_vector_rfc5869_test_case_1():
    """RFC 5869 Test Case 1 — basic test case with SHA-256."""
    ikm = bytes.fromhex("0b" * 22)
    salt = bytes.fromhex("000102030405060708090a0b0c")
    info = bytes.fromhex("f0f1f2f3f4f5f6f7f8f9")
    expected = bytes.fromhex(
        "3cb25f25faacd57a90434f64d0362f2a"
        "2d2d0a90cf1a5a4c5db02d56ecc4c5bf"
        "34007208d5b887185865"
    )
    assert hkdf(ikm, info, 42, salt=salt) == expected


def test_hkdf_rejects_length_zero():
    with pytest.raises(ValueError, match="HKDF length"):
        hkdf(b"input", b"info", 0)


def test_hkdf_rejects_length_above_max():
    """RFC 5869 §2.3: max output is 255 * HashLen = 8160 bytes for SHA-256."""
    with pytest.raises(ValueError, match="HKDF length"):
        hkdf(b"input", b"info", 8161)
