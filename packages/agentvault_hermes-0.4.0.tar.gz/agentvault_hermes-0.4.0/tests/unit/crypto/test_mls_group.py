"""Tests for crypto.mls_group — MlsGroupState wrapper.

Mirrors OC's packages/crypto/src/mls-group.test.ts patterns.
"""
from __future__ import annotations

import uuid

import pytest

from agentvault_hermes.crypto import (
    AddMembersResult,
    MlsGroupNotInitializedError,
    MlsGroupState,
    RemoveMemberResult,
    SigningKeypair,
)


def _make_device_keys() -> SigningKeypair:
    """Generate a fresh Ed25519 keypair in Hermes' SigningKeypair format."""
    import nacl.signing
    sk = nacl.signing.SigningKey.generate()
    return SigningKeypair(
        public_key=bytes(sk.verify_key),
        private_key=bytes(sk),
    )


def _make_state(device_id: uuid.UUID | None = None) -> MlsGroupState:
    keys = _make_device_keys()
    device_id = device_id or uuid.uuid4()
    return MlsGroupState(device_keys=keys, device_id=device_id)


def test_uninitialized_state_invariants() -> None:
    """Test #1: Fresh wrapper has is_initialized=False; epoch and group_id raise."""
    mgr = _make_state()
    assert mgr.is_initialized is False
    assert mgr.ciphersuite_name  # str, non-empty
    with pytest.raises(MlsGroupNotInitializedError):
        _ = mgr.epoch
    with pytest.raises(MlsGroupNotInitializedError):
        _ = mgr.group_id


def test_generate_key_package_produces_valid_message() -> None:
    """Test #2: generate_key_package returns bytes that round-trip through deserialize."""
    mgr = _make_state()
    kp_bytes = mgr.generate_key_package()
    assert isinstance(kp_bytes, bytes)
    assert len(kp_bytes) > 0
    # Round-trip through the static helpers
    serialized = MlsGroupState.serialize_key_package(kp_bytes)
    deserialized = MlsGroupState.deserialize_key_package(serialized)
    assert deserialized == kp_bytes


def test_serialize_deserialize_key_package_static() -> None:
    """Test #3: Static helpers are inverses."""
    mgr = _make_state()
    kp_bytes = mgr.generate_key_package()
    assert MlsGroupState.deserialize_key_package(
        MlsGroupState.serialize_key_package(kp_bytes)
    ) == kp_bytes


def test_uninitialized_methods_raise_partial() -> None:
    """Test #16 (partial — only the methods we have so far): operations before init raise."""
    mgr = _make_state()
    # encrypt/decrypt/etc. don't exist yet (Task 2+); only export_state is testable
    # here, and it raises because there's no group to export
    with pytest.raises(MlsGroupNotInitializedError):
        mgr.export_state()


def test_create_group_initializes() -> None:
    """Test #4: post-create, is_initialized=True, epoch=0, group_id matches."""
    mgr = _make_state()
    group_id = b"\x42" * 16
    mgr.create_group(group_id)
    assert mgr.is_initialized is True
    assert mgr.epoch == 0
    assert mgr.group_id == group_id


def test_create_group_then_self_only() -> None:
    """Test #5: creator-of-1 group state is consistent (no encryption yet — that's WS-22.3)."""
    mgr = _make_state()
    mgr.create_group(group_id=b"\x01" * 16)
    assert mgr.is_initialized is True
    # No member-list query (we don't expose it per OC parity); just check group is operational
    assert mgr.group_id == b"\x01" * 16


def test_join_from_welcome() -> None:
    """Test #6: Alice creates, adds Bob's KP, Bob's MlsGroupState.join_from_welcome
    initializes correctly."""
    alice = _make_state()
    bob = _make_state()
    alice.create_group(b"\x42" * 16)

    result = alice.add_members([bob.generate_key_package()])
    assert result.welcome is not None
    bob.join_from_welcome(result.welcome)
    assert bob.is_initialized is True
    assert bob.epoch == alice.epoch
    assert bob.group_id == alice.group_id


def test_encrypt_decrypt_roundtrip_two_members() -> None:
    """Test #7: Alice encrypts, Bob decrypts; plaintext matches; is_handshake=False."""
    alice = _make_state()
    bob = _make_state()
    alice.create_group(b"\x42" * 16)

    result = alice.add_members([bob.generate_key_package()])
    bob.join_from_welcome(result.welcome)

    # Now Alice can encrypt and Bob can decrypt
    plaintext = b"hello bob"
    ciphertext = alice.encrypt(plaintext)
    decrypt_result = bob.decrypt(ciphertext)
    assert decrypt_result.is_handshake is False
    assert decrypt_result.plaintext == plaintext


def test_decrypt_handshake_returns_handshake_flag() -> None:
    """Test #8: A handshake (commit) message decrypts with is_handshake=True, plaintext=None."""
    alice = _make_state()
    bob = _make_state()
    charlie = _make_state()
    alice.create_group(b"\x42" * 16)

    # Add Bob first
    add_b = alice.add_members([bob.generate_key_package()])
    bob.join_from_welcome(add_b.welcome)

    # Now Alice adds Charlie — Bob receives the commit (a handshake message)
    add_c = alice.add_members([charlie.generate_key_package()])

    result = bob.decrypt(add_c.commit)
    assert result.is_handshake is True
    assert result.plaintext is None


def test_process_commit_asserts_handshake() -> None:
    """Test #9: process_commit raises if given application data."""
    alice = _make_state()
    bob = _make_state()
    alice.create_group(b"\x42" * 16)
    bob.join_from_welcome(alice.add_members([bob.generate_key_package()]).welcome)

    # Application message — process_commit should reject
    app_msg = alice.encrypt(b"not a commit")
    with pytest.raises(RuntimeError, match="handshake"):
        bob.process_commit(app_msg)


def test_invalid_wire_bytes_raise() -> None:
    """Test #17: garbage bytes to decrypt raise mls_rs_uniffi's protocol error."""
    import mls_rs_uniffi as _mls
    alice = _make_state()
    alice.create_group(b"\x42" * 16)
    with pytest.raises(_mls.Error):
        alice.decrypt(b"\xff" * 100)


def test_three_member_application_message_roundtrip() -> None:
    """Test #20: 3-way create→join→join→encrypt by member 1, decrypt by 2 and 3."""
    alice = _make_state()
    bob = _make_state()
    charlie = _make_state()

    alice.create_group(b"\x42" * 16)
    bob.join_from_welcome(alice.add_members([bob.generate_key_package()]).welcome)

    add_c = alice.add_members([charlie.generate_key_package()])
    # Bob processes the commit so his group state advances
    bob.process_commit(add_c.commit)
    charlie.join_from_welcome(add_c.welcome)

    msg = alice.encrypt(b"hello everyone")
    assert bob.decrypt(msg).plaintext == b"hello everyone"
    assert charlie.decrypt(msg).plaintext == b"hello everyone"


def test_add_members_singular_returns_commit_and_welcome() -> None:
    """Test #10: add one new member; both commit and welcome populated."""
    alice = _make_state()
    bob = _make_state()
    alice.create_group(b"\x42" * 16)

    bob_kp = bob.generate_key_package()
    result = alice.add_members([bob_kp])
    assert isinstance(result, AddMembersResult)
    assert isinstance(result.commit, bytes) and len(result.commit) > 0
    assert result.welcome is not None and len(result.welcome) > 0


def test_add_members_plural_in_one_commit() -> None:
    """Test #11: add two new members in one call; one commit, one welcome
    (multi-recipient — mls_rs bundles all welcomes into a single message)."""
    alice = _make_state()
    bob = _make_state()
    charlie = _make_state()
    alice.create_group(b"\x42" * 16)

    bob_kp = bob.generate_key_package()
    charlie_kp = charlie.generate_key_package()
    result = alice.add_members([bob_kp, charlie_kp])
    assert isinstance(result, AddMembersResult)
    assert result.welcome is not None
    # Both Bob and Charlie should be able to join from the same Welcome
    bob.join_from_welcome(result.welcome)
    charlie.join_from_welcome(result.welcome)
    assert bob.epoch == alice.epoch
    assert charlie.epoch == alice.epoch


def test_remove_member_advances_epoch() -> None:
    """Test #12: remove by leaf_index; observers see epoch advance after the commit."""
    alice = _make_state()
    bob = _make_state()
    alice.create_group(b"\x42" * 16)

    bob_kp = bob.generate_key_package()
    add_result = alice.add_members([bob_kp])
    bob.join_from_welcome(add_result.welcome)
    epoch_before = alice.epoch

    # Bob is at leaf_index 1 (alice is leaf 0); remove him
    remove_result = alice.remove_member(leaf_index=1)
    assert isinstance(remove_result, RemoveMemberResult)
    assert isinstance(remove_result.commit, bytes) and len(remove_result.commit) > 0
    assert alice.epoch > epoch_before


def test_kicked_member_cannot_decrypt_new_messages() -> None:
    """Test #21: forward-secrecy — after a removal commit, kicked Bob cannot
    decrypt new application messages from Alice."""
    alice = _make_state()
    bob = _make_state()
    alice.create_group(b"\x42" * 16)
    bob.join_from_welcome(alice.add_members([bob.generate_key_package()]).welcome)

    # Bob can decrypt now
    msg_before = alice.encrypt(b"before kick")
    assert bob.decrypt(bytes(msg_before)).plaintext == b"before kick"

    # Alice removes Bob
    remove_result = alice.remove_member(leaf_index=1)
    # Bob processes the remove commit — his state effectively dies (he's no
    # longer in the group, but the wrapper doesn't surface this — see
    # future joint upgrade #4)
    bob.process_commit(remove_result.commit)

    # Alice encrypts a new message; Bob cannot decrypt
    msg_after = alice.encrypt(b"after kick")
    with pytest.raises(Exception):  # mls_rs_uniffi raises on decrypt failure
        bob.decrypt(msg_after)


def test_remove_member_at_higher_leaf_index() -> None:
    """Test #22: removing a non-zero leaf works (sanity check that leaf_index
    arithmetic doesn't have an off-by-one)."""
    alice = _make_state()
    bob = _make_state()
    charlie = _make_state()
    alice.create_group(b"\x42" * 16)

    bob_kp = bob.generate_key_package()
    charlie_kp = charlie.generate_key_package()
    result = alice.add_members([bob_kp, charlie_kp])
    bob.join_from_welcome(result.welcome)
    charlie.join_from_welcome(result.welcome)

    # Remove Charlie (leaf_index 2 — alice 0, bob 1, charlie 2)
    epoch_before = alice.epoch
    remove_result = alice.remove_member(leaf_index=2)
    assert isinstance(remove_result, RemoveMemberResult)
    assert alice.epoch > epoch_before


def test_remove_then_add_misaligns_leaf_cache_known_limitation() -> None:
    """Documents the leaf-cache misalignment limitation called out in the
    MlsGroupState class docstring's "Known limitations" section.

    Sequence: alice + bob + charlie -> remove(bob) -> add(dave). RFC 9420 §7.6
    says mls_rs may reuse bob's blank leaf slot for dave, but our cache
    appends dave at ``max(keys)+1``. After this sequence, calling
    ``remove_member(k)`` against the dave-cached leaf MAY raise
    ``_mls.Error`` or remove the wrong identity — this test does NOT
    assert what happens at that point; it just locks in that the
    remove-then-add sequence itself completes (so we don't regress
    add-after-remove on the happy path) and serves as a regression sentinel
    for the future joint upgrade WS118 (which will obsolete the cache by
    resolving SigningIdentity from leaf_index via mls_rs's API directly).
    """
    alice = _make_state()
    bob = _make_state()
    charlie = _make_state()
    dave = _make_state()
    alice.create_group(b"\x42" * 16)

    # 3-member group: alice (leaf 0), bob (leaf 1), charlie (leaf 2)
    alice.add_members([bob.generate_key_package(), charlie.generate_key_package()])

    # Remove bob — his leaf becomes blank
    alice.remove_member(leaf_index=1)

    # Add dave — mls_rs may reuse bob's blank leaf (1), but our cache will
    # record dave at max(keys)+1. Cache is now potentially misaligned.
    add_result = alice.add_members([dave.generate_key_package()])
    assert isinstance(add_result, AddMembersResult)
    assert add_result.welcome is not None

    # NOTE: deliberately not asserting on alice.remove_member(k) for any k>0
    # here — that is the documented gray zone. The point of this test is to
    # exercise the dave-add path itself, which must keep working.


def test_uninitialized_methods_raise_full() -> None:
    """Test #16 (full): all init-required operations raise on uninitialized state."""
    mgr = _make_state()
    with pytest.raises(MlsGroupNotInitializedError):
        mgr.encrypt(b"x")
    with pytest.raises(MlsGroupNotInitializedError):
        mgr.decrypt(b"x")
    with pytest.raises(MlsGroupNotInitializedError):
        mgr.add_members([b"x"])
    with pytest.raises(MlsGroupNotInitializedError):
        mgr.remove_member(leaf_index=0)
    with pytest.raises(MlsGroupNotInitializedError):
        mgr.export_state()


def test_export_import_roundtrip_same_instance() -> None:
    """Test #13: export bytes, import into fresh wrapper, encrypt/decrypt still works."""
    alice = _make_state()
    bob = _make_state()
    alice.create_group(b"\x42" * 16)
    bob.join_from_welcome(
        alice.add_members([bob.generate_key_package()]).welcome
    )

    state_blob = alice.export_state()
    assert isinstance(state_blob, bytes)
    assert len(state_blob) > 0

    # Build a fresh wrapper using the SAME device_keys (same identity)
    # and import the state
    alice_keys = SigningKeypair(
        public_key=alice._keypair.public_key.bytes,
        private_key=alice._keypair.secret_key.bytes[:32],  # extract seed
    )
    alice_reload = MlsGroupState(device_keys=alice_keys, device_id=alice._device_id)
    alice_reload.import_state(state_blob)
    assert alice_reload.is_initialized is True

    # Reload can encrypt; bob can decrypt
    msg = alice_reload.encrypt(b"after reload")
    assert bob.decrypt(msg).plaintext == b"after reload"


def test_bug_a_creator_and_joiner_epoch_match_actual_post_join() -> None:
    """Bug A regression (action_item #164).

    Pre-fix, both ``alice.epoch`` (creator) and ``bob.epoch`` (joiner) returned
    0 after the add+join sequence, because:

    - Creator's ``_storage.max_epoch_id`` lagged: ``write_to_storage()`` ran
      BEFORE the self-applied commit advanced the internal epoch counter.
    - Joiner's ``_storage.max_epoch_id`` was ``None``: no epoch state record
      is persisted by ``join_from_welcome``.

    The existing ``test_add_members_plural_in_one_commit`` only asserted
    equality (0 == 0 passed), masking the bug. This test asserts the SPECIFIC
    correct values (1 == 1) so a regression would surface as a clear failure.

    Wire-format ciphertext is the empirical source of truth: encrypting
    after add_members + join_from_welcome produces a PrivateMessage with
    epoch=1 in the framing header (verified by ``_parse_epoch_from_mls_wire``).
    """
    alice = _make_state()
    bob = _make_state()
    alice.create_group(b"\x42" * 16)
    assert alice.epoch == 0  # initial epoch per RFC 9420 §8.1

    bob_kp = bob.generate_key_package()
    res = alice.add_members([bob_kp])
    # Creator's epoch advances by 1 on self-applied commit (Bug A: was 0).
    assert alice.epoch == 1

    bob.join_from_welcome(res.welcome)
    # Joiner picks up the same epoch (Bug A: was 0).
    assert bob.epoch == 1

    # Joiner's epoch self-heals from the wire header on the first encrypt
    # (no extra mls-rs round-trip needed).
    bob.encrypt(b"first reply")
    assert bob.epoch == 1


def test_bug_a_epoch_survives_export_import_for_joiner() -> None:
    """Bug A regression — TLV v2 footer carries the explicit epoch counter
    across export/import for joiners (action_item #164).

    Pre-fix, a joiner's exported state had no epoch records (storage was
    empty), so re-importing yielded ``epoch=0``. v2 TLV adds an explicit
    u64 LE footer carrying the tracked epoch; v1 imports still work and
    schedule a wire-refresh on next encrypt for self-healing.
    """
    alice = _make_state()
    bob = _make_state()
    alice.create_group(b"\x42" * 16)
    res = alice.add_members([bob.generate_key_package()])
    bob.join_from_welcome(res.welcome)
    assert bob.epoch == 1  # placeholder before wire refresh

    blob = bob.export_state()
    bob_keys = SigningKeypair(
        public_key=bob._keypair.public_key.bytes,
        private_key=bob._keypair.secret_key.bytes[:32],
    )
    bob_reload = MlsGroupState(device_keys=bob_keys, device_id=bob._device_id)
    bob_reload.import_state(blob)
    assert bob_reload.epoch == 1


def test_export_import_preserves_epoch_and_group_id() -> None:
    """Test #14: post-import, epoch and group_id match pre-export."""
    alice = _make_state()
    bob = _make_state()
    alice.create_group(b"\x42" * 16)
    alice.add_members([bob.generate_key_package()])  # advances epoch

    pre_epoch = alice.epoch
    pre_gid = alice.group_id
    state_blob = alice.export_state()

    alice_keys = SigningKeypair(
        public_key=alice._keypair.public_key.bytes,
        private_key=alice._keypair.secret_key.bytes[:32],
    )
    alice_reload = MlsGroupState(device_keys=alice_keys, device_id=alice._device_id)
    alice_reload.import_state(state_blob)
    assert alice_reload.epoch == pre_epoch
    assert alice_reload.group_id == pre_gid


def test_export_import_preserves_decryption_for_old_messages() -> None:
    """Test #15: validates the round-trip preserves decryption capability —
    alice can still decrypt a message bob queued before her reload.

    NOTE per pre-task spike: in single-client scenarios mls_rs_uniffi 0.1.0
    populates very few epoch_records; the live ratchet state in state_blobs
    carries forward decryption capability. So this test passes even when
    n_epochs in the TLV is small or 0 — that's the expected behavior.
    """
    alice = _make_state()
    bob = _make_state()
    alice.create_group(b"\x42" * 16)
    bob.join_from_welcome(
        alice.add_members([bob.generate_key_package()]).welcome
    )

    # Bob encrypts at epoch N
    msg_from_bob = bob.encrypt(b"from bob at epoch N")

    # Alice exports BEFORE seeing bob's message
    state_blob = alice.export_state()

    # Alice reloads from the exported state and then receives bob's old message
    alice_keys = SigningKeypair(
        public_key=alice._keypair.public_key.bytes,
        private_key=alice._keypair.secret_key.bytes[:32],
    )
    alice_reload = MlsGroupState(device_keys=alice_keys, device_id=alice._device_id)
    alice_reload.import_state(state_blob)
    result = alice_reload.decrypt(msg_from_bob)
    assert result.plaintext == b"from bob at epoch N"


def test_invalid_state_blob_on_import_raises() -> None:
    """Test #18: garbage TLV raises with a clear message."""
    mgr = _make_state()
    with pytest.raises(ValueError, match="invalid|corrupt|TLV|truncated|version"):
        mgr.import_state(b"\xff" * 50)


def test_tlv_version_byte_check() -> None:
    """Test #19: unknown version byte rejected."""
    mgr = _make_state()
    # Version 0xFF is not 0x01
    with pytest.raises(ValueError, match="version"):
        mgr.import_state(b"\xff" + b"\x00" * 20)
