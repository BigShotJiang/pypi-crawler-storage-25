"""WS-24.2 — Double Ratchet byte-equality tests against the OC vector fixtures.

5 scenarios:
  - ratchet_init: serialized state right after init_initiator (no encrypt).
  - ratchet_single_message: 1 V1-envelope encrypt.
  - ratchet_5_message_chain: 5 V1-envelope encrypts in a row (unidirectional).
  - ratchet_out_of_order: 5 V1 encrypts; consumer feeds the receiver in scrambled order.
  - ratchet_v2_header_encrypted: 1 V2-envelope encrypt (header_encryption=True).

Each scenario runs under ``deterministic_sodium(master_seed)`` so the PRG
counter draws produce the exact bytes recorded in the fixture.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any

from nacl import bindings

from agentvault_hermes.crypto.ratchet import (
    DoubleRatchet,
    EncryptedMessage,
    SigningKeypair,
)

from .conftest import LoadVector, deterministic_sodium

# Module-local backwards-compatible alias preserved for symmetry with the
# rest of this file's existing signatures; the canonical alias lives in
# conftest.
_LoadVector = LoadVector


def _derive_inputs(master_seed: bytes) -> dict[str, bytes]:
    """Re-derive Ratchet fixture inputs from master_seed via plain BLAKE2b.

    Mirrors ``packages/crypto/scripts/regenerate_oc_vectors/regenerate.mjs:385–399``.
    Used for sanity-checking that this Python test's input derivation matches
    the JS regenerator's. NONE of these calls consume the PRG counter — they're
    plain BLAKE2b + plain ``crypto_sign_seed_keypair``.
    """
    shared_secret = hashlib.blake2b(
        master_seed + b"shared_secret", digest_size=32
    ).digest()
    my_identity_seed = hashlib.blake2b(
        master_seed + b"my_identity", digest_size=32
    ).digest()
    peer_identity_seed = hashlib.blake2b(
        master_seed + b"peer_identity", digest_size=32
    ).digest()
    my_identity_pk, my_identity_sk_64 = bindings.crypto_sign_seed_keypair(
        my_identity_seed
    )
    peer_identity_pk, _ = bindings.crypto_sign_seed_keypair(peer_identity_seed)
    return {
        "shared_secret": shared_secret,
        "my_identity_seed": my_identity_seed,
        "my_identity_libsodium_sk": my_identity_sk_64,
        "my_identity_pk": my_identity_pk,
        "peer_identity_seed": peer_identity_seed,
        "peer_identity_pk": peer_identity_pk,
    }


def _assert_inputs_match(
    fx_inputs: dict[str, Any], derived: dict[str, bytes]
) -> None:
    assert fx_inputs["shared_secret"] == derived["shared_secret"].hex(), (
        "shared_secret mismatch — PRG seam or input derivation drifted from JS regenerator"
    )
    assert fx_inputs["my_identity_seed"] == derived["my_identity_seed"].hex(), (
        "my_identity_seed mismatch — input derivation drifted"
    )
    assert (
        fx_inputs["my_identity_libsodium_sk"]
        == derived["my_identity_libsodium_sk"].hex()
    ), "my_identity_libsodium_sk mismatch — crypto_sign_seed_keypair output drifted"
    assert fx_inputs["peer_identity_seed"] == derived["peer_identity_seed"].hex(), (
        "peer_identity_seed mismatch — input derivation drifted"
    )
    assert fx_inputs["peer_identity_public"] == derived["peer_identity_pk"].hex(), (
        "peer_identity_public mismatch — crypto_sign_seed_keypair output drifted"
    )


def _setup_initiator(
    master_seed: bytes, derived: dict[str, bytes]
) -> DoubleRatchet:
    """Build a DoubleRatchet under deterministic_sodium. Caller MUST be inside the `with` block.

    init_initiator() draws a DH keypair via patched ``crypto_box_keypair``
    (counter 0, domain ``"box"``). Identity keypair is passed in — already
    derived OUTSIDE the patched scope.
    """
    # CRITICAL — `SigningKeypair.private_key` is documented as 32-byte Ed25519
    # SEED at ratchet.py:57. `_sign_header` (ratchet.py:185) calls
    # `nacl_signing.SigningKey(keypair.private_key)`, which raises ValueError
    # for any input that is not exactly 32 bytes. The fixture's
    # `my_identity_libsodium_sk` is 64 bytes (seed||pk libsodium form) and
    # MUST NOT be passed here. Hermes' production divergence from OC on this
    # field is tracked as a follow-up action item (filed 2026-05-10).
    my_kp = SigningKeypair(
        public_key=derived["my_identity_pk"],
        private_key=derived["my_identity_seed"],
    )
    return DoubleRatchet.init_initiator(
        derived["shared_secret"],
        my_kp,
        derived["peer_identity_pk"],
    )


def _snap_message(m: EncryptedMessage) -> dict[str, Any]:
    """Snapshot an EncryptedMessage to the same shape the JS regenerator records."""
    return {
        "header_dh_public_key": m.header.dh_public_key.hex(),
        "header_previous_chain_length": m.header.previous_chain_length,
        "header_message_number": m.header.message_number,
        "header_signature": m.header_signature.hex(),
        "ciphertext": m.ciphertext.hex(),
        "nonce": m.nonce.hex(),
        "envelope_version": m.envelope_version,  # str or None
        "encrypted_header": (
            m.encrypted_header.hex() if m.encrypted_header is not None else None
        ),
        "header_nonce": (
            m.header_nonce.hex() if m.header_nonce is not None else None
        ),
    }


def _load_master_seed(fx: dict[str, Any]) -> bytes:
    return bytes.fromhex(fx["inputs"]["master_seed"])


# ---- field-shape canary ---------------------------------------------------


def test_encrypted_message_field_shape_canary() -> None:
    """Asserts EncryptedMessage still carries the field set ``_snap_message``
    snapshots. If a refactor renames or drops a field, ``_snap_message`` would
    silently AttributeError instead of producing an informative byte-mismatch.
    Update ``_snap_message`` AND this canary together."""
    from dataclasses import fields

    expected = {
        "header",
        "header_signature",
        "ciphertext",
        "nonce",
        "envelope_version",
        "encrypted_header",
        "header_nonce",
    }
    actual = {f.name for f in fields(EncryptedMessage)}
    assert expected <= actual, (
        f"EncryptedMessage missing fields: {expected - actual}. "
        f"_snap_message likely needs updating in lockstep."
    )


# ---- ratchet_init ---------------------------------------------------------


def test_ratchet_init_serialized_state_byte_equality(
    load_vector: _LoadVector,
) -> None:
    fx = load_vector("ratchet_init.json")
    master_seed = _load_master_seed(fx)
    derived = _derive_inputs(master_seed)
    _assert_inputs_match(fx["inputs"], derived)

    with deterministic_sodium(master_seed):
        rt = _setup_initiator(master_seed, derived)
        serialized = rt.serialize()

    actual = json.loads(serialized)
    # Deep-copy so the carve-out below doesn't mutate the fixture cache.
    expected = json.loads(json.dumps(fx["expected"]["serialized_state"]))

    # LOCKED-IN DECISION (2026-05-10, option 2): assert byte-equality on every
    # serialized_state field EXCEPT identityKeypair.privateKey. Hermes' Python
    # SigningKeypair.private_key holds a 32-byte Ed25519 SEED; OC's TS impl
    # records the 64-byte libsodium sk (seed||pk) in serialized state. This is
    # a real parity gap (action item filed 2026-05-10) but production refactor
    # is out of scope for WS-24.
    actual_id_priv = actual["identityKeypair"].pop("privateKey")
    expected_id_priv = expected["identityKeypair"].pop("privateKey")

    assert actual == expected, (
        f"ratchet_init: serialized state diverges from OC on a non-identity-priv field.\n"
        f"  expected: {json.dumps(expected, sort_keys=True)}\n"
        f"  actual:   {json.dumps(actual,   sort_keys=True)}"
    )
    # Verify the divergence is exactly the documented one: Hermes' 32-byte seed
    # is the prefix of OC's 64-byte libsodium sk (which is seed||pk).
    assert len(bytes.fromhex(actual_id_priv)) == 32, (
        f"Hermes identityKeypair.privateKey must be 32-byte seed; got "
        f"{len(bytes.fromhex(actual_id_priv))} bytes"
    )
    assert len(bytes.fromhex(expected_id_priv)) == 64, (
        f"OC fixture identityKeypair.privateKey must be 64-byte libsodium sk; got "
        f"{len(bytes.fromhex(expected_id_priv))} bytes — fixture may have drifted"
    )
    assert expected_id_priv.startswith(actual_id_priv), (
        f"Hermes seed must be the prefix of OC's libsodium sk (seed||pk).\n"
        f"  hermes seed: {actual_id_priv}\n"
        f"  oc sk:       {expected_id_priv}"
    )


# ---- ratchet_single_message ----------------------------------------------


def test_ratchet_single_message_byte_equality(load_vector: _LoadVector) -> None:
    fx = load_vector("ratchet_single_message.json")
    master_seed = _load_master_seed(fx)
    derived = _derive_inputs(master_seed)
    _assert_inputs_match(fx["inputs"], derived)

    plaintext = fx["inputs"]["plaintext"].encode("utf-8")

    with deterministic_sodium(master_seed):
        rt = _setup_initiator(master_seed, derived)
        msg = rt.encrypt(plaintext, header_encryption=False)

    assert _snap_message(msg) == fx["expected"]["message"]


# ---- ratchet_5_message_chain ---------------------------------------------


def test_ratchet_5_message_chain_byte_equality(load_vector: _LoadVector) -> None:
    fx = load_vector("ratchet_5_message_chain.json")
    master_seed = _load_master_seed(fx)
    derived = _derive_inputs(master_seed)
    _assert_inputs_match(fx["inputs"], derived)

    plaintexts = [p.encode("utf-8") for p in fx["inputs"]["plaintexts"]]

    with deterministic_sodium(master_seed):
        rt = _setup_initiator(master_seed, derived)
        msgs = [rt.encrypt(p, header_encryption=False) for p in plaintexts]

    snaps = [_snap_message(m) for m in msgs]
    assert snaps == fx["expected"]["messages"]
    # Sanity: per the fixture's _notes, header_dh_public_key is identical
    # across all 5 (unidirectional, DH ratchet does not advance).
    assert len({s["header_dh_public_key"] for s in snaps}) == 1
    # Off-by-one canary on the symmetric-ratchet message counter: catches a
    # message-number drift even if all other fields happen to align.
    assert [s["header_message_number"] for s in snaps] == [0, 1, 2, 3, 4]


# ---- ratchet_out_of_order -------------------------------------------------


def test_ratchet_out_of_order_byte_equality(load_vector: _LoadVector) -> None:
    """Verify the SENDER side produces the same 5 ciphertexts; receiver-side
    skipped-key decryption is exercised in WS-25 integration tests, not here.
    The fixture captures the messages in scrambled receive order; we have to
    un-scramble to compare against our in-order encrypts."""
    fx = load_vector("ratchet_out_of_order.json")
    master_seed = _load_master_seed(fx)
    derived = _derive_inputs(master_seed)
    _assert_inputs_match(fx["inputs"], derived)

    plaintexts = [p.encode("utf-8") for p in fx["inputs"]["plaintexts"]]
    scrambled_order: list[int] = fx["inputs"]["scrambled_order"]

    # Fixture-corruption guard: catches a duplicate / out-of-range / wrong-length
    # scrambled_order field before it manifests as IndexError or a confusing
    # element-equality mismatch downstream.
    assert sorted(scrambled_order) == list(range(len(plaintexts))), (
        f"Fixture corruption: scrambled_order={scrambled_order} is not a valid "
        f"permutation of [0..{len(plaintexts) - 1}]"
    )

    with deterministic_sodium(master_seed):
        rt = _setup_initiator(master_seed, derived)
        msgs = [rt.encrypt(p, header_encryption=False) for p in plaintexts]

    # Apply the same permutation OC applied to produce messages_in_scrambled_order.
    actual_scrambled = [_snap_message(msgs[i]) for i in scrambled_order]
    assert actual_scrambled == fx["expected"]["messages_in_scrambled_order"]


# ---- ratchet_v2_header_encrypted -----------------------------------------


def test_ratchet_v2_header_encrypted_byte_equality(
    load_vector: _LoadVector,
) -> None:
    fx = load_vector("ratchet_v2_header_encrypted.json")
    master_seed = _load_master_seed(fx)
    derived = _derive_inputs(master_seed)
    _assert_inputs_match(fx["inputs"], derived)

    plaintext = fx["inputs"]["plaintext"].encode("utf-8")

    # NOTE — V2 RNG draw order is load-bearing: ratchet.py:577 draws the AEAD
    # nonce, ratchet.py:586 draws the header_nonce. If a future refactor swaps
    # those lines, V2 byte-equality silently transposes nonce ↔ header_nonce
    # values and the byte-mismatch failure becomes hard to diagnose.
    with deterministic_sodium(master_seed):
        rt = _setup_initiator(master_seed, derived)
        msg = rt.encrypt(plaintext, header_encryption=True)

    snap = _snap_message(msg)
    assert snap == fx["expected"]["message"]
    # Tight checks on the V2-specific fields:
    assert snap["envelope_version"] == "2.0.0"
    assert snap["encrypted_header"] is not None
    assert snap["header_nonce"] is not None
