"""Test-scope deterministic-RNG seam for byte-equality WS-24 vector tests.

Mirrors ``packages/crypto/scripts/regenerate_oc_vectors/seeded_sodium.mjs``
verbatim. TEST SCOPE ONLY — do NOT export from ``agentvault_hermes``; do NOT
use in production code.

Reference contract: ``docs/plans/2026-05-10-ws-24-implementation.md`` §4.1
(the PRG contract).

Future-self note
----------------
The seam patches ``nacl.bindings.{randombytes,crypto_box_keypair,
crypto_sign_keypair}``. It works because Hermes' production code accesses
those endpoints via attribute lookup on the ``bindings`` module
(``bindings.randombytes(24)``, ``bindings.crypto_box_keypair()``). If a
future refactor switches to ``from nacl.bindings import randombytes`` or to
a higher-level wrapper such as ``nacl.public.PrivateKey.generate()``, this
seam will silently miss those call sites and the byte-equality tests will
report ghost mismatches. Audit before changing any libsodium import style
in ``src/agentvault_hermes/crypto/*.py``.

Known bypass paths the seam does NOT cover (as of 2026-05-10):

- ``nacl.utils.random()`` calls ``os.urandom`` directly, not
  ``bindings.randombytes``. ``nacl.signing.SigningKey.generate()`` and
  ``nacl.public.PrivateKey.generate()`` route through that path.
- ``packages/plugin-hermes/src/agentvault_hermes/core/identity/device.py``
  uses ``signing.SigningKey.generate()`` / ``public.PrivateKey.generate()``
  and is therefore NOT byte-stable under this seam. Any vector test that
  reaches device-key generation will produce non-deterministic output. WS-24
  tests deliberately avoid those code paths and re-derive identities from
  fixture seeds via ``crypto_sign_seed_keypair`` instead.

The mechanical enforcement test ``test_seam_does_not_affect_nacl_utils_random``
in ``test_seam.py`` makes the bypass auditable: if a future refactor wires
``nacl.utils.random`` through ``bindings.randombytes``, the test starts to
fail loudly.
"""
from __future__ import annotations

import hashlib
import json
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import pytest
from nacl import bindings


# Public type alias for the `load_vector` fixture's callable return shape.
# Use this in any vector test that takes `load_vector` as a parameter so the
# annotation stays in lockstep with this conftest's actual signature.
LoadVector = Callable[[str], dict[str, Any]]


_FIXTURES = Path(__file__).resolve().parents[3] / "fixtures" / "oc_vectors"
assert _FIXTURES.is_dir(), (
    f"WS-23 OC vector fixtures not found at {_FIXTURES}; the test directory "
    f"may have moved (parents[3] resolution is path-fragile)."
)


@pytest.fixture
def vectors_dir() -> Path:
    """Path to the WS-23 OC vector fixture directory."""
    return _FIXTURES


@pytest.fixture
def load_vector(vectors_dir: Path) -> Callable[[str], dict[str, Any]]:
    """Return a loader that reads + ``json.loads`` a fixture by file name."""

    def _load(name: str) -> dict[str, Any]:
        data: dict[str, Any] = json.loads((vectors_dir / name).read_text())
        return data

    return _load


class _SodiumPRG:
    """Counter-XOFed BLAKE2b stream backing the patched libsodium endpoints.

    A single u64 little-endian counter is shared across all three domains
    (``"rb"`` / ``"box"`` / ``"sig"``); domain separation lives in the
    BLAKE2b input string, NOT in per-domain counters. This matches the JS
    reference impl byte-for-byte. Reordering one domain's calls intentionally
    shifts bytes in the others; do NOT redesign with per-domain counters.
    """

    def __init__(self, master_seed: bytes) -> None:
        if len(master_seed) != 32:
            raise ValueError(
                f"master_seed must be 32 bytes, got {len(master_seed)}"
            )
        self._seed = bytes(master_seed)
        self._counter = 0  # u64 little-endian, shared across domains

    def stream_bytes(self, domain: str, n: int) -> bytes:
        """Return the next ``n`` bytes of the counter-XOFed BLAKE2b stream.

        Each iteration emits up to a 64-byte BLAKE2b block; the counter
        advances by 1 per block, regardless of how many bytes were taken
        from that block.
        """
        out = bytearray(n)
        off = 0
        domain_bytes = domain.encode("utf-8")
        while off < n:
            ctr_le = self._counter.to_bytes(8, "little", signed=False)
            block = hashlib.blake2b(
                self._seed + domain_bytes + ctr_le,
                digest_size=64,
            ).digest()
            take = min(64, n - off)
            out[off : off + take] = block[:take]
            off += take
            self._counter += 1
        return bytes(out)


@contextmanager
def deterministic_sodium(master_seed: bytes) -> Iterator[_SodiumPRG]:
    """Patch three libsodium endpoints with deterministic shims for the block.

    Yields the PRG instance (callers don't usually need it; it's exposed for
    introspection in ``test_seam.py``).

    Restores the originals on exit, including on exception (``try/finally``).

    Usage::

        with deterministic_sodium(master_seed_bytes) as prg:
            # ratchet code here will draw bytes from the patched stream
            rt = DoubleRatchet.init_initiator(shared, my_id, peer_id_pub)
            msg = rt.encrypt(b"hello")
        # patches are restored here

    The patched ``crypto_box_keypair`` / ``crypto_sign_keypair`` shims call
    ``bindings.crypto_box_seed_keypair`` / ``bindings.crypto_sign_seed_keypair``
    directly — those endpoints are NOT patched, so there is no recursion.
    """
    prg = _SodiumPRG(master_seed)
    real_randombytes = bindings.randombytes
    real_box_keypair = bindings.crypto_box_keypair
    real_sign_keypair = bindings.crypto_sign_keypair

    # Nesting guard — re-entering inside an already-active seam would capture
    # the OUTER seam's shims as "real" references; on inner exit, both finally
    # blocks would restore the inner shim, leaving the outer scope (and the
    # process) permanently bound to the patched function. Detect the case and
    # raise loudly rather than silently corrupt the binding.
    if any(
        getattr(fn, "__qualname__", "").startswith("deterministic_sodium.")
        for fn in (real_randombytes, real_box_keypair, real_sign_keypair)
    ):
        raise RuntimeError(
            "deterministic_sodium is already active on this thread; nesting "
            "would corrupt patch restore. Exit the outer `with` block first."
        )

    def patched_randombytes(n: int) -> bytes:
        return prg.stream_bytes("rb", n)

    def patched_box_keypair() -> tuple[bytes, bytes]:
        seed = prg.stream_bytes("box", 32)
        return bindings.crypto_box_seed_keypair(seed)

    def patched_sign_keypair() -> tuple[bytes, bytes]:
        seed = prg.stream_bytes("sig", 32)
        return bindings.crypto_sign_seed_keypair(seed)

    bindings.randombytes = patched_randombytes  # type: ignore[assignment]
    bindings.crypto_box_keypair = patched_box_keypair  # type: ignore[assignment]
    bindings.crypto_sign_keypair = patched_sign_keypair  # type: ignore[assignment]
    try:
        yield prg
    finally:
        bindings.randombytes = real_randombytes  # type: ignore[assignment]
        bindings.crypto_box_keypair = real_box_keypair  # type: ignore[assignment]
        bindings.crypto_sign_keypair = real_sign_keypair  # type: ignore[assignment]
