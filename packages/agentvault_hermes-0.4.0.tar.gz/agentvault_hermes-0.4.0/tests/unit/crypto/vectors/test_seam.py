"""Unit tests for the ``deterministic_sodium`` seam itself.

Verifies the PRG behaves like the JS reference impl
(``packages/crypto/scripts/regenerate_oc_vectors/seeded_sodium.mjs``) and
restores the patched ``nacl.bindings`` endpoints correctly.
"""
from __future__ import annotations

import hashlib

import pytest
from nacl import bindings

from .conftest import deterministic_sodium


SEED = bytes(range(32))


def test_seam_advances_counter_across_domains() -> None:
    """Counter is shared across domains.

    Drawing from ``"rb"`` then ``"box"`` then ``"rb"`` again must use distinct
    counter values 0, 1, 2 respectively. If counters were per-domain, ``a``
    and the box-seed could collide.
    """
    with deterministic_sodium(SEED):
        a = bindings.randombytes(32)  # counter 0, domain "rb"
        # patched crypto_box_keypair pulls 32 bytes from "box" domain at counter 1
        pk1, _sk1 = bindings.crypto_box_keypair()
        b = bindings.randombytes(32)  # counter 2, domain "rb"

    expected_a = hashlib.blake2b(
        SEED + b"rb" + (0).to_bytes(8, "little"), digest_size=64
    ).digest()[:32]
    expected_box_seed = hashlib.blake2b(
        SEED + b"box" + (1).to_bytes(8, "little"), digest_size=64
    ).digest()[:32]
    expected_b = hashlib.blake2b(
        SEED + b"rb" + (2).to_bytes(8, "little"), digest_size=64
    ).digest()[:32]
    assert a == expected_a
    assert b == expected_b
    expected_pk, _expected_sk = bindings.crypto_box_seed_keypair(expected_box_seed)
    assert pk1 == expected_pk


def test_seam_restores_on_normal_exit() -> None:
    real = bindings.randombytes
    with deterministic_sodium(SEED):
        assert bindings.randombytes is not real
    assert bindings.randombytes is real


def test_seam_restores_on_exception() -> None:
    real = bindings.randombytes
    with pytest.raises(ValueError, match="boom"):
        with deterministic_sodium(SEED):
            assert bindings.randombytes is not real
            raise ValueError("boom")
    assert bindings.randombytes is real


def test_seam_rejects_non_32_byte_seed() -> None:
    with pytest.raises(ValueError):
        with deterministic_sodium(b"\x00" * 31):
            pass


def test_seam_64_byte_block_boundary() -> None:
    """``stream_bytes`` loops the BLAKE2b block when ``n > 64``.

    Verify the second block lands correctly: ``randombytes(96)`` spans 2
    blocks (counters 0 and 1) and the second block contributes its first
    32 bytes.
    """
    with deterministic_sodium(SEED):
        big = bindings.randombytes(96)  # spans 2 blocks (counters 0 and 1)
    block0 = hashlib.blake2b(
        SEED + b"rb" + (0).to_bytes(8, "little"), digest_size=64
    ).digest()
    block1 = hashlib.blake2b(
        SEED + b"rb" + (1).to_bytes(8, "little"), digest_size=64
    ).digest()
    assert big[:64] == block0
    assert big[64:] == block1[:32]


def test_seam_patches_crypto_sign_keypair() -> None:
    """The ``"sig"`` domain shim is unused by current Hermes code paths but
    the seam patches it for OC parity. This test exercises the shim so a
    typo in ``patched_sign_keypair`` cannot ship silently.
    """
    with deterministic_sodium(SEED):
        # Burn counter 0 on "rb" so the sign keypair lands at counter 1, "sig".
        _ = bindings.randombytes(32)
        pk, sk = bindings.crypto_sign_keypair()

    expected_sig_seed = hashlib.blake2b(
        SEED + b"sig" + (1).to_bytes(8, "little"), digest_size=64
    ).digest()[:32]
    expected_pk, expected_sk = bindings.crypto_sign_seed_keypair(expected_sig_seed)
    assert pk == expected_pk
    assert sk == expected_sk


def test_seam_does_not_affect_nacl_utils_random() -> None:
    """Mechanical enforcement of the documented bypass.

    ``nacl.utils.random`` is a known bypass path (it routes through
    ``os.urandom``, NOT ``bindings.randombytes``). WS-24 vector tests
    deliberately avoid call sites that use it (notably
    ``nacl.signing.SigningKey.generate()`` and
    ``nacl.public.PrivateKey.generate()``). If a future PyNaCl release wires
    ``nacl.utils.random`` through ``bindings.randombytes``, this test starts
    failing — surfacing the audit obligation.
    """
    from nacl import utils as nacl_utils

    # Two consecutive draws from nacl.utils.random under the patched seam
    # must NOT collide with the deterministic stream — they come from os.urandom.
    with deterministic_sodium(SEED):
        a = nacl_utils.random(32)
        b = nacl_utils.random(32)

    # The seam-derived first 32 bytes from "rb" at counter 0 must NOT equal a.
    seam_block0 = hashlib.blake2b(
        SEED + b"rb" + (0).to_bytes(8, "little"), digest_size=64
    ).digest()[:32]
    assert a != seam_block0, (
        "nacl.utils.random returned bytes matching the deterministic stream — "
        "either by astronomical coincidence or because PyNaCl now routes "
        "nacl.utils.random through bindings.randombytes. Audit the seam."
    )
    # Two os.urandom draws must also not be equal to each other.
    assert a != b


def test_seam_rejects_nesting() -> None:
    """Re-entering ``deterministic_sodium`` inside an active block would
    corrupt the patch restore protocol. The seam must raise rather than
    silently allow it.
    """
    with deterministic_sodium(SEED):
        with pytest.raises(RuntimeError, match="already active"):
            with deterministic_sodium(SEED):
                pass  # pragma: no cover — should not reach here
