"""WS-24.1 — X3DH byte-equality tests against the OC vector fixtures.

Each fixture pins a fully deterministic X3DH input set (no RNG draws on the
critical path). Hermes' perform_x3dh must produce the same 32-byte shared
secret OC produced.
"""
from __future__ import annotations

import pytest

from agentvault_hermes.crypto.x3dh import X3DHParams, perform_x3dh

from .conftest import LoadVector

# Backwards-compatible alias preserved for symmetry with the rest of this
# test module's existing signatures; the canonical alias lives in conftest.
_LoadVector = LoadVector


def _strict_bool(name: str, fixture_name: str, raw: object) -> bool:
    """Return ``raw`` if it's a real ``bool``; raise ``TypeError`` otherwise.

    Plain ``bool(raw)`` accepts strings — ``bool("false") == True`` — so a
    fixture-generation regression that emitted ``"is_initiator": "false"`` as
    a quoted string would silently flip a receiver test to initiator mode.
    The byte-equality assertion would catch the wrong-mode bug, but as an
    opaque ``shared_secret diverges`` failure with no hint of the type drift.
    Failing here keeps the diagnosis on rails.
    """
    if not isinstance(raw, bool):
        raise TypeError(
            f"{fixture_name}: {name} must be a JSON bool, "
            f"got {type(raw).__name__}={raw!r}"
        )
    return raw


@pytest.mark.parametrize("fixture_name", ["x3dh_initiator.json", "x3dh_receiver.json"])
def test_x3dh_byte_equality(fixture_name: str, load_vector: _LoadVector) -> None:
    fx = load_vector(fixture_name)
    inputs = fx["inputs"]

    params = X3DHParams(
        my_identity_private=bytes.fromhex(inputs["my_identity_seed"]),
        my_ephemeral_private=bytes.fromhex(inputs["my_ephemeral_private"]),
        their_identity_public=bytes.fromhex(inputs["their_identity_public"]),
        their_ephemeral_public=bytes.fromhex(inputs["their_ephemeral_public"]),
        is_initiator=_strict_bool("is_initiator", fixture_name, inputs["is_initiator"]),
    )
    secret = perform_x3dh(params)
    assert secret.hex() == fx["expected"]["shared_secret"], (
        f"{fixture_name}: Hermes X3DH shared_secret diverges from OC. "
        f"expected={fx['expected']['shared_secret']} got={secret.hex()}"
    )


def test_x3dh_initiator_and_receiver_disagree_when_flag_flipped(
    load_vector: _LoadVector,
) -> None:
    """Sanity: the two fixtures use the SAME inputs but different is_initiator
    flags; therefore the recorded shared secrets must differ."""
    a = load_vector("x3dh_initiator.json")["expected"]["shared_secret"]
    b = load_vector("x3dh_receiver.json")["expected"]["shared_secret"]
    assert a != b, (
        "WS-23 fixture set is degenerate: initiator/receiver shared secrets "
        "must differ (same inputs, different is_initiator flag)"
    )
