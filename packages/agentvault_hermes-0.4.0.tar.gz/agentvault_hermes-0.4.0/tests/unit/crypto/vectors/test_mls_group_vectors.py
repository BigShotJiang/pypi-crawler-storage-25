"""WS-24.3 — MLS parse-only verification tests against the OC vector fixtures.

Per the locked-in decision in §3.1 of the WS-24 plan, MLS scenarios assert
structural compatibility ONLY (no byte-equality), because mls-rs-uniffi 0.1.x
does not expose Python-injectable RNG and Hermes cannot reproduce OC's MLS
wire bytes deterministically.

Per-scenario triage (see §6.3 of the plan):

- ``mls_group_create``                 — PASS  (structural ciphersuite + initial epoch)
- ``mls_group_welcome``                — XFAIL (action #124 — joiner-state plumbing)
- ``mls_group_encrypt_application``    — XFAIL (OC↔Hermes envelope impedance, plan §4.4)
- ``mls_group_add_member``             — XFAIL (same impedance — can't reach pre-add state)
- ``mls_group_remove_member``          — XFAIL (same impedance)

The xfail tests stay parked here so when WS-25 (or follow-up impedance work)
lands, removing the xfail marker turns them into real passes without any
test-file restructure. Per ``feedback_xfail_documented_failures_2026-05-09.md``
the markers are at the TEST LEVEL with ``strict=False`` and a specific
``reason=`` citing the blocker (NOT generic "TODO").
"""
from __future__ import annotations

import base64
import json
import uuid
from typing import Any

import pytest

from agentvault_hermes.crypto.mls_group import (
    DEFAULT_CIPHERSUITE,
    MlsGroupState,
    _IANA_CIPHER_SUITE_BY_NAME,
)
from agentvault_hermes.crypto.ratchet import SigningKeypair

from .conftest import LoadVector


CIPHERSUITE_OC_NAME = "MLS_128_DHKEMX25519_AES128GCM_SHA256_Ed25519"
CIPHERSUITE_HERMES_ENUM_NAME = "CURVE25519_AES128"


def _fresh_signing_keypair() -> SigningKeypair:
    """Build a deterministic-but-arbitrary ``SigningKeypair`` for tests that
    don't need byte-equality with OC's keys (only the ciphersuite shape needs
    to match).

    ``SigningKeypair.private_key`` holds a 32-byte Ed25519 SEED
    (``ratchet.py:57``), NOT a 64-byte libsodium sk — the production code
    treats it as a seed, so passing a 64-byte sk would diverge.
    """
    from nacl import bindings

    seed = bytes(range(32))  # arbitrary fixed seed
    pk, _sk_64 = bindings.crypto_sign_seed_keypair(seed)
    return SigningKeypair(public_key=pk, private_key=seed)


def _decode_oc_state_envelope(fx: dict[str, Any]) -> dict[str, Any]:
    """The fixture's ``expected.alice_state_after_create_json`` is a NESTED
    JSON STRING. Decode the outer fixture, then ``json.loads`` the inner
    string, then base64-decode ``groupState``.

    Defensive: assert the outer is a string before decoding so a future
    fixture-shape regression (e.g. flipping to a non-nested envelope)
    fails loudly with a precise message rather than silently parsing as
    a dict.
    """
    outer = fx["expected"]["alice_state_after_create_json"]
    assert isinstance(outer, str), (
        "alice_state_after_create_json should be a nested JSON string; "
        f"got {type(outer).__name__}"
    )
    try:
        inner = json.loads(outer)
        return {
            "group_state_bytes": base64.b64decode(inner["groupState"]),
            "ciphersuite": inner["ciphersuite"],
        }
    except (json.JSONDecodeError, KeyError, ValueError, TypeError) as e:
        # Convert raw json/base64 errors into a fixture-shape diagnostic so a
        # future fixture-generation regression doesn't look like a Hermes bug.
        raise AssertionError(
            f"alice_state_after_create_json: malformed inner envelope "
            f"({type(e).__name__}: {e}). Expected nested JSON string with "
            f"keys 'groupState' (base64) + 'ciphersuite'."
        ) from e


# ---- mls_group_create -----------------------------------------------------


def test_mls_group_create_ciphersuite_mapping(load_vector: LoadVector) -> None:
    """Structural test: Hermes' ``DEFAULT_CIPHERSUITE`` maps to the same
    RFC 9420 §17.1 IANA ID OC's fixture references, AND the OC state
    envelope encodes the matching ciphersuite name.

    This is the one MLS scenario that lands as a real PASS today; the other
    four are blocked on the OC↔Hermes envelope impedance (plan §4.4) and
    on joiner-state plumbing (action #124).
    """
    fx = load_vector("mls_group_create.json")

    # OC fixture's input ciphersuite name matches the on-the-wire RFC 9420 name.
    assert fx["inputs"]["ciphersuite"] == CIPHERSUITE_OC_NAME

    # Inner OC state envelope advertises the same ciphersuite name.
    inner = _decode_oc_state_envelope(fx)
    assert inner["ciphersuite"] == CIPHERSUITE_OC_NAME

    # Hermes' DEFAULT_CIPHERSUITE is CURVE25519_AES128; verify the IANA-ID
    # map matches the wire-format value used in KeyPackage / GroupContext.
    assert DEFAULT_CIPHERSUITE.name == CIPHERSUITE_HERMES_ENUM_NAME
    assert (
        _IANA_CIPHER_SUITE_BY_NAME[CIPHERSUITE_HERMES_ENUM_NAME] == 0x0001
    )  # MLS_128_DHKEMX25519_AES128GCM_SHA256_Ed25519

    # Initial epoch sanity (Hermes-side fresh group).
    state = MlsGroupState(
        _fresh_signing_keypair(), uuid.uuid4(), DEFAULT_CIPHERSUITE
    )
    state.create_group(b"hermes-test-group")
    assert state.epoch == 0
    assert fx["expected"]["initial_epoch"] == 0
    # Tighter check: the live state actually exposes the configured suite via
    # its public property (covers a future bug where __init__ stores the suite
    # but a downstream code path silently swaps it).
    assert state.ciphersuite_name == CIPHERSUITE_HERMES_ENUM_NAME


# ---- mls_group_welcome ---------------------------------------------------


@pytest.mark.xfail(
    strict=False,
    reason=(
        "OC welcome targets a KeyPackage Hermes did not generate, so "
        "mls_rs_uniffi rejects join_from_welcome before the joiner-state "
        "layer is even reached. Even when that's bridged, joiner-side "
        "RatchetTree parsing must populate _signing_identities_by_leaf. "
        "Action #124 owns both layers (WS-25 / spec §11 joiner-state "
        "plumbing)."
    ),
)
def test_mls_group_welcome_consume_oc_welcome(load_vector: LoadVector) -> None:
    fx = load_vector("mls_group_welcome.json")
    welcome_bytes = bytes.fromhex(fx["expected"]["welcome_bytes"])
    bob = MlsGroupState(
        _fresh_signing_keypair(), uuid.uuid4(), DEFAULT_CIPHERSUITE
    )
    # Will raise inside mls_rs_uniffi: welcome targets an OC-generated
    # KeyPackage, not Bob's KeyPackage — wheel raises a ProcessingError. xfail.
    bob.join_from_welcome(welcome_bytes)
    assert bob.epoch == fx["expected"]["epoch_after_add"]


# ---- mls_group_encrypt_application ---------------------------------------


@pytest.mark.xfail(
    strict=False,
    reason=(
        "OC↔Hermes envelope impedance (plan §4.4): Hermes' "
        "MlsGroupState.import_state expects TLV-packed bytes from "
        "export_state, NOT OC's structured {groupState, ciphersuite} "
        "envelope. Currently raises ValueError 'Unknown TLV version 0x00' "
        "from _unpack_tlv (mls_group.py:223). Decrypting OC's application "
        "ciphertext requires Hermes to first reach the matching epoch-1 "
        "state, which is blocked until the impedance bridge lands. "
        "Action #126 owns this."
    ),
)
def test_mls_group_decrypt_oc_application_message(
    load_vector: LoadVector,
) -> None:
    create_fx = load_vector("mls_group_create.json")
    encrypt_fx = load_vector("mls_group_encrypt_application.json")
    inner = _decode_oc_state_envelope(create_fx)

    alice = MlsGroupState(
        _fresh_signing_keypair(), uuid.uuid4(), DEFAULT_CIPHERSUITE
    )
    alice.import_state(inner["group_state_bytes"])  # raises — TLV format mismatch.

    ciphertext = bytes.fromhex(encrypt_fx["expected"]["ciphertext_bytes"])
    result = alice.decrypt(ciphertext)
    assert result.is_handshake is False
    assert result.plaintext == encrypt_fx["inputs"]["plaintext"].encode("utf-8")


# ---- mls_group_add_member ------------------------------------------------


@pytest.mark.xfail(
    strict=False,
    reason=(
        "Same OC↔Hermes envelope impedance as encrypt_application "
        "(plan §4.4): cannot reach the pre-add Alice state from OC's "
        "serialized state envelope. Action #126 owns this."
    ),
)
def test_mls_group_process_oc_add_commit(load_vector: LoadVector) -> None:
    create_fx = load_vector("mls_group_create.json")
    add_fx = load_vector("mls_group_add_member.json")
    inner = _decode_oc_state_envelope(create_fx)

    alice = MlsGroupState(
        _fresh_signing_keypair(), uuid.uuid4(), DEFAULT_CIPHERSUITE
    )
    alice.import_state(inner["group_state_bytes"])  # raises — envelope mismatch.

    alice.process_commit(bytes.fromhex(add_fx["expected"]["commit_bytes"]))
    assert alice.epoch == add_fx["expected"]["epoch_after_add"]


# ---- mls_group_remove_member ---------------------------------------------


@pytest.mark.xfail(
    strict=False,
    reason=(
        "Same OC↔Hermes envelope impedance as encrypt_application "
        "(plan §4.4): cannot reach the pre-remove Alice state from OC's "
        "serialized state envelope. Action #126 owns this."
    ),
)
def test_mls_group_process_oc_remove_commit(load_vector: LoadVector) -> None:
    create_fx = load_vector("mls_group_create.json")
    remove_fx = load_vector("mls_group_remove_member.json")
    inner = _decode_oc_state_envelope(create_fx)

    alice = MlsGroupState(
        _fresh_signing_keypair(), uuid.uuid4(), DEFAULT_CIPHERSUITE
    )
    alice.import_state(inner["group_state_bytes"])  # raises — envelope mismatch.

    alice.process_commit(bytes.fromhex(remove_fx["expected"]["commit_bytes"]))
    assert alice.epoch == remove_fx["expected"]["epoch_after_remove"]
