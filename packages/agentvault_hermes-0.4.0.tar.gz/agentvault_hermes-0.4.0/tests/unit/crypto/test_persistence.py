"""Tests for crypto.persistence — cross-cutting conversation helpers."""
from __future__ import annotations

import json
import os
import stat
import uuid
from datetime import datetime, timezone
from pathlib import Path

import pytest

from agentvault_hermes.crypto.persistence import (
    ConversationMeta,
    delete_conversation,
    list_conversations,
    read_meta,
    write_meta,
)


def test_list_returns_empty_when_no_conversations(tmp_path: Path):
    assert list_conversations(tmp_path) == []


def test_write_meta_creates_directory_with_secure_mode(tmp_path: Path):
    cid = uuid.uuid4()
    meta = ConversationMeta(
        conversation_id=cid,
        type="direct",
        created_at=datetime.now(timezone.utc),
        last_message_ts=None,
    )
    write_meta(tmp_path, cid, meta)

    conv_dir = tmp_path / "conversations" / str(cid)
    assert conv_dir.exists()
    if os.name == "posix":
        assert stat.S_IMODE(conv_dir.stat().st_mode) == 0o700
        meta_file = conv_dir / "meta.json"
        assert stat.S_IMODE(meta_file.stat().st_mode) == 0o600


def test_write_then_read_round_trip(tmp_path: Path):
    cid = uuid.uuid4()
    now = datetime.now(timezone.utc).replace(microsecond=0)
    meta = ConversationMeta(
        conversation_id=cid,
        type="room",
        created_at=now,
        last_message_ts=now,
    )
    write_meta(tmp_path, cid, meta)
    loaded = read_meta(tmp_path, cid)
    assert loaded is not None
    assert loaded.conversation_id == cid
    assert loaded.type == "room"
    assert loaded.created_at == now
    assert loaded.last_message_ts == now


def test_read_meta_returns_none_when_absent(tmp_path: Path):
    assert read_meta(tmp_path, uuid.uuid4()) is None


def test_list_conversations_after_creating_three(tmp_path: Path):
    cids = [uuid.uuid4() for _ in range(3)]
    types = ["direct", "room", "a2a"]
    now = datetime.now(timezone.utc)
    for cid, t in zip(cids, types):
        write_meta(tmp_path, cid, ConversationMeta(
            conversation_id=cid, type=t, created_at=now, last_message_ts=None
        ))
    listed = list_conversations(tmp_path)
    assert len(listed) == 3
    assert sorted(m.type for m in listed) == ["a2a", "direct", "room"]


def test_delete_removes_directory(tmp_path: Path):
    cid = uuid.uuid4()
    write_meta(tmp_path, cid, ConversationMeta(
        conversation_id=cid, type="direct",
        created_at=datetime.now(timezone.utc), last_message_ts=None,
    ))
    # Drop a fake state file alongside meta.json
    (tmp_path / "conversations" / str(cid) / "ratchet.bin").write_bytes(b"fake")

    delete_conversation(tmp_path, cid)
    assert not (tmp_path / "conversations" / str(cid)).exists()


def test_delete_idempotent_on_missing_conversation(tmp_path: Path):
    """Deleting a conversation that doesn't exist should not raise."""
    delete_conversation(tmp_path, uuid.uuid4())  # no error


def test_read_meta_rejects_invalid_type(tmp_path: Path):
    """A malformed meta.json with an out-of-Literal `type` value must be rejected."""
    cid = uuid.uuid4()
    conv_dir = tmp_path / "conversations" / str(cid)
    conv_dir.mkdir(parents=True)
    meta_file = conv_dir / "meta.json"
    meta_file.write_text(json.dumps({
        "version": 1,
        "conversation_id": str(cid),
        "type": "broadcast",  # not in {direct, room, a2a}
        "created_at": datetime.now(timezone.utc).isoformat(),
        "last_message_ts": None,
    }))
    with pytest.raises(ValueError, match="invalid 'type'"):
        read_meta(tmp_path, cid)
