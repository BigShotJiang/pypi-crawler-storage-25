"""Tests for X3DH key agreement.

The reference implementation is OC's packages/crypto/src/x3dh.ts. Our
implementation must produce the same 32-byte shared secret for the same
inputs (verified in WS-24 via recorded vectors).
"""
from __future__ import annotations

import pytest
from nacl import signing as nacl_signing
from nacl.public import PrivateKey

from agentvault_hermes.crypto.primitives import ed25519_to_x25519_public, ed25519_to_x25519_secret
from agentvault_hermes.crypto.x3dh import X3DHParams, perform_x3dh


def _generate_keypairs():
    """Generate (identity_seed, identity_pub, ephemeral_secret, ephemeral_pub) for one party."""
    sk = nacl_signing.SigningKey.generate()
    identity_seed = bytes(sk)
    identity_pub = bytes(sk.verify_key)
    ek = PrivateKey.generate()
    ephemeral_secret = bytes(ek)
    ephemeral_pub = bytes(ek.public_key)
    return identity_seed, identity_pub, ephemeral_secret, ephemeral_pub


def test_returns_32_bytes():
    a_id_priv, a_id_pub, a_eph_priv, a_eph_pub = _generate_keypairs()
    b_id_priv, b_id_pub, b_eph_priv, b_eph_pub = _generate_keypairs()

    secret = perform_x3dh(X3DHParams(
        my_identity_private=a_id_priv,
        my_ephemeral_private=a_eph_priv,
        their_identity_public=b_id_pub,
        their_ephemeral_public=b_eph_pub,
        is_initiator=True,
    ))
    assert len(secret) == 32


def test_initiator_and_receiver_derive_same_secret():
    """The whole point of X3DH: both sides compute the same shared secret."""
    a_id_priv, a_id_pub, a_eph_priv, a_eph_pub = _generate_keypairs()
    b_id_priv, b_id_pub, b_eph_priv, b_eph_pub = _generate_keypairs()

    secret_a = perform_x3dh(X3DHParams(
        my_identity_private=a_id_priv,
        my_ephemeral_private=a_eph_priv,
        their_identity_public=b_id_pub,
        their_ephemeral_public=b_eph_pub,
        is_initiator=True,
    ))
    secret_b = perform_x3dh(X3DHParams(
        my_identity_private=b_id_priv,
        my_ephemeral_private=b_eph_priv,
        their_identity_public=a_id_pub,
        their_ephemeral_public=a_eph_pub,
        is_initiator=False,
    ))
    assert secret_a == secret_b


def test_role_swap_changes_secret():
    """Same keys but role swapped should produce different secret (initiator concat order)."""
    a_id_priv, a_id_pub, a_eph_priv, a_eph_pub = _generate_keypairs()
    b_id_priv, b_id_pub, b_eph_priv, b_eph_pub = _generate_keypairs()

    s1 = perform_x3dh(X3DHParams(
        my_identity_private=a_id_priv,
        my_ephemeral_private=a_eph_priv,
        their_identity_public=b_id_pub,
        their_ephemeral_public=b_eph_pub,
        is_initiator=True,
    ))
    s2 = perform_x3dh(X3DHParams(
        my_identity_private=a_id_priv,
        my_ephemeral_private=a_eph_priv,
        their_identity_public=b_id_pub,
        their_ephemeral_public=b_eph_pub,
        is_initiator=False,
    ))
    assert s1 != s2  # different concatenation order → different BLAKE2b hash


def test_different_keys_different_secret():
    a_id_priv, a_id_pub, a_eph_priv, a_eph_pub = _generate_keypairs()
    b_id_priv, b_id_pub, b_eph_priv, b_eph_pub = _generate_keypairs()
    c_id_priv, c_id_pub, c_eph_priv, c_eph_pub = _generate_keypairs()

    s_ab = perform_x3dh(X3DHParams(
        my_identity_private=a_id_priv,
        my_ephemeral_private=a_eph_priv,
        their_identity_public=b_id_pub,
        their_ephemeral_public=b_eph_pub,
        is_initiator=True,
    ))
    s_ac = perform_x3dh(X3DHParams(
        my_identity_private=a_id_priv,
        my_ephemeral_private=a_eph_priv,
        their_identity_public=c_id_pub,
        their_ephemeral_public=c_eph_pub,
        is_initiator=True,
    ))
    assert s_ab != s_ac


def test_deterministic_for_same_inputs():
    a_id_priv, a_id_pub, a_eph_priv, a_eph_pub = _generate_keypairs()
    b_id_priv, b_id_pub, b_eph_priv, b_eph_pub = _generate_keypairs()
    params = X3DHParams(
        my_identity_private=a_id_priv,
        my_ephemeral_private=a_eph_priv,
        their_identity_public=b_id_pub,
        their_ephemeral_public=b_eph_pub,
        is_initiator=True,
    )
    assert perform_x3dh(params) == perform_x3dh(params)


def test_ephemeral_fallback_does_not_crash():
    """Asymmetric scenario: only one side uses identity-as-ephemeral. Verifies
    the fallback path doesn't crash when one side substitutes."""
    a_id_priv, a_id_pub, a_eph_priv, a_eph_pub = _generate_keypairs()
    b_id_priv, b_id_pub, b_eph_priv, b_eph_pub = _generate_keypairs()

    secret_a = perform_x3dh(X3DHParams(
        my_identity_private=a_id_priv,
        my_ephemeral_private=a_eph_priv,
        their_identity_public=b_id_pub,
        their_ephemeral_public=b_id_pub,  # fallback: identity used as ephemeral
        is_initiator=True,
    ))
    secret_b = perform_x3dh(X3DHParams(
        my_identity_private=b_id_priv,
        my_ephemeral_private=b_eph_priv,
        their_identity_public=a_id_pub,
        their_ephemeral_public=a_eph_pub,  # B uses A's real ephemeral, not A's identity
        is_initiator=False,
    ))
    # Both produce 32 bytes; the round-trip won't match because the setup
    # is asymmetric. The symmetric round-trip is in test_ephemeral_fallback_round_trip.
    assert len(secret_a) == 32
    assert len(secret_b) == 32


def test_ephemeral_fallback_round_trip():
    """Symmetric fallback: BOTH sides treat the peer's identity as their
    ephemeral. Mirrors what happens when the activate response omits
    owner_ephemeral_public_key on both ends. Round-trip must agree.

    Important: OC's X3DHParams.theirEphemeralPublic is an X25519 key (32 bytes).
    When the fallback substitutes the identity public, it must be the
    X25519-converted form (ed25519_to_x25519_public), not the raw Ed25519 key.
    Likewise, my_ephemeral_private must be the X25519-derived identity secret
    (ed25519_to_x25519_secret). Passing the raw Ed25519 public as theirEphemeral
    feeds it as a bare curve25519 point, producing a different scalar-mult result
    from the converted form — so the two sides would never agree.
    """
    a_id_priv, a_id_pub, a_eph_priv, a_eph_pub = _generate_keypairs()
    b_id_priv, b_id_pub, b_eph_priv, b_eph_pub = _generate_keypairs()

    # Derive X25519 forms of the identity keys for the fallback
    a_id_x_priv = ed25519_to_x25519_secret(a_id_priv)
    a_id_x_pub = ed25519_to_x25519_public(a_id_pub)
    b_id_x_priv = ed25519_to_x25519_secret(b_id_priv)
    b_id_x_pub = ed25519_to_x25519_public(b_id_pub)

    secret_a = perform_x3dh(X3DHParams(
        my_identity_private=a_id_priv,
        my_ephemeral_private=a_id_x_priv,    # X25519 identity secret as ephemeral
        their_identity_public=b_id_pub,
        their_ephemeral_public=b_id_x_pub,   # X25519 form of B's identity as ephemeral
        is_initiator=True,
    ))
    secret_b = perform_x3dh(X3DHParams(
        my_identity_private=b_id_priv,
        my_ephemeral_private=b_id_x_priv,    # X25519 identity secret as ephemeral
        their_identity_public=a_id_pub,
        their_ephemeral_public=a_id_x_pub,   # X25519 form of A's identity as ephemeral
        is_initiator=False,
    ))
    assert secret_a == secret_b
    assert len(secret_a) == 32


def test_validates_identity_private_length():
    with pytest.raises(ValueError, match="32 bytes"):
        perform_x3dh(X3DHParams(
            my_identity_private=b"too short",
            my_ephemeral_private=b"\x00" * 32,
            their_identity_public=b"\x00" * 32,
            their_ephemeral_public=b"\x00" * 32,
            is_initiator=True,
        ))


def test_validates_ephemeral_private_length():
    with pytest.raises(ValueError, match="32 bytes"):
        perform_x3dh(X3DHParams(
            my_identity_private=b"\x00" * 32,
            my_ephemeral_private=b"short",
            their_identity_public=b"\x00" * 32,
            their_ephemeral_public=b"\x00" * 32,
            is_initiator=True,
        ))


def test_validates_their_identity_public_length():
    with pytest.raises(ValueError, match="32 bytes"):
        perform_x3dh(X3DHParams(
            my_identity_private=b"\x00" * 32,
            my_ephemeral_private=b"\x00" * 32,
            their_identity_public=b"x",
            their_ephemeral_public=b"\x00" * 32,
            is_initiator=True,
        ))


def test_validates_their_ephemeral_public_length():
    with pytest.raises(ValueError, match="32 bytes"):
        perform_x3dh(X3DHParams(
            my_identity_private=b"\x00" * 32,
            my_ephemeral_private=b"\x00" * 32,
            their_identity_public=b"\x00" * 32,
            their_ephemeral_public=b"x",
            is_initiator=True,
        ))
