"""Integration tests — Hermes multi-agent (profile-aware) setup.

Proves: setup --profile creates an isolated profile + enrolls; two profiles do
not collide; an existing legacy-layout install migrates and still loads.
"""
from __future__ import annotations

import base64
import json
import os
import uuid
from pathlib import Path

import pytest
import respx
from httpx import Response

import agentvault_hermes.cli.setup as _setup_module
from agentvault_hermes.cli.setup import run_setup
from agentvault_hermes.core.config import migrate_legacy_layout, resolve_data_dir

_API_URL = "https://api.test.example.com"


def _make_jwt(tenant_id: str = "tenant-1") -> str:
    """Build a minimal JWT payload that _decode_jwt_tenant_id can parse."""
    header = base64.urlsafe_b64encode(b'{"alg":"HS256","typ":"JWT"}').decode().rstrip("=")
    payload = base64.urlsafe_b64encode(
        json.dumps({"sub": str(uuid.uuid4()), "tid": tenant_id, "type": "device"}).encode()
    ).decode().rstrip("=")
    return f"{header}.{payload}.signature"


def _mock_backend(mock: respx.Router, device_id: str | None = None) -> str:
    """Register enroll / status / activate routes. Returns the device_id used."""
    did = device_id or str(uuid.uuid4())
    mock.post("/api/v1/enroll").mock(
        return_value=Response(
            201,
            json={"device_id": did, "fingerprint": "fp_test", "status": "PENDING"},
        )
    )
    mock.get(f"/api/v1/devices/{did}/status").mock(
        return_value=Response(
            200,
            json={"device_id": did, "status": "APPROVED", "fingerprint": "fp_test"},
        )
    )
    mock.post(f"/api/v1/devices/{did}/activate").mock(
        return_value=Response(
            200,
            json={
                "device_id": did,
                "conversation_id": str(uuid.uuid4()),
                "status": "ACTIVE",
                "device_jwt": _make_jwt("tenant-1"),
                "owner_identity_public_key": "00" * 32,
                "conversations": [],
            },
        )
    )
    return did


def _bootstrap_hermes_install(home: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Seed the Hermes installation prerequisites that run_setup validates.

    Mirrors _bootstrap_hermes_install from the old test_setup_flow.py:
      - Creates ~/.hermes/config.yaml so _check_environment passes for
        the default-profile path.
      - Puts a fake `hermes` binary on PATH so detect_hermes_install (Tier 3)
        and shutil.which("hermes") both succeed.
    """
    hermes_dir = home / ".hermes"
    hermes_dir.mkdir(parents=True, exist_ok=True)
    (hermes_dir / "config.yaml").write_text("# minimal hermes config\n", encoding="utf-8")

    fake_bin_dir = home / ".fake-bin"
    fake_bin_dir.mkdir(parents=True, exist_ok=True)
    fake_hermes = fake_bin_dir / "hermes"
    fake_hermes.write_text("#!/bin/sh\necho 'fake hermes'\n")
    fake_hermes.chmod(0o755)
    existing_path = os.environ.get("PATH", "/usr/bin:/bin")
    monkeypatch.setenv("PATH", f"{fake_bin_dir}:{existing_path}")


def _patch_poll_fast(monkeypatch: pytest.MonkeyPatch) -> None:
    """Zero out poll delays and cap attempts to avoid slow tests."""
    monkeypatch.setattr(_setup_module, "_POLL_INTERVAL_SECONDS", 0.0)
    monkeypatch.setattr(_setup_module, "_POLL_MAX_ATTEMPTS", 5)


def _fake_profile_create(
    monkeypatch: pytest.MonkeyPatch,
    home: Path,
) -> None:
    """Patch subprocess.run so 'hermes profile create <name>' creates the dir.

    Mirrors REAL Hermes 0.13.0 behavior: creates the profile dir but does
    NOT write a config.yaml. The plugin's ensure_profile_exists is
    responsible for seeding the file — these integration tests prove that
    fallback works end-to-end.

    run_setup calls subprocess.run via agentvault_hermes.cli.setup.subprocess.run
    (the imported module reference).
    """
    import subprocess as _subprocess

    def fake_run(args, **kwargs):  # type: ignore[no-untyped-def]
        if (
            isinstance(args, list)
            and len(args) >= 4
            and args[:3] == ["hermes", "profile", "create"]
        ):
            profile_name = args[3]
            profile_home = home / ".hermes" / "profiles" / profile_name
            profile_home.mkdir(parents=True, exist_ok=True)
            # IMPORTANT: do NOT write config.yaml — real Hermes 0.13.0 doesn't.
            # The plugin's ensure_profile_exists must compensate; if these
            # integration tests still pass, end-to-end fallback is proven.
            return _subprocess.CompletedProcess(args, 0, "", "")
        return _subprocess.CompletedProcess(args, 0, "", "")

    monkeypatch.setattr(_setup_module.subprocess, "run", fake_run)


@pytest.mark.asyncio
async def test_setup_profile_enrolls_into_isolated_profile(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """setup --profile=work creates an isolated profile dir and enrolls there."""
    _bootstrap_hermes_install(fake_hermes_home, monkeypatch)
    _patch_poll_fast(monkeypatch)
    _fake_profile_create(monkeypatch, fake_hermes_home)
    monkeypatch.setenv("AGENTVAULT_HERMES_API_URL", _API_URL)

    async with respx.mock(base_url=_API_URL) as mock:
        _mock_backend(mock)
        result = await run_setup(token="av_tok_work", profile="work")

    assert result.success, result.error
    assert result.was_idempotent is False

    # State must land in the profile-scoped agentvault dir, NOT in ~/.hermes/agentvault/.
    state = fake_hermes_home / ".hermes" / "profiles" / "work" / "agentvault" / "state.json"
    assert state.exists(), f"state.json not found at {state}"

    # The default-profile path must remain empty.
    default_state = fake_hermes_home / ".hermes" / "agentvault" / "state.json"
    assert not default_state.exists(), "profile setup must not write to default-profile dir"


@pytest.mark.asyncio
async def test_two_profiles_do_not_collide(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Two profiles enrolled back-to-back have independent, non-equal state files."""
    _bootstrap_hermes_install(fake_hermes_home, monkeypatch)
    _patch_poll_fast(monkeypatch)
    _fake_profile_create(monkeypatch, fake_hermes_home)
    monkeypatch.setenv("AGENTVAULT_HERMES_API_URL", _API_URL)

    for prof in ("work", "research"):
        async with respx.mock(base_url=_API_URL) as mock:
            _mock_backend(mock)
            result = await run_setup(token=f"av_tok_{prof}", profile=prof)
        assert result.success, f"setup failed for profile={prof!r}: {result.error}"

    work_state = (
        fake_hermes_home / ".hermes" / "profiles" / "work" / "agentvault" / "state.json"
    )
    research_state = (
        fake_hermes_home / ".hermes" / "profiles" / "research" / "agentvault" / "state.json"
    )
    assert work_state.exists(), "work state.json not found"
    assert research_state.exists(), "research state.json not found"

    # Each profile must get an independent device identity (different device_ids).
    work_data = json.loads(work_state.read_text())
    research_data = json.loads(research_state.read_text())
    assert work_data["device_id"] != research_data["device_id"], (
        "profiles must have independent device identities"
    )


@pytest.mark.asyncio
async def test_setup_default_profile_enrolls_into_root_data_dir(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """`setup` with no --profile writes state to the default profile location.

    Default-profile path is ``~/.hermes/agentvault/state.json`` (flat layout,
    post-Task-3 migration). Nothing under ``~/.hermes/profiles/`` should be
    created when no profile is named.
    """
    _bootstrap_hermes_install(fake_hermes_home, monkeypatch)
    _patch_poll_fast(monkeypatch)
    _fake_profile_create(monkeypatch, fake_hermes_home)
    monkeypatch.setenv("AGENTVAULT_HERMES_API_URL", _API_URL)

    async with respx.mock(base_url=_API_URL) as mock:
        _mock_backend(mock)
        result = await run_setup(token="av_tok_default")

    assert result.success, result.error
    assert result.was_idempotent is False

    # State at the default-profile path (flat layout), NOT under profiles/.
    state = fake_hermes_home / ".hermes" / "agentvault" / "state.json"
    assert state.exists(), f"state.json not found at {state}"

    # No profile subdir should have been created.
    profiles_dir = fake_hermes_home / ".hermes" / "profiles"
    assert not profiles_dir.exists() or not any(profiles_dir.iterdir()), (
        "default-profile setup must not create ~/.hermes/profiles/<anything>"
    )


@pytest.mark.asyncio
async def test_setup_is_idempotent_when_state_exists(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A second setup call when state.json already exists returns idempotent success.

    The short-circuit must happen BEFORE the backend is contacted: the second
    respx mock registers no handlers, so any HTTP call would raise.
    """
    _bootstrap_hermes_install(fake_hermes_home, monkeypatch)
    _patch_poll_fast(monkeypatch)
    _fake_profile_create(monkeypatch, fake_hermes_home)
    monkeypatch.setenv("AGENTVAULT_HERMES_API_URL", _API_URL)

    # First call enrolls.
    async with respx.mock(base_url=_API_URL) as mock:
        _mock_backend(mock)
        first = await run_setup(token="av_tok_x", profile="work")
    assert first.success, first.error
    assert first.was_idempotent is False

    # Second call must short-circuit before hitting the backend.
    async with respx.mock(base_url=_API_URL):
        # Deliberately register no handlers — any backend call would raise.
        second = await run_setup(token="av_tok_x", profile="work")
    assert second.success, second.error
    assert second.was_idempotent is True
    assert second.device_id == first.device_id


@pytest.mark.asyncio
async def test_named_profile_setup_does_not_create_default_dir(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """`setup --profile=work` must not create `~/.hermes/agentvault/` (the default-profile dir).

    Regression for the bug where ``ensure_data_dir()`` was called with no argument,
    creating the default-profile directory even during a named-profile setup.
    """
    _patch_poll_fast(monkeypatch)
    _bootstrap_hermes_install(fake_hermes_home, monkeypatch)
    _fake_profile_create(monkeypatch, fake_hermes_home)
    monkeypatch.setenv("AGENTVAULT_HERMES_API_URL", _API_URL)

    async with respx.mock(base_url=_API_URL) as mock:
        _mock_backend(mock)
        result = await run_setup(token="av_tok_x", profile="work")

    assert result.success, result.error
    # Profile state exists in the right place.
    assert (fake_hermes_home / ".hermes" / "profiles" / "work" / "agentvault" / "state.json").exists()
    # Default-profile dir must NOT be created.
    default_dir = fake_hermes_home / ".hermes" / "agentvault"
    assert not default_dir.exists(), f"spurious default-profile directory created at {default_dir}"


@pytest.mark.asyncio
async def test_setup_rejects_invalid_invite_token(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A backend 400 on /enroll surfaces as a clean SetupResult failure."""
    _bootstrap_hermes_install(fake_hermes_home, monkeypatch)
    _patch_poll_fast(monkeypatch)
    _fake_profile_create(monkeypatch, fake_hermes_home)
    monkeypatch.setenv("AGENTVAULT_HERMES_API_URL", _API_URL)

    async with respx.mock(base_url=_API_URL) as mock:
        mock.post("/api/v1/enroll").mock(
            return_value=Response(400, json={"detail": "invalid token"})
        )
        result = await run_setup(token="av_tok_bad", profile="work")

    assert result.success is False
    assert result.error  # non-empty error message

    # No state file was created.
    state = (
        fake_hermes_home / ".hermes" / "profiles" / "work" / "agentvault" / "state.json"
    )
    assert not state.exists()


@pytest.mark.asyncio
async def test_setup_fails_when_owner_rejects_device(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """If owner-side approval returns REJECTED, setup fails cleanly and never activates."""
    _bootstrap_hermes_install(fake_hermes_home, monkeypatch)
    _patch_poll_fast(monkeypatch)
    _fake_profile_create(monkeypatch, fake_hermes_home)
    monkeypatch.setenv("AGENTVAULT_HERMES_API_URL", _API_URL)

    did = str(uuid.uuid4())
    async with respx.mock(base_url=_API_URL) as mock:
        # Enroll succeeds.
        mock.post("/api/v1/enroll").mock(
            return_value=Response(
                201,
                json={"device_id": did, "fingerprint": "fp_test", "status": "PENDING"},
            )
        )
        # Status returns REJECTED on first poll.
        mock.get(f"/api/v1/devices/{did}/status").mock(
            return_value=Response(
                200,
                json={"device_id": did, "status": "REJECTED", "fingerprint": "fp_test"},
            )
        )
        # NOTE: no /activate handler registered — if setup tries to activate, respx raises.
        result = await run_setup(token="av_tok_x", profile="work")

    assert result.success is False
    assert result.error  # non-empty error message

    # Verify activate was never called → no state file was written.
    state = (
        fake_hermes_home / ".hermes" / "profiles" / "work" / "agentvault" / "state.json"
    )
    assert not state.exists()


@pytest.mark.asyncio
async def test_setup_times_out_when_approval_never_arrives(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """If the device stays PENDING through all poll attempts, setup fails cleanly.

    ``_patch_poll_fast`` zeroes the interval AND caps ``_POLL_MAX_ATTEMPTS`` at 5,
    so this exhausts the poll budget in well under a second.
    """
    _bootstrap_hermes_install(fake_hermes_home, monkeypatch)
    _patch_poll_fast(monkeypatch)
    _fake_profile_create(monkeypatch, fake_hermes_home)
    monkeypatch.setenv("AGENTVAULT_HERMES_API_URL", _API_URL)

    did = str(uuid.uuid4())
    async with respx.mock(base_url=_API_URL) as mock:
        mock.post("/api/v1/enroll").mock(
            return_value=Response(
                201,
                json={"device_id": did, "fingerprint": "fp_test", "status": "PENDING"},
            )
        )
        # Every poll returns PENDING — exhausts _POLL_MAX_ATTEMPTS (=5).
        mock.get(f"/api/v1/devices/{did}/status").mock(
            return_value=Response(
                200,
                json={"device_id": did, "status": "PENDING", "fingerprint": "fp_test"},
            )
        )
        # NOTE: no /activate handler — must never be called.
        result = await run_setup(token="av_tok_x", profile="work")

    assert result.success is False
    assert result.error  # non-empty error message

    state = (
        fake_hermes_home / ".hermes" / "profiles" / "work" / "agentvault" / "state.json"
    )
    assert not state.exists()


@pytest.mark.asyncio
async def test_setup_profile_seeds_model_and_env_from_default(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """End-to-end: a `setup --profile=work` run mirrors the default profile's
    `model:` block + `.env` so the customer doesn't hand-edit YAML.

    Regression guard for the 2026-05-24 smartcoder smoke: customer hit
    HTTP 400 ("No models provided") because `agentvault-hermes setup
    --profile=smartcoder` injected plugin entries but left `model:` empty.
    """
    _bootstrap_hermes_install(fake_hermes_home, monkeypatch)
    # Default-profile config + .env populated as a real Hermes user would have.
    default_cfg = fake_hermes_home / ".hermes" / "config.yaml"
    default_cfg.write_text(
        "model:\n"
        "  default: nvidia/nemotron-3-super-120b-a12b:free\n"
        "  provider: openrouter\n"
        "  base_url: https://openrouter.ai/api/v1\n"
        "  api_mode: chat_completions\n",
        encoding="utf-8",
    )
    (fake_hermes_home / ".hermes" / ".env").write_text(
        "OPENROUTER_API_KEY=sk-fake-test\n",
        encoding="utf-8",
    )

    _patch_poll_fast(monkeypatch)
    _fake_profile_create(monkeypatch, fake_hermes_home)
    monkeypatch.setenv("AGENTVAULT_HERMES_API_URL", _API_URL)

    async with respx.mock(base_url=_API_URL) as mock:
        _mock_backend(mock)
        result = await run_setup(token="av_tok_seed", profile="work")

    assert result.success, result.error

    profile_dir = fake_hermes_home / ".hermes" / "profiles" / "work"
    profile_cfg = profile_dir / "config.yaml"
    profile_env = profile_dir / ".env"

    from ruamel.yaml import YAML

    loaded = YAML().load(profile_cfg.read_text())
    # Mirrored model block from default
    assert loaded["model"]["default"] == "nvidia/nemotron-3-super-120b-a12b:free"
    assert loaded["model"]["provider"] == "openrouter"
    # AV plugin entries also present (model + plugin entries coexist)
    assert loaded["plugins"]["enabled"] == ["agentvault"]
    assert loaded["gateway"]["platforms"]["agentvault"]["enabled"] is True

    # Mirrored .env from default
    assert profile_env.read_text(encoding="utf-8") == "OPENROUTER_API_KEY=sk-fake-test\n"


def test_legacy_install_migrates(fake_hermes_home: Path) -> None:
    """Legacy ~/.hermes/agentvault/default/ layout migrates to the new flat layout."""
    # Seed the legacy directory structure.
    legacy = fake_hermes_home / ".hermes" / "agentvault" / "default"
    legacy.mkdir(parents=True)
    (legacy / "state.json").write_text(
        '{"version": 1, "device_id": "d1"}', encoding="utf-8"
    )

    migrate_legacy_layout()

    # Post-migration: state lives directly in agentvault/, not in agentvault/default/.
    migrated = resolve_data_dir() / "state.json"
    assert migrated.exists(), f"migrated state.json not found at {migrated}"
    assert json.loads(migrated.read_text())["device_id"] == "d1"
    assert not legacy.exists(), "legacy default/ dir should be removed after migration"
