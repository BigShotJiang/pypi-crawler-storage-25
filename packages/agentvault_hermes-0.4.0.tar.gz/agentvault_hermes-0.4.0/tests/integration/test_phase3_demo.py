"""Phase 3 acceptance demo — owner -> agent E2E via MLS over a mocked AV WS.

Source pattern: ``tests/integration/test_phase1_demo.py`` (Phase 1 enrollment
demo) for the integration-test convention; ``tests/unit/plugins/test_adapter.py``
for the ``sys.modules`` gateway-runtime patching pattern;
``tests/unit/transport/test_relay_send.py`` for the
``monkeypatch.setattr(relay_module, "WsClient", ...)`` call-site shape.

This test does NOT spin up a real Hermes runtime — that's manual verification
(see plan §M2). What it DOES prove, end-to-end through the production code
path (real ``Relay`` + real ``SecureChannel`` + real ``AgentVaultAdapter`` +
real ``MlsGroupState``), with only the WS transport + Hermes runtime types
mocked:

  1. ``AgentVaultAdapter.connect()`` opens a (mocked) WS and hydrates MLS
     states from disk.
  2. AV backend forwards an inbound ``message_mls`` envelope (hex
     ``payload`` + ``sender_device_id`` server-stamped per §3.7).
  3. The agent's ``_on_inbound`` is reached; the message_handler fires with
     the decrypted plaintext.
  4. ``adapter.send(...)`` encrypts and pushes an outbound envelope.
  5. The outbound envelope shape matches §3.7 / OC ``channel.ts:660-690``:
     ``event=="message_mls"``, ``payload`` is hex (NOT base64),
     ``group_id`` + ``epoch`` present, ``sender_device_id`` ABSENT.
  6. The owner's ``MlsGroupState.decrypt()`` on the agent's reply ciphertext
     returns the agent's plaintext.

Wire-format note: the Tier-3 spike at
``_spike/phase3_e2e/tier3_live_transport.py:49-102`` shipped a stand-in that
used base64 + a ``ciphertext`` field. That was wrong — §3.7 +
``channel/outbox.py`` are canonical: hex-encoded ``payload``. This test
exercises the canonical path.
"""
from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
import respx
from httpx import Response

# Gateway runtime mocks — installed BEFORE the adapter import below because
# the adapter imports from ``gateway.platforms.base`` / ``gateway.config`` /
# ``gateway.session`` at module load. The shared installer is the SINGLE
# SOURCE OF TRUTH for those fakes (DA WS-34 MAJOR-1 — duplicated
# definitions across test files invites silent drift).
from tests._fixtures.gateway_runtime import install_gateway_mocks

install_gateway_mocks()


# Module under test — imported AFTER gateway mocks are installed.
from agentvault_hermes.core.identity import (  # noqa: E402
    PersistedState,
    generate_device_keys,
    save_state,
)
from agentvault_hermes.core.transport import relay as relay_module  # noqa: E402
from agentvault_hermes.crypto import MlsGroupState, SigningKeypair  # noqa: E402
from agentvault_hermes.crypto.persistence import (  # noqa: E402
    ConversationMeta,
    write_meta,
)
from agentvault_hermes.plugins.agentvault import adapter as adapter_module  # noqa: E402
from agentvault_hermes.plugins.agentvault.adapter import AgentVaultAdapter  # noqa: E402


# ---------------------------------------------------------------------------
# Fixture
# ---------------------------------------------------------------------------


@pytest.fixture
def owner_and_agent(
    tmp_path: Path,
) -> tuple[
    MlsGroupState,
    MlsGroupState,
    uuid.UUID,
    uuid.UUID,
    uuid.UUID,
    Path,
    PersistedState,
]:
    """Build owner + agent ``MlsGroupState``s in a 1:1 group via Welcome.

    Persists the agent's MLS state + a ``ConversationMeta`` + the agent's
    ``state.json`` in the layout ``AgentVaultAdapter.connect()`` expects, so
    hydration finds them.
    """
    owner_dk = generate_device_keys()
    agent_dk = generate_device_keys()

    # SigningKeypair.private_key is the 32-byte Ed25519 seed (parity with
    # OC + the WS-25 lesson — DeviceKeys.signing_secret IS the seed; do NOT
    # refactor to 64-byte libsodium sk per
    # ``feedback_signing_keypair_seed_only_2026-05-10.md``).
    owner_signing = SigningKeypair(
        public_key=owner_dk.signing_public,
        private_key=owner_dk.signing_secret,
    )
    agent_signing = SigningKeypair(
        public_key=agent_dk.signing_public,
        private_key=agent_dk.signing_secret,
    )

    owner_device_id = uuid.uuid4()
    agent_device_id = uuid.uuid4()

    owner = MlsGroupState(device_keys=owner_signing, device_id=owner_device_id)
    agent = MlsGroupState(device_keys=agent_signing, device_id=agent_device_id)

    conv_id = uuid.uuid4()
    owner.create_group(conv_id.bytes)
    add_result = owner.add_members([agent.generate_key_package()])
    assert add_result.welcome is not None, (
        "first add_members must produce a Welcome for the joining agent"
    )
    agent.join_from_welcome(add_result.welcome)

    # Persist agent state in the layout AgentVaultAdapter expects:
    #   <data_dir>/state.json
    #   <data_dir>/conversations/<conv_id>/mls_state.bin
    #   <data_dir>/conversations/<conv_id>/meta.json
    account_dir = tmp_path / "agentvault-account"
    save_state(
        account_dir,
        PersistedState(
            device_id=str(agent_device_id),
            tenant_id="22222222-2222-2222-2222-222222222222",
            device_jwt="ey.fake.jwt",
            device_keys=agent_dk,
        ),
    )
    agent_state_blob = agent.export_state()
    persisted_state = PersistedState(
        device_id=str(agent_device_id),
        tenant_id="22222222-2222-2222-2222-222222222222",
        device_jwt="ey.fake.jwt",
        device_keys=agent_dk,
    )

    # write_meta creates the conversations/<conv_id>/ directory with mode
    # 0o700; we then drop mls_state.bin into it.
    write_meta(
        account_dir,
        conv_id,
        ConversationMeta(
            conversation_id=conv_id,
            type="direct",
            created_at=datetime.now(timezone.utc),
            last_message_ts=None,
        ),
    )
    bin_path = account_dir / "conversations" / str(conv_id) / "mls_state.bin"
    bin_path.write_bytes(agent_state_blob)

    return (
        owner,
        agent,
        owner_device_id,
        agent_device_id,
        conv_id,
        account_dir,
        persisted_state,
    )


# ---------------------------------------------------------------------------
# Test
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_phase3_demo_owner_to_agent_to_owner(
    owner_and_agent: tuple[
        MlsGroupState,
        MlsGroupState,
        uuid.UUID,
        uuid.UUID,
        uuid.UUID,
        Path,
        PersistedState,
    ],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Phase 3 design-doc deliverable: owner -> agent -> reply -> owner E2E.

    All six demo steps run through the production code path with only the
    WS transport (``WsClient``) and Hermes runtime types
    (``gateway.platforms.base`` etc.) mocked. ``Relay``, ``SecureChannel``,
    ``AgentVaultAdapter``, and both ``MlsGroupState`` instances are real.
    """
    (
        owner,
        _agent_state,  # owned by adapter after connect; not used directly
        owner_device_id,
        agent_device_id,
        conv_id,
        account_dir,
        _persisted_state,
    ) = owner_and_agent

    # --- Build a fake WS we control --------------------------------------
    fake_ws_outbox: list[dict[str, Any]] = []
    fake_ws_inbox: asyncio.Queue[dict[str, Any]] = asyncio.Queue()

    async def fake_send_json(payload: dict[str, Any]) -> None:
        fake_ws_outbox.append(payload)

    async def fake_receive_json() -> dict[str, Any]:
        return await fake_ws_inbox.get()

    fake_ws_instance = MagicMock(name="FakeWsClient")
    fake_ws_instance.send_json = AsyncMock(side_effect=fake_send_json)
    fake_ws_instance.receive_json = AsyncMock(side_effect=fake_receive_json)
    fake_ws_instance.__aenter__ = AsyncMock(return_value=fake_ws_instance)
    fake_ws_instance.__aexit__ = AsyncMock(return_value=None)
    # NOTE: ``Relay.disconnect()`` reaches the WS via ``__aexit__``, NOT a
    # ``close()`` method, so we don't stub one — DA WS-34 MINOR-4 (the dead
    # ``fake_ws_instance.close = AsyncMock()`` previously here was never
    # invoked).

    # CRITICAL: monkeypatch the call-site (``relay_module.WsClient``), NOT
    # ``core.transport.ws_client.WsClient``. ``Relay`` imported the symbol by
    # reference at module load (``from ... import WsClient``), so patching
    # the module where the class is *defined* is a silent no-op.
    fake_ws_ctor = MagicMock(name="FakeWsClientCtor", return_value=fake_ws_instance)
    monkeypatch.setattr(relay_module, "WsClient", fake_ws_ctor)

    # --- Patch profile resolution to use our tmp account -------------------
    from agentvault_hermes.core.config import ProfileConfig

    fake_profile_cfg = ProfileConfig(
        profile=None,
        data_dir=account_dir,
        api_url="http://av-test.example.com",
        agent_name="testagent",
        http_port=18790,
    )
    monkeypatch.setattr(adapter_module, "migrate_legacy_layout", lambda: None)
    monkeypatch.setattr(
        adapter_module, "resolve_profile", lambda _p=None: fake_profile_cfg
    )

    # --- Build the adapter -------------------------------------------------
    # The adapter no longer reads account_id from config; HERMES_HOME /
    # resolve_profile() is the single source of truth (Task 9).
    cfg = MagicMock()
    cfg.extra = {}
    adapter = AgentVaultAdapter(cfg)

    # --- Wire up a deterministic wait via asyncio.Event --------------------
    # NEVER ``asyncio.sleep(0.05)`` — that's flaky on slow CI runners.
    # The Event is set from inside the message_handler; we await it under a
    # 2.0s timeout (way more than enough for in-process work).
    delivered = asyncio.Event()
    received: list[Any] = []

    async def fake_handler(event: Any) -> None:
        received.append(event)
        delivered.set()

    adapter._message_handler = fake_handler

    # Mock the new HTTP endpoints that Stage 2 + Stage 3 added to
    # ``SecureChannel.start()`` (publish KP + pull delivery queue). Per
    # plan §3.3 Seam A + §3.3 ``_pull_delivery_queue``. Stage 5 will
    # rewrite this integration test with full Welcome-roundtrip respx
    # coverage; the simple stubs below just keep the demo green.
    # ``assert_all_called=False`` because the empty-pull path here means
    # the ack stub is registered defensively but won't fire — Stage 5
    # rewrites this with a full Welcome roundtrip.
    respx_mock = respx.mock(
        base_url="http://av-test.example.com", assert_all_called=False
    )
    respx_mock.post("/api/v1/mls/key-packages").mock(
        return_value=Response(
            200, json={"id": str(uuid.uuid4()), "device_id": str(agent_device_id)}
        )
    )
    respx_mock.get("/api/v1/mls/delivery").mock(
        return_value=Response(200, json={"messages": []})
    )
    respx_mock.post("/api/v1/mls/delivery/ack").mock(
        return_value=Response(200, json={"acked": 0})
    )
    respx_mock.start()

    try:
        # --- Step 1: connect ----------------------------------------------
        ok = await adapter.connect()
        assert ok is True
        assert str(conv_id) in adapter._mls_states, (
            "agent's MlsGroupState must be hydrated from disk on connect()"
        )
        assert adapter._secure_channel is not None
        # WsClient was constructed via the patched call-site. Lock the
        # exact kwargs signature so a future ``Relay`` change that adds a
        # new kwarg breaks loudly here instead of silently being absorbed
        # by the MagicMock's permissive accept-anything behavior. DA WS-34
        # MINOR-5.
        fake_ws_ctor.assert_called_once()
        assert fake_ws_ctor.call_args.args == ()
        ws_kwargs = fake_ws_ctor.call_args.kwargs
        assert set(ws_kwargs.keys()) == {"url", "device_jwt", "device_id"}, (
            f"WsClient kwargs drifted from the expected (url, device_jwt, "
            f"device_id) shape: got {sorted(ws_kwargs)}"
        )
        assert ws_kwargs["url"] == "ws://av-test.example.com/api/v1/ws"
        assert ws_kwargs["device_jwt"] == "ey.fake.jwt"
        assert ws_kwargs["device_id"] == str(agent_device_id)

        # --- Step 2: simulate the AV backend forwarding owner's message ----
        # Owner encrypts FIRST so we read epoch AFTER the encrypt advances
        # the ratchet (DA prior #7 — epoch staleness). The inbound ``epoch``
        # field is informational on the agent side anyway (the agent's
        # MlsGroupState tracks epoch internally on decrypt), but reading it
        # post-encrypt keeps the wire envelope honest.
        plaintext_owner = b"hello agent, please reply"
        cipher_owner = owner.encrypt(plaintext_owner)
        owner_epoch_after_encrypt = owner.epoch

        inbound_data: dict[str, Any] = {
            "conversation_id": str(conv_id),
            "group_id": str(conv_id),  # 1:1 demo: group_id == conv_id
            "sender_device_id": str(owner_device_id),  # server-stamped per §3.7
            "payload": cipher_owner.hex(),  # hex per §3.7 (NOT base64)
            "epoch": owner_epoch_after_encrypt,
            "message_type": "text",
            "message_id": str(uuid.uuid4()),  # server-assigned
            "created_at": "2026-05-10T20:00:00Z",
        }
        await fake_ws_inbox.put({"event": "message_mls", "data": inbound_data})

        # --- Step 3: agent receives + decrypts ----------------------------
        # ``asyncio.Event`` + ``wait_for`` is the deterministic pattern; the
        # 2.0s cap is a safety bound — in-process delivery is a few ms.
        await asyncio.wait_for(delivered.wait(), timeout=2.0)
        assert len(received) == 1
        event = received[0]
        # The handler got a MessageEvent (faked at module load). UTF-8
        # decode happens in ``inbox.handle_message_mls`` (with
        # ``errors="replace"`` per ``inbox.py``); the adapter's
        # ``_on_inbound`` then passes ``msg.plaintext`` (already a ``str``)
        # straight through to ``MessageEvent.text``. DA WS-34 MAJOR-2 — the
        # earlier "the adapter decoded the plaintext" comment was wrong.
        assert event.text == plaintext_owner.decode("utf-8")
        assert event.source.chat_id == str(conv_id)
        assert event.source.user_id == str(owner_device_id)

        # --- Step 4: agent replies ----------------------------------------
        result = await adapter.send(
            chat_id=str(conv_id), content="hello back from agent"
        )
        assert result.success is True

        # --- Step 5: outbound envelope shape per §3.7 ---------------------
        # Exactly ONE ``message_mls`` frame on the wire — the agent's reply.
        # Phase 4a PR-2 also emits an ``mls_sync`` frame on connect (one per
        # known group with intact local state); filter to ``message_mls``
        # so this assertion stays focused on the reply envelope.
        message_frames = [
            f for f in fake_ws_outbox if f.get("event") == "message_mls"
        ]
        assert len(message_frames) == 1, (
            f"Expected exactly 1 message_mls frame; got {len(message_frames)}: "
            f"{message_frames}"
        )
        out_env = message_frames[0]
        assert out_env["event"] == "message_mls"

        out_data = out_env["data"]
        assert out_data["conversation_id"] == str(conv_id)
        # Required outbound fields per §3.7 / OC channel.ts:660-690:
        assert "group_id" in out_data, "outbound MUST include group_id"
        assert "epoch" in out_data and isinstance(out_data["epoch"], int), (
            "outbound MUST include epoch as int"
        )
        assert "payload" in out_data, "outbound MUST include payload"
        # The Tier-3 spike (`_spike/phase3_e2e/tier3_live_transport.py:49-102`)
        # shipped a stand-in that used base64 + a ``ciphertext`` field. The
        # canonical wire shape is hex-encoded ``payload`` per ``ws.py:1063-1082``
        # and ``channel/outbox.py``. ``bytes.fromhex`` proves we're on the
        # canonical path.
        cipher_back = bytes.fromhex(out_data["payload"])
        # Backend stamps ``sender_device_id`` from the authenticated WS
        # session — the agent does NOT include it on outbound (§3.7).
        assert "sender_device_id" not in out_data, (
            "outbound MUST NOT include sender_device_id; backend stamps it"
        )

        # --- Step 6: owner decrypts the agent's reply ---------------------
        decrypt_result = owner.decrypt(cipher_back)
        assert decrypt_result.is_handshake is False
        assert decrypt_result.plaintext == b"hello back from agent"
    finally:
        # Clean up — even on assertion failure — so background tasks
        # (demux, silence-timeout, stubs) don't leak across the test
        # boundary. ``disconnect`` is idempotent.
        await adapter.disconnect()
        respx_mock.stop()
