"""Integration test for the doctor command."""
from __future__ import annotations

import json
import os
from pathlib import Path

import pytest
import respx

from agentvault_hermes.cli.doctor import (
    _check_gateway_platform,
    _check_mls_state,
    run_doctor,
)
from agentvault_hermes.core.identity.credentials import save_state, PersistedState
from agentvault_hermes.core.identity.device import generate_device_keys


def _setup_state(fake_hermes_home: Path) -> Path:
    data_dir = fake_hermes_home / ".hermes" / "agentvault"
    data_dir.mkdir(parents=True)
    keys = generate_device_keys()
    save_state(
        data_dir,
        PersistedState(
            device_id="dev_test",
            tenant_id="tenant_test",
            device_jwt="ey.test.jwt",
            device_keys=keys,
        ),
    )
    return data_dir


def _write_valid_hermes_config(fake_hermes_home: Path) -> Path:
    """Write a config.yaml with both required keys for gateway_platform."""
    cfg_path = fake_hermes_home / ".hermes" / "config.yaml"
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    cfg_path.write_text(
        "plugins:\n"
        "  enabled:\n"
        "    - agentvault\n"
        "gateway:\n"
        "  platforms:\n"
        "    agentvault:\n"
        "      enabled: true\n"
    )
    return cfg_path


@pytest.mark.asyncio
async def test_doctor_all_green_when_state_exists_and_backend_healthy(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
):
    _setup_state(fake_hermes_home)
    _write_valid_hermes_config(fake_hermes_home)
    monkeypatch.setenv("AGENTVAULT_HERMES_API_URL", "https://api.test.example.com")

    async with respx.mock(base_url="https://api.test.example.com") as mock:
        mock.get("/health").respond(json={"status": "ok"})

        result = await run_doctor()

    assert result.all_green
    assert result.checks["configuration"] == "PASS"
    assert result.checks["connectivity"] == "PASS"
    assert result.checks["gateway_platform"] == "PASS"
    assert result.checks["mls_state"] == "PASS"


@pytest.mark.asyncio
async def test_doctor_fails_when_no_state(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setenv("AGENTVAULT_HERMES_API_URL", "https://api.test.example.com")

    result = await run_doctor()

    assert not result.all_green
    assert result.checks["configuration"] == "FAIL"


@pytest.mark.asyncio
async def test_doctor_warns_when_backend_unreachable(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
):
    _setup_state(fake_hermes_home)
    monkeypatch.setenv("AGENTVAULT_HERMES_API_URL", "https://api.unreachable.example.com")

    result = await run_doctor()

    assert not result.all_green
    assert result.checks["connectivity"] == "FAIL"


@pytest.mark.asyncio
async def test_doctor_reports_oc_coexistence(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
):
    _setup_state(fake_hermes_home)
    (fake_hermes_home / ".openclaw" / "agentvault").mkdir(parents=True)
    monkeypatch.setenv("AGENTVAULT_HERMES_API_URL", "https://api.test.example.com")

    async with respx.mock(base_url="https://api.test.example.com") as mock:
        mock.get("/health").respond(json={"status": "ok"})
        result = await run_doctor()

    assert "openclaw" in result.checks
    assert result.checks["openclaw"] == "DETECTED"


@pytest.mark.asyncio
async def test_doctor_continues_when_gateway_platform_check_raises(
    fake_hermes_home: Path, monkeypatch: pytest.MonkeyPatch
):
    """Regression — DA WS-32+35 MAJOR-2.

    If ``_check_gateway_platform`` raises (e.g. ``PermissionError`` reading
    a 0600 config the doctor user can't access), the whole doctor must NOT
    crash — ``mls_state`` and earlier checks still run, and the failing
    check downgrades to FAIL with a one-line message rather than escaping
    the run as an unhandled exception.
    """
    _setup_state(fake_hermes_home)
    monkeypatch.setenv("AGENTVAULT_HERMES_API_URL", "https://api.test.example.com")

    def _raise_permission_error(*_args: object, **_kwargs: object) -> tuple[bool, str]:
        raise PermissionError("EACCES")

    monkeypatch.setattr(
        "agentvault_hermes.cli.doctor._check_gateway_platform",
        _raise_permission_error,
    )

    async with respx.mock(base_url="https://api.test.example.com") as mock:
        mock.get("/health").respond(json={"status": "ok"})
        result = await run_doctor()

    # Whole run completed despite the raised exception.
    assert result.checks["gateway_platform"] == "FAIL"
    # Downstream check still ran.
    assert "mls_state" in result.checks


# ---------------------------------------------------------------------------
# _check_gateway_platform — WS-35
# ---------------------------------------------------------------------------


def test_gateway_platform_missing_config(tmp_path: Path) -> None:
    cfg = tmp_path / "config.yaml"
    ok, msg = _check_gateway_platform(cfg)
    assert ok is False
    assert "Hermes config missing" in msg


def test_gateway_platform_no_plugins_enabled(tmp_path: Path) -> None:
    cfg = tmp_path / "config.yaml"
    cfg.write_text("gateway:\n  platforms:\n    agentvault:\n      enabled: true\n")
    ok, msg = _check_gateway_platform(cfg)
    assert ok is False
    assert "agentvault not in plugins.enabled" in msg


def test_gateway_platform_missing_gateway_block(tmp_path: Path) -> None:
    cfg = tmp_path / "config.yaml"
    cfg.write_text("plugins:\n  enabled:\n    - agentvault\n")
    ok, msg = _check_gateway_platform(cfg)
    assert ok is False
    assert "gateway.platforms.agentvault.enabled" in msg


def test_gateway_platform_gateway_block_disabled(tmp_path: Path) -> None:
    cfg = tmp_path / "config.yaml"
    cfg.write_text(
        "plugins:\n"
        "  enabled:\n"
        "    - agentvault\n"
        "gateway:\n"
        "  platforms:\n"
        "    agentvault:\n"
        "      enabled: false\n"
    )
    ok, msg = _check_gateway_platform(cfg)
    assert ok is False
    assert "gateway.platforms.agentvault.enabled" in msg


def test_gateway_platform_happy_path(tmp_path: Path) -> None:
    cfg = tmp_path / "config.yaml"
    cfg.write_text(
        "plugins:\n"
        "  enabled:\n"
        "    - agentvault\n"
        "gateway:\n"
        "  platforms:\n"
        "    agentvault:\n"
        "      enabled: true\n"
    )
    ok, msg = _check_gateway_platform(cfg)
    assert ok is True
    assert "enabled and importable" in msg


def test_gateway_platform_plugin_not_importable(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    cfg = tmp_path / "config.yaml"
    cfg.write_text(
        "plugins:\n"
        "  enabled:\n"
        "    - agentvault\n"
        "gateway:\n"
        "  platforms:\n"
        "    agentvault:\n"
        "      enabled: true\n"
    )

    # Simulate a system where the plugin's setuptools entry point isn't
    # registered (e.g. user installed the wheel by extracting it manually
    # rather than via pip).
    def fake_entry_points(*, group: str) -> list[object]:
        return []

    monkeypatch.setattr(
        "agentvault_hermes.cli.doctor.importlib.metadata.entry_points",
        fake_entry_points,
    )

    ok, msg = _check_gateway_platform(cfg)
    assert ok is False
    assert "plugin not importable" in msg


def test_gateway_platform_malformed_yaml(tmp_path: Path) -> None:
    cfg = tmp_path / "config.yaml"
    # ruamel.yaml chokes on this: opening bracket with no close.
    cfg.write_text("plugins: [unterminated\n  enabled:\n")
    ok, msg = _check_gateway_platform(cfg)
    assert ok is False
    assert "could not parse Hermes config" in msg
    # No traceback / Python exception class names should leak through.
    assert "Traceback" not in msg


def test_gateway_platform_yaml_parses_to_non_dict(tmp_path: Path) -> None:
    """Regression — DA WS-32+35 CRITICAL-2.

    ruamel.yaml will parse a top-level scalar (e.g. `"just a string"`) into
    a string rather than a dict. Without an explicit ``isinstance(config,
    dict)`` guard, the next ``.get`` would raise AttributeError and the
    doctor would surface a Python traceback to the user instead of a clean
    one-line FAIL.
    """
    cfg = tmp_path / "config.yaml"
    cfg.write_text("just a top-level string\n")
    ok, msg = _check_gateway_platform(cfg)
    assert ok is False
    assert "not a YAML mapping" in msg
    assert "Traceback" not in msg


def test_gateway_platform_plugins_key_is_a_scalar(tmp_path: Path) -> None:
    """Regression — DA WS-32+35 CRITICAL-2 (sub-section variant).

    If the user's config has ``plugins: agentvault`` (scalar instead of
    mapping), the doctor must report the shape error cleanly rather than
    crashing on ``.get("enabled")``.
    """
    cfg = tmp_path / "config.yaml"
    cfg.write_text("plugins: agentvault\n")
    ok, msg = _check_gateway_platform(cfg)
    assert ok is False
    assert "'plugins'" in msg and "mapping" in msg
    assert "Traceback" not in msg


# ---------------------------------------------------------------------------
# _check_mls_state — WS-35
# ---------------------------------------------------------------------------


def test_mls_state_no_conversations_dir(tmp_path: Path) -> None:
    ok, msg = _check_mls_state(tmp_path)
    assert ok is True
    assert "no conversations" in msg


def test_mls_state_empty_conversations_dir(tmp_path: Path) -> None:
    (tmp_path / "conversations").mkdir()
    ok, msg = _check_mls_state(tmp_path)
    assert ok is True
    assert "0 conversation" in msg


def test_mls_state_one_healthy(tmp_path: Path) -> None:
    conv = tmp_path / "conversations" / "conv-aaa"
    conv.mkdir(parents=True)
    (conv / "mls_state.bin").write_bytes(b"\x00\x01\x02\x03")
    (conv / "meta.json").write_text(json.dumps({"epoch": 0, "members": []}))
    ok, msg = _check_mls_state(tmp_path)
    assert ok is True
    assert "1 conversation" in msg
    assert "healthy" in msg


def test_mls_state_missing_blob(tmp_path: Path) -> None:
    conv = tmp_path / "conversations" / "conv-aaa"
    conv.mkdir(parents=True)
    (conv / "meta.json").write_text(json.dumps({}))
    ok, msg = _check_mls_state(tmp_path)
    assert ok is False
    assert "missing mls_state.bin" in msg


def test_mls_state_empty_blob(tmp_path: Path) -> None:
    conv = tmp_path / "conversations" / "conv-aaa"
    conv.mkdir(parents=True)
    (conv / "mls_state.bin").write_bytes(b"")
    (conv / "meta.json").write_text(json.dumps({}))
    ok, msg = _check_mls_state(tmp_path)
    assert ok is False
    assert "empty mls_state.bin" in msg


def test_mls_state_malformed_meta(tmp_path: Path) -> None:
    conv = tmp_path / "conversations" / "conv-aaa"
    conv.mkdir(parents=True)
    (conv / "mls_state.bin").write_bytes(b"\x00\x01")
    (conv / "meta.json").write_text("{not valid json")
    ok, msg = _check_mls_state(tmp_path)
    assert ok is False
    assert "meta.json malformed" in msg


def test_mls_state_skips_ds_store(tmp_path: Path) -> None:
    """DA-driven: macOS Finder drops .DS_Store files into directories. They
    are not directories, so iterdir() picks them up but is_dir() filters them."""
    conv_root = tmp_path / "conversations"
    conv_root.mkdir()
    (conv_root / ".DS_Store").write_bytes(b"\x00\x00")  # not a dir
    conv = conv_root / "conv-aaa"
    conv.mkdir()
    (conv / "mls_state.bin").write_bytes(b"\x00\x01")
    (conv / "meta.json").write_text(json.dumps({}))
    ok, msg = _check_mls_state(tmp_path)
    assert ok is True
    # Count is 1 (the real conv), not 2 — .DS_Store was skipped.
    assert "1 conversation" in msg


def test_mls_state_follows_symlinked_conv_dir(tmp_path: Path) -> None:
    """DA-driven: Path.iterdir() follows symlinks by default, and a symlinked
    conversation directory is a legitimate Hermes layout (e.g. a user moves
    state to external storage and symlinks back). Validate it like any other
    entry. This documents current behavior; if it changes the test should
    be updated alongside the code change.
    """
    real_conv = tmp_path / "real_conv"
    real_conv.mkdir()
    (real_conv / "mls_state.bin").write_bytes(b"\x00\x01")
    (real_conv / "meta.json").write_text(json.dumps({}))

    conv_root = tmp_path / "conversations"
    conv_root.mkdir()
    link = conv_root / "linked_conv"
    try:
        os.symlink(real_conv, link, target_is_directory=True)
    except (OSError, NotImplementedError):
        pytest.skip("symlinks unsupported on this platform")

    ok, msg = _check_mls_state(tmp_path)
    assert ok is True
    assert "1 conversation" in msg
