"""Integration tests — A2A messaging end-to-end (action #238, Slice A).

Mirrors test_room_welcome_to_message_roundtrip.py: real MlsGroupState +
SigningKeypair, respx HTTP intercepts, an in-memory _MockedRelay. Exercises
the full A2A member path — invite -> KeyPackage publish -> creator founds the
group + welcomes -> Welcome join -> A2A message decrypt -> surfaced with
a2a_channel_id + from_hub_address -> reply via a2a_message_mls -- plus
connect-time reconciliation recovering a channel known only from the poll.

Note: connect-time reconciliation hits GET /api/v1/a2a/channels. That backend
endpoint was hardened to accept device JWTs in PR #232; until #232 deploys to
prod the REST reconcile-poll returns 401 there. The plugin-side wiring is
proven end-to-end here against respx mocks.
"""
from __future__ import annotations

import asyncio
import uuid
from typing import Any, AsyncIterator, Optional
from unittest.mock import AsyncMock

import pytest
import respx
from httpx import Response

from agentvault_hermes.channel.outbox import WireEnvelope
from agentvault_hermes.channel.secure_channel import SecureChannel
from agentvault_hermes.crypto import MlsGroupState, SigningKeypair

_BASE_URL = "http://av-test.example.com"
_BOB_DEVICE_ID = uuid.UUID("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
_ALICE_DEVICE_ID = uuid.UUID("bbbbbbbb-cccc-dddd-eeee-ffffffffffff")
_A2A_CHANNEL_ID = "33333333-3333-3333-3333-333333333333"
_ALICE_HUB = "alice-hub-1"


def _make_keys() -> SigningKeypair:
    import nacl.signing

    sk = nacl.signing.SigningKey.generate()
    return SigningKeypair(public_key=bytes(sk.verify_key), private_key=bytes(sk))


class _MockedRelay:
    """In-memory Relay — same shape as the room roundtrip test."""

    def __init__(self) -> None:
        self.rest_base_url = _BASE_URL
        self.device_jwt = "test-jwt-bob"
        self.device_id = str(_BOB_DEVICE_ID)
        self._inbound: asyncio.Queue[Optional[WireEnvelope]] = asyncio.Queue()
        self.connect = AsyncMock()
        self.disconnect = AsyncMock()
        self.send_message = AsyncMock()
        self.send_pong = AsyncMock()
        self.send_json = AsyncMock()

    async def receive_messages(self) -> AsyncIterator[WireEnvelope]:
        while True:
            env = await self._inbound.get()
            if env is None:
                return
            yield env

    async def push_inbound(self, env: WireEnvelope) -> None:
        await self._inbound.put(env)

    async def shutdown(self) -> None:
        await self._inbound.put(None)


async def _wait_until(predicate: Any, *, timeout: float = 2.0) -> None:
    deadline = asyncio.get_event_loop().time() + timeout
    while not predicate():
        if asyncio.get_event_loop().time() > deadline:
            raise AssertionError(f"_wait_until: predicate stayed falsy for {timeout}s")
        await asyncio.sleep(0.01)


def _invited_envelope() -> WireEnvelope:
    return WireEnvelope(
        event="a2a_channel_invited",
        data={
            "channel_id": _A2A_CHANNEL_ID,
            "conversation_id": "conv-a2a-1",
            "role": "member",
            "participants": [
                {"hub_id": _ALICE_HUB, "hub_address": "hub://alice",
                 "status": "active"},
            ],
        },
    )


def _welcome_row(alice: MlsGroupState, welcome_hex: str) -> dict[str, Any]:
    return {
        "queue_id": "q-a2a-welcome",
        "message_id": str(uuid.uuid4()),
        "group_id": str(uuid.UUID(bytes=alice.group_id)),
        "message_type": "welcome",
        "sender_device_id": str(_ALICE_DEVICE_ID),
        "epoch": 0,
        "payload": welcome_hex,
        "room_id": None,
        "conversation_id": None,
        "a2a_channel_id": _A2A_CHANNEL_ID,
        "conversation_group_id": None,
        "created_at": "2026-05-22T00:00:01Z",
    }


def _app_row(alice: MlsGroupState, ciphertext_hex: str, queue_id: str) -> dict[str, Any]:
    return {
        "queue_id": queue_id,
        "message_id": str(uuid.uuid4()),
        "group_id": str(uuid.UUID(bytes=alice.group_id)),
        "message_type": "application",
        "sender_device_id": str(_ALICE_DEVICE_ID),
        "epoch": alice.epoch,
        "payload": ciphertext_hex,
        "room_id": None,
        "conversation_id": None,
        "a2a_channel_id": _A2A_CHANNEL_ID,
        "conversation_group_id": None,
        "from_hub_address": "hub://alice",
        "created_at": "2026-05-22T00:00:02Z",
    }


def _make_channel(tmp_path: Any, relay: _MockedRelay, on_inbound: Any) -> SecureChannel:
    return SecureChannel(
        relay=relay,  # type: ignore[arg-type]
        mls_states={},
        on_inbound=on_inbound,
        data_dir=tmp_path,
        device_keys=_make_keys(),
        device_id=_BOB_DEVICE_ID,
        agent_name="bob-agent",
        account_id="acct-bob",
    )


def _respx_intercepts(mock: Any, captured_kp_hex: list[str],
                       pull_response: dict[str, Any], acked: list[str],
                       a2a_channels: list[dict[str, Any]]) -> None:
    async def capture_publish(request: Any) -> Response:
        import json

        captured_kp_hex.append(json.loads(request.read())["key_package"])
        return Response(200, json={"id": str(uuid.uuid4()),
                                   "device_id": str(_BOB_DEVICE_ID)})

    async def respond_pull(request: Any) -> Response:
        return Response(200, json=pull_response)

    async def respond_ack(request: Any) -> Response:
        import json

        ids = json.loads(request.read()).get("queue_ids", [])
        acked.extend(ids)
        return Response(200, json={"acked": len(ids)})

    mock.post("/api/v1/mls/key-packages").mock(side_effect=capture_publish)
    mock.get("/api/v1/rooms").mock(return_value=Response(200, json=[]))
    mock.get("/api/v1/a2a/channels").mock(
        return_value=Response(200, json=a2a_channels)
    )
    mock.get("/api/v1/mls/delivery").mock(side_effect=respond_pull)
    mock.post("/api/v1/mls/delivery/ack").mock(side_effect=respond_ack)


@pytest.mark.asyncio
async def test_a2a_invite_welcome_message_roundtrip_and_reply(tmp_path: Any) -> None:
    """Bob is invited to an A2A channel, publishes a KeyPackage, joins via the
    creator's Welcome, receives an A2A message surfaced with a2a_channel_id +
    from_hub_address, and replies via an a2a_message_mls envelope."""
    captured_kp_hex: list[str] = []
    pull_response: dict[str, Any] = {"messages": []}
    acked: list[str] = []
    alice_keys = _make_keys()
    relay = _MockedRelay()
    received: list[Any] = []
    delivered = asyncio.Event()

    async def on_inbound(msg: Any) -> None:
        received.append(msg)
        delivered.set()

    ch = _make_channel(tmp_path, relay, on_inbound)

    async with respx.mock(base_url=_BASE_URL, assert_all_called=False) as mock:
        _respx_intercepts(mock, captured_kp_hex, pull_response, acked, [])
        await ch.start()
        try:
            # Invite: Bob upserts the channel and publishes a KeyPackage.
            await relay.push_inbound(_invited_envelope())
            await _wait_until(lambda: ch._a2a_registry.get(_A2A_CHANNEL_ID) is not None)
            await _wait_until(lambda: len(captured_kp_hex) >= 1)

            # Creator side (synthesized): Alice founds the MLS group and adds
            # Bob using the REAL KeyPackage Bob published (non-gameable id).
            alice = MlsGroupState(device_keys=alice_keys, device_id=_ALICE_DEVICE_ID)
            alice.create_group(b"\x53" * 16)
            add_result = alice.add_members([bytes.fromhex(captured_kp_hex[0])])
            assert add_result.welcome is not None

            # Welcome arrives via the delivery queue.
            pull_response["messages"] = [_welcome_row(alice, add_result.welcome.hex())]
            await relay.push_inbound(WireEnvelope(event="mls_delivery", data={"count": 1}))
            await _wait_until(lambda: _A2A_CHANNEL_ID in ch._mls_states)

            # Non-gameable identity check: consumer group_id IS producer's.
            assert ch._mls_states[_A2A_CHANNEL_ID].group_id == alice.group_id

            def _entry_has_group() -> bool:
                entry = ch._a2a_registry.get(_A2A_CHANNEL_ID)
                return entry is not None and entry.mls_group_id is not None

            await _wait_until(_entry_has_group)

            # Alice sends an A2A application message.
            ciphertext = alice.encrypt(b"need a hand?")
            pull_response["messages"] = [_app_row(alice, ciphertext.hex(), "q-a2a-app")]
            await relay.push_inbound(WireEnvelope(event="mls_delivery", data={"count": 1}))
            await asyncio.wait_for(delivered.wait(), timeout=2.0)

            assert received, "on_inbound was never called for the A2A message"
            inbound = received[0]
            assert inbound.a2a_channel_id == _A2A_CHANNEL_ID
            assert inbound.from_hub_address == "hub://alice"
            assert inbound.plaintext == "need a hand?"  # no [sender]: prefix

            # Bob replies into the channel.
            await ch.send(conversation_id=_A2A_CHANNEL_ID, plaintext=b"on it")
            relay.send_message.assert_awaited()
            assert relay.send_message.await_args.kwargs["a2a_channel_id"] == _A2A_CHANNEL_ID
        finally:
            await relay.shutdown()
            await ch.stop()


@pytest.mark.asyncio
async def test_a2a_connect_reconcile_recovers_unjoined_channel(tmp_path: Any) -> None:
    """A channel known only from the GET /api/v1/a2a/channels poll (its invite
    event was never received) with no local MLS group triggers a KeyPackage
    publish and a Welcome re-request during connect-time reconciliation.

    Backend dependency note: GET /api/v1/a2a/channels accepts device JWTs only
    after PR #232 deploys to prod. The test mocks the endpoint with respx, so
    plugin-side wiring is exercised independent of the backend's auth state.
    """
    captured_kp_hex: list[str] = []
    pull_response: dict[str, Any] = {"messages": []}
    acked: list[str] = []
    relay = _MockedRelay()
    requested_welcome_groups: list[str] = []

    a2a_channels = [{
        "channel_id": _A2A_CHANNEL_ID,
        "conversation_id": "conv-a2a-1",
        "role": "member",
        "participants": [],
    }]

    async def on_inbound(msg: Any) -> None:
        pass

    ch = _make_channel(tmp_path, relay, on_inbound)

    async with respx.mock(base_url=_BASE_URL, assert_all_called=False) as mock:
        _respx_intercepts(mock, captured_kp_hex, pull_response, acked, a2a_channels)
        mock.get(f"/api/v1/mls/a2a/{_A2A_CHANNEL_ID}/group").mock(
            return_value=Response(200, json={"group_id": "group-xyz"})
        )

        async def capture_request_welcome(request: Any) -> Response:
            requested_welcome_groups.append("group-xyz")
            return Response(200, json={"ok": True})

        mock.post("/api/v1/mls/groups/group-xyz/request-welcome").mock(
            side_effect=capture_request_welcome
        )
        await ch.start()
        try:
            # connect-time reconciliation runs during start(): the channel is
            # discovered from the poll and, being not-joined, recovered.
            await _wait_until(
                lambda: ch._a2a_registry.get(_A2A_CHANNEL_ID) is not None
            )
            await _wait_until(lambda: len(captured_kp_hex) >= 1)
            await _wait_until(lambda: requested_welcome_groups == ["group-xyz"])
        finally:
            await relay.shutdown()
            await ch.stop()
