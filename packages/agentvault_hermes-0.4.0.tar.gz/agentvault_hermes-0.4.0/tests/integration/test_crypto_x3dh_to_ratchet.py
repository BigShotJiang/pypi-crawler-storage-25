"""Integration: X3DH bootstrap → Double Ratchet initialization → bidirectional exchange.

Phase 2 plan §4282-4382 originally prescribed this scenario but with a
DoubleRatchet API that doesn't exist (`peer_dh_public=`, `my_dh_keypair=`,
`my_signing_keypair=`, `peer_signing_public=`). The actual API is
``init_initiator(shared_secret, identity_keypair, peer_identity_public_key=None)``
and ``init_receiver(...)`` — the DH ratchet bootstrap is lazy. These tests
use the real API; the conceptual scenario (full bootstrap, bidirectional
exchange, serialize-during-active-session) is preserved.

Cross-module surface exercised:
    crypto.x3dh.perform_x3dh    →  shared_secret
    crypto.ratchet.DoubleRatchet.init_initiator/init_receiver  ← shared_secret
    encrypt/decrypt round-trip with serialize/deserialize in the middle
"""
from __future__ import annotations

import os
import random

from nacl import signing as nacl_signing
from nacl.public import PrivateKey

from agentvault_hermes.crypto.ratchet import (
    DoubleRatchet,
    SigningKeypair,
)
from agentvault_hermes.crypto.x3dh import X3DHParams, perform_x3dh


def _signing_keypair() -> SigningKeypair:
    sk = nacl_signing.SigningKey.generate()
    return SigningKeypair(public_key=bytes(sk.verify_key), private_key=bytes(sk))


def _x25519_keypair() -> tuple[bytes, bytes]:
    """Return (private, public) for a fresh X25519 keypair."""
    sk = PrivateKey.generate()
    return bytes(sk), bytes(sk.public_key)


def test_x3dh_to_ratchet_full_bootstrap_and_bidirectional_exchange() -> None:
    """Full X3DH handshake → DR init → bidirectional message exchange.

    Both parties derive the same X3DH shared secret, then bootstrap their
    Double Ratchets from it. Alice (initiator) sends 50 messages, Bob
    (receiver) decrypts. Then roles flip — Bob sends, Alice decrypts —
    exercising the DH-ratchet rotation that happens on direction-change.
    """
    # X3DH handshake: each side has Ed25519 identity + X25519 ephemeral.
    a_id = _signing_keypair()
    a_eph_priv, a_eph_pub = _x25519_keypair()
    b_id = _signing_keypair()
    b_eph_priv, b_eph_pub = _x25519_keypair()

    a_shared = perform_x3dh(X3DHParams(
        my_identity_private=a_id.private_key,
        my_ephemeral_private=a_eph_priv,
        their_identity_public=b_id.public_key,
        their_ephemeral_public=b_eph_pub,
        is_initiator=True,
    ))
    b_shared = perform_x3dh(X3DHParams(
        my_identity_private=b_id.private_key,
        my_ephemeral_private=b_eph_priv,
        their_identity_public=a_id.public_key,
        their_ephemeral_public=a_eph_pub,
        is_initiator=False,
    ))
    # Sanity: X3DH symmetry
    assert a_shared == b_shared
    assert len(a_shared) == 32

    # Bootstrap ratchets from the shared secret. Per ratchet.py, init_initiator
    # only takes (shared_secret, identity_keypair, peer_identity_public_key);
    # the DH ratchet step is lazy (happens inside encrypt/decrypt).
    rt_a = DoubleRatchet.init_initiator(
        shared_secret=a_shared,
        identity_keypair=a_id,
        peer_identity_public_key=b_id.public_key,
    )
    rt_b = DoubleRatchet.init_receiver(
        shared_secret=b_shared,
        identity_keypair=b_id,
        peer_identity_public_key=a_id.public_key,
    )

    # Direction 1: Alice sends 50 messages in order; Bob decrypts in order.
    a_to_b = [rt_a.encrypt(f"a-{i}".encode()) for i in range(50)]
    for i, msg in enumerate(a_to_b):
        plaintext = rt_b.decrypt(msg)
        assert plaintext == f"a-{i}".encode()

    # Direction 2: Bob sends 50 messages back. Bob's first encrypt triggers
    # a DH ratchet step (his sending chain was None until now); Alice's
    # first decrypt of Bob's message triggers a matching DH ratchet step
    # on her receiving side.
    b_to_a = [rt_b.encrypt(f"b-{i}".encode()) for i in range(50)]
    for i, msg in enumerate(b_to_a):
        plaintext = rt_a.decrypt(msg)
        assert plaintext == f"b-{i}".encode()


def test_x3dh_to_ratchet_out_of_order_delivery() -> None:
    """X3DH bootstrap, then 20 in-order encrypts followed by shuffled decrypts.

    Exercises the skipped-keys cache on the receiver side. Once the receiver
    sees a higher message_number, intermediate keys get stashed so later
    out-of-order deliveries can still decrypt. MAX_SKIP=1000 bounds the cache.
    """
    a_id = _signing_keypair()
    a_eph_priv, a_eph_pub = _x25519_keypair()
    b_id = _signing_keypair()
    b_eph_priv, b_eph_pub = _x25519_keypair()

    a_shared = perform_x3dh(X3DHParams(
        my_identity_private=a_id.private_key,
        my_ephemeral_private=a_eph_priv,
        their_identity_public=b_id.public_key,
        their_ephemeral_public=b_eph_pub,
        is_initiator=True,
    ))
    b_shared = perform_x3dh(X3DHParams(
        my_identity_private=b_id.private_key,
        my_ephemeral_private=b_eph_priv,
        their_identity_public=a_id.public_key,
        their_ephemeral_public=a_eph_pub,
        is_initiator=False,
    ))
    assert a_shared == b_shared

    rt_a = DoubleRatchet.init_initiator(
        shared_secret=a_shared,
        identity_keypair=a_id,
        peer_identity_public_key=b_id.public_key,
    )
    rt_b = DoubleRatchet.init_receiver(
        shared_secret=b_shared,
        identity_keypair=b_id,
        peer_identity_public_key=a_id.public_key,
    )

    # Alice encrypts 100 messages; Bob receives them in shuffled order.
    # 100 (not 20) per plan §4283 + §4309: stresses _skip_message_keys cache
    # under realistic load. Seed 42's shuffle starts with index 19, forcing
    # Bob to stash 19 skipped keys upfront on the first decrypt — and then
    # progressively grows. MAX_SKIP=1000 keeps this safely below the cap.
    msgs = [(i, rt_a.encrypt(f"m-{i}".encode())) for i in range(100)]
    shuffled = list(msgs)
    random.Random(42).shuffle(shuffled)

    decrypted: dict[int, bytes] = {}
    for i, msg in shuffled:
        decrypted[i] = rt_b.decrypt(msg)

    for i in range(100):
        assert decrypted[i] == f"m-{i}".encode()


def test_ratchet_serialize_during_active_session() -> None:
    """Encrypt 5 messages, serialize ratchet, deserialize, encrypt again — chain advances correctly.

    Plan §4363-4382 prescribes asserting the post-restore message advances
    the chain to message_number 5 (sender-side: encrypts 0..4, then on the
    6th encrypt the header carries message_number 5). Bob then decrypts
    the original 5 + the 6th to confirm the deserialized state is fully
    operational.
    """
    a_id = _signing_keypair()
    b_id = _signing_keypair()
    shared = os.urandom(32)

    rt_a = DoubleRatchet.init_initiator(
        shared_secret=shared,
        identity_keypair=a_id,
        peer_identity_public_key=b_id.public_key,
    )
    rt_b = DoubleRatchet.init_receiver(
        shared_secret=shared,
        identity_keypair=b_id,
        peer_identity_public_key=a_id.public_key,
    )

    # Alice encrypts 5 messages. After the 5th, sending chain message_number=5.
    pre = [rt_a.encrypt(f"pre-{i}".encode()) for i in range(5)]
    assert pre[-1].header.message_number == 4  # 0-indexed, last one was #4

    # Serialize Alice's ratchet, then restore.
    serialized = rt_a.serialize()
    rt_a_restored = DoubleRatchet.deserialize(serialized)

    # The next encrypt's header must carry message_number 5 (chain advanced).
    after = rt_a_restored.encrypt(b"after-restore")
    assert after.header.message_number == 5

    # End-to-end: Bob decrypts all 6 messages in order, including the
    # post-restore one. The serialize/deserialize cycle must not break the
    # cryptographic continuity of the session.
    for i, msg in enumerate(pre):
        assert rt_b.decrypt(msg) == f"pre-{i}".encode()
    assert rt_b.decrypt(after) == b"after-restore"
