"""Integration: persistence helpers + state classes save/load round trip.

Phase 2 plan §4428-4479 originally prescribed this scenario via
``MlsGroupState.create_initial(...)``, ``grp.save(tmp_path)`` and
``MlsGroupState.load(tmp_path, conv_id, my_keys=keys)`` — none of which
exist on the wrapper that shipped. The actual surface is split:

    state.export_state() -> bytes                      (per-state)
    state.import_state(bytes) -> None                   (per-state)
    crypto.persistence.write_meta(data_dir, conv_id, ConversationMeta)
    crypto.persistence.read_meta(data_dir, conv_id) -> ConversationMeta | None
    crypto.persistence.list_conversations(data_dir) -> list[ConversationMeta]

These tests integrate both halves: write meta + state-blob to disk per
conversation, then read meta + state-blob back, then import the state
into a fresh wrapper and prove encrypt/decrypt continues. Conceptual
scenarios from the plan (save+reload across "restart"; meta listing
across multiple conversations; corrupt-meta raises) are preserved.
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

import pytest

from agentvault_hermes.core.identity import DeviceKeys, generate_device_keys
from agentvault_hermes.crypto import MlsGroupState, SigningKeypair
from agentvault_hermes.crypto.persistence import (
    ConversationMeta,
    list_conversations,
    read_meta,
    write_meta,
)


_STATE_FILE_NAME = "mls_state.bin"


def _signing_kp_from_device_keys(dk: DeviceKeys) -> SigningKeypair:
    return SigningKeypair(
        public_key=dk.signing_public,
        private_key=dk.signing_secret,
    )


def _save_mls_state(
    data_dir: Path, conversation_id: uuid.UUID, state_blob: bytes
) -> None:
    """Write the MLS state blob alongside meta.json. Mirrors the semantic
    contract the plan's `grp.save(tmp_path)` was meant to deliver: state
    bytes + meta sidecar in the conversation directory."""
    conv_dir = data_dir / "conversations" / str(conversation_id)
    conv_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    (conv_dir / _STATE_FILE_NAME).write_bytes(state_blob)


def _load_mls_state(data_dir: Path, conversation_id: uuid.UUID) -> bytes:
    return (data_dir / "conversations" / str(conversation_id) / _STATE_FILE_NAME).read_bytes()


def test_mls_group_persistence_across_restart(tmp_path: Path) -> None:
    """Create a group, add B, encrypt one message, persist state + meta to disk,
    'restart' (build a fresh wrapper), reload, and prove the reloaded wrapper
    can still encrypt to B and B can still decrypt.

    Cross-module integration: MlsGroupState.export_state ↔ import_state +
    crypto.persistence.write_meta ↔ read_meta on the same conversation_id.
    """
    conv_id = uuid.uuid4()
    a_dk = generate_device_keys()
    a_signing = _signing_kp_from_device_keys(a_dk)
    a_device_id = uuid.uuid4()

    grp_a = MlsGroupState(device_keys=a_signing, device_id=a_device_id)
    grp_a.create_group(b"\x42" * 16)

    # Add B and have B join, so the group has someone to talk to after restart.
    grp_b = MlsGroupState(
        device_keys=_signing_kp_from_device_keys(generate_device_keys()),
        device_id=uuid.uuid4(),
    )
    add = grp_a.add_members([grp_b.generate_key_package()])
    assert add.welcome is not None
    grp_b.join_from_welcome(add.welcome)

    pre_epoch = grp_a.epoch
    pre_group_id = grp_a.group_id

    # Persist state-blob + meta.json under tmp_path.
    state_blob = grp_a.export_state()
    write_meta(
        tmp_path,
        conv_id,
        ConversationMeta(
            conversation_id=conv_id,
            type="direct",
            created_at=datetime.now(timezone.utc),
            last_message_ts=None,
        ),
    )
    _save_mls_state(tmp_path, conv_id, state_blob)

    # "Restart": construct a fresh wrapper from the same identity material
    # (signing keypair must match — the signing key is part of the MLS leaf).
    grp_a_reload = MlsGroupState(device_keys=a_signing, device_id=a_device_id)
    grp_a_reload.import_state(_load_mls_state(tmp_path, conv_id))

    # State preserved: epoch and group_id match pre-export.
    assert grp_a_reload.is_initialized
    assert grp_a_reload.epoch == pre_epoch
    assert grp_a_reload.group_id == pre_group_id

    # Meta preserved: read_meta returns the same conversation_id + type.
    loaded_meta = read_meta(tmp_path, conv_id)
    assert loaded_meta is not None
    assert loaded_meta.conversation_id == conv_id
    assert loaded_meta.type == "direct"

    # End-to-end: reloaded A can encrypt; B (still resident in memory) can
    # decrypt. This proves the round-trip was operationally complete, not
    # just byte-equal.
    wire = grp_a_reload.encrypt(b"after restart")
    # Encrypt-continues semantics (plan §4442-4452): the post-reload encrypt
    # must advance the epoch beyond what was captured at save time, proving
    # the loaded state is a working group (not an inert snapshot).
    assert grp_a_reload.epoch >= pre_epoch
    res = grp_b.decrypt(wire)
    assert res.is_handshake is False
    assert res.plaintext == b"after restart"


def test_persistence_meta_listing_after_creating_three(tmp_path: Path) -> None:
    """Create three different-typed conversations; ``list_conversations``
    enumerates all three with type metadata intact and no key material loaded.

    Plan §4455-4467 — preserved scenario, but the state-blob persistence is
    layered atop ``write_meta`` + ``export_state`` since ``MlsGroupState.save``
    isn't a method on the wrapper.
    """
    conv_specs: list[tuple[uuid.UUID, str]] = [
        (uuid.uuid4(), "direct"),
        (uuid.uuid4(), "room"),
        (uuid.uuid4(), "a2a"),
    ]
    a_dk = generate_device_keys()
    a_signing = _signing_kp_from_device_keys(a_dk)

    for cid, type_ in conv_specs:
        grp = MlsGroupState(device_keys=a_signing, device_id=uuid.uuid4())
        grp.create_group(cid.bytes)  # 16-byte UUID → group_id
        write_meta(
            tmp_path,
            cid,
            ConversationMeta(
                conversation_id=cid,
                type=type_,
                created_at=datetime.now(timezone.utc),
                last_message_ts=None,
            ),
        )
        _save_mls_state(tmp_path, cid, grp.export_state())

    metas = list_conversations(tmp_path)
    assert len(metas) == 3
    listed_ids = {m.conversation_id for m in metas}
    assert listed_ids == {cid for cid, _ in conv_specs}
    listed_types = sorted(m.type for m in metas)
    assert listed_types == ["a2a", "direct", "room"]

    # list_conversations returns metadata only — no key material is decoded
    # or loaded by the enumeration (state-blob bytes stay on disk untouched).
    for cid, _ in conv_specs:
        assert (
            tmp_path / "conversations" / str(cid) / _STATE_FILE_NAME
        ).exists()


def test_corrupted_meta_json_raises_value_error(tmp_path: Path) -> None:
    """A non-JSON meta.json must raise ValueError with a 'malformed' marker.

    Plan §4470-4478 — preserved verbatim against the real read_meta surface.
    """
    cid = uuid.uuid4()
    conv_dir = tmp_path / "conversations" / str(cid)
    conv_dir.mkdir(parents=True)
    (conv_dir / "meta.json").write_text("not json {")
    with pytest.raises(ValueError, match="malformed"):
        read_meta(tmp_path, cid)


def test_persistence_meta_version_mismatch_raises(tmp_path: Path) -> None:
    """A meta.json with an unsupported version is rejected. Companion to the
    corrupt-JSON test — covers the second documented failure mode of
    ``read_meta`` (persistence.py:133-137)."""
    cid = uuid.uuid4()
    conv_dir = tmp_path / "conversations" / str(cid)
    conv_dir.mkdir(parents=True)
    (conv_dir / "meta.json").write_text(json.dumps({
        "version": 99,
        "conversation_id": str(cid),
        "type": "direct",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "last_message_ts": None,
    }))
    with pytest.raises(ValueError, match="version"):
        read_meta(tmp_path, cid)
