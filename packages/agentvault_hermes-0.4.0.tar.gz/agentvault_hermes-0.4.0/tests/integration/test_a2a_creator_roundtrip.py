"""Integration tests — A2A creator role end-to-end (action #238, Slice B).

The Slice A integration test (``test_a2a_welcome_to_message_roundtrip.py``)
covers the MEMBER role: receive Welcome, join, reply. Slice B is the
inverse — this test covers the CREATOR role: receive a2a_channel_approved
with ``role=creator``, fetch peer KeyPackages from the backend, found the
MLS group, dispatch a Welcome the peer can join from, and roundtrip an
app message.

Bob is the Hermes creator under test. Alice is a synthesized peer (real
``MlsGroupState``, no SecureChannel) — same pattern Slice A's test uses for
the symmetric direction.

Backend mocks via respx (``GET /api/v1/mls/key-packages/batch`` +
``POST /api/v1/mls/a2a/{channel_id}/init``); the founder's WS outbound
``mls_welcome`` / ``mls_commit`` events are captured off
``relay.send_json``.
"""
from __future__ import annotations

import asyncio
import uuid
from typing import Any, AsyncIterator, Optional
from unittest.mock import AsyncMock

import pytest
import respx
from httpx import Response

from agentvault_hermes.channel.outbox import WireEnvelope
from agentvault_hermes.channel.secure_channel import SecureChannel
from agentvault_hermes.crypto import MlsGroupState, SigningKeypair

_BASE_URL = "http://av-test.example.com"
_BOB_DEVICE_ID = uuid.UUID("11111111-1111-1111-1111-111111111111")
_ALICE_DEVICE_ID = uuid.UUID("22222222-2222-2222-2222-222222222222")
_A2A_CHANNEL_ID = "33333333-3333-3333-3333-333333333333"
_GROUP_ID = "44444444-4444-4444-4444-444444444444"
_BOB_HUB = "bob-hub-1"
_ALICE_HUB = "alice-hub-1"


def _make_keys() -> SigningKeypair:
    import nacl.signing

    sk = nacl.signing.SigningKey.generate()
    return SigningKeypair(public_key=bytes(sk.verify_key), private_key=bytes(sk))


class _MockedRelay:
    """In-memory Relay mock — same shape as Slice A's roundtrip test."""

    def __init__(self) -> None:
        self.rest_base_url = _BASE_URL
        self.device_jwt = "test-jwt-bob"
        self.device_id = str(_BOB_DEVICE_ID)
        self._inbound: asyncio.Queue[Optional[WireEnvelope]] = asyncio.Queue()
        self.connect = AsyncMock()
        self.disconnect = AsyncMock()
        self.send_message = AsyncMock()
        self.send_pong = AsyncMock()
        # send_json captures every outbound WS event the founder emits.
        self.sent_json: list[dict[str, Any]] = []

        async def _send_json(payload: dict[str, Any]) -> None:
            self.sent_json.append(payload)

        self.send_json = AsyncMock(side_effect=_send_json)

    async def receive_messages(self) -> AsyncIterator[WireEnvelope]:
        while True:
            env = await self._inbound.get()
            if env is None:
                return
            yield env

    async def push_inbound(self, env: WireEnvelope) -> None:
        await self._inbound.put(env)

    async def shutdown(self) -> None:
        await self._inbound.put(None)


async def _wait_until(predicate: Any, *, timeout: float = 2.0) -> None:
    deadline = asyncio.get_event_loop().time() + timeout
    while not predicate():
        if asyncio.get_event_loop().time() > deadline:
            raise AssertionError(
                f"_wait_until: predicate stayed falsy for {timeout}s"
            )
        await asyncio.sleep(0.01)


def _make_channel(tmp_path: Any, relay: _MockedRelay, on_inbound: Any) -> SecureChannel:
    return SecureChannel(
        relay=relay,  # type: ignore[arg-type]
        mls_states={},
        on_inbound=on_inbound,
        data_dir=tmp_path,
        device_keys=_make_keys(),
        device_id=_BOB_DEVICE_ID,
        agent_name="bob-agent",
        account_id="acct-bob",
        own_hub_id=_BOB_HUB,
    )


def _approved_creator_envelope(*, alice_device_id: str) -> WireEnvelope:
    """Backend payload mirror for ``a2a_channel_approved`` with role=creator.

    Mirrors ``packages/backend/app/api/v1/a2a_channels.py:344`` (the activation
    payload sent to the creator's device when the channel is approved).
    """
    return WireEnvelope(
        event="a2a_channel_approved",
        data={
            "channel_id": _A2A_CHANNEL_ID,
            "conversation_id": "conv-a2a-creator-1",
            "status": "active",
            "role": "creator",
            "creator_hub_id": _BOB_HUB,
            "participants": [
                {
                    "hub_id": _BOB_HUB,
                    "hub_address": "hub://bob",
                    "status": "active",
                    "device_id": str(_BOB_DEVICE_ID),
                    "role": "creator",
                },
                {
                    "hub_id": _ALICE_HUB,
                    "hub_address": "hub://alice",
                    "status": "invited",
                    "device_id": alice_device_id,
                    "role": "member",
                },
            ],
        },
    )


def _backend_intercepts(
    mock: Any,
    *,
    alice_kp_hex: str,
) -> None:
    """Wire the respx backend mocks needed for one creator-founds flow."""

    # KP-publish (Bob's own KP, side effect of start()): swallow.
    mock.post("/api/v1/mls/key-packages").mock(
        return_value=Response(
            200, json={"id": str(uuid.uuid4()), "device_id": str(_BOB_DEVICE_ID)}
        )
    )
    # Channel list poll on start (no pre-existing channels).
    mock.get("/api/v1/a2a/channels").mock(return_value=Response(200, json=[]))
    # Room poll on start (no rooms).
    mock.get("/api/v1/rooms").mock(return_value=Response(200, json=[]))
    # Delivery queue idle.
    mock.get("/api/v1/mls/delivery").mock(
        return_value=Response(200, json={"messages": []})
    )
    mock.post("/api/v1/mls/delivery/ack").mock(
        return_value=Response(200, json={"acked": 0})
    )

    # KP batch fetch returns Alice's KP keyed by her device_id.
    mock.get("/api/v1/mls/key-packages/batch").mock(
        return_value=Response(200, json={str(_ALICE_DEVICE_ID): alice_kp_hex})
    )
    # A2A MLS group init returns a stable group_id.
    mock.post(f"/api/v1/mls/a2a/{_A2A_CHANNEL_ID}/init").mock(
        return_value=Response(
            200,
            json={
                "group_id": _GROUP_ID,
                "current_epoch": 0,
                "member_device_ids": [
                    str(_BOB_DEVICE_ID),
                    str(_ALICE_DEVICE_ID),
                ],
            },
        )
    )


@pytest.mark.asyncio
async def test_creator_founds_and_member_joins_via_slice_a_then_message_roundtrip(
    tmp_path: Any,
) -> None:
    """End-to-end Hermes-to-Hermes A2A: Bob (Hermes creator) receives
    ``a2a_channel_approved role=creator``, fetches Alice's KeyPackage, founds
    the MLS group, sends a Welcome that Alice (synthesized real MlsGroupState)
    accepts via the standard MLS join path, and a subsequent app message Bob
    sends decrypts cleanly on Alice's side. End-to-end MLS, no shortcuts."""
    relay = _MockedRelay()

    async def on_inbound(_msg: Any) -> None:
        pass

    # Alice's signing identity + KP, pre-published so the backend mock can
    # hand it to Bob's founder.
    alice_keys = _make_keys()
    alice_kp_owner = MlsGroupState(device_keys=alice_keys, device_id=_ALICE_DEVICE_ID)
    alice_kp = alice_kp_owner.generate_key_package()

    ch = _make_channel(tmp_path, relay, on_inbound)

    async with respx.mock(base_url=_BASE_URL, assert_all_called=False) as mock:
        _backend_intercepts(mock, alice_kp_hex=alice_kp.hex())
        await ch.start()
        try:
            # Bob receives the creator-role activation event.
            await relay.push_inbound(
                _approved_creator_envelope(alice_device_id=str(_ALICE_DEVICE_ID))
            )

            # Founder runs: registry gets mls_group_id + creator_device_id;
            # the founder emits one mls_commit and one mls_welcome.
            def _bob_founded() -> bool:
                entry = ch._a2a_registry.get(_A2A_CHANNEL_ID)
                return (
                    entry is not None
                    and entry.mls_group_id == _GROUP_ID
                    and entry.creator_device_id == str(_BOB_DEVICE_ID)
                )

            await _wait_until(_bob_founded)

            # Bob's local MLS state is registered and uses the same group_id.
            assert _GROUP_ID in ch._mls_states
            bob_state = ch._mls_states[_GROUP_ID]
            assert bob_state.group_id == _GROUP_ID.encode()

            # Verify the founder sent commit + welcome events.
            events = [e["event"] for e in relay.sent_json]
            assert "mls_commit" in events
            assert "mls_welcome" in events

            welcome_event = next(
                e for e in relay.sent_json if e["event"] == "mls_welcome"
            )
            welcome_data = welcome_event["data"]
            assert welcome_data["target_device_id"] == str(_ALICE_DEVICE_ID)
            assert welcome_data["target_hub_id"] == _ALICE_HUB
            assert welcome_data["a2a_channel_id"] == _A2A_CHANNEL_ID
            welcome_hex = welcome_data["payload"]

            # Alice joins from the Welcome bytes Bob dispatched.
            alice_state = alice_kp_owner  # reuse — its private key matches the KP
            alice_state.join_from_welcome(bytes.fromhex(welcome_hex))
            assert alice_state.group_id == _GROUP_ID.encode()

            # App message round-trip: Bob -> Alice.
            ciphertext = bob_state.encrypt(b"hello from bob (creator)")
            result = alice_state.decrypt(ciphertext)
            assert result.plaintext == b"hello from bob (creator)"
        finally:
            await relay.shutdown()
            await ch.stop()


@pytest.mark.asyncio
async def test_no_kps_at_found_time_then_reconcile_recovers(tmp_path: Any) -> None:
    """First a2a_channel_approved: backend returns NO KeyPackages for Alice.
    Founder leaves the channel unfounded with pending_kp_hub_ids populated.
    A subsequent reconcile cycle finds Alice's KP available and re-runs
    found_a2a_group; the idempotent backend init lands the group and
    Alice can join.

    This is the partial-found recovery path from spec §5.4 — concretely the
    'mls_group_id null, pending populated' row. The 'partial-then-add-more'
    case where a found channel later adds the missing members is Slice C
    (dynamic add); this test only proves the recovery path Slice B owns.
    """
    relay = _MockedRelay()

    async def on_inbound(_msg: Any) -> None:
        pass

    alice_keys = _make_keys()
    alice_kp_owner = MlsGroupState(device_keys=alice_keys, device_id=_ALICE_DEVICE_ID)
    alice_kp = alice_kp_owner.generate_key_package()

    ch = _make_channel(tmp_path, relay, on_inbound)

    # Toggle for the KP-batch response between calls.
    kp_batch_calls: list[int] = []

    async with respx.mock(base_url=_BASE_URL, assert_all_called=False) as mock:
        # Boilerplate intercepts (no-op start path).
        mock.post("/api/v1/mls/key-packages").mock(
            return_value=Response(
                200,
                json={"id": str(uuid.uuid4()), "device_id": str(_BOB_DEVICE_ID)},
            )
        )
        mock.get("/api/v1/rooms").mock(return_value=Response(200, json=[]))
        mock.get("/api/v1/mls/delivery").mock(
            return_value=Response(200, json={"messages": []})
        )
        mock.post("/api/v1/mls/delivery/ack").mock(
            return_value=Response(200, json={"acked": 0})
        )

        # KP batch: first call returns empty, subsequent calls return Alice's KP.
        async def respond_batch(_request: Any) -> Response:
            kp_batch_calls.append(1)
            if len(kp_batch_calls) == 1:
                return Response(200, json={})
            return Response(200, json={str(_ALICE_DEVICE_ID): alice_kp.hex()})

        mock.get("/api/v1/mls/key-packages/batch").mock(side_effect=respond_batch)

        # A2A init: idempotent (always returns the same group_id).
        mock.post(f"/api/v1/mls/a2a/{_A2A_CHANNEL_ID}/init").mock(
            return_value=Response(
                200,
                json={
                    "group_id": _GROUP_ID,
                    "current_epoch": 0,
                    "member_device_ids": [
                        str(_BOB_DEVICE_ID),
                        str(_ALICE_DEVICE_ID),
                    ],
                },
            )
        )

        # Channel list poll: empty on the FIRST call (start()), then returns
        # the partially-founded channel on subsequent reconcile calls.
        a2a_poll_calls: list[int] = []

        async def respond_a2a_list(_request: Any) -> Response:
            a2a_poll_calls.append(1)
            if len(a2a_poll_calls) == 1:
                return Response(200, json=[])
            # Return the not-yet-founded channel so reconcile picks it up.
            return Response(
                200,
                json=[
                    {
                        "channel_id": _A2A_CHANNEL_ID,
                        "conversation_id": "conv-a2a-creator-1",
                        "role": "creator",
                        "participants": [
                            {
                                "hub_id": _ALICE_HUB,
                                "hub_address": "hub://alice",
                                "status": "invited",
                                "device_id": str(_ALICE_DEVICE_ID),
                            },
                        ],
                    }
                ],
            )

        mock.get("/api/v1/a2a/channels").mock(side_effect=respond_a2a_list)

        await ch.start()
        try:
            # First found attempt: backend has no KPs for Alice.
            await relay.push_inbound(
                _approved_creator_envelope(alice_device_id=str(_ALICE_DEVICE_ID))
            )

            def _bob_unfounded_with_pending() -> bool:
                entry = ch._a2a_registry.get(_A2A_CHANNEL_ID)
                return (
                    entry is not None
                    and entry.mls_group_id is None
                    and entry.pending_kp_hub_ids == [_ALICE_HUB]
                )

            await _wait_until(_bob_unfounded_with_pending)

            # No welcome dispatched yet.
            assert not any(e["event"] == "mls_welcome" for e in relay.sent_json)

            # Trigger reconcile manually (production runs it on connect; we
            # drive it directly so the test stays deterministic).
            await ch._reconcile_a2a_channels()

            # After reconcile: channel founded with Alice's KP from the
            # second batch call.
            def _bob_founded() -> bool:
                entry = ch._a2a_registry.get(_A2A_CHANNEL_ID)
                return (
                    entry is not None
                    and entry.mls_group_id == _GROUP_ID
                    and entry.pending_kp_hub_ids == []
                )

            await _wait_until(_bob_founded)

            # And the Welcome to Alice was dispatched on the reconcile pass.
            welcome_events = [
                e for e in relay.sent_json if e["event"] == "mls_welcome"
            ]
            assert len(welcome_events) == 1
            assert welcome_events[0]["data"]["target_device_id"] == str(
                _ALICE_DEVICE_ID
            )
        finally:
            await relay.shutdown()
            await ch.stop()


@pytest.mark.asyncio
async def test_restart_mid_found_recovers_via_reconcile(tmp_path: Any) -> None:
    """Simulate a gateway crash between MLS persist (step 8) and registry
    update (step 11) of the founder pipeline (spec §5.2). On restart, the
    registry shows mls_group_id=None + role=creator; reconcile re-runs
    found_a2a_group; the idempotent backend init returns the existing
    group; the peer can join from the re-dispatched Welcome.

    Concretely: we monkey-patch save_registry on the founder to raise on
    its first call (simulating the crash between persist and registry
    update). After the failed found, the registry on-disk does NOT carry
    mls_group_id (the in-memory mutation never made it to disk because
    save_registry raised). A second SecureChannel instance loads the
    on-disk registry, reconcile sees the unfounded creator entry, re-runs
    found, and the channel reaches the founded state.

    Validates the Option A persistence model from spec §5.4: no per-
    channel Welcome queue on disk, recovery is via re-found.
    """
    alice_keys = _make_keys()
    # Alice generates ONE KP for the first found attempt (which crashes
    # mid-pipeline; we don't actually use Alice's join on that path) and a
    # SEPARATE KP owned by a fresh MlsGroupState for the restart attempt
    # — mls_rs marks KP slots one-shot, so reusing the first KP on a
    # different MlsGroupState instance would fail with "key package not
    # found, unable to process".
    alice_kp1_owner = MlsGroupState(device_keys=alice_keys, device_id=_ALICE_DEVICE_ID)
    alice_kp1 = alice_kp1_owner.generate_key_package()

    # First (crashing) lifecycle.
    relay1 = _MockedRelay()

    async def on_inbound(_msg: Any) -> None:
        pass

    ch1 = _make_channel(tmp_path, relay1, on_inbound)

    async with respx.mock(base_url=_BASE_URL, assert_all_called=False) as mock:
        _backend_intercepts(mock, alice_kp_hex=alice_kp1.hex())

        await ch1.start()
        try:
            # Make save_registry raise so the in-memory mutation never lands
            # on disk — simulates a crash between MLS persist (already
            # happened by this point) and registry update.
            crash_count = {"n": 0}

            def crashing_save_registry() -> None:
                crash_count["n"] += 1
                raise RuntimeError("simulated crash mid-found")

            ch1._a2a_founder._save_registry = crashing_save_registry

            await relay1.push_inbound(
                _approved_creator_envelope(alice_device_id=str(_ALICE_DEVICE_ID))
            )
            # Wait for the founder to attempt the save (which raises).
            await _wait_until(lambda: crash_count["n"] >= 1)
        finally:
            await relay1.shutdown()
            await ch1.stop()

    # Verify on-disk state: registry was NOT updated with mls_group_id (the
    # crash prevented persist), but the MLS state file MAY exist on disk
    # (persist happened first per the ordering invariant). Either way,
    # restart should recover.
    from agentvault_hermes.channel.a2a_registry import A2AChannelRegistry

    persisted = A2AChannelRegistry()
    persisted.load(tmp_path)
    entry_after_crash = persisted.get(_A2A_CHANNEL_ID)
    # The lifecycle handler's _persist (via upsert_from_event in
    # handle_channel_approved) wrote the entry with role=creator BUT
    # without mls_group_id (founder's save_registry crashed before update).
    assert entry_after_crash is not None
    assert entry_after_crash.role == "creator"
    assert entry_after_crash.mls_group_id is None

    # Second lifecycle — restart on the same data_dir.
    relay2 = _MockedRelay()
    ch2 = _make_channel(tmp_path, relay2, on_inbound)

    async with respx.mock(base_url=_BASE_URL, assert_all_called=False) as mock:
        # Backend reconcile poll returns the unfounded channel so reconcile
        # discovers it and re-runs found.
        a2a_poll_calls: list[int] = []

        async def respond_a2a_list(_request: Any) -> Response:
            a2a_poll_calls.append(1)
            return Response(
                200,
                json=[
                    {
                        "channel_id": _A2A_CHANNEL_ID,
                        "conversation_id": "conv-a2a-creator-1",
                        "role": "creator",
                        "participants": [
                            {
                                "hub_id": _ALICE_HUB,
                                "hub_address": "hub://alice",
                                "status": "invited",
                                "device_id": str(_ALICE_DEVICE_ID),
                            },
                        ],
                    }
                ],
            )

        # Boilerplate intercepts.
        mock.post("/api/v1/mls/key-packages").mock(
            return_value=Response(
                200,
                json={"id": str(uuid.uuid4()), "device_id": str(_BOB_DEVICE_ID)},
            )
        )
        mock.get("/api/v1/rooms").mock(return_value=Response(200, json=[]))
        mock.get("/api/v1/mls/delivery").mock(
            return_value=Response(200, json={"messages": []})
        )
        mock.post("/api/v1/mls/delivery/ack").mock(
            return_value=Response(200, json={"acked": 0})
        )
        mock.get("/api/v1/a2a/channels").mock(side_effect=respond_a2a_list)

        # Alice republished a fresh KP between crash and restart (mls_rs
        # KP slots are one-shot — the original KP would fail "key package
        # not found" on a second add_members call). Backend now hands out
        # the fresh KP.
        alice_kp2_owner = MlsGroupState(
            device_keys=alice_keys, device_id=_ALICE_DEVICE_ID
        )
        alice_kp2 = alice_kp2_owner.generate_key_package()
        mock.get("/api/v1/mls/key-packages/batch").mock(
            return_value=Response(
                200, json={str(_ALICE_DEVICE_ID): alice_kp2.hex()}
            )
        )
        mock.post(f"/api/v1/mls/a2a/{_A2A_CHANNEL_ID}/init").mock(
            return_value=Response(
                200,
                json={
                    "group_id": _GROUP_ID,
                    "current_epoch": 0,
                    "member_device_ids": [
                        str(_BOB_DEVICE_ID),
                        str(_ALICE_DEVICE_ID),
                    ],
                },
            )
        )

        await ch2.start()
        try:
            # Reconcile runs as part of start(); wait for the founded state.
            def _bob_refounded() -> bool:
                entry = ch2._a2a_registry.get(_A2A_CHANNEL_ID)
                return (
                    entry is not None
                    and entry.mls_group_id == _GROUP_ID
                    and entry.creator_device_id == str(_BOB_DEVICE_ID)
                )

            await _wait_until(_bob_refounded)

            # A Welcome MUST have been re-dispatched so the peer can join.
            welcome_events = [
                e for e in relay2.sent_json if e["event"] == "mls_welcome"
            ]
            assert len(welcome_events) >= 1
            assert welcome_events[-1]["data"]["target_device_id"] == str(
                _ALICE_DEVICE_ID
            )

            # Peer joins from the re-dispatched Welcome (using the same
            # MlsGroupState instance that owns the fresh KP).
            alice_kp2_owner.join_from_welcome(
                bytes.fromhex(welcome_events[-1]["data"]["payload"])
            )
            assert alice_kp2_owner.group_id == _GROUP_ID.encode()
        finally:
            await relay2.shutdown()
            await ch2.stop()
