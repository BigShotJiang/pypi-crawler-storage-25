"""Integration tests for ``AgentVaultAdapter`` lifecycle against a real
``SecureChannel`` and a fake relay transport.

Closes action_item #145 (DA WS-31 F4 from PR #161): the unit tests at
``tests/unit/plugins/test_adapter.py`` mock ``SecureChannel`` entirely, so
contract drift between the adapter and ``SecureChannel.__init__`` /
``.start()`` / ``.stop()`` / ``.send()`` would go undetected. This file
exercises the lifecycle paths the WS-34 phase3 demo does NOT cover:

* connect with no ``state.json`` (early-return False)
* connect partial failure — ``SC.start()`` raises mid-startup; adapter
  must call ``SC.stop()`` and reset ``_secure_channel`` to ``None``
  (DA WS-31 C1)
* connect-while-connected — adapter must stop the prior channel,
  rebuild, and clear hydrated states (DA WS-31 C2)
* disconnect idempotency — calling disconnect twice (or before connect)
  is a no-op

These are SEPARATE from the happy-path messaging E2E covered by
``tests/integration/test_phase3_demo.py``. Keeping them in their own
file means each test stays tight and a future failure pinpoints whether
the regression is in the lifecycle plumbing or the message-flow path.

Mocking strategy (matches phase3_demo):

* ``WsClient`` is monkeypatched at the ``relay_module`` call-site
  (NOT at its definition site — ``Relay`` imported it by reference at
  module load). The fake exposes an in-memory inbox/outbox + the
  ``__aenter__/__aexit__`` async-cm protocol.
* REST endpoints (``/api/v1/mls/key-packages``, ``/mls/delivery``) are
  stubbed with ``respx`` so ``_ensure_pending_key_package`` and
  ``_pull_delivery_queue`` can complete (or be made to fail).
* ``resolve_profile`` / ``migrate_legacy_layout`` are patched to return a temp-dir ``data_dir``.

Everything else is real: ``Relay``, ``SecureChannel``, ``MlsGroupState``,
``RestClient``, persistence I/O, the asyncio background-task plumbing.
"""
from __future__ import annotations

import asyncio
import uuid
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
import respx
from httpx import Response

# Gateway runtime mocks must be installed BEFORE importing the adapter
# (same constraint as test_phase3_demo.py + test_adapter.py).
from tests._fixtures.gateway_runtime import install_gateway_mocks

install_gateway_mocks()


from agentvault_hermes.core.identity import (  # noqa: E402
    PersistedState,
    generate_device_keys,
    save_state,
)
from agentvault_hermes.core.transport import relay as relay_module  # noqa: E402
from agentvault_hermes.plugins.agentvault import adapter as adapter_module  # noqa: E402
from agentvault_hermes.plugins.agentvault.adapter import AgentVaultAdapter  # noqa: E402


# ---------------------------------------------------------------------------
# Shared test infrastructure
# ---------------------------------------------------------------------------


def _build_fake_ws() -> tuple[MagicMock, list[dict[str, Any]], asyncio.Queue[Any]]:
    """Build a fake WsClient instance.

    Returns ``(instance, outbox_list, inbox_queue)``. The inbox is an
    ``asyncio.Queue`` whose ``put`` lets tests inject inbound frames; the
    fake's ``receive_json`` ``await``s on the queue so the demux loop
    parks naturally until a test feeds something in.

    Critical: the fake itself supports the ``__aenter__/__aexit__``
    async-cm protocol because ``Relay.connect()`` calls
    ``ws.__aenter__()`` directly (not ``async with ws``) — see
    ``core/transport/relay.py:73``.
    """
    outbox: list[dict[str, Any]] = []
    inbox: asyncio.Queue[Any] = asyncio.Queue()

    async def fake_send_json(payload: dict[str, Any]) -> None:
        outbox.append(payload)

    async def fake_receive_json() -> Any:
        return await inbox.get()

    instance = MagicMock(name="FakeWsClient")
    instance.send_json = AsyncMock(side_effect=fake_send_json)
    instance.receive_json = AsyncMock(side_effect=fake_receive_json)
    instance.__aenter__ = AsyncMock(return_value=instance)
    instance.__aexit__ = AsyncMock(return_value=None)
    return instance, outbox, inbox


def _write_state_json(account_dir: Path) -> PersistedState:
    """Write a minimal valid ``state.json`` to ``account_dir``."""
    dk = generate_device_keys()
    state = PersistedState(
        device_id=str(uuid.uuid4()),
        tenant_id=str(uuid.uuid4()),
        device_jwt="ey.fake.jwt",
        device_keys=dk,
    )
    save_state(account_dir, state)
    return state


def _build_adapter(monkeypatch: pytest.MonkeyPatch, account_dir: Path) -> Any:
    """Construct a real ``AgentVaultAdapter`` with profile resolution
    pinned to ``account_dir``. Returns the adapter (un-connected).

    Uses the new profile-aware API: patches ``resolve_profile`` +
    ``migrate_legacy_layout`` instead of the now-removed ``resolve_account``.
    """
    from agentvault_hermes.core.config import ProfileConfig

    fake_profile_cfg = ProfileConfig(
        profile=None,
        data_dir=account_dir,
        api_url="http://av-test.example.com",
        agent_name="testagent",
        http_port=18790,
    )
    monkeypatch.setattr(adapter_module, "migrate_legacy_layout", lambda: None)
    monkeypatch.setattr(
        adapter_module, "resolve_profile", lambda _p=None: fake_profile_cfg
    )

    cfg = MagicMock()
    cfg.extra = {}
    return AgentVaultAdapter(cfg)


def _install_rest_stubs(
    *,
    kp_publish_status: int = 200,
    delivery_status: int = 200,
) -> respx.MockRouter:
    """Stub the AV REST endpoints SecureChannel.start() touches.

    Defaults to 200/empty responses so ``start()`` completes normally.
    ``kp_publish_status=500`` makes ``_ensure_pending_key_package`` raise
    ``RestClientError`` → propagates up out of ``start()`` and triggers
    the adapter's partial-failure rollback path.
    """
    mock = respx.mock(
        base_url="http://av-test.example.com", assert_all_called=False
    )
    if kp_publish_status == 200:
        mock.post("/api/v1/mls/key-packages").mock(
            return_value=Response(
                200,
                json={"id": str(uuid.uuid4()), "device_id": str(uuid.uuid4())},
            )
        )
    else:
        mock.post("/api/v1/mls/key-packages").mock(
            return_value=Response(
                kp_publish_status, json={"detail": "synthetic failure"}
            )
        )
    mock.get("/api/v1/mls/delivery").mock(
        return_value=Response(delivery_status, json={"messages": []})
    )
    mock.post("/api/v1/mls/delivery/ack").mock(
        return_value=Response(200, json={"acked": 0})
    )
    return mock


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


async def test_connect_returns_false_when_no_state_json(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """No ``state.json`` on disk → ``connect()`` returns False WITHOUT
    constructing a SecureChannel.

    The unit-test equivalent at ``test_adapter.py`` mocks
    ``load_state`` to return None. This integration version proves the
    REAL ``load_state`` path returns None when the file is genuinely
    absent — catches any future regression where ``load_state`` starts
    silently returning a stub on miss.
    """
    account_dir = tmp_path / "empty-account"
    account_dir.mkdir()  # exists, but no state.json inside

    adapter = _build_adapter(monkeypatch, account_dir)

    ok = await adapter.connect()

    assert ok is False
    assert adapter._secure_channel is None
    assert adapter._state is None


async def test_connect_partial_failure_resets_secure_channel_to_none(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """If ``SecureChannel.start()`` raises mid-startup, the adapter MUST
    call ``SC.stop()`` to tear down whatever started and reset
    ``_secure_channel`` to ``None`` so a subsequent Hermes-driven retry
    can rebuild from scratch.

    DA WS-31 C1 — without this rollback, the WS + 4 background tasks
    that SC.start spawned mid-flight would leak and Hermes' next
    ``connect()`` would silently double-attach.

    Trigger: make ``/api/v1/mls/key-packages`` return 500 so
    ``_ensure_pending_key_package`` raises ``RestClientError`` from
    inside ``start()``.
    """
    account_dir = tmp_path / "account-partial-fail"
    _write_state_json(account_dir)
    adapter = _build_adapter(monkeypatch, account_dir)

    fake_ws, _outbox, _inbox = _build_fake_ws()
    monkeypatch.setattr(
        relay_module,
        "WsClient",
        MagicMock(return_value=fake_ws),
    )

    rest = _install_rest_stubs(kp_publish_status=500)
    rest.start()
    try:
        # SC.start raises → adapter catches → SC.stop() → re-raise.
        # The adapter's ``except Exception`` re-raises after cleanup; we
        # expect the underlying RestClientError to surface here.
        with pytest.raises(Exception) as exc_info:
            await adapter.connect()

        # The error type is ``RestClientError`` from rest_client.py; we
        # check substring to avoid coupling to the exact class import.
        assert "synthetic failure" in str(exc_info.value) or "500" in str(
            exc_info.value
        )

        # CRITICAL contract assertion: the rollback ran.
        assert adapter._secure_channel is None, (
            "adapter did NOT reset _secure_channel on partial-failure "
            "rollback — a subsequent connect() would leak the half-started "
            "channel"
        )
        # The fake WS was opened by Relay.connect() before _ensure_pending_key_package
        # ran, so __aenter__ was called. The cleanup path then called Relay.disconnect()
        # which routes through __aexit__.
        assert fake_ws.__aenter__.await_count >= 1
        assert fake_ws.__aexit__.await_count >= 1
    finally:
        rest.stop()


async def test_reconnect_replaces_secure_channel_and_clears_states(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Calling ``connect()`` while already connected MUST:

    1. Stop the prior ``SecureChannel`` (idempotent — second connect
       cleans up first connect's WS + background tasks).
    2. Clear ``_mls_states`` so a stale dict from a prior session can't
       bleed into the new one.
    3. Build a fresh ``SecureChannel`` and start it.

    DA WS-31 C2 — Hermes lifecycle managers occasionally call
    ``connect()`` twice (reconnect path, restart, supervisor flap);
    without this, the previous channel + 4 background tasks leak AND
    both demuxes would race on the shared ``_mls_states`` dict
    (ratchet corruption risk).
    """
    account_dir = tmp_path / "account-reconnect"
    _write_state_json(account_dir)
    adapter = _build_adapter(monkeypatch, account_dir)

    # First connect: build fake WS #1.
    fake_ws_first, _o1, _i1 = _build_fake_ws()
    fake_ws_second, _o2, _i2 = _build_fake_ws()
    ws_ctor = MagicMock(side_effect=[fake_ws_first, fake_ws_second])
    monkeypatch.setattr(relay_module, "WsClient", ws_ctor)

    rest = _install_rest_stubs()
    rest.start()
    try:
        # --- First connect ---
        ok1 = await adapter.connect()
        assert ok1 is True
        first_channel = adapter._secure_channel
        assert first_channel is not None

        # Pollute _mls_states with a stale entry so we can verify the
        # clear-on-reconnect contract.
        adapter._mls_states["stale-conv-id-not-on-disk"] = MagicMock()
        assert "stale-conv-id-not-on-disk" in adapter._mls_states

        # --- Second connect (the reconnect path) ---
        ok2 = await adapter.connect()
        assert ok2 is True

        # Contract assertions:
        # (a) A NEW SecureChannel was built — not the same instance.
        assert adapter._secure_channel is not first_channel, (
            "connect-while-connected returned the SAME SecureChannel "
            "instance; it must build a fresh one"
        )
        # (b) Stale state entries were cleared.
        assert "stale-conv-id-not-on-disk" not in adapter._mls_states, (
            "stale _mls_states entry survived reconnect; concurrent demux "
            "loops would race on it"
        )
        # (c) Two WsClient constructions = two distinct WS lifecycles.
        assert ws_ctor.call_count == 2
        # (d) First fake WS got disconnected before the second one opened.
        assert fake_ws_first.__aexit__.await_count >= 1, (
            "first WS was not closed during reconnect — Relay leak"
        )
        assert fake_ws_second.__aenter__.await_count >= 1
    finally:
        await adapter.disconnect()
        rest.stop()


async def test_disconnect_is_idempotent_with_real_secure_channel(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Calling ``disconnect()`` on a non-connected adapter is a no-op;
    calling it twice after a connect is also a no-op on the second call.

    Lock the behavior so a future regression where ``disconnect()``
    starts requiring a connected state (or fails on double-call) breaks
    loudly.
    """
    account_dir = tmp_path / "account-disconnect"
    _write_state_json(account_dir)
    adapter = _build_adapter(monkeypatch, account_dir)

    # --- Disconnect-before-connect: no-op, no raise ---
    await adapter.disconnect()
    assert adapter._secure_channel is None

    # --- Connect, then disconnect twice ---
    fake_ws, _outbox, _inbox = _build_fake_ws()
    monkeypatch.setattr(
        relay_module, "WsClient", MagicMock(return_value=fake_ws)
    )

    rest = _install_rest_stubs()
    rest.start()
    try:
        ok = await adapter.connect()
        assert ok is True
        assert adapter._secure_channel is not None

        await adapter.disconnect()
        assert adapter._secure_channel is None
        first_aexit_count = fake_ws.__aexit__.await_count
        assert first_aexit_count >= 1

        # Second disconnect: must not raise, must not re-stop the WS.
        await adapter.disconnect()
        assert adapter._secure_channel is None
        assert fake_ws.__aexit__.await_count == first_aexit_count, (
            "second disconnect() reached the WS again — the channel-None "
            "guard at adapter.py:179 is not protecting"
        )
    finally:
        rest.stop()


async def test_send_uses_real_secure_channel_send_signature(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """``adapter.send`` calls ``SecureChannel.send(conversation_id, plaintext)``
    with utf-8-encoded bytes. The unit test mocks SC entirely; this
    version proves the call REACHES the real SC.send and raises a
    ``RuntimeError`` on unknown-conv (the real SC's documented contract
    at ``secure_channel.py:378-380``).

    Catches drift if a future SC.send signature change (adds a kwarg,
    renames an arg) goes unupdated in the adapter — the unit-mock
    wouldn't see it; this integration test would.
    """
    account_dir = tmp_path / "account-send-sig"
    _write_state_json(account_dir)
    adapter = _build_adapter(monkeypatch, account_dir)

    fake_ws, _outbox, _inbox = _build_fake_ws()
    monkeypatch.setattr(
        relay_module, "WsClient", MagicMock(return_value=fake_ws)
    )

    rest = _install_rest_stubs()
    rest.start()
    try:
        await adapter.connect()
        # No MLS state for "unknown-conv" → real SC.send raises
        # ``RuntimeError("No MlsGroupState for conversation …")``. The
        # adapter catches and returns SendResult(success=False, retryable=True).
        result = await adapter.send("unknown-conv", "hello")
        assert result.success is False
        assert result.retryable is True
        assert (
            "No MlsGroupState" in (result.error or "")
            or "unknown-conv" in (result.error or "")
        ), (
            f"adapter.send did not surface the real SC.send contract "
            f"error; got error={result.error!r}"
        )
    finally:
        await adapter.disconnect()
        rest.stop()
