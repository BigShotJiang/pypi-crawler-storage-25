"""Integration tests — room messaging end-to-end (action #234).

Mirrors tests/integration/test_welcome_to_message_roundtrip.py: real
MlsGroupState + SigningKeypair, respx HTTP intercepts, an in-memory
_MockedRelay. Exercises the full room receive path — room Welcome -> join
-> room application message -> decrypt -> mention gate -> [senderName]:
attribution -> on_inbound — plus the agent replying into the room, and the
mention-filter loop guard for an un-mentioned agent sender.
"""
from __future__ import annotations

import asyncio
import uuid
from typing import Any, AsyncIterator, Optional
from unittest.mock import AsyncMock

import pytest
import respx
from httpx import Response

from agentvault_hermes.channel.outbox import WireEnvelope
from agentvault_hermes.channel.secure_channel import SecureChannel
from agentvault_hermes.crypto import MlsGroupState, SigningKeypair

_BASE_URL = "http://av-test.example.com"
_BOB_DEVICE_ID = uuid.UUID("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
_ALICE_DEVICE_ID = uuid.UUID("bbbbbbbb-cccc-dddd-eeee-ffffffffffff")
_ROOM_ID = "33333333-3333-3333-3333-333333333333"


def _make_keys() -> SigningKeypair:
    import nacl.signing

    sk = nacl.signing.SigningKey.generate()
    return SigningKeypair(public_key=bytes(sk.verify_key), private_key=bytes(sk))


class _MockedRelay:
    """In-memory Relay — the 1:1 round-trip test's shape plus send_json."""

    def __init__(self) -> None:
        self.rest_base_url = _BASE_URL
        self.device_jwt = "test-jwt-bob"
        self.device_id = str(_BOB_DEVICE_ID)
        self._inbound: asyncio.Queue[Optional[WireEnvelope]] = asyncio.Queue()
        self.connect = AsyncMock()
        self.disconnect = AsyncMock()
        self.send_message = AsyncMock()
        self.send_pong = AsyncMock()
        self.send_json = AsyncMock()

    async def receive_messages(self) -> AsyncIterator[WireEnvelope]:
        while True:
            env = await self._inbound.get()
            if env is None:
                return
            yield env

    async def push_inbound(self, env: WireEnvelope) -> None:
        await self._inbound.put(env)

    async def shutdown(self) -> None:
        await self._inbound.put(None)


async def _wait_until(predicate: Any, *, timeout: float = 2.0) -> None:
    deadline = asyncio.get_event_loop().time() + timeout
    while not predicate():
        if asyncio.get_event_loop().time() > deadline:
            raise AssertionError(f"_wait_until: predicate stayed falsy for {timeout}s")
        await asyncio.sleep(0.01)


def _room_joined_envelope(alice_entity_type: str = "owner") -> WireEnvelope:
    """``room_joined`` event placing Alice + Bob's agent in the room.

    ``alice_entity_type`` lets the gating test present Alice as another
    agent so her plain chatter is loop-guarded.
    """
    return WireEnvelope(
        event="room_joined",
        data={
            "room_id": _ROOM_ID,
            "room_name": "Launch Room",
            "members": [
                {"device_id": str(_ALICE_DEVICE_ID),
                 "entity_type": alice_entity_type, "display_name": "Alice"},
                {"device_id": str(_BOB_DEVICE_ID),
                 "entity_type": "agent", "display_name": "Bob"},
            ],
            "conversations": [],
        },
    )


def _welcome_row(alice: MlsGroupState, welcome_hex: str) -> dict[str, Any]:
    return {
        "queue_id": "q-room-welcome",
        "message_id": str(uuid.uuid4()),
        "group_id": str(uuid.UUID(bytes=alice.group_id)),
        "message_type": "welcome",
        "sender_device_id": str(_ALICE_DEVICE_ID),
        "epoch": 0,
        "payload": welcome_hex,
        "room_id": _ROOM_ID,
        "conversation_id": None,
        "a2a_channel_id": None,
        "conversation_group_id": None,
        "created_at": "2026-05-21T00:00:01Z",
    }


def _app_row(alice: MlsGroupState, ciphertext_hex: str, queue_id: str) -> dict[str, Any]:
    return {
        "queue_id": queue_id,
        "message_id": str(uuid.uuid4()),
        "group_id": str(uuid.UUID(bytes=alice.group_id)),
        "message_type": "application",
        "sender_device_id": str(_ALICE_DEVICE_ID),
        "epoch": alice.epoch,
        "payload": ciphertext_hex,
        "room_id": _ROOM_ID,
        "conversation_id": None,
        "a2a_channel_id": None,
        "conversation_group_id": None,
        "created_at": "2026-05-21T00:00:02Z",
    }


async def _join_bob_to_room(
    ch: SecureChannel,
    relay: _MockedRelay,
    pull_response: dict[str, Any],
    captured_kp_hex: list[str],
    alice_keys: SigningKeypair,
) -> MlsGroupState:
    """Drive Alice creating the room MLS group + adding Bob, and Bob joining
    via the queued room Welcome. Returns Alice's MlsGroupState."""
    assert captured_kp_hex, "publish_key_package was not called by start()"
    alice = MlsGroupState(device_keys=alice_keys, device_id=_ALICE_DEVICE_ID)
    alice.create_group(b"\x52" * 16)
    add_result = alice.add_members([bytes.fromhex(captured_kp_hex[0])])
    assert add_result.welcome is not None
    pull_response["messages"] = [_welcome_row(alice, add_result.welcome.hex())]
    await relay.push_inbound(WireEnvelope(event="mls_delivery", data={"count": 1}))
    await _wait_until(lambda: _ROOM_ID in ch._mls_states)
    return alice


def _make_channel(tmp_path: Any, relay: _MockedRelay, on_inbound: Any) -> SecureChannel:
    return SecureChannel(
        relay=relay,  # type: ignore[arg-type]
        mls_states={},
        on_inbound=on_inbound,
        data_dir=tmp_path,
        device_keys=_make_keys(),
        device_id=_BOB_DEVICE_ID,
        agent_name="bob-agent",
        account_id="acct-bob",
    )


def _respx_intercepts(mock: Any, captured_kp_hex: list[str],
                       pull_response: dict[str, Any], acked: list[str]) -> None:
    async def capture_publish(request: Any) -> Response:
        import json

        captured_kp_hex.append(json.loads(request.read())["key_package"])
        return Response(200, json={"id": str(uuid.uuid4()),
                                   "device_id": str(_BOB_DEVICE_ID)})

    async def respond_pull(request: Any) -> Response:
        return Response(200, json=pull_response)

    async def respond_ack(request: Any) -> Response:
        import json

        ids = json.loads(request.read()).get("queue_ids", [])
        acked.extend(ids)
        return Response(200, json={"acked": len(ids)})

    mock.post("/api/v1/mls/key-packages").mock(side_effect=capture_publish)
    mock.get("/api/v1/rooms").mock(return_value=Response(200, json=[]))
    mock.get("/api/v1/mls/delivery").mock(side_effect=respond_pull)
    mock.post("/api/v1/mls/delivery/ack").mock(side_effect=respond_ack)


@pytest.mark.asyncio
async def test_room_welcome_message_roundtrip_and_reply(tmp_path: Any) -> None:
    """Bob joins a room via Welcome, receives a room message from Alice (an
    owner) decrypted with ``[Alice]:`` attribution, and replies into the
    room via a room_message_mls envelope."""
    captured_kp_hex: list[str] = []
    pull_response: dict[str, Any] = {"messages": []}
    acked: list[str] = []
    alice_keys = _make_keys()
    relay = _MockedRelay()
    received: list[Any] = []
    delivered = asyncio.Event()

    async def on_inbound(msg: Any) -> None:
        received.append(msg)
        delivered.set()

    ch = _make_channel(tmp_path, relay, on_inbound)

    async with respx.mock(base_url=_BASE_URL, assert_all_called=False) as mock:
        _respx_intercepts(mock, captured_kp_hex, pull_response, acked)
        await ch.start()
        try:
            alice = await _join_bob_to_room(
                ch, relay, pull_response, captured_kp_hex, alice_keys
            )
            # Bob joined the room MLS group, keyed by room_id.
            assert ch._mls_states[_ROOM_ID].is_initialized
            # Non-gameable identity check: the consumer's group_id IS the
            # real producer's group_id (not a synthetic id on both sides).
            assert ch._mls_states[_ROOM_ID].group_id == alice.group_id
            await _wait_until(
                lambda: ch._room_directory.get(_ROOM_ID) is not None
                and ch._room_directory.get(_ROOM_ID).mls_group_id is not None
            )

            # room_joined event supplies the member roster (Alice = owner).
            await relay.push_inbound(_room_joined_envelope())
            await _wait_until(
                lambda: bool(
                    ch._room_directory.get(_ROOM_ID)
                    and ch._room_directory.get(_ROOM_ID).members
                )
            )

            # Alice sends a room application message.
            ciphertext = alice.encrypt(b"hello room")
            pull_response["messages"] = [_app_row(alice, ciphertext.hex(), "q-room-app")]
            await relay.push_inbound(
                WireEnvelope(event="mls_delivery", data={"count": 1})
            )
            await asyncio.wait_for(delivered.wait(), timeout=2.0)

            assert received, "on_inbound was never called for the room message"
            inbound = received[0]
            assert inbound.room_id == _ROOM_ID
            assert inbound.plaintext == "[Alice]: hello room"

            # Bob replies into the room.
            await ch.send(conversation_id=_ROOM_ID, plaintext=b"on it")
            relay.send_message.assert_awaited()
            assert relay.send_message.await_args.kwargs["room_id"] == _ROOM_ID
        finally:
            await relay.shutdown()
            await ch.stop()


@pytest.mark.asyncio
async def test_room_message_from_unmentioned_agent_is_gated(tmp_path: Any) -> None:
    """A room message from another AGENT with no @mention is decrypted +
    acked but NOT surfaced to on_inbound (mention-filter loop guard)."""
    captured_kp_hex: list[str] = []
    pull_response: dict[str, Any] = {"messages": []}
    acked: list[str] = []
    alice_keys = _make_keys()
    relay = _MockedRelay()
    received: list[Any] = []

    async def on_inbound(msg: Any) -> None:
        received.append(msg)

    ch = _make_channel(tmp_path, relay, on_inbound)

    async with respx.mock(base_url=_BASE_URL, assert_all_called=False) as mock:
        _respx_intercepts(mock, captured_kp_hex, pull_response, acked)
        await ch.start()
        try:
            alice = await _join_bob_to_room(
                ch, relay, pull_response, captured_kp_hex, alice_keys
            )
            # Alice is presented as another AGENT in the roster.
            await relay.push_inbound(_room_joined_envelope(alice_entity_type="agent"))
            await _wait_until(
                lambda: bool(
                    ch._room_directory.get(_ROOM_ID)
                    and ch._room_directory.get(_ROOM_ID).members
                )
            )

            ciphertext = alice.encrypt(b"just some chatter")
            pull_response["messages"] = [_app_row(alice, ciphertext.hex(), "q-gated")]
            await relay.push_inbound(
                WireEnvelope(event="mls_delivery", data={"count": 1})
            )
            # Wait for the gated row to be acked — proves the pull processed
            # and decrypted it — then assert it was never surfaced.
            await _wait_until(lambda: "q-gated" in acked)
            assert received == [], "gated agent message must not reach on_inbound"
        finally:
            await relay.shutdown()
            await ch.stop()
