"""Integration: telemetry hooks fire across the crypto stack.

Phase 2 plan §4481-4530 originally prescribed asserting that both
``DoubleRatchet`` and ``MlsGroupState`` invoke an ``on_encrypt`` hook when
their respective ``encrypt()`` is called. That works for the Double Ratchet
side — ``on_encrypt`` / ``on_decrypt`` are real attributes (ratchet.py:244-245)
and fire with a ``RatchetTelemetryEvent`` payload. For MLS, however, the
shipped ``MlsGroupState`` (mls_group.py) has no telemetry hook attribute at
all — telemetry for MLS is explicitly deferred to Phase 6 (see mls_group.py:455).

To preserve the plan's intent without inventing a missing API, this module:

1. Ships a fully-passing test that ``DoubleRatchet`` fires ``on_encrypt`` AND
   ``on_decrypt`` with the documented event shape, end-to-end across an
   encrypt → decrypt cycle. This covers the "DR side" of the plan's request.
2. Marks the dual-protocol assertion ``xfail(strict=False)`` citing that
   ``MlsGroupState`` doesn't yet expose a telemetry hook. The test will start
   passing the moment Phase 6 wires the hook in, at which point the xfail
   marker should be dropped.
"""
from __future__ import annotations

import os
import uuid

import pytest

from agentvault_hermes.core.identity import generate_device_keys
from agentvault_hermes.crypto import MlsGroupState, SigningKeypair
from agentvault_hermes.crypto.ratchet import (
    DoubleRatchet,
    RatchetTelemetryEvent,
)


def _signing_keypair() -> SigningKeypair:
    from nacl import signing as nacl_signing
    sk = nacl_signing.SigningKey.generate()
    return SigningKeypair(public_key=bytes(sk.verify_key), private_key=bytes(sk))


def test_double_ratchet_telemetry_hooks_fire_on_encrypt_and_decrypt() -> None:
    """End-to-end: registering ``on_encrypt`` + ``on_decrypt`` callbacks on
    initiator and receiver fires them with payloads matching the
    RatchetTelemetryEvent contract (message_number, ciphertext_size,
    envelope_version)."""
    a_id = _signing_keypair()
    b_id = _signing_keypair()
    shared = os.urandom(32)

    rt_a = DoubleRatchet.init_initiator(
        shared_secret=shared,
        identity_keypair=a_id,
        peer_identity_public_key=b_id.public_key,
    )
    rt_b = DoubleRatchet.init_receiver(
        shared_secret=shared,
        identity_keypair=b_id,
        peer_identity_public_key=a_id.public_key,
    )

    encrypt_events: list[RatchetTelemetryEvent] = []
    decrypt_events: list[RatchetTelemetryEvent] = []
    rt_a.on_encrypt = lambda event: encrypt_events.append(event)
    rt_b.on_decrypt = lambda event: decrypt_events.append(event)

    msg = rt_a.encrypt(b"hello bob")
    plaintext = rt_b.decrypt(msg)
    assert plaintext == b"hello bob"

    # Encrypt-side hook fired exactly once with the expected shape.
    assert len(encrypt_events) == 1
    enc_evt = encrypt_events[0]
    assert enc_evt["message_number"] == 0
    assert enc_evt["ciphertext_size"] == len(msg.ciphertext)
    assert enc_evt["envelope_version"] is None  # V1 default (no header encryption)

    # Decrypt-side hook fired exactly once with matching message_number /
    # ciphertext_size (envelope_version mirrors the encrypted message's).
    assert len(decrypt_events) == 1
    dec_evt = decrypt_events[0]
    assert dec_evt["message_number"] == 0
    assert dec_evt["ciphertext_size"] == len(msg.ciphertext)
    assert dec_evt["envelope_version"] == msg.envelope_version


def test_double_ratchet_telemetry_hook_payload_v2_envelope() -> None:
    """When ``encrypt(header_encryption=True)`` is used, the telemetry event's
    ``envelope_version`` field carries the 2.0.0 marker (ratchet.py:39-43,
    ratchet.py:610-614). Locks down the wire-format-aware telemetry shape."""
    a_id = _signing_keypair()
    b_id = _signing_keypair()
    shared = os.urandom(32)

    rt_a = DoubleRatchet.init_initiator(
        shared_secret=shared,
        identity_keypair=a_id,
        peer_identity_public_key=b_id.public_key,
    )
    captured: list[RatchetTelemetryEvent] = []
    rt_a.on_encrypt = lambda event: captured.append(event)

    rt_a.encrypt(b"secret payload", header_encryption=True)

    assert len(captured) == 1
    assert captured[0]["envelope_version"] == "2.0.0"


@pytest.mark.xfail(
    strict=False,
    reason=(
        "MlsGroupState has no on_encrypt/on_decrypt telemetry hook today; "
        "MLS telemetry is explicitly deferred to Phase 6 (see mls_group.py:455 "
        "'future joint upgrades #2 and #4'). Drop this xfail marker when "
        "Phase 6 wires telemetry callbacks into MlsGroupState."
    ),
)
def test_telemetry_hooks_fire_for_both_protocols() -> None:
    """Plan §4505-4529's exact intent: a DR encrypt and an MLS encrypt both
    invoke registered hooks. Marked xfail because ``MlsGroupState`` lacks the
    ``on_encrypt`` attribute the plan presupposed."""
    captured: list[tuple[str, object]] = []

    rt = DoubleRatchet.init_initiator(
        shared_secret=os.urandom(32),
        identity_keypair=_signing_keypair(),
        peer_identity_public_key=_signing_keypair().public_key,
    )
    rt.on_encrypt = lambda event: captured.append(("dr", event))
    rt.encrypt(b"hello")

    # MLS side: this is the line that fails today — MlsGroupState has no
    # `on_encrypt` attribute. setattr would silently work on Python objects,
    # but `encrypt()` never reads it because no hook-call site exists in
    # mls_group.py.
    dk = generate_device_keys()
    grp = MlsGroupState(
        device_keys=SigningKeypair(
            public_key=dk.signing_public,
            private_key=dk.signing_secret,
        ),
        device_id=uuid.uuid4(),
    )
    grp.create_group(b"\x42" * 16)
    # The next line is the assertion the plan made: MLS exposes a hook.
    # Setattr succeeds (no __slots__) but encrypt() never reads it — the
    # xfail marker on this test absorbs the resulting len(captured) == 1
    # mismatch. When MlsGroupState gains an on_encrypt hook (Phase 6), the
    # xfail flips to PASS automatically.
    grp.on_encrypt = lambda event: captured.append(("mls", event))
    grp.encrypt(b"hello")

    assert len(captured) == 2
    assert captured[0][0] == "dr"
    assert captured[1][0] == "mls"
