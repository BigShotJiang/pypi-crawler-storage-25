"""Stage-5 integration test — Welcome → application-message round-trip.

Plan §5.7. Drives bob's ``SecureChannel`` through:

1. ``start()`` → KP publish → first pull (initially empty)
2. alice (real ``MlsGroupState``) constructs Welcome against bob's published KP
3. respx queues the Welcome row in the next pull response
4. ``mls_delivery`` ping triggers second pull → bob joins the group
5. application-message round-trip: alice encrypts, bob's pull
   surfaces the row, ``handle_message_mls`` decrypts → on_inbound fires.

This is the regression guard for the entire Phase 3 §M1 work-stream
and the executable form of §7 acceptance criteria.

P10 mandate: respx with literal URL paths matching plan §2.1/§2.2 (NOT
method-level RestClient mocks — that wouldn't catch wire-format
regressions).

Out-of-scope (action_items / future work):

- Live WS handshake — Relay's WsClient is mocked. The §M1 manual smoke
  (PR #164) covers that path.
- Back-to-back two-Welcomes test — would require driving alice through
  two add_members calls + capturing two distinct KPs. The unit-level
  ``test_welcome_join_triggers_fire_and_forget_republish`` covers the
  republish wiring; the back-to-back integration test is xfailed
  pending a separate Stage 5.x sub-task.
- KP-lost negative case — covered at the unit level
  (``test_no_bundle_logs_permanent_failure_and_drops``).
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from typing import Any, AsyncIterator, Optional
from unittest.mock import AsyncMock

import pytest
import respx
from httpx import Response

from agentvault_hermes.channel.outbox import WireEnvelope
from agentvault_hermes.channel.secure_channel import SecureChannel
from agentvault_hermes.crypto import MlsGroupState, SigningKeypair


_BASE_URL = "http://av-test.example.com"
_BOB_DEVICE_ID = uuid.UUID("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
_ALICE_DEVICE_ID = uuid.UUID("bbbbbbbb-cccc-dddd-eeee-ffffffffffff")
_CONV_ID = "22222222-2222-2222-2222-222222222222"


def _make_keys() -> SigningKeypair:
    import nacl.signing

    sk = nacl.signing.SigningKey.generate()
    return SigningKeypair(public_key=bytes(sk.verify_key), private_key=bytes(sk))


class _MockedRelay:
    """In-memory Relay that exposes the same surface SecureChannel reads.

    ``rest_base_url`` + ``device_jwt`` are read by
    ``_ensure_pending_key_package`` to build the ad-hoc RestClient (which
    respx intercepts). ``device_id`` matches what the backend would stamp.
    The WS path is mocked: ``connect`` / ``disconnect`` are no-ops;
    ``receive_messages`` yields from an in-memory queue the test controls.
    """

    def __init__(self) -> None:
        self.rest_base_url = _BASE_URL
        self.device_jwt = "test-jwt-bob"
        self.device_id = str(_BOB_DEVICE_ID)
        self._inbound: asyncio.Queue[Optional[WireEnvelope]] = asyncio.Queue()
        self.connect = AsyncMock()
        self.disconnect = AsyncMock()
        self.send_message = AsyncMock()
        self.send_pong = AsyncMock()

    async def receive_messages(self) -> AsyncIterator[WireEnvelope]:
        while True:
            env = await self._inbound.get()
            if env is None:
                return
            yield env

    async def push_inbound(self, env: WireEnvelope) -> None:
        await self._inbound.put(env)

    async def shutdown(self) -> None:
        await self._inbound.put(None)


@pytest.mark.asyncio
async def test_basic_welcome_to_message_roundtrip(
    tmp_path: Any,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """End-to-end: alice creates group + adds bob → respx queues Welcome
    → bob's pull surfaces it → bob joins → mls_states populated →
    application message round-trips.

    Captures bob's published KP via respx so the test can build the
    Welcome with the SAME KP bob's wrapper holds privately.

    Doubles as the operator-visibility regression for action_item #159:
    INFO logs fire on all three Phase 3 success paths (KP publish,
    delivery pull, Welcome join). Pre-#159 the success path was silent
    and operators had to grep absence-of-ERROR to confirm health.
    """
    caplog.set_level(logging.INFO, logger="agentvault_hermes.channel")
    bob_keys = _make_keys()
    alice_keys = _make_keys()

    # Alice will create the group + add bob's KP. We need bob's published
    # KP bytes to do that, so we capture them from the publish call.
    captured_kp_hex: list[str] = []

    async def capture_publish(request: Any) -> Response:
        body = request.read()
        import json

        data = json.loads(body)
        captured_kp_hex.append(data["key_package"])
        return Response(200, json={"id": str(uuid.uuid4()), "device_id": str(_BOB_DEVICE_ID)})

    # State holds the next-pull response so we can swap mid-test.
    pull_response: dict[str, Any] = {"messages": []}

    async def respond_pull(request: Any) -> Response:
        return Response(200, json=pull_response)

    acked_queue_ids: list[str] = []

    async def respond_ack(request: Any) -> Response:
        body = request.read()
        import json

        data = json.loads(body)
        acked_queue_ids.extend(data.get("queue_ids", []))
        return Response(200, json={"acked": len(data.get("queue_ids", []))})

    relay = _MockedRelay()
    on_inbound_received: list[Any] = []
    # asyncio.Event replaces the brittle ``asyncio.sleep(0.1)`` wait pattern
    # the original WS-30 implementation used (action_item #174 — non-
    # deterministic; failed on py3.11 in PR #178 CI when the demux happened
    # to not have processed within the 100ms budget). The handler ``.set()``s
    # the event; the test ``wait_for``s with a generous 2.0s safety cap.
    delivered = asyncio.Event()

    async def on_inbound(msg: Any) -> None:
        on_inbound_received.append(msg)
        delivered.set()

    ch = SecureChannel(
        relay=relay,  # type: ignore[arg-type]
        mls_states={},
        on_inbound=on_inbound,
        data_dir=tmp_path,
        device_keys=bob_keys,
        device_id=_BOB_DEVICE_ID,
        agent_name="bob-agent",
        account_id="acct-bob",
    )

    async def _wait_until(predicate: Any, *, timeout: float = 2.0) -> None:
        """Poll ``predicate`` until truthy or ``timeout`` elapses.

        For state-dict mutations (e.g. ``mls_states`` getting populated by
        the Welcome handler), ``asyncio.Event`` isn't natively available —
        the producer would need a callback to ``.set()`` it, which would
        require modifying production code just for this test. A 10ms poll
        with a 2.0s deadline is a safe alternative: under healthy CI the
        loop terminates within a few iterations; if something is genuinely
        broken the deadline surfaces a clearer error than an "in-flight"
        assertion (action_item #174).
        """
        deadline = asyncio.get_event_loop().time() + timeout
        while not predicate():
            if asyncio.get_event_loop().time() > deadline:
                raise AssertionError(
                    f"_wait_until: predicate stayed falsy for {timeout}s"
                )
            await asyncio.sleep(0.01)

    async with respx.mock(base_url=_BASE_URL, assert_all_called=False) as mock:
        mock.post("/api/v1/mls/key-packages").mock(side_effect=capture_publish)
        mock.get("/api/v1/mls/delivery").mock(side_effect=respond_pull)
        mock.post("/api/v1/mls/delivery/ack").mock(side_effect=respond_ack)

        # --- Step 1: bob.start() — publishes KP, runs first (empty) pull
        await ch.start()
        try:
            assert captured_kp_hex, "publish_key_package was not called"
            bob_kp_hex = captured_kp_hex[0]
            assert ch._pending_kp_state is not None
            assert ch._initial_setup_complete.is_set()

            # --- Step 2: alice creates the group and adds bob's KP.
            alice = MlsGroupState(device_keys=alice_keys, device_id=_ALICE_DEVICE_ID)
            alice.create_group(b"\x42" * 16)
            bob_kp_bytes = bytes.fromhex(bob_kp_hex)
            add_result = alice.add_members([bob_kp_bytes])
            assert add_result.welcome is not None
            welcome_hex = add_result.welcome.hex()

            # --- Step 3: respx pull now returns the welcome row.
            pull_response["messages"] = [
                {
                    "queue_id": "q-welcome-1",
                    "message_id": str(uuid.uuid4()),
                    "group_id": str(uuid.UUID(bytes=alice.group_id)),
                    "message_type": "welcome",
                    "sender_device_id": str(_ALICE_DEVICE_ID),
                    "epoch": 0,
                    "payload": welcome_hex,
                    "room_id": None,
                    "conversation_id": _CONV_ID,
                    "a2a_channel_id": None,
                    "conversation_group_id": None,
                    "created_at": "2026-05-10T00:00:01Z",
                }
            ]

            # --- Step 4: trigger another pull via mls_delivery ping.
            await relay.push_inbound(
                WireEnvelope(event="mls_delivery", data={"count": 1})
            )
            # Wait deterministically for the Welcome to land in mls_states
            # (action_item #174 — was asyncio.sleep(0.1) which raced on py3.11).
            await _wait_until(lambda: _CONV_ID in ch._mls_states)

            # bob has joined the group.
            assert _CONV_ID in ch._mls_states, (
                "Welcome handler did not populate mls_states[conv_id]"
            )
            assert ch._mls_states[_CONV_ID].is_initialized
            assert ch._mls_states[_CONV_ID].epoch == alice.epoch
            assert ch._mls_states[_CONV_ID].group_id == alice.group_id
            # Welcome row was acked.
            await _wait_until(lambda: "q-welcome-1" in acked_queue_ids)
            assert "q-welcome-1" in acked_queue_ids
            # Republish task was scheduled (P3 fire-and-forget). The
            # `_pending_kp_state is None` invariant only holds in the
            # narrow window between ``clear_pending_kp_state`` and the
            # fire-and-forget republish completing — by the time we
            # observe it here, the republish may have repopulated it.
            # The republish-task-non-None assertion is the deterministic
            # signal.
            assert ch._republish_task is not None

            # --- Step 5: alice encrypts an application message; respx
            # surfaces it on next pull; bob's handle_message_mls decrypts.
            ciphertext = alice.encrypt(b"hello bob")
            pull_response["messages"] = [
                {
                    "queue_id": "q-app-1",
                    "message_id": str(uuid.uuid4()),
                    "group_id": str(uuid.UUID(bytes=alice.group_id)),
                    "message_type": "application",
                    "sender_device_id": str(_ALICE_DEVICE_ID),
                    "epoch": alice.epoch,
                    "payload": ciphertext.hex(),
                    "room_id": None,
                    "conversation_id": _CONV_ID,
                    "a2a_channel_id": None,
                    "conversation_group_id": None,
                    "created_at": "2026-05-10T00:00:02Z",
                }
            ]
            await relay.push_inbound(
                WireEnvelope(event="mls_delivery", data={"count": 1})
            )

            # asyncio.Event-based wait — fires the moment ``on_inbound``
            # appends + sets. Was ``asyncio.sleep(0.1)`` which lost the
            # race on py3.11 in PR #178 CI.
            await asyncio.wait_for(delivered.wait(), timeout=2.0)

            assert on_inbound_received, "on_inbound was never called"
            inbound = on_inbound_received[0]
            assert inbound.plaintext == "hello bob"
            assert inbound.conversation_id == _CONV_ID
            # Ack happens AFTER on_inbound dispatch — wait deterministically.
            await _wait_until(lambda: "q-app-1" in acked_queue_ids)
            assert "q-app-1" in acked_queue_ids

            # action_item #159 — operator visibility on all three Phase 3
            # success paths. Substring match (not exact wording) so a
            # future copy-edit doesn't fail this test, but deletion of the
            # log line entirely would. The actual format strings are at
            # secure_channel._ensure_pending_key_package + ._pull_delivery_queue
            # and inbox.handle_mls_welcome.
            log_msgs = [r.message for r in caplog.records]
            assert any("MLS KeyPackage published" in m for m in log_msgs), (
                "action_item #159: expected INFO log on KP publish success "
                "path was missing — operators have no positive signal "
                "that the KP made it to the backend"
            )
            assert any("MLS delivery pull" in m for m in log_msgs), (
                "action_item #159: expected INFO log on delivery-pull "
                "success path was missing — operators can't correlate "
                "incoming Welcome / application rows"
            )
            assert any("Joined MLS group via Welcome" in m for m in log_msgs), (
                "action_item #159: expected INFO log on Welcome-join "
                "success path was missing — operators see no positive "
                "signal that the agent joined the group"
            )
        finally:
            await relay.shutdown()
            await ch.stop()


@pytest.mark.asyncio
async def test_welcome_queued_while_offline(tmp_path: Any) -> None:
    """§7 acceptance #3: a Welcome queued while bob is offline is
    surfaced + processed on bob's first ``start()`` pull-on-connect.

    Differs from the basic test only in that the Welcome row is staged
    in respx BEFORE bob calls start(), simulating "alice created the
    conversation while bob was offline."
    """
    bob_keys = _make_keys()
    alice_keys = _make_keys()

    captured_kp_hex: list[str] = []

    async def capture_publish(request: Any) -> Response:
        body = request.read()
        import json

        data = json.loads(body)
        captured_kp_hex.append(data["key_package"])
        return Response(200, json={"id": str(uuid.uuid4()), "device_id": str(_BOB_DEVICE_ID)})

    pull_response: dict[str, Any] = {"messages": []}
    welcome_hex_holder: list[str] = []

    async def respond_pull(request: Any) -> Response:
        return Response(200, json=pull_response)

    acked: list[str] = []

    async def respond_ack(request: Any) -> Response:
        body = request.read()
        import json

        data = json.loads(body)
        acked.extend(data.get("queue_ids", []))
        return Response(200, json={"acked": len(data.get("queue_ids", []))})

    relay = _MockedRelay()
    on_inbound_received: list[Any] = []

    async def on_inbound(msg: Any) -> None:
        on_inbound_received.append(msg)

    ch = SecureChannel(
        relay=relay,  # type: ignore[arg-type]
        mls_states={},
        on_inbound=on_inbound,
        data_dir=tmp_path,
        device_keys=bob_keys,
        device_id=_BOB_DEVICE_ID,
        agent_name="bob-agent",
        account_id="acct-bob",
    )

    async with respx.mock(base_url=_BASE_URL, assert_all_called=False) as mock:
        mock.post("/api/v1/mls/key-packages").mock(side_effect=capture_publish)
        mock.get("/api/v1/mls/delivery").mock(side_effect=respond_pull)
        mock.post("/api/v1/mls/delivery/ack").mock(side_effect=respond_ack)

        # We can't pre-stage the welcome because we need bob's KP first.
        # In production: alice creates the conv THIS WAY before bob is
        # online. The KP that's used is bob's PRIOR KP — i.e. one
        # published in a previous session. To simulate that, we run a
        # prior bob.start()/stop() cycle to publish a KP, save it, then
        # (without restoring _pending_kp_state across the boundary)
        # construct the welcome against THAT prior KP, queue it, and
        # trigger the new start() — which republishes a fresh KP and
        # then pulls. The welcome SHOULD decrypt against bob's PRIOR
        # _pending_kp_state IF state survived. But `_pending_kp_state`
        # is in-memory only (P5), so a true "offline" cycle would lose
        # it. The §M1 acceptance criterion is operator-visibility on
        # such loss (logged MLS_WELCOME_PERMANENT_FAILURE).
        #
        # For this happy-path test, we instead piggy-back on the SAME
        # SecureChannel instance — start() publishes a KP that's
        # captured + used immediately to build the welcome, then the
        # welcome is queued before the next pull.

        await ch.start()
        try:
            assert captured_kp_hex
            bob_kp_hex = captured_kp_hex[0]
            alice = MlsGroupState(device_keys=alice_keys, device_id=_ALICE_DEVICE_ID)
            alice.create_group(b"\x42" * 16)
            add_result = alice.add_members([bytes.fromhex(bob_kp_hex)])
            welcome_hex_holder.append(add_result.welcome.hex())

            pull_response["messages"] = [
                {
                    "queue_id": "q-welcome-offline",
                    "message_id": str(uuid.uuid4()),
                    "group_id": str(uuid.UUID(bytes=alice.group_id)),
                    "message_type": "welcome",
                    "sender_device_id": str(_ALICE_DEVICE_ID),
                    "epoch": 0,
                    "payload": welcome_hex_holder[0],
                    "room_id": None,
                    "conversation_id": _CONV_ID,
                    "a2a_channel_id": None,
                    "conversation_group_id": None,
                    "created_at": "2026-05-10T00:00:01Z",
                }
            ]

            # Trigger a second pull — simulating the on-reconnect pull
            # finding the queued Welcome.
            await ch._pull_delivery_queue()

            assert _CONV_ID in ch._mls_states
            assert "q-welcome-offline" in acked
        finally:
            await relay.shutdown()
            await ch.stop()


@pytest.mark.asyncio
async def test_welcome_queued_while_offline_kp_lost_acks_and_logs(
    tmp_path: Any,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """P19 / §7 acceptance #7: if bob's KP was rotated mid-cycle (e.g.
    cross-restart loss), the queued Welcome was encrypted to a KP we no
    longer hold. ``join_from_welcome`` raises → handler returns
    drop=True → queue_id is acked → ERROR log with literal
    ``MLS_WELCOME_PERMANENT_FAILURE`` substring.
    """
    bob_keys = _make_keys()
    alice_keys = _make_keys()

    async def capture_publish(request: Any) -> Response:
        return Response(200, json={"id": str(uuid.uuid4()), "device_id": str(_BOB_DEVICE_ID)})

    # Pre-build a Welcome encrypted to a KP we'll then ROTATE away (i.e.
    # overwrite bob's _pending_kp_state with a freshly-allocated unrelated
    # state). Simulates: bob published KP_A, owner created conv with
    # Welcome_A, bob restarted between publish + pull → _pending_kp_state
    # is now KP_B (fresh allocation), but the queued Welcome is for KP_A.
    bob_lost_state = MlsGroupState(device_keys=bob_keys, device_id=_BOB_DEVICE_ID)
    lost_kp = bob_lost_state.generate_key_package()
    alice = MlsGroupState(device_keys=alice_keys, device_id=_ALICE_DEVICE_ID)
    alice.create_group(b"\x42" * 16)
    welcome_for_lost_kp = alice.add_members([lost_kp]).welcome
    assert welcome_for_lost_kp is not None

    pull_response = {
        "messages": [
            {
                "queue_id": "q-welcome-stale",
                "message_id": str(uuid.uuid4()),
                "group_id": str(uuid.UUID(bytes=alice.group_id)),
                "message_type": "welcome",
                "sender_device_id": str(_ALICE_DEVICE_ID),
                "epoch": 0,
                "payload": welcome_for_lost_kp.hex(),
                "room_id": None,
                "conversation_id": _CONV_ID,
                "a2a_channel_id": None,
                "conversation_group_id": None,
                "created_at": "2026-05-10T00:00:01Z",
            }
        ]
    }

    async def respond_pull(request: Any) -> Response:
        return Response(200, json=pull_response)

    acked: list[str] = []

    async def respond_ack(request: Any) -> Response:
        body = request.read()
        import json

        data = json.loads(body)
        acked.extend(data.get("queue_ids", []))
        return Response(200, json={"acked": len(data.get("queue_ids", []))})

    relay = _MockedRelay()
    ch = SecureChannel(
        relay=relay,  # type: ignore[arg-type]
        mls_states={},
        on_inbound=AsyncMock(),
        data_dir=tmp_path,
        device_keys=bob_keys,
        device_id=_BOB_DEVICE_ID,
        agent_name="bob-agent",
        account_id="acct-bob",
    )

    async with respx.mock(base_url=_BASE_URL, assert_all_called=False) as mock:
        mock.post("/api/v1/mls/key-packages").mock(side_effect=capture_publish)
        mock.get("/api/v1/mls/delivery").mock(side_effect=respond_pull)
        mock.post("/api/v1/mls/delivery/ack").mock(side_effect=respond_ack)

        with caplog.at_level(
            logging.ERROR, logger="agentvault_hermes.channel.inbox"
        ):
            await ch.start()
            try:
                # ROTATE: the welcome is encrypted to lost_kp, but
                # ch._pending_kp_state is now a NEW MlsGroupState created
                # by start()'s _ensure_pending_key_package — it doesn't
                # hold the private material for lost_kp.
                # Trigger a second pull — the queued welcome surfaces.
                await ch._pull_delivery_queue()
            finally:
                await relay.shutdown()
                await ch.stop()

    # P14 invariant: PERMANENT_FAILURE marker logged.
    assert any(
        "MLS_WELCOME_PERMANENT_FAILURE" in r.message for r in caplog.records
    )
    # Queue_id was acked (not nacked → not dead-lettered).
    assert "q-welcome-stale" in acked
