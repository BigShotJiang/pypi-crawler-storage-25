"""WS-27 — Phase 2 capabilities smoke demo.

A single end-to-end test that imports every public crypto surface, walks
through the four Phase 2 primitives (X3DH bootstrap → Double Ratchet
exchange → MLS group create+encrypt+decrypt → persistence round trip), and
asserts each contract. Runtime well under 10 seconds.

This is **smoke**, not coverage. Deep coverage lives in:

- ``tests/unit/crypto/`` — primitive-level unit tests (~150 tests).
- ``tests/unit/crypto/vectors/`` — OC byte-equality + MLS structural tests
  (18 + 4 documented xfails).
- ``tests/integration/test_crypto_*.py`` — cross-module integration tests
  shipped in WS-25 (11 tests covering full lifecycle, persistence,
  out-of-order delivery, telemetry).

When this file fails, expect a packaging-level break: the wheel didn't
install, a public symbol moved, or the protocol composition lost a contract.
Use the deep tests for diagnosis.

Phase 2 acceptance criteria (per ``docs/plans/2026-05-07-hermes-phase2-design.md``):

1. **DR roundtrip** — exercised below + extensively in WS-25 / WS-24 tests.
2. **MLS group bootstrap** — exercised below + WS-25's 3-member lifecycle.
3. **Wheel install + ``Group.export_secret`` patch** — ``import mls_rs_uniffi``
   running at all confirms the wheel; ``hasattr`` confirms our fork's
   additive UniFFI method survived publication.
4. **Recorded vector cross-check** — delegated to the standard suite at
   ``tests/unit/crypto/vectors/`` (12 fixtures × 3 protocols, see WS-24).
"""
from __future__ import annotations

import os
import uuid

import mls_rs_uniffi as _mls

from agentvault_hermes.core.identity import generate_device_keys
from agentvault_hermes.crypto.mls_group import DEFAULT_CIPHERSUITE, MlsGroupState
from agentvault_hermes.crypto.persistence import (
    ConversationMeta,
    read_meta,
    write_meta,
)
from agentvault_hermes.crypto.primitives import xchacha20_decrypt, xchacha20_encrypt
from agentvault_hermes.crypto.ratchet import (
    DoubleRatchet,
    SigningKeypair,
    _generate_dh_keypair,
)
from agentvault_hermes.crypto.x3dh import X3DHParams, perform_x3dh

from datetime import datetime, timezone
from pathlib import Path


def _signing_keypair() -> SigningKeypair:
    """Build a SigningKeypair from a fresh Ed25519 seed (32-byte)."""
    from nacl import signing as nacl_signing

    sk = nacl_signing.SigningKey.generate()
    return SigningKeypair(public_key=bytes(sk.verify_key), private_key=bytes(sk))


def _signing_kp_from_device_keys(dk: object) -> SigningKeypair:
    """Mirror the WS-25 adapter — DeviceKeys.signing_secret holds the 32-byte
    Ed25519 seed; SigningKeypair.private_key takes the seed (not 64-byte sk)."""
    return SigningKeypair(
        public_key=dk.signing_public,  # type: ignore[attr-defined]
        private_key=dk.signing_secret,  # type: ignore[attr-defined]
    )


def test_phase_2_acceptance_demo(tmp_path: Path) -> None:
    """Phase 2 smoke: every public crypto surface participates in one run.

    Failure signature is an entire-stack break (packaging, wheel, public-API
    rename). Localized regressions surface in the deeper test suites.
    """

    # --- Criterion 3: Wheel install + Group.export_secret patch present ---
    # Importing _mls above didn't blow up — the agentvault-mls-rs-uniffi
    # wheel resolved. The hasattr check confirms our fork's additive
    # UniFFI method was published (motiveflowllc/mls-rs branch
    # agentvault/uniffi-export-secret-and-message-bytes).
    assert hasattr(_mls.Group, "export_secret"), (
        "agentvault-mls-rs-uniffi wheel is missing Group.export_secret — "
        "either the upstream wheel is installed instead of motiveflowllc's, "
        "or the fork's additive patch regressed."
    )

    # --- Criterion 1: X3DH → DR bootstrap and exchange ---
    a_id = _signing_keypair()
    a_eph = _generate_dh_keypair()
    b_id = _signing_keypair()
    b_eph = _generate_dh_keypair()

    a_shared = perform_x3dh(
        X3DHParams(
            my_identity_private=a_id.private_key,
            my_ephemeral_private=a_eph.private_key,
            their_identity_public=b_id.public_key,
            their_ephemeral_public=b_eph.public_key,
            is_initiator=True,
        )
    )
    b_shared = perform_x3dh(
        X3DHParams(
            my_identity_private=b_id.private_key,
            my_ephemeral_private=b_eph.private_key,
            their_identity_public=a_id.public_key,
            their_ephemeral_public=a_eph.public_key,
            is_initiator=False,
        )
    )
    assert a_shared == b_shared, "X3DH must agree on the shared secret"

    rt_a = DoubleRatchet.init_initiator(
        shared_secret=a_shared,
        identity_keypair=a_id,
        peer_identity_public_key=b_id.public_key,
    )
    rt_b = DoubleRatchet.init_receiver(
        shared_secret=b_shared,
        identity_keypair=b_id,
        peer_identity_public_key=a_id.public_key,
    )
    msg = rt_a.encrypt(b"phase 2 smoke", header_encryption=False)
    assert rt_b.decrypt(msg) == b"phase 2 smoke"

    # --- Bonus: bare AEAD primitive still wires up ---
    aad_key = os.urandom(32)
    aad_nonce = os.urandom(24)
    ct = xchacha20_encrypt(b"primitive smoke", aad_key, aad_nonce, ad=b"ad")
    assert xchacha20_decrypt(ct, aad_key, aad_nonce, ad=b"ad") == b"primitive smoke"

    # --- Criterion 2: MLS group bootstrap + decrypt ---
    alice_dk = generate_device_keys()
    bob_dk = generate_device_keys()
    alice = MlsGroupState(
        device_keys=_signing_kp_from_device_keys(alice_dk),
        device_id=uuid.uuid4(),
        ciphersuite=DEFAULT_CIPHERSUITE,
    )
    bob = MlsGroupState(
        device_keys=_signing_kp_from_device_keys(bob_dk),
        device_id=uuid.uuid4(),
        ciphersuite=DEFAULT_CIPHERSUITE,
    )

    group_id = uuid.uuid4().bytes  # 16-byte; create_group requires bytes
    alice.create_group(group_id)
    assert alice.epoch == 0

    bob_kp = bob.generate_key_package()
    add_result = alice.add_members([bob_kp])
    assert add_result.welcome is not None
    bob.join_from_welcome(add_result.welcome)

    wire = alice.encrypt(b"to bob")
    decrypted = bob.decrypt(wire)
    assert decrypted.is_handshake is False
    assert decrypted.plaintext == b"to bob"

    # --- Persistence cross-cut: meta round-trip ---
    cid = uuid.uuid4()
    meta = ConversationMeta(
        conversation_id=cid,
        type="room",
        created_at=datetime.now(timezone.utc),
        last_message_ts=None,
    )
    write_meta(tmp_path, cid, meta)
    loaded = read_meta(tmp_path, cid)
    assert loaded.conversation_id == cid
    assert loaded.type == "room"
