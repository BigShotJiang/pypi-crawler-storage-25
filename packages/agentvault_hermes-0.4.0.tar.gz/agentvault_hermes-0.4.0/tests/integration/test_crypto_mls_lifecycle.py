"""Integration: MLS group create → add → encrypt → process → remove → encrypt.

Phase 2 plan §4384-4426 originally prescribed this scenario but with an
MlsGroupState API that doesn't exist (`create_initial`, `_build_key_package`,
`from_welcome`, `add_member` (singular), unified `process()` returning
`ev.plaintext.content`). The actual API is:

    state = MlsGroupState(device_keys, device_id)
    state.create_group(group_id: bytes)
    state.generate_key_package() -> bytes
    state.join_from_welcome(welcome_bytes)
    state.add_members([kp_bytes, ...]) -> AddMembersResult(commit, welcome)
    state.remove_member(leaf_index) -> RemoveMemberResult(commit)
    state.encrypt(plaintext) -> bytes
    state.decrypt(message_bytes) -> DecryptResult(plaintext, is_handshake)
    state.process_commit(commit_bytes) -> None

The conceptual scenario (3-member full lifecycle: create→add×2→encrypt→
process→remove→encrypt) is preserved end-to-end with the real API.

Cross-module surface exercised:
    core.identity.generate_device_keys      → DeviceKeys
    SigningKeypair built from DeviceKeys    → MlsGroupState constructor
    create_group → add_members → encrypt → decrypt → remove_member → encrypt
"""
from __future__ import annotations

import uuid

import pytest

from agentvault_hermes.core.identity import DeviceKeys, generate_device_keys
from agentvault_hermes.crypto import MlsGroupState, SigningKeypair


def _signing_kp_from_device_keys(dk: DeviceKeys) -> SigningKeypair:
    """Construct an MLS-compatible SigningKeypair from a freshly-generated
    DeviceKeys. DeviceKeys.signing_secret is the 32-byte Ed25519 seed (matches
    SigningKeypair.private_key contract — see ratchet.py:55-58)."""
    return SigningKeypair(
        public_key=dk.signing_public,
        private_key=dk.signing_secret,
    )


def _make_state() -> MlsGroupState:
    """Build a fresh MlsGroupState with a new identity. Wraps the
    DeviceKeys → SigningKeypair conversion so tests stay readable."""
    dk = generate_device_keys()
    return MlsGroupState(
        device_keys=_signing_kp_from_device_keys(dk),
        device_id=uuid.uuid4(),
    )


def test_three_member_full_lifecycle() -> None:
    """End-to-end: A creates, adds B, B joins; A adds C, B processes commit,
    C joins; A encrypts → B+C both decrypt; A removes B; A encrypts → C still
    decrypts; B (kicked) cannot decrypt new messages.

    Mirrors plan §4396-4425's intent with the real MlsGroupState API.
    """
    grp_a = _make_state()
    grp_b = _make_state()
    grp_c = _make_state()

    # Group identifier is opaque bytes (RFC 9420 §8.1). Use a stable 16-byte
    # constant so the test is repeatable.
    group_id = b"\x42" * 16

    # A creates and adds B; B joins via Welcome.
    grp_a.create_group(group_id)
    add_b = grp_a.add_members([grp_b.generate_key_package()])
    assert add_b.welcome is not None
    grp_b.join_from_welcome(add_b.welcome)
    assert grp_b.is_initialized
    assert grp_b.group_id == grp_a.group_id
    # Note: in mls-rs-uniffi 0.1.0 the join-from-welcome flow does not produce
    # an epoch storage record on its own (epochs are persisted on subsequent
    # commits), so MlsGroupState.epoch reads back as 0 for fresh joiners until
    # they process the next commit. This matches the unit-test pattern in
    # test_mls_group.py — group_id parity is enough to confirm the join.

    # A adds C; B processes the commit (epoch advances), C joins via Welcome.
    add_c = grp_a.add_members([grp_c.generate_key_package()])
    assert add_c.welcome is not None
    grp_b.process_commit(add_c.commit)
    grp_c.join_from_welcome(add_c.welcome)
    # After processing add_c, B has the same epoch as A. C's epoch lags until
    # she processes the next commit (see note above).
    assert grp_a.epoch == grp_b.epoch
    assert grp_c.group_id == grp_a.group_id

    # A → all members. The same wire bytes decrypt for both B and C.
    wire = grp_a.encrypt(b"to all members")
    res_b = grp_b.decrypt(wire)
    res_c = grp_c.decrypt(wire)
    assert res_b.is_handshake is False
    assert res_c.is_handshake is False
    assert res_b.plaintext == b"to all members"
    assert res_c.plaintext == b"to all members"

    # A removes B (leaf 1: A=0, B=1, C=2). C processes the remove commit so
    # her epoch advances; B does too, even though he's about to be cut off.
    epoch_before_remove = grp_a.epoch
    remove_result = grp_a.remove_member(leaf_index=1)
    grp_c.process_commit(remove_result.commit)
    grp_b.process_commit(remove_result.commit)  # B sees the kick commit
    assert grp_a.epoch > epoch_before_remove

    # After removal, A → C still works.
    wire2 = grp_a.encrypt(b"only C now")
    res_c2 = grp_c.decrypt(wire2)
    assert res_c2.is_handshake is False
    assert res_c2.plaintext == b"only C now"

    # Forward-secrecy sanity: B (kicked) cannot decrypt the post-removal
    # message. mls_rs raises an mls_rs_uniffi.Error rather than returning
    # None. Tighter exception class than `Exception` so a future regression
    # that swaps "B raises" for "B silently returns garbage" can't pass this
    # test.
    import mls_rs_uniffi as _mls_module

    with pytest.raises(_mls_module.Error):
        grp_b.decrypt(wire2)
