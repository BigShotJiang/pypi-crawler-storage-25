"""Shared Hermes-runtime mocks installed via ``sys.modules`` patching.

The agentvault gateway-platform adapter at
``agentvault_hermes.plugins.agentvault.adapter`` imports

    from gateway.platforms.base import (BasePlatformAdapter, MessageEvent,
                                        MessageType, SendResult)
    from gateway.config import Platform
    from gateway.session import SessionSource

at module load time. ``gateway`` is provided by Hermes' runtime and is NOT
on ``sys.path`` in our test virtualenv. Tests must inject minimal stand-ins
into ``sys.modules`` BEFORE the adapter module is imported.

This module is the SINGLE SOURCE OF TRUTH for those stand-ins. Both
``tests/unit/plugins/test_adapter.py`` and
``tests/integration/test_phase3_demo.py`` (and any future test that touches
the adapter) MUST call ``install_gateway_mocks()`` here rather than inlining
their own copies — DA WS-34 MAJOR-1: duplicating the fakes invites silent
drift between the two definitions, so a future field added to one but not
the other would have a test pass against the wrong shape.

The fakes mirror the real Hermes types' shapes as verified at WS-28.0
pre-flight. The contract anchors:

* ``BasePlatformAdapter.__init__(self, config, platform)`` — the adapter
  calls ``super().__init__(config=config, platform=Platform("agentvault"))``.
  The fake stores both as instance attributes.
* ``MessageEvent`` accepts ``text``, ``message_type``, ``source``,
  ``message_id`` kwargs.
* ``SessionSource`` accepts ``platform``, ``chat_id``, ``chat_type``,
  ``user_id``, ``message_id`` kwargs.
* ``SendResult`` accepts ``success``, ``message_id``, ``error``,
  ``retryable`` kwargs.
* ``Platform("agentvault")`` returns an object with a ``.value`` attribute.

If the real Hermes types add a field, mirror it here ONCE and every test
gets the update for free.
"""
from __future__ import annotations

import sys
import types
from types import SimpleNamespace
from typing import Any
from unittest.mock import MagicMock


def install_gateway_mocks() -> None:
    """Idempotently inject ``gateway.*`` stand-ins into ``sys.modules``.

    Safe to call multiple times — the ``if "name" not in sys.modules`` guard
    means the second caller reuses the first caller's module objects.
    """
    if "gateway" not in sys.modules:
        sys.modules["gateway"] = types.ModuleType("gateway")

    if "gateway.platforms" not in sys.modules:
        sys.modules["gateway.platforms"] = types.ModuleType("gateway.platforms")

    if "gateway.platforms.base" not in sys.modules:
        base_mod = types.ModuleType("gateway.platforms.base")

        class _BasePlatformAdapter:
            """Mirrors the real signature: ``__init__(self, config, platform)``.

            Bug B (action_item #163) regression: the real Hermes
            ``BasePlatformAdapter.handle_message`` is the dispatch entry
            point that spawns ``_process_message_background`` → calls
            ``_message_handler`` → dispatches via ``_send_with_retry``.
            Our stub forwards to ``_message_handler`` so existing test
            semantics hold; the dedicated regression test in
            ``test_adapter.py`` patches ``handle_message`` to verify the
            adapter dispatches through it (not the handler directly).
            """

            def __init__(self, config: Any = None, platform: Any = None) -> None:
                self.config = config
                self.platform = platform
                self._message_handler: Any = None

            async def handle_message(self, event: Any) -> None:
                # Approximation of base.py:2660 — spawns background work in
                # the real Hermes; here we just delegate so the test fakes
                # see the same eventual handler invocation.
                if self._message_handler is None:
                    return
                await self._message_handler(event)

        class _MessageType:
            TEXT = "text"

        class _MessageEvent:
            def __init__(
                self,
                text: str = "",
                message_type: Any = None,
                source: Any = None,
                message_id: Any = None,
            ) -> None:
                self.text = text
                self.message_type = message_type
                self.source = source
                self.message_id = message_id

        class _SendResult:
            def __init__(
                self,
                success: bool,
                message_id: Any = None,
                error: Any = None,
                retryable: bool = False,
            ) -> None:
                self.success = success
                self.message_id = message_id
                self.error = error
                self.retryable = retryable

        base_mod.BasePlatformAdapter = _BasePlatformAdapter  # type: ignore[attr-defined]
        base_mod.MessageType = _MessageType  # type: ignore[attr-defined]
        base_mod.MessageEvent = _MessageEvent  # type: ignore[attr-defined]
        base_mod.SendResult = _SendResult  # type: ignore[attr-defined]
        sys.modules["gateway.platforms.base"] = base_mod

    if "gateway.config" not in sys.modules:
        config_mod = types.ModuleType("gateway.config")
        # ``Platform("agentvault")`` returns a SimpleNamespace with
        # ``.value == "agentvault"``. ``MagicMock(side_effect=...)`` preserves
        # call-tracking (so tests can assert on call args) while returning a
        # fresh namespace per call.
        config_mod.Platform = MagicMock(  # type: ignore[attr-defined]
            side_effect=lambda v: SimpleNamespace(value=v)
        )
        sys.modules["gateway.config"] = config_mod

    if "gateway.session" not in sys.modules:
        session_mod = types.ModuleType("gateway.session")

        class _SessionSource:
            def __init__(
                self,
                platform: Any = None,
                chat_id: Any = None,
                chat_type: str = "dm",
                user_id: Any = None,
                message_id: Any = None,
            ) -> None:
                self.platform = platform
                self.chat_id = chat_id
                self.chat_type = chat_type
                self.user_id = user_id
                self.message_id = message_id

        session_mod.SessionSource = _SessionSource  # type: ignore[attr-defined]
        sys.modules["gateway.session"] = session_mod
