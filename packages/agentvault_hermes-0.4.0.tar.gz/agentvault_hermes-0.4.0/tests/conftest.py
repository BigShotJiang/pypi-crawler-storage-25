import pytest
from pathlib import Path


@pytest.fixture
def fake_hermes_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect $HOME so resolve_data_dir() places things under tmp_path."""
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.delenv("AGENTVAULT_HERMES_DATA_DIR", raising=False)
    # Clear HERMES_HOME so resolve_data_dir() falls through to HOME-rooted
    # default. Without this, a developer shell or CI step exporting
    # HERMES_HOME would shadow the fixture's HOME redirect.
    monkeypatch.delenv("HERMES_HOME", raising=False)
    return tmp_path


@pytest.fixture
def tmp_data_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """A throwaway directory used as AGENTVAULT_HERMES_DATA_DIR base in tests.

    Tests are responsible for setting AGENTVAULT_HERMES_DATA_DIR themselves
    so the override is visible to module-level code.
    """
    monkeypatch.delenv("AGENTVAULT_HERMES_API_URL", raising=False)
    monkeypatch.delenv("AGENTVAULT_HERMES_AGENT_NAME", raising=False)
    monkeypatch.delenv("AGENTVAULT_HERMES_HTTP_PORT", raising=False)
    return tmp_path
