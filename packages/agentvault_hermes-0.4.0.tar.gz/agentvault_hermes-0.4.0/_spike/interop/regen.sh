#!/usr/bin/env bash
# Regenerate the patched mls-rs-uniffi build artifacts (.dylib + Python wrapper)
# for the Phase 0 interop spike. Run from any directory.
#
# Prerequisites:
#   - Rust toolchain (rustup) on PATH
#   - awslabs/mls-rs cloned at ../../../../mls-rs-spike/mls-rs (or set MLS_RS_DIR)
#   - Homebrew openssl@3 installed at /opt/homebrew/opt/openssl@3 (or set OPENSSL_DIR)
#   - The mls-rs clone has the AgentVault export_secret patch applied
#
# Run: bash regen.sh
set -euo pipefail

SPIKE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
MLS_RS_DIR="${MLS_RS_DIR:-$HOME/Documents/Projects/mls-rs-spike/mls-rs}"
OPENSSL_DIR="${OPENSSL_DIR:-/opt/homebrew/opt/openssl@3}"

if [ ! -d "$MLS_RS_DIR" ]; then
  echo "mls-rs not found at $MLS_RS_DIR" >&2
  echo "Clone it: git clone https://github.com/awslabs/mls-rs.git \"$MLS_RS_DIR\"" >&2
  exit 1
fi

cd "$MLS_RS_DIR"
OPENSSL_DIR="$OPENSSL_DIR" cargo build -p mls-rs-uniffi --release
OPENSSL_DIR="$OPENSSL_DIR" cargo run -p uniffi-bindgen --release --quiet -- \
  generate \
  --library "$MLS_RS_DIR/target/release/libmls_rs_uniffi.dylib" \
  --language python \
  --out-dir "$SPIKE_DIR" \
  --no-format

cp "$MLS_RS_DIR/target/release/libmls_rs_uniffi.dylib" "$SPIKE_DIR/"

echo "regenerated:"
echo "  $SPIKE_DIR/mls_rs_uniffi.py"
echo "  $SPIKE_DIR/libmls_rs_uniffi.dylib"
