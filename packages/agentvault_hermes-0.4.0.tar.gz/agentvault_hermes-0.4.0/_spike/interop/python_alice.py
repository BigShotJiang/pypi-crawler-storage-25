"""Python side of the mls-rs-uniffi ↔ ts-mls interop spike.

Step 1 of the interop test: Alice (using mls-rs-uniffi) generates her MLS
KeyPackage and writes the wire-format bytes to ./artifacts/alice_kp.bin.

Step 2 (later): we hand alice_kp.bin to a Node script that uses ts-mls to
verify it parses cleanly — this is our wire-format interop check.

Run: DYLD_LIBRARY_PATH=. python python_alice.py
"""
from __future__ import annotations

import os
import pathlib
import sys

import mls_rs_uniffi as m

ARTIFACTS = pathlib.Path(__file__).parent / "artifacts"
ARTIFACTS.mkdir(exist_ok=True)


def main() -> int:
    config = m.client_config_default()
    key = m.generate_signature_keypair(m.CipherSuite.CURVE25519_AES128)
    alice = m.Client(b"alice", key, config)

    kp_message = alice.generate_key_package_message()
    kp_bytes = kp_message.to_bytes()

    out = ARTIFACTS / "alice_kp.bin"
    out.write_bytes(kp_bytes)

    print(f"wrote {len(kp_bytes)} bytes to {out}")
    print(f"first 16 bytes (hex): {kp_bytes[:16].hex()}")
    print("(RFC 9420 KeyPackage wire format — feed to ts-mls for interop check)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
