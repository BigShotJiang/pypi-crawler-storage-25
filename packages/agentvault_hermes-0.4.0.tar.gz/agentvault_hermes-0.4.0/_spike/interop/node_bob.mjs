// Node side of the mls-rs-uniffi <-> ts-mls interop spike.
//
// Reads ./artifacts/alice_kp.bin (a KeyPackage produced by Python alice via
// mls-rs-uniffi) and decodes it with ts-mls's RFC 9420 decoder. If the bytes
// parse cleanly into a KeyPackage with the fields we expect, the two libraries
// agree on the wire format and Phase 0 has its interop signal.
//
// Run:  node node_bob.mjs

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

// Resolve ts-mls from the workspace's packages/crypto install — npm workspace
// hoisting at the agentvault-gen2 root collides with @noble/hashes versions if
// we install ts-mls locally in this _spike/interop directory.
import { decodeMlsMessage } from "../../../crypto/node_modules/ts-mls/dist/src/index.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const kpPath = path.join(here, "artifacts", "alice_kp.bin");
const kpBytes = fs.readFileSync(kpPath);

console.log(`read ${kpBytes.length} bytes from ${kpPath}`);
console.log(`first 16 bytes (hex): ${kpBytes.subarray(0, 16).toString("hex")}`);

const result = decodeMlsMessage(new Uint8Array(kpBytes), 0);
if (result === undefined) {
  console.error("decodeMlsMessage returned undefined — wire format incompatible");
  process.exit(2);
}
const [msg, consumed] = result;

console.log(`decoded successfully: consumed ${consumed} of ${kpBytes.length} bytes`);
console.log(`  protocol version: ${msg.version}`);
console.log(`  wire format:      ${msg.wireformat}`);

if (msg.wireformat !== "mls_key_package") {
  console.error(`expected wireformat=mls_key_package, got ${msg.wireformat}`);
  process.exit(3);
}

const kp = msg.keyPackage;
console.log(`  KeyPackage:`);
console.log(`    version:        ${kp.version}`);
console.log(`    cipher_suite:   ${kp.cipherSuite}`);
console.log(`    init_key:       ${kp.initKey.length} bytes`);
console.log(`    leaf_node:      credential.type=${kp.leafNode.credential.credentialType}`);

const cred = kp.leafNode.credential;
if (cred.credentialType === "basic") {
  const identity = Buffer.from(cred.identity).toString("utf8");
  console.log(`    identity:       "${identity}"`);
  if (identity !== "alice") {
    console.error(`expected identity="alice", got "${identity}"`);
    process.exit(4);
  }
}

console.log("");
console.log("✓ ts-mls successfully parsed mls-rs-uniffi's KeyPackage");
console.log("✓ wire format compatibility CONFIRMED for KeyPackage at protocol version + cipher suite 1");
