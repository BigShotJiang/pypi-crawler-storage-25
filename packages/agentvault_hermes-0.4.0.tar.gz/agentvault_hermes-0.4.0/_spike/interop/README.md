# Phase 0 interop spike — `mls-rs-uniffi` ↔ `ts-mls`

Validates that a patched `mls-rs-uniffi` Python build produces RFC 9420
wire-format messages that `ts-mls` (already in `packages/crypto/`) can parse.
The spike is the WS-3.x deliverable of Phase 0; full findings live in
`docs/plans/2026-05-06-hermes-phase0-findings.md`.

## Files

- `python_alice.py` — generates an MLS KeyPackage via patched `mls-rs-uniffi`,
  writes the wire bytes to `artifacts/alice_kp.bin`.
- `node_bob.mjs` — reads `artifacts/alice_kp.bin`, parses with `ts-mls`,
  asserts every field. Resolves `ts-mls` from `../../../crypto/node_modules/`
  to avoid the workspace-hoist `@noble/hashes` collision.
- `regen.sh` — rebuilds the patched `mls-rs-uniffi` dylib + Python wrapper.
- `mls-rs-uniffi-agentvault.patch` — the `mls-rs` patch that adds
  `Group.export_secret`, `Message.to_bytes`, `Message.from_bytes`, and a test.

## Prerequisites (one-time)

1. **Rust toolchain** — `curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh`
2. **Homebrew openssl@3** — `brew install openssl@3`
3. **Clone `awslabs/mls-rs`** alongside this repo:
   ```bash
   git clone https://github.com/awslabs/mls-rs.git ~/Documents/Projects/mls-rs-spike/mls-rs
   cd ~/Documents/Projects/mls-rs-spike/mls-rs
   git checkout e96b484e1bc5e90161d532b192b71f696e1a06b9   # the audited commit
   git apply <path-to-this-repo>/packages/plugin-hermes/_spike/interop/mls-rs-uniffi-agentvault.patch
   ```
4. **Plugin venv** — `cd packages/plugin-hermes && python3 -m venv .venv && source .venv/bin/activate && pip install -e ".[dev]"`

## Run

```bash
# 1. Build patched dylib + Python wrapper
bash regen.sh

# 2. Generate KeyPackage from Python (mls-rs-uniffi)
source ../../.venv/bin/activate
DYLD_LIBRARY_PATH=. python python_alice.py

# 3. Parse it from Node (ts-mls)
node node_bob.mjs
```

Expected output ends with:
```
✓ ts-mls successfully parsed mls-rs-uniffi's KeyPackage
✓ wire format compatibility CONFIRMED for KeyPackage at protocol version + cipher suite 1
```

## Why a separate `mls-rs` clone?

Patching mls-rs in-tree would mean vendoring all 19 mls-rs workspace crates
into agentvault-gen2 — tens of thousands of lines of Rust we don't own.
Keeping the clone external + applying our patch via `git apply` preserves
the upstream commit history and makes it trivial to rebase onto upstream
updates. Production builds will eventually reference a published
`motiveflowllc/mls-rs` fork (or the patches will land upstream).
