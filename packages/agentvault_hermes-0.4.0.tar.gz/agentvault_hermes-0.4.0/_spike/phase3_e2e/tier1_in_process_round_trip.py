"""Phase 3 Spike Tier 1 — in-process 1:1 round-trip.

Goal: validate that the WS-22..25 API composes cleanly for a 1:1
conversation lifecycle, including persistence + reload.

Steps (mirrors the Phase 3 design doc demo shape):
    1. Build two MlsGroupState instances ("owner", "agent").
    2. owner.create_group(group_id) → owner.add_members([agent_kp])
       → agent.join_from_welcome(welcome).
    3. owner → agent: encrypt/decrypt round-trip.
    4. agent → owner: encrypt/decrypt round-trip (reverse direction).
       NOTE: requires agent to process the previous commit first; see
       comments below.
    5. Persist agent state via export_state + write_meta.
    6. Reload agent from disk; verify it can still decrypt.

This is a SPIKE: no production code is modified. Output is structured
"Tier 1 passed" / "Tier 1 failed: <reason>" so the CI-style invocation
in SPIKE_FINDINGS.md can grep for it.

Run from packages/plugin-hermes:
    uv run python _spike/phase3_e2e/tier1_in_process_round_trip.py
"""
from __future__ import annotations

import sys
import tempfile
import traceback
import uuid
from datetime import datetime, timezone
from pathlib import Path

from agentvault_hermes.core.identity import DeviceKeys, generate_device_keys
from agentvault_hermes.crypto import MlsGroupState, SigningKeypair
from agentvault_hermes.crypto.persistence import (
    ConversationMeta,
    read_meta,
    write_meta,
)


_STATE_FILE_NAME = "mls_state.bin"


def _signing_kp_from_device_keys(dk: DeviceKeys) -> SigningKeypair:
    """WS-25 pattern (test_crypto_mls_lifecycle.py:36)."""
    return SigningKeypair(
        public_key=dk.signing_public,
        private_key=dk.signing_secret,
    )


def _save_mls_state(data_dir: Path, conv_id: uuid.UUID, blob: bytes) -> None:
    conv_dir = data_dir / "conversations" / str(conv_id)
    conv_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    (conv_dir / _STATE_FILE_NAME).write_bytes(blob)


def _load_mls_state(data_dir: Path, conv_id: uuid.UUID) -> bytes:
    return (
        data_dir / "conversations" / str(conv_id) / _STATE_FILE_NAME
    ).read_bytes()


def _make_state(label: str) -> tuple[MlsGroupState, SigningKeypair, uuid.UUID]:
    """Build a fresh MlsGroupState and return (state, signing_kp, device_id).
    The signing keypair + device_id are returned so we can rebuild the
    wrapper post-restart with the same identity material.
    """
    dk = generate_device_keys()
    signing = _signing_kp_from_device_keys(dk)
    device_id = uuid.uuid4()
    state = MlsGroupState(device_keys=signing, device_id=device_id)
    print(f"  [{label}] device_id={device_id} signing_pub={signing.public_key.hex()[:16]}...")
    return state, signing, device_id


def run_tier1() -> None:
    """Full Tier 1 scenario. Raises on any unexpected behavior."""
    print("\n=== Tier 1: in-process 1:1 round-trip ===\n")

    # --- Step 1: build owner + agent ----------------------------------------
    print("[1/6] Build owner + agent MlsGroupState instances")
    owner, owner_signing, owner_device_id = _make_state("owner")
    agent, _agent_signing, _agent_device_id = _make_state("agent")

    # --- Step 2: owner creates group, adds agent, agent joins ---------------
    print("\n[2/6] owner.create_group → add_members → agent.join_from_welcome")
    group_id = b"\x42" * 16
    owner.create_group(group_id)
    print(f"  owner.is_initialized={owner.is_initialized} epoch={owner.epoch}")

    agent_kp = agent.generate_key_package()
    print(f"  agent_kp len={len(agent_kp)} bytes (sanity check: nonzero)")
    assert len(agent_kp) > 0, "agent KeyPackage is empty"

    add_result = owner.add_members([agent_kp])
    print(f"  add_members → commit={len(add_result.commit)}b welcome={len(add_result.welcome) if add_result.welcome else 0}b")
    assert add_result.welcome is not None, "no welcome produced"

    agent.join_from_welcome(add_result.welcome)
    print(f"  agent.is_initialized={agent.is_initialized}")
    assert agent.is_initialized
    # Note (from WS-25 test_three_member_full_lifecycle): the joiner's epoch
    # reads back as 0 in mls-rs-uniffi 0.1.0 until they process a subsequent
    # commit. group_id parity is the join indicator.
    assert agent.group_id == owner.group_id, "group_id mismatch after join"

    # --- Step 3: owner → agent, plaintext round-trip ------------------------
    print("\n[3/6] owner.encrypt → agent.decrypt")
    msg_owner = b"hello from owner"
    wire_owner = owner.encrypt(msg_owner)
    print(f"  wire bytes len={len(wire_owner)}")

    res = agent.decrypt(wire_owner)
    print(f"  agent.decrypt → is_handshake={res.is_handshake} plaintext={res.plaintext!r}")
    assert res.plaintext == msg_owner, f"owner→agent plaintext mismatch: {res.plaintext!r}"
    assert res.is_handshake is False

    # --- Step 4: agent → owner, reverse-direction round-trip ----------------
    # Per OC's mls-conversation.test.ts pattern + WS-25 test_three_member_full_lifecycle,
    # bidirectional encryption only works once both sides agree on the active
    # epoch. Since the joiner came in via Welcome WITHOUT processing a commit
    # of their own, agent.epoch may still be 0 in 0.1.0. We probe whether
    # the wrapper supports immediate reverse encryption — if it doesn't,
    # log it as a Phase 3 finding rather than failing the whole spike.
    print("\n[4/6] agent.encrypt → owner.decrypt (reverse direction)")
    print(f"  pre-encrypt: owner.epoch={owner.epoch} agent.epoch={agent.epoch}")
    reverse_supported = False
    reverse_error: str | None = None
    try:
        msg_agent = b"hello from agent"
        wire_agent = agent.encrypt(msg_agent)
        print(f"  wire bytes len={len(wire_agent)}")
        res2 = owner.decrypt(wire_agent)
        print(f"  owner.decrypt → is_handshake={res2.is_handshake} plaintext={res2.plaintext!r}")
        assert res2.plaintext == msg_agent
        reverse_supported = True
    except Exception as e:  # noqa: BLE001 — spike: catch-all to record finding
        reverse_error = f"{type(e).__name__}: {e}"
        print(f"  ! reverse direction raised: {reverse_error}")
        print("  ! This is a Phase 3 finding, not a Tier 1 fail — Welcome-then-encrypt may need a commit roundtrip first.")

    # --- Step 5: persist agent state via export_state + write_meta ----------
    print("\n[5/6] Persist agent state to disk (export_state + write_meta)")
    with tempfile.TemporaryDirectory() as tmpdir_str:
        data_dir = Path(tmpdir_str)
        conv_id = uuid.uuid4()

        agent_blob = agent.export_state()
        print(f"  agent.export_state → {len(agent_blob)} bytes")

        write_meta(
            data_dir,
            conv_id,
            ConversationMeta(
                conversation_id=conv_id,
                type="direct",
                created_at=datetime.now(timezone.utc),
                last_message_ts=None,
            ),
        )
        _save_mls_state(data_dir, conv_id, agent_blob)
        print(f"  meta + state-blob saved under {data_dir / 'conversations' / str(conv_id)}")

        loaded_meta = read_meta(data_dir, conv_id)
        assert loaded_meta is not None
        assert loaded_meta.conversation_id == conv_id
        assert loaded_meta.type == "direct"
        print("  read_meta → conversation_id + type preserved")

        # --- Step 6: reload agent from disk and verify it can still decrypt -
        print("\n[6/6] Reload agent from disk; owner.encrypt → reloaded_agent.decrypt")
        # Per WS-25 test_mls_group_persistence_across_restart: build a fresh
        # wrapper from the SAME signing identity material. The signing key is
        # part of the MLS leaf node, so identity must round-trip exactly.
        # We grabbed _agent_signing + _agent_device_id at build time — reuse.
        agent_reloaded = MlsGroupState(
            device_keys=_agent_signing,
            device_id=_agent_device_id,
        )
        agent_reloaded.import_state(_load_mls_state(data_dir, conv_id))
        print(f"  reloaded.is_initialized={agent_reloaded.is_initialized}")
        print(f"  reloaded.group_id matches: {agent_reloaded.group_id == owner.group_id}")
        assert agent_reloaded.is_initialized
        assert agent_reloaded.group_id == owner.group_id

        # Owner sends a fresh message; reloaded agent decrypts.
        msg_postrestart = b"after restart"
        wire_postrestart = owner.encrypt(msg_postrestart)
        res3 = agent_reloaded.decrypt(wire_postrestart)
        print(f"  reloaded.decrypt → plaintext={res3.plaintext!r} is_handshake={res3.is_handshake}")
        assert res3.plaintext == msg_postrestart

    # --- Summary -----------------------------------------------------------
    print("\n=== Tier 1 results ===")
    print(f"  owner→agent round-trip:        OK")
    print(f"  agent→owner reverse direction: {'OK' if reverse_supported else f'BLOCKED ({reverse_error})'}")
    print(f"  persist + reload + decrypt:    OK")


def main() -> int:
    try:
        run_tier1()
    except AssertionError as e:
        print(f"\nTier 1 failed: assertion: {e}")
        traceback.print_exc()
        return 1
    except Exception as e:  # noqa: BLE001 — top-level reporter
        print(f"\nTier 1 failed: {type(e).__name__}: {e}")
        traceback.print_exc()
        return 1
    print("\nTier 1 passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
