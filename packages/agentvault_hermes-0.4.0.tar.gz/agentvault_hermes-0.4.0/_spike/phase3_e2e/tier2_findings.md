# Tier 2 — Hermes plugin entry point research

**Time spent:** ~1h. All findings sourced from the local Hermes install at
`~/.hermes/hermes-agent/` (Hermes Agent v0.12.0, 2026.4.30, ~723 commits
behind upstream — readily available source-of-truth for this spike).

---

## 1. What is the Hermes plugin contract?

**Hermes has TWO independent extension surfaces, and the AgentVault plugin
is currently configured to use the WRONG one for Phase 3's needs.**

### Surface A — MCP servers (what Phase 1 setup wires today)

`~/.hermes/config.yaml` has an `mcp_servers:` map. Phase 1 setup
(`packages/plugin-hermes/src/agentvault_hermes/cli/setup.py:198-205`) writes:

```yaml
mcp_servers:
  agentvault:
    command: agentvault-hermes
    args: ["serve"]
    env:
      AGENTVAULT_HERMES_ACCOUNT: default
```

Hermes loads MCP servers via `~/.hermes/hermes-agent/tools/mcp_tool.py`,
using the official MCP Python SDK's `stdio_client(StdioServerParameters)`.
Hermes is purely an **MCP client** here — it spawns the listed `command` as
a subprocess and speaks JSON-RPC over stdio (`tools/mcp_tool.py:175-178,
1063-1100`). The `agentvault-hermes serve` subcommand DOES NOT EXIST in the
plugin today (`grep` against `cli/__main__.py` confirms only `setup` and
`doctor`).

**Implication for Phase 3:** to make the AV plugin functional via the
existing Phase 1 wiring, Phase 3 must implement an `agentvault-hermes
serve` subcommand that runs an MCP stdio server. Hermes will spawn it and
connect — but the resulting tools are _outbound from Hermes to AV_ (Hermes
calls AV-provided tools like `agentvault_send_message`,
`agentvault_discover_agents`, etc.).

This works for Phase 4 (Tools plugin / A2A — agent calls
`agentvault_discover_agents` and `agentvault_send_a2a_message`), but it
**does NOT solve Phase 3's "owner sends message → agent receives → agent
replies"** flow. MCP is a request/response surface from Hermes to its
servers; it has no notion of "the MCP server pushes an unsolicited inbound
message into the running Hermes session." See OC's
`SecureChannel.onMessage` callback (channel.ts:982 ff.) — that's the shape
Phase 3 needs, and MCP cannot provide it.

### Surface B — Native Python plugins (`plugins/<name>/__init__.py`)

This is the surface OC's `openclaw-entry.ts` is the equivalent of, and the
one Phase 3 actually needs. Found at `~/.hermes/hermes-agent/hermes_cli/plugins.py`.

A Hermes plugin is a directory with a `plugin.yaml` manifest and a
`__init__.py` exporting a `register(ctx)` function. The `ctx`
(`PluginContext`, plugins.py:233) gives access to:

| API | Purpose |
|---|---|
| `ctx.register_tool(name, toolset, schema, handler, …)` | Add a callable tool to the agent's toolbox. |
| `ctx.register_hook(hook_name, callback)` | Subscribe to lifecycle events (`pre_llm_call`, `pre_tool_call`, `on_session_start`, `pre_gateway_dispatch`, etc. — full list at plugins.py:78-114). |
| `ctx.register_platform(name, label, adapter_factory, …)` | Register a **gateway platform adapter** — the slot for "external messaging surface that pushes inbound messages and receives outbound replies." |
| `ctx.register_cli_command(name, help, setup_fn, …)` | Add `hermes <subcommand>` extensions. |
| `ctx.register_skill(name, path, description)` | Add namespaced skills. |
| `ctx.register_command(name, handler)` | Add slash commands inside chat. |
| `ctx.inject_message(content, role)` | Push a synthetic message into the active conversation (the closest mechanism to OC's `onMessage` callback for non-platform plugins). |

**Plugin discovery sources** (plugins.py:617 ff.):

1. Bundled: `<repo>/plugins/<name>/`
2. User: `~/.hermes/plugins/<name>/`
3. Setuptools entry points under group `hermes_agent.plugins`
4. Git-installed (via `hermes plugins install <git-url>`)

A plugin is loaded only if its name appears in `~/.hermes/config.yaml`
under `plugins.enabled: [...]` (opt-in default; plugins.py:142-169).

### Gateway-platform adapter (BasePlatformAdapter)

`~/.hermes/hermes-agent/gateway/platforms/base.py:1206` defines
`BasePlatformAdapter`, the abstract class that Telegram, Discord,
WhatsApp, Slack, IRC, Teams, etc. all subclass. Required methods:

| Method | Purpose |
|---|---|
| `async def connect(self) -> bool` | Open the platform connection (login, websocket, etc.). |
| `async def disconnect(self) -> None` | Tear down. |
| `async def send(self, chat_id, text, …) -> SendResult` | Outbound: agent reply → external recipient. |

Inbound messages are produced by the adapter calling
`self._message_handler(MessageEvent(...))` — the `MessageHandler` is set
by the gateway runner at startup. `MessageEvent` (base.py:870) is the
normalized inbound shape: `text`, `source: SessionSource`, `media_urls`,
`reply_to_*`, `auto_skill`, etc.

**This is the OC `onMessage` analogue.** A Hermes platform adapter is to
`gateway` what `SecureChannel.onMessage` is to `openclaw-entry.ts`.

The IRC adapter at `~/.hermes/hermes-agent/plugins/platforms/irc/adapter.py`
is the cleanest reference: a 660-LOC standalone plugin that inherits
`BasePlatformAdapter`, drives a stdlib asyncio loop, fires
`MessageEvent`s into the gateway, and registers via `register(ctx)` →
`ctx.register_platform(...)`.

---

## 2. What does an MCP server "do" from Hermes' perspective?

- **Transport:** stdio. Hermes spawns the configured `command` and speaks
  JSON-RPC 2.0 over stdin/stdout per the MCP spec. Source:
  `tools/mcp_tool.py:1063-1109`.
- **Direction:** Hermes is the **client**; the MCP server EXPOSES tools.
  Hermes calls them; the server cannot push unsolicited messages back.
- **Status of `agentvault-hermes serve`:** NOT IMPLEMENTED. The CLI today
  has only `setup` and `doctor` subcommands (`cli/__main__.py:14-44`).
  Phase 1 already pre-wired `mcp_servers.agentvault.args = ["serve"]`,
  so the slot is reserved but the implementation is Phase 3+ work.
- **What Phase 3 needs to add for MCP path:** an asyncio MCP stdio server
  process exposing tools. Likely future use: Phase 4 A2A tools
  (`agentvault_send_a2a_message`, `agentvault_discover_agents`) and Phase
  5 outbound-MCP (skill invocation).
- **What Phase 3 CANNOT achieve via MCP alone:** owner→agent inbound
  messaging. MCP has no server-pushes-inbound-event primitive. The
  closest official MCP primitive is "sampling" (server asks client to run
  an LLM call), but it doesn't model "deliver this user message into the
  agent's running session."

---

## 3. Gateway-platform integration shape

**OC equivalent:** `packages/plugin/src/openclaw-entry.ts:947-1340` — the
`gateway.startAccount` callback that constructs `SecureChannel`, wires
its `onMessage`/`onA2AMessage`/`onA2AChannelReady` callbacks into
OpenClaw's `runtime.handleInbound`, and stays-pending until the
abort-signal fires.

**Hermes equivalent (the slot Phase 3 needs to fill):**

A new bundled plugin at `<plugin-hermes-install>/plugins/agentvault/__init__.py`
with:

```python
def register(ctx):
    ctx.register_platform(
        name="agentvault",
        label="AgentVault",
        adapter_factory=lambda cfg: AgentVaultAdapter(cfg),
        check_fn=_check_av_configured,  # state.json exists + JWT
        emoji="🔐",
        setup_fn=_av_interactive_setup,  # optional, mirrors `hermes gateway setup`
    )
```

`AgentVaultAdapter(BasePlatformAdapter)` would:

- `connect()`: open the AV WebSocket (the existing `WsClient` at
  `core/transport/ws_client.py`), authenticate with the device JWT.
- `send(chat_id, text, …)`: call into the SecureChannel-equivalent
  encrypt-and-send path (Phase 3 work — fills in `Relay.send_message`).
- Internally on each inbound encrypted frame: decrypt via
  `MlsGroupState`, then call `self._message_handler(MessageEvent(text=…,
  source=SessionSource(platform="agentvault", chat_id=conv_id, …)))`.

**`config.yaml` activation surface:**

```yaml
gateway:
  platforms:
    agentvault:
      enabled: true
plugins:
  enabled: [agentvault]
```

Phase 1 currently writes only `mcp_servers.agentvault`. Phase 3 setup
would need to additionally write the `gateway.platforms.agentvault`
+ `plugins.enabled` entries (or — preferable — a separate `agentvault-hermes
gateway-install` subcommand).

---

## 4. Minimum change to make Hermes invoke Phase 3 channel/secure-channel code

Best-guess concrete delta (load-bearing for the Phase 3 plan):

1. **New `agentvault-hermes` CLI subcommand**: `serve` (MCP stdio server)
   for outbound A2A/discovery tools. ~150-300 LOC. Uses `mcp` SDK
   (already a transitive dep via Hermes itself). Useful starting Phase 4.
2. **New `plugins/agentvault/` plugin directory** inside the
   `agentvault-hermes` Python package (or installed standalone via
   `hermes plugins install`). Houses:
   - `plugin.yaml` with `kind: platform`, `name: agentvault`.
   - `__init__.py` with `register(ctx)` → `ctx.register_platform(...)`.
   - `adapter.py` with `class AgentVaultAdapter(BasePlatformAdapter)`.
   - The adapter's connect/send methods are where today's stub
     `Relay.send_message` / `Relay.receive_messages` get fleshed out.
   - Decrypt path uses `MlsGroupState` + `crypto/persistence.py`
     (already proven by Tier 1).
3. **Setup-flow extension**: `agentvault-hermes setup` must also
   register the gateway-platform plugin (write
   `plugins.enabled: [..., agentvault]` + `gateway.platforms.agentvault.enabled:
   true`), or add a separate `agentvault-hermes install` subcommand. This
   is the customer-visible delta from Phase 1's "MCP-only" setup.
4. **Discovery wiring**: Hermes resolves bundled plugins from
   `<repo>/plugins/`. Since `agentvault-hermes` is `pip install`-ed as a
   wheel into the same venv as Hermes, the cleanest approach is to use
   setuptools entry points (group `hermes_agent.plugins`,
   plugins.py:116) — Hermes' discovery loop scans entry points and loads
   the package automatically. No file-copy into `~/.hermes/plugins/` needed.
5. **OC parity hook for telemetry**: `ctx.register_hook("post_llm_call",
   …)` — Phase 6 will use this for the `httpx_hook`/cost-calculator
   surface. Not Phase 3's job, but the slot exists.

---

## 5. Standalone-testable vs needs-real-Hermes

| Component | Testable standalone? | How |
|---|---|---|
| MlsGroupState round-trip + persistence | YES — Tier 1 proves it | `pytest` + in-process |
| `Relay.send_message` / `Relay.receive_messages` | YES with respx | Mock the AV WebSocket protocol; Tier 3 candidate |
| `MessageEvent` inbound decrypt path | YES — feed bytes through `MlsGroupState.decrypt` and assert plaintext | Unit test |
| Stdio MCP server (`serve` subcommand) | YES — `mcp` Python SDK has client harness | Integration test that spawns subprocess and lists tools |
| Full gateway-platform adapter | NO — needs a real Hermes runtime to host it | Manual e2e or a Hermes-test-harness fixture |
| Owner→agent end-to-end demo | Needs both real Hermes AND a real AV backend (or a thorough WS mock) | The Phase 3 demo itself |

---

## Open unknowns the spike could not answer from local source alone

1. **Does Hermes' MCP client preserve subprocess between calls, or
   re-spawn per tool call?** Affects whether the `serve` process can
   maintain WS state. Skim of `tools/mcp_tool.py:856-1100` suggests
   per-process (single `MCPServerTask` instance). **Likely answer:
   long-lived subprocess.** Confirm by running `hermes mcp test
   agentvault` after `serve` is implemented.
2. **Is `register_platform`'s `adapter_factory` invoked once at gateway
   startup or per session?** Skim suggests once per platform, but the
   per-session interrupt-event maps in `BasePlatformAdapter.__init__`
   imply the adapter is long-lived and multiplexes sessions.
3. **Can a single plugin register BOTH a platform AND register MCP-style
   tools the agent can call?** Reading plugins.py: yes — `register(ctx)`
   can call both `ctx.register_platform` and `ctx.register_tool`. This
   is the right shape: gateway-platform for inbound owner-messaging, plus
   tools for outbound A2A / discovery / skill invocation.
4. **What happens if BOTH the `mcp_servers.agentvault` MCP entry AND a
   `plugins.enabled.agentvault` gateway-platform plugin are configured
   simultaneously?** Likely: they coexist (different surfaces, different
   processes). But Phase 3 setup needs to decide whether to keep the
   Phase 1 MCP entry or remove it (probably keep — Phase 4 needs it).
