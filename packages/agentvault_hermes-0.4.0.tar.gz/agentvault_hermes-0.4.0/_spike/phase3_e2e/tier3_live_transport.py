"""Phase 3 Spike Tier 3 — wire-envelope round-trip without a real backend.

Goal: prove the AV WebSocket message envelope schema against
``MlsGroupState`` ciphertext, surfacing what the Phase 3 ``Relay`` impl
needs to do.

We don't run a real WebSocket server here (the ``websockets`` package
isn't a project dep, and ``httpx_ws``'s server features are tuned for
production not test fixtures). Instead we:

1. Set up two ``MlsGroupState`` instances (owner + agent) and bring up
   a 1:1 group via Welcome (same as Tier 1).
2. Serialize what owner WOULD send: the AV WS envelope shape from OC's
   ``channel.ts`` line 685-689 — ``{"event": "message_mls", "data":
   {<ciphertext payload + metadata>}}``.
3. Hand that JSON envelope to a lightweight in-memory queue (the "wire"
   stand-in). Agent picks it up, parses the envelope, decodes the
   ciphertext field, hands it to ``MlsGroupState.decrypt``, asserts
   the plaintext matches.
4. Reverse direction.

This validates that:
    * ``MlsGroupState.encrypt`` returns bytes that fit a JSON envelope
      after base64 encoding.
    * The OC ``message_mls`` envelope shape carries enough metadata to
      route the message on the receiver side.
    * The proposed ``Relay.send_message(conversation_id, payload)``
      / ``Relay.receive_messages()`` API surface is sufficient.

Run from packages/plugin-hermes:
    uv run python _spike/phase3_e2e/tier3_live_transport.py
"""
from __future__ import annotations

import asyncio
import base64
import json
import sys
import traceback
import uuid
from collections import deque
from dataclasses import dataclass
from typing import Optional

from agentvault_hermes.core.identity import generate_device_keys
from agentvault_hermes.crypto import MlsGroupState, SigningKeypair


# --- Envelope schema (from OC channel.ts:685-689 + 3582-3596) -----------------


@dataclass
class WireEnvelope:
    """Outer JSON envelope sent over the AV WebSocket.

    Source-of-truth: ``packages/plugin/src/channel.ts:685-689``.
    Mapped to the AV backend's expected ``{event, data}`` shape.
    """
    event: str  # "message_mls" for MLS 1:1; "message" for DR fallback
    data: dict

    def to_json(self) -> str:
        return json.dumps({"event": self.event, "data": self.data})

    @classmethod
    def from_json(cls, raw: str) -> "WireEnvelope":
        parsed = json.loads(raw)
        return cls(event=parsed["event"], data=parsed["data"])


def make_outbound_message_mls(
    conversation_id: str,
    sender_device_id: str,
    ciphertext: bytes,
    *,
    message_group_id: Optional[str] = None,
    topic_id: Optional[str] = None,
    client_message_id: Optional[str] = None,
    message_type: str = "text",
    parent_span_id: Optional[str] = None,
) -> WireEnvelope:
    """Build the outbound MLS message envelope.

    Mirrors the OC payload shape at ``channel.ts:686-689`` adapted for
    MLS (single ciphertext blob, no separate header_blob — MLS embeds
    framing in its own bytes).
    """
    payload: dict = {
        "conversation_id": conversation_id,
        "sender_device_id": sender_device_id,
        "ciphertext": base64.b64encode(ciphertext).decode("ascii"),
        "message_type": message_type,
    }
    if message_group_id:
        payload["message_group_id"] = message_group_id
    if topic_id:
        payload["topic_id"] = topic_id
    if client_message_id:
        payload["client_message_id"] = client_message_id
    if parent_span_id:
        payload["parent_span_id"] = parent_span_id
    return WireEnvelope(event="message_mls", data=payload)


# --- In-memory "wire" stand-in -------------------------------------------------


class FakeWire:
    """Bidirectional in-memory queue. Mimics the WebSocket without spawning
    a server. Each side has a deque; ``send`` pushes into the peer's queue,
    ``receive`` pops from its own.
    """

    def __init__(self) -> None:
        self._owner_inbox: deque[str] = deque()
        self._agent_inbox: deque[str] = deque()
        self.transcript: list[tuple[str, str]] = []  # (sender, raw_json)

    async def owner_send(self, raw: str) -> None:
        self.transcript.append(("owner", raw))
        self._agent_inbox.append(raw)

    async def agent_send(self, raw: str) -> None:
        self.transcript.append(("agent", raw))
        self._owner_inbox.append(raw)

    async def owner_recv(self) -> str:
        return self._owner_inbox.popleft()

    async def agent_recv(self) -> str:
        return self._agent_inbox.popleft()


# --- Spike body ---------------------------------------------------------------


def _signing_kp(dk) -> SigningKeypair:
    return SigningKeypair(
        public_key=dk.signing_public, private_key=dk.signing_secret
    )


async def run_tier3() -> None:
    print("\n=== Tier 3: wire envelope round-trip ===\n")

    # --- Setup: bring up the 1:1 MLS group --------------------------------------
    print("[1/5] Build owner + agent and join via Welcome")
    owner_dk = generate_device_keys()
    agent_dk = generate_device_keys()
    owner_signing = _signing_kp(owner_dk)
    agent_signing = _signing_kp(agent_dk)
    owner_device_id = uuid.uuid4()
    agent_device_id = uuid.uuid4()

    owner = MlsGroupState(device_keys=owner_signing, device_id=owner_device_id)
    agent = MlsGroupState(device_keys=agent_signing, device_id=agent_device_id)

    conversation_id = str(uuid.uuid4())
    group_id = uuid.UUID(conversation_id).bytes  # 16 bytes
    owner.create_group(group_id)
    add_result = owner.add_members([agent.generate_key_package()])
    assert add_result.welcome is not None
    agent.join_from_welcome(add_result.welcome)
    print(f"  conversation_id={conversation_id}")
    print(f"  owner.epoch={owner.epoch} agent.epoch={agent.epoch}")

    # --- Wire setup ------------------------------------------------------------
    wire = FakeWire()

    # --- Step 2: owner.send_message ---------------------------------------------
    print("\n[2/5] owner: encrypt + serialize envelope + push to wire")
    plaintext_a = b"hello from owner via tier3 wire"
    cipher_a = owner.encrypt(plaintext_a)
    print(f"  ciphertext: {len(cipher_a)} bytes")

    envelope_a = make_outbound_message_mls(
        conversation_id=conversation_id,
        sender_device_id=str(owner_device_id),
        ciphertext=cipher_a,
        client_message_id=str(uuid.uuid4()),
        topic_id=str(uuid.uuid4()),
    )
    raw_a = envelope_a.to_json()
    print(f"  envelope: {len(raw_a)} bytes JSON, event={envelope_a.event}")
    print(f"  envelope keys: {list(envelope_a.data.keys())}")
    await wire.owner_send(raw_a)

    # --- Step 3: agent.receive_messages -----------------------------------------
    print("\n[3/5] agent: pop from wire + parse envelope + decrypt")
    raw_in = await wire.agent_recv()
    parsed = WireEnvelope.from_json(raw_in)
    assert parsed.event == "message_mls", f"unexpected event {parsed.event}"
    assert parsed.data["conversation_id"] == conversation_id
    # Spec check: do NOT decrypt your own messages (channel.ts:3598)
    assert parsed.data["sender_device_id"] != str(agent_device_id)

    ciphertext_in = base64.b64decode(parsed.data["ciphertext"])
    res = agent.decrypt(ciphertext_in)
    print(f"  decrypted plaintext: {res.plaintext!r} is_handshake={res.is_handshake}")
    assert res.plaintext == plaintext_a
    assert res.is_handshake is False

    # --- Step 4: reverse direction ----------------------------------------------
    print("\n[4/5] agent: encrypt reply + send back; owner: decrypt")
    plaintext_b = b"hello back from agent"
    cipher_b = agent.encrypt(plaintext_b)
    envelope_b = make_outbound_message_mls(
        conversation_id=conversation_id,
        sender_device_id=str(agent_device_id),
        ciphertext=cipher_b,
        client_message_id=str(uuid.uuid4()),
    )
    await wire.agent_send(envelope_b.to_json())

    raw_back = await wire.owner_recv()
    parsed_back = WireEnvelope.from_json(raw_back)
    assert parsed_back.event == "message_mls"
    assert parsed_back.data["sender_device_id"] != str(owner_device_id)

    ciphertext_back = base64.b64decode(parsed_back.data["ciphertext"])
    res_back = owner.decrypt(ciphertext_back)
    print(f"  decrypted reply: {res_back.plaintext!r}")
    assert res_back.plaintext == plaintext_b

    # --- Step 5: schema gap probe -----------------------------------------------
    print("\n[5/5] Schema gap probe — what fields does the AV backend require?")
    print("  Verified shape (from OC channel.ts:685-689 + 3582-3596):")
    for k, v in envelope_a.data.items():
        rendering = v if isinstance(v, str) and len(v) < 50 else f"<{type(v).__name__} len={len(str(v))}>"
        print(f"    {k}: {rendering}")
    print("\n  Fields OC sends but Tier 3 omitted (not load-bearing for MVP):")
    print("    - hub_address      (multi-tenant routing)")
    print("    - sender_hub_id    (multi-tenant routing)")
    print("    - priority         (UI ordering)")
    print("    - parent_span_id   (telemetry)")
    print("    - metadata.scan_status (DLP)")
    print("\n  Field PRESENT in inbound shape (channel.ts:3582-3596) but NOT in outbound:")
    print("    - message_id (server-assigned at the AV backend on accept)")
    print("    - created_at (server-assigned)")
    print("    - envelope_version (server may stamp)")

    # --- Summary ---------------------------------------------------------------
    print("\n=== Tier 3 results ===")
    print(f"  owner -> agent envelope round-trip: OK")
    print(f"  agent -> owner envelope round-trip: OK")
    print(f"  base64 encoding survives JSON round-trip: OK")
    print(f"  Wire transcript entries: {len(wire.transcript)}")


def main() -> int:
    try:
        asyncio.run(run_tier3())
    except AssertionError as e:
        print(f"\nTier 3 failed: assertion: {e}")
        traceback.print_exc()
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\nTier 3 failed: {type(e).__name__}: {e}")
        traceback.print_exc()
        return 1
    print("\nTier 3 passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
