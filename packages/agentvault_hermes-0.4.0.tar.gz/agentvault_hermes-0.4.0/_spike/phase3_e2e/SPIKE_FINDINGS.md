# Phase 3 Spike — Findings

**Branch:** `feat/phase3-e2e-spike` (off main).
**Time spent:** ~2.5h of 3-4h budget. Tier 1 + 2 + 3 all completed.
**Hard constraints satisfied:** `git diff main -- packages/plugin-hermes/src/`
is empty; all spike code lives under `_spike/phase3_e2e/`.

---

## What worked (Tier 1 results)

`uv run python _spike/phase3_e2e/tier1_in_process_round_trip.py` → **Tier 1
passed**. The WS-22..25 API composes cleanly for a 1:1 conversation flow:

- `MlsGroupState(device_keys, device_id)` constructor accepts the
  `_signing_kp_from_device_keys` shape from WS-25 unchanged.
- `create_group(group_id) → add_members([kp]) → join_from_welcome(welcome)`
  sequence works without surprise.
- **Bidirectional encrypt/decrypt works immediately after Welcome**,
  no commit-roundtrip required. (This was a question mark going in
  because the WS-25 multi-member test only proved one-way encrypt and
  asserted joiner.epoch == 0 in 0.1.0.) Owner→agent and agent→owner
  both round-trip plaintext on the first message.
- `export_state` → `write_meta` + state-blob persistence → reload via
  fresh `MlsGroupState(...)`+ `import_state` → `decrypt` continues
  working. Identity material (signing keypair + device_id) must be
  preserved across "restart" since the signing key is part of the MLS
  leaf — the WS-25 persistence test showed the pattern.

**Tier 3 also passed**: `uv run python _spike/phase3_e2e/tier3_live_transport.py`.
Validated that the OC `{"event": "message_mls", "data": {...}}` envelope
shape carries `MlsGroupState.encrypt` ciphertext through a JSON +
base64 round-trip without information loss.

---

## What's unknown (Tier 2 unanswered)

The unknowns surfaced by Tier 2 (full detail in `tier2_findings.md`):

1. **Does Hermes' MCP client preserve the subprocess between calls or
   re-spawn per tool invocation?** Skim of `tools/mcp_tool.py` suggests
   a long-lived `MCPServerTask` per server entry, but unverified until
   `agentvault-hermes serve` is implemented and `hermes mcp test
   agentvault` is run against it. **Practical impact:** if it's
   per-call, the WebSocket cannot live inside the MCP process. (Likely
   long-lived → not actually a problem.)
2. **`register_platform` adapter lifetime** (per session vs process-wide)
   — code reads as process-wide multiplexing sessions, but worth
   confirming once we implement `AgentVaultAdapter` and trace it.
3. **Coexistence**: keeping the Phase 1 `mcp_servers.agentvault` entry
   while ALSO adding a `plugins.enabled.agentvault` gateway-platform
   plugin. Almost certainly fine (different processes, different
   surfaces), but Phase 3 setup needs to make this explicit.
4. **Ed25519/Hermes auth pairing**: how the AV device JWT relates to
   Hermes' own session/pairing system. Not surfaced in Phase 1; Phase 3
   may need to bridge them.

---

## What changed in our understanding of Phase 3 since the design doc

### Big finding — the design-doc demo path needs an architecture decision

The design doc lines 329-333 say Phase 3's deliverable is "**Channel +
gateway platform** — Owner sends message from AV app → Hermes agent
receives, decrypts, replies → reply arrives in AV app." That happens to
be the MOST architecturally non-obvious part of the whole project, and
the Phase 1 setup wired the WRONG Hermes surface for it.

**The mismatch:** Phase 1 (`cli/setup.py`) writes only an
`mcp_servers.agentvault` config entry. MCP servers in Hermes are
**Hermes-as-client, plugin-as-server** — the agent CALLS tools the AV
plugin EXPOSES. There is no MCP primitive for "the MCP server pushes an
unsolicited inbound owner-message into the running Hermes agent
session." This is not an implementation gap; it's a fundamental shape
mismatch between MCP and what Phase 3 needs.

**The right slot:** Hermes has a **second extension surface** —
native Python plugins under `plugins/<name>/__init__.py` that get a
`PluginContext` with `register_platform`, `register_hook`,
`register_tool`, `register_command`, `inject_message`, etc.
`register_platform` registers a `BasePlatformAdapter` subclass that the
gateway treats as a first-class messaging surface — exactly like the
bundled IRC, Discord, Slack, Telegram adapters. That's where AV
inbound owner-messaging belongs. The IRC adapter
(`~/.hermes/hermes-agent/plugins/platforms/irc/adapter.py`, 660 LOC) is
the cleanest reference implementation.

**OC parity:** OC's `openclaw-entry.ts` is 1765 LOC of exactly this
shape — it registers a "channel" with the OpenClaw runtime, handles
inbound messages via a callback, and orchestrates outbound replies.
The Hermes equivalent is a `register_platform` plugin with a
`BasePlatformAdapter` subclass.

### Phase 3's actual scope (refined)

Per the design doc's _stated_ Phase 3 deliverable list (channel/ +
agentvault_hermes.gateway wrapper + Hermes gateway-platform integration),
the breakdown is:

| Sub-deliverable | Phase 3 work |
|---|---|
| Fill in `Relay.send_message` / `Relay.receive_messages` | YES — uses existing `WsClient`, MLS encrypt/decrypt |
| Build `channel/secure_channel.py` (the OC SecureChannel analogue) | YES — orchestrates Relay + MlsGroupState + persistence |
| Build the gateway-platform plugin (`plugins/agentvault/` with `register_platform`) | YES — this is the integration delta |
| Implement `agentvault-hermes serve` (the MCP path) | DEFER to Phase 4 — MCP path is for outbound A2A tools, not Phase 3 demo |
| Update `cli/setup.py` to wire `plugins.enabled` + `gateway.platforms.agentvault` | YES — small extension to existing setup |

**MCP-via-`serve` is Phase 4 scope, not Phase 3.** The Phase 3 demo
(owner → agent inbound, agent → owner reply) does not require it. Phase
4 (A2A tools) does.

---

## Recommended next step

**Write the Phase 3 plan, with a brainstorm phase first.**

The spike validates that the implementation work is tractable
(crypto API composes cleanly, envelope shape carries the necessary
metadata, identity round-trips work). The risk has shifted from
"implementation unknowns" to "architectural decision: which Hermes
surface to plug into."

The brainstorm should explicitly resolve:

1. **Phase 3 plugs into `register_platform`, not `mcp_servers`.** Confirm with
   Eric. This realigns Phase 3 with OC parity (`onMessage` callback
   shape) and is exactly the gateway-platform pattern Hermes IRC,
   Telegram, Discord, etc. already use.
2. **The Phase 1 `mcp_servers.agentvault` entry stays as Phase 4
   scaffolding** (for `agentvault-hermes serve` outbound A2A tools).
3. **Setup-flow extension scope**: minimum viable is a one-line
   addition to `cli/setup.py` writing `plugins.enabled: [agentvault]`
   + `gateway.platforms.agentvault.enabled: true`. Could split into a
   `agentvault-hermes install` subcommand if Eric prefers a hard separation.
4. **Plugin distribution**: setuptools entry point under
   `hermes_agent.plugins` group (Hermes scans those, plugins.py:116) is
   the cleanest fit since `agentvault-hermes` is `pip install`-ed into
   Hermes' venv. No file-copy to `~/.hermes/plugins/` needed.

After the brainstorm + design alignment, the Phase 3 plan should be
straightforward to draft. Estimated raw LOC: ~600-900 across `channel/`
+ `plugins/agentvault/` with another ~300 of integration + smoke tests.

---

## Concrete WS-28+ sub-task list (informed by spike)

These map to the design-doc Phase 3 deliverables but are reshaped by
spike findings:

| WS | Title | LOC est. | Notes |
|---|---|---|---|
| **WS-28** | `channel/secure_channel.py` — orchestrator | 300-450 | OC `SecureChannel` analogue, Python-flavored. Holds `Relay` + `MlsGroupState` + persistence. Emits async events. |
| **WS-29** | `Relay.send_message` impl | 100-150 | WS path: encrypt via `MlsGroupState`, JSON-envelope wrap, `WsClient.send_json`. Drops the `NotImplementedError` stub at `core/transport/relay.py:28`. |
| **WS-30** | `Relay.receive_messages` impl | 150-200 | Async generator over `WsClient.receive_json`; demux on `event` type; route `message_mls` → decrypt. |
| **WS-31** | `plugins/agentvault/` — Hermes platform plugin | 300-450 | `plugin.yaml` + `__init__.py` with `register(ctx)` calling `ctx.register_platform`. Adapter inherits `BasePlatformAdapter` from `gateway/platforms/base.py`. The actual integration point. |
| **WS-32** | `cli/setup.py` extension — register platform | 50-80 | Add `plugins.enabled` and `gateway.platforms.agentvault.enabled` to the YAML write in `_modify_hermes_config`. |
| **WS-33** | Wire envelope schema module | 80-120 | Promote Tier 3's `WireEnvelope` + `make_outbound_message_mls` from spike to production. Add typing for the inbound shape (`channel.ts:3582-3596`). |
| **WS-34** | Phase 3 acceptance demo + smoke test | 100-150 | OC↔Hermes 1:1 against AV dev backend (or thorough mock). Mirrors the Phase 1 demo pattern. |
| **WS-35** | Doctor extensions for Phase 3 | 60-100 | Add `gateway-platform` and `mls-state` checks to `cli/doctor.py`. |

Optional / parallel:

| WS | Title | LOC est. | Notes |
|---|---|---|---|
| WS-36 | `agentvault-hermes serve` (MCP server) | 200-300 | Phase 4 prerequisite; not Phase 3 critical-path. Worth scoping during Phase 3 if the rest is moving. |

**Suggested ordering:** WS-29 + WS-33 (transport-only, in parallel) →
WS-28 (orchestrator, depends on 29+33) → WS-31 (platform plugin,
depends on 28) → WS-32 + WS-35 (setup + doctor wiring) → WS-34
(end-to-end demo). WS-30 and WS-29 can probably collapse into one PR
since they share the `Relay` surface.

---

## Open follow-ups not in WS-28+

- Confirm Hermes MCP client subprocess lifetime experimentally (Tier 2
  open unknown #1).
- Decide whether to remove or keep the existing `mcp_servers.agentvault`
  entry in Phase 1 setup output. Recommendation: keep, as Phase 4 will
  use it.
- Pairing/auth bridge between AV device JWT and Hermes' session model —
  may surface during WS-31 implementation.
- The Phase 7 deletion (OC migration to mls-rs) was already removed from
  the project plan per the 2026-05-06 Phase 0 spike findings; this
  spike confirms nothing in Phase 3 requires Phase 7. Cross-impl
  interop is its own work-stream tracked under actions #124 + #126.
