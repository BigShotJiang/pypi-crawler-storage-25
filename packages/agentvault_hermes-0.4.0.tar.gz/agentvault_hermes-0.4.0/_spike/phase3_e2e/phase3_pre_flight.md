# WS-28.0 — Phase 3 Pre-Flight Findings

- **Date:** 2026-05-10
- **Status:** PASS — every blocker question resolved; Phase 3 sub-task dispatch is unblocked.
- **Hermes reference:** local install at `~/.hermes/hermes-agent/`. Findings cite verbatim line ranges.
- **Resolves:** Phase 3 plan §2.2 Q1/Q2/Q4 + DA #5 (Platform enum chicken-and-egg) + DA #12 (JWT TTL).

---

## 1. `BasePlatformAdapter.__init__` signature (Q1 + DA #4)

**Source:** `~/.hermes/hermes-agent/gateway/platforms/base.py:1217`

```python
class BasePlatformAdapter(ABC):
    def __init__(self, config: PlatformConfig, platform: Platform):
        self.config = config
        self.platform = platform
        self._message_handler: Optional[MessageHandler] = None
        self._running = False
        ...
```

**Confirmed:** 2 positional args (`config`, `platform`). Reference adapter at `plugins/platforms/irc/adapter.py:108-110`:

```python
def __init__(self, config, **kwargs):
    platform = Platform("irc")
    super().__init__(config=config, platform=platform)
```

The plan's §11.4 patched skeleton mirrors this exactly. Direct subclass + inline `Platform("agentvault")` is correct.

---

## 2. `Platform` enum + `_missing_` classmethod (Q4 + DA #5)

**Source:** `~/.hermes/hermes-agent/gateway/config.py:82-154`

```python
class Platform(Enum):
    LOCAL = "local"
    TELEGRAM = "telegram"
    ... (20 explicit members)

    @classmethod
    def _missing_(cls, value):
        if not isinstance(value, str) or not value.strip():
            return None
        value = value.strip().lower()
        if value in cls._value2member_map_:
            return cls._value2member_map_[value]

        # (a) Bundled plugin filesystem scan
        global _Platform__bundled_plugin_names
        if _Platform__bundled_plugin_names is None:
            _Platform__bundled_plugin_names = cls._scan_bundled_plugin_platforms()
        if value in _Platform__bundled_plugin_names:
            pseudo = object.__new__(cls)
            pseudo._value_ = value
            pseudo._name_ = value.upper().replace("-", "_").replace(" ", "_")
            cls._value2member_map_[value] = pseudo
            cls._member_map_[pseudo._name_] = pseudo
            return pseudo

        # (b) Runtime-registered plugin platforms
        try:
            from gateway.platform_registry import platform_registry
            if platform_registry.is_registered(value):
                pseudo = object.__new__(cls)
                pseudo._value_ = value
                pseudo._name_ = value.upper().replace("-", "_").replace(" ", "_")
                cls._value2member_map_[value] = pseudo
                cls._member_map_[pseudo._name_] = pseudo
                return pseudo
        except Exception:
            pass

        return None
```

**Critical:** `Platform("agentvault")` resolves only if EITHER (a) `agentvault` is in the bundled-plugin filesystem scan (we are NOT bundled), OR (b) `platform_registry.is_registered("agentvault")` is True. Our path is (b).

If neither matches, `Platform("agentvault")` returns `None` from `_missing_`, which Enum then raises as `ValueError("'agentvault' is not a valid Platform")`. **Bootstrap order is therefore load-bearing — `register_platform("agentvault", ...)` MUST run before any `Platform("agentvault")` resolution.**

---

## 3. Bootstrap-order trace (DA #5 BLOCKER)

The trace below proves: in any Hermes invocation that reaches adapter instantiation, `platform_registry.register("agentvault", ...)` has already run.

### Phase A — Gateway startup calls `discover_plugins`

**Source:** `~/.hermes/hermes-agent/gateway/run.py:2787-2793`

```python
try:
    from hermes_cli.plugins import discover_plugins
    discover_plugins()
except Exception:
    logger.debug("plugin discovery failed at gateway startup", exc_info=True)
```

This call is **synchronous**. It runs to completion before the platform-iteration loop at line 2868 starts. The CLI startup path also calls `discover_plugins()` earlier from `hermes_cli/main.py` (per the comment at line 2783-2786), but the gateway re-invokes it defensively because lazy imports of `run_agent` may have skipped the CLI-side call.

### Phase B — `discover_plugins` calls `_load_plugin` for each enabled plugin

**Source:** `~/.hermes/hermes-agent/hermes_cli/plugins.py:728-743`

```python
is_enabled = (
    enabled is not None
    and (lookup_key in enabled or manifest.name in enabled)
)
if not is_enabled:
    ...
    continue
self._load_plugin(manifest)
```

For our plugin, `agentvault` must appear in `plugins.enabled` of `~/.hermes/config.yaml` (WS-32 writes this). Bundled platform plugins auto-load (line 720); we are NOT bundled, so we depend on the explicit enable.

### Phase C — `_load_plugin` calls the plugin's `register(ctx)`

**Source:** `~/.hermes/hermes-agent/hermes_cli/plugins.py:943-987`

```python
def _load_plugin(self, manifest: PluginManifest) -> None:
    loaded = LoadedPlugin(manifest=manifest)
    try:
        if manifest.source in ("user", "project", "bundled"):
            module = self._load_directory_module(manifest)
        else:
            module = self._load_entrypoint_module(manifest)
        loaded.module = module

        register_fn = getattr(module, "register", None)
        if register_fn is None:
            loaded.error = "no register() function"
            ...
        else:
            ctx = PluginContext(manifest, self)
            register_fn(ctx)
            ...
            loaded.enabled = True
    except Exception as exc:
        loaded.error = str(exc)
        ...
```

For entry-point plugins (us), `_load_entrypoint_module` calls `ep.load()` (line 1045) which imports our `agentvault_hermes.plugins.agentvault.__init__` and returns the module. `register_fn(ctx)` then invokes our `register(ctx)`.

### Phase D — Our `register(ctx)` calls `ctx.register_platform`

**Source:** Phase 3 plan §11.3 + IRC reference at `~/.hermes/hermes-agent/plugins/platforms/irc/__init__.py`

```python
def register(ctx):
    ctx.register_platform(
        name="agentvault",
        label="AgentVault",
        adapter_factory=_adapter_factory,
        check_fn=_check_av_configured,
        emoji="🔐",
        install_hint=...,
    )
```

### Phase E — `register_platform` adds to `platform_registry`

**Source:** `~/.hermes/hermes-agent/hermes_cli/plugins.py:472-524` (specifically line 518)

```python
def register_platform(
    self, name, label, adapter_factory, check_fn,
    validate_config=None, required_env=None, install_hint="",
    **entry_kwargs,
) -> None:
    from gateway.platform_registry import platform_registry, PlatformEntry

    entry_kwargs.setdefault("plugin_name", self.manifest.name)
    entry = PlatformEntry(
        name=name,
        label=label,
        adapter_factory=adapter_factory,
        check_fn=check_fn,
        validate_config=validate_config,
        required_env=required_env or [],
        install_hint=install_hint,
        source="plugin",
        **entry_kwargs,
    )
    platform_registry.register(entry)        # ← line 518: registry populated
    self._manager._plugin_platform_names.add(name)
```

After this returns, `platform_registry.is_registered("agentvault") == True` for the rest of the process lifetime.

### Phase F — Gateway iterates platforms and calls `_create_adapter`

**Source:** `~/.hermes/hermes-agent/gateway/run.py:2868-2873`

```python
for platform, platform_config in self.config.platforms.items():
    if not platform_config.enabled:
        continue
    enabled_platform_count += 1

    adapter = self._create_adapter(platform, platform_config)
```

This loop runs AFTER `discover_plugins()` returned (line 2789). Phases A-E have all completed.

### Phase G — `_create_adapter` resolves via the registry

**Source:** `~/.hermes/hermes-agent/gateway/run.py:4101-4138`

```python
def _create_adapter(self, platform, config) -> Optional[BasePlatformAdapter]:
    ...
    try:
        from gateway.platform_registry import platform_registry
        if platform_registry.is_registered(platform.value):
            adapter = platform_registry.create_adapter(platform.value, config)
            if adapter is not None:
                return adapter
            ...
            return None
    except Exception as e:
        ...
```

`platform_registry.create_adapter` (`platform_registry.py:160-208`) eventually calls `entry.adapter_factory(config)` at line 199.

### Phase H — `adapter_factory` constructs `AgentVaultAdapter`

**Source:** Phase 3 plan §11.3 `_adapter_factory`:

```python
def _adapter_factory(cfg, **kwargs):
    return AgentVaultAdapter(cfg, **kwargs)
```

`AgentVaultAdapter.__init__` (per Phase 3 plan §11.4, mirroring IRC):

```python
def __init__(self, config, **kwargs):
    platform = Platform("agentvault")  # ← FIRST resolution attempt
    super().__init__(config=config, platform=platform)
    ...
```

By this point, Phases A-G have all completed. `Platform._missing_("agentvault")` reaches branch (b), `platform_registry.is_registered("agentvault")` returns True, the pseudo-member is constructed and cached, and `Platform("agentvault")` returns it. **No `ValueError`.**

### Conclusion

The order is structurally guaranteed by Python's sequential execution model:

```
discover_plugins() → _load_plugin → register(ctx) → register_platform → platform_registry.register
    ↓ (synchronous return)
for platform in config.platforms: ← adapter loop only starts after discover_plugins() returns
    ↓
_create_adapter → platform_registry.create_adapter → adapter_factory(cfg)
    ↓
AgentVaultAdapter(cfg) → Platform("agentvault") ← resolves via registry, NEVER raises
```

The dual-class `_bind_to_hermes()` workaround the original plan-writer drafted is unnecessary. Direct `class AgentVaultAdapter(BasePlatformAdapter)` with `super().__init__(config=config, platform=Platform("agentvault"))` is the right pattern, and Phase 3 plan §11.4 (post-patch) ships it.

---

## 4. `MessageEvent` dataclass (Q1)

**Source:** `~/.hermes/hermes-agent/gateway/platforms/base.py:869-947`

Field set + defaults:

| Field | Type | Default |
|---|---|---|
| `text` | `str` | (required) |
| `message_type` | `MessageType` | `MessageType.TEXT` |
| `source` | `SessionSource` | `None` |
| `raw_message` | `Any` | `None` |
| `message_id` | `Optional[str]` | `None` |
| `platform_update_id` | `Optional[int]` | `None` |
| `media_urls` | `List[str]` | `[]` |
| `media_types` | `List[str]` | `[]` |
| `reply_to_message_id` | `Optional[str]` | `None` |
| `reply_to_text` | `Optional[str]` | `None` |
| `auto_skill` | `Optional[str \| list[str]]` | `None` |
| `channel_prompt` | `Optional[str]` | `None` |
| `internal` | `bool` | `False` |
| `timestamp` | `datetime` | `datetime.now()` |

Helper methods: `is_command()`, `get_command()`, `get_command_args()`.

**Implication for Phase 3:** `_on_inbound` only needs to set `text`, `message_type`, `source`, `message_id`. All other fields default. The plan §11.4 skeleton matches this.

---

## 5. `SendResult` dataclass (Q1)

**Source:** `~/.hermes/hermes-agent/gateway/platforms/base.py:984-991`

```python
@dataclass
class SendResult:
    success: bool                       # required
    message_id: Optional[str] = None
    error: Optional[str] = None
    raw_response: Any = None
    retryable: bool = False             # True triggers automatic retry
```

**Implication for Phase 3:** `AgentVaultAdapter.send` returns `SendResult(success=True, message_id=None)` on happy path. On `SecureChannel.send` exception, returns `SendResult(success=False, error=str(e), retryable=True)` — `retryable=True` lets Hermes' base layer auto-retry transient connection errors. Plan §11.4 already does this.

---

## 6. `SessionSource` dataclass (Q4)

**Source:** `~/.hermes/hermes-agent/gateway/session.py:70-94`

Required: `platform`, `chat_id`. All others default to `None` or sensible defaults.

| Field | Type | Default |
|---|---|---|
| `platform` | `Platform` | (required) |
| `chat_id` | `str` | (required) |
| `chat_name` | `Optional[str]` | `None` |
| `chat_type` | `str` | `"dm"` |
| `user_id` | `Optional[str]` | `None` |
| `user_name` | `Optional[str]` | `None` |
| `thread_id` | `Optional[str]` | `None` |
| `chat_topic` | `Optional[str]` | `None` |
| `user_id_alt` | `Optional[str]` | `None` |
| `chat_id_alt` | `Optional[str]` | `None` |
| `is_bot` | `bool` | `False` |
| `guild_id` | `Optional[str]` | `None` |
| `parent_chat_id` | `Optional[str]` | `None` |
| `message_id` | `Optional[str]` | `None` |

**Implication for Phase 3:** `_on_inbound` builds `SessionSource(platform=self.platform, chat_id=msg.conversation_id, chat_type="dm", user_id=msg.sender_device_id, message_id=msg.server_message_id)`. The `platform` field is the `Platform` enum value (not a string), pulled from `self.platform` set by `super().__init__`. Plan §11.4 matches this.

---

## 7. `register_platform` actual signature (Q2 + Spec D4)

**Source:** `~/.hermes/hermes-agent/hermes_cli/plugins.py:472-524`

```python
def register_platform(
    self,
    name: str,
    label: str,
    adapter_factory: Callable,
    check_fn: Callable,
    validate_config: Callable | None = None,
    required_env: list | None = None,
    install_hint: str = "",
    **entry_kwargs: Any,
) -> None:
```

`emoji`, `setup_fn`, `allowed_users_env`, `platform_hint`, etc. flow through `**entry_kwargs` and are unpacked into the `PlatformEntry` dataclass. Unknown keys raise `TypeError` from the dataclass constructor — which is fine, it gives a clear error.

**Confirmed:** `check_fn` is `Callable[[], bool]` (no args, returns truthy). IRC at `plugins/platforms/irc/__init__.py` uses `check_fn=lambda: True` — we do the same conceptually but with `_check_av_configured()` returning whether `~/.hermes/agentvault/<account>/state.json` exists.

---

## 8. `ENTRY_POINTS_GROUP` (verification)

**Source:** `~/.hermes/hermes-agent/hermes_cli/plugins.py:116`

```python
ENTRY_POINTS_GROUP = "hermes_agent.plugins"
```

Phase 3 plan §11.6 / `pyproject.toml` entry must be:

```toml
[project.entry-points."hermes_agent.plugins"]
agentvault = "agentvault_hermes.plugins.agentvault:register"
```

Confirmed — matches.

---

## 9. Device JWT TTL (DA #12)

**Empirical:** decoded the JWT in `~/.hermes/agentvault/default/state.json`:

```python
import base64, json
payload = json.loads(base64.urlsafe_b64decode(<jwt_payload> + '=='))
# {'sub': '8961dc93-bbc2-...', 'tid': 'a0d153a2-...', 'type': 'device',
#  'exp': 1785950171, 'iat': 1778174171}
ttl = payload['exp'] - payload['iat']
# 7,776,000 seconds = 90.0 days
```

**Source-side:** `packages/backend/app/services/device_jwt.py:9`:

```python
DEVICE_JWT_EXPIRY_DAYS = 90

def sign_device_jwt(device_id, tenant_id):
    payload = {
        "sub": str(device_id),
        "tid": str(tenant_id),
        "type": "device",
        "exp": datetime.now(timezone.utc) + timedelta(days=DEVICE_JWT_EXPIRY_DAYS),
        ...
    }
```

**TTL = 90 days** — far exceeds the 24h threshold in plan §19.4. **Trust-token refresh deferral is SAFE.** A Hermes process running >90 days will hit the 401-on-reconnect failure mode; document in plan §M4 + add a Phase 3.x follow-up if any user reports it.

---

## 10. Live Hermes boot verification

**Skipped — but justified.** The bootstrap-order trace in §3 above is structural, not contingent on runtime state. Every code path from `discover_plugins()` → `_load_plugin` → `register(ctx)` → `register_platform` → `platform_registry.register` is enforced by Python's synchronous call-chain. Python doesn't execute the `for platform in config.platforms.items()` loop at `run.py:2868` until `discover_plugins()` returns at line 2789.

A live boot would also require WS-31's deliverables (`packages/plugin-hermes/src/agentvault_hermes/plugins/agentvault/` + the `pyproject.toml` entry-point) to exist — which they don't yet. Booting Hermes today with the current `agentvault-hermes` package would surface "plugin not enabled" because the entry-point isn't shipped.

**WS-31 implementer must run the live boot AS PART OF WS-31's acceptance** (the plan §11.7 `test_register.py` covers the call-shape; §M2 covers actual Hermes process discovery). If WS-31 ships and `hermes plugins list` doesn't show `agentvault`, the failure is in WS-31's entry-point wiring, not in the bootstrap-order assumption verified here.

---

## 11. Outstanding plan-related observations

While reading the source, three minor points worth flagging:

1. **`gateway/run.py:2787-2793` re-invokes `discover_plugins()` defensively** because the gateway's lazy imports may have skipped the CLI-side call. This means our plugin loads even if the user invokes some non-standard entrypoint. No action needed.

2. **`platform_registry.create_adapter` calls `entry.check_fn()` BEFORE `entry.adapter_factory(config)`** (`platform_registry.py:173`). Our `_check_av_configured()` returns `True` only when `~/.hermes/agentvault/<account>/state.json` exists. If the user enables the plugin without running `agentvault-hermes setup`, `check_fn` returns False, the warning logs `"Platform 'AgentVault' requirements not met"` + the install_hint, and `create_adapter` returns None. The gateway then logs the platform as not connected and continues. This is the correct fail-soft behavior — verify WS-31 implementer's `_check_av_configured()` matches.

3. **`Platform._missing_` caches successful resolutions in `cls._value2member_map_`** (`gateway/config.py:136, 148`). After the first `Platform("agentvault")` call succeeds, all subsequent calls hit the cache directly without re-querying the registry. Identity-stable: `Platform("agentvault") is Platform("agentvault")` holds True. WS-31 implementer can rely on this for `event.source.platform == self.platform` comparisons.

---

## 12. Sign-off

All four blocker questions resolved. WS-28.0 status: **PASS**.

Sub-task dispatch order (per plan §6.1):

1. **WS-33** — wire envelope schema (`channel/outbox.py`).
2. **WS-29** — `Relay.send_message`.
3. **WS-28a** — `loop_prevention.py` + `lock_file.py` (verbatim modules).
4. **WS-28b** — `secure_channel.py` orchestrator.
5. **WS-30** — `Relay.receive_messages` + `inbox.py` + `mention.py`.
6. **WS-31** — `plugins/agentvault/` Hermes platform plugin.
7. **WS-32 + WS-35** — parallel.
8. **WS-34** — Phase 3 acceptance demo.

§M1 (live AV-backend run) gates Phase 3 closure per acceptance criterion #13.
