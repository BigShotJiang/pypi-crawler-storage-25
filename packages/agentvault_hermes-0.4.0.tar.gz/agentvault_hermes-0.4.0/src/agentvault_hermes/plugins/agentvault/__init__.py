"""AgentVault gateway-platform plugin for Hermes.

OC parity: packages/plugin/src/openclaw-entry.ts:1355-1410 (register flow)
+ :947-1070 (gateway.startAccount callback, the per-account adapter analogue).

Discovery: setuptools entry point under group ``hermes_agent.plugins``. Hermes
finds this via ``importlib.metadata.entry_points()`` at startup
(hermes_cli/plugins.py:116, :913-935).

Activation: the user must add ``agentvault`` to ``plugins.enabled`` in
``~/.hermes/config.yaml`` AND set ``gateway.platforms.agentvault.enabled: true``.
WS-32 makes ``agentvault-hermes setup`` write both keys automatically.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from agentvault_hermes.plugins.agentvault.adapter import AgentVaultAdapter

logger = logging.getLogger(__name__)


def _check_av_configured() -> bool:
    """Return True if the AV setup flow has run for the active profile.

    Recognizes both the new layout (``$HERMES_HOME/agentvault/state.json``) and
    the legacy default-profile layout (``~/.hermes/agentvault/default/state.json``)
    so an un-migrated install is still offered the AV platform — the migration
    then runs inside ``connect()``.
    """
    from agentvault_hermes.core.config import resolve_data_dir

    try:
        if (resolve_data_dir() / "state.json").exists():
            return True
        legacy = Path.home() / ".hermes" / "agentvault" / "default" / "state.json"
        if legacy.exists():
            return True
    except OSError:
        # Permission-denied or other filesystem errors → treat as "not configured."
        # Plugin discovery must never crash on this.
        return False
    return False


def _adapter_factory(cfg: Any, **kwargs: Any) -> AgentVaultAdapter:
    """Construct an AgentVaultAdapter for the active Hermes profile.

    The agent is resolved at gateway-run time via ``HERMES_HOME`` (set by
    Hermes for the active profile). The plugin reads no account/profile
    selector from the YAML config — that source-of-truth is the environment,
    not the file.

    Mirrors IRC's adapter_factory at
    ``~/.hermes/hermes-agent/plugins/platforms/irc/adapter.py:661`` (1-line
    ``lambda cfg: IRCAdapter(cfg)``).
    """
    return AgentVaultAdapter(cfg, **kwargs)


def register(ctx: Any) -> None:
    """Hermes plugin entry point.

    Source: ``hermes_cli/plugins.py:472-524`` (``register_platform``).
    The actual signature is
    ``(name, label, adapter_factory, check_fn, validate_config=None,
    required_env=None, install_hint="", **entry_kwargs)`` —
    ``emoji`` flows through ``**entry_kwargs`` to ``PlatformEntry``.
    """
    ctx.register_platform(
        name="agentvault",
        label="AgentVault",
        adapter_factory=_adapter_factory,
        check_fn=_check_av_configured,
        emoji="\U0001f510",  # closed-lock-with-key
        install_hint=(
            "Run `agentvault-hermes setup --token=<invite-token>` to enroll a device."
        ),
    )
    logger.info("AgentVault gateway platform registered")
