"""AgentVaultAdapter — BasePlatformAdapter subclass for the AV WebSocket.

OC parity: packages/plugin/src/openclaw-entry.ts:947-1340 (gateway.startAccount
callback that owns the SecureChannel + MLS state). Hermes equivalent: the
adapter owns SecureChannel + ``dict[conv_id, MlsGroupState]``.

Hermes integration pattern: mirrors IRC adapter at
``~/.hermes/hermes-agent/plugins/platforms/irc/adapter.py:101-110``.
- ``__init__(self, config, **kwargs)``: manufactures ``Platform("agentvault")``
  inline and calls ``super().__init__(config=config, platform=platform)``.
- The adapter is registered with the gateway via ``register_platform()``
  in ``__init__.py``; Hermes's ``_missing_`` on the Platform enum reads from
  ``platform_registry``, so ``Platform("agentvault")`` only resolves AFTER
  ``register(ctx)`` has run. WS-28.0 verifies the bootstrap order.

Lifecycle:
  __init__       — calls super; no account_id concept (HERMES_HOME is the source of truth)
  connect()      — migrates legacy layout, resolves data_dir via HERMES_HOME, loads state.json,
                   opens WS, hydrates MlsGroupStates, starts SecureChannel
  send()         — agent reply; SecureChannel.send encrypts + envelopes + pushes
  disconnect()   — stops SecureChannel
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional
from uuid import UUID

# Hermes runtime imports — these resolve only inside a Hermes process or
# under sys.modules patching for unit tests. Import order is intentional:
# - gateway.platforms.base provides BasePlatformAdapter + SendResult etc.
# - gateway.config provides the Platform enum (which we EXTEND via
#   register_platform → platform_registry → Platform._missing_).
from gateway.platforms.base import (  # type: ignore[import-not-found]
    BasePlatformAdapter,
    MessageEvent,
    MessageType,
    SendResult,
)
from gateway.config import Platform  # type: ignore[import-not-found]
from gateway.session import SessionSource  # type: ignore[import-not-found]

from agentvault_hermes.channel.secure_channel import InboundMessage, SecureChannel
from agentvault_hermes.core.config import (
    migrate_legacy_layout,
    resolve_profile,
)
from agentvault_hermes.core.identity import PersistedState, load_state
from agentvault_hermes.core.transport.relay import Relay
from agentvault_hermes.crypto import MlsGroupState, SigningKeypair
from agentvault_hermes.crypto.persistence import list_conversations

logger = logging.getLogger(__name__)


class AgentVaultAdapter(BasePlatformAdapter):  # type: ignore[misc]
    """BasePlatformAdapter for AV. One per Hermes profile; multiplexes conversations."""

    def __init__(self, config: Any, **kwargs: Any) -> None:
        # Mirror IRC adapter at plugins/platforms/irc/adapter.py:108-110.
        # Platform("agentvault") only resolves because register(ctx) ran
        # earlier and added "agentvault" to platform_registry; Platform's
        # _missing_ classmethod (gateway/config.py:111-154) accepts any
        # value that platform_registry.is_registered(...) confirms. WS-28.0
        # pre-flight verifies the bootstrap order.
        platform = Platform("agentvault")
        super().__init__(config=config, platform=platform)

        self._state: Optional[PersistedState] = None
        self._secure_channel: Optional[SecureChannel] = None
        self._mls_states: dict[str, MlsGroupState] = {}
        # _message_handler is set on the parent (BasePlatformAdapter) via
        # set_message_handler — we don't override.

    @property
    def name(self) -> str:
        return "AgentVault"

    async def connect(self) -> bool:
        """OC parity: openclaw-entry.ts:947-1070. Load state, open WS, start channel."""
        # Idempotency — DA WS-31 C2. Hermes lifecycle managers occasionally
        # call connect() twice (reconnect path, restart, supervisor flap);
        # without this guard the previous SecureChannel + WS + 4 background
        # tasks leak and both demux loops would race on the shared
        # _mls_states dict (ratchet corruption risk).
        if self._secure_channel is not None:
            logger.warning(
                "AV adapter: connect() called while already connected; "
                "tearing down previous channel"
            )
            await self._secure_channel.stop()
            self._secure_channel = None
        # Reset hydrated state so the rebuild reads fresh from disk and a
        # stale dict from a previous session can't bleed into the new one.
        self._mls_states.clear()

        # Spec §4.3: migrate_legacy_layout() at the top of every entry point so
        # an existing pre-feature install self-heals on first gateway run.
        migrate_legacy_layout()
        # resolve_profile(None) reads env-var driven config (api_url, agent_name,
        # data_dir) for the current profile. With profile=None it uses HERMES_HOME
        # (set by Hermes to the active profile's dir) or the default ~/.hermes.
        # The AGENTVAULT_HERMES_DATA_DIR test override is also respected.
        cfg = resolve_profile(None)
        data_dir = cfg.data_dir
        self._state = load_state(data_dir)
        if self._state is None:
            logger.error(
                "AV adapter: no state.json in %s — run `agentvault-hermes setup` first",
                data_dir,
            )
            return False

        # P11 (plan §3.6): build the SigningKeypair + device UUID once and
        # share between hydration AND SecureChannel. Same instance is used
        # by ``_ensure_pending_key_package`` to construct fresh
        # MlsGroupStates for KP generation on connect.
        signing = SigningKeypair(
            public_key=self._state.device_keys.signing_public,
            private_key=self._state.device_keys.signing_secret,
        )
        device_uuid = UUID(self._state.device_id)

        # Hydrate MlsGroupStates from existing conversations on disk BEFORE
        # SecureChannel exists so we can pass the full dict in. The seeding
        # of `_conv_to_group_id` then happens against the live SecureChannel.
        self._hydrate_mls_states(data_dir, signing, device_uuid)

        # Build Relay. Convert https:// → wss:// and http:// → ws:// so
        # local development against http://localhost:8000 still produces a
        # valid WS URL. Path is ``/api/v1/ws`` per the backend route at
        # ``packages/backend/app/api/v1/ws.py:246`` — NOT ``/ws``.
        ws_url = (
            cfg.api_url.replace("https://", "wss://").replace("http://", "ws://")
            + "/api/v1/ws"
        )
        relay = Relay(
            rest_base_url=cfg.api_url,
            ws_url=ws_url,
            device_jwt=self._state.device_jwt,
            device_id=self._state.device_id,
        )

        # Start SecureChannel
        self._secure_channel = SecureChannel(
            relay=relay,
            mls_states=self._mls_states,
            on_inbound=self._on_inbound,
            data_dir=data_dir,
            device_keys=signing,
            device_id=device_uuid,
            agent_name=cfg.agent_name or "default",
            account_id=cfg.profile or "default",
        )
        # Seed the conv→group_id cache on the freshly-built channel.
        self._seed_conv_to_group_id_map()

        # Partial-failure rollback — DA WS-31 C1. SecureChannel.start() opens
        # the WS and spawns background tasks; if it raises mid-startup the
        # adapter must tear those down before the exception propagates,
        # otherwise the WS + tasks leak (Hermes won't necessarily call
        # disconnect() on a connect() that raised).
        try:
            await self._secure_channel.start()
        except Exception:
            try:
                await self._secure_channel.stop()
            finally:
                self._secure_channel = None
            raise

        logger.info(
            "AV adapter connected: profile=%s tenant=%s",
            cfg.profile or "default",
            self._state.tenant_id,
        )
        return True

    async def disconnect(self) -> None:
        if self._secure_channel is not None:
            await self._secure_channel.stop()
            self._secure_channel = None

    async def send(
        self,
        chat_id: str,
        content: str,
        reply_to: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> SendResult:
        """OC parity: SecureChannel.send wrapping. Returns SendResult."""
        logger.debug("adapter.send entry conv=%s len=%d", chat_id[:8], len(content))
        if self._secure_channel is None:
            # The ``_secure_channel is None`` early-return used to be silent
            # (`SendResult(success=False, error="AV adapter not connected")`
            # with no log). That silence is what hid Bug B's symptom — the
            # underlying cause was actually elsewhere (see ``_on_inbound``
            # dispatch fix in PR #170), but a partial-failure ``connect()``
            # path CAN still leave us here, and a future regression would
            # otherwise mute the conversation with no observable diagnostic.
            # Kept loud at ERROR + ``retryable=True`` so Hermes' platform
            # reconnect watcher retries instead of giving up silently.
            logger.error(
                "AV adapter.send early-return: _secure_channel is None — "
                "Hermes platform reconnect must have failed partially. "
                "conv=%s. All sends for this adapter instance will silently "
                "fail until Hermes rebuilds the adapter via "
                "_platform_reconnect_watcher.",
                chat_id[:8],
            )
            return SendResult(
                success=False,
                error="AV adapter not connected (_secure_channel is None)",
                retryable=True,
            )
        try:
            await self._secure_channel.send(
                conversation_id=chat_id,
                plaintext=content.encode("utf-8"),
            )
            logger.debug("adapter.send success conv=%s", chat_id[:8])
            return SendResult(success=True, message_id=None)
        except Exception as exc:
            logger.exception("AV adapter send failed for %s: %s", chat_id, exc)
            return SendResult(success=False, error=str(exc), retryable=True)

    async def get_chat_info(self, chat_id: str) -> dict[str, Any]:
        """Return chat metadata for the gateway router.

        ``BasePlatformAdapter`` (gateway/platforms/base.py:3230-3240) requires
        a ``{name, type}`` dict. A ``chat_id`` known to the SecureChannel's
        ``RoomDirectory`` is reported as a ``room`` with its directory name;
        everything else is a ``dm``.

        OC parity: there is no direct OC equivalent — OC's plugin is the
        chat surface; Hermes' adapter is. Mirrors IRC adapter at
        ``plugins/platforms/irc/adapter.py:288-293`` (also a "name + type"
        synth without server lookup).
        """
        # action #234: a chat_id known to the RoomDirectory is a room.
        # action #238: a chat_id known to the A2AChannelRegistry is A2A.
        if self._secure_channel is not None:
            a2a_entry = self._secure_channel._a2a_registry.get(chat_id)
            if a2a_entry is not None:
                return {
                    "name": a2a_entry.topic or chat_id,
                    "type": "a2a",
                }
            entry = self._secure_channel._room_directory.get(chat_id)
            if entry is not None:
                return {"name": entry.name or chat_id, "type": "room"}
        return {"name": chat_id, "type": "dm"}

    # --- internals ------------------------------------------------------------

    def _hydrate_mls_states(
        self,
        data_dir: Path,
        signing: SigningKeypair,
        device_uuid: UUID,
    ) -> None:
        """Load every existing MlsGroupState from data_dir/conversations/<id>/.

        P11 (plan §3.6): SigningKeypair + device UUID are now constructed
        once at the call site and shared with SecureChannel, so we accept
        them as parameters rather than rebuilding here.
        """
        if self._state is None:
            return
        # `list_conversations` returns ConversationMeta objects; we need the
        # UUID off each one. (Plan §11.4 said "for conv_id_uuid in
        # list_conversations" — corrected here against the real source.)
        for meta in list_conversations(data_dir):
            conv_id_uuid = meta.conversation_id
            blob_path = data_dir / "conversations" / str(conv_id_uuid) / "mls_state.bin"
            if not blob_path.exists():
                continue
            try:
                state = MlsGroupState(device_keys=signing, device_id=device_uuid)
                state.import_state(blob_path.read_bytes())
                self._mls_states[str(conv_id_uuid)] = state
            except (ValueError, OSError, RuntimeError) as exc:
                # DA WS-31 M2: tightened from bare `Exception`. ValueError
                # covers corrupt TLV / bad bytes; OSError covers disk read
                # failures; RuntimeError covers MlsGroupState contract
                # violations (e.g. AlreadyInitialized). ERROR (not WARNING)
                # because hydration loss silently disables that conversation
                # for the lifetime of the connection — the user will see
                # "no MlsGroupState for conv X" on their first send with no
                # other clue.
                logger.error(
                    "Failed to hydrate MLS state for %s from %s: %s",
                    conv_id_uuid,
                    blob_path,
                    exc,
                )

    def _seed_conv_to_group_id_map(self) -> None:
        """Pre-populate SecureChannel._conv_to_group_id from hydrated states.

        This is an optimization — SecureChannel.send falls back to lazily
        deriving the group_id on first send if the cache is empty
        (channel/secure_channel.py:299-315) — but seeding it now means the
        first outbound send avoids a `state.group_id` round-trip under the
        per-conversation send lock.
        """
        if self._secure_channel is None:
            return
        for conv_id, state in self._mls_states.items():
            try:
                raw_gid = state.group_id
            except RuntimeError:
                # DA WS-31 M3: tightened from bare `Exception`. The only
                # case `state.group_id` raises is _require_initialized
                # failing (mls_group.py) — every successfully-imported
                # state has a group_id. Skip silently; SecureChannel will
                # surface a clearer error if these get used to send.
                continue
            if len(raw_gid) == 16:
                group_id_str = str(UUID(bytes=raw_gid))
            elif len(raw_gid) == 36:
                group_id_str = raw_gid.decode("ascii")
            else:
                logger.warning(
                    "Skipping conv %s: unexpected group_id length %d",
                    conv_id,
                    len(raw_gid),
                )
                continue
            # Intentional cross-package access — SecureChannel exposes this
            # cache as a private attribute; both modules ship in this
            # package and the seam is documented in
            # channel/secure_channel.py:152-156.
            self._secure_channel._conv_to_group_id[conv_id] = group_id_str

    async def _on_inbound(self, msg: InboundMessage) -> None:
        """SecureChannel callback: convert InboundMessage → MessageEvent → handler."""
        # Defense-in-depth — SecureChannel._demux_loop already filters
        # is_handshake before invoking on_inbound (channel/secure_channel.py
        # :443-444), but a future contract regression there would otherwise
        # surface MLS Commit/Proposal/Welcome frames to the LLM as empty
        # messages. DA WS-31 M5 — re-filter here.
        if msg.is_handshake:
            return
        if self._message_handler is None:
            logger.warning(
                "AV adapter: no message_handler set; dropping %s",
                msg.conversation_id[:8],
            )
            return

        # action #234: room messages route by room_id and carry chat_type
        # "room" so the gateway router treats them as multi-party.
        # action #238: A2A messages route by a2a_channel_id and carry
        # chat_type "a2a". A2A takes precedence over room (registries are
        # disjoint in practice, but explicit branch ordering matches the
        # SecureChannel._dispatch_inbound branch order).
        if msg.a2a_channel_id is not None:
            chat_id = msg.a2a_channel_id
            chat_type = "a2a"
        elif msg.room_id is not None:
            chat_id = msg.room_id
            chat_type = "room"
        else:
            chat_id = msg.conversation_id
            chat_type = "dm"
        source = SessionSource(
            platform=self.platform,  # set by super().__init__
            chat_id=chat_id,
            chat_type=chat_type,
            user_id=msg.sender_device_id,
            message_id=msg.server_message_id,
        )
        event = MessageEvent(
            text=msg.plaintext,
            message_type=MessageType.TEXT,
            source=source,
            message_id=msg.server_message_id,
        )
        # ROOT CAUSE FIX for Bug B (action_item #163, §M1 blocker):
        # Dispatch through ``self.handle_message`` — NOT
        # ``self._message_handler`` directly. The base
        # ``BasePlatformAdapter.handle_message`` is the proper Hermes entry
        # point: it spawns ``_process_message_background`` which in turn
        # calls the message handler AND THEN dispatches the returned
        # response via ``_send_with_retry → adapter.send``. Calling
        # ``_message_handler`` directly only does step 1 — the agent's
        # final response was awaited and silently discarded, never
        # reaching the WS. Mirrors IRC's plugins/platforms/irc/adapter.py
        # :508 (the same pattern every Hermes platform adapter uses).
        #
        # ``handle_message`` returns quickly: it spawns the background
        # task so this _on_inbound callback can return and let the
        # SecureChannel demux loop continue processing inbound frames
        # without blocking on agent execution.
        await self.handle_message(event)
