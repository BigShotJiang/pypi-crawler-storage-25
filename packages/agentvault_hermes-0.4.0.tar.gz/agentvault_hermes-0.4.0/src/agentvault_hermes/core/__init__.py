"""agentvault-hermes shared core library — MLS state, transport, identity, skills, telemetry."""
