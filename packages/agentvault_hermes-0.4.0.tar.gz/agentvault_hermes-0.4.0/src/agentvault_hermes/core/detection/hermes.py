"""Hermes install detection — 4-tier cascade (Layer 1 / #210-arc follow-up).

Used by `agentvault-hermes setup` as a hard pre-flight: if Hermes itself
isn't installed, setup refuses with a friendly error and points the user at
the Nous Research install instructions. We deliberately do NOT auto-install
Hermes — that is the user's responsibility (per Layer 1 spec).

Cascade (highest priority first):
  Tier 1: HERMES_INSTALL_DIR env var set AND points at an existing dir
  Tier 2: ~/.hermes/hermes-agent/ exists       (canonical install location)
  Tier 3: `which hermes` returns success       (binary on PATH)
  Tier 4: nothing detected
"""
from __future__ import annotations

import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class HermesDetectionResult:
    """Outcome of the Hermes detection cascade."""
    detected: bool
    tier: int  # 1 (most specific) → 4 (no detection)
    reason: str
    install_dir: Optional[Path] = None  # populated when tier 1 or 2 detects


def detect_hermes_install() -> HermesDetectionResult:
    """Run the 4-tier detection cascade. Returns the highest-tier match."""
    # Tier 1: explicit env-var override (user asserts where Hermes lives)
    env_value = os.environ.get("HERMES_INSTALL_DIR")
    if env_value:
        env_path = Path(env_value).expanduser()
        if env_path.is_dir():
            return HermesDetectionResult(
                detected=True,
                tier=1,
                reason=f"HERMES_INSTALL_DIR points at {env_path}",
                install_dir=env_path,
            )
        # Env var set but dir doesn't exist — ignore the override and fall
        # through to lower tiers (don't trust a stale env var alone).

    # Tier 2: canonical install location
    home = Path(os.path.expanduser("~"))
    default_dir = home / ".hermes" / "hermes-agent"
    if default_dir.is_dir():
        return HermesDetectionResult(
            detected=True,
            tier=2,
            reason=f"Hermes installation detected at {default_dir}",
            install_dir=default_dir,
        )

    # Tier 3: binary on PATH
    if shutil.which("hermes") is not None:
        return HermesDetectionResult(
            detected=True,
            tier=3,
            reason="hermes binary found on PATH",
            install_dir=None,
        )

    # Tier 4: nothing detected
    return HermesDetectionResult(
        detected=False,
        tier=4,
        reason="no Hermes installation detected",
        install_dir=None,
    )
