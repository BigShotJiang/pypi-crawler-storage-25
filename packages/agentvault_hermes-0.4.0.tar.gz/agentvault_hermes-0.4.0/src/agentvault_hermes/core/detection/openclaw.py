"""OpenClaw install detection — 4-tier cascade per design doc Q11.

Used by the setup CLI to pick a sensible default HTTP port. If OC is
installed on the same machine, we shift Hermes to 18791 to avoid colliding
with OC's 18790. Asymmetric risk: false positive (use 18791 unnecessarily)
is cosmetic; false negative (collision) is functional breakage. We always
take the safer side.
"""
from __future__ import annotations

import os
import shutil
from dataclasses import dataclass
from pathlib import Path


_PORT_WITH_OC = 18791
_PORT_DEFAULT = 18790


@dataclass(frozen=True)
class DetectionResult:
    """Outcome of the OC detection cascade."""
    recommended_port: int
    tier: int  # 1 (most specific) → 4 (no detection)
    reason: str


def detect_openclaw_install() -> DetectionResult:
    """Run the 4-tier detection cascade. Returns the highest-tier match."""
    home = Path(os.path.expanduser("~"))

    # Tier 1: ~/.openclaw/agentvault/ exists — OC AgentVault plugin set up
    if (home / ".openclaw" / "agentvault").is_dir():
        return DetectionResult(
            recommended_port=_PORT_WITH_OC,
            tier=1,
            reason=f"OpenClaw AgentVault plugin detected at {home}/.openclaw/agentvault/",
        )

    # Tier 2: ~/.openclaw/ exists — OC installed, plugin may follow
    if (home / ".openclaw").is_dir():
        return DetectionResult(
            recommended_port=_PORT_WITH_OC,
            tier=2,
            reason=f"OpenClaw installation detected at {home}/.openclaw/",
        )

    # Tier 3: openclaw binary on PATH
    if shutil.which("openclaw") is not None:
        return DetectionResult(
            recommended_port=_PORT_WITH_OC,
            tier=3,
            reason="openclaw binary found on PATH",
        )

    # Tier 4: clear
    return DetectionResult(
        recommended_port=_PORT_DEFAULT,
        tier=4,
        reason="no OpenClaw installation detected",
    )
