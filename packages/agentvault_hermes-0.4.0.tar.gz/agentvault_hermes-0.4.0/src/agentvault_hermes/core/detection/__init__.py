"""Detection — discover related installations on the user's machine."""

from agentvault_hermes.core.detection.hermes import (
    HermesDetectionResult,
    detect_hermes_install,
)
from agentvault_hermes.core.detection.openclaw import (
    DetectionResult,
    detect_openclaw_install,
)

__all__ = [
    "DetectionResult",
    "HermesDetectionResult",
    "detect_hermes_install",
    "detect_openclaw_install",
]
