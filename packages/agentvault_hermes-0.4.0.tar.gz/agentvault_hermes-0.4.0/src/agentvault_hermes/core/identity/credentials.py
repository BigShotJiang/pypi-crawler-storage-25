"""Persists device credentials to state.json with mode 0o600.

Layout:
{
  "version": 1,
  "device_id": "<uuid from POST /api/v1/enroll>",
  "tenant_id": "<uuid from device JWT 'tid' claim>",
  "device_jwt": "ey...",
  "device_keys": {
    "signing_secret": "<base64>",
    "signing_public": "<base64>",
    "x25519_secret": "<base64>",
    "x25519_public": "<base64>",
    "mls_init_secret": "<base64>",
    "mls_init_public": "<base64>"
  }
}

Idempotency: if state.json exists, the setup CLI treats it as "already
enrolled" and exits no-op. To re-enroll, delete the file first.
"""
from __future__ import annotations

import base64
import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from agentvault_hermes.core.identity.device import DeviceKeys


_STATE_FILE_NAME = "state.json"
_STATE_VERSION = 1


@dataclass(frozen=True)
class PersistedState:
    """The contents of state.json."""
    device_id: str
    tenant_id: str
    device_jwt: str
    device_keys: DeviceKeys


def _b64e(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _b64d(s: str) -> bytes:
    return base64.b64decode(s.encode("ascii"))


def _state_to_dict(state: PersistedState) -> dict[str, Any]:
    return {
        "version": _STATE_VERSION,
        "device_id": state.device_id,
        "tenant_id": state.tenant_id,
        "device_jwt": state.device_jwt,
        "device_keys": {
            "signing_secret": _b64e(state.device_keys.signing_secret),
            "signing_public": _b64e(state.device_keys.signing_public),
            "x25519_secret": _b64e(state.device_keys.x25519_secret),
            "x25519_public": _b64e(state.device_keys.x25519_public),
            "mls_init_secret": _b64e(state.device_keys.mls_init_secret),
            "mls_init_public": _b64e(state.device_keys.mls_init_public),
        },
    }


def _state_from_dict(d: dict[str, Any]) -> PersistedState:
    keys_data = d["device_keys"]
    keys = DeviceKeys(
        signing_secret=_b64d(keys_data["signing_secret"]),
        signing_public=_b64d(keys_data["signing_public"]),
        x25519_secret=_b64d(keys_data["x25519_secret"]),
        x25519_public=_b64d(keys_data["x25519_public"]),
        mls_init_secret=_b64d(keys_data["mls_init_secret"]),
        mls_init_public=_b64d(keys_data["mls_init_public"]),
    )
    return PersistedState(
        device_id=d["device_id"],
        tenant_id=d["tenant_id"],
        device_jwt=d["device_jwt"],
        device_keys=keys,
    )


def load_state(data_dir: Path) -> PersistedState | None:
    """Load persisted state. Returns None if no state.json exists.

    Raises ValueError if state.json exists but is malformed.
    """
    state_file = data_dir / _STATE_FILE_NAME
    if not state_file.exists():
        return None

    try:
        raw = state_file.read_text(encoding="utf-8")
        data = json.loads(raw)
    except (json.JSONDecodeError, OSError) as e:
        raise ValueError(f"state.json at {state_file} is malformed: {e}") from e

    if data.get("version") != _STATE_VERSION:
        raise ValueError(
            f"state.json version mismatch: expected {_STATE_VERSION}, got {data.get('version')}"
        )

    return _state_from_dict(data)


def save_state(data_dir: Path, state: PersistedState) -> None:
    """Atomically write state.json with mode 0o600.

    Uses a write-temp-then-rename pattern so a crash mid-write doesn't
    leave a corrupt state.json.
    """
    data_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    if os.name == "posix":
        os.chmod(data_dir, 0o700)

    state_file = data_dir / _STATE_FILE_NAME
    payload = json.dumps(_state_to_dict(state), indent=2)

    fd, tmp_path = tempfile.mkstemp(dir=str(data_dir), prefix=".state-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(payload)
        if os.name == "posix":
            os.chmod(tmp_path, 0o600)
        os.replace(tmp_path, state_file)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise
