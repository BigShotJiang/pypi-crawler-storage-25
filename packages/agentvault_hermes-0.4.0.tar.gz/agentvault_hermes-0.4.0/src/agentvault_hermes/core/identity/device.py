"""Device keypair generation.

Each device has three keys:
- signing (ed25519): identity / signing artifacts (DIDs, attestations)
- x25519: ratchet / key exchange (Double Ratchet for 1:1 fallback)
- mls init (x25519): MLS leaf init key

Generated via PyNaCl's libsodium bindings. Each is a fresh random secret.
"""
from __future__ import annotations

from dataclasses import dataclass

from nacl import public, signing


@dataclass(frozen=True)
class DeviceKeys:
    """A complete set of device keys.

    All ``*_secret`` fields are 32-byte private keys. ``*_public`` fields are
    derived; included for convenience and to avoid re-deriving on every send.
    """
    signing_secret: bytes
    signing_public: bytes
    x25519_secret: bytes
    x25519_public: bytes
    mls_init_secret: bytes
    mls_init_public: bytes


def generate_device_keys() -> DeviceKeys:
    """Generate a fresh set of device keys."""
    signing_key = signing.SigningKey.generate()
    x25519_secret_key = public.PrivateKey.generate()
    mls_init_secret_key = public.PrivateKey.generate()

    return DeviceKeys(
        signing_secret=bytes(signing_key),
        signing_public=bytes(signing_key.verify_key),
        x25519_secret=bytes(x25519_secret_key),
        x25519_public=bytes(x25519_secret_key.public_key),
        mls_init_secret=bytes(mls_init_secret_key),
        mls_init_public=bytes(mls_init_secret_key.public_key),
    )
