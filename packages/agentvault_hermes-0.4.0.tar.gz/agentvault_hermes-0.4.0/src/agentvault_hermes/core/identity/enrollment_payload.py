"""Build the enrollment payload that POST /api/v1/enroll expects.

The AV backend's enrollment endpoint validates a self-signed proof of
possession: an Ed25519 signature over the identity public key bytes,
verified with the same identity public key. This proves the caller holds
the matching private key.

Payload shape (per app/schemas/enrollment.py::EnrollRequest):
    {
        "invite_token": "<raw token from web UI>",
        "identity_public_key": "<hex-encoded Ed25519 pubkey>",
        "ephemeral_public_key": "<hex-encoded X25519 pubkey>",
        "proof_of_possession": "<hex-encoded Ed25519 signature>",
        "platform": "<optional platform string>",
    }

Field naming mirrors the backend exactly so the dict serializes 1:1.
"""
from __future__ import annotations

from nacl import exceptions as nacl_exc
from nacl import signing

from agentvault_hermes.core.identity.device import DeviceKeys


def _hex(data: bytes) -> str:
    return data.hex()


def _unhex(s: str) -> bytes:
    return bytes.fromhex(s)


def build_enrollment_payload(
    keys: DeviceKeys,
    invite_token: str,
    platform: str | None = None,
) -> dict[str, str]:
    """Build the dict POSTed to /api/v1/enroll.

    The proof_of_possession is an Ed25519 signature over the raw bytes of
    the identity public key, signed by the identity private key. The
    backend verifies it as ``verify_key.verify(identity_pubkey, sig)``.
    """
    identity_pubkey = keys.signing_public
    ephemeral_pubkey = keys.x25519_public
    signing_secret = signing.SigningKey(keys.signing_secret)

    signed = signing_secret.sign(identity_pubkey)
    proof = signed.signature

    payload: dict[str, str] = {
        "invite_token": invite_token,
        "identity_public_key": _hex(identity_pubkey),
        "ephemeral_public_key": _hex(ephemeral_pubkey),
        "proof_of_possession": _hex(proof),
    }
    if platform is not None:
        payload["platform"] = platform
    return payload


def verify_proof_of_possession(payload: dict[str, str]) -> bool:
    """Round-trip helper used in tests. Returns True if the proof is valid."""
    try:
        identity_pubkey = _unhex(payload["identity_public_key"])
        proof = _unhex(payload["proof_of_possession"])
    except (KeyError, ValueError):
        return False

    try:
        verify_key = signing.VerifyKey(identity_pubkey)
        verify_key.verify(identity_pubkey, proof)
        return True
    except (nacl_exc.BadSignatureError, ValueError):
        return False
