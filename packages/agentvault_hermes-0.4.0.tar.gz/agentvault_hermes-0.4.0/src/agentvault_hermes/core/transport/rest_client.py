"""Async REST client wrapper around httpx.AsyncClient.

Sets the Authorization: Bearer <device_jwt> header automatically when a
JWT is configured. Raises RestClientError on any 4xx/5xx response with
the response body included for debugging.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

import httpx

from agentvault_hermes import __version__

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class KeyPackageBatchResult:
    """Result of :meth:`RestClient.batch_fetch_key_packages`.

    ``available`` maps each device_id whose KeyPackage was returned to the raw
    KP bytes (hex-decoded). ``missing`` is the list of requested device_ids the
    backend returned no KeyPackage for — callers (e.g. the A2A founder) treat
    these as pending KPs to retry later via the connect-time reconcile loop.
    """

    available: dict[str, bytes] = field(default_factory=dict)
    missing: list[str] = field(default_factory=list)


class RestClientError(Exception):
    """Raised on any non-2xx HTTP response. ``status_code`` and ``body`` are populated."""

    def __init__(self, status_code: int, body: str, message: str):
        super().__init__(message)
        self.status_code = status_code
        self.body = body


def _user_agent() -> str:
    return f"agentvault-hermes/{__version__}"


class RestClient:
    """Minimal async REST client with device-JWT auth + structured errors.

    Use as an async context manager:
        async with RestClient(base_url="...", device_jwt="...") as client:
            data = await client.get("/v1/path")
    """

    def __init__(
        self,
        base_url: str,
        device_jwt: str | None = None,
        *,
        timeout: float = 30.0,
    ):
        self.base_url = base_url.rstrip("/")
        self.device_jwt = device_jwt
        self._timeout = timeout
        self._client: httpx.AsyncClient | None = None
        self._closed = False

    async def __aenter__(self) -> RestClient:
        headers: dict[str, str] = {
            "user-agent": _user_agent(),
            "accept": "application/json",
        }
        if self.device_jwt:
            headers["authorization"] = f"Bearer {self.device_jwt}"

        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=self._timeout,
            headers=headers,
        )
        return self

    async def __aexit__(self, *exc_info: Any) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._closed = True

    def _ensure_open(self) -> httpx.AsyncClient:
        if self._client is None or self._closed:
            raise RuntimeError("RestClient must be used inside an async context manager")
        return self._client

    async def _check_response(self, resp: httpx.Response) -> dict[str, Any]:
        if resp.status_code >= 400:
            body = resp.text
            raise RestClientError(
                status_code=resp.status_code,
                body=body,
                message=f"{resp.request.method} {resp.url.path} -> {resp.status_code}: {body[:500]}",
            )
        if not resp.content:
            return {}
        data: dict[str, Any] = resp.json()
        return data

    async def get(self, path: str, *, params: dict[str, Any] | None = None) -> dict[str, Any]:
        client = self._ensure_open()
        resp = await client.get(path, params=params)
        return await self._check_response(resp)

    async def post(
        self,
        path: str,
        *,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        client = self._ensure_open()
        headers = {"content-type": "application/json"} if json is not None else None
        resp = await client.post(path, json=json, headers=headers)
        return await self._check_response(resp)

    async def publish_key_package(self, kp_hex: str) -> dict[str, Any]:
        """POST /api/v1/mls/key-packages.

        Returns the response body ({id, device_id}). Raises RestClientError
        on 4xx/5xx. Does NOT pass device_id in the body — Hermes uses device-JWT
        auth and the backend resolves device_id from the token (mls.py:58).
        """
        if not kp_hex:
            raise ValueError("kp_hex must be a non-empty hex string")
        return await self.post(
            "/api/v1/mls/key-packages",
            json={"key_package": kp_hex},
        )

    async def pull_mls_delivery(self, device_id: str) -> list[dict[str, Any]]:
        """GET /api/v1/mls/delivery?device_id=<uuid>.

        Returns the `messages` list from the response (NOT the full envelope).
        Raises RestClientError on 4xx/5xx.
        """
        data = await self.get(
            "/api/v1/mls/delivery",
            params={"device_id": device_id},
        )
        raw = data.get("messages")
        return raw if isinstance(raw, list) else []

    async def ack_mls_delivery(self, queue_ids: list[str], device_id: str) -> int:
        """POST /api/v1/mls/delivery/ack. Returns count of acked rows."""
        if not queue_ids:
            raise ValueError("queue_ids must be a non-empty list")
        data = await self.post(
            "/api/v1/mls/delivery/ack",
            json={"queue_ids": queue_ids, "device_id": device_id},
        )
        raw = data.get("acked")
        return int(raw) if isinstance(raw, int) else 0

    async def list_a2a_channels(self) -> list[dict[str, Any]]:
        """GET /api/v1/a2a/channels — the channels this device is a member of.

        action #238: connect-time A2A reconciliation poll. The backend
        returns a JSON list (``A2AChannelListItem``); we coerce to ``list``
        to match the type contract.
        """
        client = self._ensure_open()
        resp = await client.get("/api/v1/a2a/channels")
        if resp.status_code >= 400:
            raise RestClientError(
                status_code=resp.status_code,
                body=resp.text,
                message=(
                    f"GET /api/v1/a2a/channels -> {resp.status_code}: "
                    f"{resp.text[:500]}"
                ),
            )
        data: Any = resp.json() if resp.content else []
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            channels = data.get("channels")
            return channels if isinstance(channels, list) else []
        return []

    async def get_a2a_group(self, a2a_channel_id: str) -> dict[str, Any]:
        """GET /api/v1/mls/a2a/{channel_id}/group — the channel's MLS group.

        Returns the ``MLSGroupResponse`` body (``{group_id, current_epoch,
        member_device_ids}``). Raises ``RestClientError`` on 4xx/5xx.
        """
        return await self.get(f"/api/v1/mls/a2a/{a2a_channel_id}/group")

    async def request_mls_welcome(
        self, group_id: str, device_id: str
    ) -> dict[str, Any]:
        """POST /api/v1/mls/groups/{group_id}/request-welcome.

        Backend requires ``device_id`` in the body — see
        ``WelcomeRequestBody`` at ``app/api/v1/mls.py:266``.
        """
        return await self.post(
            f"/api/v1/mls/groups/{group_id}/request-welcome",
            json={"device_id": device_id},
        )

    async def batch_fetch_key_packages(
        self, *, device_ids: list[str]
    ) -> KeyPackageBatchResult:
        """Fetch KeyPackages for a batch of devices.

        Calls ``GET /api/v1/mls/key-packages/batch?device_ids=uuid1,uuid2``
        (backend at ``app/api/v1/mls.py:67``). The backend returns a flat
        ``{str(device_uuid): kp_hex_str}`` dict containing only the devices
        it has a KeyPackage for; we compute ``missing`` from the request side.

        Empty ``device_ids`` short-circuits without an HTTP call.

        Returns a :class:`KeyPackageBatchResult` so callers (the A2A founder)
        can found with the available subset and mark the rest as pending.
        """
        if not device_ids:
            return KeyPackageBatchResult(available={}, missing=[])

        # Backend accepts a single comma-separated query string per its
        # Query(..., description="Comma-separated device UUIDs") binding.
        raw = await self.get(
            "/api/v1/mls/key-packages/batch",
            params={"device_ids": ",".join(device_ids)},
        )
        available: dict[str, bytes] = {}
        for device_id, kp_hex in (raw or {}).items():
            if not isinstance(kp_hex, str) or not kp_hex:
                continue
            try:
                available[str(device_id)] = bytes.fromhex(kp_hex)
            except ValueError:
                logger.warning(
                    "batch_fetch_key_packages: device=%s returned non-hex KP; skipping",
                    device_id,
                )
        missing = [d for d in device_ids if d not in available]
        return KeyPackageBatchResult(available=available, missing=missing)

    async def init_a2a_mls_group(
        self,
        *,
        channel_id: str,
        member_device_ids: list[str],
    ) -> str:
        """Register an MLS group for an A2A channel at the backend.

        Calls ``POST /api/v1/mls/a2a/{channel_id}/init`` with
        ``member_device_ids``. Idempotent on the backend (``mls.py:222`` —
        ``get_mls_group_by_a2a`` short-circuits when a group already exists for
        the channel; existing.member_device_ids is updated from the request
        only when previously empty).

        Returns the backend-assigned ``group_id`` as a string. Raises
        :class:`RestClientError` on non-2xx — caller logs + leaves the channel
        unfounded for reconcile retry.
        """
        body = await self.post(
            f"/api/v1/mls/a2a/{channel_id}/init",
            json={"member_device_ids": member_device_ids},
        )
        return str(body["group_id"])

    async def nack_mls_delivery(self, queue_ids: list[str]) -> None:
        """POST /api/v1/mls/delivery/nack. Best-effort; logs on failure."""
        if not queue_ids:
            return
        try:
            await self.post(
                "/api/v1/mls/delivery/nack",
                json={"queue_ids": queue_ids},
            )
        except RestClientError as exc:
            logger.warning(
                "nack_mls_delivery best-effort failure: status=%s body=%s",
                exc.status_code,
                exc.body[:200],
            )
