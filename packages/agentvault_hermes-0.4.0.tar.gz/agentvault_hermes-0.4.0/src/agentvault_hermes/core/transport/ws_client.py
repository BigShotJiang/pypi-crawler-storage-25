"""Async WebSocket client to the AgentVault backend with auto-reconnect.

The AV backend expects ``?token=<device-jwt>`` as a query parameter (per
the architecture spec). On disconnect, the client attempts exponential-
backoff reconnect up to ``max_reconnect_attempts`` times. Application code
interacts via send_json / receive_json; the reconnect logic is transparent.
"""
from __future__ import annotations

import enum
import json
from typing import Any
from urllib.parse import urlencode, urlparse, urlunparse

import httpx
from httpx_ws import aconnect_ws, AsyncWebSocketSession


class WsClientState(enum.Enum):
    CLOSED = "closed"
    CONNECTING = "connecting"
    OPEN = "open"
    RECONNECTING = "reconnecting"


def _append_query_params(url: str, **params: str | None) -> str:
    """Append (or merge) ``key=value`` query params to a URL.

    Order is preserved: existing query params first, then the new ones in
    ``params`` order. ``None`` values are skipped (so callers can pass
    optional fields like ``device_id``).
    """
    parsed = urlparse(url)
    existing_query = parsed.query
    filtered: dict[str, str] = {k: v for k, v in params.items() if v is not None}
    if not filtered:
        return url
    new_query = urlencode(filtered)
    if existing_query:
        new_query = f"{existing_query}&{new_query}"
    return urlunparse(parsed._replace(query=new_query))


class WsClient:
    """Minimal WebSocket client with auto-reconnect and JSON message helpers.

    Use as an async context manager:
        async with WsClient(url="...", device_jwt="...") as client:
            await client.send_json({...})
            msg = await client.receive_json()
    """

    def __init__(
        self,
        url: str,
        device_jwt: str,
        *,
        device_id: str | None = None,
        max_reconnect_attempts: int = 5,
        reconnect_base_delay: float = 0.5,
    ):
        self._base_url = url
        self._device_jwt = device_jwt
        # Optional ``device_id`` query param. The AV backend WS handler
        # (``packages/backend/app/api/v1/ws.py:246-360``) treats a connection
        # WITHOUT ``?device_id=<uuid>`` as the OWNER device — for an agent
        # adapter that's wrong. The JWT's ``sub`` claim IS the device_id but
        # ``_authenticate_ws`` discards it for non-API-key flows, so we have
        # to pass it explicitly.
        self._device_id = device_id
        self._max_reconnect = max_reconnect_attempts
        self._base_delay = reconnect_base_delay
        self._http_client: httpx.AsyncClient | None = None
        self._ws_ctx: Any = None
        self._ws: AsyncWebSocketSession | None = None
        self._state = WsClientState.CLOSED

    @property
    def state(self) -> WsClientState:
        return self._state

    async def __aenter__(self) -> WsClient:
        self._http_client = httpx.AsyncClient()
        await self._connect()
        return self

    async def __aexit__(self, *exc_info: Any) -> None:
        await self.close()

    async def _connect(self) -> None:
        assert self._http_client is not None
        self._state = WsClientState.CONNECTING
        url_with_query = _append_query_params(
            self._base_url, token=self._device_jwt, device_id=self._device_id
        )

        self._ws_ctx = aconnect_ws(url_with_query, self._http_client)
        self._ws = await self._ws_ctx.__aenter__()
        self._state = WsClientState.OPEN

    async def send_json(self, payload: dict[str, Any]) -> None:
        if self._state != WsClientState.OPEN or self._ws is None:
            raise RuntimeError(f"ws_client: not open (state={self._state.value})")
        try:
            await self._ws.send_text(json.dumps(payload))
        except Exception:
            # On WS failure, mark closed and propagate. Reconnect is handled
            # at a higher layer by ``SecureChannel._schedule_reconnect``,
            # which tears down the entire ``Relay`` (including this
            # ``WsClient``) and rebuilds it. Doing reconnect HERE created
            # cross-task ``aconnect_ws`` cancel-scope issues
            # (``Attempted to exit cancel scope in a different task``)
            # because the new ``aconnect_ws.__aenter__`` ran in a different
            # asyncio task than the original — anyio cancel scopes are
            # task-scoped and reject that.
            self._state = WsClientState.CLOSED
            raise

    async def receive_json(self) -> dict[str, Any]:
        if self._state != WsClientState.OPEN or self._ws is None:
            raise RuntimeError(f"ws_client: not open (state={self._state.value})")
        try:
            text = await self._ws.receive_text()
        except Exception:
            self._state = WsClientState.CLOSED
            raise
        data: dict[str, Any] = json.loads(text)
        return data

    async def close(self) -> None:
        if self._ws_ctx is not None:
            try:
                await self._ws_ctx.__aexit__(None, None, None)
            except Exception:
                pass
        if self._http_client is not None:
            await self._http_client.aclose()
        self._ws = None
        self._ws_ctx = None
        self._http_client = None
        self._state = WsClientState.CLOSED
