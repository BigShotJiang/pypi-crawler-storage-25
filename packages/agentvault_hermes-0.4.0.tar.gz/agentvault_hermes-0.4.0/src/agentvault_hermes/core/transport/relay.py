"""Relay — orchestrates outbound send + inbound dispatch.

Phase 3 implementation. Owns one ``WsClient`` and multiplexes all
conversations through that single socket. Methods:

- ``connect()`` / ``disconnect()`` — idempotent lifecycle wrappers
  around ``WsClient.__aenter__`` / ``__aexit__``.
- ``send_message(...)`` — encryption is the caller's job; this builds
  the outbound MLS envelope (per OC ``channel.ts:660-690``) and pushes
  it via ``WsClient.send_json``.
- ``receive_messages()`` — async generator. Stub here; **WS-30** ships
  the real implementation.

Source-of-truth: ``packages/plugin/src/channel.ts:660-690`` (outbound
MLS shape) and ``packages/plugin/src/channel.ts:2569-2740`` (connect
lifecycle). Backend reader: ``packages/backend/app/api/v1/ws.py:1063-1082``
(requires ``group_id`` + hex ``payload``; stamps ``sender_device_id``
from the authenticated session).

Relay does NOT send outbound heartbeats. AV's WS protocol has the
SERVER ping the agent (channel.ts:205-210); the agent watches for
inbound silence in ``SecureChannel._silence_timeout_task`` (WS-28b).
Adding outbound pings would invert OC parity and serve no purpose.
"""
from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from typing import Any, Optional

from agentvault_hermes.channel.outbox import WireEnvelope, make_outbound_mls_envelope
from agentvault_hermes.core.transport.ws_client import WsClient

logger = logging.getLogger(__name__)


class Relay:
    """Owns the WS to the AV backend. Multiplexes all conversations through one socket.

    The ``device_id`` is held for downstream telemetry / log correlation
    only; ``sender_device_id`` is **never** placed on the outbound MLS
    envelope (the backend stamps it from the authenticated session — see
    ``packages/backend/app/api/v1/ws.py:1063-1082``).
    """

    def __init__(
        self,
        rest_base_url: str,
        ws_url: str,
        device_jwt: str,
        device_id: str,
    ) -> None:
        self.rest_base_url = rest_base_url
        self.ws_url = ws_url
        self.device_jwt = device_jwt
        self.device_id = device_id
        self._ws: Optional[WsClient] = None

    async def connect(self) -> None:
        """Open the WebSocket. Idempotent — calling twice is a no-op."""
        if self._ws is not None:
            return
        # Pass ``device_id`` so the backend's WS handler treats us as the
        # agent device. Without it, the connection falls into the
        # owner-device branch (``packages/backend/app/api/v1/ws.py:355``)
        # and the agent never receives ``message_mls`` events for its own
        # conversations.
        ws = WsClient(
            url=self.ws_url,
            device_jwt=self.device_jwt,
            device_id=self.device_id,
        )
        await ws.__aenter__()
        # Only assign to ``self._ws`` after a successful handshake so a
        # mid-handshake exception leaves Relay in the disconnected state
        # and the next ``connect()`` retries cleanly.
        self._ws = ws

    async def disconnect(self) -> None:
        """Close the WebSocket. Idempotent — calling twice is a no-op."""
        if self._ws is None:
            return
        ws = self._ws
        # Clear the slot first so a second concurrent ``disconnect()``
        # call cannot double-close.
        self._ws = None
        try:
            await ws.__aexit__(None, None, None)
        except Exception:  # noqa: BLE001 — best-effort close
            logger.warning("Relay.disconnect: WsClient close raised", exc_info=True)

    async def send_message(
        self,
        conversation_id: str,
        group_id: str,
        epoch: int,
        ciphertext: bytes,
        *,
        message_type: str = "text",
        client_message_id: Optional[str] = None,
        topic_id: Optional[str] = None,
        parent_span_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
        hub_address: Optional[str] = None,
        sender_hub_id: Optional[str] = None,
        room_id: Optional[str] = None,
        a2a_channel_id: Optional[str] = None,
    ) -> None:
        """Push an already-encrypted MLS application message.

        OC parity: ``packages/plugin/src/channel.ts:660-690``.

        Builds the ``{event: "message_mls", data: {conversation_id,
        group_id, epoch, payload (hex), …}}`` envelope and pushes via
        ``WsClient.send_json``. The caller (``SecureChannel``) has
        already encrypted ``ciphertext`` and read ``state.epoch`` +
        ``state.group_id`` under the per-conversation lock. Relay does
        NOT touch crypto and does NOT include ``sender_device_id`` on
        the outbound envelope (the backend stamps it from the
        authenticated WebSocket session — see §3.7 + ``ws.py:1063-1082``).

        ``room_id``: when set, the envelope is emitted as
        ``room_message_mls`` carrying ``room_id`` — used for a room reply.

        Raises:
            RuntimeError: if ``connect()`` has not been called or after
                ``disconnect()``. Errors raised by ``WsClient.send_json``
                (e.g. when the socket is in ``RECONNECTING``) propagate
                verbatim — ``SecureChannel`` decides whether to retry.
        """
        if self._ws is None:
            raise RuntimeError("Relay.send_message: not connected")
        # action #238: A2A takes precedence over room when both somehow set;
        # the event name (and the data field attached below) shapes routing.
        if a2a_channel_id:
            event = "a2a_message_mls"
        elif room_id:
            event = "room_message_mls"
        else:
            event = "message_mls"
        envelope: WireEnvelope = make_outbound_mls_envelope(
            conversation_id=conversation_id,
            group_id=group_id,
            epoch=epoch,
            ciphertext=ciphertext,
            message_type=message_type,
            client_message_id=client_message_id,
            topic_id=topic_id,
            parent_span_id=parent_span_id,
            metadata=metadata,
            hub_address=hub_address,
            sender_hub_id=sender_hub_id,
            event=event,
            room_id=room_id,
        )
        # action #238: ``make_outbound_mls_envelope`` doesn't take
        # ``a2a_channel_id``; rather than widen its signature for the one
        # new event type, attach the field here so an A2A reply carries it
        # on the wire alongside the standard MLS frame.
        if a2a_channel_id:
            envelope.data["a2a_channel_id"] = a2a_channel_id
        await self._ws.send_json({"event": envelope.event, "data": envelope.data})

    # NOTE: ``send_heartbeat`` is intentionally NOT implemented. The AV
    # WS protocol has the SERVER ping the agent (channel.ts:205-210);
    # the agent watches for inbound silence in
    # ``SecureChannel._silence_timeout_task``. Adding outbound pings
    # would break OC parity and serve no purpose.

    async def send_json(self, payload: dict[str, Any]) -> None:
        """Send a raw JSON-serializable frame on the WebSocket.

        Used by orchestrator-level paths that need to emit a frame whose
        shape is not covered by the purpose-built methods (``send_message``,
        ``send_pong``). The first caller is Phase 4a PR-2's
        ``SecureChannel._send_initial_sync``, which emits one
        ``event:"mls_sync"`` frame per known group on every WS attach.

        Raises:
            RuntimeError: if ``connect()`` has not been called or after
                ``disconnect()``. ``WsClient.send_json`` errors (e.g. socket
                closed mid-send) propagate verbatim — the caller decides
                whether to retry or skip.
        """
        if self._ws is None:
            raise RuntimeError("Relay.send_json: not connected")
        await self._ws.send_json(payload)

    async def send_pong(self) -> None:
        """Echo a ``{"event": "pong"}`` reply to a server ping.

        The AV backend at ``packages/backend/app/api/v1/ws.py:762-764``
        handles ``event == "pong"`` by calling ``manager.on_pong(did)``,
        which refreshes the Redis ``device:<id>:alive`` TTL. WITHOUT this
        echo, the device's liveness key expires, ``manager.is_alive``
        returns False, and other devices' MLS-delivery pings silently
        drop — symptom is "agent appears connected but receives no
        messages." OC at ``channel.ts:2753-2756`` echoes the same shape.

        This is NOT outbound-heartbeat ownership — the SERVER drives the
        cadence (every 30s); we react. Calling it spontaneously is a
        no-op for liveness but harmless.
        """
        if self._ws is None:
            raise RuntimeError("Relay.send_pong: not connected")
        await self._ws.send_json({"event": "pong"})

    async def receive_messages(self) -> AsyncIterator[WireEnvelope]:
        """Yield inbound envelopes from the WebSocket as ``WireEnvelope``s.

        OC parity: ``packages/plugin/src/channel.ts:2742-3169`` (demux loop's
        inbound source). The orchestrator's ``_demux_loop`` consumes this
        iterator and dispatches by ``envelope.event``.

        Behavior:

        - Pulls one frame per iteration via ``WsClient.receive_json``.
        - Wraps the ``{event, data}`` dict into a ``WireEnvelope`` (typed
          downstream surface) — callers do NOT see raw dicts.
        - Malformed frames (missing ``event`` or ``data``, or wrong types)
          are logged and skipped; the next frame is yielded.
        - WS-level errors (connection drop, JSON decode failure) propagate
          so the demux loop can decide whether to reconnect. The
          ``WsClient`` itself attempts reconnect under the hood for transient
          drops, but a hard failure raises.

        Raises:
            RuntimeError: if ``connect()`` has not been called or after
                ``disconnect()``.
        """
        if self._ws is None:
            raise RuntimeError("Relay.receive_messages: not connected")
        while True:
            try:
                raw = await self._ws.receive_json()
            except Exception as e:
                # WsClient handles reconnect under the hood for transient
                # drops; a hard failure surfaces here. Re-raise so the
                # demux loop can decide whether to reconnect.
                logger.warning("Relay: WS receive error %s; reconnect underway", e)
                raise
            try:
                # ``data`` is optional on the wire — the backend sends
                # ``{"event": "ping"}`` with no data field
                # (``packages/backend/app/services/ws_manager.py:636``).
                # Default to an empty dict so the ping path doesn't get
                # dropped as malformed and the pong echo can fire (which
                # the backend's heartbeat liveness keeper requires —
                # without pong, the WS gets ``NORMAL_CLOSURE`` after
                # ``HEARTBEAT_TIMEOUT``).
                envelope = WireEnvelope(
                    event=str(raw["event"]),
                    data=raw.get("data", {}),
                )
            except (KeyError, TypeError) as e:
                logger.warning("Relay: malformed WS frame %r: %s", raw, e)
                continue
            if not isinstance(envelope.data, dict):
                logger.warning(
                    "Relay: WS frame data is not a dict (%r); skipping",
                    type(envelope.data).__name__,
                )
                continue
            yield envelope
