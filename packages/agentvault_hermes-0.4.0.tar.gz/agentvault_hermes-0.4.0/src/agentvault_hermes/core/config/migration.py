"""One-time migration from the legacy per-account layout to the profile layout.

Pre-feature installs stored the default agent at
``~/.hermes/agentvault/default/state.json``. The profile model puts the default
profile's AV data directly at ``~/.hermes/agentvault/``. This module moves it,
once, idempotently, without ever destroying data.
"""
from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path

logger = logging.getLogger(__name__)


def migrate_legacy_layout() -> None:
    """Migrate a legacy ``agentvault/default/`` layout to the new layout.

    Idempotent and non-destructive:
      * new-layout ``agentvault/state.json`` already present → no-op
      * legacy ``agentvault/default/state.json`` present → move every item from
        ``agentvault/default/`` up into ``agentvault/`` and remove the empty dir
      * both present (should not happen) → leave the legacy dir, log a warning
      * any non-``default`` legacy account dir → left in place, logged
    """
    av_root = Path(os.path.expanduser("~")) / ".hermes" / "agentvault"
    new_state = av_root / "state.json"
    legacy_default = av_root / "default"
    legacy_state = legacy_default / "state.json"

    if new_state.exists():
        if legacy_state.exists():
            logger.warning(
                "agentvault: both new (%s) and legacy (%s) state exist; "
                "leaving the legacy directory in place for inspection",
                new_state,
                legacy_state,
            )
        elif legacy_default.exists():
            logger.warning(
                "agentvault: migration appears partial — %s still exists "
                "after state.json was migrated; manual inspection may be needed",
                legacy_default,
            )
        return

    if not legacy_state.exists():
        # Nothing to migrate (fresh install, or already migrated).
        for child in _legacy_account_dirs(av_root):
            logger.warning(
                "agentvault: legacy non-default account dir %s left in place "
                "(multi-account is superseded by Hermes profiles)",
                child,
            )
        return

    logger.info("agentvault: migrating legacy default account → %s", av_root)
    for item in legacy_default.iterdir():
        dest = av_root / item.name
        if dest.exists():
            logger.warning("agentvault: migration skip — %s already exists", dest)
            continue
        try:
            shutil.move(str(item), str(dest))
        except OSError as exc:
            logger.warning(
                "agentvault: migration could not move %s → %s: %s", item, dest, exc
            )
            continue
    try:
        legacy_default.rmdir()
    except OSError as exc:
        logger.warning("agentvault: could not remove legacy %s: %s", legacy_default, exc)

    for child in _legacy_account_dirs(av_root):
        logger.warning(
            "agentvault: legacy non-default account dir %s left in place", child
        )


def _legacy_account_dirs(av_root: Path) -> list[Path]:
    """Return any leftover ``agentvault/<name>/`` account subdirectories."""
    if not av_root.exists():
        return []
    return [p for p in av_root.iterdir() if p.is_dir() and (p / "state.json").exists()]
