"""Config paths — profile-aware resolution rooted at HERMES_HOME.

A Hermes "profile" is an isolated agent instance. The default profile lives at
``~/.hermes``; a named profile at ``~/.hermes/profiles/<name>``. Hermes selects
a profile via the ``HERMES_HOME`` env var. The AgentVault plugin resolves all of
its paths off the same mechanism, so one machine runs N isolated AV agents.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

_DATA_DIR_ENV_VAR = "AGENTVAULT_HERMES_DATA_DIR"
_HERMES_HOME_ENV_VAR = "HERMES_HOME"
_VALID_PROFILE = re.compile(r"^[a-zA-Z0-9_-]+\Z")


def resolve_hermes_home(profile: str | None = None) -> Path:
    """Resolve the Hermes home directory for the target profile.

    Resolution order:
      * ``profile`` given (setup / doctor ``--profile``) → ``~/.hermes/profiles/<profile>``
      * else ``HERMES_HOME`` env set (runtime — Hermes sets it) → that path
      * else → ``~/.hermes`` (the default profile)

    ``profile`` must match ``[a-zA-Z0-9_-]+`` — prevents path traversal.
    """
    if profile is not None:
        if not _VALID_PROFILE.match(profile):
            raise ValueError(
                f"invalid profile name: {profile!r} — must match [a-zA-Z0-9_-]+"
            )
        home = Path(os.path.expanduser("~"))
        return home / ".hermes" / "profiles" / profile
    env_home = os.environ.get(_HERMES_HOME_ENV_VAR)
    if env_home:
        return Path(env_home).expanduser()
    return Path(os.path.expanduser("~")) / ".hermes"


def hermes_config_path(profile: str | None = None) -> Path:
    """Return the Hermes ``config.yaml`` for the profile."""
    return resolve_hermes_home(profile) / "config.yaml"


def resolve_data_dir(profile: str | None = None) -> Path:
    """Return the AgentVault data directory for the profile. Does not create it.

    With an explicit ``profile`` the path is always under that profile (so the
    profile's config and its state never diverge). With no profile, the
    ``AGENTVAULT_HERMES_DATA_DIR`` test override is honored.
    """
    if profile is None:
        env_override = os.environ.get(_DATA_DIR_ENV_VAR)
        if env_override:
            return Path(env_override).expanduser()
    return resolve_hermes_home(profile) / "agentvault"


def ensure_data_dir(profile: str | None = None) -> Path:
    """Create the data directory with mode 0o700 if absent. Idempotent."""
    path = resolve_data_dir(profile)
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    if os.name == "posix":
        os.chmod(path, 0o700)
    return path

