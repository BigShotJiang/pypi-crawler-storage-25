"""Resolved per-profile configuration for an AgentVault-bound Hermes agent."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from agentvault_hermes.core.config.data_dir import resolve_data_dir

_DEFAULT_API_URL = "https://api.agentvault.chat"
_DEFAULT_HTTP_PORT = 18790


@dataclass(frozen=True)
class ProfileConfig:
    """Resolved configuration for one AgentVault Hermes agent (one profile).

    ``profile`` is the Hermes profile name, or ``None`` for the default profile.
    ``http_port`` is retained for backward compatibility — it is not used to
    bind anything (the plugin's only network activity is an outbound WebSocket).
    """

    profile: str | None
    data_dir: Path
    api_url: str
    agent_name: str | None
    http_port: int


def resolve_profile(profile: str | None) -> ProfileConfig:
    """Resolve configuration for the given Hermes profile.

    ``None`` resolves to the default profile. The profile name is validated by
    ``resolve_data_dir`` → ``resolve_hermes_home``.
    """
    data_dir = resolve_data_dir(profile)

    api_url = os.environ.get("AGENTVAULT_HERMES_API_URL", _DEFAULT_API_URL)
    agent_name = os.environ.get("AGENTVAULT_HERMES_AGENT_NAME")

    port_str = os.environ.get("AGENTVAULT_HERMES_HTTP_PORT")
    if port_str is not None:
        try:
            http_port = int(port_str)
        except ValueError as e:
            raise ValueError(
                f"HTTP port (AGENTVAULT_HERMES_HTTP_PORT) must be an integer: {port_str!r}"
            ) from e
        if not (1 <= http_port <= 65535):
            raise ValueError(
                f"HTTP port (AGENTVAULT_HERMES_HTTP_PORT) out of range: {http_port}"
            )
    else:
        http_port = _DEFAULT_HTTP_PORT

    return ProfileConfig(
        profile=profile,
        data_dir=data_dir,
        api_url=api_url,
        agent_name=agent_name,
        http_port=http_port,
    )
