"""Config module — profile-aware path + ProfileConfig resolution."""

from agentvault_hermes.core.config.data_dir import (
    ensure_data_dir,
    hermes_config_path,
    resolve_data_dir,
    resolve_hermes_home,
)
from agentvault_hermes.core.config.account import (
    ProfileConfig,
    resolve_profile,
)
from agentvault_hermes.core.config.migration import migrate_legacy_layout

__all__ = [
    "ProfileConfig",
    "ensure_data_dir",
    "hermes_config_path",
    "migrate_legacy_layout",
    "resolve_data_dir",
    "resolve_hermes_home",
    "resolve_profile",
]
