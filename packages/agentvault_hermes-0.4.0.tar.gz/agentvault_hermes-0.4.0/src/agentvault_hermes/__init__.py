"""agentvault-hermes — native AgentVault plugin for Hermes."""

__version__ = "0.4.0"
__all__ = ["__version__"]
