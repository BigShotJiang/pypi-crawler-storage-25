"""Health-check command. Reports green/yellow/red per check section."""
from __future__ import annotations

import importlib
import importlib.metadata
import json
from dataclasses import dataclass, field
from pathlib import Path

import click

from agentvault_hermes.core.config import (
    hermes_config_path,
    migrate_legacy_layout,
    resolve_profile,
)
from agentvault_hermes.core.detection.openclaw import detect_openclaw_install
from agentvault_hermes.core.identity import load_state
from agentvault_hermes.core.transport.rest_client import RestClient


@dataclass
class DoctorResult:
    checks: dict[str, str] = field(default_factory=dict)
    suggestions: list[str] = field(default_factory=list)

    @property
    def all_green(self) -> bool:
        return all(v in ("PASS", "DETECTED", "NONE") for v in self.checks.values())


def _check_gateway_platform(config_path: Path) -> tuple[bool, str]:
    """Verify Hermes config has the AV gateway-platform plugin enabled.

    Checks (in order):
      1. Config file exists and parses as YAML.
      2. ``plugins.enabled`` contains ``"agentvault"``.
      3. ``gateway.platforms.agentvault.enabled`` is truthy.
      4. ``agentvault_hermes.plugins.agentvault`` is importable.

    The importability sub-check uses ``importlib.metadata.entry_points()``
    rather than ``importlib.import_module``. The plugin's
    ``adapter.py`` imports ``gateway.platforms.base`` from the Hermes runtime,
    which is not installed alongside the doctor process when run standalone
    (e.g. ``agentvault-hermes doctor`` from a shell, outside a Hermes
    invocation). Confirming the entry point is registered under
    ``hermes_agent.plugins`` is sufficient to prove the plugin is reachable
    by Hermes at startup and avoids a false-FAIL during standalone runs.

    The entry-point registration itself has no side effects — it's a pure
    metadata lookup against installed-package records.
    """
    if not config_path.exists():
        return False, f"Hermes config missing at {config_path}"
    try:
        from ruamel.yaml import YAML

        yaml = YAML()
        config = yaml.load(config_path.read_text()) or {}
    except Exception as exc:
        # Surface a one-line message; suppress traceback to keep doctor output
        # human-readable.
        return False, f"could not parse Hermes config: {exc}"

    # DA WS-32+35 CRITICAL-2: ruamel.yaml will happily parse a scalar
    # (e.g. a stray string at the top of the file) — every subsequent
    # ``.get`` would then raise ``AttributeError`` and the doctor would
    # surface a Python traceback instead of a clean diagnostic.
    if not isinstance(config, dict):
        return False, "Hermes config is not a YAML mapping (top-level must be a dict)"

    plugins_block = config.get("plugins") or {}
    if not isinstance(plugins_block, dict):
        return False, "Hermes config 'plugins' key is not a YAML mapping"
    enabled = plugins_block.get("enabled") or []
    if not isinstance(enabled, list):
        return False, "Hermes config 'plugins.enabled' is not a list"
    if "agentvault" not in enabled:
        return False, "agentvault not in plugins.enabled (re-run `agentvault-hermes setup`)"

    gateway_block = config.get("gateway") or {}
    if not isinstance(gateway_block, dict):
        return False, "Hermes config 'gateway' key is not a YAML mapping"
    platforms_block = gateway_block.get("platforms") or {}
    if not isinstance(platforms_block, dict):
        return False, "Hermes config 'gateway.platforms' is not a YAML mapping"
    av_cfg = platforms_block.get("agentvault") or {}
    if not isinstance(av_cfg, dict):
        return False, "Hermes config 'gateway.platforms.agentvault' is not a YAML mapping"
    if not av_cfg.get("enabled"):
        return (
            False,
            "gateway.platforms.agentvault.enabled is false (re-run `agentvault-hermes setup`)",
        )

    try:
        eps = importlib.metadata.entry_points(group="hermes_agent.plugins")
    except Exception as exc:  # pragma: no cover — extremely unlikely
        return False, f"plugin not importable: {exc} (try `python3 -m pip install -U agentvault-hermes`)"

    names = {ep.name for ep in eps}
    if "agentvault" not in names:
        return (
            False,
            "plugin not importable: no 'agentvault' entry point under "
            "'hermes_agent.plugins' (try `python3 -m pip install -U agentvault-hermes`)",
        )

    return True, "agentvault gateway platform enabled and importable"


def _check_mls_state(account_data_dir: Path) -> tuple[bool, str]:
    """Walk ``conversations/`` and validate each ``mls_state.bin`` + ``meta.json``.

    Skips any non-directory entries (e.g. ``.DS_Store`` files dropped by macOS
    Finder). ``Path.iterdir()`` follows symlinks by default; a symlinked
    conversation directory is therefore validated like any other entry, which
    matches the rest of Hermes' on-disk handling.

    No size cap is enforced. Real MLS states are typically <100KB; if a
    corruption bug ever produces a multi-GB blob, that's a separate diagnostic.
    """
    conv_root = account_data_dir / "conversations"
    if not conv_root.exists():
        return True, "no conversations on disk yet (clean state)"

    bad: list[str] = []
    n_total = 0
    for conv_dir in conv_root.iterdir():
        if not conv_dir.is_dir():
            # Skip files like ``.DS_Store``; only directories are conversations.
            continue
        n_total += 1
        blob = conv_dir / "mls_state.bin"
        meta = conv_dir / "meta.json"
        if not blob.exists():
            bad.append(f"{conv_dir.name}: missing mls_state.bin")
            continue
        if blob.stat().st_size == 0:
            bad.append(f"{conv_dir.name}: empty mls_state.bin")
            continue
        if not meta.exists():
            bad.append(f"{conv_dir.name}: missing meta.json")
            continue
        try:
            json.loads(meta.read_text())
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            bad.append(f"{conv_dir.name}: meta.json malformed")
            continue
    if bad:
        head = "; ".join(bad[:3])
        suffix = " ..." if len(bad) > 3 else ""
        return False, f"{len(bad)} bad conversation(s) of {n_total}: {head}{suffix}"
    return True, f"{n_total} conversation(s) all healthy"


async def run_doctor(profile: str | None = None) -> DoctorResult:
    migrate_legacy_layout()
    result = DoctorResult()

    click.echo("Configuration")
    try:
        cfg = resolve_profile(profile)
    except ValueError as e:
        result.checks["configuration"] = "FAIL"
        click.echo(f"  FAIL invalid profile: {e}")
        result.suggestions.append("Check the --profile value and re-run.")
        return result
    state = load_state(cfg.data_dir)
    if state is None:
        result.checks["configuration"] = "FAIL"
        click.echo(f"  FAIL no state.json at {cfg.data_dir}")
        result.suggestions.append("Run `agentvault-hermes setup --token=<your-token>` first.")
    else:
        result.checks["configuration"] = "PASS"
        click.echo(f"  OK state.json found (device_id: {state.device_id})")
        click.echo(f"  OK tenant binding: {state.tenant_id}")

    click.echo("Connectivity")
    try:
        async with RestClient(base_url=cfg.api_url) as client:
            await client.get("/health")
        result.checks["connectivity"] = "PASS"
        click.echo(f"  OK AV backend reachable at {cfg.api_url}")
    except Exception as e:
        # ``Exception`` subsumes ``RestClientError``; the older
        # ``(RestClientError, Exception)`` form was redundant per DA
        # WS-32+35 MINOR-1.
        result.checks["connectivity"] = "FAIL"
        click.echo(f"  FAIL backend unreachable: {e}")
        result.suggestions.append("Check internet connection or AGENTVAULT_HERMES_API_URL.")

    click.echo("OpenClaw coexistence")
    detection = detect_openclaw_install()
    if detection.tier <= 3:
        result.checks["openclaw"] = "DETECTED"
        click.echo(f"  OK {detection.reason}")
        click.echo(f"  OK Port assignment: Hermes={detection.recommended_port}, OC=18790")
    else:
        result.checks["openclaw"] = "NONE"
        click.echo("  OK no OpenClaw installation detected (using default port 18790)")

    # DA WS-32+35 MAJOR-2: each new check is wrapped so an unexpected
    # exception (e.g. PermissionError reading a 0600 config the doctor user
    # can't access) downgrades to FAIL with a one-line message instead of
    # crashing the whole doctor — and so a downstream check (mls_state)
    # still runs even if an upstream one (gateway_platform) blows up.
    click.echo("Gateway platform")
    try:
        gp_ok, gp_msg = _check_gateway_platform(hermes_config_path(profile))
    except Exception as exc:
        gp_ok, gp_msg = False, f"unexpected error: {exc}"
    if gp_ok:
        result.checks["gateway_platform"] = "PASS"
        click.echo(f"  OK {gp_msg}")
    else:
        result.checks["gateway_platform"] = "FAIL"
        click.echo(f"  FAIL {gp_msg}")
        result.suggestions.append("Re-run `agentvault-hermes setup` to register the plugin.")

    click.echo("MLS state")
    try:
        mls_ok, mls_msg = _check_mls_state(cfg.data_dir)
    except Exception as exc:
        mls_ok, mls_msg = False, f"unexpected error: {exc}"
    if mls_ok:
        result.checks["mls_state"] = "PASS"
        click.echo(f"  OK {mls_msg}")
    else:
        result.checks["mls_state"] = "FAIL"
        click.echo(f"  FAIL {mls_msg}")
        result.suggestions.append(
            "Inspect the listed conversation directories under "
            f"{cfg.data_dir / 'conversations'}."
        )

    if result.suggestions:
        click.echo("\nSuggestions:")
        for s in result.suggestions:
            click.echo(f"  - {s}")

    return result
