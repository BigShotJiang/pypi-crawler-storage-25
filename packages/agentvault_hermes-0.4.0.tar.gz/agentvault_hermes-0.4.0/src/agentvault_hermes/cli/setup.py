"""The Hermes setup flow.

User journey (mirrors OpenClaw plugin enrollment):

1. User logs into agentvault.chat, opens "My Agents" → "Quick Add",
   enters an agent name. Backend mints a single-use invite token.
2. User runs ``agentvault-hermes setup --token=<token>`` on their
   machine. This module runs.
3. While this module polls, user goes back to the web UI and clicks
   "Approve" on the pending device card.
4. Once approved, this module activates the device, persists state.json,
   and registers an MCP server entry with Hermes' config.yaml.

Steps emitted to stdout:
  [1/9] Check Hermes is installed (refuse non-zero if not — #Layer-1)
  [2/9] Ensure the Hermes profile exists (create if absent via `hermes profile create`)
  [3/9] Check environment
  [4/9] Detect OpenClaw coexistence
  [5/9] Generate device keys
  [6/9] Enroll device with backend (POST /api/v1/enroll)
  [7/9] Wait for approval (poll GET /api/v1/devices/{id}/status)
  [8/9] Activate device (POST /api/v1/devices/{id}/activate)
  [9/9] Register with Hermes (write <hermes_home>/config.yaml — per-profile path)

Idempotency: if state.json already exists in the profile's data dir,
the run is treated as a no-op success. To re-enroll, delete
``$HERMES_HOME/agentvault/state.json`` first (defaults to
``~/.hermes/agentvault/state.json``; for a named profile, the path is
``~/.hermes/profiles/<profile>/agentvault/state.json``).
"""
from __future__ import annotations

import asyncio
import base64
import json
import os
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import click
from ruamel.yaml import YAML

from agentvault_hermes.core.config import (
    ProfileConfig,
    ensure_data_dir,
    hermes_config_path,
    migrate_legacy_layout,
    resolve_hermes_home,
    resolve_profile,
)
from agentvault_hermes.core.detection.hermes import detect_hermes_install
from agentvault_hermes.core.detection.openclaw import detect_openclaw_install
from agentvault_hermes.core.identity import (
    PersistedState,
    generate_device_keys,
    load_state,
    save_state,
)
from agentvault_hermes.core.identity.enrollment_payload import (
    build_enrollment_payload,
)
from agentvault_hermes.core.transport.rest_client import RestClient, RestClientError


# Backend's STATUS_POLL_LIMIT is 1 request per 5 seconds per IP. Poll interval
# must stay above 5s to avoid 429 rate limits. 6s gives us a 1-second cushion.
_POLL_INTERVAL_SECONDS = 6.0
_POLL_MAX_ATTEMPTS = 50  # 50 × 6s = 5 minutes
_POLL_NETWORK_RETRIES = 3
_POLL_RATE_LIMIT_BACKOFF_SECONDS = 12.0  # 2× the rate-limit window for a clean escape


@dataclass
class SetupResult:
    success: bool
    device_id: str | None = None
    tenant_id: str | None = None
    error: str | None = None
    was_idempotent: bool = False


def _check_environment(profile: str | None) -> tuple[bool, str]:
    if sys.version_info < (3, 10):
        return False, f"Python 3.10+ required (have {sys.version_info.major}.{sys.version_info.minor})"
    if not hermes_config_path(profile).exists():
        return False, f"Hermes config not found at {hermes_config_path(profile)}"
    if shutil.which("hermes") is None:
        return False, "hermes binary not found on PATH"
    return True, "environment OK"


def _decode_jwt_tenant_id(jwt: str) -> str:
    """Extract the ``tid`` claim from a JWT. No signature verification —
    we trust the JWT we just received over HTTPS.

    Raises ValueError if the JWT is malformed or missing the claim.
    """
    parts = jwt.split(".")
    if len(parts) != 3:
        raise ValueError("malformed device JWT")
    payload_segment = parts[1]
    padding = "=" * (-len(payload_segment) % 4)
    raw = base64.urlsafe_b64decode(payload_segment + padding)
    payload = json.loads(raw)
    tid = payload.get("tid")
    if not isinstance(tid, str):
        raise ValueError("device JWT missing 'tid' claim")
    return tid


async def _enroll(
    api_url: str,
    payload: dict[str, str],
) -> dict[str, Any]:
    async with RestClient(base_url=api_url) as client:
        return await client.post("/api/v1/enroll", json=payload)


async def _get_device_status(
    api_url: str,
    device_id: str,
) -> dict[str, Any]:
    async with RestClient(base_url=api_url) as client:
        return await client.get(f"/api/v1/devices/{device_id}/status")


async def _activate(
    api_url: str,
    device_id: str,
) -> dict[str, Any]:
    async with RestClient(base_url=api_url) as client:
        return await client.post(f"/api/v1/devices/{device_id}/activate", json={})


async def _wait_for_approval(api_url: str, device_id: str) -> tuple[bool, str]:
    """Poll ``/devices/{id}/status`` until status is APPROVED.

    Returns ``(success, status_or_error)``. Returns success=False if the
    device is rejected, the timeout elapses, or repeated network errors
    exhaust the retry budget.
    """
    consecutive_errors = 0
    for attempt in range(_POLL_MAX_ATTEMPTS):
        try:
            status_resp = await _get_device_status(api_url, device_id)
            consecutive_errors = 0
        except RestClientError as e:
            # 429 is a rate-limit signal, not a genuine error. The backend
            # caps polls at 1 per 5s per IP; back off well past the window
            # rather than burning the retry budget on tight retries.
            if e.status_code == 429:
                await asyncio.sleep(_POLL_RATE_LIMIT_BACKOFF_SECONDS)
                continue
            consecutive_errors += 1
            if consecutive_errors > _POLL_NETWORK_RETRIES:
                return False, f"status polling failed: {e}"
            await asyncio.sleep(_POLL_INTERVAL_SECONDS)
            continue

        device_status = str(status_resp.get("status", "")).upper()
        if device_status == "APPROVED":
            return True, "APPROVED"
        if device_status == "REJECTED":
            return False, "device was rejected by owner"

        if attempt == 0:
            click.echo(
                "      (Open agentvault.chat → My Agents in your browser "
                "and click Approve on the pending device card.)"
            )

        await asyncio.sleep(_POLL_INTERVAL_SECONDS)

    return False, (
        f"timeout waiting for approval after "
        f"{int(_POLL_MAX_ATTEMPTS * _POLL_INTERVAL_SECONDS)}s — "
        "run setup again once you've approved in the web UI"
    )


def _modify_hermes_config(config_path: Path) -> None:
    """Add the AV MCP server entry + gateway-platform plugin entries to Hermes config.

    Three keys are written (additively, idempotent on re-run):

      * ``mcp_servers.agentvault``                — Phase 1 reservation, Phase 4 use.
      * ``plugins.enabled``                       — list; ``"agentvault"`` appended if absent.
      * ``gateway.platforms.agentvault.enabled``  — Phase 3 gateway-platform activation.

    The profile is resolved entirely via ``HERMES_HOME`` at runtime; neither
    ``account_id`` nor ``AGENTVAULT_HERMES_ACCOUNT`` are written — those keys
    are vestigial under the profile model, and the function's output is
    therefore profile-agnostic.

    Preserves existing comments and structure via ruamel.yaml. Writes a
    timestamped backup before any modification.

    Known limitation: the backup-then-write sequence is not atomic. Two
    concurrent ``agentvault-hermes setup`` invocations could race. ``setup``
    is an interactive command, so this is treated as low risk.
    """
    yaml = YAML()
    yaml.preserve_quotes = True

    # DA WS-32+35 CRITICAL-1: nanoseconds (not seconds) so two same-second
    # re-runs (e.g. idempotent re-run flow, fast tests) don't overwrite the
    # first backup with the now-modified config — destroying the user's
    # recovery artifact.
    backup = config_path.with_suffix(f".yaml.backup-{time.time_ns()}")
    backup.write_bytes(config_path.read_bytes())

    config = yaml.load(config_path.read_text()) or {}

    # 1. mcp_servers.agentvault — Phase 1 reservation, idempotent.
    #
    # Guard against an explicitly-null `mcp_servers:` key. ``dict.setdefault``
    # only writes the default when the key is *absent*; when the key is
    # present and the value is ``None``, ``setdefault`` returns ``None`` and
    # the next attribute access would crash. Coalesce the value the same way
    # for every section we touch below.
    mcp_section = config.get("mcp_servers") or {}
    config["mcp_servers"] = mcp_section
    mcp_section["agentvault"] = {
        "command": "agentvault-hermes",
        "args": ["serve"],
    }

    # 2. plugins.enabled — Phase 3 gateway-platform plugin discovery.
    plugins_section = config.get("plugins") or {}
    config["plugins"] = plugins_section
    enabled = plugins_section.get("enabled") or []
    plugins_section["enabled"] = enabled
    if "agentvault" not in enabled:
        enabled.append("agentvault")

    # 3. gateway.platforms.agentvault — Phase 3 platform activation.
    gateway_section = config.get("gateway") or {}
    config["gateway"] = gateway_section
    platforms_section = gateway_section.get("platforms") or {}
    gateway_section["platforms"] = platforms_section
    av_platform = platforms_section.get("agentvault") or {}
    platforms_section["agentvault"] = av_platform
    av_platform["enabled"] = True
    # account_id removed — the runtime resolves the agent via HERMES_HOME.

    with config_path.open("w") as f:
        yaml.dump(config, f)


def _seed_profile_from_default(profile: str | None) -> dict[str, bool]:
    """Seed a newly created profile's config + .env from the default profile.

    For named profiles (``profile`` not None), copies forward two pieces of
    configuration that ``hermes profile create`` does not write:

      * the top-level ``model:`` block from ``$HERMES_HOME/config.yaml``
        (default profile) → the new profile's ``config.yaml``
      * ``$HERMES_HOME/.env`` (default-profile API keys) → the new profile's
        ``.env``

    Neither is overwritten if already present on the target — the customer
    may have already configured this profile for a different model or with
    different keys. Silent no-op for the default profile (``profile is None``)
    or when the source file does not exist (first-ever-profile setup).

    Returns ``{"model_copied": bool, "env_copied": bool}`` so the CLI can
    render an accurate per-step status and tailor the post-setup
    "Next steps" message.
    """
    summary: dict[str, bool] = {"model_copied": False, "env_copied": False}
    if profile is None:
        return summary

    default_home = resolve_hermes_home(None)
    profile_home = resolve_hermes_home(profile)

    default_cfg_path = default_home / "config.yaml"
    profile_cfg_path = profile_home / "config.yaml"
    if default_cfg_path.exists() and profile_cfg_path.exists():
        yaml = YAML()
        yaml.preserve_quotes = True
        default_cfg = yaml.load(default_cfg_path.read_text()) or {}
        profile_cfg = yaml.load(profile_cfg_path.read_text()) or {}
        default_model = default_cfg.get("model")
        if default_model and not profile_cfg.get("model"):
            profile_cfg["model"] = default_model
            with profile_cfg_path.open("w") as f:
                yaml.dump(profile_cfg, f)
            summary["model_copied"] = True

    # .env files are secrets — force 0o600 regardless of source mode.
    default_env_path = default_home / ".env"
    profile_env_path = profile_home / ".env"
    if default_env_path.exists() and not profile_env_path.exists():
        shutil.copyfile(default_env_path, profile_env_path)
        try:
            os.chmod(profile_env_path, 0o600)
        except OSError:
            pass  # best-effort on filesystems without unix perms
        summary["env_copied"] = True

    return summary


def ensure_profile_exists(profile: str | None) -> None:
    """Ensure the Hermes profile exists, creating it via `hermes profile create`.

    No-op for the default profile (``profile is None``) and for an existing
    profile directory. Raises RuntimeError with the captured stderr if
    `hermes profile create` fails (e.g. a Hermes version without profiles),
    or if `hermes` is not on PATH (a Tier-1/Tier-2 install that hasn't
    re-sourced the shell — caught and re-raised as RuntimeError so callers
    only need one except clause).

    Real-Hermes-0.13.0 quirk: ``hermes profile create`` populates ``SOUL.md``
    and a few empty subdirs but does NOT create ``config.yaml``. The next
    setup step (``_check_environment``) requires the file to exist, so we
    seed a minimal one when absent. ruamel.yaml round-trips ``{}`` cleanly,
    so the later ``_modify_hermes_config`` call merges into it without
    clobbering anything Hermes might add later.
    """
    if profile is None:
        return
    profile_dir = resolve_hermes_home(profile)
    if profile_dir.is_dir():
        return
    try:
        result = subprocess.run(
            ["hermes", "profile", "create", profile],
            capture_output=True,
            text=True,
        )
    except FileNotFoundError as e:
        raise RuntimeError(
            f"`hermes` not found on PATH. Install Hermes or update PATH and re-run setup.\n{e}"
        ) from e
    if result.returncode != 0:
        raise RuntimeError(
            f"`hermes profile create {profile}` failed (exit {result.returncode}). "
            f"Your Hermes version may not support profiles — update Hermes.\n"
            f"{result.stderr.strip()}"
        )

    # Hermes 0.13.0 does not create config.yaml; seed an empty one so
    # _check_environment and _modify_hermes_config find a valid file. Only
    # writes when absent — never overwrites a Hermes-authored config.
    config_path = hermes_config_path(profile)
    if not config_path.exists():
        config_path.write_text("{}\n", encoding="utf-8")


async def run_setup(
    token: str,
    profile: str | None = None,
) -> SetupResult:
    """Run the 9-step setup flow against the AV backend."""
    migrate_legacy_layout()
    click.echo("[1/9] Checking that Hermes is installed...")
    hermes_det = detect_hermes_install()
    if not hermes_det.detected:
        return SetupResult(
            success=False,
            error=(
                "Hermes is not installed on this machine.\n"
                "\n"
                "agentvault-hermes is the AgentVault plugin for Hermes — it "
                "needs Hermes itself installed first. We deliberately do not "
                "auto-install Hermes; that is your call to make.\n"
                "\n"
                "Install Hermes (Linux / macOS / WSL2 / Termux):\n"
                "  curl -fsSL https://raw.githubusercontent.com/NousResearch/"
                "hermes-agent/main/scripts/install.sh | bash\n"
                "\n"
                "Windows (PowerShell, early beta):\n"
                "  iex (irm https://raw.githubusercontent.com/NousResearch/"
                "hermes-agent/main/scripts/install.ps1)\n"
                "\n"
                "Full instructions:  https://github.com/NousResearch/hermes-agent\n"
                "\n"
                "Then re-run:  agentvault-hermes setup --token=<your token>"
            ),
        )
    click.echo(f"      OK {hermes_det.reason}")

    click.echo("[2/9] Ensuring the Hermes profile exists...")
    try:
        ensure_profile_exists(profile)
    except ValueError as e:
        return SetupResult(success=False, error=f"invalid profile: {e}")
    except RuntimeError as e:
        return SetupResult(success=False, error=str(e))
    click.echo("      OK")

    click.echo("[3/9] Checking environment...")
    try:
        ok, env_msg = _check_environment(profile)
    except ValueError as e:
        return SetupResult(success=False, error=f"invalid profile: {e}")
    if not ok:
        return SetupResult(success=False, error=env_msg)
    click.echo(f"      OK {env_msg}")

    click.echo("[4/9] Detecting other AgentVault installations...")
    detection = detect_openclaw_install()
    click.echo(f"      OK {detection.reason}")

    try:
        cfg = resolve_profile(profile)
    except ValueError as e:
        return SetupResult(success=False, error=f"invalid profile: {e}")
    if "AGENTVAULT_HERMES_HTTP_PORT" not in os.environ:
        cfg = ProfileConfig(
            profile=cfg.profile,
            data_dir=cfg.data_dir,
            api_url=cfg.api_url,
            agent_name=cfg.agent_name,
            http_port=detection.recommended_port,
        )
    if detection.tier <= 3:
        click.echo(f"      -> Configuring Hermes to use port {cfg.http_port}")

    existing = load_state(cfg.data_dir)
    if existing is not None:
        click.echo(
            f"      Already enrolled (device_id: {existing.device_id}). "
            "Re-run is a no-op. To re-enroll, delete "
            f"{cfg.data_dir}/state.json first."
        )
        return SetupResult(
            success=True,
            device_id=existing.device_id,
            tenant_id=existing.tenant_id,
            was_idempotent=True,
        )

    click.echo("[5/9] Generating device keys...")
    keys = generate_device_keys()
    ensure_data_dir(profile)
    click.echo("      OK ed25519 + x25519 + MLS init keys generated")

    click.echo("[6/9] Enrolling device with AgentVault backend...")
    payload = build_enrollment_payload(keys, invite_token=token, platform="hermes")
    try:
        enrollment = await _enroll(cfg.api_url, payload)
    except RestClientError as e:
        return SetupResult(success=False, error=f"enrollment failed: {e}")
    device_id = str(enrollment["device_id"])
    click.echo(f"      OK Device enrolled (device_id: {device_id}, status: pending)")

    click.echo("[7/9] Waiting for approval in the web UI...")
    approved, msg = await _wait_for_approval(cfg.api_url, device_id)
    if not approved:
        return SetupResult(success=False, error=msg)
    click.echo(f"      OK {msg}")

    click.echo("[8/9] Activating device...")
    try:
        activation = await _activate(cfg.api_url, device_id)
    except RestClientError as e:
        return SetupResult(success=False, error=f"activation failed: {e}")
    device_jwt = str(activation["device_jwt"])

    try:
        tenant_id = _decode_jwt_tenant_id(device_jwt)
    except ValueError as e:
        return SetupResult(success=False, error=f"could not parse device JWT: {e}")
    click.echo(f"      OK Device active (tenant: {tenant_id})")

    state = PersistedState(
        device_id=device_id,
        tenant_id=tenant_id,
        device_jwt=device_jwt,
        device_keys=keys,
    )
    save_state(cfg.data_dir, state)

    click.echo("[9/9] Registering with Hermes...")
    seeded = _seed_profile_from_default(profile)
    _modify_hermes_config(hermes_config_path(profile))
    click.echo(f"      OK Added agentvault MCP server entry to {hermes_config_path(profile)}")
    if seeded["model_copied"]:
        click.echo("      OK Mirrored model config from default profile")
    if seeded["env_copied"]:
        click.echo("      OK Mirrored API keys (.env) from default profile")

    click.echo("")
    click.echo("Next steps:")
    if profile is not None:
        profile_home = resolve_hermes_home(profile)
        if not seeded["model_copied"]:
            click.echo(
                f"  - Configure your main model: add a top-level `model:` block to "
                f"{profile_home / 'config.yaml'} (the default profile's config.yaml "
                f"is a working reference)."
            )
        if not seeded["env_copied"]:
            click.echo(
                f"  - Configure LLM API keys: add (e.g.) OPENROUTER_API_KEY=... to "
                f"{profile_home / '.env'}"
            )
        click.echo(f"  - Start the gateway:  {profile} gateway start")
    else:
        click.echo(
            "  - If you don't have LLM API keys in your shell environment, "
            "run `hermes setup` to configure them."
        )
        click.echo("  - Start the gateway:  hermes gateway start")

    return SetupResult(
        success=True,
        device_id=device_id,
        tenant_id=tenant_id,
    )
