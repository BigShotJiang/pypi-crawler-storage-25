"""Console-script entry point. Dispatches to setup / doctor subcommands."""
from __future__ import annotations

import asyncio
import sys

import click

from agentvault_hermes import __version__
from agentvault_hermes.cli.doctor import run_doctor
from agentvault_hermes.cli.setup import run_setup


@click.group()
@click.version_option(__version__)
def cli() -> None:
    """AgentVault plugin for Hermes — secure E2E agent messaging."""


@cli.command()
@click.option("--token", required=True, help="AV API token (av_tok_...)")
@click.option("--profile", default=None, help="Hermes profile name (one agent per profile)")
def setup(token: str, profile: str | None) -> None:
    """Set up the plugin: create/select the Hermes profile, enroll, register."""
    result = asyncio.run(run_setup(token=token, profile=profile))
    if not result.success:
        click.echo(f"Setup failed: {result.error}", err=True)
        sys.exit(1)
    # Action_item #160: the gateway-run step is the single most-missed
    # post-setup action — first-time users hit "agent stays Offline" because
    # they thought running `hermes` alone was sufficient. Be explicit about
    # the two-process model so they don't have to dig through the README.
    click.echo(
        "\n"
        "Setup complete.\n"
        "\n"
        "Next step — start the Hermes gateway (REQUIRED to bring the agent online):\n"
        "  • foreground / debug:   hermes gateway run\n"
        "  • background service:   hermes gateway install && hermes gateway start\n"
        "\n"
        "The `hermes` TUI alone only registers plugins — it does NOT open the\n"
        "WebSocket to AgentVault. Without a running gateway, agentvault.chat\n"
        "will show your agent as Offline indefinitely.\n"
        "\n"
        "Verify with `agentvault-hermes doctor` (config / connectivity / OC\n"
        "coexistence) and `hermes gateway status` (daemon liveness)."
    )


@cli.command()
@click.option("--profile", default=None, help="Hermes profile name (one agent per profile)")
def doctor(profile: str | None) -> None:
    """Run health checks against the local installation."""
    result = asyncio.run(run_doctor(profile=profile))
    if not result.all_green:
        sys.exit(1)


def main() -> None:
    cli()


if __name__ == "__main__":
    main()
