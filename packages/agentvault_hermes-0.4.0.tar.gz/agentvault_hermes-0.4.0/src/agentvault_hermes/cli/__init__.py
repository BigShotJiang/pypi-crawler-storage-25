"""CLI entry points for agentvault-hermes. Implemented in WS-13."""
