"""Cross-cutting conversation persistence helpers.

Per-state-type save/load lives on the state classes themselves
(MlsGroupState.save, DoubleRatchet.serialize). This module owns the
non-protocol-specific bits: meta.json read/write, conversation listing,
recursive delete.

Atomic-write idiom matches Phase 1's core/identity/credentials.py:
mkstemp inside the target directory, fdopen-write, chmod 0o600 on the
temp file (defense-in-depth — tempfile.mkstemp already creates 0o600
on POSIX), then os.replace. cleanup-on-exception ensures no temp file
leaks on partial failure.
"""
from __future__ import annotations

import json
import os
import shutil
import tempfile
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Literal


ConversationType = Literal["direct", "room", "a2a"]

_META_FILE_NAME = "meta.json"
_META_VERSION = 1
_VALID_TYPES = {"direct", "room", "a2a"}


@dataclass(frozen=True)
class ConversationMeta:
    """Per-conversation metadata stored in meta.json."""

    conversation_id: uuid.UUID
    type: ConversationType
    created_at: datetime
    last_message_ts: datetime | None


def _conversations_dir(data_dir: Path) -> Path:
    return data_dir / "conversations"


def _conv_dir(data_dir: Path, conversation_id: uuid.UUID) -> Path:
    return _conversations_dir(data_dir) / str(conversation_id)


def _meta_to_dict(meta: ConversationMeta) -> dict[str, Any]:
    return {
        "version": _META_VERSION,
        "conversation_id": str(meta.conversation_id),
        "type": meta.type,
        "created_at": meta.created_at.isoformat(),
        "last_message_ts": (
            meta.last_message_ts.isoformat() if meta.last_message_ts else None
        ),
    }


def _meta_from_dict(data: dict[str, Any]) -> ConversationMeta:
    type_value = data["type"]
    if type_value not in _VALID_TYPES:
        raise ValueError(
            f"meta.json: invalid 'type' field {type_value!r}, "
            f"expected one of {sorted(_VALID_TYPES)}"
        )
    last_ts_raw = data.get("last_message_ts")
    return ConversationMeta(
        conversation_id=uuid.UUID(data["conversation_id"]),
        type=type_value,
        created_at=datetime.fromisoformat(data["created_at"]),
        last_message_ts=(
            datetime.fromisoformat(last_ts_raw) if last_ts_raw else None
        ),
    )


def write_meta(
    data_dir: Path, conversation_id: uuid.UUID, meta: ConversationMeta
) -> None:
    """Atomic write of meta.json with mode 0o600. Creates parent dirs at 0o700.

    The conversation directory and the parent conversations/ root are both
    chmod'd to 0o700 on every call, even if they already exist. This is the
    security default; callers who deliberately set non-0o700 will have it
    overwritten.
    """
    conv_dir = _conv_dir(data_dir, conversation_id)
    conv_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    if os.name == "posix":
        os.chmod(_conversations_dir(data_dir), 0o700)
        os.chmod(conv_dir, 0o700)

    meta_file = conv_dir / _META_FILE_NAME
    payload = json.dumps(_meta_to_dict(meta), indent=2)

    fd, tmp_path = tempfile.mkstemp(dir=str(conv_dir), prefix=".meta-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(payload)
        if os.name == "posix":
            os.chmod(tmp_path, 0o600)
        os.replace(tmp_path, meta_file)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def read_meta(
    data_dir: Path, conversation_id: uuid.UUID
) -> ConversationMeta | None:
    """Load meta.json. Returns None if no meta.json exists.

    Raises ValueError if meta.json exists but is malformed or has an
    unexpected version.
    """
    meta_file = _conv_dir(data_dir, conversation_id) / _META_FILE_NAME
    if not meta_file.exists():
        return None
    try:
        raw = meta_file.read_text(encoding="utf-8")
        data = json.loads(raw)
    except (json.JSONDecodeError, OSError) as e:
        raise ValueError(f"meta.json at {meta_file} is malformed: {e}") from e

    if data.get("version") != _META_VERSION:
        raise ValueError(
            f"meta.json version mismatch: expected {_META_VERSION}, "
            f"got {data.get('version')!r}"
        )
    return _meta_from_dict(data)


def list_conversations(data_dir: Path) -> list[ConversationMeta]:
    """Enumerate all conversation directories under data_dir.

    Non-UUID directory names are silently skipped. If a meta.json is malformed
    or has version mismatch, the underlying read_meta raises ValueError and the
    enumeration aborts (fail-fast on partial corruption — caller should detect
    and remediate). If you need skip-and-continue semantics, wrap the call.
    """
    conv_root = _conversations_dir(data_dir)
    if not conv_root.exists():
        return []

    metas: list[ConversationMeta] = []
    for child in conv_root.iterdir():
        if not child.is_dir():
            continue
        try:
            cid = uuid.UUID(child.name)
        except ValueError:
            continue  # skip non-UUID directories
        meta = read_meta(data_dir, cid)
        if meta is not None:
            metas.append(meta)
    return metas


def delete_conversation(data_dir: Path, conversation_id: uuid.UUID) -> None:
    """Recursively remove the conversation directory. Idempotent on missing."""
    conv_dir = _conv_dir(data_dir, conversation_id)
    if conv_dir.exists():
        shutil.rmtree(conv_dir)
