"""Double Ratchet — Signal-style 1:1 encryption with per-message forward secrecy.

Reference: packages/crypto/src/ratchet.ts. This Python port must produce
byte-identical output for the same inputs; recorded-vector verification
in WS-24.

Layout follows OC's ratchet.ts:
- Constants (MAX_SKIP, KDF seeds)
- Helper functions (KDF chain, KDF root, DH keypair, DH op, header
  serialization, header signing/verification)
- State types (RatchetHeader, EncryptedMessage, ChainState, SkippedKey,
  DHKeypair, SigningKeypair)
- DoubleRatchet class (init_initiator, init_receiver, encrypt, decrypt,
  serialize, deserialize)

Per Phase 2 design: header encryption envelope_version 2.0.0 is enabled
from day 1 (matches OC's recent default). MAX_SKIP=1000 message keys
per chain. Telemetry hooks are no-op default callbacks; Phase 6 wires
them to dashboards.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Callable, Optional, TypedDict

from nacl import bindings, exceptions as nacl_exc, signing as nacl_signing

from agentvault_hermes.crypto.primitives import xchacha20_decrypt, xchacha20_encrypt


# --- Constants (mirror OC byte-for-byte) ---

MAX_SKIP = 1000
CHAIN_KEY_SEED = b"\x01"
MSG_KEY_SEED = b"\x02"
HEADER_KEY_SEED = b"\x03"
ENVELOPE_V2 = "2.0.0"
"""OC wire-format envelope identifier for header encryption.

Matches packages/crypto/src/ratchet.ts:227-235 V2 branch return value.
The 2.0.0 string is hardcoded by OC; do not change."""


# --- State types ---

@dataclass(frozen=True)
class DHKeypair:
    public_key: bytes   # 32-byte X25519 public
    private_key: bytes  # 32-byte X25519 secret


@dataclass(frozen=True)
class SigningKeypair:
    """Hermes-side Ed25519 keypair container.

    ``private_key`` is the **32-byte Ed25519 seed**, NOT the 64-byte
    libsodium sk (``seed || pk``). This intentionally diverges from OC's
    TS impl (which records 64 bytes in
    ``serialized_state.identityKeypair.privateKey``) for three reasons:

    1. PyNaCl's ``signing.SigningKey`` constructor accepts only the
       32-byte seed; passing 64 bytes raises ``ValueError``.
    2. ``DeviceKeys.signing_secret`` (in
       ``core/identity/device.py``) and ``X3DHParams.my_identity_private``
       both store seeds. Keeping all three Ed25519-private-key holders
       on one consistent 32-byte representation avoids
       seed-vs-sk slice bugs at every conversion boundary.
    3. The divergence is **disk-only state, never wire-format** — OC and
       Hermes never exchange ratchet state files, so there is no
       interop scenario where the byte-level difference matters.

    The vector test ``test_ratchet_init_serialized_state_byte_equality``
    in ``tests/unit/crypto/vectors/test_ratchet_vectors.py`` carves out
    ``identityKeypair.privateKey`` from byte-equality and verifies that
    the OC 64-byte sk is the ``seed || pk`` form of Hermes' 32-byte
    seed (i.e., the seed IS the 32-byte prefix of the OC sk). All
    other ``serialized_state`` fields match byte-for-byte.

    Action #125 (refactor ``private_key`` to 64-byte libsodium sk) was
    investigated 2026-05-10 by a code-explorer + Devils-Advocate
    brainstorm pair and closed as ``wontfix``. The refactor would
    introduce type asymmetry across ``DeviceKeys``/``X3DHParams``/
    ``SigningKeypair``, replace today's structurally-impossible-typo
    with slice-bug-prone ``[:32]`` calls in ``_sign_header``, and
    optimize for fixture aesthetics over wire-format correctness. The
    carve-out is the right answer; re-open ONLY if a future phase
    surfaces a concrete interop scenario where the 32/64 representation
    difference matters on the wire.
    """

    public_key: bytes   # 32-byte Ed25519 public
    private_key: bytes  # 32-byte Ed25519 seed (NOT 64-byte libsodium sk)


@dataclass(frozen=True)
class RatchetHeader:
    """Plaintext header carried with each ciphertext.

    For envelope_version 2.0.0 ("header encryption"), this is encrypted
    with a separate header key; for v1, it travels in the clear.
    """
    dh_public_key: bytes        # current sending DH public key
    previous_chain_length: int  # number of messages in the previous sending chain
    message_number: int         # message index within the current sending chain


@dataclass
class EncryptedMessage:
    """Wire-format envelope for a Double Ratchet ciphertext."""
    header: RatchetHeader
    header_signature: bytes
    ciphertext: bytes
    nonce: bytes
    envelope_version: Optional[str] = None  # "2.0.0" when header is encrypted
    encrypted_header: Optional[bytes] = None
    header_nonce: Optional[bytes] = None


class RatchetTelemetryEvent(TypedDict):
    """Payload for on_encrypt / on_decrypt telemetry hooks.

    Phase 6 will wire these to dashboards. Shape is locked here so encrypt
    and decrypt hooks cannot drift.
    """
    message_number: int
    ciphertext_size: int
    envelope_version: Optional[str]   # "2.0.0" for V2 envelope, None for V1


@dataclass
class ChainState:
    chain_key: bytes
    message_number: int


@dataclass
class SkippedKey:
    dh_pub_hex: str       # hex of the DH public key the sender used
    n: int                # message number
    message_key: bytes
    header_key: Optional[bytes] = None  # populated for v2 out-of-order


# --- Helper functions ---

def _kdf_chain_key(chain_key: bytes) -> tuple[bytes, bytes, bytes]:
    """Advance the chain key + derive the message key + header key.

    Mirrors OC's kdfChainKey (ratchet.ts:50-59):
        next_chain_key = crypto_generichash(32, chain_key, key=CHAIN_KEY_SEED)
        message_key    = crypto_generichash(32, chain_key, key=MSG_KEY_SEED)
        header_key     = crypto_generichash(32, chain_key, key=HEADER_KEY_SEED)

    libsodium's crypto_generichash with a single-byte "key" maps to
    BLAKE2b with that key — so hashlib.blake2b(chain_key, key=SEED) is
    byte-identical.
    """
    next_chain = hashlib.blake2b(chain_key, digest_size=32, key=CHAIN_KEY_SEED).digest()
    msg_key = hashlib.blake2b(chain_key, digest_size=32, key=MSG_KEY_SEED).digest()
    header_key = hashlib.blake2b(chain_key, digest_size=32, key=HEADER_KEY_SEED).digest()
    return next_chain, msg_key, header_key


def _kdf_root_key(root_key: bytes, dh_output: bytes) -> tuple[bytes, bytes]:
    """Advance the root key from a DH output. Returns (new_root, new_chain).

    Mirrors OC's kdfRootKey (ratchet.ts:61-74):
        derived = crypto_generichash(64, root_key || dh_output)   # NO key
        new_root_key  = derived[:32]
        new_chain_key = derived[32:64]

    Note the inputs are CONCATENATED into the hash input; there is NO
    separate BLAKE2b key. This differs from kdfChainKey above.
    """
    derived = hashlib.blake2b(root_key + dh_output, digest_size=64).digest()
    new_root = derived[:32]
    new_chain = derived[32:64]
    return new_root, new_chain


def _generate_dh_keypair() -> DHKeypair:
    """Generate a fresh X25519 keypair for DH ratcheting."""
    pk, sk = bindings.crypto_box_keypair()
    return DHKeypair(public_key=pk, private_key=sk)


def _dh(private_key: bytes, peer_public_key: bytes) -> bytes:
    """X25519 Diffie-Hellman. 32-byte shared secret."""
    return bindings.crypto_scalarmult(private_key, peer_public_key)


def _serialize_header(header: RatchetHeader) -> bytes:
    """Serialize a RatchetHeader to bytes for signing.

    Mirrors OC's serializeHeader (ratchet.ts:91-99) byte-for-byte:
        JSON.stringify({dh: <lowercase-hex-64>, pcl: <int>, n: <int>})

    Two implementation details to match OC's wire format:
    - Field order: dh, pcl, n (JSON.stringify follows insertion order
      for object literals).
    - Compact encoding: no whitespace separators, matching JS's default
      JSON.stringify output.
    - dh is lowercase hex (libsodium's to_hex default).
    """
    payload = {
        "dh": header.dh_public_key.hex(),
        "pcl": header.previous_chain_length,
        "n": header.message_number,
    }
    return json.dumps(payload, separators=(",", ":")).encode("utf-8")


def _sign_header(keypair: SigningKeypair, header: RatchetHeader) -> bytes:
    """Ed25519 signature over the serialized header.

    OC's signHeader takes (header, identityPrivateKey). We take a
    SigningKeypair for type safety; the resulting signature is
    byte-identical for the same Ed25519 seed.
    """
    sk = nacl_signing.SigningKey(keypair.private_key)
    serialized = _serialize_header(header)
    return sk.sign(serialized).signature


def _verify_header_signature(
    public_key: bytes, header: RatchetHeader, signature: bytes
) -> bool:
    """Verify Ed25519 signature on a serialized header. Returns True/False (no raise)."""
    try:
        vk = nacl_signing.VerifyKey(public_key)
        vk.verify(_serialize_header(header), signature)
        return True
    except (nacl_exc.BadSignatureError, ValueError):
        return False


# --- Ratchet state container ---

@dataclass
class _RatchetState:
    """Internal state container. Wrapped by the DoubleRatchet class.

    Mirrors OC's RatchetState interface (packages/crypto/src/ratchet.ts:38-48).
    """
    root_key: bytes
    sending_chain: Optional[ChainState]
    receiving_chain: Optional[ChainState]
    dh_sending_keypair: DHKeypair
    dh_receiving_public_key: Optional[bytes]
    identity_keypair: SigningKeypair
    peer_identity_public_key: Optional[bytes]
    previous_sending_chain_length: int
    skipped_keys: list[SkippedKey] = field(default_factory=list)


# --- DoubleRatchet ---

class DoubleRatchet:
    """Signal-style Double Ratchet for 1:1 forward-secret messaging.

    Mirrors OC's DoubleRatchet class (packages/crypto/src/ratchet.ts:122).
    The DH ratchet step is performed lazily inside encrypt() and decrypt() —
    init_initiator and init_receiver only set up state from the X3DH-derived
    shared_secret.

    Use as:
        # Initiator (knows shared_secret from X3DH bootstrap)
        rt = DoubleRatchet.init_initiator(shared_secret, my_identity, peer_identity_pub)
        msg = rt.encrypt(b"hello")  # WS-20.3

        # Receiver (knows shared_secret from X3DH bootstrap)
        rt = DoubleRatchet.init_receiver(shared_secret, my_identity, peer_identity_pub)
        plaintext = rt.decrypt(msg)  # WS-20.4
    """

    def __init__(self, state: _RatchetState):
        self._state = state
        # Telemetry hooks (no-op default; Phase 6 wires them to dashboards)
        self.on_encrypt: Optional[Callable[[RatchetTelemetryEvent], None]] = None
        self.on_decrypt: Optional[Callable[[RatchetTelemetryEvent], None]] = None

    # --- Initialization ---

    @classmethod
    def init_initiator(
        cls,
        shared_secret: bytes,
        identity_keypair: SigningKeypair,
        peer_identity_public_key: Optional[bytes] = None,
    ) -> "DoubleRatchet":
        """Initiator-side init.

        Mirrors OC's initSender (ratchet.ts:129-150). The shared secret seeds
        BOTH the root key AND the sending chain key; receiving chain is None
        until the first inbound message. The DH ratchet step happens lazily
        in encrypt() the first time we send.

        Note: peer_identity_public_key is optional. When None, header-signature
        verification is skipped on inbound messages (matches OC behavior).
        """
        dh_keypair = _generate_dh_keypair()
        state = _RatchetState(
            root_key=shared_secret,
            sending_chain=ChainState(chain_key=shared_secret, message_number=0),
            receiving_chain=None,
            dh_sending_keypair=dh_keypair,
            dh_receiving_public_key=None,
            identity_keypair=identity_keypair,
            peer_identity_public_key=peer_identity_public_key,
            previous_sending_chain_length=0,
        )
        return cls(state)

    @classmethod
    def init_receiver(
        cls,
        shared_secret: bytes,
        identity_keypair: SigningKeypair,
        peer_identity_public_key: Optional[bytes] = None,
    ) -> "DoubleRatchet":
        """Receiver-side init.

        Mirrors OC's initReceiver (ratchet.ts:152-173). The shared secret seeds
        BOTH the root key AND the receiving chain key; sending chain is None
        until the receiver sends its first message (which triggers the DH
        ratchet step in encrypt()).
        """
        dh_keypair = _generate_dh_keypair()
        state = _RatchetState(
            root_key=shared_secret,
            sending_chain=None,
            receiving_chain=ChainState(chain_key=shared_secret, message_number=0),
            dh_sending_keypair=dh_keypair,
            dh_receiving_public_key=None,
            identity_keypair=identity_keypair,
            peer_identity_public_key=peer_identity_public_key,
            previous_sending_chain_length=0,
        )
        return cls(state)

    # --- Serialization ---

    def serialize(self) -> str:
        """Serialize the full ratchet state to a JSON string for disk persistence.

        Mirrors OC's DoubleRatchet.serialize (ratchet.ts:572-609) byte-for-byte:
        - Bytes are HEX-encoded (lowercase, libsodium's `to_hex` default), NOT
          base64. Hex is required for wire-format interop with the OC plugin.
        - Field order matches OC's object literal: version, rootKey, sendingChain,
          receivingChain, dhSendingKeypair, dhReceivingPublicKey, identityKeypair,
          peerIdentityPublicKey, previousSendingChainLength, skippedKeys.
        - Skipped key entries: dhPub (already hex), n, messageKey, headerKey
          (only present when set — OC uses spread-conditional).
        - JSON is compact (no whitespace) to match JS's default JSON.stringify.
        """
        s = self._state
        sending_chain_obj: Optional[dict[str, Any]] = (
            {
                "chainKey": s.sending_chain.chain_key.hex(),
                "messageNumber": s.sending_chain.message_number,
            }
            if s.sending_chain
            else None
        )
        receiving_chain_obj: Optional[dict[str, Any]] = (
            {
                "chainKey": s.receiving_chain.chain_key.hex(),
                "messageNumber": s.receiving_chain.message_number,
            }
            if s.receiving_chain
            else None
        )
        skipped_keys_list: list[dict[str, Any]] = []
        for sk in s.skipped_keys:
            entry: dict[str, Any] = {
                "dhPub": sk.dh_pub_hex,
                "n": sk.n,
                "messageKey": sk.message_key.hex(),
            }
            if sk.header_key is not None:
                entry["headerKey"] = sk.header_key.hex()
            skipped_keys_list.append(entry)

        data: dict[str, Any] = {
            "version": 1,
            "rootKey": s.root_key.hex(),
            "sendingChain": sending_chain_obj,
            "receivingChain": receiving_chain_obj,
            "dhSendingKeypair": {
                "publicKey": s.dh_sending_keypair.public_key.hex(),
                "privateKey": s.dh_sending_keypair.private_key.hex(),
            },
            "dhReceivingPublicKey": (
                s.dh_receiving_public_key.hex()
                if s.dh_receiving_public_key is not None
                else None
            ),
            "identityKeypair": {
                "publicKey": s.identity_keypair.public_key.hex(),
                "privateKey": s.identity_keypair.private_key.hex(),
            },
            "peerIdentityPublicKey": (
                s.peer_identity_public_key.hex()
                if s.peer_identity_public_key is not None
                else None
            ),
            "previousSendingChainLength": s.previous_sending_chain_length,
            "skippedKeys": skipped_keys_list,
        }
        return json.dumps(data, separators=(",", ":"))

    @classmethod
    def deserialize(cls, serialized: str) -> "DoubleRatchet":
        """Load a previously-serialized ratchet from JSON.

        Mirrors OC's DoubleRatchet.deserialize (ratchet.ts:611-714):
        - Raises ValueError on malformed JSON or version mismatch.
        - version field is optional (legacy state without version is accepted),
          but if present must equal 1.
        - rootKey, dhSendingKeypair, identityKeypair are required; missing
          fields raise ValueError.
        - All hex inputs decoded with bytes.fromhex; corrupt hex raises ValueError.
        """
        try:
            data = json.loads(serialized)
        except json.JSONDecodeError as e:
            raise ValueError(f"Ratchet state: corrupt JSON: {e}") from e

        if not isinstance(data, dict):
            raise ValueError("Ratchet state: top-level must be a JSON object")

        # Version gate (matches OC: optional, but if present must be 1)
        version = data.get("version")
        if version is not None and version != 1:
            raise ValueError(f"Ratchet state version {version!r} not supported")

        # Required field validation (matches OC's explicit checks)
        root_key_hex = data.get("rootKey")
        if not isinstance(root_key_hex, str):
            raise ValueError("Ratchet state: missing required field rootKey")
        dh_send = data.get("dhSendingKeypair")
        if (
            not isinstance(dh_send, dict)
            or not isinstance(dh_send.get("publicKey"), str)
            or not isinstance(dh_send.get("privateKey"), str)
        ):
            raise ValueError("Ratchet state: missing required field dhSendingKeypair")
        id_kp = data.get("identityKeypair")
        if (
            not isinstance(id_kp, dict)
            or not isinstance(id_kp.get("publicKey"), str)
            or not isinstance(id_kp.get("privateKey"), str)
        ):
            raise ValueError("Ratchet state: missing required field identityKeypair")

        try:
            sending_chain_data = data.get("sendingChain")
            sending_chain: Optional[ChainState] = (
                ChainState(
                    chain_key=bytes.fromhex(sending_chain_data["chainKey"]),
                    message_number=int(sending_chain_data["messageNumber"]),
                )
                if sending_chain_data
                else None
            )
            receiving_chain_data = data.get("receivingChain")
            receiving_chain: Optional[ChainState] = (
                ChainState(
                    chain_key=bytes.fromhex(receiving_chain_data["chainKey"]),
                    message_number=int(receiving_chain_data["messageNumber"]),
                )
                if receiving_chain_data
                else None
            )
            dh_recv_pub_hex = data.get("dhReceivingPublicKey")
            peer_id_pub_hex = data.get("peerIdentityPublicKey")
            skipped_keys_raw = data.get("skippedKeys", []) or []

            skipped_keys: list[SkippedKey] = []
            for sk in skipped_keys_raw:
                skipped_keys.append(
                    SkippedKey(
                        dh_pub_hex=sk["dhPub"],
                        n=int(sk["n"]),
                        message_key=bytes.fromhex(sk["messageKey"]),
                        header_key=(
                            bytes.fromhex(sk["headerKey"])
                            if sk.get("headerKey") is not None
                            else None
                        ),
                    )
                )

            state = _RatchetState(
                root_key=bytes.fromhex(root_key_hex),
                sending_chain=sending_chain,
                receiving_chain=receiving_chain,
                dh_sending_keypair=DHKeypair(
                    public_key=bytes.fromhex(dh_send["publicKey"]),
                    private_key=bytes.fromhex(dh_send["privateKey"]),
                ),
                dh_receiving_public_key=(
                    bytes.fromhex(dh_recv_pub_hex)
                    if isinstance(dh_recv_pub_hex, str)
                    else None
                ),
                identity_keypair=SigningKeypair(
                    public_key=bytes.fromhex(id_kp["publicKey"]),
                    private_key=bytes.fromhex(id_kp["privateKey"]),
                ),
                peer_identity_public_key=(
                    bytes.fromhex(peer_id_pub_hex)
                    if isinstance(peer_id_pub_hex, str)
                    else None
                ),
                previous_sending_chain_length=int(
                    data.get("previousSendingChainLength", 0)
                ),
                skipped_keys=skipped_keys,
            )
        except ValueError:
            raise
        except (KeyError, TypeError) as err:
            raise ValueError(f"Ratchet state: corrupt structure — {err}") from err

        return cls(state)

    # --- DH ratchet (sending side) ---

    def _dh_ratchet_send(self) -> None:
        """Bootstrap or advance the sending chain via DH ratchet step.

        Mirrors OC's dhRatchetSend (ratchet.ts:435-461). Called lazily from
        encrypt() when sending_chain is None.

        Two cases:
        - No dh_receiving_public_key yet: initial sending chain seeded from
          root_key (ratchet.ts:436-443). No DH keypair regeneration.
        - dh_receiving_public_key set: full DH ratchet step — generate new
          sending DH keypair, derive new (root_key, sending_chain) from
          DH(my_dh_priv, peer_dh_pub) (ratchet.ts:445-460).
        """
        if self._state.dh_receiving_public_key is None:
            self._state.sending_chain = ChainState(
                chain_key=self._state.root_key,
                message_number=0,
            )
            return

        self._state.previous_sending_chain_length = (
            self._state.sending_chain.message_number
            if self._state.sending_chain is not None
            else 0
        )
        new_dh = _generate_dh_keypair()
        self._state.dh_sending_keypair = new_dh
        dh_out = _dh(new_dh.private_key, self._state.dh_receiving_public_key)
        new_root, new_chain = _kdf_root_key(self._state.root_key, dh_out)
        self._state.root_key = new_root
        self._state.sending_chain = ChainState(chain_key=new_chain, message_number=0)

    # --- Encryption (V1 plaintext-header default; V2 header-encryption opt-in) ---

    def encrypt(
        self, plaintext: bytes, header_encryption: bool = False
    ) -> EncryptedMessage:
        """Encrypt a plaintext message and advance the sending chain.

        V1 path (default) — header travels in cleartext, used as AD for
        XChaCha20-Poly1305. Mirrors OC's encrypt() at ratchet.ts:175-252.

        V2 path (header_encryption=True) — header is encrypted with a separate
        per-message header_key derived alongside message_key from the chain key.
        The encrypted-header bytes become the AD for the main ciphertext, binding
        them together. Mirrors OC's V2 branch at ratchet.ts:201-235:

        - encrypted_header = xchacha20(serialize_header(header), header_key,
          header_nonce, ad=None) — NO AD on header encryption.
        - ciphertext = xchacha20(plaintext, message_key, nonce, ad=encrypted_header).
        - The cleartext `header` field is STILL present on the wire; encrypted_header
          + header_signature provide both confidentiality (of header contents) and
          integrity binding to the main ciphertext.
        """
        # Lazy DH ratchet step (ratchet.ts:176-179)
        if self._state.sending_chain is None:
            self._dh_ratchet_send()

        chain = self._state.sending_chain
        if chain is None:
            # _dh_ratchet_send always populates sending_chain — this is a
            # defensive guard for type narrowing / future refactors.
            raise RuntimeError(
                "DoubleRatchet.encrypt: sending chain unset after DH ratchet step"
            )

        # KDF advance (ratchet.ts:182). header_key consumed in V2 path; unused
        # in V1 (still derived to keep KDF state byte-identical with OC).
        next_chain, message_key, header_key = _kdf_chain_key(chain.chain_key)

        # Build header (ratchet.ts:184-188)
        header = RatchetHeader(
            dh_public_key=self._state.dh_sending_keypair.public_key,
            previous_chain_length=self._state.previous_sending_chain_length,
            message_number=chain.message_number,
        )

        # Sign header (ratchet.ts:190-193). Signature is over the cleartext
        # header bytes regardless of envelope version.
        signature = _sign_header(self._state.identity_keypair, header)

        # Random 24-byte XChaCha20-Poly1305 nonce (ratchet.ts:195-197)
        nonce = bindings.randombytes(24)

        envelope_version: Optional[str]
        encrypted_header: Optional[bytes]
        header_nonce: Optional[bytes]

        if header_encryption:
            # V2 (ratchet.ts:201-235)
            header_bytes = _serialize_header(header)
            header_nonce = bindings.randombytes(24)
            # NO AD on header encryption (OC passes null at ratchet.ts:209-210).
            encrypted_header = xchacha20_encrypt(
                header_bytes, header_key, header_nonce
            )
            # Use encrypted_header as AD for the main ciphertext (ratchet.ts:216-222).
            ciphertext = xchacha20_encrypt(
                plaintext, message_key, nonce, ad=encrypted_header
            )
            envelope_version = ENVELOPE_V2
        else:
            # V1: serialized header is AD (ratchet.ts:238-246)
            ad = _serialize_header(header)
            ciphertext = xchacha20_encrypt(plaintext, message_key, nonce, ad=ad)
            envelope_version = None
            encrypted_header = None
            header_nonce = None

        # Mutate chain state in place (ratchet.ts:224-225 / 248-249).
        chain.chain_key = next_chain
        chain.message_number += 1

        # Telemetry hook — Phase 6 wires this to dashboards.
        if self.on_encrypt is not None:
            event: RatchetTelemetryEvent = {
                "message_number": header.message_number,
                "ciphertext_size": len(ciphertext),
                "envelope_version": envelope_version,
            }
            self.on_encrypt(event)

        return EncryptedMessage(
            header=header,
            header_signature=signature,
            ciphertext=ciphertext,
            nonce=nonce,
            envelope_version=envelope_version,
            encrypted_header=encrypted_header,
            header_nonce=header_nonce,
        )

    # --- Decryption (V1, plaintext header) ---

    def _find_skipped_key(self, dh_pub: bytes, n: int) -> Optional[SkippedKey]:
        """Look up a skipped message key by (dh public key, message number).

        Mirrors OC's trySkippedKeys lookup at ratchet.ts:500-508. O(n) linear
        scan over skipped_keys; n is bounded by MAX_SKIP=1000 so this is fine.
        """
        dh_pub_hex = dh_pub.hex()
        for sk in self._state.skipped_keys:
            if sk.dh_pub_hex == dh_pub_hex and sk.n == n:
                return sk
        return None

    def _skip_message_keys(
        self,
        chain: ChainState,
        until_n: int,
        dh_public_key: bytes,
        store_header_key: bool = False,
    ) -> None:
        """Advance a chain forward, stashing message keys for out-of-order delivery.

        Mirrors OC's skipMessages (ratchet.ts:463-498). Important: dh_public_key
        is a PARAMETER (not read from state) because during a DH ratchet step,
        the OLD chain's skipped keys must be tagged with the OLD DH public key
        being replaced — not the new one.

        Raises:
            ValueError: when the requested skip exceeds MAX_SKIP entries.
        """
        if until_n - chain.message_number > MAX_SKIP:
            raise ValueError(
                f"DoubleRatchet: too many skipped messages "
                f"(would skip {until_n - chain.message_number}, MAX_SKIP={MAX_SKIP})"
            )

        dh_pub_hex = dh_public_key.hex()
        while chain.message_number < until_n:
            next_chain, message_key, header_key = _kdf_chain_key(chain.chain_key)
            sk = SkippedKey(
                dh_pub_hex=dh_pub_hex,
                n=chain.message_number,
                message_key=message_key,
                header_key=header_key if store_header_key else None,
            )
            self._state.skipped_keys.append(sk)
            chain.chain_key = next_chain
            chain.message_number += 1

        # FIFO trim: discard oldest entries when over MAX_SKIP total
        # (OC ratchet.ts:491-497; Python has no sodium.memzero, parity-acceptable
        # to just drop references — GC will collect).
        while len(self._state.skipped_keys) > MAX_SKIP:
            self._state.skipped_keys.pop(0)

    def _dh_ratchet_receive(self, peer_dh_public: bytes) -> None:
        """Perform a DH ratchet step on the receiving side.

        Mirrors OC's dhRatchetReceive (ratchet.ts:402-433). Performs TWO DH
        operations and TWO root advances in a specific order:

        1. Save previous_sending_chain_length, store new peer DH public key.
        2. DH(my OLD sending priv, peer DH pub) → advance root + receiving chain.
        3. Generate NEW sending DH keypair.
        4. DH(my NEW sending priv, peer DH pub) → advance root + sending chain.
        """
        self._state.previous_sending_chain_length = (
            self._state.sending_chain.message_number
            if self._state.sending_chain is not None
            else 0
        )
        self._state.dh_receiving_public_key = peer_dh_public

        # First DH + root advance: derive new receiving chain
        dh_in = _dh(self._state.dh_sending_keypair.private_key, peer_dh_public)
        new_root_a, new_recv_chain = _kdf_root_key(self._state.root_key, dh_in)
        self._state.root_key = new_root_a
        self._state.receiving_chain = ChainState(
            chain_key=new_recv_chain, message_number=0
        )

        # Second DH + root advance: rotate sending DH keypair, derive new sending chain
        new_dh = _generate_dh_keypair()
        self._state.dh_sending_keypair = new_dh
        dh_out = _dh(new_dh.private_key, peer_dh_public)
        new_root_b, new_send_chain = _kdf_root_key(self._state.root_key, dh_out)
        self._state.root_key = new_root_b
        self._state.sending_chain = ChainState(
            chain_key=new_send_chain, message_number=0
        )

    def _fire_decrypt_hook(self, message: EncryptedMessage) -> None:
        """Fire the on_decrypt telemetry callback (Hermes-only — no OC analog).

        Called from each successful decrypt path: skipped-keys, case-B shortcut,
        and the late path. Phase 6 wires the callback to dashboards.
        """
        if self.on_decrypt is not None:
            event: RatchetTelemetryEvent = {
                "message_number": message.header.message_number,
                "ciphertext_size": len(message.ciphertext),
                "envelope_version": message.envelope_version,
            }
            self.on_decrypt(event)

    def decrypt(self, message: EncryptedMessage) -> bytes:
        """Decrypt a Double Ratchet message and advance receiving state.

        Mirrors OC's decrypt() at ratchet.ts:254-400. Handles both V1 (cleartext
        header used as AD) and V2 (encrypted header; encrypted_header bytes used
        as AD for main ciphertext) envelope formats transparently.

        V2 detection (ratchet.ts:255-258): envelope_version == "2.0.0" AND both
        encrypted_header and header_nonce are present. The cleartext `header`
        field is still on the wire in V2 and still drives branch logic; V2 only
        changes the AD source and adds a header-decryption integrity check.

        Algorithm (V2-aware):
        1. Try skipped-keys cache first — out-of-order delivery short circuits.
           For V2 entries with skipped.header_key, decrypt encrypted_header with
           that key (no AD) and use encrypted_header as AD for the main
           ciphertext (ratchet.ts:521-548).
        2. Branch on (current_dh_hex, receiving_chain) state:
           a. None / set: receiver-mode first inbound. Just store sender's DH key.
           b. None / None: initiator-mode first inbound. If message_number==0,
              attempt a rootKey-derived chain decrypt; for V2, attempt header
              decrypt with rootKey-derived header_key and use encrypted_header
              as AD on success. Fall through to full DH ratchet on failure.
           c. header_dh != current_dh: peer rotated DH keypair. Skip old chain
              up to header.previous_chain_length, then DH ratchet receive.
        3. Skip ahead to message_number in the (possibly new) receiving chain.
        4. Derive (message_key, header_key) and advance the chain in place.
        5. Verify header signature using peer_identity_public_key (skipped when
           peer_identity_public_key is None — matches OC ratchet.ts:349).
        6. Late path V2 (ratchet.ts:355-382): decrypt encrypted_header with
           header_key — RAISE on failure (committed; cannot fall through).
           Use encrypted_header as AD. V1: use serialize_header(header) as AD.
        7. Fire telemetry hook, return plaintext.
        """
        # V2 dispatch flag (ratchet.ts:255-258).
        is_v2 = (
            message.envelope_version == ENVELOPE_V2
            and message.encrypted_header is not None
            and message.header_nonce is not None
        )

        # 1. Try skipped-keys cache first (ratchet.ts:500-569).
        skipped = self._find_skipped_key(
            message.header.dh_public_key, message.header.message_number
        )
        if skipped is not None:
            # Remove skipped key BEFORE attempting decrypt, matching OC
            # ratchet.ts:511 (splice happens before the try block). A
            # corrupted-but-cached message therefore burns its cache slot —
            # by design; OC's `finally` block at ratchet.ts:567-569 zeroizes
            # the key, our reference removal is the closest Python analog.
            self._state.skipped_keys.remove(skipped)
            if (
                is_v2
                and skipped.header_key is not None
                and message.encrypted_header is not None
                and message.header_nonce is not None
            ):
                # V2 skipped-keys path (ratchet.ts:521-548).
                # Header decrypt: NO AD; raise on failure.
                try:
                    xchacha20_decrypt(
                        message.encrypted_header,
                        skipped.header_key,
                        message.header_nonce,
                    )
                except Exception as e:
                    raise ValueError(
                        f"DoubleRatchet: V2 header decryption failed with skipped key: {e}"
                    ) from e
                # Main decrypt: encrypted_header is AD.
                try:
                    plaintext = xchacha20_decrypt(
                        message.ciphertext,
                        skipped.message_key,
                        message.nonce,
                        ad=message.encrypted_header,
                    )
                except Exception as e:
                    raise ValueError(
                        f"DoubleRatchet: V2 decryption failed with skipped key: {e}"
                    ) from e
            else:
                # V1 skipped-keys path (ratchet.ts:551-566).
                ad = _serialize_header(message.header)
                try:
                    plaintext = xchacha20_decrypt(
                        message.ciphertext, skipped.message_key, message.nonce, ad=ad
                    )
                except Exception as e:
                    raise ValueError(
                        f"DoubleRatchet: decryption failed with skipped key: {e}"
                    ) from e
            self._fire_decrypt_hook(message)
            return plaintext

        # 2. Compute DH-key state (ratchet.ts:266-269)
        header_dh_hex = message.header.dh_public_key.hex()
        current_dh_hex = (
            self._state.dh_receiving_public_key.hex()
            if self._state.dh_receiving_public_key is not None
            else None
        )

        # 3. Branch on first-inbound vs DH-changed cases (ratchet.ts:271-333)
        if current_dh_hex is None and self._state.receiving_chain is not None:
            # Case (a): receiver-mode first inbound. The receiving chain was
            # seeded from shared_secret in init_receiver, so just store the
            # sender's DH key for future ratchet steps (ratchet.ts:271-275).
            self._state.dh_receiving_public_key = message.header.dh_public_key
        elif current_dh_hex is None and self._state.receiving_chain is None:
            # Case (b): initiator-mode first inbound. Try a rootKey-derived
            # chain decrypt first; fall through to a full DH ratchet step
            # only on failure (ratchet.ts:276-317).
            if message.header.message_number == 0:
                next_chain, test_key, test_header_key = _kdf_chain_key(
                    self._state.root_key
                )
                # V2 (ratchet.ts:285-294): try header decrypt with
                # test_header_key; on failure, fall through to DH ratchet
                # (matches V1 fall-through). On success, AD = encrypted_header.
                # V1: AD = serialize_header(header).
                case_b_ad: Optional[bytes]
                proceed = True
                if is_v2:
                    assert message.encrypted_header is not None
                    assert message.header_nonce is not None
                    try:
                        xchacha20_decrypt(
                            message.encrypted_header,
                            test_header_key,
                            message.header_nonce,
                        )
                    except Exception:
                        # V2 header didn't decrypt — fall through to DH ratchet
                        # (parallel to OC's outer catch at ratchet.ts:314-316).
                        proceed = False
                        case_b_ad = None
                    else:
                        case_b_ad = message.encrypted_header
                else:
                    case_b_ad = _serialize_header(message.header)

                if proceed:
                    assert case_b_ad is not None
                    try:
                        plaintext = xchacha20_decrypt(
                            message.ciphertext,
                            test_key,
                            message.nonce,
                            ad=case_b_ad,
                        )
                    except Exception:
                        # rootKey chain didn't match — fall through to DH ratchet
                        # (matches OC's bare catch at ratchet.ts:314-316;
                        # signature verification deliberately skipped here per OC).
                        pass
                    else:
                        # rootKey-derived key worked — commit state and return
                        # (ratchet.ts:307-313). NOTE: OC does NOT verify the
                        # header signature in this branch; signature verification
                        # only runs on the late-verify path at ratchet.ts:348-353.
                        self._state.dh_receiving_public_key = (
                            message.header.dh_public_key
                        )
                        self._state.receiving_chain = ChainState(
                            chain_key=next_chain, message_number=1
                        )
                        self._fire_decrypt_hook(message)
                        return plaintext
            # Fall through (rootKey decrypt failed or messageNumber > 0):
            # full DH ratchet receive (ratchet.ts:318-319).
            self._dh_ratchet_receive(message.header.dh_public_key)
        elif header_dh_hex != current_dh_hex:
            # Case (c): peer rotated DH keypair (direction change). Skip the
            # old chain up to header.previous_chain_length, then DH ratchet
            # receive (ratchet.ts:320-333). Pass is_v2 so old-chain skipped
            # entries cache header_keys for any later out-of-order arrivals.
            if (
                self._state.receiving_chain is not None
                and self._state.dh_receiving_public_key is not None
            ):
                self._skip_message_keys(
                    self._state.receiving_chain,
                    message.header.previous_chain_length,
                    self._state.dh_receiving_public_key,
                    store_header_key=is_v2,
                )
            self._dh_ratchet_receive(message.header.dh_public_key)

        # 4. Skip ahead to message_number in the current receiving chain
        # (ratchet.ts:336-341). dh_public_key parameter is the message's
        # DH public key — whether it's the existing receiving DH (in-chain
        # delivery) or the new one (post-DH-ratchet). Pass is_v2 so cached
        # skipped entries can decrypt encrypted_header on out-of-order arrival.
        if self._state.receiving_chain is None:
            # Defensive guard: case (b) fall-through always populates
            # receiving_chain via _dh_ratchet_receive. Case (a) leaves
            # the seeded receiving_chain in place. Other paths populate.
            raise RuntimeError(
                "DoubleRatchet.decrypt: receiving chain unset after branch dispatch"
            )
        self._skip_message_keys(
            self._state.receiving_chain,
            message.header.message_number,
            message.header.dh_public_key,
            store_header_key=is_v2,
        )

        # 5. Derive message key + header key, advance chain in place
        # (ratchet.ts:343-346). header_key is consumed in V2 late path below;
        # always derived to keep KDF state byte-identical with OC.
        chain = self._state.receiving_chain
        next_chain, message_key, header_key = _kdf_chain_key(chain.chain_key)
        chain.chain_key = next_chain
        chain.message_number += 1

        # 6. Verify header signature LATE (ratchet.ts:348-353). Skipped when
        # peer_identity_public_key is None (matches OC).
        # Late verification: signature is verified AFTER chain advance. This matches
        # OC ratchet.ts:348-353. Moving verification earlier would break recorded-vector
        # parity in WS-24 (state progression must match OC byte-for-byte). A failing
        # signature consumes a chain slot — by design.
        if self._state.peer_identity_public_key is not None:
            if not _verify_header_signature(
                self._state.peer_identity_public_key,
                message.header,
                message.header_signature,
            ):
                raise ValueError(
                    "DoubleRatchet: header signature verification failed"
                )

        # 7. Late path: V2 vs V1 (ratchet.ts:355-399).
        if is_v2:
            assert message.encrypted_header is not None
            assert message.header_nonce is not None
            # V2 (ratchet.ts:355-367): header decrypt with derived header_key —
            # raise on failure. Late path is committed (chain already advanced).
            try:
                xchacha20_decrypt(
                    message.encrypted_header, header_key, message.header_nonce
                )
            except Exception as e:
                raise ValueError(
                    f"DoubleRatchet: V2 header decryption failed: {e}"
                ) from e
            # V2 main decrypt with encrypted_header as AD (ratchet.ts:369-381).
            try:
                plaintext = xchacha20_decrypt(
                    message.ciphertext,
                    message_key,
                    message.nonce,
                    ad=message.encrypted_header,
                )
            except Exception as e:
                raise ValueError(
                    f"DoubleRatchet: V2 decryption failed: ciphertext tampered or wrong key: {e}"
                ) from e
        else:
            # V1: serialized header as AD (ratchet.ts:384-399).
            ad = _serialize_header(message.header)
            try:
                plaintext = xchacha20_decrypt(
                    message.ciphertext, message_key, message.nonce, ad=ad
                )
            except Exception as e:
                raise ValueError(
                    f"DoubleRatchet: decryption failed (ciphertext tampered or wrong key): {e}"
                ) from e

        # 8. Fire telemetry hook
        self._fire_decrypt_hook(message)
        return plaintext
