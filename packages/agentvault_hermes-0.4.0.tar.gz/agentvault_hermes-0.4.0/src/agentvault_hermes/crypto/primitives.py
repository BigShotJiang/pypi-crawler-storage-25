"""Shared crypto primitives — XChaCha20-Poly1305, BLAKE2b-256,
Ed25519↔X25519 conversion, HKDF-SHA256.

Stable signatures we control. If the underlying library changes, only
this file needs updating.
"""
from __future__ import annotations

import hashlib
import hmac

from nacl import bindings


def xchacha20_encrypt(
    plaintext: bytes, key: bytes, nonce: bytes, ad: bytes = b""
) -> bytes:
    """XChaCha20-Poly1305 AEAD encryption.

    Args:
        plaintext: data to encrypt.
        key: 32 bytes.
        nonce: 24 bytes (XChaCha20 has a 192-bit nonce).
        ad: associated authenticated data (not encrypted, but bound to ciphertext).

    Returns:
        ciphertext concatenated with 16-byte Poly1305 tag (16 bytes overhead total).
    """
    if len(key) != 32:
        raise ValueError(f"key must be 32 bytes, got {len(key)}")
    if len(nonce) != 24:
        raise ValueError(f"nonce must be 24 bytes, got {len(nonce)}")
    return bindings.crypto_aead_xchacha20poly1305_ietf_encrypt(
        plaintext, ad, nonce, key
    )


def xchacha20_decrypt(
    ciphertext: bytes, key: bytes, nonce: bytes, ad: bytes = b""
) -> bytes:
    """XChaCha20-Poly1305 AEAD decryption.

    Raises:
        nacl.exceptions.CryptoError: on authentication-tag mismatch or any
            decryption failure.
    """
    if len(key) != 32:
        raise ValueError(f"key must be 32 bytes, got {len(key)}")
    if len(nonce) != 24:
        raise ValueError(f"nonce must be 24 bytes, got {len(nonce)}")
    return bindings.crypto_aead_xchacha20poly1305_ietf_decrypt(
        ciphertext, ad, nonce, key
    )


def blake2b_256(data: bytes) -> bytes:
    """32-byte BLAKE2b hash. Used as KDF + fingerprinting."""
    return hashlib.blake2b(data, digest_size=32).digest()


def ed25519_to_x25519_public(pk: bytes) -> bytes:
    """Convert Ed25519 public key (Edwards form) to X25519 public key (Montgomery form)."""
    if len(pk) != 32:
        raise ValueError(f"Ed25519 public key must be 32 bytes, got {len(pk)}")
    return bindings.crypto_sign_ed25519_pk_to_curve25519(pk)


def ed25519_to_x25519_secret(seed: bytes) -> bytes:
    """Convert Ed25519 secret seed (32 bytes) to X25519 secret key.

    PyNaCl's crypto_sign_ed25519_sk_to_curve25519 expects a 64-byte secret key
    (32-byte seed + 32-byte derived public key concatenated), so we derive the
    full secret first.
    """
    if len(seed) != 32:
        raise ValueError(f"Ed25519 seed must be 32 bytes, got {len(seed)}")
    full_sk = bindings.crypto_sign_seed_keypair(seed)[1]
    return bindings.crypto_sign_ed25519_sk_to_curve25519(full_sk)


def hkdf(ikm: bytes, info: bytes, length: int, salt: bytes = b"") -> bytes:
    """HKDF-SHA256 extract+expand (RFC 5869). Used for key derivation in DR + MLS.

    Args:
        ikm: input keying material.
        info: optional context/application-specific info.
        length: number of bytes to output. Must be 1..8160 per RFC 5869 §2.3.
        salt: optional salt; if empty, a 32-byte zero salt is used.

    Raises:
        ValueError: if length is outside the RFC 5869 bounds.
    """
    _max_length = 255 * hashlib.sha256().digest_size  # RFC 5869 §2.3 — 255 * HashLen
    if length < 1 or length > _max_length:
        raise ValueError(
            f"HKDF length must be 1..{_max_length} bytes, got {length}"
        )
    if not salt:
        salt = b"\x00" * 32

    # Extract
    prk = hmac.new(salt, ikm, hashlib.sha256).digest()

    # Expand
    okm = b""
    counter = 1
    block = b""
    while len(okm) < length:
        block = hmac.new(prk, block + info + bytes([counter]), hashlib.sha256).digest()
        okm += block
        counter += 1
    return okm[:length]
