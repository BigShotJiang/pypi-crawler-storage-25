"""X3DH key agreement — initial shared-secret derivation for Double Ratchet
and MLS welcome bootstrap.

Reference: packages/crypto/src/x3dh.ts in this repo (OC's TypeScript impl).
This Python port must produce the same 32-byte shared secret for the same
inputs. Verified by recorded vectors in WS-24.

Per Phase 2 design Q4: when the activate response omits
owner_ephemeral_public_key, the caller passes owner_identity_public_key
as theirEphemeralPublic — same fallback as OC.
"""
from __future__ import annotations

from dataclasses import dataclass

from nacl import bindings

from agentvault_hermes.crypto.primitives import (
    blake2b_256,
    ed25519_to_x25519_public,
    ed25519_to_x25519_secret,
)


@dataclass(frozen=True)
class X3DHParams:
    """Parameters for X3DH key agreement.

    Field naming intentionally mirrors OC's TypeScript X3DHParams interface
    so the port is a one-to-one translation.

    Note on key widths: OC's TypeScript ``X3DHParams.myIdentityPrivate`` is
    libsodium's 64-byte secret key (the ``seed || pk`` layout from
    ``crypto_sign_keypair``). This Python port takes the **32-byte seed
    instead** because PyNaCl's API and Hermes' ``DeviceKeys.signing_secret``
    both store seeds. ``perform_x3dh`` internally expands the seed back
    to the 64-byte form via ``crypto_sign_seed_keypair`` before the
    Ed25519→X25519 conversion, so the resulting X25519 secret — and the
    final shared secret — are byte-identical to OC's output for the same
    underlying keypair. If you have a 64-byte libsodium secret key from
    an OC payload, slice ``[:32]`` to extract the seed before passing it.
    """

    my_identity_private: bytes      # 32-byte Ed25519 seed (NOT the 64-byte libsodium sk; see class docstring)
    my_ephemeral_private: bytes     # 32-byte X25519 secret
    their_identity_public: bytes    # 32-byte Ed25519 public
    their_ephemeral_public: bytes   # 32-byte X25519 public (or their identity if missing)
    is_initiator: bool


def _validate_32(name: str, data: bytes) -> None:
    if len(data) != 32:
        hint = ""
        if name == "my_identity_private" and len(data) == 64:
            hint = (
                " (looks like a 64-byte libsodium secret key — slice [:32] "
                "to extract just the Ed25519 seed)"
            )
        raise ValueError(f"{name} must be 32 bytes, got {len(data)}{hint}")


def perform_x3dh(params: X3DHParams) -> bytes:
    """Compute the X3DH shared secret.

    Mirrors OC's performX3DH:
        DH1 = my_identity_x × their_ephemeral
        DH2 = my_ephemeral   × their_identity_x
        DH3 = my_ephemeral   × their_ephemeral
        secret = BLAKE2b-256(initiator ? DH1||DH2||DH3 : DH2||DH1||DH3)

    Returns:
        32-byte shared secret. Both sides of the conversation derive the
        same secret when each calls with their own private keys + the
        other party's public keys + appropriate is_initiator flag.
    """
    _validate_32("my_identity_private", params.my_identity_private)
    _validate_32("my_ephemeral_private", params.my_ephemeral_private)
    _validate_32("their_identity_public", params.their_identity_public)
    _validate_32("their_ephemeral_public", params.their_ephemeral_public)

    my_identity_x = ed25519_to_x25519_secret(params.my_identity_private)
    their_identity_x = ed25519_to_x25519_public(params.their_identity_public)

    # DH1: my identity × their ephemeral
    dh1 = bindings.crypto_scalarmult(my_identity_x, params.their_ephemeral_public)
    # DH2: my ephemeral × their identity
    dh2 = bindings.crypto_scalarmult(params.my_ephemeral_private, their_identity_x)
    # DH3: my ephemeral × their ephemeral
    dh3 = bindings.crypto_scalarmult(
        params.my_ephemeral_private, params.their_ephemeral_public
    )

    # Concatenation order swapped by role so both sides agree
    if params.is_initiator:
        combined = dh1 + dh2 + dh3
    else:
        combined = dh2 + dh1 + dh3

    return blake2b_256(combined)
