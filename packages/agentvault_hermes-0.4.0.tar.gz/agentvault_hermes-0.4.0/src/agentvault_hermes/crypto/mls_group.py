"""MlsGroupState — Hermes wrapper around mls_rs_uniffi.Group, mirroring OC's MLSGroupManager.

See docs/superpowers/specs/2026-05-08-ws-22-mls-group-state-design.md for the full
design and parity contract. The OC reference is packages/crypto/src/mls-group.ts.

Internal architecture (from §5 of the spec):
  - _DictGroupStateStorage bridges mls_rs's callback-based persistence to
    OC's bytes-in-bytes-out export/import semantics.
  - One mls_rs_uniffi.Client per wrapper instance, built from device_keys.
  - _group: Optional[Group] is None until create_group/join_from_welcome/import_state.
  - _group_id cached because mls_rs_uniffi.Group doesn't expose group_id directly.
  - _signing_identities_by_leaf maps leaf_index -> SigningIdentity to bridge
    the OC-style "remove by leaf index" API to mls_rs's "remove by SigningIdentity"
    API. Populated at create_group (self at leaf 0) and add_members (parsed
    from input KeyPackages, see _extract_kp_signing_identity).
"""
from __future__ import annotations

import os
import struct
import uuid
from dataclasses import dataclass
from typing import Any, Optional, cast

import mls_rs_uniffi as _mls  # type: ignore[import-untyped]

from agentvault_hermes.crypto.ratchet import SigningKeypair


# --- Public types (mirror OC's TypeScript interfaces) ---------------------------

DEFAULT_CIPHERSUITE: _mls.CipherSuite = _mls.CipherSuite.CURVE25519_AES128

# IANA cipher suite IDs from RFC 9420 §17.1 — these are the on-the-wire values
# inside KeyPackage and GroupContext, NOT the Python enum's .value. The
# mls_rs_uniffi 0.1.0 Python enum just uses sequential indices (CURVE25519_AES128
# = 0), which doesn't match the wire format. Map each supported variant by name
# to its RFC-defined ID.
_IANA_CIPHER_SUITE_BY_NAME: dict[str, int] = {
    "CURVE25519_AES128": 0x0001,  # MLS_128_DHKEMX25519_AES128GCM_SHA256_Ed25519
    # Additional variants (not yet exposed by 0.1.0 wheel):
    "P256_AES128": 0x0002,
    "CURVE25519_CHACHA": 0x0003,
    "CURVE448_AES256": 0x0004,
    "P521_AES256": 0x0005,
    "CURVE448_CHACHA": 0x0006,
    "P384_AES256": 0x0007,
}


def _iana_cipher_suite_id(cs: _mls.CipherSuite) -> int:
    """Translate an mls_rs_uniffi.CipherSuite to its RFC 9420 §17.1 IANA ID."""
    iana = _IANA_CIPHER_SUITE_BY_NAME.get(cs.name)
    if iana is None:
        raise ValueError(
            f"Unknown cipher suite {cs.name!r}; please add to "
            f"_IANA_CIPHER_SUITE_BY_NAME mapping (RFC 9420 §17.1)"
        )
    return iana


@dataclass(frozen=True)
class DecryptResult:
    """Mirror of OC's DecryptResult: 2-case (plaintext or handshake)."""
    plaintext: Optional[bytes]
    is_handshake: bool


@dataclass(frozen=True)
class AddMembersResult:
    """Mirror of OC's AddMembersResult."""
    commit: bytes
    welcome: Optional[bytes]


@dataclass(frozen=True)
class RemoveMemberResult:
    """Mirror of OC's RemoveMemberResult."""
    commit: bytes


class MlsGroupNotInitializedError(RuntimeError):
    """Raised when an operation requires init but create_group/join_from_welcome/
    import_state has not been called. Mirrors OC's `Error("MLSGroupManager is not
    initialized...")`."""


class MlsGroupAlreadyInitializedError(RuntimeError):
    """Raised when create_group / join_from_welcome / import_state is called on
    a wrapper that's already initialized. Symmetric counterpart to
    `MlsGroupNotInitializedError`. Construct a fresh instance to start a new
    group / join a different group / import a different state."""


# --- Internal storage bridge -----------------------------------------------------

class _DictGroupStateStorage(_mls.GroupStateStorage):  # type: ignore[misc]
    """In-memory implementation of mls_rs_uniffi's GroupStateStorage protocol.

    Bridges mls_rs's callback-based persistence (`Group.write_to_storage()`
    invokes `write` here) to bytes round-tripping through `export_state` /
    `import_state`.
    """

    def __init__(self) -> None:
        self._state: dict[bytes, bytes] = {}
        self._epochs: dict[tuple[bytes, int], bytes] = {}
        self._max_epoch: dict[bytes, int] = {}

    def state(self, group_id: bytes) -> Optional[bytes]:
        return self._state.get(group_id)

    def epoch(self, group_id: bytes, epoch_id: int) -> Optional[bytes]:
        return self._epochs.get((group_id, epoch_id))

    def max_epoch_id(self, group_id: bytes) -> Optional[int]:
        return self._max_epoch.get(group_id)

    def write(
        self,
        group_id: bytes,
        group_state: bytes,
        epoch_inserts: list[Any],
        epoch_updates: list[Any],
    ) -> None:
        self._state[group_id] = group_state
        for record in list(epoch_inserts) + list(epoch_updates):
            self._epochs[(group_id, record.id)] = record.data
            current = self._max_epoch.get(group_id, -1)
            if record.id > current:
                self._max_epoch[group_id] = record.id


# --- Helpers --------------------------------------------------------------------

def _to_mls_keypair(
    device_keys: SigningKeypair, cipher_suite: _mls.CipherSuite
) -> _mls.SignatureKeypair:
    """Convert a Hermes 32-byte-seed SigningKeypair to mls_rs_uniffi's
    64-byte-secret SignatureKeypair (Ed25519 standard format = seed | public_key)."""
    return _mls.SignatureKeypair(
        cipher_suite=cipher_suite,
        public_key=_mls.SignaturePublicKey(bytes=device_keys.public_key),
        secret_key=_mls.SignatureSecretKey(
            bytes=device_keys.private_key + device_keys.public_key
        ),
    )


def _device_id_to_credential_bytes(device_id: uuid.UUID) -> bytes:
    """Encode device_id as UTF-8 bytes for the MLS basic credential identity field.

    Matches OC's pattern in packages/plugin/src/channel.ts:4551 —
    `new TextEncoder().encode(this._deviceId!)` produces UTF-8 of the UUID
    string (~36 bytes), which is what we mirror here.
    """
    return str(device_id).encode("utf-8")


# --- TLV format constants (see spec §5.4) -------------------------------------

_TLV_VERSION_V1 = 0x01
_TLV_VERSION_V2 = 0x02  # Bug A: adds u64 epoch footer after epoch records.
_TLV_VERSION = _TLV_VERSION_V2  # Current write format.
_HEADER_FIXED_LEN = 1 + 1 + 2  # version + ciphersuite + gid_len


def _parse_epoch_from_mls_wire(wire: bytes) -> int:
    """Parse the epoch field from an MLSCiphertext (PrivateMessage) wire blob.

    Bug A helper. RFC 9420 §6.3 MLSMessage / §6.3.1 PrivateMessage:

        MLSMessage = ProtocolVersion(u16) | WireFormat(u16) | content
        PrivateMessage = group_id<V> | epoch(u64) | content_type(u8) | ...

    Both u16 and u64 are big-endian per TLS presentation language (RFC 8446
    §3). ``<V>`` is a TLS variable-length vector with a length-prefix whose
    own length is encoded in the top 2 bits of the first byte (RFC 9420 §3.2).

    The empirical probe (see Bug A investigation 2026-05-11) confirmed that
    ``self._group.encrypt_application_message(...)`` produces wire bytes
    whose epoch field matches the group's actual current epoch — even for
    joiners whose storage doesn't track it. So parsing the framing header
    from a real encrypt() is a zero-cost way to learn the true epoch.
    """
    cursor = 0
    # ProtocolVersion (u16 BE) + WireFormat (u16 BE) = 4 bytes header.
    if len(wire) < 4:
        raise ValueError("MLS wire blob shorter than MLSMessage header")
    cursor += 4
    # group_id<V> — TLS variable-length vector.
    if cursor >= len(wire):
        raise ValueError("MLS wire blob truncated before group_id varlen")
    first = wire[cursor]
    prefix_kind = (first >> 6) & 0x3
    if prefix_kind == 0:
        gid_len = first & 0x3f
        cursor += 1
    elif prefix_kind == 1:
        if cursor + 2 > len(wire):
            raise ValueError("MLS wire blob truncated in 2-byte varlen")
        gid_len = ((first & 0x3f) << 8) | wire[cursor + 1]
        cursor += 2
    elif prefix_kind == 2:
        if cursor + 4 > len(wire):
            raise ValueError("MLS wire blob truncated in 4-byte varlen")
        gid_len = struct.unpack(
            ">I", bytes([first & 0x3f]) + wire[cursor + 1 : cursor + 4]
        )[0]
        cursor += 4
    else:
        raise ValueError(f"Reserved TLS varlen prefix 0b11 not allowed (byte={first:#x})")
    cursor += gid_len
    if cursor + 8 > len(wire):
        raise ValueError("MLS wire blob truncated before epoch field")
    return cast(int, struct.unpack(">Q", wire[cursor : cursor + 8])[0])


def _pack_tlv(
    storage: "_DictGroupStateStorage",
    group_id: bytes,
    ciphersuite: _mls.CipherSuite,
    *,
    explicit_epoch: int = 0,
) -> bytes:
    """Serialize storage state for a single group_id into TLV bytes.

    Format v1 (legacy, see spec §5.4):
        version=0x01 | ciphersuite (u8) | gid_len (u16 LE) | gid_bytes |
        state_len (u32 LE) | state_bytes |
        n_epochs (u32 LE) |
          (epoch_id (u64 LE) | epoch_len (u32 LE) | epoch_bytes)*

    Format v2 (Bug A fix for action_item #164):
        identical to v1 plus a trailing 8-byte u64 LE field carrying the
        explicit current-epoch counter so it survives export/import. v1
        readers reject v2 blobs at the version-byte check; v2 readers
        accept BOTH versions (v1 falls back to ``explicit_epoch = 0``,
        which callers then re-derive from ``_storage.max_epoch_id`` or
        the next encrypt's wire header).

    The ciphersuite byte is the mls_rs_uniffi.CipherSuite Python enum value
    (sequential index, NOT the RFC 9420 IANA ID). This format is internal to
    the wrapper's persistence layer; both pack and unpack operate on the same
    Python enum.

    Note: a separate cipher-suite domain — the RFC 9420 IANA ID (wire format) —
    is checked when parsing inbound KeyPackages in `_parse_kp_basic_identity`.
    The two checks are intentionally different domains and translate via
    `_iana_cipher_suite_id`; do not unify them.
    """
    state_blob = storage._state.get(group_id)
    if state_blob is None:
        raise ValueError(f"No storage state for group_id {group_id.hex()[:16]}")

    epoch_records = sorted(
        ((eid, blob) for (gid, eid), blob in storage._epochs.items() if gid == group_id),
        key=lambda x: x[0],
    )

    parts: list[bytes] = []
    parts.append(struct.pack("<BBH", _TLV_VERSION, ciphersuite.value, len(group_id)))
    parts.append(group_id)
    parts.append(struct.pack("<I", len(state_blob)))
    parts.append(state_blob)
    parts.append(struct.pack("<I", len(epoch_records)))
    for eid, eblob in epoch_records:
        parts.append(struct.pack("<QI", eid, len(eblob)))
        parts.append(eblob)
    # v2 footer — explicit epoch counter (Bug A fix).
    parts.append(struct.pack("<Q", explicit_epoch))
    return b"".join(parts)


def _unpack_tlv(
    blob: bytes,
) -> tuple[bytes, _mls.CipherSuite, bytes, list[tuple[int, bytes]], int]:
    """Deserialize TLV bytes into (group_id, ciphersuite, state_bytes,
    epoch_records, explicit_epoch).

    Accepts both v1 and v2 blobs (see _pack_tlv docstring for the format
    delta). For v1, ``explicit_epoch`` is returned as 0 — callers should
    fall back to deriving from ``storage.max_epoch_id`` (legacy behavior)
    or refresh from the next encrypt's wire header.

    Raises ValueError on any malformed input.
    """
    if len(blob) < _HEADER_FIXED_LEN:
        raise ValueError(
            f"TLV blob too short ({len(blob)} bytes, minimum {_HEADER_FIXED_LEN})"
        )
    version, cs_value, gid_len = struct.unpack("<BBH", blob[:4])
    if version not in (_TLV_VERSION_V1, _TLV_VERSION_V2):
        raise ValueError(
            f"Unknown TLV version 0x{version:02x} "
            f"(expected 0x{_TLV_VERSION_V1:02x} or 0x{_TLV_VERSION_V2:02x})"
        )
    try:
        ciphersuite = _mls.CipherSuite(cs_value)
    except ValueError:
        raise ValueError(f"Unknown ciphersuite value {cs_value} in TLV header")

    cursor = 4
    if cursor + gid_len > len(blob):
        raise ValueError("TLV blob truncated: gid_bytes field overruns")
    group_id = blob[cursor : cursor + gid_len]
    cursor += gid_len

    if cursor + 4 > len(blob):
        raise ValueError("TLV blob truncated: state_len field missing")
    (state_len,) = struct.unpack("<I", blob[cursor : cursor + 4])
    cursor += 4
    if cursor + state_len > len(blob):
        raise ValueError("TLV blob truncated: state_bytes field overruns")
    state_bytes = blob[cursor : cursor + state_len]
    cursor += state_len

    if cursor + 4 > len(blob):
        raise ValueError("TLV blob truncated: n_epochs field missing")
    (n_epochs,) = struct.unpack("<I", blob[cursor : cursor + 4])
    cursor += 4

    epoch_records: list[tuple[int, bytes]] = []
    for i in range(n_epochs):
        if cursor + 12 > len(blob):
            raise ValueError(f"TLV blob truncated: epoch record {i} header missing")
        epoch_id, epoch_len = struct.unpack("<QI", blob[cursor : cursor + 12])
        cursor += 12
        if cursor + epoch_len > len(blob):
            raise ValueError(f"TLV blob truncated: epoch record {i} bytes overrun")
        epoch_blob = blob[cursor : cursor + epoch_len]
        cursor += epoch_len
        epoch_records.append((epoch_id, epoch_blob))

    explicit_epoch = 0
    if version == _TLV_VERSION_V2:
        # v2 footer: u64 LE explicit epoch counter (Bug A fix).
        if cursor + 8 > len(blob):
            raise ValueError("v2 TLV blob truncated before epoch footer")
        (explicit_epoch,) = struct.unpack("<Q", blob[cursor : cursor + 8])
        cursor += 8

    if cursor != len(blob):
        raise ValueError(
            f"TLV blob has {len(blob) - cursor} trailing bytes after "
            f"{'epoch footer' if version == _TLV_VERSION_V2 else 'last epoch record'}"
        )

    return group_id, ciphersuite, state_bytes, epoch_records, explicit_epoch


# --- Wrapper class --------------------------------------------------------------

class MlsGroupState:
    """Python wrapper around mls_rs_uniffi.Group, mirroring OC's MLSGroupManager.

    Construct, then call create_group / join_from_welcome / import_state to
    initialize. After that the operational methods (encrypt, decrypt,
    add_members, remove_member, export_state) become available.

    **Known limitations**:

    - ``remove_member()`` after a previous ``remove_member()`` (or after
      ``import_state`` followed by ``remove_member()``) may misalign the
      internal leaf-index cache because mls_rs reuses blank leaves per
      RFC 9420 §7.6 and our cache assumes monotonic appends. Concretely,
      after a member is removed at leaf index ``k``, the next ``add_members``
      call may have mls_rs assign the new member to ``k`` (reusing the
      blank slot), but the cache will record them at ``max(keys) + 1``.
      Subsequent ``remove_member(k)`` may then resolve to the wrong
      ``SigningIdentity`` and either raise ``_mls.Error`` or remove an
      unintended member. Tracked under spec §11 future joint upgrade
      WS118 (signing identity resolved from leaf index via mls_rs API).
      If you need this sequence today, recreate the wrapper from a fresh
      ``export_state``/``import_state`` cycle.

    - After ``join_from_welcome`` or ``import_state``, ``_signing_identities_by_leaf``
      is empty until the joiner calls ``add_members`` itself; ``remove_member``
      raises ``IndexError`` until then. Same root cause (no RatchetTree parsing).
    """

    def __init__(
        self,
        device_keys: SigningKeypair,
        device_id: uuid.UUID,
        ciphersuite: _mls.CipherSuite = DEFAULT_CIPHERSUITE,
    ) -> None:
        self._ciphersuite = ciphersuite
        self._device_id = device_id
        self._storage = _DictGroupStateStorage()
        self._keypair = _to_mls_keypair(device_keys, ciphersuite)
        cfg = _mls.client_config_default()
        cfg.group_state_storage = self._storage
        self._client = _mls.Client(
            _device_id_to_credential_bytes(device_id),
            self._keypair,
            cfg,
        )
        self._signing_identities_by_leaf: dict[int, _mls.SigningIdentity] = {}
        self._group: Optional[_mls.Group] = None
        self._group_id: Optional[bytes] = None
        # Bug A fix (action_item #164): explicit epoch counter. mls_rs_uniffi
        # 0.1.x's ``GroupStateStorage.max_epoch_id`` is fundamentally not the
        # "current epoch" — it's the "highest persisted epoch STATE record"
        # which lags by one for creators and is empty for fresh joiners. The
        # wire-format ciphertext header always carries the correct epoch
        # (verified by probe-encrypt tests), but to surface a correct value
        # via the ``epoch`` property without paying a probe-encrypt cost on
        # every read, we track it explicitly on each lifecycle method.
        # ``None`` until create_group / join_from_welcome / import_state runs.
        self._epoch: Optional[int] = None
        # When True, the next encrypt() call will derive the real epoch from
        # the wire framing header (RFC 9420 §6.3 MLSCiphertext) and overwrite
        # ``self._epoch``. Set by join_from_welcome — we can't know the join
        # epoch a-priori (welcomes can target any epoch ≥ 1), so we lazily
        # learn from the first real encrypt rather than burning a probe key.
        self._epoch_needs_wire_refresh: bool = False

    # --- Read-only properties (OC mirror) ---------------------------------------

    @property
    def is_initialized(self) -> bool:
        """True after create_group / join_from_welcome / import_state has been called."""
        return self._group is not None

    @property
    def epoch(self) -> int:
        """Current group epoch. Raises if not initialized.

        Bug A fix (action_item #164): the explicit ``_epoch`` counter is the
        source of truth, not ``_storage.max_epoch_id``. The storage value is
        unreliable in two cases that broke the previous implementation:

        - Creators after ``add_members``: storage still reports the pre-commit
          epoch because ``write_to_storage`` happens BEFORE the self-applied
          commit advances the internal epoch counter.
        - Joiners after ``join_from_welcome``: storage's max_epoch_id is
          ``None`` because no epoch state record is persisted by the join.

        The wire-format ciphertext always carries the correct epoch
        (RFC 9420 §6.3 MLSCiphertext header). For joiners we lazily refresh
        ``_epoch`` from that header on the first encrypt (see
        ``_refresh_epoch_from_wire``) so the value is correct without a
        probe-encrypt round-trip.
        """
        self._require_initialized()
        assert self._epoch is not None
        return self._epoch

    @property
    def group_id(self) -> bytes:
        """Group identifier as bytes. Raises if not initialized."""
        self._require_initialized()
        assert self._group_id is not None
        return self._group_id

    @property
    def ciphersuite_name(self) -> str:
        """Cipher suite name (e.g. 'CURVE25519_AES128')."""
        return cast(str, self._ciphersuite.name)

    # --- Static helpers (OC mirror) --------------------------------------------

    @staticmethod
    def serialize_key_package(kp_message: bytes) -> bytes:
        """Pass-through serializer; KP messages are already wire-format bytes
        in mls_rs_uniffi (Message.to_bytes()). Method exists to mirror OC's
        static MLSGroupManager.serializeKeyPackage."""
        # Validate it's a parseable Message; round-trip to confirm
        msg = _mls.Message.from_bytes(kp_message)
        return cast(bytes, msg.to_bytes())

    @staticmethod
    def deserialize_key_package(bytes_: bytes) -> bytes:
        """Inverse of serialize_key_package."""
        msg = _mls.Message.from_bytes(bytes_)
        return cast(bytes, msg.to_bytes())

    # --- Lifecycle (OC mirror) -------------------------------------------------

    def generate_key_package(self) -> bytes:
        """Generate a fresh KeyPackage for this device. Returns wire bytes."""
        msg = self._client.generate_key_package_message()
        return cast(bytes, msg.to_bytes())

    def create_group(self, group_id: bytes) -> None:
        """Create a new MLS group with this device as the sole member.

        Mirrors OC's MLSGroupManager.createGroup. The KeyPackage bundle that
        OC's API takes is implicit here — the underlying Client carries the
        signing identity, so mls_rs_uniffi.Client.create_group only needs the
        group_id.
        """
        if self._group is not None:
            raise MlsGroupAlreadyInitializedError(
                "MlsGroupState already initialized. "
                "Construct a fresh instance for a new group."
            )
        self._group = self._client.create_group(group_id)
        self._group_id = group_id
        # Seed the leaf->identity cache: creator is at leaf 0
        self._signing_identities_by_leaf = {0: self._client.signing_identity()}
        # Persist initial state immediately so storage reflects the new group.
        self._group.write_to_storage()
        # Bug A fix: explicit epoch tracking. A fresh group is at RFC 9420
        # §8.1's initial epoch 0.
        self._epoch = 0

    def join_from_welcome(self, welcome_bytes: bytes) -> None:
        """Join an existing MLS group via a Welcome message.

        Mirrors OC's MLSGroupManager.joinFromWelcome. KP bundle is implicit
        (Client carries the signing identity).

        NOTE: After joining, _signing_identities_by_leaf is empty — joiners
        cannot reconstruct the full leaf_index → SigningIdentity map without
        parsing the RatchetTree bytes (RFC 9420 §7.1). This is a known
        limitation tracked in the spec; joiners can encrypt/decrypt but
        cannot remove_member until the cache is populated some other way
        (or future joint upgrade #2 lands accepting device_id at the
        remove_member entry point).
        """
        if self._group is not None:
            raise MlsGroupAlreadyInitializedError(
                "MlsGroupState already initialized. "
                "Construct a fresh instance to join a different group."
            )
        welcome_msg = _mls.Message.from_bytes(welcome_bytes)
        join_info = self._client.join_group(None, welcome_msg)
        self._group = join_info.group
        # Persist initial state so storage is populated; we then read the
        # group_id back from storage (mls_rs_uniffi.Group does not expose it
        # directly, and join_info doesn't surface it either).
        self._group.write_to_storage()
        state_keys = list(self._storage._state.keys())
        if len(state_keys) != 1:
            # Should never happen — fail loudly so we catch the case
            raise RuntimeError(
                f"Unexpected storage state after join: expected exactly 1 group_id, "
                f"got {len(state_keys)}: {[k.hex() for k in state_keys]}"
            )
        self._group_id = state_keys[0]
        self._signing_identities_by_leaf = {}
        # Bug A fix: joiners cannot know the welcome's target epoch a-priori
        # (it's encrypted inside group_info). For the §M1 1:1 flow it's always
        # 1, but multi-commit-before-Welcome scenarios can hand us any epoch
        # ≥ 1. Use a placeholder of 1 and mark for refresh from the wire on
        # the next encrypt() — the framing header carries the real value.
        self._epoch = 1
        self._epoch_needs_wire_refresh = True

    # --- Operations (OC mirror) ------------------------------------------------

    def encrypt(self, plaintext: bytes) -> bytes:
        """Encrypt an application message. Mirrors OC's MLSGroupManager.encrypt."""
        self._require_initialized()
        assert self._group is not None
        msg = self._group.encrypt_application_message(plaintext)
        # Persist after every operation so disk state stays consistent with memory
        self._group.write_to_storage()
        wire = cast(bytes, msg.to_bytes())
        # Bug A fix: lazy refresh of ``_epoch`` from the wire-format framing
        # header for joiners whose join epoch was unknown a-priori. Done
        # AFTER the encrypt so we capture the real epoch with no extra mls-rs
        # round-trip — encrypt() always runs at the group's current epoch, so
        # the wire header is the authoritative source.
        if self._epoch_needs_wire_refresh:
            try:
                self._epoch = _parse_epoch_from_mls_wire(wire)
            except (struct.error, IndexError, ValueError):
                # Wire-format drift — keep the placeholder rather than crash.
                # Worst case: envelope epoch stays at the join-time guess
                # (still better than the old behavior of always 0).
                pass
            self._epoch_needs_wire_refresh = False
        return wire

    def decrypt(self, message_bytes: bytes) -> DecryptResult:
        """Decrypt an MLS message. Returns a 2-case result mirroring OC's DecryptResult.

        ApplicationMessage → (plaintext=data, is_handshake=False).
        Commit / Proposal / GroupInfo / KeyPackage / Welcome → (plaintext=None, is_handshake=True).

        The 5-case → 2-case collapse is deliberate per OC parity. Future joint
        upgrades #2 and #4 in the spec (§11) will surface MemberAdded /
        MemberRemoved / EpochAdvanced / "you've been removed" distinctions when
        Phase 6 telemetry needs them.
        """
        self._require_initialized()
        assert self._group is not None
        msg = _mls.Message.from_bytes(message_bytes)
        received = self._group.process_incoming_message(msg)
        self._group.write_to_storage()
        if received.is_application_message():
            data = self._extract_application_data(received)
            return DecryptResult(plaintext=data, is_handshake=False)
        # Bug A fix: only commits advance the epoch. Proposals don't (they
        # accumulate until their commit applies them), and the other handshake
        # types (GroupInfo / KeyPackage / Welcome) don't go through decrypt at
        # all (KeyPackage is handled outside the group, Welcome goes through
        # join_from_welcome, GroupInfo is internal). ``is_commit()`` is the
        # only kind that should bump our counter.
        if received.is_commit() and self._epoch is not None:
            self._epoch += 1
        return DecryptResult(plaintext=None, is_handshake=True)

    def process_commit(self, commit_bytes: bytes) -> None:
        """Process a handshake commit. Thin alias asserting the message is handshake.

        Mirrors OC's MLSGroupManager.processCommit (alias for decrypt that throws
        if given application data).
        """
        result = self.decrypt(commit_bytes)
        if not result.is_handshake:
            raise RuntimeError(
                "Expected a handshake message but got application data"
            )

    def add_members(self, key_packages: list[bytes]) -> AddMembersResult:
        """Add one or more members. Plural per OC's MLSGroupManager.addMembers.

        Self-applies the resulting commit so this device's epoch advances
        along with the new members'. Without the self-apply, subsequent
        encrypt() calls would produce ciphertext at the pre-commit epoch
        that receivers can't decrypt. Matches upstream
        mls-rs-uniffi/tests/simple_scenario_sync.py.

        New members' SigningIdentity objects are added to
        _signing_identities_by_leaf at sequential leaf indices following
        the highest currently-occupied leaf. This matches mls_rs's leaf
        assignment for sequential adds with no removes.
        """
        self._require_initialized()
        assert self._group is not None
        if not key_packages:
            raise ValueError("add_members requires at least one key package")
        kp_msgs = [_mls.Message.from_bytes(kp) for kp in key_packages]
        # Extract identities from the wire bytes so we can populate the cache
        # for later remove_member calls. (mls_rs_uniffi does not expose a
        # SigningIdentity accessor on Message objects in this wheel version,
        # so we parse the KeyPackage TLS structure ourselves and build
        # proxy SigningIdentity objects via fresh Clients.)
        new_identities = [self._extract_kp_signing_identity(kp) for kp in key_packages]
        output = self._group.add_members(kp_msgs)
        # Self-apply so OUR epoch advances too. process_incoming_message of a
        # self-generated commit should be infallible in mls_rs; a raise here
        # indicates a wheel bug, not a recoverable error.
        self._group.process_incoming_message(output.commit_message)
        next_leaf = max(self._signing_identities_by_leaf.keys(), default=-1) + 1
        for i, identity in enumerate(new_identities):
            self._signing_identities_by_leaf[next_leaf + i] = identity
        self._group.write_to_storage()
        # Bug A fix: self-applied commit advances OUR epoch by 1.
        if self._epoch is not None:
            self._epoch += 1
        welcome_bytes = (
            output.welcome_message.to_bytes()
            if output.welcome_message is not None
            else None
        )
        return AddMembersResult(
            commit=output.commit_message.to_bytes(),
            welcome=welcome_bytes,
        )

    def remove_member(self, leaf_index: int) -> RemoveMemberResult:
        """Remove the member at the given leaf index. Singular per OC.

        Forced impedance: mls_rs_uniffi.Group.remove_members takes
        List[SigningIdentity], NOT leaf indices. The wrapper translates via
        the internal _signing_identities_by_leaf cache.

        Self-applies the resulting commit so this device's epoch advances.
        """
        self._require_initialized()
        assert self._group is not None
        if leaf_index not in self._signing_identities_by_leaf:
            raise IndexError(
                f"No member at leaf_index {leaf_index}. "
                f"Known leaves: {sorted(self._signing_identities_by_leaf.keys())}"
            )
        identity = self._signing_identities_by_leaf[leaf_index]
        output = self._group.remove_members([identity])
        # Self-apply so OUR epoch advances too. process_incoming_message of a
        # self-generated commit should be infallible in mls_rs; a raise here
        # indicates a wheel bug, not a recoverable error.
        self._group.process_incoming_message(output.commit_message)
        del self._signing_identities_by_leaf[leaf_index]
        self._group.write_to_storage()
        # Bug A fix: self-applied commit advances OUR epoch by 1.
        if self._epoch is not None:
            self._epoch += 1
        return RemoveMemberResult(commit=output.commit_message.to_bytes())

    # --- Persistence (OC mirror) -----------------------------------------------

    def export_state(self) -> bytes:
        """Serialize current group state to bytes for persistence.

        Mirrors OC's MLSGroupManager.exportState (returns bytes; OC returns a
        structured object with base64 group_state + ciphersuite — same
        information, different envelope; see spec §3 forced impedance).

        Atomicity: if `_pack_tlv` raises (theoretical for v=1; reserved for
        v=2+ codecs that may have failure modes), the storage flush from
        `write_to_storage()` is rolled back so the wrapper's storage is not
        left in a half-flushed state. Mirrors `import_state`'s discipline.
        """
        self._require_initialized()
        assert self._group is not None
        assert self._group_id is not None

        # Snapshot per-group storage entries so a _pack_tlv failure rolls back
        # the write_to_storage() side-effect. Symmetric with import_state.
        group_id = self._group_id
        prev_state = self._storage._state.get(group_id)
        prev_epochs = {
            (gid, eid): blob
            for (gid, eid), blob in self._storage._epochs.items()
            if gid == group_id
        }
        prev_max = self._storage._max_epoch.get(group_id)

        try:
            self._group.write_to_storage()
            return _pack_tlv(
                self._storage,
                group_id,
                self._ciphersuite,
                explicit_epoch=self._epoch if self._epoch is not None else 0,
            )
        except Exception:
            # Restore storage to pre-flush state. Drop any entries
            # write_to_storage() added/updated, then put the snapshot back.
            if prev_state is None:
                self._storage._state.pop(group_id, None)
            else:
                self._storage._state[group_id] = prev_state
            for (gid, eid) in list(self._storage._epochs.keys()):
                if gid == group_id:
                    del self._storage._epochs[(gid, eid)]
            for k, v in prev_epochs.items():
                self._storage._epochs[k] = v
            if prev_max is None:
                self._storage._max_epoch.pop(group_id, None)
            else:
                self._storage._max_epoch[group_id] = prev_max
            raise

    def import_state(self, state: bytes) -> None:
        """Restore group state from bytes produced by export_state.

        Mirrors OC's MLSGroupManager.importState. Raises ValueError on
        malformed input or unknown version byte.

        Limitations:
            After import, ``remove_member()`` will raise IndexError because
            ``_signing_identities_by_leaf`` cannot be reconstructed from storage
            alone (would require RatchetTree parsing per RFC 9420 §7.1, not yet
            implemented). Encrypt and decrypt work normally; this matches the
            same limitation on the joiner-from-welcome path noted in WS-22.4.
        """
        if self._group is not None:
            raise MlsGroupAlreadyInitializedError(
                "MlsGroupState already initialized. "
                "Construct a fresh instance to import into."
            )
        group_id, ciphersuite, state_bytes, epoch_records, explicit_epoch = _unpack_tlv(state)

        # Direct enum equality is intentional: both pack and unpack operate on
        # the Python `_mls.CipherSuite` enum (internal format). This is NOT the
        # same domain as the IANA wire-format check in
        # `_parse_kp_basic_identity`, which translates via `_iana_cipher_suite_id`.
        if ciphersuite != self._ciphersuite:
            raise ValueError(
                f"Imported state's ciphersuite ({ciphersuite}) does not match "
                f"wrapper ciphersuite ({self._ciphersuite}). Construct the "
                f"wrapper with the matching ciphersuite first."
            )

        # Snapshot existing storage entries for this group_id (if any) so we can
        # restore on failure. Without this, a load_group() failure on corrupt
        # state bytes would leave _storage polluted.
        prev_state = self._storage._state.get(group_id)
        prev_epochs = {
            (gid, eid): blob
            for (gid, eid), blob in self._storage._epochs.items()
            if gid == group_id
        }
        prev_max = self._storage._max_epoch.get(group_id)

        # Populate from the unpacked TLV
        self._storage._state[group_id] = state_bytes
        for epoch_id, epoch_blob in epoch_records:
            self._storage._epochs[(group_id, epoch_id)] = epoch_blob
            current = self._storage._max_epoch.get(group_id, -1)
            if epoch_id > current:
                self._storage._max_epoch[group_id] = epoch_id

        try:
            self._group = self._client.load_group(group_id)
        except Exception:
            # Restore storage to pre-import state so debugging isn't muddied
            if prev_state is None:
                self._storage._state.pop(group_id, None)
            else:
                self._storage._state[group_id] = prev_state
            # Drop newly-added epoch entries; restore prior ones
            for (gid, eid) in list(self._storage._epochs.keys()):
                if gid == group_id:
                    del self._storage._epochs[(gid, eid)]
            for k, v in prev_epochs.items():
                self._storage._epochs[k] = v
            if prev_max is None:
                self._storage._max_epoch.pop(group_id, None)
            else:
                self._storage._max_epoch[group_id] = prev_max
            raise

        self._group_id = group_id
        # _signing_identities_by_leaf cannot be reconstructed from storage alone
        # (would require RatchetTree parsing); leave empty for now. Matches the
        # joiner-from-welcome limitation noted in WS-22.4.
        self._signing_identities_by_leaf = {}
        # Bug A fix: restore the explicit epoch counter. For v2 blobs this is
        # carried in the TLV footer. For legacy v1 blobs (explicit_epoch=0)
        # we fall back to ``storage.max_epoch_id`` which is correct for
        # creators (whose state was previously persisted) but defaults to 0
        # for joiners — the next encrypt() will then refresh from the wire.
        if explicit_epoch > 0:
            self._epoch = explicit_epoch
            self._epoch_needs_wire_refresh = False
        else:
            legacy_max = self._storage.max_epoch_id(group_id)
            self._epoch = legacy_max if legacy_max is not None else 0
            # Legacy state imported with epoch=0 may be a joiner — schedule a
            # wire refresh on the next encrypt so the displayed epoch
            # self-heals once the agent sends its first reply.
            self._epoch_needs_wire_refresh = self._epoch == 0

    # --- Internal -------------------------------------------------------------

    def _require_initialized(self) -> None:
        if self._group is None:
            raise MlsGroupNotInitializedError(
                "MlsGroupState is not initialized. "
                "Call create_group, join_from_welcome, or import_state first."
            )

    @staticmethod
    def _extract_application_data(received: "_mls.ReceivedMessage") -> bytes:
        """Pull the bytes payload out of an APPLICATION_MESSAGE ReceivedMessage.

        UniFFI 0.31's Python tagged-union binding for mls_rs_uniffi 0.1.0
        exposes the APPLICATION_MESSAGE variant's fields as instance attributes
        (`sender: SigningIdentity`, `data: bytes`) — confirmed by the upstream
        `simple_scenario_sync.py` test which does `output.data == b'...'`.
        We use attribute access here.
        """
        if not hasattr(received, "data") or not isinstance(received.data, bytes):
            raise RuntimeError(
                f"Expected APPLICATION_MESSAGE ReceivedMessage with .data: bytes, "
                f"got {type(received).__name__}. UniFFI binding may have changed."
            )
        return received.data

    def _extract_kp_signing_identity(self, kp_wire_bytes: bytes) -> "_mls.SigningIdentity":
        """Build a SigningIdentity matching the credential of a KeyPackage.

        mls_rs_uniffi 0.1.0 does not expose a signing_identity accessor on
        Message objects, and the Proposal/ReceivedMessage.KEY_PACKAGE variants
        also do not surface the underlying SigningIdentity. To populate the
        leaf->identity cache (needed by remove_member), this helper:

          1. Parses the KeyPackage TLS wire format (RFC 9420 §10) to extract
             the BasicCredential identity bytes and signature_public_key.
          2. Builds a *throwaway* mls_rs_uniffi.Client with those credentials
             plus a fabricated secret key (never used for signing).
          3. Returns the proxy Client's signing_identity().

        The resulting SigningIdentity matches the in-group identity that
        mls_rs's BasicIdentityProvider stores, because matching is by credential
        bytes only (verified end-to-end in the WS-22.4 spike).

        Assumes:
          - cipher suite = ciphersuite_name (Curve25519_AES128 in this wheel)
          - credential type = BasicCredential (0x0001) — OC's only mode
        """
        identity_bytes, sig_pub_key = self._parse_kp_basic_identity(kp_wire_bytes)
        # Build a throwaway proxy client. The fake secret key is never used
        # for signing; matching is by (identity_bytes, sig_pub_key) only.
        fake_secret = os.urandom(32) + sig_pub_key
        proxy_keypair = _mls.SignatureKeypair(
            cipher_suite=self._ciphersuite,
            public_key=_mls.SignaturePublicKey(bytes=sig_pub_key),
            secret_key=_mls.SignatureSecretKey(bytes=fake_secret),
        )
        proxy_cfg = _mls.client_config_default()
        proxy_cfg.group_state_storage = _DictGroupStateStorage()
        proxy_client = _mls.Client(identity_bytes, proxy_keypair, proxy_cfg)
        return proxy_client.signing_identity()

    def _parse_kp_basic_identity(self, kp_wire_bytes: bytes) -> tuple[bytes, bytes]:
        """Parse a KeyPackage MlsMessage to extract (identity_bytes, signature_pub_key).

        Implements the minimal subset of RFC 9420 §10 (KeyPackage) + §5.3
        (BasicCredential) needed to recover member identity for the cache.

        Validates that the KeyPackage's declared cipher suite matches the
        wrapper's configured `_ciphersuite`. Cross-suite KeyPackage injection
        is rejected with a clear ValueError. The TLS varint-based parser
        itself is cipher-suite-agnostic (varints carry length in-band), but
        we still pin the suite to catch mismatch bugs early.

        Wire format (BasicCredential mode — OC's only mode):
          MlsMessage:
            ProtocolVersion(2)        = 0x0001
            WireFormat(2)             = 0x0005 (KeyPackage)
          KeyPackage:
            ProtocolVersion(2), CipherSuite(2)        ← validated against self._ciphersuite
            HPKEPublicKey init_key<V>
            LeafNode:
              HPKEPublicKey encryption_key<V>
              SignaturePublicKey signature_key<V>     ← extracted
              Credential:
                CredentialType(2)     = 0x0001 (BasicCredential)
                opaque identity<V>    ← extracted
              ...

        Variable-length fields use RFC 9420 §2.1.2 TLS-style varints.
        """
        if len(kp_wire_bytes) < 8:
            raise ValueError("KeyPackage too short for MlsMessage header")
        version = int.from_bytes(kp_wire_bytes[0:2], "big")
        wire_format = int.from_bytes(kp_wire_bytes[2:4], "big")
        if version != 0x0001:
            raise ValueError(f"Expected MLS 1.0 (0x0001), got version {version:#06x}")
        if wire_format != 0x0005:
            raise ValueError(
                f"Expected KeyPackage wireformat (0x0005), got {wire_format:#06x}"
            )
        # KeyPackage inner header: ProtocolVersion(2) + CipherSuite(2)
        # NOTE: the wire CipherSuite is the RFC 9420 §17.1 IANA ID, which differs
        # from the Python enum's `.value` (mls_rs_uniffi 0.1.0 uses sequential
        # indices). Translate via _iana_cipher_suite_id.
        # The internal-format cipher-suite check (Python enum equality) lives
        # at `import_state` / `_pack_tlv`; they operate on a different domain.
        wire_cipher_suite = int.from_bytes(kp_wire_bytes[6:8], "big")
        expected_iana = _iana_cipher_suite_id(self._ciphersuite)
        if wire_cipher_suite != expected_iana:
            raise ValueError(
                f"KeyPackage cipher_suite mismatch: KP claims {wire_cipher_suite:#06x}, "
                f"wrapper is configured for {expected_iana:#06x} ({self._ciphersuite.name})"
            )
        # Skip ProtocolVersion + CipherSuite (4 bytes) of inner KeyPackage
        pos = 8
        # init_key<V>
        n, length = _read_tls_varint(kp_wire_bytes, pos)
        pos += length + n
        # LeafNode.encryption_key<V>
        n, length = _read_tls_varint(kp_wire_bytes, pos)
        pos += length + n
        # LeafNode.signature_key<V>
        n, length = _read_tls_varint(kp_wire_bytes, pos)
        sig_key_start = pos + length
        sig_pub_key = bytes(kp_wire_bytes[sig_key_start : sig_key_start + n])
        pos = sig_key_start + n
        # Credential.credential_type
        if pos + 2 > len(kp_wire_bytes):
            raise ValueError("KeyPackage truncated before credential type")
        cred_type = int.from_bytes(kp_wire_bytes[pos : pos + 2], "big")
        pos += 2
        if cred_type != 0x0001:
            raise ValueError(
                f"Expected BasicCredential (0x0001), got credential type {cred_type:#06x}"
            )
        # BasicCredential.identity<V>
        n, length = _read_tls_varint(kp_wire_bytes, pos)
        id_start = pos + length
        identity_bytes = bytes(kp_wire_bytes[id_start : id_start + n])
        return identity_bytes, sig_pub_key


def _read_tls_varint(buf: bytes, pos: int) -> tuple[int, int]:
    """Read an RFC 9420 §2.1.2 TLS-style varint at offset `pos`.

    Returns (value, header_bytes_consumed). The 2 high bits of the first byte
    encode the field width: 00=1B, 01=2B, 10=4B, 11=8B; the low 6 bits hold
    the high-order value bits.
    """
    if pos >= len(buf):
        raise ValueError("varint EOF")
    b0 = buf[pos]
    prefix = (b0 >> 6) & 0x03
    if prefix == 0:
        return b0 & 0x3F, 1
    if prefix == 1:
        if pos + 2 > len(buf):
            raise ValueError("varint EOF (2B)")
        return ((b0 & 0x3F) << 8) | buf[pos + 1], 2
    if prefix == 2:
        if pos + 4 > len(buf):
            raise ValueError("varint EOF (4B)")
        return (
            ((b0 & 0x3F) << 24)
            | (buf[pos + 1] << 16)
            | (buf[pos + 2] << 8)
            | buf[pos + 3],
            4,
        )
    # prefix == 3 → 8B
    if pos + 8 > len(buf):
        raise ValueError("varint EOF (8B)")
    v = b0 & 0x3F
    for i in range(1, 8):
        v = (v << 8) | buf[pos + i]
    return v, 8
