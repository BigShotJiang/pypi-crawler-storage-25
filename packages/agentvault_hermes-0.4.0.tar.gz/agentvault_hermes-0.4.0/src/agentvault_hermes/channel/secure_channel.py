"""SecureChannel — async orchestrator analogous to OC's SecureChannel class.

OC source-of-truth (line ranges are an index, not a contract — verify before
divergence per ``docs/plans/2026-05-10-hermes-phase3-implementation.md`` §5.1):

- ``packages/plugin/src/channel.ts:122-214`` — constructor + private state.
- ``packages/plugin/src/channel.ts:205-210`` — PING_INTERVAL_MS / SILENCE_TIMEOUT_MS.
- ``packages/plugin/src/channel.ts:288-456`` — ``start()``.
- ``packages/plugin/src/channel.ts:545-750`` — ``send()`` (MLS path at :660-690).
- ``packages/plugin/src/channel.ts:1633-1667`` — ``stop()``.
- ``packages/plugin/src/channel.ts:2569-2740`` — ``_connect()``.
- ``packages/plugin/src/channel.ts:2742-3169`` — WS demux loop.
- ``packages/plugin/src/channel.ts:6388-6430`` — ``_scheduleReconnect()``.
- ``packages/plugin/src/channel.ts:6447-6560`` — ``_startPollFallback()``.
- ``packages/plugin/src/channel.ts:1617-1631`` — ``startTrustTokenRefresh()``.

Phase 3 scope (per plan §0):

- 1:1 MLS messaging only; A2A multi-party uses ``lock_file`` (Phase 4).
- DR fallback (``event=="message"``) is logged-and-dropped (Phase 4).
- Trust-token refresh is a no-op stub. WS-28.0 verified the device JWT TTL is
  90 days, so the deferral is safe through launch.
- Poll-fallback is a no-op stub. WS-30.x will wire it up.

**Liveness model (per plan §3.4.1 + OC channel.ts:205-210):** the AV backend
sends an app-level ``{"event":"ping"}`` to every connected WS every 30 seconds.
The agent does NOT send pings — it watches inbound traffic and reconnects if
no frame arrives for 90 seconds. ``Relay`` therefore has no ``send_heartbeat``
method, and this orchestrator does NOT spawn an outbound-heartbeat task.

**Threading model:** ``SecureChannel`` uses asyncio. All public methods MUST
be called from the asyncio event loop thread that ``start()`` was invoked on.
The orchestrator is NOT thread-safe; callers that need cross-thread invocation
should use ``asyncio.run_coroutine_threadsafe``.

**Startup sweep:** leftover lock files from a previous crashed run are NOT
cleaned up at startup. They expire 5 minutes later via the staleness path on
the next ``acquire`` call (see ``channel/lock_file.py``). A future startup
sweep is tracked as DA #13 follow-up work.
"""
from __future__ import annotations

import asyncio
import itertools
import logging
import time
from collections.abc import Awaitable, Callable, Coroutine, Iterator
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, Optional
from uuid import UUID

from agentvault_hermes.channel.a2a_founder import A2AFounder
from agentvault_hermes.channel.a2a_lifecycle import A2ALifecycleHandler
from agentvault_hermes.channel.a2a_registry import A2AChannelRegistry
from agentvault_hermes.channel.event_registry import WSEventRegistry
from agentvault_hermes.channel.loop_prevention import LoopPreventer
from agentvault_hermes.channel.mention import (
    should_process_room_message,
    strip_mentions,
)
from agentvault_hermes.channel.room_directory import RoomDirectory
from agentvault_hermes.channel.telemetry import (
    MlsTelemetryEmitter,
    MlsTelemetryEvent,
    MlsTelemetryEventType,
)

if TYPE_CHECKING:
    from agentvault_hermes.channel.outbox import WireEnvelope
    from agentvault_hermes.core.transport.relay import Relay
    from agentvault_hermes.crypto.mls_group import MlsGroupState
    from agentvault_hermes.crypto.ratchet import SigningKeypair

logger = logging.getLogger(__name__)


class _RelaySendJsonSender:
    """Adapts a Relay to the TelemetrySender Protocol used by MlsTelemetryEmitter.

    Bridges `MlsTelemetryEmitter.emit` to `Relay.send_json` so structured
    telemetry rides the existing WS envelope. Lives at module scope (not
    nested in __init__) so static analysis can see the type and ruff/mypy
    can check it like any other helper.

    Phase 4b PR-A1.
    """

    def __init__(self, relay: "Relay") -> None:
        self._relay = relay

    async def send(self, envelope: dict[str, Any]) -> None:
        await self._relay.send_json(envelope)


# Liveness / reconnect / poll-fallback constants.
# Source: packages/plugin/src/channel.ts:205-210 (PING_INTERVAL / SILENCE_TIMEOUT).
_PING_INTERVAL_SECONDS = 30.0  # cadence of the inbound silence check
_SILENCE_TIMEOUT_SECONDS = 90.0  # 3 missed inbound pings → reconnect
_POLL_FALLBACK_INTERVAL_SECONDS = 60.0  # Phase 3 stub; WS-30.x wires it up.
_TRUST_TOKEN_REFRESH_INTERVAL_SECONDS = 12 * 3600.0  # Phase 3 stub: 12h cadence.
_RECONNECT_MAX_BACKOFF_SECONDS = 60.0
# P26: bound start()'s wait on a wedged prior republish task (held inside
# _kp_publish_lock). Longer than any reasonable publish round-trip, shorter
# than human "wait for agent" patience. Tests monkeypatch this for speed.
_KP_PUBLISH_LOCK_START_TIMEOUT_SECONDS = 30.0
# P21: cancel-and-await timeout for an in-flight republish task during
# stop()/_schedule_reconnect — short window, then drop and let the task's
# own try/finally release the lock as it unwinds.
_REPUBLISH_TASK_CANCEL_TIMEOUT_SECONDS = 2.0


@dataclass
class InboundMessage:
    """Plain-text + metadata, post-decrypt. Adapter wraps it into a MessageEvent.

    Source: shape derived from OC ``channel.ts:3407-3486`` inbound MLS handler.
    Field semantics:

    - ``conversation_id`` / ``sender_device_id`` — server-stamped, see §3.7.
    - ``plaintext`` — raw decrypted bytes-as-str (callers decode JSON / etc).
    - ``message_type`` — ``"text"`` | ``"command"`` | future enum values.
    - ``is_handshake`` — True for MLS Commit / Proposal / Welcome (epoch-only,
      no application payload). The demux loop persists state then suppresses
      the agent surface (DA #10).
    - ``room_id`` — set when the frame is a room message (the frame carried
      ``room_id``); ``None`` for 1:1. Drives room-aware dispatch.
    - ``server_message_id`` / ``created_at`` / ``topic_id`` / ``parent_span_id``
      — passed through from the inbound envelope when present.
    """

    conversation_id: str
    sender_device_id: str
    plaintext: str
    message_type: str
    is_handshake: bool
    room_id: Optional[str] = None
    # action #238 — A2A: when the inbound frame carried an a2a_channel_id,
    # surface it as a structured field. ``from_hub_address`` is the sending
    # peer's hub address (OC parity: A2AMessage carries fromHubAddress; we
    # do NOT prefix the plaintext with "[sender]:" the way rooms do).
    a2a_channel_id: Optional[str] = None
    from_hub_address: Optional[str] = None
    server_message_id: Optional[str] = None
    created_at: Optional[str] = None
    topic_id: Optional[str] = None
    parent_span_id: Optional[str] = None


# Public message handler shape: matches Hermes' MessageHandler convention.
InboundCallback = Callable[[InboundMessage], Awaitable[None]]


GroupType = Literal["1to1", "room", "a2a"]


@dataclass(frozen=True)
class KnownGroup:
    """A group this Hermes instance is currently tracking for MLS sync.

    Yielded by ``SecureChannel._iter_known_groups()``. Used by
    ``_send_initial_sync()`` (PR-2) and ``_cold_start_scan()`` (PR-3) to
    iterate the agent's known groups on every WebSocket connect/reconnect.

    Fields:
      - ``group_id``: stringified UUID (matches wire format used by
        backend ``mls_sync`` handler at ``ws.py:1265-1339``).
      - ``group_type``: which OC iteration this group belongs to. PR-2's
        emission loop covers all three for forward parity; today only
        ``"1to1"`` yields real groups (rooms + A2A use lock_file in
        Phase 3 and have no MLS state yet).
      - ``last_epoch``: current MLS epoch, or None.
      - ``since_ts``: timestamp for same-epoch replay (OC channel.ts:2715).
        May be None.
      - ``has_local_state``: True iff ``_mls_states[group_id]`` is set.
        PR-2 only emits ``mls_sync`` for groups where this holds.
    """

    group_id: str
    group_type: GroupType
    last_epoch: int | None
    since_ts: int | None
    has_local_state: bool


class SecureChannel:
    """One-WebSocket-per-device orchestrator.

    Owns:

    - One ``Relay`` (= one ``WsClient`` + one ``RestClient``).
    - A read-only view of the adapter's ``dict[conv_id, MlsGroupState]``.
    - A ``LoopPreventer`` (sliding-window per-key reply rate limiter).
    - Background tasks: demux loop, silence-timeout liveness check,
      poll-fallback (stub), trust-token-refresh (stub).
    - A set of held A2A sync lock filenames (released on ``stop()``).

    Lifecycle::

        ch = SecureChannel(relay, mls_states, on_inbound, data_dir,
                           agent_name="hermes", account_id="acct-1")
        await ch.start()  # opens WS, kicks off background tasks
        ...
        await ch.send(conv_id, b"hello")
        ...
        await ch.stop()   # cancels tasks, closes WS, releases locks

    **Threading model:** asyncio-only. All public methods MUST be called from
    the event loop thread that ``start()`` was invoked on. Use
    ``asyncio.run_coroutine_threadsafe`` from non-loop threads.
    """

    def __init__(
        self,
        relay: "Relay",
        mls_states: dict[str, "MlsGroupState"],
        on_inbound: InboundCallback,
        data_dir: Path,
        *,
        device_keys: "SigningKeypair",
        device_id: UUID,
        agent_name: str,
        account_id: str,
        loop_preventer: Optional[LoopPreventer] = None,
        own_hub_id: str = "",
    ) -> None:
        self._relay = relay

        # Phase 4b PR-A1: structured MLS telemetry emitter.
        # Bound to relay.send_json so every emit rides the existing WS
        # frame. The emitter absorbs its own send failures (logs WARN,
        # does NOT raise) — but does NOT absorb CancelledError, so
        # cooperative cancellation still works.
        #
        # Spec: docs/superpowers/specs/2026-05-14-hermes-phase4b-mls-telemetry-and-ui-design.md
        self._telemetry = MlsTelemetryEmitter(_RelaySendJsonSender(self._relay))

        self._mls_states = mls_states
        self._on_inbound = on_inbound
        self._data_dir = data_dir
        # P11 (plan §3.3): SigningKeypair + device UUID are required for the
        # KP-generation path. They construct fresh MlsGroupState instances
        # inside _ensure_pending_key_package() (Seam A) and are otherwise
        # immutable for the channel lifetime.
        self._device_keys: "SigningKeypair" = device_keys
        self._device_id: UUID = device_id
        self._agent_name = agent_name
        self._account_id = account_id
        # TODO Phase 3.x: periodic GC of LoopPreventer's _reply_timestamps /
        # _cooldown_until dicts to prevent unbounded growth on rotating
        # short-lived A2A channels. (DA #8 deferred.)
        self._loop_preventer = loop_preventer or LoopPreventer()

        # conv_id → mls_group_id (string UUIDs). Populated lazily by send()
        # and the inbox handler. Required because the wire envelope carries
        # `group_id` (MLS group UUID), which can differ from
        # `conversation_id` for shared 1:1 groups (OC channel.ts:3420-3447).
        self._conv_to_group_id: dict[str, str] = {}

        # Room directory — the registry of multi-party rooms this agent
        # belongs to. Populated from three sources (room_joined WS event,
        # the connect-time GET /api/v1/rooms poll, accepted room Welcomes)
        # and persisted to data_dir/rooms.json. See channel/room_directory.py.
        self._room_directory = RoomDirectory()

        # action #238 — A2A channel state + lifecycle. Member-role only in
        # Slice A: receive + reply. The registry persists to a2a_channels.json;
        # the lifecycle handler owns the nine A2A WS events; both are wired
        # below alongside the existing room registrations.
        self._own_hub_id = own_hub_id
        self._a2a_registry = A2AChannelRegistry()
        self._a2a_registry.load(data_dir)

        # Slice B: creator-role founder for A2A channels. Constructed before
        # the lifecycle handler so the latter can take found_a2a_group as
        # a callback. Uses a RestClient factory so each found_a2a_group call
        # gets a clean per-call client (matches Slice A's _request_a2a_welcome
        # pattern at secure_channel.py:2543).
        self._a2a_founder = A2AFounder(
            rest_client_factory=self._a2a_rest_client_factory,
            relay=self._relay,
            own_hub_id=self._own_hub_id,
            own_device_id=str(self._device_id),
            registry=self._a2a_registry,
            create_mls_state=self._create_a2a_mls_state,
            persist_mls_state=self._persist_a2a_mls_state,
            save_registry=lambda: self._a2a_registry.save(self._data_dir),
        )

        self._a2a_lifecycle = A2ALifecycleHandler(
            self._a2a_registry,
            data_dir,
            own_hub_id=self._own_hub_id,
            ensure_key_package=self._ensure_pending_key_package,
            drop_channel_mls=self._drop_a2a_channel_mls,
            request_welcome=self._request_a2a_welcome,
            found_a2a_group=self._a2a_founder.found_a2a_group,
        )

        self._stop_event = asyncio.Event()
        self._background_tasks: set[asyncio.Task[None]] = set()
        self._held_locks: set[str] = set()  # conv_ids whose A2A locks we hold

        # Per-conversation send lock. MlsGroupState is not re-entrant; two
        # concurrent send() calls on the same conv would corrupt the ratchet.
        # Created lazily inside send() so the asyncio.Lock binds to the
        # running event loop (Python 3.10+ requires a running loop at
        # Lock construction time in some configurations).
        #
        # Acquirers (action_item #156 — full set of paths that serialize on
        # this map; any new state-mutating code path MUST take the same lock):
        # 1. ``send()`` — acquires for encrypt + epoch read.
        # 2. ``handle_mls_welcome`` — acquires for join_from_welcome writes
        #    (passed as ``send_locks=`` kwarg from ``_pull_delivery_queue``).
        # 3. ``handle_message_mls`` — acquires for state.decrypt + dedup
        #    record (passed as ``send_locks=`` kwarg from both
        #    ``_demux_loop`` and ``_pull_delivery_queue``). Closes the race
        #    where a concurrent send().encrypt and demux.decrypt could
        #    mutate the same Rust state machine in parallel.
        self._conv_send_locks: dict[str, asyncio.Lock] = {}

        # Liveness tracking — see plan §3.4.1.
        self._last_inbound_ts: float = time.monotonic()

        # --- KP-bundle / Welcome plumbing (plan §3.3 P2/P11/P15/P16/P21) ---
        # ``_pending_kp_state`` is the MlsGroupState that holds the
        # private-side material for the most-recently-published KP. mls_rs's
        # private KP material is NOT separately extractable — it lives inside
        # the wrapper's _client/storage — so the SAME instance must be reused
        # to process the inbound Welcome encrypted to that KP's public key.
        # Cleared by handle_mls_welcome (Stage 4) after a successful join.
        self._pending_kp_state: Optional["MlsGroupState"] = None
        # Re-entrant guard for _pull_delivery_queue (Stage 3 body lands later).
        # Concurrent invocations (ping-driven + on-connect + future heartbeat)
        # NOOP the second caller — we don't want to queue overlapping pulls.
        self._delivery_pulling: bool = False
        # P2 + P15: gate the demux loop's ``mls_delivery`` branch (added in
        # Stage 3) so it cannot fire ``_pull_delivery_queue`` before
        # ``start()`` has published the KP. The event MUST be set in a
        # ``finally`` block on every start() exit path so a parked demux can
        # always wake (and then observe ``_stop_event`` and exit cleanly).
        self._initial_setup_complete: asyncio.Event = asyncio.Event()
        # P16: serialize concurrent fire-and-forget republish attempts so a
        # ping-then-Welcome race doesn't double-publish (which would
        # backend-side delete the prior KP twice and bork in-flight Welcomes).
        # Acquired by start() (with P26 timeout) AND by every fire-and-forget
        # republish task spawned post-Welcome.
        self._kp_publish_lock: asyncio.Lock = asyncio.Lock()
        # P16/P21: track the active republish task so stop() / reconnect can
        # cancel it cleanly. Stage 4's pull-queue dispatcher writes here.
        self._republish_task: Optional[asyncio.Task[None]] = None

        # PR-1 Phase 4a: WS-event dispatch registry. Wires the 5 extracted
        # _handle_* methods to the demux loop. The registry catches per-
        # handler exceptions and lets CancelledError propagate so the demux
        # task tears down cleanly on stop(). See event_registry.py module
        # docstring.
        self._event_registry = WSEventRegistry()
        # ---------- Phase 4a PR-2: mls_sync tracking ----------
        # Monotonic counter; `next()` yields a fresh `sync_run_id` per
        # reconnect. Used to correlate N MLS_SYNC_* log lines back to
        # one reconnect event during operator triage.
        self._sync_run_counter: itertools.count[int] = itertools.count(0)
        # Per-group "sync emitted, replay_complete not yet received"
        # flag. Set when `_send_initial_sync` emits a frame for a
        # group; cleared when `_handle_mls_sync_response(action=
        # "replay_complete")` arrives (Cluster 3). Value is the
        # monotonic timestamp the sync was emitted.
        self._sync_in_progress: dict[str, float] = {}
        # Cached set of known group_ids. Populated once at the start of
        # `_send_initial_sync()` by walking `_iter_known_groups()`. Used
        # by `_handle_mls_sync_response` to validate inbound
        # `action="rejoin"` group_ids (Cluster 3).
        #
        # TODO PR-3: move the populate-call earlier so it runs at the
        # start of `_cold_start_scan()` (Phase A) rather than
        # `_send_initial_sync()` (Phase B). PR-3 will introduce
        # `_cold_start_scan` and the populate-call relocation should
        # happen in the same PR so `_known_group_ids` always reflects
        # the full known set, including lost-state groups.
        self._known_group_ids: frozenset[str] = frozenset()
        # Consecutive-failures threshold for catch-up scan abort. After
        # N per-group emit failures in a row, abort the rest of the
        # scan with one `MLS_SYNC_ABORT reason=consecutive_failures`
        # line rather than logging N near-identical failures.
        self._consecutive_failures_threshold: int = 3
        # ---------- end Phase 4a PR-2 ----------
        # ---------- Phase 4a PR-3: welcome-request inflight dedup ----------
        # Per-group "request-welcome POST in flight" tracking. Both
        # `_cold_start_recover_single_group` (PR-3's recovery path) and
        # the existing `inbox.py:_fire_request_welcome` call site (PR #184,
        # at inbox.py:601, fires on stale-KP failure) check this dict
        # before firing the POST. Without dedup, parallel recovery flows
        # could cause duplicate POST -> duplicate Welcome -> duplicate
        # failure cycles.
        #
        # Value is monotonic seconds when the inflight entry was set;
        # `_is_welcome_request_inflight` treats entries older than
        # `_welcome_request_inflight_ttl` as expired.
        #
        # Cleared on Welcome arrival (success OR failure) so retry isn't
        # TTL-bound. Inter-Hermes-restart, the in-memory dedup resets
        # entirely.
        self._welcome_request_inflight: dict[str, float] = {}
        # Configurable TTL (seconds). Welcome arrives in ~1-2s when the
        # creator device is online; 30s catches the realistic in-flight
        # window without being absurd. TTL is fallback only — the
        # inflight entry is cleared on Welcome arrival regardless.
        self._welcome_request_inflight_ttl: float = 30.0
        # ---------- end Phase 4a PR-3 ----------
        self._event_registry.register("ping", self._handle_ping)
        self._event_registry.register("error", self._handle_error)
        self._event_registry.register("message_mls", self._handle_message_mls)
        self._event_registry.register("mls_delivery", self._handle_mls_delivery)
        self._event_registry.register("message", self._handle_dr_fallback)
        # PR-2: catch-up sync response handler.
        self._event_registry.register(
            "mls_sync_response", self._handle_mls_sync_response
        )
        # PR-3: peer-initiated welcome request handler.
        self._event_registry.register(
            "mls_welcome_requested", self._handle_mls_welcome_requested
        )
        # action #234: room messaging.
        self._event_registry.register("room_joined", self._handle_room_joined)
        # room_message_mls reuses _handle_message_mls — handle_message_mls
        # resolves the group by wire fields (room_id), not by event type;
        # the room variant is distinguished downstream by InboundMessage.room_id.
        self._event_registry.register("room_message_mls", self._handle_message_mls)

        # action #238 — A2A. a2a_message_mls reuses _handle_message_mls
        # (distinguished downstream by a2a_channel_id, like room_message_mls).
        self._event_registry.register("a2a_message_mls", self._handle_message_mls)
        self._event_registry.register(
            "a2a_channel_invited", self._a2a_lifecycle.handle_channel_invited
        )
        self._event_registry.register(
            "a2a_channel_approved", self._a2a_lifecycle.handle_channel_approved
        )
        self._event_registry.register(
            "a2a_channel_rejected", self._a2a_lifecycle.handle_channel_rejected
        )
        self._event_registry.register(
            "a2a_channel_revoked", self._a2a_lifecycle.handle_channel_revoked
        )
        self._event_registry.register(
            "a2a_participant_joined",
            self._a2a_lifecycle.handle_participant_joined,
        )
        self._event_registry.register(
            "a2a_participant_left", self._a2a_lifecycle.handle_participant_left
        )
        self._event_registry.register(
            "a2a_participant_removed",
            self._a2a_lifecycle.handle_participant_removed,
        )
        self._event_registry.register(
            "a2a_agent_removed", self._a2a_lifecycle.handle_agent_removed
        )
        self._event_registry.register(
            "a2a_creator_transferred",
            self._a2a_lifecycle.handle_creator_transferred,
        )
        # Slice B: stub handler registered now so Slice C is a body-only fill.
        self._event_registry.register(
            "a2a_invite_pending", self._a2a_lifecycle.handle_invite_pending
        )

    # --- public API -----------------------------------------------------------

    async def start(self) -> None:
        """Open the relay and spawn background tasks.

        OC parity: ``channel.ts:288-456``. The connect MUST complete before the
        demux loop is spawned — otherwise the demux's ``async for`` over
        ``relay.receive_messages()`` would fail before the WS is open.

        Order (plan §3.3 Seam B; P2 + P15 + P26):

        1. Clear ``_stop_event`` and ``_initial_setup_complete``.
        2. Acquire ``_kp_publish_lock`` with a 30s timeout (P26) so a hung
           fire-and-forget republish task from a prior cycle cannot
           permanently jam start. Loud-fail with ``RuntimeError`` on timeout
           — the caller (adapter.connect) tears down via existing
           try/except.
        3. Under the lock:
           a. ``relay.connect()`` — open the WS.
           b. ``_ensure_pending_key_package()`` — Seam A; idempotent KP
              publish.
           c. ``_pull_delivery_queue()`` — Stage 3 stub today; ships the
              real body in Stage 3 of the work-stream (also synchronous so
              a queued Welcome surfaces before demux ever runs).
           If any step raises, ``_initial_setup_complete`` MUST be set
           BEFORE re-raising (P15) so a parked demux from a prior reconnect
           cycle wakes and exits via ``_stop_event`` instead of wedging.
           ``_teardown_partial_start`` runs to close the relay + cancel
           anything we managed to spawn before the failure.
        4. Spawn background tasks (demux / silence / poll / trust-token).

        **Lock-ordering invariant (P24):** No code path holds
        ``_conv_send_locks[*]`` while acquiring ``_kp_publish_lock``.
        ``start()`` honors this trivially because no per-conv lock is held
        on the start path; the Welcome handler (Stage 4) RELEASES its
        per-conv lock BEFORE the caller schedules the fire-and-forget
        republish task that acquires ``_kp_publish_lock``.

        Spawned tasks:

        1. ``_demux_loop`` — pulls inbound frames, dispatches by event type.
        2. ``_silence_timeout_task`` — every 30s checks for >90s inbound silence.
        3. ``_poll_fallback_task`` — Phase 3 stub (no-op).
        4. ``_trust_token_refresh_task`` — Phase 3 stub (no-op; verified safe by
           WS-28.0's confirmation of 90-day device JWT TTL).

        **No outbound heartbeat task is spawned** — see plan §3.4.1.

        Note: leftover lock files from a previous crashed run are NOT cleaned
        up at startup; they expire 5 min later via the staleness path on next
        acquire (see ``channel/lock_file.py``).
        """
        self._last_inbound_ts = time.monotonic()
        self._stop_event.clear()
        self._initial_setup_complete.clear()

        # Load the persisted room directory before the demux loop runs so
        # inbound room frames resolve against known rooms from the first
        # frame. The connect-time poll (later in start()) reconciles it.
        self._room_directory.load(self._data_dir)

        # P26: bound the wait on a wedged prior republish. Use the
        # module-level constant so tests can monkeypatch it for speed.
        try:
            await asyncio.wait_for(
                self._kp_publish_lock.acquire(),
                timeout=_KP_PUBLISH_LOCK_START_TIMEOUT_SECONDS,
            )
        except asyncio.TimeoutError as exc:
            # Loud-fail invariant (§3.5 P5). Caller tears down.
            raise RuntimeError(
                "start(): timed out waiting for _kp_publish_lock; a prior "
                "republish task is wedged. Force a process restart."
            ) from exc

        try:
            try:
                await self._relay.connect()
                await self._ensure_pending_key_package()
                # Stage 3 stub today — the body lands in Stage 3 of the
                # work-stream. Calling the no-op now keeps the start-order
                # contract (publish → pull → spawn demux) stable across
                # stages.
                await self._pull_delivery_queue()
            except BaseException:
                # P15: ensure the event fires on the way out so any demux
                # from a prior reconnect cycle awaiting it can unblock and
                # then observe _stop_event.
                self._initial_setup_complete.set()
                await self._teardown_partial_start()
                raise
            self._initial_setup_complete.set()
        finally:
            self._kp_publish_lock.release()

        # ---------- Phase 4a PR-3: cold-start scan (Phase A) ----------
        # Lost-state recovery for known groups with no local
        # MlsGroupState. Runs BEFORE _send_initial_sync (Phase B) per
        # the strict 3-phase startup ordering. Populates
        # _known_group_ids as a side effect so _send_initial_sync's
        # consumer (`_handle_mls_sync_response` rejoin validation) sees
        # both intact-state AND lost-state groups.
        await self._cold_start_scan()
        # ---------- end Phase 4a PR-3 ----------
        # action #234: reconcile the room directory against the backend so
        # rooms joined while offline surface before the first sync. Runs
        # after _pull_delivery_queue (room Welcomes processed) so polled
        # rooms can already have MLS state.
        await self._poll_rooms()
        # action #238: parallel A2A reconciliation — the spec §5.5
        # "connect-time reconciliation is the authoritative reliability
        # mechanism". Best-effort: failures are logged + swallowed.
        await self._reconcile_a2a_channels()
        # ---------- Phase 4a PR-2: initial mls_sync on connect ----------
        # Per OC channel.ts:2689-2733: emit one mls_sync per known group
        # with intact local state. Strict-sequential per the Phase 4a
        # spec: this runs in Phase B (initial sync). Phase A (cold-start
        # scan for lost-state groups) ran above (PR-3).
        #
        # _send_initial_sync absorbs all errors (logs + returns); the
        # demux loop spawning below is safe regardless.
        await self._send_initial_sync()
        # ---------- end Phase 4a PR-2 ----------

        self._spawn(self._demux_loop())
        self._spawn(self._silence_timeout_task())
        self._spawn(self._poll_fallback_task())
        self._spawn(self._trust_token_refresh_task())

    async def stop(self) -> None:
        """Cancel background tasks, close relay, release held A2A locks.

        OC parity: ``channel.ts:1633-1667``. Order is intentional:

        1. Set the stop event so loops break on their next iteration.
        2. Cancel all background tasks and gather them (errors absorbed).
        3. Cancel any in-flight ``_republish_task`` (P21) with a 2s
           bounded wait; the task's own try/finally releases the
           ``_kp_publish_lock``.
        4. Release any held A2A sync locks (best-effort; idempotent).
        5. Close the relay (idempotent — calling twice is a no-op).

        Lock release happens BEFORE relay disconnect so a slow relay close
        does not delay lock cleanup. Disconnect is awaited last so callers
        of ``stop()`` know the WS is fully torn down on return.
        """
        self._stop_event.set()
        tasks = list(self._background_tasks)
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        # P21: cancel any in-flight republish task. We shield + wait so we
        # don't inherit the cancellation if the calling task itself is
        # being cancelled mid-stop. Bounded by
        # _REPUBLISH_TASK_CANCEL_TIMEOUT_SECONDS; on timeout we drop the
        # reference and let the task unwind on its own (its own try/finally
        # releases the publish lock).
        await self._cancel_republish_task()
        for conv_id in list(self._held_locks):
            await self._release_lock(conv_id)
        await self._relay.disconnect()

    async def send(
        self,
        conversation_id: str,
        plaintext: bytes,
        *,
        message_type: str = "text",
        client_message_id: Optional[str] = None,
        topic_id: Optional[str] = None,
        parent_span_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> None:
        """Encrypt and push an outbound MLS application message.

        OC parity: ``channel.ts:545-750`` (MLS path at ``:660-690``).

        Order under the per-conv lock (DA #11 mandate; ratchet is not
        re-entrant):

        1. ``loop_preventer.can_reply`` — BEFORE encrypt, so a rate-limit hit
           does not advance the MLS state for a message we'll never send. A
           room conversation uses the room-scoped counter
           (``loop_preventer.can_reply_room``) instead (action #234).
        2. Resolve ``state.group_id`` → UUID-string (cached on first read).
        3. Read ``state.epoch``.
        4. ``state.encrypt(plaintext)`` — advances the MLS ratchet.
        5. Persist updated state — BEFORE relay send, so a relay error
           does not leave us with a stale on-disk state.
        6. ``relay.send_message(conversation_id, group_id, epoch, ciphertext, …)``
           — NO ``sender_device_id`` (backend stamps it from the WS session
           per plan §3.7). A room reply also passes ``room_id`` so the
           envelope is emitted as ``room_message_mls`` (action #234).
        7. ``loop_preventer.record_reply`` — AFTER successful relay send (DA
           #14); a failed send (raised exception) does not record. A room
           conversation records via ``loop_preventer.record_reply_room``
           (action #234).

        Raises:
            RuntimeError: if no ``MlsGroupState`` exists for ``conversation_id``
                or the state has not been initialized (no ``create_group`` /
                ``join_from_welcome`` / ``import_state`` yet).
        """
        logger.debug(
            "secure_channel.send entry conv=%s len=%d",
            conversation_id[:8],
            len(plaintext),
        )

        # action #234: detect whether this conversation is a room so we can
        # use the room-scoped loop-prevention counters and emit a
        # room_message_mls envelope.
        is_room = self._room_directory.get(conversation_id) is not None
        # action #238: parallel A2A detection. An A2A reply uses the
        # A2A-scoped loop-prevention counter and emits an a2a_message_mls
        # envelope. A2A takes precedence over rooms (the registries are
        # disjoint in practice).
        is_a2a = self._a2a_registry.get(conversation_id) is not None

        # Per-conv lock binds lazily to the running event loop. Subsequent
        # send() calls on the same conv reuse the same Lock instance.
        lock = self._conv_send_locks.get(conversation_id)
        if lock is None:
            lock = asyncio.Lock()
            self._conv_send_locks[conversation_id] = lock

        # Log lock-acquire intent at DEBUG so a stuck per-conv lock is
        # observable when running the gateway with --log-level=debug. Steady
        # state stays quiet at INFO.
        logger.debug(
            "secure_channel.send acquiring lock conv=%s lock_locked=%s",
            conversation_id[:8],
            lock.locked(),
        )
        async with lock:
            # 1. Loop prevention — short-circuit before any state mutation.
            #    Rooms use the room-scoped counter (LoopPreventer.can_reply_room);
            #    A2A uses the A2A-scoped counter (action #238).
            if is_a2a:
                can_reply = self._loop_preventer.can_reply_a2a(conversation_id)
            elif is_room:
                can_reply = self._loop_preventer.can_reply_room(conversation_id)
            else:
                can_reply = self._loop_preventer.can_reply(conversation_id)
            if not can_reply:
                logger.warning(
                    "Loop prevention: rate limit hit for %s", conversation_id[:8]
                )
                return

            # 2. Look up MLS state.
            state = self._mls_states.get(conversation_id)
            if state is None or not state.is_initialized:
                raise RuntimeError(
                    f"No MlsGroupState for conversation {conversation_id}"
                )

            # 3. Resolve group_id (cached) + read epoch under the lock.
            #    OC channel.ts:660-668. group_id is the MLS group UUID
            #    (state.group_id is bytes; convert to UUID string).
            #
            #    Defensive length check (DA #8): Hermes' MlsGroupState tests
            #    use 16-byte group_ids (UUID.bytes), but OC's mls-group.ts
            #    encodes the UUID-string as UTF-8 (36 bytes). When WS-30+
            #    receives a Welcome from an OC peer, mls-rs may hand back a
            #    36-byte group_id and ``UUID(bytes=...)`` raises
            #    ``ValueError: bytes is not a 16-char string``. Surface a
            #    clear error here rather than letting a cryptic stack escape
            #    from inside the lock.
            #    TODO(WS-30 interop): handle 36-byte (UTF-8 UUID-string)
            #    group_ids when OC interop tests start landing.
            group_id_str = self._conv_to_group_id.get(conversation_id)
            if group_id_str is None:
                raw_gid = state.group_id
                if len(raw_gid) == 16:
                    group_id_str = str(UUID(bytes=raw_gid))
                elif len(raw_gid) == 36:
                    # OC peers encode the UUID-string as UTF-8.
                    group_id_str = raw_gid.decode("ascii")
                    # Validate it parses as a UUID before caching.
                    UUID(group_id_str)
                else:
                    raise RuntimeError(
                        f"Unexpected group_id length {len(raw_gid)} for "
                        f"conversation {conversation_id} — expected 16 (UUID "
                        f"bytes) or 36 (UTF-8 UUID-string)"
                    )
                self._conv_to_group_id[conversation_id] = group_id_str

            # 4. Encrypt (advances application-data ratchet, NOT epoch).
            ciphertext = state.encrypt(plaintext)
            # Bug A fix (PR #171 + #172): read epoch AFTER encrypt() so a
            # joiner's wire-refresh self-heal — which fires inside the first
            # encrypt and updates ``_epoch`` from the framing header — is
            # visible in the envelope. Reading before encrypt left the
            # envelope at the placeholder/stale value for the first message
            # in every newly-restored session, even though the ciphertext
            # was correctly at the real epoch. encrypt() does NOT advance
            # the group epoch (application messages advance the application-
            # data ratchet only — RFC 9420 §6), so pre/post-encrypt are
            # semantically equivalent for a wire-refreshed state.
            epoch = state.epoch
            logger.debug(
                "secure_channel.send encrypted conv=%s ct_len=%d epoch=%d",
                conversation_id[:8],
                len(ciphertext),
                epoch,
            )

            # 5. Persist updated state. Must happen BEFORE relay send so a
            #    relay failure does not leave on-disk state out of sync with
            #    the in-memory (now-advanced) ratchet. Wrapped in to_thread
            #    so a slow filesystem (NFS / fuse / EBS) does not block the
            #    event loop (DA #10 hygiene).
            await asyncio.to_thread(self._persist_state_sync, conversation_id, state)

            # 6. Wire envelope + relay send. NO sender_device_id (§3.7).
            await self._relay.send_message(
                conversation_id=conversation_id,
                group_id=group_id_str,
                epoch=epoch,
                ciphertext=ciphertext,
                message_type=message_type,
                client_message_id=client_message_id,
                topic_id=topic_id,
                parent_span_id=parent_span_id,
                metadata=metadata,
                room_id=conversation_id if is_room else None,
                a2a_channel_id=conversation_id if is_a2a else None,
            )

            # 7. Record reply only AFTER successful relay send (DA #14).
            if is_a2a:
                self._loop_preventer.record_reply_a2a(conversation_id)
            elif is_room:
                self._loop_preventer.record_reply_room(conversation_id)
            else:
                self._loop_preventer.record_reply(conversation_id)
            # One INFO line per outbound — operators see "an outbound message
            # for conv=X just sent successfully at epoch=N" without the
            # 7-step trace spam. Bug B's diagnostic chain is now in commit
            # history (PRs #168 + #170) and the regression tests.
            logger.info(
                "outbound sent conv=%s group=%s epoch=%d ct_len=%d type=%s",
                conversation_id[:8],
                group_id_str[:8],
                epoch,
                len(ciphertext),
                message_type,
            )

    # --- internals ------------------------------------------------------------

    def _spawn(self, coro: "Coroutine[Any, Any, None]") -> None:
        """Create and track a background task. Used only by ``start()``."""
        task: asyncio.Task[None] = asyncio.create_task(coro)
        self._background_tasks.add(task)
        task.add_done_callback(self._background_tasks.discard)

    async def _handle_dr_fallback(self, envelope: "WireEnvelope") -> None:
        """Double Ratchet fallback message handler.

        Phase 3 logs and drops. A later phase (NOT this PR) will wire DR
        fallback to a real receive path.

        Lazy import on ``handle_message_dr`` from ``channel/inbox.py``.
        See ``_handle_message_mls`` docstring for the import rationale.

        Behavior preserved from the inline ``_demux_loop`` block pre-PR-1.
        """
        from agentvault_hermes.channel.inbox import handle_message_dr

        await handle_message_dr(envelope)

    async def _handle_mls_sync_response(
        self, envelope: "WireEnvelope"
    ) -> None:
        """Handle inbound ``event:"mls_sync_response"`` from backend.

        Two action variants per spec and backend ``ws.py:1265-1339``:

        - ``action="rejoin"`` — backend determined our ``last_epoch`` is
          unrecoverable; agent should re-join. PR-3 invokes
          ``await self._cold_start_recover_single_group(group_id)`` —
          the wrapper publishes a fresh KP + fires request-welcome via
          the inflight-dedup contract.
        - ``action="replay_complete"`` — backend has finished replaying
          all missed messages for this group. Clears the
          ``_sync_in_progress`` entry and logs at DEBUG. If no entry
          exists for the group (defensive: backend bug, forged frame),
          logs ``MLS_SYNC_RESPONSE_UNEXPECTED`` at INFO and drops; does
          NOT auto-create an entry.

        Malformed payloads (missing ``group_id`` or ``action``) log
        ``MLS_SYNC_RESPONSE_INVALID reason=missing_field`` at WARN
        and drop. Unknown actions log
        ``MLS_SYNC_RESPONSE_INVALID action=<value>`` at WARN and drop.
        """
        data = envelope.data or {}
        group_id = data.get("group_id")
        action = data.get("action")
        # Type-guard against backend protocol drift / forged frames:
        # `data.get(...)` returns Any; a non-string group_id or action
        # would silently slip past the truthiness check below and emit
        # grep-toxic log lines (e.g. `group_id=123`). Treat any
        # non-string as missing_field. (DA finding 2026-05-13.)
        if (
            not isinstance(group_id, str)
            or not isinstance(action, str)
            or not group_id
            or not action
        ):
            logger.warning(
                "MLS_SYNC_RESPONSE_INVALID reason=missing_field "
                "has_group_id=%s has_action=%s",
                bool(group_id),
                bool(action),
            )
            return
        if action == "rejoin":
            # KNOWN GAP: `_known_group_ids` is a one-shot snapshot taken
            # at the top of `_send_initial_sync()` (see field docstring
            # at __init__). A Welcome arriving AFTER the snapshot but
            # BEFORE this rejoin response will be rejected as
            # `unknown_group` even though legitimate. The backend
            # currently only sends `rejoin` for groups it received an
            # `mls_sync` for, so this race window is narrow; PR-3
            # closes it by moving the populate-call into
            # `_cold_start_scan` (Phase A) where it captures lost-state
            # groups too. (DA finding 2026-05-13.)
            if group_id not in self._known_group_ids:
                logger.warning(
                    "MLS_SYNC_RESPONSE_INVALID action=rejoin "
                    "reason=unknown_group group_id=%s",
                    group_id,
                )
                return
            # PR-3: real cold-start recovery for the single group.
            # The wrapper publishes a fresh KP + fires request-welcome
            # via the inflight-dedup contract. Wrap in try/except so a
            # POST failure surfaces a human-readable WARN log naming the
            # group_id — the registry's generic exception handler logs
            # only event_type + a BLAKE2b payload hash (not grep-able
            # for triage). The wrapper itself does NOT log per-group
            # failures (only the inflight-skip INFO log), so this
            # try/except is the operator-visibility seam. (DA Cluster 4
            # finding.)
            try:
                await self._cold_start_recover_single_group(group_id)
            except Exception as exc:  # noqa: BLE001 — operator-log seam
                logger.warning(
                    "MLS_SYNC_RESPONSE_REJOIN_FAIL group_id=%s error=%s",
                    group_id,
                    exc,
                )
                await self._telemetry.emit(
                    MlsTelemetryEvent(
                        event=MlsTelemetryEventType.SYNC_RESPONSE_REJOIN_FAIL,
                        group_id=group_id,
                        context={"error_class": type(exc).__name__},
                    )
                )
            return
        if action == "replay_complete":
            if group_id not in self._sync_in_progress:
                logger.info(
                    "MLS_SYNC_RESPONSE_UNEXPECTED action=replay_complete "
                    "group_id=%s",
                    group_id,
                )
                return
            del self._sync_in_progress[group_id]
            logger.debug(
                "mls_sync replay complete group_id=%s", group_id
            )
            return
        # Unknown action — log invalid, drop.
        logger.warning(
            "MLS_SYNC_RESPONSE_INVALID action=%s group_id=%s",
            action,
            group_id,
        )

    async def _handle_mls_welcome_requested(
        self, envelope: "WireEnvelope"
    ) -> None:
        """Inbound handler for ``event:"mls_welcome_requested"`` — backend
        is signaling that another peer is requesting a Welcome from us
        (this Hermes is the group creator or already-joined member).

        OC parity: ``channel.ts:2893-2898`` — triggers a fresh delivery-
        queue pull so the queued Welcome lands and the requester can
        proceed.

        Backend wiring (PR #183 receive side): backend broadcasts this
        event to non-requesting group members when any device posts to
        ``POST /api/v1/mls/groups/{id}/request-welcome``.

        Single-purpose handler: validates payload has ``group_id``, then
        delegates to ``_pull_delivery_queue``. Type-guard against non-
        string group_id (defensive against backend protocol drift).

        Mirrors ``_handle_mls_delivery`` safety checks (P2 + P15 — DA
        Cluster 4 finding): wait for ``_initial_setup_complete`` so the
        KP is published before pulling, and re-check ``_stop_event``
        post-wait so a stop-during-wait races correctly into a return
        instead of a doomed pull against a closed Relay.
        """
        data = envelope.data or {}
        group_id = data.get("group_id")
        if not isinstance(group_id, str) or not group_id:
            logger.warning(
                "MLS_WELCOME_REQUESTED_INVALID reason=missing_group_id"
            )
            await self._telemetry.emit(
                MlsTelemetryEvent(
                    event=MlsTelemetryEventType.WELCOME_REQUESTED_INVALID,
                    group_id=None,
                    context={"reason": "missing_group_id"},
                )
            )
            return
        await self._initial_setup_complete.wait()
        if self._stop_event.is_set():
            return
        await self._pull_delivery_queue()

    async def _handle_mls_delivery(self, envelope: "WireEnvelope") -> None:
        """MLS delivery-ping handler.

        Lightweight signal that the backend has rows for us in the
        delivery queue. We then call ``_pull_delivery_queue`` to fetch
        them.

        Two safety checks preserved from the inline implementation:
          1. ``await self._initial_setup_complete`` — prevents pulling
             before KP is published (Seam B, P2). Only matters on a
             reconnect cycle.
          2. After the wait, re-check ``_stop_event`` (P15). ``start()``
             sets the event in its ``finally`` on raise, so we can wake
             from the wait into a stopped channel; calling
             ``_pull_delivery_queue`` then is a wasted round-trip and may
             raise from a closed Relay.

        Body behavior preserved from the inline ``_demux_loop`` block
        pre-PR-1; control-flow keyword swapped from ``continue`` to
        ``return`` — equivalent under registry dispatch, per note below.

        Note: the inline version used ``continue`` (P22 invariant) to skip
        to the next loop iteration on stop_event. The extracted method uses
        ``return`` — equivalent in the new shape because dispatch returns
        control to the demux loop, which proceeds to the next ``async
        for`` iteration. ``test_pull_branch_keeps_loop_alive_after_skip``
        is the regression guard for this behavior; after Cluster 3 it
        inspects this method's source instead of ``_demux_loop``.
        """
        await self._initial_setup_complete.wait()
        if self._stop_event.is_set():
            return
        await self._pull_delivery_queue()

    async def _dispatch_inbound(self, inbound: "InboundMessage") -> None:
        """Route a decrypted, non-handshake application message to the agent.

        1:1 messages dispatch straight to ``_on_inbound``. Room messages
        additionally pass the mention gate — a gated-out message has already
        had its MLS state advanced and persisted by the caller, it is simply
        not surfaced — and get OC-style ``[senderName]:`` attribution so the
        LLM can tell speakers apart in a multi-party room.

        OC parity: ``channel.ts:4644-4676`` (room contextual-message build).
        """
        # action #238 — A2A: no mention gate, no roster lookup, no text
        # rewrite. ``from_hub_address`` is already a structured field on the
        # message (OC parity: A2AMessage carries fromHubAddress, not a
        # ``[sender]: `` prefix). Branch BEFORE the room check so an A2A
        # message never falls into room handling.
        if inbound.a2a_channel_id is not None:
            await self._on_inbound(inbound)
            return

        if inbound.room_id is None:
            await self._on_inbound(inbound)
            return

        # Sender resolution. When the room — or the sender's member entry —
        # is not yet in the directory (a room Welcome arrived before
        # ``room_joined`` / the connect-time poll reconciled), fall back to
        # treating the sender as a human ``[Unknown]``: the message is
        # surfaced rather than silently dropped. Accepted trade-off: during
        # that short reconciliation window an unknown *agent* sender is not
        # loop-guarded — intentional, and self-healing once the directory
        # reconciles (favor surfacing over a silent drop).
        entry = self._room_directory.get(inbound.room_id)
        member = entry.members.get(inbound.sender_device_id) if entry else None
        sender_is_agent = member.is_agent if member is not None else False
        sender_name = member.display_name if member is not None else "Unknown"

        if not should_process_room_message(
            inbound.plaintext,
            self._agent_name,
            self._account_id,
            sender_is_agent,
        ):
            logger.debug(
                "room %s: message not addressed to this agent; MLS state "
                "advanced, not dispatched",
                inbound.room_id[:8],
            )
            return

        text = strip_mentions(inbound.plaintext, self._agent_name, self._account_id)
        if not sender_is_agent:
            text = f"[{sender_name}]: {text}"
        await self._on_inbound(replace(inbound, plaintext=text))

    async def _handle_message_mls(self, envelope: "WireEnvelope") -> None:
        """MLS message frame handler.

        Decrypts the inbound MLS message, persists the resulting epoch
        advance (handshake messages must be saved too — DA #10 from
        plan §10.10), and dispatches non-handshake payloads to the
        agent surface via ``_on_inbound``.

        Lazy import: ``handle_message_mls`` lives in ``channel/inbox.py``.
        The function-local import was originally needed pre-WS-30; WS-30
        has now shipped so a module-level import is feasible. The PR-1
        refactor preserves the lazy import to keep the refactor a pure
        no-op behavior-wise; module-level promotion is a follow-up
        (filed at PR-merge time).

        Behavior preserved from the inline ``_demux_loop`` block pre-PR-1.
        """
        from agentvault_hermes.channel.inbox import handle_message_mls

        inbound = await handle_message_mls(
            envelope,
            self._mls_states,
            self._relay.device_id,
            conv_to_group_id=self._conv_to_group_id,
            send_locks=self._conv_send_locks,
        )
        if inbound is not None:
            # Persist after every successful decrypt — handshake messages
            # advance the epoch internally and MUST be saved too
            # (DA #10 from plan §10.10).
            state = self._mls_states.get(inbound.conversation_id)
            if state is not None:
                await asyncio.to_thread(
                    self._persist_state_sync,
                    inbound.conversation_id,
                    state,
                )
            # Suppress agent surface for handshake / commit messages —
            # epoch advanced internally, no payload. Application messages
            # route through _dispatch_inbound (room-aware: mention gate +
            # sender attribution for room messages).
            if not inbound.is_handshake:
                await self._dispatch_inbound(inbound)

    async def _handle_error(self, envelope: "WireEnvelope") -> None:
        """Backend error-frame handler.

        Backend rejected a previous outbound frame (bad group_id, bad
        payload hex, rate limit, etc.). action_item #177: before this
        handler existed, error events were silently dropped, masking
        deterministic protocol mismatches. WARNING surfaces in normal
        operator log views; the full data repr captures any structured
        detail the backend included.

        Behavior preserved from the inline ``_demux_loop`` block pre-PR-1.
        """
        err_data = envelope.data or {}
        detail = err_data.get("detail", "<no detail>")
        extra = {k: v for k, v in err_data.items() if k != "detail"}
        if extra:
            logger.warning(
                "Backend rejected frame: %s (extra=%r)",
                detail,
                extra,
            )
        else:
            logger.warning("Backend rejected frame: %s", detail)

    async def _handle_room_joined(self, envelope: "WireEnvelope") -> None:
        """``room_joined`` WS event handler.

        The backend fires ``room_joined`` when a room is created with this
        agent as a member, and re-fires it (identical shape) on every later
        add-member. The handler is idempotent: ``upsert_from_room_joined``
        merges, so a re-fire just refreshes name + members.

        OC parity: ``channel.ts:2823`` (``joinRoom``).
        """
        data = envelope.data or {}
        room_id = data.get("room_id")
        if not room_id:
            logger.warning("room_joined event missing room_id; ignoring")
            return
        entry = self._room_directory.upsert_from_room_joined(data)
        await asyncio.to_thread(self._room_directory.save, self._data_dir)
        logger.info(
            "room_joined: room=%s name=%r members=%d",
            str(room_id)[:8],
            entry.name,
            len(entry.members),
        )

    async def _handle_ping(self, envelope: "WireEnvelope") -> None:
        """Server-side liveness ping handler.

        Echoes a {"event":"pong"} so the backend's manager.on_pong(did)
        refreshes the Redis device:<id>:alive TTL. Without the pong, the
        backend treats us as dead despite a healthy WS, and other devices'
        message-delivery pings silently drop. Backend handler:
        packages/backend/app/api/v1/ws.py:762-764.

        Best-effort echo: if send_pong fails (e.g. WS closed mid-call), log
        at DEBUG and let the next tick recover. Behavior preserved from the
        inline ``_demux_loop`` block pre-PR-1.
        """
        try:
            await self._relay.send_pong()
        except Exception:  # noqa: BLE001 — best-effort echo
            logger.debug(
                "Failed to echo pong; relying on next tick",
                exc_info=True,
            )

    # ---------- Phase 4a PR-3: welcome-request inflight dedup -------------

    def _is_welcome_request_inflight(self, group_id: str) -> bool:
        """Return True if a request-welcome POST is currently in flight
        for the given group_id (within the TTL window).

        Side effect: evicts the entry if it has expired so subsequent
        checks short-circuit on `not in dict` instead of re-computing
        the age. Eviction is safe under asyncio single-threaded
        invariant — no `await` between dict read and `del`.

        For callers that want to atomically check-and-mark (the
        recommended pattern for "fire POST iff not inflight"), use
        ``_try_acquire_welcome_inflight`` instead.
        """
        ts = self._welcome_request_inflight.get(group_id)
        if ts is None:
            return False
        if (time.monotonic() - ts) >= self._welcome_request_inflight_ttl:
            del self._welcome_request_inflight[group_id]
            return False
        return True

    def _mark_welcome_request_inflight(self, group_id: str) -> None:
        """Record that a request-welcome POST is being fired for
        ``group_id``. Subsequent calls to ``_is_welcome_request_inflight``
        for this group return True until either the TTL expires or
        ``_clear_welcome_request_inflight`` is called.
        """
        self._welcome_request_inflight[group_id] = time.monotonic()

    def _try_acquire_welcome_inflight(self, group_id: str) -> bool:
        """Atomically acquire the inflight slot for ``group_id``.

        Returns True if the slot was free (or expired) and is now held
        by the caller; False if another caller is already inflight
        within the TTL window.

        This is the recommended entrypoint for "fire request-welcome
        POST iff not already inflight" flows. Using
        ``_is_welcome_request_inflight`` + ``_mark_welcome_request_inflight``
        as separate calls is structurally vulnerable to TOCTOU races
        if an ``await`` slips between them in a future refactor;
        ``_try_acquire_welcome_inflight`` collapses check and mark into
        a single non-awaiting operation, making the dedup invariant
        impossible to break with a refactor.

        Eviction-on-expiry side effect is preserved (same semantics as
        ``_is_welcome_request_inflight``).
        """
        ts = self._welcome_request_inflight.get(group_id)
        if ts is not None and (time.monotonic() - ts) < self._welcome_request_inflight_ttl:
            return False
        # Either no entry, or entry was expired — acquire by overwriting.
        self._welcome_request_inflight[group_id] = time.monotonic()
        return True

    def _clear_welcome_request_inflight(self, group_id: str) -> None:
        """Clear the inflight entry for ``group_id``. Idempotent — no
        error if the entry was never present (called from Welcome-
        arrival paths regardless of whether this Hermes instance was
        the one that fired the POST).
        """
        self._welcome_request_inflight.pop(group_id, None)

    async def _cold_start_recover_single_group(self, group_id: str) -> None:
        """Recover a single group: publish a fresh KP + fire upstream
        request-welcome under the inflight-dedup contract.

        Used by both ``_cold_start_scan`` (PR-3 connect-time recovery
        for lost-state groups) and ``_handle_mls_sync_response`` action=
        rejoin (PR-3 replaces PR-2's deferred log with this call).

        Dedup: the inflight slot is acquired atomically via
        ``_try_acquire_welcome_inflight`` (single non-awaiting op — TOCTOU-
        safe even if a future refactor inserts ``await`` points between
        operations). If the slot is already held within the TTL window,
        logs ``MLS_WELCOME_REQUEST_SKIPPED reason=inflight group_id=%s``
        at INFO and returns without firing. The atomic-acquire pattern
        replaces the plan's original separated check+mark per Cluster 1
        DA finding.

        Exception handling: any failure between acquire and POST clears
        the inflight entry so a retry isn't TTL-bound. The exception is
        re-raised — callers (scan + handler) wrap individual group
        recovery in try/except so one group's failure doesn't poison the
        rest of the scan. The clear runs in ``finally`` so it also fires
        for ``asyncio.CancelledError`` (BaseException, not Exception) —
        otherwise a cancelled cold-start would leak the inflight slot
        for the full TTL window and silently skip recovery on the next
        connect.

        On success the inflight entry is also cleared by the same
        ``finally`` path — the entry is no longer meaningful once the
        POST has returned. Welcome arrival is the next observable event
        and is independent of this clear; today the Welcome receive path
        does not touch ``_welcome_request_inflight`` (the synchronous
        clear here is sufficient since POST-return precedes Welcome).
        """
        if not self._try_acquire_welcome_inflight(group_id):
            logger.info(
                "MLS_WELCOME_REQUEST_SKIPPED reason=inflight group_id=%s",
                group_id,
            )
            await self._telemetry.emit(
                MlsTelemetryEvent(
                    event=MlsTelemetryEventType.WELCOME_REQUEST_SKIPPED,
                    group_id=group_id,
                    context={"reason": "inflight"},
                )
            )
            return
        try:
            # Phase 4b PR-A1 Task 3: emit COLD_START_RECOVERING at the
            # start of every recovery attempt (both `_cold_start_scan` and
            # `_handle_mls_sync_response` rejoin paths land here). Context
            # is intentionally empty: this method has no `scan_run_id`
            # parameter and is also called from the rejoin path which is
            # outside any scan. Operators correlate by group_id +
            # timestamp; fabricating a fresh run_id would be misleading.
            await self._telemetry.emit(
                MlsTelemetryEvent(
                    event=MlsTelemetryEventType.COLD_START_RECOVERING,
                    group_id=group_id,
                    context={},
                )
            )
            await self._ensure_pending_key_package()
            # Lazy import — _fire_request_welcome is a module-level
            # function in channel/inbox.py. The lazy pattern was
            # preserved through PR-1; module-level promotion is a
            # separate follow-up.
            from agentvault_hermes.channel.inbox import _fire_request_welcome
            await _fire_request_welcome(
                rest_base_url=self._relay.rest_base_url,
                device_jwt=self._relay.device_jwt,
                group_id=group_id,
                own_device_id=self._relay.device_id,
            )
        finally:
            # Clear inflight on EVERY exit path (success, exception,
            # cancellation) so retry isn't TTL-bound under any failure
            # mode. (DA Cluster 2 finding: explicit except+else would
            # not catch CancelledError.)
            self._clear_welcome_request_inflight(group_id)

    async def _cold_start_scan(self) -> None:
        """Iterate known groups; for any with `has_local_state=False`,
        publish a fresh KP + fire request-welcome via
        ``_cold_start_recover_single_group``.

        Per OC channel.ts:2276-2320 (sync-fallback path). Runs in
        Phase A of the strict 3-phase startup ordering — BEFORE
        ``_send_initial_sync`` (Phase B) and the demux loop spawn
        (Phase C). Phase A runs first so lost-state groups recover
        BEFORE we send sync frames for them (which would send
        ``last_epoch=None`` and confuse the backend's replay path).

        Populates ``self._known_group_ids`` snapshot here (PR-3 move
        from `_send_initial_sync`) so the cached set covers BOTH
        intact-state groups (for `_handle_mls_sync_response` validation)
        AND lost-state groups (so a `rejoin` response for a lost-state
        group is recognized).

        Error handling per spec:
          - Iterator raises (e.g. corrupt local DB) → log
            `MLS_COLD_START_PERSISTENCE_FAIL scan_run_id=%d` at ERROR;
            return. Operator-intervention territory. DOES NOT advance
            to `_send_initial_sync` since both flows share the same
            iterator.
          - `_cold_start_recover_single_group` raises for a group →
            log `MLS_COLD_START_FAIL group_id=%s step=request_welcome
            scan_run_id=%d` at WARN; skip group; continue.
          - Consecutive failures threshold reached → log
            `MLS_COLD_START_ABORT reason=consecutive_failures
            scan_run_id=%d threshold=%d` at ERROR; return.
        """
        scan_run_id = next(self._sync_run_counter)
        try:
            known_groups = list(self._iter_known_groups())
        except Exception:
            logger.exception(
                "MLS_COLD_START_PERSISTENCE_FAIL scan_run_id=%d",
                scan_run_id,
            )
            # Clear the snapshot on iterator-failure so a stale set from
            # a previous connect doesn't drive admission decisions in
            # `_handle_mls_sync_response`. (DA Cluster 3 finding: after
            # Cluster 4 removes the redundant populate in
            # `_send_initial_sync`, this branch is the only protection
            # against carrying forward stale group_ids.)
            #
            # Clear the snapshot BEFORE emitting telemetry. Emit is an
            # `await` point — yielding to the event loop with a stale
            # `_known_group_ids` would re-open the race that DA Cluster 3
            # (Phase 4a PR-3) closed, because a concurrent
            # `_handle_mls_sync_response` rejoin handler reads
            # `_known_group_ids` for admission checks. Telemetry is
            # operator-visibility; the synchronous state clear is the
            # safety invariant. Do the safety invariant first.
            self._known_group_ids = frozenset()
            await self._telemetry.emit(
                MlsTelemetryEvent(
                    event=MlsTelemetryEventType.COLD_START_PERSISTENCE_FAIL,
                    group_id=None,
                    context={"scan_run_id": scan_run_id},
                )
            )
            return
        # Move from PR-2: populate _known_group_ids HERE so the snapshot
        # covers lost-state groups too (closes the Welcome-mid-sync race
        # documented in PR-2's `_handle_mls_sync_response`).
        self._known_group_ids = frozenset(
            kg.group_id for kg in known_groups
        )

        # `consecutive_failures` tracks recovery POST failures only.
        # Intact-state groups (has_local_state=True) are skipped via
        # `continue` below and are intentionally NEITHER counted as a
        # failure NOR a success-reset — they're operator-orthogonal
        # signal. A run like [fail, fail, intact, fail] therefore trips
        # the threshold on the 4th iteration because the intact skip
        # doesn't reset the counter. This is the OC channel.ts:2276-2320
        # parity semantic: only recovery attempts count.
        consecutive_failures = 0
        for kg in known_groups:
            if kg.has_local_state:
                continue  # PR-2's _send_initial_sync handles this
            try:
                await self._cold_start_recover_single_group(kg.group_id)
                consecutive_failures = 0
            except Exception as exc:  # noqa: BLE001 — per-group skip path
                consecutive_failures += 1
                logger.warning(
                    "MLS_COLD_START_FAIL group_id=%s step=request_welcome "
                    "scan_run_id=%d error=%s",
                    kg.group_id,
                    scan_run_id,
                    exc,
                )
                await self._telemetry.emit(
                    MlsTelemetryEvent(
                        event=MlsTelemetryEventType.COLD_START_FAIL,
                        group_id=kg.group_id,
                        context={
                            "step": "request_welcome",
                            "scan_run_id": scan_run_id,
                            "error_class": type(exc).__name__,
                        },
                    )
                )
                if (
                    consecutive_failures
                    >= self._consecutive_failures_threshold
                ):
                    logger.error(
                        "MLS_COLD_START_ABORT reason=consecutive_failures "
                        "scan_run_id=%d threshold=%d",
                        scan_run_id,
                        self._consecutive_failures_threshold,
                    )
                    await self._telemetry.emit(
                        MlsTelemetryEvent(
                            event=MlsTelemetryEventType.COLD_START_ABORT,
                            group_id=None,
                            context={
                                "reason": "consecutive_failures",
                                "scan_run_id": scan_run_id,
                                "threshold": self._consecutive_failures_threshold,
                            },
                        )
                    )
                    return

    # ---------- end Phase 4a PR-3 -----------------------------------------

    def _iter_known_groups(self) -> Iterator[KnownGroup]:
        """Yield every group this Hermes instance is tracking for MLS sync.

        Three iterations in OC parity order (``channel.ts:2689-2733``):
          1. 1:1 conversations from ``self._mls_states``.
          2. Multi-party rooms (action #234) — every ``RoomDirectory`` entry
             with a recorded ``mls_group_id`` AND a live ``_mls_states``
             entry is yielded as a ``group_type="room"`` ``KnownGroup``.
          3. A2A channels — Phase 3 uses ``lock_file``, not MLS; iteration
             is a forward-parity stub that yields nothing today.

        The 3-iteration structure exists so PR-2 emits the correct shape
        from day one. When A2A migrates to MLS in a future phase, only the
        body of iteration 3 needs to grow.
        """
        # Iteration 1: 1:1 conversations (real data today)
        # Snapshot via list() to avoid `RuntimeError: dictionary changed
        # size during iteration` — Welcome / commit handlers can mutate
        # `_mls_states` concurrently on the same event loop while Cluster 2's
        # `_send_initial_sync` awaits between yields. (DA finding #3.)
        for conv_id, state in list(self._mls_states.items()):
            # Rooms live in _mls_states keyed by room_id; iteration 2 owns
            # them. Skip here so a joined room is not yielded twice.
            if self._room_directory.get(conv_id) is not None:
                continue
            # action #238: same shape for A2A — A2A channels live in
            # _mls_states keyed by a2a_channel_id; iteration 3 owns them.
            if self._a2a_registry.get(conv_id) is not None:
                continue
            # `MlsGroupState.epoch` is the real epoch accessor (see
            # crypto/mls_group.py:427 — explicit `_epoch` counter, NOT a
            # `last_epoch` attribute that does not exist). Tolerate
            # uninitialized states — they should not appear in
            # `_mls_states` normally, but we never want to crash the
            # iterator over a degraded state. (DA finding #1.)
            try:
                last_epoch: int | None = state.epoch
            except Exception:  # noqa: BLE001 — defensive: any access failure → None
                last_epoch = None
            # Resolve the wire-format MLS group_id from `_conv_to_group_id`.
            # `_mls_states` is keyed by conversation_id; the backend's
            # `mls_sync` handler expects the MLS group_id. (DA finding #2.)
            group_id_str = self._conv_to_group_id.get(conv_id)
            if group_id_str is None:
                logger.warning(
                    "MLS_SYNC_KNOWN_GROUP_NO_GROUP_ID conv_id=%s — "
                    "skipping; conv has MlsGroupState but no group_id "
                    "mapping",
                    conv_id,
                )
                continue
            yield KnownGroup(
                group_id=group_id_str,
                group_type="1to1",
                last_epoch=last_epoch,
                since_ts=None,
                has_local_state=True,
            )
        # Iteration 2: rooms (action #234). A room MLS group is keyed in
        # _mls_states by room_id; the wire-format group_id lives on the
        # RoomDirectory entry. Only rooms with both a recorded MLS group
        # and live local state are sync-eligible.
        for entry in self._room_directory.all():
            if entry.mls_group_id is None:
                continue
            # Distinct name from iteration 1's `state` loop variable: dict
            # `.get()` returns Optional, and reusing `state` (bound non-Optional
            # above) is a mypy assignment-type error.
            room_state = self._mls_states.get(entry.room_id)
            if room_state is None:
                continue
            try:
                room_epoch: int | None = room_state.epoch
            except Exception:  # noqa: BLE001 — defensive: any access failure -> None
                room_epoch = None
            yield KnownGroup(
                group_id=entry.mls_group_id,
                group_type="room",
                last_epoch=room_epoch,
                since_ts=None,
                has_local_state=True,
            )
        # Iteration 3: A2A channels (action #238). Yield every joined A2A
        # group so it gets mls_sync + cold-start coverage like 1:1 and rooms.
        # An A2A MLS group is keyed in ``_mls_states`` by the bare
        # ``a2a_channel_id`` (Task 4's Welcome routing). Only channels with
        # both a recorded MLS group AND live local state are sync-eligible.
        for a2a_entry in self._a2a_registry.all():
            if a2a_entry.mls_group_id is None:
                continue
            a2a_state = self._mls_states.get(a2a_entry.a2a_channel_id)
            if a2a_state is None:
                continue
            try:
                a2a_epoch: int | None = a2a_state.epoch
            except Exception:  # noqa: BLE001 — defensive: any access failure -> None
                a2a_epoch = None
            yield KnownGroup(
                group_id=a2a_entry.mls_group_id,
                group_type="a2a",
                last_epoch=a2a_epoch,
                since_ts=None,
                has_local_state=True,
            )

    async def _send_initial_sync(self) -> None:
        """Emit one ``event:"mls_sync"`` per known group with intact
        local state.

        Per OC channel.ts:2689-2733. Three iterations (1:1, rooms,
        A2A); Phase 3 only has 1:1 groups in MLS so rooms/A2A
        iteration is a forward-parity no-op today.

        Called after ``await self._relay.connect()`` in both ``start()``
        and ``_schedule_reconnect()`` (Cluster 4) so every fresh WS
        attach triggers a catch-up exchange with the backend.

        Lost-state groups (``has_local_state=False``) are skipped here —
        PR-3's ``_cold_start_scan`` handles those via proactive
        request-welcome POST.

        Wire frames flow through ``Relay.send_json`` — the generic
        dict-shaped send (PR-2 added it; same underlying ``WsClient.
        send_json`` used by ``send_pong`` / ``send_message``).

        Error handling per spec:
          - ``relay.send_json`` raises for one group → log
            ``MLS_SYNC_EMIT_FAIL group_id=<id> sync_run_id=<n>``;
            skip group; continue.
          - ``_consecutive_failures_threshold`` reached → log
            ``MLS_SYNC_ABORT reason=consecutive_failures
            sync_run_id=<n>`` at ERROR; return.
          - ``_iter_known_groups`` raises → log
            ``MLS_SYNC_ABORT reason=iterator_failed sync_run_id=<n>``
            at ERROR; return.

        ``_known_group_ids`` is populated by ``_cold_start_scan``
        (Phase A) — NOT here. See PR-3 plan + spec for rationale.
        """
        sync_run_id = next(self._sync_run_counter)
        # Materialize the iterator ONCE so we get a consistent snapshot
        # for emission. Two separate calls to _iter_known_groups() could
        # produce different sets if a Welcome lands between them
        # (mutating _mls_states). (DA finding 2026-05-13.)
        try:
            known_groups = list(self._iter_known_groups())
        except Exception:
            logger.exception(
                "MLS_SYNC_ABORT reason=iterator_failed sync_run_id=%d",
                sync_run_id,
            )
            await self._telemetry.emit(
                MlsTelemetryEvent(
                    event=MlsTelemetryEventType.SYNC_ABORT,
                    group_id=None,
                    context={"reason": "iterator_failed", "sync_run_id": sync_run_id},
                )
            )
            return
        # _known_group_ids is populated by _cold_start_scan (Phase A),
        # which runs BEFORE this method per the strict 3-phase startup
        # ordering. We rely on that populate; do NOT re-populate here.
        # See PR-3 plan + spec for the move rationale (closes the
        # Welcome-mid-sync race documented in PR-2's
        # _handle_mls_sync_response).

        consecutive_failures = 0
        for kg in known_groups:
            if not kg.has_local_state:
                # PR-3's `_cold_start_scan` owns the lost-state path
                continue
            payload: dict[str, Any] = {
                "event": "mls_sync",
                "group_id": kg.group_id,
                "last_epoch": kg.last_epoch,
            }
            if kg.since_ts is not None:
                payload["since_ts"] = kg.since_ts
            try:
                # Relay.send_json is the generic dict-shaped send
                # (added in PR-2 alongside `_send_initial_sync`).
                await self._relay.send_json(payload)
                self._sync_in_progress[kg.group_id] = time.monotonic()
                consecutive_failures = 0
            except Exception as exc:  # noqa: BLE001 — per-group skip path
                consecutive_failures += 1
                logger.warning(
                    "MLS_SYNC_EMIT_FAIL group_id=%s sync_run_id=%d "
                    "error=%s",
                    kg.group_id,
                    sync_run_id,
                    exc,
                )
                await self._telemetry.emit(
                    MlsTelemetryEvent(
                        event=MlsTelemetryEventType.SYNC_EMIT_FAIL,
                        group_id=kg.group_id,
                        context={"sync_run_id": sync_run_id, "error_class": type(exc).__name__},
                    )
                )
                if (
                    consecutive_failures
                    >= self._consecutive_failures_threshold
                ):
                    logger.error(
                        "MLS_SYNC_ABORT reason=consecutive_failures "
                        "sync_run_id=%d threshold=%d",
                        sync_run_id,
                        self._consecutive_failures_threshold,
                    )
                    await self._telemetry.emit(
                        MlsTelemetryEvent(
                            event=MlsTelemetryEventType.SYNC_ABORT,
                            group_id=None,
                            context={
                                "reason": "consecutive_failures",
                                "sync_run_id": sync_run_id,
                                "threshold": self._consecutive_failures_threshold,
                            },
                        )
                    )
                    return

    async def _demux_loop(self) -> None:
        """Pull inbound frames; dispatch via ``WSEventRegistry``.

        OC parity: ``channel.ts:2742-3169``.

        Every successful inbound frame stamps ``self._last_inbound_ts`` so the
        silence-timeout task knows the WS is alive. The server's
        ``event:"ping"`` frames also count as liveness — we do NOT echo them
        (per plan §3.4.1; AV's WS protocol expects no agent-side keepalives).

        Per-event dispatch is delegated to ``self._event_registry`` (PR-1,
        Phase 4a). The registry catches handler exceptions and logs them at
        WARN with a payload hash, so a single bad frame does not crash the WS
        demux. ``CancelledError`` propagates through the registry so
        ``stop()`` can tear the loop down. The outer try/except around the
        receive iterator handles WS-level errors (NORMAL_CLOSURE, network
        drops, cancel-scope errors) by scheduling a reconnect with backoff.
        """
        # Outer loop survives a ``_schedule_reconnect`` cycle — the inner
        # ``async for`` terminates when the OLD ``WsClient.receive_json``
        # iterator ends (because ``_relay.disconnect`` cleared ``self._ws``).
        # After ``_relay.connect`` opens a NEW WsClient we re-attach the
        # iterator so demux continues. Without this, a silence-triggered
        # reconnect would silently stop processing inbound traffic — the
        # bug surfaces as "Bobby went mute" with no error.
        consecutive_failures = 0
        while not self._stop_event.is_set():
            try:
                receive_iterator = self._relay.receive_messages()
            except RuntimeError:
                # ``Relay.receive_messages`` raises when not connected. The
                # silence-timeout task is responsible for kicking a reconnect;
                # we wait one tick and re-check ``_stop_event`` rather than
                # spinning.
                try:
                    await asyncio.sleep(_PING_INTERVAL_SECONDS)
                except asyncio.CancelledError:
                    raise
                continue
            # Wrap the inner receive loop so a WS-level exception (e.g. a
            # NORMAL_CLOSURE 1000 from the backend, a network drop, an
            # httpx_ws cancel-scope error) doesn't kill the demux task.
            # On error, we schedule a reconnect; the outer ``while`` then
            # re-attaches via ``self._relay.receive_messages()`` once the
            # new ``Relay`` is connected.
            # ``event_type`` is initialized BEFORE the ``async for`` so the
            # outer ``except`` block always has it in scope — even if the
            # receive iterator fails before yielding any envelope this
            # attach. Without this sentinel, the WS-level error log would
            # raise ``NameError`` on the first-frame failure path. ``None``
            # renders as ``None`` via ``%r`` — the correct operator signal
            # that no envelope was processed before the failure.
            event_type: Optional[str] = None
            try:
                async for envelope in receive_iterator:
                    consecutive_failures = 0  # reset on a healthy frame
                    if self._stop_event.is_set():
                        break
                    self._last_inbound_ts = time.monotonic()
                    event_type = envelope.event
                    # Per-handler exception isolation, CancelledError
                    # propagation, and unknown-event DEBUG fallthrough are
                    # the WSEventRegistry's contract (see
                    # ``event_registry.py``). No outer try/except needed
                    # here.
                    #
                    # CONTRACT: dispatch() MUST be the last action inside
                    # this ``async for`` body. ``_handle_mls_delivery``'s
                    # skip-on-stop_event uses ``return`` (equivalent to the
                    # pre-PR-1 inline ``continue``) only because nothing
                    # per-event runs after dispatch. If you add a per-event
                    # side-effect (metrics, logging, etc.) after this line,
                    # ``_handle_mls_delivery``'s skip-on-stop semantics
                    # SILENTLY break. Wrap it in a separate phase or move
                    # the side-effect into the handler.
                    await self._event_registry.dispatch(event_type, envelope)
            except asyncio.CancelledError:
                raise
            except Exception:
                consecutive_failures += 1
                # ``last_event`` is the event_type of the last successfully
                # received envelope this attach (or ``None`` if the iterator
                # failed before yielding anything). Pre-PR-1 the inline
                # demux logged ``event=%r`` here; preserving that operator
                # context is DA finding #2 (Cluster 3, PR-1, Phase 4a).
                logger.warning(
                    "Demux: WS-level error in receive iterator (failure "
                    "%d, last_event=%r); scheduling reconnect",
                    consecutive_failures,
                    event_type,
                    exc_info=True,
                )
                # Best-effort reconnect. _schedule_reconnect tears down the
                # current Relay (closing the WS) and rebuilds it; the
                # outer ``while`` then re-attaches the iterator on the new
                # Relay. Without this, a backend-initiated NORMAL_CLOSURE
                # 1000 (or any other transient WS error) would kill the
                # demux task and we'd silently stop processing inbound
                # traffic.
                await self._schedule_reconnect()
                # Backoff before re-iterating. Without this, a permanently
                # broken WS (or a test mock that re-raises) creates a
                # tight reconnect loop that starves the asyncio scheduler
                # — see ``test_demux_loop_survives_relay_reconnect``.
                # ``asyncio.sleep`` yields to the loop unconditionally.
                backoff = min(0.1 * (2 ** (consecutive_failures - 1)), 30.0)
                try:
                    await asyncio.sleep(backoff)
                except asyncio.CancelledError:
                    raise

    async def _silence_timeout_task(self) -> None:
        """Watch for >90s of inbound silence; schedule reconnect on timeout.

        OC parity: ``channel.ts:205-210``. We do NOT send outbound pings —
        the AV backend pings us, we just check for silence (plan §3.4.1).

        Implementation note: ``asyncio.sleep`` ticks every 30s. After a
        successful reconnect schedule, we reset ``_last_inbound_ts`` so the
        next tick does not double-fire while the new WS handshake is in
        progress.

        ``CancelledError`` propagates; other exceptions are logged and the
        loop continues — a single transient error must not silently kill
        liveness monitoring.
        """
        while not self._stop_event.is_set():
            try:
                await asyncio.sleep(_PING_INTERVAL_SECONDS)
                if self._stop_event.is_set():
                    break
                silence = time.monotonic() - self._last_inbound_ts
                if silence > _SILENCE_TIMEOUT_SECONDS:
                    logger.warning(
                        "WS silence %.1fs > %.1fs threshold — scheduling reconnect",
                        silence,
                        _SILENCE_TIMEOUT_SECONDS,
                    )
                    reconnected = await self._schedule_reconnect()
                    # Reset the clock ONLY if the reconnect actually
                    # succeeded. If it failed, the next tick must still
                    # see the original silence so we re-attempt — without
                    # this gate a failing reconnect would buy us another
                    # 90s of unobserved dead WS before the next try.
                    if reconnected:
                        self._last_inbound_ts = time.monotonic()
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001 — keep liveness alive
                logger.warning("Silence-timeout task error: %s", e)

    async def _poll_fallback_task(self) -> None:
        """Phase 3 no-op stub.

        OC parity: ``channel.ts:6447-6560``. When the WS is wedged (state
        ``RECONNECTING`` for >60s), OC pulls unread messages via REST. Phase 3
        ships a no-op; WS-30.x will wire this up properly.

        Returns immediately — the task completes successfully and is removed
        from ``_background_tasks`` via the ``add_done_callback`` discard.
        """
        # TODO(WS-30.x): poll REST when WS state is RECONNECTING for >60s.
        # See plan §0 out-of-scope.
        return

    async def _trust_token_refresh_task(self) -> None:
        """Phase 3 no-op stub.

        OC parity: ``channel.ts:1617-1631``. Calls
        ``/api/v1/devices/{id}/refresh`` on cadence to renew the device JWT.

        WS-28.0 verified the device JWT TTL is 90 days — far longer than any
        single Phase 3 demo session — so deferring this is safe through
        launch. Post-launch, this task should call refresh on a 12h cadence
        and update the in-memory ``device_jwt`` reference.

        Returns immediately. See plan §19.4 for follow-up tracking.
        """
        # TODO(post-launch): periodic refresh per plan §19.4.
        return

    async def _schedule_reconnect(self) -> bool:
        """Phase 3 minimal reconnect scheduler.

        OC parity: ``channel.ts:6388-6430``. The full implementation handles
        exponential backoff with a 60s ceiling, jitter, and reconnect-storm
        suppression. Phase 3 ships a minimal version that disconnects and
        reconnects the relay; full reconnect-storm handling is Phase 3.x
        follow-up.

        Errors during reconnect are logged but not raised — the silence-timeout
        task that triggered us must continue running so a follow-up reconnect
        attempt can fire on the next tick.

        Order (P21): cancel any in-flight ``_republish_task`` BEFORE the new
        socket opens. Otherwise the in-flight republish's httpx call would
        keep ``_kp_publish_lock`` held and the next ``start()`` would block
        for the full P26 timeout window.

        Returns:
            ``True`` if ``Relay.connect()`` succeeded; ``False`` otherwise.
            The caller (silence-timeout) uses this to decide whether to
            reset the inbound-silence clock — a failed reconnect must NOT
            reset the clock or we'd buy ourselves another 90s of unobserved
            dead WS before the next attempt.
        """
        # P21: cancel-and-wait BEFORE disconnect/connect cycle.
        await self._cancel_republish_task()
        try:
            await self._relay.disconnect()
        except Exception:  # noqa: BLE001 — best-effort
            logger.warning(
                "Reconnect: disconnect raised, continuing to reconnect", exc_info=True
            )
        try:
            await self._relay.connect()
            # Phase 4a PR-3: cold-start scan (Phase A) on reconnect.
            # Runs BEFORE _send_initial_sync (Phase B) per strict
            # 3-phase ordering.
            await self._cold_start_scan()
            # Phase 4a PR-2: emit initial mls_sync per known group on
            # reconnect. Same semantics as start() — runs in Phase B.
            await self._send_initial_sync()
            return True
        except Exception:  # noqa: BLE001 — let liveness retry next tick
            logger.warning(
                "Reconnect: connect raised, will retry on next silence tick",
                exc_info=True,
            )
            return False

    def _persist_state_sync(self, conv_id: str, state: "MlsGroupState") -> None:
        """Synchronous persistence helper. Called via ``asyncio.to_thread``.

        Writes ``mls_state.bin`` ATOMICALLY (tempfile + ``os.replace``, mode
        0o600) and updates ``meta.json`` with the current ``last_message_ts``.

        Critical invariants (each closes a real silent-corruption mode the
        WS-28b DA reviewer caught):

        1. **Atomic write** — a crash mid-write must NOT leave a truncated
           ``mls_state.bin``. ``import_state`` would raise on truncation
           and the conversation would be permanently broken. Mirror
           ``crypto/persistence.py:write_meta``: write to ``.tmp`` + chmod
           + ``os.replace`` (atomic on POSIX).
        2. **Mode 0o600 enforced** — ``Path.write_bytes`` honors umask,
           which on most systems would land at 0o644. We chmod explicitly.
        3. **UUID canonicalization** — ``write_meta`` canonicalizes the
           conv_id to lowercase string-form internally; if we use raw
           ``conv_id`` for the bin path, an uppercase UUID input lands
           the bin and the meta in DIFFERENT directories. Canonicalize at
           the top so both paths agree.
        4. **Stale meta tolerance** — a corrupted ``meta.json`` from an
           earlier crash must NOT escape ``read_meta`` after the in-memory
           ratchet has advanced AND the bin has been written. Catching
           ``ValueError`` lets the next persist replace the meta cleanly
           rather than wedging the conversation.
        5. **Defensive chmod on existing dirs** — ``mkdir(mode=0o700)``
           is a no-op when the dir already exists. If a prior process ran
           with a weaker umask, we chmod defensively to match the docstring
           guarantee.

        Kept synchronous because ``MlsGroupState.export_state`` and
        ``write_meta`` are sync; the whole helper is wrapped in
        ``asyncio.to_thread`` at the call site (DA #10 hygiene), so the
        event loop is not blocked on slow filesystems.
        """
        import os

        from agentvault_hermes.crypto.persistence import (
            ConversationMeta,
            read_meta,
            write_meta,
        )

        # Canonicalize the conv_id to UUID-string form so the bin path and
        # meta path agree (write_meta string-formats via str(uuid)).
        try:
            conv_uuid = UUID(conv_id)
        except ValueError:
            logger.warning(
                "Skipping persist — conv_id %r is not a valid UUID",
                conv_id,
            )
            return
        canonical_conv_id = str(conv_uuid)

        conv_dir = self._data_dir / "conversations" / canonical_conv_id
        conv_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        # Defensive chmod — mkdir(mode=0o700) is a no-op on existing dirs;
        # ensure the perms match the docstring guarantee even if a prior
        # process or test left them weaker.
        try:
            os.chmod(conv_dir, 0o700)
        except OSError:
            logger.debug(
                "Could not chmod %s to 0o700 — continuing", conv_dir, exc_info=True
            )

        bin_path = conv_dir / "mls_state.bin"
        tmp_path = conv_dir / "mls_state.bin.tmp"
        # Write to tempfile, chmod, then atomic-replace. Any crash before
        # os.replace leaves the OLD bin intact (or absent on first write,
        # in which case the next send re-tries cleanly).
        try:
            tmp_path.write_bytes(state.export_state())
            os.chmod(tmp_path, 0o600)
            os.replace(tmp_path, bin_path)
        except Exception:
            # Best-effort cleanup of the tempfile on failure.
            try:
                if tmp_path.exists():
                    tmp_path.unlink()
            except OSError:
                pass
            raise

        # Preserve created_at across rewrites so the meta is monotonic.
        # Tolerate a corrupted meta.json (ValueError) — by this point the
        # ratchet has already advanced AND the bin has been written, so
        # bailing here would wedge the conversation. Treat unparseable
        # meta as "no prior meta" and overwrite.
        try:
            existing = read_meta(self._data_dir, conv_uuid)
        except (ValueError, OSError):
            logger.warning(
                "meta.json for %s unreadable — overwriting with fresh meta",
                canonical_conv_id,
                exc_info=True,
            )
            existing = None
        now = datetime.now(timezone.utc)
        meta = ConversationMeta(
            conversation_id=conv_uuid,
            type=existing.type if existing is not None else "direct",
            created_at=existing.created_at if existing is not None else now,
            last_message_ts=now,
        )
        write_meta(self._data_dir, conv_uuid, meta)

    async def _ensure_pending_key_package(self) -> None:
        """Generate + publish a fresh MLS KeyPackage iff ``_pending_kp_state`` is None.

        OC parity: ``packages/plugin/src/channel.ts:2655-2678`` (KP publish on
        connect). Hermes diverges from OC's *after-Welcome* re-publish posture
        by also calling this from a fire-and-forget background task in
        Stage 4's pull-queue dispatcher (plan §3.3 P3 + P16) so back-to-back
        conv-creates don't starve the backend KP pool.

        Called from:
          1. ``start()`` — initial connect.
          2. ``handle_mls_welcome`` (Stage 4) — after every successful join,
             via a fire-and-forget background task tracked on
             ``self._republish_task``.

        Idempotent: if ``_pending_kp_state`` is already populated this is a
        no-op (Seam A guard). The in-memory guard is what protects the
        steady state — the published KP itself is not "still valid"
        across reconnect because the backend deletes ALL prior packages on
        every successful publish (``mls_key_package_service.py:26-28``).

        On any exception during publish, leave ``_pending_kp_state = None``
        so a retry can proceed. The newly-allocated MlsGroupState is
        garbage-collected; mls_rs's storage is in-process and does not
        leak across instances.

        Caller-side concurrency: callers acquire ``_kp_publish_lock`` to
        serialize concurrent attempts — see ``start()`` (under the lock,
        P26 timeout) and Stage 4's republish task (under the same lock).
        """
        if self._pending_kp_state is not None:
            return

        # Local import to avoid a module-load-time dependency on mls_rs_uniffi
        # — keeps ``import agentvault_hermes.channel.secure_channel`` cheap
        # in test contexts that mock the crypto layer.
        from agentvault_hermes.core.transport.rest_client import RestClient
        from agentvault_hermes.crypto.mls_group import MlsGroupState

        state = MlsGroupState(
            device_keys=self._device_keys,
            device_id=self._device_id,
        )
        kp_bytes = state.generate_key_package()
        kp_hex = kp_bytes.hex()

        # Plan defect note (Stage 2 surface): SecureChannel was not
        # previously wired to a RestClient; Relay holds ``rest_base_url`` +
        # ``device_jwt`` and the rest of the codebase constructs RestClient
        # ad-hoc via the standard async-context-manager pattern (cli/setup,
        # cli/doctor). We follow that pattern here rather than expanding
        # the SecureChannel constructor signature beyond the P11 spec.
        async with RestClient(
            base_url=self._relay.rest_base_url,
            device_jwt=self._relay.device_jwt,
        ) as client:
            await client.publish_key_package(kp_hex)

        # Only commit ``_pending_kp_state`` AFTER the publish succeeds. If
        # publish raised, _pending_kp_state stays None and a retry can
        # repopulate it cleanly on the next call.
        self._pending_kp_state = state

        # action_item #159 — operator visibility on the Phase 3 success
        # paths. Pre-#159 the success path was silent and operators had
        # to grep for absence-of-ERROR to verify health. Single INFO line
        # per publish keeps the steady-state log volume bounded (one per
        # reconnect cycle or post-Welcome republish).
        logger.info(
            "MLS KeyPackage published (account=%s, kp_len=%d)",
            self._account_id,
            len(kp_hex) // 2,
        )

    async def _poll_rooms(self) -> None:
        """Reconcile the RoomDirectory against ``GET /api/v1/rooms``.

        Runs on every connect/reconnect so a room the agent was added to
        while offline — and thus missed the ``room_joined`` event for —
        still surfaces. Best-effort: a failed poll logs at WARNING and
        leaves the directory unchanged (the Welcome path and ``room_joined``
        independently repopulate).

        Since this runs on the connect path before the demux loop spawns,
        the GET is bounded at 5s via ``asyncio.wait_for``. A timeout is
        handled as a best-effort failure — the directory was already
        loaded from disk in ``start()`` — so a slow ``/rooms`` endpoint
        degrades only the reconcile, not the whole connect.

        Note: ``RestClient.get`` is annotated ``-> dict`` but FastAPI
        serializes the ``list[RoomListItem]`` response as a JSON array, so
        the runtime value is a ``list``. The isinstance guard handles it.
        """
        try:
            from agentvault_hermes.core.transport.rest_client import RestClient

            async with RestClient(
                base_url=self._relay.rest_base_url,
                device_jwt=self._relay.device_jwt,
            ) as client:
                rooms = await asyncio.wait_for(
                    client.get("/api/v1/rooms"), timeout=5.0
                )
        except Exception as exc:  # noqa: BLE001 — best-effort reconcile
            logger.warning("room poll failed: %s; directory unchanged", exc)
            return
        if not isinstance(rooms, list):
            logger.warning(
                "room poll: unexpected response shape %s; skipping",
                type(rooms).__name__,
            )
            return
        for item in rooms:
            try:
                self._room_directory.upsert_from_poll(item)
            except (KeyError, TypeError) as exc:
                logger.warning("room poll: skipping malformed item: %s", exc)
        await asyncio.to_thread(self._room_directory.save, self._data_dir)
        # Suppress the success log on an empty reconcile to keep noise low
        # during steady-state reconnects (sibling: _pull_delivery_queue).
        if rooms:
            logger.info("room poll: reconciled %d room(s)", len(rooms))

    async def _pull_delivery_queue(self) -> None:
        """Pull MLS delivery rows; sort welcome→commit→application; dispatch.

        P17 CONTRACT: republish-after-Welcome is FIRE-AND-FORGET. On a row
        whose handler returns ``WelcomeOutcome(joined=True)``, Stage 4 will
        schedule republish as a background task on ``self._republish_task``
        and proceed to the next row WITHOUT awaiting completion. Stage 3
        ships with a stub welcome handler that returns
        ``WelcomeOutcome(joined=False, drop=True)`` so this function's
        sort/dispatch/ack mechanics can be exercised before the real
        handler lands.

        OC parity (channel.ts:5061-5106 _pullDeliveryQueue + :5079-5086
        priority sort with welcome=0/commit=1/application=2). OC does NOT
        republish from inside _handleMlsWelcome — Hermes diverges (P3) so
        back-to-back conv-creates don't starve the backend KP pool.

        Re-entrant guard: ``self._delivery_pulling``. Concurrent calls
        (ping-driven + on-connect + future heartbeat) NOOP the second
        caller; we don't queue overlapping pulls.

        Phase 3 row-type disposition:

        - ``welcome`` → ``handle_mls_welcome`` (Stage 4 real, Stage 3 stub).
        - ``commit`` → log-warning + ack-and-drop (P12). 1:1 commits don't
          surface in production today; backend only emits ``mls_commit``
          push on the ``mls_sync`` replay path which is OOS for Phase 3.
          Phase 4 reintroduces (action_item #155).
        - ``application`` → existing ``handle_message_mls`` path; persist
          on returned InboundMessage; surface to ``_on_inbound`` for
          non-handshake.
        - unknown ``message_type`` → log + ack (don't dead-letter).

        Own-echo skip (sender_device_id == own device): ack without
        invoking any handler.
        """
        if self._delivery_pulling:
            return
        self._delivery_pulling = True
        try:
            # Lazy imports — channel.inbox lives in the same layer; keep
            # the import local so circular-imports don't surface during
            # module load. RestClient is also lazy so test contexts that
            # mock the crypto layer don't drag the httpx dependency at
            # import time.
            from agentvault_hermes.channel.inbox import (  # type: ignore[import-not-found,import-untyped,unused-ignore]
                handle_message_mls,
                handle_mls_welcome,
            )
            from agentvault_hermes.channel.outbox import WireEnvelope
            from agentvault_hermes.core.transport.rest_client import RestClient

            device_id_str = str(self._device_id)
            async with RestClient(
                base_url=self._relay.rest_base_url,
                device_jwt=self._relay.device_jwt,
            ) as rest:
                rows = await rest.pull_mls_delivery(device_id_str)
                if not rows:
                    return

                # action_item #159 — operator visibility on the delivery-pull
                # success path. Counts only emitted when rows>0 to keep
                # noise low during steady-state polling. Per-message-type
                # breakdown lets operators correlate "Welcome arrived" with
                # the join-success log in handle_mls_welcome below.
                _mt_counts: dict[str, int] = {}
                for _row in rows:
                    _mt = str(_row.get("message_type") or "unknown")
                    _mt_counts[_mt] = _mt_counts.get(_mt, 0) + 1
                logger.info(
                    "MLS delivery pull: %d row(s) received (account=%s, by_type=%s)",
                    len(rows),
                    self._account_id,
                    _mt_counts,
                )

                # Stable priority sort: welcome=0, commit=1, application=2
                # then created_at ASC. OC parity: channel.ts:5079-5086.
                # Unknown message_types sort to the end (priority=3) so
                # they don't block known-good rows; we still ack them.
                def _priority(row: dict[str, Any]) -> tuple[int, str]:
                    mt = row.get("message_type")
                    pri = (
                        0
                        if mt == "welcome"
                        else 1
                        if mt == "commit"
                        else 2
                        if mt == "application"
                        else 3
                    )
                    return (pri, row.get("created_at") or "")

                rows = sorted(rows, key=_priority)

                ack_queue_ids: list[str] = []
                for row in rows:
                    queue_id = row.get("queue_id")
                    if queue_id is None:
                        # Defensive: malformed row from server. Skip but
                        # don't crash — the backend should not emit this.
                        logger.warning(
                            "_pull_delivery_queue: row missing queue_id; skipping"
                        )
                        continue
                    sender = row.get("sender_device_id")
                    if sender == device_id_str:
                        # Own echo — backend includes our own writes in
                        # the queue. Ack without re-processing.
                        ack_queue_ids.append(queue_id)
                        continue

                    mt = row.get("message_type")
                    if mt == "welcome":
                        outcome = await handle_mls_welcome(
                            envelope=WireEnvelope(event="message_mls", data=row),
                            mls_states=self._mls_states,
                            pending_kp_state=self._pending_kp_state,
                            own_device_id=device_id_str,
                            conv_to_group_id=self._conv_to_group_id,
                            send_locks=self._conv_send_locks,
                            persist_state=self._persist_state_callback,
                            clear_pending_kp_state=self._clear_pending_kp_state,
                            rest_base_url=self._relay.rest_base_url,
                            device_jwt=self._relay.device_jwt,
                            welcome_request_callable=(
                                self._cold_start_recover_single_group
                            ),
                            telemetry=self._telemetry,
                        )
                        if outcome.drop or outcome.joined:
                            ack_queue_ids.append(queue_id)
                        # P3 + P16 + P21: Stage 4 fire-and-forget republish.
                        # On a successful join, schedule
                        # _ensure_pending_key_package as a background task
                        # WITHOUT awaiting completion (avoid blocking
                        # subsequent row processing on a non-critical-path
                        # network call). Cancel-and-replace any prior
                        # in-flight task per P21 — two welcomes in the
                        # same pull batch correctly serialize via
                        # _kp_publish_lock acquired inside the helper's
                        # caller (start() acquires it; the republish task
                        # acquires it via the lock-ordering invariant P24
                        # documented on _ensure_pending_key_package).
                        if outcome.joined:
                            prior = self._republish_task
                            if prior is not None and not prior.done():
                                prior.cancel()
                                # Don't await — we're inside the
                                # pull-queue dispatch loop. The cancelled
                                # task's try/finally below releases the
                                # lock as it unwinds.

                            async def _republish_under_lock() -> None:
                                # Acquire-with-30s-timeout mirrors P26
                                # in start() so a wedged prior cycle
                                # can't permanently block this task too.
                                try:
                                    await asyncio.wait_for(
                                        self._kp_publish_lock.acquire(),
                                        timeout=_KP_PUBLISH_LOCK_START_TIMEOUT_SECONDS,
                                    )
                                except asyncio.TimeoutError:
                                    logger.warning(
                                        "_pull_delivery_queue republish: "
                                        "timed out acquiring _kp_publish_lock; "
                                        "skipping. Next reconnect's start() "
                                        "will republish."
                                    )
                                    return
                                try:
                                    await self._ensure_pending_key_package()
                                finally:
                                    self._kp_publish_lock.release()

                            self._republish_task = asyncio.create_task(
                                _republish_under_lock()
                            )
                        # action #234: a room Welcome just joined — record
                        # the room in the directory so it is routable and
                        # surfaces in get_chat_info / _iter_known_groups.
                        if outcome.joined and row.get("room_id"):
                            self._room_directory.record_welcome(
                                str(row["room_id"]),
                                self._conv_to_group_id.get(outcome.routing_key or "")
                                or str(row.get("group_id") or ""),
                            )
                            await asyncio.to_thread(
                                self._room_directory.save, self._data_dir
                            )
                        # action #238: an A2A Welcome just joined — record
                        # the channel in the registry so it is routable and
                        # surfaces in _iter_known_groups (iteration 3).
                        if outcome.joined and row.get("a2a_channel_id"):
                            self._a2a_registry.record_welcome(
                                str(row["a2a_channel_id"]),
                                self._conv_to_group_id.get(outcome.routing_key or "")
                                or str(row.get("group_id") or ""),
                            )
                            await asyncio.to_thread(
                                self._a2a_registry.save, self._data_dir
                            )
                    elif mt in ("commit", "application"):
                        # commit + application rows both decrypt via
                        # handle_message_mls; a commit returns
                        # is_handshake=True (epoch advanced, persisted,
                        # not dispatched). action #234 un-drops commits so
                        # room membership-change commits advance the epoch.
                        envelope = WireEnvelope(
                            event="message_mls", data=row
                        )
                        try:
                            inbound = await handle_message_mls(
                                envelope,
                                self._mls_states,
                                device_id_str,
                                conv_to_group_id=self._conv_to_group_id,
                                send_locks=self._conv_send_locks,
                            )
                        except Exception:
                            # handle_message_mls is supposed to absorb
                            # decrypt errors itself, but a contract
                            # regression must not crash the pull loop.
                            logger.exception(
                                "_pull_delivery_queue: handle_message_mls "
                                "raised on commit/application row queue_id=%s",
                                queue_id[:8] if isinstance(queue_id, str) else queue_id,
                            )
                            ack_queue_ids.append(queue_id)
                            continue
                        if inbound is not None:
                            state = self._mls_states.get(inbound.conversation_id)
                            if state is not None:
                                await asyncio.to_thread(
                                    self._persist_state_sync,
                                    inbound.conversation_id,
                                    state,
                                )
                            if not inbound.is_handshake:
                                await self._dispatch_inbound(inbound)
                        ack_queue_ids.append(queue_id)
                    else:
                        # Unknown message_type — log + ack to avoid
                        # dead-lettering rows we just don't recognize.
                        logger.warning(
                            "_pull_delivery_queue: unknown message_type=%r "
                            "queue_id=%s; acking and dropping",
                            mt,
                            queue_id[:8] if isinstance(queue_id, str) else queue_id,
                        )
                        ack_queue_ids.append(queue_id)

                if ack_queue_ids:
                    await rest.ack_mls_delivery(ack_queue_ids, device_id_str)
        finally:
            self._delivery_pulling = False

    async def _persist_state_callback(
        self, conv_id: str, state: "MlsGroupState"
    ) -> None:
        """Async wrapper around ``_persist_state_sync`` for Stage 4 inbox use.

        Wraps the synchronous persistence helper in ``asyncio.to_thread``
        so the inbox handler (which is part of the asyncio dispatch loop)
        doesn't block the event loop on slow filesystems. Kept on
        SecureChannel so the inbox module stays acyclic w.r.t. this one.
        """
        await asyncio.to_thread(self._persist_state_sync, conv_id, state)

    def _clear_pending_kp_state(self) -> None:
        """Clear the in-memory pending KP bundle.

        Called by Stage 4's ``handle_mls_welcome`` after a successful
        join consumes the bundle. The next ``_ensure_pending_key_package``
        invocation (start-on-reconnect or fire-and-forget post-Welcome)
        regenerates and republishes.
        """
        self._pending_kp_state = None

    async def _teardown_partial_start(self) -> None:
        """Best-effort teardown after a mid-``start()`` failure.

        Closes the relay and cancels any background tasks the partial
        start managed to spawn. Must NOT raise — start() is already
        re-raising the original exception, and a teardown raise would
        mask it.

        Stage 2 reaches this only on connect/publish/pull-stub failures;
        no background tasks have been spawned yet, so this is mostly the
        relay close. We still iterate ``_background_tasks`` defensively
        in case future stages spawn anything earlier.
        """
        # Cancel any pending tasks first so a slow disconnect doesn't
        # trap them past stop().
        tasks = list(self._background_tasks)
        for task in tasks:
            task.cancel()
        if tasks:
            try:
                await asyncio.gather(*tasks, return_exceptions=True)
            except Exception:  # noqa: BLE001 — best-effort
                logger.debug(
                    "_teardown_partial_start: gather raised", exc_info=True
                )
        # Cancel the republish task too, just in case a future stage
        # spawns it before publish completes.
        try:
            await self._cancel_republish_task()
        except Exception:  # noqa: BLE001 — best-effort
            logger.debug(
                "_teardown_partial_start: cancel republish raised",
                exc_info=True,
            )
        try:
            await self._relay.disconnect()
        except Exception:  # noqa: BLE001 — best-effort
            logger.debug(
                "_teardown_partial_start: relay disconnect raised",
                exc_info=True,
            )

    async def _cancel_republish_task(self) -> None:
        """Cancel any in-flight ``_republish_task`` and bound the wait (P21).

        Used by both ``stop()`` and ``_schedule_reconnect()``. The 2s
        timeout is long enough for a healthy task to honor cancel-and-unwind
        but short enough to keep stop()/reconnect responsive. On timeout
        we drop the reference; the task's own try/finally (added in
        Stage 4 alongside the republish wiring) releases ``_kp_publish_lock``
        as it finally unwinds.

        Stage 2: ``_republish_task`` is always None today (Stage 4 sets
        it). The early-return makes the method safe to call from stop()
        even on a channel that never published.
        """
        task = self._republish_task
        if task is None or task.done():
            self._republish_task = None
            return
        task.cancel()
        try:
            await asyncio.wait_for(
                asyncio.shield(task),
                timeout=_REPUBLISH_TASK_CANCEL_TIMEOUT_SECONDS,
            )
        except (asyncio.CancelledError, asyncio.TimeoutError):
            # Task either honored cancel or is genuinely wedged. Either
            # way, drop the reference; lock release is best-effort via
            # the task's own try/finally.
            pass
        except Exception:  # noqa: BLE001 — best-effort
            logger.debug(
                "_cancel_republish_task: shielded await raised", exc_info=True
            )
        finally:
            self._republish_task = None

    async def _drop_a2a_channel_mls(self, a2a_channel_id: str) -> None:
        """Remove an A2A channel's MLS state from memory and disk.

        Used by ``a2a_agent_removed`` cleanup. The MLS state file lives at
        ``{data_dir}/conversations/{a2a_channel_id}/mls_state.bin`` —
        parallel to 1:1 and room state, since A2A also keys ``mls_states``
        by the bare channel id. Best-effort filesystem cleanup: failures
        are logged, never raised into the demux loop.
        """
        self._mls_states.pop(a2a_channel_id, None)
        bin_path = (
            self._data_dir
            / "conversations"
            / a2a_channel_id
            / "mls_state.bin"
        )
        try:
            if bin_path.exists():
                await asyncio.to_thread(bin_path.unlink)
        except OSError as exc:
            logger.warning(
                "a2a: failed to delete MLS state for %s: %s",
                a2a_channel_id,
                exc,
            )

    # --- Slice B founder helpers ----------------------------------------

    def _a2a_rest_client_factory(self):  # type: ignore[no-untyped-def]
        """Build a fresh RestClient context manager for A2AFounder.

        Slice B founder constructs one RestClient per ``found_a2a_group``
        call (mirrors Slice A's ``_request_a2a_welcome`` pattern). Returning
        the context manager — not entering it — keeps the
        ``async with`` site inside the founder.
        """
        from agentvault_hermes.core.transport.rest_client import RestClient

        return RestClient(
            base_url=self._relay.rest_base_url,
            device_jwt=self._relay.device_jwt,
        )

    def _create_a2a_mls_state(self) -> "MlsGroupState":
        """Construct a fresh MlsGroupState for a newly-founded A2A group.

        Mirrors the ``MlsGroupState(device_keys=..., device_id=...)``
        instantiation pattern used by ``_ensure_pending_key_package``
        (secure_channel.py:2055). The caller invokes ``create_group`` on
        the returned instance.
        """
        from agentvault_hermes.crypto.mls_group import MlsGroupState

        return MlsGroupState(
            device_keys=self._device_keys,
            device_id=self._device_id,
        )

    async def _persist_a2a_mls_state(
        self, group_id: str, state: "MlsGroupState"
    ) -> None:
        """Persist a founded A2A group's MLS state to disk.

        Reuses :meth:`_persist_state_sync` (the same atomic-write helper
        used by 1:1 conversations + rooms). ``group_id`` is the canonical
        MLS group UUID; the helper canonicalizes + writes to
        ``data_dir/conversations/<group_id>/mls_state.bin``. Also registers
        the live state in ``_mls_states`` so subsequent sends/receives
        find it without a disk reload.
        """
        # Make the state usable in-process for sends/receives via this same
        # SecureChannel instance.
        self._mls_states[group_id] = state
        await asyncio.to_thread(self._persist_state_sync, group_id, state)

    async def _request_a2a_welcome(self, a2a_channel_id: str) -> None:
        """Ask the backend to (re-)deliver a Welcome for an A2A channel this
        agent is a member of but has not joined. Port of OC's listA2AChannels
        member sync-fallback (channel.ts ~:2203-2327).

        Two-step REST flow:
          1. ``GET /api/v1/mls/a2a/{a2a_channel_id}/group`` — look up the
             MLS group id for the channel.
          2. ``POST /api/v1/mls/groups/{group_id}/request-welcome`` — ask the
             group creator to re-emit a Welcome targeted at our KeyPackage.

        Best-effort: a 404 / 5xx is logged and swallowed; the next reconnect
        re-tries via ``_reconcile_a2a_channels``.
        """
        from agentvault_hermes.core.transport.rest_client import (
            RestClient,
            RestClientError,
        )

        try:
            async with RestClient(
                base_url=self._relay.rest_base_url,
                device_jwt=self._relay.device_jwt,
            ) as client:
                group = await client.get_a2a_group(a2a_channel_id)
                group_id = group.get("group_id") if isinstance(group, dict) else None
                if not group_id:
                    logger.warning(
                        "a2a: get_a2a_group returned no group_id for channel %s; "
                        "skipping welcome re-request",
                        a2a_channel_id,
                    )
                    return
                await client.request_mls_welcome(
                    str(group_id), str(self._device_id)
                )
        except (RestClientError, OSError) as exc:
            logger.warning(
                "a2a: request_welcome for channel %s failed: %s",
                a2a_channel_id,
                exc,
            )

    async def _reconcile_a2a_channels(self) -> None:
        """Connect-time A2A reconciliation (spec §5.5). Poll the backend for
        every A2A channel this agent is a member of, upsert it into the
        registry, and recover any channel that is not yet joined. Best-effort:
        a failed poll is logged, never raised into the connect path.

        Backend requirement: ``GET /api/v1/a2a/channels`` must accept the
        device JWT. PR #232 added device-JWT support to ``get_auth_context``;
        until that deploys to prod, the integration test path proves the
        plugin-side wiring with respx mocks while the prod path returns 401.
        """
        from agentvault_hermes.core.transport.rest_client import RestClient

        try:
            async with RestClient(
                base_url=self._relay.rest_base_url,
                device_jwt=self._relay.device_jwt,
            ) as client:
                channels = await client.list_a2a_channels()
            for item in channels:
                try:
                    self._a2a_registry.upsert_from_poll(item)
                except (KeyError, TypeError) as exc:
                    logger.warning(
                        "a2a poll: skipping malformed item: %s", exc
                    )
            await asyncio.to_thread(self._a2a_registry.save, self._data_dir)
            for entry in self._a2a_registry.all():
                if entry.mls_group_id is None:
                    await self._a2a_lifecycle.recover_unjoined_channel(entry)
        except Exception as exc:  # noqa: BLE001 — reconcile is best-effort
            logger.warning(
                "a2a: connect-time reconciliation failed: %s; channel state "
                "unchanged", exc
            )

    async def _release_lock(self, conv_id: str) -> None:
        """Release a held A2A sync lock. Idempotent.

        Validates ``conv_id`` is non-empty before calling into ``lock_file``
        — an empty conv_id would yield a filename like ``mls-a2a-sync-.lock``
        which conflicts across processes (DA #2). Wrapped in
        ``asyncio.to_thread`` so a slow filesystem does not block the loop
        during ``stop()`` (DA #10).
        """
        if not conv_id:
            return
        from agentvault_hermes.channel.lock_file import release_a2a_sync_lock

        try:
            await asyncio.to_thread(
                release_a2a_sync_lock, self._data_dir, conv_id
            )
        finally:
            self._held_locks.discard(conv_id)


__all__ = [
    "InboundMessage",
    "SecureChannel",
]
