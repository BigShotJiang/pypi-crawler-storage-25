"""WebSocket event dispatch registry for the Hermes SecureChannel.

Substrate for the Phase 4a parity refactor (see docs/superpowers/specs/
2026-05-13-hermes-phase4a-mls-catchup-coldstart-design.md). Handlers register
themselves at __init__ time; dispatch catches per-handler exceptions so one
buggy handler cannot kill the demux loop.

OC parity note: OC's channel.ts uses a switch on event in a monolithic file.
Hermes uses this registry for trivial extensibility (Phase 4a PR-2, PR-3, and
Phase 4b telemetry all register handlers without further refactor). An
eventual mirror refactor on the OC side is documented in the Phase 4a design
spec at docs/superpowers/specs/2026-05-13-hermes-phase4a-mls-catchup-coldstart-design.md
(see "Running list of 'better ways' to port to OC later").
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
from typing import TYPE_CHECKING, Awaitable, Callable, TypeAlias

if TYPE_CHECKING:
    from agentvault_hermes.channel.outbox import WireEnvelope

logger = logging.getLogger(__name__)

WSEventHandler: TypeAlias = Callable[["WireEnvelope"], Awaitable[None]]
"""Async handler for a single inbound WS event type.

Handlers are bound methods on SecureChannel (so they have access to channel
state via ``self``); they accept the parsed WireEnvelope and return None on
success. Exceptions are caught by ``WSEventRegistry.dispatch`` — handlers
should let unexpected errors propagate rather than swallowing them.
"""


class WSEventRegistry:
    """Dispatch table mapping event_type strings to async handlers.

    See module docstring for context. Handlers are registered at
    SecureChannel __init__ time; ``register()`` MUST NOT be called after
    ``dispatch()`` has been invoked at runtime. The registry is otherwise
    safe under concurrent dispatch since handler resolution and invocation
    use a single GIL-protected ``dict.get`` and ``register()`` is called
    only at startup before any dispatch.

    ``dispatch()`` catches per-handler exceptions so the WS demux loop
    survives a single bad frame.
    """

    def __init__(self) -> None:
        self._handlers: dict[str, WSEventHandler] = {}

    def registered_event_types(self) -> set[str]:
        """Return the set of event_type strings currently registered.

        Public introspection surface. Tests use this instead of reaching
        into the private ``_handlers`` dict; future operator/debug
        endpoints (e.g. a ``/debug/handlers`` route) can call it for the
        live list without violating encapsulation.
        """
        return set(self._handlers)

    def register(self, event_type: str, handler: WSEventHandler) -> None:
        """Register an async handler for the given event_type.

        Intended to be called during SecureChannel.__init__ ONLY — calling
        after dispatch() has started can race with in-flight events.

        Raises:
            ValueError: if event_type already has a registered handler.
                Fail-fast surface for collision bugs (e.g. two feature
                modules both trying to own the same event).
        """
        if event_type in self._handlers:
            raise ValueError(
                f"Handler already registered for event_type={event_type!r}"
            )
        self._handlers[event_type] = handler

    async def dispatch(self, event_type: str, envelope: "WireEnvelope") -> None:
        """Dispatch an inbound event to its registered handler.

        Behavior:
          - Unknown event_type: logs DEBUG and returns (matches existing
            ``_demux_loop`` fallthrough at ``secure_channel.py:676-679``).
          - Handler raises ``asyncio.CancelledError``: propagates to caller
            so ``stop()``/teardown still works. NOT logged here.
          - Handler raises any other ``Exception``: caught, logged at WARN
            with event_type and BLAKE2b-8 payload hash, returns.

        The caller (``SecureChannel._demux_loop``) does NOT need to wrap this
        in its own try/except — that wrapping IS the contract this method
        provides.
        """
        handler = self._handlers.get(event_type)
        if handler is None:
            logger.debug("Unknown WS event %r, ignoring", event_type)
            return
        try:
            await handler(envelope)
        except asyncio.CancelledError:
            # Propagate so stop()/teardown works. Matches the existing
            # try/except pattern in _demux_loop:680-685.
            raise
        except Exception:
            try:
                payload_hash = _hash_payload(envelope)
            except Exception:  # noqa: BLE001 — best-effort log helper
                payload_hash = "unhashable"
            logger.warning(
                "WS event handler raised event_type=%r payload_hash=%s",
                event_type,
                payload_hash,
                exc_info=True,
            )


def _hash_payload(envelope: "WireEnvelope") -> str:
    """Return an 8-hex-char BLAKE2b digest of the envelope payload.

    Truncated digest is for log correlation only — not cryptographically
    significant. Matches CLAUDE.md convention (BLAKE2b for hashing).
    Determinism: ``sort_keys=True`` so equivalent payloads always hash the
    same.
    """
    payload_bytes = json.dumps(
        {"event": envelope.event, "data": envelope.data},
        sort_keys=True,
        default=str,
    ).encode("utf-8")
    return hashlib.blake2b(payload_bytes, digest_size=4).hexdigest()
