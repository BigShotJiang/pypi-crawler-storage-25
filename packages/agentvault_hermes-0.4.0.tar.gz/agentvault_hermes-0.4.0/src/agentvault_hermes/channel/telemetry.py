"""Structured MLS telemetry emitter for SecureChannel.

Spec: docs/superpowers/specs/2026-05-14-hermes-phase4b-mls-telemetry-and-ui-design.md (PR-4b-A1)

Replaces the operator-grep-only MLS_* logger.warning lines with typed
events on the existing WS envelope. Phase 4a log lines stay in place
through Phase 4c; this module emits alongside the log, not in place of it.

Failure to emit is WARN-logged and absorbed. Telemetry MUST NOT cause
an MLS flow to throw or stall.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Protocol

logger = logging.getLogger(__name__)


class MlsTelemetryEventType(str, Enum):
    """Closed enum mirrored on the TS side (packages/web/lib/mls-telemetry.ts).

    Each value MUST equal its lowercase name (enforced by test). Adding a
    new value will require paired updates on the TS side
    (`packages/web/lib/mls-telemetry.ts`, Phase 4b PR-B1) AND the backend
    Pydantic Literal (`packages/backend/app/schemas/mls_telemetry.py`,
    Phase 4b PR-A2). Until those mirrors land, this enum is the authoritative
    source; PR-A2 and PR-B1 will add closed-enum agreement tests.
    """
    COLD_START_RECOVERING = "cold_start_recovering"
    COLD_START_FAIL = "cold_start_fail"
    COLD_START_ABORT = "cold_start_abort"
    COLD_START_PERSISTENCE_FAIL = "cold_start_persistence_fail"
    SYNC_RESPONSE_REJOIN_FAIL = "sync_response_rejoin_fail"
    WELCOME_REQUESTED_INVALID = "welcome_requested_invalid"
    WELCOME_REQUEST_SKIPPED = "welcome_request_skipped"
    WELCOME_PERMANENT_FAILURE = "welcome_permanent_failure"
    SYNC_EMIT_FAIL = "sync_emit_fail"
    SYNC_ABORT = "sync_abort"
    JOINED = "joined"


@dataclass(frozen=True)
class MlsTelemetryEvent:
    """A single telemetry event ready for emit.

    `group_id` is None for scan-level events (e.g. cold_start_persistence_fail
    fires once per scan even though the failure may affect many groups).
    `context` carries everything else as small primitives — strings or ints.
    Never put secrets, key material, or exception messages in `context`;
    use `error_class` (exception class name only) for error correlation.
    """
    event: MlsTelemetryEventType
    group_id: str | None
    context: dict[str, str | int] = field(default_factory=dict)


class TelemetrySender(Protocol):
    """Sink for emitted envelopes. Production binds to the SecureChannel
    relay's `send_json`; tests bind to an in-memory recorder."""
    async def send(self, envelope: dict[str, Any]) -> None: ...


class MlsTelemetryEmitter:
    """Async, fire-and-forget emitter.

    Failure to send (network, cancellation, serializer error) is
    WARN-logged and absorbed. Telemetry NEVER raises into the caller.
    """

    def __init__(self, sender: TelemetrySender) -> None:
        self._sender = sender

    async def emit(self, event: MlsTelemetryEvent) -> None:
        envelope: dict[str, Any] = {
            "event": "telemetry.mls",
            "data": {
                "event": event.event.value,
                "group_id": event.group_id,
                "context": dict(event.context),
            },
        }
        try:
            await self._sender.send(envelope)
        except Exception as exc:  # noqa: BLE001 — telemetry must absorb its own errors only
            # CancelledError + KeyboardInterrupt + SystemExit propagate by design:
            # cancellation is the caller's signal, not ours to swallow. Callers who
            # want to shield emit from cancellation should use `asyncio.shield` at
            # the call site.
            logger.warning(
                "telemetry_emit_failed event=%s group_id=%s error=%s",
                event.event.value,
                event.group_id,
                exc,
            )
