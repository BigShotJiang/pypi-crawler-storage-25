"""A2A lifecycle handler — turns A2A lifecycle WS events into registry state.

``A2ALifecycleHandler`` owns the nine A2A lifecycle event handlers OpenClaw
handles (``channel.ts ~:3083-3355``), the KeyPackage-publish on invite, and the
not-joined recovery routine used by connect-time reconciliation. It is a
member-role port: the agent is invited into channels others create — it never
founds a group (that is Slice B).

``SecureChannel`` instantiates this and registers each ``handle_*`` method on the
``WSEventRegistry``; the handler bodies stay out of ``secure_channel.py``. State
lives in the injected ``A2AChannelRegistry``; crypto/MLS side-effects are
injected callables so this module has no MLS dependency.
"""
from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Optional

from agentvault_hermes.channel.a2a_registry import (
    A2AChannelEntry,
    A2AChannelRegistry,
    A2AParticipant,
)
from agentvault_hermes.channel.outbox import WireEnvelope

logger = logging.getLogger(__name__)


class A2ALifecycleHandler:
    """Handlers for the A2A lifecycle WS events (member + creator).

    Slice A (member-only) shipped first; Slice B adds the creator branch on
    ``handle_channel_approved`` via the optional ``found_a2a_group`` callback.
    Slice B also bundles a fast-path fix: ``handle_channel_invited`` and the
    member-side ``handle_channel_approved`` now both call ``request_welcome``
    immediately, so the member joins in the same connection cycle rather than
    waiting for the next reconnect. See
    ``docs/superpowers/specs/2026-05-24-hermes-a2a-creator-slice-b-design.md``
    §5.3.
    """

    def __init__(
        self,
        registry: A2AChannelRegistry,
        data_dir: Path,
        *,
        own_hub_id: str,
        ensure_key_package: Callable[[], Awaitable[None]],
        drop_channel_mls: Callable[[str], Awaitable[None]],
        request_welcome: Callable[[str], Awaitable[None]],
        # Slice B addition. Optional so tests + Slice-A-only constructions keep
        # working; in production wiring SecureChannel always passes the real
        # A2AFounder.found_a2a_group bound method.
        found_a2a_group: Optional[
            Callable[[str, list[A2AParticipant]], Awaitable[None]]
        ] = None,
    ) -> None:
        self._registry = registry
        self._data_dir = data_dir
        self._own_hub_id = own_hub_id
        self._ensure_key_package = ensure_key_package
        self._drop_channel_mls = drop_channel_mls
        self._request_welcome = request_welcome
        self._found_a2a_group = found_a2a_group

    def _persist(self) -> None:
        """Persist the registry after a mutation. Best-effort — a failed write
        is logged, never raised into the demux loop."""
        try:
            self._registry.save(self._data_dir)
        except OSError as exc:
            logger.warning("a2a_lifecycle: registry save failed: %s", exc)

    @staticmethod
    def _channel_id(envelope: WireEnvelope) -> str:
        data = envelope.data
        cid = data.get("a2a_channel_id") or data.get("channel_id")
        if not cid:
            raise KeyError("a2a lifecycle event missing channel id")
        return str(cid)

    # --- channel lifecycle ------------------------------------------------

    async def handle_channel_invited(self, envelope: WireEnvelope) -> None:
        """``a2a_channel_invited`` — the member entry point. Upsert + ensure
        a KeyPackage is published + (Slice B fast-path fix) immediately
        request a Welcome so the member joins in the same connection cycle,
        not at the next reconnect.
        """
        self._registry.upsert_from_event(envelope.data)
        self._persist()
        await self._ensure_key_package()
        await self._request_welcome(self._channel_id(envelope))

    async def handle_channel_approved(self, envelope: WireEnvelope) -> None:
        """``a2a_channel_approved`` — the channel went active.

        role=creator (Slice B): invoke the founder to init the MLS group and
        send Welcomes to all invited participants.

        role=member (Slice A path + bundled fast-path fix): publish a
        KeyPackage and immediately request a Welcome from the creator.
        """
        self._registry.upsert_from_event(envelope.data)
        self._persist()

        role = str(envelope.data.get("role") or "member")
        channel_id = self._channel_id(envelope)

        if role == "creator":
            if self._found_a2a_group is None:
                logger.warning(
                    "a2a_channel_approved role=creator for %s but no founder "
                    "wired; channel will not be founded",
                    channel_id,
                )
                return
            entry = self._registry.get(channel_id)
            if entry is None:
                logger.warning(
                    "a2a_channel_approved creator for %s — entry missing "
                    "after upsert; skipping",
                    channel_id,
                )
                return
            await self._found_a2a_group(
                channel_id, list(entry.participants.values())
            )
            return

        await self._ensure_key_package()
        await self._request_welcome(channel_id)

    async def handle_invite_pending(self, envelope: WireEnvelope) -> None:
        """``a2a_invite_pending`` — a new participant is being added to an
        already-active channel. Slice C will implement this. Registered here
        so dispatch is wired; Slice C is a body-only change.
        """
        logger.info(
            "a2a_invite_pending: deferred to Slice C; channel=%s device=%s",
            envelope.data.get("a2a_channel_id") or envelope.data.get("channel_id"),
            envelope.data.get("device_id"),
        )

    async def handle_channel_rejected(self, envelope: WireEnvelope) -> None:
        """``a2a_channel_rejected`` — the channel request was denied. Minimal,
        per OC: drop any pending entry, no crypto."""
        self._registry.remove(self._channel_id(envelope))
        self._persist()

    async def handle_channel_revoked(self, envelope: WireEnvelope) -> None:
        """``a2a_channel_revoked`` — the channel was deleted. Strict OC parity:
        remove the registry entry only; the MLS state file is intentionally
        NOT cleaned up here (known OC quirk — see spec §6)."""
        self._registry.remove(self._channel_id(envelope))
        self._persist()

    async def handle_participant_joined(self, envelope: WireEnvelope) -> None:
        """``a2a_participant_joined`` — a peer became active. Member-side: a
        roster update, no MLS action."""
        hub_id = str(envelope.data.get("hub_id") or "")
        if hub_id:
            self._registry.update_participant(
                self._channel_id(envelope), hub_id, "active"
            )
            self._persist()

    async def handle_participant_left(self, envelope: WireEnvelope) -> None:
        """``a2a_participant_left`` — a peer left voluntarily."""
        hub_id = str(envelope.data.get("hub_id") or "")
        if hub_id:
            self._registry.update_participant(
                self._channel_id(envelope), hub_id, "left"
            )
            self._persist()

    async def handle_participant_removed(self, envelope: WireEnvelope) -> None:
        """``a2a_participant_removed`` — a peer was removed."""
        hub_id = str(envelope.data.get("hub_id") or "")
        if hub_id:
            self._registry.update_participant(
                self._channel_id(envelope), hub_id, "removed"
            )
            self._persist()

    async def handle_agent_removed(self, envelope: WireEnvelope) -> None:
        """``a2a_agent_removed`` — THIS agent was removed. Full cleanup:
        forget the channel, drop its MLS state, delete the state file."""
        channel_id = self._channel_id(envelope)
        self._registry.remove(channel_id)
        await self._drop_channel_mls(channel_id)
        self._persist()

    async def handle_creator_transferred(self, envelope: WireEnvelope) -> None:
        """``a2a_creator_transferred`` — channel ownership changed. Track the
        role verbatim. If we became the creator, log a warning: creator
        operations are unimplemented until Slice B; the channel still works
        for member-shaped receive/reply."""
        channel_id = self._channel_id(envelope)
        new_creator = str(envelope.data.get("new_creator_hub_id") or "")
        role = "creator" if new_creator == self._own_hub_id else "member"
        self._registry.set_role(channel_id, role)
        if role == "creator":
            logger.warning(
                "a2a_lifecycle: assigned creator role on channel %s, but "
                "creator operations are not implemented until Slice B; "
                "channel remains usable for receive/reply only",
                channel_id,
            )
        self._persist()


    # --- connect-time reconciliation -------------------------------------

    async def recover_unjoined_channel(self, entry: A2AChannelEntry) -> None:
        """Drive recovery for a channel that has not joined an MLS group
        (``mls_group_id is None``). Idempotent: a joined channel is a no-op.
        Called by connect-time reconciliation (spec §5.5).

        Slice B (spec §5.4): branches on ``entry.role``. Creator-role
        entries re-attempt founding via :meth:`A2AFounder.found_a2a_group`
        (which is idempotent at the backend init endpoint). Member-role
        entries take the Slice A request_welcome path. If a creator entry
        is seen but no ``found_a2a_group`` callback was wired (legacy or
        test construction), log a warning and skip — falling through to the
        member path would publish a KP and ask ourselves for a Welcome,
        which is confusing at best.
        """
        if entry.mls_group_id is not None:
            return

        if entry.role == "creator":
            if self._found_a2a_group is None:
                logger.warning(
                    "a2a reconcile: creator-role entry %s found but no "
                    "founder wired; channel cannot be (re-)founded",
                    entry.a2a_channel_id,
                )
                return
            try:
                await self._found_a2a_group(
                    entry.a2a_channel_id,
                    list(entry.participants.values()),
                )
            except Exception as exc:  # noqa: BLE001 — reconcile is best-effort
                logger.warning(
                    "a2a reconcile: found_a2a_group for %s failed: %s; will "
                    "retry on next connect",
                    entry.a2a_channel_id,
                    exc,
                )
            return

        await self._ensure_key_package()
        await self._request_welcome(entry.a2a_channel_id)


__all__ = ["A2ALifecycleHandler"]
