"""Mention helpers — verbatim translation from OpenClaw.

Source: ``packages/plugin/src/openclaw-entry.ts:140-206``. Hermes Phase 3
WS-30. Plan ref: ``docs/plans/2026-05-10-hermes-phase3-implementation.md``
§4.5.

Three pure-function helpers for room / A2A message routing:

- ``parse_mentions`` — extracts ``@word`` mentions, lower-cased.
- ``should_process_room_message`` — mention-semantic filter for whether
  this agent should react to a room message. Loop prevention is the
  rate-limiter's job (see ``channel/loop_prevention.py``); this function
  ONLY filters by ``@mention`` semantics.
- ``strip_mentions`` — removes own-name + ``@all`` / ``@everyone``;
  preserves other-agent mentions so the LLM can still reason about
  who else was addressed.

The regex deliberately matches only ``\\w+`` (word characters) to mirror
OC's behavior on edge cases like ``user@example.com`` → ``["example"]``.
That is verified in OC's ``mention-filter.test.ts:37-39``.
"""
from __future__ import annotations

import re

# OC at openclaw-entry.ts:143 uses /@(\w[\w]*)/gi which is identical in
# semantics to /@(\w+)/gi for any input — \w[\w]* and \w+ both match one
# or more word characters. We use the simpler form.
_MENTION_RE = re.compile(r"@(\w+)", re.IGNORECASE)


def parse_mentions(text: str) -> list[str]:
    """Extract ``@word`` mentions from text, lower-cased.

    Source: OC ``openclaw-entry.ts:140-149``.

    Examples:
        >>> parse_mentions("hello @bob")
        ['bob']
        >>> parse_mentions("@all please review")
        ['all']
        >>> parse_mentions("user@example.com")  # email-like; matches at boundary
        ['example']
    """
    return [m.group(1).lower() for m in _MENTION_RE.finditer(text)]


def should_process_room_message(
    plaintext: str,
    agent_name: str,
    account_id: str,
    sender_is_agent: bool = False,
) -> bool:
    """Decide whether this agent should react to a room message.

    Source: OC ``openclaw-entry.ts:151-182``. Loop prevention is the
    rate-limiter's job (``loop_prevention.LoopPreventer``); this function
    ONLY filters by ``@mention`` semantics.

    Decision tree (mirroring OC):

    1. ``sender_is_agent`` AND no mentions → ``False`` (loop guard;
       agents don't auto-reply to each other's plain chatter).
    2. No mentions (from a human) → ``True`` (broadcast to all agents).
    3. ``@all`` or ``@everyone`` in mentions → ``True`` (intentional
       broadcast; OK from agents too).
    4. Mention matches this agent's name (full or first word) OR account
       ID → ``True``.
    5. Mentions exist but none match this agent → ``False``.

    Args:
        plaintext: Decrypted message text.
        agent_name: This agent's display name (e.g. ``"Cortina"`` or
            ``"Markus (Coder)"``).
        account_id: This agent's account ID (e.g. ``"cortina"``).
        sender_is_agent: Whether the inbound message was sent by another
            agent. Defaults to ``False`` (human sender).

    Returns:
        ``True`` if this agent should process the message; ``False``
        otherwise.
    """
    mentions = parse_mentions(plaintext)
    # Loop prevention: agent senders without explicit @mentions are skipped.
    # Without this guard, agents respond to each other's plain-text chatter
    # and create infinite reply loops in shared rooms.
    if sender_is_agent and not mentions:
        return False
    # No mentions from a human → broadcast to all agents.
    if not mentions:
        return True
    # @all / @everyone → all agents process (intentional broadcast OK from agents).
    if "all" in mentions or "everyone" in mentions:
        return True
    # Check if this agent is mentioned (by name, first-word, or accountId).
    name_lower = agent_name.lower()
    id_lower = account_id.lower()
    first_word = re.split(r"[\s(]", name_lower, maxsplit=1)[0]
    return any(m == name_lower or m == first_word or m == id_lower for m in mentions)


def strip_mentions(text: str, agent_name: str, account_id: str) -> str:
    """Strip own-name + ``@all`` / ``@everyone`` mentions; preserve others.

    Source: OC ``openclaw-entry.ts:184-206``. The LLM still sees mentions
    of OTHER agents so it can reason about who else was addressed; only
    its own routing-directive mentions are stripped.

    Args:
        text: Raw plaintext, possibly with leading whitespace from a
            stripped mention.
        agent_name: This agent's display name.
        account_id: This agent's account ID.

    Returns:
        Cleaned text with leading whitespace trimmed and trailing
        whitespace stripped.

    Examples:
        >>> strip_mentions("@Cortina hello", "Cortina", "cortina")
        'hello'
        >>> strip_mentions("@Cortina @Markus hello", "Cortina", "cortina")
        '@Markus hello'
        >>> strip_mentions("@Markus hello", "Markus (Coder)", "markus--coder-")
        'hello'
    """
    name_lower = agent_name.lower()
    first_word = re.split(r"[\s(]", name_lower, maxsplit=1)[0]
    id_lower = account_id.lower()

    def _replace(m: re.Match[str]) -> str:
        lower = m.group(1).lower()
        if lower in (name_lower, first_word, id_lower):
            return ""
        if lower in ("all", "everyone"):
            return ""
        return m.group(0)

    return _MENTION_RE.sub(_replace, text).lstrip().strip()


__all__ = [
    "parse_mentions",
    "should_process_room_message",
    "strip_mentions",
]
