"""Slice B — A2A channel creator role.

When the Hermes plugin is assigned ``role=creator`` on an A2A channel, this
module founds the MLS group: fetches invited participants' KeyPackages in
one batch, creates the MLS group, adds members in a single commit, and
sends per-target Welcomes.

Two primitives (``_batch_fetch_keypackages`` and
``_add_members_and_send_welcomes``) are extracted as reusable building
blocks — Slice C's dynamic-add path calls them with a single new
participant. See
``docs/superpowers/specs/2026-05-24-hermes-a2a-creator-slice-b-design.md``
§4 (B-compat hard rule).

Hub_id -> device_id resolution: backend lifecycle payloads carry
``device_id`` per participant
(see ``packages/backend/app/api/v1/a2a_channels.py:344``), so participants
flow into the registry already device-tagged. The founder reads
``A2AParticipant.device_id`` directly — no separate resolver function. A
participant with no ``device_id`` (legacy payload) is reported as pending
because we cannot fetch a KP without a device id.
"""
from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from typing import Protocol

from agentvault_hermes.channel.a2a_registry import (
    A2AChannelRegistry,
    A2AParticipant,
)
from agentvault_hermes.core.transport.relay import Relay
from agentvault_hermes.core.transport.rest_client import RestClient
from agentvault_hermes.crypto.mls_group import MlsGroupState

logger = logging.getLogger(__name__)


# A RestClient is constructed per public call so its async context is opened
# and closed cleanly — mirrors Slice A's _request_a2a_welcome pattern at
# secure_channel.py:2543. The protocol covers both the real RestClient and
# the AsyncMock used in tests; primitive tests inject a bare AsyncMock as
# rest_client directly to skip the factory layer.
RestClientFactory = Callable[[], "_RestClientCM"]


class _RestClientCM(Protocol):
    """Minimal async context manager protocol — only what A2AFounder uses."""

    async def __aenter__(self) -> RestClient: ...
    async def __aexit__(self, *exc: object) -> None: ...


class A2AFounder:
    """Owns the creator-role MLS founding for A2A channels.

    Stateless aside from injected dependencies — one instance per
    :class:`~agentvault_hermes.channel.secure_channel.SecureChannel`. Methods
    are independently callable; :meth:`found_a2a_group` is the orchestrator
    that composes the two primitives.

    Two construction modes:

    - ``rest_client``: a bare object exposing ``batch_fetch_key_packages``
      and ``init_a2a_mls_group`` (used by primitive unit tests; AsyncMock).
    - ``rest_client_factory``: a callable returning an async-context-managed
      :class:`RestClient` (used in production wiring — one client per
      :meth:`found_a2a_group` call so the underlying httpx client is opened
      and closed cleanly, matching Slice A's :func:`_request_a2a_welcome`).

    Exactly one of the two must be supplied.
    """

    def __init__(
        self,
        *,
        rest_client: object | None = None,
        rest_client_factory: RestClientFactory | None = None,
        relay: Relay,
        own_hub_id: str,
        own_device_id: str,
        registry: A2AChannelRegistry,
        create_mls_state: Callable[[], MlsGroupState],
        persist_mls_state: Callable[[str, MlsGroupState], Awaitable[None]],
        save_registry: Callable[[], None],
    ) -> None:
        if rest_client is None and rest_client_factory is None:
            raise ValueError(
                "A2AFounder requires either rest_client or rest_client_factory"
            )
        self._rest_direct = rest_client
        self._rest_factory = rest_client_factory
        self._relay = relay
        self._own_hub_id = own_hub_id
        self._own_device_id = own_device_id
        self._registry = registry
        self._create_mls_state = create_mls_state
        self._persist_mls_state = persist_mls_state
        self._save_registry = save_registry

    # Internal helper exposing a context manager regardless of construction.
    def _rest_ctx(self) -> _RestClientCM:
        if self._rest_factory is not None:
            return self._rest_factory()
        # When rest_client was supplied directly (test mode), wrap it in a
        # trivial async-context-manager so call sites stay uniform.
        rest = self._rest_direct
        assert rest is not None

        class _Bare:
            async def __aenter__(self_inner) -> object:
                return rest

            async def __aexit__(self_inner, *exc: object) -> None:
                return None

        return _Bare()  # type: ignore[return-value]

    # --- Primitives (also called directly by Slice C dynamic-add) --------

    async def _batch_fetch_keypackages(
        self,
        participants: list[A2AParticipant],
        *,
        rest: object | None = None,
    ) -> tuple[dict[str, bytes], list[str]]:
        """Fetch KeyPackages for invited+active participants other than self.

        Returns ``(available_by_hub_id, missing_hub_ids)``. The split lets
        the caller (founder orchestrator, or Slice C dynamic-add) found with
        what's available and mark the rest as ``pending_kp_hub_ids`` on the
        registry entry for reconcile retry.

        OC parity: only ``invited`` or ``active`` participants get a fetch
        attempt; left/removed are excluded. Participants whose ``device_id``
        is unset (legacy payloads) are reported as pending — we can't fetch
        a KP without a device_id.
        """
        eligible = [
            p
            for p in participants
            if p.hub_id != self._own_hub_id
            and p.status in ("invited", "active")
        ]

        hub_to_dev: dict[str, str] = {}
        no_device: list[str] = []
        for p in eligible:
            if p.device_id:
                hub_to_dev[p.hub_id] = p.device_id
            else:
                no_device.append(p.hub_id)

        if not hub_to_dev:
            return {}, [p.hub_id for p in eligible]

        if rest is None:
            async with self._rest_ctx() as client:
                result = await client.batch_fetch_key_packages(
                    device_ids=list(hub_to_dev.values())
                )
        else:
            result = await rest.batch_fetch_key_packages(  # type: ignore[attr-defined]
                device_ids=list(hub_to_dev.values())
            )

        dev_to_hub = {dev: hub for hub, dev in hub_to_dev.items()}
        available: dict[str, bytes] = {}
        for dev_id, kp_bytes in result.available.items():
            hub_id = dev_to_hub.get(dev_id)
            if hub_id:
                available[hub_id] = kp_bytes

        missing: list[str] = list(no_device)
        for p in eligible:
            if p.device_id and p.hub_id not in available:
                missing.append(p.hub_id)
        return available, missing

    async def _add_members_and_send_welcomes(
        self,
        *,
        mls_state: MlsGroupState,
        group_id: str,
        a2a_channel_id: str,
        kp_by_hub_id: dict[str, bytes],
        hub_to_device_id: dict[str, str] | None = None,
    ) -> None:
        """Add the given members to ``mls_state`` in one commit and dispatch
        per-target Welcomes via the relay.

        Hermes's MLS wrapper does N adds in a single commit (vs OC's
        per-member loop) — one epoch transition for all. The Welcome blob
        can serve every new member; we send it via N ``mls_welcome`` WS
        events (one per ``target_device_id``) because the backend's event
        handler is single-target (``app/api/v1/ws.py:1233``).

        Wire-shape (verified against backend handler):
          - ``mls_commit`` carries ``group_id`` + ``epoch`` + ``payload``
            (hex); we attach ``a2a_channel_id`` for plugin-side observability.
          - ``mls_welcome`` carries ``group_id`` + ``target_device_id`` +
            ``payload`` (hex); we attach ``target_hub_id`` + ``a2a_channel_id``
            for plugin-side observability.

        ``hub_to_device_id`` maps each hub_id in ``kp_by_hub_id`` to its
        device_id. When None, ``target_device_id`` is omitted — useful only
        in primitive-isolation tests; the orchestrator always provides it.

        Idempotent against empty input: no MLS mutation, no WS traffic.
        Caller persists MLS state AFTER this returns (orchestrator does so
        in :meth:`found_a2a_group`).
        """
        if not kp_by_hub_id:
            return

        kp_list = list(kp_by_hub_id.values())
        add_result = mls_state.add_members(kp_list)
        commit_bytes = add_result.commit
        welcome_bytes = add_result.welcome

        # Commit: broadcast to backend. epoch comes from the wrapper, which
        # advanced it as part of the self-applied commit (mls_group.py:653).
        commit_epoch = mls_state.epoch if hasattr(mls_state, "epoch") else 0
        await self._relay.send_json(
            {
                "event": "mls_commit",
                "data": {
                    "group_id": group_id,
                    "epoch": commit_epoch,
                    "payload": commit_bytes.hex(),
                    "a2a_channel_id": a2a_channel_id,
                },
            }
        )

        if welcome_bytes is None:
            logger.warning(
                "a2a: add_members for %s returned commit but no Welcome; "
                "members won't bootstrap",
                a2a_channel_id,
            )
            return

        # One Welcome blob -> N target events (backend dispatches per
        # target_device_id). We attach target_hub_id + a2a_channel_id for
        # observability even though the backend only reads target_device_id.
        for hub_id in kp_by_hub_id:
            data: dict[str, object] = {
                "group_id": group_id,
                "a2a_channel_id": a2a_channel_id,
                "target_hub_id": hub_id,
                "payload": welcome_bytes.hex(),
            }
            if hub_to_device_id is not None:
                device_id = hub_to_device_id.get(hub_id)
                if device_id:
                    data["target_device_id"] = device_id
            await self._relay.send_json(
                {"event": "mls_welcome", "data": data}
            )

    # --- Orchestrator ----------------------------------------------------

    async def found_a2a_group(
        self,
        channel_id: str,
        participants: list[A2AParticipant],
    ) -> None:
        """Found the MLS group for an A2A channel as the creator.

        Pipeline (matches spec §5.2):
          1. Batch-fetch participants' KeyPackages (primitive)
          2. If nothing fetched: mark pending, exit (reconcile retries)
          3. Register MLS group at backend (idempotent)
          4. Create local MLS state, persist it
          5. Add members in one commit, persist updated state, dispatch Welcomes
          6. Update registry with mls_group_id + creator_device_id + clear pending

        Ordering invariant: persist BEFORE Welcome dispatch. If we die between
        persist and send, Slice A's request_welcome path will refire the
        Welcome on member's next reconcile (Option A persistence model from
        spec §5.4).
        """
        entry = self._registry.get(channel_id)
        if entry is None:
            logger.warning(
                "a2a: found_a2a_group called for unknown channel %s; skipping",
                channel_id,
            )
            return

        async with self._rest_ctx() as rest:
            available, missing = await self._batch_fetch_keypackages(
                participants, rest=rest
            )

            if not available:
                entry.pending_kp_hub_ids = list(missing)
                self._save_registry()
                logger.warning(
                    "a2a: no KeyPackages available for any participant of "
                    "channel %s; deferred to reconcile retry. pending: %s",
                    channel_id,
                    missing,
                )
                return

            # Member set sent to backend init: self + everyone we have a KP for.
            hub_to_device_id: dict[str, str] = {}
            for hub_id in available:
                p = entry.participants.get(hub_id)
                if p is not None and p.device_id:
                    hub_to_device_id[hub_id] = p.device_id
            member_device_ids = [
                self._own_device_id, *hub_to_device_id.values()
            ]

            group_id = await rest.init_a2a_mls_group(
                channel_id=channel_id,
                member_device_ids=member_device_ids,
            )

        mls_state = self._create_mls_state()
        mls_state.create_group(group_id.encode())
        # Persist BEFORE Welcomes — see ordering invariant in docstring.
        await self._persist_mls_state(group_id, mls_state)

        await self._add_members_and_send_welcomes(
            mls_state=mls_state,
            group_id=group_id,
            a2a_channel_id=channel_id,
            kp_by_hub_id=available,
            hub_to_device_id=hub_to_device_id,
        )

        # Persist updated MLS state after add_members (epoch advanced).
        await self._persist_mls_state(group_id, mls_state)

        entry.mls_group_id = group_id
        entry.creator_device_id = self._own_device_id
        entry.pending_kp_hub_ids = list(missing)
        self._save_registry()

        logger.info(
            "a2a: founded MLS group %s for channel %s with %d members "
            "(%d pending KP)",
            group_id,
            channel_id,
            len(available),
            len(missing),
        )


__all__ = ["A2AFounder"]
