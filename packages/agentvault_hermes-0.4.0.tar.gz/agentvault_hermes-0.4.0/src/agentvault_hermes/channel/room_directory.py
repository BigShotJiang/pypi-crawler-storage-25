"""Room directory — the registry of multi-party rooms this agent belongs to.

A room is discovered from three independent sources, none of which alone is
complete:

- ``room_joined`` WS event — full metadata (name, members, conversation ids)
- ``GET /api/v1/rooms`` connect-time poll — name + members, no conversations
- an accepted MLS Welcome — ``room_id`` + ``mls_group_id`` only

``RoomDirectory`` merges all three into one ``RoomEntry`` per room. Every
upsert MERGES: a source that does not carry a field never clobbers a value a
prior source already set. This is why ``record_welcome`` (which knows only the
group id) can run before or after ``upsert_from_room_joined`` (which knows the
name) — order does not matter.

OC parity: OC keeps the equivalent state in ``_persisted.rooms`` keyed by bare
``roomId`` (``channel.ts``). Hermes isolates it here so ``SecureChannel`` does
not grow a fourth responsibility.
"""
from __future__ import annotations

import contextlib
import json
import logging
import os
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

_ROOMS_FILE_NAME = "rooms.json"
_ROOMS_VERSION = 1


@dataclass(frozen=True)
class RoomMember:
    """One member of a room.

    ``is_agent`` drives the mention-filter loop guard
    (``should_process_room_message``). It is derived from the backend
    member's ``entity_type``: anything that is not ``"owner"`` is treated as
    an agent, so an unrecognized entity_type fails safe toward loop-guarding.
    """

    device_id: str
    display_name: str
    is_agent: bool


@dataclass
class RoomEntry:
    """Everything the agent knows about one room.

    ``name`` / ``mls_group_id`` are Optional because the three discovery
    sources fill them at different times — see the module docstring.
    """

    room_id: str
    name: Optional[str] = None
    mls_group_id: Optional[str] = None
    members: dict[str, RoomMember] = field(default_factory=dict)
    conversation_ids: list[str] = field(default_factory=list)


def _members_from_backend(raw_members: list[dict[str, Any]]) -> dict[str, RoomMember]:
    """Convert a backend member list (``room_joined`` or ``RoomListItem``)
    into a ``device_id -> RoomMember`` map. Both backend shapes use the same
    field names: ``device_id``, ``entity_type``, ``display_name``.
    """
    out: dict[str, RoomMember] = {}
    for m in raw_members:
        did = str(m["device_id"])
        out[did] = RoomMember(
            device_id=did,
            display_name=str(m.get("display_name") or did),
            is_agent=(m.get("entity_type") != "owner"),
        )
    return out


class RoomDirectory:
    """In-memory registry of rooms, with disk persistence to ``rooms.json``."""

    def __init__(self) -> None:
        self._rooms: dict[str, RoomEntry] = {}

    def get(self, room_id: str) -> Optional[RoomEntry]:
        return self._rooms.get(room_id)

    def all(self) -> list[RoomEntry]:
        return list(self._rooms.values())

    def resolve_by_group_id(self, mls_group_id: str) -> Optional[RoomEntry]:
        """Reverse lookup MLS group id -> RoomEntry. Linear scan; the room
        count per agent is small (tens at most)."""
        for entry in self._rooms.values():
            if entry.mls_group_id == mls_group_id:
                return entry
        return None

    def upsert_from_room_joined(self, data: dict[str, Any]) -> RoomEntry:
        """Merge a ``room_joined`` WS event payload.

        Payload shape (``room_service.py:778-794``): ``{room_id, room_name,
        members: [...], conversations: [...]}``. Carries name + members +
        conversation ids; does NOT carry ``mls_group_id`` (preserved).
        """
        room_id = str(data["room_id"])
        entry = self._rooms.get(room_id) or RoomEntry(room_id=room_id)
        name = data.get("room_name")
        if name:
            entry.name = str(name)
        raw_members = data.get("members") or []
        if raw_members:
            entry.members = _members_from_backend(raw_members)
        convs = data.get("conversations") or []
        if convs:
            entry.conversation_ids = [str(c["id"]) for c in convs if c.get("id")]
        self._rooms[room_id] = entry
        return entry

    def upsert_from_poll(self, item: dict[str, Any]) -> RoomEntry:
        """Merge one ``RoomListItem`` from ``GET /api/v1/rooms``.

        Shape (``schemas/room.py``): ``{id, name, status, created_at,
        member_count, members: [RoomMemberInfo]}``. Carries name + members;
        does NOT carry conversations or ``mls_group_id`` (both preserved).
        """
        room_id = str(item["id"])
        entry = self._rooms.get(room_id) or RoomEntry(room_id=room_id)
        name = item.get("name")
        if name:
            entry.name = str(name)
        raw_members = item.get("members") or []
        if raw_members:
            entry.members = _members_from_backend(raw_members)
        self._rooms[room_id] = entry
        return entry

    def record_welcome(self, room_id: str, mls_group_id: str) -> RoomEntry:
        """Record that an MLS Welcome for ``room_id`` was accepted.

        Creates a minimal entry when the room is otherwise unknown so a
        Welcome that arrives before ``room_joined`` / the poll still makes
        the room routable. Name + members are preserved when already set.
        """
        entry = self._rooms.get(room_id) or RoomEntry(room_id=room_id)
        entry.mls_group_id = mls_group_id
        self._rooms[room_id] = entry
        return entry

    def save(self, data_dir: Path) -> None:
        """Atomically write the directory to ``data_dir/rooms.json`` (0o600).

        Mirrors the mkstemp + os.replace atomic-write pattern in
        ``crypto/persistence.py``.
        """
        payload = {
            "version": _ROOMS_VERSION,
            "rooms": [
                {
                    "room_id": e.room_id,
                    "name": e.name,
                    "mls_group_id": e.mls_group_id,
                    "members": [
                        {
                            "device_id": m.device_id,
                            "display_name": m.display_name,
                            "is_agent": m.is_agent,
                        }
                        for m in e.members.values()
                    ],
                    "conversation_ids": e.conversation_ids,
                }
                for e in self._rooms.values()
            ],
        }
        data_dir.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=data_dir, prefix=".rooms-", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(payload, fh)
            os.chmod(tmp, 0o600)
            os.replace(tmp, data_dir / _ROOMS_FILE_NAME)
        except BaseException:
            with contextlib.suppress(OSError):
                os.unlink(tmp)
            raise

    def load(self, data_dir: Path) -> None:
        """Load the directory from ``data_dir/rooms.json``.

        A missing file is normal (first run) — leaves the directory empty. A
        malformed file is logged at WARNING and skipped (degraded, not fatal
        — the three discovery sources repopulate on connect).
        """
        path = data_dir / _ROOMS_FILE_NAME
        if not path.exists():
            return
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                logger.warning(
                    "room_directory: %s is not a JSON object; ignoring", path
                )
                return
            if raw.get("version") != _ROOMS_VERSION:
                logger.warning(
                    "room_directory: unexpected version in %s; ignoring", path
                )
                return
            # Build into a local dict and commit all-or-nothing: a malformed
            # entry mid-list must not leave a half-populated directory.
            loaded: dict[str, RoomEntry] = {}
            for r in raw.get("rooms", []):
                entry = RoomEntry(
                    room_id=str(r["room_id"]),
                    name=r.get("name"),
                    mls_group_id=r.get("mls_group_id"),
                    members={
                        str(m["device_id"]): RoomMember(
                            device_id=str(m["device_id"]),
                            display_name=str(m["display_name"]),
                            is_agent=bool(m["is_agent"]),
                        )
                        for m in r.get("members", [])
                    },
                    conversation_ids=[str(c) for c in r.get("conversation_ids", [])],
                )
                loaded[entry.room_id] = entry
            self._rooms = loaded
        except (OSError, ValueError, KeyError, TypeError) as exc:
            logger.warning(
                "room_directory: failed to load %s: %s; starting empty",
                path,
                exc,
            )


__all__ = ["RoomDirectory", "RoomEntry", "RoomMember"]
