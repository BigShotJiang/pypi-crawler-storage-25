"""Inbox — inbound message dispatch + decrypt.

OC parity (line ranges are an index, not a contract — verify before
divergence per ``docs/plans/2026-05-10-hermes-phase3-implementation.md`` §5.1):

- ``packages/plugin/src/channel.ts:3407-3486`` — ``_handleMessageMLS``. The
  source-of-truth for routing, dedup, hex-decode, and the handshake-vs-
  application split.
- ``packages/plugin/src/channel.ts:3582-3863`` — ``_handleIncomingMessage``
  (DR fallback). Phase 3 stubs this per plan §0 out-of-scope.

Phase 3 surfaces ``handle_message_mls`` fully and ``handle_message_dr`` as a
log-and-drop stub. The orchestrator at ``secure_channel.SecureChannel._demux_loop``
lazy-imports both functions so the modules can ship in either order; once
WS-30 lands the import resolves to the real handlers and the stub_inbox
fixture in ``tests/unit/channel/test_secure_channel.py`` is no longer the
only thing keeping the orchestrator's tests green.

**Threading model:** asyncio-only. The module-level ``_seen_ids`` cache is
NOT thread-safe and MUST only be touched from the asyncio event loop thread
that the demux runs on. Cross-thread invocation would race
``OrderedDict.move_to_end`` / ``__setitem__`` / ``popitem`` and corrupt the
cache. WS-28a's DA review flagged the threading-model implication; Phase 3
ships single-loop-only and revisits in Phase 4 if multi-loop becomes a thing.

**Module-level cache scope:** ``_seen_ids`` is process-global. Two ``Relay``
instances in the same process (unlikely Phase 3, possible Phase 4
multi-account) would share the cache, keyed by resolved-conv-id. That is a
deliberate trade-off — see DA notes in plan §10.10.

**Binary plaintext caveat:** ``handle_message_mls`` decodes the decrypted
plaintext as UTF-8 with ``errors="replace"``. OC has ``MessageType.PHOTO``
etc. that may carry binary frames; Phase 3 demos text-only. Binary frames
will surface as mojibake. Phase 4 follow-up: pass through raw bytes for
non-text message types (DA #3 from plan §10.10).
"""
from __future__ import annotations

import asyncio
import contextlib
import logging
from collections import OrderedDict
from collections.abc import Awaitable, Callable, Coroutine
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Optional

from agentvault_hermes.channel.outbox import WireEnvelope
from agentvault_hermes.channel.secure_channel import InboundMessage
from agentvault_hermes.channel.telemetry import (
    MlsTelemetryEmitter,
    MlsTelemetryEvent,
    MlsTelemetryEventType,
)

if TYPE_CHECKING:
    from agentvault_hermes.crypto.mls_group import MlsGroupState

logger = logging.getLogger(__name__)


# Per-conversation seen-message-ids cache for dedup.
# OC dedups by client_message_id; if absent, by message_id (server-assigned).
# OrderedDict gives us proper LRU eviction (DA #9 — set-based "drop half"
# was approximate and unsound).
_seen_ids: dict[str, "OrderedDict[str, None]"] = {}
_SEEN_CACHE_MAX = 5000  # per-conversation cap


def _resolve_state(
    data: dict[str, Any],
    mls_states: dict[str, "MlsGroupState"],
    conv_to_group_id: dict[str, str],
) -> tuple[Optional[str], Optional["MlsGroupState"]]:
    """Multi-key routing — OC ``channel.ts:3416-3447``.

    Returns ``(key_in_mls_states, state)`` by trying:

    1. ``data["room_id"]`` — room MLS group key (room frames are authoritative).
    2. ``data["conversation_group_id"]`` — shared 1:1 group key.
    3. ``data["conversation_id"]`` — per-conversation key.
    4. ``data["group_id"]`` — search ``conv_to_group_id`` mapping for a
       matching value (reverse lookup).

    Returns ``(None, None)`` if no group is found.

    Note on the fourth branch: OC iterates over ``_persisted.mlsGroups`` and
    ``_persisted.mlsConversations`` separately; Hermes collapses both into
    a single ``conv_to_group_id`` map. The behavior is equivalent for the
    Phase 3 wire-format paths verified against ``ws.py:1063-1082``.
    """
    conv_group_id = data.get("conversation_group_id")
    conv_id = data.get("conversation_id")
    group_id = data.get("group_id")
    room_id = data.get("room_id")
    a2a_channel_id = data.get("a2a_channel_id")

    # room_id is authoritative — a room MLS group is keyed by room_id.
    if room_id and room_id in mls_states:
        state = mls_states[room_id]
        if state.is_initialized:
            return room_id, state

    # action #238: a2a_channel_id is parallel to room_id — an A2A MLS group
    # is keyed in mls_states by the bare a2a_channel_id.
    if a2a_channel_id and a2a_channel_id in mls_states:
        state = mls_states[a2a_channel_id]
        if state.is_initialized:
            return a2a_channel_id, state

    # Try conv_group_id first (shared 1:1 group key takes precedence).
    if conv_group_id and conv_group_id in mls_states:
        state = mls_states[conv_group_id]
        if state.is_initialized:
            return conv_group_id, state

    # Then conv_id (per-conversation key).
    if conv_id and conv_id in mls_states:
        state = mls_states[conv_id]
        if state.is_initialized:
            return conv_id, state

    # Then search conv_to_group_id for a matching group_id (reverse-lookup).
    if group_id:
        for k, gid in conv_to_group_id.items():
            if gid == group_id and k in mls_states:
                state = mls_states[k]
                if state.is_initialized:
                    return k, state

    return None, None


def _is_stale_kp_error(exc: Exception) -> bool:
    """True when the exception looks like an mls-rs key-package-missing
    error from join_from_welcome.

    action_item #161: matches the production signature from gateway log
    "A mls-rs error occurred: key package not found, unable to process".
    String-match is OK here — mls-rs-uniffi flattens its error taxonomy
    into a single MlsError type, so we can't catch a narrower class.

    Matched substrings (case-insensitive):
        - "key package not found"
        - "no key package"
    """
    msg = str(exc).lower()
    return "key package not found" in msg or "no key package" in msg


async def _fire_request_welcome(
    rest_base_url: str,
    device_jwt: str,
    group_id: str,
    own_device_id: str,
) -> None:
    """Fire-and-forget upstream request: ask AV-web to re-Welcome us with
    the current published KP.

    action_item #161: called from the MLS_WELCOME_PERMANENT_FAILURE catch
    when the failure looks like a stale KP. Errors are LOGGED at WARNING
    but never propagated — the caller (demux loop) must not block.

    Backend endpoint: POST /api/v1/mls/groups/{group_id}/request-welcome
    (packages/backend/app/api/v1/mls.py:270-390). Backend persists the
    request + broadcasts a mls_welcome_requested WS event to other group
    members. AV-web's use-chat 1:1 handler responds with a fresh
    addMembers commit+welcome (PR #183).
    """
    try:
        from agentvault_hermes.core.transport.rest_client import RestClient
        async with RestClient(
            base_url=rest_base_url,
            device_jwt=device_jwt,
        ) as client:
            await client.post(
                f"/api/v1/mls/groups/{group_id}/request-welcome",
                json={"device_id": own_device_id},
            )
            logger.info(
                "mls.request_welcome fired upstream (group=%s, device=%s)",
                group_id[:8],
                own_device_id[:8],
            )
    except Exception as exc:  # noqa: BLE001 — fire-and-forget contract
        logger.warning(
            "mls.request_welcome upstream call failed: %s — "
            "operator may need to manually retry the conversation",
            exc,
        )


async def handle_message_mls(
    envelope: WireEnvelope,
    mls_states: dict[str, "MlsGroupState"],
    own_device_id: str,
    *,
    conv_to_group_id: Optional[dict[str, str]] = None,
    send_locks: Optional[dict[str, asyncio.Lock]] = None,
) -> Optional[InboundMessage]:
    """Decrypt + dedup + filter own messages.

    Returns ``InboundMessage`` if the envelope is something the orchestrator
    needs to act on (either a fresh peer plaintext to surface OR a handshake
    message whose epoch advance must be persisted). Returns ``None`` for
    own echoes, duplicates, malformed payloads, decrypt failures, or unknown
    routing.

    The handshake path returns an ``InboundMessage`` (with ``is_handshake=True``,
    ``plaintext=""``, ``message_type="handshake"``) so the orchestrator's
    ``_demux_loop`` can persist the post-decrypt state. The orchestrator
    suppresses the agent surface for handshakes (verified in
    ``test_secure_channel.py``).

    OC parity: ``packages/plugin/src/channel.ts:3407-3486``
    (``_handleMessageMLS``).

    Args:
        envelope: Inbound ``{event:"message_mls", data:{...}}`` envelope.
        mls_states: Read-only view of the orchestrator's per-conv state map.
        own_device_id: This device's ID. Used for echo filtering.
        conv_to_group_id: Optional reverse-lookup map for the third routing
            branch. Defaults to an empty dict; pass the orchestrator's
            ``_conv_to_group_id`` to enable the ``group_id`` lookup path.
        send_locks: Per-conversation asyncio locks (the orchestrator's
            ``_conv_send_locks``). When provided, ``state.decrypt`` and the
            dedup-record post-step run inside ``send_locks[state_key]`` so
            they serialize against concurrent ``send()`` calls operating on
            the same ``MlsGroupState`` (action_item #156 — Welcome-support
            plan v3 P13 audit outcome b). Production callers in
            ``SecureChannel._demux_loop`` and ``_pull_delivery_queue`` MUST
            pass ``send_locks=self._conv_send_locks``. Tests that do not
            exercise encrypt/decrypt concurrency may omit this kwarg; the
            critical section then runs without a lock via
            ``contextlib.nullcontext()``.

    Returns:
        ``InboundMessage`` for handshake-or-plaintext frames; ``None`` for
        echoes, duplicates, malformed frames, or decrypt failures.

    Side effects:
        - Mutates module-level ``_seen_ids`` (asyncio-only — see module
          docstring).
        - Logs at ``WARNING`` for malformed / undecryptable / unrouted frames
          and at ``DEBUG`` for dedup hits and handshake messages.
    """
    data = envelope.data
    conv_to_group_id = conv_to_group_id or {}

    sender_device_id = data.get("sender_device_id")
    if sender_device_id == own_device_id:
        # Skip our own echo (OC channel.ts:3414).
        return None

    # Multi-key routing — OC channel.ts:3416-3447.
    state_key, state = _resolve_state(data, mls_states, conv_to_group_id)
    if state is None or state_key is None:
        cg = (data.get("conversation_group_id") or "")[:8]
        ci = (data.get("conversation_id") or "")[:8]
        gi = (data.get("group_id") or "")[:8]
        logger.warning(
            "inbox: no MLS group for message_mls (cg=%s, conv=%s, group=%s); dropping",
            cg,
            ci,
            gi,
        )
        return None

    # The conversation_id we surface to the orchestrator is the key under
    # which mls_states is indexed (could be conv_id OR conv_group_id).
    conv_id_for_callers = state_key

    # Dedup CHECK (post state-resolution so we don't bypass dedup on routing
    # miss). The msg_id is recorded only AFTER a successful decrypt — see DA
    # WS-30 finding #1: recording before decrypt poisons the cache on transient
    # decrypt failures, so a subsequent re-delivery of the same msg_id is
    # silently dropped and the message is permanently lost.
    msg_id = data.get("client_message_id") or data.get("message_id")
    seen: Optional[OrderedDict[str, None]] = None
    if msg_id is not None:
        seen = _seen_ids.setdefault(conv_id_for_callers, OrderedDict())
        if msg_id in seen:
            seen.move_to_end(msg_id)  # LRU touch
            logger.debug(
                "inbox: duplicate %s for %s, skipping",
                str(msg_id)[:8],
                conv_id_for_callers[:8],
            )
            return None

    # Decrypt — payload is hex-encoded per §3.7 / channel.ts:3455.
    payload_hex = data.get("payload")
    if not payload_hex:
        logger.warning(
            "inbox: message_mls missing payload for %s; dropping",
            conv_id_for_callers[:8],
        )
        return None
    try:
        ciphertext = bytes.fromhex(payload_hex)
    except (ValueError, TypeError) as e:
        logger.warning(
            "inbox: invalid hex payload for %s: %s",
            conv_id_for_callers[:8],
            e,
        )
        return None
    # Per-conv lock (action_item #156). When ``send_locks`` is provided,
    # serialize ``state.decrypt`` against concurrent ``send()`` calls on the
    # same ``MlsGroupState`` — the Rust state machine inside mls_rs_uniffi is
    # mutated by BOTH paths, and parallel decrypt+encrypt on a single state
    # is undefined behavior. The lock dict is shared with the orchestrator
    # (``SecureChannel._conv_send_locks``); we lazy-create the per-conv Lock
    # the first time a conversation is decrypted, matching ``send()``'s own
    # ``setdefault`` pattern at ``secure_channel.py:390``. Tests that don't
    # exercise concurrency may omit ``send_locks`` and the critical section
    # runs unlocked via ``contextlib.nullcontext()``.
    lock_ctx: contextlib.AbstractAsyncContextManager[Any]
    if send_locks is not None:
        lock_ctx = send_locks.setdefault(conv_id_for_callers, asyncio.Lock())
    else:
        lock_ctx = contextlib.nullcontext()

    async with lock_ctx:
        # Re-check dedup under the lock — a concurrent demux iteration that
        # decrypted the same msg_id while we waited would have recorded it
        # by the time we acquire. Matches ``handle_mls_welcome``'s
        # under-lock idempotency re-check pattern.
        if msg_id is not None and seen is not None and msg_id in seen:
            seen.move_to_end(msg_id)  # LRU touch
            logger.debug(
                "inbox: duplicate %s for %s (re-checked under lock), skipping",
                str(msg_id)[:8],
                conv_id_for_callers[:8],
            )
            return None

        try:
            result = state.decrypt(ciphertext)
        except Exception as e:  # noqa: BLE001 — broad catch is intentional
            # MlsGroupState raises specific types (decryption errors, replay,
            # epoch mismatch) but the demux must absorb ALL of them so a single
            # bad frame doesn't crash the WS loop. NOTE: we deliberately do NOT
            # record msg_id here — see dedup-CHECK comment above.
            logger.warning(
                "inbox: MLS decrypt failed for %s: %s",
                conv_id_for_callers[:8],
                e,
            )
            return None

        # Decrypt succeeded — record msg_id so subsequent re-deliveries of the
        # same message are deduped, but transient decrypt failures don't poison
        # the cache.
        if msg_id is not None and seen is not None:
            seen[msg_id] = None
            if len(seen) > _SEEN_CACHE_MAX:
                seen.popitem(last=False)  # evict oldest

    # Lock released. ``result`` is a value-type ``DecryptResult`` detached
    # from ``state`` (crypto/mls_group.py:62-66) — safe to use unlocked.

    sender_did_str = str(sender_device_id) if sender_device_id else ""

    if result.is_handshake:
        # Handshake messages don't surface to the agent — the MLS state
        # has already advanced its epoch internally. The orchestrator's
        # _demux_loop persists the updated state regardless of is_handshake
        # (DA #10 from plan §10.10).
        logger.debug(
            "inbox: handshake message for %s; epoch advanced",
            conv_id_for_callers[:8],
        )
        return InboundMessage(
            conversation_id=conv_id_for_callers,
            sender_device_id=sender_did_str,
            plaintext="",
            message_type="handshake",
            is_handshake=True,
            room_id=_str_or_none(data.get("room_id")),
            a2a_channel_id=_str_or_none(data.get("a2a_channel_id")),
            from_hub_address=_str_or_none(data.get("from_hub_address")),
            server_message_id=_str_or_none(data.get("message_id")),
            created_at=_str_or_none(data.get("created_at")),
            topic_id=_str_or_none(data.get("topic_id")),
            parent_span_id=_str_or_none(data.get("parent_span_id")),
        )

    # Surface to agent. ``result.plaintext`` is Optional[bytes]; on the
    # non-handshake path the wrapper guarantees bytes (see DecryptResult
    # docstring at crypto/mls_group.py:62-66) — raise loudly so a contract
    # regression surfaces rather than silently mojibaking. NOTE: must be an
    # explicit ``if/raise`` (not ``assert``) because ``python -O`` strips
    # asserts — DA WS-30 finding #2.
    if result.plaintext is None:
        raise RuntimeError(
            "MlsGroupState.decrypt returned plaintext=None on non-handshake result; "
            "this is a contract violation in mls_group.py"
        )
    plaintext = result.plaintext.decode("utf-8", errors="replace")
    return InboundMessage(
        conversation_id=conv_id_for_callers,
        sender_device_id=sender_did_str,
        plaintext=plaintext,
        message_type=str(data.get("message_type", "text")),
        is_handshake=False,
        room_id=_str_or_none(data.get("room_id")),
        a2a_channel_id=_str_or_none(data.get("a2a_channel_id")),
        from_hub_address=_str_or_none(data.get("from_hub_address")),
        server_message_id=_str_or_none(data.get("message_id")),
        created_at=_str_or_none(data.get("created_at")),
        topic_id=_str_or_none(data.get("topic_id")),
        parent_span_id=_str_or_none(data.get("parent_span_id")),
    )


@dataclass(frozen=True)
class WelcomeOutcome:
    """Result of ``handle_mls_welcome`` — drives caller's ack/nack/republish.

    Caller behavior matrix (per plan §3.4 P6/P7/P3):

    - ``joined=True``                  → caller ack's the queue_id AND
                                         schedules a fire-and-forget
                                         ``_ensure_pending_key_package``
                                         on ``secure_channel._republish_task``
                                         (Stage 4 wiring).
    - ``joined=False, drop=True``      → caller ack's the queue_id (idempotent
                                         duplicate, malformed payload,
                                         out-of-routing-scope, or permanent
                                         join failure per P7+P14).
    - ``joined=False, drop=False``     → caller nack's the queue_id (genuinely
                                         retryable). Reserved for future
                                         extensions; current Stage 4 paths
                                         all return drop=True.
    """

    joined: bool
    drop: bool
    routing_key: Optional[str] = None


async def handle_mls_welcome(
    envelope: WireEnvelope,
    mls_states: dict[str, "MlsGroupState"],
    *,
    pending_kp_state: Optional["MlsGroupState"],
    own_device_id: str,
    conv_to_group_id: dict[str, str],
    send_locks: dict[str, asyncio.Lock],
    persist_state: Callable[[str, "MlsGroupState"], Awaitable[None]],
    clear_pending_kp_state: Callable[[], None],
    rest_base_url: Optional[str] = None,
    device_jwt: Optional[str] = None,
    welcome_request_callable: Optional[
        Callable[[str], Coroutine[Any, Any, None]]
    ] = None,
    telemetry: Optional["MlsTelemetryEmitter"] = None,
) -> WelcomeOutcome:
    """Process an inbound MLS Welcome row.

    Plan §3.4 step-by-step. Returns ``WelcomeOutcome`` driving the caller's
    ack/nack/republish behavior:

      - ``joined=True``                  → caller acks queue_id AND
                                           schedules fire-and-forget
                                           ``_ensure_pending_key_package``
                                           on ``self._republish_task``
                                           (P3 republish, P16+P21
                                           cancel-and-replace).
      - ``joined=False, drop=True``      → caller acks queue_id (idempotent,
                                           malformed, OOS routing, or
                                           permanent join failure per
                                           P7 + P14 ERROR-log marker).
      - ``joined=False, drop=False``     → caller nacks queue_id
                                           (genuinely retryable; reserved).

    Lock-ordering invariant (P24): this handler acquires
    ``send_locks[routing_key]`` for its writes (step 6 → 15). The caller's
    fire-and-forget republish task (which acquires
    ``secure_channel._kp_publish_lock``) is scheduled AFTER this handler
    returns and the per-conv lock is released. No code path holds
    ``send_locks[*]`` while acquiring ``_kp_publish_lock``.

    OC parity (P27 — three branches at channel.ts:4940/4958/4988); none
    of them republish from inside the handler (Hermes diverges via
    caller-side fire-and-forget per P3).

    ``rest_base_url``: base URL of the AV REST API (e.g.
      ``https://api.agentvault.chat``). Required for stale-KP recovery
      fallback path; defaults to None (disables recovery when no
      ``welcome_request_callable`` either).
    ``device_jwt``: bearer token for the registered device. Required for
      stale-KP recovery fallback path; defaults to None.
    ``welcome_request_callable`` (PR-3, Phase 4a): optional async callable
      ``async def f(group_id: str) -> None`` that the orchestrator passes to
      embed inflight-dedup around request-welcome POST firing. When
      provided, it is invoked INSTEAD OF the module-level
      ``_fire_request_welcome`` for the stale-KP recovery path; the
      orchestrator's callable handles the dedup contract. When ``None``
      (e.g. older tests that don't construct a full SecureChannel), falls
      back to firing ``_fire_request_welcome`` directly with the
      module-level args.
    ``telemetry`` (PR-4b-A1, Phase 4b): optional ``MlsTelemetryEmitter``
      that the orchestrator passes so welcome-handler emit sites can
      publish structured events alongside the existing MLS_* operator-grep
      log lines. When ``None`` (older tests that don't construct a full
      SecureChannel), emit calls are skipped via the ``if telemetry is not
      None`` guard. Three emit sites are wired:
      ``WELCOME_PERMANENT_FAILURE`` when ``pending_kp_state is None``
      (cross-restart KP loss), ``WELCOME_PERMANENT_FAILURE`` when
      ``join_from_welcome`` raises, and ``JOINED`` on the success-return
      path. Emit failures are absorbed by the emitter (see
      ``telemetry.py``); telemetry never raises into this caller.
    """
    # Local import to avoid module-load circular deps.
    from agentvault_hermes.crypto.mls_group import (
        MlsGroupAlreadyInitializedError,
    )

    data = envelope.data

    sender_device_id = data.get("sender_device_id")
    own_echo = sender_device_id == own_device_id
    if own_echo:
        # OC parity: backend includes our own writes in the queue. Ack
        # without re-processing.
        return WelcomeOutcome(joined=False, drop=True)

    # action #238: a2a_channel_id is authoritative for A2A Welcomes —
    # parallel to room_id for rooms (Phase 4a/#234) — keyed in mls_states by
    # the bare a2a_channel_id. The prior out-of-scope ack+drop guard is gone.
    routing_key: Optional[str] = (
        data.get("a2a_channel_id")
        or data.get("room_id")
        or data.get("conversation_group_id")
        or data.get("conversation_id")
    )
    if not routing_key:
        logger.warning(
            "inbox.welcome: no a2a_channel_id or room_id or conversation_group_id "
            "or conversation_id; ack+drop"
        )
        return WelcomeOutcome(joined=False, drop=True)

    group_id = data.get("group_id") or ""

    # Idempotency check (P6): if we've already initialized this routing
    # key, this is a duplicate Welcome row. Ack so the queue doesn't
    # recycle forever.
    existing = mls_states.get(routing_key)
    if existing is not None and existing.is_initialized:
        logger.debug(
            "inbox.welcome: routing_key=%s already initialized; idempotent ack+drop",
            routing_key[:8],
        )
        return WelcomeOutcome(joined=False, drop=True, routing_key=routing_key)

    # KP-bundle resolve. In-memory only (P5 — no disk fallback).
    if pending_kp_state is None:
        # Should be unreachable: start() always populates _pending_kp_state
        # before the first pull (Seam B P2). If reached, the KP that the
        # owner encrypted to is gone (cross-restart loss). Ack-and-log
        # so the row doesn't dead-letter into infinite retries.
        logger.error(
            "MLS_WELCOME_PERMANENT_FAILURE: pending_kp_state is None "
            "exc_type=NoBundle group_id=%s routing_key=%s reason=%s",
            group_id[:8] if group_id else "<unknown>",
            routing_key[:8],
            "KP bundle missing — likely process restart between publish and Welcome",
        )
        if telemetry is not None:
            await telemetry.emit(
                MlsTelemetryEvent(
                    event=MlsTelemetryEventType.WELCOME_PERMANENT_FAILURE,
                    group_id=group_id or None,
                    context={"reason": "pending_kp_state_none"},
                )
            )
        return WelcomeOutcome(joined=False, drop=True, routing_key=routing_key)

    # Per-conv lock (P8). Hold across all subsequent state mutation.
    lock = send_locks.setdefault(routing_key, asyncio.Lock())
    async with lock:
        # Re-check idempotency under the lock — a concurrent Welcome
        # processed between the early check and lock acquire would have
        # populated mls_states[routing_key].
        existing = mls_states.get(routing_key)
        if existing is not None and existing.is_initialized:
            logger.debug(
                "inbox.welcome: routing_key=%s initialized under lock; ack+drop",
                routing_key[:8],
            )
            return WelcomeOutcome(joined=False, drop=True, routing_key=routing_key)

        # Decode hex payload.
        payload_hex = data.get("payload")
        if not payload_hex:
            logger.warning(
                "inbox.welcome: missing payload for routing_key=%s; ack+drop",
                routing_key[:8],
            )
            return WelcomeOutcome(
                joined=False, drop=True, routing_key=routing_key
            )
        try:
            welcome_bytes = bytes.fromhex(payload_hex)
        except (ValueError, TypeError) as exc:
            logger.warning(
                "inbox.welcome: invalid hex payload for routing_key=%s: %s; ack+drop",
                routing_key[:8],
                exc,
            )
            return WelcomeOutcome(
                joined=False, drop=True, routing_key=routing_key
            )

        # join_from_welcome — P7 exception handling.
        try:
            pending_kp_state.join_from_welcome(welcome_bytes)
        except MlsGroupAlreadyInitializedError:
            logger.debug(
                "inbox.welcome: pending_kp_state already initialized for routing_key=%s; idempotent ack+drop",
                routing_key[:8],
            )
            return WelcomeOutcome(
                joined=False, drop=True, routing_key=routing_key
            )
        except Exception as exc:  # noqa: BLE001 — see P14 below
            # P14 logging discipline: ERROR (not WARNING) because this is
            # a permanent-failure-from-owner-POV event. Owner waits forever
            # for an agent that silently dropped their Welcome. The
            # MLS_WELCOME_PERMANENT_FAILURE literal is the operator-grep
            # contract. Phase 4 replaces with structured telemetry per
            # action_item #157.
            logger.error(
                "MLS_WELCOME_PERMANENT_FAILURE: join_from_welcome raised "
                "exc_type=%s group_id=%s routing_key=%s reason=%s",
                type(exc).__name__,
                group_id[:8] if group_id else "<unknown>",
                routing_key[:8],
                str(exc)[:200],
            )
            # action_item #161: if the failure indicates a stale KP, fire an
            # upstream request_welcome so AV-web re-runs addMembers with our
            # current published KP. Fire-and-forget so the demux loop continues
            # processing subsequent rows.
            if _is_stale_kp_error(exc) and group_id:
                if welcome_request_callable is not None:
                    # PR-3: orchestrator-provided callable embeds the
                    # inflight-dedup contract. Both this stale-KP
                    # recovery path AND the cold-start scan path route
                    # through the same dedup.
                    asyncio.create_task(welcome_request_callable(group_id))
                elif (
                    rest_base_url is not None
                    and device_jwt is not None
                ):
                    # Fallback for callers that don't supply a callable
                    # (e.g. tests that don't build a full SecureChannel).
                    # Preserves PR #184 behavior.
                    asyncio.create_task(
                        _fire_request_welcome(
                            rest_base_url=rest_base_url,
                            device_jwt=device_jwt,
                            group_id=group_id,
                            own_device_id=own_device_id,
                        )
                    )
            if telemetry is not None:
                # This emit sits inside the per-conv send_lock acquired earlier in this
                # handler. The lock-held emit is bounded: the failure path is terminal
                # (the WelcomeOutcome.drop=True return immediately follows, releasing the
                # lock), and MlsTelemetryEmitter.emit absorbs RuntimeError-class send
                # failures so a backed-up WS write buffer is the only stall vector. Other
                # routing_keys are processed serially in the pull-loop, so the practical
                # blast radius is one row's delay.
                await telemetry.emit(
                    MlsTelemetryEvent(
                        event=MlsTelemetryEventType.WELCOME_PERMANENT_FAILURE,
                        group_id=group_id or None,
                        context={
                            "reason": "join_from_welcome_raised",
                            "error_class": type(exc).__name__,
                        },
                    )
                )
            # P7: ack-not-nack. Broken Welcomes don't get less broken on
            # retry; 5 nacks dead-letter the row, which means the row IS
            # lost regardless. Ack-and-log accepts the loss without
            # amplifying load.
            return WelcomeOutcome(
                joined=False, drop=True, routing_key=routing_key
            )

        # P9: conv_to_group_id write check. The post-join group_id
        # (bytes) is canonicalized to UUID-string for parity with the
        # send-path's conv_to_group_id values.
        from uuid import UUID

        post_join_group_id_bytes = pending_kp_state.group_id
        try:
            if len(post_join_group_id_bytes) == 16:
                group_id_str = str(UUID(bytes=post_join_group_id_bytes))
            elif len(post_join_group_id_bytes) == 36:
                # AV-web (and OC) encode the UUID-string as UTF-8 (36 bytes).
                # Mirror secure_channel.py:443-459 to keep both code paths in
                # sync. action_item #177: previously fell through to .hex()
                # producing an invalid 72-char hex blob the backend rejected.
                group_id_str = post_join_group_id_bytes.decode("ascii")
                UUID(group_id_str)  # validate it parses as a UUID
            else:
                raise ValueError(
                    f"unexpected group_id length: {len(post_join_group_id_bytes)} "
                    f"(expected 16 or 36)"
                )
        except (ValueError, TypeError, UnicodeDecodeError):
            # Fallback for any path that raises above:
            #   - explicit ValueError from the else-branch (unexpected length)
            #   - UnicodeDecodeError from non-ASCII 36-byte input
            #   - ValueError from a 36-byte ASCII string that isn't a valid UUID
            # Mirrors OC's permissive group_id treatment. Landing here for an
            # AV-web peer indicates a deeper interop bug — action_item #177's
            # canary should fire via the demux WARNING handler in that case.
            group_id_str = post_join_group_id_bytes.hex()

        existing_group_id = conv_to_group_id.get(routing_key)
        if existing_group_id is not None and existing_group_id != group_id_str:
            logger.warning(
                "inbox.welcome: conv_to_group_id mismatch for routing_key=%s "
                "(existing=%s new=%s); ack+drop without overwrite",
                routing_key[:8],
                existing_group_id[:8] if isinstance(existing_group_id, str) else existing_group_id,
                group_id_str[:8],
            )
            return WelcomeOutcome(
                joined=False, drop=True, routing_key=routing_key
            )
        conv_to_group_id[routing_key] = group_id_str

        # Move state into mls_states. Atomic per-conv-lock-protected.
        mls_states[routing_key] = pending_kp_state

        # Persist via callback. Awaited under the lock so a crash
        # between persist completion and clear_pending_kp_state leaves
        # disk consistent with memory.
        await persist_state(routing_key, pending_kp_state)

        # Clear pending KP state — next _ensure_pending_key_package will
        # regenerate. The fire-and-forget republish (caller-scheduled)
        # races with this clear; that's intentional — both paths converge
        # on a fresh KP being published before the next Welcome can race.
        clear_pending_kp_state()

    # action_item #159 — operator visibility on the Welcome success path.
    # Phase 3 acceptance #1's expected log string was "Joined 1:1 MLS group
    # for conv … via Welcome"; the original WS-30 implementation emitted
    # only ERROR/WARNING on failures. group_id is short-prefixed to keep
    # the line readable while still allowing operators to correlate with
    # the upstream "MLS delivery pull" log emitted by _pull_delivery_queue.
    logger.info(
        "Joined MLS group via Welcome (routing_key=%s, group_id=%s)",
        routing_key[:8],
        group_id_str[:8] if group_id_str else "<unknown>",
    )

    if telemetry is not None:
        # Symmetric with the PERMANENT_FAILURE sites' `group_id or None` so empty-string
        # never reaches downstream consumers. Today `group_id_str` is structurally
        # non-empty for the success path (UUID-bytes canonicalize to a 36-char string),
        # but the fallback `b"".hex()` branch in the canonicalization code above can
        # theoretically produce ""; this guard keeps wire-format consistent.
        await telemetry.emit(
            MlsTelemetryEvent(
                event=MlsTelemetryEventType.JOINED,
                group_id=group_id_str or None,
                context={},
            )
        )

    # Lock released. Caller schedules fire-and-forget republish per
    # WelcomeOutcome.joined=True (P3 + P16 + P21 + P24 invariant).
    return WelcomeOutcome(joined=True, drop=False, routing_key=routing_key)


async def handle_message_dr(envelope: WireEnvelope) -> None:
    """DR fallback — Phase 3 stub per plan §0 out-of-scope.

    OC parity: ``packages/plugin/src/channel.ts:3582-3863``. Phase 4 will
    wire this up using the WS-22 ratchet API.

    Logs at ``INFO`` (not ``WARNING``) because a DR-fallback frame is not
    an error condition — it is an OC peer that hasn't migrated to MLS yet.
    The drop is expected behavior in Phase 3.
    """
    conv_id = envelope.data.get("conversation_id", "<unknown>")
    conv_id_short = conv_id[:8] if isinstance(conv_id, str) else "<unknown>"
    logger.info(
        "inbox: DR fallback received for %s but not yet handled "
        "(Phase 3 ships MLS only); dropping",
        conv_id_short,
    )


def _str_or_none(value: Any) -> Optional[str]:
    """Coerce a JSON value to ``Optional[str]`` for ``InboundMessage`` fields.

    The wire envelope's ``data`` is ``dict[str, Any]``; pass-throughs that
    land on ``InboundMessage``'s typed string-or-None fields need to be
    coerced or strict-mypy would have no idea whether an ``int`` snuck in.
    None propagates as None; non-None values are stringified.
    """
    if value is None:
        return None
    return str(value)


__all__ = [
    "WelcomeOutcome",
    "handle_message_dr",
    "handle_message_mls",
    "handle_mls_welcome",
]
