"""A2A sync lock file — verbatim translation from OpenClaw.

Source: ``packages/plugin/src/mls-state.ts:8-68``. Hermes Phase 3 WS-28a.

Why this exists:
    Multiple gateway processes (or restarts mid-Welcome) can race on
    A2A MLS state. OC uses a per-channel lock file with atomic
    exclusive-create semantics + a 5-minute staleness threshold so a
    crashed gateway doesn't permanently wedge subsequent runs.

Why ``time.time()`` (not ``time.monotonic()``):
    The lock file's timestamp must be comparable across processes /
    across reboots — ``monotonic()`` is process-local and undefined
    across process boundaries. Wall-clock is correct here even though
    it's wrong for the loop preventer's sliding window. (See OC
    ``mls-state.ts:30,40`` — uses ``Date.now()`` for the same reason.)

Phase 3 ships this module for hygiene — ``SecureChannel.stop()``
releases any locks held by the orchestrator. Phase 4 wires it into the
A2A multi-party flows that actually need it.

See ``docs/plans/2026-05-10-hermes-phase3-implementation.md`` §4.4 / §8.5.
"""
from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Final

_FILE_MODE: Final[int] = 0o600
_DIR_MODE: Final[int] = 0o700
_SYNC_LOCK_STALE_SECONDS: Final[float] = 5 * 60.0
_SAFE_RE = re.compile(r"[^a-zA-Z0-9_-]")


def _sync_lock_path(data_dir: Path, channel_id: str) -> Path:
    """Resolve the absolute lock-file path for a given channel id.

    Source: OC ``mls-state.ts:9-12`` (``syncLockPath``). The unsafe
    characters are collapsed to ``_`` so any UUID/URI works as a
    filename component.
    """
    safe = _SAFE_RE.sub("_", channel_id)
    return data_dir / f"mls-a2a-sync-{safe}.lock"


def acquire_a2a_sync_lock(data_dir: Path, channel_id: str) -> bool:
    """Atomic exclusive-create lock with 5-min stale cleanup.

    Returns True on acquire, False if another instance holds the lock.

    Source: OC ``mls-state.ts:24-55`` (``acquireA2ASyncLock``).

    Implementation notes:
    - ``os.open(..., O_CREAT | O_EXCL | O_WRONLY, _FILE_MODE)`` is the
      Python equivalent of Node's ``writeFile(..., { flag: "wx" })``
      and is atomic w.r.t. concurrent racers (only one wins).
    - On ``FileExistsError`` we read the existing lock; if its
      ``timestamp`` is more than 5 minutes old we treat the lock as
      stale, ``unlink`` it, and retry the create exactly once. A
      second racer arriving between unlink and retry causes the retry
      to ``FileExistsError`` and we yield (return False).
    - The data dir is created if missing with mode 0o700.
    """
    data_dir.mkdir(parents=True, exist_ok=True, mode=_DIR_MODE)
    lock_file = _sync_lock_path(data_dir, channel_id)
    payload = json.dumps({"pid": os.getpid(), "timestamp": time.time()})
    try:
        # Python equivalent of Node 'wx' flag — O_CREAT | O_EXCL | O_WRONLY
        fd = os.open(
            str(lock_file),
            os.O_CREAT | os.O_EXCL | os.O_WRONLY,
            _FILE_MODE,
        )
        try:
            os.write(fd, payload.encode("utf-8"))
            return True
        finally:
            os.close(fd)
    except FileExistsError:
        # Lock exists — check staleness
        try:
            raw = lock_file.read_text(encoding="utf-8")
            parsed = json.loads(raw)
            ts = parsed.get("timestamp")
            if (
                isinstance(ts, (int, float))
                and time.time() - ts > _SYNC_LOCK_STALE_SECONDS
            ):
                # Stale lock — clean up and retry once
                try:
                    lock_file.unlink()
                except FileNotFoundError:
                    pass
                try:
                    fd = os.open(
                        str(lock_file),
                        os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                        _FILE_MODE,
                    )
                    try:
                        os.write(fd, payload.encode("utf-8"))
                    finally:
                        os.close(fd)
                    return True
                except FileExistsError:
                    # Another instance beat us to it
                    return False
        except (OSError, json.JSONDecodeError):
            # Can't read or parse — treat as held (OC mls-state.ts:50-52)
            pass
        return False


def release_a2a_sync_lock(data_dir: Path, channel_id: str) -> None:
    """Release the channel-level A2A sync lock.

    Idempotent — no error if the lock file does not exist.

    Source: OC ``mls-state.ts:61-68`` (``releaseA2ASyncLock``).
    """
    try:
        _sync_lock_path(data_dir, channel_id).unlink()
    except FileNotFoundError:
        pass


__all__ = [
    "acquire_a2a_sync_lock",
    "release_a2a_sync_lock",
]
