"""Outbound wire envelope schema for the AgentVault WebSocket.

This module is the canonical Python translation of the OC TypeScript
plugin's outbound MLS envelope, derived **verbatim** from
``packages/plugin/src/channel.ts:665-689``.

The Tier-3 spike at ``_spike/phase3_e2e/tier3_live_transport.py:49-102``
shipped a stand-in (``ciphertext``/base64) that did NOT match the on-the-wire
shape. The schema here matches the AgentVault backend reader at
``packages/backend/app/api/v1/ws.py:1063-1082``, which does
``bytes.fromhex(data["payload"])`` and rejects messages missing
``group_id`` or ``payload``.

Required outbound fields (per OC source + backend reader):
    - ``conversation_id``
    - ``group_id``
    - ``epoch``
    - ``payload`` (HEX-encoded ciphertext, NOT base64)
    - ``message_type``

Always emitted (None when caller does not override, except ``priority``
which defaults to ``"normal"`` per OC ``channel.ts:562``):
    - ``topic_id``
    - ``client_message_id``
    - ``priority`` (defaults to ``"normal"``)
    - ``parent_span_id``
    - ``metadata``

Conditionally emitted (only when truthy, per OC ``channel.ts:679-684``):
    - ``hub_address``
    - ``sender_hub_id``

INTENTIONALLY ABSENT: ``sender_device_id``. The AV backend stamps this from
the authenticated WebSocket session (see ``ws.py:1063-1082``); including it
on the outbound envelope diverges from OC parity and is silently ignored.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any


@dataclass
class WireEnvelope:
    """Outer ``{event, data}`` envelope sent over the AV WebSocket.

    Source-of-truth: ``packages/plugin/src/channel.ts:685-689`` (outbound)
    and ``packages/plugin/src/channel.ts:3582-3596`` (inbound).

    ``event`` is one of ``"message_mls"`` (primary, MLS), ``"message"`` (DR
    fallback — Phase 3 stub), or ``"room_message_mls"`` /
    ``"a2a_message_mls"`` (Phase 4+).
    """

    event: str
    data: dict[str, Any]

    def to_json(self) -> str:
        """Serialize to a UTF-8 JSON string.

        Uses ``json.dumps`` with default settings — ``ensure_ascii=True`` —
        which matches the JS ``JSON.stringify`` behavior on the OC side
        for the byte-shape of pure-ASCII payloads. Non-ASCII characters in
        ``metadata`` are escaped as ``\\uXXXX``; ``from_json`` round-trips
        them losslessly.
        """
        return json.dumps({"event": self.event, "data": self.data})

    @classmethod
    def from_json(cls, raw: str) -> "WireEnvelope":
        """Parse a JSON envelope. Raises on malformed input.

        Strictness matches the OC peer: a missing ``event`` or ``data`` key
        is a programming error and surfaces as ``KeyError``. Malformed JSON
        surfaces as ``json.JSONDecodeError``. Callers that need lenient
        parsing should validate first.
        """
        parsed = json.loads(raw)
        if not isinstance(parsed, dict):
            raise TypeError(
                f"WireEnvelope.from_json expected JSON object, got {type(parsed).__name__}"
            )
        event = parsed["event"]
        data = parsed["data"]
        if not isinstance(data, dict):
            raise TypeError(
                f"WireEnvelope.from_json expected 'data' as object, got {type(data).__name__}"
            )
        return cls(event=event, data=data)


def make_outbound_mls_envelope(
    conversation_id: str,
    group_id: str,
    epoch: int,
    ciphertext: bytes,
    *,
    topic_id: str | None = None,
    client_message_id: str | None = None,
    message_type: str = "text",
    priority: str = "normal",
    parent_span_id: str | None = None,
    metadata: dict[str, Any] | None = None,
    hub_address: str | None = None,
    sender_hub_id: str | None = None,
    event: str = "message_mls",
    room_id: str | None = None,
) -> WireEnvelope:
    """Build the outbound ``message_mls`` envelope.

    Field order, presence, and encoding are byte-identical to OC at
    ``packages/plugin/src/channel.ts:665-689``.

    Args:
        conversation_id: AV conversation UUID (string form).
        group_id: MLS group UUID (string form). REQUIRED — backend rejects
            messages missing this (``ws.py:1067``).
        epoch: Current MLS group epoch as an integer. JS-side OC uses
            ``Number(mls.epoch)``, so values >2**53 lose precision on the
            JS peer; not a concern at any realistic Phase-3 traffic level.
        ciphertext: MLS-encrypted application message bytes. Encoded as
            lowercase hex via ``bytes.hex()`` per OC ``channel.ts:669``
            (``Buffer.from(cipherBytes).toString("hex")``). The backend
            decodes via ``bytes.fromhex`` (``ws.py:1076``).
        topic_id: Optional thread/topic UUID.
        client_message_id: Optional client-generated UUID for dedup.
        message_type: ``"text"`` (default), ``"file"``, etc.
        priority: Routing priority. OC at ``channel.ts:562`` resolves to
            ``"normal"`` when the caller does not override. The backend
            stores this verbatim, so emitting ``null`` would produce a
            different DB row than an OC peer's message — defaulting to
            ``"normal"`` here matches OC parity.
        parent_span_id: Optional tracing span ID for telemetry parenting.
        metadata: Optional arbitrary metadata dict.
        hub_address: Optional federation hub URL. Emitted only when
            truthy, matching OC ``channel.ts:679-681``.
        sender_hub_id: Optional federation hub ID. Emitted only when
            truthy, matching OC ``channel.ts:682-684``.
        event: WS event name. ``"message_mls"`` (default) for 1:1;
            ``"room_message_mls"`` for room messages.
        room_id: Room UUID. Emitted in ``data`` only when truthy; set
            together with ``event="room_message_mls"`` for a room reply.

    Returns:
        ``WireEnvelope`` with the specified ``event`` (default
        ``"message_mls"``).

    Note:
        ``sender_device_id`` is INTENTIONALLY not part of this signature.
        The AV backend stamps it from the authenticated WS session; sending
        it on outbound MLS would diverge from OC parity and is ignored by
        the backend reader.
    """
    data: dict[str, Any] = {
        "conversation_id": conversation_id,
        "group_id": group_id,
        "epoch": epoch,
        "payload": ciphertext.hex(),
        "topic_id": topic_id,
        "client_message_id": client_message_id,
        "message_type": message_type,
        "priority": priority,
        "parent_span_id": parent_span_id,
        "metadata": metadata,
    }
    if hub_address:
        data["hub_address"] = hub_address
    if sender_hub_id:
        data["sender_hub_id"] = sender_hub_id
    if room_id:
        data["room_id"] = room_id
    return WireEnvelope(event=event, data=data)
