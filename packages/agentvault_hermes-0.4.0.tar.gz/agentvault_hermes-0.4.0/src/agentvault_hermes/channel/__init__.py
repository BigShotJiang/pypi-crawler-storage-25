"""``agentvault_hermes.channel`` — channel orchestrator + wire envelope.

Phase 3 (WS-28..WS-35) lives here. WS-33 landed the outbound wire envelope
(``outbox`` module). WS-28a added the verbatim-from-OC primitives:
``loop_prevention`` (per-key reply rate limiter) and ``lock_file`` (A2A
sync lock). WS-28b added ``secure_channel`` (the SecureChannel
orchestrator + ``InboundMessage`` dataclass). WS-30 lands ``inbox``
(inbound dispatch + decrypt) and ``mention`` (room-message routing
helpers).
"""
from agentvault_hermes.channel.inbox import (
    handle_message_dr,
    handle_message_mls,
)
from agentvault_hermes.channel.lock_file import (
    acquire_a2a_sync_lock,
    release_a2a_sync_lock,
)
from agentvault_hermes.channel.loop_prevention import LoopPreventer
from agentvault_hermes.channel.mention import (
    parse_mentions,
    should_process_room_message,
    strip_mentions,
)
from agentvault_hermes.channel.outbox import (
    WireEnvelope,
    make_outbound_mls_envelope,
)
from agentvault_hermes.channel.secure_channel import (
    InboundMessage,
    SecureChannel,
)

__all__ = [
    "InboundMessage",
    "LoopPreventer",
    "SecureChannel",
    "WireEnvelope",
    "acquire_a2a_sync_lock",
    "handle_message_dr",
    "handle_message_mls",
    "make_outbound_mls_envelope",
    "parse_mentions",
    "release_a2a_sync_lock",
    "should_process_room_message",
    "strip_mentions",
]
