"""Per-conversation reply rate limiter — verbatim translation from OpenClaw.

Source: ``packages/plugin/src/openclaw-entry.ts:37-88``. Hermes Phase 3
WS-28a. The OC implementation rate-limits agent replies on a sliding
4-replies-per-60s window with a 120s cooldown after the limit is hit; the
goal is to prevent runaway A2A / room loops where two agents amplify each
other indefinitely.

Why ``time.monotonic()`` (not ``time.time()``):
    OC uses ``Date.now()`` which is wall-clock and jumps on NTP sync /
    daylight-saving / suspend-resume. For a 60s sliding window on a
    long-running daemon that is a known foot-gun. Python idiom is to
    use ``time.monotonic()`` for any "elapsed time within a process"
    measurement. Semantics are identical for non-pathological clocks.

Phase 3 ships only the rate limiter primitive; the orchestrator
(``channel/secure_channel.py``, WS-28b) wires it into the send path.

See ``docs/plans/2026-05-10-hermes-phase3-implementation.md`` §4.3 / §8.4.
"""
from __future__ import annotations

import time
from typing import Final

LOOP_MAX_REPLIES_PER_WINDOW: Final[int] = 4
LOOP_WINDOW_SECONDS: Final[float] = 60.0
LOOP_COOLDOWN_SECONDS: Final[float] = 120.0


class LoopPreventer:
    """Per-key sliding-window reply rate limiter.

    A "key" is a namespaced conversation identifier such as
    ``f"a2a:{channel_id}"`` or ``f"room:{room_id}"`` (see helper methods
    below). Distinct keys are independent — the rate limit on
    ``a2a:foo`` does not affect ``room:bar``.

    Source: ``packages/plugin/src/openclaw-entry.ts:37-88``.
    """

    def __init__(self) -> None:
        self._reply_timestamps: dict[str, list[float]] = {}
        self._cooldown_until: dict[str, float] = {}

    def can_reply(self, key: str) -> bool:
        """Return True if a reply on ``key`` is currently allowed.

        Mirrors OC ``_canReply`` (openclaw-entry.ts:47-72). If the key
        is in cooldown, returns False without modifying state. If the
        sliding window already holds ``LOOP_MAX_REPLIES_PER_WINDOW``
        recent timestamps, enters cooldown (resets timestamps, sets
        cooldown_until to now + 120s) and returns False.
        """
        now = time.monotonic()

        # Check cooldown
        cooldown_end = self._cooldown_until.get(key, 0.0)
        if now < cooldown_end:
            return False

        # Get timestamps within window
        timestamps = self._reply_timestamps.get(key, [])
        recent = [t for t in timestamps if now - t < LOOP_WINDOW_SECONDS]

        if len(recent) >= LOOP_MAX_REPLIES_PER_WINDOW:
            # Hit limit — enter cooldown
            self._cooldown_until[key] = now + LOOP_COOLDOWN_SECONDS
            self._reply_timestamps[key] = []
            return False

        return True

    def record_reply(self, key: str) -> None:
        """Record a successful reply against ``key``.

        Mirrors OC ``_recordReply`` (openclaw-entry.ts:74-83). Appends
        the current monotonic time to the per-key list, then prunes
        any entries older than the window so the list never grows
        unboundedly.
        """
        now = time.monotonic()
        timestamps = self._reply_timestamps.get(key, [])
        timestamps.append(now)
        self._reply_timestamps[key] = [
            t for t in timestamps if now - t < LOOP_WINDOW_SECONDS
        ]

    # --- Back-compat key-prefix helpers (OC openclaw-entry.ts:86-89) ---
    def can_reply_a2a(self, channel_id: str) -> bool:
        return self.can_reply(f"a2a:{channel_id}")

    def record_reply_a2a(self, channel_id: str) -> None:
        self.record_reply(f"a2a:{channel_id}")

    def can_reply_room(self, room_id: str) -> bool:
        return self.can_reply(f"room:{room_id}")

    def record_reply_room(self, room_id: str) -> None:
        self.record_reply(f"room:{room_id}")


__all__ = [
    "LOOP_COOLDOWN_SECONDS",
    "LOOP_MAX_REPLIES_PER_WINDOW",
    "LOOP_WINDOW_SECONDS",
    "LoopPreventer",
]
