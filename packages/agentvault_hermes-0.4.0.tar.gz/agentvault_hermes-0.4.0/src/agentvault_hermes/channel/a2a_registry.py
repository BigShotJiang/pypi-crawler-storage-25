"""A2A channel registry — the agent-to-agent channels this agent belongs to.

An A2A channel is learned from two independent sources:

- A2A lifecycle WS events (``a2a_channel_invited`` / ``a2a_channel_approved``,
  plus the ``a2a_participant_*`` / ``a2a_creator_transferred`` updates) — the
  low-latency fast path.
- the ``GET /api/v1/a2a/channels`` connect-time reconciliation poll — the
  authoritative backstop that catches any channel missed while offline.

``A2AChannelRegistry`` merges both into one ``A2AChannelEntry`` per channel.
Every upsert MERGES: a source that does not carry a field never clobbers a
value a prior source already set — so ``record_welcome`` (group id only) and
``upsert_from_event`` (participants) compose in any order.

OC parity: OC keeps the equivalent state in ``_persisted.a2aChannels`` keyed by
bare ``channelId`` (``channel.ts``). Hermes isolates it here so ``SecureChannel``
does not grow another responsibility — the same split #234 made with
``room_directory.py``.
"""
from __future__ import annotations

import contextlib
import json
import logging
import os
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

_A2A_FILE_NAME = "a2a_channels.json"
_A2A_VERSION = 1


@dataclass
class A2AParticipant:
    """One participant of an A2A channel (this agent excluded).

    ``status`` tracks the backend participant lifecycle
    (``invited`` | ``active`` | ``left`` | ``removed``). An unrecognized
    status from the wire is stored verbatim — the registry never invents a
    value. NOT frozen: ``update_participant`` mutates ``status`` in place.

    ``device_id`` (Slice B): the participant's primary device UUID, carried
    by lifecycle event payloads. Used by ``A2AFounder`` to batch-fetch
    KeyPackages. Optional because some legacy poll/payload shapes may not
    carry it; the founder skips participants whose ``device_id`` is ``None``.
    """

    hub_id: str
    hub_address: str
    status: str
    device_id: Optional[str] = None


@dataclass
class A2AChannelEntry:
    """Everything the agent knows about one A2A channel.

    ``mls_group_id`` is None until a Welcome is accepted (member role) or the
    founder finishes init (creator role). ``role`` is tracked verbatim per OC
    (``creator`` | ``member``); Slice A acts as a member, but an
    ``a2a_creator_transferred`` event can flip it (see ``a2a_lifecycle.py``).

    ``creator_device_id`` (Slice B): set when this device founds the group;
    Slice C's dynamic-add path reads it to decide whether to generate the
    add-member commit.

    ``pending_kp_hub_ids`` (Slice B): hubs whose KeyPackages were missing at
    the last fetch attempt. Reconcile retries the fetch on connect; Slice C
    will run dynamic-add for any that show up later.
    """

    a2a_channel_id: str
    conversation_id: Optional[str] = None
    mls_group_id: Optional[str] = None
    role: str = "member"
    topic: Optional[str] = None
    participants: dict[str, A2AParticipant] = field(default_factory=dict)
    creator_device_id: Optional[str] = None
    pending_kp_hub_ids: list[str] = field(default_factory=list)


def _channel_id_of(data: dict[str, Any]) -> str:
    """Extract the channel id from a lifecycle/poll payload.

    A2A payloads use ``a2a_channel_id`` on delivery-queue/Welcome rows and
    ``channel_id`` on lifecycle events / the list-channels poll; accept either.
    """
    cid = data.get("a2a_channel_id") or data.get("channel_id")
    if not cid:
        raise KeyError("a2a payload missing a2a_channel_id / channel_id")
    return str(cid)


def _participants_from_payload(
    raw: list[dict[str, Any]] | None,
) -> dict[str, A2AParticipant]:
    """Convert a backend participant list into a ``hub_id -> A2AParticipant`` map.

    Lifecycle events and the channel-list poll both carry participants with the
    same fields: ``hub_id``, ``hub_address``, ``status``.
    """
    out: dict[str, A2AParticipant] = {}
    for p in raw or []:
        hub_id = p.get("hub_id")
        if not hub_id:
            continue
        hub_id = str(hub_id)
        device_id_raw = p.get("device_id")
        out[hub_id] = A2AParticipant(
            hub_id=hub_id,
            hub_address=str(p.get("hub_address") or ""),
            status=str(p.get("status") or "invited"),
            device_id=str(device_id_raw) if device_id_raw else None,
        )
    return out


class A2AChannelRegistry:
    """In-memory registry of A2A channels, persisted to ``a2a_channels.json``."""

    def __init__(self) -> None:
        self._channels: dict[str, A2AChannelEntry] = {}

    def get(self, a2a_channel_id: str) -> Optional[A2AChannelEntry]:
        return self._channels.get(a2a_channel_id)

    def all(self) -> list[A2AChannelEntry]:
        return list(self._channels.values())

    def resolve_by_group_id(self, mls_group_id: str) -> Optional[A2AChannelEntry]:
        """Reverse lookup MLS group id -> entry. Linear scan; channel count
        per agent is small."""
        for entry in self._channels.values():
            if entry.mls_group_id == mls_group_id:
                return entry
        return None

    def upsert_from_event(self, data: dict[str, Any]) -> A2AChannelEntry:
        """Merge an ``a2a_channel_invited`` / ``a2a_channel_approved`` payload.

        Carries channel id + conversation id + role + participants + topic; does
        NOT carry ``mls_group_id`` (preserved).
        """
        channel_id = _channel_id_of(data)
        entry = self._channels.get(channel_id) or A2AChannelEntry(
            a2a_channel_id=channel_id
        )
        conv = data.get("conversation_id")
        if conv:
            entry.conversation_id = str(conv)
        role = data.get("role")
        if role:
            entry.role = str(role)
        topic = data.get("topic")
        if topic:
            entry.topic = str(topic)
        raw_participants = data.get("participants")
        if raw_participants:
            entry.participants = _participants_from_payload(raw_participants)
        self._channels[channel_id] = entry
        return entry

    def upsert_from_poll(self, item: dict[str, Any]) -> A2AChannelEntry:
        """Merge one channel item from ``GET /api/v1/a2a/channels``.

        Same merge semantics as ``upsert_from_event`` — the poll is the
        connect-time reconciliation source.
        """
        return self.upsert_from_event(item)

    def record_welcome(
        self, a2a_channel_id: str, mls_group_id: str
    ) -> A2AChannelEntry:
        """Record that an MLS Welcome for ``a2a_channel_id`` was accepted.

        Creates a minimal entry when the channel is otherwise unknown so a
        Welcome arriving before any lifecycle event still makes it routable.
        """
        entry = self._channels.get(a2a_channel_id) or A2AChannelEntry(
            a2a_channel_id=a2a_channel_id
        )
        entry.mls_group_id = mls_group_id
        self._channels[a2a_channel_id] = entry
        return entry

    def update_participant(
        self, a2a_channel_id: str, hub_id: str, status: str
    ) -> None:
        """Apply an ``a2a_participant_*`` status change.

        No-op for an unknown channel. An unknown participant is added so the
        roster converges toward the backend's view.
        """
        entry = self._channels.get(a2a_channel_id)
        if entry is None:
            return
        existing = entry.participants.get(hub_id)
        if existing is None:
            entry.participants[hub_id] = A2AParticipant(
                hub_id=hub_id, hub_address="", status=status
            )
        else:
            existing.status = status

    def set_role(self, a2a_channel_id: str, role: str) -> None:
        """Set this agent's role in a channel (``a2a_creator_transferred``)."""
        entry = self._channels.get(a2a_channel_id)
        if entry is not None:
            entry.role = role

    def remove(self, a2a_channel_id: str) -> None:
        """Forget a channel (``a2a_channel_revoked`` / ``a2a_agent_removed``).

        Idempotent.
        """
        self._channels.pop(a2a_channel_id, None)

    def save(self, data_dir: Path) -> None:
        """Atomically write the registry to ``data_dir/a2a_channels.json``.

        Mirrors the mkstemp + os.replace atomic-write pattern in
        ``room_directory.py`` / ``crypto/persistence.py``.
        """
        payload = {
            "version": _A2A_VERSION,
            "channels": [
                {
                    "a2a_channel_id": e.a2a_channel_id,
                    "conversation_id": e.conversation_id,
                    "mls_group_id": e.mls_group_id,
                    "role": e.role,
                    "topic": e.topic,
                    "creator_device_id": e.creator_device_id,
                    "pending_kp_hub_ids": list(e.pending_kp_hub_ids),
                    "participants": [
                        {
                            "hub_id": p.hub_id,
                            "hub_address": p.hub_address,
                            "status": p.status,
                            "device_id": p.device_id,
                        }
                        for p in e.participants.values()
                    ],
                }
                for e in self._channels.values()
            ],
        }
        data_dir.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=data_dir, prefix=".a2a-", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(payload, fh)
            os.chmod(tmp, 0o600)
            os.replace(tmp, data_dir / _A2A_FILE_NAME)
        except BaseException:
            with contextlib.suppress(OSError):
                os.unlink(tmp)
            raise

    def load(self, data_dir: Path) -> None:
        """Load the registry from ``data_dir/a2a_channels.json``.

        Missing file → empty (first run). Malformed file → logged at WARNING
        and skipped (the two discovery sources repopulate on connect).
        """
        path = data_dir / _A2A_FILE_NAME
        if not path.exists():
            return
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                logger.warning("a2a_registry: %s is not a JSON object; ignoring", path)
                return
            if raw.get("version") != _A2A_VERSION:
                logger.warning("a2a_registry: unexpected version in %s; ignoring", path)
                return
            loaded: dict[str, A2AChannelEntry] = {}
            for c in raw.get("channels", []):
                raw_pending = c.get("pending_kp_hub_ids") or []
                pending_kp_hub_ids = (
                    [str(h) for h in raw_pending]
                    if isinstance(raw_pending, list)
                    else []
                )
                creator_device_id_raw = c.get("creator_device_id")
                creator_device_id = (
                    str(creator_device_id_raw)
                    if creator_device_id_raw is not None
                    else None
                )
                entry = A2AChannelEntry(
                    a2a_channel_id=str(c["a2a_channel_id"]),
                    conversation_id=c.get("conversation_id"),
                    mls_group_id=c.get("mls_group_id"),
                    role=str(c.get("role") or "member"),
                    topic=c.get("topic"),
                    creator_device_id=creator_device_id,
                    pending_kp_hub_ids=pending_kp_hub_ids,
                    participants={
                        str(p["hub_id"]): A2AParticipant(
                            hub_id=str(p["hub_id"]),
                            hub_address=str(p.get("hub_address") or ""),
                            status=str(p.get("status") or "invited"),
                            device_id=(
                                str(p["device_id"])
                                if p.get("device_id") is not None
                                else None
                            ),
                        )
                        for p in c.get("participants", [])
                    },
                )
                loaded[entry.a2a_channel_id] = entry
            self._channels = loaded
        except (OSError, ValueError, KeyError, TypeError) as exc:
            logger.warning(
                "a2a_registry: failed to load %s: %s; starting empty", path, exc
            )


__all__ = ["A2AChannelEntry", "A2AChannelRegistry", "A2AParticipant"]
