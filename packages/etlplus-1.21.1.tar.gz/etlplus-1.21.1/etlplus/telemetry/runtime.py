"""
:mod:`etlplus.telemetry.runtime` module.

Optional runtime telemetry adapters built on top of structured event payloads.
"""

from __future__ import annotations

import logging
import os
from collections.abc import Mapping
from importlib import import_module
from typing import Any

from ..__version__ import __version__
from .config import ResolvedTelemetryConfig
from .config import TelemetryConfig
from .config import TelemetryExporter

# SECTION: EXPORTS ========================================================== #


__all__ = [
    'RuntimeTelemetry',
    'ResolvedTelemetryConfig',
    'TelemetryConfig',
]


# SECTION: INTERNAL CONSTANTS =============================================== #


_DEFAULT_EXPORTER: TelemetryExporter = 'none'
_ENV_TELEMETRY_ENABLED = 'ETLPLUS_TELEMETRY_ENABLED'
_ENV_TELEMETRY_EXPORTER = 'ETLPLUS_TELEMETRY_EXPORTER'
_ENV_TELEMETRY_SERVICE_NAME = 'ETLPLUS_TELEMETRY_SERVICE_NAME'
_LOGGER = logging.getLogger(__name__)


# SECTION: INTERNAL FUNCTIONS =============================================== #


def _span_name(
    event: Mapping[str, Any],
) -> str:
    """Return one stable span name for a runtime command event."""
    command = event.get('command')
    return f'etlplus.{command}' if isinstance(command, str) and command else 'etlplus'


# SECTION: INTERNAL CLASSES ================================================= #


class _OpenTelemetryAdapter:
    """In-process bridge from runtime events to OpenTelemetry primitives."""

    # -- Magic Methods (Object Lifecycle) -- #

    def __init__(
        self,
        settings: ResolvedTelemetryConfig,
    ) -> None:
        opentelemetry_root = import_module('opentelemetry')
        trace_module = import_module('opentelemetry.trace')
        metrics = opentelemetry_root.metrics
        trace = opentelemetry_root.trace
        status_factory = trace_module.Status
        status_code_enum = trace_module.StatusCode

        self._settings = settings
        self._status = status_factory
        self._status_code = status_code_enum
        self._spans: dict[str, Any] = {}
        self._tracer = trace.get_tracer('etlplus.runtime', __version__)
        meter = metrics.get_meter('etlplus.runtime', __version__)
        self._event_counter = meter.create_counter(
            'etlplus.command.events',
            unit='1',
            description='Count of ETLPlus structured runtime lifecycle events.',
        )
        self._failure_counter = meter.create_counter(
            'etlplus.command.failures',
            unit='1',
            description='Count of failed ETLPlus structured runtime lifecycle events.',
        )
        self._duration_histogram = meter.create_histogram(
            'etlplus.command.duration',
            unit='ms',
            description='Observed ETLPlus command duration in milliseconds.',
        )
        self._history_record_counter = meter.create_counter(
            'etlplus.history.records',
            unit='1',
            description='Count of persisted ETLPlus run and job history records.',
        )
        self._history_duration_histogram = meter.create_histogram(
            'etlplus.history.duration',
            unit='ms',
            description='Observed persisted ETLPlus run/job durations in milliseconds.',
        )
        self._history_records_in_histogram = meter.create_histogram(
            'etlplus.history.records_in',
            unit='1',
            description=(
                'Observed persisted input record counts for ETLPlus history rows.'
            ),
        )
        self._history_records_out_histogram = meter.create_histogram(
            'etlplus.history.records_out',
            unit='1',
            description=(
                'Observed persisted output record counts for ETLPlus history rows.'
            ),
        )

    # -- Instance Methods -- #

    def emit_event(
        self,
        event: Mapping[str, Any],
    ) -> None:
        """Export one structured runtime event as spans and metrics."""
        attrs = _event_attributes(
            event,
            service_name=self._settings.service_name,
        )
        self._event_counter.add(1, attrs)

        lifecycle = event.get('lifecycle')
        run_id = event.get('run_id')
        if not isinstance(lifecycle, str) or not isinstance(run_id, str):
            return

        if lifecycle == 'started':
            span = self._tracer.start_span(_span_name(event))
            span.set_attributes(attrs)
            span.add_event(str(event.get('event', 'started')), attributes=attrs)
            self._spans[run_id] = span
            return

        if lifecycle not in {'completed', 'failed'}:
            return

        span = self._spans.pop(run_id, None)
        if span is None:
            span = self._tracer.start_span(_span_name(event))

        span.set_attributes(attrs)
        span.add_event(str(event.get('event', lifecycle)), attributes=attrs)

        duration_ms = event.get('duration_ms')
        if isinstance(duration_ms, int):
            self._duration_histogram.record(duration_ms, attrs)

        if lifecycle == 'failed':
            self._failure_counter.add(1, attrs)
            error_message = event.get('error_message')
            error_text = (
                error_message
                if isinstance(error_message, str)
                else 'ETLPlus command failed'
            )
            span.record_exception(RuntimeError(error_text))
            span.set_status(self._status(self._status_code.ERROR, error_text))
        else:
            span.set_status(self._status(self._status_code.OK))

        span.end()

    def emit_history_record(
        self,
        record: Mapping[str, Any],
        *,
        record_level: str,
    ) -> None:
        """Export one normalized persisted history record as metrics."""
        attrs = _history_record_attributes(
            record,
            record_level=record_level,
            service_name=self._settings.service_name,
        )
        self._history_record_counter.add(1, attrs)

        for field_name, histogram in (
            ('duration_ms', self._history_duration_histogram),
            ('records_in', self._history_records_in_histogram),
            ('records_out', self._history_records_out_histogram),
        ):
            value = record.get(field_name)
            if isinstance(value, int):
                histogram.record(value, attrs)

    # -- Static Methods -- #

    @staticmethod
    def build_adapter(
        settings: ResolvedTelemetryConfig,
    ) -> _OpenTelemetryAdapter | None:
        """Return one configured adapter when OpenTelemetry is available."""
        if not settings.enabled or settings.exporter == 'none':
            return None
        if settings.exporter != 'opentelemetry':
            return None
        try:
            return _OpenTelemetryAdapter(settings)
        except ImportError:
            _LOGGER.warning(
                'Telemetry is enabled but optional OpenTelemetry dependencies '
                'are not installed. Install the telemetry extra to activate '
                'export.',
            )
            return None


# SECTION: INTERNAL FUNCTIONS =============================================== #


def _event_attributes(
    event: Mapping[str, Any],
    *,
    service_name: str,
) -> dict[str, str | bool | int | float]:
    """Return one attribute mapping derived from the stable event envelope."""
    attrs: dict[str, str | bool | int | float] = {
        'etlplus.service_name': service_name,
        'etlplus.schema': str(event.get('schema', '')),
        'etlplus.schema_version': int(event.get('schema_version', 0) or 0),
        'etlplus.command': str(event.get('command', '')),
        'etlplus.lifecycle': str(event.get('lifecycle', '')),
        'etlplus.run_id': str(event.get('run_id', '')),
    }
    attrs.update(
        _optional_string_attributes(
            event,
            fields=(
                'config_path',
                'error_message',
                'error_type',
                'event',
                'job',
                'pipeline_name',
                'result_status',
                'source',
                'source_type',
                'status',
                'target',
                'target_type',
                'timestamp',
            ),
            prefix='etlplus.',
        ),
    )
    for field_name in ('continue_on_fail', 'run_all', 'valid'):
        value = event.get(field_name)
        if isinstance(value, bool):
            attrs[f'etlplus.{field_name}'] = value
    return attrs


def _history_record_attributes(
    record: Mapping[str, Any],
    *,
    record_level: str,
    service_name: str,
) -> dict[str, str | bool | int | float]:
    """Return one attribute mapping derived from normalized history fields."""
    attrs: dict[str, str | bool | int | float] = {
        'etlplus.service_name': service_name,
        'etlplus.history.level': record_level,
        'etlplus.run_id': str(record.get('run_id', '')),
    }
    attrs.update(
        _optional_string_attributes(
            record,
            fields=(
                'config_path',
                'error_type',
                'etlplus_version',
                'job_name',
                'pipeline_name',
                'result_status',
                'status',
            ),
            prefix='etlplus.history.',
        ),
    )
    sequence_index = record.get('sequence_index')
    if isinstance(sequence_index, int):
        attrs['etlplus.history.sequence_index'] = sequence_index
    return attrs


def _optional_string_attributes(
    payload: Mapping[str, Any],
    *,
    fields: tuple[str, ...],
    prefix: str,
) -> dict[str, str]:
    """Return optional string attributes copied from one payload mapping."""
    return {
        f'{prefix}{field_name}': value
        for field_name in fields
        if isinstance(value := payload.get(field_name), str) and value
    }


# SECTION: CLASSES ========================================================== #


class RuntimeTelemetry:
    """Global runtime telemetry bridge configured per CLI invocation."""

    # -- Internal Class Attributes -- #

    _adapter: _OpenTelemetryAdapter | None = None
    _settings: ResolvedTelemetryConfig | None = None

    # -- Internal Class Methods -- #

    @classmethod
    def _emit_via_adapter(
        cls,
        emitter: str,
        *args: object,
        debug_message: str,
        **kwargs: object,
    ) -> None:
        """Call one adapter emitter defensively when telemetry is enabled."""
        if cls._settings is None:
            cls.configure(env=os.environ)
        if cls._adapter is None:
            return
        try:
            getattr(cls._adapter, emitter)(*args, **kwargs)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            _LOGGER.debug(debug_message, exc_info=True)

    # -- Class Methods -- #

    @classmethod
    def configure(
        cls,
        config: TelemetryConfig | ResolvedTelemetryConfig | None = None,
        *,
        env: Mapping[str, str] | None = None,
        enabled: bool | None = None,
        exporter: str | None = None,
        service_name: str | None = None,
        force: bool = False,
    ) -> ResolvedTelemetryConfig:
        """Resolve and install the active runtime telemetry settings."""
        resolved = (
            config
            if isinstance(config, ResolvedTelemetryConfig)
            else ResolvedTelemetryConfig.resolve(
                config,
                env=env,
                enabled=enabled,
                exporter=exporter,
                service_name=service_name,
            )
        )
        if not force and resolved == cls._settings:
            return resolved
        cls._settings = resolved
        cls._adapter = _OpenTelemetryAdapter.build_adapter(resolved)
        return resolved

    @classmethod
    def emit_event(
        cls,
        event: Mapping[str, Any],
    ) -> None:
        """Export one runtime event through the active adapter when enabled."""
        cls._emit_via_adapter(
            'emit_event',
            event,
            debug_message='Runtime telemetry adapter failed to export event.',
        )

    @classmethod
    def emit_history_record(
        cls,
        record: Mapping[str, Any],
        *,
        record_level: str,
    ) -> None:
        """Export one normalized persisted history record as metrics."""
        cls._emit_via_adapter(
            'emit_history_record',
            record,
            record_level=record_level,
            debug_message=(
                'Runtime telemetry adapter failed to export history record.'
            ),
        )

    @classmethod
    def reset(
        cls,
    ) -> None:
        """Reset the process-local telemetry bridge state for tests."""
        cls._adapter = None
        cls._settings = None
