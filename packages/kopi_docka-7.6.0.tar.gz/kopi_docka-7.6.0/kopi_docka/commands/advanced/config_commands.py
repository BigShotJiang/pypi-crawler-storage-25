################################################################################
# KOPI-DOCKA
#
# @file:        config_commands.py
# @module:      kopi_docka.commands.advanced
# @description: Configuration management commands (advanced config subgroup)
#               Thin wrapper around legacy config_commands.py
# @author:      Markus F. (TZERO78) & KI-Assistenten
# @repository:  https://github.com/TZERO78/kopi-docka
# @version:     3.5.0
#
# ------------------------------------------------------------------------------
# Copyright (c) 2025 Markus F. (TZERO78)
# MIT-Lizenz: siehe LICENSE oder https://opensource.org/licenses/MIT
################################################################################

"""
Configuration management commands under 'advanced config'.

This module is a thin wrapper that delegates to config_commands.py.
All business logic is in the legacy module to avoid code duplication.

Commands:
- advanced config show               - Show current configuration
- advanced config new                - Create new configuration
- advanced config edit               - Edit configuration file
- advanced config reset              - Reset configuration (DANGEROUS)
- advanced config status             - Show repository storage status
- advanced config change-password    - Change repository password
- advanced config repair-kopia-params - Rebuild SFTP kopia_params from [credentials]
"""

from pathlib import Path
from typing import Optional

import typer

# Import from legacy config_commands - Single Source of Truth
from ..config_commands import (
    cmd_config,  # show
    cmd_new_config,  # new (FIXED: detect_repository_type, terminology)
    cmd_edit_config,  # edit
    cmd_reset_config,  # reset
    cmd_status,  # status (FIXED: dead code removed)
    cmd_change_password,  # change-password
    cmd_repair_kopia_params,  # repair-kopia-params (v7.5.0, Plan 0029)
)

# Create config subcommand group
config_app = typer.Typer(
    name="config",
    help="Configuration management commands.",
    no_args_is_help=True,
)


# -------------------------
# Registration
# -------------------------


def register(app: typer.Typer):
    """Register configuration commands under 'advanced config'."""

    @config_app.command("show")
    def _config_show_cmd(ctx: typer.Context):
        """Show current configuration."""
        cmd_config(ctx)

    @config_app.command("new")
    def _config_new_cmd(
        force: bool = typer.Option(
            False, "--force", "-f", help="Overwrite existing config (with warnings)"
        ),
        edit: bool = typer.Option(True, "--edit/--no-edit", help="Open in editor after creation"),
        path: Optional[Path] = typer.Option(None, "--path", help="Custom config path"),
    ):
        """Create new configuration file with interactive setup wizard."""
        cmd_new_config(force=force, edit=edit, path=path)

    @config_app.command("edit")
    def _config_edit_cmd(
        ctx: typer.Context,
        editor: Optional[str] = typer.Option(None, "--editor", help="Specify editor to use"),
    ):
        """Edit existing configuration file."""
        cmd_edit_config(ctx, editor)

    @config_app.command("reset")
    def _config_reset_cmd(
        path: Optional[Path] = typer.Option(None, "--path", help="Custom config path"),
    ):
        """Reset configuration completely (DANGEROUS - creates new password!)."""
        cmd_reset_config(path)

    @config_app.command("status")
    def _config_status_cmd(ctx: typer.Context):
        """Show detailed repository storage status."""
        cmd_status(ctx)

    @config_app.command("change-password")
    def _config_change_password_cmd(ctx: typer.Context):
        """Change repository encryption password."""
        cmd_change_password(ctx)

    @config_app.command("repair-kopia-params")
    def _config_repair_kopia_params_cmd(
        ctx: typer.Context,
        dry_run: bool = typer.Option(
            False, "--dry-run", help="Show the diff but don't write the config."
        ),
        yes: bool = typer.Option(
            False, "--yes", "-y", help="Skip the confirmation prompt."
        ),
    ):
        """Rebuild SFTP kopia_params from [credentials] (fixes Plan 0029 / v7.0–v7.3.13 wizard bug)."""
        cmd_repair_kopia_params(ctx, dry_run=dry_run, yes=yes)

    # Add config subgroup to admin app
    app.add_typer(config_app, name="config", help="Configuration management commands")
