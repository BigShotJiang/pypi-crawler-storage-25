#!/usr/bin/env python3
"""
Harris Matrix Interactive Creator Routes
========================================

Web-based visual editor for creating Harris Matrix diagrams.

Features:
- Drag-and-drop node creation
- Visual relationship connections
- Extended Matrix node type support
- Real-time preview
- Save to database
- Export to GraphML/DOT formats
"""

from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for, session as flask_session, current_app
from sqlalchemy.orm import Session
from datetime import datetime
import json
import os
import logging

logger = logging.getLogger(__name__)

from pyarchinit_mini.services.relationship_sync_service import RelationshipSyncService
from pyarchinit_mini.config.em_node_config_manager import get_config_manager
from pyarchinit_mini.vocab.provider import VocabProvider
from pyarchinit_mini.graphml_io.writer import write_graphml
from pyarchinit_mini.graphproj.projector import GraphProjector

# Create Blueprint
harris_creator_bp = Blueprint('harris_creator', __name__, url_prefix='/harris-creator')

# Helper function to get database session
def get_db_session():
    """Get database session from Flask app context"""
    if hasattr(current_app, 'db_manager'):
        db_manager = current_app.db_manager
        return db_manager.connection.get_session()
    else:
        # Fallback: create connection from environment
        from pyarchinit_mini.database.connection import DatabaseConnection
        db_url = os.getenv("DATABASE_URL", "sqlite:///pyarchinit_mini.db")
        conn = DatabaseConnection.from_url(db_url)
        return conn.get_session()


@harris_creator_bp.route('/')
def index():
    """Show list of sites to choose from or create new"""
    from pyarchinit_mini.models.site import Site

    with get_db_session() as db:
        sites = db.query(Site).order_by(Site.sito).all()
        return render_template('harris_creator/index.html', sites=sites)


@harris_creator_bp.route('/editor')
def editor():
    """
    Harris Matrix visual editor

    Query parameters:
        site: Site name (optional, creates new if not exists)
        mode: 'new' or 'edit' (default: 'new')
    """
    from pyarchinit_mini.models.site import Site
    from pyarchinit_mini.models.us import US
    from pyarchinit_mini.models.harris_matrix import USRelationships

    site_name = request.args.get('site', '')
    mode = request.args.get('mode', 'new')

    if not site_name:
        flash('Please select or create a site first', 'warning')
        return redirect(url_for('harris_creator.index'))

    with get_db_session() as db:
        # Get or create site
        site = db.query(Site).filter_by(sito=site_name).first()

        if not site:
            site = Site(sito=site_name, definizione_sito='Created via Harris Matrix Creator')
            db.add(site)
            db.flush()
            flash(f'Created new site: {site_name}', 'success')

        # If editing, load existing matrix
        existing_nodes = []
        existing_relationships = []

        if mode == 'edit':
            # Load existing US nodes
            us_list = db.query(US).filter_by(sito=site_name).all()
            for us in us_list:
                existing_nodes.append({
                    'id': f'us_{us.us}',
                    'us_number': us.us,
                    'unit_type': us.unita_tipo or 'US',  # default per VocabProvider canonical types
                    'description': us.d_stratigrafica or '',
                    'area': us.area or '',
                    'period': us.periodo_iniziale or '',
                    'phase': us.fase_iniziale or '',
                    'datazione': us.datazione or '',  # datazione_estesa from periodizzazione
                    'file_path': us.file_path or ''
                })

            # Load relationships from the dedicated table
            relationships = db.query(USRelationships).filter_by(sito=site_name).all()
            for rel in relationships:
                existing_relationships.append({
                    'from_us': rel.us_from,
                    'to_us': rel.us_to,
                    'relationship': rel.relationship_type
                })
            # Fallback: when us_relationships_table is empty for this site
            # (data imported from QGIS pyarchinit only fills us.rapporti),
            # parse the rapporti field of each US as a python literal.
            if not existing_relationships:
                import ast
                for us in us_list:
                    rap = (us.rapporti or '').strip()
                    if not rap or rap in ('[]', 'null', 'None'):
                        continue
                    try:
                        parsed = ast.literal_eval(rap)
                    except Exception:
                        continue
                    if not isinstance(parsed, (list, tuple)):
                        continue
                    for item in parsed:
                        if not isinstance(item, (list, tuple)) or len(item) < 2:
                            continue
                        rel_type = str(item[0]).strip()
                        us_to = str(item[1]).strip()
                        if rel_type and us_to:
                            existing_relationships.append({
                                'from_us': str(us.us),
                                'to_us': us_to,
                                'relationship': rel_type,
                            })

        return render_template('harris_creator/editor.html',
                             site_name=site_name,
                             mode=mode,
                             existing_nodes=json.dumps(existing_nodes),
                             existing_relationships=json.dumps(existing_relationships))


@harris_creator_bp.route('/api/save', methods=['POST'])
def save_matrix():
    """
    Save Harris Matrix to database

    POST JSON body:
        {
            "site_name": "Site Name",
            "nodes": [
                {
                    "us_number": "1001",
                    "unit_type": "US",
                    "description": "...",
                    "area": "Area A",
                    "period": "Medieval",
                    "phase": "Late",
                    "file_path": ""
                },
                ...
            ],
            "relationships": [
                {
                    "from_us": "1001",
                    "to_us": "1002",
                    "relationship": "Covers"
                },
                ...
            ]
        }

    Returns:
        {
            "success": true,
            "message": "...",
            "nodes_created": 10,
            "relationships_created": 15
        }
    """
    # TODO(Spec-3): replace debug print() calls with logger.debug per
    # final review nit. Lines below contain prints kept from initial dev.

    # Debug logging
    print(f"[DEBUG] Content-Type: {request.content_type}")
    print(f"[DEBUG] Request data: {request.data}")

    data = request.get_json(force=True)  # Force JSON parsing even without Content-Type
    print(f"[DEBUG] Parsed data: {data}")

    if not data:
        return jsonify({'success': False, 'message': 'No data provided'}), 400

    site_name = data.get('site_name')
    nodes = data.get('nodes', [])
    relationships = data.get('relationships', [])

    print(f"[DEBUG] site_name: {site_name}")
    print(f"[DEBUG] nodes count: {len(nodes)}")
    print(f"[DEBUG] relationships count: {len(relationships)}")

    if not site_name:
        return jsonify({'success': False, 'message': 'Site name is required'}), 400

    from pyarchinit_mini.models.site import Site
    from pyarchinit_mini.models.us import US
    from pyarchinit_mini.models.harris_matrix import USRelationships, Periodizzazione

    try:
        # Use db_manager for proper model creation
        if not hasattr(current_app, 'db_manager'):
            return jsonify({'success': False, 'message': 'Database manager not available'}), 500

        db_manager = current_app.db_manager

        with db_manager.connection.get_session() as db:
            # Get or create site
            site = db.query(Site).filter_by(sito=site_name).first()
            if not site:
                site = Site(sito=site_name)
                db.add(site)
                db.flush()

            nodes_created = 0
            nodes_updated = 0

            # Save nodes
            for node_data in nodes:
                us_number = node_data.get('us_number')
                if not us_number:
                    continue

                # Check if exists
                us = db.query(US).filter_by(
                    sito=site_name,
                    us=us_number
                ).first()

                if us:
                    # Update existing US
                    nodes_updated += 1
                    us.unita_tipo = node_data.get('unit_type', 'US')  # default per VocabProvider canonical types
                    us.d_stratigrafica = node_data.get('description', '') if node_data.get('description') else None
                    us.area = node_data.get('area', '') if node_data.get('area') else None
                    us.periodo_iniziale = node_data.get('period', '') if node_data.get('period') else None
                    us.fase_iniziale = node_data.get('phase', '') if node_data.get('phase') else None
                    us.file_path = node_data.get('file_path', '') if node_data.get('file_path') else None
                else:
                    # Create new US - id_us is auto-incremented by database
                    nodes_created += 1

                    us_create_data = {
                        # Do NOT set id_us - it's auto-incremented by the database
                        'sito': site_name,
                        'us': us_number,
                        'unita_tipo': node_data.get('unit_type', 'US'),  # default per VocabProvider canonical types
                        'd_stratigrafica': node_data.get('description', '') if node_data.get('description') else None,
                        'area': node_data.get('area', '') if node_data.get('area') else None,
                        'periodo_iniziale': node_data.get('period', '') if node_data.get('period') else None,
                        'fase_iniziale': node_data.get('phase', '') if node_data.get('phase') else None,
                        'file_path': node_data.get('file_path', '') if node_data.get('file_path') else None
                    }
                    us = db_manager.create(US, us_create_data)

                # Create or update periodizzazione record if period/phase are specified
                periodo = node_data.get('period', '')
                fase = node_data.get('phase', '')

                if periodo or fase:
                    # Create datazione_estesa
                    if periodo and fase:
                        datazione_estesa = f"{periodo} - {fase}"
                    elif periodo:
                        datazione_estesa = periodo
                    else:
                        datazione_estesa = fase

                    # Check if periodizzazione exists
                    periodizzazione = db.query(Periodizzazione).filter_by(
                        sito=site_name,
                        us=us_number
                    ).first()

                    if periodizzazione:
                        # Update existing
                        periodizzazione.periodo_iniziale = periodo if periodo else None
                        periodizzazione.fase_iniziale = fase if fase else None
                        periodizzazione.datazione_estesa = datazione_estesa
                        periodizzazione.area = node_data.get('area', '') or None
                    else:
                        # Create new
                        periodizzazione = Periodizzazione(
                            sito=site_name,
                            area=node_data.get('area', '') or None,
                            us=us_number,
                            periodo_iniziale=periodo if periodo else None,
                            fase_iniziale=fase if fase else None,
                            datazione_estesa=datazione_estesa
                        )
                        db.add(periodizzazione)

            db.flush()

            relationships_created = 0
            relationships_updated = 0

            # Save relationships
            for rel_data in relationships:
                from_us = rel_data.get('from_us')
                to_us = rel_data.get('to_us')
                rel_type = rel_data.get('relationship')

                if not all([from_us, to_us, rel_type]):
                    continue

                # Check if exists
                existing_rel = db.query(USRelationships).filter_by(
                    sito=site_name,
                    us_from=from_us,
                    us_to=to_us
                ).first()

                if existing_rel:
                    existing_rel.relationship_type = rel_type
                    relationships_updated += 1
                else:
                    relationship = USRelationships(
                        sito=site_name,
                        us_from=from_us,
                        us_to=to_us,
                        relationship_type=rel_type
                    )
                    db.add(relationship)
                    relationships_created += 1

            # Synchronize us_relationships_table to rapporti field for all affected US
            try:
                # Get list of all US numbers that have relationships
                affected_us = set()
                for rel in db.query(USRelationships).filter_by(sito=site_name).all():
                    affected_us.add(rel.us_from)

                # Update rapporti field for each US
                from pyarchinit_mini.models.us import US
                sync_service = RelationshipSyncService(current_app.db_manager)

                for us_number in affected_us:
                    rapporti_text = sync_service.sync_relationships_table_to_rapporti(
                        sito=site_name,
                        us_number=us_number,
                        session=db
                    )

                    # Update the us_table.rapporti field
                    us_record = db.query(US).filter_by(sito=site_name, us=us_number).first()
                    if us_record:
                        us_record.rapporti = rapporti_text

                db.flush()

            except Exception as sync_error:
                print(f"Warning: Failed to sync relationships to rapporti field: {sync_error}")

            # Explicitly commit all changes
            db.commit()

            # Spec 2: auto-regen stratigraphy.graphml after Harris Creator save.
            # Best-effort; _trigger_graph_regen already catches its own errors.
            try:
                from pyarchinit_mini.graphproj.auto_regen import _trigger_graph_regen
                _trigger_graph_regen(site_name, session=db)
            except Exception:
                pass

            return jsonify({
                'success': True,
                'message': f'Successfully saved Harris Matrix',
                'nodes_created': nodes_created,
                'nodes_updated': nodes_updated,
                'relationships_created': relationships_created,
                'relationships_updated': relationships_updated
            })

    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


@harris_creator_bp.route('/api/export/<format>')
def export_matrix(format):
    """
    Export Harris Matrix to GraphML or DOT format

    Query parameters:
        site: Site name (required)

    Returns:
        File download of the exported matrix
    """
    site_name = request.args.get('site')

    if not site_name:
        return jsonify({'success': False, 'message': 'Site name is required'}), 400

    if format not in ['graphml', 'dot']:
        return jsonify({'success': False, 'message': 'Invalid format. Use "graphml" or "dot"'}), 400

    try:
        with get_db_session() as db:
            # Export
            import tempfile
            from pathlib import Path as _Path
            output_dir = tempfile.mkdtemp()
            base_name = site_name.replace(' ', '_').replace('/', '_')
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"{base_name}_{timestamp}.{format}"
            output_path = os.path.join(output_dir, filename)

            if format == 'graphml':
                # Build s3dgraphy.Graph via GraphProjector then write with
                # graphml_io.writer (bypasses the GraphMLBuilder.to_string bug).
                graph = GraphProjector.populate_graph(db, site_name)

                if not graph.nodes:
                    return jsonify({'success': False, 'message': 'No nodes found for this site'}), 404

                write_graphml(graph, _Path(output_path))
            else:  # dot
                # DOT export: build networkx graph via HarrisMatrixGenerator
                # and delegate to GraphMLExporter (no GraphMLBuilder involved).
                from pyarchinit_mini.harris_matrix.matrix_generator import HarrisMatrixGenerator
                from pyarchinit_mini.graphml_converter.graphml_exporter import GraphMLExporter

                if hasattr(current_app, 'db_manager'):
                    db_manager = current_app.db_manager
                    from pyarchinit_mini.services.us_service import USService
                    us_service = USService(db_manager)
                    generator = HarrisMatrixGenerator(db_manager, us_service)
                else:
                    from pyarchinit_mini.database.manager import DatabaseManager
                    from pyarchinit_mini.database.connection import DatabaseConnection
                    from pyarchinit_mini.services.us_service import USService
                    db_url = os.getenv("DATABASE_URL", "sqlite:///pyarchinit_mini.db")
                    conn = DatabaseConnection.from_url(db_url)
                    db_manager = DatabaseManager(conn)
                    us_service = USService(db_manager)
                    generator = HarrisMatrixGenerator(db_manager, us_service)

                nx_graph = generator.generate_matrix(site_name)

                if not nx_graph or nx_graph.number_of_nodes() == 0:
                    return jsonify({'success': False, 'message': 'No nodes found for this site'}), 404

                exporter = GraphMLExporter()
                dot_path = output_path.replace('.dot', '') + '.dot'
                try:
                    exporter.export_to_dot(nx_graph, dot_path, site_name=site_name)
                    output_path = dot_path
                except Exception as e:
                    return jsonify({'success': False, 'message': f'DOT export failed: {str(e)}'}), 500

            # Send file
            from flask import send_file
            return send_file(
                output_path,
                as_attachment=True,
                download_name=filename,
                mimetype='application/xml' if format == 'graphml' else 'text/plain'
            )

    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


@harris_creator_bp.route('/api/node-types')
def get_node_types():
    """List Extended Matrix node types from VocabProvider (s3dgraphy JSON
    catalogues). The previous implementation read a legacy YAML config and
    so missed every node type added in s3dgraphy >= 0.1.42 (USVs/USVn/USN/
    RSF/serSU/serUSD/serUSVn/serUSVs/TSU/UL/BR/SE...). With this refactor,
    upgrading s3dgraphy is enough to make new types appear in the editor.
    """
    # Map s3dgraphy yEd-style shapes to Cytoscape.js shapes.
    SHAPE_MAP = {
        'note': 'roundrectangle',
        'trapezium': 'triangle',
        'trapezium2': 'vee',
        'parallelogram': 'rhomboid',
        'rounded_rectangle': 'roundrectangle',
        # Cytoscape-native shapes pass through.
        'rectangle': 'rectangle',
        'roundrectangle': 'roundrectangle',
        'ellipse': 'ellipse',
        'triangle': 'triangle',
        'pentagon': 'pentagon',
        'hexagon': 'hexagon',
        'heptagon': 'heptagon',
        'octagon': 'octagon',
        'star': 'star',
        'diamond': 'diamond',
        'vee': 'vee',
        'rhomboid': 'rhomboid',
    }

    try:
        from pyarchinit_mini.vocab.provider import VocabProvider
        provider = VocabProvider.instance()
        unit_types = provider.get_unit_types()

        node_types = []
        for ut in unit_types:
            style = getattr(ut, "visual_style", None) or {}
            shape = style.get("shape", "rectangle") if isinstance(style, dict) else getattr(style, "shape", "rectangle")
            fill = style.get("fill_color", "#CCCCCC") if isinstance(style, dict) else getattr(style, "fill_color", "#CCCCCC")
            description = getattr(ut, "description", "") or ""
            label = ut.abbreviation
            if description:
                label = f"{ut.abbreviation} - {description[:80]}"

            node_types.append({
                "value": ut.abbreviation,
                "label": label,
                "color": fill,
                "shape": SHAPE_MAP.get(shape, "rectangle"),
                "family": getattr(ut, "family", None),
            })
        return jsonify(node_types)
    except Exception as e:
        return jsonify([
            {"value": "US", "label": "US - Standard Stratigraphic Unit",
             "color": "#F0F0F0", "shape": "rectangle"}
        ])


@harris_creator_bp.route('/api/relationship-types')
def get_relationship_types():
    """Get list of relationship types with descriptions, localized by current language"""
    from pyarchinit_mini.i18n import get_locale
    try:
        lang = get_locale()
    except Exception:
        lang = 'it'

    if lang == 'en':
        relationship_types = [
            {'value': 'Covers', 'label': 'Covers', 'symbol': 'Covers', 'style': 'solid', 'arrow': 'triangle'},
            {'value': 'Covered_by', 'label': 'Covered by', 'symbol': 'Covered by', 'style': 'solid', 'arrow': 'triangle'},
            {'value': 'Fills', 'label': 'Fills', 'symbol': 'Fills', 'style': 'solid', 'arrow': 'triangle'},
            {'value': 'Filled_by', 'label': 'Filled by', 'symbol': 'Filled by', 'style': 'solid', 'arrow': 'triangle'},
            {'value': 'Cuts', 'label': 'Cuts', 'symbol': 'Cuts', 'style': 'dashed', 'arrow': 'triangle'},
            {'value': 'Cut_by', 'label': 'Cut by', 'symbol': 'Cut by', 'style': 'dashed', 'arrow': 'triangle'},
            {'value': 'Bonds_to', 'label': 'Connected to', 'symbol': 'Connected to', 'style': 'solid', 'arrow': 'triangle'},
            {'value': 'Equal_to', 'label': 'Same as', 'symbol': 'Same as', 'style': 'solid', 'arrow': 'triangle'},
            {'value': 'Leans_on', 'label': 'Supports', 'symbol': 'Supports', 'style': 'solid', 'arrow': 'triangle'},
            {'value': '>', 'label': '> - Connection to single-symbol unit', 'symbol': '>', 'style': 'dotted', 'arrow': 'triangle'},
            {'value': '<', 'label': '< - From single-symbol unit', 'symbol': '<', 'style': 'dotted', 'arrow': 'triangle'},
            {'value': '>>', 'label': '>> - Connection to double-symbol unit', 'symbol': '>>', 'style': 'dotted', 'arrow': 'triangle'},
            {'value': '<<', 'label': '<< - From double-symbol unit', 'symbol': '<<', 'style': 'dotted', 'arrow': 'triangle'},
            {'value': 'Continuity', 'label': 'Continuity (contemporary units)', 'symbol': 'Continuity', 'style': 'solid', 'arrow': 'none'},
        ]
    else:
        relationship_types = [
            {'value': 'Covers', 'label': 'Copre (sopra)', 'symbol': 'Copre', 'style': 'solid', 'arrow': 'triangle'},
            {'value': 'Covered_by', 'label': 'Coperto da (sotto)', 'symbol': 'Coperto da', 'style': 'solid', 'arrow': 'triangle'},
            {'value': 'Fills', 'label': 'Riempie', 'symbol': 'Riempie', 'style': 'solid', 'arrow': 'triangle'},
            {'value': 'Filled_by', 'label': 'Riempito da', 'symbol': 'Riempito da', 'style': 'solid', 'arrow': 'triangle'},
            {'value': 'Cuts', 'label': 'Taglia', 'symbol': 'Taglia', 'style': 'dashed', 'arrow': 'triangle'},
            {'value': 'Cut_by', 'label': 'Tagliato da', 'symbol': 'Tagliato da', 'style': 'dashed', 'arrow': 'triangle'},
            {'value': 'Bonds_to', 'label': 'Si lega a', 'symbol': 'Si lega a', 'style': 'solid', 'arrow': 'triangle'},
            {'value': 'Equal_to', 'label': 'Uguale a', 'symbol': 'Uguale a', 'style': 'solid', 'arrow': 'triangle'},
            {'value': 'Leans_on', 'label': 'Si appoggia a', 'symbol': 'Si appoggia a', 'style': 'solid', 'arrow': 'triangle'},
            {'value': '>', 'label': '> - Connessione a unità simbolo singolo', 'symbol': '>', 'style': 'dotted', 'arrow': 'triangle'},
            {'value': '<', 'label': '< - Da unità simbolo singolo', 'symbol': '<', 'style': 'dotted', 'arrow': 'triangle'},
            {'value': '>>', 'label': '>> - Connessione a unità simbolo doppio', 'symbol': '>>', 'style': 'dotted', 'arrow': 'triangle'},
            {'value': '<<', 'label': '<< - Da unità simbolo doppio', 'symbol': '<<', 'style': 'dotted', 'arrow': 'triangle'},
            {'value': 'Continuity', 'label': 'Continuità (unità contemporanee)', 'symbol': 'Continuità', 'style': 'solid', 'arrow': 'none'},
        ]
    return jsonify(relationship_types)


@harris_creator_bp.route('/api/periods')
def get_periods():
    """Get list of periods and phases from period_table"""
    try:
        from pyarchinit_mini.models.harris_matrix import Period
        from sqlalchemy import text as sa_text

        with get_db_session() as db:
            # Use raw SQL to avoid ORM touching BaseModel columns not yet migrated
            rows = db.execute(
                sa_text("SELECT period_name, phase_name FROM period_table ORDER BY period_name, phase_name")
            ).fetchall()

            periods_dict = {}
            for row in rows:
                period_name = row[0] or ''
                phase_name = row[1] or ''
                if not period_name:
                    continue
                if period_name not in periods_dict:
                    periods_dict[period_name] = {'period': period_name, 'phases': []}
                if phase_name and phase_name not in periods_dict[period_name]['phases']:
                    periods_dict[period_name]['phases'].append(phase_name)

            return jsonify(list(periods_dict.values()))

    except Exception as e:
        logger.warning(f"get_periods failed (non-fatal): {e}")
        return jsonify([])  # Return empty list — periods dropdown is optional


# === Spec 3-bis: Harris Swimlane Editor endpoints ===

from flask import g

from pyarchinit_mini.harris_swimlane.row_provider import RowProvider
from pyarchinit_mini.harris_swimlane.swimlane_state import SwimlaneState
from pyarchinit_mini.harris_swimlane.exceptions import SwimlaneError, RowProviderError
from pyarchinit_mini.harris_swimlane.period_sync_service import PeriodSyncService
from pyarchinit_mini.harris_swimlane.exceptions import PeriodSyncError


def _load_epochs(session, site: str) -> list[dict]:
    """Load periodizzazione rows for the site to feed yed_writer epochs_meta.

    Primary source: ``periodizzazione_table`` (populated when data is saved via
    the Harris Creator editor).  Falls back to the distinct ``periodo_iniziale``
    / ``fase_iniziale`` pairs from ``us_table`` so that fixture databases that
    pre-date the periodizzazione write path (e.g. the Volterra test fixture)
    still produce a non-empty epochs list.
    """
    from sqlalchemy import text
    # ``datazione_estesa`` may not exist in older schema versions — use a
    # NULL placeholder and handle missing column gracefully.
    try:
        rows = session.execute(text(
            "SELECT DISTINCT periodo_iniziale, fase_iniziale, datazione_estesa "
            "FROM periodizzazione_table WHERE sito = :s AND periodo_iniziale IS NOT NULL"
        ), {"s": site}).fetchall()
    except Exception:
        rows = session.execute(text(
            "SELECT DISTINCT periodo_iniziale, fase_iniziale, NULL as datazione_estesa "
            "FROM periodizzazione_table WHERE sito = :s AND periodo_iniziale IS NOT NULL"
        ), {"s": site}).fetchall()
    if not rows:
        # Fallback: derive epochs from us_table distinct values.
        rows = session.execute(text(
            "SELECT DISTINCT periodo_iniziale, fase_iniziale, NULL as datazione_estesa "
            "FROM us_table WHERE sito = :s AND periodo_iniziale IS NOT NULL"
        ), {"s": site}).fetchall()
    out = []
    for r in rows:
        out.append({
            "name": f"Period{r[0]}" + (f"_phase{r[1]}" if r[1] else ""),
            "periodo": r[0] or "",
            "fase": r[1] or "",
            "datazione_estesa": r[2] or "",
        })
    return out


def _get_session():
    """Get a request-scoped SQLAlchemy session for Spec 3-bis endpoints.

    Reuses ``g.db_session`` if a before_request hook has set it. Otherwise
    lazily opens one through the same path as ``get_db_session()`` and
    binds it to ``g`` (the teardown_request hook below releases it). This
    keeps the API contract simple — endpoints just call ``_get_session()``
    and get a real ``Session`` back, whether or not the host app wires a
    before_request hook (the production app in 2.4.x does not).
    """
    db = getattr(g, "db_session", None)
    if db is not None:
        return db
    cm = get_db_session()
    db = cm.__enter__()
    g.db_session = db
    g._db_session_cm = cm
    return db


@harris_creator_bp.teardown_request
def _release_lazy_db_session(exc):  # noqa: ARG001 — exc is part of the signature
    """Close any session that ``_get_session()`` opened lazily for this request."""
    cm = getattr(g, "_db_session_cm", None)
    if cm is None:
        return
    try:
        cm.__exit__(type(exc) if exc else None, exc, getattr(exc, "__traceback__", None))
    except Exception:
        pass
    finally:
        try:
            delattr(g, "_db_session_cm")
        except AttributeError:
            pass


@harris_creator_bp.get("/api/swimlanes/<site>")
def api_get_swimlanes(site: str):
    """List swimlane rows for the site."""
    try:
        session = _get_session()
        provider = RowProvider(session, site)
        rows = provider.list_rows()
        return jsonify([{
            "row_id": r.row_id,
            "period_name": r.period_name,
            "phase_name": r.phase_name,
            "start_date": r.start_date,
            "end_date": r.end_date,
            "color": r.color,
            "source": r.source,
        } for r in rows]), 200
    except RowProviderError as e:
        return jsonify({"error": "row_provider", "message": str(e)}), 500
    except Exception as e:
        logger.exception("api_get_swimlanes failed")
        return jsonify({"error": "internal", "message": str(e)}), 500


@harris_creator_bp.get("/api/load/<site>")
def api_load_state(site: str):
    """Load full editor state (rows + nodes + edges) as Cytoscape JSON.

    Pipeline selection honours SWIMLANE_PIPELINE env var:
      - "s3dgraphy" (default): S3DProjector → flat palette fields (Fix B/C/D)
      - "legacy": SwimlaneState.load → nested style dict (backward compat)
    """
    pipeline = os.environ.get("SWIMLANE_PIPELINE", "s3dgraphy").lower()
    try:
        session = _get_session()

        if pipeline == "s3dgraphy":
            # ── New pipeline: S3DProjector + flat-palette to_cytoscape ──────
            from pyarchinit_mini.graphproj.s3d_projector import (
                S3DProjector, VALID_GROUP_BY as S3D_VALID,
            )
            from pyarchinit_mini.graphproj.s3d_to_cytoscape import to_cytoscape

            group_by = request.args.get("group_by", "none")
            s3d_group_by = group_by if group_by in S3D_VALID else "none"
            projected = S3DProjector.from_site(session, site, group_by=s3d_group_by)
            cyto = to_cytoscape(projected)
            # Wrap nodes/edges in the envelope renderSwimlaneState expects:
            # each element is {data: {...}} (no nested style key — flat fields
            # are already in data).  Pending changes not relevant for this path.
            return jsonify({
                "site": cyto["site"],
                "group_by": cyto["group_by"],
                "rows": cyto["rows"],
                "nodes": cyto["nodes"],
                "edges": cyto["edges"],
                "pending_changes": {"us_updates": [], "us_inserts": [], "us_deletes": []},
            }), 200

        # ── Legacy pipeline ──────────────────────────────────────────────────
        group_by = request.args.get("group_by", "period_phase")
        state = SwimlaneState.load(session, site, group_by=group_by)
        return jsonify({
            "site": state.site,
            "group_by": state.group_by,
            "rows": [
                {
                    "row_id": r.row_id,
                    "period_name": r.period_name,
                    "phase_name": r.phase_name,
                    "color": r.color,
                    "start_date": r.start_date,
                    "end_date": r.end_date,
                    "source": r.source,
                }
                for r in state.rows
            ],
            "nodes": [{"data": el.data, "style": getattr(el, "style", None), "position": el.position} for el in state.nodes],
            "edges": [{"data": el.data, "style": getattr(el, "style", None)} for el in state.edges],
            "pending_changes": state.pending_changes,
        }), 200
    except ValueError as e:
        return jsonify({"error": "validation", "message": str(e)}), 400
    except SwimlaneError as e:
        return jsonify({"error": "swimlane", "message": str(e)}), 500
    except Exception as e:
        logger.exception("api_load_state failed")
        return jsonify({"error": "internal", "message": str(e)}), 500


@harris_creator_bp.post("/api/save/<site>")
def api_save_state(site: str):
    """Save pending_changes for site. Triggers Spec 2 auto_regen on success."""
    try:
        payload = request.get_json(silent=True) or {}
        session = _get_session()
        result = SwimlaneState.save(session, site, payload)
        return jsonify({
            "updated": result.updated,
            "inserted": result.inserted,
            "deleted": result.deleted,
            "errors": list(result.errors),
        }), 200
    except SwimlaneError as e:
        return jsonify({"error": "swimlane", "message": str(e)}), 500
    except Exception as e:
        logger.exception("api_save_state failed")
        return jsonify({"error": "internal", "message": str(e)}), 500


@harris_creator_bp.post("/api/swimlanes/<site>")
def api_create_row(site: str):
    """Create a new swimlane row (upsert period_table for this site)."""
    payload = request.get_json(silent=True) or {}
    period_name = payload.get("period_name", "")
    phase_name = payload.get("phase_name") or None
    start_date = payload.get("start_date")
    end_date = payload.get("end_date")
    try:
        session = _get_session()
        svc = PeriodSyncService(session, site=site)
        row = svc.upsert_row(
            period_name=period_name, phase_name=phase_name,
            start_date=start_date, end_date=end_date,
        )
        return jsonify({
            "row_id": row.row_id,
            "period_name": row.period_name,
            "phase_name": row.phase_name,
            "start_date": row.start_date,
            "end_date": row.end_date,
            "color": row.color,
            "source": row.source,
        }), 201
    except PeriodSyncError as e:
        return jsonify({
            "error": "validation",
            "message": str(e),
            "period_name": e.period_name,
            "phase_name": e.phase_name,
        }), 400
    except Exception as e:
        logger.exception("api_create_row failed")
        return jsonify({"error": "internal", "message": str(e)}), 500


from pathlib import Path as _Path
from datetime import datetime as _datetime
import json as _json
from flask import send_file as _send_file

from pyarchinit_mini.harris_swimlane.exceptions import YEDWriterError
from pyarchinit_mini.graphproj.filesystem import slugify


@harris_creator_bp.get("/api/export/<site>/yed-graphml")
def api_export_yed(site: str):
    """Export site stratigraphy as yEd-flavored GraphML.

    Pipeline selection honours SWIMLANE_PIPELINE env var:
      - "s3dgraphy" (default): S3DProjector → EM palette graphml_writer
      - "legacy": SwimlaneState.load → write_extended_matrix_graphml
    """
    import os as _os
    from flask import Response
    group_by = request.args.get("group_by", "none")
    pipeline = _os.environ.get("SWIMLANE_PIPELINE", "s3dgraphy").lower()
    try:
        session = _get_session()
        if pipeline == "legacy":
            from pyarchinit_mini.harris_swimlane.swimlane_state import SwimlaneState
            from pyarchinit_mini.graphml_io.yed_writer import write_extended_matrix_graphml
            import tempfile, pathlib
            state = SwimlaneState.load(session, site, group_by=group_by)
            epochs = _load_epochs(session, site)
            with tempfile.TemporaryDirectory() as td:
                out = pathlib.Path(td) / f"{site}.graphml"
                write_extended_matrix_graphml(
                    state,
                    site_meta={"sito": site},
                    epochs=epochs,
                    out=out,
                )
                data = out.read_bytes()
        else:
            from pyarchinit_mini.graphproj.s3d_projector import S3DProjector
            from pyarchinit_mini.graphproj.graphml_writer import write_graphml
            # Map legacy group_by values that S3DProjector doesn't accept
            from pyarchinit_mini.graphproj.s3d_projector import VALID_GROUP_BY as S3D_VALID
            s3d_group_by = group_by if group_by in S3D_VALID else "none"
            projected = S3DProjector.from_site(session, site, group_by=s3d_group_by)
            data = write_graphml(projected)
        return Response(
            data,
            mimetype="application/graphml+xml",
            headers={"Content-Disposition": f"attachment; filename={site}.graphml"},
        )
    except Exception as e:
        logger.exception("export yed-graphml failed")
        return jsonify({"error": "export_failed", "message": str(e)}), 500


@harris_creator_bp.get("/api/export/<site>/heriverse-json")
def api_export_heriverse(site: str):
    """Export site stratigraphy as Heriverse/ATON JSON (single format covers both)."""
    from flask import Response
    import os as _os
    import tempfile
    from pyarchinit_mini.s3d_integration.s3d_converter import S3DConverter
    try:
        session = _get_session()
        # Fetch US rows as dicts using a column-variant fallback (mirrors S3DProjector)
        _VARIANTS = [
            "id_us, sito, area, us, unita_tipo, d_stratigrafica, d_interpretativa, "
            "interpretazione, anno_scavo, scavato, periodo_iniziale, fase_iniziale, rapporti",
            "id_us, sito, area, us, unita_tipo, descrizione, NULL AS d_interpretativa, "
            "NULL AS interpretazione, NULL AS anno_scavo, NULL AS scavato, "
            "fase_iniziale, fase_iniziale, rapporti",
            "id_us, sito, area, us, unita_tipo, NULL AS d_stratigrafica, "
            "NULL AS d_interpretativa, NULL AS interpretazione, NULL AS anno_scavo, "
            "NULL AS scavato, NULL AS periodo_iniziale, NULL AS fase_iniziale, NULL AS rapporti",
        ]
        us_list = []
        for cols in _VARIANTS:
            try:
                from sqlalchemy import text as _text
                rows = session.execute(
                    _text(f"SELECT {cols} FROM us_table WHERE sito = :s"),
                    {"s": site},
                ).fetchall()
                _keys = [
                    "id_us", "sito", "area", "us", "unita_tipo",
                    "d_stratigrafica", "d_interpretativa", "interpretazione",
                    "anno_scavo", "scavato", "periodo_iniziale", "fase_iniziale", "rapporti",
                ]
                us_list = [dict(zip(_keys, r)) for r in rows]
                break
            except Exception:
                try:
                    session.rollback()
                except Exception:
                    pass
        converter = S3DConverter()
        graph = converter.create_graph_from_us(us_list, site_name=site)
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
            tmp_path = tmp.name
        try:
            converter.export_to_heriverse_json(graph, output_path=tmp_path)
            with open(tmp_path, "rb") as f:
                data = f.read()
        finally:
            try:
                _os.unlink(tmp_path)
            except OSError:
                pass
        return Response(
            data,
            mimetype="application/json",
            headers={"Content-Disposition": f"attachment; filename={site}_heriverse.json"},
        )
    except Exception as e:
        logger.exception("export heriverse failed")
        return jsonify({"error": "export_failed", "message": str(e)}), 500


@harris_creator_bp.post("/api/import/<site>/graphml")
def api_import_graphml(site: str):
    """Import yEd GraphML; writes us_table rows and rapporti (4-tuple + inverses)."""
    from pyarchinit_mini.graphproj.graphml_reader import parse_graphml
    from pyarchinit_mini.graphproj.graph_to_db import write_graph
    f = request.files.get("file")
    if f is None or not f.filename:
        return jsonify({"error": "no_file"}), 400
    try:
        projected = parse_graphml(f.read(), target_site=site)
    except Exception as e:
        logger.warning("import graphml parse failed: %s", e)
        return jsonify({"error": "parse_error", "detail": str(e)}), 400
    try:
        session = _get_session()
        result = write_graph(projected, target_site=site, session=session, source_label="graphml")
        return jsonify({
            "imported_us": result.imported_us,
            "imported_edges": result.imported_edges,
            "inverses_written": result.inverses_written,
            "stubs_created": result.stubs_created,
            "inverses_skipped": result.inverses_skipped,
            "errors": result.errors,
        }), 200
    except Exception as e:
        logger.exception("import graphml write failed")
        return jsonify({"error": "write_failed", "message": str(e)}), 500


@harris_creator_bp.post("/api/import/<site>/json")
def api_import_heriverse_json(site: str):
    """Import Heriverse/ATON JSON; writes us_table + rapporti (4-tuple + inverses)."""
    from pyarchinit_mini.graphproj.heriverse_parser import parse_heriverse
    from pyarchinit_mini.graphproj.graph_to_db import write_graph
    f = request.files.get("file")
    if f is None or not f.filename:
        return jsonify({"error": "no_file"}), 400
    try:
        projected = parse_heriverse(f.read().decode("utf-8"))
        # Override site to the URL parameter
        projected.site = site
        for n in projected.nodes:
            n.sito = site
    except Exception as e:
        logger.warning("import json parse failed: %s", e)
        return jsonify({"error": "parse_error", "detail": str(e)}), 400
    try:
        session = _get_session()
        result = write_graph(projected, target_site=site, session=session, source_label="json")
        return jsonify({
            "imported_us": result.imported_us,
            "imported_edges": result.imported_edges,
            "inverses_written": result.inverses_written,
            "stubs_created": result.stubs_created,
            "inverses_skipped": result.inverses_skipped,
        }), 200
    except Exception as e:
        logger.exception("import json write failed")
        return jsonify({"error": "write_failed", "message": str(e)}), 500