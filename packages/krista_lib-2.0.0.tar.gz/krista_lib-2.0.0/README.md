# krista-lib 2.0.0

Enterprise automation library for the Krista platform. Replaces 65+ copy-pasted scripts with a single importable package.

## Installation

```bash
# Basic
pip install krista-lib

# With Excel report support
pip install "krista-lib[excel]"

# Development (editable)
cd krista-lib
pip install -e ".[all,dev]"
```

**Requires Python 3.9+**

## Quick Start

```python
from krista_lib import Krista, KristaConfig

config = KristaConfig(
    studio_url="https://studio.qa-in.eng.krista.app",
    node="node1",
    workspace_id="ws_0bbfb01f-8dcb-4999-8e5c-478278d72418",
    username="user@kristasoft.com",
    password="your_password",  # or set KRISTA_PASSWORD env var
)

with Krista(config) as krista:
    krista.login()
    krista.login_appliance()

    # Workspace info
    info = krista.workspace.get_info()
    roles = krista.workspace.get_role_details()

    # List conversations
    conversations = krista.workspace.get_conversation_meta()

    # List invokers
    invokers = krista.invokers.list_all()

    # Upload extension
    krista.extensions.upload_jar("/path/to/ext.jar", "Krista", "SDK", "Extension Development")

    # Export/import DAZ
    krista.daz.export_domain("Krista", "SDK", output_dir="/tmp/daz")
    krista.daz.import_all_to_global("/tmp/daz")

    # Auto-logout on exit
```

## Configuration

### From environment variables
```bash
export KRISTA_STUDIO_URL=https://studio.qa-in.eng.krista.app
export KRISTA_USERNAME=user@kristasoft.com
export KRISTA_PASSWORD=secret
export KRISTA_WORKSPACE_ID=ws_xxx
```
```python
krista = Krista.from_env()
```

### From JSON file
```python
krista = Krista.from_json("config.json")
```

### From explicit values
```python
config = KristaConfig(studio_url="...", username="...", password="...")
krista = Krista(config)
```

## Running Tests

```bash
# Unit tests (no network)
python3.9 -m pytest tests/unit/ -v

# Integration tests (hits real server)
python3.9 -m pytest tests/integration/ -v -s

# With coverage
python3.9 -m pytest tests/unit/ --cov=krista_lib --cov-report=term-missing
```

## API Reference

See [API_REFERENCE.md](API_REFERENCE.md) for complete documentation of every class, method, and parameter.

## License

Proprietary - Krista Software Inc.
