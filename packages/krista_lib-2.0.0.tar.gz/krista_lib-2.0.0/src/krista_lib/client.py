"""HTTP client for Krista API calls.

Wraps requests.Session with URL resolution, retry logic, logging, and error handling.
"""

from __future__ import annotations

import json
import logging
import re
import time
from typing import TYPE_CHECKING, Any

import requests
import requests.packages.urllib3

from .exceptions import KristaAPIError, KristaValidationError

if TYPE_CHECKING:
    from .config import KristaConfig

logger = logging.getLogger("krista_lib.client")

# URL patterns that need /nodeX/ stripped
_NODE_STRIP_PATTERNS = [
    re.compile(r"/node\d+/(?=auth/)"),
    re.compile(r"/node\d+/(?=sdp/)"),
    re.compile(r"/node\d+/(?=assets/)"),
]

# Status codes that trigger retry
_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


class KristaClient:
    """HTTP client for Krista platform APIs.

    Handles URL resolution, retry logic, SSL configuration, and request logging.
    """

    def __init__(self, config: KristaConfig):
        self.config = config
        self.session = requests.Session()

        # Suppress SSL warnings once (Krista uses internal certs)
        requests.packages.urllib3.disable_warnings()

        # Optional curl logging
        self._curlify = None
        if config.log_curl:
            try:
                import curlify
                self._curlify = curlify
            except ImportError:
                logger.warning("curlify not installed — install with: pip install 'krista-lib[curl]'")

    def request(
        self,
        method: str,
        url: str,
        data: Any = None,
        json_data: dict | None = None,
        headers: dict | None = None,
        files: Any = None,
        params: Any = None,
        auth: tuple | None = None,
        remove_content_type: bool = False,
        token: Any = None,
    ) -> requests.Response:
        """Make an HTTP request to the Krista API.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE, PATCH).
            url: URL (relative paths are resolved against studio_node_url).
            data: Request body (string or bytes).
            json_data: JSON body (will be serialized).
            headers: Additional headers (merged with defaults).
            files: File upload data for multipart requests.
            params: Query parameters.
            auth: Basic auth tuple (username, password).
            remove_content_type: If True, don't set Content-Type header (for multipart).
            token: KristaToken to use for auth headers. If None, no auth headers added.

        Returns:
            requests.Response object.

        Raises:
            KristaAPIError: On non-retryable HTTP errors.
            ValueError: On invalid HTTP method.
        """
        method = method.upper()
        if method not in ("GET", "POST", "PUT", "DELETE", "PATCH"):
            raise ValueError(f"Unsupported HTTP method: {method}")

        # Resolve URL
        resolved_url = self._resolve_url(url)

        # Build headers
        request_headers = {"X-Requested-With": "curl"}
        if token:
            if files or remove_content_type:
                request_headers.update(token.headers_no_content_type())
            else:
                request_headers.update(token.headers())
        elif not remove_content_type:
            request_headers["Content-Type"] = "application/json; charset=UTF-8"

        if headers:
            request_headers.update(headers)

        # Handle json_data
        body = json.dumps(json_data) if json_data is not None else data

        # Retry loop
        last_exception = None
        for attempt in range(self.config.max_retries + 1):
            try:
                start = time.time()
                response = self._do_request(method, resolved_url, body, request_headers, files, params, auth)
                elapsed_ms = int((time.time() - start) * 1000)

                # Log curl equivalent
                if self._curlify:
                    logger.debug("curl: %s", self._curlify.to_curl(response.request))

                # Log request
                if response.ok:
                    logger.debug("%s %s → %d (%dms)", method, url, response.status_code, elapsed_ms)
                else:
                    logger.warning("%s %s → %d (%dms): %s", method, url, response.status_code, elapsed_ms,
                                   response.text[:200])

                # Retry on retryable status codes
                if response.status_code in _RETRYABLE_STATUS_CODES and attempt < self.config.max_retries:
                    wait = self.config.retry_backoff * (2 ** attempt)
                    logger.info("Retrying %s %s (attempt %d/%d) after %.1fs",
                                method, url, attempt + 1, self.config.max_retries, wait)
                    time.sleep(wait)
                    continue

                return response

            except (requests.ConnectionError, requests.Timeout) as e:
                last_exception = e
                if attempt < self.config.max_retries:
                    wait = self.config.retry_backoff * (2 ** attempt)
                    logger.info("Connection error on %s %s (attempt %d/%d), retrying after %.1fs: %s",
                                method, url, attempt + 1, self.config.max_retries, wait, e)
                    time.sleep(wait)
                else:
                    raise KristaAPIError(
                        f"Request failed after {self.config.max_retries + 1} attempts: {e}",
                        url=resolved_url, method=method
                    ) from e

        # Should not reach here, but just in case
        raise KristaAPIError(
            f"Request failed after retries: {last_exception}",
            url=resolved_url, method=method
        )

    def get(self, url: str, token: Any = None, **kwargs) -> requests.Response:
        """HTTP GET request."""
        return self.request("GET", url, token=token, **kwargs)

    def post(self, url: str, token: Any = None, **kwargs) -> requests.Response:
        """HTTP POST request."""
        return self.request("POST", url, token=token, **kwargs)

    def put(self, url: str, token: Any = None, **kwargs) -> requests.Response:
        """HTTP PUT request."""
        return self.request("PUT", url, token=token, **kwargs)

    def delete(self, url: str, token: Any = None, **kwargs) -> requests.Response:
        """HTTP DELETE request."""
        return self.request("DELETE", url, token=token, **kwargs)

    def patch(self, url: str, token: Any = None, **kwargs) -> requests.Response:
        """HTTP PATCH request."""
        return self.request("PATCH", url, token=token, **kwargs)

    def _resolve_url(self, url: str) -> str:
        """Resolve a URL against the base studio URL.

        - Relative paths → prepend studio_node_url
        - Auth/SDP/Asset endpoints → strip /nodeX/ from path
        - Absolute URLs → pass through unchanged
        """
        if url.startswith("http://") or url.startswith("https://"):
            resolved = url
        elif url.startswith("/"):
            resolved = self.config.studio_node_url + url
        else:
            resolved = self.config.studio_node_url + "/" + url

        # Strip /nodeX/ for auth, sdp, assets endpoints
        for pattern in _NODE_STRIP_PATTERNS:
            resolved = pattern.sub("/", resolved)

        return resolved

    def _do_request(self, method, url, data, headers, files, params, auth) -> requests.Response:
        """Execute the actual HTTP request."""
        kwargs = {
            "url": url,
            "headers": headers,
            "verify": self.config.verify_ssl,
            "timeout": self.config.request_timeout,
        }
        if auth:
            kwargs["auth"] = auth

        if method == "GET":
            kwargs["params"] = data if params is None else params
            return self.session.get(**kwargs)
        elif method == "POST":
            kwargs["data"] = data
            kwargs["files"] = files
            return self.session.post(**kwargs)
        elif method == "PUT":
            kwargs["data"] = data
            kwargs["files"] = files
            return self.session.put(**kwargs)
        elif method == "DELETE":
            kwargs["data"] = data
            return self.session.delete(**kwargs)
        elif method == "PATCH":
            kwargs["data"] = data
            kwargs["files"] = files
            return self.session.patch(**kwargs)

    def close(self) -> None:
        """Close the HTTP session."""
        self.session.close()


def parse_response(response: requests.Response, expected_status: int = 200) -> dict:
    """Parse a Krista API response and check for errors.

    All Krista APIs return: {"isError": false, "payload": {...}}

    Args:
        response: The HTTP response.
        expected_status: Expected HTTP status code.

    Returns:
        The full response dict (with isError and payload).

    Raises:
        KristaAPIError: If status code doesn't match expected.
        KristaValidationError: If response has isError=True.
    """
    if response.status_code != expected_status:
        raise KristaAPIError(
            f"HTTP {response.status_code}: {response.text[:300]}",
            status_code=response.status_code,
            url=response.url,
            method=response.request.method if response.request else "",
            response_body=response.text,
        )

    try:
        data = response.json()
    except (json.JSONDecodeError, ValueError):
        # Some endpoints return plain text (e.g., media upload returns media ID)
        return {"payload": response.text, "isError": False}

    if data.get("isError"):
        errors = data.get("payload", {}).get("validationErrors", []) if isinstance(data.get("payload"), dict) else []
        raise KristaValidationError(
            f"API error: {response.text[:300]}",
            validation_errors=errors,
            status_code=response.status_code,
            url=response.url,
            method=response.request.method if response.request else "",
            response_body=response.text,
        )

    return data
