"""User management operations: CRUD, bulk add/delete, role assignment."""

from __future__ import annotations

import json
import logging
import time
from typing import TYPE_CHECKING

from .client import parse_response

if TYPE_CHECKING:
    from .auth import KristaToken
    from .client import KristaClient
    from .config import KristaConfig

logger = logging.getLogger("krista_lib.users")


class UserManager:
    """Manage users/contacts in a Krista workspace."""

    def __init__(self, config: KristaConfig, client: KristaClient, token: KristaToken):
        self._config = config
        self._client = client
        self._token = token

    def list_all(self) -> list[dict]:
        """Download all contacts/users in the workspace.

        POST /api/rpc/v1/studio/wsContactDownload
        """
        url = "/api/rpc/v1/studio/wsContactDownload"
        body = {"context": {}, "payload": self._config.workspace_id}
        response = self._client.post(url, token=self._token, data=json.dumps(body))
        data = parse_response(response)
        payload = data.get("payload", {})

        # Handle different response shapes
        if isinstance(payload, dict):
            return payload.get("wsContacts", [])
        elif isinstance(payload, list):
            return payload
        return []

    def search(self, query: str = "") -> list[dict]:
        """Search users in the workspace.

        POST /appliance/{ws_id}/user/search
        """
        url = f"/appliance/{self._config.workspace_id}/user/search"
        body = {"query": query}
        response = self._client.post(url, token=self._token, data=json.dumps(body))
        data = parse_response(response)
        return data.get("payload", [])

    def send_invite(self, ws_contact_ids: list[str]) -> dict:
        """Send user invitations to workspace contacts.

        POST /appliance/{ws_id}/user/send-invite
        Payload is an array of wsContactId strings.

        Args:
            ws_contact_ids: List of wsContactId values to invite.
        """
        url = f"/appliance/{self._config.workspace_id}/user/send-invite"
        response = self._client.post(url, token=self._token, data=json.dumps(ws_contact_ids))
        data = parse_response(response)
        return data.get("payload", {})

    def make_admin_or_assign_role(
        self,
        account_ids: list[str],
        is_admin: bool | None = None,
        role_ids: list[str] | None = None,
    ) -> list[dict]:
        """Make users admin or assign roles.

        POST /appliance/{ws_id}/user/update/makeAdminOrRole

        Args:
            account_ids: List of wsContactId/accountId values.
            is_admin: Set True to make admin, False to remove admin, None to leave unchanged.
            role_ids: List of role IDs to assign.

        Returns:
            Updated user records.
        """
        url = f"/appliance/{self._config.workspace_id}/user/update/makeAdminOrRole"
        body = {
            "accountIds": account_ids,
            "isAdmin": is_admin,
            "roles": role_ids or [],
        }
        response = self._client.post(url, token=self._token, data=json.dumps(body))
        data = parse_response(response)
        return data.get("payload", [])

    def delete_contacts(self, contacts: list[dict]) -> None:
        """Delete contacts from the workspace.

        POST /api/rpc/v1/studio/wsDeleteContacts

        Args:
            contacts: List of contact dicts (as returned by list_all).
        """
        url = "/api/rpc/v1/studio/wsDeleteContacts"
        body = {
            "context": {},
            "payload": {
                "contacts": contacts,
                "workspaceId": self._config.workspace_id,
            },
        }
        response = self._client.post(url, token=self._token, data=json.dumps(body))
        parse_response(response)
        logger.info("Deleted %d contacts", len(contacts))

    def delete_by_filter(
        self,
        email_contains: str = "",
        batch_size: int = 500,
        dry_run: bool = False,
    ) -> list[dict]:
        """Delete users matching an email filter in batches.

        Args:
            email_contains: Filter users whose email contains this string.
            batch_size: Number of users to delete per batch.
            dry_run: If True, return matches without deleting.

        Returns:
            List of matched users.
        """
        all_users = self.list_all()
        targets = []
        for user in all_users:
            for pid in user.get("publicIds", []):
                if pid.get("tokenType") == "email" and email_contains in pid.get("value", ""):
                    targets.append(user)
                    break

        logger.info("Found %d users matching '%s'", len(targets), email_contains)

        if dry_run:
            return targets

        # Delete in batches
        for i in range(0, len(targets), batch_size):
            batch = targets[i:i + batch_size]
            self.delete_contacts(batch)
            logger.info("Deleted batch %d-%d of %d", i, i + len(batch), len(targets))
            if i + batch_size < len(targets):
                time.sleep(5)  # Brief pause between batches

        return targets

    def add_from_excel(
        self,
        file_path: str,
        batch_size: int = 1000,
        delay_between_batches: int = 60,
    ) -> int:
        """Bulk add users from an Excel file.

        Args:
            file_path: Path to the Excel file with user data.
            batch_size: Number of users to add per batch.
            delay_between_batches: Seconds to wait between batches.

        Returns:
            Total number of users processed.
        """
        try:
            import openpyxl
        except ImportError:
            raise ImportError("openpyxl required for Excel import. Install with: pip install 'krista-lib[excel]'")

        wb = openpyxl.load_workbook(file_path)
        ws = wb.active
        rows = list(ws.iter_rows(min_row=2, values_only=True))  # Skip header
        total = 0

        for i in range(0, len(rows), batch_size):
            batch = rows[i:i + batch_size]
            for row in batch:
                email = row[0] if row else None
                if email:
                    try:
                        self.send_invite(str(email))
                        total += 1
                    except Exception as e:
                        logger.warning("Failed to invite %s: %s", email, e)

            logger.info("Processed batch %d-%d of %d", i, i + len(batch), len(rows))
            if i + batch_size < len(rows):
                time.sleep(delay_between_batches)

        return total
