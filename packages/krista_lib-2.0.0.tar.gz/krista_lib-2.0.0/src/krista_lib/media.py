"""Media server file upload operations."""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING

from .client import parse_response
from .exceptions import KristaFileError

if TYPE_CHECKING:
    from .auth import KristaToken
    from .client import KristaClient
    from .config import KristaConfig

logger = logging.getLogger("krista_lib.media")

MIME_TYPES = {
    "jar": "application/java-archive",
    "json": "application/json",
    "xml": "application/xml",
    "pdf": "application/pdf",
    "xlsx": "application/vnd.ms-excel",
    "xls": "application/vnd.ms-excel",
    "docx": "application/msword",
    "doc": "application/msword",
    "csv": "text/csv",
    "txt": "text/plain",
    "html": "text/html",
    "htm": "text/html",
    "css": "text/css",
    "js": "application/javascript",
    "jpg": "image/jpeg",
    "jpeg": "image/jpeg",
    "png": "image/png",
    "gif": "image/gif",
    "mp3": "audio/mpeg",
    "mp4": "video/mp4",
    "zip": "application/zip",
    "ppt": "application/vnd.ms-powerpoint",
    "pptx": "application/vnd.ms-powerpoint",
}


class MediaManager:
    """Upload files to the Krista media server."""

    def __init__(self, config: KristaConfig, client: KristaClient, token: KristaToken):
        self._config = config
        self._client = client
        self._token = token

    def upload(self, file_path: str, scope: str = "messages", token: KristaToken | None = None) -> str:
        """Upload a file to the media server.

        POST /media/workspaces/{ws_id}

        Args:
            file_path: Absolute path to the file.
            scope: Upload scope ("messages" or "assets").
            token: Override token (e.g., appliance token).

        Returns:
            Media ID string.

        Raises:
            KristaFileError: If file not found or upload fails.
        """
        if not os.path.exists(file_path):
            raise KristaFileError(f"File not found: {file_path}")

        t = token or self._token
        f_name = os.path.basename(file_path)
        f_ext = f_name.rsplit(".", 1)[-1].lower() if "." in f_name else ""
        content_type = MIME_TYPES.get(f_ext, "application/octet-stream")

        url = f"/media/workspaces/{self._config.workspace_id}"
        payload = {"scope": scope}
        files = [("file", (f_name, open(file_path, "rb"), content_type))]

        logger.info("Uploading file: %s (%s)", f_name, content_type)
        response = self._client.put(url, token=t, data=payload, files=files, remove_content_type=True)

        if response.status_code != 200:
            raise KristaFileError(f"Upload failed for {f_name}: HTTP {response.status_code} — {response.text}")

        media_id = response.text.strip()
        logger.info("Upload complete: %s → %s", f_name, media_id[:40])
        return media_id
