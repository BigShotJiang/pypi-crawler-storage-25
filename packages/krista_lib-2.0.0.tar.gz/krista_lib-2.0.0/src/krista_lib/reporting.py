"""Report generation and metrics collection."""

from __future__ import annotations

import json
import logging
import time
from contextlib import contextmanager
from dataclasses import dataclass, field

logger = logging.getLogger("krista_lib.reporting")


@dataclass
class MetricEntry:
    """Single metric data point."""
    name: str
    status: str = "PASS"       # PASS, FAIL, ERROR, SKIP
    duration_ms: float = 0
    metadata: dict = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


class MetricsCollector:
    """Collect metrics during test/automation execution.

    Usage:
        metrics = MetricsCollector()
        with metrics.measure("test_1"):
            run_test()
        metrics.record(status="PASS", response_time=150)
        summary = metrics.summary()
    """

    def __init__(self):
        self._entries: list[MetricEntry] = []
        self._current_name: str = ""
        self._current_start: float = 0

    @contextmanager
    def measure(self, name: str):
        """Context manager to measure execution time.

        Usage:
            with metrics.measure("my_operation"):
                do_something()
        """
        self._current_name = name
        self._current_start = time.time()
        try:
            yield
        except Exception as e:
            elapsed = (time.time() - self._current_start) * 1000
            self._entries.append(MetricEntry(
                name=name, status="ERROR", duration_ms=elapsed,
                metadata={"error": str(e)},
            ))
            raise
        else:
            elapsed = (time.time() - self._current_start) * 1000
            self._entries.append(MetricEntry(
                name=name, status="PASS", duration_ms=elapsed,
            ))

    def record(self, name: str = "", status: str = "PASS", response_time: float = 0, **metadata) -> None:
        """Manually record a metric entry.

        Args:
            name: Name/label for this entry.
            status: PASS, FAIL, ERROR, SKIP.
            response_time: Duration in milliseconds.
            **metadata: Additional key-value pairs.
        """
        self._entries.append(MetricEntry(
            name=name or self._current_name,
            status=status,
            duration_ms=response_time,
            metadata=metadata,
        ))

    def summary(self) -> dict:
        """Generate summary statistics.

        Returns:
            Dict with total, passed, failed, errored, min_ms, max_ms, avg_ms.
        """
        total = len(self._entries)
        if total == 0:
            return {"total": 0, "passed": 0, "failed": 0, "errored": 0, "min_ms": 0, "max_ms": 0, "avg_ms": 0}

        durations = [e.duration_ms for e in self._entries]
        return {
            "total": total,
            "passed": sum(1 for e in self._entries if e.status == "PASS"),
            "failed": sum(1 for e in self._entries if e.status == "FAIL"),
            "errored": sum(1 for e in self._entries if e.status == "ERROR"),
            "skipped": sum(1 for e in self._entries if e.status == "SKIP"),
            "min_ms": round(min(durations), 2),
            "max_ms": round(max(durations), 2),
            "avg_ms": round(sum(durations) / total, 2),
        }

    @property
    def entries(self) -> list[MetricEntry]:
        return self._entries


class JSONReport:
    """Generate JSON reports from metrics."""

    def __init__(self, metrics: MetricsCollector):
        self._metrics = metrics

    def save(self, file_path: str) -> None:
        """Save metrics to a JSON file."""
        data = {
            "summary": self._metrics.summary(),
            "entries": [
                {
                    "name": e.name,
                    "status": e.status,
                    "duration_ms": round(e.duration_ms, 2),
                    "timestamp": e.timestamp,
                    "metadata": e.metadata,
                }
                for e in self._metrics.entries
            ],
        }
        with open(file_path, "w") as f:
            json.dump(data, f, indent=4)
        logger.info("JSON report saved: %s", file_path)


class ExcelReport:
    """Generate Excel reports from metrics.

    Requires openpyxl: pip install 'krista-lib[excel]'
    """

    def __init__(self, metrics: MetricsCollector):
        self._metrics = metrics

    def save(self, file_path: str) -> None:
        """Save metrics to an Excel file with summary and detail sheets."""
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, PatternFill
        except ImportError:
            raise ImportError("openpyxl required. Install with: pip install 'krista-lib[excel]'")

        wb = Workbook()

        # Summary sheet
        ws_summary = wb.active
        ws_summary.title = "Summary"
        summary = self._metrics.summary()
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")

        for col, (key, value) in enumerate(summary.items(), 1):
            cell = ws_summary.cell(row=1, column=col, value=key)
            cell.fill = header_fill
            cell.font = header_font
            ws_summary.cell(row=2, column=col, value=value)

        # Detail sheet
        ws_detail = wb.create_sheet("Details")
        detail_headers = ["Name", "Status", "Duration (ms)", "Timestamp"]
        for col, header in enumerate(detail_headers, 1):
            cell = ws_detail.cell(row=1, column=col, value=header)
            cell.fill = header_fill
            cell.font = header_font

        for row, entry in enumerate(self._metrics.entries, 2):
            ws_detail.cell(row=row, column=1, value=entry.name)
            ws_detail.cell(row=row, column=2, value=entry.status)
            ws_detail.cell(row=row, column=3, value=round(entry.duration_ms, 2))
            ws_detail.cell(row=row, column=4, value=entry.timestamp)

        # Auto-width columns
        for ws in [ws_summary, ws_detail]:
            for col in ws.columns:
                max_len = max(len(str(cell.value or "")) for cell in col)
                ws.column_dimensions[col[0].column_letter].width = min(max_len + 4, 50)

        wb.save(file_path)
        logger.info("Excel report saved: %s", file_path)
