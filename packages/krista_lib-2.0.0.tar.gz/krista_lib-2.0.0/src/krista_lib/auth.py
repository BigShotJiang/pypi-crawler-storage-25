"""Authentication module for Krista platform.

Supports JWT (current) and legacy session-based authentication.
Includes token refresh, logout, and token tracking.
"""

from __future__ import annotations

import json
import logging
import re
import time
import urllib.parse
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from .exceptions import KristaAuthError, KristaConfigError, KristaTokenExpiredError
from .utils import base64encode

if TYPE_CHECKING:
    from .client import KristaClient
    from .config import KristaConfig

logger = logging.getLogger("krista_lib.auth")

# Refresh token when it reaches 67% of its lifetime (40 min of 60 min TTL)
_REFRESH_THRESHOLD_MINUTES = 40


@dataclass
class KristaToken:
    """Represents an authenticated session (JWT or legacy session).

    This is auth-method-agnostic — callers use .headers() without
    caring whether it's JWT or session-based.
    """
    auth_method: str       # "jwt" | "session"
    app_name: str          # "studio" | "client"
    access_token: str      # JWT token or clientSessionId
    username: str
    created_at: float = field(default_factory=time.time)
    _invalidated: bool = field(default=False, repr=False)

    def headers(self, content_type: str = "application/json; charset=UTF-8") -> dict:
        """Build request headers for this token.

        Args:
            content_type: Content-Type header value. Pass empty string to omit.
        """
        if self._invalidated:
            raise KristaTokenExpiredError("Token has been invalidated (logged out)")

        if self.auth_method == "jwt":
            h = {
                "Cookie": f"X-Krista-Access-Token={self.access_token}",
                "X-Krista-Application": self.app_name,
            }
        else:
            ctx = json.dumps({"clientSessionId": self.access_token})
            h = {"Cookie": f"X-Krista-Context={urllib.parse.quote(ctx)}"}

        if content_type:
            h["Content-Type"] = content_type
        return h

    def headers_no_content_type(self) -> dict:
        """Headers for multipart/file uploads (Content-Type set by requests)."""
        return self.headers(content_type="")

    def is_expired(self) -> bool:
        """Check if the JWT token has expired based on its iat claim.

        For session tokens, always returns False.
        """
        if self._invalidated:
            return True
        if self.auth_method != "jwt":
            return False
        return self._get_token_age_minutes() >= 60  # JWT TTL is 60 minutes

    def needs_refresh(self) -> bool:
        """Check if the token should be proactively refreshed."""
        if self._invalidated or self.auth_method != "jwt":
            return False
        return self._get_token_age_minutes() >= _REFRESH_THRESHOLD_MINUTES

    def invalidate(self) -> None:
        """Mark this token as invalid (called after logout)."""
        self._invalidated = True

    def _get_token_age_minutes(self) -> float:
        """Get the age of the JWT token in minutes from its iat claim."""
        try:
            import base64 as b64
            parts = self.access_token.split(".")
            if len(parts) != 3:
                return 0

            payload = parts[1]
            # Add padding
            padding = len(payload) % 4
            if padding:
                payload += "=" * (4 - padding)

            decoded = json.loads(b64.urlsafe_b64decode(payload))
            iat = decoded.get("iat", 0)
            if iat:
                return (time.time() - iat) / 60
        except Exception:
            pass
        # Fallback to creation time
        return (time.time() - self.created_at) / 60


class KristaAuth:
    """Authentication manager for the Krista platform.

    Handles login (JWT + legacy session), logout, and token refresh.
    Tracks all tokens for bulk logout.

    Usage:
        auth = KristaAuth(config, client)
        token = auth.login()
        # ... use token ...
        auth.logout_all()

    Context manager:
        with KristaAuth(config, client) as auth:
            token = auth.login()
            # ... auto-logout on exit ...
    """

    def __init__(self, config: KristaConfig, client: KristaClient):
        self.config = config
        self.client = client
        self._tokens: list[dict] = []  # Track all tokens for logout_all

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.logout_all()
        return False  # Don't suppress exceptions

    def login(
        self,
        username: str | None = None,
        password: str | None = None,
        app_name: str = "studio",
        is_appliance: bool = False,
    ) -> KristaToken:
        """Login to Krista and return a token.

        Uses JWT or session-based auth depending on config.auth_method.

        Args:
            username: Email address. Defaults to config.username.
            password: Password. Defaults to config.password.
            app_name: Application name ("studio" or "client").
            is_appliance: If True, use appliance login endpoint.

        Returns:
            KristaToken that can be used for API calls.

        Raises:
            KristaAuthError: On login failure.
            KristaConfigError: If credentials are missing.
        """
        user = username or (self.config.appliance_username if is_appliance else self.config.username)
        pwd = password or (self.config.appliance_password if is_appliance else self.config.password)

        if not user:
            raise KristaConfigError("Username is required for login")
        if not pwd:
            raise KristaConfigError(
                "Password is required. Set KRISTA_PASSWORD (or KRISTA_APPLIANCE_PASSWORD) environment variable."
            )

        if self.config.auth_method == "jwt":
            token = self._jwt_login(user, pwd, app_name, is_appliance)
        else:
            token = self._session_login(user, pwd, app_name, is_appliance)

        # Track for logout_all
        self._tokens.append({"token": token, "user": user, "app": app_name})
        logger.info("Login successful: %s (%s)", user, app_name)
        return token

    def login_appliance(
        self,
        username: str | None = None,
        password: str | None = None,
        app_name: str = "studio",
    ) -> KristaToken:
        """Convenience method for appliance user login."""
        return self.login(username=username, password=password, app_name=app_name, is_appliance=True)

    def logout(self, token: KristaToken) -> None:
        """Logout a specific token.

        Calls POST /auth/v1/logout to invalidate the token server-side.
        Best-effort: does not raise on failure.
        """
        if token._invalidated:
            return

        try:
            url = self.config.base_url + "/auth/v1/logout"
            headers = token.headers()
            self.client.session.post(
                url=url,
                headers=headers,
                data=json.dumps({"payload": {}}),
                verify=self.config.verify_ssl,
                timeout=10,
            )
            token.invalidate()
            logger.info("Logged out: %s (%s)", token.username, token.app_name)
        except Exception as e:
            logger.warning("Logout failed for %s (%s): %s", token.username, token.app_name, e)
            token.invalidate()  # Mark invalid anyway

    def logout_all(self) -> None:
        """Logout all tokens that were created by this auth instance."""
        if not self._tokens:
            return

        logger.info("Logging out %d session(s)...", len(self._tokens))
        for entry in self._tokens:
            token = entry["token"]
            try:
                self.logout(token)
            except Exception as e:
                logger.warning("Logout failed for %s: %s", entry["user"], e)
        self._tokens.clear()

    def refresh_token(self, token: KristaToken) -> KristaToken:
        """Refresh a JWT access token.

        Uses POST /auth/v1/refresh with the refresh token cookie
        (automatically managed by requests.Session).

        Args:
            token: The token to refresh.

        Returns:
            Updated KristaToken with new access token.
        """
        if token.auth_method != "jwt":
            return token

        if not token.needs_refresh():
            return token

        try:
            url = self.config.base_url + "/auth/v1/refresh"
            headers = {
                "Content-Type": "application/json; charset=UTF-8",
                "X-Krista-Application": token.app_name,
            }
            response = self.client.session.post(
                url=url,
                headers=headers,
                data=json.dumps({"payload": {}}),
                verify=self.config.verify_ssl,
                timeout=10,
            )

            if response.status_code == 200:
                data = response.json()
                new_access_token = data.get("payload", {}).get("accessToken")
                if new_access_token:
                    token.access_token = new_access_token
                    token.created_at = time.time()
                    logger.info("Token refreshed: %s (%s)", token.username, token.app_name)
                else:
                    logger.warning("No accessToken in refresh response for %s", token.username)
            else:
                logger.warning("Token refresh failed HTTP %d for %s", response.status_code, token.username)

        except Exception as e:
            logger.warning("Token refresh error for %s: %s", token.username, e)

        return token

    def get_available_workspaces(self, username: str | None = None, app_name: str = "studio") -> list[dict]:
        """Get available workspaces for a user via verify-person.

        Calls POST /auth/v1/verify-person.

        Returns:
            List of workspace dicts with workspaceId, workspaceName, nodeName.
        """
        user = username or self.config.username
        url = self.config.base_url + "/auth/v1/verify-person"
        payload = {
            "payload": {
                "identificationToken": {"tokenType": "email", "value": user},
                "application": app_name.upper(),
            }
        }
        headers = {"Content-Type": "application/json; charset=UTF-8", "X-Krista-Application": app_name}
        response = self.client.session.post(
            url=url, headers=headers, data=json.dumps(payload),
            verify=self.config.verify_ssl, timeout=self.config.request_timeout,
        )

        if response.status_code != 200:
            raise KristaAuthError(f"verify-person failed: HTTP {response.status_code} — {response.text}")

        data = response.json()
        if data.get("isError"):
            raise KristaAuthError(f"verify-person error: {response.text}")

        return data.get("payload", {}).get("authMeta", [])

    def forgot_password(self, email: str, app_name: str = "studio") -> dict:
        """Trigger forgot-password flow.

        POST /auth/v1/forgotPassword
        """
        url = self.config.base_url + "/auth/v1/forgotPassword"
        body = {
            "context": {},
            "payload": {
                "identificationToken": {"tokenType": "email", "value": email},
                "workspaceId": self.config.workspace_id,
                "appVersion": {"name": "studio", "version": "release-2.1", "build": "release-2.1"},
                "application": app_name,
            },
        }
        headers = {"Content-Type": "application/json; charset=UTF-8"}
        response = self.client.session.post(
            url=url, headers=headers, data=json.dumps(body),
            verify=self.config.verify_ssl, timeout=self.config.request_timeout,
        )
        if response.status_code != 200:
            raise KristaAuthError(f"forgot_password failed: HTTP {response.status_code} — {response.text[:300]}")
        return response.json()

    def change_password(self, email: str, old_password: str, new_password: str,
                        token: KristaToken | None = None, app_name: str = "studio") -> dict:
        """Change user password.

        POST /auth/v1/changePassword
        """
        url = self.config.base_url + "/auth/v1/changePassword"
        body = {
            "context": {},
            "payload": {
                "identificationToken": {"tokenType": "email", "value": email},
                "oldPassword": base64encode(old_password),
                "newPassword": base64encode(new_password),
            },
        }
        t = token or (self._tokens[0]["token"] if self._tokens else None)
        headers = {"Content-Type": "application/json; charset=UTF-8", "X-Krista-Application": app_name}
        if t:
            headers["Cookie"] = f"X-Krista-Access-Token={t.access_token}"
        response = self.client.session.post(
            url=url, headers=headers, data=json.dumps(body),
            verify=self.config.verify_ssl, timeout=self.config.request_timeout,
        )
        if response.status_code != 200:
            raise KristaAuthError(f"change_password failed: HTTP {response.status_code} — {response.text[:300]}")
        return response.json()

    # ── JWT Auth Strategy ──────────────────────────────────────────────

    def _jwt_login(self, username: str, password: str, app_name: str, is_appliance: bool) -> KristaToken:
        """JWT login: single-step POST to /auth/v1/login/password or /auth/v1/appliance-login."""
        if is_appliance:
            body = {
                "payload": {
                    "identificationToken": {"tokenType": "email", "value": username},
                    "password": base64encode(password),
                    "application": app_name.upper(),
                }
            }
            url = self.config.base_url + "/auth/v1/appliance-login"
        else:
            body = {
                "payload": {
                    "authType": "local",
                    "identificationToken": {"tokenType": "email", "value": username},
                    "password": base64encode(password),
                }
            }
            base = self.config.client_node_url if app_name == "client" else self.config.studio_node_url
            url = base + "/auth/v1/login/password"

        # Strip /nodeX/ from auth URLs (auth endpoints sit outside the node path)
        url = re.sub(r"/node\d+/(?=auth/)", "/", url)

        headers = {"Content-Type": "application/json; charset=UTF-8", "X-Krista-Application": app_name}
        response = self.client.session.post(
            url=url, headers=headers, data=json.dumps(body),
            verify=self.config.verify_ssl, timeout=self.config.request_timeout,
        )

        if response.status_code != 200:
            raise KristaAuthError(
                f"Login failed [{app_name.upper()}] — HTTP {response.status_code} | "
                f"User: {username} | URL: {url} | Response: {response.text[:500]}"
            )

        data = response.json()
        if data.get("isError"):
            raise KristaAuthError(f"Login error [{app_name.upper()}]: {data}")

        access_token = data.get("payload", {}).get("accessToken")
        if not access_token:
            raise KristaAuthError(f"No accessToken returned for {username}")

        # Check refresh token cookie
        if not self.client.session.cookies.get("X-Krista-Refresh-Token"):
            logger.warning("Refresh Token NOT in cookies for %s — token refresh may fail", username)

        return KristaToken(
            auth_method="jwt",
            app_name=app_name,
            access_token=access_token,
            username=username,
        )

    # ── Legacy Session Auth Strategy ───────────────────────────────────

    def _session_login(self, username: str, password: str, app_name: str, is_appliance: bool) -> KristaToken:
        """Legacy 3-step session login. Kept for backward compatibility."""
        if is_appliance:
            return self._session_appliance_login(username, password, app_name)

        # Step 1: Verify email → loginCode
        verify_url = re.sub(r"/node\d+/?$", "", self.config.studio_node_url) + "/sdp/v1/auth/verify-email"
        verify_body = {
            "payload": {
                "identificationToken": {"tokenType": "email", "value": username},
                "appVersion": {"name": app_name.upper(), "version": "release-3.5", "build": "dev"},
                "application": app_name.upper(),
                "rememberMeToken": "0ee22a5d-7c18-4a3c-a3ed-893e5d0ecdfb",
            }
        }
        headers = {"Content-Type": "application/json; charset=UTF-8"}
        response = self.client.session.post(
            url=verify_url, headers=headers, data=json.dumps(verify_body),
            verify=self.config.verify_ssl, timeout=self.config.request_timeout,
        )
        if response.status_code != 200:
            raise KristaAuthError(f"verify-email failed: {response.text}")

        verify_data = response.json()
        if verify_data.get("isError"):
            raise KristaAuthError(f"verify-email error: {verify_data}")
        login_code = verify_data["payload"]["loginCode"]

        # Step 2: Validate login code
        login_page_url = self.config.base_url + f"/sdp/v1/auth/login-page?loginCode={login_code}"
        response = self.client.session.get(
            url=login_page_url, verify=self.config.verify_ssl, timeout=self.config.request_timeout,
        )
        if response.status_code != 200:
            raise KristaAuthError(f"login-page validation failed: {response.text}")

        # Step 3: Login with validated code
        login_url = self.config.studio_node_url + "/api/rpc/v1/auth/login"
        login_body = {
            "context": {"transactionId": None},
            "payload": {
                "identificationToken": {"tokenType": "email", "value": username},
                "workspaceId": self.config.workspace_id,
                "password": base64encode(password),
                "loginCode": login_code,
                "appVersion": {"name": app_name.upper(), "version": "release-3.5", "build": "dev"},
                "application": app_name.upper(),
            },
        }
        response = self.client.session.post(
            url=login_url, headers=headers, data=json.dumps(login_body),
            verify=self.config.verify_ssl, timeout=self.config.request_timeout,
        )
        if response.status_code != 200:
            raise KristaAuthError(f"Session login failed: {response.text}")

        session_id = response.json().get("payload", {}).get("clientSessionId")
        if not session_id:
            raise KristaAuthError(f"No clientSessionId returned for {username}")

        return KristaToken(
            auth_method="session",
            app_name=app_name,
            access_token=session_id,
            username=username,
        )

    def _session_appliance_login(self, username: str, password: str, app_name: str) -> KristaToken:
        """Legacy appliance login (single step)."""
        url = re.sub(r"/node\d+/?$", "", self.config.studio_node_url) + "/sdp/v1/auth/appliance-login"
        body = {
            "payload": {
                "identificationToken": {"tokenType": "email", "value": username},
                "password": base64encode(password),
                "appVersion": {"name": "STUDIO", "version": "release-3.5", "build": "dev"},
                "application": app_name.upper(),
            }
        }
        headers = {"Content-Type": "application/json; charset=UTF-8"}
        response = self.client.session.post(
            url=url, headers=headers, data=json.dumps(body),
            verify=self.config.verify_ssl, timeout=self.config.request_timeout,
        )
        if response.status_code != 200:
            raise KristaAuthError(f"Appliance login failed: {response.text}")

        session_id = response.json().get("payload", {}).get("clientSessionId")
        if not session_id:
            raise KristaAuthError(f"No clientSessionId for appliance user {username}")

        return KristaToken(
            auth_method="session",
            app_name=app_name,
            access_token=session_id,
            username=username,
        )
