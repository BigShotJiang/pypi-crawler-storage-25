"""Configuration management for krista-lib.

Supports layered configuration with precedence: CLI args > env vars > config file > defaults.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field

from .exceptions import KristaConfigError


@dataclass
class KristaConfig:
    """Configuration for connecting to a Krista environment.

    Passwords are NEVER loaded from config files. They must come from
    environment variables or be passed explicitly.
    """

    # Connection
    studio_url: str = ""
    node: str = "node1"
    client_url: str = ""
    extension_url: str = ""

    # Authentication
    username: str = ""
    password: str = ""
    appliance_username: str = ""
    appliance_password: str = ""
    auth_method: str = "jwt"  # "jwt" | "session"

    # Workspace
    workspace_id: str = ""
    workspace_name: str = ""

    # Extension context (optional)
    ecosystem: str = ""
    domain: str = ""
    extension_name: str = ""
    invoker_names: list[str] = field(default_factory=list)
    conversation_name: str = ""
    client_api_ext_name: str = ""
    topic_name: str = ""

    # HTTP settings
    request_timeout: int = 30
    verify_ssl: bool = False
    max_retries: int = 3
    retry_backoff: float = 1.0

    # Logging
    log_level: str = "INFO"
    log_file: str = ""
    log_curl: bool = False

    @property
    def studio_node_url(self) -> str:
        """Full URL with node: https://studio.qa-in.eng.krista.app/node1"""
        base = self.studio_url.rstrip("/")
        return f"{base}/{self.node}" if self.node else base

    @property
    def client_node_url(self) -> str:
        """Client URL with node."""
        base = (self.client_url or self.studio_url).rstrip("/")
        return f"{base}/{self.node}" if self.node else base

    @property
    def ext_node_url(self) -> str:
        """Extension URL with node."""
        base = (self.extension_url or self.studio_url).rstrip("/")
        return f"{base}/{self.node}" if self.node else base

    @property
    def base_url(self) -> str:
        """URL without node, for auth endpoints."""
        return self.studio_url.rstrip("/")

    def validate(self) -> None:
        """Validate that required configuration is present."""
        if not self.studio_url:
            raise KristaConfigError("studio_url is required")
        if not self.username:
            raise KristaConfigError("username is required")

    @classmethod
    def from_json(cls, file_path: str) -> KristaConfig:
        """Load configuration from a JSON file.

        Passwords in the JSON file are IGNORED for security.
        Passwords must be set via environment variables or explicitly.

        Args:
            file_path: Path to JSON config file.

        Returns:
            KristaConfig instance.
        """
        if not os.path.exists(file_path):
            raise KristaConfigError(f"Config file not found: {file_path}")

        with open(file_path) as f:
            data = json.load(f)

        # Map qa-lib-1.0.2 field names to new names
        field_map = {
            "studio_url": "studio_url",
            "client_url": "client_url",
            "extension_url": "extension_url",
            "node": "node",
            "username": "username",
            "workspace_id": "workspace_id",
            "workspace_name": "workspace_name",
            "ecosystem": "ecosystem",
            "domain": "domain",
            "extension_name": "extension_name",
            "conversation_name": "conversation_name",
            "client_api_ext_name": "client_api_ext_name",
            "topic_name": "topic_name",
            "auth_method": "auth_method",
        }

        kwargs = {}
        for json_key, attr_name in field_map.items():
            if json_key in data:
                kwargs[attr_name] = data[json_key]

        # Handle invoker_names (comma-separated string or list)
        if "invoker_names" in data:
            val = data["invoker_names"]
            kwargs["invoker_names"] = val.split(",") if isinstance(val, str) else val

        config = cls(**kwargs)

        # Load passwords from environment variables
        config._load_passwords_from_env()

        return config

    @classmethod
    def from_env(cls) -> KristaConfig:
        """Load configuration entirely from environment variables.

        Environment variables:
            KRISTA_STUDIO_URL, KRISTA_NODE, KRISTA_CLIENT_URL, KRISTA_EXTENSION_URL,
            KRISTA_USERNAME, KRISTA_PASSWORD, KRISTA_WORKSPACE_ID, KRISTA_WORKSPACE_NAME,
            KRISTA_APPLIANCE_USERNAME, KRISTA_APPLIANCE_PASSWORD,
            KRISTA_AUTH_METHOD, KRISTA_LOG_LEVEL
        """
        config = cls(
            studio_url=os.environ.get("KRISTA_STUDIO_URL", ""),
            node=os.environ.get("KRISTA_NODE", "node1"),
            client_url=os.environ.get("KRISTA_CLIENT_URL", ""),
            extension_url=os.environ.get("KRISTA_EXTENSION_URL", ""),
            username=os.environ.get("KRISTA_USERNAME", ""),
            password=os.environ.get("KRISTA_PASSWORD", ""),
            workspace_id=os.environ.get("KRISTA_WORKSPACE_ID", ""),
            workspace_name=os.environ.get("KRISTA_WORKSPACE_NAME", ""),
            appliance_username=os.environ.get("KRISTA_APPLIANCE_USERNAME", ""),
            appliance_password=os.environ.get("KRISTA_APPLIANCE_PASSWORD", ""),
            auth_method=os.environ.get("KRISTA_AUTH_METHOD", "jwt"),
            log_level=os.environ.get("KRISTA_LOG_LEVEL", "INFO"),
            topic_name=os.environ.get("KRISTA_TOPIC_NAME", ""),
        )
        return config

    def _load_passwords_from_env(self) -> None:
        """Load passwords from environment variables if not already set."""
        if not self.password:
            self.password = os.environ.get("KRISTA_PASSWORD", "")
        if not self.appliance_password:
            self.appliance_password = os.environ.get("KRISTA_APPLIANCE_PASSWORD", "")
        if not self.appliance_username:
            self.appliance_username = os.environ.get("KRISTA_APPLIANCE_USERNAME", "")
