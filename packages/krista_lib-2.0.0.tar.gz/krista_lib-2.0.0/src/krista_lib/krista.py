"""Main Krista facade — single entry point for all library operations.

Usage:
    from krista_lib import Krista, KristaConfig

    config = KristaConfig.from_json("config.json")
    with Krista(config) as krista:
        krista.login()
        catalogs = krista.workspace.get_catalogs()
        krista.extensions.upload_jar("/path/to.jar", "Krista", "SDK", "Extension Development")
"""

from __future__ import annotations

import atexit
import logging
from typing import TYPE_CHECKING

from .auth import KristaAuth, KristaToken
from .client import KristaClient
from .config import KristaConfig
from .log import setup_logging

if TYPE_CHECKING:
    from .conversations import ConversationManager
    from .daz import DAZManager
    from .extensions import ExtensionManager
    from .invokers import InvokerManager
    from .media import MediaManager
    from .users import UserManager
    from .workspace import WorkspaceManager

logger = logging.getLogger("krista_lib.krista")


class Krista:
    """Unified entry point for the Krista automation library.

    Wires together all managers (workspace, extensions, invokers, conversations,
    users, media, daz) and provides convenience HTTP methods.

    Supports context manager for auto-logout:
        with Krista(config) as krista:
            krista.login()
            # ... work ...
        # auto-logout here

    All sub-managers are lazy-loaded on first access.
    """

    def __init__(self, config: KristaConfig):
        self.config = config
        setup_logging(level=config.log_level, log_file=config.log_file or None)

        self._client = KristaClient(config)
        self._auth = KristaAuth(config, self._client)

        # Tokens (set after login)
        self._studio_token: KristaToken | None = None
        self._client_token: KristaToken | None = None
        self._appliance_token: KristaToken | None = None

        # Lazy-loaded managers
        self._workspace: WorkspaceManager | None = None
        self._extensions: ExtensionManager | None = None
        self._invokers: InvokerManager | None = None
        self._conversations: ConversationManager | None = None
        self._users: UserManager | None = None
        self._media: MediaManager | None = None
        self._daz: DAZManager | None = None

        # Register atexit handler for cleanup
        atexit.register(self._atexit_cleanup)

    @classmethod
    def from_env(cls) -> Krista:
        """Create a Krista instance from environment variables."""
        return cls(KristaConfig.from_env())

    @classmethod
    def from_json(cls, config_path: str) -> Krista:
        """Create a Krista instance from a JSON config file."""
        return cls(KristaConfig.from_json(config_path))

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.logout()
        return False

    # ── Authentication ──────────────────────────────────────────────────

    def login(self, username: str | None = None, password: str | None = None, app_name: str = "studio") -> KristaToken:
        """Login to Krista Studio.

        Args:
            username: Override username (defaults to config).
            password: Override password (defaults to env var).
            app_name: Application name ("studio" or "client").

        Returns:
            KristaToken for the logged-in user.
        """
        token = self._auth.login(username=username, password=password, app_name=app_name)
        if app_name == "client":
            self._client_token = token
        else:
            self._studio_token = token
        self._invalidate_managers()
        return token

    def login_client(self, username: str | None = None, password: str | None = None) -> KristaToken:
        """Login to Krista Client."""
        token = self._auth.login(username=username, password=password, app_name="client")
        self._client_token = token
        return token

    def login_appliance(self, username: str | None = None, password: str | None = None) -> KristaToken:
        """Login as appliance user."""
        token = self._auth.login_appliance(username=username, password=password)
        self._appliance_token = token
        return token

    def logout(self) -> None:
        """Logout all active tokens."""
        self._auth.logout_all()
        self._studio_token = None
        self._client_token = None
        self._appliance_token = None
        self._invalidate_managers()

    @property
    def auth(self) -> KristaAuth:
        """Access the auth manager directly (for verify-person, etc.)."""
        return self._auth

    @property
    def token(self) -> KristaToken:
        """Current studio token."""
        if not self._studio_token:
            raise RuntimeError("Not logged in. Call krista.login() first.")
        # Auto-refresh if needed
        self._auth.refresh_token(self._studio_token)
        return self._studio_token

    @property
    def client_token(self) -> KristaToken:
        """Current client token (lazy-login if not yet created)."""
        if not self._client_token:
            self._client_token = self._auth.login(app_name="client")
        self._auth.refresh_token(self._client_token)
        return self._client_token

    @property
    def appliance_token(self) -> KristaToken | None:
        """Current appliance token (None if not logged in)."""
        if self._appliance_token:
            self._auth.refresh_token(self._appliance_token)
        return self._appliance_token

    # ── Sub-Managers (lazy-loaded) ──────────────────────────────────────

    @property
    def workspace(self) -> WorkspaceManager:
        """Workspace, catalog, ecosystem, conversation meta, topic, and role operations."""
        if self._workspace is None:
            from .workspace import WorkspaceManager
            self._workspace = WorkspaceManager(self.config, self._client, self.token)
        return self._workspace

    @property
    def extensions(self) -> ExtensionManager:
        """Extension upload, download, and deployment."""
        if self._extensions is None:
            from .extensions import ExtensionManager
            self._extensions = ExtensionManager(
                self.config, self._client, self.token, self.workspace, self.media
            )
        return self._extensions

    @property
    def invokers(self) -> InvokerManager:
        """Invoker (extension instance) management."""
        if self._invokers is None:
            from .invokers import InvokerManager
            self._invokers = InvokerManager(self.config, self._client, self.token, self.workspace)
        return self._invokers

    @property
    def conversations(self) -> ConversationManager:
        """Conversation execution and management."""
        if self._conversations is None:
            from .conversations import ConversationManager
            self._conversations = ConversationManager(
                self.config, self._client, self.token,
                self._client_token, self.workspace,
            )
        return self._conversations

    @property
    def users(self) -> UserManager:
        """User management."""
        if self._users is None:
            from .users import UserManager
            self._users = UserManager(self.config, self._client, self.token)
        return self._users

    @property
    def media(self) -> MediaManager:
        """Media server file upload."""
        if self._media is None:
            from .media import MediaManager
            self._media = MediaManager(self.config, self._client, self.token)
        return self._media

    @property
    def daz(self) -> DAZManager:
        """DAZ (catalog archive) export/import."""
        if self._daz is None:
            from .daz import DAZManager
            self._daz = DAZManager(
                self.config, self._client, self.token,
                self._appliance_token, self.workspace,
            )
        return self._daz

    # ── Convenience HTTP Methods ────────────────────────────────────────

    def get(self, url: str, **kwargs):
        """HTTP GET with studio token."""
        return self._client.get(url, token=self.token, **kwargs)

    def post(self, url: str, **kwargs):
        """HTTP POST with studio token."""
        return self._client.post(url, token=self.token, **kwargs)

    def put(self, url: str, **kwargs):
        """HTTP PUT with studio token."""
        return self._client.put(url, token=self.token, **kwargs)

    def delete(self, url: str, **kwargs):
        """HTTP DELETE with studio token."""
        return self._client.delete(url, token=self.token, **kwargs)

    def upload(self, file_path: str, **kwargs) -> str:
        """Upload a file to the media server."""
        return self.media.upload(file_path, **kwargs)

    # ── Internal ────────────────────────────────────────────────────────

    def _invalidate_managers(self) -> None:
        """Reset lazy-loaded managers (e.g., after login/logout)."""
        self._workspace = None
        self._extensions = None
        self._invokers = None
        self._conversations = None
        self._users = None
        self._media = None
        self._daz = None

    def _atexit_cleanup(self) -> None:
        """Best-effort cleanup on process exit."""
        try:
            self._auth.logout_all()
        except Exception:
            pass
