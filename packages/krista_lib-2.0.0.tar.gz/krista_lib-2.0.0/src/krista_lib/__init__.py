"""krista-lib — Enterprise automation library for the Krista platform.

Quick start:
    from krista_lib import Krista, KristaConfig

    config = KristaConfig.from_json("config.json")
    with Krista(config) as krista:
        krista.login()
        krista.login_appliance()
        catalogs = krista.workspace.get_catalogs()
"""

from ._version import __version__
from .auth import KristaAuth, KristaToken
from .client import KristaClient, parse_response
from .config import KristaConfig
from .exceptions import (
    KristaAPIError,
    KristaAuthError,
    KristaConfigError,
    KristaError,
    KristaFileError,
    KristaNotFoundError,
    KristaTimeoutError,
    KristaTokenExpiredError,
    KristaValidationError,
    KristaWebSocketError,
)
from .krista import Krista
from .log import setup_logging

__all__ = [
    "__version__",
    # Main entry points
    "Krista",
    "KristaConfig",
    # Auth
    "KristaAuth",
    "KristaToken",
    # Client
    "KristaClient",
    "parse_response",
    # Logging
    "setup_logging",
    # Exceptions
    "KristaError",
    "KristaConfigError",
    "KristaAuthError",
    "KristaTokenExpiredError",
    "KristaAPIError",
    "KristaValidationError",
    "KristaNotFoundError",
    "KristaTimeoutError",
    "KristaWebSocketError",
    "KristaFileError",
]
