"""Invoker (extension instance) management operations."""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

from .client import parse_response
from .exceptions import KristaNotFoundError
from .utils import find_one_in_list

if TYPE_CHECKING:
    from .auth import KristaToken
    from .client import KristaClient
    from .config import KristaConfig
    from .workspace import WorkspaceManager

logger = logging.getLogger("krista_lib.invokers")


class InvokerManager:
    """Manage invokers (extension instances) in a workspace.

    Uses the new REST endpoint first, falls back to legacy RPC.
    """

    def __init__(self, config: KristaConfig, client: KristaClient, token: KristaToken, workspace: WorkspaceManager):
        self._config = config
        self._client = client
        self._token = token
        self._workspace = workspace
        self._invokers_cache: list[dict] | None = None

    def list_all(self, reload: bool = False) -> list[dict]:
        """Get all invokers in the workspace.

        Tries new REST endpoint first: GET /studio/v1/workspaces/{defnWsId}/invokers
        Falls back to legacy RPC: POST /api/rpc/v1/studio/invokerGetAll
        """
        if self._invokers_cache is not None and not reload:
            return self._invokers_cache

        defn_ws_id = self._workspace.defn_ws_id

        # Try new REST endpoint (single attempt, no retries — this endpoint may not exist)
        try:
            url = f"/studio/v1/workspaces/{defn_ws_id}/invokers"
            # Use session directly to avoid retry loop on 500 (endpoint may not exist on this server)
            resolved_url = self._client._resolve_url(url)
            headers = {"X-Requested-With": "curl"}
            headers.update(self._token.headers())
            response = self._client.session.get(
                url=resolved_url, headers=headers,
                verify=self._config.verify_ssl, timeout=self._config.request_timeout,
            )
            if response.status_code == 200:
                text = response.text.strip()
                if text.startswith("{"):
                    data = response.json()
                    invokers = (
                        data.get("payload", {}).get("invokers")
                        or data.get("invokers")
                        or []
                    )
                    self._invokers_cache = invokers
                    return invokers
        except Exception as e:
            logger.debug("REST invokers endpoint failed: %s — trying RPC fallback", e)

        # Fallback to legacy RPC
        try:
            url = "/api/rpc/v1/studio/invokerGetAll"
            body = {"context": {}, "payload": {"defnWsId": defn_ws_id}}
            response = self._client.post(url, token=self._token, data=json.dumps(body))
            if response.status_code == 200:
                data = response.json()
                invokers = data.get("payload", {}).get("invokers", [])
                self._invokers_cache = invokers
                return invokers
        except Exception as e:
            logger.warning("RPC invokers endpoint also failed: %s", e)

        logger.warning("Could not get invokers — returning empty list")
        self._invokers_cache = []
        return []

    def get_by_name(self, name: str) -> dict:
        """Get a single invoker by name.

        Raises:
            KristaNotFoundError: If invoker not found.
        """
        inv = find_one_in_list(self.list_all(), "name", name)
        if not inv:
            raise KristaNotFoundError("invoker", name)
        return inv

    def get_id(self, name: str) -> str:
        """Get invoker ID by name."""
        return self.get_by_name(name)["id"]

    def get_routing_id(self, name: str) -> str:
        """Get routing ID for an invoker by name."""
        inv = self.get_by_name(name)
        routing_id = inv.get("routingId")
        if not routing_id:
            raise KristaNotFoundError("routing_id for invoker", name)
        return routing_id

    def get_details(self, name: str) -> dict:
        """Get full invoker details including extensionDescription."""
        return self.get_by_name(name)

    def get_supported_requests(self, name: str) -> list[dict]:
        """Get supported requests for an invoker."""
        inv = self.get_by_name(name)
        return inv.get("extensionDescription", {}).get("supportedRequests", [])

    def filter(
        self,
        name_startswith: str = "",
        name_contains: str = "",
        exclude_names: list[str] | None = None,
    ) -> list[dict]:
        """Filter invokers by name patterns.

        Args:
            name_startswith: Filter invokers whose name starts with this string.
            name_contains: Filter invokers whose name contains this string.
            exclude_names: List of name patterns to exclude (supports * wildcard).
        """
        import fnmatch
        exclude = exclude_names or []
        results = []
        for inv in self.list_all():
            name = inv.get("name", "")
            if name_startswith and not name.startswith(name_startswith):
                continue
            if name_contains and name_contains not in name:
                continue
            if any(fnmatch.fnmatch(name, pat) for pat in exclude):
                continue
            results.append(inv)
        return results

    def delete(self, invoker_id: str, force: bool = False) -> None:
        """Delete an invoker by ID.

        Args:
            invoker_id: The invoker ID.
            force: If False, refuses to delete invokers with DO_NOT_DELETE in name.
        """
        if not force:
            for inv in self.list_all():
                if inv.get("id") == invoker_id and "DO_NOT_DELETE" in inv.get("name", ""):
                    logger.warning("Skipping delete of protected invoker: %s", inv["name"])
                    return

        url = "/api/rpc/v1/studio/invokerRemove"
        body = {"context": {}, "payload": {"defnWsId": self._workspace.defn_ws_id, "invokerId": invoker_id}}
        response = self._client.post(url, token=self._token, data=json.dumps(body))
        parse_response(response)
        self._invokers_cache = None  # Invalidate cache
        logger.info("Deleted invoker: %s", invoker_id)

    def delete_by_filter(
        self,
        name_startswith: str = "",
        name_contains: str = "",
        exclude_names: list[str] | None = None,
        dry_run: bool = False,
    ) -> list[dict]:
        """Delete invokers matching filter criteria.

        Args:
            dry_run: If True, return what would be deleted without deleting.

        Returns:
            List of invokers that were (or would be) deleted.
        """
        targets = self.filter(name_startswith=name_startswith, name_contains=name_contains, exclude_names=exclude_names)
        if dry_run:
            logger.info("DRY RUN — would delete %d invokers", len(targets))
            return targets

        for inv in targets:
            try:
                self.delete(inv["id"], force=True)
            except Exception as e:
                logger.warning("Failed to delete invoker %s: %s", inv.get("name"), e)

        return targets

    def upgrade(self, invoker_name: str) -> None:
        """Trigger extension upgrade for an invoker.

        POST /api/rpc/v1/studio/invokerUpgrade
        """
        invoker_id = self.get_id(invoker_name)
        url = "/api/rpc/v1/studio/invokerUpgrade"
        body = {
            "context": {},
            "payload": {
                "workspaceId": self._config.workspace_id,
                "invokerId": invoker_id,
            },
        }
        self._client.post(url, token=self._token, data=json.dumps(body))
        logger.info("Upgrade triggered: %s", invoker_name)

    def upgrade_all(self, invoker_names: list[str]) -> None:
        """Upgrade multiple invokers."""
        for name in invoker_names:
            self.upgrade(name)

    def update_setup(self, invoker_id: str, setup_payload: dict) -> dict:
        """Update invoker configuration.

        POST /api/rpc/v1/studio/invokerUpdateSetup
        """
        url = "/api/rpc/v1/studio/invokerUpdateSetup"
        body = {"context": {}, "payload": setup_payload}
        body["payload"]["invokerId"] = invoker_id
        response = self._client.post(url, token=self._token, data=json.dumps(body))
        data = parse_response(response)
        logger.info("Invoker setup updated: %s", invoker_id)
        return data["payload"]
