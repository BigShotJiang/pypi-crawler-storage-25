"""Shared utility functions for krista-lib."""

from __future__ import annotations

import base64
import uuid


def base64encode(value: str) -> str:
    """Encode a string to base64 (used for password encoding)."""
    return base64.b64encode(value.encode("ascii")).decode("ascii")


def generate_uuid() -> str:
    """Generate a random UUID v4 string."""
    return str(uuid.uuid4())


def find_in_list(items: list[dict], key: str, value) -> list[dict]:
    """Find all dicts in a list where dict[key] == value.

    Args:
        items: List of dictionaries to search.
        key: The key to match on.
        value: The value to match.

    Returns:
        List of matching dictionaries.
    """
    return [item for item in items if item.get(key) == value]


def find_one_in_list(items: list[dict], key: str, value) -> dict | None:
    """Find the first dict in a list where dict[key] == value.

    Returns:
        The matching dict, or None if not found.
    """
    for item in items:
        if item.get(key) == value:
            return item
    return None
