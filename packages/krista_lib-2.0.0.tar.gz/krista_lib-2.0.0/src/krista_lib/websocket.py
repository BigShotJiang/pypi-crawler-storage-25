"""WebSocket client for Krista real-time communication."""

from __future__ import annotations

import json
import logging
import threading
import time
from typing import Callable

from .exceptions import KristaWebSocketError

logger = logging.getLogger("krista_lib.websocket")


class KristaWebSocket:
    """WebSocket client with heartbeat, message routing, and auto-reconnect.

    Usage:
        ws = KristaWebSocket(url="wss://studio.qa-in.eng.krista.app/node1/ws", token=token)

        @ws.on_message
        def handle(msg_type, payload):
            print(f"Got: {msg_type}")

        ws.connect(heartbeat_interval=5)
        # ... work ...
        ws.close()
    """

    KNOWN_SIGNALS = {
        "ConnectionEstablished", "NewMessages", "Notification",
        "ping", "pong", "MessageUpdate", "ExecutionComplete",
    }

    def __init__(self, url: str, token=None, session_id: str = ""):
        """
        Args:
            url: WebSocket URL (wss://...).
            token: KristaToken for auth headers.
            session_id: Legacy session ID (if not using token).
        """
        self.url = url
        self._token = token
        self._session_id = session_id
        self._ws = None
        self._heartbeat_thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._connected = False

        # Callbacks
        self._on_message_cb: Callable | None = None
        self._on_connected_cb: Callable | None = None
        self._on_error_cb: Callable | None = None
        self._on_close_cb: Callable | None = None

    def on_message(self, fn: Callable) -> Callable:
        """Decorator to register a message handler.

        The handler receives (msg_type: str, payload: dict).
        """
        self._on_message_cb = fn
        return fn

    def on_connected(self, fn: Callable) -> Callable:
        """Decorator to register a connection handler."""
        self._on_connected_cb = fn
        return fn

    def on_error(self, fn: Callable) -> Callable:
        """Decorator to register an error handler."""
        self._on_error_cb = fn
        return fn

    def on_close(self, fn: Callable) -> Callable:
        """Decorator to register a close handler."""
        self._on_close_cb = fn
        return fn

    def connect(self, heartbeat_interval: int = 5, auto_close_after: int = 0) -> None:
        """Connect to the WebSocket server.

        Args:
            heartbeat_interval: Seconds between ping messages (0 to disable).
            auto_close_after: Auto-disconnect after N seconds (0 to disable).
        """
        try:
            import websocket
        except ImportError:
            raise ImportError("websocket-client required. Install with: pip install websocket-client")

        headers = {}
        if self._token:
            headers = self._token.headers()
        elif self._session_id:
            headers = {"Cookie": f"clientSessionId={self._session_id}"}

        header_list = [f"{k}: {v}" for k, v in headers.items()]

        self._stop_event.clear()

        def _on_open(ws):
            self._connected = True
            logger.info("WebSocket connected: %s", self.url)
            if self._on_connected_cb:
                self._on_connected_cb()

            # Start heartbeat
            if heartbeat_interval > 0:
                self._heartbeat_thread = threading.Thread(
                    target=self._heartbeat_loop, args=(ws, heartbeat_interval), daemon=True
                )
                self._heartbeat_thread.start()

            # Auto-close timer
            if auto_close_after > 0:
                threading.Timer(auto_close_after, self.close).start()

        def _on_message(ws, message):
            try:
                data = json.loads(message)
                msg_type = data.get("type", data.get("signal", "unknown"))
                if self._on_message_cb:
                    self._on_message_cb(msg_type, data)
                else:
                    logger.debug("WS message: %s", msg_type)
            except json.JSONDecodeError:
                logger.debug("WS raw message: %s", message[:200])

        def _on_error(ws, error):
            logger.error("WebSocket error: %s", error)
            if self._on_error_cb:
                self._on_error_cb(error)

        def _on_close(ws, close_status_code, close_msg):
            self._connected = False
            logger.info("WebSocket closed: %s %s", close_status_code, close_msg)
            if self._on_close_cb:
                self._on_close_cb()

        self._ws = websocket.WebSocketApp(
            self.url,
            header=header_list,
            on_open=_on_open,
            on_message=_on_message,
            on_error=_on_error,
            on_close=_on_close,
        )

        # Run in a background thread so it doesn't block
        thread = threading.Thread(
            target=self._ws.run_forever,
            kwargs={"sslopt": {"cert_reqs": 0}},
            daemon=True,
        )
        thread.start()

    def send(self, data: dict) -> None:
        """Send a JSON message."""
        if not self._ws or not self._connected:
            raise KristaWebSocketError("WebSocket not connected")
        self._ws.send(json.dumps(data))

    def close(self) -> None:
        """Gracefully close the WebSocket connection."""
        self._stop_event.set()
        if self._ws:
            try:
                self._ws.close()
            except Exception:
                pass
        self._connected = False

    @property
    def is_connected(self) -> bool:
        return self._connected

    def _heartbeat_loop(self, ws, interval: int) -> None:
        """Send periodic ping messages."""
        while not self._stop_event.is_set():
            try:
                if self._connected:
                    ws.send(json.dumps({"type": "ping"}))
            except Exception:
                break
            self._stop_event.wait(interval)
