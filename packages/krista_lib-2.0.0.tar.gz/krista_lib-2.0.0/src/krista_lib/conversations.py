"""Conversation execution, messaging, and management operations."""

from __future__ import annotations

import json
import logging
import time
from typing import TYPE_CHECKING

from .client import parse_response
from .exceptions import KristaNotFoundError, KristaTimeoutError

if TYPE_CHECKING:
    from .auth import KristaToken
    from .client import KristaClient
    from .config import KristaConfig
    from .workspace import WorkspaceManager

logger = logging.getLogger("krista_lib.conversations")


class ConversationExecution:
    """Represents an active conversation execution.

    Provides methods to submit steps, wait for messages, and extract field values.
    """

    def __init__(
        self,
        execution_id: str,
        conversation_id: str,
        messages_url: str,
        client: KristaClient,
        client_token: KristaToken,
        config,
    ):
        self.execution_id = execution_id
        self.conversation_id = conversation_id
        self.messages_url = messages_url
        self._client = client
        self._client_token = client_token
        self._config = config

    def wait_for_message(self, text: str | None = None, is_substring: bool = False, timeout: int = 10) -> str:
        """Wait for a specific message and return its message ID.

        Args:
            text: Message text to search for. None to get latest message.
            is_substring: If True, match exact string; if False, check containment.
            timeout: Maximum seconds to wait.

        Returns:
            Message ID.

        Raises:
            KristaTimeoutError: If message not found within timeout.
        """
        for _ in range(timeout):
            response = self._client.get(self.messages_url, token=self._client_token)
            if response.status_code != 200:
                time.sleep(1)
                continue

            messages = json.loads(response.text.replace("'", '"'))

            if text is None and len(messages) >= 2:
                return messages[-1]["messageId"]

            for msg in messages[-2:]:
                user_msg = msg.get("userMessage", "")
                if not is_substring and text and text in user_msg:
                    return msg["messageId"]
                elif is_substring and text == user_msg:
                    return msg["messageId"]

            time.sleep(1)

        raise KristaTimeoutError(f"Message not found within {timeout}s: {text}")

    def submit(self, fields: dict | None = None, message: str | None = None,
               is_substring: bool = False, timeout: int = 10) -> None:
        """Submit a step with field values.

        Args:
            fields: Dictionary of field values to submit.
            message: Wait for this message before submitting. None for latest.
            is_substring: Whether to match message exactly.
            timeout: Seconds to wait for the target message.
        """
        msg_id = self.wait_for_message(message, is_substring, timeout)
        url = self.messages_url + msg_id
        payload = {"values": fields or {}, "submitType": "SUBMIT"}
        headers = {"Content-Type": "application/json; charset=UTF-8"}
        response = self._client.put(url, token=self._client_token, data=json.dumps(payload), headers=headers)
        if response.status_code not in (200, 202):
            logger.error("Submit failed: %d — %s", response.status_code, response.text)

    def submit_path(self, path_name: str, message: str | None = None, timeout: int = 10) -> None:
        """Submit a path choice in a conversation.

        Args:
            path_name: The path name to select.
            message: Wait for this message before submitting.
            timeout: Seconds to wait.
        """
        msg_id = self.wait_for_message(message, timeout=timeout)
        url = self.messages_url + msg_id
        payload = {"submitValue": path_name, "submitType": "path"}
        headers = {"Content-Type": "application/json; charset=UTF-8"}
        response = self._client.put(url, token=self._client_token, data=json.dumps(payload), headers=headers)
        if response.status_code not in (200, 202):
            logger.error("Submit path failed: %d — %s", response.status_code, response.text)

    def get_all_messages(self, expected_count: int = 1, timeout: int = 30, page_size: int = 20) -> dict:
        """Retrieve all messages with polling.

        Uses GET /api/rpc/v1/client/workspaces/{ws_id}/executions/{exec_id}

        Args:
            expected_count: Expected number of messages.
            timeout: Maximum seconds to wait.
            page_size: Number of messages per page.

        Returns:
            Full response dict with payload.messages.main[].
        """
        ws_id = self._config.workspace_id
        base_url = f"/api/rpc/v1/client/workspaces/{ws_id}/executions/{self.execution_id}"
        all_messages: dict = {"payload": {"messages": {"main": []}}}
        url = f"{base_url}?&pageSize={page_size}"

        for _ in range(timeout):
            response = self._client.get(url, token=self._client_token)
            if response.status_code != 200:
                time.sleep(2)
                continue

            data = response.json()
            msgs = data.get("payload", {}).get("messages", {}).get("main", [])
            all_messages["payload"]["messages"]["main"].extend(msgs)

            current_count = len(all_messages["payload"]["messages"]["main"])
            logger.debug("Messages collected: %d / %d", current_count, expected_count)

            if current_count >= expected_count:
                return all_messages

            # Pagination: use last messageId as offset
            if msgs and expected_count > page_size:
                last_id = msgs[-1]["messageId"]
                url = f"{base_url}?&pageSize={page_size}&offset={last_id}"

            time.sleep(2)

        return all_messages

    def get_field_value(self, message_index: int, field_label: str, messages: dict | None = None) -> str | None:
        """Extract a field value from a specific message.

        Args:
            message_index: Index in the messages.main[] array.
            field_label: The label of the field to extract.
            messages: Pre-fetched messages dict. If None, fetches fresh.

        Returns:
            The field value, or None if not found.
        """
        try:
            if messages is None:
                messages = self.get_all_messages(expected_count=message_index + 1)

            msg = messages["payload"]["messages"]["main"][message_index]
            page_fields = msg["attributes"]["form"]["pages"][0]["pageFields"]
            field_values = msg["attributes"]["formResponse"]["fieldValues"]

            for field in page_fields:
                if field["label"] == field_label:
                    local_id = field["localId"]
                    return field_values.get(local_id)
        except (KeyError, IndexError, TypeError) as e:
            logger.debug("Field value extraction failed for '%s': %s", field_label, e)

        return None


class ConversationManager:
    """Manage conversation executions and definitions."""

    def __init__(
        self,
        config: KristaConfig,
        client: KristaClient,
        studio_token: KristaToken,
        client_token: KristaToken | None,
        workspace: WorkspaceManager,
    ):
        self._config = config
        self._client = client
        self._studio_token = studio_token
        self._client_token = client_token or studio_token
        self._workspace = workspace

    def start(
        self,
        conversation_name: str,
        routing_id: str | None = None,
        retries: int = 5,
    ) -> ConversationExecution:
        """Start a conversation execution.

        Args:
            conversation_name: Name of the conversation to execute.
            routing_id: Routing ID of the Client API extension. If None, looks up from config.
            retries: Number of retry attempts.

        Returns:
            ConversationExecution object for interacting with the running conversation.
        """
        conv_id = self._workspace.get_conversation_id(conversation_name)

        if not routing_id:
            from .invokers import InvokerManager
            inv_mgr = InvokerManager(self._config, self._client, self._studio_token, self._workspace)
            ext_name = self._config.client_api_ext_name or "Client API"
            routing_id = inv_mgr.get_routing_id(ext_name)

        base_url = f"/extension/api/{routing_id}/rest/conversations/{conv_id}/executions/"

        # Get execution ID with retries
        execution_id = None
        headers = self._client_token.headers()
        for attempt in range(retries):
            response = self._client.post(base_url, token=self._client_token)
            if response.status_code == 200:
                execution_id = json.loads(response.text.replace("'", '"')).get("executionId")
                if execution_id:
                    break
            logger.debug("Execution start attempt %d/%d failed: %s", attempt + 1, retries, response.text)
            time.sleep(5)

        if not execution_id:
            raise KristaTimeoutError(f"Failed to start conversation '{conversation_name}' after {retries} attempts")

        messages_url = f"{base_url}{execution_id}/messages/"

        # Wait for messages endpoint to be ready
        for _ in range(5):
            response = self._client.get(messages_url, token=self._client_token)
            if response.status_code == 200:
                break
            time.sleep(1)

        logger.info("Conversation started: %s (execution: %s)", conversation_name, execution_id)
        return ConversationExecution(
            execution_id=execution_id,
            conversation_id=conv_id,
            messages_url=messages_url,
            client=self._client,
            client_token=self._client_token,
            config=self._config,
        )

    # ── Studio RPC APIs (Conversation Design) ──────────────────────────

    def upsert(self, definition_payload: dict) -> dict:
        """Create or update a conversation definition.

        POST /api/rpc/v1/studio/conversationUpsert
        """
        url = "/api/rpc/v1/studio/conversationUpsert"
        body = {"context": {}, "payload": definition_payload}
        response = self._client.post(url, token=self._studio_token, data=json.dumps(body))
        return parse_response(response)["payload"]

    def publish(self, conversation_id: str, test_mode: bool = False) -> dict:
        """Publish a conversation.

        POST /api/rpc/v1/studio/conversationPublish
        """
        url = "/api/rpc/v1/studio/conversationPublish"
        body = {
            "context": {"clientSessionId": self._studio_token.access_token},
            "payload": {
                "defnWsId": self._workspace.defn_ws_id,
                "conversationDefinitionId": conversation_id,
                "testMode": test_mode,
            },
        }
        response = self._client.post(url, token=self._studio_token, data=json.dumps(body))
        return parse_response(response)["payload"]

    def remove(self, conversation_id: str) -> dict:
        """Remove a conversation definition.

        POST /api/rpc/v1/studio/conversationRemove
        """
        url = "/api/rpc/v1/studio/conversationRemove"
        body = {
            "context": {},
            "payload": {
                "defnWsId": self._workspace.defn_ws_id,
                "conversationDefinitionId": conversation_id,
            },
        }
        response = self._client.post(url, token=self._studio_token, data=json.dumps(body))
        return parse_response(response)["payload"]

    def delete(self, conversation_id: str) -> None:
        """Delete a conversation.

        DELETE /api/rpc/v1/studio/workspace/{ws_id}/conversation/{conv_id}
        """
        url = f"/api/rpc/v1/studio/workspace/{self._config.workspace_id}/conversation/{conversation_id}"
        response = self._client.delete(url, token=self._studio_token)
        parse_response(response)

    def get_schedules(self, page: int = 0, size: int = 150) -> list[dict]:
        """Get scheduled conversations.

        GET /api/rpc/v1/studio/workspace/{ws_id}/schedules?page={page}&size={size}
        """
        url = f"/api/rpc/v1/studio/workspace/{self._config.workspace_id}/schedules?page={page}&size={size}"
        response = self._client.get(url, token=self._studio_token)
        data = parse_response(response)
        return data["payload"]

    def delete_schedule(self, job_id: str) -> None:
        """Delete a scheduled conversation job.

        DELETE /api/rpc/v1/studio/workspace/{ws_id}/schedules/job/{job_id}
        """
        url = f"/api/rpc/v1/studio/workspace/{self._config.workspace_id}/schedules/job/{job_id}"
        response = self._client.delete(url, token=self._studio_token)
        parse_response(response)

    def save_action_stack(self, payload: dict) -> dict:
        """Save action stack (conversation steps).

        POST /api/rpc/v1/studio/actionStackSave
        """
        url = "/api/rpc/v1/studio/actionStackSave"
        body = {"context": {}, "payload": payload}
        response = self._client.post(url, token=self._studio_token, data=json.dumps(body))
        return parse_response(response)["payload"]

    def terminate(self, conversation_exec_id: str) -> None:
        """Terminate a running conversation execution.

        DELETE /api/rpc/v1/studio/workspace/{ws_id}/conversation/{conv_exec_id}
        """
        url = f"/api/rpc/v1/studio/workspace/{self._config.workspace_id}/conversation/{conversation_exec_id}"
        response = self._client.delete(url, token=self._studio_token)
        parse_response(response)

    def get_executed_conversations_of_topic(self, topic_id: str, before: int = 10, after: int = 10) -> dict:
        """Get executed conversations for a topic.

        GET /api/rpc/v1/client/workspaces/{ws_id}/executions?channelId={topic_id}&before=X&after=Y
        Uses client token.
        """
        url = (f"/api/rpc/v1/client/workspaces/{self._config.workspace_id}/executions"
               f"?channelId={topic_id}&before={before}&after={after}")
        # This endpoint uses client_url, not studio_url
        client_base = self._config.client_node_url
        full_url = client_base + url
        response = self._client.get(full_url, token=self._client_token)
        data = parse_response(response)
        return data["payload"]

    def get_conversation_definition_by_topic(self, topic_id: str, conversation_id: str) -> dict:
        """Get conversation definition via client API with topic context.

        GET /api/rpc/v1/client/workspace/{ws_id}/channel/{topic_id}/conversationDefinition/{conv_id}
        Uses client token.
        """
        url = (f"/api/rpc/v1/client/workspace/{self._config.workspace_id}"
               f"/channel/{topic_id}/conversationDefinition/{conversation_id}")
        client_base = self._config.client_node_url
        full_url = client_base + url
        response = self._client.get(full_url, token=self._client_token)
        data = parse_response(response)
        return data["payload"]

    def get_conversation_executions(self, conversation_exec_id: str) -> dict:
        """Get conversation execution details.

        GET /api/rpc/v1/client/workspaces/{ws_id}/conversation/{conv_exec_id}
        Uses client token.
        """
        url = f"/api/rpc/v1/client/workspaces/{self._config.workspace_id}/conversation/{conversation_exec_id}"
        client_base = self._config.client_node_url
        full_url = client_base + url
        response = self._client.get(full_url, token=self._client_token)
        data = parse_response(response)
        return data["payload"]
