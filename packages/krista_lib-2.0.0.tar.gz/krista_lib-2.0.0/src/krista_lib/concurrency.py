"""Batch processing, thread pools, and rate limiting."""

from __future__ import annotations

import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any, Callable

logger = logging.getLogger("krista_lib.concurrency")


@dataclass
class BatchError:
    """Record of a single failed item in a batch operation."""
    item: Any
    exception: Exception


@dataclass
class BatchResult:
    """Result of a batch operation."""
    success_count: int = 0
    failure_count: int = 0
    errors: list[BatchError] = field(default_factory=list)
    results: list[Any] = field(default_factory=list)


class BatchProcessor:
    """Execute operations on collections with thread pools and rate limiting.

    Usage:
        processor = BatchProcessor(max_workers=10)
        results = processor.run(
            items=invokers,
            fn=lambda inv: krista.invokers.delete(inv["id"]),
            batch_size=50,
            delay_between_batches=5,
        )
    """

    def __init__(self, max_workers: int = 10):
        self.max_workers = max_workers

    def run(
        self,
        items: list,
        fn: Callable,
        batch_size: int = 0,
        delay_between_batches: float = 0,
        on_error: str = "continue",
        progress: bool = False,
    ) -> BatchResult:
        """Execute fn for each item using a thread pool.

        Args:
            items: List of items to process.
            fn: Function to call for each item. Receives the item as argument.
            batch_size: If > 0, process in batches with delay between them. 0 = all at once.
            delay_between_batches: Seconds to wait between batches.
            on_error: "continue" to keep going, "stop" to halt on first error, "raise" to re-raise.
            progress: If True, print progress to stdout.

        Returns:
            BatchResult with success/failure counts and error details.
        """
        result = BatchResult()

        if not items:
            return result

        if batch_size <= 0:
            batch_size = len(items)

        total = len(items)
        processed = 0

        for batch_start in range(0, total, batch_size):
            batch = items[batch_start:batch_start + batch_size]

            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                future_to_item = {executor.submit(fn, item): item for item in batch}

                for future in as_completed(future_to_item):
                    item = future_to_item[future]
                    processed += 1

                    try:
                        res = future.result()
                        result.success_count += 1
                        result.results.append(res)
                    except Exception as e:
                        result.failure_count += 1
                        result.errors.append(BatchError(item=item, exception=e))
                        logger.warning("Batch item failed: %s", e)

                        if on_error == "stop":
                            return result
                        elif on_error == "raise":
                            raise

                    if progress:
                        print(f"\r  Progress: {processed}/{total} "
                              f"(OK: {result.success_count}, FAIL: {result.failure_count})", end="", flush=True)

            # Delay between batches
            remaining = total - (batch_start + len(batch))
            if remaining > 0 and delay_between_batches > 0:
                logger.debug("Batch complete. Waiting %.1fs before next batch...", delay_between_batches)
                time.sleep(delay_between_batches)

        if progress:
            print()  # Newline after progress

        return result


class RateLimiter:
    """Simple rate limiter for throttling API calls.

    Usage:
        limiter = RateLimiter(max_per_second=10)
        for item in items:
            limiter.wait()
            process(item)
    """

    def __init__(self, max_per_second: float = 10):
        self._interval = 1.0 / max_per_second
        self._last_call = 0.0

    def wait(self) -> None:
        """Wait until the next call is allowed."""
        now = time.time()
        elapsed = now - self._last_call
        if elapsed < self._interval:
            time.sleep(self._interval - elapsed)
        self._last_call = time.time()
