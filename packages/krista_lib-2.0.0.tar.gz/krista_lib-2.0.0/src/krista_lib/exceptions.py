"""Custom exception hierarchy for krista-lib."""

from __future__ import annotations


class KristaError(Exception):
    """Base exception for all krista-lib errors."""


class KristaConfigError(KristaError):
    """Invalid or missing configuration."""


class KristaAuthError(KristaError):
    """Authentication failure (bad credentials, expired token, etc.)."""


class KristaTokenExpiredError(KristaAuthError):
    """JWT token has expired. Re-login required."""


class KristaAPIError(KristaError):
    """API returned an error response."""

    def __init__(self, message: str, status_code: int = 0, url: str = "", method: str = "", response_body: str = ""):
        self.status_code = status_code
        self.url = url
        self.method = method
        self.response_body = response_body
        super().__init__(message)


class KristaValidationError(KristaAPIError):
    """API returned isError=True with validationErrors."""

    def __init__(self, message: str, validation_errors: list | None = None, **kwargs):
        self.validation_errors = validation_errors or []
        super().__init__(message, **kwargs)


class KristaNotFoundError(KristaAPIError):
    """Requested resource not found (ecosystem, domain, extension, invoker, etc.)."""

    def __init__(self, resource_type: str, resource_name: str, **kwargs):
        self.resource_type = resource_type
        self.resource_name = resource_name
        msg = f"{resource_type} '{resource_name}' not found"
        super().__init__(msg, **kwargs)


class KristaTimeoutError(KristaError):
    """Operation timed out (polling for messages, waiting for execution, etc.)."""


class KristaWebSocketError(KristaError):
    """WebSocket connection or communication failure."""


class KristaFileError(KristaError):
    """File not found, upload failure, or media server error."""
