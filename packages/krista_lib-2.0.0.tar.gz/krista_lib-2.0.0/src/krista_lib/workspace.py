"""Workspace, catalog, ecosystem, domain, conversation meta, topic, and role operations."""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

from .client import parse_response
from .exceptions import KristaNotFoundError

if TYPE_CHECKING:
    from .auth import KristaToken
    from .client import KristaClient
    from .config import KristaConfig

logger = logging.getLogger("krista_lib.workspace")


class WorkspaceManager:
    """Manages workspace-level operations: info, catalogs, ecosystems, conversations, topics, roles.

    Results are cached after first fetch. Call clear_cache() to refresh.
    """

    def __init__(self, config: KristaConfig, client: KristaClient, token: KristaToken):
        self._config = config
        self._client = client
        self._token = token
        self._cache: dict[str, Any] = {}

    def clear_cache(self) -> None:
        """Clear all cached data."""
        self._cache.clear()

    # ── Workspace Info ──────────────────────────────────────────────────

    def get_info(self) -> dict:
        """Get workspace info + user account details.

        GET /appliance/workspace/{ws_id}/info
        Replaces deprecated wsGet.
        """
        if "ws_info" not in self._cache:
            url = f"/appliance/workspace/{self._config.workspace_id}/info"
            response = self._client.get(url, token=self._token)
            data = parse_response(response)
            self._cache["ws_info"] = data["payload"]
        return self._cache["ws_info"]

    def get_all_workspaces(self) -> list[dict]:
        """Get all workspace details.

        GET /sdp/v1/workspaces?app=studio
        """
        url = "/sdp/v1/workspaces?app=studio"
        response = self._client.get(url, token=self._token)
        data = parse_response(response)
        return data.get("payload", {}).get("wsList", [])

    @property
    def defn_ws_id(self) -> str:
        """Get the definition workspace ID (defnWs_xxx).

        Resolved from workspace info or workspace list.
        """
        if "defn_ws_id" not in self._cache:
            # Try from workspace info first
            info = self.get_info()
            defn_id = info.get("ws", {}).get("defnWsId")
            if not defn_id:
                # Fallback: derive from workspace_id
                ws_uuid = self._config.workspace_id.split("_", 1)[1] if "_" in self._config.workspace_id else ""
                defn_id = f"defnWs_{ws_uuid}"
            self._cache["defn_ws_id"] = defn_id
        return self._cache["defn_ws_id"]

    # ── Conversation Meta ───────────────────────────────────────────────

    def get_conversation_meta(self, include_error_state: bool = True) -> list[dict]:
        """Get conversation metadata for the workspace.

        GET /appliance/workspace/{ws_id}/conversations/meta?includeErrorState=true
        This is the primary way to list conversations.
        """
        if "conversation_meta" not in self._cache:
            flag = str(include_error_state).lower()
            url = f"/appliance/workspace/{self._config.workspace_id}/conversations/meta?includeErrorState={flag}"
            response = self._client.get(url, token=self._token)
            data = parse_response(response)
            self._cache["conversation_meta"] = data["payload"]
        return self._cache["conversation_meta"]

    def get_conversation_id(self, conversation_name: str, reload: bool = False) -> str:
        """Find a conversation ID by name from conversation meta.

        Args:
            conversation_name: Title of the conversation.
            reload: Force refresh of conversation meta cache.

        Raises:
            KristaNotFoundError: If conversation not found.
        """
        if reload:
            self._cache.pop("conversation_meta", None)

        for conv in self.get_conversation_meta():
            if conv.get("title") == conversation_name:
                return conv["id"]
        raise KristaNotFoundError("conversation", conversation_name)

    def get_all_conversation_ids(self, reload: bool = False) -> dict[str, str]:
        """Get all conversation IDs as {title: id} dict."""
        if reload:
            self._cache.pop("conversation_meta", None)
        return {conv["title"]: conv["id"] for conv in self.get_conversation_meta()}

    def get_conversation_definition(self, conversation_id: str) -> dict:
        """Get full conversation definition by ID.

        GET /appliance/workspace/{ws_id}/conversations/{conv_id}
        """
        url = f"/appliance/workspace/{self._config.workspace_id}/conversations/{conversation_id}"
        response = self._client.get(url, token=self._token)
        data = parse_response(response)
        return data["payload"]

    def get_conversations_of_agent(self, topic_id: str) -> list[dict]:
        """Get conversations for a specific agent/topic.

        GET /appliance/workspace/{ws_id}/topic/{topic_id}/conversations
        """
        url = f"/appliance/workspace/{self._config.workspace_id}/topic/{topic_id}/conversations"
        response = self._client.get(url, token=self._token)
        data = parse_response(response)
        return data["payload"]

    # ── Topics (Agents) ─────────────────────────────────────────────────

    def get_topic_id(self, topic_name: str) -> str | None:
        """Find a topic/agent ID by name.

        GET /appliance/kb/{ws_id}/articles/info
        Iterates articlesInfo[].topicName to find channelId.
        """
        if "articles_info" not in self._cache:
            url = f"/appliance/kb/{self._config.workspace_id}/articles/info"
            response = self._client.get(url, token=self._token)
            data = parse_response(response)
            self._cache["articles_info"] = data["payload"].get("articlesInfo", [])

        for topic in self._cache["articles_info"]:
            if topic.get("topicName") == topic_name:
                return topic.get("channelId")
        return None

    # ── Roles ───────────────────────────────────────────────────────────

    def get_role_details(self) -> dict:
        """Get all roles for the workspace.

        GET /appliance/{ws_id}/role
        Returns: {defnRoles: [{defnRoleId, role, ...}, ...]}
        """
        if "role_details" not in self._cache:
            url = f"/appliance/{self._config.workspace_id}/role"
            response = self._client.get(url, token=self._token)
            data = parse_response(response)
            self._cache["role_details"] = data["payload"]
        return self._cache["role_details"]

    def get_role_id(self, role_name: str, reload: bool = False) -> str | None:
        """Find a role ID by name.

        Args:
            role_name: Display name of the role (e.g., "Krista Admin").
            reload: Force refresh of role cache.
        """
        if reload:
            self._cache.pop("role_details", None)

        roles = self.get_role_details().get("defnRoles", [])
        for r in roles:
            if r.get("role") == role_name:
                return r.get("defnRoleId")
        return None

    def get_all_role_ids(self) -> list[str]:
        """Get all role IDs."""
        roles = self.get_role_details().get("defnRoles", [])
        return [r["defnRoleId"] for r in roles]

    def get_role_info(self, role_ids: list[str]) -> list[dict]:
        """Get details for specific role IDs.

        POST /appliance/{ws_id}/role/info
        Payload: [role_id_1, role_id_2]
        """
        import json
        url = f"/appliance/{self._config.workspace_id}/role/info"
        response = self._client.post(url, token=self._token, data=json.dumps(role_ids))
        data = parse_response(response)
        return data["payload"]

    # ── Catalogs ────────────────────────────────────────────────────────

    def get_catalogs(self) -> list[dict]:
        """Get all catalogs in the workspace.

        GET /appliance/{ws_id}/catalogs
        """
        if "catalogs" not in self._cache:
            url = f"/appliance/{self._config.workspace_id}/catalogs"
            response = self._client.get(url, token=self._token)
            data = parse_response(response)
            self._cache["catalogs"] = data["payload"]
        return self._cache["catalogs"]

    def get_private_catalog_id(self) -> str | None:
        """Find the private catalog ID."""
        for catalog in self.get_catalogs():
            if catalog.get("type") == "PRIVATE":
                return catalog["id"]
        return None

    def get_global_catalog_id(self) -> str | None:
        """Find the appliance/global catalog ID."""
        for catalog in self.get_catalogs():
            if catalog.get("type") == "APPLIANCE":
                return catalog["id"]
        return None

    def get_catalog_extensions(self, offset: int = 0, limit: int = 200) -> list[dict]:
        """Get catalog extensions with pagination.

        GET /appliance/{ws_id}/catalog/extensions?offset={offset}&limit={limit}&catalogs=...
        """
        params = self._catalog_params()
        url = f"/appliance/{self._config.workspace_id}/catalog/extensions?&offset={offset}&limit={limit}&{params}"
        response = self._client.get(url, token=self._token)
        data = parse_response(response)
        return data["payload"]

    # ── Ecosystems & Domains ────────────────────────────────────────────

    def _catalog_params(self) -> str:
        """Build catalog query params for ecosystem/domain lookups."""
        return "&".join(f"catalogs={c['id']}" for c in self.get_catalogs())

    def list_ecosystems(self) -> list[dict]:
        """List all ecosystems."""
        params = self._catalog_params()
        url = f"/appliance/{self._config.workspace_id}/catalog/ecosystems?{params}"
        response = self._client.get(url, token=self._token)
        data = parse_response(response)
        return data["payload"].get("ecosystems", [])

    def get_ecosystem_id(self, ecosystem_name: str) -> str:
        """Find an ecosystem ID by name.

        Raises:
            KristaNotFoundError: If ecosystem not found.
        """
        for eco in self.list_ecosystems():
            if eco.get("title") == ecosystem_name:
                return eco["id"]
        raise KristaNotFoundError("ecosystem", ecosystem_name)

    def list_domains(self, ecosystem_id: str) -> list[dict]:
        """List all domains in an ecosystem."""
        params = self._catalog_params()
        url = f"/appliance/{self._config.workspace_id}/catalog/ecosystems/{ecosystem_id}/domains?{params}"
        response = self._client.get(url, token=self._token)
        data = parse_response(response)
        return data["payload"].get("domains", [])

    def get_domain_id(self, ecosystem_id: str, domain_name: str) -> str:
        """Find a domain ID by name.

        Raises:
            KristaNotFoundError: If domain not found.
        """
        for domain in self.list_domains(ecosystem_id):
            if domain.get("title") == domain_name:
                return domain["id"]
        raise KristaNotFoundError("domain", domain_name)

    def list_areas(self, ecosystem_id: str, domain_id: str) -> list[dict]:
        """List areas in a domain."""
        params = self._catalog_params()
        url = (f"/appliance/{self._config.workspace_id}/catalog/ecosystems/{ecosystem_id}"
               f"/domains/{domain_id}/areas?{params}")
        response = self._client.get(url, token=self._token)
        data = parse_response(response)
        return data["payload"].get("areas", [])

    def list_extensions(self, ecosystem_id: str, domain_id: str) -> list[dict]:
        """List all extensions in a domain."""
        params = self._catalog_params()
        url = (f"/appliance/{self._config.workspace_id}/catalog/ecosystems/{ecosystem_id}"
               f"/domains/{domain_id}/extensions?{params}")
        response = self._client.get(url, token=self._token)
        data = parse_response(response)
        return data["payload"].get("extensions", [])

    def get_extension(self, ecosystem_name: str, domain_name: str, extension_name: str) -> dict:
        """Find an extension by ecosystem/domain/name.

        Returns:
            Dict with id, title, description, icon.

        Raises:
            KristaNotFoundError: If any part of the hierarchy not found.
        """
        eco_id = self.get_ecosystem_id(ecosystem_name)
        domain_id = self.get_domain_id(eco_id, domain_name)
        for ext in self.list_extensions(eco_id, domain_id):
            if ext.get("title") == extension_name:
                return ext
        raise KristaNotFoundError("extension", extension_name)

    # ── Catalog CRUD ────────────────────────────────────────────────────

    def create_ecosystem(self, title: str, description: str = "") -> dict:
        """Create a new ecosystem in the private catalog.

        POST /appliance/{ws_id}/catalog/ecosystems
        """
        url = f"/appliance/{self._config.workspace_id}/catalog/ecosystems"
        body = json.dumps({"icon": None, "title": title, "description": description})
        response = self._client.post(url, token=self._token, data=body)
        data = parse_response(response)
        self._cache.pop("ecosystems", None)
        return data["payload"]

    def delete_ecosystem(self, ecosystem_id: str, force: bool = True) -> None:
        """Delete an ecosystem.

        DELETE /appliance/{ws_id}/catalog/ecosystems/{eco_id}?force=true
        """
        url = f"/appliance/{self._config.workspace_id}/catalog/ecosystems/{ecosystem_id}?force={str(force).lower()}"
        response = self._client.delete(url, token=self._token)
        if response.status_code not in (200, 204):
            from .exceptions import KristaAPIError
            raise KristaAPIError(f"Delete ecosystem failed: HTTP {response.status_code}", status_code=response.status_code)
        self._cache.pop("ecosystems", None)

    def create_domain(self, ecosystem_id: str, title: str, description: str = "") -> dict:
        """Create a new domain in an ecosystem.

        POST /appliance/{ws_id}/catalog/ecosystems/{eco_id}/domains
        """
        url = f"/appliance/{self._config.workspace_id}/catalog/ecosystems/{ecosystem_id}/domains"
        body = json.dumps({"icon": None, "title": title, "description": description})
        response = self._client.post(url, token=self._token, data=body)
        data = parse_response(response)
        return data["payload"]

    def delete_domain(self, ecosystem_id: str, domain_id: str, force: bool = True) -> None:
        """Delete a domain.

        DELETE /appliance/{ws_id}/catalog/ecosystems/{eco_id}/domains/{dom_id}?force=true
        """
        url = (f"/appliance/{self._config.workspace_id}/catalog/ecosystems/{ecosystem_id}"
               f"/domains/{domain_id}?force={str(force).lower()}")
        response = self._client.delete(url, token=self._token)
        parse_response(response)

    def create_area(self, ecosystem_id: str, domain_id: str, title: str) -> dict:
        """Create a new area in a domain.

        POST /appliance/{ws_id}/catalog/ecosystems/{eco_id}/domains/{dom_id}/areas
        """
        url = (f"/appliance/{self._config.workspace_id}/catalog/ecosystems/{ecosystem_id}"
               f"/domains/{domain_id}/areas")
        body = json.dumps({"title": title})
        response = self._client.post(url, token=self._token, data=body)
        data = parse_response(response)
        return data["payload"]

    def get_domain_details(self, ecosystem_id: str, domain_id: str) -> dict:
        """Get full domain details including entities.

        GET /appliance/{ws_id}/catalog/ecosystems/{eco_id}/domains/{dom_id}?catalogs=...
        """
        params = self._catalog_params()
        url = (f"/appliance/{self._config.workspace_id}/catalog/ecosystems/{ecosystem_id}"
               f"/domains/{domain_id}?{params}")
        response = self._client.get(url, token=self._token)
        data = parse_response(response)
        return data["payload"]

    def get_channels_of_domain(self, ecosystem_id: str, domain_id: str) -> dict:
        """Get channels (topics) of a domain.

        GET /appliance/{ws_id}/catalog/ecosystems/{eco_id}/domains/{dom_id}/channels?catalogs=...
        """
        params = self._catalog_params()
        url = (f"/appliance/{self._config.workspace_id}/catalog/ecosystems/{ecosystem_id}"
               f"/domains/{domain_id}/channels?{params}")
        response = self._client.get(url, token=self._token)
        data = parse_response(response)
        return data["payload"]

    def get_conversations_of_domain_topic(self, ecosystem_id: str, domain_id: str, topic_id: str) -> dict:
        """Get conversations for a topic within a domain.

        GET /appliance/{ws_id}/catalog/ecosystems/{eco_id}/domains/{dom_id}/channels/{topic_id}/conversations?catalogs=...
        """
        params = self._catalog_params()
        url = (f"/appliance/{self._config.workspace_id}/catalog/ecosystems/{ecosystem_id}"
               f"/domains/{domain_id}/channels/{topic_id}/conversations?{params}")
        response = self._client.get(url, token=self._token)
        data = parse_response(response)
        return data["payload"]

    # ── Entity Search ───────────────────────────────────────────────────

    def search_entity_from_catalog(self, entity_name: str, offset: int = 0, limit: int = 25) -> dict:
        """Search for an entity in the catalog.

        GET /api/rpc/v1/{ws_id}/catalog/search?tags=Entities&search_text=...&offset=0&limit=25&catalogs=...
        """
        params = "&".join(f"catalogs={c['id']}" for c in self.get_catalogs())
        url = (f"/api/rpc/v1/{self._config.workspace_id}/catalog/search"
               f"?tags=Entities&search_text={entity_name}&offset={offset}&limit={limit}&{params}")
        response = self._client.get(url, token=self._token)
        data = parse_response(response)
        return data["payload"]

    def get_entity_extensions(self, entity_name: str) -> dict:
        """Get extensions that support a given entity.

        POST /api/rpc/v1/studio/getEntityExtensions
        """
        entity_resp = self.search_entity_from_catalog(entity_name)
        item = entity_resp["searchResult"][0]["item"]
        body = {
            "context": {},
            "payload": {
                "workspaceId": self._config.workspace_id,
                "entityType": {
                    "entityId": item["entity"]["localId"],
                    "entityName": item["entity"]["name"],
                    "registry": {
                        "ecosystemId": item["domainReference"]["ecosystemId"],
                        "domainId": item["domainReference"]["domainId"],
                        "catalogId": item["domainReference"]["catalogId"],
                    },
                },
            },
        }
        response = self._client.post("/api/rpc/v1/studio/getEntityExtensions", token=self._token,
                                     data=json.dumps(body))
        data = parse_response(response)
        return data["payload"]

    # ── Topic/Role/Attribute CRUD (via actionStackSave) ─────────────────

    def create_topic(self, topic_name: str, defn_ws_id: str | None = None) -> dict:
        """Create a topic/agent via actionStackSave.

        POST /api/rpc/v1/studio/actionStackSave
        Matches krista-pytest-automation CommonFunctions.create_topic() exactly.
        """
        from .utils import generate_uuid

        defn_ws = defn_ws_id or self.defn_ws_id
        topic_id = "defnMult_" + generate_uuid()
        roles = self.get_all_role_ids()

        def _hint(hint_id, new_value):
            return {
                "type": "hint", "actionId": "random_" + generate_uuid(),
                "editType": "update", "targetDefnId": topic_id,
                "hintCategory": "property", "hintId": hint_id,
                "currentValue": None, "newValue": new_value,
            }

        action_stack = [
            # Create mapping
            {"type": "mapping", "actionId": "random_" + generate_uuid(),
             "targetDefnId": topic_id, "associationDefnId": defn_ws,
             "editType": "create", "mappingArgs": {}},
            # Set name
            _hint("name", {"type": "string", "value": topic_name}),
            # Set rolePermissions
            _hint("rolePermissions", {"type": "string", "value": str(
                {r: ["channel_view", "channel_author", "channel_deploy"] for r in roles})}),
            # Set testModeRoles
            _hint("testModeRoles", {"type": "stringArray", "value": roles}),
            # Set testModeUsers
            _hint("testModeUsers", {"type": "stringArray", "value": []}),
        ]

        body = json.dumps({"context": {}, "payload": {"defnWsId": defn_ws, "actionStack": action_stack}})
        response = self._client.post("/api/rpc/v1/studio/actionStackSave", token=self._token, data=body)
        data = parse_response(response)
        return data["payload"]

    def delete_topic(self, topic_id: str, defn_ws_id: str | None = None) -> dict:
        """Delete a topic/agent via actionStackSave."""
        from .utils import generate_uuid

        defn_ws = defn_ws_id or self.defn_ws_id
        action_stack = [{
            "actionId": "random_" + generate_uuid(),
            "targetDefnId": topic_id,
            "associationDefnId": defn_ws,
            "editType": "delete",
        }]
        body = json.dumps({"context": {}, "payload": {"defnWsId": defn_ws, "actionStack": action_stack}})
        response = self._client.post("/api/rpc/v1/studio/actionStackSave", token=self._token, data=body)
        data = parse_response(response)
        return data["payload"]

    def create_role(self, role_name: str, defn_ws_id: str | None = None) -> dict:
        """Create a role via actionStackSave."""
        from .utils import generate_uuid

        defn_ws = defn_ws_id or self.defn_ws_id
        role_id = "defnRole_" + generate_uuid()

        action_stack = [
            {"actionId": "random_" + generate_uuid(), "targetDefnId": role_id,
             "associationDefnId": defn_ws, "editType": "create"},
            {"actionId": "random_" + generate_uuid(), "targetDefnId": role_id,
             "editType": "update", "hintId": "role_name", "hintCategory": "phantom",
             "newValue": {"type": "string", "value": role_name}},
            {"actionId": "random_" + generate_uuid(), "targetDefnId": role_id,
             "editType": "update", "hintId": "role_admin", "hintCategory": "phantom",
             "newValue": {"type": "string", "value": "true"}},
            {"actionId": "random_" + generate_uuid(), "targetDefnId": role_id,
             "editType": "update", "hintId": "role_settings", "hintCategory": "phantom",
             "newValue": {"type": "stringArray", "values": ["Allow studio access"]}},
        ]
        body = json.dumps({"context": {}, "payload": {"defnWsId": defn_ws, "actionStack": action_stack}})
        response = self._client.post("/api/rpc/v1/studio/actionStackSave", token=self._token, data=body)
        data = parse_response(response)
        return data["payload"]

    def delete_role(self, role_id: str, defn_ws_id: str | None = None) -> dict:
        """Delete a role via actionStackSave."""
        from .utils import generate_uuid

        defn_ws = defn_ws_id or self.defn_ws_id
        action_stack = [{
            "actionId": "random_" + generate_uuid(),
            "targetDefnId": role_id,
            "associationDefnId": defn_ws,
            "editType": "delete",
        }]
        body = json.dumps({"context": {}, "payload": {"defnWsId": defn_ws, "actionStack": action_stack}})
        response = self._client.post("/api/rpc/v1/studio/actionStackSave", token=self._token, data=body)
        data = parse_response(response)
        return data["payload"]

    def create_personal_attribute(self, attr_name: str, defn_ws_id: str | None = None) -> dict:
        """Create a personal attribute via actionStackSave.

        Matches krista-pytest-automation CommonFunctions.create_personal_attribute() exactly.
        """
        from .utils import generate_uuid

        defn_ws = defn_ws_id or self.defn_ws_id
        attr_id = "defnUserAttr_" + generate_uuid()

        def _hint(hint_id, new_value):
            return {
                "type": "hint", "actionId": "random_" + generate_uuid(),
                "editType": "update", "targetDefnId": attr_id,
                "hintCategory": "property", "hintId": hint_id,
                "currentValue": None, "newValue": new_value,
            }

        action_stack = [
            # Create mapping
            {"type": "mapping", "actionId": "random_" + generate_uuid(),
             "targetDefnId": attr_id, "associationDefnId": defn_ws,
             "editType": "create", "mappingArgs": {}},
            # Set name
            _hint("name", {"type": "string", "value": attr_name}),
            # Set type
            _hint("type", {"type": "string", "value": "Text"}),
            # Set visibility
            _hint("visibility", {"type": "string", "value": "Everyone"}),
        ]
        body = json.dumps({"context": {}, "payload": {"defnWsId": defn_ws, "actionStack": action_stack}})
        response = self._client.post("/api/rpc/v1/studio/actionStackSave", token=self._token, data=body)
        data = parse_response(response)
        return data["payload"]

    def delete_personal_attribute(self, attr_id: str, defn_ws_id: str | None = None) -> dict:
        """Delete a personal attribute via actionStackSave."""
        from .utils import generate_uuid

        defn_ws = defn_ws_id or self.defn_ws_id
        action_stack = [{
            "actionId": "random_" + generate_uuid(),
            "targetDefnId": attr_id,
            "associationDefnId": defn_ws,
            "editType": "delete",
        }]
        body = json.dumps({"context": {}, "payload": {"defnWsId": defn_ws, "actionStack": action_stack}})
        response = self._client.post("/api/rpc/v1/studio/actionStackSave", token=self._token, data=body)
        data = parse_response(response)
        return data["payload"]

    def get_user_attribute_id(self, attr_name: str, reload: bool = False) -> str | None:
        """Find a user attribute ID by name from workspace info."""
        info = self.get_info() if reload else self._cache.get("ws_info", self.get_info())
        attrs = info.get("defnWs", {}).get("userAttributesSet", {}).get("defnUserAttributes", [])
        for a in attrs:
            if a.get("properties", {}).get("name", {}).get("value") == attr_name:
                return a.get("defnUserAttributeId")
        return None
