"""DAZ (catalog archive) export and import operations."""

from __future__ import annotations

import glob
import logging
import os
from typing import TYPE_CHECKING

from .exceptions import KristaFileError

if TYPE_CHECKING:
    from .auth import KristaToken
    from .client import KristaClient
    from .config import KristaConfig
    from .workspace import WorkspaceManager

logger = logging.getLogger("krista_lib.daz")


class DAZManager:
    """Export and import ecosystem/domain catalog archives (DAZ files)."""

    def __init__(
        self,
        config: KristaConfig,
        client: KristaClient,
        studio_token: KristaToken,
        appliance_token: KristaToken | None,
        workspace: WorkspaceManager,
    ):
        self._config = config
        self._client = client
        self._studio_token = studio_token
        self._appliance_token = appliance_token
        self._workspace = workspace

    def export_ecosystem(self, ecosystem_name: str, output_dir: str) -> str:
        """Export an entire ecosystem to a .daz file.

        GET /appliance/{ws_id}/catalog/ecosystems/{eco_id}/contents?catalogs={private_catalog_id}

        Args:
            ecosystem_name: Name of the ecosystem.
            output_dir: Directory to save the .daz file.

        Returns:
            Path to the exported .daz file.
        """
        os.makedirs(output_dir, exist_ok=True)

        eco_id = self._workspace.get_ecosystem_id(ecosystem_name)
        catalog_id = self._workspace.get_private_catalog_id()
        url = f"/appliance/{self._config.workspace_id}/catalog/ecosystems/{eco_id}/contents?catalogs={catalog_id}"

        response = self._client.get(url, token=self._studio_token)
        if response.status_code != 200:
            raise KristaFileError(f"Ecosystem export failed: HTTP {response.status_code} — {response.text}")

        file_path = os.path.join(output_dir, f"{ecosystem_name}.daz")
        with open(file_path, "wb") as f:
            f.write(response.content)

        logger.info("Exported ecosystem: %s → %s", ecosystem_name, file_path)
        return file_path

    def export_domain(self, ecosystem_name: str, domain_name: str, output_dir: str) -> str:
        """Export a specific domain to a .daz file.

        GET /appliance/{ws_id}/catalog/ecosystems/{eco_id}/domains/{dom_id}/contents?catalogs={private_catalog_id}

        Args:
            ecosystem_name: Name of the ecosystem.
            domain_name: Name of the domain.
            output_dir: Directory to save the .daz file.

        Returns:
            Path to the exported .daz file.
        """
        os.makedirs(output_dir, exist_ok=True)

        eco_id = self._workspace.get_ecosystem_id(ecosystem_name)
        domain_id = self._workspace.get_domain_id(eco_id, domain_name)
        catalog_id = self._workspace.get_private_catalog_id()
        url = (f"/appliance/{self._config.workspace_id}/catalog/ecosystems/{eco_id}"
               f"/domains/{domain_id}/contents?catalogs={catalog_id}")

        response = self._client.get(url, token=self._studio_token)
        if response.status_code != 200:
            raise KristaFileError(f"Domain export failed: HTTP {response.status_code} — {response.text}")

        daz_filename = f"{ecosystem_name}_{domain_name}.daz".replace(" ", "_")
        file_path = os.path.join(output_dir, daz_filename)
        with open(file_path, "wb") as f:
            f.write(response.content)

        logger.info("Exported domain: %s/%s → %s", ecosystem_name, domain_name, file_path)
        return file_path

    def import_to_global(self, daz_file_path: str, token: KristaToken | None = None) -> None:
        """Import a .daz file into the global (appliance) catalog.

        POST /appliance/{ws_id}/catalogs/{global_catalog_id}/contents

        Args:
            daz_file_path: Path to the .daz file.
            token: Override token (defaults to appliance token).
        """
        self._import_to_catalog(daz_file_path, "global", token)

    def import_to_private(self, daz_file_path: str, token: KristaToken | None = None) -> None:
        """Import a .daz file into the private catalog.

        POST /appliance/{ws_id}/catalogs/{private_catalog_id}/contents
        """
        self._import_to_catalog(daz_file_path, "private", token)

    def import_all_to_global(self, daz_dir: str, token: KristaToken | None = None) -> list[str]:
        """Import all .daz files in a directory to the global catalog.

        Returns:
            List of imported file paths.
        """
        daz_files = glob.glob(os.path.join(daz_dir, "*.daz"))
        if not daz_files:
            logger.warning("No .daz files found in: %s", daz_dir)
            return []

        imported = []
        for daz_file in daz_files:
            self.import_to_global(daz_file, token=token)
            imported.append(daz_file)
        return imported

    def _import_to_catalog(self, daz_file_path: str, catalog_type: str, token: KristaToken | None = None) -> None:
        """Import a .daz file to a specific catalog type."""
        if not os.path.exists(daz_file_path):
            raise KristaFileError(f"DAZ file not found: {daz_file_path}")

        t = token or self._appliance_token or self._studio_token

        if catalog_type == "global":
            catalog_id = self._workspace.get_global_catalog_id()
        else:
            catalog_id = self._workspace.get_private_catalog_id()

        if not catalog_id:
            raise KristaFileError(f"Could not find {catalog_type} catalog ID")

        url = f"/appliance/{self._config.workspace_id}/catalogs/{catalog_id}/contents"
        headers = t.headers_no_content_type()

        with open(daz_file_path, "rb") as f:
            response = self._client.post(url, token=t, data=f, remove_content_type=True)

        if response.status_code != 200:
            raise KristaFileError(
                f"DAZ import failed for {os.path.basename(daz_file_path)}: "
                f"HTTP {response.status_code} — {response.text}"
            )

        logger.info("Imported DAZ to %s catalog: %s", catalog_type, os.path.basename(daz_file_path))
