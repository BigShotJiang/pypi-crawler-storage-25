"""Structured logging configuration for krista-lib."""

from __future__ import annotations

import logging
import re

# Patterns to redact from log output
_SENSITIVE_PATTERNS = re.compile(
    r"(password|accessToken|refreshToken|sessionId|secret|X-Krista-Access-Token|X-Krista-Refresh-Token)"
    r"\s*[=:]\s*\S+",
    re.IGNORECASE,
)

_REDACTED = "[REDACTED]"


class RedactingFormatter(logging.Formatter):
    """Formatter that redacts sensitive values from log messages."""

    def format(self, record: logging.LogRecord) -> str:
        message = super().format(record)
        return _SENSITIVE_PATTERNS.sub(
            lambda m: m.group().split("=")[0].split(":")[0].strip() + "=" + _REDACTED
            if "=" in m.group()
            else m.group().split(":")[0].strip() + ": " + _REDACTED,
            message,
        )


def setup_logging(
    level: str = "INFO",
    log_file: str | None = None,
    json_format: bool = False,
) -> None:
    """Configure logging for krista-lib.

    All krista-lib modules use the 'krista_lib' logger namespace.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR).
        log_file: Optional file path to write logs to.
        json_format: If True, output logs in JSON format (for CI/CD).
    """
    logger = logging.getLogger("krista_lib")
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    # Remove existing handlers
    logger.handlers.clear()

    if json_format:
        fmt = '{"timestamp":"%(asctime)s","level":"%(levelname)s","logger":"%(name)s","message":"%(message)s"}'
    else:
        fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"

    formatter = RedactingFormatter(fmt, datefmt="%Y-%m-%dT%H:%M:%S")

    # Console handler
    console = logging.StreamHandler()
    console.setFormatter(formatter)
    logger.addHandler(console)

    # File handler (optional)
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
