"""Extension upload, download, and deployment operations."""

from __future__ import annotations

import glob
import json
import logging
import os
import ssl
from typing import TYPE_CHECKING

from .client import parse_response
from .exceptions import KristaFileError, KristaNotFoundError

if TYPE_CHECKING:
    from .auth import KristaToken
    from .client import KristaClient
    from .config import KristaConfig
    from .media import MediaManager
    from .workspace import WorkspaceManager

logger = logging.getLogger("krista_lib.extensions")


class ExtensionManager:
    """Manage extension JAR uploads and upgrades."""

    def __init__(
        self,
        config: KristaConfig,
        client: KristaClient,
        token: KristaToken,
        workspace: WorkspaceManager,
        media: MediaManager,
    ):
        self._config = config
        self._client = client
        self._token = token
        self._workspace = workspace
        self._media = media

    def upload_jar(
        self,
        jar_path: str,
        ecosystem: str,
        domain: str,
        extension_name: str,
        token: KristaToken | None = None,
    ) -> str:
        """Upload a JAR file and update the extension in the catalog.

        Args:
            jar_path: Path to the extension JAR file.
            ecosystem: Ecosystem name (e.g., "Krista").
            domain: Domain name (e.g., "SDK").
            extension_name: Extension title (e.g., "Extension Development").
            token: Override token for the upload.

        Returns:
            Media ID of the uploaded JAR.

        Raises:
            KristaFileError: If JAR file not found.
            KristaNotFoundError: If ecosystem/domain/extension not found.
        """
        if not os.path.exists(jar_path):
            raise KristaFileError(f"JAR file not found: {jar_path}")

        t = token or self._token

        # Navigate catalog hierarchy
        eco_id = self._workspace.get_ecosystem_id(ecosystem)
        domain_id = self._workspace.get_domain_id(eco_id, domain)

        # Find extension
        ext = None
        for e in self._workspace.list_extensions(eco_id, domain_id):
            if e.get("title") == extension_name:
                ext = e
                break
        if not ext:
            raise KristaNotFoundError("extension", extension_name)

        # Upload JAR to media server
        media_id = self._media.upload(jar_path, token=t)

        # Update extension with new binary
        update_payload = {
            "title": ext["title"],
            "description": ext.get("description", ""),
            "extensionBinaryId": media_id,
        }
        if "icon" in ext:
            update_payload["icon"] = ext["icon"]

        url = (f"/appliance/{self._config.workspace_id}/catalog/ecosystems/{eco_id}"
               f"/domains/{domain_id}/extensions/{ext['id']}")
        response = self._client.put(url, token=t, data=json.dumps(update_payload))
        parse_response(response)

        logger.info("Extension uploaded: %s → %s", extension_name, media_id[:40])
        return media_id

    def download_and_upload(
        self,
        cicd_base_url: str,
        extensions: list[dict],
        version: str,
        download_dir: str,
        token: KristaToken | None = None,
    ) -> list[str]:
        """Download JARs from CICD and upload to Krista.

        Args:
            cicd_base_url: Base URL of the CICD artifact repository.
            extensions: List of extension dicts with keys:
                ecosystem, domain, ext_title, name, path
            version: Version string (e.g., "3.5.1").
            download_dir: Directory to download JARs into.
            token: Override token for uploads.

        Returns:
            List of media IDs for uploaded extensions.
        """
        os.makedirs(download_dir, exist_ok=True)

        # Clean old JARs
        for f in glob.glob(os.path.join(download_dir, "*.jar")):
            os.remove(f)

        media_ids = []
        for ext in extensions:
            jar_name = f"{ext['name']}-{version}.jar"
            jar_url = f"{cicd_base_url}{ext['path']}{ext['name']}/{version}/{jar_name}"
            jar_path = os.path.join(download_dir, jar_name)

            # Download
            logger.info("Downloading: %s", jar_url)
            try:
                ssl._create_default_https_context = ssl._create_unverified_context
                import wget
                wget.download(jar_url, out=download_dir)
                print()  # wget doesn't print newline
            except ImportError:
                import urllib.request
                urllib.request.urlretrieve(jar_url, jar_path)

            # Upload
            if os.path.exists(jar_path):
                mid = self.upload_jar(
                    jar_path=jar_path,
                    ecosystem=ext["ecosystem"],
                    domain=ext["domain"],
                    extension_name=ext["ext_title"],
                    token=token,
                )
                media_ids.append(mid)
            else:
                logger.error("Download failed — file not found: %s", jar_path)

        return media_ids

    def upgrade(self, invoker_name: str, token: KristaToken | None = None) -> None:
        """Trigger extension upgrade for an invoker.

        POST /api/rpc/v1/studio/invokerUpgrade
        """
        from .invokers import InvokerManager
        # Delegate to invoker manager — this is a convenience shortcut
        t = token or self._token
        invoker_mgr = InvokerManager(self._config, self._client, t, self._workspace)
        invoker_mgr.upgrade(invoker_name)

    def add_to_workspace(self, ext_name: str, new_name: str | None = None) -> dict:
        """Add a catalog extension to the workspace as an invoker.

        POST /api/rpc/v1/studio/addExtensionToWorkspace

        Args:
            ext_name: Extension title in the catalog.
            new_name: Optional invoker name (defaults to ext_name).

        Returns:
            Response payload dict.
        """
        # Find extension in catalog
        catalog_exts = self._workspace.get_catalog_extensions()
        ext_details = None
        if isinstance(catalog_exts, list):
            for ext in catalog_exts:
                if ext.get("title") == ext_name:
                    ext_details = ext
                    break
        elif isinstance(catalog_exts, dict):
            for ext in catalog_exts.get("extensions", []):
                if ext.get("title") == ext_name:
                    ext_details = ext
                    break

        if not ext_details:
            raise KristaNotFoundError("catalog extension", ext_name)

        invoker_name = new_name or ext_name
        payload = {
            "context": {},
            "payload": {
                "workspaceId": self._config.workspace_id,
                "catalogId": ext_details["domainReference"]["catalogId"],
                "extensionDescriptionId": ext_details["id"],
                "invokerName": invoker_name,
            },
        }
        response = self._client.post("/api/rpc/v1/studio/addExtensionToWorkspace",
                                     token=self._token, data=json.dumps(payload))
        from .client import parse_response
        data = parse_response(response)
        logger.info("Extension added to workspace: %s as '%s'", ext_name, invoker_name)
        return data["payload"]
