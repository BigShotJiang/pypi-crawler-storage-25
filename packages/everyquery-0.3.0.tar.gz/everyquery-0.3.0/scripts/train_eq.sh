#!/bin/bash
#SBATCH --job-name=eq_train
#SBATCH --output=logs/%x_%j.out
#SBATCH --mail-user=gbk2114@cumc.columbia.edu
#SBATCH --mail-type=END,FAIL

#SBATCH --nodes=1               # Explicitly define 1 node
#SBATCH --ntasks-per-node=1     # Must match Lightning devices count for DDP
#SBATCH --gres=gpu:1            # Total GPUs per node
#SBATCH --partition=gpu
#SBATCH --cpus-per-task=2
#SBATCH --mem=256G
#SBATCH --time=300:00:00

echo "Allocated GPUs:"
echo "CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES"
echo "SLURM_JOB_GPUS=$SLURM_JOB_GPUS"

export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
export MKL_NUM_THREADS=$SLURM_CPUS_PER_TASK
export OPENBLAS_NUM_THREADS=$SLURM_CPUS_PER_TASK
export NUMEXPR_NUM_THREADS=$SLURM_CPUS_PER_TASK



set -euo pipefail
export PYTHONNOUSERSITE=1

mkdir -p logs
echo "Starting job on $(hostname) at $(date)"
echo "SLURM CPU PER TASK: $SLURM_CPUS_PER_TASK"
# Move to the repo root (directory from which sbatch was invoked).
cd "${SLURM_SUBMIT_DIR:-$PWD}"

# Load .env variables (portable: all machine-specific paths live here).
set -a
# shellcheck source=/dev/null
. ./.env
set +a

uv sync --locked

echo "Using python: $(uv run which python)"
uv run python -c "import sys; print('Executable:', sys.executable)"

export HYDRA_FULL_ERROR=1

srun uv run python -m every_query.train.train "$@"

echo "Finished at $(date)"
