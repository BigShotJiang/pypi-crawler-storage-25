"""Cryptocurrency exchange providers."""
