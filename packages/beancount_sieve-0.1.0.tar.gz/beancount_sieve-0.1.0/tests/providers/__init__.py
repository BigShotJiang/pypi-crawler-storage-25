"""Tests for statement providers."""
