"""Tests for BlockContext."""

import os
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import httpx
import pytest

from athena import BlockContext, RegisteredArtifact
from athena.output_handle import OutputHandle
from athena.types import ArtifactRef


class TestBlockContext:
    """Tests for BlockContext."""

    def test_create_context(self) -> None:
        """Test creating a BlockContext."""
        run_id = uuid4()
        lab_id = uuid4()

        ctx = BlockContext(
            run_id=run_id,
            step_id="train_vae",
            lab_id=lab_id,
            config={"epochs": 100},
        )

        assert ctx.run_id == run_id
        assert ctx.step_id == "train_vae"
        assert ctx.lab_id == lab_id
        assert ctx.config == {"epochs": 100}

    def test_context_defaults(self) -> None:
        """Test BlockContext default values."""
        ctx = BlockContext()

        assert ctx.run_id is None
        assert ctx.step_id is None
        assert ctx.lab_id is None
        assert ctx.inputs == {}
        assert ctx.config == {}
        assert ctx._block_api_url == "http://127.0.0.1:8002"

    def test_context_requires_block_api(self) -> None:
        """Test that BlockContext requires ATHENA_BLOCK_API env var."""
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(RuntimeError) as exc_info:
                BlockContext()

            assert "ATHENA_BLOCK_API" in str(exc_info.value)
            assert "daemon" in str(exc_info.value).lower()

    def test_context_with_inputs(self) -> None:
        """Test BlockContext with OutputHandle inputs."""
        data = {"key": "value", "numbers": [1, 2, 3]}
        handle = OutputHandle.from_data(data, name="test_data")
        inputs: dict[str, OutputHandle] = {
            "data": handle,
        }

        ctx = BlockContext(inputs=inputs)

        assert "data" in ctx.inputs
        # ctx.inputs transparently unwraps OutputHandles
        data_input = ctx.inputs["data"]
        assert data_input == data
        # Raw inputs still preserve OutputHandles for internal use
        assert isinstance(ctx._raw_inputs["data"], OutputHandle)

    @pytest.mark.asyncio
    async def test_emit_metric(self) -> None:
        """Test emitting a metric event."""
        ctx = BlockContext(
            run_id=uuid4(),
            step_id="train",
        )

        with patch.object(ctx, "_emit_event", new_callable=AsyncMock) as mock_emit:
            await ctx.emit_metric("loss", 0.5, step=100, labels={"lr": 0.001})

            mock_emit.assert_called_once_with(
                "metric",
                "loss",
                {"value": 0.5, "step": 100.0, "labels": {"lr": 0.001}},
            )

    @pytest.mark.asyncio
    async def test_emit_progress(self) -> None:
        """Test emitting a progress event."""
        ctx = BlockContext(
            run_id=uuid4(),
            step_id="train",
        )

        with patch.object(ctx, "_emit_event", new_callable=AsyncMock) as mock_emit:
            await ctx.emit_progress(50, 100, message="Training...")

            mock_emit.assert_called_once_with(
                "progress",
                None,
                {"current": 50, "total": 100, "message": "Training..."},
            )

    @pytest.mark.asyncio
    async def test_emit_metrics(self) -> None:
        """Test emitting multiple scalar metrics."""
        ctx = BlockContext(run_id=uuid4(), step_id="train")

        with patch.object(ctx, "_emit_event", new_callable=AsyncMock) as mock_emit:
            await ctx.emit_metrics(
                {"loss": 0.5, "accuracy": 0.9},
                step=10,
                labels={"split": "val"},
            )

        assert mock_emit.call_count == 2
        mock_emit.assert_any_call(
            "metric",
            "loss",
            {"value": 0.5, "step": 10.0, "labels": {"split": "val"}},
        )
        mock_emit.assert_any_call(
            "metric",
            "accuracy",
            {"value": 0.9, "step": 10.0, "labels": {"split": "val"}},
        )

    @pytest.mark.asyncio
    async def test_emit_log(self) -> None:
        """Test emitting a structured log event."""
        ctx = BlockContext(run_id=uuid4(), step_id="train")

        with patch.object(ctx, "_emit_event", new_callable=AsyncMock) as mock_emit:
            await ctx.emit_log("training started", level="info", source="train")

        mock_emit.assert_called_once_with(
            "log",
            None,
            {"level": "info", "message": "training started", "source": "train"},
        )

    @pytest.mark.asyncio
    async def test_context_manager(self) -> None:
        """Test using BlockContext as async context manager."""
        ctx = BlockContext()

        async with ctx as c:
            assert c is ctx

        # Client should be closed after exiting context
        assert ctx._block_api_client.is_closed

    @pytest.mark.asyncio
    async def test_close(self) -> None:
        """Test closing the context."""
        ctx = BlockContext()

        await ctx.close()

        assert ctx._block_api_client.is_closed


class TestArtifactManager:
    """Tests for ArtifactManager."""

    @pytest.mark.asyncio
    async def test_calculate_hash(self, tmp_path) -> None:
        """Test file hash calculation."""
        # Create a test file
        test_file = tmp_path / "test.txt"
        test_file.write_text("Hello, World!")

        ctx = BlockContext()

        hash_value = ctx.artifacts._calculate_hash(test_file)

        # SHA256 of "Hello, World!"
        assert len(hash_value) == 64
        assert hash_value == "dffd6021bb2bd5b0af676290809ec3a53191dd81c7f70a4b28688a362182986f"


class TestArtifactResolve:
    """Tests for ArtifactManager.resolve()."""

    @pytest.mark.asyncio
    async def test_resolve_returns_path(self) -> None:
        """Test that resolve returns a Path from the Block API response."""
        artifact_id = uuid4()
        ref = ArtifactRef(artifact_id=artifact_id, schema_type="model_checkpoint", name="weights")

        ctx = BlockContext(run_id=uuid4(), step_id="eval")

        mock_response = MagicMock()
        mock_response.json.return_value = {"path": "/tmp/artifacts/ab/cd/abcdef123"}
        mock_response.raise_for_status = MagicMock()

        async def mock_get(_url, **_kwargs):
            return mock_response

        with patch.object(ctx._block_api_client, "get", side_effect=mock_get) as mock_get_obj:
            from pathlib import Path as P

            result = await ctx.artifacts.resolve(ref)

        assert isinstance(result, P)
        assert str(result) == "/tmp/artifacts/ab/cd/abcdef123"

        # Verify correct endpoint was called
        mock_get_obj.assert_called_once()
        call_url = mock_get_obj.call_args[0][0]
        assert call_url == f"http://127.0.0.1:8002/api/artifacts/{artifact_id}/resolve"

        await ctx.close()

    @pytest.mark.asyncio
    async def test_resolve_raises_on_error(self) -> None:
        """Test that resolve raises on HTTP error."""
        artifact_id = uuid4()
        ref = ArtifactRef(artifact_id=artifact_id, schema_type="model_checkpoint")

        ctx = BlockContext(run_id=uuid4(), step_id="eval")

        mock_response = MagicMock()
        mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "Not Found", request=MagicMock(), response=MagicMock()
        )

        async def mock_get(_url, **_kwargs):
            return mock_response

        with (
            patch.object(ctx._block_api_client, "get", side_effect=mock_get),
            pytest.raises(httpx.HTTPStatusError),
        ):
            await ctx.artifacts.resolve(ref)

        await ctx.close()


class TestOutputHandleIntegration:
    """Tests for OutputHandle integration with BlockContext."""

    def test_context_with_output_handle_input(self) -> None:
        """Test BlockContext with OutputHandle inputs - transparently unwrapped."""
        data = {"weights": [1.0, 2.0, 3.0]}
        handle = OutputHandle.from_data(data, name="model_weights")

        ctx = BlockContext(inputs={"model": handle})

        assert "model" in ctx.inputs
        # ctx.inputs transparently unwraps OutputHandles
        assert ctx.inputs["model"] == data
        # Raw inputs preserve the original OutputHandle object for internal access
        assert isinstance(ctx._raw_inputs["model"], OutputHandle)

    def test_multiple_inputs_via_ctx_inputs(self) -> None:
        """Test context with multiple OutputHandle inputs accessed via ctx.inputs."""
        handle1 = OutputHandle.from_data([1, 2, 3], name="data1")
        handle2 = OutputHandle.from_data({"key": "value"}, name="data2")

        ctx = BlockContext(inputs={"first": handle1, "second": handle2})

        # Both inputs accessible via ctx.inputs (transparently unwrapped)
        assert ctx.inputs["first"] == [1, 2, 3]
        assert ctx.inputs["second"] == {"key": "value"}


class TestContextHardening:
    """Hardening tests for BlockContext edge cases and invariants."""

    @pytest.mark.asyncio
    async def test_emit_metric_with_labels(self) -> None:
        """Test that labels are included in metric event payload."""
        ctx = BlockContext(
            run_id=uuid4(),
            step_id="train",
        )

        with patch.object(ctx, "_emit_event", new_callable=AsyncMock) as mock_emit:
            await ctx.emit_metric(
                "loss",
                0.25,
                step=500,
                labels={"lr": 0.001, "batch_size": 32, "model": "vae"},
            )

            mock_emit.assert_called_once()
            call_args = mock_emit.call_args
            assert call_args[0][0] == "metric"
            assert call_args[0][1] == "loss"
            payload = call_args[0][2]
            assert payload["value"] == 0.25
            assert "epoch" not in payload
            assert payload["step"] == 500.0
            assert payload["labels"] == {"lr": 0.001, "batch_size": 32, "model": "vae"}

    @pytest.mark.asyncio
    async def test_emit_metric_rejects_vector_values(self) -> None:
        """Metrics are scalar series; vectors should be artifacts, tables, or logs."""
        ctx = BlockContext(run_id=uuid4(), step_id="train")

        with pytest.raises(TypeError, match="numeric scalar"):
            await ctx.emit_metric("embedding", [0.1, 0.2])  # type: ignore[arg-type]

    @pytest.mark.asyncio
    async def test_emit_metric_rejects_non_finite_values(self) -> None:
        """Metrics must be JSON-safe finite numbers."""
        ctx = BlockContext(run_id=uuid4(), step_id="train")

        with pytest.raises(ValueError, match="finite"):
            await ctx.emit_metric("loss", float("nan"))

    @pytest.mark.asyncio
    async def test_emit_log_rejects_invalid_level(self) -> None:
        """Structured logs use the shared log level contract."""
        ctx = BlockContext(run_id=uuid4(), step_id="train")

        with pytest.raises(ValueError, match="level"):
            await ctx.emit_log("bad level", level="critical")  # type: ignore[arg-type]

    @pytest.mark.asyncio
    async def test_emit_progress_bounds(self) -> None:
        """Test progress values - current and total are passed through as-is.

        Note: The implementation does not clamp values; callers are responsible
        for providing valid progress values (0 <= current <= total).
        """
        ctx = BlockContext(
            run_id=uuid4(),
            step_id="process",
        )

        with patch.object(ctx, "_emit_event", new_callable=AsyncMock) as mock_emit:
            # Normal case
            await ctx.emit_progress(50, 100, message="Halfway done")
            call_args = mock_emit.call_args
            payload = call_args[0][2]
            assert payload["current"] == 50
            assert payload["total"] == 100
            assert payload["message"] == "Halfway done"

        with patch.object(ctx, "_emit_event", new_callable=AsyncMock) as mock_emit:
            # Edge case: current equals total (100% complete)
            await ctx.emit_progress(100, 100, message="Done")
            payload = mock_emit.call_args[0][2]
            assert payload["current"] == 100
            assert payload["total"] == 100

        with patch.object(ctx, "_emit_event", new_callable=AsyncMock) as mock_emit:
            # Edge case: zero progress
            await ctx.emit_progress(0, 100, message="Starting")
            payload = mock_emit.call_args[0][2]
            assert payload["current"] == 0
            assert payload["total"] == 100

    @pytest.mark.asyncio
    async def test_artifacts_register_returns_ref(self, tmp_path) -> None:
        """Test that artifact registration returns a RegisteredArtifact wrapper."""
        # Create a test file
        test_file = tmp_path / "model.pt"
        test_file.write_bytes(b"fake model weights data")

        lab_id = uuid4()
        run_id = uuid4()
        artifact_id = uuid4()

        ctx = BlockContext(
            run_id=run_id,
            step_id="train_vae",
            lab_id=lab_id,
        )

        # Mock the HTTP response for artifact registration
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "id": str(artifact_id),
            "name": "vae_weights",
            "schema_type": "model_checkpoint",
            "storage_ref": "managed://abc123",
        }
        mock_response.raise_for_status = MagicMock()

        async def mock_post(*_args, **_kwargs):
            return mock_response

        with (
            patch.object(ctx._block_api_client, "post", side_effect=mock_post) as mock_post_obj,
            patch.object(ctx, "_emit_event", new_callable=AsyncMock) as mock_emit,
        ):
            ref = await ctx.artifacts.register(
                local_path=test_file,
                schema_type="model_checkpoint",
                name="vae_weights",
                mime_type="application/x-pytorch",
                tags=["vae", "checkpoint"],
                metadata={"epoch": 10},
            )

        # Verify the returned RegisteredArtifact
        assert isinstance(ref, RegisteredArtifact)
        assert ref.artifact_id == artifact_id
        assert ref.schema_type == "model_checkpoint"
        assert ref.name == "vae_weights"
        assert isinstance(ref.ref, ArtifactRef)

        # Verify the registration request was made with correct data
        mock_post_obj.assert_called_once()
        call_kwargs = mock_post_obj.call_args[1]
        payload = call_kwargs["json"]
        assert payload["name"] == "vae_weights"
        assert payload["schema_type"] == "model_checkpoint"
        assert payload["mime_type"] == "application/x-pytorch"
        assert payload["tags"] == ["vae", "checkpoint"]
        assert payload["metadata"] == {"epoch": 10}
        assert payload["run_id"] == str(run_id)
        assert payload["step_id"] == "train_vae"
        mock_emit.assert_not_called()

    @pytest.mark.asyncio
    async def test_artifacts_register_inline_json_supports_as_data(self) -> None:
        """Test in-memory artifact registration with explicit format supports as_data()."""
        ctx = BlockContext(run_id=uuid4(), step_id="train")
        artifact_id = uuid4()

        mock_response = MagicMock()
        mock_response.json.return_value = {
            "id": str(artifact_id),
            "name": "metrics",
            "schema_type": "metrics",
            "format": "json",
            "storage_ref": "managed://feedface",
            "content_hash": "feedface",
        }
        mock_response.raise_for_status = MagicMock()

        async def mock_post(*_args, **_kwargs):
            return mock_response

        with (
            patch.object(ctx._block_api_client, "post", side_effect=mock_post) as mock_post_obj,
            patch.object(ctx, "_emit_event", new_callable=AsyncMock) as mock_emit,
        ):
            registered = await ctx.artifacts.register(
                {"loss": 0.1},
                schema_type="metrics",
                name="metrics",
                format="json",
            )

        assert isinstance(registered, RegisteredArtifact)
        assert registered.format == "json"
        assert registered.as_ref() == registered.ref
        data_token = registered.as_data()
        assert data_token.artifact is registered
        payload = mock_post_obj.call_args[1]["json"]
        assert payload["format"] == "json"
        assert payload["inline_bytes_b64"]
        mock_emit.assert_not_called()

    def test_registered_artifact_as_data_rejects_external_refs(self) -> None:
        """External artifacts should stay pointer-delivered at block boundaries."""
        registered = RegisteredArtifact(
            ref=ArtifactRef(
                artifact_id=uuid4(),
                schema_type="dataset",
                name="remote-dataset",
                uri="s3://bucket/data.parquet",
            ),
            format="json",
            content_hash="abc123",
            storage_key="abc123",
        )

        with pytest.raises(ValueError, match="External artifacts cannot be returned as data"):
            registered.as_data()

    @pytest.mark.asyncio
    async def test_load_deserializes_using_stored_format(self) -> None:
        """Test artifact load uses the artifact format field."""
        artifact_id = uuid4()
        ctx = BlockContext(run_id=uuid4(), step_id="train")
        ref = ArtifactRef(artifact_id=artifact_id, schema_type="metrics", name="metrics")

        meta_response = MagicMock()
        meta_response.json.return_value = {"id": str(artifact_id), "format": "json"}
        meta_response.raise_for_status = MagicMock()

        bytes_response = MagicMock()
        bytes_response.content = b'{"loss": 0.1}'
        bytes_response.raise_for_status = MagicMock()

        async def mock_get(url, **_kwargs):
            if url.endswith("/meta"):
                return meta_response
            if url.endswith("/bytes"):
                return bytes_response
            raise AssertionError(f"Unexpected URL: {url}")

        with patch.object(ctx._block_api_client, "get", side_effect=mock_get):
            loaded = await ctx.artifacts.load(ref)

        assert loaded == {"loss": 0.1}

    @pytest.mark.asyncio
    async def test_check_pause_cooperative(self) -> None:
        """Test check_pause returns current pause state from run status."""
        run_id = uuid4()
        ctx = BlockContext(run_id=run_id)

        # Test when run is paused
        mock_response_paused = MagicMock()
        mock_response_paused.json.return_value = {"status": "paused"}
        mock_response_paused.raise_for_status = MagicMock()

        async def mock_get_paused(*_args, **_kwargs):
            return mock_response_paused

        with patch.object(ctx._block_api_client, "get", side_effect=mock_get_paused):
            is_paused = await ctx.check_pause()
            assert is_paused is True

        # Test when run is running
        mock_response_running = MagicMock()
        mock_response_running.json.return_value = {"status": "running"}
        mock_response_running.raise_for_status = MagicMock()

        async def mock_get_running(*_args, **_kwargs):
            return mock_response_running

        with patch.object(ctx._block_api_client, "get", side_effect=mock_get_running):
            is_paused = await ctx.check_pause()
            assert is_paused is False

        # Test when run_id is None (no run context)
        ctx_no_run = BlockContext()
        is_paused = await ctx_no_run.check_pause()
        assert is_paused is False

        # Test when HTTP request fails (returns False gracefully)
        async def mock_get_error(*_args, **_kwargs):
            raise httpx.HTTPError("Connection failed")

        with patch.object(ctx._block_api_client, "get", side_effect=mock_get_error):
            is_paused = await ctx.check_pause()
            assert is_paused is False

    def test_context_immutable_config(self) -> None:
        """Test that config cannot be modified after context creation.

        Note: The current implementation uses a regular dict for config.
        This test documents the expected behavior - config should be treated
        as immutable after context creation. The implementation may need
        to be updated to enforce true immutability.
        """
        original_config = {"epochs": 100, "lr": 0.001}
        ctx = BlockContext(config=original_config)

        # Config should be accessible
        assert ctx.config["epochs"] == 100
        assert ctx.config["lr"] == 0.001

        # Test that modifying the original dict doesn't affect context config
        # (config should be a copy)
        original_config["epochs"] = 200
        # If implementation copies the config, this should still be 100
        # If it doesn't copy, this documents the current behavior

        # Verify the config was stored
        assert "epochs" in ctx.config
        assert "lr" in ctx.config

        # Verify basic structure is correct
        assert isinstance(ctx.config, dict)


class TestBlockAPIRouting:
    """Tests for Block API routing."""

    def test_block_api_set(self) -> None:
        """Test context with Block API env var creates Block API client."""
        ctx = BlockContext()

        assert ctx._block_api_url == "http://127.0.0.1:8002"
        assert ctx._block_api_client is not None

    @pytest.mark.asyncio
    async def test_typed_event_helpers_use_block_api(self) -> None:
        """Test that typed event helpers route to Block API."""
        run_id = uuid4()
        ctx = BlockContext(run_id=run_id, step_id="train")

        # Mock the Block API client's post method
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()

        async def mock_post(_url, **_kwargs):
            return mock_response

        with patch.object(ctx._block_api_client, "post", side_effect=mock_post) as mock:
            await ctx.emit_metric("loss", 0.5, step=1)

        # Verify call was made to Block API endpoint
        mock.assert_called_once()
        call_url = mock.call_args[0][0]
        assert call_url == "http://127.0.0.1:8002/api/events"

        # Verify event data
        call_kwargs = mock.call_args[1]
        event_data = call_kwargs["json"]
        assert event_data["run_id"] == str(run_id)
        assert event_data["event_type"] == "metric"
        assert event_data["event_name"] == "loss"
        assert event_data["step_id"] == "train"
        assert "node_id" not in event_data

        await ctx.close()

    def test_public_generic_emit_event_removed(self) -> None:
        """Block authors should use typed helpers instead of arbitrary events."""
        ctx = BlockContext()

        assert not hasattr(ctx, "emit_event")

    @pytest.mark.asyncio
    async def test_check_pause_uses_block_api(self) -> None:
        """Test that check_pause routes to Block API status endpoint."""
        run_id = uuid4()
        ctx = BlockContext(run_id=run_id)

        # Mock the Block API response for paused state
        mock_response = MagicMock()
        mock_response.json.return_value = {"run_id": str(run_id), "status": "paused"}
        mock_response.raise_for_status = MagicMock()

        async def mock_get(_url, **_kwargs):
            return mock_response

        with patch.object(ctx._block_api_client, "get", side_effect=mock_get) as mock:
            is_paused = await ctx.check_pause()

        assert is_paused is True

        # Verify call was made to Block API status endpoint
        mock.assert_called_once()
        call_url = mock.call_args[0][0]
        assert call_url == f"http://127.0.0.1:8002/api/runs/{run_id}/status"

        await ctx.close()

    @pytest.mark.asyncio
    async def test_artifact_register_uses_block_api(self, tmp_path) -> None:
        """Test that artifact registration routes to Block API."""
        run_id = uuid4()
        artifact_id = uuid4()

        # Create test file
        test_file = tmp_path / "model.pt"
        test_file.write_bytes(b"fake model weights")

        ctx = BlockContext(run_id=run_id, step_id="train")

        # Mock Block API response
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "id": str(artifact_id),
            "name": "weights",
            "schema_type": "model_checkpoint",
            "storage_ref": "managed://abc123",
        }
        mock_response.raise_for_status = MagicMock()

        async def mock_post(_url, **_kwargs):
            return mock_response

        with (
            patch.object(ctx._block_api_client, "post", side_effect=mock_post) as mock_post_obj,
            patch.object(ctx, "_emit_event", new_callable=AsyncMock) as mock_emit,
        ):
            ref = await ctx.artifacts.register(
                local_path=test_file,
                schema_type="model_checkpoint",
                name="weights",
            )

        assert ref.artifact_id == artifact_id

        # Verify call was made to Block API artifacts endpoint
        mock_post_obj.assert_called_once()
        call_url = mock_post_obj.call_args[0][0]
        assert call_url == "http://127.0.0.1:8002/api/artifacts"

        # Verify payload uses storage_ref URI format
        call_kwargs = mock_post_obj.call_args[1]
        payload = call_kwargs["json"]
        assert payload["local_path"] == str(test_file.absolute())
        mock_emit.assert_not_called()

        await ctx.close()

    @pytest.mark.asyncio
    async def test_close_closes_client(self) -> None:
        """Test that close() closes Block API client."""
        ctx = BlockContext()

        assert ctx._block_api_client is not None
        assert not ctx._block_api_client.is_closed

        await ctx.close()

        assert ctx._block_api_client.is_closed

    @pytest.mark.asyncio
    async def test_context_manager_closes_client(self) -> None:
        """Test that context manager closes client."""
        ctx = BlockContext()

        async with ctx as c:
            assert c is ctx
            assert not c._block_api_client.is_closed

        assert ctx._block_api_client.is_closed
