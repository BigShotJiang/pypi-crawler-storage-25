# AUTO-GENERATED — do not edit manually.
# Source of truth: schemas/*.json
#
# Regenerate with: make generate-types

from __future__ import annotations

from enum import StrEnum
from typing import Any, Literal, TypeAlias
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class ArtifactRef(BaseModel):
    """Reference to an artifact.."""

    model_config = ConfigDict(frozen=True)

    artifact_id: UUID
    schema_type: str | None = None
    name: str | None = None
    uri: str | None = None

    def __str__(self) -> str:
        return f"ArtifactRef({self.artifact_id})"

    def __hash__(self) -> int:
        return hash((self.artifact_id, self.schema_type, self.name, self.uri))


class BlockDataRef(BaseModel):
    """Storage-backed value passed between the daemon and harness.."""

    kind: Literal["data"] = "data"
    storage_key: str
    content_hash: str
    artifact_id: str | None = None
    execution_output_id: UUID | None = None
    name: str | None = None
    schema_type: str | None = None
    mime_type: str | None = None
    step_id: str | None = None
    tags: list[str] | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    format: str | None = None


class BlockArtifactRef(BaseModel):
    """Artifact pointer passed between the daemon and harness.."""

    model_config = ConfigDict(populate_by_name=True)

    artifact_ref: Literal[True] = Field(default=True, alias="__artifact_ref__")
    artifact_id: UUID
    schema_type: str | None = None
    name: str | None = None
    uri: str | None = None


class EventType(StrEnum):
    """Persisted run event type.."""

    METRIC = "metric"
    PROGRESS = "progress"
    ARTIFACT_WRITTEN = "artifact_written"
    STEP_STATUS = "step_status"
    RUN_STATUS = "run_status"
    LOG = "log"
    GATE_FIRED = "gate_fired"
    PACKAGE_PUBLISHED = "package_published"
    NODES_HELD = "nodes_held"
    NODES_RELEASED = "nodes_released"
    GATE_CREATED = "gate_created"
    GATE_UPDATED = "gate_updated"
    GATE_DELETED = "gate_deleted"
    INSPECTOR_ATTACHED = "inspector_attached"
    INSPECTOR_DETACHED = "inspector_detached"
    GATE_ERROR = "gate_error"
    RUN_RESUMED = "run_resumed"


class EventPayload(BaseModel):
    """Generic event payload base for internal event types without specialized contracts.."""

    model_config = ConfigDict(extra="allow")

    pass


class MetricEvent(BaseModel):
    """Payload for metric events.."""

    model_config = ConfigDict(allow_inf_nan=False, extra="forbid")

    value: float
    step: float | None = None
    labels: dict[str, Any] = Field(default_factory=dict)


class ProgressEvent(BaseModel):
    """Payload for progress events.."""

    model_config = ConfigDict(extra="allow")

    current: int = Field(..., ge=0)
    total: int = Field(..., ge=0)
    message: str | None = None


class ArtifactWrittenEvent(BaseModel):
    """Payload for artifact_written events.."""

    model_config = ConfigDict(extra="allow")

    artifact_id: str
    schema_type: str | None = None
    tags: list[str] = Field(default_factory=list)


class StepStatusEvent(BaseModel):
    """Payload for step_status events.."""

    model_config = ConfigDict(extra="allow")

    status: Literal[
        "pending", "context_pending", "running", "succeeded", "failed", "skipped", "killed"
    ]
    message: str | None = None


class RunStatusEvent(BaseModel):
    """Payload for run_status events.."""

    model_config = ConfigDict(extra="allow")

    status: Literal["created", "running", "paused", "succeeded", "failed", "killed"]
    message: str | None = None
    is_terminal: bool = False
    held_nodes: dict[str, Any] | None = None
    pause_gate: dict[str, Any] | None = None


class LogEvent(BaseModel):
    """Payload for log events.."""

    model_config = ConfigDict(extra="allow")

    level: Literal["debug", "info", "warning", "error"] = "info"
    message: str
    source: str | None = None
    traceback: str | None = None


class GateFiredEvent(BaseModel):
    """Payload for gate_fired events.."""

    model_config = ConfigDict(extra="allow")

    gate_id: str
    gate_name: str
    action: str
    reason: str | None = None
    target_nodes: list[str] | None = None
    human_only: bool = False


KnownEventPayload: TypeAlias = (
    MetricEvent
    | ProgressEvent
    | ArtifactWrittenEvent
    | StepStatusEvent
    | RunStatusEvent
    | LogEvent
    | GateFiredEvent
)


class RunEventDisplayProjection(BaseModel):
    """Server-owned display projection for persisted run events.."""

    model_config = ConfigDict(extra="forbid")

    category: str
    severity: Literal["debug", "info", "success", "warning", "error"]
    summary: str
    detail: str | None = None
    payload: EventPayload = Field(default_factory=lambda: EventPayload())


class RunEventEnvelope(BaseModel):
    """Canonical persisted and streamed run event envelope.."""

    model_config = ConfigDict(extra="forbid")

    id: int = Field(..., ge=0)
    run_id: UUID
    event_type: str
    event_name: str | None = None
    node_id: str | None = None
    payload: EventPayload
    created_at: str
    display: RunEventDisplayProjection


class SessionStreamPayloadType(StrEnum):
    """Planner session stream payload discriminator.."""

    CONNECTED = "connected"
    RESYNC_REQUIRED = "resync_required"
    DELETED = "deleted"
    SESSION = "session"
    ENTRY = "entry"
    DIRECTIVE = "directive"
    ASSISTANT_TEXT_DELTA = "assistant_text_delta"
    ASSISTANT_TEXT_COMMIT = "assistant_text_commit"
    CLEARED = "cleared"


class SessionConnectedStreamPayload(BaseModel):
    """Planner session stream connection acknowledgement.."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["connected"] = "connected"
    transcript_id: UUID


class SessionResyncRequiredStreamPayload(BaseModel):
    """Planner session stream replay cursor is stale.."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["resync_required"] = "resync_required"
    transcript_id: UUID


class SessionDeletedStreamPayload(BaseModel):
    """Planner session stream terminal deletion signal.."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["deleted"] = "deleted"
    transcript_id: UUID


class SessionStateStreamPayload(BaseModel):
    """Planner session summary update.."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["session"] = "session"
    session: dict[str, Any]


class SessionEntryStreamPayload(BaseModel):
    """Planner transcript entry update.."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["entry"] = "entry"
    entry: dict[str, Any]


class SessionDirectiveStreamPayload(BaseModel):
    """Planner directive queue update.."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["directive"] = "directive"
    directive: dict[str, Any]


class SessionAssistantTextDeltaStreamPayload(BaseModel):
    """Incremental assistant text delta for an in-progress turn.."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["assistant_text_delta"] = "assistant_text_delta"
    directive_id: UUID
    stream_id: str = Field(..., min_length=1)
    delta: str


class SessionAssistantTextCommitStreamPayload(BaseModel):
    """Committed assistant text entry for an in-progress turn.."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["assistant_text_commit"] = "assistant_text_commit"
    directive_id: UUID
    stream_id: str = Field(..., min_length=1)
    entry: dict[str, Any]


class SessionClearedStreamPayload(BaseModel):
    """Planner session clear result update.."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["cleared"] = "cleared"
    cleared: dict[str, Any]


SessionStreamPayload: TypeAlias = (
    SessionConnectedStreamPayload
    | SessionResyncRequiredStreamPayload
    | SessionDeletedStreamPayload
    | SessionStateStreamPayload
    | SessionEntryStreamPayload
    | SessionDirectiveStreamPayload
    | SessionAssistantTextDeltaStreamPayload
    | SessionAssistantTextCommitStreamPayload
    | SessionClearedStreamPayload
)


class SessionStreamEnvelope(BaseModel):
    """Canonical server-side planner session stream envelope.."""

    model_config = ConfigDict(extra="forbid")

    event_id: int = Field(..., ge=1)
    payload: SessionStreamPayload


class BlockConfig(BaseModel):
    """Base class for block configuration.."""

    model_config = ConfigDict(extra="allow")

    pass


class BlockInput(BaseModel):
    """Definition of a block input.."""

    name: str
    type: str
    required: bool = True
    description: str | None = None


class BlockOutput(BaseModel):
    """Definition of a block output.."""

    name: str
    type: str
    description: str | None = None


class BlockSpec(BaseModel):
    """Specification for a block.."""

    name: str
    description: str | None = None
    inputs: list[BlockInput] = Field(default_factory=list)
    outputs: list[BlockOutput] = Field(default_factory=list)
    config_schema: dict[str, Any] | None = None
    config_path: str | None = Field(
        default=None,
        description="Path to config file, relative to workspace root (e.g., 'configs/blocks/train_vae.yaml')",
    )
    secrets: list[str] = Field(
        default_factory=list,
        description="List of required secret names resolved at runtime (e.g., ['OPENAI_API_KEY'])",
    )


class GateAction(StrEnum):
    """Actions a gate can take when fired.."""

    PAUSE = "pause"
    KILL = "kill"
    NOTIFY = "notify"


class GateSource(StrEnum):
    """Source of a gate - where it was defined.."""

    CONFIG = "config"
    RUNTIME = "runtime"


class AfterStepPredicate(BaseModel):
    """Predicate that fires after a step completes.."""

    model_config = ConfigDict(extra="allow")

    type: Literal["after_step"] = "after_step"
    node_id: str = Field(..., description="Node ID to wait for")
    status: str = Field(
        default="succeeded", description="Status to trigger on (succeeded, failed, any)"
    )


class MetricThresholdPredicate(BaseModel):
    """Predicate that fires when a metric crosses a threshold.."""

    model_config = ConfigDict(extra="allow")

    type: Literal["metric_threshold"] = "metric_threshold"
    metric: str = Field(..., description="Metric name to monitor")
    op: Literal["<", "<=", ">", ">=", "==", "!="] = Field(..., description="Comparison operator")
    value: float = Field(..., description="Threshold value")
    node_id: str | None = Field(default=None, description="Optional node ID filter")


class MetricWindowPredicate(BaseModel):
    """Predicate that fires based on metric behavior over a window.."""

    model_config = ConfigDict(extra="allow")

    type: Literal["metric_window"] = "metric_window"
    metric: str = Field(..., description="Metric name to monitor")
    window: int = Field(..., description="Window size (number of samples)", ge=2)
    reducer: Literal["slope", "mean", "min", "max", "std"] = Field(
        ..., description="Reduction function"
    )
    op: Literal["<", "<=", ">", ">=", "==", "!="] = Field(..., description="Comparison operator")
    value: float = Field(..., description="Threshold value")


class GateRefPredicate(BaseModel):
    """Predicate that references another gate's match result.."""

    model_config = ConfigDict(extra="allow")

    type: Literal["gate_ref"] = "gate_ref"
    gate_id: str = Field(..., description="ID of the gate to reference")


class CompoundPredicate(BaseModel):
    """Predicate that combines multiple predicates with AND/OR logic.."""

    model_config = ConfigDict(extra="allow")

    type: Literal["compound"] = "compound"
    operator: Literal["and", "or"] = Field(..., description="Logical operator")
    predicates: list[GatePredicate] = Field(
        ..., description="Child predicates to combine", min_length=1
    )


class NotPredicate(BaseModel):
    """Predicate that negates another predicate.."""

    model_config = ConfigDict(extra="allow")

    type: Literal["not"] = "not"
    when: GatePredicate = Field(..., description="Predicate to negate")


GatePredicate: TypeAlias = (
    AfterStepPredicate
    | MetricThresholdPredicate
    | MetricWindowPredicate
    | GateRefPredicate
    | CompoundPredicate
    | NotPredicate
)


class GateDefinition(BaseModel):
    """Definition of a gate.."""

    name: str
    description: str | None = None
    predicate: GatePredicate
    action: GateAction
    action_params: dict[str, Any] = Field(default_factory=dict)
    is_enabled: bool = True
    target_nodes: list[str] | None = Field(
        default=None,
        description="Node IDs to hold when gate fires. None = pause entire run (default).",
    )
    human_only: bool = Field(
        default=False,
        description="If True, only humans (JWT) can release held nodes; agent (MCP) cannot.",
    )


class RuntimeSpec(BaseModel):
    """How to launch a block's worker process.."""

    interpreter: str | None = Field(
        default=None,
        description="Language runtime invocation (e.g. 'uv run python', 'julia'). Resolved server-side from workflow config _default / _default.{ext} / per-node overrides. If None at daemon launch time, the daemon hard-fails with an actionable error.",
    )
    fresh: bool = Field(
        default=False,
        description="If True, spawn a new process for each block execution and kill after. If False (default), reuse warm worker processes between blocks.",
    )


class ExecutionBackendKind(StrEnum):
    """Execution backend used by a daemon host for one attempt.."""

    PROCESS_POOL = "process_pool"


class ExecutionExecutableSpec(BaseModel):
    """Language-neutral executable description for one block attempt.."""

    kind: Literal["sdk_block", "command"] = "sdk_block"
    block_path: str = Field(..., description="Path to the block source file.", min_length=1)
    block_id: str = Field(
        ...,
        description="Discovered block entrypoint identifier for SDK-backed execution.",
        min_length=1,
    )
    command: str | None = Field(
        default=None, description="CLI command for raw execution when kind='command'."
    )


class ExecuteBlockAttempt(BaseModel):
    """Transport-neutral execute_block attempt payload.."""

    model_config = ConfigDict(extra="ignore")

    type: Literal["execute_block"] = "execute_block"
    run_id: UUID
    node_id: str = Field(..., min_length=1)
    dispatch_id: str = Field(..., min_length=1)
    dispatch_token: str = Field(..., min_length=1)
    execution_attempt_id: UUID
    workspace_id: UUID | None = None
    context_name: str | None = None
    context_id: UUID | None = None
    code_ref: CodeRef
    runtime: RuntimeSpec = Field(default_factory=lambda: RuntimeSpec())
    execution_backend: ExecutionBackendKind = ExecutionBackendKind("process_pool")
    executable: ExecutionExecutableSpec
    config: dict[str, Any] = Field(default_factory=dict)
    inputs: dict[str, Any] = Field(default_factory=dict)
    input_artifact_ids: list[str] = Field(default_factory=list)
    secret_names: list[str] = Field(default_factory=list)
    effective_cache_key: str | None = None


class DagNode(BaseModel):
    """A node in the DAG representing a block.."""

    model_config = ConfigDict(extra="ignore")

    id: str = Field(..., description="Unique identifier for this node in the DAG")
    block_path: str = Field(..., description="Path to the block file")
    block_id: str = Field(..., description="Block class/function identifier")
    context_ref: str | None = Field(
        default=None, description="Execution context name. Compiler stamps 'default' when omitted."
    )
    code_ref: CodeRef | None = Field(
        default=None,
        description="Repository and commit for this node. Compiler resolves this before execution.",
    )
    label: str = Field(
        ..., description="Human-readable display name from @block(name=...)", min_length=1
    )
    secrets: list[str] = Field(
        default_factory=list,
        description="Secret names required by this block (from @block(secrets=[...]))",
    )
    outputs: list[BlockOutput] = Field(
        default_factory=list,
        description="Optional declared outputs used for cache/seed completeness checks.",
    )
    command: str | None = Field(
        default=None,
        description="CLI command for raw blocks (e.g. 'bash train.sh'). If set, the block runs in raw mode with file-based I/O instead of the harness.",
    )


class DagEdge(BaseModel):
    """An edge in the DAG representing data flow or execution ordering.."""

    from_node: str
    from_output: str | None = None
    to_node: str
    to_input: str | None = None


class DagSpec(BaseModel):
    """Complete DAG specification.."""

    nodes: list[DagNode]
    edges: list[DagEdge] = Field(default_factory=list)


class CodeRef(BaseModel):
    """Code selection for a node or run default.."""

    model_config = ConfigDict(frozen=True)

    repo_url: str = Field(..., description="Repository identity for this code", min_length=1)
    branch_name: str | None = Field(
        default=None,
        description="Optional branch name used as a fetch hint when the commit is not local.",
    )
    commit_sha: str | None = Field(
        default=None, description="Pinned commit SHA. The compiler resolves this before execution."
    )


class BlockApiWorkerTask(BaseModel):
    """Task assigned by the daemon Block API to a worker harness.."""

    run_id: UUID
    step_id: str
    block_path: str
    block_id: str
    config: dict[str, Any] = Field(default_factory=dict)
    inputs: dict[str, Any] = Field(default_factory=dict)
    secrets: dict[str, str] = Field(default_factory=dict)


class BlockApiWorkerDoneSuccess(BaseModel):
    """Successful worker completion payload.."""

    outputs: dict[str, Any] = Field(default_factory=dict)


class BlockApiWorkerDoneFailure(BaseModel):
    """Failed worker completion payload.."""

    error: str
    traceback: str | None = None


BlockApiWorkerDoneRequest: TypeAlias = BlockApiWorkerDoneSuccess | BlockApiWorkerDoneFailure


class BlockApiEmitEventRequest(BaseModel):
    """Single event emission request accepted by the Block API.."""

    model_config = ConfigDict(extra="forbid")

    run_id: UUID
    event_type: Literal["metric", "progress", "log"]
    event_name: str | None = None
    step_id: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)


class BlockApiEmitEventsBatchRequest(BaseModel):
    """Batch event emission request accepted by the Block API.."""

    events: list[BlockApiEmitEventRequest]


class BlockApiRegisterArtifactRequest(BaseModel):
    """Artifact registration request accepted by the Block API.."""

    model_config = ConfigDict(extra="forbid")

    name: str
    content_hash: str | None = None
    schema_type: str | None = None
    mime_type: str | None = None
    storage_ref: str | None = None
    run_id: UUID | None = None
    step_id: str | None = None
    size_bytes: int | None = None
    tags: list[str] | None = None
    metadata: dict[str, Any] | None = None
    input_artifact_ids: list[str] | None = None
    format: str | None = None
    local_path: str | None = None
    uri: str | None = None
    inline_bytes_b64: str | None = None
    connection: str | None = None


class BlockApiArtifactMetaResponse(BaseModel):
    """Artifact metadata response returned by the Block API.."""

    model_config = ConfigDict(extra="allow")

    id: UUID
    name: str | None = None
    schema_type: str | None = None
    external_uri: str | None = None
    uri: str | None = None
    storage_ref: str | None = None
    content_hash: str | None = None
    mime_type: str | None = None
    format: str | None = None
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    size_bytes: int | None = None
    credential_id: str | None = None


class BlockApiResolveArtifactResponse(BaseModel):
    """Artifact resolve response returned by the Block API.."""

    path: str


class BlockApiRunStatusResponse(BaseModel):
    """Run status response returned by the Block API.."""

    run_id: UUID
    status: str | None = None
    held_nodes: dict[str, Any] | None = None
    node_held: bool


class InputSpec(BaseModel):
    """Declared input metadata for a discovered block.."""

    name: str
    type: str
    required: bool = True


class OutputSpec(BaseModel):
    """Declared output metadata for a discovered block.."""

    name: str
    type: str


class ScannerDiscoveryIssue(BaseModel):
    """Structured issue emitted directly by a language scanner while building a block registry.."""

    file: str
    error: str
    function: str | None = None
    functions: list[str] | None = None
    traceback: str | None = None

    def __getitem__(self, key: str) -> Any:
        return getattr(self, key)

    def get(self, key: str, default: Any = None) -> Any:
        return getattr(self, key, default)

    def __contains__(self, key: object) -> bool:
        return isinstance(key, str) and getattr(self, key, None) is not None


class DiscoveredBlock(BaseModel):
    """A discovered block in one repo surface before source annotation is applied.."""

    name: str
    file_path: str = Field(..., description="Relative path to the block file.")
    entrypoint_id: str = Field(
        ..., description="Canonical execution entrypoint identifier for this block."
    )
    inputs: list[InputSpec] = Field(default_factory=list)
    outputs: list[OutputSpec] = Field(default_factory=list)
    config_schema: dict[str, Any] | None = None
    config_path: str | None = Field(
        default=None, description="Path to config file, relative to workspace root."
    )
    secrets: list[str] = Field(
        default_factory=list, description="Required secret names for this block."
    )
    description: str | None = None
    language: str = "python"


class BlockRegistry(BaseModel):
    """Registry of discovered blocks emitted by one language scanner.."""

    version: str = "2.0"
    language: str = Field(..., description="Language of the scanner that produced this registry.")
    workspace: str = Field(..., description="Absolute path to the workspace root.")
    blocks: list[DiscoveredBlock] = Field(default_factory=list)
    scan_errors: list[ScannerDiscoveryIssue] = Field(default_factory=list)


class DiscoveryConfigEntry(BaseModel):
    """One workflow config blob included in a raw discovery snapshot.."""

    key: str
    config: dict[str, Any]
    is_composed: bool = False


class DiscoveryBlockConfigEntry(BaseModel):
    """One block config blob included in a raw discovery snapshot.."""

    block_id: str
    config: dict[str, Any]
    config_path: str | None = None
    is_composed: bool = False


class InspectorDescriptor(BaseModel):
    """Inspector metadata included in discovery payloads.."""

    name: str
    display_name: str | None = None
    description: str | None = None
    version: str | None = None
    tags: list[str] = Field(default_factory=list)
    path: str | None = None
    url: str | None = None
    entry: str | None = None
    multi_run: bool | None = None
    build_status: str | None = None
    build_error: str | None = None
    build_log: str | None = None


class DiscoveryIssue(BaseModel):
    """Top-level discovery issue surfaced to server and UI consumers.."""

    stage: str | None = None
    severity: str | None = None
    message: str
    error: str | None = None
    error_code: str | None = None
    hint: str | None = None
    recoverable: bool = False
    language: str | None = None
    interpreter: str | None = None
    file: str | None = None
    function: str | None = None
    functions: list[str] | None = None
    traceback: str | None = None

    def __getitem__(self, key: str) -> Any:
        return getattr(self, key)

    def get(self, key: str, default: Any = None) -> Any:
        return getattr(self, key, default)

    def __contains__(self, key: object) -> bool:
        return isinstance(key, str) and getattr(self, key, None) is not None


class WorkspaceDiscoverySnapshot(BaseModel):
    """Canonical raw discovery payload emitted by a live workspace daemon.."""

    registry: BlockRegistry
    configs: list[DiscoveryConfigEntry] = Field(default_factory=list)
    block_configs: list[DiscoveryBlockConfigEntry] = Field(default_factory=list)
    configs_path: str = "configs"
    inspectors: list[InspectorDescriptor] = Field(default_factory=list)
    errors: list[DiscoveryIssue] = Field(default_factory=list)
    sdk_version: str | None = None
    inspector_server_url: str | None = None
    workspace_id: UUID
    repo_url: str | None = None


class AuthoringDiscoverySnapshot(BaseModel):
    """Canonical raw discovery payload emitted for a planner/session worktree snapshot.."""

    registry: BlockRegistry
    configs: list[DiscoveryConfigEntry] = Field(default_factory=list)
    block_configs: list[DiscoveryBlockConfigEntry] = Field(default_factory=list)
    configs_path: str = "configs"
    inspectors: list[InspectorDescriptor] = Field(default_factory=list)
    errors: list[DiscoveryIssue] = Field(default_factory=list)
    sdk_version: str | None = None
    head_sha: str | None = None
    inspector_server_url: str | None = None
    snapshot_persistable: bool | None = None


DiscoverySnapshot: TypeAlias = WorkspaceDiscoverySnapshot | AuthoringDiscoverySnapshot


class DiscoverySource(BaseModel):
    """One active or inactive repo surface contributing discovery to a lab.."""

    source_id: str
    source_kind: Literal["workspace", "session"]
    workspace_id: UUID
    branch_context_id: UUID | None = None
    workspace_name: str | None = None
    repo_url: str | None = None
    session_id: UUID | None = None
    repo_context_id: UUID | None = None
    branch_name: str | None = None
    commit_sha: str | None = None
    is_dirty: bool = False
    availability: str
    configs_path: str | None = None
    inspector_server_url: str | None = None


class LabDiscoveredBlock(BaseModel):
    """A discovered block annotated with its contributing repo surface.."""

    name: str
    file_path: str
    entrypoint_id: str = Field(
        ..., description="Canonical execution entrypoint identifier for this block."
    )
    inputs: list[InputSpec] = Field(default_factory=list)
    outputs: list[OutputSpec] = Field(default_factory=list)
    config_schema: dict[str, Any] | None = None
    config_path: str | None = None
    secrets: list[str] = Field(default_factory=list)
    description: str | None = None
    language: str = "python"
    source_id: str
    source_kind: Literal["workspace", "session"]
    workspace_id: UUID
    branch_context_id: UUID | None = None
    workspace_name: str | None = None
    repo_url: str | None = None
    session_id: UUID | None = None
    repo_context_id: UUID | None = None


class WorkflowConfigEntry(BaseModel):
    """A workflow config blob annotated with its contributing repo surface.."""

    key: str
    config: dict[str, Any]
    is_composed: bool = False
    source_id: str
    source_kind: Literal["workspace", "session"]
    workspace_id: UUID
    branch_context_id: UUID | None = None
    workspace_name: str | None = None
    repo_url: str | None = None
    session_id: UUID | None = None
    repo_context_id: UUID | None = None


class BlockConfigEntry(BaseModel):
    """A block config blob annotated with its contributing repo surface.."""

    block_id: str
    config: dict[str, Any]
    config_path: str | None = None
    is_composed: bool = False
    source_id: str
    source_kind: Literal["workspace", "session"]
    workspace_id: UUID
    branch_context_id: UUID | None = None
    workspace_name: str | None = None
    repo_url: str | None = None
    session_id: UUID | None = None
    repo_context_id: UUID | None = None


class LabInspector(BaseModel):
    """A discovered inspector annotated with its contributing repo surface.."""

    name: str
    display_name: str | None = None
    description: str | None = None
    version: str | None = None
    tags: list[str] = Field(default_factory=list)
    path: str | None = None
    url: str | None = None
    entry: str | None = None
    multi_run: bool | None = None
    build_status: str | None = None
    build_error: str | None = None
    build_log: str | None = None
    source_id: str
    source_kind: Literal["workspace", "session"]
    workspace_id: UUID
    branch_context_id: UUID | None = None
    workspace_name: str | None = None
    repo_url: str | None = None
    session_id: UUID | None = None
    repo_context_id: UUID | None = None


class LabDiscoveryIssue(BaseModel):
    """A discovery issue annotated with its contributing repo surface.."""

    stage: str | None = None
    severity: str | None = None
    message: str
    error: str | None = None
    error_code: str | None = None
    hint: str | None = None
    recoverable: bool = False
    language: str | None = None
    interpreter: str | None = None
    file: str | None = None
    function: str | None = None
    functions: list[str] | None = None
    traceback: str | None = None
    source_id: str
    source_kind: Literal["workspace", "session"]
    workspace_id: UUID
    branch_context_id: UUID | None = None
    workspace_name: str | None = None
    repo_url: str | None = None
    session_id: UUID | None = None
    repo_context_id: UUID | None = None

    def __getitem__(self, key: str) -> Any:
        return getattr(self, key)

    def get(self, key: str, default: Any = None) -> Any:
        return getattr(self, key, default)

    def __contains__(self, key: object) -> bool:
        return isinstance(key, str) and getattr(self, key, None) is not None


class LabBlockRegistry(BaseModel):
    """Merged block registry for a lab discovery response.."""

    version: str = "1"
    language: str = "python"
    workspace: str
    blocks: list[LabDiscoveredBlock] = Field(default_factory=list)


class LabDiscoveryResponse(BaseModel):
    """Merged discovery payload spanning all active repo surfaces in a lab.."""

    sources: list[DiscoverySource] = Field(default_factory=list)
    registry: LabBlockRegistry
    configs: list[WorkflowConfigEntry] = Field(default_factory=list)
    block_configs: list[BlockConfigEntry] = Field(default_factory=list)
    inspectors: list[LabInspector] = Field(default_factory=list)
    inspector_server_url: str | None = None
    errors: list[LabDiscoveryIssue] = Field(default_factory=list)


CompoundPredicate.model_rebuild()


NotPredicate.model_rebuild()
