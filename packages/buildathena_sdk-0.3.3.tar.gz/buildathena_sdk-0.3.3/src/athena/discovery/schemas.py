"""Discovery contract re-exports generated from canonical JSON Schema."""

from athena._generated_schemas import (
    BlockRegistry,
    DiscoveredBlock,
    InputSpec,
    OutputSpec,
    ScannerDiscoveryIssue,
)

__all__ = [
    "BlockRegistry",
    "DiscoveredBlock",
    "InputSpec",
    "OutputSpec",
    "ScannerDiscoveryIssue",
]
