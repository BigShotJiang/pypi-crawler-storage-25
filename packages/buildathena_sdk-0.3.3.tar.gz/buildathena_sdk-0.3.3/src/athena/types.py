"""Type definitions for Athena SDK.

This module re-exports shared types from local generated schemas and
SDK-owned modules.
"""

# Re-export shared types from local generated schemas
from athena._generated_schemas import (
    ArtifactRef,
    BlockConfig,
    BlockInput,
    BlockOutput,
    BlockSpec,
)
from athena.storage.protocol import StorageBackend

__all__ = [
    "ArtifactRef",
    "BlockConfig",
    "BlockInput",
    "BlockOutput",
    "BlockSpec",
    "RegisteredArtifact",
    "StorageBackend",
]
from athena.context import RegisteredArtifact
