import os
def eprint(text):
  print(text, end="")

# Uses hexcodes
# Example: printc("Hello", "ff0000", "00ff00")
def printc(text, font_color, bg_color):
  eprint(f"\x1b[38;2;{font_color}m")
  eprint(f"\x1b[48;2;{bg_color}m")
  eprint(text)

def set_color(color, bg_color):
  eprint(f"\x1b[38;2;{color}m")
  eprint(f"\x1b[48;2;{bg_color}m")
  
def reset_color():
  eprint("\x1b[0m")


def printf(text):
  # Print but keep the previous x pos
  print(text, end="")
  

def home():
  print("\x1b[H", end="")

def set_pos(x, y):
  eprint(f"\x1b[H") # home
  eprint(f"\x1b[{y}B") # y
  eprint(f"\x1b[{x}C") # x

def move(x, y):
  if x < 0:
    eprint(f"\x1b[{abs(x)}D") # x
  elif x > 0:
    eprint(f"\x1b[{x}C")

  if y < 0:
    eprint(f"\x1b[{abs(y)}A") # y
  elif y > 0:
    eprint(f"\x1b[{y}B")

def clear():
  eprint("\x1b[2J")

def full_clear():
  os.system('clear')

def clearln():
  eprint("\x1b[2K")



terminal = {
  "width": os.get_terminal_size().columns,
  "height": os.get_terminal_size().lines
}