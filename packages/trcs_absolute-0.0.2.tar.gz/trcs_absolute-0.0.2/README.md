# TRCS (Terminal relative coordinate system)
TRCS is a very simple Python module that can be used to easily control the terminal cursor with a simple XY coordinate system.

| Function | Usage |
|--|--|
| printc(text, font-color, bg-color) | Prints text with a given font and bg color. Must be in RGB format (`rr;gg;bb;`) |
| set_color(font, bg) | Sets a color to apply to everything until `reset` is ran. Must be in RGB format.
| reset_color | Resets `set_color`.
| home | Returns the cursor to 'home', or (0, 0)
| set_pos(x, y) | Sets the cursor's x and y position.
| move(x, y) | Moves the cursor relative to it's current position by a given x and y.
| clear | Clears the screen safely without using system clear. Won't cause flickering.
| full_clear | Forcefully clears the screen by using system clear. Will cause flickering.
| clearln | Clears the entire current line the cursor is on.

And if you need to access the terminals' dimensions, you can do that too
```
trcs.terminal['height']
trcs.terminal['width']
```
