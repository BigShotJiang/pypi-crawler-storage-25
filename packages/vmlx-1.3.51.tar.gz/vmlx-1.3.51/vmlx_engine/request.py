# SPDX-License-Identifier: Apache-2.0
"""
Request management for vmlx-engine continuous batching.

This module provides Request and RequestStatus classes adapted from vLLM's
request management system, simplified for MLX backend.
"""

import enum
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Set, Union

if TYPE_CHECKING:
    from .paged_cache import BlockTable


class RequestStatus(enum.IntEnum):
    """Status of a request in the scheduling system."""

    # Request is waiting to be scheduled
    WAITING = enum.auto()
    # Request is currently being processed (generating tokens)
    RUNNING = enum.auto()
    # Request was preempted and needs to be resumed
    PREEMPTED = enum.auto()
    # Request finished successfully (hit stop token)
    FINISHED_STOPPED = enum.auto()
    # Request finished due to max_tokens limit
    FINISHED_LENGTH_CAPPED = enum.auto()
    # Request was aborted by user
    FINISHED_ABORTED = enum.auto()

    @staticmethod
    def is_finished(status: "RequestStatus") -> bool:
        """Check if the status indicates a finished request."""
        return status > RequestStatus.PREEMPTED

    @staticmethod
    def get_finish_reason(status: "RequestStatus") -> Optional[str]:
        """Get the finish reason string for a finished status."""
        if status == RequestStatus.FINISHED_STOPPED:
            return "stop"
        elif status == RequestStatus.FINISHED_LENGTH_CAPPED:
            return "length"
        elif status == RequestStatus.FINISHED_ABORTED:
            return "abort"
        return None


@dataclass
class SamplingParams:
    """Sampling parameters for text generation."""

    max_tokens: int = 256
    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 0  # 0 means disabled
    min_p: float = 0.0
    repetition_penalty: float = 1.0
    stop: Optional[List[str]] = None
    stop_token_ids: Optional[List[int]] = None

    def __post_init__(self):
        if self.stop is None:
            self.stop = []
        if self.stop_token_ids is None:
            self.stop_token_ids = []


@dataclass
class Request:
    """
    Represents a single inference request in the scheduling system.

    Adapted from vLLM's Request class with simplifications for MLX backend.

    Attributes:
        request_id: Unique identifier for this request
        prompt: The input prompt (string or token ids)
        prompt_token_ids: Tokenized prompt
        sampling_params: Parameters for generation
        arrival_time: When the request was received
        status: Current status of the request
        num_prompt_tokens: Number of tokens in the prompt
        num_computed_tokens: Number of tokens processed so far
        output_token_ids: Generated token ids
        output_text: Generated text (decoded)
    """

    request_id: str
    prompt: Union[str, List[int]]
    sampling_params: SamplingParams
    arrival_time: float = field(default_factory=time.time)
    priority: int = 0  # Lower is higher priority

    # Set after tokenization
    prompt_token_ids: Optional[List[int]] = None
    num_prompt_tokens: int = 0

    # Generation state
    status: RequestStatus = RequestStatus.WAITING
    num_computed_tokens: int = 0
    output_token_ids: List[int] = field(default_factory=list)
    output_text: str = ""

    # For BatchGenerator integration
    batch_uid: Optional[int] = None  # UID assigned by BatchGenerator

    # Prefix cache fields
    prompt_cache: Optional[List[Any]] = None  # Cached KV state from prefix cache
    cached_tokens: int = 0  # Number of tokens retrieved from cache
    remaining_tokens: Optional[List[int]] = None  # Tokens still needing processing

    # Paged cache fields (for BlockAwarePrefixCache)
    block_table: Optional["BlockTable"] = None  # Block table for paged cache
    shared_prefix_blocks: int = 0  # Number of shared prefix blocks

    # Per-request stop tokens added to shared BatchGenerator (for cleanup on abort)
    _added_stop_tokens: Set[int] = field(default_factory=set)

    # Phase 3d (Agent 2): chat segment boundaries for cache_type-aware prefix
    # cache storage. Populated by API gateways during prompt rendering.
    # Each entry is `(token_index_inclusive, role)` where role ∈
    # {"system","user","assistant"}. Token index is the count of tokens
    # **up to and including** the boundary (not the index of the boundary
    # token itself). When None or empty, scheduler stores the whole prompt
    # under the default `cache_type="assistant"` (legacy behaviour).
    # Consumed by `Scheduler._store_cache_with_segments` and Agent 1's
    # `PrefixCacheManager.store_cache(cache_type=)`.
    # See `agentprogress/2/decisions.md` D-A2-008.
    _segment_boundaries: Optional[List[Any]] = None  # List[Tuple[int, str]]

    # Phase 3c (Agent 2): per-request SequenceStateMachine state.
    # Lazy-init by `Scheduler._advance_request_state_machine` on first emitted
    # token. Tracks reasoning/tool tag entry/exit at the token level.
    _sm_state: Optional[Any] = None

    # Phase 3c (Agent 2): set by `PrefixCacheManager.fetch_cache` to the
    # number of tokens recovered from the prefix cache. Consumed by the
    # state machine `advance_from(state, tokens)` to skip-scan the trusted
    # prefix without re-running tag matching on cached tokens.
    _cached_prefix_len: int = 0

    # Multimodal content (images, video) - raw inputs
    images: Optional[List[Any]] = None
    videos: Optional[List[Any]] = None

    # Processed multimodal inputs for VLM batching
    pixel_values: Optional[Any] = None  # Processed image tensors (mx.array)
    image_grid_thw: Optional[Any] = None  # Grid info for Qwen-VL models
    attention_mask: Optional[Any] = None  # Attention mask for multimodal input
    multimodal_kwargs: Optional[Dict[str, Any]] = None  # Model-specific kwargs
    is_multimodal: bool = False  # Flag indicating this is a multimodal request

    # Cache bypass flag — set by the server when the API request carried
    # cache_salt or skip_prefix_cache=true. When True, the scheduler skips
    # EVERY prefix cache layer (paged, memory-aware, legacy prefix, disk
    # L2, block disk, SSM companion, multimodal pixel_values) for BOTH
    # lookup and store. Used by benchmark clients that need guaranteed
    # fresh execution without pollution from prior requests.
    _bypass_prefix_cache: bool = False

    # Metadata
    finish_reason: Optional[str] = None

    @property
    def num_output_tokens(self) -> int:
        """Number of output tokens generated so far."""
        return len(self.output_token_ids)

    @property
    def num_tokens(self) -> int:
        """Total number of tokens (prompt + output)."""
        return self.num_prompt_tokens + self.num_output_tokens

    @property
    def max_tokens(self) -> int:
        """Maximum output tokens for this request."""
        return self.sampling_params.max_tokens

    def is_finished(self) -> bool:
        """Check if request has finished."""
        return RequestStatus.is_finished(self.status)

    def get_finish_reason(self) -> Optional[str]:
        """Get the finish reason if finished."""
        if self.finish_reason:
            return self.finish_reason
        return RequestStatus.get_finish_reason(self.status)

    def append_output_token(self, token_id: int) -> None:
        """Append a generated token to the output."""
        self.output_token_ids.append(token_id)
        self.num_computed_tokens += 1

    def set_finished(self, status: RequestStatus, reason: Optional[str] = None) -> None:
        """Mark the request as finished."""
        self.status = status
        self.finish_reason = reason or RequestStatus.get_finish_reason(status)

    def __lt__(self, other: "Request") -> bool:
        """Compare requests for priority queue ordering."""
        if self.priority != other.priority:
            return self.priority < other.priority
        return self.arrival_time < other.arrival_time

    def __hash__(self) -> int:
        return hash(self.request_id)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Request):
            return False
        return self.request_id == other.request_id


@dataclass
class RequestOutput:
    """
    Output for a single request after a generation step.

    This is returned by the engine to communicate results back to the API layer.
    """

    request_id: str
    # New tokens generated in this step
    new_token_ids: List[int] = field(default_factory=list)
    new_text: str = ""
    # Cumulative output
    output_token_ids: List[int] = field(default_factory=list)
    output_text: str = ""
    # Status
    finished: bool = False
    finish_reason: Optional[str] = None
    # Timing
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cached_tokens: int = 0
    cache_detail: str = ""  # e.g. "paged", "paged+ssm(23)", "memory", "prefix", "disk"

    @property
    def usage(self) -> Dict[str, int]:
        """Return usage statistics compatible with OpenAI API."""
        usage = {
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.prompt_tokens + self.completion_tokens,
        }
        if self.cached_tokens > 0:
            usage["prompt_tokens_details"] = {"cached_tokens": self.cached_tokens}
        return usage
