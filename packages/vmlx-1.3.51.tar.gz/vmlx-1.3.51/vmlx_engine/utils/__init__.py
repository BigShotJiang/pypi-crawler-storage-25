# SPDX-License-Identifier: Apache-2.0
"""Utility modules for vmlx-engine."""

from .tokenizer import load_model_with_fallback

__all__ = ["load_model_with_fallback"]
