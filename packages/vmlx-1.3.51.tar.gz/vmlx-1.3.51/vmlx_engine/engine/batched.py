# SPDX-License-Identifier: Apache-2.0
"""
Batched engine for continuous batching with multiple concurrent users.

This engine wraps AsyncEngineCore to provide continuous batching
for better throughput when serving multiple concurrent requests.

For MLLM models, this engine supports a hybrid approach:
- Text-only requests: Use BatchGenerator for continuous batching
- Multimodal requests (with images/videos): Fall back to MLLM.chat() for correct processing

This is necessary because BatchGenerator only supports token IDs, not pixel_values.
"""

import logging
from collections.abc import AsyncIterator
from typing import Any

from ..api.tool_calling import check_and_inject_fallback_tools, convert_tools_for_template
from ..api.utils import clean_output_text, extract_multimodal_content, is_mllm_model
from ..model_config_registry import get_model_config_registry
from .base import BaseEngine, GenerationOutput

logger = logging.getLogger(__name__)


class MLLMModelWrapper:
    """
    Wrapper for MLLM models to make them compatible with BatchGenerator.

    BatchGenerator expects model output to be subscriptable (logits array),
    but MLLM models return LanguageModelOutput objects. This wrapper extracts
    the logits from the output.

    Also handles Gemma 3's required pixel_values argument by injecting None
    for text-only requests.
    """

    def __init__(self, model, model_name: str = ""):
        self._model = model
        # Use registry to check if model needs pixel_values injection
        self._inject_pixel_values = False
        if model_name:
            registry = get_model_config_registry()
            hints = registry.get_architecture_hints(model_name)
            self._inject_pixel_values = hints.get("inject_pixel_values", False)
        if not self._inject_pixel_values:
            # Fallback: detect from model_type attribute
            _mt = str(getattr(model, "model_type", "")).lower()
            self._inject_pixel_values = (
                hasattr(model, "model_type")
                and _mt in ("gemma3", "gemma3n", "gemma4")
            )

    def __call__(self, *args, **kwargs):
        """Call the model and extract logits from LanguageModelOutput."""
        # Some models (e.g., Gemma 3, MedGemma) require pixel_values as a
        # positional arg. Inject pixel_values=None for text-only requests.
        if self._inject_pixel_values and "pixel_values" not in kwargs:
            kwargs["pixel_values"] = None

        output = self._model(*args, **kwargs)
        # If output has logits attribute, return just the logits
        if hasattr(output, "logits"):
            return output.logits
        return output

    def __getattr__(self, name):
        """Forward all other attributes to the wrapped model."""
        return getattr(self._model, name)


class BatchedEngine(BaseEngine):
    """
    Batched engine for continuous batching.

    This engine provides better throughput when serving multiple
    concurrent users by batching requests together.

    For MLLM (multimodal) models, this engine uses MLLMScheduler
    which handles images and videos alongside text generation.
    """

    def __init__(
        self,
        model_name: str,
        trust_remote_code: bool = True,
        scheduler_config: Any | None = None,
        stream_interval: int = 1,
        force_mllm: bool = False,
    ):
        """
        Initialize the batched engine.

        Args:
            model_name: HuggingFace model name or local path
            trust_remote_code: Whether to trust remote code
            scheduler_config: Optional scheduler configuration
            stream_interval: Tokens to batch before streaming (1=every token)
            force_mllm: Force loading as MLLM even if not auto-detected
        """
        self._model_name = model_name
        self._trust_remote_code = trust_remote_code
        self._scheduler_config = scheduler_config
        self._stream_interval = stream_interval
        self._is_mllm = is_mllm_model(model_name, force_mllm=force_mllm)

        self._model = None
        self._processor = None  # For MLLM
        self._tokenizer = None  # For LLM
        self._engine = None  # AsyncEngineCore for LLM
        self._mllm_scheduler = None  # MLLMScheduler for MLLM
        self._mllm_instance = None  # MLXMultimodalLM instance
        self._loaded = False

    @property
    def model_name(self) -> str:
        """Get the model name."""
        return self._model_name

    @property
    def is_mllm(self) -> bool:
        """Check if this is a multimodal model."""
        return self._is_mllm

    @property
    def tokenizer(self) -> Any:
        """Get the tokenizer."""
        if self._is_mllm and self._processor:
            return getattr(self._processor, "tokenizer", self._processor)
        return self._tokenizer

    async def start(self) -> None:
        """Start the engine (load model if not loaded)."""
        if self._loaded:
            return

        if self._is_mllm:
            await self._start_mllm()
        else:
            await self._start_llm()

        self._loaded = True
        logger.info(f"BatchedEngine loaded: {self._model_name} (mllm={self._is_mllm})")

    async def _start_mllm(self) -> None:
        """Start the MLLM engine with MLLMScheduler (continuous batching).

        Forwards ALL cache settings from the user's SchedulerConfig to
        MLLMSchedulerConfig for full LLM/MLLM cache parity. This includes
        paged cache, memory-aware cache, legacy prefix cache, disk L2,
        block disk store, and KV cache quantization settings.
        """
        from ..mllm_scheduler import MLLMScheduler, MLLMSchedulerConfig
        from ..models.mllm import MLXMultimodalLM

        # Load the MLLM model
        self._mllm_instance = MLXMultimodalLM(
            self._model_name,
            trust_remote_code=self._trust_remote_code,
        )
        self._mllm_instance.load()

        self._model = self._mllm_instance.model
        self._processor = self._mllm_instance.processor

        # Create MLLM scheduler config with batch generator support
        if self._scheduler_config and hasattr(self._scheduler_config, "max_num_seqs"):
            max_num_seqs = self._scheduler_config.max_num_seqs
        else:
            max_num_seqs = 16  # Default for continuous batching

        # Get batch sizes from config if available
        prefill_batch_size = getattr(self._scheduler_config, "prefill_batch_size", 4)
        completion_batch_size = getattr(
            self._scheduler_config, "completion_batch_size", 16
        )

        mllm_config = MLLMSchedulerConfig(
            max_num_seqs=max_num_seqs,
            prefill_batch_size=prefill_batch_size,
            completion_batch_size=completion_batch_size,
            prefill_step_size=getattr(self._scheduler_config, "prefill_step_size", 1024),
            enable_vision_cache=True,
            vision_cache_size=16,
            # Propagate cache settings from user's SchedulerConfig
            enable_prefix_cache=getattr(self._scheduler_config, "enable_prefix_cache", True),
            use_paged_cache=getattr(self._scheduler_config, "use_paged_cache", True),
            paged_cache_block_size=getattr(self._scheduler_config, "paged_cache_block_size", 64),
            max_cache_blocks=getattr(self._scheduler_config, "max_cache_blocks", 1000),
            kv_cache_quantization=getattr(self._scheduler_config, "kv_cache_quantization", "none"),
            kv_cache_group_size=getattr(self._scheduler_config, "kv_cache_group_size", 64),
            # Memory-aware cache settings
            use_memory_aware_cache=getattr(self._scheduler_config, "use_memory_aware_cache", True),
            cache_memory_mb=getattr(self._scheduler_config, "cache_memory_mb", None),
            cache_memory_percent=getattr(self._scheduler_config, "cache_memory_percent", 0.20),
            cache_ttl_minutes=getattr(self._scheduler_config, "cache_ttl_minutes", 0),
            # Legacy prefix cache
            prefix_cache_size=getattr(self._scheduler_config, "prefix_cache_size", 100),
            # Disk cache L2
            enable_disk_cache=getattr(self._scheduler_config, "enable_disk_cache", False),
            disk_cache_dir=getattr(self._scheduler_config, "disk_cache_dir", None),
            disk_cache_max_gb=getattr(self._scheduler_config, "disk_cache_max_gb", 10.0),
            # Block-level disk cache L2
            enable_block_disk_cache=getattr(self._scheduler_config, "enable_block_disk_cache", False),
            block_disk_cache_dir=getattr(self._scheduler_config, "block_disk_cache_dir", None),
            block_disk_cache_max_gb=getattr(self._scheduler_config, "block_disk_cache_max_gb", 10.0),
            # Model path for disk cache scoping
            model_path=getattr(self._scheduler_config, "model_path", None) or self._model_name,
            # Hybrid SSM state cache size
            ssm_state_cache_size=getattr(self._scheduler_config, "ssm_state_cache_size", 50),
        )

        # Create and start MLLM scheduler
        self._mllm_scheduler = MLLMScheduler(
            model=self._model,
            processor=self._processor,
            config=mllm_config,
        )
        await self._mllm_scheduler.start()

        logger.info(
            f"MLLM Scheduler started with continuous batching: "
            f"max_num_seqs={max_num_seqs}, prefill_batch={prefill_batch_size}, "
            f"completion_batch={completion_batch_size}"
        )

    async def _start_llm(self) -> None:
        """Start the LLM engine with AsyncEngineCore."""
        from ..engine_core import AsyncEngineCore, EngineConfig
        from ..scheduler import SchedulerConfig
        from ..utils.tokenizer import load_model_with_fallback

        # Build tokenizer config with registry-based EOS overrides
        tokenizer_config = {"trust_remote_code": self._trust_remote_code}

        registry = get_model_config_registry()
        model_config = registry.lookup(self._model_name)
        if model_config.eos_tokens:
            tokenizer_config["eos_token"] = model_config.eos_tokens[0]

        self._model, self._tokenizer = load_model_with_fallback(
            self._model_name,
            tokenizer_config=tokenizer_config,
        )

        # Wrap model so BatchGenerator gets raw logits tensors.
        # Some models (nemotron_h, etc.) return LanguageModelOutput objects
        # instead of plain tensors. MLLMModelWrapper extracts .logits when
        # present and is a no-op passthrough for models returning tensors.
        self._model = MLLMModelWrapper(self._model, model_name=self._model_name)

        # Create engine config
        scheduler_config = self._scheduler_config or SchedulerConfig()
        engine_config = EngineConfig(
            model_name=self._model_name,
            scheduler_config=scheduler_config,
            stream_interval=self._stream_interval,
        )

        # Create async engine
        self._engine = AsyncEngineCore(
            model=self._model,
            tokenizer=self._tokenizer,
            config=engine_config,
        )

        await self._engine.engine.start()

    async def stop(self) -> None:
        """Stop the engine and cleanup resources."""
        if self._mllm_scheduler:
            await self._mllm_scheduler.stop()
            self._mllm_scheduler = None

        if self._engine:
            await self._engine.stop()
            # close() handles scheduler.shutdown() + deep_reset() + collector cleanup.
            # stop() already called scheduler.shutdown(), but close() is idempotent
            # and handles additional cleanup (model ownership, deep_reset).
            self._engine.engine.close()
            self._engine = None

        self._model = None
        self._tokenizer = None
        self._processor = None
        self._mllm_instance = None
        self._loaded = False
        logger.info("BatchedEngine stopped")

    def _inject_fallback_chat_template(self, tokenizer) -> str | None:
        """Best-effort attach a chat_template to a tokenizer that's missing one.

        Why this exists (GH issue #66 part 2): mlx-community quants ship the
        chat template as a SEPARATE ``chat_template.jinja`` file alongside
        the tokenizer instead of baking it into ``tokenizer_config.json``.
        Stock HF transformers raises ``tokenizer.chat_template is not set``
        on first use. Falling back here lets the user run those quants
        without re-downloading a JANG variant just to get a working prompt.

        Resolution order:
          1. ``chat_template.jinja`` in the model directory (most common)
          2. ``chat_template.json`` (alternate format)
          3. The model_configs registry's ``chat_template_custom`` field
             (Harmony fallback for GLM/GPT-OSS-style models)

        Returns the source description (e.g. ``"chat_template.jinja"``) on
        success, ``None`` if no fallback was found. Mutates ``tokenizer``
        in place by setting ``tokenizer.chat_template``.
        """
        if not hasattr(tokenizer, "chat_template"):
            return None
        try:
            from pathlib import Path
            model_dir = Path(self._model_name) if self._model_name else None
            if model_dir and model_dir.is_dir():
                # 1. chat_template.jinja
                jinja_path = model_dir / "chat_template.jinja"
                if jinja_path.is_file():
                    tokenizer.chat_template = jinja_path.read_text(encoding="utf-8")
                    return str(jinja_path.name)
                # 2. chat_template.json
                json_path = model_dir / "chat_template.json"
                if json_path.is_file():
                    import json as _json
                    data = _json.loads(json_path.read_text(encoding="utf-8"))
                    tpl = data.get("chat_template") if isinstance(data, dict) else None
                    if isinstance(tpl, str):
                        tokenizer.chat_template = tpl
                        return str(json_path.name)
        except Exception as e:
            logger.debug(f"chat_template file probe failed: {e}")

        # 3. Registry fallback by family
        try:
            from ..model_config_registry import get_model_config_registry
            mc = get_model_config_registry().lookup(self._model_name or "")
            tpl = getattr(mc, "chat_template_custom", None)
            if isinstance(tpl, str) and tpl.strip():
                tokenizer.chat_template = tpl
                return f"registry:{mc.family_name}"
        except Exception as e:
            logger.debug(f"registry chat_template lookup failed: {e}")

        return None

    def _compute_gen_prompt_len(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict] | None,
        num_images: int,
        enable_thinking: bool,
        extra_template_kwargs: dict | None,
        prompt_with_gen: str,
    ) -> int:
        """Compute the number of tokens added by add_generation_prompt=True.

        This is used by the prefix cache to strip generation prompt tokens
        from the cache key, preventing 100% cache misses in multi-turn
        conversations for thinking models (where the generation prompt
        includes <think> which differs each turn).

        Args:
            messages: Chat messages
            tools: Tool definitions
            num_images: Number of images
            enable_thinking: Whether thinking is enabled
            extra_template_kwargs: Extra template kwargs
            prompt_with_gen: The already-rendered prompt WITH generation prompt

        Returns:
            Number of tokens in the generation prompt suffix
        """
        try:
            prompt_without_gen = self._apply_chat_template(
                messages,
                tools,
                num_images=num_images,
                enable_thinking=enable_thinking,
                extra_template_kwargs=extra_template_kwargs,
                skip_generation_prompt=True,
            )
            tokenizer = self._tokenizer or self._processor
            if tokenizer is None:
                return 0

            # Use the tokenizer's encode method
            if hasattr(tokenizer, "encode"):
                enc = tokenizer.encode
            elif hasattr(tokenizer, "tokenizer") and hasattr(tokenizer.tokenizer, "encode"):
                enc = tokenizer.tokenizer.encode
            else:
                return 0

            tokens_with = enc(prompt_with_gen)
            tokens_without = enc(prompt_without_gen)
            gen_len = len(tokens_with) - len(tokens_without)
            if gen_len > 0:
                logger.debug(f"Gen prompt len: {gen_len} tokens")
            return max(gen_len, 0)
        except Exception as e:
            logger.debug(f"Failed to compute gen_prompt_len: {e}")
            return 0

    def _compute_segment_boundaries(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict] | None,
        num_images: int,
        enable_thinking: bool,
        extra_template_kwargs: dict | None,
    ) -> list[tuple[int, str]]:
        """Compute (token_offset, role) boundaries for the chat history.

        Phase 5 audit fix (F11, 2026-04-08): the LLM scheduler reads
        ``request._segment_boundaries`` to drive Agent 1's PrefixCacheManager
        cache_type-priority LRU (system pinned > user > assistant). Without
        this helper, no API gateway populates the field, and every request
        gets stored under the default ``cache_type='assistant'`` — defeating
        cross-session prefix sharing for system prompts entirely.

        We compute boundaries by re-rendering the chat template incrementally
        for each prefix of messages (without ``add_generation_prompt``) and
        tokenizing the result. The token-count delta between successive
        renders gives each segment's end offset.

        Returns:
            List of ``(token_offset, role)`` tuples in increasing offset
            order. ``role`` is the role of the message ending at that
            offset (e.g. ``"system"`` after the system message).
            Empty list on any failure — the caller falls back to
            single-store under ``cache_type='assistant'``.
        """
        # Skip the work for trivial conversations: 1 message has no boundary,
        # 0 messages is degenerate.
        if not messages or len(messages) < 2:
            return []
        # Skip if no system or non-uniform structure — only valuable when at
        # least one message can be pinned with a role > "assistant" priority.
        roles = {m.get("role") for m in messages}
        if not (roles & {"system", "user"}):
            return []
        try:
            tokenizer = self._tokenizer or self._processor
            if tokenizer is None:
                return []
            if hasattr(tokenizer, "encode"):
                enc = tokenizer.encode
            elif hasattr(tokenizer, "tokenizer") and hasattr(tokenizer.tokenizer, "encode"):
                enc = tokenizer.tokenizer.encode
            else:
                return []

            boundaries: list[tuple[int, str]] = []
            prev_count = 0
            for i in range(1, len(messages) + 1):
                try:
                    rendered = self._apply_chat_template(
                        messages[:i],
                        tools if i == len(messages) else None,
                        num_images=num_images if i == len(messages) else 0,
                        enable_thinking=enable_thinking,
                        extra_template_kwargs=extra_template_kwargs,
                        skip_generation_prompt=True,
                    )
                    cur_count = len(enc(rendered))
                except Exception:
                    # Re-rendering can fail for partial histories on some
                    # templates (e.g. assistant-prefix-only). Skip this
                    # boundary, keep going.
                    continue
                if cur_count <= prev_count:
                    continue
                role = messages[i - 1].get("role") or "assistant"
                # Normalise unknown roles to "assistant" so they hit the
                # default eviction priority bucket.
                if role not in ("system", "user", "assistant"):
                    role = "assistant"
                boundaries.append((cur_count, role))
                prev_count = cur_count
            return boundaries
        except Exception as e:
            logger.debug(f"Failed to compute segment boundaries: {e}")
            return []

    def _apply_chat_template(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict] | None = None,
        num_images: int = 0,
        enable_thinking: bool = True,
        extra_template_kwargs: dict | None = None,
        skip_generation_prompt: bool = False,
    ) -> str:
        """Apply chat template to messages."""
        tokenizer = self.tokenizer

        # Count non-system messages to detect multi-turn conversations
        non_system_msgs = sum(1 for m in messages if m.get("role") != "system")

        if self._is_mllm and self._processor and not tools and num_images > 0:
            # Use mlx_vlm for MLLM when actual images are present (any turn count).
            # Text-only VL conversations still use the standard tokenizer path,
            # ensuring consistent cache keys across text-only turns.
            try:
                from mlx_vlm.prompt_utils import apply_chat_template
                from mlx_vlm.utils import load_config

                config = getattr(self._model, "config", None)
                if config is None:
                    config = load_config(self._model_name)

                # Two-step pipeline:
                # 1. Build messages with image tokens via mlx_vlm (return_messages=True)
                # 2. Apply template via processor with enable_thinking support
                built_messages = apply_chat_template(
                    self._processor,
                    config,
                    messages,
                    num_images=num_images,
                    return_messages=True,
                )

                # Apply template with enable_thinking via the processor directly.
                # mlx_vlm's get_chat_template doesn't forward enable_thinking,
                # causing thinking models to always use thinking-OFF format.
                tpl_kwargs = {
                    "tokenize": False,
                    "add_generation_prompt": True,
                }
                if enable_thinking is not None:
                    tpl_kwargs["enable_thinking"] = enable_thinking
                # Merge extra chat_template_kwargs (e.g. thinking_budget, reasoning_effort)
                if extra_template_kwargs:
                    tpl_kwargs.update(extra_template_kwargs)
                try:
                    prompt = self._processor.apply_chat_template(
                        built_messages, **tpl_kwargs
                    )
                except TypeError:
                    # Processor doesn't support enable_thinking — fall back
                    tpl_kwargs.pop("enable_thinking", None)
                    prompt = self._processor.apply_chat_template(
                        built_messages, **tpl_kwargs
                    )
                    if enable_thinking is False and not tools:
                        last_think = prompt.rfind("<think>")
                        if last_think >= 0:
                            after = prompt[last_think + 7:]
                            if "</think>" not in after:
                                prompt = prompt[:last_think + 7] + "</think>\n"
                        elif "<think>" not in prompt:
                            prompt = prompt.rstrip() + "\n<think>\n</think>\n"
                return prompt
            except Exception as e:
                logger.warning(f"Failed to apply MLLM chat template: {e}")
                # Fall through to standard template

        if hasattr(tokenizer, "apply_chat_template"):
            # Ensure tool_calls arguments are dicts, not JSON strings.
            # Chat templates (Qwen3, Llama, etc.) call .items() on arguments.
            for msg in messages:
                for tc in msg.get("tool_calls") or []:
                    fn = tc.get("function", {})
                    args = fn.get("arguments")
                    if isinstance(args, str):
                        try:
                            import json
                            fn["arguments"] = json.loads(args)
                        except (json.JSONDecodeError, TypeError):
                            fn["arguments"] = {}

            template_kwargs = {
                "tokenize": False,
                "add_generation_prompt": not skip_generation_prompt,
            }
            if enable_thinking is not None:
                template_kwargs["enable_thinking"] = enable_thinking
            if tools:
                template_kwargs["tools"] = tools
            # Merge extra chat_template_kwargs (e.g. thinking_budget).
            # Strip reserved keys (Concern #14): tokenize and
            # add_generation_prompt are managed by us; client overrides change
            # the return type and break downstream code.
            if extra_template_kwargs:
                template_kwargs.update({
                    k: v for k, v in extra_template_kwargs.items()
                    if k not in ("tokenize", "add_generation_prompt")
                })

            prompt = None
            try:
                prompt = tokenizer.apply_chat_template(messages, **template_kwargs)
            except Exception as template_err:
                # GH#66 part 2 — mlx-community quants (e.g. mlx-community/
                # gemma-4-31b-8bit) often DON'T bake `chat_template` into
                # tokenizer_config.json, so HF transformers raises
                # `ValueError: tokenizer.chat_template is not set`. The
                # template is usually shipped as a separate file in the
                # model dir (`chat_template.jinja` or `chat_template.json`).
                # Load it once, attach it to the tokenizer, and retry —
                # avoids forcing the user to re-download a JANG variant
                # just to get a working prompt.
                _err_msg = str(template_err)
                if "chat_template is not set" in _err_msg or "no template argument" in _err_msg:
                    _injected = self._inject_fallback_chat_template(tokenizer)
                    if _injected:
                        try:
                            prompt = tokenizer.apply_chat_template(messages, **template_kwargs)
                            logger.info(
                                f"Chat template injected from {_injected} for {self._model_name}"
                            )
                        except Exception as retry_err:
                            template_err = retry_err
                            prompt = None

                if prompt is None:
                    # Progressively strip non-essential kwargs to preserve tools/thinking
                    # when only extra kwargs (e.g. thinking_budget) cause failures.
                    # Strip order: extra kwargs first, then tools, then enable_thinking.
                    strip_order = [
                        k for k in template_kwargs
                        if k not in ("tokenize", "add_generation_prompt")
                    ]
                    # Reverse so we strip least important first (extra kwargs added last)
                    for key in reversed(strip_order):
                        del template_kwargs[key]
                        try:
                            prompt = tokenizer.apply_chat_template(messages, **template_kwargs)
                            stripped = [k for k in strip_order if k not in template_kwargs]
                            logger.warning(
                                f"Chat template succeeded after stripping: {stripped} "
                                f"(original error: {template_err})"
                            )
                            break
                        except Exception:
                            continue
                if prompt is None:
                    # All kwargs stripped and still failing — last resort (will raise)
                    prompt = tokenizer.apply_chat_template(messages, **template_kwargs)

            prompt = check_and_inject_fallback_tools(
                prompt, messages, tools, tokenizer, template_kwargs
            )

            # When thinking is OFF and no tools in request, close any unclosed
            # <think> in the prompt. This tells the model "thinking already
            # happened" and it should produce content directly.
            # CRITICAL: skip this when tools are present — the model needs to
            # think in order to decide whether to call a tool. The <think></think>
            # injection suppresses not just thinking but also tool-call decision
            # making, causing the model to produce a direct (often wrong) answer
            # instead of calling the tool. Server-side reasoning suppression
            # (heartbeats) handles the UX when tools are active.
            if enable_thinking is False and not tools:
                last_think = prompt.rfind("<think>")
                if last_think >= 0:
                    after_think = prompt[last_think + 7:]
                    if "</think>" not in after_think:
                        prompt = prompt[:last_think + 7] + "</think>\n"
                elif "<think>" not in prompt:
                    prompt = prompt.rstrip() + "\n<think>\n</think>\n"
            return prompt
        else:
            prompt = "\n".join(f"{m['role']}: {m['content']}" for m in messages)
            return prompt + "\nassistant:"

    async def generate(
        self,
        prompt: str,
        max_tokens: int = 256,
        temperature: float = 0.7,
        top_p: float = 0.9,
        stop: list[str] | None = None,
        images: list[str] | None = None,
        videos: list[str] | None = None,
        **kwargs,
    ) -> GenerationOutput:
        """
        Generate a complete response (non-streaming).

        Args:
            prompt: Input text
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            top_p: Top-p sampling
            stop: Stop sequences
            images: Optional image URLs/paths (for MLLM)
            videos: Optional video URLs/paths (for MLLM)
            **kwargs: Additional model-specific parameters

        Returns:
            GenerationOutput with complete text
        """
        if not self._loaded:
            await self.start()

        # Cache-bypass flag from the server gateway layer. Forwarded by every
        # chat/completion handler when the API request carried cache_salt or
        # skip_prefix_cache=true. Engine pops it out of kwargs so it doesn't
        # leak downstream and attaches it to the internal Request object so
        # the scheduler can gate EVERY lookup and store site on it.
        bypass_prefix_cache = bool(kwargs.pop("_bypass_prefix_cache", False))

        if self._is_mllm and self._mllm_scheduler:
            # Use MLLM scheduler for all requests (text-only and multimodal)
            # MLLM models only initialize _mllm_scheduler, not _engine
            output = await self._mllm_scheduler.generate(
                prompt=prompt,
                images=images,
                videos=videos,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
                stop=stop,
                top_k=kwargs.get("top_k", 0),
                min_p=kwargs.get("min_p", 0.0),
                repetition_penalty=kwargs.get("repetition_penalty", 1.0),
                video_fps=kwargs.get("video_fps"),
                video_max_frames=kwargs.get("video_max_frames"),
                num_messages=kwargs.get("num_messages", 1),
                gen_prompt_len=kwargs.get("gen_prompt_len", 0),
                bypass_prefix_cache=bypass_prefix_cache,
            )

            return GenerationOutput(
                text=clean_output_text(output.output_text),
                prompt_tokens=output.prompt_tokens,
                completion_tokens=output.completion_tokens,
                cached_tokens=getattr(output, "cached_tokens", 0),
                finish_reason=output.finish_reason,
            )

        # Use LLM engine for text-only
        from ..request import SamplingParams

        gen_prompt_len = kwargs.pop("gen_prompt_len", 0)
        segment_boundaries = kwargs.pop("segment_boundaries", None)

        sampling_params = SamplingParams(
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            top_k=kwargs.get("top_k", 0),
            min_p=kwargs.get("min_p", 0.0),
            repetition_penalty=kwargs.get("repetition_penalty", 1.0),
            stop=stop or [],
        )

        output = await self._engine.generate(
            prompt=prompt,
            sampling_params=sampling_params,
            gen_prompt_len=gen_prompt_len,
            num_messages=kwargs.get("num_messages", 1),
            segment_boundaries=segment_boundaries,
            bypass_prefix_cache=bypass_prefix_cache,
        )

        text = clean_output_text(output.output_text)

        return GenerationOutput(
            text=text,
            prompt_tokens=output.prompt_tokens,
            completion_tokens=output.completion_tokens,
            cached_tokens=getattr(output, "cached_tokens", 0),
            finish_reason=output.finish_reason,
        )

    async def stream_generate(
        self,
        prompt: str,
        max_tokens: int = 256,
        temperature: float = 0.7,
        top_p: float = 0.9,
        stop: list[str] | None = None,
        images: list[str] | None = None,
        videos: list[str] | None = None,
        request_id: str | None = None,
        **kwargs,
    ) -> AsyncIterator[GenerationOutput]:
        """
        Stream generation token by token.

        Args:
            prompt: Input text
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            top_p: Top-p sampling
            stop: Stop sequences
            images: Optional image URLs/paths (for MLLM)
            videos: Optional video URLs/paths (for MLLM)
            request_id: Optional custom request ID for cancellation support
            **kwargs: Additional model-specific parameters

        Yields:
            GenerationOutput with incremental text
        """
        if not self._loaded:
            await self.start()

        # Per-request cache bypass (forwarded from server gateway — see
        # BatchedEngine.chat for details). Pop out of kwargs so it doesn't
        # collide with downstream positional arguments.
        bypass_prefix_cache = bool(kwargs.pop("_bypass_prefix_cache", False))

        if self._is_mllm and self._mllm_scheduler:
            # Use MLLM scheduler for all requests (text-only and multimodal)
            # MLLM models only initialize _mllm_scheduler, not _engine
            request_id = await self._mllm_scheduler.add_request_async(
                prompt=prompt,
                images=images,
                videos=videos,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
                request_id=request_id,
                stop=stop,
                top_k=kwargs.get("top_k", 0),
                min_p=kwargs.get("min_p", 0.0),
                repetition_penalty=kwargs.get("repetition_penalty", 1.0),
                video_fps=kwargs.get("video_fps"),
                video_max_frames=kwargs.get("video_max_frames"),
                num_messages=kwargs.get("num_messages", 1),
                gen_prompt_len=kwargs.get("gen_prompt_len", 0),
                bypass_prefix_cache=bypass_prefix_cache,
            )

            async for output in self._mllm_scheduler.stream_outputs(request_id):
                yield GenerationOutput(
                    text=clean_output_text(output.output_text),
                    new_text=output.new_text,
                    prompt_tokens=output.prompt_tokens,
                    completion_tokens=output.completion_tokens,
                    cached_tokens=getattr(output, "cached_tokens", 0),
                    finished=output.finished,
                    finish_reason=output.finish_reason,
                )
            return

        # Use LLM engine for text-only
        from ..request import SamplingParams

        gen_prompt_len = kwargs.pop("gen_prompt_len", 0)
        segment_boundaries = kwargs.pop("segment_boundaries", None)

        sampling_params = SamplingParams(
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            top_k=kwargs.get("top_k", 0),
            min_p=kwargs.get("min_p", 0.0),
            repetition_penalty=kwargs.get("repetition_penalty", 1.0),
            stop=stop or [],
        )

        request_id = await self._engine.add_request(
            prompt=prompt,
            sampling_params=sampling_params,
            request_id=request_id,
            gen_prompt_len=gen_prompt_len,
            num_messages=kwargs.get("num_messages", 1),
            segment_boundaries=segment_boundaries,
            bypass_prefix_cache=bypass_prefix_cache,
        )

        async for output in self._engine.stream_outputs(request_id):
            text = clean_output_text(output.output_text)

            yield GenerationOutput(
                text=text,
                new_text=output.new_text,
                prompt_tokens=output.prompt_tokens,
                completion_tokens=output.completion_tokens,
                cached_tokens=getattr(output, "cached_tokens", 0),
                finished=output.finished,
                finish_reason=output.finish_reason,
            )

    async def chat(
        self,
        messages: list[dict[str, Any]],
        max_tokens: int = 256,
        temperature: float = 0.7,
        top_p: float = 0.9,
        tools: list[dict] | None = None,
        images: list[str] | None = None,
        videos: list[str] | None = None,
        **kwargs,
    ) -> GenerationOutput:
        """
        Chat completion (non-streaming).

        For MLLM models with images/videos, uses the native MLLM.chat() method
        which properly processes multimodal content through the vision encoder.
        For text-only requests, uses BatchGenerator for continuous batching.

        Args:
            messages: List of chat messages (OpenAI format)
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            top_p: Top-p sampling
            tools: Optional tool definitions
            images: Optional image URLs/paths
            videos: Optional video URLs/paths
            **kwargs: Additional model-specific parameters

        Returns:
            GenerationOutput with assistant response
        """
        if not self._loaded:
            await self.start()

        # Extract images/videos from messages (OpenAI multimodal format)
        # Note: We only use extracted media here, messages are already processed by server
        _, extracted_images, extracted_videos = extract_multimodal_content(messages)
        all_images = (images or []) + extracted_images
        all_videos = (videos or []) + extracted_videos

        # Convert tools for template
        template_tools = convert_tools_for_template(tools) if tools else None

        # Apply chat template — pop reasoning_effort and merge into template kwargs
        # so it reaches tokenizer.apply_chat_template() for models that support it
        reasoning_effort = kwargs.pop("reasoning_effort", None)
        extra_tpl = kwargs.pop("chat_template_kwargs", None)
        prompt_suffix = kwargs.pop("prompt_suffix", None)
        skip_gen_prompt = kwargs.pop("skip_generation_prompt", False)
        if reasoning_effort:
            extra_tpl = extra_tpl or {}
            extra_tpl["reasoning_effort"] = reasoning_effort

        thinking_enabled = kwargs.pop("enable_thinking", True)

        prompt = self._apply_chat_template(
            messages,
            template_tools,
            num_images=len(all_images),
            enable_thinking=thinking_enabled,
            extra_template_kwargs=extra_tpl,
            skip_generation_prompt=skip_gen_prompt,
        )

        # Compute gen_prompt_len for prefix cache key stripping.
        # Enables multi-turn prefix cache hits for thinking models by
        # stripping generation prompt tokens (e.g., <|im_start|>assistant\n<think>\n)
        # from the cache key. Works for both LLM and MLLM paths.
        gen_prompt_len = 0
        if not skip_gen_prompt:
            gen_prompt_len = self._compute_gen_prompt_len(
                messages, template_tools, len(all_images),
                thinking_enabled, extra_tpl, prompt,
            )

        # Phase 5 audit fix (F11, 2026-04-08): compute per-segment boundaries
        # so the LLM scheduler can store cache entries with the correct
        # cache_type (system / user / assistant). This is what activates
        # Agent 1's PrefixCacheManager priority LRU breakthrough — without
        # it, every entry was stored as 'assistant' and system prompts could
        # not be pinned across sessions.
        segment_boundaries = self._compute_segment_boundaries(
            messages, template_tools, len(all_images),
            thinking_enabled, extra_tpl,
        )

        # Append prompt suffix (e.g. Harmony analysis prefix for GPT-OSS)
        if prompt_suffix:
            prompt += prompt_suffix

        # Pass message count for cache skip heuristic (Phase 2 optimization).
        # Single-turn API requests (1-2 messages: system+user) with short output
        # skip cache storage to reduce per-request overhead.
        kwargs["num_messages"] = len(messages)
        if segment_boundaries:
            kwargs["segment_boundaries"] = segment_boundaries

        return await self.generate(
            prompt=prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            images=all_images if all_images else None,
            videos=all_videos if all_videos else None,
            gen_prompt_len=gen_prompt_len,
            **kwargs,
        )

    async def stream_chat(
        self,
        messages: list[dict[str, Any]],
        max_tokens: int = 256,
        temperature: float = 0.7,
        top_p: float = 0.9,
        tools: list[dict] | None = None,
        images: list[str] | None = None,
        videos: list[str] | None = None,
        request_id: str | None = None,
        **kwargs,
    ) -> AsyncIterator[GenerationOutput]:
        """
        Stream chat completion token by token.

        For MLLM models with images/videos, uses the native MLLM.stream_chat() method
        which properly processes multimodal content through the vision encoder.
        For text-only requests, uses BatchGenerator for continuous batching.

        Args:
            messages: List of chat messages (OpenAI format)
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            top_p: Top-p sampling
            tools: Optional tool definitions
            images: Optional image URLs/paths
            videos: Optional video URLs/paths
            request_id: Optional custom request ID for cancellation support
            **kwargs: Additional model-specific parameters

        Yields:
            GenerationOutput with incremental text
        """
        if not self._loaded:
            await self.start()

        # Extract images/videos from messages (OpenAI multimodal format)
        # Note: We only use extracted media here, messages are already processed by server
        _, extracted_images, extracted_videos = extract_multimodal_content(messages)
        all_images = (images or []) + extracted_images
        all_videos = (videos or []) + extracted_videos

        # Convert tools for template
        template_tools = convert_tools_for_template(tools) if tools else None

        # Apply chat template — pop reasoning_effort and merge into template kwargs
        # so it reaches tokenizer.apply_chat_template() for models that support it
        reasoning_effort = kwargs.pop("reasoning_effort", None)
        extra_tpl = kwargs.pop("chat_template_kwargs", None)
        prompt_suffix = kwargs.pop("prompt_suffix", None)
        skip_gen_prompt = kwargs.pop("skip_generation_prompt", False)
        if reasoning_effort:
            extra_tpl = extra_tpl or {}
            extra_tpl["reasoning_effort"] = reasoning_effort

        thinking_enabled = kwargs.pop("enable_thinking", True)

        prompt = self._apply_chat_template(
            messages,
            template_tools,
            num_images=len(all_images),
            enable_thinking=thinking_enabled,
            extra_template_kwargs=extra_tpl,
            skip_generation_prompt=skip_gen_prompt,
        )

        # Compute gen_prompt_len for prefix cache key stripping.
        # Enables multi-turn prefix cache hits for thinking models by
        # stripping generation prompt tokens (e.g., <|im_start|>assistant\n<think>\n)
        # from the cache key. Works for both LLM and MLLM paths.
        gen_prompt_len = 0
        if not skip_gen_prompt:
            gen_prompt_len = self._compute_gen_prompt_len(
                messages, template_tools, len(all_images),
                thinking_enabled, extra_tpl, prompt,
            )

        # F11 (audit 2026-04-08): per-segment boundaries for cache_type LRU.
        # Mirrors the non-streaming chat() path so the priority eviction
        # breakthrough fires for streaming requests too.
        segment_boundaries = self._compute_segment_boundaries(
            messages, template_tools, len(all_images),
            thinking_enabled, extra_tpl,
        )

        # Append prompt suffix (e.g. Harmony analysis prefix for GPT-OSS)
        if prompt_suffix:
            prompt += prompt_suffix

        # Pass message count for cache skip heuristic (Phase 2 optimization).
        kwargs["num_messages"] = len(messages)
        if segment_boundaries:
            kwargs["segment_boundaries"] = segment_boundaries

        async for output in self.stream_generate(
            prompt=prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            images=all_images if all_images else None,
            videos=all_videos if all_videos else None,
            request_id=request_id,
            gen_prompt_len=gen_prompt_len,
            **kwargs,
        ):
            yield output

    def get_stats(self) -> dict[str, Any]:
        """Get engine statistics."""
        stats = {
            "engine_type": "batched",
            "model_name": self._model_name,
            "is_mllm": self._is_mllm,
            "loaded": self._loaded,
            "stream_interval": self._stream_interval,
        }

        if self._mllm_scheduler:
            stats["mllm_scheduler"] = self._mllm_scheduler.get_stats()
        elif self._engine:
            stats.update(self._engine.get_stats())

        return stats

    def get_cache_stats(self) -> dict[str, Any] | None:
        """Get cache statistics."""
        if self._mllm_scheduler:
            stats = {}
            # Vision cache stats
            if self._mllm_scheduler.batch_generator:
                stats.update(
                    self._mllm_scheduler.batch_generator.get_vision_cache_stats()
                )
            # Paged cache stats
            if self._mllm_scheduler.block_aware_cache is not None:
                paged_stats = self._mllm_scheduler.block_aware_cache.get_stats()
                stats.update(paged_stats)
            return stats if stats else None
        elif self._engine:
            return self._engine.get_cache_stats()
        return None

    async def abort_request(self, request_id: str) -> bool:
        """
        Abort an ongoing request.

        Args:
            request_id: Request ID to abort

        Returns:
            True if request was found and aborted, False otherwise
        """
        if self._mllm_scheduler:
            return self._mllm_scheduler.abort_request(request_id)
        elif self._engine:
            return await self._engine.abort_request(request_id)
        return False
