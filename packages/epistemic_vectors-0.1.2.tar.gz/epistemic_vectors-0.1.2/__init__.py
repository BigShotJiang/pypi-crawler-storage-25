"""Epistemic Layer — the retrieval-pipeline component that attaches one
Epistemic Vector per document and exposes filter / re-rank / audit primitives.

Adapters are lazy-loaded; importing `epistemic_layer` does not force
`langchain-core`, `llama-index-core`, or `mem0ai` to be installed.

    from epistemic_layer.adapters.langchain import EpistemicRetriever
    # or
    from epistemic_layer.adapters.llamaindex import EpistemicRetriever
    # or
    from epistemic_layer.adapters.mem0 import EpistemicMemory
"""
from agm_r import EpistemicVector, epistemic_vector  # re-export primitive

__all__ = ["EpistemicVector", "epistemic_vector"]
__version__ = "0.1.0"
