"""Tests for the LangChain Epistemic Layer adapter.

Uses real langchain-core Document objects (langchain-core >= 1.0). The
base_retriever is a tiny in-memory stub — we don't need Chroma for the
semantics test, only the Document-shape integration. A full end-to-end
Chroma CI test lives in a separate integration-tests file.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pytest

# If langchain-core is missing, skip these tests (CI installs it).
langchain_core = pytest.importorskip("langchain_core")
from langchain_core.documents import Document

from agm_r import KnowledgeGraph, assert_belief, revise, retract
from epistemic_layer.adapters.langchain import EpistemicRetriever


class _StubRetriever:
    """Minimal LangChain-compatible base retriever for tests."""
    def __init__(self, docs: list[Document]):
        self.docs = docs

    def get_relevant_documents(self, query: str) -> list[Document]:
        return list(self.docs)


def _three_belief_kg() -> KnowledgeGraph:
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="x", source_id="doc_a",
                       claim_text="A", timestamp="2020-01-01")
    kg = assert_belief(kg, term="x", source_id="doc_b",
                       claim_text="B", timestamp="2022-01-01")
    kg = revise(kg, old_source_id="doc_a", new_source_id="doc_c",
                new_claim_text="C", timestamp="2024-01-01")
    return kg


def _make_docs() -> list[Document]:
    return [
        Document(page_content="A-text", metadata={"source_id": "doc_a"}),
        Document(page_content="B-text", metadata={"source_id": "doc_b"}),
        Document(page_content="C-text", metadata={"source_id": "doc_c"}),
        Document(page_content="no-match", metadata={"source_id": "unknown"}),
    ]


def test_attaches_epistemic_vector_to_metadata():
    kg = _three_belief_kg()
    base = _StubRetriever(_make_docs())
    ret = EpistemicRetriever(base_retriever=base, kg=kg)
    docs = ret.get_relevant_documents("query")
    assert len(docs) == 4
    doc_by_id = {d.metadata["source_id"]: d for d in docs}
    # doc_a was revised
    assert doc_by_id["doc_a"].metadata["epistemic_vector"]["revision_state"] == "revised"
    assert doc_by_id["doc_c"].metadata["epistemic_vector"]["revision_state"] == "asserted"
    # unknown doc → None vector
    assert doc_by_id["unknown"].metadata["epistemic_vector"] is None


def test_drop_unmapped_removes_unknown():
    kg = _three_belief_kg()
    base = _StubRetriever(_make_docs())
    ret = EpistemicRetriever(base_retriever=base, kg=kg, drop_unmapped=True)
    docs = ret.get_relevant_documents("query")
    sids = [d.metadata["source_id"] for d in docs]
    assert "unknown" not in sids
    assert len(docs) == 3


def test_filter_by_removes_retracted():
    kg = _three_belief_kg()
    kg = retract(kg, source_id="doc_b", retraction_time="2025-01-01")
    base = _StubRetriever(_make_docs())
    ret = EpistemicRetriever(
        base_retriever=base, kg=kg,
        filter_by=lambda ev: ev.revision_state != "retracted",
    )
    docs = ret.get_relevant_documents("query")
    sids = [d.metadata["source_id"] for d in docs]
    assert "doc_b" not in sids


def test_rerank_by_freshness():
    kg = _three_belief_kg()
    base = _StubRetriever(_make_docs())
    ret = EpistemicRetriever(
        base_retriever=base, kg=kg,
        rerank_by=lambda ev: ev.freshness,
        drop_unmapped=True,
    )
    docs = ret.get_relevant_documents("query")
    sids = [d.metadata["source_id"] for d in docs]
    # doc_c is 2024 (max), so freshest; doc_b is 2022; doc_a is 2020.
    assert sids[0] == "doc_c"
    assert sids[-1] == "doc_a"


def test_invoke_alias_works():
    kg = _three_belief_kg()
    base = _StubRetriever(_make_docs())
    ret = EpistemicRetriever(base_retriever=base, kg=kg)
    out = ret.invoke("query")
    assert len(out) == 4


def test_accepts_base_with_only_invoke():
    class InvokeOnly:
        def invoke(self, query: str) -> list[Document]:
            return [Document(page_content="x", metadata={"source_id": "doc_a"})]
    kg = _three_belief_kg()
    ret = EpistemicRetriever(base_retriever=InvokeOnly(), kg=kg)
    docs = ret.get_relevant_documents("q")
    assert len(docs) == 1
    assert docs[0].metadata["epistemic_vector"]["revision_state"] == "revised"


def test_custom_source_id_field():
    kg = _three_belief_kg()
    docs = [Document(page_content="x", metadata={"belief_id": "doc_a"})]
    ret = EpistemicRetriever(base_retriever=_StubRetriever(docs), kg=kg,
                              source_id_field="belief_id")
    out = ret.get_relevant_documents("q")
    assert out[0].metadata["epistemic_vector"]["source_id"] == "doc_a"
