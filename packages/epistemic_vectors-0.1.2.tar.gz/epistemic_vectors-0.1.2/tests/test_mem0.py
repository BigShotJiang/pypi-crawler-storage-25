"""Tests for the Mem0 Epistemic Layer adapter.

Uses a stub base memory — we don't need actual Mem0 + LLM credentials to
test the annotation semantics. A full end-to-end Mem0 CI test lives in
integration-tests.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pytest

from agm_r import KnowledgeGraph, assert_belief, revise, retract
from epistemic_layer.adapters.mem0 import EpistemicMemory


class _StubMemory:
    """Mem0-shaped stub for unit testing the adapter."""
    def __init__(self):
        self.records: list[dict] = []

    def add(self, messages, user_id=None, metadata=None, **kw):
        record = {
            "id": f"m{len(self.records)}",
            "memory": messages if isinstance(messages, str) else str(messages),
            "user_id": user_id,
            "metadata": dict(metadata) if metadata else {},
        }
        self.records.append(record)
        return {"results": [{"id": record["id"], "event": "ADD"}]}

    def search(self, query, user_id=None, limit=10, **kw):
        hits = [r for r in self.records if user_id is None
                 or r.get("user_id") == user_id]
        return {"results": hits[:limit]}

    def get_all(self, user_id=None, **kw):
        return {"results": [r for r in self.records
                             if user_id is None or r.get("user_id") == user_id]}

    def get(self, memory_id):
        for r in self.records:
            if r["id"] == memory_id:
                return r
        return None


def _kg() -> KnowledgeGraph:
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="t", source_id="m_a",
                       claim_text="A", timestamp="2020-01-01")
    kg = assert_belief(kg, term="t", source_id="m_b",
                       claim_text="B", timestamp="2022-01-01")
    kg = revise(kg, old_source_id="m_a", new_source_id="m_c",
                new_claim_text="C", timestamp="2024-01-01")
    return kg


def _populate(base: _StubMemory) -> None:
    base.add("memo-A", user_id="alice", metadata={"source_id": "m_a"})
    base.add("memo-B", user_id="alice", metadata={"source_id": "m_b"})
    base.add("memo-C", user_id="alice", metadata={"source_id": "m_c"})
    base.add("memo-X", user_id="alice", metadata={"source_id": "nope"})


def test_search_attaches_vectors():
    base = _StubMemory()
    _populate(base)
    em = EpistemicMemory(base=base, kg=_kg())
    out = em.search("q", user_id="alice")
    assert "results" in out and len(out["results"]) == 4
    by_sid = {r["metadata"]["source_id"]: r for r in out["results"]}
    assert by_sid["m_a"]["epistemic_vector"]["revision_state"] == "revised"
    assert by_sid["m_c"]["epistemic_vector"]["revision_state"] == "asserted"
    assert by_sid["nope"]["epistemic_vector"] is None


def test_drop_unmapped():
    base = _StubMemory()
    _populate(base)
    em = EpistemicMemory(base=base, kg=_kg(), drop_unmapped=True)
    out = em.search("q", user_id="alice")
    sids = [r["metadata"]["source_id"] for r in out["results"]]
    assert "nope" not in sids
    assert len(out["results"]) == 3


def test_filter_removes_retracted():
    kg = _kg()
    kg = retract(kg, source_id="m_b", retraction_time="2025-01-01")
    base = _StubMemory()
    _populate(base)
    em = EpistemicMemory(
        base=base, kg=kg,
        filter_by=lambda ev: ev.revision_state != "retracted",
    )
    out = em.search("q", user_id="alice")
    sids = [r["metadata"]["source_id"] for r in out["results"]]
    assert "m_b" not in sids


def test_rerank_by_freshness():
    base = _StubMemory()
    _populate(base)
    em = EpistemicMemory(
        base=base, kg=_kg(),
        rerank_by=lambda ev: ev.freshness,
        drop_unmapped=True,
    )
    out = em.search("q", user_id="alice")
    sids = [r["metadata"]["source_id"] for r in out["results"]]
    assert sids[0] == "m_c"
    assert sids[-1] == "m_a"


def test_get_all_attaches_vectors():
    base = _StubMemory()
    _populate(base)
    em = EpistemicMemory(base=base, kg=_kg())
    out = em.get_all(user_id="alice")
    assert len(out["results"]) == 4
    assert any(r.get("epistemic_vector") for r in out["results"])


def test_add_passthrough():
    base = _StubMemory()
    em = EpistemicMemory(base=base, kg=_kg())
    resp = em.add("fact", user_id="alice", metadata={"source_id": "m_a"})
    assert "results" in resp
    assert len(base.records) == 1
