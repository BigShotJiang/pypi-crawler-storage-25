"""Tests for the LlamaIndex Epistemic Layer adapter."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pytest

# Skip cleanly if llama-index-core missing (CI installs it).
pytest.importorskip("llama_index.core")
from llama_index.core.schema import NodeWithScore, TextNode

from agm_r import KnowledgeGraph, assert_belief, revise, retract
from epistemic_layer.adapters.llamaindex import EpistemicRetriever


class _StubRetriever:
    def __init__(self, nodes: list[NodeWithScore]):
        self.nodes = nodes

    def retrieve(self, query: str) -> list[NodeWithScore]:
        return list(self.nodes)


def _kg() -> KnowledgeGraph:
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="x", source_id="n_a",
                       claim_text="A", timestamp="2020-01-01")
    kg = assert_belief(kg, term="x", source_id="n_b",
                       claim_text="B", timestamp="2022-01-01")
    kg = revise(kg, old_source_id="n_a", new_source_id="n_c",
                new_claim_text="C", timestamp="2024-01-01")
    return kg


def _nodes() -> list[NodeWithScore]:
    return [
        NodeWithScore(node=TextNode(text="A-text", metadata={"source_id": "n_a"}),
                      score=0.9),
        NodeWithScore(node=TextNode(text="B-text", metadata={"source_id": "n_b"}),
                      score=0.8),
        NodeWithScore(node=TextNode(text="C-text", metadata={"source_id": "n_c"}),
                      score=0.7),
        NodeWithScore(node=TextNode(text="lost", metadata={"source_id": "nx"}),
                      score=0.1),
    ]


def test_attaches_vector_to_node_metadata():
    ret = EpistemicRetriever(base_retriever=_StubRetriever(_nodes()), kg=_kg())
    out = ret.retrieve("q")
    assert len(out) == 4
    by_id = {n.node.metadata["source_id"]: n for n in out}
    assert by_id["n_a"].node.metadata["epistemic_vector"]["revision_state"] == "revised"
    assert by_id["n_c"].node.metadata["epistemic_vector"]["revision_state"] == "asserted"
    assert by_id["nx"].node.metadata["epistemic_vector"] is None


def test_drop_unmapped_removes_unknown():
    ret = EpistemicRetriever(base_retriever=_StubRetriever(_nodes()), kg=_kg(),
                              drop_unmapped=True)
    out = ret.retrieve("q")
    sids = [n.node.metadata["source_id"] for n in out]
    assert "nx" not in sids
    assert len(out) == 3


def test_filter_removes_retracted():
    kg = _kg()
    kg = retract(kg, source_id="n_b", retraction_time="2025-01-01")
    ret = EpistemicRetriever(
        base_retriever=_StubRetriever(_nodes()), kg=kg,
        filter_by=lambda ev: ev.revision_state != "retracted",
    )
    out = ret.retrieve("q")
    sids = [n.node.metadata["source_id"] for n in out]
    assert "n_b" not in sids


def test_rerank_by_consistency_then_freshness():
    ret = EpistemicRetriever(
        base_retriever=_StubRetriever(_nodes()), kg=_kg(),
        rerank_by=lambda ev: ev.freshness,
        drop_unmapped=True,
    )
    out = ret.retrieve("q")
    sids = [n.node.metadata["source_id"] for n in out]
    assert sids[0] == "n_c"  # 2024 → freshest
    assert sids[-1] == "n_a"  # 2020 → stalest


def test_query_alias_works():
    ret = EpistemicRetriever(base_retriever=_StubRetriever(_nodes()), kg=_kg())
    out = ret.query("q")
    assert len(out) == 4
