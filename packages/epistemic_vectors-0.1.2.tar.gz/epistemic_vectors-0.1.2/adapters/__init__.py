"""Epistemic Layer adapters for third-party RAG stacks.

Each adapter is independently importable; the stack-specific dependency
(`langchain-core`, `llama-index-core`, `mem0ai`) is optional at install
time and only imported lazily inside the adapter module.
"""
