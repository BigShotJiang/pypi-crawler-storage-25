"""LangChain adapter — `EpistemicRetriever` wraps any base retriever so each
returned Document carries an `epistemic_vector` field in metadata.

Usage:

    from epistemic_layer.adapters.langchain import EpistemicRetriever

    retriever = EpistemicRetriever(
        base_retriever=any_langchain_retriever,  # Chroma, FAISS, BM25, etc.
        kg=kg,                                    # an agm_r.KnowledgeGraph
        source_id_field="source_id",              # where to look for the id
    )
    docs = retriever.get_relevant_documents("...")
    for d in docs:
        ev = d.metadata["epistemic_vector"]       # dict; None if no match

Optional re-rank / filter by Epistemic Vector:

    retriever = EpistemicRetriever(
        base_retriever=...,
        kg=kg,
        filter_by=lambda ev: ev.revision_state != "retracted",
        rerank_by=lambda ev: 0.5 * ev.freshness + 0.5 * ev.consistency_score,
    )

The adapter is intentionally thin: no embedding model, no reranker,
no audit chain. Compose with the rest of the LangChain toolkit as
usual. The Epistemic Vector is the only thing this class adds.
"""
from __future__ import annotations

from typing import Any, Callable, List, Optional

from agm_r import KnowledgeGraph, EpistemicVector, epistemic_vector


class EpistemicRetriever:
    """LangChain-compatible retriever that annotates docs with Epistemic Vectors.

    Accepts any object with a `get_relevant_documents(query) -> list` method,
    or LangChain's modern `invoke(query)` interface. Doesn't subclass
    `BaseRetriever` to avoid a hard `langchain-core` dependency; LangChain
    pipelines accept the duck-typed interface transparently.

    Args:
        base_retriever: any object exposing `get_relevant_documents(query)`
            or `invoke(query)`.
        kg: the agm_r KnowledgeGraph to look up each doc's belief state from.
        source_id_field: the metadata key (or attribute name) to use when
            locating each doc's source_id in `kg`. Defaults to "source_id".
        filter_by: optional predicate `EpistemicVector -> bool`. Docs
            whose vector returns False are dropped. Docs with no matching
            belief (ev=None) are kept by default; set `drop_unmapped=True`
            to drop them.
        rerank_by: optional score function `EpistemicVector -> float`.
            When provided, docs are sorted in descending score. Unmapped
            docs get score 0.0.
        drop_unmapped: if True, drop docs whose `source_id` is not in `kg`.
        freshness_lambda: override the freshness decay constant.
        now: override the reference "current time" (ISO-8601 timestamp).
    """

    def __init__(
        self,
        *,
        base_retriever: Any,
        kg: KnowledgeGraph,
        source_id_field: str = "source_id",
        filter_by: Optional[Callable[[EpistemicVector], bool]] = None,
        rerank_by: Optional[Callable[[EpistemicVector], float]] = None,
        drop_unmapped: bool = False,
        freshness_lambda: Optional[float] = None,
        now: Optional[str] = None,
    ):
        self.base = base_retriever
        self.kg = kg
        self.source_id_field = source_id_field
        self.filter_by = filter_by
        self.rerank_by = rerank_by
        self.drop_unmapped = drop_unmapped
        self.freshness_lambda = freshness_lambda
        self.now = now

    # ------------------------------------------------------------------
    # Retrieval
    # ------------------------------------------------------------------

    def get_relevant_documents(self, query: str) -> List[Any]:
        """LangChain-compatible retrieval with per-doc Epistemic Vector annotation."""
        docs = self._call_base(query)
        annotated: List[tuple[Any, Optional[EpistemicVector]]] = []
        for d in docs:
            sid = self._extract_source_id(d)
            ev = self._compute_vector(sid)
            if ev is None and self.drop_unmapped:
                continue
            if ev is not None and self.filter_by is not None:
                if not self.filter_by(ev):
                    continue
            self._attach_vector(d, ev)
            annotated.append((d, ev))
        if self.rerank_by is not None:
            annotated.sort(
                key=lambda pair: (self.rerank_by(pair[1])
                                   if pair[1] is not None else 0.0),
                reverse=True,
            )
        return [d for d, _ in annotated]

    def invoke(self, query: str, *args: Any, **kwargs: Any) -> List[Any]:
        """Alias for LangChain's modern `invoke()` API."""
        return self.get_relevant_documents(query)

    def _get_relevant_documents(self, query: str, **_: Any) -> List[Any]:
        """BaseRetriever internal hook (LangChain private method name)."""
        return self.get_relevant_documents(query)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _call_base(self, query: str) -> List[Any]:
        """Call the underlying retriever via whichever method it exposes."""
        if hasattr(self.base, "get_relevant_documents"):
            return list(self.base.get_relevant_documents(query))
        if hasattr(self.base, "invoke"):
            return list(self.base.invoke(query))
        raise TypeError(
            f"base_retriever {self.base!r} has neither "
            "`get_relevant_documents` nor `invoke` method")

    def _extract_source_id(self, doc: Any) -> Optional[str]:
        # LangChain Document has `.metadata` dict; some custom docs use attrs.
        meta = getattr(doc, "metadata", None)
        if isinstance(meta, dict) and self.source_id_field in meta:
            return str(meta[self.source_id_field])
        sid = getattr(doc, self.source_id_field, None)
        if sid is not None:
            return str(sid)
        return None

    def _compute_vector(self, source_id: Optional[str]) -> Optional[EpistemicVector]:
        if source_id is None:
            return None
        if self.kg.belief_by_source(source_id) is None:
            return None
        kwargs = {}
        if self.freshness_lambda is not None:
            kwargs["freshness_lambda"] = self.freshness_lambda
        if self.now is not None:
            kwargs["now"] = self.now
        return epistemic_vector(self.kg, source_id, **kwargs)

    def _attach_vector(self, doc: Any, ev: Optional[EpistemicVector]) -> None:
        """Write the vector into `doc.metadata` as a dict (JSON-friendly)."""
        meta = getattr(doc, "metadata", None)
        if not isinstance(meta, dict):
            # Not a LangChain-style Document — attach as attribute
            try:
                setattr(doc, "epistemic_vector", ev)
            except Exception:
                pass
            return
        meta["epistemic_vector"] = ev.to_json() if ev is not None else None
