"""LlamaIndex adapter — `EpistemicRetriever` wraps any LI retriever so each
returned NodeWithScore carries an `epistemic_vector` in its node.metadata.

Usage:

    from epistemic_layer.adapters.llamaindex import EpistemicRetriever

    retriever = EpistemicRetriever(
        base_retriever=any_llamaindex_retriever,  # Vector, BM25, Keyword, etc.
        kg=kg,                                     # an agm_r.KnowledgeGraph
    )
    nodes = retriever.retrieve("...")
    for nws in nodes:
        ev = nws.node.metadata["epistemic_vector"]   # dict or None
"""
from __future__ import annotations

from typing import Any, Callable, List, Optional

from agm_r import KnowledgeGraph, EpistemicVector, epistemic_vector


class EpistemicRetriever:
    """LlamaIndex-compatible retriever that annotates nodes with Epistemic Vectors.

    Accepts any object exposing `retrieve(query) -> list[NodeWithScore]`.
    Does not subclass `llama_index.core.retrievers.BaseRetriever` to avoid
    a hard dependency; LlamaIndex pipelines accept the duck-typed interface
    as long as `retrieve()` returns `NodeWithScore`-shaped objects.

    Args and semantics mirror the LangChain adapter.
    """

    def __init__(
        self,
        *,
        base_retriever: Any,
        kg: KnowledgeGraph,
        source_id_field: str = "source_id",
        filter_by: Optional[Callable[[EpistemicVector], bool]] = None,
        rerank_by: Optional[Callable[[EpistemicVector], float]] = None,
        drop_unmapped: bool = False,
        freshness_lambda: Optional[float] = None,
        now: Optional[str] = None,
    ):
        self.base = base_retriever
        self.kg = kg
        self.source_id_field = source_id_field
        self.filter_by = filter_by
        self.rerank_by = rerank_by
        self.drop_unmapped = drop_unmapped
        self.freshness_lambda = freshness_lambda
        self.now = now

    # ------------------------------------------------------------------
    # Retrieval
    # ------------------------------------------------------------------

    def retrieve(self, query: str) -> List[Any]:
        """LlamaIndex-compatible retrieval with per-node Epistemic Vector annotation.

        Returns a list of NodeWithScore-shaped objects whose `.node.metadata`
        dict carries an `epistemic_vector` key.
        """
        nodes = self._call_base(query)
        annotated: List[tuple[Any, Optional[EpistemicVector]]] = []
        for nws in nodes:
            sid = self._extract_source_id(nws)
            ev = self._compute_vector(sid)
            if ev is None and self.drop_unmapped:
                continue
            if ev is not None and self.filter_by is not None:
                if not self.filter_by(ev):
                    continue
            self._attach_vector(nws, ev)
            annotated.append((nws, ev))
        if self.rerank_by is not None:
            annotated.sort(
                key=lambda pair: (self.rerank_by(pair[1])
                                   if pair[1] is not None else 0.0),
                reverse=True,
            )
        return [nws for nws, _ in annotated]

    def query(self, query_str: str) -> List[Any]:
        """Alias used by some LI query engines."""
        return self.retrieve(query_str)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _call_base(self, query: str) -> List[Any]:
        if hasattr(self.base, "retrieve"):
            return list(self.base.retrieve(query))
        if hasattr(self.base, "query"):
            return list(self.base.query(query))
        raise TypeError(
            f"base_retriever {self.base!r} exposes neither "
            "`retrieve` nor `query`")

    def _extract_source_id(self, nws: Any) -> Optional[str]:
        """NodeWithScore has `.node.metadata`; plain nodes have `.metadata`."""
        node = getattr(nws, "node", nws)
        meta = getattr(node, "metadata", None)
        if isinstance(meta, dict) and self.source_id_field in meta:
            return str(meta[self.source_id_field])
        sid = getattr(node, self.source_id_field, None)
        if sid is not None:
            return str(sid)
        return None

    def _compute_vector(self, source_id: Optional[str]) -> Optional[EpistemicVector]:
        if source_id is None:
            return None
        if self.kg.belief_by_source(source_id) is None:
            return None
        kwargs = {}
        if self.freshness_lambda is not None:
            kwargs["freshness_lambda"] = self.freshness_lambda
        if self.now is not None:
            kwargs["now"] = self.now
        return epistemic_vector(self.kg, source_id, **kwargs)

    def _attach_vector(self, nws: Any, ev: Optional[EpistemicVector]) -> None:
        node = getattr(nws, "node", nws)
        meta = getattr(node, "metadata", None)
        if isinstance(meta, dict):
            meta["epistemic_vector"] = ev.to_json() if ev is not None else None
            return
        try:
            setattr(node, "epistemic_vector", ev)
        except Exception:
            pass
