"""Mem0 adapter — `EpistemicMemory` wraps a Mem0 `Memory` instance so
`search()` / `get_all()` results carry Epistemic Vectors.

Usage:

    from mem0 import Memory
    from epistemic_layer.adapters.mem0 import EpistemicMemory

    base = Memory()
    em = EpistemicMemory(base=base, kg=kg)
    em.add(messages=[...], user_id="alice",
           metadata={"source_id": "doc_a"})      # source_id threaded through
    results = em.search(query="...", user_id="alice")
    for r in results["results"]:
        ev = r["epistemic_vector"]                # dict or None

The base memory object is not modified; the adapter wraps `add` / `search` /
`get_all` / `get` / `update` / `delete` transparently and attaches the
Epistemic Vector by looking up each result's `metadata.source_id` in the
accompanying KnowledgeGraph. If a given memory has no matching belief,
`epistemic_vector` is None.
"""
from __future__ import annotations

from typing import Any, Callable, Iterable, Optional

from agm_r import KnowledgeGraph, EpistemicVector, epistemic_vector


class EpistemicMemory:
    """Mem0-compatible memory wrapper that annotates results with Epistemic Vectors.

    Args:
        base: a Mem0 `Memory` (or any object exposing `add` / `search` /
            `get_all` / `get`).
        kg: the agm_r KnowledgeGraph to resolve each memory's belief from.
        source_id_field: the metadata key to treat as `source_id` in each
            memory record. Defaults to "source_id".
        filter_by: optional predicate `EpistemicVector -> bool`. Results
            whose vector returns False are dropped from search/get_all output.
        rerank_by: optional score function `EpistemicVector -> float` used
            to re-sort search results.
        drop_unmapped: if True, drop search results whose `source_id` is not
            in `kg`.
        freshness_lambda: override the freshness decay constant.
        now: override the reference "current time" (ISO-8601 timestamp).
    """

    def __init__(
        self,
        *,
        base: Any,
        kg: KnowledgeGraph,
        source_id_field: str = "source_id",
        filter_by: Optional[Callable[[EpistemicVector], bool]] = None,
        rerank_by: Optional[Callable[[EpistemicVector], float]] = None,
        drop_unmapped: bool = False,
        freshness_lambda: Optional[float] = None,
        now: Optional[str] = None,
    ):
        self.base = base
        self.kg = kg
        self.source_id_field = source_id_field
        self.filter_by = filter_by
        self.rerank_by = rerank_by
        self.drop_unmapped = drop_unmapped
        self.freshness_lambda = freshness_lambda
        self.now = now

    # ------------------------------------------------------------------
    # Mem0-shaped passthrough + annotation
    # ------------------------------------------------------------------

    def add(self, *args: Any, **kwargs: Any) -> Any:
        """Delegate `add` untouched. Callers supply `metadata={"source_id": ...}`
        themselves; the adapter does not mutate user-supplied memory payloads.
        """
        return self.base.add(*args, **kwargs)

    def search(self, *args: Any, **kwargs: Any) -> dict:
        raw = self.base.search(*args, **kwargs)
        return self._annotate_results(raw)

    def get_all(self, *args: Any, **kwargs: Any) -> dict:
        raw = self.base.get_all(*args, **kwargs)
        return self._annotate_results(raw)

    def get(self, *args: Any, **kwargs: Any) -> dict:
        raw = self.base.get(*args, **kwargs)
        return self._annotate_one(raw)

    def update(self, *args: Any, **kwargs: Any) -> Any:
        return self.base.update(*args, **kwargs)

    def delete(self, *args: Any, **kwargs: Any) -> Any:
        return self.base.delete(*args, **kwargs)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _annotate_results(self, raw: Any) -> dict:
        """Mem0's search / get_all return a dict with a `results` list.
        Fall back to annotating the raw list if the shape is flat.
        """
        if isinstance(raw, dict) and "results" in raw:
            items = list(raw["results"])
            annotated = self._annotate_list(items)
            out = dict(raw)
            out["results"] = annotated
            return out
        if isinstance(raw, list):
            return {"results": self._annotate_list(raw)}
        return {"results": [self._annotate_one(raw)]} if raw is not None else {"results": []}

    def _annotate_list(self, items: list) -> list:
        annotated: list[tuple[dict, Optional[EpistemicVector]]] = []
        for item in items:
            ev = self._compute_vector_for(item)
            if ev is None and self.drop_unmapped:
                continue
            if ev is not None and self.filter_by is not None:
                if not self.filter_by(ev):
                    continue
            out = dict(item) if isinstance(item, dict) else {"item": item}
            out["epistemic_vector"] = ev.to_json() if ev is not None else None
            annotated.append((out, ev))
        if self.rerank_by is not None:
            annotated.sort(
                key=lambda pair: (self.rerank_by(pair[1])
                                   if pair[1] is not None else 0.0),
                reverse=True,
            )
        return [o for o, _ in annotated]

    def _annotate_one(self, item: Any) -> dict:
        ev = self._compute_vector_for(item)
        out = dict(item) if isinstance(item, dict) else {"item": item}
        out["epistemic_vector"] = ev.to_json() if ev is not None else None
        return out

    def _compute_vector_for(self, item: Any) -> Optional[EpistemicVector]:
        meta = item.get("metadata") if isinstance(item, dict) else None
        sid: Optional[str] = None
        if isinstance(meta, dict) and self.source_id_field in meta:
            sid = str(meta[self.source_id_field])
        elif isinstance(item, dict) and self.source_id_field in item:
            sid = str(item[self.source_id_field])
        if sid is None:
            return None
        if self.kg.belief_by_source(sid) is None:
            return None
        kwargs: dict[str, Any] = {}
        if self.freshness_lambda is not None:
            kwargs["freshness_lambda"] = self.freshness_lambda
        if self.now is not None:
            kwargs["now"] = self.now
        return epistemic_vector(self.kg, sid, **kwargs)
