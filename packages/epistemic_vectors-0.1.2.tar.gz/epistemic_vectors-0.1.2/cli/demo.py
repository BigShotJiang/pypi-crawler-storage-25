"""`crux demo` — side-by-side vanilla-vs-layer comparison.

Uses pre-computed illustrative results from a reference experiment.
Runs in under 5 seconds, requires no API keys, and shows the user-felt
difference the Epistemic Layer produces on current-belief queries:
vanilla RAG retrieves stale / retracted / revised notes alongside current
ones; the layer filters to the current head and the generator's answer
tracks reality.

Output is intentionally visceral: a user running `pip install
epistemic-vectors && crux demo` sees the failure mode the demo
documents, without touching an API key.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

_DATA = Path(__file__).resolve().parent / "data" / "demo_cases.json"


def _color_supported() -> bool:
    """Best-effort ANSI color detection."""
    import os
    import sys
    if not sys.stdout.isatty():
        return False
    return os.environ.get("TERM", "") not in {"dumb", ""}


class _Style:
    def __init__(self, enabled: bool):
        self.enabled = enabled

    def _wrap(self, code: str, text: str) -> str:
        if not self.enabled:
            return text
        return f"\033[{code}m{text}\033[0m"

    def bold(self, t):    return self._wrap("1", t)
    def dim(self, t):     return self._wrap("2", t)
    def red(self, t):     return self._wrap("31", t)
    def green(self, t):   return self._wrap("32", t)
    def yellow(self, t):  return self._wrap("33", t)
    def cyan(self, t):    return self._wrap("36", t)


def run(argv: list[str]) -> int:
    s = _Style(_color_supported())
    data = json.loads(_DATA.read_text())
    demo_cases = data["demo_cases"]
    agg = data["aggregate"]
    size = data["dataset_size"]

    print(s.bold("Epistemic Layer — vanilla vs +Layer side-by-side"))
    print(s.dim(f"  Benchmark: {data['benchmark_name']} — "
                f"{size['topics']} topics, {size['notes']} notes, "
                f"{size['queries']} queries"))
    print(s.dim(f"  Generator: GPT-4.1, top-k=3"))
    print(s.dim(f"  Results: pre-computed from published experiment "
                f"(no API key required for this demo)"))
    print()

    for i, c in enumerate(demo_cases, start=1):
        print(s.bold(f"━━━  Case {i}  " + "━" * 50))
        print(f"Query:  {s.cyan(c['question'])}")
        print(s.dim(f"  (topic: {c['topic_id']} "
                    f"· ground-truth note: {c['ground_truth_note_id']})"))
        print()

        print(s.red("  Vanilla RAG (top-k semantic, no layer):"))
        print(f"    retrieved: {c['vanilla']['retrieved']}")
        vans = c['vanilla']['answer'].replace("\n", " ").strip()
        print(f"    answer:    {s.red(vans[:200])}")
        print()

        print(s.green("  With Epistemic Layer (filter revised + rerank):"))
        print(f"    retrieved: {c['layer']['retrieved']}")
        lans = c['layer']['answer'].replace("\n", " ").strip()
        print(f"    answer:    {s.green(lans[:200])}")
        print()

    # Aggregate summary
    print(s.bold("━━━  Aggregate across all 25 current-belief queries  " + "━" * 22))
    print(f"  vanilla accuracy:         {agg['current_belief_vanilla_acc']:.3f}")
    print(f"  +Epistemic Layer:         {agg['current_belief_layer_acc']:.3f}")
    delta = agg['current_belief_delta_pp']
    print(s.bold(f"  delta:                    {s.green(f'+{delta:.1f} pp')}   "
                  f"(both GPT-4.1 and Haiku-4.5)"))
    print()
    print(s.dim(f"  Smart-routed aggregate (filter applied only to current-state queries):"))
    print(s.dim(f"    GPT-4.1  : {agg['smart_routed_aggregate_gpt41_vanilla']:.3f} "
                f"→ {agg['smart_routed_aggregate_gpt41_layer']:.3f}   "
                f"(+{agg['smart_routed_delta_gpt41_pp']:.1f} pp)"))
    print(s.dim(f"    Haiku-4.5: {agg['smart_routed_aggregate_haiku_vanilla']:.3f} "
                f"→ {agg['smart_routed_aggregate_haiku_layer']:.3f}   "
                f"(+{agg['smart_routed_delta_haiku_pp']:.1f} pp)"))
    print()
    print(s.bold("How to try this on your own notes:"))
    print("  from epistemic_layer.adapters.langchain import EpistemicRetriever")
    print("  from agm_r import KnowledgeGraph, assert_belief, revise")
    print("  retriever = EpistemicRetriever(base_retriever=your_chroma_retriever, kg=your_kg)")
    print("  # retrieved docs now carry .metadata['epistemic_vector']")
    print()
    print(s.dim(f"  Paper: {data['paper_reference']}"))
    print(s.dim(f"  pip install epistemic-vectors[langchain,llamaindex,mem0]"))
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(run(sys.argv[1:]))
