"""`crux vector` — compute an EpistemicVector for a belief in a simple KG.

Minimal interactive demo. Builds a tiny 3-note KG, applies a revise
operation, and prints the resulting EpistemicVector for each belief.
Useful for "what does this primitive actually look like" checks.
"""
from __future__ import annotations


def run(argv: list[str]) -> int:
    from agm_r import (KnowledgeGraph, assert_belief, revise,
                        epistemic_vector)
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="productivity_system", source_id="p1",
                       claim_text="Starting with GTD.",
                       timestamp="2023-01-10")
    kg = assert_belief(kg, term="productivity_system", source_id="p2",
                       claim_text="A simple daily checklist.",
                       timestamp="2024-06-15")
    kg = revise(kg, old_source_id="p1", new_source_id="p3",
                new_claim_text="GTD was overhead; switched to Apple Notes.",
                timestamp="2023-09-02")

    print("Belief graph (3 beliefs across one topic):")
    print()
    for sid in ["p1", "p2", "p3"]:
        ev = epistemic_vector(kg, sid)
        print(f"  {sid}: {ev}")
    print()
    print("Interpretation:")
    print("  p1: original GTD note — superseded, revision_state='revised'")
    print("  p2: independent Apple-Notes claim — revision_state='asserted', newest timestamp → freshness=1.00")
    print("  p3: the revision that supersedes p1 — revision_state='asserted'")
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(run(sys.argv[1:]))
