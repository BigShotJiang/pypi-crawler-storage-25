"""Epistemic Layer CLI — `crux` command.

Entry points:
    crux demo      — show the vanilla-vs-layer comparison from the
                     reference experiment (no API keys required, <5s)
    crux version   — print package version
    crux vector    — compute an EpistemicVector interactively
"""
from __future__ import annotations

import sys


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0] in {"-h", "--help", "help"}:
        return _print_help()
    cmd, rest = argv[0], argv[1:]
    if cmd == "demo":
        from .demo import run
        return run(rest)
    if cmd == "version":
        from epistemic_layer import __version__
        print(__version__)
        return 0
    if cmd == "vector":
        from .vector_cli import run
        return run(rest)
    print(f"crux: unknown command {cmd!r}. Try `crux help`.", file=sys.stderr)
    return 2


def _print_help() -> int:
    print(__doc__)
    print("Commands:")
    print("  crux demo       — show vanilla-vs-layer comparison (recommended first run)")
    print("  crux vector     — compute an EpistemicVector interactively")
    print("  crux version    — show package version")
    return 0


if __name__ == "__main__":
    sys.exit(main())
