> **DEPRECATED** — This package is no longer maintained.
> Migrate to [surety-ui](https://github.com/elenakulgavaya/surety-ui):
> `pip install surety-ui`
>
> Replace `from fild_ui import ...` with `from surety.ui import ...`.

# fild-ui v 0.1.10

![Downloads](https://img.shields.io/pypi/dm/fild-ui.svg?style=flat)
![Python Versions](https://img.shields.io/pypi/pyversions/fild-ui.svg?style=flat)
![License](https://img.shields.io/pypi/l/fild-ui.svg?version=latest)
[![Build Status](https://github.com/elenakulgavaya/fild-ui/workflows/Tests/badge.svg)](https://github.com/elenakulgavaya/fild-ui/actions)
