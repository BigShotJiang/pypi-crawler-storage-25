"""Module package source namespace."""
