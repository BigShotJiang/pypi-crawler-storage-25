from setuptools import setup, find_packages

setup(
    name="ub-clean-test",
    version="0.79.2",
    author="pengyeqin",
    author_email="xxbj433@qq.com",
    description="湘西紫 - 具身智能框架 (Xiangxi Purple - Embodied AI Framework)",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    
    # ========== 包含数据文件 ==========
    include_package_data=True,
    package_data={
        'ultra_balance.knowledge': ['*.json', '*.bin'],
        'ultra_balance.demo': ['*.py'],
    },
    # ==================================
    
    install_requires=[
        "numpy>=1.21.0",
        "scipy>=1.7.0"
    ],
    python_requires=">=3.6",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10"
    ]
)
