import numpy as np
from typing import List, Tuple, Optional
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class FrictionParams:
    """摩擦力参数"""
    coulomb: float = 0.5      # 库仑摩擦系数 (Nm)
    static: float = 0.8       # 静摩擦系数 (Nm)
    stribeck_vel: float = 0.1 # Stribeck 速度 (rad/s)
    viscous: float = 0.2      # 粘滞摩擦系数 (Nm/(rad/s))


class FrictionCompensator:
    """
    关节摩擦力补偿器
    
    提供摩擦力辨识和实时补偿功能。
    """
    
    def __init__(self, n_joints: int):
        self.n_joints = n_joints
        self.params = [FrictionParams() for _ in range(n_joints)]
        self.is_identified = False
        
        logger.info(f"摩擦力补偿器初始化: {n_joints} 关节")
    
    def friction_model(self, velocity: float, params: FrictionParams) -> float:
        """
        Stribeck + 库仑 + 粘滞摩擦模型
        
        Args:
            velocity: 关节速度 (rad/s)
            params: 摩擦参数
            
        Returns:
            摩擦力矩 (Nm)
        """
        v_abs = abs(velocity)
        if v_abs < 1e-6:
            return 0.0
        
        sign = np.sign(velocity)
        
        # Stribeck 项
        stribeck = (params.coulomb + 
                   (params.static - params.coulomb) * np.exp(-v_abs / params.stribeck_vel))
        
        # 粘滞项
        viscous = params.viscous * velocity
        
        return stribeck * sign + viscous
    
    def identify(self, 
                 velocities: np.ndarray, 
                 torques: np.ndarray,
                 joint_idx: int = 0):
        """
        辨识摩擦参数（简化：最小二乘拟合）
        
        Args:
            velocities: 速度序列
            torques: 力矩序列（无负载时）
            joint_idx: 关节索引
        """
        if len(velocities) < 10:
            logger.warning("数据点不足，跳过辨识")
            return
        
        params = self.params[joint_idx]
        
        # 简化辨识：只估计粘滞和库仑摩擦
        # 正速度部分
        pos_mask = velocities > 0.01
        if np.sum(pos_mask) > 3:
            v_pos = velocities[pos_mask]
            t_pos = torques[pos_mask]
            
            # t = τ_c + τ_v * v
            A = np.column_stack([np.ones_like(v_pos), v_pos])
            coeffs, _, _, _ = np.linalg.lstsq(A, t_pos, rcond=None)
            params.coulomb = max(0, coeffs[0])
            params.viscous = max(0, coeffs[1])
        
        # 估计静摩擦
        zero_mask = abs(velocities) < 0.005
        if np.sum(zero_mask) > 3:
            params.static = max(abs(torques[zero_mask]))
        
        self.is_identified = True
        logger.info(f"关节 {joint_idx} 摩擦参数: "
                   f"τ_c={params.coulomb:.3f}, τ_s={params.static:.3f}, "
                   f"τ_v={params.viscous:.3f}")
    
    def compensate(self, velocities: np.ndarray) -> np.ndarray:
        """
        计算摩擦补偿力矩
        
        Args:
            velocities: 各关节速度 [n_joints]
            
        Returns:
            补偿力矩 [n_joints]
        """
        comp_torque = np.zeros(self.n_joints)
        
        for i in range(min(self.n_joints, len(velocities))):
            comp_torque[i] = self.friction_model(velocities[i], self.params[i])
        
        return comp_torque
    
    def get_statistics(self) -> dict:
        """获取统计信息"""
        stats = {'is_identified': self.is_identified, 'joints': {}}
        for i, p in enumerate(self.params):
            stats['joints'][i] = {
                'coulomb': p.coulomb,
                'static': p.static,
                'viscous': p.viscous,
                'stribeck_vel': p.stribeck_vel
            }
        return stats
