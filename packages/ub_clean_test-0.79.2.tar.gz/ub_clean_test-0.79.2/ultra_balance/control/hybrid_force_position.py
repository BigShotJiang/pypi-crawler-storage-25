import numpy as np
from typing import List, Optional, Dict
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class HybridControlConfig:
    """混合控制配置"""
    dim: int = 6                           # 任务空间维度
    force_axes: List[int] = None           # 力控制轴（0-based）
    position_axes: List[int] = None        # 位置控制轴
    Kp: float = 500.0                      # 位置控制比例增益
    Kd: float = 50.0                       # 位置控制微分增益
    Kf: float = 1.0                        # 力控制比例增益
    Kf_d: float = 0.1                      # 力控制微分增益
    Ki_f: float = 0.01                     # 力控制积分增益
    max_force: float = 100.0               # 最大输出力
    max_force_rate: float = 500.0          # 最大力变化率 (N/s)


class HybridForcePositionController:
    """
    力/位混合控制器
    
    在指定轴上进行力控制，其他轴进行位置控制。
    适用于装配、打磨、抛光等需要同时控制力和位置的任务。
    """
    
    def __init__(self, config: Optional[HybridControlConfig] = None, **kwargs):
        if config is None:
            config = HybridControlConfig(**kwargs)
        
        if config.force_axes is None:
            config.force_axes = []
        if config.position_axes is None:
            config.position_axes = [i for i in range(config.dim) if i not in config.force_axes]
        
        self.config = config
        
        # 构造选择矩阵 S
        self.S = np.zeros((config.dim, config.dim))
        for i in config.position_axes:
            self.S[i, i] = 1.0
        
        # 力控制积分项
        self.force_integral = np.zeros(len(config.force_axes))
        self.last_force_error = np.zeros(len(config.force_axes))
        self.last_force = np.zeros(len(config.force_axes))
        
        logger.info(f"力/位混合控制器初始化: dim={config.dim}, "
                   f"力控制轴={config.force_axes}, 位置控制轴={config.position_axes}")
    
    def compute(self,
                jacobian: np.ndarray,
                x_des: np.ndarray,
                x_actual: np.ndarray,
                x_dot_des: np.ndarray,
                x_dot_actual: np.ndarray,
                f_des: np.ndarray,
                f_actual: np.ndarray,
                dt: float = 0.01) -> np.ndarray:
        """
        计算控制力矩
        
        Args:
            jacobian: 雅可比矩阵 J
            x_des: 期望末端位置/姿态
            x_actual: 实际末端位置/姿态
            x_dot_des: 期望末端速度
            x_dot_actual: 实际末端速度
            f_des: 期望力/力矩（仅在力控制轴有效）
            f_actual: 实际力/力矩
            dt: 时间步长
            
        Returns:
            关节力矩 τ
        """
        cfg = self.config
        
        # === 位置控制力 ===
        pos_error = x_des - x_actual
        vel_error = x_dot_des - x_dot_actual
        F_position = cfg.Kp * pos_error + cfg.Kd * vel_error
        
        # === 力控制力 ===
        # 只取力控制轴
        force_axes = cfg.force_axes
        if len(force_axes) > 0:
            f_des_axes = np.array([f_des[i] for i in force_axes])
            f_actual_axes = np.array([f_actual[i] for i in force_axes])
            
            force_error = f_des_axes - f_actual_axes
            
            # PID 力控制
            self.force_integral += force_error * dt
            force_derivative = (force_error - self.last_force_error) / dt
            
            F_force_axes = (cfg.Kf * force_error + 
                           cfg.Kf_d * force_derivative + 
                           cfg.Ki_f * self.force_integral)
            
            self.last_force_error = force_error.copy()
            
            # 构造完整力控制向量
            F_force = np.zeros(cfg.dim)
            for i, axis in enumerate(force_axes):
                F_force[axis] = F_force_axes[i]
        else:
            F_force = np.zeros(cfg.dim)
        
        # === 混合控制合成 ===
        # F = S * F_position + (I - S) * F_force
        I = np.eye(cfg.dim)
        F_task = self.S @ F_position + (I - self.S) @ F_force
        
        # 力限幅
        force_norm = np.linalg.norm(F_task)
        if force_norm > cfg.max_force:
            F_task = F_task / force_norm * cfg.max_force
        
        # 力变化率限制
        if dt > 0:
            force_rate = np.linalg.norm(F_task - self.last_force) / dt
            if force_rate > cfg.max_force_rate:
                alpha = cfg.max_force_rate * dt / np.linalg.norm(F_task - self.last_force)
                F_task = self.last_force + alpha * (F_task - self.last_force)
        
        self.last_force = F_task.copy()
        
        # 关节力矩: τ = J^T * F_task
        tau = jacobian.T @ F_task
        
        return tau
    
    def reset(self):
        """重置控制器状态"""
        self.force_integral = np.zeros(len(self.config.force_axes))
        self.last_force_error = np.zeros(len(self.config.force_axes))
        self.last_force = np.zeros(self.config.dim)
        logger.info("力/位混合控制器已重置")
    
    def get_statistics(self) -> dict:
        """获取统计信息"""
        return {
            'force_axes': self.config.force_axes,
            'position_axes': self.config.position_axes,
            'force_integral': self.force_integral.tolist(),
            'last_force': self.last_force.tolist()
        }
