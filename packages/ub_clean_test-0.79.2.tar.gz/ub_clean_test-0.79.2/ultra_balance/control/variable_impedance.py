import numpy as np
from typing import Tuple, Optional
from dataclasses import dataclass
from enum import Enum, auto
import logging

logger = logging.getLogger(__name__)


class TaskPhase(Enum):
    """任务阶段"""
    FREE_SPACE = auto()      # 自由空间（无接触）
    CONTACT_TRANSITION = auto()  # 接触过渡
    STABLE_CONTACT = auto()  # 稳定接触


@dataclass
class ImpedanceConfig:
    """阻抗控制配置"""
    dim: int = 3                                    # 维度
    K_free: float = 100.0                           # 自由空间刚度
    K_contact: float = 500.0                        # 接触过渡刚度
    K_stable: float = 1000.0                        # 稳定接触刚度
    D_ratio: float = 0.7                            # 阻尼比（临界阻尼=1.0）
    force_threshold: float = 2.0                    # 接触力阈值 (N)
    velocity_threshold: float = 0.01                # 速度阈值 (m/s)
    smoothing_time: float = 0.1                     # 刚度切换平滑时间 (s)
    max_force: float = 100.0                        # 最大输出力


class VariableImpedanceController:
    """
    变刚度阻抗控制器
    
    根据任务阶段自动调整刚度，使机器人在不同阶段有合适的柔顺性。
    """
    
    def __init__(self, config: Optional[ImpedanceConfig] = None, **kwargs):
        if config is None:
            config = ImpedanceConfig(**kwargs)
        self.config = config
        
        # 当前阶段
        self.phase = TaskPhase.FREE_SPACE
        
        # 当前刚度和阻尼
        self.K_current = config.K_free
        self.D_current = self._compute_damping(config.K_free)
        
        # 目标刚度和阻尼（用于平滑过渡）
        self.K_target = config.K_free
        self.D_target = self._compute_damping(config.K_free)
        
        # 力历史（用于接触检测）
        self.force_history = []
        self.force_window = 10
        
        # 统计
        self.phase_history = []
        
        logger.info(f"变刚度阻抗控制器初始化: dim={config.dim}, "
                   f"K=({config.K_free}, {config.K_contact}, {config.K_stable})")
    
    def _compute_damping(self, K: float) -> float:
        """根据刚度和阻尼比计算阻尼系数"""
        # D = 2 * ζ * sqrt(K * M)，假设 M=1
        return 2 * self.config.D_ratio * np.sqrt(K)
    
    def detect_phase(self, 
                     force_actual: np.ndarray, 
                     velocity_actual: np.ndarray) -> TaskPhase:
        """
        检测当前任务阶段
        
        Args:
            force_actual: 实际接触力
            velocity_actual: 实际末端速度
            
        Returns:
            任务阶段
        """
        force_norm = np.linalg.norm(force_actual)
        velocity_norm = np.linalg.norm(velocity_actual)
        
        self.force_history.append(force_norm)
        if len(self.force_history) > self.force_window:
            self.force_history.pop(0)
        
        avg_force = np.mean(self.force_history) if self.force_history else 0
        
        if avg_force > self.config.force_threshold:
            # 有接触力
            if velocity_norm < self.config.velocity_threshold:
                return TaskPhase.STABLE_CONTACT
            else:
                return TaskPhase.CONTACT_TRANSITION
        else:
            return TaskPhase.FREE_SPACE
    
    def update_stiffness(self, phase: TaskPhase, dt: float):
        """
        根据阶段更新刚度（平滑过渡）
        
        Args:
            phase: 当前阶段
            dt: 时间步长
        """
        # 设置目标刚度
        cfg = self.config
        if phase == TaskPhase.FREE_SPACE:
            self.K_target = cfg.K_free
        elif phase == TaskPhase.CONTACT_TRANSITION:
            self.K_target = cfg.K_contact
        else:
            self.K_target = cfg.K_stable
        
        self.D_target = self._compute_damping(self.K_target)
        
        # 平滑过渡
        alpha = min(1.0, dt / cfg.smoothing_time)
        self.K_current += alpha * (self.K_target - self.K_current)
        self.D_current += alpha * (self.D_target - self.D_current)
        
        # 更新阶段
        if phase != self.phase:
            logger.debug(f"阶段切换: {self.phase.name} -> {phase.name}, "
                        f"K={self.K_current:.1f}")
            self.phase = phase
            self.phase_history.append(phase)
    
    def compute(self,
                x_des: np.ndarray,
                x_actual: np.ndarray,
                x_dot_des: np.ndarray,
                x_dot_actual: np.ndarray,
                force_actual: np.ndarray,
                dt: float = 0.01) -> Tuple[np.ndarray, TaskPhase]:
        """
        计算控制力
        
        Args:
            x_des: 期望位置
            x_actual: 实际位置
            x_dot_des: 期望速度
            x_dot_actual: 实际速度
            force_actual: 实际接触力
            dt: 时间步长
            
        Returns:
            (控制力, 当前阶段)
        """
        # 检测阶段
        phase = self.detect_phase(force_actual, x_dot_actual)
        
        # 更新刚度
        self.update_stiffness(phase, dt)
        
        # 阻抗控制律: F = K*(x_des - x) + D*(x_dot_des - x_dot)
        pos_error = x_des - x_actual
        vel_error = x_dot_des - x_dot_actual
        
        force = self.K_current * pos_error + self.D_current * vel_error
        
        # 限幅
        force_norm = np.linalg.norm(force)
        if force_norm > self.config.max_force:
            force = force / force_norm * self.config.max_force
        
        return force, phase
    
    def get_current_stiffness(self) -> float:
        """获取当前刚度"""
        return self.K_current
    
    def get_statistics(self) -> dict:
        """获取统计信息"""
        phase_counts = {p.name: self.phase_history.count(p) for p in TaskPhase}
        return {
            'current_phase': self.phase.name,
            'current_stiffness': self.K_current,
            'current_damping': self.D_current,
            'phase_history': phase_counts
        }
