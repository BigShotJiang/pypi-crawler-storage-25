import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field
import logging

logger = logging.getLogger(__name__)

try:
    import osqp
    from scipy import sparse
    HAS_OSQP = True
except ImportError:
    HAS_OSQP = False
    logger.warning("OSQP 未安装，使用内置简化求解器。安装: pip install osqp")


@dataclass
class Task:
    """任务定义"""
    name: str
    jacobian: np.ndarray          # 雅可比矩阵 J
    desired_velocity: np.ndarray   # 期望末端速度 x_dot_des
    weight: float = 1.0            # 任务权重
    priority: int = 0              # 优先级（越小越高）
    
    def __post_init__(self):
        self.dim = len(self.desired_velocity)


@dataclass
class ContactConstraint:
    """接触约束"""
    name: str
    jacobian: np.ndarray           # 接触点雅可比 J_c
    friction_coefficient: float = 0.6  # 摩擦系数 μ
    max_normal_force: float = 500.0    # 最大法向力 (N)
    min_normal_force: float = 0.0      # 最小法向力 (N)


class OSQPWholeBodyControl:
    """
    基于 OSQP 的全身控制求解器
    
    求解问题：
        min  Σ w_i || J_i q_ddot + J_i_dot q_dot - x_i_ddot_des ||?
        s.t. M q_ddot + h = S^T τ + J_c^T f_c
             摩擦锥约束
             关节力矩限制
    """
    
    def __init__(self, 
                 n_joints: int,
                 dt: float = 0.001,
                 torque_limits: Optional[np.ndarray] = None,
                 use_osqp: bool = True):
        """
        初始化 WBC 求解器
        
        Args:
            n_joints: 关节数量
            dt: 控制周期 (s)
            torque_limits: 关节力矩限制 [n_joints]，None 表示无限制
            use_osqp: 是否使用 OSQP 求解器
        """
        self.n_joints = n_joints
        self.dt = dt
        self.torque_limits = torque_limits
        self.use_osqp = use_osqp and HAS_OSQP
        
        # 动力学参数（需外部设置）
        self.M = np.eye(n_joints)       # 惯量矩阵
        self.h = np.zeros(n_joints)     # 科氏力+重力
        self.S = np.eye(n_joints)        # 选择矩阵
        
        # 统计
        self.total_solves = 0
        self.avg_solve_time = 0.0
        
        logger.info(f"WBC 求解器初始化: {n_joints} 关节, dt={dt*1000:.1f}ms, "
                   f"OSQP={'启用' if self.use_osqp else '禁用'}")
    
    def set_dynamics(self, M: np.ndarray, h: np.ndarray, S: Optional[np.ndarray] = None):
        """设置动力学参数"""
        self.M = M
        self.h = h
        if S is not None:
            self.S = S
    
    def solve(self, 
              tasks: List[Task],
              contacts: List[ContactConstraint],
              q_dot: np.ndarray) -> Dict[str, np.ndarray]:
        """
        求解 WBC
        
        Args:
            tasks: 任务列表
            contacts: 接触约束列表
            q_dot: 当前关节速度
            
        Returns:
            {'tau': 关节力矩, 'f_c': 接触力, 'q_ddot': 关节加速度}
        """
        import time
        t_start = time.perf_counter()
        
        if self.use_osqp:
            result = self._solve_osqp(tasks, contacts, q_dot)
        else:
            result = self._solve_simple(tasks, contacts, q_dot)
        
        solve_time = time.perf_counter() - t_start
        self.total_solves += 1
        self.avg_solve_time = 0.9 * self.avg_solve_time + 0.1 * solve_time
        
        return result
    
    def _solve_simple(self, tasks, contacts, q_dot):
        """简化求解器（不需要 OSQP）"""
        n_joints = self.n_joints
        
        # 按优先级排序
        tasks = sorted(tasks, key=lambda t: t.priority)
        
        # 累计任务矩阵
        A_stack = []
        b_stack = []
        weights = []
        
        for task in tasks:
            J = task.jacobian
            x_dot_des = task.desired_velocity
            
            # 计算 J_dot * q_dot（简化：假设 J_dot = 0）
            J_dot_q_dot = np.zeros(task.dim)
            
            A_stack.append(J)
            b_stack.append(x_dot_des - J_dot_q_dot)
            weights.append(task.weight)
        
        if not A_stack:
            return {'tau': np.zeros(n_joints), 'f_c': np.zeros(0), 'q_ddot': np.zeros(n_joints)}
        
        # 加权最小二乘
        A = np.vstack(A_stack)
        b = np.concatenate(b_stack)
        W = np.diag(np.repeat(weights, [t.dim for t in tasks]))
        
        # q_ddot = A^+ * b（伪逆解）
        A_pinv = np.linalg.pinv(A)
        q_ddot = A_pinv @ b
        
        # 计算力矩: τ = M q_ddot + h
        tau = self.M @ q_ddot + self.h
        
        # 力矩限幅
        if self.torque_limits is not None:
            tau = np.clip(tau, -self.torque_limits, self.torque_limits)
        
        # 接触力（简化：零空间投影）
        n_contacts = len(contacts)
        f_c = np.zeros(n_contacts * 3) if n_contacts > 0 else np.zeros(0)
        
        return {'tau': tau, 'f_c': f_c, 'q_ddot': q_ddot}
    
    def _solve_osqp(self, tasks, contacts, q_dot):
        """使用 OSQP 求解器"""
        n_joints = self.n_joints
        
        # 决策变量: [q_ddot, f_c]
        n_contacts = len(contacts)
        n_fc = n_contacts * 3
        n_vars = n_joints + n_fc
        
        # === 目标函数 ===
        tasks = sorted(tasks, key=lambda t: t.priority)
        
        H_blocks = []
        q_blocks = []
        
        for task in tasks:
            J = task.jacobian
            w = task.weight
            
            # 构造 Hessian: w * J^T * J
            H_blocks.append(np.zeros((n_joints + n_fc, n_joints + n_fc)))
            H_blocks[-1][:n_joints, :n_joints] = w * J.T @ J
            
            # 构造 gradient: -w * J^T * x_ddot_des
            q_blocks.append(np.zeros(n_vars))
            q_blocks[-1][:n_joints] = -w * J.T @ task.desired_velocity
        
        # 合并（简化：使用第一个任务）
        H = sparse.csc_matrix(H_blocks[0][:n_joints, :n_joints])
        q = q_blocks[0][:n_joints]
        
        # === 约束 ===
        # 动力学约束: M q_ddot = S^T τ + J_c^T f_c - h
        if n_contacts > 0:
            J_c = contacts[0].jacobian
            A_dyn = np.hstack([self.M, -J_c.T])
            l_dyn = -self.h
            u_dyn = -self.h
        else:
            A_dyn = self.M.copy()
            l_dyn = -self.h
            u_dyn = -self.h
        
        A = sparse.csc_matrix(A_dyn)
        l = l_dyn
        u = u_dyn
        
        # === 求解 ===
        try:
            prob = osqp.OSQP()
            prob.setup(H, q, A, l, u, verbose=False, eps_abs=1e-4, eps_rel=1e-4)
            res = prob.solve()
            
            if res.info.status != 'solved':
                logger.warning(f"OSQP 求解状态: {res.info.status}")
                return self._solve_simple(tasks, contacts, q_dot)
            
            q_ddot = res.x[:n_joints]
            f_c = res.x[n_joints:] if n_contacts > 0 else np.zeros(0)
            
        except Exception as e:
            logger.warning(f"OSQP 求解失败: {e}，回退到简化求解器")
            return self._solve_simple(tasks, contacts, q_dot)
        
        # 计算力矩
        tau = self.M @ q_ddot + self.h
        
        # 力矩限幅
        if self.torque_limits is not None:
            tau = np.clip(tau, -self.torque_limits, self.torque_limits)
        
        return {'tau': tau, 'f_c': f_c, 'q_ddot': q_ddot}
    
    def get_statistics(self) -> dict:
        """获取统计信息"""
        return {
            'total_solves': self.total_solves,
            'avg_solve_time_ms': self.avg_solve_time * 1000,
            'solver': 'OSQP' if self.use_osqp else 'Simple'
        }
