"""
变刚度阻抗控制演示 v0.79.0

运行方式：
    python -m ultra_balance.demo.demo_variable_impedance
"""

import numpy as np
import os

# ========== 图形界面智能检测 ==========
try:
    import matplotlib
    matplotlib.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']
    matplotlib.rcParams['axes.unicode_minus'] = False
    
    if 'DISPLAY' in os.environ or os.name == 'nt':
        import matplotlib.pyplot as plt
        HAS_PLOT = True
    else:
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        HAS_PLOT = True
except ImportError:
    HAS_PLOT = False
    plt = None

from ultra_balance.control.variable_impedance import (
    VariableImpedanceController, ImpedanceConfig, TaskPhase
)


def main():
    print("\n" + "=" * 50)
    print("变刚度阻抗控制演示 v0.79.0")
    print("=" * 50)
    
    # 创建控制器
    config = ImpedanceConfig(
        dim=2,
        K_free=100,
        K_contact=500,
        K_stable=1000,
        force_threshold=2.0
    )
    vic = VariableImpedanceController(config)
    
    # 模拟任务：从自由空间移动到接触表面
    dt = 0.01
    total_time = 3.0
    steps = int(total_time / dt)
    
    # 轨迹：先自由移动，再接触，最后稳定
    x_des = np.array([0.1, 0.0])
    x_actual = np.zeros(2)
    x_dot_actual = np.zeros(2)
    
    position_history = []
    stiffness_history = []
    phase_history = []
    force_history = []
    
    print(f"\n? 模拟变刚度控制...")
    print(f"   阶段: 自由空间 → 接触过渡 → 稳定接触")
    print("-" * 40)
    
    for step in range(steps):
        t = step * dt
        
        # 模拟接触力（位置 > 0.05 时开始接触）
        if x_actual[0] > 0.05:
            penetration = x_actual[0] - 0.05
            force_actual = np.array([5000 * penetration, 0.0])
        else:
            force_actual = np.zeros(2)
        
        # 计算控制力
        force, phase = vic.compute(
            x_des, x_actual,
            np.zeros(2), x_dot_actual,
            force_actual, dt
        )
        
        # 简单动力学模拟
        x_ddot = force  # F = ma, m=1
        x_dot_actual += x_ddot * dt
        x_actual += x_dot_actual * dt
        
        # 记录
        position_history.append(x_actual[0])
        stiffness_history.append(vic.get_current_stiffness())
        phase_history.append(phase)
        force_history.append(np.linalg.norm(force_actual))
        
        # 打印阶段切换
        if step > 0 and phase != phase_history[-2]:
            print(f"   t={t:.2f}s: {phase.name}, K={vic.get_current_stiffness():.0f}")
    
    print("-" * 40)
    print(f"\n? 模拟完成！")
    
    # 绘图
    if HAS_PLOT and plt:
        fig, axes = plt.subplots(3, 1, figsize=(10, 10), sharex=True)
        
        t = np.linspace(0, total_time, steps)
        
        # 位置
        axes[0].plot(t, position_history, 'b-', label='实际位置')
        axes[0].axhline(y=0.05, color='r', linestyle='--', label='接触面')
        axes[0].set_ylabel('位置 (m)')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)
        
        # 刚度
        axes[1].plot(t, stiffness_history, 'g-', label='刚度 K')
        axes[1].set_ylabel('刚度 (N/m)')
        axes[1].legend()
        axes[1].grid(True, alpha=0.3)
        
        # 接触力
        axes[2].plot(t, force_history, 'r-', label='接触力')
        axes[2].set_xlabel('时间 (s)')
        axes[2].set_ylabel('力 (N)')
        axes[2].legend()
        axes[2].grid(True, alpha=0.3)
        
        fig.suptitle('变刚度阻抗控制演示', fontsize=14)
        plt.tight_layout()
        
        try:
            plt.show()
        except:
            filename = "demo_variable_impedance.png"
            plt.savefig(filename, dpi=150, bbox_inches='tight')
            print(f"\n? 图形已保存至: {filename}")
            plt.close()


if __name__ == "__main__":
    main()
