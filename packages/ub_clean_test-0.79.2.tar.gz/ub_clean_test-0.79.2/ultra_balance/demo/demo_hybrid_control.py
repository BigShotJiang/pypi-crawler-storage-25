"""
力/位混合控制演示 v0.79.0

运行方式：
    python -m ultra_balance.demo.demo_hybrid_control
"""

import numpy as np
import os

# ========== 图形界面智能检测 ==========
try:
    import matplotlib
    matplotlib.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']
    matplotlib.rcParams['axes.unicode_minus'] = False
    
    if 'DISPLAY' in os.environ or os.name == 'nt':
        import matplotlib.pyplot as plt
        HAS_PLOT = True
    else:
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        HAS_PLOT = True
except ImportError:
    HAS_PLOT = False
    plt = None

from ultra_balance.control.hybrid_force_position import (
    HybridForcePositionController, HybridControlConfig
)


def main():
    print("\n" + "=" * 50)
    print("力/位混合控制演示 v0.79.0")
    print("=" * 50)
    
    # 创建控制器：Z轴力控制，X/Y轴位置控制
    config = HybridControlConfig(
        dim=3,
        force_axes=[2],       # Z轴力控制
        position_axes=[0, 1],  # X/Y轴位置控制
        Kp=500,
        Kd=50,
        Kf=0.5,
        max_force=50
    )
    hfc = HybridForcePositionController(config)
    
    print(f"\n控制配置:")
    print(f"  力控制轴: Z (保持10N接触力)")
    print(f"  位置控制轴: X, Y (沿表面移动)")
    print(f"  位置增益: Kp={config.Kp}, Kd={config.Kd}")
    print(f"  力增益: Kf={config.Kf}")
    
    # 模拟：沿表面移动，同时保持10N接触力
    dt = 0.01
    total_time = 3.0
    steps = int(total_time / dt)
    
    jacobian = np.eye(3)
    
    # 期望轨迹
    x_des = np.array([0.0, 0.0, 0.0])      # 期望位置
    f_des = np.array([0.0, 0.0, 10.0])      # 期望力（Z轴10N）
    
    # 实际状态
    x_actual = np.array([0.0, 0.0, 0.0])
    x_dot_actual = np.zeros(3)
    
    position_history = []
    force_history = []
    tau_history = []
    
    print(f"\n? 模拟力/位混合控制...")
    print(f"   任务：沿X轴移动，同时保持Z轴10N压力")
    print("-" * 40)
    
    for step in range(steps):
        t = step * dt
        
        # 期望位置沿X轴移动，Z轴保持
        x_des[0] = 0.1 * np.sin(2 * np.pi * t / total_time)
        x_dot_des = np.array([0.1 * 2 * np.pi / total_time * np.cos(2 * np.pi * t / total_time), 0.0, 0.0])
        
        # 模拟接触力（Z轴）: 受实际位置影响
        if x_actual[2] > 0:
            f_actual = np.array([0.0, 0.0, 5000 * x_actual[2]])
        else:
            f_actual = np.zeros(3)
        
        # 计算控制力矩
        tau = hfc.compute(
            jacobian, x_des, x_actual,
            x_dot_des, x_dot_actual,
            f_des, f_actual, dt
        )
        
        # 简单动力学模拟
        x_ddot = tau / 100.0  # 假设质量=100
        x_dot_actual += x_ddot * dt
        x_actual += x_dot_actual * dt
        
        # 记录
        position_history.append(x_actual.copy())
        force_history.append(f_actual[2])
        tau_history.append(np.linalg.norm(tau))
        
        # 打印
        if step % (steps // 5) == 0:
            print(f"   t={t:.1f}s: pos=({x_actual[0]:.3f}, {x_actual[2]:.3f}), "
                  f"Fz={f_actual[2]:.2f}N, |tau|={np.linalg.norm(tau):.2f}")
    
    print("-" * 40)
    print(f"\n? 模拟完成！")
    
    # 绘图
    if HAS_PLOT and plt:
        fig, axes = plt.subplots(3, 1, figsize=(10, 10), sharex=True)
        
        t = np.linspace(0, total_time, steps)
        pos = np.array(position_history)
        
        # X轴位置
        axes[0].plot(t, pos[:, 0], 'b-', label='X轴实际位置')
        axes[0].plot(t, 0.1 * np.sin(2 * np.pi * t / total_time), 'r--', label='X轴期望位置')
        axes[0].set_ylabel('X位置 (m)')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)
        
        # Z轴位置
        axes[1].plot(t, pos[:, 2] * 1000, 'g-', label='Z轴位置')
        axes[1].set_ylabel('Z位置 (mm)')
        axes[1].legend()
        axes[1].grid(True, alpha=0.3)
        
        # 接触力
        axes[2].plot(t, force_history, 'r-', label='实际接触力')
        axes[2].axhline(y=f_des[2], color='g', linestyle='--', label=f'期望力 {f_des[2]}N')
        axes[2].set_xlabel('时间 (s)')
        axes[2].set_ylabel('接触力 (N)')
        axes[2].legend()
        axes[2].grid(True, alpha=0.3)
        
        fig.suptitle('力/位混合控制演示', fontsize=14)
        plt.tight_layout()
        
        try:
            plt.show()
        except:
            filename = "demo_hybrid_control.png"
            plt.savefig(filename, dpi=150, bbox_inches='tight')
            print(f"\n? 图形已保存至: {filename}")
            plt.close()


if __name__ == "__main__":
    main()
