# Copyright 2023 Euratom
# Copyright 2023 United Kingdom Atomic Energy Authority
# Copyright 2023 Centro de Investigaciones Energéticas, Medioambientales y Tecnológicas
#
# Licensed under the EUPL, Version 1.1 or – as soon they will be approved by the
# European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
#
# https://joinup.ec.europa.eu/software/page/eupl5
#
# Unless required by applicable law or agreed to in writing, software distributed
# under the Licence is distributed on an "AS IS" basis, WITHOUT WARRANTIES OR
# CONDITIONS OF ANY KIND, either express or implied.
#
# See the Licence for the specific language governing permissions and limitations
# under the Licence.
"""Subpackage for loading GGD grids from IMAS IDS structures."""

from .load_grid import load_grid
from .load_unstruct_2d import load_unstruct_grid_2d
from .load_unstruct_3d import load_unstruct_grid_2d_extended, load_unstruct_grid_3d

__all__ = [
    "load_grid",
    "load_unstruct_grid_2d",
    "load_unstruct_grid_2d_extended",
    "load_unstruct_grid_3d",
]
