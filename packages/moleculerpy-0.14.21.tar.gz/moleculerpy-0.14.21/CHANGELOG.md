# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.14.21] - 2026-04-07

### Added
- **Redis Cacher production-ready** — start()/stop() lifecycle, broker integration,
  16 integration tests (get/set/delete/clean/TTL/keys/broker)
- **seq/instanceID heartbeat checks** — detects remote node restart and service changes
  via heartbeat (Node.js heartbeatReceived parity)

### Fixed
- **instanceID persistence** — process_node_info now saves instanceID from INFO packets
  (was causing infinite re-discovery loop on every heartbeat)
- **payload dict guard** — _handle_heartbeat validates payload is dict before access
  (prevents crash on malformed packets)
- **seq type coercion** — int comparison for cross-language safety
- **instanceID=None guard** — skip comparison when node has no instanceID yet
- **_discover_pending cleanup** — stale entries evicted in check_remote_nodes
  (prevents unbounded memory growth)
- **Redis cacher: logger fallback** — set in __init__ (was crashing if connect() before init())
- **Redis cacher: prefix dedup** — removed duplicate namespace logic (BaseCacher handles it)
- **Redis cacher: TTL validation** — negative/zero TTL warns and stores without expiry
- **Redis cacher: ping loop** — pings first then sleeps (detects immediate connection drop)

## [0.14.20] - 2026-04-06

### Added
- **Kafka 2-node discovery** — 6 root causes fixed: batch make_subscriptions, heartbeat-driven
  discover_node, targeted DISCOVER/INFO, broadcast PING subscription (Node.js parity)
- **checkRemoteNodes timer** — marks nodes unavailable after heartbeat_timeout (Node.js base.js)
- **checkOfflineNodes timer** — removes nodes silent >10 minutes (Node.js base.js)
- **Auto-reconnect** — Transit.connect() retries with 5s backoff on transporter failure
- **Demo matrix** — 28-cell smoke test (7 transports × 4 serializers)
- **Comprehensive test suite** — 90 integration tests: lifecycle, actions, events, discovery,
  errors, versioning, ping, multi-service across all 7 transports

### Changed
- **DRY Template Method** — receive()/publish()/get_topic_name() moved to base Transporter
  (~250 lines eliminated). Subclasses only override send/connect/disconnect/_is_connected.
- **Transit SRP** — discovery logic extracted to Discoverer (discover_all, discover_node,
  request_discovery, _discover_pending). Transit delegates to broker.discoverer.
- **SubscriptionTopic TypedDict** — replaces dict[str, Any] for type safety
- **Typed attributes** — LatencyMonitor|None, logging.Logger, asyncio.Task[None]

### Fixed
- **AMQP broadcast consumer** — wrapped in try/except to prevent silent crash on unknown cmd
- **PROTOCOL_VERSION dedup** — single source of truth in base.py (was duplicated 4x)
- **NATS _is_connected** — checks nc.is_connected property, not just reference existence
- **Discoverer stop()** — guards on _started flag, not _tasks (fixes zero-interval config)

## [0.14.19] - 2026-04-06

### Fixed (Audit-driven fixes for v0.14.18 serializers — PRD-019)

Post-release audit by 9 expert agents (2 rounds) identified correctness, security,
and typing issues in the v0.14.18 CBOR/ProtoBuf implementation. All CRITICAL and
HIGH findings fixed, plus code quality improvements.

**Security (CRITICAL/HIGH):**
- `MAX_PAYLOAD_BYTES` now enforced in sync path via template method pattern in
  `BaseSerializer` — previously only async path checked, sync calls could OOM
- CBOR `tag_hook=_reject_tag` added — rejects unknown CBOR tags, pin `cbor2>=5.6.0`
  (CVE-2024-26130 fixed); documented limitation for well-known tags 0/1
- ProtoBuf JSON depth protection via `_check_json_depth()` pre-scan — prevents
  stack exhaustion DoS through deeply-nested attacker-controlled `meta`/`params`
- Silent `pass` in JSON parse failures replaced with `logger.warning` for observability
- Error messages sanitized — no payload content in exception strings
- Per-field size limit (`MAX_NESTED_FIELD_BYTES=1MB`) for nested JSON fields

**Correctness:**
- ProtoBuf `DATATYPE_BUFFER` branch added — bytes fields now round-trip correctly
  (was missing, resulted in base64 strings instead of bytes)
- `params=None` now correctly marks `DATATYPE_NULL` (was unreachable branch)
- `params=str` now JSON-stringified + base64 (was unhandled, caused proto error)
- NATS incoming `deserialize_async` now passes `packet_type` from meta —
  previously ProtoBuf hit bruteforce fallback silently
- NATS `publish_balanced_request/event` now pass `packet_type` explicitly

**Typing (strict mypy):**
- Added `PacketType = Literal[...]` with exhaustive 12 packet types in `types.py`
- Added `to_packet_type(value: str) -> PacketType` runtime validator
- `_VALID_PACKET_TYPES` derived from `get_args(PacketType)` — single source of truth
- Template method pattern: public `serialize`/`deserialize` enforce limits,
  subclasses implement `_serialize_impl`/`_deserialize_impl`
- Store-on-self pattern for optional modules (`self._cbor`, `self._mp`,
  `self._parse_dict`) — eliminates runtime `None` checks in hot path
- Two `except` clauses instead of `isinstance(e, SerializationError)` re-raise
- Removed dead TYPE_CHECKING aliases in cbor/msgpack/protobuf

**Code Quality:**
- `_HEARTBEAT_MAX_FIELDS` constant instead of magic number with `noqa`
- `_deserialize_bruteforce` warns each failed attempt via `logger.debug`
- `nats.disconnect()` clears `self.nc = None` in `finally` (was leak on timeout)
- JSON serializer logs `RecursionError` via `logger.warning` (DoS observability)
- `__init__.py` docstring updated to document all 4 serializers + usage examples

**Tests:**
- +33 audit-driven tests: DATATYPE_BUFFER/NULL/JSON roundtrip, DISCONNECT packet,
  RES with error dict, INFO with config/metadata, bruteforce fallback, heuristic
  resolver, PacketType validator, CBOR tag security, broker integration
- Unit: 2261 tests passing (was 2228)
- Serializer tests: 105 passing (was 72)
- Performance: all 4 serializers within 5% of v0.14.18 baseline

### Audit Evidence
- Round 1 (v0.14.18): 5 experts found 3 CRITICAL + 10 HIGH → all fixed
- Round 2 (v0.14.19): 4 Python-native experts found 0 CRIT, 3 P1 + 8 nits → all fixed

## [0.14.18] - 2026-04-06

### Added
- **CBOR Serializer** (PRD-019) — compact binary serialization without schema:
  - `CborSerializer` using `cbor2` library, ~29% smaller than JSON
  - Schema-less, wire-compatible with Node.js Moleculer CborSerializer (cbor-x)
  - `pip install moleculerpy[cbor]`
- **ProtoBuf Serializer** (PRD-019) — schema-based binary serialization:
  - `ProtoBufSerializer` using Google Protocol Buffers, ~25% smaller than JSON
  - `packets.proto` schema from Node.js Moleculer (all 12 packet types)
  - Custom field conversion matching Node.js base.js (services, meta, params → JSON strings)
  - `pip install moleculerpy[protobuf]`
- Serializers now 4/8: JSON, MsgPack, CBOR, ProtoBuf
- `Settings(serializer="cbor")` and `Settings(serializer="protobuf")` now accepted

## [0.14.17] - 2026-04-06

### Added
- **TCP Transporter with Gossip Protocol** (PRD-010) — peer-to-peer transport without external broker:
  - `TcpTransporter` with direct TCP messaging and Gossip-based service discovery
  - No external dependencies — pure asyncio P2P (no NATS, Redis, or Docker needed)
  - Gossip Protocol replaces HEARTBEAT/DISCOVER/INFO for node state exchange
  - `FrameParser` with 6-byte binary wire protocol (CRC + length + type), compatible with Node.js
  - `TcpReader` — asyncio TCP server with per-connection frame parsing, max incoming limit (256)
  - `TcpWriter` — outgoing connection pool with LRU eviction, lazy connect, 5s timeout
  - `UdpBroadcaster` — zero-config LAN discovery via UDP multicast (239.0.0.0:4445) or broadcast
  - Static URL config: string, array, dict, or `file://` (matching Node.js loadUrls)
  - Writer EOF detection via background monitor tasks (Node.js socket.on("end") equivalent)
  - TCP tuning: TCP_NODELAY + SO_KEEPALIVE (from Go reference)
  - Security: incoming connection cap, UDP payload size limit, port validation
  - 100% feature parity with Node.js TCP transporter (all 8 packet types, all gossip cases)
  - 84 unit tests + 5 integration tests (2-node P2P with real gossip discovery)
  - Performance: 196K req/sec local, 5.8K req/sec remote (0.17ms P2P latency)
  - 3 audit rounds (7+ agents): security, code quality, Node.js compat, test coverage, feature parity
  - `transporter="tcp://host:port/nodeID,host2:port2/nodeID2"` or `transporter="tcp://"` (UDP discovery)

### Changed
- `packet.py` — added GOSSIP_HELLO, GOSSIP_REQ, GOSSIP_RES topic types
- `node.py` — added `port` and `udp_address` slots to Node class
- `transporter/base.py` — registered TCP transporter in factory

## [0.14.16] - 2026-04-05

### Added
- **Kafka Transporter** (PRD-018) — high-throughput durable messaging:
  - `KafkaTransporter` with aiokafka producer/consumer
  - Batch topic subscription via `make_subscriptions()` (ConsumerGroup pattern)
  - AdminClient topic pre-creation for reliability
  - 24 unit tests + 5 integration tests with Docker Kafka (181K req/sec)
  - `pip install moleculerpy[kafka]`

## [0.14.15] - 2026-04-05

### Added
- **AMQP Transporter** (PRD-017) — enterprise RabbitMQ messaging with built-in load balancing:
  - `AmqpTransporter` with `hasBuiltInBalancer=True` (RabbitMQ work queues)
  - Fanout exchanges for broadcast (DISCOVER, INFO, HEARTBEAT, EVENT)
  - Direct queues for targeted packets (REQUEST, RESPONSE)
  - ACK/NACK for REQUEST packets (at-least-once delivery)
  - Configurable prefetch (default: 1), queue TTL, event/heartbeat TTL
  - Multi-URL cluster failover (round-robin)
  - 51 unit tests + 5 integration tests with Docker RabbitMQ
  - `pip install moleculerpy[amqp]` (aio-pika dependency)

### Fixed
- Transit: DISCONNECT added to self-echo topics (AMQP fanout echo compatibility)

## [0.14.14] - 2026-04-05

### Added
- **MQTT Transporter** (PRD-016) — lightweight pub/sub for IoT and edge computing:
  - `MqttTransporter` class with full Moleculer protocol v4 compatibility
  - Configurable QoS (0, 1, 2) and topic separator (default ".")
  - Lazy import of `aiomqtt` — graceful error when not installed
  - Wire-compatible with Node.js MqttTransporter topic format
  - Reconnect guard: safe to call connect() on already-connected transporter
  - Zombie state protection: broken connections detected and cleaned up
  - IPv6 address support in connection strings
  - `mqtts://` explicitly rejected until TLS support is added (prevents silent security issue)
  - 46 unit tests + 6 integration tests with Docker Mosquitto
  - Registered in transporter registry: `Settings(transporter="mqtt://host:1883")`

## [0.14.13] - 2026-04-05

### Fixed
- **Audit hotfix release** — accumulated fixes from audit cycles:
  - ZipkinExporter: ID truncation to Zipkin spec (16/32 hex), error spans, remoteEndpoint
  - ZipkinExporter: flush() runs HTTP in executor (non-blocking)
  - TracingMiddleware: service name extraction from action (was "unknown")
  - TracingMiddleware: parent-child span linking via ctx.parent_span
  - Tracer.stop(): async support for async exporters
  - broker.mcall(): input validation + options/timeout proxy
  - broker.ping(): transit.connected check + list[str] support
  - health: mem.percent = FREE (Node.js compat), os.uptime, process.argv
  - 35 new tests for broker gaps (mcall, ping, health, $node)

## [0.14.12] - 2026-04-04

### Added
- **$node Internal Service** — 7 introspection actions:
  - `$node.list` — list all cluster nodes
  - `$node.services` — list all services (filter: onlyLocal, skipInternal)
  - `$node.actions` — list all actions
  - `$node.events` — list all events
  - `$node.health` — system health (CPU, memory, OS, process)
  - `$node.options` — broker settings
  - `$node.metrics` — metrics listing
- **broker.mcall()** — parallel multi-action calls (list and dict formats)
  - `settled=True` for partial failure tolerance (like Promise.allSettled)
- **broker.ping()** — ping remote nodes, measure RTT
- **broker.get_health_status()** + `moleculerpy.health` module
  - Returns: cpu, mem, os, process, client, net, time
- Transit: `$node.pong` event emitted on PONG receive (enables broker.ping)

## [0.14.11] - 2026-04-04

### Added
- **Tracing Exporters: Jaeger + Zipkin** (PRD-015)
  - `ZipkinExporter`: batch HTTP POST to Zipkin API v2 (`/api/v2/spans`)
  - `JaegerExporter`: HTTP POST to Jaeger Zipkin collector endpoint
  - Zipkin v2 JSON format with microsecond timestamps
  - Periodic async flush with configurable interval (default 5s)
  - Graceful stop: flush remaining spans before shutdown
  - ID conversion: UUID → 64/128-bit hex (Node.js compatible)
  - Span tags flattened + stringified, annotations from logs
  - `default_tags` merged into every span
  - Zero new dependencies (stdlib `urllib.request`)
  - 58 unit tests + 3 E2E tests

### Fixed
- **Tracer.stop() async**: now properly awaits async exporters (was sync, caused
  RuntimeWarning with ZipkinExporter/JaegerExporter)

## [0.14.10] - 2026-04-04

### Added
- **LRU Memory Cacher** (PRD-014)
  - `MemoryLRUCacher` with bounded size and LRU eviction policy
  - `max` parameter limits cache entries (default: 1000)
  - Least-recently-used items evicted on overflow (O(1) via OrderedDict)
  - `get()` updates item recency — frequently accessed items stay cached
  - `get_with_ttl()` returns `(data, None)` — Node.js compatible
  - Registered as "MemoryLRU" and "memory-lru" in cacher registry
  - Warns on unsupported `lock.staleTime` option (Node.js compat)
  - `max < 1` raises ValueError (prevents infinite eviction loop)
  - 29 unit tests + 3 E2E tests
  - Zero new dependencies (stdlib `collections.OrderedDict`)

## [0.14.9] - 2026-04-03

### Added
- **Pluggable Validator System** (PRD-013)
  - `moleculerpy.validators` package with pluggable validator architecture
  - `BaseValidator` ABC: `init(broker)`, `compile(schema)`, `validate(params, schema)`
  - `BaseValidator.middleware()` returns middleware hooks (Node.js pattern)
  - `BaseValidator.convert_schema_to_moleculer()` for schema format conversion
  - `DefaultValidator` wrapping existing validation logic
  - `resolve_validator()` + `register_validator()` for plugin ecosystem
  - `Settings(validator=...)` broker option: "default", "none", False, class, instance
  - Compile-once-validate-many: `compile()` at action registration, checker at call time
  - Event parameter validation support via middleware hooks
  - 31 unit tests + 12 E2E tests

### Changed
- Broker validation: pre-compiled checker at registration time (was inline per-call)
- Action.__slots__ includes `_compiled_checker` for cached validator
- Broker `_wrap_service_handlers` uses `service.full_name` for action matching

## [0.14.8] - 2026-04-03

### Added
- **Pluggable Metrics Reporter System** (PRD-012)
  - `moleculerpy.metric_reporters` package with pluggable reporter architecture
  - `BaseReporter` ABC: `init(registry)`, `stop()`, `metric_changed()`, includes/excludes filtering
  - `ConsoleReporter`: periodic async metric output to logger (dev mode)
  - `PrometheusReporter`: `get_text()` pull-based Prometheus exposition format
  - `MetricRegistry` extended with `add_reporter()`, `stop_reporters()`, `list()` methods
  - Reporter resolution: `resolve_reporter("console")`, `resolve_reporter({"type": "prometheus"})`
  - `snapshot()` method on Counter, Gauge, Histogram for structured metric export
  - 58 unit tests + 4 E2E tests for reporter system

### Fixed
- **Lock contention in to_prometheus()**: snapshot metric keys under lock, render outside
  lock to avoid blocking registrations during Prometheus scrape
- **ConsoleReporter double-init leak**: cancel existing task before creating new one
- **ConsoleReporter silent no-loop**: log warning when init() called without event loop

## [0.14.7] - 2026-04-03

### Added
- **Service Versioning** (PRD-011)
  - `Service.version` attribute (int or str): `version = 2` → actions as `v2.users.get`
  - `Service.full_name` property: `"v2.users"` for versioned, `"users"` for plain
  - `Service.get_versioned_full_name()` static method (Node.js `service.js:835` compatible)
  - Multiple versions of same service coexist in registry: v1.users + v2.users
  - `$noVersionPrefix` setting suppresses version prefix
  - `$noServiceNamePrefix` setting removes service name prefix from action names
  - INFO packets include `version` and `fullName` fields per service
  - Remote node `fullName` reconstruction for backward compatibility
  - Wire protocol compatible with Node.js Moleculer versioned services

### Fixed
- **Settings propagation bug**: class-level `settings`, `metadata`, `dependencies` on
  services without mixins were not propagated to instances (pre-existing bug found during
  versioning work)
- **INFO action names**: `ensure_local_node()` now uses `handler._name` for action names
  (consistent with registry), not Python method names
- **version=0 handling**: numeric version `0` is now correctly treated as valid (not falsy)

### Changed
- `MixinSchema.version` type: `str` → `int | str` (supports numeric versions)
- Registry keys services by `full_name` instead of `name`

## [0.14.6] - 2026-03-31

### Added
- **Transit Message Handler Hook** (PRD-008)
  - 4th and final transit middleware hook: `transit_message_handler`
  - Intercepts packets after deserialization, before dispatch
  - Use for: auth, rate limiting, audit logging, packet filtering, metrics
  - 4/4 transit middleware hooks now complete (100% Node.js middleware API parity)

## [0.14.5] - 2026-03-31

### Added
- **Balanced Request/Event Handling** (PRD-009)
  - `Settings(disable_balancer=True)` enables native NATS queue group balancing
  - Balanced request topics: `MOL.REQB.<action>` with NATS queue groups
  - Balanced event topics: `MOL.EVENTB.<group>.<event>` with NATS queue groups
  - `prepublish()` routes ALL outgoing packets — balanced vs normal
  - `call_without_balancer()` bypasses broker strategy
  - `make_balanced_subscriptions()` subscribes for all local actions/events
  - Wire protocol compatible with Node.js Moleculer `disableBalancer: true`
  - E2E verified: 49/51 distribution on 100 requests across 2 nodes
- Codecov integration with PR coverage checks
- `codecov.yml` — project target auto, patch target 80%

### Fixed
- Balanced topic parsing: `REQB` → `REQUEST`, `EVENTB` → `EVENT` in packet.py
- Wildcard regex: `re.sub(r"\*\*.*$", ">", event)` matches Node.js behavior
- Disconnected check in `prepublish` — raises `BrokerDisconnectedError`
- `call_without_balancer` guard for `transit=None`

## [0.14.4] - 2026-03-31

### Added
- **Pluggable Serializer System** (PRD-007)
  - `BaseSerializer` ABC with sync/async methods and thread offload (>1MB)
  - `JsonSerializer` — extracted from transporters, proper error handling
  - `MsgPackSerializer` — 2x faster throughput, 40-64% smaller payloads on large data
  - `resolve_serializer()` factory — `Settings(serializer="msgpack")` just works
  - `SerializationError` in error hierarchy
  - `MAX_PAYLOAD_BYTES` (8MB) protection against DoS
  - `pip install moleculerpy[msgpack]` for MsgPack support
- **Transit P0 Safety Fixes** (PRD-006)
  - Protocol version check — reject packets with incompatible `ver`
  - NodeID conflict detection — graceful shutdown on duplicate ID
  - `_SELF_ECHO_TOPICS` exclusion (DISCOVER, HEARTBEAT, INFO)
  - `_shutting_down` guard against repeated `broker.stop()`
  - `ServiceNotFoundError` instead of generic `Exception`
- **Pre-commit hooks** — ruff format + check on commit, mypy + pytest on push
- Demo app `--serializer` flag for JSON/MSGPACK selection

### Fixed
- Middleware order for `transporter_receive` — `reversed()` symmetric with send
- Remote requests/events now use `wrapped_handler` (middleware bypass fix)
- Memory transporter double-deserialization eliminated (sender via meta dict)
- MsgPack `strict_map_key=True` preventing integer key bypass
- JSON deserializer catches `RecursionError` (nested bomb protection)
- Log injection prevention — `%r` for network-supplied data
- 9 pre-existing mypy errors fixed (encryption.py, action_logger.py, context_tracker.py)
- `setattr` → direct assignment in context_tracker.py (ruff B010)

### Changed
- All transporters use pluggable `transit.serializer` instead of hardcoded JSON
- `_broker` typed as `ServiceBroker | None` (was `Any`)
- `_wrapped_publish` typed as `Callable[[Packet], Awaitable[None]] | None` (was `Any`)
- `PROTOCOL_VERSION` constant in transit.py
- Pre-commit ruff updated v0.1.10 → v0.15.0
- 22 middlewares (was 19 in docs)

## [0.14.1] - 2026-01-31

### Added
- Initial public release as MoleculerPy (rebranded from pylecular)
- Full service lifecycle management
- NATS, Redis, and Memory transporters
- 19 built-in middlewares:
  - Circuit Breaker, Bulkhead, Retry, Timeout, Fallback
  - Caching (Memory, Redis)
  - Compression, Encryption
  - Metrics, Tracing, Validator
  - Action Logger, Context Tracker, Error Handler
  - Debounce, Throttle, Hot Reload
- 5 load balancing strategies:
  - Round Robin, Random, CPU Usage, Latency, Sharding
- Built-in metrics with Prometheus exporter
- Built-in tracing with Console exporter
- Streaming support for large data transfer
- Service mixins
- Event-driven architecture with balanced events
- CLI for starting brokers and loading services

### Changed
- Renamed package from `pylecular` to `moleculerpy`
- Updated all imports and references

### Notes
- Version 0.14.1 indicates compatibility with Moleculer Protocol v4 (Moleculer.js 0.14.x)

### Credits
- Based on [pylecular](https://github.com/alvaroinckot/pylecular) by Alvaro Inckot
- Inspired by [Moleculer.js](https://moleculer.services)

## [Unreleased]

### Added
- Domain primitive `NewType` aliases (NodeID, ServiceName, ActionName, EventName, ContextID, RequestID)
- Context kind guards for action/event/internal intent
- Graceful broker shutdown timeout setting
- Wildcard event matching in registry (`*`, `**`)

### Changed
- Broadcast fan-out now follows Moleculer.js `Promise.all` semantics (handler errors propagate)
- Service lifecycle hook dispatch refactored with `match/case` (no behavior change)
- Core models use `__slots__` with extension maps for dynamic attrs (Context, Service, Packet, Registry, Node)

### Fixed
- Registry action/event lookups now indexed (O(1) vs O(N))
- Encryption/compression offloaded for large payloads to avoid event loop blocking
- Transporter disconnects now have timeouts (NATS/Redis)
- Memory transporter task cleanup on disconnect
- Debounce no longer swallows errors (logs warnings)
- Circuit breaker error hierarchy corrected; `RemoteCallError` registered
- Middleware hook gather no longer swallows exceptions
- Streaming cleanup for cancelled streams; pending streams cleared on close
- Silent topic skips in transporters now logged

### Performance
- Reduced allocations in registry event/action selection
- Large JSON deserialization offloaded for >1MB payloads
- Removed task naming overhead in hot paths
- Simplified missing-service scans in broker

### Planned
- Kafka transporter
- AMQP transporter
- REST API Gateway (moleculerpy-web)
- Database adapters (moleculerpy-db)
- GraphQL gateway
- gRPC support
