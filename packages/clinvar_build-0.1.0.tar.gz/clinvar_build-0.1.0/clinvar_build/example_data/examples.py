"""
Provides centralised access to example data sets that can be used in tests
and also in example code and/or jupyter notebooks.

Notes
-----
Data can be "added" either through functions that generate the data on the fly
or via functions that load the data from a static file located in the
``example_data`` directory. The data files being added  should be as small as
possible (i.e. kilobyte/megabyte range). The dataset functions should be
decorated with the ``@dataset`` decorator, so the example module knows about
them. If the function is loading a dataset from a file in the package, it
should look for the path in ``_ROOT_DATASETS_DIR``.

Examples
--------

Registering a function as a dataset providing function:

>>> @dataset
>>> def dummy_data(*args, **kwargs):
>>>     \"\"\"A dummy dataset function that returns a small list.
>>>
>>>     Returns
>>>     -------
>>>     data : `list`
>>>         A list of length 3 with ``['A', 'B', 'C']``
>>>
>>>     Notes
>>>     -----
>>>     This function is called ``dummy_data`` and has been decorated with a
>>>     ``@dataset`` decorator which makes it available with the
>>>     `example_data.get_data(<NAME>)` function and also
>>>     `example_data.help(<NAME>)` functions.
>>>     \"\"\"
>>>     return ['A', 'B', 'C']

The dataset can then be used as follows:

>>> from skeleton_package.example_data import examples
>>> examples.get_data('dummy_data')
>>> ['A', 'B', 'C']

A dataset function that loads a dataset from file, these functions should load
 from the ``_ROOT_DATASETS_DIR``:

>>> @dataset
>>> def dummy_load_data(*args, **kwargs):
>>>     \"\"\"A dummy dataset function that loads a string from a file.
>>>
>>>     Returns
>>>     -------
>>>     str_data : `str`
>>>         A string of data loaded from an example data file.
>>>
>>>     Notes
>>>     -----
>>>     This function is called ``dummy_data`` and has been decorated with a
>>>     ``@dataset`` decorator which makes it available with the
>>>     `example_data.get_data(<NAME>)` function and also
>>>     `example_data.help(<NAME>)` functions. The path to this dataset is
>>>     built from ``_ROOT_DATASETS_DIR``.
>>>     \"\"\"
>>>     load_path = os.path.join(_ROOT_DATASETS_DIR, "string_data.txt")
>>>     with open(load_path) as data_file:
>>>         return data_file.read().strip()

The dataset can then be used as follows:

>>> from skeleton_package.example_data import examples
>>> examples.get_data('dummy_load_data')
>>> 'an example data string'
"""
import os
import re
import sqlite3
from pathlib import Path
from typing import Any

# The name of the example datasets directory
_EXAMPLE_DATASETS = "example_datasets"
"""The example dataset directory name (`str`)
"""

_ROOT_DATASETS_DIR = os.path.join(os.path.dirname(__file__), _EXAMPLE_DATASETS)
"""The root path to the dataset files that are available (`str`)
"""

_DATASETS = dict()
"""This will hold the registered dataset functions (`dict`)
"""

_EXAMPLE_VCV_XML = os.path.join(_ROOT_DATASETS_DIR, "VCV.xml.gz")
"""A subset of complete VariationArchive records"""

_EXAMPLE_RCV_XML = os.path.join(_ROOT_DATASETS_DIR, "RCV.xml.gz")
"""A subset of complete ClinVarSet records. """

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def dataset(func):
    """Register a dataset generating function. This function should be used as
    a decorator.
    
    Parameters
    ----------
    func : `function`
        The function to register as a dataset. It is registered as under the
        function name.
    
    Returns
    -------
    func : `function`
        The function that has been registered.
    
    Raises
    ------
    KeyError
        If a function of the same name has already been registered.
    
    Notes
    -----
    The dataset function should accept ``*args`` and ``**kwargs`` and should be
    decorated with the ``@dataset`` decorator.
    
    Examples
    --------
    Create a dataset function that returns a dictionary.
    
    >>> @dataset
    >>> def get_dict(*args, **kwargs):
    >>>     \"\"\"A dictionary to test or use as an example.
    >>>
    >>>     Returns
    >>>     -------
    >>>     test_dict : `dict`
    >>>         A small dictionary of string keys and numeric values
    >>>     \"\"\"
    >>>     return {'A': 1, 'B': 2, 'C': 3}
    >>>
    
    The dataset can then be used as follows:
    
    >>> from skeleton_package.example_data import examples
    >>> examples.get_data('get_dict')
    >>> {'A': 1, 'B': 2, 'C': 3}
    
    """
    try:
        _DATASETS[func.__name__]
        raise KeyError("function already registered")
    except KeyError:
        pass
    
    _DATASETS[func.__name__] = func
    return func


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_data(name, *args, **kwargs):
    """Central point to get the datasets.
    
    Parameters
    ----------
    name : `str`
        A name for the dataset that should correspond to a registered
        dataset function.
    *args
        Arguments to the data generating functions
    **kwargs
        Keyword arguments to the data generating functions
    
    Returns
    -------
    dataset : `Any`
        The requested datasets
    """
    try:
        return _DATASETS[name](*args, **kwargs)
    except KeyError as e:
        raise KeyError("dataset not available: {0}".format(name)) from e

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def list_datasets():
    """List all the registered datasets.
    
    Returns
    -------
    datasets : `list` of `tuple`
        The registered datasets. Element [0] for each tuple is the dataset name
        and element [1] is a short description captured from the docstring.
    """
    datasets = []
    for d in _DATASETS.keys():
        desc = re.sub(
            r'(Parameters|Returns).*$', '', _DATASETS[d].__doc__.replace(
                '\n', ' '
            )
        ).strip()
        datasets.append((d, desc))
    return datasets

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def help(name):
    """Central point to get help for the datasets.
    
    Parameters
    ----------
    name : `str`
        A name for the dataset that should correspond to a unique key in the
        DATASETS module level dictionary.
    
    Returns
    -------
    help : `str`
        The docstring for the function
    """
    docs = ["Dataset: {0}\n{1}\n\n".format(name, "-" * (len(name) + 9))]
    try:
        docs.extend(
            ["{0}\n".format(re.sub(r"^\s{4}", "", i))
             for i in _DATASETS[name].__doc__.split("\n")]
        )
        return "".join(docs)
    except KeyError as e:
        raise KeyError("dataset not available: {0}".format(name)) from e

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _infer_sql_type(value: Any) -> str:
    """Infer SQLite column type from a Python value.

    Parameters
    ----------
    value : `Any`
        A Python value whose type is to be mapped.

    Returns
    -------
    sql_type : `str`
        SQLite type string: ``'INTEGER'``, ``'REAL'``, or ``'TEXT'``.
    """
    if value is None:
        return "TEXT"
    if isinstance(value, bool):
        return "INTEGER"
    if isinstance(value, int):
        return "INTEGER"
    if isinstance(value, float):
        return "REAL"
    return "TEXT"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _create_db(db_path: str | Path, data: dict) -> Path:
    """Create a SQLite database from a dictionary of table data.

    Parameters
    ----------
    db_path : `str` or `Path`
        Destination path for the new SQLite database file.
    data : `dict`
        Mapping of table name to a list of row dicts (as returned by
        dataset functions such as `vcv_variant_query_data` and
        `rcv_condition_query_data`).

    Returns
    -------
    db_path : `Path`
        Resolved path to the created database file.
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    for table_name, rows in data.items():
        if not rows:
            continue
        columns = list(rows[0].keys())
        col_defs = ", ".join(
            f"{col} {_infer_sql_type(rows[0][col])}" for col in columns
        )
        cursor.execute(f"CREATE TABLE {table_name} ({col_defs})")
        placeholders = ",".join("?" * len(columns))
        col_str = ",".join(columns)
        for row in rows:
            cursor.execute(
                f"INSERT INTO {table_name} ({col_str}) VALUES ({placeholders})",
                [row[c] for c in columns],
            )
    conn.commit()
    conn.close()
    return Path(db_path)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def vcv_parse_dict() -> dict[str, Any]:
    """
    A dictionary with parsing instructions for the VCV clinvar XML file.
    
    Returns
    -------
    dict
        A dictionary with XML parsing instructions.
    """
    config = {
        "_meta": {
            "progress_table": "VCVParseProgress",
            "root_element": "ClinVarVariationRelease",
            "record_element": "VariationArchive",
            "accession_attr": "Accession",
        },
        "ClinVarVariationRelease": {
            "returns_id": "false",
            "parent_id": None,
            "attributes": {
                "release_date": {"xml_attr": "ReleaseDate"},
            },
            "children": [],
            "sql": {
                "statement": "INSERT INTO",
                "table_name": "ClinVarVariationRelease",
                "columns": ["release_date"],
            },
        },
        "VariationArchive": {
            "returns_id": "variation_archive_id",
            "parent_id": None,
            "attributes": {
                "variation_id": {
                    "xml_attr": "VariationID", "cast": "int",
                },
                "variation_name": {
                    "xml_attr": "VariationName",
                },
                "variation_type": {
                    "xml_attr": "VariationType",
                },
                "accession": {
                    "xml_attr": "Accession",
                },
                "version": {
                    "xml_attr": "Version", "cast": "int",
                },
            },
            "children": [
                {
                    "xpath": "./Comment", "table": "Comment",
                    "entity_type": "VariationArchive",
                },
                {
                    "xpath": "./ClassifiedRecord/SimpleAllele",
                 "table": "SimpleAllele",
                },
                {
                    "xpath": "./ClassifiedRecord/RCVList/RCVAccession",
                 "table": "RCVAccession"
                },
            ],
            "sql": {
                "statement": "INSERT INTO",
                "table_name": "VariationArchive",
                "columns": [
                    "variation_id", "variation_name", "variation_type",
                    "accession", "version",
                ],
            },
        },
        "SimpleAllele": {
            "returns_id": "simple_allele_id",
            "parent_id": "variation_archive_id",
            "attributes": {
                "allele_id": {
                    "xml_attr": "AlleleID", "cast": "int",
                },
                "variation_id": {
                    "xml_attr": "VariationID", "cast": "int",
                },
                "name": {
                    "xml_path": "./Name", "xml_text": True,
                },
                "variant_type": {
                    "xml_path": ".//VariantType", "xml_text": True,
                },
            },
            "children": [
                {"xpath": ".//Gene", "table": "Gene"},
                {"xpath": "./XRefList/XRef", "table": "XRef",
                 "entity_type": "SimpleAllele"},
            ],
            "sql": {
                "statement": "INSERT OR IGNORE INTO",
                "table_name": "SimpleAllele",
                "columns": [
                    "variation_archive_id", "allele_id", "variation_id",
                    "name", "variant_type",
                ],
            },
        },
        "Gene": {
            "returns_id": "gene_id",
            "parent_id": "simple_allele_id",
            "attributes": {
                "gene_id": {
                    "xml_attr": "GeneID", "cast": "int",
                },
                "symbol": {
                    "xml_attr": "Symbol",
                },
                "full_name": {
                    "xml_attr": "FullName",
                },
            },
            "children": [
                {"xpath": "./Location/SequenceLocation",
                 "table": "SequenceLocation"}
            ],
            "sql": {
                "statement": "INSERT OR IGNORE INTO",
                "table_name": "Gene",
                "columns": [
                    "simple_allele_id", "gene_id", "symbol", "full_name",
                ],
            },
        },
        "SequenceLocation": {
            "returns_id": False,
            "parent_id": "gene_id",
            "attributes": {
                "assembly": {
                    "xml_attr": "Assembly",
                },
                "chr": {
                    "xml_attr": "Chr",
                },
                "start": {
                    "xml_attr": "start", "cast": "int",
                },
                "stop": {
                    "xml_attr": "stop", "cast": "int",
                },
            },
            "children": [],
            "sql": {
                "statement": "INSERT OR IGNORE INTO",
                "table_name": "SequenceLocation",
                "columns": [
                    "gene_id", "assembly", "chr", "start", "stop",
                ],
            }
        },
        "RCVAccession": {
            "returns_id": "rcv_accession_id",
            "parent_id": "variation_archive_id",
            "attributes": {
                "accession": {
                    "xml_attr": "Accession",
                },
                "version": {
                    "xml_attr": "Version", "cast": "int",
                },
                "title": {
                    "xml_attr": "Title",
                },
            },
            "children": [
                {"xpath": ".//ClassifiedCondition",
                 "table": "ClassifiedCondition"},
            ],
            "sql": {
                "statement": "INSERT INTO",
                "table_name": "RCVAccession",
                "columns": ["variation_archive_id", "accession", "version",
                           "title"],
            }
        },
        "ClassifiedCondition": {
            "returns_id": False,
            "parent_id": "rcv_accession_id",
            "attributes": {
                "db": {
                    "xml_attr": "DB",
                },
                "condition_id": {
                    "xml_attr": "ID",
                },
                "name": {
                    "xml_text": True
                }
            },
            "children": [],
            "sql": {
                "statement": "INSERT OR IGNORE INTO",
                "table_name": "ClassifiedCondition",
                "columns": [
                    "rcv_accession_id", "db", "condition_id", "name",
                ],
            }
        },
        "XRef": {
            "returns_id": False,
            "parent_id": "entity_id",
            "attributes": {
                "db": {
                    "xml_attr": "DB",
                },
                "xref_id": {
                    "xml_attr": "ID",
                },
                "xref_type": {
                    "xml_attr": "Type",
                },
            },
            "children": [],
            "sql": {
                "statement": "INSERT OR IGNORE INTO",
                "table_name": "XRef",
                "columns": [
                    "entity_type", "entity_id", "db", "xref_id", "xref_type",
                ],
            }
        },
        "Comment": {
            "returns_id": False,
            "parent_id": "entity_id",
            "attributes": {
                "comment_type": {
                    "xml_attr": "Type",
                },
                "data_source": {
                    "xml_attr": "DataSource",
                },
                "value": {
                    "xml_text": True,
                }
            },
            "children": [],
            "sql": {
                "statement": "INSERT OR IGNORE INTO",
                "table_name": "Comment",
                "columns": [
                    "entity_type", "entity_id", "comment_type", "data_source",
                    "value",
                ],
            }
        },
    }
    return config

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def vcv_variant_query_data() -> dict[str, list[dict]]:
    """
    Test data for VariantQuery class from VCV database.
    
    Returns
    -------
    dict
        Dictionary with table names as keys and list of row dicts as
        values. Tables: VariationArchive, SimpleAllele, Gene,
        AlleleLocation, AggregateClassification.
    
    Notes
    -----
    Contains 5 variants from different genes (TSPAN12, CPOX, FECH, APC,
    NHEJ1) with GRCh38 locations. All are Pathogenic classification.
    """
    data = {
        "VariationArchive": [
            {
                "id": 1,
                "variation_id": 323,
                "variation_name": "NM_012338.4(TSPAN12):c.361-5_361-1del",
                "variation_type": "Deletion",
                "accession": "VCV000000323",
                "version": 1,
                "record_status": "current",
                "record_type": "classified",
                "species": "Homo sapiens",
                "date_created": "2016-10-23",
                "date_last_updated": "2022-04-25",
                "most_recent_submission": "2016-10-23",
                "number_of_submitters": 1,
                "number_of_submissions": 1,
            },
            {
                "id": 3,
                "variation_id": 455,
                "variation_name": (
                    "NM_000097.7(CPOX):c.489_509del (p.Cys164_Val170del)"
                ),
                "variation_type": "Deletion",
                "accession": "VCV000000455",
                "version": 2,
                "record_status": "current",
                "record_type": "classified",
                "species": "Homo sapiens",
                "date_created": "2020-05-31",
                "date_last_updated": "2022-04-25",
                "most_recent_submission": "2020-05-31",
                "number_of_submitters": 1,
                "number_of_submissions": 1,
            },
            {
                "id": 8,
                "variation_id": 556,
                "variation_name": "NM_000140.5(FECH):c.314+6A>C",
                "variation_type": "single nucleotide variant",
                "accession": "VCV000000556",
                "version": 1,
                "record_status": "current",
                "record_type": "classified",
                "species": "Homo sapiens",
                "date_created": "2018-06-22",
                "date_last_updated": "2025-01-13",
                "most_recent_submission": "2018-06-22",
                "number_of_submitters": 1,
                "number_of_submissions": 1,
            },
            {
                "id": 10,
                "variation_id": 826,
                "variation_name": "NM_000038.6(APC):c.1311_1312+1del",
                "variation_type": "Deletion",
                "accession": "VCV000000826",
                "version": 2,
                "record_status": "current",
                "record_type": "classified",
                "species": "Homo sapiens",
                "date_created": "2016-10-23",
                "date_last_updated": "2023-03-11",
                "most_recent_submission": "2023-03-11",
                "number_of_submitters": 2,
                "number_of_submissions": 2,
            },
            {
                "id": 15,
                "variation_id": 984,
                "variation_name": (
                    "NM_024782.3(NHEJ1):c.177+1_177+3delinsTT"
                ),
                "variation_type": "Indel",
                "accession": "VCV000000984",
                "version": 2,
                "record_status": "current",
                "record_type": "classified",
                "species": "Homo sapiens",
                "date_created": "2013-09-21",
                "date_last_updated": "2024-09-01",
                "most_recent_submission": "2024-09-01",
                "number_of_submitters": 1,
                "number_of_submissions": 1,
            },
        ],
        "SimpleAllele": [
            {
                "id": 1,
                "variation_archive_id": 1,
                "allele_id": 15362,
                "variation_id": 323,
                "name": "NM_012338.4(TSPAN12):c.361-5_361-1del",
                "common_name": None,
                "canonical_spdi": "NC_000007.14:120810570:CTGGT:",
                "variant_type": "Deletion",
                "global_maf_value": None,
                "global_maf_source": None,
                "global_maf_minor_allele": None,
            },
            {
                "id": 3,
                "variation_archive_id": 3,
                "allele_id": 15494,
                "variation_id": 455,
                "name": (
                    "NM_000097.7(CPOX):c.489_509del (p.Cys164_Val170del)"
                ),
                "common_name": None,
                "canonical_spdi": (
                    "NC_000003.12:98592995:ACCTGTGCCAGAGCCTGGCACACCTG:ACCTG"
                ),
                "variant_type": "Deletion",
                "global_maf_value": None,
                "global_maf_source": None,
                "global_maf_minor_allele": None,
            },
            {
                "id": 8,
                "variation_archive_id": 8,
                "allele_id": 15595,
                "variation_id": 556,
                "name": "NM_000140.5(FECH):c.314+6A>C",
                "common_name": None,
                "canonical_spdi": "NC_000018.10:57573239:T:G",
                "variant_type": "single nucleotide variant",
                "global_maf_value": None,
                "global_maf_source": None,
                "global_maf_minor_allele": None,
            },
            {
                "id": 10,
                "variation_archive_id": 10,
                "allele_id": 15865,
                "variation_id": 826,
                "name": "NM_000038.6(APC):c.1311_1312+1del",
                "common_name": None,
                "canonical_spdi": "NC_000005.10:112819342:AAG:",
                "variant_type": "Deletion",
                "global_maf_value": None,
                "global_maf_source": None,
                "global_maf_minor_allele": None,
            },
            {
                "id": 15,
                "variation_archive_id": 15,
                "allele_id": 16023,
                "variation_id": 984,
                "name": "NM_024782.3(NHEJ1):c.177+1_177+3delinsTT",
                "common_name": None,
                "canonical_spdi": "NC_000002.12:219158182:TAC:AA",
                "variant_type": "Indel",
                "global_maf_value": None,
                "global_maf_source": None,
                "global_maf_minor_allele": None,
            },
        ],
        "Gene": [
            {
                "id": 1,
                "simple_allele_id": 1,
                "gene_id": 23554,
                "symbol": "TSPAN12",
                "full_name": "tetraspanin 12",
                "hgnc_id": "HGNC:21641",
                "source": "submitted",
                "relationship_type": "within single gene",
                "haploinsufficiency": None,
                "haploinsufficiency_last_evaluated": None,
                "haploinsufficiency_clingen": None,
                "triplosensitivity": None,
                "triplosensitivity_last_evaluated": None,
                "triplosensitivity_clingen": None,
            },
            {
                "id": 5,
                "simple_allele_id": 3,
                "gene_id": 1371,
                "symbol": "CPOX",
                "full_name": "coproporphyrinogen oxidase",
                "hgnc_id": "HGNC:2321",
                "source": "submitted",
                "relationship_type": "within single gene",
                "haploinsufficiency": None,
                "haploinsufficiency_last_evaluated": None,
                "haploinsufficiency_clingen": None,
                "triplosensitivity": None,
                "triplosensitivity_last_evaluated": None,
                "triplosensitivity_clingen": None,
            },
            {
                "id": 16,
                "simple_allele_id": 8,
                "gene_id": 2235,
                "symbol": "FECH",
                "full_name": "ferrochelatase",
                "hgnc_id": "HGNC:3647",
                "source": "submitted",
                "relationship_type": "within single gene",
                "haploinsufficiency": None,
                "haploinsufficiency_last_evaluated": None,
                "haploinsufficiency_clingen": None,
                "triplosensitivity": None,
                "triplosensitivity_last_evaluated": None,
                "triplosensitivity_clingen": None,
            },
            {
                "id": 19,
                "simple_allele_id": 10,
                "gene_id": 324,
                "symbol": "APC",
                "full_name": "APC regulator of WNT signaling pathway",
                "hgnc_id": "HGNC:583",
                "source": "submitted",
                "relationship_type": "within single gene",
                "haploinsufficiency": (
                    "Sufficient evidence for dosage pathogenicity"
                ),
                "haploinsufficiency_last_evaluated": "2021-07-18",
                "haploinsufficiency_clingen": (
                    "https://www.ncbi.nlm.nih.gov/projects/dbvar/ISCA/"
                    "isca_gene.cgi?sym=APC"
                ),
                "triplosensitivity": "No evidence available",
                "triplosensitivity_last_evaluated": "2021-07-18",
                "triplosensitivity_clingen": (
                    "https://www.ncbi.nlm.nih.gov/projects/dbvar/ISCA/"
                    "isca_gene.cgi?sym=APC"
                ),
            },
            {
                "id": 24,
                "simple_allele_id": 15,
                "gene_id": 79840,
                "symbol": "NHEJ1",
                "full_name": "non-homologous end joining factor 1",
                "hgnc_id": "HGNC:25737",
                "source": "submitted",
                "relationship_type": "within single gene",
                "haploinsufficiency": None,
                "haploinsufficiency_last_evaluated": None,
                "haploinsufficiency_clingen": None,
                "triplosensitivity": None,
                "triplosensitivity_last_evaluated": None,
                "triplosensitivity_clingen": None,
            },
        ],
        "AlleleLocation": [
            {
                "id": 1,
                "simple_allele_id": 1,
                "for_display": 1,
                "assembly": "GRCh38",
                "assembly_accession_version": "GCF_000001405.38",
                "assembly_status": "current",
                "chr": "7",
                "accession": "NC_000007.14",
                "start": 120810571,
                "stop": 120810575,
                "display_start": 120810571,
                "display_stop": 120810575,
                "variant_length": 5,
                "position_vcf": 120810570,
                "reference_allele_vcf": "CCTGGT",
                "alternate_allele_vcf": "C",
            },
            {
                "id": 5,
                "simple_allele_id": 3,
                "for_display": 1,
                "assembly": "GRCh38",
                "assembly_accession_version": "GCF_000001405.38",
                "assembly_status": "current",
                "chr": "3",
                "accession": "NC_000003.12",
                "start": 98592996,
                "stop": 98593016,
                "display_start": 98592996,
                "display_stop": 98593016,
                "variant_length": 21,
                "position_vcf": 98592995,
                "reference_allele_vcf": "TACCTGTGCCAGAGCCTGGCAC",
                "alternate_allele_vcf": "T",
            },
            {
                "id": 11,
                "simple_allele_id": 8,
                "for_display": 1,
                "assembly": "GRCh38",
                "assembly_accession_version": "GCF_000001405.38",
                "assembly_status": "current",
                "chr": "18",
                "accession": "NC_000018.10",
                "start": 57573240,
                "stop": 57573240,
                "display_start": 57573240,
                "display_stop": 57573240,
                "variant_length": 1,
                "position_vcf": 57573240,
                "reference_allele_vcf": "T",
                "alternate_allele_vcf": "G",
            },
            {
                "id": 13,
                "simple_allele_id": 10,
                "for_display": 1,
                "assembly": "GRCh38",
                "assembly_accession_version": "GCF_000001405.38",
                "assembly_status": "current",
                "chr": "5",
                "accession": "NC_000005.10",
                "start": 112819343,
                "stop": 112819345,
                "display_start": 112819343,
                "display_stop": 112819345,
                "variant_length": 3,
                "position_vcf": 112819342,
                "reference_allele_vcf": "CAAG",
                "alternate_allele_vcf": "C",
            },
            {
                "id": 19,
                "simple_allele_id": 15,
                "for_display": 1,
                "assembly": "GRCh38",
                "assembly_accession_version": "GCF_000001405.38",
                "assembly_status": "current",
                "chr": "2",
                "accession": "NC_000002.12",
                "start": 219158183,
                "stop": 219158185,
                "display_start": 219158183,
                "display_stop": 219158185,
                "variant_length": 3,
                "position_vcf": 219158183,
                "reference_allele_vcf": "TAC",
                "alternate_allele_vcf": "AA",
            },
        ],
        "AggregateClassification": [
            {
                "id": 1,
                "variation_archive_id": 1,
                "classification_type": "GermlineClassification",
                "review_status": "no assertion criteria provided",
                "description": "Pathogenic",
                "explanation": None,
                "date_last_evaluated": "2010-02-12",
                "number_of_submissions": 1,
                "number_of_submitters": 1,
                "date_created": "2016-10-23",
                "most_recent_submission": "2016-10-23",
            },
            {
                "id": 3,
                "variation_archive_id": 3,
                "classification_type": "GermlineClassification",
                "review_status": "no assertion criteria provided",
                "description": "Pathogenic",
                "explanation": None,
                "date_last_evaluated": "1997-01-01",
                "number_of_submissions": 1,
                "number_of_submitters": 1,
                "date_created": "2020-05-31",
                "most_recent_submission": "2020-05-31",
            },
            {
                "id": 8,
                "variation_archive_id": 8,
                "classification_type": "GermlineClassification",
                "review_status": "no assertion criteria provided",
                "description": "Pathogenic",
                "explanation": None,
                "date_last_evaluated": "1998-07-01",
                "number_of_submissions": 1,
                "number_of_submitters": 1,
                "date_created": "2018-06-22",
                "most_recent_submission": "2018-06-22",
            },
            {
                "id": 10,
                "variation_archive_id": 10,
                "classification_type": "GermlineClassification",
                "review_status": "reviewed by expert panel",
                "description": "Pathogenic",
                "explanation": None,
                "date_last_evaluated": "2023-02-19",
                "number_of_submissions": 2,
                "number_of_submitters": 2,
                "date_created": "2016-10-23",
                "most_recent_submission": "2023-03-11",
            },
            {
                "id": 15,
                "variation_archive_id": 15,
                "classification_type": "GermlineClassification",
                "review_status": "no assertion criteria provided",
                "description": "Pathogenic",
                "explanation": None,
                "date_last_evaluated": "2006-01-27",
                "number_of_submissions": 1,
                "number_of_submitters": 1,
                "date_created": "2013-09-21",
                "most_recent_submission": "2024-09-01",
            },
        ],
        "ClinicalAssertion": [
            {
                "id": 1,
                "variation_archive_id": 1,
                "clinical_assertion_id": 20495,
                "accession": "SCV000020495",
                "version": 6,
                "submitter_name": "OMIM",
                "org_id": 3,
                "organisation_category": "resource",
                "org_abbreviation": None,
                "assertion": "variation to disease",
                "review_status": "no assertion criteria provided",
                "germline_classification": "Pathogenic",
                "somatic_clinical_impact": None,
                "oncogenicity_classification": None,
                "date_last_evaluated": "2010-02-12",
                "no_classification": None,
                "date_created": "2013-04-04",
                "date_updated": "2016-10-23",
                "submission_date": "2016-10-21",
                "local_key": (
                    "613138.0005_EXUDATIVE VITREORETINOPATHY 5"
                ),
                "title": (
                    "TSPAN12, IVS5AS, 5-BP DEL, NT361-5_"
                    "EXUDATIVE VITREORETINOPATHY 5"
                ),
                "local_key_is_submitted": None,
                "submitted_assembly": None,
                "record_status": "current",
                "fda_recognised_database": None,
                "contributes_to_aggregate_classification": 1,
            },
            {
                "id": 5,
                "variation_archive_id": 3,
                "clinical_assertion_id": 20633,
                "accession": "SCV000020633",
                "version": 4,
                "submitter_name": "OMIM",
                "org_id": 3,
                "organisation_category": "resource",
                "org_abbreviation": None,
                "assertion": "variation to disease",
                "review_status": "no assertion criteria provided",
                "germline_classification": "Pathogenic",
                "somatic_clinical_impact": None,
                "oncogenicity_classification": None,
                "date_last_evaluated": "1997-01-01",
                "no_classification": None,
                "date_created": "2013-04-04",
                "date_updated": "2020-05-31",
                "submission_date": "2020-05-22",
                "local_key": "612732.0005_COPROPORPHYRIA",
                "title": "CPOX, 21-BP DEL_COPROPORPHYRIA",
                "local_key_is_submitted": None,
                "submitted_assembly": None,
                "record_status": "current",
                "fda_recognised_database": None,
                "contributes_to_aggregate_classification": 1,
            },
            {
                "id": 10,
                "variation_archive_id": 8,
                "clinical_assertion_id": 20735,
                "accession": "SCV000020735",
                "version": 4,
                "submitter_name": "OMIM",
                "org_id": 3,
                "organisation_category": "resource",
                "org_abbreviation": None,
                "assertion": "variation to disease",
                "review_status": "no assertion criteria provided",
                "germline_classification": "Pathogenic",
                "somatic_clinical_impact": None,
                "oncogenicity_classification": None,
                "date_last_evaluated": "1998-07-01",
                "no_classification": None,
                "date_created": "2013-04-04",
                "date_updated": "2018-06-22",
                "submission_date": "2018-06-19",
                "local_key": (
                    "612386.0009_PROTOPORPHYRIA, ERYTHROPOIETIC, 1"
                ),
                "title": (
                    "FECH, IVS3DS, A-C, +6_"
                    "PROTOPORPHYRIA, ERYTHROPOIETIC, 1"
                ),
                "local_key_is_submitted": None,
                "submitted_assembly": None,
                "record_status": "current",
                "fda_recognised_database": None,
                "contributes_to_aggregate_classification": 1,
            },
            {
                "id": 12,
                "variation_archive_id": 10,
                "clinical_assertion_id": 21019,
                "accession": "SCV000021019",
                "version": 2,
                "submitter_name": "OMIM",
                "org_id": 3,
                "organisation_category": "resource",
                "org_abbreviation": None,
                "assertion": "variation to disease",
                "review_status": "no assertion criteria provided",
                "germline_classification": "Pathogenic",
                "somatic_clinical_impact": None,
                "oncogenicity_classification": None,
                "date_last_evaluated": "1994-01-01",
                "no_classification": None,
                "date_created": "2013-04-04",
                "date_updated": "2016-10-23",
                "submission_date": "2016-10-20",
                "local_key": (
                    "611731.0033_FAMILIAL ADENOMATOUS POLYPOSIS 1"
                ),
                "title": (
                    "APC, 3-BP DEL_FAMILIAL ADENOMATOUS POLYPOSIS 1"
                ),
                "local_key_is_submitted": None,
                "submitted_assembly": None,
                "record_status": "current",
                "fda_recognised_database": None,
                "contributes_to_aggregate_classification": 0,
            },
            {
                "id": 13,
                "variation_archive_id": 10,
                "clinical_assertion_id": 7161961,
                "accession": "SCV003836581",
                "version": 1,
                "submitter_name": (
                    "ClinGen InSiGHT Hereditary Colorectal Cancer/"
                    "Polyposis Variant Curation Expert Panel"
                ),
                "org_id": 508966,
                "organisation_category": "consortium",
                "org_abbreviation": None,
                "assertion": "variation to disease",
                "review_status": "reviewed by expert panel",
                "germline_classification": "Pathogenic",
                "somatic_clinical_impact": None,
                "oncogenicity_classification": None,
                "date_last_evaluated": "2023-02-19",
                "no_classification": None,
                "date_created": "2023-03-11",
                "date_updated": "2023-03-11",
                "submission_date": "2023-02-26",
                "local_key": "4164a1aa-3ebc-40fb-be5f-f08864f41253",
                "title": None,
                "local_key_is_submitted": 1,
                "submitted_assembly": "GRCh38",
                "record_status": "current",
                "fda_recognised_database": 1,
                "contributes_to_aggregate_classification": 1,
            },
            {
                "id": 18,
                "variation_archive_id": 15,
                "clinical_assertion_id": 21185,
                "accession": "SCV000021185",
                "version": 4,
                "submitter_name": "OMIM",
                "org_id": 3,
                "organisation_category": "resource",
                "org_abbreviation": None,
                "assertion": "variation to disease",
                "review_status": "no assertion criteria provided",
                "germline_classification": "Pathogenic",
                "somatic_clinical_impact": None,
                "oncogenicity_classification": None,
                "date_last_evaluated": "2006-01-27",
                "no_classification": None,
                "date_created": "2013-04-04",
                "date_updated": "2024-09-01",
                "submission_date": "2013-09-19",
                "local_key": (
                    "611290.0004_IMMUNODEFICIENCY 124, SEVERE COMBINED"
                ),
                "title": (
                    "NHEJ1, 1-BP DEL, 267G AND IVS2DS, A-T, +3_"
                    "IMMUNODEFICIENCY 124, SEVERE COMBINED"
                ),
                "local_key_is_submitted": None,
                "submitted_assembly": None,
                "record_status": "current",
                "fda_recognised_database": None,
                "contributes_to_aggregate_classification": 1,
            },
        ],
        "RCVAccession": [
                    {
                        "id": 1,
                        "variation_archive_id": 1,
                        "accession": "RCV000000351",
                        "version": 7,
                        "title": (
                            "NM_012338.4(TSPAN12):c.361-5_361-1del AND "
                            "Exudative vitreoretinopathy 5"
                        ),
                        "trait_set_id": 93,
                    },
                    {
                        "id": 3,
                        "variation_archive_id": 3,
                        "accession": "RCV000000484",
                        "version": 5,
                        "title": (
                            "NM_000097.7(CPOX):c.489_509del (p.Cys164_Val170del) "
                            "AND Coproporphyria"
                        ),
                        "trait_set_id": 128,
                    },
                    {
                        "id": 8,
                        "variation_archive_id": 8,
                        "accession": "RCV000000586",
                        "version": 5,
                        "title": (
                            "NM_000140.5(FECH):c.314+6A>C AND "
                            "Protoporphyria, erythropoietic, 1"
                        ),
                        "trait_set_id": 152,
                    },
                    {
                        "id": 10,
                        "variation_archive_id": 10,
                        "accession": "RCV000000869",
                        "version": 4,
                        "title": (
                            "NM_000038.6(APC):c.1311_1312+1del AND "
                            "Familial adenomatous polyposis 1"
                        ),
                        "trait_set_id": 6265,
                    },
                    {
                        "id": 15,
                        "variation_archive_id": 15,
                        "accession": "RCV000001035",
                        "version": 5,
                        "title": (
                            "NM_024782.3(NHEJ1):c.177+1_177+3delinsTT AND "
                            "Cernunnos-XLF deficiency"
                        ),
                        "trait_set_id": 258,
                    },
                ],
                "ClassifiedCondition": [
                    {
                        "id": 1,
                        "rcv_accession_id": 1,
                        "db": "MedGen",
                        "condition_id": "C2750079",
                        "name": "Exudative vitreoretinopathy 5",
                    },
                    {
                        "id": 3,
                        "rcv_accession_id": 3,
                        "db": "MedGen",
                        "condition_id": "C0342856",
                        "name": "Coproporphyria",
                    },
                    {
                        "id": 8,
                        "rcv_accession_id": 8,
                        "db": "MedGen",
                        "condition_id": "C4692546",
                        "name": "Protoporphyria, erythropoietic, 1",
                    },
                    {
                        "id": 10,
                        "rcv_accession_id": 10,
                        "db": "MedGen",
                        "condition_id": "C2713442",
                        "name": "Familial adenomatous polyposis 1",
                    },
                    {
                        "id": 15,
                        "rcv_accession_id": 15,
                        "db": "MedGen",
                        "condition_id": "C1969799",
                        "name": "Cernunnos-XLF deficiency",
                    },
                ],
                "RCVClassification": [
                    {
                        "id": 1,
                        "rcv_accession_id": 1,
                        "classification_type": "GermlineClassification",
                        "review_status": "no assertion criteria provided",
                        "description": "Pathogenic",
                        "date_last_evaluated": "2010-02-12",
                        "submission_count": 1,
                        "clinical_impact_assertion_type": None,
                        "clinical_impact_clinical_significance": None,
                    },
                    {
                        "id": 3,
                        "rcv_accession_id": 3,
                        "classification_type": "GermlineClassification",
                        "review_status": "no assertion criteria provided",
                        "description": "Pathogenic",
                        "date_last_evaluated": "1997-01-01",
                        "submission_count": 1,
                        "clinical_impact_assertion_type": None,
                        "clinical_impact_clinical_significance": None,
                    },
                    {
                        "id": 8,
                        "rcv_accession_id": 8,
                        "classification_type": "GermlineClassification",
                        "review_status": "no assertion criteria provided",
                        "description": "Pathogenic",
                        "date_last_evaluated": "1998-07-01",
                        "submission_count": 1,
                        "clinical_impact_assertion_type": None,
                        "clinical_impact_clinical_significance": None,
                    },
                    {
                        "id": 10,
                        "rcv_accession_id": 10,
                        "classification_type": "GermlineClassification",
                        "review_status": "reviewed by expert panel",
                        "description": "Pathogenic",
                        "date_last_evaluated": "2023-02-19",
                        "submission_count": 2,
                        "clinical_impact_assertion_type": None,
                        "clinical_impact_clinical_significance": None,
                    },
                    {
                        "id": 15,
                        "rcv_accession_id": 15,
                        "classification_type": "GermlineClassification",
                        "review_status": "no assertion criteria provided",
                        "description": "Pathogenic",
                        "date_last_evaluated": "2006-01-27",
                        "submission_count": 1,
                        "clinical_impact_assertion_type": None,
                        "clinical_impact_clinical_significance": None,
                    },
                ],
    }
    return data

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def rcv_condition_query_data() -> dict[str, list[dict]]:
    """
    Test data for ConditionQuery and RCV enrichment from RCV database.
    
    Returns
    -------
    dict
        Dictionary with table names as keys and list of row dicts as
        values. Tables: ClinVarSet, ReferenceClinVarAssertion,
        MeasureSet, Measure, TraitSet, Trait, Name, XRef,
        RCVClassification.
    
    Notes
    -----
    Contains 5 records matching the VCV test data canonical_spdi values
    for cross-database enrichment testing.
    """
    data = {
        "ClinVarSet": [
            {
                "id": 7,
                "clinvar_id": 92148308,
                "record_status": "current",
                "title": (
                    "NM_012338.4(TSPAN12):c.361-5_361-1del AND "
                    "Exudative vitreoretinopathy 5"
                ),
                "date_created": "2013-04-04",
                "date_updated": "2022-04-23",
            },
            {
                "id": 14,
                "clinvar_id": 92148434,
                "record_status": "current",
                "title": (
                    "NM_000097.7(CPOX):c.489_509del (p.Cys164_Val170del) "
                    "AND Coproporphyria"
                ),
                "date_created": "2013-04-04",
                "date_updated": "2022-04-23",
            },
            {
                "id": 22365,
                "clinvar_id": 130485391,
                "record_status": "current",
                "title": (
                    "NM_000038.6(APC):c.1311_1312+1del AND "
                    "Familial adenomatous polyposis 1"
                ),
                "date_created": "2013-04-04",
                "date_updated": "2023-03-11",
            },
            {
                "id": 125220,
                "clinvar_id": 220902262,
                "record_status": "current",
                "title": (
                    "NM_024782.3(NHEJ1):c.177+1_177+3delinsTT AND "
                    "Cernunnos-XLF deficiency"
                ),
                "date_created": "2013-04-04",
                "date_updated": "2024-09-01",
            },
            {
                "id": 172634,
                "clinvar_id": 245825166,
                "record_status": "current",
                "title": (
                    "NM_000140.5(FECH):c.314+6A>C AND "
                    "Protoporphyria, erythropoietic, 1"
                ),
                "date_created": "2013-04-04",
                "date_updated": "2025-01-13",
            },
        ],
        "ReferenceClinVarAssertion": [
            {
                "id": 7,
                "clinvar_set_id": 7,
                "clinvar_id": 57854,
                "accession": "RCV000000351",
                "version": 7,
                "date_created": "2013-04-04",
                "date_updated": "2022-04-23",
                "record_status": "current",
                "assertion_type": "variation to disease",
            },
            {
                "id": 14,
                "clinvar_set_id": 14,
                "clinvar_id": 57987,
                "accession": "RCV000000484",
                "version": 5,
                "date_created": "2013-04-04",
                "date_updated": "2022-04-23",
                "record_status": "current",
                "assertion_type": "variation to disease",
            },
            {
                "id": 22365,
                "clinvar_set_id": 22365,
                "clinvar_id": 58372,
                "accession": "RCV000000869",
                "version": 4,
                "date_created": "2013-04-04",
                "date_updated": "2023-03-11",
                "record_status": "current",
                "assertion_type": "variation to disease",
            },
            {
                "id": 125220,
                "clinvar_set_id": 125220,
                "clinvar_id": 58538,
                "accession": "RCV000001035",
                "version": 5,
                "date_created": "2013-04-04",
                "date_updated": "2024-09-01",
                "record_status": "current",
                "assertion_type": "variation to disease",
            },
            {
                "id": 172634,
                "clinvar_set_id": 172634,
                "clinvar_id": 58089,
                "accession": "RCV000000586",
                "version": 5,
                "date_created": "2013-04-04",
                "date_updated": "2025-01-13",
                "record_status": "current",
                "assertion_type": "variation to disease",
            },
        ],
        "MeasureSet": [
            {
                "id": 7,
                "reference_assertion_id": 7,
                "clinvar_id": 323,
                "type": "Variant",
                "acc": "VCV000000323",
                "version": 1,
            },
            {
                "id": 14,
                "reference_assertion_id": 14,
                "clinvar_id": 455,
                "type": "Variant",
                "acc": "VCV000000455",
                "version": 2,
            },
            {
                "id": 22365,
                "reference_assertion_id": 22365,
                "clinvar_id": 826,
                "type": "Variant",
                "acc": "VCV000000826",
                "version": 2,
            },
            {
                "id": 125218,
                "reference_assertion_id": 125220,
                "clinvar_id": 984,
                "type": "Variant",
                "acc": "VCV000000984",
                "version": 2,
            },
            {
                "id": 172630,
                "reference_assertion_id": 172634,
                "clinvar_id": 556,
                "type": "Variant",
                "acc": "VCV000000556",
                "version": 1,
            },
        ],
        "Measure": [
            {
                "id": 7,
                "measure_set_id": 7,
                "clinvar_id": 15362,
                "type": "Deletion",
                "canonical_spdi": "NC_000007.14:120810570:CTGGT:",
                "gene_symbol": "TSPAN12",
                "gene_id": 23554,
                "cytogenetic_location": "7q31.31",
            },
            {
                "id": 14,
                "measure_set_id": 14,
                "clinvar_id": 15494,
                "type": "Deletion",
                "canonical_spdi": (
                    "NC_000003.12:98592995:ACCTGTGCCAGAGCCTGGCACACCTG:ACCTG"
                ),
                "gene_symbol": "CPOX",
                "gene_id": 1371,
                "cytogenetic_location": "3q11.2",
            },
            {
                "id": 22365,
                "measure_set_id": 22365,
                "clinvar_id": 15865,
                "type": "Deletion",
                "canonical_spdi": "NC_000005.10:112819342:AAG:",
                "gene_symbol": "APC",
                "gene_id": 324,
                "cytogenetic_location": "5q22.2",
            },
            {
                "id": 125231,
                "measure_set_id": 125218,
                "clinvar_id": 16023,
                "type": "Indel",
                "canonical_spdi": "NC_000002.12:219158182:TAC:AA",
                "gene_symbol": "NHEJ1",
                "gene_id": 79840,
                "cytogenetic_location": "2q35",
            },
            {
                "id": 172646,
                "measure_set_id": 172630,
                "clinvar_id": 15595,
                "type": "single nucleotide variant",
                "canonical_spdi": "NC_000018.10:57573239:T:G",
                "gene_symbol": "FECH",
                "gene_id": 2235,
                "cytogenetic_location": "18q21.31",
            },
        ],
        "TraitSet": [
            {
                "id": 7,
                "reference_assertion_id": 7,
                "clinvar_id": 93,
                "type": "Disease",
            },
            {
                "id": 14,
                "reference_assertion_id": 14,
                "clinvar_id": 128,
                "type": "Disease",
            },
            {
                "id": 22365,
                "reference_assertion_id": 22365,
                "clinvar_id": 6265,
                "type": "Disease",
            },
            {
                "id": 125220,
                "reference_assertion_id": 125220,
                "clinvar_id": 258,
                "type": "Disease",
            },
            {
                "id": 172634,
                "reference_assertion_id": 172634,
                "clinvar_id": 152,
                "type": "Disease",
            },
        ],
        "Trait": [
            {
                "id": 7,
                "trait_set_id": 7,
                "clinvar_id": 6894,
                "type": "Disease",
                "public_definition": None,
            },
            {
                "id": 14,
                "trait_set_id": 14,
                "clinvar_id": 9639,
                "type": "Disease",
                "public_definition": None,
            },
            {
                "id": 22522,
                "trait_set_id": 22365,
                "clinvar_id": 15929,
                "type": "Disease",
                "public_definition": (
                    "APC-associated polyposis conditions include (classic "
                    "or attenuated) familial adenomatous polyposis (FAP) "
                    "and gastric adenocarcinoma and proximal polyposis of "
                    "the stomach (GAPPS)."
                ),
            },
            {
                "id": 125621,
                "trait_set_id": 125220,
                "clinvar_id": 3718,
                "type": "Disease",
                "public_definition": None,
            },
            {
                "id": 174517,
                "trait_set_id": 172634,
                "clinvar_id": 5814,
                "type": "Disease",
                "public_definition": (
                    "Erythropoietic protoporphyria (EPP) is characterized "
                    "by cutaneous photosensitivity (usually beginning in "
                    "infancy or childhood)."
                ),
            },
        ],
        "Name": [
            {
                "id": 16,
                "entity_type": "Trait",
                "entity_id": 7,
                "element_value": "Exudative vitreoretinopathy 5",
                "type": "Preferred",
            },
            {
                "id": 33,
                "entity_type": "Trait",
                "entity_id": 14,
                "element_value": "Coproporphyria",
                "type": "Preferred",
            },
            {
                "id": 67199,
                "entity_type": "Trait",
                "entity_id": 22522,
                "element_value": "Familial adenomatous polyposis 1",
                "type": "Preferred",
            },
            {
                "id": 67200,
                "entity_type": "Trait",
                "entity_id": 22522,
                "element_value": "POLYPOSIS, ADENOMATOUS INTESTINAL",
                "type": "Alternate",
            },
            {
                "id": 354591,
                "entity_type": "Trait",
                "entity_id": 125621,
                "element_value": "Cernunnos-XLF deficiency",
                "type": "Preferred",
            },
            {
                "id": 516712,
                "entity_type": "Trait",
                "entity_id": 174517,
                "element_value": "Protoporphyria, erythropoietic, 1",
                "type": "Preferred",
            },
        ],
        "XRef": [
            {
                "id": 53,
                "entity_type": "Trait",
                "entity_id": 7,
                "db": "MONDO",
                "xref_id": "MONDO:0013218",
                "xref_type": None,
            },
            {
                "id": 54,
                "entity_type": "Trait",
                "entity_id": 7,
                "db": "MedGen",
                "xref_id": "C2750079",
                "xref_type": None,
            },
            {
                "id": 55,
                "entity_type": "Trait",
                "entity_id": 7,
                "db": "Orphanet",
                "xref_id": "891",
                "xref_type": None,
            },
            {
                "id": 56,
                "entity_type": "Trait",
                "entity_id": 7,
                "db": "OMIM",
                "xref_id": "613310",
                "xref_type": "MIM",
            },
            {
                "id": 114,
                "entity_type": "Trait",
                "entity_id": 14,
                "db": "MedGen",
                "xref_id": "C0342856",
                "xref_type": None,
            },
            {
                "id": 169521,
                "entity_type": "Trait",
                "entity_id": 22522,
                "db": "MONDO",
                "xref_id": "MONDO:0021056",
                "xref_type": None,
            },
            {
                "id": 169522,
                "entity_type": "Trait",
                "entity_id": 22522,
                "db": "MedGen",
                "xref_id": "C2713442",
                "xref_type": None,
            },
            {
                "id": 169523,
                "entity_type": "Trait",
                "entity_id": 22522,
                "db": "OMIM",
                "xref_id": "175100",
                "xref_type": "MIM",
            },
            {
                "id": 1112979,
                "entity_type": "Trait",
                "entity_id": 125621,
                "db": "MONDO",
                "xref_id": "MONDO:0012650",
                "xref_type": None,
            },
            {
                "id": 1112980,
                "entity_type": "Trait",
                "entity_id": 125621,
                "db": "MedGen",
                "xref_id": "C1969799",
                "xref_type": None,
            },
            {
                "id": 1112981,
                "entity_type": "Trait",
                "entity_id": 125621,
                "db": "Orphanet",
                "xref_id": "169079",
                "xref_type": None,
            },
            {
                "id": 1112982,
                "entity_type": "Trait",
                "entity_id": 125621,
                "db": "OMIM",
                "xref_id": "611291",
                "xref_type": "MIM",
            },
            {
                "id": 1586151,
                "entity_type": "Trait",
                "entity_id": 174517,
                "db": "MONDO",
                "xref_id": "MONDO:0008319",
                "xref_type": None,
            },
            {
                "id": 1586152,
                "entity_type": "Trait",
                "entity_id": 174517,
                "db": "MedGen",
                "xref_id": "C4692546",
                "xref_type": None,
            },
            {
                "id": 1586153,
                "entity_type": "Trait",
                "entity_id": 174517,
                "db": "Orphanet",
                "xref_id": "79278",
                "xref_type": None,
            },
            {
                "id": 1586154,
                "entity_type": "Trait",
                "entity_id": 174517,
                "db": "OMIM",
                "xref_id": "177000",
                "xref_type": "MIM",
            },
        ],
        "RCVClassification": [
            {
                "id": 7,
                "reference_assertion_id": 7,
                "classification_type": "GermlineClassification",
                "review_status": "no assertion criteria provided",
                "description": "Pathogenic",
                "date_last_evaluated": "2010-02-12",
                "submission_count": 1,
                "explanation": None,
            },
            {
                "id": 14,
                "reference_assertion_id": 14,
                "classification_type": "GermlineClassification",
                "review_status": "no assertion criteria provided",
                "description": "Pathogenic",
                "date_last_evaluated": "1997-01-01",
                "submission_count": 1,
                "explanation": None,
            },
            {
                "id": 22365,
                "reference_assertion_id": 22365,
                "classification_type": "GermlineClassification",
                "review_status": "reviewed by expert panel",
                "description": "Pathogenic",
                "date_last_evaluated": "2023-02-19",
                "submission_count": 2,
                "explanation": None,
            },
            {
                "id": 125220,
                "reference_assertion_id": 125220,
                "classification_type": "GermlineClassification",
                "review_status": "no assertion criteria provided",
                "description": "Pathogenic",
                "date_last_evaluated": "2006-01-27",
                "submission_count": 1,
                "explanation": None,
            },
            {
                "id": 172634,
                "reference_assertion_id": 172634,
                "classification_type": "GermlineClassification",
                "review_status": "no assertion criteria provided",
                "description": "Pathogenic",
                "date_last_evaluated": "1998-07-01",
                "submission_count": 1,
                "explanation": None,
            },
        ],
    }
    return data


