"""
Constants used in clinvar-build.
"""
import sys
from pathlib import Path

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# PATHS

# _ROOT_PROJECT = os.path.dirname(__file__)
# """The module root"""

# fallback for development vs installed
_dev_config = Path(__file__).parent.parent / "resources" / "clinvar_config"
_installed_config = Path(sys.prefix) / "share" / "clinvar_build" / "clinvar_config"

# _CONFIG_DIR = os.path.join(_ROOT_PROJECT, 'resources', 'clinvar_config')
_CONFIG_DIR = _dev_config if _dev_config.exists() else _installed_config
"""The config directory path"""

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
class UtilsConfigData(object):
    """
    Names used in the Utils Config Data module
    """
    config_dir  = 'CLINVAR_BUILD_CONFIG'

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
class DBNames(object):
    """
    Database names
    """
    rcv     = 'clinvar_rcv.db'
    vcv     = 'clinvar_vcv.db'

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
class ParserNames(object):
    """
    Parser names
    """
    attr         = 'attributes'
    name         = 'name'
    stmt         = 'statement'
    xml_path     = 'xml_path'
    xml_tag      = 'xml_tag'
    xml_text     = 'xml_text'
    xml_attr     = 'xml_attr'
    cast         = 'cast'
    prnt_id      = 'parent_id'
    enty_type    = 'entity_type'
    enty_id      = 'entity_id'
    rtrn_id      = 'returns_id'
    tab_name     = 'table_name'
    child        = 'children'
    xpath        = 'xpath'
    table        = 'table'
    sql          = 'sql'
    cols         = 'columns'
    meta         = '_meta'
    idxs         = '_indexes'
    meta_table   = 'progress_table'
    meta_column  = 'progress_columns'
    meta_type    = 'type'
    meta_nn      = 'not_null'
    meta_default = 'default'
    meta_record  = 'record_element'
    meta_acc     = 'accession_attr'
    rcv          = 'rcv_parse.json'
    vcv          = 'vcv_parse.json'

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# Genomic assembly defaults
VALID_ASSEMBLIES = ("GRCh37", "GRCh38")
DEFAULT_ASSEMBLY = "GRCh38"

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# Default query
RCV_ENRICHMENT_QUERY = """
        SELECT DISTINCT
            m.canonical_spdi,
            n_trait.element_value AS rcv_condition,
            x.db AS rcv_condition_db,
            x.xref_id AS rcv_condition_id,
            rc.description AS rcv_classification,
            rc.review_status AS rcv_review_status
        FROM Measure AS m
        JOIN MeasureSet AS ms ON ms.id = m.measure_set_id
        JOIN ReferenceClinVarAssertion AS rca
            ON rca.id = ms.reference_assertion_id
        LEFT JOIN RCVClassification AS rc
            ON rc.reference_assertion_id = rca.id
        LEFT JOIN TraitSet AS ts
            ON ts.reference_assertion_id = rca.id
        LEFT JOIN Trait AS t ON t.trait_set_id = ts.id
        LEFT JOIN Name AS n_trait
            ON n_trait.entity_type = 'Trait'
            AND n_trait.entity_id = t.id
            AND n_trait.type = 'Preferred'
        LEFT JOIN XRef AS x
            ON x.entity_type = 'Trait'
            AND x.entity_id = t.id
        WHERE m.canonical_spdi IN ({spdi_placeholders})
    """
VCV_ENRICHMENT_QUERY = """
        SELECT DISTINCT
            sa.canonical_spdi,
            va.accession AS vcv_accession,
            va.variation_name,
            ac.description AS vcv_classification,
            ac.review_status AS vcv_review_status,
            ac.date_last_evaluated AS vcv_date_last_evaluated,
            g.symbol AS gene_symbol
        FROM SimpleAllele AS sa
        JOIN VariationArchive AS va ON va.id = sa.variation_archive_id
        LEFT JOIN AggregateClassification AS ac
            ON ac.variation_archive_id = va.id
            AND ac.classification_type = 'GermlineClassification'
        LEFT JOIN Gene AS g ON g.simple_allele_id = sa.id
        WHERE sa.canonical_spdi IN ({spdi_placeholders})
    """
# NOTE: WHERE ca.contributes_to_aggregate_classification = 1
# ensure we only use classifications clinvar actually uses in the
# aggregation
CONCORDANCE_SUBQUERY = """
    LEFT JOIN (
        SELECT
            ca.variation_archive_id,
            GROUP_CONCAT(DISTINCT ca.germline_classification)
                AS submitted_classifications,
            COUNT(DISTINCT ca.germline_classification)
                AS classification_count
        FROM ClinicalAssertion AS ca
        WHERE ca.contributes_to_aggregate_classification = 1
        GROUP BY ca.variation_archive_id
    ) conc ON conc.variation_archive_id = va.id"""
