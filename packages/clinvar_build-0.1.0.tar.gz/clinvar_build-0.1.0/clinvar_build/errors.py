'''
Error handeling for clinvar-build.
'''
import inspect
from typing import Any, Type

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class InputValidationError(Exception):
    pass

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_param_name(param:Any) -> str | None:
    '''
    Gets the name of `param` or otherwise return a None.
    '''
    frame = inspect.currentframe().f_back.f_back
    param_names =\
        [name for name, value in frame.f_locals.items() if value is param]
    return param_names[0] if param_names else None

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def is_type(param: Any, types: tuple[Type] | Type,
            param_name: str | None=None) -> bool:
    """
    Checks if a given parameter matches any of the supplied types
    
    Parameters
    ----------
    param: `any`
        Object to test.
    types: `type`
        Either a single type, or a tuple of types to test against.
    
    Returns
    -------
    True if the parameter is an instance of any of the given types.
    Raises AttributeError otherwise.
    """
    if not isinstance(param, types):
        if param_name is None:
            param_name = get_param_name(param)
        raise InputValidationError(
            f"Expected any of [{types}], "
            f"got {type(param)}; Please see parameter: `{param_name}`."
        )
    return True

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class FileValidationError(Exception):
    '''
    General expection raised when a file was not valid
    '''
    def __init__(self, message="File failed to validate."):
        self.message = message
        super().__init__(self.message)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class XMLValidationError(FileValidationError):
    """
    Expection raised when the XML and XSD file are incompatible.
    """
    def __init__(self, errors: list[str]):
        custom_message = (
            "XML validation failed due to the following issues:\n"
            + "\n".join(errors)
        )
        super().__init__(custom_message)
