# ClinVar XSD Schema Files 

## Overview

This directory contains ClinVar XML Schema Definition (XSD) files representing
the structure for two primary ClinVar record types: RCV (Record) and VCV 
(Variation). 
The latest version can be downloaded from ClinVar's FTP 
[server](https://ftp.ncbi.nlm.nih.gov/pub/clinvar/xsd_public/). 

**Schema Versions:**
- ClinVar_RCV.xsd: Version 2.2 (August 6, 2025)
- ClinVar_VCV.xsd: Version 2.5 (August 6, 2025)

## Schema Files

**ClinVar_RCV.xsd**
- Record Classification View schema
- Defines structure for individual clinical assertions (SCV records)
- Root element: `ReleaseSet`
- Supports submission-level variant-disease associations
- Validation focused on assertion-level metadata and classifications

**ClinVar_VCV.xsd**
- Variation Classification View schema
- Defines structure for aggregated variant records across all submissions
- Root element: `ClinVarVariationRelease`
- Supports aggregate-level classifications and RCV reference lists
- More complex nested structures for classification aggregation


## Key Differences: RCV vs VCV

 | Aspect                   | RCV                   | VCV                          |
 | --------                 | -----                 | -----                        |
 | **Focus**                | Individual assertions | Aggregated variations        |
 | **Root Element**         | ReleaseSet            | ClinVarVariationRelease      |
 | **Primary Container**    | ClinVarSet            | VariationArchive             |
 | **Use Case**             | Submission tracking   | Variant summary              |
 | **Classification Level** | Per-submission        | Aggregate across submissions |


## Related Documentation

For comprehensive ClinVar documentation:
- https://www.ncbi.nlm.nih.gov/clinvar/
- https://github.com/ncbi/clinvar/

