# Configuration files

The `./resources/clinvar_config` directory contains configuration 
files that drive both database schema generation and XML parsing for 
`clinvar-build`. 
Additionally, the directory includes the `xsd` file the configuration files
were developed against. 

---

## How configuration works

A single set of JSON files (one per ClinVar record type) is used to both 
build the SQL schema as well as parse the XML files:

| Concern | Module | What it reads |
|---------|--------|---------------|
| Database schema (CREATE TABLE, CREATE INDEX) | `schema_generator` | `sql/*.json` |
| XML parsing and database loading | `parser` | `sql/*.json` |

Schema constraints (`not_null`, `unique`, `defaults`, `foreign_key_constraint`,
`_indexes`) are annotations on the same entity definitions used for parsing.
See `sql/README.md` for the full annotation reference.

---

## Setting-up the directory

The `parser` and `schema_generator` modules look for configuration files using
the environmental variable `${CLINVAR_BUILD_CONFIG}`.

### Create configuration directory

```bash
mkdir ~/.clinvar_build_config
mkdir ~/.clinvar_build_config/sql
```

_Note_: while the location and root directory name can be user defined,
the `sql` subdirectory name must not be changed.

### Add to your path

```bash
vim ~/.bashrc
export CLINVAR_BUILD_CONFIG="${HOME}/.clinvar_build_config"
source ~/.bashrc
```

## Configuration files

Copy the `.json` files from the `sql/` subdirectory in this directory
(`clinvar_build/resources/clinvar_config/sql`) to your configuration
directory's `sql/` subdirectory.

### Fallback behavior

If the environmental variable is not found, clinvar-build will attempt to
look for the location of the `./resources/clinvar_build_config` directory
among the installed package files as a fallback.

---

## Configuration file types

| File | Purpose |
|------|---------|
| `sql/rcv_parse.json` | RCV entity definitions (parsing + schema) |
| `sql/vcv_parse.json` | VCV entity definitions (parsing + schema) |
