# Building and querying clinvar
__version__: `0.1.0`

Clinvar-build is a python module to build a SQLite database using the 
publicly available XML data from Clinvar. 
The module is slipped with command line entry points for routine queries.

The documentation for clinvar-build can be found 
[here](https://SchmidtAF.gitlab.io/clinvar-build/). 

## Installation 
At present, the repository is undergoing development and no packages exist yet 
on PyPy or in Conda.
Therefore it is recommended that it is installed in either of the two ways
listed below.
First, clone this repository and then `cd` to the root of the repository.

```sh
git clone git@gitlab.com:SchmidtAF/clinvar-build.git
cd clinvar-build
```

### Installation using conda dependencies
A conda environment is provided in a `yaml` file in the directory 
`./resources/conda/envs`.
A new conda environment called `clinvar-build` can be built using the command:

```sh
# From the root of the repository
conda env create --file ./resources/conda/envs/conda_create.yaml
```

To add to an existing environment use:

```sh
# From the root of the repository
conda env update --file ./resources/conda/envs/conda_update.yam
```

Next the package can be installed: 

```bash
make install
```

#### Development
For development work, install the package in editable mode with Git commit
hooks configured:

```bash
make install-dev
```
This command installs the package in editable mode and configures Git commit
hooks, allowing you to run `git pull` to update the repository or switch
branches without reinstalling.

#### Git Hooks Configuration

When setting up a development environment, the `setup-hooks` command 
configures Git hooks to enforce conventional commit message formatting and 
spell check using `codespell`.

To view the commit message format requirements, run:

```bash
./.githooks/commit-msg -help
```

For frequent use, add this function to your shell configuration (`~/.bashrc` 
or `~/.zshrc`):

```bash
commit-format-help() {
    local git_root
    git_root=$(git rev-parse --show-toplevel 2>/dev/null)
    
    if [ -z "$git_root" ]; then
        echo "Error: Not inside a git repository"
        return 1
    fi
    
    local hook_path="$git_root/.githooks/commit-msg"
    
    if [ ! -f "$hook_path" ]; then
        echo "Error: commit-msg hook not found"
        return 1
    fi
    
    "$hook_path" --help
}
```

#### Validating the package

After installing the package from GitLab, you may wish to run the test
suite to confirm everything is working as expected:

```bash
# From the root of the repository
pytest tests
```

## Usage

Please have a look at the examples in 
[resources](https://gitlab.com/SchmidtAF/clinvar-build/-/tree/master/resources)
for some possible recipes. 


