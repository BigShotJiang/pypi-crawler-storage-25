from playwright.sync_api import Playwright, sync_playwright

from examples import (
    LEXMOUNT_PROJECT_ID,
    lm,
)


def run(playwright: Playwright) -> None:
    # Create a session on Lexmount
    # Option 1: Use context manager (automatically closes session)
    with lm.sessions.create(project_id=LEXMOUNT_PROJECT_ID) as session:
        # Connect to the remote session
        chromium = playwright.chromium
        browser = chromium.connect_over_cdp(session.connect_url)
        context = browser.contexts[0]
        page = context.pages[0]

        # Execute Playwright actions on the remote browser tab
        page.goto("https://www.bilibili.com/")
        page_title = page.title()
        assert page_title == "哔哩哔哩 (゜-゜)つロ 干杯~-bilibili", f"Page title is not '哔哩哔哩 (゜-゜)つロ 干杯~-bilibili', it is '{page_title}'"
        page.screenshot(path="screenshot.png")

        page.close()
        browser.close()
    # Session is automatically closed when exiting the 'with' block

    # Option 2: Manual close (alternative approach)
    # session = lm.sessions.create(project_id=LEXMOUNT_PROJECT_ID)
    # try:
    #     # ... use session ...
    #     pass
    # finally:
    #     session.close()  # Manually close the session


if __name__ == "__main__":
    with sync_playwright() as playwright:
        run(playwright)

