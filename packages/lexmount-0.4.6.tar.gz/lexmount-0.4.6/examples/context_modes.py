"""
Context access modes example (read_write vs read_only).

This example demonstrates:
- Creating a session with read_write mode (exclusive access)
- Creating a session with read_only mode (shared access)
- Differences between the two modes
- Multiple concurrent read_only sessions
"""

from lexmount import Lexmount


def main():
    """Demonstrate context access modes."""
    # Initialize client
    client = Lexmount()

    print("=" * 60)
    print("Context Access Modes - read_write vs read_only")
    print("=" * 60)

    # 1. Create context first (required - contexts are not auto-created)
    print(f"\n1. Creating context...")
    try:
        context = client.contexts.create(
            metadata={"purpose": "mode_demonstration"}
        )
        context_id = context.id  # Server-generated ID
        print(f"   ✓ Context created with ID: {context.id}")
    except Exception as e:
        print(f"   ✗ Failed to create context: {e}")
        return

    # 2. Create session with read_write mode
    print("\n2. Creating session with read_write mode...")
    print("   Mode: read_write")
    print("   - Exclusive write access (single session at a time)")
    print("   - Context data is saved when session closes")
    print("   - Blocks other read_write sessions until released")
    try:
        session_rw = client.sessions.create(
            context={"id": context_id, "mode": "read_write"}
        )
        print(f"   ✓ Session created: {session_rw.id}")
        print(f"   WebSocket: {session_rw.connect_url}")

        # Use the session (simulate browser automation)
        print("\n   Simulating browser automation...")
        print("   - Navigate to websites")
        print("   - Perform actions (login, fill forms, etc.)")
        print("   - Cookies and local storage are being modified")

        # Close session (saves context)
        print("\n   Closing session...")
        session_rw.close()
        print("   ✓ Session closed, context data saved")

    except Exception as e:
        print(f"   ✗ Failed: {e}")
        return

    # 3. Create session with read_only mode
    print("\n3. Creating session with read_only mode...")
    print("   Mode: read_only")
    print("   - Shared read access (multiple concurrent sessions)")
    print("   - Loads snapshot of last saved state")
    print("   - Changes are NOT saved when session closes")
    try:
        session_ro = client.sessions.create(
            context={"id": context_id, "mode": "read_only"}
        )
        print(f"   ✓ Session created: {session_ro.id}")
        print(f"   WebSocket: {session_ro.connect_url}")

        # Use the session
        print("\n   Simulating browser automation...")
        print("   - Access websites with existing cookies")
        print("   - Perform read-only operations")
        print("   - Changes won't be persisted")

        # Close session (does not save)
        print("\n   Closing session...")
        session_ro.close()
        print("   ✓ Session closed, changes discarded")

    except Exception as e:
        print(f"   ✗ Failed: {e}")

    # 4. Demonstrate concurrent read_only sessions
    print("\n4. Creating multiple concurrent read_only sessions...")
    try:
        session_ro1 = client.sessions.create(
            context={"id": context_id, "mode": "read_only"}
        )
        session_ro2 = client.sessions.create(
            context={"id": context_id, "mode": "read_only"}
        )
        session_ro3 = client.sessions.create(
            context={"id": context_id, "mode": "read_only"}
        )

        print(f"   ✓ Session 1: {session_ro1.id}")
        print(f"   ✓ Session 2: {session_ro2.id}")
        print(f"   ✓ Session 3: {session_ro3.id}")
        print("\n   All sessions running concurrently with same context!")
        print("   Each has access to the same saved state.")

        # Clean up
        session_ro1.close()
        session_ro2.close()
        session_ro3.close()
        print("\n   ✓ All sessions closed")

    except Exception as e:
        print(f"   ✗ Failed: {e}")

    # 5. Cleanup
    print(f"\n5. Cleaning up context '{context_id}'...")
    try:
        client.contexts.delete(context_id)
        print(f"   ✓ Context deleted")
    except Exception as e:
        print(f"   Note: {e}")

    print("\n" + "=" * 60)
    print("Mode Comparison Summary:")
    print("=" * 60)
    print("\nread_write mode:")
    print("  ✓ Exclusive access (single session)")
    print("  ✓ Changes are saved")
    print("  ✗ Blocks other writers")
    print("\nread_only mode:")
    print("  ✓ Concurrent access (multiple sessions)")
    print("  ✓ Fast access to snapshot")
    print("  ✗ Changes are not saved")
    print("\nUse Cases:")
    print("  read_write: Login, data collection, state modification")
    print("  read_only:  Testing, monitoring, parallel scraping")
    print("=" * 60)


if __name__ == "__main__":
    main()
