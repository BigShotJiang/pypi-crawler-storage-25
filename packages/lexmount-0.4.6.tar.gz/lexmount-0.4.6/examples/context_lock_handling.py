"""
Context lock conflict handling example.

This example demonstrates:
- Detecting and handling ContextLockedError
- Implementing retry logic with exponential backoff
- Fallback to read_only mode
- Force releasing stuck locks (emergency)
"""

import time
from lexmount import Lexmount, ContextLockedError, ContextNotFoundError


def retry_with_backoff(client, context_id, max_attempts=3, initial_delay=2):
    """
    Attempt to create read_write session with exponential backoff retry.

    Args:
        client: Lexmount client instance
        context_id: Context identifier
        max_attempts: Maximum number of retry attempts
        initial_delay: Initial delay in seconds (doubles each retry)

    Returns:
        SessionInfo: Created session if successful
        None: If all attempts failed
    """
    delay = initial_delay

    for attempt in range(1, max_attempts + 1):
        try:
            print(f"\n   Attempt {attempt}/{max_attempts}...")
            session = client.sessions.create(
                context={"id": context_id, "mode": "read_write"}
            )
            print(f"   ✓ Success! Session: {session.id}")
            return session

        except ContextLockedError as e:
            if attempt == max_attempts:
                print(f"   ✗ All {max_attempts} attempts failed")
                print(f"   Context locked by: {e.active_session_id}")
                return None

            wait_time = e.retry_after or delay
            print(f"   ⏰ Context locked by session: {e.active_session_id}")
            print(f"   Waiting {wait_time}s before retry...")
            time.sleep(wait_time)
            delay *= 2  # Exponential backoff

    return None


def fallback_to_readonly(client, context_id):
    """
    Fallback strategy: use read_only mode if read_write fails.

    Args:
        client: Lexmount client instance
        context_id: Context identifier

    Returns:
        SessionInfo: Created session in read_only mode
    """
    try:
        print("\n   Attempting read_write mode...")
        return client.sessions.create(
            context={"id": context_id, "mode": "read_write"}
        )
    except ContextLockedError as e:
        print(f"   ⚠️  Context locked by: {e.active_session_id}")
        print("   Falling back to read_only mode...")

        session = client.sessions.create(
            context={"id": context_id, "mode": "read_only"}
        )
        print(f"   ✓ Read-only session created: {session.id}")
        print("   Note: Changes will not be saved")
        return session


def force_release_stuck_lock(client, context_id, timeout_threshold=600):
    """
    Force release a stuck lock after verifying it's truly stuck.

    WARNING: This is an emergency operation. Only use after confirming
    the lock is stuck (e.g., session crashed and lock wasn't released).

    Args:
        client: Lexmount client instance
        context_id: Context identifier
        timeout_threshold: Time in seconds to wait before force release

    Returns:
        bool: True if lock was released, False otherwise
    """
    print(f"\n   🚨 EMERGENCY: Force releasing lock on '{context_id}'")
    print(f"   ⚠️  This should only be used for stuck/zombie locks!")

    # 1. Verify context is actually locked
    try:
        context = client.contexts.get(context_id)
        if not context.is_locked():
            print("   ℹ️  Context is not locked, no action needed")
            return False

        print(f"   Context is locked (status: {context.status})")

        # 2. Check how long it's been locked (in production, check this from monitoring)
        print(f"   Waiting {timeout_threshold}s to confirm lock is stuck...")
        print("   (In production: verify from monitoring/logs)")
        # time.sleep(timeout_threshold)  # In real scenario, check actual time

        # 3. Force release
        print("\n   Executing force release...")
        result = client.contexts.force_release(context_id)
        print(f"   ✓ {result['message']}")
        print(f"   Status: {result['status']}")
        return True

    except ContextNotFoundError:
        print("   ✗ Context not found")
        return False
    except Exception as e:
        print(f"   ✗ Failed to force release: {e}")
        return False


def main():
    """Demonstrate lock conflict handling strategies."""
    client = Lexmount()

    print("=" * 60)
    print("Context Lock Conflict Handling")
    print("=" * 60)

    # Setup: Create context first
    print(f"\n1. Setting up context...")
    try:
        context = client.contexts.create()
        context_id = context.id  # Server-generated ID
        print(f"   ✓ Context created with ID: {context_id}")
    except Exception as e:
        print(f"   ✗ Failed to create context: {e}")
        return

    # Strategy 1: Retry with exponential backoff
    print("\n" + "=" * 60)
    print("Strategy 1: Retry with Exponential Backoff")
    print("=" * 60)
    print("Use case: Context might be briefly locked, worth waiting")

    # Simulate: Create a blocking session first
    print("\nSimulating locked context...")
    try:
        blocking_session = client.sessions.create(
            context={"id": context_id, "mode": "read_write"}
        )
        print(f"   Context now locked by: {blocking_session.id}")

        # Try to get another read_write session
        print("\nAttempting to create another read_write session...")
        session = retry_with_backoff(client, context_id, max_attempts=3)

        if session:
            print(f"\n   ✓ Successfully acquired lock")
            session.close()
        else:
            print(f"\n   ⚠️  Could not acquire lock, context still in use")

        # Clean up
        blocking_session.close()
        print("\n   (Blocking session closed)")

    except Exception as e:
        print(f"   ✗ Error: {e}")

    # Strategy 2: Fallback to read_only
    print("\n" + "=" * 60)
    print("Strategy 2: Fallback to read_only Mode")
    print("=" * 60)
    print("Use case: Read access is acceptable if write fails")

    try:
        # Create blocking session again
        blocking_session = client.sessions.create(
            context={"id": context_id, "mode": "read_write"}
        )
        print(f"\nContext locked by: {blocking_session.id}")

        # Try with fallback
        print("\nAttempting with fallback strategy...")
        session = fallback_to_readonly(client, context_id)

        if session:
            print(f"\n   ✓ Session active: {session.id}")
            session.close()

        # Clean up
        blocking_session.close()

    except Exception as e:
        print(f"   ✗ Error: {e}")

    # Strategy 3: Force release (emergency only)
    print("\n" + "=" * 60)
    print("Strategy 3: Force Release (Emergency)")
    print("=" * 60)
    print("Use case: Lock is stuck, session crashed, zombie lock")
    print("WARNING: Use only after confirming lock is truly stuck!")

    # Simulate stuck lock scenario
    print("\nSimulating stuck lock scenario...")
    try:
        # Create session but simulate it "crashed" (we just don't close it properly)
        stuck_session = client.sessions.create(
            context={"id": context_id, "mode": "read_write"}
        )
        print(f"   Context locked by: {stuck_session.id}")
        print("   (Simulating: session crashed without releasing lock)")

        # Verify it's locked
        context = client.contexts.get(context_id)
        print(f"\n   Context status: {context.status}")

        # Force release
        if force_release_stuck_lock(client, context_id, timeout_threshold=0):
            # Now we can create a new session
            print("\n   Attempting to create new session...")
            new_session = client.sessions.create(
                context={"id": context_id, "mode": "read_write"}
            )
            print(f"   ✓ New session created: {new_session.id}")
            new_session.close()

        # Clean up the "crashed" session ID is now invalid
        try:
            stuck_session.close()
        except Exception:
            pass  # Expected to fail since we force-released

    except Exception as e:
        print(f"   ✗ Error: {e}")

    # Cleanup
    print(f"\n\nCleaning up context '{context_id}'...")
    try:
        client.contexts.delete(context_id)
        print(f"   ✓ Context deleted")
    except Exception as e:
        print(f"   Note: {e}")

    print("\n" + "=" * 60)
    print("Lock Handling Best Practices:")
    print("=" * 60)
    print("""
1. Retry with backoff:
   - Use for temporary locks
   - Respect retry_after from error
   - Implement timeout limit

2. Fallback to read_only:
   - When write is optional
   - For monitoring/testing scenarios
   - Graceful degradation

3. Force release:
   - EMERGENCY ONLY
   - Verify lock is stuck first
   - Check monitoring/logs
   - May cause data loss

4. General tips:
   - Always close sessions (use context manager)
   - Implement proper error handling
   - Monitor session durations
   - Set reasonable timeouts
    """)
    print("=" * 60)


if __name__ == "__main__":
    main()
