import os
from pathlib import Path

from dotenv import load_dotenv

from lexmount import Lexmount

# Load environment variables
# 优先从项目根目录加载 .env 文件
project_root = Path(__file__).parent.parent
env_file = project_root / ".env"
load_dotenv(dotenv_path=env_file, override=True)

# Validate required environment variables
_LEXMOUNT_API_KEY = os.environ.get("LEXMOUNT_API_KEY")
if not _LEXMOUNT_API_KEY:
    raise ValueError("LEXMOUNT_API_KEY is not set in environment")
LEXMOUNT_API_KEY: str = _LEXMOUNT_API_KEY

_LEXMOUNT_PROJECT_ID = os.environ.get("LEXMOUNT_PROJECT_ID")
if not _LEXMOUNT_PROJECT_ID:
    raise ValueError("LEXMOUNT_PROJECT_ID is not set in environment")
LEXMOUNT_PROJECT_ID: str = _LEXMOUNT_PROJECT_ID

# Instantiate the Lexmount client
lm = Lexmount(api_key=LEXMOUNT_API_KEY, project_id=LEXMOUNT_PROJECT_ID)

