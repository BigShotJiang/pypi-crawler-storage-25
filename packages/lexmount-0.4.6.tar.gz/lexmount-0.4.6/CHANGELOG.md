# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.4.6] - 2026-04-08

### Changed
- Default `sessions.create()` to async create (`/instance/v2`) with polling, and added session status lookup/poll controls.

## [0.4.3] - 2026-03-24

### Added
- Added `ExtensionsResource` to the Python SDK
- Added extension upload, list, get, and delete support
- Added `extension_ids` support to `sessions.create()`
- Added quickstart example for extension upload and session creation
- Added SDK tests covering extension resource and extension-aware session creation

### Changed
- SDK HTTP requests now include `api_key` and `project_id` headers by default
- Updated SDK and quickstart documentation to include extension workflow and office test environment usage

## [0.1.0] - 2025-01-XX

### Added
- Initial release of Lexmount Python SDK
- `Lexmount` client for managing browser instances
- `SessionsResource` for creating and managing browser sessions
- Support for multiple browser modes (chrome-docker, chrome-light-docker, etc.)
- Integration with Playwright via CDP WebSocket
- Environment variable configuration support
- Basic error handling and timeout management
- Comprehensive README and API documentation

### Features
- Create browser sessions with configurable browser modes
- Retrieve WebSocket URLs for Playwright connection
- Support for project-level and session-level configuration
- HTTP client with timeout and error handling

[Unreleased]: https://github.com/yourusername/lexmount-python-sdk/compare/v0.4.6...HEAD
[0.4.6]: https://github.com/yourusername/lexmount-python-sdk/releases/tag/v0.4.6
[0.4.3]: https://github.com/yourusername/lexmount-python-sdk/releases/tag/v0.4.3
[0.1.0]: https://github.com/yourusername/lexmount-python-sdk/releases/tag/v0.1.0
