"""Lexmount API client."""
import os
import time
from typing import Optional

import httpx

from ._sessions import SessionsResource
from ._contexts import ContextsResource
from ._extensions import ExtensionsResource
from .exceptions import (
    ValidationError,
    AuthenticationError,
    NetworkError,
    TimeoutError as LexmountTimeoutError,
    APIError,
)
from ._logging import get_logger

logger = get_logger()


class Lexmount:
    """
    Lexmount API client for managing browser automation sessions.

    This is the main entry point for interacting with the Lexmount browser
    automation service. It provides access to session management and handles
    authentication, HTTP requests, and error handling.

    The client supports context manager protocol for automatic resource cleanup:

    Attributes:
        api_key (str): API key for authentication
        project_id (str): Project ID for session management
        base_url (str): Base URL of the Lexmount API
        sessions (SessionsResource): Resource for managing browser sessions

    Example:
        Basic usage:

        >>> from lexmount import Lexmount
        >>> client = Lexmount(api_key="your-key", project_id="your-project")
        >>> session = client.sessions.create()
        >>> print(session.connect_url)
        >>> session.close()

        With context manager (recommended):

        >>> with Lexmount(api_key="key", project_id="proj") as client:
        ...     session = client.sessions.create()
        ...     # Use session
        ...     session.close()

        With environment variables:

        >>> # Set LEXMOUNT_API_KEY and LEXMOUNT_PROJECT_ID in .env
        >>> client = Lexmount()  # Auto-loads from environment

    Note:
        API credentials can be provided via parameters or environment variables:
        - LEXMOUNT_API_KEY: Your API key
        - LEXMOUNT_PROJECT_ID: Your project ID
        - LEXMOUNT_BASE_URL: API base URL (optional, defaults to https://api.lexmount.cn)

    See Also:
        - :class:`SessionsResource`: Session management operations
        - :class:`SessionInfo`: Session information object
    """

    sessions: SessionsResource
    extensions: ExtensionsResource

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        project_id: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 60.0
    ) -> None:
        """
        Initialize the Lexmount API client.

        Creates a new client instance for interacting with the Lexmount browser
        automation service. The client handles authentication, manages HTTP
        connections, and provides access to session management operations.

        Args:
            api_key: API key for authentication. If not provided, reads from
                LEXMOUNT_API_KEY environment variable. Required.
            project_id: Project ID for session management. If not provided,
                reads from LEXMOUNT_PROJECT_ID environment variable. Required.
            base_url: Base URL of the Lexmount API. If not provided, reads from
                LEXMOUNT_BASE_URL environment variable. Defaults to
                https://api.lexmount.cn
            timeout: Request timeout in seconds. Applies to all HTTP requests
                made by this client. Defaults to 60.0 seconds.

        Raises:
            ValidationError: If api_key or project_id is not provided and not
                found in environment variables.

        Example:
            With explicit credentials:

            >>> client = Lexmount(
            ...     api_key="your-api-key",
            ...     project_id="your-project-id"
            ... )

            With environment variables:

            >>> # Set LEXMOUNT_API_KEY and LEXMOUNT_PROJECT_ID in .env
            >>> client = Lexmount()

            With custom timeout:

            >>> client = Lexmount(
            ...     api_key="key",
            ...     project_id="proj",
            ...     timeout=120.0  # 2 minutes
            ... )

        Note:
            The client uses connection pooling by default for better performance.
            Always close the client when done (use context manager or call close()).
        """
        # Get API key
        self.api_key = api_key or os.environ.get("LEXMOUNT_API_KEY")
        if not self.api_key:
            logger.error("API key not provided")
            raise ValidationError(
                "api_key must be provided or set LEXMOUNT_API_KEY environment variable"
            )

        # Get project ID
        self.project_id = project_id or os.environ.get("LEXMOUNT_PROJECT_ID")
        if not self.project_id:
            logger.error("Project ID not provided")
            raise ValidationError(
                "project_id must be provided or set LEXMOUNT_PROJECT_ID environment variable"
            )

        # Get base URL
        self.base_url = base_url or os.environ.get("LEXMOUNT_BASE_URL", "https://api.lexmount.cn")
        self.base_url = self.base_url.rstrip("/")

        # HTTP client
        self._http_client = httpx.Client(timeout=timeout)

        # Initialize resources
        self.sessions = SessionsResource(self)
        self.contexts = ContextsResource(self)
        self.extensions = ExtensionsResource(self)

        logger.debug(
            f"Lexmount client initialized: base_url={self.base_url}, "
            f"project_id={self.project_id}"
        )

    def _post(self, url: str, **kwargs) -> httpx.Response:
        """
        Internal POST request method with comprehensive error handling.

        This is an internal method used by the SDK to make POST requests to the
        Lexmount API. It handles common error scenarios and converts httpx
        exceptions into SDK-specific exceptions for better error handling.

        Args:
            url: The full URL to send the POST request to
            **kwargs: Additional arguments to pass to httpx (json, headers, etc.)

        Returns:
            httpx.Response: The HTTP response object

        Raises:
            NetworkError: If there's a network connectivity issue (DNS failure,
                connection refused, etc.)
            TimeoutError: If the request exceeds the configured timeout
            APIError: For other HTTP protocol errors

        Note:
            This method automatically sets Content-Type header to application/json
            when the json parameter is provided. Request duration is logged at
            DEBUG level for performance monitoring.
        """
        start_time = time.perf_counter()
        logger.debug(f"POST request to {url}")
        try:
            # Ensure auth headers are always present for gateway compatibility
            headers = self._build_auth_headers(kwargs.get('headers'))
            if 'json' in kwargs:
                headers['Content-Type'] = 'application/json'
            kwargs['headers'] = headers
            response = self._http_client.post(url, **kwargs)
            elapsed = time.perf_counter() - start_time
            logger.debug(
                f"POST response: status={response.status_code}, "
                f"duration={elapsed*1000:.2f}ms"
            )
            return response
        except httpx.TimeoutException as e:
            elapsed = time.perf_counter() - start_time
            logger.error(f"Request timeout after {elapsed*1000:.2f}ms: {e}")
            raise LexmountTimeoutError(f"Request timed out: {e}") from e
        except (httpx.NetworkError, httpx.ConnectError) as e:
            elapsed = time.perf_counter() - start_time
            logger.error(f"Network error after {elapsed*1000:.2f}ms: {e}")
            raise NetworkError(f"Network error: {e}") from e
        except httpx.HTTPError as e:
            elapsed = time.perf_counter() - start_time
            logger.error(f"HTTP error after {elapsed*1000:.2f}ms: {e}")
            raise APIError(f"HTTP error: {e}") from e

    def _delete(self, url: str, **kwargs) -> httpx.Response:
        """
        Internal DELETE request method with comprehensive error handling.

        This is an internal method used by the SDK to make DELETE requests to the
        Lexmount API. It handles common error scenarios and converts httpx
        exceptions into SDK-specific exceptions for better error handling.

        Args:
            url: The full URL to send the DELETE request to
            **kwargs: Additional arguments to pass to httpx (json, headers, etc.)

        Returns:
            httpx.Response: The HTTP response object

        Raises:
            NetworkError: If there's a network connectivity issue (DNS failure,
                connection refused, etc.)
            TimeoutError: If the request exceeds the configured timeout
            APIError: For other HTTP protocol errors

        Note:
            This method uses httpx.request('DELETE', ...) instead of delete()
            to support JSON request bodies, which is required by some Lexmount
            API endpoints. Request duration is logged at DEBUG level for
            performance monitoring.
        """
        start_time = time.perf_counter()
        logger.debug(f"DELETE request to {url}")
        try:
            # httpx.Client.delete() doesn't support json parameter
            # Use request() method instead to send DELETE with JSON body
            headers = self._build_auth_headers(kwargs.get('headers'))
            if 'json' in kwargs:
                headers['Content-Type'] = 'application/json'
            kwargs['headers'] = headers
            response = self._http_client.request('DELETE', url, **kwargs)
            elapsed = time.perf_counter() - start_time
            logger.debug(
                f"DELETE response: status={response.status_code}, "
                f"duration={elapsed*1000:.2f}ms"
            )
            return response
        except httpx.TimeoutException as e:
            elapsed = time.perf_counter() - start_time
            logger.error(f"Request timeout after {elapsed*1000:.2f}ms: {e}")
            raise LexmountTimeoutError(f"Request timed out: {e}") from e
        except (httpx.NetworkError, httpx.ConnectError) as e:
            elapsed = time.perf_counter() - start_time
            logger.error(f"Network error after {elapsed*1000:.2f}ms: {e}")
            raise NetworkError(f"Network error: {e}") from e
        except httpx.HTTPError as e:
            elapsed = time.perf_counter() - start_time
            logger.error(f"HTTP error after {elapsed*1000:.2f}ms: {e}")
            raise APIError(f"HTTP error: {e}") from e

    def _get(self, url: str, **kwargs) -> httpx.Response:
        """
        Internal GET request method with comprehensive error handling.

        This is an internal method used by the SDK to make GET requests to the
        Lexmount API. It handles common error scenarios and converts httpx
        exceptions into SDK-specific exceptions for better error handling.

        Args:
            url: The full URL to send the GET request to
            **kwargs: Additional arguments to pass to httpx (params, headers, etc.)

        Returns:
            httpx.Response: The HTTP response object

        Raises:
            NetworkError: If there's a network connectivity issue (DNS failure,
                connection refused, etc.)
            TimeoutError: If the request exceeds the configured timeout
            APIError: For other HTTP protocol errors

        Note:
            Query parameters can be passed via the 'params' keyword argument.
            Request duration is logged at DEBUG level for performance monitoring.
        """
        start_time = time.perf_counter()
        logger.debug(f"GET request to {url}")
        try:
            kwargs['headers'] = self._build_auth_headers(kwargs.get('headers'))
            response = self._http_client.get(url, **kwargs)
            elapsed = time.perf_counter() - start_time
            logger.debug(
                f"GET response: status={response.status_code}, "
                f"duration={elapsed*1000:.2f}ms"
            )
            return response
        except httpx.TimeoutException as e:
            elapsed = time.perf_counter() - start_time
            logger.error(f"Request timeout after {elapsed*1000:.2f}ms: {e}")
            raise LexmountTimeoutError(f"Request timed out: {e}") from e
        except (httpx.NetworkError, httpx.ConnectError) as e:
            elapsed = time.perf_counter() - start_time
            logger.error(f"Network error after {elapsed*1000:.2f}ms: {e}")
            raise NetworkError(f"Network error: {e}") from e
        except httpx.HTTPError as e:
            elapsed = time.perf_counter() - start_time
            logger.error(f"HTTP error after {elapsed*1000:.2f}ms: {e}")
            raise APIError(f"HTTP error: {e}") from e

    def _build_auth_headers(self, headers: Optional[dict] = None) -> dict:
        """Merge caller headers with gateway-required auth headers."""
        merged = dict(headers or {})
        merged.setdefault("api_key", self.api_key)
        merged.setdefault("project_id", self.project_id)
        return merged

    def close(self) -> None:
        """
        Close the HTTP client and release resources.

        This method should be called when you're done using the client to
        properly release network resources and close connections. Alternatively,
        use the client as a context manager to handle cleanup automatically.

        Example:
            Manual cleanup:

            >>> client = Lexmount(api_key="key", project_id="proj")
            >>> # ... use client ...
            >>> client.close()

            Automatic cleanup with context manager (recommended):

            >>> with Lexmount(api_key="key", project_id="proj") as client:
            ...     # ... use client ...
            ...     pass  # Automatically closed

        Note:
            After calling close(), the client cannot be reused. Create a new
            client instance if you need to make more requests.
        """
        logger.debug("Closing Lexmount client")
        self._http_client.close()

    def __enter__(self):
        """
        Context manager entry point.

        Returns:
            Lexmount: The client instance itself.

        Example:
            >>> with Lexmount(api_key="key", project_id="proj") as client:
            ...     session = client.sessions.create()
            ...     print(session.id)
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Context manager exit point.

        Automatically closes the client and releases resources when exiting
        the context manager, even if an exception occurs.

        Args:
            exc_type: Exception type (if an exception occurred)
            exc_val: Exception value (if an exception occurred)
            exc_tb: Exception traceback (if an exception occurred)

        Returns:
            None: Does not suppress exceptions (returns None/False)
        """
        self.close()

    def __repr__(self) -> str:
        """
        Return a string representation of the Lexmount client.

        Returns:
            str: String representation showing project_id and base_url

        Example:
            >>> client = Lexmount(api_key="key", project_id="proj-123")
            >>> print(repr(client))
            Lexmount(project_id='proj-123', base_url='https://api.lexmount.cn')
        """
        return f"Lexmount(project_id={self.project_id!r}, base_url={self.base_url!r})"
