"""Contexts resource for managing browser persistent storage."""
import time
from typing import TYPE_CHECKING, Optional, List, Dict, Any
from urllib.parse import urljoin
from datetime import datetime

if TYPE_CHECKING:
    from ._client import Lexmount

from .exceptions import (
    AuthenticationError,
    ContextNotFoundError,
    ContextLockedError,
    APIError,
)
from ._logging import get_logger

logger = get_logger()


class ContextInfo:
    """
    Information about a browser context (persistent storage).

    A context represents a persistent browser profile that can store cookies,
    local storage, session state, and other browser data. Contexts support
    concurrent read access but only one write session at a time.

    Attributes:
        id (str): Context identifier (business alias)
        status (str): Current status - "available" or "locked"
        metadata (Optional[Dict]): Custom metadata tags
        created_at (Optional[datetime]): Context creation timestamp
        updated_at (Optional[datetime]): Last update timestamp

    Example:
        Get context information:

        >>> context = client.contexts.get("user_twitter_1001")
        >>> print(f"Status: {context.status}")
        >>> if context.status == "locked":
        ...     print("Context is locked")
    """

    def __init__(
        self,
        id: str,
        status: str,
        metadata: Optional[Dict[str, Any]] = None,
        created_at: Optional[str] = None,
        updated_at: Optional[str] = None,
    ):
        """
        Initialize context information.

        Args:
            id: Context identifier
            status: Context status ("available" or "locked")
            metadata: Custom metadata
            created_at: Creation timestamp (ISO format)
            updated_at: Last update timestamp (ISO format)
        """
        self.id = id
        self.status = status
        self.metadata = metadata or {}

        # Parse timestamps
        self.created_at = None
        if created_at:
            try:
                self.created_at = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
            except (ValueError, AttributeError):
                logger.warning(f"Failed to parse created_at timestamp: {created_at}")

        self.updated_at = None
        if updated_at:
            try:
                self.updated_at = datetime.fromisoformat(updated_at.replace('Z', '+00:00'))
            except (ValueError, AttributeError):
                logger.warning(f"Failed to parse updated_at timestamp: {updated_at}")

    def is_locked(self) -> bool:
        """
        Check if context is currently locked.

        Returns:
            bool: True if locked, False if available

        Example:
            >>> if context.is_locked():
            ...     print("Context is in use, waiting...")
        """
        return self.status == "locked"

    def is_available(self) -> bool:
        """
        Check if context is available for use.

        Returns:
            bool: True if available, False if locked

        Example:
            >>> if context.is_available():
            ...     session = client.sessions.create(
            ...         context={"id": context.id, "mode": "read_write"}
            ...     )
        """
        return self.status == "available"

    def __repr__(self) -> str:
        """Return string representation of context info."""
        return f"ContextInfo(id='{self.id}', status='{self.status}')"

    def __str__(self) -> str:
        """Return human-readable string representation."""
        return f"Context {self.id} ({self.status})"


class ContextListResponse:
    """
    Response object from contexts.list() containing contexts list.

    This object is returned by the contexts.list() method and supports
    list-like operations for convenient access to contexts.

    Attributes:
        data (List[ContextInfo]): List of context information objects

    Example:
        Direct iteration:

        >>> result = client.contexts.list()
        >>> for context in result:
        ...     print(f"{context.id}: {context.status}")

        Access by index:

        >>> result = client.contexts.list()
        >>> first_context = result[0]

        Check length:

        >>> result = client.contexts.list()
        >>> print(f"Found {len(result)} contexts")
    """

    def __init__(self, data: List[ContextInfo]):
        """
        Initialize context list response.

        Args:
            data: List of ContextInfo objects
        """
        self.data = data

    def __iter__(self):
        """Iterate over contexts."""
        return iter(self.data)

    def __len__(self) -> int:
        """Return number of contexts."""
        return len(self.data)

    def __getitem__(self, index: int) -> ContextInfo:
        """Get context by index."""
        return self.data[index]

    def __repr__(self) -> str:
        """Return string representation."""
        return f"ContextListResponse(count={len(self.data)})"


class ContextsResource:
    """
    Resource for managing browser contexts (persistent storage).

    Contexts represent persistent browser profiles that can store cookies,
    local storage, and session state across multiple browser sessions.

    The context system uses a single-writer, multiple-reader concurrency model:
    - read_write mode: Exclusive access, one session at a time
    - read_only mode: Shared access, multiple concurrent sessions

    Example:
        Basic context management:

        >>> # Create a new context
        >>> context = client.contexts.create(
        ...     id="user_profile_001",
        ...     metadata={"user": "john", "environment": "prod"}
        ... )
        >>>
        >>> # List all contexts
        >>> contexts = client.contexts.list()
        >>> for ctx in contexts:
        ...     print(f"{ctx.id}: {ctx.status}")
        >>>
        >>> # Get specific context
        >>> context = client.contexts.get("user_profile_001")
        >>> print(f"Size: {context.size}")
        >>>
        >>> # Delete context
        >>> client.contexts.delete("user_profile_001")
    """

    def __init__(self, client: "Lexmount"):
        """
        Initialize contexts resource.

        Args:
            client: Parent Lexmount client instance
        """
        self._client = client

    def _log_response(self, response, operation: str) -> None:
        """
        Log response details for debugging.

        Args:
            response: HTTP response object
            operation: Name of the operation (e.g., "create", "list", "get", "delete")
        """
        logger.debug(f"[{operation}] Response Status Code: {response.status_code}")
        try:
            response_body = response.json() if response.text else {}
            logger.debug(f"[{operation}] Response Body: {response_body}")
        except Exception:
            logger.debug(f"[{operation}] Response Text (non-JSON): {response.text}")

    def _handle_error_response(self, response, operation: str, context_id: Optional[str] = None) -> None:
        """
        Handle error responses from context API calls.

        Args:
            response: HTTP response object
            operation: Name of the operation (e.g., "create", "list", "get", "delete")
            context_id: Optional context ID for more specific error messages

        Raises:
            AuthenticationError: For 401 errors
            ContextNotFoundError: For 404 errors
            ContextLockedError: For 409 errors with context_locked code
            APIError: For all other errors
        """
        try:
            error_data = response.json() if response.text else {}
        except Exception:
            error_data = {"raw_response": response.text}

        error_msg = error_data.get("error") or error_data.get("message") or "Unknown error"
        error_code = error_data.get("code", "")
        metadata = error_data.get("metadata", {})

        # Log error details
        logger.error(f"API Error in {operation}: {error_msg} (code: {error_code}, status: {response.status_code})")
        logger.debug(f"Error Response: {error_data}")

        # Handle specific status codes
        if response.status_code == 401:
            raise AuthenticationError(f"Authentication failed: {error_msg}")

        elif response.status_code == 404:
            ctx_info = f": {context_id}" if context_id else ""
            raise ContextNotFoundError(f"Context not found{ctx_info}")

        elif response.status_code == 409:
            if error_code == "context_locked":
                raise ContextLockedError(
                    error_msg,
                    active_session_id=metadata.get("activeSessionId"),
                    retry_after=metadata.get("retryAfter")
                )
            elif error_code == "session_active":
                raise APIError(
                    f"Cannot {operation} context: {error_msg} (session is active)",
                    status_code=response.status_code,
                    response=error_data
                )
            else:
                raise APIError(
                    f"Conflict error during {operation}: {error_msg}",
                    status_code=response.status_code,
                    response=error_data
                )

        elif response.status_code == 500:
            # Internal server error - include details if available
            details = error_data.get("details", "")
            detail_msg = f" Details: {details}" if details else ""
            raise APIError(
                f"Internal server error (500) during {operation}: {error_msg}.{detail_msg}",
                status_code=response.status_code,
                response=error_data
            )

        elif response.status_code == 502:
            raise APIError(
                f"Server gateway error (502) during {operation}: The service may be temporarily unavailable. Please retry.",
                status_code=response.status_code,
                response=error_data
            )

        elif response.status_code == 503:
            raise APIError(
                f"Service unavailable (503) during {operation}: The service is temporarily unavailable. Please retry later.",
                status_code=response.status_code,
                response=error_data
            )

        elif response.status_code == 504:
            raise APIError(
                f"Gateway timeout (504) during {operation}: The request timed out. Please retry.",
                status_code=response.status_code,
                response=error_data
            )

        else:
            raise APIError(
                f"Failed to {operation} context: {error_msg}",
                status_code=response.status_code,
                response=error_data
            )

    def create(
        self,
        metadata: Optional[Dict[str, Any]] = None
    ) -> ContextInfo:
        """
        Create a new context (persistent browser profile).

        The context ID is automatically generated by the server and returned
        in the response. Use the returned context ID when creating sessions.

        Args:
            metadata: Optional metadata tags/labels for organizing contexts

        Returns:
            ContextInfo: Created context information including server-generated ID

        Raises:
            AuthenticationError: Invalid credentials
            APIError: API request failed
            ValidationError: Invalid input parameters
            NetworkError: Network communication failed
            TimeoutError: Request timed out

        Example:
            Create context with metadata:

            >>> context = client.contexts.create(
            ...     metadata={
            ...         "user_id": "1001",
            ...         "platform": "twitter",
            ...         "environment": "production"
            ...     }
            ... )
            >>> print(f"Created context: {context.id}")  # Server-generated ID
            >>> print(f"Status: {context.status}")
            >>>
            >>> # Use the context in a session
            >>> session = client.sessions.create(
            ...     context={"id": context.id, "mode": "read_write"}
            ... )

            Create context without metadata:

            >>> context = client.contexts.create()
            >>> print(f"Generated ID: {context.id}")
        """
        start_time = time.perf_counter()
        logger.debug("Creating new context (ID will be generated by server)")

        # Build request payload
        payload = {
            "api_key": self._client.api_key,
            "project_id": self._client.project_id
        }
        if metadata:
            payload["metadata"] = metadata

        # Make API request
        url = f"{self._client.base_url}/instance/v1/contexts/create-context"

        # Log detailed request information
        logger.debug(f"Request URL: {url}")
        logger.debug(f"Request Method: POST")
        logger.debug(f"Request Payload: {payload}")
        logger.debug(f"Project ID: {self._client.project_id}")
        logger.debug(f"Base URL: {self._client.base_url}")

        response = self._client._post(url, json=payload)

        # Log response
        self._log_response(response, "create")

        # Handle error responses
        if response.status_code >= 400:
            self._handle_error_response(response, "create")

        elapsed = time.perf_counter() - start_time
        logger.debug(f"Context creation completed in {elapsed:.3f}s")

        # Parse response
        result = response.json()

        # Extract context data - create returns context object directly (not wrapped in 'context' key)
        context_data = result

        # Service returns 'context_id'
        context_id = context_data.get("context_id")

        # Handle timestamp (service returns ISO format string)
        created_at = context_data.get("created_at")
        if created_at and isinstance(created_at, (int, float)):
            # Convert milliseconds timestamp to ISO format if needed
            from datetime import datetime, timezone
            created_at = datetime.fromtimestamp(created_at / 1000, tz=timezone.utc).isoformat()

        context_info = ContextInfo(
            id=context_id,
            status=context_data.get("locked", "available"),  # "locked" field contains status value
            created_at=created_at,
            metadata=metadata
        )

        logger.info(f"Successfully created context '{context_info.id}'")
        return context_info

    def list(
        self,
        status: Optional[str] = None,
        limit: int = 20
    ) -> ContextListResponse:
        """
        List all contexts in the project.

        Retrieves context information including status, size, and active sessions.
        Supports filtering by status and pagination.

        Args:
            status: Filter by status - "available" or "locked" (optional)
            limit: Maximum number of contexts to return (default: 20)

        Returns:
            ContextListResponse: List of context information objects

        Raises:
            AuthenticationError: Invalid credentials
            APIError: API request failed
            NetworkError: Network communication failed
            TimeoutError: Request timed out

        Example:
            List all contexts:

            >>> contexts = client.contexts.list()
            >>> print(f"Total: {len(contexts)}")
            >>> for context in contexts:
            ...     print(f"{context.id}: {context.status}")

            Filter by status:

            >>> locked = client.contexts.list(status="locked")
            >>> for context in locked:
            ...     print(f"{context.id} locked by {context.active_session_id}")
            >>>
            >>> available = client.contexts.list(status="available")
            >>> print(f"{len(available)} contexts available for use")

            Pagination:

            >>> contexts = client.contexts.list(limit=50)
        """
        start_time = time.perf_counter()
        logger.debug(f"Listing contexts (status={status}, limit={limit})")

        # Build request payload
        payload = {
            "api_key": self._client.api_key,
            "project_id": self._client.project_id,
            "limit": limit
        }
        if status:
            payload["status"] = status

        # Make API request (POST method)
        url = f"{self._client.base_url}/instance/v1/contexts/list-contexts"
        response = self._client._post(url, json=payload)

        # Log response
        self._log_response(response, "list")

        # Handle error responses
        if response.status_code >= 400:
            self._handle_error_response(response, "list")

        elapsed = time.perf_counter() - start_time
        logger.debug(f"Context list retrieved in {elapsed:.3f}s")

        # Parse response
        result = response.json()
        contexts = []
        # Server returns "contexts" array, not "data"
        for item in result.get("contexts", []):
            context_info = ContextInfo(
                id=item.get("context_id"),
                status=item.get("locked", "available"),  # "locked" field contains status value
                created_at=item.get("created_at"),
                updated_at=item.get("updated_at")
            )
            contexts.append(context_info)

        logger.info(f"Retrieved {len(contexts)} contexts")
        return ContextListResponse(data=contexts)

    def get(self, context_id: str) -> ContextInfo:
        """
        Get information about a specific context.

        Retrieves detailed metadata for a single context including its current
        status, size, active session, and timestamps.

        Args:
            context_id: Context identifier

        Returns:
            ContextInfo: Context information

        Raises:
            ContextNotFoundError: Context does not exist
            AuthenticationError: Invalid credentials
            APIError: API request failed
            NetworkError: Network communication failed
            TimeoutError: Request timed out

        Example:
            Get context details:

            >>> context = client.contexts.get("user_twitter_1001")
            >>> print(f"Status: {context.status}")
            >>> print(f"Size: {context.size}")
            >>> print(f"Last updated: {context.updated_at}")
            >>>
            >>> if context.is_locked():
            ...     print(f"Locked by session: {context.active_session_id}")
            >>> else:
            ...     print("Context is available")

            Check before use:

            >>> try:
            ...     context = client.contexts.get("my_context")
            ...     if context.is_available():
            ...         session = client.sessions.create(
            ...             context={"id": context.id, "mode": "read_write"}
            ...         )
            ... except ContextNotFoundError:
            ...     print("Context doesn't exist, will be created implicitly")
            ...     session = client.sessions.create(
            ...         context={"id": "my_context", "mode": "read_write"}
            ...     )
        """
        start_time = time.perf_counter()
        logger.debug(f"Getting context '{context_id}'")

        # Build request payload
        payload = {
            "api_key": self._client.api_key,
            "project_id": self._client.project_id
        }

        # Make API request (POST method)
        url = f"{self._client.base_url}/instance/v1/contexts/{context_id}"
        response = self._client._post(url, json=payload)

        # Log response
        self._log_response(response, "get")

        # Handle error responses
        if response.status_code >= 400:
            self._handle_error_response(response, "get", context_id)

        elapsed = time.perf_counter() - start_time
        logger.debug(f"Context info retrieved in {elapsed:.3f}s")

        # Parse response
        result = response.json()

        # Extract context data - server returns {'success': True, 'context': {...}}
        context_data = result["context"]

        # Service returns 'context_id'
        ctx_id = context_data.get("context_id") or context_id
        context_info = ContextInfo(
            id=ctx_id,
            status=context_data.get("locked", "available"),  # "locked" field contains status value
            metadata=context_data.get("metadata", {}),
            created_at=context_data.get("created_at"),
            updated_at=context_data.get("updated_at")
        )

        logger.info(f"Retrieved context '{context_info.id}' (status: {context_info.status})")
        return context_info

    def delete(self, context_id: str) -> None:
        """
        Delete a context and all its stored data.

        Permanently removes the context and all associated browser data (cookies,
        local storage, etc.). This operation cannot be undone.

        The context must not be locked (in use by an active session). If locked,
        the request will fail with ContextLockedError.

        Args:
            context_id: Context identifier to delete

        Raises:
            ContextNotFoundError: Context does not exist
            ContextLockedError: Context is currently locked by an active session
            AuthenticationError: Invalid credentials
            APIError: API request failed
            NetworkError: Network communication failed
            TimeoutError: Request timed out

        Example:
            Simple delete:

            >>> client.contexts.delete("old_context")
            >>> print("Context deleted successfully")

            Safe delete with error handling:

            >>> from lexmount import ContextNotFoundError, ContextLockedError
            >>>
            >>> try:
            ...     client.contexts.delete("my_context")
            ... except ContextNotFoundError:
            ...     print("Context doesn't exist")
            ... except ContextLockedError as e:
            ...     print(f"Context is locked by session {e.active_session_id}")
            ...     print("Wait for session to complete or use force_release()")

            Check before delete:

            >>> context = client.contexts.get("my_context")
            >>> if context.is_locked():
            ...     print(f"Cannot delete: locked by {context.active_session_id}")
            ... else:
            ...     client.contexts.delete("my_context")
        """
        start_time = time.perf_counter()
        logger.debug(f"Deleting context '{context_id}'")

        # Build request payload
        payload = {
            "api_key": self._client.api_key,
            "project_id": self._client.project_id
        }

        # Make API request
        url = f"{self._client.base_url}/instance/v1/contexts/{context_id}"
        response = self._client._delete(url, json=payload)

        # Log response
        self._log_response(response, "delete")

        # Handle error responses
        if response.status_code >= 400:
            self._handle_error_response(response, "delete", context_id)

        elapsed = time.perf_counter() - start_time
        logger.debug(f"Context deletion completed in {elapsed:.3f}s")
        logger.info(f"Successfully deleted context '{context_id}'")

    def force_release(self, context_id: str) -> Dict[str, str]:
        """
        Force release a stuck lock on a context (emergency operation).

        This is an emergency operation for clearing zombie locks when a session
        crashes or fails to release properly. Use with caution as it will:
        - Remove the lock immediately
        - Attempt to terminate the associated session
        - May cause data loss if session was mid-write

        Only use when:
        - A session has crashed and lock is stuck
        - Normal session termination has failed
        - You've confirmed the session is no longer running

        Args:
            context_id: Context identifier to unlock

        Returns:
            Dict[str, str]: Response with status and message

        Raises:
            ContextNotFoundError: Context does not exist
            AuthenticationError: Invalid credentials
            APIError: API request failed
            NetworkError: Network communication failed
            TimeoutError: Request timed out

        Example:
            Force unlock stuck context:

            >>> from lexmount import ContextLockedError
            >>>
            >>> # Try normal access first
            >>> try:
            ...     session = client.sessions.create(
            ...         context={"id": "stuck_ctx", "mode": "read_write"}
            ...     )
            ... except ContextLockedError as e:
            ...     print(f"Locked by {e.active_session_id}")
            ...
            ...     # Verify session is actually dead/stuck
            ...     # ... check your monitoring/logs ...
            ...
            ...     # Force release as last resort
            ...     result = client.contexts.force_release("stuck_ctx")
            ...     print(result["message"])
            ...
            ...     # Retry
            ...     session = client.sessions.create(
            ...         context={"id": "stuck_ctx", "mode": "read_write"}
            ...     )

        Warning:
            This is a destructive operation. Always verify the lock is truly
            stuck before using force_release. Consider implementing a timeout
            threshold (e.g., only force release if locked for > 10 minutes).
        """
        start_time = time.perf_counter()
        logger.warning(f"Force releasing lock on context '{context_id}'")

        # Build request payload
        payload = {
            "api_key": self._client.api_key,
            "project_id": self._client.project_id
        }

        # Make API request
        url = f"{self._client.base_url}/instance/v1/contexts/{context_id}/force-release"
        response = self._client._post(url, json=payload)

        # Log response
        self._log_response(response, "force_release")

        # Handle error responses
        if response.status_code >= 400:
            self._handle_error_response(response, "force_release", context_id)

        elapsed = time.perf_counter() - start_time
        logger.debug(f"Force release completed in {elapsed:.3f}s")
        logger.info(f"Successfully force released context '{context_id}'")

        # Parse response
        result = response.json() if response.text else {}
        return {
            "status": result.get("status", "unlocked"),
            "message": result.get("message", "Lock released successfully")
        }
