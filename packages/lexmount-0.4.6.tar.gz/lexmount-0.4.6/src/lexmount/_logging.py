"""
Centralized logging configuration for the Lexmount SDK.

This module provides a unified logging system for the SDK, allowing users
to control log verbosity and output format. All SDK components use this
logger for consistent logging behavior.

The logger uses the name "lexmount" and outputs to stderr by default with
a formatted timestamp. The default level is WARNING to minimize noise in
production environments.

Example:
    Enable debug logging for development:

    >>> from lexmount import set_log_level
    >>> set_log_level("DEBUG")
    >>>
    >>> # Now all SDK operations will log debug information
    >>> client = Lexmount(api_key="key", project_id="proj")
    >>> session = client.sessions.create()  # Logs detailed timing info

    Disable logging completely:

    >>> from lexmount._logging import disable_logging
    >>> disable_logging()
    >>> # No logs will be output

    Custom log handling:

    >>> import logging
    >>> from lexmount._logging import get_logger
    >>>
    >>> # Get the SDK logger and add custom handler
    >>> logger = get_logger()
    >>> file_handler = logging.FileHandler("lexmount.log")
    >>> logger.addHandler(file_handler)

Note:
    The SDK logs various information at different levels:
    - DEBUG: HTTP requests, responses, timing, WebSocket URLs
    - INFO: Session creation/deletion, operation success
    - WARNING: Non-fatal issues, fallback behaviors
    - ERROR: Critical failures, initialization errors
"""

import logging
from typing import Optional

# Default logger name
LOGGER_NAME = "lexmount"

# Create a module-level logger
_logger: Optional[logging.Logger] = None


def get_logger(name: str = LOGGER_NAME) -> logging.Logger:
    """
    Get or create the SDK logger instance.

    Returns a configured logger instance for the SDK. If the logger doesn't
    exist, creates it with a StreamHandler and appropriate formatter. The
    logger is cached globally to ensure consistent configuration across all
    SDK modules.

    Args:
        name: Logger name to use. Defaults to "lexmount". This parameter is
            primarily for internal use; external users should use the default.

    Returns:
        logging.Logger: Configured logger instance with StreamHandler and
            timestamp formatter. Default level is WARNING.

    Example:
        Internal use (SDK modules):

        >>> from lexmount._logging import get_logger
        >>> logger = get_logger()
        >>> logger.debug("Operation started")
        >>> logger.info("Operation completed successfully")

        External use (add custom handler):

        >>> import logging
        >>> from lexmount._logging import get_logger
        >>>
        >>> logger = get_logger()
        >>> # Add file handler
        >>> fh = logging.FileHandler("lexmount.log")
        >>> fh.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
        >>> logger.addHandler(fh)

    Note:
        - The logger is created only once and reused for efficiency
        - Default level is WARNING to minimize noise in production
        - Format: 'YYYY-MM-DD HH:MM:SS - lexmount - LEVEL - message'
        - Outputs to stderr by default
    """
    global _logger

    if _logger is not None and _logger.name == name:
        return _logger

    logger = logging.getLogger(name)

    # Only add handler if none exist (avoid duplicate handlers)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)

        # Set default level to WARNING to avoid verbose output by default
        logger.setLevel(logging.WARNING)

    _logger = logger
    return logger


def set_log_level(level: str = "WARNING") -> None:
    """
    Set the logging level for all SDK operations.

    Controls the verbosity of SDK logging output. Lower levels (DEBUG, INFO)
    provide more detailed information useful for debugging, while higher
    levels (WARNING, ERROR, CRITICAL) show only important messages.

    Args:
        level: Log level as string (case-insensitive). Valid values:
            - "DEBUG": Detailed debugging information including HTTP requests,
              responses, timing data, and internal state changes
            - "INFO": General informational messages about successful operations
              (e.g., session created, deleted)
            - "WARNING": Warning messages for non-fatal issues (default level)
            - "ERROR": Error messages for failures and exceptions
            - "CRITICAL": Critical error messages for severe failures

    Raises:
        ValueError: If an invalid log level string is provided. Valid levels
            are: DEBUG, INFO, WARNING, ERROR, CRITICAL.

    Example:
        Enable debug logging for development:

        >>> from lexmount import set_log_level, Lexmount
        >>>
        >>> set_log_level("DEBUG")
        >>> client = Lexmount(api_key="key", project_id="proj")
        >>> session = client.sessions.create()
        # Output:
        # 2026-01-16 10:30:00 - lexmount - DEBUG - POST request to https://api.lexmount.cn/instance
        # 2026-01-16 10:30:01 - lexmount - DEBUG - POST response: status=200, duration=1234.56ms
        # 2026-01-16 10:30:01 - lexmount - INFO - Session created successfully: id=abc123...

        Use INFO level for production monitoring:

        >>> set_log_level("INFO")
        >>> session = client.sessions.create()
        # Output:
        # 2026-01-16 10:30:01 - lexmount - INFO - Session created successfully: id=abc123...

        Minimize output in production:

        >>> set_log_level("WARNING")  # Only warnings and errors

        Set level based on environment:

        >>> import os
        >>> level = "DEBUG" if os.getenv("ENV") == "development" else "WARNING"
        >>> set_log_level(level)

    Note:
        - The level is set globally and affects all SDK operations
        - Default level is WARNING if not explicitly set
        - Case-insensitive: "debug" and "DEBUG" are equivalent
        - Changes take effect immediately for subsequent operations
    """
    logger = get_logger()

    # Validate and convert level
    level_upper = level.upper()
    numeric_level = getattr(logging, level_upper, None)

    if not isinstance(numeric_level, int):
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        raise ValueError(
            f"Invalid log level: {level}. "
            f"Valid levels are: {', '.join(valid_levels)}"
        )

    logger.setLevel(numeric_level)
    logger.debug(f"Log level set to {level_upper}")


def disable_logging() -> None:
    """
    Completely disable all logging output from the SDK.

    Sets the log level to a value higher than CRITICAL, effectively
    suppressing all log messages. This is useful when you want the SDK
    to run completely silently, even for critical errors.

    Example:
        Silence all SDK output:

        >>> from lexmount._logging import disable_logging
        >>> from lexmount import Lexmount
        >>>
        >>> disable_logging()
        >>> client = Lexmount(api_key="key", project_id="proj")
        >>> session = client.sessions.create()
        # No output at all

        Conditional logging:

        >>> from lexmount._logging import disable_logging, enable_logging
        >>> import os
        >>>
        >>> if os.getenv("SILENT_MODE"):
        ...     disable_logging()
        >>> # SDK runs silently in silent mode

    Note:
        - This affects all SDK operations globally
        - Even CRITICAL level messages will be suppressed
        - Use enable_logging() to restore logging
        - Exceptions are still raised normally; only logging is disabled

    See Also:
        - :func:`enable_logging`: Re-enable logging after disabling
        - :func:`set_log_level`: Set specific log level
    """
    logger = get_logger()
    logger.setLevel(logging.CRITICAL + 1)  # Higher than CRITICAL


def enable_logging(level: str = "INFO") -> None:
    """
    Re-enable logging after it was disabled.

    Restores logging to the specified level after disable_logging() was
    called. This is equivalent to calling set_log_level() but more
    semantically clear when used after disabling.

    Args:
        level: Log level to restore. Defaults to "INFO" for reasonable
            verbosity. Valid values: DEBUG, INFO, WARNING, ERROR, CRITICAL.

    Example:
        Toggle logging:

        >>> from lexmount._logging import disable_logging, enable_logging
        >>> from lexmount import Lexmount
        >>>
        >>> client = Lexmount(api_key="key", project_id="proj")
        >>>
        >>> # Temporarily disable for some operations
        >>> disable_logging()
        >>> session1 = client.sessions.create()  # Silent
        >>>
        >>> # Re-enable for others
        >>> enable_logging("DEBUG")
        >>> session2 = client.sessions.create()  # With debug logs

        Context-based logging:

        >>> def sensitive_operation():
        ...     disable_logging()
        ...     try:
        ...         # ... sensitive code ...
        ...         pass
        ...     finally:
        ...         enable_logging()  # Always restore

    Raises:
        ValueError: If an invalid log level string is provided

    See Also:
        - :func:`disable_logging`: Disable all logging
        - :func:`set_log_level`: Set specific log level
    """
    set_log_level(level)
