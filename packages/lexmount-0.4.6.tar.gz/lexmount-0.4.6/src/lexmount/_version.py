"""Version information for lexmount package."""

__version__ = "0.4.6"
