"""
Custom exceptions for the Lexmount SDK.

This module defines all exceptions that can be raised by the Lexmount SDK.
All exceptions inherit from the base LexmountError class, allowing users
to catch all SDK-specific errors with a single except clause.

Exception hierarchy:
    LexmountError (base)
    ├── AuthenticationError
    ├── SessionNotFoundError
    ├── ContextLockedError
    ├── ContextNotFoundError
    ├── APIError
    ├── NetworkError
    ├── ValidationError
    └── TimeoutError

Example:
    Catch all SDK errors:

    >>> from lexmount import Lexmount, LexmountError
    >>> try:
    ...     client = Lexmount(api_key="key", project_id="proj")
    ...     session = client.sessions.create()
    ... except LexmountError as e:
    ...     print(f"SDK error occurred: {e}")

    Catch specific errors:

    >>> from lexmount import (
    ...     AuthenticationError,
    ...     NetworkError,
    ...     TimeoutError
    ... )
    >>> try:
    ...     session = client.sessions.create()
    ... except AuthenticationError:
    ...     print("Invalid credentials")
    ... except NetworkError:
    ...     print("Network issue")
    ... except TimeoutError:
    ...     print("Request timed out")
"""

from typing import Optional


class LexmountError(Exception):
    """
    Base exception for all Lexmount SDK errors.

    All exceptions raised by the SDK inherit from this class,
    allowing you to catch all SDK-specific errors with a single except clause.
    This is useful for top-level error handling where you want to handle
    all SDK errors uniformly.

    Example:
        Catch any SDK error:

        >>> from lexmount import Lexmount, LexmountError
        >>> try:
        ...     client = Lexmount(api_key="key", project_id="proj")
        ...     session = client.sessions.create()
        ... except LexmountError as e:
        ...     logging.error(f"Lexmount SDK error: {e}")
        ...     # Handle or re-raise

        Check error type:

        >>> try:
        ...     session = client.sessions.create()
        ... except LexmountError as e:
        ...     if isinstance(e, AuthenticationError):
        ...         print("Auth failed")
        ...     else:
        ...         print(f"Other error: {e}")

    Note:
        It's generally better to catch specific exception types when possible
        for more precise error handling.
    """
    pass


class AuthenticationError(LexmountError):
    """
    Raised when API authentication fails.

    This exception is raised when the Lexmount API rejects the provided
    credentials (HTTP 401). Common causes include:

    - Invalid or missing API key
    - Invalid or missing project ID
    - Expired credentials
    - Insufficient permissions for the requested operation
    - API key not associated with the project

    Resolution:
        1. Verify your API key and project ID are correct
        2. Check that credentials haven't expired
        3. Ensure the API key has access to the specified project
        4. Contact support if credentials are correct but still failing

    Example:
        Handle authentication errors:

        >>> from lexmount import Lexmount, AuthenticationError
        >>> try:
        ...     client = Lexmount(api_key="invalid", project_id="invalid")
        ...     session = client.sessions.create()
        ... except AuthenticationError as e:
        ...     print("Authentication failed. Please check your credentials.")
        ...     print(f"Error: {e}")

        Retry with different credentials:

        >>> try:
        ...     session = client.sessions.create()
        ... except AuthenticationError:
        ...     # Try with backup credentials
        ...     client2 = Lexmount(api_key=backup_key, project_id=backup_proj)
        ...     session = client2.sessions.create()
    """
    pass


class SessionNotFoundError(LexmountError):
    """
    Session not found.

    Raised when trying to access or delete a session that doesn't exist.
    This can happen if:
    - Session was already deleted
    - Session ID is invalid
    - Session expired

    Example:
        >>> try:
        ...     client.sessions.delete(session_id="invalid-id")
        ... except SessionNotFoundError as e:
        ...     print(f"Session not found: {e}")
    """
    pass


class ContextLockedError(LexmountError):
    """
    Raised when attempting to access a context in read_write mode that is already locked.

    This exception is raised when you try to create a session with read_write mode
    on a context that is currently locked by another session (HTTP 409 with code
    'context_locked'). The context uses a single-writer concurrency model to ensure
    data consistency.

    Common causes:
    - Another session is actively using the context in read_write mode
    - A previous session didn't properly release the lock
    - Concurrent write attempts from multiple clients

    Attributes:
        message: Error message
        active_session_id: ID of the session currently holding the lock
        retry_after: Suggested retry delay in seconds

    Resolution:
        1. Wait for the active session to complete and retry
        2. Use read_only mode if you don't need to modify the context
        3. Use force_release() if the lock is stuck (emergency use only)
        4. Implement exponential backoff retry strategy

    Example:
        Handle with retry logic:

        >>> from lexmount import Lexmount, ContextLockedError
        >>> import time
        >>>
        >>> for attempt in range(3):
        ...     try:
        ...         session = client.sessions.create(
        ...             context={"id": "user_ctx", "mode": "read_write"}
        ...         )
        ...         break
        ...     except ContextLockedError as e:
        ...         print(f"Context locked by {e.active_session_id}")
        ...         time.sleep(e.retry_after or 5)

        Fallback to read_only mode:

        >>> try:
        ...     session = client.sessions.create(
        ...         context={"id": "user_ctx", "mode": "read_write"}
        ...     )
        ... except ContextLockedError:
        ...     # Fallback to read-only access
        ...     session = client.sessions.create(
        ...         context={"id": "user_ctx", "mode": "read_only"}
        ...     )
    """

    def __init__(
        self,
        message: str,
        active_session_id: Optional[str] = None,
        retry_after: Optional[int] = None
    ):
        """
        Initialize ContextLockedError.

        Args:
            message: Error message
            active_session_id: ID of the session holding the lock
            retry_after: Suggested retry delay in seconds
        """
        super().__init__(message)
        self.active_session_id = active_session_id
        self.retry_after = retry_after

    def __str__(self) -> str:
        """Return string representation of the error."""
        parts = [super().__str__()]
        if self.active_session_id:
            parts.append(f"(locked by session: {self.active_session_id})")
        if self.retry_after:
            parts.append(f"(retry after {self.retry_after}s)")
        return " ".join(parts)


class ContextNotFoundError(LexmountError):
    """
    Raised when a requested context does not exist.

    This exception is raised when you try to access, delete, or operate on
    a context that doesn't exist in the system (HTTP 404 with code
    'context_not_found').

    Common causes:
    - Context ID typo or incorrect ID
    - Context was already deleted
    - Context was never created
    - Wrong project scope

    Resolution:
        1. Verify the context ID is correct
        2. Check if context exists using contexts.list()
        3. Create the context first if needed
        4. Use implicit creation via sessions.create()

    Example:
        Handle missing context:

        >>> from lexmount import Lexmount, ContextNotFoundError
        >>> try:
        ...     context = client.contexts.get("nonexistent_id")
        ... except ContextNotFoundError:
        ...     print("Context not found, creating new one...")
        ...     context = client.contexts.create(id="nonexistent_id")

        Safe delete with error handling:

        >>> try:
        ...     client.contexts.delete("old_context")
        ... except ContextNotFoundError:
        ...     print("Context already deleted or never existed")
    """
    pass


class APIError(LexmountError):
    """
    API request failed.

    Raised when the Lexmount API returns an error response.
    Contains additional information about the error including
    status code and response data.

    Attributes:
        message: Error message
        status_code: HTTP status code (if available)
        response: Raw response data (if available)

    Example:
        >>> try:
        ...     session = client.sessions.create(browser_mode="invalid")
        ... except APIError as e:
        ...     print(f"API error: {e}")
        ...     print(f"Status code: {e.status_code}")
        ...     print(f"Response: {e.response}")
    """

    def __init__(self, message: str, status_code: int = None, response: dict = None):
        """
        Initialize APIError.

        Args:
            message: Error message
            status_code: HTTP status code
            response: Raw response data
        """
        super().__init__(message)
        self.status_code = status_code
        self.response = response

    def __str__(self) -> str:
        """Return string representation of the error."""
        parts = [super().__str__()]
        if self.status_code is not None:
            parts.append(f"(HTTP {self.status_code})")
        return " ".join(parts)


class NetworkError(LexmountError):
    """
    Network communication error.

    Raised when there's a network-level error communicating with the API.
    This can be caused by:
    - Connection timeout
    - DNS resolution failure
    - Network connectivity issues
    - SSL/TLS errors

    Example:
        >>> try:
        ...     session = client.sessions.create()
        ... except NetworkError as e:
        ...     print("Network error, please check your connection")
    """
    pass


class ValidationError(LexmountError):
    """
    Input validation error.

    Raised when input parameters fail validation.
    This indicates a client-side error that should be fixed
    before retrying the request.

    Example:
        >>> try:
        ...     client = Lexmount(api_key="", project_id="")
        ... except ValidationError as e:
        ...     print(f"Invalid input: {e}")
    """
    pass


class TimeoutError(LexmountError):
    """
    Raised when a request exceeds the configured timeout.

    This exception is raised when an API request takes longer than the
    timeout specified in the client configuration. This can happen due to:

    - Slow network connection
    - High server load
    - Large session creation times
    - Network congestion

    Resolution:
        1. Increase the timeout value in client initialization
        2. Check your network connection
        3. Retry the request
        4. Contact support if timeouts persist

    Example:
        Handle timeout with retry:

        >>> from lexmount import Lexmount, TimeoutError
        >>> import time
        >>>
        >>> client = Lexmount(api_key="key", project_id="proj", timeout=30.0)
        >>> for attempt in range(3):
        ...     try:
        ...         session = client.sessions.create()
        ...         break
        ...     except TimeoutError:
        ...         print(f"Timeout on attempt {attempt + 1}, retrying...")
        ...         time.sleep(2)

        Increase timeout for slow operations:

        >>> # For operations that typically take longer
        >>> client = Lexmount(
        ...     api_key="key",
        ...     project_id="proj",
        ...     timeout=120.0  # 2 minutes
        ... )
        >>> session = client.sessions.create()

    Note:
        The default timeout is 60 seconds. Adjust based on your needs and
        network conditions.
    """
    pass
