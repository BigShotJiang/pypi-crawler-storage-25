"""Lexmount Python SDK - Browser automation made simple."""

from ._version import __version__
from ._client import Lexmount
from ._sessions import (
    SessionCreateResponse,
    SessionInfo,
    SessionListResponse,
    PaginationInfo,
    SessionProxyConfig,
    SessionDownloadInfo,
    SessionDownloadsListResponse,
    SessionDownloadsDeleteResponse,
)
from ._contexts import ContextInfo, ContextListResponse
from ._extensions import ExtensionInfo
from .exceptions import (
    LexmountError,
    AuthenticationError,
    SessionNotFoundError,
    ContextLockedError,
    ContextNotFoundError,
    APIError,
    NetworkError,
    ValidationError,
    TimeoutError,
)
from ._logging import set_log_level

__all__ = [
    "Lexmount",
    # Sessions
    "SessionCreateResponse",
    "SessionInfo",
    "SessionListResponse",
    "PaginationInfo",
    "SessionProxyConfig",
    "SessionDownloadInfo",
    "SessionDownloadsListResponse",
    "SessionDownloadsDeleteResponse",
    # Contexts
    "ContextInfo",
    "ContextListResponse",
    # Extensions
    "ExtensionInfo",
    # Exceptions
    "LexmountError",
    "AuthenticationError",
    "SessionNotFoundError",
    "ContextLockedError",
    "ContextNotFoundError",
    "APIError",
    "NetworkError",
    "ValidationError",
    "TimeoutError",
    # Logging
    "set_log_level",
]
