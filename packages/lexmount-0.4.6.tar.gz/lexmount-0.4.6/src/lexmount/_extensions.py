"""Extensions resource for managing browser extensions."""
from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from ._client import Lexmount

from .exceptions import AuthenticationError, APIError
from ._logging import get_logger

logger = get_logger()


@dataclass
class ExtensionInfo:
    """Metadata describing an uploaded browser extension."""

    id: str
    name: str
    project_id: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    @classmethod
    def from_api(cls, data: dict) -> "ExtensionInfo":
        return cls(
            id=data["id"],
            name=data["name"],
            project_id=data["project_id"],
            created_at=_parse_dt(data.get("created_at")),
            updated_at=_parse_dt(data.get("updated_at")),
        )


def _parse_dt(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        logger.warning(f"Failed to parse extension timestamp: {value}")
        return None


class ExtensionsResource:
    """Resource for uploading, listing, reading, and deleting extensions."""

    def __init__(self, client: "Lexmount") -> None:
        self._client = client

    def upload(
        self,
        file_path: str,
        *,
        name: Optional[str] = None,
        project_id: Optional[str] = None,
    ) -> ExtensionInfo:
        """Upload a zip/crx extension archive and register it."""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Extension file not found: {file_path}")

        used_project_id = project_id or self._client.project_id
        url = f"{self._client.base_url}/instance/v1/extension/upload"

        with path.open("rb") as fp:
            response = self._client._post(
                url,
                data={
                    "project_id": used_project_id,
                    **({"name": name} if name else {}),
                },
                files={"file": (path.name, fp, "application/octet-stream")},
            )

        if response.status_code >= 400:
            error_data = response.json() if response.text else {}
            error_msg = error_data.get("message") or error_data.get("error", "Unknown error")
            if response.status_code == 401:
                raise AuthenticationError(
                    f"Authentication failed: {error_msg}. "
                    "Please check your API key and project ID."
                )
            raise APIError(
                f"Failed to upload extension: {error_msg}",
                status_code=response.status_code,
                response=error_data,
            )

        return ExtensionInfo.from_api(response.json())

    def list(
        self,
        *,
        project_id: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[ExtensionInfo]:
        """List uploaded extensions for the current project."""
        url = f"{self._client.base_url}/instance/v1/extension/list"
        response = self._client._post(
            url,
            json={
                "project_id": project_id or self._client.project_id,
                "limit": limit,
                "offset": offset,
            },
        )

        if response.status_code >= 400:
            error_data = response.json() if response.text else {}
            error_msg = error_data.get("message") or error_data.get("error", "Unknown error")
            raise APIError(
                f"Failed to list extensions: {error_msg}",
                status_code=response.status_code,
                response=error_data,
            )

        result = response.json()
        return [ExtensionInfo.from_api(item) for item in result.get("data", [])]

    def get(self, extension_id: str, *, project_id: Optional[str] = None) -> ExtensionInfo:
        """Fetch a single extension by id."""
        url = f"{self._client.base_url}/instance/v1/extension/info"
        response = self._client._post(
            url,
            json={
                "project_id": project_id or self._client.project_id,
                "extension_id": extension_id,
            },
        )

        if response.status_code >= 400:
            error_data = response.json() if response.text else {}
            error_msg = error_data.get("message") or error_data.get("error", "Unknown error")
            raise APIError(
                f"Failed to get extension: {error_msg}",
                status_code=response.status_code,
                response=error_data,
            )

        return ExtensionInfo.from_api(response.json())

    def delete(self, extension_id: str) -> None:
        """Delete an uploaded extension."""
        url = f"{self._client.base_url}/instance/v1/extension/{extension_id}"
        response = self._client._delete(url)
        if response.status_code >= 400:
            error_data = response.json() if response.text else {}
            error_msg = error_data.get("message") or error_data.get("error", "Unknown error")
            raise APIError(
                f"Failed to delete extension: {error_msg}",
                status_code=response.status_code,
                response=error_data,
            )
