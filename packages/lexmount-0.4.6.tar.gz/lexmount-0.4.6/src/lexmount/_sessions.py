"""Sessions resource for managing browser instances."""
import time
from typing import TYPE_CHECKING, Optional, List, TypedDict
from urllib.parse import urljoin
from datetime import datetime, timezone

if TYPE_CHECKING:
    from ._client import Lexmount

from .exceptions import (
    AuthenticationError,
    SessionNotFoundError,
    ContextLockedError,
    ContextNotFoundError,
    APIError,
    TimeoutError,
)
from ._logging import get_logger

logger = get_logger()


class SessionProxyConfig(TypedDict, total=False):
    """Proxy configuration for sessions.create()."""

    type: str
    server: str
    username: str
    password: str


class PaginationInfo:
    """
    Pagination information for session list responses.

    Contains metadata about the current page, total counts, and session status
    statistics returned by the sessions.list() API.

    Attributes:
        current_page (int): Current page number (1-indexed)
        page_size (int): Number of sessions per page
        total_count (int): Total number of sessions across all pages
        total_pages (int): Total number of pages available
        active_count (int): Number of active sessions
        closed_count (int): Number of closed sessions

    Example:
        >>> result = client.sessions.list()
        >>> print(result.pagination.total_count)
        42
        >>> print(result.pagination.active_count)
        10
    """

    def __init__(
        self,
        current_page: int,
        page_size: int,
        total_count: int,
        total_pages: int,
        active_count: int,
        closed_count: int
    ):
        """
        Initialize pagination information.

        Args:
            current_page: Current page number (1-indexed)
            page_size: Number of sessions per page
            total_count: Total number of sessions
            total_pages: Total number of pages
            active_count: Number of active sessions
            closed_count: Number of closed sessions
        """
        self.current_page = current_page
        self.page_size = page_size
        self.total_count = total_count
        self.total_pages = total_pages
        self.active_count = active_count
        self.closed_count = closed_count

    def __repr__(self) -> str:
        """
        Return string representation of pagination info.

        Returns:
            str: Formatted pagination information
        """
        return (
            f"PaginationInfo(page={self.current_page}/{self.total_pages}, "
            f"total={self.total_count}, active={self.active_count}, closed={self.closed_count})"
        )


class SessionListResponse:
    """
    Response object from sessions.list() containing sessions and pagination.

    This object is returned by the sessions.list() method and contains both
    the list of sessions and pagination metadata. It supports list-like
    operations for convenient access to sessions.

    Attributes:
        sessions (List[SessionInfo]): List of session information objects
        pagination (PaginationInfo): Pagination metadata

    Example:
        Direct iteration:

        >>> result = client.sessions.list()
        >>> for session in result:  # Iterates over sessions
        ...     print(session.id)

        List-like access:

        >>> print(len(result))  # Number of sessions
        >>> first_session = result[0]  # Index access
        >>> print(result.sessions)  # Direct access to list

        Pagination info:

        >>> print(result.pagination.total_count)
        >>> print(result.pagination.active_count)
    """

    def __init__(self, sessions: List["SessionInfo"], pagination: PaginationInfo):
        """
        Initialize session list response.

        Args:
            sessions: List of SessionInfo objects
            pagination: Pagination metadata
        """
        self.sessions = sessions
        self.pagination = pagination

    def __repr__(self) -> str:
        """
        Return string representation.

        Returns:
            str: Formatted string showing session count and pagination
        """
        return f"SessionListResponse(sessions={len(self.sessions)}, pagination={self.pagination!r})"

    def __iter__(self):
        """
        Allow iteration over sessions directly.

        Returns:
            Iterator[SessionInfo]: Iterator over sessions

        Example:
            >>> result = client.sessions.list()
            >>> for session in result:
            ...     print(session.id)
        """
        return iter(self.sessions)

    def __len__(self):
        """
        Return number of sessions in current page.

        Returns:
            int: Number of sessions

        Example:
            >>> result = client.sessions.list()
            >>> print(len(result))
        """
        return len(self.sessions)

    def __getitem__(self, index):
        """
        Allow indexing into sessions.

        Args:
            index: List index or slice

        Returns:
            SessionInfo or List[SessionInfo]: Session(s) at the given index

        Example:
            >>> result = client.sessions.list()
            >>> first = result[0]
            >>> first_three = result[0:3]
        """
        return self.sessions[index]


class SessionInfo:
    """
    Detailed information about a browser automation session.

    This class represents a browser session created through the Lexmount API.
    It contains all session metadata, WebSocket connection URLs, and provides
    methods for session management (close) and context manager support.

    Instances of this class are returned by both sessions.create() and
    sessions.list() methods, providing a unified interface for session
    information.

    Attributes:
        id (str): Unique session identifier
        session_id (str): Alias for id (for backward compatibility)
        status (str): Session status (e.g., "active", "closed")
        api_key (str): API key used for this session
        project_id (str): Project ID for this session
        browser_type (str): Browser mode (e.g., "normal", "light")
        created_at (str): ISO 8601 timestamp of session creation
        inspect_url (str): Chrome DevTools inspection URL
        container_id (Optional[str]): Docker container ID (if applicable)
        inspect_url_dbg (Optional[str]): Debug inspection URL
        ws (Optional[str]): WebSocket URL for Playwright connection
        connect_url (str): Alias for ws (for backward compatibility)
        create_error (Optional[str]): Error detail when session status is create_failed

    Example:
        Create and use a session:

        >>> session = client.sessions.create()
        >>> print(f"Session {session.id} created at {session.created_at}")
        >>> print(f"Connect via: {session.connect_url}")
        >>> session.close()

        With context manager:

        >>> with client.sessions.create() as session:
        ...     print(f"Using session {session.id}")
        ...     # Session automatically closed

        List sessions:

        >>> result = client.sessions.list()
        >>> for session in result.sessions:
        ...     print(f"{session.id}: {session.status}")

    See Also:
        - :meth:`SessionsResource.create`: Create a new session
        - :meth:`SessionsResource.list`: List existing sessions
        - :meth:`close`: Close this session
    """

    def __init__(
        self,
        id: Optional[str] = None,
        status: str = "active",
        api_key: str = "",
        project_id: str = "",
        browser_type: str = "normal",
        created_at: str = "",
        inspect_url: str = "",
        container_id: Optional[str] = None,
        inspect_url_dbg: Optional[str] = None,
        ws: Optional[str] = None,
        client: Optional["Lexmount"] = None,
        session_id: Optional[str] = None,  # Backward compatibility alias
        create_error: Optional[str] = None,
    ):
        """
        Initialize session information object.

        Args:
            id: Unique session identifier. Either this or session_id must be provided.
            status: Session status (default: "active")
            api_key: API key used for this session
            project_id: Project ID for this session
            browser_type: Browser mode (default: "normal")
            created_at: ISO 8601 timestamp of creation
            inspect_url: Chrome DevTools inspection URL
            container_id: Docker container ID (optional)
            inspect_url_dbg: Debug inspection URL (optional)
            ws: WebSocket URL for Playwright connection (optional)
            client: Lexmount client instance for session management (optional)
            session_id: Alias for id (for backward compatibility)
            create_error: Server-reported creation failure message when status is create_failed

        Raises:
            ValueError: If neither id nor session_id is provided

        Note:
            The client parameter is required for the close() method to work.
            When creating sessions via client.sessions.create(), the client
            is automatically provided.
        """
        # Support both 'id' and 'session_id' parameters for backward compatibility
        if session_id is not None and id is None:
            id = session_id
        elif id is None:
            raise ValueError("Either 'id' or 'session_id' must be provided")

        self.id = id
        self.session_id = id  # Alias for consistency
        self.status = status
        self.api_key = api_key
        self.project_id = project_id
        self.browser_type = browser_type
        self.created_at = created_at
        self.inspect_url = inspect_url
        self.container_id = container_id
        self.inspect_url_dbg = inspect_url_dbg
        self.ws = ws
        self.connect_url = ws or ""  # Alias for consistency
        self._client = client
        self._closed = False
        self.create_error = create_error

    @property
    def created_at_datetime(self) -> Optional[datetime]:
        """
        Parse created_at timestamp to datetime object.

        Converts the ISO 8601 timestamp string to a Python datetime object
        for easier date/time manipulation.

        Returns:
            datetime or None: Parsed datetime object, or None if parsing fails

        Example:
            >>> session = client.sessions.create()
            >>> dt = session.created_at_datetime
            >>> print(dt.strftime("%Y-%m-%d %H:%M:%S"))
            2025-10-13 10:30:00
        """
        try:
            # Handle ISO 8601 format: "2025-10-13T10:30:00.000Z"
            return datetime.fromisoformat(self.created_at.replace('Z', '+00:00'))
        except (ValueError, AttributeError):
            return None

    def close(self) -> None:
        """
        Close the browser session and release resources.

        Sends a request to the Lexmount API to terminate the browser session
        and release associated resources. This method is idempotent - calling
        it multiple times is safe and will not raise errors.

        Raises:
            No exceptions are raised. Errors are logged as warnings.

        Example:
            Manual cleanup:

            >>> session = client.sessions.create()
            >>> # ... use session ...
            >>> session.close()
            >>> session.close()  # Safe to call multiple times

            Automatic cleanup with context manager (recommended):

            >>> with client.sessions.create() as session:
            ...     # ... use session ...
            ...     pass  # Automatically closed on exit

        Note:
            - If the client was not provided during initialization, a warning
              is logged and the session is not closed.
            - Errors during close are logged but not raised to ensure
              idempotent behavior.
            - After closing, the session object remains valid but the remote
              browser instance is terminated.
        """
        if self._closed:
            logger.debug(f"Session {self.session_id} is already closed.")
            return

        if self._client is None:
            logger.warning(
                f"Cannot close session {self.session_id}: "
                "client was not provided during session creation."
            )
            return

        try:
            logger.debug(f"Closing session: {self.session_id}")
            self._client.sessions.delete(session_id=self.session_id)
            self._closed = True
            logger.info(f"Session closed: {self.session_id}")
        except Exception as e:
            # Log error but don't raise to make close() idempotent
            logger.warning(f"Failed to close session {self.session_id}: {e}")

    def __enter__(self):
        """
        Context manager entry point.

        Returns:
            SessionInfo: The session instance itself

        Example:
            >>> with client.sessions.create() as session:
            ...     print(f"Using session {session.id}")
            ...     # Session automatically closed on exit
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Context manager exit point.

        Automatically closes the session when exiting the context manager,
        regardless of whether an exception occurred.

        Args:
            exc_type: Exception type (if an exception occurred)
            exc_val: Exception value (if an exception occurred)
            exc_tb: Exception traceback (if an exception occurred)

        Returns:
            None: Does not suppress exceptions

        Note:
            The session is closed even if an exception occurs within the
            context manager block.
        """
        self.close()

    def __repr__(self) -> str:
        """
        Return string representation of the session.

        Returns:
            str: Formatted string showing key session attributes

        Example:
            >>> session = client.sessions.create()
            >>> print(repr(session))
            SessionInfo(id='abc123', status='active', browser_type='normal', created_at='2025-10-13T10:30:00.000Z')
        """
        status_str = "closed" if self._closed else self.status
        return (
            f"SessionInfo(id={self.id!r}, status={status_str!r}, "
            f"browser_type={self.browser_type!r}, created_at={self.created_at!r})"
        )


# Backward compatibility alias
# DEPRECATED: Use SessionInfo instead
SessionCreateResponse = SessionInfo


class SessionDownloadInfo:
    """Metadata for a single session download."""

    def __init__(
        self,
        *,
        id: str,
        filename: str,
        content_type: Optional[str],
        size: int,
        sha256: Optional[str],
        status: str,
        created_at: str,
    ):
        self.id = id
        self.filename = filename
        self.content_type = content_type
        self.size = size
        self.sha256 = sha256
        self.status = status
        self.created_at = created_at


class SessionDownloadsListResponse:
    """Structured response for session downloads list."""

    def __init__(self, downloads: List[SessionDownloadInfo], count: int, total_size: int):
        self.downloads = downloads
        self.summary = {
            "count": count,
            "total_size": total_size,
        }


class SessionDownloadsDeleteResponse:
    """Structured response for session downloads delete."""

    def __init__(self, status: str, deleted_count: int):
        self.status = status
        self.deleted_count = deleted_count


class SessionDownloadsResource:
    """Resource for session download operations."""

    def __init__(self, client: "Lexmount") -> None:
        self._client = client

    def list(
        self,
        session_id: str,
        *,
        project_id: Optional[str] = None,
    ) -> SessionDownloadsListResponse:
        url = f"{self._client.base_url}/instance/v1/sessions/{session_id}/downloads/list"
        response = self._client._post(url, json={
            "api_key": self._client.api_key,
            "project_id": project_id or self._client.project_id,
        })
        if response.status_code >= 400:
            self._raise_downloads_error("list session downloads", response, session_id)

        result = response.json()
        downloads = [
            SessionDownloadInfo(
                id=item["id"],
                filename=item["filename"],
                content_type=item.get("content_type"),
                size=item.get("size", 0),
                sha256=item.get("sha256"),
                status=item.get("status", "available"),
                created_at=item.get("created_at", ""),
            )
            for item in result.get("downloads", [])
        ]
        summary = result.get("summary", {})
        return SessionDownloadsListResponse(
            downloads=downloads,
            count=summary.get("count", len(downloads)),
            total_size=summary.get("total_size", 0),
        )

    def get(
        self,
        session_id: str,
        download_id: str,
        *,
        project_id: Optional[str] = None,
    ) -> bytes:
        url = f"{self._client.base_url}/instance/v1/sessions/{session_id}/downloads/{download_id}"
        response = self._client._get(url, params={
            "api_key": self._client.api_key,
            "project_id": project_id or self._client.project_id,
        })
        if response.status_code >= 400:
            self._raise_downloads_error("fetch session download", response, session_id)
        return response.content

    def archive(
        self,
        session_id: str,
        *,
        project_id: Optional[str] = None,
    ) -> bytes:
        url = f"{self._client.base_url}/instance/v1/sessions/{session_id}/downloads/archive"
        response = self._client._get(url, params={
            "api_key": self._client.api_key,
            "project_id": project_id or self._client.project_id,
        })
        if response.status_code >= 400:
            self._raise_downloads_error("archive session downloads", response, session_id)
        return response.content

    def delete(
        self,
        session_id: str,
        *,
        project_id: Optional[str] = None,
    ) -> SessionDownloadsDeleteResponse:
        url = f"{self._client.base_url}/instance/v1/sessions/{session_id}/downloads"
        response = self._client._delete(url, json={
            "api_key": self._client.api_key,
            "project_id": project_id or self._client.project_id,
        })
        if response.status_code >= 400:
            self._raise_downloads_error("delete session downloads", response, session_id)

        result = response.json()
        return SessionDownloadsDeleteResponse(
            status=result.get("status", ""),
            deleted_count=result.get("deleted_count", 0),
        )

    def _raise_downloads_error(self, action: str, response, session_id: str) -> None:
        error_data = response.json() if response.text else {}
        error_msg = error_data.get("error", "Unknown error")
        if response.status_code == 401:
            raise AuthenticationError(
                f"Authentication failed: {error_msg}. "
                "Please check your API key and project ID."
            )
        if response.status_code == 404:
            raise SessionNotFoundError(f"Session downloads not found for {session_id}: {error_msg}")
        raise APIError(
            f"Failed to {action}: {error_msg}",
            status_code=response.status_code,
            response=error_data,
        )


class SessionsResource:
    """
    Resource for managing browser automation sessions.

    This class provides methods for creating, listing, and deleting browser
    sessions through the Lexmount API. It is accessed via the `sessions`
    attribute of the Lexmount client.

    Example:
        >>> client = Lexmount(api_key="key", project_id="proj")
        >>> # Create a session
        >>> session = client.sessions.create()
        >>> # List sessions
        >>> result = client.sessions.list()
        >>> # Delete a session
        >>> client.sessions.delete(session_id=session.id)

    See Also:
        - :class:`SessionInfo`: Session information object
        - :class:`SessionListResponse`: List response with pagination
    """

    def __init__(self, client: "Lexmount") -> None:
        """
        Initialize the sessions resource.

        Args:
            client: The Lexmount client instance
        """
        self._client = client
        self.downloads = SessionDownloadsResource(client)

    def _session_from_api(self, raw: dict) -> SessionInfo:
        """Map a single-session API JSON object to SessionInfo."""
        data = dict(raw)
        if data.get("id") and not data.get("session_id"):
            data["session_id"] = data["id"]
        sid = data.get("session_id")
        if not sid:
            raise ValueError("session payload missing session_id or id")

        created = data.get("created_at")
        if isinstance(created, (int, float)):
            dt = datetime.fromtimestamp(created / 1000.0, tz=timezone.utc)
            created_at = dt.isoformat().replace("+00:00", "Z")
        else:
            created_at = created or ""

        return SessionInfo(
            id=sid,
            status=data.get("status", "unknown"),
            api_key=data.get("api_key") or self._client.api_key,
            project_id=data.get("project_id") or self._client.project_id,
            browser_type=data.get("browser_type") or data.get("browser_mode", "normal"),
            created_at=created_at,
            inspect_url=data.get("inspect_url") or "",
            container_id=data.get("container_id"),
            inspect_url_dbg=data.get("inspect_url_dbg"),
            ws=data.get("ws"),
            client=self._client,
            create_error=data.get("create_error"),
        )

    def _handle_create_error_response(self, response) -> None:
        """Raise a typed exception for failed session create (v1 or v2)."""
        error_data = response.json() if response.text else {}
        error_msg = error_data.get("error", "Unknown error")
        error_code = error_data.get("code", "")
        metadata = error_data.get("metadata", {})

        if response.status_code == 401:
            raise AuthenticationError(
                f"Authentication failed: {error_msg}. "
                "Please check your API key and project ID."
            )
        if response.status_code == 404:
            if error_code == "context_not_found":
                raise ContextNotFoundError(f"Context not found: {error_msg}")
            raise SessionNotFoundError(f"Resource not found: {error_msg}")
        if response.status_code == 409 and error_code == "context_locked":
            raise ContextLockedError(
                error_msg,
                active_session_id=metadata.get("activeSessionId"),
                retry_after=metadata.get("retryAfter"),
            )
        if response.status_code == 429:
            raise APIError(
                f"Active session limit reached: {error_msg}",
                status_code=429,
                response=error_data,
            )
        raise APIError(
            f"Failed to create session: {error_msg}",
            status_code=response.status_code,
            response=error_data,
        )

    def _build_create_payload(
        self,
        *,
        project_id: Optional[str],
        browser_mode: str,
        context: Optional[dict],
        extension_ids: Optional[List[str]],
        proxy: Optional[SessionProxyConfig],
        weak_lock: bool,
    ) -> dict:
        data = {
            "api_key": self._client.api_key,
            "project_id": project_id or self._client.project_id,
            "browser_mode": browser_mode,
        }
        if context:
            data["context"] = context
        if extension_ids:
            data["extension_ids"] = extension_ids
        if weak_lock:
            data["weak_lock"] = True
        if proxy:
            proxy_type = proxy.get("type", "external")
            proxy_server = proxy.get("server", "")
            if proxy_type != "external":
                raise ValueError("proxy.type must be 'external'")
            if not proxy_server:
                raise ValueError("proxy.server is required when proxy is provided")
            data["proxy"] = {
                "type": proxy_type,
                "server": proxy_server,
                "username": proxy.get("username", ""),
                "password": proxy.get("password", ""),
            }
        return data

    def get(
        self,
        session_id: str,
        *,
        project_id: Optional[str] = None,
    ) -> SessionInfo:
        """
        Fetch one session by id (any status), including creating / create_failed.

        Uses ``POST /instance/session`` — the same endpoint used to poll async
        creation started via :meth:`create` with ``async_create=True``.

        Args:
            session_id: Session identifier returned by the API.
            project_id: Project scope; defaults to the client's project id.

        Returns:
            SessionInfo: Current session record from the server.

        Raises:
            AuthenticationError: If credentials are rejected.
            SessionNotFoundError: If the session does not exist for this project.
            APIError: On other API failures.
        """
        url = f"{self._client.base_url}/instance/session"
        payload = {
            "api_key": self._client.api_key,
            "project_id": project_id or self._client.project_id,
            "session_id": session_id,
        }
        response = self._client._post(url, json=payload)
        if response.status_code >= 400:
            error_data = response.json() if response.text else {}
            error_msg = error_data.get("error", "Unknown error")
            if response.status_code == 401:
                raise AuthenticationError(
                    f"Authentication failed: {error_msg}. "
                    "Please check your API key and project ID."
                )
            if response.status_code == 404:
                raise SessionNotFoundError(f"Session not found: {error_msg}")
            raise APIError(
                f"Failed to get session: {error_msg}",
                status_code=response.status_code,
                response=error_data,
            )
        return self._session_from_api(response.json())

    def create(
        self,
        *,
        project_id: Optional[str] = None,
        browser_mode: str = "normal",
        context: Optional[dict] = None,
        extension_ids: Optional[List[str]] = None,
        proxy: Optional[SessionProxyConfig] = None,
        weak_lock: bool = False,
        async_create: bool = True,
        poll_interval_sec: float = 1.0,
        poll_timeout_sec: float = 600.0,
    ) -> SessionInfo:
        """
        Create a new browser automation session.

        Creates a remote browser instance on the Lexmount platform that can
        be controlled via Playwright or other automation tools using the
        provided WebSocket URL.

        Supports persistent browser contexts for preserving cookies, local storage,
        and other browser state across sessions using the context parameter.

        Note:
            When using context parameter, the context must already exist. Create
            contexts first using client.contexts.create() if needed.

        Args:
            project_id: Project ID to use for this session. If not provided,
                uses the client's default project ID from initialization.
            browser_mode: Browser mode to use. Available options:
                - "normal": Standard Chrome browser (default)
                - "light": Lightweight Chrome in Docker
            context: Optional persistent context configuration dict with:
                - "id" (str, required): Context identifier. Must be an existing context.
                - "mode" (str, required): Access mode - "read_write" or "read_only"
                    - "read_write": Exclusive write access. Context data is saved on exit.
                      Only one read_write session per context at a time. Raises
                      ContextLockedError if already locked.
                    - "read_only": Concurrent read access. Loads snapshot, no save on exit.
                      Multiple read_only sessions can run simultaneously.
            extension_ids: Optional list of uploaded extension IDs to mount into
                the browser instance.
            proxy: Optional upstream proxy configuration dict with:
                - "type" (str, optional): currently only supports "external"
                - "server" (str, required when provided): upstream proxy URL
                - "username" (str, optional): upstream proxy username
                - "password" (str, optional): upstream proxy password
            weak_lock: When True, forwards ``weak_lock`` to the API for read_write contexts.
            async_create: Defaults to ``True``. Uses ``POST /instance/v2`` to receive a
                ``session_id`` immediately (HTTP 202), then polls :meth:`get` until
                ``active`` or ``create_failed``. Set ``False`` to use legacy sync
                ``POST /instance`` behavior.
            poll_interval_sec: Delay between status polls when ``async_create`` is True.
            poll_timeout_sec: Maximum time to wait for ``active`` when ``async_create`` is True.

        Returns:
            SessionInfo: Object containing session information including:
                - id: Unique session identifier
                - connect_url / ws: WebSocket URL for Playwright connection
                - status: Session status (typically "active")
                - container_id: Docker container ID (if applicable)
                - inspect_url: Chrome DevTools inspection URL
                - created_at: ISO 8601 timestamp

        Raises:
            AuthenticationError: If API credentials are invalid or expired
            ContextLockedError: If context is already locked (409 with context mode=read_write)
            ContextNotFoundError: If specified context doesn't exist. Create the context
                first using client.contexts.create()
            ValidationError: If browser_mode, context, or other parameters are invalid
            APIError: If the API request fails for other reasons
            NetworkError: If there's a network connectivity issue
            TimeoutError: If ``async_create`` is True and ``poll_timeout_sec`` elapses before
                the session becomes ``active``, or if the HTTP client times out.

        Example:
            Basic usage (no context, async by default):

            >>> session = client.sessions.create()
            >>> print(f"Session ID: {session.id}")
            >>> print(f"Connect URL: {session.connect_url}")

            With persistent context (read_write mode):

            >>> # Create context first
            >>> context = client.contexts.create()
            >>> session = client.sessions.create(
            ...     context={"id": context.id, "mode": "read_write"}
            ... )
            >>> # Changes to cookies/storage are saved automatically on session.close()

            With persistent context (read_only mode):

            >>> session = client.sessions.create(
            ...     context={"id": "user_profile_001", "mode": "read_only"}
            ... )
            >>> # Loads context snapshot, changes are not saved

            Handle context lock conflict:

            >>> from lexmount import ContextLockedError
            >>> import time
            >>>
            >>> try:
            ...     session = client.sessions.create(
            ...         context={"id": "user_ctx", "mode": "read_write"}
            ...     )
            ... except ContextLockedError as e:
            ...     print(f"Locked by {e.active_session_id}, waiting...")
            ...     time.sleep(e.retry_after or 5)
            ...     # Retry or fallback to read_only

            With context manager (auto-cleanup):

            >>> with client.sessions.create(
            ...     context={"id": "my_ctx", "mode": "read_write"}
            ... ) as session:
            ...     # Use session
            ...     print(session.id)
            ...     # Context auto-saved and session closed on exit

            With authenticated upstream proxy:

            >>> session = client.sessions.create(
            ...     proxy={
            ...         "type": "external",
            ...         "server": "http://10.3.6.54:28080",
            ...         "username": "user",
            ...         "password": "pass",
            ...     }
            ... )

        Note:
            - Sessions consume resources and should be closed when done
            - Use context manager or call session.close() explicitly
            - Session creation time is logged at DEBUG level
            - Contexts must be created before use (not auto-created)
            - read_write mode provides exclusive access (single-writer)
            - read_only mode allows concurrent access (multiple-reader)

        See Also:
            - :meth:`delete`: Delete a session
            - :meth:`get`: Fetch session status (used for async_create polling)
            - :meth:`list`: List existing sessions
            - :meth:`SessionInfo.close`: Close a session
            - :class:`~lexmount.ContextInfo`: Context information and management
        """
        start_time = time.perf_counter()

        if context:
            logger.debug(
                f"Creating session with context (id={context.get('id')}, "
                f"mode={context.get('mode')})"
            )
        else:
            logger.debug(f"Creating session with browser_mode={browser_mode}")

        data = self._build_create_payload(
            project_id=project_id,
            browser_mode=browser_mode,
            context=context,
            extension_ids=extension_ids,
            proxy=proxy,
            weak_lock=weak_lock,
        )

        if proxy:
            proxy_type = proxy.get("type", "external")
            proxy_server = proxy.get("server", "")
            logger.debug(
                "Creating session with proxy "
                f"(type={proxy_type}, server={proxy_server}, "
                f"username={'set' if proxy.get('username') else 'empty'})"
            )

        used_project_id = project_id or self._client.project_id

        if async_create:
            url = f"{self._client.base_url}/instance/v2"
            response = self._client._post(url, json=data)
            if response.status_code >= 400:
                self._handle_create_error_response(response)
            result = response.json()
            session_id = result.get("session_id")
            if not session_id:
                raise APIError(
                    "instance/v2 response missing session_id",
                    status_code=response.status_code,
                    response=result,
                )
            deadline = time.monotonic() + poll_timeout_sec
            while time.monotonic() < deadline:
                info = self.get(session_id, project_id=used_project_id)
                if info.status == "active":
                    ws_url = self._get_web_socket_debugger_url(session_id)
                    elapsed = time.perf_counter() - start_time
                    logger.info(
                        f"Session created successfully (async): id={session_id}, "
                        f"container_id={info.container_id}"
                    )
                    logger.debug(f"Total session creation time: {elapsed*1000:.2f}ms")
                    return SessionInfo(
                        id=session_id,
                        status="active",
                        api_key=self._client.api_key,
                        project_id=used_project_id,
                        browser_type=info.browser_type or browser_mode,
                        created_at=info.created_at,
                        inspect_url=info.inspect_url or (
                            f"{self._client.base_url}/inspect?session_id={session_id}"
                        ),
                        container_id=info.container_id,
                        inspect_url_dbg=info.inspect_url_dbg,
                        ws=ws_url or info.ws,
                        client=self._client,
                    )
                if info.status == "create_failed":
                    raise APIError(
                        f"Session creation failed: {info.create_error or 'unknown error'}",
                        status_code=500,
                        response={
                            "session_id": session_id,
                            "status": info.status,
                            "create_error": info.create_error,
                        },
                    )
                if info.status == "closed":
                    raise APIError(
                        "Session closed before activation",
                        status_code=500,
                        response={"session_id": session_id, "status": info.status},
                    )
                time.sleep(poll_interval_sec)
            raise TimeoutError(
                f"Timed out waiting for session {session_id} to become active "
                f"after {poll_timeout_sec}s"
            )

        url = f"{self._client.base_url}/instance"
        response = self._client._post(url, json=data)
        if response.status_code >= 400:
            self._handle_create_error_response(response)

        result = response.json()
        session_id = result.get("session_id")
        container_id = result.get("container_id")
        ws_url = self._get_web_socket_debugger_url(session_id)

        elapsed = time.perf_counter() - start_time
        logger.info(
            f"Session created successfully: id={session_id}, "
            f"container_id={container_id}"
        )
        logger.debug(f"Total session creation time: {elapsed*1000:.2f}ms")

        return SessionInfo(
            id=session_id,
            status="active",
            api_key=self._client.api_key,
            project_id=used_project_id,
            browser_type=browser_mode,
            created_at=datetime.now().isoformat() + "Z",
            inspect_url=f"{self._client.base_url}/inspect?session_id={session_id}",
            container_id=container_id,
            ws=ws_url,
            client=self._client,
        )

    def delete(
        self,
        *,
        session_id: str,
        project_id: Optional[str] = None
    ) -> None:
        """
        Delete a browser session and release associated resources.

        Terminates the specified browser session on the Lexmount platform
        and frees up associated resources (browser instance, containers, etc.).
        This operation is final and cannot be undone.

        Args:
            session_id: Unique identifier of the session to delete. This is
                the `id` field from a SessionInfo object.
            project_id: Project ID to use. If not provided, uses the client's
                default project ID from initialization.

        Raises:
            AuthenticationError: If API credentials are invalid or expired
            SessionNotFoundError: If the session doesn't exist (already deleted
                or never existed)
            APIError: If the deletion request fails for other reasons
            NetworkError: If there's a network connectivity issue
            TimeoutError: If the request exceeds the configured timeout

        Example:
            Basic deletion:

            >>> session = client.sessions.create()
            >>> # ... use session ...
            >>> client.sessions.delete(session_id=session.id)

            Delete from session object:

            >>> session = client.sessions.create()
            >>> # ... use session ...
            >>> session.close()  # Internally calls delete

            Delete multiple sessions:

            >>> result = client.sessions.list()
            >>> for session in result.sessions:
            ...     client.sessions.delete(session_id=session.id)

        Note:
            - Deletion is permanent and cannot be reversed
            - Attempting to delete an already-deleted session raises SessionNotFoundError
            - Deletion time is logged at DEBUG level
            - It's recommended to use session.close() or context managers
              rather than calling delete() directly

        See Also:
            - :meth:`create`: Create a new session
            - :meth:`list`: List existing sessions
            - :meth:`SessionInfo.close`: Close a session (preferred method)
        """
        start_time = time.perf_counter()
        url = f"{self._client.base_url}/instance"

        data = {
            "api_key": self._client.api_key,
            "project_id": project_id or self._client.project_id,
            "session_id": session_id
        }

        logger.debug(f"Deleting session: {session_id}")
        response = self._client._delete(url, json=data)

        # Handle error responses
        if response.status_code >= 400:
            error_data = response.json() if response.text else {}
            error_msg = error_data.get("error", "Unknown error")

            # Map status codes to specific exceptions
            if response.status_code == 401:
                raise AuthenticationError(
                    f"Authentication failed: {error_msg}. "
                    "Please check your API key and project ID."
                )
            elif response.status_code == 404:
                raise SessionNotFoundError(
                    f"Session not found: {error_msg}. "
                    f"Session ID '{session_id}' may have already been deleted or never existed."
                )
            else:
                raise APIError(
                    f"Failed to delete session: {error_msg}",
                    status_code=response.status_code,
                    response=error_data
                )

        elapsed = time.perf_counter() - start_time
        logger.info(f"Session deleted successfully: {session_id}")
        logger.debug(f"Total session deletion time: {elapsed*1000:.2f}ms")

    def list(
        self,
        *,
        project_id: Optional[str] = None,
        status: Optional[str] = None
    ) -> SessionListResponse:
        """
        List browser sessions with pagination and filtering.

        Retrieves a list of browser sessions for the specified project,
        with optional server-side filtering by status. Returns a
        SessionListResponse object containing the sessions and pagination
        metadata.

        Args:
            project_id: Project ID to list sessions for. If not provided,
                uses the client's default project ID from initialization.
            status: Filter sessions by status (server-side filtering).
                Common values:
                - "active": Only active/running sessions
                - "closed": Only closed/terminated sessions
                - None: All sessions regardless of status (default)

        Returns:
            SessionListResponse: Object containing:
                - sessions: List of SessionInfo objects
                - pagination: PaginationInfo with:
                    - current_page, page_size, total_count, total_pages
                    - active_count: Number of active sessions
                    - closed_count: Number of closed sessions

        Raises:
            AuthenticationError: If API credentials are invalid or expired
            APIError: If the API request fails
            NetworkError: If there's a network connectivity issue
            TimeoutError: If the request exceeds the configured timeout

        Example:
            List all sessions:

            >>> result = client.sessions.list()
            >>> print(f"Total sessions: {result.pagination.total_count}")
            >>> print(f"Active: {result.pagination.active_count}")
            >>> for session in result.sessions:
            ...     print(f"{session.id}: {session.status}")

            List only active sessions:

            >>> active = client.sessions.list(status="active")
            >>> print(f"Found {len(active)} active sessions")

            List-like access:

            >>> result = client.sessions.list()
            >>> print(len(result))  # Number of sessions
            >>> first_session = result[0]  # Index access
            >>> for session in result:  # Direct iteration
            ...     print(session.id)

            Pagination info:

            >>> result = client.sessions.list()
            >>> print(f"Page {result.pagination.current_page} of {result.pagination.total_pages}")
            >>> print(f"Active: {result.pagination.active_count}, Closed: {result.pagination.closed_count}")

            Clean up old sessions:

            >>> result = client.sessions.list(status="active")
            >>> for session in result.sessions:
            ...     session.close()

        Note:
            - Status filtering is performed server-side for better performance
            - The response includes pagination metadata even for single-page results
            - Each SessionInfo in the list includes the client reference for cleanup
            - Request duration is logged at DEBUG level

        See Also:
            - :class:`SessionListResponse`: Response object with list-like behavior
            - :class:`PaginationInfo`: Pagination metadata
            - :meth:`create`: Create a new session
            - :meth:`delete`: Delete a session
        """
        start_time = time.perf_counter()
        url = f"{self._client.base_url}/instance/v2/sessions"

        data = {
            "api_key": self._client.api_key,
            "project_id": project_id or self._client.project_id
        }

        # Add status filter if specified (server-side filtering)
        if status is not None:
            data["status"] = status

        logger.debug(f"Fetching session list for project: {project_id or self._client.project_id}" +
                    (f", status={status}" if status else ""))
        response = self._client._post(url, json=data)

        # Handle error responses
        if response.status_code >= 400:
            error_data = response.json() if response.text else {}
            error_msg = error_data.get("error", "Unknown error")

            # Map status codes to specific exceptions
            if response.status_code == 401:
                raise AuthenticationError(
                    f"Authentication failed: {error_msg}. "
                    "Please check your API key and project ID."
                )
            else:
                raise APIError(
                    f"Failed to list sessions: {error_msg}",
                    status_code=response.status_code,
                    response=error_data
                )

        result = response.json()

        # Parse new response structure with pagination
        sessions_data = result.get("sessions", [])
        pagination_data = result.get("pagination", {})

        # Convert response to SessionInfo objects
        sessions = []
        for session_data in sessions_data:
            sessions.append(self._session_from_api(session_data))

        # Parse pagination info
        pagination = PaginationInfo(
            current_page=pagination_data.get("currentPage", 1),
            page_size=pagination_data.get("pageSize", len(sessions)),
            total_count=pagination_data.get("totalCount", len(sessions)),
            total_pages=pagination_data.get("totalPages", 1),
            active_count=pagination_data.get("activeCount", 0),
            closed_count=pagination_data.get("closedCount", 0)
        )

        elapsed = time.perf_counter() - start_time
        logger.info(
            f"Retrieved {len(sessions)} sessions "
            f"(total: {pagination.total_count}, active: {pagination.active_count}, closed: {pagination.closed_count})"
        )
        logger.debug(f"Total session list time: {elapsed*1000:.2f}ms")

        return SessionListResponse(sessions=sessions, pagination=pagination)

    def _get_web_socket_debugger_url(self, session_id: str) -> Optional[str]:
        """
        Get the WebSocket debugger URL for a session (internal method).

        Queries the /json/version endpoint to retrieve the WebSocket URL
        that can be used to connect to the browser session via Chrome DevTools
        Protocol (CDP). Prefers the transformed URL which includes the session_id.

        Args:
            session_id: Unique identifier of the session

        Returns:
            str or None: WebSocket URL for CDP connection, or None if retrieval fails

        Note:
            This is an internal method used by create(). It:
            - Prefers webSocketDebuggerUrlTransformed (includes session_id)
            - Falls back to webSocketDebuggerUrl if transformed version unavailable
            - Returns None and logs error if the request fails
            - Does not raise exceptions to avoid breaking session creation
        """
        try:
            url = urljoin(self._client.base_url, '/json/version')
            params = {'session_id': session_id}

            logger.debug(f"Fetching WebSocket URL for session: {session_id}")
            response = self._client._http_client.get(url, params=params)
            response.raise_for_status()

            data = response.json()
            # 后端直接提供转换后的 URL，包含了 session_id，可直接使用
            ws_url = data.get('webSocketDebuggerUrlTransformed') or data.get('webSocketDebuggerUrl')
            logger.debug(f"WebSocket URL retrieved: {ws_url}")
            return ws_url
        except Exception as e:
            logger.error(f"Error getting WebSocket debugger URL: {e}")
            return None
