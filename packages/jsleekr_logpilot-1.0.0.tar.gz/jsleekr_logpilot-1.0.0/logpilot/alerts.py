"""Alerting rules for log monitoring."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Sequence

from logpilot.models import LogEntry, LogLevel


@dataclass
class Alert:
    """A triggered alert."""
    rule_name: str
    severity: str  # "critical", "warning", "info"
    message: str
    triggered_at: datetime | None = None
    context: dict[str, Any] = field(default_factory=dict)
    sample_entries: list[LogEntry] = field(default_factory=list)


@dataclass
class AlertRule:
    """A rule that checks log entries and triggers alerts."""
    name: str
    description: str
    severity: str
    check_fn: Callable[[list[LogEntry]], Alert | None]

    def check(self, entries: list[LogEntry]) -> Alert | None:
        return self.check_fn(entries)


class AlertEngine:
    """Engine for evaluating alert rules against log entries."""

    def __init__(self) -> None:
        self._rules: list[AlertRule] = []

    def add_rule(self, rule: AlertRule) -> None:
        self._rules.append(rule)

    def evaluate(self, entries: list[LogEntry]) -> list[Alert]:
        """Evaluate all rules against entries."""
        alerts: list[Alert] = []
        for rule in self._rules:
            alert = rule.check(entries)
            if alert is not None:
                alerts.append(alert)
        return alerts

    @property
    def rule_count(self) -> int:
        return len(self._rules)


def error_rate_rule(threshold_pct: float = 20.0) -> AlertRule:
    """Create a rule that alerts when error rate exceeds threshold."""
    def check(entries: list[LogEntry]) -> Alert | None:
        if not entries:
            return None
        error_count = sum(1 for e in entries if e.level >= LogLevel.ERROR)
        rate = error_count / len(entries) * 100
        if rate > threshold_pct:
            return Alert(
                rule_name="high_error_rate",
                severity="critical" if rate > 50 else "warning",
                message=f"Error rate {rate:.1f}% exceeds threshold {threshold_pct}%",
                context={"error_count": error_count, "total": len(entries), "rate": rate},
            )
        return None
    return AlertRule(
        name="high_error_rate",
        description=f"Error rate exceeds {threshold_pct}%",
        severity="warning",
        check_fn=check,
    )


def fatal_count_rule(max_count: int = 0) -> AlertRule:
    """Alert when any FATAL entries are detected."""
    def check(entries: list[LogEntry]) -> Alert | None:
        fatals = [e for e in entries if e.level == LogLevel.FATAL]
        if len(fatals) > max_count:
            return Alert(
                rule_name="fatal_detected",
                severity="critical",
                message=f"{len(fatals)} FATAL entries detected",
                sample_entries=fatals[:3],
                context={"count": len(fatals)},
            )
        return None
    return AlertRule(
        name="fatal_detected",
        description="FATAL log entries detected",
        severity="critical",
        check_fn=check,
    )


def pattern_alert_rule(
    name: str,
    pattern: str,
    severity: str = "warning",
    max_count: int = 0,
) -> AlertRule:
    """Alert when a pattern appears more than max_count times."""
    import re
    compiled = re.compile(pattern, re.IGNORECASE)

    def check(entries: list[LogEntry]) -> Alert | None:
        matches = [e for e in entries if compiled.search(e.message)]
        if len(matches) > max_count:
            return Alert(
                rule_name=name,
                severity=severity,
                message=f"Pattern '{pattern}' matched {len(matches)} times",
                sample_entries=matches[:3],
                context={"count": len(matches), "pattern": pattern},
            )
        return None
    return AlertRule(
        name=name,
        description=f"Pattern match: {pattern}",
        severity=severity,
        check_fn=check,
    )


def no_logs_rule(min_entries: int = 1) -> AlertRule:
    """Alert when too few entries are present (possible log pipeline failure)."""
    def check(entries: list[LogEntry]) -> Alert | None:
        if len(entries) < min_entries:
            return Alert(
                rule_name="no_logs",
                severity="critical",
                message=f"Only {len(entries)} entries found (minimum: {min_entries})",
                context={"count": len(entries), "minimum": min_entries},
            )
        return None
    return AlertRule(
        name="no_logs",
        description=f"Fewer than {min_entries} log entries",
        severity="critical",
        check_fn=check,
    )


def create_default_engine() -> AlertEngine:
    """Create an alert engine with default rules."""
    engine = AlertEngine()
    engine.add_rule(error_rate_rule(20.0))
    engine.add_rule(fatal_count_rule(0))
    engine.add_rule(pattern_alert_rule("oom", r"out\s*of\s*memory|OOM", "critical"))
    engine.add_rule(no_logs_rule(1))
    return engine
