"""logpilot - Structured JSON log viewer and analyzer for the terminal."""

__version__ = "1.0.0"
