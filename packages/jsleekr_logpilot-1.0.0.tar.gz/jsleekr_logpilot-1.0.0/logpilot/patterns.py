"""Pre-defined patterns for common log formats and known issues."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Sequence

from logpilot.models import LogEntry, LogLevel


@dataclass
class PatternMatch:
    """A match against a known pattern."""
    pattern_name: str
    description: str
    severity: LogLevel
    entries: list[LogEntry] = field(default_factory=list)
    count: int = 0
    suggestion: str = ""


@dataclass
class PatternRule:
    """A rule for detecting known patterns."""
    name: str
    description: str
    severity: LogLevel
    field: str  # which field to check: "message", "raw", or a custom field
    pattern: str  # regex pattern
    suggestion: str = ""
    _compiled: re.Pattern[str] | None = None

    def compile(self) -> re.Pattern[str]:
        if self._compiled is None:
            self._compiled = re.compile(self.pattern, re.IGNORECASE)
        return self._compiled

    def matches(self, entry: LogEntry) -> bool:
        """Check if entry matches this pattern."""
        compiled = self.compile()
        if self.field == "message":
            return bool(compiled.search(entry.message))
        if self.field == "raw":
            return bool(compiled.search(entry.raw))
        val = entry.get(self.field)
        if val is not None:
            return bool(compiled.search(str(val)))
        return False


# Built-in patterns for common issues
BUILTIN_PATTERNS: list[PatternRule] = [
    PatternRule(
        name="oom",
        description="Out of memory error",
        severity=LogLevel.FATAL,
        field="message",
        pattern=r"out\s*of\s*memory|OOM|heap\s*space|memory\s*limit",
        suggestion="Check memory limits and consider scaling up or optimizing memory usage.",
    ),
    PatternRule(
        name="connection_refused",
        description="Connection refused error",
        severity=LogLevel.ERROR,
        field="message",
        pattern=r"connection\s*refused|ECONNREFUSED|connect\s*failed",
        suggestion="Check if the target service is running and accessible.",
    ),
    PatternRule(
        name="timeout",
        description="Timeout error",
        severity=LogLevel.ERROR,
        field="message",
        pattern=r"timeout|timed?\s*out|deadline\s*exceeded|ETIMEDOUT",
        suggestion="Consider increasing timeout values or investigating slow dependencies.",
    ),
    PatternRule(
        name="disk_full",
        description="Disk space error",
        severity=LogLevel.FATAL,
        field="message",
        pattern=r"no\s*space\s*left|disk\s*full|ENOSPC|quota\s*exceeded",
        suggestion="Free disk space or increase storage allocation.",
    ),
    PatternRule(
        name="auth_failure",
        description="Authentication/authorization failure",
        severity=LogLevel.WARN,
        field="message",
        pattern=r"unauthorized|forbidden|auth.*fail|invalid\s*token|401|403",
        suggestion="Check credentials and permissions.",
    ),
    PatternRule(
        name="rate_limit",
        description="Rate limiting detected",
        severity=LogLevel.WARN,
        field="message",
        pattern=r"rate\s*limit|too\s*many\s*requests|429|throttl",
        suggestion="Implement backoff strategy or request a rate limit increase.",
    ),
    PatternRule(
        name="dns_failure",
        description="DNS resolution failure",
        severity=LogLevel.ERROR,
        field="message",
        pattern=r"dns.*fail|ENOTFOUND|name.*resolution|getaddrinfo",
        suggestion="Check DNS configuration and network connectivity.",
    ),
    PatternRule(
        name="ssl_error",
        description="SSL/TLS error",
        severity=LogLevel.ERROR,
        field="message",
        pattern=r"ssl|tls|certificate.*(?:expired|invalid|error)|CERT_",
        suggestion="Check certificate validity and SSL configuration.",
    ),
    PatternRule(
        name="null_pointer",
        description="Null pointer / undefined error",
        severity=LogLevel.ERROR,
        field="message",
        pattern=r"null\s*pointer|NullPointer|undefined\s*is\s*not|cannot\s*read\s*propert",
        suggestion="Add null checks and validate input data.",
    ),
    PatternRule(
        name="deadlock",
        description="Deadlock detected",
        severity=LogLevel.FATAL,
        field="message",
        pattern=r"deadlock|lock\s*timeout|lock\s*contention",
        suggestion="Review locking strategy and transaction isolation levels.",
    ),
]


def scan_patterns(
    entries: Sequence[LogEntry],
    patterns: list[PatternRule] | None = None,
) -> list[PatternMatch]:
    """Scan entries against known patterns."""
    if patterns is None:
        patterns = BUILTIN_PATTERNS

    matches: dict[str, PatternMatch] = {}

    for entry in entries:
        for pattern in patterns:
            if pattern.matches(entry):
                if pattern.name not in matches:
                    matches[pattern.name] = PatternMatch(
                        pattern_name=pattern.name,
                        description=pattern.description,
                        severity=pattern.severity,
                        suggestion=pattern.suggestion,
                    )
                match = matches[pattern.name]
                match.count += 1
                if len(match.entries) < 3:  # keep up to 3 samples
                    match.entries.append(entry)

    result = list(matches.values())
    result.sort(key=lambda m: (m.severity.value, m.count), reverse=True)
    return result


def create_custom_pattern(
    name: str,
    pattern: str,
    field: str = "message",
    severity: LogLevel = LogLevel.WARN,
    description: str = "",
    suggestion: str = "",
) -> PatternRule:
    """Create a custom pattern rule."""
    return PatternRule(
        name=name,
        description=description or f"Custom pattern: {name}",
        severity=severity,
        field=field,
        pattern=pattern,
        suggestion=suggestion,
    )
