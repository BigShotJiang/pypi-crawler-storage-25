"""Simple query language for filtering logs.

Supports expressions like:
    level:error
    level:>=warn
    source:api
    msg:timeout
    field.name:value
    status:>=400
    method:GET AND path:/api
    level:error OR level:fatal
    NOT source:healthcheck
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from typing import Sequence

from logpilot.models import LogEntry, LogLevel


class TokenType(Enum):
    FIELD_VALUE = "field_value"
    AND = "and"
    OR = "or"
    NOT = "not"
    LPAREN = "lparen"
    RPAREN = "rparen"


@dataclass
class Token:
    type: TokenType
    value: str = ""
    field: str = ""
    operator: str = "="


@dataclass
class QueryResult:
    entries: list[LogEntry]
    total_scanned: int
    matched: int
    query_str: str


def tokenize(query: str) -> list[Token]:
    """Tokenize a query string into tokens."""
    tokens: list[Token] = []
    parts = _split_preserving_quotes(query)

    for part in parts:
        upper = part.upper()
        if upper == "AND":
            tokens.append(Token(type=TokenType.AND))
        elif upper == "OR":
            tokens.append(Token(type=TokenType.OR))
        elif upper == "NOT":
            tokens.append(Token(type=TokenType.NOT))
        elif part == "(":
            tokens.append(Token(type=TokenType.LPAREN))
        elif part == ")":
            tokens.append(Token(type=TokenType.RPAREN))
        elif ":" in part:
            field, _, value = part.partition(":")
            op = "="
            # Check for comparison operators
            if value.startswith(">="):
                op = ">="
                value = value[2:]
            elif value.startswith("<="):
                op = "<="
                value = value[2:]
            elif value.startswith(">"):
                op = ">"
                value = value[1:]
            elif value.startswith("<"):
                op = "<"
                value = value[1:]
            elif value.startswith("!="):
                op = "!="
                value = value[2:]
            elif value.startswith("~"):
                op = "~"  # regex
                value = value[1:]
            # Remove quotes
            value = value.strip('"').strip("'")
            tokens.append(Token(type=TokenType.FIELD_VALUE, field=field, value=value, operator=op))
        else:
            # Plain text search
            tokens.append(Token(type=TokenType.FIELD_VALUE, field="msg", value=part, operator="~"))

    return tokens


def evaluate_query(entry: LogEntry, tokens: list[Token]) -> bool:
    """Evaluate a tokenized query against a log entry."""
    if not tokens:
        return True

    # Simple evaluation: process tokens linearly
    # Handle NOT, then AND/OR
    result = True
    current_op = "AND"
    negate = False

    for token in tokens:
        if token.type == TokenType.NOT:
            negate = True
            continue
        if token.type == TokenType.AND:
            current_op = "AND"
            continue
        if token.type == TokenType.OR:
            current_op = "OR"
            continue
        if token.type in (TokenType.LPAREN, TokenType.RPAREN):
            continue

        if token.type == TokenType.FIELD_VALUE:
            match = _evaluate_field(entry, token)
            if negate:
                match = not match
                negate = False

            if current_op == "AND":
                result = result and match
            elif current_op == "OR":
                result = result or match

    return result


def execute_query(
    entries: Sequence[LogEntry],
    query: str,
) -> QueryResult:
    """Execute a query against log entries."""
    tokens = tokenize(query)
    matched: list[LogEntry] = []

    for entry in entries:
        if evaluate_query(entry, tokens):
            matched.append(entry)

    return QueryResult(
        entries=matched,
        total_scanned=len(entries),
        matched=len(matched),
        query_str=query,
    )


def _evaluate_field(entry: LogEntry, token: Token) -> bool:
    """Evaluate a field:value condition against an entry."""
    field = token.field.lower()
    value = token.value
    op = token.operator

    # Special fields
    if field == "level" or field == "lvl":
        return _compare_level(entry.level, value, op)
    if field == "msg" or field == "message":
        return _compare_string(entry.message, value, op)
    if field == "source" or field == "logger":
        return _compare_string(entry.source, value, op)
    if field == "json":
        return entry.is_json if value.lower() == "true" else not entry.is_json

    # Generic field lookup
    actual = entry.get(token.field)  # use original case for field lookup
    if actual is None:
        actual = entry.get(field)
    if actual is None:
        return op == "!="  # field doesn't exist, != matches

    return _compare_value(actual, value, op)


def _compare_level(level: LogLevel, value: str, op: str) -> bool:
    """Compare a log level with an operator."""
    try:
        target = LogLevel.from_string(value)
    except (KeyError, ValueError):
        return False

    if op == "=":
        return level == target
    if op == "!=":
        return level != target
    if op == ">=":
        return level >= target
    if op == "<=":
        return level <= target
    if op == ">":
        return level > target
    if op == "<":
        return level < target
    if op == "~":
        return level == target
    return level == target


def _compare_string(actual: str, expected: str, op: str) -> bool:
    """Compare strings with operator support."""
    if op == "=":
        return actual.lower() == expected.lower()
    if op == "!=":
        return actual.lower() != expected.lower()
    if op == "~":
        return expected.lower() in actual.lower()
    return actual.lower() == expected.lower()


def _compare_value(actual: object, expected: str, op: str) -> bool:
    """Compare a value (may be numeric) with an operator."""
    # Try numeric comparison
    try:
        actual_num = float(str(actual))
        expected_num = float(expected)
        if op == "=":
            return actual_num == expected_num
        if op == "!=":
            return actual_num != expected_num
        if op == ">=":
            return actual_num >= expected_num
        if op == "<=":
            return actual_num <= expected_num
        if op == ">":
            return actual_num > expected_num
        if op == "<":
            return actual_num < expected_num
    except (ValueError, TypeError):
        pass

    # Fall back to string comparison
    actual_str = str(actual)
    if op == "~":
        return expected.lower() in actual_str.lower()
    if op == "!=":
        return actual_str.lower() != expected.lower()
    return actual_str.lower() == expected.lower()


def _split_preserving_quotes(text: str) -> list[str]:
    """Split text on whitespace, preserving quoted strings."""
    parts: list[str] = []
    current = ""
    in_quote = False
    quote_char = ""

    for char in text:
        if char in ('"', "'") and not in_quote:
            in_quote = True
            quote_char = char
            current += char
        elif char == quote_char and in_quote:
            in_quote = False
            current += char
            quote_char = ""
        elif char == " " and not in_quote:
            if current:
                parts.append(current)
                current = ""
        else:
            current += char

    if current:
        parts.append(current)

    return parts
