"""Bookmark and annotation support for log entries."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Sequence

from logpilot.models import LogEntry


@dataclass
class Bookmark:
    """A bookmarked log entry with optional annotation."""
    line_number: int
    message: str
    annotation: str = ""
    tags: list[str] = field(default_factory=list)
    created_at: str = ""
    source_file: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "line_number": self.line_number,
            "message": self.message,
            "annotation": self.annotation,
            "tags": self.tags,
            "created_at": self.created_at,
            "source_file": self.source_file,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Bookmark:
        return cls(
            line_number=data.get("line_number", 0),
            message=data.get("message", ""),
            annotation=data.get("annotation", ""),
            tags=data.get("tags", []),
            created_at=data.get("created_at", ""),
            source_file=data.get("source_file", ""),
        )


@dataclass
class BookmarkStore:
    """Collection of bookmarks for a log file."""
    bookmarks: list[Bookmark] = field(default_factory=list)
    source_file: str = ""

    def add(
        self,
        entry: LogEntry,
        annotation: str = "",
        tags: list[str] | None = None,
    ) -> Bookmark:
        """Bookmark a log entry."""
        bookmark = Bookmark(
            line_number=entry.line_number,
            message=entry.message,
            annotation=annotation,
            tags=tags or [],
            created_at=datetime.now().isoformat(),
            source_file=self.source_file,
        )
        self.bookmarks.append(bookmark)
        return bookmark

    def remove(self, line_number: int) -> bool:
        """Remove bookmark by line number."""
        original_len = len(self.bookmarks)
        self.bookmarks = [b for b in self.bookmarks if b.line_number != line_number]
        return len(self.bookmarks) < original_len

    def get_by_line(self, line_number: int) -> Bookmark | None:
        """Get bookmark at a specific line."""
        for b in self.bookmarks:
            if b.line_number == line_number:
                return b
        return None

    def get_by_tag(self, tag: str) -> list[Bookmark]:
        """Get all bookmarks with a specific tag."""
        return [b for b in self.bookmarks if tag in b.tags]

    def search(self, query: str) -> list[Bookmark]:
        """Search bookmarks by annotation or message text."""
        q = query.lower()
        return [
            b for b in self.bookmarks
            if q in b.annotation.lower() or q in b.message.lower()
        ]

    @property
    def count(self) -> int:
        return len(self.bookmarks)

    def all_tags(self) -> set[str]:
        """Get all unique tags."""
        tags: set[str] = set()
        for b in self.bookmarks:
            tags.update(b.tags)
        return tags

    def save(self, path: str) -> None:
        """Save bookmarks to a JSON file."""
        data = {
            "source_file": self.source_file,
            "bookmarks": [b.to_dict() for b in self.bookmarks],
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    @classmethod
    def load(cls, path: str) -> BookmarkStore:
        """Load bookmarks from a JSON file."""
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            store = cls(source_file=data.get("source_file", ""))
            for bm_data in data.get("bookmarks", []):
                store.bookmarks.append(Bookmark.from_dict(bm_data))
            return store
        except (json.JSONDecodeError, IOError, OSError):
            return cls()

    def clear(self) -> None:
        """Remove all bookmarks."""
        self.bookmarks.clear()
