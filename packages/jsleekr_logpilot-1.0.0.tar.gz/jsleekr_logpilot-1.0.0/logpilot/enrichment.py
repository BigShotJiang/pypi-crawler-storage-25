"""Log entry enrichment and augmentation."""

from __future__ import annotations

import re
from typing import Any, Callable, Sequence

from logpilot.models import LogEntry, LogLevel


# Type for enrichment rules
EnrichmentFn = Callable[[LogEntry], dict[str, Any]]


class Enricher:
    """Enriches log entries with additional computed fields."""

    def __init__(self) -> None:
        self._rules: list[tuple[str, EnrichmentFn]] = []

    def add_rule(self, name: str, fn: EnrichmentFn) -> None:
        """Add an enrichment rule."""
        self._rules.append((name, fn))

    def enrich(self, entry: LogEntry) -> LogEntry:
        """Apply all enrichment rules to an entry."""
        new_extra = dict(entry.extra)
        for name, fn in self._rules:
            try:
                additions = fn(entry)
                new_extra.update(additions)
            except Exception:
                pass  # Don't let enrichment failures break the pipeline
        return LogEntry(
            raw=entry.raw, data=entry.data, timestamp=entry.timestamp,
            level=entry.level, message=entry.message, source=entry.source,
            line_number=entry.line_number, is_json=entry.is_json, extra=new_extra,
        )

    def enrich_all(self, entries: Sequence[LogEntry]) -> list[LogEntry]:
        """Enrich all entries."""
        return [self.enrich(e) for e in entries]


def classify_http_status(entry: LogEntry) -> dict[str, Any]:
    """Classify HTTP status codes into categories."""
    status = entry.get("statusCode") or entry.get("status") or entry.get("status_code")
    if status is None:
        return {}
    try:
        code = int(str(status))
    except (ValueError, TypeError):
        return {}

    if code < 200:
        category = "informational"
    elif code < 300:
        category = "success"
    elif code < 400:
        category = "redirect"
    elif code < 500:
        category = "client_error"
    else:
        category = "server_error"

    return {"http_category": category}


def extract_http_method(entry: LogEntry) -> dict[str, Any]:
    """Extract HTTP method from message if not in fields."""
    if entry.get("method"):
        return {}
    match = re.search(r'\b(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)\b', entry.message)
    if match:
        return {"_http_method": match.group(1)}
    return {}


def calculate_response_time_bucket(entry: LogEntry) -> dict[str, Any]:
    """Bucket response times into categories."""
    rt = entry.get("responseTime") or entry.get("response_time") or entry.get("duration_ms") or entry.get("duration")
    if rt is None:
        return {}
    try:
        ms = float(str(rt))
    except (ValueError, TypeError):
        return {}

    if ms < 100:
        bucket = "fast"
    elif ms < 500:
        bucket = "normal"
    elif ms < 2000:
        bucket = "slow"
    else:
        bucket = "very_slow"

    return {"response_time_bucket": bucket}


def tag_error_severity(entry: LogEntry) -> dict[str, Any]:
    """Tag errors with additional severity context."""
    if entry.level < LogLevel.ERROR:
        return {}

    message = entry.message.lower()
    if any(kw in message for kw in ["fatal", "crash", "panic", "oom", "out of memory"]):
        return {"error_severity": "critical"}
    if any(kw in message for kw in ["timeout", "connection", "refused"]):
        return {"error_severity": "infrastructure"}
    if any(kw in message for kw in ["auth", "permission", "forbidden", "unauthorized"]):
        return {"error_severity": "security"}
    if any(kw in message for kw in ["validation", "invalid", "malformed"]):
        return {"error_severity": "user_input"}
    return {"error_severity": "application"}


def create_default_enricher() -> Enricher:
    """Create an enricher with all default rules."""
    enricher = Enricher()
    enricher.add_rule("http_status", classify_http_status)
    enricher.add_rule("http_method", extract_http_method)
    enricher.add_rule("response_time", calculate_response_time_bucket)
    enricher.add_rule("error_severity", tag_error_severity)
    return enricher
