"""Field extraction, transformation, and projection utilities."""

from __future__ import annotations

import re
from typing import Any, Callable, Sequence

from logpilot.models import LogEntry


def extract_fields(entries: Sequence[LogEntry]) -> set[str]:
    """Extract all unique field names from entries."""
    fields: set[str] = set()
    for entry in entries:
        fields.update(entry.data.keys())
        fields.update(entry.extra.keys())
    return fields


def flatten_fields(data: dict[str, Any], prefix: str = "") -> dict[str, Any]:
    """Flatten nested dict into dot-notation keys.

    Example: {"a": {"b": 1}} -> {"a.b": 1}
    """
    result: dict[str, Any] = {}
    for key, value in data.items():
        full_key = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            result.update(flatten_fields(value, full_key))
        else:
            result[full_key] = value
    return result


def unflatten_fields(data: dict[str, Any]) -> dict[str, Any]:
    """Convert dot-notation keys back to nested dict.

    Example: {"a.b": 1} -> {"a": {"b": 1}}
    """
    result: dict[str, Any] = {}
    for key, value in data.items():
        parts = key.split(".")
        current = result
        for part in parts[:-1]:
            if part not in current:
                current[part] = {}
            current = current[part]
        current[parts[-1]] = value
    return result


def rename_field(entries: Sequence[LogEntry], old_name: str, new_name: str) -> list[LogEntry]:
    """Rename a field in all entries."""
    result: list[LogEntry] = []
    for entry in entries:
        new_extra = dict(entry.extra)
        if old_name in new_extra:
            new_extra[new_name] = new_extra.pop(old_name)
        new_data = dict(entry.data)
        if old_name in new_data:
            new_data[new_name] = new_data.pop(old_name)
        result.append(LogEntry(
            raw=entry.raw, data=new_data, timestamp=entry.timestamp,
            level=entry.level, message=entry.message, source=entry.source,
            line_number=entry.line_number, is_json=entry.is_json, extra=new_extra,
        ))
    return result


def add_computed_field(
    entries: Sequence[LogEntry],
    field_name: str,
    compute_fn: Callable[[LogEntry], Any],
) -> list[LogEntry]:
    """Add a computed field to all entries."""
    result: list[LogEntry] = []
    for entry in entries:
        new_extra = dict(entry.extra)
        new_extra[field_name] = compute_fn(entry)
        result.append(LogEntry(
            raw=entry.raw, data=entry.data, timestamp=entry.timestamp,
            level=entry.level, message=entry.message, source=entry.source,
            line_number=entry.line_number, is_json=entry.is_json, extra=new_extra,
        ))
    return result


def project_fields(
    entries: Sequence[LogEntry],
    fields: list[str],
) -> list[dict[str, Any]]:
    """Project entries to only specified fields.

    Returns a list of dicts with only the requested fields.
    """
    result: list[dict[str, Any]] = []
    for entry in entries:
        row: dict[str, Any] = {}
        for f in fields:
            if f == "timestamp":
                row[f] = entry.timestamp.isoformat() if entry.timestamp else None
            elif f == "level":
                row[f] = entry.level.name
            elif f == "message":
                row[f] = entry.message
            elif f == "source":
                row[f] = entry.source
            elif f == "line":
                row[f] = entry.line_number
            else:
                row[f] = entry.get(f)
        result.append(row)
    return result


def extract_regex(
    entries: Sequence[LogEntry],
    field: str,
    pattern: str,
    output_field: str,
) -> list[LogEntry]:
    """Extract values from a field using regex and store in a new field."""
    compiled = re.compile(pattern)
    result: list[LogEntry] = []
    for entry in entries:
        val = str(entry.get(field, entry.message))
        match = compiled.search(val)
        new_extra = dict(entry.extra)
        if match:
            groups = match.groups()
            new_extra[output_field] = groups[0] if len(groups) == 1 else list(groups)
        result.append(LogEntry(
            raw=entry.raw, data=entry.data, timestamp=entry.timestamp,
            level=entry.level, message=entry.message, source=entry.source,
            line_number=entry.line_number, is_json=entry.is_json, extra=new_extra,
        ))
    return result


def mask_field(
    entries: Sequence[LogEntry],
    field_name: str,
    mask: str = "***",
) -> list[LogEntry]:
    """Mask sensitive field values."""
    result: list[LogEntry] = []
    for entry in entries:
        new_extra = dict(entry.extra)
        if field_name in new_extra:
            new_extra[field_name] = mask
        new_data = dict(entry.data)
        if field_name in new_data:
            new_data[field_name] = mask
        result.append(LogEntry(
            raw=entry.raw, data=new_data, timestamp=entry.timestamp,
            level=entry.level, message=entry.message, source=entry.source,
            line_number=entry.line_number, is_json=entry.is_json, extra=new_extra,
        ))
    return result
