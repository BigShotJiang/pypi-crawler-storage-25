"""Output formatters for log entries."""

from __future__ import annotations

import json
from typing import Any, Sequence

from logpilot.models import LogEntry, LogLevel, LogStats


# ANSI color codes
class Colors:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    GRAY = "\033[90m"
    BG_RED = "\033[41m"
    BG_YELLOW = "\033[43m"


LEVEL_COLORS: dict[LogLevel, str] = {
    LogLevel.TRACE: Colors.GRAY,
    LogLevel.DEBUG: Colors.CYAN,
    LogLevel.INFO: Colors.GREEN,
    LogLevel.WARN: Colors.YELLOW,
    LogLevel.ERROR: Colors.RED,
    LogLevel.FATAL: Colors.BG_RED + Colors.WHITE,
}

LEVEL_ICONS: dict[LogLevel, str] = {
    LogLevel.TRACE: ".",
    LogLevel.DEBUG: "*",
    LogLevel.INFO: "i",
    LogLevel.WARN: "!",
    LogLevel.ERROR: "x",
    LogLevel.FATAL: "X",
}


def colorize(text: str, color: str) -> str:
    """Wrap text with ANSI color codes."""
    return f"{color}{text}{Colors.RESET}"


def format_level(level: LogLevel, use_color: bool = True) -> str:
    """Format a log level with color and icon."""
    icon = LEVEL_ICONS.get(level, "?")
    label = f"[{icon}] {level.name:5s}"
    if use_color:
        color = LEVEL_COLORS.get(level, Colors.WHITE)
        return colorize(label, color)
    return label


def format_timestamp(entry: LogEntry, use_color: bool = True) -> str:
    """Format the timestamp portion of a log entry."""
    if entry.timestamp:
        ts = entry.timestamp.strftime("%H:%M:%S.%f")[:-3]
        if use_color:
            return colorize(ts, Colors.DIM)
        return ts
    return ""


def format_compact(entry: LogEntry, use_color: bool = True) -> str:
    """Format a log entry in compact single-line format.

    Format: HH:MM:SS.mmm [L] LEVEL message  key=value key=value
    """
    parts: list[str] = []

    # Timestamp
    ts = format_timestamp(entry, use_color)
    if ts:
        parts.append(ts)

    # Level
    parts.append(format_level(entry.level, use_color))

    # Message
    if entry.message:
        parts.append(entry.message)

    # Extra fields as key=value
    if entry.extra:
        extras = _format_extras(entry.extra, use_color)
        if extras:
            parts.append(extras)

    return " ".join(parts)


def format_pretty(entry: LogEntry, use_color: bool = True) -> str:
    """Format a log entry in pretty multi-line format with indented fields."""
    lines: list[str] = []

    # Header line
    header_parts: list[str] = []
    ts = format_timestamp(entry, use_color)
    if ts:
        header_parts.append(ts)
    header_parts.append(format_level(entry.level, use_color))
    if entry.source:
        src = f"({entry.source})"
        if use_color:
            src = colorize(src, Colors.MAGENTA)
        header_parts.append(src)
    header_parts.append(entry.message)
    lines.append(" ".join(header_parts))

    # Extra fields indented
    if entry.extra:
        for key, value in entry.extra.items():
            formatted_value = _format_value(value)
            if use_color:
                key_str = colorize(f"  {key}:", Colors.BLUE)
            else:
                key_str = f"  {key}:"
            lines.append(f"{key_str} {formatted_value}")

    return "\n".join(lines)


def format_json(entry: LogEntry) -> str:
    """Format a log entry as JSON."""
    return entry.to_json()


def format_json_pretty(entry: LogEntry) -> str:
    """Format a log entry as pretty-printed JSON."""
    return json.dumps(entry.to_dict(), indent=2, default=str)


def format_raw(entry: LogEntry) -> str:
    """Return the original raw log line."""
    return entry.raw.rstrip("\n")


def format_table_header(columns: list[str], widths: list[int], use_color: bool = True) -> str:
    """Format a table header row."""
    cells = []
    for col, width in zip(columns, widths):
        cell = col.ljust(width)
        if use_color:
            cell = colorize(cell, Colors.BOLD)
        cells.append(cell)
    header = " | ".join(cells)
    separator = "-+-".join("-" * w for w in widths)
    return f"{header}\n{separator}"


def format_table_row(entry: LogEntry, columns: list[str], widths: list[int]) -> str:
    """Format a log entry as a table row."""
    cells = []
    for col, width in zip(columns, widths):
        value = _get_column_value(entry, col)
        cells.append(str(value)[:width].ljust(width))
    return " | ".join(cells)


def format_stats(stats: LogStats, use_color: bool = True) -> str:
    """Format log statistics for display."""
    lines: list[str] = []

    title = "Log Statistics"
    if use_color:
        title = colorize(title, Colors.BOLD)
    lines.append(title)
    lines.append("=" * 40)

    lines.append(f"Total entries: {stats.total}")
    lines.append(f"Parse errors: {stats.parse_errors}")

    if stats.duration_seconds is not None:
        lines.append(f"Time span: {_format_duration(stats.duration_seconds)}")

    if stats.first_timestamp:
        lines.append(f"First entry: {stats.first_timestamp.isoformat()}")
    if stats.last_timestamp:
        lines.append(f"Last entry: {stats.last_timestamp.isoformat()}")

    lines.append("")
    lines.append("By Level:")
    for level_name in ["TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL"]:
        count = stats.by_level.get(level_name, 0)
        if count > 0:
            pct = (count / stats.total * 100) if stats.total > 0 else 0
            bar = _make_bar(pct)
            level_str = f"  {level_name:5s}: {count:>6d} ({pct:5.1f}%) {bar}"
            if use_color:
                color = LEVEL_COLORS.get(LogLevel[level_name], Colors.WHITE)
                level_str = colorize(level_str, color)
            lines.append(level_str)

    error_rate = stats.error_rate
    lines.append("")
    err_line = f"Error rate: {error_rate:.1f}%"
    if use_color and error_rate > 10:
        err_line = colorize(err_line, Colors.RED)
    lines.append(err_line)

    if stats.by_source:
        lines.append("")
        lines.append("Top Sources:")
        sorted_sources = sorted(stats.by_source.items(), key=lambda x: x[1], reverse=True)
        for source, count in sorted_sources[:10]:
            lines.append(f"  {source}: {count}")

    if stats.unique_fields:
        lines.append("")
        lines.append(f"Unique fields ({len(stats.unique_fields)}):")
        sorted_fields = sorted(stats.unique_fields)
        lines.append(f"  {', '.join(sorted_fields[:20])}")
        if len(sorted_fields) > 20:
            lines.append(f"  ... and {len(sorted_fields) - 20} more")

    return "\n".join(lines)


def _format_extras(extra: dict[str, Any], use_color: bool = True) -> str:
    """Format extra fields as key=value pairs."""
    parts: list[str] = []
    for key, value in extra.items():
        formatted = _format_value(value)
        if use_color:
            parts.append(f"{colorize(key, Colors.BLUE)}={formatted}")
        else:
            parts.append(f"{key}={formatted}")
    return " ".join(parts)


def _format_value(value: Any) -> str:
    """Format a single value for display."""
    if isinstance(value, str):
        if " " in value or "=" in value:
            return f'"{value}"'
        return value
    if isinstance(value, dict):
        return json.dumps(value, default=str)
    if isinstance(value, list):
        return json.dumps(value, default=str)
    return str(value)


def _format_duration(seconds: float) -> str:
    """Format duration in human-readable form."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    if seconds < 3600:
        minutes = seconds / 60
        return f"{minutes:.1f}m"
    hours = seconds / 3600
    return f"{hours:.1f}h"


def _make_bar(percentage: float, width: int = 20) -> str:
    """Create a simple bar chart."""
    filled = int(percentage / 100 * width)
    return "█" * filled + "░" * (width - filled)


def _get_column_value(entry: LogEntry, column: str) -> str:
    """Get a column value from a log entry."""
    col = column.lower()
    if col == "time" or col == "timestamp":
        if entry.timestamp:
            return entry.timestamp.strftime("%H:%M:%S.%f")[:-3]
        return ""
    if col == "level":
        return entry.level.name
    if col == "message" or col == "msg":
        return entry.message
    if col == "source" or col == "logger":
        return entry.source
    # Try extra fields
    val = entry.get(column)
    if val is not None:
        return str(val)
    return ""


class OutputFormatter:
    """Configurable output formatter."""

    def __init__(
        self,
        style: str = "compact",
        use_color: bool = True,
        fields: list[str] | None = None,
        exclude_fields: list[str] | None = None,
    ):
        self.style = style
        self.use_color = use_color
        self.fields = fields
        self.exclude_fields = exclude_fields or []

    def format(self, entry: LogEntry) -> str:
        """Format a single log entry."""
        # Apply field selection
        if self.fields:
            entry = self._select_fields(entry)
        if self.exclude_fields:
            entry = self._exclude_entry_fields(entry)

        if self.style == "compact":
            return format_compact(entry, self.use_color)
        if self.style == "pretty":
            return format_pretty(entry, self.use_color)
        if self.style == "json":
            return format_json(entry)
        if self.style == "json-pretty":
            return format_json_pretty(entry)
        if self.style == "raw":
            return format_raw(entry)
        if self.style == "table":
            return format_compact(entry, self.use_color)
        return format_compact(entry, self.use_color)

    def format_all(self, entries: Sequence[LogEntry]) -> str:
        """Format multiple log entries."""
        return "\n".join(self.format(e) for e in entries)

    def _select_fields(self, entry: LogEntry) -> LogEntry:
        """Create a new entry with only selected fields in extra."""
        if not self.fields:
            return entry
        new_extra: dict[str, Any] = {}
        for field in self.fields:
            val = entry.get(field)
            if val is not None:
                new_extra[field] = val
        return LogEntry(
            raw=entry.raw,
            data=entry.data,
            timestamp=entry.timestamp,
            level=entry.level,
            message=entry.message,
            source=entry.source,
            line_number=entry.line_number,
            is_json=entry.is_json,
            extra=new_extra,
        )

    def _exclude_entry_fields(self, entry: LogEntry) -> LogEntry:
        """Create a new entry without excluded fields."""
        new_extra = {
            k: v for k, v in entry.extra.items()
            if k not in self.exclude_fields
        }
        return LogEntry(
            raw=entry.raw,
            data=entry.data,
            timestamp=entry.timestamp,
            level=entry.level,
            message=entry.message,
            source=entry.source,
            line_number=entry.line_number,
            is_json=entry.is_json,
            extra=new_extra,
        )
