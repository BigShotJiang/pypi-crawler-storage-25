"""Data models for logpilot."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class LogLevel(Enum):
    """Standard log levels with numeric severity."""
    TRACE = 10
    DEBUG = 20
    INFO = 30
    WARN = 40
    ERROR = 50
    FATAL = 60

    @classmethod
    def from_string(cls, value: str) -> LogLevel:
        """Parse a log level string (case-insensitive).

        Supports common aliases: warning->WARN, critical/crit->FATAL,
        verbose->DEBUG, notice->INFO.
        """
        normalized = value.upper().strip()
        aliases: dict[str, str] = {
            "WARNING": "WARN",
            "CRITICAL": "FATAL",
            "CRIT": "FATAL",
            "VERBOSE": "DEBUG",
            "NOTICE": "INFO",
            "INFORMATION": "INFO",
            "ERR": "ERROR",
            "FTL": "FATAL",
            "WRN": "WARN",
            "INF": "INFO",
            "DBG": "DEBUG",
            "TRC": "TRACE",
        }
        resolved = aliases.get(normalized, normalized)
        try:
            return cls[resolved]
        except KeyError:
            return cls.INFO  # default fallback

    def __ge__(self, other: object) -> bool:
        if not isinstance(other, LogLevel):
            return NotImplemented
        return self.value >= other.value

    def __gt__(self, other: object) -> bool:
        if not isinstance(other, LogLevel):
            return NotImplemented
        return self.value > other.value

    def __le__(self, other: object) -> bool:
        if not isinstance(other, LogLevel):
            return NotImplemented
        return self.value <= other.value

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, LogLevel):
            return NotImplemented
        return self.value < other.value


@dataclass
class LogEntry:
    """A single parsed log entry."""
    raw: str
    data: dict[str, Any] = field(default_factory=dict)
    timestamp: datetime | None = None
    level: LogLevel = LogLevel.INFO
    message: str = ""
    source: str = ""
    line_number: int = 0
    is_json: bool = False
    extra: dict[str, Any] = field(default_factory=dict)

    def get(self, key: str, default: Any = None) -> Any:
        """Get a value from the log entry data using dot notation.

        Example: entry.get("request.method") returns data["request"]["method"]
        """
        parts = key.split(".")
        current: Any = self.data
        for part in parts:
            if isinstance(current, dict):
                current = current.get(part)
                if current is None:
                    return default
            else:
                return default
        return current

    def matches_level(self, min_level: LogLevel) -> bool:
        """Check if this entry meets the minimum log level."""
        return self.level >= min_level

    def to_dict(self) -> dict[str, Any]:
        """Convert back to a dictionary."""
        result: dict[str, Any] = {
            "message": self.message,
            "level": self.level.name,
        }
        if self.timestamp:
            result["timestamp"] = self.timestamp.isoformat()
        if self.source:
            result["source"] = self.source
        result.update(self.extra)
        return result

    def to_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), default=str)


@dataclass
class LogStats:
    """Aggregate statistics for a collection of log entries."""
    total: int = 0
    by_level: dict[str, int] = field(default_factory=dict)
    by_source: dict[str, int] = field(default_factory=dict)
    first_timestamp: datetime | None = None
    last_timestamp: datetime | None = None
    parse_errors: int = 0
    unique_fields: set[str] = field(default_factory=set)

    def record(self, entry: LogEntry) -> None:
        """Update stats with a new entry."""
        self.total += 1
        level_name = entry.level.name
        self.by_level[level_name] = self.by_level.get(level_name, 0) + 1
        if entry.source:
            self.by_source[entry.source] = self.by_source.get(entry.source, 0) + 1
        if entry.timestamp:
            if self.first_timestamp is None or entry.timestamp < self.first_timestamp:
                self.first_timestamp = entry.timestamp
            if self.last_timestamp is None or entry.timestamp > self.last_timestamp:
                self.last_timestamp = entry.timestamp
        for key in entry.data.keys():
            self.unique_fields.add(key)

    @property
    def duration_seconds(self) -> float | None:
        """Total time span of the log entries."""
        if self.first_timestamp and self.last_timestamp:
            return (self.last_timestamp - self.first_timestamp).total_seconds()
        return None

    @property
    def error_rate(self) -> float:
        """Percentage of ERROR and FATAL entries."""
        if self.total == 0:
            return 0.0
        errors = self.by_level.get("ERROR", 0) + self.by_level.get("FATAL", 0)
        return (errors / self.total) * 100.0


@dataclass
class FilterConfig:
    """Configuration for filtering log entries."""
    min_level: LogLevel | None = None
    search: str | None = None
    fields: list[str] = field(default_factory=list)
    exclude_fields: list[str] = field(default_factory=list)
    source: str | None = None
    since: datetime | None = None
    until: datetime | None = None
    jq_expr: str | None = None
    grep: str | None = None
    invert: bool = False

    def matches(self, entry: LogEntry) -> bool:
        """Check if an entry passes all filters.

        When invert=True, entries that would normally pass are rejected
        and entries that would normally fail are accepted.
        """
        passed = True
        if self.min_level and not entry.matches_level(self.min_level):
            passed = False
        elif self.source and entry.source != self.source:
            passed = False
        elif self.since and entry.timestamp and entry.timestamp < self.since:
            passed = False
        elif self.until and entry.timestamp and entry.timestamp > self.until:
            passed = False
        elif self.search and self.search.lower() not in entry.message.lower():
            passed = False
        elif self.grep and self.grep.lower() not in entry.raw.lower():
            passed = False
        if self.invert:
            return not passed
        return passed
