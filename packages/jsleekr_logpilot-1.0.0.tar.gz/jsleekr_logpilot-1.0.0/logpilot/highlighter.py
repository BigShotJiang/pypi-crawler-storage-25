"""Text highlighting for search matches and patterns."""

from __future__ import annotations

import re
from typing import Sequence

from logpilot.formatter import Colors


class Highlighter:
    """Highlight matching text in log output."""

    def __init__(
        self,
        patterns: list[str] | None = None,
        use_color: bool = True,
        highlight_color: str = Colors.BOLD + Colors.YELLOW,
    ):
        self.patterns = patterns or []
        self.use_color = use_color
        self.highlight_color = highlight_color
        self._compiled: list[re.Pattern[str]] = []
        for pattern in self.patterns:
            try:
                self._compiled.append(re.compile(re.escape(pattern), re.IGNORECASE))
            except re.error:
                pass

    def highlight(self, text: str) -> str:
        """Apply highlighting to text."""
        if not self.use_color or not self._compiled:
            return text

        result = text
        for regex in self._compiled:
            result = regex.sub(
                lambda m: f"{self.highlight_color}{m.group()}{Colors.RESET}",
                result,
            )
        return result

    def highlight_regex(self, text: str, pattern: str) -> str:
        """Highlight text matching a regex pattern."""
        if not self.use_color:
            return text
        try:
            compiled = re.compile(pattern, re.IGNORECASE)
            return compiled.sub(
                lambda m: f"{self.highlight_color}{m.group()}{Colors.RESET}",
                text,
            )
        except re.error:
            return text

    def has_match(self, text: str) -> bool:
        """Check if text contains any highlighted pattern."""
        for regex in self._compiled:
            if regex.search(text):
                return True
        return False

    def count_matches(self, text: str) -> int:
        """Count total matches across all patterns."""
        total = 0
        for regex in self._compiled:
            total += len(regex.findall(text))
        return total


def strip_ansi(text: str) -> str:
    """Remove ANSI escape codes from text."""
    ansi_pattern = re.compile(r'\033\[[0-9;]*m')
    return ansi_pattern.sub('', text)


def truncate(text: str, max_width: int = 80, suffix: str = "...") -> str:
    """Truncate text to max width, preserving words."""
    if len(text) <= max_width:
        return text
    truncated = text[:max_width - len(suffix)]
    # Try to break at word boundary
    last_space = truncated.rfind(' ')
    if last_space > max_width // 2:
        truncated = truncated[:last_space]
    return truncated + suffix


def wrap_text(text: str, max_width: int = 80, indent: int = 0) -> list[str]:
    """Wrap text to fit within max_width."""
    if len(text) <= max_width:
        return [text]

    lines: list[str] = []
    current = ""
    prefix = " " * indent

    for word in text.split():
        if not current:
            current = word
        elif len(current) + 1 + len(word) <= max_width:
            current += " " + word
        else:
            lines.append(current)
            current = prefix + word

    if current:
        lines.append(current)

    return lines
