"""Log analysis and pattern detection."""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Sequence

from logpilot.models import LogEntry, LogLevel, LogStats


@dataclass
class ErrorCluster:
    """A cluster of similar error messages."""
    pattern: str
    count: int
    samples: list[LogEntry] = field(default_factory=list)
    first_seen: datetime | None = None
    last_seen: datetime | None = None


@dataclass
class TimeBucket:
    """Log entries grouped by time interval."""
    start: datetime
    end: datetime
    entries: list[LogEntry] = field(default_factory=list)
    count: int = 0
    error_count: int = 0

    @property
    def error_rate(self) -> float:
        if self.count == 0:
            return 0.0
        return (self.error_count / self.count) * 100.0


@dataclass
class AnomalyReport:
    """Report of detected anomalies in log data."""
    error_spikes: list[TimeBucket] = field(default_factory=list)
    high_frequency_errors: list[ErrorCluster] = field(default_factory=list)
    slow_gaps: list[tuple[LogEntry, LogEntry, float]] = field(default_factory=list)
    summary: str = ""


def compute_stats(entries: Sequence[LogEntry]) -> LogStats:
    """Compute aggregate statistics for log entries."""
    stats = LogStats()
    for entry in entries:
        if entry.is_json:
            stats.record(entry)
        else:
            stats.total += 1
            stats.parse_errors += 1
    return stats


def group_by_level(entries: Sequence[LogEntry]) -> dict[LogLevel, list[LogEntry]]:
    """Group entries by log level."""
    result: dict[LogLevel, list[LogEntry]] = {}
    for entry in entries:
        if entry.level not in result:
            result[entry.level] = []
        result[entry.level].append(entry)
    return result


def group_by_source(entries: Sequence[LogEntry]) -> dict[str, list[LogEntry]]:
    """Group entries by source/logger."""
    result: dict[str, list[LogEntry]] = {}
    for entry in entries:
        source = entry.source or "(unknown)"
        if source not in result:
            result[source] = []
        result[source].append(entry)
    return result


def group_by_field(entries: Sequence[LogEntry], field_name: str) -> dict[str, list[LogEntry]]:
    """Group entries by an arbitrary field value."""
    result: dict[str, list[LogEntry]] = {}
    for entry in entries:
        value = str(entry.get(field_name, "(none)"))
        if value not in result:
            result[value] = []
        result[value].append(entry)
    return result


def cluster_errors(
    entries: Sequence[LogEntry],
    max_clusters: int = 20,
    similarity_threshold: float = 0.6,
) -> list[ErrorCluster]:
    """Cluster similar error messages together.

    Uses simple token-based similarity to group similar error messages.
    """
    error_entries = [e for e in entries if e.level >= LogLevel.ERROR]
    if not error_entries:
        return []

    clusters: list[ErrorCluster] = []

    for entry in error_entries:
        normalized = _normalize_message(entry.message)
        matched = False

        for cluster in clusters:
            if _similarity(normalized, cluster.pattern) >= similarity_threshold:
                cluster.count += 1
                if len(cluster.samples) < 3:
                    cluster.samples.append(entry)
                if entry.timestamp:
                    if cluster.first_seen is None or entry.timestamp < cluster.first_seen:
                        cluster.first_seen = entry.timestamp
                    if cluster.last_seen is None or entry.timestamp > cluster.last_seen:
                        cluster.last_seen = entry.timestamp
                matched = True
                break

        if not matched and len(clusters) < max_clusters:
            cluster = ErrorCluster(
                pattern=normalized,
                count=1,
                samples=[entry],
                first_seen=entry.timestamp,
                last_seen=entry.timestamp,
            )
            clusters.append(cluster)

    clusters.sort(key=lambda c: c.count, reverse=True)
    return clusters


def time_histogram(
    entries: Sequence[LogEntry],
    bucket_seconds: int = 60,
) -> list[TimeBucket]:
    """Create a time-based histogram of log entries."""
    timed = [e for e in entries if e.timestamp is not None]
    if not timed:
        return []

    timed_sorted = sorted(timed, key=lambda e: e.timestamp)  # type: ignore
    start = timed_sorted[0].timestamp
    end = timed_sorted[-1].timestamp

    if start is None or end is None:
        return []

    buckets: list[TimeBucket] = []
    current_start = start
    delta = timedelta(seconds=bucket_seconds)

    while current_start <= end:
        current_end = current_start + delta
        bucket = TimeBucket(start=current_start, end=current_end)
        buckets.append(bucket)
        current_start = current_end

    # Assign entries to buckets
    bucket_idx = 0
    for entry in timed_sorted:
        ts = entry.timestamp
        if ts is None:
            continue
        while bucket_idx < len(buckets) - 1 and ts >= buckets[bucket_idx].end:
            bucket_idx += 1
        buckets[bucket_idx].entries.append(entry)
        buckets[bucket_idx].count += 1
        if entry.level >= LogLevel.ERROR:
            buckets[bucket_idx].error_count += 1

    return buckets


def detect_anomalies(
    entries: Sequence[LogEntry],
    error_spike_threshold: float = 3.0,
    gap_threshold_seconds: float = 30.0,
) -> AnomalyReport:
    """Detect anomalies in log data.

    Checks for:
    - Error rate spikes (compared to average)
    - High-frequency repeating errors
    - Unusual time gaps between entries
    """
    report = AnomalyReport()

    # Error spikes via histogram
    buckets = time_histogram(entries, bucket_seconds=60)
    if buckets:
        avg_errors = sum(b.error_count for b in buckets) / len(buckets) if buckets else 0
        for bucket in buckets:
            if avg_errors > 0 and bucket.error_count > avg_errors * error_spike_threshold:
                report.error_spikes.append(bucket)

    # High frequency errors
    error_clusters = cluster_errors(entries)
    report.high_frequency_errors = [c for c in error_clusters if c.count >= 5]

    # Time gaps
    timed = [e for e in entries if e.timestamp is not None]
    timed_sorted = sorted(timed, key=lambda e: e.timestamp)  # type: ignore
    for i in range(1, len(timed_sorted)):
        prev = timed_sorted[i - 1]
        curr = timed_sorted[i]
        if prev.timestamp and curr.timestamp:
            gap = (curr.timestamp - prev.timestamp).total_seconds()
            if gap > gap_threshold_seconds:
                report.slow_gaps.append((prev, curr, gap))

    # Summary
    parts: list[str] = []
    if report.error_spikes:
        parts.append(f"{len(report.error_spikes)} error spike(s) detected")
    if report.high_frequency_errors:
        parts.append(f"{len(report.high_frequency_errors)} recurring error pattern(s)")
    if report.slow_gaps:
        parts.append(f"{len(report.slow_gaps)} unusual gap(s) in log timeline")
    report.summary = "; ".join(parts) if parts else "No anomalies detected"

    return report


def top_messages(entries: Sequence[LogEntry], n: int = 10) -> list[tuple[str, int]]:
    """Find the most frequent log messages."""
    counter: Counter[str] = Counter()
    for entry in entries:
        if entry.message:
            counter[entry.message] += 1
    return counter.most_common(n)


def field_value_distribution(
    entries: Sequence[LogEntry],
    field_name: str,
    top_n: int = 10,
) -> list[tuple[str, int]]:
    """Get the distribution of values for a specific field."""
    counter: Counter[str] = Counter()
    for entry in entries:
        val = entry.get(field_name)
        if val is not None:
            counter[str(val)] += 1
    return counter.most_common(top_n)


def correlate_fields(
    entries: Sequence[LogEntry],
    field_a: str,
    field_b: str,
) -> dict[str, Counter[str]]:
    """Find correlations between two fields."""
    result: dict[str, Counter[str]] = {}
    for entry in entries:
        val_a = entry.get(field_a)
        val_b = entry.get(field_b)
        if val_a is not None and val_b is not None:
            key = str(val_a)
            if key not in result:
                result[key] = Counter()
            result[key][str(val_b)] += 1
    return result


def _normalize_message(message: str) -> str:
    """Normalize an error message for clustering.

    Replaces numbers, UUIDs, IPs, etc. with placeholders.
    """
    # Replace UUIDs
    result = re.sub(
        r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',
        '<UUID>',
        message,
        flags=re.IGNORECASE,
    )
    # Replace IP addresses
    result = re.sub(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', '<IP>', result)
    # Replace hex strings
    result = re.sub(r'0x[0-9a-fA-F]+', '<HEX>', result)
    # Replace numbers
    result = re.sub(r'\b\d+\b', '<N>', result)
    # Replace quoted strings
    result = re.sub(r'"[^"]*"', '<STR>', result)
    return result


def _similarity(a: str, b: str) -> float:
    """Simple token-based Jaccard similarity."""
    tokens_a = set(a.lower().split())
    tokens_b = set(b.lower().split())
    if not tokens_a or not tokens_b:
        return 0.0
    intersection = tokens_a & tokens_b
    union = tokens_a | tokens_b
    return len(intersection) / len(union)
