"""JSON log parser with multi-format support."""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any, Iterator, TextIO

from logpilot.models import LogEntry, LogLevel


# Common timestamp field names
TIMESTAMP_FIELDS = [
    "timestamp", "time", "ts", "@timestamp", "datetime", "date",
    "created", "logged_at", "event_time", "t",
]

# Common level field names
LEVEL_FIELDS = [
    "level", "severity", "log_level", "loglevel", "lvl", "log.level",
    "priority", "sev",
]

# Common message field names
MESSAGE_FIELDS = [
    "message", "msg", "text", "body", "log", "description", "content",
    "event", "summary",
]

# Common source/logger field names
SOURCE_FIELDS = [
    "source", "logger", "logger_name", "module", "component",
    "service", "app", "application", "name", "caller",
]

# ISO 8601 and common timestamp patterns
TIMESTAMP_PATTERNS = [
    # ISO 8601 with timezone
    r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?",
    # Standard datetime
    r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(?:\.\d+)?",
    # Unix timestamp (seconds)
    r"^\d{10}(?:\.\d+)?$",
    # Unix timestamp (milliseconds)
    r"^\d{13}$",
]


def _extract_field(data: dict[str, Any], candidates: list[str]) -> Any | None:
    """Try to extract a field from data using a list of candidate keys."""
    for key in candidates:
        if "." in key:
            parts = key.split(".")
            current: Any = data
            for part in parts:
                if isinstance(current, dict):
                    current = current.get(part)
                else:
                    current = None
                    break
            if current is not None:
                return current
        elif key in data:
            return data[key]
    return None


def _parse_timestamp(value: Any) -> datetime | None:
    """Parse a timestamp from various formats."""
    if value is None:
        return None

    if isinstance(value, (int, float)):
        try:
            # Unix timestamp in seconds
            if value > 1e12:
                # Milliseconds
                return datetime.fromtimestamp(value / 1000, tz=timezone.utc)
            return datetime.fromtimestamp(value, tz=timezone.utc)
        except (ValueError, OSError, OverflowError):
            return None

    if not isinstance(value, str):
        return None

    value = value.strip()

    # Try Unix timestamp string
    try:
        num = float(value)
        if num > 1e12:
            return datetime.fromtimestamp(num / 1000, tz=timezone.utc)
        if num > 1e9:
            return datetime.fromtimestamp(num, tz=timezone.utc)
    except ValueError:
        pass

    # Try ISO 8601 formats
    formats = [
        "%Y-%m-%dT%H:%M:%S.%fZ",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%S.%f%z",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%d %H:%M:%S.%f",
        "%Y-%m-%d %H:%M:%S",
        "%d/%b/%Y:%H:%M:%S %z",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue

    return None


def parse_line(line: str, line_number: int = 0) -> LogEntry:
    """Parse a single log line into a LogEntry.

    Handles:
    - Pure JSON lines
    - JSON with prefix text (e.g., timestamp + JSON)
    - Plain text lines (stored as-is)
    """
    stripped = line.strip()
    if not stripped:
        return LogEntry(
            raw=line,
            line_number=line_number,
            message="",
            is_json=False,
        )

    # Try pure JSON first
    data = _try_parse_json(stripped)

    # Try JSON embedded in text (e.g., "2024-01-01 INFO {json...}")
    if data is None:
        json_match = re.search(r'\{.*\}', stripped)
        if json_match:
            data = _try_parse_json(json_match.group())

    if data is None:
        # Plain text log
        return LogEntry(
            raw=line,
            line_number=line_number,
            message=stripped,
            is_json=False,
        )

    # Extract fields
    timestamp_raw = _extract_field(data, TIMESTAMP_FIELDS)
    timestamp = _parse_timestamp(timestamp_raw)

    level_raw = _extract_field(data, LEVEL_FIELDS)
    level = LogLevel.from_string(str(level_raw)) if level_raw else LogLevel.INFO

    message_raw = _extract_field(data, MESSAGE_FIELDS)
    message = str(message_raw) if message_raw is not None else ""

    source_raw = _extract_field(data, SOURCE_FIELDS)
    source = str(source_raw) if source_raw is not None else ""

    # Collect extra fields (not standard ones)
    known_keys = set()
    for field_list in [TIMESTAMP_FIELDS, LEVEL_FIELDS, MESSAGE_FIELDS, SOURCE_FIELDS]:
        for k in field_list:
            if "." not in k:
                known_keys.add(k)
    extra = {k: v for k, v in data.items() if k not in known_keys}

    return LogEntry(
        raw=line,
        data=data,
        timestamp=timestamp,
        level=level,
        message=message,
        source=source,
        line_number=line_number,
        is_json=True,
        extra=extra,
    )


def _try_parse_json(text: str) -> dict[str, Any] | None:
    """Attempt to parse a string as JSON, return None on failure."""
    try:
        result = json.loads(text)
        if isinstance(result, dict):
            return result
        return None
    except (json.JSONDecodeError, ValueError):
        return None


def parse_stream(stream: TextIO, max_lines: int = 0) -> Iterator[LogEntry]:
    """Parse a stream of log lines.

    Args:
        stream: Text stream to read from.
        max_lines: Maximum number of lines to parse (0 = unlimited).

    Yields:
        LogEntry for each line.
    """
    for i, line in enumerate(stream, start=1):
        if max_lines > 0 and i > max_lines:
            break
        yield parse_line(line, line_number=i)


def parse_file(path: str, max_lines: int = 0) -> list[LogEntry]:
    """Parse a log file into a list of LogEntry objects."""
    entries: list[LogEntry] = []
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for entry in parse_stream(f, max_lines=max_lines):
            entries.append(entry)
    return entries


def parse_text(text: str) -> list[LogEntry]:
    """Parse a multi-line string of logs."""
    entries: list[LogEntry] = []
    for i, line in enumerate(text.splitlines(), start=1):
        entries.append(parse_line(line, line_number=i))
    return entries
