"""Log filtering engine with support for complex queries."""

from __future__ import annotations

import re
from datetime import datetime
from typing import Iterator, Sequence

from logpilot.models import FilterConfig, LogEntry, LogLevel


def apply_filter(entries: Sequence[LogEntry], config: FilterConfig) -> list[LogEntry]:
    """Apply filter configuration to a sequence of log entries."""
    return list(filter_stream(iter(entries), config))


def filter_stream(entries: Iterator[LogEntry], config: FilterConfig) -> Iterator[LogEntry]:
    """Apply filter to a stream of log entries (lazy)."""
    for entry in entries:
        if config.matches(entry):
            yield entry


def filter_by_level(entries: Sequence[LogEntry], min_level: LogLevel) -> list[LogEntry]:
    """Filter entries by minimum log level."""
    return [e for e in entries if e.matches_level(min_level)]


def filter_by_time_range(
    entries: Sequence[LogEntry],
    since: datetime | None = None,
    until: datetime | None = None,
) -> list[LogEntry]:
    """Filter entries within a time range."""
    result: list[LogEntry] = []
    for entry in entries:
        if entry.timestamp is None:
            continue
        if since and entry.timestamp < since:
            continue
        if until and entry.timestamp > until:
            continue
        result.append(entry)
    return result


def filter_by_source(entries: Sequence[LogEntry], source: str) -> list[LogEntry]:
    """Filter entries by source/logger name."""
    return [e for e in entries if e.source == source]


def filter_by_search(entries: Sequence[LogEntry], query: str) -> list[LogEntry]:
    """Filter entries whose message contains the query (case-insensitive)."""
    q = query.lower()
    return [e for e in entries if q in e.message.lower()]


def filter_by_regex(entries: Sequence[LogEntry], pattern: str) -> list[LogEntry]:
    """Filter entries whose raw text matches a regex pattern."""
    compiled = re.compile(pattern, re.IGNORECASE)
    return [e for e in entries if compiled.search(e.raw)]


def filter_by_field_exists(entries: Sequence[LogEntry], field_name: str) -> list[LogEntry]:
    """Filter entries that have a specific field."""
    return [e for e in entries if e.get(field_name) is not None]


def filter_by_field_value(
    entries: Sequence[LogEntry],
    field_name: str,
    value: str,
) -> list[LogEntry]:
    """Filter entries where a field equals a specific value."""
    return [e for e in entries if str(e.get(field_name, "")) == value]


def exclude_by_field(entries: Sequence[LogEntry], field_name: str) -> list[LogEntry]:
    """Exclude entries that have a specific field."""
    return [e for e in entries if e.get(field_name) is None]


def unique_by_field(entries: Sequence[LogEntry], field_name: str) -> list[LogEntry]:
    """Deduplicate entries by a field value, keeping the first occurrence."""
    seen: set[str] = set()
    result: list[LogEntry] = []
    for entry in entries:
        val = str(entry.get(field_name, ""))
        if val not in seen:
            seen.add(val)
            result.append(entry)
    return result


def sample_entries(entries: Sequence[LogEntry], count: int) -> list[LogEntry]:
    """Take every Nth entry to get approximately `count` entries."""
    if len(entries) <= count or count <= 0:
        return list(entries)
    step = max(1, len(entries) // count)
    return [entries[i] for i in range(0, len(entries), step)][:count]


def tail_entries(entries: Sequence[LogEntry], count: int) -> list[LogEntry]:
    """Get the last N entries."""
    if count <= 0:
        return []
    return list(entries[-count:])


def head_entries(entries: Sequence[LogEntry], count: int) -> list[LogEntry]:
    """Get the first N entries."""
    if count <= 0:
        return []
    return list(entries[:count])
