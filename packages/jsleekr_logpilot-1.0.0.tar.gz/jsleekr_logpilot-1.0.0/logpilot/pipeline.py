"""Log processing pipeline for composable transformations."""

from __future__ import annotations

from typing import Any, Callable, Iterator, Sequence

from logpilot.models import FilterConfig, LogEntry, LogLevel


# Type aliases
TransformFn = Callable[[LogEntry], LogEntry | None]
FilterFn = Callable[[LogEntry], bool]


class Pipeline:
    """Composable log processing pipeline.

    Supports chaining operations like filter, map, sort, limit.

    Usage:
        entries = Pipeline(entries)
            .filter_level(LogLevel.WARN)
            .search("timeout")
            .sort_by("timestamp")
            .limit(100)
            .execute()
    """

    def __init__(self, entries: Sequence[LogEntry] | None = None):
        self._entries: list[LogEntry] = list(entries) if entries else []
        self._transforms: list[TransformFn] = []
        self._filters: list[FilterFn] = []
        self._sort_key: str | None = None
        self._sort_reverse: bool = False
        self._limit_count: int = 0
        self._offset: int = 0
        self._executed: bool = False

    def from_entries(self, entries: Sequence[LogEntry]) -> Pipeline:
        """Set the input entries."""
        self._entries = list(entries)
        return self

    def filter(self, fn: FilterFn) -> Pipeline:
        """Add a custom filter function."""
        self._filters.append(fn)
        return self

    def filter_level(self, min_level: LogLevel) -> Pipeline:
        """Filter by minimum log level."""
        self._filters.append(lambda e: e.matches_level(min_level))
        return self

    def filter_source(self, source: str) -> Pipeline:
        """Filter by source/logger name."""
        self._filters.append(lambda e: e.source == source)
        return self

    def search(self, query: str) -> Pipeline:
        """Filter by message text search."""
        q = query.lower()
        self._filters.append(lambda e: q in e.message.lower())
        return self

    def grep(self, pattern: str) -> Pipeline:
        """Filter by raw text pattern."""
        import re
        compiled = re.compile(pattern, re.IGNORECASE)
        self._filters.append(lambda e: bool(compiled.search(e.raw)))
        return self

    def filter_field(self, field: str, value: str) -> Pipeline:
        """Filter by field value."""
        self._filters.append(lambda e: str(e.get(field, "")) == value)
        return self

    def has_field(self, field: str) -> Pipeline:
        """Filter entries that have a specific field."""
        self._filters.append(lambda e: e.get(field) is not None)
        return self

    def exclude_field(self, field: str) -> Pipeline:
        """Exclude entries that have a specific field."""
        self._filters.append(lambda e: e.get(field) is None)
        return self

    def json_only(self) -> Pipeline:
        """Keep only JSON-parsed entries."""
        self._filters.append(lambda e: e.is_json)
        return self

    def transform(self, fn: TransformFn) -> Pipeline:
        """Add a custom transform function. Return None to drop entry."""
        self._transforms.append(fn)
        return self

    def add_field(self, field: str, value: Any) -> Pipeline:
        """Add a field to all entries."""
        def _add(entry: LogEntry) -> LogEntry:
            entry.extra[field] = value
            return entry
        self._transforms.append(_add)
        return self

    def remove_field(self, field: str) -> Pipeline:
        """Remove a field from all entries."""
        def _remove(entry: LogEntry) -> LogEntry:
            entry.extra.pop(field, None)
            return entry
        self._transforms.append(_remove)
        return self

    def sort_by(self, key: str, reverse: bool = False) -> Pipeline:
        """Sort entries by a field."""
        self._sort_key = key
        self._sort_reverse = reverse
        return self

    def limit(self, count: int) -> Pipeline:
        """Limit number of results."""
        self._limit_count = count
        return self

    def offset(self, count: int) -> Pipeline:
        """Skip first N entries."""
        self._offset = count
        return self

    def tail(self, count: int) -> Pipeline:
        """Take last N entries."""
        self._limit_count = -count  # negative signals tail
        return self

    def apply_config(self, config: FilterConfig) -> Pipeline:
        """Apply a FilterConfig to the pipeline."""
        if config.min_level:
            self.filter_level(config.min_level)
        if config.source:
            self.filter_source(config.source)
        if config.search:
            self.search(config.search)
        if config.grep:
            self.grep(config.grep)
        return self

    def execute(self) -> list[LogEntry]:
        """Execute the pipeline and return results."""
        result: list[LogEntry] = []

        for entry in self._entries:
            # Apply filters
            passed = True
            for f in self._filters:
                if not f(entry):
                    passed = False
                    break
            if not passed:
                continue

            # Apply transforms
            current: LogEntry | None = entry
            for t in self._transforms:
                if current is None:
                    break
                current = t(current)
            if current is not None:
                result.append(current)

        # Sort
        if self._sort_key:
            result = self._sort_entries(result)

        # Offset
        if self._offset > 0:
            result = result[self._offset:]

        # Limit
        if self._limit_count > 0:
            result = result[:self._limit_count]
        elif self._limit_count < 0:
            result = result[self._limit_count:]

        self._executed = True
        return result

    def count(self) -> int:
        """Execute and return count."""
        return len(self.execute())

    def first(self) -> LogEntry | None:
        """Execute and return first entry."""
        results = self.limit(1).execute()
        return results[0] if results else None

    def last(self) -> LogEntry | None:
        """Execute and return last entry."""
        results = self.execute()
        return results[-1] if results else None

    def _sort_entries(self, entries: list[LogEntry]) -> list[LogEntry]:
        """Sort entries by the configured key."""
        key = self._sort_key
        if key is None:
            return entries

        def sort_key(entry: LogEntry) -> Any:
            if key == "timestamp":
                return entry.timestamp or datetime_min()
            if key == "level":
                return entry.level.value
            if key == "message":
                return entry.message
            if key == "source":
                return entry.source
            val = entry.get(key)
            return str(val) if val is not None else ""

        return sorted(entries, key=sort_key, reverse=self._sort_reverse)


def datetime_min() -> Any:
    """Return a minimum datetime for sorting purposes."""
    from datetime import datetime, timezone
    return datetime(1970, 1, 1, tzinfo=timezone.utc)
