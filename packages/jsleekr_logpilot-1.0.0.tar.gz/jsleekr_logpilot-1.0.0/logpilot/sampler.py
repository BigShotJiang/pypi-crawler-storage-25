"""Log sampling strategies and summarization."""

from __future__ import annotations

import hashlib
import random
from typing import Sequence

from logpilot.models import LogEntry, LogLevel


def reservoir_sample(entries: Sequence[LogEntry], k: int) -> list[LogEntry]:
    """Reservoir sampling: select k random entries from a potentially large sequence.

    Uses Vitter's Algorithm R for O(n) time complexity.
    """
    if k <= 0:
        return []

    result: list[LogEntry] = []
    for i, entry in enumerate(entries):
        if i < k:
            result.append(entry)
        else:
            j = random.randint(0, i)
            if j < k:
                result[j] = entry
    return result


def stratified_sample(
    entries: Sequence[LogEntry],
    k: int,
    by: str = "level",
) -> list[LogEntry]:
    """Sample entries proportionally by a grouping field.

    Ensures representation from each group.
    """
    if k <= 0:
        return []

    groups: dict[str, list[LogEntry]] = {}
    for entry in entries:
        if by == "level":
            key = entry.level.name
        elif by == "source":
            key = entry.source or "(unknown)"
        else:
            key = str(entry.get(by, "(unknown)"))
        if key not in groups:
            groups[key] = []
        groups[key].append(entry)

    total = len(entries)
    if total == 0:
        return []

    result: list[LogEntry] = []
    for group_entries in groups.values():
        # Proportional allocation
        group_k = max(1, int(k * len(group_entries) / total))
        group_k = min(group_k, len(group_entries))
        result.extend(reservoir_sample(group_entries, group_k))

    # Trim if we got too many
    if len(result) > k:
        result = reservoir_sample(result, k)

    return result


def systematic_sample(entries: Sequence[LogEntry], k: int) -> list[LogEntry]:
    """Take every Nth entry to get approximately k entries."""
    n = len(entries)
    if n <= k or k <= 0:
        return list(entries)
    step = max(1, n // k)
    return [entries[i] for i in range(0, n, step)][:k]


def hash_sample(entries: Sequence[LogEntry], rate: float, field: str = "message") -> list[LogEntry]:
    """Deterministic sampling based on hash of a field.

    Same entries always get selected, useful for consistent sampling.
    """
    if rate <= 0:
        return []
    if rate >= 1.0:
        return list(entries)

    threshold = int(rate * 2**32)
    result: list[LogEntry] = []

    for entry in entries:
        val = str(entry.get(field, entry.message))
        h = int(hashlib.md5(val.encode()).hexdigest()[:8], 16)
        if h < threshold:
            result.append(entry)

    return result


def error_focused_sample(entries: Sequence[LogEntry], k: int) -> list[LogEntry]:
    """Sample that prioritizes errors and their surrounding context.

    Takes all errors + context entries before/after each error.
    """
    errors: list[int] = []
    for i, entry in enumerate(entries):
        if entry.level >= LogLevel.ERROR:
            errors.append(i)

    if not errors:
        return systematic_sample(entries, k)

    # Include context around each error
    context_window = 2
    selected_indices: set[int] = set()
    for idx in errors:
        for offset in range(-context_window, context_window + 1):
            target = idx + offset
            if 0 <= target < len(entries):
                selected_indices.add(target)

    result = [entries[i] for i in sorted(selected_indices)]

    # If still under k, add more entries
    remaining_k = k - len(result)
    if remaining_k > 0:
        remaining = [e for i, e in enumerate(entries) if i not in selected_indices]
        result.extend(systematic_sample(remaining, remaining_k))

    return result[:k]


def summarize(entries: Sequence[LogEntry]) -> dict[str, object]:
    """Generate a compact summary of log entries."""
    if not entries:
        return {"total": 0}

    level_counts: dict[str, int] = {}
    source_counts: dict[str, int] = {}
    has_timestamps = False

    for entry in entries:
        name = entry.level.name
        level_counts[name] = level_counts.get(name, 0) + 1
        if entry.source:
            source_counts[entry.source] = source_counts.get(entry.source, 0) + 1
        if entry.timestamp:
            has_timestamps = True

    error_count = level_counts.get("ERROR", 0) + level_counts.get("FATAL", 0)

    return {
        "total": len(entries),
        "levels": level_counts,
        "sources": source_counts,
        "error_count": error_count,
        "error_rate_pct": round(error_count / len(entries) * 100, 1) if entries else 0,
        "has_timestamps": has_timestamps,
        "top_source": max(source_counts, key=source_counts.get) if source_counts else None,
    }
