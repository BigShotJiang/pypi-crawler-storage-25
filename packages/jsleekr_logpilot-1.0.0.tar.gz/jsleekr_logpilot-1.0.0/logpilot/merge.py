"""Multi-file log merging and correlation."""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Iterator, Sequence

from logpilot.models import LogEntry
from logpilot.parser import parse_file


@dataclass
class FileSource:
    """Metadata about a log file source."""
    path: str
    name: str
    entry_count: int = 0
    json_count: int = 0
    error_count: int = 0

    @property
    def json_ratio(self) -> float:
        if self.entry_count == 0:
            return 0.0
        return self.json_count / self.entry_count


def load_multiple_files(
    paths: list[str],
    tag_source: bool = True,
    max_lines_per_file: int = 0,
) -> list[LogEntry]:
    """Load and merge entries from multiple log files.

    Entries are tagged with their source file name and merged chronologically.

    Args:
        paths: List of file paths to load.
        tag_source: Add file name as source tag if entry has no source.
        max_lines_per_file: Max lines per file (0 = unlimited).
    """
    all_entries: list[LogEntry] = []

    for path in paths:
        if not os.path.exists(path):
            continue
        file_name = os.path.basename(path)
        entries = parse_file(path, max_lines=max_lines_per_file)

        for entry in entries:
            if tag_source and not entry.source:
                entry.source = file_name
            entry.extra["_file"] = file_name
            all_entries.append(entry)

    return all_entries


def merge_sorted(entries: list[LogEntry]) -> list[LogEntry]:
    """Sort entries chronologically, keeping order for entries without timestamps."""
    timed = [e for e in entries if e.timestamp is not None]
    untimed = [e for e in entries if e.timestamp is None]

    timed.sort(key=lambda e: e.timestamp)  # type: ignore
    return timed + untimed


def interleave_files(
    file_entries: dict[str, list[LogEntry]],
) -> list[LogEntry]:
    """Interleave entries from multiple files in chronological order."""
    all_entries: list[LogEntry] = []
    for name, entries in file_entries.items():
        for entry in entries:
            entry.extra["_file"] = name
            all_entries.append(entry)

    return merge_sorted(all_entries)


def file_summary(paths: list[str]) -> list[FileSource]:
    """Generate summary info for each file."""
    summaries: list[FileSource] = []

    for path in paths:
        name = os.path.basename(path)
        source = FileSource(path=path, name=name)

        if not os.path.exists(path):
            summaries.append(source)
            continue

        entries = parse_file(path)
        source.entry_count = len(entries)
        source.json_count = sum(1 for e in entries if e.is_json)
        from logpilot.models import LogLevel
        source.error_count = sum(1 for e in entries if e.level >= LogLevel.ERROR)
        summaries.append(source)

    return summaries


def split_by_source(entries: Sequence[LogEntry]) -> dict[str, list[LogEntry]]:
    """Split entries by their source field."""
    result: dict[str, list[LogEntry]] = {}
    for entry in entries:
        source = entry.source or entry.extra.get("_file", "(unknown)")
        if source not in result:
            result[source] = []
        result[source].append(entry)
    return result
