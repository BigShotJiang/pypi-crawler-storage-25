"""Structured output support for programmatic consumption."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Sequence

from logpilot.models import LogEntry, LogLevel, LogStats
from logpilot.analyzer import compute_stats


@dataclass
class StructuredOutput:
    """Structured output wrapper for all logpilot operations."""
    status: str = "ok"
    command: str = ""
    data: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "status": self.status,
            "command": self.command,
            "data": self.data,
            "metadata": self.metadata,
        }
        if self.errors:
            result["errors"] = self.errors
        return result

    def to_json(self, pretty: bool = False) -> str:
        if pretty:
            return json.dumps(self.to_dict(), indent=2, default=str)
        return json.dumps(self.to_dict(), default=str)


def create_view_output(
    entries: Sequence[LogEntry],
    total_input: int = 0,
) -> StructuredOutput:
    """Create structured output for view command."""
    return StructuredOutput(
        command="view",
        data={
            "entries": [_entry_to_dict(e) for e in entries],
            "count": len(entries),
        },
        metadata={
            "total_input": total_input,
            "filtered_count": len(entries),
        },
    )


def create_stats_output(entries: Sequence[LogEntry]) -> StructuredOutput:
    """Create structured output for stats command."""
    stats = compute_stats(entries)
    return StructuredOutput(
        command="stats",
        data={
            "total": stats.total,
            "by_level": stats.by_level,
            "by_source": stats.by_source,
            "error_rate": stats.error_rate,
            "parse_errors": stats.parse_errors,
            "first_timestamp": stats.first_timestamp.isoformat() if stats.first_timestamp else None,
            "last_timestamp": stats.last_timestamp.isoformat() if stats.last_timestamp else None,
            "duration_seconds": stats.duration_seconds,
            "unique_fields": sorted(stats.unique_fields),
        },
    )


def create_query_output(
    entries: Sequence[LogEntry],
    query: str,
    total_scanned: int,
) -> StructuredOutput:
    """Create structured output for query command."""
    return StructuredOutput(
        command="query",
        data={
            "entries": [_entry_to_dict(e) for e in entries],
            "matched": len(entries),
        },
        metadata={
            "query": query,
            "total_scanned": total_scanned,
            "match_rate": round(len(entries) / total_scanned * 100, 1) if total_scanned > 0 else 0,
        },
    )


def create_error_output(message: str, command: str = "") -> StructuredOutput:
    """Create structured output for errors."""
    return StructuredOutput(
        status="error",
        command=command,
        errors=[message],
    )


def _entry_to_dict(entry: LogEntry) -> dict[str, Any]:
    """Convert a log entry to a structured dict."""
    result: dict[str, Any] = {
        "line": entry.line_number,
        "level": entry.level.name,
        "message": entry.message,
        "is_json": entry.is_json,
    }
    if entry.timestamp:
        result["timestamp"] = entry.timestamp.isoformat()
    if entry.source:
        result["source"] = entry.source
    if entry.extra:
        result["fields"] = entry.extra
    return result
