"""Log diff comparison between two log datasets."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

from logpilot.models import LogEntry, LogLevel, LogStats
from logpilot.analyzer import compute_stats


@dataclass
class LogDiff:
    """Result of comparing two log datasets."""
    only_in_a: list[LogEntry] = field(default_factory=list)
    only_in_b: list[LogEntry] = field(default_factory=list)
    common: list[tuple[LogEntry, LogEntry]] = field(default_factory=list)
    stats_a: LogStats | None = None
    stats_b: LogStats | None = None

    @property
    def total_changes(self) -> int:
        return len(self.only_in_a) + len(self.only_in_b)

    @property
    def similarity(self) -> float:
        """Jaccard similarity between the two sets."""
        total = len(self.only_in_a) + len(self.only_in_b) + len(self.common)
        if total == 0:
            return 1.0
        return len(self.common) / total


@dataclass
class LevelDiff:
    """Comparison of level distributions."""
    level: str
    count_a: int = 0
    count_b: int = 0

    @property
    def delta(self) -> int:
        return self.count_b - self.count_a

    @property
    def delta_pct(self) -> float:
        if self.count_a == 0:
            return 100.0 if self.count_b > 0 else 0.0
        return ((self.count_b - self.count_a) / self.count_a) * 100


def compare_by_message(
    entries_a: Sequence[LogEntry],
    entries_b: Sequence[LogEntry],
) -> LogDiff:
    """Compare two log datasets by message content."""
    msgs_a = {e.message for e in entries_a}
    msgs_b = {e.message for e in entries_b}

    only_a_msgs = msgs_a - msgs_b
    only_b_msgs = msgs_b - msgs_a
    common_msgs = msgs_a & msgs_b

    result = LogDiff()
    result.only_in_a = [e for e in entries_a if e.message in only_a_msgs]
    result.only_in_b = [e for e in entries_b if e.message in only_b_msgs]

    # Pair common messages
    b_by_msg: dict[str, LogEntry] = {}
    for e in entries_b:
        if e.message in common_msgs and e.message not in b_by_msg:
            b_by_msg[e.message] = e
    for e in entries_a:
        if e.message in common_msgs and e.message in b_by_msg:
            result.common.append((e, b_by_msg.pop(e.message)))

    result.stats_a = compute_stats(entries_a)
    result.stats_b = compute_stats(entries_b)
    return result


def compare_levels(
    entries_a: Sequence[LogEntry],
    entries_b: Sequence[LogEntry],
) -> list[LevelDiff]:
    """Compare level distributions between two datasets."""
    stats_a = compute_stats(entries_a)
    stats_b = compute_stats(entries_b)

    all_levels = set(stats_a.by_level.keys()) | set(stats_b.by_level.keys())
    diffs: list[LevelDiff] = []

    level_order = ["TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL"]
    for level in level_order:
        if level in all_levels:
            diffs.append(LevelDiff(
                level=level,
                count_a=stats_a.by_level.get(level, 0),
                count_b=stats_b.by_level.get(level, 0),
            ))

    return diffs


def compare_error_patterns(
    entries_a: Sequence[LogEntry],
    entries_b: Sequence[LogEntry],
) -> dict[str, object]:
    """Compare error patterns between two datasets."""
    errors_a = {e.message for e in entries_a if e.level >= LogLevel.ERROR}
    errors_b = {e.message for e in entries_b if e.level >= LogLevel.ERROR}

    return {
        "new_errors": list(errors_b - errors_a),
        "resolved_errors": list(errors_a - errors_b),
        "persistent_errors": list(errors_a & errors_b),
        "new_count": len(errors_b - errors_a),
        "resolved_count": len(errors_a - errors_b),
        "persistent_count": len(errors_a & errors_b),
    }


def format_diff_summary(diff: LogDiff) -> str:
    """Format a diff summary for display."""
    lines: list[str] = []
    lines.append(f"Log Diff Summary")
    lines.append(f"  Only in A: {len(diff.only_in_a)} entries")
    lines.append(f"  Only in B: {len(diff.only_in_b)} entries")
    lines.append(f"  Common: {len(diff.common)} entries")
    lines.append(f"  Similarity: {diff.similarity:.1%}")
    return "\n".join(lines)
