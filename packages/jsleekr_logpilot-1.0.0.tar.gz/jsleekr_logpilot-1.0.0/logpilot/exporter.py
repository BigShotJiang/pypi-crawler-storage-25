"""Export log entries to various formats."""

from __future__ import annotations

import csv
import io
import json
from typing import Any, Sequence

from logpilot.models import LogEntry, LogStats


def export_json(entries: Sequence[LogEntry], pretty: bool = False) -> str:
    """Export entries as JSON array."""
    data = [e.to_dict() for e in entries]
    if pretty:
        return json.dumps(data, indent=2, default=str)
    return json.dumps(data, default=str)


def export_jsonl(entries: Sequence[LogEntry]) -> str:
    """Export entries as JSON Lines (one JSON object per line)."""
    lines = [json.dumps(e.to_dict(), default=str) for e in entries]
    return "\n".join(lines)


def export_csv(entries: Sequence[LogEntry], fields: list[str] | None = None) -> str:
    """Export entries as CSV.

    Args:
        entries: Log entries to export.
        fields: Column names. If None, auto-detect from entries.
    """
    if not entries:
        return ""

    if fields is None:
        fields = _auto_detect_fields(entries)

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(fields)

    for entry in entries:
        row = [_get_csv_value(entry, field) for field in fields]
        writer.writerow(row)

    return output.getvalue()


def export_tsv(entries: Sequence[LogEntry], fields: list[str] | None = None) -> str:
    """Export entries as TSV (tab-separated values)."""
    if not entries:
        return ""

    if fields is None:
        fields = _auto_detect_fields(entries)

    output = io.StringIO()
    writer = csv.writer(output, delimiter="\t")
    writer.writerow(fields)

    for entry in entries:
        row = [_get_csv_value(entry, field) for field in fields]
        writer.writerow(row)

    return output.getvalue()


def export_stats_json(stats: LogStats) -> str:
    """Export statistics as JSON."""
    data: dict[str, Any] = {
        "total": stats.total,
        "parse_errors": stats.parse_errors,
        "by_level": stats.by_level,
        "by_source": stats.by_source,
        "error_rate": stats.error_rate,
    }
    if stats.first_timestamp:
        data["first_timestamp"] = stats.first_timestamp.isoformat()
    if stats.last_timestamp:
        data["last_timestamp"] = stats.last_timestamp.isoformat()
    if stats.duration_seconds is not None:
        data["duration_seconds"] = stats.duration_seconds
    data["unique_fields"] = sorted(stats.unique_fields)
    return json.dumps(data, indent=2, default=str)


def export_markdown_table(
    entries: Sequence[LogEntry],
    fields: list[str] | None = None,
) -> str:
    """Export entries as a Markdown table."""
    if not entries:
        return ""

    if fields is None:
        fields = _auto_detect_fields(entries)

    lines: list[str] = []
    # Header
    lines.append("| " + " | ".join(fields) + " |")
    lines.append("| " + " | ".join("---" for _ in fields) + " |")

    for entry in entries:
        values = [_get_csv_value(entry, f).replace("|", "\\|") for f in fields]
        lines.append("| " + " | ".join(values) + " |")

    return "\n".join(lines)


def _auto_detect_fields(entries: Sequence[LogEntry]) -> list[str]:
    """Auto-detect field names from entries."""
    fields: list[str] = ["timestamp", "level", "message"]
    extra_keys: set[str] = set()
    for entry in entries[:100]:  # Sample first 100
        if entry.source:
            extra_keys.add("source")
        for key in entry.extra:
            extra_keys.add(key)
    if "source" in extra_keys:
        fields.append("source")
        extra_keys.discard("source")
    fields.extend(sorted(extra_keys))
    return fields


def _get_csv_value(entry: LogEntry, field: str) -> str:
    """Get a string value for a CSV field."""
    if field == "timestamp":
        return entry.timestamp.isoformat() if entry.timestamp else ""
    if field == "level":
        return entry.level.name
    if field == "message":
        return entry.message
    if field == "source":
        return entry.source
    if field == "raw":
        return entry.raw.strip()
    val = entry.get(field)
    if val is None:
        return ""
    if isinstance(val, (dict, list)):
        return json.dumps(val, default=str)
    return str(val)
