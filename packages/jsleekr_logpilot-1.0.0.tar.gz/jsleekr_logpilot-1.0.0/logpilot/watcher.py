"""File watching and tail-follow functionality."""

from __future__ import annotations

import os
import time
from typing import Callable, TextIO

from logpilot.models import LogEntry
from logpilot.parser import parse_line


class FileWatcher:
    """Watch a file for new lines (tail -f behavior).

    Usage:
        watcher = FileWatcher("app.log")
        watcher.watch(callback=print_entry)
    """

    def __init__(
        self,
        path: str,
        poll_interval: float = 0.1,
        from_end: bool = True,
    ):
        self.path = path
        self.poll_interval = poll_interval
        self.from_end = from_end
        self._running = False
        self._position: int = 0
        self._line_count: int = 0
        self._inode: int | None = None

    def watch(
        self,
        callback: Callable[[LogEntry], None],
        max_iterations: int = 0,
    ) -> None:
        """Start watching the file for new lines.

        Args:
            callback: Function called for each new log entry.
            max_iterations: Maximum number of poll cycles (0 = unlimited).
        """
        self._running = True
        iterations = 0

        # Initialize position
        if os.path.exists(self.path):
            stat = os.stat(self.path)
            self._inode = getattr(stat, 'st_ino', None)
            if self.from_end:
                self._position = stat.st_size

        while self._running:
            if max_iterations > 0:
                iterations += 1
                if iterations > max_iterations:
                    break

            if not os.path.exists(self.path):
                time.sleep(self.poll_interval)
                continue

            stat = os.stat(self.path)

            # Check for file rotation (inode change or truncation)
            current_inode = getattr(stat, 'st_ino', None)
            if self._inode is not None and current_inode != self._inode:
                self._position = 0
                self._inode = current_inode

            if stat.st_size < self._position:
                # File was truncated
                self._position = 0

            if stat.st_size > self._position:
                self._read_new_lines(callback)

            time.sleep(self.poll_interval)

    def stop(self) -> None:
        """Stop watching."""
        self._running = False

    def _read_new_lines(self, callback: Callable[[LogEntry], None]) -> None:
        """Read new lines from the file."""
        try:
            with open(self.path, "r", encoding="utf-8", errors="replace") as f:
                f.seek(self._position)
                for line in f:
                    self._line_count += 1
                    entry = parse_line(line, line_number=self._line_count)
                    callback(entry)
                self._position = f.tell()
        except (IOError, OSError):
            pass

    @property
    def is_running(self) -> bool:
        return self._running


class StreamFollower:
    """Follow a stream (stdin) for log entries."""

    def __init__(self, stream: TextIO):
        self.stream = stream
        self._line_count = 0

    def follow(self, callback: Callable[[LogEntry], None]) -> None:
        """Read lines from stream and call callback for each."""
        for line in self.stream:
            self._line_count += 1
            entry = parse_line(line, line_number=self._line_count)
            callback(entry)
