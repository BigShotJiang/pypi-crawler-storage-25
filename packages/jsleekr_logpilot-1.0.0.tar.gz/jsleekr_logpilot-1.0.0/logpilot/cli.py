"""Command-line interface for logpilot."""

from __future__ import annotations

import argparse
import sys
from typing import Sequence

from logpilot import __version__
from logpilot.analyzer import cluster_errors, compute_stats, detect_anomalies, top_messages
from logpilot.exporter import export_csv, export_json, export_jsonl, export_markdown_table
from logpilot.filter import (
    apply_filter,
    filter_by_level,
    head_entries,
    tail_entries,
)
from logpilot.formatter import OutputFormatter, format_stats
from logpilot.models import FilterConfig, LogEntry, LogLevel
from logpilot.parser import parse_file, parse_stream
from logpilot.pipeline import Pipeline
from logpilot.query import execute_query


def create_parser() -> argparse.ArgumentParser:
    """Create the argument parser."""
    parser = argparse.ArgumentParser(
        prog="logpilot",
        description="Structured JSON log viewer and analyzer for the terminal",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  logpilot app.log                          View logs with auto-formatting
  logpilot app.log --level warn             Show WARN and above
  logpilot app.log --search "timeout"       Search for timeout errors
  logpilot app.log --query "level:error AND source:api"
  logpilot app.log --stats                  Show log statistics
  logpilot app.log --format json            Output as JSON
  logpilot app.log --tail 50                Show last 50 entries
  cat app.log | logpilot                    Read from stdin
  logpilot app.log --follow                 Follow file for new entries
  logpilot app.log --anomalies              Detect anomalies
  logpilot app.log --export csv             Export to CSV
        """,
    )

    parser.add_argument(
        "file",
        nargs="?",
        default=None,
        help="Log file to read (reads stdin if omitted)",
    )
    parser.add_argument(
        "-V", "--version",
        action="version",
        version=f"logpilot {__version__}",
    )

    # Filtering
    filter_group = parser.add_argument_group("Filtering")
    filter_group.add_argument(
        "-l", "--level",
        type=str,
        default=None,
        help="Minimum log level (trace, debug, info, warn, error, fatal)",
    )
    filter_group.add_argument(
        "-s", "--search",
        type=str,
        default=None,
        help="Search for text in message field",
    )
    filter_group.add_argument(
        "-g", "--grep",
        type=str,
        default=None,
        help="Search for text in raw log line",
    )
    filter_group.add_argument(
        "-q", "--query",
        type=str,
        default=None,
        help="Query expression (e.g., 'level:error AND source:api')",
    )
    filter_group.add_argument(
        "--source",
        type=str,
        default=None,
        help="Filter by source/logger name",
    )
    filter_group.add_argument(
        "--field",
        type=str,
        nargs=2,
        metavar=("FIELD", "VALUE"),
        action="append",
        default=None,
        help="Filter by field value (e.g., --field method GET)",
    )
    filter_group.add_argument(
        "--has-field",
        type=str,
        default=None,
        help="Only show entries with this field",
    )
    filter_group.add_argument(
        "--json-only",
        action="store_true",
        help="Only show JSON-parsed entries",
    )
    filter_group.add_argument(
        "-v", "--invert",
        action="store_true",
        help="Invert filter (show non-matching entries)",
    )

    # Display
    display_group = parser.add_argument_group("Display")
    display_group.add_argument(
        "-f", "--format",
        type=str,
        default="compact",
        choices=["compact", "pretty", "json", "json-pretty", "raw", "table"],
        help="Output format (default: compact)",
    )
    display_group.add_argument(
        "--no-color",
        action="store_true",
        help="Disable colored output",
    )
    display_group.add_argument(
        "--fields",
        type=str,
        nargs="+",
        default=None,
        help="Only show these fields",
    )
    display_group.add_argument(
        "--exclude-fields",
        type=str,
        nargs="+",
        default=None,
        help="Hide these fields",
    )

    # Limiting
    limit_group = parser.add_argument_group("Limiting")
    limit_group.add_argument(
        "-n", "--head",
        type=int,
        default=0,
        help="Show first N entries",
    )
    limit_group.add_argument(
        "-t", "--tail",
        type=int,
        default=0,
        help="Show last N entries",
    )
    limit_group.add_argument(
        "--max-lines",
        type=int,
        default=0,
        help="Maximum number of input lines to read",
    )

    # Sorting
    sort_group = parser.add_argument_group("Sorting")
    sort_group.add_argument(
        "--sort",
        type=str,
        default=None,
        help="Sort by field (timestamp, level, message, etc.)",
    )
    sort_group.add_argument(
        "--reverse",
        action="store_true",
        help="Reverse sort order",
    )

    # Analysis
    analysis_group = parser.add_argument_group("Analysis")
    analysis_group.add_argument(
        "--stats",
        action="store_true",
        help="Show log statistics",
    )
    analysis_group.add_argument(
        "--anomalies",
        action="store_true",
        help="Detect anomalies in log data",
    )
    analysis_group.add_argument(
        "--top-errors",
        type=int,
        nargs="?",
        const=10,
        default=None,
        help="Show top N error clusters (default: 10)",
    )
    analysis_group.add_argument(
        "--top-messages",
        type=int,
        nargs="?",
        const=10,
        default=None,
        help="Show most frequent messages (default: 10)",
    )

    # Export
    export_group = parser.add_argument_group("Export")
    export_group.add_argument(
        "--export",
        type=str,
        choices=["json", "jsonl", "csv", "tsv", "markdown"],
        default=None,
        help="Export format",
    )
    export_group.add_argument(
        "-o", "--output",
        type=str,
        default=None,
        help="Output file (default: stdout)",
    )

    # Follow mode
    parser.add_argument(
        "-F", "--follow",
        action="store_true",
        help="Follow file for new entries (tail -f mode)",
    )

    return parser


def load_entries(args: argparse.Namespace) -> list[LogEntry]:
    """Load log entries from file or stdin."""
    if args.file:
        return parse_file(args.file, max_lines=args.max_lines)
    elif not sys.stdin.isatty():
        entries = list(parse_stream(sys.stdin, max_lines=args.max_lines))
        return entries
    else:
        print("Error: No input. Provide a file or pipe data via stdin.", file=sys.stderr)
        sys.exit(1)


def apply_filters(entries: list[LogEntry], args: argparse.Namespace) -> list[LogEntry]:
    """Apply all filter arguments to entries."""
    # Use query language if provided
    if args.query:
        result = execute_query(entries, args.query)
        return result.entries

    # Build pipeline
    pipeline = Pipeline(entries)

    if args.level:
        level = LogLevel.from_string(args.level)
        pipeline.filter_level(level)

    if args.search:
        pipeline.search(args.search)

    if args.grep:
        pipeline.grep(args.grep)

    if args.source:
        pipeline.filter_source(args.source)

    if args.json_only:
        pipeline.json_only()

    if args.has_field:
        pipeline.has_field(args.has_field)

    if args.field:
        for field_name, field_value in args.field:
            pipeline.filter_field(field_name, field_value)

    if args.sort:
        pipeline.sort_by(args.sort, reverse=args.reverse)

    result = pipeline.execute()

    # Apply head/tail
    if args.tail > 0:
        result = tail_entries(result, args.tail)
    elif args.head > 0:
        result = head_entries(result, args.head)

    return result


def run_analysis(entries: list[LogEntry], args: argparse.Namespace) -> None:
    """Run analysis commands."""
    use_color = not args.no_color

    if args.stats:
        stats = compute_stats(entries)
        print(format_stats(stats, use_color=use_color))
        return

    if args.anomalies:
        report = detect_anomalies(entries)
        print(f"Anomaly Report: {report.summary}")
        if report.error_spikes:
            print(f"\nError Spikes ({len(report.error_spikes)}):")
            for bucket in report.error_spikes:
                print(f"  {bucket.start.isoformat()} - {bucket.error_count} errors in {(bucket.end - bucket.start).total_seconds()}s")
        if report.high_frequency_errors:
            print(f"\nRecurring Errors ({len(report.high_frequency_errors)}):")
            for cluster in report.high_frequency_errors:
                print(f"  [{cluster.count}x] {cluster.pattern[:80]}")
        if report.slow_gaps:
            print(f"\nTime Gaps ({len(report.slow_gaps)}):")
            for prev_entry, next_entry, gap in report.slow_gaps[:10]:
                print(f"  {gap:.1f}s gap at line {prev_entry.line_number}")
        return

    if args.top_errors is not None:
        clusters = cluster_errors(entries, max_clusters=args.top_errors)
        if not clusters:
            print("No errors found.")
            return
        print(f"Top {len(clusters)} Error Clusters:")
        for i, cluster in enumerate(clusters, 1):
            print(f"\n  #{i} [{cluster.count}x] {cluster.pattern[:100]}")
            if cluster.samples:
                print(f"       Sample: {cluster.samples[0].message[:120]}")
        return

    if args.top_messages is not None:
        msgs = top_messages(entries, n=args.top_messages)
        if not msgs:
            print("No messages found.")
            return
        print(f"Top {len(msgs)} Messages:")
        for msg, count in msgs:
            print(f"  [{count:>5}x] {msg[:120]}")
        return


def run_export(entries: list[LogEntry], args: argparse.Namespace) -> None:
    """Run export commands."""
    if args.export == "json":
        output = export_json(entries, pretty=True)
    elif args.export == "jsonl":
        output = export_jsonl(entries)
    elif args.export == "csv":
        output = export_csv(entries)
    elif args.export == "tsv":
        output = export_csv(entries)  # reuse with tab
    elif args.export == "markdown":
        output = export_markdown_table(entries)
    else:
        output = export_json(entries, pretty=True)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(output)
        print(f"Exported {len(entries)} entries to {args.output}", file=sys.stderr)
    else:
        print(output)


def main(argv: Sequence[str] | None = None) -> int:
    """Main entry point."""
    parser = create_parser()
    args = parser.parse_args(argv)

    # Follow mode
    if args.follow and args.file:
        from logpilot.watcher import FileWatcher
        formatter = OutputFormatter(
            style=args.format,
            use_color=not args.no_color,
            fields=args.fields,
            exclude_fields=args.exclude_fields,
        )

        def on_entry(entry: LogEntry) -> None:
            if args.level:
                level = LogLevel.from_string(args.level)
                if not entry.matches_level(level):
                    return
            if args.search and args.search.lower() not in entry.message.lower():
                return
            print(formatter.format(entry), flush=True)

        watcher = FileWatcher(args.file)
        try:
            watcher.watch(callback=on_entry)
        except KeyboardInterrupt:
            watcher.stop()
        return 0

    # Load entries
    entries = load_entries(args)

    # Analysis modes
    if args.stats or args.anomalies or args.top_errors is not None or args.top_messages is not None:
        filtered = apply_filters(entries, args)
        run_analysis(filtered, args)
        return 0

    # Export mode
    if args.export:
        filtered = apply_filters(entries, args)
        run_export(filtered, args)
        return 0

    # Default: display
    filtered = apply_filters(entries, args)
    formatter = OutputFormatter(
        style=args.format,
        use_color=not args.no_color,
        fields=args.fields,
        exclude_fields=args.exclude_fields,
    )

    for entry in filtered:
        print(formatter.format(entry))

    return 0


if __name__ == "__main__":
    sys.exit(main())
