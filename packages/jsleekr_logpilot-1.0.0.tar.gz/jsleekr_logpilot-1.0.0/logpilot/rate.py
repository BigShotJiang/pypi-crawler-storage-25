"""Rate analysis and throughput calculation for log streams."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Sequence

from logpilot.models import LogEntry, LogLevel


@dataclass
class RateWindow:
    """A time window with rate information."""
    start: datetime
    end: datetime
    count: int = 0
    error_count: int = 0

    @property
    def duration_seconds(self) -> float:
        return max((self.end - self.start).total_seconds(), 0.001)

    @property
    def rate_per_second(self) -> float:
        return self.count / self.duration_seconds

    @property
    def error_rate_per_second(self) -> float:
        return self.error_count / self.duration_seconds


def calculate_throughput(
    entries: Sequence[LogEntry],
    window_seconds: int = 1,
) -> list[RateWindow]:
    """Calculate log throughput over time windows."""
    timed = sorted(
        [e for e in entries if e.timestamp is not None],
        key=lambda e: e.timestamp,  # type: ignore
    )
    if not timed:
        return []

    windows: list[RateWindow] = []
    start = timed[0].timestamp
    if start is None:
        return []

    delta = timedelta(seconds=window_seconds)
    current_start = start
    idx = 0

    while idx < len(timed):
        current_end = current_start + delta
        window = RateWindow(start=current_start, end=current_end)

        while idx < len(timed):
            ts = timed[idx].timestamp
            if ts is None or ts >= current_end:
                break
            window.count += 1
            if timed[idx].level >= LogLevel.ERROR:
                window.error_count += 1
            idx += 1

        windows.append(window)
        current_start = current_end

        # Skip empty windows (no entries in range)
        if idx < len(timed) and timed[idx].timestamp:
            next_ts = timed[idx].timestamp
            if next_ts and next_ts > current_start + delta:
                current_start = datetime(
                    next_ts.year, next_ts.month, next_ts.day,
                    next_ts.hour, next_ts.minute, next_ts.second,
                    tzinfo=next_ts.tzinfo,
                )

    return windows


def detect_rate_spikes(
    entries: Sequence[LogEntry],
    window_seconds: int = 10,
    threshold_multiplier: float = 3.0,
) -> list[RateWindow]:
    """Detect windows where rate exceeds N times the average."""
    windows = calculate_throughput(entries, window_seconds)
    if not windows:
        return []

    avg_rate = sum(w.rate_per_second for w in windows) / len(windows)
    threshold = avg_rate * threshold_multiplier

    return [w for w in windows if w.rate_per_second > threshold]


def calculate_percentiles(
    entries: Sequence[LogEntry],
    field: str,
    percentiles: list[float] | None = None,
) -> dict[str, float]:
    """Calculate percentile values for a numeric field."""
    if percentiles is None:
        percentiles = [50.0, 90.0, 95.0, 99.0]

    values: list[float] = []
    for entry in entries:
        val = entry.get(field)
        if val is not None:
            try:
                values.append(float(str(val)))
            except (ValueError, TypeError):
                pass

    if not values:
        return {}

    values.sort()
    result: dict[str, float] = {}
    for p in percentiles:
        idx = int(len(values) * p / 100)
        idx = min(idx, len(values) - 1)
        result[f"p{int(p)}"] = values[idx]

    result["min"] = values[0]
    result["max"] = values[-1]
    result["avg"] = sum(values) / len(values)
    result["count"] = float(len(values))

    return result
