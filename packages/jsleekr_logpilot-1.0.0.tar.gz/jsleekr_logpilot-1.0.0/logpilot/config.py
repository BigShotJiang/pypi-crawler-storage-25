"""Configuration file support for logpilot."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


CONFIG_FILE_NAMES = [
    ".logpilot.json",
    ".logpilotrc",
    "logpilot.json",
]

DEFAULT_CONFIG: dict[str, Any] = {
    "format": "compact",
    "color": True,
    "level": None,
    "fields": None,
    "exclude_fields": None,
    "timestamp_fields": None,
    "level_fields": None,
    "message_fields": None,
    "aliases": {},
    "profiles": {},
}


@dataclass
class LogpilotConfig:
    """Parsed configuration."""
    format: str = "compact"
    color: bool = True
    level: str | None = None
    fields: list[str] | None = None
    exclude_fields: list[str] | None = None
    timestamp_fields: list[str] | None = None
    level_fields: list[str] | None = None
    message_fields: list[str] | None = None
    aliases: dict[str, str] = field(default_factory=dict)
    profiles: dict[str, dict[str, Any]] = field(default_factory=dict)
    source_path: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any], source_path: str | None = None) -> LogpilotConfig:
        """Create config from a dictionary."""
        return cls(
            format=data.get("format", "compact"),
            color=data.get("color", True),
            level=data.get("level"),
            fields=data.get("fields"),
            exclude_fields=data.get("exclude_fields"),
            timestamp_fields=data.get("timestamp_fields"),
            level_fields=data.get("level_fields"),
            message_fields=data.get("message_fields"),
            aliases=data.get("aliases", {}),
            profiles=data.get("profiles", {}),
            source_path=source_path,
        )

    def get_profile(self, name: str) -> dict[str, Any]:
        """Get a named profile configuration."""
        return self.profiles.get(name, {})

    def merge_profile(self, name: str) -> LogpilotConfig:
        """Apply a profile's settings on top of current config."""
        profile = self.get_profile(name)
        if not profile:
            return self
        merged = {
            "format": profile.get("format", self.format),
            "color": profile.get("color", self.color),
            "level": profile.get("level", self.level),
            "fields": profile.get("fields", self.fields),
            "exclude_fields": profile.get("exclude_fields", self.exclude_fields),
            "aliases": {**self.aliases, **profile.get("aliases", {})},
            "profiles": self.profiles,
        }
        return LogpilotConfig.from_dict(merged, self.source_path)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        result: dict[str, Any] = {"format": self.format, "color": self.color}
        if self.level:
            result["level"] = self.level
        if self.fields:
            result["fields"] = self.fields
        if self.exclude_fields:
            result["exclude_fields"] = self.exclude_fields
        if self.aliases:
            result["aliases"] = self.aliases
        if self.profiles:
            result["profiles"] = self.profiles
        return result


def find_config_file(start_dir: str | None = None) -> str | None:
    """Search for a config file, walking up from start_dir."""
    if start_dir is None:
        start_dir = os.getcwd()

    current = Path(start_dir).resolve()

    # Check current and parent directories
    for _ in range(10):  # max depth
        for name in CONFIG_FILE_NAMES:
            config_path = current / name
            if config_path.exists():
                return str(config_path)
        parent = current.parent
        if parent == current:
            break
        current = parent

    # Check home directory
    home = Path.home()
    for name in CONFIG_FILE_NAMES:
        config_path = home / name
        if config_path.exists():
            return str(config_path)

    return None


def load_config(path: str | None = None) -> LogpilotConfig:
    """Load configuration from file.

    If path is None, searches for config file automatically.
    """
    if path is None:
        path = find_config_file()

    if path is None:
        return LogpilotConfig()

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return LogpilotConfig.from_dict(data, source_path=path)
    except (json.JSONDecodeError, IOError, OSError):
        return LogpilotConfig()


def save_config(config: LogpilotConfig, path: str) -> None:
    """Save configuration to a JSON file."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(config.to_dict(), f, indent=2)


def generate_default_config() -> str:
    """Generate a default configuration file content."""
    default = {
        "format": "compact",
        "color": True,
        "level": None,
        "fields": None,
        "exclude_fields": ["_file"],
        "aliases": {
            "err": "--level error",
            "warn": "--level warn",
        },
        "profiles": {
            "production": {
                "format": "compact",
                "level": "warn",
                "exclude_fields": ["debug_info", "stack_trace"],
            },
            "debug": {
                "format": "pretty",
                "level": "debug",
            },
        },
    }
    return json.dumps(default, indent=2)
