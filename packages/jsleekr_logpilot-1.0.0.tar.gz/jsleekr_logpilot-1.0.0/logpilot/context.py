"""Request context tracking and trace correlation."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Sequence

from logpilot.models import LogEntry, LogLevel


# Common request/trace ID field names
TRACE_ID_FIELDS = [
    "trace_id", "traceId", "trace-id", "x-trace-id",
    "request_id", "requestId", "request-id", "x-request-id",
    "correlation_id", "correlationId", "x-correlation-id",
    "span_id", "spanId",
    "req_id", "reqId",
    "transaction_id", "transactionId",
    "uuid",
]


@dataclass
class RequestTrace:
    """A group of log entries sharing a trace/request ID."""
    trace_id: str
    entries: list[LogEntry] = field(default_factory=list)
    start_time: datetime | None = None
    end_time: datetime | None = None
    has_error: bool = False
    sources: set[str] = field(default_factory=set)

    @property
    def duration_ms(self) -> float | None:
        """Duration of the trace in milliseconds."""
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds() * 1000
        return None

    @property
    def entry_count(self) -> int:
        return len(self.entries)

    def add_entry(self, entry: LogEntry) -> None:
        """Add an entry to this trace."""
        self.entries.append(entry)
        if entry.timestamp:
            if self.start_time is None or entry.timestamp < self.start_time:
                self.start_time = entry.timestamp
            if self.end_time is None or entry.timestamp > self.end_time:
                self.end_time = entry.timestamp
        if entry.level >= LogLevel.ERROR:
            self.has_error = True
        if entry.source:
            self.sources.add(entry.source)


def extract_trace_id(entry: LogEntry) -> str | None:
    """Extract a trace/request ID from a log entry."""
    for field_name in TRACE_ID_FIELDS:
        value = entry.get(field_name)
        if value is not None:
            return str(value)
    return None


def group_by_trace(entries: Sequence[LogEntry]) -> dict[str, RequestTrace]:
    """Group log entries by trace/request ID."""
    traces: dict[str, RequestTrace] = {}
    for entry in entries:
        trace_id = extract_trace_id(entry)
        if trace_id is None:
            continue
        if trace_id not in traces:
            traces[trace_id] = RequestTrace(trace_id=trace_id)
        traces[trace_id].add_entry(entry)
    return traces


def find_slow_traces(
    entries: Sequence[LogEntry],
    threshold_ms: float = 1000.0,
) -> list[RequestTrace]:
    """Find traces that exceed the duration threshold."""
    traces = group_by_trace(entries)
    slow: list[RequestTrace] = []
    for trace in traces.values():
        duration = trace.duration_ms
        if duration is not None and duration > threshold_ms:
            slow.append(trace)
    slow.sort(key=lambda t: t.duration_ms or 0, reverse=True)
    return slow


def find_error_traces(entries: Sequence[LogEntry]) -> list[RequestTrace]:
    """Find traces that contain errors."""
    traces = group_by_trace(entries)
    return [t for t in traces.values() if t.has_error]


def trace_summary(traces: dict[str, RequestTrace]) -> dict[str, object]:
    """Generate a summary of all traces."""
    durations = [t.duration_ms for t in traces.values() if t.duration_ms is not None]
    error_count = sum(1 for t in traces.values() if t.has_error)
    return {
        "total_traces": len(traces),
        "error_traces": error_count,
        "avg_duration_ms": sum(durations) / len(durations) if durations else 0,
        "max_duration_ms": max(durations) if durations else 0,
        "min_duration_ms": min(durations) if durations else 0,
        "error_rate_pct": (error_count / len(traces) * 100) if traces else 0,
    }
