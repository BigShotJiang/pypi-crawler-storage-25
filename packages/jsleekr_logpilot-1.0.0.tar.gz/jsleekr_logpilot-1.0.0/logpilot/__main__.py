"""Allow running logpilot as a module: python -m logpilot."""

import sys
from logpilot.cli import main

sys.exit(main())
