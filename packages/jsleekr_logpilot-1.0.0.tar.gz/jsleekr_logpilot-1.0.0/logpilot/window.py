"""Time-based windowing and sessionization for log entries."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Sequence

from logpilot.models import LogEntry, LogLevel


@dataclass
class TimeWindow:
    """A fixed time window containing log entries."""
    start: datetime
    end: datetime
    entries: list[LogEntry] = field(default_factory=list)
    label: str = ""

    @property
    def count(self) -> int:
        return len(self.entries)

    @property
    def error_count(self) -> int:
        return sum(1 for e in self.entries if e.level >= LogLevel.ERROR)

    @property
    def duration_seconds(self) -> float:
        return (self.end - self.start).total_seconds()


@dataclass
class Session:
    """A session of related log entries grouped by time proximity."""
    entries: list[LogEntry] = field(default_factory=list)
    session_id: int = 0

    @property
    def start(self) -> datetime | None:
        if not self.entries or not self.entries[0].timestamp:
            return None
        return self.entries[0].timestamp

    @property
    def end(self) -> datetime | None:
        if not self.entries or not self.entries[-1].timestamp:
            return None
        return self.entries[-1].timestamp

    @property
    def duration_seconds(self) -> float | None:
        if self.start and self.end:
            return (self.end - self.start).total_seconds()
        return None

    @property
    def count(self) -> int:
        return len(self.entries)


def fixed_windows(
    entries: Sequence[LogEntry],
    window_seconds: int = 60,
) -> list[TimeWindow]:
    """Split entries into fixed-size time windows."""
    timed = sorted(
        [e for e in entries if e.timestamp is not None],
        key=lambda e: e.timestamp,  # type: ignore
    )
    if not timed:
        return []

    start = timed[0].timestamp
    end = timed[-1].timestamp
    if start is None or end is None:
        return []

    windows: list[TimeWindow] = []
    delta = timedelta(seconds=window_seconds)
    current = start
    idx = 0

    while current <= end:
        window_end = current + delta
        window = TimeWindow(start=current, end=window_end)

        while idx < len(timed):
            ts = timed[idx].timestamp
            if ts is None or ts >= window_end:
                break
            window.entries.append(timed[idx])
            idx += 1

        windows.append(window)
        current = window_end

    return windows


def sliding_window(
    entries: Sequence[LogEntry],
    window_seconds: int = 60,
    step_seconds: int = 30,
) -> list[TimeWindow]:
    """Create sliding/overlapping time windows."""
    timed = sorted(
        [e for e in entries if e.timestamp is not None],
        key=lambda e: e.timestamp,  # type: ignore
    )
    if not timed:
        return []

    start = timed[0].timestamp
    end = timed[-1].timestamp
    if start is None or end is None:
        return []

    windows: list[TimeWindow] = []
    delta = timedelta(seconds=window_seconds)
    step = timedelta(seconds=step_seconds)
    current = start

    while current <= end:
        window_end = current + delta
        window = TimeWindow(start=current, end=window_end)

        for entry in timed:
            ts = entry.timestamp
            if ts is not None and current <= ts < window_end:
                window.entries.append(entry)

        windows.append(window)
        current += step

    return windows


def sessionize(
    entries: Sequence[LogEntry],
    gap_seconds: float = 300.0,
) -> list[Session]:
    """Group entries into sessions based on time gaps.

    A new session starts when there's a gap > gap_seconds between entries.
    """
    timed = sorted(
        [e for e in entries if e.timestamp is not None],
        key=lambda e: e.timestamp,  # type: ignore
    )
    if not timed:
        return []

    sessions: list[Session] = []
    current = Session(session_id=1)
    current.entries.append(timed[0])

    for i in range(1, len(timed)):
        prev_ts = timed[i - 1].timestamp
        curr_ts = timed[i].timestamp
        if prev_ts and curr_ts:
            gap = (curr_ts - prev_ts).total_seconds()
            if gap > gap_seconds:
                sessions.append(current)
                current = Session(session_id=len(sessions) + 1)
        current.entries.append(timed[i])

    sessions.append(current)
    return sessions


def peak_window(
    entries: Sequence[LogEntry],
    window_seconds: int = 60,
) -> TimeWindow | None:
    """Find the time window with the most entries."""
    windows = fixed_windows(entries, window_seconds)
    if not windows:
        return None
    return max(windows, key=lambda w: w.count)


def quietest_window(
    entries: Sequence[LogEntry],
    window_seconds: int = 60,
) -> TimeWindow | None:
    """Find the time window with the fewest entries."""
    windows = fixed_windows(entries, window_seconds)
    if not windows:
        return None
    return min(windows, key=lambda w: w.count)
