"""Log quality validation and lint checks."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

from logpilot.models import LogEntry, LogLevel


@dataclass
class ValidationIssue:
    """A single validation issue found in a log entry."""
    rule: str
    severity: str  # "error", "warning", "info"
    message: str
    line_number: int = 0
    entry: LogEntry | None = None


@dataclass
class ValidationReport:
    """Result of validating a set of log entries."""
    issues: list[ValidationIssue] = field(default_factory=list)
    entries_checked: int = 0
    entries_with_issues: int = 0

    @property
    def issue_count(self) -> int:
        return len(self.issues)

    @property
    def has_errors(self) -> bool:
        return any(i.severity == "error" for i in self.issues)

    def by_severity(self, severity: str) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == severity]

    def by_rule(self, rule: str) -> list[ValidationIssue]:
        return [i for i in self.issues if i.rule == rule]


def validate_entries(
    entries: Sequence[LogEntry],
    rules: list[str] | None = None,
) -> ValidationReport:
    """Run validation rules against log entries.

    Default rules:
    - missing_timestamp: Entries without timestamps
    - missing_level: Entries without explicit levels
    - missing_message: Entries with empty messages
    - non_json: Entries that aren't valid JSON
    - duplicate_messages: Repeated identical messages
    - level_consistency: Mixed level field names
    """
    if rules is None:
        rules = [
            "missing_timestamp",
            "missing_message",
            "non_json",
            "high_error_rate",
        ]

    report = ValidationReport(entries_checked=len(entries))
    entries_flagged: set[int] = set()

    for rule in rules:
        if rule == "missing_timestamp":
            _check_missing_timestamp(entries, report, entries_flagged)
        elif rule == "missing_message":
            _check_missing_message(entries, report, entries_flagged)
        elif rule == "non_json":
            _check_non_json(entries, report, entries_flagged)
        elif rule == "high_error_rate":
            _check_high_error_rate(entries, report)
        elif rule == "duplicate_messages":
            _check_duplicate_messages(entries, report, entries_flagged)

    report.entries_with_issues = len(entries_flagged)
    return report


def _check_missing_timestamp(
    entries: Sequence[LogEntry],
    report: ValidationReport,
    flagged: set[int],
) -> None:
    count = 0
    for entry in entries:
        if entry.is_json and entry.timestamp is None:
            count += 1
            if count <= 5:  # limit samples
                report.issues.append(ValidationIssue(
                    rule="missing_timestamp",
                    severity="warning",
                    message=f"JSON entry at line {entry.line_number} has no timestamp",
                    line_number=entry.line_number,
                    entry=entry,
                ))
            flagged.add(entry.line_number)
    if count > 5:
        report.issues.append(ValidationIssue(
            rule="missing_timestamp",
            severity="warning",
            message=f"... and {count - 5} more entries without timestamps",
        ))


def _check_missing_message(
    entries: Sequence[LogEntry],
    report: ValidationReport,
    flagged: set[int],
) -> None:
    count = 0
    for entry in entries:
        if entry.is_json and not entry.message:
            count += 1
            if count <= 5:
                report.issues.append(ValidationIssue(
                    rule="missing_message",
                    severity="info",
                    message=f"JSON entry at line {entry.line_number} has no message field",
                    line_number=entry.line_number,
                    entry=entry,
                ))
            flagged.add(entry.line_number)


def _check_non_json(
    entries: Sequence[LogEntry],
    report: ValidationReport,
    flagged: set[int],
) -> None:
    non_json_count = sum(1 for e in entries if not e.is_json)
    total = len(entries)
    if non_json_count > 0 and total > 0:
        pct = non_json_count / total * 100
        report.issues.append(ValidationIssue(
            rule="non_json",
            severity="warning" if pct > 10 else "info",
            message=f"{non_json_count} of {total} entries ({pct:.1f}%) are not valid JSON",
        ))
        for entry in entries:
            if not entry.is_json:
                flagged.add(entry.line_number)


def _check_high_error_rate(
    entries: Sequence[LogEntry],
    report: ValidationReport,
) -> None:
    if not entries:
        return
    error_count = sum(1 for e in entries if e.level >= LogLevel.ERROR)
    total = len(entries)
    rate = error_count / total * 100
    if rate > 50:
        report.issues.append(ValidationIssue(
            rule="high_error_rate",
            severity="error",
            message=f"Very high error rate: {rate:.1f}% ({error_count}/{total})",
        ))
    elif rate > 20:
        report.issues.append(ValidationIssue(
            rule="high_error_rate",
            severity="warning",
            message=f"High error rate: {rate:.1f}% ({error_count}/{total})",
        ))


def _check_duplicate_messages(
    entries: Sequence[LogEntry],
    report: ValidationReport,
    flagged: set[int],
) -> None:
    from collections import Counter
    msg_counts: Counter[str] = Counter()
    for entry in entries:
        if entry.message:
            msg_counts[entry.message] += 1

    for msg, count in msg_counts.most_common(5):
        if count > 10:
            report.issues.append(ValidationIssue(
                rule="duplicate_messages",
                severity="info",
                message=f"Message repeated {count} times: {msg[:80]}",
            ))
