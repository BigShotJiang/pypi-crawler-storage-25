"""Tests for logpilot.context."""

import pytest
from datetime import datetime, timezone, timedelta

from logpilot.context import (
    extract_trace_id,
    group_by_trace,
    find_slow_traces,
    find_error_traces,
    trace_summary,
    RequestTrace,
)
from logpilot.models import LogEntry, LogLevel


def _traced_entries() -> list[LogEntry]:
    base = datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    return [
        LogEntry(raw="", level=LogLevel.INFO, message="start",
                 data={"trace_id": "abc123", "method": "GET"},
                 timestamp=base, source="api", is_json=True),
        LogEntry(raw="", level=LogLevel.INFO, message="query",
                 data={"trace_id": "abc123", "table": "users"},
                 timestamp=base + timedelta(milliseconds=50), source="db", is_json=True),
        LogEntry(raw="", level=LogLevel.INFO, message="response",
                 data={"trace_id": "abc123", "status": 200},
                 timestamp=base + timedelta(milliseconds=100), source="api", is_json=True),
        LogEntry(raw="", level=LogLevel.INFO, message="start",
                 data={"trace_id": "def456", "method": "POST"},
                 timestamp=base + timedelta(seconds=1), source="api", is_json=True),
        LogEntry(raw="", level=LogLevel.ERROR, message="failed",
                 data={"trace_id": "def456", "error": "timeout"},
                 timestamp=base + timedelta(seconds=3), source="worker", is_json=True),
    ]


class TestExtractTraceId:
    def test_trace_id_field(self):
        entry = LogEntry(raw="", data={"trace_id": "abc123"}, message="")
        assert extract_trace_id(entry) == "abc123"

    def test_request_id_field(self):
        entry = LogEntry(raw="", data={"requestId": "req-001"}, message="")
        assert extract_trace_id(entry) == "req-001"

    def test_correlation_id_field(self):
        entry = LogEntry(raw="", data={"correlation_id": "corr-1"}, message="")
        assert extract_trace_id(entry) == "corr-1"

    def test_no_trace_id(self):
        entry = LogEntry(raw="", data={"method": "GET"}, message="")
        assert extract_trace_id(entry) is None


class TestRequestTrace:
    def test_add_entry(self):
        trace = RequestTrace(trace_id="abc")
        entry = LogEntry(raw="", level=LogLevel.INFO, message="test",
                        timestamp=datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc))
        trace.add_entry(entry)
        assert trace.entry_count == 1
        assert trace.start_time is not None

    def test_duration(self):
        trace = RequestTrace(
            trace_id="abc",
            start_time=datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            end_time=datetime(2024, 1, 1, 12, 0, 1, tzinfo=timezone.utc),
        )
        assert trace.duration_ms == 1000.0

    def test_has_error(self):
        trace = RequestTrace(trace_id="abc")
        entry = LogEntry(raw="", level=LogLevel.ERROR, message="fail")
        trace.add_entry(entry)
        assert trace.has_error

    def test_sources_tracked(self):
        trace = RequestTrace(trace_id="abc")
        trace.add_entry(LogEntry(raw="", level=LogLevel.INFO, message="", source="api"))
        trace.add_entry(LogEntry(raw="", level=LogLevel.INFO, message="", source="db"))
        assert trace.sources == {"api", "db"}


class TestGroupByTrace:
    def test_groups_entries(self):
        entries = _traced_entries()
        traces = group_by_trace(entries)
        assert "abc123" in traces
        assert "def456" in traces
        assert traces["abc123"].entry_count == 3
        assert traces["def456"].entry_count == 2

    def test_empty_entries(self):
        traces = group_by_trace([])
        assert len(traces) == 0

    def test_entries_without_trace(self):
        entries = [LogEntry(raw="", data={"method": "GET"}, message="")]
        traces = group_by_trace(entries)
        assert len(traces) == 0


class TestFindSlowTraces:
    def test_find_slow(self):
        entries = _traced_entries()
        slow = find_slow_traces(entries, threshold_ms=50)
        # abc123 = 100ms, def456 = 2000ms
        assert len(slow) >= 1
        assert slow[0].trace_id == "def456"  # slowest first

    def test_no_slow(self):
        entries = _traced_entries()
        slow = find_slow_traces(entries, threshold_ms=10000)
        assert len(slow) == 0


class TestFindErrorTraces:
    def test_find_errors(self):
        entries = _traced_entries()
        error_traces = find_error_traces(entries)
        assert len(error_traces) == 1
        assert error_traces[0].trace_id == "def456"


class TestTraceSummary:
    def test_summary(self):
        entries = _traced_entries()
        traces = group_by_trace(entries)
        summary = trace_summary(traces)
        assert summary["total_traces"] == 2
        assert summary["error_traces"] == 1
        assert summary["error_rate_pct"] == 50.0
        assert summary["max_duration_ms"] > 0
