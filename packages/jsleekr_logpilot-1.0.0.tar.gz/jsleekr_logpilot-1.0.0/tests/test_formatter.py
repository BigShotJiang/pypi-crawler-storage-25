"""Tests for logpilot.formatter."""

import pytest
from datetime import datetime, timezone

from logpilot.formatter import (
    format_level,
    format_compact,
    format_pretty,
    format_json,
    format_raw,
    format_stats,
    colorize,
    OutputFormatter,
    Colors,
)
from logpilot.models import LogEntry, LogLevel, LogStats


class TestColorize:
    def test_colorize_adds_reset(self):
        result = colorize("hello", Colors.RED)
        assert result.startswith(Colors.RED)
        assert result.endswith(Colors.RESET)
        assert "hello" in result


class TestFormatLevel:
    def test_format_with_color(self):
        result = format_level(LogLevel.ERROR, use_color=True)
        assert "ERROR" in result
        assert Colors.RED in result

    def test_format_without_color(self):
        result = format_level(LogLevel.INFO, use_color=False)
        assert "INFO" in result
        assert Colors.GREEN not in result

    def test_all_levels_have_icons(self):
        for level in LogLevel:
            result = format_level(level, use_color=False)
            assert level.name in result


class TestFormatCompact:
    def test_basic_entry(self):
        entry = LogEntry(
            raw="",
            level=LogLevel.INFO,
            message="Server started",
            timestamp=datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        )
        result = format_compact(entry, use_color=False)
        assert "12:00:00" in result
        assert "INFO" in result
        assert "Server started" in result

    def test_with_extras(self):
        entry = LogEntry(
            raw="",
            level=LogLevel.INFO,
            message="Request",
            extra={"method": "GET", "path": "/api"},
        )
        result = format_compact(entry, use_color=False)
        assert "method=GET" in result
        assert "path=/api" in result

    def test_no_timestamp(self):
        entry = LogEntry(raw="", level=LogLevel.INFO, message="test")
        result = format_compact(entry, use_color=False)
        assert "INFO" in result
        assert "test" in result


class TestFormatPretty:
    def test_pretty_with_source(self):
        entry = LogEntry(
            raw="",
            level=LogLevel.INFO,
            message="Request handled",
            source="api",
            extra={"method": "GET", "status": 200},
        )
        result = format_pretty(entry, use_color=False)
        assert "(api)" in result
        assert "method:" in result
        assert "status:" in result

    def test_pretty_multiline(self):
        entry = LogEntry(
            raw="",
            level=LogLevel.ERROR,
            message="Failed",
            extra={"error": "timeout", "retry": 3},
        )
        result = format_pretty(entry, use_color=False)
        lines = result.split("\n")
        assert len(lines) >= 2  # header + at least one field


class TestFormatJson:
    def test_json_output(self):
        entry = LogEntry(raw="", message="test", level=LogLevel.INFO)
        result = format_json(entry)
        import json
        parsed = json.loads(result)
        assert parsed["message"] == "test"
        assert parsed["level"] == "INFO"


class TestFormatRaw:
    def test_raw_returns_original(self):
        entry = LogEntry(raw='{"level":"info","msg":"original"}\n')
        result = format_raw(entry)
        assert result == '{"level":"info","msg":"original"}'


class TestFormatStats:
    def test_format_stats_output(self):
        stats = LogStats(
            total=100,
            by_level={"INFO": 70, "WARN": 20, "ERROR": 10},
            parse_errors=5,
        )
        result = format_stats(stats, use_color=False)
        assert "100" in result
        assert "INFO" in result
        assert "Error rate: 10.0%" in result

    def test_format_stats_with_sources(self):
        stats = LogStats(
            total=50,
            by_level={"INFO": 50},
            by_source={"api": 30, "worker": 20},
        )
        result = format_stats(stats, use_color=False)
        assert "api" in result
        assert "worker" in result


class TestOutputFormatter:
    def test_compact_format(self):
        formatter = OutputFormatter(style="compact", use_color=False)
        entry = LogEntry(raw="", level=LogLevel.INFO, message="test")
        result = formatter.format(entry)
        assert "INFO" in result

    def test_json_format(self):
        formatter = OutputFormatter(style="json")
        entry = LogEntry(raw="", level=LogLevel.INFO, message="test")
        result = formatter.format(entry)
        import json
        parsed = json.loads(result)
        assert parsed["level"] == "INFO"

    def test_field_selection(self):
        formatter = OutputFormatter(style="compact", use_color=False, fields=["method"])
        entry = LogEntry(
            raw="",
            level=LogLevel.INFO,
            message="test",
            data={"method": "GET", "path": "/api"},
            extra={"method": "GET", "path": "/api"},
        )
        result = formatter.format(entry)
        assert "method" in result

    def test_field_exclusion(self):
        formatter = OutputFormatter(
            style="compact",
            use_color=False,
            exclude_fields=["secret"],
        )
        entry = LogEntry(
            raw="",
            level=LogLevel.INFO,
            message="test",
            extra={"secret": "hidden", "visible": "shown"},
        )
        result = formatter.format(entry)
        assert "hidden" not in result
        assert "shown" in result

    def test_format_all(self):
        formatter = OutputFormatter(style="compact", use_color=False)
        entries = [
            LogEntry(raw="", level=LogLevel.INFO, message="first"),
            LogEntry(raw="", level=LogLevel.ERROR, message="second"),
        ]
        result = formatter.format_all(entries)
        assert "first" in result
        assert "second" in result
