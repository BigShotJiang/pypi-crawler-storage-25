"""Tests for logpilot.bookmark."""

import json
import pytest

from logpilot.bookmark import Bookmark, BookmarkStore
from logpilot.models import LogEntry, LogLevel


class TestBookmark:
    def test_to_dict(self):
        bm = Bookmark(line_number=10, message="error occurred", annotation="investigate")
        d = bm.to_dict()
        assert d["line_number"] == 10
        assert d["message"] == "error occurred"
        assert d["annotation"] == "investigate"

    def test_from_dict(self):
        data = {"line_number": 5, "message": "test", "tags": ["bug"]}
        bm = Bookmark.from_dict(data)
        assert bm.line_number == 5
        assert bm.tags == ["bug"]

    def test_roundtrip(self):
        bm = Bookmark(line_number=1, message="hello", annotation="note", tags=["a", "b"])
        d = bm.to_dict()
        restored = Bookmark.from_dict(d)
        assert restored.line_number == bm.line_number
        assert restored.message == bm.message
        assert restored.tags == bm.tags


class TestBookmarkStore:
    def test_add_bookmark(self):
        store = BookmarkStore()
        entry = LogEntry(raw="", message="error", line_number=42, level=LogLevel.ERROR)
        bm = store.add(entry, annotation="check this")
        assert store.count == 1
        assert bm.line_number == 42
        assert bm.annotation == "check this"

    def test_remove_bookmark(self):
        store = BookmarkStore()
        entry = LogEntry(raw="", message="test", line_number=10)
        store.add(entry)
        assert store.remove(10)
        assert store.count == 0

    def test_remove_nonexistent(self):
        store = BookmarkStore()
        assert not store.remove(99)

    def test_get_by_line(self):
        store = BookmarkStore()
        entry = LogEntry(raw="", message="test", line_number=5)
        store.add(entry, annotation="found it")
        bm = store.get_by_line(5)
        assert bm is not None
        assert bm.annotation == "found it"

    def test_get_by_line_not_found(self):
        store = BookmarkStore()
        assert store.get_by_line(99) is None

    def test_get_by_tag(self):
        store = BookmarkStore()
        store.add(LogEntry(raw="", message="a", line_number=1), tags=["bug"])
        store.add(LogEntry(raw="", message="b", line_number=2), tags=["feature"])
        store.add(LogEntry(raw="", message="c", line_number=3), tags=["bug"])
        bugs = store.get_by_tag("bug")
        assert len(bugs) == 2

    def test_search(self):
        store = BookmarkStore()
        store.add(LogEntry(raw="", message="timeout error", line_number=1))
        store.add(LogEntry(raw="", message="ok response", line_number=2))
        results = store.search("timeout")
        assert len(results) == 1

    def test_search_annotation(self):
        store = BookmarkStore()
        store.add(LogEntry(raw="", message="error", line_number=1), annotation="needs fix")
        results = store.search("needs fix")
        assert len(results) == 1

    def test_all_tags(self):
        store = BookmarkStore()
        store.add(LogEntry(raw="", message="", line_number=1), tags=["a", "b"])
        store.add(LogEntry(raw="", message="", line_number=2), tags=["b", "c"])
        assert store.all_tags() == {"a", "b", "c"}

    def test_clear(self):
        store = BookmarkStore()
        store.add(LogEntry(raw="", message="", line_number=1))
        store.add(LogEntry(raw="", message="", line_number=2))
        store.clear()
        assert store.count == 0

    def test_save_and_load(self, tmp_path):
        store = BookmarkStore(source_file="app.log")
        store.add(LogEntry(raw="", message="error", line_number=10), annotation="check")
        store.add(LogEntry(raw="", message="warn", line_number=20), tags=["slow"])

        path = str(tmp_path / "bookmarks.json")
        store.save(path)

        loaded = BookmarkStore.load(path)
        assert loaded.count == 2
        assert loaded.source_file == "app.log"
        assert loaded.bookmarks[0].annotation == "check"

    def test_load_nonexistent(self):
        store = BookmarkStore.load("/nonexistent/path.json")
        assert store.count == 0

    def test_load_invalid_json(self, tmp_path):
        path = str(tmp_path / "bad.json")
        with open(path, "w") as f:
            f.write("not json")
        store = BookmarkStore.load(path)
        assert store.count == 0
