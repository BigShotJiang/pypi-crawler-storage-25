"""Tests for logpilot.highlighter."""

import pytest

from logpilot.highlighter import Highlighter, strip_ansi, truncate, wrap_text


class TestHighlighter:
    def test_highlight_match(self):
        h = Highlighter(patterns=["error"], use_color=True)
        result = h.highlight("An error occurred")
        assert "error" in result
        assert "\033[" in result  # ANSI codes present

    def test_no_color(self):
        h = Highlighter(patterns=["error"], use_color=False)
        result = h.highlight("An error occurred")
        assert result == "An error occurred"

    def test_case_insensitive(self):
        h = Highlighter(patterns=["ERROR"], use_color=True)
        result = h.highlight("An error occurred")
        assert "\033[" in result

    def test_multiple_patterns(self):
        h = Highlighter(patterns=["error", "timeout"], use_color=True)
        result = h.highlight("An error and timeout")
        stripped = strip_ansi(result)
        assert "error" in stripped
        assert "timeout" in stripped

    def test_has_match(self):
        h = Highlighter(patterns=["error"])
        assert h.has_match("An error occurred")
        assert not h.has_match("All good")

    def test_count_matches(self):
        h = Highlighter(patterns=["error"])
        assert h.count_matches("error and another error") == 2
        assert h.count_matches("no match") == 0

    def test_empty_patterns(self):
        h = Highlighter(patterns=[])
        result = h.highlight("test text")
        assert result == "test text"

    def test_highlight_regex(self):
        h = Highlighter(use_color=True)
        result = h.highlight_regex("status: 500", r"\d+")
        assert "\033[" in result

    def test_highlight_regex_no_color(self):
        h = Highlighter(use_color=False)
        result = h.highlight_regex("status: 500", r"\d+")
        assert result == "status: 500"


class TestStripAnsi:
    def test_strip_codes(self):
        text = "\033[31mred text\033[0m"
        assert strip_ansi(text) == "red text"

    def test_no_codes(self):
        text = "plain text"
        assert strip_ansi(text) == "plain text"

    def test_multiple_codes(self):
        text = "\033[1m\033[31mbold red\033[0m normal"
        assert strip_ansi(text) == "bold red normal"


class TestTruncate:
    def test_short_text(self):
        assert truncate("short", max_width=80) == "short"

    def test_long_text(self):
        result = truncate("a" * 100, max_width=50)
        assert len(result) <= 50
        assert result.endswith("...")

    def test_word_boundary(self):
        result = truncate("this is a long text that needs truncation here", max_width=30)
        assert result.endswith("...")
        assert len(result) <= 30


class TestWrapText:
    def test_short_text(self):
        result = wrap_text("short text", max_width=80)
        assert result == ["short text"]

    def test_long_text(self):
        long = "word " * 20
        result = wrap_text(long.strip(), max_width=40)
        assert len(result) > 1
        for line in result:
            assert len(line) <= 45  # some tolerance for word boundaries

    def test_indent(self):
        long = "word " * 20
        result = wrap_text(long.strip(), max_width=40, indent=4)
        if len(result) > 1:
            assert result[1].startswith("    ")
