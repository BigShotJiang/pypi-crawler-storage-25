"""Tests for logpilot.config."""

import json
import pytest

from logpilot.config import (
    LogpilotConfig,
    find_config_file,
    load_config,
    save_config,
    generate_default_config,
)


class TestLogpilotConfig:
    def test_defaults(self):
        config = LogpilotConfig()
        assert config.format == "compact"
        assert config.color is True
        assert config.level is None

    def test_from_dict(self):
        data = {"format": "pretty", "color": False, "level": "warn"}
        config = LogpilotConfig.from_dict(data)
        assert config.format == "pretty"
        assert config.color is False
        assert config.level == "warn"

    def test_from_dict_with_profiles(self):
        data = {
            "format": "compact",
            "profiles": {
                "prod": {"level": "error", "format": "json"},
            },
        }
        config = LogpilotConfig.from_dict(data)
        assert "prod" in config.profiles

    def test_get_profile(self):
        config = LogpilotConfig(profiles={"prod": {"level": "error"}})
        assert config.get_profile("prod") == {"level": "error"}
        assert config.get_profile("nonexistent") == {}

    def test_merge_profile(self):
        config = LogpilotConfig(
            format="compact",
            level="info",
            profiles={"prod": {"level": "error", "format": "json"}},
        )
        merged = config.merge_profile("prod")
        assert merged.level == "error"
        assert merged.format == "json"

    def test_merge_nonexistent_profile(self):
        config = LogpilotConfig(format="compact")
        merged = config.merge_profile("nonexistent")
        assert merged.format == "compact"

    def test_to_dict(self):
        config = LogpilotConfig(format="pretty", level="warn")
        d = config.to_dict()
        assert d["format"] == "pretty"
        assert d["level"] == "warn"

    def test_aliases(self):
        config = LogpilotConfig(aliases={"err": "--level error"})
        assert config.aliases["err"] == "--level error"


class TestFindConfigFile:
    def test_find_in_directory(self, tmp_path):
        config_file = tmp_path / ".logpilot.json"
        config_file.write_text('{"format":"pretty"}')
        result = find_config_file(str(tmp_path))
        assert result is not None
        assert ".logpilot.json" in result

    def test_not_found(self, tmp_path):
        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()
        result = find_config_file(str(empty_dir))
        # May or may not find one in parent dirs
        # Just verify it doesn't crash
        assert result is None or isinstance(result, str)

    def test_parent_directory(self, tmp_path):
        config_file = tmp_path / ".logpilot.json"
        config_file.write_text('{"format":"json"}')
        child = tmp_path / "subdir"
        child.mkdir()
        result = find_config_file(str(child))
        assert result is not None


class TestLoadConfig:
    def test_load_valid(self, tmp_path):
        config_file = tmp_path / "config.json"
        config_file.write_text('{"format":"pretty","level":"warn"}')
        config = load_config(str(config_file))
        assert config.format == "pretty"
        assert config.level == "warn"

    def test_load_invalid_json(self, tmp_path):
        config_file = tmp_path / "config.json"
        config_file.write_text('not valid json')
        config = load_config(str(config_file))
        assert config.format == "compact"  # defaults

    def test_load_nonexistent(self):
        config = load_config("/nonexistent/config.json")
        assert config.format == "compact"

    def test_load_none(self):
        config = load_config(None)
        assert isinstance(config, LogpilotConfig)


class TestSaveConfig:
    def test_save_and_load(self, tmp_path):
        config = LogpilotConfig(format="pretty", level="error")
        path = str(tmp_path / "config.json")
        save_config(config, path)

        loaded = load_config(path)
        assert loaded.format == "pretty"
        assert loaded.level == "error"


class TestGenerateDefault:
    def test_valid_json(self):
        content = generate_default_config()
        data = json.loads(content)
        assert "format" in data
        assert "profiles" in data
