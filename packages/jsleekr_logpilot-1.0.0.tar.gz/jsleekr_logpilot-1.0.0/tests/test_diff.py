"""Tests for logpilot.diff."""

import pytest
from datetime import datetime, timezone

from logpilot.diff import (
    compare_by_message,
    compare_levels,
    compare_error_patterns,
    format_diff_summary,
    LogDiff,
    LevelDiff,
)
from logpilot.models import LogEntry, LogLevel


def _set_a() -> list[LogEntry]:
    return [
        LogEntry(raw="", level=LogLevel.INFO, message="startup", is_json=True,
                 timestamp=datetime(2024, 1, 1, tzinfo=timezone.utc), data={}),
        LogEntry(raw="", level=LogLevel.ERROR, message="connection failed", is_json=True,
                 timestamp=datetime(2024, 1, 1, 0, 1, tzinfo=timezone.utc), data={}),
        LogEntry(raw="", level=LogLevel.INFO, message="request handled", is_json=True,
                 timestamp=datetime(2024, 1, 1, 0, 2, tzinfo=timezone.utc), data={}),
    ]


def _set_b() -> list[LogEntry]:
    return [
        LogEntry(raw="", level=LogLevel.INFO, message="startup", is_json=True,
                 timestamp=datetime(2024, 1, 2, tzinfo=timezone.utc), data={}),
        LogEntry(raw="", level=LogLevel.ERROR, message="timeout error", is_json=True,
                 timestamp=datetime(2024, 1, 2, 0, 1, tzinfo=timezone.utc), data={}),
        LogEntry(raw="", level=LogLevel.WARN, message="slow query", is_json=True,
                 timestamp=datetime(2024, 1, 2, 0, 2, tzinfo=timezone.utc), data={}),
    ]


class TestLogDiff:
    def test_total_changes(self):
        diff = LogDiff(
            only_in_a=[LogEntry(raw="", message="a")],
            only_in_b=[LogEntry(raw="", message="b"), LogEntry(raw="", message="c")],
        )
        assert diff.total_changes == 3

    def test_similarity_identical(self):
        diff = LogDiff(common=[(LogEntry(raw="", message="a"), LogEntry(raw="", message="a"))])
        assert diff.similarity == 1.0

    def test_similarity_no_overlap(self):
        diff = LogDiff(
            only_in_a=[LogEntry(raw="", message="a")],
            only_in_b=[LogEntry(raw="", message="b")],
        )
        assert diff.similarity == 0.0

    def test_similarity_empty(self):
        diff = LogDiff()
        assert diff.similarity == 1.0


class TestLevelDiff:
    def test_delta(self):
        ld = LevelDiff(level="ERROR", count_a=10, count_b=15)
        assert ld.delta == 5

    def test_delta_pct(self):
        ld = LevelDiff(level="ERROR", count_a=100, count_b=150)
        assert ld.delta_pct == 50.0

    def test_delta_pct_from_zero(self):
        ld = LevelDiff(level="ERROR", count_a=0, count_b=5)
        assert ld.delta_pct == 100.0


class TestCompareByMessage:
    def test_compare(self):
        diff = compare_by_message(_set_a(), _set_b())
        assert len(diff.common) == 1  # "startup" is common
        assert len(diff.only_in_a) == 2  # connection failed, request handled
        assert len(diff.only_in_b) == 2  # timeout error, slow query

    def test_identical(self):
        entries = _set_a()
        diff = compare_by_message(entries, entries)
        assert len(diff.only_in_a) == 0
        assert len(diff.only_in_b) == 0

    def test_empty(self):
        diff = compare_by_message([], [])
        assert diff.similarity == 1.0


class TestCompareLevels:
    def test_level_comparison(self):
        diffs = compare_levels(_set_a(), _set_b())
        levels = {d.level for d in diffs}
        assert "INFO" in levels
        assert "ERROR" in levels

    def test_new_level(self):
        diffs = compare_levels(_set_a(), _set_b())
        warn_diff = next(d for d in diffs if d.level == "WARN")
        assert warn_diff.count_a == 0
        assert warn_diff.count_b == 1


class TestCompareErrorPatterns:
    def test_new_and_resolved(self):
        result = compare_error_patterns(_set_a(), _set_b())
        assert "connection failed" in result["resolved_errors"]
        assert "timeout error" in result["new_errors"]
        assert result["new_count"] == 1
        assert result["resolved_count"] == 1

    def test_empty(self):
        result = compare_error_patterns([], [])
        assert result["new_count"] == 0
        assert result["resolved_count"] == 0


class TestFormatDiffSummary:
    def test_format(self):
        diff = compare_by_message(_set_a(), _set_b())
        output = format_diff_summary(diff)
        assert "Log Diff Summary" in output
        assert "Similarity" in output
