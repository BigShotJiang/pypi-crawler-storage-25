"""Tests for logpilot.merge."""

import pytest
from datetime import datetime, timezone, timedelta

from logpilot.merge import (
    load_multiple_files,
    merge_sorted,
    interleave_files,
    file_summary,
    split_by_source,
    FileSource,
)
from logpilot.models import LogEntry, LogLevel


class TestFileSource:
    def test_json_ratio(self):
        source = FileSource(path="/test.log", name="test.log", entry_count=100, json_count=80)
        assert source.json_ratio == 0.8

    def test_json_ratio_zero(self):
        source = FileSource(path="/test.log", name="test.log", entry_count=0)
        assert source.json_ratio == 0.0


class TestMergeSorted:
    def test_sort_by_timestamp(self):
        base = datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc)
        entries = [
            LogEntry(raw="", message="third", timestamp=base + timedelta(seconds=2)),
            LogEntry(raw="", message="first", timestamp=base),
            LogEntry(raw="", message="second", timestamp=base + timedelta(seconds=1)),
        ]
        result = merge_sorted(entries)
        assert result[0].message == "first"
        assert result[1].message == "second"
        assert result[2].message == "third"

    def test_untimed_at_end(self):
        base = datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc)
        entries = [
            LogEntry(raw="", message="no time"),
            LogEntry(raw="", message="has time", timestamp=base),
        ]
        result = merge_sorted(entries)
        assert result[0].message == "has time"
        assert result[1].message == "no time"


class TestInterleaveFiles:
    def test_interleave(self):
        base = datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc)
        file_entries = {
            "app.log": [
                LogEntry(raw="", message="app1", timestamp=base),
                LogEntry(raw="", message="app2", timestamp=base + timedelta(seconds=2)),
            ],
            "db.log": [
                LogEntry(raw="", message="db1", timestamp=base + timedelta(seconds=1)),
            ],
        }
        result = interleave_files(file_entries)
        assert len(result) == 3
        assert result[0].message == "app1"
        assert result[1].message == "db1"
        assert result[2].message == "app2"

    def test_file_tag(self):
        file_entries = {
            "app.log": [LogEntry(raw="", message="test")],
        }
        result = interleave_files(file_entries)
        assert result[0].extra["_file"] == "app.log"


class TestLoadMultipleFiles:
    def test_load_with_temp_files(self, tmp_path):
        f1 = tmp_path / "app.log"
        f2 = tmp_path / "worker.log"
        f1.write_text('{"level":"info","msg":"from app"}\n')
        f2.write_text('{"level":"error","msg":"from worker"}\n')

        entries = load_multiple_files([str(f1), str(f2)])
        assert len(entries) == 2
        sources = {e.source for e in entries}
        assert "app.log" in sources
        assert "worker.log" in sources

    def test_nonexistent_file(self):
        entries = load_multiple_files(["/nonexistent/file.log"])
        assert len(entries) == 0

    def test_tag_source(self, tmp_path):
        f = tmp_path / "test.log"
        f.write_text('{"level":"info","msg":"hello"}\n')
        entries = load_multiple_files([str(f)], tag_source=True)
        assert entries[0].source == "test.log"

    def test_no_tag_source(self, tmp_path):
        f = tmp_path / "test.log"
        f.write_text('{"level":"info","msg":"hello","source":"custom"}\n')
        entries = load_multiple_files([str(f)], tag_source=True)
        assert entries[0].source == "custom"


class TestFileSummary:
    def test_summary(self, tmp_path):
        f = tmp_path / "test.log"
        f.write_text('{"level":"info","msg":"ok"}\n{"level":"error","msg":"fail"}\nplain text\n')
        summaries = file_summary([str(f)])
        assert len(summaries) == 1
        assert summaries[0].entry_count == 3
        assert summaries[0].json_count == 2
        assert summaries[0].error_count == 1

    def test_nonexistent(self):
        summaries = file_summary(["/nonexistent.log"])
        assert len(summaries) == 1
        assert summaries[0].entry_count == 0


class TestSplitBySource:
    def test_split(self):
        entries = [
            LogEntry(raw="", source="api", message="a"),
            LogEntry(raw="", source="api", message="b"),
            LogEntry(raw="", source="worker", message="c"),
        ]
        result = split_by_source(entries)
        assert len(result["api"]) == 2
        assert len(result["worker"]) == 1
