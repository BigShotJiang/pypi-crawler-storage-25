"""Tests for logpilot.validators."""

import pytest
from datetime import datetime, timezone

from logpilot.validators import validate_entries, ValidationReport, ValidationIssue
from logpilot.models import LogEntry, LogLevel


class TestValidateEntries:
    def test_all_valid(self):
        entries = [
            LogEntry(raw="", level=LogLevel.INFO, message="ok",
                     timestamp=datetime(2024, 1, 1, tzinfo=timezone.utc),
                     is_json=True),
        ]
        report = validate_entries(entries)
        assert report.entries_checked == 1
        assert not report.has_errors

    def test_missing_timestamp(self):
        entries = [
            LogEntry(raw="", level=LogLevel.INFO, message="no ts", is_json=True),
        ]
        report = validate_entries(entries, rules=["missing_timestamp"])
        issues = report.by_rule("missing_timestamp")
        assert len(issues) >= 1

    def test_missing_message(self):
        entries = [
            LogEntry(raw="", level=LogLevel.INFO, message="", is_json=True),
        ]
        report = validate_entries(entries, rules=["missing_message"])
        issues = report.by_rule("missing_message")
        assert len(issues) >= 1

    def test_non_json(self):
        entries = [
            LogEntry(raw="plain text", message="plain text", is_json=False),
            LogEntry(raw='{"msg":"json"}', message="json", is_json=True),
        ]
        report = validate_entries(entries, rules=["non_json"])
        issues = report.by_rule("non_json")
        assert len(issues) == 1
        assert "50.0%" in issues[0].message

    def test_high_error_rate(self):
        entries = [
            LogEntry(raw="", level=LogLevel.ERROR, message=f"err {i}")
            for i in range(8)
        ] + [
            LogEntry(raw="", level=LogLevel.INFO, message=f"ok {i}")
            for i in range(2)
        ]
        report = validate_entries(entries, rules=["high_error_rate"])
        issues = report.by_rule("high_error_rate")
        assert len(issues) == 1
        assert issues[0].severity == "error"  # 80% > 50%

    def test_moderate_error_rate(self):
        entries = [
            LogEntry(raw="", level=LogLevel.ERROR, message="err")
        ] * 3 + [
            LogEntry(raw="", level=LogLevel.INFO, message="ok")
        ] * 7
        report = validate_entries(entries, rules=["high_error_rate"])
        issues = report.by_rule("high_error_rate")
        assert len(issues) == 1
        assert issues[0].severity == "warning"

    def test_low_error_rate(self):
        entries = [
            LogEntry(raw="", level=LogLevel.ERROR, message="err"),
        ] + [
            LogEntry(raw="", level=LogLevel.INFO, message="ok"),
        ] * 99
        report = validate_entries(entries, rules=["high_error_rate"])
        issues = report.by_rule("high_error_rate")
        assert len(issues) == 0

    def test_duplicate_messages(self):
        entries = [
            LogEntry(raw="", message="repeated message")
            for _ in range(20)
        ]
        report = validate_entries(entries, rules=["duplicate_messages"])
        issues = report.by_rule("duplicate_messages")
        assert len(issues) >= 1


class TestValidationReport:
    def test_by_severity(self):
        report = ValidationReport(issues=[
            ValidationIssue(rule="a", severity="error", message="err"),
            ValidationIssue(rule="b", severity="warning", message="warn"),
            ValidationIssue(rule="c", severity="info", message="info"),
        ])
        assert len(report.by_severity("error")) == 1
        assert len(report.by_severity("warning")) == 1

    def test_has_errors(self):
        report = ValidationReport(issues=[
            ValidationIssue(rule="a", severity="warning", message="warn"),
        ])
        assert not report.has_errors

        report.issues.append(ValidationIssue(rule="b", severity="error", message="err"))
        assert report.has_errors

    def test_issue_count(self):
        report = ValidationReport(issues=[
            ValidationIssue(rule="a", severity="info", message="a"),
            ValidationIssue(rule="b", severity="info", message="b"),
        ])
        assert report.issue_count == 2
