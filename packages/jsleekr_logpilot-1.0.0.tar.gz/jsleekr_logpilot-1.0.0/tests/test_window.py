"""Tests for logpilot.window."""

import pytest
from datetime import datetime, timezone, timedelta

from logpilot.window import (
    fixed_windows,
    sliding_window,
    sessionize,
    peak_window,
    quietest_window,
    TimeWindow,
    Session,
)
from logpilot.models import LogEntry, LogLevel


def _timed(n: int = 20, interval_s: int = 10) -> list[LogEntry]:
    base = datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    return [
        LogEntry(
            raw="", message=f"entry {i}",
            level=LogLevel.ERROR if i == 5 else LogLevel.INFO,
            timestamp=base + timedelta(seconds=i * interval_s),
        )
        for i in range(n)
    ]


class TestTimeWindow:
    def test_count(self):
        w = TimeWindow(
            start=datetime(2024, 1, 1, tzinfo=timezone.utc),
            end=datetime(2024, 1, 1, 0, 1, tzinfo=timezone.utc),
            entries=[LogEntry(raw="", message="a"), LogEntry(raw="", message="b")],
        )
        assert w.count == 2

    def test_error_count(self):
        w = TimeWindow(
            start=datetime(2024, 1, 1, tzinfo=timezone.utc),
            end=datetime(2024, 1, 1, 0, 1, tzinfo=timezone.utc),
            entries=[
                LogEntry(raw="", message="", level=LogLevel.INFO),
                LogEntry(raw="", message="", level=LogLevel.ERROR),
            ],
        )
        assert w.error_count == 1

    def test_duration(self):
        w = TimeWindow(
            start=datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc),
            end=datetime(2024, 1, 1, 12, 5, tzinfo=timezone.utc),
        )
        assert w.duration_seconds == 300.0


class TestSession:
    def test_duration(self):
        base = datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc)
        s = Session(entries=[
            LogEntry(raw="", message="", timestamp=base),
            LogEntry(raw="", message="", timestamp=base + timedelta(seconds=30)),
        ])
        assert s.duration_seconds == 30.0
        assert s.count == 2


class TestFixedWindows:
    def test_creates_windows(self):
        entries = _timed(20, interval_s=10)
        windows = fixed_windows(entries, window_seconds=60)
        assert len(windows) >= 3
        total = sum(w.count for w in windows)
        assert total == 20

    def test_empty(self):
        assert fixed_windows([]) == []

    def test_no_timestamps(self):
        entries = [LogEntry(raw="", message="no ts")]
        assert fixed_windows(entries) == []


class TestSlidingWindow:
    def test_creates_overlapping_windows(self):
        entries = _timed(10, interval_s=10)
        windows = sliding_window(entries, window_seconds=60, step_seconds=30)
        assert len(windows) >= 2

    def test_empty(self):
        assert sliding_window([]) == []


class TestSessionize:
    def test_single_session(self):
        entries = _timed(10, interval_s=10)
        sessions = sessionize(entries, gap_seconds=300)
        assert len(sessions) == 1
        assert sessions[0].count == 10

    def test_multiple_sessions(self):
        base = datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc)
        entries = [
            LogEntry(raw="", message="a", timestamp=base),
            LogEntry(raw="", message="b", timestamp=base + timedelta(seconds=10)),
            # Big gap
            LogEntry(raw="", message="c", timestamp=base + timedelta(minutes=10)),
            LogEntry(raw="", message="d", timestamp=base + timedelta(minutes=10, seconds=5)),
        ]
        sessions = sessionize(entries, gap_seconds=60)
        assert len(sessions) == 2
        assert sessions[0].count == 2
        assert sessions[1].count == 2

    def test_empty(self):
        assert sessionize([]) == []


class TestPeakQuietest:
    def test_peak_window(self):
        entries = _timed(20, interval_s=10)
        peak = peak_window(entries, window_seconds=60)
        assert peak is not None
        assert peak.count > 0

    def test_quietest_window(self):
        entries = _timed(20, interval_s=10)
        quietest = quietest_window(entries, window_seconds=60)
        assert quietest is not None

    def test_peak_empty(self):
        assert peak_window([]) is None

    def test_quietest_empty(self):
        assert quietest_window([]) is None
