"""Tests for logpilot.exporter."""

import json
import pytest
from datetime import datetime, timezone

from logpilot.exporter import (
    export_json,
    export_jsonl,
    export_csv,
    export_stats_json,
    export_markdown_table,
)
from logpilot.models import LogEntry, LogLevel, LogStats


def _entries() -> list[LogEntry]:
    return [
        LogEntry(
            raw="",
            level=LogLevel.INFO,
            message="request handled",
            source="api",
            timestamp=datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc),
            extra={"method": "GET", "status": 200},
        ),
        LogEntry(
            raw="",
            level=LogLevel.ERROR,
            message="connection failed",
            source="worker",
            timestamp=datetime(2024, 1, 1, 12, 1, tzinfo=timezone.utc),
            extra={"error_code": "ECONNREFUSED"},
        ),
    ]


class TestExportJson:
    def test_json_array(self):
        result = export_json(_entries())
        parsed = json.loads(result)
        assert isinstance(parsed, list)
        assert len(parsed) == 2

    def test_json_pretty(self):
        result = export_json(_entries(), pretty=True)
        assert "\n" in result
        parsed = json.loads(result)
        assert len(parsed) == 2

    def test_empty(self):
        result = export_json([])
        assert json.loads(result) == []


class TestExportJsonl:
    def test_jsonl_format(self):
        result = export_jsonl(_entries())
        lines = result.strip().split("\n")
        assert len(lines) == 2
        for line in lines:
            parsed = json.loads(line)
            assert "message" in parsed

    def test_empty(self):
        result = export_jsonl([])
        assert result == ""


class TestExportCsv:
    def test_csv_output(self):
        result = export_csv(_entries())
        lines = result.strip().split("\n")
        assert len(lines) >= 3  # header + 2 data rows
        assert "timestamp" in lines[0]
        assert "level" in lines[0]

    def test_csv_custom_fields(self):
        result = export_csv(_entries(), fields=["level", "message"])
        lines = result.strip().split("\n")
        assert "level" in lines[0]
        assert "message" in lines[0]
        assert "timestamp" not in lines[0]

    def test_csv_empty(self):
        result = export_csv([])
        assert result == ""


class TestExportStatsJson:
    def test_stats_json(self):
        stats = LogStats(
            total=100,
            by_level={"INFO": 70, "ERROR": 30},
            parse_errors=5,
            unique_fields={"method", "status"},
        )
        result = export_stats_json(stats)
        parsed = json.loads(result)
        assert parsed["total"] == 100
        assert parsed["error_rate"] == 30.0
        assert "method" in parsed["unique_fields"]


class TestExportMarkdown:
    def test_markdown_table(self):
        result = export_markdown_table(_entries())
        lines = result.split("\n")
        assert lines[0].startswith("|")
        assert "---" in lines[1]
        assert len(lines) >= 4

    def test_markdown_custom_fields(self):
        result = export_markdown_table(_entries(), fields=["level", "message"])
        assert "level" in result
        assert "message" in result

    def test_markdown_empty(self):
        result = export_markdown_table([])
        assert result == ""
