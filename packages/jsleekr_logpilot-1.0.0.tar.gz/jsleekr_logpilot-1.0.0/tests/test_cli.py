"""Tests for logpilot.cli."""

import pytest
import tempfile
import os

from logpilot.cli import create_parser, main


@pytest.fixture
def log_file(tmp_path):
    """Create a temporary log file."""
    content = """{"timestamp":"2024-01-01T12:00:00Z","level":"info","msg":"Server started","port":8080}
{"timestamp":"2024-01-01T12:00:01Z","level":"info","msg":"Request handled","method":"GET","path":"/api"}
{"timestamp":"2024-01-01T12:00:02Z","level":"warn","msg":"Slow query","duration_ms":500}
{"timestamp":"2024-01-01T12:00:03Z","level":"error","msg":"Connection failed","status":503}
{"timestamp":"2024-01-01T12:00:04Z","level":"error","msg":"Timeout error","retry":3}
{"timestamp":"2024-01-01T12:00:05Z","level":"info","msg":"Request handled","method":"POST","path":"/api/users"}
"""
    filepath = tmp_path / "test.log"
    filepath.write_text(content)
    return str(filepath)


class TestCreateParser:
    def test_parser_exists(self):
        parser = create_parser()
        assert parser is not None

    def test_default_args(self):
        parser = create_parser()
        args = parser.parse_args([])
        assert args.file is None
        assert args.level is None
        assert args.format == "compact"
        assert args.no_color is False


class TestMainFunction:
    def test_view_file(self, log_file, capsys):
        exit_code = main([log_file, "--no-color"])
        assert exit_code == 0
        captured = capsys.readouterr()
        assert "Server started" in captured.out

    def test_level_filter(self, log_file, capsys):
        main([log_file, "--level", "error", "--no-color"])
        captured = capsys.readouterr()
        assert "Connection failed" in captured.out
        assert "Server started" not in captured.out

    def test_search_filter(self, log_file, capsys):
        main([log_file, "--search", "timeout", "--no-color"])
        captured = capsys.readouterr()
        assert "Timeout" in captured.out
        assert "Server started" not in captured.out

    def test_source_filter(self, log_file, capsys):
        # No source field in our test data, but test the flag works
        main([log_file, "--no-color"])
        captured = capsys.readouterr()
        assert len(captured.out) > 0

    def test_json_format(self, log_file, capsys):
        main([log_file, "--format", "json", "--head", "1"])
        captured = capsys.readouterr()
        import json
        parsed = json.loads(captured.out.strip())
        assert "level" in parsed

    def test_raw_format(self, log_file, capsys):
        main([log_file, "--format", "raw", "--head", "1"])
        captured = capsys.readouterr()
        assert captured.out.strip().startswith("{")

    def test_head_limit(self, log_file, capsys):
        main([log_file, "--head", "2", "--no-color"])
        captured = capsys.readouterr()
        lines = [l for l in captured.out.strip().split("\n") if l.strip()]
        assert len(lines) == 2

    def test_tail_limit(self, log_file, capsys):
        main([log_file, "--tail", "2", "--no-color"])
        captured = capsys.readouterr()
        assert "Request handled" in captured.out or "POST" in captured.out

    def test_stats_mode(self, log_file, capsys):
        main([log_file, "--stats", "--no-color"])
        captured = capsys.readouterr()
        assert "Total entries" in captured.out
        assert "By Level" in captured.out

    def test_query_mode(self, log_file, capsys):
        main([log_file, "--query", "level:error", "--no-color"])
        captured = capsys.readouterr()
        assert "failed" in captured.out.lower() or "error" in captured.out.lower()

    def test_export_json(self, log_file, capsys):
        main([log_file, "--export", "json"])
        captured = capsys.readouterr()
        import json
        data = json.loads(captured.out)
        assert isinstance(data, list)
        assert len(data) == 6

    def test_export_csv(self, log_file, capsys):
        main([log_file, "--export", "csv"])
        captured = capsys.readouterr()
        lines = captured.out.strip().split("\n")
        assert len(lines) >= 7  # header + 6 entries

    def test_export_to_file(self, log_file, tmp_path):
        output_file = str(tmp_path / "output.json")
        main([log_file, "--export", "json", "--output", output_file])
        assert os.path.exists(output_file)
        import json
        with open(output_file) as f:
            data = json.load(f)
        assert len(data) == 6

    def test_grep_filter(self, log_file, capsys):
        main([log_file, "--grep", "503", "--no-color"])
        captured = capsys.readouterr()
        assert "503" in captured.out

    def test_pretty_format(self, log_file, capsys):
        main([log_file, "--format", "pretty", "--head", "1", "--no-color"])
        captured = capsys.readouterr()
        assert "Server started" in captured.out

    def test_top_messages(self, log_file, capsys):
        main([log_file, "--top-messages", "--no-color"])
        captured = capsys.readouterr()
        assert "Request handled" in captured.out

    def test_anomalies(self, log_file, capsys):
        main([log_file, "--anomalies", "--no-color"])
        captured = capsys.readouterr()
        assert "Anomaly Report" in captured.out
