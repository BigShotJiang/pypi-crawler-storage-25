"""Tests for logpilot.pipeline."""

import pytest
from datetime import datetime, timezone

from logpilot.pipeline import Pipeline
from logpilot.models import LogEntry, LogLevel, FilterConfig


def _entries() -> list[LogEntry]:
    return [
        LogEntry(raw="1", level=LogLevel.DEBUG, message="debug msg",
                 source="api", data={"status": "200"}, extra={"status": "200"},
                 timestamp=datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc)),
        LogEntry(raw="2", level=LogLevel.INFO, message="info msg",
                 source="api", data={"status": "200"}, extra={"status": "200"},
                 timestamp=datetime(2024, 1, 1, 12, 1, tzinfo=timezone.utc)),
        LogEntry(raw="3", level=LogLevel.WARN, message="warn timeout",
                 source="worker", data={"status": "408"}, extra={"status": "408"},
                 timestamp=datetime(2024, 1, 1, 12, 2, tzinfo=timezone.utc)),
        LogEntry(raw="4", level=LogLevel.ERROR, message="error failed",
                 source="api", data={"status": "500"}, extra={"status": "500"},
                 timestamp=datetime(2024, 1, 1, 12, 3, tzinfo=timezone.utc)),
    ]


class TestPipeline:
    def test_no_filters(self):
        result = Pipeline(_entries()).execute()
        assert len(result) == 4

    def test_filter_level(self):
        result = Pipeline(_entries()).filter_level(LogLevel.WARN).execute()
        assert len(result) == 2

    def test_filter_source(self):
        result = Pipeline(_entries()).filter_source("api").execute()
        assert len(result) == 3

    def test_search(self):
        result = Pipeline(_entries()).search("timeout").execute()
        assert len(result) == 1

    def test_grep(self):
        result = Pipeline(_entries()).grep(r"\d").execute()
        assert len(result) == 4

    def test_filter_field(self):
        result = Pipeline(_entries()).filter_field("status", "500").execute()
        assert len(result) == 1

    def test_has_field(self):
        entries = _entries() + [LogEntry(raw="5", level=LogLevel.INFO, message="no status")]
        result = Pipeline(entries).has_field("status").execute()
        assert len(result) == 4

    def test_json_only(self):
        entries = _entries() + [LogEntry(raw="plain", message="plain", is_json=False)]
        result = Pipeline(entries).json_only().execute()
        # _entries() don't set is_json, so they default to False
        assert all(e.is_json for e in result) or len(result) == 0

    def test_chained_filters(self):
        result = (
            Pipeline(_entries())
            .filter_level(LogLevel.WARN)
            .filter_source("api")
            .execute()
        )
        assert len(result) == 1
        assert result[0].level == LogLevel.ERROR

    def test_sort_by_level(self):
        result = Pipeline(_entries()).sort_by("level", reverse=True).execute()
        assert result[0].level == LogLevel.ERROR
        assert result[-1].level == LogLevel.DEBUG

    def test_sort_by_timestamp(self):
        result = Pipeline(_entries()).sort_by("timestamp", reverse=True).execute()
        assert result[0].timestamp > result[-1].timestamp

    def test_limit(self):
        result = Pipeline(_entries()).limit(2).execute()
        assert len(result) == 2

    def test_offset(self):
        result = Pipeline(_entries()).offset(2).execute()
        assert len(result) == 2
        assert result[0].raw == "3"

    def test_tail(self):
        result = Pipeline(_entries()).tail(1).execute()
        assert len(result) == 1
        assert result[0].raw == "4"

    def test_count(self):
        count = Pipeline(_entries()).filter_level(LogLevel.WARN).count()
        assert count == 2

    def test_first(self):
        entry = Pipeline(_entries()).first()
        assert entry is not None
        assert entry.raw == "1"

    def test_last(self):
        entry = Pipeline(_entries()).last()
        assert entry is not None
        assert entry.raw == "4"

    def test_first_empty(self):
        entry = Pipeline([]).first()
        assert entry is None

    def test_transform_add_field(self):
        result = Pipeline(_entries()).add_field("env", "prod").execute()
        assert all(e.extra.get("env") == "prod" for e in result)

    def test_transform_remove_field(self):
        result = Pipeline(_entries()).remove_field("status").execute()
        assert all("status" not in e.extra for e in result)

    def test_custom_filter(self):
        result = Pipeline(_entries()).filter(lambda e: len(e.message) > 10).execute()
        assert all(len(e.message) > 10 for e in result)

    def test_custom_transform(self):
        def upper_msg(e: LogEntry) -> LogEntry:
            e.message = e.message.upper()
            return e
        result = Pipeline(_entries()).transform(upper_msg).execute()
        assert all(e.message.isupper() for e in result)

    def test_apply_config(self):
        config = FilterConfig(min_level=LogLevel.ERROR)
        result = Pipeline(_entries()).apply_config(config).execute()
        assert len(result) == 1

    def test_transform_drop_entry(self):
        def drop_debug(e: LogEntry) -> LogEntry | None:
            return None if e.level == LogLevel.DEBUG else e
        result = Pipeline(_entries()).transform(drop_debug).execute()
        assert len(result) == 3
