"""Tests for logpilot.filter."""

import pytest
from datetime import datetime, timezone

from logpilot.filter import (
    apply_filter,
    filter_by_level,
    filter_by_source,
    filter_by_search,
    filter_by_regex,
    filter_by_field_exists,
    filter_by_field_value,
    exclude_by_field,
    unique_by_field,
    sample_entries,
    tail_entries,
    head_entries,
)
from logpilot.models import FilterConfig, LogEntry, LogLevel


def _make_entries() -> list[LogEntry]:
    """Create sample entries for testing."""
    return [
        LogEntry(raw="1", level=LogLevel.DEBUG, message="debug msg", source="api",
                 data={"method": "GET"}, extra={"method": "GET"}, is_json=True),
        LogEntry(raw="2", level=LogLevel.INFO, message="info msg", source="api",
                 data={"method": "POST"}, extra={"method": "POST"}, is_json=True),
        LogEntry(raw="3", level=LogLevel.WARN, message="warn timeout", source="worker",
                 data={"duration": "500"}, extra={"duration": "500"}, is_json=True),
        LogEntry(raw="4", level=LogLevel.ERROR, message="error connection failed", source="api",
                 data={"status": "503"}, extra={"status": "503"}, is_json=True),
        LogEntry(raw="5", level=LogLevel.FATAL, message="fatal crash", source="worker",
                 data={}, extra={}, is_json=True),
    ]


class TestFilterByLevel:
    def test_filter_warn_and_above(self):
        entries = _make_entries()
        result = filter_by_level(entries, LogLevel.WARN)
        assert len(result) == 3
        assert all(e.level >= LogLevel.WARN for e in result)

    def test_filter_error_only(self):
        entries = _make_entries()
        result = filter_by_level(entries, LogLevel.ERROR)
        assert len(result) == 2

    def test_filter_trace_returns_all(self):
        entries = _make_entries()
        result = filter_by_level(entries, LogLevel.TRACE)
        assert len(result) == 5


class TestFilterBySource:
    def test_filter_api(self):
        entries = _make_entries()
        result = filter_by_source(entries, "api")
        assert len(result) == 3

    def test_filter_worker(self):
        entries = _make_entries()
        result = filter_by_source(entries, "worker")
        assert len(result) == 2

    def test_filter_unknown_source(self):
        entries = _make_entries()
        result = filter_by_source(entries, "unknown")
        assert len(result) == 0


class TestFilterBySearch:
    def test_search_timeout(self):
        entries = _make_entries()
        result = filter_by_search(entries, "timeout")
        assert len(result) == 1
        assert result[0].level == LogLevel.WARN

    def test_search_case_insensitive(self):
        entries = _make_entries()
        result = filter_by_search(entries, "TIMEOUT")
        assert len(result) == 1

    def test_search_partial(self):
        entries = _make_entries()
        result = filter_by_search(entries, "msg")
        assert len(result) == 2  # debug msg, info msg


class TestFilterByRegex:
    def test_regex_pattern(self):
        entries = _make_entries()
        result = filter_by_regex(entries, r"\d+")
        assert len(result) == 5  # all have numbers in raw

    def test_regex_specific(self):
        entries = [
            LogEntry(raw='{"status":200}', message="ok"),
            LogEntry(raw='{"status":500}', message="error"),
        ]
        result = filter_by_regex(entries, r"500")
        assert len(result) == 1


class TestFilterByField:
    def test_field_exists(self):
        entries = _make_entries()
        result = filter_by_field_exists(entries, "method")
        assert len(result) == 2

    def test_field_value(self):
        entries = _make_entries()
        result = filter_by_field_value(entries, "method", "GET")
        assert len(result) == 1

    def test_exclude_field(self):
        entries = _make_entries()
        result = exclude_by_field(entries, "method")
        assert len(result) == 3


class TestUniqueByField:
    def test_unique_by_method(self):
        entries = _make_entries()
        result = unique_by_field(entries, "method")
        methods = [e.get("method") for e in result]
        assert "GET" in methods
        assert "POST" in methods
        assert len(result) >= 2  # GET, POST, and entries without method


class TestHeadTail:
    def test_head(self):
        entries = _make_entries()
        result = head_entries(entries, 2)
        assert len(result) == 2
        assert result[0].raw == "1"

    def test_tail(self):
        entries = _make_entries()
        result = tail_entries(entries, 2)
        assert len(result) == 2
        assert result[-1].raw == "5"

    def test_head_zero(self):
        entries = _make_entries()
        assert head_entries(entries, 0) == []

    def test_tail_zero(self):
        entries = _make_entries()
        assert tail_entries(entries, 0) == []

    def test_head_larger_than_list(self):
        entries = _make_entries()
        result = head_entries(entries, 100)
        assert len(result) == 5


class TestSample:
    def test_sample(self):
        entries = _make_entries()
        result = sample_entries(entries, 2)
        assert len(result) <= 3  # approximate

    def test_sample_larger_than_list(self):
        entries = _make_entries()
        result = sample_entries(entries, 100)
        assert len(result) == 5


class TestApplyFilter:
    def test_apply_filter_config(self):
        config = FilterConfig(min_level=LogLevel.WARN, search="timeout")
        entries = _make_entries()
        result = apply_filter(entries, config)
        assert len(result) == 1
        assert result[0].message == "warn timeout"
