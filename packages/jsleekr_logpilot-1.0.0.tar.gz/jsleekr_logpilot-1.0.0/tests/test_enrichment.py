"""Tests for logpilot.enrichment."""

import pytest

from logpilot.enrichment import (
    Enricher,
    classify_http_status,
    extract_http_method,
    calculate_response_time_bucket,
    tag_error_severity,
    create_default_enricher,
)
from logpilot.models import LogEntry, LogLevel


class TestClassifyHttpStatus:
    def test_success(self):
        entry = LogEntry(raw="", message="", data={"statusCode": 200})
        result = classify_http_status(entry)
        assert result["http_category"] == "success"

    def test_client_error(self):
        entry = LogEntry(raw="", message="", data={"status": "404"})
        result = classify_http_status(entry)
        assert result["http_category"] == "client_error"

    def test_server_error(self):
        entry = LogEntry(raw="", message="", data={"status_code": "500"})
        result = classify_http_status(entry)
        assert result["http_category"] == "server_error"

    def test_redirect(self):
        entry = LogEntry(raw="", message="", data={"statusCode": 302})
        result = classify_http_status(entry)
        assert result["http_category"] == "redirect"

    def test_no_status(self):
        entry = LogEntry(raw="", message="", data={})
        result = classify_http_status(entry)
        assert result == {}


class TestExtractHttpMethod:
    def test_extract_get(self):
        entry = LogEntry(raw="", message="GET /api/users returned 200", data={})
        result = extract_http_method(entry)
        assert result["_http_method"] == "GET"

    def test_extract_post(self):
        entry = LogEntry(raw="", message="POST /api/orders", data={})
        result = extract_http_method(entry)
        assert result["_http_method"] == "POST"

    def test_already_has_method(self):
        entry = LogEntry(raw="", message="GET /api", data={"method": "GET"})
        result = extract_http_method(entry)
        assert result == {}

    def test_no_method(self):
        entry = LogEntry(raw="", message="Server started", data={})
        result = extract_http_method(entry)
        assert result == {}


class TestCalculateResponseTimeBucket:
    def test_fast(self):
        entry = LogEntry(raw="", message="", data={"responseTime": 50})
        result = calculate_response_time_bucket(entry)
        assert result["response_time_bucket"] == "fast"

    def test_normal(self):
        entry = LogEntry(raw="", message="", data={"duration_ms": "200"})
        result = calculate_response_time_bucket(entry)
        assert result["response_time_bucket"] == "normal"

    def test_slow(self):
        entry = LogEntry(raw="", message="", data={"response_time": 1500})
        result = calculate_response_time_bucket(entry)
        assert result["response_time_bucket"] == "slow"

    def test_very_slow(self):
        entry = LogEntry(raw="", message="", data={"duration_ms": 5000})
        result = calculate_response_time_bucket(entry)
        assert result["response_time_bucket"] == "very_slow"

    def test_no_response_time(self):
        entry = LogEntry(raw="", message="", data={})
        result = calculate_response_time_bucket(entry)
        assert result == {}


class TestTagErrorSeverity:
    def test_critical(self):
        entry = LogEntry(raw="", level=LogLevel.ERROR, message="Out of memory crash")
        result = tag_error_severity(entry)
        assert result["error_severity"] == "critical"

    def test_infrastructure(self):
        entry = LogEntry(raw="", level=LogLevel.ERROR, message="Connection timeout to db")
        result = tag_error_severity(entry)
        assert result["error_severity"] == "infrastructure"

    def test_security(self):
        entry = LogEntry(raw="", level=LogLevel.ERROR, message="Unauthorized access attempt")
        result = tag_error_severity(entry)
        assert result["error_severity"] == "security"

    def test_user_input(self):
        entry = LogEntry(raw="", level=LogLevel.ERROR, message="Invalid email format")
        result = tag_error_severity(entry)
        assert result["error_severity"] == "user_input"

    def test_generic(self):
        entry = LogEntry(raw="", level=LogLevel.ERROR, message="Something went wrong")
        result = tag_error_severity(entry)
        assert result["error_severity"] == "application"

    def test_not_error(self):
        entry = LogEntry(raw="", level=LogLevel.INFO, message="ok")
        result = tag_error_severity(entry)
        assert result == {}


class TestEnricher:
    def test_add_rule_and_enrich(self):
        enricher = Enricher()
        enricher.add_rule("custom", lambda e: {"custom_field": "hello"})
        entry = LogEntry(raw="", message="test")
        result = enricher.enrich(entry)
        assert result.extra["custom_field"] == "hello"

    def test_multiple_rules(self):
        enricher = Enricher()
        enricher.add_rule("a", lambda e: {"field_a": 1})
        enricher.add_rule("b", lambda e: {"field_b": 2})
        result = enricher.enrich(LogEntry(raw="", message=""))
        assert result.extra["field_a"] == 1
        assert result.extra["field_b"] == 2

    def test_enrich_all(self):
        enricher = Enricher()
        enricher.add_rule("tag", lambda e: {"tagged": True})
        entries = [LogEntry(raw="", message="a"), LogEntry(raw="", message="b")]
        result = enricher.enrich_all(entries)
        assert all(e.extra.get("tagged") for e in result)

    def test_rule_exception_handled(self):
        enricher = Enricher()
        enricher.add_rule("bad", lambda e: 1 / 0)  # type: ignore
        entry = LogEntry(raw="", message="test")
        result = enricher.enrich(entry)
        assert result.message == "test"


class TestDefaultEnricher:
    def test_creates_enricher(self):
        enricher = create_default_enricher()
        entry = LogEntry(raw="", level=LogLevel.ERROR, message="Connection timeout",
                        data={"statusCode": 503, "responseTime": 5000})
        result = enricher.enrich(entry)
        assert result.extra.get("http_category") == "server_error"
        assert result.extra.get("response_time_bucket") == "very_slow"
        assert result.extra.get("error_severity") == "infrastructure"
