"""Edge case tests for robustness."""

import pytest
from datetime import datetime, timezone

from logpilot.parser import parse_line, parse_text
from logpilot.models import LogEntry, LogLevel, LogStats, FilterConfig
from logpilot.pipeline import Pipeline
from logpilot.query import execute_query, tokenize
from logpilot.formatter import format_compact, format_pretty, OutputFormatter
from logpilot.analyzer import compute_stats, cluster_errors
from logpilot.exporter import export_json, export_csv
from logpilot.highlighter import strip_ansi
from logpilot.fields import flatten_fields, unflatten_fields


class TestParserEdgeCases:
    def test_parse_whitespace_only(self):
        entry = parse_line("   \t  ")
        assert not entry.is_json
        assert entry.message == ""

    def test_parse_very_long_line(self):
        long_msg = "x" * 10000
        line = f'{{"msg":"{long_msg}","level":"info"}}'
        entry = parse_line(line)
        assert entry.is_json
        assert len(entry.message) == 10000

    def test_parse_unicode(self):
        line = '{"msg":"Hello world","level":"info"}'
        entry = parse_line(line)
        assert entry.is_json

    def test_parse_special_characters(self):
        line = '{"msg":"path: C:\\\\Users\\\\test\\\\file.txt","level":"info"}'
        entry = parse_line(line)
        assert entry.is_json

    def test_parse_nested_json_string(self):
        line = '{"msg":"got response: {\\"status\\":200}","level":"info"}'
        entry = parse_line(line)
        assert entry.is_json

    def test_parse_null_values(self):
        line = '{"msg":null,"level":"info"}'
        entry = parse_line(line)
        assert entry.is_json

    def test_parse_boolean_level(self):
        line = '{"msg":"test","level":true}'
        entry = parse_line(line)
        assert entry.is_json

    def test_parse_numeric_message(self):
        line = '{"msg":42,"level":"info"}'
        entry = parse_line(line)
        assert entry.message == "42"

    def test_parse_empty_json(self):
        line = '{}'
        entry = parse_line(line)
        assert entry.is_json
        assert entry.message == ""


class TestFilterEdgeCases:
    def test_filter_with_empty_search(self):
        config = FilterConfig(search="")
        entry = LogEntry(raw="", message="test")
        assert config.matches(entry)

    def test_filter_none_timestamp(self):
        config = FilterConfig(
            since=datetime(2024, 1, 1, tzinfo=timezone.utc),
        )
        entry = LogEntry(raw="", message="no timestamp")
        # Entry with no timestamp passes since/until filters (no timestamp to compare)
        assert config.matches(entry)


class TestPipelineEdgeCases:
    def test_empty_pipeline(self):
        result = Pipeline([]).execute()
        assert result == []

    def test_pipeline_chain_many_filters(self):
        entries = [
            LogEntry(raw="", level=LogLevel.ERROR, message="timeout error",
                     source="api", data={"status": "503"}, extra={"status": "503"}),
        ]
        result = (
            Pipeline(entries)
            .filter_level(LogLevel.WARN)
            .search("timeout")
            .filter_source("api")
            .has_field("status")
            .sort_by("level")
            .limit(10)
            .execute()
        )
        assert len(result) == 1


class TestQueryEdgeCases:
    def test_empty_query_string(self):
        entries = [LogEntry(raw="", message="test")]
        result = execute_query(entries, "")
        assert result.matched == 1

    def test_query_special_characters(self):
        tokens = tokenize("msg:hello world")
        assert len(tokens) >= 1

    def test_query_quoted_value(self):
        tokens = tokenize('msg:"hello world"')
        assert tokens[0].value == "hello world"


class TestFormatterEdgeCases:
    def test_format_entry_no_fields(self):
        entry = LogEntry(raw="", level=LogLevel.INFO, message="")
        result = format_compact(entry, use_color=False)
        assert "INFO" in result

    def test_format_entry_with_dict_extra(self):
        entry = LogEntry(
            raw="", level=LogLevel.INFO, message="test",
            extra={"nested": {"key": "value"}},
        )
        result = format_compact(entry, use_color=False)
        assert "nested" in result

    def test_format_entry_with_list_extra(self):
        entry = LogEntry(
            raw="", level=LogLevel.INFO, message="test",
            extra={"tags": ["a", "b", "c"]},
        )
        result = format_compact(entry, use_color=False)
        assert "tags" in result

    def test_format_pretty_empty_source(self):
        entry = LogEntry(raw="", level=LogLevel.INFO, message="test", source="")
        result = format_pretty(entry, use_color=False)
        assert "test" in result


class TestExporterEdgeCases:
    def test_export_json_with_datetime(self):
        entries = [
            LogEntry(raw="", message="test",
                     timestamp=datetime(2024, 1, 1, tzinfo=timezone.utc)),
        ]
        result = export_json(entries)
        assert "2024" in result

    def test_export_csv_with_special_chars(self):
        entries = [
            LogEntry(raw="", message='hello, "world"', level=LogLevel.INFO),
        ]
        result = export_csv(entries)
        assert "hello" in result


class TestAnalyzerEdgeCases:
    def test_stats_single_entry(self):
        entries = [LogEntry(raw="", level=LogLevel.INFO, message="only one", is_json=True,
                           data={}, timestamp=datetime(2024, 1, 1, tzinfo=timezone.utc))]
        stats = compute_stats(entries)
        assert stats.total == 1
        assert stats.duration_seconds == 0.0  # same first and last timestamp

    def test_cluster_identical_messages(self):
        entries = [
            LogEntry(raw="", level=LogLevel.ERROR, message="Same error message")
            for _ in range(50)
        ]
        clusters = cluster_errors(entries)
        assert len(clusters) == 1
        assert clusters[0].count == 50


class TestFieldsEdgeCases:
    def test_flatten_empty_nested(self):
        result = flatten_fields({"a": {}})
        assert result == {}

    def test_unflatten_single_key(self):
        result = unflatten_fields({"key": "value"})
        assert result == {"key": "value"}


class TestHighlighterEdgeCases:
    def test_strip_ansi_empty(self):
        assert strip_ansi("") == ""

    def test_strip_ansi_only_codes(self):
        assert strip_ansi("\033[31m\033[0m") == ""
