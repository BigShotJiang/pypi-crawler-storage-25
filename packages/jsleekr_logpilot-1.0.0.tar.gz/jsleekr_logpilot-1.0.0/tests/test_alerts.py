"""Tests for logpilot.alerts."""

import pytest

from logpilot.alerts import (
    AlertEngine,
    Alert,
    AlertRule,
    error_rate_rule,
    fatal_count_rule,
    pattern_alert_rule,
    no_logs_rule,
    create_default_engine,
)
from logpilot.models import LogEntry, LogLevel


def _entries(errors: int = 2, infos: int = 8) -> list[LogEntry]:
    result = [
        LogEntry(raw="", level=LogLevel.ERROR, message=f"error {i}")
        for i in range(errors)
    ]
    result.extend([
        LogEntry(raw="", level=LogLevel.INFO, message=f"info {i}")
        for i in range(infos)
    ])
    return result


class TestErrorRateRule:
    def test_triggers_above_threshold(self):
        rule = error_rate_rule(10.0)
        entries = _entries(errors=6, infos=4)  # 60% error rate > 50%
        alert = rule.check(entries)
        assert alert is not None
        assert alert.rule_name == "high_error_rate"
        assert alert.severity == "critical"

    def test_no_trigger_below_threshold(self):
        rule = error_rate_rule(30.0)
        entries = _entries(errors=2, infos=8)  # 20% error rate
        alert = rule.check(entries)
        assert alert is None

    def test_empty_entries(self):
        rule = error_rate_rule(10.0)
        alert = rule.check([])
        assert alert is None

    def test_warning_severity(self):
        rule = error_rate_rule(10.0)
        entries = _entries(errors=3, infos=7)  # 30%
        alert = rule.check(entries)
        assert alert is not None
        assert alert.severity == "warning"


class TestFatalCountRule:
    def test_triggers_on_fatal(self):
        rule = fatal_count_rule(0)
        entries = [LogEntry(raw="", level=LogLevel.FATAL, message="crash")]
        alert = rule.check(entries)
        assert alert is not None
        assert alert.severity == "critical"

    def test_no_fatals(self):
        rule = fatal_count_rule(0)
        entries = _entries()
        alert = rule.check(entries)
        assert alert is None


class TestPatternAlertRule:
    def test_pattern_match(self):
        rule = pattern_alert_rule("oom", r"out of memory")
        entries = [LogEntry(raw="", message="Out of memory error")]
        alert = rule.check(entries)
        assert alert is not None

    def test_no_match(self):
        rule = pattern_alert_rule("oom", r"out of memory")
        entries = [LogEntry(raw="", message="All good")]
        alert = rule.check(entries)
        assert alert is None

    def test_max_count(self):
        rule = pattern_alert_rule("timeout", r"timeout", max_count=2)
        entries = [LogEntry(raw="", message=f"timeout {i}") for i in range(2)]
        alert = rule.check(entries)
        assert alert is None  # exactly 2, not above

        entries.append(LogEntry(raw="", message="timeout 3"))
        alert = rule.check(entries)
        assert alert is not None


class TestNoLogsRule:
    def test_triggers_empty(self):
        rule = no_logs_rule(5)
        alert = rule.check([])
        assert alert is not None
        assert alert.severity == "critical"

    def test_enough_entries(self):
        rule = no_logs_rule(5)
        entries = _entries(errors=1, infos=9)
        alert = rule.check(entries)
        assert alert is None


class TestAlertEngine:
    def test_evaluate_all_rules(self):
        engine = AlertEngine()
        engine.add_rule(error_rate_rule(10.0))
        engine.add_rule(fatal_count_rule(0))

        entries = _entries(errors=5, infos=5)
        alerts = engine.evaluate(entries)
        assert len(alerts) >= 1  # at least error_rate should trigger

    def test_no_alerts(self):
        engine = AlertEngine()
        engine.add_rule(error_rate_rule(50.0))
        entries = _entries(errors=1, infos=99)
        alerts = engine.evaluate(entries)
        assert len(alerts) == 0

    def test_rule_count(self):
        engine = AlertEngine()
        engine.add_rule(error_rate_rule(10.0))
        engine.add_rule(fatal_count_rule(0))
        assert engine.rule_count == 2


class TestDefaultEngine:
    def test_default_rules(self):
        engine = create_default_engine()
        assert engine.rule_count == 4

    def test_default_catches_fatal(self):
        engine = create_default_engine()
        entries = [LogEntry(raw="", level=LogLevel.FATAL, message="crash")]
        alerts = engine.evaluate(entries)
        assert any(a.rule_name == "fatal_detected" for a in alerts)

    def test_default_catches_oom(self):
        engine = create_default_engine()
        entries = [LogEntry(raw="", level=LogLevel.ERROR, message="Out of memory")]
        alerts = engine.evaluate(entries)
        assert any(a.rule_name == "oom" for a in alerts)
