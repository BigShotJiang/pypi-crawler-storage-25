"""Tests for logpilot.models."""

import pytest
from datetime import datetime, timezone

from logpilot.models import LogLevel, LogEntry, LogStats, FilterConfig


class TestLogLevel:
    def test_from_string_standard(self):
        assert LogLevel.from_string("INFO") == LogLevel.INFO
        assert LogLevel.from_string("ERROR") == LogLevel.ERROR
        assert LogLevel.from_string("WARN") == LogLevel.WARN

    def test_from_string_case_insensitive(self):
        assert LogLevel.from_string("info") == LogLevel.INFO
        assert LogLevel.from_string("Error") == LogLevel.ERROR

    def test_from_string_aliases(self):
        assert LogLevel.from_string("WARNING") == LogLevel.WARN
        assert LogLevel.from_string("CRITICAL") == LogLevel.FATAL
        assert LogLevel.from_string("CRIT") == LogLevel.FATAL
        assert LogLevel.from_string("VERBOSE") == LogLevel.DEBUG
        assert LogLevel.from_string("NOTICE") == LogLevel.INFO
        assert LogLevel.from_string("ERR") == LogLevel.ERROR

    def test_from_string_abbreviations(self):
        assert LogLevel.from_string("INF") == LogLevel.INFO
        assert LogLevel.from_string("WRN") == LogLevel.WARN
        assert LogLevel.from_string("DBG") == LogLevel.DEBUG
        assert LogLevel.from_string("TRC") == LogLevel.TRACE
        assert LogLevel.from_string("FTL") == LogLevel.FATAL

    def test_from_string_unknown_defaults_to_info(self):
        assert LogLevel.from_string("unknown") == LogLevel.INFO

    def test_comparison_operators(self):
        assert LogLevel.ERROR > LogLevel.WARN
        assert LogLevel.WARN >= LogLevel.WARN
        assert LogLevel.DEBUG < LogLevel.INFO
        assert LogLevel.INFO <= LogLevel.INFO

    def test_severity_ordering(self):
        levels = [LogLevel.TRACE, LogLevel.DEBUG, LogLevel.INFO, LogLevel.WARN, LogLevel.ERROR, LogLevel.FATAL]
        for i in range(len(levels) - 1):
            assert levels[i] < levels[i + 1]


class TestLogEntry:
    def test_get_simple_field(self):
        entry = LogEntry(raw="", data={"method": "GET"})
        assert entry.get("method") == "GET"

    def test_get_nested_field(self):
        entry = LogEntry(raw="", data={"request": {"method": "GET", "path": "/api"}})
        assert entry.get("request.method") == "GET"
        assert entry.get("request.path") == "/api"

    def test_get_missing_field(self):
        entry = LogEntry(raw="", data={"a": 1})
        assert entry.get("b") is None
        assert entry.get("b", "default") == "default"

    def test_get_deeply_nested(self):
        entry = LogEntry(raw="", data={"a": {"b": {"c": 42}}})
        assert entry.get("a.b.c") == 42

    def test_matches_level(self):
        entry = LogEntry(raw="", level=LogLevel.ERROR)
        assert entry.matches_level(LogLevel.WARN)
        assert entry.matches_level(LogLevel.ERROR)
        assert not entry.matches_level(LogLevel.FATAL)

    def test_to_dict(self):
        entry = LogEntry(
            raw="",
            message="test",
            level=LogLevel.INFO,
            timestamp=datetime(2024, 1, 1, tzinfo=timezone.utc),
            source="app",
            extra={"request_id": "abc"},
        )
        d = entry.to_dict()
        assert d["message"] == "test"
        assert d["level"] == "INFO"
        assert d["source"] == "app"
        assert d["request_id"] == "abc"
        assert "timestamp" in d

    def test_to_json(self):
        entry = LogEntry(raw="", message="hello", level=LogLevel.INFO)
        j = entry.to_json()
        assert '"message": "hello"' in j
        assert '"level": "INFO"' in j


class TestLogStats:
    def test_record_entry(self):
        stats = LogStats()
        entry = LogEntry(
            raw="",
            level=LogLevel.INFO,
            message="test",
            timestamp=datetime(2024, 1, 1, tzinfo=timezone.utc),
            source="app",
            data={"field1": "v1"},
        )
        stats.record(entry)
        assert stats.total == 1
        assert stats.by_level["INFO"] == 1
        assert stats.by_source["app"] == 1
        assert "field1" in stats.unique_fields

    def test_error_rate(self):
        stats = LogStats(total=10, by_level={"ERROR": 2, "FATAL": 1, "INFO": 7})
        assert stats.error_rate == 30.0

    def test_error_rate_zero(self):
        stats = LogStats(total=0)
        assert stats.error_rate == 0.0

    def test_duration_seconds(self):
        stats = LogStats(
            first_timestamp=datetime(2024, 1, 1, 0, 0, 0, tzinfo=timezone.utc),
            last_timestamp=datetime(2024, 1, 1, 0, 5, 0, tzinfo=timezone.utc),
        )
        assert stats.duration_seconds == 300.0

    def test_duration_none(self):
        stats = LogStats()
        assert stats.duration_seconds is None


class TestFilterConfig:
    def test_matches_level(self):
        config = FilterConfig(min_level=LogLevel.WARN)
        entry_info = LogEntry(raw="", level=LogLevel.INFO)
        entry_error = LogEntry(raw="", level=LogLevel.ERROR)
        assert not config.matches(entry_info)
        assert config.matches(entry_error)

    def test_matches_search(self):
        config = FilterConfig(search="timeout")
        entry1 = LogEntry(raw="", message="Connection timeout occurred")
        entry2 = LogEntry(raw="", message="Request completed")
        assert config.matches(entry1)
        assert not config.matches(entry2)

    def test_matches_source(self):
        config = FilterConfig(source="api")
        entry1 = LogEntry(raw="", source="api")
        entry2 = LogEntry(raw="", source="worker")
        assert config.matches(entry1)
        assert not config.matches(entry2)

    def test_matches_grep(self):
        config = FilterConfig(grep="ERROR")
        entry1 = LogEntry(raw='{"level":"ERROR","msg":"fail"}')
        entry2 = LogEntry(raw='{"level":"INFO","msg":"ok"}')
        assert config.matches(entry1)
        assert not config.matches(entry2)

    def test_matches_time_range(self):
        config = FilterConfig(
            since=datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc),
            until=datetime(2024, 1, 1, 13, 0, tzinfo=timezone.utc),
        )
        entry_in = LogEntry(raw="", timestamp=datetime(2024, 1, 1, 12, 30, tzinfo=timezone.utc))
        entry_before = LogEntry(raw="", timestamp=datetime(2024, 1, 1, 11, 0, tzinfo=timezone.utc))
        entry_after = LogEntry(raw="", timestamp=datetime(2024, 1, 1, 14, 0, tzinfo=timezone.utc))
        assert config.matches(entry_in)
        assert not config.matches(entry_before)
        assert not config.matches(entry_after)

    def test_matches_combined(self):
        config = FilterConfig(min_level=LogLevel.WARN, search="timeout")
        entry = LogEntry(raw="", level=LogLevel.ERROR, message="Connection timeout")
        assert config.matches(entry)

    def test_matches_no_filters(self):
        config = FilterConfig()
        entry = LogEntry(raw="", message="anything")
        assert config.matches(entry)
