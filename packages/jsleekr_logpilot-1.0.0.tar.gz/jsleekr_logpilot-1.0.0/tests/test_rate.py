"""Tests for logpilot.rate."""

import pytest
from datetime import datetime, timezone, timedelta

from logpilot.rate import (
    calculate_throughput,
    detect_rate_spikes,
    calculate_percentiles,
    RateWindow,
)
from logpilot.models import LogEntry, LogLevel


def _timed_entries(count: int = 10, interval_ms: int = 100) -> list[LogEntry]:
    base = datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    return [
        LogEntry(
            raw="",
            level=LogLevel.INFO if i % 5 != 0 else LogLevel.ERROR,
            message=f"entry {i}",
            timestamp=base + timedelta(milliseconds=i * interval_ms),
            data={"duration_ms": str(i * 10 + 50)},
            is_json=True,
        )
        for i in range(count)
    ]


class TestRateWindow:
    def test_rate_per_second(self):
        w = RateWindow(
            start=datetime(2024, 1, 1, tzinfo=timezone.utc),
            end=datetime(2024, 1, 1, 0, 0, 10, tzinfo=timezone.utc),
            count=100,
        )
        assert w.rate_per_second == 10.0

    def test_error_rate(self):
        w = RateWindow(
            start=datetime(2024, 1, 1, tzinfo=timezone.utc),
            end=datetime(2024, 1, 1, 0, 0, 5, tzinfo=timezone.utc),
            count=50,
            error_count=10,
        )
        assert w.error_rate_per_second == 2.0

    def test_duration(self):
        w = RateWindow(
            start=datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            end=datetime(2024, 1, 1, 12, 0, 30, tzinfo=timezone.utc),
        )
        assert w.duration_seconds == 30.0


class TestCalculateThroughput:
    def test_basic_throughput(self):
        entries = _timed_entries(10, interval_ms=100)
        windows = calculate_throughput(entries, window_seconds=1)
        assert len(windows) >= 1
        total = sum(w.count for w in windows)
        assert total == 10

    def test_empty_entries(self):
        windows = calculate_throughput([])
        assert len(windows) == 0

    def test_no_timestamps(self):
        entries = [LogEntry(raw="", message="no ts")]
        windows = calculate_throughput(entries)
        assert len(windows) == 0


class TestDetectRateSpikes:
    def test_no_spikes_uniform(self):
        entries = _timed_entries(100, interval_ms=100)
        spikes = detect_rate_spikes(entries, window_seconds=1)
        # Uniform distribution shouldn't have spikes
        # (though the first/last windows might be partial)
        assert isinstance(spikes, list)

    def test_empty(self):
        spikes = detect_rate_spikes([])
        assert spikes == []


class TestCalculatePercentiles:
    def test_basic_percentiles(self):
        entries = _timed_entries(100, interval_ms=10)
        result = calculate_percentiles(entries, "duration_ms")
        assert "p50" in result
        assert "p90" in result
        assert "p95" in result
        assert "p99" in result
        assert "min" in result
        assert "max" in result
        assert "avg" in result
        assert result["min"] <= result["p50"] <= result["max"]

    def test_empty_entries(self):
        result = calculate_percentiles([], "duration_ms")
        assert result == {}

    def test_missing_field(self):
        entries = [LogEntry(raw="", data={"other": "val"}, message="")]
        result = calculate_percentiles(entries, "duration_ms")
        assert result == {}

    def test_custom_percentiles(self):
        entries = _timed_entries(50, interval_ms=10)
        result = calculate_percentiles(entries, "duration_ms", percentiles=[50.0, 75.0])
        assert "p50" in result
        assert "p75" in result
        assert "p90" not in result
