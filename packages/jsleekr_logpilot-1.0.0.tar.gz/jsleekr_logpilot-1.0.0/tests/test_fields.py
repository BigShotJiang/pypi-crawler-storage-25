"""Tests for logpilot.fields."""

import pytest

from logpilot.fields import (
    extract_fields,
    flatten_fields,
    unflatten_fields,
    rename_field,
    add_computed_field,
    project_fields,
    extract_regex,
    mask_field,
)
from logpilot.models import LogEntry, LogLevel


def _entries() -> list[LogEntry]:
    return [
        LogEntry(raw="", level=LogLevel.INFO, message="ok",
                 data={"method": "GET", "status": 200},
                 extra={"method": "GET", "status": 200}),
        LogEntry(raw="", level=LogLevel.ERROR, message="fail",
                 data={"method": "POST", "status": 500, "error": "timeout"},
                 extra={"method": "POST", "status": 500, "error": "timeout"}),
    ]


class TestExtractFields:
    def test_extract(self):
        fields = extract_fields(_entries())
        assert "method" in fields
        assert "status" in fields
        assert "error" in fields

    def test_empty(self):
        assert extract_fields([]) == set()


class TestFlattenFields:
    def test_flatten_nested(self):
        data = {"a": {"b": 1, "c": {"d": 2}}}
        result = flatten_fields(data)
        assert result["a.b"] == 1
        assert result["a.c.d"] == 2

    def test_flatten_flat(self):
        data = {"x": 1, "y": 2}
        result = flatten_fields(data)
        assert result == {"x": 1, "y": 2}

    def test_flatten_empty(self):
        assert flatten_fields({}) == {}


class TestUnflattenFields:
    def test_unflatten(self):
        data = {"a.b": 1, "a.c.d": 2}
        result = unflatten_fields(data)
        assert result["a"]["b"] == 1
        assert result["a"]["c"]["d"] == 2

    def test_unflatten_flat(self):
        data = {"x": 1}
        result = unflatten_fields(data)
        assert result == {"x": 1}

    def test_roundtrip(self):
        original = {"a": {"b": 1, "c": {"d": 2}}, "e": 3}
        flat = flatten_fields(original)
        restored = unflatten_fields(flat)
        assert restored == original


class TestRenameField:
    def test_rename(self):
        entries = _entries()
        result = rename_field(entries, "method", "http_method")
        assert result[0].extra.get("http_method") == "GET"
        assert "method" not in result[0].extra

    def test_rename_nonexistent(self):
        entries = _entries()
        result = rename_field(entries, "nonexistent", "new_name")
        assert len(result) == 2  # no crash


class TestAddComputedField:
    def test_add(self):
        entries = _entries()
        result = add_computed_field(entries, "msg_length", lambda e: len(e.message))
        assert result[0].extra["msg_length"] == 2  # "ok"
        assert result[1].extra["msg_length"] == 4  # "fail"


class TestProjectFields:
    def test_project(self):
        entries = _entries()
        result = project_fields(entries, ["level", "message", "method"])
        assert len(result) == 2
        assert result[0]["level"] == "INFO"
        assert result[0]["method"] == "GET"
        assert "status" not in result[0]

    def test_project_line(self):
        entries = [LogEntry(raw="", message="test", line_number=5)]
        result = project_fields(entries, ["line", "message"])
        assert result[0]["line"] == 5


class TestExtractRegex:
    def test_extract_from_message(self):
        entries = [LogEntry(raw="", message="status code 503 returned")]
        result = extract_regex(entries, "message", r"status code (\d+)", "status_code")
        assert result[0].extra["status_code"] == "503"

    def test_extract_no_match(self):
        entries = [LogEntry(raw="", message="all good")]
        result = extract_regex(entries, "message", r"status code (\d+)", "status_code")
        assert "status_code" not in result[0].extra

    def test_extract_multiple_groups(self):
        entries = [LogEntry(raw="", message="GET /api/users 200")]
        result = extract_regex(entries, "message", r"(\w+) (/\S+) (\d+)", "parsed")
        assert result[0].extra["parsed"] == ["GET", "/api/users", "200"]


class TestMaskField:
    def test_mask(self):
        entries = [LogEntry(raw="", message="", data={"password": "secret123"}, extra={"password": "secret123"})]
        result = mask_field(entries, "password")
        assert result[0].extra["password"] == "***"
        assert result[0].data["password"] == "***"

    def test_mask_nonexistent(self):
        entries = [LogEntry(raw="", message="", extra={"name": "John"})]
        result = mask_field(entries, "password")
        assert result[0].extra.get("name") == "John"

    def test_custom_mask(self):
        entries = [LogEntry(raw="", message="", data={"token": "abc"}, extra={"token": "abc"})]
        result = mask_field(entries, "token", mask="[REDACTED]")
        assert result[0].extra["token"] == "[REDACTED]"
