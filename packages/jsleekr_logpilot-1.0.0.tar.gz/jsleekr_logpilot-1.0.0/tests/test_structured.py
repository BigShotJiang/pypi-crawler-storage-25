"""Tests for logpilot.structured."""

import json
import pytest
from datetime import datetime, timezone

from logpilot.structured import (
    StructuredOutput,
    create_view_output,
    create_stats_output,
    create_query_output,
    create_error_output,
)
from logpilot.models import LogEntry, LogLevel


def _entries() -> list[LogEntry]:
    return [
        LogEntry(raw="", level=LogLevel.INFO, message="ok",
                 timestamp=datetime(2024, 1, 1, tzinfo=timezone.utc),
                 source="api", is_json=True, data={"status": "200"}),
        LogEntry(raw="", level=LogLevel.ERROR, message="fail",
                 timestamp=datetime(2024, 1, 1, 0, 1, tzinfo=timezone.utc),
                 source="api", is_json=True),
    ]


class TestStructuredOutput:
    def test_to_dict(self):
        output = StructuredOutput(status="ok", command="test", data={"key": "val"})
        d = output.to_dict()
        assert d["status"] == "ok"
        assert d["data"]["key"] == "val"

    def test_to_json(self):
        output = StructuredOutput(status="ok", command="test")
        j = output.to_json()
        parsed = json.loads(j)
        assert parsed["status"] == "ok"

    def test_to_json_pretty(self):
        output = StructuredOutput(status="ok", command="test")
        j = output.to_json(pretty=True)
        assert "\n" in j

    def test_errors_included(self):
        output = StructuredOutput(status="error", errors=["something went wrong"])
        d = output.to_dict()
        assert "errors" in d

    def test_no_errors_excluded(self):
        output = StructuredOutput(status="ok")
        d = output.to_dict()
        assert "errors" not in d


class TestCreateViewOutput:
    def test_basic(self):
        output = create_view_output(_entries(), total_input=10)
        assert output.command == "view"
        assert output.data["count"] == 2
        assert output.metadata["total_input"] == 10

    def test_entries_serialized(self):
        output = create_view_output(_entries())
        entries = output.data["entries"]
        assert len(entries) == 2
        assert entries[0]["level"] == "INFO"


class TestCreateStatsOutput:
    def test_basic(self):
        output = create_stats_output(_entries())
        assert output.command == "stats"
        assert output.data["total"] == 2

    def test_json_serializable(self):
        output = create_stats_output(_entries())
        j = output.to_json()
        parsed = json.loads(j)
        assert parsed["data"]["total"] == 2


class TestCreateQueryOutput:
    def test_basic(self):
        output = create_query_output(_entries(), query="level:error", total_scanned=10)
        assert output.command == "query"
        assert output.data["matched"] == 2
        assert output.metadata["query"] == "level:error"
        assert output.metadata["match_rate"] == 20.0


class TestCreateErrorOutput:
    def test_error(self):
        output = create_error_output("File not found", command="view")
        assert output.status == "error"
        assert "File not found" in output.errors
