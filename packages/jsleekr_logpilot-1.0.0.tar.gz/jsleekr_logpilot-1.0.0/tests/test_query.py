"""Tests for logpilot.query."""

import pytest

from logpilot.query import tokenize, evaluate_query, execute_query, TokenType
from logpilot.models import LogEntry, LogLevel


def _entries() -> list[LogEntry]:
    return [
        LogEntry(raw="", level=LogLevel.INFO, message="request handled",
                 source="api", data={"status": "200", "method": "GET"},
                 extra={"status": "200", "method": "GET"}, is_json=True),
        LogEntry(raw="", level=LogLevel.WARN, message="slow query detected",
                 source="db", data={"duration_ms": "500"},
                 extra={"duration_ms": "500"}, is_json=True),
        LogEntry(raw="", level=LogLevel.ERROR, message="connection failed",
                 source="api", data={"status": "503"},
                 extra={"status": "503"}, is_json=True),
        LogEntry(raw="", level=LogLevel.ERROR, message="timeout error",
                 source="worker", data={"retry": "3"},
                 extra={"retry": "3"}, is_json=True),
    ]


class TestTokenize:
    def test_simple_field_value(self):
        tokens = tokenize("level:error")
        assert len(tokens) == 1
        assert tokens[0].type == TokenType.FIELD_VALUE
        assert tokens[0].field == "level"
        assert tokens[0].value == "error"

    def test_and_operator(self):
        tokens = tokenize("level:error AND source:api")
        assert len(tokens) == 3
        assert tokens[1].type == TokenType.AND

    def test_or_operator(self):
        tokens = tokenize("level:error OR level:fatal")
        assert len(tokens) == 3
        assert tokens[1].type == TokenType.OR

    def test_not_operator(self):
        tokens = tokenize("NOT source:healthcheck")
        assert len(tokens) == 2
        assert tokens[0].type == TokenType.NOT

    def test_comparison_operators(self):
        tokens = tokenize("level:>=warn")
        assert tokens[0].operator == ">="
        assert tokens[0].value == "warn"

    def test_not_equal(self):
        tokens = tokenize("source:!=api")
        assert tokens[0].operator == "!="
        assert tokens[0].value == "api"

    def test_regex_operator(self):
        tokens = tokenize("msg:~timeout")
        assert tokens[0].operator == "~"

    def test_plain_text_search(self):
        tokens = tokenize("timeout")
        assert tokens[0].type == TokenType.FIELD_VALUE
        assert tokens[0].field == "msg"
        assert tokens[0].operator == "~"


class TestEvaluateQuery:
    def test_level_equals(self):
        tokens = tokenize("level:error")
        entry = LogEntry(raw="", level=LogLevel.ERROR, message="fail")
        assert evaluate_query(entry, tokens)

    def test_level_gte(self):
        tokens = tokenize("level:>=warn")
        entry_warn = LogEntry(raw="", level=LogLevel.WARN, message="")
        entry_info = LogEntry(raw="", level=LogLevel.INFO, message="")
        assert evaluate_query(entry_warn, tokens)
        assert not evaluate_query(entry_info, tokens)

    def test_message_search(self):
        tokens = tokenize("msg:~timeout")
        entry = LogEntry(raw="", message="connection timeout occurred")
        assert evaluate_query(entry, tokens)

    def test_source_match(self):
        tokens = tokenize("source:api")
        entry = LogEntry(raw="", source="api", message="")
        assert evaluate_query(entry, tokens)

    def test_and_condition(self):
        tokens = tokenize("level:error AND source:api")
        entry_match = LogEntry(raw="", level=LogLevel.ERROR, source="api", message="")
        entry_no = LogEntry(raw="", level=LogLevel.ERROR, source="worker", message="")
        assert evaluate_query(entry_match, tokens)
        assert not evaluate_query(entry_no, tokens)

    def test_or_condition(self):
        tokens = tokenize("level:error OR level:fatal")
        entry1 = LogEntry(raw="", level=LogLevel.ERROR, message="")
        entry2 = LogEntry(raw="", level=LogLevel.FATAL, message="")
        entry3 = LogEntry(raw="", level=LogLevel.INFO, message="")
        assert evaluate_query(entry1, tokens)
        assert evaluate_query(entry2, tokens)
        assert not evaluate_query(entry3, tokens)

    def test_not_condition(self):
        tokens = tokenize("NOT source:healthcheck")
        entry1 = LogEntry(raw="", source="api", message="")
        entry2 = LogEntry(raw="", source="healthcheck", message="")
        assert evaluate_query(entry1, tokens)
        assert not evaluate_query(entry2, tokens)

    def test_numeric_comparison(self):
        tokens = tokenize("status:>=400")
        entry1 = LogEntry(raw="", message="", data={"status": "503"}, extra={"status": "503"})
        entry2 = LogEntry(raw="", message="", data={"status": "200"}, extra={"status": "200"})
        assert evaluate_query(entry1, tokens)
        assert not evaluate_query(entry2, tokens)

    def test_empty_query(self):
        tokens = tokenize("")
        entry = LogEntry(raw="", message="anything")
        assert evaluate_query(entry, tokens)


class TestExecuteQuery:
    def test_execute_level_filter(self):
        result = execute_query(_entries(), "level:error")
        assert result.matched == 2
        assert result.total_scanned == 4

    def test_execute_source_filter(self):
        result = execute_query(_entries(), "source:api")
        assert result.matched == 2

    def test_execute_combined(self):
        result = execute_query(_entries(), "level:error AND source:api")
        assert result.matched == 1

    def test_execute_text_search(self):
        result = execute_query(_entries(), "timeout")
        assert result.matched == 1

    def test_execute_field_comparison(self):
        result = execute_query(_entries(), "status:>=400")
        assert result.matched >= 1
