"""Tests for logpilot.watcher."""

import pytest
import os
import tempfile
import time
import threading

from logpilot.watcher import FileWatcher, StreamFollower
from logpilot.models import LogEntry


class TestFileWatcher:
    def test_init(self):
        watcher = FileWatcher("test.log")
        assert watcher.path == "test.log"
        assert watcher.poll_interval == 0.1
        assert watcher.from_end is True
        assert not watcher.is_running

    def test_watch_new_lines(self, tmp_path):
        log_file = str(tmp_path / "test.log")
        with open(log_file, "w") as f:
            f.write('{"level":"info","msg":"initial"}\n')

        received: list[LogEntry] = []

        def on_entry(entry: LogEntry):
            received.append(entry)

        watcher = FileWatcher(log_file, poll_interval=0.05, from_end=False)

        # Run watcher with max_iterations
        watcher.watch(callback=on_entry, max_iterations=3)

        assert len(received) >= 1
        assert received[0].message == "initial"

    def test_watch_file_append(self, tmp_path):
        log_file = str(tmp_path / "test.log")
        with open(log_file, "w") as f:
            f.write('{"level":"info","msg":"line1"}\n')

        received: list[LogEntry] = []

        def on_entry(entry: LogEntry):
            received.append(entry)

        watcher = FileWatcher(log_file, poll_interval=0.05, from_end=True)

        # Write new content in another thread
        def write_later():
            time.sleep(0.1)
            with open(log_file, "a") as f:
                f.write('{"level":"error","msg":"line2"}\n')
            time.sleep(0.1)
            watcher.stop()

        writer = threading.Thread(target=write_later)
        writer.start()
        watcher.watch(callback=on_entry, max_iterations=50)
        writer.join()

        assert any(e.message == "line2" for e in received)

    def test_watch_nonexistent_file(self, tmp_path):
        log_file = str(tmp_path / "nonexistent.log")
        received: list[LogEntry] = []
        watcher = FileWatcher(log_file, poll_interval=0.05)
        watcher.watch(callback=lambda e: received.append(e), max_iterations=2)
        assert len(received) == 0

    def test_stop(self):
        watcher = FileWatcher("test.log")
        watcher.stop()
        assert not watcher.is_running

    def test_watch_file_truncation(self, tmp_path):
        log_file = str(tmp_path / "test.log")
        with open(log_file, "w") as f:
            f.write('{"level":"info","msg":"before truncate"}\n' * 10)

        received: list[LogEntry] = []
        watcher = FileWatcher(log_file, poll_interval=0.05, from_end=False)

        def write_later():
            time.sleep(0.1)
            # Truncate and write new content
            with open(log_file, "w") as f:
                f.write('{"level":"warn","msg":"after truncate"}\n')
            time.sleep(0.1)
            watcher.stop()

        writer = threading.Thread(target=write_later)
        writer.start()
        watcher.watch(callback=lambda e: received.append(e), max_iterations=50)
        writer.join()

        assert len(received) > 0


class TestStreamFollower:
    def test_follow_stream(self, tmp_path):
        log_file = str(tmp_path / "test.log")
        with open(log_file, "w") as f:
            f.write('{"level":"info","msg":"line1"}\n')
            f.write('{"level":"error","msg":"line2"}\n')

        received: list[LogEntry] = []
        with open(log_file, "r") as f:
            follower = StreamFollower(f)
            follower.follow(callback=lambda e: received.append(e))

        assert len(received) == 2
        assert received[0].message == "line1"
        assert received[1].message == "line2"
