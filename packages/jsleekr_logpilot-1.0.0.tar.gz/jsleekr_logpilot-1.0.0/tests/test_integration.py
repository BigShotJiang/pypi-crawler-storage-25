"""Integration tests: end-to-end scenarios with realistic log data."""

import json
import pytest
import tempfile
import os

from logpilot.parser import parse_text, parse_file
from logpilot.pipeline import Pipeline
from logpilot.filter import apply_filter
from logpilot.analyzer import compute_stats, detect_anomalies, cluster_errors
from logpilot.query import execute_query
from logpilot.exporter import export_json, export_csv
from logpilot.formatter import OutputFormatter
from logpilot.context import group_by_trace
from logpilot.patterns import scan_patterns
from logpilot.sampler import summarize
from logpilot.models import FilterConfig, LogLevel


# Realistic log samples from different frameworks
PINO_LOGS = """{"level":30,"time":1704067200000,"pid":1234,"hostname":"web-1","msg":"Server listening","port":3000}
{"level":30,"time":1704067201000,"pid":1234,"hostname":"web-1","msg":"GET /api/users","method":"GET","url":"/api/users","statusCode":200,"responseTime":45}
{"level":40,"time":1704067202000,"pid":1234,"hostname":"web-1","msg":"Slow query detected","query":"SELECT * FROM users","duration":1500}
{"level":50,"time":1704067203000,"pid":1234,"hostname":"web-1","msg":"Connection refused","error":{"message":"ECONNREFUSED","code":"ECONNREFUSED"},"service":"redis"}
{"level":30,"time":1704067204000,"pid":1234,"hostname":"web-1","msg":"GET /api/health","method":"GET","url":"/api/health","statusCode":200,"responseTime":2}"""

STRUCTLOG_LOGS = """{"event":"request_started","method":"POST","path":"/api/orders","timestamp":"2024-01-01T12:00:00Z","level":"info","request_id":"req-001"}
{"event":"db_query","sql":"INSERT INTO orders","duration_ms":35,"timestamp":"2024-01-01T12:00:00.050Z","level":"debug","request_id":"req-001"}
{"event":"payment_processed","amount":99.99,"timestamp":"2024-01-01T12:00:00.200Z","level":"info","request_id":"req-001"}
{"event":"request_completed","status":201,"duration_ms":250,"timestamp":"2024-01-01T12:00:00.250Z","level":"info","request_id":"req-001"}
{"event":"request_started","method":"GET","path":"/api/orders/1","timestamp":"2024-01-01T12:00:01Z","level":"info","request_id":"req-002"}
{"event":"request_completed","status":200,"duration_ms":15,"timestamp":"2024-01-01T12:00:01.015Z","level":"info","request_id":"req-002"}"""

WINSTON_LOGS = """{"level":"info","message":"Application started","timestamp":"2024-01-01T08:00:00.000Z","service":"order-api"}
{"level":"info","message":"Connected to database","timestamp":"2024-01-01T08:00:01.000Z","service":"order-api","db":"postgres"}
{"level":"warn","message":"High memory usage: 85%","timestamp":"2024-01-01T08:05:00.000Z","service":"order-api","memory_pct":85}
{"level":"error","message":"Failed to process order","timestamp":"2024-01-01T08:10:00.000Z","service":"order-api","order_id":"ORD-123","error":"Payment gateway timeout"}
{"level":"error","message":"Failed to process order","timestamp":"2024-01-01T08:10:05.000Z","service":"order-api","order_id":"ORD-124","error":"Payment gateway timeout"}
{"level":"info","message":"Health check passed","timestamp":"2024-01-01T08:15:00.000Z","service":"order-api"}"""

MIXED_LOGS = """{"timestamp":"2024-01-01T12:00:00Z","level":"info","msg":"json line"}
plain text log line with no structure
2024-01-01 12:00:02 ERROR something went wrong
{"timestamp":"2024-01-01T12:00:03Z","level":"error","msg":"another json error"}"""


class TestPinoLogParsing:
    def test_parse_pino_entries(self):
        entries = parse_text(PINO_LOGS)
        assert len(entries) == 5
        assert all(e.is_json for e in entries)

    def test_pino_level_mapping(self):
        entries = parse_text(PINO_LOGS)
        # Pino uses numeric levels (30=info, 40=warn, 50=error)
        # Our parser should handle these via field detection
        assert entries[0].message == "Server listening"

    def test_pino_timestamp_parsing(self):
        entries = parse_text(PINO_LOGS)
        assert entries[0].timestamp is not None


class TestStructlogParsing:
    def test_parse_structlog(self):
        entries = parse_text(STRUCTLOG_LOGS)
        assert len(entries) == 6
        assert all(e.is_json for e in entries)

    def test_structlog_event_as_message(self):
        entries = parse_text(STRUCTLOG_LOGS)
        # "event" is not in default MESSAGE_FIELDS, but should be picked up
        # The message might be empty, but the data should be parsed
        assert entries[0].is_json

    def test_structlog_request_tracing(self):
        entries = parse_text(STRUCTLOG_LOGS)
        traces = group_by_trace(entries)
        assert "req-001" in traces
        assert "req-002" in traces
        assert traces["req-001"].entry_count == 4
        assert traces["req-002"].entry_count == 2


class TestWinstonParsing:
    def test_parse_winston(self):
        entries = parse_text(WINSTON_LOGS)
        assert len(entries) == 6
        assert all(e.is_json for e in entries)

    def test_winston_levels(self):
        entries = parse_text(WINSTON_LOGS)
        assert entries[2].level == LogLevel.WARN
        assert entries[3].level == LogLevel.ERROR

    def test_winston_error_clustering(self):
        entries = parse_text(WINSTON_LOGS)
        clusters = cluster_errors(entries)
        assert len(clusters) >= 1
        assert clusters[0].count == 2  # two "Failed to process order" errors


class TestMixedLogParsing:
    def test_parse_mixed(self):
        entries = parse_text(MIXED_LOGS)
        assert len(entries) == 4
        json_entries = [e for e in entries if e.is_json]
        assert len(json_entries) == 2


class TestEndToEndPipeline:
    def test_full_pipeline(self):
        entries = parse_text(WINSTON_LOGS)
        result = (
            Pipeline(entries)
            .filter_level(LogLevel.WARN)
            .sort_by("timestamp")
            .execute()
        )
        assert len(result) == 3  # 1 warn + 2 errors
        assert result[0].level == LogLevel.WARN

    def test_query_then_export(self):
        entries = parse_text(WINSTON_LOGS)
        query_result = execute_query(entries, "level:error")
        exported = export_json(query_result.entries, pretty=True)
        parsed = json.loads(exported)
        assert len(parsed) == 2

    def test_stats_computation(self):
        entries = parse_text(WINSTON_LOGS)
        stats = compute_stats(entries)
        assert stats.total == 6
        assert stats.by_level["ERROR"] == 2
        assert stats.error_rate > 0

    def test_pattern_detection(self):
        # Use logs where timeout appears in the message itself
        logs = """{"level":"error","message":"Request timed out after 30s","timestamp":"2024-01-01T08:10:00Z"}
{"level":"warn","message":"Connection timeout to database","timestamp":"2024-01-01T08:10:01Z"}"""
        entries = parse_text(logs)
        matches = scan_patterns(entries)
        pattern_names = [m.pattern_name for m in matches]
        assert "timeout" in pattern_names

    def test_filter_config(self):
        entries = parse_text(PINO_LOGS)
        config = FilterConfig(min_level=LogLevel.WARN)
        filtered = apply_filter(entries, config)
        assert all(e.level >= LogLevel.WARN for e in filtered)


class TestFileOperations:
    def test_parse_and_export_file(self, tmp_path):
        # Write logs to file
        log_file = tmp_path / "test.log"
        log_file.write_text(WINSTON_LOGS)

        # Parse
        entries = parse_file(str(log_file))
        assert len(entries) == 6

        # Export to CSV
        csv_output = export_csv(entries)
        assert "timestamp" in csv_output
        assert "level" in csv_output

    def test_roundtrip_json(self, tmp_path):
        entries = parse_text(PINO_LOGS)
        exported = export_json(entries, pretty=True)

        output_file = tmp_path / "output.json"
        output_file.write_text(exported)

        reimported = json.loads(output_file.read_text())
        assert len(reimported) == 5


class TestFormatterIntegration:
    def test_compact_format(self):
        entries = parse_text(WINSTON_LOGS)
        formatter = OutputFormatter(style="compact", use_color=False)
        output = formatter.format_all(entries)
        assert "Application started" in output
        assert "ERROR" in output

    def test_json_format(self):
        entries = parse_text(WINSTON_LOGS)
        formatter = OutputFormatter(style="json")
        for entry in entries:
            line = formatter.format(entry)
            parsed = json.loads(line)
            assert "level" in parsed

    def test_pretty_format(self):
        entries = parse_text(WINSTON_LOGS)
        formatter = OutputFormatter(style="pretty", use_color=False)
        output = formatter.format_all(entries)
        assert "order-api" in output or "INFO" in output


class TestSummaryIntegration:
    def test_full_summary(self):
        entries = parse_text(WINSTON_LOGS)
        summary = summarize(entries)
        assert summary["total"] == 6
        assert summary["error_count"] == 2
        assert summary["has_timestamps"]
