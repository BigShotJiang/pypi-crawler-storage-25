"""Tests for logpilot.patterns."""

import pytest

from logpilot.patterns import (
    PatternRule,
    scan_patterns,
    create_custom_pattern,
    BUILTIN_PATTERNS,
)
from logpilot.models import LogEntry, LogLevel


class TestPatternRule:
    def test_matches_message(self):
        rule = PatternRule(
            name="test", description="test", severity=LogLevel.ERROR,
            field="message", pattern=r"timeout",
        )
        entry = LogEntry(raw="", message="Connection timeout occurred")
        assert rule.matches(entry)

    def test_no_match(self):
        rule = PatternRule(
            name="test", description="test", severity=LogLevel.ERROR,
            field="message", pattern=r"timeout",
        )
        entry = LogEntry(raw="", message="Request completed successfully")
        assert not rule.matches(entry)

    def test_matches_raw(self):
        rule = PatternRule(
            name="test", description="test", severity=LogLevel.ERROR,
            field="raw", pattern=r"503",
        )
        entry = LogEntry(raw='{"status":503}', message="")
        assert rule.matches(entry)

    def test_matches_custom_field(self):
        rule = PatternRule(
            name="test", description="test", severity=LogLevel.WARN,
            field="status_code", pattern=r"5\d{2}",
        )
        entry = LogEntry(raw="", message="", data={"status_code": "503"})
        assert rule.matches(entry)

    def test_case_insensitive(self):
        rule = PatternRule(
            name="test", description="test", severity=LogLevel.ERROR,
            field="message", pattern=r"timeout",
        )
        entry = LogEntry(raw="", message="TIMEOUT ERROR")
        assert rule.matches(entry)


class TestBuiltinPatterns:
    def test_oom_pattern(self):
        entry = LogEntry(raw="", message="Java heap space out of memory")
        matches = scan_patterns([entry])
        names = [m.pattern_name for m in matches]
        assert "oom" in names

    def test_connection_refused(self):
        entry = LogEntry(raw="", message="ECONNREFUSED: connection refused to db:5432")
        matches = scan_patterns([entry])
        names = [m.pattern_name for m in matches]
        assert "connection_refused" in names

    def test_timeout_pattern(self):
        entry = LogEntry(raw="", message="Request timed out after 30s")
        matches = scan_patterns([entry])
        names = [m.pattern_name for m in matches]
        assert "timeout" in names

    def test_auth_failure(self):
        entry = LogEntry(raw="", message="401 Unauthorized: invalid token")
        matches = scan_patterns([entry])
        names = [m.pattern_name for m in matches]
        assert "auth_failure" in names

    def test_rate_limit(self):
        entry = LogEntry(raw="", message="429 Too many requests, rate limited")
        matches = scan_patterns([entry])
        names = [m.pattern_name for m in matches]
        assert "rate_limit" in names

    def test_ssl_error(self):
        entry = LogEntry(raw="", message="SSL certificate expired for host example.com")
        matches = scan_patterns([entry])
        names = [m.pattern_name for m in matches]
        assert "ssl_error" in names

    def test_no_matches(self):
        entry = LogEntry(raw="", message="Request completed successfully in 50ms")
        matches = scan_patterns([entry])
        assert len(matches) == 0


class TestScanPatterns:
    def test_count_multiple(self):
        entries = [
            LogEntry(raw="", message="timeout error 1"),
            LogEntry(raw="", message="timeout error 2"),
            LogEntry(raw="", message="timeout error 3"),
        ]
        matches = scan_patterns(entries)
        timeout_match = next(m for m in matches if m.pattern_name == "timeout")
        assert timeout_match.count == 3

    def test_samples_limited(self):
        entries = [
            LogEntry(raw="", message=f"timeout error {i}")
            for i in range(10)
        ]
        matches = scan_patterns(entries)
        timeout_match = next(m for m in matches if m.pattern_name == "timeout")
        assert len(timeout_match.entries) == 3  # max 3 samples

    def test_sorted_by_severity(self):
        entries = [
            LogEntry(raw="", message="out of memory"),  # FATAL
            LogEntry(raw="", message="timeout"),  # ERROR
            LogEntry(raw="", message="rate limited"),  # WARN
        ]
        matches = scan_patterns(entries)
        assert matches[0].severity.value >= matches[-1].severity.value

    def test_custom_patterns(self):
        custom = [
            PatternRule(name="custom", description="test", severity=LogLevel.WARN,
                       field="message", pattern=r"custom_error_\d+"),
        ]
        entries = [
            LogEntry(raw="", message="got custom_error_42"),
            LogEntry(raw="", message="normal message"),
        ]
        matches = scan_patterns(entries, patterns=custom)
        assert len(matches) == 1
        assert matches[0].pattern_name == "custom"

    def test_suggestions_present(self):
        entry = LogEntry(raw="", message="out of memory error")
        matches = scan_patterns([entry])
        oom = next(m for m in matches if m.pattern_name == "oom")
        assert len(oom.suggestion) > 0


class TestCreateCustomPattern:
    def test_create(self):
        rule = create_custom_pattern(
            name="slow_query",
            pattern=r"duration_ms:\s*\d{4,}",
            field="raw",
            severity=LogLevel.WARN,
            suggestion="Optimize the query.",
        )
        assert rule.name == "slow_query"
        assert rule.severity == LogLevel.WARN

    def test_default_description(self):
        rule = create_custom_pattern(name="test", pattern=r"test")
        assert "test" in rule.description
