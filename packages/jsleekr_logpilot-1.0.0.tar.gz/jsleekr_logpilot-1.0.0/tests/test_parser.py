"""Tests for logpilot.parser."""

import pytest
from datetime import datetime, timezone

from logpilot.parser import parse_line, parse_text, _parse_timestamp, _try_parse_json
from logpilot.models import LogLevel


class TestParseLine:
    def test_parse_json_line(self):
        line = '{"level":"info","msg":"Server started","port":8080}'
        entry = parse_line(line)
        assert entry.is_json
        assert entry.level == LogLevel.INFO
        assert entry.message == "Server started"
        assert entry.extra.get("port") == 8080

    def test_parse_json_with_timestamp(self):
        line = '{"timestamp":"2024-01-01T12:00:00Z","level":"error","message":"Failed"}'
        entry = parse_line(line)
        assert entry.is_json
        assert entry.level == LogLevel.ERROR
        assert entry.message == "Failed"
        assert entry.timestamp is not None
        assert entry.timestamp.year == 2024

    def test_parse_plain_text(self):
        line = "Just a plain text log line"
        entry = parse_line(line)
        assert not entry.is_json
        assert entry.message == "Just a plain text log line"

    def test_parse_empty_line(self):
        entry = parse_line("")
        assert not entry.is_json
        assert entry.message == ""

    def test_parse_json_with_nested_fields(self):
        line = '{"level":"info","msg":"Request","request":{"method":"GET","path":"/api"}}'
        entry = parse_line(line)
        assert entry.is_json
        assert entry.get("request.method") == "GET"

    def test_parse_various_level_fields(self):
        # severity field
        line = '{"severity":"WARNING","message":"disk full"}'
        entry = parse_line(line)
        assert entry.level == LogLevel.WARN

    def test_parse_various_message_fields(self):
        # text field
        line = '{"level":"info","text":"hello"}'
        entry = parse_line(line)
        assert entry.message == "hello"

    def test_parse_source_field(self):
        line = '{"level":"info","msg":"test","logger":"myapp.api"}'
        entry = parse_line(line)
        assert entry.source == "myapp.api"

    def test_parse_component_source(self):
        line = '{"level":"info","msg":"test","component":"database"}'
        entry = parse_line(line)
        assert entry.source == "database"

    def test_line_number_tracking(self):
        entry = parse_line('{"msg":"test"}', line_number=42)
        assert entry.line_number == 42

    def test_parse_json_embedded_in_text(self):
        line = '2024-01-01 INFO {"level":"info","msg":"embedded"}'
        entry = parse_line(line)
        assert entry.is_json
        assert entry.message == "embedded"

    def test_parse_json_array_not_treated_as_log(self):
        line = '[1, 2, 3]'
        entry = parse_line(line)
        assert not entry.is_json

    def test_parse_unix_timestamp(self):
        line = '{"ts":1704067200,"level":"info","msg":"test"}'
        entry = parse_line(line)
        assert entry.timestamp is not None

    def test_parse_millisecond_timestamp(self):
        line = '{"ts":1704067200000,"level":"info","msg":"test"}'
        entry = parse_line(line)
        assert entry.timestamp is not None


class TestParseTimestamp:
    def test_iso8601_with_z(self):
        ts = _parse_timestamp("2024-01-01T12:00:00Z")
        assert ts is not None
        assert ts.year == 2024

    def test_iso8601_with_offset(self):
        ts = _parse_timestamp("2024-01-01T12:00:00+09:00")
        assert ts is not None

    def test_iso8601_with_millis(self):
        ts = _parse_timestamp("2024-01-01T12:00:00.123Z")
        assert ts is not None

    def test_standard_datetime(self):
        ts = _parse_timestamp("2024-01-01 12:00:00")
        assert ts is not None
        assert ts.hour == 12

    def test_unix_seconds(self):
        ts = _parse_timestamp(1704067200)
        assert ts is not None

    def test_unix_milliseconds(self):
        ts = _parse_timestamp(1704067200000)
        assert ts is not None

    def test_unix_string(self):
        ts = _parse_timestamp("1704067200")
        assert ts is not None

    def test_invalid_string(self):
        ts = _parse_timestamp("not a timestamp")
        assert ts is None

    def test_none_input(self):
        ts = _parse_timestamp(None)
        assert ts is None


class TestTryParseJson:
    def test_valid_json_object(self):
        result = _try_parse_json('{"key":"value"}')
        assert result == {"key": "value"}

    def test_json_array_returns_none(self):
        result = _try_parse_json('[1, 2, 3]')
        assert result is None

    def test_invalid_json_returns_none(self):
        result = _try_parse_json('not json')
        assert result is None

    def test_empty_object(self):
        result = _try_parse_json('{}')
        assert result == {}


class TestParseText:
    def test_parse_multiline(self):
        text = """{"level":"info","msg":"first"}
{"level":"error","msg":"second"}
{"level":"debug","msg":"third"}"""
        entries = parse_text(text)
        assert len(entries) == 3
        assert entries[0].message == "first"
        assert entries[1].level == LogLevel.ERROR
        assert entries[2].level == LogLevel.DEBUG

    def test_parse_mixed_lines(self):
        text = """{"level":"info","msg":"json line"}
plain text line
{"level":"error","msg":"another json"}"""
        entries = parse_text(text)
        assert len(entries) == 3
        assert entries[0].is_json
        assert not entries[1].is_json
        assert entries[2].is_json

    def test_line_numbers(self):
        text = "line1\nline2\nline3"
        entries = parse_text(text)
        assert entries[0].line_number == 1
        assert entries[1].line_number == 2
        assert entries[2].line_number == 3
