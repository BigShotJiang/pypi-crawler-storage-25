"""Tests for logpilot.sampler."""

import pytest

from logpilot.sampler import (
    reservoir_sample,
    stratified_sample,
    systematic_sample,
    hash_sample,
    error_focused_sample,
    summarize,
)
from logpilot.models import LogEntry, LogLevel


def _entries(n: int = 100) -> list[LogEntry]:
    return [
        LogEntry(
            raw=f"line {i}",
            level=LogLevel.ERROR if i % 10 == 0 else LogLevel.INFO,
            message=f"entry {i}",
            source="api" if i % 2 == 0 else "worker",
        )
        for i in range(n)
    ]


class TestReservoirSample:
    def test_sample_size(self):
        result = reservoir_sample(_entries(100), 10)
        assert len(result) == 10

    def test_sample_larger_than_input(self):
        result = reservoir_sample(_entries(5), 10)
        assert len(result) == 5

    def test_sample_zero(self):
        result = reservoir_sample(_entries(), 0)
        assert len(result) == 0

    def test_deterministic_small(self):
        entries = _entries(3)
        result = reservoir_sample(entries, 3)
        assert len(result) == 3


class TestStratifiedSample:
    def test_by_level(self):
        result = stratified_sample(_entries(100), 20, by="level")
        assert len(result) <= 20
        levels = {e.level for e in result}
        assert LogLevel.ERROR in levels
        assert LogLevel.INFO in levels

    def test_by_source(self):
        result = stratified_sample(_entries(100), 20, by="source")
        assert len(result) <= 20
        sources = {e.source for e in result}
        assert "api" in sources
        assert "worker" in sources

    def test_zero(self):
        result = stratified_sample(_entries(), 0)
        assert len(result) == 0


class TestSystematicSample:
    def test_sample_size(self):
        result = systematic_sample(_entries(100), 10)
        assert len(result) == 10

    def test_larger_than_input(self):
        result = systematic_sample(_entries(5), 10)
        assert len(result) == 5

    def test_preserves_order(self):
        entries = _entries(100)
        result = systematic_sample(entries, 10)
        # Should be in order
        for i in range(len(result) - 1):
            idx_a = int(result[i].message.split()[-1])
            idx_b = int(result[i + 1].message.split()[-1])
            assert idx_a < idx_b


class TestHashSample:
    def test_deterministic(self):
        entries = _entries(100)
        result1 = hash_sample(entries, 0.5)
        result2 = hash_sample(entries, 0.5)
        assert len(result1) == len(result2)

    def test_rate_zero(self):
        result = hash_sample(_entries(), 0.0)
        assert len(result) == 0

    def test_rate_one(self):
        entries = _entries(10)
        result = hash_sample(entries, 1.0)
        assert len(result) == 10

    def test_approximate_rate(self):
        entries = _entries(1000)
        result = hash_sample(entries, 0.5)
        # Should be roughly 50% (+/- 15%)
        assert 350 < len(result) < 650


class TestErrorFocusedSample:
    def test_includes_errors(self):
        entries = _entries(100)
        result = error_focused_sample(entries, 30)
        errors_in_result = [e for e in result if e.level == LogLevel.ERROR]
        assert len(errors_in_result) > 0

    def test_includes_context(self):
        entries = _entries(100)
        result = error_focused_sample(entries, 50)
        # Should include entries around errors
        assert len(result) <= 50

    def test_no_errors(self):
        entries = [LogEntry(raw="", level=LogLevel.INFO, message=f"info {i}") for i in range(20)]
        result = error_focused_sample(entries, 10)
        assert len(result) == 10


class TestSummarize:
    def test_basic_summary(self):
        entries = _entries(100)
        summary = summarize(entries)
        assert summary["total"] == 100
        assert summary["error_count"] == 10
        assert "api" in summary["sources"]

    def test_empty(self):
        summary = summarize([])
        assert summary["total"] == 0

    def test_error_rate(self):
        entries = _entries(100)
        summary = summarize(entries)
        assert summary["error_rate_pct"] == 10.0

    def test_top_source(self):
        entries = _entries(100)
        summary = summarize(entries)
        assert summary["top_source"] in ("api", "worker")
