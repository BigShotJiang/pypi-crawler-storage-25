"""Tests for logpilot.analyzer."""

import pytest
from datetime import datetime, timezone, timedelta

from logpilot.analyzer import (
    compute_stats,
    group_by_level,
    group_by_source,
    group_by_field,
    cluster_errors,
    time_histogram,
    detect_anomalies,
    top_messages,
    field_value_distribution,
    correlate_fields,
    _normalize_message,
    _similarity,
)
from logpilot.models import LogEntry, LogLevel


def _make_timed_entries() -> list[LogEntry]:
    """Create entries with timestamps for analysis."""
    base = datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    return [
        LogEntry(raw="", level=LogLevel.INFO, message="request handled",
                 timestamp=base, source="api", data={"method": "GET"}, is_json=True),
        LogEntry(raw="", level=LogLevel.INFO, message="request handled",
                 timestamp=base + timedelta(seconds=10), source="api",
                 data={"method": "POST"}, is_json=True),
        LogEntry(raw="", level=LogLevel.WARN, message="slow query",
                 timestamp=base + timedelta(seconds=20), source="db",
                 data={"duration_ms": "500"}, is_json=True),
        LogEntry(raw="", level=LogLevel.ERROR, message="connection failed to host 192.168.1.1",
                 timestamp=base + timedelta(seconds=30), source="api",
                 data={"status": "503"}, is_json=True),
        LogEntry(raw="", level=LogLevel.ERROR, message="connection failed to host 10.0.0.1",
                 timestamp=base + timedelta(seconds=40), source="api",
                 data={"status": "503"}, is_json=True),
    ]


class TestComputeStats:
    def test_basic_stats(self):
        entries = _make_timed_entries()
        stats = compute_stats(entries)
        assert stats.total == 5
        assert stats.by_level["INFO"] == 2
        assert stats.by_level["ERROR"] == 2

    def test_source_stats(self):
        entries = _make_timed_entries()
        stats = compute_stats(entries)
        assert stats.by_source["api"] == 4
        assert stats.by_source["db"] == 1

    def test_time_range(self):
        entries = _make_timed_entries()
        stats = compute_stats(entries)
        assert stats.first_timestamp is not None
        assert stats.last_timestamp is not None
        assert stats.duration_seconds == 40.0

    def test_empty_entries(self):
        stats = compute_stats([])
        assert stats.total == 0
        assert stats.error_rate == 0.0


class TestGroupBy:
    def test_group_by_level(self):
        entries = _make_timed_entries()
        groups = group_by_level(entries)
        assert len(groups[LogLevel.INFO]) == 2
        assert len(groups[LogLevel.ERROR]) == 2

    def test_group_by_source(self):
        entries = _make_timed_entries()
        groups = group_by_source(entries)
        assert "api" in groups
        assert "db" in groups
        assert len(groups["api"]) == 4

    def test_group_by_field(self):
        entries = _make_timed_entries()
        groups = group_by_field(entries, "method")
        assert "GET" in groups
        assert "POST" in groups


class TestClusterErrors:
    def test_cluster_similar_errors(self):
        entries = _make_timed_entries()
        clusters = cluster_errors(entries)
        assert len(clusters) >= 1
        # The two "connection failed" errors should cluster
        assert clusters[0].count >= 2

    def test_no_errors(self):
        entries = [
            LogEntry(raw="", level=LogLevel.INFO, message="ok"),
        ]
        clusters = cluster_errors(entries)
        assert len(clusters) == 0


class TestTimeHistogram:
    def test_basic_histogram(self):
        entries = _make_timed_entries()
        buckets = time_histogram(entries, bucket_seconds=60)
        assert len(buckets) >= 1
        total = sum(b.count for b in buckets)
        assert total == 5

    def test_error_counts(self):
        entries = _make_timed_entries()
        buckets = time_histogram(entries, bucket_seconds=60)
        total_errors = sum(b.error_count for b in buckets)
        assert total_errors == 2

    def test_no_timed_entries(self):
        entries = [LogEntry(raw="", message="no timestamp")]
        buckets = time_histogram(entries)
        assert len(buckets) == 0


class TestDetectAnomalies:
    def test_detect_no_anomalies(self):
        entries = [
            LogEntry(raw="", level=LogLevel.INFO, message="ok",
                     timestamp=datetime(2024, 1, 1, 12, i, tzinfo=timezone.utc))
            for i in range(10)
        ]
        report = detect_anomalies(entries)
        assert "No anomalies" in report.summary or len(report.error_spikes) == 0

    def test_detect_time_gap(self):
        entries = [
            LogEntry(raw="", level=LogLevel.INFO, message="before",
                     timestamp=datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc)),
            LogEntry(raw="", level=LogLevel.INFO, message="after",
                     timestamp=datetime(2024, 1, 1, 12, 5, tzinfo=timezone.utc)),
        ]
        report = detect_anomalies(entries, gap_threshold_seconds=30)
        assert len(report.slow_gaps) == 1
        assert report.slow_gaps[0][2] == 300.0  # 5 minutes


class TestTopMessages:
    def test_top_messages(self):
        entries = [
            LogEntry(raw="", message="hello"),
            LogEntry(raw="", message="hello"),
            LogEntry(raw="", message="world"),
        ]
        result = top_messages(entries, n=2)
        assert result[0] == ("hello", 2)
        assert result[1] == ("world", 1)

    def test_empty_entries(self):
        result = top_messages([], n=5)
        assert len(result) == 0


class TestFieldDistribution:
    def test_distribution(self):
        entries = _make_timed_entries()
        result = field_value_distribution(entries, "method")
        # Should have GET and POST
        values = dict(result)
        assert "GET" in values
        assert "POST" in values


class TestCorrelateFields:
    def test_correlate(self):
        entries = [
            LogEntry(raw="", level=LogLevel.INFO, message="test",
                     data={"source": "api", "method": "GET"},
                     extra={"source": "api", "method": "GET"}, is_json=True),
            LogEntry(raw="", level=LogLevel.INFO, message="test",
                     data={"source": "api", "method": "POST"},
                     extra={"source": "api", "method": "POST"}, is_json=True),
            LogEntry(raw="", level=LogLevel.INFO, message="test",
                     data={"source": "db", "method": "GET"},
                     extra={"source": "db", "method": "GET"}, is_json=True),
        ]
        result = correlate_fields(entries, "source", "method")
        assert "api" in result


class TestNormalize:
    def test_normalize_uuids(self):
        msg = "Failed for user 550e8400-e29b-41d4-a716-446655440000"
        result = _normalize_message(msg)
        assert "<UUID>" in result

    def test_normalize_ips(self):
        msg = "Connection to 192.168.1.1 failed"
        result = _normalize_message(msg)
        assert "<IP>" in result

    def test_normalize_numbers(self):
        msg = "Took 1500ms to process 42 items"
        result = _normalize_message(msg)
        assert "<N>" in result


class TestSimilarity:
    def test_identical(self):
        assert _similarity("hello world", "hello world") == 1.0

    def test_completely_different(self):
        assert _similarity("abc", "xyz") == 0.0

    def test_partial_overlap(self):
        score = _similarity("connection failed host", "connection failed server")
        assert 0.3 < score < 0.9

    def test_empty_strings(self):
        assert _similarity("", "") == 0.0
