"""Unit tests for waypointing_sdk.auth."""

from __future__ import annotations

import time

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from waypointing_sdk.auth import (
    EMPTY_CONTENT_SHA256,
    canonical_request,
    content_sha256,
    create_delegation_token,
    format_key_id,
    format_public_key,
    generate_keypair,
    sign,
    verify,
)


def test_generate_keypair_returns_pair() -> None:
    signing_key, verify_key = generate_keypair()
    assert signing_key.verify_key.encode() == verify_key.encode()
    assert len(verify_key.encode()) == 32


def test_format_public_key_is_prefixed_hex() -> None:
    _, vk = generate_keypair()
    formatted = format_public_key(vk)
    assert formatted.startswith("ed25519:")
    assert len(formatted) == len("ed25519:") + 64  # 32 bytes hex


def test_format_key_id_has_expected_shape() -> None:
    key_id = format_key_id("acme/agent")
    assert key_id.startswith("acme/agent.key-")
    # key-YYYY-MM suffix is 11 chars (key-2026-04)
    assert len(key_id) == len("acme/agent.key-YYYY-MM")


def test_content_sha256_matches_known_empty() -> None:
    assert content_sha256(b"") == EMPTY_CONTENT_SHA256


def test_canonical_request_sorts_headers() -> None:
    headers = {"Z-Header": "last", "A-Header": "first", "M-Header": "middle"}
    canonical = canonical_request("POST /v1/foo", headers)
    lines = canonical.strip().split("\n")
    assert lines[0] == "POST /v1/foo"
    assert lines[1:] == ["A-Header: first", "M-Header: middle", "Z-Header: last"]


def test_sign_and_verify_round_trip() -> None:
    signing_key, verify_key = generate_keypair()
    canonical = "POST /v1/foo\nA-Header: a\n"
    signature = sign(signing_key, canonical)
    assert signature.startswith("ed25519:")
    assert verify(verify_key, canonical, signature) is True


def test_verify_rejects_tampered_canonical() -> None:
    signing_key, verify_key = generate_keypair()
    canonical = "POST /v1/foo\nA-Header: a\n"
    signature = sign(signing_key, canonical)
    assert verify(verify_key, "POST /v1/bar\nA-Header: a\n", signature) is False


def test_verify_rejects_bad_prefix() -> None:
    _, verify_key = generate_keypair()
    with pytest.raises(ValueError):
        verify(verify_key, "canonical", "rs256:deadbeef")


def test_create_delegation_token_round_trips() -> None:
    """Regression test for the EdDSA signing bug.

    Before the fix, create_delegation_token passed raw 64-byte seed+public
    bytes to jwt.encode, which modern PyJWT rejects (expects an
    Ed25519PrivateKey object or PEM string). The fix uses
    Ed25519PrivateKey.from_private_bytes to serialize the PyNaCl key for
    PyJWT's EdDSA backend.
    """
    signing_key, verify_key = generate_keypair()

    token = create_delegation_token(
        signing_key,
        issuer="acme/caller",
        subject="acme/worker",
        audience=["acme/target"],
        scopes=["task.run", "task.read"],
        key_id="acme/caller.key-01",
        expires_in_seconds=60,
    )

    # Round-trip the token through jwt.decode using the matching Ed25519 public key
    public_key = Ed25519PublicKey.from_public_bytes(verify_key.encode())
    claims = jwt.decode(token, public_key, algorithms=["EdDSA"], audience="acme/target")

    assert claims["iss"] == "acme/caller"
    assert claims["sub"] == "acme/worker"
    assert claims["aud"] == ["acme/target"]
    assert claims["scopes"] == ["task.run", "task.read"]
    assert claims["re_delegate"] is False
    assert claims["max_chain_depth"] == 5
    assert claims["jti"].startswith("tok-")
    assert "iat" in claims and "exp" in claims
    assert claims["exp"] - claims["iat"] == 60

    # The kid header should be set so the verifier can look up the key
    header = jwt.get_unverified_header(token)
    assert header["kid"] == "acme/caller.key-01"


def test_create_delegation_token_parent_jti_chain() -> None:
    signing_key, verify_key = generate_keypair()

    token = create_delegation_token(
        signing_key,
        issuer="acme/caller",
        subject="acme/worker",
        audience=["acme/target"],
        scopes=["task.run"],
        key_id="acme/caller.key-01",
        re_delegate=True,
        max_chain_depth=3,
        parent_jti="tok-parent-1234",
    )

    public_key = Ed25519PublicKey.from_public_bytes(verify_key.encode())
    claims = jwt.decode(token, public_key, algorithms=["EdDSA"], audience="acme/target")

    assert claims["re_delegate"] is True
    assert claims["max_chain_depth"] == 3
    assert claims["parent_jti"] == "tok-parent-1234"


def test_create_delegation_token_rejects_wrong_audience() -> None:
    signing_key, verify_key = generate_keypair()

    token = create_delegation_token(
        signing_key,
        issuer="acme/caller",
        subject="acme/worker",
        audience=["acme/target"],
        scopes=["task.run"],
        key_id="acme/caller.key-01",
    )

    public_key = Ed25519PublicKey.from_public_bytes(verify_key.encode())
    with pytest.raises(jwt.InvalidAudienceError):
        jwt.decode(token, public_key, algorithms=["EdDSA"], audience="acme/other")


def test_create_delegation_token_rejects_wrong_public_key() -> None:
    """A token signed by one key must not verify with a different public key."""
    signing_key, _ = generate_keypair()
    _, other_verify_key = generate_keypair()

    token = create_delegation_token(
        signing_key,
        issuer="acme/caller",
        subject="acme/worker",
        audience=["acme/target"],
        scopes=["task.run"],
        key_id="acme/caller.key-01",
    )

    wrong_public_key = Ed25519PublicKey.from_public_bytes(other_verify_key.encode())
    with pytest.raises(jwt.InvalidSignatureError):
        jwt.decode(token, wrong_public_key, algorithms=["EdDSA"], audience="acme/target")


def test_create_delegation_token_expiry() -> None:
    signing_key, verify_key = generate_keypair()

    # Token expiring immediately
    token = create_delegation_token(
        signing_key,
        issuer="acme/caller",
        subject="acme/worker",
        audience=["acme/target"],
        scopes=["task.run"],
        key_id="acme/caller.key-01",
        expires_in_seconds=1,
    )
    # Advance past expiry
    time.sleep(2)

    public_key = Ed25519PublicKey.from_public_bytes(verify_key.encode())
    with pytest.raises(jwt.ExpiredSignatureError):
        jwt.decode(token, public_key, algorithms=["EdDSA"], audience="acme/target")
