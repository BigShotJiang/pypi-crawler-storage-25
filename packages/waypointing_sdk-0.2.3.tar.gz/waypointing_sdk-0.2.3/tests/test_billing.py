"""Unit tests for the ATP BillingClient."""

import json

import httpx
import pytest
import respx
from nacl.signing import SigningKey

from waypointing_sdk.billing import BillingClient


@pytest.fixture
def signing_key():
    return SigningKey.generate()


@pytest.fixture
def client(signing_key):
    c = BillingClient(
        base_url="http://billing.test",
        signing_key=signing_key,
        key_id="acme/caller.key-2026-03",
        agent_id="acme/caller",
    )
    yield c
    c.close()


@respx.mock
def test_get_balance(client):
    respx.get("http://billing.test/v1/billing/balance").mock(
        return_value=httpx.Response(200, json={
            "principal": "acme/caller",
            "balance_usd": 42.50,
        })
    )

    result = client.get_balance("acme/caller")
    assert result["principal"] == "acme/caller"
    assert result["balance_usd"] == 42.50


@respx.mock
def test_add_credits(client):
    respx.post("http://billing.test/v1/billing/credits").mock(
        return_value=httpx.Response(200, json={
            "principal": "acme/caller",
            "balance_usd": 142.50,
        })
    )

    result = client.add_credits("acme/caller", 100.00)
    assert result["balance_usd"] == 142.50


@respx.mock
def test_add_credits_sends_body(client):
    route = respx.post("http://billing.test/v1/billing/credits").mock(
        return_value=httpx.Response(200, json={"principal": "x", "balance_usd": 0})
    )

    client.add_credits("acme/caller", 50.0)
    body = json.loads(route.calls[0].request.content)
    assert body["principal"] == "acme/caller"
    assert body["amount_usd"] == 50.0


@respx.mock
def test_get_usage(client):
    respx.get("http://billing.test/v1/billing/usage").mock(
        return_value=httpx.Response(200, json={
            "principal": "acme/caller",
            "period": "2026-03",
            "summary": {
                "total_calls": 100,
                "total_cost_usd": 5.00,
                "unique_agents": 3,
                "unique_capabilities": 5,
            },
            "by_agent_capability": [],
            "daily_breakdown": [],
        })
    )

    result = client.get_usage("acme/caller", "2026-03")
    assert result["summary"]["total_calls"] == 100
    assert result["summary"]["total_cost_usd"] == 5.00


@respx.mock
def test_get_revenue(client):
    respx.get("http://billing.test/v1/billing/revenue").mock(
        return_value=httpx.Response(200, json={
            "agent_id": "acme/enricher",
            "period": "2026-03",
            "summary": {
                "total_calls": 500,
                "gross_revenue_usd": 25.00,
                "refunds_usd": 0.50,
                "adjusted_gross_usd": 24.50,
                "platform_fee_usd": 2.45,
                "net_revenue_usd": 22.05,
            },
        })
    )

    result = client.get_revenue("acme/enricher", "2026-03")
    assert result["summary"]["net_revenue_usd"] == 22.05


@respx.mock
def test_create_dispute(client):
    respx.post("http://billing.test/v1/billing/disputes").mock(
        return_value=httpx.Response(201, json={
            "id": "disp-123",
            "billing_record_id": "rec-456",
            "principal": "acme/caller",
            "provider_agent": "acme/enricher",
            "reason": "incorrect charge",
            "status": "open",
        })
    )

    result = client.create_dispute("rec-456", "incorrect charge")
    assert result["status"] == "open"
    assert result["id"] == "disp-123"


@respx.mock
def test_get_limits(client):
    respx.get("http://billing.test/v1/billing/limits").mock(
        return_value=httpx.Response(200, json={
            "principal": "acme/caller",
            "limits": {
                "max_per_call_usd": 1.0,
                "max_daily_usd": 50.0,
                "max_monthly_usd": 500.0,
            },
            "agent_limits": {"acme/enricher": 100.0},
        })
    )

    result = client.get_limits("acme/caller")
    assert result["limits"]["max_daily_usd"] == 50.0
    assert result["agent_limits"]["acme/enricher"] == 100.0


@respx.mock
def test_set_limits(client):
    route = respx.put("http://billing.test/v1/billing/limits").mock(
        return_value=httpx.Response(204)
    )

    client.set_limits(
        "acme/caller",
        max_per_call_usd=2.0,
        max_daily_usd=100.0,
        agent_limits={"acme/enricher": 50.0},
    )

    body = json.loads(route.calls[0].request.content)
    assert body["principal"] == "acme/caller"
    assert body["max_per_call_usd"] == 2.0
    assert body["max_daily_usd"] == 100.0
    assert body["agent_limits"]["acme/enricher"] == 50.0


@respx.mock
def test_set_limits_omits_none_fields(client):
    route = respx.put("http://billing.test/v1/billing/limits").mock(
        return_value=httpx.Response(204)
    )

    client.set_limits("acme/caller", max_monthly_usd=1000.0)

    body = json.loads(route.calls[0].request.content)
    assert body["principal"] == "acme/caller"
    assert body["max_monthly_usd"] == 1000.0
    assert "max_per_call_usd" not in body
    assert "max_daily_usd" not in body


@respx.mock
def test_auth_headers_present(client):
    route = respx.get("http://billing.test/v1/billing/balance").mock(
        return_value=httpx.Response(200, json={"principal": "x", "balance_usd": 0})
    )

    client.get_balance("acme/caller")

    req = route.calls[0].request
    assert req.headers["Agent-From"] == "acme/caller"
    assert req.headers["Agent-Key-ID"] == "acme/caller.key-2026-03"
    assert req.headers["Agent-Signature"].startswith("ed25519:")
    assert "Timestamp" in req.headers


@respx.mock
def test_http_error_raises(client):
    respx.get("http://billing.test/v1/billing/balance").mock(
        return_value=httpx.Response(401, json={"status": "error"})
    )

    with pytest.raises(httpx.HTTPStatusError):
        client.get_balance("acme/caller")
