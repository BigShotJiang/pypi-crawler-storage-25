"""Unit tests for the ATP GatewayClient."""

import json

import httpx
import pytest
import respx
from nacl.signing import SigningKey

from waypointing_sdk.gateway import GatewayClient, SSEEvent


@pytest.fixture
def signing_key():
    return SigningKey.generate()


@pytest.fixture
def client(signing_key):
    c = GatewayClient(
        base_url="http://gateway.test",
        signing_key=signing_key,
        key_id="acme/caller.key-2026-03",
        agent_id="acme/caller",
    )
    yield c
    c.close()


@respx.mock
def test_task_success(client):
    response_body = {
        "status": "success",
        "output": {"result": "enriched"},
        "metadata": {
            "request_id": "req-abc123",
            "agent_id": "acme/enricher",
            "capability": "lead.enrich",
            "latency_ms": 42,
            "cost_usd": 0.05,
        },
    }
    respx.post("http://gateway.test/v1/agents/acme/enricher/task/lead.enrich").mock(
        return_value=httpx.Response(200, json=response_body)
    )

    result = client.task("acme", "enricher", "lead.enrich", {"email": "j@co.com"})
    assert result["status"] == "success"
    assert result["output"]["result"] == "enriched"
    assert result["metadata"]["cost_usd"] == 0.05


@respx.mock
def test_task_sends_auth_headers(client):
    route = respx.post("http://gateway.test/v1/agents/acme/test/task/cap").mock(
        return_value=httpx.Response(200, json={"status": "success", "metadata": {}})
    )

    client.task("acme", "test", "cap", {"x": 1})

    req = route.calls[0].request
    assert req.headers["Agent-From"] == "acme/caller"
    assert req.headers["Agent-Key-ID"] == "acme/caller.key-2026-03"
    assert "Agent-Signature" in req.headers
    assert req.headers["Agent-Signature"].startswith("ed25519:")
    assert "Timestamp" in req.headers
    assert "Request-ID" in req.headers


@respx.mock
def test_task_with_cost_and_latency_headers(client):
    route = respx.post("http://gateway.test/v1/agents/acme/test/task/cap").mock(
        return_value=httpx.Response(200, json={"status": "success", "metadata": {}})
    )

    client.task("acme", "test", "cap", {}, max_cost_usd=1.5, max_latency_ms=500)

    req = route.calls[0].request
    assert req.headers["Max-Cost"] == "1.5"
    assert req.headers["Max-Latency"] == "500"


@respx.mock
def test_task_with_idempotency_key(client):
    route = respx.post("http://gateway.test/v1/agents/acme/test/task/cap").mock(
        return_value=httpx.Response(200, json={"status": "success", "metadata": {}})
    )

    client.task("acme", "test", "cap", {}, idempotency_key="idem-123")

    req = route.calls[0].request
    assert req.headers["Idempotency-Key"] == "idem-123"


@respx.mock
def test_cancel(client):
    respx.post("http://gateway.test/v1/agents/acme/test/task/cancel").mock(
        return_value=httpx.Response(200, json={
            "status": "cancelled",
            "target_request_id": "req-target",
            "request_id": "req-cancel",
        })
    )

    result = client.cancel("acme", "test", "req-target")
    assert result["status"] == "cancelled"
    assert result["target_request_id"] == "req-target"


@respx.mock
def test_negotiate(client):
    respx.post("http://gateway.test/v1/agents/acme/test/negotiate/lead.enrich").mock(
        return_value=httpx.Response(200, json={
            "agent_id": "acme/test",
            "capability": "lead.enrich",
            "available": True,
            "estimated_cost_usd": 0.05,
            "estimated_latency_ms": 100,
        })
    )

    result = client.negotiate("acme", "test", "lead.enrich", max_cost_usd=1.0)
    assert result["available"] is True
    assert result["estimated_cost_usd"] == 0.05


@respx.mock
def test_delegate(client):
    respx.post("http://gateway.test/v1/delegate/lead.enrich").mock(
        return_value=httpx.Response(200, json={
            "status": "success",
            "output": {"company": "Acme Inc"},
            "metadata": {
                "request_id": "req-del",
                "agent_id": "best/agent",
                "capability": "lead.enrich",
                "latency_ms": 120,
            },
        })
    )

    result = client.delegate(
        "lead.enrich",
        {"email": "j@co.com"},
        optimize_for="cost",
        max_cost_usd=0.10,
        fallback=True,
    )
    assert result["status"] == "success"
    assert result["metadata"]["agent_id"] == "best/agent"


@respx.mock
def test_delegate_sends_body_fields(client):
    route = respx.post("http://gateway.test/v1/delegate/cap").mock(
        return_value=httpx.Response(200, json={"status": "success", "metadata": {}})
    )

    client.delegate(
        "cap", {"x": 1},
        optimize_for="latency",
        prefer_agents=["a/b"],
        exclude_agents=["c/d"],
        max_fallback_attempts=3,
    )

    body = json.loads(route.calls[0].request.content)
    assert body["optimize_for"] == "latency"
    assert body["prefer_agents"] == ["a/b"]
    assert body["exclude_agents"] == ["c/d"]
    assert body["max_fallback_attempts"] == 3


@respx.mock
def test_task_http_error_raises(client):
    respx.post("http://gateway.test/v1/agents/acme/test/task/cap").mock(
        return_value=httpx.Response(429, json={
            "status": "error",
            "error": {"code": 429, "type": "rate_limit_exceeded", "message": "too fast"},
        })
    )

    with pytest.raises(httpx.HTTPStatusError) as exc_info:
        client.task("acme", "test", "cap", {})
    assert exc_info.value.response.status_code == 429


def test_sse_event_dataclass():
    event = SSEEvent(event="message", data='{"hello": "world"}', id="1")
    assert event.event == "message"
    assert event.data == '{"hello": "world"}'
    assert event.id == "1"
