"""Ed25519 signing and JWT creation for ATP authentication."""

from __future__ import annotations

import hashlib
import time
import uuid

import jwt
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from nacl.signing import SigningKey, VerifyKey


def generate_keypair() -> tuple[SigningKey, VerifyKey]:
    """Generate an Ed25519 key pair."""
    signing_key = SigningKey.generate()
    verify_key = signing_key.verify_key
    return signing_key, verify_key


def format_public_key(verify_key: VerifyKey) -> str:
    """Format a public key as 'ed25519:<hex>'."""
    return f"ed25519:{verify_key.encode().hex()}"


def format_key_id(agent_short_id: str) -> str:
    """Generate a key ID in the format '{agent_short_id}.key-{YYYY-MM}'."""
    from datetime import datetime, timezone

    now = datetime.now(timezone.utc)
    return f"{agent_short_id}.key-{now.strftime('%Y-%m')}"


def content_sha256(body: bytes) -> str:
    """Compute SHA-256 hash of the body, hex-encoded."""
    return hashlib.sha256(body).hexdigest()


EMPTY_CONTENT_SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"


def canonical_request(command_line: str, headers: dict[str, str]) -> str:
    """Construct the canonical string for signing."""
    lines = [command_line]
    for key in sorted(headers.keys()):
        value = headers[key].replace("\r", "").replace("\n", "")
        lines.append(f"{key}: {value}")
    return "\n".join(lines) + "\n"


def sign(signing_key: SigningKey, canonical: str) -> str:
    """Sign the canonical string and return 'ed25519:<hex>'."""
    signed = signing_key.sign(canonical.encode())
    return f"ed25519:{signed.signature.hex()}"


def verify(verify_key: VerifyKey, canonical: str, signature: str) -> bool:
    """Verify an Ed25519 signature."""
    if not signature.startswith("ed25519:"):
        raise ValueError("Signature must start with 'ed25519:'")
    sig_bytes = bytes.fromhex(signature[len("ed25519:") :])
    try:
        verify_key.verify(canonical.encode(), sig_bytes)
        return True
    except Exception:
        return False


def create_delegation_token(
    signing_key: SigningKey,
    *,
    issuer: str,
    subject: str,
    audience: list[str],
    scopes: list[str],
    key_id: str,
    re_delegate: bool = False,
    max_chain_depth: int = 5,
    parent_jti: str | None = None,
    expires_in_seconds: int = 3600,
) -> str:
    """Create a signed JWT delegation token."""
    now = int(time.time())
    jti = f"tok-{uuid.uuid4().hex[:16]}"

    payload = {
        "iss": issuer,
        "sub": subject,
        "aud": audience,
        "scopes": scopes,
        "re_delegate": re_delegate,
        "max_chain_depth": max_chain_depth,
        "iat": now,
        "exp": now + expires_in_seconds,
        "jti": jti,
    }
    if parent_jti:
        payload["parent_jti"] = parent_jti

    headers = {"kid": key_id}

    # PyJWT's EdDSA backend expects a cryptography Ed25519PrivateKey, not raw bytes
    private_key = Ed25519PrivateKey.from_private_bytes(signing_key.encode())
    return jwt.encode(payload, private_key, algorithm="EdDSA", headers=headers)
