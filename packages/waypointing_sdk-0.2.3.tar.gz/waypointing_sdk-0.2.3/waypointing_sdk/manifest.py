"""Manifest builder and validator for ATP agents."""

from __future__ import annotations

import json
import re
from pathlib import Path

from waypointing_sdk.models import (
    AgentManifest,
    Capability,
    Endpoint,
    Execution,
    ManifestAgent,
    ManifestOwner,
    Pricing,
)

CAPABILITY_PATTERN = re.compile(r"^[a-z][a-z0-9]*(\.[a-z][a-z0-9]*){1,4}$")
OWNER_PATTERN = re.compile(r"^[a-z][a-z0-9](?:[a-z0-9-]*[a-z0-9])?$")


class ManifestBuilder:
    """Fluent builder for constructing ATP agent manifests."""

    def __init__(self, agent_id: str, invoke_url: str):
        self._agent_id = agent_id
        parts = agent_id.split("/")
        self._owner = parts[0] if len(parts) == 2 else ""
        self._description = ""
        self._tags: list[str] = []
        self._agent_type = "independent"
        self._provenance = "native"
        self._contact = ""
        self._invoke_url = invoke_url
        self._capabilities: list[Capability] = []

    def description(self, desc: str) -> ManifestBuilder:
        self._description = desc
        return self

    def tags(self, *tags: str) -> ManifestBuilder:
        self._tags = list(tags)
        return self

    def agent_type(self, t: str) -> ManifestBuilder:
        self._agent_type = t
        return self

    def provenance(self, p: str) -> ManifestBuilder:
        self._provenance = p
        return self

    def contact(self, email: str) -> ManifestBuilder:
        self._contact = email
        return self

    def add_capability(self, capability: Capability) -> ManifestBuilder:
        self._capabilities.append(capability)
        return self

    def build(self) -> AgentManifest:
        return AgentManifest(
            agent=ManifestAgent(
                id=self._agent_id,
                description=self._description,
                tags=self._tags,
                type=self._agent_type,
                provenance=self._provenance,
            ),
            owner=ManifestOwner(
                name=self._owner,
                contact=self._contact,
            ),
            capabilities=self._capabilities,
            execution=Execution(),
            endpoint=Endpoint(invoke_url=self._invoke_url),
        )


def validate_manifest(manifest: AgentManifest) -> list[str]:
    """Validate a manifest and return a list of error messages (empty = valid)."""
    errors: list[str] = []

    # Validate agent ID format
    parts = manifest.agent.id.split("/")
    if len(parts) != 2:
        errors.append(f"Invalid agent ID format: {manifest.agent.id}")
    else:
        owner, name = parts
        if not OWNER_PATTERN.match(owner):
            errors.append(f"Invalid owner namespace: {owner}")
        if len(owner) < 2 or len(owner) > 64:
            errors.append(f"Owner must be 2-64 characters: {owner}")

    # Validate capabilities
    for cap in manifest.capabilities:
        if not CAPABILITY_PATTERN.match(cap.name):
            errors.append(f"Invalid capability name: {cap.name}")
        if len(cap.name) < 3 or len(cap.name) > 64:
            errors.append(f"Capability name must be 3-64 characters: {cap.name}")
        if not cap.description:
            errors.append(f"Capability {cap.name} missing description")

    # Validate endpoint
    if not manifest.endpoint.invoke_url:
        errors.append("Missing invoke_url")

    return errors


def validate_manifest_file(path: str | Path) -> list[str]:
    """Validate a manifest JSON file."""
    data = Path(path).read_text()
    try:
        manifest = AgentManifest.model_validate_json(data)
    except Exception as e:
        return [f"Invalid JSON: {e}"]
    return validate_manifest(manifest)
