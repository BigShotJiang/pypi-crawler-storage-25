"""HTTP client for the ATP Registry API."""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any

import httpx
from nacl.signing import SigningKey

from waypointing_sdk.auth import canonical_request, content_sha256, sign, EMPTY_CONTENT_SHA256
from waypointing_sdk.models import AgentManifest


class RegistryClient:
    """HTTP client for the ATP Registry.

    For public (unauthenticated) endpoints, no credentials are needed::

        client = RegistryClient("http://localhost:8080")
        agent = client.get_agent("acme/my-agent")

    For authenticated endpoints, provide signing credentials::

        client = RegistryClient(
            "http://localhost:8080",
            signing_key=my_key,
            key_id="acme/my-agent.key-2026-03",
            agent_id="acme/my-agent",
        )
        client.create_namespace("acme", "admin@acme.io")
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8080",
        timeout: float = 30.0,
        signing_key: SigningKey | None = None,
        key_id: str | None = None,
        agent_id: str | None = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.client = httpx.Client(base_url=self.base_url, timeout=timeout)
        self._signing_key = signing_key
        self._key_id = key_id
        self._agent_id = agent_id

    def close(self) -> None:
        self.client.close()

    def __enter__(self) -> RegistryClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # --- Auth helpers ---

    def _sign_request(
        self, method: str, path: str, body: bytes | None = None,
    ) -> dict[str, str]:
        """Build auth headers for a signed request."""
        if not self._signing_key or not self._key_id or not self._agent_id:
            return {}

        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        request_id = f"req-{uuid.uuid4().hex[:8]}"
        body_hash = content_sha256(body) if body else EMPTY_CONTENT_SHA256

        # Agent-To is the registry itself; use "atp/registry" as convention
        agent_to = "atp/registry"

        headers = {
            "Agent-From": self._agent_id,
            "Agent-To": agent_to,
            "Content-SHA256": body_hash,
            "Request-ID": request_id,
            "Timestamp": now,
        }

        command_line = f"{method} {path}"
        canonical = canonical_request(command_line, headers)
        signature = sign(self._signing_key, canonical)

        return {
            "Agent-From": self._agent_id,
            "Agent-To": agent_to,
            "Agent-Key-ID": self._key_id,
            "Agent-Signature": signature,
            "Timestamp": now,
            "Request-ID": request_id,
        }

    def _post(self, path: str, payload: Any) -> httpx.Response:
        """POST with optional request signing."""
        body = json.dumps(payload).encode()
        auth_headers = self._sign_request("POST", path, body)
        resp = self.client.post(path, content=body, headers={
            "Content-Type": "application/json",
            **auth_headers,
        })
        resp.raise_for_status()
        return resp

    # --- Namespace ---

    def create_namespace(self, name: str, contact_email: str) -> dict[str, Any]:
        resp = self._post(
            "/v1/namespaces",
            {"name": name, "contact_email": contact_email},
        )
        return resp.json()

    def get_namespace(self, name: str) -> dict[str, Any]:
        resp = self.client.get(f"/v1/namespaces/{name}")
        resp.raise_for_status()
        return resp.json()

    # --- Agent ---

    def publish_agent(self, manifest: AgentManifest, version: str) -> dict[str, Any]:
        resp = self._post(
            "/v1/agents",
            {"manifest": manifest.model_dump(), "version": version},
        )
        return resp.json()

    def get_agent(self, short_id: str) -> dict[str, Any]:
        resp = self.client.get(f"/v1/agents/{short_id}")
        resp.raise_for_status()
        return resp.json()

    def search(
        self,
        capability: str | None = None,
        tags: list[str] | None = None,
        owner: str | None = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"limit": limit}
        if capability:
            body["capability"] = capability
        if tags:
            body["tags"] = tags
        if owner:
            body["owner"] = owner

        resp = self._post("/v1/agents/search", body)
        return resp.json()

    # --- Discovery ---

    def discover(self, short_id: str) -> dict[str, Any]:
        resp = self.client.get(f"/v1/agents/{short_id}/capabilities")
        resp.raise_for_status()
        return resp.json()

    # --- Keys ---

    def register_key(self, short_id: str, key_id: str, public_key: str) -> dict[str, Any]:
        resp = self._post(
            f"/v1/agents/{short_id}/keys",
            {"key_id": key_id, "public_key": public_key},
        )
        return resp.json()

    # --- Versions ---

    def list_versions(self, short_id: str) -> dict[str, Any]:
        resp = self.client.get(f"/v1/agents/{short_id}/versions")
        resp.raise_for_status()
        return resp.json()

    def get_version(self, short_id: str, version: str) -> dict[str, Any]:
        resp = self.client.get(f"/v1/agents/{short_id}/versions/{version}")
        resp.raise_for_status()
        return resp.json()
