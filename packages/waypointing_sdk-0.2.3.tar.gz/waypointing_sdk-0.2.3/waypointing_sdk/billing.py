"""HTTP client for the ATP Billing API.

The billing service verifies request signatures against a canonical string
whose first line is a service-specific command (``BILLING.BALANCE`` and
friends), not the HTTP method+path. See
``internal/middleware/auth.go:BillingCommandResolver`` for the mapping.
Every call below MUST pass the matching ``command_line`` to ``_sign_request``
or the server will compute a different canonical and reject the signature
with ``401 signature_mismatch``.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any

import httpx
from nacl.signing import SigningKey

from waypointing_sdk.auth import canonical_request, content_sha256, sign, EMPTY_CONTENT_SHA256


class BillingClient:
    """HTTP client for the ATP Billing service.

    Example::

        client = BillingClient(
            "http://localhost:8082",
            signing_key=my_key,
            key_id="acme/caller.key-2026-03",
            agent_id="acme/caller",
        )
        balance = client.get_balance("acme/caller")
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8082",
        timeout: float = 30.0,
        signing_key: SigningKey | None = None,
        key_id: str | None = None,
        agent_id: str | None = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.client = httpx.Client(base_url=self.base_url, timeout=timeout)
        self._signing_key = signing_key
        self._key_id = key_id
        self._agent_id = agent_id

    def close(self) -> None:
        self.client.close()

    def __enter__(self) -> BillingClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def _sign_request(
        self,
        method: str,
        path: str,
        command_line: str,
        body: bytes | None = None,
    ) -> dict[str, str]:
        if not self._signing_key or not self._key_id or not self._agent_id:
            return {}

        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        request_id = f"req-{uuid.uuid4().hex[:8]}"
        body_hash = content_sha256(body) if body else EMPTY_CONTENT_SHA256

        agent_to = "atp/billing"
        headers = {
            "Agent-From": self._agent_id,
            "Agent-To": agent_to,
            "Content-SHA256": body_hash,
            "Request-ID": request_id,
            "Timestamp": now,
        }

        canonical = canonical_request(command_line, headers)
        signature = sign(self._signing_key, canonical)

        return {
            "Agent-From": self._agent_id,
            "Agent-To": agent_to,
            "Agent-Key-ID": self._key_id,
            "Agent-Signature": signature,
            "Timestamp": now,
            "Request-ID": request_id,
        }

    def _get(self, path: str, command_line: str) -> httpx.Response:
        auth_headers = self._sign_request("GET", path, command_line)
        resp = self.client.get(path, headers=auth_headers)
        resp.raise_for_status()
        return resp

    def _post(self, path: str, payload: Any, command_line: str) -> httpx.Response:
        body = json.dumps(payload).encode()
        auth_headers = self._sign_request("POST", path, command_line, body)
        resp = self.client.post(path, content=body, headers={
            "Content-Type": "application/json",
            **auth_headers,
        })
        resp.raise_for_status()
        return resp

    def _put(self, path: str, payload: Any, command_line: str) -> httpx.Response:
        body = json.dumps(payload).encode()
        auth_headers = self._sign_request("PUT", path, command_line, body)
        resp = self.client.put(path, content=body, headers={
            "Content-Type": "application/json",
            **auth_headers,
        })
        resp.raise_for_status()
        return resp

    # --- Balance ---

    def get_balance(self, principal: str) -> dict[str, Any]:
        """Get prepaid credit balance for a principal."""
        resp = self._get(f"/v1/billing/balance?principal={principal}", "BILLING.BALANCE")
        return resp.json()

    def add_credits(self, principal: str, amount_usd: float) -> dict[str, Any]:
        """Add prepaid credits to an account."""
        resp = self._post("/v1/billing/credits", {
            "principal": principal,
            "amount_usd": amount_usd,
        }, "BILLING.CREDITS")
        return resp.json()

    # --- Usage & Revenue ---

    def get_usage(self, principal: str, period: str | None = None) -> dict[str, Any]:
        """Get usage report for a principal."""
        params = f"principal={principal}"
        if period:
            params += f"&period={period}"
        resp = self._get(f"/v1/billing/usage?{params}", "BILLING.USAGE")
        return resp.json()

    def get_revenue(self, provider_agent: str, period: str | None = None) -> dict[str, Any]:
        """Get revenue report for a provider agent."""
        params = f"agent_id={provider_agent}"
        if period:
            params += f"&period={period}"
        resp = self._get(f"/v1/billing/revenue?{params}", "BILLING.REVENUE")
        return resp.json()

    # --- Disputes ---

    def create_dispute(self, billing_record_id: str, reason: str) -> dict[str, Any]:
        """Create a billing dispute."""
        resp = self._post("/v1/billing/disputes", {
            "billing_record_id": billing_record_id,
            "reason": reason,
        }, "BILLING.DISPUTES")
        return resp.json()

    # --- Spending Limits ---

    def get_limits(self, principal: str) -> dict[str, Any]:
        """Get spending limits for a principal."""
        resp = self._get(f"/v1/billing/limits?principal={principal}", "BILLING.GET_LIMITS")
        return resp.json()

    def set_limits(
        self,
        principal: str,
        *,
        max_per_call_usd: float | None = None,
        max_daily_usd: float | None = None,
        max_monthly_usd: float | None = None,
        alert_threshold_pct: int | None = None,
        agent_limits: dict[str, float] | None = None,
    ) -> None:
        """Set spending limits for a principal."""
        payload: dict[str, Any] = {"principal": principal}
        if max_per_call_usd is not None:
            payload["max_per_call_usd"] = max_per_call_usd
        if max_daily_usd is not None:
            payload["max_daily_usd"] = max_daily_usd
        if max_monthly_usd is not None:
            payload["max_monthly_usd"] = max_monthly_usd
        if alert_threshold_pct is not None:
            payload["alert_threshold_percent"] = alert_threshold_pct
        if agent_limits:
            payload["agent_limits"] = agent_limits

        self._put("/v1/billing/limits", payload, "BILLING.SET_LIMITS")
