"""Pydantic models for ATP manifest, capability, and related types."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class Pricing(BaseModel):
    model: str = "per_call"
    price_usd: float | None = None
    unit: str | None = None
    tiers: list[dict[str, Any]] | None = None


class RateLimit(BaseModel):
    requests_per_minute: int = 200
    requests_per_day: int = 50000
    burst_limit: int = 20


class SLA(BaseModel):
    target_uptime: float = 0.999
    target_latency_p95_ms: int = 2000
    maintenance_window: str | None = None


class Capability(BaseModel):
    name: str
    description: str
    tags: list[str] = Field(default_factory=list)
    supported_languages: list[str] = Field(default_factory=list)
    supported_regions: list[str] = Field(default_factory=list)
    input_schema: dict[str, Any] = Field(default_factory=dict)
    output_schema: dict[str, Any] = Field(default_factory=dict)
    pricing: Pricing = Field(default_factory=Pricing)
    constraints: dict[str, Any] | None = None
    rate_limit: RateLimit | None = None
    sla: SLA | None = None


class ManifestAgent(BaseModel):
    id: str
    description: str = ""
    tags: list[str] = Field(default_factory=list)
    type: str = "independent"
    status: str = "active"
    provenance: str = "native"


class ManifestOwner(BaseModel):
    name: str
    org_id: str | None = None
    contact: str = ""
    verification_status: str = "unverified"


class Execution(BaseModel):
    execution_model: str = "stateless"
    supported_streaming: bool = False


class Endpoint(BaseModel):
    invoke_url: str
    health_url: str | None = None
    region: str | None = None


class AgentManifest(BaseModel):
    record_schema_version: str = "1.0"
    agent: ManifestAgent
    owner: ManifestOwner
    capabilities: list[Capability] = Field(default_factory=list)
    execution: Execution = Field(default_factory=Execution)
    endpoint: Endpoint


class Compliance(BaseModel):
    certifications: list[str] = Field(default_factory=list)
    data_residency: list[str] = Field(default_factory=list)
    frameworks: list[str] = Field(default_factory=list)
    governance_platform: str | None = None
    audit_url: str | None = None


class ErrorResponse(BaseModel):
    status: str = "error"
    error: dict[str, Any] = Field(default_factory=dict)


# --- Gateway models ---


class TaskResponse(BaseModel):
    status: str
    output: dict[str, Any] | None = None
    error: dict[str, Any] | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class NegotiateOffer(BaseModel):
    agent_id: str
    capability: str
    available: bool
    estimated_cost_usd: float | None = None
    estimated_latency_ms: int | None = None
    constraint_violations: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] | None = None


# --- Billing models ---


class Balance(BaseModel):
    principal: str
    balance_usd: float


class UsageSummary(BaseModel):
    total_calls: int = 0
    total_cost_usd: float = 0.0
    unique_agents: int = 0
    unique_capabilities: int = 0


class UsageReport(BaseModel):
    principal: str
    period: str
    summary: UsageSummary = Field(default_factory=UsageSummary)
    by_agent_capability: list[dict[str, Any]] = Field(default_factory=list)
    daily_breakdown: list[dict[str, Any]] = Field(default_factory=list)


class RevenueSummary(BaseModel):
    total_calls: int = 0
    gross_revenue_usd: float = 0.0
    refunds_usd: float = 0.0
    adjusted_gross_usd: float = 0.0
    platform_fee_usd: float = 0.0
    net_revenue_usd: float = 0.0


class RevenueReport(BaseModel):
    agent_id: str
    period: str
    summary: RevenueSummary = Field(default_factory=RevenueSummary)


class SpendingLimits(BaseModel):
    principal: str
    limits: dict[str, Any] = Field(default_factory=dict)
    agent_limits: dict[str, float] | None = None


class Dispute(BaseModel):
    id: str
    billing_record_id: str
    principal: str
    provider_agent: str
    reason: str
    status: str = "open"
    resolution_notes: str | None = None
    created_at: str | None = None
    resolved_at: str | None = None
