"""Top-level WaypointClient with `from_env()` factory.

The recommended way to construct a Waypoint client is via environment
variables. After clicking "Generate API Key" on the portal billing page,
copy the ready-to-paste ``.env`` snippet into your project. The three
``WAYPOINT_*`` values are generated per account; your values will differ::

    WAYPOINT_AGENT_ID=users/u-<your-id>
    WAYPOINT_KEY_ID=wk_<timestamp>_<random>
    WAYPOINT_PRIVATE_KEY=<64-char hex>  # shown exactly once

Optional overrides::

    WAYPOINT_GATEWAY_URL   (default https://gateway.waypoint.ing)
    WAYPOINT_REGISTRY_URL  (default https://registry.waypoint.ing)
    WAYPOINT_BILLING_URL   (default https://billing.waypoint.ing)
    WAYPOINT_TRUST_URL     (default https://trust.waypoint.ing)

Then::

    from waypointing_sdk import WaypointClient
    waypoint = WaypointClient.from_env()
    result = waypoint.task("jhibird/heyspark.generate", {"prompt": "hello"})
"""

from __future__ import annotations

import os
import re
from typing import Any, Mapping

from nacl.signing import SigningKey

from waypointing_sdk.billing import BillingClient
from waypointing_sdk.client import RegistryClient
from waypointing_sdk.gateway import GatewayClient
from waypointing_sdk.models import TaskResponse


# All four services share api.waypoint.ing in production — path-based
# nginx routing dispatches to gateway/registry/billing/trust by path prefix.
# For self-hosted deployments, override via WAYPOINT_*_URL env vars.
_DEFAULT_API_URL = "https://api.waypoint.ing"
_DEFAULT_GATEWAY_URL = _DEFAULT_API_URL
_DEFAULT_REGISTRY_URL = _DEFAULT_API_URL
_DEFAULT_BILLING_URL = _DEFAULT_API_URL

_HEX64_RE = re.compile(r"^[0-9a-fA-F]{64}$")


class WaypointClient:
    """Convenience entry point bundling gateway, registry, and billing clients."""

    def __init__(
        self,
        agent_id: str,
        key_id: str,
        signing_key: SigningKey,
        gateway_url: str | None = None,
        registry_url: str | None = None,
        billing_url: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        self.agent_id = agent_id
        self.gateway = GatewayClient(
            base_url=gateway_url or _DEFAULT_GATEWAY_URL,
            timeout=timeout,
            signing_key=signing_key,
            key_id=key_id,
            agent_id=agent_id,
        )
        self.registry = RegistryClient(
            base_url=registry_url or _DEFAULT_REGISTRY_URL,
            timeout=timeout,
            signing_key=signing_key,
            key_id=key_id,
            agent_id=agent_id,
        )
        self.billing = BillingClient(
            base_url=billing_url or _DEFAULT_BILLING_URL,
            timeout=timeout,
            signing_key=signing_key,
            key_id=key_id,
            agent_id=agent_id,
        )

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> "WaypointClient":
        """Construct a WaypointClient from `WAYPOINT_*` environment variables.

        Raises ValueError with a clear message if any required variable is
        missing or the private key is malformed.
        """
        env = env if env is not None else os.environ

        agent_id = env.get("WAYPOINT_AGENT_ID")
        key_id = env.get("WAYPOINT_KEY_ID")
        private_key_hex = env.get("WAYPOINT_PRIVATE_KEY")

        missing = [
            name
            for name, value in (
                ("WAYPOINT_AGENT_ID", agent_id),
                ("WAYPOINT_KEY_ID", key_id),
                ("WAYPOINT_PRIVATE_KEY", private_key_hex),
            )
            if not value
        ]
        if missing:
            raise ValueError(
                "WaypointClient.from_env: missing required environment variable(s): "
                f"{', '.join(missing)}. Generate an API key at "
                "https://waypoint.ing/dashboard/billing and copy the .env snippet."
            )

        assert private_key_hex is not None  # mypy
        if not _HEX64_RE.match(private_key_hex):
            raise ValueError(
                "WaypointClient.from_env: WAYPOINT_PRIVATE_KEY must be 64 hex "
                "characters (the Ed25519 seed)."
            )

        signing_key = SigningKey(bytes.fromhex(private_key_hex))
        assert agent_id is not None  # mypy
        assert key_id is not None  # mypy
        return cls(
            agent_id=agent_id,
            key_id=key_id,
            signing_key=signing_key,
            gateway_url=env.get("WAYPOINT_GATEWAY_URL"),
            registry_url=env.get("WAYPOINT_REGISTRY_URL"),
            billing_url=env.get("WAYPOINT_BILLING_URL"),
        )

    def task(
        self,
        target: str,
        input: dict[str, Any],
    ) -> TaskResponse:
        """Invoke an agent capability by its dotted target string.

        Example::

            waypoint.task("jhibird/heyspark.generate", {"prompt": "hello"})

        This is a non-streaming convenience wrapper. For streaming responses,
        use ``client.gateway.task_stream(owner, name, capability, input)``
        directly. For more control over options like max_cost_usd, delegation
        tokens, or idempotency keys, use ``client.gateway.task(...)`` directly.
        """
        owner, name, capability = _parse_target(target)
        return self.gateway.task(owner, name, capability, input)

    def close(self) -> None:
        self.gateway.close()
        self.registry.close()
        self.billing.close()

    def __enter__(self) -> "WaypointClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


def _parse_target(target: str) -> tuple[str, str, str]:
    slash = target.find("/")
    dot = target.find(".", slash + 1)
    if slash < 1 or dot < 0 or dot == len(target) - 1:
        raise ValueError(
            f'WaypointClient: invalid task target "{target}", expected "owner/agent.capability"'
        )
    return target[:slash], target[slash + 1 : dot], target[dot + 1 :]
