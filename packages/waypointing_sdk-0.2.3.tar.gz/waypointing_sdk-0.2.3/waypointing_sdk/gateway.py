"""HTTP client for the ATP Gateway API (TASK, CANCEL, NEGOTIATE, DELEGATE)."""

from __future__ import annotations

import json
import uuid
from collections.abc import Iterator
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import httpx
from nacl.signing import SigningKey

from waypointing_sdk.auth import canonical_request, content_sha256, sign, EMPTY_CONTENT_SHA256


@dataclass
class SSEEvent:
    """A parsed Server-Sent Event."""

    event: str | None = None
    data: str = ""
    id: str | None = None


class GatewayClient:
    """HTTP client for the ATP Gateway.

    Example::

        client = GatewayClient(
            "http://localhost:8081",
            signing_key=my_key,
            key_id="acme/caller.key-2026-03",
            agent_id="acme/caller",
        )
        result = client.task("acme", "lead-enricher", "lead.enrich", {"email": "j@co.com"})
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8081",
        timeout: float = 30.0,
        signing_key: SigningKey | None = None,
        key_id: str | None = None,
        agent_id: str | None = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.client = httpx.Client(base_url=self.base_url, timeout=timeout)
        self._signing_key = signing_key
        self._key_id = key_id
        self._agent_id = agent_id

    def close(self) -> None:
        self.client.close()

    def __enter__(self) -> GatewayClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def _sign_request(
        self, method: str, path: str, body: bytes | None = None,
        command_line: str | None = None,
    ) -> dict[str, str]:
        if not self._signing_key or not self._key_id or not self._agent_id:
            return {}

        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        request_id = f"req-{uuid.uuid4().hex[:8]}"
        body_hash = content_sha256(body) if body else EMPTY_CONTENT_SHA256

        agent_to = "atp/gateway"
        headers = {
            "Agent-From": self._agent_id,
            "Agent-To": agent_to,
            "Content-SHA256": body_hash,
            "Request-ID": request_id,
            "Timestamp": now,
        }

        cl = command_line if command_line else f"{method} {path}"
        canonical = canonical_request(cl, headers)
        signature = sign(self._signing_key, canonical)

        return {
            "Agent-From": self._agent_id,
            "Agent-To": agent_to,
            "Agent-Key-ID": self._key_id,
            "Agent-Signature": signature,
            "Timestamp": now,
            "Request-ID": request_id,
        }

    def _post(
        self, path: str, payload: Any, extra_headers: dict[str, str] | None = None,
        command_line: str | None = None,
    ) -> httpx.Response:
        body = json.dumps(payload).encode()
        auth_headers = self._sign_request("POST", path, body, command_line=command_line)
        headers = {"Content-Type": "application/json", **auth_headers}
        if extra_headers:
            headers.update(extra_headers)
        resp = self.client.post(path, content=body, headers=headers)
        resp.raise_for_status()
        return resp

    # --- TASK ---

    def task(
        self,
        owner: str,
        name: str,
        capability: str,
        input: dict[str, Any],
        *,
        delegation_token: str | None = None,
        max_cost_usd: float | None = None,
        max_latency_ms: int | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        """Execute a task on a specific agent."""
        extra: dict[str, str] = {}
        if max_cost_usd is not None:
            extra["Max-Cost"] = str(max_cost_usd)
        if max_latency_ms is not None:
            extra["Max-Latency"] = str(max_latency_ms)
        if idempotency_key:
            extra["Idempotency-Key"] = idempotency_key

        payload: dict[str, Any] = {
            "caller_agent": self._agent_id,
            "input": input,
            "streaming": False,
        }
        if delegation_token:
            payload["delegation_token"] = delegation_token

        resp = self._post(
            f"/v1/agents/{owner}/{name}/task/{capability}",
            payload,
            extra,
            command_line=f"TASK {capability}",
        )
        return resp.json()

    def task_stream(
        self,
        owner: str,
        name: str,
        capability: str,
        input: dict[str, Any],
        *,
        delegation_token: str | None = None,
        max_cost_usd: float | None = None,
        max_latency_ms: int | None = None,
    ) -> Iterator[SSEEvent]:
        """Execute a streaming task, yielding SSE events."""
        path = f"/v1/agents/{owner}/{name}/task/{capability}"
        payload: dict[str, Any] = {
            "caller_agent": self._agent_id,
            "input": input,
            "streaming": True,
        }
        if delegation_token:
            payload["delegation_token"] = delegation_token

        body = json.dumps(payload).encode()
        auth_headers = self._sign_request("POST", path, body, command_line=f"TASK {capability}")
        headers = {
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            **auth_headers,
        }
        if max_cost_usd is not None:
            headers["Max-Cost"] = str(max_cost_usd)
        if max_latency_ms is not None:
            headers["Max-Latency"] = str(max_latency_ms)

        with self.client.stream("POST", path, content=body, headers=headers) as resp:
            resp.raise_for_status()
            yield from _parse_sse_stream(resp.iter_lines())

    # --- CANCEL ---

    def cancel(
        self, owner: str, name: str, request_id: str,
    ) -> dict[str, Any]:
        """Cancel an in-flight task."""
        resp = self._post(
            f"/v1/agents/{owner}/{name}/task/cancel",
            {"target_request_id": request_id},
            command_line="TASK.CANCEL",
        )
        return resp.json()

    # --- NEGOTIATE ---

    def negotiate(
        self,
        owner: str,
        name: str,
        capability: str,
        *,
        max_cost_usd: float | None = None,
        max_latency_ms: int | None = None,
    ) -> dict[str, Any]:
        """Negotiate pricing and availability."""
        extra: dict[str, str] = {}
        if max_cost_usd is not None:
            extra["Max-Cost"] = str(max_cost_usd)
        if max_latency_ms is not None:
            extra["Max-Latency"] = str(max_latency_ms)

        resp = self._post(
            f"/v1/agents/{owner}/{name}/negotiate/{capability}",
            {},
            extra,
            command_line=f"NEGOTIATE {capability}",
        )
        return resp.json()

    # --- DELEGATE ---

    def delegate(
        self,
        capability: str,
        input: dict[str, Any],
        *,
        optimize_for: str | None = None,
        max_cost_usd: float | None = None,
        max_latency_ms: int | None = None,
        prefer_agents: list[str] | None = None,
        exclude_agents: list[str] | None = None,
        min_accuracy: float | None = None,
        fallback: bool = False,
        max_fallback_attempts: int | None = None,
        delegation_token: str | None = None,
    ) -> dict[str, Any]:
        """Delegate task to best-matching agent."""
        payload: dict[str, Any] = {
            "caller_agent": self._agent_id,
            "input": input,
        }
        if optimize_for:
            payload["optimize_for"] = optimize_for
        if max_cost_usd is not None:
            payload["max_cost_usd"] = max_cost_usd
        if max_latency_ms is not None:
            payload["max_latency_ms"] = max_latency_ms
        if prefer_agents:
            payload["prefer_agents"] = prefer_agents
        if exclude_agents:
            payload["exclude_agents"] = exclude_agents
        if min_accuracy is not None:
            payload["min_accuracy"] = min_accuracy
        if fallback:
            payload["fallback"] = True
        if max_fallback_attempts is not None:
            payload["max_fallback_attempts"] = max_fallback_attempts
        if delegation_token:
            payload["delegation_token"] = delegation_token

        resp = self._post(f"/v1/delegate/{capability}", payload, command_line=f"DELEGATE {capability}")
        return resp.json()


def _parse_sse_stream(lines: Iterator[str]) -> Iterator[SSEEvent]:
    """Parse a stream of SSE lines into SSEEvent objects."""
    event: str | None = None
    data_lines: list[str] = []
    event_id: str | None = None

    for line in lines:
        if line == "":
            # Empty line = event boundary
            if data_lines:
                yield SSEEvent(event=event, data="\n".join(data_lines), id=event_id)
            event = None
            data_lines = []
            event_id = None
        elif line.startswith("event:"):
            event = line[6:].strip()
        elif line.startswith("data:"):
            data_lines.append(line[5:].lstrip())
        elif line.startswith("id:"):
            event_id = line[3:].strip()

    # Flush remaining
    if data_lines:
        yield SSEEvent(event=event, data="\n".join(data_lines), id=event_id)
