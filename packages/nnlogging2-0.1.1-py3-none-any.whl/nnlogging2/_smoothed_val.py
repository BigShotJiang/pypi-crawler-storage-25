from __future__ import annotations

import math
from collections import deque

import numpy as np

import nnlogging2._typings as tp


__all__ = ["NonnullableMetric", "NullableMetric"]


class NullableMetric(deque[float]):
    def __init__(self, *, maxlen: int = 64) -> None:
        super().__init__(maxlen=maxlen)

    @property
    def median(self) -> float:
        return float(np.nanmedian(self))

    @property
    def mean(self) -> float:
        return float(np.nanmean(self))

    @property
    def max(self) -> float:
        return float(np.nanmax(self))  # pyright: ignore[reportAny]

    @property
    def lastval(self) -> float:
        for ele in reversed(self):
            if not math.isnan(ele):
                return ele
        return float("nan")

    @property
    def val(self) -> float:  # pragma: no cover
        return self.lastval

    def update(self, val: tp.MetUpContT[float | None]) -> None:
        if isinstance(val, (float, int)):
            self.append(val)
            return

        if val is None:
            self.append(float("nan"))
            return

        if isinstance(val, tp.Iter):  # pyright: ignore[reportUnnecessaryIsInstance]
            self.extend(float("nan") if v is None else v for v in val)
            return

        msg = f"Cannot update value with type '{type(val)}'"  # pyright: ignore[reportUnreachable]
        raise TypeError(msg)


class NonnullableMetric(deque[float]):
    def __init__(self, *, maxlen: int = 64) -> None:
        super().__init__(maxlen=maxlen)

    @property
    def median(self) -> float:
        return float(np.nanmedian(self))

    @property
    def mean(self) -> float:
        return float(np.nanmean(self))

    @property
    def max(self) -> float:
        return float(np.nanmax(self))  # pyright: ignore[reportAny]

    @property
    def lastval(self) -> float:
        if len(self):
            return self[-1]
        return float("nan")

    @property
    def val(self) -> float:  # pragma: no cover
        return self.lastval

    def update(self, val: tp.MetUpContT[float]) -> None:
        if isinstance(val, (float, int)):
            self.append(val)
            return

        if isinstance(val, tp.Iter):  # pyright: ignore[reportUnnecessaryIsInstance]
            self.extend(val)
            return

        msg = f"Cannot update value with type '{type(val)}'"  # pyright: ignore[reportUnreachable]
        raise TypeError(msg)


# No need for global modifier function here since got one in `_logging.py`
fallback_updatable_metric_cls: type[tp.UpMetProt] = NullableMetric
fallback_attrs_recorded: tp.TdSeq[str] = ("val",)
