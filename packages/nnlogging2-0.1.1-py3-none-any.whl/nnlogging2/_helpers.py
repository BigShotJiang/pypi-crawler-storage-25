from __future__ import annotations

import logging
import sys
import threading

import nnlogging2._typings as tp

__all__ = [
    "add_level_name",
    "detect_attyio",
    "force_atty",
    "level_to_colorname",
    "level_to_int",
    "modify_colorname_fallback",
    "modify_level_fallback_colorname",
    "promote_logger",
    "unpack_metric_format",
]


_lock = threading.Lock()


_isatty: bool = sys.stdout.isatty() or sys.stderr.isatty()


def detect_attyio(*_ios: tp.SIO) -> None:  # pragma: no cover
    global _isatty
    with _lock:
        _isatty = all(_.isatty() for _ in _ios)


def force_atty(*, enabled: bool) -> None:  # pragma: no cover
    global _isatty
    with _lock:
        _isatty = enabled


_name_to_colorname = {
    "CRITICAL": "\033[41mCRITICAL\033[0m",
    "ERROR": "\033[31mERROR\033[0m",
    "WARNING": "\033[33mWARNING\033[0m",
    "INFO": "\033[32mINFO\033[0m",
    "DEBUG": "\033[37mDEBUG\033[0m",
}


_colorname_fb = "\033[36m%s\033[0m"


def modify_level_fallback_colorname(colorname: str, /) -> None:  # pragma: no cover
    global _colorname_fb
    with _lock:
        _colorname_fb = colorname


def level_to_int(lvl: tp.LogLevel, /) -> int:  # pragma: no cover
    return logging._nameToLevel.get(lvl, lvl)  # pyright: ignore[reportPrivateUsage, reportCallIssue, reportUnknownVariableType, reportArgumentType]


def level_to_colorname(lvl: tp.LogLevel, /, *, colored: bool | None = None) -> str:
    if isinstance(lvl, str):
        lvl = logging._nameToLevel[lvl]  # pyright: ignore[reportPrivateUsage]
    name = logging._levelToName.get(lvl, f"Level {lvl}")  # pyright: ignore[reportPrivateUsage]
    colored = _isatty if colored is None else colored
    return _name_to_colorname.get(name, _colorname_fb % name) if colored else name


def add_level_name(level: int, levelname: str, colorname: str | None = None) -> None:
    logging.addLevelName(level, levelname)
    with _lock:
        if colorname:
            _name_to_colorname[levelname] = colorname


def modify_colorname_fallback(name: str) -> None:
    global _colorname_fb
    with _lock:
        _colorname_fb = name


def unpack_metric_format(
    formattable: tp.MetFmt,
    /,
) -> tuple[str, str | None]:  # pragma: no cover
    if isinstance(formattable, tuple):
        if len(formattable) == 1:
            return formattable[0], None
        return formattable[0], formattable[1]
    return formattable, None


def promote_logger(logger: logging.Logger, cls: type[tp.PLoggerT], /) -> tp.PLoggerT:
    """Promote a standard `logging.Logger` instance to a specialized subclass
    (e.g., `MetricLogger`) at runtime.

    Why `promote_logger`?

    - Non-Invasive: `logging.setLoggerClass` changes the type of future loggers
    globally, while promotion is surgical. It only the provided logger.

    - Registry Compatibility: Loggers are singletons managed by `logging.Manager`.
    Modifying a logger help other modules enjoy the benefit from the new features
    without breaking changes.

    Args:

        logger (Logger): The logger instance to be 'promoted'.

        cls (Any subclass of `Logger`): The target subclass type.

    Returns:

        The promoted logger instance.
    """

    if type(logger) is not logging.Logger and type(logger) is not cls:
        msg = (
            f"Cannot promote '{logger}' because "
            f"'{type(logger)}' is neither '{logging.Logger}' nor '{cls}'"
        )
        raise TypeError(msg)
    if type(logger) is not cls:
        with _lock:
            logger.__class__ = cls
        if hasattr(logger, "promote") and callable(logger.promote):  # pyright: ignore[reportUnknownArgumentType, reportUnknownMemberType, reportAttributeAccessIssue]
            logger.promote()  # pyright: ignore[reportAttributeAccessIssue, reportUnusedCallResult]
    return tp.cast(tp.PLoggerT, logger)
