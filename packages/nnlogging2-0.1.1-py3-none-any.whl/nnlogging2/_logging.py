from __future__ import annotations

import logging
from collections import defaultdict

import nnlogging2._helpers as hp
import nnlogging2._smoothed_val as sv
import nnlogging2._typings as tp

__all__ = [
    "AttyStreamHandler",
    "ContextedMetricFormatter",
    "ContextedMetricLogger",
    "MetricLogger",
    "get_metric_logger",
    "modify_context_key",
    "modify_format_fallback_context_delimiter",
    "modify_format_fallback_context_fmtstr",
    "modify_format_fallback_metrics_delimiter",
    "modify_format_fallback_metrics_fmtstr",
    "modify_logger_fallback_attrs_recorded",
    "modify_logger_fallback_metcls",
    "modify_metrics_key",
]


class MetricLogger(logging.Logger):
    """A customizable `logging.Logger` subclass.

    `py.logging` library ultilizes a global manager to maintain logger tree status.
    Although a `logging.setLoggerClass` method is provided, it has a deeper impact.

    `MetricLogger` works in a non-invasive way: user gets its instance by calling
    `get_metric_logger`, and `nnlogging2` promote it without impacting other
    modules or creating a new tree; `MetricLogger` will put all attributes it is
    assigned to trace to `LogRecord` regardless of metric name.

    Reference:

    - https://docs.python.org/3/tutorial/classes
    - https://docs.python.org/3/library/logging
    """

    # This will be injected to record with metric attributes being recorded.
    # Modify it at any time to what you like.
    metrics_key: str = "_metrics_nnlogging2"

    # Updatable-Metric Class & Record Attributes fallback
    # Modify it if you want, but calling updating method is way better.
    fallback_metric_cls: type[tp.UpMetProt] = sv.fallback_updatable_metric_cls
    fallback_attrs_recorded: tp.TdSeq[str] = sv.fallback_attrs_recorded

    # type-checking
    _metcls: type[tp.UpMetProt]  # pyright: ignore[reportUninitializedInstanceVariable]
    _tracer: defaultdict[str, tp.UpMetProt]  # pyright: ignore[reportUninitializedInstanceVariable]
    _attrs: tp.TdSeq[str]  # pyright: ignore[reportUninitializedInstanceVariable]

    @classmethod
    def modify_metrics_key(cls, metrics_key: str, /) -> None:  # pragma: no cover
        with hp._lock:  # pyright: ignore[reportPrivateUsage]
            cls.metrics_key = metrics_key

    @classmethod
    def modify_fallback_metric_cls(
        cls,
        metric_cls: type[tp.UpMetProt],
        /,
    ) -> None:  # pragma: no cover
        with hp._lock:  # pyright: ignore[reportPrivateUsage]
            cls.fallback_metric_cls = metric_cls

    @classmethod
    def modify_fallback_attrs_recorded(
        cls,
        attrs_recorded: tp.TdSeq[str],
        /,
    ) -> None:  # pragma: no cover
        with hp._lock:  # pyright: ignore[reportPrivateUsage]
            cls.fallback_attrs_recorded = attrs_recorded

    def promote(self) -> None:  # pragma: no cover
        """Define attributes correctly.

        `promote` should be called without any arguments.
        """
        with hp._lock:  # pyright: ignore[reportPrivateUsage]
            if not hasattr(self, "_metcls"):
                self._metcls = self.fallback_metric_cls
            if not hasattr(self, "_tracer"):
                self._tracer = defaultdict(self.fallback_metric_cls)
            if not hasattr(self, "_attrs"):
                self._attrs = self.fallback_attrs_recorded

    def customize(
        self,
        *,
        metcls: type[tp.UpMetProt] | None = None,
        attrs: tp.TdSeq[str] | None = None,
    ) -> None:  # pragma: no cover
        """Customize logger instance's tracing way or attributes."""
        check_metcls = metcls or self._metcls
        check_attrs = attrs or self._attrs
        if any(not hasattr(check_metcls, a) for a in check_attrs):
            msg = f"Cannot find all attributes '{check_attrs}' in '{check_metcls}'"
            raise AttributeError(msg)

        with hp._lock:  # pyright: ignore[reportPrivateUsage]
            if metcls is not None:
                self._metcls = metcls
                self._tracer = defaultdict(metcls)

            if attrs is not None:
                self._attrs = attrs

    def update(self, **kwargs: tp.MetUpContT[tp.MetContT]) -> None:  # pragma: no cover
        for k, v in kwargs.items():
            self._tracer[k].update(v)

    def log_metric(
        self,
        level: tp.LogLevel,
        *,
        msg: str = "",
        metrics: tp.Iter[tp.MetFmt] | None = None,
        **kwargs: tp.Any,  # pyright: ignore[reportAny]
    ) -> None:
        """Log provided metric names with a specified level.

        Record format:
        ```json
        {
          'extra': {
            metrics_key: {
              metric_name1: {
                'attrs': { attribute_name1: ..., ... },
                'fmtstr': ... (String / None)
              }, ...
            }, ...
          }, ...
        }
        ```
        """
        level = hp.level_to_int(level)
        if not self.isEnabledFor(level):
            return
        metrec: tp.MetRecDict = {}
        for met in self._tracer if metrics is None else metrics:
            name, fmtstr = hp.unpack_metric_format(met)
            metrec[name] = {
                "attrs": {a: getattr(self._tracer[name], a) for a in self._attrs},
                "fmtstr": fmtstr,
            }

        if "extra" not in kwargs:
            kwargs["extra"] = {}
        metrec_orig: tp.MetRecDict = kwargs["extra"].get(self.metrics_key, {})  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
        kwargs["extra"][self.metrics_key] = {**metrec_orig, **metrec}

        self.log(level, msg=msg, **kwargs)  # pyright: ignore[reportAny]

    def export_tracer(self, /) -> defaultdict[str, tp.UpMetProt]:
        return self._tracer

    def contexted(
        self,
        context: tp.IMap[str, tp.Any] | None = None,
        *,
        cover: bool = False,
    ) -> ContextedMetricLogger:  # pragma: no cover
        return ContextedMetricLogger(self, context, cover=cover)


modify_metrics_key = MetricLogger.modify_metrics_key
modify_logger_fallback_metcls = MetricLogger.modify_fallback_metric_cls
modify_logger_fallback_attrs_recorded = MetricLogger.modify_fallback_attrs_recorded


class ContextedMetricLogger(logging.LoggerAdapter[MetricLogger]):
    """Yet another `logging.LoggerAdapter`.

    Its responsibility is to attach a context to log record emitted.
    """

    # This will inject to record with context being recorded.
    # Modify it at any time to what you like.
    context_key: str = "_context_nnlogging2"

    @classmethod
    def modify_context_key(cls, context_key: str, /) -> None:  # pragma: no cover
        with hp._lock:  # pyright: ignore[reportPrivateUsage]
            cls.context_key = context_key

    def __init__(
        self,
        metric_logger: MetricLogger,
        context: tp.IMap[str, tp.Any] | None = None,
        *,
        cover: bool = False,
    ) -> None:
        super().__init__(metric_logger)
        self._context: tp.IMap[str, tp.Any] = context or {}
        self._cover: bool = cover

    @tp.override
    def process(
        self,
        msg: str,
        kwargs: tp.MMap[str, tp.Any],
    ) -> tuple[str, tp.MMap[str, tp.Any]]:
        if self._context:
            if "extra" not in kwargs:
                kwargs["extra"] = {}
            ctxrec_orig: tp.CtxRecDict = kwargs["extra"].get(self.context_key, {})  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            kwargs["extra"][self.context_key] = (
                self._context if self._cover else {**ctxrec_orig, **self._context}
            )
        return msg, kwargs

    def update(self, **kwargs: tp.MetUpContT[tp.MetContT]) -> None:  # pragma: no cover
        self.logger.update(**kwargs)

    def log_metric(
        self,
        level: tp.LogLevel,
        *,
        msg: str = "",
        metrics: tp.Iter[tp.MetFmt] | None = None,
        **kwargs: tp.Any,  # pyright: ignore[reportAny]
    ) -> None:  # pragma: no cover
        level = hp.level_to_int(level)
        if self.isEnabledFor(level):
            msg, kwargs = self.process(msg, kwargs)  # pyright: ignore[reportAssignmentType]
            self.logger.log_metric(level, msg=msg, metrics=metrics, **kwargs)

    def contexted(
        self,
        context: tp.IMap[str, tp.Any] | None = None,
        *,
        cover: bool | None = None,
    ) -> tp.Self:
        cover = self._cover if cover is None else cover
        context = context or {} if cover else {**self._context, **(context or {})}
        return type(self)(self.logger, context, cover=cover)


modify_context_key = ContextedMetricLogger.modify_context_key


class AttyStreamHandler(logging.StreamHandler[tp.SIO]):
    """An atty-aware `StreamHandler`.

    `AttyStreamHandler` now only provide colored level. And because ANSI
    escaped code print nothing but hold length size when formatting, please
    increase 9 character length, e.g. '%(levelname)-8s' -> '%(levelname)-17s',
    when you know ANSI escaped codes will work.
    """

    @tp.override
    def __init__(
        self,
        stream: tp.SIO | None = None,
        *,
        force_colored_level: bool | None = None,
    ) -> None:
        super().__init__(stream)
        isatty: bool = (
            hasattr(self.stream, "isatty")
            and callable(self.stream.isatty)
            and self.stream.isatty()
        )
        self._use_colored_level: bool = (
            isatty if force_colored_level is None else force_colored_level
        )

    @tp.override
    def format(self, record: logging.LogRecord) -> str:
        levelname_orig = record.levelname

        try:
            record.levelname = hp.level_to_colorname(
                record.levelno,
                colored=self._use_colored_level,
            )
            return super().format(record)

        finally:
            record.levelname = levelname_orig


class ContextedMetricFormatter(logging.Formatter):
    """Format context and metrics if provided.

    This formatter extracts context and metric data from the `LogRecord`,
    formats them according to the specified format strings, and temporarily
    injects them into the record as `context_ext` and `metrics_ext` attributes
    so they can be used in the main log message format string.

    Note: Currently only '%' formatting style is supported.
    """

    context_key: str = ContextedMetricLogger.context_key
    metrics_key: str = MetricLogger.metrics_key

    fallback_context_fmtstr: str = "(%(context)s)"
    fallback_metrics_fmtstr: str = "[%(metricname)s: %(val).4f]"
    fallback_context_delim: str = ""
    fallback_metrics_delim: str = " "

    @classmethod
    def modify_fallback_context_fmtstr(cls, ctxfmt: str, /) -> None:  # pragma: no cover
        with hp._lock:  # pyright: ignore[reportPrivateUsage]
            cls.fallback_context_fmtstr = ctxfmt

    @classmethod
    def modify_fallback_metrics_fmtstr(cls, metfmt: str, /) -> None:  # pragma: no cover
        with hp._lock:  # pyright: ignore[reportPrivateUsage]
            cls.fallback_metrics_fmtstr = metfmt

    @classmethod
    def modify_fallback_context_delimiter(
        cls,
        ctxdelim: str,
        /,
    ) -> None:  # pragma: no cover
        with hp._lock:  # pyright: ignore[reportPrivateUsage]
            cls.fallback_context_delim = ctxdelim

    @classmethod
    def modify_fallback_metrics_delimiter(
        cls,
        metdelim: str,
        /,
    ) -> None:  # pragma: no cover
        with hp._lock:  # pyright: ignore[reportPrivateUsage]
            cls.fallback_metrics_delim = metdelim

    @tp.overload
    @classmethod
    def modify_context_key(cls, typ: type, /) -> None: ...  # pragma: no cover
    @tp.overload
    @classmethod
    def modify_context_key(cls, s: str, /) -> None: ...  # pragma: no cover
    @classmethod
    def modify_context_key(cls, _in: type | str, /) -> None:  # pragma: no cover
        match _in:
            case type():
                if getattr(_in, "context_key", None) is None:
                    msg = f"Class '{_in}' has no attribute 'context_key'"
                    raise AttributeError(msg)
                with hp._lock:  # pyright: ignore[reportPrivateUsage]
                    cls.context_key = _in.context_key  # pyright: ignore[reportUnknownMemberType]
            case str():
                with hp._lock:  # pyright: ignore[reportPrivateUsage]
                    cls.context_key = _in
            case _:  # pyright: ignore[reportUnnecessaryComparison]
                msg = f"Cannot recognize '{_in}' when modify 'context_key'"  # pyright: ignore[reportUnreachable]
                raise TypeError(msg)

    @tp.overload
    @classmethod
    def modify_metrics_key(cls, typ: type, /) -> None: ...  # pragma: no cover
    @tp.overload
    @classmethod
    def modify_metrics_key(cls, s: str, /) -> None: ...  # pragma: no cover
    @classmethod
    def modify_metrics_key(cls, _in: type | str, /) -> None:  # pragma: no cover
        match _in:
            case type():
                if getattr(_in, "metrics_key", None) is None:
                    msg = f"Class '{_in}' has no attribute 'metrics_key'"
                    raise TypeError(msg)
                with hp._lock:  # pyright: ignore[reportPrivateUsage]
                    cls.metrics_key = _in.metrics_key  # pyright: ignore[reportUnknownMemberType]
            case str():
                with hp._lock:  # pyright: ignore[reportPrivateUsage]
                    cls.metrics_key = _in
            case _:  # pyright: ignore[reportUnnecessaryComparison]
                msg = f"Cannot recognize '{_in}' when modify 'metrics_key'"  # pyright: ignore[reportUnreachable]
                raise TypeError(msg)

    def __init__(
        self,
        fmt: str | None = None,
        datefmt: str | None = None,
        ctxfmt: str = fallback_context_fmtstr,
        metfmt: str = fallback_metrics_fmtstr,
        ctxdelim: str = fallback_context_delim,
        metdelim: str = fallback_metrics_delim,
        *,
        validate: bool = True,
        defaults: dict[str, tp.Any] | None = None,
    ) -> None:  # pragma: no cover
        """Initialize the formatter with specific formats for context and metrics.

        Reference for other arguments:

        - https://docs.python.org/3/library/logging.html#logging.Formatter

        Args:
            ctxfmt (str): Context format string. Supported formatting keys:
                - `contextname`: Name of the context.
                - `context`: Content of the context.

            metfmt (str): Metric format string. Supported formatting keys:
                - `metricname`: Name of the metric.
                - `<attribute name>`: Any passing attribute name (e.g. 'val', 'mean').

            ctxdelim (str): Delimiter used to join multiple formatted context strings.

            metdelim (str): Delimiter used to join multiple formatted metric strings.

        """
        super().__init__(fmt, datefmt, style="%", validate=validate, defaults=defaults)
        self.ctxfmt: str = ctxfmt
        self.metfmt: str = metfmt
        self.ctxdelim: str = ctxdelim
        self.metdelim: str = metdelim

    def format_context(self, record: logging.LogRecord, /) -> str:
        if hasattr(record, self.context_key):
            return self.ctxdelim.join(
                self.ctxfmt % {"contextname": name, "context": context}
                for name, context in getattr(record, self.context_key).items()  # pyright: ignore[reportAny]
            )
        return ""

    def format_metrics(self, record: logging.LogRecord, /) -> str:
        if hasattr(record, self.metrics_key):
            return self.metdelim.join(
                (metric.get("fmtstr") or self.metfmt)  # pyright: ignore[reportAny]
                % {"metricname": name, **metric.get("attrs", {})}  # pyright: ignore[reportAny]
                for name, metric in getattr(record, self.metrics_key).items()  # pyright: ignore[reportAny]
            )
        return ""

    @tp.override
    def format(self, record: logging.LogRecord) -> str:
        context_str = self.format_context(record)
        metrics_str = self.format_metrics(record)

        record.context_ext = context_str
        record.metrics_ext = metrics_str

        try:
            return super().format(record)

        finally:
            if hasattr(record, "context_ext"):
                del record.context_ext  # pyright: ignore[reportAttributeAccessIssue]
            if hasattr(record, "metrics_ext"):
                del record.metrics_ext  # pyright: ignore[reportAttributeAccessIssue]


modify_format_fallback_context_fmtstr = (
    ContextedMetricFormatter.modify_fallback_context_fmtstr
)
modify_format_fallback_metrics_fmtstr = (
    ContextedMetricFormatter.modify_fallback_metrics_fmtstr
)
modify_format_fallback_context_delimiter = (
    ContextedMetricFormatter.modify_fallback_context_delimiter
)
modify_format_fallback_metrics_delimiter = (
    ContextedMetricFormatter.modify_fallback_metrics_delimiter
)


def get_metric_logger(name: str | None = None) -> MetricLogger:  # pragma: no cover
    """Get a logger using `logging.getLogger` then promote it in-place.

    For promotion details please goto `nnlogging2._helpers.promote_logger`.
    """
    logger = logging.getLogger(name)
    return hp.promote_logger(logger, MetricLogger)
