from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np
import xarray as xr


DEFAULT_AXIS_UNITS = {
    "x": "px",
    "y": "px",
    "z": "index",
}


def _default_coord(axis: str, size: int) -> np.ndarray:
    return np.arange(int(size), dtype=np.float64)


def _coord_edges(values: np.ndarray) -> np.ndarray:
    vals = np.asarray(values, dtype=np.float64)
    if vals.ndim != 1 or vals.size == 0:
        raise ValueError("Coordinate array must be 1D and non-empty")
    if vals.size == 1:
        return np.array([vals[0] - 0.5, vals[0] + 0.5], dtype=np.float64)
    mids = 0.5 * (vals[:-1] + vals[1:])
    first = vals[0] - (mids[0] - vals[0])
    last = vals[-1] + (vals[-1] - mids[-1])
    return np.concatenate([[first], mids, [last]]).astype(np.float64)


@dataclass
class ImageStack:
    """Container for a 3D image stack backed by an xarray DataArray.

    The canonical representation is an xarray DataArray with dims ('z', 'y', 'x').
    For compatibility with the rest of the codebase, ``data`` exposes the underlying
    NumPy array view.
    """

    data: np.ndarray
    name: str = "Untitled"
    source_path: str | None = None
    data_array: xr.DataArray | None = None

    def __post_init__(self) -> None:
        if self.data_array is None:
            arr = np.asarray(self.data)
            if arr.ndim != 3:
                raise ValueError("ImageStack.data must have shape (n_images, ny, nx)")
            if not np.issubdtype(arr.dtype, np.number):
                raise TypeError("ImageStack.data must be numeric")
            self.data_array = self._build_default_data_array(arr)
        else:
            if tuple(self.data_array.dims) != ("z", "y", "x"):
                self.data_array = self.data_array.transpose("z", "y", "x")
            arr = np.asarray(self.data_array.data)
            if arr.ndim != 3:
                raise ValueError("ImageStack.data_array must have dims ('z', 'y', 'x')")
            if not np.issubdtype(arr.dtype, np.number):
                raise TypeError("ImageStack.data_array must be numeric")
            self.data_array = self._ensure_coords_and_attrs(self.data_array)
        self.data = np.asarray(self.data_array.data)

    @classmethod
    def _build_default_data_array(cls, arr: np.ndarray) -> xr.DataArray:
        coords = {
            axis: xr.DataArray(
                _default_coord(axis, arr.shape[i]),
                dims=(axis,),
                attrs={"units": DEFAULT_AXIS_UNITS[axis]},
            )
            for i, axis in enumerate(("z", "y", "x"))
        }
        return xr.DataArray(arr, dims=("z", "y", "x"), coords=coords, attrs={})

    @classmethod
    def _ensure_coords_and_attrs(cls, da: xr.DataArray) -> xr.DataArray:
        da = da.copy(deep=False)
        coords = {}
        for i, axis in enumerate(("z", "y", "x")):
            if axis in da.coords and da.coords[axis].size == da.sizes[axis]:
                vals = np.asarray(da.coords[axis].values, dtype=np.float64)
                attrs = dict(da.coords[axis].attrs)
            else:
                vals = _default_coord(axis, da.sizes[axis])
                attrs = {}
            attrs.setdefault("units", DEFAULT_AXIS_UNITS[axis])
            coords[axis] = xr.DataArray(vals, dims=(axis,), attrs=attrs)
        return xr.DataArray(np.asarray(da.data), dims=("z", "y", "x"), coords=coords, attrs=dict(da.attrs))

    @classmethod
    def from_xarray(cls, data_array: xr.DataArray, name: str = "Untitled", source_path: str | None = None) -> "ImageStack":
        return cls(data=np.asarray(data_array.data), name=name, source_path=source_path, data_array=data_array)

    def copy(self, deep: bool = True) -> "ImageStack":
        da = self.data_array.copy(deep=deep)
        return ImageStack.from_xarray(da, name=self.name, source_path=self.source_path)

    @property
    def n_images(self) -> int:
        return int(self.data.shape[0])

    @property
    def shape2d(self) -> Tuple[int, int]:
        return int(self.data.shape[1]), int(self.data.shape[2])

    @property
    def x_coords(self) -> np.ndarray:
        return np.asarray(self.data_array.coords["x"].values, dtype=np.float64)

    @property
    def y_coords(self) -> np.ndarray:
        return np.asarray(self.data_array.coords["y"].values, dtype=np.float64)

    @property
    def z_coords(self) -> np.ndarray:
        return np.asarray(self.data_array.coords["z"].values, dtype=np.float64)

    def axis_units(self, axis: str) -> str:
        if axis not in self.data_array.coords:
            return ""
        return str(self.data_array.coords[axis].attrs.get("units", ""))

    def axis_label(self, axis: str) -> str:
        coord = self.data_array.coords.get(axis)
        base = axis
        if coord is not None:
            base = str(coord.attrs.get("long_name", axis))
        unit = self.axis_units(axis)
        return f"{base} ({unit})" if unit else base

    def distance_label(self) -> str:
        x_unit = self.axis_units("x")
        y_unit = self.axis_units("y")
        unit = x_unit if x_unit == y_unit else x_unit or y_unit
        return f"distance ({unit})" if unit else "distance"

    def axis_edges(self, axis: str) -> np.ndarray:
        return _coord_edges(getattr(self, f"{axis}_coords"))

    def image_rect(self) -> tuple[float, float, float, float]:
        x_edges = self.axis_edges("x")
        y_edges = self.axis_edges("y")
        return float(x_edges[0]), float(y_edges[0]), float(x_edges[-1] - x_edges[0]), float(y_edges[-1] - y_edges[0])

    def coord_to_pixel_float(self, axis: str, value: float) -> float:
        coords = getattr(self, f"{axis}_coords")
        return self._coord_to_pixel_float(axis, value, extrapolate=False)

    def coord_to_pixel_float_extrapolated(self, axis: str, value: float) -> float:
        return self._coord_to_pixel_float(axis, value, extrapolate=True)

    def _coord_to_pixel_float(self, axis: str, value: float, extrapolate: bool) -> float:
        coords = np.asarray(getattr(self, f"{axis}_coords"), dtype=np.float64)
        if coords.size == 1:
            return 0.0

        original_descending = bool(coords[0] > coords[-1])
        if original_descending:
            coords_work = coords[::-1]
        else:
            coords_work = coords

        idx_work = np.arange(coords_work.size, dtype=np.float64)
        value = float(value)

        if not extrapolate:
            pix = float(np.interp(value, coords_work, idx_work))
        elif value < coords_work[0]:
            denom = coords_work[1] - coords_work[0]
            slope = 1.0 / denom if abs(denom) > 0.0 else 0.0
            pix = (value - coords_work[0]) * slope
        elif value > coords_work[-1]:
            denom = coords_work[-1] - coords_work[-2]
            slope = 1.0 / denom if abs(denom) > 0.0 else 0.0
            pix = (coords_work.size - 1) + (value - coords_work[-1]) * slope
        else:
            pix = float(np.interp(value, coords_work, idx_work))

        if original_descending:
            pix = (coords.size - 1) - pix
        return float(pix)

    def coord_to_nearest_index(self, axis: str, value: float) -> int:
        coords = getattr(self, f"{axis}_coords")
        idx = int(np.argmin(np.abs(coords - value)))
        return max(0, min(idx, coords.size - 1))

    def coord_bounds_to_index_range(self, axis: str, start: float, stop: float, allow_empty: bool = False) -> tuple[int, int]:
        edges = np.asarray(self.axis_edges(axis), dtype=np.float64)
        low, high = (float(start), float(stop)) if start <= stop else (float(stop), float(start))
        n = getattr(self, f"{axis}_coords").size

        if edges[0] > edges[-1]:
            edges = edges[::-1]

        data_low = float(edges[0])
        data_high = float(edges[-1])
        no_overlap = bool(high <= data_low or low >= data_high)
        if allow_empty and no_overlap:
            if high <= data_low:
                return 0, 0
            return n, n

        i0 = int(np.clip(np.searchsorted(edges, low, side="right") - 1, 0, n - 1))
        i1 = int(np.clip(np.searchsorted(edges, high, side="left"), 0, n))
        if i1 <= i0:
            center = self.coord_to_nearest_index(axis, 0.5 * (low + high))
            i0 = center
            i1 = min(center + 1, n)
        return i0, i1

    def physical_roi_to_pixel(self, roi: tuple[float, float, float, float]) -> tuple[int, int, int, int]:
        x, y, w, h = (float(v) for v in roi)
        x0, x1 = self.coord_bounds_to_index_range("x", x, x + w, allow_empty=True)
        y0, y1 = self.coord_bounds_to_index_range("y", y, y + h, allow_empty=True)
        return int(x0), int(y0), int(max(0, x1 - x0)), int(max(0, y1 - y0))

    def physical_line_to_pixel(
        self,
        start_xy: tuple[float, float],
        end_xy: tuple[float, float],
    ) -> tuple[tuple[float, float], tuple[float, float]]:
        x0, y0 = start_xy
        x1, y1 = end_xy
        return (
            (self.coord_to_pixel_float_extrapolated("x", x0), self.coord_to_pixel_float_extrapolated("y", y0)),
            (self.coord_to_pixel_float_extrapolated("x", x1), self.coord_to_pixel_float_extrapolated("y", y1)),
        )

    def line_distance_axis(
        self,
        start_xy: tuple[float, float],
        end_xy: tuple[float, float],
        n_samples: int,
    ) -> np.ndarray:
        x0, y0 = start_xy
        x1, y1 = end_xy
        length = float(np.hypot(x1 - x0, y1 - y0))
        return np.linspace(0.0, length, int(n_samples), dtype=np.float64)

    def z_value(self, index: int) -> float:
        return float(self.z_coords[int(index)])

    def pixel_to_coord_float(self, axis: str, pixel: float) -> float:
        coords = np.asarray(getattr(self, f"{axis}_coords"), dtype=np.float64)
        if coords.size == 0:
            raise ValueError(f"Axis {axis!r} has no coordinates")
        if coords.size == 1:
            return float(coords[0])

        idx = np.arange(coords.size, dtype=np.float64)
        pixel = float(pixel)
        if pixel <= idx[0]:
            denom = idx[1] - idx[0]
            slope = (coords[1] - coords[0]) / denom if abs(denom) > 0.0 else 0.0
            return float(coords[0] + (pixel - idx[0]) * slope)
        if pixel >= idx[-1]:
            denom = idx[-1] - idx[-2]
            slope = (coords[-1] - coords[-2]) / denom if abs(denom) > 0.0 else 0.0
            return float(coords[-1] + (pixel - idx[-1]) * slope)
        return float(np.interp(pixel, idx, coords))

    def pixel_roi_to_physical(self, roi: tuple[int, int, int, int]) -> tuple[float, float, float, float]:
        x0, y0, w, h = (int(v) for v in roi)
        x_edges = np.asarray(self.axis_edges("x"), dtype=np.float64)
        y_edges = np.asarray(self.axis_edges("y"), dtype=np.float64)
        nx = self.x_coords.size
        ny = self.y_coords.size
        x0 = int(np.clip(x0, 0, nx))
        y0 = int(np.clip(y0, 0, ny))
        x1 = int(np.clip(x0 + max(0, w), 0, nx))
        y1 = int(np.clip(y0 + max(0, h), 0, ny))
        x_start = float(x_edges[x0])
        x_stop = float(x_edges[x1])
        y_start = float(y_edges[y0])
        y_stop = float(y_edges[y1])
        return x_start, y_start, x_stop - x_start, y_stop - y_start

    def with_linear_axis_ranges(
        self,
        x_range: tuple[float, float] | None = None,
        y_range: tuple[float, float] | None = None,
        z_range: tuple[float, float] | None = None,
    ) -> "ImageStack":
        """Return a copy of the stack with linearly redefined axis coordinates.

        The image data are unchanged. Only the coordinate arrays attached to the
        xarray DataArray are rebuilt. Each provided range is interpreted as
        (start, stop) spanning the full axis length. Axes left as None keep
        their current coordinates.
        """

        da = self.data_array
        assert da is not None

        requested = {"x": x_range, "y": y_range, "z": z_range}
        coords = {}
        for axis in ("z", "y", "x"):
            coord = da.coords[axis]
            attrs = dict(coord.attrs)
            requested_range = requested[axis]
            if requested_range is None:
                values = np.asarray(coord.values, dtype=np.float64)
            else:
                start, stop = (float(v) for v in requested_range)
                size = int(da.sizes[axis])
                if size <= 1:
                    values = np.array([start], dtype=np.float64)
                else:
                    values = np.linspace(start, stop, size, dtype=np.float64)
            coords[axis] = xr.DataArray(values, dims=(axis,), attrs=attrs)

        new_da = xr.DataArray(
            np.asarray(da.data),
            dims=da.dims,
            coords=coords,
            attrs=dict(da.attrs),
            name=da.name,
        )
        return ImageStack.from_xarray(new_da, name=self.name, source_path=self.source_path)

    # Debug-only sample data generator kept as commented reference.
    # Uncomment/adapt if you want a synthetic stack while debugging.
    #
    # @classmethod
    # def dummy(cls, n: int = 20, ny: int = 512, nx: int = 512) -> "ImageStack":
    #     rng = np.random.default_rng(42)
    #     x = np.linspace(-1, 1, nx)
    #     y = np.linspace(-1, 1, ny)
    #     xx, yy = np.meshgrid(x, y)
    #
    #     stack = []
    #     for i in range(n):
    #         shift_x = 0.15 * np.sin(i / 4)
    #         shift_y = 0.10 * np.cos(i / 5)
    #         img = np.exp(-(((xx - shift_x) * 2.5) ** 2 + ((yy - shift_y) * 2.5) ** 2))
    #         img += 0.25 * np.exp(-(((xx + 0.35) * 7) ** 2 + ((yy - 0.2) * 7) ** 2))
    #         img += 0.03 * rng.standard_normal((ny, nx))
    #         stack.append(img.astype(np.float32))
    #
    #     return cls(np.stack(stack, axis=0), name="Dummy stack")
