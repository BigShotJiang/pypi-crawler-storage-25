from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np
import xarray as xr
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtWidgets import (
    QButtonGroup,
    QCheckBox,
    QDockWidget,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QComboBox,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QProgressBar,
    QRadioButton,
    QScrollArea,
    QSlider,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from pyAthina.io import load_stack_auto, save_image_tiff
from pyAthina.lineprofile import LineProfileWindow
from pyAthina.lineslice import LineSliceWindow
from pyAthina.models import ImageStack
from pyAthina.processing import (
    ALIGNMENT_METHOD_ECC,
    ALIGNMENT_METHOD_PHASE,
    WARP_MODEL_AFFINE,
    WARP_MODEL_EUCLIDEAN,
    WARP_MODEL_TRANSLATION,
    average_stack,
    average_stack_in_roi,
    line_profile_from_image,
    line_slice_from_stack,
    normalize_alignment_roi,
    roi_integrated_signal,
    roi_mean_signal,
)
from pyAthina.signals import PEEMSignals
from pyAthina.viewer import PEEMImageView
from pyAthina.workers import AlignmentWorker, create_alignment_thread
from pyAthina.zprofile import ZProfileWindow


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("pyAthina")
        self.resize(1450, 920)

        self.signals = PEEMSignals()
        self.stack: Optional[ImageStack] = None
        self.original_stack: Optional[ImageStack] = None
        self.current_index = 0
        self.last_shifts: np.ndarray | None = None
        self.last_transforms: np.ndarray | None = None
        self.last_transform_models: list[str] | None = None

        self._alignment_thread = None
        self._alignment_worker = None
        self._alignment_running = False
        self._z_profile_active = False
        self._line_profile_active = False
        self._line_slice_active = False
        self.z_profile_window: ZProfileWindow | None = None
        self.line_profile_window: LineProfileWindow | None = None
        self.line_slice_window: LineSliceWindow | None = None
        self._z_profile_refresh_timer = QTimer(self)
        self._z_profile_refresh_timer.setSingleShot(True)
        self._z_profile_refresh_timer.setInterval(15)
        self._z_profile_refresh_timer.timeout.connect(self._refresh_z_profile_if_possible)
        self._line_profile_refresh_timer = QTimer(self)
        self._line_profile_refresh_timer.setSingleShot(True)
        self._line_profile_refresh_timer.setInterval(15)
        self._line_profile_refresh_timer.timeout.connect(self._refresh_line_profile_if_possible)
        self._line_slice_refresh_timer = QTimer(self)
        self._line_slice_refresh_timer.setSingleShot(True)
        self._line_slice_refresh_timer.setInterval(20)
        self._line_slice_refresh_timer.timeout.connect(self._refresh_line_slice_if_possible)

        self.viewer = PEEMImageView(self.signals)
        self._build_central_panel()
        self._build_left_panel()
        self._build_z_profile_panel()
        self._build_right_panel()
        self._connect_signals()
        self._apply_profile_button_styles()
        # Debug-only sample data loader intentionally disabled.
        # Uncomment the next line temporarily if you want to start with a synthetic stack.
        # self._load_dummy_data()
        self._update_registration_options_enabled()
        self._update_registration_model_label()

    def _build_central_panel(self) -> None:
        central = QWidget()
        layout = QVBoxLayout(central)
        layout.setContentsMargins(6, 6, 6, 6)

        self.frame_slider = QSlider(Qt.Orientation.Horizontal)
        self.frame_slider.setMinimum(0)
        self.frame_slider.setMaximum(0)
        self.frame_slider.setSingleStep(1)
        self.frame_slider.setPageStep(1)
        self.frame_slider.setTickInterval(1)
        self.frame_slider.setTracking(True)

        slider_row = QHBoxLayout()
        self.lbl_frame_min = QLabel("0")
        self.lbl_frame_current = QLabel("Frame 0 / 0")
        self.lbl_frame_max = QLabel("0")
        slider_row.addWidget(self.lbl_frame_min)
        slider_row.addWidget(self.frame_slider, stretch=1)
        slider_row.addWidget(self.lbl_frame_max)

        layout.addWidget(self.viewer, stretch=1)
        layout.addLayout(slider_row)
        layout.addWidget(self.lbl_frame_current)

        self.setCentralWidget(central)

    def _build_left_panel(self) -> None:
        dock = QDockWidget("Controls", self)
        dock.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )
        panel = QWidget()
        layout = QVBoxLayout(panel)

        self.btn_load = QPushButton("Load stack")
        self.btn_prev = QPushButton("Previous frame")
        self.btn_next = QPushButton("Next frame")
        self.btn_align = QPushButton("Align stack (threaded)")
        self.btn_restore = QPushButton("Restore original stack")
        self.btn_average_roi = QPushButton("Show ROI average")
        self.btn_average_full = QPushButton("Show full-stack average")
        self.btn_export_view = QPushButton("Export current view as TIFF")

        self.spin_reference = QSpinBox()
        self.spin_reference.setMinimum(0)
        self.spin_reference.setMaximum(0)

        self.spin_upsample = QSpinBox()
        self.spin_upsample.setMinimum(1)
        self.spin_upsample.setMaximum(100)
        self.spin_upsample.setValue(10)

        self.chk_roi = QCheckBox("Enable ROI")
        self.chk_crosshair = QCheckBox("Enable crosshair")
        self.chk_lock_histogram = QCheckBox("Lock histogram levels")

        self.edit_x_min = QLineEdit()
        self.edit_x_max = QLineEdit()
        self.edit_y_min = QLineEdit()
        self.edit_y_max = QLineEdit()
        self.edit_z_min = QLineEdit()
        self.edit_z_max = QLineEdit()
        for edit in (
            self.edit_x_min,
            self.edit_x_max,
            self.edit_y_min,
            self.edit_y_max,
            self.edit_z_min,
            self.edit_z_max,
        ):
            edit.setPlaceholderText("0")
            edit.setClearButtonEnabled(True)

        self.btn_apply_axis_ranges = QPushButton("Apply axis ranges")
        self.btn_axis_defaults = QPushButton("Pixels/index defaults")

        self.progress_align = QProgressBar()
        self.progress_align.setRange(0, 100)
        self.progress_align.setValue(0)
        self.progress_align.setFormat("Idle")

        form = QFormLayout()
        form.addRow("Reference frame", self.spin_reference)
        form.addRow("Upsample factor", self.spin_upsample)

        method_group = QGroupBox("Alignment method")
        method_layout = QVBoxLayout(method_group)
        self.radio_phase = QRadioButton("Phase correlation")
        self.radio_registration = QRadioButton("Image registration")
        self.radio_registration.setChecked(True)
        self.alignment_method_group = QButtonGroup(self)
        self.alignment_method_group.addButton(self.radio_phase)
        self.alignment_method_group.addButton(self.radio_registration)
        method_layout.addWidget(self.radio_registration)
        method_layout.addWidget(self.radio_phase)

        registration_group = QGroupBox("Image registration options")
        registration_layout = QVBoxLayout(registration_group)
        self.lbl_registration_note = QLabel("Default: sub-pixel translation on ROI, applied to full image.")
        self.chk_allow_rotation = QCheckBox("Allow rotation")
        self.chk_allow_scale = QCheckBox("Allow scale")
        self.chk_allow_skew = QCheckBox("Allow skew")
        self.lbl_registration_model = QLabel("Model: translation")
        registration_layout.addWidget(self.lbl_registration_note)
        registration_layout.addWidget(self.chk_allow_rotation)
        registration_layout.addWidget(self.chk_allow_scale)
        registration_layout.addWidget(self.chk_allow_skew)
        registration_layout.addWidget(self.lbl_registration_model)
        self.registration_group = registration_group

        axis_range_group = QGroupBox("Axis ranges")
        axis_range_layout = QFormLayout(axis_range_group)

        def _axis_range_row(edit_min: QLineEdit, edit_max: QLineEdit) -> QWidget:
            row = QWidget()
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.addWidget(edit_min)
            row_layout.addWidget(QLabel("to"))
            row_layout.addWidget(edit_max)
            return row

        axis_range_layout.addRow("x range", _axis_range_row(self.edit_x_min, self.edit_x_max))
        axis_range_layout.addRow("y range", _axis_range_row(self.edit_y_min, self.edit_y_max))
        axis_range_layout.addRow("z range", _axis_range_row(self.edit_z_min, self.edit_z_max))

        axis_button_row = QWidget()
        axis_button_layout = QHBoxLayout(axis_button_row)
        axis_button_layout.setContentsMargins(0, 0, 0, 0)
        axis_button_layout.addWidget(self.btn_apply_axis_ranges)
        axis_button_layout.addWidget(self.btn_axis_defaults)
        axis_range_layout.addRow(axis_button_row)

        self.lbl_axis_range_note = QLabel("Rebuilds x, y and z coordinates linearly over the current stack size.")
        self.lbl_axis_range_note.setWordWrap(True)
        self.lbl_axis_range_note.setStyleSheet("color: #666; font-size: 11px;")
        axis_range_layout.addRow(self.lbl_axis_range_note)

        layout.addWidget(self.btn_load)
        layout.addWidget(method_group)
        layout.addWidget(registration_group)
        layout.addLayout(form)
        layout.addWidget(self.btn_prev)
        layout.addWidget(self.btn_next)
        layout.addWidget(self.chk_roi)
        layout.addWidget(self.chk_crosshair)
        layout.addWidget(self.chk_lock_histogram)
        layout.addWidget(axis_range_group)
        layout.addWidget(self.btn_align)
        layout.addWidget(self.btn_restore)
        layout.addWidget(self.progress_align)
        layout.addWidget(self.btn_average_roi)
        layout.addWidget(self.btn_average_full)
        layout.addWidget(self.btn_export_view)
        layout.addStretch()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(panel)
        dock.setWidget(scroll)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, dock)

    def _build_z_profile_panel(self) -> None:
        dock = QDockWidget("Profiles", self)
        dock.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )
        panel = QWidget()
        layout = QVBoxLayout(panel)

        self.btn_plot_zprofile = QPushButton("z-profile from ROI")
        self.cmb_zprofile_stat = QComboBox()
        self.cmb_zprofile_stat.addItem("Summed ROI intensity", userData="sum")
        self.cmb_zprofile_stat.addItem("Mean gray value", userData="mean")
        self.btn_plot_lineprofile = QPushButton("Line profile using line ROI")
        self.spin_lineprofile_width = QSpinBox()
        self.btn_plot_lineslice = QPushButton("Z-slice using line ROI")
        self.spin_lineprofile_width.setRange(1, 200)
        self.spin_lineprofile_width.setValue(1)
        self.lbl_lineprofile_width_readout = QLabel("1 px")
        self.lbl_lineprofile_width_readout.setWordWrap(True)
        self.lbl_lineprofile_width_readout.setStyleSheet("color: #666; font-size: 11px;")

        line_form = QFormLayout()
        line_form.addRow("Profile width (px)", self.spin_lineprofile_width)
        line_form.addRow("", self.lbl_lineprofile_width_readout)

        layout.addWidget(self.btn_plot_zprofile)
        layout.addWidget(self.cmb_zprofile_stat)
        layout.addWidget(self.btn_plot_lineprofile)
        layout.addWidget(self.btn_plot_lineslice)
        layout.addLayout(line_form)
        layout.addStretch()

        dock.setWidget(panel)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock)

    def _profile_button_stylesheet(self, active: bool) -> str:
        bg = "#2e8b57" if active else "#b22222"
        disabled_bg = "#7aa88f" if active else "#cc8888"
        return (
            f"QPushButton {{ background-color: {bg}; color: white; font-weight: 600; padding: 8px; }}"
            f"QPushButton:disabled {{ background-color: {disabled_bg}; color: #f3f3f3; }}"
        )

    def _apply_profile_button_styles(self) -> None:
        self.btn_plot_zprofile.setStyleSheet(self._profile_button_stylesheet(self._z_profile_active))
        self.btn_plot_lineprofile.setStyleSheet(self._profile_button_stylesheet(self._line_profile_active))
        self.btn_plot_lineslice.setStyleSheet(self._profile_button_stylesheet(self._line_slice_active))

    def _any_line_mode_active(self) -> bool:
        return bool(self._line_profile_active or self._line_slice_active)

    def _ensure_line_roi_ready_for_active_modes(self) -> None:
        self.viewer.set_line_profile_width(int(self.spin_lineprofile_width.value()))
        self._update_line_width_readout()
        if self.viewer.line_profile_is_defined():
            self.viewer.show_line_profile_roi()
            if self._line_profile_active:
                self._refresh_line_profile_if_possible(show_errors=False)
            if self._line_slice_active:
                self._refresh_line_slice_if_possible(show_errors=False)
            return

        if self._line_profile_active and self.line_profile_window is not None:
            self.line_profile_window.clear_profile()
        if self._line_slice_active and self.line_slice_window is not None:
            self.line_slice_window.clear_profile()
        self.viewer.start_line_profile_drawing()
        self.statusBar().showMessage("Press and drag on the image to draw a new line ROI")

    def _set_z_profile_active(self, active: bool) -> None:
        self._z_profile_active = bool(active)
        if active:
            self.chk_roi.setChecked(True)
            self.viewer.show_roi(True)
            window = self._ensure_z_profile_window()
            self._refresh_z_profile_if_possible(show_errors=False)
            window.show()
            window.raise_()
            window.activateWindow()
        else:
            if self.z_profile_window is not None:
                self.z_profile_window.hide()
            self.chk_roi.setChecked(False)
            self.viewer.show_roi(False)
        self._apply_profile_button_styles()

    def _set_line_profile_active(self, active: bool) -> None:
        self._line_profile_active = bool(active)
        if active:
            window = self._ensure_line_profile_window()
            window.show()
            window.raise_()
            window.activateWindow()
            self._ensure_line_roi_ready_for_active_modes()
        else:
            if self.line_profile_window is not None:
                self.line_profile_window.hide()
            if not self._line_slice_active:
                self.viewer.hide_line_profile_roi()
        self._apply_profile_button_styles()

    def _set_line_slice_active(self, active: bool) -> None:
        self._line_slice_active = bool(active)
        if active:
            window = self._ensure_line_slice_window()
            window.show()
            window.raise_()
            window.activateWindow()
            self._ensure_line_roi_ready_for_active_modes()
        else:
            if self.line_slice_window is not None:
                self.line_slice_window.hide()
            if not self._line_profile_active:
                self.viewer.hide_line_profile_roi()
        self._apply_profile_button_styles()

    def _build_right_panel(self) -> None:
        dock = QDockWidget("Status", self)
        dock.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )
        panel = QWidget()
        layout = QFormLayout(panel)

        self.lbl_stack = QLabel("-")
        self.lbl_shape = QLabel("-")
        self.lbl_mouse = QLabel("x=-, y=-")
        self.lbl_value = QLabel("-")
        self.lbl_roi = QLabel("-")
        self.lbl_crosshair = QLabel("-")
        self.lbl_last_transform = QLabel("-")

        layout.addRow("Stack", self.lbl_stack)
        layout.addRow("Shape", self.lbl_shape)
        layout.addRow("Mouse", self.lbl_mouse)
        layout.addRow("Pixel value", self.lbl_value)
        layout.addRow("ROI", self.lbl_roi)
        layout.addRow("Crosshair", self.lbl_crosshair)
        layout.addRow("Last transform", self.lbl_last_transform)

        dock.setWidget(panel)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock)

    def _connect_signals(self) -> None:
        self.btn_load.clicked.connect(self.load_stack_dialog)
        self.btn_prev.clicked.connect(self.prev_frame)
        self.btn_next.clicked.connect(self.next_frame)
        self.btn_align.clicked.connect(self.run_alignment_threaded)
        self.btn_restore.clicked.connect(self.restore_original_stack)
        self.btn_average_roi.clicked.connect(self.show_average_roi)
        self.btn_average_full.clicked.connect(self.show_average_full)
        self.btn_export_view.clicked.connect(self.export_current_view)
        self.btn_plot_zprofile.clicked.connect(self.plot_z_profile)
        self.btn_plot_lineprofile.clicked.connect(self.plot_line_profile)
        self.btn_plot_lineslice.clicked.connect(self.plot_line_slice)
        self.frame_slider.valueChanged.connect(self.set_frame)
        self.chk_roi.toggled.connect(self.viewer.show_roi)
        self.chk_crosshair.toggled.connect(self.viewer.show_crosshair)
        self.chk_lock_histogram.toggled.connect(self._on_lock_histogram_toggled)
        self.btn_apply_axis_ranges.clicked.connect(self.apply_axis_ranges_from_controls)
        self.btn_axis_defaults.clicked.connect(self.apply_pixel_index_axis_defaults)
        self.radio_registration.toggled.connect(self._update_registration_options_enabled)
        self.chk_allow_rotation.toggled.connect(self._update_registration_model_label)
        self.chk_allow_scale.toggled.connect(self._update_registration_model_label)
        self.chk_allow_skew.toggled.connect(self._update_registration_model_label)
        self.spin_lineprofile_width.valueChanged.connect(self._on_line_profile_width_changed)

        self.signals.mouse_moved.connect(self.on_mouse_moved)
        self.signals.left_clicked.connect(self.on_left_clicked)
        self.signals.right_clicked.connect(self.on_right_clicked)
        self.signals.double_clicked.connect(self.on_double_clicked)
        self.signals.roi_changed.connect(self.on_roi_changed)
        self.signals.crosshair_moved.connect(self.on_crosshair_moved)
        self.signals.frame_changed.connect(self.on_frame_changed)
        self.signals.stack_loaded.connect(self.on_stack_loaded)
        self.signals.line_profile_changed.connect(self.on_line_profile_changed)
        self.signals.line_profile_finished.connect(self.on_line_profile_finished)

    def _load_dummy_data(self) -> None:
        """Optional debug helper kept for manual re-enabling only.

        pyAthina should start without bundled sample data. If you want a quick
        synthetic stack for debugging, uncomment the block below temporarily.
        """
        return

        # self.set_stack(ImageStack.dummy(), remember_as_original=True)
        # if self.stack is not None:
        #     x0, x1 = float(self.stack.x_coords.min()), float(self.stack.x_coords.max())
        #     y0, y1 = float(self.stack.y_coords.min()), float(self.stack.y_coords.max())
        #     self.viewer.set_roi(
        #         x0 + 0.2 * (x1 - x0),
        #         y0 + 0.2 * (y1 - y0),
        #         0.3 * (x1 - x0),
        #         0.3 * (y1 - y0),
        #     )
        # self.viewer.set_line_profile_width(int(self.spin_lineprofile_width.value()))
        # self._update_line_width_readout()

    def _update_registration_options_enabled(self) -> None:
        enabled = self.radio_registration.isChecked()
        self.registration_group.setEnabled(enabled)
        self._update_registration_model_label()

    def _update_registration_model_label(self) -> None:
        if not self.radio_registration.isChecked():
            self.lbl_registration_model.setText("Model: not used for phase correlation")
            return

        model = self._current_registration_model_name()
        pretty = {
            WARP_MODEL_TRANSLATION: "translation",
            WARP_MODEL_EUCLIDEAN: "translation + rotation",
            WARP_MODEL_AFFINE: "affine (translation + rotation/scale/skew)",
        }
        self.lbl_registration_model.setText(f"Model: {pretty[model]}")

    def _current_alignment_method(self) -> str:
        if self.radio_registration.isChecked():
            return ALIGNMENT_METHOD_ECC
        return ALIGNMENT_METHOD_PHASE

    def _current_registration_model_name(self) -> str:
        if self.chk_allow_skew.isChecked() or self.chk_allow_scale.isChecked():
            return WARP_MODEL_AFFINE
        if self.chk_allow_rotation.isChecked():
            return WARP_MODEL_EUCLIDEAN
        return WARP_MODEL_TRANSLATION

    def _line_width_unit(self) -> str:
        if self.stack is None:
            return ""
        x_unit = self.stack.axis_units("x")
        y_unit = self.stack.axis_units("y")
        if x_unit and x_unit == y_unit:
            return x_unit
        return x_unit or y_unit

    def _mean_axis_step(self, values) -> float:
        arr = np.asarray(values, dtype=np.float64)
        if arr.size <= 1:
            return float("nan")
        return float(np.mean(np.abs(np.diff(arr))))

    def _current_line_width_physical(self) -> float | None:
        if self.stack is None:
            return None

        width_px = max(1, int(self.spin_lineprofile_width.value()))
        dx = self._mean_axis_step(self.stack.x_coords)
        dy = self._mean_axis_step(self.stack.y_coords)

        if self.viewer.has_line_profile_roi():
            try:
                start_xy, end_xy = self.viewer.get_line_profile_points()
                start_px, end_px = self.stack.physical_line_to_pixel(start_xy, end_xy)
                delta_px = np.asarray(end_px, dtype=np.float64) - np.asarray(start_px, dtype=np.float64)
                length_px = float(np.hypot(delta_px[0], delta_px[1]))
                if length_px > 1e-12:
                    perp_px = np.array([-delta_px[1], delta_px[0]], dtype=np.float64) / length_px
                    physical_per_px = float(np.hypot(perp_px[0] * dx, perp_px[1] * dy))
                    if np.isfinite(physical_per_px) and physical_per_px > 0:
                        return float(width_px * physical_per_px)
            except Exception:
                pass

        if np.isfinite(dx) and dx > 0 and np.isfinite(dy) and dy > 0:
            fallback_per_px = float(np.hypot(dx, dy) / np.sqrt(2.0))
        elif np.isfinite(dx) and dx > 0:
            fallback_per_px = float(dx)
        elif np.isfinite(dy) and dy > 0:
            fallback_per_px = float(dy)
        else:
            return None
        return float(width_px * fallback_per_px)

    def _line_width_text(self) -> str:
        width_px = max(1, int(self.spin_lineprofile_width.value()))
        physical_width = self._current_line_width_physical()
        unit = self._line_width_unit()
        if physical_width is None or not np.isfinite(physical_width) or physical_width <= 0:
            return f"{width_px} px"
        if unit:
            return f"{width_px} px (~{physical_width:.4g} {unit})"
        return f"{width_px} px (~{physical_width:.4g})"

    def _update_line_width_readout(self) -> None:
        self.lbl_lineprofile_width_readout.setText(self._line_width_text())

    @staticmethod
    def _format_axis_edit_value(value: float) -> str:
        return f"{float(value):.12g}"

    def _set_axis_range_controls_from_stack(self) -> None:
        if self.stack is None:
            for edit in (
                self.edit_x_min,
                self.edit_x_max,
                self.edit_y_min,
                self.edit_y_max,
                self.edit_z_min,
                self.edit_z_max,
            ):
                edit.clear()
            return

        self.edit_x_min.setText(self._format_axis_edit_value(self.stack.x_coords[0]))
        self.edit_x_max.setText(self._format_axis_edit_value(self.stack.x_coords[-1]))
        self.edit_y_min.setText(self._format_axis_edit_value(self.stack.y_coords[0]))
        self.edit_y_max.setText(self._format_axis_edit_value(self.stack.y_coords[-1]))
        self.edit_z_min.setText(self._format_axis_edit_value(self.stack.z_coords[0]))
        self.edit_z_max.setText(self._format_axis_edit_value(self.stack.z_coords[-1]))

    @staticmethod
    def _parse_axis_range_from_edits(axis_name: str, edit_min: QLineEdit, edit_max: QLineEdit) -> tuple[float, float]:
        text_min = edit_min.text().strip()
        text_max = edit_max.text().strip()
        if not text_min or not text_max:
            raise ValueError(f"Enter both minimum and maximum values for axis {axis_name}.")
        try:
            start = float(text_min)
            stop = float(text_max)
        except ValueError as exc:
            raise ValueError(f"Axis {axis_name} range must contain valid numbers.") from exc
        if not np.isfinite(start) or not np.isfinite(stop):
            raise ValueError(f"Axis {axis_name} range must be finite.")
        return float(start), float(stop)

    def _default_axis_ranges(self) -> dict[str, tuple[float, float]]:
        if self.stack is None:
            return {"x": (0.0, 0.0), "y": (0.0, 0.0), "z": (0.0, 0.0)}
        ny, nx = self.stack.shape2d
        nz = self.stack.n_images
        return {
            "x": (0.0, float(max(0, nx - 1))),
            "y": (0.0, float(max(0, ny - 1))),
            "z": (0.0, float(max(0, nz - 1))),
        }

    def _load_default_axis_ranges_into_controls(self) -> None:
        defaults = self._default_axis_ranges()
        self.edit_x_min.setText(self._format_axis_edit_value(defaults["x"][0]))
        self.edit_x_max.setText(self._format_axis_edit_value(defaults["x"][1]))
        self.edit_y_min.setText(self._format_axis_edit_value(defaults["y"][0]))
        self.edit_y_max.setText(self._format_axis_edit_value(defaults["y"][1]))
        self.edit_z_min.setText(self._format_axis_edit_value(defaults["z"][0]))
        self.edit_z_max.setText(self._format_axis_edit_value(defaults["z"][1]))

    def _refresh_stack_metadata_labels(self) -> None:
        if self.stack is None:
            self.lbl_stack.setText("-")
            self.lbl_shape.setText("-")
            return
        n, (ny, nx) = self.stack.n_images, self.stack.shape2d
        self.lbl_stack.setText(self.stack.name)
        self.lbl_shape.setText(
            f"{n} × {ny} × {nx} | x=[{self.stack.x_coords[0]:.4g}, {self.stack.x_coords[-1]:.4g}] | y=[{self.stack.y_coords[0]:.4g}, {self.stack.y_coords[-1]:.4g}] | z=[{self.stack.z_coords[0]:.4g}, {self.stack.z_coords[-1]:.4g}]"
        )

    def apply_axis_ranges_from_controls(self) -> None:
        if self.stack is None:
            return

        try:
            x_range = self._parse_axis_range_from_edits("x", self.edit_x_min, self.edit_x_max)
            y_range = self._parse_axis_range_from_edits("y", self.edit_y_min, self.edit_y_max)
            z_range = self._parse_axis_range_from_edits("z", self.edit_z_min, self.edit_z_max)
        except ValueError as exc:
            QMessageBox.warning(self, "Axis range error", str(exc))
            return

        old_stack = self.stack
        roi_px = None
        if self.viewer.has_roi():
            try:
                roi_px = old_stack.physical_roi_to_pixel(self.viewer.get_roi_bounds())
            except Exception:
                roi_px = None

        self.stack = old_stack.with_linear_axis_ranges(x_range=x_range, y_range=y_range, z_range=z_range)

        if roi_px is not None:
            try:
                self.viewer.set_roi(*self.stack.pixel_roi_to_physical(roi_px))
            except Exception:
                pass

        line_roi_cleared = False
        if self.viewer.has_line_profile_roi():
            self.viewer.clear_line_profile_roi()
            line_roi_cleared = True
            if self.line_profile_window is not None:
                self.line_profile_window.clear_profile()
            if self.line_slice_window is not None:
                self.line_slice_window.clear_profile()

        self._set_axis_range_controls_from_stack()
        self._update_display()
        self._refresh_stack_metadata_labels()
        self._update_frame_indicator()
        self._update_line_width_readout()
        if self.z_profile_window is not None and self.z_profile_window.isVisible():
            self.z_profile_window.set_current_value(self.stack.z_value(self.current_index))
        if self._z_profile_active:
            self._schedule_z_profile_refresh()

        suffix = " Line ROI was cleared; redraw it if needed." if line_roi_cleared else ""
        self.statusBar().showMessage(
            f"Updated axis ranges: x=[{x_range[0]:.6g}, {x_range[1]:.6g}], y=[{y_range[0]:.6g}, {y_range[1]:.6g}], z=[{z_range[0]:.6g}, {z_range[1]:.6g}]" + suffix
        )

    def apply_pixel_index_axis_defaults(self) -> None:
        if self.stack is None:
            return
        self._load_default_axis_ranges_into_controls()
        self.apply_axis_ranges_from_controls()

    def load_stack_dialog(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Open stack",
            "",
            "Stacks (*.npy *.h5 *.hdf5 *.hdf *.tif *.tiff);;All files (*)",
        )
        if not path:
            return

        try:
            stack = load_stack_auto(path)
            self.set_stack(stack, remember_as_original=True)
        except Exception as exc:
            QMessageBox.critical(self, "Load error", str(exc))

    def set_stack(self, stack: ImageStack, remember_as_original: bool = False) -> None:
        if remember_as_original:
            self.original_stack = stack.copy(deep=True)

        self.stack = stack
        self.current_index = 0
        self.last_shifts = None
        self.last_transforms = None
        self.last_transform_models = None

        self.spin_reference.blockSignals(True)
        self.frame_slider.blockSignals(True)
        self.spin_reference.setMaximum(stack.n_images - 1)
        self.frame_slider.setMaximum(stack.n_images - 1)
        self.spin_reference.setValue(0)
        self.frame_slider.setValue(0)
        self.spin_reference.blockSignals(False)
        self.frame_slider.blockSignals(False)
        self.lbl_frame_min.setText("0")
        self.lbl_frame_max.setText(str(max(0, stack.n_images - 1)))
        self._update_frame_indicator()
        self.progress_align.setValue(0)
        self.progress_align.setFormat("Idle")
        self.btn_restore.setEnabled(self.original_stack is not None)
        self.viewer.clear_line_profile_roi()
        if self.z_profile_window is not None:
            self.z_profile_window.clear_profile()
        if self.line_profile_window is not None:
            self.line_profile_window.clear_profile()
        if self.line_slice_window is not None:
            self.line_slice_window.clear_profile()

        self._apply_profile_button_styles()
        self._set_axis_range_controls_from_stack()
        self._update_display()
        self._refresh_stack_metadata_labels()
        n, (ny, nx) = stack.n_images, stack.shape2d
        self.signals.stack_loaded.emit(stack.name, n, ny, nx)

    def set_frame(self, index: int) -> None:
        if self.stack is None:
            return
        index = max(0, min(index, self.stack.n_images - 1))
        self.current_index = index

        self.frame_slider.blockSignals(True)
        self.frame_slider.setValue(index)
        self.frame_slider.blockSignals(False)

        self._update_display()
        self._update_frame_indicator()
        self.signals.frame_changed.emit(index)

    def prev_frame(self) -> None:
        self.set_frame(self.current_index - 1)

    def next_frame(self) -> None:
        self.set_frame(self.current_index + 1)

    def _format_transform_for_display(self, index: int) -> str:
        if self.last_transforms is None or self.last_transform_models is None:
            return "-"
        model = self.last_transform_models[index]
        matrix = self.last_transforms[index]
        tx = float(matrix[0, 2])
        ty = float(matrix[1, 2])
        suffix = ""
        if "[" in model:
            base, suffix = model.split("[", 1)
            model = base.strip()
            suffix = f" [{suffix}"
        if model == WARP_MODEL_TRANSLATION:
            return f"translation{suffix}: dx={tx:.3f}, dy={ty:.3f}"
        if model == WARP_MODEL_EUCLIDEAN:
            return f"rigid{suffix}: dx={tx:.3f}, dy={ty:.3f}"
        return f"affine{suffix}: dx={tx:.3f}, dy={ty:.3f}"

    def _update_display(self) -> None:
        if self.stack is None:
            return
        self.viewer.set_image(
            self.stack.data[self.current_index],
            x_coords=self.stack.x_coords,
            y_coords=self.stack.y_coords,
            axis_labels={"x": self.stack.axis_label("x"), "y": self.stack.axis_label("y")},
            auto_levels=not self.chk_lock_histogram.isChecked(),
        )
        self._update_frame_indicator()
        self.lbl_last_transform.setText(self._format_transform_for_display(self.current_index))

    def _update_frame_indicator(self) -> None:
        if self.stack is None or self.stack.n_images <= 0:
            self.lbl_frame_current.setText("Frame 0 / 0")
            return
        self.lbl_frame_current.setText(
            f"Frame {self.current_index} / {self.stack.n_images - 1} | {self.stack.axis_label('z')}={self.stack.z_value(self.current_index):.6g}"
        )

    def _on_lock_histogram_toggled(self, checked: bool) -> None:
        if self.stack is None:
            return
        if checked:
            self.statusBar().showMessage("Histogram levels locked to current bar positions")
        else:
            self.statusBar().showMessage("Histogram levels unlocked; auto-levels restored per frame")
        self._update_display()

    def _current_roi_or_none(self):
        if self.chk_roi.isChecked() or self._z_profile_active:
            return self.viewer.get_roi_bounds()
        return None

    def _current_roi_pixels_or_none(self):
        if self.stack is None:
            return None
        roi = self._current_roi_or_none()
        if roi is None:
            return None
        return self.stack.physical_roi_to_pixel(roi)

    def _current_alignment_roi_pixels_or_none(self):
        if self.stack is None or not self.viewer.has_roi() or not self.chk_roi.isChecked():
            return None
        return self.stack.physical_roi_to_pixel(self.viewer.get_roi_bounds())

    @staticmethod
    def _format_alignment_region_status(roi) -> str:
        if roi is None:
            return "full image"
        x0, y0, w, h = roi
        return f"ROI x={x0}, y={y0}, w={w}, h={h} px"

    def _ensure_z_profile_window(self) -> ZProfileWindow:
        if self.z_profile_window is None:
            self.z_profile_window = ZProfileWindow(self)
            self.z_profile_window.hidden.connect(self._on_z_profile_window_hidden)
        return self.z_profile_window

    def _ensure_line_profile_window(self) -> LineProfileWindow:
        if self.line_profile_window is None:
            self.line_profile_window = LineProfileWindow(self)
            self.line_profile_window.hidden.connect(self._on_line_profile_window_hidden)
        return self.line_profile_window

    def _ensure_line_slice_window(self) -> LineSliceWindow:
        if self.line_slice_window is None:
            self.line_slice_window = LineSliceWindow(self)
            self.line_slice_window.hidden.connect(self._on_line_slice_window_hidden)
        return self.line_slice_window

    def plot_z_profile(self) -> None:
        if self.stack is None:
            return

        self._set_z_profile_active(not self._z_profile_active)

    def plot_line_profile(self) -> None:
        if self.stack is None:
            return

        self._set_line_profile_active(not self._line_profile_active)

    def plot_line_slice(self) -> None:
        if self.stack is None:
            return

        self._set_line_slice_active(not self._line_slice_active)

    def _schedule_z_profile_refresh(self) -> None:
        if not self._z_profile_active:
            return
        if not self._z_profile_refresh_timer.isActive():
            self._z_profile_refresh_timer.start()

    def _schedule_line_profile_refresh(self) -> None:
        if not self._line_profile_active:
            return
        if not self.viewer.has_line_profile_roi() or self.stack is None:
            return
        if not self._line_profile_refresh_timer.isActive():
            self._line_profile_refresh_timer.start()

    def _schedule_line_slice_refresh(self) -> None:
        if not self._line_slice_active:
            return
        if not self.viewer.has_line_profile_roi() or self.stack is None:
            return
        if not self._line_slice_refresh_timer.isActive():
            self._line_slice_refresh_timer.start()

    def _refresh_z_profile_if_possible(self, show_errors: bool = False) -> None:
        if self.stack is None:
            return

        roi_phys = self._current_roi_or_none()
        roi = self._current_roi_pixels_or_none()
        if roi is None or roi_phys is None:
            if show_errors:
                QMessageBox.information(self, "ROI required", "Enable the ROI first to compute a z profile.")
            return

        stat_mode = str(self.cmb_zprofile_stat.currentData() or "sum")
        try:
            if stat_mode == "sum":
                profile = roi_integrated_signal(self.stack.data, roi)
                y_label = "Summed ROI intensity"
                title = "Summed ROI intensity vs z"
                statistic_text = "summed intensity"
                export_name = "summed_roi_intensity"
                status_text = "Z-profile updated using summed ROI intensity over x and y for each z layer"
            else:
                profile = roi_mean_signal(self.stack.data, roi)
                y_label = "Mean gray value"
                title = "Mean gray value vs z"
                statistic_text = "mean gray value"
                export_name = "mean_gray_value"
                status_text = "Z-profile updated using mean gray value over the ROI for each z layer"
        except Exception as exc:
            if show_errors:
                QMessageBox.critical(self, "Z profile error", str(exc))
            return

        window = self._ensure_z_profile_window()
        window.set_profile(
            profile,
            self.stack.z_coords,
            roi_phys,
            self.stack.name,
            x_label=self.stack.axis_label("z"),
            y_label=y_label,
            title=title,
            statistic_text=statistic_text,
            export_column_name=export_name,
        )
        window.set_current_value(self.stack.z_value(self.current_index))
        self.statusBar().showMessage(status_text)

    def _refresh_line_profile_if_possible(self, show_errors: bool = False) -> None:
        if self.stack is None:
            return
        if not self.viewer.has_line_profile_roi():
            if show_errors:
                QMessageBox.information(self, "Line ROI required", "Draw a line ROI on the image first.")
            return

        try:
            start_xy, end_xy = self.viewer.get_line_profile_points()
            start_px, end_px = self.stack.physical_line_to_pixel(start_xy, end_xy)
            _, profile = line_profile_from_image(
                self.stack.data[self.current_index],
                start_px,
                end_px,
                width_px=int(self.spin_lineprofile_width.value()),
            )
            distance_axis = self.stack.line_distance_axis(start_xy, end_xy, profile.size)
        except Exception as exc:
            if show_errors:
                QMessageBox.critical(self, "Line profile error", str(exc))
            return

        window = self._ensure_line_profile_window()
        window.set_profile(
            distance_axis,
            profile,
            frame_value=self.stack.z_value(self.current_index),
            stack_name=self.stack.name,
            line_points=(start_xy, end_xy),
            profile_width=int(self.spin_lineprofile_width.value()),
            x_label=self.stack.distance_label(),
            width_text=self._line_width_text(),
        )

    def _refresh_line_slice_if_possible(self, show_errors: bool = False) -> None:
        if self.stack is None:
            return
        if not self.viewer.has_line_profile_roi():
            if show_errors:
                QMessageBox.information(self, "Line ROI required", "Draw a line ROI on the image first.")
            return

        try:
            start_xy, end_xy = self.viewer.get_line_profile_points()
            start_px, end_px = self.stack.physical_line_to_pixel(start_xy, end_xy)
            _, slice_image = line_slice_from_stack(
                self.stack.data,
                start_px,
                end_px,
                width_px=int(self.spin_lineprofile_width.value()),
            )
            distance_axis = self.stack.line_distance_axis(start_xy, end_xy, slice_image.shape[1])
        except Exception as exc:
            if show_errors:
                QMessageBox.critical(self, "Z-slice error", str(exc))
            return

        window = self._ensure_line_slice_window()
        window.set_slice(
            distance_axis,
            self.stack.z_coords,
            slice_image,
            stack_name=self.stack.name,
            line_points=(start_xy, end_xy),
            profile_width=int(self.spin_lineprofile_width.value()),
            x_label=self.stack.distance_label(),
            y_label=self.stack.axis_label("z"),
            width_text=self._line_width_text(),
        )
        window.set_current_value(self.stack.z_value(self.current_index))

    def restore_original_stack(self) -> None:
        if self._alignment_running:
            QMessageBox.information(self, "Alignment running", "Wait for the current alignment to finish before restoring the original stack.")
            return

        if self.original_stack is None:
            QMessageBox.information(self, "No original stack", "There is no saved original stack to restore.")
            return

        restored_stack = self.original_stack.copy(deep=True)
        restore_index = min(self.current_index, restored_stack.n_images - 1)
        self.set_stack(restored_stack, remember_as_original=False)
        self.set_frame(restore_index)
        self.statusBar().showMessage("Restored the original stack")
        if self._z_profile_active:
            self._schedule_z_profile_refresh()
        if self._line_slice_active and self.viewer.has_line_profile_roi():
            self._schedule_line_slice_refresh()
        if self._line_profile_active and self.viewer.has_line_profile_roi():
            self._schedule_line_profile_refresh()

    def _set_controls_enabled(self, enabled: bool) -> None:
        for widget in (
            self.btn_load,
            self.btn_prev,
            self.btn_next,
            self.btn_align,
            self.btn_restore,
            self.btn_average_roi,
            self.btn_average_full,
            self.btn_export_view,
            self.frame_slider,
            self.spin_reference,
            self.spin_upsample,
            self.chk_roi,
            self.chk_crosshair,
            self.chk_lock_histogram,
            self.edit_x_min,
            self.edit_x_max,
            self.edit_y_min,
            self.edit_y_max,
            self.edit_z_min,
            self.edit_z_max,
            self.btn_apply_axis_ranges,
            self.btn_axis_defaults,
            self.radio_phase,
            self.radio_registration,
            self.chk_allow_rotation,
            self.chk_allow_scale,
            self.chk_allow_skew,
            self.btn_plot_zprofile,
            self.btn_plot_lineprofile,
            self.btn_plot_lineslice,
            self.spin_lineprofile_width,
        ):
            widget.setEnabled(enabled)

    def run_alignment_threaded(self) -> None:
        if self.stack is None:
            return

        if self._alignment_running:
            QMessageBox.information(self, "Alignment running", "An alignment job is already running.")
            return

        self._alignment_running = True
        self._set_controls_enabled(False)
        self.progress_align.setValue(0)
        self.progress_align.setFormat("Aligning... %p%")

        reference_index = int(self.spin_reference.value())
        roi = normalize_alignment_roi(self._current_alignment_roi_pixels_or_none(), self.stack.data.shape[1:])
        upsample_factor = int(self.spin_upsample.value())
        method = self._current_alignment_method()

        self._alignment_worker = AlignmentWorker(
            stack=self.stack.data,
            reference_index=reference_index,
            roi=roi,
            method=method,
            upsample_factor=upsample_factor,
            allow_rotation=self.chk_allow_rotation.isChecked(),
            allow_scale=self.chk_allow_scale.isChecked(),
            allow_skew=self.chk_allow_skew.isChecked(),
        )
        self._alignment_thread = create_alignment_thread(self._alignment_worker)

        self._alignment_worker.progress.connect(self._on_alignment_progress)
        self._alignment_worker.finished.connect(self._on_alignment_finished)
        self._alignment_worker.failed.connect(self._on_alignment_failed)

        self._alignment_worker.finished.connect(self._cleanup_alignment_thread)
        self._alignment_worker.failed.connect(self._cleanup_alignment_thread)
        self._alignment_thread.finished.connect(self._alignment_thread.deleteLater)

        self._alignment_thread.start()
        region_text = self._format_alignment_region_status(roi)
        self.statusBar().showMessage(f"Alignment started in background thread using {region_text} for estimation")

    def _on_alignment_progress(self, done: int, total: int) -> None:
        if total <= 0:
            self.progress_align.setValue(0)
            return
        percent = int(round(100 * done / total))
        self.progress_align.setValue(percent)
        self.statusBar().showMessage(f"Alignment progress: {done}/{total}")

    def _on_alignment_finished(self, aligned_data, shifts, transforms, transform_models) -> None:
        assert self.stack is not None

        aligned_da = xr.DataArray(
            np.asarray(aligned_data),
            dims=self.stack.data_array.dims,
            coords=self.stack.data_array.coords,
            attrs=self.stack.data_array.attrs,
            name=self.stack.data_array.name,
        )
        self.stack = ImageStack.from_xarray(
            aligned_da,
            name=f"{self.stack.name} [aligned]",
            source_path=self.stack.source_path,
        )
        self.last_shifts = np.asarray(shifts)
        self.last_transforms = np.asarray(transforms)
        self.last_transform_models = list(transform_models)
        self._alignment_running = False
        self._set_controls_enabled(True)
        self.progress_align.setValue(100)
        self.progress_align.setFormat("Done")

        self.frame_slider.blockSignals(True)
        self.frame_slider.setMaximum(self.stack.n_images - 1)
        self.frame_slider.blockSignals(False)
        self.lbl_frame_max.setText(str(max(0, self.stack.n_images - 1)))

        self._update_display()
        self.statusBar().showMessage(f"Alignment finished for {self.stack.n_images} frames")
        if self._z_profile_active:
            self._schedule_z_profile_refresh()
        self._update_line_width_readout()
        if self._line_profile_active and self.viewer.has_line_profile_roi():
            self._schedule_line_profile_refresh()
        if self._line_slice_active and self.viewer.has_line_profile_roi():
            self._schedule_line_slice_refresh()
        if self.line_slice_window is not None and self.line_slice_window.isVisible():
            self.line_slice_window.set_current_value(self.stack.z_value(self.current_index))

    def _on_alignment_failed(self, message: str) -> None:
        self._alignment_running = False
        self._set_controls_enabled(True)
        self.progress_align.setValue(0)
        self.progress_align.setFormat("Failed")
        QMessageBox.critical(self, "Alignment error", message)

    def _cleanup_alignment_thread(self, *_) -> None:
        if self._alignment_thread is not None:
            self._alignment_thread.quit()
            self._alignment_thread.wait()
            self._alignment_thread = None
        self._alignment_worker = None

    def show_average_roi(self) -> None:
        if self.stack is None:
            return
        roi_phys = self._current_roi_or_none()
        roi = self._current_roi_pixels_or_none()
        if roi is None or roi_phys is None:
            QMessageBox.information(self, "ROI required", "Enable the ROI first.")
            return

        try:
            avg = average_stack_in_roi(self.stack.data, roi)
        except Exception as exc:
            QMessageBox.critical(self, "ROI average error", str(exc))
            return

        x0, y0, w, h = roi
        self.viewer.set_image(
            avg,
            x_coords=self.stack.x_coords[x0:x0 + w],
            y_coords=self.stack.y_coords[y0:y0 + h],
            axis_labels={"x": self.stack.axis_label("x"), "y": self.stack.axis_label("y")},
        )
        self.statusBar().showMessage("Showing ROI average over the current stack")

    def show_average_full(self) -> None:
        if self.stack is None:
            return
        avg = average_stack(self.stack.data)
        self.viewer.set_image(
            avg,
            x_coords=self.stack.x_coords,
            y_coords=self.stack.y_coords,
            axis_labels={"x": self.stack.axis_label("x"), "y": self.stack.axis_label("y")},
        )
        self.statusBar().showMessage("Showing full-stack average")

    def export_current_view(self) -> None:
        if self.viewer.current_image is None:
            return

        path, _ = QFileDialog.getSaveFileName(
            self,
            "Export current view as TIFF",
            str(Path.home() / "pyAthina_export.tif"),
            "TIFF (*.tif *.tiff)",
        )
        if not path:
            return

        try:
            save_image_tiff(path, self.viewer.current_image)
            self.statusBar().showMessage(f"Saved TIFF: {path}")
        except Exception as exc:
            QMessageBox.critical(self, "Export error", str(exc))

    def on_mouse_moved(self, x: float, y: float, value: float) -> None:
        self.lbl_mouse.setText(f"x={x:.4g}, y={y:.4g}")
        self.lbl_value.setText("nan" if np.isnan(value) else f"{value:.5g}")

    def on_left_clicked(self, x: float, y: float) -> None:
        self.statusBar().showMessage(f"Left click at x={x:.1f}, y={y:.1f}")

    def on_right_clicked(self, x: float, y: float) -> None:
        self.statusBar().showMessage(f"Right click at x={x:.1f}, y={y:.1f}")

    def on_double_clicked(self, x: float, y: float) -> None:
        self.statusBar().showMessage(f"Double click at x={x:.1f}, y={y:.1f}")

    def on_roi_changed(self, x: float, y: float, w: float, h: float) -> None:
        self.lbl_roi.setText(f"x={x:.4g}, y={y:.4g}, w={w:.4g}, h={h:.4g}")
        if self._z_profile_active and self.stack is not None:
            self._schedule_z_profile_refresh()

    def on_crosshair_moved(self, x: float, y: float) -> None:
        self.lbl_crosshair.setText(f"x={x:.4g}, y={y:.4g}")

    def on_frame_changed(self, index: int) -> None:
        if self.stack is not None and self.z_profile_window is not None and self.z_profile_window.isVisible():
            self.z_profile_window.set_current_value(self.stack.z_value(index))
        if self.stack is not None and self.line_slice_window is not None and self.line_slice_window.isVisible():
            self.line_slice_window.set_current_value(self.stack.z_value(index))
        if self._line_profile_active and self.viewer.has_line_profile_roi():
            self._schedule_line_profile_refresh()
        self.statusBar().showMessage(f"Frame changed to {index}")

    def on_stack_loaded(self, name: str, n: int, ny: int, nx: int) -> None:
        self._refresh_stack_metadata_labels()
        self.statusBar().showMessage(f"Loaded stack: {name}")
        if self._z_profile_active:
            self._schedule_z_profile_refresh()
        self._update_line_width_readout()
        if self._line_profile_active and self.viewer.has_line_profile_roi():
            self._schedule_line_profile_refresh()
        if self._line_slice_active and self.viewer.has_line_profile_roi():
            self._schedule_line_slice_refresh()

    def _on_line_profile_width_changed(self, value: int) -> None:
        self.viewer.set_line_profile_width(int(value))
        self._update_line_width_readout()
        self._schedule_line_profile_refresh()
        self._schedule_line_slice_refresh()

    def on_line_profile_changed(self, *_args) -> None:
        self._update_line_width_readout()
        self._schedule_line_profile_refresh()
        self._schedule_line_slice_refresh()

    def on_line_profile_finished(self, *_args) -> None:
        if self._line_profile_active:
            window = self._ensure_line_profile_window()
            self._refresh_line_profile_if_possible(show_errors=True)
            window.show()
            window.raise_()
            window.activateWindow()
        if self._line_slice_active:
            window = self._ensure_line_slice_window()
            self._refresh_line_slice_if_possible(show_errors=True)
            window.show()
            window.raise_()
            window.activateWindow()

    def _on_z_profile_window_hidden(self) -> None:
        if self._z_profile_active:
            self._set_z_profile_active(False)

    def _on_line_profile_window_hidden(self) -> None:
        if self._line_profile_active:
            self._set_line_profile_active(False)

    def _on_line_slice_window_hidden(self) -> None:
        if self._line_slice_active:
            self._set_line_slice_active(False)
