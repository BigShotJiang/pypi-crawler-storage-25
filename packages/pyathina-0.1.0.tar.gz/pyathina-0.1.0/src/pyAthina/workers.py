from __future__ import annotations

from typing import Optional

import numpy as np
from PyQt6.QtCore import QObject, QThread, pyqtSignal

from pyAthina.processing import ROI, align_stack_to_reference


class AlignmentWorker(QObject):
    """Run drift correction in a worker thread to keep the UI responsive."""

    progress = pyqtSignal(int, int)
    finished = pyqtSignal(object, object, object, object)  # aligned_stack, shifts, transforms, models
    failed = pyqtSignal(str)

    def __init__(
        self,
        stack: np.ndarray,
        reference_index: int,
        roi: Optional[ROI],
        method: str,
        upsample_factor: int,
        allow_rotation: bool = False,
        allow_scale: bool = False,
        allow_skew: bool = False,
        interpolation_order: int = 1,
        mode: str = "nearest",
        cval: float = 0.0,
    ) -> None:
        super().__init__()
        self.stack = stack
        self.reference_index = reference_index
        self.roi = roi
        self.method = method
        self.upsample_factor = upsample_factor
        self.allow_rotation = allow_rotation
        self.allow_scale = allow_scale
        self.allow_skew = allow_skew
        self.interpolation_order = interpolation_order
        self.mode = mode
        self.cval = cval

    def run(self) -> None:
        try:
            aligned, shifts, transforms, transform_models = align_stack_to_reference(
                self.stack,
                reference_index=self.reference_index,
                roi=self.roi,
                method=self.method,
                upsample_factor=self.upsample_factor,
                allow_rotation=self.allow_rotation,
                allow_scale=self.allow_scale,
                allow_skew=self.allow_skew,
                interpolation_order=self.interpolation_order,
                mode=self.mode,
                cval=self.cval,
                progress_callback=self._emit_progress,
            )
        except Exception as exc:
            self.failed.emit(str(exc))
            return

        self.finished.emit(aligned, shifts, transforms, transform_models)

    def _emit_progress(self, done: int, total: int) -> None:
        self.progress.emit(done, total)



def create_alignment_thread(worker: AlignmentWorker) -> QThread:
    thread = QThread()
    worker.moveToThread(thread)
    thread.started.connect(worker.run)
    return thread
