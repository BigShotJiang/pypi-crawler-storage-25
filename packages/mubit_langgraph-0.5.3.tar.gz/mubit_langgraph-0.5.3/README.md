# `mubit-langgraph`

LangGraph `BaseStore` backed by [MuBit](https://mubit.ai).

This adapter now uses the canonical Python SDK transport internally instead of raw `httpx`, while preserving the LangGraph store interface and adding MuBit-specific helpers for MAS and long-running coding-agent loops.

## Install

```bash
pip install mubit-langgraph[langgraph]
```

## Basic usage

```python
from mubit_langgraph import MubitStore

store = MubitStore(
    endpoint="http://127.0.0.1:3000",
    api_key="mbt_...",
)

store.batch(
    [
        PutOp(
            namespace=("memories", "user-1", "session-1"),
            key="deploy-note",
            value={"text": "Canary before rollout.", "intent": "lesson"},
        )
    ]
)
```

## Namespace mapping

| Namespace | MuBit scope |
| --- | --- |
| `("memories",)` | global |
| `("memories", user_id)` | user-scoped |
| `("memories", user_id, session_id)` | user + session scoped |

## Store behavior

- `PutOp` writes through MuBit control ingest with `upsert_key`
- `GetOp` and `SearchOp` use MuBit control query
- evidence metadata is normalized from current MuBit response fields
- namespace listing remains local-cache based
- single-item delete remains a no-op because MuBit deletion is explicit and scope-based

## MuBit extension methods

Existing MAS helpers:

- `checkpoint()`
- `record_outcome()`
- `surface_strategies()`

Current observability and coordination helpers:

- `get_context()`
- `memory_health()`
- `diagnose()`
- `archive()`
- `dereference()`
- `register_agent()`
- `list_agents()`
- `handoff()`
- `feedback()`

## Config

| Parameter | Default | Purpose |
| --- | --- | --- |
| `endpoint` | `http://127.0.0.1:3000` | MuBit HTTP endpoint |
| `api_key` | `""` | MuBit API key |

For tests or custom embedding, you can inject `mubit_client` directly.

## Development

```bash
PYTHONPATH=sdk/python/mubit-sdk/src:integrations/python \
python3 -m unittest integrations.python.mubit_langgraph.tests.test_store -v
```

## License

Apache-2.0
