from __future__ import annotations

import unittest

from mubit_langgraph.mubit_client import MubitControlClient


class FakeSdkClient:
    """Stands in for `mubit.Client` for the integration-base wrapper.

    `MubitControlClient.remember` calls top-level `ingest` + `get_ingest_job`
    on the SDK client and blocks on the latter until `done=True`. We track
    every call here so tests can assert the full submit+poll sequence.
    """

    def __init__(self) -> None:
        self.calls: list[tuple[str, dict]] = []
        self._polls = 0

    def ingest(self, payload):
        self.calls.append(("ingest", payload))
        return {"accepted": True, "job_id": "job-1"}

    def get_ingest_job(self, payload):
        self.calls.append(("get_ingest_job", payload))
        self._polls += 1
        # Succeed on the first poll so the test stays fast.
        return {"done": self._polls >= 1}


class TestMubitControlClient(unittest.TestCase):
    def test_remember_waits_for_ingest_completion(self) -> None:
        sdk_client = FakeSdkClient()
        client = MubitControlClient(sdk_client=sdk_client)

        client.remember(session_id="session-1", text="release note")

        self.assertEqual(len(sdk_client.calls), 2)
        self.assertEqual(sdk_client.calls[0][0], "ingest")
        self.assertEqual(sdk_client.calls[1][0], "get_ingest_job")
        self.assertEqual(sdk_client.calls[0][1]["run_id"], "session-1")
        self.assertEqual(sdk_client.calls[1][1]["job_id"], "job-1")


if __name__ == "__main__":
    unittest.main()
