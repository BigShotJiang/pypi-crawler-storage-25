"""Install a minimal `langgraph.store.base` stub before any test module loads.

`mubit_langgraph/__init__.py` eagerly imports from `langgraph.store.base`.
CI runs without the real `langgraph` package installed (it's an optional
runtime dep), so we seed `sys.modules` with stubs here — pytest loads
conftest.py before test modules, so top-level imports like
`from mubit_langgraph.mubit_client import MubitControlClient` resolve
cleanly in the test_mubit_client.py unit test.

Tests that need the full stub classes (dataclass PutOp/SearchOp/etc.) call
`install_langgraph_stub()` from test_store.py in their `setUpClass` to
guarantee a fresh install plus a fresh import of mubit_langgraph.
"""

from __future__ import annotations

import sys
import types
from dataclasses import dataclass


def _install_langgraph_stub() -> None:
    if "langgraph.store.base" in sys.modules:
        return

    store_base = types.ModuleType("langgraph.store.base")

    class BaseStore:
        supports_ttl = False

    @dataclass
    class Item:
        value: dict
        key: str
        namespace: tuple
        created_at: object
        updated_at: object

    @dataclass
    class SearchItem(Item):
        score: float | None = None

    @dataclass
    class GetOp:
        namespace: tuple
        key: str

    @dataclass
    class SearchOp:
        namespace: tuple
        query: str | None = None
        limit: int = 10
        filter: dict | None = None

    @dataclass
    class PutOp:
        namespace: tuple
        key: str
        value: dict

    @dataclass
    class MatchCondition:
        match_type: str
        path: tuple

    @dataclass
    class ListNamespacesOp:
        match_conditions: list | None = None
        max_depth: int | None = None
        offset: int = 0
        limit: int = 100

    store_base.BaseStore = BaseStore
    store_base.Item = Item
    store_base.SearchItem = SearchItem
    store_base.GetOp = GetOp
    store_base.SearchOp = SearchOp
    store_base.PutOp = PutOp
    store_base.ListNamespacesOp = ListNamespacesOp
    store_base.Op = object
    store_base.Result = object

    langgraph = types.ModuleType("langgraph")
    store = types.ModuleType("langgraph.store")
    langgraph.store = store
    store.base = store_base

    sys.modules["langgraph"] = langgraph
    sys.modules["langgraph.store"] = store
    sys.modules["langgraph.store.base"] = store_base


_install_langgraph_stub()
