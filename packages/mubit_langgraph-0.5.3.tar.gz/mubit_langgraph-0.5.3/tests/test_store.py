from __future__ import annotations

import importlib
import sys
import types
import unittest
from dataclasses import dataclass
from pathlib import Path


def install_langgraph_stub() -> None:
    store_base = types.ModuleType("langgraph.store.base")

    class BaseStore:
        supports_ttl = False

    @dataclass
    class Item:
        value: dict
        key: str
        namespace: tuple[str, ...]
        created_at: object
        updated_at: object

    @dataclass
    class SearchItem(Item):
        score: float | None = None

    @dataclass
    class GetOp:
        namespace: tuple[str, ...]
        key: str

    @dataclass
    class SearchOp:
        namespace: tuple[str, ...]
        query: str | None = None
        limit: int = 10
        filter: dict | None = None

    @dataclass
    class PutOp:
        namespace: tuple[str, ...]
        key: str
        value: dict

    @dataclass
    class MatchCondition:
        match_type: str
        path: tuple[str, ...]

    @dataclass
    class ListNamespacesOp:
        match_conditions: list[MatchCondition] | None = None
        max_depth: int | None = None
        offset: int = 0
        limit: int = 100

    store_base.BaseStore = BaseStore
    store_base.Item = Item
    store_base.SearchItem = SearchItem
    store_base.GetOp = GetOp
    store_base.SearchOp = SearchOp
    store_base.PutOp = PutOp
    store_base.ListNamespacesOp = ListNamespacesOp
    store_base.Op = object
    store_base.Result = object

    langgraph = types.ModuleType("langgraph")
    store = types.ModuleType("langgraph.store")
    langgraph.store = store
    store.base = store_base

    sys.modules["langgraph"] = langgraph
    sys.modules["langgraph.store"] = store
    sys.modules["langgraph.store.base"] = store_base


class MockClient:
    def __init__(self) -> None:
        self.calls: list[tuple[str, dict]] = []

    def _record(self, name: str, result):
        def inner(**payload):
            self.calls.append((name, payload))
            return result

        return inner

    def remember(self, **payload):
        self.calls.append(("remember", payload))
        return {"accepted": True, "job_id": "job-1"}

    def recall(self, **payload):
        self.calls.append(("recall", payload))
        return {
            "evidence": [
                {
                    "id": "mem-1",
                    "content": "Stored text",
                    "metadata_json": '{"author":"planner","kind":"lesson"}',
                    "score": 0.88,
                }
            ]
        }

    def get_context(self, **payload):
        self.calls.append(("get_context", payload))
        return {"context_block": "assembled"}

    def archive(self, **payload):
        self.calls.append(("archive", payload))
        return {"success": True, "reference_id": "archive-1"}

    def dereference(self, **payload):
        self.calls.append(("dereference", payload))
        return {"found": True, "evidence": {"id": "archive-1"}}

    def memory_health(self, **payload):
        self.calls.append(("memory_health", payload))
        return {"entry_counts": {"lesson": 1}}

    def diagnose(self, **payload):
        self.calls.append(("diagnose", payload))
        return {"failure_lessons": []}

    def register_agent(self, **payload):
        self.calls.append(("register_agent", payload))
        return {"success": True}

    def list_agents(self, **payload):
        self.calls.append(("list_agents", payload))
        return {"agents": []}

    def checkpoint(self, **payload):
        self.calls.append(("checkpoint", payload))
        return {"success": True}

    def record_outcome(self, **payload):
        self.calls.append(("record_outcome", payload))
        return {"success": True}

    def surface_strategies(self, **payload):
        self.calls.append(("surface_strategies", payload))
        return {"strategies": []}

    def handoff(self, **payload):
        self.calls.append(("handoff", payload))
        return {"success": True, "handoff_id": "handoff-1"}

    def feedback(self, **payload):
        self.calls.append(("feedback", payload))
        return {"success": True, "feedback_id": "feedback-1"}


class TestMubitLangGraphStore(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        install_langgraph_stub()
        package_root = Path(__file__).resolve().parents[1]
        if str(package_root) not in sys.path:
            sys.path.insert(0, str(package_root))
        # Force a fresh import so mubit_langgraph binds `PutOp`/`SearchOp`/etc.
        # to the stubbed `langgraph.store.base` classes. Without this, pytest
        # plugins (e.g. langchain-openai) may have already imported the real
        # langgraph, leaving isinstance checks against a different class object.
        for mod_name in ("mubit_langgraph", "mubit_langgraph.mubit_client"):
            sys.modules.pop(mod_name, None)
        cls.module = importlib.import_module("mubit_langgraph")

    def test_put_routes_through_sdk_client(self) -> None:
        PutOp = sys.modules["langgraph.store.base"].PutOp
        client = MockClient()
        store = self.module.MubitStore(mubit_client=client)

        store.batch(
            [
                PutOp(
                    namespace=("memories", "user-1", "session-1"),
                    key="deploy-note",
                    value={
                        "text": "Need canary before rollout.",
                        "intent": "lesson",
                        "source": "human",
                        "metadata": {"severity": "high"},
                    },
                )
            ]
        )

        self.assertEqual(
            client.calls[0],
            (
                "remember",
                {
                    "session_id": "session-1",
                    "user_id": "user-1",
                    "text": "Need canary before rollout.",
                    "intent": "lesson",
                    "source": "human",
                    "metadata": {"severity": "high"},
                    "upsert_key": "deploy-note",
                },
            ),
        )

    def test_search_normalizes_metadata_json(self) -> None:
        SearchOp = sys.modules["langgraph.store.base"].SearchOp
        client = MockClient()
        store = self.module.MubitStore(mubit_client=client)

        results = store.batch(
            [
                SearchOp(
                    namespace=("memories", "user-1", "session-1"),
                    query="rollout lesson",
                    limit=5,
                )
            ]
        )[0]

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].value["text"], "Stored text")
        self.assertEqual(
            results[0].value["metadata"],
            {"author": "planner", "kind": "lesson"},
        )

    def test_current_helper_surface_is_available(self) -> None:
        client = MockClient()
        store = self.module.MubitStore(mubit_client=client)
        namespace = ("memories", "user-1", "session-1")

        store.get_context(namespace, query="release status", mode="summary")
        store.archive(
            namespace,
            content="pytest failure summary",
            artifact_kind="failing_test_summary",
            source_tool="pytest",
        )
        store.dereference(namespace, reference_id="archive-1")
        store.memory_health(namespace, limit=50)
        store.diagnose(namespace, error_text="kubectl apply failed")
        store.register_agent(namespace, agent_id="planner", role="planner")
        store.list_agents(namespace)
        store.handoff(
            namespace,
            from_agent_id="planner",
            to_agent_id="reviewer",
            content="Review the release notes.",
        )
        store.feedback(namespace, handoff_id="handoff-1", verdict="approve")

        self.assertEqual(
            [name for name, _payload in client.calls],
            [
                "get_context",
                "archive",
                "dereference",
                "memory_health",
                "diagnose",
                "register_agent",
                "list_agents",
                "handoff",
                "feedback",
            ],
        )


if __name__ == "__main__":
    unittest.main()
