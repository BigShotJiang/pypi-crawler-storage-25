"""Application entry point: initializes Core and runs the server."""

import asyncio

from app import config, telegram_bot
from app.core.db import Db
from app.core.services import ServiceRegistry
from app.server.jinja import JinjaConfig
from mm_base6 import Core, run


async def main() -> None:
    """Initialize Core with all components and start the server."""
    core = await Core.init(
        config=config.config,
        settings_cls=config.Settings,
        state_cls=config.State,
        db_cls=Db,
        service_registry_cls=ServiceRegistry,
    )

    await run(
        core=core,
        telegram_handlers=telegram_bot.handlers,
        jinja_config_cls=JinjaConfig,
        host="0.0.0.0",  # noqa: S104 # nosec
        port=3000,
        uvicorn_log_level="warning",
    )


if __name__ == "__main__":
    asyncio.run(main())
