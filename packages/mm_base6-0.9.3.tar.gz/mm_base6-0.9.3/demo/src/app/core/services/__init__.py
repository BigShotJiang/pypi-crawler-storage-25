"""Service registry and service re-exports."""

from .data import DataService as DataService
from .misc import MiscService as MiscService


class ServiceRegistry:
    """Container for application service instances."""

    data: DataService
    misc: MiscService
