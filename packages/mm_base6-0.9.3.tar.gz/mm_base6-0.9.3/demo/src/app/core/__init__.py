"""Core module with database, services, and type definitions."""
