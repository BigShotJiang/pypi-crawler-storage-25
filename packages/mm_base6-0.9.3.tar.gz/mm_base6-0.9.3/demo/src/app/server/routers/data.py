"""REST API endpoints for data CRUD operations."""

from bson import ObjectId
from fastapi import APIRouter
from mm_mongo import MongoDeleteResult, MongoInsertManyResult, MongoInsertOneResult, MongoUpdateResult

from app.core.db import Data
from app.core.types import AppView
from mm_base6 import cbv

router = APIRouter(prefix="/api/data", tags=["data"])


@cbv(router)
class DataRouter(AppView):
    """Data API endpoints."""

    @router.post("/generate-one")
    async def generate_one(self) -> MongoInsertOneResult:
        """POST: Generate and insert a single data item."""
        return await self.core.services.data.generate_one()

    @router.post("/generate-many")
    async def generate_many(self) -> MongoInsertManyResult:
        """POST: Generate and insert multiple data items."""
        return await self.core.services.data.generate_many()

    @router.get("/{id}")
    async def get_data(self, id: ObjectId) -> Data:
        """GET: Retrieve data item by ID."""
        return await self.core.db.data.get(id)

    @router.post("/{id}/inc")
    async def inc_data(self, id: ObjectId, value: int | None = None) -> MongoUpdateResult:
        """POST: Increment data value by specified amount (default 1)."""
        return await self.core.db.data.update(id, {"$inc": {"value": value or 1}})

    @router.delete("/{id}")
    async def delete_data(self, id: ObjectId) -> MongoDeleteResult:
        """DELETE: Remove data item by ID."""
        return await self.core.db.data.delete(id)
