"""Miscellaneous API endpoints for testing and utilities."""

import asyncio
import logging
import time
from typing import Annotated

from fastapi import APIRouter, File, UploadFile
from mm_result import Result

from app.core.types import AppView
from mm_base6 import UserError, cbv

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/misc", tags=["misc"])


@cbv(router)
class MiscRouter(AppView):
    """Miscellaneous testing and utility endpoints."""

    @router.get("/user-error")
    async def user_error(self) -> str:
        """GET: Raise UserError for error handling testing."""
        raise UserError("user bla bla bla")

    @router.get("/runtime-error")
    async def runtime_error(self) -> str:
        """GET: Raise RuntimeError for error handling testing."""
        raise RuntimeError("runtime bla bla bla")

    @router.get("/sleep/{seconds}")
    async def sleep_seconds(self, seconds: int) -> dict[str, object]:
        """GET: Sleep for specified seconds and return timing info."""
        start = time.perf_counter()
        logger.info("sleep_seconds called: %d", seconds)
        await asyncio.sleep(seconds)
        counter = self.core.services.misc.increment_counter()
        logger.info("sleep_seconds: %d, perf_counter=%s, counter=%s", seconds, time.perf_counter() - start, counter)
        return {"sleep_seconds": seconds, "counter": counter, "perf_counter": time.perf_counter() - start}

    @router.get("/result-ok")
    async def result_ok(self) -> Result[str]:
        """GET: Return successful Result for response testing."""
        return Result.ok("it works")

    @router.get("/result-err")
    async def result_err(self) -> Result[str]:
        """GET: Return error Result for response testing."""
        return Result.err("bla bla", context={"logs": ["ssss", 123]})

    @router.post("/upload")
    async def upload(self, file: Annotated[UploadFile, File()]) -> dict[str, str]:
        """POST: Upload file and return its text content."""
        content = await file.read()
        text_content = content.decode("utf-8")
        return {"text_content": text_content}

    @router.post("/update-state-value")
    async def update_state_value(self) -> int:
        """POST: Increment processed_block state and return new value."""
        return await self.core.services.misc.update_state_value()
