"""Server components: routers, views, templates, and middleware."""
