"""State API endpoints."""

from fastapi import APIRouter
from starlette.responses import PlainTextResponse

from mm_base6.core.db import State
from mm_base6.server.cbv import cbv
from mm_base6.server.deps import InternalView

router: APIRouter = APIRouter(prefix="/api/system/state", tags=["system"])
"""Router for state endpoints."""


@cbv(router)
class StateRouter(InternalView):
    """API endpoints for reading application state."""

    @router.get("/toml", response_class=PlainTextResponse)
    async def get_state_as_toml(self) -> str:
        """Export all state values as TOML."""
        return self.core.builtin_services.state.export_state_as_toml()

    @router.get("/{key}/toml", response_class=PlainTextResponse)
    async def get_state_value_as_toml(self, key: str) -> str:
        """Export a single state value as TOML."""
        return self.core.builtin_services.state.export_state_value_as_toml(key)

    @router.get("/{key}/value")
    async def get_state_value(self, key: str) -> object:
        """Get the raw value of a state key."""
        return self.core.builtin_services.state.get_state_value(key)

    @router.get("/{key}")
    async def get_state_value_key(self, key: str) -> State:
        """Get the full State document for a key."""
        return await self.core.db.state.get(key)
