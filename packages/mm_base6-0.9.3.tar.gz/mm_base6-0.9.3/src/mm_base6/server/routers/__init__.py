"""Built-in router aggregation for mm_base6.

Combines all internal routers (auth, system, settings, etc.) into base_router.
"""

from fastapi import APIRouter

from . import (
    api_method,
    auth,
    event,
    settings,
    state,
    system,
    ui,
)

base_router = APIRouter()
"""Aggregated router containing all built-in mm_base6 routes."""
base_router.include_router(auth.router)
base_router.include_router(api_method.router)
base_router.include_router(ui.router)
base_router.include_router(settings.router)
base_router.include_router(state.router)
base_router.include_router(event.router)
base_router.include_router(system.router)
