"""Settings API endpoints."""

from fastapi import APIRouter
from starlette.responses import PlainTextResponse

from mm_base6.server.cbv import cbv
from mm_base6.server.deps import InternalView

router: APIRouter = APIRouter(prefix="/api/system/settings", tags=["system"])
"""Router for settings endpoints."""


@cbv(router)
class SettingsRouter(InternalView):
    """API endpoints for exporting settings."""

    @router.get("/toml", response_class=PlainTextResponse)
    async def get_settings_toml(self) -> str:
        """Export all settings as TOML."""
        return self.core.builtin_services.settings.export_as_toml()
