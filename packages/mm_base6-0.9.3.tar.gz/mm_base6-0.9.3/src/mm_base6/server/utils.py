"""Server utility functions."""

import importlib.metadata

from starlette.responses import RedirectResponse
from starlette.status import HTTP_303_SEE_OTHER


def get_package_version(package: str) -> str:
    """Return the installed version of a package, or '_development_' if not found."""
    try:
        return importlib.metadata.version(package)
    except importlib.metadata.PackageNotFoundError:
        return "_development_"


def redirect(url: str) -> RedirectResponse:
    """Create a 303 See Other redirect response."""
    return RedirectResponse(url, status_code=HTTP_303_SEE_OTHER)
