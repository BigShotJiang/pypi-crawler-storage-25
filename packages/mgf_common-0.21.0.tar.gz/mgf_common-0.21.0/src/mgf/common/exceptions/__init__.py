"""Typed exception hierarchy for any application built on mgf.common.

See: ``docs/public/02_exceptions.md``.

The shape mirrors the standard documented in
``docs/standards/ERROR_HANDLING.md``:

  * ``AppError`` — base for every exception raised by application
    code. Subclass to define your project's own base if you want a
    nominal type ("MyAppError"); see VManager's ``vmanager.exceptions``
    module for the canonical pattern.
  * Eight category bases — ``ConfigError``, ``ProviderError``,
    ``OperationError``, ``GuestError``, ``HostEnvironmentError``,
    ``VaultError``, ``SchedulerError``, ``HttpError``. The first
    seven cover systems-management domain (the original
    reference-consumer shape); ``HttpError`` (added v0.18.0,
    closes FEEDBACK HTTP-01) covers web/API consumers whose
    natural exception taxonomy is HTTP-status-coded.
  * Four generic concretes — ``SchemaValidationError`` (carries
    ``.errors``), ``CommandError`` (carries
    ``.argv`` / ``.returncode`` / ``.stderr``),
    ``ResourceNotFoundError`` (carries ``.name``),
    ``ResourceAlreadyExistsError`` (carries ``.name``). These exist
    because they're useful on their own AND because consumers
    typically subclass them rather than re-implement the field
    plumbing.
  * HTTP concrete leaves (v0.18.0) — ``HttpClientError`` (4xx
    base) and ``HttpServerError`` (5xx base), plus seven
    common-status leaves (``HttpBadRequest`` 400,
    ``HttpUnauthorized`` 401, ``HttpForbidden`` 403,
    ``HttpNotFound`` 404, ``HttpConflict`` 409, ``HttpGone`` 410,
    ``HttpUnprocessable`` 422, ``HttpInternalServerError`` 500,
    ``HttpServiceUnavailable`` 503). Each carries ``http_status``
    as a class attribute for framework integration.

Consumer projects subclass per their domain. See
``docs/standards/ERROR_HANDLING.md`` §2 for the full design rationale
and the drop-in template.
"""

from __future__ import annotations

from mgf.common.exceptions._base import AppError
from mgf.common.exceptions._well_known import (
    AppConfigError,
    AppConfigErrorKind,
    BootstrapError,
    CancellationError,
    CommandError,
    ConfigError,
    EnvironmentError,  # noqa: A004 — temporary alias for HostEnvironmentError
    GuestCommandError,
    GuestError,
    GuestUnreachableError,
    HostEnvironmentError,
    HttpBadRequest,
    HttpClientError,
    HttpConflict,
    HttpError,
    HttpForbidden,
    HttpGone,
    HttpInternalServerError,
    HttpNotFound,
    HttpServerError,
    HttpServiceUnavailable,
    HttpUnauthorized,
    HttpUnprocessable,
    OperationError,
    ProcessError,
    ProcessNonZeroExit,
    ProcessSignaled,
    ProcessTimeout,
    ProviderError,
    ResourceAlreadyExistsError,
    ResourceNotFoundError,
    SchedulerError,
    SchemaValidationError,
    ServiceNotReady,
    VaultError,
)

__all__ = [
    "AppConfigError",
    "AppConfigErrorKind",
    "AppError",
    "BootstrapError",
    "CancellationError",
    "CommandError",
    "ConfigError",
    "EnvironmentError",
    "GuestCommandError",
    "GuestError",
    "GuestUnreachableError",
    "HostEnvironmentError",
    "HttpBadRequest",
    "HttpClientError",
    "HttpConflict",
    "HttpError",
    "HttpForbidden",
    "HttpGone",
    "HttpInternalServerError",
    "HttpNotFound",
    "HttpServerError",
    "HttpServiceUnavailable",
    "HttpUnauthorized",
    "HttpUnprocessable",
    "OperationError",
    "ProcessError",
    "ProcessNonZeroExit",
    "ProcessSignaled",
    "ProcessTimeout",
    "ProviderError",
    "ResourceAlreadyExistsError",
    "ResourceNotFoundError",
    "SchedulerError",
    "SchemaValidationError",
    "ServiceNotReady",
    "VaultError",
]
