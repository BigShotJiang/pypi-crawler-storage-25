"""``mgf-common init-project`` — scaffold a new mgf-common-aligned project.

Closes the v0.9.0 deliverable: starting a new project should give
Claude (and humans) the engineering standards as context
automatically, without any manual copy-paste-and-pray. This
command generates the minimal project skeleton:

  - ``docs/CLAUDE.md`` — auto-loaded by Claude every session,
    inlines the most-violated rules, points at
    ``mgf-common standards <topic>`` for full text.
  - ``pyproject.toml`` snippet — printed to stdout for the user
    to merge (we do NOT modify an existing pyproject; that's
    riskier than printing what to add).
  - ``.claude/settings.json`` — sensible permissions for the kind
    of project being built.

The standards themselves are NOT copied — they live in
``mgf-common`` and are accessible at runtime via
``mgf-common standards <topic>``. Single source of truth; new
projects always see fresh standards by bumping their mgf-common
pin.

Usage:

.. code-block:: bash

    cd /path/to/new/project/root
    mgf-common init-project --name myapp --kind cli
    # …creates docs/CLAUDE.md + .claude/settings.json …
    # …prints the pyproject.toml additions to stdout …
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    import argparse


_KINDS = ("cli", "fastapi", "django", "library", "service")
_VALID_KIND = Literal["cli", "fastapi", "django", "library", "service"]


# CLAUDE.md delimiter markers. Wrap the auto-managed portion so
# `mgf-common catch-up --apply` can refresh just that block without
# touching project-specific content elsewhere in the file.
CLAUDE_MD_BEGIN_MARKER = (
    "<!-- BEGIN mgf-common auto-generated — managed by "
    "`mgf-common catch-up`."
)
CLAUDE_MD_END_MARKER = "<!-- END mgf-common auto-generated."


def add_init_project_args(parser: argparse.ArgumentParser) -> None:
    """Register the ``init-project`` subcommand's arguments."""
    parser.add_argument(
        "--name",
        required=True,
        help="Project name (used in CLAUDE.md + pyproject snippet).",
    )
    parser.add_argument(
        "--kind",
        choices=_KINDS,
        required=True,
        help=(
            "Project kind: cli (Click/argparse tool), fastapi "
            "(async HTTP service), django (full Django app), "
            "library (Python package for other apps), or service "
            "(plain async service / worker, not HTTP-shaped)."
        ),
    )
    parser.add_argument(
        "--path",
        type=Path,
        default=Path.cwd(),
        help=(
            "Target directory (default: current working directory). "
            "Refuses to overwrite existing files unless --force is set."
        ),
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing CLAUDE.md / .claude/settings.json.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print the files that would be created; don't write anything.",
    )


def run_init_project(args: argparse.Namespace) -> int:
    """Generate the project skeleton."""
    target_dir = args.path.resolve()
    if not target_dir.is_dir() and not args.dry_run:
        # Real run requires the target dir to exist (we won't `mkdir`
        # an arbitrary path silently). Dry-run is a preview, no
        # writes happen — we let it work against a non-existent dir
        # so users can preview before `mkdir foo && cd foo`.
        print(
            f"error: target path {target_dir} is not a directory. "
            f"(--dry-run works against non-existent paths if you "
            f"want a preview before creating the directory.)",
            file=sys.stderr,
        )
        return 1

    claude_md_path = target_dir / "docs" / "CLAUDE.md"
    settings_path = target_dir / ".claude" / "settings.json"

    if not args.force and not args.dry_run:
        existing = [p for p in (claude_md_path, settings_path) if p.exists()]
        if existing:
            print(
                f"error: refusing to overwrite existing files: "
                f"{', '.join(str(p) for p in existing)}. "
                f"Use --force to overwrite, or --dry-run to preview.",
                file=sys.stderr,
            )
            return 1

    claude_md_content = _render_claude_md(args.name, args.kind)
    settings_content = _render_claude_settings(args.kind)
    pyproject_snippet = _render_pyproject_snippet(args.name, args.kind)

    if args.dry_run:
        print(f"Would create: {claude_md_path}")
        print(f"Would create: {settings_path}")
        print()
        print("--- pyproject.toml additions (paste into your existing file) ---")
        print(pyproject_snippet)
        return 0

    claude_md_path.parent.mkdir(parents=True, exist_ok=True)
    claude_md_path.write_text(claude_md_content, encoding="utf-8")

    settings_path.parent.mkdir(parents=True, exist_ok=True)
    settings_path.write_text(settings_content, encoding="utf-8")

    print(f"created: {claude_md_path}")
    print(f"created: {settings_path}")
    print()
    print("--- pyproject.toml additions ---")
    print("Paste the following into your project's pyproject.toml:")
    print()
    print(pyproject_snippet)
    print()
    print(
        "Next: review docs/CLAUDE.md and customize the project-specific "
        "sections. Run `mgf-common standards` to list the full standards "
        "corpus.",
    )

    return 0


# ---------------------------------------------------------------------------
# CLAUDE.md template — inlines the top rules + points at the rest.
# ---------------------------------------------------------------------------


_CLAUDE_MD_TEMPLATE = """# {name} — Claude Reference

<!-- BEGIN mgf-common auto-generated — managed by `mgf-common catch-up`.
Edit only between this block's BEGIN/END markers if you want catch-up to
refresh your changes; project-specific content goes BELOW the END marker
in the "Project-specific lookup" section. -->

Project-specific lookup for Claude sessions. Cross-project
engineering standards live in `mgf-common`; run
`mgf-common standards <topic>` to read any one of them.

> **Project kind:** {kind}
> **Cornerstone library:** `mgf-common` (this project depends on it).
> **Conformance level:** L1 (production-ready) by default. See
> `mgf-common standards README` §"Conformance levels".

---

## Standing instructions — every session

Claude reads this file on every session start. The rules below are
canonical; the full text lives in `mgf-common` standards docs and
is accessible via:

```bash
mgf-common standards            # list all topics
mgf-common standards LOGGING    # print the full doc
mgf-common standards security   # alias also works
```

**Before writing or editing code in any of these areas, read the
corresponding topic doc:**

| Area | Topic | Run |
|---|---|---|
| API surface (public functions, modules) | API_DESIGN | `mgf-common standards api` |
| Error handling, exceptions, retries | ERROR_HANDLING | `mgf-common standards errors` |
| Logging, redaction, OTel | LOGGING | `mgf-common standards logging` |
| Configuration, settings, env vars | CONFIGURATION | `mgf-common standards config` |
| Secrets, TLS, subprocess, crypto | SECURITY | `mgf-common standards security` |
| Tests, fixtures, isolation | TESTING | `mgf-common standards testing` |
| Architecture, layering, replaceability | DESIGN_PRINCIPLES | `mgf-common standards design` |
| Scope (what belongs in this project) | SCOPE | `mgf-common standards scope` |

---

## The top-30 most-violated rules (inline so they're always in context)

These are the rules that come up most often in code review. Treat
every MUST as non-negotiable. The ID prefix tells you which doc
the full rationale lives in (DP- = DESIGN_PRINCIPLES, EH- =
ERROR_HANDLING, etc.).

### Architecture (DP-)

- **DP-01** Layering MUST be enforced: UI MUST NOT be imported by
  core; core MUST NOT import third-party SDKs that have a provider
  in front of them.
- **DP-02** Every third-party I/O dep MUST sit behind an ABC with
  a production AND a mock implementation.
- **DP-03** Domain types passed between modules MUST be frozen
  dataclasses (or pydantic `frozen=True`); never bare strings/dicts.
- **DP-04** Every public function MUST have a typed signature;
  `mypy --strict` MUST pass on `src/`.
- **DP-09** Cancellation MUST be explicit. Long-running ops take
  an explicit `CancellationToken`-like parameter; never thread-global.
- **DP-11** Async tasks MUST have an owner. Bare
  `asyncio.create_task(...)` without retention is a defect.
- **DP-12** Time MUST be UTC at every boundary. `datetime.now()`
  is forbidden; use `datetime.now(UTC)`. Naive datetimes never
  cross module boundaries.
- **DP-13** Every owned external resource MUST be released
  deterministically via context manager or `try / finally`.
  GC-based cleanup is a defect.

### Error handling (EH-)

- **EH-01** Every exception raised by app code MUST be a subclass
  of the application's base error class (typically
  `mgf.common.exceptions.AppError`).
- **EH-02** Third-party exceptions MUST be translated to typed
  application exceptions at the boundary. Use
  `mgf.common.providers.ProviderABC` + `@translate_at_seam` for
  this.
- **EH-03** When re-raising a translated exception, the original
  cause MUST be chained via `raise NewError(...) from original`.
- **EH-04** Every entry point MUST install a top-level handler
  (folded into `mgf.common.bootstrap()` automatically).
- **EH-07** Bare `except Exception:` (without re-raise or typed
  translation) MUST NOT appear except in narrow cleanup paths.
- **EH-11** Retries MUST use exponential backoff with full jitter
  and a finite cap. Use `mgf.common.http.RetryPolicy`.

### Logging (LG-)

- **LG-01** Every module MUST acquire its logger via
  `logging.getLogger(__name__)`. No bare `logging.info(...)`.
- **LG-04** Sensitive fields MUST be redacted by the formatter
  before any sink sees them. The default
  `mgf.common.observability.Redactor` covers the canonical set.
- **LG-05** Error-level logs MUST include the exception via
  `LOG.exception(...)` or `exc_info=True`.
- **LG-08** Log messages MUST use lazy `%`-style formatting
  (`LOG.info("processing %s", x)`), NOT f-strings.
- **LG-09** Structured fields MUST be passed via `extra={{...}}`.
- **LG-12** Log emission MUST be cheap (≤100 µs per record).
  Heavy work belongs in the handler, not the call site. Use
  `mgf.common.observability.AsyncJsonHandler` for non-blocking I/O.

### Configuration (CF-)

- **CF-01** Application config MUST live in a single typed object
  (`mgf.common.config.BaseAppSettings`-derived). No module reads
  config files / env vars directly.
- **CF-02** Precedence: CLI flags → env vars → `.env` → on-disk
  config → typed defaults.
- **CF-05** Secrets MUST NOT live in the config file; they live in
  a vault. Use `mgf.common.vault.VaultProtocol`.
- **CF-08** `Settings` is loaded once at the entry point and
  passed down by constructor injection. No module-global singletons.
- **CF-10** Tests MUST construct `Settings` with explicit values
  (no env-var leakage).

### Security (SC-)

- **SC-01** Secrets MUST live in a Vault, never in config / env /
  source / logs / crash reports.
- **SC-02** Subprocess invocation MUST use `argv` lists with
  `shell=False`.
- **SC-06** TLS verification MUST be enabled on every outbound
  connection.
- **SC-07** Every external request MUST carry a finite timeout.
- **SC-15** Filesystem operations MUST validate against directory
  traversal via `Path.resolve()` + `is_relative_to()`.

### Testing (TS-)

- **TS-01** `tests/` MUST mirror `src/` 1:1.
- **TS-02** The unit suite MUST run with no production
  credentials, no network, no real third-party daemon.
- **TS-04** `filterwarnings = ["error"]` MUST be set in
  `pyproject.toml`.
- **TS-06** Coverage gate ≥80% project-wide; ≥90% on changed
  lines.

### API design (AP-)

- **AP-01** Public API surface MUST be enumerated explicitly via
  `__all__` at every package and module boundary.
- **AP-04** Deprecation cycle MUST be: announce → still works
  (≥1 MINOR) → removed; deprecated names emit
  `DeprecationWarning`.
- **AP-08** Public modules MUST use
  `from __future__ import annotations`; runtime-unused imports go
  in `if TYPE_CHECKING:`.
- **AP-14** Internal modules MUST NOT be imported by consumers.
  Single-underscore module names are private.

---

## Quick start — bootstrapping this project

This project depends on `mgf-common`. The canonical entry point
is `mgf.common.bootstrap()`:

{quick_start_block}

For test fixtures, use `mgf.common.bootstrap_for_test()`:

```python
import pytest
from mgf.common import bootstrap_for_test, AppContext

@pytest.fixture
def app_ctx() -> AppContext:
    with bootstrap_for_test() as ctx:
        yield ctx
```

For the full integration shape (settings, exceptions, observability,
recipes), see `mgf-common`'s
`docs/public/recipes/{kind}.md` (run `mgf-common standards
components` to find it).

---

## Four green gates — every PR

Before any commit, all four MUST pass:

```bash
ruff check src tests
mypy --strict src/
pytest --cov --cov-fail-under=80
lint-imports
```

The pyproject.toml snippet generated alongside this file pre-tunes
ruff + mypy + pytest. Add `import-linter` rules for layering as
the project grows.

---

## Reporting feedback to mgf-common

Hit a sharp edge in mgf-common? Want a primitive lifted? Have a
roadmap request or aspirational comment? **`FEEDBACK.md` in the
mgf-common repo is the canonical channel** — not ad-hoc emails,
not one-off issues that get lost. Every entry follows a uniform
shape so the document is machine-actionable.

```bash
mgf-common feedback              # how to submit + severity guide
mgf-common feedback --template   # the entry template, ready to paste
mgf-common feedback --url        # the FEEDBACK.md URL on codeberg
```

Severity guide (pick one):

- 🔴 **Blocker** — getting it wrong requires a breaking change later.
- 🟡 **High** — real quality-of-life pain, additive to fix.
- 🟢 **Nice-to-have** — real value, not urgent.
- 💭 **Aspirational** — long-term direction input.

When this project's use of mgf-common surfaces a real problem
(unclear API, missing primitive, painful workaround), file it.
Pre-1.0 entries are minor commits; same concern raised post-1.0
is a breaking-change coordination exercise.

<!-- END mgf-common auto-generated. Project-specific content below
this marker is preserved across `mgf-common catch-up --apply` runs. -->

---

## Project-specific lookup

*(Add project-specific facts here as the project grows: gotchas,
non-obvious design decisions, fixed bugs, performance budgets,
etc. Keep this section the canonical "what will burn you"
reference. Do NOT add ephemeral state — current branch, in-progress
tasks — those belong in the task tracker.)*

---

*Generated by `mgf-common init-project`. Re-run with `--force` to
regenerate (your project-specific sections will be overwritten —
back them up first).*
"""


_QUICK_START_BLOCKS: dict[str, str] = {
    "cli": """```python
# src/{name}/__main__.py
import mgf.common
from mgf.common.cli import run_and_translate, build_cli, dispatch

def main(argv=None) -> int:
    parser = build_cli(prog="{name}")
    args = parser.parse_args(argv)
    with mgf.common.bootstrap(app_name="{name}", app_version="0.1.0"):
        return dispatch(args, parser=parser)

if __name__ == "__main__":
    raise SystemExit(run_and_translate(main))
```""",
    "fastapi": """```python
# src/{name}/app.py
from contextlib import asynccontextmanager
from fastapi import FastAPI
from mgf.common import bootstrap
from mgf.common.fastapi import (
    ExceptionTranslationMiddleware,
    RequestIdMiddleware,
)

@asynccontextmanager
async def lifespan(app: FastAPI):
    with bootstrap(app_name="{name}", app_version="0.1.0"):
        yield

app = FastAPI(lifespan=lifespan)
app.add_middleware(ExceptionTranslationMiddleware)
app.add_middleware(RequestIdMiddleware)
```""",
    "django": """```python
# {name}/settings.py
INSTALLED_APPS = [
    # … your apps …
    "mgf.common.django",
]

MIDDLEWARE = [
    "mgf.common.django.MgfRequestIdMiddleware",
    "mgf.common.django.MgfContextMiddleware",
    # … your other middleware …
]

LOGGING = {{
    "version": 1,
    "formatters": {{"json": {{"()": "mgf.common.django.JsonFormatter"}}}},
    "handlers": {{
        "console": {{"class": "logging.StreamHandler", "formatter": "json"}},
    }},
    "root": {{"handlers": ["console"], "level": "INFO"}},
}}

MGF_COMMON_APP_NAME = "{name}"
MGF_COMMON_APP_VERSION = "0.1.0"
```""",
    "library": """```python
# src/{name}/__init__.py
\"\"\"{name} — library shape; do NOT call bootstrap() here.\"\"\"
from mgf.common.observability import get_logger, operation_span

LOG = get_logger(__name__)

# Library code uses get_logger + operation_span (no-op-safe when no
# host has bootstrapped). The host app calls mgf.common.bootstrap().
```""",
    "service": """```python
# src/{name}/__main__.py
import asyncio
import mgf.common

async def serve() -> None:
    # … your service loop …
    pass

def main() -> int:
    with mgf.common.bootstrap(app_name="{name}", app_version="0.1.0"):
        asyncio.run(serve())
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
```""",
}


def _render_claude_md(name: str, kind: str) -> str:
    """Fill the CLAUDE.md template with project-specific blanks."""
    quick_start = _QUICK_START_BLOCKS.get(kind, _QUICK_START_BLOCKS["cli"])
    quick_start = quick_start.format(name=name)
    return _CLAUDE_MD_TEMPLATE.format(
        name=name,
        kind=kind,
        quick_start_block=quick_start,
    )


# ---------------------------------------------------------------------------
# .claude/settings.json template.
# ---------------------------------------------------------------------------


def _render_claude_settings(kind: str) -> str:
    """Generate a .claude/settings.json with sensible permissions."""
    allow: list[str] = [
        "Bash(ruff *)",
        "Bash(mypy *)",
        "Bash(pytest *)",
        "Bash(lint-imports *)",
        "Bash(uv *)",
        "Bash(git status*)",
        "Bash(git diff*)",
        "Bash(git log*)",
        "Bash(git add *)",
        "Bash(git commit *)",
        "Bash(mgf-common *)",
        "Read",
        "Edit",
        "Write",
    ]
    deny: list[str] = [
        "Bash(rm -rf *)",
        "Bash(git push --force *)",
        "Bash(git reset --hard *)",
    ]

    if kind in ("fastapi", "service", "django"):
        allow.extend(["Bash(uvicorn *)", "Bash(alembic *)"])
    if kind == "django":
        allow.append("Bash(python manage.py *)")

    payload = {
        "permissions": {
            "allow": allow,
            "deny": deny,
            "defaultMode": "default",
        },
    }
    return json.dumps(payload, indent=2) + "\n"


# ---------------------------------------------------------------------------
# pyproject.toml snippet — the four-gate config blocks.
# ---------------------------------------------------------------------------


def _render_pyproject_snippet(name: str, kind: str) -> str:
    """Generate a pyproject.toml snippet for the four gates + mgf-common dep."""
    extras_for_kind = {
        "cli": "",
        "fastapi": "[fastapi,http]",
        "django": "[django]",
        "library": "",
        "service": "[http]",
    }.get(kind, "")

    return f'''# Add the following blocks to your project's pyproject.toml.
# Generated by `mgf-common init-project --name {name} --kind {kind}`.

[project]
name = "{name}"
version = "0.1.0"
requires-python = ">=3.11"
dependencies = [
    # mgf-common is the cornerstone — depends on this for the
    # standards, primitives, and `mgf-common standards <topic>` CLI.
    "mgf-common{extras_for_kind}>=0.9.0,<0.10",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-cov>=5.0",
    "ruff>=0.4",
    "mypy>=1.10",
    "import-linter>=2.0",
]

# ---------------------------------------------------------------------------
# Four green gates — pin them. Every PR must pass all four.
# ---------------------------------------------------------------------------

[tool.ruff]
line-length = 100
target-version = "py311"
src = ["src", "tests"]

[tool.ruff.lint]
select = [
    "E", "W", "F",      # pycodestyle + pyflakes
    "I",                 # isort
    "N",                 # pep8-naming
    "UP",                # pyupgrade
    "B",                 # bugbear
    "RUF",               # ruff-specific (incl. RUF006 — unawaited tasks → DP-11)
    "DTZ",               # naive datetime → DP-12
    "ASYNC",             # asyncio correctness → DP-11
    "S",                 # bandit security checks
    "TCH",               # type-checking imports → AP-08
    "PTH",               # pathlib over os.path
]

[tool.mypy]
python_version = "3.11"
strict = true
warn_unused_ignores = true

[tool.pytest.ini_options]
minversion = "8.0"
testpaths = ["tests"]
addopts = "--strict-markers --strict-config"
filterwarnings = ["error"]   # TS-04 — every warning is an error

[tool.coverage.report]
fail_under = 80              # TS-06

[tool.importlinter]
root_packages = ["{name}"]
include_external_packages = true

# Add layering contracts as the project grows. See:
#   mgf-common standards design   # rule DP-01 (layering)
#   mgf-common standards api      # rule AP-14 (internal modules)
'''


__all__ = ["add_init_project_args", "run_init_project"]
