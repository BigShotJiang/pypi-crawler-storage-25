"""Line-by-line stdout/stderr streaming for child processes.

The thread-based streamer reads lines from a child's pipe + emits them
through :mod:`logging` line-by-line, one log record per child line. The
``Redactor`` wired by :func:`mgf.common.bootstrap` (when active) scrubs
each line before it lands in the log — so a child that prints
``DATABASE_URL=postgres://user:hunter2@host/db`` in its startup banner
does not leak the password into your log aggregator.

Each line emitted carries:

  - ``logger``  : ``mgf.process.<name>`` (the ``name=`` passed to
    :func:`mgf.common.process.run` / :class:`Service`, or
    ``argv[0]``-basename when omitted).
  - ``level``   : ``INFO`` for stdout; ``WARNING`` for stderr (so
    aggregators that filter on level surface child stderr without
    over-warning on stdout).
  - ``extra``   : ``{"child_pid": int, "stream": "stdout"|"stderr",
    "command_id": str}`` — for log-grepping by command id.
  - ``msg``     : the redacted line text (no trailing newline).

A copy of every line is also appended to a per-stream ``deque`` so
:func:`mgf.common.process.run` can return the captured output in
:class:`ProcessResult`. The deque is bounded (``maxlen=10000`` per
stream) — pathological children that emit gigabytes of stdout don't
exhaust memory; the captured tail still shows the most recent N lines.
"""

from __future__ import annotations

import logging
import threading
from collections import deque
from typing import IO, TYPE_CHECKING

if TYPE_CHECKING:
    from mgf.common.observability.redaction import Redactor


# Per-stream capture cap. Pathological children that print 1 GB of
# stdout shouldn't exhaust memory — keep the most-recent-N lines.
# 10k lines × ~200 bytes/line ≈ 2 MiB worst case, which is acceptable.
_LINE_CAPTURE_CAP = 10_000


class _StreamCapture:
    """Reader thread that pumps a child stream into log records + a deque.

    Created twice per launched process (one for stdout, one for stderr).
    ``join()`` from the main thread waits for the child to close the
    stream; works for both completed processes and processes that
    crashed mid-run (close-on-exit semantics).
    """

    def __init__(
        self,
        *,
        stream: IO[bytes],
        kind: str,  # "stdout" | "stderr"
        logger_name: str,
        child_pid: int,
        command_id: str,
        redactor: Redactor | None,
        capture: bool,
    ) -> None:
        self._stream = stream
        self._kind = kind
        self._logger = logging.getLogger(logger_name)
        self._child_pid = child_pid
        self._command_id = command_id
        self._redactor = redactor
        self._capture = capture
        self._captured: deque[str] = deque(maxlen=_LINE_CAPTURE_CAP)
        self._thread = threading.Thread(
            target=self._pump,
            name=f"mgf-process-stream-{kind}-{child_pid}",
            daemon=True,
        )

    def start(self) -> None:
        self._thread.start()

    def join(self, timeout: float | None = None) -> None:
        self._thread.join(timeout=timeout)

    @property
    def captured(self) -> str:
        """Captured output joined as a single string. Reads after join."""
        return "\n".join(self._captured)

    @property
    def captured_tail(self) -> str:
        """Last few lines — for `ProcessNonZeroExit.stderr_tail`."""
        # Last 10 lines is a useful diagnostic without being unwieldy.
        tail = list(self._captured)[-10:]
        return "\n".join(tail)

    def _pump(self) -> None:
        """Reader loop. Drains the stream until EOF + closes."""
        level = logging.INFO if self._kind == "stdout" else logging.WARNING
        try:
            # Read line-by-line. ``stream`` is binary; decode tolerantly
            # (children print arbitrary bytes; we don't want a stray
            # 0x80 byte to terminate capture).
            for raw_line in iter(self._stream.readline, b""):
                line = raw_line.decode("utf-8", errors="replace").rstrip(
                    "\r\n",
                )
                if not line:
                    continue
                if self._redactor is not None:
                    line = self._redactor.redact_string(line)
                if self._capture:
                    self._captured.append(line)
                self._logger.log(
                    level,
                    line,
                    extra={
                        "child_pid": self._child_pid,
                        "stream": self._kind,
                        "command_id": self._command_id,
                    },
                )
        finally:
            with _suppress_close_errors():
                self._stream.close()


class _suppress_close_errors:
    """``contextlib.suppress(Exception)`` written inline.

    A bare ``except Exception`` is the right catch here because
    ``stream.close()`` on a process whose pipes have already been
    closed by the OS can raise OSError, ValueError, or BrokenPipeError
    depending on platform + state. We don't care about any of them —
    the stream is gone either way.
    """

    def __enter__(self) -> None:
        return None

    def __exit__(self, *args: object) -> bool:
        return True


def get_active_redactor() -> Redactor | None:
    """Return the Redactor wired by :func:`mgf.common.bootstrap`, if any.

    Walks the active :class:`AppContext`'s wiring handles. Returns
    ``None`` when no bootstrap context is active (CLI scripts that
    use :func:`mgf.common.process.run` standalone, tests that don't
    bootstrap, etc.) — callers fall back to no-redaction in that case,
    matching the "default-on but only when bootstrap is wired" ergonomic.

    Why not read from ``logging.root.handlers``: the redactor lives
    on mgf-installed handlers; framework consumers using
    ``setup_logging=False`` (BOOTSTRAP-01) deliberately have no mgf
    handlers, so reading from there would mis-report "no redactor"
    even when one is configured at the framework level. The right
    discovery seam is the AppContext wiring.
    """
    try:
        from mgf.common._lifecycle import _GLOBAL_CONTEXT
    except ImportError:
        return None
    if _GLOBAL_CONTEXT is None:
        return None
    # The redactor is constructed inside _bootstrap_inner step 4 and
    # passed to _wire_logging; it isn't currently exposed on AppContext.
    # Reach into the wiring handles via the formatter on the first
    # mgf handler that has one. This is intentionally best-effort —
    # the public ergonomic is "redaction follows bootstrap"; the
    # implementation detail is "ask the wired logging stack."
    import logging as _logging
    for handler in _logging.root.handlers:
        formatter = getattr(handler, "formatter", None)
        if formatter is None:
            continue
        redactor = getattr(formatter, "_redactor", None)
        if redactor is not None:
            return redactor
    return None
