"""``mgf.common.process.Service`` — long-lived process with readiness wait + clean shutdown.

The orchestration primitive for "launch this dev server / database /
worker / docker-compose stack, wait until it's ready to accept
traffic, run my scope, tear it down." Used as a context manager
(recommended; teardown on exit guaranteed) or via explicit
``start() / stop()`` for finer control.

Out of scope (deliberately):

  - **Restart-on-crash supervision.** That's systemd / supervisord
    / Procfile territory. :class:`Service` is for "launch + wait
    + monitor while running + tear down" — the demo / test /
    script orchestration shape, not the production daemon shape.
  - **Restart policies + backoff.** Same scope reasoning.
  - **Multi-service dependency ordering.** A consumer who needs
    "start postgres, wait, then start the app" composes two
    :class:`Service`s with two ``with``-blocks (or a stack of
    ``ExitStack.enter_context`` calls). The library does not
    ship a docker-compose-style declarative orchestrator.
"""

from __future__ import annotations

import logging
import os
import secrets
import subprocess
import sys
import threading
import time
from collections import deque
from pathlib import Path
from types import TracebackType
from typing import TYPE_CHECKING

from mgf.common.exceptions import ServiceNotReady
from mgf.common.process._readiness import (
    LogLineReady,
    ReadinessProbe,
    wait_for_ready,
)
from mgf.common.process._run import _terminate
from mgf.common.process._streamer import _StreamCapture, get_active_redactor

if TYPE_CHECKING:
    from collections.abc import Mapping


# Cap recent captured lines exposed to LogLineReady probes. 1000 is
# enough for practical readiness-probe matching (most ready-signal
# log lines arrive in the first few hundred lines of startup output)
# while bounding memory.
_RECENT_LINE_CAP = 1_000


class Service:
    """A long-lived process with a readiness predicate + clean shutdown.

    Construct, then either:

    1. Use as a context manager (recommended)::

           with Service(["postgres", "-D", db_dir], ready=PortReady("localhost", 5432)) as svc:
               run_my_smoke_test()
           # Service is stopped on with-exit, even on test failure.

    2. Or call :meth:`start` / :meth:`stop` explicitly when the
       lifecycle doesn't fit a single scope::

           svc = Service([...], ready=...)
           svc.start()
           try:
               run_my_thing()
           finally:
               svc.stop()

    :meth:`start` blocks until the readiness predicate resolves
    (default 30s timeout) or raises :class:`ServiceNotReady`. The
    service is fully torn down before that exception is raised —
    no leaked process; the failure mode is "tried, didn't work,
    cleaned up."

    Parameters
    ----------
    command
        argv list. List-only, no shell strings (same constraint as
        :func:`run`).
    ready
        :class:`ReadinessProbe` to poll. Use one of
        :class:`PortReady` / :class:`HttpReady` / :class:`LogLineReady`
        / :class:`CallableReady`, or :class:`AllOf` / :class:`AnyOf`
        for composition.
    timeout_s
        Default 30.0. How long :meth:`start` waits for the readiness
        probe to resolve before raising :class:`ServiceNotReady`.
    poll_interval_s
        Default 0.2. How often the readiness probe is polled.
    name
        Default: basename of ``command[0]``. Used in log records
        and error messages.
    cwd / env_extra
        Same semantics as :func:`run`.
    process_group / kill_grace_s
        Same semantics as :func:`run`. Process-group cascade is the
        default for the same reason — services with child processes
        (uvicorn workers, celery prefork pools, docker-compose
        sub-services) need group-kill on shutdown to not leak.
    redact
        Same semantics as :func:`run`. ``None`` means
        "redact-via-bootstrap-Redactor when active."
    """

    def __init__(
        self,
        command: list[str],
        *,
        ready: ReadinessProbe,
        timeout_s: float = 30.0,
        poll_interval_s: float = 0.2,
        name: str | None = None,
        cwd: str | os.PathLike[str] | None = None,
        env_extra: Mapping[str, str] | None = None,
        process_group: bool = True,
        kill_grace_s: float = 5.0,
        redact: bool | None = None,
    ) -> None:
        if not isinstance(command, list) or not all(
            isinstance(a, str) for a in command
        ):
            raise TypeError(
                "Service requires command to be a list of strings"
            )
        if not command:
            raise ValueError("command must not be empty")
        self.command: list[str] = command
        self.ready: ReadinessProbe = ready
        self.timeout_s: float = timeout_s
        self.poll_interval_s: float = poll_interval_s
        self.name: str = name or Path(command[0]).name
        self.cwd = cwd
        self.env_extra = env_extra
        self.process_group: bool = process_group
        self.kill_grace_s: float = kill_grace_s
        self.redact = redact

        self.command_id: str = secrets.token_hex(4)
        self._proc: subprocess.Popen[bytes] | None = None
        self._stdout_capture: _StreamCapture | None = None
        self._stderr_capture: _StreamCapture | None = None
        self._started_at: float | None = None
        self._lock = threading.Lock()
        self._recent_lines: deque[str] = deque(maxlen=_RECENT_LINE_CAP)

    # ------------------------------------------------------------------
    # Public lifecycle
    # ------------------------------------------------------------------

    def __enter__(self) -> Service:
        self.start()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.stop()

    @property
    def is_running(self) -> bool:
        """``True`` iff the child has been started AND has not exited."""
        if self._proc is None:
            return False
        return self._proc.poll() is None

    @property
    def pid(self) -> int | None:
        """The child's PID, or ``None`` if not started."""
        if self._proc is None:
            return None
        return self._proc.pid

    @property
    def returncode(self) -> int | None:
        """The child's exit code, or ``None`` if still running."""
        if self._proc is None:
            return None
        return self._proc.returncode

    def start(self) -> None:
        """Launch + wait until ready. Raises :class:`ServiceNotReady` on timeout.

        Idempotent: calling :meth:`start` on an already-started
        service returns immediately. The "already started" check is
        ``is_running`` — so a service that has crashed will be
        re-launched on a second :meth:`start` call (which is usually
        the right behaviour for test fixtures).
        """
        with self._lock:
            if self.is_running:
                return

            logger = logging.getLogger(f"mgf.service.{self.name}")
            logger.info(
                "service starting",
                extra={
                    "command_id": self.command_id,
                    "command": self.command,
                    "service_name": self.name,
                },
            )

            redactor = self._resolve_redactor()
            env = (
                None
                if self.env_extra is None
                else {**os.environ, **dict(self.env_extra)}
            )
            start_new_session = (
                self.process_group and sys.platform != "win32"
            )

            self._started_at = time.monotonic()
            self._proc = subprocess.Popen(  # noqa: S603 — list-validated above
                self.command,
                cwd=self.cwd,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                start_new_session=start_new_session,
            )

            stream_logger_name = f"mgf.process.{self.name}"
            if self._proc.stdout is not None:
                self._stdout_capture = _StreamCapture(
                    stream=self._proc.stdout,
                    kind="stdout",
                    logger_name=stream_logger_name,
                    child_pid=self._proc.pid,
                    command_id=self.command_id,
                    redactor=redactor,
                    capture=True,
                )
                self._stdout_capture.start()
            if self._proc.stderr is not None:
                self._stderr_capture = _StreamCapture(
                    stream=self._proc.stderr,
                    kind="stderr",
                    logger_name=stream_logger_name,
                    child_pid=self._proc.pid,
                    command_id=self.command_id,
                    redactor=redactor,
                    capture=True,
                )
                self._stderr_capture.start()

            # Bind the LogLineReady probes to our capture so they
            # can scan recent lines without us exposing internals.
            self._bind_log_probes(self.ready)

            # Kick off readiness wait. On failure, tear down before
            # raising — the contract is "no leaked process on
            # failure."
            ready, last_error = wait_for_ready(
                self.ready,
                timeout_s=self.timeout_s,
                poll_interval_s=self.poll_interval_s,
            )
            if not ready:
                # Capture diagnostics BEFORE stop() — stop() drains
                # the streamers and resets state.
                tail = (
                    self._stderr_capture.captured_tail
                    if self._stderr_capture is not None
                    else ""
                )
                _diagnostic = (
                    last_error or f"stderr tail: {tail}" if tail else last_error
                )
                self._stop_locked()
                raise ServiceNotReady(
                    command=self.command,
                    command_id=self.command_id,
                    probe_description=self.ready.description,
                    timeout=self.timeout_s,
                    last_error=_diagnostic,
                )

            logger.info(
                "service ready",
                extra={
                    "command_id": self.command_id,
                    "service_name": self.name,
                    "elapsed_s": time.monotonic() - self._started_at,
                },
            )

    def stop(self) -> None:
        """Send SIGTERM → grace → SIGKILL. Idempotent.

        Safe to call multiple times; safe to call when the service
        has already exited (the exit-code is preserved on
        ``returncode``).
        """
        with self._lock:
            self._stop_locked()

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _stop_locked(self) -> None:
        """Stop logic with the lock already held."""
        if self._proc is None:
            return
        if self._proc.poll() is None:
            _terminate(
                self._proc,
                grace_s=self.kill_grace_s,
                process_group=self.process_group and sys.platform != "win32",
            )
        # Drain streamer threads.
        if self._stdout_capture is not None:
            self._stdout_capture.join(timeout=2.0)
        if self._stderr_capture is not None:
            self._stderr_capture.join(timeout=2.0)
        # NOTE: we DON'T null out self._proc — caller may want to
        # inspect ``returncode`` after stop. ``is_running`` still
        # returns False because poll() returned a value.

        logger = logging.getLogger(f"mgf.service.{self.name}")
        elapsed = (
            time.monotonic() - self._started_at
            if self._started_at is not None
            else 0.0
        )
        logger.info(
            "service stopped",
            extra={
                "command_id": self.command_id,
                "service_name": self.name,
                "returncode": self._proc.returncode,
                "elapsed_s": elapsed,
            },
        )

    def _resolve_redactor(self):  # type: ignore[no-untyped-def]
        if self.redact is False:
            return None
        redactor = get_active_redactor()
        if self.redact is True and redactor is None:
            raise RuntimeError(
                "Service(redact=True) requires mgf.common.bootstrap() "
                "to be active."
            )
        return redactor

    def _bind_log_probes(self, probe: ReadinessProbe) -> None:
        """Walk the probe tree and bind any LogLineReady to our capture.

        LogLineReady needs to peek into the captured-line history
        — but the history lives on the streamer, which the probe
        doesn't know about. This binder hands each LogLineReady a
        thunk that returns the merged-recent-lines view at call
        time.
        """
        # Local import to avoid circular: AllOf / AnyOf live in
        # _readiness; importing them at module level is fine but
        # the isinstance checks belong inside the binder.
        from mgf.common.process._readiness import AllOf, AnyOf

        if isinstance(probe, LogLineReady):
            probe._capture_provider = self._snapshot_lines_for(probe.stream)
        elif isinstance(probe, (AllOf, AnyOf)):
            for sub in probe.probes:
                self._bind_log_probes(sub)

    def _snapshot_lines_for(
        self, stream: str,
    ) -> "_LineSnapshot":
        """Return a callable yielding recent lines for ``stream``.

        Closes over the streamer; the callable is invoked by the
        probe on each poll-tick. Read-only — does not mutate the
        streamer's state.
        """
        return _LineSnapshot(self, stream)


class _LineSnapshot:
    """Callable adapter from Service+stream → list of recent lines.

    A class (not a closure) so it survives pickle / repr cleanly,
    and its return shape is documented as a list-of-strings copy
    (not the live deque) so the probe never mutates the streamer's
    state.
    """

    def __init__(self, service: Service, stream: str) -> None:
        self._service = service
        self._stream = stream

    def __call__(self) -> list[str]:
        snap: list[str] = []
        if self._stream in ("stdout", "both") and self._service._stdout_capture is not None:
            snap.extend(self._service._stdout_capture._captured)
        if self._stream in ("stderr", "both") and self._service._stderr_capture is not None:
            snap.extend(self._service._stderr_capture._captured)
        return snap
