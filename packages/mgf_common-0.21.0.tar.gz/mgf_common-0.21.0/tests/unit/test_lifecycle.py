"""Phase 1 of the v0.3 closed-box redesign — lifecycle tests.

Covers the new ``bootstrap()`` + ``AppContext`` + ``current_context()``
surface plus the round-2 additions:

  - §14.2 Bootstrap atomicity — transactional with rollback.
  - §14.3 Bootstrap-time logging — deferred replay buffer.
  - §14.10 Bootstrap idempotency — replace + AUDIT log.

The existing v0.1 APIs (configure / setup_logging / setup_otel /
install_excepthook / install_threading_excepthook) are NOT tested
here — their existing tests in ``tests/unit/test_identity.py``
and ``tests/unit/observability/`` continue to pass unchanged.

Each test isolates side-effects via tempfile + monkeypatch +
explicit ``shutdown()`` so no test leaves the process in a wired
state.
"""

from __future__ import annotations

import contextlib
import logging
import sys
from typing import TYPE_CHECKING, Any

import pytest
from pydantic import ValidationError

import mgf.common
from mgf.common import _identity, _lifecycle
from mgf.common.exceptions import BootstrapError
from mgf.common.settings import (
    CrashSettings,
    LoggingSettings,
    MgfSettings,
    OtelSettings,
    RedactionSettings,
)

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Fixtures — process-global state isolation
# ---------------------------------------------------------------------------


@pytest.fixture
def _isolated_state(monkeypatch: Any, tmp_path: Path) -> Path:
    """Redirect XDG state to tmp_path; restore identity + global ctx."""
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path))
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.delenv("JOURNAL_STREAM", raising=False)
    monkeypatch.delenv("INVOCATION_ID", raising=False)
    # Pristine identity so app_name() returns the placeholder.
    monkeypatch.setattr(_identity, "_APP_NAME", "app")
    monkeypatch.setattr(_identity, "_APP_VERSION", "unknown")
    monkeypatch.setattr(_identity, "_CONFIGURED", False)
    monkeypatch.setattr(_identity, "_UNCONFIGURED_WARNED", False)
    # Pristine global context so each test sees no prior bootstrap.
    monkeypatch.setattr(_lifecycle, "_GLOBAL_CONTEXT", None)
    return tmp_path


@pytest.fixture
def _isolated_logging() -> Any:
    """Save + restore root-logger handlers around each test."""
    yield
    # Close + remove every handler to satisfy filterwarnings = error
    # (RotatingFileHandler GC fires ResourceWarning otherwise).
    for h in list(logging.root.handlers):
        with contextlib.suppress(Exception):
            h.close()
        logging.root.removeHandler(h)


@pytest.fixture
def _isolated_excepthook() -> Any:
    """Save + restore sys.excepthook + threading.excepthook."""
    import threading

    prior_sys = sys.excepthook
    prior_threading = threading.excepthook
    # Replace sys.excepthook with no-op so pytest's prior hook
    # doesn't capture synthetic exceptions during tests.
    sys.excepthook = lambda *_args: None
    yield
    sys.excepthook = prior_sys
    threading.excepthook = prior_threading


# ---------------------------------------------------------------------------
# bootstrap() — basic shape
# ---------------------------------------------------------------------------


class TestBootstrapBasic:
    """The headline contract: one call, full setup, clean exit."""

    def test_bootstrap_as_context_manager(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None,
    ) -> None:
        with mgf.common.bootstrap(app_name="test-app", app_version="0.0.1") as ctx:
            assert ctx.app_name == "test-app"
            assert ctx.app_version == "0.0.1"
            assert mgf.common.current_context() is ctx
        # After exit, context is cleared.
        assert mgf.common.current_context() is None

    def test_bootstrap_as_one_shot_returns_appcontext(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None,
    ) -> None:
        """The dual-mode return: ``ctx = bootstrap(...)`` works
        without ``with``. The returned wrapper delegates to the
        AppContext."""
        ctx = mgf.common.bootstrap(app_name="oneshot", app_version="1.0")
        try:
            assert ctx.app_name == "oneshot"
            assert ctx.app_version == "1.0"
            assert mgf.common.current_context() is not None
        finally:
            ctx.shutdown()
        assert mgf.common.current_context() is None

    def test_bootstrap_default_settings_use_auto_preset(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None,
    ) -> None:
        """FEEDBACK §14.15: omitted ``settings=`` → preset='auto'
        (preserves v0.1 behaviour for legacy consumers)."""
        with mgf.common.bootstrap(app_name="auto-default", app_version="0.0") as ctx:
            assert ctx.settings.preset == "auto"

    def test_bootstrap_explicit_settings_keep_preset(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None,
    ) -> None:
        """Explicit MgfSettings(...) defaults to preset='explicit'
        — the new-project default."""
        s = MgfSettings(logging=LoggingSettings(level="DEBUG"))
        with mgf.common.bootstrap(
            app_name="explicit", app_version="0.0", settings=s,
        ) as ctx:
            assert ctx.settings.preset == "explicit"
            assert ctx.settings.logging.level == "DEBUG"

    def test_app_name_resolves_via_current_context(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None,
    ) -> None:
        """``app_name()`` consults current_context() first; the
        value matches what bootstrap was called with."""
        with mgf.common.bootstrap(app_name="ctx-app", app_version="0.1"):
            assert mgf.common.app_name() == "ctx-app"
            assert mgf.common.app_version() == "0.1"

    def test_shutdown_is_idempotent(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None,
    ) -> None:
        """Two shutdowns do not raise; second is a no-op."""
        ctx = mgf.common.bootstrap(app_name="idem", app_version="0.0")
        ctx.shutdown()
        ctx.shutdown()  # MUST NOT raise


# ---------------------------------------------------------------------------
# Atomicity (FEEDBACK §14.2)
# ---------------------------------------------------------------------------


class TestBootstrapSetupLoggingFlag:
    """BOOTSTRAP-01 — ``bootstrap(setup_logging=False)``.

    When the consumer's framework owns the logging stack (Django
    LOGGING dictConfig, FastAPI/uvicorn logging, Flask app.logger),
    bootstrap() must NOT install StreamHandler / RotatingFileHandler
    on top — that produces double log emission and conflicts with
    framework-native carve-outs (LOG-01).
    """

    def test_setup_logging_false_skips_handler_install(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None,
    ) -> None:
        # Snapshot whatever handlers are present BEFORE bootstrap
        # (the framework's dictConfig has run by now in real usage;
        # our isolation fixture just clears them, so the baseline is
        # 0 handlers).
        before = list(logging.root.handlers)

        ctx = mgf.common.bootstrap(
            app_name="django-style",
            app_version="0.0.1",
            setup_logging=False,
        )
        try:
            after = list(logging.root.handlers)
            # No handlers added — framework keeps full control.
            assert after == before
            # But identity + AppContext registration still happened.
            assert ctx.app_name == "django-style"
            assert mgf.common.current_context() is ctx
        finally:
            ctx.shutdown()

    def test_setup_logging_true_installs_handlers(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None,
    ) -> None:
        # Default behaviour — handlers ARE installed.
        ctx = mgf.common.bootstrap(
            app_name="default-style",
            app_version="0.0.1",
        )
        try:
            assert len(logging.root.handlers) > 0
        finally:
            ctx.shutdown()

    def test_setup_logging_false_skips_level_overrides(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None,
    ) -> None:
        # When skipped, level_overrides MUST not run either — they
        # presume the handlers exist + are owned by mgf-common.
        target = "test_bootstrap_skip_overrides_logger"
        prior_level = logging.getLogger(target).level
        s = MgfSettings(
            logging=LoggingSettings(
                level_overrides={target: "ERROR"},
            ),
        )
        ctx = mgf.common.bootstrap(
            app_name="skip-overrides",
            app_version="0.0.1",
            settings=s,
            setup_logging=False,
        )
        try:
            # Override should NOT have been applied.
            assert logging.getLogger(target).level == prior_level
        finally:
            ctx.shutdown()


class TestBootstrapAtomicity:
    """Bootstrap is transactional. On any failure, partial state
    is rolled back and ``BootstrapError`` is raised carrying the
    failed step + the original cause."""

    def test_bootstrap_failure_rolls_back_partial_state(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Inject a failure at the OTel step. Assert no log handlers
        left attached and BootstrapError carries the right metadata."""

        def _bad_setup_otel(*args: Any, **kwargs: Any) -> None:
            raise RuntimeError("synthetic OTel setup failure")

        # Patch where bootstrap looks it up (lazy import inside).
        # bootstrap calls the PRIVATE `_wire_otel` to bypass the
        # deprecation warning the public `setup_otel` shim emits.
        monkeypatch.setattr(
            "mgf.common.observability.otel_setup._wire_otel",
            _bad_setup_otel,
        )

        with pytest.raises(BootstrapError) as exc_info:
            mgf.common.bootstrap(
                app_name="rollback-test",
                app_version="0.0",
                settings=MgfSettings(otel=OtelSettings(enabled=True)),
            )

        assert exc_info.value.failed_step == "otel"
        assert "synthetic OTel setup failure" in str(exc_info.value.__cause__)
        # Identity rolled back to the placeholder defaults.
        assert _identity._APP_NAME == "app"
        # No global context left.
        assert _lifecycle._GLOBAL_CONTEXT is None

    def test_bootstrap_failure_message_carries_cause(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """The BootstrapError message includes the failed step name
        AND the original exception text, with `__cause__` populated."""

        def _bad_install(*a: Any, **kw: Any) -> None:
            raise OSError("permission denied: cannot install hook")

        # Patch the private `_wire_excepthook` (bootstrap bypasses
        # the deprecated public `install_excepthook` shim).
        monkeypatch.setattr(
            "mgf.common.observability.excepthook._wire_excepthook",
            _bad_install,
        )
        with pytest.raises(BootstrapError) as exc_info:
            mgf.common.bootstrap(app_name="hook-fail", app_version="0.0")

        assert exc_info.value.failed_step == "excepthooks"
        assert "permission denied" in str(exc_info.value.__cause__)


# ---------------------------------------------------------------------------
# Idempotency (FEEDBACK §14.10)
# ---------------------------------------------------------------------------


class TestBootstrapIdempotency:
    """Second bootstrap() call replaces; previous context gets
    shutdown; AUDIT log fires."""

    def test_second_bootstrap_replaces_previous(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None,
    ) -> None:
        ctx1 = mgf.common.bootstrap(app_name="first", app_version="1.0")
        try:
            assert mgf.common.current_context().app_name == "first"
            ctx2 = mgf.common.bootstrap(app_name="second", app_version="2.0")
            try:
                assert mgf.common.current_context().app_name == "second"
                # Previous ctx was shut down by the second call.
                assert ctx1._shut_down is True
            finally:
                ctx2.shutdown()
        finally:
            with contextlib.suppress(Exception):
                ctx1.shutdown()  # idempotent; no-op


# ---------------------------------------------------------------------------
# Bootstrap-time log buffer (FEEDBACK §14.3)
# ---------------------------------------------------------------------------


class TestBootstrapLogBuffer:
    """The deferred replay buffer captures records emitted from
    inside bootstrap and replays them through the wired handlers."""

    def test_buffer_captures_and_replays(self) -> None:
        """Direct unit test of the buffer mechanics."""
        buffer = _lifecycle._BootstrapLogBuffer()
        # Synthesise three records.
        for i in range(3):
            record = logging.LogRecord(
                name="test",
                level=logging.INFO,
                pathname=__file__,
                lineno=1,
                msg=f"msg-{i}",
                args=None,
                exc_info=None,
            )
            buffer.emit(record)
        assert len(buffer._records) == 3

        # Replay through a target handler that captures.
        target = logging.Handler(level=logging.INFO)
        seen: list[str] = []
        target.handle = lambda r: seen.append(r.getMessage())  # type: ignore[method-assign]
        buffer.replay_to([target])
        assert seen == ["msg-0", "msg-1", "msg-2"]

    def test_buffer_respects_target_handler_level(self) -> None:
        """Replay applies the target's level filter — DEBUG records
        get dropped if the target is set to INFO."""
        buffer = _lifecycle._BootstrapLogBuffer()
        for level, msg in [(logging.DEBUG, "debug-msg"), (logging.INFO, "info-msg")]:
            record = logging.LogRecord(
                name="test", level=level, pathname=__file__, lineno=1,
                msg=msg, args=None, exc_info=None,
            )
            buffer.emit(record)

        target = logging.Handler(level=logging.INFO)
        seen: list[str] = []
        target.handle = lambda r: seen.append(r.getMessage())  # type: ignore[method-assign]
        buffer.replay_to([target])
        assert seen == ["info-msg"]


# ---------------------------------------------------------------------------
# AppContext (the data shape)
# ---------------------------------------------------------------------------


class TestAppContext:
    """The frozen-snapshot data class returned by bootstrap."""

    def test_appcontext_carries_settings(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None,
    ) -> None:
        s = MgfSettings(
            logging=LoggingSettings(level="WARNING"),
            otel=OtelSettings(sample_rate=0.5),
        )
        with mgf.common.bootstrap(
            app_name="data", app_version="9.9", settings=s,
        ) as ctx:
            assert ctx.settings.logging.level == "WARNING"
            assert ctx.settings.otel.sample_rate == 0.5


# ---------------------------------------------------------------------------
# MgfSettings — the typed root
# ---------------------------------------------------------------------------


class TestMgfSettings:
    """The library's own settings root."""

    def test_defaults_construct_cleanly(self) -> None:
        s = MgfSettings()
        assert s.preset == "explicit"
        assert s.logging.level == "INFO"
        assert s.otel.enabled is False
        assert s.crash.sinks == ["local"]
        assert s.redaction.strict_mode is False

    def test_env_var_aliases_work(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """``MGF_*`` env vars override defaults via pydantic-settings
        nested-delimiter convention."""
        monkeypatch.setenv("MGF_LOGGING__LEVEL", "DEBUG")
        monkeypatch.setenv("MGF_OTEL__SAMPLE_RATE", "0.1")
        s = MgfSettings()
        assert s.logging.level == "DEBUG"
        assert s.otel.sample_rate == 0.1

    def test_unknown_field_rejected(self) -> None:
        """Rule CF-06: extra='forbid' on every sub-model."""
        with pytest.raises(ValidationError):
            LoggingSettings(unknown_field=42)  # type: ignore[call-arg]

    def test_level_overrides_field_typed(self) -> None:
        """FEEDBACK §14.6: per-component log levels first-class."""
        s = LoggingSettings(level_overrides={
            "mgf.common.observability": "DEBUG",
            "urllib3": "WARNING",
        })
        assert s.level_overrides["mgf.common.observability"] == "DEBUG"

    def test_strict_mode_field_present(self) -> None:
        """FEEDBACK §14.12: GDPR strict mode field wired in Phase 1
        (patterns themselves wired in Phase 6)."""
        s = RedactionSettings(strict_mode=True)
        assert s.strict_mode is True

    def test_sample_rate_validated(self) -> None:
        """OtelSettings.sample_rate MUST be in [0.0, 1.0]."""
        with pytest.raises(ValidationError):
            OtelSettings(sample_rate=1.5)
        with pytest.raises(ValidationError):
            OtelSettings(sample_rate=-0.1)

    def test_recursive_serialisation(self) -> None:
        """``model_dump_for_yaml`` recurses into sub-models (works
        around the shallow ``to_yaml_dict`` known limitation)."""
        s = MgfSettings(
            logging=LoggingSettings(level="DEBUG"),
            crash=CrashSettings(sinks=["local", "sentry"]),
        )
        dumped = s.model_dump_for_yaml()
        assert dumped["logging"]["level"] == "DEBUG"
        assert dumped["crash"]["sinks"] == ["local", "sentry"]


# ---------------------------------------------------------------------------
# Per-component log level overrides applied at bootstrap (§14.6)
# ---------------------------------------------------------------------------


class TestLevelOverridesAppliedAtBootstrap:
    """The level_overrides dict is applied during _wire_logging
    so the named loggers see the override level."""

    def test_overrides_set_logger_levels(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None,
    ) -> None:
        s = MgfSettings(logging=LoggingSettings(
            level="INFO",
            level_overrides={"some.deep.module": "DEBUG"},
        ))
        with mgf.common.bootstrap(
            app_name="lo", app_version="0.0", settings=s,
        ):
            assert logging.getLogger("some.deep.module").level == logging.DEBUG

    def test_overrides_rolled_back_on_shutdown(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None,
    ) -> None:
        prior = logging.getLogger("rollback.test").level
        s = MgfSettings(logging=LoggingSettings(
            level_overrides={"rollback.test": "ERROR"},
        ))
        ctx = mgf.common.bootstrap(
            app_name="rb", app_version="0.0", settings=s,
        )
        assert logging.getLogger("rollback.test").level == logging.ERROR
        ctx.shutdown()
        # Restored to prior level.
        assert logging.getLogger("rollback.test").level == prior


# ---------------------------------------------------------------------------
# current_context() — resolution order
# ---------------------------------------------------------------------------


class TestCurrentContext:
    """The accessor consulted by every observability function."""

    def test_returns_none_before_bootstrap(self) -> None:
        # _isolated_state isn't a fixture here — we just verify the
        # module-level state without bootstrapping.
        # If a prior test left a context, skip via the global directly.
        assert _lifecycle._GLOBAL_CONTEXT is None or isinstance(
            _lifecycle._GLOBAL_CONTEXT, _lifecycle.AppContext,
        )

    def test_returns_active_context_after_bootstrap(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None,
    ) -> None:
        with mgf.common.bootstrap(app_name="active", app_version="0.0") as ctx:
            assert mgf.common.current_context() is ctx

    def test_returns_none_after_shutdown(
        self, _isolated_state: Path, _isolated_logging: None,
        _isolated_excepthook: None,
    ) -> None:
        ctx = mgf.common.bootstrap(app_name="cleanup", app_version="0.0")
        ctx.shutdown()
        assert mgf.common.current_context() is None
