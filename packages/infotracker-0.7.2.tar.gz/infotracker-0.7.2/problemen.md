# Problemen

- Data analizy: 2026-03-18 10:47:43
- Źródło: `build/output/full_prod_41/column_graph.json`
- Wszystkie temp datasety (`#`): 837
- Temp bez źródła (incoming=0): 20
- Temp bez dzieci (outgoing=0): 467

## Temp bez źródła (incoming = 0) — pogrupowane wg procedury

### mssql://localhost/EDW_CORE.dbo.update_FactSecInsurance_MSBRG (1)

- mssql://localhost/EDW_CORE.dbo.update_FactSecInsurance_MSBRG#InsurancePolicy_MSBV

### mssql://localhost/EDW_CORE.dbo.update_FactSecSRPortfolioOuts (1)

- mssql://localhost/EDW_CORE.dbo.update_FactSecSRPortfolioOuts#SecuritisationCalculationLog_MaxSecuId_AUXBV

### mssql://localhost/EDW_CORE.dbo.update_FactSecSRPurchasePric (1)

- mssql://localhost/EDW_CORE.dbo.update_FactSecSRPurchasePric#SecuritisationCalculationLog_MaxSecuId_AUXBV

### mssql://localhost/EDW_CORE.dbo.update_OBT_Annex8_MSBRG (1)

- mssql://localhost/EDW_CORE.dbo.update_OBT_Annex8_MSBRG#DimSecContract_MSBV

### mssql://localhost/EDW_CORE.dbo.update_Offer_BRG (3)

- mssql://localhost/EDW_CORE.dbo.update_Offer_BRG#Offer_CommissionRegisterAgreement_lnk_MSAUX
- mssql://localhost/EDW_CORE.dbo.update_Offer_BRG#Offer_FirstOfferNumber_lnk
- mssql://localhost/EDW_CORE.dbo.update_Offer_BRG#Offer_LinkedOffer_lnk_MSAUX

### mssql://localhost/EDW_CORE.dbo.update_PublicRegisterData_MSP (1)

- mssql://localhost/EDW_CORE.dbo.update_PublicRegisterData_MSP#ClientScoring_hub_ActiveKeysHistory

### mssql://localhost/EDW_CORE.dbo.update_src_ADP_BRG_CFM (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ADP_BRG_CFM#ADP_src

### mssql://localhost/EDW_CORE.dbo.update_src_ADP_BRG_EFL (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ADP_BRG_EFL#ADP_src

### mssql://localhost/EDW_CORE.dbo.update_src_ADP_BRG_EFLF (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ADP_BRG_EFLF#ADP_src

### mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_CFM_initial (1)

- mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_CFM_initial#src

### mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_EFL (1)

- mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_EFL#DAC_src

### mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_EFLF (1)

- mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_EFLF#DAC_src

### mssql://localhost/EDW_CORE.dbo.update_stage_lfo_Offer_Partne (1)

- mssql://localhost/EDW_CORE.dbo.update_stage_lfo_Offer_Partne#temp2

### mssql://localhost/EDW_CORE.dbo.update_stage_mis_ProcessParam (1)

- mssql://localhost/EDW_CORE.dbo.update_stage_mis_ProcessParam#stage_mis_ProcessParameterValue

### mssql://localhost/EDW_CORE.dbo.update_stage_mis_ProcessTask_ (1)

- mssql://localhost/EDW_CORE.dbo.update_stage_mis_ProcessTask_#stage_mis_ProcessTask_ProcessTaskData_src

### mssql://localhost/METRICS_CORE.dbo.sp_BlitzFirst (1)

- mssql://localhost/METRICS_CORE.dbo.sp_BlitzFirst#PerfmonStats

### mssql://localhost/METRICS_CORE.dbo.update_src_DQ_src_vdesk_DI_2 (1)

- mssql://localhost/METRICS_CORE.dbo.update_src_DQ_src_vdesk_DI_2#DI_Current

### mssql://localhost/METRICS_CORE.dbo.update_src_DQ_src_vdesk_Doc_2 (1)

- mssql://localhost/METRICS_CORE.dbo.update_src_DQ_src_vdesk_Doc_2#DI_Current

## Temp bez dzieci (outgoing = 0) — pogrupowane wg procedury

### mssql://localhost/CONFIG.dbo.EFL_GrantAccess (4)

- mssql://localhost/CONFIG.dbo.EFL_GrantAccess#InvalidDatabaseObjects
- mssql://localhost/CONFIG.dbo.EFL_GrantAccess#MissingLogins
- mssql://localhost/CONFIG.dbo.EFL_GrantAccess#MissingUsers
- mssql://localhost/CONFIG.dbo.EFL_GrantAccess#ServerPrincipals

### mssql://localhost/CONFIG.dbo.EFL_PartitionUpkeep (11)

- mssql://localhost/CONFIG.dbo.EFL_PartitionUpkeep#FileGroupCurrent
- mssql://localhost/CONFIG.dbo.EFL_PartitionUpkeep#LastFileGroup
- mssql://localhost/CONFIG.dbo.EFL_PartitionUpkeep#lastPartition
- mssql://localhost/CONFIG.dbo.EFL_PartitionUpkeep#missingFile
- mssql://localhost/CONFIG.dbo.EFL_PartitionUpkeep#missingFile.fg
- mssql://localhost/CONFIG.dbo.EFL_PartitionUpkeep#missingFilegroup
- mssql://localhost/CONFIG.dbo.EFL_PartitionUpkeep#missingPartition
- mssql://localhost/CONFIG.dbo.EFL_PartitionUpkeep#missingPartition.NULL,fg.[FileGroup_Name],CONCAT('FG_',newP
- mssql://localhost/CONFIG.dbo.EFL_PartitionUpkeep#missingPartition.newP
- mssql://localhost/CONFIG.dbo.EFL_PartitionUpkeep#partitionedTable
- mssql://localhost/CONFIG.dbo.EFL_PartitionUpkeep#solidSnapshot

### mssql://localhost/CONFIG.dbo.EFL_SnapshotPurge (13)

- mssql://localhost/CONFIG.dbo.EFL_SnapshotPurge#currentPartitions
- mssql://localhost/CONFIG.dbo.EFL_SnapshotPurge#currentPartitions.pf
- mssql://localhost/CONFIG.dbo.EFL_SnapshotPurge#existingTablePartitions
- mssql://localhost/CONFIG.dbo.EFL_SnapshotPurge#existingTablePartitions.CONCAT_WS(''.'',QUOTENAME(DB_NAME()),QUOTENAME(sch.name),QUOTENAME(o
- mssql://localhost/CONFIG.dbo.EFL_SnapshotPurge#existingTablePartitions.fg
- mssql://localhost/CONFIG.dbo.EFL_SnapshotPurge#existingTablePartitions.o
- mssql://localhost/CONFIG.dbo.EFL_SnapshotPurge#existingTablePartitions.p
- mssql://localhost/CONFIG.dbo.EFL_SnapshotPurge#purgePartitionMerge
- mssql://localhost/CONFIG.dbo.EFL_SnapshotPurge#purgePartitionMerge.part
- mssql://localhost/CONFIG.dbo.EFL_SnapshotPurge#purgeTableTruncates
- mssql://localhost/CONFIG.dbo.EFL_SnapshotPurge#purgeTableTruncates.tab
- mssql://localhost/CONFIG.dbo.EFL_SnapshotPurge#snapshottedTable
- mssql://localhost/CONFIG.dbo.EFL_SnapshotPurge#solidSnapshotPerCalendar

### mssql://localhost/CONFIG.dbo.MaintainDataCompression (3)

- mssql://localhost/CONFIG.dbo.MaintainDataCompression#DatabaseList
- mssql://localhost/CONFIG.dbo.MaintainDataCompression#ProcessedObjectList
- mssql://localhost/CONFIG.dbo.MaintainDataCompression#TableNamePatternList

### mssql://localhost/CONFIG.dbo.MaintainRawData (1)

- mssql://localhost/CONFIG.dbo.MaintainRawData#ViewsList

### mssql://localhost/EDW_CORE.dbo.EFL_SnapshotPurge (1)

- mssql://localhost/EDW_CORE.dbo.EFL_SnapshotPurge#loopPartition

### mssql://localhost/EDW_CORE.dbo.update_ActiveDirecto_22fadbaa (1)

- mssql://localhost/EDW_CORE.dbo.update_ActiveDirecto_22fadbaa#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ActiveDirecto_satst_ad (1)

- mssql://localhost/EDW_CORE.dbo.update_ActiveDirecto_satst_ad#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ad_src_Active_90ee6799 (1)

- mssql://localhost/EDW_CORE.dbo.update_ad_src_Active_90ee6799#temp

### mssql://localhost/EDW_CORE.dbo.update_Address_Party_Person_s (1)

- mssql://localhost/EDW_CORE.dbo.update_Address_Party_Person_s#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ADUser_satst_ad_ADUser (1)

- mssql://localhost/EDW_CORE.dbo.update_ADUser_satst_ad_ADUser#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_Annex12_MSBRG (2)

- mssql://localhost/EDW_CORE.dbo.update_Annex12_MSBRG#ContractBase
- mssql://localhost/EDW_CORE.dbo.update_Annex12_MSBRG#PDMatrix

### mssql://localhost/EDW_CORE.dbo.update_asefa_AccountBalance_BV (1)

- mssql://localhost/EDW_CORE.dbo.update_asefa_AccountBalance_BV#AccountBalance_asefa_TBH_temp

### mssql://localhost/EDW_CORE.dbo.update_asefa_cdc_src_d7f553fe (1)

- mssql://localhost/EDW_CORE.dbo.update_asefa_cdc_src_d7f553fe#temp

### mssql://localhost/EDW_CORE.dbo.update_asefa_src_Acc_e708035e (1)

- mssql://localhost/EDW_CORE.dbo.update_asefa_src_Acc_e708035e#temp

### mssql://localhost/EDW_CORE.dbo.update_asefa_toip10pf_src_ADh (1)

- mssql://localhost/EDW_CORE.dbo.update_asefa_toip10pf_src_ADh#temp

### mssql://localhost/EDW_CORE.dbo.update_asefl_AccountBalance_BV (1)

- mssql://localhost/EDW_CORE.dbo.update_asefl_AccountBalance_BV#AccountBalance_asefl_TBH_temp

### mssql://localhost/EDW_CORE.dbo.update_asefl_cdc_src_a31954e9 (1)

- mssql://localhost/EDW_CORE.dbo.update_asefl_cdc_src_a31954e9#temp

### mssql://localhost/EDW_CORE.dbo.update_asefl_src_Acc_642561c9 (1)

- mssql://localhost/EDW_CORE.dbo.update_asefl_src_Acc_642561c9#temp

### mssql://localhost/EDW_CORE.dbo.update_asefl_toip10pf_src_ADh (1)

- mssql://localhost/EDW_CORE.dbo.update_asefl_toip10pf_src_ADh#temp

### mssql://localhost/EDW_CORE.dbo.update_asefl_TrialBalance_BV (3)

- mssql://localhost/EDW_CORE.dbo.update_asefl_TrialBalance_BV#MaxLoadDate
- mssql://localhost/EDW_CORE.dbo.update_asefl_TrialBalance_BV#MinAccountingPeriod
- mssql://localhost/EDW_CORE.dbo.update_asefl_TrialBalance_BV#insert_update_temp_asefl

### mssql://localhost/EDW_CORE.dbo.update_AssetGroupDic_d818d0d9 (1)

- mssql://localhost/EDW_CORE.dbo.update_AssetGroupDic_d818d0d9#stage_AssetGroupDictionary_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_AssetOldTypeD_90039f5b (1)

- mssql://localhost/EDW_CORE.dbo.update_AssetOldTypeD_90039f5b#stage_AssetOldTypeDictionary_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_AssetSectorDi_f6935aa9 (1)

- mssql://localhost/EDW_CORE.dbo.update_AssetSectorDi_f6935aa9#stage_AssetSectorTypelDictionary_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_AssetState_sa_39ed433e (1)

- mssql://localhost/EDW_CORE.dbo.update_AssetState_sa_39ed433e#stage_AssetState_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_AssetToBudget_dedd54b3 (1)

- mssql://localhost/EDW_CORE.dbo.update_AssetToBudget_dedd54b3#stage_AssetToBudgetClassification_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_BankruptcyAnd_d1ce4652 (1)

- mssql://localhost/EDW_CORE.dbo.update_BankruptcyAnd_d1ce4652#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_BrandDictiona_189d308a (1)

- mssql://localhost/EDW_CORE.dbo.update_BrandDictiona_189d308a#stage_BrandDictionary_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_C_CBRCoF_satma_S_mis (8)

- mssql://localhost/EDW_CORE.dbo.update_C_CBRCoF_satma_S_mis#BaseRate
- mssql://localhost/EDW_CORE.dbo.update_C_CBRCoF_satma_S_mis#CBRCoFCurrent
- mssql://localhost/EDW_CORE.dbo.update_C_CBRCoF_satma_S_mis#CBRCoFCurrent_BR_NM
- mssql://localhost/EDW_CORE.dbo.update_C_CBRCoF_satma_S_mis#CBRCoFHistory
- mssql://localhost/EDW_CORE.dbo.update_C_CBRCoF_satma_S_mis#CBRCoFHistory_BR
- mssql://localhost/EDW_CORE.dbo.update_C_CBRCoF_satma_S_mis#CBRCoFHistory_BR_NM
- mssql://localhost/EDW_CORE.dbo.update_C_CBRCoF_satma_S_mis#CBRCoFHistory_BR_NM_with_GAPS
- mssql://localhost/EDW_CORE.dbo.update_C_CBRCoF_satma_S_mis#NominalMargin

### mssql://localhost/EDW_CORE.dbo.update_camino_src_ActiveDirec (1)

- mssql://localhost/EDW_CORE.dbo.update_camino_src_ActiveDirec#temp

### mssql://localhost/EDW_CORE.dbo.update_CapitalGroupM_33391747 (1)

- mssql://localhost/EDW_CORE.dbo.update_CapitalGroupM_33391747#stage_ContractApplicationRestructuringType_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_CaseStatus_sa_4dcc7d7f (2)

- mssql://localhost/EDW_CORE.dbo.update_CaseStatus_sa_4dcc7d7f#stage_ChargingPlace_sat_ms_mis_TEMP
- mssql://localhost/EDW_CORE.dbo.update_CaseStatus_sa_4dcc7d7f#stage_ChargingProfile_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_ClientFaultMe_25b105df (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientFaultMe_25b105df#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_116230ba (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_116230ba#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_1b9110fc (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_1b9110fc#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_41914c89 (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_41914c89#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_47dbe3b0 (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_47dbe3b0#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_61162491 (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_61162491#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_6f14a42b (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_6f14a42b#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_83e80cb0 (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_83e80cb0#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_887331c9 (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_887331c9#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_951e5dfa (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_951e5dfa#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_98a53ebb (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_98a53ebb#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_9e1459c0 (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_9e1459c0#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring__dfc24fe (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring__dfc24fe#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_a01118c6 (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_a01118c6#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_a6714067 (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_a6714067#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_ae47bff9 (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_ae47bff9#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_b1f94ff0 (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_b1f94ff0#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_c4bd2c7f (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_c4bd2c7f#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ClientScoring_d8d7d68a (1)

- mssql://localhost/EDW_CORE.dbo.update_ClientScoring_d8d7d68a#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_Con_ParCust_sate_asefl (1)

- mssql://localhost/EDW_CORE.dbo.update_Con_ParCust_sate_asefl#tmp_stage_asefl_PartyCustomer_Contract_lnk

### mssql://localhost/EDW_CORE.dbo.update_Con_ParSupl_sate_asefl (1)

- mssql://localhost/EDW_CORE.dbo.update_Con_ParSupl_sate_asefl#tmp_stage_asefl_PartySupplier_Contract_lnk

### mssql://localhost/EDW_CORE.dbo.update_Cont_ParCust_sate_efa (1)

- mssql://localhost/EDW_CORE.dbo.update_Cont_ParCust_sate_efa#tmp_stage_asefa_PartyCustomer_Contract_lnk

### mssql://localhost/EDW_CORE.dbo.update_Cont_ParSupl_sate_efa (1)

- mssql://localhost/EDW_CORE.dbo.update_Cont_ParSupl_sate_efa#tmp_stage_asefa_PartySupplier_Contract_lnk

### mssql://localhost/EDW_CORE.dbo.update_Contract_CFP_MS_sat (1)

- mssql://localhost/EDW_CORE.dbo.update_Contract_CFP_MS_sat#HWM

### mssql://localhost/EDW_CORE.dbo.update_Contract_CRA_sate (1)

- mssql://localhost/EDW_CORE.dbo.update_Contract_CRA_sate#tmp_stage_mis_Contract_CommissionRegisterAgreement_lnk

### mssql://localhost/EDW_CORE.dbo.update_Contract_IN_PIT (4)

- mssql://localhost/EDW_CORE.dbo.update_Contract_IN_PIT#C_BI_sate_asefa_current
- mssql://localhost/EDW_CORE.dbo.update_Contract_IN_PIT#C_BI_sate_asefl_current
- mssql://localhost/EDW_CORE.dbo.update_Contract_IN_PIT#C_PIT_MAXIN
- mssql://localhost/EDW_CORE.dbo.update_Contract_IN_PIT#pit

### mssql://localhost/EDW_CORE.dbo.update_Contract_PIT_SEC (1)

- mssql://localhost/EDW_CORE.dbo.update_Contract_PIT_SEC#05_ContractScheduleDates

### mssql://localhost/EDW_CORE.dbo.update_Contract_satst_ps_e_di (1)

- mssql://localhost/EDW_CORE.dbo.update_Contract_satst_ps_e_di#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ContractAnnexScheduleD (1)

- mssql://localhost/EDW_CORE.dbo.update_ContractAnnexScheduleD#stage_ContractAnnexType_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_ContractStartType_sat_ms_mis (1)

- mssql://localhost/EDW_CORE.dbo.update_ContractStartType_sat_ms_mis#stage_ContractStartType_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_ContractStatu_fb4b6998 (1)

- mssql://localhost/EDW_CORE.dbo.update_ContractStatu_fb4b6998#stage_ContractStatus_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_CostCenter_sat_S_mis (1)

- mssql://localhost/EDW_CORE.dbo.update_CostCenter_sat_S_mis#stage_CostCenter_sat_S_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_Country_ref_b6c2c4a (1)

- mssql://localhost/EDW_CORE.dbo.update_Country_ref_b6c2c4a#stage_Country_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_CRMIssue_Offer_sate_mi (1)

- mssql://localhost/EDW_CORE.dbo.update_CRMIssue_Offer_sate_mi#tmp_stage_mis_CRMIssue_Offer_lnk

### mssql://localhost/EDW_CORE.dbo.update_CRMIssue_Party_sate_mi (1)

- mssql://localhost/EDW_CORE.dbo.update_CRMIssue_Party_sate_mi#tmp_stage_mis_CRMIssue_Party_lnk

### mssql://localhost/EDW_CORE.dbo.update_CurrencyRate__d7804f2c (2)

- mssql://localhost/EDW_CORE.dbo.update_CurrencyRate__d7804f2c#stage_CurrencyRate_sat_ms_mis_TEMP
- mssql://localhost/EDW_CORE.dbo.update_CurrencyRate__d7804f2c#stage_CustomerClassification_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_DecisionAddit_e6f882b1 (3)

- mssql://localhost/EDW_CORE.dbo.update_DecisionAddit_e6f882b1#StageSourceData
- mssql://localhost/EDW_CORE.dbo.update_DecisionAddit_e6f882b1#stage_DeemedCollectionFlag_sat_ms_mis_TEMP
- mssql://localhost/EDW_CORE.dbo.update_DecisionAddit_e6f882b1#stage_DefaultRepurchasedContract_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_Document_Contract_sate (1)

- mssql://localhost/EDW_CORE.dbo.update_Document_Contract_sate#tmp_stage_mis_Document_Contract_lnk

### mssql://localhost/EDW_CORE.dbo.update_EFLMapping_sa_226722e0 (1)

- mssql://localhost/EDW_CORE.dbo.update_EFLMapping_sa_226722e0#stage_EligibilityCriteriaConfiguration_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_EngineTypeDictionary_sat_ms_mis (1)

- mssql://localhost/EDW_CORE.dbo.update_EngineTypeDictionary_sat_ms_mis#stage_EngineTypeDictionary_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_FactSecCashDeemedColle (3)

- mssql://localhost/EDW_CORE.dbo.update_FactSecCashDeemedColle#BaseDeemedCollectionFlagValues
- mssql://localhost/EDW_CORE.dbo.update_FactSecCashDeemedColle#ContractAnnex
- mssql://localhost/EDW_CORE.dbo.update_FactSecCashDeemedColle#ContractAnnexScheduleDetail

### mssql://localhost/EDW_CORE.dbo.update_FactSecSRPortfolioColl (2)

- mssql://localhost/EDW_CORE.dbo.update_FactSecSRPortfolioColl#SecuritisationSettlementAttachment_MSBV
- mssql://localhost/EDW_CORE.dbo.update_FactSecSRPortfolioColl#SecuritisationSettlement_MSBV

### mssql://localhost/EDW_CORE.dbo.update_FactSecSRPortfolioOuts (1)

- mssql://localhost/EDW_CORE.dbo.update_FactSecSRPortfolioOuts#SecuritisationBaseSchedule_BV_tmp

### mssql://localhost/EDW_CORE.dbo.update_FactSecSRPortfolioPerf (2)

- mssql://localhost/EDW_CORE.dbo.update_FactSecSRPortfolioPerf#SecuritisationSettlementAttachment_MSBV
- mssql://localhost/EDW_CORE.dbo.update_FactSecSRPortfolioPerf#SecuritisationSettlement_MSBV

### mssql://localhost/EDW_CORE.dbo.update_FactSecSRReplenishment (1)

- mssql://localhost/EDW_CORE.dbo.update_FactSecSRReplenishment#BaseData

### mssql://localhost/EDW_CORE.dbo.update_FinancialInit_f63ccca9 (1)

- mssql://localhost/EDW_CORE.dbo.update_FinancialInit_f63ccca9#stage_FinancialInitiative_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_FraudScoring__e3999236 (1)

- mssql://localhost/EDW_CORE.dbo.update_FraudScoring__e3999236#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_FuelKind_sat__5d497ca7 (1)

- mssql://localhost/EDW_CORE.dbo.update_FuelKind_sat__5d497ca7#stage_FuelKind_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_FuelKindMappi_a1d00cb8 (2)

- mssql://localhost/EDW_CORE.dbo.update_FuelKindMappi_a1d00cb8#stage_FuelKindTags_sat_ms_mis_TEMP
- mssql://localhost/EDW_CORE.dbo.update_FuelKindMappi_a1d00cb8#stage_FuelUnit_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_IncomingInvoice_sat_S_ (1)

- mssql://localhost/EDW_CORE.dbo.update_IncomingInvoice_sat_S_#stage_IndividualRestructuring_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_InsuranceClas_f8948613 (1)

- mssql://localhost/EDW_CORE.dbo.update_InsuranceClas_f8948613#stage_InsuranceClassificationDictionary_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_InsurancePolicy_MSPIT (3)

- mssql://localhost/EDW_CORE.dbo.update_InsurancePolicy_MSPIT#stage_InsurancePolicyKind_sat_ms_mis_TEMP
- mssql://localhost/EDW_CORE.dbo.update_InsurancePolicy_MSPIT#stage_InsurancePolicyStatus_sat_ms_mis_TEMP
- mssql://localhost/EDW_CORE.dbo.update_InsurancePolicy_MSPIT#stage_InsurancePolicyType_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_InterestRateT_af66db78 (1)

- mssql://localhost/EDW_CORE.dbo.update_InterestRateT_af66db78#stage_InterestRateType_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_Lead_ActiveDi_bfcb2e6f (1)

- mssql://localhost/EDW_CORE.dbo.update_Lead_ActiveDi_bfcb2e6f#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_Lead_satmast_camino_le (1)

- mssql://localhost/EDW_CORE.dbo.update_Lead_satmast_camino_le#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_Lead_satst_CA_8c48303a (1)

- mssql://localhost/EDW_CORE.dbo.update_Lead_satst_CA_8c48303a#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_Lead_satst_CA_a6aa59e5 (1)

- mssql://localhost/EDW_CORE.dbo.update_Lead_satst_CA_a6aa59e5#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_Lead_satst_camino_lead (1)

- mssql://localhost/EDW_CORE.dbo.update_Lead_satst_camino_lead#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_Lead_satst_mis (1)

- mssql://localhost/EDW_CORE.dbo.update_Lead_satst_mis#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_LeadCampaign__b3d4f29e (1)

- mssql://localhost/EDW_CORE.dbo.update_LeadCampaign__b3d4f29e#stage_LeadCampaign_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_LeadCreditDat_a29f3e9f (1)

- mssql://localhost/EDW_CORE.dbo.update_LeadCreditDat_a29f3e9f#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_LeadJournalSt_285e8a41 (1)

- mssql://localhost/EDW_CORE.dbo.update_LeadJournalSt_285e8a41#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_LeadPartner_s_548f607a (1)

- mssql://localhost/EDW_CORE.dbo.update_LeadPartner_s_548f607a#stage_LeadPartner_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_LeadStatus_sa_51cd43f1 (1)

- mssql://localhost/EDW_CORE.dbo.update_LeadStatus_sa_51cd43f1#stage_LeadStatus_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_lfo_src_Activ_40d3649b (1)

- mssql://localhost/EDW_CORE.dbo.update_lfo_src_Activ_40d3649b#temp

### mssql://localhost/EDW_CORE.dbo.update_LiabilityNipP_dc2798d1 (1)

- mssql://localhost/EDW_CORE.dbo.update_LiabilityNipP_dc2798d1#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_LiabilityPese_71c48c41 (1)

- mssql://localhost/EDW_CORE.dbo.update_LiabilityPese_71c48c41#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_LiabilityPesR_2d993e7b (1)

- mssql://localhost/EDW_CORE.dbo.update_LiabilityPesR_2d993e7b#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_LiabilityReq__f639e31a (1)

- mssql://localhost/EDW_CORE.dbo.update_LiabilityReq__f639e31a#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_MainProductTy_fee74d04 (1)

- mssql://localhost/EDW_CORE.dbo.update_MainProductTy_fee74d04#stage_MainProductType_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_MarketingProd_9c0d9f0e (1)

- mssql://localhost/EDW_CORE.dbo.update_MarketingProd_9c0d9f0e#stage_MarketingProductPromotion_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_MiddleNameMis_a89856aa (1)

- mssql://localhost/EDW_CORE.dbo.update_MiddleNameMis_a89856aa#stage_MiddleNameMissingType_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_ModelDictiona_6b78f92c (1)

- mssql://localhost/EDW_CORE.dbo.update_ModelDictiona_6b78f92c#stage_ModelDictionary_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_MOSTDataForReplenishPr (2)

- mssql://localhost/EDW_CORE.dbo.update_MOSTDataForReplenishPr#MOSTDataForReplenishProcess0
- mssql://localhost/EDW_CORE.dbo.update_MOSTDataForReplenishPr#stage_NCRCollection_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_OBT_Annex8_MSBRG (8)

- mssql://localhost/EDW_CORE.dbo.update_OBT_Annex8_MSBRG#Annex8template_pivoted
- mssql://localhost/EDW_CORE.dbo.update_OBT_Annex8_MSBRG#ContractPaidInstallments
- mssql://localhost/EDW_CORE.dbo.update_OBT_Annex8_MSBRG#Contract_OriginalObligor_PoolAdditionDate
- mssql://localhost/EDW_CORE.dbo.update_OBT_Annex8_MSBRG#DateLastInArrears
- mssql://localhost/EDW_CORE.dbo.update_OBT_Annex8_MSBRG#PortfolioCollection
- mssql://localhost/EDW_CORE.dbo.update_OBT_Annex8_MSBRG#PortfolioOutstanding
- mssql://localhost/EDW_CORE.dbo.update_OBT_Annex8_MSBRG#SecuritisationBaseSchedule_PaymentDue
- mssql://localhost/EDW_CORE.dbo.update_OBT_Annex8_MSBRG#SnapshotContrlTable

### mssql://localhost/EDW_CORE.dbo.update_Offer_BRG (1)

- mssql://localhost/EDW_CORE.dbo.update_Offer_BRG#LinkOfferContract_MSBV

### mssql://localhost/EDW_CORE.dbo.update_Offer_OfferFinancialPa (3)

- mssql://localhost/EDW_CORE.dbo.update_Offer_OfferFinancialPa#BaseRates
- mssql://localhost/EDW_CORE.dbo.update_Offer_OfferFinancialPa#OFP_initialview
- mssql://localhost/EDW_CORE.dbo.update_Offer_OfferFinancialPa#stage_mis_Offer_OfferFinancialParameters_step30

### mssql://localhost/EDW_CORE.dbo.update_Offer_OfferVerificatio (1)

- mssql://localhost/EDW_CORE.dbo.update_Offer_OfferVerificatio#stage1

### mssql://localhost/EDW_CORE.dbo.update_Offer_Party_efs (1)

- mssql://localhost/EDW_CORE.dbo.update_Offer_Party_efs#tmp_stage_lfo_PartyCustomer_Offer_lnk

### mssql://localhost/EDW_CORE.dbo.update_Offer_PartySup_sate_ps (1)

- mssql://localhost/EDW_CORE.dbo.update_Offer_PartySup_sate_ps#tmp_stage_ps_PartySupplier_Offer_lnk

### mssql://localhost/EDW_CORE.dbo.update_Offer_PartySupplier_sa (1)

- mssql://localhost/EDW_CORE.dbo.update_Offer_PartySupplier_sa#tmp_stage_lfo_PartySupplier_Offer_lnk

### mssql://localhost/EDW_CORE.dbo.update_Offer_sat_S_mis_CaseCa (1)

- mssql://localhost/EDW_CORE.dbo.update_Offer_sat_S_mis_CaseCa#Offer_sat_S_mis_CaseCalculation_TEMP

### mssql://localhost/EDW_CORE.dbo.update_OfferContractPhSt_sat_ (1)

- mssql://localhost/EDW_CORE.dbo.update_OfferContractPhSt_sat_#stage_OfferContractStatus_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_OfferStatus_s_9d2d556b (1)

- mssql://localhost/EDW_CORE.dbo.update_OfferStatus_s_9d2d556b#stage_OfferStatus_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_OpportunityCl_ba4de03a (1)

- mssql://localhost/EDW_CORE.dbo.update_OpportunityCl_ba4de03a#stage_OpportunityClosingReason_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_Party_sat_mis_Customer (6)

- mssql://localhost/EDW_CORE.dbo.update_Party_sat_mis_Customer#MaxLoadDate
- mssql://localhost/EDW_CORE.dbo.update_Party_sat_mis_Customer#RP
- mssql://localhost/EDW_CORE.dbo.update_Party_sat_mis_Customer#Segment0
- mssql://localhost/EDW_CORE.dbo.update_Party_sat_mis_Customer#Segment3
- mssql://localhost/EDW_CORE.dbo.update_Party_sat_mis_Customer#Turnover
- mssql://localhost/EDW_CORE.dbo.update_Party_sat_mis_Customer#minparty

### mssql://localhost/EDW_CORE.dbo.update_PartyRolePara_d2b97801 (2)

- mssql://localhost/EDW_CORE.dbo.update_PartyRolePara_d2b97801#stage_PartyRoleParameterListValue_sat_ms_mis_TEMP
- mssql://localhost/EDW_CORE.dbo.update_PartyRolePara_d2b97801#stage_PartyRoleParameter_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_PartyRoleParamVal_sate (1)

- mssql://localhost/EDW_CORE.dbo.update_PartyRoleParamVal_sate#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_PartySegmentT_6420241d (1)

- mssql://localhost/EDW_CORE.dbo.update_PartySegmentT_6420241d#stage_PartySegmentTypeValue_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_PartyStatement_f738275 (1)

- mssql://localhost/EDW_CORE.dbo.update_PartyStatement_f738275#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_Person_sat_PII__8e7df6 (1)

- mssql://localhost/EDW_CORE.dbo.update_Person_sat_PII__8e7df6#stage_FuelKind_sat_s_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_Person_sat_s__52737185 (1)

- mssql://localhost/EDW_CORE.dbo.update_Person_sat_s__52737185#loopPartition

### mssql://localhost/EDW_CORE.dbo.update_Person_satst__cc1aadd2 (1)

- mssql://localhost/EDW_CORE.dbo.update_Person_satst__cc1aadd2#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_Person_satst__cc1e6b11 (1)

- mssql://localhost/EDW_CORE.dbo.update_Person_satst__cc1e6b11#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_Person_satst__cc1ed7ee (1)

- mssql://localhost/EDW_CORE.dbo.update_Person_satst__cc1ed7ee#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_PLED26BPF_sat_f0e7add6 (1)

- mssql://localhost/EDW_CORE.dbo.update_PLED26BPF_sat_f0e7add6#stage_PowerFromRenewableSources_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_PrivatePartne_234a3ab6 (1)

- mssql://localhost/EDW_CORE.dbo.update_PrivatePartne_234a3ab6#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_ps_psoprdefn_src_Activ (1)

- mssql://localhost/EDW_CORE.dbo.update_ps_psoprdefn_src_Activ#temp

### mssql://localhost/EDW_CORE.dbo.update_ps_rd_person_emplid_sr (1)

- mssql://localhost/EDW_CORE.dbo.update_ps_rd_person_emplid_sr#temp

### mssql://localhost/EDW_CORE.dbo.update_ps_rd_person_src_Activ (1)

- mssql://localhost/EDW_CORE.dbo.update_ps_rd_person_src_Activ#temp

### mssql://localhost/EDW_CORE.dbo.update_PublicRegiste_24850d03 (1)

- mssql://localhost/EDW_CORE.dbo.update_PublicRegiste_24850d03#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_PublicRegiste_2c7fd417 (1)

- mssql://localhost/EDW_CORE.dbo.update_PublicRegiste_2c7fd417#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_PublicRegiste_387ef261 (1)

- mssql://localhost/EDW_CORE.dbo.update_PublicRegiste_387ef261#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_PublicRegiste_c00c5fae (1)

- mssql://localhost/EDW_CORE.dbo.update_PublicRegiste_c00c5fae#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_PublicRegiste_e335d7bc (1)

- mssql://localhost/EDW_CORE.dbo.update_PublicRegiste_e335d7bc#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_PublicRegister_be4a259 (1)

- mssql://localhost/EDW_CORE.dbo.update_PublicRegister_be4a259#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_QualifiedSigna_90fc13e (1)

- mssql://localhost/EDW_CORE.dbo.update_QualifiedSigna_90fc13e#stage_QualifiedSignatureInfo_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_ref_data_src__73d7aecc (1)

- mssql://localhost/EDW_CORE.dbo.update_ref_data_src__73d7aecc#temp

### mssql://localhost/EDW_CORE.dbo.update_ReportList_ref (1)

- mssql://localhost/EDW_CORE.dbo.update_ReportList_ref#stage_ReportList_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee38 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee38#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee39 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee39#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee3a (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee3a#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee3b (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee3b#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee3c (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee3c#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee3d (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee3d#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee3e (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee3e#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee3f (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee3f#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee40 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_2548ee40#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_390bcc06 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_390bcc06#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_83d4d8f8 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_83d4d8f8#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_83d4d8f9 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_83d4d8f9#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_83d4d8fa (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_83d4d8fa#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_83d4d8fb (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_83d4d8fb#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_83d4d8fc (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_83d4d8fc#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_83d4d8fd (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_83d4d8fd#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_83d4d8fe (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_83d4d8fe#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_83d4d8ff (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_cs_src_C_83d4d8ff#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_a34d7f6b (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_a34d7f6b#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f73 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f73#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f74 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f74#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f75 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f75#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f76 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f76#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f77 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f77#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f78 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f78#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f79 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f79#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f7a (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f7a#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f7b (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f7b#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f7c (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f7c#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f92 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f92#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f93 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f93#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f94 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f94#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f95 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f95#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f96 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f96#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f97 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f97#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f98 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f98#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f99 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_T_b7802f99#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c5d (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c5d#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c5d_initial (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c5d_initial#source_new

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c5e (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c5e#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c5f (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c5f#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c60 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c60#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c61 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c61#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c62 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c62#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c63 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c63#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c64 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c64#temp

### mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c65 (1)

- mssql://localhost/EDW_CORE.dbo.update_risk_ts_src_Tr_5eb5c65#temp

### mssql://localhost/EDW_CORE.dbo.update_RiskMargin_Tr_8d2a3af1 (1)

- mssql://localhost/EDW_CORE.dbo.update_RiskMargin_Tr_8d2a3af1#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_RiskMargin_Tr_c74890a1 (1)

- mssql://localhost/EDW_CORE.dbo.update_RiskMargin_Tr_c74890a1#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_SanctionList_sate (1)

- mssql://localhost/EDW_CORE.dbo.update_SanctionList_sate#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_SanctionList_sate_mis (1)

- mssql://localhost/EDW_CORE.dbo.update_SanctionList_sate_mis#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_SanctionListT_9370a27a (1)

- mssql://localhost/EDW_CORE.dbo.update_SanctionListT_9370a27a#stage_SanctionListType_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_ScheduleType__f00b062e (1)

- mssql://localhost/EDW_CORE.dbo.update_ScheduleType__f00b062e#stage_ScheduleType_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_ScoringClientData_Part (1)

- mssql://localhost/EDW_CORE.dbo.update_ScoringClientData_Part#tmp_stage_risk_Party_ScoringClientData_lnk

### mssql://localhost/EDW_CORE.dbo.update_SecuContractP_cdefee3c (1)

- mssql://localhost/EDW_CORE.dbo.update_SecuContractP_cdefee3c#stage_SecuritisationNonCompliantReceivableContract_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_Securitisatio_8540857e (1)

- mssql://localhost/EDW_CORE.dbo.update_Securitisatio_8540857e#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_Securitisation_92a3697 (5)

- mssql://localhost/EDW_CORE.dbo.update_Securitisation_92a3697#stage_SecuritisationCollectionPeriod_sat_ms_mis_TEMP
- mssql://localhost/EDW_CORE.dbo.update_Securitisation_92a3697#stage_SecuritisationConfiguration_sat_ms_mis_TEMP
- mssql://localhost/EDW_CORE.dbo.update_Securitisation_92a3697#stage_SecuritisationInflowCategory_sat_ms_mis_TEMP
- mssql://localhost/EDW_CORE.dbo.update_Securitisation_92a3697#stage_SecuritisationReceivableType_sat_ms_mis_TEMP
- mssql://localhost/EDW_CORE.dbo.update_Securitisation_92a3697#stage_SecuritisationStatus_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_SecuritisationUpsize_s (1)

- mssql://localhost/EDW_CORE.dbo.update_SecuritisationUpsize_s#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_SIGReportOUT__e6ba3db3 (1)

- mssql://localhost/EDW_CORE.dbo.update_SIGReportOUT__e6ba3db3#stage_SmallCompanyRestructuring_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_src_AccPeriod_asefa (1)

- mssql://localhost/EDW_CORE.dbo.update_src_AccPeriod_asefa#stage_AccountingPeriod_sat_S_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_src_AccPeriod_asefl (1)

- mssql://localhost/EDW_CORE.dbo.update_src_AccPeriod_asefl#stage_AccountingPeriod_sat_S_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_src_AccPeriod_tetafk (1)

- mssql://localhost/EDW_CORE.dbo.update_src_AccPeriod_tetafk#stage_AccountingPeriod_sat_S_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_10 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_10#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_11 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_11#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_12 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_12#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_13 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_13#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_14 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_14#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_15 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_15#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_16 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_16#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_17 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_17#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_18 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_18#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_19 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_19#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_20 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_20#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_21 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_21#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_22 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_22#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_23 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_23#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_24 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_24#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_25 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_25#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_26 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_26#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_27 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_27#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_28 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_28#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_29 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_29#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_31 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_31#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_32 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_32#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_33 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_33#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_34 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_34#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_35 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_35#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_36 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_36#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_37 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_37#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_38 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_38#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_39 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectory_39#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectoryU_9 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ActiveDirectoryU_9#temp

### mssql://localhost/EDW_CORE.dbo.update_src_ADP_BRG_CFM (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ADP_BRG_CFM#AP

### mssql://localhost/EDW_CORE.dbo.update_src_ADP_BRG_EFL (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ADP_BRG_EFL#AP

### mssql://localhost/EDW_CORE.dbo.update_src_ADP_BRG_EFLF (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ADP_BRG_EFLF#AP

### mssql://localhost/EDW_CORE.dbo.update_src_ADUser_8 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_ADUser_8#temp

### mssql://localhost/EDW_CORE.dbo.update_src_asefl_pled65ub (3)

- mssql://localhost/EDW_CORE.dbo.update_src_asefl_pled65ub#stage_mis_CostCenterAccount_asefa_TEMP
- mssql://localhost/EDW_CORE.dbo.update_src_asefl_pled65ub#stage_mis_CostCenterAccount_asefl_TEMP
- mssql://localhost/EDW_CORE.dbo.update_src_asefl_pled65ub#stage_mis_CostCenterAccount_dc_TEMP

### mssql://localhost/EDW_CORE.dbo.update_src_COA_s_asefl (1)

- mssql://localhost/EDW_CORE.dbo.update_src_COA_s_asefl#stage_ChartOfAccount_sat_s_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_src_COA_s_dc (1)

- mssql://localhost/EDW_CORE.dbo.update_src_COA_s_dc#stage_ChartOfAccount_sat_s_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_src_COA_s_tetafk (1)

- mssql://localhost/EDW_CORE.dbo.update_src_COA_s_tetafk#stage_ChartOfAccount_sat_s_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_src_COA_sat_s_asefa (1)

- mssql://localhost/EDW_CORE.dbo.update_src_COA_sat_s_asefa#stage_ChartOfAccount_sat_s_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_CFM (3)

- mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_CFM#AP
- mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_CFM#CC_lnk
- mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_CFM#MP

### mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_EFL (2)

- mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_EFL#CC_lnk
- mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_EFL#MP

### mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_EFLF (2)

- mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_EFLF#CC_lnk
- mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_EFLF#MP

### mssql://localhost/EDW_CORE.dbo.update_src_DebitAndCredit_A_1 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_DebitAndCredit_A_1#temp

### mssql://localhost/EDW_CORE.dbo.update_src_DebitAndCredit_l_2 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_DebitAndCredit_l_2#temp

### mssql://localhost/EDW_CORE.dbo.update_src_Document_DI_vdesk (1)

- mssql://localhost/EDW_CORE.dbo.update_src_Document_DI_vdesk#current_effectivity

### mssql://localhost/EDW_CORE.dbo.update_src_Offer_AD_sate_lfo (1)

- mssql://localhost/EDW_CORE.dbo.update_src_Offer_AD_sate_lfo#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_src_Offer_AD_sate_ps (1)

- mssql://localhost/EDW_CORE.dbo.update_src_Offer_AD_sate_ps#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_src_SpecialProgram_r_2 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_SpecialProgram_r_2#stage_SpecialProgram_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_src_UserToActiveDire_1 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_UserToActiveDire_1#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_src_UserToActiveDire_2 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_UserToActiveDire_2#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_src_UserToActiveDire_3 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_UserToActiveDire_3#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_src_UserToActiveDire_4 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_UserToActiveDire_4#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_src_UserToADU_sate_5 (1)

- mssql://localhost/EDW_CORE.dbo.update_src_UserToADU_sate_5#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_src_UserToADU_sate_bpm (1)

- mssql://localhost/EDW_CORE.dbo.update_src_UserToADU_sate_bpm#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_src_UserToADU_sate_lfo (1)

- mssql://localhost/EDW_CORE.dbo.update_src_UserToADU_sate_lfo#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_srcLTFCCeffEFAtoip10pf (1)

- mssql://localhost/EDW_CORE.dbo.update_srcLTFCCeffEFAtoip10pf#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_srcLTFCCeffEFLtoip10pf (1)

- mssql://localhost/EDW_CORE.dbo.update_srcLTFCCeffEFLtoip10pf#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_stage_lfo_Offer_Partne (1)

- mssql://localhost/EDW_CORE.dbo.update_stage_lfo_Offer_Partne#temp3

### mssql://localhost/EDW_CORE.dbo.update_stage_mis_CBS_current (3)

- mssql://localhost/EDW_CORE.dbo.update_stage_mis_CBS_current#C_PIT_INCR
- mssql://localhost/EDW_CORE.dbo.update_stage_mis_CBS_current#FilteredContracts
- mssql://localhost/EDW_CORE.dbo.update_stage_mis_CBS_current#MaxLoadDate

### mssql://localhost/EDW_CORE.dbo.update_stage_mis_ContractBase (2)

- mssql://localhost/EDW_CORE.dbo.update_stage_mis_ContractBase#FilteredContracts
- mssql://localhost/EDW_CORE.dbo.update_stage_mis_ContractBase#MaxLoadDate

### mssql://localhost/EDW_CORE.dbo.update_stage_mis_LeadTime (1)

- mssql://localhost/EDW_CORE.dbo.update_stage_mis_LeadTime#ctrl

### mssql://localhost/EDW_CORE.dbo.update_stage_mis_LinkProcessC (2)

- mssql://localhost/EDW_CORE.dbo.update_stage_mis_LinkProcessC#Manual
- mssql://localhost/EDW_CORE.dbo.update_stage_mis_LinkProcessC#System

### mssql://localhost/EDW_CORE.dbo.update_stage_mis_LinkProcessO (2)

- mssql://localhost/EDW_CORE.dbo.update_stage_mis_LinkProcessO#PartialLoading
- mssql://localhost/EDW_CORE.dbo.update_stage_mis_LinkProcessO#xmlparsed

### mssql://localhost/EDW_CORE.dbo.update_stage_mis_Process_tbl (1)

- mssql://localhost/EDW_CORE.dbo.update_stage_mis_Process_tbl#MaxLoadDate

### mssql://localhost/EDW_CORE.dbo.update_stage_mis_ProcessParam (3)

- mssql://localhost/EDW_CORE.dbo.update_stage_mis_ProcessParam#HistoryProcessInstances_ProcessTaxIdentificationNumber
- mssql://localhost/EDW_CORE.dbo.update_stage_mis_ProcessParam#MaxLoadDate
- mssql://localhost/EDW_CORE.dbo.update_stage_mis_ProcessParam#stage_mis_ProcessParameterValue_to_process

### mssql://localhost/EDW_CORE.dbo.update_stage_mis_ProcessTask_ (1)

- mssql://localhost/EDW_CORE.dbo.update_stage_mis_ProcessTask_#MaxLoadDate

### mssql://localhost/EDW_CORE.dbo.update_StatisticalProvision_M (5)

- mssql://localhost/EDW_CORE.dbo.update_StatisticalProvision_M#CA
- mssql://localhost/EDW_CORE.dbo.update_StatisticalProvision_M#CAR
- mssql://localhost/EDW_CORE.dbo.update_StatisticalProvision_M#CASD
- mssql://localhost/EDW_CORE.dbo.update_StatisticalProvision_M#STEP1
- mssql://localhost/EDW_CORE.dbo.update_StatisticalProvision_M#spcp.spcp

### mssql://localhost/EDW_CORE.dbo.update_SubsidyType_s_5ea4fb02 (2)

- mssql://localhost/EDW_CORE.dbo.update_SubsidyType_s_5ea4fb02#stage_TableOfFeesAndCommStandard_sat_ms_mis_TEMP
- mssql://localhost/EDW_CORE.dbo.update_SubsidyType_s_5ea4fb02#stage_TableOfFeesAndComm_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_TableOfFeesAn_202fd126 (2)

- mssql://localhost/EDW_CORE.dbo.update_TableOfFeesAn_202fd126#stage_TableOfFeesAndCommStdType_sat_ms_mis_TEMP
- mssql://localhost/EDW_CORE.dbo.update_TableOfFeesAn_202fd126#stage_TableOfFeesAndCommVersion_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_TableOfFeesAn_2ad0ce62 (1)

- mssql://localhost/EDW_CORE.dbo.update_TableOfFeesAn_2ad0ce62#stage_TableOfFeesAndCommTariffSet_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_TableOfFeesAn_8a630bde (1)

- mssql://localhost/EDW_CORE.dbo.update_TableOfFeesAn_8a630bde#stage_TableOfFeesAndCommComponent_sat_ms_mis_TEMP

### mssql://localhost/EDW_CORE.dbo.update_TaxIdentificationNumbe (4)

- mssql://localhost/EDW_CORE.dbo.update_TaxIdentificationNumbe#PartyBase
- mssql://localhost/EDW_CORE.dbo.update_TaxIdentificationNumbe#PartyRoleTemp
- mssql://localhost/EDW_CORE.dbo.update_TaxIdentificationNumbe#PartyTemp
- mssql://localhost/EDW_CORE.dbo.update_TaxIdentificationNumbe#stage_mis_LinkTaxIdentificationNumberParty_AUX_TEMP

### mssql://localhost/EDW_CORE.dbo.update_tetafk_src_AccountBabv (1)

- mssql://localhost/EDW_CORE.dbo.update_tetafk_src_AccountBabv#AccountBalance_tetafk_TBH_temp

### mssql://localhost/EDW_CORE.dbo.update_TransactionCa_9db77bc9 (1)

- mssql://localhost/EDW_CORE.dbo.update_TransactionCa_9db77bc9#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_TransactionLa_df53b513 (1)

- mssql://localhost/EDW_CORE.dbo.update_TransactionLa_df53b513#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_TransScoring__491f4ffe_initial (1)

- mssql://localhost/EDW_CORE.dbo.update_TransScoring__491f4ffe_initial#Temp

### mssql://localhost/EDW_CORE.dbo.update_TransScoring__64277d35_initial (1)

- mssql://localhost/EDW_CORE.dbo.update_TransScoring__64277d35_initial#Temp

### mssql://localhost/EDW_CORE.dbo.update_TransScoring__8f2d855f (1)

- mssql://localhost/EDW_CORE.dbo.update_TransScoring__8f2d855f#StageSourceData

### mssql://localhost/EDW_CORE.dbo.update_TransScoring__a1de3992_initial (1)

- mssql://localhost/EDW_CORE.dbo.update_TransScoring__a1de3992_initial#Temp

### mssql://localhost/EDW_CORE.dbo.update_TransScoring__ef8a127a_initial (1)

- mssql://localhost/EDW_CORE.dbo.update_TransScoring__ef8a127a_initial#Temp

### mssql://localhost/EDW_CORE.dbo.update_TransScoring_T_71604ad_initial (1)

- mssql://localhost/EDW_CORE.dbo.update_TransScoring_T_71604ad_initial#Temp

### mssql://localhost/EDW_CORE.dbo.update_TrialBalance_tetafk_BV (3)

- mssql://localhost/EDW_CORE.dbo.update_TrialBalance_tetafk_BV#MaxLoadDate
- mssql://localhost/EDW_CORE.dbo.update_TrialBalance_tetafk_BV#MinAccountingPeriod
- mssql://localhost/EDW_CORE.dbo.update_TrialBalance_tetafk_BV#insert_update_temp_tetafk

### mssql://localhost/EDW_CORE.dbo.ZeroKeysUpdate (2)

- mssql://localhost/EDW_CORE.dbo.ZeroKeysUpdate#WS_BASE
- mssql://localhost/EDW_CORE.dbo.ZeroKeysUpdate#WS_BASE.s

### mssql://localhost/EDW_PII.dbo.update_DefaultRestructuringCa (1)

- mssql://localhost/EDW_PII.dbo.update_DefaultRestructuringCa#SnapshotsToProcess

### mssql://localhost/EDW_PII.dbo.update_PartyTaxIdentification (2)

- mssql://localhost/EDW_PII.dbo.update_PartyTaxIdentification#PartyTaxId_lnk_ctrl_temp
- mssql://localhost/EDW_PII.dbo.update_PartyTaxIdentification#SnapshotsToProcess

### mssql://localhost/EDW_PII.dbo.update_PartyTIN_satma_ms_mis (3)

- mssql://localhost/EDW_PII.dbo.update_PartyTIN_satma_ms_mis#Defaults
- mssql://localhost/EDW_PII.dbo.update_PartyTIN_satma_ms_mis#MinPeriods
- mssql://localhost/EDW_PII.dbo.update_PartyTIN_satma_ms_mis#PartiesPeriods

### mssql://localhost/METRICS_CORE.dbo.DataQualityParallel (1)

- mssql://localhost/METRICS_CORE.dbo.DataQualityParallel#ProcessedKPICodes

### mssql://localhost/METRICS_CORE.dbo.DQ_DuplicatesDWHGlobal (1)

- mssql://localhost/METRICS_CORE.dbo.DQ_DuplicatesDWHGlobal#QueryParams

### mssql://localhost/METRICS_CORE.dbo.DQ_DuplicatesDWHGlobalConfig (1)

- mssql://localhost/METRICS_CORE.dbo.DQ_DuplicatesDWHGlobalConfig#QueryParams

### mssql://localhost/METRICS_CORE.dbo.DQ_OrphansDWHGlobal (1)

- mssql://localhost/METRICS_CORE.dbo.DQ_OrphansDWHGlobal#QueryParamsOrph

### mssql://localhost/METRICS_CORE.dbo.DQ_OrphansDWHGlobalConfig (1)

- mssql://localhost/METRICS_CORE.dbo.DQ_OrphansDWHGlobalConfig#QueryParamsOrph

### mssql://localhost/METRICS_CORE.dbo.sp_BlitzFirst (6)

- mssql://localhost/METRICS_CORE.dbo.sp_BlitzFirst#BlitzFirstResults
- mssql://localhost/METRICS_CORE.dbo.sp_BlitzFirst#FilterPlansByDatabase
- mssql://localhost/METRICS_CORE.dbo.sp_BlitzFirst#PerfmonCounters
- mssql://localhost/METRICS_CORE.dbo.sp_BlitzFirst#QueryStats
- mssql://localhost/METRICS_CORE.dbo.sp_BlitzFirst#WaitCategories
- mssql://localhost/METRICS_CORE.dbo.sp_BlitzFirst#WaitCategories.'8

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult (16)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult#CompanyMap
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult#DG_KPI_DC_001
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult#DG_KPI_DC_002
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult#DG_KPI_DC_003
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult#DG_KPI_DC_004
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult#DG_KPI_DC_005
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult#DG_KPI_DC_006
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult#DG_KPI_DC_007
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult#DG_KPI_DC_008
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult#DG_KPI_DR_001_1
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult#DG_KPI_DR_001_2
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult#DG_KPI_DR_001_3
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult#DG_KPI_DR_001_4
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult#DG_KPI_DR_002
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult#LastInsert
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult#aggr

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_anonym_Common (7)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_anonym_Common#KPI_ANONYM_ADDRESS
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_anonym_Common#KPI_ANONYM_ADDRESS_V2
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_anonym_Common#KPI_ANONYM_ADU
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_anonym_Common#KPI_ANONYM_FIRMID
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_anonym_Common#KPI_ANONYM_FIRMID_V2
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_anonym_Common#KPI_ANONYM_PARTY
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_anonym_Common#KPI_ANONYM_PARTY_V2

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_anonym_Sales (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_anonym_Sales#KPI_ANONYM_SAC
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_anonym_Sales#KPI_ANONYM_SAC_V2

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates#CompanyMapDict
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates#KPI_TECH_DUP

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates_ALL (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates_ALL#CompanyMapDict
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates_ALL#KPI_TECH_DUP

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates_Common (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates_Common#CompanyMapDict
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates_Common#KPI_TECH_DUP

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates_Provision (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates_Provision#CompanyMapDict
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates_Provision#KPI_TECH_DUP

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates_Sales (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates_Sales#CompanyMapDict
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates_Sales#KPI_TECH_DUP

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates_Securitisation (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates_Securitisation#CompanyMapDict
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicates_Securitisation#KPI_TECH_DUP

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicatesTabular (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicatesTabular#CompanyMapTabDup
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_duplicatesTabular#KPI_TECH_DUP_TAB

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans#CompanyMapOrph
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans#KPI_TECH_ORPH

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans_ALL (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans_ALL#CompanyMapOrph
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans_ALL#KPI_TECH_ORPH

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans_Common (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans_Common#CompanyMapOrph
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans_Common#KPI_TECH_ORPH

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans_Provision (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans_Provision#CompanyMapOrph
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans_Provision#KPI_TECH_ORPH

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans_Sales (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans_Sales#CompanyMapOrph
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans_Sales#KPI_TECH_ORPH

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans_Securitisation (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans_Securitisation#CompanyMapOrph
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphans_Securitisation#KPI_TECH_ORPH

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphansBridge (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphansBridge#CompanyMapOrphBridge
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_orphansBridge#KPI_TECH_ORPH_BRIDGE

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_Sales (3)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_Sales#CompanyMap
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_Sales#CustomerMetricsKPI
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_Sales#DG_KPI_DM_001

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_technical (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_technical#CompanyMapTech
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_technical#KPI_TECH_BO

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_technical_Common (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_technical_Common#CompanyMapTech
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_technical_Common#KPI_TECH_BO

### mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_technicalBridge (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_technicalBridge#CompanyMapTechBridge
- mssql://localhost/METRICS_CORE.dbo.update_KPIGeneralResult_technicalBridge#KPI_TECH_BRIDGE

### mssql://localhost/METRICS_CORE.dbo.update_KPITenantMap (2)

- mssql://localhost/METRICS_CORE.dbo.update_KPITenantMap#CTE
- mssql://localhost/METRICS_CORE.dbo.update_KPITenantMap#CompanyMap1

### mssql://localhost/METRICS_CORE.dbo.update_Person_sat_PII__8e7df6 (1)

- mssql://localhost/METRICS_CORE.dbo.update_Person_sat_PII__8e7df6#QueryParams

### mssql://localhost/METRICS_CORE.dbo.update_src_KPIGenRes_tech_aud (2)

- mssql://localhost/METRICS_CORE.dbo.update_src_KPIGenRes_tech_aud#CompanyMapTech
- mssql://localhost/METRICS_CORE.dbo.update_src_KPIGenRes_tech_aud#DQ_AUDIT

### mssql://localhost/METRICS_CORE.dbo.update_src_KPIGenRes_techTab (1)

- mssql://localhost/METRICS_CORE.dbo.update_src_KPIGenRes_techTab#DQLastLoadDates
