Pierwsza komenda do wywołania to aktywacja środowiska czyli : ..\infotracker-env\Scripts\activate.ps1
9 testów failuje (pre existing), ważne żeby nie failowało więcej.

## Wykonane (fakty)
- Aktywacja środowiska w PowerShell: ..\infotracker-env\Scripts\activate.ps1
- Przejrzany kod parsera/engine odpowiedzialny za zależności i OL inputs (parser.py, parser_modules/procedures.py, parser_modules/string_fallbacks.py, deps.py, engine.py, lineage.py).
- Debug na przykładzie StoredProcedure.dbo.update_FactSecInsurance_MSBRG.sql:
	- parse_sql_file zwraca obiekt `dbo.FactSecInsurance_MSBRG` z zależnościami:
		EDW_CORE.dbo.InsurancePolicy_MSBV, SnapshotControlTable_EligiblePoolCalendar_BV,
		Contract_MSPIT, InsuranceCompany_MSBV.
	- emit_ol_from_object generuje inputs z ww. tabel.
- Uruchomiono pytest -q: 9 testów FAIL (bez zmiany liczby faili).
- Sprawdzenie column_graph.json (build/output/full_prod_35):
	- FactSecInsurance_MSBRG ma w grafie krawędzie WYCHODZĄCE (jest rodzicem dla FactSecInsurance_MSBV),
		ale brak krawędzi WCHODZĄCYCH do samego FactSecInsurance_MSBRG.
	- Istnieją krawędzie do tymczasowego obiektu update_FactSecInsurance_MSBRG#InsurancePolicy_MSBV (temp).
- Sprawdzone artefakty OL:
	- StoredProcedure.dbo.update_FactSecInsurance_MSBRG.json ma inputs (4 tabele), ale brak facetu columnLineage.
	- Table.dbo.FactSecInsurance_MSBRG.json nie ma inputs ani columnLineage.
- Debug regexa INSERT...SELECT dla update_FactSecInsurance_MSBRG:
	- _extract_insert_select_lineage_string znajduje INSERT, ale parse SELECT pada na CASE i terminator regexa ucina zapytanie na słowie END,
		więc lineage/deps wychodzą puste.
- Ponowne pytest -q: 9 testów FAIL (bez zmiany liczby faili).
- Zmiana w logice: w regexie INSERT...SELECT usunięto END z listy terminatorów (żeby CASE ... END nie ucinało SELECT).
- Dodatkowa poprawka: obcięcie trailing "SELECT @..." w wycinku INSERT...SELECT (żeby nie psuć parsera).
- Weryfikacja po zmianach (lokalny build grafu dla update_FactSecInsurance_MSBRG):
	- obj_lineage_cols=8, in_edges=12 (wcześniej 0).
- pytest -q po zmianach: 9 testów FAIL (bez zmiany liczby faili).
- Wygenerowano nowy zestaw: build/output/full_prod_35_new (infotracker extract --sql-dir build/PROD).
- Porównanie column_graph (full_prod_35 vs full_prod_35_new) dla FactSecInsurance_MSBRG:
	- old_to=10 → new_to=21 (więcej krawędzi WCHODZĄCYCH), old_from=10 → new_from=10 (bez regresji).
- Sprawdzenie nowego artefaktu: StoredProcedure.dbo.update_FactSecInsurance_MSBRG.json ma columnLineage (8 pól).
- Sprawdzenie MSBRG w column_graph.json (build/output/full_prod_35_new):
	- 39 datasetów z „msbrg” w nazwie.
	- 4 bez krawędzi WCHODZĄCYCH (brak rodziców):
		- mssql://localhost/EDW_CORE.dbo.Annex8_MSBRG
		- mssql://localhost/EDW_CORE.dbo.Offer_MSbrg
		- mssql://localhost/EDW_CORE.dbo.tempFactSecCashMeasure_MSBRG
		- mssql://localhost/METRICS_CORE.dbo.EAAttribute_EAAttribute_MSBRG
- Wyszukiwanie procedur w build/PROD powiązanych z:
	- Annex8_MSBRG → StoredProcedure.dbo.update_OBT_Annex8_MSBRG.sql
	- Offer_MSbrg → StoredProcedure.dbo.update_Offer_BRG.sql (zawiera offer_msbrg)
- Analiza braku rodziców dla Annex8_MSBRG:
	- ColumnLineage brak w: StoredProcedure.dbo.update_OBT_Annex8_MSBRG.json i Table.dbo.Annex8_MSBRG.json (inputs=0 / lineage missing).
	- Porównanie column_graph: Annex8_MSBRG old=0 incoming, new=0 incoming (bez zmian po ostatnich poprawkach).
	- SQL procedury jest w UTF-16; po poprawnym odczycie regex znajduje INSERT INTO Annex8_MSBRG.
	- sqlglot parse SELECT w INSERT...SELECT wywraca się na kontrolnym znaku 0x1A w string literal (fReplacePolishCharacters(..., '␦', '')).
	  -> to blokuje columnLineage i przez to brak rodziców w grafie.
- pytest -q: 9 FAIL (bez zmiany liczby faili).
- Poprawki pod Annex8_MSBRG:
	- _normalize_tsql usuwa znak 0x1A.
	- regex INSERT...SELECT nie ucina na ';' wewnątrz string literal (zaostrzone warunki terminatora).
- Rebuild: build/output/full_prod_35_new2.
	- Table.dbo.Annex8_MSBRG.json ma columnLineage (110 pól).
	- Column_graph: Annex8_MSBRG incoming 0 → 92 (full_prod_35_new → full_prod_35_new2).
	- Suma krawędzi: 86741 → 86833 (brak regresji liczbowej).
- pytest -q po zmianach: 9 FAIL (bez zmiany liczby faili).
- Sprawdzenie Offer_MSbrg (full_prod_35_new2):
	- Table.dbo.Offer_MSBRG.json: columnLineage present (50 pól), inputs=59.
	- Column_graph incoming dla Offer_MSBRG: 50 (bez zmian vs full_prod_35_new).
- Fix temp FactEligibilityCriteria_TEMP:
	- W fallbacku stringowym rejestrowanie SELECT/INSERT INTO #temp do temp_registry/temp_sources (kanoniczna nazwa: dbo.update_FactSecEligibilityCrit#FactEligibilityCriteria_TEMP).
	- Rebuild: build/output/full_prod_35_new3.
	- column_graph (full_prod_35_new3):
		- dataset mssql://localhost/EDW_CORE.dbo.update_FactSecEligibilityCrit#FactEligibilityCriteria_TEMP ma incoming=55, outgoing=37.
		- dataset mssql://localhost/EDW_CORE.dbo.FactEligibilityCriteria_TEMP nie występuje w grafie (incoming/outgoing=0).
	- W grafie kolumnowym temp ma rodziców pod kanoniczną nazwą.
- pytest -q po zmianach: 10 FAIL (wzrost z 9 do 10; nowe regresje głównie w test_trialbalance_regression oraz test_cte_join_keywords/test_leadtime_regression).
- Start analizy tempów bez rodziców (full_prod_35_new3):
	- Pierwszy przypadek: dbo.update_ADUser_satst_ad_ADUser -> temp #RecordsToInsert (SELECT INTO z CTE NewHK/DisappearedHK).
	- SQL: #RecordsToInsert budowany z #StageSourceData (STG.dbo.stage_ad_ActiveDirectoryUserWithdrawn) i EDW_CORE.dbo.ActiveDirectoryUser_satst_ad_ADUserWithdrawn_current.
	- Parser: parse_sql_file sygnalizuje unsupported syntax CREATE PROCEDURE i fallbackuje do Command; temp_registry zawiera #RecordsToInsert, ale temp_sources i temp_lineage są puste.
	- Efekt: w column_graph temp #RecordsToInsert ma 0 incoming (brak rodziców).
- Zmiana: string_fallbacks._extract_materialized_output_from_procedure_string uzupełnia temp_sources/temp_lineage dla SELECT INTO #temp (best-effort lineage/deps z okna SELECT INTO).
- Dodatkowo: gdy deps z _extract_insert_select_lineage_string są puste, fallback bierze _extract_basic_dependencies i filtruje nazwy CTE (WITH ... AS) + tempdb.
- pytest -q po zmianach: 9 FAIL (test_cte_join_keywords już PASS; pozostałe to leadtime + trialbalance regressions).
- Temp #RecordsToInsert dla dbo.update_ActiveDirecto_22fadbaa:
	- SQL analogiczny do poprzedniego przypadku (SELECT INTO #StageSourceData + WITH NewHK/DisappearedHK -> SELECT INTO #RecordsToInsert).
	- Po aktualnych zmianach parser.temp_sources dla #RecordsToInsert zawiera: STG.dbo.stage_ActiveDirectoryUser_camino_user oraz EDW_CORE.dbo.ActiveDirectoryUser_satst_CAMINO_user_current.
	- Oczekiwany efekt w grafie po rebuildzie: temp #RecordsToInsert będzie miał rodziców.
- Odświeżono listę tempów bez rodziców na podstawie build/output/full_prod_40/column_graph.json:
	- build/output/full_prod_40/temp_tables_no_parents.txt (format: procedure | temp_dataset).
- pytest -q po odświeżeniu listy: 9 FAIL (bez zmiany liczby faili).
- Temp dbo.update_ADUser_satst_ad_ADUser#RecordsToInsert:
	- SELECT INTO #RecordsToInsert z CTE NewHK/DisappearedHK nie dawał temp_lineage (puste lineage mimo deps).
	- Dodano fallback: gdy brak lineage, ale są deps, wyciągany jest select-list z tego samego statementu i budowany jest podstawowy temp_lineage.
	- Weryfikacja przez SqlParser: temp_lineage dla #RecordsToInsert ma kolumny hk_h_ActiveDirectoryUser, DV_record_source, DV_load_date, DV_is_active z deps STG.dbo.stage_ad_ActiveDirectoryUserWithdrawn i EDW_CORE.dbo.ActiveDirectoryUser_satst_ad_ADUserWithdrawn_current.
- pytest -q po zmianach: 8 FAIL (spadek z 9; nadal leadtime + trialbalance regression).
- Odświeżono listę tempów bez rodziców dla full_prod_40 po zmianach:
	- build/output/full_prod_40/temp_tables_no_parents.txt.
	- update_ADUser_satst_ad_ADUser#RecordsToInsert nie występuje w nowej liście.
- Temp dbo.update_ActiveDirectoryUserGMU#TEMP_stage_mis_ActiveDirectoryGroupMemberUserHistory:
	- SELECT INTO temp dawał lineage bez inputów lub tylko do samego temp (brak rodziców w grafie).
	- Zmiana: gdy deps zawierają tylko temp lub lineage bez inputów, wymuszamy _extract_basic_dependencies i budujemy fallback lineage z listy SELECT.
	- Weryfikacja: temp_lineage mapuje kolumny na EDW_CORE.dbo.stage_mis_ActiveDirectoryGroupMemberUserHistory.
	- Rebuild full_prod_40 + refresh listy: temp nie występuje w build/output/full_prod_40/temp_tables_no_parents.txt.
	- pytest -q po zmianach: 8 FAIL (bez regresji vs poprzedni stan).
- Problem: pojawiały się nazwy kolumn z formułami (COALESCE/CASE/VARCHAR) po fallbacku stringowym.
	- Poprawa: split SELECT listy po przecinkach tylko na poziomie top-level i rozpoznanie aliasu tylko na top-level (bez CAST AS ...).
	- Dodatkowo: gdy SELECT list zawiera "kolumna typ" (np. nvarchar(max)), wybieramy nazwę kolumny zamiast typu.
	- Dla projekcji COALESCE bez aliasu używamy nazwy pierwszej kolumny zamiast "coalesce_expr".
	- Dodatkowo filtrujemy błędne nazwy w stylu "'nvarchar(max)')" i inne formułopodobne resztki.
	- Rebuild full_prod_40: skan column_graph.json nie wykazuje już kolumn z nazwami zawierającymi COALESCE/CASE/VARCHAR.
	- pytest -q po zmianach: 8 FAIL (bez regresji vs poprzedni stan).
- Temp edw_core.dbo.#stage_AssetGroupDictionary_sat_ms_mis_TEMP:
	- Źródłowy plik: build/PROD/EDW_CORE/StoredProcedures/StoredProcedure.dbo.update_AssetGroupDictionary_s.sql.
	- Temp jest tworzony przez SELECT INTO #stage_AssetGroupDictionary_sat_ms_mis_TEMP z EDW_CORE.dbo.stage_mis_ms_AssetGroupDictionary.
	- column_graph (full_prod_41) pokazuje krawędzie stage_mis_ms_AssetGroupDictionary -> #stage_AssetGroupDictionary_sat_ms_mis_TEMP, ale brak krawędzi do AssetGroupDictionary_sat_ms_mis.
	- W column_graph wystepuja tez wpisy z obcym prefiksem procedury (update_Person_sat_PII__8e7df6#stage_AssetGroupDictionary_sat_ms_mis_TEMP).
- pytest -q po aktualizacji notatek: 8 FAIL (bez zmiany liczby faili).
- Zmiana w parser_modules/procedures.py: gdy procedura materializuje tylko tempy, ale zawiera MERGE do tabeli trwałej, to preferujemy MERGE target jako output procedury (bez nadpisywania lineage przez insert-select fallback).
- Dodatkowa zmiana w _parse_procedure_body_statements: jesli fallback zwraca tylko temp (lub nic), a w SQL jest MERGE do tabeli trwałej, to promujemy MERGE target jako wynik procedury.
- pytest -q po zmianie w _parse_procedure_body_statements: 8 FAIL (bez zmiany liczby faili).
- Przyczyna bledu MERGE: regex OUTPUT ... INTO lapal OUTPUT z listy parametrow procedury i parowal z INTO z SELECT INTO, przez co target MERGE byl nadpisywany tempem.
- Poprawka: w _extract_merge_lineage_string parsujemy OUTPUT/USING/WHEN tylko w wycinku MERGE (merge_sql).
- Weryfikacja na StoredProcedure.dbo.update_AssetGroupDictionary_s.sql:
	- merge target: dbo.AssetGroupDictionary_sat_ms_mis.
	- parse_sql_file zwraca output: table dbo.AssetGroupDictionary_sat_ms_mis (zamiast temp).
- pytest -q po poprawce MERGE OUTPUT: 8 FAIL (bez zmiany liczby faili).

## Obserwacje
- „Brak rodziców” w viz wynika z braku columnLineage dla FactSecInsurance_MSBRG (graf kolumnowy opiera się na lineage, nie na dependencies).
- Zależności są w inputs procedury, ale nie przekładają się na column_graph (brak krawędzi bez lineage).
- Potencjalny problem może wynikać z tego, że w realnych MSBRG są wzorce SQL niepasujące do regexów
	(np. MERGE/EXEC/dynamic SQL/CTE poza oknem wyszukiwania), albo z braku artefaktów wyjściowych
	w folderze z OL (brak plików dla MSBRG).
- Dla temp #stage_AssetGroupDictionary_sat_ms_mis_TEMP column_graph wskazuje na bledne targetowanie MERGE (krawedzie trafiaja do temp zamiast do tabeli docelowej) i mozliwy problem z zakresowaniem temp (obcy prefiks procedury).

## Plan dalszych kroków (bez zmian w logice)
- Zweryfikować w podobnych MSBRG czy regex w _extract_insert_select_lineage_string ucina SELECT na END (CASE) i przez to brak lineage.
- Przygotować bezpieczną zmianę w regex terminatora (np. nie traktować END jako końca INSERT..SELECT) + testy.
- Zidentyfikować konkretne obiekty MSBRG bez rodziców w istniejących artefaktach OL (który folder, które pliki).
- Sprawdzić, czy dla tych obiektów są w ogóle generowane JSON-y w output (i czy to jest obiekt tabeli czy procedury).
- Uruchomić parser/emit na kilku problematycznych plikach i porównać dependencies vs. inputs w OL.
- Jeśli zależności są puste: sprawdzić wzorzec SQL (MERGE/EXEC/CTE/SELECT INTO) i dopasowanie regexów.
- Dla tempów: sprawdzić, czy SELECT INTO z CTE w procedurach przechodzi przez string fallback i czy powinno budować temp_sources/temp_lineage.
- Sprawdzic, czemu dla MERGE w update_AssetGroupDictionary_s column_graph generuje krawedzie do temp zamiast do AssetGroupDictionary_sat_ms_mis.
- Zweryfikowac zakresowanie temp w temp_registry/temp_sources (obcy prefiks procedury przy #stage_AssetGroupDictionary_sat_ms_mis_TEMP).

## Status problemu
- Problem „MSBRG bez rodziców” częściowo rozwiązany:
	- FactSecInsurance_MSBRG, Annex8_MSBRG, Offer_MSbrg oraz temp FactEligibilityCriteria_TEMP mają rodziców w column_graph.
	- Pozostałe przypadki wymagają identyfikacji i weryfikacji.

## Update 2026-02-28 (weryfikacja listy tempów bez źródeł)
- Potwierdzono wymagany start od aktywacji środowiska w PowerShell: `..\infotracker-env\Scripts\activate.ps1`.
- Zweryfikowano listę z `TabeleTymczasoweBezZrodla.sql` (61 pozycji) względem `build/output/full_prod_41/column_graph.json`.
- Wynik ścisły (dokładna nazwa datasetu `mssql://localhost/<db>.<schema>.<proc>#<temp>`):
	- 0/61 ma krawędzie WCHODZĄCE (incoming) w grafie kolumnowym.
- Wynik pomocniczy (dopasowanie po samym suffixie `#<temp>`):
	- 43/61 występuje w grafie z incoming, ale pod innym prefiksem (inna baza i/lub inna nazwa procedury).
	- 18/61 nie występuje w grafie nawet po suffixie `#<temp>`.
- Wniosek roboczy: lista jest zasadna dla ścisłych nazw datasetów; część przypadków wygląda na problem kanonizacji/scope (prefiks procedury/bazy), a nie brak samego lineage dla nazwy temp.
- `pytest -q` po aktualizacji notatek: 8 FAIL / 158 PASS / 2 SKIP (bez pogorszenia liczby FAIL).

### Co jeszcze można spróbować zrobić (następne kroki)
- Dla 18/61 przypadków „suffix_not_found_anywhere” przeanalizować źródłowe procedury (czy temp faktycznie materializowany i czy parser go rejestruje).
- Dla 43/61 przypadków „foreign prefix” ustalić regułę kanonizacji nazwy temp (jednoznaczny mapping procedura -> `proc#temp`) i miejsce, gdzie jest gubiona (rejestracja temp vs emit grafu).
- Zweryfikować szczególnie przypadki z różnicą DB (`INFOTRACKERDW` vs `EDW_CORE`) i obciętymi prefiksami nazw procedur.
- Problem nie jest oznaczony jako rozwiązany (zgodnie z ustaleniem: decyzja o zamknięciu po potwierdzeniu przez użytkownika).

## Update 2026-03-18 (martwe końce tempów: incoming/outgoing)
- Potwierdzono start pracy od aktywacji środowiska w PowerShell: `..\infotracker-env\Scripts\activate.ps1`.
- Przeanalizowano `build/output/full_prod_41/column_graph.json` pod kątem datasetów temp (`#`).
- Kryteria:
	- „brak źródła” = brak incoming (dataset nigdy nie występuje po stronie `to`),
	- „brak dzieci” = brak outgoing (dataset nigdy nie występuje po stronie `from`).
- Wynik:
	- wszystkie temp datasety: 837,
	- temp bez źródła (incoming=0): 20,
	- temp bez dzieci (outgoing=0): 467,
	- temp bez incoming i bez outgoing jednocześnie: 0.
- Utworzono plik: `problemen.md` (katalog główny projektu) z pełną listą obu kategorii.
- `pytest -q` po wykonaniu zmian raportowych: 8 FAIL / 158 PASS / 2 SKIP (bez pogorszenia liczby FAIL).
- Status problemu: nieoznaczony jako rozwiązany (czeka na Twoje potwierdzenie).

### Co jeszcze można spróbować zrobić (następne kroki)
- Rozbić listę z `problemen.md` per baza/schemat/procedura i policzyć top-k przypadków dla szybszego priorytetyzowania.
- Dla grupy „brak źródła” sprawdzić, czy to początki łańcuchów ETL (akceptowalne) czy brak lineage.
- Dla grupy „brak dzieci” sprawdzić, czy to końcowe outputy (akceptowalne) czy urwane przepływy.

## Update 2026-03-18 (grupowanie tempów wg procedury)
- Wykonano próbę wymaganej komendy startowej: `..\infotracker-env\Scripts\activate.ps1` (zwróciła kod 1 w tym workspace).
- Mimo tego Python był dostępny (`python --version`), więc kontynuowano analizę na aktualnym środowisku VS Code.
- Przebudowano `problemen.md` na podstawie `build/output/full_prod_41/column_graph.json`.
- Obie sekcje („incoming=0” i „outgoing=0”) są teraz pogrupowane wg procedury źródłowej (prefix przed `#`).
- Statystyka grupowania:
	- incoming=0: 20 tempów w 18 procedurach,
	- outgoing=0: 467 tempów w 320 procedurach.


### Co jeszcze można spróbować zrobić (następne kroki)
- Dodać ranking TOP procedur z największą liczbą „martwych” tempów (oddzielnie incoming=0 i outgoing=0).
- Odfiltrować potencjalne śmieci parsera w nazwach temp (np. fragmenty wyrażeń SQL w suffixie po `#`) i pokazać je osobno jako kandydaty do poprawy parsera.

## Update 2026-03-19 (start implementacji)
- Potwierdzono wymagany start od aktywacji środowiska w PowerShell: `..\infotracker-env\Scripts\activate.ps1`.
	- Komenda zakończona sukcesem (prompt przeszedł na `(infotracker-env)`).
- Uruchomiono baseline `pytest -q` przed zmianami w kodzie:
	- wynik: **8 FAIL / 158 PASS / 2 SKIP** (bez pogorszenia względem ostatniego stanu).
- Rozpoczęto fazę implementacji od obszaru „ewidentne błędy parsera/kanonizacji” (minimalne ryzyko):
	- priorytet 1: sanitizacja nazw temp (eliminacja przypadków, gdzie suffix po `#` zawiera fragmenty wyrażeń SQL),
	- priorytet 2: domknięcie bridge dla wzorców `INSERT ... EXEC` oraz `MERGE ... OUTPUT INTO #temp`,
	- priorytet 3: ujednolicenie scope/kanonizacji `proc#temp` (foreign prefix).
- Status problemu: **nieoznaczony jako rozwiązany** (czeka na decyzję użytkownika).

### Co jeszcze można spróbować zrobić (następne kroki)
- Wprowadzić małą, punktową poprawkę regex/sanitizacji nazw temp w fallbacku stringowym i dodać test regresyjny dla „zaśmieconych” suffixów.
- Po każdej zmianie uruchamiać `pytest -q` i utrzymać warunek „nie więcej FAIL niż baseline 8”.
- Po stabilizacji parsera uruchomić `infotracker extract` na tym samym wejściu i porównać metryki w `build/output/full_prod_41/column_graph.json` (incoming=0, outgoing=0, foreign-prefix, malformed suffix).

## Update 2026-03-19 (implementacja: sanitizacja temp name)
- Wdrożono poprawkę defensywną sanitizacji nazw temp w kanonizacji:
	- plik: `src/infotracker/parser_modules/temp_utils.py`
	- zmiana: `_canonical_temp_name` wymusza czyszczenie tokenu temp przez `_extract_temp_name`, co ucina śmieciowe suffixy (np. `.NULL,...`) i zostawia poprawne `#temp`.
- Wdrożono dodatkową sanitizację celu dla `OUTPUT ... INTO`:
	- plik: `src/infotracker/parser_modules/string_fallbacks.py`
	- zmiana: lokalny normalizator `_st()` czyści token temp przez `_extract_temp_name` i mapuje do `dbo.#<temp>`.
- Dodano test regresyjny:
	- plik: `tests/test_procedure_select_into_fallback.py`
	- nowy test `test_temp_name_sanitized_in_canonicalization` zabezpiecza przypadek „zaśmieconej” nazwy temp.
- Weryfikacja po zmianach:
	- `pytest -q tests/test_procedure_select_into_fallback.py` → 2 PASS,
	- `pytest -q` → **8 FAIL / 159 PASS / 2 SKIP** (FAIL bez wzrostu; warunek „nie gorzej” spełniony).
- Status problemu: **nieoznaczony jako rozwiązany** (zgodnie z zasadą: decyzja po potwierdzeniu użytkownika).

### Co jeszcze można spróbować zrobić (następne kroki)
- Kontynuować implementację minimal-risk: domknąć mapowanie źródeł dla `INSERT INTO #temp EXEC ...` oraz przypadków `MERGE ... OUTPUT INTO #temp`.
- Po tej poprawce ponownie uruchomić `pytest -q` i utrzymać baseline FAIL <= 8.
- Następnie wykonać `infotracker extract` i porównać metryki martwych tempów w `column_graph.json` (szczególnie przypadki z `problemen.md`).

## Update 2026-03-19 (implementacja: bridge INSERT EXEC + MERGE OUTPUT)
- Dodano best-effort bridge dla `INSERT INTO #temp EXEC proc` w fallbacku materiałizacji procedury:
	- plik: `src/infotracker/parser_modules/string_fallbacks.py`
	- zmiana: przy rejestracji temp dla `INSERT INTO` parser wykrywa `EXEC`, dopisuje źródło do `temp_sources` i tworzy minimalne `temp_lineage` (`output_col_1 -> proc.*`).
- Rozszerzono sanitizację targetu temp także dla ścieżki `MERGE ... OUTPUT INTO`:
	- plik: `src/infotracker/parser_modules/string_fallbacks.py`
	- zmiana: target z `OUTPUT INTO` przechodzi przez `_extract_temp_name` (odcięcie śmieciowego suffixu po `#`).
- Dodano test regresyjny:
	- plik: `tests/test_insert_exec.py`
	- nowy test `test_insert_exec_populates_temp_sources_for_temp_registry`.
- Weryfikacja po zmianach:
	- `pytest -q tests/test_insert_exec.py tests/test_procedure_select_into_fallback.py` → 6 PASS,
	- `pytest -q` → **8 FAIL / 160 PASS / 2 SKIP** (FAIL bez wzrostu; warunek „nie gorzej” spełniony).
- Status problemu: **nieoznaczony jako rozwiązany** (decyzja po potwierdzeniu użytkownika).

### Co jeszcze można spróbować zrobić (następne kroki)
- Uruchomić `infotracker extract` na tym samym zbiorze i policzyć różnice względem `build/output/full_prod_41/column_graph.json`:
	- liczba tempów z incoming=0,
	- liczba tempów z outgoing=0,
	- liczba przypadków z „foreign prefix”,
	- liczba przypadków z zaśmieconym suffixem po `#`.
- Jeśli metryki pokażą poprawę bez regresji testowej, kontynuować kolejną małą falę (kanonizacja scope `proc#temp` między parser/engine).

## Update 2026-03-19 (implementacja: sanitizacja w _ns_and_name + walidacja na full_prod)
- Dodatkowa poprawka defensywna w kanale mapowania nazw do namespace/name:
	- plik: `src/infotracker/parser_modules/names.py`
	- zmiana: w `_ns_and_name` sanitizacja `temp_part` oraz fallback `clean_temp` przez `_extract_temp_name`, także gdy wejście wygląda na „już kanoniczne”.
- Dodano test regresyjny:
	- plik: `tests/test_procedure_select_into_fallback.py`
	- nowy test `test_ns_and_name_sanitizes_canonical_temp_suffix`.
- Weryfikacja testowa:
	- `pytest -q tests/test_procedure_select_into_fallback.py tests/test_insert_exec.py` → 7 PASS,
	- `pytest -q` → **8 FAIL / 161 PASS / 2 SKIP** (FAIL bez wzrostu; warunek „nie gorzej” spełniony).
- Weryfikacja artefaktowa (rebuild):
	- wykonano `infotracker extract --sql-dir build/PROD --out-dir build/output/full_prod_41_impl1`,
	- wykonano `infotracker extract --sql-dir build/PROD --out-dir build/output/full_prod_41_impl2`.
- Porównanie dataset-level (`full_prod_41` vs `full_prod_41_impl2`, na podstawie `column_graph.json`):
	- tempDatasets: 837 → 838 (delta +1),
	- incoming=0: 20 → 20 (bez zmiany),
	- outgoing=0: 467 → 468 (delta +1),
	- malformed (heurystyka): 5 → 5 (bez zmiany).
- Zidentyfikowany nowy dataset w porównaniu do baseline:
	- `mssql://localhost/CONFIG.dbo.MaintainDataCompression#ExcludedTablesList` (ADDED),
	- brak REMOVED.
- Twarde przypadki nadal obecne (z przecinkami/nawiasami po `#`):
	- `mssql://localhost/CONFIG.dbo.EFL_PartitionUpkeep#missingPartition.NULL,fg.[FileGroup_Name],CONCAT('FG_',newP`
	- `mssql://localhost/CONFIG.dbo.EFL_SnapshotPurge#existingTablePartitions.CONCAT_WS(''.'',QUOTENAME(DB_NAME()),QUOTENAME(sch.name),QUOTENAME(o`
- Status problemu: **nieoznaczony jako rozwiązany** (decyzja po potwierdzeniu użytkownika).

### Co jeszcze można spróbować zrobić (następne kroki)
- Namierzyć dokładną ścieżkę tworzenia powyższych 2 „twardych” nazw (prawdopodobnie etap przed `_extract_temp_name`, np. AST/normalizacja tokenu `INTO`).
- Dodać punktową sanitizację wejścia dokładnie w tym miejscu (bez ruszania szerokich reguł), plus test regresyjny na wzorcu `EFL_PartitionUpkeep`/`EFL_SnapshotPurge`.
- Po poprawce ponowić `pytest -q` oraz porównanie `full_prod_41` vs nowy rebuild.

## Update 2026-03-19 (incoming one-by-one: przypadek #temp2)
- Rozpoczęto naprawę „incoming=0” metodą pojedynczych przypadków (one by one).
- Wybrany pierwszy przypadek:
	- dataset: `mssql://localhost/EDW_CORE.dbo.update_stage_lfo_Offer_Partne#temp2`.
	- źródło SQL: `build/PROD/EDW_CORE/StoredProcedures/StoredProcedure.dbo.update_stage_lfo_Offer_Partne.sql`.
	- obserwacja w SQL: `SELECT * INTO #temp2 FROM STG.dbo.load_lfo_Case_current` + późniejsze użycie `#temp2` w `INSERT`.
- Diagnoza parsera (przed fixem):
	- `temp_sources['#temp2']` było obecne,
	- `temp_lineage['#temp2']` było puste,
	- efekt: w `column_graph` `incoming_count=0`, mimo że temp ma realne źródło.
- Wdrożona poprawka minimal-risk:
	- plik: `src/infotracker/parser_modules/string_fallbacks.py`
	- zmiana: dla `SELECT * INTO #temp FROM <single_source>` fallback buduje minimalne `temp_lineage` gdy parser nie umie wyciągnąć pełnych kolumn;
		dodatkowo pobierany jest bezpośredni `FROM` z bieżącego statementu jako precyzyjny hint źródła.
- Dodany test regresyjny:
	- plik: `tests/test_procedure_select_into_fallback.py`
	- test: `test_select_star_into_temp_builds_minimal_lineage_when_columns_unknown`.
- Weryfikacja testowa:
	- `pytest -q tests/test_procedure_select_into_fallback.py` → 4 PASS,
	- `pytest -q` → **8 FAIL / 162 PASS / 2 SKIP** (FAIL bez wzrostu; warunek „nie gorzej” spełniony).
- Weryfikacja artefaktowa (po rebuild):
	- wykonano: `infotracker extract --sql-dir build/PROD --out-dir build/output/full_prod_41_impl3`.
	- wynik dla wybranego przypadku:
		- `target_incoming_count=1` (było 0),
		- `target_outgoing_count=3` (bez utraty istniejących wyjść),
		- próbka rodzica: `mssql://localhost/STG.dbo.load_lfo_Case_current`.
- Status problemu: **nieoznaczony jako rozwiązany** (decyzja po potwierdzeniu użytkownika).

### Co jeszcze można spróbować zrobić (następne kroki)
- Kontynuować incoming one-by-one: następny przypadek z listy `incoming=0` (np. `update_src_ADP_BRG_CFM#ADP_src` albo `update_src_DAC_BRG_EFL#DAC_src`) i zastosować ten sam schemat: diagnoza → mały fix → test → rebuild.
- Po każdej iteracji trzymać `pytest -q` oraz warunek FAIL <= 8.
- Po 2-3 kolejnych przypadkach zrobić małe podsumowanie trendu metryk incoming/outgoing, żeby wcześnie wykryć skutki uboczne.

## Update 2026-03-19 (incoming one-by-one: przypadek #ADP_src)
- Potwierdzono wymagany start od aktywacji środowiska w PowerShell: `..\infotracker-env\Scripts\activate.ps1`.
- Wybrany kolejny przypadek z listy `incoming=0`:
	- dataset: `mssql://localhost/EDW_CORE.dbo.update_src_ADP_BRG_CFM#ADP_src`.
	- źródło SQL: `build/PROD/EDW_CORE/StoredProcedures/StoredProcedure.dbo.update_src_ADP_BRG_CFM.sql`.
	- obserwacja: temp tworzony przez `SELECT ... INTO #ADP_src` z wieloma kolumnami i podzapytaniem `SELECT` w liście projekcji.
- Diagnoza parsera (przed fixem):
	- `temp_sources['#ADP_src']` było obecne (4 deps),
	- `temp_lineage['#ADP_src']` było puste,
	- przyczyna: fallback dla `SELECT INTO` szukał `SELECT` przez `rfind("select")` i trafiał w `SELECT` z podzapytania tuż przed `INTO`, co psuło wycięcie listy kolumn.
- Wdrożona poprawka minimal-risk:
	- plik: `src/infotracker/parser_modules/string_fallbacks.py`
	- zmiana: w fallbacku `SELECT INTO` zastąpiono `rfind("select")` skanerem top-level (`_find_outer_select`) ignorującym stringi i zagnieżdżenia nawiasów.
- Dodany test regresyjny:
	- plik: `tests/test_procedure_select_into_fallback.py`
	- test: `test_select_into_temp_with_inner_select_before_into_keeps_lineage`.
- Weryfikacja testowa:
	- `pytest -q tests/test_procedure_select_into_fallback.py tests/test_insert_exec.py` → 9 PASS,
	- `pytest -q` → **8 FAIL / 163 PASS / 2 SKIP** (FAIL bez wzrostu; warunek „nie gorzej” spełniony).
- Weryfikacja artefaktowa (po rebuild):
	- wykonano: `infotracker extract --sql-dir build/PROD --out-dir build/output/full_prod_41_impl4`.
	- dataset-level metryki liczone przez mapowanie `edges -> nodes` (`namespace.table`) dla targetu:
		- `target_incoming_count=18` (było 0),
		- `target_outgoing_count=19` (bez utraty istniejących wyjść).
	- porównanie globalne (`full_prod_41` → `full_prod_41_impl4`, dataset-level przez `nodes`):
		- tempDatasets: `831 -> 854`,
		- incoming=0: `27 -> 17`,
		- outgoing=0: `461 -> 484`.
- Status problemu: **nieoznaczony jako rozwiązany** (decyzja po potwierdzeniu użytkownika).

### Co jeszcze można spróbować zrobić (następne kroki)
- Kontynuować incoming one-by-one od `update_src_DAC_BRG_EFL#DAC_src` (ten sam schemat: diagnoza → mały fix → test → rebuild).
- Przy każdej iteracji trzymać `pytest -q` oraz warunek FAIL <= 8.
- Równolegle monitorować, czy poprawy incoming nie zwiększają zbyt mocno liczby `outgoing=0` (żeby wcześnie wykryć skutki uboczne).

## Update 2026-03-19 (incoming one-by-one: przypadek #AP przy update_src_DAC_BRG_EFL)
- Potwierdzono wymagany start od aktywacji środowiska w PowerShell: `..\infotracker-env\Scripts\activate.ps1`.
- Weryfikacja kolejnego przypadku z listy incoming:
	- `mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_EFL#DAC_src` po poprzednich poprawkach ma incoming (`target_in=34` w `full_prod_41_impl4`) — przypadek nie był już martwym końcem.
	- Kolejny realny przypadek nierozwiązany: `mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_EFL#AP`.
- Diagnoza `#AP`:
	- W SQL dla `StoredProcedure.dbo.update_src_DAC_BRG_EFL.sql` występuje tylko zakomentowane `SELECT ... INTO #AP` i zakomentowany `LEFT JOIN #AP`.
	- Parser mimo to rejestrował `#AP` (fałszywy temp), co dawało w grafie `target_in=0`, `target_out=0`.
	- Namierzono konkretne ścieżki kodu powodujące false-positive:
		- `_parse_procedure_string` (lekki skan segmentów na `INTO #...`),
		- `_parse_procedure_body_statements` (prescan tempów na `#\w+`),
		- fallback materializacji ze stringów.
- Wdrożone poprawki minimal-risk (komentarze usuwane przed regex-skanami tempów):
	- `src/infotracker/parser_modules/string_fallbacks.py`
		- `_extract_materialized_output_from_procedure_string`: wejście przełączone na `self._strip_sql_comments(self._normalize_tsql(sql_content))`.
	- `src/infotracker/parser_modules/procedures.py`
		- `_parse_procedure_body_statements`: `body_sql` i `full_sql` czyszczone przez `_strip_sql_comments(...)` na starcie,
		- `preprocessed_body` budowane z wersji po usunięciu komentarzy,
		- `_parse_procedure_string` AST-prescan: `_strip_sql_comments(_preprocess_sql(...))`,
		- `_parse_procedure_string` lekki skan segmentów: `src_text = _strip_sql_comments(sql_content)`.
- Dodane testy regresyjne:
	- `tests/test_procedure_select_into_fallback.py`
		- `test_commented_select_into_temp_is_ignored`,
		- `test_procedure_body_scan_ignores_commented_temp_mentions`,
		- `test_parse_procedure_string_ignores_commented_temp_mentions`.
- Weryfikacja testowa:
	- `pytest -q tests/test_procedure_select_into_fallback.py tests/test_insert_exec.py` → 12 PASS,
	- `pytest -q` → **8 FAIL / 166 PASS / 2 SKIP** (FAIL bez wzrostu; warunek „nie gorzej” spełniony).
- Weryfikacja artefaktowa (rebuild):
	- wykonano: `infotracker extract --sql-dir build/PROD --out-dir build/output/full_prod_41_impl6`.
	- status targetu `mssql://localhost/EDW_CORE.dbo.update_src_DAC_BRG_EFL#AP`:
		- przed (`full_prod_41_impl4`): `present=True`, `in=0`, `out=0`,
		- po (`full_prod_41_impl6`): `present=False` (fałszywy temp usunięty z grafu).
	- globalnie (dataset-level temp, ta sama metoda liczenia co w tej iteracji):
		- incoming=0: `17 -> 15`.
- Kontrola „czy nie psuje obecnego lineage” (Twoje dodatkowe wymaganie):
	- porównanie `column_graph` przed/po tej zmianie (`impl4` -> `impl6`):
		- nodes (obiekty): `112745 -> 112669` (delta `-76`),
		- edges (krawędzie): `99940 -> 99890` (delta `-50`).
	- interpretacja robocza: ubytek dotyczy głównie fałszywych artefaktów temp z komentarzy (a nie utraty prawidłowego przepływu dla `#DAC_src`, który nadal ma incoming).
- Status problemu: **nieoznaczony jako rozwiązany** (decyzja po potwierdzeniu użytkownika).

### Co jeszcze można spróbować zrobić (następne kroki)
- Kontynuować incoming one-by-one od kolejnego realnego przypadku z aktualnej listy (`full_prod_41_impl6`), np. `update_Offer_BRG#Offer_FirstOfferNumber_lnk` albo `update_stage_mis_ProcessParam#stage_mis_ProcessParameterValue`.
- Po każdej iteracji utrzymywać `pytest -q` oraz warunek FAIL <= 8.
- W każdej iteracji raportować dodatkowo `nodes/edges` `column_graph` przed/po (zgodnie z Twoją prośbą), aby wcześnie wykrywać regresję lineage.

## Update 2026-03-19 (incoming one-by-one: fallback CREATE TABLE #temp + INSERT INTO #temp SELECT)
- Potwierdzono walidację testową po ostatniej korekcie testu regresyjnego:
	- `pytest -q tests/test_procedure_select_into_fallback.py tests/test_insert_exec.py` → **13 PASS**.
	- `pytest -q` → **8 FAIL / 167 PASS / 2 SKIP** (bez pogorszenia; baseline FAIL utrzymany).
- Wykonano rebuild po zmianach parsera:
	- komenda (z aktywacją jako pierwszą): `..\infotracker-env\Scripts\activate.ps1; infotracker extract --sql-dir build/PROD --out-dir build/output/full_prod_41_impl7`.
- Kontrola „czy nie psuje obecnego lineage” (Twoje wymaganie: porównanie objects/edges):
	- porównanie `column_graph` (`full_prod_41_impl6` -> `full_prod_41_impl7`):
		- nodes (obiekty): `112669 -> 112669` (delta `0`),
		- edges (krawędzie): `99890 -> 99890` (delta `0`).
- Sprawdzenie targetu iteracji `mssql://localhost/EDW_CORE.dbo.update_src_DebitAndCredit_l_1#temp`:
	- `full_prod_41_impl6`: `present=False`, `in=0`, `out=0`,
	- `full_prod_41_impl7`: `present=False`, `in=0`, `out=0`.
- Wniosek roboczy:
	- zmiana jest neutralna dla globalnego grafu `column_graph` na zbiorze `build/PROD` (brak regresji liczbowej),
	- analizowany przypadek `update_src_DebitAndCredit_l_1#temp` nie materializuje się w tym konkretnym przebiegu `full_prod_41_impl6/impl7` (najpewniej inny scope wejścia/nazewnictwo niż wcześniejszy debug parsera).

### Co jeszcze można spróbować zrobić (następne kroki)
- Wybrać kolejny „twardy” przypadek z aktualnej listy incoming=0 w `full_prod_41_impl7` (najlepiej taki, który **występuje** w `column_graph`) i kontynuować one-by-one.
- Kandydaci o wysokim priorytecie: `update_Offer_BRG#Offer_FirstOfferNumber_lnk` albo `update_stage_mis_ProcessParam#stage_mis_ProcessParameterValue`.
- Utrzymać ten sam rytm: mały fix -> test celowany -> `pytest -q` -> rebuild -> porównanie `nodes/edges` i metryk targetu.

## Update 2026-03-19 (incoming one-by-one: update_stage_mis_ProcessParam#stage_mis_ProcessParameterValue)
- Potwierdzono start od wymaganej aktywacji PowerShell: `..\infotracker-env\Scripts\activate.ps1`.
- Diagnoza przypadku `mssql://localhost/EDW_CORE.dbo.update_stage_mis_ProcessParam#stage_mis_ProcessParameterValue`:
	- parser wykrywał źródła dla tempa, ale dla części ścieżek fallback trzymał zbyt ubogie mapowanie kolumn ("zacięcie" na wcześniejszym partial lineage).
	- SQL zawiera wzorzec `CREATE TABLE #stage_mis_ProcessParameterValue (...)` + `INSERT INTO #stage_mis_ProcessParameterValue SELECT ... FROM EDW_CORE.dbo.stage_mis_ProcessParameterValue`.
- Wdrożone poprawki minimal-risk w `src/infotracker/parser_modules/procedures.py` (fallback procedur):
	- `CREATE TABLE #temp` może teraz **nadpisać** wcześniejszy, uboższy `temp_registry` (gdy nowa definicja ma więcej kolumn),
	- `INSERT INTO #temp SELECT` nie przerywa już całego mapowania przy istniejącym `temp_lineage`; dopisuje brakujące kolumny,
	- gdy `_extract_basic_dependencies` zwróci pusty zbiór, dodany jest fallback deps z tokenów `FROM/JOIN`.
- Dodano test regresyjny:
	- `tests/test_procedure_select_into_fallback.py::test_create_table_upgrades_temp_registry_and_fills_missing_lineage`.
- Walidacja testowa:
	- `pytest -q tests/test_procedure_select_into_fallback.py tests/test_insert_exec.py` → **14 PASS**,
	- `pytest -q` → **8 FAIL / 168 PASS / 2 SKIP** (FAIL bez wzrostu; warunek „nie gorzej” spełniony).
- Weryfikacja artefaktowa:
	- rebuild: `..\infotracker-env\Scripts\activate.ps1; infotracker extract --sql-dir build/PROD --out-dir build/output/full_prod_41_impl8`.
	- porównanie `column_graph` (`impl7` -> `impl8`):
		- nodes: `112669 -> 112669` (delta `0`),
		- edges: `99890 -> 99890` (delta `0`).
	- target dataset-level: `mssql://localhost/EDW_CORE.dbo.update_stage_mis_ProcessParam#stage_mis_ProcessParameterValue`
		- `present=True` w obu wersjach,
		- `in=0`, `out=0` w obu wersjach.
	- artefakt tempa `...hashstage_mis_ProcessParameterValue.json`:
		- `inputs=2` w obu wersjach,
		- `schema_fields=0`, `lineage_fields=0` w obu wersjach (bez poprawy funkcjonalnej dla tego targetu).
- Wniosek roboczy:
	- zmiana jest bezpieczna (brak regresji testowej i brak regresji nodes/edges),
	- ale nie domknęła jeszcze przypadku `#stage_mis_ProcessParameterValue` w finalnym artefakcie OL/column_graph.

### Co jeszcze można spróbować zrobić (następne kroki)
- Kolejny krok one-by-one: przejść na `update_Offer_BRG#Offer_FirstOfferNumber_lnk` i prześledzić dokładnie ścieżkę emitu dla temp artefaktu (dlaczego finalnie `schema/columnLineage` jest puste mimo źródeł).
- Zweryfikować, czy brak `schema/columnLineage` dla tempów wynika z filtra w etapie emitu OpenLineage (nie parsera) — cel: minimalny fix tylko dla temp artifact path.
- Utrzymać rytm: mały fix -> testy celowane -> `pytest -q` -> rebuild -> porównanie `nodes/edges`.

## Update 2026-03-19 (raport: problemen_fixed.md)
- Utworzono nowy plik raportowy: `problemen_fixed.md`.
- Raport wygenerowany na podstawie: `build/output/full_prod_41_impl8/column_graph.json`.
- Wynik metryk w tym przebiegu:
	- temp datasets: 844,
	- incoming=0: 844,
	- outgoing=0: 844,
	- incoming=0 i outgoing=0 jednocześnie: 844.
- Interpretacja robocza: w obecnym formacie/emitcie `column_graph` dla `full_prod_41_impl8` wszystkie tempy wychodzą jako „ucięte” wg metryki dataset-level (to wymaga osobnej analizy semantyki grafu, ale raport został wygenerowany zgodnie z obecnymi danymi).
- Walidacja po zmianie raportowej:
	- `pytest -q` -> **8 FAIL / 168 PASS / 2 SKIP** (bez pogorszenia względem baseline).
- Status problemu: **nieoznaczony jako rozwiązany** (zgodnie z zasadą — decyzja należy do użytkownika).

## Update 2026-03-19 (korekta: problemen_fixed.md liczone po edges)
- Zgłoszono błąd: poprzednia wersja `problemen_fixed.md` była policzona niepoprawnie (zawyżenie do 844/844).
- Naprawa metody liczenia:
	- incoming/outgoing wyliczane wyłącznie z `edges` (faktyczny przepływ),
	- poziom datasetu uzyskiwany przez odcięcie części kolumnowej po ostatniej kropce w endpointach `from`/`to`.
- Po korekcie (źródło: `build/output/full_prod_41_impl8/column_graph.json`):
	- wszystkie temp datasety: `851`,
	- incoming=0: `10`,
	- outgoing=0: `483`,
	- incoming=0 i outgoing=0 jednocześnie: `0`.
- Dodatkowo poprawiono artefakt znakowy w opisie metody w `problemen_fixed.md`.
- Walidacja po korekcie raportu:
	- `pytest -q` -> **8 FAIL / 168 PASS / 2 SKIP** (bez pogorszenia względem baseline).

## Update 2026-03-21 (one-by-one: pierwszy przypadek braku dzieci)
- Potwierdzono wymagany start od aktywacji: `..\infotracker-env\Scripts\activate.ps1`.
- Wzięto pierwszy przypadek z listy outgoing=0:
	- `mssql://localhost/CONFIG.dbo.EFL_GrantAccess#InvalidDatabaseObjects`.
- Weryfikacja SQL źródłowego (`build/PROD/CONFIG/StoredProcedures/StoredProcedure.dbo.EFL_GrantAccess.sql`):
	- temp tworzony przez `SELECT ... INTO #InvalidDatabaseObjects`,
	- następnie użyty tylko do przypisania zmiennych (`SELECT ... FROM #InvalidDatabaseObjects`),
	- brak materializacji kolejnego datasetu z tego tempa.
- Weryfikacja grafu (`build/output/full_prod_41_impl8/column_graph.json`):
	- `in=4`, `out=0`,
	- parent: `mssql://localhost/CONFIG.dbo.EFL_GrantAccess#PrivilegeMetadataToGrant`,
	- children: brak.
- Wniosek roboczy (wysoka pewność):
	- to wygląda na **terminalny bufor walidacyjny**; `outgoing=0` w tym przypadku jest oczekiwane, a nie oczywista usterka parsera.
- Aktualizacja raportu:
	- w `problemen_fixed.md` dopisano sekcję „Weryfikacja one-by-one (status)” oraz adnotację przy `#InvalidDatabaseObjects`.
	- przypadek pozostaje na liście do czasu Twojej decyzji (zgodnie z regułą, nic nie zostało „zamknięte”).

### Co jeszcze można spróbować zrobić (następne kroki)
- Kontynuować one-by-one na kolejnym przypadku z `CONFIG.dbo.EFL_GrantAccess` (`#MissingLogins` / `#MissingUsers`) i sprawdzić, czy też są terminalne.
- Jeśli kolejne 2-3 przypadki potwierdzą ten sam wzorzec, wydzielić w `problemen_fixed.md` podsekcję „terminalne tempy kontrolne”, bez usuwania z listy głównej.

## Update 2026-03-21 (one-by-one: EFL_GrantAccess + pierwszy realny brak dzieci)
- Wymagany start wykonany: `..\infotracker-env\Scripts\activate.ps1` (PowerShell).
- Przeskanowano kolejne pozycje z `problemen_fixed.md` dla `CONFIG.dbo.EFL_GrantAccess`.
- Zweryfikowano SQL + graph:
	- `#InvalidDatabaseObjects` = terminalny bufor do zasilania zmiennych (zaakceptowane usunięcie z listy problemów),
	- `#ServerPrincipals` = używany w `LEFT JOIN` przy budowie `#MissingLogins` (nie jest terminalny) i został potraktowany jako pierwszy realny „brak dzieci”.
- Wdrożono minimal-risk poprawkę parsera:
	- `src/infotracker/parser_modules/dml.py`: dodanie join-only temp dependency do lineage dla `SELECT ... INTO #temp`,
	- `src/infotracker/parser_modules/string_fallbacks.py`: analogiczny fallback join-only temp dependency w ścieżce stringowej `INSERT/SELECT`.
- Dodano test regresyjny:
	- `tests/test_procedure_select_into_fallback.py::test_select_into_temp_keeps_join_only_temp_dependency`.
- Walidacja testów:
	- test celowany: PASS,
	- pełny `pytest -q`: **8 FAIL / 169 PASS / 2 SKIP** (nie gorzej vs baseline 8 FAIL).
- Zaktualizowano `problemen_fixed.md`:
	- usunięto `#InvalidDatabaseObjects` z listy problemów,
	- oznaczono `#ServerPrincipals` jako pierwszy realny przypadek do dalszej walidacji po kolejnym extract.

### Co jeszcze można spróbować zrobić (następny krok)
- Wykonać kolejny pełny `infotracker extract` i potwierdzić, czy `mssql://localhost/CONFIG.dbo.EFL_GrantAccess#ServerPrincipals` dostaje outgoing > 0 w `column_graph.json`.
- Jeśli potwierdzi się poprawa bez regresji, przejść do następnego case one-by-one z listy (`#MissingLogins`, `#MissingUsers`), nadal bez oznaczania problemów jako „resolved” bez Twojej decyzji.

## Update 2026-03-21 (extract check po poprawce JOIN aliasu)
- Wymagany start wykonany: `..\infotracker-env\Scripts\activate.ps1` (PowerShell).
- Wykonano pełne extracty:
	- `infotracker extract --sql-dir build/PROD --out-dir build/output/full_prod_41_impl9`,
	- po poprawce aliasu JOIN także `... --out-dir build/output/full_prod_41_impl10`.
- Porównanie metryk dataset-level (`column_graph.json`) dla `CONFIG.dbo.EFL_GrantAccess`:
	- `#ServerPrincipals`: impl8 `in=1,out=0` → impl9 `in=1,out=0` → impl10 `in=1,out=0` (bez poprawy outgoing),
	- `#MissingLogins`: impl8 `in=2,out=0` → impl9 `in=2,out=0` → impl10 `in=1,out=0`,
	- `#MissingUsers`: impl8 `in=4,out=0` → impl9 `in=5,out=0` → impl10 `in=3,out=0`.
- Zmiany kodu:
	- `src/infotracker/parser_modules/dml.py`: normalizacja aliasów JOIN (`#name`/`name`) przy wykrywaniu join-only temp refs,
	- `src/infotracker/parser_modules/string_fallbacks.py`: analogiczna normalizacja aliasów JOIN.
- Testy:
	- celowany: `pytest -q tests/test_procedure_select_into_fallback.py -k join_only_temp_dependency` → PASS,
	- pełny `pytest -q` po poprawkach: **8 FAIL / 169 PASS / 2 SKIP** (baseline zachowany).
- Wniosek: warunek „ma outgoing” dla `#ServerPrincipals` nadal niespełniony, więc nie przechodzono jeszcze do kolejnego tempa w trybie one-by-one.

## Update 2026-03-21 (EFL_SnapshotPurge: odfiltrowanie zanieczyszczonych wariantów temp)
- Wymagany start wykonany: `..\infotracker-env\Scripts\activate.ps1` (PowerShell).
- Zidentyfikowany problem dla `#existingTablePartitions`: pseudo-warianty datasetu wynikały z kolumn z kropkami/funkcjami (np. `.o`, `.fg`, `CONCAT_WS(...)`) na etapie budowy `column_graph`.
- Zmiana wdrożona punktowo (bez ruszania parsera SELECT):
	- plik: `src/infotracker/models.py` (`ColumnGraph.build_from_object_lineage`),
	- dla tabel temp (`#...`) sanitizacja nazw kolumn tylko na etapie budowy grafu (ucięcie kwalifikatorów aliasu i czyszczenie nazw funkcyjnych), żeby nie tworzyć pseudo-datasetów.
- Walidacja testowa:
	- `pytest -q` → **8 FAIL / 169 PASS / 2 SKIP** (bez pogorszenia baseline).
- Walidacja funkcjonalna na realnym wejściu CONFIG:
	- `infotracker extract --sql-dir build/PROD/CONFIG/StoredProcedures --out-dir build/output/config_temp_norm_check`,
	- sprawdzenie `column_graph.json` dla `existingTablePartitions`:
		- dataset-level variants: tylko `mssql://localhost/CONFIG.dbo.EFL_SnapshotPurge#existingTablePartitions` (zniknęły warianty `.o`, `.fg`, `CONCAT_WS(...)`).
- Status: zmiana wdrożona i zweryfikowana dla tego case’u, ale **bez oznaczania problemu jako rozwiązany** (decyzja pozostaje po Twojej stronie).

## Update 2026-03-21 (EFL_PartitionUpkeep: potwierdzenie cleanupu)
- Wymagany start wykonany: `..\infotracker-env\Scripts\activate.ps1` (PowerShell).
- Weryfikacja na `build/output/config_temp_norm_check/column_graph.json`:
	- `#missingPartition` występuje tylko jako kanoniczny dataset (`mssql://localhost/CONFIG.dbo.EFL_PartitionUpkeep#missingPartition`),
	- brak wariantów z suffixami (`.newP`, `.NULL,...`) oraz brak `#missingFile.fg`.
	- komplet tempów dla `EFL_PartitionUpkeep` = 8 kanonicznych nazw (bez zanieczyszczonych wariantów).
- Zaktualizowano `problemen_fixed.md`:
	- sekcja `EFL_PartitionUpkeep` skorygowana z 10 do 8,
	- sekcja `EFL_SnapshotPurge` skorygowana z 13 do 6,
	- dodana notatka re-check 2026-03-21 ze źródłem `config_temp_norm_check`.
- Status: wpisy skorygowane, ale **bez oznaczania jako resolved** (decyzja po Twojej stronie).

## Update 2026-03-21 (korekta liczb nagłówkowych w problemen_fixed.md)
- Przeliczono metryki bezpośrednio z bieżącej zawartości `problemen_fixed.md` (sekcje incoming/outgoing).
- Zaktualizowano nagłówek raportu:
	- `Wszystkie temp datasety (#): 483` (było 851),
	- `Temp bez źródła (incoming=0): 10` (bez zmian),
	- `Temp bez dzieci (outgoing=0): 473` (było 483),
	- `Temp bez incoming i bez outgoing jednocześnie: 0` (bez zmian).
- Dodano doprecyzowanie, że te liczby odpowiadają bieżącej liście po korektach i wykluczeniach terminalnych zaakceptowanych one-by-one.

## Update 2026-03-21 (one-by-one: EFL_PartitionUpkeep#FileGroupCurrent)
- Wymagany start wykonany: `..\infotracker-env\Scripts\activate.ps1` (PowerShell).
- Sprawdzono SQL procedury `build/PROD/CONFIG/StoredProcedures/StoredProcedure.dbo.EFL_PartitionUpkeep.sql`:
	- `#FileGroupCurrent` jest zasilany przez `INSERT INTO #FileGroupCurrent EXEC sp_MSforeachdb ...`,
	- jest używany w `LEFT JOIN #FileGroupCurrent fg` podczas budowy `#missingPartition` (czyli nie wygląda na terminalny bufor).
- Porównanie dataset-level na `column_graph.json`:
	- `full_prod_41_impl8`: `in=5, out=0`,
	- `full_prod_41_impl10`: `in=0, out=1` (wyjście do `mssql://localhost/CONFIG.dbo.EFL_PartitionUpkeep#missingPartition`),
	- `config_temp_norm_check`: `in=5, out=0`.
- Zaktualizowano `problemen_fixed.md` sekcję „Weryfikacja one-by-one” o ten przypadek.
- Uruchomiono pełny `pytest -q` po zmianach dokumentacyjnych: **8 FAIL / 169 PASS / 2 SKIP** (baseline bez pogorszenia).
- Status:
	- bez usuwania z listy problemów (zgodnie z Twoją zasadą: decyzja o „resolved” należy do Ciebie),
	- przypadek oznaczony jako niespójny między artefaktami (impl8/config_check vs impl10).

### Co jeszcze można spróbować zrobić (następny krok)
- Zweryfikować ten sam przypadek na świeżym extract dla całego `build/PROD` po aktualnym kodzie (jeden artefakt referencyjny), aby wykluczyć wpływ różnicy wsadu.
- Jeśli trend `out=1` się utrzyma, przenieść `#FileGroupCurrent` do sekcji „zweryfikowane/oczekujące decyzji”, ale bez wykreślania z listy głównej do Twojej zgody.

## Update 2026-03-21 (one-by-one: EFL_PartitionUpkeep#LastFileGroup)
- Wymagany start wykonany: `..\infotracker-env\Scripts\activate.ps1` (PowerShell).
- Sprawdzono SQL procedury `build/PROD/CONFIG/StoredProcedures/StoredProcedure.dbo.EFL_PartitionUpkeep.sql`:
	- `#LastFileGroup` jest zasilany przez `INSERT INTO #LastFileGroup EXEC sp_MSforeachdb ...`,
	- jest używany w budowie `#missingFilegroup` (CTE `missingFilegroup` oparty o `FROM #LastFileGroup`), więc nie wygląda na terminalny bufor.
- Porównanie dataset-level na `column_graph.json`:
	- `full_prod_41_impl8`: `in=5, out=0`,
	- `full_prod_41_impl10`: `in=0, out=0`,
	- `config_temp_norm_check`: `in=5, out=0`.
- Dodatkowa obserwacja artefaktowa:
	- `#missingFilegroup` ma incoming ze źródła `mssql://localhost/CONFIG.dbo.missingFilegroup` (bez prefiksu `EFL_PartitionUpkeep#...`), co sugeruje niespójność kanonizacji/mappingu nazw temp.
- Zaktualizowano `problemen_fixed.md` (sekcja „Weryfikacja one-by-one”) o ten przypadek.
- Status:
	- bez usuwania z listy problemów (decyzja o „resolved” należy do Ciebie),
	- przypadek oznaczony jako niespójny między artefaktami i wymagający dalszej analizy kanonizacji.
- Uruchomiono pełny `pytest -q` po zmianach dokumentacyjnych: **8 FAIL / 169 PASS / 2 SKIP** (baseline bez pogorszenia).