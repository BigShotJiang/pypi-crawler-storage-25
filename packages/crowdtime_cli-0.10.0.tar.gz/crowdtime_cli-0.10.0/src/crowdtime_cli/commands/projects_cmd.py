"""Project commands: list, show, create, update, archive, switch, budget, members, tasks."""

from __future__ import annotations

from decimal import Decimal
from typing import List, Optional

import typer
from rich.console import Console
from rich.table import Table

from ..client import APIError, CrowdTimeClient
from ..config import get_config
from ..formatters import extract_results, format_currency, format_error, format_projects_table, format_success, print_json
from ..models import Project
from ..utils import format_duration

app = typer.Typer(name="projects", help="Manage projects.")
console = Console()

BILLING_MODES = ["per_task", "per_person", "custom"]


def _resolve_or_create_client(api_client: CrowdTimeClient, client_name: str) -> str:
    """Look up a client by name; create one if it doesn't exist. Returns the client UUID."""
    # Search for existing clients matching the name
    data = api_client.get("/clients/", params={"search": client_name})
    clients_list = extract_results(data)

    # Exact match (case-insensitive)
    for c in clients_list:
        if c.get("name", "").lower() == client_name.lower():
            return c["id"]

    # No match — auto-create the client
    console.print(f"[dim]Client '{client_name}' not found — creating it...[/dim]")
    new_client = api_client.post("/clients/", data={"name": client_name})
    return new_client["id"]


@app.command("list")
def list_projects(
    archived: bool = typer.Option(False, "--archived", "-a", help="Include archived projects."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List all projects in the current organization."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}
    if archived:
        params["status"] = "archived"

    try:
        data = client.get("/projects/", params=params)
        projects_list = extract_results(data)
        projects = [Project(**item) for item in projects_list]

        if output_json:
            print_json(projects)
        else:
            # Show which is default
            default_proj = client.config.default_project
            format_projects_table(projects)
            if default_proj:
                console.print(f"\n[dim]Default project: {default_proj}[/dim]")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def show(
    project_id: str = typer.Argument(..., help="Project ID or slug."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show details for a specific project.

    Examples:
        ct projects show <project-id>
        ct projects show my-project-slug
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get(f"/projects/{project_id}/")
        project = Project(**data)

        if output_json:
            print_json(project)
        else:
            billing_labels = {
                "per_task": "Per Task",
                "per_person": "Per Person",
                "custom": "Custom (Waterfall)",
            }
            console.print(f"\n[bold]{project.name}[/bold]")
            console.print(f"  ID:           {project.id}")
            console.print(f"  Code:         {project.code}")
            console.print(f"  Client:       {project.client_name or project.client or '-'}")
            console.print(f"  Status:       {project.status}")
            console.print(f"  Billable:     {'Yes' if project.is_billable else 'No'}")
            console.print(f"  Billing Mode: {billing_labels.get(project.billing_mode, project.billing_mode)}")
            if project.budget_type and project.budget_type != "none" and project.budget_amount:
                currency = data.get("currency", "USD")
                budget_label = f"{project.budget_amount}h" if project.budget_type == "hours" else format_currency(project.budget_amount, currency)
                console.print(f"  Budget:       {budget_label} ({project.budget_type})")
                console.print(f"  Alert At:     {project.budget_alert_percent}%")
            if project.notes or project.description:
                console.print(f"  Notes:        {project.notes or project.description}")
            console.print()
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Project '{project_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command()
def create(
    name: str = typer.Argument(..., help="Project name."),
    client_name: Optional[str] = typer.Option(None, "--client", "-c", help="Client name."),
    billable: bool = typer.Option(True, "--billable/--no-billable", "-b/-B",
                                  help="Mark as billable."),
    billing_mode: Optional[str] = typer.Option(
        None, "--billing-mode", "-m",
        help="Billing mode: per_task, per_person, custom.",
    ),
    color: Optional[str] = typer.Option(None, "--color", help="Project color hex code (e.g. #FF5733)."),
    budget: Optional[float] = typer.Option(None, "--budget", help="Budget amount (hours or money depending on --budget-type)."),
    budget_type: Optional[str] = typer.Option(None, "--budget-type",
                                               help="Budget type: hours, money, none."),
    budget_alert: Optional[int] = typer.Option(None, "--budget-alert",
                                                help="Budget alert threshold percentage (default: 80)."),
    code: Optional[str] = typer.Option(None, "--code", help="Short project code."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create a new project."""
    api_client = CrowdTimeClient(require_auth=True, require_org=True)

    if billing_mode and billing_mode not in BILLING_MODES:
        format_error(f"Invalid billing mode. Choose from: {', '.join(BILLING_MODES)}")
        raise typer.Exit(1)

    budget_types = ["hours", "money", "none"]
    if budget_type and budget_type not in budget_types:
        format_error(f"Invalid budget type. Choose from: {', '.join(budget_types)}")
        raise typer.Exit(1)
    if budget is not None and budget <= 0:
        format_error("Budget amount must be positive.")
        raise typer.Exit(1)
    if budget_alert is not None and not (0 <= budget_alert <= 100):
        format_error("Budget alert percentage must be between 0 and 100.")
        raise typer.Exit(1)

    payload: dict = {"name": name, "is_billable": billable}
    if billing_mode:
        payload["billing_mode"] = billing_mode
    if color:
        payload["color"] = color
    if budget is not None:
        payload["budget_amount"] = budget
        # Default to hours if not specified
        if not budget_type:
            budget_type = "hours"
            console.print("[yellow]Note: Defaulting budget type to 'hours'. Use --budget-type to specify.[/yellow]")
    if budget_type:
        payload["budget_type"] = budget_type
    if budget_alert is not None:
        payload["budget_alert_percent"] = budget_alert
    if code:
        payload["code"] = code

    # Resolve client name to UUID (or auto-create)
    if client_name:
        try:
            client_id = _resolve_or_create_client(api_client, client_name)
            payload["client"] = str(client_id)
        except APIError as e:
            format_error(f"Failed to resolve client '{client_name}': {e.message}")
            raise typer.Exit(1)

    try:
        data = api_client.post("/projects/", data=payload)
        project = Project(**data)

        if output_json:
            print_json(project)
        else:
            format_success(f"Project '{project.name}' created (ID: {project.id})")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def archive(
    project_id: str = typer.Argument(..., help="Project ID or slug to archive."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
) -> None:
    """Archive a project."""
    if not force:
        if not typer.confirm(f"Archive project '{project_id}'?"):
            console.print("[dim]Cancelled.[/dim]")
            return

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.patch(f"/projects/{project_id}/", data={"status": "archived"})
        format_success(f"Project '{project_id}' archived.")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Project '{project_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command()
def update(
    project_id: str = typer.Argument(..., help="Project ID or slug."),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New project name."),
    client_name: Optional[str] = typer.Option(None, "--client", "-c", help="Client name."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B",
                                            help="Mark as billable or not."),
    billing_mode: Optional[str] = typer.Option(
        None, "--billing-mode", "-m",
        help="Billing mode: per_task, per_person, custom.",
    ),
    color: Optional[str] = typer.Option(None, "--color", help="Project color hex code (e.g. #FF5733)."),
    budget: Optional[float] = typer.Option(None, "--budget", help="Budget amount (hours or money depending on --budget-type)."),
    budget_type: Optional[str] = typer.Option(None, "--budget-type",
                                               help="Budget type: hours, money, none."),
    budget_alert: Optional[int] = typer.Option(None, "--budget-alert",
                                                help="Budget alert threshold percentage."),
    code: Optional[str] = typer.Option(None, "--code", help="Short project code."),
    status: Optional[str] = typer.Option(None, "--status", "-s",
                                          help="Project status: active, paused, completed, archived."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Update an existing project.

    Only specified options are updated; unspecified fields remain unchanged.

    Examples:
        ct projects update my-project --name "New Name"
        ct projects update my-project --budget 200 --budget-type hours
        ct projects update my-project --billing-mode per_person --status paused
    """
    api_client = CrowdTimeClient(require_auth=True, require_org=True)

    if billing_mode and billing_mode not in BILLING_MODES:
        format_error(f"Invalid billing mode. Choose from: {', '.join(BILLING_MODES)}")
        raise typer.Exit(1)

    budget_types = ["hours", "money", "none"]
    if budget_type and budget_type not in budget_types:
        format_error(f"Invalid budget type. Choose from: {', '.join(budget_types)}")
        raise typer.Exit(1)
    if budget is not None and budget <= 0:
        format_error("Budget amount must be positive.")
        raise typer.Exit(1)
    if budget_alert is not None and not (0 <= budget_alert <= 100):
        format_error("Budget alert percentage must be between 0 and 100.")
        raise typer.Exit(1)

    valid_statuses = ["active", "paused", "completed", "archived"]
    if status and status not in valid_statuses:
        format_error(f"Invalid status. Choose from: {', '.join(valid_statuses)}")
        raise typer.Exit(1)

    payload: dict = {}
    if name is not None:
        payload["name"] = name
    if billable is not None:
        payload["is_billable"] = billable
    if billing_mode:
        payload["billing_mode"] = billing_mode
    if color:
        payload["color"] = color
    if budget is not None:
        payload["budget_amount"] = budget
    if budget_type:
        payload["budget_type"] = budget_type
    if budget_alert is not None:
        payload["budget_alert_percent"] = budget_alert
    if code is not None:
        payload["code"] = code
    if status:
        payload["status"] = status

    if not payload:
        format_error("No changes specified. Use --name, --budget, --status, etc.")
        raise typer.Exit(1)

    # Resolve client name to UUID (or auto-create)
    if client_name:
        try:
            client_id = _resolve_or_create_client(api_client, client_name)
            payload["client"] = str(client_id)
        except APIError as e:
            format_error(f"Failed to resolve client '{client_name}': {e.message}")
            raise typer.Exit(1)

    try:
        data = api_client.patch(f"/projects/{project_id}/", data=payload)
        project = Project(**data)

        if output_json:
            print_json(project)
        else:
            format_success(f"Project '{project.name}' updated (ID: {project.id})")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Project '{project_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("switch")
def switch_project(
    slug: str = typer.Argument(..., help="Project slug or name to set as default."),
) -> None:
    """Set a project as the default for new entries."""
    config = get_config()
    config.set("defaults.project", slug)
    format_success(f"Default project set to '{slug}'")


@app.command("budget")
def budget(
    project_id: str = typer.Argument(..., help="Project ID or slug."),
    refresh: bool = typer.Option(False, "--refresh", help="Trigger a fresh budget snapshot computation."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show project budget status.

    Displays budget type, amount, spent, remaining, and percentage used.
    Use --refresh to trigger a fresh snapshot computation.

    Examples:
        ct projects budget my-project
        ct projects budget my-project --refresh
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        # Fetch project details for budget type and amount
        project_data = client.get(f"/projects/{project_id}/")
        project = Project(**project_data)

        # Trigger refresh if requested
        if refresh:
            console.print("[dim]Computing fresh budget snapshot...[/dim]")
            client.post("/reports/budget-burn/compute/", data={"project_id": str(project.id)})

        # Fetch budget burn data
        burn_data = client.get(f"/reports/budget-burn/{project.id}/")

        if output_json:
            print_json({
                "project": project_data,
                "budget_burn": burn_data,
            })
        else:
            budget_type = project_data.get("budget_type", "none")
            budget_amount = project_data.get("budget_amount")

            console.print(f"\n[bold]{project.name}[/bold] — Budget Status")
            console.print(f"  Budget Type:  {budget_type.replace('_', ' ').capitalize() if budget_type else 'None'}")

            if not budget_amount and budget_type in ("none", None):
                console.print("  [dim]No budget configured for this project.[/dim]")
                console.print()
                return

            # Parse budget values
            spent = Decimal(str(burn_data.get("spent", burn_data.get("total_spent", 0))))
            budget_val = Decimal(str(budget_amount)) if budget_amount else Decimal("0")
            remaining = budget_val - spent if budget_val else Decimal("0")
            pct_used = (spent / budget_val * 100) if budget_val else Decimal("0")

            # Determine if budget is hours or currency
            is_hours_budget = budget_type in ("hours", "total_hours", None)

            if is_hours_budget:
                console.print(f"  Budget:       {format_duration(budget_val)}")
                console.print(f"  Spent:        {format_duration(spent)}")
                remaining_style = "red" if remaining < 0 else "green"
                console.print(f"  Remaining:    [{remaining_style}]{format_duration(abs(remaining))}{'  (over budget)' if remaining < 0 else ''}[/{remaining_style}]")
            else:
                currency = project_data.get("currency", "USD")
                console.print(f"  Budget:       {format_currency(budget_val, currency)}")
                console.print(f"  Spent:        {format_currency(spent, currency)}")
                remaining_style = "red" if remaining < 0 else "green"
                console.print(f"  Remaining:    [{remaining_style}]{format_currency(abs(remaining), currency)}{'  (over budget)' if remaining < 0 else ''}[/{remaining_style}]")

            # Progress bar
            pct_float = min(float(pct_used), 100)
            bar_width = 30
            filled = int(bar_width * pct_float / 100)
            bar_style = "green" if pct_float < 75 else "yellow" if pct_float < 90 else "red"
            bar = f"[{bar_style}]" + "\u2588" * filled + f"[/{bar_style}]" + "[dim]" + "\u2591" * (bar_width - filled) + "[/dim]"
            console.print(f"  Used:         {bar} {pct_used:.1f}%")

            # Fetch forecast data from insights endpoint
            try:
                insights_data = client.get("/insights/projects/")
                for p in insights_data.get("projects", []):
                    if p.get("id") == str(project.id):
                        burn_weekly = p.get("burn_rate_weekly")
                        exhaust_date = p.get("estimated_exhaustion_date")
                        if burn_weekly is not None:
                            if is_hours_budget:
                                console.print(f"  Burn Rate:    {format_duration(Decimal(str(burn_weekly)))}/week")
                            else:
                                console.print(f"  Burn Rate:    {format_currency(Decimal(str(burn_weekly)), currency)}/week")
                        if exhaust_date:
                            console.print(f"  Exhaustion:   [yellow]{exhaust_date}[/yellow]")
                        elif remaining <= 0:
                            console.print(f"  Exhaustion:   [red]Over budget[/red]")
                        elif remaining > 0:
                            console.print(f"  Exhaustion:   [green]On track[/green]")
                        break
            except APIError:
                pass  # Insights not available (permission or no data) — skip silently

            if refresh:
                console.print("\n  [dim]Snapshot refreshed.[/dim]")

            console.print()
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Project '{project_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("members")
def list_members(
    project_id: str = typer.Argument(..., help="Project ID or slug."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List members assigned to a project.

    Shows each member's name, email, project role, org role, and hourly rate.

    Examples:
        ct projects members my-project
        ct projects members my-project --json
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get(f"/projects/{project_id}/members/")
        members_list = data if isinstance(data, list) else extract_results(data)

        if output_json:
            print_json(members_list)
            return

        if not members_list:
            console.print("[dim]No members assigned to this project.[/dim]")
            return

        table = Table(show_header=True, header_style="bold")
        table.add_column("Name", width=20)
        table.add_column("Email", width=25)
        table.add_column("Project Role", width=16)
        table.add_column("Org Role", width=16)
        table.add_column("Rate", justify="right", width=10)
        table.add_column("User ID", style="dim")

        for m in members_list:
            proj_role = m.get("project_role") or "[dim]-[/dim]"
            org_role = m.get("org_role") or ""
            rate = m.get("hourly_rate")
            rate_str = str(rate) if rate else "[dim]-[/dim]"
            table.add_row(
                m.get("user_name", ""),
                m.get("user_email", ""),
                proj_role,
                org_role,
                rate_str,
                m.get("user", ""),
            )

        console.print(table)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Project '{project_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("tasks")
def list_tasks(
    project_id: str = typer.Argument(..., help="Project ID or slug."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List tasks assigned to a project.

    Shows each task's name, billable status, and hourly rate override.

    Examples:
        ct projects tasks my-project
        ct projects tasks my-project --json
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get(f"/projects/{project_id}/tasks/")
        tasks_list = data if isinstance(data, list) else extract_results(data)

        if output_json:
            print_json(tasks_list)
            return

        if not tasks_list:
            console.print("[dim]No tasks assigned to this project.[/dim]")
            return

        table = Table(show_header=True, header_style="bold")
        table.add_column("Task Name", width=25)
        table.add_column("Billable", width=10)
        table.add_column("Task Rate", justify="right", width=12)
        table.add_column("Project Rate", justify="right", width=14)
        table.add_column("Active", width=8)
        table.add_column("Task ID", style="dim")

        for t in tasks_list:
            billable = "[green]Yes[/green]" if t.get("task_is_billable") else "[dim]No[/dim]"
            task_rate = t.get("task_hourly_rate")
            task_rate_str = str(task_rate) if task_rate else "[dim]-[/dim]"
            proj_rate = t.get("hourly_rate")
            proj_rate_str = str(proj_rate) if proj_rate else "[dim]-[/dim]"
            active = "[green]Yes[/green]" if t.get("is_active", True) else "[dim]No[/dim]"
            table.add_row(
                t.get("task_name", ""),
                billable,
                task_rate_str,
                proj_rate_str,
                active,
                t.get("task", ""),
            )

        console.print(table)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Project '{project_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("update-member")
def update_member(
    project_id: str = typer.Argument(..., help="Project ID."),
    user_id: str = typer.Argument(..., help="User ID to update."),
    role: Optional[str] = typer.Option(None, "--role", "-r", help="Project role override."),
    rate: Optional[str] = typer.Option(None, "--rate", help="Hourly rate for this project."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Update a project member's role or rate.

    Examples:
        ct projects update-member <project-id> <user-id> --role project_manager
        ct projects update-member <project-id> <user-id> --rate 150
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {}
    if role is not None:
        payload["project_role"] = role
    if rate is not None:
        payload["hourly_rate"] = rate

    if not payload:
        format_error("Provide at least --role or --rate to update.")
        raise typer.Exit(1)

    try:
        data = client.patch(f"/projects/{project_id}/members/{user_id}/", data=payload)
        if output_json:
            print_json(data)
        else:
            name = data.get("user_name") or data.get("user_email", user_id)
            parts = []
            if role:
                parts.append(f"role={data.get('effective_role', role)}")
            if rate:
                org_rate = data.get("org_hourly_rate")
                rate_info = f"rate={data.get('hourly_rate', rate)}"
                if org_rate:
                    rate_info += f" (org rate: {org_rate})"
                parts.append(rate_info)
            format_success(f"Updated {name}: {', '.join(parts)}")
    except APIError as e:
        if e.status_code == 404:
            format_error("Project or member not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("add-members")
def add_members_bulk(
    project_id: str = typer.Argument(..., help="Project ID."),
    users: List[str] = typer.Option(..., "--user", "-u", help="User ID(s) to add. Repeat for multiple."),
    role: Optional[str] = typer.Option(None, "--role", "-r", help="Project role for all."),
    rate: Optional[str] = typer.Option(None, "--rate", help="Hourly rate for all."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Bulk add members to a project.

    Examples:
        ct projects add-members <project-id> --user <uid1> --user <uid2>
        ct projects add-members <project-id> --user <uid1> --user <uid2> --role member --rate 120
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    members = []
    for uid in users:
        entry: dict = {"user_id": uid}
        if role:
            entry["project_role"] = role
        if rate:
            entry["hourly_rate"] = rate
        members.append(entry)

    try:
        data = client.post(f"/projects/{project_id}/members/bulk/", data={"members": members})
        result = extract_results(data) or data

        if output_json:
            print_json(result)
        else:
            count = len(result) if isinstance(result, list) else 0
            format_success(f"Added/updated {count} members on project.")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("add-tasks")
def add_tasks_bulk(
    project_id: str = typer.Argument(..., help="Project ID."),
    tasks: List[str] = typer.Option(..., "--task", "-t", help="Task ID(s) to assign. Repeat for multiple."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Bulk assign tasks to a project.

    Examples:
        ct projects add-tasks <project-id> --task <tid1> --task <tid2>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post(f"/projects/{project_id}/tasks/bulk/", data={"task_ids": tasks})
        result = extract_results(data) or data

        if output_json:
            print_json(result)
        else:
            count = len(result) if isinstance(result, list) else 0
            format_success(f"Assigned {count} tasks to project.")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)
