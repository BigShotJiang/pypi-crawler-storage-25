"""CrowdTime CLI - AI-powered time tracking from the command line."""

__version__ = "0.10.0"
