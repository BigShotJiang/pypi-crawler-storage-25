"""Anonymous, opt-out usage telemetry for pisama-core.

Fired once per process on first DetectionOrchestrator instantiation.

What is sent:
    install_id    UUID4 generated locally and persisted at ~/.pisama/install_id
    sdk_version   pisama-core package version
    python        e.g. "3.12.3"
    os            platform.system() — Darwin / Linux / Windows
    os_release    platform.release() (truncated to 64 chars)
    runtime_env   one of: github_actions, gitlab_ci, circleci, jenkins, travis,
                  aws_lambda, vercel, fly, modal, kubernetes, docker, local
    event         "first_run" the first time, "session" thereafter
    ts            request time (added server-side)

What is NOT sent: trace contents, detector outputs, file paths, environment
variables, hostnames, IPs (server discards on receipt), API keys, user names.

How to disable (any one of these works):
    export PISAMA_TELEMETRY=0       # also: false / no / off / empty
    export DO_NOT_TRACK=1           # consoledonottrack.com convention
    touch ~/.pisama/telemetry_disabled
    python -c "import pisama_core; pisama_core.disable_telemetry()"
"""

from __future__ import annotations

import json
import os
import platform
import sys
import threading
import uuid
from importlib.metadata import PackageNotFoundError, version as _pkg_version
from pathlib import Path

_ENDPOINT = os.environ.get(
    "PISAMA_TELEMETRY_ENDPOINT",
    "https://api.pisama.ai/api/v1/telemetry/install",
)
_CONFIG_DIR = Path.home() / ".pisama"
_INSTALL_ID_FILE = _CONFIG_DIR / "install_id"
_OPT_OUT_FILE = _CONFIG_DIR / "telemetry_disabled"
_BANNER_FILE = _CONFIG_DIR / "telemetry_banner_shown"

_FIRED_THIS_PROCESS = False
_FIRED_LOCK = threading.Lock()

_BANNER = (
    "[pisama] One-time notice: pisama-core sends an anonymous install ping "
    "(version, OS, Python). No code, traces, or identifiers.\n"
    "[pisama] Disable: export PISAMA_TELEMETRY=0  |  Details: "
    "https://github.com/tn-pisama/pisama-core#telemetry"
)


def _is_disabled() -> bool:
    val = os.environ.get("PISAMA_TELEMETRY")
    if val is not None and val.strip().lower() in ("", "0", "false", "no", "off"):
        return True
    dnt = os.environ.get("DO_NOT_TRACK")
    if dnt is not None and dnt.strip() not in ("", "0", "false", "no", "off"):
        return True
    if _OPT_OUT_FILE.exists():
        return True
    return False


def _detect_runtime_env() -> str:
    env = os.environ
    if env.get("GITHUB_ACTIONS"):
        return "github_actions"
    if env.get("GITLAB_CI"):
        return "gitlab_ci"
    if env.get("CIRCLECI"):
        return "circleci"
    if env.get("JENKINS_URL"):
        return "jenkins"
    if env.get("TRAVIS"):
        return "travis"
    if env.get("AWS_LAMBDA_FUNCTION_NAME"):
        return "aws_lambda"
    if env.get("VERCEL"):
        return "vercel"
    if env.get("FLY_APP_NAME"):
        return "fly"
    if env.get("MODAL_TASK_ID"):
        return "modal"
    if env.get("KUBERNETES_SERVICE_HOST"):
        return "kubernetes"
    if Path("/.dockerenv").exists():
        return "docker"
    return "local"


def _load_or_create_install_id() -> tuple[str, bool]:
    try:
        _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    except OSError:
        return str(uuid.uuid4()), True

    if _INSTALL_ID_FILE.exists():
        try:
            existing = _INSTALL_ID_FILE.read_text().strip()
            if existing:
                return existing, False
        except OSError:
            pass

    new_id = str(uuid.uuid4())
    try:
        _INSTALL_ID_FILE.write_text(new_id)
    except OSError:
        pass
    return new_id, True


def _show_banner_once() -> None:
    if _BANNER_FILE.exists():
        return
    try:
        sys.stderr.write(_BANNER + "\n")
        sys.stderr.flush()
    except Exception:
        return
    try:
        _BANNER_FILE.touch()
    except OSError:
        pass


def _get_version() -> str:
    try:
        return _pkg_version("pisama-core")
    except PackageNotFoundError:
        return "0.0.0+unknown"
    except Exception:
        return "unknown"


def _build_payload(install_id: str, is_first_run: bool) -> dict[str, str]:
    py = sys.version_info
    return {
        "install_id": install_id,
        "sdk_version": _get_version(),
        "python": f"{py.major}.{py.minor}.{py.micro}",
        "os": platform.system() or "unknown",
        "os_release": (platform.release() or "")[:64],
        "runtime_env": _detect_runtime_env(),
        "event": "first_run" if is_first_run else "session",
    }


def _send(payload: dict[str, str]) -> None:
    # Stdlib-only: pisama-core's only runtime dependency is pydantic.
    try:
        import urllib.request

        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            _ENDPOINT,
            data=body,
            headers={
                "Content-Type": "application/json",
                "User-Agent": f"pisama-core/{payload['sdk_version']} ({payload['os']})",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=2) as resp:
            resp.read(0)
    except Exception:
        # Telemetry must never raise into the host process.
        pass


def _run() -> None:
    try:
        if _is_disabled():
            return
        install_id, is_first_run = _load_or_create_install_id()
        if is_first_run:
            _show_banner_once()
        _send(_build_payload(install_id, is_first_run))
    except Exception:
        pass


def record_first_run() -> None:
    """Fire telemetry once per process. Safe to call from constructors."""
    global _FIRED_THIS_PROCESS
    with _FIRED_LOCK:
        if _FIRED_THIS_PROCESS:
            return
        _FIRED_THIS_PROCESS = True
    if _is_disabled():
        return
    try:
        threading.Thread(target=_run, name="pisama-telemetry", daemon=True).start()
    except Exception:
        pass


def disable_telemetry() -> None:
    """Programmatic kill switch. Persists opt-out for future processes."""
    try:
        _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        _OPT_OUT_FILE.touch()
    except OSError:
        pass
    os.environ["PISAMA_TELEMETRY"] = "0"
