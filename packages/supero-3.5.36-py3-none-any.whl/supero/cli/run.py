"""
supero.cli.run — Main orchestrator for Supero App Runner

Entry point: python3 -m supero.cli

Robust orchestrator with proper logging and error reporting:
  1. Validate project files exist (schemas.py, config.py, setup.py)
  2. Detect & report SDK versions (supero, pymodel_*, requests)
  3. Interactive .env setup (if not configured)
  4. CDN downloads (supero-ui.js, index.html, server.py, config.js)
  5. Run setup.py (handles ALL platform interaction via AppSetup)
  6. Start server (or mobile, or docker)

The CLI does NOT duplicate platform logic — setup.py's AppSetup.run()
handles domain bootstrap, schema upload, services, workflows, policies,
and seed data. The CLI only ensures .env + venv + infrastructure files exist.
"""

import os
import sys
import time
import socket
import subprocess
import atexit
import signal

# RUN_PY_MOBILE_REORDER_V1_APPLIED
# Track a backgrounded web-server process so we can clean it up on exit
# when --mobile is used (server runs in background while user starts expo).
_BG_SERVER_PROC = None

# RUN_PY_NODE_AUTOINSTALL_V1_APPLIED
# Best-effort Node 20 install for --mobile. Returns an env dict with the
# upgraded PATH that should be passed to subprocess.run for expo.sh.
# Never raises — failures degrade to "use whatever is on PATH" and let
# expo.sh's own version check be the safety net.
NODE_MIN_MAJOR = 18
NODE_TARGET_MAJOR = "20"

# Bash bootstrap — installs nvm + Node 20 + prints upgraded PATH.
# nvm install URL is a literal here; no Python-side string splicing.
_NODE_BOOTSTRAP_SCRIPT = r"""
set -e
export NVM_DIR="${NVM_DIR:-$HOME/.nvm}"

if [ ! -s "$NVM_DIR/nvm.sh" ]; then
    echo "[node-bootstrap] Installing nvm..." >&2
    if command -v curl >/dev/null 2>&1; then
        curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash >&2
    elif command -v wget >/dev/null 2>&1; then
        wget -qO- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash >&2
    else
        echo "[node-bootstrap] ERROR: neither curl nor wget available" >&2
        exit 1
    fi
fi

# shellcheck disable=SC1091
. "$NVM_DIR/nvm.sh"

if ! nvm ls 20 >/dev/null 2>&1; then
    echo "[node-bootstrap] Installing Node 20..." >&2
    nvm install 20 >&2
fi
nvm use 20 >&2
nvm alias default 20 >/dev/null 2>&1 || true

echo "PATH=$PATH"
echo "NODE=$(command -v node)"
echo "NODE_VERSION=$(node --version)"
"""

def _current_node_major():
    """Return current Node major version int, or None if Node not found."""
    try:
        out = subprocess.check_output(
            ["node", "--version"], stderr=subprocess.DEVNULL, text=True
        ).strip()
        if out.startswith("v"):
            return int(out[1:].split(".")[0])
    except (FileNotFoundError, subprocess.CalledProcessError, ValueError):
        pass
    return None

def _ensure_node_for_mobile(verbose=False, logger=None):
    """
    Best-effort: ensure node >= NODE_MIN_MAJOR is on PATH for the expo
    subprocess. Returns an env dict (for subprocess.run env=) with an
    upgraded PATH if we successfully installed Node, or os.environ.copy()
    otherwise. Never raises.
    """
    env = os.environ.copy()
    current = _current_node_major()
    if current is not None and current >= NODE_MIN_MAJOR:
        if logger: logger.info(f"Node v{current}.x detected — meets minimum (>= {NODE_MIN_MAJOR})")
        return env

    if current is None:
        _info(f"Node not found — installing Node {NODE_TARGET_MAJOR} via nvm (this can take a minute)")
        if logger: logger.info("Node not found; bootstrapping via nvm")
    else:
        _info(
            f"Node v{current}.x found but Expo SDK 54 needs >= {NODE_MIN_MAJOR}; "
            f"installing Node {NODE_TARGET_MAJOR} via nvm"
        )
        if logger: logger.info(f"Node v{current}.x is too old; bootstrapping Node {NODE_TARGET_MAJOR} via nvm")

    try:
        result = subprocess.run(
            ["bash", "-c", _NODE_BOOTSTRAP_SCRIPT],
            capture_output=True,
            text=True,
            timeout=300,
        )
    except subprocess.TimeoutExpired:
        _warn("Node auto-install timed out after 5min — continuing with system Node")
        if logger: logger.warning("Node bootstrap timed out")
        return env
    except Exception as exc:
        _warn(f"Node auto-install failed: {exc} — continuing with system Node")
        if logger: logger.warning(f"Node bootstrap raised: {exc}")
        return env

    if result.returncode != 0:
        _warn(
            "Node auto-install failed — continuing with system Node "
            "(expo.sh will refuse to set up if Node is too old)"
        )
        if logger: logger.warning(
            f"Node bootstrap exited {result.returncode}; "
            f"stderr tail: {result.stderr.strip()[-500:]}"
        )
        if verbose and result.stderr:
            for line in result.stderr.strip().splitlines()[-10:]:
                print(f"    {line}")
        return env

    new_path = None
    new_node_version = None
    for line in result.stdout.strip().splitlines():
        if line.startswith("PATH="):
            new_path = line[len("PATH="):]
        elif line.startswith("NODE_VERSION="):
            new_node_version = line[len("NODE_VERSION="):]
    if not new_path:
        _warn("Node bootstrap produced no PATH — continuing with system Node")
        if logger: logger.warning("Node bootstrap stdout missing PATH line")
        return env

    env["PATH"] = new_path
    _ok(f"Node {new_node_version or NODE_TARGET_MAJOR + '.x'} ready for mobile setup")
    if logger: logger.info(f"Node bootstrap OK; new node: {new_node_version}")
    return env


def _kill_bg_server():
    global _BG_SERVER_PROC
    p = _BG_SERVER_PROC
    if p is None:
        return
    try:
        if p.poll() is None:
            p.terminate()
            try:
                p.wait(timeout=5)
            except Exception:
                p.kill()
    except Exception:
        pass

atexit.register(_kill_bg_server)
signal.signal(signal.SIGINT,  lambda *_: (_kill_bg_server(), sys.exit(130)))
signal.signal(signal.SIGTERM, lambda *_: (_kill_bg_server(), sys.exit(143)))
import argparse
import logging
from datetime import datetime

from supero.cli.env_manager import EnvManager
from supero.cli.interactive import interactive_setup
# REPLACED-BY-3.5.0: per-file template strings replaced
# by the wheel-bundled supero.install machinery.
from supero.install import extract_to_project, PROJECT_MANIFEST as _SUPERO_MANIFEST
import re
import unicodedata
import datetime as _dt


__version__ = "1.2.0"

# Bump this when crud_tests.py template changes; existing files
# with older stamps are auto-regenerated by _ensure_crud_tests().
CRUD_TESTS_VERSION = "2"
E2E_TESTS_VERSION = "1"
WORKFLOW_TESTS_VERSION = "1"


# ── Logging setup ────────────────────────────────────────────
LOG_FILE = os.path.join(os.getcwd(), ".supero-run.log")

def _setup_logging(verbose: bool = False):
    """Configure file + console logging."""
    logger = logging.getLogger("supero.cli")
    logger.setLevel(logging.DEBUG)

    # File handler — always DEBUG
    fh = logging.FileHandler(LOG_FILE, mode="a")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(
        "[%(asctime)s] %(levelname)s %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    ))
    logger.addHandler(fh)

    # Console handler — INFO or DEBUG
    if verbose:
        ch = logging.StreamHandler()
        ch.setLevel(logging.DEBUG)
        ch.setFormatter(logging.Formatter("  %(levelname)s %(message)s"))
        logger.addHandler(ch)

    return logger


# ── ANSI colors for terminal output ──
class _C:
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    RED    = "\033[91m"
    CYAN   = "\033[96m"
    BOLD   = "\033[1m"
    DIM    = "\033[2m"
    RESET  = "\033[0m"

# Disable colors if not a TTY (piped output, CI, etc.)
if not sys.stdout.isatty():
    for attr in ('GREEN', 'YELLOW', 'RED', 'CYAN', 'BOLD', 'DIM', 'RESET'):
        setattr(_C, attr, '')


def _ok(msg):     print(f"  {_C.GREEN}✓{_C.RESET} {msg}")
def _warn(msg):   print(f"  {_C.YELLOW}⚠{_C.RESET} {msg}")
def _fail(msg):   print(f"  {_C.RED}✗{_C.RESET} {msg}")
def _info(msg):   print(f"  {_C.DIM}{msg}{_C.RESET}")
def _header(msg): print(f"\n{_C.BOLD}── {msg} ──{_C.RESET}\n")


def _step(num, title, desc=""):
    """Print a step header with optional description."""
    print(f"\n{_C.BOLD}── Step {num} · {title} ──{_C.RESET}")
    if desc:
        print(f"  {_C.DIM}{desc}{_C.RESET}\n")


# ── Version detection ────────────────────────────────────────

def _detect_versions() -> dict:
    """
    Detect installed SDK versions and report them.

    Returns dict with:
      python: "3.11.5"
      supero: "1.4.8" or None
      supero_location: "/path/to/supero"
      tenant_sdks: [{"name": "pymodel-foo", "version": "0.1.0", "location": "..."}]
      requests: "2.31.0" or None
      venv: True/False (whether running in a venv)
      venv_path: "/path/to/.venv" or None
    """
    info = {
        "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "python_path": sys.executable,
        "supero": None,
        "supero_location": None,
        "tenant_sdks": [],
        "requests": None,
        "venv": hasattr(sys, 'real_prefix') or (
            hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix
        ),
        "venv_path": sys.prefix if hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix else None,
    }

    # Supero SDK
    try:
        import supero
        info["supero"] = getattr(supero, '__version__', 'unknown')
        info["supero_location"] = os.path.dirname(supero.__file__)
    except ImportError:
        pass

    # Requests
    try:
        import requests as _req
        info["requests"] = _req.__version__
    except ImportError:
        pass

    # Tenant SDKs (pymodel_*)
    try:
        import pkg_resources
        for pkg in pkg_resources.working_set:
            if pkg.project_name.startswith('pymodel'):
                info["tenant_sdks"].append({
                    "name": pkg.project_name,
                    "version": pkg.version,
                    "location": pkg.location,
                })
    except Exception:
        pass

    return info


def _print_versions(info: dict, logger=None):
    """Print version info in a clean format."""
    _ok(f"Python {info['python']} ({info['python_path']})")

    if info["venv"]:
        _ok(f"Virtual env: {info['venv_path'] or 'active'}")
    else:
        _warn("Not running in a virtual environment")
        _info("Tip: run.sh creates .venv automatically. Use ./run.sh instead of python3 -m supero.cli")

    if info["supero"]:
        _ok(f"Supero SDK: v{info['supero']}")
        if logger:
            logger.info(f"Supero SDK v{info['supero']} at {info['supero_location']}")
    else:
        _fail("Supero SDK: NOT INSTALLED")
        _info("Install with: pip install supero")

    if info["requests"]:
        _ok(f"Requests: v{info['requests']}")
    else:
        _fail("Requests library: NOT INSTALLED")

    if info["tenant_sdks"]:
        for sdk in info["tenant_sdks"]:
            _ok(f"Tenant SDK: {sdk['name']} v{sdk['version']}")
            if logger:
                logger.info(f"Tenant SDK: {sdk['name']} v{sdk['version']} at {sdk['location']}")
    else:
        _info("No tenant SDK packages installed (will be built during setup)")

    if logger:
        logger.info(f"Versions: python={info['python']}, supero={info['supero']}, "
                     f"requests={info['requests']}, tenant_sdks={len(info['tenant_sdks'])}, "
                     f"venv={info['venv']}")


# ── Launch mode ──────────────────────────────────────────────


def _is_port_available(port: int) -> bool:
    """Check if a port is available to bind."""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        s.bind(('', port))
        s.close()
        return True
    except OSError:
        return False


def _find_available_port(start_port: int, max_tries: int = 10) -> int:
    """Find next available port starting from start_port."""
    for offset in range(max_tries):
        port = start_port + offset
        if _is_port_available(port):
            return port
    return start_port  # give up, let it fail with the original


def _resolve_port(preferred: int, interactive: bool = True) -> int:
    """Check if preferred port is available, offer alternatives if not."""
    if _is_port_available(preferred):
        return preferred

    # Port is busy
    _warn(f"Port {preferred} is already in use")

    # Try to kill existing process
    try:
        import subprocess
        result = subprocess.run(
            ["lsof", "-ti", f"tcp:{preferred}"],
            capture_output=True, text=True
        )
        if result.stdout.strip():
            pids = result.stdout.strip()
            if interactive:
                print()
                try:
                    choice = input(f"  Kill existing process on port {preferred}? [y/N] ").strip().lower()
                except (EOFError, KeyboardInterrupt):
                    choice = "n"

                if choice in ("y", "yes"):
                    import time
                    subprocess.run(["kill", "-9"] + pids.split(), capture_output=True)
                    time.sleep(1)
                    if _is_port_available(preferred):
                        _ok(f"Port {preferred} freed")
                        return preferred
    except FileNotFoundError:
        pass  # lsof not available

    # Find alternative
    alt_port = _find_available_port(preferred + 1)

    if interactive:
        print()
        try:
            choice = input(f"  Use port {alt_port} instead? [Y/n] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            choice = "y"

        if choice in ("n", "no"):
            _fail(f"Port {preferred} is in use. Free it or use --port={alt_port}")
            sys.exit(1)
    else:
        _info(f"Port {preferred} busy — using {alt_port}")

    return alt_port


def _update_port_in_env(env, new_port: int):
    """Update PORT in .env when port changes (e.g. busy port fallback)."""
    env.set("PORT", str(new_port))
    env.set("UI_PORT", str(new_port))
    env.save()
    _ok(f"Port updated to {new_port} in .env")


def _prompt_launch_mode() -> str:
    """Ask user how they want to run."""
    print()
    print(f"  How would you like to run this app?")
    print()
    print(f"  {_C.BOLD}1){_C.RESET} {_C.GREEN}Standalone{_C.RESET}    Run directly on this machine")
    print(f"     {_C.DIM}Best for: development, quick testing{_C.RESET}")
    print()
    print(f"  {_C.BOLD}2){_C.RESET} {_C.CYAN}Docker{_C.RESET}        Build and run in a container")
    print(f"     {_C.DIM}Best for: production, reproducible deploys{_C.RESET}")
    print()
    print(f"  {_C.BOLD}3){_C.RESET} {_C.DIM}Setup only{_C.RESET}    Configure without starting server")
    print(f"     {_C.DIM}Best for: CI/CD, preparing deploy{_C.RESET}")
    print()
    try:
        choice = input("  Choose [1/2/3] (default: 1): ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        choice = "1"
    return {"2": "docker", "3": "setup"}.get(choice, "standalone")


# ── Args ─────────────────────────────────────────────────────

def parse_args():
    parser = argparse.ArgumentParser(
        prog="supero-run",
        description="Supero App Runner — interactive setup + server launcher",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  ./run.sh                    Interactive setup + start server
  ./run.sh --setup-only       Run setup without starting server
  ./run.sh --server-only      Start server (skip setup)
  ./run.sh --reset            Rebuild venv + re-run setup (keeps .env)
  ./run.sh --reset-config     Wipe .env and reconfigure from scratch
  ./run.sh --docker           Build and run with Docker Compose
  ./run.sh --no-interactive   Use .env values without prompting
  ./run.sh --verbose          Show detailed logs
  ./run.sh --skip-tests       Skip CRUD smoke tests and launch directly

Log file: .supero-run.log (always written, even without --verbose)
        """
    )
    parser.add_argument("--setup-only", action="store_true",
                        help="Run setup without starting server")
    parser.add_argument("--server-only", action="store_true",
                        help="Start server without running setup")
    parser.add_argument("--build-ui-schemas", action="store_true",  # BAKE_UI_SCHEMAS_V1
                        help="Bake UI schemas into ui/supero-schemas.js and exit")
    parser.add_argument("--mobile", action="store_true",
                        help="Also set up the mobile app (Expo)")
    parser.add_argument("--docker", action="store_true",
                        help="Build and run with Docker Compose")
    parser.add_argument("--port", type=int,
                        help="Override server port (default: from .env or 5648)")
    parser.add_argument("--no-interactive", action="store_true",
                        help="Use .env values without prompting")
    parser.add_argument("--reset", action="store_true",
                        help="Rebuild venv and re-run setup (preserves .env credentials)")
    parser.add_argument("--reset-config", action="store_true",
                        help="WIPE .env and start fresh (asks for domain, project, etc. again)")
    parser.add_argument("--verbose", action="store_true",
                        help="Show detailed logs from setup and server")
    parser.add_argument("--no-seed", action="store_true",
                        help="Skip seeding test data (seed runs by default)")
    parser.add_argument("--seed", action="store_true", default=True,
                        help=argparse.SUPPRESS)
    parser.add_argument("--skip-tests", action="store_true",
                        help="Skip CRUD smoke tests before launching")
    parser.add_argument("--version", action="version",
                        version=f"%(prog)s {__version__}")
    return parser.parse_args()


# ── Project validation ───────────────────────────────────────

def validate_project(path: str, logger=None) -> dict:
    """Validate that required project files exist."""
    required = [
        ("schemas.py", "Schema definitions"),
        ("config.py",  "App configuration"),
        ("setup.py",   "Setup script"),
    ]

    missing = []
    for filename, desc in required:
        filepath = os.path.join(path, filename)
        if os.path.exists(filepath):
            _ok(f"Found {filename}")
        else:
            _fail(f"Missing {filename} ({desc})")
            missing.append(filename)

    has_web = (
        os.path.exists(os.path.join(path, "ui", "app.js"))
        or os.path.exists(os.path.join(os.getcwd(), "ui", "app.js"))
    )
    has_mobile = (
        os.path.exists(os.path.join(path, "mobile", "src", "appConfig.ts"))
        or os.path.exists(os.path.join(os.getcwd(), "mobile", "src", "appConfig.ts"))
    )

    if has_web:
        _ok("Found ui/app.js (Web UI)")
    if has_mobile:
        _ok("Found mobile/src/appConfig.ts (Mobile)")
    if not has_web and not has_mobile:
        _warn("No ui/app.js or mobile/src/appConfig.ts found")

    if missing:
        print()
        _fail(f"Missing required files: {', '.join(missing)}")
        _info("Make sure you're in the app root directory.")
        if logger:
            logger.error(f"Missing project files: {missing}")
        sys.exit(1)

    if logger:
        logger.info(f"Project validated: has_web={has_web}, has_mobile={has_mobile}")

    return {"has_web": has_web, "has_mobile": has_mobile}


# BAKE_UI_SCHEMAS_V1
def _bake_ui_schemas(app_dir, verbose=False):
    """Generate <app_dir>/ui/supero-schemas.js from wheel + tenant schemas.

    Inputs:
      - Base UI schemas from supero/ui/schemas/{atoms,actions,views,pages}/*.json
        (read via importlib.resources from the supero wheel)
      - Tenant UI schemas from <app_dir>/schemas.py, filtered for
        schema_type == 'ui'

    Output:
      - <app_dir>/ui/supero-schemas.js with:
            window.SUPERO_UI_SCHEMAS = {...}
            window.SUPERO_UI_SCHEMAS_META = {...}

    Normalization:
      Base schemas in the wheel use a `schema_content` wrapper; this
      function unwraps it so the output is a single consistent flat
      format matching tenant schemas.

    Never raises. Returns (ok, base_count, tenant_count) tuple.
    On any failure logs a warning and returns (False, _, _) — caller
    decides whether to continue.
    """
    import json as _json
    import time as _time
    try:
        from importlib.resources import files as _resource_files
    except ImportError:
        try:
            from importlib_resources import files as _resource_files
        except ImportError:
            print("  [bake_ui] importlib.resources unavailable — skipping",
                  file=sys.stderr)
            return (False, 0, 0)

    base_schemas = {}
    tenant_schemas = {}

    # ── 1. Base schemas from wheel ──
    try:
        base_dir = _resource_files('supero.ui') / 'schemas'
        if base_dir.is_dir():
            for category in ('atoms', 'actions', 'views', 'pages'):
                cat_dir = base_dir / category
                if not cat_dir.is_dir():
                    continue
                for f in cat_dir.iterdir():
                    if not f.name.endswith('.json'):
                        continue
                    try:
                        raw = _json.loads(f.read_text())
                        name = raw.get('name')
                        if not name:
                            continue
                        # Unwrap schema_content if present (normalize to flat)
                        if isinstance(raw.get('schema_content'), dict):
                            flat = dict(raw['schema_content'])
                            flat['name'] = name
                            flat['schema_type'] = raw.get('schema_type', 'ui')
                        else:
                            flat = dict(raw)
                        flat['namespace'] = 'supero_ui'
                        flat['_category'] = category
                        base_schemas[f'supero_ui:{name}'] = flat
                    except Exception as e:
                        if verbose:
                            print(f"  [bake_ui] Skip {f.name}: {e}", file=sys.stderr)
    except Exception as e:
        print(f"  [bake_ui] Warning: base schemas load failed: {e}",
              file=sys.stderr)

    # ── 2. Tenant schemas: prefer ui_schemas.py, fallback to schemas.py ──
    # BAKE_UI_PY_V1
    # Priority chain:
    #   1. <app_dir>/ui_schemas.py with UI_SCHEMAS list   (new format)
    #   2. <app_dir>/schemas.py with ALL_SCHEMAS filtered (legacy)
    _ui_schemas_py = os.path.join(app_dir, 'ui_schemas.py')
    _schemas_py = os.path.join(app_dir, 'schemas.py')

    def _load_from_module(mod, list_attr, filter_ui_only, default_ns_attr):
        """Extract UI schemas from an imported module. Returns dict."""
        out = {}
        items = getattr(mod, list_attr, None)
        if not isinstance(items, list):
            return out
        default_ns = (
            getattr(mod, default_ns_attr, None)
            or os.environ.get('SUPERO_APP_NAMESPACE', '')
            or 'tenant'
        )
        for s in items:
            if not isinstance(s, dict):
                continue
            if filter_ui_only and s.get('schema_type') != 'ui':
                continue
            name = s.get('name')
            if not name:
                continue
            ns = s.get('namespace') or default_ns
            key = f'{ns}:{name}'
            copy = dict(s)
            copy['namespace'] = ns
            out[key] = copy
        return out

    _loaded_source = None
    if os.path.isfile(_ui_schemas_py):
        try:
            if app_dir not in sys.path:
                sys.path.insert(0, app_dir)
            if 'ui_schemas' in sys.modules:
                del sys.modules['ui_schemas']
            import importlib as _importlib
            _ui_mod = _importlib.import_module('ui_schemas')
            tenant_schemas = _load_from_module(
                _ui_mod, 'UI_SCHEMAS',
                filter_ui_only=False,
                default_ns_attr='SUPERO_APP_NAMESPACE',
            )
            _loaded_source = 'ui_schemas.py'
            if verbose:
                print(f"  [bake_ui] Loaded {len(tenant_schemas)} from ui_schemas.py")
        except Exception as e:
            print(f"  [bake_ui] Warning: ui_schemas.py load failed: {e}",
                  file=sys.stderr)
            if verbose:
                import traceback as _tb
                _tb.print_exc()

    if not tenant_schemas and os.path.isfile(_schemas_py):
        try:
            if app_dir not in sys.path:
                sys.path.insert(0, app_dir)
            if 'schemas' in sys.modules:
                del sys.modules['schemas']
            import importlib as _importlib
            _legacy_mod = _importlib.import_module('schemas')
            tenant_schemas = _load_from_module(
                _legacy_mod, 'ALL_SCHEMAS',
                filter_ui_only=True,
                default_ns_attr='SUPERO_APP_NAMESPACE',
            )
            _loaded_source = 'schemas.py (legacy fallback)'
            if verbose and tenant_schemas:
                print(f"  [bake_ui] Loaded {len(tenant_schemas)} from schemas.py (legacy)")
        except Exception as e:
            print(f"  [bake_ui] Warning: schemas.py fallback failed: {e}",
                  file=sys.stderr)
            if verbose:
                import traceback as _tb
                _tb.print_exc()
    # /BAKE_UI_PY_V1

    # ── 3. Merge and write ──
    all_schemas = {}
    all_schemas.update(base_schemas)
    all_schemas.update(tenant_schemas)

    ui_dir = os.path.join(app_dir, 'ui')
    if not os.path.isdir(ui_dir):
        print(f"  [bake_ui] {ui_dir} missing — skipping write", file=sys.stderr)
        return (False, len(base_schemas), len(tenant_schemas))

    out_path = os.path.join(ui_dir, 'supero-schemas.js')
    try:
        stamp = _time.strftime('%Y-%m-%dT%H:%M:%SZ', _time.gmtime())
        meta = {
            'base_count': len(base_schemas),
            'tenant_count': len(tenant_schemas),
            'total': len(all_schemas),
            'generated_at': stamp,
        }
        body = (
            "// Generated by supero.cli --build-ui-schemas. Do not edit.\n"
            f"// Generated at: {stamp}\n"
            f"// Base: {len(base_schemas)} schemas | Tenant: {len(tenant_schemas)} schemas\n"
            "\n"
            "window.SUPERO_UI_SCHEMAS = "
            + _json.dumps(all_schemas, indent=2, sort_keys=True)
            + ";\n\n"
            "window.SUPERO_UI_SCHEMAS_META = "
            + _json.dumps(meta, indent=2)
            + ";\n"
        )
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write(body)
        size_kb = len(body) / 1024
        print(f"  ✓ UI schemas baked: {out_path} "
              f"({len(all_schemas)} schemas, {size_kb:.1f}KB)")
        return (True, len(base_schemas), len(tenant_schemas))
    except Exception as e:
        print(f"  [bake_ui] Write failed: {e}", file=sys.stderr)
        return (False, len(base_schemas), len(tenant_schemas))
# /BAKE_UI_SCHEMAS_V1


def _find_app_dir() -> str:
    """Find the app package directory containing setup.py."""
    cwd = os.getcwd()

    # Flat layout
    if os.path.exists(os.path.join(cwd, "setup.py")):
        return cwd

    # Package layout
    for entry in os.listdir(cwd):
        candidate = os.path.join(cwd, entry)
        if (os.path.isdir(candidate)
                and not entry.startswith(".")
                and entry not in ("mobile", "e2e-tests", ".venv", "__pycache__", "node_modules")
                and os.path.exists(os.path.join(candidate, "setup.py"))):
            return candidate

    return cwd


def _get_lan_ip() -> str:
    """Get LAN IP address for network URL display."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(2)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "0.0.0.0"


def _extract_public_schemas_ast(schemas_py_path: str):
    """Statically extract PUBLIC_SCHEMAS from schemas.py via AST.

    Does NOT execute the file — safe even if schemas.py has import-time
    side effects, missing dependencies, or imports that aren't available
    in the CLI's Python environment.

    Returns (status, value, error):
      status:
        'defined'      — PUBLIC_SCHEMAS = [...] or (...) found, value populated
        'not_defined'  — PUBLIC_SCHEMAS not in file at all
        'non_literal'  — PUBLIC_SCHEMAS = some_function() — can't extract statically
        'parse_error'  — schemas.py has a syntax error
        'io_error'     — couldn't read the file
      value: list of strings (only meaningful when status == 'defined')
      error: error message (set for parse_error / io_error / non_literal)
    """
    import ast as _ast_x
    try:
        with open(schemas_py_path) as _fr:
            _source = _fr.read()
    except OSError as _ioe:
        return ('io_error', [], str(_ioe))

    try:
        _tree = _ast_x.parse(_source)
    except SyntaxError as _se:
        return ('parse_error', [], f"line {_se.lineno}: {_se.msg}")

    # Walk top-level statements only — PUBLIC_SCHEMAS is module-level.
    # ast.walk() would also descend into function bodies, which would
    # falsely match a local variable named PUBLIC_SCHEMAS.
    for _node in _tree.body:
        if not isinstance(_node, _ast_x.Assign):
            continue
        if len(_node.targets) != 1:
            continue
        _target = _node.targets[0]
        if not isinstance(_target, _ast_x.Name) or _target.id != "PUBLIC_SCHEMAS":
            continue
        # Found the assignment — check the value
        _value = _node.value
        if isinstance(_value, (_ast_x.List, _ast_x.Tuple)):
            _schemas = []
            for _elt in _value.elts:
                if isinstance(_elt, _ast_x.Constant) and isinstance(_elt.value, str):
                    _schemas.append(_elt.value)
                elif (isinstance(_elt, _ast_x.Call)
                        and isinstance(getattr(_elt, 'func', None), _ast_x.Name)
                        and getattr(_elt.func, 'id', '') == 'to_url_name'
                        and _elt.args
                        and isinstance(_elt.args[0], _ast_x.Constant)
                        and isinstance(_elt.args[0].value, str)):
                    # Handle to_url_name("PascalCase") → compute snake_case statically.
                    # Generated schemas.py often uses to_url_name() in PUBLIC_SCHEMAS
                    # because the same function is used elsewhere (setup.py, policies).
                    # We evaluate it here so the CLI doesn't need to import the module.
                    import re as _re_ast
                    _pascal = _elt.args[0].value
                    _snake = _re_ast.sub(r'(?<!^)(?=[A-Z])', '_', _pascal).lower()
                    _schemas.append(_snake)
                else:
                    return ('non_literal', [],
                            "PUBLIC_SCHEMAS contains non-string-literal elements")
            return ('defined', _schemas, None)
        else:
            return ('non_literal', [],
                    "PUBLIC_SCHEMAS is not a literal list/tuple "
                    "(found function call, variable reference, or comprehension)")

    return ('not_defined', [], None)



def _fetch_is_multi_tenant(env) -> bool:
    """Get is_multi_tenant for this project.

    Primary: reads SUPERO_IS_MULTI_TENANT from .env (written at app-gen time
    by the AI service from the project record). Fast, reliable, no auth needed.

    Fallback: legacy remote fetch against /api/v1/crud/<domain>/project. Kept
    for backward compat with apps generated before SUPERO_IS_MULTI_TENANT
    was added to .env. Tenant-scoped API keys may not be able to list
    projects, so this path is best-effort and silently returns False on
    any error.
    """
    # Refresh env from disk — bootstrap writes a refreshed api-key to .env
    # after initial EnvManager init, so cached in-memory values may be stale.
    if hasattr(env, 'reload'):
        env.reload()
    # Primary path: explicit env var from app-gen time
    _explicit = env.get_project_setting('IS_MULTI_TENANT', default=None) if hasattr(env, 'get_project_setting') else None
    if _explicit is True:
        return True
    if _explicit is False:
        return False
    # _explicit is None → env var not set. Fall back to remote fetch for
    # backward compat (older apps generated before this env var existed).
    import urllib.request, urllib.error, json, ssl
    try:
        def _strip(s):
            return s.strip().strip('"').strip("'") if s else ''
        domain = _strip(env.get('SUPERO_DOMAIN', ''))
        project = _strip(env.get('SUPERO_PROJECT', ''))
        api_key = _strip(env.get('SUPERO_API_KEY', ''))
        api_url = _strip(env.get('SUPERO_URL', 'https://api.supero.dev')).rstrip('/')
        if not (domain and project and api_key):
            return False
        ctx = ssl._create_unverified_context()
        headers = {'X-API-Key': api_key, 'Content-Type': 'application/json'}
        url = f"{api_url}/api/v1/crud/{domain}/project"
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=10, context=ctx) as resp:
            data = json.loads(resp.read())
        results = data.get('results') or data.get('data') or []
        for proj in results:
            if proj.get('name') == project:
                return bool(proj.get('is_multi_tenant', False))
        return False
    except Exception as e:
        import sys
        print(f"  ⚠ _fetch_is_multi_tenant fallback failed: {type(e).__name__}: {e}", file=sys.stderr)
        return False


# ─────────────────────────────────────────────────────────────────────────────
# SUPERO-FINGERPRINT-CAPTURE-V1
# Capture platform fingerprint after successful setup.
#
# Reads SUPERO_DOMAIN / SUPERO_PROJECT / SUPERO_API_KEY / SUPERO_URL from
# .env (same as _fetch_is_multi_tenant). Resolves project name -> uuid,
# fetches GET /api/v1/projects/{uuid}/fingerprint, writes the result to
# .supero-state.json next to .env.
#
# Best-effort: any failure logs a warning and returns False. Never raises.
# ─────────────────────────────────────────────────────────────────────────────

_SUPERO_STATE_FILE = ".supero-state.json"
_SUPERO_STATE_SCHEMA_VERSION = "1"


def _capture_setup_state(env, logger=None) -> bool:
    """Fetch current fingerprint, write .supero-state.json.

    Returns True on success, False on any failure (logged as warning).
    """
    import json
    import os
    import ssl
    import tempfile
    import urllib.request
    import urllib.error
    from datetime import datetime, timezone

    def _log_info(msg):
        if logger:
            logger.info(msg)

    def _log_warn(msg):
        if logger:
            logger.warning(msg)

    def _strip(s):
        if not s:
            return ""
        return s.strip().strip('"').strip("'")

    # Read .env values (same pattern as _fetch_is_multi_tenant)
    if hasattr(env, "reload"):
        try:
            env.reload()
        except Exception:
            pass
    api_url = _strip(env.get("SUPERO_URL", "https://api.supero.dev")).rstrip("/")
    domain = _strip(env.get("SUPERO_DOMAIN", ""))
    project_name = _strip(env.get("SUPERO_PROJECT", ""))
    api_key = _strip(env.get("SUPERO_API_KEY", ""))

    if not (domain and project_name and api_key):
        _log_warn(
            "fingerprint capture skipped: missing "
            "SUPERO_DOMAIN/SUPERO_PROJECT/SUPERO_API_KEY"
        )
        _warn(
            "fingerprint capture skipped (missing identity in .env)"
        )
        return False

    ctx = ssl._create_unverified_context()
    headers = {"X-API-Key": api_key, "Content-Type": "application/json"}

    # Step 1: Resolve project name -> uuid
    try:
        url = f"{api_url}/api/v1/crud/{domain}/project"
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=10, context=ctx) as resp:
            body = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        _log_warn(f"fingerprint capture: project lookup HTTP {e.code}")
        _warn(f"fingerprint capture: project lookup returned HTTP {e.code}")
        return False
    except Exception as e:
        _log_warn(f"fingerprint capture: project lookup failed: {e}")
        _warn(f"fingerprint capture: project lookup failed ({type(e).__name__})")
        return False

    project_uuid = None
    for proj in (body.get("results") or body.get("data") or []):
        if isinstance(proj, dict) and proj.get("name") == project_name:
            project_uuid = proj.get("uuid")
            break
    if not project_uuid:
        _log_warn(f"fingerprint capture: project {project_name!r} not found")
        _warn(f"fingerprint capture: project {project_name!r} not found")
        return False

    # Step 2: Fetch fingerprint
    try:
        url = f"{api_url}/api/v1/projects/{project_uuid}/fingerprint"
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=10, context=ctx) as resp:
            body = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        _log_warn(f"fingerprint capture: fetch HTTP {e.code}")
        _warn(f"fingerprint capture: fingerprint fetch returned HTTP {e.code}")
        return False
    except Exception as e:
        _log_warn(f"fingerprint capture: fetch failed: {e}")
        _warn(f"fingerprint capture: fingerprint fetch failed ({type(e).__name__})")
        return False

    fp = body.get("fingerprint")
    if not isinstance(fp, dict) or not fp.get("composite"):
        _log_warn(f"fingerprint capture: bad response shape: {str(body)[:200]}")
        _warn("fingerprint capture: fingerprint endpoint returned no data")
        return False

    # Step 3: Compose state file
    try:
        version = __version__  # noqa: F821 — module-level constant
    except Exception:
        version = "unknown"

    state = {
        "schema_version": _SUPERO_STATE_SCHEMA_VERSION,
        "fingerprint": fp,
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "supero_sdk_version": version,
        "project_uuid": project_uuid,
        "domain_name": domain,
        "project_name": project_name,
    }

    # Step 4: Write atomically (tmpfile + rename)
    try:
        cwd = os.getcwd()
        state_path = os.path.join(cwd, _SUPERO_STATE_FILE)
        # Write to a temp file in the same dir (so rename is atomic)
        fd, tmp_path = tempfile.mkstemp(
            prefix=".supero-state-", suffix=".tmp", dir=cwd,
        )
        try:
            with os.fdopen(fd, "w") as f:
                json.dump(state, f, indent=2)
                f.write("\n")
            os.replace(tmp_path, state_path)
        except Exception:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass
            raise
    except Exception as e:
        _log_warn(f"fingerprint capture: write failed: {e}")
        _warn(f"fingerprint capture: could not write {_SUPERO_STATE_FILE}")
        return False

    composite_short = fp["composite"][:24] + "..."
    _log_info(
        f"fingerprint captured: composite={composite_short} "
        f"-> {_SUPERO_STATE_FILE}"
    )
    _ok(f"Fingerprint captured ({composite_short})")
    return True


# ─────────────────────────────────────────────────────────────────────────────
# Module-scope helpers used by _read_app_meta and main().
#
# _strip_js_comments  — used by _read_app_meta to scrub JS comments before
#                       regex-matching publicSchemas, so a comment that
#                       mentions publicSchemas doesn't trigger a false
#                       "stale publicSchemas" warning. (Bug 5/12.)
# _extract_app_namespace_ast / _resolve_app_namespace
#                     — single source of truth for SUPERO_APP_NAMESPACE.
#                       Resolution priority:
#                         1. SUPERO_APP_NAMESPACE literal in schemas.py
#                         2. SUPERO_APP_NAMESPACE env var
#                         3. slugify(SUPERO_DOMAIN) fallback
#                       Used by main() to populate .env and os.environ
#                       once, after which env_manager.generate_config_js,
#                       install/__init__.py, and the embedded crud_tests.py
#                       smoke test all read the same value. (Bug 9.)
# ─────────────────────────────────────────────────────────────────────────────

def _strip_js_comments(source):
    """
    Return `source` with JavaScript line/block comments removed but
    string/template literal contents preserved verbatim.

    State machine over the source. Recognises:
      - Double-quoted strings  "..." (with \\-escapes)
      - Single-quoted strings  '...' (with \\-escapes)
      - Template literals      `...` (with \\-escapes; ${...} expressions
                                       are not recursively parsed — sufficient
                                       for comment detection)
      - Line comments          //...end-of-line
      - Block comments         /* ... */

    // and /* sequences inside string/template literals are preserved.
    Newlines inside block comments are preserved so line-anchored regex
    still works on the result.
    """
    out = []
    i = 0
    n = len(source)
    state = None  # None | 'str_d' | 'str_s' | 'str_t' | 'line_cmt' | 'block_cmt'

    while i < n:
        c = source[i]
        nxt = source[i + 1] if i + 1 < n else ""

        if state is None:
            if c == "/" and nxt == "/":
                state = 'line_cmt'; i += 2; continue
            if c == "/" and nxt == "*":
                state = 'block_cmt'; i += 2; continue
            if c == '"':
                state = 'str_d'; out.append(c); i += 1; continue
            if c == "'":
                state = 'str_s'; out.append(c); i += 1; continue
            if c == "`":
                state = 'str_t'; out.append(c); i += 1; continue
            out.append(c); i += 1; continue

        if state == 'line_cmt':
            if c == "\n":
                state = None
                out.append("\n")
            i += 1; continue

        if state == 'block_cmt':
            if c == "*" and nxt == "/":
                state = None; i += 2; continue
            if c == "\n":
                out.append("\n")
            i += 1; continue

        # Inside a string/template literal.
        if state in ('str_d', 'str_s', 'str_t'):
            out.append(c)
            if c == "\\" and i + 1 < n:
                out.append(source[i + 1])
                i += 2; continue
            if state == 'str_d' and c == '"':
                state = None
            elif state == 'str_s' and c == "'":
                state = None
            elif state == 'str_t' and c == "`":
                state = None
            i += 1; continue

        # Unreachable; bail with what we have.
        break

    return "".join(out)


def _extract_app_namespace_ast(schemas_py_path):
    """
    AST-extract SUPERO_APP_NAMESPACE from schemas.py.

    Returns one of:
      ('literal', '<value>', None)      — bare string literal assignment
      ('non_literal', None, None)       — defined but not a bare literal
                                          (e.g. os.environ.get(...) expression)
      ('not_defined', None, None)       — name never assigned at module level
      ('error', None, '<reason>')       — file unreadable or unparseable

    Mirrors the contract of _extract_public_schemas_ast.
    """
    import ast as _ast_local
    try:
        with open(schemas_py_path, "r", encoding="utf-8") as f:
            source = f.read()
    except (OSError, IOError) as e:
        return ("error", None, f"read failed: {e}")

    try:
        tree = _ast_local.parse(source, filename=schemas_py_path)
    except SyntaxError as e:
        return ("error", None, f"parse failed: {e}")

    found_non_literal = False
    # Walk top-level statements only — SUPERO_APP_NAMESPACE is module-level.
    for node in tree.body:
        if not isinstance(node, _ast_local.Assign):
            continue
        for target in node.targets:
            if not (isinstance(target, _ast_local.Name)
                    and target.id == "SUPERO_APP_NAMESPACE"):
                continue
            if (isinstance(node.value, _ast_local.Constant)
                    and isinstance(node.value.value, str)):
                return ("literal", node.value.value, None)
            found_non_literal = True

    if found_non_literal:
        return ("non_literal", None, None)
    return ("not_defined", None, None)


def _resolve_app_namespace(app_dir, env_like, domain):
    """
    Resolve the canonical app namespace via priority chain.

    Arguments:
      app_dir   — directory containing schemas.py (or None to skip AST step)
      env_like  — mapping with .get() for env lookups (os.environ or similar)
      domain    — SUPERO_DOMAIN string (used for the final slugify fallback)

    Returns a normalized string: lowercased, dashes-to-underscores.
    """
    def _norm(s):
        return (s or "").strip().lower().replace("-", "_")

    # 1. schemas.py literal — authoritative
    if app_dir:
        schemas_py = os.path.join(app_dir, "schemas.py")
        if os.path.isfile(schemas_py):
            status, value, _err = _extract_app_namespace_ast(schemas_py)
            if status == "literal" and value:
                return _norm(value)
            # 'non_literal' / 'not_defined' / 'error' — fall through silently.

    # 2. SUPERO_APP_NAMESPACE env var (CLI sets this once; downstream reads it)
    val = env_like.get("SUPERO_APP_NAMESPACE") if hasattr(env_like, "get") else None
    if val:
        return _norm(val)

    # 3. slugify(SUPERO_DOMAIN) — fallback preserves pre-Bug-9 behavior
    # SUPERO_NAMESPACE_REQUIRED_V1 — final fallback to domain removed.
    # Cascade exhausted: schemas.py had no literal, env had no value.
    raise RuntimeError(
        "Cannot resolve SUPERO_APP_NAMESPACE.\n"
        "Checked (in order):\n"
        "  1. schemas.py bare literal — not found or non-literal\n"
        "  2. SUPERO_APP_NAMESPACE env var — empty\n"
        "\n"
        "Falling back to SUPERO_DOMAIN was removed because it\n"
        "silently routed CRUD to wrong namespace.\n"
        "\n"
        "Fix: add to schemas.py as a bare literal:\n"
        "  SUPERO_APP_NAMESPACE = \"<your_namespace>\"\n"
        "\n"
        "See SUPERO_NAMESPACE_REQUIRED_V1."
    )


def _read_app_meta(app_dir: str) -> dict:
    """Extract app metadata from config.py + schemas.py.

    Branding (name/emoji/description) comes from config.py.
    public_schemas comes from schemas.py PUBLIC_SCHEMAS — that is the
    single source of truth. PUBLIC_SCHEMAS is extracted via AST parsing
    (not by executing schemas.py), so a broken or import-failing
    schemas.py produces a clear diagnostic instead of a silent default.
    If app.js still has a stale publicSchemas array (from an older
    generation), a warning is printed but the schemas.py value wins.
    """
    config_path = os.path.join(app_dir, "config.py")
    result = {"name": "", "emoji": "", "description": "", "public_schemas": []}

    # ── Branding from config.py ──
    if os.path.exists(config_path):
        attr_map = {
            "app_name": "name",
            "display_name": "name",
            "app_emoji": "emoji",
            "app_description": "description",
        }
        try:
            with open(config_path) as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    for attr, key in attr_map.items():
                        if line.startswith(f"{attr}") and "=" in line:
                            val = line.split("=", 1)[1].strip().strip("'\"")
                            if val and not result[key]:
                                result[key] = val
        except Exception:
            pass

    # ── public_schemas from schemas.py (single source of truth, AST-based) ──
    _schemas_py = os.path.join(app_dir, "schemas.py")
    _public_schemas_loaded = False
    if os.path.exists(_schemas_py):
        _status, _value, _err = _extract_public_schemas_ast(_schemas_py)
        if _status == 'defined':
            result["public_schemas"] = _value
            _public_schemas_loaded = True
        elif _status == 'not_defined':
            print(
                "  \u2139  PUBLIC_SCHEMAS not defined in schemas.py \u2014 "
                "defaulting to empty (no public landing page). "
                "Add `PUBLIC_SCHEMAS = []` for explicit private, or "
                "`PUBLIC_SCHEMAS = [\"schema_name\"]` to expose schemas publicly."
            )
        elif _status == 'non_literal':
            print(
                f"  \u26a0  Cannot statically extract PUBLIC_SCHEMAS from "
                f"schemas.py: {_err}. Defaulting to empty. Use a literal "
                f"list of strings."
            )
        elif _status == 'parse_error':
            print(
                f"  \u26a0  schemas.py has a syntax error ({_err}). "
                f"Defaulting publicSchemas to empty. Fix the file."
            )
        elif _status == 'io_error':
            print(
                f"  \u26a0  Could not read schemas.py: {_err}. "
                f"Defaulting publicSchemas to empty."
            )

    # ── Sanity check: warn if app.js disagrees ──
    if _public_schemas_loaded:
        _app_js = os.path.join(app_dir, "ui", "app.js")
        if not os.path.exists(_app_js):
            _app_js = os.path.join(app_dir, "app.js")
        if os.path.exists(_app_js):
            try:
                import re as _re_warn
                with open(_app_js) as _fjs:
                    # [bug5-patch] strip JS comments first to avoid
                    # false-positive "stale publicSchemas" warnings
                    # when a comment in app.js happens to mention
                    # publicSchemas: [...].
                    _ac = _strip_js_comments(_fjs.read())
                _m = _re_warn.search(r'publicSchemas\s*:\s*\[([^\]]*)\]', _ac)
                if _m:
                    # Two patterns to require matching quotes — the v1
                    # pattern allowed 'foo" mismatches.
                    _js_schemas = (
                        _re_warn.findall(r'"(\w[\w-]*)"', _m.group(1))
                        + _re_warn.findall(r"'(\w[\w-]*)'", _m.group(1))
                    )
                    _py_set = set(result["public_schemas"])
                    _js_set = set(_js_schemas)
                    if _py_set != _js_set:
                        print(
                            f"  \u26a0  app.js has stale publicSchemas {sorted(_js_set)} "
                            f"that disagrees with schemas.py PUBLIC_SCHEMAS "
                            f"{sorted(_py_set)} \u2014 using schemas.py. "
                            f"Remove the publicSchemas line from app.js to silence this warning."
                        )
            except Exception:
                pass

    return result


def _ensure_crud_tests(app_dir: str):
    """Generate crud_tests.py in app_dir.

    Auto-regenerates if the existing file is missing the current
    CRUD_TESTS_VERSION stamp on its first line. This propagates
    template fixes (e.g. namespace qualification) into existing
    apps without requiring users to manually rm the file.
    """
    dest = os.path.join(app_dir, "crud_tests.py")
    expected_marker = "# CRUD_TESTS_TEMPLATE_VERSION: " + CRUD_TESTS_VERSION
    if os.path.exists(dest):
        try:
            with open(dest, "r") as _fr:
                first_line = _fr.readline().rstrip("\n")
            if first_line == expected_marker:
                return  # up-to-date
            print("  \u21bb crud_tests.py is stale, regenerating with namespace-aware version...")
        except Exception:
            return  # if we can't read it, leave it alone
    # Only generate when schemas.py and config.py are present (supero.cli app)
    if not (os.path.exists(os.path.join(app_dir, "schemas.py")) and
            os.path.exists(os.path.join(app_dir, "config.py"))):
        return
    content = '''\
"""
crud_tests.py — CRUD smoke tests for all schemas.

Run automatically by supero CLI (Step 4.5) after setup and before server launch.
Exit 0 = all tests passed. Exit 1 = one or more failures (launch will be blocked).

Can also be run directly:
    python crud_tests.py

Requires env vars (set by run.sh / .env):
    SUPERO_URL, SUPERO_DOMAIN, SUPERO_ADMIN_EMAIL, SUPERO_PASSWORD,
    SUPERO_PROJECT, SUPERO_API_KEY, SUPERO_DEFAULT_TENANT
"""

import os
import sys
import uuid as _uuid
import warnings

import requests
urllib3 = None
try:
    import urllib3 as _urllib3
    urllib3 = _urllib3
except ImportError:
    pass

# Suppress SSL warnings (dev/staging environments use self-signed certs)
warnings.filterwarnings("ignore", message="Unverified HTTPS request")
if urllib3:
    urllib3.disable_warnings()

# -- Load app schemas and config from the same directory ----------------------
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from schemas import ALL_SCHEMAS
from config import AppConfig

# -- Credentials from environment ---------------------------------------------
BASE_URL    = os.environ.get("SUPERO_URL", "https://api.supero.dev").rstrip("/")
DOMAIN      = os.environ.get("SUPERO_DOMAIN", "")
PROJECT     = os.environ.get("SUPERO_PROJECT", "default-project")
API_KEY     = os.environ.get("SUPERO_API_KEY", "")
ADMIN_EMAIL = os.environ.get("SUPERO_ADMIN_EMAIL", "")
ADMIN_PASS  = os.environ.get("SUPERO_PASSWORD", "")

# -- PascalCase → snake_case (matches platform storage form) -----------------
import re as _re
def _to_snake(name):
    """FamilyMember -> family_member, Photo -> photo, MenuItem -> menu_item."""
    return _re.sub(r'(?<!^)(?=[A-Z])', '_', name).lower()


# -- Types to skip when building test payloads --------------------------------
SKIP_TYPES = {"File"}

# -- Primitive type -> minimal valid value ------------------------------------
TYPE_DEFAULTS = {
    "string":   lambda h: f"test-{h}",
    "integer":  lambda _: 1,
    "float":    lambda _: 1.0,
    "datetime": lambda _: "2026-01-01T00:00:00Z",
    "bool":     lambda _: True,
    "Image":    lambda h: {"url": f"https://picsum.photos/seed/{h}/800/600",
                           "thumbnail_url": f"https://picsum.photos/seed/{h}/400/300"},
}


# -- Helpers ------------------------------------------------------------------

def make_session(token=None, api_key=None):
    s = requests.Session()
    s.verify = False
    s.headers.update({"Content-Type": "application/json"})
    if token:
        s.headers["Authorization"] = f"Bearer {token}"
    if api_key:
        s.headers["X-API-Key"] = api_key
    return s


def login(email, password, project=None):
    """Login and return JWT access token, or None on failure."""
    try:
        r = requests.post(
            f"{BASE_URL}/api/v1/auth/login",
            json={"username": email, "password": password,
                  "domain": DOMAIN, "project": project or PROJECT},
            headers={"Content-Type": "application/json"},
            timeout=15, verify=False,
        )
        if r.status_code in (200, 201):
            auth = r.json().get("auth", {})
            return auth.get("access_token") or auth.get("session_id")
    except Exception:
        pass
    return None


def fetch_tenant_uuid(session, tenant_name):
    """Return UUID of named tenant, or None."""
    try:
        r = session.get(f"{BASE_URL}/api/v1/crud/{DOMAIN}/tenant", timeout=15)
        if r.status_code in (200, 201):
            for t in r.json().get("results", []):
                if t.get("name") == tenant_name:
                    return t["uuid"]
    except Exception:
        pass
    return None


def extract_uuid(body):
    """Extract UUID from various response shapes."""
    if not isinstance(body, dict):
        return None
    if body.get("uuid"):
        return body["uuid"]
    data = body.get("data", {})
    if isinstance(data, dict):
        if data.get("uuid"):
            return data["uuid"]
        for v in data.values():
            if isinstance(v, dict) and v.get("uuid"):
                return v["uuid"]
    return None


def build_enum_map(schemas):
    """Build {EnumName: first_valid_value} from ALL_SCHEMAS."""
    return {
        s["name"]: s["values"][0]
        for s in schemas
        if s.get("schema_type") == "enum" and s.get("values")
    }


def make_payload(schema_dict, hex_suffix, tenant_uuid, enum_map):
    """Build minimal valid create payload for a schema."""
    payload = {
        "name": f"smoketest-{_to_snake(schema_dict[\'name\'])}-{hex_suffix}",
        "parent_type": "tenant",
        "parent_uuid": tenant_uuid,
    }
    for attr in schema_dict.get("attributes", []):
        if not attr.get("mandatory"):
            continue
        atype = attr["type"]
        if atype in SKIP_TYPES:
            continue
        if atype in TYPE_DEFAULTS:
            payload[attr["name"]] = TYPE_DEFAULTS[atype](hex_suffix)
        elif atype in enum_map:
            payload[attr["name"]] = enum_map[atype]
    return payload


# -- Core test functions -------------------------------------------------------

def test_schema_crud(session, schema_name, payload, label):
    msgs = []
    created_uuid = None
    # SUPERO_TEMPLATE_FIX_V1 — restored original template line.
    # EDIT C of patch_namespace_required_python_v1 anchored too
    # loosely and landed inside this template instead of real
    # code at run.py L1173. Step 0 validation (from patch
    # startup_validation_v1) covers the same protection at
    # startup, so this template doesn't need fail-loud.
    _app_ns = (os.environ.get("SUPERO_APP_NAMESPACE") or DOMAIN).lower().replace("-", "_")
    _ns_type = f"{_app_ns}:{_to_snake(schema_name)}"
    url_base = f"{BASE_URL}/api/v1/crud/{DOMAIN}/{_ns_type}"
    passed = True

    try:
        # CREATE
        try:
            r = session.post(url_base, json=payload, timeout=30)
        except Exception as e:
            msgs.append(f"  FAIL CREATE {schema_name} [{label}]: request error -- {e}")
            return False, msgs

        if r.status_code not in (200, 201):
            msgs.append(
                f"  FAIL CREATE {schema_name} [{label}]: "
                f"HTTP {r.status_code} -- {r.text[:200]}"
            )
            return False, msgs

        created_uuid = extract_uuid(r.json())
        if not created_uuid:
            msgs.append(
                f"  FAIL CREATE {schema_name} [{label}]: "
                f"no UUID in response -- {r.text[:200]}"
            )
            return False, msgs
        msgs.append(f"  PASS CREATE {schema_name} [{label}]")

        # READ
        try:
            r = session.get(f"{url_base}/{created_uuid}", timeout=15)
            if r.status_code == 200:
                msgs.append(f"  PASS READ   {schema_name} [{label}]")
            else:
                msgs.append(f"  FAIL READ   {schema_name} [{label}]: HTTP {r.status_code}")
                passed = False
        except Exception as e:
            msgs.append(f"  FAIL READ   {schema_name} [{label}]: {e}")
            passed = False

        # LIST
        try:
            r = session.get(url_base, timeout=15)
            if r.status_code == 200:
                msgs.append(f"  PASS LIST   {schema_name} [{label}]")
            else:
                msgs.append(f"  FAIL LIST   {schema_name} [{label}]: HTTP {r.status_code}")
                passed = False
        except Exception as e:
            msgs.append(f"  FAIL LIST   {schema_name} [{label}]: {e}")
            passed = False

        # UPDATE
        try:
            r = session.put(
                f"{url_base}/{created_uuid}",
                json={"name": payload["name"] + "-upd"},
                timeout=30,
            )
            if r.status_code in (200, 201):
                msgs.append(f"  PASS UPDATE {schema_name} [{label}]")
            else:
                msgs.append(f"  FAIL UPDATE {schema_name} [{label}]: HTTP {r.status_code}")
                passed = False
        except Exception as e:
            msgs.append(f"  FAIL UPDATE {schema_name} [{label}]: {e}")
            passed = False

    finally:
        # DELETE (always attempt cleanup)
        if created_uuid:
            try:
                r = session.delete(f"{url_base}/{created_uuid}", timeout=15)
                if r.status_code in (200, 204):
                    msgs.append(f"  PASS DELETE {schema_name} [{label}]")
                else:
                    msgs.append(
                        f"  WARN DELETE {schema_name} [{label}]: "
                        f"HTTP {r.status_code} (cleanup may have failed)"
                    )
            except Exception as e:
                msgs.append(f"  WARN DELETE {schema_name} [{label}]: {e} (cleanup)")

    return passed, msgs


# -- Main ---------------------------------------------------------------------

def main():
    if not DOMAIN:
        print("  x SUPERO_DOMAIN not set -- skipping CRUD tests")
        sys.exit(2)
    if not API_KEY and not (ADMIN_EMAIL and ADMIN_PASS):
        print("  x No SUPERO_API_KEY or SUPERO_PASSWORD set -- skipping CRUD tests")
        sys.exit(2)

    hex_suffix = _uuid.uuid4().hex[:8]
    failures = []
    cfg = AppConfig()

    enum_map = build_enum_map(ALL_SCHEMAS)
    object_schemas = [s for s in ALL_SCHEMAS if s.get("schema_type") == "object"]

    if not object_schemas:
        print("  No object schemas found -- skipping CRUD tests")
        sys.exit(0)

    print(f"\\n  Running CRUD smoke tests -- {len(object_schemas)} schemas\\n")

    # Build admin session: prefer API key, fall back to password
    if API_KEY:
        admin_session = make_session(api_key=API_KEY)
    else:
        admin_token = login(ADMIN_EMAIL, ADMIN_PASS)
        if not admin_token:
            print(f"  x Admin login failed for {ADMIN_EMAIL} -- check SUPERO_PASSWORD in .env")
            sys.exit(2)
        admin_session = make_session(token=admin_token)

    # Fast-fail: verify domain is reachable and credentials are valid
    # Exit code 2 = infra/config issue (not a test failure) -- server launch continues
    try:
        r = admin_session.get(f"{BASE_URL}/api/v1/crud/{DOMAIN}/tenant", timeout=15)
        if r.status_code == 401:
            print(f"  x Auth rejected (HTTP 401) -- check SUPERO_API_KEY or SUPERO_PASSWORD in .env")
            print(f"    {r.text[:200]}")
            sys.exit(2)
        elif r.status_code == 404:
            print(f"  x Domain \'{DOMAIN}\' not found (HTTP 404) -- check SUPERO_DOMAIN in .env")
            sys.exit(2)
        elif r.status_code not in (200, 201):
            print(f"  x Unexpected response from server (HTTP {r.status_code}) -- aborting tests")
            print(f"    {r.text[:200]}")
            sys.exit(2)
    except Exception as e:
        print(f"  x Cannot reach {BASE_URL} -- network error, skipping tests")
        print(f"    {e}")
        sys.exit(2)

    # Fetch tenant UUID
    tenant_name = next(
        (t["name"] for t in cfg.tenants if t["name"] != "default-tenant"),
        cfg.tenants[0]["name"] if cfg.tenants else "default-tenant",
    )
    tenant_uuid = fetch_tenant_uuid(admin_session, tenant_name)
    if not tenant_uuid:
        tenant_uuid = fetch_tenant_uuid(admin_session, "default-tenant")
    if not tenant_uuid:
        print(f"  x Could not fetch tenant UUID for \'{tenant_name}\' -- skipping tests")
        sys.exit(2)

    # Build user sessions from config.users
    user_sessions = []
    for u in cfg.users:
        email    = u["email"]
        # REPLACED-BY-3.5.0: no hardcoded password fallback (§1.7).

        password = u.get("password") or getattr(cfg, "default_user_password", "")
        role     = u.get("role", "tenant_user")
        token = login(email, password)
        if token:
            user_sessions.append((make_session(token=token), role, email))
        else:
            print(f"  Warning: Login failed for {email} (role={role}) -- skipping")

    sessions_to_test = [
        (admin_session, "tenant_admin", ADMIN_EMAIL),
        *user_sessions,
    ]

    for schema in object_schemas:
        schema_name = schema["name"]
        payload = make_payload(schema, hex_suffix, tenant_uuid, enum_map)
        print(f"  -- {schema_name} --")
        for session, role, email in sessions_to_test:
            label = f"{role}:{email.split(\'@\')[0]}"
            passed, msgs = test_schema_crud(session, schema_name, payload, label)
            for m in msgs:
                print(m)
            if not passed:
                failures.append(f"{schema_name} [{label}]")
        print()

    if failures:
        print(f"  x {len(failures)} test(s) FAILED:")
        for f in failures:
            print(f"      * {f}")
        sys.exit(1)
    else:
        print("  All CRUD smoke tests passed")
        sys.exit(0)


if __name__ == "__main__":
    main()
'''
    # Prepend version stamp so _ensure_crud_tests() can detect stale files
    _stamp = "# CRUD_TESTS_TEMPLATE_VERSION: " + CRUD_TESTS_VERSION + "\n"
    with open(dest, "w") as _f:
        _f.write(_stamp + content)
    _ok("Generated crud_tests.py")


def _ensure_e2e_tests(app_dir: str):
    """Generate e2e_tests.py from SDK template if missing or stale."""
    dest = os.path.join(app_dir, "e2e_tests.py")
    expected_marker = "# E2E_TESTS_VERSION: " + E2E_TESTS_VERSION
    if os.path.exists(dest):
        try:
            with open(dest, "r") as _fr:
                first_line = _fr.readline().rstrip("\n")
            if first_line == expected_marker:
                return
            print("  \u21bb e2e_tests.py is stale, regenerating...")
        except Exception:
            return
    if not (os.path.exists(os.path.join(app_dir, "schemas.py")) and
            os.path.exists(os.path.join(app_dir, "config.py"))):
        return
    try:
        _cli_dir = os.path.dirname(os.path.abspath(__file__))
        _tmpl = os.path.join(_cli_dir, "_e2e_template.py")
        if os.path.exists(_tmpl):
            with open(_tmpl, "r") as _fr:
                _content = _fr.read()
            with open(dest, "w") as _fw:
                _fw.write("# E2E_TESTS_VERSION: " + E2E_TESTS_VERSION + "\n" + _content)
            _ok("Generated e2e_tests.py")
    except Exception:
        pass


def _ensure_workflow_tests(app_dir: str):
    """Generate workflow_tests.py from SDK template if missing or stale.

    Only generated when setup.py declares WORKFLOW_DEFINITIONS so it doesn't
    appear in apps that have no workflows.
    """
    dest = os.path.join(app_dir, "workflow_tests.py")
    expected_marker = "# WORKFLOW_TESTS_VERSION: " + WORKFLOW_TESTS_VERSION
    if os.path.exists(dest):
        try:
            with open(dest, "r") as _fr:
                first_line = _fr.readline().rstrip("\n")
            if first_line == expected_marker:
                return
            print("  ↻ workflow_tests.py is stale, regenerating...")
        except Exception:
            return

    if not (os.path.exists(os.path.join(app_dir, "schemas.py")) and
            os.path.exists(os.path.join(app_dir, "config.py"))):
        return

    # Only generate when setup.py actually defines WORKFLOW_DEFINITIONS
    setup_path = os.path.join(app_dir, "setup.py")
    if not os.path.exists(setup_path):
        return
    try:
        with open(setup_path, "r") as _fr:
            setup_src = _fr.read()
        if "WORKFLOW_DEFINITIONS" not in setup_src:
            return
    except Exception:
        return

    try:
        _cli_dir = os.path.dirname(os.path.abspath(__file__))
        _tmpl_path = os.path.join(_cli_dir, "_workflow_tests_template.py")
        if not os.path.exists(_tmpl_path):
            return
        # Import the template module to get WORKFLOW_TESTS_TEMPLATE string
        import importlib.util as _ilu
        _spec = _ilu.spec_from_file_location("_wtt", _tmpl_path)
        _mod  = _ilu.module_from_spec(_spec)
        _spec.loader.exec_module(_mod)
        _content = getattr(_mod, "WORKFLOW_TESTS_TEMPLATE", None)
        if not _content:
            return
        with open(dest, "w") as _fw:
            _fw.write("# WORKFLOW_TESTS_VERSION: " + WORKFLOW_TESTS_VERSION + "\n" + _content)
        _ok("Generated workflow_tests.py")
    except Exception:
        pass


def _make_slug(name: str, max_length: int = 40) -> str:
    """
    Produce a Docker-safe slug from an app name.

    Rules:
      - Lowercase
      - NFKD unicode normalize (Über → Uber, Café → Cafe)
      - Non-alphanumeric chars collapse to dashes
      - Leading/trailing dashes stripped
      - Capped at max_length chars
      - Empty result falls back to "supero-app"
    """
    if not name:
        return "supero-app"
    normalized = unicodedata.normalize('NFKD', name)
    ascii_name = normalized.encode('ascii', 'ignore').decode('ascii')
    slug = ascii_name.lower()
    slug = re.sub(r'[^a-z0-9]+', '-', slug)
    slug = slug.strip('-')
    if len(slug) > max_length:
        slug = slug[:max_length].rstrip('-')
    return slug or "supero-app"


def _safe_write(path: str, content: str, label: str) -> bool:
    """
    Write content to path, catching permission and I/O errors.
    Returns True on success, False on error (with a warning printed).
    """
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return True
    except PermissionError:
        _warn(f"Could not write {label}: permission denied ({path})")
        return False
    except OSError as e:
        _warn(f"Could not write {label}: {e}")
        return False


def _ensure_docker_files(app_dir: str, env: 'EnvManager', app_name: str = "supero-app"):
    """Generate Dockerfile and docker-compose.yml from the SDK wheel.

    REPLACED-BY-3.5.0: previously imported DOCKERFILE_TEMPLATE/COMPOSE_TEMPLATE
    as Python strings and called .format(...). Now both files come from the
    wheel's supero.install package via extract_to_project.

    Per-file resilience (3.5.0): each item is extracted in its own
    try/except so one failure does not abort the others.

    Preserves "skip if exists" semantics — user-edited Dockerfiles are
    NOT clobbered.
    """
    project_root = os.getcwd()
    port = env.get("PORT", env.get("UI_PORT", "5648"))
    slug = _make_slug(app_name)

    render_values = {
        "SDK_VERSION": __version__,
        "APP_SLUG": slug,
        "PORT": str(port),
    }

    items_to_extract = []
    dockerfile_path = os.path.join(project_root, "Dockerfile")
    compose_path = os.path.join(project_root, "docker-compose.yml")

    if not os.path.exists(dockerfile_path):
        items_to_extract.append('supero.install:containers/Dockerfile.tmpl')
    else:
        _ok("Found existing Dockerfile")

    if not os.path.exists(compose_path):
        items_to_extract.append('supero.install:containers/docker-compose.yml.tmpl')
    else:
        _ok("Found existing docker-compose.yml")

    # 3.5.0 per-item resilience: extract each item independently so a single
    # failure (e.g. permission error) does not prevent the others from being
    # attempted. extract_to_project is atomic per call; we loop one item at
    # a time and catch per-item.
    for item in items_to_extract:
        try:
            extract_to_project(project_root, items=[item],
                               render_values=render_values)
            if 'Dockerfile' in item:
                _ok("Generated Dockerfile")
            elif 'compose' in item:
                _ok("Generated docker-compose.yml")
        except Exception as exc:
            _warn(f"Could not extract {item}: {exc}")

    return dockerfile_path, compose_path

def _ensure_docs_files(app_dir: str, env: 'EnvManager', app_name: str = "Supero App"):
    """Generate README.md, CLAUDE.md, CUSTOMIZATION.md, .cursorrules, .windsurfrules.

    REPLACED-BY-3.5.0: docs templates now come from the wheel via
    extract_to_project. The .cursorrules / .windsurfrules aliases are
    handled by extract_to_project (the manifest declares CLAUDE.md
    with aliases).

    Per-file resilience (3.5.0): each item is extracted in its own
    try/except so one failure does not abort the others.

    Preserves "skip if exists" semantics — user-edited README.md is
    NOT clobbered.
    """
    project_root = os.getcwd()

    domain = env.get("SUPERO_DOMAIN", "your-domain")
    project = env.get("SUPERO_PROJECT", "default-project")
    tenant = env.get("SUPERO_DEFAULT_TENANT", "default-tenant")
    admin_email = env.get("SUPERO_ADMIN_EMAIL", f"admin@{domain}.com")
    port = env.get("PORT", env.get("UI_PORT", "5648"))
    slug = _make_slug(app_name)

    render_values = {
        "APP_NAME": app_name,
        "APP_SLUG": slug,
        "DOMAIN": domain,
        "PROJECT": project,
        "TENANT": tenant,
        "ADMIN_EMAIL": admin_email,
        "PORT": str(port),
        "SDK_VERSION": __version__,
        "GENERATED_DATE": _dt.date.today().isoformat(),
    }

    readme_path = os.path.join(project_root, "README.md")
    claude_path = os.path.join(project_root, "CLAUDE.md")
    cursor_path = os.path.join(project_root, ".cursorrules")
    windsurf_path = os.path.join(project_root, ".windsurfrules")
    custom_path = os.path.join(project_root, "CUSTOMIZATION.md")

    items_to_extract = []

    if not os.path.exists(readme_path):
        items_to_extract.append('supero.install:docs/README.md.tmpl')
    else:
        _ok("Found existing README.md")

    if not os.path.exists(claude_path):
        items_to_extract.append('supero.install:docs/CLAUDE.md')
    else:
        _ok("Found existing CLAUDE.md")
        # Editor-rule aliases are normally written by extract_to_project
        # alongside CLAUDE.md. If CLAUDE.md exists but aliases do not,
        # copy them manually.
        try:
            with open(claude_path) as _frc:
                _claude_text = _frc.read()
            if not os.path.exists(cursor_path):
                with open(cursor_path, 'w') as _fwc:
                    _fwc.write(_claude_text)
            if not os.path.exists(windsurf_path):
                with open(windsurf_path, 'w') as _fww:
                    _fww.write(_claude_text)
        except Exception:
            pass

    if not os.path.exists(custom_path):
        items_to_extract.append('supero.install:docs/CUSTOMIZATION.md')
    else:
        _ok("Found existing CUSTOMIZATION.md")

    # 3.5.0 per-item resilience: extract each item independently so a single
    # failure does not prevent the others from being attempted.
    for item in items_to_extract:
        try:
            extract_to_project(project_root, items=[item],
                               render_values=render_values)
            if 'README' in item:
                _ok("Generated README.md")
            elif 'CLAUDE' in item:
                _ok("Generated CLAUDE.md")
            elif 'CUSTOMIZATION' in item:
                _ok("Generated CUSTOMIZATION.md")
        except Exception as exc:
            _warn(f"Could not extract {item}: {exc}")

    return readme_path, claude_path, custom_path

def main():
    args = parse_args()
    logger = _setup_logging(verbose=args.verbose)

    logger.info(f"=== supero.cli v{__version__} started ===")
    logger.info(f"CWD: {os.getcwd()}")

    # BAKE_UI_SCHEMAS_V1 — handle --build-ui-schemas as standalone command
    if getattr(args, 'build_ui_schemas', False):
        try:
            app_dir = _find_app_dir()
        except Exception:
            app_dir = os.getcwd()
        ok, base, tenant = _bake_ui_schemas(app_dir, verbose=args.verbose)
        sys.exit(0 if ok else 1)
    # /BAKE_UI_SCHEMAS_V1

    logger.info(f"Args: {sys.argv[1:]}")
    logger.info(f"Env: SUPERO_DOMAIN={os.environ.get('SUPERO_DOMAIN', '')}, "
                f"SUPERO_URL={os.environ.get('SUPERO_URL', '')}")

    # ── Banner ──
    print()
    print(f"{_C.BOLD}🚀 Supero App Runner v{__version__}{_C.RESET}")
    print("━" * 40)

    # ── Step 1: Versions + Project validation ──
    _header("Step 1 · Environment & project files")

    versions = _detect_versions()
    _print_versions(versions, logger)
    print()

    app_dir = _find_app_dir()
    if app_dir != os.getcwd():
        _info(f"App directory: {os.path.basename(app_dir)}/")
        logger.info(f"App dir: {app_dir}")

    project = validate_project(app_dir, logger)

    # Resolve ui_dir
    if os.path.exists(os.path.join(app_dir, "ui", "app.js")):
        ui_base = app_dir
    elif os.path.exists(os.path.join(os.getcwd(), "ui", "app.js")):
        ui_base = os.getcwd()
    else:
        ui_base = app_dir

    # ── Step 2: Environment setup ──
    env = EnvManager(env_path=os.path.join(os.getcwd(), ".env"))

    # Clear stale SUPERO_* env vars from previous runs in this shell session.
    # Without this, a key from a different app/project leaks via os.environ.
    for _k in list(os.environ.keys()):
        if _k.startswith("SUPERO_") or _k in ("PLATFORM_CORE_HOST", "PLATFORM_CORE_PORT"):
            if _k not in env.values:
                del os.environ[_k]
    # Sync .env values into os.environ (override any stale values)
    for _k, _v in env.values.items():
        if _k and _v:
            os.environ[_k] = _v

    if not args.server_only:
        # ── --reset-config: nuke .env (destructive, requires confirmation) ──
        if args.reset_config:
            _header("Step 2 · Wiping ALL configuration")
            _warn("This will delete domain, project, API key, email, and password from .env")
            if not args.no_interactive:
                try:
                    confirm = input(
                        f"  {_C.RED}Are you sure? Type 'yes' to confirm: {_C.RESET}"
                    ).strip().lower()
                except (EOFError, KeyboardInterrupt):
                    confirm = ""
                if confirm != "yes":
                    _info("Aborted — .env preserved")
                    sys.exit(0)
            env.clear()
            _ok("Configuration cleared")
            logger.info("Reset-config: .env wiped")
            print()

        # ── --reset: keep .env, just force setup re-run ──
        elif args.reset:
            _header("Step 2 · Rebuilding (keeping .env credentials)")
            _ok(f"Domain:  {env.get('SUPERO_DOMAIN', '(none)')}")
            _ok(f"Project: {env.get('SUPERO_PROJECT', '(none)')}")
            _info("Venv rebuilt by run.sh; setup.py will re-upload schemas and re-seed")
            logger.info("Reset: keeping .env, forcing setup re-run")
            print()

        if not env.is_configured() or args.reset_config:
            # SUPERO_BUNDLE_RECOVERY_V1 — try bundle-identity recovery
            # before falling through to the interactive_setup wizard.
            # If schemas.py has SUPERO_DOMAIN / SUPERO_PROJECT /
            # SUPERO_APP_NAMESPACE bare literals, recovery prompts
            # only for credentials — the project is locked to the
            # bundle's identity. See env_manager.recover_from_bundle.
            _recovered = False
            try:
                _recovered = env.recover_from_bundle(
                    app_dir, no_interactive=args.no_interactive,
                )
            except Exception as _e:
                logger.warning(f"Bundle recovery failed: {_e}")
            if not _recovered:
                _header("Step 2 · Domain configuration")
                if args.no_interactive:
                    _fail(".env not configured. Run without --no-interactive first.")
                    sys.exit(1)
                interactive_setup(env)
        else:
            _header("Step 2 · Configuration")

            domain = env.get('SUPERO_DOMAIN')
            project_name = env.get('SUPERO_PROJECT', 'default-project')
            email = env.get('SUPERO_ADMIN_EMAIL')
            api_key = env.get('SUPERO_API_KEY')
            url = env.get('SUPERO_URL', 'https://api.supero.dev')
            port = env.get('PORT', env.get('UI_PORT', '5648'))

            print(f"  {_C.CYAN}Domain:{_C.RESET}   {domain}")
            print(f"  {_C.CYAN}Project:{_C.RESET}  {project_name}")
            if email:
                print(f"  {_C.CYAN}Email:{_C.RESET}    {email}")
            if api_key and api_key.startswith("ak_"):
                print(f"  {_C.CYAN}API key:{_C.RESET}  ...{api_key[-4:]}")
            elif env.get('SUPERO_PASSWORD'):
                print(f"  {_C.CYAN}Auth:{_C.RESET}     password (saved)")
            else:
                _warn("No API key or password configured")
                if not args.no_interactive:
                    import getpass
                    print()
                    try:
                        pw = getpass.getpass(f"  Enter password for {email}: ")
                    except (EOFError, KeyboardInterrupt):
                        pw = ""
                    if pw:
                        env.set("SUPERO_PASSWORD", pw)
                        env.save()
                        _ok("Password saved")
                    else:
                        _fail("Password required — setup will fail without credentials")
            print(f"  {_C.CYAN}Server:{_C.RESET}   {url}")
            print(f"  {_C.CYAN}Port:{_C.RESET}     {port}")
            print()

            logger.info(f"Config: domain={domain}, project={project_name}, "
                        f"email={email}, api_key={'yes' if api_key else 'no'}, port={port}")

            if not args.no_interactive:
                try:
                    choice = input(f"  Continue with this configuration? [Y/n] ").strip().lower()
                except (EOFError, KeyboardInterrupt):
                    print()
                    choice = "y"

                if choice in ("n", "no"):
                    # Let user change port
                    print()
                    try:
                        new_port = input(f"  Port [{port}]: ").strip()
                    except (EOFError, KeyboardInterrupt):
                        new_port = ""
                    if new_port and new_port != port:
                        env.set("PORT", new_port)
                        env.set("UI_PORT", new_port)
                        env.save()
                        _ok(f"Port updated to {new_port}")

                    # Offer to re-enter password
                    if not (api_key and api_key.startswith("ak_")):
                        try:
                            import getpass
                            new_pass = getpass.getpass(f"  Password [{('*' * 8 if env.get('SUPERO_PASSWORD') else 'not set')}]: ")
                        except (EOFError, KeyboardInterrupt):
                            new_pass = ""
                        if new_pass:
                            env.set("SUPERO_PASSWORD", new_pass)
                            env.save()
                            _ok("Password updated")
                    print()
    else:
        if not env.is_configured():
            _fail("No .env configuration found. Run without --server-only first.")
            sys.exit(1)
        _header("Step 2 · Skipped (--server-only)")
        _ok(f"Domain: {env.get('SUPERO_DOMAIN')}")

    env.derive_sdk_vars()
    # SUPERO_STARTUP_VALIDATION_V1 — Step 0 config gate.
    # Validates .env / environment BEFORE any setup runs.
    # Refuses to proceed with bad config — better a clear error
    # than a silent empty-UI later.
    _header("Step 0 · Configuration validation")
    try:
        env.validate_required()
        _ok("Configuration valid")
        print()
    except ValueError as _ve:
        print()
        print(str(_ve))
        sys.exit(1)
    
    # [bug9-patch] Resolve SUPERO_APP_NAMESPACE once and propagate to BOTH .env
    # and os.environ. .env lets server.py / env_manager.py / install pick it up;
    # os.environ lets the module-level smoke test (test_schema_crud) see the
    # same value without re-deriving from SUPERO_DOMAIN.
    _resolved_app_ns = _resolve_app_namespace(app_dir, os.environ, env.get("SUPERO_DOMAIN", ""))
    env.set("SUPERO_APP_NAMESPACE", _resolved_app_ns)
    os.environ["SUPERO_APP_NAMESPACE"] = _resolved_app_ns
    _ok(f"App namespace: {_resolved_app_ns}")


    # ── Step 3: CDN downloads + config.js ──
    if project["has_web"]:
        _header("Step 3 · Preparing web UI files")
        ui_dir = os.path.join(ui_base, "ui")

        meta = _read_app_meta(app_dir)
        app_name = env.get("APP_NAME") or meta["name"] or env.get(
            "SUPERO_DOMAIN", "Supero App"
        ).replace("-", " ").title()
        app_emoji = env.get("APP_EMOJI") or meta["emoji"]
        app_description = env.get("APP_DESCRIPTION") or meta["description"]

        # REPLACED-BY-3.5.0: extract ui artifacts from SDK wheel.
        # (always overwrites — bundled artifacts are the source of truth)
        try:
            extract_to_project(
                os.path.dirname(ui_dir) or os.getcwd(),
                items=[
                    'supero.install:templates/index.html.tmpl',
                    'supero.install:templates/server.py',
                    # DISPATCHER_RUNPY_V1 — dispatcher.js must be in this list,
                    # or the SDK won't copy it from .venv to ui/ on server start.
                    'supero.ui:dispatcher.js',
                    # FIELD_RENDERER_RUNPY_V1 — same applies for field-renderer.js.
                    'supero.ui:field-renderer.js',
                    'supero.ui:supero-ui.js',
                ],
                render_values={
                    "app_name": app_name,
                    "version": __version__,
                    "APP_NAME": app_name,
                    "SDK_VERSION": __version__,
                },
            )
            _ok("ui artifacts synced from SDK wheel")
        except Exception as _ex:
            _warn(f"Could not extract ui/ artifacts from wheel: {_ex}")
        _public = meta.get("public_schemas", [])
        _tn_sing = env.get("SUPERO_TENANT_NOUN_SINGULAR", "Workspace") or "Workspace"
        _tn_plur = env.get("SUPERO_TENANT_NOUN_PLURAL", "Workspaces") or "Workspaces"
        env.generate_config_js(
            ui_dir,
            app_name=app_name,
            app_emoji=app_emoji,
            app_description=app_description,
            public_schemas=_public,
            is_multi_tenant=False,  # First pass: no auth yet, default False; refreshed in Step 3.5
            tenant_noun_singular=_tn_sing,
            tenant_noun_plural=_tn_plur,
            app_namespace=_resolved_app_ns,
        )
        if _public:
            _schemas_csv = ",".join(_public)
            env.set("PUBLIC_SCHEMAS", _schemas_csv)
            _ok(f"Public schemas: {_schemas_csv}")
        else:
            # Explicit empty — clear any stale env var so server.py
            # doesn't bleed publicSchemas from a previous run.
            env.set("PUBLIC_SCHEMAS", "")
            _ok("Public schemas: (none — login-first app)")
    else:
        _header("Step 3 · Skipped (no web UI)")
        _info("No ui/app.js found, skipping CDN downloads")


    # ── Step 3.5: Docs + Docker files ──
    _header("Step 3.5 · Documentation & deployment files")
    _meta35 = _read_app_meta(app_dir)
    _docs_app_name = env.get("APP_NAME") or _meta35.get("name") or env.get(
        "SUPERO_DOMAIN", "Supero App"
    ).replace("-", " ").title()
    _ensure_docs_files(app_dir, env, app_name=_docs_app_name)
    _ensure_docker_files(app_dir, env, app_name=_docs_app_name)

    # ── Step 4: Run setup.py ──
    if not args.server_only:
        _header("Step 4 · Running platform setup")
        _info("This registers the domain, uploads schemas, configures services...")
        logger.info("Starting setup.py")
        print()

        setup_cmd = [sys.executable, "setup.py"]
        if args.no_seed:
            setup_cmd.append("--no-seed")

        setup_start = time.time()

        if args.verbose:
            result = subprocess.run(setup_cmd, cwd=app_dir)
        else:
            result = subprocess.run(
                setup_cmd, cwd=app_dir,
                capture_output=True, text=True
            )
            # Log full output
            if result.stdout:
                logger.info("setup.py stdout:\n" + result.stdout)
            if result.stderr:
                logger.warning("setup.py stderr:\n" + result.stderr)

            # Show meaningful lines to console
            if result.stdout:
                for line in result.stdout.splitlines():
                    stripped = line.strip()
                    if any(k in stripped for k in ("✅", "✓", "⚠", "❌", "Error",
                                                    "created", "skipped", "failed",
                                                    "uploaded", "registered", "logged",
                                                    "ready", "API key")):
                        print(f"  {stripped}")

        setup_elapsed = time.time() - setup_start
        logger.info(f"setup.py completed in {setup_elapsed:.1f}s (exit={result.returncode})")

        if result.returncode != 0:
            print()
            _fail(f"Setup failed (exit code {result.returncode}, {setup_elapsed:.1f}s)")
            if not args.verbose:
                if result.stderr:
                    print(f"\n{_C.DIM}Error output (last 20 lines):{_C.RESET}")
                    for line in result.stderr.strip().splitlines()[-20:]:
                        print(f"  {line}")
                print()
                _info(f"Full logs: {LOG_FILE}")
                _info("Tip: run with --verbose for full output")
                _info("Tip: run with --reset to clear config and retry")
            sys.exit(1)

        print()
        _ok(f"Platform setup complete ({setup_elapsed:.1f}s)")

        # ── Report tenant SDK after setup (may have been installed) ──
        post_versions = _detect_versions()
        if post_versions["tenant_sdks"]:
            for sdk in post_versions["tenant_sdks"]:
                _ok(f"Tenant SDK: {sdk['name']} v{sdk['version']}")
                logger.info(f"Post-setup tenant SDK: {sdk['name']} v{sdk['version']}")
    else:
        _header("Step 4 · Skipped (--server-only)")

    # ── Reload .env after setup ──
    env.reload()

    # Sync ALL .env values into os.environ — always override
    for _k, _v in env.values.items():
        if _k and _v:
            os.environ[_k] = _v

    # ── Regenerate config.js after setup ──
    if project["has_web"]:
        ui_dir = os.path.join(ui_base, "ui")
        meta = _read_app_meta(app_dir)
        _public2 = meta.get("public_schemas", [])
        _is_multi = _fetch_is_multi_tenant(env)
        _tn_sing2 = env.get("SUPERO_TENANT_NOUN_SINGULAR", "Workspace") or "Workspace"
        _tn_plur2 = env.get("SUPERO_TENANT_NOUN_PLURAL", "Workspaces") or "Workspaces"
        env.generate_config_js(
            ui_dir,
            app_name=meta["name"],
            app_emoji=meta["emoji"],
            app_description=meta["description"],
            public_schemas=_public2,
            is_multi_tenant=_is_multi,
            tenant_noun_singular=_tn_sing2,
            tenant_noun_plural=_tn_plur2,
            app_namespace=_resolved_app_ns,
        )
        if _is_multi:
            _ok("Multi-tenant mode: enabled (signup modals will render)")
        # Symmetric with the first call site (Step 3): set or clear
        # PUBLIC_SCHEMAS env var explicitly. Empty list is a deliberate
        # signal and must clear stale env values, not leave them in place.
        if _public2:
            _csv2 = ",".join(_public2)
            env.set("PUBLIC_SCHEMAS", _csv2)
            os.environ["PUBLIC_SCHEMAS"] = _csv2
        else:
            env.set("PUBLIC_SCHEMAS", "")
            os.environ.pop("PUBLIC_SCHEMAS", None)

    # ── Step 4.5: CRUD smoke tests ──
    if not args.server_only and not getattr(args, 'skip_tests', False):
        _ensure_crud_tests(app_dir)
        _ensure_e2e_tests(app_dir)
        _ensure_workflow_tests(app_dir)
    _crud_tests_path = os.path.join(app_dir, "crud_tests.py")
    if (not args.server_only
            and not getattr(args, 'skip_tests', False)
            and os.path.exists(_crud_tests_path)):
        _header("Step 4.5 · CRUD smoke tests")
        _info("Testing Create, Read, List, Update, Delete on all schemas...")
        print()
        _test_start = time.time()
        if args.verbose:
            _test_result = subprocess.run(
                [sys.executable, "crud_tests.py"], cwd=app_dir
            )
        else:
            _test_result = subprocess.run(
                [sys.executable, "crud_tests.py"], cwd=app_dir,
                capture_output=True, text=True,
            )
            if _test_result.stdout:
                logger.info("crud_tests.py stdout:\n" + _test_result.stdout)
                for _line in _test_result.stdout.splitlines():
                    _s = _line.strip()
                    if _s:
                        print(f"  {_s}")
                    else:
                        print()
            if _test_result.stderr:
                logger.warning("crud_tests.py stderr:\n" + _test_result.stderr)
        _test_elapsed = time.time() - _test_start
        if _test_result.returncode == 2:
            # Infra/config issue (bad API key, domain unreachable, env var missing)
            # Not a test failure — warn and continue to server launch
            print()
            _warn(f"CRUD smoke tests SKIPPED ({_test_elapsed:.1f}s) — infrastructure issue (see above)")
            _info("Check SUPERO_API_KEY and SUPERO_DOMAIN in .env, then re-run to validate")
            _info(f"Full logs: {LOG_FILE}")
        elif _test_result.returncode != 0:
            # Tests ran but one or more failed — warn prominently, continue to server
            print()
            _warn(f"CRUD smoke tests FAILED ({_test_elapsed:.1f}s) — server launching anyway")
            _fail("One or more CRUD operations failed (see above for details)")
            _info("Fix the failing schemas or use --skip-tests to suppress this warning")
            _info(f"Full logs: {LOG_FILE}")
            print()
        else:
            _ok(f"All CRUD smoke tests passed ({_test_elapsed:.1f}s)")

    # ── Mobile setup (optional) ──
    if args.mobile:
        if project.get("has_mobile"):
            _header("Mobile · Setting up Expo app")
            mobile_dir = os.path.join(os.getcwd(), "mobile")
            expo_sh = os.path.join(mobile_dir, "expo.sh")

            # Bootstrap from CDN if missing  # RUN_PY_MOBILE_DOWNLOAD_V1_APPLIED
            if not os.path.exists(expo_sh):
                _info("expo.sh missing — extracting from SDK wheel")
                try:
                    # REPLACED-BY-3.5.0: was _cdn_mobile.download_mobile_bootstrap()
                    extract_to_project(
                        os.getcwd(),
                        items=[
                            'supero.install:scripts/expo.sh',
                            'supero.ui:supero-mobile.jsx',
                        ],
                    )
                except Exception as _ex:
                    _warn(f"Could not extract mobile artifacts from wheel: {_ex}")
            if os.path.exists(expo_sh):
                # RUN_PY_NODE_AUTOINSTALL_V1_APPLIED — ensure Node >= 18 before running expo.sh
                _mobile_env = _ensure_node_for_mobile(verbose=args.verbose, logger=logger)
                subprocess.run(
                    ["bash", expo_sh, "setup"], cwd=mobile_dir, env=_mobile_env
                )
                _ok("Mobile app ready")
                _info("Start with: cd mobile && ./expo.sh start")
            else:
                _warn("mobile/expo.sh not found")
        else:
            _warn("No mobile app found — skipping")
    # SUPERO-FINGERPRINT-CAPTURE-V1: capture platform state now that
    # setup uploads are complete. Best-effort — never blocks server start.
    try:
        _capture_setup_state(env, logger=logger)
    except Exception as _fp_err:
        logger.warning(f"fingerprint capture wrapper error: {_fp_err}")

    # ── Step 5: Start server ──
    if not args.setup_only:
        # BAKE_UI_SCHEMAS_V1 — refresh ui/supero-schemas.js before serve
        try:
            _bake_ui_schemas(app_dir, verbose=args.verbose)
        except Exception as _bake_e:
            print(f"  ⚠ UI schemas bake failed: {_bake_e} — continuing",
                  file=sys.stderr)
        # /BAKE_UI_SCHEMAS_V1

        port = args.port or int(env.get("PORT", env.get("UI_PORT", "5648")))

        if not args.docker and not args.server_only and not args.no_interactive:
            launch_mode = _prompt_launch_mode()
            if launch_mode == "docker":
                args.docker = True
            elif launch_mode == "setup":
                _ok("Setup complete! Run ./run.sh to start the server.")
                sys.exit(0)

        if args.docker:
            _header("Step 5 · Starting with Docker")
            meta = _read_app_meta(app_dir)

            if not os.path.exists(os.path.join(os.getcwd(), ".env")):
                env.save()
                _ok("Created .env for Docker")

            print()
            _info("Building and starting container...")
            _info("This may take a few minutes on first build.")
            print()

            try:
                result = subprocess.run(
                    ["docker", "compose", "up", "--build", "-d"],
                    capture_output=not args.verbose, text=True
                )
                if result.returncode == 0:
                    lan_ip = _get_lan_ip()
                    print()
                    print(f"  {_C.GREEN}{_C.BOLD}✅ CONTAINER RUNNING{_C.RESET}")
                    print()
                    print(f"  {_C.CYAN}Local:{_C.RESET}    http://localhost:{port}")
                    if lan_ip != "0.0.0.0":
                        print(f"  {_C.CYAN}Network:{_C.RESET}  http://{lan_ip}:{port}")
                    print()
                    print(f"  {_C.DIM}View logs:   docker compose logs -f{_C.RESET}")
                    print(f"  {_C.DIM}Stop:        docker compose down{_C.RESET}")
                    print()
                else:
                    _fail("Docker build failed")
                    if not args.verbose and result.stderr:
                        for line in result.stderr.strip().splitlines()[-10:]:
                            print(f"  {line}")
                    _info("Try: docker compose up --build (without -d) for full output")
            except FileNotFoundError:
                _fail("Docker not found. Install: https://docs.docker.com/get-docker/")
                sys.exit(1)

        elif project["has_web"]:
            _header("Step 5 · Starting web server")

            ui_dir = os.path.join(ui_base, "ui")
            server_py = os.path.join(ui_dir, "server.py")

            if not os.path.exists(server_py):
                _fail(f"server.py not found in {ui_dir}")
                sys.exit(1)

            # Check port availability — offer alternatives if busy
            port = _resolve_port(
                port,
                interactive=not args.no_interactive,
            )

            lan_ip = _get_lan_ip()
            admin_email = env.get("SUPERO_ADMIN_EMAIL", "admin@example.com")
            domain = env.get("SUPERO_DOMAIN", "")

            print()
            print(f"  {_C.GREEN}{_C.BOLD}✅ READY{_C.RESET}")
            print()
            print(f"  ┌──────────────────────────────────────────────┐")
            print(f"  │                                              │")
            print(f"  │  {_C.CYAN}Local:{_C.RESET}    http://localhost:{str(port):<17}│")
            if lan_ip != "0.0.0.0":
                print(f"  │  {_C.CYAN}Network:{_C.RESET}  http://{lan_ip}:{str(port):<11}│")
            print(f"  │                                              │")
            if domain:
                print(f"  │  {_C.CYAN}Domain:{_C.RESET}   {domain:<28s}│")
            print(f"  │  {_C.CYAN}Login:{_C.RESET}    {admin_email:<28s}│")
            print(f"  │                                              │")
            print(f"  └──────────────────────────────────────────────┘")
            print()
            print(f"  {_C.DIM}Docs:      README.md  ·  CLAUDE.md (for AI assistants){_C.RESET}")
            print(f"  {_C.DIM}Deploy:    Dockerfile  ·  docker-compose.yml{_C.RESET}")
            print(f"  {_C.DIM}Logs:      .supero-run.log{_C.RESET}")
            print(f"  {_C.DIM}Stop:      Ctrl+C{_C.RESET}")
            print()

            # Update .env if port changed (e.g. busy port fallback)
            orig_port = int(env.get("PORT", env.get("UI_PORT", "5648")))
            if port != orig_port:
                _update_port_in_env(env, port)

            os.environ["PORT"] = str(port)
            os.environ["UI_PORT"] = str(port)

            logger.info(f"Starting server on port {port}")

            # RUN_PY_MOBILE_REORDER_V1_APPLIED
            # If --mobile is set, run the web server in the background so
            # the user can start Expo (`cd mobile && ./expo.sh start`) in
            # the same shell. Otherwise keep blocking behavior.
            if getattr(args, "mobile", False):
                global _BG_SERVER_PROC
                _BG_SERVER_PROC = subprocess.Popen(
                    [sys.executable, "server.py"], cwd=ui_dir
                )
                logger.info(
                    f"Server started in background (PID {_BG_SERVER_PROC.pid}) for --mobile"
                )
                print()
                print(f"  {_C.GREEN}Web server running in background (PID {_BG_SERVER_PROC.pid}){_C.RESET}")
                print(f"  {_C.DIM}It will be stopped automatically when this script exits.{_C.RESET}")
                print()
                print(f"  {_C.CYAN}Next:{_C.RESET} cd mobile && ./expo.sh start")
                print()
            else:
                try:
                    subprocess.run([sys.executable, "server.py"], cwd=ui_dir)
                except KeyboardInterrupt:
                    print(f"\n  {_C.DIM}Server stopped.{_C.RESET}")
                    logger.info("Server stopped by user (Ctrl+C)")
        else:
            _ok("Setup complete (no web UI to start)")
    else:
        _header("Step 5 · Skipped (--setup-only)")
        _ok("Setup complete. Run without --setup-only to start the server.")

    logger.info("=== supero.cli finished ===")


if __name__ == "__main__":
    main()
