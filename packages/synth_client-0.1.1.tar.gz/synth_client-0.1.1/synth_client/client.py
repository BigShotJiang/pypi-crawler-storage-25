"""Root client object for the Synth SDK."""

from __future__ import annotations

from collections.abc import Mapping
from typing import IO

import httpx

from synth_client.augmentations import AugmentationsNamespace
from synth_client.exceptions import NotFoundError, SynthClientError
from synth_client.images import ImagesNamespace
from synth_client.pipeline import AugmentationPipeline
from synth_client.schemas import CollectionInfo, StatsInfo

DEFAULT_BASE_URL = "http://localhost:8000"
DEFAULT_COLLECTION = "images"


class SynthClient:
    """High-level SDK client for the Synth API."""

    def __init__(
        self,
        *,
        base_url: str = DEFAULT_BASE_URL,
        collection: str = DEFAULT_COLLECTION,
        api_key: str | None = None,
        timeout: float = 30.0,
        http_client: httpx.Client | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.collection = collection
        self._api_key = api_key
        self._owns_client = http_client is None
        self._client = http_client or httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            follow_redirects=True,
        )
        self.images = ImagesNamespace(self)
        self.augmentations = AugmentationsNamespace(self)

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> SynthClient:
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def pipeline(self, *, collection: str | None = None) -> AugmentationPipeline:
        return AugmentationPipeline(self, collection=collection or self.collection)

    def list_collections(self) -> list[CollectionInfo]:
        response = self._request("GET", "/api/collections")
        return [CollectionInfo.model_validate(item) for item in response.json()["collections"]]

    def create_collection(self, name: str) -> str:
        response = self._request("POST", "/api/collections", json={"name": name})
        return str(response.json()["message"])

    def delete_collection(self, name: str) -> None:
        self._request("DELETE", f"/api/collections/{name}")

    def get_stats(self, *, collection: str | None = None) -> StatsInfo:
        response = self._request("GET", "/api/stats", params=self._collection_params(collection))
        return StatsInfo.model_validate(response.json())

    def _collection_params(self, collection: str | None) -> dict[str, str]:
        return {"collection": collection or self.collection}

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None = None,
        json: dict[str, object] | None = None,
        files: Mapping[str, tuple[str, IO[bytes], str]] | None = None,
    ) -> httpx.Response:
        headers: dict[str, str] = {}
        if self._api_key is not None:
            headers["Authorization"] = f"Bearer {self._api_key}"
        try:
            response = self._client.request(
                method, path, params=params, json=json, files=files, headers=headers
            )
            response.raise_for_status()
            return response
        except httpx.HTTPStatusError as exc:
            detail = self._extract_error_message(exc.response)
            if exc.response.status_code == 404:
                raise NotFoundError(
                    detail,
                    status_code=404,
                    response_body=exc.response.text,
                ) from exc
            raise SynthClientError(
                detail,
                status_code=exc.response.status_code,
                response_body=exc.response.text,
            ) from exc
        except httpx.HTTPError as exc:
            raise SynthClientError(str(exc)) from exc

    @staticmethod
    def _extract_error_message(response: httpx.Response) -> str:
        try:
            payload = response.json()
        except ValueError:
            payload = None
        if isinstance(payload, dict) and payload.get("detail"):
            return str(payload["detail"])
        return f"HTTP {response.status_code}: {response.text}"


Synth = SynthClient
