"""Augmentation and suggestion API namespace."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

from synth_client.annotations import AnnotationStrategy
from synth_client.exceptions import TaskFailedError
from synth_client.prompt import Prompt
from synth_client.schemas import (
    AugmentationResult,
    AugmentationSuggestion,
    AugmentationTask,
    GenerationParams,
)

if TYPE_CHECKING:
    from synth_client.client import SynthClient


class AugmentationsNamespace:
    """Operations under `/api/suggests` and `/api/tasks`."""

    def __init__(self, client: SynthClient) -> None:
        self._client = client

    def suggest(
        self, image_id: str, *, collection: str | None = None
    ) -> list[AugmentationSuggestion]:
        response = self._client._request(
            "GET",
            f"/api/suggests/augmentations/{image_id}",
            params=self._client._collection_params(collection),
        )
        return [
            AugmentationSuggestion.model_validate(item)
            for item in response.json().get("suggestions", [])
        ]

    def start(
        self,
        *,
        image_id: str,
        suggestions: list[AugmentationSuggestion],
        target_image_id: str | None = None,
        collection_name: str | None = None,
        generation_params: GenerationParams | None = None,
        copy_annotations: bool = True,
    ) -> AugmentationTask:
        payload: dict[str, object] = {
            "image_id": image_id,
            "suggestions": [item.model_dump() for item in suggestions],
        }
        if target_image_id is not None:
            payload["target_image_id"] = target_image_id
        if collection_name is not None:
            payload["collection_name"] = collection_name
        if generation_params is not None:
            payload["generation_params"] = generation_params.model_dump()
        payload["copy_annotations"] = copy_annotations
        response = self._client._request("POST", "/api/tasks/augmentations", json=payload)
        return AugmentationTask.model_validate(response.json())

    def start_from_prompts(
        self,
        *,
        image_id: str,
        prompts: list[str],
        categories: list[str] | None = None,
        target_image_id: str | None = None,
        collection_name: str | None = None,
        generation_params: GenerationParams | None = None,
        copy_annotations: bool = True,
    ) -> AugmentationTask:
        if categories is None:
            categories = ["custom"] * len(prompts)
        suggestions = [
            AugmentationSuggestion(prompt=prompt, category=category)
            for prompt, category in zip(prompts, categories, strict=True)
        ]
        return self.start(
            image_id=image_id,
            suggestions=suggestions,
            target_image_id=target_image_id,
            collection_name=collection_name,
            generation_params=generation_params,
            copy_annotations=copy_annotations,
        )

    def start_tree(
        self,
        *,
        root_image_id: str,
        epochs: int,
        suggestions_per_node: int = 5,
        collection_name: str | None = None,
        generation_params: GenerationParams | None = None,
    ) -> AugmentationTask:
        payload: dict[str, object] = {
            "root_image_id": root_image_id,
            "epochs": epochs,
            "suggestions_per_node": suggestions_per_node,
        }
        if collection_name is not None:
            payload["collection_name"] = collection_name
        if generation_params is not None:
            payload["generation_params"] = generation_params.model_dump()
        response = self._client._request("POST", "/api/tasks/augmentation-tree", json=payload)
        return AugmentationTask.model_validate(response.json())

    def run(
        self,
        *,
        image_id: str,
        prompt: str | Prompt,
        annotation_strategy: AnnotationStrategy = AnnotationStrategy.DISCARD,
        collection_name: str | None = None,
        generation_params: GenerationParams | None = None,
        poll_interval: float = 2.0,
        timeout: float | None = 120.0,
    ) -> AugmentationResult:
        """Start an augmentation and block until it completes.

        Args:
            image_id: Source image ID to augment.
            prompt: A text prompt string or a ``Prompt`` object. String prompts
                are wrapped in a single ``AugmentationSuggestion`` with
                ``category="custom"``.
            annotation_strategy: How to handle annotations on resulting images.
                Only ``DISCARD`` is currently supported; others raise
                ``NotImplementedError``.
            collection_name: Override the client's default collection.
            generation_params: Override default generation quality settings.
            poll_interval: Seconds between status poll requests.
            timeout: Maximum seconds to wait before raising ``TimeoutError``.
                Pass ``None`` to wait indefinitely.

        Returns:
            The completed ``AugmentationResult``.

        Raises:
            NotImplementedError: If ``annotation_strategy`` is not ``DISCARD``.
            TaskFailedError: If the task finishes with status ``failed`` or
                ``cancelled``.
            TimeoutError: If the task does not complete within ``timeout``
                seconds.
        """
        if annotation_strategy != AnnotationStrategy.DISCARD:
            raise NotImplementedError(
                f"{annotation_strategy!r} requires additional parameters. "
                "Use start() + wait() for custom annotation handling."
            )
        if isinstance(prompt, str):
            suggestions = [AugmentationSuggestion(prompt=prompt, category="custom")]
        else:
            suggestions = prompt.to_suggestions()
        task = self.start(
            image_id=image_id,
            suggestions=suggestions,
            collection_name=collection_name,
            generation_params=generation_params,
            copy_annotations=False,
        )
        return self.wait(task.task_id, poll_interval=poll_interval, timeout=timeout)

    def status(self, task_id: str) -> AugmentationTask:
        response = self._client._request("GET", f"/api/tasks/{task_id}")
        return AugmentationTask.model_validate(response.json())

    def cancel(self, task_id: str) -> dict[str, str]:
        response = self._client._request("DELETE", f"/api/tasks/{task_id}")
        body = response.json()
        return {"status": str(body["status"]), "message": str(body["message"])}

    def wait(
        self,
        task_id: str,
        *,
        poll_interval: float = 2.0,
        timeout: float | None = None,
    ) -> AugmentationResult:
        started_at = time.monotonic()
        while True:
            task = self.status(task_id)
            if task.status == "completed":
                raw_result: dict[str, object] = task.result or {}
                raw_ids = raw_result.get("image_ids")
                image_ids = [str(item) for item in raw_ids] if isinstance(raw_ids, list) else []
                raw_total = raw_result.get("total")
                total = raw_total if isinstance(raw_total, int) else len(image_ids)
                return AugmentationResult(
                    task_id=task.task_id,
                    status=task.status,
                    image_ids=image_ids,
                    total=total,
                    raw_result=raw_result,
                )
            if task.status in {"failed", "cancelled"}:
                raise TaskFailedError(task.task_id, task.status, task.error or "unknown error")
            if timeout is not None and time.monotonic() - started_at >= timeout:
                raise TimeoutError(f"Task {task_id} did not finish within {timeout} seconds")
            time.sleep(poll_interval)
