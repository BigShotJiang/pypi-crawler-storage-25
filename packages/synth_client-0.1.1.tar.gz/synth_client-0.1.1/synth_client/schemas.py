"""Pydantic DTOs used by the Synth SDK."""

from __future__ import annotations

from pydantic import BaseModel, Field


class BoundingBox(BaseModel):
    """Single detected object with bounding box coordinates."""

    label: str
    x_min: int
    y_min: int
    x_max: int
    y_max: int
    polygon: list[list[int]] | None = None


class ImageDTO(BaseModel):
    """Image record returned by the Synth API."""

    id: str
    name: str
    description: str | None = None
    s3_url: str
    media_type: str | None = None
    mime_type: str | None = None
    parent_id: str | None = None
    augmentation_prompt: str | None = None
    augmentation_category: str | None = None
    video_width: int | None = None
    video_height: int | None = None
    frame_count: int | None = None
    fps: float | None = None
    duration_sec: float | None = None
    annotations: list[BoundingBox] = Field(default_factory=list)
    score: float | None = None


class CollectionPreviewDTO(BaseModel):
    """Preview item for a collection."""

    url: str
    media_type: str


class CollectionInfo(BaseModel):
    """Collection summary."""

    name: str
    points_count: int
    previews: list[CollectionPreviewDTO] = Field(default_factory=list)


class StatsInfo(BaseModel):
    """Aggregate storage statistics."""

    collections: int
    images: int
    augmentations: int
    descriptions: int


class AugmentationSuggestion(BaseModel):
    """Suggested augmentation prompt."""

    prompt: str
    category: str


class GenerationParams(BaseModel):
    """Parameters controlling generation quality and speed."""

    num_inference_steps: int = Field(default=20, ge=1, le=100)
    true_cfg_scale: float = Field(default=4.0, ge=1.0, le=10.0)
    guidance_scale: float = Field(default=1.0, ge=0.1, le=5.0)


class AugmentationTask(BaseModel):
    """Async task status payload."""

    task_id: str
    status: str
    message: str | None = None
    progress: dict[str, int] = Field(default_factory=dict)
    result: dict[str, object] | None = None
    error: str | None = None


class AugmentationResult(BaseModel):
    """Normalized async augmentation result."""

    task_id: str
    status: str
    image_ids: list[str] = Field(default_factory=list)
    total: int = 0
    error: str | None = None
    raw_result: dict[str, object] | None = None
