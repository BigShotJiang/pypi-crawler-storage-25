"""Client-specific exception types."""


class SynthClientError(Exception):
    """Base SDK error raised for HTTP and transport failures."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        response_body: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class NotFoundError(SynthClientError):
    """Raised when the API returns 404 Not Found."""


class TaskFailedError(SynthClientError):
    """Raised when an asynchronous augmentation task finishes unsuccessfully."""

    def __init__(self, task_id: str, status: str, message: str) -> None:
        super().__init__(f"Task {task_id} {status}: {message}")
        self.task_id = task_id
        self.status = status
