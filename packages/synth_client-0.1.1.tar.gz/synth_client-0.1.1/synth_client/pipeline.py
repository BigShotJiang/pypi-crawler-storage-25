"""High-level dataset and augmentation pipeline helpers."""

from __future__ import annotations

from collections.abc import Iterator
from typing import TYPE_CHECKING

from pydantic import BaseModel, Field

from synth_client.schemas import AugmentationResult, GenerationParams, ImageDTO

if TYPE_CHECKING:
    from synth_client.client import SynthClient


class SynthDataset(BaseModel):
    """A lightweight wrapper around a list of Synth images."""

    images: list[ImageDTO] = Field(default_factory=list)

    def __iter__(self) -> Iterator[ImageDTO]:
        return iter(self.images)

    def __len__(self) -> int:
        return len(self.images)

    @property
    def ids(self) -> list[str]:
        return [image.id for image in self.images]


class AugmentationPipeline:
    """Sequential helper for running augmentation tasks over a dataset."""

    def __init__(self, client: SynthClient, *, collection: str | None = None) -> None:
        self._client = client
        self._collection = collection

    def dataset_from_query(self, query: str, *, limit: int = 50) -> SynthDataset:
        images = self._client.images.search(
            query=query,
            limit=limit,
            collection=self._collection,
        )
        return SynthDataset(images=images)

    def run(
        self,
        dataset: SynthDataset,
        *,
        prompts: list[str],
        categories: list[str] | None = None,
        generation_params: GenerationParams | None = None,
        poll_interval: float = 2.0,
        timeout: float | None = None,
    ) -> list[AugmentationResult]:
        results: list[AugmentationResult] = []
        for image in dataset:
            task = self._client.augmentations.start_from_prompts(
                image_id=image.id,
                prompts=prompts,
                categories=categories,
                collection_name=self._collection,
                generation_params=generation_params,
            )
            results.append(
                self._client.augmentations.wait(
                    task.task_id,
                    poll_interval=poll_interval,
                    timeout=timeout,
                )
            )
        return results
