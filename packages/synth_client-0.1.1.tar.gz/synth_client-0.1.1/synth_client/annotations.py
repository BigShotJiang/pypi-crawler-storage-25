"""Annotation helpers exposed by the SDK."""

from __future__ import annotations

from collections.abc import Callable
from enum import StrEnum
from typing import TYPE_CHECKING

from synth_client.schemas import BoundingBox

if TYPE_CHECKING:
    from synth_client.images import ImagesNamespace


class AnnotationStrategy(StrEnum):
    """Supported annotation flows."""

    DISCARD = "discard"
    MANUAL = "manual"
    DETECT = "detect"


def _manual_handler(
    _images: ImagesNamespace,
    *,
    annotations: list[BoundingBox],
    **_: object,
) -> list[BoundingBox]:
    return annotations


def _detect_handler(
    images: ImagesNamespace,
    *,
    image_id: str,
    prompt: str,
    collection: str | None = None,
    **_: object,
) -> list[BoundingBox]:
    return images.detect_objects(image_id=image_id, prompt=prompt, collection=collection)


ANNOTATION_HANDLERS: dict[AnnotationStrategy, Callable[..., list[BoundingBox]]] = {
    AnnotationStrategy.MANUAL: _manual_handler,
    AnnotationStrategy.DETECT: _detect_handler,
}
