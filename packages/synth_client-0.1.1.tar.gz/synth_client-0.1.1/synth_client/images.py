"""Image-related API namespace."""

from __future__ import annotations

import io
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from synth_client.schemas import BoundingBox, ImageDTO

if TYPE_CHECKING:
    from PIL.Image import Image as PILImage

    from synth_client.client import SynthClient


class ImagesNamespace:
    """Operations under `/api/images`."""

    def __init__(self, client: SynthClient) -> None:
        self._client = client

    def list(
        self,
        *,
        limit: int = 100,
        offset: int = 0,
        collection: str | None = None,
    ) -> list[ImageDTO]:
        response = self._client._request(
            "GET",
            "/api/images",
            params={
                **self._client._collection_params(collection),
                "limit": str(limit),
                "offset": str(offset),
            },
        )
        return [ImageDTO.model_validate(item) for item in response.json()["images"]]

    def get(self, image_id: str, *, collection: str | None = None) -> ImageDTO:
        response = self._client._request(
            "GET",
            f"/api/images/{image_id}",
            params=self._client._collection_params(collection),
        )
        return ImageDTO.model_validate(response.json())

    def search(
        self,
        *,
        query: str | None = None,
        image_id: str | None = None,
        limit: int = 50,
        collection: str | None = None,
    ) -> list[ImageDTO]:
        payload: dict[str, object] = {"limit": limit}
        if query is not None:
            payload["query"] = query
        if image_id is not None:
            payload["image_id"] = image_id
        response = self._client._request(
            "POST",
            "/api/images/search",
            params=self._client._collection_params(collection),
            json=payload,
        )
        return [ImageDTO.model_validate(item) for item in response.json()["images"]]

    def upload(
        self,
        source: str | Path | PILImage,
        *,
        collection: str | None = None,
    ) -> ImageDTO:
        """Upload an image from a file path or a PIL Image.

        Args:
            source: A file path (``str`` or ``Path``) or a ``PIL.Image.Image`` object.
            collection: Override the client's default collection.

        Returns:
            The uploaded image record.

        Raises:
            TypeError: If ``source`` is a PIL-like object but ``pillow`` is not installed.
        """
        if isinstance(source, (str, Path)):
            path = Path(source)
            with path.open("rb") as file_obj:
                response = self._client._request(
                    "POST",
                    "/api/images",
                    params=self._client._collection_params(collection),
                    files={"file": (path.name, file_obj, "application/octet-stream")},
                )
        else:
            try:
                from PIL.Image import Image as _PILImage  # noqa: PLC0415
            except ImportError as exc:
                raise TypeError(
                    "source is not a str or Path. Install pillow to enable PIL.Image.Image support."
                ) from exc
            if not isinstance(source, _PILImage):
                raise TypeError(
                    f"Unsupported source type: {type(source)!r}. "
                    "Expected str, Path, or PIL.Image.Image."
                )
            buf = io.BytesIO()
            source.save(buf, format="PNG")
            buf.seek(0)
            response = self._client._request(
                "POST",
                "/api/images",
                params=self._client._collection_params(collection),
                files={"file": ("image.png", buf, "image/png")},
            )
        return ImageDTO.model_validate(response.json())

    def delete(self, image_id: str, *, collection: str | None = None) -> None:
        self._client._request(
            "DELETE",
            f"/api/images/{image_id}",
            params=self._client._collection_params(collection),
        )

    def describe(self, image_id: str, *, collection: str | None = None) -> str:
        response = self._client._request(
            "POST",
            f"/api/images/{image_id}/description",
            params=self._client._collection_params(collection),
        )
        return str(response.json()["description"])

    def _build_annotation_request(
        self,
        *,
        mode: Literal["detect", "segment"],
        prompt: str,
        image_id: str | None = None,
        image_url: str | None = None,
        collection: str | None = None,
    ) -> tuple[str, dict[str, str], dict[str, str]]:
        if bool(image_id) == bool(image_url):
            raise ValueError("Pass exactly one of image_id or image_url")

        params = self._client._collection_params(collection)

        if image_id is not None:
            return (
                f"/api/images/{image_id}/annotations/{mode}",
                params,
                {"prompt": prompt},
            )

        params["image-url"] = image_url or ""
        return (
            f"/api/images/annotations/{mode}",
            params,
            {"prompt": prompt},
        )

    def detect_objects(
        self,
        image_id: str | None = None,
        *,
        prompt: str,
        image_url: str | None = None,
        collection: str | None = None,
    ) -> list[BoundingBox]:
        path, params, payload = self._build_annotation_request(
            mode="detect",
            prompt=prompt,
            image_id=image_id,
            image_url=image_url,
            collection=collection,
        )
        response = self._client._request(
            "POST",
            path,
            params=params,
            json=payload,
        )
        return [BoundingBox.model_validate(item) for item in response.json().get("detections", [])]

    def segment_objects(
        self,
        image_id: str | None = None,
        *,
        prompt: str,
        image_url: str | None = None,
        collection: str | None = None,
    ) -> list[BoundingBox]:
        path, params, payload = self._build_annotation_request(
            mode="segment",
            prompt=prompt,
            image_id=image_id,
            image_url=image_url,
            collection=collection,
        )
        response = self._client._request(
            "POST",
            path,
            params=params,
            json=payload,
        )
        return [BoundingBox.model_validate(item) for item in response.json().get("detections", [])]

    def update_annotations(
        self,
        image_id: str,
        annotations: list[BoundingBox],
        *,
        collection: str | None = None,
    ) -> ImageDTO:
        response = self._client._request(
            "PUT",
            f"/api/images/{image_id}/annotations",
            params=self._client._collection_params(collection),
            json={"annotations": [item.model_dump() for item in annotations]},
        )
        return ImageDTO.model_validate(response.json())

    def update_description(
        self,
        image_id: str,
        description: str,
        *,
        collection: str | None = None,
    ) -> ImageDTO:
        response = self._client._request(
            "PUT",
            f"/api/images/{image_id}/description",
            params=self._client._collection_params(collection),
            json={"description": description},
        )
        return ImageDTO.model_validate(response.json())
