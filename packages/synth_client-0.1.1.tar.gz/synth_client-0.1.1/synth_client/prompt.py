"""Composable augmentation prompt with sequential and random-choice combinators."""

from __future__ import annotations

import random

from synth_client.schemas import AugmentationSuggestion


class Prompt:
    """Composable augmentation prompt.

    Supports sequential composition with ``+`` (apply all) and random choice
    with ``|`` (apply one at resolution time).

    Internally stores a list of "branches". Each branch is a list of
    ``AugmentationSuggestion`` to apply sequentially. ``to_suggestions()``
    randomly picks one branch, so:

    - Single branch (leaf or ``+`` result) → deterministic output.
    - Multiple branches (``|`` result) → random output on each call.

    ``+`` applies cross-product over branches, so ``(a | b) + c`` resolves
    to either ``[a, c]`` or ``[b, c]`` with equal probability.

    Examples:
        >>> winter = Prompt("make it winter")
        >>> fog = Prompt("add fog")
        >>> (winter + fog).to_suggestions()  # both applied
        >>> (winter | fog).to_suggestions()  # one randomly chosen
        >>> Prompt.batch(["p1", "p2"]).to_suggestions()  # both applied
    """

    def __init__(self, text: str, category: str = "custom") -> None:
        """Create a leaf prompt from a single text string.

        Args:
            text: The augmentation instruction.
            category: Semantic category label for the suggestion.
        """
        self._branches: list[list[AugmentationSuggestion]] = [
            [AugmentationSuggestion(prompt=text, category=category)]
        ]

    @classmethod
    def _from_branches(cls, branches: list[list[AugmentationSuggestion]]) -> Prompt:
        """Internal factory that constructs a Prompt from pre-built branches."""
        instance = cls.__new__(cls)
        instance._branches = branches
        return instance

    def __add__(self, other: Prompt) -> Prompt:
        """Sequential composition: apply all suggestions from both prompts.

        Args:
            other: The prompt to append after this one.

        Returns:
            A new ``Prompt`` whose suggestions are the concatenation of both.
        """
        branches = [left + right for left in self._branches for right in other._branches]
        return Prompt._from_branches(branches)

    def __or__(self, other: Prompt) -> Prompt:
        """Random-choice composition: apply one of the two prompts.

        The choice is deferred until ``to_suggestions()`` is called.

        Args:
            other: The alternative prompt.

        Returns:
            A new ``Prompt`` that randomly selects between the two on resolution.
        """
        return Prompt._from_branches(self._branches + other._branches)

    @classmethod
    def batch(cls, prompts: list[str], *, category: str = "custom") -> Prompt:
        """Create a sequential prompt from multiple strings.

        All prompts are applied together as a single sequential suggestion list.

        Args:
            prompts: List of augmentation instruction strings.
            category: Shared category label for all suggestions.

        Returns:
            A ``Prompt`` whose ``to_suggestions()`` returns one entry per string.
        """
        suggestions = [AugmentationSuggestion(prompt=text, category=category) for text in prompts]
        return cls._from_branches([suggestions])

    def to_suggestions(self) -> list[AugmentationSuggestion]:
        """Resolve the prompt to a concrete list of suggestions.

        For prompts built with ``|``, one branch is selected at random on each
        call, so successive calls may return different results.

        Returns:
            A list of ``AugmentationSuggestion`` ready to pass to the API.
        """
        return list(random.choice(self._branches))
