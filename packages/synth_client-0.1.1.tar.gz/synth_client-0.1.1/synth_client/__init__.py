"""Public SDK exports for synth-client."""

from synth_client.annotations import ANNOTATION_HANDLERS, AnnotationStrategy
from synth_client.augmentations import AugmentationsNamespace
from synth_client.client import Synth, SynthClient
from synth_client.exceptions import NotFoundError, SynthClientError, TaskFailedError
from synth_client.images import ImagesNamespace
from synth_client.pipeline import AugmentationPipeline, SynthDataset
from synth_client.prompt import Prompt as Prompt
from synth_client.schemas import (
    AugmentationResult,
    AugmentationSuggestion,
    AugmentationTask,
    BoundingBox,
    CollectionInfo,
    GenerationParams,
    ImageDTO,
    StatsInfo,
)

__all__ = [
    "ANNOTATION_HANDLERS",
    "AnnotationStrategy",
    "AugmentationPipeline",
    "AugmentationResult",
    "AugmentationSuggestion",
    "AugmentationTask",
    "AugmentationsNamespace",
    "BoundingBox",
    "CollectionInfo",
    "GenerationParams",
    "ImageDTO",
    "ImagesNamespace",
    "NotFoundError",
    "Prompt",
    "StatsInfo",
    "Synth",
    "SynthClient",
    "SynthClientError",
    "SynthDataset",
    "TaskFailedError",
]
