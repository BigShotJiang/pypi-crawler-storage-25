"""Shared fixtures for integration tests against the real Synth API."""

from __future__ import annotations

from collections.abc import Generator
from pathlib import Path

import pytest
from PIL import Image as PILImage

from synth_client import ImageDTO, SynthClient
from synth_client.exceptions import SynthClientError

API_BASE_URL = "http://localhost:8000"


@pytest.fixture(scope="session")
def client() -> Generator[SynthClient, None, None]:
    """Session-scoped SynthClient pointing at the local API.

    Fails immediately with ``pytest.fail`` if the API is not reachable so that
    the error is obvious rather than every test failing independently.
    """
    c = SynthClient(base_url=API_BASE_URL)
    try:
        c.get_stats()
    except (SynthClientError, Exception) as exc:
        pytest.fail(f"Synth API not available at {API_BASE_URL}: {exc}")
    yield c
    c.close()


@pytest.fixture
def test_image_path(tmp_path: Path) -> Path:
    """Write a small solid-colour PNG to a temporary path."""
    img = PILImage.new("RGB", (64, 64), color=(100, 149, 237))
    path = tmp_path / "test_fixture.png"
    img.save(path)
    return path


@pytest.fixture
def test_pil_image() -> PILImage.Image:
    """Return a small in-memory PIL image."""
    return PILImage.new("RGB", (64, 64), color=(200, 100, 50))


@pytest.fixture
def uploaded_image(client: SynthClient, test_image_path: Path) -> Generator[ImageDTO, None, None]:
    """Upload a test image before the test and delete it after."""
    image = client.images.upload(test_image_path)
    yield image
    import contextlib

    with contextlib.suppress(Exception):
        client.images.delete(image.id)
