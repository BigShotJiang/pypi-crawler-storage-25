"""Integration tests for ImagesNamespace against the real Synth API."""

from __future__ import annotations

from pathlib import Path

import pytest
from PIL import Image as PILImage

from synth_client import ImageDTO, SynthClient
from synth_client.exceptions import NotFoundError


class TestUpload:
    def test_upload_from_path(self, client: SynthClient, test_image_path: Path) -> None:
        image = client.images.upload(test_image_path)

        assert isinstance(image, ImageDTO)
        assert image.id
        assert image.s3_url

        client.images.delete(image.id)

    def test_upload_from_str_path(self, client: SynthClient, test_image_path: Path) -> None:
        image = client.images.upload(str(test_image_path))

        assert isinstance(image, ImageDTO)
        assert image.id

        client.images.delete(image.id)

    def test_upload_from_pil_image(
        self, client: SynthClient, test_pil_image: PILImage.Image
    ) -> None:
        image = client.images.upload(test_pil_image)

        assert isinstance(image, ImageDTO)
        assert image.id
        assert image.s3_url

        client.images.delete(image.id)

    def test_upload_invalid_type_raises(self, client: SynthClient) -> None:
        with pytest.raises(TypeError):
            client.images.upload(12345)  # type: ignore[arg-type]


class TestGet:
    def test_get_returns_image(self, client: SynthClient, uploaded_image: ImageDTO) -> None:
        image = client.images.get(uploaded_image.id)

        assert image.id == uploaded_image.id
        assert image.s3_url == uploaded_image.s3_url

    def test_get_nonexistent_raises_not_found(self, client: SynthClient) -> None:
        with pytest.raises(NotFoundError):
            client.images.get("nonexistent-id-00000000")


class TestList:
    def test_list_returns_list(self, client: SynthClient, uploaded_image: ImageDTO) -> None:
        images = client.images.list()
        ids = [img.id for img in images]

        assert isinstance(images, list)
        assert all(isinstance(img, ImageDTO) for img in images)
        assert uploaded_image.id in ids

    def test_list_contains_uploaded(self, client: SynthClient, uploaded_image: ImageDTO) -> None:
        images = client.images.list(limit=500)
        ids = [img.id for img in images]

        assert uploaded_image.id in ids

    def test_list_respects_limit(self, client: SynthClient) -> None:
        images = client.images.list(limit=2)

        assert len(images) <= 2


class TestDelete:
    def test_delete_removes_image(self, client: SynthClient, test_image_path: Path) -> None:
        image = client.images.upload(test_image_path)

        client.images.delete(image.id)

        with pytest.raises(NotFoundError):
            client.images.get(image.id)


class TestSearch:
    def test_search_by_query_returns_list(
        self, client: SynthClient, uploaded_image: ImageDTO
    ) -> None:
        results = client.images.search(query=uploaded_image.name, limit=10)

        assert isinstance(results, list)
        assert all(isinstance(img, ImageDTO) for img in results)

    def test_search_by_image_id(self, client: SynthClient, uploaded_image: ImageDTO) -> None:
        results = client.images.search(image_id=uploaded_image.id, limit=5)

        assert isinstance(results, list)
