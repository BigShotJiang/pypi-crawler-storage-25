"""Contract tests for all public Pydantic schemas."""

import pytest
from pydantic import ValidationError

from synth_client.schemas import (
    AugmentationResult,
    AugmentationSuggestion,
    AugmentationTask,
    BoundingBox,
    CollectionInfo,
    CollectionPreviewDTO,
    GenerationParams,
    ImageDTO,
    StatsInfo,
)


class TestBoundingBox:
    def test_valid(self) -> None:
        box = BoundingBox(label="cat", x_min=0, y_min=0, x_max=100, y_max=100)

        assert box.label == "cat"
        assert box.x_max == 100
        assert box.polygon is None

    def test_polygon_is_supported(self) -> None:
        box = BoundingBox(
            label="cat",
            x_min=0,
            y_min=0,
            x_max=100,
            y_max=100,
            polygon=[[0, 0], [100, 0], [100, 100]],
        )

        assert box.polygon == [[0, 0], [100, 0], [100, 100]]

    def test_missing_field_raises(self) -> None:
        with pytest.raises(ValidationError):
            BoundingBox(label="cat", x_min=0, y_min=0, x_max=100)  # type: ignore[call-arg]


class TestImageDTO:
    def test_minimal(self) -> None:
        image = ImageDTO(id="abc", name="photo.jpg", s3_url="http://s3/photo.jpg")

        assert image.id == "abc"
        assert image.description is None
        assert image.annotations == []
        assert image.score is None

    def test_annotations_are_bounding_boxes(self) -> None:
        image = ImageDTO(
            id="abc",
            name="photo.jpg",
            s3_url="http://s3/photo.jpg",
            annotations=[{"label": "dog", "x_min": 1, "y_min": 2, "x_max": 3, "y_max": 4}],  # type: ignore[arg-type]
        )

        assert len(image.annotations) == 1
        assert isinstance(image.annotations[0], BoundingBox)
        assert image.annotations[0].label == "dog"

    def test_invalid_annotation_raises(self) -> None:
        with pytest.raises(ValidationError):
            ImageDTO(
                id="abc",
                name="photo.jpg",
                s3_url="http://s3/photo.jpg",
                annotations=[{"label": "dog"}],  # type: ignore[arg-type]  # missing bbox coords
            )

    def test_full(self) -> None:
        image = ImageDTO(
            id="abc",
            name="photo.jpg",
            s3_url="http://s3/photo.jpg",
            description="a dog",
            media_type="image",
            mime_type="image/jpeg",
            parent_id="parent-1",
            augmentation_prompt="make it rain",
            augmentation_category="weather",
            score=0.92,
        )

        assert image.parent_id == "parent-1"
        assert image.score == pytest.approx(0.92)


class TestCollectionPreviewDTO:
    def test_valid(self) -> None:
        preview = CollectionPreviewDTO(url="http://s3/thumb.jpg", media_type="image")

        assert preview.url == "http://s3/thumb.jpg"

    def test_missing_url_raises(self) -> None:
        with pytest.raises(ValidationError):
            CollectionPreviewDTO(media_type="image")  # type: ignore[call-arg]


class TestCollectionInfo:
    def test_empty_previews_by_default(self) -> None:
        info = CollectionInfo(name="images", points_count=42)

        assert info.previews == []

    def test_with_previews(self) -> None:
        info = CollectionInfo(
            name="images",
            points_count=1,
            previews=[{"url": "http://s3/x.jpg", "media_type": "image"}],  # type: ignore[arg-type]
        )

        assert len(info.previews) == 1
        assert isinstance(info.previews[0], CollectionPreviewDTO)


class TestStatsInfo:
    def test_valid(self) -> None:
        stats = StatsInfo(collections=2, images=10, augmentations=5, descriptions=8)

        assert stats.collections == 2

    def test_missing_field_raises(self) -> None:
        with pytest.raises(ValidationError):
            StatsInfo(collections=2, images=10, augmentations=5)  # type: ignore[call-arg]


class TestAugmentationSuggestion:
    def test_valid(self) -> None:
        s = AugmentationSuggestion(prompt="add rain", category="weather")

        assert s.prompt == "add rain"
        assert s.category == "weather"

    def test_missing_category_raises(self) -> None:
        with pytest.raises(ValidationError):
            AugmentationSuggestion(prompt="add rain")  # type: ignore[call-arg]


class TestGenerationParams:
    def test_defaults(self) -> None:
        params = GenerationParams()

        assert params.num_inference_steps == 20
        assert params.true_cfg_scale == pytest.approx(4.0)
        assert params.guidance_scale == pytest.approx(1.0)

    def test_custom(self) -> None:
        params = GenerationParams(num_inference_steps=30, true_cfg_scale=5.0, guidance_scale=2.0)

        assert params.num_inference_steps == 30

    def test_steps_below_min_raises(self) -> None:
        with pytest.raises(ValidationError):
            GenerationParams(num_inference_steps=0)

    def test_steps_above_max_raises(self) -> None:
        with pytest.raises(ValidationError):
            GenerationParams(num_inference_steps=101)

    def test_cfg_below_min_raises(self) -> None:
        with pytest.raises(ValidationError):
            GenerationParams(true_cfg_scale=0.9)

    def test_guidance_below_min_raises(self) -> None:
        with pytest.raises(ValidationError):
            GenerationParams(guidance_scale=0.0)


class TestAugmentationTask:
    def test_minimal(self) -> None:
        task = AugmentationTask(task_id="t-1", status="running")

        assert task.task_id == "t-1"
        assert task.message is None
        assert task.progress == {}
        assert task.result is None
        assert task.error is None

    def test_with_result(self) -> None:
        task = AugmentationTask(
            task_id="t-1",
            status="completed",
            result={"image_ids": ["img-1", "img-2"], "total": 2},
        )

        assert task.result is not None
        assert task.result["total"] == 2

    def test_missing_task_id_raises(self) -> None:
        with pytest.raises(ValidationError):
            AugmentationTask(status="running")  # type: ignore[call-arg]


class TestAugmentationResult:
    def test_minimal(self) -> None:
        result = AugmentationResult(task_id="t-1", status="completed")

        assert result.image_ids == []
        assert result.total == 0
        assert result.error is None
        assert result.raw_result is None

    def test_full(self) -> None:
        result = AugmentationResult(
            task_id="t-1",
            status="completed",
            image_ids=["img-1"],
            total=1,
            raw_result={"image_ids": ["img-1"], "total": 1},
        )

        assert result.image_ids == ["img-1"]
        assert result.raw_result is not None
        assert result.raw_result["total"] == 1

    def test_missing_status_raises(self) -> None:
        with pytest.raises(ValidationError):
            AugmentationResult(task_id="t-1")  # type: ignore[call-arg]
