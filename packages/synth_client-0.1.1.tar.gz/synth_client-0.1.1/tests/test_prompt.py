"""Unit tests for Prompt composition and serialization."""

from __future__ import annotations

from synth_client.prompt import Prompt
from synth_client.schemas import AugmentationSuggestion


class TestLeaf:
    def test_single_prompt_serializes_to_one_suggestion(self) -> None:
        p = Prompt("make it winter")
        suggestions = p.to_suggestions()

        assert len(suggestions) == 1
        assert suggestions[0].prompt == "make it winter"
        assert suggestions[0].category == "custom"

    def test_custom_category(self) -> None:
        p = Prompt("add snow", category="weather")
        suggestions = p.to_suggestions()

        assert suggestions[0].category == "weather"

    def test_to_suggestions_returns_augmentation_suggestion_instances(self) -> None:
        p = Prompt("add fog")
        suggestions = p.to_suggestions()

        assert all(isinstance(s, AugmentationSuggestion) for s in suggestions)


class TestSequential:
    def test_add_combines_both_prompts(self) -> None:
        a = Prompt("make it winter")
        b = Prompt("add fog")
        combined = a + b
        suggestions = combined.to_suggestions()

        assert len(suggestions) == 2
        assert suggestions[0].prompt == "make it winter"
        assert suggestions[1].prompt == "add fog"

    def test_add_preserves_categories(self) -> None:
        a = Prompt("p1", category="cat1")
        b = Prompt("p2", category="cat2")
        combined = a + b
        suggestions = combined.to_suggestions()

        assert suggestions[0].category == "cat1"
        assert suggestions[1].category == "cat2"

    def test_add_is_not_commutative(self) -> None:
        a = Prompt("first")
        b = Prompt("second")

        assert (a + b).to_suggestions()[0].prompt == "first"
        assert (b + a).to_suggestions()[0].prompt == "second"

    def test_add_chaining(self) -> None:
        a = Prompt("a")
        b = Prompt("b")
        c = Prompt("c")
        combined = a + b + c
        suggestions = combined.to_suggestions()

        assert len(suggestions) == 3
        assert [s.prompt for s in suggestions] == ["a", "b", "c"]

    def test_original_prompts_unchanged_after_add(self) -> None:
        a = Prompt("original")
        b = Prompt("other")
        _ = a + b

        assert len(a.to_suggestions()) == 1
        assert a.to_suggestions()[0].prompt == "original"


class TestChoice:
    def test_or_always_returns_one_branch(self) -> None:
        a = Prompt("winter")
        b = Prompt("summer")
        variant = a | b
        suggestions = variant.to_suggestions()

        assert len(suggestions) == 1
        assert suggestions[0].prompt in {"winter", "summer"}

    def test_or_can_return_either_branch(self) -> None:
        a = Prompt("winter")
        b = Prompt("summer")
        variant = a | b

        seen: set[str] = set()
        for _ in range(100):
            seen.add(variant.to_suggestions()[0].prompt)
            if len(seen) == 2:
                break

        assert seen == {"winter", "summer"}

    def test_or_chaining_gives_multiple_choices(self) -> None:
        a = Prompt("rain")
        b = Prompt("fog")
        c = Prompt("snow")
        variant = a | b | c

        seen: set[str] = set()
        for _ in range(200):
            seen.add(variant.to_suggestions()[0].prompt)
            if len(seen) == 3:
                break

        assert seen == {"rain", "fog", "snow"}

    def test_original_prompts_unchanged_after_or(self) -> None:
        a = Prompt("original")
        b = Prompt("other")
        _ = a | b

        assert len(a.to_suggestions()) == 1


class TestComposition:
    def test_choice_then_sequential(self) -> None:
        """(a | b) + c should always include c and one of a or b."""
        a = Prompt("a")
        b = Prompt("b")
        c = Prompt("c")
        combined = (a | b) + c

        seen_first: set[str] = set()
        for _ in range(100):
            suggestions = combined.to_suggestions()
            assert len(suggestions) == 2
            assert suggestions[1].prompt == "c"
            seen_first.add(suggestions[0].prompt)
            if len(seen_first) == 2:
                break

        assert seen_first == {"a", "b"}

    def test_sequential_then_choice(self) -> None:
        """a + (b | c) should always include a and one of b or c."""
        a = Prompt("a")
        b = Prompt("b")
        c = Prompt("c")
        combined = a + (b | c)

        seen_second: set[str] = set()
        for _ in range(100):
            suggestions = combined.to_suggestions()
            assert len(suggestions) == 2
            assert suggestions[0].prompt == "a"
            seen_second.add(suggestions[1].prompt)
            if len(seen_second) == 2:
                break

        assert seen_second == {"b", "c"}


class TestBatch:
    def test_batch_creates_sequential_suggestions(self) -> None:
        p = Prompt.batch(["p1", "p2", "p3"])
        suggestions = p.to_suggestions()

        assert len(suggestions) == 3
        assert [s.prompt for s in suggestions] == ["p1", "p2", "p3"]

    def test_batch_default_category(self) -> None:
        p = Prompt.batch(["a", "b"])
        suggestions = p.to_suggestions()

        assert all(s.category == "custom" for s in suggestions)

    def test_batch_custom_category(self) -> None:
        p = Prompt.batch(["a", "b"], category="weather")
        suggestions = p.to_suggestions()

        assert all(s.category == "weather" for s in suggestions)

    def test_batch_single_item(self) -> None:
        p = Prompt.batch(["only one"])
        suggestions = p.to_suggestions()

        assert len(suggestions) == 1
        assert suggestions[0].prompt == "only one"

    def test_batch_empty_raises_or_returns_empty(self) -> None:
        p = Prompt.batch([])
        suggestions = p.to_suggestions()

        assert suggestions == []

    def test_batch_is_deterministic(self) -> None:
        """batch() has no random branches, so to_suggestions() is stable."""
        p = Prompt.batch(["x", "y", "z"])

        results = [p.to_suggestions() for _ in range(10)]
        prompts = [[s.prompt for s in r] for r in results]

        assert all(ps == ["x", "y", "z"] for ps in prompts)


class TestToSuggestionsReturnsCopy:
    def test_mutating_result_does_not_affect_prompt(self) -> None:
        p = Prompt("original")
        suggestions = p.to_suggestions()
        suggestions.append(AugmentationSuggestion(prompt="injected", category="x"))

        fresh = p.to_suggestions()
        assert len(fresh) == 1
