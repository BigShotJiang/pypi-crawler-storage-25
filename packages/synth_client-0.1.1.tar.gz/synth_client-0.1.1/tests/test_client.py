import json

import httpx

from synth_client import AugmentationSuggestion, SynthClient


def test_start_and_wait_for_augmentation_task() -> None:
    calls = {"status": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "POST" and request.url.path == "/api/tasks/augmentations":
            payload = json.loads(request.content.decode("utf-8"))
            assert payload["image_id"] == "img-1"
            assert payload["suggestions"] == [{"prompt": "rain", "category": "weather"}]
            return httpx.Response(
                202,
                json={
                    "task_id": "task-1",
                    "status": "running",
                    "message": "started",
                },
            )
        if request.method == "GET" and request.url.path == "/api/tasks/task-1":
            calls["status"] += 1
            if calls["status"] == 1:
                return httpx.Response(
                    200,
                    json={
                        "task_id": "task-1",
                        "status": "running",
                        "progress": {"total": 1, "current": 0},
                    },
                )
            return httpx.Response(
                200,
                json={
                    "task_id": "task-1",
                    "status": "completed",
                    "progress": {"total": 1, "completed": 1},
                    "result": {"image_ids": ["aug-1"], "total": 1},
                },
            )
        raise AssertionError(f"Unexpected request: {request.method} {request.url}")

    http_client = httpx.Client(
        base_url="http://testserver",
        transport=httpx.MockTransport(handler),
    )
    client = SynthClient(http_client=http_client)

    task = client.augmentations.start(
        image_id="img-1",
        suggestions=[AugmentationSuggestion(prompt="rain", category="weather")],
    )
    result = client.augmentations.wait(task.task_id, poll_interval=0.0, timeout=1.0)

    assert task.task_id == "task-1"
    assert result.image_ids == ["aug-1"]
    assert result.total == 1
