"""Integration tests for AugmentationsNamespace against the real Synth API."""

from __future__ import annotations

import pytest

from synth_client import AugmentationResult, ImageDTO, Prompt, SynthClient
from synth_client.annotations import AnnotationStrategy
from synth_client.exceptions import TaskFailedError
from synth_client.schemas import AugmentationTask

AUGMENTATION_TIMEOUT = 300.0
POLL_INTERVAL = 5.0


class TestRun:
    def test_run_with_string_prompt(self, client: SynthClient, uploaded_image: ImageDTO) -> None:
        result = client.augmentations.run(
            image_id=uploaded_image.id,
            prompt="make it slightly brighter",
            poll_interval=POLL_INTERVAL,
            timeout=AUGMENTATION_TIMEOUT,
        )

        assert isinstance(result, AugmentationResult)
        assert result.status == "completed"
        assert result.total >= 1
        assert len(result.image_ids) >= 1

        for aug_id in result.image_ids:
            client.images.delete(aug_id)

    def test_run_with_prompt_object(self, client: SynthClient, uploaded_image: ImageDTO) -> None:
        prompt = Prompt("add slight vignette", category="style")

        result = client.augmentations.run(
            image_id=uploaded_image.id,
            prompt=prompt,
            poll_interval=POLL_INTERVAL,
            timeout=AUGMENTATION_TIMEOUT,
        )

        assert result.status == "completed"
        assert len(result.image_ids) >= 1

        for aug_id in result.image_ids:
            client.images.delete(aug_id)

    def test_run_discard_is_default(self, client: SynthClient, uploaded_image: ImageDTO) -> None:
        result = client.augmentations.run(
            image_id=uploaded_image.id,
            prompt="slightly desaturate",
            annotation_strategy=AnnotationStrategy.DISCARD,
            poll_interval=POLL_INTERVAL,
            timeout=AUGMENTATION_TIMEOUT,
        )

        assert result.status == "completed"

        for aug_id in result.image_ids:
            client.images.delete(aug_id)

    def test_run_unsupported_strategy_raises(
        self, client: SynthClient, uploaded_image: ImageDTO
    ) -> None:
        with pytest.raises(NotImplementedError):
            client.augmentations.run(
                image_id=uploaded_image.id,
                prompt="test",
                annotation_strategy=AnnotationStrategy.DETECT,
            )

    def test_run_timeout_raises(self, client: SynthClient, uploaded_image: ImageDTO) -> None:
        with pytest.raises(TimeoutError):
            client.augmentations.run(
                image_id=uploaded_image.id,
                prompt="make it look like a painting in incredible artistic detail",
                poll_interval=0.1,
                timeout=0.01,
            )


class TestWait:
    def test_wait_returns_result_on_completion(
        self, client: SynthClient, uploaded_image: ImageDTO
    ) -> None:
        task = client.augmentations.start_from_prompts(
            image_id=uploaded_image.id,
            prompts=["slightly adjust contrast"],
        )

        assert isinstance(task, AugmentationTask)
        assert task.task_id

        result = client.augmentations.wait(
            task.task_id,
            poll_interval=POLL_INTERVAL,
            timeout=AUGMENTATION_TIMEOUT,
        )

        assert result.status == "completed"
        assert result.task_id == task.task_id

        for aug_id in result.image_ids:
            client.images.delete(aug_id)

    def test_wait_timeout_raises(self, client: SynthClient, uploaded_image: ImageDTO) -> None:
        task = client.augmentations.start_from_prompts(
            image_id=uploaded_image.id,
            prompts=["apply complex artistic transformation with many details"],
        )

        with pytest.raises(TimeoutError):
            client.augmentations.wait(task.task_id, poll_interval=0.1, timeout=0.01)

        client.augmentations.cancel(task.task_id)


class TestStatus:
    def test_status_returns_task(self, client: SynthClient, uploaded_image: ImageDTO) -> None:
        task = client.augmentations.start_from_prompts(
            image_id=uploaded_image.id,
            prompts=["add slight warmth"],
        )

        status = client.augmentations.status(task.task_id)

        assert isinstance(status, AugmentationTask)
        assert status.task_id == task.task_id
        assert status.status in {"running", "pending", "completed", "failed", "cancelled"}

        client.augmentations.cancel(task.task_id)


class TestFailedTask:
    def test_failed_task_raises_task_failed_error(self, client: SynthClient) -> None:
        with pytest.raises(TaskFailedError):
            client.augmentations.run(
                image_id="nonexistent-image-id-00000",
                prompt="make it winter",
                poll_interval=POLL_INTERVAL,
                timeout=AUGMENTATION_TIMEOUT,
            )
