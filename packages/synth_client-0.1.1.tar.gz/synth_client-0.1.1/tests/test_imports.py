from synth_client import SynthClient


def test_public_import() -> None:
    assert SynthClient.__name__ == "SynthClient"
