"""
Ponto de entrada principal do CLI VectorGov.
"""

import sys

# Fix Windows: reconfigura stdout/stderr para UTF-8 antes de qualquer print.
# No Windows, sys.stdout.encoding pode ser cp1252, quebrando o emit de JSON
# com caracteres fora desse range (ex: \u202f non-breaking space, chars
# tipograficos). print() resulta em UnicodeEncodeError nesses casos.
# reconfigure() preserva o stdout/stderr original mas troca o codec.
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:  # pragma: no cover — fail silently se nao suportado
        pass

import typer
from rich.console import Console

from .commands import auth, search, ask, feedback, docs, config, tokens
from .commands import smart_search, hybrid, lookup, grep_cmd, merged, audit, quota, prompts
from .commands import context as context_cmd, init as init_cmd, fs_search, read as read_cmd, explain

# Console para output formatado
console = Console()

# App principal
app = typer.Typer(
    name="vectorgov",
    help="CLI para a API VectorGov - Busca semântica em legislação brasileira",
    add_completion=True,
    no_args_is_help=True,
)

# Grupos reais (com subcomandos) — registrados via add_typer
app.add_typer(auth.app, name="auth", help="Autenticação e gerenciamento de credenciais")
app.add_typer(feedback.app, name="feedback", help="Enviar feedback sobre respostas")
app.add_typer(docs.app, name="docs", help="Listar e consultar documentos disponíveis")
app.add_typer(config.app, name="config", help="Gerenciar configurações")
app.add_typer(audit.app, name="audit", help="Eventos de segurança (PII, injection, rate-limit)")
app.add_typer(prompts.app, name="prompts", help="System prompts para LLMs")

# Comandos single-shot — registrados direto no app raiz para que Click
# aceite flags e argumentos posicionais em qualquer ordem (GNU-style).
# Registrar como add_typer + @app.callback faria o Click tratar cada
# comando como multi-command group e exigir ordem estrita.
app.command(name="search", help="Buscar documentos na base de legislação")(search.search)
app.command(name="ask", help="[ADMIN] Fazer perguntas com resposta de IA", hidden=True)(ask.ask)
app.command(name="tokens", help="Estimar tokens para planejamento de uso de LLM")(tokens.tokens)
app.command(name="smart-search", help="Busca inteligente com análise jurídica (MOC v4)")(smart_search.smart_search)
app.command(name="hybrid", help="Busca híbrida com expansão por grafo normativo")(hybrid.hybrid)
app.command(name="lookup", help="Consulta artigo específico por referência legal")(lookup.lookup)
app.command(name="grep", help="Busca exata por texto nas normas")(grep_cmd.grep)
app.command(name="merged", help="Busca dual-path (semântica + índice curado)")(merged.merged)
app.command(name="quota", help="Uso e limites do plano")(quota.quota)
app.command(name="context", help="Gera contexto completo pronto para LLMs")(context_cmd.context)
app.command(name="init", help="Inicializa projeto para ferramentas AI")(init_cmd.init)
app.command(name="fs-search", help="Busca no índice curado (filesystem)")(fs_search.fs_search)
app.command(name="read", help="Lê texto canônico de um documento ou dispositivo")(read_cmd.read_canonical)
app.command(name="explain", help="Contexto completo de um dispositivo legal")(explain.explain)


def _version_callback(value: bool):
    """Callback para o flag --version."""
    if value:
        from . import __version__
        console.print(f"vectorgov-cli versão {__version__}")
        raise typer.Exit()


@app.command()
def version():
    """Mostra a versão do CLI."""
    from . import __version__
    console.print(f"vectorgov-cli versão {__version__}")


@app.callback()
def callback(
    version: bool = typer.Option(
        False,
        "--version", "-V",
        callback=_version_callback,
        is_eager=True,
        help="Mostra a versão do CLI e sai.",
    ),
):
    """
    VectorGov CLI - Busca semântica em legislação brasileira.

    Use 'vectorgov COMANDO --help' para mais informações sobre cada comando.
    """
    pass


def main():
    """Função principal executada pelo entry point."""
    app()


if __name__ == "__main__":
    main()
