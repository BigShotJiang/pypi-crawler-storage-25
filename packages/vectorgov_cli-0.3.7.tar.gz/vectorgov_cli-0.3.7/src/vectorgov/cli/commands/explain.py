"""Contexto completo de um dispositivo legal em uma unica chamada."""

import json
import typer
from rich.console import Console
from rich.panel import Panel
from ..utils.config import ConfigManager
from ..utils.output import (
    absolute_url,
    extract_request_id,
    get_evidence_links,
    print_request_id_footer,
    render_llm_output,
)

console = Console()
config_manager = ConfigManager()


def explain(
    reference: str = typer.Argument(..., help="Referencia legal (ex: 'Art. 75 da Lei 14.133')"),
    output: str = typer.Option("llm", "--output", "-o", help="Formato: llm, text, json, raw"),
    raw: bool = typer.Option(False, "--raw", help="JSON bruto para piping"),
):
    """Contexto completo de um dispositivo legal em uma unica chamada.

    Combina lookup (resolve a referencia) + texto consolidado (caput + filhos)
    + parent + links de evidencia. Ideal para LLMs que precisam entender um
    artigo completo sem fazer multiplas chamadas.

    Diferente de 'lookup' (que resolve a referencia) e 'read' (que le o
    canonical), o 'explain' retorna TUDO em uma chamada.

    Exemplo:
        vectorgov explain "Art. 75 da Lei 14.133"
        vectorgov explain "Art. 33 inc I da Lei 14.133" --output llm
        vectorgov explain "Art. 18 da Lei 14.133" --raw
    """
    try:
        from vectorgov import VectorGov

        api_key = config_manager.get("api_key")
        if not api_key:
            console.print("[red]Erro:[/red] API key nao configurada.")
            console.print("  Use [cyan]vectorgov auth login[/cyan] para configurar.")
            raise typer.Exit(1)

        vg = VectorGov(api_key=api_key)

        with console.status("[bold]Consultando dispositivo...[/bold]"):
            result = vg.lookup(
                reference=reference,
                include_parent=True,
                include_siblings=False,
            )

        status = getattr(result, "status", "unknown")
        raw_resp = getattr(result, "_raw_response", None) or {}

        # Evidence URLs (workaround SDK v0.16 + fix v0.17.2)
        evidence_url = absolute_url(
            getattr(result, "evidence_url", None) or raw_resp.get("evidence_url")
        )
        document_url = absolute_url(
            getattr(result, "document_url", None) or raw_resp.get("document_url")
        )

        # Texto principal: preferir stitched_text (consolidado com filhos)
        main_text = (
            getattr(result, "stitched_text", None)
            or raw_resp.get("stitched_text")
            or raw_resp.get("text")
            or ""
        )

        # Match info
        match_text = ""
        if hasattr(result, "match") and result.match:
            match_text = getattr(result.match, "text", "")
        elif not main_text:
            match_text = raw_resp.get("text", "")

        if not main_text:
            main_text = match_text

        # Document info
        doc_id = raw_resp.get("document_id", "")
        device_type = raw_resp.get("device_type", "")
        article_number = raw_resp.get("article_number", "")
        breadcrumb = raw_resp.get("breadcrumb", "")
        tipo_doc = raw_resp.get("tipo_documento", "")

        # Parent
        parent = getattr(result, "parent", None)
        parent_text = ""
        if parent and hasattr(parent, "text"):
            parent_text = getattr(parent, "text", "")
        elif isinstance(parent, dict):
            parent_text = parent.get("text", "")

        # Children count
        children = getattr(result, "children", []) or []
        children_count = len(children)

        # Specialist notes
        nota = raw_resp.get("nota_especialista", "")
        juris = raw_resp.get("jurisprudencia_tcu", "")

        # === OUTPUT ===

        if raw:
            data = {
                "reference": reference,
                "status": status,
                "document_id": doc_id,
                "device_type": device_type,
                "article_number": article_number,
                "breadcrumb": breadcrumb,
                "tipo_documento": tipo_doc,
                "text": main_text,
                "parent_text": parent_text or None,
                "children_count": children_count,
                "nota_especialista": nota or None,
                "jurisprudencia_tcu": juris or None,
                "evidence_url": evidence_url,
                "document_url": document_url,
                "request_id": extract_request_id(result, raw_resp),
            }
            print(json.dumps(data, ensure_ascii=False, indent=2))
            return

        if status != "found":
            if output == "llm":
                print(f"REFERENCIA: {reference}")
                print(f"STATUS: {status}")
                msg = getattr(result, "message", None) or raw_resp.get("message", "")
                if msg:
                    print(f"MENSAGEM: {msg}")
            else:
                console.print(f"Status: [red]{status}[/red]")
                msg = getattr(result, "message", None)
                if msg:
                    console.print(f"  {msg}")
            raise typer.Exit(0)

        if output == "llm":
            lines = []
            lines.append(f"REFERENCIA: {reference}")
            lines.append(f"STATUS: {status}")
            if doc_id:
                lines.append(f"DOCUMENTO: {doc_id}")
            if breadcrumb:
                lines.append(f"BREADCRUMB: {breadcrumb}")
            lines.append("")
            lines.append("TEXTO CONSOLIDADO:")
            lines.append(main_text)
            if parent_text:
                lines.append("")
                lines.append(f"PARENT: {parent_text}")
            else:
                lines.append("")
                lines.append("PARENT: (nenhum -- dispositivo de primeiro nivel)")
            lines.append(f"FILHOS: {children_count} dispositivos")
            if nota:
                lines.append("")
                lines.append(f"NOTA DO ESPECIALISTA: {nota}")
            if juris:
                lines.append("")
                lines.append(f"JURISPRUDENCIA TCU: {juris}")
            if evidence_url:
                lines.append("")
                lines.append(f"EVIDENCE: {evidence_url}")
            if document_url:
                lines.append(f"PDF: {document_url}")
            req_id = extract_request_id(result, raw_resp)
            if req_id:
                lines.append("")
                lines.append(f"REQUEST_ID: {req_id}")
            print("\n".join(lines))

        elif output == "json":
            data = {
                "reference": reference,
                "status": status,
                "document_id": doc_id,
                "text": main_text,
                "parent_text": parent_text or None,
                "children_count": children_count,
                "evidence_url": evidence_url,
                "document_url": document_url,
                "request_id": extract_request_id(result, raw_resp),
            }
            console.print_json(json.dumps(data, ensure_ascii=False))

        else:  # text
            title = breadcrumb or reference
            console.print(f"\nStatus: [green]{status}[/green]")
            console.print(Panel(main_text, title=title, border_style="cyan"))
            if parent_text:
                console.print(Panel(parent_text, title="Parent", border_style="dim"))
            console.print(f"[dim]Filhos: {children_count} dispositivos[/dim]")
            if nota:
                console.print(f"\n[bold]Nota do especialista:[/bold] {nota}")
            if evidence_url:
                console.print(f"[dim]    Ver trecho: {evidence_url}[/dim]")
            if document_url:
                console.print(f"[dim]    Baixar PDF: {document_url}[/dim]")
            print_request_id_footer(console, extract_request_id(result, raw_resp))

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
