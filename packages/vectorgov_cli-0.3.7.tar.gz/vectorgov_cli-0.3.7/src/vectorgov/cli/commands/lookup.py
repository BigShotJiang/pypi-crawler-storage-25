"""Consulta artigo específico por referência legal."""

import json
import typer
from rich.console import Console
from rich.panel import Panel
from ..utils.config import ConfigManager
from ..utils.output import (
    absolute_url,
    extract_credits,
    extract_request_id,
    print_credits_footer,
    print_request_id_footer,
    render_evidence_lines_text,
    render_llm_output,
    resolve_output_format,
)

console = Console()
config_manager = ConfigManager()


def lookup(  # noqa: C901
    query: str = typer.Argument(None, help="Referência legal (ex: 'Art. 75 da Lei 14.133')"),
    include_parent: bool = typer.Option(
        True, "--parent/--no-parent", help="Incluir dispositivo pai"
    ),
    include_siblings: bool = typer.Option(
        True, "--siblings/--no-siblings", help="Incluir irmãos"
    ),
    output: str = typer.Option("text", "--output", "-o", help="Formato: text, json, llm"),
    raw: bool = typer.Option(False, "--raw", help="JSON bruto para piping"),
    pipe: bool = typer.Option(False, "--pipe", help="Ler referencias de stdin (uma por linha, batch)"),
):
    """Consulta um dispositivo legal específico por referência.

    Resolve referências como 'Art. 75', 'par. 2 do Art. 24', 'inciso IV do Art. 75'.
    Mais rápido que search para consultas de artigos específicos.

    Para filtrar por documento, inclua o nome na própria referência
    (ex: "Art. 75 da Lei 14.133" em vez de --doc).

    Exemplo:
        vectorgov lookup "Art. 75 da Lei 14.133"
        vectorgov lookup "par. 2 do Art. 24 da Lei 14.133"
        vectorgov lookup --no-parent "Art. 1 da Lei 14.133"
        echo -e "Art. 75 da Lei 14.133\\nArt. 24 da Lei 14.133" | vectorgov lookup --pipe
    """
    try:
        from vectorgov import VectorGov

        api_key = config_manager.get("api_key")
        if not api_key:
            console.print("[red]Erro:[/red] API key nao configurada.")
            console.print("  Use [cyan]vectorgov auth login[/cyan] para configurar.")
            raise typer.Exit(1)

        # Handle --pipe mode: read from stdin
        refs = []
        if pipe:
            import sys
            refs = [line.strip() for line in sys.stdin if line.strip()]
            if not refs:
                console.print("[red]Erro:[/red] stdin vazio. Passe referencias (uma por linha).")
                raise typer.Exit(1)
            query = refs[0] if len(refs) == 1 else None
        elif not query:
            console.print("[red]Erro:[/red] informe a referencia ou use --pipe para ler de stdin.")
            raise typer.Exit(1)

        vg = VectorGov(api_key=api_key)

        if pipe and len(refs) > 1:
            # Batch mode
            with console.status(f"[bold]Consultando {len(refs)} referencias...[/bold]"):
                result = vg.lookup(
                    reference=refs,
                    include_parent=include_parent,
                    include_siblings=include_siblings,
                )

            # Handle batch result for --raw
            if raw:
                batch_results = getattr(result, "results", []) or []
                data = {
                    "batch": True,
                    "total": len(batch_results),
                    "request_id": extract_request_id(result),
                    "results": []
                }
                for r in batch_results:
                    raw_r = getattr(r, "_raw_response", None) or {}
                    data["results"].append({
                        "reference": getattr(r, "query", ""),
                        "status": getattr(r, "status", "unknown"),
                        "text": raw_r.get("text", getattr(r, "stitched_text", "") or ""),
                        "evidence_url": absolute_url(getattr(r, "evidence_url", None) or raw_r.get("evidence_url")),
                        "document_url": absolute_url(getattr(r, "document_url", None) or raw_r.get("document_url")),
                    })
                print(json.dumps(data, ensure_ascii=False, indent=2))
                return

            # Handle batch result for text/json/llm output
            batch_results = getattr(result, "results", []) or []
            for i, r in enumerate(batch_results):
                raw_r = getattr(r, "_raw_response", None) or {}
                status = getattr(r, "status", "unknown")
                text = raw_r.get("text", "") or getattr(r, "stitched_text", "") or ""
                ref_str = getattr(r, "query", refs[i] if i < len(refs) else "")
                ev = absolute_url(getattr(r, "evidence_url", None) or raw_r.get("evidence_url"))
                doc_url = absolute_url(getattr(r, "document_url", None) or raw_r.get("document_url"))

                if output == "llm":
                    print(f"[{i+1}/{len(batch_results)}] {ref_str} ({status})")
                    if text:
                        print(text)
                    if ev:
                        print(f"EVIDENCE: {ev}")
                    if doc_url:
                        print(f"PDF: {doc_url}")
                    if i < len(batch_results) - 1:
                        print("---")
                else:
                    console.print(f"\n[bold cyan][{i+1}] {ref_str}[/bold cyan] [{status}]")
                    if text:
                        console.print(text)
                    if ev:
                        console.print(f"[dim]    Ver trecho: {ev}[/dim]")
                    if doc_url:
                        console.print(f"[dim]    Baixar PDF: {doc_url}[/dim]")
            # Rodapé com request_id (graceful se ausente)
            print_request_id_footer(console, extract_request_id(result))
            return

        # Single mode (existing logic)
        effective_output = resolve_output_format(output, is_raw=raw)
        ref = query if not pipe else refs[0]
        with console.status("[bold]Consultando dispositivo...[/bold]"):
            result = vg.lookup(
                reference=ref,
                include_parent=include_parent,
                include_siblings=include_siblings,
            )

        status = getattr(result, "status", None)

        # Backend faz auto-split quando a query contem multiplas referencias
        # separadas por virgula ou "e" (ex: "inc. I do Art. 4, inc. II do Art. 4").
        # Nesse caso retorna status=batch com a lista em `results`.
        if status == "batch":
            batch_results = getattr(result, "results", None) or []
            if raw or effective_output == "raw":
                data = {
                    "batch": True,
                    "total": len(batch_results),
                    "request_id": extract_request_id(result),
                    "results": [],
                }
                for r in batch_results:
                    raw_r = getattr(r, "_raw_response", None) or {}
                    data["results"].append({
                        "reference": getattr(r, "query", ""),
                        "status": getattr(r, "status", "unknown"),
                        "text": raw_r.get("text") or getattr(r, "stitched_text", "") or "",
                        "evidence_url": absolute_url(
                            getattr(r, "evidence_url", None) or raw_r.get("evidence_url")
                        ),
                        "document_url": absolute_url(
                            getattr(r, "document_url", None) or raw_r.get("document_url")
                        ),
                        "document_id": raw_r.get("document_id", ""),
                        "device_type": raw_r.get("device_type", ""),
                        "breadcrumb": raw_r.get("breadcrumb", ""),
                    })
                print(json.dumps(data, ensure_ascii=False, indent=2))
                return

            # JSON estruturado (-o json) com syntax highlight no console
            if effective_output == "json":
                data = {
                    "batch": True,
                    "total": len(batch_results),
                    "request_id": extract_request_id(result),
                    "results": [],
                }
                for r in batch_results:
                    raw_r = getattr(r, "_raw_response", None) or {}
                    data["results"].append({
                        "reference": getattr(r, "query", ""),
                        "status": getattr(r, "status", "unknown"),
                        "text": raw_r.get("text") or getattr(r, "stitched_text", "") or "",
                        "evidence_url": absolute_url(
                            getattr(r, "evidence_url", None) or raw_r.get("evidence_url")
                        ),
                        "document_url": absolute_url(
                            getattr(r, "document_url", None) or raw_r.get("document_url")
                        ),
                        "document_id": raw_r.get("document_id", ""),
                        "device_type": raw_r.get("device_type", ""),
                        "breadcrumb": raw_r.get("breadcrumb", ""),
                    })
                console.print_json(json.dumps(data, ensure_ascii=False))
                return

            # Text / llm output
            if effective_output == "llm":
                for i, r in enumerate(batch_results):
                    raw_r = getattr(r, "_raw_response", None) or {}
                    r_status = getattr(r, "status", "unknown")
                    r_text = raw_r.get("text") or getattr(r, "stitched_text", "") or ""
                    r_ref = getattr(r, "query", f"ref {i+1}")
                    r_ev = absolute_url(getattr(r, "evidence_url", None) or raw_r.get("evidence_url"))
                    r_doc = absolute_url(getattr(r, "document_url", None) or raw_r.get("document_url"))
                    print(f"[{i+1}/{len(batch_results)}] {r_ref} ({r_status})")
                    if r_text:
                        print(r_text)
                    if r_ev:
                        print(f"EVIDENCE: {r_ev}")
                    if r_doc:
                        print(f"PDF: {r_doc}")
                    if i < len(batch_results) - 1:
                        print("---")
            else:
                console.print(f"[bold]Batch:[/bold] {len(batch_results)} referencias encontradas")
                for i, r in enumerate(batch_results):
                    raw_r = getattr(r, "_raw_response", None) or {}
                    r_status = getattr(r, "status", "unknown")
                    r_text = raw_r.get("text") or getattr(r, "stitched_text", "") or ""
                    r_ref = getattr(r, "query", f"ref {i+1}")
                    r_breadcrumb = raw_r.get("breadcrumb", "")
                    r_ev = absolute_url(
                        getattr(r, "evidence_url", None) or raw_r.get("evidence_url")
                    )
                    r_doc = absolute_url(
                        getattr(r, "document_url", None) or raw_r.get("document_url")
                    )
                    title = f"[{i+1}] {r_ref} [{r_status}]"
                    if r_breadcrumb:
                        title += f"\n  {r_breadcrumb}"
                    if r_text:
                        console.print(Panel(r_text, title=title, border_style="cyan"))
                    else:
                        console.print(f"\n[yellow]{title}[/yellow]")
                        console.print(f"  Nenhum texto retornado.")
                    # Links de evidencia abaixo de cada resultado
                    pseudo_r = {"evidence_url": r_ev, "document_url": r_doc}
                    for line in render_evidence_lines_text(pseudo_r):
                        console.print(f"[dim]{line}[/dim]")
            # Rodapé com request_id (comum a todos os formatos de batch)
            print_request_id_footer(console, extract_request_id(result))
            return

        # Fallback: SDK v0.16 falha ao parsear `match` quando o backend aplica
        # _strip_lookup_internals (remove node_id/span_id por segurança). O
        # backend envia text/document_id/device_type no root do response mas
        # o SDK só cria o Hit de match se node_id existir. Reconstruímos a
        # partir de _raw_response quando match é None mas status=found.
        raw_resp = getattr(result, "_raw_response", None) or {}

        # Tenta primeiro o atributo do objeto, fallback para _raw_response
        # (SDK v0.16 não expõe evidence_url/document_url no LookupResult)
        evidence_url = (
            absolute_url(getattr(result, "evidence_url", None))
            or absolute_url(raw_resp.get("evidence_url"))
        )
        document_url = (
            absolute_url(getattr(result, "document_url", None))
            or absolute_url(raw_resp.get("document_url"))
        )

        def _build_match_from_raw(raw: dict):
            if not raw or raw.get("status") != "found":
                return None
            text = raw.get("text") or raw.get("stitched_text")
            if not text:
                return None
            return {
                "text": text,
                "document_id": raw.get("document_id", ""),
                "span_id": raw.get("span_id", ""),
                "device_type": raw.get("device_type", ""),
                "article_number": raw.get("article_number", ""),
                "tipo_documento": raw.get("tipo_documento", ""),
                "breadcrumb": raw.get("breadcrumb", ""),
                "source": raw.get("document_id", ""),
                "evidence_url": absolute_url(raw.get("evidence_url")),
                "document_url": absolute_url(raw.get("document_url")),
            }

        # LookupResult has match, children, stitched_text
        # Determina device_type cedo para decidir se duplica children.
        # Para ARTIGOS, o match.text ja e o stitched_text (caput + filhos
        # concatenados via fix backend), entao adicionar children gera
        # duplicacao. Para inciso/paragrafo/alinea especificos, o match
        # e so o dispositivo, e children pode agregar contexto.
        resolved_device = raw_resp.get("device_type", "")

        hits = []
        if hasattr(result, "match") and result.match:
            hits.append(result.match)
        elif status == "found":
            fallback_match = _build_match_from_raw(raw_resp)
            if fallback_match:
                hits.append(fallback_match)
        if hasattr(result, "children") and resolved_device != "article":
            hits.extend(result.children)

        # Curadoria (SPEC 1C): nota do especialista e jurisprudencia TCU.
        # Backend envia no root do response; expor no output para usuarios.
        nota_especialista = raw_resp.get("nota_especialista") or getattr(
            result, "nota_especialista", None
        )
        jurisprudencia_tcu = raw_resp.get("jurisprudencia_tcu") or getattr(
            result, "jurisprudencia_tcu", None
        )
        acordao_tcu_key = raw_resp.get("acordao_tcu_key") or getattr(
            result, "acordao_tcu_key", None
        )
        acordao_tcu_link = raw_resp.get("acordao_tcu_link") or getattr(
            result, "acordao_tcu_link", None
        )

        if effective_output == "raw":

            def _obj_to_dict(obj):
                if obj is None:
                    return None
                if isinstance(obj, dict):
                    return obj
                # Dataclass com slots (sem __dict__)
                if hasattr(obj, "__slots__"):
                    return {
                        k: getattr(obj, k, None)
                        for k in obj.__slots__
                        if not k.startswith("_")
                    }
                if hasattr(obj, "__dict__"):
                    return {
                        k: v for k, v in obj.__dict__.items() if not k.startswith("_")
                    }
                # Fallback: extrai atributos comuns de Hit
                return {
                    "text": getattr(obj, "text", ""),
                    "span_id": getattr(obj, "span_id", ""),
                    "document_id": getattr(obj, "document_id", ""),
                    "source": getattr(obj, "source", ""),
                    "score": getattr(obj, "score", 0),
                    "device_type": getattr(obj, "device_type", ""),
                }

            match_raw = _obj_to_dict(getattr(result, "match", None))
            if match_raw is None and status == "found":
                match_raw = _build_match_from_raw(raw_resp)
            parent_raw = (
                _obj_to_dict(getattr(result, "parent", None))
                if include_parent
                else None
            )
            siblings_raw = (
                [_obj_to_dict(s) for s in getattr(result, "siblings", []) or []]
                if include_siblings
                else []
            )
            candidates_raw = [
                _obj_to_dict(c) for c in getattr(result, "candidates", []) or []
            ]
            children_raw = [
                {
                    "text": getattr(c, "text", ""),
                    "span_id": getattr(c, "span_id", ""),
                }
                for c in getattr(result, "children", []) or []
            ]

            data = {
                "query": query,
                "status": status,
                "query_id": getattr(result, "query_id", None),
                "request_id": extract_request_id(result, raw_resp),
                "match": match_raw,
                "parent": parent_raw,
                "siblings": siblings_raw,
                "candidates": candidates_raw,
                "children": children_raw,
                "stitched_text": getattr(result, "stitched_text", None),
                "evidence_url": evidence_url,
                "document_url": document_url,
                "nota_especialista": nota_especialista,
                "jurisprudencia_tcu": jurisprudencia_tcu,
                "acordao_tcu_key": acordao_tcu_key,
                "acordao_tcu_link": acordao_tcu_link,
                "total": len(hits),
                "hits": [
                    {
                        "text": getattr(h, "text", str(h)),
                        "source": getattr(h, "source", ""),
                        "document_id": getattr(h, "document_id", ""),
                        "span_id": getattr(h, "span_id", ""),
                        "device_type": getattr(h, "device_type", ""),
                    }
                    for h in hits
                ],
            }
            print(json.dumps(data, ensure_ascii=False, indent=2, default=str))
            return

        # Show status in non-raw output
        if status:
            status_colors = {
                "found": "green",
                "ambiguous": "yellow",
                "not_found": "red",
                "parse_failed": "red",
            }
            color = status_colors.get(status, "white")
            console.print(f"Status: [{color}]{status}[/{color}]")

        if not hits:
            console.print(
                "[yellow]Nenhum dispositivo encontrado para essa referência.[/yellow]"
            )
            raise typer.Exit(0)

        if effective_output == "llm":
            metadata = {
                "total": len(hits),
                "latency_ms": getattr(result, "latency_ms", None),
                "query_id": getattr(result, "query_id", None),
                "request_id": extract_request_id(result, raw_resp),
                "credits": extract_credits(result),
                "nota_especialista": nota_especialista,
                "jurisprudencia_tcu": jurisprudencia_tcu,
                "acordao_tcu_key": acordao_tcu_key,
                "acordao_tcu_link": acordao_tcu_link,
            }
            print(render_llm_output(hits, query, metadata))
            return

        # hits pode conter dict (fallback _build_match_from_raw) OU objeto
        # (SDK Hit). Helper para ler campos de ambos uniformemente — usar
        # getattr direto em dict não lê chaves, então str(h) acabava
        # serializando o dict inteiro dentro do campo `text` do output JSON.
        def _get(obj, key, default=""):
            if obj is None:
                return default
            if isinstance(obj, dict):
                return obj.get(key, default)
            return getattr(obj, key, default)

        if output == "json":
            data = {
                "status": status,
                "query": query,
                "query_id": getattr(result, "query_id", None),
                "request_id": extract_request_id(result, raw_resp),
                "evidence_url": evidence_url,
                "document_url": document_url,
                "nota_especialista": nota_especialista,
                "jurisprudencia_tcu": jurisprudencia_tcu,
                "acordao_tcu_key": acordao_tcu_key,
                "acordao_tcu_link": acordao_tcu_link,
                "total": len(hits),
                "hits": [
                    {
                        "source": _get(h, "source") or _get(h, "document_id"),
                        "text": _get(h, "text"),
                        "span_id": _get(h, "span_id"),
                        "device_type": _get(h, "device_type"),
                        "document_id": _get(h, "document_id"),
                        "article_number": _get(h, "article_number"),
                        "breadcrumb": _get(h, "breadcrumb"),
                    }
                    for h in hits
                ],
            }
            console.print_json(json.dumps(data, ensure_ascii=False))
        else:
            for h in hits:
                source = _get(h, "source") or _get(h, "document_id")
                span = _get(h, "span_id")
                title = f"{source} — {span}" if span else source
                text = _get(h, "text") or str(h)
                console.print(Panel(text, title=title, border_style="cyan"))

            # Links de evidência (extraídos do result, não dos hits — o backend
            # envia no root do response, não por hit, no endpoint lookup)
            pseudo = {"evidence_url": evidence_url, "document_url": document_url}
            for line in render_evidence_lines_text(pseudo):
                console.print(f"[dim]{line}[/dim]")

            # Curadoria (SPEC 1C): exibe nota do especialista e
            # jurisprudencia TCU quando presentes no response.
            if nota_especialista:
                console.print()
                console.print(Panel(
                    nota_especialista,
                    title="[bold yellow]Nota do Especialista[/bold yellow]",
                    border_style="yellow",
                ))
            if jurisprudencia_tcu:
                console.print()
                jur_content = jurisprudencia_tcu
                if acordao_tcu_key:
                    jur_content += f"\n\nAcórdão: {acordao_tcu_key}"
                if acordao_tcu_link:
                    jur_content += f"\nLink: {acordao_tcu_link}"
                console.print(Panel(
                    jur_content,
                    title="[bold magenta]Jurisprudência TCU[/bold magenta]",
                    border_style="magenta",
                ))

        query_id = getattr(result, "query_id", None)
        if query_id:
            console.print(f"\n[dim]query_id: {query_id}[/dim]")
        # Request ID para correlação com logs
        req_id = extract_request_id(result, raw_resp)
        if req_id:
            console.print(f"[dim]Request ID: {req_id}[/dim]")

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
