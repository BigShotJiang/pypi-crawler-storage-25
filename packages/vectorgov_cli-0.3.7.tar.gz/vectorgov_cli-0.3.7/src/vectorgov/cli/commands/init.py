"""Inicializa projeto com configuração para ferramentas AI (Claude Code, Cursor, etc)."""

from pathlib import Path

import typer
from rich.console import Console

from ..utils.config import ConfigManager

console = Console()
config_manager = ConfigManager()

CLAUDE_MD = """# VectorGov — Instruções para o Claude Code

Este projeto utiliza o **VectorGov** para busca jurídica em legislação brasileira.

## Como buscar legislação

Use o CLI `vectorgov` instalado no ambiente. Comandos disponíveis:

```bash
# Busca semântica (mais comum)
vectorgov search "sua pergunta aqui"

# Busca inteligente com análise de completude (mais lenta, mais precisa)
vectorgov smart-search "sua pergunta aqui"

# Consultar artigo específico
vectorgov lookup "Art. 75 da Lei 14.133"

# Busca exata por texto
vectorgov grep "dispensa de licitação"

# Busca com expansão por grafo normativo (artigos relacionados)
vectorgov hybrid "critérios de julgamento"

# Gerar contexto completo para LLM
vectorgov context "sua pergunta" --format raw

# Ver uso do plano
vectorgov quota
```

## Dicas

- Use `--output json` ou `--raw` quando precisar processar a saída programaticamente
- Use `vectorgov context "query"` para obter busca + system prompt em um bloco pronto
- Use `vectorgov smart-search` para perguntas complexas que exigem análise de completude
- O `--format messages` gera JSON compatível com a API da OpenAI
- Para feedback sobre resultados: `vectorgov feedback send <query_id> --like`
"""

CURSORRULES = """# VectorGov — Instruções para o Cursor AI

Este projeto utiliza o **VectorGov** para busca em legislação brasileira.

## Ferramentas disponíveis

O CLI `vectorgov` está instalado. Use-o para buscar legislação:

- `vectorgov search "pergunta"` — busca semântica rápida
- `vectorgov smart-search "pergunta"` — busca inteligente com análise (mais lenta)
- `vectorgov lookup "Art. 75 da Lei 14.133"` — consulta artigo específico
- `vectorgov grep "texto exato"` — busca literal no corpo das normas
- `vectorgov hybrid "pergunta"` — busca com artigos relacionados via grafo
- `vectorgov context "pergunta"` — bloco completo pronto para LLM
- `vectorgov quota` — verificar uso do plano

## Regras

1. Sempre use `vectorgov search` antes de responder perguntas sobre legislação
2. Para perguntas complexas, prefira `vectorgov smart-search`
3. Para citar um artigo específico, use `vectorgov lookup`
4. Sempre inclua a referência da fonte na resposta (documento, artigo)
5. Use `--output json` quando precisar processar dados programaticamente
"""

CODEX_MD = """# VectorGov — Instruções para o OpenAI Codex / ChatGPT

Este projeto utiliza o **VectorGov** para busca em legislação brasileira.

## Comandos do terminal

```bash
# Busca semântica
vectorgov search "pergunta sobre legislação"

# Busca inteligente (mais completa)
vectorgov smart-search "pergunta complexa"

# Consultar artigo
vectorgov lookup "Art. 75 da Lei 14.133"

# Busca exata
vectorgov grep "texto literal"

# Contexto completo para LLM
vectorgov context "pergunta" --format messages
```

## Como usar

1. Execute `vectorgov search` ou `vectorgov smart-search` para buscar legislação
2. Os resultados incluem texto dos dispositivos legais e referências
3. Use `--raw` ou `--output json` para saída processável
4. Cite sempre a fonte (Lei, Decreto, IN, artigo)
"""

ENV_EXAMPLE = """# VectorGov API Key
# Obtenha sua chave em https://vectorgov.io/playground
VECTORGOV_API_KEY=vg_sua_chave_aqui

# URL da API (opcional, padrão: https://vectorgov.io)
# VECTORGOV_BASE_URL=https://vectorgov.io
"""

EXAMPLE_SCRIPT = '''#!/usr/bin/env python3
"""Exemplo de uso do VectorGov SDK."""

from vectorgov import VectorGov

# Inicializa (usa VECTORGOV_API_KEY do ambiente)
vg = VectorGov()

# Busca simples
results = vg.search("O que é ETP?", top_k=5)
print(f"Encontrados: {results.total} resultados")

for hit in results:
    print(f"  [{getattr(hit, 'document_id', None) or getattr(hit, 'source', '')}] Art. {hit.article_number}: {hit.text}")

# Contexto para LLM
context = results.to_context()
messages = results.to_messages("O que é ETP?")

# Use com qualquer LLM:
# from openai import OpenAI
# resp = OpenAI().chat.completions.create(model="gpt-4o", messages=messages)
# print(resp.choices[0].message.content)
'''


def init(
    claude: bool = typer.Option(False, "--claude", help="Gerar CLAUDE.md para Claude Code"),
    cursor: bool = typer.Option(False, "--cursor", help="Gerar .cursorrules para Cursor AI"),
    codex: bool = typer.Option(False, "--codex", help="Gerar AGENTS.md para OpenAI Codex"),
    all_tools: bool = typer.Option(False, "--all", "-a", help="Gerar arquivos para todas as ferramentas AI"),
    directory: str = typer.Option(".", "--dir", "-d", help="Diretório do projeto"),
):
    """Inicializa projeto com configuração para ferramentas AI.

    Gera arquivos de instrução para que Claude Code, Cursor, Codex e outros
    saibam usar o VectorGov automaticamente nas sessões de AI.

    Exemplos:
        vectorgov init --claude          # Só CLAUDE.md
        vectorgov init --cursor          # Só .cursorrules
        vectorgov init --all             # Tudo: CLAUDE.md, .cursorrules, AGENTS.md, .env.example
        vectorgov init --all --dir ./meu-projeto
    """
    project_dir = Path(directory).resolve()

    if not project_dir.exists():
        console.print(f"[red]Erro:[/red] Diretório não encontrado: {project_dir}")
        raise typer.Exit(1)

    # Se nenhuma flag → gera tudo
    if not any([claude, cursor, codex, all_tools]):
        all_tools = True

    created = []

    # CLAUDE.md
    if claude or all_tools:
        path = project_dir / "CLAUDE.md"
        if path.exists():
            console.print(f"  [yellow]Já existe:[/yellow] {path.name} (pulando)")
        else:
            path.write_text(CLAUDE_MD.strip() + "\n", encoding="utf-8")
            created.append(path.name)

    # .cursorrules
    if cursor or all_tools:
        path = project_dir / ".cursorrules"
        if path.exists():
            console.print(f"  [yellow]Já existe:[/yellow] {path.name} (pulando)")
        else:
            path.write_text(CURSORRULES.strip() + "\n", encoding="utf-8")
            created.append(path.name)

    # AGENTS.md (Codex)
    if codex or all_tools:
        path = project_dir / "AGENTS.md"
        if path.exists():
            console.print(f"  [yellow]Já existe:[/yellow] {path.name} (pulando)")
        else:
            path.write_text(CODEX_MD.strip() + "\n", encoding="utf-8")
            created.append(path.name)

    # .env.example (sempre com --all)
    if all_tools:
        path = project_dir / ".env.example"
        if path.exists():
            console.print(f"  [yellow]Já existe:[/yellow] {path.name} (pulando)")
        else:
            path.write_text(ENV_EXAMPLE.strip() + "\n", encoding="utf-8")
            created.append(path.name)

    # example.py (sempre com --all)
    if all_tools:
        path = project_dir / "example_vectorgov.py"
        if path.exists():
            console.print(f"  [yellow]Já existe:[/yellow] {path.name} (pulando)")
        else:
            path.write_text(EXAMPLE_SCRIPT.strip() + "\n", encoding="utf-8")
            created.append(path.name)

    # Resumo
    if created:
        console.print(f"\n[green]Projeto inicializado![/green] Arquivos criados:")
        for name in created:
            console.print(f"  [cyan]✓[/cyan] {name}")
        console.print(f"\n[dim]Próximo passo: configure sua API key com 'vectorgov auth login'[/dim]")
    else:
        console.print("[yellow]Nenhum arquivo novo criado (todos já existem).[/yellow]")
