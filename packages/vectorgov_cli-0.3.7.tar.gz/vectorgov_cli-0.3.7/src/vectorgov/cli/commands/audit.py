"""Eventos de segurança da API (PII, injection, rate-limit).

IMPORTANTE: este módulo lida com **eventos de segurança**, NÃO com
requisições totais. Se seus requests são limpos (sem PII/injection/
rate-limit violations), é esperado que `audit stats` e `audit logs`
retornem zero — isso é um sinal positivo.

Para ver histórico de uso geral (total de requests, latência por
endpoint), acesse https://vectorgov.io/uso-api.
"""

import json
import typer
from rich.console import Console
from rich.table import Table
from ..utils.config import ConfigManager

app = typer.Typer(no_args_is_help=True)
console = Console()
config_manager = ConfigManager()


@app.command()
def logs(
    days: int = typer.Option(7, "--days", "-d", help="Período em dias (1-90)"),
    limit: int = typer.Option(20, "--limit", "-l", help="Máximo de registros"),
    output: str = typer.Option("table", "--output", "-o", help="Formato: table, json"),
):
    """Exibe logs de EVENTOS DE SEGURANÇA (PII, injection, rate-limit).

    Este comando NÃO lista suas requisições totais. Para isso, acesse
    https://vectorgov.io/uso-api (interface web).

    Zero eventos = seus requests estão limpos. É o comportamento esperado.

    Exemplo:
        vectorgov audit logs
        vectorgov audit logs --days 30 --limit 50
        vectorgov audit logs --output json
    """
    try:
        from vectorgov import VectorGov

        api_key = config_manager.get("api_key")
        if not api_key:
            console.print("[red]Erro:[/red] API key não configurada.")
            console.print("  Use [cyan]vectorgov auth login[/cyan] para configurar.")
            raise typer.Exit(1)

        if days < 1 or days > 90:
            console.print("[red]Erro:[/red] --days deve estar entre 1 e 90.")
            raise typer.Exit(1)

        vg = VectorGov(api_key=api_key)

        # Converter --days para start_date (ISO 8601)
        from datetime import datetime, timedelta
        start_date = (datetime.utcnow() - timedelta(days=days)).strftime("%Y-%m-%d")

        with console.status("[bold]Buscando logs de auditoria...[/bold]"):
            result = vg.get_audit_logs(limit=limit, start_date=start_date)

        # AuditLogsResponse has .logs (list of AuditLog)
        entries = result.logs if hasattr(result, "logs") else (result if isinstance(result, list) else [])

        # JSON output sempre emite, mesmo com entries vazias (array vazio).
        # Text output so mostra "Nenhum log" quando nao tem resultados.
        if output == "json":
            data = [
                {
                    "timestamp": getattr(e, "timestamp", getattr(e, "created_at", "")),
                    "event": getattr(e, "event_type", getattr(e, "event", "")),
                    "endpoint": getattr(e, "endpoint", ""),
                    "status": getattr(e, "status_code", ""),
                    "latency_ms": getattr(e, "latency_ms", 0),
                }
                for e in entries
            ]
            console.print_json(json.dumps(data, ensure_ascii=False))
            return

        if not entries:
            console.print("[yellow]Nenhum evento de segurança registrado.[/yellow]")
            console.print(
                "[dim]Isto é normal — significa que seus requests estão limpos "
                "(sem PII, injection ou rate-limit). Para histórico de uso geral, "
                "acesse [cyan]https://vectorgov.io/uso-api[/cyan].[/dim]"
            )
            return
        else:
            table = Table(title=f"Audit Logs (últimos {days} dias)")
            table.add_column("Data", style="dim", width=18)
            table.add_column("Evento", style="cyan", width=20)
            table.add_column("Endpoint", width=25)
            table.add_column("Status", justify="right", width=6)
            table.add_column("Latência", justify="right", width=8)
            for e in entries:
                ts = str(getattr(e, "timestamp", getattr(e, "created_at", "")))[:16]
                event = getattr(e, "event_type", getattr(e, "event", ""))
                endpoint = getattr(e, "endpoint", "")
                status = str(getattr(e, "status_code", ""))
                latency = getattr(e, "latency_ms", 0)
                lat_str = f"{latency:.0f}ms" if latency else "-"
                table.add_row(ts, event, endpoint, status, lat_str)
            console.print(table)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def stats(
    days: int = typer.Option(30, "--days", "-d", help="Período em dias"),
    output: str = typer.Option("text", "--output", "-o", help="Formato: text, json"),
):
    """Exibe estatísticas de EVENTOS DE SEGURANÇA (não de requests totais).

    Conta PII detectado, injection attempts, rate-limit violations e
    outros eventos de segurança registrados para sua API key.

    NÃO é o mesmo que total de requisições — zero eventos significa
    que seu uso está limpo (comportamento esperado).

    Para histórico geral de uso (requests, latência, endpoints),
    acesse https://vectorgov.io/uso-api.

    Exemplo:
        vectorgov audit stats
        vectorgov audit stats --days 7
    """
    try:
        from vectorgov import VectorGov

        api_key = config_manager.get("api_key")
        if not api_key:
            console.print("[red]Erro:[/red] API key não configurada.")
            console.print("  Use [cyan]vectorgov auth login[/cyan] para configurar.")
            raise typer.Exit(1)

        vg = VectorGov(api_key=api_key)

        with console.status("[bold]Carregando estatísticas...[/bold]"):
            result = vg.get_audit_stats(days=days)

        if output == "json":
            data = {
                "period_days": days,
                "total_requests": getattr(result, "total_requests", 0),
                "success_rate": getattr(result, "success_rate", 0),
                "avg_latency_ms": getattr(result, "avg_latency_ms", 0),
            }
            console.print_json(json.dumps(data, ensure_ascii=False))
        else:
            console.print(
                f"\n[bold]Eventos de segurança nos últimos {days} dias[/bold]"
            )
            console.print(
                "[dim](PII, injection, rate-limit — não é histórico de uso geral)[/dim]\n"
            )
            total = getattr(result, "total_requests", 0)
            success = getattr(result, "success_rate", 0)
            latency = getattr(result, "avg_latency_ms", 0)
            console.print(f"  Eventos registrados:   [cyan]{total}[/cyan]")
            console.print(f"  Taxa de sucesso:       [green]{success:.1f}%[/green]")
            console.print(f"  Latência média:        [yellow]{latency:.0f}ms[/yellow]")

            if total == 0:
                console.print(
                    "\n[dim]Zero eventos é o comportamento esperado para uso limpo. "
                    "Histórico de uso geral: [cyan]https://vectorgov.io/uso-api[/cyan][/dim]"
                )

            by_endpoint = getattr(result, "by_endpoint", {})
            if by_endpoint:
                console.print(f"\n  [bold]Por endpoint:[/bold]")
                for ep, count in by_endpoint.items():
                    console.print(f"    {ep}: {count}")

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
