"""Busca dual-path combinando semântica + índice curado."""

import json
import typer
from rich.console import Console
from rich.table import Table
from ..utils.config import ConfigManager
from ..utils.output import (
    extract_credits,
    extract_request_id,
    get_evidence_links,
    print_credits_footer,
    print_request_id_footer,
    render_evidence_lines_text,
    render_llm_output,
    resolve_output_format,
)

console = Console()
config_manager = ConfigManager()


def merged(
    query: str = typer.Argument(..., help="Pergunta jurídica"),
    top_k: int = typer.Option(10, "--top-k", "-k", help="Quantidade de resultados (1-50)"),
    document_id: str = typer.Option(
        None, "--doc", "-d",
        help="Filtrar por documento (ex: LEI-14133-2021)"
    ),
    token_budget: int = typer.Option(None, "--token-budget", help="Limite de tokens para contexto"),
    no_hybrid: bool = typer.Option(
        False, "--no-hybrid",
        help="Desabilita o backend semântico, usa só filesystem"
    ),
    no_filesystem: bool = typer.Option(
        False, "--no-filesystem",
        help="Desabilita o backend filesystem (índice curado), usa só hybrid"
    ),
    output: str = typer.Option("table", "--output", "-o", help="Formato: table, json, text, llm"),
    raw: bool = typer.Option(False, "--raw", help="JSON bruto para piping"),
):
    """Busca dual-path: combina semântica (vetores) + índice curado (filesystem).

    Usa Reciprocal Rank Fusion (RRF) para combinar resultados de ambos os caminhos.
    Ideal para consultas que precisam tanto de compreensão semântica quanto de precisão.

    Exemplo:
        vectorgov merged "Modalidades de licitação"
        vectorgov merged "Pesquisa de preços" --top-k 15 --output json
        vectorgov merged "art. 75" --doc LEI-14133-2021
        vectorgov merged "licitação" --no-filesystem    # só hybrid
        vectorgov merged "dispensa" --no-hybrid         # só filesystem
    """
    try:
        from vectorgov import VectorGov

        api_key = config_manager.get("api_key")
        if not api_key:
            console.print("[red]Erro:[/red] API key não configurada.")
            console.print("  Use [cyan]vectorgov auth login[/cyan] para configurar.")
            raise typer.Exit(1)

        if top_k < 1 or top_k > 50:
            console.print("[red]Erro:[/red] --top-k deve estar entre 1 e 50.")
            raise typer.Exit(1)

        if no_hybrid and no_filesystem:
            console.print(
                "[red]Erro:[/red] --no-hybrid e --no-filesystem não podem "
                "ser usados juntos (deixa merged sem backends)."
            )
            raise typer.Exit(1)

        effective_output = resolve_output_format(output, is_raw=raw)

        vg = VectorGov(api_key=api_key)

        merged_kwargs = dict(
            query=query,
            top_k=top_k,
            enable_hybrid=not no_hybrid,
            enable_filesystem=not no_filesystem,
        )
        if document_id:
            merged_kwargs["document_id"] = document_id
        if token_budget is not None:
            merged_kwargs["token_budget"] = token_budget

        with console.status("[bold]Buscando em dual-path...[/bold]"):
            result = vg.merged(**merged_kwargs)

        hits = getattr(result, "results", getattr(result, "hits", []))
        if not isinstance(hits, list):
            hits = []

        if effective_output == "raw":
            data = {
                "query": query,
                "total": len(hits),
                "request_id": extract_request_id(result),
                "mutual_count": getattr(result, "mutual_count", None),
                "hybrid_count": getattr(result, "hybrid_count", None),
                "filesystem_count": getattr(result, "filesystem_count", None),
                "token_total": getattr(result, "token_total", None),
                "token_budget": getattr(result, "token_budget", None),
                "latency_ms": getattr(result, "latency_ms", None),
                "hits": [
                    {
                        "text": getattr(h, "text", str(h)),
                        "source": getattr(h, "source", ""),
                        "sources": getattr(h, "sources", []),
                        "score": getattr(h, "score", 0),
                        "hybrid_score": getattr(h, "hybrid_score", None),
                        "filesystem_score": getattr(h, "filesystem_score", None),
                        "document_id": getattr(h, "document_id", ""),
                        "span_id": getattr(h, "span_id", ""),
                        "path": getattr(h, "path", ""),
                        "breadcrumb": getattr(h, "breadcrumb", ""),
                        **get_evidence_links(h),
                    }
                    for h in hits
                ],
            }
            print(json.dumps(data, ensure_ascii=False, indent=2))
            return

        if not hits:
            console.print("[yellow]Nenhum resultado encontrado.[/yellow]")
            raise typer.Exit(0)

        if effective_output == "llm":
            metadata = {
                "total": len(hits),
                "latency_ms": getattr(result, "latency_ms", None),
                "query_id": None,
                "request_id": extract_request_id(result),
                "credits": extract_credits(result),
            }
            print(render_llm_output(hits, query, metadata))
            return

        if output == "json":
            data = {
                "request_id": extract_request_id(result),
                "hits": [
                    {"source": getattr(h, "source", ""), "score": getattr(h, "score", 0),
                     "text": getattr(h, "text", str(h)), "path": getattr(h, "path", "")}
                    for h in hits
                ],
            }
            console.print_json(json.dumps(data, ensure_ascii=False))
        elif output == "table":
            table = Table(title=f"Merged Search ({len(hits)} resultados)")
            table.add_column("#", style="dim", width=3)
            table.add_column("Fonte", style="cyan", width=30)
            table.add_column("Texto", overflow="fold")
            table.add_column("Score", justify="right", width=6)
            for i, h in enumerate(hits, 1):
                source = getattr(h, "source", getattr(h, "document_id", ""))
                score = getattr(h, "score", 0)
                text = getattr(h, "text", str(h))
                table.add_row(str(i), source, text, f"{score:.2f}" if score else "-")
            console.print(table)
        else:
            for i, h in enumerate(hits, 1):
                source = getattr(h, "source", getattr(h, "document_id", ""))
                console.print(f"\n[cyan][{i}][/cyan] [bold]{source}[/bold]")
                console.print(f"  {getattr(h, 'text', str(h))}")
                for line in render_evidence_lines_text(h):
                    console.print(f"[dim]{line}[/dim]")

        print_request_id_footer(console, extract_request_id(result))
        print_credits_footer(console, result)

    except typer.Exit:
        # typer.Exit(0) usado para "nenhum resultado" nao deve ser tratado
        # como erro pelo handler geral abaixo.
        raise
    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
