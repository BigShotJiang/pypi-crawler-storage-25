"""
Comando de documentos do CLI VectorGov.
"""

import json
import re
import typer
from rich.console import Console
from rich.table import Table

from ..utils.config import ConfigManager
from ..utils.output import extract_request_id, print_request_id_footer

app = typer.Typer(no_args_is_help=True)
console = Console()
config_manager = ConfigManager()


def _derive_title_from_doc_id(doc_id: str) -> str:
    """Deriva um titulo humano do document_id quando o backend nao retorna
    o titulo (acontece com acordaos e alguns docs).

    Exemplos:
        LEI-14.133-2021       -> "Lei 14.133/2021"
        DECRETO-10.947-2022   -> "Decreto 10.947/2022"
        IN-65-2021            -> "IN 65/2021"
        PORTARIA-8.678-2021   -> "Portaria 8.678/2021"
        AC-1.852-2.020-P      -> "Acordao 1.852/2020 (Plenario)"
        AC-2.450-2.025-2C     -> "Acordao 2.450/2025 (2a Camara)"
    """
    if not doc_id:
        return ""

    # Acordaos: AC-<num>-<ano>-<colegiado>
    m = re.match(r"^AC-([\d.]+)-([\d.]+)-(P|1C|2C)$", doc_id)
    if m:
        num, ano, col = m.groups()
        ano_clean = ano.replace(".", "")
        colegiado = {"P": "Plenario", "1C": "1a Camara", "2C": "2a Camara"}.get(col, col)
        return f"Acordao {num}/{ano_clean} ({colegiado})"

    # Leis/Decretos/INs/Portarias: TIPO-<num>-<ano>
    m = re.match(r"^(LEI|DECRETO|IN|PORTARIA|RESOLUCAO|INSTRUCAO)-([\d.]+)-(\d{4})$", doc_id, re.IGNORECASE)
    if m:
        tipo_upper, num, ano = m.groups()
        tipo_map = {
            "LEI": "Lei",
            "DECRETO": "Decreto",
            "IN": "IN",
            "PORTARIA": "Portaria",
            "RESOLUCAO": "Resolucao",
            "INSTRUCAO": "Instrucao",
        }
        tipo = tipo_map.get(tipo_upper.upper(), tipo_upper.capitalize())
        return f"{tipo} {num}/{ano}"

    # Fallback: retorna o proprio doc_id formatado
    return doc_id


@app.command("list")
def list_docs(
    page: int = typer.Option(1, "--page", "-p", help="Página (1+)"),
    limit: int = typer.Option(50, "--limit", "-l", help="Itens por página (1-100)"),
    output: str = typer.Option("table", "--output", "-o", help="Formato: table, json"),
):
    """
    Lista documentos disponíveis na base.

    Exemplos:
        vectorgov docs list
        vectorgov docs list --page 2 --limit 20
        vectorgov docs list --output json
    """
    # Obtém API key
    api_key = config_manager.get("api_key")
    if not api_key:
        console.print("[red]Erro:[/red] API key não configurada.")
        console.print("  Use 'vectorgov auth login' para configurar.")
        raise typer.Exit(1)

    if page < 1:
        console.print("[red]Erro:[/red] --page deve ser >= 1.")
        raise typer.Exit(1)
    if limit < 1 or limit > 100:
        console.print("[red]Erro:[/red] --limit deve estar entre 1 e 100.")
        raise typer.Exit(1)

    try:
        from vectorgov import VectorGov

        vg = VectorGov(api_key=api_key)
        resp = vg.list_documents(page=page, limit=limit)
        # SDK v0.16 retorna DocumentsResponse com atributo .documents
        doc_list = getattr(resp, "documents", resp) or []

        if output == "json":
            def _title_or_derived(d) -> str:
                """Le titulo do backend; se vazio, deriva do document_id."""
                t = getattr(d, "titulo", None) or getattr(d, "title", None) or ""
                if t:
                    return t
                doc_id = getattr(d, "document_id", None) or getattr(d, "id", "")
                return _derive_title_from_doc_id(doc_id)

            data = {
                "request_id": extract_request_id(resp),
                "documents": [
                    {
                        "id": getattr(d, "document_id", getattr(d, "id", "")),
                        "title": _title_or_derived(d),
                        "type": getattr(d, "tipo_documento", getattr(d, "type", "")),
                        "year": getattr(d, "ano", getattr(d, "year", "")),
                        "chunks": getattr(d, "chunks_count", 0),
                    }
                    for d in doc_list
                ],
            }
            console.print_json(json.dumps(data, ensure_ascii=False))
        else:
            table = Table(title="Documentos Disponíveis")
            table.add_column("ID", style="cyan")
            table.add_column("Título", overflow="fold")
            table.add_column("Tipo", style="green")
            table.add_column("Ano", justify="right")
            table.add_column("Chunks", justify="right")

            for d in doc_list:
                doc_id = getattr(d, "document_id", getattr(d, "id", ""))
                titulo = getattr(d, "titulo", getattr(d, "title", "")) or ""
                if not titulo:
                    titulo = _derive_title_from_doc_id(str(doc_id))
                tipo = getattr(d, "tipo_documento", getattr(d, "type", ""))
                ano = getattr(d, "ano", getattr(d, "year", ""))
                chunks = getattr(d, "chunks_count", 0)
                table.add_row(
                    str(doc_id),
                    str(titulo),
                    str(tipo),
                    str(ano),
                    str(chunks),
                )

            console.print(table)
            total = getattr(resp, "total", len(doc_list))
            pages = getattr(resp, "pages", 1)
            console.print(
                f"\nPágina [cyan]{page}[/cyan]/[cyan]{pages}[/cyan]  "
                f"•  Total na base: [cyan]{total}[/cyan] documentos  "
                f"•  Mostrando: [cyan]{len(doc_list)}[/cyan]"
            )
            print_request_id_footer(console, extract_request_id(resp))

    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)


@app.command("info")
def doc_info(
    document_id: str = typer.Argument(..., help="ID do documento"),
):
    """
    Mostra informações detalhadas de um documento.

    Exemplos:
        vectorgov docs info LEI-14133-2021
        vectorgov docs info IN-58-2022
    """
    # Obtém API key
    api_key = config_manager.get("api_key")
    if not api_key:
        console.print("[red]Erro:[/red] API key não configurada.")
        console.print("  Use 'vectorgov auth login' para configurar.")
        raise typer.Exit(1)

    try:
        from vectorgov import VectorGov

        vg = VectorGov(api_key=api_key)

        doc = None
        try:
            doc = vg.get_document(document_id)
        except Exception:
            # Fallback: try to find the document in list_documents (e.g. 404)
            try:
                all_docs = vg.list_documents()
                for d in all_docs:
                    d_id = getattr(d, "document_id", getattr(d, "id", ""))
                    if str(d_id) == document_id:
                        doc = d
                        break
            except Exception:
                pass

        if doc is None:
            console.print(f"[red]Erro:[/red] Documento '{document_id}' não encontrado.")
            raise typer.Exit(1)

        titulo = getattr(doc, "titulo", getattr(doc, "title", "")) or ""
        doc_id = getattr(doc, "document_id", getattr(doc, "id", ""))
        if not titulo:
            titulo = _derive_title_from_doc_id(str(doc_id))
        tipo = getattr(doc, "tipo_documento", getattr(doc, "type", ""))
        ano = getattr(doc, "ano", getattr(doc, "year", ""))
        chunks = getattr(doc, "chunks_count", 0)

        console.print(f"\n[bold]{titulo}[/bold]")
        console.print(f"ID: [cyan]{doc_id}[/cyan]")
        console.print(f"Tipo: [green]{tipo}[/green]")
        console.print(f"Ano: {ano}")
        console.print(f"Chunks: {chunks}")

        if hasattr(doc, 'description') and doc.description:
            console.print(f"\nDescrição: {doc.description}")

        print_request_id_footer(console, extract_request_id(doc))

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Erro:[/red] {e}")
        raise typer.Exit(1)
