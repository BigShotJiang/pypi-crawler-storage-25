"""
Tests for TraceBuilder, StepContext, and auto-instrumentation decorators.
"""
import asyncio
import time
import warnings
import pytest
from unittest.mock import Mock, AsyncMock, patch

from infinium import TaskData
from infinium.tracing import (
    TraceBuilder, StepContext, trace_agent, async_trace_agent,
)
from infinium.types import (
    ExecutionStep, ErrorDetail, ToolCall, LlmCall,
    ExpectedOutcome, EnvironmentContext, LlmUsage, Research,
)


class TestStepContext:
    def test_basic_step(self):
        ctx = StepContext(1, "search", "Search database")
        with ctx:
            ctx.set_input("query: AAPL")
            ctx.set_output("Found 5 results")

        step = ctx._build()
        assert step.step_number == 1
        assert step.action == "search"
        assert step.input_preview == "query: AAPL"
        assert step.output_preview == "Found 5 results"
        assert step.duration_ms is not None
        assert step.duration_ms >= 0

    def test_step_timing(self):
        ctx = StepContext(1, "slow", "Slow operation")
        with ctx:
            time.sleep(0.05)

        step = ctx._build()
        assert step.duration_ms >= 40  # Allow some tolerance

    def test_step_captures_exception(self):
        ctx = StepContext(1, "fail", "This will fail")
        with pytest.raises(ValueError, match="boom"):
            with ctx:
                raise ValueError("boom")

        step = ctx._build()
        assert step.error is not None
        assert step.error.error_type == "ValueError"
        assert step.error.message == "boom"
        assert step.error.recoverable is False
        assert step.error.stack_trace is not None

    def test_step_does_not_suppress_exception(self):
        ctx = StepContext(1, "fail", "Fail step")
        with pytest.raises(RuntimeError):
            with ctx:
                raise RuntimeError("not suppressed")

    def test_record_tool_call(self):
        ctx = StepContext(1, "tool_use", "Call API")
        with ctx:
            ctx.record_tool_call(
                "github_api", duration_ms=230, output_summary="3 repos", http_status=200
            )

        step = ctx._build()
        assert step.tool_call is not None
        assert step.tool_call.tool_name == "github_api"
        assert step.tool_call.duration_ms == 230
        assert step.tool_call.http_status == 200

    def test_record_llm_call(self):
        ctx = StepContext(1, "llm_inference", "Summarize")
        with ctx:
            ctx.record_llm_call(
                "gpt-4o", provider="openai", prompt_tokens=2000,
                completion_tokens=500, latency_ms=3200
            )

        step = ctx._build()
        assert step.llm_call is not None
        assert step.llm_call.model == "gpt-4o"
        assert step.llm_call.prompt_tokens == 2000

    def test_set_metadata(self):
        ctx = StepContext(1, "action", "desc")
        with ctx:
            ctx.set_metadata({"key": "value"})

        step = ctx._build()
        assert step.metadata == {"key": "value"}

    def test_input_truncation(self):
        ctx = StepContext(1, "a", "d")
        with ctx:
            ctx.set_input("x" * 1000)

        step = ctx._build()
        assert len(step.input_preview) <= 500

    def test_output_truncation(self):
        ctx = StepContext(1, "a", "d")
        with ctx:
            ctx.set_output("y" * 1000)

        step = ctx._build()
        assert len(step.output_preview) <= 500

    def test_fluent_returns_self(self):
        ctx = StepContext(1, "a", "d")
        assert ctx.set_input("x") is ctx
        assert ctx.set_output("y") is ctx
        assert ctx.record_tool_call("t") is ctx
        assert ctx.record_llm_call("m") is ctx
        assert ctx.set_metadata({}) is ctx


class TestTraceBuilder:
    def test_basic_build(self):
        trace = TraceBuilder("Test", "Description")
        td = trace.build()

        assert isinstance(td, TaskData)
        assert td.name == "Test"
        assert td.description == "Description"
        assert td.duration >= 0
        assert td.current_datetime is not None
        assert td.environment is not None
        assert td.environment.python_version is not None

    def test_with_steps(self):
        trace = TraceBuilder("Multi-step", "Multi-step task")
        with trace.step("search", "Search"):
            pass
        with trace.step("analyze", "Analyze"):
            pass
        with trace.step("report", "Report"):
            pass

        td = trace.build()
        assert len(td.steps) == 3
        assert td.steps[0].step_number == 1
        assert td.steps[1].step_number == 2
        assert td.steps[2].step_number == 3

    def test_auto_computed_duration(self):
        trace = TraceBuilder("Timed", "Timed task")
        time.sleep(0.05)
        td = trace.build()
        assert td.duration >= 0.04

    def test_set_expected_outcome(self):
        trace = TraceBuilder("T", "D")
        trace.set_expected_outcome(
            task_objective="Do something",
            required_deliverables=["A", "B"],
            constraints=["C1"],
        )
        td = trace.build()
        assert td.expected_outcome is not None
        assert td.expected_outcome.task_objective == "Do something"
        assert len(td.expected_outcome.required_deliverables) == 2

    def test_set_environment(self):
        trace = TraceBuilder("T", "D")
        trace.set_environment(framework="langchain", runtime="docker")
        td = trace.build()
        assert td.environment.framework == "langchain"
        assert td.environment.runtime == "docker"
        assert td.environment.sdk_version is not None

    def test_set_summaries(self):
        trace = TraceBuilder("T", "D")
        trace.set_input_summary("Input")
        trace.set_output_summary("Output")
        td = trace.build()
        assert td.input_summary == "Input"
        assert td.output_summary == "Output"

    def test_set_llm_usage(self):
        trace = TraceBuilder("T", "D")
        trace.set_llm_usage(LlmUsage(model="gpt-4o", total_tokens=5000))
        td = trace.build()
        assert td.llm_usage.model == "gpt-4o"

    def test_set_section(self):
        trace = TraceBuilder("T", "D")
        trace.set_section("research", Research(research_topic="AI"))
        td = trace.build()
        assert td.research.research_topic == "AI"

    def test_add_error(self):
        trace = TraceBuilder("T", "D")
        trace.add_error(ErrorDetail(error_type="APIError", message="Failed"))
        td = trace.build()
        assert len(td.errors) == 1
        assert td.errors[0].error_type == "APIError"

    def test_no_steps_gives_none(self):
        trace = TraceBuilder("T", "D")
        td = trace.build()
        assert td.steps is None

    def test_no_errors_gives_none(self):
        trace = TraceBuilder("T", "D")
        td = trace.build()
        assert td.errors is None

    def test_fluent_setters_return_self(self):
        trace = TraceBuilder("T", "D")
        assert trace.set_input_summary("i") is trace
        assert trace.set_output_summary("o") is trace
        assert trace.set_expected_outcome("obj") is trace
        assert trace.set_environment(framework="f") is trace
        assert trace.set_llm_usage(LlmUsage()) is trace
        assert trace.set_section("general", None) is trace
        assert trace.add_error(ErrorDetail(error_type="E", message="m")) is trace


class TestTraceAgentDecorator:
    def test_sync_decorator_captures_result(self):
        mock_client = Mock()
        mock_client.send_task_data = Mock()

        @trace_agent("Test Op", client=mock_client)
        def my_func(x):
            return x * 2

        result = my_func(5)
        assert result == 10
        mock_client.send_task_data.assert_called_once()

        # Inspect the TaskData sent
        td = mock_client.send_task_data.call_args[0][0]
        assert isinstance(td, TaskData)
        assert td.name == "Test Op"
        assert td.output_summary is not None

    def test_sync_decorator_captures_exception(self):
        mock_client = Mock()

        @trace_agent("Failing Op", client=mock_client)
        def fail_func():
            raise RuntimeError("kaboom")

        with pytest.raises(RuntimeError, match="kaboom"):
            fail_func()

        # Should still auto-send even on failure
        mock_client.send_task_data.assert_called_once()
        td = mock_client.send_task_data.call_args[0][0]
        assert td.errors is not None
        assert td.errors[0].error_type == "RuntimeError"

    def test_sync_decorator_no_auto_send(self):
        mock_client = Mock()

        @trace_agent("No Send", client=mock_client, auto_send=False)
        def func():
            return "ok"

        func()
        mock_client.send_task_data.assert_not_called()

    def test_sync_decorator_no_client(self):
        @trace_agent("No Client", client=None, auto_send=True)
        def func():
            return "ok"

        result = func()
        assert result == "ok"  # Should not crash

    def test_sync_decorator_uses_docstring(self):
        mock_client = Mock()

        @trace_agent("Op", client=mock_client)
        def documented_func():
            """This is the docstring."""
            return 42

        documented_func()
        td = mock_client.send_task_data.call_args[0][0]
        assert td.description == "This is the docstring."

    def test_sync_decorator_send_failure_doesnt_crash(self):
        mock_client = Mock()
        mock_client.send_task_data.side_effect = Exception("send failed")

        @trace_agent("Op", client=mock_client)
        def func():
            return "ok"

        result = func()
        assert result == "ok"  # Function result still returned


class TestAsyncTraceAgentDecorator:
    async def test_async_decorator_captures_result(self):
        mock_client = AsyncMock()

        @async_trace_agent("Async Op", client=mock_client)
        async def my_func(x):
            return x * 3

        result = await my_func(4)
        assert result == 12
        mock_client.send_task_data.assert_called_once()

    async def test_async_decorator_captures_exception(self):
        mock_client = AsyncMock()

        @async_trace_agent("Failing Async", client=mock_client)
        async def fail_func():
            raise ValueError("async boom")

        with pytest.raises(ValueError, match="async boom"):
            await fail_func()

        mock_client.send_task_data.assert_called_once()
        td = mock_client.send_task_data.call_args[0][0]
        assert td.errors[0].error_type == "ValueError"

    async def test_async_decorator_no_auto_send(self):
        mock_client = AsyncMock()

        @async_trace_agent("No Send", client=mock_client, auto_send=False)
        async def func():
            return "ok"

        await func()
        mock_client.send_task_data.assert_not_called()
