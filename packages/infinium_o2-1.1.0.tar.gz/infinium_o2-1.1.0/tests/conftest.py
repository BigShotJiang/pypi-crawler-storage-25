"""
Test configuration and fixtures.
"""
import pytest
import httpx
from typing import Any, Dict
from unittest.mock import AsyncMock, Mock

from infinium import InfiniumClient, AsyncInfiniumClient, TaskData


@pytest.fixture
def agent_credentials():
    """Test agent credentials."""
    return {
        "agent_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
        "agent_secret": "test-secret-456-long-enough"
    }


@pytest.fixture
def client(agent_credentials):
    """Synchronous client for testing."""
    return InfiniumClient(
        agent_id=agent_credentials["agent_id"],
        agent_secret=agent_credentials["agent_secret"],
        enable_rate_limiting=False
    )


@pytest.fixture
def async_client(agent_credentials):
    """Asynchronous client for testing."""
    return AsyncInfiniumClient(
        agent_id=agent_credentials["agent_id"],
        agent_secret=agent_credentials["agent_secret"],
        enable_rate_limiting=False
    )


@pytest.fixture
def sample_task_data():
    """Sample task data for testing."""
    return TaskData(
        name="Test Task",
        description="A test task for unit testing",
        current_datetime="2025-10-07T12:00:00Z",
        duration=120.5,
    )


@pytest.fixture
def mock_success_response():
    """Mock successful API response."""
    return {
        "status": "success",
        "message": "Task sent successfully",
        "data": {
            "task_id": "task-123",
            "created_at": "2025-10-07T12:00:00Z"
        }
    }


@pytest.fixture
def mock_httpx_response(mock_success_response):
    """Mock httpx response."""
    response = Mock(spec=httpx.Response)
    response.status_code = 200
    response.is_success = True
    response.json.return_value = mock_success_response
    response.content = b'{"status": "success"}'
    response.headers = {}
    return response


@pytest.fixture
def mock_httpx_client(mock_httpx_response):
    """Mock httpx client."""
    client = Mock(spec=httpx.Client)
    client.request.return_value = mock_httpx_response
    client.close = Mock()
    return client


@pytest.fixture
def mock_async_httpx_client(mock_httpx_response):
    """Mock async httpx client."""
    client = AsyncMock(spec=httpx.AsyncClient)
    client.request.return_value = mock_httpx_response
    client.aclose = AsyncMock()
    client.is_closed = False
    return client
