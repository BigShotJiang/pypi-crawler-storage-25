"""
Extended coverage tests for LLM provider adapters, OTel exporter,
and client get_prompt / prompt request methods.

All provider SDKs are mocked — no real API calls are made.
"""
import time
import asyncio
import pytest
from unittest.mock import Mock, AsyncMock, MagicMock, patch, PropertyMock
from dataclasses import dataclass

from infinium import (
    InfiniumClient, AsyncInfiniumClient, TaskData,
    InfiniumError, ValidationError, NotFoundError, AuthenticationError,
    ServerError, RateLimitError, InfiniumTimeoutError,
)
from infinium.integrations._context import (
    CapturedLlmCall,
    CapturedPromptFetch,
    TraceContext,
    get_current_trace_context,
    set_trace_context,
)
from infinium.integrations.openai import (
    patch_openai_client,
    patch_async_openai_client,
    _detect_provider,
    _truncate,
    _extract_content_from_messages,
    _extract_output as openai_extract_output,
    _StreamWrapper as OpenAIStreamWrapper,
    _AsyncStreamWrapper as OpenAIAsyncStreamWrapper,
)
from infinium.integrations.anthropic import (
    patch_anthropic_client,
    patch_async_anthropic_client,
    _extract_input as anthropic_extract_input,
    _extract_output as anthropic_extract_output,
    _StreamWrapper as AnthropicStreamWrapper,
    _AsyncStreamWrapper as AnthropicAsyncStreamWrapper,
)
from infinium.integrations.google import (
    patch_google_model,
    _extract_input as google_extract_input,
    _extract_output as google_extract_output,
    _extract_usage as google_extract_usage,
    _StreamWrapper as GoogleStreamWrapper,
    _AsyncStreamWrapper as GoogleAsyncStreamWrapper,
)
from infinium.integrations import watch


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_openai_response(model="gpt-4o", prompt_tokens=100, completion_tokens=50, content="Hello"):
    usage = Mock()
    usage.prompt_tokens = prompt_tokens
    usage.completion_tokens = completion_tokens
    message = Mock()
    message.content = content
    choice = Mock()
    choice.message = message
    response = Mock()
    response.model = model
    response.usage = usage
    response.choices = [choice]
    return response


def _make_openai_client(response=None):
    if response is None:
        response = _make_openai_response()
    create_fn = Mock(return_value=response)
    completions = Mock()
    completions.create = create_fn
    chat = Mock()
    chat.completions = completions
    client = Mock()
    client.chat = chat
    type(client).__name__ = "OpenAI"
    type(client).__module__ = "openai._client"
    return client


def _make_async_openai_client(response=None):
    if response is None:
        response = _make_openai_response()
    create_fn = AsyncMock(return_value=response)
    completions = Mock()
    completions.create = create_fn
    chat = Mock()
    chat.completions = completions
    client = Mock()
    client.chat = chat
    type(client).__name__ = "AsyncOpenAI"
    type(client).__module__ = "openai._async_client"
    return client


def _make_anthropic_response(model="claude-3-5-sonnet", input_tokens=200, output_tokens=80):
    usage = Mock()
    usage.input_tokens = input_tokens
    usage.output_tokens = output_tokens
    text_block = Mock()
    text_block.text = "Anthropic says hello"
    response = Mock()
    response.model = model
    response.usage = usage
    response.content = [text_block]
    return response


def _make_anthropic_client(response=None):
    if response is None:
        response = _make_anthropic_response()
    create_fn = Mock(return_value=response)
    messages = Mock()
    messages.create = create_fn
    client = Mock()
    client.messages = messages
    type(client).__name__ = "Anthropic"
    type(client).__module__ = "anthropic._client"
    return client


def _make_async_anthropic_client(response=None):
    if response is None:
        response = _make_anthropic_response()
    create_fn = AsyncMock(return_value=response)
    messages = Mock()
    messages.create = create_fn
    client = Mock()
    client.messages = messages
    type(client).__name__ = "AsyncAnthropic"
    type(client).__module__ = "anthropic._async_client"
    return client


def _make_google_response(prompt_tokens=150, completion_tokens=60, text="Gemini says hello"):
    meta = Mock()
    meta.prompt_token_count = prompt_tokens
    meta.candidates_token_count = completion_tokens
    response = Mock()
    response.text = text
    response.usage_metadata = meta
    return response


def _make_google_model(response=None, async_response=None):
    if response is None:
        response = _make_google_response()
    model = Mock()
    model.model_name = "gemini-1.5-pro"
    model.generate_content = Mock(return_value=response)
    if async_response is not None:
        model.generate_content_async = AsyncMock(return_value=async_response)
    else:
        model.generate_content_async = AsyncMock(return_value=response)
    type(model).__name__ = "GenerativeModel"
    type(model).__module__ = "google.generativeai.generative_models"
    return model


def _client_factory():
    return InfiniumClient(
        agent_id="a1b2c3d4-e5f6-7890-abcd-ef1234567890",
        agent_secret="test-secret-456-long-enough",
        enable_rate_limiting=False,
    )


def _async_client_factory():
    return AsyncInfiniumClient(
        agent_id="a1b2c3d4-e5f6-7890-abcd-ef1234567890",
        agent_secret="test-secret-456-long-enough",
        enable_rate_limiting=False,
    )


# ---------------------------------------------------------------------------
# OpenAI: helpers
# ---------------------------------------------------------------------------

class TestOpenAIHelpers:
    def test_truncate_none(self):
        assert _truncate(None) is None

    def test_truncate_short(self):
        assert _truncate("hello") == "hello"

    def test_truncate_long(self):
        long_text = "a" * 600
        result = _truncate(long_text)
        assert result.endswith("...")
        assert len(result) == 503  # 500 + "..."

    def test_extract_content_no_capture(self):
        assert _extract_content_from_messages([{"role": "user", "content": "Hi"}], False) is None

    def test_extract_content_empty_messages(self):
        assert _extract_content_from_messages([], True) is None

    def test_extract_content_filters_roles(self):
        messages = [
            {"role": "system", "content": "Be helpful"},
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "I should be excluded from preview"},
        ]
        result = _extract_content_from_messages(messages, True)
        assert result is not None
        assert "system" in result
        assert "Hello" in result

    def test_extract_output_no_capture(self):
        assert openai_extract_output(Mock(), False) is None

    def test_extract_output_missing_choices(self):
        response = Mock()
        response.choices = []
        assert openai_extract_output(response, True) is None

    def test_detect_provider_grok(self):
        client = Mock()
        client.base_url = "https://api.x.ai/v1/chat"
        assert _detect_provider(client) == "xai"

    def test_detect_provider_no_base_url(self):
        client = Mock(spec=[])  # no base_url attribute
        assert _detect_provider(client) == "openai"


# ---------------------------------------------------------------------------
# OpenAI: sync stream context manager
# ---------------------------------------------------------------------------

class TestOpenAISyncStreamContextManager:
    def test_stream_with_context_manager(self):
        call = CapturedLlmCall(provider="openai", model="gpt-4o")
        inner_stream = Mock()
        inner_stream.__enter__ = Mock(return_value=inner_stream)
        inner_stream.__exit__ = Mock(return_value=False)
        inner_stream.__iter__ = Mock(return_value=iter([]))

        wrapper = OpenAIStreamWrapper(inner_stream, call, capture_content=False)
        with wrapper as w:
            assert w is wrapper
            inner_stream.__enter__.assert_called_once()

        # __exit__ should finalise
        assert wrapper._finalised
        inner_stream.__exit__.assert_called_once()

    def test_double_finalise_is_safe(self):
        call = CapturedLlmCall(provider="openai", model="gpt-4o")
        wrapper = OpenAIStreamWrapper(iter([]), call, capture_content=False)
        wrapper._finalise()
        latency_first = call.latency_ns
        wrapper._finalise()
        assert call.latency_ns == latency_first

    def test_stream_without_context_manager_support(self):
        """Stream that doesn't have __enter__/__exit__."""
        call = CapturedLlmCall(provider="openai", model="gpt-4o")
        plain_iter = iter([])
        wrapper = OpenAIStreamWrapper(plain_iter, call, capture_content=False)
        with wrapper:
            pass
        assert wrapper._finalised

    def test_chunk_with_no_delta_content(self):
        """Chunk where delta.content is None — should not accumulate."""
        call = CapturedLlmCall(provider="openai", model="gpt-4o")
        chunk = Mock()
        delta = Mock()
        delta.content = None
        choice = Mock()
        choice.delta = delta
        chunk.choices = [choice]
        chunk.usage = None

        wrapper = OpenAIStreamWrapper(iter([chunk]), call, capture_content=True)
        list(wrapper)
        assert call.output_preview is None


# ---------------------------------------------------------------------------
# OpenAI: async stream
# ---------------------------------------------------------------------------

class TestOpenAIAsyncStream:
    async def test_async_stream_iteration(self):
        call = CapturedLlmCall(provider="openai", model="gpt-4o")

        chunk1 = Mock()
        delta1 = Mock()
        delta1.content = "Hi"
        choice1 = Mock()
        choice1.delta = delta1
        chunk1.choices = [choice1]
        chunk1.usage = None

        chunk2 = Mock()
        delta2 = Mock()
        delta2.content = " there"
        choice2 = Mock()
        choice2.delta = delta2
        chunk2.choices = [choice2]
        usage = Mock()
        usage.prompt_tokens = 10
        usage.completion_tokens = 5
        chunk2.usage = usage

        async def async_gen():
            yield chunk1
            yield chunk2

        wrapper = OpenAIAsyncStreamWrapper(async_gen().__aiter__(), call, capture_content=True)
        collected = []
        async for c in wrapper:
            collected.append(c)

        assert len(collected) == 2
        assert call.prompt_tokens == 10
        assert call.completion_tokens == 5
        assert call.output_preview == "Hi there"
        assert call.latency_ns is not None

    async def test_async_stream_context_manager(self):
        call = CapturedLlmCall(provider="openai", model="gpt-4o")
        inner = AsyncMock()
        inner.__aenter__ = AsyncMock(return_value=inner)
        inner.__aexit__ = AsyncMock(return_value=False)

        wrapper = OpenAIAsyncStreamWrapper(inner, call, capture_content=False)
        async with wrapper as w:
            assert w is wrapper
        assert wrapper._finalised

    async def test_async_stream_without_context_manager(self):
        call = CapturedLlmCall(provider="openai", model="gpt-4o")
        inner = Mock(spec=[])  # no __aenter__

        async def empty_gen():
            return
            yield  # make it an async generator

        wrapper = OpenAIAsyncStreamWrapper(empty_gen().__aiter__(), call, capture_content=False)
        async with wrapper:
            pass
        assert wrapper._finalised

    async def test_async_error_captured(self):
        client = _make_async_openai_client()
        client.chat.completions.create = AsyncMock(side_effect=RuntimeError("API down"))
        patch_async_openai_client(client)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            with pytest.raises(RuntimeError, match="API down"):
                await client.chat.completions.create(model="gpt-4o", messages=[])
        finally:
            set_trace_context(None)

        assert len(ctx.calls) == 1
        assert ctx.calls[0].error_type == "RuntimeError"

    async def test_async_stream_returns_wrapper(self):
        async def fake_stream():
            yield Mock()

        client = _make_async_openai_client()
        client.chat.completions.create = AsyncMock(return_value=fake_stream())
        patch_async_openai_client(client, capture_content=True)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            result = await client.chat.completions.create(
                model="gpt-4o", messages=[], stream=True
            )
            assert isinstance(result, OpenAIAsyncStreamWrapper)
        finally:
            set_trace_context(None)

    async def test_async_no_context_passthrough(self):
        client = _make_async_openai_client()
        original_create = client.chat.completions.create
        patch_async_openai_client(client)

        # No TraceContext set
        result = await client.chat.completions.create(model="gpt-4o", messages=[])
        original_create.assert_called_once()

    async def test_async_double_patch_idempotent(self):
        client = _make_async_openai_client()
        patch_async_openai_client(client)
        first_create = client.chat.completions.create
        patch_async_openai_client(client)
        assert client.chat.completions.create is first_create


# ---------------------------------------------------------------------------
# Anthropic: helpers
# ---------------------------------------------------------------------------

class TestAnthropicHelpers:
    def test_extract_input_no_capture(self):
        assert anthropic_extract_input([], "sys", False) is None

    def test_extract_input_with_system_and_messages(self):
        result = anthropic_extract_input(
            [{"role": "user", "content": "Hello"}],
            "You are helpful",
            True,
        )
        assert "system" in result
        assert "Hello" in result

    def test_extract_input_no_system(self):
        result = anthropic_extract_input(
            [{"role": "user", "content": "Hello"}],
            None,
            True,
        )
        assert result is not None
        assert "Hello" in result

    def test_extract_input_empty_messages(self):
        result = anthropic_extract_input([], None, True)
        assert result is None

    def test_extract_output_no_capture(self):
        assert anthropic_extract_output(Mock(), False) is None

    def test_extract_output_text_block(self):
        block = Mock()
        block.text = "Hello from Claude"
        response = Mock()
        response.content = [block]
        result = anthropic_extract_output(response, True)
        assert result == "Hello from Claude"

    def test_extract_output_no_text_attr(self):
        block = Mock(spec=[])
        response = Mock()
        response.content = [block]
        result = anthropic_extract_output(response, True)
        assert result is None


# ---------------------------------------------------------------------------
# Anthropic: patching, errors, streaming
# ---------------------------------------------------------------------------

class TestAnthropicPatching:
    def test_no_context_passthrough(self):
        client = _make_anthropic_client()
        original = client.messages.create
        patch_anthropic_client(client)
        client.messages.create(model="claude-3", messages=[])
        original.assert_called_once()

    def test_double_patch_idempotent(self):
        client = _make_anthropic_client()
        patch_anthropic_client(client)
        first = client.messages.create
        patch_anthropic_client(client)
        assert client.messages.create is first

    def test_error_captured(self):
        client = _make_anthropic_client()
        client.messages.create = Mock(side_effect=RuntimeError("down"))
        patch_anthropic_client(client)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            with pytest.raises(RuntimeError):
                client.messages.create(model="claude-3", messages=[])
        finally:
            set_trace_context(None)

        assert ctx.calls[0].error_type == "RuntimeError"

    def test_sync_streaming(self):
        def make_event(event_type, **kwargs):
            e = Mock()
            e.type = event_type
            for k, v in kwargs.items():
                setattr(e, k, v)
            return e

        msg_usage = Mock()
        msg_usage.input_tokens = 100
        msg_start = make_event("message_start", message=Mock(usage=msg_usage))

        delta_block = make_event("content_block_delta", delta=Mock(text="Hello"))

        delta_usage = Mock()
        delta_usage.output_tokens = 50
        msg_delta = make_event("message_delta", usage=delta_usage)

        events = [msg_start, delta_block, msg_delta]

        client = _make_anthropic_client()
        client.messages.create = Mock(return_value=iter(events))
        patch_anthropic_client(client, capture_content=True)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            stream = client.messages.create(model="claude-3", messages=[], stream=True)
            collected = list(stream)
        finally:
            set_trace_context(None)

        assert len(collected) == 3
        call = ctx.calls[0]
        assert call.prompt_tokens == 100
        assert call.completion_tokens == 50
        assert call.output_preview == "Hello"

    def test_stream_context_manager(self):
        call = CapturedLlmCall(provider="anthropic", model="claude")
        inner = Mock()
        inner.__enter__ = Mock(return_value=inner)
        inner.__exit__ = Mock(return_value=False)

        wrapper = AnthropicStreamWrapper(inner, call, capture_content=False)
        with wrapper:
            pass
        assert wrapper._finalised

    def test_stream_event_missing_attr(self):
        """Events with missing attributes should not crash."""
        call = CapturedLlmCall(provider="anthropic", model="claude")
        e = Mock()
        e.type = "message_start"
        del e.message  # simulate missing attribute
        wrapper = AnthropicStreamWrapper(iter([e]), call, capture_content=False)
        list(wrapper)  # should not raise


class TestAsyncAnthropicAdapter:
    async def test_async_patch_records_call(self):
        client = _make_async_anthropic_client()
        patch_async_anthropic_client(client)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            await client.messages.create(model="claude-3", messages=[])
        finally:
            set_trace_context(None)

        assert len(ctx.calls) == 1
        assert ctx.calls[0].provider == "anthropic"
        assert ctx.calls[0].prompt_tokens == 200

    async def test_async_no_context_passthrough(self):
        client = _make_async_anthropic_client()
        original = client.messages.create
        patch_async_anthropic_client(client)
        await client.messages.create(model="claude-3", messages=[])
        original.assert_called_once()

    async def test_async_double_patch_idempotent(self):
        client = _make_async_anthropic_client()
        patch_async_anthropic_client(client)
        first = client.messages.create
        patch_async_anthropic_client(client)
        assert client.messages.create is first

    async def test_async_error_captured(self):
        client = _make_async_anthropic_client()
        client.messages.create = AsyncMock(side_effect=RuntimeError("down"))
        patch_async_anthropic_client(client)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            with pytest.raises(RuntimeError):
                await client.messages.create(model="claude-3", messages=[])
        finally:
            set_trace_context(None)
        assert ctx.calls[0].error_type == "RuntimeError"

    async def test_async_streaming(self):
        def make_event(event_type, **kwargs):
            e = Mock()
            e.type = event_type
            for k, v in kwargs.items():
                setattr(e, k, v)
            return e

        msg_usage = Mock()
        msg_usage.input_tokens = 100
        events = [
            make_event("message_start", message=Mock(usage=msg_usage)),
            make_event("content_block_delta", delta=Mock(text="Hi")),
            make_event("message_delta", usage=Mock(output_tokens=50)),
        ]

        async def async_events():
            for e in events:
                yield e

        client = _make_async_anthropic_client()
        client.messages.create = AsyncMock(return_value=async_events())
        patch_async_anthropic_client(client, capture_content=True)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            stream = await client.messages.create(model="claude-3", messages=[], stream=True)
            collected = []
            async for e in stream:
                collected.append(e)
        finally:
            set_trace_context(None)

        assert len(collected) == 3
        assert ctx.calls[0].prompt_tokens == 100
        assert ctx.calls[0].completion_tokens == 50
        assert ctx.calls[0].output_preview == "Hi"

    async def test_async_stream_context_manager(self):
        call = CapturedLlmCall(provider="anthropic", model="claude")
        inner = AsyncMock()
        inner.__aenter__ = AsyncMock(return_value=inner)
        inner.__aexit__ = AsyncMock(return_value=False)

        wrapper = AnthropicAsyncStreamWrapper(inner, call, capture_content=False)
        async with wrapper:
            pass
        assert wrapper._finalised


# ---------------------------------------------------------------------------
# Google: helpers
# ---------------------------------------------------------------------------

class TestGoogleHelpers:
    def test_extract_input_string(self):
        result = google_extract_input("Hello Gemini", True)
        assert result == "Hello Gemini"

    def test_extract_input_list_of_strings(self):
        result = google_extract_input(["Hello", "World"], True)
        assert "Hello" in result
        assert "World" in result

    def test_extract_input_list_of_dicts(self):
        result = google_extract_input([{"text": "Question"}], True)
        assert "Question" in result

    def test_extract_input_no_capture(self):
        assert google_extract_input("Hello", False) is None

    def test_extract_input_empty(self):
        assert google_extract_input(None, True) is None

    def test_extract_input_list_of_objects(self):
        obj = Mock()
        obj.__str__ = lambda self: "custom_object"
        result = google_extract_input([obj], True)
        assert "custom_object" in result

    def test_extract_output_no_capture(self):
        assert google_extract_output(Mock(), False) is None

    def test_extract_output_text(self):
        response = Mock()
        response.text = "Response text"
        assert google_extract_output(response, True) == "Response text"

    def test_extract_output_no_text(self):
        response = Mock(spec=[])
        assert google_extract_output(response, True) is None

    def test_extract_usage(self):
        call = CapturedLlmCall(provider="google", model="gemini")
        meta = Mock()
        meta.prompt_token_count = 100
        meta.candidates_token_count = 50
        response = Mock()
        response.usage_metadata = meta
        google_extract_usage(response, call)
        assert call.prompt_tokens == 100
        assert call.completion_tokens == 50

    def test_extract_usage_missing_metadata(self):
        call = CapturedLlmCall(provider="google", model="gemini")
        response = Mock(spec=[])
        google_extract_usage(response, call)
        assert call.prompt_tokens is None


# ---------------------------------------------------------------------------
# Google: patching, errors, streaming, async
# ---------------------------------------------------------------------------

class TestGooglePatching:
    def test_no_context_passthrough(self):
        model = _make_google_model()
        original = model.generate_content
        patch_google_model(model)
        model.generate_content("Hello")
        original.assert_called_once()

    def test_double_patch_idempotent(self):
        model = _make_google_model()
        patch_google_model(model)
        first = model.generate_content
        patch_google_model(model)
        assert model.generate_content is first

    def test_error_captured(self):
        model = _make_google_model()
        model.generate_content = Mock(side_effect=RuntimeError("quota"))
        patch_google_model(model)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            with pytest.raises(RuntimeError):
                model.generate_content("Hello")
        finally:
            set_trace_context(None)

        assert ctx.calls[0].error_type == "RuntimeError"

    def test_sync_streaming(self):
        def make_chunk(text=None, prompt_tokens=None, comp_tokens=None):
            chunk = Mock()
            chunk.text = text
            if prompt_tokens is not None:
                meta = Mock()
                meta.prompt_token_count = prompt_tokens
                meta.candidates_token_count = comp_tokens
                chunk.usage_metadata = meta
            else:
                chunk.usage_metadata = None
            return chunk

        chunks = [
            make_chunk(text="Hello"),
            make_chunk(text=" world", prompt_tokens=50, comp_tokens=25),
        ]

        model = _make_google_model()
        model.generate_content = Mock(return_value=iter(chunks))
        patch_google_model(model, capture_content=True)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            stream = model.generate_content("Hi", stream=True)
            collected = list(stream)
        finally:
            set_trace_context(None)

        assert len(collected) == 2
        assert ctx.calls[0].prompt_tokens == 50
        assert ctx.calls[0].output_preview == "Hello world"

    def test_content_capture_with_kwargs(self):
        model = _make_google_model()
        patch_google_model(model, capture_content=True)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            model.generate_content(contents="What is AI?")
        finally:
            set_trace_context(None)

        assert ctx.calls[0].input_preview == "What is AI?"

    def test_async_patched(self):
        model = _make_google_model()
        patch_google_model(model)
        assert getattr(model.generate_content, "_infinium_patched", None)
        assert getattr(model.generate_content_async, "_infinium_patched", None)


class TestAsyncGoogleAdapter:
    async def test_async_records_call(self):
        model = _make_google_model()
        patch_google_model(model)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            await model.generate_content_async("Hello")
        finally:
            set_trace_context(None)

        assert len(ctx.calls) == 1
        assert ctx.calls[0].provider == "google"
        assert ctx.calls[0].prompt_tokens == 150

    async def test_async_no_context_passthrough(self):
        model = _make_google_model()
        original = model.generate_content_async
        patch_google_model(model)
        await model.generate_content_async("Hello")
        original.assert_called_once()

    async def test_async_error_captured(self):
        model = _make_google_model()
        model.generate_content_async = AsyncMock(side_effect=RuntimeError("down"))
        patch_google_model(model)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            with pytest.raises(RuntimeError):
                await model.generate_content_async("Hello")
        finally:
            set_trace_context(None)

        assert ctx.calls[0].error_type == "RuntimeError"

    async def test_async_streaming(self):
        chunk = Mock()
        chunk.text = "Hi"
        chunk.usage_metadata = Mock()
        chunk.usage_metadata.prompt_token_count = 30
        chunk.usage_metadata.candidates_token_count = 15

        async def async_gen():
            yield chunk

        model = _make_google_model()
        model.generate_content_async = AsyncMock(return_value=async_gen())
        patch_google_model(model, capture_content=True)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            stream = await model.generate_content_async("Hi", stream=True)
            collected = []
            async for c in stream:
                collected.append(c)
        finally:
            set_trace_context(None)

        assert len(collected) == 1
        assert ctx.calls[0].prompt_tokens == 30
        assert ctx.calls[0].output_preview == "Hi"


# ---------------------------------------------------------------------------
# Google: stream wrappers
# ---------------------------------------------------------------------------

class TestGoogleStreamWrappers:
    def test_sync_stream_finalise_idempotent(self):
        call = CapturedLlmCall(provider="google", model="gemini")
        wrapper = GoogleStreamWrapper(iter([]), call, capture_content=False)
        list(wrapper)
        latency = call.latency_ns
        wrapper._finalise()
        assert call.latency_ns == latency

    def test_chunk_with_no_text(self):
        call = CapturedLlmCall(provider="google", model="gemini")
        chunk = Mock()
        chunk.text = None
        chunk.usage_metadata = None
        wrapper = GoogleStreamWrapper(iter([chunk]), call, capture_content=True)
        list(wrapper)
        assert call.output_preview is None

    async def test_async_stream_finalise_idempotent(self):
        call = CapturedLlmCall(provider="google", model="gemini")

        async def empty():
            return
            yield

        wrapper = GoogleAsyncStreamWrapper(empty().__aiter__(), call, capture_content=False)
        async for _ in wrapper:
            pass
        latency = call.latency_ns
        wrapper._finalise()
        assert call.latency_ns == latency


# ---------------------------------------------------------------------------
# watch() extended
# ---------------------------------------------------------------------------

class TestWatchExtended:
    def test_watch_async_openai(self):
        client = _make_async_openai_client()
        result = watch(client)
        assert result is client
        assert getattr(client.chat.completions.create, "_infinium_patched", False)

    def test_watch_async_anthropic(self):
        client = _make_async_anthropic_client()
        result = watch(client)
        assert result is client
        assert getattr(client.messages.create, "_infinium_patched", False)

    def test_watch_xai_sync(self):
        """xAI client with x.ai base_url should be detected."""
        client = _make_openai_client()
        client.base_url = "https://api.x.ai/v1"
        # Also set module to not match "OpenAI" detection
        type(client).__name__ = "OpenAI"
        type(client).__module__ = "openai._client"
        result = watch(client)
        assert result is client

    def test_watch_xai_async(self):
        client = _make_async_openai_client()
        client.base_url = "https://api.x.ai/v1"
        type(client).__name__ = "AsyncOpenAI"
        type(client).__module__ = "openai._async_client"
        # _is_async_openai matches first, but _is_xai with "Async" in name also works
        result = watch(client)
        assert result is client

    def test_watch_with_capture_content(self):
        client = _make_openai_client()
        watch(client, capture_content=True)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "test"}],
            )
        finally:
            set_trace_context(None)

        # With capture enabled, output_preview should be populated
        assert ctx.calls[0].output_preview == "Hello"


# ---------------------------------------------------------------------------
# OTel exporter
# ---------------------------------------------------------------------------

class TestOTelExporter:
    def test_init_without_otel_warns(self):
        from infinium.integrations.otel import InfiniumOTelExporter, _HAS_OTEL
        if _HAS_OTEL:
            pytest.skip("OTel is installed, can't test warning path")
        with patch("infinium.integrations.otel.logger") as mock_logger:
            exporter = InfiniumOTelExporter()
            mock_logger.warning.assert_called_once()

    def test_get_tracer_returns_none_without_otel(self):
        from infinium.integrations.otel import InfiniumOTelExporter, _HAS_OTEL
        if _HAS_OTEL:
            pytest.skip("OTel is installed")
        exporter = InfiniumOTelExporter.__new__(InfiniumOTelExporter)
        exporter._tracer = None
        exporter.tracer_name = "test"
        assert exporter._get_tracer() is None

    def test_export_trace_no_op_without_otel(self):
        from infinium.integrations.otel import InfiniumOTelExporter, _HAS_OTEL
        if _HAS_OTEL:
            pytest.skip("OTel is installed")
        exporter = InfiniumOTelExporter.__new__(InfiniumOTelExporter)
        exporter._tracer = None
        exporter.tracer_name = "test"
        exporter.service_name = "test"
        # Should not raise
        exporter.export_trace("test-trace", 1.0)

    def test_export_trace_with_mock_otel(self):
        from infinium.integrations import otel as otel_mod
        original_has = otel_mod._HAS_OTEL

        # Mock the OTel API
        mock_span = MagicMock()
        mock_span.__enter__ = Mock(return_value=mock_span)
        mock_span.__exit__ = Mock(return_value=False)

        mock_tracer = Mock()
        mock_tracer.start_as_current_span = Mock(return_value=mock_span)

        try:
            otel_mod._HAS_OTEL = True
            exporter = otel_mod.InfiniumOTelExporter.__new__(otel_mod.InfiniumOTelExporter)
            exporter.service_name = "test-agent"
            exporter.tracer_name = "infinium"
            exporter._tracer = mock_tracer

            ctx = TraceContext()
            ctx.calls.append(CapturedLlmCall(
                provider="openai", model="gpt-4o",
                prompt_tokens=100, completion_tokens=50,
                latency_ns=1_000_000_000, temperature=0.7,
            ))
            ctx.prompts.append(CapturedPromptFetch(
                prompt_id="abc", prompt_name="Test", version=1,
            ))

            exporter.export_trace("my-trace", 2.5, ctx=ctx)

            # Root span created
            mock_tracer.start_as_current_span.assert_called()
            mock_span.set_attribute.assert_any_call("infinium.service", "test-agent")
            mock_span.set_attribute.assert_any_call("infinium.duration_s", 2.5)
        finally:
            otel_mod._HAS_OTEL = original_has

    def test_export_trace_with_error_call(self):
        from infinium.integrations import otel as otel_mod
        original_has = otel_mod._HAS_OTEL

        mock_span = MagicMock()
        mock_span.__enter__ = Mock(return_value=mock_span)
        mock_span.__exit__ = Mock(return_value=False)

        mock_tracer = Mock()
        mock_tracer.start_as_current_span = Mock(return_value=mock_span)

        try:
            otel_mod._HAS_OTEL = True

            # Mock StatusCode
            mock_status_code = Mock()
            mock_status_code.ERROR = "ERROR"
            otel_mod.StatusCode = mock_status_code

            exporter = otel_mod.InfiniumOTelExporter.__new__(otel_mod.InfiniumOTelExporter)
            exporter.service_name = "test"
            exporter.tracer_name = "infinium"
            exporter._tracer = mock_tracer

            ctx = TraceContext()
            ctx.calls.append(CapturedLlmCall(
                provider="openai", model="gpt-4o",
                error_type="RuntimeError", error_message="API down",
            ))

            exporter.export_trace("error-trace", 1.0, ctx=ctx)
            mock_tracer.start_as_current_span.assert_called()
        finally:
            otel_mod._HAS_OTEL = original_has

    def test_export_trace_no_ctx(self):
        from infinium.integrations import otel as otel_mod
        original_has = otel_mod._HAS_OTEL

        mock_span = MagicMock()
        mock_span.__enter__ = Mock(return_value=mock_span)
        mock_span.__exit__ = Mock(return_value=False)

        mock_tracer = Mock()
        mock_tracer.start_as_current_span = Mock(return_value=mock_span)

        try:
            otel_mod._HAS_OTEL = True
            exporter = otel_mod.InfiniumOTelExporter.__new__(otel_mod.InfiniumOTelExporter)
            exporter.service_name = "test"
            exporter.tracer_name = "infinium"
            exporter._tracer = mock_tracer

            exporter.export_trace("trace", 1.0, ctx=None)
            # Should still create root span, but return early
            mock_tracer.start_as_current_span.assert_called_once()
        finally:
            otel_mod._HAS_OTEL = original_has


# ---------------------------------------------------------------------------
# Client: get_prompt
# ---------------------------------------------------------------------------

class TestSyncGetPrompt:
    def test_get_prompt_success(self):
        client = _client_factory()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.is_success = True
        mock_response.content = b'{"data": "ok"}'
        mock_response.json.return_value = {
            "promptId": "abc-123",
            "name": "Test Prompt",
            "version": 3,
            "content": "Hello {{name}}, you are {{role}}",
            "createdAt": "2026-03-17T12:00:00Z",
        }
        mock_response.headers = {}
        client._client.request = Mock(return_value=mock_response)

        result = client.get_prompt(
            prompt_id="a1b2c3d4-e5f6-7890-abcd-ef1234567890",
            prompt_key="pk_test_key_long_enough",
            version=3,
            variables={"name": "Alice", "role": "admin"},
        )

        assert result.prompt_id == "abc-123"
        assert result.name == "Test Prompt"
        assert result.version == 3
        assert "Hello Alice" in result.rendered_content
        assert "admin" in result.rendered_content
        assert "{{name}}" not in result.rendered_content

    def test_get_prompt_latest_version(self):
        client = _client_factory()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.is_success = True
        mock_response.content = b'ok'
        mock_response.json.return_value = {
            "promptId": "abc", "name": "P", "version": 1,
            "content": "content", "createdAt": "2026-01-01",
        }
        mock_response.headers = {}
        client._client.request = Mock(return_value=mock_response)

        result = client.get_prompt("a1b2c3d4-e5f6-7890-abcd-ef1234567890", "pk_key_value_here")
        assert result.content == "content"
        assert result.rendered_content is None  # no variables passed

    def test_get_prompt_no_variables(self):
        client = _client_factory()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.is_success = True
        mock_response.content = b'ok'
        mock_response.json.return_value = {
            "promptId": "abc", "name": "P", "version": 1,
            "content": "Hello {{name}}", "createdAt": "2026-01-01",
        }
        mock_response.headers = {}
        client._client.request = Mock(return_value=mock_response)

        result = client.get_prompt("a1b2c3d4-e5f6-7890-abcd-ef1234567890", "pk_key_value_here")
        assert result.rendered_content is None

    def test_get_prompt_records_trace_context(self):
        client = _client_factory()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.is_success = True
        mock_response.content = b'ok'
        mock_response.json.return_value = {
            "promptId": "abc", "name": "MyPrompt", "version": 2,
            "content": "Hello", "createdAt": "2026-01-01",
        }
        mock_response.headers = {}
        client._client.request = Mock(return_value=mock_response)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            client.get_prompt(
                "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                "pk_key_value_here",
                variables={"x": "1"},
            )
        finally:
            set_trace_context(None)

        assert len(ctx.prompts) == 1
        assert ctx.prompts[0].prompt_name == "MyPrompt"
        assert ctx.prompts[0].version == 2
        assert ctx.prompts[0].variables_used == ["x"]

    def test_get_prompt_validation_errors(self):
        client = _client_factory()

        with pytest.raises(ValidationError):
            client.get_prompt("", "key")

        with pytest.raises(ValidationError):
            client.get_prompt("a1b2c3d4-e5f6-7890-abcd-ef1234567890", "")

        with pytest.raises(ValidationError):
            client.get_prompt("a1b2c3d4-e5f6-7890-abcd-ef1234567890", "key", version=-1)

        with pytest.raises(ValidationError):
            client.get_prompt("a1b2c3d4-e5f6-7890-abcd-ef1234567890", "key", version="abc")

        with pytest.raises(ValidationError):
            client.get_prompt("a1b2c3d4-e5f6-7890-abcd-ef1234567890", "key", version=3.14)

    def test_get_prompt_string_version(self):
        client = _client_factory()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.is_success = True
        mock_response.content = b'ok'
        mock_response.json.return_value = {
            "promptId": "abc", "name": "P", "version": 5,
            "content": "c", "createdAt": "2026-01-01",
        }
        mock_response.headers = {}
        client._client.request = Mock(return_value=mock_response)

        result = client.get_prompt("a1b2c3d4-e5f6-7890-abcd-ef1234567890", "pk_key", version="5")
        assert result.version == 5

    def test_get_prompt_empty_response(self):
        client = _client_factory()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.is_success = True
        mock_response.content = b'ok'
        mock_response.json.return_value = None
        mock_response.headers = {}
        client._client.request = Mock(return_value=mock_response)

        with pytest.raises(InfiniumError, match="Empty or invalid"):
            client.get_prompt("a1b2c3d4-e5f6-7890-abcd-ef1234567890", "pk_key")

    def test_get_prompt_404(self):
        client = _client_factory()
        mock_response = Mock()
        mock_response.status_code = 404
        mock_response.is_success = False
        mock_response.content = b'{"error": "Not found"}'
        mock_response.json.return_value = {"error": "Not found"}
        mock_response.headers = {}
        client._client.request = Mock(return_value=mock_response)

        with pytest.raises(NotFoundError):
            client.get_prompt("a1b2c3d4-e5f6-7890-abcd-ef1234567890", "pk_key")


# ---------------------------------------------------------------------------
# AsyncClient: get_prompt
# ---------------------------------------------------------------------------

class TestAsyncGetPrompt:
    async def test_get_prompt_success(self):
        client = _async_client_factory()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.is_success = True
        mock_response.content = b'ok'
        mock_response.json.return_value = {
            "promptId": "abc-123",
            "name": "Test Prompt",
            "version": 3,
            "content": "Hello {{name}}",
            "createdAt": "2026-03-17T12:00:00Z",
        }
        mock_response.headers = {}

        mock_http = AsyncMock()
        mock_http.request = AsyncMock(return_value=mock_response)
        mock_http.is_closed = False
        client._client = mock_http

        result = await client.get_prompt(
            "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
            "pk_test_key_long_enough",
            version=3,
            variables={"name": "Bob"},
        )

        assert result.prompt_id == "abc-123"
        assert result.rendered_content == "Hello Bob"

    async def test_get_prompt_validation_errors(self):
        client = _async_client_factory()

        with pytest.raises(ValidationError):
            await client.get_prompt("", "key")

        with pytest.raises(ValidationError):
            await client.get_prompt("a1b2c3d4-e5f6-7890-abcd-ef1234567890", "")

        with pytest.raises(ValidationError):
            await client.get_prompt("a1b2c3d4-e5f6-7890-abcd-ef1234567890", "k", version=-1)

    async def test_get_prompt_records_trace_context(self):
        client = _async_client_factory()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.is_success = True
        mock_response.content = b'ok'
        mock_response.json.return_value = {
            "promptId": "def", "name": "AsyncPrompt", "version": 1,
            "content": "c", "createdAt": "2026-01-01",
        }
        mock_response.headers = {}

        mock_http = AsyncMock()
        mock_http.request = AsyncMock(return_value=mock_response)
        mock_http.is_closed = False
        client._client = mock_http

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            await client.get_prompt(
                "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                "pk_key_value_here",
            )
        finally:
            set_trace_context(None)

        assert len(ctx.prompts) == 1
        assert ctx.prompts[0].prompt_name == "AsyncPrompt"


# ---------------------------------------------------------------------------
# Client: _handle_response edge cases
# ---------------------------------------------------------------------------

class TestHandleResponseEdgeCases:
    def test_404_error(self):
        client = _client_factory()
        response = Mock()
        response.status_code = 404
        response.is_success = False
        response.content = b'{}'
        response.json.return_value = {}
        response.headers = {}
        with pytest.raises(NotFoundError):
            client._handle_response(response)

    def test_generic_error(self):
        client = _client_factory()
        response = Mock()
        response.status_code = 422
        response.is_success = False
        response.content = b'{"error": "Validation failed"}'
        response.json.return_value = {"error": "Validation failed"}
        response.headers = {}
        with pytest.raises(InfiniumError, match="Validation failed"):
            client._handle_response(response)

    def test_generic_error_no_body(self):
        client = _client_factory()
        response = Mock()
        response.status_code = 400
        response.is_success = False
        response.content = b''
        response.json.return_value = None
        response.headers = {}
        with pytest.raises(InfiniumError, match="400"):
            client._handle_response(response)

    def test_json_decode_error(self):
        import json
        client = _client_factory()
        response = Mock()
        response.status_code = 200
        response.is_success = True
        response.content = b'not json'
        response.json.side_effect = json.JSONDecodeError("err", "doc", 0)
        response.headers = {}
        result = client._handle_response(response)
        assert result.success is True
        assert result.data is None

    def test_rate_limit_non_numeric_retry(self):
        client = _client_factory()
        response = Mock()
        response.status_code = 429
        response.is_success = False
        response.content = b'{}'
        response.json.return_value = {}
        response.headers = {"Retry-After": "not-a-number"}
        with pytest.raises(RateLimitError) as exc_info:
            client._handle_response(response)
        assert exc_info.value.retry_after == 60
