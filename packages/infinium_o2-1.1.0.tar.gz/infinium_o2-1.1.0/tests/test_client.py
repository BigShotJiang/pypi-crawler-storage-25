"""
Tests for the synchronous client.
"""
import json
import pytest
from unittest.mock import Mock, patch
import httpx

from infinium import InfiniumClient, TaskData
from infinium.types import (
    Customer, Sales, ExecutionStep, ErrorDetail, ExpectedOutcome,
    EnvironmentContext, LlmUsage, LlmCall,
)
from infinium.exceptions import (
    ValidationError, AuthenticationError, RateLimitError,
    NetworkError, ServerError, NotFoundError, InfiniumTimeoutError, InfiniumError
)


class TestInfiniumClient:
    def test_client_initialization(self, agent_credentials):
        client = InfiniumClient(
            agent_id=agent_credentials["agent_id"],
            agent_secret=agent_credentials["agent_secret"]
        )
        assert client.agent_id == agent_credentials["agent_id"]
        assert client.timeout == 30.0
        assert client.max_retries == 3

    def test_client_initialization_invalid_credentials(self):
        with pytest.raises(ValidationError, match="agent_id is required"):
            InfiniumClient(agent_id="", agent_secret="valid-password")
        with pytest.raises(ValidationError, match="agent_secret is required"):
            InfiniumClient(agent_id="valid-id", agent_secret="")

    def test_get_headers(self, client):
        headers = client._get_headers()
        assert headers["x-agent-id"] == "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
        assert headers["x-agent-key"] == "test-secret-456-long-enough"
        assert headers["Content-Type"] == "application/json"

    @patch('infinium.client.httpx.Client')
    def test_send_task_success(self, mock_httpx_class, client, mock_httpx_response, mock_success_response):
        mock_inst = Mock()
        mock_inst.request.return_value = mock_httpx_response
        client._client = mock_inst

        response = client.send_task(
            name="Test Task",
            description="Test description",
            duration=120.5,
        )
        assert response.success is True
        assert response.status_code == 200

    def test_send_task_validation_errors(self, client):
        with pytest.raises(ValidationError, match="name cannot be empty"):
            client.send_task(name="", description="Test", duration=100)
        with pytest.raises(ValidationError, match="duration must be a number"):
            client.send_task(name="Test", description="Test", duration="invalid")

    def test_send_task_with_sections(self, client):
        customer = Customer(customer_name="John Doe", customer_email="john@example.com")
        sales = Sales(lead_source="Website", deal_value=5000.0)

        with patch.object(client, '_make_request') as mock_req:
            mock_req.return_value = Mock(success=True, status_code=200, data={})
            client.send_task(
                name="Sales Task",
                description="Process lead",
                duration=300,
                customer=customer,
                sales=sales
            )
            mock_req.assert_called_once()

    @patch('infinium.client.httpx.Client')
    def test_authentication_error(self, mock_httpx_class, client):
        mock_inst = Mock()
        mock_resp = Mock()
        mock_resp.status_code = 401
        mock_resp.is_success = False
        mock_resp.json.return_value = {"error": "Unauthorized"}
        mock_resp.content = b'{"error": "Unauthorized"}'
        mock_resp.headers = {}
        mock_inst.request.return_value = mock_resp
        client._client = mock_inst

        with pytest.raises(AuthenticationError):
            client.send_task(name="Test", description="Test", duration=100)

    @patch('infinium.client.httpx.Client')
    def test_rate_limit_error(self, mock_httpx_class, client):
        mock_inst = Mock()
        mock_resp = Mock()
        mock_resp.status_code = 429
        mock_resp.is_success = False
        mock_resp.json.return_value = {"error": "Rate limited"}
        mock_resp.content = b'{}'
        mock_resp.headers = {"Retry-After": "60"}
        mock_inst.request.return_value = mock_resp
        client._client = mock_inst

        with pytest.raises(RateLimitError):
            client.send_task(name="Test", description="Test", duration=100)

    @patch('infinium.client.httpx.Client')
    def test_server_error(self, mock_httpx_class, client):
        mock_inst = Mock()
        mock_resp = Mock()
        mock_resp.status_code = 500
        mock_resp.is_success = False
        mock_resp.json.return_value = {}
        mock_resp.content = b'{}'
        mock_resp.headers = {}
        mock_inst.request.return_value = mock_resp
        client._client = mock_inst

        with pytest.raises(ServerError):
            client.send_task(name="Test", description="Test", duration=100)

    def test_send_tasks_batch(self, client):
        tasks = [
            TaskData(name=f"Task {i}", description=f"Desc {i}",
                     current_datetime="2025-10-07T12:00:00Z", duration=float(i * 10),
)
            for i in range(1, 4)
        ]
        with patch.object(client, 'send_task_data') as mock_send:
            mock_send.return_value = Mock(success=True, status_code=200, data={})
            result = client.send_tasks_batch(tasks)
            assert result.successful == 3
            assert result.failed == 0

    def test_send_tasks_batch_with_failures(self, client):
        tasks = [
            TaskData(name=f"Task {i}", description=f"Desc {i}",
                     current_datetime="2025-10-07T12:00:00Z", duration=float(i * 10),
)
            for i in range(1, 4)
        ]

        def side_effect(td):
            if "Task 2" in td.name:
                raise Exception("Network error")
            return Mock(success=True, status_code=200, data={})

        with patch.object(client, 'send_task_data', side_effect=side_effect):
            result = client.send_tasks_batch(tasks)
            assert result.successful == 2
            assert result.failed == 1

    def test_context_manager(self, agent_credentials):
        with InfiniumClient(
            agent_id=agent_credentials["agent_id"],
            agent_secret=agent_credentials["agent_secret"]
        ) as c:
            assert c.agent_id == agent_credentials["agent_id"]

    def test_create_task_data_static_method(self):
        td = InfiniumClient.create_task_data(
            name="Test", description="Desc", duration=100,
        )
        assert isinstance(td, TaskData)
        assert td.current_datetime is not None

    @patch('infinium.client.httpx.Client')
    def test_network_timeout_error(self, mock_httpx_class, client):
        mock_inst = Mock()
        mock_inst.request.side_effect = httpx.TimeoutException("timeout")
        client._client = mock_inst

        with pytest.raises(InfiniumTimeoutError):
            client.send_task(name="Test", description="Test", duration=100)

    @patch('infinium.client.httpx.Client')
    def test_retry_mechanism(self, mock_httpx_class, client):
        mock_inst = Mock()
        mock_success = Mock()
        mock_success.status_code = 200
        mock_success.is_success = True
        mock_success.json.return_value = {"status": "success"}
        mock_success.content = b'{}'
        mock_inst.request.side_effect = [
            httpx.NetworkError("fail"),
            httpx.NetworkError("fail"),
            mock_success
        ]
        client._client = mock_inst

        response = client.send_task(name="Test", description="Test", duration=100)
        assert response.success is True
        assert mock_inst.request.call_count == 3

    def test_close_client(self, client):
        client.close()  # Should not raise


class TestSerialization:
    """Tests for _task_data_to_dict priority ordering and new fields."""

    def test_basic_serialization(self, client):
        td = TaskData(
            name="Test", description="Desc",
            current_datetime="2025-10-07T12:00:00Z", duration=100.0,
        )
        result = client._task_data_to_dict(td)
        assert result["name"] == "Test"
    def test_new_top_level_fields_serialized(self, client):
        td = TaskData(
            name="Rich", description="Rich task",
            current_datetime="2025-10-07T12:00:00Z", duration=300.0,
            input_summary="Input data",
            output_summary="Output data",
            expected_outcome=ExpectedOutcome(
                task_objective="Do research",
                required_deliverables=["Report"],
            ),
            steps=[
                ExecutionStep(step_number=1, action="search", description="Search DB"),
                ExecutionStep(step_number=2, action="llm_inference", description="Summarize"),
            ],
            errors=[ErrorDetail(error_type="Timeout", message="Slow API")],
            environment=EnvironmentContext(framework="langchain", sdk_version="0.2.0"),
            llm_usage=LlmUsage(model="gpt-4o", total_tokens=5000),
        )
        result = client._task_data_to_dict(td)

        assert result["input_summary"] == "Input data"
        assert result["output_summary"] == "Output data"
        assert result["expected_outcome"]["task_objective"] == "Do research"
        assert len(result["steps"]) == 2
        assert result["steps"][0]["action"] == "search"
        assert len(result["errors"]) == 1
        assert result["errors"][0]["error_type"] == "Timeout"
        assert result["environment"]["framework"] == "langchain"
        assert result["llm_usage"]["total_tokens"] == 5000

    def test_sections_serialized(self, client):
        td = TaskData(
            name="Test", description="Desc",
            current_datetime="2025-10-07T12:00:00Z", duration=100.0,
            customer=Customer(customer_name="Alice"),
        )
        result = client._task_data_to_dict(td)
        assert result["sections"]["customer"]["customer_name"] == "Alice"

    def test_priority_order_keys(self, client):
        """Verify fields appear in Maestro-priority order."""
        td = TaskData(
            name="Test", description="Desc",
            current_datetime="2025-10-07T12:00:00Z", duration=100.0,
            expected_outcome=ExpectedOutcome(task_objective="Obj"),
            steps=[ExecutionStep(step_number=1, action="a", description="d")],
            errors=[ErrorDetail(error_type="E", message="m")],
            llm_usage=LlmUsage(model="m"),
            customer=Customer(customer_name="C"),
            environment=EnvironmentContext(framework="f"),
        )
        result = client._task_data_to_dict(td)
        keys = list(result.keys())
        # expected_outcome before steps before errors before llm_usage before sections before environment
        assert keys.index("expected_outcome") < keys.index("steps")
        assert keys.index("steps") < keys.index("errors")
        assert keys.index("errors") < keys.index("llm_usage")
        assert keys.index("llm_usage") < keys.index("sections")
        assert keys.index("sections") < keys.index("environment")


class TestDictCoercion:
    """Tests for create_task_data dict-to-dataclass coercion."""

    def test_dict_coerced_to_customer(self):
        td = InfiniumClient.create_task_data(
            name="Test", description="Desc", duration=100,
            customer={"customer_name": "Bob", "client_company": "Acme"},
        )
        assert isinstance(td.customer, Customer)
        assert td.customer.customer_name == "Bob"

    def test_dict_coerced_to_expected_outcome(self):
        td = InfiniumClient.create_task_data(
            name="Test", description="Desc", duration=100,
            expected_outcome={"task_objective": "Do it", "required_deliverables": ["A"]},
        )
        assert isinstance(td.expected_outcome, ExpectedOutcome)
        assert td.expected_outcome.task_objective == "Do it"

    def test_dict_coerced_to_environment(self):
        td = InfiniumClient.create_task_data(
            name="Test", description="Desc", duration=100,
            environment={"framework": "crewai"},
        )
        assert isinstance(td.environment, EnvironmentContext)

    def test_dataclass_passed_through(self):
        c = Customer(customer_name="Alice")
        td = InfiniumClient.create_task_data(
            name="Test", description="Desc", duration=100,
            customer=c,
        )
        assert td.customer is c

    def test_unknown_kwargs_passed_through(self):
        """Non-section kwargs go straight to TaskData (may fail if not valid)."""
        td = InfiniumClient.create_task_data(
            name="Test", description="Desc", duration=100,
            input_summary="Some input",
        )
        assert td.input_summary == "Some input"


class TestWaitForInterpretation:
    def test_returns_immediately_when_ready(self, client):
        with patch.object(client, 'get_interpreted_task_result') as mock_get:
            mock_get.return_value = Mock(
                data={"interpretedTraceResult": '{"score": 85}'}
            )
            result = client.wait_for_interpretation("a1b2c3d4-e5f6-7890-abcd-ef1234567890")
            assert result.data["interpretedTraceResult"] is not None
            mock_get.assert_called_once()

    def test_polls_until_ready(self, client):
        empty = Mock(data={"interpretedTraceResult": None})
        ready = Mock(data={"interpretedTraceResult": '{"score": 90}'})

        with patch.object(client, 'get_interpreted_task_result', side_effect=[empty, empty, ready]):
            result = client.wait_for_interpretation(
                "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                timeout=10, poll_interval=0.01,
            )
            assert result.data["interpretedTraceResult"] is not None

    def test_timeout_raises(self, client):
        empty = Mock(data={"interpretedTraceResult": None})

        with patch.object(client, 'get_interpreted_task_result', return_value=empty):
            with pytest.raises(InfiniumTimeoutError, match="Interpretation not ready"):
                client.wait_for_interpretation(
                    "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                    timeout=0.05, poll_interval=0.01,
                )

    def test_validation_error_on_empty_id(self, client):
        with pytest.raises(ValidationError):
            client.wait_for_interpretation("")
