"""
Coverage tests for AsyncInfiniumClient and provider Instrumentor classes.
All HTTP calls are mocked — no real API calls are made.
"""
import asyncio
import json
import re
import pytest
from unittest.mock import AsyncMock, MagicMock, Mock, patch, PropertyMock
from dataclasses import dataclass

import httpx

from infinium import (
    AsyncInfiniumClient,
    TaskData,
    ApiResponse,
    BatchResult,
    InfiniumError,
    ValidationError,
    NotFoundError,
    AuthenticationError,
    ServerError,
    RateLimitError,
)
from infinium.types import (
    PromptContent,
    TimeTracking,
    Customer,
    Support,
    LlmUsage,
    ExecutionStep,
    ErrorDetail,
    ExpectedOutcome,
    EnvironmentContext,
)
from infinium.integrations._context import (
    CapturedLlmCall,
    TraceContext,
    get_current_trace_context,
    set_trace_context,
)
from infinium.integrations.openai import (
    _AsyncStreamWrapper as OpenAIAsyncStreamWrapper,
    _make_async_wrapper as openai_make_async_wrapper,
)
from infinium.integrations.anthropic import (
    _AsyncStreamWrapper as AnthropicAsyncStreamWrapper,
    _make_async_wrapper as anthropic_make_async_wrapper,
)
from infinium.integrations.google import (
    _AsyncStreamWrapper as GoogleAsyncStreamWrapper,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

AGENT_ID = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
AGENT_SECRET = "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"


def _make_httpx_response(status: int, body=None, headers=None):
    content = json.dumps(body).encode() if body is not None else b""
    return httpx.Response(
        status_code=status,
        content=content,
        headers=headers or {},
        request=httpx.Request("POST", "https://test.example.com"),
    )


def _mock_http_client(response):
    """Create a mock httpx.AsyncClient that returns the given response."""
    mock = AsyncMock()
    mock.is_closed = False
    mock.request = AsyncMock(return_value=response)
    return mock


class _AsyncIter:
    """Helper async iterator from a list of items."""
    def __init__(self, items):
        self._items = list(items)
        self._index = 0

    def __aiter__(self):
        return self

    async def __anext__(self):
        if self._index >= len(self._items):
            raise StopAsyncIteration
        item = self._items[self._index]
        self._index += 1
        return item


# ---------------------------------------------------------------------------
# AsyncInfiniumClient basics
# ---------------------------------------------------------------------------

class TestAsyncClientInit:
    def test_init_defaults(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        assert client.agent_id == AGENT_ID
        assert client._client is None

    def test_init_custom_base_url(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET, base_url="https://custom.api/")
        assert client.base_url == "https://custom.api"

    def test_init_with_logging(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET, enable_logging=True, log_level="DEBUG")
        assert client.logger is not None


class TestAsyncClientContextManager:
    @pytest.mark.asyncio
    async def test_aenter_aexit(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        async with client as c:
            assert c is client
            assert c._client is not None
        assert client._client is None

    @pytest.mark.asyncio
    async def test_close_idempotent(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        await client.close()
        assert client._client is None

    @pytest.mark.asyncio
    async def test_close_with_error(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        mock_http = AsyncMock()
        mock_http.is_closed = False
        mock_http.aclose = AsyncMock(side_effect=RuntimeError("boom"))
        client._client = mock_http
        await client.close()
        assert client._client is None


class TestAsyncClientHandleResponse:
    def _client(self):
        return AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)

    def test_success(self):
        result = self._client()._handle_response(
            _make_httpx_response(200, {"success": True, "data": {"id": 1}})
        )
        assert result.success is True

    def test_401(self):
        with pytest.raises(AuthenticationError):
            self._client()._handle_response(_make_httpx_response(401, {"error": "unauth"}))

    def test_429(self):
        with pytest.raises(RateLimitError):
            self._client()._handle_response(
                _make_httpx_response(429, None, headers={"Retry-After": "30"})
            )

    def test_429_non_numeric_retry(self):
        with pytest.raises(RateLimitError):
            self._client()._handle_response(
                _make_httpx_response(429, None, headers={"Retry-After": "abc"})
            )

    def test_404(self):
        with pytest.raises(NotFoundError):
            self._client()._handle_response(_make_httpx_response(404, None))

    def test_500(self):
        with pytest.raises(ServerError):
            self._client()._handle_response(_make_httpx_response(500, {"error": "boom"}))

    def test_generic_error(self):
        with pytest.raises(InfiniumError):
            self._client()._handle_response(_make_httpx_response(422, {"error": "bad input"}))

    def test_generic_error_no_body(self):
        with pytest.raises(InfiniumError):
            self._client()._handle_response(_make_httpx_response(418, None))

    def test_json_decode_error(self):
        resp = httpx.Response(
            status_code=200,
            content=b"not json",
            request=httpx.Request("POST", "https://test.example.com"),
        )
        result = self._client()._handle_response(resp)
        assert result.data is None


class TestAsyncClientSendTask:
    @pytest.mark.asyncio
    async def test_send_task_basic(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        resp = _make_httpx_response(200, {"success": True, "data": {"id": "t1"}})
        client._client = _mock_http_client(resp)

        result = await client.send_task(
            name="Test Task", description="A test", duration=10,
        )
        assert result.success is True

    @pytest.mark.asyncio
    async def test_send_task_with_sections(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        resp = _make_httpx_response(200, {"success": True})
        client._client = _mock_http_client(resp)

        result = await client.send_task(
            name="Test", description="Desc", duration=5,
            time_tracking=TimeTracking(start_time="2024-01-01T00:00:00Z"),
            customer=Customer(customer_name="Acme", client_industry="Tech"),
            input_summary="input", output_summary="output",
            llm_usage=LlmUsage(total_tokens=50),
            steps=[ExecutionStep(step_number=1, action="run", description="step")],
            errors=[ErrorDetail(error_type="E", message="m")],
            expected_outcome=ExpectedOutcome(task_objective="pass"),
            environment=EnvironmentContext(framework="linux"),
        )
        assert result.success is True

    @pytest.mark.asyncio
    async def test_send_task_with_custom_datetime(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        client._client = _mock_http_client(_make_httpx_response(200, {"success": True}))

        result = await client.send_task(
            name="Test", description="Desc", duration=5,
            current_datetime="2024-01-01T00:00:00Z",
        )
        assert result.success is True

    @pytest.mark.asyncio
    async def test_send_task_invalid_datetime(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        with pytest.raises(ValidationError):
            await client.send_task(
                name="Test", description="Desc", duration=5,
                current_datetime="not-a-date",
            )


class TestAsyncClientSendTaskData:
    @pytest.mark.asyncio
    async def test_send_task_data(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        client._client = _mock_http_client(_make_httpx_response(200, {"success": True}))

        td = TaskData(
            name="Test", description="Desc",
            current_datetime="2024-01-01T00:00:00Z", duration=5,
        )
        result = await client.send_task_data(td)
        assert result.success is True


class TestAsyncClientBatch:
    @pytest.mark.asyncio
    async def test_batch_empty(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        with pytest.raises(ValidationError):
            await client.send_tasks_batch([])

    @pytest.mark.asyncio
    async def test_batch_invalid_concurrency(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        td = TaskData(name="T", description="D", current_datetime="2024-01-01T00:00:00Z", duration=1)
        with pytest.raises(ValidationError):
            await client.send_tasks_batch([td], max_concurrent=0)

    @pytest.mark.asyncio
    async def test_batch_success(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        client._client = _mock_http_client(_make_httpx_response(200, {"success": True, "data": {}}))

        tasks = [
            TaskData(name=f"T{i}", description="D", current_datetime="2024-01-01T00:00:00Z", duration=1)
            for i in range(3)
        ]
        result = await client.send_tasks_batch(tasks)
        assert result.successful == 3
        assert result.failed == 0

    @pytest.mark.asyncio
    async def test_batch_partial_failure(self):
        """One task raises an error; others succeed — fail_fast=False."""
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        call_count = 0
        orig_send = client.send_task_data

        async def mock_send(td):
            nonlocal call_count
            call_count += 1
            if call_count == 2:
                raise ValidationError("simulated failure")
            return ApiResponse(success=True, message="ok", data={})

        client.send_task_data = mock_send

        tasks = [
            TaskData(name=f"T{i}", description="D", current_datetime="2024-01-01T00:00:00Z", duration=1)
            for i in range(3)
        ]
        result = await client.send_tasks_batch(tasks)
        assert result.failed > 0

    @pytest.mark.asyncio
    async def test_batch_fail_fast(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        client._client = _mock_http_client(_make_httpx_response(500, {"error": "fail"}))

        tasks = [
            TaskData(name=f"T{i}", description="D", current_datetime="2024-01-01T00:00:00Z", duration=1)
            for i in range(2)
        ]
        from infinium.exceptions import BatchError
        with pytest.raises((BatchError, ServerError)):
            await client.send_tasks_batch(tasks, fail_fast=True)


class TestAsyncClientTaskDataToDict:
    def _client(self):
        return AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)

    def test_full_task_data(self):
        td = TaskData(
            name="Test", description="Desc",
            current_datetime="2024-01-01T00:00:00Z", duration=5,
            input_summary="in", output_summary="out",
            expected_outcome=ExpectedOutcome(task_objective="done"),
            steps=[ExecutionStep(step_number=1, action="run", description="step", duration_ms=100)],
            errors=[ErrorDetail(error_type="TypeError", message="oops")],
            llm_usage=LlmUsage(total_tokens=100, api_calls_count=1),
            time_tracking=TimeTracking(start_time="2024-01-01T00:00:00Z"),
            environment=EnvironmentContext(framework="test"),
        )
        d = self._client()._task_data_to_dict(td)
        assert d["input_summary"] == "in"
        assert d["output_summary"] == "out"
        assert "expected_outcome" in d
        assert "steps" in d
        assert "errors" in d
        assert "llm_usage" in d
        assert "sections" in d
        assert "environment" in d

    def test_prompt_studio_attached(self):
        td = TaskData(
            name="Test", description="Desc",
            current_datetime="2024-01-01T00:00:00Z", duration=5,
        )
        td._prompt_studio = {"prompts_used": [{"prompt_id": "abc"}]}
        d = self._client()._task_data_to_dict(td)
        assert "prompt_studio" in d

    def test_minimal_task_data(self):
        td = TaskData(
            name="Test", description="Desc",
            current_datetime="2024-01-01T00:00:00Z", duration=5,
        )
        d = self._client()._task_data_to_dict(td)
        assert "sections" not in d
        assert "steps" not in d


class TestAsyncClientCreateTaskData:
    def test_basic(self):
        td = AsyncInfiniumClient.create_task_data(
            name="T", description="D", duration=1,
        )
        assert td.name == "T"

    def test_with_dict_sections(self):
        td = AsyncInfiniumClient.create_task_data(
            name="T", description="D", duration=1,
            time_tracking={"start_time": "2024-01-01T00:00:00Z"},
        )
        assert isinstance(td.time_tracking, TimeTracking)
        assert td.time_tracking.start_time == "2024-01-01T00:00:00Z"


class TestAsyncClientTraceDecorator:
    @pytest.mark.asyncio
    async def test_trace_async_fn(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        client._client = _mock_http_client(_make_httpx_response(200, {"success": True, "data": {}}))

        @client.trace("TestTrace")
        async def my_fn():
            return {"result": "ok"}

        result = await my_fn()
        assert result == {"result": "ok"}

    def test_trace_sync_fn(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)

        @client.trace("TestTrace", auto_send=False)
        def my_fn():
            return 42

        result = my_fn()
        assert result == 42


class TestAsyncClientGetPrompt:
    @pytest.mark.asyncio
    async def test_get_prompt_success(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        resp_data = {"promptId": "p-1", "name": "My Prompt", "version": 3,
                     "content": "Hello {{name}}", "createdAt": "2024-01-01T00:00:00Z"}
        client._client = _mock_http_client(_make_httpx_response(200, resp_data))

        result = await client.get_prompt(AGENT_ID, "key123", version=3, variables={"name": "World"})
        assert isinstance(result, PromptContent)
        assert result.rendered_content == "Hello World"

    @pytest.mark.asyncio
    async def test_get_prompt_latest(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        resp_data = {"promptId": "p-1", "name": "P", "version": 1, "content": "text", "createdAt": ""}
        client._client = _mock_http_client(_make_httpx_response(200, resp_data))

        result = await client.get_prompt(AGENT_ID, "key123")
        assert result.content == "text"
        assert result.rendered_content is None

    @pytest.mark.asyncio
    async def test_get_prompt_string_version(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        resp_data = {"promptId": "p-1", "name": "P", "version": 2, "content": "c", "createdAt": ""}
        client._client = _mock_http_client(_make_httpx_response(200, resp_data))

        result = await client.get_prompt(AGENT_ID, "key123", version="2")
        assert result.version == 2

    @pytest.mark.asyncio
    async def test_get_prompt_bad_version_string(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        with pytest.raises(ValidationError):
            await client.get_prompt(AGENT_ID, "key123", version="abc")

    @pytest.mark.asyncio
    async def test_get_prompt_negative_version(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        with pytest.raises(ValidationError):
            await client.get_prompt(AGENT_ID, "key123", version=-1)

    @pytest.mark.asyncio
    async def test_get_prompt_negative_string_version(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        with pytest.raises(ValidationError):
            await client.get_prompt(AGENT_ID, "key123", version="-1")

    @pytest.mark.asyncio
    async def test_get_prompt_invalid_version_type(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        with pytest.raises(ValidationError):
            await client.get_prompt(AGENT_ID, "key123", version=3.14)

    @pytest.mark.asyncio
    async def test_get_prompt_empty_key(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        with pytest.raises(ValidationError):
            await client.get_prompt(AGENT_ID, "")

    @pytest.mark.asyncio
    async def test_get_prompt_empty_response(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        # Empty body → data=None after json parse
        client._client = _mock_http_client(_make_httpx_response(200, None))

        with pytest.raises(InfiniumError, match="Empty"):
            await client.get_prompt(AGENT_ID, "key123")

    @pytest.mark.asyncio
    async def test_get_prompt_records_trace_context(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        resp_data = {"promptId": "p-1", "name": "P", "version": 1, "content": "c", "createdAt": ""}
        client._client = _mock_http_client(_make_httpx_response(200, resp_data))

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            await client.get_prompt(AGENT_ID, "key123", variables={"x": "1"})
            assert len(ctx.prompts) == 1
            assert ctx.prompts[0].prompt_name == "P"
        finally:
            set_trace_context(None)

    @pytest.mark.asyncio
    async def test_get_prompt_non_string_content(self):
        """When content is not a string, it should default to empty."""
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        resp_data = {"promptId": "p-1", "name": "P", "version": 1, "content": 123, "createdAt": ""}
        client._client = _mock_http_client(_make_httpx_response(200, resp_data))
        result = await client.get_prompt(AGENT_ID, "key123")
        assert result.content == ""


class TestAsyncClientMakeRequest:
    @pytest.mark.asyncio
    async def test_rate_limiter_used(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET, enable_rate_limiting=True, requests_per_second=100)
        client._client = _mock_http_client(_make_httpx_response(200, {"success": True}))
        result = await client._make_request("GET", "https://test.example.com/api")
        assert result.success is True


class TestAsyncClientGetDatetime:
    def test_get_current_iso_datetime(self):
        result = AsyncInfiniumClient.get_current_iso_datetime()
        assert "T" in result


class TestAsyncClientGetInterpretedResult:
    @pytest.mark.asyncio
    async def test_get_interpreted_result(self):
        client = AsyncInfiniumClient(AGENT_ID, AGENT_SECRET)
        client._client = _mock_http_client(_make_httpx_response(200, {"success": True, "data": {"result": "ok"}}))
        result = await client.get_interpreted_task_result("cccccccc-cccc-cccc-cccc-cccccccccccc")
        assert result.success is True


# ---------------------------------------------------------------------------
# OpenAI Async Stream Wrapper
# ---------------------------------------------------------------------------

class TestOpenAIAsyncStreamUsageAndContent:
    @pytest.mark.asyncio
    async def test_process_chunk_with_usage(self):
        call = CapturedLlmCall(provider="openai", model="gpt-4")

        chunk = Mock()
        chunk.choices = [Mock(delta=Mock(content="hi"))]
        chunk.usage = Mock(prompt_tokens=10, completion_tokens=5)

        wrapper = OpenAIAsyncStreamWrapper(_AsyncIter([chunk]), call, capture_content=True)
        collected = []
        async for c in wrapper:
            collected.append(c)

        assert call.prompt_tokens == 10
        assert call.completion_tokens == 5
        assert call.output_preview is not None

    @pytest.mark.asyncio
    async def test_aexit_with_underlying_stream(self):
        call = CapturedLlmCall(provider="openai", model="gpt-4")
        inner = AsyncMock()
        inner.__aenter__ = AsyncMock(return_value=inner)
        inner.__aexit__ = AsyncMock(return_value=False)
        wrapper = OpenAIAsyncStreamWrapper(inner, call, capture_content=False)
        await wrapper.__aenter__()
        result = await wrapper.__aexit__(None, None, None)
        assert result is False

    @pytest.mark.asyncio
    async def test_chunk_without_content(self):
        """Chunk with no content attr on delta."""
        call = CapturedLlmCall(provider="openai", model="gpt-4")
        chunk = Mock()
        chunk.choices = [Mock(delta=Mock(spec=[]))]  # delta has no content attr
        chunk.usage = None
        wrapper = OpenAIAsyncStreamWrapper(_AsyncIter([chunk]), call, capture_content=True)
        async for _ in wrapper:
            pass
        assert call.output_preview is None


# ---------------------------------------------------------------------------
# Anthropic Async Stream Wrapper
# ---------------------------------------------------------------------------

class TestAnthropicAsyncStreamEvents:
    @pytest.mark.asyncio
    async def test_all_event_types(self):
        call = CapturedLlmCall(provider="anthropic", model="claude-3")
        events = [
            Mock(type="message_start", message=Mock(usage=Mock(input_tokens=50))),
            Mock(type="content_block_delta", delta=Mock(text="hello ")),
            Mock(type="content_block_delta", delta=Mock(text="world")),
            Mock(type="message_delta", usage=Mock(output_tokens=20)),
        ]

        wrapper = AnthropicAsyncStreamWrapper(_AsyncIter(events), call, capture_content=True)
        collected = []
        async for e in wrapper:
            collected.append(e)

        assert call.prompt_tokens == 50
        assert call.completion_tokens == 20
        assert "hello" in call.output_preview

    @pytest.mark.asyncio
    async def test_aexit_with_stream(self):
        call = CapturedLlmCall(provider="anthropic", model="claude-3")
        inner = AsyncMock()
        inner.__aenter__ = AsyncMock(return_value=inner)
        inner.__aexit__ = AsyncMock(return_value=False)
        wrapper = AnthropicAsyncStreamWrapper(inner, call, capture_content=False)
        await wrapper.__aenter__()
        result = await wrapper.__aexit__(None, None, None)
        assert result is False

    @pytest.mark.asyncio
    async def test_missing_attr_event(self):
        call = CapturedLlmCall(provider="anthropic", model="claude-3")
        event = Mock(type="message_start")
        del event.message

        wrapper = AnthropicAsyncStreamWrapper(_AsyncIter([event]), call, capture_content=False)
        async for _ in wrapper:
            pass

    @pytest.mark.asyncio
    async def test_message_delta_missing_usage(self):
        call = CapturedLlmCall(provider="anthropic", model="claude-3")
        event = Mock(type="message_delta")
        del event.usage

        wrapper = AnthropicAsyncStreamWrapper(_AsyncIter([event]), call, capture_content=False)
        async for _ in wrapper:
            pass

    @pytest.mark.asyncio
    async def test_content_block_delta_missing_text(self):
        call = CapturedLlmCall(provider="anthropic", model="claude-3")
        event = Mock(type="content_block_delta")
        event.delta = Mock(spec=[])  # no text attr

        wrapper = AnthropicAsyncStreamWrapper(_AsyncIter([event]), call, capture_content=True)
        async for _ in wrapper:
            pass


# ---------------------------------------------------------------------------
# Google Async Stream Wrapper
# ---------------------------------------------------------------------------

class TestGoogleAsyncStreamUsage:
    @pytest.mark.asyncio
    async def test_process_chunk_with_usage_metadata(self):
        call = CapturedLlmCall(provider="gemini", model="gemini-pro")
        chunk = Mock(text="hello", usage_metadata=Mock(prompt_token_count=15, candidates_token_count=8))

        wrapper = GoogleAsyncStreamWrapper(_AsyncIter([chunk]), call, capture_content=True)
        async for _ in wrapper:
            pass

        assert call.prompt_tokens == 15
        assert call.completion_tokens == 8

    @pytest.mark.asyncio
    async def test_chunk_without_text(self):
        call = CapturedLlmCall(provider="gemini", model="gemini-pro")
        chunk = Mock(text="", usage_metadata=None)

        wrapper = GoogleAsyncStreamWrapper(_AsyncIter([chunk]), call, capture_content=True)
        async for _ in wrapper:
            pass
        assert call.output_preview is None


# ---------------------------------------------------------------------------
# OpenAI _make_async_wrapper
# ---------------------------------------------------------------------------

class TestOpenAIMakeAsyncWrapper:
    @pytest.mark.asyncio
    async def test_non_stream_with_usage(self):
        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            response = Mock()
            response.model = "gpt-4o"
            response.usage = Mock(prompt_tokens=100, completion_tokens=50)
            response.choices = [Mock(message=Mock(content="reply"))]

            original = AsyncMock(return_value=response)
            wrapper = openai_make_async_wrapper(original, "openai", True)
            result = await wrapper(model="gpt-4o", messages=[{"role": "user", "content": "hi"}])
            assert result is response
            assert ctx.calls[0].prompt_tokens == 100
        finally:
            set_trace_context(None)

    @pytest.mark.asyncio
    async def test_stream_returns_wrapper(self):
        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            original = AsyncMock(return_value=_AsyncIter([]))
            wrapper = openai_make_async_wrapper(original, "openai", False)
            result = await wrapper(model="gpt-4o", messages=[], stream=True)
            assert isinstance(result, OpenAIAsyncStreamWrapper)
        finally:
            set_trace_context(None)

    @pytest.mark.asyncio
    async def test_error_captured(self):
        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            original = AsyncMock(side_effect=RuntimeError("api fail"))
            wrapper = openai_make_async_wrapper(original, "openai", False)
            with pytest.raises(RuntimeError):
                await wrapper(model="gpt-4o", messages=[])
            assert ctx.calls[0].error_type == "RuntimeError"
        finally:
            set_trace_context(None)

    @pytest.mark.asyncio
    async def test_no_context_passthrough(self):
        set_trace_context(None)
        original = AsyncMock(return_value="raw")
        wrapper = openai_make_async_wrapper(original, "openai", False)
        result = await wrapper(model="gpt-4o", messages=[])
        assert result == "raw"

    @pytest.mark.asyncio
    async def test_non_stream_no_usage(self):
        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            response = Mock()
            response.model = "gpt-4o"
            response.usage = None
            response.choices = []
            original = AsyncMock(return_value=response)
            wrapper = openai_make_async_wrapper(original, "openai", False)
            await wrapper(model="gpt-4o", messages=[])
            assert ctx.calls[0].prompt_tokens is None
        finally:
            set_trace_context(None)


# ---------------------------------------------------------------------------
# Anthropic _make_async_wrapper
# ---------------------------------------------------------------------------

class TestAnthropicMakeAsyncWrapper:
    @pytest.mark.asyncio
    async def test_non_stream_with_usage(self):
        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            response = Mock()
            response.model = "claude-3-opus"
            response.usage = Mock(input_tokens=80, output_tokens=30)
            response.content = [Mock(text="reply")]

            original = AsyncMock(return_value=response)
            wrapper = anthropic_make_async_wrapper(original, True)
            result = await wrapper(model="claude-3-opus", messages=[{"role": "user", "content": "hi"}])
            assert result is response
            assert ctx.calls[0].prompt_tokens == 80
        finally:
            set_trace_context(None)

    @pytest.mark.asyncio
    async def test_stream_returns_wrapper(self):
        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            original = AsyncMock(return_value=_AsyncIter([]))
            wrapper = anthropic_make_async_wrapper(original, False)
            result = await wrapper(model="claude-3", messages=[], stream=True)
            assert isinstance(result, AnthropicAsyncStreamWrapper)
        finally:
            set_trace_context(None)

    @pytest.mark.asyncio
    async def test_error_captured(self):
        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            original = AsyncMock(side_effect=ValueError("bad"))
            wrapper = anthropic_make_async_wrapper(original, False)
            with pytest.raises(ValueError):
                await wrapper(model="claude-3", messages=[])
            assert ctx.calls[0].error_type == "ValueError"
        finally:
            set_trace_context(None)

    @pytest.mark.asyncio
    async def test_no_context_passthrough(self):
        set_trace_context(None)
        original = AsyncMock(return_value="raw")
        wrapper = anthropic_make_async_wrapper(original, False)
        result = await wrapper(model="claude-3", messages=[])
        assert result == "raw"

    @pytest.mark.asyncio
    async def test_non_stream_no_usage(self):
        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            response = Mock()
            response.model = "claude-3"
            response.usage = None
            response.content = []
            original = AsyncMock(return_value=response)
            wrapper = anthropic_make_async_wrapper(original, False)
            await wrapper(model="claude-3", messages=[])
            assert ctx.calls[0].prompt_tokens is None
        finally:
            set_trace_context(None)


# ---------------------------------------------------------------------------
# Instrumentor classes
# ---------------------------------------------------------------------------

class TestOpenAIInstrumentor:
    def test_instrument_and_uninstrument(self):
        from infinium.integrations.openai import OpenAIInstrumentor

        mock_sync_create = lambda self, *a, **kw: None
        mock_async_create = lambda self, *a, **kw: None

        mock_sync_cls = type("Completions", (), {"create": mock_sync_create})
        mock_async_cls = type("AsyncCompletions", (), {"create": mock_async_create})

        mock_completions = MagicMock()
        mock_completions.Completions = mock_sync_cls
        mock_completions.AsyncCompletions = mock_async_cls

        mock_chat = MagicMock()
        mock_chat.completions = mock_completions

        mock_resources = MagicMock()
        mock_resources.chat = mock_chat
        mock_resources.chat.completions = mock_completions

        mock_openai = MagicMock()
        mock_openai.resources = mock_resources
        mock_openai.resources.chat = mock_chat
        mock_openai.resources.chat.completions = mock_completions

        OpenAIInstrumentor._original_sync_create = None
        OpenAIInstrumentor._original_async_create = None

        with patch.dict("sys.modules", {"openai": mock_openai, "openai.resources": mock_resources, "openai.resources.chat": mock_chat, "openai.resources.chat.completions": mock_completions}):
            inst = OpenAIInstrumentor(capture_content=True)
            inst.instrument()
            assert OpenAIInstrumentor._original_sync_create is not None
            assert hasattr(mock_sync_cls.create, "_infinium_patched")
            inst.uninstrument()
            assert OpenAIInstrumentor._original_sync_create is None
            assert OpenAIInstrumentor._original_async_create is None

    def test_instrument_import_error(self):
        from infinium.integrations.openai import OpenAIInstrumentor
        OpenAIInstrumentor._original_sync_create = None
        OpenAIInstrumentor._original_async_create = None
        with patch.dict("sys.modules", {"openai": None}):
            inst = OpenAIInstrumentor()
            inst.instrument()
            assert OpenAIInstrumentor._original_sync_create is None

    def test_uninstrument_import_error(self):
        from infinium.integrations.openai import OpenAIInstrumentor
        with patch.dict("sys.modules", {"openai": None}):
            inst = OpenAIInstrumentor()
            inst.uninstrument()


class TestAnthropicInstrumentor:
    def test_instrument_and_uninstrument(self):
        from infinium.integrations.anthropic import AnthropicInstrumentor

        mock_sync_create = lambda self, *a, **kw: None
        mock_async_create = lambda self, *a, **kw: None

        mock_sync_cls = type("Messages", (), {"create": mock_sync_create})
        mock_async_cls = type("AsyncMessages", (), {"create": mock_async_create})

        mock_messages = MagicMock()
        mock_messages.Messages = mock_sync_cls
        mock_messages.AsyncMessages = mock_async_cls

        mock_resources = MagicMock()
        mock_resources.messages = mock_messages

        mock_anthropic = MagicMock()
        mock_anthropic.resources = mock_resources
        mock_anthropic.resources.messages = mock_messages

        AnthropicInstrumentor._original_sync_create = None
        AnthropicInstrumentor._original_async_create = None

        with patch.dict("sys.modules", {"anthropic": mock_anthropic, "anthropic.resources": mock_resources, "anthropic.resources.messages": mock_messages}):
            inst = AnthropicInstrumentor(capture_content=True)
            inst.instrument()
            assert AnthropicInstrumentor._original_sync_create is not None
            inst.uninstrument()
            assert AnthropicInstrumentor._original_sync_create is None

    def test_instrument_import_error(self):
        from infinium.integrations.anthropic import AnthropicInstrumentor
        AnthropicInstrumentor._original_sync_create = None
        AnthropicInstrumentor._original_async_create = None
        with patch.dict("sys.modules", {"anthropic": None}):
            inst = AnthropicInstrumentor()
            inst.instrument()
            assert AnthropicInstrumentor._original_sync_create is None

    def test_uninstrument_import_error(self):
        from infinium.integrations.anthropic import AnthropicInstrumentor
        with patch.dict("sys.modules", {"anthropic": None}):
            inst = AnthropicInstrumentor()
            inst.uninstrument()


class TestGoogleInstrumentor:
    def test_instrument_and_uninstrument(self):
        from infinium.integrations.google import GoogleInstrumentor

        mock_model_cls = type("GenerativeModel", (), {
            "generate_content": lambda self, *a, **kw: None,
            "generate_content_async": lambda self, *a, **kw: None,
        })

        mock_google_genai = MagicMock()
        mock_google_genai.GenerativeModel = mock_model_cls

        GoogleInstrumentor._original_sync = None
        GoogleInstrumentor._original_async = None

        with patch.dict("sys.modules", {"google": MagicMock(), "google.generativeai": mock_google_genai}):
            inst = GoogleInstrumentor(capture_content=True)
            inst.instrument()
            assert GoogleInstrumentor._original_sync is not None
            inst.uninstrument()
            assert GoogleInstrumentor._original_sync is None

    def test_instrument_import_error(self):
        from infinium.integrations.google import GoogleInstrumentor
        GoogleInstrumentor._original_sync = None
        GoogleInstrumentor._original_async = None
        with patch.dict("sys.modules", {"google": None, "google.generativeai": None}):
            inst = GoogleInstrumentor()
            inst.instrument()
            assert GoogleInstrumentor._original_sync is None

    def test_uninstrument_import_error(self):
        from infinium.integrations.google import GoogleInstrumentor
        with patch.dict("sys.modules", {"google": None, "google.generativeai": None}):
            inst = GoogleInstrumentor()
            inst.uninstrument()


# ---------------------------------------------------------------------------
# Sync client additional edge cases
# ---------------------------------------------------------------------------

class TestSyncClientEdgeCases:
    def test_send_task_with_all_optional_fields(self):
        from infinium import InfiniumClient
        client = InfiniumClient(AGENT_ID, AGENT_SECRET)
        resp = _make_httpx_response(200, {"success": True, "data": {}})

        with patch.object(client, "_make_request", return_value=client._handle_response(resp)):
            result = client.send_task(
                name="Test", description="Desc", duration=5,
                llm_usage=LlmUsage(total_tokens=50),
                steps=[ExecutionStep(step_number=1, action="run", description="step")],
                errors=[ErrorDetail(error_type="E", message="m")],
                expected_outcome=ExpectedOutcome(task_objective="pass"),
                environment=EnvironmentContext(framework="linux"),
                support=Support(call_id="T-1"),
            )
            assert result.success is True

    def test_send_task_invalid_datetime(self):
        from infinium import InfiniumClient
        client = InfiniumClient(AGENT_ID, AGENT_SECRET)
        with pytest.raises(ValidationError):
            client.send_task(
                name="T", description="D", duration=1,
                current_datetime="nope",
            )

    def test_task_data_to_dict_minimal(self):
        from infinium import InfiniumClient
        client = InfiniumClient(AGENT_ID, AGENT_SECRET)
        td = TaskData(
            name="T", description="D", current_datetime="2024-01-01T00:00:00Z",
            duration=1,
        )
        d = client._task_data_to_dict(td)
        assert d["name"] == "T"
