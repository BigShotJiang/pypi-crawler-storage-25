"""
Tests for AsyncInfiniumClient.
"""
import pytest
import asyncio
from unittest.mock import Mock, patch, AsyncMock
from infinium import AsyncInfiniumClient, TaskData
from infinium.types import (
    Customer, Sales, BatchResult, ExecutionStep, ExpectedOutcome,
    EnvironmentContext, ErrorDetail, LlmUsage,
)
from infinium.exceptions import (
    ValidationError, AuthenticationError, RateLimitError,
    NetworkError, ServerError, NotFoundError, InfiniumTimeoutError,
)


@pytest.fixture
async def async_client():
    client = AsyncInfiniumClient(
        agent_id="a1b2c3d4-e5f6-7890-abcd-ef1234567890",
        agent_secret="test-agent-secret-long-enough"
    )
    yield client
    await client.close()


@pytest.fixture
def mock_async_httpx_response():
    mock_resp = Mock()
    mock_resp.status_code = 200
    mock_resp.is_success = True
    mock_resp.json.return_value = {"message": "Success", "status": "success"}
    mock_resp.content = b'{"message": "Success"}'
    mock_resp.headers = {}
    return mock_resp


class TestAsyncInfiniumClient:
    def test_initialization(self):
        client = AsyncInfiniumClient(
            agent_id="test-agent",
            agent_secret="test-secret",
            base_url="https://custom.api.com",
            timeout=60.0,
            max_retries=5,
        )
        assert client.agent_id == "test-agent"
        assert client.base_url == "https://custom.api.com"
        assert client.timeout == 60.0

    def test_initialization_invalid_credentials(self):
        with pytest.raises(ValidationError, match="agent_id is required"):
            AsyncInfiniumClient(agent_id="", agent_secret="secret")
        with pytest.raises(ValidationError, match="agent_secret is required"):
            AsyncInfiniumClient(agent_id="agent", agent_secret="")

    def test_get_headers(self, async_client):
        headers = async_client._get_headers()
        assert headers["x-agent-id"] == "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
        assert headers["x-agent-key"] == "test-agent-secret-long-enough"

    async def test_send_task_success(self, async_client, mock_async_httpx_response):
        with patch.object(async_client, '_make_request') as mock_req:
            mock_req.return_value = Mock(success=True, status_code=200, data={}, message="Success")
            response = await async_client.send_task(
                name="Test", description="Desc", duration=120.5            )
            assert response.success is True

    async def test_authentication_error(self, async_client):
        with patch.object(async_client, '_make_request', side_effect=AuthenticationError("Auth failed")):
            with pytest.raises(AuthenticationError):
                await async_client.send_task(name="T", description="D", duration=100)

    async def test_rate_limit_error(self, async_client):
        with patch.object(async_client, '_make_request', side_effect=RateLimitError("Rate limited")):
            with pytest.raises(RateLimitError):
                await async_client.send_task(name="T", description="D", duration=100)

    async def test_server_error(self, async_client):
        with patch.object(async_client, '_make_request', side_effect=ServerError("Server error")):
            with pytest.raises(ServerError):
                await async_client.send_task(name="T", description="D", duration=100)

    async def test_send_task_validation_errors(self, async_client):
        with pytest.raises(ValidationError, match="name cannot be empty"):
            await async_client.send_task(name="", description="D", duration=100)

    async def test_send_tasks_batch(self, async_client):
        tasks = [
            TaskData(name=f"Task {i}", description=f"D {i}",
                     current_datetime="2025-10-07T12:00:00Z", duration=float(i * 10))
            for i in range(1, 4)
        ]
        with patch.object(async_client, 'send_task_data') as mock_send:
            mock_send.return_value = Mock(success=True, status_code=200, data={})
            result = await async_client.send_tasks_batch(tasks)
            assert isinstance(result, BatchResult)
            assert result.successful >= 3
            assert result.failed == 0

    def test_create_task_data_static_method(self):
        td = AsyncInfiniumClient.create_task_data(
            name="Test", description="Desc", duration=100        )
        assert isinstance(td, TaskData)
        assert td.current_datetime is not None

    def test_get_current_iso_datetime(self, async_client):
        dt = async_client.get_current_iso_datetime()
        assert isinstance(dt, str)
        assert dt.endswith("Z")


class TestAsyncSerialization:
    """Tests for async _task_data_to_dict (same logic as sync)."""

    def test_new_fields_serialized(self, async_client):
        td = TaskData(
            name="Test", description="Desc",
            current_datetime="2025-10-07T12:00:00Z", duration=100.0,
            expected_outcome=ExpectedOutcome(task_objective="Obj"),
            steps=[ExecutionStep(step_number=1, action="a", description="d")],
            errors=[ErrorDetail(error_type="E", message="m")],
            environment=EnvironmentContext(framework="f"),
        )
        result = async_client._task_data_to_dict(td)
        assert "expected_outcome" in result
        assert "steps" in result
        assert "errors" in result
        assert "environment" in result



class TestAsyncDictCoercion:
    def test_dict_coerced(self):
        td = AsyncInfiniumClient.create_task_data(
            name="Test", description="Desc", duration=100,
            customer={"customer_name": "Bob"},
            expected_outcome={"task_objective": "Do it"},
        )
        assert isinstance(td.customer, Customer)
        assert isinstance(td.expected_outcome, ExpectedOutcome)


class TestAsyncWaitForInterpretation:
    async def test_returns_immediately_when_ready(self, async_client):
        with patch.object(async_client, 'get_interpreted_task_result') as mock_get:
            mock_get.return_value = Mock(data={"interpretedTraceResult": '{"score": 85}'})
            result = await async_client.wait_for_interpretation("a1b2c3d4-e5f6-7890-abcd-ef1234567890")
            assert result.data["interpretedTraceResult"] is not None

    async def test_polls_until_ready(self, async_client):
        empty = Mock(data={"interpretedTraceResult": None})
        ready = Mock(data={"interpretedTraceResult": '{"score": 90}'})

        with patch.object(async_client, 'get_interpreted_task_result', side_effect=[empty, empty, ready]):
            result = await async_client.wait_for_interpretation(
                "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                timeout=10, poll_interval=0.01,
            )
            assert result.data["interpretedTraceResult"] is not None

    async def test_timeout_raises(self, async_client):
        empty = Mock(data={"interpretedTraceResult": None})
        with patch.object(async_client, 'get_interpreted_task_result', return_value=empty):
            with pytest.raises(InfiniumTimeoutError, match="Interpretation not ready"):
                await async_client.wait_for_interpretation(
                    "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                    timeout=0.05, poll_interval=0.01,
                )
