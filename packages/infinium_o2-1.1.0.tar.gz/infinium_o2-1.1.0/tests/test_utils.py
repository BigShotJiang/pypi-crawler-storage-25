"""
Tests for utils module.
"""
import pytest
import time
import logging
from datetime import datetime, timezone
from typing import Optional
from unittest.mock import patch
from dataclasses import dataclass

from infinium.utils import (
    validate_agent_credentials, validate_iso_datetime,
    validate_duration, validate_required_field,
    get_current_iso_datetime, dataclass_to_dict, exponential_backoff,
    safe_json_loads, merge_dicts, RateLimiter, setup_logging, truncate_string,
    retry_with_backoff, coerce_section,
    validate_path_id, validate_string_length, validate_payload_size,
)
from infinium.types import (
    Customer, ErrorDetail, ExecutionStep, LlmCall,
    ExpectedOutcome, EnvironmentContext,
)
from infinium.exceptions import ValidationError


class TestValidation:
    def test_validate_agent_credentials_valid(self):
        validate_agent_credentials("valid-agent", "valid-secret")

    def test_validate_agent_credentials_invalid_agent_id(self):
        with pytest.raises(ValidationError, match="agent_id is required"):
            validate_agent_credentials("", "valid-secret")
        with pytest.raises(ValidationError, match="agent_id is required"):
            validate_agent_credentials(None, "valid-secret")

    def test_validate_agent_credentials_invalid_agent_secret(self):
        with pytest.raises(ValidationError, match="agent_secret is required"):
            validate_agent_credentials("valid-agent", "")

    def test_validate_iso_datetime_valid(self):
        assert validate_iso_datetime("2025-10-07T12:00:00Z") is True
        assert validate_iso_datetime("2025-10-07T12:00:00+00:00") is True
        assert validate_iso_datetime("2025-10-07T12:00:00.123Z") is True

    def test_validate_iso_datetime_invalid(self):
        assert validate_iso_datetime("invalid-date") is False
        assert validate_iso_datetime("") is False
        assert validate_iso_datetime(None) is False
        assert validate_iso_datetime(123) is False
        assert validate_iso_datetime("1800-01-01T00:00:00Z") is False
        assert validate_iso_datetime("2200-01-01T00:00:00Z") is False

    def test_validate_duration_valid(self):
        assert validate_duration(100) == 100.0
        assert validate_duration(0) == 0.0
        assert validate_duration("100.5") == 100.5

    def test_validate_duration_invalid(self):
        with pytest.raises(ValidationError, match="duration must be non-negative"):
            validate_duration(-1)
        with pytest.raises(ValidationError, match="duration must be a number"):
            validate_duration("invalid")
        with pytest.raises(ValidationError, match="duration cannot be NaN"):
            validate_duration(float('nan'))
        with pytest.raises(ValidationError, match="duration cannot be infinite"):
            validate_duration(float('inf'))
        with pytest.raises(ValidationError, match="duration cannot exceed"):
            validate_duration(25 * 60 * 60)

    def test_validate_required_field(self):
        validate_required_field("valid", "field")
        with pytest.raises(ValidationError, match="field is required"):
            validate_required_field(None, "field")
        with pytest.raises(ValidationError, match="field cannot be empty"):
            validate_required_field("", "field")

    def test_validate_path_id(self):
        valid = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
        assert validate_path_id(valid, "id") == valid
        with pytest.raises(ValidationError, match="contains invalid characters"):
            validate_path_id("../bad", "id")
        with pytest.raises(ValidationError, match="must be a valid UUID"):
            validate_path_id("not-a-uuid", "id")

    def test_validate_string_length(self):
        assert validate_string_length("short", "f", 100) == "short"
        with pytest.raises(ValidationError, match="exceeds maximum length"):
            validate_string_length("a" * 101, "f", 100)

    def test_validate_payload_size(self):
        validate_payload_size({"small": "data"})
        with pytest.raises(ValidationError, match="Payload exceeds maximum size"):
            validate_payload_size({"big": "x" * 2_000_000})


class TestUtilityFunctions:
    def test_get_current_iso_datetime(self):
        dt = get_current_iso_datetime()
        assert isinstance(dt, str)
        assert "T" in dt
        assert dt.endswith("Z")
        assert validate_iso_datetime(dt) is True

    def test_dataclass_to_dict(self):
        customer = Customer(customer_name="John", customer_email="john@test.com", customer_phone=None)
        result = dataclass_to_dict(customer)
        assert result["customer_name"] == "John"
        assert "customer_phone" not in result

    def test_dataclass_to_dict_none(self):
        assert dataclass_to_dict(None) == {}

    def test_dataclass_to_dict_non_dataclass(self):
        assert dataclass_to_dict("string") == {}
        assert dataclass_to_dict(123) == {}

    def test_dataclass_to_dict_nested(self):
        """Test recursive handling of nested dataclasses."""
        step = ExecutionStep(
            step_number=1,
            action="tool_use",
            description="Search",
            llm_call=LlmCall(model="gpt-4o", prompt_tokens=1000),
            error=None,
        )
        result = dataclass_to_dict(step)
        assert result["step_number"] == 1
        assert result["llm_call"]["model"] == "gpt-4o"
        assert "error" not in result  # None filtered out

    def test_dataclass_to_dict_list_of_dataclasses(self):
        """Test handling of lists containing dataclasses."""
        @dataclass
        class WithList:
            items: list

        obj = WithList(items=[
            Customer(customer_name="A"),
            Customer(customer_name=None),  # all None fields -> empty dict -> excluded
            "plain_string",
            None,
        ])
        result = dataclass_to_dict(obj)
        assert len(result["items"]) == 2
        assert result["items"][0] == {"customer_name": "A"}
        assert result["items"][1] == "plain_string"

    def test_dataclass_to_dict_with_error_detail_in_step(self):
        """New types serialize correctly."""
        step = ExecutionStep(
            step_number=1,
            action="call_api",
            description="Call external API",
            error=ErrorDetail(error_type="Timeout", message="Timed out", retry_count=2),
        )
        result = dataclass_to_dict(step)
        assert result["error"]["error_type"] == "Timeout"
        assert result["error"]["retry_count"] == 2

    def test_exponential_backoff(self):
        assert exponential_backoff(0, jitter=False) == 1.0
        assert exponential_backoff(1, jitter=False) == 2.0
        assert exponential_backoff(2, jitter=False) == 4.0
        assert exponential_backoff(10, max_delay=5.0, jitter=False) == 5.0

    def test_safe_json_loads(self):
        assert safe_json_loads('{"key": "value"}') == {"key": "value"}
        assert safe_json_loads('[]') is None
        assert safe_json_loads('invalid') is None
        assert safe_json_loads(None) is None
        assert safe_json_loads({"already": "dict"}) == {"already": "dict"}

    def test_merge_dicts(self):
        assert merge_dicts({"a": 1}, {"b": 2}) == {"a": 1, "b": 2}
        assert merge_dicts({"a": 1}, {"a": 2}) == {"a": 2}
        assert merge_dicts() == {}
        assert merge_dicts({"a": 1}, "not_a_dict", {"b": 2}) == {"a": 1, "b": 2}

    def test_truncate_string(self):
        assert truncate_string("short", 20) == "short"
        result = truncate_string("a" * 50, 20)
        assert len(result) == 20
        assert result.endswith("...")

    def test_setup_logging(self):
        with patch('logging.basicConfig') as mock:
            setup_logging(level="INFO")
            mock.assert_called_once()

    def test_retry_with_backoff_success(self):
        import asyncio
        result = asyncio.run(retry_with_backoff(lambda: "ok"))
        assert result == "ok"

    def test_retry_with_backoff_failure(self):
        import asyncio
        with pytest.raises(ValueError, match="fail"):
            asyncio.run(retry_with_backoff(lambda: (_ for _ in ()).throw(ValueError("fail")), max_retries=1))


class TestCoerceSection:
    def test_coerce_dict_to_dataclass(self):
        result = coerce_section({"customer_name": "Alice", "client_company": "Acme"}, Customer)
        assert isinstance(result, Customer)
        assert result.customer_name == "Alice"
        assert result.client_company == "Acme"

    def test_coerce_passes_through_dataclass(self):
        c = Customer(customer_name="Bob")
        result = coerce_section(c, Customer)
        assert result is c

    def test_coerce_passes_through_none(self):
        assert coerce_section(None, Customer) is None

    def test_coerce_passes_through_non_dict(self):
        assert coerce_section("string", Customer) == "string"

    def test_coerce_extra_keys_into_metadata(self):
        result = coerce_section(
            {"step_number": 1, "action": "test", "description": "desc", "custom_key": "val"},
            ExecutionStep,
        )
        assert isinstance(result, ExecutionStep)
        assert result.metadata == {"custom_key": "val"}

    def test_coerce_expected_outcome(self):
        result = coerce_section(
            {"task_objective": "Do something", "required_deliverables": ["A", "B"]},
            ExpectedOutcome,
        )
        assert isinstance(result, ExpectedOutcome)
        assert result.task_objective == "Do something"
        assert len(result.required_deliverables) == 2

    def test_coerce_environment_context(self):
        result = coerce_section(
            {"framework": "langchain", "python_version": "3.12"},
            EnvironmentContext,
        )
        assert isinstance(result, EnvironmentContext)
        assert result.framework == "langchain"


class TestRateLimiter:
    def test_initialization(self):
        limiter = RateLimiter()
        assert limiter.requests_per_second == 10.0
        assert limiter.burst_size == 20

    def test_initialization_invalid(self):
        with pytest.raises(ValueError):
            RateLimiter(requests_per_second=0)
        with pytest.raises(ValueError):
            RateLimiter(burst_size=0)

    @pytest.mark.asyncio
    async def test_acquire(self):
        limiter = RateLimiter(requests_per_second=10.0, burst_size=5)
        await limiter.acquire()
        assert limiter.tokens == 4

    def test_acquire_sync(self):
        limiter = RateLimiter(requests_per_second=10.0, burst_size=5)
        limiter.acquire_sync()
        assert limiter.tokens == 4

    @pytest.mark.asyncio
    async def test_token_replenishment(self):
        limiter = RateLimiter(requests_per_second=10.0, burst_size=2)
        await limiter.acquire()
        await limiter.acquire()
        # Tokens may be slightly above 0 due to time elapsed between acquires
        assert limiter.tokens < 0.1
        start = time.time()
        await limiter.acquire()
        assert time.time() - start >= 0.05
