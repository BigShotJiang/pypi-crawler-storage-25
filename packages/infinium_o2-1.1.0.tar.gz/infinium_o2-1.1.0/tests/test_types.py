"""
Tests for types and data structures.
"""
import pytest

from infinium.types import (
    TaskData, ApiResponse, BatchResult,
    TimeTracking, Customer, Support, Sales, Marketing, Content, Research,
    Project, Development, Executive, General, LlmUsage,
    # New types
    ExecutionStep, ErrorDetail, ToolCall, LlmCall,
    ExpectedOutcome, EnvironmentContext,
)


class TestTaskData:
    def test_task_data_creation(self):
        task = TaskData(
            name="Test Task",
            description="Test description",
            current_datetime="2025-10-07T12:00:00Z",
            duration=120.5,
        )
        assert task.name == "Test Task"
        assert task.duration == 120.5

    def test_task_data_with_optional_fields(self):
        customer = Customer(customer_name="John Doe", customer_email="john@example.com")
        time_tracking = TimeTracking(start_time="2025-10-07T11:00:00Z", end_time="2025-10-07T13:00:00Z")

        task = TaskData(
            name="Customer Task",
            description="Handle customer inquiry",
            current_datetime="2025-10-07T12:00:00Z",
            duration=7200.0,
            customer=customer,
            time_tracking=time_tracking
        )
        assert task.customer.customer_name == "John Doe"
        assert task.time_tracking.start_time == "2025-10-07T11:00:00Z"

    def test_task_data_with_new_fields(self):
        steps = [
            ExecutionStep(step_number=1, action="search", description="Search database"),
            ExecutionStep(step_number=2, action="llm_inference", description="Summarize"),
        ]
        errors = [ErrorDetail(error_type="TimeoutError", message="API timed out")]
        expected = ExpectedOutcome(
            task_objective="Find and summarize data",
            required_deliverables=["Summary report"],
        )
        env = EnvironmentContext(framework="langchain", sdk_version="0.2.0")

        task = TaskData(
            name="Rich Task",
            description="Task with all new fields",
            current_datetime="2025-10-07T12:00:00Z",
            duration=300.0,
            steps=steps,
            errors=errors,
            expected_outcome=expected,
            environment=env,
            input_summary="Query: find earnings data",
            output_summary="Generated 500-word summary",
        )
        assert len(task.steps) == 2
        assert task.steps[0].action == "search"
        assert len(task.errors) == 1
        assert task.expected_outcome.task_objective == "Find and summarize data"
        assert task.environment.framework == "langchain"



class TestNewDataclasses:
    """Tests for new trace-enrichment dataclasses."""

    def test_error_detail(self):
        err = ErrorDetail(
            error_type="ValueError",
            message="Invalid input",
            recoverable=True,
            retry_count=2,
            error_code="VAL_001",
        )
        assert err.error_type == "ValueError"
        assert err.recoverable is True
        assert err.retry_count == 2
        assert err.stack_trace is None

    def test_tool_call(self):
        tc = ToolCall(
            tool_name="web_search",
            duration_ms=450,
            input_summary="query: AAPL earnings",
            output_summary="Found 5 results",
            http_status=200,
        )
        assert tc.tool_name == "web_search"
        assert tc.duration_ms == 450
        assert tc.error is None

    def test_tool_call_with_error(self):
        err = ErrorDetail(error_type="APIError", message="Rate limited")
        tc = ToolCall(tool_name="api_call", error=err)
        assert tc.error.error_type == "APIError"

    def test_llm_call(self):
        lc = LlmCall(
            model="gpt-4o",
            provider="openai",
            prompt_tokens=2000,
            completion_tokens=500,
            latency_ms=3200,
            temperature=0.7,
            purpose="main_reasoning",
        )
        assert lc.model == "gpt-4o"
        assert lc.prompt_tokens == 2000

    def test_execution_step(self):
        step = ExecutionStep(
            step_number=1,
            action="llm_inference",
            description="Summarize findings",
            duration_ms=3500,
            input_preview="Document text...",
            output_preview="Summary: ...",
            llm_call=LlmCall(model="gpt-4o", prompt_tokens=1000),
            metadata={"key": "value"},
        )
        assert step.step_number == 1
        assert step.action == "llm_inference"
        assert step.llm_call.model == "gpt-4o"
        assert step.error is None

    def test_expected_outcome(self):
        eo = ExpectedOutcome(
            task_objective="Produce Q4 earnings summary",
            required_deliverables=["Revenue breakdown", "Margin analysis"],
            constraints=["Use public data only"],
            acceptance_criteria=["Cover all business segments"],
        )
        assert eo.task_objective == "Produce Q4 earnings summary"
        assert len(eo.required_deliverables) == 2

    def test_environment_context(self):
        env = EnvironmentContext(
            framework="crewai",
            framework_version="0.3.0",
            python_version="3.12.1",
            sdk_version="0.2.0",
            runtime="docker",
            custom_tags={"env": "prod"},
        )
        assert env.framework == "crewai"
        assert env.custom_tags["env"] == "prod"


class TestEnhancedExistingDataclasses:
    """Tests for enhanced fields on existing dataclasses."""

    def test_general_new_fields(self):
        g = General(
            tools_used=["web_search", "calculator"],
            agent_notes="Completed successfully",
            errors_encountered=[ErrorDetail(error_type="Timeout", message="API slow")],
            retries=2,
            warnings=["Rate limit approaching"],
            external_apis_called=["openai", "serpapi"],
            data_sources_accessed=["postgres", "redis"],
            tags=["urgent", "customer-facing"],
        )
        assert isinstance(g.tools_used, list)
        assert len(g.errors_encountered) == 1
        assert g.retries == 2
        assert "urgent" in g.tags

    def test_general_backward_compat_string_tools(self):
        """tools_used still accepts a string for backward compat."""
        g = General(tools_used="VS Code, Git, Docker")
        assert g.tools_used == "VS Code, Git, Docker"

    def test_research_new_fields(self):
        r = Research(
            research_topic="Market Analysis",
            data_sources=["Academic papers", "Industry reports"],
            sources_consulted=15,
            key_findings=["Strong demand", "Growing market"],
            confidence_level="high",
            data_quality="good",
        )
        assert isinstance(r.data_sources, list)
        assert r.sources_consulted == 15
        assert len(r.key_findings) == 2

    def test_research_backward_compat_string_sources(self):
        r = Research(data_sources="Academic papers, industry reports")
        assert r.data_sources == "Academic papers, industry reports"

    def test_llm_usage_new_fields(self):
        lu = LlmUsage(
            model="gpt-4o",
            total_latency_ms=5000,
            calls=[
                LlmCall(model="gpt-4o", prompt_tokens=1000),
                LlmCall(model="gpt-4o", prompt_tokens=2000),
            ],
        )
        assert lu.total_latency_ms == 5000
        assert len(lu.calls) == 2

    def test_development_new_fields(self):
        d = Development(
            programming_language="Python",
            files_modified=["main.py", "utils.py"],
            tests_run=42,
            tests_passed=41,
            performance_metrics={"p99_latency_ms": 120, "throughput_rps": 500},
        )
        assert len(d.files_modified) == 2
        assert d.tests_run == 42
        assert isinstance(d.performance_metrics, dict)

    def test_development_backward_compat_string_metrics(self):
        d = Development(performance_metrics="p99: 120ms")
        assert d.performance_metrics == "p99: 120ms"

    def test_executive_new_fields(self):
        e = Executive(
            meeting_type="Board Meeting",
            agenda_items=["Budget review", "Strategic planning"],
            action_items=["Approve Q1 budget", "Hire VP"],
            decisions_made=["Budget approved", "Hiring timeline set"],
        )
        assert isinstance(e.agenda_items, list)
        assert len(e.decisions_made) == 2

    def test_executive_backward_compat_string(self):
        e = Executive(agenda_items="Budget review, strategic planning")
        assert e.agenda_items == "Budget review, strategic planning"

    def test_project_new_fields(self):
        p = Project(
            project_name="SDK v2",
            deliverables=["Python SDK", "Node SDK"],
            stakeholders=["Engineering", "Product"],
            blockers=["API spec not finalized"],
        )
        assert isinstance(p.deliverables, list)
        assert len(p.blockers) == 1


class TestDataclasses:
    """Test existing section dataclasses (unchanged API)."""

    def test_time_tracking(self):
        tt = TimeTracking(start_time="2025-10-07T10:00:00Z", end_time="2025-10-07T12:00:00Z")
        assert tt.start_time == "2025-10-07T10:00:00Z"

    def test_customer(self):
        c = Customer(customer_name="Alice", client_company="Acme Corp")
        assert c.customer_name == "Alice"

    def test_support(self):
        s = Support(call_id="CALL-123", follow_up_required=False)
        assert s.follow_up_required is False

    def test_sales(self):
        s = Sales(deal_value=10000.0, conversion_rate=0.85)
        assert s.deal_value == 10000.0

    def test_marketing(self):
        m = Marketing(campaign_name="Q4 Launch", target_audience="Enterprise")
        assert m.campaign_name == "Q4 Launch"

    def test_content(self):
        c = Content(content_type="Blog Post", content_length=2500)
        assert c.content_length == 2500


class TestApiResponse:
    def test_api_response_success(self):
        response = ApiResponse(success=True, status_code=200, message="OK", data={"id": "123"})
        assert response.success is True
        assert response.data["id"] == "123"

    def test_api_response_failure(self):
        response = ApiResponse(success=False, status_code=400, message="Bad request")
        assert response.success is False


class TestBatchResult:
    def test_batch_result(self):
        results = [
            ApiResponse(success=True, status_code=200, message="OK"),
            ApiResponse(success=False, status_code=400, message="Failed"),
        ]
        br = BatchResult(successful=1, failed=1, results=results, errors=["Task 2 failed"])
        assert br.successful == 1
        assert br.failed == 1
        assert len(br.results) == 2
        assert len(br.errors) == 1
