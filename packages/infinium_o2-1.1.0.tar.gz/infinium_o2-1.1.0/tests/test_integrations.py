"""
Tests for the zero-boilerplate LLM integration layer.

All provider SDKs are mocked — no real API calls are made.
"""
import time
import pytest
from unittest.mock import Mock, AsyncMock, MagicMock, patch
from dataclasses import dataclass

from infinium import TaskData
from infinium.integrations._context import (
    CapturedLlmCall,
    CapturedPromptFetch,
    TraceContext,
    get_current_trace_context,
    set_trace_context,
)
from infinium.integrations.openai import (
    patch_openai_client,
    patch_async_openai_client,
    _detect_provider,
)
from infinium.integrations.anthropic import (
    patch_anthropic_client,
    patch_async_anthropic_client,
)
from infinium.integrations.google import patch_google_model, patch_google_genai_client
from infinium.integrations import watch
from infinium.tracing import TraceBuilder, trace_agent, async_trace_agent


# ---------------------------------------------------------------------------
# Helpers — mock LLM objects
# ---------------------------------------------------------------------------

def _make_openai_response(model="gpt-4o", prompt_tokens=100, completion_tokens=50, content="Hello"):
    """Create a mock OpenAI ChatCompletion response."""
    usage = Mock()
    usage.prompt_tokens = prompt_tokens
    usage.completion_tokens = completion_tokens

    message = Mock()
    message.content = content

    choice = Mock()
    choice.message = message

    response = Mock()
    response.model = model
    response.usage = usage
    response.choices = [choice]
    return response


def _make_openai_client(response=None):
    """Create a mock that looks like openai.OpenAI()."""
    if response is None:
        response = _make_openai_response()

    create_fn = Mock(return_value=response)
    completions = Mock()
    completions.create = create_fn

    chat = Mock()
    chat.completions = completions

    client = Mock()
    client.chat = chat
    type(client).__name__ = "OpenAI"
    type(client).__module__ = "openai._client"
    return client


def _make_async_openai_client(response=None):
    if response is None:
        response = _make_openai_response()

    create_fn = AsyncMock(return_value=response)
    completions = Mock()
    completions.create = create_fn

    chat = Mock()
    chat.completions = completions

    client = Mock()
    client.chat = chat
    type(client).__name__ = "AsyncOpenAI"
    type(client).__module__ = "openai._async_client"
    return client


def _make_anthropic_response(model="claude-3-5-sonnet", input_tokens=200, output_tokens=80):
    usage = Mock()
    usage.input_tokens = input_tokens
    usage.output_tokens = output_tokens

    text_block = Mock()
    text_block.text = "Anthropic says hello"

    response = Mock()
    response.model = model
    response.usage = usage
    response.content = [text_block]
    return response


def _make_anthropic_client(response=None):
    if response is None:
        response = _make_anthropic_response()

    create_fn = Mock(return_value=response)
    messages = Mock()
    messages.create = create_fn

    client = Mock()
    client.messages = messages
    type(client).__name__ = "Anthropic"
    type(client).__module__ = "anthropic._client"
    return client


def _make_google_response(prompt_tokens=150, completion_tokens=60, text="Gemini says hello"):
    meta = Mock()
    meta.prompt_token_count = prompt_tokens
    meta.candidates_token_count = completion_tokens

    response = Mock()
    response.text = text
    response.usage_metadata = meta
    return response


def _make_google_model(response=None):
    if response is None:
        response = _make_google_response()

    model = Mock()
    model.model_name = "gemini-1.5-pro"
    model.generate_content = Mock(return_value=response)
    type(model).__name__ = "GenerativeModel"
    type(model).__module__ = "google.generativeai.generative_models"
    return model


def _make_google_genai_client(response=None):
    """Mock a google-genai Client (v1.70.0+) with client.models.generate_content."""
    if response is None:
        response = _make_google_response()

    models = Mock()
    models.generate_content = Mock(return_value=response)
    models.generate_content_stream = Mock(return_value=iter([]))

    client = Mock()
    client.models = models
    type(client).__name__ = "Client"
    type(client).__module__ = "google.genai.client"
    return client


# ---------------------------------------------------------------------------
# TraceContext basics
# ---------------------------------------------------------------------------

class TestTraceContext:
    def test_default_is_none(self):
        assert get_current_trace_context() is None

    def test_set_and_get(self):
        ctx = TraceContext()
        token = set_trace_context(ctx)
        try:
            assert get_current_trace_context() is ctx
        finally:
            set_trace_context(None)
        assert get_current_trace_context() is None

    def test_captures_accumulate(self):
        ctx = TraceContext()
        ctx.calls.append(CapturedLlmCall(provider="openai", model="gpt-4o"))
        ctx.calls.append(CapturedLlmCall(provider="anthropic", model="claude"))
        assert len(ctx.calls) == 2

    def test_prompt_fetches_accumulate(self):
        ctx = TraceContext()
        ctx.prompts.append(CapturedPromptFetch(
            prompt_id="abc", prompt_name="Test", version=1
        ))
        assert len(ctx.prompts) == 1
        assert ctx.prompts[0].source == "prompt_studio"


# ---------------------------------------------------------------------------
# OpenAI adapter
# ---------------------------------------------------------------------------

class TestOpenAIAdapter:
    def test_patch_records_call(self):
        client = _make_openai_client()
        patch_openai_client(client)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            result = client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "Hi"}],
                temperature=0.7,
            )
        finally:
            set_trace_context(None)

        assert len(ctx.calls) == 1
        call = ctx.calls[0]
        assert call.provider == "openai"
        assert call.model == "gpt-4o"
        assert call.prompt_tokens == 100
        assert call.completion_tokens == 50
        assert call.temperature == 0.7
        assert call.latency_ns is not None
        assert call.latency_ns > 0

    def test_no_context_passthrough(self):
        """Without active TraceContext, calls pass through unmodified."""
        client = _make_openai_client()
        original_create = client.chat.completions.create
        patch_openai_client(client)

        # No TraceContext set
        result = client.chat.completions.create(model="gpt-4o", messages=[])
        # Original create was still called
        original_create.assert_called_once()

    def test_capture_content(self):
        client = _make_openai_client()
        patch_openai_client(client, capture_content=True)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": "You are helpful"},
                    {"role": "user", "content": "Hi there"},
                ],
            )
        finally:
            set_trace_context(None)

        call = ctx.calls[0]
        assert call.input_preview is not None
        assert "system" in call.input_preview
        assert call.output_preview == "Hello"

    def test_no_content_by_default(self):
        client = _make_openai_client()
        patch_openai_client(client, capture_content=False)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "secret"}],
            )
        finally:
            set_trace_context(None)

        assert ctx.calls[0].input_preview is None
        assert ctx.calls[0].output_preview is None

    def test_error_captured_and_reraised(self):
        client = _make_openai_client()
        client.chat.completions.create = Mock(side_effect=RuntimeError("API down"))
        patch_openai_client(client)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            with pytest.raises(RuntimeError, match="API down"):
                client.chat.completions.create(model="gpt-4o", messages=[])
        finally:
            set_trace_context(None)

        assert len(ctx.calls) == 1
        assert ctx.calls[0].error_type == "RuntimeError"
        assert ctx.calls[0].error_message == "API down"

    def test_double_patch_is_idempotent(self):
        client = _make_openai_client()
        patch_openai_client(client)
        first_create = client.chat.completions.create
        patch_openai_client(client)
        assert client.chat.completions.create is first_create

    def test_xai_detection(self):
        client = Mock()
        client.base_url = "https://api.x.ai/v1"
        assert _detect_provider(client) == "xai"

    def test_openai_detection(self):
        client = Mock()
        client.base_url = "https://api.openai.com/v1"
        assert _detect_provider(client) == "openai"


class TestAsyncOpenAIAdapter:
    async def test_async_patch_records_call(self):
        client = _make_async_openai_client()
        patch_async_openai_client(client)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            result = await client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "Hi"}],
            )
        finally:
            set_trace_context(None)

        assert len(ctx.calls) == 1
        assert ctx.calls[0].provider == "openai"
        assert ctx.calls[0].prompt_tokens == 100


# ---------------------------------------------------------------------------
# Anthropic adapter
# ---------------------------------------------------------------------------

class TestAnthropicAdapter:
    def test_patch_records_call(self):
        client = _make_anthropic_client()
        patch_anthropic_client(client)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            client.messages.create(
                model="claude-3-5-sonnet",
                messages=[{"role": "user", "content": "Hi"}],
                max_tokens=1024,
            )
        finally:
            set_trace_context(None)

        assert len(ctx.calls) == 1
        call = ctx.calls[0]
        assert call.provider == "anthropic"
        assert call.model == "claude-3-5-sonnet"
        assert call.prompt_tokens == 200
        assert call.completion_tokens == 80

    def test_capture_content_with_system(self):
        client = _make_anthropic_client()
        patch_anthropic_client(client, capture_content=True)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            client.messages.create(
                model="claude-3-5-sonnet",
                messages=[{"role": "user", "content": "Hi"}],
                system="You are an assistant",
                max_tokens=1024,
            )
        finally:
            set_trace_context(None)

        call = ctx.calls[0]
        assert call.input_preview is not None
        assert "system" in call.input_preview
        assert call.output_preview == "Anthropic says hello"


# ---------------------------------------------------------------------------
# Google Gemini adapter
# ---------------------------------------------------------------------------

class TestGoogleAdapter:
    def test_patch_records_call(self):
        model = _make_google_model()
        patch_google_model(model)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            model.generate_content("Explain quantum computing")
        finally:
            set_trace_context(None)

        assert len(ctx.calls) == 1
        call = ctx.calls[0]
        assert call.provider == "google"
        assert call.model == "gemini-1.5-pro"
        assert call.prompt_tokens == 150
        assert call.completion_tokens == 60

    def test_capture_content(self):
        model = _make_google_model()
        patch_google_model(model, capture_content=True)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            model.generate_content("Hello Gemini")
        finally:
            set_trace_context(None)

        call = ctx.calls[0]
        assert call.input_preview == "Hello Gemini"
        assert call.output_preview == "Gemini says hello"


# ---------------------------------------------------------------------------
# Google GenAI adapter (new google-genai SDK)
# ---------------------------------------------------------------------------

class TestGoogleGenAIAdapter:
    def test_patch_records_call(self):
        client = _make_google_genai_client()
        patch_google_genai_client(client)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            client.models.generate_content(model="gemini-2.0-flash", contents="Hello")
        finally:
            set_trace_context(None)

        assert len(ctx.calls) == 1
        call = ctx.calls[0]
        assert call.provider == "google"
        assert call.model == "gemini-2.0-flash"
        assert call.prompt_tokens == 150
        assert call.completion_tokens == 60
        assert call.latency_ns is not None

    def test_capture_content(self):
        client = _make_google_genai_client()
        patch_google_genai_client(client, capture_content=True)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            client.models.generate_content(model="gemini-2.0-flash", contents="Hello GenAI")
        finally:
            set_trace_context(None)

        call = ctx.calls[0]
        assert call.input_preview == "Hello GenAI"
        assert call.output_preview == "Gemini says hello"

    def test_no_capture_outside_context(self):
        client = _make_google_genai_client()
        patch_google_genai_client(client)

        # No trace context active — should pass through without recording
        client.models.generate_content(model="gemini-2.0-flash", contents="Hello")
        # Original was called (via the mock)
        assert client.models.generate_content._infinium_original.call_count == 1

    def test_stream_wrapper(self):
        response = _make_google_response()
        chunk = Mock()
        chunk.text = "streamed"
        chunk.usage_metadata = response.usage_metadata

        client = _make_google_genai_client()
        client.models.generate_content_stream = Mock(return_value=iter([chunk]))
        patch_google_genai_client(client, capture_content=True)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            stream = client.models.generate_content_stream(
                model="gemini-2.0-flash", contents="Stream this"
            )
            chunks = list(stream)
        finally:
            set_trace_context(None)

        assert len(chunks) == 1
        assert len(ctx.calls) == 1
        call = ctx.calls[0]
        assert call.model == "gemini-2.0-flash"
        assert call.prompt_tokens == 150
        assert call.completion_tokens == 60
        assert call.output_preview == "streamed"

    def test_error_capture(self):
        client = _make_google_genai_client()
        client.models.generate_content = Mock(side_effect=RuntimeError("quota exceeded"))
        patch_google_genai_client(client)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            with pytest.raises(RuntimeError, match="quota exceeded"):
                client.models.generate_content(model="gemini-2.0-flash", contents="test")
        finally:
            set_trace_context(None)

        assert len(ctx.calls) == 1
        call = ctx.calls[0]
        assert call.error_type == "RuntimeError"
        assert call.error_message == "quota exceeded"


# ---------------------------------------------------------------------------
# watch() auto-detection
# ---------------------------------------------------------------------------

class TestWatch:
    def test_watch_openai(self):
        client = _make_openai_client()
        result = watch(client)
        assert result is client
        assert getattr(client.chat.completions.create, "_infinium_patched", False)

    def test_watch_anthropic(self):
        client = _make_anthropic_client()
        result = watch(client)
        assert result is client
        assert getattr(client.messages.create, "_infinium_patched", False)

    def test_watch_google(self):
        model = _make_google_model()
        result = watch(model)
        assert result is model
        assert getattr(model.generate_content, "_infinium_patched", False)

    def test_watch_google_genai(self):
        client = _make_google_genai_client()
        result = watch(client)
        assert result is client
        assert getattr(client.models.generate_content, "_infinium_patched", False)

    def test_watch_unknown_warns(self):
        unknown = Mock()
        type(unknown).__name__ = "SomeLLM"
        type(unknown).__module__ = "some_provider"
        with patch("infinium.integrations.logger") as mock_logger:
            watch(unknown)
            mock_logger.warning.assert_called_once()


# ---------------------------------------------------------------------------
# OpenAI streaming
# ---------------------------------------------------------------------------

class TestOpenAIStreaming:
    def test_sync_stream_wrapper(self):
        # Create mock chunks
        def _make_chunk(content=None, usage=None):
            chunk = Mock()
            delta = Mock()
            delta.content = content
            choice = Mock()
            choice.delta = delta
            chunk.choices = [choice]
            chunk.usage = usage
            return chunk

        final_usage = Mock()
        final_usage.prompt_tokens = 50
        final_usage.completion_tokens = 25

        chunks = [
            _make_chunk(content="Hello"),
            _make_chunk(content=" world"),
            _make_chunk(content=None, usage=final_usage),
        ]

        client = _make_openai_client()
        # Override create to return an iterator when stream=True
        client.chat.completions.create = Mock(return_value=iter(chunks))
        patch_openai_client(client, capture_content=True)

        ctx = TraceContext()
        set_trace_context(ctx)
        try:
            stream = client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "Hi"}],
                stream=True,
            )
            collected = list(stream)
        finally:
            set_trace_context(None)

        assert len(collected) == 3
        call = ctx.calls[0]
        assert call.prompt_tokens == 50
        assert call.completion_tokens == 25
        assert call.output_preview == "Hello world"
        assert call.latency_ns is not None


# ---------------------------------------------------------------------------
# TraceBuilder incorporation
# ---------------------------------------------------------------------------

class TestTraceBuilderIncorporation:
    def test_incorporate_captured_calls(self):
        ctx = TraceContext()
        ctx.calls.append(CapturedLlmCall(
            provider="openai",
            model="gpt-4o",
            prompt_tokens=1000,
            completion_tokens=500,
            latency_ns=2_000_000_000,  # 2s
            temperature=0.7,
        ))

        trace = TraceBuilder("Test", "Test trace")
        td = trace.build(_trace_ctx=ctx)

        # Should have the original step + 1 LLM call step
        assert td.steps is not None
        llm_steps = [s for s in td.steps if s.action == "llm_call"]
        assert len(llm_steps) == 1
        assert llm_steps[0].llm_call.model == "gpt-4o"
        assert llm_steps[0].duration_ms == 2000

        # Aggregate LLM usage
        assert td.llm_usage is not None
        assert td.llm_usage.prompt_tokens == 1000
        assert td.llm_usage.completion_tokens == 500
        assert td.llm_usage.total_tokens == 1500
        assert td.llm_usage.api_calls_count == 1

    def test_incorporate_multiple_calls(self):
        ctx = TraceContext()
        ctx.calls.append(CapturedLlmCall(
            provider="openai", model="gpt-4o",
            prompt_tokens=500, completion_tokens=200, latency_ns=1_000_000_000,
        ))
        ctx.calls.append(CapturedLlmCall(
            provider="anthropic", model="claude-3",
            prompt_tokens=300, completion_tokens=100, latency_ns=800_000_000,
        ))

        trace = TraceBuilder("Multi", "Multi provider")
        td = trace.build(_trace_ctx=ctx)

        assert td.llm_usage is not None
        assert td.llm_usage.model == "multiple"
        assert td.llm_usage.provider == "multiple"
        assert td.llm_usage.api_calls_count == 2
        assert td.llm_usage.prompt_tokens == 800
        assert td.llm_usage.completion_tokens == 300

    def test_prompt_studio_section(self):
        ctx = TraceContext()
        ctx.prompts.append(CapturedPromptFetch(
            prompt_id="550e8400-e29b-41d4-a716-446655440000",
            prompt_name="Ticket Classifier",
            version=3,
            variables_used=["ticket"],
            fetched_at="2026-03-17T14:22:00Z",
        ))

        trace = TraceBuilder("Test", "Test trace")
        td = trace.build(_trace_ctx=ctx)

        ps = getattr(td, "_prompt_studio", None)
        assert ps is not None
        assert len(ps["prompts_used"]) == 1
        assert ps["prompts_used"][0]["prompt_id"] == "550e8400-e29b-41d4-a716-446655440000"
        assert ps["prompts_used"][0]["source"] == "prompt_studio"
        assert ps["prompts_used"][0]["version"] == 3

    def test_no_captured_calls_no_side_effects(self):
        """Empty TraceContext should not alter the trace."""
        ctx = TraceContext()
        trace = TraceBuilder("Empty", "Nothing captured")
        td = trace.build(_trace_ctx=ctx)

        assert td.llm_usage is None
        assert td.steps is None
        assert not hasattr(td, "_prompt_studio") or getattr(td, "_prompt_studio", None) is None

    def test_user_llm_usage_not_overwritten(self):
        """If user sets LLM usage explicitly, captured calls don't override."""
        from infinium.types import LlmUsage

        ctx = TraceContext()
        ctx.calls.append(CapturedLlmCall(
            provider="openai", model="gpt-4o",
            prompt_tokens=100, completion_tokens=50, latency_ns=1_000_000_000,
        ))

        trace = TraceBuilder("Test", "Test")
        trace.set_llm_usage(LlmUsage(model="custom", total_tokens=9999))
        td = trace.build(_trace_ctx=ctx)

        assert td.llm_usage.model == "custom"
        assert td.llm_usage.total_tokens == 9999


# ---------------------------------------------------------------------------
# trace_agent decorator with captured calls
# ---------------------------------------------------------------------------

class TestTraceAgentWithCapture:
    def test_decorator_opens_trace_context(self):
        mock_client = Mock()
        mock_client.send_task_data = Mock()

        observed_ctx = None

        @trace_agent("Test", client=mock_client)
        def my_func():
            nonlocal observed_ctx
            observed_ctx = get_current_trace_context()
            return "ok"

        my_func()
        assert observed_ctx is not None
        assert isinstance(observed_ctx, TraceContext)

        # After the decorator finishes, context should be cleared
        assert get_current_trace_context() is None

    def test_decorator_incorporates_captured_calls(self):
        mock_client = Mock()
        mock_client.send_task_data = Mock()

        @trace_agent("Test", client=mock_client)
        def my_func():
            ctx = get_current_trace_context()
            # Simulate what a patched OpenAI client would do
            ctx.calls.append(CapturedLlmCall(
                provider="openai", model="gpt-4o",
                prompt_tokens=100, completion_tokens=50,
                latency_ns=500_000_000,
            ))
            return "result"

        my_func()

        td = mock_client.send_task_data.call_args[0][0]
        assert td.llm_usage is not None
        assert td.llm_usage.prompt_tokens == 100

    def test_decorator_records_prompt_fetch(self):
        mock_client = Mock()
        mock_client.send_task_data = Mock()

        @trace_agent("Test", client=mock_client)
        def my_func():
            ctx = get_current_trace_context()
            ctx.prompts.append(CapturedPromptFetch(
                prompt_id="abc-123",
                prompt_name="Test Prompt",
                version=2,
                variables_used=["name"],
            ))
            return "done"

        my_func()

        td = mock_client.send_task_data.call_args[0][0]
        ps = getattr(td, "_prompt_studio", None)
        assert ps is not None
        assert ps["prompts_used"][0]["prompt_id"] == "abc-123"


class TestAsyncTraceAgentWithCapture:
    async def test_async_decorator_opens_context(self):
        mock_client = AsyncMock()

        observed_ctx = None

        @async_trace_agent("Test", client=mock_client)
        async def my_func():
            nonlocal observed_ctx
            observed_ctx = get_current_trace_context()
            return "ok"

        await my_func()
        assert observed_ctx is not None
        assert isinstance(observed_ctx, TraceContext)
        assert get_current_trace_context() is None


# ---------------------------------------------------------------------------
# Client .trace() convenience method
# ---------------------------------------------------------------------------

class TestClientTraceMethod:
    def test_sync_client_trace_decorator(self):
        from infinium import InfiniumClient

        client = InfiniumClient(
            agent_id="a1b2c3d4-e5f6-7890-abcd-ef1234567890",
            agent_secret="test-secret-456-long-enough",
            enable_rate_limiting=False,
        )

        # Mock send_task_data so we don't make real HTTP calls
        client.send_task_data = Mock()

        @client.trace("Test Op")
        def my_func(x):
            return x * 2

        result = my_func(5)
        assert result == 10
        client.send_task_data.assert_called_once()

    async def test_async_client_trace_decorator(self):
        from infinium import AsyncInfiniumClient

        client = AsyncInfiniumClient(
            agent_id="a1b2c3d4-e5f6-7890-abcd-ef1234567890",
            agent_secret="test-secret-456-long-enough",
            enable_rate_limiting=False,
        )

        client.send_task_data = AsyncMock()

        @client.trace("Test Op")
        async def my_func(x):
            return x * 3

        result = await my_func(4)
        assert result == 12
        client.send_task_data.assert_called_once()


# ---------------------------------------------------------------------------
# Prompt Studio auto-linking in _task_data_to_dict
# ---------------------------------------------------------------------------

class TestPromptStudioSerialization:
    def test_prompt_studio_included_in_dict(self):
        from infinium import InfiniumClient

        client = InfiniumClient(
            agent_id="a1b2c3d4-e5f6-7890-abcd-ef1234567890",
            agent_secret="test-secret-456-long-enough",
            enable_rate_limiting=False,
        )

        td = TaskData(
            name="Test",
            description="Test",
            current_datetime="2026-03-17T12:00:00Z",
            duration=1.0,
        )
        td._prompt_studio = {
            "prompts_used": [{
                "prompt_id": "abc",
                "prompt_name": "Test",
                "version": 1,
                "source": "prompt_studio",
                "variables_used": None,
                "fetched_at": "2026-03-17T12:00:00Z",
            }]
        }

        result = client._task_data_to_dict(td)
        assert "prompt_studio" in result
        assert result["prompt_studio"]["prompts_used"][0]["prompt_id"] == "abc"

    def test_no_prompt_studio_when_absent(self):
        from infinium import InfiniumClient

        client = InfiniumClient(
            agent_id="a1b2c3d4-e5f6-7890-abcd-ef1234567890",
            agent_secret="test-secret-456-long-enough",
            enable_rate_limiting=False,
        )

        td = TaskData(
            name="Test",
            description="Test",
            current_datetime="2026-03-17T12:00:00Z",
            duration=1.0,
        )

        result = client._task_data_to_dict(td)
        assert "prompt_studio" not in result


# ---------------------------------------------------------------------------
# Error in captured call
# ---------------------------------------------------------------------------

class TestNestedTraces:
    def test_nested_trace_restores_parent_context(self):
        """Inner @trace should not destroy the outer trace's context."""
        mock_client = Mock()
        mock_client.send_task_data = Mock()

        parent_ctx_before = None
        parent_ctx_after = None

        @trace_agent("Inner", client=mock_client)
        def inner_func():
            return "inner"

        @trace_agent("Outer", client=mock_client)
        def outer_func():
            nonlocal parent_ctx_before, parent_ctx_after
            parent_ctx_before = get_current_trace_context()
            inner_func()
            parent_ctx_after = get_current_trace_context()
            return "outer"

        outer_func()

        # After inner finishes, outer's context should be restored
        assert parent_ctx_before is not None
        assert parent_ctx_after is not None
        assert parent_ctx_before is parent_ctx_after  # Same context object

        # After everything finishes, context is cleared
        assert get_current_trace_context() is None

        # Both traces sent
        assert mock_client.send_task_data.call_count == 2


class TestAutoDetectSyncAsync:
    async def test_sync_client_trace_on_async_func(self):
        """InfiniumClient.trace() should auto-detect async functions."""
        from infinium import InfiniumClient

        client = InfiniumClient(
            agent_id="a1b2c3d4-e5f6-7890-abcd-ef1234567890",
            agent_secret="test-secret-456-long-enough",
            enable_rate_limiting=False,
        )
        client.send_task_data = AsyncMock()

        @client.trace("Test")
        async def my_async_func(x):
            return x + 1

        result = await my_async_func(5)
        assert result == 6
        client.send_task_data.assert_called_once()

    async def test_async_client_trace_on_sync_func(self):
        """AsyncInfiniumClient.trace() should auto-detect sync functions."""
        from infinium import AsyncInfiniumClient

        client = AsyncInfiniumClient(
            agent_id="a1b2c3d4-e5f6-7890-abcd-ef1234567890",
            agent_secret="test-secret-456-long-enough",
            enable_rate_limiting=False,
        )
        client.send_task_data = Mock()

        @client.trace("Test")
        def my_sync_func(x):
            return x + 1

        result = my_sync_func(5)
        assert result == 6
        client.send_task_data.assert_called_once()


class TestStreamDoubleFinalise:
    def test_stream_exit_after_full_consumption(self):
        """Using stream as context manager after full iteration should not corrupt latency."""
        from infinium.integrations.openai import _StreamWrapper
        from infinium.integrations._context import CapturedLlmCall

        call = CapturedLlmCall(provider="openai", model="gpt-4o")

        chunk = Mock()
        delta = Mock()
        delta.content = "Hi"
        choice = Mock()
        choice.delta = delta
        chunk.choices = [choice]
        chunk.usage = None

        wrapper = _StreamWrapper(iter([chunk]), call, capture_content=True)

        # Consume fully via iteration (triggers _finalise on StopIteration)
        with wrapper as stream:
            collected = list(stream)

        # __exit__ calls _finalise again — should be a no-op
        assert len(collected) == 1
        assert call.latency_ns is not None
        # Latency should be the value from the first _finalise, not overwritten
        first_latency = call.latency_ns
        assert first_latency > 0


class TestCapturedErrors:
    def test_error_becomes_step_error(self):
        ctx = TraceContext()
        ctx.calls.append(CapturedLlmCall(
            provider="openai",
            model="gpt-4o",
            error_type="RateLimitError",
            error_message="Rate limit exceeded",
            latency_ns=100_000_000,
        ))

        trace = TraceBuilder("Error Test", "Test")
        td = trace.build(_trace_ctx=ctx)

        error_steps = [s for s in td.steps if s.error is not None]
        assert len(error_steps) == 1
        assert error_steps[0].error.error_type == "RateLimitError"
