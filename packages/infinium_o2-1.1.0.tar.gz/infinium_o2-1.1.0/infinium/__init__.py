"""
Infinium SDK for Python.

A production-ready SDK for interacting with the Infinium Hosted MCP Bridge API.
"""

from .client import InfiniumClient
from .async_client import AsyncInfiniumClient
from .types import (
    TaskData, ApiResponse, BatchResult,
    TimeTracking, Customer, Support, Sales, Marketing, Content, Research,
    Project, Development, Executive, General, LlmUsage, PromptContent,
    # New trace-enrichment types
    ExecutionStep, ErrorDetail, ToolCall, LlmCall,
    ExpectedOutcome, EnvironmentContext,
)
from .tracing import TraceBuilder, StepContext, trace_agent, async_trace_agent
from .integrations import (
    watch,
    OpenAIInstrumentor,
    AnthropicInstrumentor,
    GoogleInstrumentor,
)
from .exceptions import (
    InfiniumError, AuthenticationError, ValidationError, RateLimitError,
    NetworkError, InfiniumTimeoutError, TimeoutError, ServerError,
    NotFoundError, BatchError, ConfigurationError
)
from .utils import (
    get_current_iso_datetime, validate_iso_datetime,
    validate_duration, validate_path_id,
    validate_string_length, validate_payload_size, coerce_section,
    MAX_NAME_LENGTH, MAX_DESCRIPTION_LENGTH, MAX_STRING_LENGTH, MAX_PAYLOAD_SIZE,
    setup_logging
)

__version__ = "1.1.0"
__author__ = "Infinium"
__email__ = "support@infinium.com"
__description__ = "Python SDK for Infinium Hosted MCP Bridge API"

__all__ = [
    # Main clients
    "InfiniumClient",
    "AsyncInfiniumClient",

    # Types — core
    "TaskData",
    "ApiResponse",
    "BatchResult",
    "PromptContent",

    # Types — sections
    "TimeTracking",
    "Customer",
    "Support",
    "Sales",
    "Marketing",
    "Content",
    "Research",
    "Project",
    "Development",
    "Executive",
    "General",
    "LlmUsage",

    # Types — trace enrichment (new)
    "ExecutionStep",
    "ErrorDetail",
    "ToolCall",
    "LlmCall",
    "ExpectedOutcome",
    "EnvironmentContext",

    # Tracing
    "TraceBuilder",
    "StepContext",
    "trace_agent",
    "async_trace_agent",

    # Integrations
    "watch",
    "OpenAIInstrumentor",
    "AnthropicInstrumentor",
    "GoogleInstrumentor",

    # Exceptions
    "InfiniumError",
    "AuthenticationError",
    "ValidationError",
    "RateLimitError",
    "NetworkError",
    "InfiniumTimeoutError",
    "TimeoutError",
    "ServerError",
    "NotFoundError",
    "BatchError",
    "ConfigurationError",

    # Utilities
    "get_current_iso_datetime",
    "validate_iso_datetime",
    "validate_duration",
    "validate_path_id",
    "validate_string_length",
    "validate_payload_size",
    "coerce_section",
    "MAX_NAME_LENGTH",
    "MAX_DESCRIPTION_LENGTH",
    "MAX_STRING_LENGTH",
    "MAX_PAYLOAD_SIZE",
    "setup_logging",
]
