"""
TraceBuilder, StepContext, and auto-instrumentation decorators.

All data captured is factual and observable — timestamps, token counts,
error types, tool call results. The agent never judges its own work;
Maestro is the sole evaluator.
"""
from __future__ import annotations

import functools
import inspect
import sys
import time
import traceback
import logging
from contextlib import contextmanager
from typing import Any, Callable, Dict, List, Optional, TypeVar

from .types import (
    TaskData, ExecutionStep, ErrorDetail, ToolCall, LlmCall,
    ExpectedOutcome, EnvironmentContext, LlmUsage,
)
from .utils import get_current_iso_datetime, truncate_string
from .integrations._context import (
    TraceContext as _TraceContext,
    _current_trace_ctx,
    get_current_trace_context as _get_ctx,
    set_trace_context as _set_ctx,
)

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])

# Single source of truth: read version from pyproject.toml at import time.
# Falls back to __init__.__version__ or a hardcoded default.
def _get_sdk_version() -> str:
    try:
        from importlib.metadata import version as _pkg_version
        return _pkg_version("infinium-o2")
    except Exception:
        pass
    try:
        from . import __version__ as _v
        return _v
    except Exception:
        return "1.1.0"

__version__ = _get_sdk_version()


# ---------------------------------------------------------------------------
# StepContext — context manager for a single execution step
# ---------------------------------------------------------------------------

class StepContext:
    """Context manager that tracks a single execution step with auto-timing.

    Usage::

        with trace.step("llm_inference", "Summarize findings") as step:
            result = llm.complete(prompt)
            step.set_output(result[:500])
            step.record_llm_call("gpt-4o", prompt_tokens=2000, completion_tokens=500)
    """

    def __init__(self, step_number: int, action: str, description: str):
        self._step_number = step_number
        self._action = action
        self._description = description
        self._start_ns: int = 0
        self._duration_ms: Optional[int] = None
        self._input_preview: Optional[str] = None
        self._output_preview: Optional[str] = None
        self._error: Optional[ErrorDetail] = None
        self._tool_call: Optional[ToolCall] = None
        self._llm_call: Optional[LlmCall] = None
        self._metadata: Optional[Dict[str, Any]] = None

    # -- public helpers --

    def set_input(self, preview: str) -> StepContext:
        self._input_preview = truncate_string(preview, 500)
        return self

    def set_output(self, preview: str) -> StepContext:
        self._output_preview = truncate_string(preview, 500)
        return self

    def record_tool_call(
        self,
        tool_name: str,
        *,
        duration_ms: Optional[int] = None,
        input_summary: Optional[str] = None,
        output_summary: Optional[str] = None,
        http_status: Optional[int] = None,
        error: Optional[ErrorDetail] = None,
    ) -> StepContext:
        self._tool_call = ToolCall(
            tool_name=tool_name,
            duration_ms=duration_ms,
            input_summary=truncate_string(input_summary, 300) if input_summary else None,
            output_summary=truncate_string(output_summary, 300) if output_summary else None,
            http_status=http_status,
            error=error,
        )
        return self

    def record_llm_call(
        self,
        model: str,
        *,
        provider: Optional[str] = None,
        prompt_tokens: Optional[int] = None,
        completion_tokens: Optional[int] = None,
        latency_ms: Optional[int] = None,
        temperature: Optional[float] = None,
        purpose: Optional[str] = None,
    ) -> StepContext:
        self._llm_call = LlmCall(
            model=model,
            provider=provider,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            latency_ms=latency_ms,
            temperature=temperature,
            purpose=purpose,
        )
        return self

    def set_metadata(self, metadata: Dict[str, Any]) -> StepContext:
        self._metadata = metadata
        return self

    # -- context-manager protocol --

    def __enter__(self) -> StepContext:
        self._start_ns = time.perf_counter_ns()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        elapsed_ns = time.perf_counter_ns() - self._start_ns
        self._duration_ms = int(elapsed_ns / 1_000_000)

        if exc_val is not None and self._error is None:
            self._error = ErrorDetail(
                error_type=type(exc_val).__name__,
                message=str(exc_val),
                recoverable=False,
                stack_trace=truncate_string(
                    "".join(traceback.format_exception(type(exc_val), exc_val, exc_tb)),
                    1000,
                ),
            )
        # Don't suppress the exception
        return False

    # -- internal --

    def _build(self) -> ExecutionStep:
        return ExecutionStep(
            step_number=self._step_number,
            action=self._action,
            description=self._description,
            duration_ms=self._duration_ms,
            input_preview=self._input_preview,
            output_preview=self._output_preview,
            error=self._error,
            tool_call=self._tool_call,
            llm_call=self._llm_call,
            metadata=self._metadata,
        )


# ---------------------------------------------------------------------------
# TraceBuilder — accumulates steps, errors, sections; builds TaskData
# ---------------------------------------------------------------------------

class TraceBuilder:
    """Incrementally construct a :class:`TaskData` during agent execution.

    Example::

        trace = TraceBuilder("AAPL Analysis", "Analyze Q4 earnings")
        trace.set_expected_outcome(task_objective="Produce Q4 earnings summary")

        with trace.step("search", "Search SEC EDGAR") as step:
            results = search_edgar("AAPL", "10-Q")
            step.set_output(f"Found {len(results)} filings")
            step.record_tool_call("edgar_api", duration_ms=450)

        trace.set_output_summary("1,400-word analysis covering revenue, margins, guidance")
        task_data = trace.build()
    """

    def __init__(
        self,
        name: str,
        description: str,
    ):
        self._name = name
        self._description = description
        self._start_ns = time.perf_counter_ns()

        self._steps: List[StepContext] = []
        self._errors: List[ErrorDetail] = []
        self._input_summary: Optional[str] = None
        self._output_summary: Optional[str] = None
        self._expected_outcome: Optional[ExpectedOutcome] = None
        self._environment: Optional[EnvironmentContext] = None
        self._llm_usage: Optional[LlmUsage] = None

        # Section dataclass instances (set via set_section)
        self._sections: Dict[str, Any] = {}

    # -- fluent setters --

    def set_input_summary(self, summary: str) -> TraceBuilder:
        self._input_summary = summary
        return self

    def set_output_summary(self, summary: str) -> TraceBuilder:
        self._output_summary = summary
        return self

    def set_expected_outcome(
        self,
        task_objective: str,
        *,
        required_deliverables: Optional[List[str]] = None,
        constraints: Optional[List[str]] = None,
        acceptance_criteria: Optional[List[str]] = None,
    ) -> TraceBuilder:
        self._expected_outcome = ExpectedOutcome(
            task_objective=task_objective,
            required_deliverables=required_deliverables,
            constraints=constraints,
            acceptance_criteria=acceptance_criteria,
        )
        return self

    def set_environment(
        self,
        *,
        framework: Optional[str] = None,
        framework_version: Optional[str] = None,
        python_version: Optional[str] = None,
        runtime: Optional[str] = None,
        region: Optional[str] = None,
        custom_tags: Optional[Dict[str, str]] = None,
    ) -> TraceBuilder:
        self._environment = EnvironmentContext(
            framework=framework,
            framework_version=framework_version,
            python_version=python_version or f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            sdk_version=__version__,
            runtime=runtime,
            region=region,
            custom_tags=custom_tags,
        )
        return self

    def set_llm_usage(self, llm_usage: LlmUsage) -> TraceBuilder:
        self._llm_usage = llm_usage
        return self

    def set_section(self, name: str, value: Any) -> TraceBuilder:
        """Set a domain section (e.g. ``research``, ``customer``)."""
        self._sections[name] = value
        return self

    # -- step creation --

    def step(self, action: str, description: str) -> StepContext:
        """Create a new step context manager.

        Steps are auto-numbered in creation order.
        """
        ctx = StepContext(
            step_number=len(self._steps) + 1,
            action=action,
            description=description,
        )
        self._steps.append(ctx)
        return ctx

    def add_error(self, error: ErrorDetail) -> TraceBuilder:
        self._errors.append(error)
        return self

    # -- captured-call incorporation --

    def _incorporate_captured_calls(self, ctx: _TraceContext) -> None:
        """Merge auto-captured LLM calls and prompt fetches into the trace.

        Called automatically by :func:`trace_agent` / ``@client.trace()``
        when there is an active :class:`TraceContext`.
        """
        # Convert captured LLM calls → ExecutionStep + aggregate LlmUsage
        total_prompt_tokens = 0
        total_completion_tokens = 0
        total_latency_ms = 0
        calls_list: list[LlmCall] = []

        for captured in ctx.calls:
            latency_ms = int(captured.latency_ns / 1_000_000) if captured.latency_ns else None

            llm_call = LlmCall(
                model=captured.model,
                provider=captured.provider,
                prompt_tokens=captured.prompt_tokens,
                completion_tokens=captured.completion_tokens,
                latency_ms=latency_ms,
                temperature=captured.temperature,
            )
            calls_list.append(llm_call)

            # Build a step for each LLM call
            step = StepContext(
                step_number=len(self._steps) + 1,
                action="llm_call",
                description=f"{captured.provider}/{captured.model}",
            )
            step._duration_ms = latency_ms
            step._llm_call = llm_call
            step._input_preview = captured.input_preview
            step._output_preview = captured.output_preview
            if captured.error_type:
                step._error = ErrorDetail(
                    error_type=captured.error_type,
                    message=captured.error_message or "",
                    recoverable=False,
                )
            self._steps.append(step)

            if captured.prompt_tokens:
                total_prompt_tokens += captured.prompt_tokens
            if captured.completion_tokens:
                total_completion_tokens += captured.completion_tokens
            if latency_ms:
                total_latency_ms += latency_ms

        # Set aggregate LLM usage (only if there were calls and user didn't set it)
        if calls_list and self._llm_usage is None:
            model_name = calls_list[0].model if len(calls_list) == 1 else "multiple"
            provider_name = calls_list[0].provider if len(calls_list) == 1 else "multiple"
            self._llm_usage = LlmUsage(
                model=model_name,
                provider=provider_name,
                prompt_tokens=total_prompt_tokens or None,
                completion_tokens=total_completion_tokens or None,
                total_tokens=(total_prompt_tokens + total_completion_tokens) or None,
                api_calls_count=len(calls_list),
                total_latency_ms=total_latency_ms or None,
                calls=calls_list,
            )

    def _build_prompt_studio_section(self, ctx: _TraceContext) -> dict | None:
        """Build the ``prompt_studio`` JSON section from captured prompt fetches."""
        if not ctx.prompts:
            return None
        return {
            "prompts_used": [
                {
                    "prompt_id": pf.prompt_id,
                    "prompt_name": pf.prompt_name,
                    "version": pf.version,
                    "source": pf.source,
                    "variables_used": pf.variables_used,
                    "fetched_at": pf.fetched_at,
                }
                for pf in ctx.prompts
            ]
        }

    # -- build --

    def build(self, _trace_ctx: _TraceContext | None = None) -> TaskData:
        """Build the :class:`TaskData`, auto-computing duration from wall clock.

        Args:
            _trace_ctx: Internal — passed by the ``@trace`` decorator so that
                captured LLM calls and prompt fetches are incorporated.
        """
        # Incorporate auto-captured data if present
        if _trace_ctx is not None:
            self._incorporate_captured_calls(_trace_ctx)

        elapsed_ns = time.perf_counter_ns() - self._start_ns
        duration_seconds = elapsed_ns / 1_000_000_000

        # Auto-populate environment if not explicitly set
        env = self._environment
        if env is None:
            env = EnvironmentContext(
                python_version=f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
                sdk_version=__version__,
            )

        task_data = TaskData(
            name=self._name,
            description=self._description,
            current_datetime=get_current_iso_datetime(),
            duration=round(duration_seconds, 3),
            input_summary=self._input_summary,
            output_summary=self._output_summary,
            expected_outcome=self._expected_outcome,
            environment=env,
            llm_usage=self._llm_usage,
            steps=[s._build() for s in self._steps] if self._steps else None,
            errors=self._errors if self._errors else None,
            **self._sections,
        )

        # Embed prompt_studio section into the TaskData description as metadata
        if _trace_ctx is not None:
            ps_section = self._build_prompt_studio_section(_trace_ctx)
            if ps_section is not None:
                # Store as a hidden attribute for serialisation by _task_data_to_dict
                task_data._prompt_studio = ps_section  # type: ignore[attr-defined]

        return task_data


# ---------------------------------------------------------------------------
# Decorators for auto-instrumentation
# ---------------------------------------------------------------------------

def trace_agent(
    name: str,
    client: Any = None,
    *,
    auto_send: bool = True,
    description: Optional[str] = None,
) -> Callable[[F], F]:
    """Decorator that wraps a sync function in automatic trace instrumentation.

    Captures: duration, input args (truncated), return value (truncated),
    exceptions as :class:`ErrorDetail`. All data is factual — no self-assessment.

    When an active :class:`TraceContext` exists (set up by ``watch()``), captured
    LLM calls and prompt fetches are automatically incorporated into the trace.

    Args:
        name: Trace name.
        client: An :class:`InfiniumClient` instance. Required if ``auto_send=True``.
        auto_send: If ``True``, send the trace on function completion.
        description: Optional description; defaults to the function's docstring.
    """

    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            desc = description or func.__doc__ or f"Auto-traced call to {func.__name__}"
            trace = TraceBuilder(name, desc.strip())
            trace.set_input_summary(
                truncate_string(repr({"args": args, "kwargs": kwargs}), 500)
            )

            # Open a TraceContext so watch()-patched clients record into it
            trace_ctx = _TraceContext()
            token = _set_ctx(trace_ctx)

            result = None
            try:
                with trace.step("execution", f"Execute {func.__name__}") as step:
                    result = func(*args, **kwargs)
                    step.set_output(truncate_string(repr(result), 500))
                return result
            except Exception as exc:
                trace.add_error(ErrorDetail(
                    error_type=type(exc).__name__,
                    message=str(exc),
                    recoverable=False,
                    stack_trace=truncate_string(traceback.format_exc(), 1000),
                ))
                raise
            finally:
                # Reset to previous context (supports nested traces)
                _current_trace_ctx.reset(token)
                if result is not None:
                    trace.set_output_summary(truncate_string(repr(result), 500))
                task_data = trace.build(_trace_ctx=trace_ctx)
                if auto_send and client is not None:
                    try:
                        client.send_task_data(task_data)
                    except Exception:
                        logger.warning("Failed to auto-send trace for %s", name, exc_info=True)

        return wrapper  # type: ignore[return-value]

    return decorator


def async_trace_agent(
    name: str,
    client: Any = None,
    *,
    auto_send: bool = True,
    description: Optional[str] = None,
) -> Callable[[F], F]:
    """Async variant of :func:`trace_agent`.

    Works identically but awaits the decorated coroutine and uses
    ``await client.send_task_data(...)`` for auto-send.
    """

    def decorator(func: F) -> F:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            desc = description or func.__doc__ or f"Auto-traced call to {func.__name__}"
            trace = TraceBuilder(name, desc.strip())
            trace.set_input_summary(
                truncate_string(repr({"args": args, "kwargs": kwargs}), 500)
            )

            # Open a TraceContext so watch()-patched clients record into it
            trace_ctx = _TraceContext()
            token = _set_ctx(trace_ctx)

            result = None
            try:
                with trace.step("execution", f"Execute {func.__name__}") as step:
                    result = await func(*args, **kwargs)
                    step.set_output(truncate_string(repr(result), 500))
                return result
            except Exception as exc:
                trace.add_error(ErrorDetail(
                    error_type=type(exc).__name__,
                    message=str(exc),
                    recoverable=False,
                    stack_trace=truncate_string(traceback.format_exc(), 1000),
                ))
                raise
            finally:
                # Reset to previous context (supports nested traces)
                _current_trace_ctx.reset(token)
                if result is not None:
                    trace.set_output_summary(truncate_string(repr(result), 500))
                task_data = trace.build(_trace_ctx=trace_ctx)
                if auto_send and client is not None:
                    try:
                        await client.send_task_data(task_data)
                    except Exception:
                        logger.warning("Failed to auto-send trace for %s", name, exc_info=True)

        return wrapper  # type: ignore[return-value]

    return decorator
