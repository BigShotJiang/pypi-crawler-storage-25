"""
Type definitions for the Infinium SDK.
"""
from __future__ import annotations
from typing import Any, Dict, List, Optional, Union
from dataclasses import dataclass


# ---------------------------------------------------------------------------
# New dataclasses for rich trace data
# ---------------------------------------------------------------------------

@dataclass
class ErrorDetail:
    """Structured error information — factual, no self-assessment."""
    error_type: str
    message: str
    recoverable: bool = False
    retry_count: int = 0
    stack_trace: Optional[str] = None
    error_code: Optional[str] = None


@dataclass
class ToolCall:
    """Individual tool/function invocation record."""
    tool_name: str
    duration_ms: Optional[int] = None
    input_summary: Optional[str] = None
    output_summary: Optional[str] = None
    error: Optional[ErrorDetail] = None
    http_status: Optional[int] = None


@dataclass
class LlmCall:
    """Individual LLM invocation within a step."""
    model: str
    provider: Optional[str] = None
    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    latency_ms: Optional[int] = None
    temperature: Optional[float] = None
    purpose: Optional[str] = None


@dataclass
class ExecutionStep:
    """Ordered record of what the agent did — factual only."""
    step_number: int
    action: str
    description: str
    duration_ms: Optional[int] = None
    input_preview: Optional[str] = None
    output_preview: Optional[str] = None
    error: Optional[ErrorDetail] = None
    tool_call: Optional[ToolCall] = None
    llm_call: Optional[LlmCall] = None
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class ExpectedOutcome:
    """Factual definition of what the agent was asked to do."""
    task_objective: str
    required_deliverables: Optional[List[str]] = None
    constraints: Optional[List[str]] = None
    acceptance_criteria: Optional[List[str]] = None


@dataclass
class EnvironmentContext:
    """Runtime environment information."""
    framework: Optional[str] = None
    framework_version: Optional[str] = None
    python_version: Optional[str] = None
    sdk_version: Optional[str] = None
    runtime: Optional[str] = None
    region: Optional[str] = None
    custom_tags: Optional[Dict[str, str]] = None


# ---------------------------------------------------------------------------
# Existing section dataclasses (enhanced)
# ---------------------------------------------------------------------------

@dataclass
class TimeTracking:
    """Time tracking information for a task."""
    start_time: Optional[str] = None
    end_time: Optional[str] = None


@dataclass
class Customer:
    """Customer information for a task."""
    customer_name: Optional[str] = None
    customer_email: Optional[str] = None
    customer_phone: Optional[str] = None
    customer_address: Optional[str] = None
    client_company: Optional[str] = None
    client_industry: Optional[str] = None


@dataclass
class Support:
    """Support-specific information for a task."""
    call_id: Optional[str] = None
    issue_description: Optional[str] = None
    issue_type: Optional[str] = None
    resolution: Optional[str] = None
    priority: Optional[str] = None
    follow_up_required: Optional[bool] = None
    agent_notes: Optional[str] = None


@dataclass
class Sales:
    """Sales-specific information for a task."""
    lead_source: Optional[str] = None
    sales_stage: Optional[str] = None
    deal_value: Optional[float] = None
    conversion_rate: Optional[float] = None
    sales_notes: Optional[str] = None


@dataclass
class Marketing:
    """Marketing-specific information for a task."""
    campaign_name: Optional[str] = None
    campaign_type: Optional[str] = None
    target_audience: Optional[str] = None
    marketing_channel: Optional[str] = None
    engagement_metrics: Optional[str] = None
    conversion_metrics: Optional[str] = None


@dataclass
class Content:
    """Content creation information for a task."""
    content_type: Optional[str] = None
    content_format: Optional[str] = None
    content_length: Optional[int] = None
    content_topic: Optional[str] = None
    target_platform: Optional[str] = None


@dataclass
class Research:
    """Research-specific information for a task."""
    research_topic: Optional[str] = None
    research_method: Optional[str] = None
    data_sources: Optional[Union[str, List[str]]] = None
    research_findings: Optional[str] = None
    analysis_type: Optional[str] = None
    sources_consulted: Optional[int] = None
    key_findings: Optional[List[str]] = None
    confidence_level: Optional[str] = None
    data_quality: Optional[str] = None


@dataclass
class Project:
    """Project management information for a task."""
    project_name: Optional[str] = None
    project_phase: Optional[str] = None
    deliverables: Optional[Union[str, List[str]]] = None
    stakeholders: Optional[Union[str, List[str]]] = None
    project_status: Optional[str] = None
    milestone_achieved: Optional[str] = None
    task_priority: Optional[str] = None
    resource_utilization: Optional[float] = None
    risk_assessment: Optional[str] = None
    blockers: Optional[List[str]] = None


@dataclass
class Development:
    """Development-specific information for a task."""
    programming_language: Optional[str] = None
    framework_used: Optional[str] = None
    bugs_found: Optional[int] = None
    bugs_fixed: Optional[int] = None
    test_coverage: Optional[float] = None
    performance_metrics: Optional[Union[str, Dict[str, Any]]] = None
    deployment_status: Optional[str] = None
    technical_debt: Optional[str] = None
    files_modified: Optional[List[str]] = None
    tests_run: Optional[int] = None
    tests_passed: Optional[int] = None


@dataclass
class Executive:
    """Executive assistant information for a task."""
    meeting_type: Optional[str] = None
    attendees_count: Optional[int] = None
    agenda_items: Optional[Union[str, List[str]]] = None
    action_items: Optional[Union[str, List[str]]] = None
    calendar_conflicts: Optional[int] = None
    decisions_made: Optional[List[str]] = None


@dataclass
class General:
    """General task information."""
    tools_used: Optional[Union[str, List[str]]] = None
    agent_notes: Optional[str] = None
    errors_encountered: Optional[List[ErrorDetail]] = None
    retries: Optional[int] = None
    warnings: Optional[List[str]] = None
    external_apis_called: Optional[List[str]] = None
    data_sources_accessed: Optional[List[str]] = None
    tags: Optional[List[str]] = None


# ---------------------------------------------------------------------------
# Non-section dataclasses
# ---------------------------------------------------------------------------

@dataclass
class PromptContent:
    """Content returned from Prompt Studio."""
    prompt_id: str
    name: str
    version: int
    content: str
    created_at: str
    rendered_content: Optional[str] = None


@dataclass
class LlmUsage:
    """LLM token consumption and cost tracking."""
    model: Optional[str] = None
    provider: Optional[str] = None
    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    total_tokens: Optional[int] = None
    estimated_cost_usd: Optional[float] = None
    api_calls_count: Optional[int] = None
    total_latency_ms: Optional[int] = None
    calls: Optional[List[LlmCall]] = None


# ---------------------------------------------------------------------------
# Core task data
# ---------------------------------------------------------------------------

@dataclass
class TaskData:
    """Complete task data structure."""
    name: str
    description: str
    current_datetime: str
    duration: float

    # Optional sections
    time_tracking: Optional[TimeTracking] = None
    customer: Optional[Customer] = None
    support: Optional[Support] = None
    sales: Optional[Sales] = None
    marketing: Optional[Marketing] = None
    content: Optional[Content] = None
    research: Optional[Research] = None
    project: Optional[Project] = None
    development: Optional[Development] = None
    executive: Optional[Executive] = None
    general: Optional[General] = None

    # LLM usage tracking
    llm_usage: Optional[LlmUsage] = None

    # Input/output summaries (factual)
    input_summary: Optional[str] = None
    output_summary: Optional[str] = None

    # New top-level fields (factual, no self-assessment)
    steps: Optional[List[ExecutionStep]] = None
    expected_outcome: Optional[ExpectedOutcome] = None
    environment: Optional[EnvironmentContext] = None
    errors: Optional[List[ErrorDetail]] = None



@dataclass
class ApiResponse:
    """Standard API response structure."""
    success: bool
    status_code: Optional[int] = None
    message: str = ""
    data: Optional[Dict[str, Any]] = None


@dataclass
class BatchResult:
    """Result of a batch operation."""
    successful: int
    failed: int
    results: list[ApiResponse]
    errors: list[str]


# Type aliases for convenience
TaskSections = Dict[str, Union[
    TimeTracking, Customer, Support, Sales, Marketing,
    Content, Research, Project, Development, Executive, General
]]

ConfigDict = Dict[str, Any]
