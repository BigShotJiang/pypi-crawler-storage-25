"""
Asynchronous client for Infinium API.
"""
from __future__ import annotations
import json
import re
import asyncio
import logging
from typing import Any, Dict, List, Optional, Union

import httpx

from .types import (
    TaskData, ApiResponse, BatchResult,
    TimeTracking, Customer, Support, Sales, Marketing, Content, Research,
    Project, Development, Executive, General, PromptContent,
    ExecutionStep, ErrorDetail, ToolCall, LlmCall,
    ExpectedOutcome, EnvironmentContext, LlmUsage
)
from .exceptions import (
    InfiniumError, AuthenticationError, ValidationError, RateLimitError,
    NetworkError, ServerError, NotFoundError, BatchError, InfiniumTimeoutError
)
from .utils import (
    validate_agent_credentials, validate_iso_datetime,
    validate_duration, validate_required_field,
    validate_path_id, validate_string_length, validate_payload_size,
    MAX_NAME_LENGTH, MAX_DESCRIPTION_LENGTH, MAX_STRING_LENGTH,
    get_current_iso_datetime, dataclass_to_dict, retry_with_backoff,
    safe_json_loads, merge_dicts, coerce_section, RateLimiter
)
from .integrations._context import (
    CapturedPromptFetch,
    get_current_trace_context,
)
from .tracing import trace_agent, async_trace_agent


class AsyncInfiniumClient:
    """
    Asynchronous client for Infinium API.
    
    Example:
        ```python
        import asyncio
        from infinium import AsyncInfiniumClient, TaskData

        async def main():
            async with AsyncInfiniumClient(
                agent_id="your-agent-id",
                agent_secret="your-agent-secret"
            ) as client:
                # Send a simple task
                response = await client.send_task(
                    name="Process customer inquiry",
                    description="Handled customer question about pricing",
                    duration=120.5,
                )

                # Send multiple tasks concurrently
                tasks = [
                    TaskData(
                        name=f"Task {i}",
                        description=f"Description {i}",
                        current_datetime=client.get_current_iso_datetime(),
                        duration=float(i * 10),
                    )
                    for i in range(5)
                ]

                batch_result = await client.send_tasks_batch(tasks)
                print(f"Sent {batch_result.successful} tasks successfully")

        asyncio.run(main())
        ```
    """
    
    def __init__(
        self,
        agent_id: str,
        agent_secret: str,
        base_url: str = "https://platform.i42m.ai/api/v1",
        timeout: float = 30.0,
        max_retries: int = 3,
        enable_rate_limiting: bool = True,
        requests_per_second: float = 10.0,
        user_agent: str = "infinium-python/1.0.0",
        enable_logging: bool = False,
        log_level: str = "INFO",
        verify_ssl: bool = True
    ):
        """
        Initialize the async Infinium client.

        Args:
            agent_id: Your agent ID from Infinium
            agent_secret: Your agent secret from Infinium
            base_url: Base URL for the API
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts
            enable_rate_limiting: Whether to enable client-side rate limiting
            requests_per_second: Rate limit for requests per second
            user_agent: User agent string
            enable_logging: Whether to enable SDK logging
            log_level: Log level (DEBUG, INFO, WARNING, ERROR)
            verify_ssl: Whether to verify SSL certificates (set to False for self-signed certs)
        """
        validate_agent_credentials(agent_id, agent_secret)
        
        self.agent_id = agent_id
        self.agent_secret = agent_secret
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.user_agent = user_agent
        self.verify_ssl = verify_ssl

        # Setup logging
        if enable_logging:
            logging.basicConfig(level=getattr(logging, log_level.upper()))
        
        self.logger = logging.getLogger(__name__)
        
        # Rate limiting
        self.rate_limiter = RateLimiter(requests_per_second) if enable_rate_limiting else None
        
        # HTTP client (will be initialized on first use)
        self._client: Optional[httpx.AsyncClient] = None
    
    async def __aenter__(self):
        await self._ensure_client()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
    
    async def _ensure_client(self) -> httpx.AsyncClient:
        """Ensure HTTP client is initialized."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=self.timeout,
                limits=httpx.Limits(max_connections=100, max_keepalive_connections=20),
                verify=self.verify_ssl,
                follow_redirects=False  # Prevent credential leakage on redirects
            )
        return self._client
    
    async def close(self) -> None:
        """Close the HTTP client and cleanup resources."""
        if self._client is not None and not self._client.is_closed:
            try:
                await self._client.aclose()
            except Exception as e:
                self.logger.warning(f"Error closing async HTTP client: {e}")
            finally:
                self._client = None
    
    def _get_headers(self) -> Dict[str, str]:
        """Get request headers."""
        return {
            "User-Agent": self.user_agent,
            "x-agent-id": self.agent_id,
            "x-agent-key": self.agent_secret,
            "Content-Type": "application/json",
        }
    
    def _handle_response(self, response: httpx.Response, *, context: str = "agent") -> ApiResponse:
        """Handle HTTP response and convert to ApiResponse."""
        try:
            data = response.json() if response.content else None
        except json.JSONDecodeError:
            data = None

        # Handle different status codes
        if response.status_code == 401:
            if context == "prompt":
                msg = "Authentication failed. Check your prompt_id and prompt_key."
            else:
                msg = "Authentication failed. Check your agent_id and agent_secret."
            raise AuthenticationError(
                msg,
                status_code=response.status_code,
                details={"response_data": data}
            )
        elif response.status_code == 429:
            try:
                retry_after = int(response.headers.get("Retry-After", "60"))
            except (ValueError, TypeError):
                retry_after = 60
            raise RateLimitError(
                f"Rate limit exceeded. Retry after {retry_after} seconds.",
                retry_after=retry_after,
                details={"response_data": data}
            )
        elif response.status_code == 404:
            raise NotFoundError(
                "Resource not found",
                details={"response_data": data}
            )
        elif 500 <= response.status_code < 600:
            raise ServerError(
                f"Server error: {response.status_code}",
                status_code=response.status_code,
                details={"response_data": data}
            )
        elif not response.is_success:
            error_msg = data.get("error", f"Request failed with status {response.status_code}") if data else f"Request failed with status {response.status_code}"
            raise InfiniumError(
                error_msg,
                status_code=response.status_code,
                details={"response_data": data}
            )
        
        return ApiResponse(
            success=True,
            status_code=response.status_code,
            message=data.get("message", "Success") if data else "Success",
            data=data
        )
    
    async def _make_request(
        self,
        method: str,
        url: str,
        json_data: Optional[Dict[str, Any]] = None,
        max_retries: Optional[int] = None
    ) -> ApiResponse:
        """Make HTTP request with retries."""
        if max_retries is None:
            max_retries = self.max_retries
        
        client = await self._ensure_client()
        
        async def make_single_request():
            # Rate limiting
            if self.rate_limiter:
                await self.rate_limiter.acquire()
            
            response = await client.request(
                method=method,
                url=url,
                headers=self._get_headers(),
                json=json_data
            )
            
            return self._handle_response(response)
        
        # Retry only on transient errors (network/timeout/server).
        # Do NOT retry client errors (auth, validation, not found, rate limit).
        return await retry_with_backoff(
            make_single_request,
            max_retries=max_retries,
            exceptions=(
                httpx.TimeoutException, httpx.ConnectTimeout, httpx.ReadTimeout,
                httpx.NetworkError, httpx.ConnectError, ServerError
            )
        )
    
    async def send_task(
        self,
        name: str,
        description: str,
        duration: Union[int, float],
        current_datetime: Optional[str] = None,
        **kwargs
    ) -> ApiResponse:
        """
        Send a task to the API with simple parameters.

        Args:
            name: Task name
            description: Task description
            duration: Task duration in seconds
            current_datetime: ISO datetime string (auto-generated if not provided)
            **kwargs: Additional task sections (time_tracking, customer, etc.)

        Returns:
            ApiResponse with the result

        Raises:
            ValidationError: If validation fails
            AuthenticationError: If authentication fails
            RateLimitError: If rate limited
            NetworkError: If network request fails
            InfiniumError: For other API errors
        """
        # Validation
        validate_required_field(name, "name")
        validate_required_field(description, "description")

        # String length validation
        validate_string_length(name, "name", MAX_NAME_LENGTH)
        validate_string_length(description, "description", MAX_DESCRIPTION_LENGTH)

        validated_duration = validate_duration(duration)

        if current_datetime is None:
            current_datetime = get_current_iso_datetime()
        elif not validate_iso_datetime(current_datetime):
            raise ValidationError("current_datetime must be a valid ISO 8601 string", field="current_datetime")

        # Build task data
        task_data = TaskData(
            name=name,
            description=description,
            current_datetime=current_datetime,
            duration=validated_duration,
        )
        
        # Add optional sections from kwargs
        for section_name in ['time_tracking', 'customer', 'support', 'sales', 'marketing',
                           'content', 'research', 'project', 'development', 'executive', 'general']:
            if section_name in kwargs:
                setattr(task_data, section_name, kwargs[section_name])

        # Add optional top-level fields from kwargs
        for field_name in ['llm_usage', 'input_summary', 'output_summary',
                           'steps', 'expected_outcome', 'environment', 'errors']:
            if field_name in kwargs:
                setattr(task_data, field_name, kwargs[field_name])

        return await self.send_task_data(task_data)
    
    async def send_task_data(self, task_data: TaskData) -> ApiResponse:
        """
        Send a TaskData object to the API.
        
        Args:
            task_data: TaskData object containing all task information
            
        Returns:
            ApiResponse with the result
            
        Raises:
            ValidationError: If validation fails
            AuthenticationError: If authentication fails
            RateLimitError: If rate limited
            NetworkError: If network request fails
            InfiniumError: For other API errors
        """
        # Convert task data to API format
        payload = self._task_data_to_dict(task_data)

        # Validate path ID and payload size
        safe_agent_id = validate_path_id(self.agent_id, "agent_id")
        validate_payload_size(payload)

        url = f"{self.base_url}/agents/{safe_agent_id}/trace"

        self.logger.info(f"Sending task '{task_data.name}' to {url}")

        response = await self._make_request("POST", url, json_data=payload)

        self.logger.info(f"Task '{task_data.name}' sent successfully")

        return response
    
    async def send_tasks_batch(
        self, 
        tasks: List[TaskData], 
        max_concurrent: int = 5,
        fail_fast: bool = False
    ) -> BatchResult:
        """
        Send multiple tasks concurrently.
        
        Args:
            tasks: List of TaskData objects
            max_concurrent: Maximum number of concurrent requests
            fail_fast: If True, stop on first error
            
        Returns:
            BatchResult with success/failure counts and individual results
            
        Raises:
            ValidationError: If input validation fails
            BatchError: If fail_fast is True and any task fails
        """
        if not tasks:
            raise ValidationError("tasks list cannot be empty")
        
        if max_concurrent < 1:
            raise ValidationError("max_concurrent must be at least 1")
        
        # Use semaphore to limit concurrency
        semaphore = asyncio.Semaphore(max_concurrent)
        results = []
        errors = []
        successful = 0
        failed = 0
        
        async def send_single_task(task: TaskData) -> ApiResponse:
            async with semaphore:
                try:
                    result = await self.send_task_data(task)
                    return result
                except Exception as e:
                    error_msg = f"Task '{task.name}' failed: {str(e)}"
                    self.logger.error(error_msg)

                    if fail_fast:
                        raise BatchError(
                            f"Batch operation failed on task '{task.name}': {str(e)}",
                            successful_count=successful,
                            failed_count=failed,
                            errors=errors + [error_msg]
                        )

                    return ApiResponse(
                        success=False,
                        message=error_msg,
                        data={"task_name": task.name}
                    )

        # Execute all tasks concurrently
        raw_results = await asyncio.gather(
            *[send_single_task(task) for task in tasks],
            return_exceptions=not fail_fast
        )

        # Process all results in a single pass to avoid double-counting
        processed_results = []
        for i, result in enumerate(raw_results):
            if isinstance(result, Exception):
                task_name = tasks[i].name if i < len(tasks) else "unknown"
                error_msg = f"Task '{task_name}' failed: {str(result)}"
                errors.append(error_msg)
                processed_results.append(ApiResponse(
                    success=False,
                    message=error_msg,
                    data={"task_name": task_name}
                ))
                failed += 1
            else:
                processed_results.append(result)
                if result.success:
                    successful += 1
                else:
                    errors.append(result.message)
                    failed += 1
        results = processed_results
        
        return BatchResult(
            successful=successful,
            failed=failed,
            results=results,
            errors=errors
        )
    
    async def get_interpreted_task_result(self, task_id: str) -> ApiResponse:
        """
        Get the AI-interpreted result for a task.
        
        Args:
            task_id: The task ID
            
        Returns:
            ApiResponse with the interpreted result
            
        Raises:
            ValidationError: If task_id is invalid
            AuthenticationError: If authentication fails
            NotFoundError: If task not found
            NetworkError: If network request fails
            InfiniumError: For other API errors
        """
        validate_required_field(task_id, "task_id")
        safe_agent_id = validate_path_id(self.agent_id, "agent_id")
        safe_task_id = validate_path_id(task_id, "task_id")

        url = f"{self.base_url}/agents/{safe_agent_id}/interpreted-result/{safe_task_id}"
        return await self._make_request("GET", url)
    
    async def wait_for_interpretation(
        self,
        trace_id: str,
        timeout: float = 120.0,
        poll_interval: float = 3.0,
    ) -> ApiResponse:
        """
        Poll until Maestro finishes interpreting a trace or timeout is reached.

        Args:
            trace_id: The trace ID returned from ``send_task_data``.
            timeout: Maximum seconds to wait.
            poll_interval: Seconds between polls.

        Returns:
            ApiResponse whose ``data`` contains the interpreted result.

        Raises:
            InfiniumTimeoutError: If the timeout is exceeded before interpretation completes.
            ValidationError: If trace_id is invalid.
        """
        validate_required_field(trace_id, "trace_id")
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout

        while True:
            response = await self.get_interpreted_task_result(trace_id)
            if response.data and response.data.get("interpretedTraceResult"):
                return response

            if loop.time() >= deadline:
                raise InfiniumTimeoutError(
                    f"Interpretation not ready after {timeout}s for trace {trace_id}",
                    timeout_duration=timeout,
                )

            await asyncio.sleep(poll_interval)

    def _task_data_to_dict(self, task_data: TaskData) -> Dict[str, Any]:
        """Convert TaskData to dictionary for API request.

        Fields are serialized in Maestro-priority order so the most valuable
        data survives backend truncation:
        1. name, description, input/output summaries
        2. expected_outcome
        3. steps (execution trace)
        4. errors
        5. llm_usage
        6. sections (domain data)
        7. environment (least critical)
        """
        # 1 — Core identifiers (always present)
        result: Dict[str, Any] = {
            "name": task_data.name,
            "description": task_data.description,
            "current_datetime": task_data.current_datetime,
            "duration": task_data.duration,
        }

        if task_data.input_summary is not None:
            result["input_summary"] = task_data.input_summary
        if task_data.output_summary is not None:
            result["output_summary"] = task_data.output_summary

        # 2 — Expected outcome (tells Maestro what to grade against)
        if task_data.expected_outcome is not None:
            eo = dataclass_to_dict(task_data.expected_outcome)
            if eo:
                result["expected_outcome"] = eo

        # 3 — Execution steps
        if task_data.steps:
            steps_list = [d for s in task_data.steps if (d := dataclass_to_dict(s))]
            if steps_list:
                result["steps"] = steps_list

        # 4 — Top-level errors
        if task_data.errors:
            errors_list = [d for e in task_data.errors if (d := dataclass_to_dict(e))]
            if errors_list:
                result["errors"] = errors_list

        # 5 — LLM usage
        if task_data.llm_usage is not None:
            llm_dict = dataclass_to_dict(task_data.llm_usage)
            if llm_dict:
                result["llm_usage"] = llm_dict

        # 6 — Domain sections
        section_names = [
            'time_tracking', 'customer', 'support', 'sales', 'marketing',
            'content', 'research', 'project', 'development', 'executive', 'general'
        ]

        sections_dict = {}
        for section_name in section_names:
            section_data = getattr(task_data, section_name, None)
            if section_data is not None:
                section_dict = dataclass_to_dict(section_data)
                if section_dict:
                    sections_dict[section_name] = section_dict
        if sections_dict:
            result["sections"] = sections_dict

        # 7 — Environment context (least critical)
        if task_data.environment is not None:
            env = dataclass_to_dict(task_data.environment)
            if env:
                result["environment"] = env

        # 8 — Prompt Studio auto-linking (set by TraceBuilder)
        prompt_studio = getattr(task_data, "_prompt_studio", None)
        if prompt_studio is not None:
            result["prompt_studio"] = prompt_studio

        return result

    async def _make_prompt_request(self, prompt_id: str, prompt_key: str, url: str) -> ApiResponse:
        """Make HTTP GET request to Prompt Studio API using prompt-specific auth headers."""
        client = await self._ensure_client()

        async def make_single_request():
            if self.rate_limiter:
                await self.rate_limiter.acquire()

            response = await client.request(
                method="GET",
                url=url,
                headers={
                    "User-Agent": self.user_agent,
                    "x-prompt-id": prompt_id,
                    "x-prompt-key": prompt_key,
                }
            )

            return self._handle_response(response, context="prompt")

        return await retry_with_backoff(
            make_single_request,
            max_retries=self.max_retries,
            exceptions=(
                httpx.TimeoutException, httpx.ConnectTimeout, httpx.ReadTimeout,
                httpx.NetworkError, httpx.ConnectError, ServerError
            )
        )

    async def get_prompt(
        self,
        prompt_id: str,
        prompt_key: str,
        version: Union[str, int] = "latest",
        variables: Optional[Dict[str, str]] = None,
    ) -> PromptContent:
        """
        Retrieve prompt content from Prompt Studio.

        Args:
            prompt_id: UUID of the prompt (from Prompt Studio UI).
            prompt_key: API key for the prompt (from Prompt Studio → API Keys tab).
            version: Version to retrieve — a positive integer or "latest" (default).
            variables: Optional dict of {{placeholder}} → value substitutions.
                       Unknown placeholders are left unchanged.

        Returns:
            PromptContent with prompt data and optionally rendered_content.

        Raises:
            ValidationError: If prompt_id, prompt_key, or version is invalid.
            NotFoundError: If the prompt or version is not found.
            NetworkError: If network request fails.
            InfiniumError: For other API errors (including wrong key → 403).
        """
        safe_prompt_id = validate_path_id(prompt_id, "prompt_id")

        if not prompt_key or not str(prompt_key).strip():
            raise ValidationError("prompt_key is required", field="prompt_key")
        validate_string_length(prompt_key, "prompt_key", MAX_STRING_LENGTH)

        if isinstance(version, int):
            if version < 1:
                raise ValidationError("version must be a positive integer or 'latest'", field="version")
            version_str = str(version)
        elif isinstance(version, str):
            if version == "latest":
                version_str = "latest"
            else:
                try:
                    v = int(version)
                    if v < 1:
                        raise ValidationError("version must be a positive integer or 'latest'", field="version")
                    version_str = str(v)
                except ValueError:
                    raise ValidationError("version must be a positive integer or 'latest'", field="version")
        else:
            raise ValidationError("version must be a positive integer or 'latest'", field="version")

        url = f"{self.base_url}/prompts/{safe_prompt_id}/v/{version_str}"
        response = await self._make_prompt_request(safe_prompt_id, prompt_key, url)

        if not response.data or not isinstance(response.data, dict):
            raise InfiniumError("Empty or invalid response from prompt API")

        data = response.data
        raw_content = data.get("content")
        content = raw_content if isinstance(raw_content, str) else ""

        rendered_content = None
        if variables is not None:
            rendered_content = re.sub(
                r'\{\{(\w+)\}\}',
                lambda m: variables.get(m.group(1), m.group(0)),
                content
            )

        result = PromptContent(
            prompt_id=data.get("promptId", ""),
            name=data.get("name", ""),
            version=data.get("version", 0),
            content=content,
            created_at=data.get("createdAt", ""),
            rendered_content=rendered_content,
        )

        # Record into active TraceContext for Prompt Studio auto-linking
        ctx = get_current_trace_context()
        if ctx is not None:
            ctx.prompts.append(CapturedPromptFetch(
                prompt_id=result.prompt_id,
                prompt_name=result.name,
                version=result.version,
                source="prompt_studio",
                variables_used=list(variables.keys()) if variables else None,
                fetched_at=get_current_iso_datetime(),
            ))

        return result

    def trace(
        self,
        name: str,
        *,
        auto_send: bool = True,
        description: Optional[str] = None,
    ):
        """Convenience decorator that instruments a function as an Infinium trace.

        Automatically detects whether the decorated function is sync or async
        and uses the appropriate decorator.

        Usage::

            @client.trace("Ticket Classifier")
            async def classify(ticket: str) -> dict:
                resp = await openai.chat.completions.create(...)
                return json.loads(resp.choices[0].message.content)
        """
        sync_dec = trace_agent(
            name, client=self,
            auto_send=auto_send, description=description,
        )
        async_dec = async_trace_agent(
            name, client=self,
            auto_send=auto_send, description=description,
        )

        import inspect as _inspect

        def _pick(func):  # type: ignore[no-untyped-def]
            if _inspect.iscoroutinefunction(func):
                return async_dec(func)
            return sync_dec(func)

        return _pick

    @staticmethod
    def get_current_iso_datetime() -> str:
        """Get current datetime as ISO 8601 string."""
        return get_current_iso_datetime()
    
    @staticmethod
    def create_task_data(
        name: str,
        description: str,
        duration: Union[int, float],
        current_datetime: Optional[str] = None,
        **sections
    ) -> TaskData:
        """
        Create a TaskData object with validation.

        Raw dicts passed as section values are automatically coerced to the
        corresponding dataclass when possible.

        Args:
            name: Task name
            description: Task description
            duration: Task duration
            current_datetime: ISO datetime (auto-generated if not provided)
            **sections: Additional task sections

        Returns:
            TaskData object
        """
        if current_datetime is None:
            current_datetime = get_current_iso_datetime()

        # Coerce dict kwargs to dataclasses where possible
        _section_type_map = {
            'time_tracking': TimeTracking, 'customer': Customer, 'support': Support,
            'sales': Sales, 'marketing': Marketing, 'content': Content,
            'research': Research, 'project': Project, 'development': Development,
            'executive': Executive, 'general': General, 'llm_usage': LlmUsage,
            'expected_outcome': ExpectedOutcome, 'environment': EnvironmentContext,
        }
        coerced = {}
        for k, v in sections.items():
            target_type = _section_type_map.get(k)
            if target_type is not None and isinstance(v, dict):
                coerced[k] = coerce_section(v, target_type)
            else:
                coerced[k] = v

        return TaskData(
            name=name,
            description=description,
            current_datetime=current_datetime,
            duration=validate_duration(duration),
            **coerced
        )
