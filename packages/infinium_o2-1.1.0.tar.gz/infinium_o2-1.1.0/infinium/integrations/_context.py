"""
TraceContext and captured-call dataclasses for LLM auto-instrumentation.

TraceContext is a ``contextvars.ContextVar`` that holds captured LLM calls
and prompt fetches for the current trace scope.  It is async-safe and
thread-safe by design (each task / thread gets its own copy).
"""
from __future__ import annotations

import contextvars
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class CapturedLlmCall:
    """One intercepted LLM API call."""

    provider: str
    model: str
    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    temperature: Optional[float] = None
    latency_ns: Optional[int] = None
    error_type: Optional[str] = None
    error_message: Optional[str] = None
    # Opt-in content capture
    input_preview: Optional[str] = None
    output_preview: Optional[str] = None


@dataclass
class CapturedPromptFetch:
    """One ``get_prompt()`` call recorded inside a trace scope."""

    prompt_id: str
    prompt_name: str
    version: int
    source: str = "prompt_studio"
    variables_used: Optional[List[str]] = None
    fetched_at: Optional[str] = None


@dataclass
class TraceContext:
    """Mutable bag attached to the current ``ContextVar`` token.

    Accumulated by ``watch()`` wrappers and ``get_prompt()``, then consumed
    by :class:`TraceBuilder` when the ``@trace`` decorator finishes.
    """

    calls: List[CapturedLlmCall] = field(default_factory=list)
    prompts: List[CapturedPromptFetch] = field(default_factory=list)


# The single context-var used across the SDK.
_current_trace_ctx: contextvars.ContextVar[Optional[TraceContext]] = contextvars.ContextVar(
    "infinium_trace_ctx", default=None
)


def get_current_trace_context() -> Optional[TraceContext]:
    """Return the active :class:`TraceContext`, or ``None`` outside a trace."""
    return _current_trace_ctx.get()


def set_trace_context(ctx: Optional[TraceContext]) -> contextvars.Token:
    """Set (or clear) the active trace context.  Returns a reset token."""
    return _current_trace_ctx.set(ctx)
