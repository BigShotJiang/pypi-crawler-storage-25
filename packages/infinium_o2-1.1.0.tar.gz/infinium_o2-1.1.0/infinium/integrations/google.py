"""
Google Gemini adapter.

Patches ``generate_content`` (sync and async) on GenerativeModel instances
to record calls into the active :class:`TraceContext`.

Supports both the legacy ``google-generativeai`` package (EOL Nov 2025) and
the new ``google-genai`` package (v1.70.0+).

Legacy: ``watch(GenerativeModel(...))``  — patches model.generate_content
New:    ``watch(genai.Client(...))``     — patches client.models.generate_content
"""
from __future__ import annotations

import time
import logging
from typing import Any, Iterator, AsyncIterator, Optional

from ._context import CapturedLlmCall, get_current_trace_context

logger = logging.getLogger(__name__)

_CONTENT_LIMIT = 500


def _truncate(text: Optional[str], limit: int = _CONTENT_LIMIT) -> Optional[str]:
    if text is None:
        return None
    return text[:limit] + "..." if len(text) > limit else text


def _extract_input(contents: Any, capture_content: bool) -> Optional[str]:
    if not capture_content or not contents:
        return None
    try:
        if isinstance(contents, str):
            return _truncate(contents)
        if isinstance(contents, list):
            parts = []
            for item in contents[-2:]:
                if isinstance(item, str):
                    parts.append(item)
                elif isinstance(item, dict):
                    parts.append(str(item.get("text", item.get("parts", ""))))
                else:
                    parts.append(str(item))
            return _truncate("\n".join(parts))
    except Exception:
        pass
    return None


def _extract_output(response: Any, capture_content: bool) -> Optional[str]:
    if not capture_content:
        return None
    try:
        return _truncate(response.text)
    except (AttributeError, ValueError):
        pass
    return None


def _extract_usage(response: Any, call: CapturedLlmCall) -> None:
    """Extract token usage from Gemini response.usage_metadata."""
    try:
        meta = response.usage_metadata
        call.prompt_tokens = meta.prompt_token_count
        call.completion_tokens = meta.candidates_token_count
    except AttributeError:
        pass


# ---------------------------------------------------------------------------
# Streaming wrappers
# ---------------------------------------------------------------------------

class _StreamWrapper:
    def __init__(self, stream: Iterator, call: CapturedLlmCall, capture_content: bool):
        self._stream = stream
        self._call = call
        self._capture_content = capture_content
        self._chunks: list[str] = []
        self._start_ns = time.perf_counter_ns()
        self._finalised = False

    def __iter__(self):
        return self

    def __next__(self):
        try:
            chunk = next(self._stream)
        except StopIteration:
            self._finalise()
            raise
        self._process_chunk(chunk)
        return chunk

    def _process_chunk(self, chunk: Any) -> None:
        try:
            if hasattr(chunk, "text") and chunk.text:
                self._chunks.append(chunk.text)
        except (AttributeError, ValueError):
            pass
        # Gemini sends cumulative usage on each chunk
        try:
            meta = chunk.usage_metadata
            if meta:
                self._call.prompt_tokens = meta.prompt_token_count
                self._call.completion_tokens = meta.candidates_token_count
        except AttributeError:
            pass

    def _finalise(self) -> None:
        if self._finalised:
            return
        self._finalised = True
        self._call.latency_ns = time.perf_counter_ns() - self._start_ns
        if self._capture_content and self._chunks:
            self._call.output_preview = _truncate("".join(self._chunks))


class _AsyncStreamWrapper:
    def __init__(self, stream: AsyncIterator, call: CapturedLlmCall, capture_content: bool):
        self._stream = stream
        self._call = call
        self._capture_content = capture_content
        self._chunks: list[str] = []
        self._start_ns = time.perf_counter_ns()
        self._finalised = False

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            chunk = await self._stream.__anext__()
        except StopAsyncIteration:
            self._finalise()
            raise
        self._process_chunk(chunk)
        return chunk

    def _process_chunk(self, chunk: Any) -> None:
        try:
            if hasattr(chunk, "text") and chunk.text:
                self._chunks.append(chunk.text)
        except (AttributeError, ValueError):
            pass
        try:
            meta = chunk.usage_metadata
            if meta:
                self._call.prompt_tokens = meta.prompt_token_count
                self._call.completion_tokens = meta.candidates_token_count
        except AttributeError:
            pass

    def _finalise(self) -> None:
        if self._finalised:
            return
        self._finalised = True
        self._call.latency_ns = time.perf_counter_ns() - self._start_ns
        if self._capture_content and self._chunks:
            self._call.output_preview = _truncate("".join(self._chunks))


# ---------------------------------------------------------------------------
# Patching
# ---------------------------------------------------------------------------

def _make_sync_wrapper(original: Any, model_name: str, capture_content: bool) -> Any:
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        ctx = get_current_trace_context()
        if ctx is None:
            return original(*args, **kwargs)

        # First positional arg is typically `contents`
        contents = args[0] if args else kwargs.get("contents")
        is_stream = kwargs.get("stream", False)
        gen_config = kwargs.get("generation_config", {})
        temperature = gen_config.get("temperature") if isinstance(gen_config, dict) else getattr(gen_config, "temperature", None)

        call = CapturedLlmCall(
            provider="google",
            model=model_name,
            temperature=temperature if isinstance(temperature, (int, float)) else None,
            input_preview=_extract_input(contents, capture_content),
        )
        ctx.calls.append(call)

        start = time.perf_counter_ns()
        try:
            response = original(*args, **kwargs)
        except Exception as exc:
            call.latency_ns = time.perf_counter_ns() - start
            call.error_type = type(exc).__name__
            call.error_message = str(exc)
            raise

        if is_stream:
            return _StreamWrapper(response, call, capture_content)

        call.latency_ns = time.perf_counter_ns() - start
        _extract_usage(response, call)
        call.output_preview = _extract_output(response, capture_content)
        return response

    return wrapper


def _make_async_wrapper(original: Any, model_name: str, capture_content: bool) -> Any:
    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        ctx = get_current_trace_context()
        if ctx is None:
            return await original(*args, **kwargs)

        contents = args[0] if args else kwargs.get("contents")
        is_stream = kwargs.get("stream", False)
        gen_config = kwargs.get("generation_config", {})
        temperature = gen_config.get("temperature") if isinstance(gen_config, dict) else getattr(gen_config, "temperature", None)

        call = CapturedLlmCall(
            provider="google",
            model=model_name,
            temperature=temperature if isinstance(temperature, (int, float)) else None,
            input_preview=_extract_input(contents, capture_content),
        )
        ctx.calls.append(call)

        start = time.perf_counter_ns()
        try:
            response = await original(*args, **kwargs)
        except Exception as exc:
            call.latency_ns = time.perf_counter_ns() - start
            call.error_type = type(exc).__name__
            call.error_message = str(exc)
            raise

        if is_stream:
            return _AsyncStreamWrapper(response, call, capture_content)

        call.latency_ns = time.perf_counter_ns() - start
        _extract_usage(response, call)
        call.output_preview = _extract_output(response, capture_content)
        return response

    return wrapper


def patch_google_model(model: Any, capture_content: bool = False) -> Any:
    """Monkey-patch a single GenerativeModel instance."""
    model_name = getattr(model, "model_name", "unknown")

    if hasattr(model, "generate_content"):
        original = model.generate_content
        if not getattr(original, "_infinium_patched", None) is True:
            wrapped = _make_sync_wrapper(original, model_name, capture_content)
            wrapped._infinium_patched = True  # type: ignore[attr-defined]
            wrapped._infinium_original = original  # type: ignore[attr-defined]
            model.generate_content = wrapped

    if hasattr(model, "generate_content_async"):
        original_async = model.generate_content_async
        if not getattr(original_async, "_infinium_patched", None) is True:
            wrapped_async = _make_async_wrapper(original_async, model_name, capture_content)
            wrapped_async._infinium_patched = True  # type: ignore[attr-defined]
            wrapped_async._infinium_original = original_async  # type: ignore[attr-defined]
            model.generate_content_async = wrapped_async

    return model


class GoogleInstrumentor:
    """Global instrumentor for Google Gemini at the class level."""

    _original_sync = None
    _original_async = None

    def __init__(self, capture_content: bool = False):
        self.capture_content = capture_content

    def instrument(self) -> None:
        try:
            from google.generativeai import GenerativeModel  # type: ignore[import-untyped]
        except ImportError:
            logger.warning("google-generativeai not installed; GoogleInstrumentor is a no-op")
            return

        if GoogleInstrumentor._original_sync is None:
            GoogleInstrumentor._original_sync = GenerativeModel.generate_content

        wrapped = _make_sync_wrapper(
            GoogleInstrumentor._original_sync, "gemini", self.capture_content
        )
        wrapped._infinium_patched = True  # type: ignore[attr-defined]
        GenerativeModel.generate_content = wrapped

        if hasattr(GenerativeModel, "generate_content_async"):
            if GoogleInstrumentor._original_async is None:
                GoogleInstrumentor._original_async = GenerativeModel.generate_content_async
            wrapped_async = _make_async_wrapper(
                GoogleInstrumentor._original_async, "gemini", self.capture_content
            )
            wrapped_async._infinium_patched = True  # type: ignore[attr-defined]
            GenerativeModel.generate_content_async = wrapped_async

    def uninstrument(self) -> None:
        try:
            from google.generativeai import GenerativeModel  # type: ignore[import-untyped]
        except ImportError:
            return

        if GoogleInstrumentor._original_sync is not None:
            GenerativeModel.generate_content = GoogleInstrumentor._original_sync
            GoogleInstrumentor._original_sync = None

        if GoogleInstrumentor._original_async is not None:
            GenerativeModel.generate_content_async = GoogleInstrumentor._original_async
            GoogleInstrumentor._original_async = None


# ---------------------------------------------------------------------------
# New google-genai SDK (v1.70.0+)
#
# API surface:  client.models.generate_content(model=..., contents=...)
#               client.models.generate_content_stream(model=..., contents=...)
# Async:        client.aio.models.generate_content(...)
#               client.aio.models.generate_content_stream(...)
# Response:     response.text, response.usage_metadata.prompt_token_count,
#               response.usage_metadata.candidates_token_count
# ---------------------------------------------------------------------------


def _extract_genai_model_name(args: tuple, kwargs: dict) -> str:
    """Extract model name from google-genai call arguments."""
    if "model" in kwargs:
        return str(kwargs["model"])
    if args:
        return str(args[0])
    return "unknown"


def _extract_genai_contents(args: tuple, kwargs: dict) -> Any:
    """Extract contents from google-genai call arguments."""
    if "contents" in kwargs:
        return kwargs["contents"]
    if len(args) >= 2:
        return args[1]
    return None


def _extract_genai_config(kwargs: dict) -> Optional[float]:
    """Extract temperature from google-genai config argument."""
    config = kwargs.get("config")
    if config is None:
        return None
    if isinstance(config, dict):
        return config.get("temperature")
    return getattr(config, "temperature", None)


def _make_genai_sync_wrapper(original: Any, capture_content: bool) -> Any:
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        ctx = get_current_trace_context()
        if ctx is None:
            return original(*args, **kwargs)

        model_name = _extract_genai_model_name(args, kwargs)
        contents = _extract_genai_contents(args, kwargs)
        temperature = _extract_genai_config(kwargs)

        call = CapturedLlmCall(
            provider="google",
            model=model_name,
            temperature=temperature if isinstance(temperature, (int, float)) else None,
            input_preview=_extract_input(contents, capture_content),
        )
        ctx.calls.append(call)

        start = time.perf_counter_ns()
        try:
            response = original(*args, **kwargs)
        except Exception as exc:
            call.latency_ns = time.perf_counter_ns() - start
            call.error_type = type(exc).__name__
            call.error_message = str(exc)
            raise

        call.latency_ns = time.perf_counter_ns() - start
        _extract_usage(response, call)
        call.output_preview = _extract_output(response, capture_content)
        return response

    return wrapper


def _make_genai_async_wrapper(original: Any, capture_content: bool) -> Any:
    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        ctx = get_current_trace_context()
        if ctx is None:
            return await original(*args, **kwargs)

        model_name = _extract_genai_model_name(args, kwargs)
        contents = _extract_genai_contents(args, kwargs)
        temperature = _extract_genai_config(kwargs)

        call = CapturedLlmCall(
            provider="google",
            model=model_name,
            temperature=temperature if isinstance(temperature, (int, float)) else None,
            input_preview=_extract_input(contents, capture_content),
        )
        ctx.calls.append(call)

        start = time.perf_counter_ns()
        try:
            response = await original(*args, **kwargs)
        except Exception as exc:
            call.latency_ns = time.perf_counter_ns() - start
            call.error_type = type(exc).__name__
            call.error_message = str(exc)
            raise

        call.latency_ns = time.perf_counter_ns() - start
        _extract_usage(response, call)
        call.output_preview = _extract_output(response, capture_content)
        return response

    return wrapper


def _make_genai_stream_sync_wrapper(original: Any, capture_content: bool) -> Any:
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        ctx = get_current_trace_context()
        if ctx is None:
            return original(*args, **kwargs)

        model_name = _extract_genai_model_name(args, kwargs)
        contents = _extract_genai_contents(args, kwargs)
        temperature = _extract_genai_config(kwargs)

        call = CapturedLlmCall(
            provider="google",
            model=model_name,
            temperature=temperature if isinstance(temperature, (int, float)) else None,
            input_preview=_extract_input(contents, capture_content),
        )
        ctx.calls.append(call)

        response = original(*args, **kwargs)
        return _StreamWrapper(response, call, capture_content)

    return wrapper


def _make_genai_stream_async_wrapper(original: Any, capture_content: bool) -> Any:
    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        ctx = get_current_trace_context()
        if ctx is None:
            return await original(*args, **kwargs)

        model_name = _extract_genai_model_name(args, kwargs)
        contents = _extract_genai_contents(args, kwargs)
        temperature = _extract_genai_config(kwargs)

        call = CapturedLlmCall(
            provider="google",
            model=model_name,
            temperature=temperature if isinstance(temperature, (int, float)) else None,
            input_preview=_extract_input(contents, capture_content),
        )
        ctx.calls.append(call)

        response = await original(*args, **kwargs)
        return _AsyncStreamWrapper(response, call, capture_content)

    return wrapper


def _patch_models_obj(models: Any, capture_content: bool, is_async: bool = False) -> None:
    """Patch generate_content and generate_content_stream on a models sub-object."""
    if hasattr(models, "generate_content"):
        original = models.generate_content
        if not getattr(original, "_infinium_patched", None) is True:
            make_wrapper = _make_genai_async_wrapper if is_async else _make_genai_sync_wrapper
            wrapped = make_wrapper(original, capture_content)
            wrapped._infinium_patched = True  # type: ignore[attr-defined]
            wrapped._infinium_original = original  # type: ignore[attr-defined]
            models.generate_content = wrapped

    if hasattr(models, "generate_content_stream"):
        original_stream = models.generate_content_stream
        if not getattr(original_stream, "_infinium_patched", None) is True:
            make_stream_wrapper = _make_genai_stream_async_wrapper if is_async else _make_genai_stream_sync_wrapper
            wrapped_stream = make_stream_wrapper(original_stream, capture_content)
            wrapped_stream._infinium_patched = True  # type: ignore[attr-defined]
            wrapped_stream._infinium_original = original_stream  # type: ignore[attr-defined]
            models.generate_content_stream = wrapped_stream


def patch_google_genai_client(client: Any, capture_content: bool = False) -> Any:
    """Monkey-patch a google-genai Client instance (v1.70.0+).

    Patches ``client.models.generate_content`` and
    ``client.models.generate_content_stream`` for sync usage,
    and the equivalents on ``client.aio.models`` for async usage.
    """
    if hasattr(client, "models"):
        _patch_models_obj(client.models, capture_content, is_async=False)

    # Async sub-client: client.aio.models
    aio = getattr(client, "aio", None)
    if aio is not None and hasattr(aio, "models"):
        _patch_models_obj(aio.models, capture_content, is_async=True)

    return client
