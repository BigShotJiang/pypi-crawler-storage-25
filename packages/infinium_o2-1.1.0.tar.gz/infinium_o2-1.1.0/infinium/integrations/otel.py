"""
Optional OpenTelemetry span exporter for Infinium traces.

Only active when ``opentelemetry-api`` is installed.  Users opt in by
creating an :class:`InfiniumOTelExporter` and passing it to the client
or decorator.

This is a lightweight bridge — Infinium uses ``contextvars`` internally,
not OTel context propagation.  The exporter simply emits a span per trace
(with child spans per LLM call) so teams that already have OTel collectors
get visibility alongside their existing telemetry.
"""
from __future__ import annotations

import logging
from typing import Any, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ._context import TraceContext

logger = logging.getLogger(__name__)

_HAS_OTEL = False
try:
    from opentelemetry import trace as otel_trace  # type: ignore[import-untyped]
    from opentelemetry.trace import StatusCode  # type: ignore[import-untyped]

    _HAS_OTEL = True
except ImportError:
    pass


class InfiniumOTelExporter:
    """Emit OTel spans for Infinium traces.

    Usage::

        from infinium.integrations.otel import InfiniumOTelExporter

        exporter = InfiniumOTelExporter(service_name="my-agent")
        # Pass to @client.trace(..., otel_exporter=exporter)
    """

    def __init__(self, service_name: str = "infinium-agent", tracer_name: str = "infinium"):
        self.service_name = service_name
        self.tracer_name = tracer_name
        self._tracer: Any = None

        if not _HAS_OTEL:
            logger.warning(
                "opentelemetry-api not installed; InfiniumOTelExporter will not emit spans. "
                "Install with: pip install opentelemetry-api opentelemetry-sdk"
            )

    def _get_tracer(self) -> Any:
        if self._tracer is None and _HAS_OTEL:
            self._tracer = otel_trace.get_tracer(self.tracer_name)
        return self._tracer

    def export_trace(
        self,
        trace_name: str,
        duration_s: float,
        ctx: Optional[TraceContext] = None,
    ) -> None:
        """Create an OTel span for the trace, with child spans per LLM call."""
        tracer = self._get_tracer()
        if tracer is None:
            return

        with tracer.start_as_current_span(trace_name) as root_span:
            root_span.set_attribute("infinium.service", self.service_name)
            root_span.set_attribute("infinium.duration_s", duration_s)

            if ctx is None:
                return

            root_span.set_attribute("infinium.llm_call_count", len(ctx.calls))
            root_span.set_attribute("infinium.prompt_fetch_count", len(ctx.prompts))

            total_prompt_tokens = 0
            total_completion_tokens = 0

            for i, call in enumerate(ctx.calls):
                with tracer.start_as_current_span(f"llm.{call.provider}.{i}") as call_span:
                    call_span.set_attribute("llm.provider", call.provider)
                    call_span.set_attribute("llm.model", call.model)
                    if call.prompt_tokens is not None:
                        call_span.set_attribute("llm.prompt_tokens", call.prompt_tokens)
                        total_prompt_tokens += call.prompt_tokens
                    if call.completion_tokens is not None:
                        call_span.set_attribute("llm.completion_tokens", call.completion_tokens)
                        total_completion_tokens += call.completion_tokens
                    if call.temperature is not None:
                        call_span.set_attribute("llm.temperature", call.temperature)
                    if call.latency_ns is not None:
                        call_span.set_attribute("llm.latency_ms", call.latency_ns / 1_000_000)
                    if call.error_type:
                        call_span.set_status(StatusCode.ERROR, call.error_message or "")
                        call_span.set_attribute("error.type", call.error_type)

            root_span.set_attribute("llm.total_prompt_tokens", total_prompt_tokens)
            root_span.set_attribute("llm.total_completion_tokens", total_completion_tokens)

            for pf in ctx.prompts:
                root_span.add_event(
                    "prompt_studio.fetch",
                    attributes={
                        "prompt.id": pf.prompt_id,
                        "prompt.name": pf.prompt_name,
                        "prompt.version": pf.version,
                    },
                )
