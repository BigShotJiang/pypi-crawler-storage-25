"""
Zero-boilerplate LLM integrations for Infinium.

Usage::

    from infinium.integrations import watch

    openai_client = watch(OpenAI(api_key="..."), capture_content=True)

Or use global instrumentors::

    from infinium.integrations import OpenAIInstrumentor
    OpenAIInstrumentor(capture_content=True).instrument()
"""
from __future__ import annotations

import logging
from typing import Any, TypeVar

from ._context import (
    TraceContext,
    CapturedLlmCall,
    CapturedPromptFetch,
    get_current_trace_context,
    set_trace_context,
)
from .openai import (
    patch_openai_client,
    patch_async_openai_client,
    OpenAIInstrumentor,
)
from .anthropic import (
    patch_anthropic_client,
    patch_async_anthropic_client,
    AnthropicInstrumentor,
)
from .google import (
    patch_google_model,
    patch_google_genai_client,
    GoogleInstrumentor,
)

logger = logging.getLogger(__name__)

T = TypeVar("T")


def _is_openai(client: Any) -> bool:
    cls_name = type(client).__name__
    mod = type(client).__module__ or ""
    return cls_name in ("OpenAI",) and "openai" in mod


def _is_async_openai(client: Any) -> bool:
    cls_name = type(client).__name__
    mod = type(client).__module__ or ""
    return cls_name in ("AsyncOpenAI",) and "openai" in mod


def _is_xai(client: Any) -> bool:
    """xAI/Grok uses the openai library with a custom base_url."""
    try:
        base = str(getattr(client, "base_url", ""))
        if "x.ai" in base or "grok" in base or "xai" in base:
            return True
    except Exception:
        pass
    return False


def _is_anthropic(client: Any) -> bool:
    cls_name = type(client).__name__
    mod = type(client).__module__ or ""
    return cls_name == "Anthropic" and "anthropic" in mod


def _is_async_anthropic(client: Any) -> bool:
    cls_name = type(client).__name__
    mod = type(client).__module__ or ""
    return cls_name == "AsyncAnthropic" and "anthropic" in mod


def _is_google_genai_client(client: Any) -> bool:
    """Detect a google-genai Client (v1.70.0+)."""
    cls_name = type(client).__name__
    mod = type(client).__module__ or ""
    return cls_name == "Client" and "google" in mod and "genai" in mod


def _is_google_model(client: Any) -> bool:
    """Detect a legacy google-generativeai GenerativeModel."""
    cls_name = type(client).__name__
    mod = type(client).__module__ or ""
    return cls_name == "GenerativeModel" and "google" in mod


def watch(client: T, capture_content: bool = False) -> T:
    """Auto-detect the LLM provider and monkey-patch a single client instance.

    Supported clients:
    - ``openai.OpenAI`` / ``openai.AsyncOpenAI`` (including xAI/Grok)
    - ``anthropic.Anthropic`` / ``anthropic.AsyncAnthropic``
    - ``google.generativeai.GenerativeModel`` (legacy)
    - ``google.genai.Client`` (new SDK, v1.70.0+)

    Returns the same client object for chaining::

        openai = watch(OpenAI(api_key="..."), capture_content=True)

    Args:
        client: An LLM provider client instance.
        capture_content: If ``True``, capture input/output previews (truncated
            to 500 chars).  Default ``False`` to protect sensitive data.
    """
    if _is_async_openai(client) or (_is_xai(client) and "Async" in type(client).__name__):
        patch_async_openai_client(client, capture_content)
    elif _is_openai(client) or _is_xai(client):
        patch_openai_client(client, capture_content)
    elif _is_async_anthropic(client):
        patch_async_anthropic_client(client, capture_content)
    elif _is_anthropic(client):
        patch_anthropic_client(client, capture_content)
    elif _is_google_genai_client(client):
        patch_google_genai_client(client, capture_content)
    elif _is_google_model(client):
        patch_google_model(client, capture_content)
    else:
        logger.warning(
            "watch(): unrecognised client type %s.%s — no instrumentation applied",
            type(client).__module__,
            type(client).__name__,
        )

    return client


__all__ = [
    # Core
    "watch",
    "TraceContext",
    "CapturedLlmCall",
    "CapturedPromptFetch",
    "get_current_trace_context",
    "set_trace_context",
    # Instrumentors
    "OpenAIInstrumentor",
    "AnthropicInstrumentor",
    "GoogleInstrumentor",
    "patch_google_genai_client",
]
