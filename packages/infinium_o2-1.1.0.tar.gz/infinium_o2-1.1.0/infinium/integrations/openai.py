"""
OpenAI / xAI (Grok) adapter.

Patches ``chat.completions.create`` (sync and async) to record every call
into the active :class:`TraceContext`.  Streaming is handled transparently
by wrapping the chunk iterator.
"""
from __future__ import annotations

import time
import logging
from typing import Any, Iterator, AsyncIterator, Optional

from ._context import CapturedLlmCall, get_current_trace_context

logger = logging.getLogger(__name__)

_CONTENT_LIMIT = 500


def _truncate(text: Optional[str], limit: int = _CONTENT_LIMIT) -> Optional[str]:
    if text is None:
        return None
    return text[:limit] + "..." if len(text) > limit else text


def _detect_provider(client: Any) -> str:
    """Detect whether the client is OpenAI or xAI based on base_url."""
    try:
        base = str(getattr(client, "base_url", ""))
        if "x.ai" in base or "grok" in base or "xai" in base:
            return "xai"
    except Exception:
        pass
    return "openai"


def _extract_content_from_messages(messages: Any, capture_content: bool) -> Optional[str]:
    """Extract input preview from messages list."""
    if not capture_content or not messages:
        return None
    parts = []
    for msg in messages:
        if isinstance(msg, dict):
            role = msg.get("role", "")
            content = msg.get("content", "")
            if role in ("system", "user"):
                parts.append(f"[{role}] {content}")
    return _truncate("\n".join(parts[-2:])) if parts else None


def _extract_output(response: Any, capture_content: bool) -> Optional[str]:
    """Extract output preview from a non-streaming response."""
    if not capture_content:
        return None
    try:
        return _truncate(response.choices[0].message.content)
    except (AttributeError, IndexError):
        return None


# ---------------------------------------------------------------------------
# Streaming wrappers
# ---------------------------------------------------------------------------

class _StreamWrapper:
    """Wraps a sync OpenAI streaming iterator to accumulate usage/content."""

    def __init__(self, stream: Iterator, call: CapturedLlmCall, capture_content: bool):
        self._stream = stream
        self._call = call
        self._capture_content = capture_content
        self._chunks: list[str] = []
        self._start_ns = time.perf_counter_ns()
        self._finalised = False

    def __iter__(self):
        return self

    def __next__(self):
        try:
            chunk = next(self._stream)
        except StopIteration:
            self._finalise()
            raise
        self._process_chunk(chunk)
        return chunk

    def __enter__(self):
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args):
        self._finalise()
        if hasattr(self._stream, "__exit__"):
            return self._stream.__exit__(*args)
        return False

    def _process_chunk(self, chunk: Any) -> None:
        # Accumulate content
        try:
            delta = chunk.choices[0].delta
            if hasattr(delta, "content") and delta.content:
                self._chunks.append(delta.content)
        except (AttributeError, IndexError):
            pass
        # Extract usage from final chunk
        if hasattr(chunk, "usage") and chunk.usage is not None:
            try:
                self._call.prompt_tokens = chunk.usage.prompt_tokens
                self._call.completion_tokens = chunk.usage.completion_tokens
            except AttributeError:
                pass

    def _finalise(self) -> None:
        if self._finalised:
            return
        self._finalised = True
        self._call.latency_ns = time.perf_counter_ns() - self._start_ns
        if self._capture_content and self._chunks:
            self._call.output_preview = _truncate("".join(self._chunks))


class _AsyncStreamWrapper:
    """Wraps an async OpenAI streaming iterator."""

    def __init__(self, stream: AsyncIterator, call: CapturedLlmCall, capture_content: bool):
        self._stream = stream
        self._call = call
        self._capture_content = capture_content
        self._chunks: list[str] = []
        self._start_ns = time.perf_counter_ns()
        self._finalised = False

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            chunk = await self._stream.__anext__()
        except StopAsyncIteration:
            self._finalise()
            raise
        self._process_chunk(chunk)
        return chunk

    async def __aenter__(self):
        if hasattr(self._stream, "__aenter__"):
            await self._stream.__aenter__()
        return self

    async def __aexit__(self, *args):
        self._finalise()
        if hasattr(self._stream, "__aexit__"):
            return await self._stream.__aexit__(*args)
        return False

    def _process_chunk(self, chunk: Any) -> None:
        try:
            delta = chunk.choices[0].delta
            if hasattr(delta, "content") and delta.content:
                self._chunks.append(delta.content)
        except (AttributeError, IndexError):
            pass
        if hasattr(chunk, "usage") and chunk.usage is not None:
            try:
                self._call.prompt_tokens = chunk.usage.prompt_tokens
                self._call.completion_tokens = chunk.usage.completion_tokens
            except AttributeError:
                pass

    def _finalise(self) -> None:
        if self._finalised:
            return
        self._finalised = True
        self._call.latency_ns = time.perf_counter_ns() - self._start_ns
        if self._capture_content and self._chunks:
            self._call.output_preview = _truncate("".join(self._chunks))


# ---------------------------------------------------------------------------
# Patching helpers
# ---------------------------------------------------------------------------

def _make_sync_wrapper(original_create: Any, provider: str, capture_content: bool) -> Any:
    """Return a replacement for ``chat.completions.create`` (sync)."""

    def wrapper(*args: Any, **kwargs: Any) -> Any:
        ctx = get_current_trace_context()
        if ctx is None:
            return original_create(*args, **kwargs)

        model = kwargs.get("model", "unknown")
        temperature = kwargs.get("temperature")
        messages = kwargs.get("messages")
        is_stream = kwargs.get("stream", False)

        call = CapturedLlmCall(
            provider=provider,
            model=model,
            temperature=temperature,
            input_preview=_extract_content_from_messages(messages, capture_content),
        )
        ctx.calls.append(call)

        start = time.perf_counter_ns()
        try:
            response = original_create(*args, **kwargs)
        except Exception as exc:
            call.latency_ns = time.perf_counter_ns() - start
            call.error_type = type(exc).__name__
            call.error_message = str(exc)
            raise

        if is_stream:
            return _StreamWrapper(response, call, capture_content)

        # Non-streaming
        call.latency_ns = time.perf_counter_ns() - start
        try:
            call.model = response.model or model
            if response.usage:
                call.prompt_tokens = response.usage.prompt_tokens
                call.completion_tokens = response.usage.completion_tokens
        except AttributeError:
            pass
        call.output_preview = _extract_output(response, capture_content)
        return response

    return wrapper


def _make_async_wrapper(original_create: Any, provider: str, capture_content: bool) -> Any:
    """Return a replacement for ``chat.completions.create`` (async)."""

    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        ctx = get_current_trace_context()
        if ctx is None:
            return await original_create(*args, **kwargs)

        model = kwargs.get("model", "unknown")
        temperature = kwargs.get("temperature")
        messages = kwargs.get("messages")
        is_stream = kwargs.get("stream", False)

        call = CapturedLlmCall(
            provider=provider,
            model=model,
            temperature=temperature,
            input_preview=_extract_content_from_messages(messages, capture_content),
        )
        ctx.calls.append(call)

        start = time.perf_counter_ns()
        try:
            response = await original_create(*args, **kwargs)
        except Exception as exc:
            call.latency_ns = time.perf_counter_ns() - start
            call.error_type = type(exc).__name__
            call.error_message = str(exc)
            raise

        if is_stream:
            return _AsyncStreamWrapper(response, call, capture_content)

        call.latency_ns = time.perf_counter_ns() - start
        try:
            call.model = response.model or model
            if response.usage:
                call.prompt_tokens = response.usage.prompt_tokens
                call.completion_tokens = response.usage.completion_tokens
        except AttributeError:
            pass
        call.output_preview = _extract_output(response, capture_content)
        return response

    return wrapper


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def patch_openai_client(client: Any, capture_content: bool = False) -> Any:
    """Monkey-patch a single OpenAI client instance.

    Returns the same client for chaining.
    """
    provider = _detect_provider(client)

    # Sync: client.chat.completions.create
    completions = getattr(getattr(client, "chat", None), "completions", None)
    if completions is not None:
        original = completions.create
        if not getattr(original, "_infinium_patched", None) is True:
            wrapped = _make_sync_wrapper(original, provider, capture_content)
            wrapped._infinium_patched = True  # type: ignore[attr-defined]
            wrapped._infinium_original = original  # type: ignore[attr-defined]
            completions.create = wrapped

    return client


def patch_async_openai_client(client: Any, capture_content: bool = False) -> Any:
    """Monkey-patch a single AsyncOpenAI client instance."""
    provider = _detect_provider(client)

    completions = getattr(getattr(client, "chat", None), "completions", None)
    if completions is not None:
        original = completions.create
        if not getattr(original, "_infinium_patched", None) is True:
            wrapped = _make_async_wrapper(original, provider, capture_content)
            wrapped._infinium_patched = True  # type: ignore[attr-defined]
            wrapped._infinium_original = original  # type: ignore[attr-defined]
            completions.create = wrapped

    return client


class OpenAIInstrumentor:
    """Global instrumentor that patches OpenAI at the class level.

    Usage::

        OpenAIInstrumentor(capture_content=True).instrument()
        # All OpenAI() and AsyncOpenAI() instances are now auto-instrumented.
        OpenAIInstrumentor().uninstrument()
    """

    _original_sync_create = None
    _original_async_create = None

    def __init__(self, capture_content: bool = False):
        self.capture_content = capture_content

    def instrument(self) -> None:
        try:
            import openai  # type: ignore[import-untyped]
        except ImportError:
            logger.warning("openai package not installed; OpenAIInstrumentor is a no-op")
            return

        # Patch sync
        sync_completions_cls = openai.resources.chat.completions.Completions
        if OpenAIInstrumentor._original_sync_create is None:
            OpenAIInstrumentor._original_sync_create = sync_completions_cls.create
        wrapped_sync = _make_sync_wrapper(
            OpenAIInstrumentor._original_sync_create, "openai", self.capture_content
        )
        wrapped_sync._infinium_patched = True  # type: ignore[attr-defined]
        sync_completions_cls.create = wrapped_sync

        # Patch async
        async_completions_cls = openai.resources.chat.completions.AsyncCompletions
        if OpenAIInstrumentor._original_async_create is None:
            OpenAIInstrumentor._original_async_create = async_completions_cls.create
        wrapped_async = _make_async_wrapper(
            OpenAIInstrumentor._original_async_create, "openai", self.capture_content
        )
        wrapped_async._infinium_patched = True  # type: ignore[attr-defined]
        async_completions_cls.create = wrapped_async

    def uninstrument(self) -> None:
        try:
            import openai  # type: ignore[import-untyped]
        except ImportError:
            return

        if OpenAIInstrumentor._original_sync_create is not None:
            openai.resources.chat.completions.Completions.create = (
                OpenAIInstrumentor._original_sync_create
            )
            OpenAIInstrumentor._original_sync_create = None

        if OpenAIInstrumentor._original_async_create is not None:
            openai.resources.chat.completions.AsyncCompletions.create = (
                OpenAIInstrumentor._original_async_create
            )
            OpenAIInstrumentor._original_async_create = None
