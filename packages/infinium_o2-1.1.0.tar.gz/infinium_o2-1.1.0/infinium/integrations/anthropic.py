"""
Anthropic adapter.

Patches ``messages.create`` (sync and async) to record every call
into the active :class:`TraceContext`.  Streaming captures usage from
``message_start`` / ``message_delta`` events.
"""
from __future__ import annotations

import time
import logging
from typing import Any, Iterator, AsyncIterator, Optional

from ._context import CapturedLlmCall, get_current_trace_context

logger = logging.getLogger(__name__)

_CONTENT_LIMIT = 500


def _truncate(text: Optional[str], limit: int = _CONTENT_LIMIT) -> Optional[str]:
    if text is None:
        return None
    return text[:limit] + "..." if len(text) > limit else text


def _extract_input(messages: Any, system: Any, capture_content: bool) -> Optional[str]:
    if not capture_content:
        return None
    parts = []
    if system:
        parts.append(f"[system] {system}")
    if messages:
        for msg in messages[-2:]:
            if isinstance(msg, dict):
                role = msg.get("role", "")
                content = msg.get("content", "")
                parts.append(f"[{role}] {content}")
    return _truncate("\n".join(parts)) if parts else None


def _extract_output(response: Any, capture_content: bool) -> Optional[str]:
    if not capture_content:
        return None
    try:
        for block in response.content:
            if hasattr(block, "text"):
                return _truncate(block.text)
    except (AttributeError, TypeError):
        pass
    return None


# ---------------------------------------------------------------------------
# Streaming wrappers
# ---------------------------------------------------------------------------

class _StreamWrapper:
    """Wraps an Anthropic sync event stream."""

    def __init__(self, stream: Iterator, call: CapturedLlmCall, capture_content: bool):
        self._stream = stream
        self._call = call
        self._capture_content = capture_content
        self._chunks: list[str] = []
        self._start_ns = time.perf_counter_ns()
        self._finalised = False

    def __iter__(self):
        return self

    def __next__(self):
        try:
            event = next(self._stream)
        except StopIteration:
            self._finalise()
            raise
        self._process_event(event)
        return event

    def __enter__(self):
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args):
        self._finalise()
        if hasattr(self._stream, "__exit__"):
            return self._stream.__exit__(*args)
        return False

    def _process_event(self, event: Any) -> None:
        event_type = getattr(event, "type", "")
        if event_type == "message_start":
            try:
                usage = event.message.usage
                self._call.prompt_tokens = usage.input_tokens
            except AttributeError:
                pass
        elif event_type == "message_delta":
            try:
                self._call.completion_tokens = event.usage.output_tokens
            except AttributeError:
                pass
        elif event_type == "content_block_delta":
            try:
                if hasattr(event.delta, "text"):
                    self._chunks.append(event.delta.text)
            except AttributeError:
                pass

    def _finalise(self) -> None:
        if self._finalised:
            return
        self._finalised = True
        self._call.latency_ns = time.perf_counter_ns() - self._start_ns
        if self._capture_content and self._chunks:
            self._call.output_preview = _truncate("".join(self._chunks))


class _AsyncStreamWrapper:
    """Wraps an Anthropic async event stream."""

    def __init__(self, stream: AsyncIterator, call: CapturedLlmCall, capture_content: bool):
        self._stream = stream
        self._call = call
        self._capture_content = capture_content
        self._chunks: list[str] = []
        self._start_ns = time.perf_counter_ns()
        self._finalised = False

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            event = await self._stream.__anext__()
        except StopAsyncIteration:
            self._finalise()
            raise
        self._process_event(event)
        return event

    async def __aenter__(self):
        if hasattr(self._stream, "__aenter__"):
            await self._stream.__aenter__()
        return self

    async def __aexit__(self, *args):
        self._finalise()
        if hasattr(self._stream, "__aexit__"):
            return await self._stream.__aexit__(*args)
        return False

    def _process_event(self, event: Any) -> None:
        event_type = getattr(event, "type", "")
        if event_type == "message_start":
            try:
                usage = event.message.usage
                self._call.prompt_tokens = usage.input_tokens
            except AttributeError:
                pass
        elif event_type == "message_delta":
            try:
                self._call.completion_tokens = event.usage.output_tokens
            except AttributeError:
                pass
        elif event_type == "content_block_delta":
            try:
                if hasattr(event.delta, "text"):
                    self._chunks.append(event.delta.text)
            except AttributeError:
                pass

    def _finalise(self) -> None:
        if self._finalised:
            return
        self._finalised = True
        self._call.latency_ns = time.perf_counter_ns() - self._start_ns
        if self._capture_content and self._chunks:
            self._call.output_preview = _truncate("".join(self._chunks))


# ---------------------------------------------------------------------------
# Patching helpers
# ---------------------------------------------------------------------------

def _make_sync_wrapper(original_create: Any, capture_content: bool) -> Any:
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        ctx = get_current_trace_context()
        if ctx is None:
            return original_create(*args, **kwargs)

        model = kwargs.get("model", "unknown")
        temperature = kwargs.get("temperature")
        messages = kwargs.get("messages")
        system = kwargs.get("system")
        is_stream = kwargs.get("stream", False)

        call = CapturedLlmCall(
            provider="anthropic",
            model=model,
            temperature=temperature,
            input_preview=_extract_input(messages, system, capture_content),
        )
        ctx.calls.append(call)

        start = time.perf_counter_ns()
        try:
            response = original_create(*args, **kwargs)
        except Exception as exc:
            call.latency_ns = time.perf_counter_ns() - start
            call.error_type = type(exc).__name__
            call.error_message = str(exc)
            raise

        if is_stream:
            return _StreamWrapper(response, call, capture_content)

        call.latency_ns = time.perf_counter_ns() - start
        try:
            call.model = response.model or model
            if response.usage:
                call.prompt_tokens = response.usage.input_tokens
                call.completion_tokens = response.usage.output_tokens
        except AttributeError:
            pass
        call.output_preview = _extract_output(response, capture_content)
        return response

    return wrapper


def _make_async_wrapper(original_create: Any, capture_content: bool) -> Any:
    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        ctx = get_current_trace_context()
        if ctx is None:
            return await original_create(*args, **kwargs)

        model = kwargs.get("model", "unknown")
        temperature = kwargs.get("temperature")
        messages = kwargs.get("messages")
        system = kwargs.get("system")
        is_stream = kwargs.get("stream", False)

        call = CapturedLlmCall(
            provider="anthropic",
            model=model,
            temperature=temperature,
            input_preview=_extract_input(messages, system, capture_content),
        )
        ctx.calls.append(call)

        start = time.perf_counter_ns()
        try:
            response = await original_create(*args, **kwargs)
        except Exception as exc:
            call.latency_ns = time.perf_counter_ns() - start
            call.error_type = type(exc).__name__
            call.error_message = str(exc)
            raise

        if is_stream:
            return _AsyncStreamWrapper(response, call, capture_content)

        call.latency_ns = time.perf_counter_ns() - start
        try:
            call.model = response.model or model
            if response.usage:
                call.prompt_tokens = response.usage.input_tokens
                call.completion_tokens = response.usage.output_tokens
        except AttributeError:
            pass
        call.output_preview = _extract_output(response, capture_content)
        return response

    return wrapper


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def patch_anthropic_client(client: Any, capture_content: bool = False) -> Any:
    """Monkey-patch a single Anthropic client instance."""
    messages = getattr(client, "messages", None)
    if messages is not None:
        original = messages.create
        if not getattr(original, "_infinium_patched", None) is True:
            wrapped = _make_sync_wrapper(original, capture_content)
            wrapped._infinium_patched = True  # type: ignore[attr-defined]
            wrapped._infinium_original = original  # type: ignore[attr-defined]
            messages.create = wrapped
    return client


def patch_async_anthropic_client(client: Any, capture_content: bool = False) -> Any:
    """Monkey-patch a single AsyncAnthropic client instance."""
    messages = getattr(client, "messages", None)
    if messages is not None:
        original = messages.create
        if not getattr(original, "_infinium_patched", None) is True:
            wrapped = _make_async_wrapper(original, capture_content)
            wrapped._infinium_patched = True  # type: ignore[attr-defined]
            wrapped._infinium_original = original  # type: ignore[attr-defined]
            messages.create = wrapped
    return client


class AnthropicInstrumentor:
    """Global instrumentor for Anthropic at the class level."""

    _original_sync_create = None
    _original_async_create = None

    def __init__(self, capture_content: bool = False):
        self.capture_content = capture_content

    def instrument(self) -> None:
        try:
            import anthropic  # type: ignore[import-untyped]
        except ImportError:
            logger.warning("anthropic package not installed; AnthropicInstrumentor is a no-op")
            return

        sync_cls = anthropic.resources.messages.Messages
        if AnthropicInstrumentor._original_sync_create is None:
            AnthropicInstrumentor._original_sync_create = sync_cls.create
        wrapped = _make_sync_wrapper(AnthropicInstrumentor._original_sync_create, self.capture_content)
        wrapped._infinium_patched = True  # type: ignore[attr-defined]
        sync_cls.create = wrapped

        async_cls = anthropic.resources.messages.AsyncMessages
        if AnthropicInstrumentor._original_async_create is None:
            AnthropicInstrumentor._original_async_create = async_cls.create
        wrapped_async = _make_async_wrapper(AnthropicInstrumentor._original_async_create, self.capture_content)
        wrapped_async._infinium_patched = True  # type: ignore[attr-defined]
        async_cls.create = wrapped_async

    def uninstrument(self) -> None:
        try:
            import anthropic  # type: ignore[import-untyped]
        except ImportError:
            return

        if AnthropicInstrumentor._original_sync_create is not None:
            anthropic.resources.messages.Messages.create = AnthropicInstrumentor._original_sync_create
            AnthropicInstrumentor._original_sync_create = None

        if AnthropicInstrumentor._original_async_create is not None:
            anthropic.resources.messages.AsyncMessages.create = AnthropicInstrumentor._original_async_create
            AnthropicInstrumentor._original_async_create = None
