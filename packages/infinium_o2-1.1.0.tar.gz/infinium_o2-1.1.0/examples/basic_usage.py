"""
Basic synchronous usage examples for the Infinium SDK.
"""
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

from infinium import (
    InfiniumClient, TaskData,
    TraceBuilder, ErrorDetail, LlmUsage, LlmCall, ExpectedOutcome,
)
from infinium.types import Customer, Sales, Support, Marketing, Research
from infinium.exceptions import InfiniumError, AuthenticationError, RateLimitError


def main():
    """Main example function."""
    # Initialize client with credentials from environment variables
    client = InfiniumClient(
        agent_id=os.getenv("INFINIUM_AGENT_ID"),
        agent_secret=os.getenv("INFINIUM_AGENT_SECRET"),
        enable_logging=True,
        log_level="INFO"
    )

    print("=" * 50)

    # Example 1: Simple task (unchanged API — backward compatible)
    print("Example 1: Simple task")
    try:
        response = client.send_task(
            name="Process customer inquiry",
            description="Handled customer question about pricing for enterprise package",
            duration=125.5,
        )

        print(f"  Task sent successfully!")
        print(f"  Status Code: {response.status_code}")

    except InfiniumError as e:
        print(f"  Task failed: {e}")

    print("\n" + "=" * 50)

    # Example 2: Task with enriched sections (new fields)
    print("Example 2: Task with enriched data")

    customer_data = Customer(
        customer_name="John Smith",
        customer_email="john.smith@acmecorp.com",
        client_company="Acme Corporation",
        client_industry="Manufacturing"
    )

    sales_data = Sales(
        lead_source="Website Contact Form",
        sales_stage="Qualified Lead",
        deal_value=15000.0,
        conversion_rate=0.75,
        sales_notes="Interested in enterprise features, budget approved"
    )

    try:
        response = client.send_task(
            name="Qualify enterprise lead",
            description="Evaluated enterprise customer needs and provided pricing information",
            duration=1800.0,
            customer=customer_data,
            sales=sales_data,
            input_summary="Inbound lead from website form: Acme Corp, manufacturing vertical",
            output_summary="Sent enterprise pricing deck; scheduled demo for next Tuesday",
            expected_outcome=ExpectedOutcome(
                task_objective="Qualify the lead and schedule a product demo",
                required_deliverables=["Pricing document sent", "Demo scheduled"],
                constraints=["Must follow up within 24h"],
            ),
        )

        print(f"  Sales task sent!")
        print(f"  Customer: {customer_data.customer_name}")
        print(f"  Deal Value: ${sales_data.deal_value:,.2f}")

    except InfiniumError as e:
        print(f"  Sales task failed: {e}")

    print("\n" + "=" * 50)

    # Example 3: TraceBuilder — multi-step trace with auto-timing
    print("Example 3: TraceBuilder with execution steps")

    trace = TraceBuilder(
        "AAPL Q4 Analysis",
        "Analyze Apple Q4 2025 earnings report",
    )
    trace.set_expected_outcome(
        task_objective="Produce investment-grade Q4 earnings summary for AAPL",
        required_deliverables=["Revenue breakdown by segment", "Margin analysis", "Forward guidance summary"],
        constraints=["Use only public SEC filings and earnings call transcript"],
    )
    trace.set_input_summary("Ticker: AAPL, Period: Q4 2025, Requested by: Portfolio team")

    # Step 1 — Search for filings
    with trace.step("tool_use", "Search SEC EDGAR for AAPL 10-Q") as step:
        # In real usage, this would call an actual API
        step.record_tool_call("edgar_api", duration_ms=450, output_summary="Found 3 filings")
        step.set_output("Found 3 filings: 10-Q (Q4), 8-K (Dec), 10-K (annual)")

    # Step 2 — LLM analysis
    with trace.step("llm_inference", "Summarize earnings data") as step:
        step.record_llm_call(
            "gpt-4o",
            provider="openai",
            prompt_tokens=4200,
            completion_tokens=1800,
            latency_ms=3200,
            purpose="main_reasoning",
        )
        step.set_output("Generated 1,400-word analysis covering revenue, margins, and guidance")

    # Step 3 — Format output
    with trace.step("decision", "Format and finalize report") as step:
        step.set_output("Formatted into structured report with executive summary")

    trace.set_output_summary("1,400-word analysis: Revenue $124.3B (+8% YoY), gross margin 46.2%, guidance raised")
    trace.set_llm_usage(LlmUsage(
        model="gpt-4o",
        provider="openai",
        prompt_tokens=4200,
        completion_tokens=1800,
        total_tokens=6000,
        api_calls_count=1,
        total_latency_ms=3200,
    ))

    # Set research section
    trace.set_section("research", Research(
        research_topic="AAPL Q4 2025 Earnings",
        research_method="SEC filing analysis + earnings call review",
        data_sources=["SEC EDGAR", "Earnings call transcript"],
        sources_consulted=3,
        key_findings=["Revenue beat estimates by 3%", "Services revenue up 18%", "Guidance raised for Q1"],
        analysis_type="Quantitative + Qualitative",
    ))

    task_data = trace.build()

    try:
        response = client.send_task_data(task_data)
        print(f"  TraceBuilder task sent!")
        print(f"  Steps: {len(task_data.steps)}")
        print(f"  Duration: {task_data.duration:.3f}s (auto-computed)")
        print(f"  Has expected_outcome: {task_data.expected_outcome is not None}")
        print(f"  Has environment: {task_data.environment is not None}")
    except InfiniumError as e:
        print(f"  TraceBuilder task failed: {e}")

    print("\n" + "=" * 50)

    # Example 4: Dict-to-dataclass coercion (backward compat for raw dict users)
    print("Example 4: Dict coercion — raw dicts auto-converted")

    task_data = InfiniumClient.create_task_data(
        name="Customer support ticket",
        description="Resolved auth issue for enterprise customer",
        duration=600,
        support={"call_id": "TICKET-2025-42", "issue_type": "Authentication", "resolution": "Reset API tokens"},
        expected_outcome={"task_objective": "Resolve customer auth issue within SLA"},
    )

    print(f"  support type: {type(task_data.support).__name__}")
    print(f"  expected_outcome type: {type(task_data.expected_outcome).__name__}")

    print("\n" + "=" * 50)

    # Example 5: wait_for_interpretation (polling)
    print("Example 5: Polling for Maestro interpretation")
    print("  (Skipped in this example — requires a running backend)")
    print("  Usage:")
    print("    response = client.send_task_data(task_data)")
    print("    trace_id = response.data['traceId']")
    print("    result = client.wait_for_interpretation(trace_id, timeout=120)")

    # Close the client
    client.close()
    print("\nAll examples completed!")


def batch_example():
    """Example of sending multiple tasks in batch."""
    print("Batch Example: Sending multiple tasks")

    client = InfiniumClient(
        agent_id=os.getenv("INFINIUM_AGENT_ID"),
        agent_secret=os.getenv("INFINIUM_AGENT_SECRET")
    )

    tasks = []
    for i in range(5):
        task = TaskData(
            name=f"Daily task #{i+1}",
            description=f"Completed routine task number {i+1} for the day",
            current_datetime=client.get_current_iso_datetime(),
            duration=float((i + 1) * 300),
        )
        tasks.append(task)

    try:
        result = client.send_tasks_batch(tasks, max_concurrent=3)
        print(f"  Batch completed! Successful: {result.successful}, Failed: {result.failed}")
    except InfiniumError as e:
        print(f"  Batch failed: {e}")

    client.close()


if __name__ == "__main__":
    if not os.getenv("INFINIUM_AGENT_ID") or not os.getenv("INFINIUM_AGENT_SECRET"):
        print("Please set INFINIUM_AGENT_ID and INFINIUM_AGENT_SECRET environment variables")
        exit(1)

    main()
    print("\n" + "=" * 60 + "\n")
    batch_example()
