"""
Asynchronous usage examples for the Infinium SDK.
"""
import asyncio
import os
from dotenv import load_dotenv

load_dotenv()

from infinium import (
    AsyncInfiniumClient, TaskData,
    TraceBuilder, trace_agent, async_trace_agent,
    LlmUsage,
)
from infinium.types import Customer, Development, Research
from infinium.exceptions import InfiniumError


async def main():
    """Main async example function."""
    async with AsyncInfiniumClient(
        agent_id=os.getenv("INFINIUM_AGENT_ID"),
        agent_secret=os.getenv("INFINIUM_AGENT_SECRET"),
        enable_logging=True,
        log_level="INFO"
    ) as client:

        print("=" * 50)

        # Example 1: Simple async task
        print("Example 1: Simple async task")
        try:
            response = await client.send_task(
                name="Async data processing",
                description="Processed large dataset using async operations",
                duration=1500.0,
            )
            print(f"  Sent! Status: {response.status_code}")
        except InfiniumError as e:
            print(f"  Failed: {e}")

        print("\n" + "=" * 50)

        # Example 2: TraceBuilder with multi-step workflow
        print("Example 2: TraceBuilder (async)")

        trace = TraceBuilder(
            "Code Review Agent",
            "Automated code review of PR #42",
        )
        trace.set_expected_outcome(
            task_objective="Review PR #42 for correctness, security, and style",
            required_deliverables=["Line-by-line comments", "Summary verdict"],
            constraints=["Must check for OWASP top 10 issues"],
        )
        trace.set_input_summary("PR #42: 14 files changed, +320 -45 lines")

        with trace.step("tool_use", "Fetch PR diff from GitHub") as step:
            step.record_tool_call("github_api", duration_ms=230, output_summary="14 files, 365 changed lines")
            step.set_output("Fetched diff: 14 files")

        with trace.step("llm_inference", "Analyze code for issues") as step:
            step.record_llm_call("gpt-4o", prompt_tokens=8000, completion_tokens=2000, latency_ms=5400)
            step.set_output("Found 3 issues: 1 security (SQL injection), 2 style")

        with trace.step("tool_use", "Post review comments to GitHub") as step:
            step.record_tool_call("github_api", duration_ms=180, output_summary="Posted 3 inline comments")
            step.set_output("Posted review comments")

        trace.set_output_summary("Review complete: 1 security issue (SQL injection in user_service.py), 2 style nits")
        trace.set_section("development", Development(
            programming_language="Python",
            framework_used="FastAPI",
            bugs_found=1,
            files_modified=["user_service.py", "auth_middleware.py"],
            tests_run=42,
            tests_passed=41,
        ))

        task_data = trace.build()

        try:
            response = await client.send_task_data(task_data)
            print(f"  TraceBuilder sent! Steps: {len(task_data.steps)}, Duration: {task_data.duration:.3f}s")
        except InfiniumError as e:
            print(f"  Failed: {e}")

        print("\n" + "=" * 50)

        # Example 3: Async decorator auto-instrumentation
        print("Example 3: @async_trace_agent decorator")

        @async_trace_agent(
            name="Research Task",
            client=client,
            auto_send=True,
            description="Perform research on the given query"
        )
        async def run_research(query: str) -> str:
            """Simulate a research task."""
            await asyncio.sleep(0.1)  # Simulate work
            return f"Research results for: {query} — Found 5 relevant papers"

        try:
            result = await run_research("LLM evaluation frameworks")
            print(f"  Decorator result: {result}")
        except InfiniumError as e:
            print(f"  Failed: {e}")


async def concurrent_tasks_example():
    """Example of sending multiple tasks concurrently."""
    print("Concurrent Tasks Example")

    async with AsyncInfiniumClient(
        agent_id=os.getenv("INFINIUM_AGENT_ID"),
        agent_secret=os.getenv("INFINIUM_AGENT_SECRET")
    ) as client:

        tasks = [
            TaskData(
                name="Morning standup meeting",
                description="Facilitated daily standup for development team",
                current_datetime=client.get_current_iso_datetime(),
                duration=900.0,
            ),
            TaskData(
                name="Customer feedback analysis",
                description="Analyzed recent customer feedback and identified improvement areas",
                current_datetime=client.get_current_iso_datetime(),
                duration=3600.0,
            ),
            TaskData(
                name="Blog post creation",
                description="Created technical blog post about API best practices",
                current_datetime=client.get_current_iso_datetime(),
                duration=7200.0,
            ),
        ]

        try:
            result = await client.send_tasks_batch(tasks, max_concurrent=2)
            print(f"  Batch completed! Successful: {result.successful}, Failed: {result.failed}")
        except InfiniumError as e:
            print(f"  Batch failed: {e}")


if __name__ == "__main__":
    if not os.getenv("INFINIUM_AGENT_ID") or not os.getenv("INFINIUM_AGENT_SECRET"):
        print("Please set INFINIUM_AGENT_ID and INFINIUM_AGENT_SECRET environment variables")
        exit(1)

    async def run_all():
        await main()
        print("\n" + "=" * 60 + "\n")
        await concurrent_tasks_example()
        print("\nAll async examples completed!")

    asyncio.run(run_all())
