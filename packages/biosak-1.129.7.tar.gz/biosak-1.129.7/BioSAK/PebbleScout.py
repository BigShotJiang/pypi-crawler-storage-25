import os
import glob
import argparse
from Bio import SeqIO
import multiprocessing as mp


PebbleScout_usage = '''
=================== PebbleScout example commands ===================

BioSAK PebbleScout -i gnm_dir -x fna -db meta,meta_vol2 -o op_dir

====================================================================
'''


def sep_path_basename_ext(file_in):
    f_path, f_name = os.path.split(file_in)
    if f_path == '':
        f_path = '.'
    f_base, f_ext = os.path.splitext(f_name)
    f_ext = f_ext[1:]
    return f_name, f_path, f_base, f_ext


def pebblescout_results_to_data_matrix(file_list, db_list, pebblescout_op_dir, min_cov_pct, op_txt, metadata_txt):

    subject_to_biosample_dict = dict()
    biosample_title_dict = dict()
    subject_id_set_all = set()
    pebblescout_op_dod = dict()
    for each_gnm in file_list:
        f_name, f_path, f_base, f_ext = sep_path_basename_ext(each_gnm)
        current_gnm_dict = dict()
        for each_db in db_list:
            op_file = '%s/%s_%s.txt' % (pebblescout_op_dir, f_base, each_db)
            if os.path.isfile(op_file):
                for each_line in open(op_file):
                    if not each_line.startswith('QueryID\tSubjectID'):
                        each_line_split = each_line.strip().split('\t')
                        subject_id      = each_line_split[1]
                        pct_coverage    = each_line_split[3]
                        bioSample_id    = each_line_split[5]
                        bioSample_title = each_line_split[6]
                        if (bioSample_id != '""') and (bioSample_title != '""'):
                            if float(pct_coverage) >= min_cov_pct:
                                current_gnm_dict[subject_id] = pct_coverage
                                subject_to_biosample_dict[subject_id] = bioSample_id
                                biosample_title_dict[bioSample_id] = bioSample_title
                                subject_id_set_all.add(subject_id)
        pebblescout_op_dod[f_base] = current_gnm_dict

    subject_id_list_sorted = sorted(list(subject_id_set_all))

    # write out to file
    op_txt_handle = open(op_txt, 'w')
    op_txt_handle.write('Genome\t%s\n' % ('\t'.join(subject_id_list_sorted)))
    for each_gnm in sorted(list(pebblescout_op_dod.keys())):
        current_gnm_dict = pebblescout_op_dod[each_gnm]
        value_list = [each_gnm]
        for each_subject_id in subject_id_list_sorted:
            value_list.append(current_gnm_dict.get(each_subject_id, '0'))
        op_txt_handle.write('%s\n' % ('\t'.join(value_list)))
    op_txt_handle.close()

    metadata_txt_handle = open(metadata_txt, 'w')
    for each_subject in subject_id_list_sorted:
        bioSample_id = subject_to_biosample_dict[each_subject]
        bioSample_title = biosample_title_dict[bioSample_id]
        metadata_txt_handle.write('%s\t%s\t%s\n' % (each_subject, bioSample_id, bioSample_title))
    metadata_txt_handle.close()


def PebbleScout(args):

    file_dir            = args['i']
    file_ext            = args['x']
    db_str              = args['db']
    # min_cov_pct         = args['min_cov']
    num_threads         = args['t']
    force_create_op_dir = args['f']
    op_dir              = args['o']
    gnm_id_txt          = args['id']


    # define file name
    gnm_dir                 = '%s/genomes_concatenated'             % op_dir
    pebblescout_op_dir      = '%s/pebblescout_op'                   % op_dir
    cmd_txt                 = '%s/commands.txt'                     % op_dir
    df_txt                  = '%s/PebbleScout_df.txt'               % op_dir
    df_txt_all              = '%s/PebbleScout_df_all.txt'           % op_dir
    df_txt_min_cov_1        = '%s/PebbleScout_df_min_cov_1.txt'     % op_dir
    df_txt_min_cov_3        = '%s/PebbleScout_df_min_cov_3.txt'     % op_dir
    df_txt_min_cov_5        = '%s/PebbleScout_df_min_cov_5.txt'     % op_dir
    df_txt_min_cov_10       = '%s/PebbleScout_df_min_cov_10.txt'    % op_dir
    metadata_txt            = '%s/metadata.txt'                     % op_dir

    # create output folder
    if os.path.isdir(op_dir) is True:
        if force_create_op_dir is True:
            os.system('rm -r %s' % op_dir)
        else:
            print('Output folder detected, program exited!')
            exit()
    os.system('mkdir %s' % op_dir)
    os.system('mkdir %s' % gnm_dir)
    os.system('mkdir %s' % pebblescout_op_dir)

    db_list = db_str.split(',')

    gnm_id_set = set()
    if gnm_id_txt is not None:
        if os.path.isfile(gnm_id_txt) is True:
            for each_gnm in open(gnm_id_txt):
                gnm_id_set.add(each_gnm.strip().split()[0])

    # concatenate sequences in input genomes
    file_re = '%s/*.%s' % (file_dir, file_ext)
    file_list = glob.glob(file_re)
    file_base_list_to_process = []
    for each_gnm in file_list:
        f_name, f_path, f_base, f_ext = sep_path_basename_ext(each_gnm)

        to_process = ''
        if len(gnm_id_set) == 0:
            to_process = True
        else:
            if (f_base in gnm_id_set) or (f_name in gnm_id_set):
                to_process = True

        if to_process is True:
            file_base_list_to_process.append(f_base)
            current_gnm_after_cat = '%s/%s.%s' % (gnm_dir, f_base, f_ext)
            concatenates_seq_str = ''
            for each_seq in SeqIO.parse(each_gnm, 'fasta'):
                concatenates_seq_str = concatenates_seq_str + str(each_seq.seq).strip()
            current_gnm_after_cat_handle = open(current_gnm_after_cat, 'w')
            current_gnm_after_cat_handle.write('>%s\n' % f_base)
            current_gnm_after_cat_handle.write(concatenates_seq_str + '\n')
            current_gnm_after_cat_handle.close()

    # get pebblescout commands
    cmd_txt_handle = open(cmd_txt, 'w')
    cmd_set = set()
    for f_base in file_base_list_to_process:
        for each_db in db_list:
            pebblescout_cmd = 'curl -s -F "fasta=@%s/%s" "https://pebblescout.ncbi.nlm.nih.gov/sra-cl-be/sra-cl-be.cgi?db=%s&m=2&rettype=pebblescout&download=yes" > %s/%s_%s.txt' % (gnm_dir, f_name, each_db, pebblescout_op_dir, f_base, each_db)
            cmd_set.add(pebblescout_cmd)
            cmd_txt_handle.write(pebblescout_cmd + '\n')
    cmd_txt_handle.close()

    # run pebblescout
    print('Running %s commands with %s cores' % (len(file_base_list_to_process), num_threads))
    pool = mp.Pool(processes=num_threads)
    pool.map(os.system, sorted([i for i in cmd_set]))
    pool.close()
    pool.join()

    # get data matrix
    pebblescout_results_to_data_matrix(file_list, db_list, pebblescout_op_dir, 1,  df_txt_min_cov_1,  metadata_txt)
    pebblescout_results_to_data_matrix(file_list, db_list, pebblescout_op_dir, 3,  df_txt_min_cov_3,  metadata_txt)
    pebblescout_results_to_data_matrix(file_list, db_list, pebblescout_op_dir, 5,  df_txt_min_cov_5,  metadata_txt)
    pebblescout_results_to_data_matrix(file_list, db_list, pebblescout_op_dir, 10, df_txt_min_cov_10, metadata_txt)
    pebblescout_results_to_data_matrix(file_list, db_list, pebblescout_op_dir, 0,  df_txt_all,        metadata_txt)

    print('Done!')


if __name__ == '__main__':

    PebbleScout_parser = argparse.ArgumentParser(usage=PebbleScout_usage)
    PebbleScout_parser.add_argument('-i',           required=True,                                  help='input fasta file/dir')
    PebbleScout_parser.add_argument('-x',           required=False, default=None,                   help='file extension')
    PebbleScout_parser.add_argument('-id',          required=False, default=None,                   help='id of genomes to process')
    PebbleScout_parser.add_argument('-db',          required=False, default='meta,meta_vol2',       help='query database, default is meta and meta_vol2')
    # PebbleScout_parser.add_argument('-min_cov',     required=False, type=str, default='1,3,5,10',   help='minimum %coverage to include in the datamatrix, default is 1,3,5,10')
    PebbleScout_parser.add_argument('-t',           required=False, type=int, default=1,            help='number of core, default is 1')
    PebbleScout_parser.add_argument('-f',           required=False, action="store_true",            help='force overwrite')
    PebbleScout_parser.add_argument('-o',           required=True,                                  help='output directory')
    args = vars(PebbleScout_parser.parse_args())
    PebbleScout(args)
