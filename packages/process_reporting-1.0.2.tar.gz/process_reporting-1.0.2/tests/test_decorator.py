import pytest
from unittest.mock import patch, AsyncMock
from src.bpmn_reporting.decorator import bpmn_element
from src.bpmn_reporting.models import ReportStatus

@pytest.mark.asyncio
async def test_bpmn_element_success():
    """Tests if the decorator captures STARTED and COMPLETED events on success."""

    # We mock _publish_event so it doesn't actually call the API
    with patch("src.bpmn_reporting.decorator._publish_event", new_callable=AsyncMock) as mock_publish:

        @bpmn_element(id="Task_Success", process_id="P_100")
        async def my_function(name):
            return {"hello": name}

        # Execute
        result = await my_function("Mario")

        # Assertions
        assert result == {"hello": "Mario"}
        assert mock_publish.call_count == 2

        # Check first call was STARTED
        first_call_event = mock_publish.call_args_list[0][0][0]
        assert first_call_event.status == ReportStatus.STARTED

        # Check second call was COMPLETED
        second_call_event = mock_publish.call_args_list[1][0][0]
        assert second_call_event.status == ReportStatus.COMPLETED

@pytest.mark.asyncio
async def test_bpmn_element_error():
    """Tests if the decorator captures the ERROR event when the function crashes."""

    with patch("src.bpmn_reporting.decorator._publish_event", new_callable=AsyncMock) as mock_publish:

        @bpmn_element(id="Task_Fail")
        async def failing_function():
            raise ValueError("F*ck Python!")

        # We expect the exception to still be raised (re-raised by decorator)
        with pytest.raises(ValueError, match="F*ck Python!"):
            await failing_function()

        # Check that an ERROR event was sent
        # Call 1: STARTED, Call 2: ERROR
        error_event = mock_publish.call_args_list[1][0][0]
        assert error_event.status == ReportStatus.ERROR
        assert error_event.errorMessage == "F*ck Python!"
