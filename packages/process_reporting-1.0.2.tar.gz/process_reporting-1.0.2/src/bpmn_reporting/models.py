from dataclasses import dataclass
from typing import Dict, Union, Callable, Optional, Any
from enum import Enum

class ReportStatus(str, Enum):
    # Process/Activity has been queued
    QUEUED = 'QUEUED'

    # Process/Activity has been started
    STARTED = 'STARTED'

    # Process/Activity has been restarted
    RESTARTED = 'RESTARTED'

    # Process/Activity has been completed
    COMPLETED = 'COMPLETED'

    # Process/Activity has been terminated and should be deleted
    TERMINATED = 'TERMINATED'

    PROCESS_COMPLETED = 'PROCESS_COMPLETED'

    # Process/Activity has warning, but will not stop the process
    WARNING = 'WARNING'

    # Process/Activity has error and the process will be terminated
    ERROR = 'ERROR'


@dataclass
class ReportEvent:

    status: ReportStatus

    params: Optional[Any] = None

    startEvent: Optional[bool] = None
    endEvent: Optional[bool] = None

    # Camunda Element id
    elementId: Optional[str] = None

    transactionId: Optional[str] = None

    # Camunda process id
    processId: Optional[str] = None

    # Unique Execution id
    executionId: Optional[str] = None

    # Camunda process version 1.0
    processVersion: Optional[str] = None

    # Event timestamp (Equivalent to JS Date)
    eventTime: Optional[str] = None

    # NOTE: if size of payload is longer then supported, we need to chunk
    partCount: Optional[int] = None

    # Who triggered the event
    startedBy: Optional[str] = None

    # Multiple Instance Count
    multipleInstanceIndex: Optional[str] = None
    instanceId: Optional[str] = None

    # Optional fields (nullable)
    errorMessage: Optional[str] = None
    retryCount: Optional[int] = None
    referenceId: Optional[str] = None
    referenceType: Optional[str] = None
    payload: Optional[str] = None


@dataclass
class BpmnElementOptions:
    # Record<string, string | Function | undefined>
    mask_params: Optional[Dict[str, Union[str, Callable, None]]] = None

    id: Optional[str] = None
    process_id: Optional[str] = None
    multiple_instance: Optional[str] = None
    retries: Optional[int] = None
    delay: Optional[int] = None
    suppress_exception: Optional[bool] = None
    start_event: Optional[bool] = None
    end_event: Optional[bool] = None

    # string | Function
    instance_id_expression: Optional[Union[str, Callable]] = None
    key_expression: Optional[Union[str, Callable]] = None
    started_by_expression: Optional[Union[str, Callable]] = None
    transaction_id_expression: Optional[Union[str, Callable]] = None