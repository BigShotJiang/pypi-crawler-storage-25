import inspect
from typing import Optional, Any, Callable, Union, Dict
import pystache
import uuid
import os
import httpx
import logging
from datetime import datetime, timezone
from dataclasses import asdict
import json

from .models import ReportEvent, BpmnElementOptions, ReportStatus


def _get_payload(func, args, kwargs):
    sig = inspect.signature(func)
    bound_args = sig.bind(*args, **kwargs)
    bound_args.apply_defaults()

    return bound_args.arguments


async def _publish_event(event: ReportEvent, options: BpmnElementOptions):
    event.elementId = options.id

    if options.process_id:
        event.processId = options.process_id

    event.startEvent = options.start_event is True
    event.endEvent = options.end_event is True

    event.execution_id = str(uuid.uuid4())

    if event.startEvent:
        event.reference_type = os.environ.get("REPORTING_EVENT_CATEGORY")

    elif event.endEvent and event.status == ReportStatus.COMPLETED:
        event.status = ReportStatus.PROCESS_COMPLETED

    if event.transactionId:
        parent_transaction_id = event.transactionId.split(':')[0]
        event.transactionId = parent_transaction_id

    return await fire_event(event)


async def fire_event(event: ReportEvent):
    base_url = os.environ.get("REPORTING_SERVER", "")
    url = f"{base_url}/reporting-service/rest/api/report"

    if not event.processId:
        event.processId = os.environ.get("REPORTING_PROCESS_ID", "")

    # Set metadata and defaults
    event.eventTime = datetime.now(timezone.utc).isoformat()
    event.processVersion = os.environ.get("REPORTING_PROCESS_VERSION", "1.0")
    event.startedBy = event.startedBy or 'system'

    # Optional debug logging
    if os.environ.get("REPORTING_PROCESS_DEBUG") == 'true':
        print(f"[DEBUG] Event: {event}")

    # Prepare JSON payload (stripping None values)
    payload = {k: v for k, v in asdict(event).items() if v is not None}

    # Asynchronous POST request using httpx
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(url, json=payload)
            response.raise_for_status()
            return response.json()
        except Exception as e:

            logging.error(
                f"Unable to post Process Event [{event.processId}/{event.elementId}] [{url}] Error: {e}"
            )
            return None


def _parse_expression(expression: Union[str, Callable, None], payload: Any) -> Optional[str]:
    if not expression or payload is None:
        return None

    # Handle Array/List context
    context = payload
    if isinstance(payload, list):
        context = {"items": payload}

    # If expression is a function or lambda
    if callable(expression):
        return expression(context)

    # Standard Mustache render
    if isinstance(expression, str):
        return pystache.render(expression, context)

    return None


def _serialize_payload(payload: Any, mask_params: Optional[Dict[str, Any]]) -> Any:
    if not mask_params or not isinstance(payload, dict):
        return payload

    result = payload.copy()

    for key, expression in mask_params.items():
        if expression is None:
            result.pop(key, None)
        else:
            context = payload
            if callable(expression):
                result[key] = expression(context)
            elif isinstance(expression, str):
                result[key] = pystache.render(expression, context)

    clean_json = {k: v for k, v in result.items() if v is not None}

    return json.dumps(clean_json)
