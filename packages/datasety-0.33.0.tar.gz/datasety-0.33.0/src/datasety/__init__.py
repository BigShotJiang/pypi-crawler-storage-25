"""datasety - dataset preparation tools.

Commands: resize, align, caption, shuffle, synthetic, mask, filter, degrade,
character, sweep, workflow, audio.
"""

__version__ = "0.33.0"
