"""
Public SDK for run management (create, list, get, cancel, delete, logs, csv, videos, download).

Use these for programmatic run inspection, cancellation, and video downloads.
For end-to-end pipeline execution (create run + generate + upload), use worldjen.run().
"""

from pathlib import Path
import json
import time
from dataclasses import asdict, is_dataclass
from typing import Any, Callable, Dict, List, Optional

from worldjen._api import (
    ApiError,
    cancel_run,
    create_run,
    delete_run,
    get_run,
    get_run_csv,
    get_run_logs,
    get_run_videos,
    list_runs as _list_runs,
)
from worldjen._run import Progress, progress_from_api

try:
    import requests
except ImportError:  # pragma: no cover — defensive; requests is a dependency
    requests = None


__all__ = [
    "create",
    "get",
    "wait",
    "list_runs",
    "cancel",
    "delete",
    "get_logs",
    "get_csv",
    "get_videos",
    "download_videos",
]

TERMINAL_STATUSES = {"completed", "failed", "cancelled", "deleted"}

# Stop polling completed-but-not-fully-evaluated runs after this many consecutive
# polls with no progress change. ~5 minutes at default 2s interval. Long enough
# for slow Gemini batches, short enough to not hang scripts on truly stuck runs.
_COMPLETED_STALL_LIMIT = 150


def create(
    name: str,
    dimensions: List[str],
    *,
    runner_id: str,
    model_id: str,
    run_instructions: Optional[Dict[str, Any]] = None,
    reference_model_id: Optional[str] = None,
    reasoning_enabled: bool = False,
) -> str:
    """
    Create a run and enqueue it on the given runner. Returns the run ID.

    Pass ``reference_model_id`` to compare against another model in the same run
    (the dashboard's reference-model comparison flow).

    For a run that is not tied to a worker queue (e.g. internal tooling), use
    ``worldjen._api.create_run`` with ``runner_id`` omitted.
    """
    return create_run(
        name=name,
        dimensions=dimensions,
        run_instructions=run_instructions,
        model_id=model_id,
        runner_id=runner_id,
        reference_model_id=reference_model_id,
        reasoning_enabled=reasoning_enabled,
    )


def get(run_id: str) -> Dict[str, Any]:
    """Fetch run metadata and result data."""
    data = get_run(run_id)
    progress = progress_from_api(data.get("progress")) if isinstance(data, dict) else None
    if progress is None:
        return data
    return {**data, "progress": progress}


def wait(
    run_id: str,
    poll_interval: float = 2.0,
    on_progress: Optional[Callable[[Progress], None]] = None,
    timeout: Optional[float] = None,
) -> Dict[str, Any]:
    """Poll a run until it reaches completed, failed, cancelled, or deleted.

    ``on_progress`` is called only when the stable progress payload changes.
    ``poll_interval`` is clamped to at least 1 second to avoid hammering the API.
    A 404 from the API is treated as a deleted run.
    """
    interval = max(1.0, float(poll_interval))
    start = time.monotonic()
    last_progress_hash: Optional[str] = None
    stalled_polls = 0

    while True:
        try:
            data = get(run_id)
        except ApiError as exc:
            if exc.status_code == 404:
                return {"status": "deleted"}
            raise
        progress = data.get("progress") if isinstance(data, dict) else None
        progress_changed = False
        if isinstance(progress, Progress):
            progress_hash = _progress_hash(progress)
            if progress_hash != last_progress_hash:
                progress_changed = True
                if on_progress is not None:
                    on_progress(progress)
                last_progress_hash = progress_hash

        status = str(data.get("status") or "").lower() if isinstance(data, dict) else ""
        if status in TERMINAL_STATUSES:
            # For "completed", evaluator may still be writing scores. Keep polling
            # until progress catches up — but bail if it stalls for too long so
            # we don't hang on a stuck run.
            still_evaluating = (
                status == "completed"
                and isinstance(progress, Progress)
                and progress.videos_total > 0
                and progress.videos_evaluated < progress.videos_total
            )
            if still_evaluating:
                stalled_polls = 0 if progress_changed else stalled_polls + 1
                if stalled_polls >= _COMPLETED_STALL_LIMIT:
                    return data
            else:
                return data

        if timeout is not None:
            elapsed = time.monotonic() - start
            if elapsed >= timeout:
                raise TimeoutError(f"Timed out waiting for run {run_id}")
            sleep_for = min(interval, max(0.0, timeout - elapsed))
        else:
            sleep_for = interval
        time.sleep(sleep_for)


def cancel(run_id: str) -> None:
    """Cancel a run."""
    cancel_run(run_id)


def delete(run_id: str) -> None:
    """Delete a run."""
    delete_run(run_id)


def get_logs(run_id: str) -> Dict[str, Any]:
    """Fetch run logs."""
    return get_run_logs(run_id)


def get_csv(run_id: str) -> bytes:
    """Fetch run CSV as bytes."""
    return get_run_csv(run_id)


def list_runs(
    status: Optional[str] = None,
    page: int = 1,
    limit: int = 50,
) -> Dict[str, Any]:
    """List runs with optional status filter and pagination."""
    return _list_runs(status=status, page=page, limit=limit)


def get_videos(run_id: str) -> List[Dict[str, Any]]:
    """List video metadata (id, prompt, url) for a run."""
    return get_run_videos(run_id)


_CONTENT_TYPE_EXT = {
    "video/mp4": ".mp4",
    "video/webm": ".webm",
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/jpg": ".jpg",
    "image/webp": ".webp",
}


def _extension_for_video(video: Dict[str, Any], url: str) -> str:
    """Resolve a file extension for a downloaded video/image asset.

    text_to_image runs return image content (PNG/JPEG/WebP), not video,
    so this also has to handle image types — earlier logic that branched
    only on `mp4` would mis-label PNGs as `.webm`.
    """
    content_type = (video.get("contentType") or "").lower().split(";")[0].strip()
    if content_type in _CONTENT_TYPE_EXT:
        return _CONTENT_TYPE_EXT[content_type]
    url_path = url.split("?", 1)[0].rsplit("/", 1)[-1]
    if "." in url_path:
        suffix = "." + url_path.rsplit(".", 1)[-1].lower()
        if suffix in {".mp4", ".webm", ".png", ".jpg", ".jpeg", ".webp"}:
            return ".jpg" if suffix == ".jpeg" else suffix
    return ".mp4"


def download_videos(
    run_id: str,
    output_dir: str | Path = ".",
) -> Path:
    """
    Download all videos for a run to output_dir.
    Returns the output directory path.
    """
    if requests is None:
        raise ImportError("requests is required for download_videos")
    videos = get_run_videos(run_id)
    out_dir = Path(output_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    for i, v in enumerate(videos):
        url = v.get("url")
        if not url:
            continue
        vid = v.get("id") or v.get("_id") or str(i)
        ext = _extension_for_video(v, url)
        path = out_dir / f"{vid}{ext}"
        r = requests.get(url, timeout=300)
        r.raise_for_status()
        path.write_bytes(r.content)
    return out_dir


def _progress_hash(progress: Progress) -> str:
    return json.dumps(
        {
            "videosTotal": progress.videos_total,
            "videosEvaluated": progress.videos_evaluated,
            "perDimension": {
                key: asdict(value) if is_dataclass(value) else value
                for key, value in sorted(progress.per_dimension.items())
            },
        },
        sort_keys=True,
    )
