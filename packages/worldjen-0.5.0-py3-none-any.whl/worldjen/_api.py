import hashlib
import json
import os
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

from worldjen._config import _config


def _sdk_version() -> str:
    try:
        from importlib.metadata import version
        return version("worldjen")
    except Exception:
        return "unknown"


def _headers() -> Dict[str, str]:
    base = {
        "Content-Type": "application/json",
        "User-Agent": f"worldjen-sdk/{_sdk_version()}",
        "X-WorldJen-Source": "sdk",
    }
    api_key = _config.api_key
    if api_key:
        return {**base, "X-API-Key": api_key}
    runner_token = _runner_token_if_available()
    if runner_token:
        return {**base, "Authorization": f"Bearer {runner_token}"}
    raise RuntimeError(
        "worldjen.config(api_key=...) or WORLDJEN_API_KEY must be set, "
        "or run inside a registered runner with a valid runner token"
    )


def _runner_token_if_available() -> Optional[str]:
    """Return the runner token if this process is running as a registered
    WorldJen runner. Imports lazily so non-runner SDK callers never load
    the runner config module."""
    try:
        from worldjen.runner.config import config as runner_config  # type: ignore
        return runner_config.get_runner_token()
    except Exception:
        return None


class ApiError(RuntimeError):
    """RuntimeError subclass that preserves the HTTP status code from the
    failed response. Callers that need to branch on auth-vs-transient (e.g.
    ``_is_auth_error``) can read ``status_code`` directly instead of relying
    on the message text."""

    def __init__(self, message: str, status_code: int) -> None:
        super().__init__(message)
        self.status_code = status_code


def _raise_for_response(response: requests.Response, context: str) -> None:
    if not response.ok:
        try:
            detail = response.json().get("detail", response.text)
        except Exception:
            detail = response.text
        raise ApiError(f"{context}: {detail}", status_code=response.status_code)


def create_run(
    name: str,
    dimensions: List[str],
    run_instructions: Optional[Dict[str, Any]] = None,
    model_id: Optional[str] = None,
    runner_id: Optional[str] = None,
    reference_model_id: Optional[str] = None,
    reasoning_enabled: bool = False,
) -> str:
    url = f"{_config.api_url}/api/v1/runs"
    runner_id_val = (runner_id or "").strip() or None
    model_id_val = (model_id or "").strip() or None
    reference_model_id_val = (reference_model_id or "").strip() or None

    if runner_id_val and not model_id_val:
        raise ValueError("model_id is required when runner_id is set")

    if runner_id_val and model_id_val:
        payload: Dict[str, Any] = {
            "name": name,
            "runner_id": runner_id_val,
            "model_id": model_id_val,
            "run_instructions": _json_sanitize(
                run_instructions if run_instructions is not None else {}
            ),
            "evaluate_config": {
                "dimensions": dimensions,
                "reasoning_enabled": reasoning_enabled,
            },
        }
    else:
        payload = {
            "name": name,
            "dimensions": dimensions,
            "reasoning_enabled": reasoning_enabled,
        }
        if run_instructions is not None:
            payload["run_instructions"] = _json_sanitize(run_instructions)
        if model_id_val is not None:
            payload["model_id"] = model_id_val
    if reference_model_id_val is not None:
        payload["reference_model_id"] = reference_model_id_val
    response = requests.post(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Create run failed")
    data = response.json()
    run_id = data.get("run_id") or data.get("id") or data.get("_id")
    if not run_id:
        raise RuntimeError("Create run: response missing run id")
    return str(run_id)


def update_run_status(
    run_id: str,
    status: Optional[str] = None,
    error_message: Optional[str] = None,
    num_videos: Optional[int] = None,
) -> None:
    url = f"{_config.api_url}/api/v1/runs/{run_id}"
    payload: Dict[str, Any] = {}
    if status is not None:
        payload["status"] = status
    if error_message is not None:
        payload["errorMessage"] = error_message
    if num_videos is not None:
        payload["numVideos"] = num_videos
    response = requests.patch(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Update run status failed")


def get_run(run_id: str) -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/runs/{run_id}"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Get run failed")
    return response.json()


def list_runs(
    status: Optional[str] = None,
    page: int = 1,
    limit: int = 50,
) -> Dict[str, Any]:
    params: List[str] = [f"page={page}", f"limit={limit}"]
    if status:
        params.append(f"status={status}")
    url = f"{_config.api_url}/api/v1/runs?{'&'.join(params)}"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "List runs failed")
    return response.json()


def cancel_run(run_id: str) -> None:
    url = f"{_config.api_url}/api/v1/runs/{run_id}/cancel"
    response = requests.post(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Cancel run failed")


def delete_run(run_id: str) -> None:
    url = f"{_config.api_url}/api/v1/runs/{run_id}"
    response = requests.delete(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Delete run failed")


def get_run_logs(run_id: str) -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/runs/{run_id}/logs"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Get run logs failed")
    return response.json()


def get_run_csv(run_id: str) -> bytes:
    url = f"{_config.api_url}/api/v1/runs/{run_id}/csv"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Get run CSV failed")
    return response.content


def get_run_videos(run_id: str) -> List[Dict[str, Any]]:
    url = f"{_config.api_url}/api/v1/runs/{run_id}/videos"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Get run videos failed")
    data = response.json()
    return data if isinstance(data, list) else data.get("videos", [])


def get_or_create_playground_run(kind: str = "playground") -> Dict[str, Any]:
    if kind not in ("playground", "rank"):
        raise ValueError("kind must be 'playground' or 'rank'")
    qs = "?kind=rank" if kind == "rank" else ""
    url = f"{_config.api_url}/api/v1/runs/playground{qs}"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Get playground run failed")
    return response.json()


def reset_playground_run(kind: str = "playground") -> Dict[str, Any]:
    if kind not in ("playground", "rank"):
        raise ValueError("kind must be 'playground' or 'rank'")
    qs = "?kind=rank" if kind == "rank" else ""
    url = f"{_config.api_url}/api/v1/runs/playground/reset{qs}"
    response = requests.post(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Reset playground run failed")
    return response.json()


def append_run_logs(run_id: str, logs: str) -> None:
    url = f"{_config.api_url}/api/v1/runner/runs/{run_id}/logs"
    response = requests.post(
        url, json={"logs": logs}, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Append run logs failed")


def get_upload_url(
    run_id: str,
    file_name: str,
    content_type: str = "video/mp4",
    prompt: Optional[str] = None,
    prompt_hash: Optional[str] = None,
    dimension_ids: Optional[List[str]] = None,
    reference_image_url: Optional[str] = None,
    source: str = "sdk",
) -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/runner/runs/videos/upload-url"
    payload: Dict[str, Any] = {
        "runId": run_id,
        "fileName": file_name,
        "contentType": content_type,
        "source": source,
    }
    if prompt is not None:
        payload["prompt"] = prompt
    if prompt_hash is not None:
        payload["promptHash"] = prompt_hash
    if dimension_ids is not None:
        payload["dimensionIds"] = dimension_ids
    if reference_image_url is not None:
        payload["referenceImageUrl"] = reference_image_url
    response = requests.post(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Get upload URL failed")
    return response.json()


def upload_to_presigned(
    upload_url: str,
    file_path: Any,
    content_type: str = "video/mp4",
) -> None:
    path = Path(file_path) if not isinstance(file_path, Path) else file_path
    with open(path, "rb") as f:
        body = f.read()
    response = requests.put(
        upload_url,
        data=body,
        headers={"Content-Type": content_type},
        timeout=_config.timeout,
    )
    if not response.ok:
        raise RuntimeError(f"Upload to presigned URL failed: {response.status_code} {response.text}")


def confirm_upload(run_id: str, video_id: str) -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/runner/runs/videos/confirm-upload"
    payload: Dict[str, Any] = {"runId": run_id, "videoId": video_id}
    response = requests.post(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Confirm upload failed")
    return response.json()


def list_user_models(sort_by: Optional[str] = None) -> List[Dict[str, Any]]:
    url = f"{_config.api_url}/api/v1/models"
    if sort_by:
        url += f"?sortBy={sort_by}"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "List user models failed")
    data = response.json()
    return data if isinstance(data, list) else data.get("models", [])


def list_base_models(sort_by: Optional[str] = None) -> List[Dict[str, Any]]:
    url = f"{_config.api_url}/api/v1/models/base"
    if sort_by:
        url += f"?sortBy={sort_by}"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "List base models failed")
    data = response.json()
    return data if isinstance(data, list) else data.get("models", [])


def list_ref_models(sort_by: Optional[str] = None) -> List[Dict[str, Any]]:
    url = f"{_config.api_url}/api/v1/models/ref"
    if sort_by:
        url += f"?sortBy={sort_by}"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "List reference models failed")
    data = response.json()
    return data if isinstance(data, list) else data.get("models", [])


def create_model(
    name: str,
    provider: str,
    hf_repo_id: str,
    model_type: str,
    encrypted_tokens: Optional[List[Dict[str, str]]] = None,
) -> Dict[str, Any]:
    """Create a user model. For private repos, pass encrypted_tokens (from encrypt_token_for_runners) or use the dashboard."""
    url = f"{_config.api_url}/api/v1/models"
    payload: Dict[str, Any] = {
        "name": name,
        "provider": provider,
        "hfRepoId": hf_repo_id,
        "type": model_type,
    }
    if encrypted_tokens:
        payload["encryptedTokens"] = encrypted_tokens
    response = requests.post(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Create model failed")
    return response.json()


def delete_model(model_id: str) -> None:
    url = f"{_config.api_url}/api/v1/models/{model_id}"
    response = requests.delete(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Delete model failed")


def list_api_keys() -> List[Dict[str, Any]]:
    url = f"{_config.api_url}/api/v1/api-keys"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "List API keys failed")
    data = response.json()
    keys = data.get("keys", data) if isinstance(data, dict) else data
    return keys if isinstance(keys, list) else []


_VALID_MODALITIES = ("t2v", "i2v", "t2i")


def list_dimensions(model_type: Optional[str] = None) -> List[Dict[str, Any]]:
    """List evaluation dimensions, optionally filtered by modality.

    Args:
        model_type: If provided, only return dimensions compatible with this
            modality. One of "t2v", "i2v", "t2i".
    """
    if model_type is not None and model_type not in _VALID_MODALITIES:
        raise ValueError(
            f"model_type must be one of {_VALID_MODALITIES}, got {model_type!r}"
        )
    url = f"{_config.api_url}/api/v1/dimensions"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "List dimensions failed")
    data = response.json()
    dimensions = data if isinstance(data, list) else []
    if model_type is None:
        return dimensions
    return [d for d in dimensions if model_type in (d.get("modalities") or [])]


def create_api_key(
    name: Optional[str] = None,
    expires_in: Optional[str] = None,
) -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/api-keys"
    payload: Dict[str, Any] = {}
    if name is not None:
        payload["name"] = name
    if expires_in is not None:
        payload["expires_in"] = expires_in
    response = requests.post(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Create API key failed")
    return response.json()


def revoke_api_key(key_id: str) -> None:
    url = f"{_config.api_url}/api/v1/api-keys/{key_id}"
    response = requests.delete(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Revoke API key failed")


def list_runners() -> List[Dict[str, Any]]:
    url = f"{_config.api_url}/api/v1/runner"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "List runners failed")
    data = response.json()
    return data if isinstance(data, list) else data.get("runners", [])


def init_runner_registration(name: Optional[str] = None) -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/runner/register/init"
    payload: Dict[str, Any] = {}
    if name is not None:
        payload["name"] = name
    response = requests.post(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Init runner registration failed")
    return response.json()


def delete_runner(runner_id: str) -> None:
    url = f"{_config.api_url}/api/v1/runner/{runner_id}"
    response = requests.delete(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Delete runner failed")


_EVAL_CONFIG_CACHE_DIR = Path.home() / ".worldjen" / "cache"
# Refuse cached fallback older than this on probe failure. Long enough to ride
# out short backend outages, short enough that a forgotten/stale cache from
# a previous environment can't quietly score runs against months-old config.
_EVAL_CONFIG_MAX_FALLBACK_AGE_SECONDS = 24 * 60 * 60


def _eval_config_cache_path() -> Path:
    """Return the cache file path for the currently-configured ``api_url``.
    The path is keyed on a hash of the URL so a user who switches between
    dev/staging/prod (or self-hosted backends) never serves cached config
    from one environment to another. Same-version-counter coincidence
    across environments would otherwise be undetectable."""
    api_url = _config.api_url or "default"
    digest = hashlib.sha256(api_url.encode("utf-8")).hexdigest()[:16]
    return _EVAL_CONFIG_CACHE_DIR / f"eval-config-{digest}.json"


def fetch_eval_config_version() -> Dict[str, Any]:
    """Cheap probe — returns ``{version, lastSeededAt}``. Used by clients to
    decide whether their cached eval config is still current."""
    url = f"{_config.api_url}/api/v1/eval-config/version"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Fetch eval config version failed")
    return response.json()


def _read_eval_config_cache() -> Optional[Dict[str, Any]]:
    try:
        with open(_eval_config_cache_path(), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


def _write_eval_config_cache(payload: Dict[str, Any]) -> None:
    try:
        path = _eval_config_cache_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        # Unique tmp name per writer prevents same-PID concurrent writers from
        # racing each other into a partial replace().
        tmp_path = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(payload, f)
            tmp_path.replace(path)
        finally:
            # Clean up if replace() failed mid-flight.
            try:
                tmp_path.unlink()
            except OSError:
                pass
    except OSError:
        # Cache write is best-effort; never fail the call because of disk.
        pass


def _is_auth_error(exc: BaseException) -> bool:
    """True for 401/403 — never fall back to cache on auth errors. The user's
    credentials are wrong; serving cached data hides the misconfiguration."""
    if isinstance(exc, ApiError) and exc.status_code in (401, 403):
        return True
    if isinstance(exc, requests.HTTPError):
        status = getattr(getattr(exc, "response", None), "status_code", None)
        if status in (401, 403):
            return True
    return False


def fetch_eval_config() -> Dict[str, Any]:
    """Get the latest eval config, using a local cache invalidated by the
    server's monotonic version counter.

    Flow:
      1. Probe ``/eval-config/version`` (single Mongo doc lookup, ~10ms).
      2. If the local cache's version matches, return cached data — no big fetch.
      3. Otherwise GET ``/eval-config/latest`` and replace the cache.

    On probe failure (transient backend issue), fall back to cached data if it
    exists AND was fetched within ``_EVAL_CONFIG_MAX_FALLBACK_AGE_SECONDS``.
    Auth failures (401/403) re-raise immediately — serving cached data on a
    bad API key just hides misconfiguration.
    """
    cached = _read_eval_config_cache()
    cached_version = cached.get("version") if isinstance(cached, dict) else None
    cached_data = cached.get("data") if isinstance(cached, dict) else None
    cached_fetched_at = cached.get("fetchedAt") if isinstance(cached, dict) else None

    try:
        probe = fetch_eval_config_version()
    except Exception as exc:
        if _is_auth_error(exc):
            raise
        if cached_data is None or not isinstance(cached_fetched_at, (int, float)):
            raise
        if (time.time() - cached_fetched_at) > _EVAL_CONFIG_MAX_FALLBACK_AGE_SECONDS:
            raise
        return cached_data

    if cached_data is not None and cached_version == probe.get("version"):
        return cached_data

    url = f"{_config.api_url}/api/v1/eval-config/latest"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Fetch eval config failed")
    data = response.json()

    _write_eval_config_cache(
        {
            "version": probe.get("version"),
            "lastSeededAt": probe.get("lastSeededAt"),
            "fetchedAt": time.time(),
            "data": data,
        }
    )
    return data


def list_projects() -> List[Dict[str, Any]]:
    url = f"{_config.api_url}/api/v1/projects"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "List projects failed")
    data = response.json()
    return data if isinstance(data, list) else data.get("projects", [])


def get_project(project_id: str) -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/projects/{project_id}"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Get project failed")
    return response.json()


def create_project(name: str) -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/projects"
    response = requests.post(
        url, json={"name": name}, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Create project failed")
    return response.json()


def get_preferences() -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/preferences"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Get preferences failed")
    return response.json()


def set_preferences(
    notifications_enabled: Optional[bool] = None,
    cache_i2v_images: Optional[bool] = None,
) -> Dict[str, Any]:
    payload: Dict[str, Any] = {}
    if notifications_enabled is not None:
        payload["notifications_enabled"] = notifications_enabled
    if cache_i2v_images is not None:
        payload["cache_i2v_images"] = cache_i2v_images
    if not payload:
        raise ValueError("set_preferences: pass at least one preference to update")
    url = f"{_config.api_url}/api/v1/preferences"
    response = requests.put(url, json=payload, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Set preferences failed")
    return response.json()


def _json_sanitize(obj: Any) -> Any:
    """Return a JSON-serializable copy of obj; non-serializable values are dropped."""
    if obj is None or isinstance(obj, (bool, int, float, str)):
        return obj
    if isinstance(obj, dict):
        out: Dict[str, Any] = {}
        for k, v in obj.items():
            if not isinstance(k, str):
                continue
            try:
                out[k] = _json_sanitize(v)
            except (TypeError, ValueError):
                continue
        return out
    if isinstance(obj, (list, tuple)):
        out_list: List[Any] = []
        for v in obj:
            try:
                out_list.append(_json_sanitize(v))
            except (TypeError, ValueError):
                continue
        return out_list
    try:
        json.dumps(obj)
        return obj
    except (TypeError, ValueError):
        raise TypeError(f"{type(obj).__name__} is not JSON serializable")
