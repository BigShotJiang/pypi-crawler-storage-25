from pathlib import Path
from typing import Any, List, Union

import imageio
import numpy as np

AnyFrame = Union[np.ndarray, Any]


def _to_uint8(frame: np.ndarray) -> np.ndarray:
    if frame.dtype == np.uint8:
        return frame
    if np.issubdtype(frame.dtype, np.floating):
        if frame.max() <= 1.0 and frame.min() >= 0.0:
            return (frame * 255).clip(0, 255).astype(np.uint8)
        if frame.min() >= -1.0 and frame.max() <= 1.0:
            return ((frame + 1) * 127.5).clip(0, 255).astype(np.uint8)
        return frame.clip(0, 255).astype(np.uint8)
    if frame.dtype == np.uint16:
        return (frame / 256).astype(np.uint8)
    return frame.clip(0, 255).astype(np.uint8)


def _normalize_frame(frame: AnyFrame) -> np.ndarray:
    frame = np.array(frame)
    while frame.ndim > 3:
        if frame.shape[0] == 1:
            frame = frame[0]
        else:
            raise ValueError(f"Cannot normalize frame with shape: {frame.shape}")
    frame = _to_uint8(frame)
    if frame.ndim == 2:
        frame = np.stack([frame, frame, frame], axis=-1)
    elif frame.ndim == 3:
        if frame.shape[2] == 1:
            frame = np.concatenate([frame, frame, frame], axis=-1)
        elif frame.shape[2] == 4:
            frame = frame[:, :, :3]
    return frame


def save_frames_as_video(
    frames: List[AnyFrame],
    output_path: Path,
    fps: int = 24,
) -> None:
    if isinstance(frames, np.ndarray) and frames.ndim == 4:
        if frames.shape[0] == 0:
            raise ValueError("No frames to save")
        frame_list = [_normalize_frame(frames[i]) for i in range(frames.shape[0])]
    else:
        if not frames:
            raise ValueError("No frames to save")
        frame_list = [_normalize_frame(f) for f in frames]
    imageio.mimsave(
        str(output_path),
        frame_list,
        fps=fps,
        codec="libx264",
        ffmpeg_params=["-pix_fmt", "yuv420p"],
    )


def save_image(image: AnyFrame, output_path: Path) -> None:
    """Save a single image (PIL Image, numpy array, or tensor) to disk as PNG."""
    try:
        from PIL import Image as PILImage
        if isinstance(image, PILImage.Image):
            image.save(str(output_path))
            return
    except ImportError:
        pass
    arr = _normalize_frame(image)
    imageio.imwrite(str(output_path), arr)
