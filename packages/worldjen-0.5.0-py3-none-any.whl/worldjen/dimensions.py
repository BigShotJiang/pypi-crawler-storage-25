"""
Evaluation dimensions exposed by the WorldJen platform.

Use the ``Dimensions`` enum to refer to dimensions by symbolic name, or the
``VIDEO_DIMENSIONS`` / ``I2V_VIDEO_DIMENSIONS`` / ``IMAGE_DIMENSIONS`` /
``BOTH_DIMENSIONS`` sets when you need to select a category at once.

The full, authoritative list with descriptions is at https://docs.worldjen.com/dimensions.
"""

from enum import Enum


class Dimensions(str, Enum):
    """Dimension IDs for evaluation. Use ALL, ALL_VIDEO, or ALL_IMAGE for bulk selection."""

    ALL = "all"
    ALL_VIDEO = "all_video"
    ALL_IMAGE = "all_image"

    # Video
    SUBJECT_CONSISTENCY = "subject_consistency"
    SCENE_CONSISTENCY = "scene_consistency"
    MOTION_SMOOTHNESS = "motion_smoothness"
    TEMPORAL_FLICKERING = "temporal_flickering"
    PHYSICAL_MECHANICS = "physical_mechanics"
    OBJECT_PERMANENCE = "object_permanence"
    HUMAN_FIDELITY = "human_fidelity"
    DYNAMIC_DEGREE = "dynamic_degree"
    SEMANTIC_ADHERENCE = "semantic_adherence"
    SPATIAL_RELATIONSHIP = "spatial_relationship"
    SEMANTIC_DRIFT = "semantic_drift"
    FIRST_FRAME_FIDELITY = "first_frame_fidelity"
    CONTEXT_EXTENDING = "context_extending"

    # Image
    AESTHETIC_QUALITY = "aesthetic_quality"
    STRUCTURAL_INTEGRITY = "structural_integrity"
    DETAIL_FIDELITY = "detail_fidelity"
    COLOR_LIGHTING = "color_lighting"
    ARTIFACT_FREEDOM = "artifact_freedom"


VIDEO_DIMENSIONS = {
    Dimensions.SUBJECT_CONSISTENCY,
    Dimensions.SCENE_CONSISTENCY,
    Dimensions.MOTION_SMOOTHNESS,
    Dimensions.TEMPORAL_FLICKERING,
    Dimensions.PHYSICAL_MECHANICS,
    Dimensions.OBJECT_PERMANENCE,
    Dimensions.DYNAMIC_DEGREE,
    Dimensions.SEMANTIC_DRIFT,
}

I2V_VIDEO_DIMENSIONS = {
    Dimensions.FIRST_FRAME_FIDELITY,
    Dimensions.CONTEXT_EXTENDING,
}

IMAGE_DIMENSIONS = {
    Dimensions.AESTHETIC_QUALITY,
    Dimensions.STRUCTURAL_INTEGRITY,
    Dimensions.DETAIL_FIDELITY,
    Dimensions.COLOR_LIGHTING,
    Dimensions.ARTIFACT_FREEDOM,
}

BOTH_DIMENSIONS = {
    Dimensions.HUMAN_FIDELITY,
    Dimensions.SEMANTIC_ADHERENCE,
    Dimensions.SPATIAL_RELATIONSHIP,
}

_META = {Dimensions.ALL, Dimensions.ALL_VIDEO, Dimensions.ALL_IMAGE}
