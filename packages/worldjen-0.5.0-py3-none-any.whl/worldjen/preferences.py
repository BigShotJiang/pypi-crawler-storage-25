"""
Public SDK for user preferences (notifications, i2v image caching, etc.).

Mirrors the dashboard's Settings → Preferences page.
"""

from typing import Any, Dict

from worldjen._api import get_preferences, set_preferences


__all__ = ["get", "set_notifications", "set_cache_i2v_images"]


def get() -> Dict[str, Any]:
    """Fetch current preferences."""
    return get_preferences()


def set_notifications(enabled: bool) -> Dict[str, Any]:
    """Enable or disable run-completion email notifications."""
    return set_preferences(notifications_enabled=enabled)


def set_cache_i2v_images(enabled: bool) -> Dict[str, Any]:
    """Opt in/out of caching i2v reference images locally on the SDK / runner
    machine at ``~/.worldjen/cache/i2v/``. A full-dimension i2v run can persist
    >1GB of images, so this is off by default. Toggle per-account; the runner
    and ``worldjen.run(...)`` read this preference as their default."""
    return set_preferences(cache_i2v_images=enabled)
