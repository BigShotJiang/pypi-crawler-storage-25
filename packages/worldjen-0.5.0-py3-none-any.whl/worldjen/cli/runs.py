"""CLI commands for worldjen runs."""
import argparse
import json
import sys
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

from worldjen.cli.common import apply_api_config
from worldjen.cli.table import print_table
from worldjen.runs import _extension_for_video, wait as wait_for_run
from worldjen._run import Progress
from worldjen._api import (
    cancel_run,
    create_run,
    delete_run,
    get_run,
    get_run_csv,
    get_run_logs,
    get_run_videos,
    list_runs,
)


def cmd_create(args: argparse.Namespace) -> None:
    apply_api_config(args)
    dimensions = [d.strip() for d in args.dimensions.split(",") if d.strip()]
    if not dimensions:
        print("Error: at least one dimension required", file=sys.stderr)
        sys.exit(1)
    runner_id = (args.runner_id or "").strip()
    model_id = (args.model_id or "").strip()
    if not runner_id or not model_id:
        print(
            "Error: --runner-id and --model-id are required.",
            file=sys.stderr,
        )
        sys.exit(1)
    run_instructions = _parse_run_instructions_arg(getattr(args, "run_instructions", None))
    reference_model_id = (getattr(args, "reference_model_id", None) or "").strip() or None
    reasoning_enabled = args.reasoning
    try:
        run_id = create_run(
            name=args.name,
            dimensions=dimensions,
            model_id=model_id,
            runner_id=runner_id,
            run_instructions=run_instructions,
            reference_model_id=reference_model_id,
            reasoning_enabled=reasoning_enabled,
        )
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    out = {
        "run_id": run_id,
        "name": args.name,
        "dimensions": dimensions,
        "runner_id": runner_id,
        "model_id": model_id,
    }
    if run_instructions is not None:
        out["run_instructions"] = run_instructions
    if reference_model_id is not None:
        out["reference_model_id"] = reference_model_id
    out["reasoning_enabled"] = reasoning_enabled
    if args.json:
        print(json.dumps(out, indent=2))
    else:
        print(f"Created run: {run_id}")


def cmd_list(args: argparse.Namespace) -> None:
    apply_api_config(args)
    data = list_runs(status=args.status, page=args.page, limit=args.limit)
    runs = data.get("runs", data) if isinstance(data, dict) else data
    if not isinstance(runs, list):
        runs = []
    if args.json:
        print(json.dumps(data, indent=2))
        return
    rows = [
        (str(r.get("_id") or r.get("id") or ""), str(r.get("name") or ""), str(r.get("status") or ""))
        for r in runs
    ]
    print_table(("RUN ID", "NAME", "STATUS"), rows, empty_msg="No runs found.", max_widths={1: 50})


def _dimension_display_name(dim_id: str) -> str:
    return dim_id.replace("_", " ").title()


def _scores_per_dimension(data: dict) -> list[tuple[str, str, str, str]]:
    videos = data.get("resultData") or {}
    videos = videos.get("videos") if isinstance(videos, dict) else []
    if not isinstance(videos, list):
        return []
    by_dim: dict[str, list[float]] = {}
    for v in videos:
        scores = v.get("scores") or {}
        if not isinstance(scores, dict):
            continue
        for dim, val in scores.items():
            if val is None:
                continue
            try:
                n = float(val)
                if not (n != n or n == float("inf") or n == float("-inf")):
                    by_dim.setdefault(dim, []).append(n)
            except (TypeError, ValueError):
                continue
    config_dims = data.get("evaluateConfig") or {}
    dim_order = config_dims.get("dimensions") if isinstance(config_dims, dict) else []
    if not isinstance(dim_order, list):
        dim_order = []
    ordered = [d for d in dim_order if d in by_dim] + [d for d in sorted(by_dim) if d not in dim_order]
    rows = []
    for dim in ordered:
        vals = by_dim[dim]
        if not vals:  # pragma: no cover — defensive; vals are always non-empty when dim is in by_dim
            continue
        worst = min(vals)
        best = max(vals)
        avg = sum(vals) / len(vals)
        rows.append(
            (
                _dimension_display_name(dim),
                f"{worst:.2f}",
                f"{avg:.2f}",
                f"{best:.2f}",
            )
        )
    return rows


def cmd_get(args: argparse.Namespace) -> None:
    apply_api_config(args)
    data = get_run(args.run_id)
    if args.json:
        print(json.dumps(data, indent=2))
        return
    run_id = data.get("_id") or data.get("id")
    print(f"Run: {run_id}")
    print(f"Name: {data.get('name')}")
    print(f"Status: {data.get('status')}")
    dims = data.get("evaluateConfig", {}).get("dimensions", [])
    print(f"Dimensions: {dims}")
    progress = data.get("progress")
    if isinstance(progress, dict):
        print()
        print(_render_progress(progress, tty=sys.stdout.isatty()))
    score_rows = _scores_per_dimension(data)
    if score_rows:
        print()
        print("Scores per dimension (worst / average / best across videos):")
        print_table(("DIMENSION", "WORST", "AVERAGE", "BEST"), score_rows)


def cmd_wait(args: argparse.Namespace) -> None:
    apply_api_config(args)

    def on_progress(progress: Progress) -> None:
        if args.json:
            return
        print(_render_progress(_progress_to_api_dict(progress), tty=sys.stdout.isatty()))

    data = wait_for_run(
        args.run_id,
        poll_interval=args.poll_interval,
        timeout=args.timeout,
        on_progress=on_progress,
    )
    if args.json:
        print(json.dumps(_json_ready(data), indent=2))
    else:
        print(f"Run {args.run_id} finished with status: {data.get('status')}")

    status = str(data.get("status") or "").lower()
    if status == "failed":
        sys.exit(1)
    if status == "cancelled":
        sys.exit(2)
    if status == "deleted":
        sys.exit(3)


def cmd_cancel(args: argparse.Namespace) -> None:
    apply_api_config(args)
    cancel_run(args.run_id)
    if not args.json:
        print(f"Cancelled run {args.run_id}")


def cmd_delete(args: argparse.Namespace) -> None:
    apply_api_config(args)
    delete_run(args.run_id)
    if not args.json:
        print(f"Deleted run {args.run_id}")


def cmd_logs(args: argparse.Namespace) -> None:
    apply_api_config(args)
    data = get_run_logs(args.run_id)
    logs = data.get("logs", "") if isinstance(data, dict) else str(data)
    print(logs or "")


def cmd_csv(args: argparse.Namespace) -> None:
    apply_api_config(args)
    content = get_run_csv(args.run_id)
    if args.output:
        Path(args.output).write_bytes(content)
        if not args.json:
            print(f"Wrote CSV to {args.output}")
    else:
        sys.stdout.buffer.write(content)


def cmd_videos(args: argparse.Namespace) -> None:
    """List video metadata (id, prompt, URL) for a run. Does not download files."""
    apply_api_config(args)
    videos = get_run_videos(args.run_id)
    if args.json:
        print(json.dumps(videos, indent=2))
        return
    if not videos:
        print("No videos found for this run.")
        return
    rows = []
    for v in videos:
        vid = str(v.get("id") or v.get("_id") or "")
        prompt = str(v.get("prompt") or "")
        url = str(v.get("url") or v.get("s3Key") or "")
        rows.append((vid, prompt, url))
    print_table(
        ("VIDEO ID", "PROMPT", "URL"),
        rows,
        empty_msg="No videos found for this run.",
        max_widths={1: 50, 2: 60},
    )


def cmd_download_videos(args: argparse.Namespace) -> None:
    """Fetch video list for the run and download each video file to disk (--output-dir)."""
    apply_api_config(args)
    import requests
    videos = get_run_videos(args.run_id)
    out_dir = Path(args.output_dir or ".").resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    for i, v in enumerate(videos):
        url = v.get("url")
        if not url:
            continue
        vid = v.get("id") or v.get("_id") or str(i)
        ext = _extension_for_video(v, url)
        path = out_dir / f"{vid}{ext}"
        try:
            r = requests.get(url, timeout=300)
            r.raise_for_status()
            path.write_bytes(r.content)
            print(f"Saved {path.name}")
        except Exception as e:
            print(f"Error downloading {vid}: {e}", file=sys.stderr)
    if not args.json:
        print(f"Downloaded to {out_dir}")


def add_parser(subparsers: argparse._SubParsersAction) -> None:
    parser = subparsers.add_parser("runs", help="Manage runs")
    runs_sub = parser.add_subparsers(dest="runs_command", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--api-key", help="API key (default: WORLDJEN_API_KEY)")
    common.add_argument("--api-url", help=argparse.SUPPRESS)
    common.add_argument("--json", action="store_true", help="Output JSON")

    p_create = runs_sub.add_parser(
        "create",
        parents=[common],
        help="Create a run on a worker queue (same as the web UI)",
        description=(
            "Create a run and enqueue it for the given runner and model. "
            "Requires --runner-id and --model-id (MongoDB ids from the dashboard). "
            "For local pipeline execution without a worker, use: worldjen.run() in Python."
        ),
    )
    p_create.add_argument("--name", required=True, help="Run display name")
    p_create.add_argument("--dimensions", required=True, help="Comma-separated dimension ids")
    p_create.add_argument(
        "--runner-id",
        required=True,
        help="Runner id (from worldjen runner list or the dashboard)",
    )
    p_create.add_argument(
        "--model-id",
        required=True,
        help="Model id (from worldjen models list or the dashboard)",
    )
    p_create.add_argument(
        "--run-instructions",
        metavar="JSON_OR_PATH",
        help="Optional JSON object or path to a .json file (runner pipeline kwargs)",
    )
    p_create.add_argument(
        "--reference-model-id",
        help="Optional reference model id to compare against (dashboard's compare flow)",
    )
    p_create.add_argument(
        "--reasoning",
        action="store_true",
        help="Enable per-question evaluator reasoning and generated summaries for this run",
    )
    p_create.set_defaults(_run=cmd_create)

    p_list = runs_sub.add_parser("list", parents=[common])
    p_list.add_argument("--status")
    p_list.add_argument("--page", type=int, default=1)
    p_list.add_argument("--limit", type=int, default=50)
    p_list.set_defaults(_run=cmd_list)

    p_get = runs_sub.add_parser("get", parents=[common])
    p_get.add_argument("run_id")
    p_get.set_defaults(_run=cmd_get)

    p_wait = runs_sub.add_parser("wait", parents=[common])
    p_wait.add_argument("run_id")
    p_wait.add_argument("--poll-interval", type=float, default=2.0)
    p_wait.add_argument("--timeout", type=float, default=None)
    p_wait.set_defaults(_run=cmd_wait)

    p_cancel = runs_sub.add_parser("cancel", parents=[common])
    p_cancel.add_argument("run_id")
    p_cancel.set_defaults(_run=cmd_cancel)

    p_delete = runs_sub.add_parser("delete", parents=[common])
    p_delete.add_argument("run_id")
    p_delete.set_defaults(_run=cmd_delete)

    p_logs = runs_sub.add_parser("logs", parents=[common])
    p_logs.add_argument("run_id")
    p_logs.set_defaults(_run=cmd_logs)

    p_csv = runs_sub.add_parser("csv", parents=[common])
    p_csv.add_argument("run_id")
    p_csv.add_argument("--output", "-o", help="Write CSV to file")
    p_csv.set_defaults(_run=cmd_csv)

    p_videos = runs_sub.add_parser("videos", parents=[common])
    p_videos.add_argument("run_id")
    p_videos.set_defaults(_run=cmd_videos)

    p_dl = runs_sub.add_parser("download-videos", parents=[common])
    p_dl.add_argument("run_id")
    p_dl.add_argument("--output-dir", "-o", default=".", help="Directory to save videos")
    p_dl.set_defaults(_run=cmd_download_videos)


def _parse_run_instructions_arg(raw: str | None) -> dict[str, Any] | None:
    if raw is None:
        return None
    s = raw.strip()
    if not s:
        return None
    try:
        parsed: Any = json.loads(s)
    except json.JSONDecodeError:
        p = Path(s)
        if not p.is_file():
            print(
                "Error: --run-instructions must be valid JSON or a path to a JSON file",
                file=sys.stderr,
            )
            sys.exit(1)
        try:
            parsed = json.loads(p.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            print(f"Error: invalid JSON in {p}: {e}", file=sys.stderr)
            sys.exit(1)
    if not isinstance(parsed, dict):
        print("Error: run_instructions must be a JSON object", file=sys.stderr)
        sys.exit(1)
    return parsed


def _render_progress(progress: dict[str, Any], *, tty: bool) -> str:
    total = _to_int(progress.get("videosTotal"))
    evaluated = _to_int(progress.get("videosEvaluated"))
    pending = max(0, total - evaluated)
    lines = [f"Progress: {evaluated} / {total} evaluated ({pending} pending)"]
    if tty:
        lines.append(_bar(evaluated, total, width=28))
    per_dimension = progress.get("perDimension") or {}
    if isinstance(per_dimension, dict) and per_dimension:
        rows = []
        for dimension_id, item in per_dimension.items():
            if not isinstance(item, dict):
                continue
            dimension_total = _to_int(item.get("total", evaluated))
            row = [
                _dimension_display_name(str(dimension_id)),
                f"{_to_int(item.get('evaluated'))}/{dimension_total}",
                str(_to_int(item.get("failed"))),
            ]
            if tty:
                row.append(
                    _bar(
                        _to_int(item.get("evaluated")) + _to_int(item.get("failed")),
                        dimension_total,
                        width=16,
                    )
                )
            rows.append(tuple(row))
        if rows:
            lines.append("")
            lines.append("Dimension progress:")
            headers = (
                ("DIMENSION", "EVAL/TOTAL", "FAIL", "PROGRESS")
                if tty
                else ("DIMENSION", "EVAL/TOTAL", "FAIL")
            )
            rendered = _table_to_string(headers, rows)
            lines.append(rendered)
    return "\n".join(lines)


def _bar(value: int, total: int, *, width: int) -> str:
    if total <= 0:
        filled = 0
    else:
        filled = max(0, min(width, round((value / total) * width)))
    return "[" + "#" * filled + "-" * (width - filled) + "]"


def _table_to_string(headers: tuple[str, ...], rows: list[tuple[str, ...]]) -> str:
    widths = [len(h) for h in headers]
    for row in rows:
        for index, value in enumerate(row):
            widths[index] = max(widths[index], len(value))
    lines = ["  ".join(h.ljust(widths[index]) for index, h in enumerate(headers))]
    lines.extend("  ".join(value.ljust(widths[index]) for index, value in enumerate(row)) for row in rows)
    return "\n".join(lines)


def _progress_to_api_dict(progress: Progress) -> dict[str, Any]:
    return {
        "videosTotal": progress.videos_total,
        "videosEvaluated": progress.videos_evaluated,
        "perDimension": {
            key: {"evaluated": value.evaluated, "failed": value.failed, "total": value.total}
            for key, value in progress.per_dimension.items()
        },
        "updatedAt": progress.updated_at,
    }


def _json_ready(value: Any) -> Any:
    if isinstance(value, Progress):
        return _progress_to_api_dict(value)
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, dict):
        return {key: _json_ready(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_json_ready(item) for item in value]
    return value


def _to_int(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0
