"""CLI commands for worldjen runner (create, register, install, start, stop, etc.)."""
import argparse
import json
import os
import sys
from pathlib import Path

from worldjen._config import _config as _state
from worldjen._api import delete_runner, init_runner_registration, list_runners, list_runs
from worldjen.cli.common import apply_api_config
from worldjen.cli.table import print_table
from worldjen.runner.config.runner_config import RunnerConfig


def cmd_create(args: argparse.Namespace) -> None:
    apply_api_config(args)
    instance_name = args.name
    display_name = getattr(args, "display_name", None) or instance_name
    data = init_runner_registration(name=display_name)
    token = data.get("runner_token") or data.get("token")
    if not token:
        print("Error: Init registration did not return a runner token", file=sys.stderr)
        sys.exit(1)
    api_url = _state.api_url
    if args.data_dir:
        pass
    # Lazy import: svc imports systemd; defer until runner command actually runs
    from worldjen.runner.register import register_runner
    from worldjen.runner.svc import install as svc_install, start as svc_start

    print(f"Registering runner '{instance_name}'...")
    register_runner(runner_token=token, api_url=api_url, instance_name=instance_name)
    print("Installing systemd service...")
    svc_install(instance_name=instance_name, loglevel=args.loglevel or "info", working_dir=args.data_dir)
    print("Starting service...")
    svc_start(instance_name=instance_name)
    if not args.json:
        print(f"Runner '{instance_name}' created, registered, installed, and started.")


def cmd_delete(args: argparse.Namespace) -> None:
    apply_api_config(args)
    instance_name = args.name
    runner_id = getattr(args, "runner_id", None) or _get_runner_id_from_config(instance_name)
    if not runner_id:
        print(f"Error: No runner config found for '{instance_name}'. Specify --runner-id or register first.", file=sys.stderr)
        sys.exit(1)
    try:
        runs_data = list_runs(status="pending", limit=1000)
        runs = runs_data.get("runs", runs_data) if isinstance(runs_data, dict) else runs_data
        if isinstance(runs, list):
            for r in runs:
                if r.get("runnerId") == runner_id or r.get("runner_id") == runner_id:
                    print("Error: Runner has queued (pending) runs. Cancel them first, then retry delete.", file=sys.stderr)
                    sys.exit(1)
    except Exception:
        pass
    # Lazy import: svc imports systemd; defer until runner command actually runs
    from worldjen.runner.svc import stop as svc_stop, uninstall as svc_uninstall

    try:
        svc_stop(instance_name=instance_name)
    except Exception:
        pass
    try:
        svc_uninstall(instance_name=instance_name)
    except Exception:
        pass
    delete_runner(runner_id)
    # Remove local config so a subsequent create/register can succeed
    runner_cfg = RunnerConfig(instance_name)
    cfg_path = runner_cfg.get_config_path()
    key_path = runner_cfg.get_private_key_path()
    for p in (cfg_path, key_path):
        if p.exists():
            try:
                p.unlink()
            except OSError:
                pass
    if not args.json:
        print(f"Deleted runner '{instance_name}' ({runner_id})")


def cmd_register(args: argparse.Namespace) -> None:
    # Lazy import: svc imports systemd; defer until runner command actually runs
    from worldjen.runner.register import register_runner
    from worldjen.runner.svc import install as svc_install, start as svc_start

    token = args.token
    instance_name = args.name
    if not token:
        print("Error: --token required for register", file=sys.stderr)
        sys.exit(1)
    api_url = args.api_url or os.environ.get("WORLDJEN_API_URL") or RunnerConfig(instance_name).get_api_url()
    if args.data_dir:
        pass
    register_runner(runner_token=token, api_url=api_url, instance_name=instance_name)
    print("Installing systemd service...")
    svc_install(instance_name=instance_name, loglevel=args.loglevel or "info", working_dir=args.data_dir)
    print("Starting service...")
    svc_start(instance_name=instance_name)
    if not args.json:
        print(f"Runner '{instance_name}' registered, installed, and started.")


def cmd_install(args: argparse.Namespace) -> None:
    # Lazy import: svc imports systemd; defer until runner command actually runs
    from worldjen.runner.svc import install as svc_install, start as svc_start

    instance_name = args.name
    svc_install(instance_name=instance_name, loglevel=args.loglevel or "info", working_dir=args.data_dir)
    print("Starting service...")
    svc_start(instance_name=instance_name)
    if not args.json:
        print(f"Runner '{instance_name}' service installed and started.")


def cmd_uninstall(args: argparse.Namespace) -> None:
    # Lazy import: svc imports systemd; defer until runner command actually runs
    from worldjen.runner.svc import stop as svc_stop, uninstall as svc_uninstall

    instance_name = args.name
    svc_stop(instance_name=instance_name)
    svc_uninstall(instance_name=instance_name)
    if not args.json:
        print(f"Runner '{instance_name}' service uninstalled.")


def cmd_start(args: argparse.Namespace) -> None:
    # Lazy import: svc imports systemd; defer until runner command actually runs
    from worldjen.runner.svc import start as svc_start

    svc_start(instance_name=args.name)


def cmd_stop(args: argparse.Namespace) -> None:
    # Lazy import: svc imports systemd; defer until runner command actually runs
    from worldjen.runner.svc import stop as svc_stop

    svc_stop(instance_name=args.name)


def cmd_status(args: argparse.Namespace) -> None:
    # Lazy import: svc imports systemd; defer until runner command actually runs
    from worldjen.runner.svc import status as svc_status

    svc_status(instance_name=args.name)


def cmd_logs(args: argparse.Namespace) -> None:
    # Lazy import: svc imports systemd; defer until runner command actually runs
    from worldjen.runner.svc import logs as svc_logs

    svc_logs(instance_name=args.name, follow=args.follow, lines=args.lines or 50)


def cmd_list(args: argparse.Namespace) -> None:
    if args.local:
        instances = RunnerConfig.list_instances()
        if args.json:
            print(json.dumps(instances, indent=2))
            return
        if not instances:
            print("No local runner instances found.")
            return
        rows = [(name,) for name in instances]
        print_table(("INSTANCE",), rows)
        return
    apply_api_config(args)
    runners = list_runners()
    if args.json:
        print(json.dumps(runners, indent=2))
        return
    rows = [
        (
            str(r.get("_id") or r.get("id") or ""),
            str(r.get("name") or ""),
            str(r.get("status") or ""),
            _runner_availability(r),
            str(r.get("lastHeartbeatAt") or ""),
        )
        for r in runners
    ]
    print_table(
        ("RUNNER ID", "NAME", "STATUS", "AVAILABLE", "LAST HEARTBEAT"),
        rows,
        empty_msg="No runners found.",
    )


def validate_runner_name(name: str) -> str:
    if not RunnerConfig.validate_instance_name(name):
        raise argparse.ArgumentTypeError(
            f"Invalid runner name '{name}'. Use alphanumeric, hyphens, underscores. "
            "Max 64 chars. Must start with alphanumeric."
        )
    return name


def _runner_availability(runner: dict) -> str:
    status = str(runner.get("status") or "").lower()
    is_online = bool(runner.get("isOnline")) or status == "online"
    if status in {"registered", "online"}:
        return "yes" if is_online else "no"
    return "no"


def _get_runner_id_from_config(instance_name: str = "default") -> str | None:
    runner_cfg = RunnerConfig(instance_name)
    cfg_path = runner_cfg.get_config_path()
    if not cfg_path.exists():
        return None
    from configparser import ConfigParser

    cp = ConfigParser()
    cp.read(cfg_path)
    return cp.get("runner", "runner_id", fallback=None)


def add_parser(subparsers: argparse._SubParsersAction) -> None:
    parser = subparsers.add_parser(
        "runner",
        help="Manage runners. Backend: create/delete/list resources. Local: register, install, start, stop, logs (this machine).",
    )
    sub = parser.add_subparsers(dest="runner_command", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--api-key", help="API key (default: WORLDJEN_API_KEY)")
    common.add_argument("--api-url", help=argparse.SUPPRESS)
    common.add_argument("--json", action="store_true")
    common.add_argument("--name", type=validate_runner_name, default="default",
                        help="Runner instance name (default: 'default')")
    install_opts = argparse.ArgumentParser(add_help=False)
    install_opts.add_argument("--data-dir", help="Data directory for videos (optional)")
    install_opts.add_argument("--loglevel", default="info")

    p_create = sub.add_parser(
        "create",
        parents=[common, install_opts],
        help="(Backend + local) Create runner in API, register this machine, install and start systemd service.",
    )
    p_create.add_argument("--display-name", help="Human-friendly name for the backend (default: same as --name)")
    p_create.set_defaults(_run=cmd_create)

    p_delete = sub.add_parser(
        "delete",
        parents=[common],
        help="(Backend + local) Delete runner from API; stop and uninstall local service; remove config.",
    )
    p_delete.add_argument("--runner-id", help="Runner ID (default: from local config)")
    p_delete.set_defaults(_run=cmd_delete)

    p_register = sub.add_parser(
        "register",
        parents=[common, install_opts],
        help="(Local) Register this machine with a token from the web UI; writes config, optionally installs and starts service.",
    )
    p_register.add_argument("--token", required=True, help="Registration token from web UI")
    p_register.set_defaults(_run=cmd_register)

    p_install = sub.add_parser(
        "install",
        parents=[common, install_opts],
        help="(Local) Install systemd service (requires existing config from register).",
    )
    p_install.set_defaults(_run=cmd_install)

    p_uninstall = sub.add_parser(
        "uninstall",
        parents=[common],
        help="(Local) Stop and uninstall systemd service.",
    )
    p_uninstall.set_defaults(_run=cmd_uninstall)

    p_start = sub.add_parser(
        "start",
        parents=[common],
        help="(Local) Start the installed systemd service.",
    )
    p_start.set_defaults(_run=cmd_start)

    p_stop = sub.add_parser(
        "stop",
        parents=[common],
        help="(Local) Stop the systemd service.",
    )
    p_stop.set_defaults(_run=cmd_stop)

    p_status = sub.add_parser(
        "status",
        parents=[common],
        help="(Local) Show systemd status for the worldjen-runner service.",
    )
    p_status.set_defaults(_run=cmd_status)

    p_logs = sub.add_parser(
        "logs",
        parents=[common],
        help="(Local) Tail logs of the systemd service.",
    )
    p_logs.add_argument("--follow", "-f", action="store_true")
    p_logs.add_argument("--lines", "-n", type=int, default=50)
    p_logs.set_defaults(_run=cmd_logs)

    p_list = sub.add_parser(
        "list",
        parents=[common],
        help="(Backend) List runners for your account. Use --local for local instances.",
    )
    p_list.add_argument("--local", action="store_true", help="List local runner instances instead of backend runners")
    p_list.set_defaults(_run=cmd_list)
