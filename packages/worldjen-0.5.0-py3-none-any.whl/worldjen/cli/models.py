"""CLI commands for worldjen models."""
import argparse
import json
import os
import sys

from worldjen.cli.common import apply_api_config
from worldjen.cli.table import print_table
from worldjen.hf_token import encrypt_token_for_runners
from worldjen._api import (
    create_model,
    delete_model,
    list_base_models,
    list_ref_models,
    list_runners,
    list_user_models,
)


def cmd_list(args: argparse.Namespace) -> None:
    apply_api_config(args)
    models = list_user_models(sort_by=args.sort_by)
    if args.json:
        print(json.dumps(models, indent=2))
        return
    rows = [(str(m.get("_id") or m.get("id") or ""), str(m.get("name") or "")) for m in models]
    print_table(("MODEL ID", "NAME"), rows, empty_msg="No models found.")


def cmd_list_base(args: argparse.Namespace) -> None:
    apply_api_config(args)
    models = list_base_models(sort_by=args.sort_by)
    if args.json:
        print(json.dumps(models, indent=2))
        return
    rows = [(str(m.get("_id") or m.get("id") or ""), str(m.get("name") or "")) for m in models]
    print_table(("MODEL ID", "NAME"), rows, empty_msg="No base models found.")


def cmd_list_ref(args: argparse.Namespace) -> None:
    apply_api_config(args)
    models = list_ref_models(sort_by=args.sort_by)
    if args.json:
        print(json.dumps(models, indent=2))
        return
    rows = [(str(m.get("_id") or m.get("id") or ""), str(m.get("name") or "")) for m in models]
    print_table(("MODEL ID", "NAME"), rows, empty_msg="No reference models found.")


def cmd_create(args: argparse.Namespace) -> None:
    apply_api_config(args)
    encrypted_tokens = None
    hf_token = getattr(args, "hf_token", None) or os.environ.get("WORLDJEN_HF_TOKEN")
    if hf_token:
        runners = list_runners()
        encrypted_tokens = encrypt_token_for_runners(hf_token, runners)
        if not encrypted_tokens:
            print(
                "Warning: No registered runners with public keys; private repo access may fail. "
                "Register a runner first or add the token in the dashboard.",
                file=sys.stderr,
            )
    data = create_model(
        name=args.name,
        provider=args.provider,
        hf_repo_id=args.hf_repo_id,
        model_type=args.type,
        encrypted_tokens=encrypted_tokens,
    )
    if args.json:
        print(json.dumps(data, indent=2))
        return
    mid = data.get("_id") or data.get("id", "")
    print(f"Created model: {mid}")


def cmd_delete(args: argparse.Namespace) -> None:
    apply_api_config(args)
    delete_model(args.model_id)
    if not args.json:
        print(f"Deleted model {args.model_id}")


def add_parser(subparsers: argparse._SubParsersAction) -> None:
    parser = subparsers.add_parser("models", help="Manage models")
    sub = parser.add_subparsers(dest="models_command", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--api-key", help="API key (default: WORLDJEN_API_KEY)")
    common.add_argument("--api-url", help=argparse.SUPPRESS)
    common.add_argument("--json", action="store_true")

    p_list = sub.add_parser("list", parents=[common])
    p_list.add_argument("--sort-by")
    p_list.set_defaults(_run=cmd_list)

    p_list_base = sub.add_parser("list-base", parents=[common])
    p_list_base.add_argument("--sort-by")
    p_list_base.set_defaults(_run=cmd_list_base)

    p_list_ref = sub.add_parser("list-ref", parents=[common])
    p_list_ref.add_argument("--sort-by")
    p_list_ref.set_defaults(_run=cmd_list_ref)

    p_create = sub.add_parser("create", parents=[common])
    p_create.add_argument("--name", required=True)
    p_create.add_argument("--provider", required=True)
    p_create.add_argument("--hf-repo-id", required=True)
    p_create.add_argument(
        "--type",
        required=True,
        choices=["text_to_video", "image_to_video", "text_to_image"],
    )
    p_create.add_argument(
        "--hf-token",
        dest="hf_token",
        metavar="TOKEN",
        help="Hugging Face access token for private repos; encrypted per runner. Or set WORLDJEN_HF_TOKEN.",
    )
    p_create.set_defaults(_run=cmd_create)

    p_delete = sub.add_parser("delete", parents=[common])
    p_delete.add_argument("model_id")
    p_delete.set_defaults(_run=cmd_delete)
