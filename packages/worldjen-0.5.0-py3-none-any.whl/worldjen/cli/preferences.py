"""CLI commands for worldjen user preferences."""
import argparse
import json

from worldjen.cli.common import apply_api_config
from worldjen._api import get_preferences, set_preferences


_BOOL_TRUE = {"true", "1", "yes", "on"}


def _parse_bool(value: str) -> bool:
    return value.lower() in _BOOL_TRUE


def cmd_get(args: argparse.Namespace) -> None:
    apply_api_config(args)
    prefs = get_preferences()
    if args.json:
        print(json.dumps(prefs, indent=2))
        return
    print(f"notifications_enabled: {prefs.get('notificationsEnabled')}")
    print(f"cache_i2v_images: {prefs.get('cacheI2vImages')}")


def cmd_set_notifications(args: argparse.Namespace) -> None:
    apply_api_config(args)
    prefs = set_preferences(notifications_enabled=_parse_bool(args.value))
    if args.json:
        print(json.dumps(prefs, indent=2))
        return
    print(f"notifications_enabled: {prefs.get('notificationsEnabled')}")


def cmd_set_cache_images(args: argparse.Namespace) -> None:
    apply_api_config(args)
    prefs = set_preferences(cache_i2v_images=_parse_bool(args.value))
    if args.json:
        print(json.dumps(prefs, indent=2))
        return
    print(f"cache_i2v_images: {prefs.get('cacheI2vImages')}")


def add_parser(subparsers: argparse._SubParsersAction) -> None:
    parser = subparsers.add_parser("preferences", help="Manage user preferences")
    sub = parser.add_subparsers(dest="preferences_command", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--api-key", help="API key (default: WORLDJEN_API_KEY)")
    common.add_argument("--api-url", help=argparse.SUPPRESS)
    common.add_argument("--json", action="store_true")

    p_get = sub.add_parser("get", parents=[common], help="Show current preferences")
    p_get.set_defaults(_run=cmd_get)

    p_set_notif = sub.add_parser(
        "set-notifications",
        parents=[common],
        help="Enable or disable run-completion email notifications",
    )
    p_set_notif.add_argument(
        "value", choices=["true", "false", "on", "off", "1", "0", "yes", "no"]
    )
    p_set_notif.set_defaults(_run=cmd_set_notifications)

    p_set_cache = sub.add_parser(
        "set-cache-i2v-images",
        parents=[common],
        help=(
            "Opt in/out of caching i2v reference images locally at "
            "~/.worldjen/cache/i2v/. A full-dimension run can persist >1GB. "
            "Off by default."
        ),
    )
    p_set_cache.add_argument(
        "value", choices=["true", "false", "on", "off", "1", "0", "yes", "no"]
    )
    p_set_cache.set_defaults(_run=cmd_set_cache_images)
