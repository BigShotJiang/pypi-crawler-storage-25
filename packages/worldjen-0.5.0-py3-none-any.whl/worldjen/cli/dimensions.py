"""CLI commands for worldjen dimensions."""
import argparse
import json
from worldjen.cli.common import apply_api_config
from worldjen.cli.table import print_table
from worldjen._api import list_dimensions

MODALITY_CHOICES = ("t2v", "i2v", "t2i")


def cmd_list(args: argparse.Namespace) -> None:
    apply_api_config(args)
    dimensions = list_dimensions(model_type=args.model_type)

    if args.json:
        print(json.dumps(dimensions, indent=2))
        return

    rows = [
        (
            str(d.get("id") or ""),
            str(d.get("name") or ""),
            ",".join(d.get("modalities") or []),
            str(d.get("description") or ""),
        )
        for d in dimensions
    ]
    print_table(
        ("ID", "NAME", "MODALITIES", "DESCRIPTION"),
        rows,
        empty_msg="No dimensions found.",
        max_widths={3: 60},
    )


def add_parser(subparsers: argparse._SubParsersAction) -> None:
    parser = subparsers.add_parser("dimensions", help="List available evaluation dimensions")
    dim_sub = parser.add_subparsers(dest="dimensions_command", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--api-key", help="API key (default: WORLDJEN_API_KEY)")
    common.add_argument("--api-url", help=argparse.SUPPRESS)
    common.add_argument("--json", action="store_true", help="Output JSON")

    p_list = dim_sub.add_parser("list", parents=[common], help="List all available dimensions")
    p_list.add_argument(
        "--model-type",
        choices=MODALITY_CHOICES,
        help="Filter by modality (t2v=text-to-video, i2v=image-to-video, t2i=text-to-image)",
    )
    p_list.set_defaults(_run=cmd_list)
