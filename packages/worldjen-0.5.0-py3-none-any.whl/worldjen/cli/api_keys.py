"""CLI commands for worldjen API keys (list only; create and revoke are dashboard-only)."""
import argparse
import json
import sys

from worldjen.cli.common import apply_api_config
from worldjen.cli.table import print_table
from worldjen._api import list_api_keys


_DASHBOARD_ONLY_MESSAGE = (
    "API key {action} is dashboard-only for security reasons. "
    "Visit your WorldJen dashboard at Settings -> API Keys to {action} keys."
)


def cmd_list(args: argparse.Namespace) -> None:
    apply_api_config(args)
    keys = list_api_keys()
    if args.json:
        print(json.dumps(keys, indent=2))
        return
    rows = [
        (str(k.get("id") or ""), str(k.get("key_suffix") or k.get("keySuffix") or ""), str(k.get("name") or ""))
        for k in keys
    ]
    print_table(("ID", "SUFFIX", "NAME"), rows, empty_msg="No API keys found.")


def cmd_create(_args: argparse.Namespace) -> None:
    print(_DASHBOARD_ONLY_MESSAGE.format(action="create"), file=sys.stderr)
    sys.exit(2)


def cmd_revoke(_args: argparse.Namespace) -> None:
    print(_DASHBOARD_ONLY_MESSAGE.format(action="revoke"), file=sys.stderr)
    sys.exit(2)


def add_parser(subparsers: argparse._SubParsersAction) -> None:
    parser = subparsers.add_parser("api-keys", help="Manage API keys")
    sub = parser.add_subparsers(dest="api_keys_command", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--api-key", help="API key (default: WORLDJEN_API_KEY)")
    common.add_argument("--api-url", help=argparse.SUPPRESS)
    common.add_argument("--json", action="store_true")

    p_list = sub.add_parser("list", parents=[common])
    p_list.set_defaults(_run=cmd_list)

    p_create = sub.add_parser(
        "create",
        parents=[common],
        help="Create an API key (dashboard-only)",
        description=_DASHBOARD_ONLY_MESSAGE.format(action="create"),
    )
    p_create.set_defaults(_run=cmd_create)

    p_revoke = sub.add_parser(
        "revoke",
        parents=[common],
        help="Revoke an API key (dashboard-only)",
        description=_DASHBOARD_ONLY_MESSAGE.format(action="revoke"),
    )
    p_revoke.add_argument("key_id", nargs="?")
    p_revoke.set_defaults(_run=cmd_revoke)
