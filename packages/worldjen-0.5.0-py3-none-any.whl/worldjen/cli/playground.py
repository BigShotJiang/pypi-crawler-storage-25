"""CLI commands for the Playground and Rank sandbox runs."""
import argparse
import json

from worldjen.cli.common import apply_api_config
from worldjen._api import get_or_create_playground_run, reset_playground_run


def cmd_get(args: argparse.Namespace) -> None:
    apply_api_config(args)
    run = get_or_create_playground_run(args.kind)
    if args.json:
        print(json.dumps(run, indent=2))
        return
    run_id = run.get("_id") or run.get("id") or ""
    print(f"{args.kind} run id: {run_id}")
    print(f"name: {run.get('name')}")
    print(f"status: {run.get('status')}")


def cmd_reset(args: argparse.Namespace) -> None:
    apply_api_config(args)
    run = reset_playground_run(args.kind)
    if args.json:
        print(json.dumps(run, indent=2))
        return
    run_id = run.get("_id") or run.get("id") or ""
    print(f"Reset {args.kind} run {run_id}")


def add_parser(subparsers: argparse._SubParsersAction) -> None:
    parser = subparsers.add_parser(
        "playground",
        help="Manage Playground and Rank sandbox runs",
        description=(
            "Playground and Rank are per-user sandbox runs the dashboard uses for "
            "ad-hoc custom-prompt evaluations. Use --kind rank to target the Rank "
            "sandbox; default is playground."
        ),
    )
    sub = parser.add_subparsers(dest="playground_command", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--api-key", help="API key (default: WORLDJEN_API_KEY)")
    common.add_argument("--api-url", help=argparse.SUPPRESS)
    common.add_argument("--json", action="store_true", help="Output JSON")
    common.add_argument(
        "--kind",
        choices=["playground", "rank"],
        default="playground",
        help="Which sandbox run to target (default: playground)",
    )

    p_get = sub.add_parser(
        "get",
        parents=[common],
        help="Get (or lazily create) the active sandbox run",
    )
    p_get.set_defaults(_run=cmd_get)

    p_reset = sub.add_parser(
        "reset",
        parents=[common],
        help="Clear all videos from the active sandbox run (keeps the run id)",
    )
    p_reset.set_defaults(_run=cmd_reset)
