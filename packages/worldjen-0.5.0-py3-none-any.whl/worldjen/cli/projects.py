"""CLI commands for worldjen projects."""
import argparse
import json

from worldjen.cli.common import apply_api_config
from worldjen.cli.table import print_table
from worldjen._api import create_project, get_project, list_projects


def cmd_list(args: argparse.Namespace) -> None:
    apply_api_config(args)
    projects = list_projects()
    if args.json:
        print(json.dumps(projects, indent=2))
        return
    rows = [
        (
            str(p.get("_id") or p.get("id") or ""),
            str(p.get("name") or ""),
        )
        for p in projects
    ]
    print_table(("ID", "NAME"), rows, empty_msg="No projects found.")


def cmd_get(args: argparse.Namespace) -> None:
    apply_api_config(args)
    project = get_project(args.project_id)
    print(json.dumps(project, indent=2))


def cmd_create(args: argparse.Namespace) -> None:
    apply_api_config(args)
    project = create_project(args.name)
    if args.json:
        print(json.dumps(project, indent=2))
        return
    print(f"Created project {project.get('_id') or project.get('id')}: {project.get('name')}")


def add_parser(subparsers: argparse._SubParsersAction) -> None:
    parser = subparsers.add_parser("projects", help="Manage projects")
    sub = parser.add_subparsers(dest="projects_command", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--api-key", help="API key (default: WORLDJEN_API_KEY)")
    common.add_argument("--api-url", help=argparse.SUPPRESS)
    common.add_argument("--json", action="store_true")

    p_list = sub.add_parser("list", parents=[common], help="List your projects")
    p_list.set_defaults(_run=cmd_list)

    p_get = sub.add_parser("get", parents=[common], help="Get a project by ID")
    p_get.add_argument("project_id")
    p_get.set_defaults(_run=cmd_get)

    p_create = sub.add_parser("create", parents=[common], help="Create a new project")
    p_create.add_argument("name")
    p_create.set_defaults(_run=cmd_create)
