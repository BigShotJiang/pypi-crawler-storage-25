"""
WorldJen Python SDK — programmatic access to the WorldJen evaluation platform.

Quick start::

    import worldjen

    worldjen.config(api_key="wj_...")
    result = worldjen.run(
        my_pipeline,
        dimensions=[worldjen.Dimensions.SUBJECT_CONSISTENCY],
        run_name="my-eval",
    )

Submodules wrap dedicated REST resources: ``runs``, ``models``, ``api_keys``,
``projects``, ``preferences``. Use ``worldjen.run(...)`` for end-to-end pipeline
execution; use ``worldjen.runs.create(...)`` to enqueue runs on a runner.

Set the ``WORLDJEN_API_KEY`` environment variable or call ``config(api_key=...)``
before any authenticated call. See https://docs.worldjen.com/sdk-cli for full reference.
"""

from importlib.metadata import PackageNotFoundError, version

from worldjen._config import config
from worldjen import api_keys, models, playground, preferences, projects, runners, runs
from worldjen._api import list_dimensions
from worldjen._run import DimensionProgress, Progress, run, RunResult
from worldjen.dimensions import (
    BOTH_DIMENSIONS,
    Dimensions,
    I2V_VIDEO_DIMENSIONS,
    IMAGE_DIMENSIONS,
    VIDEO_DIMENSIONS,
)

try:
    __version__ = version("worldjen")
except PackageNotFoundError:
    __version__ = "unknown"

__all__ = [
    "api_keys",
    "BOTH_DIMENSIONS",
    "config",
    "Dimensions",
    "I2V_VIDEO_DIMENSIONS",
    "IMAGE_DIMENSIONS",
    "list_dimensions",
    "models",
    "playground",
    "preferences",
    "projects",
    "Progress",
    "DimensionProgress",
    "run",
    "RunResult",
    "runners",
    "runs",
    "VIDEO_DIMENSIONS",
    "__version__",
]
