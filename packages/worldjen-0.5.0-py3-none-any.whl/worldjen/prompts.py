import io
import os
import re
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Iterable, List

import requests
from PIL import Image

from worldjen._config import _config

_I2V_CACHE_DIR = Path.home() / ".worldjen" / "cache" / "i2v"
_I2V_PATH_TOKEN_RE = re.compile(r"[A-Za-z0-9._-]+")


def _validate_i2v_path_token(token: str, label: str = "filename") -> str:
    """Validate a single path component (no slashes, no parent-traversal). Used
    for both the dimension prefix AND the filename inside ``s3Key``. A hostile
    server response could otherwise write arbitrary bytes to arbitrary user-
    writable paths under the cache root."""
    if not isinstance(token, str) or not _I2V_PATH_TOKEN_RE.fullmatch(token):
        raise ValueError(f"Invalid image {label} in metadata: {token!r}")
    if ".." in token or "/" in token or "\\" in token:
        raise ValueError(f"Invalid image {label} in metadata: {token!r}")
    return token


# Back-compat alias — old code (and tests) called this _validate_i2v_filename.
_validate_i2v_filename = _validate_i2v_path_token


def get_prompts(dimensions: Iterable[str]) -> List[dict]:
    """Load text-only prompts (t2v + t2i) for the given dimensions from the server.

    For image-conditioned (i2v) prompts, use ``get_i2v_prompts`` instead.

    Returns ``[{"prompt_hash": str, "prompt": str, "dimensions": [str, ...]}, ...]``.
    """
    dimension_list = list(dimensions)
    if not dimension_list:
        return []

    from worldjen._api import fetch_eval_config

    config = fetch_eval_config()
    prompts = config.get("prompts", [])
    dim_set = set(dimension_list)

    items: dict[str, dict] = {}
    for prompt_obj in prompts:
        modality = prompt_obj.get("modality")
        if modality == "i2v":
            continue
        text = prompt_obj.get("text", "")
        prompt_hash = prompt_obj.get("promptHash", "")
        prompt_dims = prompt_obj.get("dimensions", [])
        matching = [d for d in prompt_dims if d in dim_set]
        if matching:
            if prompt_hash not in items:
                items[prompt_hash] = {
                    "prompt_hash": prompt_hash,
                    "prompt": text,
                    "dimensions": [],
                }
            for d in matching:
                if d not in items[prompt_hash]["dimensions"]:
                    items[prompt_hash]["dimensions"].append(d)

    if not items:
        raise ValueError(f"No prompts found for dimensions: {dimension_list}")

    return list(items.values())


def _fetch_cached(dimension: str, filename: str, use_cache: bool = True) -> bytes:
    """Fetch an i2v reference image. ``use_cache=True`` reads/writes
    ``~/.worldjen/cache/i2v/<dimension>/<filename>``; ``False`` always hits
    the network and never writes to disk.

    Callers (``get_i2v_prompts``) decide based on a user-supplied flag — image
    caching is opt-in to avoid silently writing GBs of reference images for
    a full-dimension run."""
    dimension = _validate_i2v_path_token(dimension, "dimension")
    filename = _validate_i2v_path_token(filename)
    cache_path = _I2V_CACHE_DIR / dimension / filename
    # Defensive: even though both tokens are validated, refuse any path that
    # resolves outside the cache root. Cheap belt-and-suspenders.
    cache_root = _I2V_CACHE_DIR.resolve()
    try:
        cache_path.resolve().relative_to(cache_root)
    except ValueError:
        raise ValueError(f"Cache path escapes cache root: {cache_path}")
    if use_cache and cache_path.exists():
        return cache_path.read_bytes()

    url = f"{_config.api_url}/api/v1/public/i2v-prompts/{dimension}/{filename}"
    resp = requests.get(url, timeout=60)
    resp.raise_for_status()

    if use_cache:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = cache_path.with_name(
            f".{cache_path.name}.{os.getpid()}.{id(cache_path)}.tmp"
        )
        try:
            tmp_path.write_bytes(resp.content)
            tmp_path.replace(cache_path)
        finally:
            if tmp_path.exists():
                tmp_path.unlink()
    return resp.content


def get_i2v_prompts(
    dimensions: Iterable[str],
    cache_images: bool = False,
) -> List[dict]:
    """Load I2V prompts with pre-generated first-frame images for the given dimensions.

    Pulls the prompt list from the centralized eval config (single API call,
    locally cached + version-checked), then fetches each unique reference image.

    Reference images can total >1GB across all dimensions, so they are NOT
    cached to disk by default. Pass ``cache_images=True`` to opt into
    ``~/.worldjen/cache/i2v/`` for repeated runs over the same dimension set.
    The opt-in is honoured by every reference-image fetch in this call.

    Returns ``[{"prompt_hash": str, "prompt": str, "image": PIL.Image,
                 "reference_image_url": str, "dimensions": [str, ...]}, ...]``.
    """
    dimension_list = list(dimensions)
    if not dimension_list:
        return []

    from worldjen._api import fetch_eval_config

    config = fetch_eval_config()
    raw_prompts = config.get("prompts", [])
    dim_set = set(dimension_list)

    items: list[dict] = []
    image_sources: list[tuple[str, str]] = []
    for prompt_obj in raw_prompts:
        if prompt_obj.get("modality") != "i2v":
            continue
        prompt_dims = prompt_obj.get("dimensions", [])
        matching = [d for d in prompt_dims if d in dim_set]
        if not matching:
            continue
        reference = prompt_obj.get("referenceImage") or {}
        s3_key = reference.get("s3Key")
        if not s3_key:
            continue
        try:
            dimension, image_name = _split_s3_key(s3_key)
        except ValueError:
            continue
        items.append(
            {
                "prompt_hash": prompt_obj.get("promptHash", ""),
                "prompt": prompt_obj.get("text", ""),
                "dimensions": list(matching),
                "reference_image_url": _build_i2v_public_url(dimension, image_name),
                "_image_source": (dimension, image_name),
            }
        )
        image_sources.append((dimension, image_name))

    if not items:
        return []

    image_assets = _load_i2v_images_batch(image_sources, use_cache=cache_images)
    for item in items:
        source = item.pop("_image_source")
        image, _ = image_assets[source]
        item["image"] = image

    return items


def _split_s3_key(s3_key: str) -> tuple[str, str]:
    parts = s3_key.split("/", 1)
    if len(parts) != 2 or not parts[0] or not parts[1]:
        raise ValueError(f"Invalid s3Key: {s3_key!r}")
    # Validate BOTH components — without dimension validation a server-controlled
    # s3Key like "../../etc/dimension/foo.png" would let cache writes escape
    # the cache directory.
    return _validate_i2v_path_token(parts[0], "dimension"), _validate_i2v_path_token(parts[1])


def _build_i2v_public_url(dimension: str, filename: str) -> str:
    return f"{_config.api_url}/api/v1/public/i2v-prompts/{dimension}/{filename}"


def _load_i2v_images_batch(
    image_sources: list[tuple[str, str]],
    use_cache: bool = False,
) -> dict[tuple[str, str], tuple[Image.Image, str]]:
    unique = {key: key for key in image_sources}
    if len(unique) <= 1:
        return {
            key: _load_i2v_image(key[0], key[1], use_cache=use_cache)
            for key in unique
        }

    with ThreadPoolExecutor(max_workers=min(8, len(unique))) as executor:
        futures = {
            key: executor.submit(_load_i2v_image, key[0], key[1], use_cache)
            for key in unique
        }
        return {key: futures[key].result() for key in unique}


def _load_i2v_image(
    dimension: str,
    image_name: str,
    use_cache: bool = False,
) -> tuple[Image.Image, str]:
    image_bytes = _fetch_cached(dimension, image_name, use_cache=use_cache)
    image = Image.open(io.BytesIO(image_bytes))
    image.load()
    return image, _build_i2v_public_url(dimension, image_name)
