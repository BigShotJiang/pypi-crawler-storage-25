"""
Public SDK for project management (list, get, create).

Projects group videos and dimension scores in the dashboard.
"""

from typing import Any, Dict, List

from worldjen._api import (
    create_project as _create_project,
    get_project,
    list_projects as _list_projects,
)


__all__ = [
    "list_projects",
    "get",
    "create",
]


def list_projects() -> List[Dict[str, Any]]:
    """List your projects."""
    return _list_projects()


def get(project_id: str) -> Dict[str, Any]:
    """Fetch a project by ID."""
    return get_project(project_id)


def create(name: str) -> Dict[str, Any]:
    """Create a project."""
    return _create_project(name)
