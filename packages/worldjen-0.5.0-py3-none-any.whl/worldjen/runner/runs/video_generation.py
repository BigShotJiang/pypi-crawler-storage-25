"""Video generation runs for Celery runners"""
import io
import os
import sys
import hashlib
from pathlib import Path
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
import base64
import threading
import queue
from PIL import Image
import traceback

from worldjen.runner.celery_app import celery_app
from worldjen.runner.run_utils import RunStatus
from worldjen.runner.utils.logging import capture_output, log_print
from worldjen.runner.api import get_run, update_run_status, get_model, upload_video
from worldjen._api import fetch_eval_config, get_preferences
from worldjen.runner.utils.hf_token import decrypt_model_token
from worldjen.runner.utils.gpu import cleanup_gpu_memory, log_gpu_memory_status
from worldjen._config import config as sdk_config
from worldjen.prompts import get_i2v_prompts, get_prompts
from worldjen.video import save_frames_as_video, save_image
from worldjen.runner.config.model_configs import MODEL_CONFIGS, get_model_config
from worldjen.runner.config import config as runner_config

VIDEO_DIR = runner_config.get_video_dir()
RESULTS_DIR = runner_config.get_results_dir()

def get_eval_config() -> Dict[str, Any]:
    """Get the eval config. Backed by ``fetch_eval_config`` which itself
    handles caching at ``~/.worldjen/cache/eval-config-<host>.json``: a cheap
    ``/eval-config/version`` probe decides whether to reuse the local cache
    or refetch the full payload."""
    # Make sure the SDK client points at the same backend the runner is
    # registered against (runners may target dev/self-hosted, while the SDK
    # global default is www.worldjen.com).
    sdk_config(api_url=runner_config.get_api_url())

    config = fetch_eval_config()
    dims = config.get("dimensions", [])
    prompts = config.get("prompts", [])
    log_print(
        f"[Config] Loaded {len(dims)} dimensions, {len(prompts)} prompts "
        f"(hash: {config.get('configHash', 'N/A')})"
    )
    return config


def _read_cache_i2v_preference() -> bool:
    """Return the runner's user-account ``cacheI2vImages`` preference.
    Falls back to ``False`` on auth/network errors so a misconfigured runner
    never silently fills the disk."""
    try:
        prefs = get_preferences()
    except Exception as e:
        log_print(f"[Config] Could not read cacheI2vImages preference ({e}); defaulting to False")
        return False
    return bool(prefs.get("cacheI2vImages")) if isinstance(prefs, dict) else False


def get_supported_dimensions() -> set:
    """Get set of supported dimension IDs from server config."""
    eval_config = get_eval_config()
    return {d["id"] for d in eval_config.get("dimensions", [])}


IMAGE_MODEL_TYPES = {"text_to_image"}


def is_image_model(model_type: str) -> bool:
    return model_type in IMAGE_MODEL_TYPES


class BackgroundUploader:
    """Non-blocking background processor that handles video uploads to S3."""

    def __init__(self, run_id: str):
        self.run_id = run_id
        self.upload_queue: queue.Queue = queue.Queue()
        self.upload_results: Dict[str, Dict[str, Any]] = {}
        self.results_lock = threading.Lock()
        self.upload_enabled = True
        self.upload_thread: Optional[threading.Thread] = None
        self.stop_event = threading.Event()

    def start(self):
        self.upload_thread = threading.Thread(target=self._upload_runner, daemon=True)
        self.upload_thread.start()

    def stop(self, timeout: float = 30.0):
        self.stop_event.set()
        if self.upload_thread and self.upload_thread.is_alive():
            self.upload_thread.join(timeout=timeout)

    def queue_video(
        self,
        video_path: Path,
        prompt: str,
        dimension_ids: List[str],
        idx: int,
        total: int,
        reference_image_url: Optional[str] = None,
        prompt_hash: Optional[str] = None,
    ):
        self.upload_queue.put({
            "video_path": video_path,
            "prompt": prompt,
            "prompt_hash": prompt_hash,
            "dimension_ids": dimension_ids,
            "idx": idx,
            "total": total,
            "reference_image_url": reference_image_url,
        })

    def get_upload_results(self) -> Dict[str, Dict[str, Any]]:
        with self.results_lock:
            return dict(self.upload_results)

    def wait_for_completion(self, timeout: float = 600.0):
        try:
            self.upload_queue.join()
        except Exception:
            pass

    def _drain_queue(self, q: queue.Queue, handler):
        while not q.empty():
            try:
                item = q.get_nowait()
                handler(item)
                q.task_done()
            except queue.Empty:
                break

    def _upload_runner(self):
        while not self.stop_event.is_set():
            try:
                item = self.upload_queue.get(timeout=0.5)
            except queue.Empty:
                continue
            self._process_upload(item)
            self.upload_queue.task_done()

        self._drain_queue(self.upload_queue, self._process_upload)

    def _process_upload(self, item: Dict[str, Any]):
        if check_run_cancelled(self.run_id):
            return

        video_path = item["video_path"]
        prompt = item["prompt"]
        prompt_hash = item.get("prompt_hash")
        dimension_ids = item["dimension_ids"]
        idx = item["idx"]
        total = item["total"]
        reference_image_url = item.get("reference_image_url")

        try:
            upload_result = self._do_upload(
                video_path,
                prompt,
                dimension_ids,
                idx,
                total,
                reference_image_url=reference_image_url,
                prompt_hash=prompt_hash,
            )

            with self.results_lock:
                self.upload_results[video_path.name] = upload_result

        except Exception as e:
            log_print(f"[Upload] ERROR: Video {idx+1}/{total}: {type(e).__name__}: {e}")
            print(f"[Upload] ERROR: {type(e).__name__}: {e}", file=sys.stderr)

    def _do_upload(
        self,
        video_path: Path,
        prompt: str,
        dimension_ids: List[str],
        idx: int,
        total: int,
        reference_image_url: Optional[str] = None,
        prompt_hash: Optional[str] = None,
    ) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "uploaded": False,
            "error": None,
        }

        if not self.upload_enabled:
            result["error"] = "Upload disabled"
            return result

        try:
            log_print(f"[Upload] [{idx+1}/{total}] Uploading: {video_path.name}")
            upload_video(
                video_path=video_path,
                run_id=self.run_id,
                prompt=prompt,
                prompt_hash=prompt_hash,
                source='runner',
                dimension_ids=dimension_ids,
                reference_image_url=reference_image_url,
            )
            result["uploaded"] = True
            log_print(f"[Upload] [{idx+1}/{total}] ✓ Complete")

        except RuntimeError as e:
            error_str = str(e)
            if "S3 not configured" in error_str or "S3_BUCKET" in error_str or "bucket" in error_str.lower():
                log_print(f"[Upload] WARNING: S3 not configured - uploads disabled")
                print(f"[Upload] WARNING: S3 not configured", file=sys.stderr)
                self.upload_enabled = False
                result["error"] = "S3 not configured"
            elif "Connection" in error_str or "timeout" in error_str.lower() or "refused" in error_str.lower():
                log_print(f"[Upload] ERROR: Network error for video {idx+1}/{total}: {error_str}")
                print(f"[Upload] ERROR: Network error - {error_str}", file=sys.stderr)
                result["error"] = f"Network error: {error_str}"
            elif "Runner token" in error_str or "401" in error_str or "403" in error_str:
                log_print(f"[Upload] ERROR: Auth failed for video {idx+1}/{total}: {error_str}")
                print(f"[Upload] ERROR: Auth error - {error_str}", file=sys.stderr)
                result["error"] = "Authentication error"
            else:
                log_print(f"[Upload] ERROR: Failed for video {idx+1}/{total}: {error_str}")
                print(f"[Upload] ERROR: Upload failed - {error_str}", file=sys.stderr)
                result["error"] = error_str

        except Exception as e:
            log_print(f"[Upload] ERROR: Unexpected error for video {idx+1}/{total}: {e}")
            print(f"[Upload] ERROR: {type(e).__name__}: {e}", file=sys.stderr)
            result["error"] = str(e)

        return result


def check_run_cancelled(run_id: str) -> bool:
    try:
        run = get_run(run_id)
        if run and run.get('status') == RunStatus.CANCELLED:
            return True
    except Exception:
        pass
    return False


@celery_app.task(
    bind=True,
    name="process_video_generation",
    acks_late=False,
    time_limit=None,
    soft_time_limit=None,
)
def process_video_generation(self, run_id: str):
    # Get run data from API
    run = get_run(run_id)
    
    if not run:
        return {"error": "Run not found"}

    if check_run_cancelled(run_id):
        log_print("Run was cancelled before starting")
        return {"status": "cancelled", "run_id": run_id}
    
    log_print("\n=== Pre-run GPU Memory Status ===")
    log_gpu_memory_status()
    cleanup_gpu_memory()
    log_print("Pre-run cleanup completed\n")
    
    with capture_output(run_id) as log_capture:
        try:
            generation_started_at = datetime.now(timezone.utc)
            
            update_run_status(run_id, status="running")

            log_print(f"=== Starting run {run_id} - {run.get('name')} ===")
            log_print(f"HuggingFace Repo: {run.get('hfRepoUrl')}")
            
            run_dir = VIDEO_DIR / str(run_id)
            run_dir.mkdir(parents=True, exist_ok=True)
            log_print(f"Created output directory: {run_dir}")
            
            model_id = run.get('modelId')
            hf_repo_url = run.get('hfRepoUrl')
            
            # Fetch model from database to get type
            if not model_id:
                raise ValueError("Model ID not found in run data")
            
            model = get_model(model_id)
            model_type = model.get('type')
            hf_token = decrypt_model_token(model.get('encryptedToken'))

            if not model_type:
                raise ValueError(f"Model type not found for model {model_id}")

            evaluate_config = run.get('evaluateConfig')
            dimensions = evaluate_config.get('dimensions', []) if evaluate_config else []

            # Validate dimensions against server config (skip if server unavailable)
            try:
                supported = get_supported_dimensions()
                for dimension in dimensions:
                    if dimension not in supported:
                        raise ValueError(
                            f"Dimension '{dimension}' is not supported. "
                            f"Supported dimensions: {', '.join(sorted(supported))}"
                        )
            except ValueError:
                raise
            except Exception as e:
                log_print(f"[Config] WARNING: Could not validate dimensions against server ({e}), proceeding without validation")

            custom_prompts = evaluate_config.get('custom_prompts', []) if evaluate_config else []
            if custom_prompts:
                unified_prompts = [{"prompt": p, "dimensions": dimensions} for p in custom_prompts]
            elif model_type == "image_to_video":
                sdk_config(api_url=runner_config.get_api_url())
                # Runner honours the user's cacheI2vImages preference (set via
                # Web UI Settings → "Cache i2v Reference Images" or via
                # `worldjen preferences set-cache-i2v-images on`). Long-lived
                # runner machines are exactly where image caching pays off,
                # but it's still opt-in to avoid surprising disk fills.
                cache_images_pref = _read_cache_i2v_preference()
                unified_prompts = get_i2v_prompts(dimensions, cache_images=cache_images_pref)
            else:
                # Delegate to the shared SDK prompt loader so modality filtering,
                # promptHash propagation, and t2v/t2i handling stay in one place.
                sdk_config(api_url=runner_config.get_api_url())
                unified_prompts = get_prompts(dimensions)
                total_slots = sum(len(item["dimensions"]) for item in unified_prompts)
                log_print(f"Server config prompts: {len(unified_prompts)} unique prompts covering "
                          f"{total_slots} dimension-prompt slots across {len(dimensions)} dimensions")

            log_print(f"Dimensions: {', '.join(dimensions)}")
            log_print(f"Unique prompts to generate: {len(unified_prompts)}")
            for dimension in dimensions:
                count = sum(1 for p in unified_prompts if dimension in p["dimensions"])
                log_print(f"  {dimension}: {count} prompts")

            try:
                update_run_status(run_id, num_videos=len(unified_prompts))
            except Exception as e:
                log_print(f"[Progress] Failed to report num_videos to server: {e}")

            log_print(f"\n=== DEBUG INFO ===")
            log_print(f"model_type: {model_type}")
            log_print(f"model_id: {model_id}")
            log_print(f"==================\n")

            result_data = {
                "metadata": {
                    "generation_started_at": generation_started_at.isoformat(),
                }
            }

            processor = BackgroundUploader(run_id)
            processor.start()
            log_print("Background uploader started")

            try:
                run_huggingface_model(
                    model_id,
                    hf_repo_url,
                    run.get('runInstructions'),
                    unified_prompts,
                    hf_token,
                    run_dir,
                    log_capture,
                    run_id,
                    model_type=model_type,
                    processor=processor,
                )

                generation_completed_at = datetime.now(timezone.utc)

                log_print("\nWaiting for background uploads to complete...")
                processor.wait_for_completion(timeout=600.0)
            finally:
                processor.stop()

            upload_results = processor.get_upload_results()
            upload_ok = sum(1 for r in upload_results.values() if r.get("uploaded"))
            upload_fail = len(upload_results) - upload_ok
            log_print(f"\n=== Processing Summary ===")
            log_print(f"Total videos: {len(unified_prompts)}")
            log_print(f"Uploaded: {upload_ok}")
            if upload_fail > 0:
                log_print(f"Upload failures: {upload_fail}")
                for name, r in upload_results.items():
                    if r.get("error"):
                        log_print(f"  - {name}: {r['error']}")
            log_print("==========================\n")

            result_data["metadata"]["generation_completed_at"] = generation_completed_at.isoformat()
            result_data["metadata"]["generation_duration"] = (generation_completed_at - generation_started_at).total_seconds()
            
            update_run_status(
                run_id,
                status="completed",
                result_data=result_data
            )
            
            log_print(f"\n=== Run {run_id} completed successfully! ===")
            
            return {"status": "completed", "run_id": run_id}
        
        except Exception as e:
            if check_run_cancelled(run_id):
                log_print(f"\nRun was cancelled: {str(e)}")
                return {"status": "cancelled", "run_id": run_id}
            
            print(f"\nERROR: Run failed with exception: {str(e)}", file=sys.stderr)
            traceback.print_exc()
            
            update_run_status(
                run_id,
                status="failed",
                error_message=str(e)
            )
            
            return {"status": "failed", "error": str(e)}
        
        finally:
            log_print("\n=== Post-run Cleanup ===")
            cleanup_gpu_memory()
            log_gpu_memory_status()
            log_print("=== Cleanup completed, runner process will restart ===")


def run_huggingface_model(
    model_id: str,
    repo_url: str,
    run_instructions: Dict[str, Any],
    unified_prompts: List[Dict[str, Any]],
    hf_token: Optional[str],
    output_dir: Path,
    log_capture,
    run_id: str,
    model_type: str = "text_to_video",
    processor: Optional[BackgroundUploader] = None,
) -> List[Dict[str, Any]]:
    if hf_token:
        log_print("Setting HuggingFace token environment variables...")
        os.environ["HF_TOKEN"] = hf_token
        os.environ["HUGGING_FACE_HUB_TOKEN"] = hf_token
    
    return run_diffusers_model(
        model_id,
        repo_url,
        run_instructions,
        unified_prompts,
        output_dir,
        log_capture,
        run_id,
        model_type,
        processor=processor,
        hf_token=hf_token,
    )


def _resolve_torch_dtype(s: str):
    # Lazy import: defer torch until needed; avoids loading heavy deps at module load
    import torch

    m = {
        "bfloat16": torch.bfloat16,
        "bf16": torch.bfloat16,
        "torch.bfloat16": torch.bfloat16,
        "float16": torch.float16,
        "torch.float16": torch.float16,
        "float32": torch.float32,
        "torch.float32": torch.float32,
        "fp16": torch.float16,
        "torch.fp16": torch.float16,
        "fp32": torch.float32,
        "torch.fp32": torch.float32,
        "float8_e4m3fn": torch.float8_e4m3fn,
        "torch.float8_e4m3fn": torch.float8_e4m3fn,
        "float8_e5m2": torch.float8_e5m2,
        "torch.float8_e5m2": torch.float8_e5m2,
    }
    return m.get(s.strip().lower(), torch.bfloat16)


def run_diffusers_model(
    model_id: str,
    repo_url: str,
    run_instructions: Dict[str, Any],
    unified_prompts: List[Dict[str, Any]],
    output_dir: Path,
    log_capture,
    run_id: str,
    model_type: str = "text_to_video",
    processor: Optional[BackgroundUploader] = None,
    hf_token: Optional[str] = None,
) -> List[Dict[str, Any]]:
    # Lazy import: defer torch/diffusers until needed; avoids loading GPU libs at module load
    import torch
    from diffusers import DiffusionPipeline

    if run_instructions is None:
        run_instructions = {}

    run_instructions = dict(run_instructions)
    pipe_extra_kwargs = run_instructions.pop("pipe_extra_kwargs", None) or {}
    pipe_extra_kwargs = dict(pipe_extra_kwargs)

    resolved: Dict[str, Any] = {}
    for key, entry in pipe_extra_kwargs.items():
        if isinstance(entry, dict) and "value" in entry and "type" in entry:
            raw_value = entry["value"]
            value_type = entry.get("type", "string")
        else:
            raw_value = entry
            value_type = "string"
        if value_type == "integer":
            try:
                resolved[key] = int(raw_value)
            except (TypeError, ValueError):
                resolved[key] = 0
        elif value_type == "dtype":
            resolved[key] = (
                _resolve_torch_dtype(str(raw_value))
                if isinstance(raw_value, str)
                else raw_value
            )
        else:
            resolved[key] = str(raw_value) if not isinstance(raw_value, str) else raw_value
    pipe_extra_kwargs = resolved

    if "dtype" not in pipe_extra_kwargs and "torch_dtype" not in pipe_extra_kwargs:
        pipe_extra_kwargs.setdefault("torch_dtype", torch.bfloat16)

    run_instructions.setdefault("num_inference_steps", 30)

    generation_kwargs = run_instructions

    model_cfg = get_model_config(repo_url)
    if model_cfg is not None:
        log_print(f"\nInitializing pipeline for {repo_url}...")

        pipe = model_cfg['init_fn'](repo_url, torch)
        if pipe is not None:
            log_print(f"Pipeline for {repo_url} initialized successfully")
        else:
            log_print(f"{repo_url} uses external execution (no pipeline initialization needed)")
    else:
        log_print(
            f"\nNo MODEL_CONFIGS entry for repo_url={repo_url} (model_id={model_id}). "
            f"Using default DiffusionPipeline..."
        )
        log_print(
            "pipe_extra_kwargs: " + 
            ", ".join(
                f"{k}={repr(v)} (type={type(v).__name__})" 
                for k, v in pipe_extra_kwargs.items()
            )
        )
        if hf_token:
            pipe_extra_kwargs["token"] = hf_token
        pipe = DiffusionPipeline.from_pretrained(repo_url, **pipe_extra_kwargs)
        
        enable_model_cpu_offload = run_instructions.get("enable_model_cpu_offload", False)
        if enable_model_cpu_offload:
            log_print("Enabling model CPU offload...")
            pipe.enable_model_cpu_offload()
        else:
            pipe.to("cuda")
    
    produces_images = is_image_model(model_type)
    media_label = "image" if produces_images else "video"
    generated_outputs: List[Dict[str, Any]] = []
    total = len(unified_prompts)
    
    for idx, prompt_info in enumerate(unified_prompts):
        if check_run_cancelled(run_id):
            log_print(f"\nRun cancelled during generation. Stopping after {len(generated_outputs)} {media_label}s.")
            raise Exception("Run cancelled by user")
        
        prompt = prompt_info["prompt"]
        image_data = prompt_info.get("image")
        image = None
        
        if model_type == 'image_to_video' and image_data:
            log_print(f"\n[{idx+1}/{total}] Generating video from image with prompt: '{prompt}'")
            
            try:
                if isinstance(image_data, Image.Image):
                    image = image_data.convert('RGB')
                else:
                    if image_data.startswith('data:image'):
                        image_data = image_data.split(',')[1]
                    image_bytes = base64.b64decode(image_data)
                    image = Image.open(io.BytesIO(image_bytes)).convert('RGB')
            except Exception as e:
                log_print(f"Error loading image: {e}")
                raise Exception(f"Failed to load image: {str(e)}")
        else:
            log_print(f"\n[{idx+1}/{total}] Generating {media_label} for prompt: '{prompt}'")
        
        torch.cuda.empty_cache()
        with torch.inference_mode():
            model_cfg = get_model_config(repo_url)
            if model_cfg is not None:
                if model_cfg.get('requires_image_input', False) and image is None:
                    raise ValueError(
                        f"Model at '{repo_url}' is an image-to-video model and requires an image input. "
                        f"Please provide an image or use a text-to-video model instead."
                    )

                if model_cfg['supports_image_input']:
                    output_raw = model_cfg['generate_fn'](pipe, image, prompt, generation_kwargs, torch)
                else:
                    output_raw = model_cfg['generate_fn'](pipe, prompt, generation_kwargs, torch)
            else:
                if model_type == 'image_to_video' and image is not None:
                    output_raw = pipe(prompt=prompt, image=image, **generation_kwargs)
                else:
                    output_raw = pipe(prompt, **generation_kwargs)
                
                if produces_images:
                    if hasattr(output_raw, "images"):
                        output_raw = output_raw.images[0]
                else:
                    if hasattr(output_raw, "frames"):
                        output_raw = output_raw.frames[0]
                    elif hasattr(output_raw, "images"):
                        output_raw = output_raw.images
        
        prompt_hash = hashlib.sha256(prompt.encode()).hexdigest()[:12]
        safe_prompt = f"{prompt[:20]}...{prompt[-20:]}" if len(prompt) > 40 else prompt
        safe_prompt = safe_prompt.replace(" ", "_").replace("/", "_").replace("\0", "")

        out_dir = output_dir / "original"
        out_dir.mkdir(parents=True, exist_ok=True)

        if produces_images:
            out_filename = f"{safe_prompt}-{prompt_hash}-{idx}.png"
            out_path = out_dir / out_filename
            log_print(f"Saving image to: {out_path}")
            save_image(output_raw, out_path)
        else:
            out_filename = f"{safe_prompt}-{prompt_hash}-{idx}.mp4"
            out_path = out_dir / out_filename
            log_print(f"Saving video to: {out_path}")
            save_frames_as_video(output_raw, out_path)
        
        abs_path = out_path.resolve()
        log_print(f"{media_label.capitalize()} {idx+1} saved successfully at {abs_path}")
        
        processor.queue_video(
            abs_path,
            prompt,
            prompt_info["dimensions"],
            idx,
            total,
            reference_image_url=prompt_info.get("reference_image_url"),
            prompt_hash=prompt_info.get("prompt_hash"),
        )

        generated_outputs.append({
            "path": str(abs_path),
            "prompt": prompt,
            "filename": abs_path.name,
        })
        
        torch.cuda.empty_cache()
    
    log_print("Cleaning up pipeline...")
    
    if pipe is not None:
        del pipe
        torch.cuda.synchronize()
        torch.cuda.empty_cache()
        import gc  # Lazy import: only needed in this cleanup path

        gc.collect()
    
    log_print("Pipeline cleanup completed")
    
    return generated_outputs

