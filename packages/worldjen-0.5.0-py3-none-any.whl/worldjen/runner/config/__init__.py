# Runner config — instance resolved from WORLDJEN_RUNNER_INSTANCE env var
import os
from worldjen.runner.config.runner_config import RunnerConfig

instance = os.environ.get("WORLDJEN_RUNNER_INSTANCE", "default")
config = RunnerConfig(instance)

__all__ = ["RunnerConfig", "config"]
