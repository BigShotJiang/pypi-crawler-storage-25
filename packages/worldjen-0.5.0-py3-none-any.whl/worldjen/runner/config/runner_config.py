"""Centralized configuration for runner (runner.conf, RabbitMQ, API)."""
import os
import re
from configparser import ConfigParser
from pathlib import Path
from typing import Optional
from urllib.parse import quote, urlparse, urlunparse


class RunnerConfig:
    _default_config_path = Path(__file__).parent.parent / "default.conf"
    INSTANCE_NAME_PATTERN = r'[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}'

    @classmethod
    def validate_instance_name(cls, name: str) -> bool:
        return re.fullmatch(cls.INSTANCE_NAME_PATTERN, name) is not None

    def __init__(self, instance_name: str = "default"):
        if not self.validate_instance_name(instance_name):
            raise ValueError(
                f"Invalid runner instance name '{instance_name}'. "
                "Use alphanumeric, hyphens, underscores. Max 64 chars. Must start with alphanumeric."
            )
        self.instance_name = instance_name
        self._runner_config_cache: Optional[ConfigParser] = None
        self._config_loaded = False
        self.DEFAULT_API_URL: Optional[str] = None
        self.DEFAULT_API_TIMEOUT: Optional[int] = None
        self.DEFAULT_PASSWORD_LENGTH: Optional[int] = None

    @staticmethod
    def _get_user_config_dir() -> Path:
        return Path(os.getenv("XDG_CONFIG_HOME", Path.home() / ".config")) / "worldjen"

    def get_config_path(self) -> Path:
        return self._get_user_config_dir() / f"runner-{self.instance_name}.conf"

    def get_private_key_path(self) -> Path:
        return self.get_config_path().with_suffix(".conf.key")

    @staticmethod
    def list_instances() -> list[str]:
        config_dir = RunnerConfig._get_user_config_dir()
        if not config_dir.is_dir():
            return []
        return [
            p.stem.removeprefix("runner-")
            for p in sorted(config_dir.glob("runner-*.conf"))
            if p.stem.removeprefix("runner-")
        ]

    def _load_default_config(self) -> ConfigParser:
        config = ConfigParser()
        if self._default_config_path.exists():
            config.read(self._default_config_path)
        return config

    def _load_runner_config(self) -> ConfigParser:
        if self._runner_config_cache is not None:
            return self._runner_config_cache
        config = ConfigParser()
        config_path = self.get_config_path()
        if config_path.exists():
            config.read(config_path)
        self._runner_config_cache = config
        return config

    def _get_config_value(
        self, section: str, key: str, env_var: Optional[str] = None, default: str = ""
    ) -> str:
        if env_var:
            env_value = os.getenv(env_var)
            if env_value:
                return env_value
        runner_config = self._load_runner_config()
        if runner_config.has_option(section, key):
            return runner_config.get(section, key)
        default_config = self._load_default_config()
        if default_config.has_option(section, key):
            return default_config.get(section, key)
        return default

    def _get_api_url(self) -> str:
        return self._get_config_value("api", "base_url", "WORLDJEN_API_URL", "https://www.worldjen.com")

    def _get_api_timeout(self) -> int:
        return int(self._get_config_value("api", "timeout", "WORLDJEN_API_TIMEOUT", "30"))

    def _get_password_length(self) -> int:
        return int(self._get_config_value("registration", "password_length", "WORLDJEN_PASSWORD_LENGTH", "32"))

    def _get_rabbitmq_base_url(self) -> Optional[str]:
        url = self._get_config_value("rabbitmq", "url", "RABBITMQ_BASE_URL", "")
        return url if url else None

    def _get_rabbitmq_user(self) -> Optional[str]:
        runner_config = self._load_runner_config()
        if runner_config.has_option("runner", "rabbitmq_user"):
            return runner_config.get("runner", "rabbitmq_user")
        return None

    def _get_rabbitmq_password(self) -> Optional[str]:
        runner_config = self._load_runner_config()
        if runner_config.has_option("runner", "password"):
            return runner_config.get("runner", "password")
        return None

    def _get_rabbitmq_vhost(self) -> Optional[str]:
        runner_config = self._load_runner_config()
        if runner_config.has_option("runner", "rabbitmq_vhost"):
            return runner_config.get("runner", "rabbitmq_vhost")
        return None

    def _get_rabbitmq_queue(self) -> Optional[str]:
        runner_config = self._load_runner_config()
        if runner_config.has_option("runner", "rabbitmq_queue"):
            return runner_config.get("runner", "rabbitmq_queue")
        return None

    def get_rabbitmq_url(self) -> str:
        env_url = os.getenv("RABBITMQ_URL")
        if env_url:
            return env_url
        config_path = self.get_config_path()
        if not config_path.exists():
            raise RuntimeError(
                f"Runner configuration file not found at '{config_path}'. "
                "The runner must be registered before it can run. "
                "Please run 'worldjen runner register --token <runner_token>' first."
            )
        user = self._get_rabbitmq_user()
        password = self._get_rabbitmq_password()
        vhost = self._get_rabbitmq_vhost()
        base_url = self._get_rabbitmq_base_url()
        if not user or not password or not base_url:
            raise RuntimeError(
                f"Runner configuration file '{config_path.name}' is missing required RabbitMQ credentials."
            )
        parsed = urlparse(base_url)
        if not vhost or vhost == "/":
            vhost_encoded = "/"
        else:
            vhost_clean = vhost.lstrip("/")
            vhost_encoded = "/" + quote(vhost_clean, safe="")
        netloc = f"{user}:{password}@{parsed.hostname}"
        if parsed.port:
            netloc += f":{parsed.port}"
        return urlunparse((parsed.scheme, netloc, vhost_encoded, "", "", ""))

    def _initialize(self) -> None:
        if not self._config_loaded:
            self.DEFAULT_API_URL = self._get_api_url()
            self.DEFAULT_API_TIMEOUT = self._get_api_timeout()
            self.DEFAULT_PASSWORD_LENGTH = self._get_password_length()
            self._config_loaded = True

    def get_api_url(self) -> str:
        env_url = os.getenv("WORLDJEN_API_URL")
        if env_url:
            return env_url.rstrip("/")
        self._initialize()
        return self.DEFAULT_API_URL or "https://www.worldjen.com"

    def get_api_timeout(self) -> int:
        self._initialize()
        return self.DEFAULT_API_TIMEOUT or 30

    def get_password_length(self) -> int:
        self._initialize()
        return self.DEFAULT_PASSWORD_LENGTH or 32

    def get_default_config_path(self) -> Path:
        return self.get_config_path()

    def get_runner_private_key_path(self) -> Optional[Path]:
        p = self.get_private_key_path()
        return p if p.exists() else None

    def get_rabbitmq_user(self) -> Optional[str]:
        return self._get_rabbitmq_user()

    def get_rabbitmq_password(self) -> Optional[str]:
        return self._get_rabbitmq_password()

    def get_rabbitmq_vhost(self) -> Optional[str]:
        return self._get_rabbitmq_vhost()

    def get_rabbitmq_queue(self) -> Optional[str]:
        return self._get_rabbitmq_queue()

    def get_runner_token(self) -> Optional[str]:
        runner_config = self._load_runner_config()
        if runner_config.has_option("runner", "runner_token"):
            return runner_config.get("runner", "runner_token")
        return None

    @staticmethod
    def get_data_dir() -> Path:
        env_data_dir = os.getenv("WORLDJEN_DATA_DIR")
        if env_data_dir:
            return Path(env_data_dir)
        return Path.home() / ".worldjen" / "data"

    @staticmethod
    def get_video_dir() -> Path:
        video_dir = RunnerConfig.get_data_dir() / "videos"
        video_dir.mkdir(parents=True, exist_ok=True)
        return video_dir

    @staticmethod
    def get_results_dir() -> Path:
        results_dir = RunnerConfig.get_data_dir() / "results"
        results_dir.mkdir(parents=True, exist_ok=True)
        return results_dir

    @staticmethod
    def get_cache_dir() -> Path:
        env_cache_dir = os.getenv("HF_HOME")
        if env_cache_dir:
            return Path(env_cache_dir)
        cache_dir = Path.home() / ".worldjen" / "cache" / "huggingface"
        cache_dir.mkdir(parents=True, exist_ok=True)
        return cache_dir
