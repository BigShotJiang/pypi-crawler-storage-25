"""Systemd service management for runner (install, start, stop, logs)."""
import os
import platform
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional

from worldjen.runner.config.runner_config import RunnerConfig

SERVICE_TEMPLATE = "worldjen-runner@"


def get_service_name(instance_name: str) -> str:
    return f"worldjen-runner@{instance_name}"


def get_template_path() -> Path:
    return Path("/etc/systemd/system/worldjen-runner@.service")


def _require_linux() -> None:
    if platform.system() != "Linux":
        raise RuntimeError(f"Service management is only supported on Linux. Current: {platform.system()}")


def _run_sudo(*args: str) -> None:
    """Run a single command under sudo. Used only for the minimal root operations (write unit, systemctl)."""
    subprocess.check_call(["sudo", *args])


def is_systemd_running() -> bool:
    try:
        return Path("/run/systemd/system").exists()
    except Exception:
        return False


def get_python_executable() -> str:
    return sys.executable


def generate_systemd_unit() -> str:
    """Generate shared systemd template unit with settings common to all instances.

    Per-instance settings (User, HOME, PATH, HF_HOME, loglevel, working_dir) go
    in drop-in overrides so each instance owns its own identity and a second
    install can't inherit or overwrite the first installer's user/environment.
    """
    return """[Unit]
Description=WorldJen Runner (%i)
After=network.target

[Service]
Type=simple
Environment="WORLDJEN_RUNNER_INSTANCE=%i"
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal
LimitNOFILE=524288

[Install]
WantedBy=multi-user.target
"""


def get_dropin_dir(instance_name: str) -> Path:
    """Return the systemd drop-in directory for instance-specific overrides."""
    return Path(f"/etc/systemd/system/worldjen-runner@{instance_name}.service.d")


def generate_dropin_override(
    user: str = "root",
    home_dir: str = "/root",
    path: str = "/usr/local/bin:/usr/bin:/bin",
    loglevel: str = "info",
    working_dir: Optional[Path] = None,
) -> str:
    """Generate a per-instance drop-in override.

    Contains User identity, environment (HOME/PATH/HF_HOME), ExecStart, and
    WorkingDirectory — everything that may differ between instances.
    """
    python = get_python_executable()
    celery_cmd = f"{python} -m celery -A worldjen.runner.celery_app worker --loglevel={loglevel} --without-gossip --without-mingle --without-heartbeat -c 1"
    work_dir = working_dir or Path.cwd()
    hf_home = f"{home_dir}/.worldjen/cache/huggingface"
    return f"""[Service]
User={user}
Environment="HOME={home_dir}"
Environment="PATH={path}"
Environment="HF_HOME={hf_home}"
ExecStart=
ExecStart={celery_cmd}
WorkingDirectory={work_dir}
"""


def install(
    instance_name: str = "default",
    loglevel: str = "info",
    working_dir: Optional[str] = None,
) -> None:
    _require_linux()
    runner_cfg = RunnerConfig(instance_name)
    queue = runner_cfg.get_rabbitmq_queue()
    if not queue:
        raise RuntimeError(
            f"Runner '{instance_name}' not registered. Register first with 'worldjen runner register --token <token>'."
        )
    work_dir = Path(working_dir) if working_dir else Path.cwd()
    template_path = get_template_path()
    service_name = get_service_name(instance_name)
    user = os.environ.get("SUDO_USER") or os.environ.get("USER", "root")
    home_dir = os.environ.get("HOME", str(Path.home()))
    path_env = os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin")

    # Write shared template (common settings only) if it doesn't exist yet.
    # Per-instance identity (User, HOME, PATH, ExecStart, WorkingDirectory)
    # lives in the drop-in below, so the template never bakes in a single
    # installer's environment.
    if not template_path.exists():
        unit_content = generate_systemd_unit()
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".service", prefix="worldjen-runner-", delete=False
        ) as f:
            f.write(unit_content)
            tmp_path = f.name
        try:
            _run_sudo("cp", tmp_path, str(template_path))
            print(f"Service template created at: {template_path}")
        finally:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass

    # Write per-instance drop-in override for user, environment, loglevel, and working_dir
    dropin_dir = get_dropin_dir(instance_name)
    override_content = generate_dropin_override(
        user=user,
        home_dir=home_dir,
        path=path_env,
        loglevel=loglevel,
        working_dir=work_dir,
    )
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".conf", prefix="worldjen-override-", delete=False
    ) as f:
        f.write(override_content)
        tmp_override = f.name
    try:
        _run_sudo("mkdir", "-p", str(dropin_dir))
        _run_sudo("cp", tmp_override, str(dropin_dir / "override.conf"))
        print(f"Instance override created at: {dropin_dir / 'override.conf'}")
    finally:
        try:
            os.unlink(tmp_override)
        except OSError:
            pass

    if is_systemd_running():
        _run_sudo("systemctl", "daemon-reload")
        _run_sudo("systemctl", "enable", service_name)
        print(f"Service {service_name} enabled to start on boot. Start now with: worldjen runner start --name {instance_name}")
    else:
        print(f"Systemd not running. On a systemd system run: sudo systemctl daemon-reload && sudo systemctl enable {service_name}")


def uninstall(instance_name: str = "default") -> None:
    _require_linux()
    service_name = get_service_name(instance_name)
    template_path = get_template_path()
    if is_systemd_running():
        subprocess.run(["sudo", "systemctl", "stop", service_name], check=False)
        subprocess.run(["sudo", "systemctl", "disable", service_name], check=False)
    # Remove per-instance drop-in override
    dropin_dir = get_dropin_dir(instance_name)
    subprocess.run(["sudo", "rm", "-rf", str(dropin_dir)], check=False)
    # Remove shared template only if no other instances remain
    remaining = [
        name for name in RunnerConfig.list_instances()
        if name != instance_name
    ]
    if not remaining:
        _run_sudo("rm", "-f", str(template_path))
        if is_systemd_running():
            _run_sudo("systemctl", "daemon-reload")
        print(f"Service template removed: {template_path}")
    elif is_systemd_running():
        _run_sudo("systemctl", "daemon-reload")
    print(f"Service {service_name} stopped and disabled")


def _require_systemd() -> None:
    _require_linux()
    if not is_systemd_running():
        raise RuntimeError("Systemd is not running. This command requires a systemd-based system.")


def start(instance_name: str = "default") -> None:
    _require_systemd()
    service_name = get_service_name(instance_name)
    result = subprocess.run(
        ["sudo", "systemctl", "start", service_name], capture_output=True, text=True
    )
    if result.returncode != 0:
        raise RuntimeError(f"Failed to start service: {result.stderr}")
    print(f"Service {service_name} started")


def stop(instance_name: str = "default") -> None:
    _require_systemd()
    service_name = get_service_name(instance_name)
    result = subprocess.run(
        ["sudo", "systemctl", "stop", service_name], capture_output=True, text=True
    )
    if result.returncode != 0:
        raise RuntimeError(f"Failed to stop service: {result.stderr}")
    print(f"Service {service_name} stopped")


def status(instance_name: str = "default") -> None:
    _require_systemd()
    service_name = get_service_name(instance_name)
    result = subprocess.run(
        ["systemctl", "status", service_name],
        capture_output=True,
        text=True,
    )
    print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)


def logs(instance_name: str = "default", follow: bool = False, lines: int = 50) -> None:
    _require_systemd()
    service_name = get_service_name(instance_name)
    cmd = ["journalctl", "-u", service_name, "-n", str(lines)]
    if follow:
        cmd.append("-f")
    subprocess.run(cmd)
