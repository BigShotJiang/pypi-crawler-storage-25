"""Celery app for runner worker (consumes process_video_generation tasks)."""
import sys
import threading
import time

from celery import Celery

try:
    from worldjen.runner.config import config
    rabbitmq_url = config.get_rabbitmq_url()
except RuntimeError as e:
    print(f"\n{'='*80}", file=sys.stderr)
    print("ERROR: Runner registration required", file=sys.stderr)
    print(f"{'='*80}", file=sys.stderr)
    print(str(e), file=sys.stderr)
    print(f"{'='*80}\n", file=sys.stderr)
    sys.exit(1)

include_modules = ["worldjen.runner.runs.video_generation"]
backend_url = rabbitmq_url.replace("amqps://", "rpc://").replace("amqp://", "rpc://")
celery_app = Celery(
    "worldjen",
    broker=rabbitmq_url,
    backend=backend_url,
    include=include_modules,
)

queue_name = None
try:
    from worldjen.runner.config import config
    queue_name = config.get_rabbitmq_queue()
except Exception:
    pass

run_queues = {}
if queue_name:
    from kombu import Queue
    run_queues[queue_name] = Queue(queue_name, exchange="", routing_key=queue_name)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=False,
    task_time_limit=None,
    task_soft_time_limit=None,
    worker_prefetch_multiplier=1,
    worker_enable_remote_control=False,
    task_default_queue=queue_name,
    task_default_exchange_type="direct",
    task_default_routing_key=queue_name,
    worker_send_task_events=True,
    task_send_sent_event=True,
)

if run_queues:
    celery_app.conf.task_queues = list(run_queues.values())


def _heartbeat_loop() -> None:
    from worldjen.runner.api import send_heartbeat

    while True:
        try:
            send_heartbeat()
        except Exception as e:
            print(f"[Runner Heartbeat] {e}", file=sys.stderr)
        time.sleep(30)


threading.Thread(target=_heartbeat_loop, daemon=True).start()

from worldjen.runner.run_utils import fail_unfinished_runs_on_runner_startup
fail_unfinished_runs_on_runner_startup()
