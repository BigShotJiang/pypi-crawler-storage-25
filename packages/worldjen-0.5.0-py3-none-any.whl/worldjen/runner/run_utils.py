"""Run utilities for runners."""
from enum import Enum


class RunStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


def fail_unfinished_runs_on_runner_startup() -> None:
    try:
        from worldjen.runner.api import get_running_runs, send_logs, update_run_status
        running_run_ids = get_running_runs()
        if running_run_ids:
            print(f"[Runner Startup] Marking {len(running_run_ids)} running runs as failed due to runner restart")
            for run_id in running_run_ids:
                try:
                    try:
                        send_logs(run_id, "\n\n=== Runner restarted, run marked as failed ===\n")
                    except Exception as log_error:
                        print(f"[Runner Startup] Warning: Failed to append log for run {run_id}: {log_error}")
                    update_run_status(run_id=run_id, status="failed", error_message="Run failed due to runner restart")
                except Exception as run_error:
                    print(f"[Runner Startup] Error marking run {run_id} as failed: {run_error}")
            print("[Runner Startup] Successfully marked runs as failed")
    except Exception as e:
        print(f"[Runner Startup] Error marking runs as failed: {e}")
