"""
Public SDK for the Playground and Rank surfaces.

Playground and Rank are user-scoped sandbox runs (one of each per user) that the
dashboard uses for ad-hoc custom-prompt evaluations. They share the same routes,
distinguished by ``kind="playground"`` (default) or ``kind="rank"``.

Use these to programmatically reset a sandbox or fetch the active run id so you
can attach videos to it via the runner upload endpoints.
"""

from typing import Any, Dict

from worldjen._api import (
    get_or_create_playground_run as _get_or_create_playground_run,
    reset_playground_run as _reset_playground_run,
)


__all__ = ["get_or_create", "reset"]


def get_or_create(kind: str = "playground") -> Dict[str, Any]:
    """
    Return the user's Playground (``kind="playground"``) or Rank (``kind="rank"``) run,
    creating it lazily if it doesn't exist yet.
    """
    return _get_or_create_playground_run(kind)


def reset(kind: str = "playground") -> Dict[str, Any]:
    """
    Clear all videos from the active Playground or Rank run. The run id is preserved
    so frontends and SDK clients can keep their session reference stable.
    """
    return _reset_playground_run(kind)
