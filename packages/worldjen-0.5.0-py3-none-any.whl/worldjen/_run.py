import io
import sys
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

import numpy as np

from worldjen._config import _config
from worldjen._api import (
    append_run_logs,
    confirm_upload,
    create_run,
    get_preferences,
    get_run,
    get_upload_url,
    update_run_status,
    upload_to_presigned,
)
from worldjen.prompts import get_i2v_prompts, get_prompts
from worldjen.video import save_frames_as_video, save_image


@dataclass
class DimensionProgress:
    evaluated: int = 0
    failed: int = 0
    total: int = 0


@dataclass
class Progress:
    videos_total: int
    videos_evaluated: int
    per_dimension: Dict[str, DimensionProgress] = field(default_factory=dict)
    updated_at: Optional[str] = None


@dataclass
class RunResult:
    """
    Result of a ``worldjen.run(...)`` invocation.

    Attributes:
        run_id: Server-assigned run identifier (empty string on early failure).
        video_paths: Local paths of generated videos (or images if ``output_type="image"``).
        output_paths: Alias of ``video_paths``; populated for both video and image runs.
        output_dir: Directory containing the saved outputs.
        eval_results: Dimension scores keyed by dimension ID. ``None`` if ``wait_for_evals=False``.
        progress: Evaluation progress returned by the API, when available.
        status: Final run status — typically ``completed`` or ``failed``.
        error_message: Reason for failure, if any.
    """

    run_id: str
    video_paths: List[Path] = field(default_factory=list)
    output_paths: List[Path] = field(default_factory=list)
    output_dir: Optional[Path] = None
    eval_results: Optional[Dict[str, Any]] = None
    progress: Optional[Progress] = None
    status: str = "unknown"
    error_message: Optional[str] = None


def progress_from_api(raw: Any) -> Optional[Progress]:
    if not isinstance(raw, dict):
        return None
    videos_evaluated = _to_int(raw.get("videosEvaluated"))
    per_dimension: Dict[str, DimensionProgress] = {}
    raw_per_dimension = raw.get("perDimension") or {}
    if isinstance(raw_per_dimension, dict):
        for dimension_id, value in raw_per_dimension.items():
            if not isinstance(value, dict):
                continue
            per_dimension[str(dimension_id)] = DimensionProgress(
                evaluated=_to_int(value.get("evaluated")),
                failed=_to_int(value.get("failed")),
                total=_to_int(value.get("total", videos_evaluated)),
            )
    return Progress(
        videos_total=_to_int(raw.get("videosTotal")),
        videos_evaluated=videos_evaluated,
        per_dimension=per_dimension,
        updated_at=raw.get("updatedAt") if isinstance(raw.get("updatedAt"), str) else None,
    )


def _resolve_dimension_ids(dimensions: Any, mode: str = "t2v") -> List[str]:
    from worldjen.dimensions import (
        Dimensions,
        VIDEO_DIMENSIONS,
        I2V_VIDEO_DIMENSIONS,
        IMAGE_DIMENSIONS,
        BOTH_DIMENSIONS,
        _META,
    )

    def _ordered_members(selected: set[Any]) -> List[str]:
        return [member.value for member in Dimensions if member in selected]

    def _all_dimensions() -> List[str]:
        concrete = [member for member in Dimensions if member not in _META]
        if mode != "i2v":
            concrete = [member for member in concrete if member not in I2V_VIDEO_DIMENSIONS]
        return [member.value for member in concrete]

    def _all_video_dimensions() -> List[str]:
        selected = VIDEO_DIMENSIONS | BOTH_DIMENSIONS
        if mode == "i2v":
            selected |= I2V_VIDEO_DIMENSIONS
        return _ordered_members(selected)

    out: List[str] = []
    for d in dimensions:
        if isinstance(d, Dimensions):
            if d == Dimensions.ALL:
                return _all_dimensions()
            if d == Dimensions.ALL_VIDEO:
                return _all_video_dimensions()
            if d == Dimensions.ALL_IMAGE:
                return _ordered_members(IMAGE_DIMENSIONS | BOTH_DIMENSIONS)
            out.append(d.value)
        elif isinstance(d, str):
            if d == "all":
                return _all_dimensions()
            if d == "all_video":
                return _all_video_dimensions()
            if d == "all_image":
                return _ordered_members(IMAGE_DIMENSIONS | BOTH_DIMENSIONS)
            out.append(d)
        else:
            out.append(str(d))
    return out


def _validate_dimension_mode_compatibility(dimension_ids: List[str], mode: str) -> Optional[str]:
    from worldjen.dimensions import I2V_VIDEO_DIMENSIONS

    if mode == "i2v":
        return None

    invalid = [dimension.value for dimension in I2V_VIDEO_DIMENSIONS if dimension.value in dimension_ids]
    if not invalid:
        return None

    invalid_list = ", ".join(sorted(invalid))
    return (
        f"dimensions [{invalid_list}] require mode='i2v' because they need a conditioning "
        "reference image"
    )


def _normalize_frames(raw: Any) -> List[Any]:
    if raw is None:
        return []
    if hasattr(raw, "frames"):
        f = raw.frames
        if isinstance(f, list) and len(f) > 0 and isinstance(f[0], list):
            return list(f[0])
        return list(f) if isinstance(f, list) else [f]
    if hasattr(raw, "images"):
        img = raw.images
        return list(img) if isinstance(img, list) else [img]
    if isinstance(raw, np.ndarray) and raw.ndim == 4:
        return [raw[i] for i in range(raw.shape[0])]
    return list(raw) if isinstance(raw, (list, tuple)) else [raw]


@contextmanager
def _capture_stdout_stderr():
    out, err = io.StringIO(), io.StringIO()
    old_out, old_err = sys.stdout, sys.stderr
    sys.stdout = _Tee(old_out, out)
    sys.stderr = _Tee(old_err, err)
    try:
        yield out, err
    finally:
        sys.stdout, sys.stderr = old_out, old_err


class _Tee:
    def __init__(self, orig, buf):
        self._orig, self._buf = orig, buf

    def write(self, s):
        self._orig.write(s)
        return self._buf.write(s)

    def flush(self):
        self._orig.flush()

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def __getattr__(self, name):
        return getattr(self._orig, name)


def _append_log(run_id: str, message: str) -> None:
    try:
        append_run_logs(run_id, message if message.endswith("\n") else message + "\n")
    except Exception:
        pass


def _invoke_pipeline(
    pipeline: Union[Callable[..., Any], Any],
    prompt: str,
    image: Any = None,
    **kwargs: Any,
) -> List[Any]:
    call_kw: Dict[str, Any] = {"prompt": prompt, **kwargs}
    if image is not None:
        call_kw["image"] = image
    if callable(pipeline):
        out = pipeline(**call_kw)
    elif hasattr(pipeline, "generate"):
        out = pipeline.generate(**call_kw)
    elif hasattr(pipeline, "infer"):
        out = pipeline.infer(**call_kw)
    else:
        raise TypeError(
            "pipeline must be callable or have .generate() or .infer(prompt, **kwargs)"
        )
    return _normalize_frames(out)


_MIME_MAP = {
    "mp4": "video/mp4",
    "webm": "video/webm",
    "png": "image/png",
    "jpg": "image/jpeg",
    "jpeg": "image/jpeg",
    "webp": "image/webp",
    "gif": "image/gif",
}


def _content_type_for(filename: str) -> str:
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    return _MIME_MAP.get(ext, "application/octet-stream")


def _read_cache_preference_default() -> bool:
    """Return the user's stored ``cacheI2vImages`` preference. Falls back to
    ``False`` if the preference can't be fetched (e.g. unauthenticated, network
    error, or the server is older than this SDK)."""
    try:
        prefs = get_preferences()
    except Exception:
        return False
    value = prefs.get("cacheI2vImages") if isinstance(prefs, dict) else None
    return bool(value) if isinstance(value, bool) else False


def run(
    pipeline: Union[Callable[..., Any], Any],
    dimensions: Union[List[str], List[Any]],
    run_name: Optional[str] = None,
    model_id: Optional[str] = None,
    wait_for_evals: bool = True,
    output_type: str = "video",
    *,
    mode: str = "t2v",
    cache_i2v_images: Optional[bool] = None,
    reasoning_enabled: bool = False,
    **pipeline_kwargs: Any,
) -> RunResult:
    """Run a generation pipeline and upload outputs for evaluation.

    Args:
        pipeline: Callable or object with .generate()/.infer() that produces frames/images.
        dimensions: List of dimension IDs or Dimensions enum values.
        run_name: Human-readable run name.
        model_id: Optional model ID to associate with the run.
        mode: "t2v" (text-to-video) or "i2v" (image-to-video).
              In i2v mode the pipeline receives ``image`` (PIL Image) alongside ``prompt``.
        wait_for_evals: Poll until all evaluations finish (default True).
        output_type: "video" (default) or "image". Controls save format and upload MIME.
        cache_i2v_images: When ``mode="i2v"``, persist downloaded reference images
            to ``~/.worldjen/cache/i2v/`` so subsequent runs reuse them. When None
            (default), reads the ``cacheI2vImages`` flag from the user's account
            preferences (set via Web UI Settings or the ``set_preferences`` SDK
            call). Pass an explicit bool to override the preference for this run.
            A full-dimension i2v run can download >1GB of images, so keep this
            off unless you need offline reuse.
        reasoning_enabled: Store per-question evaluator reasoning and generated
            summaries for this run. Defaults to False to keep evaluation cost down.
        **pipeline_kwargs: Extra kwargs forwarded to the pipeline.
    """
    if mode not in ("t2v", "i2v"):
        raise ValueError(f"mode must be 't2v' or 'i2v', got {mode!r}")
    is_image = output_type == "image"
    dimension_ids = _resolve_dimension_ids(dimensions, mode=mode)
    if not dimension_ids:
        return RunResult(
            run_id="",
            status="failed",
            error_message="dimensions must be a non-empty list",
        )
    compatibility_error = _validate_dimension_mode_compatibility(dimension_ids, mode)
    if compatibility_error:
        return RunResult(
            run_id="",
            status="failed",
            error_message=compatibility_error,
        )

    if cache_i2v_images is None:
        cache_i2v_images = _read_cache_preference_default() if mode == "i2v" else False

    prompt_loader_name = "get_i2v_prompts" if mode == "i2v" else "get_prompts"
    try:
        if mode == "i2v":
            prompts = get_i2v_prompts(dimension_ids, cache_images=cache_i2v_images)
        else:
            prompts = get_prompts(dimension_ids)
    except Exception as e:
        return RunResult(
            run_id="",
            status="failed",
            error_message=f"{prompt_loader_name} failed: {e}",
        )

    if not prompts:
        return RunResult(
            run_id="",
            status="failed",
            error_message="No prompts returned for the given dimensions",
        )

    try:
        run_id = create_run(
            name=run_name or "sdk-run",
            dimensions=dimension_ids,
            run_instructions=pipeline_kwargs if pipeline_kwargs else None,
            model_id=model_id,
            reasoning_enabled=reasoning_enabled,
        )
        update_run_status(run_id, status="running", num_videos=len(prompts))
    except Exception as e:
        return RunResult(
            run_id="",
            status="failed",
            error_message=f"create_run failed: {e}",
        )

    total_prompts = len(prompts)
    media_label = "image" if is_image else "video"
    _append_log(
        run_id,
        f"Run started ({media_label}). Dimensions: {dimension_ids}. "
        f"Processing {total_prompts} prompt(s).",
    )

    video_dir = _config.video_dir
    output_dir = Path(video_dir) / run_id
    output_dir.mkdir(parents=True, exist_ok=True)
    output_paths: List[Path] = []

    try:
        for idx, item in enumerate(prompts):
            prompt_text = item.get("prompt", "")
            prompt_hash = item.get("prompt_hash")
            dims = item.get("dimensions", dimension_ids)
            reference_image_url = item.get("reference_image_url")
            if isinstance(dims, list) and dims:
                dim_ids = [d if isinstance(d, str) else str(d) for d in dims]
            else:
                dim_ids = dimension_ids

            prompt_preview = (prompt_text[:80] + "…") if len(prompt_text) > 80 else prompt_text
            _append_log(run_id, f"[{idx + 1}/{total_prompts}] Processing: {prompt_preview}")

            item_image = item.get("image")
            if item_image is not None:
                kw = {k: v for k, v in pipeline_kwargs.items() if k != "image"}
                kw["image"] = item_image
            else:
                kw = pipeline_kwargs
            with _capture_stdout_stderr() as (out_io, err_io):
                raw_output = _invoke_pipeline(pipeline, prompt_text, **kw)
            out_str = out_io.getvalue().strip()
            err_str = err_io.getvalue().strip()
            if out_str:
                _append_log(run_id, out_str)
            if err_str:
                _append_log(run_id, err_str)

            if raw_output is None or (hasattr(raw_output, "__len__") and len(raw_output) == 0):
                _append_log(run_id, f"Pipeline returned no output for prompt index {idx}.")
                update_run_status(
                    run_id,
                    status="failed",
                    error_message=f"Pipeline returned no output for prompt index {idx}",
                )
                return RunResult(
                    run_id=run_id,
                    video_paths=output_paths,
                    output_paths=output_paths,
                    output_dir=output_dir,
                    status="failed",
                    error_message=f"Pipeline returned no output for prompt index {idx}",
                )

            if is_image:
                single = raw_output[0] if isinstance(raw_output, list) else raw_output
                filename = f"image_{idx:04d}.png"
                out_path = output_dir / filename
                save_image(single, out_path)
                _append_log(run_id, f"Saved {filename}.")
            else:
                filename = f"video_{idx:04d}.mp4"
                out_path = output_dir / filename
                save_frames_as_video(raw_output, out_path)
                _append_log(run_id, f"Generated {len(raw_output)} frames. Saved {filename}.")

            output_paths.append(out_path)

            content_type = _content_type_for(filename)
            upload_info = get_upload_url(
                run_id,
                filename,
                content_type=content_type,
                prompt=prompt_text or None,
                prompt_hash=prompt_hash,
                dimension_ids=dim_ids,
                reference_image_url=reference_image_url,
            )
            upload_to_presigned(
                upload_info["uploadUrl"],
                out_path,
                content_type=content_type,
            )
            confirm_upload(run_id=run_id, video_id=upload_info["videoId"])
            _append_log(run_id, f"Uploaded {filename}.")

        _append_log(run_id, "Run completed.")
        update_run_status(run_id, status="completed")
    except Exception as e:
        _append_log(run_id, f"Run failed: {e}")
        update_run_status(
            run_id,
            status="failed",
            error_message=str(e),
        )
        return RunResult(
            run_id=run_id,
            video_paths=output_paths,
            output_paths=output_paths,
            output_dir=output_dir,
            status="failed",
            error_message=str(e),
        )

    eval_results: Optional[Dict[str, Any]] = None
    status = "completed"
    expected_count = len(output_paths)

    if wait_for_evals and expected_count > 0:
        _append_log(run_id, f"Waiting for evaluations ({expected_count} {media_label}(s))…")
        poll_interval = 5
        max_wait = 600
        waited = 0
        while waited < max_wait:
            run_data = get_run(run_id)
            result_data = run_data.get("resultData") or {}
            videos = result_data.get("videos") or []
            scored_count = len(videos) if isinstance(videos, list) else 0
            if run_data.get("errorMessage"):
                eval_results = result_data or run_data.get("eval_results")
                return RunResult(
                    run_id=run_id,
                    video_paths=output_paths,
                    output_paths=output_paths,
                    output_dir=output_dir,
                    eval_results=eval_results,
                    progress=progress_from_api(run_data.get("progress")),
                    status=run_data.get("status", status),
                    error_message=run_data.get("errorMessage"),
                )
            if scored_count >= expected_count:
                eval_results = result_data or run_data.get("eval_results")
                progress = progress_from_api(run_data.get("progress"))
                break
            time.sleep(poll_interval)
            waited += poll_interval
        else:
            final = get_run(run_id)
            eval_results = final.get("resultData") or final.get("eval_results")
            progress = progress_from_api(final.get("progress"))
    else:
        progress = None

    return RunResult(
        run_id=run_id,
        video_paths=output_paths,
        output_paths=output_paths,
        output_dir=output_dir,
        eval_results=eval_results,
        progress=progress,
        status=status,
    )


def _to_int(value: Any) -> int:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0
