"""Public SDK for runner inspection."""

from typing import Any, Dict, List

from worldjen._api import list_runners as _list_runners

__all__ = ["list", "list_available", "is_available"]


def list() -> List[Dict[str, Any]]:
    """List runners registered to your account."""
    return _list_runners()


def list_available() -> List[Dict[str, Any]]:
    """List runners that are registered and currently online."""
    return [runner for runner in _list_runners() if _is_runner_available(runner)]


def is_available(runner_id: str) -> bool:
    """Return True when a runner is registered and currently online."""
    for runner in _list_runners():
        current_id = str(runner.get("_id") or runner.get("id") or "")
        if current_id == runner_id:
            return _is_runner_available(runner)
    return False


def _is_runner_available(runner: Dict[str, Any]) -> bool:
    status = str(runner.get("status") or "").lower()
    return status in {"registered", "online"} and bool(runner.get("isOnline", status == "online"))
