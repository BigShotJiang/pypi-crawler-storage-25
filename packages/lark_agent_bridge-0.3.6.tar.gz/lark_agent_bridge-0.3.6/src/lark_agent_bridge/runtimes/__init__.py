"""Runtime adapters (CoPaw, OpenClaw)."""
