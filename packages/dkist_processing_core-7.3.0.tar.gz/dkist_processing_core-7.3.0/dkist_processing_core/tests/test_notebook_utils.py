"""Tests for the notebook_utils module"""

from pathlib import Path
from uuid import uuid4

import nbformat
import pytest
from nbformat.v4 import new_code_cell
from nbformat.v4 import new_markdown_cell
from nbformat.v4 import new_notebook
from nbformat.v4 import new_output

from dkist_processing_core.notebook_utils import export_notebook_by_path
from dkist_processing_core.notebook_utils import wait_for_notebook_save


@pytest.fixture
def notebook_path_factory(tmp_path: Path):
    def _make_notebook(*, cells=None) -> Path:
        notebook_path = tmp_path / "test.ipynb"
        cells = cells or []
        nb = new_notebook(cells=cells)
        with notebook_path.open("w", encoding="utf-8") as f:
            nbformat.write(nb, f)
        return notebook_path

    return _make_notebook


@pytest.fixture
def notebook_sentinel() -> str:
    return uuid4().hex


@pytest.fixture
def notebook_with_sentinel_output(notebook_path_factory, notebook_sentinel) -> Path:
    return notebook_path_factory(
        cells=[
            new_markdown_cell("# Title"),
            new_code_cell(
                source="print('ready')",
                outputs=[
                    new_output(
                        output_type="stream",
                        name="stdout",
                        text=f"before {notebook_sentinel} after",
                    )
                ],
            ),
        ]
    )


@pytest.fixture
def notebook_without_sentinel_output(notebook_path_factory) -> Path:
    return notebook_path_factory(
        cells=[
            new_code_cell(
                source="print('not ready')",
                outputs=[
                    new_output(
                        output_type="stream",
                        name="stdout",
                        text="some other output",
                    )
                ],
            )
        ]
    )


def test_wait_for_notebook_save_succeeds_when_sentinel_in_code_cell_output(
    notebook_with_sentinel_output, notebook_sentinel
):
    # no error raised
    wait_for_notebook_save(
        notebook_with_sentinel_output, sentinel=notebook_sentinel, attempts=1, delay_s=0
    )


def test_wait_for_notebook_save_times_out_when_sentinel_missing(
    notebook_without_sentinel_output,
):
    with pytest.raises(TimeoutError, match="Notebook did not save updated outputs in time"):
        wait_for_notebook_save(notebook_without_sentinel_output, attempts=1, delay_s=0)


def test_export_notebook_by_path_returns_markdown_bytes(
    notebook_with_sentinel_output, notebook_sentinel
) -> None:
    exported = export_notebook_by_path(notebook_with_sentinel_output)

    assert isinstance(exported, bytes)

    output = exported.decode("utf-8")

    assert "# Title" in output  # markdown
    assert "print('ready')" in output  # code
    assert notebook_sentinel in output  # output
