"""Utilities for working with the notebook execution environment."""

import time
from pathlib import Path
from uuid import uuid4

import nbformat
from nbconvert import MarkdownExporter


def wait_for_notebook_save(
    notebook_path: Path,
    sentinel: str | None = None,
    attempts: int = 120,
    delay_s: int = 1,
) -> None:
    """
    Wait until the notebook on disk contains the sentinel output.

    Parameters
    ----------
    notebook_path
        The path to the notebook file to check for the sentinel output.

    sentinel
        The string to search for in the notebook outputs to confirm that the notebook has been saved with the expected output.

    attempts
        The number of times to check the notebook for the sentinel output before giving up and raising a
        TimeoutError.

    delay_s
        The number of seconds to wait between attempts to check the notebook for the sentinel output.

    Returns
    -------
    None if the sentinel is found within the notebook outputs, otherwise raises a TimeoutError after the specified number of attempts.
    """
    sentinel = sentinel or uuid4().hex

    print(f"Waiting for notebook to save with sentinel '{sentinel}'...", flush=True)

    for _ in range(attempts):
        text = notebook_path.read_text(encoding="utf-8")
        if sentinel in text:
            return
        time.sleep(delay_s)

    raise TimeoutError("Notebook did not save updated outputs in time")


def export_notebook_by_path(notebook_path: Path) -> bytes:
    """
    Export the notebook at the given path to markdown format and return the resulting bytes.

    Parameters
    ----------
    notebook_path
        The path to the notebook file to export.

    Returns
    -------
    The exported notebook in markdown format as bytes.
    """
    notebook = nbformat.read(notebook_path, as_version=nbformat.NO_CONVERT)

    exporter = MarkdownExporter()
    body, _ = exporter.from_notebook_node(notebook)
    return body.encode("utf-8")
