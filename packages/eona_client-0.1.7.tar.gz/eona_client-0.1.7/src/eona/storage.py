from __future__ import annotations

import json
import sqlite3
import tempfile
import hashlib
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from eona.runtime import _ensure_layout, get_runtime_paths

SCHEMA_VERSION = 3
DB_FILENAME = "eona.db"
CONFIG_FILENAME = "config.json"
STATE_FILENAME = "state.json"
RUN_STATE_FILENAME = "run-state.json"
LEGACY_ROOT_GROUP_HASH = "__legacy_global__"


@dataclass(frozen=True)
class StoragePaths:
    root: Path
    database: Path
    config_file: Path
    state_file: Path
    run_state_file: Path
    run_artifacts_dir: Path


PROJECT_STATE_BUILDING = "Building"
PROJECT_STATE_NOT_IMPORTED = "Not Imported Yet"
PROJECT_STATE_NEEDS_ATTENTION = "Needs Attention"
PROJECT_STATE_REIMPORT_SUGGESTED = "Re-import Suggested"
PROJECT_STATE_STABLE = "Stable"


def get_storage_paths() -> StoragePaths:
    runtime_paths = get_runtime_paths()
    return StoragePaths(
        root=runtime_paths.root,
        database=runtime_paths.root / DB_FILENAME,
        config_file=runtime_paths.config / CONFIG_FILENAME,
        state_file=runtime_paths.config / STATE_FILENAME,
        run_state_file=runtime_paths.config / RUN_STATE_FILENAME,
        run_artifacts_dir=runtime_paths.root / "run-artifacts",
    )


def _utc_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _default_config() -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "authorized_capability": {
            "cadis": None,
            "exiftool": None,
        },
    }


def _default_state() -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "index_status": "idle",
        "last_index_time": None,
        "indexed_count": 0,
        "last_completed_run_at": None,
    }


def default_run_state(*, daemon_id: str | None = None) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "daemon_id": daemon_id,
        "active_run_id": None,
        "active_job_type": None,
        "run_started_at": None,
        "current_state": "IDLE",
        "recovering": False,
        "current_file": None,
        "current_content_id": None,
        "processed": 0,
        "total_estimated": None,
        "selection_summary": None,
        "pause_requested": False,
        "stop_requested": False,
        "cadis_capability": None,
        "exiftool_capability": None,
        "daemon_runtime_manifest_hash": None,
        "last_run_artifact_path": None,
        "last_run_terminal_state": None,
        "last_run_job_type": None,
    }


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _atomic_write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        "w",
        encoding="utf-8",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        handle.write(content)
        temp_path = Path(handle.name)
    temp_path.replace(path)


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    _atomic_write_text(path, json.dumps(payload, indent=2, sort_keys=True) + "\n")


def serialize_cadis_payload(payload: Any) -> str:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def normalize_root_paths(root_paths: tuple[Path | str, ...]) -> tuple[Path, ...]:
    return tuple(Path(path).expanduser().resolve() for path in root_paths)


def derive_root_group_hash(root_paths: tuple[Path | str, ...]) -> str:
    normalized = sorted({str(path) for path in normalize_root_paths(root_paths)})
    payload = "\n".join(normalized).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _row_to_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if row is None:
        return None
    return {str(key): row[key] for key in row.keys()}


def _connect_database(database_path: Path) -> sqlite3.Connection:
    connection = sqlite3.connect(database_path)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def _create_schema(connection: sqlite3.Connection) -> None:
    connection.executescript(
        """
        CREATE TABLE IF NOT EXISTS schema_version (
            version INTEGER PRIMARY KEY,
            applied_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS contents (
            id INTEGER PRIMARY KEY,
            md5 TEXT NOT NULL UNIQUE,
            file_size INTEGER NOT NULL,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS files (
            id INTEGER PRIMARY KEY,
            root_group_hash TEXT NOT NULL,
            content_id INTEGER NOT NULL REFERENCES contents(id),
            file_path TEXT NOT NULL,
            mtime_ns INTEGER NOT NULL,
            missing INTEGER NOT NULL DEFAULT 0 CHECK (missing IN (0, 1)),
            first_seen_at TEXT NOT NULL,
            last_seen_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS image_facts (
            content_id INTEGER PRIMARY KEY REFERENCES contents(id),
            taken_at_utc TEXT,
            taken_at_original TEXT,
            mime_type TEXT,
            width INTEGER,
            height INTEGER,
            orientation INTEGER,
            last_processed_snapshot_version INTEGER
        );

        CREATE TABLE IF NOT EXISTS image_camera (
            content_id INTEGER PRIMARY KEY REFERENCES contents(id),
            make TEXT,
            model TEXT,
            lens TEXT,
            focal_length_mm REAL,
            aperture REAL,
            iso INTEGER,
            shutter_speed TEXT
        );

        CREATE TABLE IF NOT EXISTS image_location (
            content_id INTEGER PRIMARY KEY REFERENCES contents(id),
            raw_latitude REAL,
            raw_longitude REAL,
            raw_altitude REAL,
            cadis_result_json TEXT,
            cadis_version TEXT,
            last_processed_snapshot_version INTEGER,
            CHECK (cadis_result_json IS NULL OR cadis_version IS NOT NULL)
        );

        CREATE TABLE IF NOT EXISTS system_capability (
            snapshot_version INTEGER PRIMARY KEY,
            updated_time TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS import_runs (
            run_id TEXT PRIMARY KEY,
            root_group_hash TEXT NOT NULL,
            snapshot_version INTEGER NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT,
            status TEXT NOT NULL CHECK (status IN ('queued', 'running', 'completed', 'failed', 'cancelled')),
            error_code TEXT,
            rows_evaluated INTEGER NOT NULL DEFAULT 0,
            rows_mutated INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS project_import_state (
            root_group_hash TEXT PRIMARY KEY,
            last_snapshot_version INTEGER NOT NULL,
            last_import_time TEXT NOT NULL,
            last_import_status TEXT NOT NULL CHECK (last_import_status IN ('stable', 'failed')),
            impairment_reason TEXT
        );

        CREATE TABLE IF NOT EXISTS import_suggestions (
            suggestion_id TEXT PRIMARY KEY,
            root_group_hash TEXT NOT NULL,
            snapshot_version INTEGER NOT NULL,
            suggestion_type TEXT NOT NULL,
            payload_hash TEXT NOT NULL,
            created_time TEXT NOT NULL,
            UNIQUE(root_group_hash, snapshot_version, suggestion_type, payload_hash)
        );

        CREATE UNIQUE INDEX IF NOT EXISTS idx_contents_md5 ON contents(md5);
        CREATE UNIQUE INDEX IF NOT EXISTS idx_files_root_path ON files(root_group_hash, file_path);
        CREATE INDEX IF NOT EXISTS idx_files_content_id ON files(content_id);
        CREATE INDEX IF NOT EXISTS idx_files_root_content ON files(root_group_hash, content_id);
        CREATE INDEX IF NOT EXISTS idx_files_root_missing ON files(root_group_hash, missing);
        CREATE INDEX IF NOT EXISTS idx_files_path_lookup ON files(file_path);
        CREATE INDEX IF NOT EXISTS idx_files_root_group_hash ON files(root_group_hash);
        CREATE INDEX IF NOT EXISTS idx_import_runs_root_status ON import_runs(root_group_hash, status, start_time);
        CREATE INDEX IF NOT EXISTS idx_project_import_state_snapshot ON project_import_state(last_snapshot_version);
        """
    )


def _table_columns(connection: sqlite3.Connection, table: str) -> set[str]:
    rows = connection.execute(f"PRAGMA table_info({table})").fetchall()
    return {str(row["name"]) for row in rows}


def _migrate_schema(connection: sqlite3.Connection) -> None:
    file_columns = _table_columns(connection, "files")
    if "root_group_hash" not in file_columns:
        connection.execute("ALTER TABLE files ADD COLUMN root_group_hash TEXT")

    _migrate_files_table(connection)

    facts_columns = _table_columns(connection, "image_facts")
    if "last_processed_snapshot_version" not in facts_columns:
        connection.execute("ALTER TABLE image_facts ADD COLUMN last_processed_snapshot_version INTEGER")

    location_columns = _table_columns(connection, "image_location")
    if "last_processed_snapshot_version" not in location_columns:
        connection.execute("ALTER TABLE image_location ADD COLUMN last_processed_snapshot_version INTEGER")

    _create_schema(connection)
    connection.execute(
        """
        INSERT INTO system_capability(snapshot_version, updated_time)
        SELECT 0, ?
        WHERE NOT EXISTS (SELECT 1 FROM system_capability)
        """,
        (_utc_now(),),
    )


def _migrate_files_table(connection: sqlite3.Connection) -> None:
    connection.execute("DROP INDEX IF EXISTS idx_files_path")
    connection.execute("DROP INDEX IF EXISTS idx_files_missing")
    file_columns = _table_columns(connection, "files")
    files_sql_row = connection.execute(
        "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'files'"
    ).fetchone()
    files_sql = str(files_sql_row["sql"]) if files_sql_row is not None and files_sql_row["sql"] else ""

    needs_rebuild = (
        "root_group_hash" not in file_columns
        or "root_group_hash TEXT NOT NULL" not in files_sql
        or "file_path TEXT NOT NULL UNIQUE" in files_sql
    )

    if not needs_rebuild:
        connection.execute(
            "UPDATE files SET root_group_hash = ? WHERE root_group_hash IS NULL OR root_group_hash = ''",
            (LEGACY_ROOT_GROUP_HASH,),
        )
        return

    connection.execute(
        """
        CREATE TABLE files_v3 (
            id INTEGER PRIMARY KEY,
            root_group_hash TEXT NOT NULL,
            content_id INTEGER NOT NULL REFERENCES contents(id),
            file_path TEXT NOT NULL,
            mtime_ns INTEGER NOT NULL,
            missing INTEGER NOT NULL DEFAULT 0 CHECK (missing IN (0, 1)),
            first_seen_at TEXT NOT NULL,
            last_seen_at TEXT NOT NULL,
            UNIQUE(root_group_hash, file_path)
        )
        """
    )
    connection.execute(
        """
        INSERT INTO files_v3(
            id,
            root_group_hash,
            content_id,
            file_path,
            mtime_ns,
            missing,
            first_seen_at,
            last_seen_at
        )
        SELECT
            id,
            COALESCE(NULLIF(root_group_hash, ''), ?),
            content_id,
            file_path,
            mtime_ns,
            missing,
            first_seen_at,
            last_seen_at
        FROM files
        """,
        (LEGACY_ROOT_GROUP_HASH,),
    )
    connection.execute("DROP TABLE files")
    connection.execute("ALTER TABLE files_v3 RENAME TO files")


def _initialize_database_file(database_path: Path) -> tuple[bool, str]:
    database_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        "w",
        encoding="utf-8",
        dir=database_path.parent,
        prefix=f".{database_path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        temp_path = Path(handle.name)

    try:
        with _connect_database(temp_path) as connection:
            _create_schema(connection)
            _migrate_schema(connection)
            connection.execute(
                "INSERT INTO schema_version(version, applied_at) VALUES(?, ?)",
                (SCHEMA_VERSION, _utc_now()),
            )
            connection.commit()
        temp_path.replace(database_path)
    finally:
        if temp_path.exists():
            temp_path.unlink()

    return True, f"Recorded schema version {SCHEMA_VERSION}."


def _ensure_schema_version(connection: sqlite3.Connection) -> tuple[bool, str]:
    rows = connection.execute("SELECT version FROM schema_version ORDER BY version").fetchall()
    if not rows:
        connection.execute(
            "INSERT INTO schema_version(version, applied_at) VALUES(?, ?)",
            (SCHEMA_VERSION, _utc_now()),
        )
        return True, f"Recorded schema version {SCHEMA_VERSION}."
    current_version = int(rows[-1]["version"])
    if current_version > SCHEMA_VERSION:
        raise RuntimeError(
            "database schema version mismatch: "
            f"expected at most version {SCHEMA_VERSION} but found {current_version}"
        )
    if current_version < SCHEMA_VERSION:
        _migrate_schema(connection)
        connection.execute("DELETE FROM schema_version")
        connection.execute(
            "INSERT INTO schema_version(version, applied_at) VALUES(?, ?)",
            (SCHEMA_VERSION, _utc_now()),
        )
        return True, f"Migrated schema to version {SCHEMA_VERSION}."
    _migrate_schema(connection)
    return False, f"Schema version {SCHEMA_VERSION} already recorded."


def initialize_storage(force: bool = False) -> dict[str, Any]:
    runtime_paths = get_runtime_paths()
    storage_paths = get_storage_paths()
    created_layout = _ensure_layout(runtime_paths)
    details: list[str] = []

    if created_layout:
        details.append(f"Ensured Eona layout under {runtime_paths.root}.")
    else:
        details.append(f"Eona layout already present under {runtime_paths.root}.")

    config_created = force or not storage_paths.config_file.exists()
    if config_created:
        _write_json(storage_paths.config_file, _default_config())
        details.append(f"Wrote config file to {storage_paths.config_file}.")
    else:
        config = _read_json(storage_paths.config_file)
        if config.get("schema_version") != SCHEMA_VERSION:
            raise RuntimeError(
                f"config schema_version mismatch at {storage_paths.config_file}: "
                f"expected {SCHEMA_VERSION}"
            )
        details.append(f"Config file already present at {storage_paths.config_file}.")

    state_created = force or not storage_paths.state_file.exists()
    if state_created:
        _write_json(storage_paths.state_file, _default_state())
        details.append(f"Wrote state file to {storage_paths.state_file}.")
    else:
        state = _read_json(storage_paths.state_file)
        if state.get("schema_version") != SCHEMA_VERSION:
            raise RuntimeError(
                f"state schema_version mismatch at {storage_paths.state_file}: "
                f"expected {SCHEMA_VERSION}"
            )
        details.append(f"State file already present at {storage_paths.state_file}.")

    run_state_created = force or not storage_paths.run_state_file.exists()
    if run_state_created:
        _write_json(storage_paths.run_state_file, default_run_state())
        details.append(f"Wrote run-state file to {storage_paths.run_state_file}.")
    else:
        run_state = _read_json(storage_paths.run_state_file)
        if run_state.get("schema_version", SCHEMA_VERSION) != SCHEMA_VERSION:
            raise RuntimeError(
                f"run-state schema_version mismatch at {storage_paths.run_state_file}: "
                f"expected {SCHEMA_VERSION}"
            )
        details.append(f"Run-state file already present at {storage_paths.run_state_file}.")

    db_existed = storage_paths.database.exists()
    if force or not db_existed:
        version_created, version_message = _initialize_database_file(storage_paths.database)
        if force and db_existed:
            details.append(f"Recreated SQLite database at {storage_paths.database}.")
        else:
            details.append(f"Created SQLite database at {storage_paths.database}.")
    else:
        with _connect_database(storage_paths.database) as connection:
            _create_schema(connection)
            version_created, version_message = _ensure_schema_version(connection)
            connection.commit()
        details.append(f"SQLite database already present at {storage_paths.database}.")
    details.append(version_message)

    return {
        "ok": True,
        "summary": "Eona schema initialization completed.",
        "details": details,
        "paths": {
            "database": str(storage_paths.database),
            "config": str(storage_paths.config_file),
            "state": str(storage_paths.state_file),
        },
        "changed": (
            config_created
            or state_created
            or run_state_created
            or (not db_existed)
            or version_created
            or bool(created_layout)
        ),
    }


def _require_initialized_file(path: Path, label: str) -> dict[str, Any]:
    if not path.is_file():
        raise RuntimeError(f"{label} missing at {path}; run 'eona schema init' first")
    return _read_json(path)


def read_config() -> dict[str, Any]:
    config = _require_initialized_file(get_storage_paths().config_file, "config")
    config.setdefault("authorized_capability", {"cadis": None, "exiftool": None})
    return config


def write_config(payload: dict[str, Any]) -> None:
    payload["schema_version"] = SCHEMA_VERSION
    payload.setdefault("authorized_capability", {"cadis": None, "exiftool": None})
    _write_json(get_storage_paths().config_file, payload)


def update_config(**changes: Any) -> dict[str, Any]:
    config = read_config()
    config.update(changes)
    write_config(config)
    return config


def read_state() -> dict[str, Any]:
    return _require_initialized_file(get_storage_paths().state_file, "state")


def write_state(payload: dict[str, Any]) -> None:
    payload["schema_version"] = SCHEMA_VERSION
    _write_json(get_storage_paths().state_file, payload)


def update_state(**changes: Any) -> dict[str, Any]:
    state = read_state()
    state.update(changes)
    write_state(state)
    return state


def read_run_state() -> dict[str, Any]:
    storage_paths = get_storage_paths()
    if not storage_paths.run_state_file.is_file():
        payload = default_run_state()
        _write_json(storage_paths.run_state_file, payload)
        return payload
    payload = _read_json(storage_paths.run_state_file)
    payload.setdefault("schema_version", SCHEMA_VERSION)
    return payload


def write_run_state(payload: dict[str, Any]) -> None:
    payload["schema_version"] = SCHEMA_VERSION
    _write_json(get_storage_paths().run_state_file, payload)


def update_run_state(**changes: Any) -> dict[str, Any]:
    run_state = read_run_state()
    run_state.update(changes)
    write_run_state(run_state)
    return run_state


def write_run_artifact(run_id: str, payload: dict[str, Any]) -> Path:
    storage_paths = get_storage_paths()
    storage_paths.run_artifacts_dir.mkdir(parents=True, exist_ok=True)
    path = storage_paths.run_artifacts_dir / f"{run_id}.json"
    _write_json(path, payload)
    return path


def set_authorized_capability(*, cadis: dict[str, Any] | None, exiftool: dict[str, Any] | None) -> dict[str, Any]:
    config = read_config()
    config["authorized_capability"] = {
        "cadis": None if cadis is None else dict(cadis),
        "exiftool": None if exiftool is None else dict(exiftool),
    }
    write_config(config)
    return config["authorized_capability"]


def current_snapshot_version(*, connection: sqlite3.Connection | None = None) -> int:
    if connection is not None:
        row = connection.execute(
            "SELECT snapshot_version FROM system_capability ORDER BY snapshot_version DESC LIMIT 1"
        ).fetchone()
        return int(row["snapshot_version"]) if row is not None else 0

    initialize_storage(force=False)
    with _connect_database(get_storage_paths().database) as owned_connection:
        row = owned_connection.execute(
            "SELECT snapshot_version FROM system_capability ORDER BY snapshot_version DESC LIMIT 1"
        ).fetchone()
        return int(row["snapshot_version"]) if row is not None else 0


def advance_snapshot_version() -> int:
    initialize_storage(force=False)
    with _connect_database(get_storage_paths().database) as connection:
        next_version = current_snapshot_version(connection=connection) + 1
        connection.execute(
            "INSERT INTO system_capability(snapshot_version, updated_time) VALUES(?, ?)",
            (next_version, _utc_now()),
        )
        connection.commit()
    return next_version


def create_import_run(*, run_id: str, root_group_hash: str, snapshot_version: int) -> dict[str, Any]:
    initialize_storage(force=False)
    payload = {
        "run_id": run_id,
        "root_group_hash": root_group_hash,
        "snapshot_version": snapshot_version,
        "start_time": _utc_now(),
        "end_time": None,
        "status": "queued",
        "error_code": None,
        "rows_evaluated": 0,
        "rows_mutated": 0,
    }
    with _connect_database(get_storage_paths().database) as connection:
        connection.execute(
            """
            INSERT INTO import_runs(
                run_id,
                root_group_hash,
                snapshot_version,
                start_time,
                end_time,
                status,
                error_code,
                rows_evaluated,
                rows_mutated
            ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                payload["run_id"],
                payload["root_group_hash"],
                payload["snapshot_version"],
                payload["start_time"],
                payload["end_time"],
                payload["status"],
                payload["error_code"],
                payload["rows_evaluated"],
                payload["rows_mutated"],
            ),
        )
        connection.commit()
    return payload


def update_import_run(
    run_id: str,
    *,
    status: str | None = None,
    error_code: str | None = None,
    rows_evaluated: int | None = None,
    rows_mutated: int | None = None,
    end_time: str | None = None,
) -> dict[str, Any]:
    initialize_storage(force=False)
    changes: dict[str, Any] = {}
    if status is not None:
        changes["status"] = status
    if error_code is not None:
        changes["error_code"] = error_code
    if rows_evaluated is not None:
        changes["rows_evaluated"] = int(rows_evaluated)
    if rows_mutated is not None:
        changes["rows_mutated"] = int(rows_mutated)
    if end_time is not None:
        changes["end_time"] = end_time
    if not changes:
        return get_import_run(run_id)

    assignments = ", ".join(f"{column} = ?" for column in changes)
    params = [*changes.values(), run_id]
    with _connect_database(get_storage_paths().database) as connection:
        cursor = connection.execute(f"UPDATE import_runs SET {assignments} WHERE run_id = ?", params)
        if cursor.rowcount != 1:
            raise RuntimeError(f"import run not found: {run_id}")
        row = connection.execute("SELECT * FROM import_runs WHERE run_id = ?", (run_id,)).fetchone()
        connection.commit()
    return _row_to_dict(row) or {}


def get_import_run(run_id: str) -> dict[str, Any]:
    initialize_storage(force=False)
    with _connect_database(get_storage_paths().database) as connection:
        row = connection.execute("SELECT * FROM import_runs WHERE run_id = ?", (run_id,)).fetchone()
    if row is None:
        raise RuntimeError(f"import run not found: {run_id}")
    return _row_to_dict(row) or {}


def latest_import_run(root_group_hash: str, *, statuses: tuple[str, ...] | None = None) -> dict[str, Any] | None:
    initialize_storage(force=False)
    query = "SELECT * FROM import_runs WHERE root_group_hash = ?"
    params: list[Any] = [root_group_hash]
    if statuses:
        placeholders = ", ".join("?" for _ in statuses)
        query += f" AND status IN ({placeholders})"
        params.extend(statuses)
    query += " ORDER BY start_time DESC LIMIT 1"
    with _connect_database(get_storage_paths().database) as connection:
        row = connection.execute(query, params).fetchone()
    return _row_to_dict(row)


def set_project_import_state(
    *,
    root_group_hash: str,
    snapshot_version: int,
    import_time: str | None = None,
    import_status: str,
    impairment_reason: str | None,
) -> dict[str, Any]:
    initialize_storage(force=False)
    recorded_at = import_time or _utc_now()
    with _connect_database(get_storage_paths().database) as connection:
        connection.execute(
            """
            INSERT INTO project_import_state(
                root_group_hash,
                last_snapshot_version,
                last_import_time,
                last_import_status,
                impairment_reason
            ) VALUES(?, ?, ?, ?, ?)
            ON CONFLICT(root_group_hash) DO UPDATE SET
                last_snapshot_version = excluded.last_snapshot_version,
                last_import_time = excluded.last_import_time,
                last_import_status = excluded.last_import_status,
                impairment_reason = excluded.impairment_reason
            """,
            (root_group_hash, snapshot_version, recorded_at, import_status, impairment_reason),
        )
        row = connection.execute(
            "SELECT * FROM project_import_state WHERE root_group_hash = ?",
            (root_group_hash,),
        ).fetchone()
        connection.commit()
    return _row_to_dict(row) or {}


def get_project_import_state(root_group_hash: str) -> dict[str, Any] | None:
    initialize_storage(force=False)
    with _connect_database(get_storage_paths().database) as connection:
        row = connection.execute(
            "SELECT * FROM project_import_state WHERE root_group_hash = ?",
            (root_group_hash,),
        ).fetchone()
    return _row_to_dict(row)


def record_import_suggestion(
    *,
    suggestion_id: str,
    root_group_hash: str,
    snapshot_version: int,
    suggestion_type: str,
    payload_hash: str,
    created_time: str | None = None,
) -> dict[str, Any]:
    initialize_storage(force=False)
    recorded_at = created_time or _utc_now()
    with _connect_database(get_storage_paths().database) as connection:
        connection.execute(
            """
            INSERT OR IGNORE INTO import_suggestions(
                suggestion_id,
                root_group_hash,
                snapshot_version,
                suggestion_type,
                payload_hash,
                created_time
            ) VALUES(?, ?, ?, ?, ?, ?)
            """,
            (suggestion_id, root_group_hash, snapshot_version, suggestion_type, payload_hash, recorded_at),
        )
        row = connection.execute(
            """
            SELECT *
            FROM import_suggestions
            WHERE root_group_hash = ?
              AND snapshot_version = ?
              AND suggestion_type = ?
              AND payload_hash = ?
            """,
            (root_group_hash, snapshot_version, suggestion_type, payload_hash),
        ).fetchone()
        connection.commit()
    return _row_to_dict(row) or {}


def list_import_suggestions(root_group_hash: str, *, snapshot_version: int | None = None) -> list[dict[str, Any]]:
    initialize_storage(force=False)
    query = "SELECT * FROM import_suggestions WHERE root_group_hash = ?"
    params: list[Any] = [root_group_hash]
    if snapshot_version is not None:
        query += " AND snapshot_version = ?"
        params.append(snapshot_version)
    query += " ORDER BY created_time DESC, suggestion_id DESC"
    with _connect_database(get_storage_paths().database) as connection:
        rows = connection.execute(query, params).fetchall()
    return [_row_to_dict(row) or {} for row in rows]


def get_project_operational_state(root_group_hash: str) -> dict[str, Any]:
    initialize_storage(force=False)
    with _connect_database(get_storage_paths().database) as connection:
        active_run = connection.execute(
            """
            SELECT *
            FROM import_runs
            WHERE root_group_hash = ?
              AND status = 'running'
            ORDER BY start_time DESC
            LIMIT 1
            """,
            (root_group_hash,),
        ).fetchone()
        latest_snapshot = current_snapshot_version(connection=connection)
        terminal_state = connection.execute(
            "SELECT * FROM project_import_state WHERE root_group_hash = ?",
            (root_group_hash,),
        ).fetchone()

    if active_run is not None:
        return {
            "project_state": PROJECT_STATE_BUILDING,
            "active_run": _row_to_dict(active_run),
            "project_import_state": _row_to_dict(terminal_state),
            "snapshot_version": latest_snapshot,
        }

    if terminal_state is None:
        return {
            "project_state": PROJECT_STATE_NOT_IMPORTED,
            "active_run": None,
            "project_import_state": None,
            "snapshot_version": latest_snapshot,
        }

    terminal_payload = _row_to_dict(terminal_state) or {}
    if terminal_payload["last_import_status"] == "failed":
        project_state = PROJECT_STATE_NEEDS_ATTENTION
    elif latest_snapshot > int(terminal_payload["last_snapshot_version"]):
        project_state = PROJECT_STATE_REIMPORT_SUGGESTED
    else:
        project_state = PROJECT_STATE_STABLE

    return {
        "project_state": project_state,
        "active_run": None,
        "project_import_state": terminal_payload,
        "snapshot_version": latest_snapshot,
    }


def get_project_status_for_roots(root_paths: tuple[Path | str, ...]) -> dict[str, Any]:
    normalized_roots = normalize_root_paths(root_paths)
    root_group_hash = derive_root_group_hash(tuple(normalized_roots))
    project_status = get_project_operational_state(root_group_hash)
    project_status["root_group_hash"] = root_group_hash
    project_status["root_paths"] = [str(path) for path in normalized_roots]
    project_status["latest_run"] = latest_import_run(root_group_hash)
    project_status["suggestions"] = list_import_suggestions(
        root_group_hash,
        snapshot_version=project_status.get("snapshot_version"),
    )
    return project_status


def get_status() -> dict[str, Any]:
    storage_paths = get_storage_paths()
    details: list[str] = []
    errors: list[str] = []

    config: dict[str, Any] | None = None
    schema_version: int | None = None
    snapshot_version: int | None = None
    active_run_count = 0

    if storage_paths.database.is_file():
        try:
            with _connect_database(storage_paths.database) as connection:
                row = connection.execute("SELECT version FROM schema_version").fetchone()
                if row is None:
                    errors.append(f"database: schema_version missing in {storage_paths.database}")
                else:
                    schema_version = int(row["version"])
                    details.append(f"database: present at {storage_paths.database}")
                    details.append(f"database schema_version: {schema_version}")
                    snapshot_version = current_snapshot_version(connection=connection)
                    details.append(f"capability snapshot_version: {snapshot_version}")
                    active_run_count = int(
                        connection.execute(
                            "SELECT COUNT(*) AS count FROM import_runs WHERE status = 'running'"
                        ).fetchone()["count"]
                    )
                    details.append(f"active import runs: {active_run_count}")
        except sqlite3.DatabaseError as exc:
            errors.append(f"database: unreadable at {storage_paths.database} ({exc})")
    else:
        errors.append(f"database: missing at {storage_paths.database}")

    if storage_paths.config_file.is_file():
        config = _read_json(storage_paths.config_file)
        details.append(f"config: present at {storage_paths.config_file}")
    else:
        errors.append(f"config: missing at {storage_paths.config_file}")

    if config is not None:
        if config.get("schema_version") != SCHEMA_VERSION:
            errors.append(
                f"config schema_version: expected {SCHEMA_VERSION} but found {config.get('schema_version')}"
            )

    if schema_version is not None and schema_version != SCHEMA_VERSION:
        errors.append(f"database schema_version: expected {SCHEMA_VERSION} but found {schema_version}")

    ok = not errors
    return {
        "ok": ok,
        "summary": "Eona status is healthy." if ok else "Eona status check failed.",
        "details": details + errors,
        "status": {
            "database": str(storage_paths.database),
            "snapshot_version": snapshot_version,
            "active_import_runs": active_run_count,
            "config": config,
            "schema_version": schema_version,
        },
    }
