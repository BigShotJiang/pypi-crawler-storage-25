from __future__ import annotations

import os
import signal
import subprocess
import sys

from eona.artifact_validation import earliest_invalid_or_incomplete_stage
from eona.errors import EonaCancelRequested, EonaCliError
from eona.run_state_machine import (
    STAGES,
    create_run_state,
    reset_from_stage,
    set_run_cancelled,
    set_run_cancelling,
    set_stage_failed,
    set_stage_running,
)
from eona.stages import execute_stage
from eona.workspace_runs import (
    WorkspaceRunPaths,
    create_run_dir,
    ensure_input_path,
    ensure_workspace,
    generate_run_id,
    read_run_json,
    run_paths,
    utc_now,
    write_run_json,
)

_WORKER_CANCEL_SIGNAL = False


def create_run(*, photo_path: str, workspace_dir: str) -> dict[str, object]:
    input_path = ensure_input_path(photo_path)
    workspace = ensure_workspace(workspace_dir)
    run_id = generate_run_id()
    paths = run_paths(workspace=workspace, run_id=run_id)
    create_run_dir(paths)
    started_at = utc_now()
    run_state = create_run_state(
        run_id=run_id,
        input_path=str(input_path),
        workspace=str(workspace),
        started_at=started_at,
    )
    write_run_json(paths, run_state)
    start_worker(paths)
    return {
        "status": "started",
        "run_id": run_id,
        "workspace": str(workspace),
        "input_path": str(input_path),
        "started_at": started_at,
    }


def get_status(*, run_id: str, workspace_dir: str) -> dict[str, object]:
    workspace = ensure_workspace(workspace_dir)
    paths = run_paths(workspace=workspace, run_id=run_id)
    run_state = read_run_json(paths)
    if str(run_state["status"]) == "cancelling" and not worker_is_active(paths):
        run_state = finalize_cancelled_run(paths=paths, run_state=run_state)
    return {
        "run_id": str(run_state["run_id"]),
        "status": str(run_state["status"]),
        "stage": run_state.get("current_stage"),
        "progress": float(run_state["progress"]),
        "photos_processed": int(run_state.get("photos_processed", 0)),
        "photos_total": int(run_state.get("photos_total", 0)),
        "started_at": run_state.get("started_at"),
        "updated_at": run_state.get("updated_at"),
        "error_code": run_state.get("error_code"),
    }


def cancel_run(*, run_id: str, workspace_dir: str) -> dict[str, object]:
    workspace = ensure_workspace(workspace_dir)
    paths = run_paths(workspace=workspace, run_id=run_id)
    run_state = read_run_json(paths)
    current_status = str(run_state["status"])
    if current_status == "cancelled":
        raise EonaCliError("RUN_ALREADY_CANCELLED", "Run is already cancelled")
    if current_status == "complete":
        raise EonaCliError("RUN_NOT_CANCELLABLE", "Completed run cannot be cancelled")
    if current_status == "failed":
        raise EonaCliError("RUN_NOT_CANCELLABLE", "Run cannot be cancelled in its current state")

    requested_at = utc_now()
    if current_status != "cancelling":
        run_state = set_run_cancelling(run_state, requested_at=requested_at)
        write_run_json(paths, run_state)

    if not request_worker_stop(paths):
        raise EonaCliError("CANCEL_FAILED", "Unable to stop active worker")

    if not worker_is_active(paths):
        run_state = finalize_cancelled_run(paths=paths, run_state=read_run_json(paths))

    return {
        "status": str(run_state["status"]),
        "run_id": run_id,
        "requested_at": requested_at,
        "stage": run_state.get("current_stage"),
        "previous_status": current_status,
    }


def resume_run(*, run_id: str, workspace_dir: str) -> dict[str, object]:
    workspace = ensure_workspace(workspace_dir)
    paths = run_paths(workspace=workspace, run_id=run_id)
    run_state = read_run_json(paths)
    if str(run_state["status"]) in {"complete", "cancelled", "cancelling"}:
        raise EonaCliError("RUN_NOT_RESUMABLE", "Run cannot be resumed")
    if worker_is_active(paths):
        raise EonaCliError("RUN_NOT_RESUMABLE", "Run cannot be resumed while a worker is active")
    stage = earliest_invalid_or_incomplete_stage(paths=paths, run_state=run_state)
    if stage is None:
        raise EonaCliError("RUN_NOT_RESUMABLE", "Run cannot be resumed")
    previous_payload = run_state["stages"][stage]
    rewind_reason = "incomplete_stage"
    if previous_payload.get("state") == "complete":
        rewind_reason = "invalid_artifact"
    elif previous_payload.get("state") == "failed":
        rewind_reason = "failed_stage"
    updated = reset_from_stage(run_state, stage=stage, updated_at=utc_now())
    write_run_json(paths, updated)
    start_worker(paths)
    return {
        "status": "resumed",
        "run_id": run_id,
        "stage": stage,
        "rewind_reason": rewind_reason,
        "restarted_from_stage": stage,
        "resumed_at": utc_now(),
    }


def start_worker(paths: WorkspaceRunPaths) -> None:
    log_handle = paths.pipeline_log.open("a", encoding="utf-8")
    env = dict(os.environ)
    pythonpath = env.get("PYTHONPATH")
    src_path = str(__import__("pathlib").Path(__file__).resolve().parents[2] / "src")
    env["PYTHONPATH"] = f"{src_path}{os.pathsep}{pythonpath}" if pythonpath else src_path
    subprocess.Popen(
        [
            sys.executable,
            "-m",
            "eona",
            "_run-worker",
            paths.run_dir.name,
            "--workspace",
            str(paths.workspace),
        ],
        stdout=log_handle,
        stderr=log_handle,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
        env=env,
    )


def worker_is_active(paths: WorkspaceRunPaths) -> bool:
    if not paths.lock_file.exists():
        return False
    try:
        raw_pid = paths.lock_file.read_text(encoding="utf-8").strip()
        pid = int(raw_pid)
    except (OSError, ValueError):
        paths.lock_file.unlink(missing_ok=True)
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        paths.lock_file.unlink(missing_ok=True)
        return False
    except PermissionError:
        return True
    return True


def request_worker_stop(paths: WorkspaceRunPaths) -> bool:
    if not paths.lock_file.exists():
        return True
    try:
        pid = int(paths.lock_file.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        paths.lock_file.unlink(missing_ok=True)
        return True
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        paths.lock_file.unlink(missing_ok=True)
        return True
    except PermissionError as exc:
        raise EonaCliError("CANCEL_FAILED", f"Unable to stop active worker: {exc}") from exc
    except OSError as exc:
        raise EonaCliError("CANCEL_FAILED", f"Unable to stop active worker: {exc}") from exc
    return True


def finalize_cancelled_run(*, paths: WorkspaceRunPaths, run_state: dict[str, object]) -> dict[str, object]:
    stage = current_or_running_stage(run_state)
    updated = set_run_cancelled(run_state, stage=stage, cancelled_at=utc_now())
    write_run_json(paths, updated)
    return updated


def current_or_running_stage(run_state: dict[str, object]) -> str | None:
    current_stage = run_state.get("current_stage")
    if isinstance(current_stage, str):
        return current_stage
    for stage in STAGES:
        if run_state["stages"][stage]["state"] == "running":
            return stage
    return None


def run_worker(*, run_id: str, workspace_dir: str) -> int:
    global _WORKER_CANCEL_SIGNAL
    _WORKER_CANCEL_SIGNAL = False
    workspace = ensure_workspace(workspace_dir)
    paths = run_paths(workspace=workspace, run_id=run_id)
    if worker_is_active(paths):
        return 0
    paths.lock_file.write_text(str(os.getpid()), encoding="utf-8")
    previous_handler = signal.getsignal(signal.SIGTERM)
    signal.signal(signal.SIGTERM, _handle_worker_sigterm)
    try:
        run_state = read_run_json(paths)
        for stage in STAGES:
            run_state = read_run_json(paths)
            if _worker_cancel_requested(run_state):
                finalize_cancelled_run(paths=paths, run_state=run_state)
                return 0
            if run_state["stages"][stage]["state"] == "complete":
                continue
            run_state = set_stage_running(run_state, stage=stage, started_at=utc_now())
            write_run_json(paths, run_state)
            try:
                run_state = execute_stage(paths=paths, run_state=run_state, stage=stage)
            except EonaCancelRequested:
                finalize_cancelled_run(paths=paths, run_state=read_run_json(paths))
                return 0
            except EonaCliError as exc:
                run_state = set_stage_failed(
                    run_state,
                    stage=stage,
                    failed_at=utc_now(),
                    error_code=exc.error_code,
                    error_message=exc.message,
                )
                write_run_json(paths, run_state)
                return 1
            except Exception as exc:
                run_state = set_stage_failed(
                    run_state,
                    stage=stage,
                    failed_at=utc_now(),
                    error_code=_stage_error_code(stage),
                    error_message=str(exc),
                )
                write_run_json(paths, run_state)
                return 1
            write_run_json(paths, run_state)
        return 0
    finally:
        signal.signal(signal.SIGTERM, previous_handler)
        paths.lock_file.unlink(missing_ok=True)


def _stage_error_code(stage: str) -> str:
    return {
        "SCANNING": "SCANNING_FAILED",
        "METADATA_EXTRACTION": "METADATA_EXTRACTION_FAILED",
        "CADIS_LOOKUP": "CADIS_LOOKUP_FAILED",
        "SQLITE_WRITE": "SQLITE_WRITE_FAILED",
    }[stage]


def _handle_worker_sigterm(signum: int, frame: object) -> None:
    del signum, frame
    global _WORKER_CANCEL_SIGNAL
    _WORKER_CANCEL_SIGNAL = True


def _worker_cancel_requested(run_state: dict[str, object]) -> bool:
    return _WORKER_CANCEL_SIGNAL or str(run_state.get("status")) == "cancelling"
