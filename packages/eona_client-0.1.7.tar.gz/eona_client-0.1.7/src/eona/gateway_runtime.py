from __future__ import annotations

import importlib.metadata
import json
import os
import hashlib
import platform
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from eona.env_compat import compat_env, compat_env_truthy
from eona.gateway_image_support import register_gateway_image_support
from eona.runtime import get_runtime_paths, load_contract


@dataclass(frozen=True)
class GatewayRuntimePaths:
    image_root: Path
    app_root: Path
    venv_root: Path
    runtime_root: Path
    metadata_dir: Path
    manifest_path: Path
    exiftool_root: Path
    exiftool_executable: Path
    cadis_root: Path
    cadis_dataset_root: Path


def get_gateway_runtime_paths() -> GatewayRuntimePaths:
    configured_root = compat_env("EONA_GATEWAY_IMAGE_ROOT")
    if configured_root:
        image_root = Path(configured_root).expanduser().resolve()
    else:
        container_root = Path("/opt/eona")
        image_root = container_root if container_root.exists() else get_runtime_paths().root
    runtime_root = image_root / "runtime"
    return GatewayRuntimePaths(
        image_root=image_root,
        app_root=image_root / "app",
        venv_root=image_root / "venv",
        runtime_root=runtime_root,
        metadata_dir=runtime_root / "metadata",
        manifest_path=runtime_root / "metadata" / "runtime-manifest.json",
        exiftool_root=runtime_root / "tools" / "exiftool",
        exiftool_executable=runtime_root / "tools" / "exiftool" / "exiftool",
        cadis_root=runtime_root / "cadis",
        cadis_dataset_root=runtime_root / "cadis" / "datasets",
    )


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _gateway_runtime_paths_for_root(image_root: Path) -> GatewayRuntimePaths:
    runtime_root = image_root / "runtime"
    return GatewayRuntimePaths(
        image_root=image_root,
        app_root=image_root / "app",
        venv_root=image_root / "venv",
        runtime_root=runtime_root,
        metadata_dir=runtime_root / "metadata",
        manifest_path=runtime_root / "metadata" / "runtime-manifest.json",
        exiftool_root=runtime_root / "tools" / "exiftool",
        exiftool_executable=runtime_root / "tools" / "exiftool" / "exiftool",
        cadis_root=runtime_root / "cadis",
        cadis_dataset_root=runtime_root / "cadis" / "datasets",
    )


def _gateway_manifest_source_path() -> Path:
    installed_template = get_runtime_paths().runtime / "metadata" / "runtime-manifest-template.json"
    if installed_template.is_file():
        return installed_template
    return _repo_root() / "contracts" / "runtime-manifest-template.json"


def _gateway_datasets_source_path() -> Path:
    # Datasets are already provisioned to the final location by runtime bootstrap
    return get_gateway_runtime_paths().cadis_dataset_root


def _discover_dataset_entries(datasets_root: Path) -> list[dict[str, str]]:
    entries: list[dict[str, str]] = []
    seen_iso2: set[str] = set()
    for manifest_path in sorted(datasets_root.glob("*/*/*/dataset_release_manifest.json")):
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
        country_iso = payload.get("country_iso")
        dataset_id = payload.get("dataset_id")
        dataset_version = payload.get("dataset_version")
        if not all(isinstance(value, str) and value for value in (country_iso, dataset_id, dataset_version)):
            raise ValueError(f"Dataset manifest missing identity fields: {manifest_path}")
        normalized_iso2 = country_iso.upper()
        if normalized_iso2 in seen_iso2:
            raise ValueError(f"Multiple dataset releases found for ISO2 {normalized_iso2} under {datasets_root}")
        seen_iso2.add(normalized_iso2)
        entries.append(
            {
                "country_iso": normalized_iso2,
                "dataset_id": dataset_id,
                "dataset_version": dataset_version,
            }
        )
    return sorted(entries, key=lambda item: (item["country_iso"], item["dataset_id"], item["dataset_version"]))


def _build_dataset_bundle_section(*, datasets_root: Path, image_datasets_path: str) -> dict[str, Any]:
    datasets = _discover_dataset_entries(datasets_root)
    payload_bytes = json.dumps(datasets, sort_keys=True, separators=(",", ":")).encode("utf-8")
    bundle_digest = f"sha256:{hashlib.sha256(payload_bytes).hexdigest()}"
    return {
        "version": f"generated-{bundle_digest.split(':', 1)[1][:12]}",
        "path": image_datasets_path,
        "required_iso2": [item["country_iso"] for item in datasets],
        "datasets": datasets,
        "bundle_digest": bundle_digest,
    }


def _template_python_package_version(payload: dict[str, Any], package_name: str) -> str | None:
    packages = payload.get("python_packages")
    if not isinstance(packages, list):
        return None
    normalized_name = package_name.strip().lower()
    for package in packages:
        if not isinstance(package, dict):
            continue
        name = package.get("name")
        version = package.get("version")
        if isinstance(name, str) and name.strip().lower() == normalized_name and isinstance(version, str) and version:
            return version
    return None


def build_gateway_runtime_manifest(
    *,
    image_root: Path,
    template_path: Path | None = None,
    eona_version_override: str | None = None,
) -> dict[str, Any]:
    payload = json.loads((template_path or _gateway_manifest_source_path()).read_text(encoding="utf-8"))
    paths = _gateway_runtime_paths_for_root(image_root)
    exiftool = payload.get("tools", {}).get("exiftool", {})
    cadis_version = _template_python_package_version(payload, "cadis")
    return {
        "runtime_version": payload.get("runtime_version"),
        "eona_version": eona_version_override or payload.get("eona_version"),
        "python_version": payload.get("python_version"),
        "platform": {
            "os": platform.system().lower(),
            "arch": platform.machine().lower(),
        },
        "tools": {
            "exiftool": {
                "version": exiftool.get("version"),
                "executable_path": "runtime/tools/exiftool/exiftool",
            }
        },
        "python_packages": {
            "cadis": {
                "version": cadis_version,
            }
        },
        "dataset_bundle": _build_dataset_bundle_section(
            datasets_root=paths.cadis_dataset_root,
            image_datasets_path="runtime/cadis/datasets",
        ),
    }


def write_gateway_runtime_manifest(
    *,
    image_root: Path,
    force: bool = False,
    template_path: Path | None = None,
    eona_version_override: str | None = None,
) -> dict[str, Any]:
    paths = _gateway_runtime_paths_for_root(image_root)
    if paths.manifest_path.exists() and not force:
        return json.loads(paths.manifest_path.read_text(encoding="utf-8"))
    paths.metadata_dir.mkdir(parents=True, exist_ok=True)
    payload = build_gateway_runtime_manifest(
        image_root=image_root,
        template_path=template_path,
        eona_version_override=eona_version_override,
    )
    paths.manifest_path.write_text(json.dumps(payload, indent=2, sort_keys=False) + "\n", encoding="utf-8")
    return payload


def bootstrap_gateway_runtime(*, force: bool = False) -> dict[str, Any]:
    runtime_paths = get_runtime_paths()
    gateway_paths = get_gateway_runtime_paths()
    contract = load_contract()

    venv_pip = runtime_paths.root / str(contract["venv"]["pip_executable_relative_path"])
    if not venv_pip.is_file():
        return {
            "ok": False,
            "summary": "Gateway local runtime bootstrap failed.",
            "details": [
                f"Eona runtime venv is missing at {venv_pip}.",
                "Run `eona runtime bootstrap` first.",
            ],
        }

    manifest_source = _gateway_manifest_source_path()
    datasets_source = _gateway_datasets_source_path()
    if not manifest_source.is_file():
        return {
            "ok": False,
            "summary": "Gateway local runtime bootstrap failed.",
            "details": [f"Gateway runtime manifest template missing at {manifest_source}. Run `eona runtime bootstrap` first."],
        }
    if not datasets_source.is_dir():
        return {
            "ok": False,
            "summary": "Gateway local runtime bootstrap failed.",
            "details": [f"Gateway dataset bundle missing at {datasets_source}. Run `eona runtime bootstrap` first."],
        }

    details: list[str] = []
    metadata_dir = gateway_paths.metadata_dir
    metadata_dir.mkdir(parents=True, exist_ok=True)
    gateway_paths.cadis_dataset_root.parent.mkdir(parents=True, exist_ok=True)

    if force:
        shutil.rmtree(gateway_paths.cadis_dataset_root, ignore_errors=True)

    manifest_payload = write_gateway_runtime_manifest(
        image_root=gateway_paths.image_root,
        force=True,
        template_path=manifest_source,
    )
    details.append(f"Wrote Gateway runtime manifest to {gateway_paths.manifest_path}.")

    # In hermetic mode, datasets are already in place. We only verify they exist.
    details.append(f"Verified Gateway datasets under {gateway_paths.cadis_dataset_root}.")

    missing_packages: list[str] = []
    for package_name in ("cadis", "Pillow", "pillow-heif", "pyvips"):
        try:
            subprocess.run(
                [
                    str(venv_pip.parent / "python"),
                    "-c",
                    f"import importlib.metadata; importlib.metadata.version({package_name!r})",
                ],
                check=True,
                capture_output=True,
                text=True,
            )
        except subprocess.CalledProcessError:
            missing_packages.append(package_name)
    if missing_packages:
        return {
            "ok": False,
            "summary": "Gateway local runtime bootstrap failed.",
            "details": [
                "Eona runtime is missing required Gateway Python packages.",
                f"Missing packages: {', '.join(missing_packages)}",
                "Run `eona runtime bootstrap` with the current sealed runtime artifacts.",
            ],
        }
    details.append("Verified required Gateway Python dependencies are already present in the local Eona runtime venv.")

    return {
        "ok": True,
        "summary": "Gateway local runtime bootstrap completed.",
        "details": details,
        "paths": {
            "image_root": str(gateway_paths.image_root),
            "manifest": str(gateway_paths.manifest_path),
            "datasets": str(gateway_paths.cadis_dataset_root),
        },
    }


def load_gateway_runtime_manifest() -> dict[str, Any] | None:
    manifest_path = get_gateway_runtime_paths().manifest_path
    if not manifest_path.is_file():
        return None
    return json.loads(manifest_path.read_text(encoding="utf-8"))


def _resolve_manifest_path(value: str | None, *, default: Path) -> Path:
    if not value:
        return default
    candidate = Path(value)
    if candidate.is_absolute():
        return candidate
    return (get_gateway_runtime_paths().image_root / candidate).resolve()


def resolve_gateway_exiftool_path() -> Path | None:
    manifest = load_gateway_runtime_manifest() or {}
    tools = manifest.get("tools")
    if isinstance(tools, dict):
        exiftool = tools.get("exiftool")
        if isinstance(exiftool, dict):
            executable_path = exiftool.get("executable_path")
            candidate = _resolve_manifest_path(executable_path if isinstance(executable_path, str) else None, default=get_gateway_runtime_paths().exiftool_executable)
            if candidate.exists():
                return candidate
    env_override = compat_env("EONA_GATEWAY_EXIFTOOL")
    if env_override:
        candidate = Path(env_override).expanduser().resolve()
        if candidate.exists():
            return candidate
    return None


def _installed_distribution_version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def _requested_canonical_backend() -> str:
    return (compat_env("EONA_GATEWAY_CANONICAL_BACKEND", default="auto") or "auto").strip().lower() or "auto"


def _inspect_pyvips_runtime() -> dict[str, Any]:
    payload: dict[str, Any] = {
        "status": "missing",
        "version": _installed_distribution_version("pyvips"),
        "libvips_version": None,
        "heif_loader": False,
    }
    try:
        import pyvips  # type: ignore
    except Exception as exc:
        payload["error"] = str(exc)
        return payload
    try:
        payload["libvips_version"] = ".".join(str(int(pyvips.version(index))) for index in range(3))
    except Exception:
        payload["libvips_version"] = None
    heif_loader = False
    try:
        for operation_name in ("heifload", "heifload_source", "heifload_buffer"):
            heif_loader = bool(pyvips.type_find("VipsOperation", operation_name))
            if heif_loader:
                break
    except Exception:
        heif_loader = False
    payload["heif_loader"] = heif_loader
    payload["status"] = "ok"
    return payload


def _runtime_identity_from_manifest(
    *,
    manifest: dict[str, Any] | None,
    runtime_image_digest: str | None,
    canonical_backend_effective: str,
    cadis_version: str | None,
) -> dict[str, Any]:
    from eona.gateway_canonicalize import PILLOW_CANONICAL_SPEC_VERSION, VIPS_CANONICAL_SPEC_VERSION

    tools = manifest.get("tools") if isinstance(manifest, dict) else {}
    python_packages = manifest.get("python_packages") if isinstance(manifest, dict) else {}
    dataset_bundle = manifest.get("dataset_bundle") if isinstance(manifest, dict) else {}
    exiftool = tools.get("exiftool") if isinstance(tools, dict) else {}
    cadis_package = python_packages.get("cadis") if isinstance(python_packages, dict) else {}
    canonical_spec_version = (
        VIPS_CANONICAL_SPEC_VERSION
        if canonical_backend_effective == "vips"
        else PILLOW_CANONICAL_SPEC_VERSION
    )
    return {
        "runtime_version": manifest.get("runtime_version") if isinstance(manifest, dict) else None,
        "runtime_image_digest": runtime_image_digest,
        "exiftool_version": exiftool.get("version") if isinstance(exiftool, dict) else None,
        "cadis_version": (
            cadis_package.get("version")
            if isinstance(cadis_package, dict) and cadis_package.get("version")
            else cadis_version
        ),
        "cadis_dataset_bundle_version": dataset_bundle.get("version") if isinstance(dataset_bundle, dict) else None,
        "cadis_dataset_bundle_digest": dataset_bundle.get("bundle_digest") if isinstance(dataset_bundle, dict) else None,
        "canonical_backend": canonical_backend_effective,
        "canonical_spec_version": canonical_spec_version,
    }


def env_truthy(name: str, *, default: bool = False) -> bool:
    return compat_env_truthy(name, default=default)


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _discover_dataset_manifests(dataset_root: Path) -> tuple[list[dict[str, Any]], list[str]]:
    installed: list[dict[str, Any]] = []
    problems: list[str] = []
    if not dataset_root.exists():
        return installed, problems

    for manifest_path in sorted(dataset_root.glob("*/*/*/dataset_release_manifest.json")):
        try:
            payload = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception as exc:
            problems.append(f"invalid dataset manifest at {manifest_path}: {exc}")
            continue

        dataset_id = payload.get("dataset_id")
        country_iso = payload.get("country_iso")
        dataset_version = payload.get("dataset_version")
        if not all(isinstance(item, str) and item for item in (dataset_id, country_iso, dataset_version)):
            problems.append(f"dataset manifest missing identity fields at {manifest_path}")
            continue

        files = ((payload.get("checksums") or {}).get("files") or {})
        if not isinstance(files, dict):
            problems.append(f"dataset manifest has invalid checksum section at {manifest_path}")
            continue

        release_dir = manifest_path.parent
        file_problems: list[str] = []
        for filename, metadata in sorted(files.items()):
            if not isinstance(metadata, dict):
                file_problems.append(f"{filename}: invalid checksum metadata")
                continue
            candidate = release_dir / filename
            if not candidate.is_file():
                file_problems.append(f"{filename}: missing")
                continue
            expected_sha = metadata.get("sha256")
            if isinstance(expected_sha, str) and expected_sha:
                actual_sha = _sha256_file(candidate)
                if actual_sha != expected_sha:
                    file_problems.append(f"{filename}: sha256 mismatch")
            expected_size = metadata.get("size")
            if isinstance(expected_size, int) and candidate.stat().st_size != expected_size:
                file_problems.append(f"{filename}: size mismatch")

        installed.append(
            {
                "country_iso": country_iso.upper(),
                "dataset_id": dataset_id,
                "dataset_version": dataset_version,
                "manifest_path": str(manifest_path),
                "status": "ok" if not file_problems else "invalid",
                "problems": file_problems,
            }
        )
        for problem in file_problems:
            problems.append(f"{country_iso.upper()} {dataset_id} {dataset_version}: {problem}")

    return installed, problems


def inspect_gateway_runtime(*, strict: bool = False) -> dict[str, Any]:
    try:
        from PIL import Image

        configured_root = compat_env("EONA_GATEWAY_IMAGE_ROOT")
        container_root = Path("/opt/eona")
        source_tree_mode = not configured_root and not container_root.exists()

        image_support = register_gateway_image_support()
        Image.init()
        paths = get_gateway_runtime_paths()
        manifest = load_gateway_runtime_manifest()
        if source_tree_mode and manifest is None:
            return {
                "ok": True,
                "summary": "Gateway runtime check skipped in source-tree mode.",
                "details": [],
                "warnings": ["Gateway runtime image is not configured; source-tree mode skips sealed-runtime validation."],
                "lifecycle_state": "ready",
                "runtime_version": None,
                "runtime_image_digest": None,
                "runtime_identity": {},
                "image_root": str(paths.image_root),
                "manifest_path": str(paths.manifest_path),
                "dependencies": {},
            }
        manifest_ok = manifest is not None

        runtime_version = None
        dataset_version = None
        dataset_path = paths.cadis_dataset_root
        required_iso2: tuple[str, ...] = ()
        if manifest:
            runtime_version = manifest.get("runtime_version")
            dataset_bundle = manifest.get("dataset_bundle")
            if isinstance(dataset_bundle, dict):
                dataset_version = dataset_bundle.get("version")
                dataset_path_value = dataset_bundle.get("path")
                dataset_path = _resolve_manifest_path(
                    dataset_path_value if isinstance(dataset_path_value, str) else None,
                    default=paths.cadis_dataset_root,
                )
                raw_required_iso2 = dataset_bundle.get("required_iso2")
                if isinstance(raw_required_iso2, list):
                    required_iso2 = tuple(
                        str(item).strip().upper()
                        for item in raw_required_iso2
                        if isinstance(item, str) and item.strip()
                    )

        exiftool_path = resolve_gateway_exiftool_path()
        exiftool_ok = exiftool_path is not None and exiftool_path.is_file() and os.access(exiftool_path, os.X_OK)
        cadis_version = _installed_distribution_version("cadis")
        cadis_ok = cadis_version is not None
        pillow_heif_version = _installed_distribution_version("pillow-heif")
        pillow_heif_ok = pillow_heif_version is not None
        pyvips_runtime = _inspect_pyvips_runtime()
        pyvips_ok = pyvips_runtime["status"] == "ok"
        canonical_backend_requested = _requested_canonical_backend()
        canonical_backend_effective = (
            "vips"
            if canonical_backend_requested in {"auto", "vips"} and pyvips_ok
            else "pillow"
        )
        heif_decoder_ok = bool(image_support.get("heif")) and any(
            str(key).upper() in {"HEIF", "HEIC"} for key in Image.OPEN.keys()
        )
        vips_heif_ok = bool(pyvips_runtime.get("heif_loader"))
        dataset_ok = dataset_path.exists() and dataset_path.is_dir()
        installed_datasets, dataset_problems = _discover_dataset_manifests(dataset_path)
        installed_iso2 = tuple(sorted({item["country_iso"] for item in installed_datasets if item.get("status") == "ok"}))
        missing_required_iso2 = tuple(sorted(code for code in required_iso2 if code not in installed_iso2))

        problems: list[str] = []
        if not manifest_ok:
            problems.append(f"runtime manifest missing at {paths.manifest_path}")
        if not exiftool_ok:
            problems.append("bundled exiftool is missing or not executable")
        if not cadis_ok:
            problems.append("cadis is not installed in the runtime environment")
        if canonical_backend_effective == "pillow" and not pillow_heif_ok:
            problems.append("pillow-heif is not installed in the runtime environment")
        if canonical_backend_effective == "pillow" and not heif_decoder_ok:
            problems.append("HEIC/HEIF decoding is not enabled in the runtime environment")
        if canonical_backend_requested == "vips" and not pyvips_ok:
            problems.append("EONA_GATEWAY_CANONICAL_BACKEND=vips but pyvips/libvips is not available.")
        if canonical_backend_effective == "vips" and not vips_heif_ok:
            problems.append("libvips HEIC/HEIF decoding is not enabled in the runtime environment")
        if strict and not dataset_ok:
            problems.append(f"dataset bundle missing at {dataset_path}")
        problems.extend(dataset_problems)
        if strict and required_iso2 and missing_required_iso2:
            problems.append(f"required datasets missing for ISO2: {', '.join(missing_required_iso2)}")

        warnings: list[str] = []
        runtime_image_digest = compat_env("EONA_GATEWAY_IMAGE_DIGEST")
        if not runtime_image_digest:
            warnings.append(
                "runtime image digest is not set; production deployments should pass EONA_GATEWAY_IMAGE_DIGEST."
            )
        runtime_identity = _runtime_identity_from_manifest(
            manifest=manifest,
            runtime_image_digest=runtime_image_digest,
            canonical_backend_effective=canonical_backend_effective,
            cadis_version=cadis_version,
        )

        if problems:
            lifecycle_state = "blocked"
            ok = False
            summary = "Gateway runtime check failed."
            details = list(problems)
        elif warnings:
            lifecycle_state = "needs_attention"
            ok = True
            summary = "Gateway runtime check passed with warnings."
            details = list(warnings)
        else:
            lifecycle_state = "ready"
            ok = True
            summary = "Gateway runtime check passed."
            details = []

        return {
            "ok": ok,
            "summary": summary,
            "details": details,
            "warnings": warnings,
            "lifecycle_state": lifecycle_state,
            "runtime_version": runtime_version,
            "runtime_image_digest": runtime_image_digest,
            "runtime_identity": runtime_identity,
            "image_root": str(paths.image_root),
            "manifest_path": str(paths.manifest_path),
            "dependencies": {
                "canonical_backend": {
                    "requested": canonical_backend_requested,
                    "effective": canonical_backend_effective,
                },
                "runtime_manifest": {
                    "status": "ok" if manifest_ok else "missing",
                    "path": str(paths.manifest_path),
                },
                "exiftool": {
                    "status": "ok" if exiftool_ok else "missing",
                    "path": str(exiftool_path) if exiftool_path else None,
                },
                "cadis": {
                    "status": "ok" if cadis_ok else "missing",
                    "version": cadis_version,
                },
                "pillow_heif": {
                    "status": "ok" if pillow_heif_ok else "missing",
                    "version": pillow_heif_version,
                },
                "heif_decoder": {
                    "status": "ok" if heif_decoder_ok else "missing",
                    "registered_formats": sorted(
                        str(key) for key in Image.OPEN.keys() if str(key).upper() in {"HEIF", "HEIC"}
                    ),
                },
                "pyvips": pyvips_runtime,
            },
            "dataset_bundle": {
                "status": "ok" if dataset_ok else "missing",
                "version": dataset_version,
                "path": str(dataset_path),
                "required_iso2": list(required_iso2),
                "installed_iso2": list(installed_iso2),
                "installed_datasets": installed_datasets,
            },
            "problems": problems,
        }
    except Exception as exc:
        paths = get_gateway_runtime_paths()
        return {
            "ok": False,
            "summary": "Gateway runtime check failed.",
            "details": [f"runtime inspection failed: {exc}"],
            "warnings": [],
            "lifecycle_state": "failed",
            "runtime_version": None,
            "runtime_image_digest": compat_env("EONA_GATEWAY_IMAGE_DIGEST"),
            "runtime_identity": {},
            "image_root": str(paths.image_root),
            "manifest_path": str(paths.manifest_path),
            "dependencies": {},
            "dataset_bundle": {
                "status": "unknown",
                "version": None,
                "path": str(paths.cadis_dataset_root),
                "required_iso2": [],
                "installed_iso2": [],
                "installed_datasets": [],
            },
            "problems": [f"runtime inspection failed: {exc}"],
        }
