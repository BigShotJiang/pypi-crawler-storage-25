from __future__ import annotations

import html
from typing import Any


def render_home_page(*, runs: list[dict[str, Any]], import_error: str | None = None) -> str:
    error_block = (
        f'<p class="error">{html.escape(import_error)}</p>'
        if import_error
        else ""
    )
    run_cards = "\n".join(_render_run_card(run) for run in runs) or '<p class="empty">No imports yet.</p>'
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Eona Gateway</title>
  <style>
    :root {{
      --bg: #f4efe6;
      --panel: #fffaf2;
      --ink: #2c241c;
      --muted: #77695a;
      --line: #d8c8b5;
      --accent: #a4512b;
      --accent-dark: #7f3f20;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      font-family: Georgia, "Times New Roman", serif;
      color: var(--ink);
      background:
        radial-gradient(circle at top left, #f7dcc0, transparent 28rem),
        linear-gradient(180deg, #f7f0e7 0%, var(--bg) 100%);
      min-height: 100vh;
    }}
    main {{
      max-width: 1080px;
      margin: 0 auto;
      padding: 2rem 1rem 3rem;
    }}
    h1 {{
      margin: 0 0 .4rem;
      font-size: clamp(2rem, 4vw, 3.4rem);
      letter-spacing: -.03em;
    }}
    p.lead {{
      margin: 0 0 2rem;
      color: var(--muted);
      max-width: 44rem;
      line-height: 1.5;
    }}
    .grid {{
      display: grid;
      grid-template-columns: minmax(0, 1.1fr) minmax(18rem, .9fr);
      gap: 1rem;
    }}
    .panel {{
      background: color-mix(in srgb, var(--panel) 92%, white);
      border: 1px solid var(--line);
      border-radius: 1.2rem;
      padding: 1.25rem;
      box-shadow: 0 12px 30px rgba(88, 57, 32, 0.08);
    }}
    .stack {{
      display: grid;
      gap: .9rem;
    }}
    .field-note {{
      margin: 0;
      font-size: .88rem;
      color: var(--muted);
      line-height: 1.45;
    }}
    .hidden-input {{
      position: absolute;
      width: 1px;
      height: 1px;
      padding: 0;
      margin: -1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border: 0;
    }}
    label {{
      display: grid;
      gap: .35rem;
      font-size: .95rem;
      color: var(--muted);
    }}
    textarea {{
      width: 100%;
      border: 1px solid var(--line);
      border-radius: .85rem;
      padding: .8rem .9rem;
      background: white;
      color: var(--ink);
      font: inherit;
    }}
    .dropzone {{
      border: 1px dashed var(--line);
      border-radius: 1rem;
      padding: 1.1rem;
      background: rgba(255,255,255,.75);
      display: grid;
      gap: .8rem;
    }}
    .dropzone.active {{
      border-color: var(--accent);
      background: rgba(255,255,255,.95);
      box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--accent) 50%, white);
    }}
    .dropzone-actions {{
      display: flex;
      gap: .75rem;
      flex-wrap: wrap;
      align-items: center;
    }}
    .secondary-button {{
      appearance: none;
      border: 1px solid var(--line);
      border-radius: 999px;
      background: white;
      color: var(--ink);
      padding: .75rem 1rem;
      font: inherit;
      cursor: pointer;
    }}
    .secondary-button:hover {{
      border-color: var(--accent);
      color: var(--accent-dark);
    }}
    .selection-summary {{
      margin: 0;
      color: var(--muted);
      min-height: 1.4rem;
    }}
    .progress-stack {{
      display: grid;
      gap: .45rem;
    }}
    .progress-bar {{
      height: .7rem;
      border-radius: 999px;
      overflow: hidden;
      background: rgba(119, 105, 90, 0.18);
    }}
    .progress-bar > span {{
      display: block;
      height: 100%;
      width: 0%;
      background: linear-gradient(90deg, #d07b46, #a4512b);
      transition: width .18s ease;
    }}
    .status-line {{
      margin: 0;
      color: var(--muted);
      font-size: .92rem;
      min-height: 1.35rem;
    }}
    .selection-list {{
      margin: 0;
      padding-left: 1.1rem;
      color: var(--muted);
      font-size: .92rem;
      display: grid;
      gap: .25rem;
    }}
    textarea {{ min-height: 6.5rem; resize: vertical; }}
    button {{
      appearance: none;
      border: 0;
      border-radius: 999px;
      background: var(--accent);
      color: white;
      padding: .9rem 1.2rem;
      font: inherit;
      cursor: pointer;
    }}
    button:hover {{ background: var(--accent-dark); }}
    .run-list {{
      display: grid;
      gap: .8rem;
    }}
    .run-card {{
      display: grid;
      gap: .35rem;
      padding: 1rem;
      border-radius: 1rem;
      border: 1px solid var(--line);
      background: rgba(255,255,255,.65);
      text-decoration: none;
      color: inherit;
    }}
    .run-meta {{
      display: flex;
      justify-content: space-between;
      gap: .8rem;
      flex-wrap: wrap;
      color: var(--muted);
      font-size: .92rem;
    }}
    .status {{
      display: inline-flex;
      align-items: center;
      gap: .4rem;
      font-size: .82rem;
      text-transform: uppercase;
      letter-spacing: .06em;
      color: var(--accent-dark);
    }}
    .empty, .error {{
      margin: 0;
      padding: 1rem;
      border-radius: .9rem;
      background: rgba(255,255,255,.6);
    }}
    .error {{
      color: #8a1f1f;
      border: 1px solid #d2a0a0;
    }}
    @media (max-width: 820px) {{
      .grid {{ grid-template-columns: 1fr; }}
    }}
  </style>
</head>
<body>
  <main>
    <h1>Eona Gateway</h1>
    <p class="lead">Collect photos into the single substrate, let the backend continue processing after commit, and return later to inspect progress or the final import report.</p>
    {error_block}
    <div class="grid">
      <section class="panel">
        <h2>Start Import</h2>
        <form class="stack" method="post" action="/ui/import" enctype="multipart/form-data" id="import-form">
          <input class="hidden-input" id="folder-input" type="file" name="file" multiple webkitdirectory directory accept=".jpg,.jpeg,.heic,.heif,image/jpeg,image/heic,image/heif">
          <label>
            Drop Zone
            <div class="dropzone" id="dropzone" tabindex="0" role="button" aria-describedby="dropzone-note">
              <p class="selection-summary" id="selection-summary">Drag and drop a folder here, or choose a folder from disk.</p>
              <div class="dropzone-actions">
                <button type="button" class="secondary-button" id="choose-folder">Choose Folder</button>
              </div>
              <ul class="selection-list" id="selection-list"></ul>
            </div>
          </label>
          <p class="field-note" id="dropzone-note">Folder drop works best in Chromium-based browsers. Accepted formats are `.jpg`, `.jpeg`, `.heic`, and `.heif`.</p>
          <label>
            Path Hint
            <textarea name="path_hint" placeholder="/Users/name/Pictures/Trip/IMG_0001.JPG&#10;Optional. If provided, the same hint is attached to imported files in this form submission."></textarea>
          </label>
          <div class="progress-stack">
            <div class="progress-bar" aria-hidden="true"><span id="import-progress-bar"></span></div>
            <p class="status-line" id="import-status">No import in progress.</p>
          </div>
          <button type="submit" id="import-submit">Import And Commit</button>
          <p class="field-note">Import And Commit always starts a new import run from scratch. Interrupted runs do not resume automatically.</p>
        </form>
      </section>
      <section class="panel">
        <h2>Recent Runs</h2>
        <div class="run-list">
          {run_cards}
        </div>
      </section>
    </div>
  </main>
  <script>
    const form = document.getElementById("import-form");
    const dropzone = document.getElementById("dropzone");
    const folderInput = document.getElementById("folder-input");
    const chooseFolderButton = document.getElementById("choose-folder");
    const selectionSummary = document.getElementById("selection-summary");
    const selectionList = document.getElementById("selection-list");
    const pathHintField = form.querySelector("textarea[name='path_hint']");
    const progressBar = document.getElementById("import-progress-bar");
    const statusLine = document.getElementById("import-status");
    const submitButton = document.getElementById("import-submit");
    const selectedEntries = [];
    const acceptedExtensions = new Set(["jpg", "jpeg", "heic", "heif"]);
    const importConcurrency = 3;
    const importStateStorageKey = "eona.gateway.activeImport";
    let importInFlight = false;
    let activeImportState = null;

    function basename(path) {{
      const parts = path.split("/");
      return parts[parts.length - 1] || path;
    }}

    function extensionFor(path) {{
      const parts = basename(path).split(".");
      return parts.length > 1 ? parts[parts.length - 1].toLowerCase() : "";
    }}

    function isAcceptedEntry(entry) {{
      const relativePath = entry.relativePath || entry.file.name;
      return acceptedExtensions.has(extensionFor(relativePath));
    }}

    function dedupeEntries(entries) {{
      const byPath = new Map();
      for (const entry of entries) {{
        if (!entry || !entry.file) {{
          continue;
        }}
        if (!isAcceptedEntry(entry)) {{
          continue;
        }}
        byPath.set(entry.relativePath || entry.file.name, entry);
      }}
      return Array.from(byPath.values()).sort((left, right) =>
        (left.relativePath || left.file.name).localeCompare(right.relativePath || right.file.name)
      );
    }}

    function renderSelection() {{
      selectionList.innerHTML = "";
      if (!selectedEntries.length) {{
        selectionSummary.textContent = "Drag and drop a folder here, or choose a folder from disk.";
        updateProgress(0, "No import in progress.");
        return;
      }}
      const count = selectedEntries.length;
      const totalBytes = selectedEntries.reduce((sum, entry) => sum + (entry.file?.size || 0), 0);
      selectionSummary.textContent = `${{count}} file${{count === 1 ? "" : "s"}} queued for import (${{
        formatBytes(totalBytes)
      }}).`;
      for (const entry of selectedEntries.slice(0, 6)) {{
        const item = document.createElement("li");
        item.textContent = entry.relativePath || entry.file.name;
        selectionList.appendChild(item);
      }}
      if (selectedEntries.length > 6) {{
        const more = document.createElement("li");
        more.textContent = `...and ${{selectedEntries.length - 6}} more`;
        selectionList.appendChild(more);
      }}
    }}

    function updateProgress(fraction, message) {{
      const safeFraction = Math.max(0, Math.min(1, fraction));
      progressBar.style.width = `${{(safeFraction * 100).toFixed(1)}}%`;
      statusLine.textContent = message;
    }}

    function readStoredImportState() {{
      try {{
        const raw = window.sessionStorage.getItem(importStateStorageKey);
        return raw ? JSON.parse(raw) : null;
      }} catch (error) {{
        return null;
      }}
    }}

    function persistImportState(patch) {{
      activeImportState = {{
        ...(activeImportState || {{}}),
        ...patch,
      }};
      window.sessionStorage.setItem(importStateStorageKey, JSON.stringify(activeImportState));
    }}

    function clearImportState() {{
      activeImportState = null;
      window.sessionStorage.removeItem(importStateStorageKey);
    }}

    function renderRecoveredImportState(state, serverSession) {{
      const collectedCount = Number(serverSession?.file_count || state?.collected || 0);
      const total = Number(state?.total || 0);
      const importId = state?.importId || serverSession?.import_id || "unknown";
      progressBar.style.width = `${{(Math.max(0, Math.min(1, total > 0 ? collectedCount / total : 0)) * 100).toFixed(1)}}%`;
      statusLine.textContent =
        `Import session ${{importId}} was interrupted by a page reload after ${{collectedCount}} / ${{total || "?"}} files. Choose the folder again to start a new import run.`;
    }}

    function formatBytes(value) {{
      if (!Number.isFinite(value) || value <= 0) {{
        return "0 B";
      }}
      const units = ["B", "KB", "MB", "GB", "TB"];
      let size = value;
      let unitIndex = 0;
      while (size >= 1024 && unitIndex < units.length - 1) {{
        size /= 1024;
        unitIndex += 1;
      }}
      const decimals = size >= 10 || unitIndex === 0 ? 0 : 1;
      return `${{size.toFixed(decimals)}} ${{units[unitIndex]}}`;
    }}

    function replaceSelection(entries) {{
      selectedEntries.splice(0, selectedEntries.length, ...dedupeEntries(entries));
      renderSelection();
    }}

    async function readFileEntry(entry, prefix = "") {{
      if (entry.isFile) {{
        return new Promise((resolve, reject) => {{
          entry.file((file) => {{
            resolve([{{
              file,
              relativePath: prefix + file.name,
            }}]);
          }}, reject);
        }});
      }}
      if (!entry.isDirectory) {{
        return [];
      }}
      const reader = entry.createReader();
      const directoryEntries = await new Promise((resolve, reject) => {{
        const collected = [];
        function readNextBatch() {{
          reader.readEntries((batch) => {{
            if (!batch.length) {{
              resolve(collected);
              return;
            }}
            collected.push(...batch);
            readNextBatch();
          }}, reject);
        }}
        readNextBatch();
      }});
      const nested = await Promise.all(
        directoryEntries.map((child) => readFileEntry(child, `${{prefix}}${{entry.name}}/`))
      );
      return nested.flat();
    }}

    async function entriesFromDrop(event) {{
      const items = Array.from(event.dataTransfer?.items || []);
      const entries = items
        .map((item) => item.webkitGetAsEntry ? item.webkitGetAsEntry() : null)
        .filter(Boolean);
      if (entries.length) {{
        const nested = await Promise.all(entries.map((entry) => readFileEntry(entry)));
        return nested.flat();
      }}
      return Array.from(event.dataTransfer?.files || []).map((file) => ({{
        file,
        relativePath: file.webkitRelativePath || file.name,
      }}));
    }}

    function entriesFromInput(files) {{
      return Array.from(files || []).map((file) => ({{
        file,
        relativePath: file.webkitRelativePath || file.name,
      }}));
    }}

    async function createImportSession() {{
      const response = await fetch("/import-sessions", {{
        method: "POST",
      }});
      if (!response.ok) {{
        throw new Error(`Failed to create import session (${{response.status}}).`);
      }}
      return response.json();
    }}

    async function fetchImportSession(importId) {{
      const response = await fetch(`/import-sessions/${{importId}}`);
      if (!response.ok) {{
        throw new Error(`Failed to load import session ${{importId}} (${{response.status}}).`);
      }}
      return response.json();
    }}

    async function stageOneFile(importId, entry, pathHint) {{
      const formData = new FormData();
      formData.append("file", entry.file, basename(entry.relativePath || entry.file.name));
      if (pathHint) {{
        formData.append("path_hint", pathHint);
      }}
      const response = await fetch(`/import-sessions/${{importId}}/files`, {{
        method: "POST",
        body: formData,
      }});
      if (!response.ok) {{
        let message = `Failed to stage ${{entry.relativePath || entry.file.name}} (${{response.status}}).`;
        try {{
          const payload = await response.json();
          if (payload && payload.message) {{
            message = payload.message;
          }}
        }} catch (error) {{
          // Keep the fallback message when the server response is not JSON.
        }}
        throw new Error(message);
      }}
      return response.json();
    }}

    async function commitImportSession(importId) {{
      const response = await fetch(`/import-sessions/${{importId}}/commit`, {{
        method: "POST",
      }});
      if (!response.ok) {{
        throw new Error(`Failed to commit import session (${{response.status}}).`);
      }}
      return response.json();
    }}

    async function collectSelectedEntries(importId, entries, sharedPathHint) {{
      let collected = 0;
      let nextIndex = 0;
      const total = entries.length;
      updateProgress(0, `Collecting 0 / ${{total}} files...`);

      async function worker() {{
        while (nextIndex < total) {{
          const currentIndex = nextIndex;
          nextIndex += 1;
          const entry = entries[currentIndex];
          const resolvedPathHint = sharedPathHint || entry.relativePath || entry.file.name;
          await stageOneFile(importId, entry, resolvedPathHint);
          collected += 1;
          persistImportState({{ collected }});
          updateProgress(collected / total, `Collecting ${{collected}} / ${{total}} files...`);
        }}
      }}

      const workerCount = Math.max(1, Math.min(importConcurrency, total));
      await Promise.all(Array.from({{ length: workerCount }}, () => worker()));
    }}

    async function submitSelection(event) {{
      event.preventDefault();
      if (importInFlight) {{
        return;
      }}
      if (!selectedEntries.length) {{
        updateProgress(0, "Choose or drop a folder before starting the import.");
        return;
      }}
      importInFlight = true;
      submitButton.disabled = true;
      chooseFolderButton.disabled = true;
      folderInput.disabled = true;
      pathHintField.disabled = true;
      try {{
        updateProgress(0, "Creating import session...");
        const session = await createImportSession();
        const importId = session.import_id;
        const totalBytes = selectedEntries.reduce((sum, entry) => sum + (entry.file?.size || 0), 0);
        persistImportState({{
          importId,
          total: selectedEntries.length,
          collected: 0,
          totalBytes,
          startedAt: new Date().toISOString(),
        }});
        const availableImportBytes = Number(session?.storage?.available_import_bytes || 0);
        if (availableImportBytes > 0 && totalBytes > availableImportBytes) {{
          throw new Error(
            `Selected files need ${{formatBytes(totalBytes)}}, but the server currently allows only ${{formatBytes(availableImportBytes)}} for new imports.`
          );
        }}
        const sharedPathHint = pathHintField.value.trim();
        await collectSelectedEntries(importId, selectedEntries, sharedPathHint);
        updateProgress(1, "Committing import session...");
        const committed = await commitImportSession(importId);
        const runId = committed.run_id;
        persistImportState({{ status: "committed", runId }});
        updateProgress(1, "Import collection complete. Redirecting to run details...");
        importInFlight = false;
        clearImportState();
        window.location.assign(`/runs/${{runId}}`);
      }} catch (error) {{
        const message = error instanceof Error ? error.message : "Import failed.";
        persistImportState({{ status: "interrupted" }});
        updateProgress(0, message);
      }} finally {{
        importInFlight = false;
        submitButton.disabled = false;
        chooseFolderButton.disabled = false;
        folderInput.disabled = false;
        pathHintField.disabled = false;
      }}
    }}

    chooseFolderButton.addEventListener("click", (event) => {{
      event.preventDefault();
      event.stopPropagation();
      folderInput.click();
    }});
    folderInput.addEventListener("change", () => replaceSelection(entriesFromInput(folderInput.files)));
    form.addEventListener("submit", submitSelection);
    ["dragenter", "dragover"].forEach((eventName) => {{
      dropzone.addEventListener(eventName, (event) => {{
        event.preventDefault();
        dropzone.classList.add("active");
      }});
    }});
    ["dragleave", "drop"].forEach((eventName) => {{
      dropzone.addEventListener(eventName, (event) => {{
        event.preventDefault();
        dropzone.classList.remove("active");
      }});
    }});
    dropzone.addEventListener("drop", async (event) => {{
      const entries = await entriesFromDrop(event);
      replaceSelection(entries);
    }});
    dropzone.addEventListener("click", (event) => {{
      if (event.target === chooseFolderButton) {{
        return;
      }}
      folderInput.click();
    }});
    dropzone.addEventListener("keydown", (event) => {{
      if (event.key === "Enter" || event.key === " ") {{
        event.preventDefault();
        folderInput.click();
      }}
    }});
    window.addEventListener("beforeunload", (event) => {{
      if (!importInFlight) {{
        return;
      }}
      event.preventDefault();
      event.returnValue = "";
    }});
    (async () => {{
      const stored = readStoredImportState();
      if (!stored || !stored.importId) {{
        return;
      }}
      activeImportState = stored;
      try {{
        const session = await fetchImportSession(stored.importId);
        if (session.status === "committed" && session.import_run_id) {{
          clearImportState();
          window.location.replace(`/runs/${{session.import_run_id}}`);
          return;
        }}
        if (session.status === "collecting") {{
          renderRecoveredImportState(stored, session);
          return;
        }}
        clearImportState();
      }} catch (error) {{
        clearImportState();
      }}
    }})();
  </script>
</body>
</html>"""


def render_blocked_page(*, readiness: dict[str, Any]) -> str:
    problems = readiness.get("problems") or ["Gateway is blocked."]
    problem_items = "\n".join(f"<li>{html.escape(str(problem))}</li>" for problem in problems)
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Eona Gateway Blocked</title>
  <style>
    :root {{
      --bg: #f5efe7;
      --panel: #fffaf3;
      --ink: #2e251d;
      --line: #d8c8b5;
      --warn: #91551d;
      --warn-bg: #fff0da;
    }}
    body {{
      margin: 0;
      font-family: Georgia, "Times New Roman", serif;
      color: var(--ink);
      background: linear-gradient(180deg, #f8f1e7 0%, var(--bg) 100%);
    }}
    main {{
      max-width: 900px;
      margin: 0 auto;
      padding: 2rem 1rem 3rem;
    }}
    .panel {{
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 1.2rem;
      padding: 1.25rem;
      box-shadow: 0 12px 30px rgba(88, 57, 32, 0.08);
    }}
    .warning {{
      border-color: #d8b46c;
      background: var(--warn-bg);
    }}
  </style>
</head>
<body>
  <main>
    <h1>Eona Gateway</h1>
    <section class="panel warning">
      <h2>Gateway Blocked</h2>
      <p><strong>{html.escape(str(readiness.get("summary") or "Gateway startup is blocked."))}</strong></p>
      <p>Gateway is running in operator-only mode. Normal imports and content serving are unavailable until the integrity issue is fixed.</p>
      <ul>{problem_items}</ul>
    </section>
  </main>
</body>
</html>"""


def render_run_detail_page(*, run: dict[str, Any], import_session: dict[str, Any] | None = None) -> str:
    report = run.get("report") or {}
    resume_from_stage = run.get("resume_from_stage")
    report_rows = "\n".join(
        f"<li><strong>{html.escape(str(key).replace('_', ' ').title())}</strong>: {html.escape(str(value))}</li>"
        for key, value in report.items()
    ) or "<li>No report available yet.</li>"
    stages = run.get("stages") or {}
    ordered_stage_names = (
        "SEAL_INPUT",
        "SCANNING",
        "METADATA_EXTRACTION",
        "CADIS_LOOKUP",
        "SQLITE_WRITE",
        "CANONICALIZATION",
        "MERGE",
    )
    stage_cards: list[str] = []
    for stage_name in ordered_stage_names:
        payload = stages.get(stage_name)
        if not isinstance(payload, dict):
            continue
        items_total = payload.get("items_total")
        items_done = payload.get("items_done")
        percent = 0.0
        if isinstance(items_total, int) and items_total > 0 and isinstance(items_done, int):
            percent = min(max((items_done / items_total) * 100.0, 0.0), 100.0)
        elif str(payload.get("state")) == "complete":
            percent = 100.0
        stage_cards.append(
            f"""
            <article class="stage-card">
              <div class="stage-card-header">
                <strong>{html.escape(stage_name)}</strong>
                <span>{html.escape(str(payload.get('state', 'unknown')))} ({html.escape(str(items_done if items_done is not None else 0))}/{html.escape(str(items_total if items_total is not None else '?'))})</span>
              </div>
              <div class="stage-progress" aria-hidden="true"><span style="width: {percent:.1f}%"></span></div>
            </article>
            """
        )
    stage_block = "\n".join(stage_cards) or "<p>No stage activity recorded yet.</p>"
    interruption_notice = ""
    if str(run.get("error_code") or "") == "WORKER_INTERRUPTED":
        interruption_notice = """
        <section class="panel interruption-notice">
          <strong>This import was interrupted by a Gateway restart.</strong>
          <p>This run will not resume automatically. Start a new import from the imports page to retry the folder from scratch.</p>
        </section>
        """
    resume_notice = ""
    if isinstance(resume_from_stage, str) and resume_from_stage:
        active_stage_name = str(run.get("current_stage") or resume_from_stage)
        active_stage = stages.get(active_stage_name) if isinstance(stages, dict) else None
        retry_items = active_stage.get("items_total") if isinstance(active_stage, dict) else None
        collected_files = report.get("collected_files")
        message_parts = [f"Resuming from {html.escape(resume_from_stage)}."]
        if isinstance(retry_items, int) and retry_items >= 0:
            message_parts.append(f"Current stage counts reflect the retry set ({retry_items} items), not the original import.")
        if isinstance(collected_files, int) and collected_files >= 0:
            message_parts.append(f"Original import contained {collected_files} files.")
        resume_notice = f"""
        <section class="panel interruption-notice">
          <strong>Resume In Progress</strong>
          <p>{" ".join(message_parts)}</p>
        </section>
        """
    elif str(report.get("recovery_mode") or "") == "pause_resume":
        collected_files = report.get("collected_files")
        retried_items = report.get("retried_items")
        message_parts = ["This run completed through pause/resume recovery."]
        if isinstance(retried_items, int) and retried_items >= 0:
            message_parts.append(f"Retry set: {retried_items} items.")
        if isinstance(collected_files, int) and collected_files >= 0:
            message_parts.append(f"Original import: {collected_files} files.")
        resume_notice = f"""
        <section class="panel interruption-notice">
          <strong>Recovered Run</strong>
          <p>{" ".join(message_parts)}</p>
        </section>
        """
    import_block = ""
    if import_session is not None:
        import_block = f"""
        <section class="panel">
          <h2>Import Session</h2>
          <p><strong>ID</strong>: {html.escape(str(import_session['import_id']))}</p>
          <p><strong>Status</strong>: {html.escape(str(import_session['status']))}</p>
          <p><strong>Files</strong>: {html.escape(str(import_session['file_count']))}</p>
        </section>
        """
    run_status = str(run.get("status") or "")
    controls = ""
    if run_status in {"queued", "running", "pausing"}:
        controls = f"""
        <form method="post" action="/import-runs/{html.escape(str(run['run_id']))}/pause" class="run-controls">
          <button type="submit">Pause</button>
        </form>
        """
    elif run_status == "paused":
        controls = f"""
        <form method="post" action="/import-runs/{html.escape(str(run['run_id']))}/resume" class="run-controls">
          <button type="submit">Resume</button>
        </form>
        """
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Run {html.escape(str(run['run_id']))}</title>
  <meta http-equiv="refresh" content="5">
  <style>
    :root {{
      --bg: #f2efe9;
      --panel: #fffdf9;
      --ink: #28221c;
      --muted: #6d6459;
      --line: #d8cfc4;
      --accent: #28594d;
    }}
    body {{
      margin: 0;
      font-family: Georgia, "Times New Roman", serif;
      background: linear-gradient(180deg, #eef5f1 0%, var(--bg) 100%);
      color: var(--ink);
    }}
    main {{
      max-width: 980px;
      margin: 0 auto;
      padding: 2rem 1rem 3rem;
    }}
    a {{
      color: var(--accent);
      text-decoration: none;
    }}
    .panel {{
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 1.2rem;
      padding: 1.2rem;
      margin-top: 1rem;
      box-shadow: 0 10px 24px rgba(41, 56, 44, 0.06);
    }}
    .interruption-notice {{
      border-color: #d8b46c;
      background: #fff6df;
    }}
    .interruption-notice p {{
      margin-bottom: 0;
    }}
    .hero {{
      display: flex;
      justify-content: space-between;
      gap: 1rem;
      align-items: end;
      flex-wrap: wrap;
    }}
    .run-controls {{
      margin-top: 1rem;
    }}
    .run-controls button {{
      border: 0;
      border-radius: 999px;
      padding: .7rem 1.4rem;
      background: #28594d;
      color: #fff;
      font: inherit;
      font-weight: 700;
      cursor: pointer;
    }}
    .stage-grid {{
      display: grid;
      gap: .8rem;
    }}
    .stage-card {{
      display: grid;
      gap: .45rem;
      padding: .9rem 1rem;
      border-radius: .95rem;
      border: 1px solid var(--line);
      background: rgba(241, 247, 243, 0.55);
    }}
    .stage-card-header {{
      display: flex;
      justify-content: space-between;
      gap: .8rem;
      flex-wrap: wrap;
    }}
    .stage-card-header span {{
      color: var(--muted);
    }}
    .stage-progress {{
      height: .8rem;
      border-radius: 999px;
      background: #d9e6df;
      overflow: hidden;
    }}
    .stage-progress > span {{
      display: block;
      height: 100%;
      background: linear-gradient(90deg, #4c8c7a, #28594d);
    }}
    ul {{
      margin: .4rem 0 0;
      padding-left: 1.1rem;
    }}
  </style>
</head>
<body>
  <main>
    <p><a href="/">Back To Imports</a></p>
    <div class="hero">
      <div>
        <h1>Import Run</h1>
        <p><strong>{html.escape(str(run['run_id']))}</strong></p>
        {controls}
      </div>
      <div>
        <p><strong>Status</strong>: {html.escape(str(run['status']))}</p>
        <p><strong>Current Stage</strong>: {html.escape(str(run.get('current_stage') or 'complete'))}</p>
      </div>
    </div>
    <section class="panel">
      <h2>Run State</h2>
      <p><strong>Created</strong>: {html.escape(str(run.get('created_at')))}</p>
      <p><strong>Started</strong>: {html.escape(str(run.get('started_at')))}</p>
      <p><strong>Completed</strong>: {html.escape(str(run.get('completed_at')))}</p>
      <p><strong>Error</strong>: {html.escape(str(run.get('error_code') or 'none'))}</p>
    </section>
    {interruption_notice}
    {resume_notice}
    {import_block}
    <section class="panel">
      <h2>Stage Progress</h2>
      <div class="stage-grid">{stage_block}</div>
    </section>
    <section class="panel">
      <h2>Final Report</h2>
      <ul>{report_rows}</ul>
    </section>
  </main>
</body>
</html>"""


def _render_run_card(run: dict[str, Any]) -> str:
    current_stage = run.get("current_stage") or "complete"
    return f"""
    <a class="run-card" href="/runs/{html.escape(str(run['run_id']))}">
      <div class="status">{html.escape(str(run['status']))}</div>
      <strong>{html.escape(str(run['run_id']))}</strong>
      <div class="run-meta">
        <span>Stage: {html.escape(str(current_stage))}</span>
        <span>{html.escape(str(run.get('created_at')))}</span>
      </div>
    </a>
    """
