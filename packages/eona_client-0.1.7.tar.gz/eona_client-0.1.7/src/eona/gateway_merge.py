from __future__ import annotations

import json
import logging
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from eona.gateway_canonicalize import GatewayCanonicalizer
from eona.gateway_db import connect_database, generate_id, immediate_transaction, utc_now
from eona.gateway_identity import PHOTO_SIGNATURE_VERSION, photo_signature_for_metadata
from eona.gateway_runs import ensure_run_layout

logger = logging.getLogger(__name__)


def _manifest_input_path(*, root_dir: Path, item: dict[str, Any]) -> Path:
    input_path = item.get("input_path")
    if isinstance(input_path, str) and input_path:
        return Path(input_path)
    return root_dir / str(item["input_relpath"])


@dataclass(frozen=True)
class GatewayMergeReport:
    collected_files: int
    processed_items: int
    new_content_count: int
    new_photo_count: int
    new_path_count: int
    redundant_item_count: int
    failed_item_count: int

    def as_dict(self) -> dict[str, int]:
        return {
            "collected_files": self.collected_files,
            "processed_items": self.processed_items,
            "new_content_count": self.new_content_count,
            "new_photo_count": self.new_photo_count,
            "new_path_count": self.new_path_count,
            "redundant_item_count": self.redundant_item_count,
            "failed_item_count": self.failed_item_count,
        }


class GatewayMergeRunner:
    def __init__(self, *, service: "GatewayService", canonicalizer: GatewayCanonicalizer | None = None) -> None:
        self.service = service
        self.canonicalizer = canonicalizer or GatewayCanonicalizer(root_dir=service.paths.root)

    def execute_run(self, run_id: str, *, retry_import_file_ids: set[str] | None = None) -> GatewayMergeReport:
        run_paths = ensure_run_layout(paths=self.service.paths, run_id=run_id)
        manifest = self.service.get_run_input_manifest(run_id)
        item_map = {
            str(_manifest_input_path(root_dir=self.service.paths.root, item=item).resolve()): item
            for item in manifest["items"]
        }
        with sqlite3.connect(run_paths.run_dir / "import.db") as import_db:
            import_db.row_factory = sqlite3.Row
            all_photos = import_db.execute("SELECT path FROM photos ORDER BY path").fetchall()
            metadata_rows = {
                str(row["path"]): json.loads(str(row["metadata_json"]))
                for row in import_db.execute("SELECT path, metadata_json FROM metadata").fetchall()
            }
            geo_table_exists = import_db.execute(
                "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'geo'"
            ).fetchone()
            if geo_table_exists is None:
                geo_rows = {}
            else:
                geo_rows = {
                    str(row["path"]): json.loads(str(row["geo_json"]))
                    for row in import_db.execute("SELECT path, geo_json FROM geo").fetchall()
                }
        if retry_import_file_ids is None:
            photos = all_photos
        else:
            photos = [
                row
                for row in all_photos
                if (item := item_map.get(str(row["path"]))) is not None
                and str(item["import_file_id"]) in retry_import_file_ids
            ]
        counts = {
            "new_content_count": 0,
            "new_photo_count": 0,
            "new_path_count": 0,
            "redundant_item_count": 0,
            "failed_item_count": 0,
        }
        total = len(photos)
        self.service.mark_run_stage(run_id, stage="CANONICALIZATION", progress=0.96)
        processed = 0
        for index, row in enumerate(photos, start=1):
            photo_path = str(row["path"])
            item = item_map.get(photo_path)
            if item is None:
                counts["failed_item_count"] += 1
                continue
            metadata_row = metadata_rows.get(photo_path, {})
            try:
                canonical = self.canonicalizer.canonicalize(
                    source_path=Path(photo_path),
                    content_dir=self.service.paths.content_dir,
                )
            except sqlite3.OperationalError:
                raise
            except Exception as exc:
                counts["failed_item_count"] += 1
                self._record_item_failure(
                    run_id=run_id,
                    item=item,
                    error_code=self._classify_item_failure(exc),
                    error_message=str(exc),
                )
                self.service.record_stage_progress(
                    run_id,
                    stage="CANONICALIZATION",
                    items_total=total,
                    items_done=index,
                    artifact="content/*",
                )
                self.service.record_stage_progress(
                    run_id,
                    stage="MERGE",
                    items_total=total,
                    items_done=index,
                    artifact="gateway.db",
                )
                self.service.checkpoint_pause(run_id, stage="MERGE")
                continue
            self.service.record_stage_progress(
                run_id,
                stage="CANONICALIZATION",
                items_total=total,
                items_done=index,
                artifact="content/*",
            )
            self.service.checkpoint_pause(run_id, stage="CANONICALIZATION")
            self.service.mark_run_stage(run_id, stage="MERGE", progress=0.98)
            try:
                merge_result = self._merge_item(
                    run_id=run_id,
                    item=item,
                    metadata_row=metadata_row,
                    geo_row=geo_rows.get(photo_path, {}),
                    canonical=canonical,
                )
            except sqlite3.OperationalError:
                raise
            except Exception as exc:
                counts["failed_item_count"] += 1
                self._record_item_failure(
                    run_id=run_id,
                    item=item,
                    error_code=self._classify_item_failure(exc),
                    error_message=str(exc),
                )
                self.service.record_stage_progress(
                    run_id,
                    stage="MERGE",
                    items_total=total,
                    items_done=index,
                    artifact="gateway.db",
                )
                self.service.checkpoint_pause(run_id, stage="MERGE")
                continue
            for key, value in merge_result.items():
                counts[key] += value
            processed += 1
            self.service.record_stage_progress(
                run_id,
                stage="MERGE",
                items_total=total,
                items_done=index,
                artifact="gateway.db",
            )
            self.service.checkpoint_pause(run_id, stage="MERGE")
        return GatewayMergeReport(
            collected_files=int(manifest["item_count"]),
            processed_items=processed,
            new_content_count=counts["new_content_count"],
            new_photo_count=counts["new_photo_count"],
            new_path_count=counts["new_path_count"],
            redundant_item_count=counts["redundant_item_count"],
            failed_item_count=counts["failed_item_count"],
        )

    def _record_item_failure(
        self,
        *,
        run_id: str,
        item: dict[str, Any],
        error_code: str,
        error_message: str,
    ) -> None:
        import_file_id = str(item["import_file_id"])
        self.service.fail_run_item(
            run_id,
            import_file_id=import_file_id,
            error_code=error_code,
            error_message=error_message,
        )
        logger.warning(
            "Gateway run %s item %s failed during merge: %s %s",
            run_id,
            import_file_id,
            error_code,
            error_message,
        )

    def _classify_item_failure(self, exc: Exception) -> str:
        message = str(exc).lower()
        if "truncated" in message:
            return "SOURCE_IMAGE_TRUNCATED"
        if "cannot identify image file" in message:
            return "SOURCE_IMAGE_UNREADABLE"
        return "ITEM_PROCESSING_FAILED"

    def _merge_item(
        self,
        *,
        run_id: str,
        item: dict[str, Any],
        metadata_row: dict[str, Any],
        geo_row: dict[str, Any],
        canonical,
    ) -> dict[str, int]:
        signature, signature_payload = photo_signature_for_metadata(metadata_row=metadata_row)
        now = utc_now()
        counts = {
            "new_content_count": 0,
            "new_photo_count": 0,
            "new_path_count": 0,
            "redundant_item_count": 0,
        }
        with connect_database(self.service.paths) as connection:
            with immediate_transaction(connection):
                content_row = connection.execute(
                    "SELECT content_id FROM content WHERE content_id = ?",
                    (canonical.content_id,),
                ).fetchone()
                if content_row is None:
                    connection.execute(
                        """
                        INSERT INTO content(
                            content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            canonical.content_id,
                            canonical.canonical_spec_version,
                            canonical.storage_relpath,
                            canonical.mime_type,
                            canonical.byte_size,
                            canonical.width,
                            canonical.height,
                            now,
                        ),
                    )
                    counts["new_content_count"] += 1

                photo_row = connection.execute(
                    """
                    SELECT photo_id
                    FROM photo
                    WHERE content_id = ? AND photo_signature = ? AND photo_signature_version = ?
                    """,
                    (canonical.content_id, signature, PHOTO_SIGNATURE_VERSION),
                ).fetchone()
                if photo_row is None:
                    photo_id = generate_id("pho")
                    image_facts = metadata_row.get("image_facts") or {}
                    image_camera = metadata_row.get("image_camera") or {}
                    image_location = metadata_row.get("image_location") or {}
                    normalized_location = geo_row.get("normalized_location") or {}
                    connection.execute(
                        """
                        INSERT INTO photo(
                            photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                            taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                            cadis_result_json, cadis_version, location_detail,
                            camera_make, camera_model, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            photo_id,
                            canonical.content_id,
                            signature,
                            PHOTO_SIGNATURE_VERSION,
                            signature_payload,
                            image_facts.get("taken_at_utc"),
                            image_facts.get("taken_at_original"),
                            image_location.get("raw_latitude"),
                            image_location.get("raw_longitude"),
                            image_location.get("raw_altitude"),
                            normalized_location.get("cadis_result_json"),
                            normalized_location.get("cadis_version"),
                            normalized_location.get("detail"),
                            image_camera.get("make"),
                            image_camera.get("model"),
                            now,
                        ),
                    )
                    counts["new_photo_count"] += 1
                else:
                    photo_id = str(photo_row["photo_id"])

                path_hint = item.get("path_hint")
                if isinstance(path_hint, str) and path_hint:
                    existing_path = connection.execute(
                        """
                        SELECT 1
                        FROM photo_path_observation
                        WHERE photo_id = ? AND path_text = ?
                        """,
                        (photo_id, path_hint),
                    ).fetchone()
                    if existing_path is None:
                        connection.execute(
                            """
                            INSERT INTO photo_path_observation(photo_id, path_text, first_seen_run_id, created_at)
                            VALUES (?, ?, ?, ?)
                            """,
                            (photo_id, path_hint, run_id, now),
                        )
                        counts["new_path_count"] += 1
                    else:
                        counts["redundant_item_count"] += 1
                elif counts["new_photo_count"] == 0:
                    counts["redundant_item_count"] += 1

                connection.execute(
                    """
                    UPDATE import_run_item
                    SET status = 'complete', photo_id = ?, content_id = ?
                    WHERE run_id = ? AND import_file_id = ?
                    """,
                    (photo_id, canonical.content_id, run_id, item["import_file_id"]),
                )
        return counts
