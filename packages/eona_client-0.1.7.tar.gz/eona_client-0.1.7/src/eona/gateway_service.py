from __future__ import annotations

import errno
import json
import logging
import os
import re
import sqlite3
import threading
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
import math
from pathlib import Path
import shutil
from typing import Any, Callable

from eona.env_compat import compat_env
from eona.gateway_db import connect_database, generate_id, immediate_transaction, utc_now
from eona.gateway_paths import GatewayPaths, ensure_gateway_layout, get_gateway_paths
from eona.gateway_runtime import env_truthy, inspect_gateway_runtime
from eona.gateway_runs import INPUT_MANIFEST_VERSION, atomic_write_json, ensure_run_layout, read_json, sha256_file
from eona.gateway_upgrade_tools import run_gateway_upgrade_tools, should_rerun_cadis_row
from eona.indexing import CadisRuntimeNormalizer
from eona.query_compiler import QueryCompilationError, QueryValidationError, compile_photo_memory_query

GATEWAY_ACCEPTED_IMPORT_EXTENSIONS = {".jpg", ".jpeg", ".heic", ".heif"}
DEFAULT_MIN_FREE_BYTES = 2 * 1024 * 1024 * 1024
MAX_PHOTO_MEMORY_QUERY_LIMIT = 50
MAX_PHOTO_MEMORY_RESPONSE_BYTES = 256 * 1024
DUPLICATE_SEMANTIC_VERSION = 1
BURST_DUPLICATE_TIME_WINDOW_SECONDS = 3.0
BURST_DUPLICATE_DISTANCE_METERS = 10.0
SUPPORTED_TAG_BACKFILLS = {"has_people"}
SUPPORTED_SEMANTIC_BACKFILL_REPLAY_MODES = {"incremental", "full_replay"}
TAG_SEMANTIC_VERSION = 1
HAS_PEOPLE_TAG_SOURCE = "opencv_yunet_face_detector"
SEMANTIC_ENRICHMENT_STATUS_PENDING = "pending"
SEMANTIC_ENRICHMENT_STATUS_RUNNING = "running"
SEMANTIC_ENRICHMENT_STATUS_COMPLETED = "completed"
SEMANTIC_ENRICHMENT_STATUS_FAILED = "failed"
SEMANTIC_ENRICHMENT_JOBS = {
    "duplicate_semantic": {
        "semantic_version": DUPLICATE_SEMANTIC_VERSION,
        "summary": "Duplicate semantic enrichment has not been run yet.",
        "purpose": "Reduce export and burst duplicates in photo-memory queries.",
        "impact": "If skipped, counts and galleries may contain repeated-looking duplicate photos.",
        "priority": "better_have",
        "recommended_action": "Run duplicate semantic enrichment after import.",
        "command": "eona-client backfill-duplicate-semantic --incremental --json",
    },
    "has_people": {
        "semantic_version": TAG_SEMANTIC_VERSION,
        "summary": "People semantic enrichment has not been run yet.",
        "purpose": "Add face-derived semantic tags such as has_people and face_count.",
        "impact": "If skipped, people-photo lookup and face-count filtering will not be available.",
        "priority": "better_have",
        "recommended_action": "Run people semantic enrichment after import.",
        "command": "eona-client backfill-tags --tag has_people --incremental --json",
    },
}
RUNTIME_UPGRADE_STATUS_PRECEDENCE = {
    "ready": 0,
    "reimport_suggested": 1,
    "needs_attention": 2,
    "pending_acceptance": 2,
    "blocked": 3,
    "failed": 4,
}

logger = logging.getLogger(__name__)


def _resolve_opencv_face_model_path() -> Path:
    candidates = [
        Path(compat_env("EONA_GATEWAY_IMAGE_ROOT", default="/opt/eona") or "/opt/eona")
        / "runtime"
        / "opencv"
        / "face_detection_yunet_2023mar.onnx",
        Path(__file__).resolve().parents[2] / "artifacts" / "opencv" / "common" / "face_detection_yunet_2023mar.onnx",
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    raise GatewayServiceError(
        "TAG_RUNTIME_UNAVAILABLE",
        "OpenCV YuNet face detector model asset is unavailable.",
        500,
    )


@dataclass(frozen=True)
class GatewayServiceError(Exception):
    error_code: str
    message: str
    http_status: int

    def __str__(self) -> str:
        return self.message


@dataclass(frozen=True)
class GatewayPauseRequested(Exception):
    run_id: str
    stage: str | None


class _OpenCvFaceDetector:
    def __init__(self) -> None:
        try:
            import cv2  # type: ignore
        except Exception as exc:  # pragma: no cover - depends on runtime packaging
            raise GatewayServiceError(
                "TAG_RUNTIME_UNAVAILABLE",
                "OpenCV face detector runtime is unavailable.",
                500,
            ) from exc
        model_path = str(_resolve_opencv_face_model_path())
        try:
            detector = cv2.FaceDetectorYN.create(model_path, "", (320, 320), 0.9, 0.3, 5000)
        except Exception as exc:
            raise GatewayServiceError(
                "TAG_RUNTIME_UNAVAILABLE",
                "OpenCV YuNet face detector model is unavailable.",
                500,
            ) from exc
        self._cv2 = cv2
        self._detector = detector

    def detect_has_people(self, image_path: Path) -> bool:
        return self.detect_face_count(image_path) > 0

    def detect_face_count(self, image_path: Path) -> int:
        image = self._cv2.imread(str(image_path))
        if image is None:
            raise GatewayServiceError(
                "TAG_INPUT_INVALID",
                f"Unable to decode image for face detection: {image_path}",
                500,
            )
        self._detector.setInputSize((image.shape[1], image.shape[0]))
        _, faces = self._detector.detect(image)
        return 0 if faces is None else int(faces.shape[0])


class GatewayService:
    def __init__(self, *, paths: GatewayPaths | None = None) -> None:
        self.paths = ensure_gateway_layout(paths or get_gateway_paths())
        self._storage_fault: dict[str, str] | None = None
        self._content_store_status_cache: dict[str, Any] | None = None
        self._content_store_status_lock = threading.Lock()
        self._content_store_refresh_thread: threading.Thread | None = None

    def create_import_session(self) -> dict[str, Any]:
        import_id = generate_id("imp")
        now = utc_now()
        with connect_database(self.paths) as connection:
            connection.execute(
                """
                INSERT INTO import_session(import_id, status, created_at, updated_at)
                VALUES (?, 'collecting', ?, ?)
                """,
                (import_id, now, now),
            )
        return {
            "import_id": import_id,
            "status": "collecting",
            "created_at": now,
            "storage": self._storage_status(),
        }
        

    def stage_import_file(self, *, import_id: str, client_filename: str, content: bytes, path_hint: str | None) -> dict[str, Any]:
        session = self._get_session_record(import_id)
        if str(session["status"]) != "collecting":
            raise GatewayServiceError("IMPORT_NOT_ACCEPTING_FILES", "Import session is not accepting files.", 409)
        self._validate_import_filename(client_filename)
        import_file_id = generate_id("if")
        session_dir = self.paths.import_sessions_dir / import_id / "incoming"
        session_dir.mkdir(parents=True, exist_ok=True)
        suffix = Path(client_filename).suffix if client_filename else ""
        staging_filename = f"{import_file_id}{suffix}"
        staging_relpath = str(Path("imports") / "sessions" / import_id / "incoming" / staging_filename)
        staging_path = self.paths.root / staging_relpath
        source_path_text = str(staging_path.resolve())
        try:
            self._ensure_storage_capacity(required_bytes=len(content))
        except GatewayServiceError as exc:
            if exc.error_code == "IMPORT_STORAGE_EXHAUSTED":
                self._mark_import_session_failed(
                    import_id=import_id,
                    error_code=exc.error_code,
                    error_message=exc.message,
                )
            raise
        try:
            staging_path.write_bytes(content)
        except OSError as exc:
            if exc.errno == errno.ENOSPC:
                self._mark_import_session_failed(
                    import_id=import_id,
                    error_code="IMPORT_STORAGE_EXHAUSTED",
                    error_message=self._storage_exhausted_message(required_bytes=len(content)),
                )
                raise GatewayServiceError(
                    "IMPORT_STORAGE_EXHAUSTED",
                    self._storage_exhausted_message(required_bytes=len(content)),
                    507,
                ) from exc
            raise
        now = utc_now()
        with connect_database(self.paths) as connection:
            connection.execute(
                """
                INSERT INTO import_file(
                    import_file_id, import_id, client_filename, source_path_text, staging_relpath, path_hint, byte_size, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (import_file_id, import_id, client_filename, source_path_text, staging_relpath, path_hint, len(content), now),
            )
            connection.execute(
                "UPDATE import_session SET updated_at = ? WHERE import_id = ?",
                (now, import_id),
            )
            file_count = int(
                connection.execute("SELECT COUNT(*) FROM import_file WHERE import_id = ?", (import_id,)).fetchone()[0]
            )
        if file_count in {1, 10, 100} or file_count % 1000 == 0:
            logger.info("Gateway import session %s staged %s files", import_id, file_count)
        return {
            "import_file_id": import_file_id,
            "import_id": import_id,
            "client_filename": client_filename,
            "status": "staged",
        }

    def collect_import_path(self, *, import_id: str, source_path: str) -> dict[str, Any]:
        session = self._get_session_record(import_id)
        if str(session["status"]) != "collecting":
            raise GatewayServiceError("IMPORT_NOT_ACCEPTING_FILES", "Import session is not accepting files.", 409)

        requested_path = Path(source_path).expanduser()
        if not requested_path.is_absolute():
            raise GatewayServiceError("IMPORT_PATH_ABSOLUTE_REQUIRED", "Import path must be absolute.", 400)
        if requested_path.is_symlink():
            raise GatewayServiceError("IMPORT_PATH_SYMLINK_UNSUPPORTED", "Import path must not be a symlink.", 400)
        if not requested_path.exists():
            raise GatewayServiceError("IMPORT_PATH_NOT_FOUND", f"Import path does not exist: {requested_path}", 404)

        normalized_path = requested_path.resolve()
        discovered_files, collection_errors = self._discover_import_source_files(normalized_path)
        now = utc_now()
        staged_rows: list[tuple[str, str, str, str, str, int, str]] = []
        for file_path in discovered_files:
            import_file_id = generate_id("if")
            self._validate_import_filename(file_path.name)
            staged_rows.append(
                (
                    import_file_id,
                    import_id,
                    file_path.name,
                    str(file_path),
                    f"mount://{import_file_id}",
                    str(file_path),
                    file_path.stat().st_size,
                    now,
                )
            )
        with connect_database(self.paths) as connection:
            if staged_rows:
                connection.executemany(
                    """
                    INSERT INTO import_file(
                        import_file_id, import_id, client_filename, source_path_text, staging_relpath, path_hint, byte_size, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    staged_rows,
                )
            connection.execute(
                "UPDATE import_session SET updated_at = ?, error_code = NULL, error_message = NULL WHERE import_id = ?",
                (now, import_id),
            )
            file_count = int(
                connection.execute("SELECT COUNT(*) FROM import_file WHERE import_id = ?", (import_id,)).fetchone()[0]
            )
        return {
            "import_id": import_id,
            "status": "collecting",
            "collected_count": len(staged_rows),
            "error_count": len(collection_errors),
            "errors": collection_errors,
            "file_count": file_count,
        }

    def get_import_session(self, import_id: str) -> dict[str, Any]:
        with connect_database(self.paths) as connection:
            session = connection.execute(
                """
                SELECT import_id, status, created_at, updated_at, committed_at, import_run_id, error_code, error_message
                FROM import_session
                WHERE import_id = ?
                """,
                (import_id,),
            ).fetchone()
            if session is None:
                raise GatewayServiceError("IMPORT_NOT_FOUND", "Import session does not exist.", 404)
            file_count = connection.execute(
                "SELECT COUNT(*) FROM import_file WHERE import_id = ?",
                (import_id,),
            ).fetchone()[0]
        return {
            "import_id": str(session["import_id"]),
            "status": str(session["status"]),
            "created_at": session["created_at"],
            "updated_at": session["updated_at"],
            "committed_at": session["committed_at"],
            "file_count": int(file_count),
            "import_run_id": session["import_run_id"],
            "error_code": session["error_code"],
            "error_message": session["error_message"],
            "storage": self._storage_status(),
        }

    def commit_import_session(self, import_id: str) -> dict[str, Any]:
        with connect_database(self.paths) as connection:
            with immediate_transaction(connection):
                session = connection.execute(
                    """
                    SELECT import_id, status, import_run_id
                    FROM import_session
                    WHERE import_id = ?
                    """,
                    (import_id,),
                ).fetchone()
                if session is None:
                    raise GatewayServiceError("IMPORT_NOT_FOUND", "Import session does not exist.", 404)

                status = str(session["status"])
                if status == "committed":
                    existing_run_id = str(session["import_run_id"])
                    run = self._get_run_record(connection, existing_run_id)
                    return self._commit_response(import_id=import_id, session_status=status, run=run)
                if status == "committing":
                    existing_run_id = session["import_run_id"]
                    run = self._get_run_record(connection, str(existing_run_id)) if existing_run_id else None
                    return self._commit_response(import_id=import_id, session_status=status, run=run)
                if status in {"failed", "expired"}:
                    raise GatewayServiceError("IMPORT_NOT_COMMITTABLE", "Import session is not in a committable state.", 409)
                if status != "collecting":
                    raise GatewayServiceError("IMPORT_NOT_COMMITTABLE", "Import session is not in a committable state.", 409)

                now = utc_now()
                run_id = generate_id("run")
                source_rows = connection.execute(
                    """
                    SELECT import_file_id, client_filename, source_path_text, staging_relpath, path_hint, byte_size, created_at
                    FROM import_file
                    WHERE import_id = ?
                    ORDER BY rowid ASC
                    """,
                    (import_id,),
                ).fetchall()
                connection.execute(
                    """
                    INSERT INTO import_run(run_id, source_import_id, status, created_at, progress)
                    VALUES (?, ?, 'queued', ?, 0)
                    """,
                    (run_id, import_id, now),
                )
                connection.execute(
                    """
                    UPDATE import_session
                    SET status = 'committed', updated_at = ?, committed_at = ?, import_run_id = ?, error_code = NULL, error_message = NULL
                    WHERE import_id = ?
                    """,
                    (now, now, run_id, import_id),
                )
                connection.execute(
                    """
                    UPDATE import_file
                    SET committed_at = ?
                    WHERE import_id = ? AND committed_at IS NULL
                    """,
                    (now, import_id),
                )
                for row in source_rows:
                    connection.execute(
                        """
                        INSERT INTO import_run_item(run_id, import_file_id, source_path_text, status)
                        VALUES (?, ?, ?, 'pending')
                        """,
                        (run_id, str(row["import_file_id"]), row["path_hint"]),
                    )
                run = self._get_run_record(connection, run_id)
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        run_state = {
            "run_id": run_id,
            "source_import_id": import_id,
            "status": "queued",
            "current_stage": None,
            "created_at": now,
            "updated_at": now,
            "stages": {},
        }
        atomic_write_json(run_paths.run_json, run_state)
        logger.info("Gateway import session %s committed as run %s with %s files", import_id, run_id, len(source_rows))
        return self._commit_response(import_id=import_id, session_status="committed", run=run)

    def cleanup_abandoned_import_sessions(self, *, older_than_hours: float = 24.0, dry_run: bool = False) -> dict[str, Any]:
        cutoff = (
            datetime.now(UTC) - timedelta(hours=max(float(older_than_hours), 0.0))
        ).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        with connect_database(self.paths) as connection:
            rows = connection.execute(
                """
                SELECT
                    import_session.import_id,
                    import_session.status,
                    import_session.updated_at,
                    COUNT(import_file.import_file_id) AS file_count,
                    COALESCE(SUM(import_file.byte_size), 0) AS total_bytes
                FROM import_session
                LEFT JOIN import_file ON import_file.import_id = import_session.import_id
                WHERE import_session.status IN ('collecting', 'failed', 'expired')
                  AND import_session.import_run_id IS NULL
                  AND import_session.updated_at < ?
                GROUP BY import_session.import_id, import_session.status, import_session.updated_at
                ORDER BY import_session.updated_at ASC, import_session.import_id ASC
                """,
                (cutoff,),
            ).fetchall()
        candidates = [
            {
                "import_id": str(row["import_id"]),
                "status": str(row["status"]),
                "updated_at": str(row["updated_at"]),
                "file_count": int(row["file_count"] or 0),
                "total_bytes": int(row["total_bytes"] or 0),
            }
            for row in rows
        ]
        result = {
            "ok": True,
            "summary": "",
            "cutoff": cutoff,
            "older_than_hours": float(older_than_hours),
            "dry_run": bool(dry_run),
            "candidate_count": len(candidates),
            "removed_count": 0,
            "removed_file_count": 0,
            "removed_bytes": 0,
            "candidates": candidates,
        }
        if dry_run:
            result["summary"] = f"Found {len(candidates)} abandoned import sessions eligible for cleanup."
            return result

        removed_count = 0
        removed_file_count = 0
        removed_bytes = 0
        for candidate in candidates:
            import_id = str(candidate["import_id"])
            session_dir = self.paths.import_sessions_dir / import_id
            if session_dir.exists():
                shutil.rmtree(session_dir)
            with connect_database(self.paths) as connection:
                with immediate_transaction(connection):
                    connection.execute("DELETE FROM import_file WHERE import_id = ?", (import_id,))
                    connection.execute(
                        """
                        DELETE FROM import_session
                        WHERE import_id = ? AND import_run_id IS NULL AND status IN ('collecting', 'failed', 'expired')
                        """,
                        (import_id,),
                    )
            removed_count += 1
            removed_file_count += int(candidate["file_count"])
            removed_bytes += int(candidate["total_bytes"])

        result["removed_count"] = removed_count
        result["removed_file_count"] = removed_file_count
        result["removed_bytes"] = removed_bytes
        result["summary"] = f"Removed {removed_count} abandoned import sessions."
        logger.info(
            "Gateway cleanup removed %s abandoned import sessions (%s files, %s bytes)",
            removed_count,
            removed_file_count,
            removed_bytes,
        )
        return result

    def cleanup_terminal_run_data(
        self,
        *,
        older_than_hours: float = 24.0,
        dry_run: bool = False,
        include_recoverable_failed: bool = False,
    ) -> dict[str, Any]:
        cutoff = (
            datetime.now(UTC) - timedelta(hours=max(float(older_than_hours), 0.0))
        ).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        with connect_database(self.paths) as connection:
            rows = connection.execute(
                """
                SELECT run_id, source_import_id, status, completed_at
                FROM import_run
                WHERE status IN ('complete', 'failed', 'cancelled')
                  AND completed_at IS NOT NULL
                  AND completed_at < ?
                ORDER BY completed_at ASC, run_id ASC
                """,
                (cutoff,),
            ).fetchall()

        candidates: list[dict[str, Any]] = []
        for row in rows:
            run_id = str(row["run_id"])
            if str(row["status"]) == "failed" and not include_recoverable_failed:
                recovery_candidate = self._merge_recovery_candidate(run_id)
                if recovery_candidate["recoverable"]:
                    continue
            run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
            import_dir = self.paths.import_sessions_dir / str(row["source_import_id"])
            cleanup_paths = [
                run_paths.input_dir,
                run_paths.artifacts_dir,
                run_paths.logs_dir,
                run_paths.tmp_dir,
                run_paths.run_dir / "import.db",
                run_paths.input_manifest,
                import_dir,
            ]
            existing_paths = [path for path in cleanup_paths if path.exists()]
            file_count, byte_count = self._path_totals(existing_paths)
            candidates.append(
                {
                    "run_id": run_id,
                    "source_import_id": str(row["source_import_id"]),
                    "status": str(row["status"]),
                    "completed_at": str(row["completed_at"]),
                    "file_count": file_count,
                    "total_bytes": byte_count,
                    "paths": [str(path) for path in existing_paths],
                }
            )

        result = {
            "ok": True,
            "summary": "",
            "cutoff": cutoff,
            "older_than_hours": float(older_than_hours),
            "dry_run": bool(dry_run),
            "include_recoverable_failed": bool(include_recoverable_failed),
            "candidate_count": len(candidates),
            "removed_run_count": 0,
            "removed_file_count": 0,
            "removed_bytes": 0,
            "candidates": candidates,
        }
        if dry_run:
            result["summary"] = f"Found {len(candidates)} terminal runs eligible for transient-data cleanup."
            return result

        removed_run_count = 0
        removed_file_count = 0
        removed_bytes = 0
        for candidate in candidates:
            for path_text in candidate["paths"]:
                self._delete_path(Path(path_text))
            removed_run_count += 1
            removed_file_count += int(candidate["file_count"])
            removed_bytes += int(candidate["total_bytes"])

        result["removed_run_count"] = removed_run_count
        result["removed_file_count"] = removed_file_count
        result["removed_bytes"] = removed_bytes
        result["summary"] = f"Removed transient data for {removed_run_count} terminal runs."
        logger.info(
            "Gateway cleanup removed transient data for %s terminal runs (%s files, %s bytes)",
            removed_run_count,
            removed_file_count,
            removed_bytes,
        )
        return result

    def reconcile_interrupted_runs(self) -> dict[str, Any]:
        now = utc_now()
        with connect_database(self.paths) as connection:
            rows = connection.execute(
                """
                SELECT run_id
                FROM import_run
                WHERE status = 'running'
                ORDER BY created_at ASC, run_id ASC
                """
            ).fetchall()
        interrupted_run_ids = [str(row["run_id"]) for row in rows]
        for run_id in interrupted_run_ids:
            with connect_database(self.paths) as connection:
                connection.execute(
                    """
                    UPDATE import_run
                    SET status = 'failed',
                        completed_at = ?,
                        error_code = ?,
                        error_message = ?
                    WHERE run_id = ? AND status = 'running'
                    """,
                    (
                        now,
                        "WORKER_INTERRUPTED",
                        "Gateway worker stopped before the run completed.",
                        run_id,
                    ),
                )
                connection.execute("DELETE FROM import_run_control WHERE run_id = ?", (run_id,))
                run = self._get_run_record(connection, run_id)
            run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
            run_state = read_json(run_paths.run_json) if run_paths.run_json.is_file() else {"run_id": run_id}
            run_state["status"] = "failed"
            run_state["completed_at"] = now
            run_state["updated_at"] = now
            run_state["error_code"] = "WORKER_INTERRUPTED"
            run_state["error_message"] = "Gateway worker stopped before the run completed."
            atomic_write_json(run_paths.run_json, run_state)
            if run is not None:
                logger.warning("Gateway reconciled interrupted run %s after startup", run_id)
        return {
            "ok": True,
            "summary": f"Reconciled {len(interrupted_run_ids)} interrupted runs.",
            "reconciled_count": len(interrupted_run_ids),
            "run_ids": interrupted_run_ids,
        }

    def record_storage_fault(self, *, error_code: str, message: str) -> None:
        self._storage_fault = {
            "error_code": error_code,
            "message": message,
        }

    def clear_storage_fault(self) -> None:
        self._storage_fault = None

    def seal_run_input(self, run_id: str) -> dict[str, Any]:
        with connect_database(self.paths) as connection:
            run_row = connection.execute(
                """
                SELECT run_id, source_import_id, created_at
                FROM import_run
                WHERE run_id = ?
                """,
                (run_id,),
            ).fetchone()
            if run_row is None:
                raise GatewayServiceError("RUN_NOT_FOUND", "Import run does not exist.", 404)
            source_rows = connection.execute(
                """
                SELECT import_file_id, client_filename, source_path_text, staging_relpath, path_hint, byte_size, created_at
                FROM import_file
                WHERE import_id = ?
                ORDER BY rowid ASC
                """,
                (str(run_row["source_import_id"]),),
            ).fetchall()
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        if run_paths.input_manifest.is_file():
            return read_json(run_paths.input_manifest)

        items_total = len(source_rows)
        self.mark_run_stage(run_id, stage="SEAL_INPUT", progress=0.01)
        sealed_files: list[dict[str, Any]] = []
        for index, row in enumerate(source_rows, start=1):
            sealed_input = self._seal_run_input_file(
                run_id=run_id,
                import_file_id=str(row["import_file_id"]),
                client_filename=str(row["client_filename"]),
                source_path_text=str(row["source_path_text"]),
                staging_relpath=str(row["staging_relpath"]),
                ordinal=index,
            )
            sealed_files.append(
                {
                    "import_file_id": str(row["import_file_id"]),
                    "client_filename": str(row["client_filename"]),
                    "path_hint": row["path_hint"],
                    "byte_size": int(row["byte_size"] or 0),
                    "created_at": row["created_at"],
                    "input_path": sealed_input["input_path"],
                    "input_relpath": sealed_input["input_relpath"],
                    "input_sha256": sealed_input["input_sha256"],
                }
            )
            self.record_stage_progress(
                run_id,
                stage="SEAL_INPUT",
                items_total=items_total,
                items_done=index,
                artifact="input_manifest.json",
            )
            self.checkpoint_pause(run_id, stage="SEAL_INPUT")
        sealed_at = utc_now()
        self._write_run_metadata(
            run_id=run_id,
            source_import_id=str(run_row["source_import_id"]),
            created_at=str(run_row["created_at"]),
            sealed_at=sealed_at,
            items=sealed_files,
        )
        logger.info("Gateway run %s sealed %s input files without copying bytes", run_id, len(sealed_files))
        return read_json(run_paths.input_manifest)

    def get_import_run(self, run_id: str) -> dict[str, Any]:
        with connect_database(self.paths) as connection:
            run = self._get_run_record(connection, run_id)
            if run is None:
                raise GatewayServiceError("RUN_NOT_FOUND", "Import run does not exist.", 404)
            control_state = self._get_run_control(connection, run_id)
        return self._serialize_run(run, control_state=control_state)

    def list_import_runs(self, *, limit: int = 20) -> dict[str, Any]:
        with connect_database(self.paths) as connection:
            rows = connection.execute(
                """
                SELECT import_run.run_id, import_run.status, import_run.current_stage, import_run.progress, import_run.created_at,
                       import_run.started_at, import_run.completed_at, import_run.error_code, import_run.error_message, import_run.report_json,
                       import_run_control.desired_state
                FROM import_run
                LEFT JOIN import_run_control ON import_run_control.run_id = import_run.run_id
                ORDER BY import_run.created_at DESC, import_run.run_id DESC
                LIMIT ?
                """,
                (max(1, limit),),
            ).fetchall()
        return {"items": [self._serialize_run(row, control_state=row["desired_state"]) for row in rows]}

    def get_recent_runs_for_ui(self, *, limit: int = 20) -> list[dict[str, Any]]:
        return list(self.list_import_runs(limit=limit)["items"])

    def request_pause_run(self, run_id: str) -> dict[str, Any]:
        now = utc_now()
        with connect_database(self.paths) as connection:
            run = self._get_run_record(connection, run_id)
            if run is None:
                raise GatewayServiceError("RUN_NOT_FOUND", "Import run does not exist.", 404)
            status = str(run["status"])
            if status in {"complete", "failed", "cancelled"}:
                raise GatewayServiceError("RUN_NOT_PAUSABLE", "Run cannot be paused in its current state.", 409)
            control = self._get_run_control(connection, run_id)
            if control == "paused":
                return self._serialize_run(run, control_state=control)
            desired_state = "paused" if status == "queued" else "pause_requested"
            connection.execute(
                """
                INSERT INTO import_run_control(run_id, desired_state, updated_at)
                VALUES (?, ?, ?)
                ON CONFLICT(run_id) DO UPDATE SET desired_state = excluded.desired_state, updated_at = excluded.updated_at
                """,
                (run_id, desired_state, now),
            )
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        run_state = read_json(run_paths.run_json) if run_paths.run_json.is_file() else {"run_id": run_id}
        run_state["status"] = "paused" if status == "queued" else "pausing"
        run_state["updated_at"] = now
        atomic_write_json(run_paths.run_json, run_state)
        return self.get_import_run_detail(run_id)

    def resume_paused_run(self, run_id: str) -> dict[str, Any]:
        now = utc_now()
        with connect_database(self.paths) as connection:
            run = self._get_run_record(connection, run_id)
            if run is None:
                raise GatewayServiceError("RUN_NOT_FOUND", "Import run does not exist.", 404)
            control = self._get_run_control(connection, run_id)
            if control != "paused":
                raise GatewayServiceError("RUN_NOT_RESUMABLE", "Run is not paused.", 409)
            connection.execute("DELETE FROM import_run_control WHERE run_id = ?", (run_id,))
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        run_state = read_json(run_paths.run_json) if run_paths.run_json.is_file() else {"run_id": run_id}
        run_state["status"] = str(run["status"])
        run_state["updated_at"] = now
        atomic_write_json(run_paths.run_json, run_state)
        return self.get_import_run_detail(run_id)

    def should_pause_run(self, run_id: str) -> bool:
        with connect_database(self.paths) as connection:
            return self._get_run_control(connection, run_id) == "pause_requested"

    def checkpoint_pause(self, run_id: str, *, stage: str | None) -> None:
        if self.should_pause_run(run_id):
            self.acknowledge_pause_run(run_id, stage=stage)
            raise GatewayPauseRequested(run_id=run_id, stage=stage)

    def acknowledge_pause_run(self, run_id: str, *, stage: str | None) -> dict[str, Any]:
        now = utc_now()
        with connect_database(self.paths) as connection:
            control = self._get_run_control(connection, run_id)
            if control != "pause_requested":
                run = self._get_run_record(connection, run_id)
                if run is None:
                    raise GatewayServiceError("RUN_NOT_FOUND", "Import run does not exist.", 404)
                return self._serialize_run(run, control_state=self._get_run_control(connection, run_id))
            connection.execute(
                """
                UPDATE import_run
                SET status = 'queued', current_stage = ?, completed_at = NULL, error_code = NULL, error_message = NULL
                WHERE run_id = ?
                """,
                (stage, run_id),
            )
            connection.execute(
                """
                INSERT INTO import_run_control(run_id, desired_state, updated_at)
                VALUES (?, 'paused', ?)
                ON CONFLICT(run_id) DO UPDATE SET desired_state = 'paused', updated_at = excluded.updated_at
                """,
                (run_id, now),
            )
            run = self._get_run_record(connection, run_id)
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        run_state = read_json(run_paths.run_json) if run_paths.run_json.is_file() else {"run_id": run_id}
        run_state["status"] = "paused"
        run_state["updated_at"] = now
        run_state["current_stage"] = stage
        if stage in {"SQLITE_WRITE", "CANONICALIZATION", "MERGE"}:
            run_state["resume_from_stage"] = stage
        if stage:
            run_state.setdefault("stages", {})
            stage_state = run_state["stages"].setdefault(stage, {})
            stage_state["state"] = "paused"
            stage_state["updated_at"] = now
        atomic_write_json(run_paths.run_json, run_state)
        if run is None:
            raise GatewayServiceError("RUN_NOT_FOUND", "Import run does not exist.", 404)
        logger.info("Gateway paused run %s at stage %s", run_id, stage or "unknown")
        return self._serialize_run(run, control_state="paused")

    def resume_from_stage(self, run_id: str) -> str | None:
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        if not run_paths.run_json.is_file():
            return None
        run_state = read_json(run_paths.run_json)
        value = run_state.get("resume_from_stage")
        return str(value) if isinstance(value, str) else None

    def claim_next_run(self) -> dict[str, Any] | None:
        try:
            with connect_database(self.paths) as connection:
                with immediate_transaction(connection):
                    running = connection.execute(
                        """
                        SELECT import_run.run_id
                        FROM import_run
                        LEFT JOIN import_run_control ON import_run_control.run_id = import_run.run_id
                        WHERE import_run.status = 'running'
                          AND COALESCE(import_run_control.desired_state, '') != 'paused'
                        LIMIT 1
                        """
                    ).fetchone()
                    if running is not None:
                        return None
                    row = connection.execute(
                        """
                        SELECT import_run.run_id
                        FROM import_run
                        JOIN import_session ON import_session.import_id = import_run.source_import_id
                        LEFT JOIN import_run_control ON import_run_control.run_id = import_run.run_id
                        WHERE import_run.status = 'queued'
                          AND import_session.status = 'committed'
                          AND import_run_control.run_id IS NULL
                        ORDER BY import_run.created_at ASC, import_run.run_id ASC
                        LIMIT 1
                        """
                    ).fetchone()
                    if row is None:
                        return None
                    now = utc_now()
                    run_id = str(row["run_id"])
                    connection.execute(
                        """
                        UPDATE import_run
                        SET status = 'running', current_stage = NULL, started_at = ?, progress = 0.0
                        WHERE run_id = ? AND status = 'queued'
                        """,
                        (now, run_id),
                    )
                    updated = connection.execute(
                        """
                        SELECT run_id, status, current_stage, progress, created_at, started_at, completed_at, error_code, error_message, report_json
                        FROM import_run
                        WHERE run_id = ?
                        """,
                        (run_id,),
                    ).fetchone()
        except sqlite3.OperationalError as exc:
            if "locked" in str(exc).lower():
                logger.warning("Gateway claim_next_run skipped because the database is locked")
                return None
            raise
        if updated is None or str(updated["status"]) != "running":
            return None
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        run_state = read_json(run_paths.run_json) if run_paths.run_json.is_file() else {"run_id": run_id}
        run_state["status"] = "running"
        run_state["current_stage"] = None
        run_state["started_at"] = updated["started_at"]
        run_state["updated_at"] = updated["started_at"]
        atomic_write_json(run_paths.run_json, run_state)
        return self._serialize_run(updated)

    def complete_placeholder_run(self, run_id: str) -> dict[str, Any]:
        collected_files = self._count_run_items(run_id)
        report = {
            "collected_files": collected_files,
            "processed_items": collected_files,
            "new_content_count": 0,
            "new_photo_count": 0,
            "new_path_count": 0,
            "redundant_item_count": 0,
            "failed_item_count": 0,
        }
        now = utc_now()
        with connect_database(self.paths) as connection:
            connection.execute(
                """
                UPDATE import_run
                SET status = 'complete',
                    current_stage = NULL,
                    completed_at = ?,
                    progress = 1.0,
                    report_json = ?
                WHERE run_id = ?
                """,
                (now, json.dumps(report, sort_keys=True), run_id),
            )
            connection.execute(
                """
                UPDATE import_run_item
                SET status = 'complete'
                WHERE run_id = ?
                """,
                (run_id,),
            )
            connection.execute("DELETE FROM import_run_control WHERE run_id = ?", (run_id,))
            run = self._get_run_record(connection, run_id)
        if run is None:
            raise GatewayServiceError("RUN_NOT_FOUND", "Import run does not exist.", 404)
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        run_state = read_json(run_paths.run_json) if run_paths.run_json.is_file() else {"run_id": run_id}
        run_state["status"] = "complete"
        run_state["current_stage"] = None
        run_state["completed_at"] = now
        run_state["updated_at"] = now
        run_state["report"] = report
        run_state.pop("resume_from_stage", None)
        atomic_write_json(run_paths.run_json, run_state)
        return self._serialize_run(run)

    def complete_run(self, run_id: str, *, report: dict[str, Any]) -> dict[str, Any]:
        now = utc_now()
        final_report = dict(report)
        final_report["semantic_enrichment_suggestions"] = self._semantic_enrichment_suggestions()
        source_import_id: str | None = None
        with connect_database(self.paths) as connection:
            connection.execute(
                """
                UPDATE import_run
                SET status = 'complete',
                    current_stage = NULL,
                    completed_at = ?,
                    progress = 1.0,
                    report_json = ?
                WHERE run_id = ?
                """,
                (now, json.dumps(final_report, sort_keys=True), run_id),
            )
            connection.execute("DELETE FROM import_run_control WHERE run_id = ?", (run_id,))
            run = self._get_run_record(connection, run_id)
            if run is not None:
                source_import_id = str(run["source_import_id"])
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        run_state = read_json(run_paths.run_json) if run_paths.run_json.is_file() else {"run_id": run_id}
        run_state["status"] = "complete"
        run_state["current_stage"] = None
        run_state["completed_at"] = now
        run_state["updated_at"] = now
        run_state["report"] = final_report
        run_state.pop("resume_from_stage", None)
        atomic_write_json(run_paths.run_json, run_state)
        if run is None:
            raise GatewayServiceError("RUN_NOT_FOUND", "Import run does not exist.", 404)
        if source_import_id:
            import_dir = self.paths.import_sessions_dir / source_import_id
            if import_dir.exists():
                shutil.rmtree(import_dir)
                logger.info("Gateway run %s removed committed import session data %s after completion", run_id, source_import_id)
        logger.info("Gateway run %s completed: %s", run_id, json.dumps(final_report, sort_keys=True))
        return self._serialize_run(run)

    def _semantic_enrichment_suggestions(self) -> list[dict[str, Any]]:
        suggestions: list[dict[str, Any]] = []
        for job_name in ("duplicate_semantic", "has_people"):
            config = SEMANTIC_ENRICHMENT_JOBS[job_name]
            suggestions.append(
                {
                    "category": "semantic_enrichment",
                    "job_name": job_name,
                    "status": SEMANTIC_ENRICHMENT_STATUS_PENDING,
                    "summary": str(config["summary"]),
                    "purpose": str(config["purpose"]),
                    "impact": str(config["impact"]),
                    "priority": str(config["priority"]),
                    "recommended_action": str(config["recommended_action"]),
                    "command": str(config["command"]),
                }
            )
        return suggestions

    def mark_run_stage(self, run_id: str, *, stage: str, progress: float) -> None:
        now = utc_now()
        with connect_database(self.paths) as connection:
            connection.execute(
                """
                UPDATE import_run
                SET current_stage = ?, progress = ?, started_at = COALESCE(started_at, ?)
                WHERE run_id = ?
                """,
                (stage, progress, now, run_id),
            )
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        run_state = read_json(run_paths.run_json) if run_paths.run_json.is_file() else {"run_id": run_id}
        run_state["status"] = "running"
        run_state["current_stage"] = stage
        run_state["updated_at"] = now
        run_state.setdefault("stages", {})
        run_state["stages"].setdefault(stage, {})
        run_state["stages"][stage]["state"] = "running"
        run_state["stages"][stage]["started_at"] = run_state["stages"][stage].get("started_at") or now
        atomic_write_json(run_paths.run_json, run_state)

    def record_stage_progress(
        self,
        run_id: str,
        *,
        stage: str,
        items_total: int,
        items_done: int,
        artifact: str,
    ) -> None:
        progress_map = {
            "SEAL_INPUT": 0.05,
            "SCANNING": 0.2,
            "METADATA_EXTRACTION": 0.55,
            "CADIS_LOOKUP": 0.8,
            "SQLITE_WRITE": 0.95,
            "CANONICALIZATION": 0.97,
            "MERGE": 0.99,
        }
        now = utc_now()
        with connect_database(self.paths) as connection:
            connection.execute(
                """
                UPDATE import_run
                SET current_stage = ?, progress = ?
                WHERE run_id = ?
                """,
                (stage, progress_map.get(stage, 0.0), run_id),
            )
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        run_state = read_json(run_paths.run_json) if run_paths.run_json.is_file() else {"run_id": run_id}
        run_state["status"] = "running"
        run_state.setdefault("stages", {})
        stage_state = run_state["stages"].setdefault(stage, {})
        stage_state["state"] = "running" if items_done < items_total else "complete"
        stage_state["items_total"] = items_total
        stage_state["items_done"] = items_done
        stage_state["artifact"] = artifact
        stage_state["started_at"] = stage_state.get("started_at") or now
        stage_state["updated_at"] = now
        if items_done >= items_total:
            stage_state["completed_at"] = now
        if items_done >= items_total and stage in {"SEAL_INPUT", "SQLITE_WRITE", "CANONICALIZATION", "MERGE"}:
            run_state["current_stage"] = None
        else:
            run_state["current_stage"] = stage
        run_state["updated_at"] = now
        atomic_write_json(run_paths.run_json, run_state)

    def fail_run(self, run_id: str, *, error_code: str, error_message: str) -> dict[str, Any]:
        now = utc_now()
        with connect_database(self.paths) as connection:
            connection.execute(
                """
                UPDATE import_run
                SET status = 'failed',
                    completed_at = ?,
                    error_code = ?,
                    error_message = ?
                WHERE run_id = ?
                """,
                (now, error_code, error_message, run_id),
            )
            connection.execute(
                """
                UPDATE import_run_item
                SET status = 'failed', error_code = ?, error_message = ?
                WHERE run_id = ? AND status = 'pending'
                """,
                (error_code, error_message, run_id),
            )
            connection.execute("DELETE FROM import_run_control WHERE run_id = ?", (run_id,))
            run = self._get_run_record(connection, run_id)
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        run_state = read_json(run_paths.run_json) if run_paths.run_json.is_file() else {"run_id": run_id}
        run_state["status"] = "failed"
        run_state["error_code"] = error_code
        run_state["error_message"] = error_message
        run_state["updated_at"] = now
        run_state["completed_at"] = now
        run_state.pop("resume_from_stage", None)
        atomic_write_json(run_paths.run_json, run_state)
        if run is None:
            raise GatewayServiceError("RUN_NOT_FOUND", "Import run does not exist.", 404)
        logger.error("Gateway run %s failed: %s %s", run_id, error_code, error_message)
        return self._serialize_run(run)

    def fail_run_item(
        self,
        run_id: str,
        *,
        import_file_id: str,
        error_code: str,
        error_message: str,
    ) -> None:
        with connect_database(self.paths) as connection:
            connection.execute(
                """
                UPDATE import_run_item
                SET status = 'failed',
                    error_code = ?,
                    error_message = ?
                WHERE run_id = ? AND import_file_id = ?
                """,
                (error_code, error_message, run_id, import_file_id),
            )

    def recover_merge_run(self, run_id: str, *, merge_runner=None) -> dict[str, Any]:
        run = self.get_import_run_detail(run_id)
        candidate = self._merge_recovery_candidate(run_id)
        if not candidate["recoverable"]:
            raise GatewayServiceError("RUN_NOT_RECOVERABLE", str(candidate["reason"]), 409)

        with connect_database(self.paths) as connection:
            status_rows = connection.execute(
                "SELECT import_file_id, status FROM import_run_item WHERE run_id = ?",
                (run_id,),
            ).fetchall()
        retry_import_file_ids = [str(row["import_file_id"]) for row in status_rows if str(row["status"]) != "complete"]
        previously_completed_items = sum(1 for row in status_rows if str(row["status"]) == "complete")
        if not retry_import_file_ids:
            raise GatewayServiceError("RUN_NOT_RECOVERABLE", "Run has no recoverable non-complete items.", 409)

        self._prepare_merge_recovery_state(
            run_id,
            retry_import_file_ids=retry_import_file_ids,
            previously_completed_items=previously_completed_items,
        )

        if merge_runner is None:
            from eona.gateway_merge import GatewayMergeRunner

            merge_runner = GatewayMergeRunner(service=self)
        merge_report = merge_runner.execute_run(run_id, retry_import_file_ids=set(retry_import_file_ids))
        report = self._build_merge_recovery_report(
            run_id,
            merge_report=merge_report.as_dict(),
            retried_items=len(retry_import_file_ids),
            previously_completed_items=previously_completed_items,
        )
        return self.complete_run(run_id, report=report)

    def resume_paused_merge_run(self, run_id: str, *, merge_runner) -> dict[str, Any]:
        with connect_database(self.paths) as connection:
            status_rows = connection.execute(
                "SELECT import_file_id, status FROM import_run_item WHERE run_id = ?",
                (run_id,),
            ).fetchall()
        retry_import_file_ids = [str(row["import_file_id"]) for row in status_rows if str(row["status"]) != "complete"]
        previously_completed_items = sum(1 for row in status_rows if str(row["status"]) == "complete")
        merge_report = merge_runner.execute_run(run_id, retry_import_file_ids=set(retry_import_file_ids))
        report = self._build_merge_recovery_report(
            run_id,
            merge_report=merge_report.as_dict(),
            retried_items=len(retry_import_file_ids),
            previously_completed_items=previously_completed_items,
        )
        report["recovery_mode"] = "pause_resume"
        return self.complete_run(run_id, report=report)

    def doctor(self, *, abandoned_older_than_hours: float = 24.0) -> dict[str, Any]:
        readiness = self.readiness()
        with connect_database(self.paths) as connection:
            import_status_rows = connection.execute(
                "SELECT status, COUNT(*) FROM import_session GROUP BY status ORDER BY status"
            ).fetchall()
            run_status_rows = connection.execute(
                "SELECT status, COUNT(*) FROM import_run GROUP BY status ORDER BY status"
            ).fetchall()
            failed_run_ids = [
                str(row[0])
                for row in connection.execute(
                    "SELECT run_id FROM import_run WHERE status = 'failed' ORDER BY created_at ASC"
                ).fetchall()
            ]
            semantic_enrichment = self._semantic_enrichment_status(connection)
        abandoned = self.cleanup_abandoned_import_sessions(
            older_than_hours=abandoned_older_than_hours,
            dry_run=True,
        )
        recoverable_runs = [
            candidate
            for run_id in failed_run_ids
            if (candidate := self._merge_recovery_candidate(run_id)).get("recoverable")
        ]
        filesystem = self._filesystem_doctor_status()

        warnings: list[str] = []
        if abandoned.get("candidate_count", 0):
            warnings.append(
                f"{abandoned['candidate_count']} abandoned import session(s) are eligible for cleanup."
            )
        if recoverable_runs:
            warnings.append(f"{len(recoverable_runs)} failed run(s) can be recovered with `gateway recover-merge`.")
        if filesystem["orphan_run_dir_count"]:
            warnings.append(f"{filesystem['orphan_run_dir_count']} orphaned run directory(s) found on disk.")
        if filesystem["orphan_import_session_dir_count"]:
            warnings.append(f"{filesystem['orphan_import_session_dir_count']} orphaned import session directory(s) found on disk.")
        failed_jobs = [job["job_name"] for job in semantic_enrichment["jobs"] if job["status"] == SEMANTIC_ENRICHMENT_STATUS_FAILED]
        running_jobs = [job["job_name"] for job in semantic_enrichment["jobs"] if job["status"] == SEMANTIC_ENRICHMENT_STATUS_RUNNING]
        pending_jobs = [job["job_name"] for job in semantic_enrichment["jobs"] if job["status"] == SEMANTIC_ENRICHMENT_STATUS_PENDING]
        if failed_jobs:
            warnings.append(f"Semantic enrichment failed for: {', '.join(failed_jobs)}.")
        if running_jobs:
            warnings.append(f"Semantic enrichment running for: {', '.join(running_jobs)}.")
        if pending_jobs:
            warnings.append(f"Semantic enrichment pending for: {', '.join(pending_jobs)}.")

        ok = bool(readiness.get("ok")) and not warnings
        summary = "Gateway doctor found no issues." if ok else "Gateway doctor found issues that need attention."
        operational_items = self._doctor_operational_items(
            readiness=readiness,
            abandoned=abandoned,
            recoverable_runs=recoverable_runs,
            semantic_enrichment=semantic_enrichment,
            filesystem=filesystem,
        )
        return {
            "ok": ok,
            "summary": summary,
            "readiness": readiness,
            "imports": {
                "by_status": {str(row[0]): int(row[1]) for row in import_status_rows},
                "abandoned_candidates": abandoned,
            },
            "runs": {
                "by_status": {str(row[0]): int(row[1]) for row in run_status_rows},
                "recoverable_merge_runs": recoverable_runs,
            },
            "semantic_enrichment": semantic_enrichment,
            "filesystem": filesystem,
            "warnings": warnings,
            "operational_items": operational_items,
        }

    def _doctor_operational_items(
        self,
        *,
        readiness: dict[str, Any],
        abandoned: dict[str, Any],
        recoverable_runs: list[dict[str, Any]],
        semantic_enrichment: dict[str, Any],
        filesystem: dict[str, Any],
    ) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        for job in semantic_enrichment.get("jobs", []):
            items.append(
                {
                    "category": "semantic_enrichment",
                    "name": str(job["job_name"]),
                    "status": str(job["status"]),
                    "summary": str(job["summary"]),
                    "purpose": str(job.get("purpose") or ""),
                    "impact_if_skipped": str(job.get("impact") or ""),
                    "priority": str(job.get("priority") or "better_have"),
                    "what_to_do_now": str(job.get("recommended_action") or ""),
                    "command": str(job.get("command") or ""),
                    "user_explanation": self._semantic_job_user_explanation(job),
                }
            )
        if recoverable_runs:
            items.append(
                {
                    "category": "recovery",
                    "name": "recoverable_merge_runs",
                    "status": "needs_attention",
                    "summary": f"{len(recoverable_runs)} failed import run(s) can be recovered.",
                    "purpose": "Recover interrupted merge work without re-importing the whole source set.",
                    "impact_if_skipped": "Those failed import runs will remain incomplete until recovered or re-imported.",
                    "priority": "must_have",
                    "what_to_do_now": "Inspect and recover the failed merge run if you still want its imported photos.",
                    "command": "eona-gateway recover-merge <run_id> --json",
                    "user_explanation": "Eona found an import run that failed after partial work. Recover it if those photos still matter.",
                }
            )
        if abandoned.get("candidate_count", 0):
            items.append(
                {
                    "category": "cleanup",
                    "name": "abandoned_import_sessions",
                    "status": "needs_attention",
                    "summary": f"{abandoned['candidate_count']} abandoned import session(s) can be cleaned up.",
                    "purpose": "Remove leftover staging data from incomplete import sessions.",
                    "impact_if_skipped": "Disk usage and operational clutter may increase, but corpus truth is not affected.",
                    "priority": "better_have",
                    "what_to_do_now": "Clean up abandoned import sessions when convenient.",
                    "command": "eona-gateway cleanup-abandoned --json",
                    "user_explanation": "Eona found leftover temporary import data. Cleanup is recommended but not urgent.",
                }
            )
        if filesystem.get("orphan_run_dir_count") or filesystem.get("orphan_import_session_dir_count"):
            details = []
            if filesystem.get("orphan_run_dir_count"):
                details.append(f"{filesystem['orphan_run_dir_count']} orphaned run directory(s)")
            if filesystem.get("orphan_import_session_dir_count"):
                details.append(f"{filesystem['orphan_import_session_dir_count']} orphaned import session directory(s)")
            items.append(
                {
                    "category": "cleanup",
                    "name": "orphaned_filesystem_state",
                    "status": "needs_attention",
                    "summary": ", ".join(details) + " found on disk.",
                    "purpose": "Keep Gateway working directories tidy and easier to operate.",
                    "impact_if_skipped": "Disk clutter may accumulate and make troubleshooting harder.",
                    "priority": "better_have",
                    "what_to_do_now": "Review cleanup actions if the orphaned directories are no longer needed.",
                    "command": "",
                    "user_explanation": "Eona found leftover directories on disk. This is maintenance work, not a corpus correctness problem.",
                }
            )
        if readiness.get("lifecycle_state") in {"blocked", "failed", "needs_attention", "reimport_suggested", "pending_acceptance"}:
            items.append(
                {
                    "category": "runtime_state",
                    "name": "gateway_readiness",
                    "status": str(readiness.get("lifecycle_state")),
                    "summary": str(readiness.get("summary") or "Gateway runtime needs operator review."),
                    "purpose": "Explain whether the current Gateway runtime and stored corpus can be trusted as-is.",
                    "impact_if_skipped": "You may miss a runtime issue or truth-affecting upgrade recommendation.",
                    "priority": "must_have" if readiness.get("lifecycle_state") in {"blocked", "failed", "reimport_suggested"} else "better_have",
                    "what_to_do_now": "Review Gateway readiness details before continuing with additional imports or upgrades.",
                    "command": "",
                    "user_explanation": "Eona has a runtime or maintenance state worth reviewing before you proceed.",
                }
            )
        return items

    def _semantic_job_user_explanation(self, job: dict[str, Any]) -> str:
        job_name = str(job.get("job_name") or "")
        status = str(job.get("status") or "")
        if job_name == "duplicate_semantic":
            if status == SEMANTIC_ENRICHMENT_STATUS_COMPLETED:
                return "Duplicate cleanup is already done, so counts and galleries should look cleaner."
            return "Duplicate cleanup is optional but recommended if you want cleaner counts and fewer repeated-looking photos."
        if job_name == "has_people":
            if status == SEMANTIC_ENRICHMENT_STATUS_COMPLETED:
                return "People tagging is already available, so Eona can search for photos with faces."
            return "People tagging is optional, but needed if you want selfie, portrait, or group-photo search."
        return "This semantic enrichment improves Eona behavior, but may not be required for basic use."

    def _build_readiness_operational_summary(
        self,
        *,
        readiness: dict[str, Any],
        semantic_enrichment: dict[str, Any],
        runtime_upgrade: dict[str, Any],
        content_store: dict[str, Any],
    ) -> dict[str, Any]:
        lifecycle_state = str(readiness.get("lifecycle_state") or "ready")
        usable_now = lifecycle_state not in {"blocked", "failed", "checking"}
        required_actions: list[dict[str, Any]] = []
        recommended_actions: list[dict[str, Any]] = []

        if content_store.get("status") not in {"ok", "checking"}:
            required_actions.append(
                {
                    "name": "content_store_integrity",
                    "priority": "must_have",
                    "what_it_is": "Content integrity problem",
                    "purpose": "Ensure canonical photo bytes still exist and can be trusted.",
                    "impact_if_skipped": "Eona may return broken or incomplete photos.",
                    "what_to_do_now": "Investigate the content store integrity failure before continuing.",
                    "command": "",
                }
            )

        upgrade_state = str(runtime_upgrade.get("status") or "ready")
        if upgrade_state in {"blocked", "failed", "reimport_suggested", "pending_acceptance", "needs_attention"}:
            required_actions.append(
                {
                    "name": "runtime_upgrade",
                    "priority": "must_have" if upgrade_state in {"blocked", "failed", "reimport_suggested"} else "better_have",
                    "what_it_is": "Runtime or truth-maintenance review",
                    "purpose": "Make sure the current runtime and stored corpus are still valid together.",
                    "impact_if_skipped": "You may miss a truth-affecting upgrade requirement or a runtime issue.",
                    "what_to_do_now": str(runtime_upgrade.get("summary") or "Review runtime upgrade details."),
                    "command": "",
                }
            )

        for job in semantic_enrichment.get("jobs", []):
            status = str(job.get("status") or "")
            if status in {SEMANTIC_ENRICHMENT_STATUS_PENDING, SEMANTIC_ENRICHMENT_STATUS_RUNNING, SEMANTIC_ENRICHMENT_STATUS_FAILED}:
                recommended_actions.append(
                    {
                        "name": str(job.get("job_name") or ""),
                        "priority": str(job.get("priority") or "better_have"),
                        "what_it_is": str(job.get("summary") or ""),
                        "purpose": str(job.get("purpose") or ""),
                        "impact_if_skipped": str(job.get("impact") or ""),
                        "what_to_do_now": str(job.get("recommended_action") or ""),
                        "command": str(job.get("command") or ""),
                    }
                )

        if usable_now and not required_actions and not recommended_actions:
            user_message = "Eona is ready now and no immediate action is recommended."
        elif usable_now and not required_actions:
            user_message = "Eona is usable now. Optional improvements are available."
        elif usable_now:
            user_message = "Eona is usable now, but there are important maintenance items to review."
        else:
            user_message = "Eona is not ready for normal use yet. Resolve the required actions first."

        return {
            "usable_now": usable_now,
            "required_actions": required_actions,
            "recommended_actions": recommended_actions,
            "user_message": user_message,
        }

    def _upsert_semantic_enrichment_job(
        self,
        connection: sqlite3.Connection,
        *,
        job_name: str,
        semantic_version: int,
        status: str,
        summary: str,
        total_rows: int = 0,
        processed_rows: int = 0,
        updated_rows: int = 0,
        failed_rows: int = 0,
        last_error: str | None = None,
        started_at: str | None = None,
        completed_at: str | None = None,
    ) -> None:
        connection.execute(
            """
            INSERT INTO semantic_enrichment_job(
                job_name,
                semantic_version,
                status,
                summary,
                total_rows,
                processed_rows,
                updated_rows,
                failed_rows,
                last_error,
                started_at,
                completed_at,
                updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(job_name) DO UPDATE SET
                semantic_version = excluded.semantic_version,
                status = excluded.status,
                summary = excluded.summary,
                total_rows = excluded.total_rows,
                processed_rows = excluded.processed_rows,
                updated_rows = excluded.updated_rows,
                failed_rows = excluded.failed_rows,
                last_error = excluded.last_error,
                started_at = excluded.started_at,
                completed_at = excluded.completed_at,
                updated_at = excluded.updated_at
            """,
            (
                job_name,
                semantic_version,
                status,
                summary,
                total_rows,
                processed_rows,
                updated_rows,
                failed_rows,
                last_error,
                started_at,
                completed_at,
                utc_now(),
            ),
        )

    def _semantic_enrichment_status(self, connection: sqlite3.Connection) -> dict[str, Any]:
        rows = connection.execute(
            """
            SELECT
                job_name,
                semantic_version,
                status,
                summary,
                total_rows,
                processed_rows,
                updated_rows,
                failed_rows,
                last_error,
                started_at,
                completed_at,
                updated_at
            FROM semantic_enrichment_job
            ORDER BY job_name
            """
        ).fetchall()
        by_name = {str(row["job_name"]): row for row in rows}
        jobs: list[dict[str, Any]] = []
        for job_name, config in SEMANTIC_ENRICHMENT_JOBS.items():
            row = by_name.get(job_name)
            if row is None:
                jobs.append(
                    {
                        "category": "semantic_enrichment",
                        "job_name": job_name,
                        "semantic_version": int(config["semantic_version"]),
                        "status": SEMANTIC_ENRICHMENT_STATUS_PENDING,
                        "summary": str(config["summary"]),
                        "purpose": str(config["purpose"]),
                        "impact": str(config["impact"]),
                        "priority": str(config["priority"]),
                        "recommended_action": str(config["recommended_action"]),
                        "command": str(config["command"]),
                        "total_rows": 0,
                        "processed_rows": 0,
                        "updated_rows": 0,
                        "failed_rows": 0,
                        "last_error": None,
                        "started_at": None,
                        "completed_at": None,
                        "updated_at": None,
                    }
                )
                continue
            jobs.append(
                {
                    "category": "semantic_enrichment",
                    "job_name": str(row["job_name"]),
                    "semantic_version": int(row["semantic_version"]),
                    "status": str(row["status"]),
                    "summary": str(row["summary"]),
                    "purpose": str(config["purpose"]),
                    "impact": str(config["impact"]),
                    "priority": str(config["priority"]),
                    "recommended_action": str(config["recommended_action"]),
                    "command": str(config["command"]),
                    "total_rows": int(row["total_rows"]),
                    "processed_rows": int(row["processed_rows"]),
                    "updated_rows": int(row["updated_rows"]),
                    "failed_rows": int(row["failed_rows"]),
                    "last_error": row["last_error"],
                    "started_at": row["started_at"],
                    "completed_at": row["completed_at"],
                    "updated_at": row["updated_at"],
                }
            )
        aggregate_status = SEMANTIC_ENRICHMENT_STATUS_COMPLETED
        if any(job["status"] == SEMANTIC_ENRICHMENT_STATUS_FAILED for job in jobs):
            aggregate_status = SEMANTIC_ENRICHMENT_STATUS_FAILED
        elif any(job["status"] == SEMANTIC_ENRICHMENT_STATUS_RUNNING for job in jobs):
            aggregate_status = SEMANTIC_ENRICHMENT_STATUS_RUNNING
        elif any(job["status"] == SEMANTIC_ENRICHMENT_STATUS_PENDING for job in jobs):
            aggregate_status = SEMANTIC_ENRICHMENT_STATUS_PENDING
        if aggregate_status == SEMANTIC_ENRICHMENT_STATUS_COMPLETED:
            summary = "Semantic enrichment jobs are complete."
        elif aggregate_status == SEMANTIC_ENRICHMENT_STATUS_RUNNING:
            summary = "Semantic enrichment jobs are running."
        elif aggregate_status == SEMANTIC_ENRICHMENT_STATUS_FAILED:
            summary = "Semantic enrichment jobs need attention."
        else:
            summary = "Semantic enrichment jobs are pending."
        return {
            "status": aggregate_status,
            "summary": summary,
            "jobs": jobs,
        }

    def get_semantic_enrichment_job(self, job_name: str) -> dict[str, Any]:
        normalized_job_name = str(job_name).strip()
        with connect_database(self.paths) as connection:
            payload = self._semantic_enrichment_status(connection)
        for job in payload["jobs"]:
            if str(job.get("job_name")) == normalized_job_name:
                return dict(job)
        raise GatewayServiceError(
            "SEMANTIC_JOB_NOT_FOUND",
            f"Unknown semantic enrichment job `{normalized_job_name}`.",
            404,
        )

    def _report_semantic_enrichment_progress(
        self,
        *,
        job_name: str,
        semantic_version: int,
        summary: str,
        total_rows: int,
        processed_rows: int,
        updated_rows: int = 0,
        failed_rows: int = 0,
        started_at: str | None = None,
    ) -> None:
        with connect_database(self.paths) as connection:
            with immediate_transaction(connection):
                self._upsert_semantic_enrichment_job(
                    connection,
                    job_name=job_name,
                    semantic_version=semantic_version,
                    status=SEMANTIC_ENRICHMENT_STATUS_RUNNING,
                    summary=summary,
                    total_rows=total_rows,
                    processed_rows=processed_rows,
                    updated_rows=updated_rows,
                    failed_rows=failed_rows,
                    started_at=started_at,
                )

    def backfill_photo_locations(
        self,
        *,
        limit: int | None = None,
        batch_size: int = 250,
        normalizer: Any | None = None,
        should_rerun: Any | None = None,
        progress_label: str | None = None,
    ) -> dict[str, Any]:
        if batch_size < 1:
            raise GatewayServiceError("INVALID_BATCH_SIZE", "batch_size must be at least 1.", 400)
        resolved_limit = None if limit is None else max(0, int(limit))
        location_normalizer = normalizer or self._default_location_normalizer()

        scanned = 0
        updated = 0
        skipped_no_gps = 0
        failed = 0
        failures: list[dict[str, Any]] = []
        last_photo_id: str | None = None
        progress_step = 1000
        next_progress_log = progress_step

        while True:
            params: list[Any] = []
            sql = """
                SELECT photo_id, raw_latitude, raw_longitude, cadis_version, cadis_result_json
                FROM photo
            """
            if last_photo_id is not None:
                sql += " WHERE photo_id > ?"
                params.append(last_photo_id)
            sql += " ORDER BY photo_id ASC LIMIT ?"
            params.append(batch_size)

            with connect_database(self.paths) as connection:
                rows = connection.execute(sql, tuple(params)).fetchall()
            if not rows:
                break

            for row in rows:
                photo_id = str(row["photo_id"])
                last_photo_id = photo_id
                if resolved_limit is not None and scanned >= resolved_limit:
                    break
                scanned += 1
                latitude = row["raw_latitude"]
                longitude = row["raw_longitude"]
                if not isinstance(latitude, (int, float)) or not isinstance(longitude, (int, float)):
                    skipped_no_gps += 1
                    continue
                row_payload = {
                    "photo_id": photo_id,
                    "raw_latitude": latitude,
                    "raw_longitude": longitude,
                    "cadis_version": row["cadis_version"],
                    "cadis_result_json": row["cadis_result_json"],
                }
                if should_rerun is None:
                    if row["cadis_result_json"] is not None:
                        continue
                elif not bool(should_rerun(row_payload)):
                    continue
                try:
                    normalized = location_normalizer.normalize(float(latitude), float(longitude))
                except Exception as exc:
                    failed += 1
                    failures.append({"photo_id": photo_id, "error": str(exc)})
                    continue
                with connect_database(self.paths) as connection:
                    connection.execute(
                        """
                        UPDATE photo
                        SET cadis_result_json = ?, cadis_version = ?, location_detail = ?
                        WHERE photo_id = ?
                        """,
                        (
                            normalized.cadis_result_json,
                            normalized.cadis_version,
                            normalized.detail,
                            photo_id,
                        ),
                    )
                updated += 1
                if progress_label and updated >= next_progress_log:
                    logger.info(
                        "Gateway %s progress: scanned=%s updated=%s skipped_no_gps=%s failed=%s",
                        progress_label,
                        scanned,
                        updated,
                        skipped_no_gps,
                        failed,
                    )
                    next_progress_log += progress_step

            if resolved_limit is not None and scanned >= resolved_limit:
                break

        ok = failed == 0
        summary = (
            f"Backfilled strict location for {updated} photo(s)."
            if ok
            else f"Backfilled strict location for {updated} photo(s) with {failed} failure(s)."
        )
        return {
            "ok": ok,
            "summary": summary,
            "scanned": scanned,
            "updated": updated,
            "skipped_no_gps": skipped_no_gps,
            "failed": failed,
            "failures": failures[:20],
        }

    def apply_runtime_upgrades(
        self,
        *,
        batch_size: int = 250,
        normalizer: Any | None = None,
    ) -> dict[str, Any]:
        location_normalizer = normalizer or self._default_location_normalizer()
        with connect_database(self.paths) as connection:
            row = self._get_runtime_upgrade_state(connection)
            if row is None:
                logger.info("Gateway runtime upgrade state missing; bootstrapping from current runtime identity")
                runtime_readiness = inspect_gateway_runtime(strict=env_truthy("EONA_GATEWAY_RUNTIME_STRICT"))
                if runtime_readiness.get("lifecycle_state") in {"blocked", "failed"}:
                    logger.warning(
                        "Gateway runtime upgrade bootstrap blocked by runtime readiness: %s",
                        runtime_readiness.get("summary"),
                    )
                    return {
                        "ok": False,
                        "summary": "Gateway runtime upgrades are blocked.",
                        "details": list(runtime_readiness.get("problems") or []),
                        "actions": [],
                    }
                runtime_upgrade = self._evaluate_runtime_upgrade_state(
                    connection,
                    current_identity=dict(runtime_readiness.get("runtime_identity") or {}),
                )
                row = self._get_runtime_upgrade_state(connection)
                if row is None:
                    return {
                        "ok": False,
                        "summary": "Gateway runtime upgrade state initialization failed.",
                        "details": [],
                        "actions": [],
                    }
                if runtime_upgrade.get("first_boot"):
                    logger.info("Gateway runtime baseline recorded for fresh data volume")
                    return {
                        "ok": True,
                        "summary": "Gateway runtime baseline recorded.",
                        "details": [],
                        "actions": [],
                    }
            lifecycle_state = str(row["lifecycle_state"])
            current_identity = json.loads(str(row["current_runtime_identity_json"]))
            previous_identity = json.loads(str(row["previous_runtime_identity_json"])) if row["previous_runtime_identity_json"] else None
            module_results = json.loads(str(row["module_results_json"]))

        if lifecycle_state == "ready":
            logger.debug("Gateway runtime upgrades already applied for current runtime identity")
            return {
                "ok": True,
                "summary": "",
                "details": [],
                "actions": [],
            }

        if lifecycle_state == "pending_acceptance":
            logger.info("Gateway runtime upgrades already applied and are pending operator acceptance")
            return {
                "ok": True,
                "summary": "Gateway runtime upgrades are pending acceptance.",
                "details": ["Runtime upgrade results are pending operator acceptance."],
                "actions": [],
            }

        if lifecycle_state in {"blocked", "failed"}:
            logger.warning("Gateway runtime upgrades cannot proceed because lifecycle_state=%s", lifecycle_state)
            return {
                "ok": False,
                "summary": "Gateway runtime upgrades are blocked.",
                "details": [str(row["summary"])],
                "actions": [],
            }

        applied_actions: list[dict[str, Any]] = []
        applied_details: list[str] = []
        for module_result in module_results if isinstance(module_results, list) else []:
            module_name = str(module_result.get("module") or "")
            module_status = str(module_result.get("status") or "ready")
            if module_status == "ready":
                continue
            logger.info(
                "Gateway applying runtime upgrade module %s with status=%s",
                module_name,
                module_status,
            )
            if module_name == "runtime_tracking":
                rerun_result = self.backfill_photo_locations(
                    batch_size=batch_size,
                    normalizer=location_normalizer,
                    should_rerun=lambda row_payload: True,
                    progress_label="legacy runtime-tracking replay",
                )
                applied_actions.append(
                    {
                        "module": "runtime_tracking",
                        "status": "ready" if rerun_result["ok"] else "failed",
                        "changed": bool(rerun_result["updated"]),
                        "details": {
                            "message": rerun_result["summary"],
                            "reason_code": "legacy_runtime_tracking_missing",
                            "updated": rerun_result["updated"],
                            "scanned": rerun_result["scanned"],
                            "failed": rerun_result["failed"],
                        },
                    }
                )
                applied_details.append(rerun_result["summary"])
                logger.info(
                    "Gateway runtime upgrade module %s completed: scanned=%s updated=%s failed=%s",
                    module_name,
                    rerun_result["scanned"],
                    rerun_result["updated"],
                    rerun_result["failed"],
                )
                if not rerun_result["ok"]:
                    with connect_database(self.paths) as connection:
                        self._persist_runtime_upgrade_state(
                            connection,
                            current_identity=current_identity,
                            previous_identity=previous_identity,
                            module_results=applied_actions,
                            lifecycle_state="failed",
                            summary="Gateway runtime upgrade application failed.",
                            details=applied_details,
                        )
                    return {
                        "ok": False,
                        "summary": "Gateway runtime upgrade application failed.",
                        "details": applied_details,
                        "actions": applied_actions,
                    }
                continue
            if module_name == "exiftool":
                applied_actions.append(
                    {
                        "module": "exiftool",
                        "status": "ready",
                        "changed": False,
                        "details": {
                            "message": "ExifTool upgrade requires no replay; new imports will use the upgraded runtime.",
                        },
                    }
                )
                applied_details.append("ExifTool upgrade accepted; no replay required.")
                logger.info("Gateway runtime upgrade module exiftool completed with no replay required")
                continue
            if module_name == "cadis":
                rerun_result = self.backfill_photo_locations(
                    batch_size=batch_size,
                    normalizer=location_normalizer,
                    should_rerun=lambda row_payload, module_result=module_result, current_identity=current_identity: should_rerun_cadis_row(
                        row=row_payload,
                        tool_result=module_result,
                        current_identity=current_identity,
                    ),
                    progress_label="cadis upgrade replay",
                )
                applied_actions.append(
                    {
                        "module": "cadis",
                        "status": "ready" if rerun_result["ok"] else "failed",
                        "changed": bool(rerun_result["updated"]),
                        "details": {
                            "message": rerun_result["summary"],
                            "updated": rerun_result["updated"],
                            "scanned": rerun_result["scanned"],
                            "failed": rerun_result["failed"],
                        },
                    }
                )
                applied_details.append(rerun_result["summary"])
                logger.info(
                    "Gateway runtime upgrade module %s completed: scanned=%s updated=%s failed=%s",
                    module_name,
                    rerun_result["scanned"],
                    rerun_result["updated"],
                    rerun_result["failed"],
                )
                if not rerun_result["ok"]:
                    with connect_database(self.paths) as connection:
                        self._persist_runtime_upgrade_state(
                            connection,
                            current_identity=current_identity,
                            previous_identity=previous_identity,
                            module_results=applied_actions,
                            lifecycle_state="failed",
                            summary="Gateway runtime upgrade application failed.",
                            details=applied_details,
                        )
                    return {
                        "ok": False,
                        "summary": "Gateway runtime upgrade application failed.",
                        "details": applied_details,
                        "actions": applied_actions,
                    }
                continue
            applied_actions.append(module_result)

        with connect_database(self.paths) as connection:
            self._persist_runtime_upgrade_state(
                connection,
                current_identity=current_identity,
                previous_identity=previous_identity,
                module_results=applied_actions,
                lifecycle_state="pending_acceptance",
                summary="Gateway runtime upgrades applied and pending acceptance.",
                details=applied_details + ["Runtime upgrade results are pending operator acceptance."],
            )
        logger.info("Gateway runtime upgrades applied; awaiting explicit acceptance")
        return {
            "ok": True,
            "summary": "Gateway runtime upgrades applied and pending acceptance.",
            "details": applied_details + ["Runtime upgrade results are pending operator acceptance."],
            "actions": applied_actions,
        }

    def accept_runtime_upgrades(self) -> dict[str, Any]:
        with connect_database(self.paths) as connection:
            row = self._get_runtime_upgrade_state(connection)
            if row is None:
                return {
                    "ok": True,
                    "summary": "No persisted Gateway runtime upgrade state exists.",
                    "details": [],
                }
            lifecycle_state = str(row["lifecycle_state"])
            if lifecycle_state == "ready":
                return {
                    "ok": True,
                    "summary": "Gateway runtime upgrade baseline is already accepted.",
                    "details": [],
                }
            if lifecycle_state != "pending_acceptance":
                return {
                    "ok": False,
                    "summary": "Gateway runtime upgrade is not ready to accept.",
                    "details": [f"Current lifecycle_state is {lifecycle_state}."],
                }
            current_identity = json.loads(str(row["current_runtime_identity_json"]))
            previous_identity = json.loads(str(row["previous_runtime_identity_json"])) if row["previous_runtime_identity_json"] else None
            module_results = json.loads(str(row["module_results_json"]))
            details = json.loads(str(row["details_json"]))
            self._persist_runtime_upgrade_state(
                connection,
                current_identity=current_identity,
                previous_identity=previous_identity,
                module_results=module_results if isinstance(module_results, list) else [],
                lifecycle_state="ready",
                summary="Gateway runtime upgrade accepted.",
                details=[detail for detail in details if isinstance(detail, str)],
            )
        return {
            "ok": True,
            "summary": "Gateway runtime upgrade accepted.",
            "details": [],
        }

    def backfill_duplicate_semantics(
        self,
        *,
        limit: int | None = None,
        replay_mode: str = "incremental",
    ) -> dict[str, Any]:
        resolved_limit = None if limit is None else max(0, int(limit))
        normalized_replay_mode = str(replay_mode).strip().lower() or "incremental"
        if normalized_replay_mode not in SUPPORTED_SEMANTIC_BACKFILL_REPLAY_MODES:
            raise GatewayServiceError(
                "UNSUPPORTED_REPLAY_MODE",
                f"Unsupported replay mode `{normalized_replay_mode}`.",
                400,
            )
        started_at = utc_now()
        mode_summary = (
            "Computing duplicate semantic enrichment (incremental)."
            if normalized_replay_mode == "incremental"
            else "Computing duplicate semantic enrichment (full replay)."
        )
        with connect_database(self.paths) as connection:
            with immediate_transaction(connection):
                self._upsert_semantic_enrichment_job(
                    connection,
                    job_name="duplicate_semantic",
                    semantic_version=DUPLICATE_SEMANTIC_VERSION,
                    status=SEMANTIC_ENRICHMENT_STATUS_RUNNING,
                    summary=mode_summary,
                    total_rows=0,
                    started_at=started_at,
                )
        rows = self._load_duplicate_candidate_rows(limit=resolved_limit)
        total_rows = len(rows)
        self._report_semantic_enrichment_progress(
            job_name="duplicate_semantic",
            semantic_version=DUPLICATE_SEMANTIC_VERSION,
            summary=f"{mode_summary[:-1]} (export variants).",
            total_rows=total_rows,
            processed_rows=0,
            started_at=started_at,
        )
        try:
            assignments = self._compute_duplicate_assignments(
                rows,
                progress_callback=lambda summary, processed_rows: self._report_semantic_enrichment_progress(
                    job_name="duplicate_semantic",
                    semantic_version=DUPLICATE_SEMANTIC_VERSION,
                    summary=summary,
                    total_rows=total_rows,
                    processed_rows=min(processed_rows, total_rows),
                    started_at=started_at,
                ),
            )
            now = utc_now()

            with connect_database(self.paths) as connection:
                with immediate_transaction(connection):
                    connection.execute("DELETE FROM photo_duplicate_semantic WHERE duplicate_semantic_version = ?", (DUPLICATE_SEMANTIC_VERSION,))
                    for assignment in assignments:
                        connection.execute(
                            """
                            INSERT INTO photo_duplicate_semantic(
                                photo_id,
                                duplicate_semantic_version,
                                duplicate_cluster_id,
                                duplicate_role,
                                duplicate_reason,
                                computed_at
                            ) VALUES (?, ?, ?, ?, ?, ?)
                            """,
                            (
                                assignment["photo_id"],
                                DUPLICATE_SEMANTIC_VERSION,
                                assignment["duplicate_cluster_id"],
                                assignment["duplicate_role"],
                                assignment["duplicate_reason"],
                                now,
                            ),
                        )

                    duplicate_rows = sum(1 for item in assignments if item["duplicate_role"] == "duplicate")
                    primary_rows = sum(1 for item in assignments if item["duplicate_role"] == "primary")
                    singleton_rows = sum(1 for item in assignments if item["duplicate_role"] == "singleton")
                    cluster_count = len({item["duplicate_cluster_id"] for item in assignments})
                    summary = f"Computed duplicate semantics for {len(assignments)} photo(s) using {normalized_replay_mode} mode."
                    self._upsert_semantic_enrichment_job(
                        connection,
                        job_name="duplicate_semantic",
                        semantic_version=DUPLICATE_SEMANTIC_VERSION,
                        status=SEMANTIC_ENRICHMENT_STATUS_COMPLETED,
                        summary=summary,
                        total_rows=total_rows,
                        processed_rows=len(rows),
                        updated_rows=len(assignments),
                        failed_rows=0,
                        started_at=started_at,
                        completed_at=now,
                    )
            return {
                "ok": True,
                "summary": summary,
                "replay_mode": normalized_replay_mode,
                "scanned": len(rows),
                "assigned": len(assignments),
                "cluster_count": cluster_count,
                "primary_rows": primary_rows,
                "duplicate_rows": duplicate_rows,
                "singleton_rows": singleton_rows,
                "semantic_version": DUPLICATE_SEMANTIC_VERSION,
            }
        except Exception as exc:
            with connect_database(self.paths) as connection:
                with immediate_transaction(connection):
                    self._upsert_semantic_enrichment_job(
                        connection,
                        job_name="duplicate_semantic",
                        semantic_version=DUPLICATE_SEMANTIC_VERSION,
                        status=SEMANTIC_ENRICHMENT_STATUS_FAILED,
                        summary=f"Duplicate semantic enrichment failed during {normalized_replay_mode} mode.",
                        total_rows=len(rows) if 'rows' in locals() else 0,
                        processed_rows=len(rows) if 'rows' in locals() else 0,
                        updated_rows=0,
                        failed_rows=1,
                        last_error=str(exc),
                        started_at=started_at,
                        completed_at=utc_now(),
                    )
            raise

    def backfill_tags(
        self,
        *,
        tag: str,
        limit: int | None = None,
        replay_mode: str = "incremental",
        detector: Any | None = None,
    ) -> dict[str, Any]:
        normalized_tag = str(tag).strip()
        if not normalized_tag:
            raise GatewayServiceError("INVALID_TAG", "tag is required.", 400)
        normalized_replay_mode = str(replay_mode).strip().lower() or "incremental"
        if normalized_replay_mode not in SUPPORTED_SEMANTIC_BACKFILL_REPLAY_MODES:
            raise GatewayServiceError(
                "UNSUPPORTED_REPLAY_MODE",
                f"Unsupported replay mode `{normalized_replay_mode}`.",
                400,
            )
        if normalized_tag not in SUPPORTED_TAG_BACKFILLS:
            raise GatewayServiceError(
                "UNSUPPORTED_TAG",
                f"Unsupported tag `{normalized_tag}`.",
                400,
            )
        if normalized_tag == "has_people":
            return self._backfill_has_people_tag(limit=limit, replay_mode=normalized_replay_mode, detector=detector)
        raise GatewayServiceError("UNSUPPORTED_TAG", f"Unsupported tag `{normalized_tag}`.", 400)

    def _backfill_has_people_tag(
        self,
        *,
        limit: int | None = None,
        replay_mode: str = "incremental",
        detector: Any | None = None,
    ) -> dict[str, Any]:
        resolved_limit = None if limit is None else max(0, int(limit))
        started_at = utc_now()
        mode_summary = (
            "Computing people semantic enrichment (incremental)."
            if replay_mode == "incremental"
            else "Computing people semantic enrichment (full replay)."
        )
        with connect_database(self.paths) as connection:
            with immediate_transaction(connection):
                self._upsert_semantic_enrichment_job(
                    connection,
                    job_name="has_people",
                    semantic_version=TAG_SEMANTIC_VERSION,
                    status=SEMANTIC_ENRICHMENT_STATUS_RUNNING,
                    summary=mode_summary,
                    total_rows=0,
                    started_at=started_at,
                )
        rows = self._load_tag_candidate_rows(limit=resolved_limit, replay_mode=replay_mode)
        total_rows = len(rows)
        self._report_semantic_enrichment_progress(
            job_name="has_people",
            semantic_version=TAG_SEMANTIC_VERSION,
            summary=mode_summary,
            total_rows=total_rows,
            processed_rows=0,
            started_at=started_at,
        )
        face_detector = detector or self._default_face_detector()
        now = utc_now()
        scanned = 0
        updated = 0
        failed = 0
        failures: list[dict[str, Any]] = []
        assignments: list[tuple[str, str, str, str, int, str]] = []
        progress_step = 250

        for row in rows:
            photo_id = str(row["photo_id"])
            content_path = (self.paths.root / str(row["storage_relpath"])).resolve()
            scanned += 1
            if not content_path.is_file():
                failed += 1
                failures.append({"photo_id": photo_id, "error": "Content bytes are missing from storage."})
                continue
            try:
                face_count = int(face_detector.detect_face_count(content_path))
            except Exception as exc:
                failed += 1
                failures.append({"photo_id": photo_id, "error": str(exc)})
                continue
            has_people = face_count > 0
            assignments.append(
                (
                    photo_id,
                    "has_people",
                    "true" if has_people else "false",
                    HAS_PEOPLE_TAG_SOURCE,
                    TAG_SEMANTIC_VERSION,
                    now,
                )
            )
            assignments.append(
                (
                    photo_id,
                    "face_count",
                    str(max(face_count, 0)),
                    HAS_PEOPLE_TAG_SOURCE,
                    TAG_SEMANTIC_VERSION,
                    now,
                )
            )
            updated += 1
            if scanned % progress_step == 0 or scanned == total_rows:
                self._report_semantic_enrichment_progress(
                    job_name="has_people",
                    semantic_version=TAG_SEMANTIC_VERSION,
                    summary=f"{mode_summary[:-1]} ({scanned}/{total_rows}).",
                    total_rows=total_rows,
                    processed_rows=scanned,
                    updated_rows=updated,
                    failed_rows=failed,
                    started_at=started_at,
                )

        with connect_database(self.paths) as connection:
            with immediate_transaction(connection):
                if replay_mode == "full_replay":
                    connection.execute(
                        "DELETE FROM photo_tag_semantic WHERE tag_key IN (?, ?)",
                        ("has_people", "face_count"),
                    )
                for assignment in assignments:
                    connection.execute(
                        """
                        INSERT INTO photo_tag_semantic(
                            photo_id,
                            tag_key,
                            tag_value,
                            tag_source,
                            tag_strength,
                            semantic_version,
                            computed_at
                        ) VALUES (?, ?, ?, ?, NULL, ?, ?)
                        ON CONFLICT(photo_id, tag_key) DO UPDATE SET
                            tag_value = excluded.tag_value,
                            tag_source = excluded.tag_source,
                            tag_strength = excluded.tag_strength,
                            semantic_version = excluded.semantic_version,
                            computed_at = excluded.computed_at
                        """,
                        assignment,
                    )
                self._upsert_semantic_enrichment_job(
                    connection,
                    job_name="has_people",
                    semantic_version=TAG_SEMANTIC_VERSION,
                    status=SEMANTIC_ENRICHMENT_STATUS_COMPLETED if failed == 0 else SEMANTIC_ENRICHMENT_STATUS_FAILED,
                    summary=(
                        f"Backfilled `has_people` semantic tags for {updated} photo(s) using {replay_mode} mode."
                        if failed == 0
                        else f"Backfilled `has_people` semantic tags for {updated} photo(s) using {replay_mode} mode with {failed} failure(s)."
                    ),
                    total_rows=total_rows,
                    processed_rows=scanned,
                    updated_rows=updated,
                    failed_rows=failed,
                    last_error=failures[0]["error"] if failures else None,
                    started_at=started_at,
                    completed_at=now,
                )

        ok = failed == 0
        summary = (
            f"Backfilled `has_people` semantic tags for {updated} photo(s) using {replay_mode} mode."
            if ok
            else f"Backfilled `has_people` semantic tags for {updated} photo(s) using {replay_mode} mode with {failed} failure(s)."
        )
        return {
            "ok": ok,
            "summary": summary,
            "tag": "has_people",
            "replay_mode": replay_mode,
            "scanned": scanned,
            "updated": updated,
            "failed": failed,
            "semantic_version": TAG_SEMANTIC_VERSION,
            "details": [],
            "failures": failures[:20],
        }

    def _load_tag_candidate_rows(self, *, limit: int | None, replay_mode: str = "incremental") -> list[dict[str, Any]]:
        sql = """
            SELECT
                photo.photo_id,
                content.storage_relpath
            FROM photo
            JOIN content ON content.content_id = photo.content_id
        """
        params: list[Any] = []
        if replay_mode == "incremental":
            sql += """
            LEFT JOIN photo_tag_semantic AS has_people_tag
                ON has_people_tag.photo_id = photo.photo_id
               AND has_people_tag.tag_key = 'has_people'
               AND has_people_tag.semantic_version = ?
            LEFT JOIN photo_tag_semantic AS face_count_tag
                ON face_count_tag.photo_id = photo.photo_id
               AND face_count_tag.tag_key = 'face_count'
               AND face_count_tag.semantic_version = ?
            WHERE has_people_tag.photo_id IS NULL
               OR face_count_tag.photo_id IS NULL
            """
            params.extend([TAG_SEMANTIC_VERSION, TAG_SEMANTIC_VERSION])
        sql += """
            ORDER BY photo.photo_id ASC
        """
        if limit is not None:
            sql += " LIMIT ?"
            params.append(limit)
        with connect_database(self.paths) as connection:
            fetched = connection.execute(sql, tuple(params)).fetchall()
        return [dict(row) for row in fetched]

    def _default_face_detector(self) -> Any:
        return _OpenCvFaceDetector()

    def _load_duplicate_candidate_rows(self, *, limit: int | None) -> list[dict[str, Any]]:
        sql = """
            SELECT
                photo.photo_id,
                photo.taken_at_utc,
                photo.taken_at_original,
                photo.raw_latitude,
                photo.raw_longitude,
                photo.camera_make,
                photo.camera_model,
                (
                    SELECT path_text
                    FROM photo_path_observation
                    WHERE photo_id = photo.photo_id
                    ORDER BY created_at ASC, path_text ASC
                    LIMIT 1
                ) AS primary_path_text
            FROM photo
            ORDER BY photo.photo_id ASC
        """
        params: tuple[Any, ...] = ()
        if limit is not None:
            sql += " LIMIT ?"
            params = (limit,)
        with connect_database(self.paths) as connection:
            fetched = connection.execute(sql, params).fetchall()
        return [dict(row) for row in fetched]

    def _compute_duplicate_assignments(
        self,
        rows: list[dict[str, Any]],
        *,
        progress_callback: Callable[[str, int], None] | None = None,
    ) -> list[dict[str, Any]]:
        assignments: list[dict[str, Any]] = []
        assigned_photo_ids: set[str] = set()
        total_rows = len(rows)

        export_assignments = self._compute_export_variant_assignments(rows)
        assignments.extend(export_assignments)
        assigned_photo_ids.update(str(item["photo_id"]) for item in export_assignments)
        if progress_callback is not None:
            progress_callback(
                "Computing duplicate semantic enrichment (burst clusters).",
                total_rows // 3,
            )

        burst_assignments = self._compute_burst_time_gps_assignments(rows, assigned_photo_ids=assigned_photo_ids)
        assignments.extend(burst_assignments)
        assigned_photo_ids.update(str(item["photo_id"]) for item in burst_assignments)
        if progress_callback is not None:
            progress_callback(
                "Computing duplicate semantic enrichment (finalizing clusters).",
                (2 * total_rows) // 3,
            )

        for row in rows:
            photo_id = str(row["photo_id"])
            if photo_id in assigned_photo_ids:
                continue
            assignments.append(
                {
                    "photo_id": photo_id,
                    "duplicate_cluster_id": photo_id,
                    "duplicate_role": "singleton",
                    "duplicate_reason": "none",
                }
            )
        if progress_callback is not None:
            progress_callback(
                "Computing duplicate semantic enrichment (writing results).",
                total_rows,
            )
        return assignments

    def _compute_export_variant_assignments(self, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        groups: dict[tuple[str, str, str, str, str], list[dict[str, Any]]] = {}
        for row in rows:
            path_text = row.get("primary_path_text")
            if not isinstance(path_text, str) or not path_text:
                continue
            normalized_stem = self._normalized_duplicate_stem(path_text)
            parent_dir = self._duplicate_parent_dir(path_text)
            temporal_key = self._duplicate_temporal_key(row)
            camera_make = str(row.get("camera_make") or "")
            camera_model = str(row.get("camera_model") or "")
            key = (parent_dir, normalized_stem, temporal_key, camera_make, camera_model)
            groups.setdefault(key, []).append(row)

        assignments: list[dict[str, Any]] = []
        for items in groups.values():
            if len(items) < 2:
                continue
            ordered = sorted(items, key=self._duplicate_primary_sort_key)
            cluster_id = generate_id("dup")
            primary = ordered[0]
            assignments.append(
                {
                    "photo_id": str(primary["photo_id"]),
                    "duplicate_cluster_id": cluster_id,
                    "duplicate_role": "primary",
                    "duplicate_reason": "export_variant",
                }
            )
            for item in ordered[1:]:
                assignments.append(
                    {
                        "photo_id": str(item["photo_id"]),
                        "duplicate_cluster_id": cluster_id,
                        "duplicate_role": "duplicate",
                        "duplicate_reason": "export_variant",
                    }
                )
        return assignments

    def _compute_burst_time_gps_assignments(
        self,
        rows: list[dict[str, Any]],
        *,
        assigned_photo_ids: set[str],
    ) -> list[dict[str, Any]]:
        candidate_groups: dict[tuple[str, str, str], list[tuple[float, dict[str, Any]]]] = {}
        for row in rows:
            photo_id = str(row["photo_id"])
            if photo_id in assigned_photo_ids:
                continue
            seconds = self._duplicate_timestamp_seconds(row)
            latitude = row.get("raw_latitude")
            longitude = row.get("raw_longitude")
            if seconds is None or not isinstance(latitude, (int, float)) or not isinstance(longitude, (int, float)):
                continue
            camera_make = str(row.get("camera_make") or "")
            camera_model = str(row.get("camera_model") or "")
            day_key = self._duplicate_day_key(seconds)
            key = (camera_make, camera_model, day_key)
            candidate_groups.setdefault(key, []).append((seconds, row))

        assignments: list[dict[str, Any]] = []
        assigned_in_branch: set[str] = set()
        for items in candidate_groups.values():
            ordered = sorted(items, key=lambda item: (item[0], str(item[1]["photo_id"])))
            current_cluster: list[dict[str, Any]] = []
            previous_seconds: float | None = None
            previous_row: dict[str, Any] | None = None
            for seconds, row in ordered:
                if (
                    previous_seconds is None
                    or previous_row is None
                    or not self._rows_form_burst_pair(
                        previous_row=previous_row,
                        current_row=row,
                        previous_seconds=previous_seconds,
                        current_seconds=seconds,
                    )
                ):
                    assignments.extend(self._build_burst_cluster_assignments(current_cluster))
                    for item in current_cluster:
                        assigned_in_branch.add(str(item["photo_id"]))
                    current_cluster = [row]
                else:
                    current_cluster.append(row)
                previous_seconds = seconds
                previous_row = row
            assignments.extend(self._build_burst_cluster_assignments(current_cluster))
            for item in current_cluster:
                assigned_in_branch.add(str(item["photo_id"]))
        return assignments

    def _build_burst_cluster_assignments(self, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        if len(rows) < 2:
            return []
        ordered = sorted(rows, key=self._duplicate_primary_sort_key)
        cluster_id = generate_id("dup")
        assignments = [
            {
                "photo_id": str(ordered[0]["photo_id"]),
                "duplicate_cluster_id": cluster_id,
                "duplicate_role": "primary",
                "duplicate_reason": "burst_time_gps",
            }
        ]
        for row in ordered[1:]:
            assignments.append(
                {
                    "photo_id": str(row["photo_id"]),
                    "duplicate_cluster_id": cluster_id,
                    "duplicate_role": "duplicate",
                    "duplicate_reason": "burst_time_gps",
                }
            )
        return assignments

    def _duplicate_temporal_key(self, row: dict[str, Any]) -> str:
        taken_at_utc = row.get("taken_at_utc")
        if isinstance(taken_at_utc, str) and taken_at_utc:
            return taken_at_utc
        taken_at_original = row.get("taken_at_original")
        if isinstance(taken_at_original, str) and taken_at_original:
            return taken_at_original
        return "unknown"

    def _duplicate_parent_dir(self, path_text: str) -> str:
        path = Path(path_text)
        parts = path.parts
        if len(parts) >= 7 and parts[0] == "iPhoto9" and parts[1] in {"Masters", "Previews"}:
            # iPhoto stores the same capture under parallel Masters/Previews trees.
            # Collapse them to the same logical parent so export-variant grouping can see both.
            if parts[1] == "Masters":
                logical_parts = (parts[0], "Library", *parts[2:-1])
            else:
                logical_parts = (parts[0], "Library", *parts[2:-2])
            return "/".join(logical_parts)
        return str(path.parent)

    def _normalized_duplicate_stem(self, path_text: str) -> str:
        stem = Path(path_text).stem
        stem = re.sub(r" \(\d+\)$", "", stem)
        return stem.lower()

    def _duplicate_timestamp_seconds(self, row: dict[str, Any]) -> float | None:
        taken_at_utc = row.get("taken_at_utc")
        if isinstance(taken_at_utc, str) and taken_at_utc:
            try:
                return datetime.fromisoformat(taken_at_utc.replace("Z", "+00:00")).timestamp()
            except ValueError:
                pass
        taken_at_original = row.get("taken_at_original")
        if isinstance(taken_at_original, str) and taken_at_original:
            for fmt in ("%Y:%m:%d %H:%M:%S.%f", "%Y:%m:%d %H:%M:%S"):
                try:
                    return datetime.strptime(taken_at_original, fmt).timestamp()
                except ValueError:
                    continue
            return None
        return None

    def _duplicate_day_key(self, seconds: float) -> str:
        day_start = math.floor(seconds / 86400.0)
        return str(day_start)

    def _rows_form_burst_pair(
        self,
        *,
        previous_row: dict[str, Any],
        current_row: dict[str, Any],
        previous_seconds: float,
        current_seconds: float,
    ) -> bool:
        if current_seconds - previous_seconds > BURST_DUPLICATE_TIME_WINDOW_SECONDS:
            return False
        previous_lat = previous_row.get("raw_latitude")
        previous_lon = previous_row.get("raw_longitude")
        current_lat = current_row.get("raw_latitude")
        current_lon = current_row.get("raw_longitude")
        if not all(isinstance(value, (int, float)) for value in (previous_lat, previous_lon, current_lat, current_lon)):
            return False
        distance = self._haversine_meters(
            float(previous_lat),
            float(previous_lon),
            float(current_lat),
            float(current_lon),
        )
        return distance <= BURST_DUPLICATE_DISTANCE_METERS

    def _haversine_meters(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        earth_radius_m = 6371000.0
        phi1 = math.radians(lat1)
        phi2 = math.radians(lat2)
        delta_phi = math.radians(lat2 - lat1)
        delta_lambda = math.radians(lon2 - lon1)
        a = (
            math.sin(delta_phi / 2.0) ** 2
            + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2.0) ** 2
        )
        c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
        return earth_radius_m * c

    def _duplicate_primary_sort_key(self, row: dict[str, Any]) -> tuple[int, int, int, str]:
        path_text = str(row.get("primary_path_text") or "")
        suffix = Path(path_text).suffix.lower()
        source_rank = 0 if "/Masters/" in path_text else 1 if "/Previews/" in path_text else 2
        extension_rank = {
            ".heic": 0,
            ".heif": 1,
            ".jpg": 2,
            ".jpeg": 3,
        }.get(suffix, 9)
        duplicate_suffix_penalty = 1 if re.search(r" \(\d+\)\.[^.]+$", path_text, re.IGNORECASE) else 0
        metadata_rank = 0 if (row.get("taken_at_utc") or row.get("taken_at_original")) else 1
        return (duplicate_suffix_penalty, source_rank, extension_rank, metadata_rank, str(row["photo_id"]))

    def _prepare_merge_recovery_state(
        self,
        run_id: str,
        *,
        retry_import_file_ids: list[str],
        previously_completed_items: int,
    ) -> None:
        now = utc_now()
        with connect_database(self.paths) as connection:
            connection.execute(
                """
                UPDATE import_run_item
                SET status = 'pending',
                    error_code = NULL,
                    error_message = NULL
                WHERE run_id = ? AND status != 'complete'
                """,
                (run_id,),
            )
            connection.execute(
                """
                UPDATE import_run
                SET status = 'running',
                    current_stage = 'CANONICALIZATION',
                    progress = 0.96,
                    completed_at = NULL,
                    error_code = NULL,
                    error_message = NULL,
                    report_json = NULL,
                    started_at = COALESCE(started_at, ?)
                WHERE run_id = ?
                """,
                (now, run_id),
            )
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        run_state = read_json(run_paths.run_json) if run_paths.run_json.is_file() else {"run_id": run_id}
        run_state["status"] = "running"
        run_state["current_stage"] = "CANONICALIZATION"
        run_state["updated_at"] = now
        run_state["completed_at"] = None
        run_state["error_code"] = None
        run_state["error_message"] = None
        run_state.pop("report", None)
        run_state.setdefault("stages", {})
        for stage in ("CANONICALIZATION", "MERGE"):
            stage_state = run_state["stages"].setdefault(stage, {})
            stage_state["state"] = "running"
            stage_state["items_total"] = len(retry_import_file_ids)
            stage_state["items_done"] = 0
            stage_state["started_at"] = now
            stage_state["updated_at"] = now
            stage_state.pop("completed_at", None)
        run_state["merge_recovery"] = {
            "retried_items": len(retry_import_file_ids),
            "previously_completed_items": previously_completed_items,
            "recovered_at": now,
        }
        atomic_write_json(run_paths.run_json, run_state)

    def _build_merge_recovery_report(
        self,
        run_id: str,
        *,
        merge_report: dict[str, Any],
        retried_items: int,
        previously_completed_items: int,
    ) -> dict[str, Any]:
        with connect_database(self.paths) as connection:
            collected_files = int(
                connection.execute(
                    "SELECT COUNT(*) FROM import_run_item WHERE run_id = ?",
                    (run_id,),
                ).fetchone()[0]
            )
            processed_items = int(
                connection.execute(
                    "SELECT COUNT(*) FROM import_run_item WHERE run_id = ? AND status = 'complete'",
                    (run_id,),
                ).fetchone()[0]
            )
            failed_item_count = int(
                connection.execute(
                    "SELECT COUNT(*) FROM import_run_item WHERE run_id = ? AND status = 'failed'",
                    (run_id,),
                ).fetchone()[0]
            )
        return {
            "collected_files": collected_files,
            "processed_items": processed_items,
            "failed_item_count": failed_item_count,
            "recovery_mode": "merge_resume",
            "retried_items": retried_items,
            "recovered_item_count": max(processed_items - previously_completed_items, 0),
            "previously_completed_items": previously_completed_items,
            "new_content_count": int(merge_report.get("new_content_count", 0)),
            "new_photo_count": int(merge_report.get("new_photo_count", 0)),
            "new_path_count": int(merge_report.get("new_path_count", 0)),
            "redundant_item_count": int(merge_report.get("redundant_item_count", 0)),
        }

    def _merge_recovery_candidate(self, run_id: str) -> dict[str, Any]:
        run = self.get_import_run_detail(run_id)
        if run["status"] != "failed":
            return {"run_id": run_id, "recoverable": False, "reason": "Only failed runs can be recovered."}
        stages = run.get("stages") or {}
        sqlite_stage = stages.get("SQLITE_WRITE") or {}
        if sqlite_stage.get("state") != "complete":
            return {
                "run_id": run_id,
                "recoverable": False,
                "reason": "Merge recovery requires SQLITE_WRITE to be complete.",
            }
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        if not run_paths.input_manifest.is_file():
            return {"run_id": run_id, "recoverable": False, "reason": "Run input manifest is missing."}
        if not (run_paths.run_dir / "import.db").is_file():
            return {"run_id": run_id, "recoverable": False, "reason": "Run import.db is missing."}
        with connect_database(self.paths) as connection:
            counts = {
                str(status): int(count)
                for status, count in connection.execute(
                    "SELECT status, COUNT(*) FROM import_run_item WHERE run_id = ? GROUP BY status",
                    (run_id,),
                ).fetchall()
            }
        return {
            "run_id": run_id,
            "recoverable": True,
            "current_stage": run.get("current_stage"),
            "error_code": run.get("error_code"),
            "error_message": run.get("error_message"),
            "item_status_counts": counts,
            "retryable_items": counts.get("failed", 0) + counts.get("pending", 0),
        }

    def _filesystem_doctor_status(self) -> dict[str, Any]:
        with connect_database(self.paths) as connection:
            db_run_ids = {
                str(row[0])
                for row in connection.execute("SELECT run_id FROM import_run").fetchall()
            }
            db_import_ids = {
                str(row[0])
                for row in connection.execute("SELECT import_id FROM import_session").fetchall()
            }
        run_dir_ids = {
            path.name
            for path in self.paths.runs_dir.iterdir()
            if path.is_dir()
        } if self.paths.runs_dir.is_dir() else set()
        import_dir_ids = {
            path.name
            for path in self.paths.import_sessions_dir.iterdir()
            if path.is_dir()
        } if self.paths.import_sessions_dir.is_dir() else set()
        orphan_run_dirs = sorted(run_dir_ids - db_run_ids)
        orphan_import_session_dirs = sorted(import_dir_ids - db_import_ids)
        return {
            "orphan_run_dir_count": len(orphan_run_dirs),
            "orphan_run_dirs": orphan_run_dirs[:20],
            "orphan_import_session_dir_count": len(orphan_import_session_dirs),
            "orphan_import_session_dirs": orphan_import_session_dirs[:20],
        }

    def _path_totals(self, paths: list[Path]) -> tuple[int, int]:
        file_count = 0
        byte_count = 0
        for path in paths:
            if path.is_file():
                file_count += 1
                byte_count += path.stat().st_size
                continue
            if path.is_dir():
                for child in path.rglob("*"):
                    if child.is_file():
                        file_count += 1
                        byte_count += child.stat().st_size
        return file_count, byte_count

    def _delete_path(self, path: Path) -> None:
        if path.is_dir():
            shutil.rmtree(path)
        elif path.exists():
            path.unlink()

    def _get_runtime_upgrade_state(self, connection: sqlite3.Connection) -> sqlite3.Row | None:
        return connection.execute(
            """
            SELECT
                state_key,
                current_runtime_identity_json,
                previous_runtime_identity_json,
                module_results_json,
                lifecycle_state,
                summary,
                details_json,
                updated_at
            FROM gateway_runtime_state
            WHERE state_key = 'current'
            """
        ).fetchone()

    def _persist_runtime_upgrade_state(
        self,
        connection: sqlite3.Connection,
        *,
        current_identity: dict[str, Any],
        previous_identity: dict[str, Any] | None,
        module_results: list[dict[str, Any]],
        lifecycle_state: str,
        summary: str,
        details: list[str],
    ) -> None:
        connection.execute(
            """
            INSERT INTO gateway_runtime_state(
                state_key,
                current_runtime_identity_json,
                previous_runtime_identity_json,
                module_results_json,
                lifecycle_state,
                summary,
                details_json,
                updated_at
            ) VALUES ('current', ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(state_key) DO UPDATE SET
                current_runtime_identity_json = excluded.current_runtime_identity_json,
                previous_runtime_identity_json = excluded.previous_runtime_identity_json,
                module_results_json = excluded.module_results_json,
                lifecycle_state = excluded.lifecycle_state,
                summary = excluded.summary,
                details_json = excluded.details_json,
                updated_at = excluded.updated_at
            """,
            (
                json.dumps(current_identity, sort_keys=True),
                json.dumps(previous_identity, sort_keys=True) if previous_identity is not None else None,
                json.dumps(module_results, sort_keys=True),
                lifecycle_state,
                summary,
                json.dumps(details, sort_keys=False),
                utc_now(),
            ),
        )

    def _has_legacy_gateway_data(self, connection: sqlite3.Connection) -> bool:
        for table in ("content", "photo", "import_session", "import_run"):
            row = connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()
            if row is not None and int(row[0]) > 0:
                return True
        return False

    def _aggregate_runtime_upgrade_modules(self, module_results: list[dict[str, Any]]) -> tuple[str, str, list[str]]:
        lifecycle_state = "ready"
        details: list[str] = []
        for result in module_results:
            status = str(result.get("status") or "ready")
            if RUNTIME_UPGRADE_STATUS_PRECEDENCE.get(status, -1) > RUNTIME_UPGRADE_STATUS_PRECEDENCE[lifecycle_state]:
                lifecycle_state = status
            if result.get("changed"):
                message = ((result.get("details") or {}).get("message")) if isinstance(result.get("details"), dict) else None
                if isinstance(message, str) and message:
                    details.append(message)
        if lifecycle_state == "ready":
            summary = "Gateway runtime upgrade check passed."
        elif lifecycle_state == "reimport_suggested":
            summary = "Gateway runtime upgrade suggests reimport."
        elif lifecycle_state == "needs_attention":
            summary = "Gateway runtime upgrade needs attention."
        elif lifecycle_state == "pending_acceptance":
            summary = "Gateway runtime upgrade is pending acceptance."
        elif lifecycle_state == "blocked":
            summary = "Gateway runtime upgrade is blocked."
        else:
            summary = "Gateway runtime upgrade check failed."
        return lifecycle_state, summary, details

    def _evaluate_runtime_upgrade_state(
        self,
        connection: sqlite3.Connection,
        *,
        current_identity: dict[str, Any],
    ) -> dict[str, Any]:
        row = self._get_runtime_upgrade_state(connection)
        if row is None:
            if self._has_legacy_gateway_data(connection):
                module_results = [
                    {
                        "module": "runtime_tracking",
                        "status": "needs_attention",
                        "changed": True,
                        "details": {
                            "message": "Gateway data volume predates runtime upgrade tracking. Gateway will replay upgrade-safe data and then require operator acceptance.",
                            "reason_code": "legacy_runtime_tracking_missing",
                            "reprocess_scope": "all_geo_rows",
                        },
                    }
                ]
                lifecycle_state, summary, details = self._aggregate_runtime_upgrade_modules(module_results)
                self._persist_runtime_upgrade_state(
                    connection,
                    current_identity=current_identity,
                    previous_identity=None,
                    module_results=module_results,
                    lifecycle_state=lifecycle_state,
                    summary=summary,
                    details=details,
                )
                return {
                    "status": lifecycle_state,
                    "summary": summary,
                    "details": details,
                    "changed": True,
                    "first_boot": False,
                    "previous_runtime_identity": None,
                    "current_runtime_identity": current_identity,
                    "module_results": module_results,
                }
            module_results: list[dict[str, Any]] = []
            lifecycle_state = "ready"
            summary = "Gateway runtime baseline recorded."
            details: list[str] = []
            self._persist_runtime_upgrade_state(
                connection,
                current_identity=current_identity,
                previous_identity=None,
                module_results=module_results,
                lifecycle_state=lifecycle_state,
                summary=summary,
                details=details,
            )
            return {
                "status": lifecycle_state,
                "summary": summary,
                "details": details,
                "changed": False,
                "first_boot": True,
                "previous_runtime_identity": None,
                "current_runtime_identity": current_identity,
                "module_results": module_results,
            }

        previous_identity = json.loads(str(row["current_runtime_identity_json"]))
        if previous_identity == current_identity:
            module_results = json.loads(str(row["module_results_json"]))
            details = json.loads(str(row["details_json"]))
            return {
                "status": str(row["lifecycle_state"]),
                "summary": str(row["summary"]),
                "details": details if isinstance(details, list) else [],
                "changed": False,
                "first_boot": False,
                "previous_runtime_identity": json.loads(str(row["previous_runtime_identity_json"])) if row["previous_runtime_identity_json"] else None,
                "current_runtime_identity": current_identity,
                "module_results": module_results if isinstance(module_results, list) else [],
            }

        module_results = run_gateway_upgrade_tools(
            previous_identity=previous_identity,
            current_identity=current_identity,
        )
        lifecycle_state, summary, details = self._aggregate_runtime_upgrade_modules(module_results)
        self._persist_runtime_upgrade_state(
            connection,
            current_identity=current_identity,
            previous_identity=previous_identity,
            module_results=module_results,
            lifecycle_state=lifecycle_state,
            summary=summary,
            details=details,
        )
        return {
            "status": lifecycle_state,
            "summary": summary,
            "details": details,
            "changed": True,
            "first_boot": False,
            "previous_runtime_identity": previous_identity,
            "current_runtime_identity": current_identity,
            "module_results": module_results,
        }

    def _merge_lifecycle_state(self, current_state: str, candidate_state: str) -> str:
        if candidate_state == "checking" or current_state == "checking":
            return "checking"
        current_rank = RUNTIME_UPGRADE_STATUS_PRECEDENCE.get(current_state, -1)
        candidate_rank = RUNTIME_UPGRADE_STATUS_PRECEDENCE.get(candidate_state, -1)
        if candidate_rank > current_rank:
            return candidate_state
        return current_state

    def health(self) -> dict[str, Any]:
        readiness = self.readiness(allow_cached_pending=True)
        return {
            "ok": bool(readiness["ok"]),
            "lifecycle_state": readiness["lifecycle_state"],
            "database": str(self.paths.database),
            "root": str(self.paths.root),
            "runtime": readiness,
        }

    def liveness(self) -> dict[str, Any]:
        return {
            "ok": True,
            "database": str(self.paths.database),
            "root": str(self.paths.root),
        }

    def readiness(self, *, allow_cached_pending: bool = False) -> dict[str, Any]:
        readiness = inspect_gateway_runtime(strict=env_truthy("EONA_GATEWAY_RUNTIME_STRICT"))
        if self._storage_fault is not None:
            readiness["ok"] = False
            readiness["lifecycle_state"] = "blocked"
            readiness["summary"] = "Gateway storage check failed."
            readiness.setdefault("problems", []).append(self._storage_fault["message"])
            readiness["database"] = {
                "status": "error",
                "path": str(self.paths.database),
            }
            readiness["storage_fault"] = dict(self._storage_fault)
            readiness["details"] = list(readiness.get("warnings") or []) + list(readiness.get("problems") or [])
            return readiness
        try:
            with connect_database(self.paths) as connection:
                connection.execute("SELECT 1").fetchone()
                semantic_enrichment = self._semantic_enrichment_status(connection)
                if readiness.get("lifecycle_state") in {"blocked", "failed"}:
                    runtime_upgrade = {
                        "status": "ready",
                        "summary": "Gateway runtime upgrade check skipped.",
                        "details": [],
                        "changed": False,
                        "first_boot": False,
                        "previous_runtime_identity": None,
                        "current_runtime_identity": dict(readiness.get("runtime_identity") or {}),
                        "module_results": [],
                    }
                else:
                    runtime_upgrade = self._evaluate_runtime_upgrade_state(
                        connection,
                        current_identity=dict(readiness.get("runtime_identity") or {}),
                    )
        except Exception as exc:
            readiness["ok"] = False
            readiness["lifecycle_state"] = "blocked"
            readiness.setdefault("problems", []).append(f"database unavailable: {exc}")
            readiness["database"] = {
                "status": "error",
                "path": str(self.paths.database),
            }
            return readiness
        readiness["database"] = {
            "status": "ok",
            "path": str(self.paths.database),
        }
        readiness["semantic_enrichment"] = semantic_enrichment
        readiness["runtime_upgrade"] = runtime_upgrade
        if allow_cached_pending:
            content_store = self._content_store_integrity_status_cached()
        else:
            content_store = self._content_store_integrity_status()
        readiness["content_store"] = content_store
        if content_store["status"] != "ok":
            if content_store["status"] == "checking":
                readiness["ok"] = False
                readiness["lifecycle_state"] = "checking"
                readiness["summary"] = "Gateway content integrity check is in progress."
                readiness.setdefault("warnings", []).append(content_store["summary"])
                readiness["details"] = list(readiness.get("warnings") or []) + list(readiness.get("problems") or [])
            else:
                readiness["ok"] = False
                readiness["lifecycle_state"] = "blocked"
                readiness["summary"] = "Gateway integrity check failed."
                readiness.setdefault("problems", []).extend(content_store.get("problems", []))
                readiness["details"] = list(readiness.get("warnings") or []) + list(readiness.get("problems") or [])
        enrichment_status = str(semantic_enrichment.get("status") or SEMANTIC_ENRICHMENT_STATUS_COMPLETED)
        if enrichment_status == SEMANTIC_ENRICHMENT_STATUS_FAILED:
            readiness.setdefault("warnings", []).append(str(semantic_enrichment.get("summary") or "Semantic enrichment needs attention."))
            if readiness["lifecycle_state"] != "checking":
                readiness["lifecycle_state"] = self._merge_lifecycle_state(str(readiness["lifecycle_state"]), "needs_attention")
        elif enrichment_status == SEMANTIC_ENRICHMENT_STATUS_RUNNING:
            readiness.setdefault("warnings", []).append(str(semantic_enrichment.get("summary") or "Semantic enrichment is running."))
        elif enrichment_status == SEMANTIC_ENRICHMENT_STATUS_PENDING:
            readiness.setdefault("warnings", []).append(str(semantic_enrichment.get("summary") or "Semantic enrichment is pending."))
        if readiness["lifecycle_state"] != "checking":
            upgrade_state = str(runtime_upgrade.get("status") or "ready")
            merged_state = self._merge_lifecycle_state(str(readiness["lifecycle_state"]), upgrade_state)
            readiness["lifecycle_state"] = merged_state
            if merged_state in {"blocked", "failed"}:
                readiness["ok"] = False
            elif merged_state in {"reimport_suggested", "pending_acceptance"}:
                readiness["ok"] = True
            if upgrade_state == merged_state and upgrade_state != "ready":
                readiness["summary"] = str(runtime_upgrade.get("summary") or readiness.get("summary") or "")
            upgrade_details = [
                detail
                for detail in runtime_upgrade.get("details") or []
                if isinstance(detail, str) and detail
            ]
            if upgrade_details:
                readiness.setdefault("details", [])
                readiness["details"] = list(readiness.get("details") or []) + upgrade_details
        readiness["operational_summary"] = self._build_readiness_operational_summary(
            readiness=readiness,
            semantic_enrichment=semantic_enrichment,
            runtime_upgrade=runtime_upgrade,
            content_store=content_store,
        )
        return readiness

    def refresh_content_store_integrity_async(self) -> None:
        with self._content_store_status_lock:
            refresh_thread = self._content_store_refresh_thread
            if refresh_thread is not None and refresh_thread.is_alive():
                return
            self._content_store_refresh_thread = threading.Thread(
                target=self._refresh_content_store_integrity,
                name="gateway-content-integrity",
                daemon=True,
            )
            self._content_store_refresh_thread.start()

    def _refresh_content_store_integrity(self) -> None:
        try:
            status = self._content_store_integrity_status()
        except Exception as exc:
            logger.exception("Gateway content integrity refresh failed: %s", exc)
            status = {
                "status": "error",
                "root": str(self.paths.content_dir),
                "checked_content_rows": 0,
                "missing_count": 0,
                "missing_examples": [],
                "problems": [f"content integrity refresh failed: {exc}"],
            }
        with self._content_store_status_lock:
            self._content_store_status_cache = status
            self._content_store_refresh_thread = None

    def _content_store_integrity_status_cached(self) -> dict[str, Any]:
        with self._content_store_status_lock:
            cached = self._content_store_status_cache
            refresh_thread = self._content_store_refresh_thread
        if cached is not None:
            return cached
        if refresh_thread is None:
            self.refresh_content_store_integrity_async()
        return {
            "status": "checking",
            "root": str(self.paths.content_dir),
            "checked_content_rows": None,
            "missing_count": None,
            "missing_examples": [],
            "problems": [],
            "summary": "Gateway content integrity check is running in the background.",
        }

    def _validate_import_filename(self, client_filename: str) -> None:
        suffix = Path(client_filename).suffix.lower()
        if suffix in GATEWAY_ACCEPTED_IMPORT_EXTENSIONS:
            return
        raise GatewayServiceError(
            "IMPORT_FILE_FORMAT_UNSUPPORTED",
            "Unsupported import format. Gateway currently accepts JPEG/HEIC (.jpg, .jpeg, .heic, .heif).",
            415,
        )

    def _discover_import_source_files(self, source_path: Path) -> tuple[list[Path], list[dict[str, str]]]:
        discovered_files: list[Path] = []
        collection_errors: list[dict[str, str]] = []

        def _walk(candidate: Path) -> None:
            if candidate.name.startswith("."):
                return
            if candidate.is_symlink():
                collection_errors.append(
                    {
                        "path": str(candidate),
                        "error_code": "IMPORT_PATH_SYMLINK_UNSUPPORTED",
                        "message": f"Symlink inputs are not supported: {candidate}",
                    }
                )
                return
            try:
                if candidate.is_dir():
                    for child in sorted(candidate.iterdir(), key=lambda item: item.name.casefold()):
                        _walk(child)
                    return
                if not candidate.is_file():
                    return
                if candidate.suffix.lower() not in GATEWAY_ACCEPTED_IMPORT_EXTENSIONS:
                    return
                with candidate.open("rb") as handle:
                    handle.read(1)
                discovered_files.append(candidate.resolve())
            except OSError as exc:
                collection_errors.append(
                    {
                        "path": str(candidate),
                        "error_code": "IMPORT_FILE_UNREADABLE",
                        "message": f"Import source is unreadable: {candidate} ({exc})",
                    }
                )

        _walk(source_path)
        return discovered_files, collection_errors

    def _storage_status(self) -> dict[str, int]:
        usage = shutil.disk_usage(self.paths.root)
        min_free_bytes = self._minimum_free_bytes()
        return {
            "total_bytes": int(usage.total),
            "used_bytes": int(usage.used),
            "free_bytes": int(usage.free),
            "min_free_bytes": int(min_free_bytes),
            "available_import_bytes": int(max(usage.free - min_free_bytes, 0)),
        }

    def _minimum_free_bytes(self) -> int:
        raw = compat_env("EONA_GATEWAY_MIN_FREE_BYTES", default=str(DEFAULT_MIN_FREE_BYTES))
        try:
            return max(int(raw), 0)
        except ValueError:
            return DEFAULT_MIN_FREE_BYTES

    def _storage_exhausted_message(self, *, required_bytes: int) -> str:
        status = self._storage_status()
        return (
            "Gateway storage is too full for this import. "
            f"Need {required_bytes} more bytes with at least {status['min_free_bytes']} bytes of free-space reserve; "
            f"server currently allows {status['available_import_bytes']} import bytes."
        )

    def _ensure_storage_capacity(self, *, required_bytes: int) -> None:
        status = self._storage_status()
        if status["available_import_bytes"] >= required_bytes:
            return
        raise GatewayServiceError(
            "IMPORT_STORAGE_EXHAUSTED",
            self._storage_exhausted_message(required_bytes=required_bytes),
            507,
        )

    def _mark_import_session_failed(self, *, import_id: str, error_code: str, error_message: str) -> None:
        now = utc_now()
        with connect_database(self.paths) as connection:
            connection.execute(
                """
                UPDATE import_session
                SET status = 'failed', updated_at = ?, error_code = ?, error_message = ?
                WHERE import_id = ? AND status = 'collecting'
                """,
                (now, error_code, error_message, import_id),
            )

    def _content_store_integrity_status(self) -> dict[str, Any]:
        with connect_database(self.paths) as connection:
            rows = connection.execute(
                """
                SELECT content_id, storage_relpath
                FROM content
                ORDER BY content_id ASC
                """
            ).fetchall()
        missing: list[dict[str, str]] = []
        for row in rows:
            storage_relpath = str(row["storage_relpath"])
            content_path = self.paths.root / storage_relpath
            if content_path.is_file():
                continue
            missing.append(
                {
                    "content_id": str(row["content_id"]),
                    "storage_relpath": storage_relpath,
                }
            )
        if not missing:
            status = {
                "status": "ok",
                "root": str(self.paths.content_dir),
                "checked_content_rows": len(rows),
                "missing_count": 0,
                "missing_examples": [],
                "problems": [],
            }
            with self._content_store_status_lock:
                self._content_store_status_cache = status
            return status
        examples = missing[:5]
        sample_paths = ", ".join(example["storage_relpath"] for example in examples)
        status = {
            "status": "error",
            "root": str(self.paths.content_dir),
            "checked_content_rows": len(rows),
            "missing_count": len(missing),
            "missing_examples": examples,
            "problems": [
                (
                    "Canonical content bytes referenced by the database are missing from storage. "
                    "Mount /data as a complete unit; mounting only /data/db is not supported."
                ),
                f"Missing canonical content files: {sample_paths}",
            ],
        }
        with self._content_store_status_lock:
            self._content_store_status_cache = status
        return status

    def get_photo_metadata(self, photo_id: str) -> dict[str, Any]:
        with connect_database(self.paths) as connection:
            row = connection.execute(
                """
                SELECT
                    photo_id,
                    content_id,
                    photo_signature,
                    photo_signature_version,
                    signature_payload_json,
                    taken_at_utc,
                    taken_at_original,
                    raw_latitude,
                    raw_longitude,
                    raw_altitude,
                    cadis_result_json,
                    cadis_version,
                    location_detail,
                    camera_make,
                    camera_model,
                    created_at
                FROM photo
                WHERE photo_id = ?
                """,
                (photo_id,),
            ).fetchone()
            if row is None:
                raise GatewayServiceError("PHOTO_NOT_FOUND", "Photo does not exist.", 404)
            path_rows = connection.execute(
                """
                SELECT path_text
                FROM photo_path_observation
                WHERE photo_id = ?
                ORDER BY created_at ASC, path_text ASC
                """,
                (photo_id,),
            ).fetchall()
        return {
            "photo_id": str(row["photo_id"]),
            "content_id": str(row["content_id"]),
            "photo_signature": str(row["photo_signature"]),
            "photo_signature_version": int(row["photo_signature_version"]),
            "signature_payload_json": json.loads(str(row["signature_payload_json"])),
            "taken_at_utc": row["taken_at_utc"],
            "taken_at_original": row["taken_at_original"],
            "raw_latitude": row["raw_latitude"],
            "raw_longitude": row["raw_longitude"],
            "raw_altitude": row["raw_altitude"],
            "cadis_result_json": (
                json.loads(str(row["cadis_result_json"]))
                if row["cadis_result_json"] is not None
                else None
            ),
            "cadis_version": row["cadis_version"],
            "location_detail": row["location_detail"],
            "camera_make": row["camera_make"],
            "camera_model": row["camera_model"],
            "created_at": row["created_at"],
            "path_observations": [str(path_row["path_text"]) for path_row in path_rows],
        }

    def _default_location_normalizer(self) -> CadisRuntimeNormalizer:
        try:
            return CadisRuntimeNormalizer()
        except Exception as exc:
            raise GatewayServiceError("DEPENDENCY_MISSING", f"Required dependency missing: cadis ({exc})", 500) from exc

    def _normalize_photo_memory_plan(self, plan: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(plan, dict):
            return plan
        effective = dict(plan)
        limit = effective.get("limit")
        if isinstance(limit, bool):
            return effective
        if isinstance(limit, int):
            effective["limit"] = min(limit, MAX_PHOTO_MEMORY_QUERY_LIMIT)
        elif limit is None:
            effective["limit"] = 20
        return effective

    def query_photo_memory(self, plan: dict[str, Any]) -> dict[str, Any]:
        effective_plan = self._normalize_photo_memory_plan(plan)
        try:
            compiled = compile_photo_memory_query(effective_plan)
        except QueryValidationError as exc:
            raise GatewayServiceError(exc.error_code, str(exc), 400) from exc
        except QueryCompilationError as exc:
            raise GatewayServiceError(exc.error_code, str(exc), 400) from exc

        with connect_database(self.paths) as connection:
            try:
                rows = connection.execute(compiled.sql, compiled.params).fetchall()
            except sqlite3.DatabaseError as exc:
                raise GatewayServiceError("QUERY_EXECUTION_FAILED", f"Gateway query execution failed: {exc}", 500) from exc

        payload = {
            "query_version": int(compiled.resolved_plan["query_version"]),
            "resolved_plan": compiled.resolved_plan,
            "columns": compiled.columns,
            "rows": [dict(row) for row in rows],
            "row_count": len(rows),
            "warnings": [],
            "capabilities_used": compiled.capabilities_used,
        }
        response_bytes = len(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
        if response_bytes > MAX_PHOTO_MEMORY_RESPONSE_BYTES:
            raise GatewayServiceError(
                "QUERY_RESULT_TOO_LARGE",
                "Gateway query result is too large to return safely. Please narrow the query or lower `limit`.",
                413,
            )
        return payload

    def get_content_response(self, content_id: str) -> tuple[Path, dict[str, str]]:
        with connect_database(self.paths) as connection:
            row = connection.execute(
                """
                SELECT storage_relpath, mime_type, byte_size
                FROM content
                WHERE content_id = ?
                """,
                (content_id,),
            ).fetchone()
            if row is None:
                raise GatewayServiceError("CONTENT_NOT_FOUND", "Content does not exist.", 404)
        content_path = (self.paths.root / str(row["storage_relpath"])).resolve()
        if not content_path.is_file():
            raise GatewayServiceError("CONTENT_NOT_FOUND", "Content bytes are missing from storage.", 404)
        return content_path, {
            "Content-Type": str(row["mime_type"]),
            "Content-Length": str(int(row["byte_size"])),
        }

    def _count_run_items(self, run_id: str) -> int:
        with connect_database(self.paths) as connection:
            return int(
                connection.execute(
                    "SELECT COUNT(*) FROM import_run_item WHERE run_id = ?",
                    (run_id,),
                ).fetchone()[0]
            )

    def _get_session_record(self, import_id: str):
        with connect_database(self.paths) as connection:
            row = connection.execute(
                "SELECT import_id, status FROM import_session WHERE import_id = ?",
                (import_id,),
            ).fetchone()
        if row is None:
            raise GatewayServiceError("IMPORT_NOT_FOUND", "Import session does not exist.", 404)
        return row

    def _get_run_record(self, connection, run_id: str):
        return connection.execute(
            """
            SELECT run_id, source_import_id, status, current_stage, progress, created_at, started_at, completed_at, error_code, error_message, report_json
            FROM import_run
            WHERE run_id = ?
            """,
            (run_id,),
        ).fetchone()

    def _serialize_run(self, row, *, control_state: str | None = None) -> dict[str, Any]:
        report = row["report_json"]
        effective_status = self._effective_run_status(str(row["status"]), control_state)
        return {
            "run_id": str(row["run_id"]),
            "status": effective_status,
            "current_stage": row["current_stage"],
            "progress": float(row["progress"]),
            "created_at": row["created_at"],
            "started_at": row["started_at"],
            "completed_at": row["completed_at"],
            "error_code": row["error_code"],
            "error_message": row["error_message"],
            "report": json.loads(report) if report else None,
        }

    def get_run_input_manifest(self, run_id: str) -> dict[str, Any]:
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        if not run_paths.input_manifest.is_file():
            raise GatewayServiceError("RUN_INPUT_NOT_SEALED", "Committed run input manifest is missing.", 404)
        return read_json(run_paths.input_manifest)

    def get_import_run_detail(self, run_id: str) -> dict[str, Any]:
        run = self.get_import_run(run_id)
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        if run_paths.run_json.is_file():
            run_state = read_json(run_paths.run_json)
            run["stages"] = run_state.get("stages") or {}
            run["source_import_id"] = run_state.get("source_import_id")
            run["resume_from_stage"] = run_state.get("resume_from_stage")
        else:
            run["stages"] = {}
        return run

    def _get_run_control(self, connection, run_id: str) -> str | None:
        row = connection.execute(
            "SELECT desired_state FROM import_run_control WHERE run_id = ?",
            (run_id,),
        ).fetchone()
        return str(row["desired_state"]) if row is not None else None

    def _effective_run_status(self, base_status: str, control_state: str | None) -> str:
        if control_state == "paused":
            return "paused"
        if control_state == "pause_requested" and base_status == "running":
            return "pausing"
        return base_status

    def _commit_response(self, *, import_id: str, session_status: str, run) -> dict[str, Any]:
        run_id = str(run["run_id"]) if run is not None else None
        run_status = str(run["status"]) if run is not None else None
        return {
            "import_id": import_id,
            "status": "committed" if session_status == "committed" else session_status,
            "run_id": run_id,
            "run_status": run_status,
        }

    def _seal_run_input_file(
        self,
        *,
        run_id: str,
        import_file_id: str,
        client_filename: str,
        source_path_text: str,
        staging_relpath: str,
        ordinal: int,
    ) -> dict[str, str | None]:
        source = Path(source_path_text)
        if not source.is_absolute():
            source = self.paths.root / source
        if not source.is_file():
            raise GatewayServiceError("IMPORT_FILE_MISSING", f"Committed import input is missing: {source_path_text}", 500)
        input_relpath: str | None = None
        if staging_relpath.startswith("imports/"):
            input_relpath = staging_relpath
        return {
            "input_path": str(source.resolve()),
            "input_relpath": input_relpath,
            "input_sha256": sha256_file(source),
        }

    def _write_run_metadata(
        self,
        *,
        run_id: str,
        source_import_id: str,
        created_at: str,
        sealed_at: str,
        items: list[dict[str, Any]],
    ) -> None:
        run_paths = ensure_run_layout(paths=self.paths, run_id=run_id)
        manifest = {
            "manifest_version": INPUT_MANIFEST_VERSION,
            "run_id": run_id,
            "source_import_id": source_import_id,
            "created_at": created_at,
            "sealed_at": sealed_at,
            "item_count": len(items),
            "items": items,
        }
        run_state = read_json(run_paths.run_json) if run_paths.run_json.is_file() else {"run_id": run_id}
        run_state["source_import_id"] = source_import_id
        run_state.setdefault("status", "queued")
        run_state.setdefault("current_stage", None)
        run_state["created_at"] = run_state.get("created_at") or created_at
        run_state["updated_at"] = sealed_at
        run_state["input_manifest"] = str(Path("runs") / run_id / "input_manifest.json")
        atomic_write_json(run_paths.input_manifest, manifest)
        atomic_write_json(run_paths.run_json, run_state)
