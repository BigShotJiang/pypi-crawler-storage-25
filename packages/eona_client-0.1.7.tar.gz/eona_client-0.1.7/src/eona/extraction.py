from __future__ import annotations

import json
import logging
import os
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

from eona.indexing import IndexingObserver, NoopObserver, PauseRequested, StopRequested
from eona.storage import _connect_database


@dataclass(frozen=True)
class ExtractionCandidate:
    content_id: int
    file_path: Path


class MetadataExtractor(Protocol):
    def extract(self, path: Path) -> Any:
        ...


class ExtractRunner:
    def __init__(
        self,
        *,
        extractor: MetadataExtractor,
        batch_size: int = 100,
        logger: logging.Logger | None = None,
    ) -> None:
        self.extractor = extractor
        self.batch_size = batch_size
        self.logger = logger or logging.getLogger(__name__)

    def run(
        self,
        *,
        database_path: Path,
        observer: IndexingObserver | None = None,
        root_paths: tuple[Path, ...] | None = None,
        snapshot_version: int | None = None,
    ) -> dict[str, Any]:
        observer = observer or NoopObserver()
        with _connect_database(database_path) as connection:
            candidates = self._select_candidates(connection=connection, root_paths=root_paths)
            selection_summary = {
                "adapter": "exiftool",
                "convergence_class": "version_based",
                "filters": {"missing": 0, "file_exists_required": True},
                "ordering": "content_id ASC, file_path ASC",
                "batch_size": self.batch_size,
                "total_estimated": len(candidates),
            }
            observer.set_selection_summary(selection_summary)
            observer.set_total(len(candidates))
            observer.set_state("SELECTING")

            processed = 0
            min_content_id: int | None = None
            max_content_id: int | None = None
            for offset in range(0, len(candidates), self.batch_size):
                action = observer.check_control()
                if action == "pause":
                    raise PauseRequested
                if action == "stop":
                    raise StopRequested
                batch = candidates[offset : offset + self.batch_size]
                connection.execute("BEGIN")
                try:
                    for candidate in batch:
                        observer.set_state(
                            "EXTRACTING",
                            current_file=str(candidate.file_path),
                            current_content_id=candidate.content_id,
                        )
                        if self._process_candidate(
                            connection=connection,
                            candidate=candidate,
                            observer=observer,
                            snapshot_version=snapshot_version,
                        ):
                            processed += 1
                            min_content_id = (
                                candidate.content_id if min_content_id is None else min(min_content_id, candidate.content_id)
                            )
                            max_content_id = (
                                candidate.content_id if max_content_id is None else max(max_content_id, candidate.content_id)
                            )
                        observer.advance(current_file=str(candidate.file_path), current_content_id=candidate.content_id)
                    observer.set_state(
                        "WRITING_DB",
                        current_file=str(batch[-1].file_path) if batch else None,
                        current_content_id=batch[-1].content_id if batch else None,
                    )
                    connection.commit()
                except Exception:
                    connection.rollback()
                    raise

        return {
            "processed": processed,
            "total_estimated": len(candidates),
            "selection_summary": {
                **selection_summary,
                "processed_content_id_span": (
                    None
                    if min_content_id is None or max_content_id is None
                    else {"min": min_content_id, "max": max_content_id}
                ),
            },
        }

    def _select_candidates(
        self,
        *,
        connection: sqlite3.Connection,
        root_paths: tuple[Path, ...] | None,
    ) -> tuple[ExtractionCandidate, ...]:
        sql = """
            SELECT content_id, file_path
            FROM files
            WHERE missing = 0
        """
        params: list[str] = []
        if root_paths:
            scope_sql, scope_params = self._path_scope_where_sql("file_path", root_paths)
            sql += f" AND ({scope_sql})"
            params.extend(scope_params)
        sql += " ORDER BY content_id ASC, file_path ASC"
        rows = connection.execute(sql, params).fetchall()
        seen: set[int] = set()
        candidates: list[ExtractionCandidate] = []
        for row in rows:
            content_id = int(row["content_id"])
            if content_id in seen:
                continue
            seen.add(content_id)
            candidates.append(
                ExtractionCandidate(content_id=content_id, file_path=Path(str(row["file_path"])))
            )
        return tuple(candidates)

    def _process_candidate(
        self,
        *,
        connection: sqlite3.Connection,
        candidate: ExtractionCandidate,
        observer: IndexingObserver,
        snapshot_version: int | None,
    ) -> bool:
        if not candidate.file_path.is_file():
            self._warning(observer, candidate, "extract_file_missing", f"missing file at {candidate.file_path}")
            return False
        if not os.access(candidate.file_path, os.R_OK):
            self._warning(observer, candidate, "extract_file_unreadable", f"unreadable file at {candidate.file_path}")
            return False
        try:
            metadata = self.extractor.extract(candidate.file_path)
        except Exception as exc:
            self._warning(observer, candidate, "extract_failed", exc)
            return False

        existing_location = connection.execute(
            """
            SELECT raw_latitude, raw_longitude, raw_altitude, cadis_result_json
            FROM image_location
            WHERE content_id = ?
            """,
            (candidate.content_id,),
        ).fetchone()
        if existing_location is not None and existing_location["cadis_result_json"] is not None:
            previous_raw = (
                existing_location["raw_latitude"],
                existing_location["raw_longitude"],
                existing_location["raw_altitude"],
            )
            new_raw = (
                metadata.image_location.get("raw_latitude"),
                metadata.image_location.get("raw_longitude"),
                metadata.image_location.get("raw_altitude"),
            )
            if previous_raw != new_raw:
                self._warning(
                    observer,
                    candidate,
                    "downstream_cadis_may_be_stale",
                    "raw GPS changed; run 'eona renorm start' to refresh Cadis-derived facts",
                )

        self._upsert_one_to_one(
            connection=connection,
            table="image_facts",
            content_id=candidate.content_id,
            payload={
                **metadata.image_facts,
                "last_processed_snapshot_version": snapshot_version,
            },
        )
        self._upsert_one_to_one(
            connection=connection,
            table="image_camera",
            content_id=candidate.content_id,
            payload=metadata.image_camera,
        )
        location_payload = {
            "raw_latitude": metadata.image_location.get("raw_latitude"),
            "raw_longitude": metadata.image_location.get("raw_longitude"),
            "raw_altitude": metadata.image_location.get("raw_altitude"),
        }
        connection.execute(
            """
            INSERT INTO image_location(content_id, raw_latitude, raw_longitude, raw_altitude)
            VALUES(?, ?, ?, ?)
            ON CONFLICT(content_id) DO UPDATE SET
                raw_latitude = excluded.raw_latitude,
                raw_longitude = excluded.raw_longitude,
                raw_altitude = excluded.raw_altitude
            """,
            (
                candidate.content_id,
                location_payload["raw_latitude"],
                location_payload["raw_longitude"],
                location_payload["raw_altitude"],
            ),
        )
        if snapshot_version is not None:
            connection.execute(
                """
                UPDATE image_location
                SET last_processed_snapshot_version = ?
                WHERE content_id = ?
                """,
                (snapshot_version, candidate.content_id),
            )
        return True

    @staticmethod
    def _upsert_one_to_one(
        *,
        connection: sqlite3.Connection,
        table: str,
        content_id: int,
        payload: dict[str, Any],
    ) -> None:
        columns = ["content_id", *payload.keys()]
        placeholders = ", ".join("?" for _ in columns)
        update_clause = ", ".join(f"{name} = excluded.{name}" for name in payload)
        values = [content_id, *payload.values()]
        connection.execute(
            f"""
            INSERT INTO {table}({", ".join(columns)})
            VALUES({placeholders})
            ON CONFLICT(content_id) DO UPDATE SET
                {update_clause}
            """,
            values,
        )

    def _warning(self, observer: IndexingObserver, candidate: ExtractionCandidate, kind: str, error: Exception | str) -> None:
        detail = str(error)
        message = json.dumps(
            {
                "level": "warning",
                "type": kind,
                "content_id": candidate.content_id,
                "file": str(candidate.file_path),
                "error": detail,
            },
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        self.logger.warning(message)
        observer.warning(message)

    @staticmethod
    def _path_scope_where_sql(column: str, root_paths: tuple[Path, ...]) -> tuple[str, list[str]]:
        clauses: list[str] = []
        params: list[str] = []
        for root_path in root_paths:
            normalized = str(root_path.resolve())
            clauses.append(f"({column} = ? OR {column} LIKE ?)")
            params.extend([normalized, f"{normalized}{os.sep}%"])
        if not clauses:
            return "1 = 0", []
        return " OR ".join(clauses), params
