from __future__ import annotations

import json
import mimetypes
import subprocess
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from eona.storage import _read_json

EXIFTOOL_EXTRACT_SCHEMA_VERSION = "1"


@dataclass(frozen=True)
class ExiftoolCapabilitySnapshot:
    exiftool_version: str
    extract_schema_version: str = EXIFTOOL_EXTRACT_SCHEMA_VERSION


@dataclass(frozen=True)
class ExiftoolExtractedMetadata:
    image_facts: dict[str, Any]
    image_camera: dict[str, Any]
    image_location: dict[str, Any]


class ExiftoolAdapter:
    convergence_class = "version_based"

    def capture_capability(self, *, manifest: dict[str, Any]) -> ExiftoolCapabilitySnapshot:
        binaries = manifest.get("binaries")
        if not isinstance(binaries, list) or not binaries:
            raise RuntimeError("runtime manifest missing binaries entry for exiftool")
        exiftool_entry = binaries[0]
        version = exiftool_entry.get("version")
        if not isinstance(version, str) or not version:
            raise RuntimeError("runtime manifest missing exiftool version")
        return ExiftoolCapabilitySnapshot(exiftool_version=version)

    def assess_convergence(
        self,
        *,
        previous_version: str | None,
        previous_extract_schema_version: str | None,
        capability_snapshot: ExiftoolCapabilitySnapshot,
    ) -> dict[str, Any]:
        reason_codes: list[str] = []
        if previous_version != capability_snapshot.exiftool_version:
            reason_codes.append("exiftool_version_changed")
        if previous_extract_schema_version != capability_snapshot.extract_schema_version:
            reason_codes.append("extract_schema_version_changed")
        return {
            "is_converged": not reason_codes,
            "should_rederive": bool(reason_codes),
            "reason_codes": reason_codes,
            "classification": self.convergence_class,
        }

    def build_extractor(
        self,
        *,
        executable: Path,
        capability_snapshot: ExiftoolCapabilitySnapshot,
    ) -> "ExiftoolMetadataExtractor":
        return ExiftoolMetadataExtractor(executable=executable, capability_snapshot=capability_snapshot)


class ExiftoolMetadataExtractor:
    def __init__(self, *, executable: Path, capability_snapshot: ExiftoolCapabilitySnapshot) -> None:
        self.executable = executable
        self.capability_snapshot = capability_snapshot

    def extract(self, path: Path) -> ExiftoolExtractedMetadata:
        if not self.executable.is_file():
            raise RuntimeError(f"exiftool missing at {self.executable}")
        result = subprocess.run(
            [
                str(self.executable),
                "-json",
                "-n",
                "-DateTimeOriginal",
                "-SubSecDateTimeOriginal",
                "-OffsetTimeOriginal",
                "-MIMEType",
                "-ImageWidth",
                "-ImageHeight",
                "-Orientation",
                "-Make",
                "-Model",
                "-LensModel",
                "-LensID",
                "-FocalLength",
                "-Aperture",
                "-ISO",
                "-ShutterSpeed",
                "-ExposureTime",
                "-GPSLatitude",
                "-GPSLongitude",
                "-GPSAltitude",
                str(path),
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        if not isinstance(payload, list) or not payload or not isinstance(payload[0], dict):
            raise RuntimeError(f"unexpected exiftool response for {path}")
        raw = payload[0]
        taken_at_original = self._first_text(raw, "SubSecDateTimeOriginal", "DateTimeOriginal")
        offset = self._first_text(raw, "OffsetTimeOriginal")
        facts = {
            "taken_at_utc": self._normalize_taken_at(taken_at_original, offset),
            "taken_at_original": taken_at_original,
            "mime_type": self._first_text(raw, "MIMEType") or mimetypes.guess_type(path.name)[0],
            "width": self._first_int(raw, "ImageWidth"),
            "height": self._first_int(raw, "ImageHeight"),
            "orientation": self._first_int(raw, "Orientation"),
        }
        camera = {
            "make": self._first_text(raw, "Make"),
            "model": self._first_text(raw, "Model"),
            "lens": self._first_text(raw, "LensModel", "LensID"),
            "focal_length_mm": self._first_float(raw, "FocalLength"),
            "aperture": self._first_float(raw, "Aperture"),
            "iso": self._first_int(raw, "ISO"),
            "shutter_speed": self._first_text(raw, "ShutterSpeed", "ExposureTime"),
        }
        location = {
            "raw_latitude": self._first_float(raw, "GPSLatitude"),
            "raw_longitude": self._first_float(raw, "GPSLongitude"),
            "raw_altitude": self._first_float(raw, "GPSAltitude"),
            "cadis_result_json": None,
            "cadis_version": None,
        }
        return ExiftoolExtractedMetadata(image_facts=facts, image_camera=camera, image_location=location)

    @staticmethod
    def _first_text(payload: dict[str, Any], *keys: str) -> str | None:
        for key in keys:
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                return value
        return None

    @staticmethod
    def _first_int(payload: dict[str, Any], *keys: str) -> int | None:
        for key in keys:
            value = payload.get(key)
            if isinstance(value, bool):
                continue
            if isinstance(value, int):
                return value
            if isinstance(value, float) and value.is_integer():
                return int(value)
        return None

    @staticmethod
    def _first_float(payload: dict[str, Any], *keys: str) -> float | None:
        for key in keys:
            value = payload.get(key)
            if isinstance(value, bool):
                continue
            if isinstance(value, (int, float)):
                return float(value)
        return None

    @staticmethod
    def _normalize_taken_at(taken_at_original: str | None, offset: str | None) -> str | None:
        if not taken_at_original or not offset:
            return None
        for fmt in ("%Y:%m:%d %H:%M:%S", "%Y:%m:%d %H:%M:%S.%f"):
            try:
                parsed = datetime.strptime(f"{taken_at_original}{offset}", f"{fmt}%z")
            except ValueError:
                continue
            return parsed.astimezone(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        return None


def capture_exiftool_capability(*, manifest_path: Path) -> ExiftoolCapabilitySnapshot:
    adapter = ExiftoolAdapter()
    manifest = _read_json(manifest_path)
    return adapter.capture_capability(manifest=manifest)
