from __future__ import annotations

import os
from collections.abc import Iterable
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable, TypeVar

from eona.gateway_runtime import get_gateway_runtime_paths, load_gateway_runtime_manifest
from eona.runtime import get_eona_cadis_cache_dir

T = TypeVar("T")


def get_effective_cadis_cache_dir() -> tuple[Path, bool]:
    manifest = load_gateway_runtime_manifest()
    if isinstance(manifest, dict):
        dataset_bundle = manifest.get("dataset_bundle")
        if isinstance(dataset_bundle, dict):
            configured_path = dataset_bundle.get("path")
            if isinstance(configured_path, str) and configured_path.strip():
                candidate = Path(configured_path)
                if not candidate.is_absolute():
                    candidate = (get_gateway_runtime_paths().image_root / candidate).resolve()
                return candidate, False
        return get_gateway_runtime_paths().cadis_dataset_root, False
    return get_eona_cadis_cache_dir(), True


@contextmanager
def cadis_process_env(*, effective_allowed_iso2: Iterable[str] | None):
    previous_cache_dir = os.environ.get("CADIS_CACHE_DIR")
    previous_allowed = os.environ.get("CADIS_ALLOWED_ISO2")
    cache_dir, _ = get_effective_cadis_cache_dir()
    try:
        os.environ["CADIS_CACHE_DIR"] = str(cache_dir)
        if effective_allowed_iso2 is not None:
            os.environ["CADIS_ALLOWED_ISO2"] = ",".join(str(code) for code in effective_allowed_iso2)
        yield
    finally:
        if previous_cache_dir is None:
            os.environ.pop("CADIS_CACHE_DIR", None)
        else:
            os.environ["CADIS_CACHE_DIR"] = previous_cache_dir
        if effective_allowed_iso2 is not None:
            if previous_allowed is None:
                os.environ.pop("CADIS_ALLOWED_ISO2", None)
            else:
                os.environ["CADIS_ALLOWED_ISO2"] = previous_allowed


def call_cadis(
    func: Callable[[Any, Path], T],
    *,
    effective_allowed_iso2: Iterable[str] | None,
) -> T:
    from cadis import CadisSDK

    cache_dir, is_mutable = get_effective_cadis_cache_dir()
    if is_mutable:
        cache_dir.mkdir(parents=True, exist_ok=True)
    allowed = None if effective_allowed_iso2 is None else [str(code) for code in effective_allowed_iso2]
    sdk_kwargs: dict[str, Any] = {"cache_dir": str(cache_dir)}
    if allowed is not None:
        sdk_kwargs["allowed_iso2"] = allowed
    try:
        sdk = CadisSDK(**sdk_kwargs)
    except TypeError:
        with cadis_process_env(effective_allowed_iso2=allowed):
            return func(CadisSDK(), cache_dir)
    return func(sdk, cache_dir)
