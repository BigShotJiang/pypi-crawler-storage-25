from __future__ import annotations

from functools import lru_cache


@lru_cache(maxsize=1)
def register_gateway_image_support() -> dict[str, bool]:
    heif_enabled = False
    try:
        from pillow_heif import register_heif_opener
    except ImportError:
        register_heif_opener = None
    if register_heif_opener is not None:
        register_heif_opener()
        heif_enabled = True
    return {
        "heif": heif_enabled,
    }
