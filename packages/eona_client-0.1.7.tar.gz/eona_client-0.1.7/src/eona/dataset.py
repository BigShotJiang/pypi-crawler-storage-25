from __future__ import annotations

from pathlib import Path
from typing import Any

from eona.cadis_runtime import call_cadis
from eona.runtime import get_eona_cadis_cache_dir
from eona.storage import initialize_storage


def _cache_dir() -> Path:
    initialize_storage(force=False)
    cache_dir = get_eona_cadis_cache_dir()
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir


def dataset_info() -> dict[str, Any]:
    cache_dir = _cache_dir()
    payload = call_cadis(lambda sdk, _: sdk.info(), effective_allowed_iso2=None)
    return {
        "ok": True,
        "summary": "Eona Cadis dataset status retrieved.",
        "details": [
            f"cache_dir = {cache_dir}",
            f"version = {payload.get('version')}",
            f"supported_iso2 = {','.join(payload.get('supported_iso2') or [])}",
            f"installed_iso2 = {','.join(payload.get('installed_iso2') or [])}",
        ],
        "dataset": payload,
        "cache_dir": str(cache_dir),
    }


def dataset_install(iso2: str, *, reinstall: bool = False) -> dict[str, Any]:
    cache_dir = _cache_dir()
    def _run_install(sdk: Any, inherited_cache_dir: Path) -> dict[str, Any]:
        if reinstall:
            return sdk.reinstall(iso2, cache_dir=inherited_cache_dir, update_to_latest=True)
        return sdk.bootstrap(iso2, cache_dir=inherited_cache_dir, update_to_latest=True)

    payload = call_cadis(_run_install, effective_allowed_iso2=None)

    ok = payload.get("bootstrap_status") == "ready"
    operation = "reinstall" if reinstall else "install"
    return {
        "ok": ok,
        "summary": (
            f"Eona Cadis dataset {operation} completed."
            if ok
            else f"Eona Cadis dataset {operation} failed."
        ),
        "details": [
            f"cache_dir = {cache_dir}",
            f"iso2 = {iso2.upper()}",
            f"bootstrap_status = {payload.get('bootstrap_status')}",
        ],
        "dataset": payload,
        "cache_dir": str(cache_dir),
    }
