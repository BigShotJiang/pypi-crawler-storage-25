from __future__ import annotations

import hashlib
import logging
import os
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path

from PIL import Image, ImageCms, ImageOps

from eona.env_compat import compat_env
from eona.gateway_image_support import register_gateway_image_support

PILLOW_CANONICAL_SPEC_VERSION = 1
VIPS_CANONICAL_SPEC_VERSION = 2
MAX_LONG_EDGE = 2880

logging.getLogger("pyvips").setLevel(logging.WARNING)
logging.getLogger("pyvips.voperation").setLevel(logging.WARNING)


@dataclass(frozen=True)
class CanonicalizationResult:
    content_id: str
    canonical_spec_version: int
    storage_relpath: str
    mime_type: str
    byte_size: int
    width: int
    height: int


def _load_pyvips():
    try:
        import pyvips  # type: ignore
    except Exception:
        return None
    return pyvips


class GatewayCanonicalizer:
    def __init__(self, *, root_dir: Path) -> None:
        self.root_dir = root_dir
        register_gateway_image_support()
        self.pyvips = _load_pyvips()
        self.backend_name = self._resolve_backend_name()
        self.canonical_spec_version = (
            VIPS_CANONICAL_SPEC_VERSION if self.backend_name == "vips" else PILLOW_CANONICAL_SPEC_VERSION
        )

    def canonicalize(self, *, source_path: Path, content_dir: Path) -> CanonicalizationResult:
        if self.backend_name == "vips":
            encoded, width, height = self._encode_canonical_bytes_vips(source_path)
        else:
            encoded = self._encode_canonical_bytes_pillow(source_path)
            with Image.open(BytesIO(encoded)) as image:
                width, height = image.size
        content_id = hashlib.sha256(encoded).hexdigest()
        relpath = Path("content") / content_id[:2] / content_id[2:4] / f"{content_id}.jpg"
        destination = self.root_dir / relpath
        destination.parent.mkdir(parents=True, exist_ok=True)
        if not destination.exists():
            temp_path = destination.with_suffix(".tmp")
            temp_path.write_bytes(encoded)
            temp_path.replace(destination)
        return CanonicalizationResult(
            content_id=content_id,
            canonical_spec_version=self.canonical_spec_version,
            storage_relpath=str(relpath),
            mime_type="image/jpeg",
            byte_size=len(encoded),
            width=width,
            height=height,
        )

    def _resolve_backend_name(self) -> str:
        requested = (compat_env("EONA_GATEWAY_CANONICAL_BACKEND", default="auto") or "auto").strip().lower()
        if requested in {"", "auto"}:
            return "vips" if self.pyvips is not None else "pillow"
        if requested == "vips":
            if self.pyvips is None:
                raise RuntimeError("EONA_GATEWAY_CANONICAL_BACKEND=vips but pyvips is not available")
            return "vips"
        if requested == "pillow":
            return "pillow"
        raise RuntimeError(f"Unsupported canonical backend: {requested}")

    def _encode_canonical_bytes_pillow(self, source_path: Path) -> bytes:
        with Image.open(source_path) as image:
            image = ImageOps.exif_transpose(image)
            image = self._convert_to_srgb_pillow(image)
            if image.mode in {"RGBA", "LA"} or (image.mode == "P" and "transparency" in image.info):
                background = Image.new("RGB", image.size, (255, 255, 255))
                alpha = image.convert("RGBA")
                background.paste(alpha, mask=alpha.getchannel("A"))
                image = background
            elif image.mode != "RGB":
                image = image.convert("RGB")
            image = self._resize_pillow(image)
            buffer = BytesIO()
            image.save(
                buffer,
                format="JPEG",
                quality=90,
                subsampling=2,
                progressive=False,
                optimize=True,
            )
            return buffer.getvalue()

    def _encode_canonical_bytes_vips(self, source_path: Path) -> tuple[bytes, int, int]:
        if self.pyvips is None:
            raise RuntimeError("pyvips is not available")
        image = self.pyvips.Image.new_from_file(str(source_path))
        if image.get_typeof("orientation") != 0:
            image = image.autorot()
        if image.hasalpha():
            image = image.flatten(background=[255, 255, 255])
        try:
            image = image.colourspace("srgb")
        except Exception:
            pass
        long_edge = max(image.width, image.height)
        if long_edge > MAX_LONG_EDGE:
            scale = MAX_LONG_EDGE / long_edge
            image = image.resize(scale, kernel="lanczos3")
        encoded = image.jpegsave_buffer(
            Q=90,
            optimize_coding=True,
            interlace=False,
            keep=self.pyvips.ForeignKeep.NONE,
        )
        return encoded, int(image.width), int(image.height)

    def _convert_to_srgb_pillow(self, image: Image.Image) -> Image.Image:
        icc_profile = image.info.get("icc_profile")
        if not icc_profile:
            return image.convert("RGB") if image.mode != "RGB" else image
        try:
            source_profile = ImageCms.ImageCmsProfile(BytesIO(icc_profile))
            destination_profile = ImageCms.createProfile("sRGB")
            converted = ImageCms.profileToProfile(image, source_profile, destination_profile, outputMode="RGB")
            return converted
        except Exception:
            return image.convert("RGB") if image.mode != "RGB" else image

    def _resize_pillow(self, image: Image.Image) -> Image.Image:
        width, height = image.size
        long_edge = max(width, height)
        if long_edge <= MAX_LONG_EDGE:
            return image
        scale = MAX_LONG_EDGE / long_edge
        resized = (
            max(1, round(width * scale)),
            max(1, round(height * scale)),
        )
        return image.resize(resized, Image.Resampling.LANCZOS)
