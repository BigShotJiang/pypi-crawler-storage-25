from __future__ import annotations

import importlib.util
import shutil


def doctor_status() -> dict[str, object]:
    exiftool_path = shutil.which("exiftool")
    sqlite_path = shutil.which("sqlite3")
    cadis_available = importlib.util.find_spec("cadis") is not None
    dependencies = {
        "exiftool": {
            "status": "ok" if exiftool_path else "missing",
            "path": exiftool_path,
        },
        "cadis": {
            "status": "ok" if cadis_available else "missing",
            "path": "python-import" if cadis_available else None,
        },
        "sqlite": {
            "status": "ok" if sqlite_path else "missing",
            "path": sqlite_path,
        },
    }
    missing = [name for name, payload in dependencies.items() if payload["status"] != "ok"]
    if missing:
        return {
            "status": "error",
            "error_code": "DEPENDENCY_MISSING",
            "dependencies": dependencies,
            "missing_dependencies": missing,
        }
    return {
        "status": "ok",
        "dependencies": dependencies,
    }
