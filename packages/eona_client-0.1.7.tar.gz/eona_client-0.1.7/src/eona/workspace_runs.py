from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4

from eona.errors import EonaCliError


@dataclass(frozen=True)
class WorkspaceRunPaths:
    workspace: Path
    runs_dir: Path
    run_dir: Path
    run_json: Path
    logs_dir: Path
    pipeline_log: Path
    memory_db: Path
    lock_file: Path


def utc_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def ensure_input_path(photo_path: str) -> Path:
    path = Path(photo_path).expanduser().resolve()
    if not path.exists():
        raise EonaCliError("INPUT_PATH_NOT_FOUND", "Photo directory does not exist")
    if not path.is_dir():
        raise EonaCliError("INPUT_PATH_NOT_FOUND", "Photo directory does not exist")
    if not os.access(path, os.R_OK | os.X_OK):
        raise EonaCliError("INPUT_PATH_NOT_READABLE", "Photo directory is not readable")
    return path


def ensure_workspace(workspace_dir: str) -> Path:
    path = Path(workspace_dir).expanduser().resolve()
    try:
        path.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise EonaCliError("WORKSPACE_NOT_WRITABLE", f"Workspace cannot be written: {exc}") from exc
    if not os.access(path, os.W_OK | os.X_OK):
        raise EonaCliError("WORKSPACE_NOT_WRITABLE", "Workspace cannot be written")
    (path / "runs").mkdir(parents=True, exist_ok=True)
    return path


def generate_run_id() -> str:
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    return f"run_{stamp}_{uuid4().hex[:6]}"


def run_paths(*, workspace: Path, run_id: str) -> WorkspaceRunPaths:
    run_dir = workspace / "runs" / run_id
    return WorkspaceRunPaths(
        workspace=workspace,
        runs_dir=workspace / "runs",
        run_dir=run_dir,
        run_json=run_dir / "run.json",
        logs_dir=run_dir / "logs",
        pipeline_log=run_dir / "logs" / "pipeline.log",
        memory_db=workspace / "memory.db",
        lock_file=run_dir / ".worker.lock",
    )


def create_run_dir(paths: WorkspaceRunPaths) -> None:
    paths.run_dir.mkdir(parents=True, exist_ok=False)
    paths.logs_dir.mkdir(parents=True, exist_ok=True)


def atomic_write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        "w",
        encoding="utf-8",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        handle.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        temp_path = Path(handle.name)
    temp_path.replace(path)


def read_run_json(paths: WorkspaceRunPaths) -> dict[str, object]:
    if not paths.run_json.is_file():
        raise EonaCliError("RUN_NOT_FOUND", "Run does not exist")
    return json.loads(paths.run_json.read_text(encoding="utf-8"))


def write_run_json(paths: WorkspaceRunPaths, payload: dict[str, object]) -> None:
    atomic_write_json(paths.run_json, payload)
