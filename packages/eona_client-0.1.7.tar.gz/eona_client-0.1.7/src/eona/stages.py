from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any

from eona.artifact_validation import read_ndjson
from eona.errors import EonaCancelRequested, EonaCliError
from eona.exiftool_adapter import ExiftoolCapabilitySnapshot, ExiftoolMetadataExtractor
from eona.indexing import CadisRuntimeNormalizer
from eona.run_state_machine import set_stage_complete, update_stage_counts
from eona.sqlite_materializer import materialize_memory_db
from eona.workspace_runs import WorkspaceRunPaths, ensure_input_path, utc_now, write_run_json


def execute_stage(*, paths: WorkspaceRunPaths, run_state: dict[str, Any], stage: str) -> dict[str, Any]:
    if stage == "SCANNING":
        return run_scanning(paths=paths, run_state=run_state)
    if stage == "METADATA_EXTRACTION":
        return run_metadata(paths=paths, run_state=run_state)
    if stage == "CADIS_LOOKUP":
        return run_geo(paths=paths, run_state=run_state)
    if stage == "SQLITE_WRITE":
        return run_sqlite(paths=paths, run_state=run_state)
    raise EonaCliError("INTERNAL_ERROR", f"Unknown stage: {stage}")


def ensure_not_cancelled(*, paths: WorkspaceRunPaths) -> None:
    run_state = json.loads(paths.run_json.read_text(encoding="utf-8"))
    if str(run_state.get("status")) == "cancelling":
        raise EonaCancelRequested()


def read_photo_records(paths: WorkspaceRunPaths) -> list[dict[str, Any]]:
    artifact = paths.run_dir / "photos.ndjson"
    if not artifact.is_file():
        raise EonaCliError("ARTIFACT_CORRUPTED", "Run artifact is missing or invalid")
    return read_ndjson(artifact)


def write_ndjson(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True) + "\n")


def is_supported_photo_file(path: Path) -> bool:
    return path.suffix.lower() in {
        ".3fr", ".arw", ".cr2", ".cr3", ".dng", ".erf", ".fff", ".heic", ".heif",
        ".iiq", ".jpeg", ".jpg", ".mos", ".mrw", ".nef", ".nrw", ".orf", ".pef",
        ".png", ".raf", ".raw", ".rw2", ".sr2", ".srf", ".tif", ".tiff", ".x3f",
    }


def scan_files(root: Path, paths: WorkspaceRunPaths | None = None) -> list[str]:
    files: list[str] = []
    for current_root, dirnames, filenames in os.walk(root):
        if paths:
            ensure_not_cancelled(paths=paths)
        dirnames[:] = sorted(name for name in dirnames if not Path(current_root, name).is_symlink())
        for name in sorted(filenames):
            path = Path(current_root, name)
            if path.is_symlink() or not path.is_file():
                continue
            if not is_supported_photo_file(path):
                continue
            files.append(str(path.resolve()))
    files.sort()
    return files


def run_scanning(*, paths: WorkspaceRunPaths, run_state: dict[str, Any]) -> dict[str, Any]:
    root = ensure_input_path(str(run_state["input_path"]))
    files = scan_files(root, paths=paths)
    artifact = paths.run_dir / "photos.ndjson"
    write_ndjson(artifact, [{"path": file_path} for file_path in files])
    run_state = update_stage_counts(
        run_state, stage="SCANNING", items_total=len(files), items_done=len(files), artifact=artifact.name, updated_at=utc_now()
    )
    return set_stage_complete(
        run_state, stage="SCANNING", completed_at=utc_now(), artifact=artifact.name, items_total=len(files), items_done=len(files)
    )


def run_metadata(*, paths: WorkspaceRunPaths, run_state: dict[str, Any]) -> dict[str, Any]:
    photos = read_photo_records(paths)
    artifact = paths.run_dir / "metadata.ndjson"
    exiftool_path = shutil.which("exiftool")
    if not exiftool_path:
        raise EonaCliError("DEPENDENCY_MISSING", "Required dependency missing: exiftool")
    extractor = ExiftoolMetadataExtractor(
        executable=Path(exiftool_path),
        capability_snapshot=ExiftoolCapabilitySnapshot(exiftool_version="path"),
    )
    rows: list[dict[str, Any]] = []
    total = len(photos)
    run_state = update_stage_counts(run_state, stage="METADATA_EXTRACTION", items_total=total, items_done=0, updated_at=utc_now())
    write_run_json(paths, run_state)
    for index, row in enumerate(photos, start=1):
        ensure_not_cancelled(paths=paths)
        path = Path(str(row["path"]))
        try:
            metadata = extractor.extract(path)
        except Exception as exc:
            raise EonaCliError("METADATA_EXTRACTION_FAILED", f"Metadata extraction failed for {path}: {exc}") from exc
        rows.append(
            {
                "path": str(path),
                "image_facts": metadata.image_facts,
                "image_camera": metadata.image_camera,
                "image_location": metadata.image_location,
            }
        )
        run_state = update_stage_counts(
            run_state, stage="METADATA_EXTRACTION", items_total=total, items_done=index, updated_at=utc_now()
        )
        write_run_json(paths, run_state)
    write_ndjson(artifact, rows)
    count = len(rows)
    run_state = update_stage_counts(
        run_state, stage="METADATA_EXTRACTION", items_total=count, items_done=count, artifact=artifact.name, updated_at=utc_now()
    )
    return set_stage_complete(
        run_state, stage="METADATA_EXTRACTION", completed_at=utc_now(), artifact=artifact.name, items_total=count, items_done=count
    )


def run_geo(*, paths: WorkspaceRunPaths, run_state: dict[str, Any]) -> dict[str, Any]:
    metadata_artifact = paths.run_dir / "metadata.ndjson"
    if not metadata_artifact.is_file():
        raise EonaCliError("ARTIFACT_CORRUPTED", "Run artifact is missing or invalid")
    metadata_rows = read_ndjson(metadata_artifact)
    total = len(metadata_rows)
    run_state = update_stage_counts(run_state, stage="CADIS_LOOKUP", items_total=total, items_done=0, updated_at=utc_now())
    write_run_json(paths, run_state)
    try:
        normalizer = CadisRuntimeNormalizer()
    except Exception as exc:
        raise EonaCliError("DEPENDENCY_MISSING", f"Required dependency missing: cadis ({exc})") from exc
    rows = []
    for index, row in enumerate(metadata_rows, start=1):
        ensure_not_cancelled(paths=paths)
        location = row.get("image_location") or {}
        latitude = location.get("raw_latitude")
        longitude = location.get("raw_longitude")
        if isinstance(latitude, (int, float)) and isinstance(longitude, (int, float)):
            try:
                normalized = normalizer.normalize(float(latitude), float(longitude))
            except Exception as exc:
                raise EonaCliError("CADIS_LOOKUP_FAILED", f"Cadis lookup failed for {row['path']}: {exc}") from exc
            normalized_payload = {
                "cadis_result_json": normalized.cadis_result_json,
                "cadis_version": normalized.cadis_version,
                "detail": normalized.detail,
            }
        else:
            normalized_payload = {"cadis_result_json": None, "cadis_version": None, "detail": "no_gps"}
        rows.append(
            {
                "path": row["path"],
                "raw_latitude": latitude,
                "raw_longitude": longitude,
                "raw_altitude": location.get("raw_altitude"),
                "normalized_location": normalized_payload,
            }
        )
        run_state = update_stage_counts(run_state, stage="CADIS_LOOKUP", items_total=total, items_done=index, updated_at=utc_now())
        write_run_json(paths, run_state)
    artifact = paths.run_dir / "geo.ndjson"
    write_ndjson(artifact, rows)
    count = len(rows)
    run_state = update_stage_counts(
        run_state, stage="CADIS_LOOKUP", items_total=count, items_done=count, artifact=artifact.name, updated_at=utc_now()
    )
    return set_stage_complete(
        run_state, stage="CADIS_LOOKUP", completed_at=utc_now(), artifact=artifact.name, items_total=count, items_done=count
    )


def run_sqlite(*, paths: WorkspaceRunPaths, run_state: dict[str, Any]) -> dict[str, Any]:
    ensure_not_cancelled(paths=paths)
    count = materialize_memory_db(paths=paths)
    run_state = update_stage_counts(
        run_state,
        stage="SQLITE_WRITE",
        items_total=count,
        items_done=count,
        artifact=str(paths.memory_db.relative_to(paths.workspace)),
        updated_at=utc_now(),
    )
    return set_stage_complete(
        run_state,
        stage="SQLITE_WRITE",
        completed_at=utc_now(),
        artifact=str(paths.memory_db.relative_to(paths.workspace)),
        items_total=count,
        items_done=count,
    )
