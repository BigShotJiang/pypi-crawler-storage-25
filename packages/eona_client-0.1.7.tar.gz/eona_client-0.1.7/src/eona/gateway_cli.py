from __future__ import annotations

import sys

from eona import cli as eona_cli


def main() -> int:
    original_argv = sys.argv[:]
    try:
        sys.argv = [original_argv[0], "gateway", *original_argv[1:]]
        return eona_cli.main()
    finally:
        sys.argv = original_argv


if __name__ == "__main__":
    raise SystemExit(main())
