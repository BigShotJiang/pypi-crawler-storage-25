from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class EonaCliError(Exception):
    error_code: str
    message: str

    def __str__(self) -> str:
        return self.message


class EonaCancelRequested(Exception):
    """Internal cooperative cancellation signal."""


ERROR_EXPLANATIONS: dict[str, dict[str, object]] = {
    "INPUT_PATH_NOT_FOUND": {
        "message": "Photo directory does not exist",
        "resolution": [
            "Check the input path",
            "Ensure the photo directory exists",
            "Retry eona import",
        ],
    },
    "INPUT_PATH_NOT_READABLE": {
        "message": "Photo directory is not readable",
        "resolution": [
            "Check filesystem permissions",
            "Ensure the directory is readable",
            "Retry eona import",
        ],
    },
    "WORKSPACE_NOT_WRITABLE": {
        "message": "Workspace cannot be written",
        "resolution": [
            "Check filesystem permissions",
            "Ensure the workspace directory exists and is writable",
            "Retry eona import",
        ],
    },
    "DEPENDENCY_MISSING": {
        "message": "Required dependency missing",
        "resolution": [
            "Install the missing dependency",
            "Ensure it is available in PATH",
            "Retry eona doctor",
            "Retry eona import",
        ],
    },
    "RUN_NOT_FOUND": {
        "message": "Run does not exist",
        "resolution": [
            "Check the run_id",
            "Check the workspace path",
            "Retry eona status or eona resume",
        ],
    },
    "RUN_NOT_RESUMABLE": {
        "message": "Run cannot be resumed",
        "resolution": [
            "Check whether the run is already complete",
            "Check whether another worker is already active for the run",
            "Retry eona status",
        ],
    },
    "RUN_NOT_CANCELLABLE": {
        "message": "Run cannot be cancelled in its current state",
        "resolution": [
            "Check the current run status",
            "Only started or running runs can be cancelled",
            "Start a new import if you need a fresh run",
        ],
    },
    "RUN_ALREADY_CANCELLED": {
        "message": "Run is already cancelled",
        "resolution": [
            "Use eona status to inspect the final state",
            "Start a new import if you want to run again",
        ],
    },
    "CANCEL_FAILED": {
        "message": "Unable to stop active worker",
        "resolution": [
            "Inspect run.json and logs/pipeline.log",
            "Verify whether the worker process is still alive",
            "Retry cancellation or inspect the run manually",
        ],
    },
    "ARTIFACT_CORRUPTED": {
        "message": "Run artifact is missing or invalid",
        "resolution": [
            "Inspect run.json and stage artifacts",
            "Retry eona resume to recompute invalid stages",
            "Restart the run if recovery fails",
        ],
    },
    "PIPELINE_VERSION_MISMATCH": {
        "message": "Stored stage metadata does not match the current pipeline version",
        "resolution": [
            "Retry eona resume to rewind invalid stages",
            "Restart the run if the mismatch persists",
        ],
    },
    "SCANNING_FAILED": {
        "message": "Scanning stage failed",
        "resolution": [
            "Check filesystem permissions and path stability",
            "Retry eona resume",
        ],
    },
    "METADATA_EXTRACTION_FAILED": {
        "message": "Metadata extraction stage failed",
        "resolution": [
            "Verify exiftool is available",
            "Retry eona doctor",
            "Retry eona resume",
        ],
    },
    "CADIS_LOOKUP_FAILED": {
        "message": "Cadis lookup stage failed",
        "resolution": [
            "Verify cadis is available",
            "Retry eona doctor",
            "Retry eona resume",
        ],
    },
    "SQLITE_WRITE_FAILED": {
        "message": "SQLite materialization failed",
        "resolution": [
            "Check workspace writability",
            "Retry eona resume",
        ],
    },
    "INTERNAL_ERROR": {
        "message": "Unexpected internal error",
        "resolution": [
            "Inspect the run logs",
            "Retry eona resume if the run is recoverable",
            "Restart the run if the failure persists",
        ],
    },
    "GATEWAY_POLICY_VIOLATION": {
        "message": "Gateway startup policy violation",
        "resolution": [
            "Bind Gateway to localhost for standard deployment",
            "Set the explicit Gateway policy environment variables when using non-local bind",
            "Configure service authentication before starting Gateway",
        ],
    },
}


def explain_error(error_code: str) -> dict[str, object]:
    payload = ERROR_EXPLANATIONS.get(error_code)
    if payload is None:
        return {
            "error_code": error_code,
            "message": "Unknown error code",
            "resolution": [
                "Inspect the run logs",
                "Check the exact error_code returned by the command",
            ],
        }
    return {
        "error_code": error_code,
        "message": payload["message"],
        "resolution": payload["resolution"],
    }


def error_result(error_code: str, message: str | None = None) -> dict[str, object]:
    explanation = explain_error(error_code)
    return {
        "status": "error",
        "error_code": error_code,
        "message": message or str(explanation["message"]),
    }
