from __future__ import annotations

import json
import sqlite3

from eona.artifact_validation import read_ndjson
from eona.workspace_runs import WorkspaceRunPaths


def materialize_memory_db(*, paths: WorkspaceRunPaths) -> int:
    sqlite_dir = paths.run_dir / "sqlite"
    sqlite_dir.mkdir(parents=True, exist_ok=True)
    temp_db = sqlite_dir / "memory.db.tmp"
    final_db = paths.memory_db
    photos = read_ndjson(paths.run_dir / "photos.ndjson")
    metadata_rows = {row["path"]: row for row in read_ndjson(paths.run_dir / "metadata.ndjson")}
    geo_rows = {row["path"]: row for row in read_ndjson(paths.run_dir / "geo.ndjson")}
    with sqlite3.connect(temp_db) as connection:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS photos (
                path TEXT PRIMARY KEY
            );
            CREATE TABLE IF NOT EXISTS metadata (
                path TEXT PRIMARY KEY,
                metadata_json TEXT
            );
            CREATE TABLE IF NOT EXISTS geo (
                path TEXT PRIMARY KEY,
                geo_json TEXT
            );
            """
        )
        for row in photos:
            connection.execute("INSERT OR REPLACE INTO photos(path) VALUES(?)", (row["path"],))
            connection.execute(
                "INSERT OR REPLACE INTO metadata(path, metadata_json) VALUES(?, ?)",
                (row["path"], json.dumps(metadata_rows.get(row["path"], {}), sort_keys=True)),
            )
            connection.execute(
                "INSERT OR REPLACE INTO geo(path, geo_json) VALUES(?, ?)",
                (row["path"], json.dumps(geo_rows.get(row["path"], {}), sort_keys=True)),
            )
        connection.commit()
    temp_db.replace(final_db)
    return len(photos)
