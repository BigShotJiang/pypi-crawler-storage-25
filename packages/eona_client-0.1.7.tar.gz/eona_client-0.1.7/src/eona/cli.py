from __future__ import annotations

import argparse
import json
from pathlib import Path

from eona.dataset import dataset_info, dataset_install
from eona.doctor import doctor_status
from eona.errors import EonaCliError, error_result, explain_error
from eona.gateway_client import (
    GatewayClientError,
    backfill_duplicate_semantics as backfill_duplicate_semantics_via_gateway,
    discover_import_files,
    backfill_tags as backfill_tags_via_gateway,
    import_path_to_gateway,
)
from eona.gateway_paths import GatewayPaths
from eona.gateway_schema import initialize_gateway_storage
from eona.gateway_runtime import bootstrap_gateway_runtime, inspect_gateway_runtime
from eona.gateway_service import GatewayService, GatewayServiceError
from eona.importer import apply_authorized_capabilities
from eona.runtime import assemble_macos_release_tree, bootstrap_runtime, check_runtime, setup_release
from eona.storage import get_project_status_for_roots, initialize_storage
from eona.worker import cancel_run, get_status as get_run_status, resume_run, run_worker


LOCAL_GATEWAY_URL = "http://127.0.0.1:8000"


def serve_gateway(*, host: str = "127.0.0.1", port: int = 8000, poll_interval: float = 0.25) -> int:
    from eona.gateway_server import serve_gateway as _serve_gateway

    return _serve_gateway(host=host, port=port, poll_interval=poll_interval)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="eona")
    subparsers = parser.add_subparsers(dest="command", required=True)

    runtime_parser = subparsers.add_parser("runtime")
    runtime_subparsers = runtime_parser.add_subparsers(dest="runtime_command", required=True)

    bootstrap_parser = runtime_subparsers.add_parser("bootstrap")
    bootstrap_parser.add_argument(
        "--force",
        action="store_true",
        help="Rewrite the installed runtime contract even if it already exists.",
    )
    bootstrap_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    check_parser = runtime_subparsers.add_parser("check")
    check_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    schema_parser = subparsers.add_parser("schema")
    schema_subparsers = schema_parser.add_subparsers(dest="schema_command", required=True)

    schema_init_parser = schema_subparsers.add_parser("init")
    schema_init_parser.add_argument(
        "--force",
        action="store_true",
        help="Recreate the Phase 2 database and rewrite config/state files even if they already exist.",
    )
    schema_init_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    status_parser = subparsers.add_parser("status")
    status_parser.add_argument("run_id", nargs="?")
    status_parser.add_argument("--workspace", help="Workspace directory. Defaults to the current directory.")
    status_parser.add_argument("--limit", type=int, default=10, help="Number of recent runs to show when no run ID is given.")
    status_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    doctor_parser = subparsers.add_parser("doctor")
    doctor_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    explain_error_parser = subparsers.add_parser("explain-error")
    explain_error_parser.add_argument("error_code", help="Stable machine-readable error code.")
    explain_error_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    apply_parser = subparsers.add_parser("apply")
    apply_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    dataset_parser = subparsers.add_parser("dataset")
    dataset_subparsers = dataset_parser.add_subparsers(dest="dataset_command", required=True)

    dataset_info_parser = dataset_subparsers.add_parser("info")
    dataset_info_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    dataset_install_parser = dataset_subparsers.add_parser("install")
    dataset_install_parser.add_argument("iso2", help="ISO2 dataset code to install.")
    dataset_install_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    dataset_reinstall_parser = dataset_subparsers.add_parser("reinstall")
    dataset_reinstall_parser.add_argument("iso2", help="ISO2 dataset code to reinstall.")
    dataset_reinstall_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    index_parser = subparsers.add_parser("index")
    index_subparsers = index_parser.add_subparsers(dest="index_command", required=True)
    for name in ("status", "start", "pause", "resume", "stop"):
        subparser = index_subparsers.add_parser(name)
        subparser.add_argument("--json", action="store_true", help="Emit JSON output.")

    extract_parser = subparsers.add_parser("extract")
    extract_subparsers = extract_parser.add_subparsers(dest="extract_command", required=True)
    for name in ("status", "start", "stop"):
        subparser = extract_subparsers.add_parser(name)
        subparser.add_argument("--json", action="store_true", help="Emit JSON output.")

    renorm_parser = subparsers.add_parser("renorm")
    renorm_subparsers = renorm_parser.add_subparsers(dest="renorm_command", required=True)
    for name in ("status", "start", "stop"):
        subparser = renorm_subparsers.add_parser(name)
        subparser.add_argument("--json", action="store_true", help="Emit JSON output.")

    import_parser = subparsers.add_parser("import")
    import_parser.add_argument("photo_path", help="Photo file or directory path to import locally.")
    import_parser.add_argument("--workspace", help="Workspace directory. Defaults to the current directory.")
    import_parser.add_argument("--dry-run", action="store_true", help="Report discovered files without starting an import run.")
    import_parser.add_argument("--limit", type=int, default=10, help="Number of recent runs to include in the response.")
    import_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    backfill_duplicate_parser = subparsers.add_parser("backfill-duplicate-semantic")
    backfill_duplicate_parser.add_argument("--workspace", help="Workspace directory. Defaults to the current directory.")
    backfill_duplicate_parser.add_argument("--limit", type=int, help="Only process up to this many photo rows.")
    backfill_duplicate_mode = backfill_duplicate_parser.add_mutually_exclusive_group()
    backfill_duplicate_mode.add_argument("--incremental", action="store_true", help="Prefer incremental duplicate semantic work when available (default).")
    backfill_duplicate_mode.add_argument("--full-replay", action="store_true", help="Recompute duplicate semantics for all candidate photos.")
    backfill_duplicate_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    backfill_tags_parser = subparsers.add_parser("backfill-tags")
    backfill_tags_parser.add_argument("--workspace", help="Workspace directory. Defaults to the current directory.")
    backfill_tags_parser.add_argument("--tag", required=True, help="Semantic tag family to backfill, currently has_people.")
    backfill_tags_parser.add_argument("--limit", type=int, help="Only process up to this many photo rows.")
    backfill_tags_mode = backfill_tags_parser.add_mutually_exclusive_group()
    backfill_tags_mode.add_argument("--incremental", action="store_true", help="Only process photos missing current semantic rows for this tag family (default).")
    backfill_tags_mode.add_argument("--full-replay", action="store_true", help="Recompute the entire tag family for all candidate photos.")
    backfill_tags_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    resume_parser = subparsers.add_parser("resume")
    resume_parser.add_argument("run_id", help="Run identifier to resume.")
    resume_parser.add_argument("--workspace", required=True, help="Workspace directory for agent-native resume.")
    resume_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    cancel_parser = subparsers.add_parser("cancel")
    cancel_parser.add_argument("run_id", help="Run identifier to cancel.")
    cancel_parser.add_argument("--workspace", required=True, help="Workspace directory for agent-native cancel.")
    cancel_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    worker_parser = subparsers.add_parser("_run-worker")
    worker_parser.add_argument("run_id", help=argparse.SUPPRESS)
    worker_parser.add_argument("--workspace", required=True, help=argparse.SUPPRESS)

    project_status_parser = subparsers.add_parser("project-status")
    project_status_parser.add_argument(
        "--root",
        dest="roots",
        action="append",
        required=True,
        help="Absolute or user-relative root path in the project root group. Repeat for multiple roots.",
    )
    project_status_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    gateway_parser = subparsers.add_parser("gateway")
    gateway_subparsers = gateway_parser.add_subparsers(dest="gateway_command", required=True)

    gateway_init_parser = gateway_subparsers.add_parser("init-db")
    gateway_init_parser.add_argument("--force", action="store_true", help="Recreate the Gateway database.")
    gateway_init_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    gateway_check_runtime_parser = gateway_subparsers.add_parser("check-runtime")
    gateway_check_runtime_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    gateway_bootstrap_runtime_parser = gateway_subparsers.add_parser("bootstrap-runtime")
    gateway_bootstrap_runtime_parser.add_argument(
        "--force",
        action="store_true",
        help="Replace any existing local Gateway runtime metadata and dataset tree.",
    )
    gateway_bootstrap_runtime_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    gateway_doctor_parser = gateway_subparsers.add_parser("doctor")
    gateway_doctor_parser.add_argument(
        "--abandoned-older-than-hours",
        type=float,
        default=24.0,
        help="Age threshold for abandoned-import cleanup candidacy checks.",
    )
    gateway_doctor_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    gateway_serve_parser = gateway_subparsers.add_parser("serve")
    gateway_serve_parser.add_argument("--host", default="127.0.0.1", help="Host interface to bind.")
    gateway_serve_parser.add_argument("--port", type=int, default=8000, help="Port to bind.")
    gateway_serve_parser.add_argument(
        "--poll-interval",
        type=float,
        default=0.25,
        help="Worker polling interval in seconds.",
    )

    gateway_import_parser = gateway_subparsers.add_parser("import")
    gateway_import_parser.add_argument("photo_folder", help="Absolute photo file or directory path to import into Gateway.")
    import_mode_group = gateway_import_parser.add_mutually_exclusive_group(required=True)
    import_mode_group.add_argument("--by-upload", action="store_true", help="Use upload-backed collection through the Gateway API.")
    import_mode_group.add_argument("--by-mount", action="store_true", help="Use mount-backed collection against a local Gateway.")
    gateway_import_parser.add_argument("--gateway-url", help="Gateway base URL override.")
    gateway_import_parser.add_argument("--access-token", help="Gateway bearer token override.")
    gateway_import_parser.add_argument(
        "--path-hint-mode",
        default="relative",
        choices=("relative", "absolute", "filename"),
        help="How to derive per-file path_hint values.",
    )
    gateway_import_parser.add_argument("--dry-run", action="store_true", help="Report discovered files without collecting them.")
    gateway_import_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    gateway_cleanup_parser = gateway_subparsers.add_parser("cleanup-abandoned")
    gateway_cleanup_parser.add_argument(
        "--older-than-hours",
        type=float,
        default=24.0,
        help="Only clean import sessions last updated before this age threshold.",
    )
    gateway_cleanup_parser.add_argument("--dry-run", action="store_true", help="Report cleanup candidates without deleting them.")
    gateway_cleanup_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    gateway_cleanup_terminal_parser = gateway_subparsers.add_parser("cleanup-terminal-data")
    gateway_cleanup_terminal_parser.add_argument(
        "--older-than-hours",
        type=float,
        default=24.0,
        help="Only clean transient data for terminal runs older than this age threshold.",
    )
    gateway_cleanup_terminal_parser.add_argument(
        "--include-recoverable-failed",
        action="store_true",
        help="Also clean failed runs that are still recoverable via recover-merge.",
    )
    gateway_cleanup_terminal_parser.add_argument("--dry-run", action="store_true", help="Report cleanup candidates without deleting them.")
    gateway_cleanup_terminal_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    gateway_apply_upgrades_parser = gateway_subparsers.add_parser("apply-runtime-upgrades")
    gateway_apply_upgrades_parser.add_argument(
        "--batch-size",
        type=int,
        default=250,
        help="Number of photo rows to scan per batch while applying runtime upgrades.",
    )
    gateway_apply_upgrades_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    gateway_accept_upgrades_parser = gateway_subparsers.add_parser("accept-runtime-upgrades")
    gateway_accept_upgrades_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    gateway_recover_merge_parser = gateway_subparsers.add_parser("recover-merge")
    gateway_recover_merge_parser.add_argument("run_ids", nargs="+", help="Failed Gateway run IDs to recover from CANONICALIZATION/MERGE.")
    gateway_recover_merge_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    gateway_backfill_location_parser = gateway_subparsers.add_parser("backfill-location")
    gateway_backfill_location_parser.add_argument(
        "--limit",
        type=int,
        help="Only process up to this many candidate photo rows.",
    )
    gateway_backfill_location_parser.add_argument(
        "--batch-size",
        type=int,
        default=250,
        help="Number of candidate rows to scan per batch.",
    )
    gateway_backfill_location_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    gateway_backfill_duplicate_parser = gateway_subparsers.add_parser("backfill-duplicate-semantic")
    gateway_backfill_duplicate_parser.add_argument(
        "--limit",
        type=int,
        help="Only process up to this many photo rows.",
    )
    gateway_backfill_duplicate_mode = gateway_backfill_duplicate_parser.add_mutually_exclusive_group()
    gateway_backfill_duplicate_mode.add_argument(
        "--incremental",
        action="store_true",
        help="Prefer incremental duplicate semantic work when available (default).",
    )
    gateway_backfill_duplicate_mode.add_argument(
        "--full-replay",
        action="store_true",
        help="Recompute duplicate semantics for all candidate photos.",
    )
    gateway_backfill_duplicate_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    gateway_backfill_tags_parser = gateway_subparsers.add_parser("backfill-tags")
    gateway_backfill_tags_parser.add_argument(
        "--tag",
        required=True,
        help="Semantic tag family to backfill, currently has_people.",
    )
    gateway_backfill_tags_parser.add_argument(
        "--limit",
        type=int,
        help="Only process up to this many photo rows.",
    )
    gateway_backfill_tags_mode = gateway_backfill_tags_parser.add_mutually_exclusive_group()
    gateway_backfill_tags_mode.add_argument(
        "--incremental",
        action="store_true",
        help="Only process photos missing current semantic rows for this tag family (default).",
    )
    gateway_backfill_tags_mode.add_argument(
        "--full-replay",
        action="store_true",
        help="Recompute the entire tag family for all candidate photos.",
    )
    gateway_backfill_tags_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    setup_parser = subparsers.add_parser("setup")
    setup_parser.add_argument(
        "--release-root",
        help="Path to an unpacked Eona macOS release. Defaults to EONA_RELEASE_ROOT, EONA_RELEASE_ROOT, or the current directory.",
    )
    setup_parser.add_argument("--force", action="store_true", help="Reinitialize Gateway state if needed.")
    setup_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    release_parser = subparsers.add_parser("release")
    release_subparsers = release_parser.add_subparsers(dest="release_command", required=True)

    release_build_parser = release_subparsers.add_parser("build-macos")
    release_build_parser.add_argument("output_root", help="Destination directory for the assembled macOS release tree.")
    release_build_parser.add_argument("--release-version", help="Version string to embed in staged macOS release metadata.")
    release_build_parser.add_argument("--force", action="store_true", help="Replace the destination if it already exists.")
    release_build_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    return parser


def _legacy_daemon_command_result(*, command_name: str) -> dict[str, object]:
    return {
        "ok": False,
        "summary": f"`eona {command_name}` is a legacy daemon-era command.",
        "details": [
            "Use `eona import --root ...` for importer execution.",
            "Use `eona project-status --root ...` for project operational state.",
        ],
    }


def _resolve_workspace_dir(workspace: str | None) -> Path:
    return (Path(workspace).expanduser() if workspace else Path.cwd()).resolve()


def _workspace_gateway_paths(workspace_dir: Path) -> GatewayPaths:
    root = workspace_dir / "data"
    return GatewayPaths(
        root=root,
        content_dir=root / "content",
        imports_dir=root / "imports",
        import_sessions_dir=root / "imports" / "sessions",
        runs_dir=root / "runs",
        db_dir=root / "db",
        tmp_dir=root / "tmp",
        database=root / "db" / "gateway.db",
    )


def _workspace_gateway_service(workspace_dir: Path) -> GatewayService:
    paths = _workspace_gateway_paths(workspace_dir)
    initialize_gateway_storage(paths=paths)
    return GatewayService(paths=paths)


def _localize_command(command: str) -> str:
    if command.startswith("eona-client "):
        return "eona " + command[len("eona-client ") :]
    return command


def _localize_run_payload(run_payload: dict[str, object]) -> dict[str, object]:
    localized = dict(run_payload)
    report = localized.get("report")
    if not isinstance(report, dict):
        return localized
    localized_report = dict(report)
    suggestions = []
    for suggestion in localized_report.get("semantic_enrichment_suggestions") or []:
        if not isinstance(suggestion, dict):
            continue
        localized_suggestion = dict(suggestion)
        command = localized_suggestion.get("command")
        if isinstance(command, str):
            localized_suggestion["command"] = _localize_command(command)
        suggestions.append(localized_suggestion)
    localized_report["semantic_enrichment_suggestions"] = suggestions
    localized["report"] = localized_report
    return localized


def _local_operational_summary_from_run_payload(run_payload: dict[str, object]) -> dict[str, object] | None:
    status = str(run_payload.get("status") or "")
    if status != "complete":
        current_stage = str(run_payload.get("current_stage") or "")
        message = "Import run is not complete yet."
        if current_stage:
            message = f"Import run is still in progress at stage {current_stage}."
        return {
            "user_message": message,
            "required_actions": [],
            "recommended_actions": [],
        }
    report = run_payload.get("report")
    if not isinstance(report, dict):
        return {
            "user_message": "Import completed. Optional semantic improvements may still be available.",
            "required_actions": [],
            "recommended_actions": [],
        }
    recommended_actions = []
    for suggestion in report.get("semantic_enrichment_suggestions") or []:
        if not isinstance(suggestion, dict):
            continue
        recommended_actions.append(
            {
                "name": str(suggestion.get("job_name") or "semantic_job"),
                "what_it_is": str(suggestion.get("summary") or ""),
                "command": _localize_command(str(suggestion.get("command") or "")),
            }
        )
    user_message = "Import completed."
    if recommended_actions:
        user_message = "Import completed. Optional semantic improvements are available."
    return {
        "user_message": user_message,
        "required_actions": [],
        "recommended_actions": recommended_actions,
    }


def _local_workspace_import(*, workspace_dir: Path, photo_path: str, dry_run: bool, list_limit: int) -> dict[str, object]:
    from eona.gateway_worker import GatewayWorkerLoop

    service = _workspace_gateway_service(workspace_dir)
    source_path = Path(photo_path).expanduser()
    if not source_path.is_absolute():
        source_path = (workspace_dir / source_path).resolve()
    else:
        source_path = source_path.resolve()

    files, errors = discover_import_files(source_path)
    if not files:
        raise EonaCliError("IMPORT_PATH_EMPTY", f"No supported photo files found under {source_path}")
    if dry_run:
        return {
            "ok": True,
            "summary": f"Discovered {len(files)} supported photo file(s).",
            "details": [],
            "workspace": str(workspace_dir),
            "gateway_root": str(service.paths.root),
            "photo_path": str(source_path),
            "file_count": len(files),
            "error_count": len(errors),
            "errors": errors,
            "status": "dry_run",
            "recent_runs": service.list_import_runs(limit=list_limit)["items"],
        }

    session = service.create_import_session()
    collected = service.collect_import_path(import_id=str(session["import_id"]), source_path=str(source_path))
    if int(collected.get("file_count") or 0) <= 0:
        raise EonaCliError("IMPORT_PATH_EMPTY", f"No supported photo files found under {source_path}")
    committed = service.commit_import_session(str(session["import_id"]))
    worker = GatewayWorkerLoop(service=service)
    run_payload = worker.run_once()
    if run_payload is None:
        run_payload = service.get_import_run_detail(str(committed["run_id"]))
    localized_run = _localize_run_payload(run_payload)
    run_status = str(localized_run.get("status") or "")
    summary = f"Imported {int(collected.get('file_count') or 0)} photo file(s) into the workspace."
    if run_status and run_status != "complete":
        summary = f"Workspace import run {str(localized_run.get('run_id') or committed.get('run_id') or '')} ended with status {run_status}."
    return {
        "ok": run_status == "complete",
        "summary": summary,
        "details": [],
        "workspace": str(workspace_dir),
        "gateway_root": str(service.paths.root),
        "photo_path": str(source_path),
        "file_count": int(collected.get("file_count") or 0),
        "error_count": int(collected.get("error_count") or len(errors)),
        "errors": list(collected.get("errors") or errors),
        "import_id": committed.get("import_id"),
        "run": localized_run,
        "operational_summary": _local_operational_summary_from_run_payload(localized_run),
        "recent_runs": service.list_import_runs(limit=list_limit)["items"],
    }


def _local_workspace_status(*, workspace_dir: Path, run_id: str | None, limit: int) -> dict[str, object]:
    service = _workspace_gateway_service(workspace_dir)
    if run_id:
        run_payload = _localize_run_payload(service.get_import_run_detail(run_id))
        return {
            "ok": True,
            "summary": f"Workspace import run {run_id} fetched.",
            "details": [],
            "workspace": str(workspace_dir),
            "gateway_root": str(service.paths.root),
            "operational_summary": _local_operational_summary_from_run_payload(run_payload),
            **run_payload,
        }
    recent_runs = [_localize_run_payload(item) for item in service.list_import_runs(limit=limit)["items"]]
    return {
        "ok": True,
        "summary": f"Fetched {len(recent_runs)} recent workspace import run(s).",
        "details": [],
        "workspace": str(workspace_dir),
        "gateway_root": str(service.paths.root),
        "items": recent_runs,
    }


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "gateway" and args.gateway_command == "import":
        if args.by_upload and not args.gateway_url:
            parser.error("`eona-gateway import --by-upload` requires `--gateway-url`.")
        if args.by_mount and args.gateway_url:
            parser.error("`eona-gateway import --by-mount` does not allow `--gateway-url`.")

    try:
        if args.command == "_run-worker":
            return run_worker(run_id=args.run_id, workspace_dir=args.workspace)
        if args.command == "gateway" and args.gateway_command == "serve":
            return serve_gateway(host=args.host, port=args.port, poll_interval=args.poll_interval)
        if args.command == "doctor":
            result = doctor_status()
        elif args.command == "explain-error":
            result = explain_error(args.error_code)
        elif args.command == "status":
            result = _local_workspace_status(
                workspace_dir=_resolve_workspace_dir(args.workspace),
                run_id=args.run_id,
                limit=args.limit,
            )
        elif args.command == "resume":
            result = resume_run(run_id=args.run_id, workspace_dir=args.workspace)
        elif args.command == "cancel":
            result = cancel_run(run_id=args.run_id, workspace_dir=args.workspace)
        elif args.command == "import":
            result = _local_workspace_import(
                workspace_dir=_resolve_workspace_dir(args.workspace),
                photo_path=args.photo_path,
                dry_run=bool(args.dry_run),
                list_limit=args.limit,
            )
        elif args.command == "backfill-duplicate-semantic":
            workspace_dir = _resolve_workspace_dir(args.workspace)
            service = _workspace_gateway_service(workspace_dir)
            backfill_result = service.backfill_duplicate_semantics(
                limit=args.limit,
                replay_mode="full_replay" if args.full_replay else "incremental",
            )
            result = {
                "summary": str(backfill_result.get("summary") or "Duplicate semantic backfill completed."),
                "details": list(backfill_result.get("details") or []),
                "workspace": str(workspace_dir),
                "gateway_root": str(service.paths.root),
                **backfill_result,
            }
        elif args.command == "backfill-tags":
            workspace_dir = _resolve_workspace_dir(args.workspace)
            service = _workspace_gateway_service(workspace_dir)
            tags_result = service.backfill_tags(
                tag=str(args.tag),
                limit=args.limit,
                replay_mode="full_replay" if args.full_replay else "incremental",
            )
            result = {
                "summary": str(tags_result.get("summary") or "Tag backfill completed."),
                "details": list(tags_result.get("details") or []),
                "workspace": str(workspace_dir),
                "gateway_root": str(service.paths.root),
                **tags_result,
            }
        elif args.command == "runtime" and args.runtime_command == "bootstrap":
            result = bootstrap_runtime(force=args.force)
        elif args.command == "runtime" and args.runtime_command == "check":
            result = check_runtime()
        elif args.command == "setup":
            result = setup_release(release_root=args.release_root, force=args.force)
        elif args.command == "schema" and args.schema_command == "init":
            result = initialize_storage(force=args.force)
        elif args.command == "gateway" and args.gateway_command == "init-db":
            result = initialize_gateway_storage(force=args.force)
        elif args.command == "gateway" and args.gateway_command == "check-runtime":
            result = inspect_gateway_runtime(strict=True)
        elif args.command == "gateway" and args.gateway_command == "bootstrap-runtime":
            result = bootstrap_gateway_runtime(force=args.force)
        elif args.command == "gateway" and args.gateway_command == "doctor":
            result = GatewayService().doctor(
                abandoned_older_than_hours=args.abandoned_older_than_hours,
            )
        elif args.command == "gateway" and args.gateway_command == "import":
            collection_mode = "upload" if args.by_upload else "mount"
            base_url = args.gateway_url if args.by_upload else LOCAL_GATEWAY_URL
            import_result = import_path_to_gateway(
                Path(args.photo_folder),
                collection_mode=collection_mode,
                base_url=base_url,
                access_token=args.access_token,
                path_hint_mode=args.path_hint_mode,
                dry_run=args.dry_run,
            )
            result = {
                "ok": True,
                "summary": (
                    f"Discovered {int(import_result['file_count'])} supported photo file(s)."
                    if args.dry_run
                    else f"Queued {int(import_result['file_count'])} file(s) to Gateway."
                ),
                "details": [],
                **import_result,
            }
        elif args.command == "gateway" and args.gateway_command == "cleanup-abandoned":
            result = GatewayService().cleanup_abandoned_import_sessions(
                older_than_hours=args.older_than_hours,
                dry_run=args.dry_run,
            )
        elif args.command == "gateway" and args.gateway_command == "cleanup-terminal-data":
            result = GatewayService().cleanup_terminal_run_data(
                older_than_hours=args.older_than_hours,
                dry_run=args.dry_run,
                include_recoverable_failed=args.include_recoverable_failed,
            )
        elif args.command == "gateway" and args.gateway_command == "apply-runtime-upgrades":
            result = GatewayService().apply_runtime_upgrades(batch_size=args.batch_size)
        elif args.command == "gateway" and args.gateway_command == "accept-runtime-upgrades":
            result = GatewayService().accept_runtime_upgrades()
        elif args.command == "gateway" and args.gateway_command == "recover-merge":
            service = GatewayService()
            recovered = [service.recover_merge_run(run_id) for run_id in args.run_ids]
            result = {
                "ok": True,
                "summary": f"Recovered {len(recovered)} failed Gateway run(s).",
                "details": [],
                "runs": recovered,
            }
        elif args.command == "gateway" and args.gateway_command == "backfill-location":
            result = GatewayService().backfill_photo_locations(
                limit=args.limit,
                batch_size=args.batch_size,
            )
        elif args.command == "gateway" and args.gateway_command == "backfill-duplicate-semantic":
            result = backfill_duplicate_semantics_via_gateway(
                base_url=LOCAL_GATEWAY_URL,
                limit=args.limit,
                replay_mode="full_replay" if args.full_replay else "incremental",
            )
        elif args.command == "gateway" and args.gateway_command == "backfill-tags":
            result = backfill_tags_via_gateway(
                tag=str(args.tag),
                base_url=LOCAL_GATEWAY_URL,
                limit=args.limit,
                replay_mode="full_replay" if args.full_replay else "incremental",
            )
        elif args.command == "dataset" and args.dataset_command == "info":
            result = dataset_info()
        elif args.command == "dataset" and args.dataset_command == "install":
            result = dataset_install(args.iso2, reinstall=False)
        elif args.command == "dataset" and args.dataset_command == "reinstall":
            result = dataset_install(args.iso2, reinstall=True)
        elif args.command == "release" and args.release_command == "build-macos":
            result = assemble_macos_release_tree(
                release_root=args.output_root,
                force=args.force,
                release_version=args.release_version,
            )
        elif args.command == "apply":
            try:
                apply_result = apply_authorized_capabilities()
            except Exception as exc:
                result = {
                    "ok": False,
                    "summary": "Capability authorization failed.",
                    "details": [str(exc)],
                }
            else:
                result = {
                    "ok": bool(apply_result.get("ok")),
                    "summary": str(apply_result.get("summary", "")),
                    "details": [],
                    "authorized_capability": apply_result.get("authorized_capability"),
                    "snapshot_version": apply_result.get("snapshot_version"),
                    "changed": apply_result.get("changed"),
                }
        elif args.command == "index":
            result = _legacy_daemon_command_result(command_name=f"index {args.index_command}")
        elif args.command == "renorm":
            result = _legacy_daemon_command_result(command_name=f"renorm {args.renorm_command}")
        elif args.command == "extract":
            result = _legacy_daemon_command_result(command_name=f"extract {args.extract_command}")
        elif args.command == "project-status":
            project_status = get_project_status_for_roots(tuple(args.roots))
            result = {
                "ok": True,
                "summary": f"Project state: {project_status['project_state']}",
                "details": [],
                "project": project_status,
            }
        else:
            parser.error("unknown command")
            return 2
    except EonaCliError as exc:
        result = error_result(exc.error_code, exc.message)
    except GatewayServiceError as exc:
        result = error_result(exc.error_code, exc.message)
    except GatewayClientError as exc:
        result = {
            "ok": False,
            "summary": "Gateway import failed.",
            "details": [str(exc)],
        }

    if getattr(args, "json", False):
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0 if result.get("status") not in {"error"} and result.get("ok", True) else 1

    if "summary" in result:
        summary = str(result.get("summary", ""))
        if summary:
            print(summary)
        operational_summary = result.get("operational_summary")
        if isinstance(operational_summary, dict):
            user_message = str(operational_summary.get("user_message") or "")
            if user_message:
                print(f"- {user_message}")
            for item in operational_summary.get("required_actions", []) or []:
                name = str(item.get("name") or "action")
                what = str(item.get("what_it_is") or "")
                command = str(item.get("command") or "")
                print(f"- required/{name}: {what}")
                if command:
                    print(f"  command: {command}")
            for item in operational_summary.get("recommended_actions", []) or []:
                name = str(item.get("name") or "action")
                what = str(item.get("what_it_is") or "")
                command = str(item.get("command") or "")
                print(f"- recommended/{name}: {what}")
                if command:
                    print(f"  command: {command}")
        operational_items = result.get("operational_items")
        if isinstance(operational_items, list):
            for item in operational_items:
                if not isinstance(item, dict):
                    continue
                name = str(item.get("name") or "item")
                priority = str(item.get("priority") or "informational")
                item_summary = str(item.get("summary") or "")
                command = str(item.get("command") or "")
                print(f"- {priority}/{name}: {item_summary}")
                if command:
                    print(f"  command: {command}")
        for detail in result.get("details", []):
            print(f"- {detail}")
        return 0 if result.get("ok", False) else 1

    if result.get("status") == "error":
        print(result["message"])
        return 1

    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
