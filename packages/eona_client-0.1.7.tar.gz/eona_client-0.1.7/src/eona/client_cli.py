from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from eona.gateway_client import (
    GatewayClientError,
    backfill_duplicate_semantics,
    backfill_tags,
    doctor_gateway,
    get_import_run,
    health_check_gateway,
    import_path_to_gateway,
)


LOCAL_GATEWAY_URL = "http://127.0.0.1:8000"


def build_parser(*, prog: str | None = None) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog=prog or Path(sys.argv[0]).name or "eona-client")
    subparsers = parser.add_subparsers(dest="command", required=True)

    import_parser = subparsers.add_parser("import")
    import_parser.add_argument("photo_folder", help="Absolute photo file or directory path to import into Gateway.")
    import_mode_group = import_parser.add_mutually_exclusive_group(required=True)
    import_mode_group.add_argument("--by-upload", action="store_true", help="Use upload-backed collection through the Gateway API.")
    import_mode_group.add_argument("--by-mount", action="store_true", help="Use mount-backed collection against a local Gateway.")
    import_parser.add_argument("--gateway-url", help="Gateway base URL override.")
    import_parser.add_argument("--access-token", help="Gateway bearer token override.")
    import_parser.add_argument(
        "--path-hint-mode",
        default="relative",
        choices=("relative", "absolute", "filename"),
        help="How to derive per-file path_hint values.",
    )
    import_parser.add_argument("--dry-run", action="store_true", help="Report discovered files without collecting them.")
    import_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    health_parser = subparsers.add_parser("health")
    health_parser.add_argument("--gateway-url", help="Gateway base URL override.")
    health_parser.add_argument("--access-token", help="Gateway bearer token override.")
    health_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    status_parser = subparsers.add_parser("status")
    status_parser.add_argument("--run-id", required=True, help="Import run ID to inspect.")
    status_parser.add_argument("--gateway-url", help="Gateway base URL override.")
    status_parser.add_argument("--access-token", help="Gateway bearer token override.")
    status_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    doctor_parser = subparsers.add_parser("doctor")
    doctor_parser.add_argument("--gateway-url", help="Gateway base URL override.")
    doctor_parser.add_argument("--access-token", help="Gateway bearer token override.")
    doctor_parser.add_argument(
        "--abandoned-older-than-hours",
        type=float,
        default=24.0,
        help="Age threshold for abandoned-import cleanup candidacy checks.",
    )
    doctor_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    duplicate_parser = subparsers.add_parser("backfill-duplicate-semantic")
    duplicate_parser.add_argument("--gateway-url", help="Gateway base URL override.")
    duplicate_parser.add_argument("--access-token", help="Gateway bearer token override.")
    duplicate_parser.add_argument("--limit", type=int, help="Only process up to this many photo rows.")
    duplicate_mode_group = duplicate_parser.add_mutually_exclusive_group()
    duplicate_mode_group.add_argument(
        "--incremental",
        action="store_true",
        help="Prefer incremental duplicate semantic work when available (default).",
    )
    duplicate_mode_group.add_argument(
        "--full-replay",
        action="store_true",
        help="Recompute duplicate semantics for all candidate photos.",
    )
    duplicate_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    tags_parser = subparsers.add_parser("backfill-tags")
    tags_parser.add_argument("--tag", required=True, help="Semantic tag family to backfill, currently has_people.")
    tags_parser.add_argument("--gateway-url", help="Gateway base URL override.")
    tags_parser.add_argument("--access-token", help="Gateway bearer token override.")
    tags_parser.add_argument("--limit", type=int, help="Only process up to this many photo rows.")
    tags_mode_group = tags_parser.add_mutually_exclusive_group()
    tags_mode_group.add_argument(
        "--incremental",
        action="store_true",
        help="Only process photos missing current semantic rows for this tag family (default).",
    )
    tags_mode_group.add_argument(
        "--full-replay",
        action="store_true",
        help="Recompute the entire tag family for all candidate photos.",
    )
    tags_parser.add_argument("--json", action="store_true", help="Emit JSON output.")

    return parser


def _emit_result(result: dict[str, object], *, as_json: bool) -> int:
    ok = bool(result.get("ok"))
    if as_json:
        print(json.dumps(result, indent=2, sort_keys=True))
    else:
        print(str(result.get("summary", "")))
        operational_summary = result.get("operational_summary")
        if isinstance(operational_summary, dict):
            user_message = str(operational_summary.get("user_message") or "")
            if user_message:
                print(f"- {user_message}")
            for item in operational_summary.get("required_actions", []) or []:
                name = str(item.get("name") or "action")
                what = str(item.get("what_it_is") or "")
                command = str(item.get("command") or "")
                print(f"- required/{name}: {what}")
                if command:
                    print(f"  command: {command}")
            for item in operational_summary.get("recommended_actions", []) or []:
                name = str(item.get("name") or "action")
                what = str(item.get("what_it_is") or "")
                command = str(item.get("command") or "")
                print(f"- recommended/{name}: {what}")
                if command:
                    print(f"  command: {command}")
        operational_items = result.get("operational_items")
        if isinstance(operational_items, list):
            for item in operational_items:
                if not isinstance(item, dict):
                    continue
                name = str(item.get("name") or "item")
                priority = str(item.get("priority") or "informational")
                summary = str(item.get("summary") or "")
                command = str(item.get("command") or "")
                print(f"- {priority}/{name}: {summary}")
                if command:
                    print(f"  command: {command}")
        for detail in result.get("details", []):
            print(f"- {detail}")
    return 0 if ok else 1


def _operational_summary_from_import_result(import_result: dict[str, object]) -> dict[str, object] | None:
    status = str(import_result.get("status") or "")
    run_id = import_result.get("run_id")
    if status == "dry_run":
        return {
            "user_message": "This was a dry run. No import was started.",
            "required_actions": [],
            "recommended_actions": [],
        }
    if status in {"queued", "running", "committing"}:
        message = "Import was queued. Wait for the run to complete before semantic enrichment."
        if run_id:
            message = f"Import was queued as {run_id}. Wait for completion before semantic enrichment."
        return {
            "user_message": message,
            "required_actions": [],
            "recommended_actions": [],
        }
    return None


def _operational_summary_from_run_payload(run_payload: dict[str, object]) -> dict[str, object] | None:
    status = str(run_payload.get("status") or "")
    if status != "complete":
        current_stage = str(run_payload.get("current_stage") or "")
        message = "Import run is not complete yet."
        if current_stage:
            message = f"Import run is still in progress at stage {current_stage}."
        return {
            "user_message": message,
            "required_actions": [],
            "recommended_actions": [],
        }
    report = run_payload.get("report")
    if not isinstance(report, dict):
        return {
            "user_message": "Import completed. Eona should be usable now.",
            "required_actions": [],
            "recommended_actions": [],
        }
    suggestions = report.get("semantic_enrichment_suggestions") or []
    recommended_actions = []
    for suggestion in suggestions:
        if not isinstance(suggestion, dict):
            continue
        recommended_actions.append(
            {
                "name": str(suggestion.get("job_name") or "semantic_job"),
                "what_it_is": str(suggestion.get("summary") or ""),
                "command": str(suggestion.get("command") or ""),
            }
        )
    user_message = "Import completed. Eona is usable now."
    if recommended_actions:
        user_message = "Import completed. Eona is usable now and optional semantic improvements are available."
    return {
        "user_message": user_message,
        "required_actions": [],
        "recommended_actions": recommended_actions,
    }


def _operational_summary_from_duplicate_backfill(result: dict[str, object]) -> dict[str, object] | None:
    if not bool(result.get("ok")):
        return None
    status = str(result.get("status") or "")
    if status in {"started", "running"}:
        return {
            "user_message": (
                "Duplicate semantic enrichment is running in the background. "
                "Use `eona-client health` or `eona-client doctor` to monitor progress."
            ),
            "required_actions": [],
            "recommended_actions": [],
        }
    updated = result.get("duplicate_rows")
    updated_text = f"{updated} duplicate row(s)" if updated is not None else "duplicate semantics"
    return {
        "user_message": (
            f"Duplicate semantic enrichment completed. Eona will now exclude {updated_text} "
            "by default in photo-memory queries."
        ),
        "required_actions": [],
        "recommended_actions": [],
    }


def _operational_summary_from_tag_backfill(result: dict[str, object]) -> dict[str, object] | None:
    if not bool(result.get("ok")):
        return None
    tag = str(result.get("tag") or "")
    status = str(result.get("status") or "")
    if status in {"started", "running"}:
        return {
            "user_message": (
                f"`{tag}` semantic enrichment is running in the background. "
                "Use `eona-client health` or `eona-client doctor` to monitor progress."
            ),
            "required_actions": [],
            "recommended_actions": [],
        }
    if tag == "has_people":
        return {
            "user_message": (
                "People semantic enrichment completed. Eona can now use `has_people` and "
                "`face_count` in photo-memory queries."
            ),
            "required_actions": [],
            "recommended_actions": [],
        }
    return {
        "user_message": "Semantic tag enrichment completed.",
        "required_actions": [],
        "recommended_actions": [],
    }


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "import":
        if args.by_upload and not args.gateway_url:
            parser.error("`import --by-upload` requires `--gateway-url`.")
        if args.by_mount and args.gateway_url:
            parser.error("`import --by-mount` does not allow `--gateway-url`.")

    try:
        if args.command == "import":
            collection_mode = "upload" if args.by_upload else "mount"
            base_url = args.gateway_url if args.by_upload else LOCAL_GATEWAY_URL
            import_result = import_path_to_gateway(
                Path(args.photo_folder),
                collection_mode=collection_mode,
                base_url=base_url,
                access_token=args.access_token,
                path_hint_mode=args.path_hint_mode,
                dry_run=args.dry_run,
            )
            result = {
                "ok": True,
                "summary": (
                    f"Discovered {int(import_result['file_count'])} supported photo file(s)."
                    if args.dry_run
                    else f"Queued {int(import_result['file_count'])} file(s) to Gateway."
                ),
                "details": [],
                "operational_summary": _operational_summary_from_import_result(import_result),
                **import_result,
            }
            return _emit_result(result, as_json=bool(args.json))

        if args.command == "health":
            health_result = health_check_gateway(
                base_url=args.gateway_url,
                access_token=args.access_token,
            )
            readiness = health_result.get("checks", {}).get("health", {})
            result = {
                "summary": "Gateway health checks passed." if health_result.get("ok") else "Gateway health checks reported issues.",
                "details": [],
                "operational_summary": readiness.get("operational_summary"),
                **health_result,
            }
            return _emit_result(result, as_json=bool(args.json))

        if args.command == "status":
            status_result = get_import_run(
                args.run_id,
                base_url=args.gateway_url,
                access_token=args.access_token,
            )
            result = {
                "ok": True,
                "summary": f"Gateway import run {args.run_id} fetched.",
                "details": [],
                "operational_summary": _operational_summary_from_run_payload(status_result),
                **status_result,
            }
            return _emit_result(result, as_json=bool(args.json))

        if args.command == "doctor":
            doctor_result = doctor_gateway(
                base_url=args.gateway_url,
                access_token=args.access_token,
                abandoned_older_than_hours=args.abandoned_older_than_hours,
            )
            result = {
                "summary": str(doctor_result.get("summary") or "Gateway doctor completed."),
                "details": list(doctor_result.get("details") or []),
                **doctor_result,
            }
            return _emit_result(result, as_json=bool(args.json))

        if args.command == "backfill-duplicate-semantic":
            duplicate_result = backfill_duplicate_semantics(
                replay_mode="full_replay" if args.full_replay else "incremental",
                base_url=args.gateway_url,
                access_token=args.access_token,
                limit=args.limit,
            )
            result = {
                "summary": str(duplicate_result.get("summary") or "Duplicate semantic backfill completed."),
                "details": list(duplicate_result.get("details") or []),
                "operational_summary": _operational_summary_from_duplicate_backfill(duplicate_result),
                **duplicate_result,
            }
            return _emit_result(result, as_json=bool(args.json))

        if args.command == "backfill-tags":
            tags_result = backfill_tags(
                tag=args.tag,
                replay_mode="full_replay" if args.full_replay else "incremental",
                base_url=args.gateway_url,
                access_token=args.access_token,
                limit=args.limit,
            )
            result = {
                "summary": str(tags_result.get("summary") or "Tag backfill completed."),
                "details": list(tags_result.get("details") or []),
                "operational_summary": _operational_summary_from_tag_backfill(tags_result),
                **tags_result,
            }
            return _emit_result(result, as_json=bool(args.json))

    except GatewayClientError as exc:
        result = {
            "ok": False,
            "summary": "Gateway client request failed.",
            "details": [str(exc)],
        }
        return _emit_result(result, as_json=bool(getattr(args, "json", False)))

    parser.error("Unsupported eona-client command.")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
