from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

from eona.run_state_machine import STAGES
from eona.workspace_runs import WorkspaceRunPaths


def read_ndjson(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def validate_stage_artifact(*, paths: WorkspaceRunPaths, run_state: dict[str, Any], stage: str) -> bool:
    payload = run_state["stages"][stage]
    artifact_name = payload.get("artifact")
    items_done = payload.get("items_done")
    if stage == "SCANNING":
        if artifact_name != "photos.ndjson":
            return False
        artifact = paths.run_dir / "photos.ndjson"
        if not artifact.is_file():
            return False
        try:
            rows = read_ndjson(artifact)
        except Exception:
            return False
        if any("path" not in row for row in rows):
            return False
        if [str(row["path"]) for row in rows] != sorted(str(row["path"]) for row in rows):
            return False
        return isinstance(items_done, int) and len(rows) == items_done
    if stage == "METADATA_EXTRACTION":
        if artifact_name != "metadata.ndjson":
            return False
        artifact = paths.run_dir / "metadata.ndjson"
        if not artifact.is_file():
            return False
        try:
            rows = read_ndjson(artifact)
        except Exception:
            return False
        if any(
            "path" not in row or "image_facts" not in row or "image_camera" not in row or "image_location" not in row
            for row in rows
        ):
            return False
        return isinstance(items_done, int) and len(rows) == items_done
    if stage == "CADIS_LOOKUP":
        if artifact_name != "geo.ndjson":
            return False
        artifact = paths.run_dir / "geo.ndjson"
        if not artifact.is_file():
            return False
        try:
            rows = read_ndjson(artifact)
        except Exception:
            return False
        if any("path" not in row or "normalized_location" not in row for row in rows):
            return False
        return isinstance(items_done, int) and len(rows) == items_done
    if stage == "SQLITE_WRITE":
        if artifact_name != "memory.db":
            return False
        artifact = paths.memory_db
        if not artifact.is_file():
            return False
        try:
            with sqlite3.connect(artifact) as connection:
                tables = {
                    row[0]
                    for row in connection.execute(
                        "SELECT name FROM sqlite_master WHERE type='table'"
                    ).fetchall()
                }
        except sqlite3.DatabaseError:
            return False
        return {"photos", "metadata", "geo"}.issubset(tables)
    return False


def earliest_invalid_or_incomplete_stage(*, paths: WorkspaceRunPaths, run_state: dict[str, Any]) -> str | None:
    for stage in STAGES:
        payload = run_state["stages"][stage]
        state = str(payload.get("state", "pending"))
        if state != "complete":
            return stage
        if not validate_stage_artifact(paths=paths, run_state=run_state, stage=stage):
            return stage
    return None
