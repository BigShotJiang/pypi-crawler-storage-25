from __future__ import annotations

import logging
from pathlib import Path
from typing import Any
from uuid import uuid4

from eona.cadis_adapter import CadisCapabilitySnapshot as AdapterCadisCapabilitySnapshot
from eona.exiftool_adapter import ExiftoolAdapter, ExiftoolCapabilitySnapshot, capture_exiftool_capability
from eona.extraction import ExtractRunner
from eona.indexing import CadisCapabilitySnapshot, Indexer, build_default_services, capture_cadis_capability
from eona.renormalizing import Renormalizer
from eona.runtime import get_runtime_paths
from eona.storage import (
    _connect_database,
    _read_json,
    advance_snapshot_version,
    create_import_run,
    current_snapshot_version,
    derive_root_group_hash,
    get_import_run,
    get_project_operational_state,
    get_storage_paths,
    normalize_root_paths,
    read_config,
    record_import_suggestion,
    set_authorized_capability,
    set_project_import_state,
    update_import_run,
)

LOCK_CONFLICT_EXIT_CODE = 73


class ImporterObserver:
    def __init__(self, *, run_id: str) -> None:
        self.run_id = run_id
        self.rows_evaluated = 0

    def set_state(
        self,
        state: str,
        *,
        current_file: str | None = None,
        current_content_id: int | None = None,
    ) -> None:
        return None

    def set_total(self, total_estimated: int) -> None:
        return None

    def set_selection_summary(self, selection_summary: dict[str, Any] | None) -> None:
        return None

    def advance(
        self,
        *,
        current_file: str | None = None,
        current_content_id: int | None = None,
        increment: int = 1,
    ) -> None:
        self.rows_evaluated += increment

    def check_control(self) -> str | None:
        return None

    def warning(self, message: str) -> None:
        return None


class EonaImporter:
    def __init__(
        self,
        *,
        indexer: Indexer | None = None,
        extractor_runner: ExtractRunner | None = None,
        renormalizer: Renormalizer | None = None,
        logger: logging.Logger | None = None,
    ) -> None:
        self.logger = logger or logging.getLogger(__name__)
        self.indexer = indexer or Indexer(batch_size=100, logger=self.logger)
        self.extractor_runner = extractor_runner
        self.renormalizer = renormalizer

    def run(
        self,
        *,
        root_paths: tuple[Path, ...],
        run_id: str,
        snapshot_version: int,
    ) -> dict[str, Any]:
        if not root_paths:
            raise RuntimeError("at least one root path is required")

        normalized_roots = normalize_root_paths(root_paths)
        root_group_hash = derive_root_group_hash(normalized_roots)
        _assert_write_lock()
        update_import_run(run_id, status="running")
        observer = ImporterObserver(run_id=run_id)
        rows_mutated = 0

        try:
            run_started_at = _utc_now()
            for root_path in normalized_roots:
                result = self.indexer.run(
                    database_path=get_storage_paths().database,
                    probe_path=root_path,
                    run_started_at=run_started_at,
                    observer=observer,
                    root_group_roots=normalized_roots,
                    root_group_hash=root_group_hash,
                )
                rows_mutated += int(result.get("processed", 0))
                update_import_run(run_id, rows_evaluated=observer.rows_evaluated, rows_mutated=rows_mutated)

            extractor_runner = self.extractor_runner or _build_authorized_extractor_runner()
            if extractor_runner is not None:
                result = extractor_runner.run(
                    database_path=get_storage_paths().database,
                    observer=observer,
                    root_paths=normalized_roots,
                    snapshot_version=snapshot_version,
                )
                rows_mutated += int(result.get("processed", 0))
                update_import_run(run_id, rows_evaluated=observer.rows_evaluated, rows_mutated=rows_mutated)

            renormalizer = self.renormalizer or _build_authorized_renormalizer()
            if renormalizer is not None:
                result = renormalizer.run(
                    database_path=get_storage_paths().database,
                    frozen_capability=_authorized_cadis_capability_snapshot(),
                    observer=observer,
                    root_paths=normalized_roots,
                    snapshot_version=snapshot_version,
                )
                rows_mutated += int(result.get("processed", 0))
                update_import_run(run_id, rows_evaluated=observer.rows_evaluated, rows_mutated=rows_mutated)

            _record_import_suggestions(root_group_hash=root_group_hash, snapshot_version=snapshot_version)
            terminal_time = _utc_now()
            update_import_run(
                run_id,
                status="completed",
                rows_mutated=rows_mutated,
                end_time=terminal_time,
            )
            state = set_project_import_state(
                root_group_hash=root_group_hash,
                snapshot_version=snapshot_version,
                import_time=terminal_time,
                import_status="stable",
                impairment_reason=None,
            )
            return {
                "ok": True,
                "summary": "Import completed.",
                "run": get_import_run(run_id),
                "project_import_state": state,
                "project_operational_state": get_project_operational_state(root_group_hash),
            }
        except Exception as exc:
            terminal_time = _utc_now()
            update_import_run(
                run_id,
                status="failed",
                error_code=_classify_error(exc),
                rows_mutated=rows_mutated,
                end_time=terminal_time,
            )
            set_project_import_state(
                root_group_hash=root_group_hash,
                snapshot_version=snapshot_version,
                import_time=terminal_time,
                import_status="failed",
                impairment_reason=str(exc),
            )
            raise


def apply_authorized_capabilities() -> dict[str, Any]:
    cadis_snapshot: dict[str, Any] | None = None
    exiftool_snapshot: dict[str, Any] | None = None

    try:
        captured_cadis = capture_cadis_capability()
    except Exception:
        captured_cadis = None
    if captured_cadis is not None:
        cadis_snapshot = {
            "cadis_version": captured_cadis.cadis_version,
            "installed_iso2": list(captured_cadis.installed_iso2),
            "supported_iso2": list(captured_cadis.supported_iso2),
            "dataset_lockdown_enabled": captured_cadis.dataset_lockdown_enabled,
            "allowed_iso2": list(captured_cadis.allowed_iso2),
            "effective_allowed_iso2": list(captured_cadis.effective_allowed_iso2),
        }

    try:
        captured_exiftool = capture_exiftool_capability(manifest_path=get_runtime_paths().manifest)
    except Exception:
        captured_exiftool = None
    if captured_exiftool is not None:
        exiftool_snapshot = {
            "exiftool_version": captured_exiftool.exiftool_version,
            "extract_schema_version": captured_exiftool.extract_schema_version,
        }

    previous = read_config().get("authorized_capability") or {"cadis": None, "exiftool": None}
    updated = set_authorized_capability(cadis=cadis_snapshot, exiftool=exiftool_snapshot)
    snapshot_version = current_snapshot_version()
    changed = previous != updated
    if changed:
        snapshot_version = advance_snapshot_version()

    return {
        "ok": True,
        "summary": "Capability authorization applied." if changed else "Capability authorization already current.",
        "authorized_capability": updated,
        "snapshot_version": snapshot_version,
        "changed": changed,
    }


def _utc_now() -> str:
    from eona.storage import _utc_now as storage_utc_now

    return storage_utc_now()


def _assert_write_lock() -> None:
    with _connect_database(get_storage_paths().database) as connection:
        try:
            connection.execute("BEGIN IMMEDIATE")
        except Exception as exc:
            raise WriteLockConflict("write lock conflict") from exc
        finally:
            connection.rollback()


class WriteLockConflict(RuntimeError):
    pass


def _classify_error(exc: Exception) -> str:
    if isinstance(exc, WriteLockConflict):
        return "write_lock_conflict"
    return exc.__class__.__name__.lower()


def _authorized_exiftool_capability_snapshot() -> ExiftoolCapabilitySnapshot | None:
    payload = read_config().get("authorized_capability", {}).get("exiftool")
    if not isinstance(payload, dict):
        return None
    version = payload.get("exiftool_version")
    if not isinstance(version, str) or not version:
        return None
    extract_schema_version = payload.get("extract_schema_version")
    if not isinstance(extract_schema_version, str) or not extract_schema_version:
        extract_schema_version = "1"
    return ExiftoolCapabilitySnapshot(
        exiftool_version=version,
        extract_schema_version=extract_schema_version,
    )


def _authorized_cadis_capability_snapshot() -> AdapterCadisCapabilitySnapshot | None:
    payload = read_config().get("authorized_capability", {}).get("cadis")
    if not isinstance(payload, dict):
        return None
    version = payload.get("cadis_version")
    if not isinstance(version, str) or not version:
        return None
    return AdapterCadisCapabilitySnapshot(
        cadis_version=version,
        ready_iso2=tuple(str(code) for code in payload.get("installed_iso2", [])),
        supported_iso2=tuple(str(code) for code in payload.get("supported_iso2", [])),
        dataset_lockdown_enabled=bool(payload.get("dataset_lockdown_enabled", False)),
        allowed_iso2=tuple(str(code) for code in payload.get("allowed_iso2", [])),
    )


def _build_authorized_extractor_runner() -> ExtractRunner | None:
    capability_snapshot = _authorized_exiftool_capability_snapshot()
    if capability_snapshot is None:
        return None
    runtime_paths = get_runtime_paths()
    manifest = capture_manifest()
    executable = runtime_paths.root / manifest["binaries"][0]["executable_relative_path"]
    extractor = ExiftoolAdapter().build_extractor(
        executable=executable,
        capability_snapshot=capability_snapshot,
    )
    return ExtractRunner(extractor=extractor, batch_size=100)


def _build_authorized_renormalizer() -> Renormalizer | None:
    capability_snapshot = _authorized_cadis_capability_snapshot()
    if capability_snapshot is None:
        return None
    runtime_snapshot = CadisCapabilitySnapshot(
        cadis_version=capability_snapshot.cadis_version,
        installed_iso2=capability_snapshot.ready_iso2,
        dataset_lockdown_enabled=capability_snapshot.dataset_lockdown_enabled,
        allowed_iso2=capability_snapshot.allowed_iso2,
        effective_allowed_iso2=capability_snapshot.effective_available_iso2(),
        supported_iso2=capability_snapshot.supported_iso2,
    )
    _, normalizer = build_default_services(capability_snapshot=runtime_snapshot)
    return Renormalizer(normalizer=normalizer, batch_size=100)


def capture_manifest() -> dict[str, Any]:
    return _read_json(get_runtime_paths().manifest)


def _record_import_suggestions(*, root_group_hash: str, snapshot_version: int) -> None:
    config = read_config()
    authorized = config.get("authorized_capability") or {}

    try:
        capture_exiftool_capability(manifest_path=get_runtime_paths().manifest)
    except Exception:
        pass
    else:
        if not isinstance(authorized.get("exiftool"), dict):
            record_import_suggestion(
                suggestion_id=uuid4().hex,
                root_group_hash=root_group_hash,
                snapshot_version=snapshot_version,
                suggestion_type="apply_extraction_capability",
                payload_hash="exiftool",
            )

    try:
        from eona.indexing import capture_cadis_capability

        capture_cadis_capability()
    except Exception:
        pass
    else:
        if not isinstance(authorized.get("cadis"), dict):
            record_import_suggestion(
                suggestion_id=uuid4().hex,
                root_group_hash=root_group_hash,
                snapshot_version=snapshot_version,
                suggestion_type="apply_location_capability",
                payload_hash="cadis",
            )


def schedule_and_run_import(
    *,
    root_paths: tuple[Path, ...],
    run_id: str | None = None,
    snapshot_version: int | None = None,
    importer: EonaImporter | None = None,
) -> dict[str, Any]:
    normalized_roots = normalize_root_paths(root_paths)
    root_group_hash = derive_root_group_hash(normalized_roots)
    effective_run_id = run_id or uuid4().hex
    effective_snapshot = current_snapshot_version() if snapshot_version is None else int(snapshot_version)

    create_import_run(
        run_id=effective_run_id,
        root_group_hash=root_group_hash,
        snapshot_version=effective_snapshot,
    )
    runner = importer or EonaImporter()
    return runner.run(
        root_paths=normalized_roots,
        run_id=effective_run_id,
        snapshot_version=effective_snapshot,
    )
