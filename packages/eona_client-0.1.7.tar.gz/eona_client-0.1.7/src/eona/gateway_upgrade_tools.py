from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class GatewayUpgradeToolResult:
    module: str
    status: str
    changed: bool
    details: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return {
            "module": self.module,
            "status": self.status,
            "changed": self.changed,
            "details": dict(self.details),
        }


def _parse_version_tuple(value: Any) -> tuple[int, ...] | None:
    if not isinstance(value, str) or not value.strip():
        return None
    parts: list[int] = []
    for item in value.strip().split("."):
        if not item.isdigit():
            return None
        parts.append(int(item))
    return tuple(parts)


def _compare_identity_fields(
    *,
    module: str,
    previous_identity: dict[str, Any],
    current_identity: dict[str, Any],
    fields: tuple[str, ...],
    message: str,
) -> GatewayUpgradeToolResult:
    changed_fields = [
        field
        for field in fields
        if previous_identity.get(field) != current_identity.get(field)
    ]
    if not changed_fields:
        return GatewayUpgradeToolResult(
            module=module,
            status="ready",
            changed=False,
            details={},
        )
    return GatewayUpgradeToolResult(
        module=module,
        status="reimport_suggested",
        changed=True,
        details={
            "message": message,
            "changed_fields": changed_fields,
            "previous": {field: previous_identity.get(field) for field in changed_fields},
            "current": {field: current_identity.get(field) for field in changed_fields},
        },
    )


def run_exiftool_upgrade_tool(
    *,
    previous_identity: dict[str, Any],
    current_identity: dict[str, Any],
) -> dict[str, Any]:
    return _compare_identity_fields(
        module="exiftool",
        previous_identity=previous_identity,
        current_identity=current_identity,
        fields=("exiftool_version",),
        message="ExifTool runtime changed; existing extracted metadata may benefit from reimport.",
    ).as_dict()


def run_cadis_upgrade_tool(
    *,
    previous_identity: dict[str, Any],
    current_identity: dict[str, Any],
) -> dict[str, Any]:
    previous_version = _parse_version_tuple(previous_identity.get("cadis_version"))
    current_version = _parse_version_tuple(current_identity.get("cadis_version"))
    if (
        previous_version is not None
        and current_version is not None
        and len(previous_version) >= 2
        and len(current_version) >= 2
        and previous_version[0] == 0
        and previous_version[1] == 3
        and current_version[0] == 0
        and current_version[1] >= 4
    ):
        return GatewayUpgradeToolResult(
            module="cadis",
            status="needs_attention",
            changed=True,
            details={
                "message": "Cadis 0.3.x to 0.4.x upgrade requires re-running all stored location rows.",
                "reason_code": "cadis_world_name_semantics_changed",
                "reprocess_scope": "all_geo_rows",
                "previous_version": previous_identity.get("cadis_version"),
                "current_version": current_identity.get("cadis_version"),
                "previous_dataset_bundle_version": previous_identity.get("cadis_dataset_bundle_version"),
                "current_dataset_bundle_version": current_identity.get("cadis_dataset_bundle_version"),
            },
        ).as_dict()
    return _compare_identity_fields(
        module="cadis",
        previous_identity=previous_identity,
        current_identity=current_identity,
        fields=("cadis_version", "cadis_dataset_bundle_version", "cadis_dataset_bundle_digest"),
        message="Cadis runtime or dataset bundle changed; existing location facts may benefit from reimport.",
    ).as_dict()


def run_canonicalization_upgrade_tool(
    *,
    previous_identity: dict[str, Any],
    current_identity: dict[str, Any],
) -> dict[str, Any]:
    return _compare_identity_fields(
        module="canonicalization",
        previous_identity=previous_identity,
        current_identity=current_identity,
        fields=("canonical_backend", "canonical_spec_version"),
        message="Canonicalization runtime changed; existing canonical content may benefit from reimport.",
    ).as_dict()


def should_rerun_cadis_row(
    *,
    row: dict[str, Any],
    tool_result: dict[str, Any],
    current_identity: dict[str, Any],
) -> bool:
    details = tool_result.get("details") if isinstance(tool_result, dict) else {}
    if not isinstance(details, dict):
        details = {}
    if details.get("reason_code") == "cadis_world_name_semantics_changed":
        return True
    current_version = current_identity.get("cadis_version")
    row_version = row.get("cadis_version")
    if row.get("cadis_result_json") is None:
        return True
    return current_version is not None and row_version != current_version


def run_gateway_upgrade_tools(
    *,
    previous_identity: dict[str, Any],
    current_identity: dict[str, Any],
) -> list[dict[str, Any]]:
    return [
        run_exiftool_upgrade_tool(previous_identity=previous_identity, current_identity=current_identity),
        run_cadis_upgrade_tool(previous_identity=previous_identity, current_identity=current_identity),
        run_canonicalization_upgrade_tool(previous_identity=previous_identity, current_identity=current_identity),
    ]
