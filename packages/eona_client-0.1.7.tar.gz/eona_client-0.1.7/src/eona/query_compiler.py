from __future__ import annotations

from dataclasses import dataclass
from typing import Any


MAX_QUERY_LIMIT = 500
DEFAULT_QUERY_LIMIT = 20
SUPPORTED_QUERY_VERSION = 1
ALLOWED_AGGREGATIONS = {"count", "count_distinct", "list", "min", "max"}
ALLOWED_OPERATORS = {"==", "!=", ">", ">=", "<", "<=", "contains", "in"}


class QueryValidationError(ValueError):
    error_code = "QUERY_VALIDATION_FAILED"


class QueryCompilationError(ValueError):
    error_code = "QUERY_COMPILATION_FAILED"


@dataclass(frozen=True)
class CompiledQuery:
    sql: str
    params: tuple[Any, ...]
    columns: list[dict[str, str]]
    resolved_plan: dict[str, Any]
    capabilities_used: list[str]


ENTITY_REGISTRY: dict[str, dict[str, Any]] = {
    "photo": {
        "capability": "photo",
        "join": None,
        "attributes": {
            "id": "p.photo_id",
            "content_id": "p.content_id",
            "taken_at_utc": "p.taken_at_utc",
        },
    },
    "time": {
        "capability": "time",
        "join": None,
        "attributes": {
            "year": "p.query_year",
            "month": "p.query_month",
            "day": "p.query_day",
        },
    },
    "camera": {
        "capability": "camera",
        "join": None,
        "attributes": {
            "make": "p.camera_make",
            "model": "p.camera_model",
        },
    },
    "location": {
        "capability": "location",
        "join": "location.photo_id = p.photo_id",
        "source": "gateway_query_location_v2",
        "attributes": {
            "country": "location.query_country",
            "admin_label": "location.query_admin_label",
            "admin_path": "location.query_admin_path",
        },
    },
    "path": {
        "capability": "path",
        "join": "path.photo_id = p.photo_id",
        "source": "gateway_query_path_v1",
        "attributes": {
            "text": "path.path_text",
        },
    },
    "tag": {
        "capability": "tag",
        "join": "tag.photo_id = p.photo_id",
        "source": "gateway_query_tag_v1",
        "attributes": {
            "key": "tag.tag_key",
            "value": "tag.tag_value",
        },
    },
}


def compile_photo_memory_query(plan: dict[str, Any]) -> CompiledQuery:
    if not isinstance(plan, dict):
        raise QueryValidationError("Query plan must be a JSON object.")
    query_version = plan.get("query_version")
    if query_version != SUPPORTED_QUERY_VERSION:
        raise QueryValidationError(
            f"Unsupported query_version `{query_version}`. Supported version is {SUPPORTED_QUERY_VERSION}."
        )

    anchor = _normalize_anchor(plan.get("anchor"))
    selects = _normalize_selects(plan.get("select"))
    filters = _normalize_filters(plan.get("filters", []))
    group_bys = _normalize_group_bys(plan.get("group_by", []))
    sort_bys = _normalize_sort_bys(plan.get("sort_by", []))
    limit = _normalize_limit(plan.get("limit", DEFAULT_QUERY_LIMIT))

    involved_entities = {anchor["entity"]}
    filtered_entities: set[str] = set()
    capabilities_used = {_capability_for(anchor["entity"])}
    for clause in selects + filters + group_bys + sort_bys:
        entity = str(clause["entity"])
        involved_entities.add(entity)
        capabilities_used.add(_capability_for(entity))
    for clause in filters:
        filtered_entities.add(str(clause["entity"]))

    joins = _build_joins(involved_entities=involved_entities, filtered_entities=filtered_entities)

    select_clauses: list[str] = []
    columns: list[dict[str, str]] = []
    resolved_selects: list[dict[str, Any]] = []
    non_aggregate_select_exprs: list[str] = []
    non_aggregate_group_aliases: list[tuple[str, str]] = []
    for clause in selects:
        compiled = _compile_select(clause)
        select_clauses.append(compiled["sql"])
        columns.append({"name": compiled["alias"], "type": compiled["type"]})
        resolved_selects.append(compiled["resolved"])
        if compiled["group_expr"] is not None:
            non_aggregate_select_exprs.append(str(compiled["group_expr"]))
            non_aggregate_group_aliases.append((compiled["alias"], str(compiled["group_expr"])))

    where_clauses: list[str] = ["COALESCE(p.duplicate_exclude_by_default, 0) = 0"]
    params: list[Any] = []
    resolved_filters: list[dict[str, Any]] = []
    for clause in filters:
        sql, sql_params = _compile_filter(clause)
        where_clauses.append(sql)
        params.extend(sql_params)
        resolved_filters.append(dict(clause))

    group_by_clauses: list[str] = []
    resolved_group_bys: list[dict[str, Any]] = []
    if group_bys:
        seen_group_exprs: set[str] = set()
        for clause in group_bys:
            expr = _field_expression(entity=str(clause["entity"]), attribute=str(clause["attribute"]))
            if expr in seen_group_exprs:
                continue
            seen_group_exprs.add(expr)
            group_by_clauses.append(expr)
            resolved_group_bys.append(dict(clause))
    else:
        seen_group_exprs = set()
        for alias, expr in non_aggregate_group_aliases:
            if expr in seen_group_exprs:
                continue
            seen_group_exprs.add(expr)
            group_by_clauses.append(expr)
            resolved_group_bys.append(
                {
                    "entity": _entity_for_expression(expr),
                    "attribute": _attribute_for_expression(expr),
                    "alias": alias,
                }
            )

    order_by_clauses: list[str] = []
    resolved_sort_bys: list[dict[str, Any]] = []
    for clause in sort_bys:
        compiled = _compile_sort_by(clause)
        order_by_clauses.append(compiled["sql"])
        resolved_sort_bys.append(compiled["resolved"])

    params.append(limit)
    sql_lines = [
        "SELECT",
        "  " + ",\n  ".join(select_clauses),
        "FROM gateway_query_photo_v2 AS p",
    ]
    sql_lines.extend(joins)
    if where_clauses:
        sql_lines.append("WHERE " + "\n  AND ".join(where_clauses))
    if group_by_clauses:
        sql_lines.append("GROUP BY " + ", ".join(group_by_clauses))
    if order_by_clauses:
        sql_lines.append("ORDER BY " + ", ".join(order_by_clauses))
    sql_lines.append("LIMIT ?")

    resolved_plan = {
        "query_version": SUPPORTED_QUERY_VERSION,
        "anchor": dict(anchor),
        "select": resolved_selects,
        "filters": resolved_filters,
        "group_by": resolved_group_bys,
        "sort_by": resolved_sort_bys,
        "limit": limit,
    }
    return CompiledQuery(
        sql="\n".join(sql_lines),
        params=tuple(params),
        columns=columns,
        resolved_plan=resolved_plan,
        capabilities_used=sorted(capabilities_used),
    )


def _normalize_anchor(raw_anchor: Any) -> dict[str, str]:
    if not isinstance(raw_anchor, dict):
        raise QueryValidationError("`anchor` is required.")
    entity = raw_anchor.get("entity")
    if not isinstance(entity, str) or entity not in ENTITY_REGISTRY:
        raise QueryValidationError(f"Unsupported anchor entity `{entity}`.")
    return {"entity": entity}


def _normalize_selects(raw_selects: Any) -> list[dict[str, Any]]:
    if not isinstance(raw_selects, list) or not raw_selects:
        raise QueryValidationError("`select` must be a non-empty array.")
    return [_normalize_select(item) for item in raw_selects]


def _normalize_select(raw_select: Any) -> dict[str, Any]:
    if not isinstance(raw_select, dict):
        raise QueryValidationError("Each `select` item must be an object.")
    entity = _validate_entity(raw_select.get("entity"))
    attribute = _validate_attribute(entity, raw_select.get("attribute", "id"))
    aggregation = raw_select.get("aggregation")
    if aggregation is not None:
        if not isinstance(aggregation, str) or aggregation not in ALLOWED_AGGREGATIONS:
            raise QueryValidationError(f"Unsupported aggregation `{aggregation}` for select clause.")
    return {
        "entity": entity,
        "attribute": attribute,
        "aggregation": aggregation,
    }


def _normalize_filters(raw_filters: Any) -> list[dict[str, Any]]:
    if not isinstance(raw_filters, list):
        raise QueryValidationError("`filters` must be an array.")
    normalized: list[dict[str, Any]] = []
    for raw_filter in raw_filters:
        if not isinstance(raw_filter, dict):
            raise QueryValidationError("Each `filters` item must be an object.")
        entity = _validate_entity(raw_filter.get("entity"))
        attribute = _validate_attribute(entity, raw_filter.get("attribute"))
        operator = raw_filter.get("operator")
        if not isinstance(operator, str) or operator not in ALLOWED_OPERATORS:
            raise QueryValidationError(f"Unsupported operator `{operator}`.")
        if "value" not in raw_filter:
            raise QueryValidationError("Filter clauses must include `value`.")
        value = raw_filter.get("value")
        if operator == "in":
            if not isinstance(value, list) or not value:
                raise QueryValidationError("`in` operator requires a non-empty array value.")
        normalized.append(
            {
                "entity": entity,
                "attribute": attribute,
                "operator": operator,
                "value": value,
            }
        )
    return normalized


def _normalize_group_bys(raw_group_bys: Any) -> list[dict[str, str]]:
    if not isinstance(raw_group_bys, list):
        raise QueryValidationError("`group_by` must be an array.")
    normalized: list[dict[str, str]] = []
    for raw_group_by in raw_group_bys:
        if not isinstance(raw_group_by, dict):
            raise QueryValidationError("Each `group_by` item must be an object.")
        entity = _validate_entity(raw_group_by.get("entity"))
        attribute = _validate_attribute(entity, raw_group_by.get("attribute"))
        normalized.append({"entity": entity, "attribute": attribute})
    return normalized


def _normalize_sort_bys(raw_sort_bys: Any) -> list[dict[str, Any]]:
    if not isinstance(raw_sort_bys, list):
        raise QueryValidationError("`sort_by` must be an array.")
    normalized: list[dict[str, Any]] = []
    for raw_sort_by in raw_sort_bys:
        if not isinstance(raw_sort_by, dict):
            raise QueryValidationError("Each `sort_by` item must be an object.")
        entity = _validate_entity(raw_sort_by.get("entity"))
        attribute = _validate_attribute(entity, raw_sort_by.get("attribute", "id"))
        aggregation = raw_sort_by.get("aggregation")
        if aggregation is not None:
            if not isinstance(aggregation, str) or aggregation not in ALLOWED_AGGREGATIONS:
                raise QueryValidationError(f"Unsupported aggregation `{aggregation}` for sort_by clause.")
        order = raw_sort_by.get("order", "asc")
        if not isinstance(order, str) or order.lower() not in {"asc", "desc"}:
            raise QueryValidationError(f"Unsupported sort order `{order}`.")
        normalized.append(
            {
                "entity": entity,
                "attribute": attribute,
                "aggregation": aggregation,
                "order": order.lower(),
            }
        )
    return normalized


def _normalize_limit(raw_limit: Any) -> int:
    if isinstance(raw_limit, bool) or not isinstance(raw_limit, int):
        raise QueryValidationError("`limit` must be an integer.")
    if raw_limit < 1 or raw_limit > MAX_QUERY_LIMIT:
        raise QueryValidationError(f"`limit` must be between 1 and {MAX_QUERY_LIMIT}.")
    return raw_limit


def _validate_entity(value: Any) -> str:
    if not isinstance(value, str) or value not in ENTITY_REGISTRY:
        raise QueryValidationError(f"Unsupported entity `{value}`.")
    return value


def _validate_attribute(entity: str, value: Any) -> str:
    if not isinstance(value, str):
        raise QueryValidationError(f"Missing attribute for entity `{entity}`.")
    if value not in ENTITY_REGISTRY[entity]["attributes"]:
        raise QueryValidationError(f"Unsupported attribute `{value}` for entity `{entity}`.")
    return value


def _build_joins(*, involved_entities: set[str], filtered_entities: set[str]) -> list[str]:
    joins: list[str] = []
    for entity in sorted(involved_entities):
        join_condition = ENTITY_REGISTRY[entity]["join"]
        if join_condition is None:
            continue
        join_type = "INNER JOIN" if entity in filtered_entities else "LEFT JOIN"
        source = str(ENTITY_REGISTRY[entity].get("source") or f"gateway_query_{entity}_v1")
        joins.append(f"{join_type} {source} AS {entity} ON {join_condition}")
    return joins


def _compile_select(clause: dict[str, Any]) -> dict[str, Any]:
    entity = str(clause["entity"])
    attribute = str(clause["attribute"])
    aggregation = clause["aggregation"]
    expr = _field_expression(entity=entity, attribute=attribute)
    alias = _select_alias(entity=entity, attribute=attribute, aggregation=aggregation)
    if aggregation is None:
        return {
            "sql": f"{expr} AS {alias}",
            "alias": alias,
            "type": _column_type(entity=entity, attribute=attribute, aggregation=None),
            "group_expr": expr,
            "resolved": {
                "entity": entity,
                "attribute": attribute,
                "aggregation": None,
                "alias": alias,
            },
        }
    aggregate_expr = _aggregate_expression(expr=expr, aggregation=str(aggregation))
    return {
        "sql": f"{aggregate_expr} AS {alias}",
        "alias": alias,
        "type": _column_type(entity=entity, attribute=attribute, aggregation=str(aggregation)),
        "group_expr": None,
        "resolved": {
            "entity": entity,
            "attribute": attribute,
            "aggregation": aggregation,
            "alias": alias,
        },
    }


def _compile_filter(clause: dict[str, Any]) -> tuple[str, list[Any]]:
    expr = _field_expression(entity=str(clause["entity"]), attribute=str(clause["attribute"]))
    operator = str(clause["operator"])
    value = clause["value"]
    if operator == "contains":
        return f"{expr} LIKE ?", [f"%{value}%"]
    if operator == "in":
        values = list(value)
        placeholders = ", ".join("?" for _ in values)
        return f"{expr} IN ({placeholders})", values
    sql_operator = {"==": "="}.get(operator, operator)
    return f"{expr} {sql_operator} ?", [value]


def _compile_sort_by(clause: dict[str, Any]) -> dict[str, Any]:
    entity = str(clause["entity"])
    attribute = str(clause["attribute"])
    aggregation = clause["aggregation"]
    order = str(clause["order"]).upper()
    expr = _field_expression(entity=entity, attribute=attribute)
    if aggregation is None:
        order_expr = expr
    else:
        order_expr = _aggregate_expression(expr=expr, aggregation=str(aggregation))
    return {
        "sql": f"{order_expr} {order}",
        "resolved": {
            "entity": entity,
            "attribute": attribute,
            "aggregation": aggregation,
            "order": order.lower(),
        },
    }


def _field_expression(*, entity: str, attribute: str) -> str:
    return str(ENTITY_REGISTRY[entity]["attributes"][attribute])


def _aggregate_expression(*, expr: str, aggregation: str) -> str:
    if aggregation == "count":
        return f"COUNT(DISTINCT {expr})"
    if aggregation == "count_distinct":
        return f"COUNT(DISTINCT {expr})"
    if aggregation == "list":
        return f"GROUP_CONCAT(DISTINCT {expr})"
    if aggregation == "min":
        return f"MIN({expr})"
    if aggregation == "max":
        return f"MAX({expr})"
    raise QueryCompilationError(f"Unsupported aggregation `{aggregation}`.")


def _select_alias(*, entity: str, attribute: str, aggregation: str | None) -> str:
    if aggregation is None:
        if entity == "photo" and attribute == "id":
            return "photo_id"
        return f"{entity}_{attribute}"
    if aggregation == "count" and entity == "photo" and attribute == "id":
        return "photo_count"
    if aggregation == "count_distinct":
        return f"{entity}_{attribute}_count_distinct"
    return f"{entity}_{attribute}_{aggregation}"


def _column_type(*, entity: str, attribute: str, aggregation: str | None) -> str:
    if aggregation in {"count", "count_distinct"}:
        return "integer"
    if aggregation == "list":
        return "string"
    if aggregation in {"min", "max"}:
        if entity == "time":
            return "integer"
        return "string"
    if entity == "time":
        return "integer"
    return "string"


def _capability_for(entity: str) -> str:
    return str(ENTITY_REGISTRY[entity]["capability"])


def _entity_for_expression(expr: str) -> str:
    for entity, config in ENTITY_REGISTRY.items():
        for attribute_expr in config["attributes"].values():
            if attribute_expr == expr:
                return entity
    raise QueryCompilationError(f"Unable to resolve group_by entity for expression `{expr}`.")


def _attribute_for_expression(expr: str) -> str:
    for config in ENTITY_REGISTRY.values():
        for attribute, attribute_expr in config["attributes"].items():
            if attribute_expr == expr:
                return attribute
    raise QueryCompilationError(f"Unable to resolve group_by attribute for expression `{expr}`.")
