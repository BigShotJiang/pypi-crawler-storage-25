from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
import tarfile
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import hashlib

from eona.env_compat import compat_env

APP_NAME = "Eona"
RUNTIME_DIRNAME = "runtime"
REQUIRED_LAYOUT = ("runtime", "cache", "logs", "config", "socket")
MANIFEST_FILENAME = "manifest.json"
CONTRACT_MANIFEST_RELPATH = Path("contracts/runtime-manifest.json")
RELEASE_MANIFEST_RELPATH = Path("release/release-manifest.json")


@dataclass(frozen=True)
class RuntimePaths:
    root: Path
    runtime: Path
    cache: Path
    logs: Path
    config: Path
    socket: Path
    manifest: Path
    certs: Path
    ca_bundle: Path


def _app_support_root() -> Path:
    override = compat_env("EONA_HOME")
    if override:
        return Path(override).expanduser().resolve()
    return Path.home() / "Library" / "Application Support" / APP_NAME


def get_runtime_paths() -> RuntimePaths:
    root = _app_support_root()
    runtime = root / RUNTIME_DIRNAME
    return RuntimePaths(
        root=root,
        runtime=runtime,
        cache=root / "cache",
        logs=root / "logs",
        config=root / "config",
        socket=root / "socket",
        manifest=runtime / MANIFEST_FILENAME,
        certs=runtime / "certs",
        ca_bundle=runtime / "certs" / "ca-bundle.pem",
    )


def get_runtime_venv_python() -> Path:
    contract = load_contract()
    return _runtime_relative_path(get_runtime_paths(), contract["venv"]["python_executable_relative_path"])


def get_eona_cadis_cache_dir() -> Path:
    return get_runtime_paths().cache / "cadis"


def get_installed_runtime_manifest_hash() -> str | None:
    manifest_path = get_runtime_paths().manifest
    if not manifest_path.is_file():
        return None
    return _sha256_file(manifest_path)


def get_source_runtime_manifest_hash() -> str:
    return _sha256_file(_contract_source_path())


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _contract_source_path() -> Path:
    # Use the distribution manifest from the contracts directory
    return _repo_root() / "contracts" / "distribution-manifest.json"


def _resolve_contract_path(path_value: str | Path) -> Path:
    path = Path(path_value).expanduser()
    if path.is_absolute():
        return path
    return (_contract_source_path().parent.parent / path).resolve()


def load_contract() -> dict[str, Any]:
    return json.loads(_contract_source_path().read_text(encoding="utf-8"))


def _release_root_from_path(value: str | Path | None = None) -> Path:
    if value is not None:
        return Path(value).expanduser().resolve()
    configured = compat_env("EONA_RELEASE_ROOT")
    if configured:
        return Path(configured).expanduser().resolve()
    return Path.cwd().resolve()


def _release_manifest_path(release_root: Path) -> Path:
    return release_root / RELEASE_MANIFEST_RELPATH


def _ensure_layout(paths: RuntimePaths) -> list[str]:
    created = []
    for name in REQUIRED_LAYOUT:
        path = getattr(paths, name)
        if not path.exists():
            path.mkdir(parents=True, exist_ok=True)
            created.append(str(path))
    return created


def _runtime_relative_path(paths: RuntimePaths, relative_path: str) -> Path:
    return paths.root / relative_path


def _current_platform() -> tuple[str, str]:
    return platform.system().lower(), platform.machine().lower()


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _verify_file_source(source: dict[str, Any], label: str) -> tuple[bool, str | None]:
    source_path = source.get("path")
    if not source_path:
        return False, f"{label}: source path missing"
    path = _resolve_contract_path(source_path)
    if not path.is_file():
        return False, f"{label}: source file missing at {path}"
    expected_sha = source.get("sha256")
    if expected_sha:
        actual_sha = _sha256_file(path)
        if actual_sha != expected_sha:
            return False, f"{label}: sha256 mismatch for {path}"
    return True, None


def _make_executable(path: Path) -> None:
    mode = path.stat().st_mode
    path.chmod(mode | 0o111)


def _write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def _write_python_wrapper(script_path: Path, framework_dir: Path, target_binary: Path, *, set_pythonhome: bool) -> None:
    script_dir = script_path.parent
    version_dir = target_binary.parent.parent.name
    framework_parent_rel = os.path.relpath(framework_dir.parent, script_dir)
    target_binary_rel = os.path.relpath(target_binary, script_dir)
    python_home_rel = os.path.relpath(framework_dir / "Versions" / version_dir, script_dir)
    ca_bundle_rel = os.path.relpath(script_path.parents[2] / "certs" / "ca-bundle.pem", script_dir)
    native_libs_rel = os.path.relpath(script_path.parents[2] / "lib" / "vips", script_dir)
    lines = [
        "#!/usr/bin/env bash",
        "set -euo pipefail",
        'SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"',
        f'export DYLD_FRAMEWORK_PATH="${{SCRIPT_DIR}}/{framework_parent_rel}"',
        f'export DYLD_LIBRARY_PATH="${{SCRIPT_DIR}}/{native_libs_rel}${{DYLD_LIBRARY_PATH:+:${{DYLD_LIBRARY_PATH}}}}"',
        f'export SSL_CERT_FILE="${{SCRIPT_DIR}}/{ca_bundle_rel}"',
        f'export REQUESTS_CA_BUNDLE="${{SCRIPT_DIR}}/{ca_bundle_rel}"',
    ]
    if set_pythonhome:
        lines.append(f'export PYTHONHOME="${{SCRIPT_DIR}}/{python_home_rel}"')
    else:
        lines.append("unset PYTHONHOME || true")
    lines.append(f'exec "${{SCRIPT_DIR}}/{target_binary_rel}" "$@"')
    _write_text(script_path, "\n".join(lines) + "\n")
    script_path.chmod(0o755)


def _collect_python_packages(venv_python: Path) -> dict[str, str]:
    result = subprocess.run(
        [
            str(venv_python),
            "-c",
            (
                "import importlib.metadata, json; "
                "packages = {dist.metadata['Name'].lower(): dist.version "
                "for dist in importlib.metadata.distributions()}; "
                "print(json.dumps(packages, sort_keys=True))"
            ),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(result.stdout)


def _normalize_package_name(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def _format_package_list(packages: dict[str, str]) -> str:
    return ", ".join(f"{name}=={version}" for name, version in sorted(packages.items()))


def _copy_tree(source: Path, destination: Path) -> None:
    if destination.exists():
        shutil.rmtree(destination)
    shutil.copytree(source, destination, symlinks=True)


def _provision_runtime_ca_bundle(contract: dict[str, Any], runtime_paths: RuntimePaths) -> tuple[str, str]:
    ca_bundle = contract.get("ca_bundle")
    if not isinstance(ca_bundle, dict):
        raise RuntimeError("runtime contract missing ca_bundle")
    source = ca_bundle.get("source")
    if not isinstance(source, dict):
        raise RuntimeError("runtime contract ca_bundle source missing")
    source_path = source.get("path")
    if not isinstance(source_path, str) or not source_path:
        raise RuntimeError("runtime contract ca_bundle source path missing")
    source_bundle = _resolve_contract_path(source_path)
    if not source_bundle.is_file():
        raise RuntimeError(f"ca bundle source missing at {source_bundle}")
    version = ca_bundle.get("version")
    if not isinstance(version, str) or not version:
        raise RuntimeError("runtime contract ca_bundle version missing")
    runtime_paths.certs.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source_bundle, runtime_paths.ca_bundle)
    return version, _sha256_file(runtime_paths.ca_bundle)


def _otool_entries(path: Path, flag: str) -> list[str]:
    result = subprocess.run(
        ["otool", flag, str(path)],
        check=True,
        capture_output=True,
        text=True,
    )
    entries = []
    seen = set()
    for line in result.stdout.splitlines()[1:]:
        stripped = line.strip()
        if not stripped:
            continue
        entry = stripped.split(" (", 1)[0]
        if entry in seen:
            continue
        seen.add(entry)
        entries.append(entry)
    return entries


def _codesign_adhoc(path: Path) -> None:
    subprocess.run(
        ["codesign", "--force", "--sign", "-", str(path)],
        check=True,
        capture_output=True,
        text=True,
    )


def _relocate_embedded_python_install_names(framework_dir: Path, version: str) -> None:
    version_dir = framework_dir / "Versions" / version
    source_prefix = f"/Library/Frameworks/Python.framework/Versions/{version}"
    candidates: list[Path] = []
    seen_paths: set[Path] = set()

    def add_candidate(path: Path) -> None:
        if path in seen_paths or not path.is_file() or path.is_symlink():
            return
        seen_paths.add(path)
        candidates.append(path)

    add_candidate(version_dir / "Python")
    for child in (version_dir / "bin").glob("*"):
        add_candidate(child)
    for child in (version_dir / "lib").rglob("*"):
        if child.suffix in {".dylib", ".so"}:
            add_candidate(child)

    for path in candidates:
        updates: list[str] = []
        try:
            dylib_ids = _otool_entries(path, "-D")
        except subprocess.CalledProcessError:
            continue
        for dylib_id in dylib_ids:
            if dylib_id.startswith(source_prefix):
                relocated = version_dir / dylib_id.removeprefix(source_prefix).lstrip("/")
                updates.extend(["-id", f"@loader_path/{os.path.relpath(relocated, path.parent)}"])
        try:
            load_commands = _otool_entries(path, "-L")
        except subprocess.CalledProcessError:
            continue
        for dependency in load_commands:
            if dependency.startswith(source_prefix):
                relocated = version_dir / dependency.removeprefix(source_prefix).lstrip("/")
                updates.extend(["-change", dependency, f"@loader_path/{os.path.relpath(relocated, path.parent)}"])
        if updates:
            subprocess.run(
                ["install_name_tool", *updates, str(path)],
                check=True,
                capture_output=True,
                text=True,
            )
            _codesign_adhoc(path)


def _create_runtime_dirs(root: Path) -> RuntimePaths:
    runtime = root / RUNTIME_DIRNAME
    return RuntimePaths(
        root=root,
        runtime=runtime,
        cache=root / "cache",
        logs=root / "logs",
        config=root / "config",
        socket=root / "socket",
        manifest=runtime / MANIFEST_FILENAME,
        certs=runtime / "certs",
        ca_bundle=runtime / "certs" / "ca-bundle.pem",
    )


def _validate_contract(contract: dict[str, Any]) -> list[str]:
    errors = []
    expected_platform = contract["platform"]
    platform_os, platform_arch = _current_platform()
    if platform_os != expected_platform["os"] or platform_arch != expected_platform["arch"]:
        errors.append(
            f"platform mismatch: expected {expected_platform['os']}-{expected_platform['arch']} "
            f"but found {platform_os}-{platform_arch}"
        )

    python_source = contract["python"].get("source", {})
    ok, error = _verify_file_source(python_source, "python")
    if not ok and error:
        errors.append(error)

    for library in contract.get("native_libraries", []):
        ok, error = _verify_file_source(library.get("source", {}), library["name"])
        if not ok and error:
            errors.append(error)

    if "dataset_bundle" in contract:
        bundle = contract["dataset_bundle"]
        ok, error = _verify_file_source(bundle.get("source", {}), "dataset_bundle")
        if not ok and error:
            errors.append(error)

    if "gateway_manifest_template" in contract:
        template = contract["gateway_manifest_template"]
        ok, error = _verify_file_source(template.get("source", {}), "gateway_manifest_template")
        if not ok and error:
            errors.append(error)

    for package in contract.get("python_packages", []):
        source = package.get("source", {})
        source_type = source.get("type")
        if source_type == "unresolved":
            errors.append(f"python package {package['name']}: source is unresolved")
        elif source_type == "local-wheel":
            ok, error = _verify_file_source(source, package["name"])
            if not ok and error:
                errors.append(error)

    ca_bundle = contract.get("ca_bundle")
    if not isinstance(ca_bundle, dict):
        errors.append("ca_bundle missing from runtime contract")
    else:
        ok, error = _verify_file_source(ca_bundle.get("source", {}), "ca_bundle")
        if not ok and error:
            errors.append(error)

    return errors


def _provision_embedded_python(contract: dict[str, Any], runtime_paths: RuntimePaths, work_dir: Path) -> Path:
    python_source = _resolve_contract_path(contract["python"]["source"]["path"])
    expanded_dir = work_dir / "python-pkg"
    subprocess.run(
        ["pkgutil", "--expand-full", str(python_source), str(expanded_dir)],
        check=True,
        capture_output=True,
        text=True,
    )

    framework_payload = expanded_dir / "Python_Framework.pkg" / "Payload"
    framework_dir = runtime_paths.runtime / "python" / "Library" / "Frameworks" / "Python.framework"
    framework_dir.parent.mkdir(parents=True, exist_ok=True)
    _copy_tree(framework_payload, framework_dir)
    _relocate_embedded_python_install_names(framework_dir, ".".join(contract["python"]["version"].split(".")[:2]))

    version = contract["python"]["version"]
    major_minor = ".".join(version.split(".")[:2])

    bin_dir = runtime_paths.runtime / "python" / "bin"
    bin_dir.mkdir(parents=True, exist_ok=True)
    target_binary = framework_dir / "Versions" / major_minor / "bin" / f"python{major_minor}"
    _write_python_wrapper(bin_dir / f"python{major_minor}", framework_dir, target_binary, set_pythonhome=True)
    _write_python_wrapper(bin_dir / "python3", framework_dir, target_binary, set_pythonhome=True)

    return bin_dir / f"python{major_minor}"


def _provision_exiftool(contract: dict[str, Any], runtime_paths: RuntimePaths) -> None:
    binary = contract["binaries"][0]
    archive_path = _resolve_contract_path(binary["source"]["path"])
    install_dir = _runtime_relative_path(runtime_paths, binary["install_relative_path"])
    if install_dir.exists():
        shutil.rmtree(install_dir)
    install_dir.mkdir(parents=True, exist_ok=True)

    with tarfile.open(archive_path, "r:gz") as archive:
        members = archive.getmembers()
        top_levels = {member.name.split("/", 1)[0] for member in members if member.name}
        if len(top_levels) != 1:
            raise RuntimeError("exiftool archive layout is not deterministic")
        prefix = next(iter(top_levels))
        for member in members:
            relative = member.name[len(prefix):].lstrip("/")
            if not relative:
                continue
            member.name = relative
            archive.extract(member, path=install_dir, filter="data")

    executable = _runtime_relative_path(runtime_paths, binary["executable_relative_path"])
    _make_executable(executable)


def _provision_native_libraries(contract: dict[str, Any], runtime_paths: RuntimePaths) -> None:
    for library in contract.get("native_libraries", []):
        archive_path = _resolve_contract_path(library["source"]["path"])
        install_dir = _runtime_relative_path(runtime_paths, library["install_relative_path"])
        _extract_archive_hermetic(archive_path, install_dir)


def _provision_dataset_bundle(contract: dict[str, Any], runtime_paths: RuntimePaths) -> None:
    if "dataset_bundle" not in contract:
        return
    bundle = contract["dataset_bundle"]
    archive_path = _resolve_contract_path(bundle["source"]["path"])
    install_dir = _runtime_relative_path(runtime_paths, bundle["install_relative_path"])
    _extract_archive_hermetic(archive_path, install_dir)


def _provision_gateway_manifest_template(contract: dict[str, Any], runtime_paths: RuntimePaths) -> None:
    if "gateway_manifest_template" not in contract:
        return
    template = contract["gateway_manifest_template"]
    source_path = _resolve_contract_path(template["source"]["path"])
    target_path = _runtime_relative_path(runtime_paths, template["install_relative_path"])
    target_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source_path, target_path)


def _stamp_gateway_manifest_version(manifest_path: Path, *, eona_version: str) -> None:
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    payload["eona_version"] = eona_version
    manifest_path.write_text(json.dumps(payload, indent=2, sort_keys=False) + "\n", encoding="utf-8")


def _extract_archive_hermetic(archive_path: Path, install_dir: Path) -> None:
    if install_dir.exists():
        shutil.rmtree(install_dir)
    install_dir.mkdir(parents=True, exist_ok=True)

    with tarfile.open(archive_path, "r:gz") as archive:
        archive.extractall(path=install_dir, filter="data")
        # If the archive contains a single top-level directory, move its contents up.
        # Ignore macOS AppleDouble metadata files so packaged native bundles flatten correctly.
        for metadata_path in list(install_dir.iterdir()):
            if metadata_path.name.startswith("._"):
                metadata_path.unlink()
        extracted = list(install_dir.iterdir())
        if len(extracted) == 1 and extracted[0].is_dir():
            for item in extracted[0].iterdir():
                shutil.move(str(item), str(install_dir / item.name))
            extracted[0].rmdir()


def _rewrite_venv_launchers(contract: dict[str, Any], runtime_paths: RuntimePaths) -> None:
    version = contract["python"]["version"]
    major_minor = ".".join(version.split(".")[:2])
    framework_dir = runtime_paths.runtime / "python" / "Library" / "Frameworks" / "Python.framework"
    venv_bin = runtime_paths.runtime / "venv" / "bin"
    ca_bundle_rel = os.path.relpath(runtime_paths.ca_bundle, venv_bin)
    real_binary_target = Path(
        os.path.relpath(
            framework_dir / "Versions" / major_minor / "bin" / f"python{major_minor}",
            venv_bin,
        )
    )
    version_hidden = f".python{major_minor}.real"
    hidden_targets = {
        version_hidden: real_binary_target,
        ".python.real": Path(version_hidden),
        ".python3.real": Path(version_hidden),
    }
    for hidden_name, link_target in hidden_targets.items():
        hidden_path = venv_bin / hidden_name
        if hidden_path.exists() or hidden_path.is_symlink():
            hidden_path.unlink()
        hidden_path.symlink_to(link_target)

    for name in ("python", "python3", f"python{major_minor}"):
        path = venv_bin / name
        if path.exists() or path.is_symlink():
            path.unlink()
        _write_python_wrapper(path, framework_dir, venv_bin / f".{name}.real", set_pythonhome=False)

    for name in ("pip", "pip3", f"pip{major_minor}"):
        path = venv_bin / name
        if path.exists():
            original = path.read_text(encoding="utf-8")
            script_copy = path.with_name(f".{name}.script")
            _write_text(script_copy, original)
            script_copy.chmod(0o755)
            python_rel = os.path.relpath(venv_bin / "python", venv_bin)
            script_rel = os.path.relpath(script_copy, venv_bin)
            framework_rel = os.path.relpath(framework_dir.parent, venv_bin)
            launcher = [
                "#!/usr/bin/env bash",
                "set -euo pipefail",
                'SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"',
                f'export DYLD_FRAMEWORK_PATH="${{SCRIPT_DIR}}/{framework_rel}"',
                f'export SSL_CERT_FILE="${{SCRIPT_DIR}}/{ca_bundle_rel}"',
                f'export REQUESTS_CA_BUNDLE="${{SCRIPT_DIR}}/{ca_bundle_rel}"',
                "unset PYTHONHOME || true",
                f'exec "${{SCRIPT_DIR}}/{python_rel}" "${{SCRIPT_DIR}}/{script_rel}" "$@"',
            ]
            _write_text(path, "\n".join(launcher) + "\n")


def _provision_venv_and_packages(contract: dict[str, Any], runtime_paths: RuntimePaths, embedded_python: Path) -> None:
    venv_path = runtime_paths.runtime / "venv"
    if venv_path.exists():
        shutil.rmtree(venv_path)
    subprocess.run([str(embedded_python), "-m", "venv", str(venv_path)], check=True, capture_output=True, text=True)
    _rewrite_venv_launchers(contract, runtime_paths)

    pip_path = venv_path / "bin" / "pip"
    for package in contract.get("python_packages", []):
        source = package.get("source", {})
        if source.get("type") == "embedded":
            continue
        if source.get("type") != "local-wheel":
            raise RuntimeError(f"unsupported python package source for {package['name']}")
        wheel_path = _resolve_contract_path(source["path"])
        install_command = [str(pip_path), "install", "--no-deps"]
        install_command.append(str(wheel_path))
        subprocess.run(
            install_command,
            check=True,
            capture_output=True,
            text=True,
        )


def bootstrap_runtime(force: bool = False) -> dict[str, Any]:
    paths = get_runtime_paths()
    contract = load_contract()
    validation_errors = _validate_contract(contract)
    if validation_errors:
        return {
            "ok": False,
            "summary": "Eona runtime bootstrap failed.",
            "details": validation_errors,
        }

    root_created = []
    for name in REQUIRED_LAYOUT:
        target = getattr(paths, name)
        if not target.exists():
            target.mkdir(parents=True, exist_ok=True)
            root_created.append(str(target))

    stage_root = Path(tempfile.mkdtemp(prefix="eona-bootstrap-", dir=str(paths.root)))
    stage_paths = _create_runtime_dirs(stage_root)

    details = []
    try:
        _ensure_layout(stage_paths)
        embedded_python = _provision_embedded_python(contract, stage_paths, stage_root)
        certifi_version, ca_bundle_sha = _provision_runtime_ca_bundle(contract, stage_paths)
        _provision_exiftool(contract, stage_paths)
        _provision_native_libraries(contract, stage_paths)
        _provision_dataset_bundle(contract, stage_paths)
        _provision_gateway_manifest_template(contract, stage_paths)
        _provision_venv_and_packages(contract, stage_paths, embedded_python)
        shutil.copyfile(_contract_source_path(), stage_paths.manifest)

        if paths.runtime.exists():
            shutil.rmtree(paths.runtime)
        shutil.move(str(stage_paths.runtime), str(paths.runtime))
    except Exception as exc:
        shutil.rmtree(stage_root, ignore_errors=True)
        return {
            "ok": False,
            "summary": "Eona runtime bootstrap failed.",
            "details": [str(exc)],
        }
    finally:
        shutil.rmtree(stage_root, ignore_errors=True)

    if root_created:
        details.append(f"Created {len(root_created)} runtime directories under {paths.root}.")
    else:
        details.append(f"Runtime directory layout already present under {paths.root}.")
    details.append(f"Provisioned embedded Python {contract['python']['version']}.")
    details.append(f"Provisioned embedded {contract['binaries'][0]['name']} {contract['binaries'][0]['version']}.")
    try:
        provisioned_packages = _collect_python_packages(paths.runtime / "venv" / "bin" / "python")
    except subprocess.CalledProcessError:
        provisioned_packages = {
            _normalize_package_name(package["name"]): package["version"]
            for package in contract.get("python_packages", [])
        }
    details.append(f"Provisioned python packages: {_format_package_list(provisioned_packages)}.")
    details.append(f"Provisioned CA bundle {certifi_version} ({ca_bundle_sha}).")
    details.append(f"Wrote static runtime contract to {paths.manifest}.")

    return {
        "ok": True,
        "summary": "Eona runtime bootstrap completed.",
        "details": details,
        "paths": {
            **{name: str(getattr(paths, name)) for name in REQUIRED_LAYOUT},
            "manifest": str(paths.manifest),
        },
    }


def assemble_macos_release_tree(
    *,
    release_root: str | Path,
    force: bool = False,
    release_version: str | None = None,
) -> dict[str, Any]:
    from eona.gateway_runtime import write_gateway_runtime_manifest

    target_root = Path(release_root).expanduser().resolve()
    contract = load_contract()
    validation_errors = _validate_contract(contract)
    if validation_errors:
        return {
            "ok": False,
            "summary": "Eona macOS release assembly failed.",
            "details": validation_errors,
        }

    if target_root.exists() and any(target_root.iterdir()):
        if not force:
            return {
                "ok": False,
                "summary": "Eona macOS release assembly failed.",
                "details": [f"Release root is not empty: {target_root}"],
            }
        shutil.rmtree(target_root)
    target_root.mkdir(parents=True, exist_ok=True)

    stage_root = Path(tempfile.mkdtemp(prefix="eona-release-", dir=str(target_root.parent)))
    stage_paths = _create_runtime_dirs(stage_root)
    details: list[str] = []
    try:
        _ensure_layout(stage_paths)
        embedded_python = _provision_embedded_python(contract, stage_paths, stage_root)
        certifi_version, ca_bundle_sha = _provision_runtime_ca_bundle(contract, stage_paths)
        _provision_exiftool(contract, stage_paths)
        _provision_native_libraries(contract, stage_paths)
        _provision_dataset_bundle(contract, stage_paths)
        _provision_gateway_manifest_template(contract, stage_paths)
        _provision_venv_and_packages(contract, stage_paths, embedded_python)
        shutil.copyfile(_contract_source_path(), stage_paths.manifest)

        # `runtime/` is the sealed runtime boundary. The release builder assembles
        # it ahead of time so host setup never has to mutate runtime contents.
        runtime_target = target_root / "runtime"
        if runtime_target.exists():
            shutil.rmtree(runtime_target)
        shutil.move(str(stage_paths.runtime), str(runtime_target))
        if release_version:
            _stamp_gateway_manifest_version(
                runtime_target / "metadata" / "runtime-manifest-template.json",
                eona_version=release_version,
            )

        # `app/` is shipped as immutable release payload, but runtime validation
        # must not depend on its contents for runtime identity.
        app_root = target_root / "app"
        app_root.mkdir(parents=True, exist_ok=True)
        shutil.copytree(_repo_root() / "src", app_root / "src", dirs_exist_ok=True)
        shutil.copytree(_repo_root() / "contracts", app_root / "contracts", dirs_exist_ok=True)

        bin_dir = target_root / "bin"
        bin_dir.mkdir(parents=True, exist_ok=True)
        eona_launcher = bin_dir / "eona"
        eona_launcher.write_text(
            "\n".join(
                [
                    "#!/usr/bin/env bash",
                    "set -euo pipefail",
                    'RELEASE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"',
                    'export EONA_RELEASE_ROOT="${RELEASE_ROOT}"',
                    'export EONA_GATEWAY_IMAGE_ROOT="${EONA_GATEWAY_IMAGE_ROOT:-${RELEASE_ROOT}}"',
                    'export EONA_WORKSPACE="${EONA_WORKSPACE:-${PWD}}"',
                    'export PYTHONPATH="${RELEASE_ROOT}/app/src${PYTHONPATH:+:${PYTHONPATH}}"',
                    'if [[ -d "${RELEASE_ROOT}/runtime/lib/vips" ]]; then',
                    '  export DYLD_LIBRARY_PATH="${RELEASE_ROOT}/runtime/lib/vips${DYLD_LIBRARY_PATH:+:${DYLD_LIBRARY_PATH}}"',
                    "fi",
                    'exec "${RELEASE_ROOT}/runtime/venv/bin/python" -m eona "$@"',
                    "",
                ]
            ),
            encoding="utf-8",
        )
        eona_launcher.chmod(0o755)

        client_launcher = bin_dir / "eona-client"
        client_launcher.write_text(
            "\n".join(
                [
                    "#!/usr/bin/env bash",
                    "set -euo pipefail",
                    'RELEASE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"',
                    'export EONA_RELEASE_ROOT="${RELEASE_ROOT}"',
                    'export EONA_GATEWAY_IMAGE_ROOT="${EONA_GATEWAY_IMAGE_ROOT:-${RELEASE_ROOT}}"',
                    'EONA_HOME_DEFAULT="${HOME}/Library/Application Support/Eona"',
                    'export EONA_HOME="${EONA_HOME:-${EONA_HOME_DEFAULT}}"',
                    'export EONA_GATEWAY_HOME="${EONA_GATEWAY_HOME:-${EONA_HOME}/gateway}"',
                    'export PYTHONPATH="${RELEASE_ROOT}/app/src${PYTHONPATH:+:${PYTHONPATH}}"',
                    'if [[ -d "${RELEASE_ROOT}/runtime/lib/vips" ]]; then',
                    '  export DYLD_LIBRARY_PATH="${RELEASE_ROOT}/runtime/lib/vips${DYLD_LIBRARY_PATH:+:${DYLD_LIBRARY_PATH}}"',
                    "fi",
                    'exec "${RELEASE_ROOT}/runtime/venv/bin/python" -m eona.client_cli "$@"',
                    "",
                ]
            ),
            encoding="utf-8",
        )
        client_launcher.chmod(0o755)

        gateway_launcher = bin_dir / "eona-gateway"
        gateway_launcher.write_text(
            "\n".join(
                [
                    "#!/usr/bin/env bash",
                    "set -euo pipefail",
                    'RELEASE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"',
                    'export EONA_RELEASE_ROOT="${RELEASE_ROOT}"',
                    'export EONA_GATEWAY_IMAGE_ROOT="${EONA_GATEWAY_IMAGE_ROOT:-${RELEASE_ROOT}}"',
                    'EONA_HOME_DEFAULT="${HOME}/Library/Application Support/Eona"',
                    'export EONA_HOME="${EONA_HOME:-${EONA_HOME_DEFAULT}}"',
                    'export EONA_GATEWAY_HOME="${EONA_GATEWAY_HOME:-${EONA_HOME}/gateway}"',
                    'export EONA_GATEWAY_RUNTIME_STRICT="${EONA_GATEWAY_RUNTIME_STRICT:-1}"',
                    'export EONA_GATEWAY_ALLOW_NONLOCAL_BIND="${EONA_GATEWAY_ALLOW_NONLOCAL_BIND:-0}"',
                    'export EONA_GATEWAY_REQUIRE_ACCESS_TOKEN="${EONA_GATEWAY_REQUIRE_ACCESS_TOKEN:-1}"',
                    'export PYTHONPATH="${RELEASE_ROOT}/app/src${PYTHONPATH:+:${PYTHONPATH}}"',
                    'if [[ -d "${RELEASE_ROOT}/runtime/lib/vips" ]]; then',
                    '  export DYLD_LIBRARY_PATH="${RELEASE_ROOT}/runtime/lib/vips${DYLD_LIBRARY_PATH:+:${DYLD_LIBRARY_PATH}}"',
                    "fi",
                    'PYTHON_BIN="${RELEASE_ROOT}/runtime/venv/bin/python"',
                    'if [[ "${1:-}" == "serve" ]]; then',
                    '  shift',
                    '  CLEANUP_OLDER_THAN_HOURS="${EONA_GATEWAY_CLEANUP_ABANDONED_HOURS:-24}"',
                    '  TERMINAL_DATA_CLEANUP_OLDER_THAN_HOURS="${EONA_GATEWAY_CLEANUP_TERMINAL_DATA_HOURS:-72}"',
                    '  "${PYTHON_BIN}" -m eona.gateway_cli check-runtime',
                    '  "${PYTHON_BIN}" -m eona.gateway_cli init-db',
                    '  if ! "${PYTHON_BIN}" -m eona.gateway_cli cleanup-abandoned --older-than-hours "${CLEANUP_OLDER_THAN_HOURS}"; then',
                    '    echo "warning: startup abandoned-upload cleanup failed; continuing with normal startup" >&2',
                    "  fi",
                    '  if ! "${PYTHON_BIN}" -m eona.gateway_cli cleanup-terminal-data --older-than-hours "${TERMINAL_DATA_CLEANUP_OLDER_THAN_HOURS}"; then',
                    '    echo "warning: startup terminal-data cleanup failed; continuing with normal startup" >&2',
                    "  fi",
                    '  if ! "${PYTHON_BIN}" -m eona.gateway_cli apply-runtime-upgrades; then',
                    '    echo "warning: startup runtime-upgrade application failed; continuing with normal startup" >&2',
                    "  fi",
                    '  exec "${PYTHON_BIN}" -m eona.gateway_cli serve "$@"',
                    "fi",
                    'exec "${PYTHON_BIN}" -m eona.gateway_cli "$@"',
                    "",
                ]
            ),
            encoding="utf-8",
        )
        gateway_launcher.chmod(0o755)

        write_gateway_runtime_manifest(
            image_root=target_root,
            force=True,
            template_path=runtime_target / "metadata" / "runtime-manifest-template.json",
            eona_version_override=release_version,
        )
        details.append(f"Assembled sealed runtime under {runtime_target}.")
        details.append(f"Copied application sources into {app_root}.")
        details.append(f"Wrote local workspace launcher to {eona_launcher}.")
        details.append(f"Wrote client launcher to {client_launcher}.")
        details.append(f"Wrote gateway launcher to {gateway_launcher}.")
        details.append(f"Provisioned CA bundle {certifi_version} ({ca_bundle_sha}).")
    except Exception as exc:
        shutil.rmtree(target_root, ignore_errors=True)
        return {
            "ok": False,
            "summary": "Eona macOS release assembly failed.",
            "details": [str(exc)],
        }
    finally:
        shutil.rmtree(stage_root, ignore_errors=True)

    return {
        "ok": True,
        "summary": "Eona macOS release assembly completed.",
        "details": details,
        "paths": {
            "release_root": str(target_root),
            "local_launcher": str(target_root / "bin" / "eona"),
            "client_launcher": str(target_root / "bin" / "eona-client"),
            "gateway_launcher": str(target_root / "bin" / "eona-gateway"),
            "runtime_root": str(target_root / "runtime"),
        },
    }


def setup_release(*, release_root: str | Path | None = None, force: bool = False) -> dict[str, Any]:
    from eona.gateway_runtime import inspect_gateway_runtime
    from eona.gateway_schema import initialize_gateway_storage

    resolved_release_root = _release_root_from_path(release_root)
    details: list[str] = []
    errors: list[str] = []

    for required_path in (
        resolved_release_root / "bin" / "eona",
        resolved_release_root / "app" / "src",
        resolved_release_root / "runtime",
        resolved_release_root / "runtime" / "metadata" / "runtime-manifest.json",
    ):
        if not required_path.exists():
            errors.append(f"release content missing at {required_path}")

    # `release-manifest.json` describes the artifact. Runtime validation remains
    # anchored to `runtime/metadata/runtime-manifest.json`.
    manifest_path = _release_manifest_path(resolved_release_root)
    if manifest_path.is_file():
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
        files = payload.get("files")
        if isinstance(files, dict):
            for relpath, metadata in files.items():
                if not isinstance(relpath, str) or not isinstance(metadata, dict):
                    continue
                candidate = resolved_release_root / relpath
                if not candidate.is_file():
                    errors.append(f"release file missing at {candidate}")
                    continue
                expected_sha = metadata.get("sha256")
                if isinstance(expected_sha, str) and expected_sha and _sha256_file(candidate) != expected_sha:
                    errors.append(f"release file sha256 mismatch at {candidate}")
        runtime_manifest = payload.get("runtime_manifest")
        if isinstance(runtime_manifest, dict):
            runtime_manifest_relpath = runtime_manifest.get("path")
            runtime_manifest_sha = runtime_manifest.get("sha256")
            if isinstance(runtime_manifest_relpath, str) and runtime_manifest_relpath:
                runtime_manifest_path = resolved_release_root / runtime_manifest_relpath
                if not runtime_manifest_path.is_file():
                    errors.append(f"runtime manifest missing at {runtime_manifest_path}")
                elif isinstance(runtime_manifest_sha, str) and runtime_manifest_sha:
                    if _sha256_file(runtime_manifest_path) != runtime_manifest_sha:
                        errors.append(
                            f"runtime manifest sha256 mismatch at {runtime_manifest_path}"
                        )
        details.append(f"Verified release manifest at {manifest_path}.")

    if errors:
        return {
            "ok": False,
            "summary": "Eona setup failed.",
            "details": errors,
        }

    previous_env = {
        "EONA_RELEASE_ROOT": os.environ.get("EONA_RELEASE_ROOT"),
        "EONA_GATEWAY_IMAGE_ROOT": os.environ.get("EONA_GATEWAY_IMAGE_ROOT"),
        "EONA_HOME": os.environ.get("EONA_HOME"),
        "EONA_GATEWAY_HOME": os.environ.get("EONA_GATEWAY_HOME"),
    }
    eona_home = Path(previous_env["EONA_HOME"]).expanduser().resolve() if previous_env["EONA_HOME"] else _app_support_root()
    try:
        os.environ["EONA_RELEASE_ROOT"] = str(resolved_release_root)
        os.environ["EONA_GATEWAY_IMAGE_ROOT"] = str(resolved_release_root)
        os.environ["EONA_HOME"] = str(eona_home)
        os.environ.setdefault("EONA_GATEWAY_HOME", str(eona_home / "gateway"))
        details.append(f"Using immutable release root {resolved_release_root}.")
        details.append(f"Using mutable Eona home {eona_home}.")

        init_result = initialize_gateway_storage(force=force)
        details.extend(str(item) for item in init_result.get("details", []))

        runtime_result = inspect_gateway_runtime(strict=True)
        if not bool(runtime_result.get("ok")):
            return {
                "ok": False,
                "summary": "Eona setup failed.",
                "details": details + list(runtime_result.get("details", [])),
            }
        details.append("Gateway runtime validation passed against the unpacked release.")
        details.append("Next step: ./bin/eona-gateway serve")
    finally:
        for name, original in previous_env.items():
            if original is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = original

    return {
        "ok": True,
        "summary": "Eona setup completed.",
        "details": details,
        "paths": {
            "release_root": str(resolved_release_root),
            "eona_home": str(eona_home),
            "gateway_home": str((eona_home / "gateway").resolve()),
        },
    }


def check_runtime() -> dict[str, Any]:
    paths = get_runtime_paths()
    source_contract = load_contract()
    details = []
    errors = []

    for name in REQUIRED_LAYOUT:
        path = getattr(paths, name)
        if path.is_dir():
            details.append(f"{name}: present")
        else:
            errors.append(f"{name}: missing at {path}")

    if paths.manifest.is_file():
        installed_contract = _read_json(paths.manifest)
        if installed_contract == source_contract:
            details.append("manifest: present and matches source contract")
        else:
            errors.append(f"manifest: installed contract at {paths.manifest} does not match source contract")
    else:
        errors.append(f"manifest: missing at {paths.manifest}")

    platform_os, platform_arch = _current_platform()
    expected_platform = source_contract["platform"]
    if platform_os == expected_platform["os"] and platform_arch == expected_platform["arch"]:
        details.append(f"platform: {platform_os}-{platform_arch}")
    else:
        errors.append(
            "platform: expected "
            f"{expected_platform['os']}-{expected_platform['arch']} "
            f"but found {platform_os}-{platform_arch}"
        )

    embedded_python = _runtime_relative_path(paths, source_contract["python"]["executable_relative_path"])
    if embedded_python.is_file():
        details.append(f"embedded python: present at {embedded_python}")
        try:
            version_output = subprocess.run(
                [str(embedded_python), "-c", "import platform; print(platform.python_version())"],
                check=True,
                capture_output=True,
                text=True,
            )
            actual_version = version_output.stdout.strip()
            if actual_version == source_contract["python"]["version"]:
                details.append(f"embedded python version: {actual_version}")
            else:
                errors.append(
                    f"embedded python version: expected {source_contract['python']['version']} but found {actual_version}"
                )
        except subprocess.CalledProcessError as exc:
            errors.append(f"embedded python: unable to execute ({exc})")
    else:
        errors.append(f"embedded python: missing at {embedded_python}")

    venv_python = _runtime_relative_path(paths, source_contract["venv"]["python_executable_relative_path"])
    if venv_python.is_file():
        details.append(f"venv python: present at {venv_python}")
        try:
            installed_packages = _collect_python_packages(venv_python)
        except subprocess.CalledProcessError as exc:
            errors.append(f"python packages: unable to inspect runtime venv ({exc})")
        else:
            expected_packages = {
                _normalize_package_name(package["name"]): package["version"]
                for package in source_contract.get("python_packages", [])
                if package.get("source", {}).get("type") != "embedded"
            }
            embedded_packages = {
                _normalize_package_name(package["name"])
                for package in source_contract.get("python_packages", [])
                if package.get("source", {}).get("type") == "embedded"
            }
            normalized_installed_packages = {
                _normalize_package_name(name): version for name, version in installed_packages.items()
            }
            if normalized_installed_packages == expected_packages:
                details.append(f"python packages: exact managed-package match ({_format_package_list(expected_packages)})")
            else:
                missing = sorted(name for name in expected_packages if name not in normalized_installed_packages)
                mismatched = sorted(
                    name
                    for name, version in expected_packages.items()
                    if normalized_installed_packages.get(name) not in (None, version)
                )
                extras = sorted(
                    name
                    for name in normalized_installed_packages
                    if name not in expected_packages and name not in embedded_packages
                )
                if missing:
                    errors.append(f"python packages: missing required packages: {', '.join(missing)}")
                if mismatched:
                    errors.append(f"python packages: version mismatch for: {', '.join(mismatched)}")
                if extras:
                    errors.append(f"python packages: unexpected installed packages: {', '.join(extras)}")
    else:
        errors.append(f"venv python: missing at {venv_python}")

    for binary in source_contract.get("binaries", []):
        binary_path = _runtime_relative_path(paths, binary["executable_relative_path"])
        if binary_path.is_file() and os.access(binary_path, os.X_OK):
            details.append(f"{binary['name']}: present at {binary_path}")
            try:
                version_output = subprocess.run(
                    [str(binary_path), "-ver"],
                    check=True,
                    capture_output=True,
                    text=True,
                )
                first_line = version_output.stdout.strip().splitlines()[0].strip()
                if binary["version"] in first_line:
                    details.append(f"{binary['name']} version: {binary['version']}")
                else:
                    errors.append(f"{binary['name']} version: expected {binary['version']} but saw '{first_line}'")
            except subprocess.CalledProcessError as exc:
                errors.append(f"{binary['name']}: unable to execute ({exc})")
        else:
            errors.append(f"{binary['name']}: missing executable at {binary_path}")

    for library in source_contract.get("native_libraries", []):
        install_dir = _runtime_relative_path(paths, library["install_relative_path"])
        if install_dir.is_dir():
            details.append(f"native library {library['name']}: present at {install_dir}")
        else:
            errors.append(f"native library {library['name']}: missing at {install_dir}")

    if "dataset_bundle" in source_contract:
        bundle = source_contract["dataset_bundle"]
        install_dir = _runtime_relative_path(paths, bundle["install_relative_path"])
        if install_dir.is_dir():
            details.append(f"dataset bundle: present at {install_dir}")
        else:
            errors.append(f"dataset bundle: missing at {install_dir}")

    if "gateway_manifest_template" in source_contract:
        template = source_contract["gateway_manifest_template"]
        target_path = _runtime_relative_path(paths, template["install_relative_path"])
        if target_path.is_file():
            details.append(f"gateway manifest template: present at {target_path}")
        else:
            errors.append(f"gateway manifest template: missing at {target_path}")

    ok = not errors
    summary = "Eona runtime check passed." if ok else "Eona runtime check failed."
    return {"ok": ok, "summary": summary, "details": details + errors}
