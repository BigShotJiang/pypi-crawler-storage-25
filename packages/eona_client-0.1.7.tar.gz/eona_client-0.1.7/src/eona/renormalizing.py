from __future__ import annotations

import json
import logging
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from eona.cadis_adapter import (
    CadisAdapter,
    CadisCapabilitySnapshot as AdapterCadisCapabilitySnapshot,
    parse_version_tuple,
)
from eona.indexing import (
    IndexingObserver,
    NoopObserver,
    NormalizedLocation,
    PauseRequested,
    StopRequested,
)
from eona.storage import _connect_database


@dataclass(frozen=True)
class RenormCandidate:
    content_id: int
    raw_latitude: float
    raw_longitude: float


@dataclass(frozen=True)
class RenormSelection:
    candidates: tuple[RenormCandidate, ...]
    summary: dict[str, Any]


class Renormalizer:
    def __init__(
        self,
        *,
        normalizer: Any,
        adapter: CadisAdapter | None = None,
        batch_size: int = 100,
        logger: logging.Logger | None = None,
    ) -> None:
        self.normalizer = normalizer
        self.adapter = adapter or CadisAdapter()
        self.batch_size = batch_size
        self.logger = logger or logging.getLogger(__name__)

    def run(
        self,
        *,
        database_path: Path,
        frozen_capability: AdapterCadisCapabilitySnapshot | None = None,
        frozen_cadis_version: str | None = None,
        installed_iso2: tuple[str, ...] = (),
        observer: IndexingObserver | None = None,
        root_paths: tuple[Path, ...] | None = None,
        snapshot_version: int | None = None,
    ) -> dict[str, Any]:
        observer = observer or NoopObserver()
        frozen_capability = frozen_capability or AdapterCadisCapabilitySnapshot(
            cadis_version=str(frozen_cadis_version or ""),
            ready_iso2=tuple(sorted(installed_iso2)),
            supported_iso2=tuple(sorted(installed_iso2)),
            dataset_lockdown_enabled=False,
            allowed_iso2=(),
        )
        with _connect_database(database_path) as connection:
            connection.create_function(
                "cadis_version_lt",
                2,
                lambda stored, frozen: int(parse_version_tuple(stored) < parse_version_tuple(frozen)),
                deterministic=True,
            )
            selection = self._select_candidates(
                connection=connection,
                frozen_capability=frozen_capability,
                root_paths=root_paths,
            )
            observer.set_selection_summary(selection.summary)
            observer.set_total(int(selection.summary["total_estimated"]))
            observer.set_state("SELECTING")

            processed = 0
            min_content_id: int | None = None
            max_content_id: int | None = None
            for offset in range(0, len(selection.candidates), self.batch_size):
                action = observer.check_control()
                if action == "pause":
                    raise PauseRequested
                if action == "stop":
                    raise StopRequested
                batch = selection.candidates[offset : offset + self.batch_size]
                connection.execute("BEGIN")
                try:
                    for candidate in batch:
                        observer.set_state("NORMALIZING", current_content_id=candidate.content_id)
                        self._process_candidate(
                            connection=connection,
                            candidate=candidate,
                            observer=observer,
                            snapshot_version=snapshot_version,
                        )
                        processed += 1
                        min_content_id = candidate.content_id if min_content_id is None else min(min_content_id, candidate.content_id)
                        max_content_id = candidate.content_id if max_content_id is None else max(max_content_id, candidate.content_id)
                        observer.advance(current_content_id=candidate.content_id)
                    observer.set_state(
                        "WRITING_DB",
                        current_content_id=batch[-1].content_id if batch else None,
                    )
                    connection.commit()
                except Exception:
                    connection.rollback()
                    raise

        return {
            "processed": processed,
            "total_estimated": int(selection.summary["total_estimated"]),
            "selection_summary": {
                **selection.summary,
                "processed_content_id_span": (
                    None
                    if min_content_id is None or max_content_id is None
                    else {"min": min_content_id, "max": max_content_id}
                ),
            },
        }

    def _select_candidates(
        self,
        *,
        connection: sqlite3.Connection,
        frozen_capability: AdapterCadisCapabilitySnapshot,
        root_paths: tuple[Path, ...] | None,
    ) -> RenormSelection:
        selection_plan = self.adapter.build_renorm_selection_plan(
            frozen_capability=frozen_capability,
            batch_size=self.batch_size,
            force_on_engine_upgrade=True,
        )
        membership_sql, membership_params = self._root_membership_sql(root_paths=root_paths)
        count_query = (
            "SELECT COUNT(*) AS count FROM image_location "
            f"WHERE ({selection_plan.where_sql}) AND ({membership_sql})"
        )
        total_estimated = int(
            connection.execute(count_query, [*selection_plan.params, *membership_params]).fetchone()["count"]
        )
        rows = connection.execute(
            f"""
            SELECT content_id, raw_latitude, raw_longitude
            FROM image_location
            WHERE ({selection_plan.where_sql}) AND ({membership_sql})
            ORDER BY content_id ASC
            """,
            [*selection_plan.params, *membership_params],
        ).fetchall()

        candidates = tuple(
            RenormCandidate(
                content_id=int(row["content_id"]),
                raw_latitude=float(row["raw_latitude"]),
                raw_longitude=float(row["raw_longitude"]),
            )
            for row in rows
        )
        selection_summary = dict(selection_plan.summary)
        selection_summary["total_estimated"] = total_estimated
        return RenormSelection(candidates=candidates, summary=selection_summary)

    def _process_candidate(
        self,
        *,
        connection: sqlite3.Connection,
        candidate: RenormCandidate,
        observer: IndexingObserver,
        snapshot_version: int | None,
    ) -> None:
        try:
            normalized = self.normalizer.normalize(candidate.raw_latitude, candidate.raw_longitude)
        except Exception as exc:
            self._warning(observer, candidate.content_id, "normalize_failed", exc)
            return

        if normalized.detail:
            self._warning(observer, candidate.content_id, "normalize_detail", normalized.detail)

        self._write_result(
            connection=connection,
            content_id=candidate.content_id,
            normalized=normalized,
            snapshot_version=snapshot_version,
        )

    @staticmethod
    def _write_result(
        *,
        connection: sqlite3.Connection,
        content_id: int,
        normalized: NormalizedLocation,
        snapshot_version: int | None,
    ) -> None:
        connection.execute(
            """
            UPDATE image_location
            SET cadis_result_json = ?, cadis_version = ?, last_processed_snapshot_version = ?
            WHERE content_id = ?
            """,
            (normalized.cadis_result_json, normalized.cadis_version, snapshot_version, content_id),
        )

    def _warning(self, observer: IndexingObserver, content_id: int, kind: str, error: Exception | str) -> None:
        detail = str(error)
        message = json.dumps(
            {
                "level": "warning",
                "type": kind,
                "content_id": content_id,
                "error": detail,
            },
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        self.logger.warning(message)
        observer.warning(message)

    @staticmethod
    def _root_membership_sql(*, root_paths: tuple[Path, ...] | None) -> tuple[str, list[str]]:
        if not root_paths:
            return (
                "EXISTS (SELECT 1 FROM files WHERE files.content_id = image_location.content_id AND files.missing = 0)",
                [],
            )

        path_clauses: list[str] = []
        params: list[str] = []
        for root_path in root_paths:
            normalized = str(root_path.resolve())
            path_clauses.append("(files.file_path = ? OR files.file_path LIKE ?)")
            params.extend([normalized, f"{normalized}/%"])
        membership_sql = (
            "EXISTS (SELECT 1 FROM files "
            "WHERE files.content_id = image_location.content_id "
            "AND files.missing = 0 "
            f"AND ({' OR '.join(path_clauses)}))"
        )
        return membership_sql, params
