from __future__ import annotations

import json
import logging
import sqlite3
from pathlib import Path
from typing import Any

from eona.artifact_validation import read_ndjson
from eona.errors import EonaCliError
from eona.exiftool_adapter import ExiftoolCapabilitySnapshot, ExiftoolMetadataExtractor
from eona.gateway_runtime import load_gateway_runtime_manifest, resolve_gateway_exiftool_path
from eona.gateway_runs import ensure_run_layout, read_json
from eona.indexing import CadisRuntimeNormalizer
from eona.stages import is_supported_photo_file, write_ndjson

logger = logging.getLogger(__name__)

PIPELINE_STAGES = (
    "SCANNING",
    "METADATA_EXTRACTION",
    "CADIS_LOOKUP",
    "SQLITE_WRITE",
)


def _manifest_input_path(*, root_dir: Path, item: dict[str, Any]) -> Path:
    input_path = item.get("input_path")
    if isinstance(input_path, str) and input_path:
        return Path(input_path)
    return root_dir / str(item["input_relpath"])


class GatewayPipelineRunner:
    def __init__(
        self,
        *,
        service: "GatewayService",
        metadata_extractor: Any | None = None,
        location_normalizer: Any | None = None,
    ) -> None:
        self.service = service
        self.metadata_extractor = metadata_extractor
        self.location_normalizer = location_normalizer

    def execute_run(self, run_id: str) -> dict[str, Any]:
        run_paths = ensure_run_layout(paths=self.service.paths, run_id=run_id)
        manifest = self.service.get_run_input_manifest(run_id)
        item_map = {
            str(_manifest_input_path(root_dir=self.service.paths.root, item=item).resolve()): item
            for item in manifest["items"]
        }
        self.service.mark_run_stage(run_id, stage="SCANNING", progress=0.05)
        photos = self._run_scanning(manifest["items"], run_paths.artifacts_dir / "photos.ndjson")
        self.service.record_stage_progress(run_id, stage="SCANNING", items_total=len(photos), items_done=len(photos), artifact="artifacts/photos.ndjson")
        self.service.checkpoint_pause(run_id, stage="SCANNING")

        self.service.mark_run_stage(run_id, stage="METADATA_EXTRACTION", progress=0.2)
        metadata_rows, metadata_failed_count = self._run_metadata(
            photos,
            run_paths.artifacts_dir / "metadata.ndjson",
            run_id,
            item_map=item_map,
        )
        successful_paths = {str(row["path"]) for row in metadata_rows}
        successful_photos = [row for row in photos if str(row["path"]) in successful_paths]
        write_ndjson(run_paths.artifacts_dir / "photos.ndjson", successful_photos)
        self.service.record_stage_progress(
            run_id,
            stage="METADATA_EXTRACTION",
            items_total=len(photos),
            items_done=len(photos),
            artifact="artifacts/metadata.ndjson",
        )
        self.service.checkpoint_pause(run_id, stage="METADATA_EXTRACTION")

        self.service.mark_run_stage(run_id, stage="CADIS_LOOKUP", progress=0.55)
        geo_rows = self._run_geo(metadata_rows, run_paths.artifacts_dir / "geo.ndjson", run_id)
        self.service.record_stage_progress(
            run_id,
            stage="CADIS_LOOKUP",
            items_total=len(geo_rows),
            items_done=len(geo_rows),
            artifact="artifacts/geo.ndjson",
        )
        self.service.checkpoint_pause(run_id, stage="CADIS_LOOKUP")

        self.service.mark_run_stage(run_id, stage="SQLITE_WRITE", progress=0.8)
        import_db = run_paths.run_dir / "import.db"
        count = self._run_sqlite(
            photos_path=run_paths.artifacts_dir / "photos.ndjson",
            metadata_path=run_paths.artifacts_dir / "metadata.ndjson",
            geo_path=run_paths.artifacts_dir / "geo.ndjson",
            output_db=import_db,
        )
        self.service.record_stage_progress(
            run_id,
            stage="SQLITE_WRITE",
            items_total=count,
            items_done=count,
            artifact="import.db",
        )
        self.service.checkpoint_pause(run_id, stage="SQLITE_WRITE")
        return {
            "run_id": run_id,
            "item_count": int(manifest["item_count"]),
            "processed_count": count,
            "failed_item_count": metadata_failed_count,
            "artifacts": {
                "photos": str(run_paths.artifacts_dir / "photos.ndjson"),
                "metadata": str(run_paths.artifacts_dir / "metadata.ndjson"),
                "geo": str(run_paths.artifacts_dir / "geo.ndjson"),
                "import_db": str(import_db),
            },
        }

    def _run_scanning(self, manifest_items: list[dict[str, Any]], artifact: Path) -> list[dict[str, Any]]:
        rows = []
        for item in manifest_items:
            candidate = _manifest_input_path(root_dir=self.service.paths.root, item=item)
            if not is_supported_photo_file(candidate):
                continue
            rows.append({"path": str(candidate.resolve())})
        artifact.parent.mkdir(parents=True, exist_ok=True)
        write_ndjson(artifact, rows)
        return rows

    def _run_metadata(
        self,
        photos: list[dict[str, Any]],
        artifact: Path,
        run_id: str,
        *,
        item_map: dict[str, dict[str, Any]],
    ) -> tuple[list[dict[str, Any]], int]:
        extractor = self.metadata_extractor or self._default_metadata_extractor()
        rows: list[dict[str, Any]] = []
        failed_count = 0
        total = len(photos)
        for index, row in enumerate(photos, start=1):
            path = Path(str(row["path"]))
            try:
                metadata = extractor.extract(path)
            except Exception as exc:
                failed_count += 1
                item = item_map.get(str(path.resolve()))
                if item is not None:
                    self.service.fail_run_item(
                        run_id,
                        import_file_id=str(item["import_file_id"]),
                        error_code=self._classify_item_failure(exc),
                        error_message=f"Metadata extraction failed for {path}: {exc}",
                    )
                logger.warning("Gateway run %s item %s failed during metadata extraction: %s", run_id, path, exc)
                self.service.record_stage_progress(
                    run_id,
                    stage="METADATA_EXTRACTION",
                    items_total=total,
                    items_done=index,
                    artifact="artifacts/metadata.ndjson",
                )
                self.service.checkpoint_pause(run_id, stage="METADATA_EXTRACTION")
                continue
            rows.append(
                {
                    "path": str(path),
                    "image_facts": metadata.image_facts,
                    "image_camera": metadata.image_camera,
                    "image_location": metadata.image_location,
                }
            )
            self.service.record_stage_progress(
                run_id,
                stage="METADATA_EXTRACTION",
                items_total=total,
                items_done=index,
                artifact="artifacts/metadata.ndjson",
            )
            self.service.checkpoint_pause(run_id, stage="METADATA_EXTRACTION")
        write_ndjson(artifact, rows)
        return rows, failed_count

    def _run_geo(self, metadata_rows: list[dict[str, Any]], artifact: Path, run_id: str) -> list[dict[str, Any]]:
        normalizer = self.location_normalizer or self._default_location_normalizer()
        rows = []
        total = len(metadata_rows)
        for index, row in enumerate(metadata_rows, start=1):
            location = row.get("image_location") or {}
            latitude = location.get("raw_latitude")
            longitude = location.get("raw_longitude")
            if isinstance(latitude, (int, float)) and isinstance(longitude, (int, float)):
                try:
                    normalized = normalizer.normalize(float(latitude), float(longitude))
                except Exception as exc:
                    raise EonaCliError("CADIS_LOOKUP_FAILED", f"Cadis lookup failed for {row['path']}: {exc}") from exc
                normalized_payload = {
                    "cadis_result_json": normalized.cadis_result_json,
                    "cadis_version": normalized.cadis_version,
                    "detail": normalized.detail,
                }
            else:
                normalized_payload = {"cadis_result_json": None, "cadis_version": None, "detail": "no_gps"}
            rows.append(
                {
                    "path": row["path"],
                    "raw_latitude": latitude,
                    "raw_longitude": longitude,
                    "raw_altitude": location.get("raw_altitude"),
                    "normalized_location": normalized_payload,
                }
            )
            self.service.record_stage_progress(
                run_id,
                stage="CADIS_LOOKUP",
                items_total=total,
                items_done=index,
                artifact="artifacts/geo.ndjson",
            )
            self.service.checkpoint_pause(run_id, stage="CADIS_LOOKUP")
        write_ndjson(artifact, rows)
        return rows

    def _run_sqlite(self, *, photos_path: Path, metadata_path: Path, geo_path: Path, output_db: Path) -> int:
        output_db.parent.mkdir(parents=True, exist_ok=True)
        temp_db = output_db.with_suffix(".tmp")
        photos = read_ndjson(photos_path)
        metadata_rows = {row["path"]: row for row in read_ndjson(metadata_path)}
        geo_rows = {row["path"]: row for row in read_ndjson(geo_path)}
        with sqlite3.connect(temp_db) as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS photos (
                    path TEXT PRIMARY KEY
                );
                CREATE TABLE IF NOT EXISTS metadata (
                    path TEXT PRIMARY KEY,
                    metadata_json TEXT
                );
                CREATE TABLE IF NOT EXISTS geo (
                    path TEXT PRIMARY KEY,
                    geo_json TEXT
                );
                """
            )
            for row in photos:
                connection.execute("INSERT OR REPLACE INTO photos(path) VALUES(?)", (row["path"],))
                connection.execute(
                    "INSERT OR REPLACE INTO metadata(path, metadata_json) VALUES(?, ?)",
                    (row["path"], json.dumps(metadata_rows.get(row["path"], {}), sort_keys=True)),
                )
                connection.execute(
                    "INSERT OR REPLACE INTO geo(path, geo_json) VALUES(?, ?)",
                    (row["path"], json.dumps(geo_rows.get(row["path"], {}), sort_keys=True)),
                )
            connection.commit()
        temp_db.replace(output_db)
        return len(photos)

    def _default_metadata_extractor(self) -> ExiftoolMetadataExtractor:
        exiftool_path = resolve_gateway_exiftool_path()
        if exiftool_path is None:
            raise EonaCliError("DEPENDENCY_MISSING", "Required dependency missing: exiftool")
        manifest = load_gateway_runtime_manifest() or {}
        tools = manifest.get("tools") if isinstance(manifest, dict) else {}
        exiftool_version = "path"
        if isinstance(tools, dict):
            exiftool = tools.get("exiftool")
            if isinstance(exiftool, dict) and isinstance(exiftool.get("version"), str):
                exiftool_version = str(exiftool["version"])
        return ExiftoolMetadataExtractor(
            executable=Path(exiftool_path),
            capability_snapshot=ExiftoolCapabilitySnapshot(exiftool_version=exiftool_version),
        )

    def _default_location_normalizer(self) -> CadisRuntimeNormalizer:
        try:
            return CadisRuntimeNormalizer()
        except Exception as exc:
            raise EonaCliError("DEPENDENCY_MISSING", f"Required dependency missing: cadis ({exc})") from exc

    def _classify_item_failure(self, exc: Exception) -> str:
        message = str(exc).lower()
        if "truncated" in message:
            return "SOURCE_IMAGE_TRUNCATED"
        if "cannot identify image file" in message:
            return "SOURCE_IMAGE_UNREADABLE"
        return "METADATA_EXTRACTION_FAILED"
