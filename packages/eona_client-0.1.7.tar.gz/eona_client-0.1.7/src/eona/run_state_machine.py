from __future__ import annotations

from copy import deepcopy
from typing import Any

RUN_STATUSES = ("started", "running", "cancelling", "cancelled", "complete", "failed")
STAGES = (
    "SCANNING",
    "METADATA_EXTRACTION",
    "CADIS_LOOKUP",
    "SQLITE_WRITE",
)
STAGE_STATES = ("pending", "running", "complete", "failed", "cancelled")
STAGE_WEIGHTS: dict[str, float] = {
    "SCANNING": 0.20,
    "METADATA_EXTRACTION": 0.35,
    "CADIS_LOOKUP": 0.25,
    "SQLITE_WRITE": 0.20,
}


def _default_stage_payload(stage: str) -> dict[str, Any]:
    version = {
        "SCANNING": "photo-scan-v1",
        "METADATA_EXTRACTION": "exiftool-path/schema-1",
        "CADIS_LOOKUP": "cadis-runtime-v1",
        "SQLITE_WRITE": "memory-db-v1",
    }[stage]
    return {
        "state": "pending",
        "artifact": None,
        "items_total": None,
        "items_done": 0,
        "started_at": None,
        "completed_at": None,
        "version": version,
        "artifact_status": "pending",
    }


def create_run_state(*, run_id: str, input_path: str, workspace: str, started_at: str) -> dict[str, Any]:
    return {
        "run_id": run_id,
        "input_path": input_path,
        "workspace": workspace,
        "status": "started",
        "current_stage": "SCANNING",
        "progress": 0.0,
        "started_at": started_at,
        "updated_at": started_at,
        "completed_at": None,
        "pipeline_version": "v1",
        "models": {},
        "photos_total": 0,
        "photos_processed": 0,
        "error_code": None,
        "error_message": None,
        "cancel_requested_at": None,
        "cancelled_at": None,
        "cancel_reason": None,
        "stages": {stage: _default_stage_payload(stage) for stage in STAGES},
    }


def compute_progress(run_state: dict[str, Any]) -> float:
    progress = 0.0
    for stage in STAGES:
        stage_payload = run_state["stages"][stage]
        if stage_payload["state"] == "complete":
            progress += STAGE_WEIGHTS[stage]
            continue
        items_total = stage_payload.get("items_total")
        items_done = stage_payload.get("items_done", 0)
        if stage_payload["state"] == "running" and isinstance(items_total, int) and items_total > 0:
            progress += STAGE_WEIGHTS[stage] * min(max(items_done / items_total, 0.0), 1.0)
        break
    return round(min(progress, 1.0), 6)


def set_stage_running(run_state: dict[str, Any], *, stage: str, started_at: str) -> dict[str, Any]:
    updated = deepcopy(run_state)
    updated["status"] = "running"
    updated["current_stage"] = stage
    updated["updated_at"] = started_at
    updated["error_code"] = None
    updated["error_message"] = None
    updated["cancel_requested_at"] = None
    updated["cancelled_at"] = None
    updated["cancel_reason"] = None
    updated["stages"][stage]["state"] = "running"
    updated["stages"][stage]["artifact_status"] = "building"
    if updated["stages"][stage]["started_at"] is None:
        updated["stages"][stage]["started_at"] = started_at
    updated["progress"] = compute_progress(updated)
    return updated


def update_stage_counts(
    run_state: dict[str, Any],
    *,
    stage: str,
    items_total: int | None = None,
    items_done: int | None = None,
    artifact: str | None = None,
    updated_at: str,
) -> dict[str, Any]:
    updated = deepcopy(run_state)
    payload = updated["stages"][stage]
    if items_total is not None:
        payload["items_total"] = items_total
    if items_done is not None:
        payload["items_done"] = items_done
    if artifact is not None:
        payload["artifact"] = artifact
    if stage == "SCANNING" and items_total is not None:
        updated["photos_total"] = items_total
    if stage != "SCANNING" and items_done is not None:
        updated["photos_processed"] = items_done
    updated["updated_at"] = updated_at
    updated["progress"] = compute_progress(updated)
    return updated


def set_stage_complete(
    run_state: dict[str, Any],
    *,
    stage: str,
    completed_at: str,
    artifact: str | None,
    items_total: int | None,
    items_done: int | None,
) -> dict[str, Any]:
    updated = deepcopy(run_state)
    payload = updated["stages"][stage]
    payload["state"] = "complete"
    payload["artifact"] = artifact
    payload["items_total"] = items_total
    payload["items_done"] = items_done
    payload["completed_at"] = completed_at
    payload["artifact_status"] = "valid"
    updated["updated_at"] = completed_at
    updated["cancel_requested_at"] = None
    updated["cancelled_at"] = None
    updated["cancel_reason"] = None
    if stage == "SCANNING":
        updated["photos_total"] = int(items_total or 0)
        updated["photos_processed"] = 0
    elif items_done is not None:
        updated["photos_processed"] = int(items_done)
    next_stage = next_stage_name(stage)
    if next_stage is None:
        updated["status"] = "complete"
        updated["current_stage"] = None
        updated["completed_at"] = completed_at
    else:
        updated["status"] = "running"
        updated["current_stage"] = next_stage
    updated["progress"] = compute_progress(updated)
    return updated


def set_stage_failed(
    run_state: dict[str, Any],
    *,
    stage: str,
    failed_at: str,
    error_code: str,
    error_message: str,
) -> dict[str, Any]:
    updated = deepcopy(run_state)
    updated["status"] = "failed"
    updated["current_stage"] = stage
    updated["updated_at"] = failed_at
    updated["error_code"] = error_code
    updated["error_message"] = error_message
    updated["stages"][stage]["state"] = "failed"
    updated["stages"][stage]["artifact_status"] = "invalid"
    updated["progress"] = compute_progress(updated)
    return updated


def set_run_cancelling(
    run_state: dict[str, Any],
    *,
    requested_at: str,
    cancel_reason: str | None = None,
) -> dict[str, Any]:
    updated = deepcopy(run_state)
    updated["status"] = "cancelling"
    updated["updated_at"] = requested_at
    updated["cancel_requested_at"] = requested_at
    updated["cancel_reason"] = cancel_reason
    updated["error_code"] = None
    updated["error_message"] = None
    updated["progress"] = compute_progress(updated)
    return updated


def set_run_cancelled(
    run_state: dict[str, Any],
    *,
    stage: str | None,
    cancelled_at: str,
) -> dict[str, Any]:
    updated = deepcopy(run_state)
    updated["status"] = "cancelled"
    updated["current_stage"] = None
    updated["updated_at"] = cancelled_at
    updated["cancelled_at"] = cancelled_at
    updated["completed_at"] = None
    updated["error_code"] = None
    updated["error_message"] = None
    if stage is not None:
        payload = updated["stages"][stage]
        payload["state"] = "cancelled"
        if payload.get("artifact") is None:
            payload["artifact"] = {
                "SCANNING": "photos.ndjson",
                "METADATA_EXTRACTION": "metadata.ndjson",
                "CADIS_LOOKUP": "geo.ndjson",
                "SQLITE_WRITE": "memory.db",
            }[stage]
        payload["artifact_status"] = "partial" if (payload.get("items_done") or 0) > 0 or payload["started_at"] else "pending"
    updated["progress"] = compute_progress(updated)
    return updated


def next_stage_name(stage: str) -> str | None:
    try:
        index = STAGES.index(stage)
    except ValueError:
        return None
    next_index = index + 1
    return STAGES[next_index] if next_index < len(STAGES) else None


def earliest_resumable_stage(run_state: dict[str, Any]) -> str | None:
    for stage in STAGES:
        payload = run_state["stages"][stage]
        if payload["state"] != "complete":
            return stage
    return None


def reset_from_stage(run_state: dict[str, Any], *, stage: str, updated_at: str) -> dict[str, Any]:
    updated = deepcopy(run_state)
    found = False
    for name in STAGES:
        if name == stage:
            found = True
        if found:
            updated["stages"][name] = _default_stage_payload(name)
    updated["status"] = "started"
    updated["current_stage"] = stage
    updated["updated_at"] = updated_at
    updated["completed_at"] = None
    updated["cancel_requested_at"] = None
    updated["cancelled_at"] = None
    updated["cancel_reason"] = None
    updated["error_code"] = None
    updated["error_message"] = None
    updated["progress"] = compute_progress(updated)
    return updated
