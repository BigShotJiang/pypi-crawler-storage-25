from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any


def parse_version_tuple(value: str | None) -> tuple[int, ...]:
    if not isinstance(value, str) or not value.strip():
        return ()
    normalized = value.strip()
    if normalized.startswith("v"):
        normalized = normalized[1:]
    parts: list[int] = []
    for piece in normalized.split("."):
        if not piece.isdigit():
            return ()
        parts.append(int(piece))
    return tuple(parts)


@dataclass(frozen=True)
class CadisCapabilitySnapshot:
    cadis_version: str
    ready_iso2: tuple[str, ...]
    supported_iso2: tuple[str, ...]
    dataset_lockdown_enabled: bool
    allowed_iso2: tuple[str, ...] = ()

    def effective_available_iso2(self) -> tuple[str, ...]:
        ready = {iso2.upper() for iso2 in self.ready_iso2}
        if not self.dataset_lockdown_enabled:
            return tuple(sorted(ready))
        allowed = {iso2.upper() for iso2 in self.allowed_iso2}
        return tuple(sorted(ready & allowed))

    def effective_supported_iso2(self) -> tuple[str, ...]:
        supported = {iso2.upper() for iso2 in self.supported_iso2}
        if not self.dataset_lockdown_enabled:
            return tuple(sorted(supported))
        allowed = {iso2.upper() for iso2 in self.allowed_iso2}
        return tuple(sorted(supported & allowed))


@dataclass(frozen=True)
class CadisConvergenceAssessment:
    should_rederive: bool
    reason_codes: tuple[str, ...]


@dataclass(frozen=True)
class CadisSelectionPlan:
    where_sql: str
    params: tuple[Any, ...]
    summary: dict[str, Any]


@dataclass(frozen=True)
class _StoredOutcome:
    lookup_status: str | None
    resolution_state: str | None
    capability_detail: str | None
    dataset_status: str | None
    dataset_iso2: str | None
    world_classification: str | None


class CadisAdapter:
    convergence_class = "semantic"

    @staticmethod
    def _in_clause(values: tuple[str, ...]) -> tuple[str, list[Any]]:
        if not values:
            return "0", []
        return ", ".join("?" for _ in values), list(values)

    @staticmethod
    def _append_engine_upgrade_reason(
        *,
        reason_codes: list[str],
        previous_cadis_version: str | None,
        frozen_capability: CadisCapabilitySnapshot,
        force_on_engine_upgrade: bool,
    ) -> None:
        if not force_on_engine_upgrade:
            return
        if parse_version_tuple(previous_cadis_version) < parse_version_tuple(frozen_capability.cadis_version):
            reason_codes.append("older_cadis_version")

    @staticmethod
    def _normalize_iso2(value: Any) -> str | None:
        if not isinstance(value, str) or len(value.strip()) != 2:
            return None
        return value.strip().upper()

    def _outcome_from_payload(self, payload: dict[str, Any]) -> _StoredOutcome:
        execution = payload.get("execution", {})
        if not isinstance(execution, dict):
            execution = {}
        state = payload.get("state", {})
        if not isinstance(state, dict):
            state = {}
        dataset = state.get("dataset", {})
        if not isinstance(dataset, dict):
            dataset = {}
        world = state.get("world", {})
        if not isinstance(world, dict):
            world = {}

        lookup_status = execution.get("lookup_status")
        resolution_state = execution.get("resolution_state")
        capability_detail = execution.get("capability_detail")
        dataset_status = dataset.get("status")
        dataset_iso2 = self._normalize_iso2(dataset.get("iso2"))
        world_classification = world.get("classification")

        if not isinstance(lookup_status, str):
            lookup_status = None
        if not isinstance(resolution_state, str):
            resolution_state = None
        if not isinstance(capability_detail, str):
            capability_detail = None
        if not isinstance(dataset_status, str):
            dataset_status = None
        if not isinstance(world_classification, str):
            world_classification = None

        return _StoredOutcome(
            lookup_status=lookup_status,
            resolution_state=resolution_state,
            capability_detail=capability_detail,
            dataset_status=dataset_status,
            dataset_iso2=dataset_iso2,
            world_classification=world_classification,
        )

    def _append_contract_driven_reasons(
        self,
        *,
        reason_codes: list[str],
        outcome: _StoredOutcome,
        frozen_capability: CadisCapabilitySnapshot,
    ) -> None:
        effective_available_iso2 = set(frozen_capability.effective_available_iso2())
        effective_supported_iso2 = set(frozen_capability.effective_supported_iso2())

        if outcome.lookup_status == "ok":
            return

        if outcome.lookup_status == "partial":
            reason_codes.append("cadis_lookup_not_ok")
            return

        if outcome.resolution_state == "invalid_input":
            return
        if outcome.resolution_state == "terminal_non_country":
            return
        if outcome.resolution_state == "engine_failure":
            reason_codes.append("cadis_engine_failure")
            return
        if outcome.resolution_state == "unresolved_country":
            reason_codes.append("cadis_unresolved_country")
            return

        if outcome.capability_detail == "supported_dataset_missing":
            if outcome.dataset_iso2 in effective_available_iso2:
                reason_codes.append("supported_dataset_missing_now_available")
            else:
                reason_codes.append("cadis_lookup_not_ok")
            return

        if outcome.capability_detail == "unsupported_country":
            if outcome.dataset_iso2 in effective_supported_iso2:
                reason_codes.append("unsupported_country_now_supported")
            return

        if outcome.capability_detail == "dataset_blocked_by_policy":
            if outcome.dataset_iso2 in effective_available_iso2:
                reason_codes.append("dataset_blocked_now_available")
            else:
                reason_codes.append("cadis_lookup_not_ok")
            return

        if outcome.capability_detail == "dataset_invalid":
            if outcome.dataset_iso2 in effective_available_iso2:
                reason_codes.append("dataset_invalid_now_available")
            else:
                reason_codes.append("cadis_lookup_not_ok")
            return

        if outcome.capability_detail == "dataset_ready_unresolved":
            reason_codes.append("cadis_unresolved_country")
            return

        if outcome.capability_detail == "input_invalid":
            return
        if outcome.capability_detail == "non_country_world_classification":
            return

        # Backward-compatible fallback for older Cadis payloads without 0.3.1 execution vocabulary.
        if outcome.dataset_status == "missing":
            if outcome.dataset_iso2 in effective_available_iso2:
                reason_codes.append("supported_dataset_missing_now_available")
            elif outcome.dataset_iso2 in effective_supported_iso2:
                reason_codes.append("cadis_lookup_not_ok")
            return
        if outcome.dataset_status == "blocked":
            if outcome.dataset_iso2 in effective_available_iso2:
                reason_codes.append("dataset_blocked_now_available")
            else:
                reason_codes.append("cadis_lookup_not_ok")
            return
        if outcome.dataset_status == "invalid":
            if outcome.dataset_iso2 in effective_available_iso2:
                reason_codes.append("dataset_invalid_now_available")
            else:
                reason_codes.append("cadis_lookup_not_ok")
            return
        if outcome.world_classification == "country":
            reason_codes.append("cadis_lookup_not_ok")

    def build_renorm_selection_plan(
        self,
        *,
        frozen_capability: CadisCapabilitySnapshot,
        batch_size: int,
        force_on_engine_upgrade: bool = False,
    ) -> CadisSelectionPlan:
        effective_available_iso2 = frozen_capability.effective_available_iso2()
        effective_supported_iso2 = frozen_capability.effective_supported_iso2()
        available_clause, params = self._in_clause(effective_available_iso2)
        supported_clause, supported_params = self._in_clause(effective_supported_iso2)

        where_sql = f"""
            image_location.raw_latitude IS NOT NULL
            AND image_location.raw_longitude IS NOT NULL
            AND (
                image_location.cadis_result_json IS NULL
                OR COALESCE(json_valid(image_location.cadis_result_json), 0) = 0
                OR json_extract(image_location.cadis_result_json, '$.execution.lookup_status') = 'partial'
                OR (
                    json_extract(image_location.cadis_result_json, '$.execution.capability_detail') = 'supported_dataset_missing'
                    AND json_extract(image_location.cadis_result_json, '$.state.dataset.iso2') IN ({available_clause})
                )
                OR (
                    json_extract(image_location.cadis_result_json, '$.execution.capability_detail') = 'unsupported_country'
                    AND json_extract(image_location.cadis_result_json, '$.state.dataset.iso2') IN ({supported_clause})
                )
                OR (
                    json_extract(image_location.cadis_result_json, '$.execution.capability_detail') = 'dataset_blocked_by_policy'
                    AND json_extract(image_location.cadis_result_json, '$.state.dataset.iso2') IN ({available_clause})
                )
                OR (
                    json_extract(image_location.cadis_result_json, '$.execution.capability_detail') = 'dataset_invalid'
                    AND json_extract(image_location.cadis_result_json, '$.state.dataset.iso2') IN ({available_clause})
                )
                OR json_extract(image_location.cadis_result_json, '$.execution.capability_detail') = 'dataset_ready_unresolved'
                OR json_extract(image_location.cadis_result_json, '$.execution.resolution_state') = 'engine_failure'
                OR json_extract(image_location.cadis_result_json, '$.execution.resolution_state') = 'unresolved_country'
                OR (
                    json_extract(image_location.cadis_result_json, '$.execution.lookup_status') = 'failed'
                    AND json_extract(image_location.cadis_result_json, '$.execution.resolution_state') IS NULL
                    AND json_extract(image_location.cadis_result_json, '$.state.dataset.status') = 'missing'
                    AND json_extract(image_location.cadis_result_json, '$.state.dataset.iso2') IN ({available_clause})
                )
                OR (
                    json_extract(image_location.cadis_result_json, '$.execution.lookup_status') = 'failed'
                    AND json_extract(image_location.cadis_result_json, '$.execution.resolution_state') IS NULL
                    AND json_extract(image_location.cadis_result_json, '$.state.dataset.status') = 'blocked'
                    AND json_extract(image_location.cadis_result_json, '$.state.dataset.iso2') IN ({available_clause})
                )
                OR (
                    json_extract(image_location.cadis_result_json, '$.execution.lookup_status') = 'failed'
                    AND json_extract(image_location.cadis_result_json, '$.execution.resolution_state') IS NULL
                    AND json_extract(image_location.cadis_result_json, '$.state.dataset.status') = 'invalid'
                    AND json_extract(image_location.cadis_result_json, '$.state.dataset.iso2') IN ({available_clause})
                )
        """

        params.extend(supported_params)
        params.extend(effective_available_iso2)
        params.extend(effective_available_iso2)
        params.extend(effective_available_iso2)
        params.extend(effective_available_iso2)
        params.extend(effective_available_iso2)

        if force_on_engine_upgrade:
            where_sql += """
                OR cadis_version_lt(image_location.cadis_version, ?) = 1
            """
            params.append(frozen_capability.cadis_version)

        where_sql += """
            )
        """

        summary = {
            "adapter": "cadis",
            "convergence_class": self.convergence_class,
            "reasons": [
                "cadis_result_missing",
                "cadis_result_unparseable",
                "cadis_lookup_not_ok",
                "supported_dataset_missing_now_available",
                "unsupported_country_now_supported",
                "dataset_blocked_now_available",
                "dataset_invalid_now_available",
                "cadis_unresolved_country",
                "cadis_engine_failure",
            ]
            + (["older_cadis_version"] if force_on_engine_upgrade else []),
            "filters": {
                "requires_raw_latitude_longitude": True,
                "frozen_cadis_version": frozen_capability.cadis_version,
                "ready_iso2": list(frozen_capability.ready_iso2),
                "supported_iso2": list(frozen_capability.supported_iso2),
                "dataset_lockdown_enabled": frozen_capability.dataset_lockdown_enabled,
                "allowed_iso2": list(frozen_capability.allowed_iso2),
                "effective_available_iso2": list(effective_available_iso2),
                "effective_supported_iso2": list(effective_supported_iso2),
                "force_on_engine_upgrade": force_on_engine_upgrade,
            },
            "ordering": "content_id ASC",
            "batch_size": batch_size,
        }
        return CadisSelectionPlan(where_sql=where_sql, params=tuple(params), summary=summary)

    def assess_convergence(
        self,
        *,
        previous_result_json: str | None,
        previous_cadis_version: str | None,
        frozen_capability: CadisCapabilitySnapshot,
        force_on_engine_upgrade: bool = False,
    ) -> CadisConvergenceAssessment:
        reason_codes: list[str] = []

        if previous_result_json is None:
            reason_codes.append("cadis_result_missing")
        else:
            try:
                payload = json.loads(previous_result_json)
            except json.JSONDecodeError:
                payload = None
                reason_codes.append("cadis_result_unparseable")

            if payload is not None and not isinstance(payload, dict):
                reason_codes.append("cadis_result_unparseable")
                payload = None

            if payload is not None:
                outcome = self._outcome_from_payload(payload)
                self._append_contract_driven_reasons(
                    reason_codes=reason_codes,
                    outcome=outcome,
                    frozen_capability=frozen_capability,
                )

        self._append_engine_upgrade_reason(
            reason_codes=reason_codes,
            previous_cadis_version=previous_cadis_version,
            frozen_capability=frozen_capability,
            force_on_engine_upgrade=force_on_engine_upgrade,
        )

        deduped = tuple(dict.fromkeys(reason_codes))
        return CadisConvergenceAssessment(should_rederive=bool(deduped), reason_codes=deduped)
