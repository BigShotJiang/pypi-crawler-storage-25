from __future__ import annotations

import hashlib
import json
import re
from typing import Any

PHOTO_SIGNATURE_VERSION = 1


def normalize_taken_at_utc(value: Any) -> str | None:
    if not isinstance(value, str) or not value:
        return None
    return value


def normalize_coordinate(value: Any) -> float | None:
    if not isinstance(value, (int, float)):
        return None
    return round(float(value), 6)


def normalize_altitude(value: Any) -> float | None:
    if not isinstance(value, (int, float)):
        return None
    return round(float(value), 1)


def normalize_camera_text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    collapsed = re.sub(r"\s+", " ", value.strip()).casefold()
    return collapsed or None


def build_signature_payload(*, metadata_row: dict[str, Any]) -> dict[str, Any]:
    image_facts = metadata_row.get("image_facts") or {}
    image_camera = metadata_row.get("image_camera") or {}
    image_location = metadata_row.get("image_location") or {}
    return {
        "version": PHOTO_SIGNATURE_VERSION,
        "taken_at_utc": normalize_taken_at_utc(image_facts.get("taken_at_utc")),
        "raw_latitude": normalize_coordinate(image_location.get("raw_latitude")),
        "raw_longitude": normalize_coordinate(image_location.get("raw_longitude")),
        "raw_altitude": normalize_altitude(image_location.get("raw_altitude")),
        "camera_make": normalize_camera_text(image_camera.get("make")),
        "camera_model": normalize_camera_text(image_camera.get("model")),
    }


def serialize_signature_payload(payload: dict[str, Any]) -> str:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def photo_signature_for_metadata(*, metadata_row: dict[str, Any]) -> tuple[str, str]:
    payload = build_signature_payload(metadata_row=metadata_row)
    payload_json = serialize_signature_payload(payload)
    signature = hashlib.sha256(payload_json.encode("utf-8")).hexdigest()
    return signature, payload_json
