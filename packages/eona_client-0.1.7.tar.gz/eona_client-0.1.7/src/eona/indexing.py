from __future__ import annotations

import hashlib
import json
import logging
import os
import sqlite3
import threading
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Protocol

from eona.cadis_runtime import call_cadis
from eona.exiftool_adapter import ExiftoolAdapter
from eona.runtime import get_installed_runtime_manifest_hash, get_runtime_paths
from eona.storage import (
    SCHEMA_VERSION,
    _connect_database,
    _read_json,
    derive_root_group_hash,
    get_storage_paths,
    serialize_cadis_payload,
    update_state,
    write_run_artifact,
    write_run_state,
)

RUN_STAGES = (
    "IDLE",
    "SCANNING",
    "HASHING",
    "EXTRACTING",
    "NORMALIZING",
    "WRITING_DB",
    "RECONCILING",
    "PAUSED",
    "RECOVERING",
    "COMPLETED",
    "FAILED",
    "STOPPING",
)


def utc_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def new_identifier() -> str:
    return uuid.uuid4().hex


@dataclass(frozen=True)
class FileCandidate:
    path: Path
    mtime_ns: int
    file_size: int


@dataclass(frozen=True)
class ProbeRootSnapshot:
    path: Path
    st_dev: int
    st_ino: int


@dataclass(frozen=True)
class ExtractedMetadata:
    image_facts: dict[str, Any]
    image_camera: dict[str, Any]
    image_location: dict[str, Any]


@dataclass(frozen=True)
class KnownFileRecord:
    file_id: int
    content_id: int
    mtime_ns: int
    file_size: int


@dataclass(frozen=True)
class NormalizedLocation:
    cadis_result_json: str | None
    cadis_version: str | None
    detail: str | None = None


@dataclass(frozen=True)
class CadisCapabilitySnapshot:
    cadis_version: str
    installed_iso2: tuple[str, ...]
    dataset_lockdown_enabled: bool
    allowed_iso2: tuple[str, ...]
    effective_allowed_iso2: tuple[str, ...]
    supported_iso2: tuple[str, ...] = ()


class MetadataExtractor(Protocol):
    def extract(self, path: Path) -> ExtractedMetadata:
        ...


class LocationNormalizer(Protocol):
    def normalize(self, latitude: float, longitude: float) -> NormalizedLocation:
        ...


class IndexingObserver(Protocol):
    def set_state(
        self,
        state: str,
        *,
        current_file: str | None = None,
        current_content_id: int | None = None,
    ) -> None:
        ...

    def set_total(self, total_estimated: int) -> None:
        ...

    def set_selection_summary(self, selection_summary: dict[str, Any] | None) -> None:
        ...

    def advance(
        self,
        *,
        current_file: str | None = None,
        current_content_id: int | None = None,
        increment: int = 1,
    ) -> None:
        ...

    def check_control(self) -> str | None:
        ...

    def warning(self, message: str) -> None:
        ...


class NoopObserver:
    def set_state(
        self,
        state: str,
        *,
        current_file: str | None = None,
        current_content_id: int | None = None,
    ) -> None:
        return None

    def set_total(self, total_estimated: int) -> None:
        return None

    def set_selection_summary(self, selection_summary: dict[str, Any] | None) -> None:
        return None

    def advance(
        self,
        *,
        current_file: str | None = None,
        current_content_id: int | None = None,
        increment: int = 1,
    ) -> None:
        return None

    def check_control(self) -> str | None:
        return None

    def warning(self, message: str) -> None:
        return None


class PauseRequested(Exception):
    pass


class StopRequested(Exception):
    pass


class ProbeRootLost(RuntimeError):
    pass


class CadisRuntimeNormalizer:
    def __init__(self, *, capability_snapshot: CadisCapabilitySnapshot | None = None) -> None:
        self.capability_snapshot = capability_snapshot

    def normalize(self, latitude: float, longitude: float) -> NormalizedLocation:
        from cadis import CadisSDK, __version__

        effective_allowed = None if self.capability_snapshot is None else self.capability_snapshot.effective_allowed_iso2
        payload = {
            "version": __version__,
            "lookup": call_cadis(
                lambda sdk, _: sdk.lookup(latitude, longitude),
                effective_allowed_iso2=effective_allowed,
            ),
        }
        return parse_cadis_lookup_payload(payload)


def parse_cadis_lookup_payload(payload: dict[str, Any]) -> NormalizedLocation:
    version = payload.get("version")
    cadis_version = version if isinstance(version, str) and version else None
    lookup = payload.get("lookup")
    if not isinstance(lookup, dict):
        return NormalizedLocation(cadis_result_json=None, cadis_version=None, detail="invalid lookup payload")
    serialized_lookup = serialize_cadis_payload(lookup)
    execution = lookup.get("execution")
    status = execution.get("lookup_status") if isinstance(execution, dict) else None
    if status == "ok":
        return NormalizedLocation(
            cadis_result_json=serialized_lookup,
            cadis_version=cadis_version,
            detail=None,
        )

    state = lookup.get("state")
    if isinstance(state, dict):
        dataset = state.get("dataset")
        if isinstance(dataset, dict):
            dataset_status = dataset.get("status")
            iso2 = dataset.get("iso2")
            if dataset_status in {"missing", "invalid", "blocked"} and isinstance(iso2, str):
                detail_code = dataset.get("detail_code")
                suffix = f" ({detail_code})" if isinstance(detail_code, str) and detail_code else ""
                return NormalizedLocation(
                    cadis_result_json=serialized_lookup,
                    cadis_version=cadis_version,
                    detail=f"cadis dataset {dataset_status} for {iso2}{suffix}",
                )
        world = state.get("world")
        if isinstance(world, dict):
            classification = world.get("classification")
            if isinstance(classification, str) and classification:
                name = world.get("name")
                if isinstance(name, str) and name:
                    return NormalizedLocation(
                        cadis_result_json=serialized_lookup,
                        cadis_version=cadis_version,
                        detail=f"cadis world classification {classification}: {name}",
                    )
                return NormalizedLocation(
                    cadis_result_json=serialized_lookup,
                    cadis_version=cadis_version,
                    detail=f"cadis world classification {classification}",
                )
    return NormalizedLocation(
        cadis_result_json=serialized_lookup,
        cadis_version=cadis_version,
        detail=None,
    )


def capture_cadis_capability() -> CadisCapabilitySnapshot:
    payload = call_cadis(lambda sdk, _: sdk.info(), effective_allowed_iso2=None)
    version = payload.get("version")
    installed = payload.get("installed_iso2") or []
    supported = payload.get("supported_iso2") or []
    lockdown_enabled = bool(payload.get("dataset_lockdown_enabled"))
    allowed = payload.get("allowed_iso2") or []
    if not isinstance(version, str) or not version:
        raise RuntimeError("cadis info missing version")
    installed_iso2 = tuple(sorted(str(code) for code in installed if isinstance(code, str)))
    supported_iso2 = tuple(sorted(str(code) for code in supported if isinstance(code, str)))
    allowed_iso2 = tuple(sorted(str(code) for code in allowed if isinstance(code, str)))
    if lockdown_enabled:
        effective_allowed = tuple(sorted(set(installed_iso2).intersection(allowed_iso2)))
    else:
        effective_allowed = installed_iso2
    return CadisCapabilitySnapshot(
        cadis_version=version,
        installed_iso2=installed_iso2,
        dataset_lockdown_enabled=lockdown_enabled,
        allowed_iso2=allowed_iso2,
        effective_allowed_iso2=effective_allowed,
        supported_iso2=supported_iso2,
    )


def build_default_services(
    *,
    capability_snapshot: CadisCapabilitySnapshot | None = None,
) -> tuple[MetadataExtractor, LocationNormalizer]:
    runtime_paths = get_runtime_paths()
    manifest = _read_json(runtime_paths.manifest)
    exiftool_relative = manifest["binaries"][0]["executable_relative_path"]
    exiftool_adapter = ExiftoolAdapter()
    exiftool_capability = exiftool_adapter.capture_capability(manifest=manifest)
    extractor = exiftool_adapter.build_extractor(
        executable=runtime_paths.root / exiftool_relative,
        capability_snapshot=exiftool_capability,
    )
    normalizer = CadisRuntimeNormalizer(capability_snapshot=capability_snapshot)
    return extractor, normalizer


class Indexer:
    def __init__(
        self,
        *,
        extractor: MetadataExtractor | None = None,
        normalizer: LocationNormalizer | None = None,
        batch_size: int = 100,
        logger: logging.Logger | None = None,
    ) -> None:
        self.extractor = extractor
        self.normalizer = normalizer
        self.batch_size = batch_size
        self.logger = logger or logging.getLogger(__name__)

    def run(
        self,
        *,
        database_path: Path,
        probe_path: Path,
        run_started_at: str,
        observer: IndexingObserver | None = None,
        recovering: bool = False,
        root_group_roots: tuple[Path, ...] | None = None,
        root_group_hash: str | None = None,
    ) -> dict[str, Any]:
        observer = observer or NoopObserver()
        observer.set_state("RECOVERING" if recovering else "SCANNING")
        probe_snapshot = self._capture_probe_root_snapshot(probe_path)
        candidates = self._scan_probe_path(probe_path=probe_path, observer=observer)
        observer.set_total(len(candidates))
        processed = 0
        scoped_roots = tuple(root.resolve() for root in (root_group_roots or (probe_path,)))
        active_root_group_hash = root_group_hash or derive_root_group_hash(scoped_roots)

        with _connect_database(database_path) as connection:
            for offset in range(0, len(candidates), self.batch_size):
                self._assert_probe_root_coherent(probe_snapshot)
                action = observer.check_control()
                if action == "pause":
                    raise PauseRequested
                if action == "stop":
                    raise StopRequested

                batch = candidates[offset : offset + self.batch_size]
                connection.execute("BEGIN")
                try:
                    for candidate in batch:
                        processed += self._process_candidate(
                            connection=connection,
                            candidate=candidate,
                            run_started_at=run_started_at,
                            observer=observer,
                            root_group_hash=active_root_group_hash,
                        )
                        observer.advance(current_file=str(candidate.path))
                    connection.commit()
                except Exception:
                    connection.rollback()
                    raise

            observer.set_state("RECONCILING")
            self._assert_probe_root_coherent(probe_snapshot)
            connection.execute("BEGIN")
            try:
                connection.execute(
                    "UPDATE files SET missing = 1 WHERE root_group_hash = ? AND last_seen_at < ?",
                    (active_root_group_hash, run_started_at),
                )
                connection.execute(
                    "UPDATE files SET missing = 0 WHERE root_group_hash = ? AND last_seen_at = ?",
                    (active_root_group_hash, run_started_at),
                )
                indexed_count = int(
                    connection.execute(
                        "SELECT COUNT(*) AS count FROM files WHERE root_group_hash = ? AND missing = 0",
                        (active_root_group_hash,),
                    ).fetchone()["count"]
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise

        return {"processed": processed, "indexed_count": indexed_count, "total_estimated": len(candidates)}

    @staticmethod
    def _capture_probe_root_snapshot(probe_path: Path) -> ProbeRootSnapshot:
        try:
            stat_result = probe_path.stat()
        except OSError as exc:
            raise ProbeRootLost(f"probe_root_lost: unable to stat {probe_path} ({exc})") from exc
        if not probe_path.is_dir():
            raise ProbeRootLost(f"probe_root_lost: probe path is not a directory: {probe_path}")
        if not os.access(probe_path, os.R_OK | os.X_OK):
            raise ProbeRootLost(f"probe_root_lost: probe path is not readable: {probe_path}")
        return ProbeRootSnapshot(
            path=probe_path,
            st_dev=stat_result.st_dev,
            st_ino=stat_result.st_ino,
        )

    @staticmethod
    def _assert_probe_root_coherent(snapshot: ProbeRootSnapshot) -> None:
        path = snapshot.path
        try:
            stat_result = path.stat()
        except OSError as exc:
            raise ProbeRootLost(f"probe_root_lost: unable to stat {path} ({exc})") from exc
        if not path.is_dir():
            raise ProbeRootLost(f"probe_root_lost: probe path is not a directory: {path}")
        if not os.access(path, os.R_OK | os.X_OK):
            raise ProbeRootLost(f"probe_root_lost: probe path is not readable: {path}")

    def _scan_probe_path(self, *, probe_path: Path, observer: IndexingObserver) -> list[FileCandidate]:
        if not probe_path.is_dir():
            raise RuntimeError(f"probe path is not a directory: {probe_path}")
        if not os.access(probe_path, os.R_OK | os.X_OK):
            raise RuntimeError(f"probe path is not readable: {probe_path}")

        candidates: list[FileCandidate] = []
        def _scan_error(exc: OSError) -> None:
            filename = exc.filename or str(probe_path)
            if Path(filename).resolve() == probe_path:
                raise RuntimeError(f"probe path became unreadable during scan: {probe_path} ({exc})") from exc
            self._warning(observer, self._warning_json("scan_error", Path(filename), exc))

        for root, dirnames, filenames in os.walk(probe_path, followlinks=False, onerror=_scan_error):
            dirnames[:] = sorted(
                name for name in dirnames if not Path(root, name).is_symlink()
            )
            for name in sorted(filenames):
                path = Path(root, name)
                try:
                    if path.is_symlink() or not path.is_file():
                        continue
                    stat_result = path.stat()
                except OSError as exc:
                    self._warning(observer, self._warning_json("scan_error", path, exc))
                    continue
                candidates.append(
                    FileCandidate(
                        path=path.resolve(),
                        mtime_ns=stat_result.st_mtime_ns,
                        file_size=stat_result.st_size,
                    )
                )
        candidates.sort(key=lambda item: str(item.path))
        return candidates

    def _process_candidate(
        self,
        *,
        connection: sqlite3.Connection,
        candidate: FileCandidate,
        run_started_at: str,
        observer: IndexingObserver,
        root_group_hash: str,
    ) -> int:
        existing_row = connection.execute(
            """
            SELECT
                files.id,
                files.content_id,
                files.mtime_ns,
                contents.file_size
            FROM files
            JOIN contents ON contents.id = files.content_id
            WHERE files.root_group_hash = ?
              AND files.file_path = ?
            """,
            (root_group_hash, str(candidate.path)),
        ).fetchone()
        existing = (
            KnownFileRecord(
                file_id=int(existing_row["id"]),
                content_id=int(existing_row["content_id"]),
                mtime_ns=int(existing_row["mtime_ns"]),
                file_size=int(existing_row["file_size"]),
            )
            if existing_row is not None
            else None
        )

        if (
            existing is not None
            and existing.mtime_ns == candidate.mtime_ns
            and existing.file_size == candidate.file_size
        ):
            observer.set_state("WRITING_DB", current_file=str(candidate.path))
            connection.execute(
                """
                UPDATE files
                SET last_seen_at = ?, missing = 0
                WHERE id = ?
                """,
                (run_started_at, existing.file_id),
            )
            return 1

        observer.set_state("HASHING", current_file=str(candidate.path))
        try:
            md5 = self._md5(candidate.path)
        except (FileNotFoundError, PermissionError, OSError) as exc:
            self._warning(observer, self._warning_json("hash_failed", candidate.path, exc))
            if existing is not None:
                self._mark_known_file_seen(
                    connection=connection,
                    file_id=existing.file_id,
                    run_started_at=run_started_at,
                )
            return 1

        observer.set_state("WRITING_DB", current_file=str(candidate.path))
        content_id = self._ensure_content(
            connection=connection,
            md5=md5,
            file_size=candidate.file_size,
            created_at=run_started_at,
        )
        self._upsert_file(
            connection=connection,
            root_group_hash=root_group_hash,
            content_id=content_id,
            candidate=candidate,
            run_started_at=run_started_at,
        )
        return 1

    @staticmethod
    def _md5(path: Path) -> str:
        digest = hashlib.md5()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    @staticmethod
    def _ensure_content(
        *,
        connection: sqlite3.Connection,
        md5: str,
        file_size: int,
        created_at: str,
    ) -> int:
        row = connection.execute(
            "SELECT id, file_size FROM contents WHERE md5 = ?",
            (md5,),
        ).fetchone()
        if row is not None:
            if int(row["file_size"]) != file_size:
                raise RuntimeError(f"content collision for md5 {md5}")
            return int(row["id"])

        cursor = connection.execute(
            """
            INSERT INTO contents(md5, file_size, created_at)
            VALUES(?, ?, ?)
            """,
            (md5, file_size, created_at),
        )
        return int(cursor.lastrowid)

    @staticmethod
    def _upsert_file(
        *,
        connection: sqlite3.Connection,
        root_group_hash: str,
        content_id: int,
        candidate: FileCandidate,
        run_started_at: str,
    ) -> None:
        connection.execute(
            """
            INSERT INTO files(
                root_group_hash,
                content_id,
                file_path,
                mtime_ns,
                missing,
                first_seen_at,
                last_seen_at
            )
            VALUES(?, ?, ?, ?, 0, ?, ?)
            ON CONFLICT(root_group_hash, file_path) DO UPDATE SET
                content_id = excluded.content_id,
                mtime_ns = excluded.mtime_ns,
                missing = 0,
                last_seen_at = excluded.last_seen_at
            """,
            (
                root_group_hash,
                content_id,
                str(candidate.path),
                candidate.mtime_ns,
                run_started_at,
                run_started_at,
            ),
        )

    @staticmethod
    def _mark_known_file_seen(
        *,
        connection: sqlite3.Connection,
        file_id: int,
        run_started_at: str,
    ) -> None:
        connection.execute(
            """
            UPDATE files
            SET last_seen_at = ?, missing = 0
            WHERE id = ?
            """,
            (run_started_at, file_id),
        )

    @staticmethod
    def _path_scope_where_sql(column: str, root_paths: tuple[Path, ...]) -> tuple[str, list[str]]:
        clauses: list[str] = []
        params: list[str] = []
        for root_path in root_paths:
            normalized = str(root_path.resolve())
            clauses.append(f"({column} = ? OR {column} LIKE ?)")
            params.extend([normalized, f"{normalized}{os.sep}%"])
        if not clauses:
            return "1 = 0", []
        return " OR ".join(clauses), params

    @staticmethod
    def _upsert_one_to_one(
        *,
        connection: sqlite3.Connection,
        table: str,
        content_id: int,
        payload: dict[str, Any],
    ) -> None:
        columns = ["content_id", *payload.keys()]
        placeholders = ", ".join("?" for _ in columns)
        update_clause = ", ".join(f"{name} = excluded.{name}" for name in payload)
        values = [content_id, *payload.values()]
        connection.execute(
            f"""
            INSERT INTO {table}({", ".join(columns)})
            VALUES({placeholders})
            ON CONFLICT(content_id) DO UPDATE SET
                {update_clause}
            """,
            values,
        )

    def _warning(self, observer: IndexingObserver, message: str) -> None:
        self.logger.warning(message)
        observer.warning(message)

    @staticmethod
    def _warning_json(kind: str, path: Path, error: Exception | str) -> str:
        detail = str(error)
        return json.dumps(
            {
                "level": "warning",
                "type": kind,
                "file": str(path),
                "error": detail,
            },
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )


class DaemonIndexingObserver:
    def __init__(self, runtime_state: "RuntimeStateController") -> None:
        self.runtime_state = runtime_state

    def set_state(
        self,
        state: str,
        *,
        current_file: str | None = None,
        current_content_id: int | None = None,
    ) -> None:
        self.runtime_state.set_state(state, current_file=current_file, current_content_id=current_content_id)

    def set_total(self, total_estimated: int) -> None:
        self.runtime_state.set_total(total_estimated)

    def set_selection_summary(self, selection_summary: dict[str, Any] | None) -> None:
        self.runtime_state.set_selection_summary(selection_summary)

    def advance(
        self,
        *,
        current_file: str | None = None,
        current_content_id: int | None = None,
        increment: int = 1,
    ) -> None:
        self.runtime_state.advance(
            current_file=current_file,
            current_content_id=current_content_id,
            increment=increment,
        )

    def check_control(self) -> str | None:
        return self.runtime_state.check_control()

    def warning(self, message: str) -> None:
        return None


class RuntimeStateController:
    def __init__(self, *, daemon_id: str, initial_state: dict[str, Any] | None = None) -> None:
        self._lock = threading.RLock()
        state = dict(initial_state or {})
        state.setdefault("schema_version", SCHEMA_VERSION)
        state.setdefault("daemon_id", daemon_id)
        state.setdefault("active_run_id", None)
        state.setdefault("active_job_type", None)
        state.setdefault("run_started_at", None)
        state.setdefault("current_state", "IDLE")
        state.setdefault("recovering", False)
        state.setdefault("current_file", None)
        state.setdefault("current_content_id", None)
        state.setdefault("processed", 0)
        state.setdefault("total_estimated", None)
        state.setdefault("selection_summary", None)
        state.setdefault("pause_requested", False)
        state.setdefault("stop_requested", False)
        state.setdefault("cadis_capability", None)
        state.setdefault("exiftool_capability", None)
        state.setdefault("daemon_runtime_manifest_hash", get_installed_runtime_manifest_hash())
        self._state = state
        self.persist()

    @property
    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return dict(self._state)

    def persist(self) -> None:
        write_run_state(dict(self._state))

    def new_run(
        self,
        *,
        recovering: bool = False,
        job_type: str = "indexing",
        initial_state: str = "SCANNING",
    ) -> dict[str, Any]:
        with self._lock:
            self._state.update(
                {
                    "active_run_id": new_identifier(),
                    "active_job_type": job_type,
                    "run_started_at": utc_now(),
                    "current_state": "RECOVERING" if recovering else initial_state,
                    "recovering": recovering,
                    "current_file": None,
                    "current_content_id": None,
                    "processed": 0,
                    "total_estimated": None,
                    "selection_summary": None,
                    "pause_requested": False,
                    "stop_requested": False,
                    "error": None,
                }
            )
            self.persist()
            return dict(self._state)

    def set_cadis_capability(self, snapshot: CadisCapabilitySnapshot) -> None:
        with self._lock:
            self._state["cadis_capability"] = {
                "cadis_version": snapshot.cadis_version,
                "installed_iso2": list(snapshot.installed_iso2),
                "supported_iso2": list(snapshot.supported_iso2),
                "dataset_lockdown_enabled": snapshot.dataset_lockdown_enabled,
                "allowed_iso2": list(snapshot.allowed_iso2),
                "effective_allowed_iso2": list(snapshot.effective_allowed_iso2),
            }
            self.persist()

    def set_exiftool_capability(self, snapshot: dict[str, Any]) -> None:
        with self._lock:
            self._state["exiftool_capability"] = dict(snapshot)
            self.persist()

    def set_state(
        self,
        state: str,
        *,
        current_file: str | None = None,
        current_content_id: int | None = None,
    ) -> None:
        with self._lock:
            self._state["current_state"] = state
            self._state["current_file"] = current_file
            self._state["current_content_id"] = current_content_id
            self.persist()

    def set_total(self, total_estimated: int) -> None:
        with self._lock:
            self._state["total_estimated"] = total_estimated
            self.persist()

    def set_selection_summary(self, selection_summary: dict[str, Any] | None) -> None:
        with self._lock:
            self._state["selection_summary"] = selection_summary
            self.persist()

    def advance(
        self,
        *,
        current_file: str | None = None,
        current_content_id: int | None = None,
        increment: int = 1,
    ) -> None:
        with self._lock:
            self._state["processed"] = int(self._state.get("processed", 0)) + increment
            self._state["current_file"] = current_file
            self._state["current_content_id"] = current_content_id
            self.persist()

    def request_pause(self) -> None:
        with self._lock:
            self._state["pause_requested"] = True
            self._state["stop_requested"] = False
            self._state["current_state"] = "STOPPING"
            self.persist()

    def request_stop(self) -> None:
        with self._lock:
            self._state["stop_requested"] = True
            self._state["pause_requested"] = False
            self._state["current_state"] = "STOPPING"
            self.persist()

    def check_control(self) -> str | None:
        with self._lock:
            if self._state.get("pause_requested"):
                return "pause"
            if self._state.get("stop_requested"):
                return "stop"
            return None

    def finish_completed(self, *, indexed_count: int | None = None) -> None:
        completed_at = utc_now()
        state_changes: dict[str, Any] = {
            "index_status": "idle",
            "last_completed_run_at": completed_at,
        }
        if indexed_count is not None:
            state_changes.update(
                {
                    "last_index_time": completed_at,
                    "indexed_count": indexed_count,
                }
            )
        update_state(**state_changes)
        with self._lock:
            artifact = self._artifact_payload(completed_at=completed_at, terminal_state="IDLE")
            run_id = str(self._state.get("active_run_id") or "")
            artifact_path = None
            if run_id:
                artifact_path = str(write_run_artifact(run_id, artifact))
            self._state.update(
                {
                    "active_run_id": None,
                    "active_job_type": None,
                    "run_started_at": None,
                    "current_state": "IDLE",
                    "recovering": False,
                    "current_file": None,
                    "current_content_id": None,
                    "pause_requested": False,
                    "stop_requested": False,
                    "error": None,
                    "last_run_artifact_path": artifact_path,
                    "last_run_terminal_state": "IDLE",
                    "last_run_job_type": artifact.get("job_type"),
                }
            )
            self.persist()

    def finish_paused(self) -> None:
        update_state(index_status="paused")
        with self._lock:
            artifact = self._artifact_payload(completed_at=utc_now(), terminal_state="PAUSED")
            run_id = str(self._state.get("active_run_id") or "")
            artifact_path = None
            if run_id:
                artifact_path = str(write_run_artifact(run_id, artifact))
            self._state.update(
                {
                    "active_run_id": None,
                    "active_job_type": None,
                    "run_started_at": None,
                    "current_state": "PAUSED",
                    "recovering": False,
                    "current_file": None,
                    "current_content_id": None,
                    "pause_requested": False,
                    "stop_requested": False,
                    "error": None,
                    "last_run_artifact_path": artifact_path,
                    "last_run_terminal_state": "PAUSED",
                    "last_run_job_type": artifact.get("job_type"),
                }
            )
            self.persist()

    def finish_stopped(self) -> None:
        update_state(index_status="idle")
        with self._lock:
            artifact = self._artifact_payload(completed_at=utc_now(), terminal_state="IDLE")
            run_id = str(self._state.get("active_run_id") or "")
            artifact_path = None
            if run_id:
                artifact_path = str(write_run_artifact(run_id, artifact))
            self._state.update(
                {
                    "active_run_id": None,
                    "active_job_type": None,
                    "run_started_at": None,
                    "current_state": "IDLE",
                    "recovering": False,
                    "current_file": None,
                    "current_content_id": None,
                    "pause_requested": False,
                    "stop_requested": False,
                    "error": None,
                    "last_run_artifact_path": artifact_path,
                    "last_run_terminal_state": "IDLE",
                    "last_run_job_type": artifact.get("job_type"),
                }
            )
            self.persist()

    def finish_failed(self, *, error: str) -> None:
        update_state(index_status="failed")
        with self._lock:
            artifact = self._artifact_payload(completed_at=utc_now(), terminal_state="FAILED", error=error)
            run_id = str(self._state.get("active_run_id") or "")
            artifact_path = None
            if run_id:
                artifact_path = str(write_run_artifact(run_id, artifact))
            self._state.update(
                {
                    "active_run_id": None,
                    "active_job_type": None,
                    "current_state": "FAILED",
                    "recovering": False,
                    "current_file": None,
                    "current_content_id": None,
                    "stop_requested": False,
                    "pause_requested": False,
                    "error": error,
                    "last_run_artifact_path": artifact_path,
                    "last_run_terminal_state": "FAILED",
                    "last_run_job_type": artifact.get("job_type"),
                }
            )
            self.persist()

    def _artifact_payload(self, *, completed_at: str, terminal_state: str, error: str | None = None) -> dict[str, Any]:
        storage_paths = get_storage_paths()
        return {
            "run_id": self._state.get("active_run_id"),
            "job_type": self._state.get("active_job_type"),
            "daemon_id": self._state.get("daemon_id"),
            "started_at": self._state.get("run_started_at"),
            "completed_at": completed_at,
            "terminal_state": terminal_state,
            "processed": self._state.get("processed"),
            "total_estimated": self._state.get("total_estimated"),
            "selection_summary": self._state.get("selection_summary"),
            "recovering": self._state.get("recovering"),
            "current_file": self._state.get("current_file"),
            "current_content_id": self._state.get("current_content_id"),
            "cadis_capability": self._state.get("cadis_capability"),
            "exiftool_capability": self._state.get("exiftool_capability"),
            "daemon_runtime_manifest_hash": self._state.get("daemon_runtime_manifest_hash"),
            "installed_runtime_manifest_hash": get_installed_runtime_manifest_hash(),
            "runtime_root": str(storage_paths.root),
            "error": error,
        }


def detect_incomplete_run(run_state: dict[str, Any]) -> bool:
    current_state = str(run_state.get("current_state", "IDLE")).upper()
    return current_state not in {"IDLE", "PAUSED", "FAILED"} and bool(run_state.get("active_run_id"))
def current_batch_size() -> int:
    return 100
