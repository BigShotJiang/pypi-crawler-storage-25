from __future__ import annotations

import hashlib
import json
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from eona.gateway_paths import GatewayPaths


INPUT_MANIFEST_VERSION = 1


@dataclass(frozen=True)
class GatewayRunPaths:
    run_id: str
    run_dir: Path
    input_dir: Path
    artifacts_dir: Path
    logs_dir: Path
    tmp_dir: Path
    run_json: Path
    input_manifest: Path


def get_run_paths(*, paths: GatewayPaths, run_id: str) -> GatewayRunPaths:
    run_dir = paths.runs_dir / run_id
    return GatewayRunPaths(
        run_id=run_id,
        run_dir=run_dir,
        input_dir=run_dir / "input",
        artifacts_dir=run_dir / "artifacts",
        logs_dir=run_dir / "logs",
        tmp_dir=run_dir / "tmp",
        run_json=run_dir / "run.json",
        input_manifest=run_dir / "input_manifest.json",
    )


def ensure_run_layout(*, paths: GatewayPaths, run_id: str) -> GatewayRunPaths:
    resolved = get_run_paths(paths=paths, run_id=run_id)
    for directory in (
        resolved.run_dir,
        resolved.input_dir,
        resolved.artifacts_dir,
        resolved.logs_dir,
        resolved.tmp_dir,
    ):
        directory.mkdir(parents=True, exist_ok=True)
    return resolved


def atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        "w",
        encoding="utf-8",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")
        temp_path = Path(handle.name)
    temp_path.replace(path)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))
