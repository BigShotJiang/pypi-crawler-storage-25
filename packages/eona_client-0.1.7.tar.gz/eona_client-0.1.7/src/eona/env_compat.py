from __future__ import annotations

import os


def compat_env(*names: str, default: str | None = None) -> str | None:
    for name in names:
        value = os.environ.get(name)
        if value is not None:
            return value
    return default


def compat_env_truthy(*names: str, default: bool = False) -> bool:
    value = compat_env(*names)
    if value is None:
        return default
    return value.strip().lower() not in {"", "0", "false", "no", "off"}
