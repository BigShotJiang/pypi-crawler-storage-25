from __future__ import annotations

from pathlib import Path
from typing import Any

from eona.gateway_db import connect_database, utc_now
from eona.gateway_paths import GatewayPaths, ensure_gateway_layout, get_gateway_paths

GATEWAY_SCHEMA_VERSION = 1


def initialize_gateway_storage(*, force: bool = False, paths: GatewayPaths | None = None) -> dict[str, Any]:
    resolved = ensure_gateway_layout(paths or get_gateway_paths())
    if force and resolved.database.exists():
        resolved.database.unlink()

    with connect_database(resolved) as connection:
        _create_schema(connection)
        _migrate_schema(connection)
        connection.execute("DELETE FROM gateway_schema_version")
        connection.execute(
            "INSERT INTO gateway_schema_version(version, applied_at) VALUES (?, ?)",
            (GATEWAY_SCHEMA_VERSION, utc_now()),
        )

    return {
        "ok": True,
        "summary": "Gateway database initialized.",
        "database": str(resolved.database),
        "root": str(resolved.root),
        "schema_version": GATEWAY_SCHEMA_VERSION,
    }


def _create_schema(connection) -> None:
    connection.executescript(
        """
        CREATE TABLE IF NOT EXISTS gateway_schema_version (
            version INTEGER PRIMARY KEY,
            applied_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS gateway_runtime_state (
            state_key TEXT PRIMARY KEY,
            current_runtime_identity_json TEXT NOT NULL,
            previous_runtime_identity_json TEXT,
            module_results_json TEXT NOT NULL,
            lifecycle_state TEXT NOT NULL,
            summary TEXT NOT NULL,
            details_json TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS content (
            content_id TEXT PRIMARY KEY,
            canonical_spec_version INTEGER NOT NULL,
            storage_relpath TEXT NOT NULL UNIQUE,
            mime_type TEXT NOT NULL,
            byte_size INTEGER NOT NULL,
            width INTEGER NOT NULL,
            height INTEGER NOT NULL,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS photo (
            photo_id TEXT PRIMARY KEY,
            content_id TEXT NOT NULL REFERENCES content(content_id),
            photo_signature TEXT NOT NULL,
            photo_signature_version INTEGER NOT NULL,
            signature_payload_json TEXT NOT NULL,
            taken_at_utc TEXT,
            taken_at_original TEXT,
            raw_latitude REAL,
            raw_longitude REAL,
            raw_altitude REAL,
            cadis_result_json TEXT,
            cadis_version TEXT,
            location_detail TEXT,
            camera_make TEXT,
            camera_model TEXT,
            created_at TEXT NOT NULL,
            UNIQUE (content_id, photo_signature, photo_signature_version)
        );

        CREATE TABLE IF NOT EXISTS import_session (
            import_id TEXT PRIMARY KEY,
            status TEXT NOT NULL CHECK (status IN ('collecting', 'committing', 'committed', 'failed', 'expired')),
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            committed_at TEXT,
            import_run_id TEXT REFERENCES import_run(run_id),
            error_code TEXT,
            error_message TEXT
        );

        CREATE TABLE IF NOT EXISTS import_file (
            import_file_id TEXT PRIMARY KEY,
            import_id TEXT NOT NULL REFERENCES import_session(import_id),
            client_filename TEXT NOT NULL,
            source_path_text TEXT NOT NULL,
            staging_relpath TEXT NOT NULL UNIQUE,
            path_hint TEXT,
            byte_size INTEGER,
            created_at TEXT NOT NULL,
            committed_at TEXT
        );

        CREATE TABLE IF NOT EXISTS import_run (
            run_id TEXT PRIMARY KEY,
            source_import_id TEXT NOT NULL UNIQUE REFERENCES import_session(import_id),
            status TEXT NOT NULL CHECK (status IN ('queued', 'running', 'complete', 'failed', 'cancelled')),
            current_stage TEXT,
            progress REAL NOT NULL DEFAULT 0,
            started_at TEXT,
            completed_at TEXT,
            created_at TEXT NOT NULL,
            error_code TEXT,
            error_message TEXT,
            report_json TEXT
        );

        CREATE TABLE IF NOT EXISTS import_run_item (
            run_id TEXT NOT NULL REFERENCES import_run(run_id),
            import_file_id TEXT NOT NULL REFERENCES import_file(import_file_id),
            source_path_text TEXT,
            status TEXT NOT NULL DEFAULT 'pending',
            photo_id TEXT REFERENCES photo(photo_id),
            content_id TEXT REFERENCES content(content_id),
            error_code TEXT,
            error_message TEXT,
            PRIMARY KEY (run_id, import_file_id)
        );

        CREATE TABLE IF NOT EXISTS import_run_control (
            run_id TEXT PRIMARY KEY REFERENCES import_run(run_id),
            desired_state TEXT NOT NULL CHECK (desired_state IN ('pause_requested', 'paused')),
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS photo_path_observation (
            photo_id TEXT NOT NULL REFERENCES photo(photo_id),
            path_text TEXT NOT NULL,
            first_seen_run_id TEXT NOT NULL REFERENCES import_run(run_id),
            created_at TEXT NOT NULL,
            PRIMARY KEY (photo_id, path_text)
        );

        CREATE TABLE IF NOT EXISTS photo_duplicate_semantic (
            photo_id TEXT PRIMARY KEY REFERENCES photo(photo_id),
            duplicate_semantic_version INTEGER NOT NULL,
            duplicate_cluster_id TEXT NOT NULL,
            duplicate_role TEXT NOT NULL CHECK (duplicate_role IN ('singleton', 'primary', 'duplicate')),
            duplicate_reason TEXT NOT NULL,
            computed_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS photo_tag_semantic (
            photo_id TEXT NOT NULL REFERENCES photo(photo_id),
            tag_key TEXT NOT NULL,
            tag_value TEXT NOT NULL,
            tag_source TEXT NOT NULL,
            tag_strength TEXT,
            semantic_version INTEGER NOT NULL,
            computed_at TEXT NOT NULL,
            PRIMARY KEY (photo_id, tag_key)
        );

        CREATE TABLE IF NOT EXISTS semantic_enrichment_job (
            job_name TEXT PRIMARY KEY,
            semantic_version INTEGER NOT NULL,
            status TEXT NOT NULL CHECK (status IN ('pending', 'running', 'completed', 'failed')),
            summary TEXT NOT NULL,
            total_rows INTEGER NOT NULL DEFAULT 0,
            processed_rows INTEGER NOT NULL DEFAULT 0,
            updated_rows INTEGER NOT NULL DEFAULT 0,
            failed_rows INTEGER NOT NULL DEFAULT 0,
            last_error TEXT,
            started_at TEXT,
            completed_at TEXT,
            updated_at TEXT NOT NULL
        );

        CREATE UNIQUE INDEX IF NOT EXISTS idx_photo_identity
            ON photo(content_id, photo_signature, photo_signature_version);
        CREATE UNIQUE INDEX IF NOT EXISTS idx_photo_path_unique
            ON photo_path_observation(photo_id, path_text);
        CREATE INDEX IF NOT EXISTS idx_photo_duplicate_cluster
            ON photo_duplicate_semantic(duplicate_cluster_id);
        CREATE INDEX IF NOT EXISTS idx_photo_duplicate_role
            ON photo_duplicate_semantic(duplicate_role);
        CREATE INDEX IF NOT EXISTS idx_photo_tag_key_value
            ON photo_tag_semantic(tag_key, tag_value);
        CREATE INDEX IF NOT EXISTS idx_semantic_enrichment_status
            ON semantic_enrichment_job(status);
        CREATE INDEX IF NOT EXISTS idx_import_run_status_created
            ON import_run(status, created_at);
        CREATE INDEX IF NOT EXISTS idx_import_file_session
            ON import_file(import_id);

        """
    )
    _recreate_query_views(connection)


def _migrate_schema(connection) -> None:
    connection.executescript(
        """
        CREATE TABLE IF NOT EXISTS gateway_runtime_state (
            state_key TEXT PRIMARY KEY,
            current_runtime_identity_json TEXT NOT NULL,
            previous_runtime_identity_json TEXT,
            module_results_json TEXT NOT NULL,
            lifecycle_state TEXT NOT NULL,
            summary TEXT NOT NULL,
            details_json TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS photo_duplicate_semantic (
            photo_id TEXT PRIMARY KEY REFERENCES photo(photo_id),
            duplicate_semantic_version INTEGER NOT NULL,
            duplicate_cluster_id TEXT NOT NULL,
            duplicate_role TEXT NOT NULL CHECK (duplicate_role IN ('singleton', 'primary', 'duplicate')),
            duplicate_reason TEXT NOT NULL,
            computed_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS photo_tag_semantic (
            photo_id TEXT NOT NULL REFERENCES photo(photo_id),
            tag_key TEXT NOT NULL,
            tag_value TEXT NOT NULL,
            tag_source TEXT NOT NULL,
            tag_strength TEXT,
            semantic_version INTEGER NOT NULL,
            computed_at TEXT NOT NULL,
            PRIMARY KEY (photo_id, tag_key)
        );
        CREATE TABLE IF NOT EXISTS semantic_enrichment_job (
            job_name TEXT PRIMARY KEY,
            semantic_version INTEGER NOT NULL,
            status TEXT NOT NULL CHECK (status IN ('pending', 'running', 'completed', 'failed')),
            summary TEXT NOT NULL,
            total_rows INTEGER NOT NULL DEFAULT 0,
            processed_rows INTEGER NOT NULL DEFAULT 0,
            updated_rows INTEGER NOT NULL DEFAULT 0,
            failed_rows INTEGER NOT NULL DEFAULT 0,
            last_error TEXT,
            started_at TEXT,
            completed_at TEXT,
            updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_photo_duplicate_cluster
            ON photo_duplicate_semantic(duplicate_cluster_id);
        CREATE INDEX IF NOT EXISTS idx_photo_duplicate_role
            ON photo_duplicate_semantic(duplicate_role);
        CREATE INDEX IF NOT EXISTS idx_photo_tag_key_value
            ON photo_tag_semantic(tag_key, tag_value);
        CREATE INDEX IF NOT EXISTS idx_semantic_enrichment_status
            ON semantic_enrichment_job(status);
        """
    )
    columns = {
        str(row[1])
        for row in connection.execute("PRAGMA table_info(photo)").fetchall()
    }
    if "taken_at_original" not in columns:
        connection.execute("ALTER TABLE photo ADD COLUMN taken_at_original TEXT")
    if "cadis_result_json" not in columns:
        connection.execute("ALTER TABLE photo ADD COLUMN cadis_result_json TEXT")
    if "cadis_version" not in columns:
        connection.execute("ALTER TABLE photo ADD COLUMN cadis_version TEXT")
    if "location_detail" not in columns:
        connection.execute("ALTER TABLE photo ADD COLUMN location_detail TEXT")
    import_file_columns = {
        str(row[1])
        for row in connection.execute("PRAGMA table_info(import_file)").fetchall()
    }
    if "source_path_text" not in import_file_columns:
        connection.execute("ALTER TABLE import_file ADD COLUMN source_path_text TEXT NOT NULL DEFAULT ''")
        connection.execute(
            """
            UPDATE import_file
            SET source_path_text = staging_relpath
            WHERE source_path_text = ''
            """
        )
    semantic_job_columns = {
        str(row[1])
        for row in connection.execute("PRAGMA table_info(semantic_enrichment_job)").fetchall()
    }
    if "total_rows" not in semantic_job_columns:
        connection.execute("ALTER TABLE semantic_enrichment_job ADD COLUMN total_rows INTEGER NOT NULL DEFAULT 0")
    _recreate_query_views(connection)


def _recreate_query_views(connection) -> None:
    connection.executescript(
        """
        DROP VIEW IF EXISTS gateway_query_photo_v1;
        CREATE VIEW gateway_query_photo_v1 AS
        SELECT
            photo.photo_id AS photo_id,
            photo.content_id AS content_id,
            photo.taken_at_utc AS taken_at_utc,
            CASE
                WHEN photo.taken_at_utc IS NOT NULL THEN CAST(strftime('%Y', photo.taken_at_utc) AS INTEGER)
                ELSE NULL
            END AS year,
            CASE
                WHEN photo.taken_at_utc IS NOT NULL THEN CAST(strftime('%m', photo.taken_at_utc) AS INTEGER)
                ELSE NULL
            END AS month,
            CASE
                WHEN photo.taken_at_utc IS NOT NULL THEN CAST(strftime('%d', photo.taken_at_utc) AS INTEGER)
                ELSE NULL
            END AS day,
            photo.camera_make AS camera_make,
            photo.camera_model AS camera_model
        FROM photo;

        DROP VIEW IF EXISTS gateway_query_photo_v2;
        CREATE VIEW gateway_query_photo_v2 AS
        SELECT
            photo.photo_id AS photo_id,
            photo.content_id AS content_id,
            photo.taken_at_utc AS taken_at_utc,
            photo.taken_at_original AS taken_at_original,
            CASE
                WHEN photo.taken_at_utc IS NOT NULL THEN CAST(strftime('%Y', photo.taken_at_utc) AS INTEGER)
                WHEN photo.taken_at_original LIKE '____:__:__%' THEN CAST(substr(photo.taken_at_original, 1, 4) AS INTEGER)
                ELSE NULL
            END AS query_year,
            CASE
                WHEN photo.taken_at_utc IS NOT NULL THEN CAST(strftime('%m', photo.taken_at_utc) AS INTEGER)
                WHEN photo.taken_at_original LIKE '____:__:__%' THEN CAST(substr(photo.taken_at_original, 6, 2) AS INTEGER)
                ELSE NULL
            END AS query_month,
            CASE
                WHEN photo.taken_at_utc IS NOT NULL THEN CAST(strftime('%d', photo.taken_at_utc) AS INTEGER)
                WHEN photo.taken_at_original LIKE '____:__:__%' THEN CAST(substr(photo.taken_at_original, 9, 2) AS INTEGER)
                ELSE NULL
            END AS query_day,
            CASE
                WHEN photo.taken_at_utc IS NOT NULL THEN 'utc'
                WHEN photo.taken_at_original LIKE '____:__:__%' THEN 'original'
                ELSE 'unknown'
            END AS query_time_source,
            duplicate.duplicate_cluster_id AS duplicate_cluster_id,
            COALESCE(duplicate.duplicate_role, 'singleton') AS duplicate_role,
            COALESCE(duplicate.duplicate_reason, 'none') AS duplicate_reason,
            CASE
                WHEN duplicate.duplicate_role = 'duplicate' THEN 1
                ELSE 0
            END AS duplicate_exclude_by_default,
            photo.camera_make AS camera_make,
            photo.camera_model AS camera_model
        FROM photo
        LEFT JOIN photo_duplicate_semantic AS duplicate ON duplicate.photo_id = photo.photo_id;

        DROP VIEW IF EXISTS gateway_query_path_v1;
        CREATE VIEW gateway_query_path_v1 AS
        SELECT
            photo_id,
            path_text
        FROM photo_path_observation;

        DROP VIEW IF EXISTS gateway_query_location_v2;
        CREATE VIEW gateway_query_location_v2 AS
        SELECT
            photo.photo_id AS photo_id,
            CASE
                WHEN photo.cadis_result_json IS NOT NULL AND json_valid(photo.cadis_result_json)
                    THEN COALESCE(
                        json_extract(photo.cadis_result_json, '$.result.country.name'),
                        CASE
                            WHEN json_extract(photo.cadis_result_json, '$.state.world.classification') = 'country'
                                THEN json_extract(photo.cadis_result_json, '$.state.world.name')
                            ELSE NULL
                        END
                    )
                ELSE NULL
            END AS query_country,
            CASE
                WHEN photo.cadis_result_json IS NOT NULL AND json_valid(photo.cadis_result_json)
                    THEN (
                        SELECT group_concat(name, ' / ')
                        FROM (
                            SELECT json_extract(json_each.value, '$.name') AS name
                            FROM json_each(photo.cadis_result_json, '$.result.admin_hierarchy')
                            WHERE json_extract(json_each.value, '$.name') IS NOT NULL
                            ORDER BY CAST(json_each.key AS INTEGER)
                        )
                    )
                ELSE NULL
            END AS query_admin_label,
            CASE
                WHEN photo.cadis_result_json IS NOT NULL AND json_valid(photo.cadis_result_json)
                    THEN (
                        SELECT json_group_array(name)
                        FROM (
                            SELECT json_extract(json_each.value, '$.name') AS name
                            FROM json_each(photo.cadis_result_json, '$.result.admin_hierarchy')
                            WHERE json_extract(json_each.value, '$.name') IS NOT NULL
                            ORDER BY CAST(json_each.key AS INTEGER)
                        )
                    )
                ELSE NULL
            END AS query_admin_path,
            CASE
                WHEN photo.cadis_result_json IS NOT NULL
                    AND json_valid(photo.cadis_result_json)
                    AND (
                        COALESCE(
                            json_extract(photo.cadis_result_json, '$.result.country.name'),
                            CASE
                                WHEN json_extract(photo.cadis_result_json, '$.state.world.classification') = 'country'
                                    THEN json_extract(photo.cadis_result_json, '$.state.world.name')
                                ELSE NULL
                            END
                        ) IS NOT NULL
                        OR (
                            SELECT group_concat(name, ' / ')
                            FROM (
                                SELECT json_extract(json_each.value, '$.name') AS name
                                FROM json_each(photo.cadis_result_json, '$.result.admin_hierarchy')
                                WHERE json_extract(json_each.value, '$.name') IS NOT NULL
                                ORDER BY CAST(json_each.key AS INTEGER)
                            )
                        ) IS NOT NULL
                    ) THEN 'strict_geo'
                ELSE 'unknown'
            END AS query_location_source
        FROM photo;

        DROP VIEW IF EXISTS gateway_query_duplicate_v1;
        CREATE VIEW gateway_query_duplicate_v1 AS
        SELECT
            photo.photo_id AS photo_id,
            duplicate.duplicate_cluster_id AS duplicate_cluster_id,
            COALESCE(duplicate.duplicate_role, 'singleton') AS duplicate_role,
            COALESCE(duplicate.duplicate_reason, 'none') AS duplicate_reason,
            CASE
                WHEN duplicate.duplicate_role = 'duplicate' THEN 1
                ELSE 0
            END AS exclude_by_default
        FROM photo
        LEFT JOIN photo_duplicate_semantic AS duplicate ON duplicate.photo_id = photo.photo_id;

        DROP VIEW IF EXISTS gateway_query_tag_v1;
        CREATE VIEW gateway_query_tag_v1 AS
        SELECT
            photo_id,
            tag_key,
            tag_value
        FROM photo_tag_semantic;
        """
    )
