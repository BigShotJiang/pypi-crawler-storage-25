# Eona

Eona is a personal photo-memory system with a protected Gateway backend, an operator CLI, and a query-oriented agent workflow.

Current public operator surface:

- `eona`
  local workspace CLI for agent-embedded imports, status, and semantic backfill without any network boundary
- `eona-gateway`
  local self-host service lifecycle and administration
- `eona-client`
  operator actions against an existing Gateway

Interface split:

- `eona`
  local-only workspace operations such as `eona import <path>`, `eona status`, and `eona backfill-*`
- `eona-gateway`
  host/port-bound service mode with health, readiness, and access-token policy
- `eona-client`
  remote/operator access to a running Gateway over URL and bearer token

Public distribution split:

- `eona-macos-arm64-<version>.tar.gz`
  primary self-host release containing `eona`, `eona-gateway`, and local runtime assets
- `eona_client-<version>-py3-none-any.whl` and `eona_client-<version>.tar.gz`
  supplemental Python client package containing `eona-client` only

`eona-client` is a lightweight Python client for interacting with a running remote or local `eona-gateway`.
The full Eona runtime, including `eona` and `eona-gateway`, is distributed via GitHub Releases.

## Start Here

- [Install / Upgrade / Maintain](docs/install-upgrade-maintain.md)
- [Import Photos Locally and Remotely](docs/import-photos-locally-remotely.md)
- [Query Semantically](docs/query-semantically.md)
- [Deploy](docs/deploy.md)

## Repo Layout

- `src/eona/`
  current implementation namespace
- `docs/`
  canonical Eona runbooks
- `manifests/`
  release and curation manifests
- `integrations/openclaw/skills/`
  agent-facing lookup and publish workflows
- `deploy/docker/`
  Docker realization for Eona Gateway
- `contracts/` and `artifacts/`
  sealed runtime contracts and assets
