"""Public-slice harness for the CONJURE transformative-creativity benchmark.

This package ships the 358-instance public split (70 percent of the
510-instance Phase 4.6 frozen corpus across 17 Lakatos families).
See README.md for the full description and the hidden-split policy.
"""

from __future__ import annotations

from .corpus import (
    PUBLIC_CORPUS_PATH,
    Instance,
    load_public_corpus,
    public_instance_ids,
    public_instance_by_id,
)

__all__ = [
    "PUBLIC_CORPUS_PATH",
    "Instance",
    "load_public_corpus",
    "public_instance_ids",
    "public_instance_by_id",
    "__version__",
]

__version__ = "0.2.0"
