"""Public capcard CLI."""

from __future__ import annotations

import json
from pathlib import Path
import sys

import click

from .parser import enrich
from .publisher import publish_card
from .validator import validate_card_file


@click.group()
@click.version_option(package_name="capcard")
def cli() -> None:
    """Generate, validate, and publish Capability Cards."""


def _write_payload(record: dict, pretty: bool, output: Path | None) -> None:
    indent = 2 if pretty else None
    payload = json.dumps(record, indent=indent) + "\n"
    if output is not None:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(payload, encoding="utf-8")
        click.echo(f"Wrote Capability Card to {output}")
    else:
        click.echo(payload, nl=False)


@cli.command("enrich")
@click.argument("spec_url")
@click.option(
    "--trust-tier", type=click.IntRange(1, 6), default=None,
    help="Trust tier (1–6) to apply quality score cap (optional).",
)
@click.option(
    "--pretty/--compact", default=True,
    help="Pretty-print JSON output (default: pretty).",
)
@click.option(
    "--output",
    type=click.Path(path_type=Path, dir_okay=False),
    default=None,
    help="Write the generated Capability Card to a file instead of stdout.",
)
@click.option(
    "--provider",
    type=click.Choice(["auto", "anthropic", "openai", "gemini", "deterministic"], case_sensitive=False),
    default="auto",
    show_default=True,
    help="LLM provider to use for enrichment, or deterministic for no-key generation.",
)
def enrich_cmd(
    spec_url: str,
    trust_tier: int | None,
    pretty: bool,
    output: Path | None,
    provider: str,
) -> None:
    """Generate a Capability Card from an OpenAPI spec or MCP manifest."""
    try:
        record = enrich(spec_url, trust_tier=trust_tier, provider=provider, include_embedding=False)
        _write_payload(record, pretty=pretty, output=output)
    except EnvironmentError as exc:
        click.echo(f"Configuration error: {exc}", err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(f"Error: {exc}", err=True)
        sys.exit(1)


@cli.command("init")
@click.argument("spec_url")
@click.option(
    "--output",
    type=click.Path(path_type=Path, dir_okay=False),
    default=Path("capability-card.json"),
    show_default=True,
    help="Output file for the generated Capability Card.",
)
@click.option(
    "--provider",
    type=click.Choice(["auto", "anthropic", "openai", "gemini", "deterministic"], case_sensitive=False),
    default="auto",
    show_default=True,
    help="LLM provider to use for enrichment, or deterministic for no-key generation.",
)
@click.option(
    "--publish-target",
    type=click.Choice(["none", "static-dir", "github-pages", "vercel", "netlify", "cloudflare-pages"], case_sensitive=False),
    default="none",
    show_default=True,
    help="Optionally publish the generated file into a deployable site directory.",
)
@click.option(
    "--site-dir",
    type=click.Path(path_type=Path, file_okay=False),
    default=Path("."),
    show_default=True,
    help="Site root where /.well-known/ should be created when publishing.",
)
def init_cmd(spec_url: str, output: Path, provider: str, publish_target: str, site_dir: Path) -> None:
    """Generate a Capability Card starter file and optionally publish it."""
    try:
        record = enrich(spec_url, provider=provider, include_embedding=False)
        _write_payload(record, pretty=True, output=output)
        click.echo("Capability Card initialized.")
        if publish_target != "none":
            result = publish_card(card_path=output, site_dir=site_dir, target=publish_target)
            click.echo(f"Published Capability Card to {result['output_path']}")
            for line in result["next_steps"]:
                click.echo(f"- {line}")
    except EnvironmentError as exc:
        click.echo(f"Configuration error: {exc}", err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(f"Error: {exc}", err=True)
        sys.exit(1)


@cli.command("validate")
@click.argument("card_path", type=click.Path(path_type=Path, exists=True, dir_okay=False))
def validate_cmd(card_path: Path) -> None:
    """Validate a Capability Card JSON file against the public schema."""
    try:
        result = validate_card_file(card_path)
        click.echo(f"Valid Capability Card: {result['id']}")
        click.echo(f"Provider: {result['provider_name']} ({result['provider_domain']})")
        click.echo(f"Source type: {result['source_type']}")
    except Exception as exc:
        click.echo(f"Validation error: {exc}", err=True)
        sys.exit(1)


@cli.command("publish")
@click.argument("card_path", type=click.Path(path_type=Path, exists=True, dir_okay=False))
@click.option(
    "--target",
    type=click.Choice(["static-dir", "github-pages", "vercel", "netlify", "cloudflare-pages"], case_sensitive=False),
    default="static-dir",
    show_default=True,
    help="Publishing helper to use.",
)
@click.option(
    "--site-dir",
    type=click.Path(path_type=Path, file_okay=False),
    default=Path("."),
    show_default=True,
    help="Site root where /.well-known/ should be created.",
)
def publish_cmd(card_path: Path, target: str, site_dir: Path) -> None:
    """Copy a validated Capability Card into a deployable /.well-known path."""
    try:
        result = publish_card(card_path=card_path, site_dir=site_dir, target=target)
        click.echo(f"Published Capability Card to {result['output_path']}")
        for line in result["next_steps"]:
            click.echo(f"- {line}")
    except Exception as exc:
        click.echo(f"Publish error: {exc}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    cli()
