"""Public validation helpers for Capability Cards."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .schema import CapabilityRecord


def validate_card_file(card_path: Path) -> dict[str, Any]:
    """Validate a Capability Card JSON file and return normalized data."""
    try:
        raw = json.loads(card_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"{card_path} is not valid JSON: {exc}") from exc

    record = CapabilityRecord.model_validate(raw)
    return record.model_dump(mode="json")
