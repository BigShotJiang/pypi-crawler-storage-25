"""Public publishing helpers for Capability Cards."""

from __future__ import annotations

import json
from pathlib import Path

from .validator import validate_card_file


_GITHUB_PAGES_INDEX = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Capability Card Published</title>
  <style>
    body { font-family: ui-sans-serif, system-ui, sans-serif; max-width: 720px; margin: 48px auto; padding: 0 20px; line-height: 1.6; }
    code { background: #f4f4f5; padding: 2px 6px; border-radius: 4px; }
  </style>
</head>
<body>
  <h1>Capability Card Published</h1>
  <p>This site publishes a Capability Card at <code>/.well-known/capability-card.json</code>.</p>
</body>
</html>
"""


def publish_card(card_path: Path, site_dir: Path, target: str) -> dict[str, object]:
    """Validate and copy a Capability Card into a deployable site directory."""
    site_dir = site_dir.resolve()
    record = validate_card_file(card_path)

    well_known_dir = site_dir / ".well-known"
    well_known_dir.mkdir(parents=True, exist_ok=True)

    output_path = well_known_dir / "capability-card.json"
    output_path.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")

    next_steps = [
        f"Deploy {site_dir} so this file is served at /.well-known/capability-card.json",
        "Verify the live URL in your browser after deployment.",
    ]

    if target == "github-pages":
        (site_dir / ".nojekyll").write_text("", encoding="utf-8")
        index_path = site_dir / "index.html"
        if not index_path.exists():
            index_path.write_text(_GITHUB_PAGES_INDEX, encoding="utf-8")
        next_steps.extend(
            [
                "Commit the generated files and push them to the branch GitHub Pages serves.",
                "In GitHub, enable Pages for that branch or folder if it is not already enabled.",
            ]
        )
    elif target == "vercel":
        next_steps.extend(
            [
                "For Next.js or Vite, place this under your deployed public/static site root.",
                "After deploy, verify https://yourdomain.com/.well-known/capability-card.json on Vercel.",
            ]
        )
    elif target == "netlify":
        next_steps.extend(
            [
                "Commit the generated .well-known directory into the site root that Netlify publishes.",
                "After deploy, verify the live /.well-known/capability-card.json path on your Netlify domain.",
            ]
        )
    elif target == "cloudflare-pages":
        next_steps.extend(
            [
                "Commit the generated .well-known directory into the directory Cloudflare Pages deploys.",
                "After deploy, verify the live /.well-known/capability-card.json path on your Pages domain.",
            ]
        )

    return {"output_path": str(output_path), "next_steps": next_steps}
