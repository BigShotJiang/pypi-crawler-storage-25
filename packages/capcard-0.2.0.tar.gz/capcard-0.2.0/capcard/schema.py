"""Capability Card schema — Pydantic model and validation."""

from __future__ import annotations

import re
from typing import List, Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


AuthMethod = Literal["api_key", "oauth2", "bearer", "basic", "none"]
PricingModel = Literal["free", "freemium", "pay_per_call", "subscription", "enterprise", "unknown"]
AccountCreationFlow = Literal["instant", "form", "oauth", "invite_only", "unknown"]
SourceType = Literal["openapi", "mcp"]
OpenAPIVersion = Literal["2.0", "3.0", "3.1"]
PrimaryCategory = Literal[
    "finance", "payments", "communications", "messaging", "email",
    "ai_ml", "developer_tools", "data_analytics", "storage",
    "auth_identity", "maps_location", "ecommerce",
    "infrastructure", "media", "productivity", "other",
]

# Trust infrastructure types
VerificationStatus = Literal["crawled", "source_verified", "claimed", "flagged", "under_review"]
TrustTier = Literal[1, 2, 3, 4, 5, 6]
CapindexRating = Literal["AAA", "AA", "A", "B", "C", "unrated"]
CrawlStatus = Literal["active", "stale", "unavailable", "revoked", "tombstoned"]
DiscoverySource = Literal[
    "well_known_crawl", "apis_guru", "konfig", "github_search",
    "community_submission", "owner_submitted", "dataset_import"
]
DomainAgeRisk = Literal["low", "medium", "high", "unknown"]
TyposquatRisk = Literal["none", "low", "medium", "high"]
ConflictStatus = Literal["none", "detected", "resolved", "canonical", "displaced"]
PromptInjectionRisk = Literal["none", "low", "high"]
SubmissionSource = Literal["crawler", "owner_submitted", "community_submitted", "dataset_import"]
ClaimMethod = Literal["dns_txt", "file_verification", "oauth_email"]


class TrustMetadata(BaseModel):
    """Trust and verification metadata set by the crawl pipeline and backend systems.

    All fields are Optional — existing records without trust infrastructure data
    remain valid. Fields are populated progressively as the crawl pipeline runs.
    """

    # -------------------------------------------------------------------------
    # 2.1 Trust Status Fields
    # Set by: SYSTEM
    # -------------------------------------------------------------------------
    verification_status: Optional[VerificationStatus] = Field(
        None,
        description="Top-level trust label. Drives ranking and display.",
    )
    trust_tier: Optional[TrustTier] = Field(
        None,
        description="Numeric tier 1–6. 1 = highest (owner-claimed + verified). 6 = flagged.",
    )
    capindex_rating: Optional[CapindexRating] = Field(
        None,
        description="S&P-style composite rating from CapindexRank.",
    )
    capindex_rank_score: Optional[float] = Field(
        None, ge=0.0, le=1.0,
        description="Raw composite CapindexRank score. Not exposed in public API v1.",
    )
    flag_reason: Optional[str] = Field(
        None,
        description="Reason for flagged status. Null if not flagged.",
    )
    flag_timestamp: Optional[str] = Field(
        None,
        description="ISO 8601 datetime when the flag was applied.",
    )
    verified_by_owner: Optional[bool] = Field(
        None,
        description="True only when the claim flow is complete.",
    )
    claim_timestamp: Optional[str] = Field(
        None,
        description="ISO 8601 datetime when domain ownership was last verified.",
    )
    claim_method: Optional[ClaimMethod] = Field(
        None,
        description="Which verification method the owner used.",
    )
    claim_expires_at: Optional[str] = Field(
        None,
        description="ISO 8601 datetime when the current verification lapses.",
    )

    # -------------------------------------------------------------------------
    # 2.2 Crawl Provenance Fields
    # Set by: CRAWLER
    # -------------------------------------------------------------------------
    discovery_source: Optional[DiscoverySource] = Field(
        None,
        description="How Capindex discovered this record.",
    )
    discovery_url: Optional[str] = Field(
        None,
        description="Exact URL fetched to discover this record.",
    )
    first_crawled_at: Optional[str] = Field(
        None,
        description="ISO 8601 timestamp of first successful crawl. Immutable.",
    )
    last_crawled_at: Optional[str] = Field(
        None,
        description="ISO 8601 timestamp of most recent crawl attempt.",
    )
    last_successful_crawl_at: Optional[str] = Field(
        None,
        description="ISO 8601 timestamp of most recent crawl returning a valid response.",
    )
    crawl_status: Optional[CrawlStatus] = Field(
        None,
        description="Current lifecycle state of this record.",
    )
    next_crawl_at: Optional[str] = Field(
        None,
        description="ISO 8601 scheduled next crawl, based on trust tier schedule.",
    )
    crawl_failure_count: Optional[int] = Field(
        None, ge=0,
        description="Consecutive fetch failures. Escalates record state when threshold exceeded.",
    )
    user_agent: Optional[str] = Field(
        None,
        description="Crawler user-agent string used at crawl time. For auditing.",
    )

    # -------------------------------------------------------------------------
    # 2.3 Content Integrity Fields
    # Set by: CRAWLER
    # -------------------------------------------------------------------------
    content_hash: Optional[str] = Field(
        None,
        description="SHA-256 of the raw fetched record content, computed at fetch before processing.",
    )
    spec_hash: Optional[str] = Field(
        None,
        description="SHA-256 of the raw OpenAPI/MCP spec fetched from source_url.",
    )
    hash_algorithm: Optional[str] = Field(
        None,
        description="Hash algorithm used. Always 'sha256'. Field exists for future rotation.",
    )
    hash_computed_at: Optional[str] = Field(
        None,
        description="ISO 8601 timestamp when content_hash was computed. Must match crawl timestamp.",
    )
    content_changed: Optional[bool] = Field(
        None,
        description="True if content_hash differs from the previous crawl's hash.",
    )
    previous_content_hash: Optional[str] = Field(
        None,
        description="Previous crawl's content hash, for diff auditing.",
    )

    # -------------------------------------------------------------------------
    # 2.4 Domain Coherence and Risk Signal Fields
    # Set by: CRAWLER (hosting/TLS/WHOIS) + SYSTEM (risk classifications)
    # -------------------------------------------------------------------------
    hosting_domain: Optional[str] = Field(
        None,
        description="Actual domain the record was fetched from. Never taken from record content.",
    )
    provider_domain_match: Optional[bool] = Field(
        None,
        description="True if hosting_domain matches provider_domain exactly (not subdomain).",
    )
    subdomain_of_provider: Optional[bool] = Field(
        None,
        description="True if hosting_domain is a subdomain of provider_domain but not exact match.",
    )
    tls_valid: Optional[bool] = Field(
        None,
        description="TLS certificate is valid and not self-signed at crawl time.",
    )
    tls_cert_expiry: Optional[str] = Field(
        None,
        description="ISO 8601 expiry date of the TLS certificate.",
    )
    domain_age_days: Optional[int] = Field(
        None, ge=0,
        description="Age of the hosting domain from WHOIS registration date. Null if WHOIS fails.",
    )
    domain_age_risk: Optional[DomainAgeRisk] = Field(
        None,
        description="low (>365 days) / medium (90–365 days) / high (<90 days) / unknown.",
    )
    typosquat_risk: Optional[TyposquatRisk] = Field(
        None,
        description="Levenshtein-distance-based risk relative to canonical provider list.",
    )
    typosquat_nearest_match: Optional[str] = Field(
        None,
        description="Canonical domain this most closely resembles, if typosquat_risk is not 'none'.",
    )
    robots_allowed: Optional[bool] = Field(
        None,
        description="Whether robots.txt permits CapindexBot at this path.",
    )
    whois_registrar: Optional[str] = Field(
        None,
        description="Registrar from WHOIS, if available.",
    )
    whois_registrant: Optional[str] = Field(
        None,
        description="Registrant org from WHOIS, if available and not privacy-shielded.",
    )

    # -------------------------------------------------------------------------
    # 2.5 URL Coherence Fields
    # Set by: CRAWLER (domain extraction) + SYSTEM (pass/fail ruling)
    # -------------------------------------------------------------------------
    onboarding_url_domain: Optional[str] = Field(
        None,
        description="Extracted domain of onboarding_url.",
    )
    onboarding_url_resolved_domain: Optional[str] = Field(
        None,
        description="Domain after following redirects from onboarding_url.",
    )
    source_url_domain: Optional[str] = Field(
        None,
        description="Extracted domain of source_url (the OpenAPI/MCP spec).",
    )
    documentation_url_domain: Optional[str] = Field(
        None,
        description="Extracted domain of documentation_url.",
    )
    url_coherence_pass: Optional[bool] = Field(
        None,
        description="True if all URL fields resolve to domains consistent with provider_domain.",
    )
    url_coherence_failures: Optional[List[str]] = Field(
        None,
        description="List of URL field names that failed coherence checks.",
    )

    # -------------------------------------------------------------------------
    # 2.6 Conflict Tracking Fields
    # Set by: SYSTEM
    # -------------------------------------------------------------------------
    conflict_ids: Optional[List[str]] = Field(
        None,
        description="IDs of other records that conflict with this one (same provider, overlapping claims).",
    )
    conflict_status: Optional[ConflictStatus] = Field(
        None,
        description="Current conflict resolution state.",
    )
    canonical_record_id: Optional[str] = Field(
        None,
        description="If this record was displaced, the ID of the record that won.",
    )
    conflict_detected_at: Optional[str] = Field(
        None,
        description="ISO 8601 datetime when the conflict was first detected.",
    )

    # -------------------------------------------------------------------------
    # 2.7 Content Safety Fields
    # Set by: CRAWLER (scans) + SYSTEM (overall pass/fail)
    # -------------------------------------------------------------------------
    secrets_scan_pass: Optional[bool] = Field(
        None,
        description="True if no credential patterns were found in any text field or raw spec.",
    )
    secrets_scan_patterns_found: Optional[List[str]] = Field(
        None,
        description="Categories of patterns found (e.g. ['aws_key', 'jwt_token']). Never stores actual credentials.",
    )
    prompt_injection_risk: Optional[PromptInjectionRisk] = Field(
        None,
        description="Static analysis risk level for prompt injection patterns in text fields.",
    )
    impersonation_claim_detected: Optional[bool] = Field(
        None,
        description="True if any text field claims to be a named third-party whose domain doesn't match hosting_domain.",
    )
    content_safety_pass: Optional[bool] = Field(
        None,
        description="Overall pass/fail for content safety. Must be True before LLM enrichment runs.",
    )

    # -------------------------------------------------------------------------
    # 2.8 Submission Metadata Fields
    # Set by: SYSTEM / MANUAL
    # -------------------------------------------------------------------------
    submission_source: Optional[SubmissionSource] = Field(
        None,
        description="How this record entered the index.",
    )
    submitter_id: Optional[str] = Field(
        None,
        description="Internal ID of the submitting user, if submitted via the claim flow.",
    )
    submission_timestamp: Optional[str] = Field(
        None,
        description="ISO 8601 datetime when the record was submitted.",
    )
    submission_reviewed: Optional[bool] = Field(
        None,
        description="For community submissions: whether a human reviewer has reviewed it.",
    )
    submission_reviewed_by: Optional[str] = Field(
        None,
        description="Internal reviewer ID, if manually reviewed.",
    )


class ConnectLayer(BaseModel):
    """Connect layer — everything an agent needs to authenticate and activate a service.

    Generated by LLM enrichment from the OpenAPI spec or MCP manifest.
    Null on records ingested before the connect layer was added.
    """

    # Account creation
    human_signup_required: bool = Field(
        ...,
        description=(
            "True if human identity verification, KYC, or legal agreement is required "
            "before an agent can use this API autonomously. "
            "E.g. Stripe=true (business entity), OpenWeatherMap=false (email only)."
        ),
    )
    account_creation_url: Optional[str] = Field(
        None, description="URL to create an account or start the signup flow."
    )
    account_creation_flow: AccountCreationFlow = Field(
        "unknown",
        description=(
            "instant = email + get key immediately. "
            "form = fill form but no identity check. "
            "oauth = sign in with Google/GitHub/etc. "
            "invite_only = waitlist or manual approval. "
            "unknown = cannot determine from spec."
        ),
    )
    api_key_acquisition_steps: List[str] = Field(
        default_factory=list,
        description="Ordered plain-English steps to obtain an API key. Each item is one instruction.",
    )

    # OAuth
    oauth_supported: bool = Field(False, description="True if OAuth 2.0 is supported.")
    oauth_scopes_required: Optional[List[str]] = Field(
        None, description="OAuth scopes needed for typical use cases."
    )
    oauth_authorization_url: Optional[str] = Field(None)
    oauth_token_url: Optional[str] = Field(None)

    # Sandbox / environments
    sandbox_available: bool = Field(
        False, description="True if a free sandbox/test environment exists with non-production credentials."
    )
    sandbox_base_url: Optional[str] = Field(None)
    production_base_url: Optional[str] = Field(None)

    # Pricing activation
    free_tier_available: bool = Field(False)
    free_tier_limits: Optional[str] = Field(
        None,
        description="Plain English: what the free tier allows (calls/month, data limits, etc.).",
    )

    # Agent onboarding estimate
    time_to_first_call_minutes: Optional[int] = Field(
        None, ge=0,
        description="Estimated minutes from zero to first successful API call.",
    )
    known_gotchas: Optional[List[str]] = Field(
        None,
        description="1-3 LLM-identified auth or integration edge cases an agent should know about.",
    )

    # Auth credential format — how to pass the key in a real HTTP request.
    # Computed deterministically from securitySchemes, not LLM-generated.
    # E.g. "Authorization: Bearer {token}", "X-API-Key: {api_key}", "?api_key={api_key}"
    auth_header_format: Optional[str] = Field(
        None,
        description=(
            "Exact format for passing credentials in an HTTP request. "
            "Computed from securitySchemes. Null if format cannot be determined."
        ),
    )

    # Rate limits — critical for agents doing batch or high-frequency operations.
    rate_limit_requests_per_minute: Optional[int] = Field(
        None, ge=0,
        description="Max requests per minute on the default/free tier. Null if unknown.",
    )
    rate_limit_requests_per_day: Optional[int] = Field(
        None, ge=0,
        description="Max requests per day on the default/free tier. Null if unknown.",
    )
    rate_limit_notes: Optional[str] = Field(
        None,
        description=(
            "Plain English notes on rate limiting: 'varies by plan', "
            "'header-based throttling', '429 with Retry-After header', etc."
        ),
    )


class CapabilityRecord(BaseModel):
    """Normalized, LLM-enriched record describing what a web service does."""

    schema_version: str = Field(
        "1.0",
        description="Public Capability Card schema version.",
    )
    id: str = Field(..., description="Stable unique identifier: {provider-slug}-{product-slug}")
    source_type: SourceType = Field(..., description="'openapi' or 'mcp'")
    source_url: str = Field(..., description="URL of the raw spec — used as dedup key")
    provider_name: str = Field(..., description="Human-readable provider name, e.g. 'Stripe'")
    provider_domain: str = Field(..., description="Apex domain, e.g. 'stripe.com'")
    semantic_summary: str = Field(
        ..., description="2–4 sentence natural language description of what the service does"
    )
    capability_tags: List[str] = Field(
        ..., description="Short lowercase tags for faceted filtering. Max 8."
    )
    use_cases: List[str] = Field(
        ..., description="3–6 plain-English task descriptions an agent might have"
    )
    auth_methods: List[AuthMethod] = Field(
        ..., description="Authentication methods supported"
    )
    pricing_model: PricingModel = Field(..., description="Best-guess pricing classification")
    onboarding_url: Optional[str] = Field(None, description="URL to authentication/getting-started docs")
    documentation_url: Optional[str] = Field(None, description="URL to primary API documentation")
    openapi_version: Optional[OpenAPIVersion] = Field(None, description="OpenAPI/Swagger spec version")
    endpoint_count: int = Field(..., ge=0, description="Total number of API endpoints")
    last_crawled: str = Field(..., description="ISO 8601 date of last crawl")
    quality_score: float = Field(..., ge=0.0, le=1.0, description="Internal completeness score 0.0–1.0")

    # Standardised category — enables faceted browsing and category-level filters.
    # One canonical value from a fixed taxonomy. Null on pre-v2 records.
    primary_category: Optional[PrimaryCategory] = Field(
        None,
        description="Top-level capability category. One of 16 fixed values.",
    )

    # Official SDKs — agents prefer SDK calls to raw HTTP. Null if no official SDKs.
    sdk_languages: Optional[List[str]] = Field(
        None,
        description="Languages with official provider-maintained SDKs, e.g. ['python', 'node', 'ruby'].",
    )

    # Webhook / event support — fundamentally changes agent integration architecture.
    # webhook_support is computed from the spec; webhook_event_types is LLM-generated.
    webhook_support: bool = Field(
        False,
        description="True if this API can push events to agent endpoints (webhooks or callbacks).",
    )
    webhook_event_types: Optional[List[str]] = Field(
        None,
        description="Named event types this API can push, e.g. ['payment.completed', 'charge.failed'].",
    )

    # Connect layer — populated by LLM enrichment.
    # Null on records ingested before the connect layer was added.
    connect: Optional[ConnectLayer] = Field(
        None,
        description="Auth flows, sandbox, pricing, and onboarding steps. Null for pre-connect-layer records.",
    )

    # Trust infrastructure — populated by the crawl pipeline and backend systems.
    # Null on records ingested before trust infrastructure was deployed.
    trust: Optional[TrustMetadata] = Field(
        None,
        description="Trust and verification metadata. Null for records ingested before trust infrastructure.",
    )

    @field_validator("id")
    @classmethod
    def id_format(cls, v: str) -> str:
        if not re.match(r"^[a-z0-9][a-z0-9-]*[a-z0-9]$", v):
            raise ValueError(
                f"id must be lowercase alphanumeric with hyphens, got: {v!r}"
            )
        return v

    @field_validator("semantic_summary")
    @classmethod
    def summary_length(cls, v: str) -> str:
        if not (50 <= len(v) <= 500):
            raise ValueError(
                f"semantic_summary must be 50–500 characters, got {len(v)}"
            )
        return v

    @field_validator("capability_tags")
    @classmethod
    def tags_rules(cls, v: List[str]) -> List[str]:
        if not (1 <= len(v) <= 8):
            raise ValueError(f"capability_tags must have 1–8 items, got {len(v)}")
        for tag in v:
            if tag != tag.lower():
                raise ValueError(f"capability_tag must be lowercase, got: {tag!r}")
            if " " in tag:
                raise ValueError(f"capability_tag must not contain spaces, got: {tag!r}")
        return v

    @field_validator("use_cases")
    @classmethod
    def use_cases_count(cls, v: List[str]) -> List[str]:
        if not (2 <= len(v) <= 8):
            raise ValueError(f"use_cases must have 2–8 items, got {len(v)}")
        return v

    @field_validator("last_crawled")
    @classmethod
    def valid_date(cls, v: str) -> str:
        if not re.match(r"^\d{4}-\d{2}-\d{2}$", v):
            raise ValueError(f"last_crawled must be ISO 8601 date (YYYY-MM-DD), got: {v!r}")
        return v

    @field_validator("provider_domain")
    @classmethod
    def domain_format(cls, v: str) -> str:
        if not re.match(r"^[a-z0-9][a-z0-9.\-]+\.[a-z]{2,}$", v, re.IGNORECASE):
            raise ValueError(f"provider_domain must be a valid domain, got: {v!r}")
        return v.lower()

    @field_validator("schema_version")
    @classmethod
    def schema_version_supported(cls, v: str) -> str:
        if v != "1.0":
            raise ValueError(f"schema_version must be '1.0', got: {v!r}")
        return v
