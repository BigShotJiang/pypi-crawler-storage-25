from __future__ import annotations

import json
from pathlib import Path

from click.testing import CliRunner

from capcard.cli import cli


FIXTURE = Path(__file__).parent / "fixtures" / "example-openapi.yaml"


def test_init_generates_and_publishes_files(tmp_path: Path) -> None:
    runner = CliRunner()
    output_path = tmp_path / "capability-card.json"

    result = runner.invoke(
        cli,
        [
            "init",
            str(FIXTURE),
            "--provider",
            "deterministic",
            "--output",
            str(output_path),
            "--publish-target",
            "github-pages",
            "--site-dir",
            str(tmp_path),
        ],
    )

    assert result.exit_code == 0, result.output
    card = json.loads(output_path.read_text(encoding="utf-8"))
    assert card["schema_version"] == "1.0"
    assert (tmp_path / ".well-known" / "capability-card.json").exists()
    assert (tmp_path / ".nojekyll").exists()


def test_validate_accepts_generated_card(tmp_path: Path) -> None:
    runner = CliRunner()
    output_path = tmp_path / "capability-card.json"

    init_result = runner.invoke(
        cli,
        [
            "init",
            str(FIXTURE),
            "--provider",
            "deterministic",
            "--output",
            str(output_path),
        ],
    )
    assert init_result.exit_code == 0, init_result.output

    validate_result = runner.invoke(cli, ["validate", str(output_path)])
    assert validate_result.exit_code == 0, validate_result.output
    assert "Valid Capability Card:" in validate_result.output
