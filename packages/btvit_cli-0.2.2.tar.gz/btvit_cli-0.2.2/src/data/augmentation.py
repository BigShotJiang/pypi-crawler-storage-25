"""Configurable image augmentation pipeline for axis training.

Operates on full grayscale images (H x W float32 ndarray) BEFORE
patch cropping. Only active in train mode; val/test pass through unchanged.
"""

import logging
from typing import Any, Callable, Dict, List, Optional

import numpy as np

logger = logging.getLogger(__name__)


class HorizontalFlip:
    """Stochastic horizontal flip."""

    def __init__(self, config: dict):
        self.probability = float(config.get("probability", 0.5))

    def __call__(self, image: np.ndarray, rng: np.random.RandomState) -> np.ndarray:
        if rng.random() < self.probability:
            return np.fliplr(image).copy()
        return image


class BrightnessContrast:
    """Random brightness and contrast adjustment."""

    def __init__(self, config: dict):
        self.probability = float(config.get("probability", 0.5))
        b_range = config.get("brightness_range", [0.8, 1.2])
        c_range = config.get("contrast_range", [0.8, 1.2])
        self.brightness_range = self._clamp_range(b_range, 0.1, 3.0)
        self.contrast_range = self._clamp_range(c_range, 0.1, 3.0)

    @staticmethod
    def _clamp_range(rng: list, lo: float, hi: float) -> tuple:
        a, b = float(rng[0]), float(rng[1])
        if abs(a - b) < 1e-9:
            raise ValueError(
                f"Degenerate range [{a}, {b}] rejected. "
                f"Provide two distinct values."
            )
        a, b = max(lo, min(a, hi)), max(lo, min(b, hi))
        return (min(a, b), max(a, b))

    def __call__(self, image: np.ndarray, rng: np.random.RandomState) -> np.ndarray:
        if rng.random() >= self.probability:
            return image
        brightness = rng.uniform(*self.brightness_range)
        contrast = rng.uniform(*self.contrast_range)
        mean = image.mean()
        adjusted = (image - mean) * contrast + mean * brightness
        return np.clip(adjusted, -3.0, 3.0).astype(np.float32)


# Registry mapping config keys to transform classes
_TRANSFORM_REGISTRY: Dict[str, type] = {
    "horizontal_flip": HorizontalFlip,
    "brightness_contrast": BrightnessContrast,
}


class AugmentationPipeline:
    """Configurable augmentation pipeline.

    Parameters
    ----------
    config : dict
        Parsed training.axis.augmentation dictionary.
    mode : str
        "train", "val", or "test". Only "train" activates augmentation.
    """

    def __init__(self, config: Optional[dict] = None, mode: str = "train"):
        config = config or {}
        self.enabled = bool(config.get("enabled", False)) and mode == "train"
        seed = config.get("random_seed")
        self.rng = np.random.RandomState(seed)
        self.transforms: List[Callable] = []
        if self.enabled:
            self.transforms = self._build_transforms(config)
            names = [t.__class__.__name__ for t in self.transforms]
            logger.info("Augmentation enabled (mode=%s): %s", mode, names)

    def _build_transforms(self, config: dict) -> list:
        transforms = []
        for key, cls in _TRANSFORM_REGISTRY.items():
            sub_cfg = config.get(key, {})
            if isinstance(sub_cfg, dict) and sub_cfg.get("enabled", False):
                transforms.append(cls(sub_cfg))
        return transforms

    def __call__(self, image: np.ndarray) -> np.ndarray:
        if not self.enabled or not self.transforms:
            return image
        for transform in self.transforms:
            image = transform(image, self.rng)
        return image
