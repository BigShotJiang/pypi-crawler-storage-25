"""BoundaryAI SDK — LLM output sanitizer.

Covers OWASP LLM06 (Improper Output Handling). The LLM generates text that
downstream code renders as HTML, Markdown, or code — attacker-crafted prompts
embed `<script>`, `javascript:` URIs, data-URIs, or unicode-tag-injection
to XSS the rendering surface.

USAGE:
    from boundaryai.output_sanitizer import sanitize_llm_output, SanitizerResult

    raw = model_response.content
    result = sanitize_llm_output(raw, mode="html")   # or "markdown", "plain"
    if result.modified:
        logger.warning("sanitized %d issues: %s", len(result.issues), result.issues)
    safe_to_render = result.text

SANITIZERS (by mode):
    "html":     strip <script>, event handlers, javascript: URIs, data: URIs, <iframe>, <object>
    "markdown": same as html + strip markdown [](javascript:) link-smuggling
    "plain":    strip ALL HTML tags, collapse to text

Supplementary helpers:
    strip_unicode_tags(s)         — remove Tag chars (U+E0000-U+E007F) used in
                                    covert instruction smuggling
    collapse_zero_width(s)        — remove ZWSP/ZWNJ/ZWJ/BOM
    detect_markdown_smuggling(s)  — returns list of `[...](javascript:...)` hits
"""
from __future__ import annotations

import html
import re
from dataclasses import dataclass, field
from typing import List


# ---------------------------------------------------------------------------
# Patterns
# ---------------------------------------------------------------------------

# HTML element / attribute dangers
_RX_SCRIPT_TAG = re.compile(r"<\s*script[^>]*>[\s\S]*?<\s*/\s*script\s*>|<\s*script[^>]*>", re.IGNORECASE)
_RX_IFRAME_TAG = re.compile(r"<\s*iframe[^>]*>[\s\S]*?<\s*/\s*iframe\s*>|<\s*iframe[^>]*/?>", re.IGNORECASE)
_RX_OBJECT_TAG = re.compile(r"<\s*(object|embed|applet)[^>]*>[\s\S]*?<\s*/\s*\1\s*>|<\s*(object|embed|applet)[^>]*/?>", re.IGNORECASE)
_RX_STYLE_TAG  = re.compile(r"<\s*style[^>]*>[\s\S]*?<\s*/\s*style\s*>", re.IGNORECASE)
_RX_ON_ATTR    = re.compile(r'\s+on[a-z]+\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]+)', re.IGNORECASE)
_RX_JS_URI     = re.compile(r'(?i)(?:href|src|action|formaction|background|poster)\s*=\s*(?:"\s*javascript:|\'\s*javascript:|\s*javascript:)')
_RX_DATA_URI   = re.compile(r'(?i)(?:href|src|action|formaction|background|poster)\s*=\s*(?:"\s*data:(?!image/)|\'\s*data:(?!image/)|\s*data:(?!image/))')
_RX_VBSCRIPT   = re.compile(r'(?i)(?:href|src|action)\s*=\s*(?:"\s*vbscript:|\'\s*vbscript:|\s*vbscript:)')
_RX_ALL_TAGS   = re.compile(r"<[^>]+>")

# Markdown link smuggling: `[text](javascript:alert(1))`
_RX_MD_JS_LINK     = re.compile(r"\[[^\]]*\]\(\s*javascript:[^)]*\)", re.IGNORECASE)
_RX_MD_DATA_LINK   = re.compile(r"\[[^\]]*\]\(\s*data:(?!image/)[^)]*\)", re.IGNORECASE)
_RX_MD_VBSCRIPT    = re.compile(r"\[[^\]]*\]\(\s*vbscript:[^)]*\)", re.IGNORECASE)

# Unicode Tag block (U+E0000–U+E007F) — invisible, carries hidden instructions
# Seen in recent ASCII-art / tag-smuggling attacks
_RX_UNICODE_TAGS = re.compile(r"[\U000E0000-\U000E007F]")

# Zero-width
_RX_ZERO_WIDTH   = re.compile(r"[\u200B\u200C\u200D\u200E\u200F\u202A-\u202E\u2060-\u2064\uFEFF]")


@dataclass
class SanitizerResult:
    """Outcome of sanitize_llm_output()."""
    text: str
    issues: List[str] = field(default_factory=list)
    modified: bool = False


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def sanitize_llm_output(raw: str, mode: str = "html") -> SanitizerResult:
    """Sanitize an LLM response for safe rendering.

    `mode`:
        - "html":     for UI code that will render as HTML (React dangerouslySetInnerHTML, etc.)
        - "markdown": for renderers that convert markdown → HTML (chat UIs, Notion, etc.)
        - "plain":    strip all HTML, return raw text
    """
    if not isinstance(raw, str) or not raw:
        return SanitizerResult(text=raw or "", issues=[], modified=False)

    original = raw
    issues: List[str] = []
    text = raw

    # Always strip invisible Unicode-Tag characters (attack channel)
    if _RX_UNICODE_TAGS.search(text):
        text = _RX_UNICODE_TAGS.sub("", text)
        issues.append("unicode_tag_block_stripped")

    # Always strip zero-width (may hide instructions)
    if _RX_ZERO_WIDTH.search(text):
        text = _RX_ZERO_WIDTH.sub("", text)
        issues.append("zero_width_stripped")

    if mode == "plain":
        # Nuke every tag
        if _RX_ALL_TAGS.search(text):
            text = _RX_ALL_TAGS.sub("", text)
            issues.append("all_html_tags_stripped")
        return SanitizerResult(text=text, issues=issues, modified=text != original)

    # HTML / Markdown path
    if _RX_SCRIPT_TAG.search(text):
        text = _RX_SCRIPT_TAG.sub("", text)
        issues.append("script_tag_removed")
    if _RX_IFRAME_TAG.search(text):
        text = _RX_IFRAME_TAG.sub("", text)
        issues.append("iframe_tag_removed")
    if _RX_OBJECT_TAG.search(text):
        text = _RX_OBJECT_TAG.sub("", text)
        issues.append("object_embed_applet_removed")
    if _RX_STYLE_TAG.search(text):
        text = _RX_STYLE_TAG.sub("", text)
        issues.append("style_tag_removed")
    if _RX_ON_ATTR.search(text):
        text = _RX_ON_ATTR.sub("", text)
        issues.append("on_event_attrs_removed")
    # Neutralize dangerous URIs by HTML-escaping the scheme
    if _RX_JS_URI.search(text):
        text = _RX_JS_URI.sub(lambda m: m.group(0).replace("javascript:", "javascript-neutralized:").replace("JAVASCRIPT:", "JAVASCRIPT-NEUTRALIZED:"), text)
        issues.append("javascript_uri_neutralized")
    if _RX_DATA_URI.search(text):
        text = _RX_DATA_URI.sub(lambda m: m.group(0).replace("data:", "data-neutralized:").replace("DATA:", "DATA-NEUTRALIZED:"), text)
        issues.append("non_image_data_uri_neutralized")
    if _RX_VBSCRIPT.search(text):
        text = _RX_VBSCRIPT.sub(lambda m: m.group(0).replace("vbscript:", "vbscript-neutralized:").replace("VBSCRIPT:", "VBSCRIPT-NEUTRALIZED:"), text)
        issues.append("vbscript_uri_neutralized")

    if mode == "markdown":
        if _RX_MD_JS_LINK.search(text):
            text = _RX_MD_JS_LINK.sub("[link removed by BoundaryAI]", text)
            issues.append("markdown_javascript_link_removed")
        if _RX_MD_DATA_LINK.search(text):
            text = _RX_MD_DATA_LINK.sub("[link removed by BoundaryAI]", text)
            issues.append("markdown_data_uri_link_removed")
        if _RX_MD_VBSCRIPT.search(text):
            text = _RX_MD_VBSCRIPT.sub("[link removed by BoundaryAI]", text)
            issues.append("markdown_vbscript_link_removed")

    return SanitizerResult(text=text, issues=issues, modified=text != original)


def strip_unicode_tags(s: str) -> str:
    return _RX_UNICODE_TAGS.sub("", s or "")


def collapse_zero_width(s: str) -> str:
    return _RX_ZERO_WIDTH.sub("", s or "")


def detect_markdown_smuggling(s: str) -> List[str]:
    """Return the full string match of every markdown link-smuggling hit."""
    hits = []
    for rx in (_RX_MD_JS_LINK, _RX_MD_DATA_LINK, _RX_MD_VBSCRIPT):
        hits.extend(m.group(0) for m in rx.finditer(s or ""))
    return hits


def html_escape(s: str) -> str:
    """Convenience: fully HTML-escape a string. Use when the LLM output will
    be interpolated into HTML but you do NOT want any tags to render."""
    return html.escape(s or "", quote=True)


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

def _self_test():
    cases = [
        # (name, input, mode, expect_modified, expected_issue_substr_or_None)
        ("clean_markdown", "Hello **world**, this is fine.", "markdown", False, None),
        ("script_tag",     "Hi <script>alert(1)</script> there", "html", True, "script_tag_removed"),
        ("iframe",         '<iframe src="evil"></iframe>', "html", True, "iframe_tag_removed"),
        ("on_attr",        '<img src=x onerror="fetch(x)">', "html", True, "on_event_attrs_removed"),
        ("js_uri",         '<a href="javascript:alert(1)">click</a>', "html", True, "javascript_uri_neutralized"),
        ("md_js_link",     "Click [here](javascript:alert(1)) now", "markdown", True, "markdown_javascript_link_removed"),
        ("md_data_link",   "[open](data:text/html,hi)", "markdown", True, "markdown_data_uri_link_removed"),
        ("unicode_tags",   "Visible text\U000E0001\U000E0010 and more", "html", True, "unicode_tag_block_stripped"),
        ("zero_width",     "Visible\u200Btext", "html", True, "zero_width_stripped"),
        ("plain_strips_all", "Click <b>here</b> now", "plain", True, "all_html_tags_stripped"),
        ("multi_attack",   '<script>x</script><a onclick="bad()" href="javascript:1">', "html", True, None),
        ("vbscript",       '<a href="vbscript:msgbox(1)">click</a>', "html", True, "vbscript_uri_neutralized"),
    ]
    passed = 0
    for name, inp, mode, expect_mod, expect_issue in cases:
        r = sanitize_llm_output(inp, mode=mode)
        mod_ok = r.modified == expect_mod
        issue_ok = expect_issue is None or any(expect_issue in i for i in r.issues)
        ok = mod_ok and issue_ok
        tag = "PASS" if ok else "FAIL"
        if ok:
            passed += 1
        print(f"  [{tag}] {name:20s} modified={r.modified} issues={r.issues}")

    # Markdown-smuggling standalone helper
    md_hits = detect_markdown_smuggling("Click [a](javascript:x) then [b](data:text/html,y) and [c](vbscript:z)")
    ok = len(md_hits) == 3
    tag = "PASS" if ok else "FAIL"
    if ok:
        passed += 1
    print(f"  [{tag}] detect_markdown_smuggling returned {len(md_hits)} hits (expected 3)")

    total = len(cases) + 1
    print(f"\n{passed}/{total} passed")
    return passed == total


if __name__ == "__main__":
    import sys
    sys.exit(0 if _self_test() else 1)
