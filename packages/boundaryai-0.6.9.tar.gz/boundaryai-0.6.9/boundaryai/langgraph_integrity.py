"""BoundaryAI LangGraph / agent checkpoint integrity.

Wraps `save_checkpoint` and `load_checkpoint` with HMAC-SHA256 so a poisoned or
tampered checkpoint is rejected at load time. Closes the agent-memory-replay
attack class (top-20 gap #19).

USAGE — direct wrap:
    from boundaryai.langgraph_integrity import sign_checkpoint, verify_checkpoint

    raw = {"messages": [...], "state": {...}}
    signed = sign_checkpoint(raw, secret)           # adds `_boundaryai_sig` key
    # ... persist `signed` to disk / DB / S3 ...
    loaded = verify_checkpoint(signed, secret)      # raises CheckpointTampered if bad

USAGE — LangGraph BaseCheckpointSaver monkey-patch:
    from boundaryai.langgraph_integrity import install_checkpoint_guard
    from langgraph.checkpoint.memory import MemorySaver
    saver = install_checkpoint_guard(MemorySaver())   # returns a wrapped saver

ENV:
    BOUNDARY_CHECKPOINT_SECRET  — HMAC key (required; otherwise unsigned mode)
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
from typing import Any, Dict, Optional

SIG_KEY = "_boundaryai_sig"
ALGO = "HMAC-SHA256"


class CheckpointTampered(Exception):
    """Raised when a checkpoint's HMAC signature does not match.

    This indicates either (a) the checkpoint was modified by an attacker,
    (b) the HMAC secret was rotated without re-signing, or (c) the data
    was corrupted in transit/storage.
    """


def _canonical_bytes(obj: Any) -> bytes:
    """Deterministic JSON encoding: sorted keys + compact separators."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")


def _compute_sig(payload_bytes: bytes, secret: bytes) -> str:
    mac = hmac.new(secret, payload_bytes, hashlib.sha256).digest()
    return base64.b64encode(mac).decode("ascii")


def sign_checkpoint(data: Dict[str, Any], secret: Optional[str] = None) -> Dict[str, Any]:
    """Return a new dict = data + `_boundaryai_sig` metadata.

    The signature covers the canonical JSON encoding of `data` MINUS any
    pre-existing `_boundaryai_sig` key (so re-signing is idempotent).
    """
    secret = secret or os.environ.get("BOUNDARY_CHECKPOINT_SECRET", "")
    if not secret:
        # Unsigned mode — pass through. Caller should set BOUNDARY_CHECKPOINT_SECRET.
        return dict(data)
    stripped = {k: v for k, v in data.items() if k != SIG_KEY}
    payload = _canonical_bytes(stripped)
    sig = _compute_sig(payload, secret.encode("utf-8"))
    out = dict(stripped)
    out[SIG_KEY] = {"algo": ALGO, "sig": sig}
    return out


def verify_checkpoint(
    data: Dict[str, Any],
    secret: Optional[str] = None,
    *,
    allow_unsigned: bool = False,
) -> Dict[str, Any]:
    """Verify a checkpoint's signature. Returns the payload (sig field removed).

    Raises `CheckpointTampered` if:
      - `_boundaryai_sig` is missing AND `allow_unsigned=False`
      - The signature is present but does not match
      - The algorithm is not `HMAC-SHA256`
    """
    secret = secret or os.environ.get("BOUNDARY_CHECKPOINT_SECRET", "")
    if not secret:
        if allow_unsigned:
            return dict(data)
        raise CheckpointTampered("No BOUNDARY_CHECKPOINT_SECRET set; cannot verify integrity")
    sig_entry = data.get(SIG_KEY)
    if not sig_entry:
        if allow_unsigned:
            return dict(data)
        raise CheckpointTampered(f"Checkpoint missing '{SIG_KEY}' field — unsigned data rejected")
    if not isinstance(sig_entry, dict) or sig_entry.get("algo") != ALGO:
        raise CheckpointTampered(f"Unsupported signature algorithm: {sig_entry}")
    stored_sig = sig_entry.get("sig", "")
    stripped = {k: v for k, v in data.items() if k != SIG_KEY}
    payload = _canonical_bytes(stripped)
    expected = _compute_sig(payload, secret.encode("utf-8"))
    if not hmac.compare_digest(expected, stored_sig):
        raise CheckpointTampered(
            "Checkpoint HMAC mismatch — data has been modified since signing, "
            "or a different secret was used to sign."
        )
    return stripped


def install_checkpoint_guard(saver, secret: Optional[str] = None):
    """Wrap a LangGraph `BaseCheckpointSaver` so every `put()` signs and every
    `get()` / `list()` verifies.

    Returns a thin proxy object exposing the same interface as the input saver.
    If the input does not have `put`/`get`, raises `TypeError`.
    """
    if not hasattr(saver, "put") or not hasattr(saver, "get"):
        raise TypeError(
            "install_checkpoint_guard expects a LangGraph BaseCheckpointSaver "
            "(must have put/get). Got: " + type(saver).__name__
        )

    class _SignedSaver:
        def __init__(self, inner, secret):
            self._inner = inner
            self._secret = secret or os.environ.get("BOUNDARY_CHECKPOINT_SECRET", "")

        def __getattr__(self, name):
            return getattr(self._inner, name)

        def put(self, config, checkpoint, *args, **kwargs):
            # Convert checkpoint to dict for signing. LangGraph usually passes a dict.
            if isinstance(checkpoint, dict):
                signed = sign_checkpoint(checkpoint, self._secret)
            else:
                signed = checkpoint
            return self._inner.put(config, signed, *args, **kwargs)

        def get(self, config, *args, **kwargs):
            result = self._inner.get(config, *args, **kwargs)
            if isinstance(result, dict):
                return verify_checkpoint(result, self._secret)
            return result

        def list(self, config=None, *args, **kwargs):
            for c in self._inner.list(config, *args, **kwargs):
                if isinstance(c, dict):
                    yield verify_checkpoint(c, self._secret)
                else:
                    yield c

    return _SignedSaver(saver, secret)


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

def _self_test():
    secret = "test-langgraph-secret-42"
    print("=== langgraph_integrity self-test ===")

    # 1. Sign + verify round-trip
    data = {"messages": [{"role": "user", "content": "hello"}], "turn": 3}
    signed = sign_checkpoint(data, secret)
    assert SIG_KEY in signed, "Signature field must be added"
    restored = verify_checkpoint(signed, secret)
    assert restored == data, f"Round-trip mismatch: {restored} vs {data}"
    print("  [PASS] sign+verify round-trip")

    # 2. Tamper detection
    tampered = dict(signed)
    tampered["turn"] = 999  # attacker modifies state
    try:
        verify_checkpoint(tampered, secret)
        print("  [FAIL] tampered checkpoint should have raised")
        return False
    except CheckpointTampered:
        print("  [PASS] tampered state rejected")

    # 3. Different secret rejection
    try:
        verify_checkpoint(signed, "different-secret")
        print("  [FAIL] wrong secret should have raised")
        return False
    except CheckpointTampered:
        print("  [PASS] wrong secret rejected")

    # 4. Missing signature rejection
    unsigned = {"messages": [], "turn": 0}
    try:
        verify_checkpoint(unsigned, secret)
        print("  [FAIL] unsigned checkpoint should have raised")
        return False
    except CheckpointTampered:
        print("  [PASS] unsigned checkpoint rejected")

    # 5. Unsigned allowed mode
    out = verify_checkpoint(unsigned, secret, allow_unsigned=True)
    assert out == unsigned
    print("  [PASS] unsigned allowed when allow_unsigned=True")

    # 6. Re-signing is idempotent (sig field stripped before re-sign)
    resigned = sign_checkpoint(signed, secret)
    assert resigned == signed, "Re-signing should be idempotent"
    print("  [PASS] re-signing idempotent")

    # 7. Empty string secret = unsigned mode
    passthrough = sign_checkpoint(data, "")
    assert SIG_KEY not in passthrough
    print("  [PASS] empty secret -> unsigned pass-through")

    # 8. install_checkpoint_guard basic type check
    try:
        install_checkpoint_guard({}, secret)
        print("  [FAIL] install_checkpoint_guard should raise on non-saver")
        return False
    except TypeError:
        print("  [PASS] install_checkpoint_guard rejects non-saver")

    print("\n8/8 passed")
    return True


if __name__ == "__main__":
    import sys
    ok = _self_test()
    sys.exit(0 if ok else 1)
