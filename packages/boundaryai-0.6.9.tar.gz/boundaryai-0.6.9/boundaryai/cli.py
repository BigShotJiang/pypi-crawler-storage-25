# -*- coding: utf-8 -*-
"""
BoundaryAI CLI — `boundaryai` command-line interface.

Subcommands:
  scan                  Run a Day Zero Discovery scan (local, zero AI)
  observe start         Enable 48h observation mode (engine passes everything through)
  observe stop          Disable observation mode (return to enforcement)
  observe report        Fetch Day Zero risk report from the engine
  propose-policies      Generate AI-assisted Day One policies from a risk report
  identity              Show or rotate Ed25519 agent identity
  version               Print SDK version

Examples:
  boundaryai scan                                # point-in-time scan
  boundaryai observe start --hours 48 --org-id ORG
  boundaryai observe report --hours 48 --out risk.md
  boundaryai propose-policies --from-report risk.json --out day1.yaml
  boundaryai observe stop --org-id ORG
"""

import argparse
import json
import os
import sys
from typing import Optional


def _cmd_version(_args) -> int:
    from . import __version__
    print(f"boundaryai {__version__}")
    return 0


def _cmd_scan(args) -> int:
    from .discovery import run_discovery_scan
    from .day_zero import generate_full_report, format_report_markdown

    org_id = args.org_id or os.environ.get("BOUNDARY_ORG_ID", "local")

    print("[scan] Running Day Zero scan (zero AI, deterministic)...", file=sys.stderr)
    report = run_discovery_scan(org_id=org_id)
    full = generate_full_report(report)

    # Emit output based on flags
    if args.json:
        print(json.dumps(full, indent=2, default=str))
    else:
        es = full["executive_summary"]
        print(f"\n{'='*60}")
        print(f"  BoundaryAI Day Zero Scan — {report['machine']['hostname']}")
        print(f"{'='*60}")
        print(f"  Risk Score:    {es['risk_score']}/100 ({es['risk_level']})")
        print(f"  Total Findings: {es['total_findings']}")
        print(f"")
        print(f"  Highlights:")
        for k, v in es["highlights"].items():
            print(f"    {k.replace('_', ' ').title():24s} {v}")
        print(f"")
        print(f"  Recommended Policies: {len(full['recommended_policies'])}")
        for p in full["recommended_policies"]:
            print(f"    - {p['name']}")
        print(f"")
        imm = full["implementation_roadmap"].get("immediate", [])
        if imm:
            print(f"  Immediate actions:")
            for a in imm:
                print(f"    [{a['priority']}] {a['action']} — {a['owner']}")
        print(f"{'='*60}\n")

    # Write markdown report if requested
    if args.report:
        md = format_report_markdown(full)
        with open(args.report, "w", encoding="utf-8") as f:
            f.write(md)
        print(f"[scan] Report written to {args.report}", file=sys.stderr)

    # Stop here if dry-run
    if args.dry_run:
        print("[scan] --dry-run: skipping engine ingest.", file=sys.stderr)
        return 0

    # Post to engine
    engine_url = args.engine_url or os.environ.get("BOUNDARY_ENGINE_URL", "http://localhost:8080")
    admin_key = args.admin_key or os.environ.get("BOUNDARY_ADMIN_KEY", "")

    if not admin_key:
        print("[scan] WARNING: no BOUNDARY_ADMIN_KEY set — skipping engine ingest.", file=sys.stderr)
        print("[scan] To post findings, set BOUNDARY_ADMIN_KEY env var or pass --admin-key.", file=sys.stderr)
        return 0

    ingest_body = {
        "scan_id": report["scan_id"],
        "machine_id": report.get("machine_id", ""),
        "started_at": report["started_at"],
        "completed_at": report["completed_at"],
        "risk_score": report["risk_score"],
        "risk_level": report["risk_level"],
        "findings": report["findings"],
        "scanner_version": report["scanner_version"],
    }

    try:
        import urllib.request
        import urllib.error
        req = urllib.request.Request(
            f"{engine_url}/v1/admin/discovery/ingest",
            data=json.dumps(ingest_body).encode(),
            headers={
                "Content-Type": "application/json",
                "X-Admin-Key": admin_key,
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read())
        print(f"[scan] Ingested to engine: {result.get('inserted_findings', 0)} findings, "
              f"{result.get('new_agents', 0)} new agents, "
              f"{result.get('new_threats', 0)} new threats.", file=sys.stderr)
    except urllib.error.HTTPError as e:
        print(f"[scan] Engine ingest failed: HTTP {e.code} — {e.read().decode()[:200]}", file=sys.stderr)
        return 2
    except Exception as e:
        print(f"[scan] Engine ingest error: {e}", file=sys.stderr)
        return 2

    # Optionally deploy recommended policies
    if args.deploy_policies:
        deployed = 0
        for policy in full["recommended_policies"]:
            try:
                req = urllib.request.Request(
                    f"{engine_url}/v1/admin/policies",
                    data=json.dumps(policy).encode(),
                    headers={
                        "Content-Type": "application/json",
                        "X-Admin-Key": admin_key,
                    },
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=15) as resp:
                    if 200 <= resp.status < 300:
                        deployed += 1
            except Exception as e:
                print(f"[scan] Policy '{policy['name']}' failed: {e}", file=sys.stderr)
        print(f"[scan] Deployed {deployed}/{len(full['recommended_policies'])} policies.", file=sys.stderr)

    return 0


def _cmd_observe(args) -> int:
    """observe start|stop|report — Day Zero 48h observation mode."""
    from . import observe as obs

    org_id = args.org_id or os.environ.get("BOUNDARY_ORG_ID", "")
    sub = args.observe_sub

    if sub in ("start", "stop", "status") and not org_id:
        print("[observe] ERROR: --org-id required (or set BOUNDARY_ORG_ID).", file=sys.stderr)
        return 2

    if sub == "start":
        result = obs.start_observation(org_id, hours=args.hours,
                                       engine_url=args.engine_url, admin_key=args.admin_key)
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"[observe] Started observation mode for org {org_id}")
            print(f"  Keys flipped:    {result.get('keys_updated', 0)}")
            print(f"  Duration:        {result.get('duration_hours', 0)}h")
            print(f"  Expires at:      {result.get('observation_expires_at', '?')}")
            print(f"  Supabase sync:   async (best-effort)")
            print("")
            print(f"  Engine will now pass-through all decisions and record")
            print(f"  counterfactuals. At T+{args.hours}h run:")
            print(f"    boundaryai observe report --hours {args.hours} --out risk.md")
        return 0

    if sub == "stop":
        result = obs.stop_observation(org_id, engine_url=args.engine_url, admin_key=args.admin_key)
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"[observe] Stopped observation mode. Engine back to enforcement.")
            print(f"  Keys flipped: {result.get('keys_updated', 0)}")
        return 0

    if sub == "report":
        report = obs.fetch_report(hours=args.hours, engine_url=args.engine_url, admin_key=args.admin_key)
        if args.json:
            print(json.dumps(report, indent=2))
        else:
            md = obs.render_markdown(report)
            if args.out:
                with open(args.out, "w", encoding="utf-8") as f:
                    f.write(md)
                # also dump raw JSON next to the markdown for the proposer
                jpath = args.out.replace(".md", ".json") if args.out.endswith(".md") else (args.out + ".json")
                with open(jpath, "w", encoding="utf-8") as f:
                    json.dump(report, f, indent=2)
                print(f"[observe] Report → {args.out}", file=sys.stderr)
                print(f"[observe] Raw JSON → {jpath}", file=sys.stderr)
            else:
                print(md)
        return 0

    print(f"[observe] unknown sub '{sub}'", file=sys.stderr)
    return 2


def _cmd_propose_policies(args) -> int:
    """propose-policies — feed a Day Zero risk report into the AI proposer."""
    from . import observe as obs

    # Source: either --from-report file, or live fetch
    if args.from_report:
        with open(args.from_report, "r", encoding="utf-8") as f:
            report = json.load(f)
    else:
        report = obs.fetch_report(hours=args.hours, engine_url=args.engine_url, admin_key=args.admin_key)

    proposal = obs.propose_policies(report, anthropic_api_key=args.anthropic_key)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(proposal)
        print(f"[propose] Day One policy proposal → {args.out}", file=sys.stderr)
    else:
        print(proposal)
    return 0


def _cmd_identity(args) -> int:
    """Print this machine's Ed25519 agent identity fingerprint + public key."""
    from .identity import get_agent_identity

    ident = get_agent_identity()
    if ident is None:
        print("error: `cryptography` package not installed. Run: pip install cryptography", file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps({
            "fingerprint": ident.fingerprint,
            "public_key": ident.public_key_b64,
        }))
    else:
        print(f"fingerprint: ed25519:{ident.fingerprint[:4]}...{ident.fingerprint[-4:]}")
        print(f"public_key:  {ident.public_key_b64}")
    return 0


def main(argv: Optional[list] = None) -> int:
    parser = argparse.ArgumentParser(prog="boundaryai", description="BoundaryAI SDK + CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    # scan
    p_scan = sub.add_parser("scan", help="Run a Day Zero Discovery scan")
    p_scan.add_argument("--org-id", help="Organization ID (default: $BOUNDARY_ORG_ID or 'local')")
    p_scan.add_argument("--engine-url", help="Engine URL (default: $BOUNDARY_ENGINE_URL or http://localhost:8080)")
    p_scan.add_argument("--admin-key", help="Admin API key (default: $BOUNDARY_ADMIN_KEY)")
    p_scan.add_argument("--dry-run", action="store_true", help="Scan only — do not post to engine")
    p_scan.add_argument("--json", action="store_true", help="JSON output to stdout instead of summary")
    p_scan.add_argument("--report", metavar="FILE", help="Write markdown report to FILE")
    p_scan.add_argument("--deploy-policies", action="store_true", help="Also POST recommended policies to engine")
    p_scan.set_defaults(func=_cmd_scan)

    # observe start|stop|report
    p_obs = sub.add_parser("observe", help="Day Zero 48h observation mode")
    obs_sub = p_obs.add_subparsers(dest="observe_sub", required=True)
    for name, help_text in [("start", "Enable observation mode"),
                            ("stop", "Disable observation mode"),
                            ("report", "Fetch Day Zero risk report")]:
        sp = obs_sub.add_parser(name, help=help_text)
        sp.add_argument("--org-id", help="Organization ID (or $BOUNDARY_ORG_ID)")
        sp.add_argument("--engine-url", help="Engine URL (or $BOUNDARY_ENGINE_URL)")
        sp.add_argument("--admin-key", help="Admin key (or $BOUNDARY_ADMIN_KEY)")
        sp.add_argument("--hours", type=int, default=48, help="Duration or lookback in hours")
        sp.add_argument("--json", action="store_true", help="JSON output")
        if name == "report":
            sp.add_argument("--out", metavar="FILE.md", help="Write markdown report to FILE (+ sibling .json)")
    p_obs.set_defaults(func=_cmd_observe)

    # propose-policies
    p_prop = sub.add_parser("propose-policies", help="AI-assisted Day One policy proposal from a risk report")
    p_prop.add_argument("--from-report", metavar="FILE.json", help="Use this risk report JSON instead of live fetch")
    p_prop.add_argument("--hours", type=int, default=48, help="Lookback if live-fetching")
    p_prop.add_argument("--engine-url", help="Engine URL")
    p_prop.add_argument("--admin-key", help="Admin key")
    p_prop.add_argument("--anthropic-key", help="Anthropic API key (or $ANTHROPIC_API_KEY)")
    p_prop.add_argument("--out", metavar="FILE.yaml", help="Write proposal to FILE")
    p_prop.set_defaults(func=_cmd_propose_policies)

    # identity
    p_id = sub.add_parser("identity", help="Show or rotate this machine's Ed25519 agent identity")
    p_id.add_argument("--json", action="store_true", help="Machine-readable output")
    p_id.set_defaults(func=_cmd_identity)

    # version
    p_ver = sub.add_parser("version", help="Print SDK version")
    p_ver.set_defaults(func=_cmd_version)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
