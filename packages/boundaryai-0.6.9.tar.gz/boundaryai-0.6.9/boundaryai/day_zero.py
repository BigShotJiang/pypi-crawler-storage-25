# -*- coding: utf-8 -*-
"""
Day Zero Report Generator.

Takes a DiscoveryReport (from discovery.run_discovery_scan) and produces:
  1. Executive summary with risk score
  2. Recommended policies (deterministic, zero AI)
  3. 30/60/90 day implementation roadmap
  4. Plain-text markdown report suitable for `boundaryai scan --report`

Ported from integrated-preview/backend/discovery/report_generator.py.
"""

import json
from datetime import datetime, timezone


def generate_recommended_policies(report):
    """Generate policy recommendations (deterministic) based on discovery findings."""
    policies = []
    findings = report.get("findings", [])

    # Policy 1: Block PII to detected AI providers
    providers = set()
    for f in findings:
        if f.get("category") == "discovery.active_connection":
            details = f.get("details", {})
            if isinstance(details, dict) and details.get("provider"):
                providers.add(details["provider"])

    if providers:
        policies.append({
            "id": "generated_block_pii_to_providers",
            "name": "Block PII transmission to active AI providers",
            "domain": "data_governance",
            "status": "draft",
            "reason": f"Active connections detected to: {', '.join(sorted(providers))}",
            "yaml": {
                "action_type": "pii.detected",
                "decision": "block",
                "severity": "critical",
                "conditions": {"provider_in": sorted(providers)},
                "message": "PII transmission to external AI providers blocked",
            },
        })

    # Policy 2: Block credential access (rotate exposed keys)
    exposed_keys = [f for f in findings if f.get("category") == "discovery.api_key_exposed"]
    if exposed_keys:
        key_names = [k.get("name", "unknown") for k in exposed_keys]
        policies.append({
            "id": "generated_protect_exposed_keys",
            "name": "Block credential access (rotate exposed keys)",
            "domain": "digital_agent",
            "status": "draft",
            "reason": f"Exposed API keys: {', '.join(key_names)}. Rotate immediately.",
            "yaml": {
                "action_type": "credential.access",
                "decision": "block",
                "severity": "critical",
                "message": "Credential access denied — AI agents cannot access API keys",
            },
            "action_required": "IT team: rotate " + ", ".join(key_names),
        })

    # Policy 3: Monitor AI tool usage
    ai_apps = [f for f in findings if f.get("category") in ("discovery.ai_app", "discovery.cli_tool")]
    if ai_apps:
        app_names = [a.get("name", "unknown") for a in ai_apps]
        policies.append({
            "id": "generated_monitor_ai_apps",
            "name": "Monitor AI tool usage",
            "domain": "digital_agent",
            "status": "draft",
            "reason": f"{len(ai_apps)} AI applications: {', '.join(app_names[:5])}{'...' if len(app_names)>5 else ''}",
            "yaml": {
                "action_type": "process.ai_tool_detected",
                "decision": "allow",
                "severity": "low",
                "message": "AI tool detected — logging for audit trail",
            },
        })

    # Policy 4: Auto-register discovered agents
    policies.append({
        "id": "generated_agent_registration",
        "name": "Auto-register discovered agents with identity",
        "domain": "digital_agent",
        "status": "draft",
        "reason": "Create cryptographic identity for each discovered AI touchpoint",
        "yaml": {
            "action_type": "agent.register",
            "decision": "allow",
            "severity": "low",
            "conditions": {"source": "discovery_scanner"},
            "message": "Agent auto-registered from Day Zero scan",
        },
    })

    # Policy 5: Baseline watchlist
    policies.append({
        "id": "generated_baseline_watchlist",
        "name": "Baseline watchlist (confidential markers)",
        "domain": "data_governance",
        "status": "draft",
        "reason": "Generic confidentiality terms that apply to any organization",
        "yaml": {
            "watchlist_terms": [
                {"term": "CONFIDENTIAL", "category": "classification", "action": "block"},
                {"term": "internal only", "category": "classification", "action": "warn"},
                {"term": "do not share", "category": "classification", "action": "block"},
            ],
        },
    })

    return policies


def generate_roadmap(report):
    """30/60/90 day roadmap."""
    score = report.get("risk_score", 0)
    roadmap = {"immediate": [], "30_day": [], "60_day": [], "90_day": []}

    exposed = [f for f in report.get("findings", []) if f.get("category") == "discovery.api_key_exposed"]
    if exposed:
        roadmap["immediate"].append({
            "action": f"Rotate {len(exposed)} exposed API key(s)",
            "priority": "CRITICAL",
            "owner": "IT/Security",
        })

    if score > 30:
        roadmap["30_day"].extend([
            {"action": "Deploy baseline PII + credential policies", "priority": "HIGH", "owner": "Security"},
            {"action": "Register all discovered agents with Ed25519 identity", "priority": "HIGH", "owner": "Security"},
        ])

    roadmap["60_day"].extend([
        {"action": "Customize watchlist with org-specific terms (project names, client names)", "priority": "MEDIUM", "owner": "Security + Business"},
        {"action": "Roll out browser extension to all employees", "priority": "MEDIUM", "owner": "IT"},
    ])

    roadmap["90_day"].extend([
        {"action": "Enable gateway mode for agent frameworks (LangChain, CrewAI)", "priority": "MEDIUM", "owner": "Engineering"},
        {"action": "Run compliance report for SOC 2 / ISO 42001 audit evidence", "priority": "LOW", "owner": "Compliance"},
    ])

    return roadmap


def generate_executive_summary(report):
    """One-page summary for CISO."""
    findings = report.get("findings", [])
    cats = report.get("category_counts", {})

    return {
        "title": "BoundaryAI Day Zero Report",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "machine": report.get("machine", {}),
        "risk_score": report.get("risk_score", 0),
        "risk_level": report.get("risk_level", "UNKNOWN"),
        "total_findings": len(findings),
        "highlights": {
            "ai_connections": cats.get("discovery.active_connection", 0),
            "ai_applications": cats.get("discovery.ai_app", 0) + cats.get("discovery.cli_tool", 0),
            "ide_extensions": cats.get("discovery.ide_extension", 0),
            "exposed_api_keys": cats.get("discovery.api_key_exposed", 0),
            "browser_extensions": cats.get("discovery.browser_extension", 0),
        },
        "top_risks": [f for f in findings if f.get("severity") in ("critical", "high")][:5],
        "key_recommendations": [
            f"Risk Score: {report.get('risk_score', 0)}/100 ({report.get('risk_level', 'UNKNOWN')})",
            f"{len(findings)} AI touchpoints found — governance opportunities identified",
            "Deploy 5 auto-generated policies to close gaps immediately",
            "Register all AI agents with cryptographic identity for audit trail",
        ],
    }


def generate_full_report(report):
    """Complete Day Zero Report with all sections."""
    return {
        "executive_summary": generate_executive_summary(report),
        "discovery_findings": {
            "total": report.get("total_findings", 0),
            "by_category": report.get("category_counts", {}),
            "details": report.get("findings", []),
        },
        "risk_analysis": {
            "score": report.get("risk_score", 0),
            "level": report.get("risk_level", "UNKNOWN"),
            "breakdown": report.get("risk_breakdown", {}),
        },
        "recommended_policies": generate_recommended_policies(report),
        "implementation_roadmap": generate_roadmap(report),
        "report_metadata": {
            "scanner_version": report.get("scanner_version", "unknown"),
            "scan_id": report.get("scan_id", ""),
            "generated_at": datetime.now(timezone.utc).isoformat(),
        },
    }


def format_report_markdown(full_report):
    """Produce a human-readable markdown report."""
    es = full_report.get("executive_summary", {})
    lines = [
        f"# {es.get('title', 'BoundaryAI Day Zero Report')}",
        f"",
        f"**Risk Score:** {es.get('risk_score')}/100 ({es.get('risk_level')})",
        f"**Total Findings:** {es.get('total_findings')}",
        f"**Machine:** {es.get('machine', {}).get('hostname', 'unknown')} ({es.get('machine', {}).get('os', '?')})",
        f"",
        f"## Highlights",
    ]
    for k, v in es.get("highlights", {}).items():
        lines.append(f"- {k.replace('_', ' ').title()}: **{v}**")

    lines.append("\n## Recommended Policies\n")
    for p in full_report.get("recommended_policies", []):
        lines.append(f"- **{p['name']}** — {p.get('reason', '')}")

    lines.append("\n## Roadmap\n")
    for phase, actions in full_report.get("implementation_roadmap", {}).items():
        if actions:
            lines.append(f"### {phase.replace('_', ' ').title()}")
            for a in actions:
                lines.append(f"- [{a.get('priority','')}] {a.get('action','')} — _{a.get('owner','')}_")

    return "\n".join(lines)
