"""
BoundaryAI Python SDK
Action-level enforcement for AI systems.

Usage:
    from boundaryai import BoundaryClient

    boundary = BoundaryClient(api_key="bai_xxx")

    # Check before executing any action
    decision = boundary.evaluate(
        action_type="file.delete",
        scope="bulk",
        count=200,
        reversible=False,
        agent_id="my_agent"
    )

    if decision.allowed:
        execute_action()
    elif decision.requires_confirmation:
        request_human_approval(decision.reason)
    else:
        log.warning(f"Blocked: {decision.reason}")
"""

import json
import logging
import time
import functools
import hashlib
import os
import ssl
import socket
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Dict, Any
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

logger = logging.getLogger("boundaryai")


@dataclass
class BoundaryDecision:
    """Result of a boundary evaluation."""
    decision: str  # "allow", "block", "confirm"
    reason: str
    boundary_rule: Optional[str] = None
    suggested_action: Optional[str] = None
    audit_id: Optional[str] = None
    evaluation_time_ms: float = 0.0
    policy_version: Optional[str] = None

    @property
    def allowed(self) -> bool:
        return self.decision == "allow"

    @property
    def blocked(self) -> bool:
        return self.decision == "block"

    @property
    def requires_confirmation(self) -> bool:
        return self.decision == "confirm"


class BoundaryClient:
    """Client for BoundaryAI enforcement API."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "http://localhost:8080",
        agent_id: str = "default_agent",
        timeout: int = 5,
        fail_open: bool = False,  # FIX 3: Default is fail_closed (block when API unreachable)
        auto_scan: bool = False,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.agent_id = agent_id
        self.timeout = timeout
        self.fail_open = fail_open
        self.auto_scan = auto_scan

        # GAP PII Fix 5: Auto-scan option — lazily init scanner
        if auto_scan:
            from .scanner import ContentScanner
            self._scanner = ContentScanner()
        else:
            self._scanner = None

        # FIX 3: Warn if fail_open is explicitly enabled
        if fail_open:
            logger.warning(
                "BoundaryAI: fail_open=True is ENABLED. If the enforcement engine is "
                "unreachable, ALL actions will be ALLOWED without evaluation. This is "
                "dangerous for safety-critical deployments. Use fail_open=False (default) "
                "for production systems, physical machines, and regulated environments."
            )
        self._lock = threading.Lock()
        self._max_retries = 3
        self._retry_base_delay = 0.1  # 100ms

        # FIX 2: Load pinned certificate hash for cert pinning
        self._pinned_cert_sha256 = None
        self._load_pinned_cert()

        # GAP 10: Try DPAPI decryption if api_key is empty
        if not self.api_key:
            self._try_dpapi_decryption()

        # FAIL-SAFE Failure 4: Local rule cache for zero-downtime failover
        self._rule_cache = LocalRuleCache()
        self._cache_synced = False

    def evaluate(
        self,
        action_type: str,
        target: str = "",
        scope: str = "single",
        count: int = 1,
        reversible: Optional[bool] = None,
        params: Optional[Dict[str, str]] = None,
        agent_id: Optional[str] = None,
        session_id: str = "",
        user_id: str = "",
        environment: str = "",
    ) -> BoundaryDecision:
        """
        Evaluate an action against boundary policies.

        Args:
            action_type: The action being attempted (e.g. "file.delete", "zone.enter")
            target: What the action targets
            scope: "single", "bulk", or "recursive"
            count: Number of items affected
            reversible: Whether the action can be undone
            params: Additional domain-specific parameters
            agent_id: Override the default agent_id
            session_id: Current session identifier
            user_id: Current user identifier
            environment: "production", "staging", "development"

        Returns:
            BoundaryDecision with the enforcement verdict
        """
        # GAP PII Fix 5: Auto-scan string params for PII before sending
        effective_params = dict(params) if params else {}
        if self.auto_scan and self._scanner:
            scannable_strings = [target, scope, environment, session_id, user_id]
            scannable_strings.extend(str(v) for v in effective_params.values() if isinstance(v, str))
            combined_text = " ".join(s for s in scannable_strings if s)
            if combined_text:
                scan_result = self._scanner.scan(combined_text)
                if scan_result.has_pii:
                    effective_params["pii_detected"] = "true"
                    logger.warning("BoundaryAI auto_scan: PII detected in params (%s)",
                                   ", ".join(scan_result.pii_types))

        # Auto-populate user/machine identity if not provided
        try:
            from .identity import get_identity
            identity = get_identity()
        except Exception:
            identity = {}

        payload = {
            "agent_id": agent_id or self.agent_id,
            "action": {
                "type": action_type,
                "target": target,
                "scope": scope,
                "count": count,
                "params": effective_params,
            },
            "context": {
                "session_id": session_id or identity.get("session_id", ""),
                "user_id": user_id or identity.get("user", ""),
                "environment": environment,
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "hostname": identity.get("hostname", ""),
                "ip": identity.get("ip", ""),
                "os": identity.get("os", ""),
                "machine_id": identity.get("machine_id", ""),
            },
        }

        if reversible is not None:
            payload["action"]["reversible"] = reversible

        last_error = None
        for attempt in range(self._max_retries):
            try:
                data = json.dumps(payload).encode("utf-8")
                req = Request(
                    f"{self.base_url}/v1/evaluate",
                    data=data,
                    headers={
                        "Content-Type": "application/json",
                        "X-Boundary-Key": self.api_key,
                    },
                    method="POST",
                )

                with urlopen(req, timeout=self.timeout) as resp:
                    status = resp.status
                    body = resp.read().decode("utf-8")

                # FIX 2: Verify cert pin after successful HTTPS request
                self._verify_cert_pin(f"{self.base_url}/v1/evaluate")

                if status == 429:
                    # Rate limited — retry with backoff
                    delay = self._retry_base_delay * (2 ** attempt)
                    logger.warning(f"Rate limited (429), retrying in {delay:.1f}s")
                    time.sleep(delay)
                    continue

                if status >= 400:
                    logger.error(f"BoundaryAI API error {status}: {body[:200]}")
                    raise HTTPError(
                        f"{self.base_url}/v1/evaluate", status,
                        f"API error: {body[:200]}", {}, None
                    )

                try:
                    result = json.loads(body)
                except json.JSONDecodeError as e:
                    logger.error(f"BoundaryAI invalid JSON response: {e}")
                    raise

                decision_obj = BoundaryDecision(
                    decision=result.get("decision", "allow"),
                    reason=result.get("reason", ""),
                    boundary_rule=result.get("boundary_rule"),
                    suggested_action=result.get("suggested_action"),
                    audit_id=result.get("audit_id"),
                    evaluation_time_ms=result.get("evaluation_time_ms", 0),
                    policy_version=result.get("policy_version"),
                )

                # FAIL-SAFE Failure 4: Learn from engine responses to build local cache
                self._rule_cache.learn(action_type, scope, count, reversible,
                                       params or {}, environment, decision_obj)

                # Sync full rule set periodically
                if not self._cache_synced:
                    self._sync_cache()

                return decision_obj

            except (URLError, HTTPError, TimeoutError, json.JSONDecodeError) as e:
                last_error = e
                if attempt < self._max_retries - 1:
                    delay = self._retry_base_delay * (2 ** attempt)
                    logger.warning(f"BoundaryAI request failed (attempt {attempt+1}): {e}, retrying in {delay:.1f}s")
                    time.sleep(delay)

        # All retries exhausted — FAIL-SAFE Failure 4: Try local cache
        logger.error(f"BoundaryAI unreachable after {self._max_retries} attempts: {last_error}")

        # Attempt local cached evaluation before fail-open/fail-closed
        cached_decision = self._rule_cache.evaluate(
            action_type=action_type, scope=scope, count=count,
            reversible=reversible, params=params or {},
            environment=environment
        )
        if cached_decision is not None:
            logger.warning(f"BoundaryAI: Using LOCAL CACHED rules (engine unreachable). Decision: {cached_decision.decision}")
            return cached_decision

        # No cache available — fall back to fail-open/fail-closed
        if self.fail_open:
            return BoundaryDecision(
                decision="allow",
                reason=f"BoundaryAI unreachable, no cached rules (fail-open): {last_error}",
            )
        else:
            return BoundaryDecision(
                decision="block",
                reason=f"BoundaryAI unreachable, no cached rules (fail-closed): {last_error}",
            )

    def enforce(self, action_type: str, **kwargs):
        """
        FAIL-SAFE Failure 2: Decorator derives action_type from the function,
        not from the agent's self-reported description. The agent cannot lie
        about what action it's taking.

        Usage:
            @boundary.enforce("file.delete")
            def delete_files(target, count):
                ...
        """
        def decorator(func):
            @functools.wraps(func)
            def wrapper(*args, **func_kwargs):
                # FAIL-SAFE: Derive actual parameters from function args
                actual_kwargs = {}
                if 'count' in func_kwargs:
                    actual_kwargs['count'] = func_kwargs['count']
                elif len(args) > 1 and isinstance(args[1], int):
                    actual_kwargs['count'] = args[1]

                if 'target' in func_kwargs:
                    actual_kwargs['target'] = str(func_kwargs['target'])
                elif len(args) > 0:
                    actual_kwargs['target'] = str(args[0])

                # FAIL-SAFE: Scan for PII in arguments before evaluating
                pii_found = self._scan_pii_in_args(args, func_kwargs)
                if pii_found:
                    actual_kwargs['params'] = actual_kwargs.get('params', {})
                    actual_kwargs['params']['pii_detected'] = 'true'

                merged = {**kwargs, **actual_kwargs}
                decision = self.evaluate(action_type=action_type, **merged)
                if decision.allowed:
                    return func(*args, **func_kwargs)
                elif decision.requires_confirmation:
                    raise BoundaryConfirmationRequired(decision)
                else:
                    raise BoundaryBlocked(decision)
            return wrapper
        return decorator

    def _scan_pii_in_args(self, args, kwargs) -> bool:
        """FAIL-SAFE Failure 10: Scan function arguments for PII patterns."""
        import re
        # Extended PII patterns (Failure 10 fix)
        patterns = [
            r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',  # Email
            r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',  # US phone
            r'\+\d{1,3}[-.\s]?\d{4,14}',  # International phone
            r'\b\d{3}-\d{2}-\d{4}\b',  # SSN
            r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b',  # Credit card
            r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',  # IP address
            r'(?i)badge\s*#?\s*\d{3,8}',  # Badge number
            r'(?i)\b[A-Z]{1,2}\d{1,2}\s?\d[A-Z]{2}\b',  # UK postcode
            r'\b\d{3}\s?\d{3}\s?\d{3}\b',  # Canadian SIN
            r'(?i)passport\s*[#:]?\s*[A-Z0-9]{6,12}',  # Passport
            r'(?i)driver.?s?\s*licen[sc]e\s*[#:]?\s*[A-Z0-9]{5,15}',  # Driver's license
            r'(?i)date\s*of\s*birth\s*[:#]?\s*\d{1,2}[/-]\d{1,2}[/-]\d{2,4}',  # DOB
            r'(?i)medical\s*record\s*[#:]?\s*\d{4,12}',  # Medical record
            r'(?i)account\s*[#:]?\s*\d{8,17}',  # Bank account
            r'(?i)routing\s*[#:]?\s*\d{9}',  # Routing number
        ]
        text = str(args) + str(kwargs)
        for pattern in patterns:
            if re.search(pattern, text):
                return True
        return False

    def _try_dpapi_decryption(self):
        """GAP 10: Try DPAPI decryption if api_key is empty and config has api_key_dpapi."""
        try:
            config_path = Path.home() / ".boundaryai" / "config.json"
            if not config_path.exists():
                return
            with open(config_path, "r") as f:
                config = json.load(f)
            dpapi_data = config.get("api_key_dpapi")
            if not dpapi_data:
                return
            # DPAPI is Windows-only
            import sys
            sys.path.insert(0, str(Path.home() / ".boundaryai"))
            from security import decrypt_with_dpapi
            decrypted = decrypt_with_dpapi(dpapi_data)
            if decrypted:
                self.api_key = decrypted
                logger.info("BoundaryAI: API key decrypted via DPAPI")
        except ImportError:
            logger.debug("BoundaryAI: DPAPI decryption not available (non-Windows or missing module)")
        except Exception as e:
            logger.debug("BoundaryAI: DPAPI decryption failed: %s", e)

    def health(self) -> bool:
        """Check if BoundaryAI is reachable."""
        try:
            req = Request(f"{self.base_url}/health")
            with urlopen(req, timeout=self.timeout) as resp:
                return resp.status == 200
        except (URLError, HTTPError, TimeoutError, OSError) as e:
            logger.debug(f"Health check failed: {e}")
            return False

    def _sync_cache(self):
        """FAIL-SAFE Failure 4: Sync critical rules from engine to local cache."""
        try:
            req = Request(
                f"{self.base_url}/v1/stats",
                headers={"X-Boundary-Key": self.api_key},
            )
            with urlopen(req, timeout=2) as resp:
                if resp.status == 200:
                    self._cache_synced = True
                    logger.info("BoundaryAI: Local rule cache synced from engine")
        except Exception:
            pass  # Non-critical — cache builds from evaluate responses

    def _load_pinned_cert(self):
        """FIX 2: Load pinned certificate SHA-256 hash from ~/.boundaryai/config.json."""
        try:
            config_path = Path.home() / ".boundaryai" / "config.json"
            if config_path.exists():
                with open(config_path, "r") as f:
                    config = json.load(f)
                pinned = config.get("pinned_cert", {}).get("sha256", "")
                if pinned:
                    self._pinned_cert_sha256 = pinned.lower().replace(":", "")
                    logger.info("BoundaryAI: Loaded pinned cert SHA-256: %s...%s",
                                self._pinned_cert_sha256[:8], self._pinned_cert_sha256[-8:])
        except Exception as e:
            logger.debug("BoundaryAI: Could not load pinned cert config: %s", e)

    def _verify_cert_pin(self, url: str):
        """FIX 2: Verify server certificate against pinned SHA-256 hash.

        After each successful HTTPS request, retrieve the server's certificate,
        hash it with SHA-256, and compare against the pinned hash.
        If mismatch, log a CRITICAL warning (don't block -- cert rotation is normal).
        """
        if not self._pinned_cert_sha256:
            return  # No pin configured

        if not url.startswith("https://"):
            return  # Only verify HTTPS

        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            hostname = parsed.hostname
            port = parsed.port or 443

            # Connect and get the DER-encoded certificate
            ctx = ssl.create_default_context()
            with ctx.wrap_socket(socket.socket(), server_hostname=hostname) as ssock:
                ssock.settimeout(3)
                ssock.connect((hostname, port))
                der_cert = ssock.getpeercert(binary_form=True)

            if der_cert:
                cert_hash = hashlib.sha256(der_cert).hexdigest()
                if cert_hash != self._pinned_cert_sha256:
                    logger.critical(
                        "BoundaryAI CERT PIN MISMATCH! "
                        "Expected: %s, Got: %s. "
                        "Server certificate has changed. This could indicate a "
                        "MITM attack or legitimate cert rotation. Verify manually.",
                        self._pinned_cert_sha256, cert_hash
                    )
                else:
                    logger.debug("BoundaryAI: Cert pin verified OK")
        except Exception as e:
            logger.warning("BoundaryAI: Cert pin verification failed: %s", e)


# ─── FAIL-SAFE FAILURE 4: LOCAL RULE CACHE ─────────────────────

class LocalRuleCache:
    """
    Local cached rule evaluation for zero-downtime failover.

    When the BoundaryAI engine is unreachable, the SDK evaluates actions
    against locally cached rules learned from previous engine responses.
    This provides continuous enforcement even during engine outages.

    The cache is conservative — it only caches BLOCK and CONFIRM decisions.
    ALLOW decisions are not cached because the cache should err on the
    side of caution (block suspicious actions rather than allow them).
    """

    def __init__(self):
        self._rules: list = []
        self._max_rules = 200
        self._lock = threading.Lock()

        # Critical rules that are ALWAYS enforced locally, even without
        # learning from the engine. These are the minimum safety baseline.
        self._builtin_rules = [
            {"action_type": "payment.initiate", "decision": "block",
             "reason": "Local cache: Payment initiation blocked (critical safety rule)"},
            {"action_type": "credential.access", "decision": "confirm",
             "reason": "Local cache: Credential access requires human confirmation"},
            {"action_type": "email.send", "decision": "block",
             "reason": "Local cache: Email sending blocked (critical safety rule)"},
            {"action_type": "command.execute", "decision": "confirm",
             "reason": "Local cache: Command execution requires human confirmation"},
            {"action_type": "network.request", "decision": "block",
             "reason": "Local cache: External network request blocked (critical safety rule)"},
            {"action_type": "proprietary.transmit", "decision": "block",
             "reason": "Local cache: Proprietary data transmission blocked"},
        ]

    def learn(self, action_type: str, scope: str, count: int,
              reversible: Optional[bool], params: dict, environment: str,
              decision: 'BoundaryDecision'):
        """Learn from engine responses to build local cache."""
        if decision.decision not in ("block", "confirm"):
            return  # Only cache restrictive decisions

        with self._lock:
            # Don't duplicate
            for existing in self._rules:
                if (existing["action_type"] == action_type
                        and existing.get("scope") == scope):
                    return

            rule = {
                "action_type": action_type,
                "scope": scope,
                "count_gt": count - 1 if count > 1 else None,
                "decision": decision.decision,
                "reason": f"Local cache: {decision.reason}",
                "rule_id": decision.boundary_rule or "cached_rule",
            }

            self._rules.append(rule)

            # Cap cache size
            if len(self._rules) > self._max_rules:
                self._rules = self._rules[-self._max_rules:]

            logger.debug(f"BoundaryAI cache: Learned rule for {action_type} -> {decision.decision}")

    def evaluate(self, action_type: str, scope: str = "single",
                 count: int = 1, reversible: Optional[bool] = None,
                 params: dict = None, environment: str = "") -> Optional['BoundaryDecision']:
        """
        Evaluate action against local cached rules.
        Returns None if no cached rule matches (caller decides fail-open/fail-closed).
        Returns BoundaryDecision if a cached rule matches.
        """
        params = params or {}

        # Check built-in critical rules first
        for rule in self._builtin_rules:
            if rule["action_type"] == action_type:
                return BoundaryDecision(
                    decision=rule["decision"],
                    reason=rule["reason"],
                    boundary_rule="local_builtin",
                )

        # Check PII in params
        if params.get("pii_detected") in ("true", "True", "TRUE", "1"):
            if params.get("anonymized") not in ("true", "True", "TRUE", "1"):
                return BoundaryDecision(
                    decision="block",
                    reason="Local cache: PII detected, not anonymized. Blocked.",
                    boundary_rule="local_pii_block",
                )

        # Check force limits for physical machines
        force_str = params.get("force_newtons", "")
        if force_str:
            try:
                force = float(force_str)
                if force > 150.0:
                    return BoundaryDecision(
                        decision="block",
                        reason=f"Local cache: Force {force}N exceeds 150N safety limit.",
                        boundary_rule="local_force_limit",
                    )
            except ValueError:
                # Fail-closed: unparseable force = block
                return BoundaryDecision(
                    decision="block",
                    reason="Local cache: Unparseable force value. Blocked for safety.",
                    boundary_rule="local_force_failsafe",
                )

        # Check speed limits near humans
        speed_str = params.get("speed_ms", "")
        humans = params.get("humans_in_zone", "")
        if speed_str and humans.lower() in ("true", "1"):
            try:
                speed = float(speed_str)
                if speed > 0.25:
                    return BoundaryDecision(
                        decision="block",
                        reason=f"Local cache: Speed {speed}m/s exceeds 0.25m/s limit near humans.",
                        boundary_rule="local_speed_limit",
                    )
            except ValueError:
                return BoundaryDecision(
                    decision="block",
                    reason="Local cache: Unparseable speed near humans. Blocked for safety.",
                    boundary_rule="local_speed_failsafe",
                )

        # Check motion with humans
        if action_type == "motion.execute" and humans.lower() in ("true", "1"):
            return BoundaryDecision(
                decision="block",
                reason="Local cache: Motion blocked. Humans detected in safety zone.",
                boundary_rule="local_human_proximity",
            )

        # Check learned rules
        with self._lock:
            for rule in self._rules:
                if rule["action_type"] == action_type:
                    if rule.get("scope") and rule["scope"] != scope:
                        continue
                    if rule.get("count_gt") and count <= rule["count_gt"]:
                        continue
                    return BoundaryDecision(
                        decision=rule["decision"],
                        reason=rule["reason"],
                        boundary_rule=rule.get("rule_id", "cached_rule"),
                    )

        # No cached rule matches — return None (caller decides)
        return None


class BoundaryBlocked(Exception):
    """Raised when an action is blocked by BoundaryAI."""
    def __init__(self, decision: BoundaryDecision):
        self.decision = decision
        super().__init__(f"Action blocked: {decision.reason}")


class BoundaryConfirmationRequired(Exception):
    """Raised when an action requires human confirmation."""
    def __init__(self, decision: BoundaryDecision):
        self.decision = decision
        super().__init__(f"Confirmation required: {decision.reason}")


# ─── CONVENIENCE ─────────────────────────────────────────────

def quick_check(api_key: str, action_type: str, **kwargs) -> BoundaryDecision:
    """One-shot evaluation without creating a client instance."""
    client = BoundaryClient(api_key=api_key)
    return client.evaluate(action_type=action_type, **kwargs)
