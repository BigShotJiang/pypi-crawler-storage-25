# -*- coding: utf-8 -*-
"""
BoundaryAI — System Identity + Ed25519 Cryptographic Agent Identity.

Two-layer design:
  1. System identity (legacy): user, hostname, OS, machine_id hash — sent
     with every evaluation for audit context.
  2. Agent identity (new): real Ed25519 keypair generated client-side.
     Private key stored at ~/.boundaryai/identity.pem (0600 perms).
     Only fingerprint + public_key are sent to the engine.

The Ed25519 layer replaces the SHA-256 stand-in from the integrated preview.

Usage:
    from boundaryai.identity import get_identity, get_agent_identity

    # Legacy system identity (unchanged)
    ident = get_identity()  # {user, hostname, ip, os, machine_id, session_id}

    # New agent identity (Ed25519)
    agent = get_agent_identity()  # AgentIdentity with fingerprint, public_key, signer
    signature_b64 = agent.sign(b"nonce-from-engine")
"""

import base64
import getpass
import hashlib
import os
import platform
import socket
import stat
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

# Ed25519 via `cryptography` — standard library of Python crypto.
# This is already a transitive dep through reqwest/urllib3 in most installs;
# if missing, SDK import will error with a clear message.
try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ed25519
    _HAS_CRYPTOGRAPHY = True
except ImportError:
    _HAS_CRYPTOGRAPHY = False


# ─── System identity (unchanged from v0.5.0) ────────────────────────────

def get_system_identity():
    """
    Collect system and user identity for audit tracking.
    Returns dict with user, machine, and system info.
    """
    try:
        username = getpass.getuser()
    except Exception:
        username = os.environ.get("USER", os.environ.get("USERNAME", "unknown"))

    hostname = socket.gethostname()
    try:
        ip_address = socket.gethostbyname(hostname)
    except Exception:
        ip_address = "unknown"

    os_name = platform.system()
    os_version = platform.version()
    os_release = platform.release()
    arch = platform.machine()
    python_version = platform.python_version()

    machine_raw = f"{hostname}|{os_name}|{arch}|{platform.processor()}"
    machine_id = hashlib.sha256(machine_raw.encode()).hexdigest()[:16]

    session_id = str(uuid.uuid4())[:8]

    return {
        "user": username,
        "hostname": hostname,
        "ip": ip_address,
        "os": f"{os_name} {os_release}",
        "os_version": os_version,
        "arch": arch,
        "python": python_version,
        "machine_id": machine_id,
        "session_id": session_id,
    }


_cached_identity = None


def get_identity():
    """Get cached system identity (computed once per process)."""
    global _cached_identity
    if _cached_identity is None:
        _cached_identity = get_system_identity()
    return _cached_identity


# ─── Agent identity (Ed25519, new) ──────────────────────────────────────

IDENTITY_DIR = Path.home() / ".boundaryai"
IDENTITY_FILE = IDENTITY_DIR / "identity.pem"


@dataclass
class AgentIdentity:
    """Cryptographic identity for an agent. Private key stays on this machine."""

    fingerprint: str                                    # sha256(public_key)[:32]
    public_key_b64: str                                 # base64 of raw 32 bytes
    _private_key: object = field(default=None, repr=False)

    def sign(self, message: bytes) -> str:
        """Sign a message (e.g., engine nonce) with the private key. Returns base64."""
        if self._private_key is None:
            raise RuntimeError("no private key available to sign")
        sig = self._private_key.sign(message)
        return base64.b64encode(sig).decode("ascii")

    def to_registration_payload(self, agent_id: str, nonce: str) -> dict:
        """Build the body for POST /v1/admin/agents/identity."""
        return {
            "agent_id": agent_id,
            "fingerprint": self.fingerprint,
            "public_key": self.public_key_b64,
            "nonce": nonce,
            "signature": self.sign(nonce.encode()),
        }


def _ensure_identity_dir():
    IDENTITY_DIR.mkdir(parents=True, exist_ok=True)
    try:
        # 0700 on POSIX; no-op on Windows
        os.chmod(IDENTITY_DIR, stat.S_IRWXU)
    except Exception:
        pass


def _write_private_key(private_key) -> None:
    """Write PEM-encoded private key with 0600 permissions."""
    _ensure_identity_dir()
    pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    with open(IDENTITY_FILE, "wb") as f:
        f.write(pem)
    try:
        # Restrict permissions (POSIX only; chmod is a no-op on Windows but safe)
        os.chmod(IDENTITY_FILE, stat.S_IRUSR | stat.S_IWUSR)
    except Exception:
        pass


def _load_private_key():
    """Load existing private key from disk, or None if missing."""
    if not IDENTITY_FILE.exists():
        return None
    try:
        with open(IDENTITY_FILE, "rb") as f:
            return serialization.load_pem_private_key(f.read(), password=None)
    except Exception:
        return None


def _generate_or_load_identity() -> Optional[AgentIdentity]:
    """Generate a new Ed25519 keypair or load the existing one."""
    if not _HAS_CRYPTOGRAPHY:
        return None

    private_key = _load_private_key()
    if private_key is None:
        private_key = ed25519.Ed25519PrivateKey.generate()
        _write_private_key(private_key)

    public_key = private_key.public_key()
    pk_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    pk_b64 = base64.b64encode(pk_bytes).decode("ascii")
    fingerprint = hashlib.sha256(pk_bytes).hexdigest()[:32]

    return AgentIdentity(
        fingerprint=fingerprint,
        public_key_b64=pk_b64,
        _private_key=private_key,
    )


_cached_agent_identity: Optional[AgentIdentity] = None


def get_agent_identity() -> Optional[AgentIdentity]:
    """
    Get this machine's Ed25519 agent identity.
    Generates on first call, then caches.
    Returns None if `cryptography` is not installed.
    """
    global _cached_agent_identity
    if _cached_agent_identity is None:
        _cached_agent_identity = _generate_or_load_identity()
    return _cached_agent_identity


def rotate_identity() -> Optional[AgentIdentity]:
    """Forcibly generate a new keypair, overwriting the current one. Returns new identity."""
    global _cached_agent_identity
    if IDENTITY_FILE.exists():
        try:
            IDENTITY_FILE.unlink()
        except Exception:
            pass
    _cached_agent_identity = None
    return get_agent_identity()
