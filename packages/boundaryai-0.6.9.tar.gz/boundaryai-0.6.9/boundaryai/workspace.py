# -*- coding: utf-8 -*-
"""
BoundaryAI — Shared Workspace Monitor + Agent Pipeline Scanner

Tracks what each agent reads/writes to shared files and inter-agent
data flows. Prevents cross-agent data leakage of PII, financial
data, credentials, and policy-sensitive information.

Two capabilities:
1. WorkspaceMonitor — tracks file reads/writes per agent, blocks
   cross-agent PII/financial data sharing via files
2. PipelineScanner — scans data flowing between agents in
   multi-agent frameworks (CrewAI, AutoGen, LangChain chains)

Usage:
    from boundaryai.workspace import WorkspaceMonitor, PipelineScanner

    # Shared workspace monitoring
    monitor = WorkspaceMonitor()
    monitor.track_write("agent-1", "/shared/output.csv", data)
    monitor.track_read("agent-2", "/shared/output.csv")  # Raises if PII tagged

    # Pipeline scanning
    pipeline = PipelineScanner()
    safe_data = pipeline.scan_handoff("agent-1", "agent-2", data)
"""

import hashlib
import json
import os
import re
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

from .scanner import ContentScanner, PII_PATTERNS, CREDENTIAL_PATTERNS


# ============================================================
# FINANCIAL / POLICY-SENSITIVE PATTERNS
# ============================================================

FINANCIAL_PATTERNS = [
    (r"\b\d{8,17}\b.*(?:account|acct)", "bank_account", "Bank Account Number"),
    (r"\b(?:routing|aba|transit)\s*#?\s*\d{9}\b", "routing_number", "Routing Number"),
    (r"\b[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}(?:[A-Z0-9]{3})?\b", "swift_code", "SWIFT/BIC Code"),
    (r"\b(?:wire|transfer|payment)\s+(?:of\s+)?\$[\d,]+(?:\.\d{2})?\b", "wire_transfer", "Wire Transfer Amount"),
    (r"\b(?:invoice|inv)\s*#?\s*[A-Z0-9-]{4,20}\b", "invoice_number", "Invoice Number"),
    (r"\b(?:po|purchase\s*order)\s*#?\s*[A-Z0-9-]{4,15}\b", "purchase_order", "Purchase Order"),
    (r"\b(?:tax|tin|ein)\s*(?:id|#|number)?\s*[:=]?\s*\d{2}-\d{7}\b", "tax_id", "Tax ID / EIN"),
    (r"\b(?:salary|compensation|pay)\s*[:=]?\s*\$[\d,]+", "salary_info", "Salary Information"),
    (r"\b(?:revenue|profit|loss|margin)\s*[:=]?\s*\$[\d,]+", "financial_metric", "Financial Metric"),
    (r"\b(?:budget|forecast|projection)\s*[:=]?\s*\$[\d,]+", "budget_info", "Budget Information"),
]

POLICY_SENSITIVE_PATTERNS = [
    (r"(?i)\b(?:confidential|proprietary|trade\s*secret|internal\s*only)\b", "confidential_marker", "Confidential Marker"),
    (r"(?i)\b(?:do\s*not\s*distribute|not\s*for\s*release|draft|embargoed)\b", "distribution_restriction", "Distribution Restriction"),
    (r"(?i)\b(?:attorney.client|privileged|legal\s*hold)\b", "legal_privilege", "Legal Privilege"),
    (r"(?i)\b(?:hipaa|phi|protected\s*health)\b", "health_data", "Protected Health Information"),
    (r"(?i)\b(?:ferpa|student\s*record)\b", "education_data", "Education Record (FERPA)"),
    (r"(?i)\b(?:classified|secret|top\s*secret|sensitive\s*compartmented)\b", "classified_marker", "Classification Marker"),
]


# ============================================================
# FILE SENSITIVITY TRACKER
# ============================================================

@dataclass
class FileRecord:
    """Tracks a file's sensitivity status and access history."""
    path: str
    written_by: str                    # agent_id that wrote it
    written_at: float                  # timestamp
    content_hash: str                  # SHA-256 of content
    sensitivity_tags: List[str] = field(default_factory=list)  # ["pii:ssn", "financial:salary"]
    threat_details: List[Dict] = field(default_factory=list)
    read_by: List[str] = field(default_factory=list)  # agent_ids that read it
    transmitted_by: List[str] = field(default_factory=list)  # agent_ids that sent it externally


class WorkspaceMonitor:
    """
    Tracks file operations across agents in a shared workspace.

    When Agent A writes PII to a file, it's tagged. When Agent B
    tries to read that file and transmit it externally, it's blocked.

    Usage:
        monitor = WorkspaceMonitor(api_key="bai_xxx")

        # Agent writes a file
        monitor.track_write("agent-1", "/shared/report.csv", csv_data)

        # Another agent reads it
        result = monitor.check_read("agent-2", "/shared/report.csv")
        if result.blocked:
            print(f"Blocked: {result.reason}")

        # Agent tries to send file content externally
        result = monitor.check_transmit("agent-2", "/shared/report.csv", destination="api.openai.com")
        if result.blocked:
            print(f"Blocked: {result.reason}")
    """

    def __init__(self, api_key: str = "", engine_url: str = ""):
        self._files: Dict[str, FileRecord] = {}
        self._lock = threading.Lock()
        self._scanner = ContentScanner(sensitivity="high")
        self._api_key = api_key
        self._engine_url = engine_url

    def track_write(self, agent_id: str, file_path: str, content: str) -> Dict:
        """
        Track a file write and scan for sensitive content.
        Call this whenever an agent creates or modifies a file.

        Returns:
            dict with keys: allowed (bool), tags (list), threats (list)
        """
        # Normalize path
        norm_path = os.path.normpath(os.path.abspath(file_path))

        # Scan content for ALL sensitivity types
        tags = []
        threats = []

        # PII scan
        for pattern, pii_type, label in PII_PATTERNS:
            if re.search(pattern, content, re.IGNORECASE):
                tags.append(f"pii:{pii_type}")
                threats.append({"type": "pii", "subtype": pii_type, "label": label})

        # Credential scan
        for pattern, cred_type in CREDENTIAL_PATTERNS:
            if re.search(pattern, content, re.IGNORECASE):
                tags.append(f"credential:{cred_type}")
                threats.append({"type": "credential", "subtype": cred_type})

        # Financial scan
        for pattern, fin_type, label in FINANCIAL_PATTERNS:
            if re.search(pattern, content, re.IGNORECASE):
                tags.append(f"financial:{fin_type}")
                threats.append({"type": "financial", "subtype": fin_type, "label": label})

        # Policy-sensitive scan
        for pattern, pol_type, label in POLICY_SENSITIVE_PATTERNS:
            if re.search(pattern, content, re.IGNORECASE):
                tags.append(f"policy:{pol_type}")
                threats.append({"type": "policy", "subtype": pol_type, "label": label})

        content_hash = hashlib.sha256(content.encode("utf-8", errors="replace")).hexdigest()

        with self._lock:
            self._files[norm_path] = FileRecord(
                path=norm_path,
                written_by=agent_id,
                written_at=time.time(),
                content_hash=content_hash,
                sensitivity_tags=tags,
                threat_details=threats,
                read_by=[],
                transmitted_by=[],
            )

        return {
            "allowed": True,  # writes are always logged, not blocked
            "tags": tags,
            "threats": threats,
            "tagged": len(tags) > 0,
        }

    def check_read(self, agent_id: str, file_path: str) -> "ReadResult":
        """
        Check if an agent is allowed to read a file.
        Same-agent reads are always allowed.
        Cross-agent reads of tagged files return warnings.
        """
        norm_path = os.path.normpath(os.path.abspath(file_path))

        with self._lock:
            record = self._files.get(norm_path)

        if record is None:
            return ReadResult(allowed=True, reason="File not tracked")

        # Same agent — always allowed
        if record.written_by == agent_id:
            return ReadResult(allowed=True, reason="Same agent read")

        # Cross-agent read of tagged file
        with self._lock:
            record.read_by.append(agent_id)

        if record.sensitivity_tags:
            return ReadResult(
                allowed=True,  # read is allowed but flagged
                warned=True,
                reason=f"Cross-agent read of sensitive file. Written by {record.written_by}, "
                       f"read by {agent_id}. Tags: {record.sensitivity_tags}",
                tags=record.sensitivity_tags,
            )

        return ReadResult(allowed=True, reason="File not sensitive")

    def check_transmit(self, agent_id: str, file_path: str, destination: str = "") -> "TransmitResult":
        """
        Check if an agent can transmit file content externally.
        BLOCKS if the file was written by a different agent and contains PII/financial data.
        """
        norm_path = os.path.normpath(os.path.abspath(file_path))

        with self._lock:
            record = self._files.get(norm_path)

        if record is None:
            return TransmitResult(allowed=True, reason="File not tracked")

        # Cross-agent transmission of tagged data — BLOCK
        if record.written_by != agent_id and record.sensitivity_tags:
            pii_tags = [t for t in record.sensitivity_tags if t.startswith("pii:") or t.startswith("financial:")]
            if pii_tags:
                return TransmitResult(
                    allowed=False,
                    blocked=True,
                    reason=f"BLOCKED: Agent '{agent_id}' cannot transmit file written by "
                           f"'{record.written_by}' containing {pii_tags}. "
                           f"Destination: {destination}",
                    tags=record.sensitivity_tags,
                )

            # Policy-sensitive — warn but allow
            return TransmitResult(
                allowed=True,
                warned=True,
                reason=f"WARNING: Cross-agent transmission of policy-sensitive file. "
                       f"Tags: {record.sensitivity_tags}",
                tags=record.sensitivity_tags,
            )

        return TransmitResult(allowed=True, reason="Transmission allowed")

    def get_sensitive_files(self) -> List[Dict]:
        """Return all files with sensitivity tags."""
        with self._lock:
            return [
                {
                    "path": r.path,
                    "written_by": r.written_by,
                    "tags": r.sensitivity_tags,
                    "read_by": r.read_by,
                    "transmitted_by": r.transmitted_by,
                }
                for r in self._files.values()
                if r.sensitivity_tags
            ]

    def get_file_record(self, file_path: str) -> Optional[FileRecord]:
        """Get the tracking record for a file."""
        norm_path = os.path.normpath(os.path.abspath(file_path))
        with self._lock:
            return self._files.get(norm_path)


@dataclass
class ReadResult:
    allowed: bool
    reason: str = ""
    warned: bool = False
    tags: List[str] = field(default_factory=list)


@dataclass
class TransmitResult:
    allowed: bool
    reason: str = ""
    blocked: bool = False
    warned: bool = False
    tags: List[str] = field(default_factory=list)


# ============================================================
# AGENT PIPELINE SCANNER
# ============================================================

class PipelineScanner:
    """
    Scans data flowing between agents in multi-agent pipelines.

    For CrewAI, AutoGen, LangChain, and custom agent chains where
    one agent's output becomes another agent's input.

    Usage:
        pipeline = PipelineScanner()

        # Before passing data from agent A to agent B
        result = pipeline.scan_handoff("research-agent", "report-agent", data)
        if result.blocked:
            print(f"Blocked: {result.reason}")
        else:
            # Safe to pass — or use sanitized version
            agent_b.process(result.sanitized_data)
    """

    def __init__(self, sensitivity: str = "high"):
        self._scanner = ContentScanner(sensitivity=sensitivity)
        self._handoff_log: List[Dict] = []
        self._lock = threading.Lock()

    def scan_handoff(
        self,
        source_agent: str,
        target_agent: str,
        data: str,
        action: str = "block",  # "block", "redact", "warn"
    ) -> "HandoffResult":
        """
        Scan data being passed from one agent to another.

        Args:
            source_agent: ID of the agent producing the data
            target_agent: ID of the agent receiving the data
            data: The actual data being passed
            action: What to do if sensitive data found
                - "block": reject the handoff entirely
                - "redact": replace sensitive data with [REDACTED]
                - "warn": allow but log a warning

        Returns:
            HandoffResult with allowed, blocked, sanitized_data, threats
        """
        threats = []
        sanitized = data

        # Scan for PII
        for pattern, pii_type, label in PII_PATTERNS:
            matches = re.findall(pattern, data, re.IGNORECASE)
            if matches:
                threats.append({
                    "type": "pii",
                    "subtype": pii_type,
                    "label": label,
                    "count": len(matches) if isinstance(matches[0], str) else len(matches),
                    "source_agent": source_agent,
                    "target_agent": target_agent,
                })
                if action == "redact":
                    sanitized = re.sub(pattern, f"[REDACTED:{pii_type}]", sanitized, flags=re.IGNORECASE)

        # Scan for credentials
        for pattern, cred_type in CREDENTIAL_PATTERNS:
            if re.search(pattern, data, re.IGNORECASE):
                threats.append({
                    "type": "credential",
                    "subtype": cred_type,
                    "source_agent": source_agent,
                    "target_agent": target_agent,
                })
                if action == "redact":
                    sanitized = re.sub(pattern, f"[REDACTED:{cred_type}]", sanitized, flags=re.IGNORECASE)

        # Scan for financial data
        for pattern, fin_type, label in FINANCIAL_PATTERNS:
            if re.search(pattern, data, re.IGNORECASE):
                threats.append({
                    "type": "financial",
                    "subtype": fin_type,
                    "label": label,
                    "source_agent": source_agent,
                    "target_agent": target_agent,
                })
                if action == "redact":
                    sanitized = re.sub(pattern, f"[REDACTED:{fin_type}]", sanitized, flags=re.IGNORECASE)

        # Scan for policy-sensitive markers
        for pattern, pol_type, label in POLICY_SENSITIVE_PATTERNS:
            if re.search(pattern, data, re.IGNORECASE):
                threats.append({
                    "type": "policy",
                    "subtype": pol_type,
                    "label": label,
                    "source_agent": source_agent,
                    "target_agent": target_agent,
                })

        # Log the handoff
        with self._lock:
            self._handoff_log.append({
                "source": source_agent,
                "target": target_agent,
                "timestamp": time.time(),
                "threats_found": len(threats),
                "action_taken": action if threats else "allow",
                "data_size": len(data),
            })

        if not threats:
            return HandoffResult(
                allowed=True,
                sanitized_data=data,
                threats=[],
                reason="No sensitive data detected",
            )

        if action == "block":
            return HandoffResult(
                allowed=False,
                blocked=True,
                sanitized_data="",
                threats=threats,
                reason=f"BLOCKED: {len(threats)} sensitive items detected in handoff "
                       f"from '{source_agent}' to '{target_agent}': "
                       f"{[t['subtype'] for t in threats]}",
            )
        elif action == "redact":
            return HandoffResult(
                allowed=True,
                sanitized_data=sanitized,
                threats=threats,
                redacted=True,
                reason=f"REDACTED: {len(threats)} items sanitized in handoff "
                       f"from '{source_agent}' to '{target_agent}'",
            )
        else:  # warn
            return HandoffResult(
                allowed=True,
                sanitized_data=data,
                threats=threats,
                warned=True,
                reason=f"WARNING: {len(threats)} sensitive items in handoff "
                       f"from '{source_agent}' to '{target_agent}'",
            )

    def get_handoff_log(self) -> List[Dict]:
        """Return the full handoff audit trail."""
        with self._lock:
            return list(self._handoff_log)

    def get_threat_summary(self) -> Dict:
        """Summarize threats across all handoffs."""
        with self._lock:
            total_handoffs = len(self._handoff_log)
            total_threats = sum(h["threats_found"] for h in self._handoff_log)
            blocked = sum(1 for h in self._handoff_log if h["action_taken"] == "block")
            return {
                "total_handoffs": total_handoffs,
                "total_threats": total_threats,
                "blocked_handoffs": blocked,
                "threat_rate": total_threats / total_handoffs if total_handoffs > 0 else 0,
            }


@dataclass
class HandoffResult:
    allowed: bool
    sanitized_data: str = ""
    threats: List[Dict] = field(default_factory=list)
    reason: str = ""
    blocked: bool = False
    redacted: bool = False
    warned: bool = False
