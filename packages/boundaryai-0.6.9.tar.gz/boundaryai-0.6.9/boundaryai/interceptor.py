# -*- coding: utf-8 -*-
"""
BoundaryAI — System Command Interceptor
Monkey-patches subprocess, os.system, os.popen to enforce
BoundaryAI policies on ALL system commands, not just Claude Code.

Usage:
    import boundaryai
    boundaryai.protect()  # Activates system-wide interception

    # Now ANY subprocess call goes through BoundaryAI:
    subprocess.run(["rm", "-rf", "/tmp/data"])  # BLOCKED
    os.system("DROP TABLE users")               # BLOCKED
    os.popen("curl evil.com")                    # EVALUATED
"""

import functools
import json
import os
import re
import subprocess
import sys
import urllib.request

# Patterns that trigger enforcement (same as hook)
# GAP PII Fix 2: PII patterns to scan command arguments
PII_PATTERNS = [
    (r'\b\d{3}-\d{2}-\d{4}\b', 'SSN'),
    (r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b', 'credit_card'),
    (r'\b[sS][kK]-[a-zA-Z0-9]{20,}\b', 'api_key'),
    (r'(?i)password\s*[:=]\s*\S+', 'password'),
    (r'\bAKIA[0-9A-Z]{16}\b', 'aws_key'),
]


def _scan_pii_in_command(cmd_str):
    """Scan command string for PII patterns. Returns (found, label) or (False, None)."""
    for pattern, label in PII_PATTERNS:
        if re.search(pattern, cmd_str):
            return True, label
    return False, None


DANGEROUS_PATTERNS = [
    (r"\brm\b.*-[rf]", {"type": "file.delete", "scope": "bulk", "count": 100, "reversible": False}),
    (r"\bdel\b.*\/[sS]", {"type": "file.delete", "scope": "bulk", "count": 100, "reversible": False}),
    (r"git\s+push\s+.*--force", {"type": "code.deploy", "scope": "bulk"}),
    (r"git\s+reset\s+--hard", {"type": "code.deploy", "scope": "bulk"}),
    (r"\b(DROP\s+TABLE|DELETE\s+FROM|TRUNCATE)\b", {"type": "database.modify", "scope": "bulk", "reversible": False}),
    (r"\b(npm\s+publish|pip\s+upload|cargo\s+publish)\b", {"type": "package.publish", "scope": "single"}),
    (r"\b(chmod\s+777|chown|shutdown|reboot|mkfs)\b", {"type": "system.modify", "scope": "single", "reversible": False}),
    (r"\b(curl|wget)\s+.*\.(exe|sh|bat|ps1)\b", {"type": "network.download", "scope": "single"}),
    # Windows CMD patterns
    (r"\bdel\s+/[sfq]", {"type": "file.delete", "scope": "bulk", "reversible": False}),
    (r"\brmdir\s+/s", {"type": "file.delete", "scope": "bulk", "reversible": False}),
    (r"\bformat\s+[cCdD]:", {"type": "system.modify", "scope": "single", "reversible": False}),
    (r"\bdiskpart\b", {"type": "system.modify", "scope": "single", "reversible": False}),
    # PowerShell patterns
    (r"Remove-Item.*-Recurse", {"type": "file.delete", "scope": "bulk", "reversible": False}),
    (r"Invoke-Expression", {"type": "code.execute", "scope": "single"}),
    (r"Invoke-WebRequest.*\|.*Invoke-Expression", {"type": "network.download", "scope": "single", "reversible": False}),
    (r"Start-Process.*-Verb\s+RunAs", {"type": "system.modify", "scope": "single", "reversible": False}),
]

_original_subprocess_run = None
_original_subprocess_popen = None
_original_os_system = None
_original_os_popen = None
_original_os_execl = None
_original_os_execle = None
_original_os_execlp = None
_original_os_execlpe = None
_original_os_execv = None
_original_os_execve = None
_original_os_execvp = None
_original_os_execvpe = None
_interceptor_active = False
_config = None

# L1: Child process auto-propagation
_original_os_environ_setitem = None

# L3: Database driver interception
_original_sqlite3_execute = None
_original_sqlite3_executemany = None

# L5: HTTP library interception
_original_urlopen = None

# L2: File write interception (scan for PII in content)
_original_builtins_open = None

# SQL patterns that should be blocked
DANGEROUS_SQL_PATTERNS = [
    r"\bDROP\s+(TABLE|DATABASE|SCHEMA|INDEX)\b",
    r"\bTRUNCATE\s+TABLE\b",
    r"\bDELETE\s+FROM\s+\S+\s*(;|$)",  # DELETE without WHERE
    r"\bALTER\s+TABLE\s+\S+\s+DROP\b",
    r"\bGRANT\s+ALL\b",
    r"\bREVOKE\s+ALL\b",
]

# VULN-6 FIX: Client-side rate limiting
_rate_window = []  # timestamps of recent engine calls
_rate_limit = 100  # max engine calls per minute
_rate_window_seconds = 60


def _load_config():
    """Load BoundaryAI config"""
    global _config
    if _config:
        return _config
    try:
        config_path = os.path.expanduser("~/.boundaryai/config.json")
        with open(config_path) as f:
            _config = json.load(f)
        # Decrypt if needed
        if "api_key_encrypted" in _config and "api_key" not in _config:
            sys.path.insert(0, os.path.expanduser("~/.boundaryai"))
            from crypto import decrypt_api_key
            _config["api_key"] = decrypt_api_key(_config["api_key_encrypted"])
        return _config
    except Exception:
        return {"engine_url": "", "api_key": "", "agent_id": "interceptor"}


def _evaluate_command(cmd_str):
    """Send command to BoundaryAI engine for evaluation.
    CENTRAL ENFORCEMENT: ALL commands go to engine for decision.
    Local detection is for categorization only — engine DECIDES.
    If engine unreachable: fail-closed (block).
    """
    config = _load_config()
    engine_url = config.get("engine_url", "")
    if not engine_url:
        return "block", "No engine configured. Fail-closed."

    # VULN-6: Check rate limit before calling engine
    import time
    global _rate_window
    now = time.time()
    _rate_window = [t for t in _rate_window if now - t < _rate_window_seconds]
    if len(_rate_window) >= _rate_limit:
        return "block", "Rate limit exceeded. Too many requests."
    _rate_window.append(now)

    # Local detection: categorize the command (engine uses this for policy eval)
    action_type = "system.command"
    action_scope = "single"
    detected_patterns = []
    is_dangerous = False

    for pattern, action_dict in DANGEROUS_PATTERNS:
        if re.search(pattern, cmd_str, re.IGNORECASE):
            action_type = action_dict.get("type", "system.command")
            action_scope = action_dict.get("scope", "single")
            is_dangerous = True
            detected_patterns.append(action_type)
            break

    # PII scan — categorize for engine
    pii_found, pii_label = _scan_pii_in_command(cmd_str)

    # Get system identity for audit tracking
    try:
        from .identity import get_identity
        identity = get_identity()
    except Exception:
        identity = {"user": "unknown", "hostname": "unknown"}

    payload = {
        "agent_id": config.get("agent_id", "interceptor"),
        "action": {
            "type": action_type,
            "scope": action_scope,
            "command": cmd_str,
            "params": {
                "source": "interceptor",
                "dangerous_pattern": "true" if is_dangerous else "false",
                "pii_detected": pii_label or "",
                "detected_patterns": ",".join(detected_patterns),
            }
        },
        "context": {
            "user_id": identity.get("user", ""),
            "hostname": identity.get("hostname", ""),
            "ip": identity.get("ip", ""),
            "os": identity.get("os", ""),
            "machine_id": identity.get("machine_id", ""),
            "session_id": identity.get("session_id", ""),
            "source_channel": "python_sdk",
        }
    }
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            f"{engine_url}/v1/evaluate",
            data=data,
            headers={
                "Content-Type": "application/json",
                "X-Boundary-Key": config.get("api_key", "")
            },
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return result.get("decision", "allow"), result.get("reason", "")
    except Exception:
        # FAIL-CLOSED: Engine unreachable — block dangerous commands, allow safe ones
        if is_dangerous or pii_found:
            return "block", f"Engine unreachable, fail-closed for: {action_type}"
        return "block", "Engine unreachable. Fail-closed."


def _cmd_to_string(args):
    """Convert subprocess args to a string for analysis"""
    if isinstance(args, str):
        return args
    if isinstance(args, (list, tuple)):
        return " ".join(str(a) for a in args)
    return str(args)


class BoundaryAIBlocked(PermissionError):
    """Raised when BoundaryAI blocks a system command"""
    def __init__(self, command, reason):
        self.command = command
        self.reason = reason
        super().__init__(f"BoundaryAI BLOCKED: {reason} (command: {command[:100]})")


def _should_block(decision, reason):
    """Determine if decision should block execution.
    Block on 'block' AND 'confirm' (no human to confirm in automated agents)."""
    return decision in ("block", "confirm")


def _intercepted_subprocess_run(*args, **kwargs):
    """Intercepted subprocess.run — evaluates BEFORE executing"""
    cmd_str = _cmd_to_string(args[0] if args else kwargs.get("args", ""))
    # GAP PII Fix 2: Scan for PII in command arguments before execution
    pii_found, pii_label = _scan_pii_in_command(cmd_str)
    if pii_found:
        raise BoundaryAIBlocked(cmd_str, f"PII detected in command arguments: {pii_label}")
    # Evaluate FIRST — before subprocess tries to find the binary
    decision, reason = _evaluate_command(cmd_str)
    if _should_block(decision, reason):
        raise BoundaryAIBlocked(cmd_str, reason or f"Action requires confirmation (decision: {decision})")
    # Only execute if allowed
    return _original_subprocess_run(*args, **kwargs)


def _intercepted_subprocess_popen(*args, **kwargs):
    """Intercepted subprocess.Popen — evaluates BEFORE executing"""
    cmd_str = _cmd_to_string(args[0] if args else kwargs.get("args", ""))
    # GAP PII Fix 2: Scan for PII in command arguments before execution
    pii_found, pii_label = _scan_pii_in_command(cmd_str)
    if pii_found:
        raise BoundaryAIBlocked(cmd_str, f"PII detected in command arguments: {pii_label}")
    decision, reason = _evaluate_command(cmd_str)
    if _should_block(decision, reason):
        raise BoundaryAIBlocked(cmd_str, reason or f"Action requires confirmation (decision: {decision})")
    return _original_subprocess_popen(*args, **kwargs)


def _intercepted_os_system(command):
    """Intercepted os.system"""
    cmd_str = str(command)
    # GAP PII Fix 2: Scan for PII in command arguments before execution
    pii_found, pii_label = _scan_pii_in_command(cmd_str)
    if pii_found:
        raise BoundaryAIBlocked(cmd_str, f"PII detected in command arguments: {pii_label}")
    decision, reason = _evaluate_command(cmd_str)
    if _should_block(decision, reason):
        raise BoundaryAIBlocked(cmd_str, reason or f"Action requires confirmation (decision: {decision})")
    return _original_os_system(command)


def _intercepted_os_popen(command, *args, **kwargs):
    """Intercepted os.popen"""
    decision, reason = _evaluate_command(str(command))
    if _should_block(decision, reason):
        raise BoundaryAIBlocked(str(command), reason or f"Action requires confirmation (decision: {decision})")
    return _original_os_popen(command, *args, **kwargs)


def _make_exec_interceptor(original_fn, uses_list_args):
    """Create an intercepted wrapper for an os.exec* function.
    uses_list_args=True for execv variants (args is a list),
    uses_list_args=False for execl variants (args are positional)."""
    if uses_list_args:
        def intercepted(path_or_file, args, *extra, **kwargs):
            cmd_str = _cmd_to_string([path_or_file] + list(args))
            decision, reason = _evaluate_command(cmd_str)
            if _should_block(decision, reason):
                raise BoundaryAIBlocked(cmd_str, reason or f"Action requires confirmation (decision: {decision})")
            return original_fn(path_or_file, args, *extra, **kwargs)
    else:
        def intercepted(path_or_file, *args, **kwargs):
            cmd_str = _cmd_to_string([path_or_file] + list(args))
            decision, reason = _evaluate_command(cmd_str)
            if _should_block(decision, reason):
                raise BoundaryAIBlocked(cmd_str, reason or f"Action requires confirmation (decision: {decision})")
            return original_fn(path_or_file, *args, **kwargs)
    return intercepted


# ============================================================
# L1: Child Process Auto-Propagation
# ============================================================

def _intercepted_environ_setitem(self, key, value):
    """L4: Intercept os.environ writes to scan for PII in values."""
    pii_found, pii_label = _scan_pii_in_command(str(value))
    if pii_found:
        import logging
        logging.getLogger("boundaryai").warning(
            f"BoundaryAI: PII ({pii_label}) detected in environment variable '{key}'. "
            f"Value stored but flagged for audit."
        )
    _original_os_environ_setitem(self, key, value)


def _inject_child_protection():
    """L1: Set env var so child Python processes auto-activate protection."""
    os.environ["BOUNDARYAI_PROTECT"] = "1"


def _remove_child_protection():
    """L1: Remove auto-protection env var."""
    os.environ.pop("BOUNDARYAI_PROTECT", None)


# ============================================================
# L2: File Write Interception (scan content for PII)
# ============================================================

class _InterceptedFile:
    """L2: Wraps file objects opened in write mode to scan content for PII."""

    def __init__(self, file_obj, filepath):
        self._file = file_obj
        self._filepath = filepath

    def write(self, data):
        if isinstance(data, str) and len(data) > 5:
            pii_found, pii_label = _scan_pii_in_command(data)
            if pii_found:
                import logging
                logging.getLogger("boundaryai").warning(
                    f"BoundaryAI: PII ({pii_label}) detected in file write to '{self._filepath}'. Flagged for audit."
                )
                # Track in workspace monitor if available
                try:
                    from .workspace import WorkspaceMonitor
                    _workspace = WorkspaceMonitor()
                    _workspace.track_write("interceptor", self._filepath, data)
                except ImportError:
                    pass
        return self._file.write(data)

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return self._file.__exit__(*args)

    def __iter__(self):
        return iter(self._file)


def _intercepted_open(file, mode="r", *args, **kwargs):
    """L2: Intercept builtins.open to scan write content for PII."""
    f = _original_builtins_open(file, mode, *args, **kwargs)
    if "w" in mode or "a" in mode:
        return _InterceptedFile(f, str(file))
    return f


# ============================================================
# L3: Database Driver Interception
# Uses sqlite3.connect wrapper since Cursor is immutable C type
# ============================================================

_original_sqlite3_connect = None


def _check_sql(sql):
    """L3: Check SQL for destructive patterns."""
    sql_upper = sql.strip().upper() if isinstance(sql, str) else ""
    for pattern in DANGEROUS_SQL_PATTERNS:
        if re.search(pattern, sql_upper):
            raise BoundaryAIBlocked(sql, f"Destructive SQL blocked: {sql[:80]}")


class _SafeCursor:
    """L3: Wraps sqlite3.Cursor to intercept execute calls."""
    def __init__(self, cursor):
        self._cursor = cursor

    def execute(self, sql, *args, **kwargs):
        _check_sql(sql)
        return self._cursor.execute(sql, *args, **kwargs)

    def executemany(self, sql, *args, **kwargs):
        _check_sql(sql)
        return self._cursor.executemany(sql, *args, **kwargs)

    def __getattr__(self, name):
        return getattr(self._cursor, name)

    def __iter__(self):
        return iter(self._cursor)


class _SafeConnection:
    """L3: Wraps sqlite3.Connection to return SafeCursor."""
    def __init__(self, conn):
        self._conn = conn

    def cursor(self, *args, **kwargs):
        return _SafeCursor(self._conn.cursor(*args, **kwargs))

    def execute(self, sql, *args, **kwargs):
        _check_sql(sql)
        return self._conn.execute(sql, *args, **kwargs)

    def executemany(self, sql, *args, **kwargs):
        _check_sql(sql)
        return self._conn.executemany(sql, *args, **kwargs)

    def __getattr__(self, name):
        return getattr(self._conn, name)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return self._conn.__exit__(*args)


def _intercepted_sqlite3_connect(*args, **kwargs):
    """L3: Intercept sqlite3.connect to return a safe-wrapped connection."""
    conn = _original_sqlite3_connect(*args, **kwargs)
    return _SafeConnection(conn)


# ============================================================
# L5: HTTP Library Interception
# ============================================================

AI_API_DOMAINS = [
    "api.openai.com", "chat.openai.com",
    "api.anthropic.com", "claude.ai",
    "generativelanguage.googleapis.com", "gemini.google.com",
    "api.cohere.ai",
    "api.mistral.ai",
]


def _intercepted_urlopen(url, data=None, *args, **kwargs):
    """L5: Intercept urllib.request.urlopen to scan outbound data for PII.
    Also routes AI API calls through BoundaryAI proxy if configured."""
    url_str = str(url.full_url if hasattr(url, "full_url") else url)
    config = _load_config()
    engine_url = config.get("engine_url", "boundaryai-engine")

    # Don't intercept BoundaryAI's own engine calls
    if engine_url and engine_url in url_str:
        return _original_urlopen(url, data, *args, **kwargs)

    # Scan outbound data for PII
    outbound_data = data
    if outbound_data is None and hasattr(url, "data") and url.data:
        outbound_data = url.data

    if outbound_data:
        data_str = outbound_data.decode("utf-8", errors="replace") if isinstance(outbound_data, bytes) else str(outbound_data)
        pii_found, pii_label = _scan_pii_in_command(data_str)
        if pii_found:
            raise BoundaryAIBlocked(
                url_str,
                f"PII ({pii_label}) detected in outbound HTTP request to {url_str[:60]}"
            )

    # Route AI API calls through BoundaryAI proxy if engine is configured
    if engine_url and any(domain in url_str for domain in AI_API_DOMAINS):
        proxy_url = config.get("proxy_url", "")
        if not proxy_url:
            # Auto-construct proxy URL from engine URL
            if "api.openai.com" in url_str:
                proxy_url = f"{engine_url}/proxy/openai"
            elif "api.anthropic.com" in url_str:
                proxy_url = f"{engine_url}/proxy/anthropic"
            elif "generativelanguage.googleapis.com" in url_str:
                proxy_url = f"{engine_url}/proxy/google"

        if proxy_url:
            # Rewrite URL to go through proxy
            import logging
            logging.getLogger("boundaryai").info(f"Routing AI API call through BoundaryAI proxy: {url_str[:40]} → {proxy_url[:40]}")
            # Replace the AI domain with proxy URL
            for domain in AI_API_DOMAINS:
                if domain in url_str:
                    proxied_url = url_str.replace(f"https://{domain}", proxy_url).replace(f"http://{domain}", proxy_url)
                    if hasattr(url, "full_url"):
                        url.full_url = proxied_url
                    else:
                        url = proxied_url
                    break

    return _original_urlopen(url, data, *args, **kwargs)


def activate():
    """Activate FULL system-wide protection.

    Patches ALL layers:
    - subprocess.run, subprocess.Popen, os.system, os.popen (commands)
    - os.exec* family (9 variants)
    - builtins.open (file writes scanned for PII) [L2]
    - sqlite3.Cursor.execute (destructive SQL blocked) [L3]
    - os.environ (PII in env vars flagged) [L4]
    - urllib.request.urlopen (outbound HTTP scanned for PII) [L5]
    - Child process auto-propagation via BOUNDARYAI_PROTECT env var [L1]
    """
    global _original_subprocess_run, _original_subprocess_popen
    global _original_os_system, _original_os_popen
    global _original_os_execl, _original_os_execle
    global _original_os_execlp, _original_os_execlpe
    global _original_os_execv, _original_os_execve
    global _original_os_execvp, _original_os_execvpe
    global _original_os_environ_setitem
    global _original_sqlite3_execute, _original_sqlite3_executemany
    global _original_urlopen, _original_builtins_open
    global _interceptor_active

    if _interceptor_active:
        return  # Already active

    # === LAYER 1: subprocess + os.system + os.popen ===
    _original_subprocess_run = subprocess.run
    _original_subprocess_popen = subprocess.Popen
    _original_os_system = os.system
    _original_os_popen = os.popen

    subprocess.run = _intercepted_subprocess_run
    subprocess.Popen = _intercepted_subprocess_popen
    os.system = _intercepted_os_system
    os.popen = _intercepted_os_popen

    # === LAYER 2: os.exec* family (9 variants) ===
    _original_os_execl = os.execl
    _original_os_execle = os.execle
    _original_os_execlp = os.execlp
    _original_os_execlpe = os.execlpe
    _original_os_execv = os.execv
    _original_os_execve = os.execve
    _original_os_execvp = os.execvp
    _original_os_execvpe = os.execvpe

    os.execl = _make_exec_interceptor(_original_os_execl, uses_list_args=False)
    os.execle = _make_exec_interceptor(_original_os_execle, uses_list_args=False)
    os.execlp = _make_exec_interceptor(_original_os_execlp, uses_list_args=False)
    os.execlpe = _make_exec_interceptor(_original_os_execlpe, uses_list_args=False)
    os.execv = _make_exec_interceptor(_original_os_execv, uses_list_args=True)
    os.execve = _make_exec_interceptor(_original_os_execve, uses_list_args=True)
    os.execvp = _make_exec_interceptor(_original_os_execvp, uses_list_args=True)
    os.execvpe = _make_exec_interceptor(_original_os_execvpe, uses_list_args=True)

    # === L1: Child process auto-propagation ===
    _inject_child_protection()

    # === L2: File write PII scanning ===
    import builtins
    _original_builtins_open = builtins.open
    builtins.open = _intercepted_open

    # === L3: Database driver interception ===
    global _original_sqlite3_connect
    try:
        import sqlite3
        _original_sqlite3_connect = sqlite3.connect
        sqlite3.connect = _intercepted_sqlite3_connect
    except (ImportError, AttributeError):
        pass  # sqlite3 not available

    # === L4: Environment variable PII detection ===
    _original_os_environ_setitem = os.environ.__class__.__setitem__
    os.environ.__class__.__setitem__ = _intercepted_environ_setitem

    # === L5: HTTP outbound PII scanning ===
    _original_urlopen = urllib.request.urlopen
    urllib.request.urlopen = _intercepted_urlopen

    # Patch requests library if installed
    try:
        import requests as _requests_lib
        _original_requests_post = _requests_lib.post
        _original_requests_put = _requests_lib.put

        def _intercepted_requests_post(url, data=None, json=None, **kwargs):
            outbound = str(data or "") + str(json or "")
            if outbound and len(outbound) > 5:
                pii_found, pii_label = _scan_pii_in_command(outbound)
                config = _load_config()
                engine_url = config.get("engine_url", "boundaryai-engine")
                if pii_found and engine_url not in str(url):
                    raise BoundaryAIBlocked(str(url), f"PII ({pii_label}) in outbound POST to {str(url)[:60]}")
            return _original_requests_post(url, data=data, json=json, **kwargs)

        def _intercepted_requests_put(url, data=None, json=None, **kwargs):
            outbound = str(data or "") + str(json or "")
            if outbound and len(outbound) > 5:
                pii_found, pii_label = _scan_pii_in_command(outbound)
                config = _load_config()
                engine_url = config.get("engine_url", "boundaryai-engine")
                if pii_found and engine_url not in str(url):
                    raise BoundaryAIBlocked(str(url), f"PII ({pii_label}) in outbound PUT to {str(url)[:60]}")
            return _original_requests_put(url, data=data, json=json, **kwargs)

        _requests_lib.post = _intercepted_requests_post
        _requests_lib.put = _intercepted_requests_put
    except ImportError:
        pass  # requests not installed

    _interceptor_active = True


def deactivate():
    """Restore ALL original system functions — reverses everything activate() patched."""
    global _interceptor_active
    if not _interceptor_active:
        return

    # Restore subprocess + os.system
    subprocess.run = _original_subprocess_run
    subprocess.Popen = _original_subprocess_popen
    os.system = _original_os_system
    os.popen = _original_os_popen

    # Restore os.exec* family
    os.execl = _original_os_execl
    os.execle = _original_os_execle
    os.execlp = _original_os_execlp
    os.execlpe = _original_os_execlpe
    os.execv = _original_os_execv
    os.execve = _original_os_execve
    os.execvp = _original_os_execvp
    os.execvpe = _original_os_execvpe

    # L1: Remove child protection env var
    _remove_child_protection()

    # L2: Restore builtins.open
    if _original_builtins_open:
        import builtins
        builtins.open = _original_builtins_open

    # L3: Restore sqlite3.connect
    if _original_sqlite3_connect:
        try:
            import sqlite3
            sqlite3.connect = _original_sqlite3_connect
        except (ImportError, AttributeError):
            pass

    # L4: Restore os.environ
    if _original_os_environ_setitem:
        os.environ.__class__.__setitem__ = _original_os_environ_setitem

    # L5: Restore urllib
    if _original_urlopen:
        urllib.request.urlopen = _original_urlopen

    _interceptor_active = False


def is_active():
    return _interceptor_active


# ============================================================
# L1: Auto-activate in child processes
# If BOUNDARYAI_PROTECT=1 env var is set, activate on import
# ============================================================

if os.environ.get("BOUNDARYAI_PROTECT") == "1" and not _interceptor_active:
    activate()


# ============================================================
# Test
# ============================================================

if __name__ == "__main__":
    print("BoundaryAI System Command Interceptor — Test")
    print("=" * 50)

    activate()
    print(f"Interceptor active: {is_active()}")
    print()

    tests = [
        ("Safe: echo hello", "echo hello"),
        ("Safe: ls -la", "ls -la"),
        ("BLOCK: rm -rf", "rm -rf /tmp/data"),
        ("BLOCK: DROP TABLE", "psql -c 'DROP TABLE users'"),
        ("BLOCK: npm publish", "npm publish"),
        ("BLOCK: git push --force", "git push --force origin main"),
    ]

    for name, cmd in tests:
        try:
            # Use os.system to test interception
            result = os.system(cmd)
            print(f"  {name}: ALLOWED (exit: {result})")
        except BoundaryAIBlocked as e:
            print(f"  {name}: BLOCKED ({e.reason[:60]})")
        except Exception as e:
            print(f"  {name}: ERROR ({e})")

    deactivate()
    print(f"\nInterceptor active: {is_active()}")
