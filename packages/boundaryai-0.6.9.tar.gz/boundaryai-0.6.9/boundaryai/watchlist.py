# -*- coding: utf-8 -*-
"""
BoundaryAI — Watchlist Client
Fetches and checks custom protected terms from the engine.

Usage:
    from boundaryai.watchlist import WatchlistClient

    wl = WatchlistClient(api_key="bai_xxx", engine_url="https://engine...")

    # Check text against org's watchlist
    result = wl.check("Project Neptune revenue is $12M")
    if not result['safe']:
        print(f"Blocked: {result['matches']}")

    # Get all terms
    terms = wl.get_terms()
"""

import json
import re
import threading
import time
from urllib.request import Request, urlopen
from urllib.error import URLError


class WatchlistClient:
    """Fetches and evaluates text against custom protected terms."""

    def __init__(self, api_key="", engine_url="", cache_ttl=300):
        self.api_key = api_key
        self.engine_url = engine_url.rstrip("/")
        self.cache_ttl = cache_ttl  # seconds
        self._terms = []
        self._last_fetch = 0
        self._lock = threading.Lock()

    def get_terms(self):
        """Fetch protected terms from engine (cached)."""
        now = time.time()
        if now - self._last_fetch < self.cache_ttl and self._terms:
            return self._terms

        try:
            req = Request(
                f"{self.engine_url}/v1/watchlist",
                headers={
                    "X-Boundary-Key": self.api_key,
                    "Content-Type": "application/json",
                }
            )
            with urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read().decode())
                with self._lock:
                    self._terms = data.get("terms", [])
                    self._last_fetch = now
                return self._terms
        except (URLError, Exception):
            return self._terms  # Return cached on failure

    def check(self, text, action_override=None):
        """
        Check text against watchlist terms.

        Returns:
            dict with keys: safe, action, matches, count
        """
        terms = self.get_terms()
        text_lower = text.lower()
        matches = []

        for term in terms:
            if not term.get("enabled", True):
                continue

            matched = False
            term_text = term.get("term", "")
            match_type = term.get("match_type", "contains")

            if match_type == "exact":
                matched = text_lower == term_text.lower()
            elif match_type == "contains":
                matched = term_text.lower() in text_lower
            elif match_type == "regex":
                try:
                    matched = bool(re.search(term_text, text, re.IGNORECASE))
                except re.error:
                    pass
            elif match_type == "keyword":
                matched = any(kw.lower() in text_lower for kw in term_text.split())

            if matched:
                matches.append({
                    "term": term_text,
                    "category": term.get("category", "custom"),
                    "action": action_override or term.get("action", "block"),
                    "severity": term.get("severity", "high"),
                })

        # Determine overall action
        if any(m["action"] == "block" for m in matches):
            action = "block"
        elif any(m["action"] == "redact" for m in matches):
            action = "redact"
        elif matches:
            action = "warn"
        else:
            action = "allow"

        return {
            "safe": len(matches) == 0,
            "action": action,
            "matches": matches,
            "count": len(matches),
        }

    def check_server(self, text):
        """Check text against watchlist via engine API (server-side check)."""
        try:
            payload = json.dumps({"text": text}).encode()
            req = Request(
                f"{self.engine_url}/v1/watchlist/check",
                data=payload,
                headers={
                    "Content-Type": "application/json",
                    "X-Boundary-Key": self.api_key,
                },
                method="POST"
            )
            with urlopen(req, timeout=5) as resp:
                return json.loads(resp.read().decode())
        except Exception as e:
            return {"safe": True, "action": "allow", "matches": [], "error": str(e)}
