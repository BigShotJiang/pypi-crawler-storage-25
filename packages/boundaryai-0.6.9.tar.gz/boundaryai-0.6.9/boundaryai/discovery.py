# -*- coding: utf-8 -*-
"""
BoundaryAI Discovery Scanner — deterministic Day Zero scan.

Zero AI. Zero external network calls. Pure OS inspection + pattern matching.

Modules:
  1. Network Traffic Analyzer — DNS cache + active connections
  2. Endpoint Application Inventory — IDE ext + desktop apps + CLI tools
  3. API Key Scanner — env vars + config files (presence only, never values)
  4. Browser Extension Scanner — Chrome/Edge/Firefox extension dirs

Output: DiscoveryReport dict ready for engine admin API
(POST /v1/admin/discovery/ingest).

Ported from integrated-preview/backend/discovery/scanner.py.
"""

import glob
import hashlib
import json
import os
import platform
import re
import socket
import subprocess
from datetime import datetime, timezone

SCANNER_VERSION = "0.6.0-sdk"

# ─── Known AI provider domains ─────────────────────────────────────────
AI_DOMAINS = {
    "api.openai.com": ("OpenAI", "api"),
    "chat.openai.com": ("OpenAI", "chat"),
    "chatgpt.com": ("OpenAI", "chat"),
    "api.anthropic.com": ("Anthropic", "api"),
    "claude.ai": ("Anthropic", "chat"),
    "generativelanguage.googleapis.com": ("Google", "api"),
    "gemini.google.com": ("Google", "chat"),
    "aistudio.google.com": ("Google", "studio"),
    "copilot.microsoft.com": ("Microsoft", "chat"),
    "api.cohere.ai": ("Cohere", "api"),
    "api.mistral.ai": ("Mistral", "api"),
    "api.together.xyz": ("Together", "api"),
    "api.groq.com": ("Groq", "api"),
    "api.perplexity.ai": ("Perplexity", "api"),
    "api.deepseek.com": ("DeepSeek", "api"),
    "api.replicate.com": ("Replicate", "api"),
    "api.ai21.com": ("AI21", "api"),
    "api-inference.huggingface.co": ("HuggingFace", "api"),
}

AI_PROCESS_NAMES = {
    "claude", "claude.exe",
    "chatgpt", "chatgpt.exe",
    "copilot", "copilot.exe",
    "ollama", "ollama.exe",
    "cursor", "cursor.exe",
    "windsurf", "windsurf.exe",
    "aider", "aider.exe",
    "lmstudio", "lmstudio.exe",
    "continue", "continue.exe",
    "tabnine", "tabnine.exe",
}

VSCODE_AI_EXTENSIONS = {
    "GitHub.copilot": "GitHub Copilot",
    "GitHub.copilot-chat": "GitHub Copilot Chat",
    "Continue.continue": "Continue",
    "sourcegraph.cody-ai": "Cody",
    "tabnine.tabnine-vscode": "Tabnine",
    "amazonwebservices.aws-toolkit-vscode": "Amazon CodeWhisperer",
    "anthropic.claude-code": "Claude Code",
    "Codeium.codeium": "Codeium",
}

AI_KEY_PATTERNS = [
    "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GOOGLE_API_KEY",
    "GOOGLE_GENERATIVE_AI_API_KEY", "HUGGINGFACE_TOKEN",
    "HUGGINGFACEHUB_API_TOKEN", "COHERE_API_KEY", "MISTRAL_API_KEY",
    "TOGETHER_API_KEY", "GROQ_API_KEY", "PERPLEXITY_API_KEY",
    "DEEPSEEK_API_KEY", "REPLICATE_API_TOKEN", "AI21_API_KEY",
]


# ─── Individual scanners ───────────────────────────────────────────────

def scan_network_connections():
    """Scan DNS cache + active connections for AI domain traffic."""
    findings = []

    # 1. DNS cache
    try:
        if platform.system() == "Windows":
            result = subprocess.run(
                ["ipconfig", "/displaydns"],
                capture_output=True, text=True, timeout=10,
                creationflags=0x08000000 if hasattr(subprocess, "_winapi") else 0,
            )
            dns_output = result.stdout
            for domain, (provider, service) in AI_DOMAINS.items():
                if domain.lower() in dns_output.lower():
                    findings.append({
                        "category": "discovery.network_connection",
                        "name": domain,
                        "details": {"provider": provider, "service": service, "source": "dns_cache"},
                        "severity": "high",
                    })
    except Exception as e:
        findings.append({"category": "discovery.error", "name": "dns_scan", "details": {"error": str(e)}, "severity": "low"})

    # 2. Active netstat connections
    try:
        result = subprocess.run(["netstat", "-an"], capture_output=True, text=True, timeout=10)
        connections = result.stdout

        domain_ips = {}
        for domain, (provider, service) in AI_DOMAINS.items():
            try:
                info = socket.getaddrinfo(domain, 443, socket.AF_INET)
                for item in info[:5]:
                    domain_ips[item[4][0]] = (provider, domain)
            except Exception:
                pass

        for ip, (provider, domain) in domain_ips.items():
            if ip in connections:
                findings.append({
                    "category": "discovery.active_connection",
                    "name": domain,
                    "details": {"provider": provider, "ip": ip, "source": "netstat"},
                    "severity": "high",
                })
    except Exception as e:
        findings.append({"category": "discovery.error", "name": "netstat_scan", "details": {"error": str(e)}, "severity": "low"})

    return findings


def scan_installed_applications():
    """Scan for installed AI applications (desktop apps, CLI tools)."""
    findings = []

    # Running processes
    try:
        cmd = ["tasklist"] if platform.system() == "Windows" else ["ps", "aux"]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        running_processes = result.stdout.lower()

        for proc_name in AI_PROCESS_NAMES:
            if proc_name.lower() in running_processes:
                findings.append({
                    "category": "discovery.ai_app",
                    "name": proc_name.replace(".exe", ""),
                    "details": {"type": "desktop_app", "status": "running"},
                    "severity": "medium",
                })
    except Exception as e:
        findings.append({"category": "discovery.error", "name": "process_scan", "details": {"error": str(e)}, "severity": "low"})

    # CLI tools on PATH
    path_dirs = os.environ.get("PATH", "").split(os.pathsep)
    cli_tools = {"claude", "ollama", "aider", "chatgpt", "copilot"}
    for path_dir in path_dirs[:50]:
        try:
            if os.path.isdir(path_dir):
                for entry in os.listdir(path_dir):
                    entry_lower = entry.lower().replace(".exe", "")
                    if entry_lower in cli_tools:
                        findings.append({
                            "category": "discovery.cli_tool",
                            "name": entry_lower,
                            "details": {"path": os.path.join(path_dir, entry)},
                            "severity": "medium",
                        })
        except Exception:
            continue

    return findings


def scan_ide_extensions():
    """Scan VS Code and Cursor for AI extensions."""
    findings = []

    vscode_ext_dirs = [
        os.path.expanduser("~/.vscode/extensions"),
        os.path.expanduser("~/.vscode-server/extensions"),
        os.path.expanduser("~/.vscode-insiders/extensions"),
    ]

    for ext_dir in vscode_ext_dirs:
        if not os.path.isdir(ext_dir):
            continue
        try:
            for entry in os.listdir(ext_dir):
                for ext_id, friendly_name in VSCODE_AI_EXTENSIONS.items():
                    if entry.lower().startswith(ext_id.lower()):
                        findings.append({
                            "category": "discovery.ide_extension",
                            "name": friendly_name,
                            "details": {"extension_id": ext_id, "ide": "VS Code"},
                            "severity": "medium",
                        })
                        break
        except Exception:
            continue

    if os.path.isdir(os.path.expanduser("~/.cursor/extensions")):
        findings.append({
            "category": "discovery.ide_extension",
            "name": "Cursor IDE",
            "details": {"ide": "Cursor"},
            "severity": "medium",
        })

    return findings


def scan_api_keys():
    """Presence-only scan for AI provider API keys. NEVER stores values."""
    findings = []

    for key_name in AI_KEY_PATTERNS:
        if key_name in os.environ:
            findings.append({
                "category": "discovery.api_key_exposed",
                "name": key_name,
                "details": {
                    "source": "environment_variable",
                    "length": len(os.environ[key_name]),  # length only, never value
                },
                "severity": "critical",
            })

    env_locations = [
        os.path.expanduser("~/.env"),
        os.path.expanduser("~/Documents/.env"),
    ]
    for env_path in env_locations:
        if os.path.isfile(env_path):
            try:
                with open(env_path, "r", encoding="utf-8", errors="replace") as f:
                    content = f.read()
                for key_name in AI_KEY_PATTERNS:
                    if re.search(rf"^{re.escape(key_name)}\s*=", content, re.MULTILINE):
                        findings.append({
                            "category": "discovery.api_key_exposed",
                            "name": key_name,
                            "details": {"source": "config_file", "file": os.path.basename(env_path)},
                            "severity": "critical",
                        })
            except Exception:
                continue

    return findings


def scan_browser_extensions():
    """Scan Chrome/Edge extension directories."""
    findings = []

    browser_dirs = []
    if platform.system() == "Windows":
        user_data = os.environ.get("LOCALAPPDATA", "")
        browser_dirs = [
            os.path.join(user_data, r"Google\Chrome\User Data\Default\Extensions"),
            os.path.join(user_data, r"Microsoft\Edge\User Data\Default\Extensions"),
        ]
    elif platform.system() == "Darwin":
        browser_dirs = [
            os.path.expanduser("~/Library/Application Support/Google/Chrome/Default/Extensions"),
        ]

    for browser_dir in browser_dirs:
        if not os.path.isdir(browser_dir):
            continue
        try:
            browser_name = "Chrome" if "Chrome" in browser_dir else "Edge"
            ext_count = 0
            for ext_id in os.listdir(browser_dir):
                ext_count += 1
                if ext_id == "amcfbpnpjmfclpkfgccbijflaokjnomd":
                    findings.append({
                        "category": "discovery.browser_extension",
                        "name": "BoundaryAI",
                        "details": {"browser": browser_name, "extension_id": ext_id},
                        "severity": "low",
                    })
            if ext_count > 0:
                findings.append({
                    "category": "discovery.browser_stats",
                    "name": browser_name,
                    "details": {"total_extensions": ext_count},
                    "severity": "low",
                })
        except Exception:
            continue

    return findings


# ─── Risk score + report assembly ──────────────────────────────────────

def calculate_risk_score(findings):
    """Deterministic 0-100 score with breakdown. Matches preview."""
    score = 0
    breakdown = {}

    connections = sum(1 for f in findings if f.get("category") == "discovery.active_connection")
    breakdown["unprotected_connections"] = min(25, connections * 5)
    score += breakdown["unprotected_connections"]

    keys = sum(1 for f in findings if f.get("category") == "discovery.api_key_exposed")
    breakdown["api_keys_exposed"] = min(20, keys * 4)
    score += breakdown["api_keys_exposed"]

    apps = sum(1 for f in findings if f.get("category") in ("discovery.ai_app", "discovery.ide_extension", "discovery.cli_tool"))
    breakdown["ai_applications"] = min(15, apps * 2)
    score += breakdown["ai_applications"]

    nets = sum(1 for f in findings if f.get("category") == "discovery.network_connection")
    breakdown["network_traffic"] = min(10, nets * 2)
    score += breakdown["network_traffic"]

    level = "LOW" if score < 20 else "MEDIUM" if score < 50 else "HIGH" if score < 76 else "CRITICAL"
    return {"score": score, "level": level, "breakdown": breakdown}


def run_discovery_scan(org_id=None, machine_id=None):
    """
    Run the full Day Zero scan. Returns a DiscoveryReport dict ready to
    POST to the engine's /v1/admin/discovery/ingest endpoint.
    """
    started_at = datetime.now(timezone.utc).isoformat()

    all_findings = []
    all_findings.extend(scan_network_connections())
    all_findings.extend(scan_installed_applications())
    all_findings.extend(scan_ide_extensions())
    all_findings.extend(scan_api_keys())
    all_findings.extend(scan_browser_extensions())

    # Attach machine_id to every finding
    resolved_machine_id = machine_id or hashlib.sha256(
        f"{platform.node()}|{platform.system()}|{platform.machine()}".encode()
    ).hexdigest()[:16]
    for f in all_findings:
        f["machine_id"] = resolved_machine_id
        f["source_channel"] = "scanner"

    completed_at = datetime.now(timezone.utc).isoformat()
    risk = calculate_risk_score(all_findings)

    category_counts = {}
    for f in all_findings:
        cat = f.get("category", "unknown")
        category_counts[cat] = category_counts.get(cat, 0) + 1

    return {
        "scan_id": hashlib.sha256(f"{org_id}:{started_at}".encode()).hexdigest()[:16],
        "scanner_version": SCANNER_VERSION,
        "org_id": org_id or "unknown",
        "machine_id": resolved_machine_id,
        "started_at": started_at,
        "completed_at": completed_at,
        "machine": {
            "hostname": platform.node(),
            "os": f"{platform.system()} {platform.release()}",
            "user": os.environ.get("USER", os.environ.get("USERNAME", "unknown")),
        },
        "total_findings": len(all_findings),
        "category_counts": category_counts,
        "risk_score": risk["score"],
        "risk_level": risk["level"],
        "risk_breakdown": risk["breakdown"],
        "findings": all_findings,
    }


def anonymize_report(report):
    """Strip identifying info before sending to recommendation engine."""
    anon = dict(report)
    anon["machine"] = {
        "hostname": "Machine-001",
        "os": report["machine"]["os"],
        "user": "User-001",
    }
    for f in anon.get("findings", []):
        details = f.get("details", {})
        if isinstance(details, dict):
            if "file" in details:
                details["file"] = os.path.basename(details["file"])
            if "path" in details:
                details["path"] = "[redacted]"
    return anon


if __name__ == "__main__":
    report = run_discovery_scan(org_id="test-org")
    print(json.dumps(report, indent=2, default=str))
