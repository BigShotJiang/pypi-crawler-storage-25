from .client import (
    BoundaryClient,
    BoundaryDecision,
    BoundaryBlocked,
    BoundaryConfirmationRequired,
    quick_check,
)
from .scanner import ContentScanner
from .interceptor import activate as protect, deactivate as unprotect, BoundaryAIBlocked
from .workspace import WorkspaceMonitor, PipelineScanner
from .watchlist import WatchlistClient
from .identity import get_identity, get_agent_identity, rotate_identity, AgentIdentity
from .discovery import run_discovery_scan, anonymize_report
from .day_zero import (
    generate_full_report,
    generate_recommended_policies,
    generate_roadmap,
    generate_executive_summary,
    format_report_markdown,
)
from .decorators import (
    boundaryai_tool,
    wrap_langchain_tool,
    wrap_crewai_tool,
    wrap_openai_function,
    wrap_anthropic_tool,
    wrap_llamaindex_tool,
)

__version__ = "0.6.1"
__all__ = [
    "BoundaryClient",
    "BoundaryDecision",
    "BoundaryBlocked",
    "BoundaryConfirmationRequired",
    "BoundaryAIBlocked",
    "ContentScanner",
    "WorkspaceMonitor",
    "PipelineScanner",
    "WatchlistClient",
    "quick_check",
    "protect",
    "unprotect",
    # Identity
    "get_identity",
    "get_agent_identity",
    "rotate_identity",
    "AgentIdentity",
    # Discovery
    "run_discovery_scan",
    "anonymize_report",
    "generate_full_report",
    "generate_recommended_policies",
    "generate_roadmap",
    "generate_executive_summary",
    "format_report_markdown",
    # Framework decorators (Vorim parity + better)
    "boundaryai_tool",
    "wrap_langchain_tool",
    "wrap_crewai_tool",
    "wrap_openai_function",
    "wrap_anthropic_tool",
    "wrap_llamaindex_tool",
]
