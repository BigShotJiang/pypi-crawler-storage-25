# -*- coding: utf-8 -*-
"""
BoundaryAI Day Zero Observation Mode (v0.6.6)
==============================================

48-hour passive observation. Engine runs full policy evaluation but rewrites
every block/confirm to "allow" with the would-be decision stamped into the
audit entry. At T+N hours, the report aggregator reconstructs the risk profile
from audit_log and the AI policy proposer recommends Day One policies.

CLI:
    boundaryai observe start  --hours 48 [--org-id ORG] [--engine-url URL] [--admin-key KEY]
    boundaryai observe stop   [--org-id ORG] [--engine-url URL] [--admin-key KEY]
    boundaryai observe status [--org-id ORG]
    boundaryai observe report [--hours 48] [--out FILE.md]
    boundaryai propose-policies --from-report REPORT.json [--out policies.yaml]
"""
from __future__ import annotations

import json
import os
import sys
import textwrap
from typing import Any, Dict, List, Optional

import urllib.request
import urllib.error


# ─────────────────────────────────────────────────────────────────
# HTTP helpers
# ─────────────────────────────────────────────────────────────────

def _engine_url(override: Optional[str]) -> str:
    return override or os.environ.get(
        "BOUNDARY_ENGINE_URL",
        "https://boundaryai-engine-248951128296.us-east1.run.app",
    )


def _admin_key(override: Optional[str]) -> str:
    k = override or os.environ.get("BOUNDARY_ADMIN_KEY", "")
    if not k:
        print("[observe] ERROR: no BOUNDARY_ADMIN_KEY; pass --admin-key or set env.", file=sys.stderr)
        sys.exit(2)
    return k


def _post(url: str, body: Dict[str, Any], admin_key: str, timeout: int = 30) -> Dict[str, Any]:
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json", "X-Admin-Key": admin_key},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read())


def _get(url: str, admin_key: str, lookback_hours: Optional[int] = None, timeout: int = 30) -> Dict[str, Any]:
    headers = {"X-Admin-Key": admin_key}
    if lookback_hours is not None:
        headers["X-Lookback-Hours"] = str(lookback_hours)
    req = urllib.request.Request(url, headers=headers, method="GET")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read())


# ─────────────────────────────────────────────────────────────────
# Engine calls
# ─────────────────────────────────────────────────────────────────

def start_observation(org_id: str, hours: int = 48,
                      engine_url: Optional[str] = None,
                      admin_key: Optional[str] = None) -> Dict[str, Any]:
    """Enable 48h observation mode for an org. Engine will stop blocking and
    start recording counterfactuals. All api_keys for that org flip."""
    return _post(f"{_engine_url(engine_url)}/v1/admin/observation",
                 {"org_id": org_id, "enable": True, "duration_hours": hours},
                 _admin_key(admin_key))


def stop_observation(org_id: str,
                     engine_url: Optional[str] = None,
                     admin_key: Optional[str] = None) -> Dict[str, Any]:
    """Disable observation mode. Engine returns to normal enforcement."""
    return _post(f"{_engine_url(engine_url)}/v1/admin/observation",
                 {"org_id": org_id, "enable": False},
                 _admin_key(admin_key))


def fetch_report(hours: int = 48,
                 engine_url: Optional[str] = None,
                 admin_key: Optional[str] = None) -> Dict[str, Any]:
    """Pull a Day Zero risk report aggregated from the last N hours of audit log."""
    return _get(f"{_engine_url(engine_url)}/v1/admin/observation/report",
                _admin_key(admin_key), lookback_hours=hours)


# ─────────────────────────────────────────────────────────────────
# Report rendering
# ─────────────────────────────────────────────────────────────────

def render_markdown(report: Dict[str, Any]) -> str:
    """Turn the JSON risk report into an operator-friendly markdown brief."""
    total = report.get("total_events", 0)
    blocks = report.get("would_block_count", 0)
    confirms = report.get("would_confirm_count", 0)
    allows = report.get("actual_allow_count", 0)
    risk = report.get("risk_score", 0)
    level = report.get("risk_level", "none")

    def _top(key: str, label: str, n: int = 10) -> str:
        items = report.get(key, [])[:n]
        if not items:
            return f"### {label}\n\n_None observed._\n"
        lines = [f"### {label}", ""]
        lines.append("| Count | Value |")
        lines.append("|---|---|")
        for it in items:
            lines.append(f"| {it['count']} | `{it['key']}` |")
        return "\n".join(lines) + "\n"

    def _samples(key: str, label: str, n: int = 5) -> str:
        items = report.get(key, [])[:n]
        if not items:
            return f"### {label}\n\n_None observed._\n"
        lines = [f"### {label}", ""]
        for s in items:
            reason = (s.get("reason") or "")[:180]
            lines.append(f"- `{s.get('at','?')}` · **{s.get('action_type','?')}** on agent `{s.get('agent_id','?')}` → {reason}")
        return "\n".join(lines) + "\n"

    md = textwrap.dedent(f"""
    # BoundaryAI — Day Zero Risk Report

    **Org:** `{report.get('org_id','?')}`
    **Window:** {report.get('window_hours','?')}h (`{report.get('window_start_utc','?')}` → `{report.get('window_end_utc','?')}`)

    ## Executive summary

    | Metric | Value |
    |---|---|
    | **Risk score** | **{risk}/100** ({level.upper()}) |
    | Total evaluations observed | {total} |
    | Would have BLOCKED (under enforcement) | {blocks} |
    | Would have asked for CONFIRMATION | {confirms} |
    | Legitimately ALLOWED | {allows} |

    > The client operated for {report.get('window_hours','?')} hours with BoundaryAI installed but **not enforcing**.
    > Under Day One policies these {blocks} block events and {confirms} confirmation events would have fired.

    """).strip() + "\n\n"

    md += _top("top_rules", "Top rules that would have fired") + "\n"
    md += _top("top_action_types", "Top action types") + "\n"
    md += _top("top_pii_types", "PII types detected") + "\n"
    md += _top("top_sources", "Sources (channels)") + "\n"
    md += _top("top_agents", "Top agents") + "\n"
    md += _samples("samples_would_block", "Sample: would-have-BLOCKED events") + "\n"
    md += _samples("samples_would_confirm", "Sample: would-have-CONFIRMED events") + "\n"

    md += textwrap.dedent(f"""
    ---

    ## Recommendation

    Based on the above risk profile, BoundaryAI recommends transitioning to
    **enforcement mode** with the AI-proposed Day One policies (run
    `boundaryai propose-policies --from-report <this_report>.json`).

    To exit observation mode and begin blocking:
    ```
    boundaryai observe stop --org-id {report.get('org_id','?')}
    ```
    """).strip() + "\n"

    return md


# ─────────────────────────────────────────────────────────────────
# AI-assisted Day One policy proposer
# ─────────────────────────────────────────────────────────────────

_PROPOSER_SYSTEM = """You are BoundaryAI's Day One policy proposer. Your job is to read a 48-hour risk report and emit a set of YAML policy rules that would protect this specific organization based on THEIR observed behavior.

Output constraints:
- Emit valid YAML. Top level: `rules:` list.
- Each rule: id (kebab-case), description (one line), domain (one of: digital_agent, physical_machine, data_governance), decision (one of: block, confirm, allow), severity (one of: critical, high, medium, low), condition (dict with action_type + optional scope/params fields), message, regulatory_ref (optional).
- Propose AT MOST 10 rules.
- PRIORITIZE rules that target the org's actual observed risks (what would have blocked in the last 48h).
- Use `decision: confirm` where a human-in-the-loop is plausible, `block` where the risk is clear (PII, credentials, payments, destructive ops).
- Do not propose rules for which there is no evidence in the report.
- Include regulatory refs (GDPR, HIPAA, SOC2, EU AI Act, NIST AI RMF, ISO 42001) when applicable.

After the YAML, output a `# Rationale:` block explaining in 3-6 bullets WHY each top-3 rule was chosen based on specific findings in the report. Cite the counts."""


def propose_policies(report: Dict[str, Any],
                     anthropic_api_key: Optional[str] = None) -> str:
    """Generate Day One policy proposal from a risk report.

    If ANTHROPIC_API_KEY is set and `anthropic` Python SDK is available, we use
    Claude to propose policies tailored to the org's actual 48h behavior.
    Otherwise we fall back to a deterministic template that's still useful.
    Returns YAML + markdown rationale as a single string.
    """
    api_key = anthropic_api_key or os.environ.get("ANTHROPIC_API_KEY", "")
    # Always try the AI path first; fall back only on import or API failure.
    if api_key:
        try:
            import anthropic  # type: ignore
        except ImportError:
            anthropic = None
        if anthropic is not None:
            try:
                client = anthropic.Anthropic(api_key=api_key)
                # Compact report for the model — full samples eat tokens.
                compact = {
                    "org_id": report.get("org_id"),
                    "window_hours": report.get("window_hours"),
                    "total_events": report.get("total_events"),
                    "would_block_count": report.get("would_block_count"),
                    "would_confirm_count": report.get("would_confirm_count"),
                    "actual_allow_count": report.get("actual_allow_count"),
                    "risk_score": report.get("risk_score"),
                    "risk_level": report.get("risk_level"),
                    "top_rules": report.get("top_rules", [])[:15],
                    "top_action_types": report.get("top_action_types", [])[:15],
                    "top_pii_types": report.get("top_pii_types", [])[:10],
                    "top_sources": report.get("top_sources", [])[:10],
                    "top_agents": report.get("top_agents", [])[:10],
                    "samples_would_block": report.get("samples_would_block", [])[:5],
                    "samples_would_confirm": report.get("samples_would_confirm", [])[:5],
                }
                message = client.messages.create(
                    model=os.environ.get("BOUNDARY_PROPOSER_MODEL", "claude-opus-4-5-20251101"),
                    max_tokens=3000,
                    system=_PROPOSER_SYSTEM,
                    messages=[{
                        "role": "user",
                        "content": (
                            "Propose Day One policies for this organization based on the 48h risk report below. "
                            "Emit valid YAML followed by a markdown # Rationale: section.\n\n"
                            "Risk report (JSON):\n```json\n"
                            + json.dumps(compact, indent=2)
                            + "\n```"
                        ),
                    }],
                )
                text = "".join(b.text for b in message.content if getattr(b, "type", None) == "text")
                return text
            except Exception as e:
                print(f"[propose] Anthropic API failed — falling back to template: {e}", file=sys.stderr)

    # ── Deterministic fallback template ──
    blocks = report.get("would_block_count", 0)
    confirms = report.get("would_confirm_count", 0)
    top_rules = [r.get("key", "") for r in report.get("top_rules", [])[:5]]
    top_pii = [p.get("key", "") for p in report.get("top_pii_types", [])[:5]]
    top_actions = [a.get("key", "") for a in report.get("top_action_types", [])[:10]]

    rules_yaml = ["rules:"]
    rule_id_seq = 0
    def _r(name, desc, domain, decision, severity, action_type, message, ref=""):
        nonlocal rule_id_seq
        rule_id_seq += 1
        rules_yaml.append(f"  - id: day1-{rule_id_seq:02d}-{name}")
        rules_yaml.append(f"    description: \"{desc}\"")
        rules_yaml.append(f"    domain: {domain}")
        rules_yaml.append(f"    decision: {decision}")
        rules_yaml.append(f"    severity: {severity}")
        rules_yaml.append( "    condition:")
        rules_yaml.append(f"      action_type: \"{action_type}\"")
        rules_yaml.append(f"    message: \"{message}\"")
        if ref:
            rules_yaml.append(f"    regulatory_ref: \"{ref}\"")

    if "SSN" in top_pii or any("ssn" in p.lower() for p in top_pii):
        _r("block-ssn", "Block SSN exfiltration to any AI channel", "data_governance",
           "block", "critical", "data.transmit",
           "SSN detected in outbound AI request — blocked", "GDPR Art.9, HIPAA §164.514")
    if any(p in top_pii for p in ["credit_card", "card_number"]):
        _r("block-cc", "Block credit card exfiltration", "data_governance",
           "block", "critical", "data.transmit",
           "Credit card detected — blocked", "PCI-DSS 3.4")
    if any("credential" in p.lower() or "api_key" in p.lower() for p in top_pii):
        _r("block-credentials", "Block credential / API key exfiltration", "data_governance",
           "block", "critical", "data.transmit",
           "API key / credential detected — blocked")
    if any("payment" in a for a in top_actions):
        _r("block-payments", "Confirm payment initiations", "digital_agent",
           "confirm", "high", "payment.initiate",
           "Payment action requires human confirmation", "SOC2 CC6.1")
    if any("delete" in a or "destructive" in a for a in top_actions):
        _r("confirm-bulk-delete", "Confirm bulk delete operations", "digital_agent",
           "confirm", "high", "file.delete",
           "Bulk deletion requires human confirmation")

    if rule_id_seq == 0:
        _r("baseline-pii", "Baseline PII block (no org-specific evidence)", "data_governance",
           "block", "critical", "pii.detected",
           "PII detected — blocked",)

    rules_yaml.append("")  # trailing newline
    yaml_block = "\n".join(rules_yaml)

    rationale = textwrap.dedent(f"""
    # Rationale

    - **{rule_id_seq} rules proposed** based on {blocks} would-block + {confirms} would-confirm events over {report.get('window_hours','?')}h.
    - Top rules observed firing (would-block): {', '.join(top_rules) if top_rules else '_none_'}.
    - Top PII types detected: {', '.join(top_pii) if top_pii else '_none_'}.
    - This is the deterministic fallback template. Set `ANTHROPIC_API_KEY` and `pip install anthropic` to get an AI-tailored proposal.
    """).strip()

    return yaml_block + "\n" + rationale + "\n"
