"""
BoundaryAI — Universal Tool-Call Decorators
=============================================

One-line integration for the 5 major AI agent frameworks. Each decorator
wraps tool calls so every invocation goes through the BoundaryAI engine
BEFORE execution — deterministic, external, sub-millisecond enforcement.

Usage (native / generic):

    from boundaryai.decorators import boundaryai_tool

    @boundaryai_tool(action_type="file.write")
    def write_report(path: str, contents: str) -> str:
        Path(path).write_text(contents)
        return f"wrote {len(contents)} bytes"

Framework-specific wrappers are provided below — they preserve each
framework's native API so the tool still plugs into LangChain agents,
CrewAI crews, OpenAI function calling, Anthropic tool_use, or LlamaIndex
query engines without further code changes.

Competitive note: this matches Vorim's land-and-expand decorator playbook
with a stronger enforcement guarantee (external Rust engine, not an
in-process Python guard).
"""
from __future__ import annotations

import functools
import inspect
import json
import os
from typing import Any, Callable, Dict, Optional

from .client import (
    BoundaryClient,
    BoundaryDecision,
    BoundaryBlocked,
    BoundaryConfirmationRequired,
)

_DEFAULT_CLIENT: Optional[BoundaryClient] = None


def _shared_client() -> BoundaryClient:
    """Lazy singleton client. Configure via env:
      BOUNDARY_API_KEY, BOUNDARY_ENGINE_URL, BOUNDARY_AGENT_ID, BOUNDARY_FAIL_OPEN"""
    global _DEFAULT_CLIENT
    if _DEFAULT_CLIENT is None:
        fail_open = os.environ.get("BOUNDARY_FAIL_OPEN", "false").lower() == "true"
        _DEFAULT_CLIENT = BoundaryClient(
            api_key=os.environ.get("BOUNDARY_API_KEY", ""),
            base_url=os.environ.get(
                "BOUNDARY_ENGINE_URL",
                "https://boundaryai-engine-248951128296.us-east1.run.app",
            ),
            agent_id=os.environ.get("BOUNDARY_AGENT_ID", "default-agent"),
            fail_open=fail_open,
        )
    return _DEFAULT_CLIENT


def _truncate(value: Any, max_len: int = 2048) -> str:
    """Stringify + bound a param value so we never blow up a POST body."""
    try:
        if isinstance(value, (dict, list)):
            s = json.dumps(value, default=str)
        else:
            s = str(value)
    except Exception:
        s = repr(value)
    return s if len(s) <= max_len else s[: max_len - 15] + "...[truncated]"


def _params_from_call(sig: inspect.Signature, args: tuple, kwargs: dict) -> Dict[str, str]:
    """Bind actual args to the function signature and produce a flat
    {name: truncated_str} map for the engine's `params` field."""
    try:
        bound = sig.bind_partial(*args, **kwargs)
        bound.apply_defaults()
        return {k: _truncate(v) for k, v in bound.arguments.items() if not k.startswith("_")}
    except Exception:
        # Fall back to best-effort
        out = {f"arg{i}": _truncate(a) for i, a in enumerate(args)}
        out.update({k: _truncate(v) for k, v in kwargs.items()})
        return out


def _evaluate(
    action_type: str,
    scope: str,
    params: Dict[str, str],
    client: Optional[BoundaryClient] = None,
    agent_id: Optional[str] = None,
    on_confirm: str = "raise",
) -> BoundaryDecision:
    """Core enforcement call. `on_confirm` is 'raise' (safe default) or 'allow'."""
    c = client or _shared_client()
    decision = c.evaluate(
        action_type=action_type,
        scope=scope,
        count=1,
        reversible=True,
        agent_id=agent_id or c.agent_id,
        params=params,
    )
    if decision.blocked:
        raise BoundaryBlocked(decision)
    if decision.requires_confirmation and on_confirm == "raise":
        raise BoundaryConfirmationRequired(decision)
    return decision


# ═══════════════════════════════════════════════════════════════
# 1. Generic decorator — works on any Python function / tool
# ═══════════════════════════════════════════════════════════════

def boundaryai_tool(
    *,
    action_type: Optional[str] = None,
    scope: Optional[str] = None,
    client: Optional[BoundaryClient] = None,
    agent_id: Optional[str] = None,
    on_confirm: str = "raise",
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Wrap any function or AI tool. Every call is evaluated by the engine
    before execution.

    Defaults:
      - action_type: "tool.<function_name>"
      - scope:       <function name>
      - on_confirm:  "raise" — raise BoundaryConfirmationRequired
                     "allow" — proceed (caller is trusted to prompt human)
    """
    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        sig = inspect.signature(fn)
        _act = action_type or f"tool.{fn.__name__}"
        _scope = scope or fn.__name__

        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            params = _params_from_call(sig, args, kwargs)
            _evaluate(_act, _scope, params, client, agent_id, on_confirm)
            return fn(*args, **kwargs)

        wrapper.__boundaryai_enforced__ = True       # introspection hook
        wrapper.__boundaryai_action_type__ = _act
        return wrapper
    return decorator


# ═══════════════════════════════════════════════════════════════
# 2. LangChain — wrap @tool functions AND BaseTool subclasses
# ═══════════════════════════════════════════════════════════════

def wrap_langchain_tool(tool: Any, *, on_confirm: str = "raise") -> Any:
    """Wrap a LangChain Tool or @tool-decorated function.

    Works with both:
      - `from langchain.tools import tool` decorator on a function
      - `BaseTool` subclasses with `_run` / `_arun`

    Example:
        from langchain.tools import tool
        from boundaryai.decorators import wrap_langchain_tool

        @tool
        def delete_file(path: str) -> str:
            ...

        safe_tool = wrap_langchain_tool(delete_file)
        agent = initialize_agent([safe_tool], llm, ...)
    """
    tool_name = getattr(tool, "name", getattr(tool, "__name__", "langchain_tool"))
    action_type = f"langchain.{tool_name}"

    # Case 1: BaseTool-style object with _run
    if hasattr(tool, "_run") and callable(tool._run):
        original_run = tool._run

        def guarded_run(*args, **kwargs):
            params = {"args": _truncate(args), "kwargs": _truncate(kwargs)}
            _evaluate(action_type, tool_name, params, on_confirm=on_confirm)
            return original_run(*args, **kwargs)

        tool._run = guarded_run
        if hasattr(tool, "_arun") and callable(tool._arun):
            original_arun = tool._arun

            async def guarded_arun(*args, **kwargs):
                params = {"args": _truncate(args), "kwargs": _truncate(kwargs)}
                _evaluate(action_type, tool_name, params, on_confirm=on_confirm)
                return await original_arun(*args, **kwargs)

            tool._arun = guarded_arun
        return tool

    # Case 2: Callable-style (@tool on a function returns a StructuredTool)
    if callable(tool):
        return boundaryai_tool(action_type=action_type, scope=tool_name, on_confirm=on_confirm)(tool)

    raise TypeError(f"wrap_langchain_tool: unsupported tool type {type(tool)}")


# ═══════════════════════════════════════════════════════════════
# 3. CrewAI — wrap @tool-decorated functions or Tool instances
# ═══════════════════════════════════════════════════════════════

def wrap_crewai_tool(tool: Any, *, on_confirm: str = "raise") -> Any:
    """Wrap a CrewAI tool (crewai.tools.tool or Tool instance).
    Preserves CrewAI's .name / .description attrs so the agent still
    knows how to choose the tool.

    Example:
        from crewai.tools import tool
        from boundaryai.decorators import wrap_crewai_tool

        @tool("delete file by path")
        def delete_file(path: str) -> str:
            ...

        safe = wrap_crewai_tool(delete_file)
        agent = Agent(..., tools=[safe])
    """
    tool_name = getattr(tool, "name", getattr(tool, "__name__", "crewai_tool"))
    action_type = f"crewai.{tool_name}"

    # Tool instances have a `.func` attribute in some CrewAI versions
    if hasattr(tool, "func") and callable(tool.func):
        original = tool.func
        sig = inspect.signature(original)

        @functools.wraps(original)
        def guarded(*args, **kwargs):
            params = _params_from_call(sig, args, kwargs)
            _evaluate(action_type, tool_name, params, on_confirm=on_confirm)
            return original(*args, **kwargs)

        tool.func = guarded
        return tool

    # Plain function (old-style @tool decorator)
    if callable(tool):
        return boundaryai_tool(action_type=action_type, scope=tool_name, on_confirm=on_confirm)(tool)

    raise TypeError(f"wrap_crewai_tool: unsupported tool type {type(tool)}")


# ═══════════════════════════════════════════════════════════════
# 4. OpenAI function calling — wrap the dispatch side
# ═══════════════════════════════════════════════════════════════

def wrap_openai_function(fn: Callable[..., Any], *, tool_name: Optional[str] = None,
                         on_confirm: str = "raise") -> Callable[..., Any]:
    """Wrap the Python function you dispatch an OpenAI `tool_calls` / function-call
    response to. OpenAI's API returns tool_calls with `name` + `arguments` (JSON
    string); you normally dispatch those to a local Python function. Put this
    wrapper in between.

    Example:
        from openai import OpenAI
        from boundaryai.decorators import wrap_openai_function

        def _run_sql(query: str) -> str: ...

        run_sql = wrap_openai_function(_run_sql, tool_name="run_sql")

        # In your dispatch loop:
        args = json.loads(tool_call.function.arguments)
        if tool_call.function.name == "run_sql":
            result = run_sql(**args)   # <-- now enforced
    """
    name = tool_name or fn.__name__
    action_type = f"openai.{name}"
    sig = inspect.signature(fn)

    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        params = _params_from_call(sig, args, kwargs)
        _evaluate(action_type, name, params, on_confirm=on_confirm)
        return fn(*args, **kwargs)

    wrapper.__boundaryai_enforced__ = True
    wrapper.__boundaryai_framework__ = "openai"
    return wrapper


# ═══════════════════════════════════════════════════════════════
# 5. Anthropic tool_use — wrap the dispatch side
# ═══════════════════════════════════════════════════════════════

def wrap_anthropic_tool(fn: Callable[..., Any], *, tool_name: Optional[str] = None,
                        on_confirm: str = "raise") -> Callable[..., Any]:
    """Wrap the Python function you dispatch an Anthropic `tool_use` block to.

    Example:
        from anthropic import Anthropic
        from boundaryai.decorators import wrap_anthropic_tool

        def _query_customer(customer_id: str) -> dict: ...
        query_customer = wrap_anthropic_tool(_query_customer, tool_name="query_customer")

        # In your tool_use dispatch:
        if block.type == "tool_use" and block.name == "query_customer":
            result = query_customer(**block.input)
    """
    name = tool_name or fn.__name__
    action_type = f"anthropic.{name}"
    sig = inspect.signature(fn)

    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        params = _params_from_call(sig, args, kwargs)
        _evaluate(action_type, name, params, on_confirm=on_confirm)
        return fn(*args, **kwargs)

    wrapper.__boundaryai_enforced__ = True
    wrapper.__boundaryai_framework__ = "anthropic"
    return wrapper


# ═══════════════════════════════════════════════════════════════
# 6. LlamaIndex — wrap FunctionTool / BaseTool
# ═══════════════════════════════════════════════════════════════

def wrap_llamaindex_tool(tool: Any, *, on_confirm: str = "raise") -> Any:
    """Wrap a LlamaIndex FunctionTool or BaseTool.

    Example:
        from llama_index.core.tools import FunctionTool
        from boundaryai.decorators import wrap_llamaindex_tool

        def multiply(a: int, b: int) -> int:
            return a * b

        mul_tool = FunctionTool.from_defaults(fn=multiply)
        safe_tool = wrap_llamaindex_tool(mul_tool)
    """
    tool_name = (
        getattr(getattr(tool, "metadata", None), "name", None)
        or getattr(tool, "name", None)
        or getattr(tool, "__name__", "llamaindex_tool")
    )
    action_type = f"llamaindex.{tool_name}"

    # FunctionTool exposes .fn and .call()
    if hasattr(tool, "fn") and callable(tool.fn):
        original = tool.fn
        sig = inspect.signature(original)

        @functools.wraps(original)
        def guarded(*args, **kwargs):
            params = _params_from_call(sig, args, kwargs)
            _evaluate(action_type, tool_name, params, on_confirm=on_confirm)
            return original(*args, **kwargs)

        tool.fn = guarded
        return tool

    # BaseTool-style with .call
    if hasattr(tool, "call") and callable(tool.call):
        original = tool.call

        def guarded(*args, **kwargs):
            params = {"args": _truncate(args), "kwargs": _truncate(kwargs)}
            _evaluate(action_type, tool_name, params, on_confirm=on_confirm)
            return original(*args, **kwargs)

        tool.call = guarded
        return tool

    if callable(tool):
        return boundaryai_tool(action_type=action_type, scope=tool_name, on_confirm=on_confirm)(tool)

    raise TypeError(f"wrap_llamaindex_tool: unsupported tool type {type(tool)}")


__all__ = [
    "boundaryai_tool",
    "wrap_langchain_tool",
    "wrap_crewai_tool",
    "wrap_openai_function",
    "wrap_anthropic_tool",
    "wrap_llamaindex_tool",
]
