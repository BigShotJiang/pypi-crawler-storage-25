"""JSON protocol for daemon<->client communication over Unix socket."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# Default runtime directory
RUNTIME_DIR = Path.home() / ".camoufox"
SOCKET_PATH = RUNTIME_DIR / "daemon.sock"
PID_PATH = RUNTIME_DIR / "daemon.pid"

# Framing: each message is a JSON line terminated with \n
ENCODING = "utf-8"


@dataclass
class Request:
    cmd: str
    args: dict[str, Any] = field(default_factory=dict)

    def encode(self) -> bytes:
        return (json.dumps({"cmd": self.cmd, "args": self.args}) + "\n").encode(
            ENCODING
        )

    @classmethod
    def decode(cls, data: bytes) -> "Request":
        obj = json.loads(data.decode(ENCODING).strip())
        return cls(cmd=obj["cmd"], args=obj.get("args", {}))


@dataclass
class Response:
    ok: bool
    result: Any = None
    error: str | None = None

    def encode(self) -> bytes:
        return (
            json.dumps({"ok": self.ok, "result": self.result, "error": self.error})
            + "\n"
        ).encode(ENCODING)

    @classmethod
    def decode(cls, data: bytes) -> "Response":
        obj = json.loads(data.decode(ENCODING).strip())
        return cls(ok=obj["ok"], result=obj.get("result"), error=obj.get("error"))
