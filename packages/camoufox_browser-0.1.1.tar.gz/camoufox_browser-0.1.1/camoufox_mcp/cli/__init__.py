"""CLI package for camoufox daemon-based browser automation."""
