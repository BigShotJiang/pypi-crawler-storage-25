"""Async Unix socket daemon that exposes the camoufox-browser command layer."""

from __future__ import annotations

import asyncio
import os
import signal
import sys
from typing import Any, Awaitable, Callable

from ..browser import browser_manager
from ..exceptions import OperationError
from ..operations import (
    click,
    close_browser,
    console_messages,
    drag_and_drop,
    evaluate,
    file_upload,
    fill_form,
    handle_dialog,
    hover,
    install_browser,
    navigate,
    navigate_back,
    network_requests,
    parse_proxy,
    press_key,
    resize,
    select_option,
    snapshot,
    tabs,
    take_screenshot,
    type_text,
    wait_for,
)
from .protocol import PID_PATH, RUNTIME_DIR, SOCKET_PATH, Request, Response

Handler = Callable[[dict[str, Any]], Awaitable[str]]


async def _navigate(args: dict[str, Any]) -> str:
    return await navigate(args["url"])


async def _navigate_back(_: dict[str, Any]) -> str:
    return await navigate_back()


async def _snapshot(_: dict[str, Any]) -> str:
    return await snapshot()


async def _wait(args: dict[str, Any]) -> str:
    return await wait_for(
        text=args.get("text"),
        text_gone=args.get("text_gone"),
        time_seconds=args.get("time"),
    )


async def _click(args: dict[str, Any]) -> str:
    return await click(
        ref=args["ref"],
        button=args.get("button", "left"),
        double_click=bool(args.get("double_click")),
    )


async def _type(args: dict[str, Any]) -> str:
    return await type_text(
        ref=args["ref"],
        text=args["text"],
        slowly=bool(args.get("slowly")),
        submit=bool(args.get("submit")),
    )


async def _hover(args: dict[str, Any]) -> str:
    return await hover(ref=args["ref"])


async def _drag(args: dict[str, Any]) -> str:
    return await drag_and_drop(
        start_ref=args["start_ref"],
        end_ref=args["end_ref"],
    )


async def _press_key(args: dict[str, Any]) -> str:
    return await press_key(args["key"])


async def _select_option(args: dict[str, Any]) -> str:
    return await select_option(ref=args["ref"], values=args["values"])


async def _evaluate(args: dict[str, Any]) -> str:
    return await evaluate(function=args["function"], ref=args.get("ref"))


async def _screenshot(args: dict[str, Any]) -> str:
    return await take_screenshot(
        filename=args.get("filename"),
        full_page=bool(args.get("full_page")),
        ref=args.get("ref"),
        image_format=args.get("type", "png"),
    )


async def _console_messages(args: dict[str, Any]) -> str:
    return await console_messages(args.get("level", "info"))


async def _network_requests(args: dict[str, Any]) -> str:
    return await network_requests(bool(args.get("include_static")))


async def _tabs(args: dict[str, Any]) -> str:
    return await tabs(action=args["action"], index=args.get("index"))


async def _resize(args: dict[str, Any]) -> str:
    return await resize(args["width"], args["height"])


async def _close(_: dict[str, Any]) -> str:
    return await close_browser()


async def _install(_: dict[str, Any]) -> str:
    return await install_browser()


async def _fill_form(args: dict[str, Any]) -> str:
    return await fill_form(args["fields"])


async def _file_upload(args: dict[str, Any]) -> str:
    return await file_upload(paths=args.get("paths"), ref=args.get("ref"))


async def _handle_dialog(args: dict[str, Any]) -> str:
    return await handle_dialog(
        accept=bool(args["accept"]),
        prompt_text=args.get("prompt_text"),
    )


HANDLERS: dict[str, Handler] = {
    "navigate": _navigate,
    "navigate_back": _navigate_back,
    "snapshot": _snapshot,
    "wait": _wait,
    "click": _click,
    "type": _type,
    "hover": _hover,
    "drag": _drag,
    "press_key": _press_key,
    "select_option": _select_option,
    "evaluate": _evaluate,
    "screenshot": _screenshot,
    "console_messages": _console_messages,
    "network_requests": _network_requests,
    "tabs": _tabs,
    "resize": _resize,
    "close": _close,
    "install": _install,
    "fill_form": _fill_form,
    "file_upload": _file_upload,
    "handle_dialog": _handle_dialog,
}


async def _handle_connection(
    reader: asyncio.StreamReader, writer: asyncio.StreamWriter
) -> None:
    try:
        data = await reader.readline()
        if not data:
            return

        request = Request.decode(data)
        handler = HANDLERS.get(request.cmd)
        if handler is None:
            response = Response(ok=False, error=f"Unknown command: {request.cmd}")
        else:
            try:
                result = await handler(request.args)
                response = Response(ok=True, result=result)
            except OperationError as exc:
                response = Response(ok=False, error=str(exc))
            except Exception as exc:
                response = Response(ok=False, error=str(exc))

        writer.write(response.encode())
        await writer.drain()
    except Exception as exc:
        try:
            writer.write(Response(ok=False, error=str(exc)).encode())
            await writer.drain()
        except Exception:
            pass
    finally:
        writer.close()
        await writer.wait_closed()


async def run(
    headless: bool = False, os_: str | None = None, proxy: str | None = None
) -> None:
    """Start the daemon: configure browser, write PID, serve socket."""
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)

    config_kwargs: dict[str, Any] = {"headless": headless}
    if os_:
        config_kwargs["os"] = os_
    if proxy:
        try:
            config_kwargs["proxy"] = parse_proxy(proxy)
        except OperationError as exc:
            print(f"Invalid proxy: {exc}", file=sys.stderr)
            sys.exit(1)

    browser_manager.update_config(**config_kwargs)

    PID_PATH.write_text(str(os.getpid()))
    if SOCKET_PATH.exists():
        SOCKET_PATH.unlink()

    stop_event = asyncio.Event()

    def _on_signal(*_: Any) -> None:
        stop_event.set()

    loop = asyncio.get_running_loop()
    loop.add_signal_handler(signal.SIGTERM, _on_signal)
    loop.add_signal_handler(signal.SIGINT, _on_signal)

    server = await asyncio.start_unix_server(_handle_connection, path=str(SOCKET_PATH))
    print(f"Daemon started (PID {os.getpid()})", flush=True)

    async with server:
        await stop_event.wait()

    await browser_manager.close()
    if SOCKET_PATH.exists():
        SOCKET_PATH.unlink()
    if PID_PATH.exists():
        PID_PATH.unlink()
    print("Daemon stopped", flush=True)
