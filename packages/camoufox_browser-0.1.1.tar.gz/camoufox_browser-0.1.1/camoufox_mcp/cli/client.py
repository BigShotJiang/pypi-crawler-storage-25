"""Client that sends commands to the running daemon over Unix socket."""

from __future__ import annotations

import asyncio

from .protocol import SOCKET_PATH, Request, Response


async def send(cmd: str, **args: object) -> Response:
    """Send a command to the daemon and return the response."""
    if not SOCKET_PATH.exists():
        raise ConnectionError(
            "Daemon is not running. Start it with: camoufox-browser start"
        )
    try:
        reader, writer = await asyncio.open_unix_connection(
            str(SOCKET_PATH), limit=16 * 1024 * 1024
        )
    except (ConnectionRefusedError, FileNotFoundError) as e:
        raise ConnectionError(
            f"Cannot connect to daemon: {e}. Start it with: camoufox-browser start"
        ) from e

    try:
        writer.write(Request(cmd=cmd, args=dict(args)).encode())
        await writer.drain()
        data = await reader.readline()
        return Response.decode(data)
    finally:
        writer.close()
        await writer.wait_closed()


def send_sync(cmd: str, **args: object) -> Response:
    """Synchronous wrapper around send()."""
    return asyncio.run(send(cmd, **args))
