"""Click CLI entry point for camoufox-browser."""

from __future__ import annotations

import asyncio
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import click

from .. import __version__
from .client import send_sync
from .protocol import PID_PATH, RUNTIME_DIR, SOCKET_PATH

CLI_NAME = "camoufox-browser"


def _ensure_supported_host() -> None:
    """Fail fast on unsupported host platforms."""
    if os.name == "nt":
        click.echo(
            f"{CLI_NAME} supports Linux and macOS hosts only.",
            err=True,
        )
        sys.exit(1)


def _print_response(resp: object) -> None:
    """Print daemon response, exit non-zero on error."""
    from .protocol import Response

    if not isinstance(resp, Response):
        click.echo("Unexpected daemon response", err=True)
        sys.exit(1)

    if resp.ok:
        if resp.result is not None:
            click.echo(resp.result)
        return

    click.echo(f"Error: {resp.error}", err=True)
    sys.exit(1)


def _read_pid() -> int | None:
    if not PID_PATH.exists():
        return None
    try:
        return int(PID_PATH.read_text().strip())
    except (OSError, ValueError):
        return None


def _pid_is_running(pid: int | None) -> bool:
    if pid is None:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _cleanup_stale_runtime() -> None:
    for path in (SOCKET_PATH, PID_PATH):
        if path.exists():
            path.unlink()


def _daemon_is_running() -> bool:
    pid = _read_pid()
    socket_ready = SOCKET_PATH.exists()
    if pid is not None and _pid_is_running(pid) and socket_ready:
        return True
    if pid is not None and not _pid_is_running(pid):
        _cleanup_stale_runtime()
    elif socket_ready and pid is None:
        _cleanup_stale_runtime()
    return False


def _daemon_command(headless: bool, os_: str | None, proxy: str | None) -> list[str]:
    cmd = [sys.executable, "-m", "camoufox_mcp.cli.main", "_daemon"]
    if headless:
        cmd.append("--headless")
    if os_:
        cmd.extend(["--os", os_])
    if proxy:
        cmd.extend(["--proxy", proxy])
    return cmd


def _start_daemon_process(
    *,
    headless: bool = False,
    os_: str | None = None,
    proxy: str | None = None,
    quiet: bool = False,
) -> int | None:
    if _daemon_is_running():
        if not quiet:
            click.echo("Daemon is already running. Use 'camoufox-browser stop' first.")
        return _read_pid()

    _cleanup_stale_runtime()
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    log_file = RUNTIME_DIR / "daemon.log"

    with open(log_file, "w") as log:
        proc = subprocess.Popen(
            _daemon_command(headless=headless, os_=os_, proxy=proxy),
            start_new_session=True,
            stdout=log,
            stderr=subprocess.STDOUT,
        )

    for _ in range(20):
        time.sleep(0.25)
        if _daemon_is_running():
            if not quiet:
                click.echo(f"Daemon started (PID {proc.pid})")
            return proc.pid
        if proc.poll() is not None:
            click.echo(f"Daemon failed to start. Check {log_file}", err=True)
            sys.exit(1)

    click.echo(
        f"Daemon PID {proc.pid} — socket not yet ready. Check {log_file}",
        err=True,
    )
    sys.exit(1)


def _require_daemon(*, auto_start: bool = False) -> None:
    if _daemon_is_running():
        return
    if auto_start:
        _start_daemon_process(quiet=True)
        return
    click.echo(
        f"Daemon is not running. Start it with: {CLI_NAME} start",
        err=True,
    )
    sys.exit(1)


def _run_command(
    cmd: str,
    *,
    auto_start: bool = False,
    **args: object,
) -> None:
    _require_daemon(auto_start=auto_start)
    _print_response(send_sync(cmd, **args))


def _load_fields(fields_json: str | None, fields_file: Path | None) -> list[dict[str, Any]]:
    if fields_file is not None:
        raw = fields_file.read_text()
    elif fields_json is not None:
        raw = fields_json
    else:
        raise click.UsageError("Provide either FIELDS_JSON or --file.")

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise click.UsageError(f"Invalid JSON: {exc}") from exc

    if not isinstance(data, list):
        raise click.UsageError("Form payload must be a JSON array of field objects.")
    return data


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(version=__version__, prog_name=CLI_NAME)
def cli() -> None:
    """Camoufox browser automation CLI.

    Primary workflow:
      camoufox-browser open https://example.com
      camoufox-browser snapshot
      camoufox-browser click 'button:Sign in'
      camoufox-browser fill 'textbox:Email' me@example.com
      camoufox-browser screenshot

    Advanced workflow:
      camoufox-browser start --headless
      camoufox-browser stop
      camoufox-browser status
    """


def main() -> None:
    """Run the CLI."""
    _ensure_supported_host()
    cli()


@cli.command()
@click.option(
    "--headless",
    is_flag=True,
    default=False,
    help="Run browser in headless mode.",
)
@click.option(
    "--os",
    "os_",
    type=click.Choice(["windows", "macos", "linux"]),
    default=None,
    help="OS to spoof.",
)
@click.option(
    "--proxy",
    default=None,
    metavar="PROXY",
    help="Proxy (login:pass@host:port).",
)
def start(headless: bool, os_: str | None, proxy: str | None) -> None:
    """Start the browser daemon in the background."""
    _start_daemon_process(headless=headless, os_=os_, proxy=proxy, quiet=False)


@cli.command()
def stop() -> None:
    """Stop the running daemon."""
    pid = _read_pid()
    if pid is None or not _pid_is_running(pid):
        _cleanup_stale_runtime()
        click.echo("Daemon is not running.")
        return

    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        _cleanup_stale_runtime()
        click.echo("Daemon process not found. Cleaned up stale runtime files.")
        return
    except Exception as exc:
        click.echo(f"Error: {exc}", err=True)
        sys.exit(1)

    click.echo(f"Sent SIGTERM to PID {pid}")


@cli.command()
def status() -> None:
    """Show whether the daemon is running."""
    if _daemon_is_running():
        click.echo(f"Daemon is running (PID {_read_pid()})")
        return
    click.echo("Daemon is not running.")


@cli.command(name="open")
@click.argument("url")
def open_cmd(url: str) -> None:
    """Navigate to a URL."""
    _run_command("navigate", auto_start=True, url=url)


cli.add_command(open_cmd, "navigate")


@cli.command(name="back")
def back_cmd() -> None:
    """Go back to the previous page."""
    _run_command("navigate_back", auto_start=True)


cli.add_command(back_cmd, "navigate-back")


@cli.command()
def snapshot() -> None:
    """Print the accessibility tree of the current page."""
    _run_command("snapshot", auto_start=True)


@cli.command(name="click")
@click.argument("ref")
@click.option(
    "--button",
    type=click.Choice(["left", "right", "middle"]),
    default="left",
)
@click.option(
    "--double",
    "double_click",
    is_flag=True,
    default=False,
    help="Double-click.",
)
def click_cmd(ref: str, button: str, double_click: bool) -> None:
    """Click an element by ref."""
    _run_command(
        "click",
        auto_start=True,
        ref=ref,
        button=button,
        double_click=double_click,
    )


@cli.command(name="fill")
@click.argument("ref")
@click.argument("text")
@click.option(
    "--slowly",
    is_flag=True,
    default=False,
    help="Type one character at a time instead of filling.",
)
@click.option("--submit", is_flag=True, default=False, help="Press Enter after typing.")
def fill_cmd(ref: str, text: str, slowly: bool, submit: bool) -> None:
    """Fill or type text into an element by ref."""
    _run_command(
        "type",
        auto_start=True,
        ref=ref,
        text=text,
        slowly=slowly,
        submit=submit,
    )


cli.add_command(fill_cmd, "type")


@cli.command()
@click.argument("ref")
def hover(ref: str) -> None:
    """Hover over an element by ref."""
    _run_command("hover", auto_start=True, ref=ref)


@cli.command(name="press")
@click.argument("key")
def press_cmd(key: str) -> None:
    """Press a keyboard key."""
    _run_command("press_key", auto_start=True, key=key)


cli.add_command(press_cmd, "press-key")


@cli.command(name="select")
@click.argument("ref")
@click.argument("values", nargs=-1, required=True)
def select_cmd(ref: str, values: tuple[str, ...]) -> None:
    """Select one or more values in a dropdown."""
    _run_command("select_option", auto_start=True, ref=ref, values=list(values))


cli.add_command(select_cmd, "select-option")


@cli.command(name="drag")
@click.argument("start_ref")
@click.argument("end_ref")
def drag_cmd(start_ref: str, end_ref: str) -> None:
    """Drag and drop between two refs."""
    _run_command(
        "drag",
        auto_start=True,
        start_ref=start_ref,
        end_ref=end_ref,
    )


@cli.command(name="upload")
@click.option(
    "--pending",
    is_flag=True,
    default=False,
    help="Use the pending file chooser instead of a file input ref.",
)
@click.argument("ref", required=False)
@click.argument("paths", nargs=-1, type=click.Path(path_type=Path), required=False)
def upload_cmd(pending: bool, ref: str | None, paths: tuple[Path, ...]) -> None:
    """Upload files through a file input ref or pending chooser."""
    if pending and ref is not None:
        raise click.UsageError("Do not pass REF when using --pending.")
    if not pending and ref is None:
        raise click.UsageError("REF is required unless --pending is used.")
    if not paths:
        raise click.UsageError("Provide at least one file path to upload.")

    _run_command(
        "file_upload",
        auto_start=True,
        ref=ref,
        paths=[str(path) for path in paths],
    )


@cli.command(name="dialog")
@click.argument("action", type=click.Choice(["accept", "dismiss"]))
@click.argument("prompt_text", required=False)
def dialog_cmd(action: str, prompt_text: str | None) -> None:
    """Accept or dismiss a pending dialog."""
    _run_command(
        "handle_dialog",
        auto_start=False,
        accept=action == "accept",
        prompt_text=prompt_text,
    )


@cli.command(name="fill-form")
@click.argument("fields_json", required=False)
@click.option(
    "--file",
    "fields_file",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    default=None,
    help="Read the JSON field array from a file.",
)
def fill_form_cmd(fields_json: str | None, fields_file: Path | None) -> None:
    """Fill multiple fields from a JSON array payload."""
    fields = _load_fields(fields_json, fields_file)
    _run_command("fill_form", auto_start=True, fields=fields)


@cli.command()
@click.option(
    "--output",
    "filename",
    default=None,
    metavar="FILE",
    help="Output file path.",
)
@click.option(
    "--full-page",
    is_flag=True,
    default=False,
    help="Capture the full scrollable page.",
)
@click.option("--ref", default=None, help="Element ref to screenshot.")
@click.option("--format", "fmt", type=click.Choice(["png", "jpeg"]), default="png")
def screenshot(
    filename: str | None,
    full_page: bool,
    ref: str | None,
    fmt: str,
) -> None:
    """Take a screenshot of the current page or element."""
    _run_command(
        "screenshot",
        auto_start=True,
        filename=filename,
        full_page=full_page,
        ref=ref,
        type=fmt,
    )


@cli.command(name="eval")
@click.argument("js")
@click.option("--ref", default=None, help="Run JS on a specific element ref.")
def evaluate_cmd(js: str, ref: str | None) -> None:
    """Evaluate JavaScript on the page or an element."""
    _run_command("evaluate", auto_start=True, function=js, ref=ref)


cli.add_command(evaluate_cmd, "evaluate")


@cli.command()
@click.option("--text", default=None, help="Wait for this text to appear.")
@click.option("--text-gone", default=None, help="Wait for this text to disappear.")
@click.option("--time", "seconds", type=float, default=None, help="Wait N seconds.")
def wait(text: str | None, text_gone: str | None, seconds: float | None) -> None:
    """Wait for a condition on the page."""
    _run_command(
        "wait",
        auto_start=True,
        text=text,
        text_gone=text_gone,
        time=seconds,
    )


@cli.command()
@click.option(
    "--level",
    type=click.Choice(["error", "warning", "info", "debug"]),
    default="info",
)
def console(level: str) -> None:
    """Show browser console messages."""
    _run_command("console_messages", auto_start=False, level=level)


@cli.command()
@click.option(
    "--all",
    "include_static",
    is_flag=True,
    default=False,
    help="Include static assets.",
)
def network(include_static: bool) -> None:
    """Show recorded network requests."""
    _run_command(
        "network_requests",
        auto_start=False,
        include_static=include_static,
    )


@cli.command()
@click.argument("width", type=int)
@click.argument("height", type=int)
def resize(width: int, height: int) -> None:
    """Resize the browser viewport."""
    _run_command("resize", auto_start=True, width=width, height=height)


@cli.command()
def close() -> None:
    """Close the browser (daemon stays running)."""
    _run_command("close", auto_start=False)


@cli.group()
def tabs() -> None:
    """Manage browser tabs."""


@tabs.command(name="list")
def tabs_list() -> None:
    """List open tabs."""
    _run_command("tabs", auto_start=False, action="list")


@tabs.command(name="new")
def tabs_new() -> None:
    """Open a new tab."""
    _run_command("tabs", auto_start=True, action="new")


@tabs.command(name="close")
@click.argument("index", type=int, required=False)
def tabs_close(index: int | None) -> None:
    """Close a tab by index (current tab if omitted)."""
    _run_command("tabs", auto_start=False, action="close", index=index)


@tabs.command(name="select")
@click.argument("index", type=int)
def tabs_select(index: int) -> None:
    """Switch to a tab by index."""
    _run_command("tabs", auto_start=False, action="select", index=index)


@cli.command()
def install() -> None:
    """Download and install the Camoufox browser binary."""
    click.echo("Installing Camoufox browser...")
    result = subprocess.run(
        [sys.executable, "-m", "camoufox", "fetch"],
        timeout=300,
    )
    sys.exit(result.returncode)


@cli.command(name="_daemon", hidden=True)
@click.option("--headless", is_flag=True, default=False)
@click.option(
    "--os",
    "os_",
    type=click.Choice(["windows", "macos", "linux"]),
    default=None,
)
@click.option("--proxy", default=None)
def _daemon_cmd(headless: bool, os_: str | None, proxy: str | None) -> None:
    """Internal: run the daemon server."""
    from . import daemon

    asyncio.run(daemon.run(headless=headless, os_=os_, proxy=proxy))


if __name__ == "__main__":
    main()
