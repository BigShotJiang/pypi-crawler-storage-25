"""Shared browser operations used by the CLI and MCP adapters."""

from __future__ import annotations

import json
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Literal

from .browser import browser_manager
from .exceptions import OperationError
from .types import FormField

InteractiveRole = Literal[
    "button",
    "link",
    "textbox",
    "checkbox",
    "radio",
    "combobox",
    "menuitem",
    "tab",
    "slider",
]

INTERACTIVE_ROLES: set[InteractiveRole] = {
    "button",
    "link",
    "textbox",
    "checkbox",
    "radio",
    "combobox",
    "menuitem",
    "tab",
    "slider",
}


def parse_ref(ref: str) -> str:
    """Convert a snapshot ref into a Playwright selector."""
    if ":" in ref and not ref.startswith(("http", "//")):
        role, name = ref.split(":", 1)
        escaped_name = name.replace("\\", "\\\\").replace("'", "\\'")
        return f"role={role}[name='{escaped_name}']"
    return ref


def format_snapshot_node(node: dict, indent: int = 0) -> str:
    """Format an accessibility tree node recursively."""
    lines: list[str] = []
    prefix = "  " * indent
    role = node.get("role", "")
    name = node.get("name", "")
    value = node.get("value", "")

    parts = [role]
    if name:
        parts.append(f'"{name}"')
    if value:
        parts.append(f"value={value}")
    if role in INTERACTIVE_ROLES:
        ref = f"{role}:{name}" if name else f"{role}:{id(node)}"
        parts.append(f"[ref={ref}]")

    lines.append(f"{prefix}{' '.join(parts)}")
    for child in node.get("children", []):
        lines.append(format_snapshot_node(child, indent + 1))
    return "\n".join(lines)


def parse_proxy(proxy: str) -> dict[str, str]:
    """Parse common proxy formats into Camoufox launch kwargs."""
    proxy = re.sub(r"^https?://", "", proxy)
    if "@" in proxy:
        auth, server = proxy.rsplit("@", 1)
        if ":" not in auth:
            raise OperationError("Invalid auth format in proxy")
        username, password = auth.split(":", 1)
        return {
            "server": f"http://{server}",
            "username": username,
            "password": password,
        }

    parts = proxy.split(":")
    if len(parts) == 4:
        return {
            "server": f"http://{parts[0]}:{parts[1]}",
            "username": parts[2],
            "password": parts[3],
        }
    if len(parts) == 2:
        return {"server": f"http://{parts[0]}:{parts[1]}"}

    raise OperationError("Invalid proxy format")


async def navigate(url: str) -> str:
    page = await browser_manager.get_page()
    try:
        await page.goto(
            url,
            wait_until=browser_manager._config.wait_strategy,
            timeout=browser_manager._config.timeout,
        )
        title = await page.title()
        return f"Navigated to {url}\nPage title: {title}"
    except Exception as exc:
        raise OperationError(f"Navigation failed: {exc}") from exc


async def navigate_back() -> str:
    page = await browser_manager.get_page()
    try:
        response = await page.go_back(
            wait_until=browser_manager._config.wait_strategy,
            timeout=browser_manager._config.timeout,
        )
        if response is None and page.url == "about:blank":
            raise OperationError("No previous page available")
        title = await page.title()
        return f"Navigated back to {page.url}\nPage title: {title}"
    except OperationError:
        raise
    except Exception as exc:
        raise OperationError(f"Navigation back failed: {exc}") from exc


async def snapshot() -> str:
    page = await browser_manager.get_page()
    try:
        tree = await page.accessibility.snapshot()
    except Exception as exc:
        raise OperationError(f"Failed to capture snapshot: {exc}") from exc

    if tree is None:
        return "No accessibility tree available for this page"
    return format_snapshot_node(tree)


async def wait_for(
    *,
    text: str | None = None,
    text_gone: str | None = None,
    time_seconds: float | None = None,
) -> str:
    page = await browser_manager.get_page()
    try:
        if text:
            await page.wait_for_selector(
                f"text={text}",
                state="visible",
                timeout=browser_manager._config.timeout,
            )
            return f"Text '{text}' appeared on the page"
        if text_gone:
            await page.wait_for_selector(
                f"text={text_gone}",
                state="hidden",
                timeout=browser_manager._config.timeout,
            )
            return f"Text '{text_gone}' is no longer visible"
        if time_seconds is not None:
            await page.wait_for_timeout(float(time_seconds) * 1000)
            return f"Waited for {time_seconds} seconds"
        raise OperationError("No wait condition specified. Provide text, text_gone, or time.")
    except OperationError:
        raise
    except Exception as exc:
        raise OperationError(f"Wait failed: {exc}") from exc


async def click(
    *,
    ref: str,
    button: Literal["left", "right", "middle"] = "left",
    double_click: bool = False,
    label: str | None = None,
) -> str:
    page = await browser_manager.get_page()
    target = label or ref
    try:
        selector = parse_ref(ref)
        if double_click:
            await page.dblclick(selector, button=button)
            return f"Double-clicked on {target}"
        await page.click(selector, button=button)
        return f"Clicked on {target}"
    except Exception as exc:
        raise OperationError(f"Click failed on {target}: {exc}") from exc


async def type_text(
    *,
    ref: str,
    text: str,
    slowly: bool = False,
    submit: bool = False,
    label: str | None = None,
) -> str:
    page = await browser_manager.get_page()
    target = label or ref
    try:
        selector = parse_ref(ref)
        if slowly:
            await page.type(selector, text, delay=100)
        else:
            await page.fill(selector, text)
        if submit:
            await page.press(selector, "Enter")
        action = "Typed and submitted" if submit else "Typed"
        return f"{action} '{text}' into {target}"
    except Exception as exc:
        raise OperationError(f"Type failed on {target}: {exc}") from exc


async def hover(*, ref: str, label: str | None = None) -> str:
    page = await browser_manager.get_page()
    target = label or ref
    try:
        await page.hover(parse_ref(ref))
        return f"Hovering over {target}"
    except Exception as exc:
        raise OperationError(f"Hover failed on {target}: {exc}") from exc


async def drag_and_drop(
    *,
    start_ref: str,
    end_ref: str,
    start_label: str | None = None,
    end_label: str | None = None,
) -> str:
    page = await browser_manager.get_page()
    source = start_label or start_ref
    target = end_label or end_ref
    try:
        await page.drag_and_drop(parse_ref(start_ref), parse_ref(end_ref))
        return f"Dragged from {source} to {target}"
    except Exception as exc:
        raise OperationError(f"Drag failed from {source} to {target}: {exc}") from exc


async def press_key(key: str) -> str:
    page = await browser_manager.get_page()
    try:
        await page.keyboard.press(key)
        return f"Pressed key: {key}"
    except Exception as exc:
        raise OperationError(f"Key press failed: {exc}") from exc


async def select_option(
    *,
    ref: str,
    values: list[str] | tuple[str, ...] | str,
    label: str | None = None,
) -> str:
    page = await browser_manager.get_page()
    target = label or ref
    selected_values = [values] if isinstance(values, str) else list(values)
    if not selected_values:
        raise OperationError("At least one option value is required")
    try:
        await page.select_option(parse_ref(ref), selected_values)
        return f"Selected '{', '.join(selected_values)}' in {target}"
    except Exception as exc:
        raise OperationError(f"Select failed on {target}: {exc}") from exc


async def evaluate(
    *,
    function: str,
    ref: str | None = None,
) -> str:
    page = await browser_manager.get_page()
    try:
        if ref:
            handle = await page.query_selector(parse_ref(ref))
            if handle is None:
                raise OperationError(f"Element not found: {ref}")
            result = await handle.evaluate(function)
        else:
            result = await page.evaluate(function)
    except OperationError:
        raise
    except Exception as exc:
        raise OperationError(f"Evaluation failed: {exc}") from exc

    if result is None:
        return "Evaluation completed (returned undefined)"
    if isinstance(result, (dict, list)):
        return json.dumps(result, indent=2)
    return str(result)


async def take_screenshot(
    *,
    filename: str | None = None,
    full_page: bool = False,
    ref: str | None = None,
    image_format: Literal["png", "jpeg"] = "png",
    label: str | None = None,
) -> str:
    page = await browser_manager.get_page()
    try:
        target_name = label or ref
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"page-{timestamp}.{image_format}"
        path = Path(filename)
        if not path.is_absolute():
            path = Path.cwd() / "screenshots" / filename
            path.parent.mkdir(parents=True, exist_ok=True)

        if ref:
            handle = await page.query_selector(parse_ref(ref))
            if handle is None:
                raise OperationError(f"Element not found: {ref}")
            await handle.screenshot(path=str(path), type=image_format)
            description = f"Screenshot of {target_name}" if target_name else "Screenshot"
            return f"{description} saved to: {path}"

        await page.screenshot(path=str(path), full_page=full_page, type=image_format)
        return f"Screenshot saved to: {path}"
    except OperationError:
        raise
    except Exception as exc:
        raise OperationError(f"Screenshot failed: {exc}") from exc


async def console_messages(level: Literal["error", "warning", "info", "debug"] = "info") -> str:
    messages = browser_manager.get_console_messages(level)
    if not messages:
        return f"No console messages at level '{level}' or above"

    lines = []
    for message in messages:
        location = f" ({message.location})" if message.location else ""
        lines.append(f"[{message.type.upper()}]{location} {message.text}")
    return "\n".join(lines)


async def network_requests(include_static: bool = False) -> str:
    requests = browser_manager.get_network_requests(include_static)
    if not requests:
        return "No network requests recorded"

    lines = []
    for request in requests:
        status = request.status if request.status is not None else "pending"
        lines.append(
            f"[{request.method}] {request.url} - {status} ({request.resource_type})"
        )
    return "\n".join(lines)


async def tabs(*, action: Literal["list", "new", "close", "select"], index: int | None = None) -> str:
    try:
        if action == "list":
            open_tabs = await browser_manager.list_pages()
            if not open_tabs:
                return "No tabs open"
            lines = []
            for tab in open_tabs:
                active = " (active)" if tab.is_active else ""
                lines.append(f"[{tab.index}]{active} {tab.title} - {tab.url}")
            return "\n".join(lines)

        if action == "new":
            _, tab_index = await browser_manager.create_page()
            return f"Created new tab at index {tab_index}"

        if action == "close":
            await browser_manager.close_page(index)
            return f"Closed tab at index {index if index is not None else 'current'}"

        if action == "select":
            if index is None:
                raise OperationError("index is required for select action")
            await browser_manager.select_page(index)
            open_tabs = await browser_manager.list_pages()
            active_tab = next((tab for tab in open_tabs if tab.is_active), None)
            if active_tab:
                return f"Selected tab {index}: {active_tab.title}"
            return f"Selected tab {index}"
    except OperationError:
        raise
    except Exception as exc:
        raise OperationError(f"Tab operation failed: {exc}") from exc

    raise OperationError(f"Unknown action: {action}")


async def resize(width: int, height: int) -> str:
    page = await browser_manager.get_page()
    try:
        await page.set_viewport_size({"width": width, "height": height})
        return f"Resized browser to {width}x{height}"
    except Exception as exc:
        raise OperationError(f"Resize failed: {exc}") from exc


async def close_browser() -> str:
    try:
        await browser_manager.close()
        return "Browser closed successfully"
    except Exception as exc:
        raise OperationError(f"Failed to close browser: {exc}") from exc


async def install_browser() -> str:
    try:
        result = subprocess.run(
            [sys.executable, "-m", "camoufox", "fetch"],
            capture_output=True,
            text=True,
            timeout=300,
        )
    except subprocess.TimeoutExpired as exc:
        raise OperationError("Installation timed out after 5 minutes") from exc
    except FileNotFoundError as exc:
        raise OperationError("Python interpreter not found for installation") from exc
    except Exception as exc:
        raise OperationError(f"Installation failed: {exc}") from exc

    if result.returncode != 0:
        error = result.stderr.strip() if result.stderr else "Unknown error"
        raise OperationError(f"Installation failed: {error}")

    output = result.stdout.strip() if result.stdout else "Installation completed"
    return f"Camoufox installed successfully.\n{output}"


async def fill_form(fields: list[dict] | list[FormField]) -> str:
    page = await browser_manager.get_page()
    filled: list[str] = []
    errors: list[str] = []

    for field_data in fields:
        raw_field = field_data.model_dump() if isinstance(field_data, FormField) else field_data
        try:
            field = field_data if isinstance(field_data, FormField) else FormField(**field_data)
            selector = parse_ref(field.ref)

            if field.type == "textbox":
                await page.fill(selector, field.value)
            elif field.type == "checkbox":
                is_checked = await page.is_checked(selector)
                should_check = field.value.lower() == "true"
                if is_checked != should_check:
                    await page.click(selector)
            elif field.type == "radio":
                await page.click(selector)
            elif field.type == "combobox":
                await page.select_option(selector, [field.value])
            elif field.type == "slider":
                handle = await page.query_selector(selector)
                if handle is None:
                    raise OperationError(f"Element not found: {field.ref}")
                await handle.evaluate(
                    """(element, value) => {
                        element.value = value;
                        element.dispatchEvent(new Event('input', { bubbles: true }));
                        element.dispatchEvent(new Event('change', { bubbles: true }));
                    }""",
                    field.value,
                )
            filled.append(field.name)
        except Exception as exc:
            field_name = raw_field.get("name", "unknown")
            errors.append(f"{field_name}: {exc}")

    if errors:
        details = []
        if filled:
            details.append(f"Filled fields: {', '.join(filled)}")
        details.append(f"Errors: {'; '.join(errors)}")
        raise OperationError("\n".join(details))

    if filled:
        return f"Filled fields: {', '.join(filled)}"
    return "No fields processed"


async def file_upload(
    *,
    paths: list[str] | None = None,
    ref: str | None = None,
    label: str | None = None,
) -> str:
    page = await browser_manager.get_page()
    target = label or ref
    files = paths or []

    try:
        if ref:
            await page.locator(parse_ref(ref)).set_input_files(files)
            action = "Uploaded files" if files else "Cleared files"
            suffix = f" for {target}" if target else ""
            return f"{action}{suffix}: {', '.join(files) if files else '(none)'}"

        chooser = browser_manager.consume_pending_file_chooser()
        if chooser is None:
            raise OperationError(
                "No pending file chooser. Provide a file input ref or trigger the chooser first."
            )
        await chooser.set_files(files)
        return f"Uploaded files: {', '.join(files) if files else '(none)'}"
    except OperationError:
        raise
    except Exception as exc:
        raise OperationError(f"File upload failed: {exc}") from exc


async def handle_dialog(*, accept: bool, prompt_text: str | None = None) -> str:
    handled = await browser_manager.handle_dialog(accept, prompt_text)
    if not handled:
        raise OperationError("No pending dialog to handle")
    action = "accepted" if accept else "dismissed"
    return f"Dialog {action}"
