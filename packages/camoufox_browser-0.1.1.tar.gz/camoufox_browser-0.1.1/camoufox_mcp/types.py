"""Pydantic models for tool parameters."""

from typing import Literal

from pydantic import BaseModel, Field


class ViewportConfig(BaseModel):
    """Viewport configuration."""

    width: int = Field(..., ge=1, description="Viewport width in pixels")
    height: int = Field(..., ge=1, description="Viewport height in pixels")


class ProxyConfig(BaseModel):
    """Proxy configuration."""

    server: str = Field(..., description="Proxy server URL")
    username: str | None = Field(None, description="Proxy username")
    password: str | None = Field(None, description="Proxy password")


class FormField(BaseModel):
    """Form field for browser_fill_form tool."""

    name: str = Field(..., description="Human-readable field name")
    ref: str = Field(
        ..., description="Exact target field reference from the page snapshot"
    )
    type: Literal["textbox", "checkbox", "radio", "combobox", "slider"] = Field(
        ..., description="Type of the field"
    )
    value: str = Field(
        ...,
        description="Value to fill. For checkbox use 'true'/'false'. For combobox use option text.",
    )


class TabInfo(BaseModel):
    """Information about a browser tab."""

    index: int = Field(..., description="Tab index")
    url: str = Field(..., description="Current URL of the tab")
    title: str = Field(..., description="Page title")
    is_active: bool = Field(..., description="Whether this is the active tab")


class NetworkRequest(BaseModel):
    """Network request information."""

    url: str = Field(..., description="Request URL")
    method: str = Field(..., description="HTTP method")
    status: int | None = Field(None, description="Response status code")
    resource_type: str = Field(
        ..., description="Resource type (document, script, etc.)"
    )


class ConsoleMessage(BaseModel):
    """Console message information."""

    type: str = Field(..., description="Message type (log, error, warning, etc.)")
    text: str = Field(..., description="Message text")
    location: str | None = Field(None, description="Source location")
