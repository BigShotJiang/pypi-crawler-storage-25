"""Custom exceptions for Camoufox MCP server."""


class CamoufoxMCPError(Exception):
    """Base exception for Camoufox MCP errors."""

    pass


class OperationError(CamoufoxMCPError):
    """Raised when a browser operation fails in an expected way."""

    pass


class BrowserNotInitializedError(CamoufoxMCPError):
    """Raised when browser operations are attempted before initialization."""

    def __init__(
        self, message: str = "Browser is not initialized. Call a navigation tool first."
    ):
        super().__init__(message)


class ElementNotFoundError(CamoufoxMCPError):
    """Raised when a referenced element cannot be found."""

    def __init__(self, ref: str, message: str | None = None):
        self.ref = ref
        msg = message or f"Element with ref '{ref}' not found"
        super().__init__(msg)


class NavigationError(CamoufoxMCPError):
    """Raised when navigation fails."""

    def __init__(self, url: str, reason: str | None = None):
        self.url = url
        msg = f"Failed to navigate to '{url}'"
        if reason:
            msg += f": {reason}"
        super().__init__(msg)


class TimeoutError(CamoufoxMCPError):
    """Raised when an operation times out."""

    def __init__(self, operation: str, timeout_ms: int):
        self.operation = operation
        self.timeout_ms = timeout_ms
        super().__init__(f"Operation '{operation}' timed out after {timeout_ms}ms")


class PageNotFoundError(CamoufoxMCPError):
    """Raised when a page/tab index is invalid."""

    def __init__(self, index: int, available: int):
        self.index = index
        self.available = available
        super().__init__(
            f"Page index {index} not found. Available pages: 0-{available - 1}"
        )
