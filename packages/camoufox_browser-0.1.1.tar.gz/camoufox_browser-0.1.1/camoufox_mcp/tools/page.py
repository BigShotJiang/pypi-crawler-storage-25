"""Page tools as thin MCP adapters over the CLI operation layer."""

from typing import Literal

from mcp.server.fastmcp import FastMCP

from ..operations import console_messages, evaluate, network_requests, take_screenshot


def register(mcp: FastMCP) -> None:
    """Register page tools with the MCP server."""

    @mcp.tool()
    async def browser_evaluate(
        function: str,
        element: str | None = None,
        ref: str | None = None,
    ) -> str:
        """Evaluate JavaScript expression on page or element."""
        del element
        return await evaluate(function=function, ref=ref)

    @mcp.tool()
    async def browser_console_messages(
        level: Literal["error", "warning", "info", "debug"] = "info",
    ) -> str:
        """Return console messages."""
        return await console_messages(level)

    @mcp.tool()
    async def browser_network_requests(include_static: bool = False) -> str:
        """Return network requests recorded for the session."""
        return await network_requests(include_static)

    @mcp.tool()
    async def browser_take_screenshot(
        full_page: bool = False,
        filename: str | None = None,
        element: str | None = None,
        ref: str | None = None,
        type: Literal["png", "jpeg"] = "png",
    ) -> str:
        """Take a screenshot of the current page or element."""
        return await take_screenshot(
            filename=filename,
            full_page=full_page,
            ref=ref,
            image_format=type,
            label=element,
        )
