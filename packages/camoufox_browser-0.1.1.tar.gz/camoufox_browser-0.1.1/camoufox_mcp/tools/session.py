"""Session tools as thin MCP adapters over the CLI operation layer."""

from typing import Literal

from mcp.server.fastmcp import FastMCP

from ..operations import close_browser, install_browser, resize, tabs


def register(mcp: FastMCP) -> None:
    """Register session tools with the MCP server."""

    @mcp.tool()
    async def browser_tabs(
        action: Literal["list", "new", "close", "select"],
        index: int | None = None,
    ) -> str:
        """List, create, close, or select a browser tab."""
        return await tabs(action=action, index=index)

    @mcp.tool()
    async def browser_resize(width: int, height: int) -> str:
        """Resize the browser window."""
        return await resize(width, height)

    @mcp.tool()
    async def browser_close() -> str:
        """Close the browser."""
        return await close_browser()

    @mcp.tool()
    async def browser_install() -> str:
        """Download and install the Camoufox browser."""
        return await install_browser()
