"""Browser automation tools for the MCP server."""

from . import forms, interaction, navigation, page, session

__all__ = ["navigation", "interaction", "page", "forms", "session"]
