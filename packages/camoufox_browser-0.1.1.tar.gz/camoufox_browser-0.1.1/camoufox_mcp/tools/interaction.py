"""Interaction tools as thin MCP adapters over the CLI operation layer."""

from typing import Literal

from mcp.server.fastmcp import FastMCP

from ..operations import click, drag_and_drop, hover, press_key, select_option, type_text


def register(mcp: FastMCP) -> None:
    """Register interaction tools with the MCP server."""

    @mcp.tool()
    async def browser_click(
        element: str,
        ref: str,
        button: Literal["left", "right", "middle"] = "left",
        double_click: bool = False,
    ) -> str:
        """Perform click on a web page element."""
        return await click(
            ref=ref,
            button=button,
            double_click=double_click,
            label=element,
        )

    @mcp.tool()
    async def browser_type(
        element: str,
        ref: str,
        text: str,
        slowly: bool = False,
        submit: bool = False,
    ) -> str:
        """Type text into an editable element."""
        return await type_text(
            ref=ref,
            text=text,
            slowly=slowly,
            submit=submit,
            label=element,
        )

    @mcp.tool()
    async def browser_hover(element: str, ref: str) -> str:
        """Hover over an element on the page."""
        return await hover(ref=ref, label=element)

    @mcp.tool()
    async def browser_drag(
        start_element: str,
        start_ref: str,
        end_element: str,
        end_ref: str,
    ) -> str:
        """Perform drag and drop between two elements."""
        return await drag_and_drop(
            start_ref=start_ref,
            end_ref=end_ref,
            start_label=start_element,
            end_label=end_element,
        )

    @mcp.tool()
    async def browser_press_key(key: str) -> str:
        """Press a key on the keyboard."""
        return await press_key(key)

    @mcp.tool()
    async def browser_select_option(
        element: str,
        ref: str,
        values: list[str],
    ) -> str:
        """Select an option in a dropdown."""
        return await select_option(ref=ref, values=values, label=element)
