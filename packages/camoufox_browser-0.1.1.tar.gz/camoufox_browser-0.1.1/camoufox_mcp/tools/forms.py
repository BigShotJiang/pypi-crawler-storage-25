"""Form tools as thin MCP adapters over the CLI operation layer."""

from mcp.server.fastmcp import FastMCP

from ..operations import file_upload, fill_form, handle_dialog


def register(mcp: FastMCP) -> None:
    """Register form tools with the MCP server."""

    @mcp.tool()
    async def browser_fill_form(fields: list[dict]) -> str:
        """Fill multiple form fields."""
        return await fill_form(fields)

    @mcp.tool()
    async def browser_file_upload(
        paths: list[str] | None = None,
        element: str | None = None,
        ref: str | None = None,
    ) -> str:
        """Upload files through a file input ref or a pending file chooser."""
        return await file_upload(paths=paths, ref=ref, label=element)

    @mcp.tool()
    async def browser_handle_dialog(
        accept: bool,
        prompt_text: str | None = None,
    ) -> str:
        """Handle a dialog (alert, confirm, prompt, beforeunload)."""
        return await handle_dialog(accept=accept, prompt_text=prompt_text)
