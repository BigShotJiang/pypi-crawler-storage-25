"""Navigation tools as thin MCP adapters over the CLI operation layer."""

from mcp.server.fastmcp import FastMCP

from ..operations import navigate, navigate_back, snapshot, wait_for


def register(mcp: FastMCP) -> None:
    """Register navigation tools with the MCP server."""

    @mcp.tool()
    async def browser_navigate(url: str) -> str:
        """Navigate to a URL."""
        return await navigate(url)

    @mcp.tool()
    async def browser_navigate_back() -> str:
        """Go back to the previous page."""
        return await navigate_back()

    @mcp.tool()
    async def browser_snapshot() -> str:
        """Capture accessibility snapshot of the current page."""
        return await snapshot()

    @mcp.tool()
    async def browser_wait_for(
        text: str | None = None,
        text_gone: str | None = None,
        time: float | None = None,
    ) -> str:
        """Wait for text to appear, disappear, or a specified time to pass."""
        return await wait_for(text=text, text_gone=text_gone, time_seconds=time)
