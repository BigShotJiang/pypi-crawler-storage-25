"""Browser configuration for Camoufox."""

from dataclasses import dataclass, field
from typing import Any, Literal


@dataclass
class BrowserConfig:
    """Configuration for Camoufox browser launch parameters.

    All 19 Camoufox launch parameters with sensible defaults.
    """

    # OS to spoof (windows/macos/linux)
    os: Literal["windows", "macos", "linux"] | None = None

    # Headless mode (bool or 'virtual' for virtual display)
    headless: bool | Literal["virtual"] = False

    # Human-like cursor movements
    humanize: bool | float = True

    # Auto-detect geolocation from IP
    geoip: bool = True

    # Proxy configuration (string URL or dict)
    # Example: proxy = {
    #     'server': 'http://thordata.com:8080',
    #     'username': 'username',
    #     'password': 'password'
    # }
    proxy: str | dict[str, Any] | None = None

    # Block WebRTC leaks
    block_webrtc: bool = True

    # Block WebGL fingerprinting
    block_webgl: bool = False

    # Block image loading
    block_images: bool = False

    # Browser locale
    locale: str | None = None

    # Viewport dimensions
    viewport: dict[str, int] | None = None

    # Enable caching
    enable_cache: bool = True

    # Custom Firefox preferences
    firefox_user_prefs: dict[str, Any] | None = None

    # Addons to exclude
    exclude_addons: list[str] | None = None

    # Fixed window size
    window: tuple[int, int] | None = None

    # Additional browser arguments
    args: list[str] = field(default_factory=list)

    # Page load timeout in milliseconds
    timeout: int = 30000

    # Wait strategy: domcontentloaded/load/networkidle
    wait_strategy: Literal["domcontentloaded", "load", "networkidle"] = (
        "domcontentloaded"
    )

    # Disable COOP for iframes
    disable_coop: bool = False

    # Enable uBlock Origin
    ublock: bool = False

    def to_launch_kwargs(self) -> dict[str, Any]:
        """Convert config to kwargs for AsyncCamoufox launch."""
        kwargs: dict[str, Any] = {}

        if self.os is not None:
            kwargs["os"] = self.os

        kwargs["headless"] = self.headless
        kwargs["humanize"] = self.humanize
        kwargs["geoip"] = self.geoip

        if self.proxy is not None:
            kwargs["proxy"] = self.proxy

        kwargs["block_webrtc"] = self.block_webrtc
        kwargs["block_webgl"] = self.block_webgl
        kwargs["block_images"] = self.block_images

        if self.locale is not None:
            kwargs["locale"] = self.locale

        if self.viewport is not None:
            kwargs["viewport"] = self.viewport

        kwargs["enable_cache"] = self.enable_cache

        if self.firefox_user_prefs is not None:
            kwargs["firefox_user_prefs"] = self.firefox_user_prefs

        if self.exclude_addons is not None:
            kwargs["exclude_addons"] = self.exclude_addons

        if self.window is not None:
            kwargs["window"] = self.window

        if self.args:
            kwargs["args"] = self.args

        # Note: timeout and wait_strategy are used at navigation level
        # disable_coop and ublock might need special handling
        kwargs["disable_coop"] = self.disable_coop
        kwargs["addons"] = [] if not self.ublock else None  # Default includes uBlock

        return kwargs


# Global config instance
config = BrowserConfig()
