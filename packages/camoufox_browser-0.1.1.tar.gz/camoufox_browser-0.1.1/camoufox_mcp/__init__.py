"""CLI-first browser automation with Camoufox and an optional MCP adapter."""

__version__ = "0.1.0"
