from __future__ import annotations

import subprocess
import sys
import tomllib
import unittest
from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

from camoufox_mcp.cli.main import cli
from camoufox_mcp.cli.protocol import Response

REPO_ROOT = Path(__file__).resolve().parents[1]
SKILL_PATH = REPO_ROOT / "skills" / "camoufox" / "SKILL.md"


class CliSmokeTests(unittest.TestCase):
    def setUp(self) -> None:
        self.runner = CliRunner()

    def test_help_lists_agent_browser_style_commands(self) -> None:
        result = self.runner.invoke(cli, ["--help"])
        self.assertEqual(result.exit_code, 0)
        for command in [
            "open",
            "snapshot",
            "click",
            "fill",
            "select",
            "upload",
            "screenshot",
            "close",
        ]:
            self.assertIn(command, result.output)
        self.assertNotIn("configure", result.output)

    def test_alias_commands_exist(self) -> None:
        for command in ["navigate", "type", "select-option", "press-key", "evaluate"]:
            with self.subTest(command=command):
                result = self.runner.invoke(cli, [command, "--help"])
                self.assertEqual(result.exit_code, 0)

    def test_repo_skill_exists(self) -> None:
        self.assertTrue(SKILL_PATH.is_file())
        self.assertIn("camoufox-browser", SKILL_PATH.read_text())

    def test_module_entrypoint_is_cli(self) -> None:
        result = subprocess.run(
            [sys.executable, "-m", "camoufox_mcp", "--help"],
            cwd=REPO_ROOT,
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("camoufox-browser", result.stdout)
        self.assertIn("open", result.stdout)

    def test_project_scripts_use_camoufox_browser(self) -> None:
        pyproject = tomllib.loads((REPO_ROOT / "pyproject.toml").read_text())
        scripts = pyproject["project"]["scripts"]
        classifiers = pyproject["project"]["classifiers"]
        self.assertIn("camoufox-browser", scripts)
        self.assertIn("camoufox-mcp", scripts)
        self.assertNotIn("camoufox", scripts)
        self.assertNotIn("Operating System :: OS Independent", classifiers)

    def test_cli_returns_non_zero_when_daemon_reports_error(self) -> None:
        with (
            patch("camoufox_mcp.cli.main._require_daemon", return_value=None),
            patch(
                "camoufox_mcp.cli.main.send_sync",
                return_value=Response(ok=False, error="boom"),
            ),
        ):
            result = self.runner.invoke(cli, ["open", "https://example.com"])
        self.assertEqual(result.exit_code, 1)
        self.assertIn("Error: boom", result.output)


if __name__ == "__main__":
    unittest.main()
