---
name: camoufox
description: >
  Use for browser automation through camoufox-browser: open a page, inspect it
  with snapshot refs, click, fill, select, upload, take screenshots, and drive
  websites through the CLI instead of direct browser code.
---

# Camoufox Browser Automation

Use `camoufox-browser` for browser automation. Prefer the CLI directly. The MCP
server is just a thin adapter over the same command layer, and this skill exists
to teach the agent the normal CLI workflow.

## Primary workflow

1. Open a page:

```bash
camoufox-browser open https://example.com
```

2. Inspect the page and collect refs:

```bash
camoufox-browser snapshot
```

3. Interact using refs from the snapshot:

```bash
camoufox-browser click 'button:Sign in'
camoufox-browser fill 'textbox:Email' user@example.com
camoufox-browser select 'combobox:Country' Ukraine
camoufox-browser upload 'textbox:Resume' /absolute/path/resume.pdf
```

4. Re-run `snapshot` after navigation or significant DOM changes.

5. Capture artifacts when needed:

```bash
camoufox-browser screenshot --output page.png
camoufox-browser eval '() => document.title'
```

## Notes

- You do not need to run `start` for the normal flow. `camoufox-browser` auto-starts the daemon with default settings when a browser command needs it.
- Use `camoufox-browser start --headless` only when you need explicit daemon control or startup options like `--proxy`.
- `camoufox-browser` is intended for Linux and macOS hosts.
- Use `camoufox-browser --help` to discover the full command surface.
- Install this skill through `npx skills add <repo> --skill camoufox`.

## Core commands

```bash
camoufox-browser open <url>
camoufox-browser snapshot
camoufox-browser click <ref>
camoufox-browser fill <ref> <text>
camoufox-browser select <ref> <value> [more-values...]
camoufox-browser upload <ref> <file> [more-files...]
camoufox-browser screenshot [--output FILE]
camoufox-browser close
```

## Advanced commands

```bash
camoufox-browser start [--headless] [--os windows|macos|linux] [--proxy PROXY]
camoufox-browser stop
camoufox-browser status
camoufox-browser tabs list|new|close [index]|select <index>
```
