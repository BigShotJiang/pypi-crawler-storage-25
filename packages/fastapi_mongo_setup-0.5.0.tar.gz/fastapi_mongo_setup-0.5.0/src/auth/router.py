from fastapi import APIRouter, HTTPException, Depends
from src.auth.schemas import UserCreate, UserLogin, UserResponse, Token
from src.auth.service import AuthService
from src.auth.dependencies import create_access_token, get_current_user
from src.auth.utils import verify_password

router = APIRouter(prefix="/auth", tags=["Authentication"])

@router.post("/register", response_model=UserResponse)
async def register(user: UserCreate):
    """Register a new user account."""
    existing_user = await AuthService.get_user_by_email(user.email)
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    created_user = await AuthService.create_user(user.model_dump())
    return created_user

@router.post("/login", response_model=Token)
async def login(user: UserLogin):
    """Authenticate user and return a JWT access token."""
    db_user = await AuthService.get_user_by_email(user.email)
    if not db_user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    if not verify_password(user.password, db_user["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    access_token = create_access_token(data={"sub": db_user["email"]})
    return {"access_token": access_token, "token_type": "bearer"}

@router.get("/me", response_model=UserResponse)
async def get_me(current_user: dict = Depends(get_current_user)):
    """Get the profile of the currently authenticated user."""
    return current_user
