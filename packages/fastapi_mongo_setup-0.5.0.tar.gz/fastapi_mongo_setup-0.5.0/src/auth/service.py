from src.utils.db import db
from src.utils.helpers import serialize_doc
from src.auth.utils import hash_password

class AuthService:
    @staticmethod
    def get_collection():
        return db.db["users"]

    @staticmethod
    async def create_user(user_data: dict) -> dict:
        """Hash password and insert user into the database."""
        user_data["password"] = hash_password(user_data["password"])
        result = await AuthService.get_collection().insert_one(user_data)
        created_user = await AuthService.get_collection().find_one({"_id": result.inserted_id})
        return serialize_doc(created_user)

    @staticmethod
    async def get_user_by_email(email: str):
        """Find a user document by email address."""
        user = await AuthService.get_collection().find_one({"email": email})
        return user
