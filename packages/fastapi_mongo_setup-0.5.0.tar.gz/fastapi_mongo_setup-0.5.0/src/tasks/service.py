from src.utils.db import db
from src.utils.helpers import serialize_doc, serialize_docs
from bson import ObjectId

class TaskService:
    @staticmethod
    def get_collection():
        return db.db["tasks"]

    @staticmethod
    async def create_task(task_data: dict) -> dict:
        result = await TaskService.get_collection().insert_one(task_data)
        created_task = await TaskService.get_collection().find_one({"_id": result.inserted_id})
        return serialize_doc(created_task)

    @staticmethod
    async def get_all_tasks() -> list:
        cursor = TaskService.get_collection().find()
        tasks = await cursor.to_list(length=100)
        return serialize_docs(tasks)

    @staticmethod
    async def delete_task(task_id: str) -> bool:
        result = await TaskService.get_collection().delete_one({"_id": ObjectId(task_id)})
        return result.deleted_count > 0
