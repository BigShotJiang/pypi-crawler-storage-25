from fastapi import APIRouter, HTTPException
from typing import List
from src.tasks.schemas import TaskCreate, TaskResponse
from src.tasks.service import TaskService

router = APIRouter(prefix="/tasks", tags=["Tasks"])

@router.post("/", response_model=TaskResponse)
async def create_task(task: TaskCreate):
    created_task = await TaskService.create_task(task.model_dump())
    return created_task

@router.get("/", response_model=List[TaskResponse])
async def get_tasks():
    return await TaskService.get_all_tasks()

@router.delete("/{task_id}")
async def delete_task(task_id: str):
    success = await TaskService.delete_task(task_id)
    if not success:
        raise HTTPException(status_code=404, detail="Task not found")
    return {"message": "Task deleted successfully"}
