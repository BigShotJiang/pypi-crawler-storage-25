"""CPU-only generation-loop regressions."""

from __future__ import annotations

from types import SimpleNamespace

import pytest
import torch

from saklas.core.generation import (
    GenerationConfig,
    GenerationState,
    _PenaltyState,
    generate_steered,
)
from saklas.core.session import SaklasSession


class _StopTokenizer:
    name_or_path = "stop-tokenizer"
    vocab_size = 4
    eos_token_id = 3
    added_tokens_encoder = {}
    all_special_ids = [3]

    _pieces = {
        0: "Hello",
        1: " STOP",
        2: " ignored",
        3: "",
    }

    def batch_decode(self, ids):
        return [self._pieces[row[0]] for row in ids]

    def decode(self, ids, skip_special_tokens=False):
        pieces = []
        for tid in ids:
            if skip_special_tokens and tid in self.all_special_ids:
                continue
            pieces.append(self._pieces[int(tid)])
        return "".join(pieces)


class _StopModel:
    config = SimpleNamespace(vocab_size=4)
    generation_config = SimpleNamespace(eos_token_id=3)

    def __init__(self):
        self._tokens = [0, 1, 2]
        self._idx = 0

    def __call__(self, **_kwargs):
        tid = self._tokens[min(self._idx, len(self._tokens) - 1)]
        self._idx += 1
        logits = torch.full((1, 1, self.config.vocab_size), -100.0)
        logits[0, 0, tid] = 100.0
        return SimpleNamespace(logits=logits, past_key_values=object())


class _NoCacheModel(_StopModel):
    def __init__(self):
        super().__init__()
        self._tokens = [0, 1, 3]

    def __call__(self, **_kwargs):
        out = super().__call__(**_kwargs)
        out.past_key_values = None
        return out


def test_stop_sequence_trimmed_text_is_final_result_text():
    model = _StopModel()
    tokenizer = _StopTokenizer()
    state = GenerationState()
    emitted: list[str] = []

    generated_ids = generate_steered(
        model,
        tokenizer,
        torch.tensor([[0]]),
        GenerationConfig(max_new_tokens=5, temperature=0.0),
        state,
        on_token=lambda text, *_args: emitted.append(text),
        stop=[" STOP"],
    )

    assert generated_ids == [0, 1]
    assert emitted == ["Hello"]
    assert state.finish_reason == "stop_sequence"
    assert state.response_text == "Hello"

    session = SaklasSession.__new__(SaklasSession)
    session._gen_state = state
    session._tokenizer = tokenizer
    session._monitor = SimpleNamespace(probe_names=[])
    session._last_per_token_scores = None
    session._last_result = None
    session.build_readings = lambda: {}

    result = SaklasSession._finalize_generation(
        session,
        "prompt",
        generated_ids,
        elapsed=1.0,
        vector_snapshot={},
        stateless=True,
    )
    assert result.text == "Hello"


def test_penalty_state_applies_sparse_counts_on_device():
    logits = torch.zeros(1, 8)
    state = _PenaltyState(max_tokens=4, device=logits.device, dtype=torch.float32)
    state.add(2)
    state.add(5)
    state.add(2)

    state.apply(logits, presence_penalty=0.5, frequency_penalty=0.25)

    assert logits[0, 2].item() == -1.0
    assert logits[0, 5].item() == -0.75
    assert logits[0, 1].item() == 0.0


def test_no_cache_fallback_does_not_cat_each_step(monkeypatch):
    model = _NoCacheModel()
    tokenizer = _StopTokenizer()
    state = GenerationState()

    def _forbid_cat(*_args, **_kwargs):
        raise AssertionError("no-cache fallback should use the preallocated buffer")

    monkeypatch.setattr(torch, "cat", _forbid_cat)
    with pytest.warns(UserWarning, match="no past_key_values"):
        generated_ids = generate_steered(
            model,
            tokenizer,
            torch.tensor([[0, 0]]),
            GenerationConfig(max_new_tokens=3, temperature=0.0),
            state,
        )

    assert generated_ids == [0, 1]
    assert state.finish_reason == "stop"
