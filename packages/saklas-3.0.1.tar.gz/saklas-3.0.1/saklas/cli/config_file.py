"""User-authored setup YAML parser for saklas -C <path>.

The ``vectors:`` key is a steering expression string (the same grammar
every surface speaks); the loader validates it and stores the raw text.
Parsing into a :class:`~saklas.core.steering.Steering` happens at
consumption time via :func:`saklas.core.steering_expr.parse_expr`.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Optional

from saklas.core.errors import SaklasError

log = logging.getLogger(__name__)

_KNOWN_KEYS = {
    "model", "vectors", "thinking",
    "temperature", "top_p", "max_tokens", "system_prompt",
    "extraction_method",
    "injection_mode", "theta_max",
    "projection_metric",
    "compile", "cuda_graphs",
    "return_top_k",
}

_VALID_EXTRACTION_METHODS = ("dim", "pca")
_VALID_INJECTION_MODES = ("angular", "additive")
_VALID_PROJECTION_METRICS = ("mahalanobis", "euclidean")


class ConfigFileError(ValueError, SaklasError):
    def user_message(self) -> tuple[int, str]:
        return (400, str(self) or self.__class__.__name__)


@dataclass
class ConfigFile:
    model: Optional[str] = None
    vectors: Optional[str] = None
    thinking: Optional[bool] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    max_tokens: Optional[int] = None
    system_prompt: Optional[str] = None
    extraction_method: Optional[str] = None  # "dim" | "pca"; None = use default
    injection_mode: Optional[str] = None     # "angular" | "additive"; None = default
    theta_max: Optional[float] = None        # radians; None = default π/2
    projection_metric: Optional[str] = None  # "mahalanobis" | "euclidean"; None = default
    compile: Optional[bool] = None           # CUDA torch.compile auto-enable; None = default (on)
    cuda_graphs: Optional[bool] = None       # CUDA StaticCache + graph capture; None = default (on)
    # Session-level default for SamplingConfig.return_top_k — the number
    # of top-K alternatives the engine decodes (with text) per generated
    # token.  ``None`` means "use session default" (which is 0 — chosen
    # logprob only).  Per-call SamplingConfig.return_top_k > 0 overrides;
    # K=0 inherits this session-level value.  Phase 1 logit pass.
    return_top_k: Optional[int] = None

    @classmethod
    def load_default(cls) -> Optional["ConfigFile"]:
        """Load ``~/.saklas/config.yaml`` if it exists, else return ``None``."""
        from saklas.io.paths import saklas_home
        p = saklas_home() / "config.yaml"
        if not p.exists():
            return None
        return cls.load(p)

    @classmethod
    def effective(
        cls,
        extra_paths: list[Path] | None = None,
        *,
        include_default: bool = True,
    ) -> "ConfigFile":
        """Compose the default config + extras into a single ConfigFile.

        Order: ``~/.saklas/config.yaml`` (if present) → extras (in order).
        Later entries override earlier ones.
        """
        chain: list[ConfigFile] = []
        if include_default:
            default = cls.load_default()
            if default is not None:
                chain.append(default)
        for p in extra_paths or []:
            chain.append(cls.load(Path(p)))
        return compose(chain) if chain else cls()

    def to_dict(self) -> dict:
        out: dict = {}
        for f in ("model", "thinking", "temperature", "top_p", "max_tokens", "system_prompt"):
            v = getattr(self, f)
            if v is not None:
                out[f] = v
        if self.vectors:
            out["vectors"] = self.vectors
        return out

    def to_yaml(self, *, header: Optional[str] = None) -> str:
        import yaml
        body = yaml.safe_dump(self.to_dict(), sort_keys=False, default_flow_style=False)
        if header:
            return f"{header}\n{body}"
        return body

    @classmethod
    def load(cls, path: Path) -> "ConfigFile":
        import yaml
        try:
            with open(path) as f:
                data = yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            raise ConfigFileError(f"{path}: YAML parse error: {e}") from e
        if not isinstance(data, dict):
            raise ConfigFileError(f"{path}: top-level must be a mapping")

        unknown = set(data.keys()) - _KNOWN_KEYS
        for k in unknown:
            log.warning("unknown key %r in %s (ignored)", k, path)

        vectors_raw = data.get("vectors")
        vectors: Optional[str] = None
        if vectors_raw is not None:
            if not isinstance(vectors_raw, str):
                raise ConfigFileError(
                    f"{path}: vectors: must be a steering expression string "
                    f"(got {type(vectors_raw).__name__}). Example: "
                    f"`vectors: \"0.5 honest + 0.3 warm\"`."
                )
            text = vectors_raw.strip()
            if text:
                # Validate via the shared parser; raise a wrapped error on
                # failure so the YAML path surfaces the column/detail.
                from saklas.core.steering_expr import (
                    SteeringExprError, parse_expr,
                )
                try:
                    parse_expr(text)
                except SteeringExprError as e:
                    raise ConfigFileError(
                        f"{path}: vectors: {e}"
                    ) from e
                vectors = text

        extraction_method = data.get("extraction_method")
        if extraction_method is not None:
            if (
                not isinstance(extraction_method, str)
                or extraction_method not in _VALID_EXTRACTION_METHODS
            ):
                raise ConfigFileError(
                    f"{path}: extraction_method must be one of "
                    f"{list(_VALID_EXTRACTION_METHODS)} "
                    f"(got {extraction_method!r})"
                )

        injection_mode = data.get("injection_mode")
        if injection_mode is not None:
            if (
                not isinstance(injection_mode, str)
                or injection_mode not in _VALID_INJECTION_MODES
            ):
                raise ConfigFileError(
                    f"{path}: injection_mode must be one of "
                    f"{list(_VALID_INJECTION_MODES)} "
                    f"(got {injection_mode!r})"
                )

        theta_max = data.get("theta_max")
        if theta_max is not None:
            if not isinstance(theta_max, (int, float)) or isinstance(theta_max, bool):
                raise ConfigFileError(
                    f"{path}: theta_max must be a number (radians); "
                    f"got {type(theta_max).__name__} {theta_max!r}"
                )
            if theta_max <= 0:
                raise ConfigFileError(
                    f"{path}: theta_max must be > 0 (got {theta_max!r})"
                )
            theta_max = float(theta_max)

        projection_metric = data.get("projection_metric")
        if projection_metric is not None:
            if (
                not isinstance(projection_metric, str)
                or projection_metric not in _VALID_PROJECTION_METRICS
            ):
                raise ConfigFileError(
                    f"{path}: projection_metric must be one of "
                    f"{list(_VALID_PROJECTION_METRICS)} "
                    f"(got {projection_metric!r})"
                )

        compile_v = data.get("compile")
        if compile_v is not None and not isinstance(compile_v, bool):
            # ``compile: false`` is the documented opt-out; reject ints,
            # strings, etc. so a malformed YAML doesn't silently disable
            # compile via ``bool("false") == True``.
            raise ConfigFileError(
                f"{path}: compile must be a boolean (got "
                f"{type(compile_v).__name__} {compile_v!r}). Use "
                f"``compile: true`` or ``compile: false``."
            )

        cuda_graphs_v = data.get("cuda_graphs")
        if cuda_graphs_v is not None and not isinstance(cuda_graphs_v, bool):
            raise ConfigFileError(
                f"{path}: cuda_graphs must be a boolean (got "
                f"{type(cuda_graphs_v).__name__} {cuda_graphs_v!r}). "
                f"Use ``cuda_graphs: true`` or ``cuda_graphs: false``."
            )

        return_top_k_v = data.get("return_top_k")
        if return_top_k_v is not None:
            # Reject bool sneaking through as int (``return_top_k: false``
            # would silently set 0 without this guard; the user almost
            # certainly meant a number).
            if isinstance(return_top_k_v, bool) or not isinstance(return_top_k_v, int):
                raise ConfigFileError(
                    f"{path}: return_top_k must be an integer in [0, 256] "
                    f"(got {type(return_top_k_v).__name__} {return_top_k_v!r})"
                )
            if return_top_k_v < 0 or return_top_k_v > 256:
                raise ConfigFileError(
                    f"{path}: return_top_k out of range [0, 256] "
                    f"(got {return_top_k_v!r})"
                )

        return cls(
            model=data.get("model"),
            vectors=vectors,
            thinking=data.get("thinking"),
            temperature=data.get("temperature"),
            top_p=data.get("top_p"),
            max_tokens=data.get("max_tokens"),
            system_prompt=data.get("system_prompt"),
            extraction_method=extraction_method,
            injection_mode=injection_mode,
            theta_max=theta_max,
            projection_metric=projection_metric,
            compile=compile_v,
            cuda_graphs=cuda_graphs_v,
            return_top_k=return_top_k_v,
        )


def compose(configs: list[ConfigFile]) -> ConfigFile:
    """Combine multiple config files; later entries override earlier ones.

    The ``vectors`` string overrides wholesale — later configs replace the
    earlier expression rather than concatenating. Callers that want to
    extend should spell out the full expression in their override file.
    """
    out = ConfigFile()
    for c in configs:
        for f in (
            "model", "thinking", "temperature",
            "top_p", "max_tokens", "system_prompt", "vectors",
            "extraction_method", "injection_mode", "theta_max",
            "projection_metric", "compile", "cuda_graphs",
            "return_top_k",
        ):
            v = getattr(c, f)
            if v is not None:
                setattr(out, f, v)
    return out


def apply_flag_overrides(cfg_in: ConfigFile, **flags) -> ConfigFile:
    """Return a new ConfigFile with non-None flag values overriding cfg_in."""
    supplied = {k: v for k, v in flags.items() if v is not None}
    return replace(cfg_in, **supplied)


def ensure_vectors_installed(config: ConfigFile, *, strict: bool) -> list[str]:
    """Install any vectors referenced in ``config.vectors`` that are not
    present locally.

    Walks the raw expression string via :func:`referenced_selectors` so
    namespace-qualified references (``bob/honest``) retain their install
    coordinates even though the parsed ``Steering`` flattens them. Returns
    a list of coords that could not be installed; in strict mode, raises
    on any failure instead.
    """
    from saklas.core.steering_expr import referenced_selectors
    from saklas.io.paths import concept_dir
    from saklas.io.packs import materialize_bundled
    from saklas.io import cache_ops

    if config.vectors is None:
        return []

    missing: list[str] = []
    for ns, concept, _variant in referenced_selectors(config.vectors):
        if ns is None:
            from saklas.io.selectors import _all_concepts
            slug = concept.split(".")[0] if "." in concept else concept
            matches = [
                c for c in _all_concepts()
                if c.name == concept
                or (
                    "." in c.name
                    and slug in c.name.split(".")
                )
            ]
            if matches:
                continue
            msg = f"vector {concept!r}: must be '<ns>/<name>' (no installed match)"
            if strict:
                raise ConfigFileError(msg)
            log.warning(msg)
            missing.append(concept)
            continue
        coord = f"{ns}/{concept}"
        cdir = concept_dir(ns, concept)
        if cdir.exists():
            continue
        if ns == "local":
            msg = f"vector {coord!r}: local namespace, cannot auto-install"
            if strict:
                raise ConfigFileError(msg)
            log.warning(msg)
            missing.append(coord)
            continue
        if ns == "default":
            materialize_bundled()
            if cdir.exists():
                continue
            msg = f"vector {coord!r}: bundled concept missing from package data"
            if strict:
                raise ConfigFileError(msg)
            log.warning(msg)
            missing.append(coord)
            continue
        try:
            cache_ops.install(coord, as_=None, force=False)
        except Exception as e:
            msg = f"vector {coord!r}: install failed ({e})"
            if strict:
                raise ConfigFileError(msg) from e
            log.warning(msg)
            missing.append(coord)
    return missing
