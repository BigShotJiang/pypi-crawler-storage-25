"""Per-call steering configuration for SaklasSession.generate.

A frozen dataclass wrapping ``alphas: {name: alpha_or_entry}`` plus an
optional ``thinking`` override and an optional default ``trigger``.
Callers hand :func:`Steering.from_value` either an expression string
(routed through the shared grammar in
:mod:`saklas.core.steering_expr`) or a pre-built :class:`Steering`.
Dict inputs are no longer accepted — the expression string is the only
input shape for ad-hoc use; programmatic callers construct the dataclass
directly.

An individual entry can carry its own :class:`~saklas.core.triggers.Trigger`
by using a ``(alpha, trigger)`` tuple as the dict value; entries given as
bare floats inherit ``Steering.trigger`` (which itself defaults to
``Trigger.BOTH``, the "steer every token" behavior).  Projection terms
land as :class:`~saklas.core.steering_expr.ProjectedTerm` values and are
materialized into derived profiles by
:class:`~saklas.core.session._SteeringContext` on scope entry.

Pole aliasing is NOT resolved here — that happens inside
``SaklasSession.steering()`` (the canonical resolver site, per the plan).
Callers that pre-resolve a pole via ``cli_selectors.resolve_pole`` can pass
the canonical name directly.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, TYPE_CHECKING, Union

from saklas.core.triggers import Trigger

if TYPE_CHECKING:
    from saklas.core.steering_expr import AblationTerm, ProjectedTerm

#: Accepted shapes for a single entry in ``Steering.alphas`` — a bare
#: alpha (inherits ``Steering.trigger``), a ``(alpha, Trigger)`` tuple for
#: a per-entry trigger override, a
#: :class:`~saklas.core.steering_expr.ProjectedTerm` for runtime
#: projection (materialized into a derived profile by the session), or
#: an :class:`~saklas.core.steering_expr.AblationTerm` for
#: mean-replacement ablation.
AlphaEntry = Union[
    float,
    "tuple[float, Trigger]",
    "ProjectedTerm",
    "AblationTerm",
]


@dataclass(frozen=True)
class Steering:
    """Per-call steering configuration.

    alphas: vector name -> alpha, ``(alpha, Trigger)``, or
        :class:`~saklas.core.steering_expr.ProjectedTerm`.  Pole aliases
        (bare poles of installed bipolar vectors) are resolved when the
        steering is entered via ``SaklasSession.steering()``.
    thinking: per-call thinking override; ``None`` means fall through to the
        caller's ``thinking=`` kwarg / the session default.
    trigger: default trigger for entries that are bare floats. Defaults to
        ``Trigger.BOTH`` — steer every token.  Entries given as
        ``(alpha, Trigger)`` tuples ignore this default; projection
        entries carry their own trigger inside the ``ProjectedTerm``.
    injection_mode: per-call override for the steering math.
        ``"angular"`` rotates the residual toward the concept direction;
        ``"additive"`` is the legacy v1.x add-and-rescale path.  ``None``
        (default) inherits the session-level setting passed to
        :class:`SaklasSession`.  Programmatic only — the canonical
        expression grammar does not (yet) round-trip this field.
    theta_max: per-call override for the angular rotation cap (radians).
        Defaults to the session value (``π/2`` unless overridden).  Has
        no effect under ``injection_mode="additive"``.
    projection_metric: per-call override for the metric used when
        materializing ``~`` / ``|`` projection terms.  ``"mahalanobis"``
        uses the closed-form LEACE projector against the session's
        :class:`~saklas.core.mahalanobis.LayerWhitener` (default since
        v2.1 — provably erases linearly-decodable information along
        ``onto`` from ``base``).  ``"euclidean"`` is plain Gram-Schmidt
        (the v2.0/v2.1 behavior).  ``None`` (default) inherits the
        session-level setting.  Programmatic only — the canonical
        expression grammar does not (yet) round-trip this field.
    """

    alphas: Mapping[str, AlphaEntry]
    thinking: bool | None = None
    trigger: Trigger = Trigger.BOTH
    injection_mode: str | None = None
    theta_max: float | None = None
    projection_metric: str | None = None

    @classmethod
    def from_value(
        cls, value: "str | Steering | None",
    ) -> "Steering | None":
        """Coerce a string / Steering / None into a Steering or None.

        Strings parse through the shared expression grammar in
        :mod:`saklas.core.steering_expr`.  ``None`` passes through (the
        caller interprets as "no steering").  Pre-built :class:`Steering`
        instances pass through unchanged.  Any other input type raises
        ``TypeError``.
        """
        if value is None:
            return None
        if isinstance(value, Steering):
            return value
        if isinstance(value, str):
            from saklas.core.steering_expr import parse_expr
            return parse_expr(value)
        raise TypeError(
            f"Steering.from_value expects str | Steering | None, "
            f"got {type(value).__name__}"  # pyright: ignore[reportUnreachable]
        )

    def normalized_entries(self) -> "dict[str, tuple[float, Trigger]]":
        """Return a plain ``{name: (alpha, trigger)}`` dict.

        Every entry carries an explicit trigger: tuple entries keep their
        per-entry trigger, bare-float entries take ``self.trigger``, and
        :class:`~saklas.core.steering_expr.ProjectedTerm` values flatten
        to ``(coeff, term.trigger)``.  This is the canonical form consumed
        by the session's steering stack and the hook manager — everything
        downstream of pole resolution works in this shape.  Synthetic
        projection keys (``"<base><op><onto>"``) pass through verbatim;
        the session is responsible for materializing the derived profile
        before the manager sees the key.  ``AblationTerm`` values are
        skipped — ablation is dispatched directly off ``Steering.alphas``
        at the session layer rather than through this flattened view.
        """
        from saklas.core.steering_expr import AblationTerm, ProjectedTerm

        out: dict[str, tuple[float, Trigger]] = {}
        default = self.trigger
        for name, val in self.alphas.items():
            if isinstance(val, AblationTerm):
                continue
            if isinstance(val, ProjectedTerm):
                out[name] = (float(val.coeff), val.trigger)
                continue
            if isinstance(val, tuple):
                alpha, trig = val
                out[name] = (float(alpha), trig)
                continue
            out[name] = (float(val), default)
        return out

    def __str__(self) -> str:
        from saklas.core.steering_expr import format_expr
        return format_expr(self)
