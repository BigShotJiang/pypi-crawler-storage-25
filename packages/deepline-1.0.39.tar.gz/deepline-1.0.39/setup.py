from __future__ import annotations

import os
from pathlib import Path
from setuptools import setup
from setuptools.command.build_py import build_py as _build_py
from setuptools.command.sdist import sdist as _sdist


ROOT = Path(__file__).resolve().parent
PACKAGE_RECIPES_RELATIVE_PATH = Path("deepline_core") / "recipes.json"


DEFAULT_PACKAGE_VERSION = "0.1.0"


def _resolve_recipes_source() -> Path:
    for parent in (ROOT, *ROOT.parents):
        candidate = parent / "src" / "lib" / "onboard" / "recipes.json"
        if candidate.is_file():
            return candidate
    packaged_recipes = ROOT / PACKAGE_RECIPES_RELATIVE_PATH
    if packaged_recipes.is_file():
        return packaged_recipes
    raise FileNotFoundError(
        "Unable to locate recipes.json for Python CLI packaging. "
        "Expected either the repo source file or a packaged copy in the sdist."
    )


def _copy_recipes(target_root: Path) -> None:
    target_path = target_root / PACKAGE_RECIPES_RELATIVE_PATH
    target_path.parent.mkdir(parents=True, exist_ok=True)
    target_path.write_text(_resolve_recipes_source().read_text(encoding="utf-8"), encoding="utf-8")


class build_py(_build_py):
    def run(self) -> None:
        super().run()
        _copy_recipes(Path(self.build_lib))


class sdist(_sdist):
    def make_release_tree(self, base_dir: str, files: list[str]) -> None:
        super().make_release_tree(base_dir, files)
        _copy_recipes(Path(base_dir))


setup(
    version=os.environ.get("DEEPLINE_PYPI_VERSION", DEFAULT_PACKAGE_VERSION),
    cmdclass={"build_py": build_py, "sdist": sdist},
)
