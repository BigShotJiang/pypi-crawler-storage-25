# Deepline CLI

The Deepline command line interface for running enrichments, workflows, and local runtime setup.

After installation, run `deepline --help` to get started.
