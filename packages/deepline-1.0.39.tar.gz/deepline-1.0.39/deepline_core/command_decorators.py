from __future__ import annotations

from dataclasses import dataclass, field
import difflib
from functools import wraps
import sys
from typing import Any, Callable, Dict

from deepline_core.command_common import EXIT_OK, EXIT_USAGE

CommandHandler = Callable[[str, Dict[str, str], list[str]], int]
UsageFactory = Callable[[], list[str]]
SubcommandHandler = Callable[[str, Dict[str, str], list[str]], int]
TypedParamsParser = Callable[["ParsedRouteOptions"], Any]
TypedSubcommandHandler = Callable[[str, Dict[str, str], Any], int]
UnknownHandler = Callable[[str, Dict[str, str], list[str]], int]


def print_usage(lines: list[str]) -> None:
    for line in lines:
        print(line)


def with_help(usage: UsageFactory) -> Callable[[CommandHandler], CommandHandler]:
    def decorate(fn: CommandHandler) -> CommandHandler:
        @wraps(fn)
        def wrapped(base_url: str, env: Dict[str, str], args: list[str]) -> int:
            if not args or args[0] in {"-h", "--help", "help"}:
                print_usage(usage())
                return EXIT_OK
            return fn(base_url, env, args)

        return wrapped

    return decorate


def build_command_handler(
    *,
    command_name: str,
    router: "SubcommandRouter",
    usage_factory: UsageFactory,
    on_unknown: UnknownHandler | None = None,
    unknown_to_stderr: bool = False,
) -> CommandHandler:
    @with_help(usage_factory)
    def _handle(base_url: str, env: Dict[str, str], args: list[str]) -> int:
        routed = router.dispatch(args[0], base_url, env, args[1:])
        if routed is not None:
            return routed
        if on_unknown is not None:
            return on_unknown(base_url, env, args)
        out = sys.stderr if unknown_to_stderr else sys.stdout
        print(f"Unknown {command_name} command: {args[0]}", file=out)
        candidates = sorted({spec.primary or spec.name for spec in router._specs.values() if (spec.primary or spec.name)})
        suggestion = difflib.get_close_matches(args[0], candidates, n=1, cutoff=0.55)
        if suggestion:
            print(f"Did you mean: deepline {command_name} {suggestion[0]}", file=out)
        return EXIT_USAGE

    return _handle


class SubcommandRouter:
    def __init__(self) -> None:
        self._routes: dict[str, SubcommandHandler] = {}
        self._typed_routes: dict[str, tuple[TypedSubcommandHandler, TypedParamsParser]] = {}
        self._specs: dict[str, RouteSpec] = {}

    def route(
        self,
        *names: str,
        summary: str = "",
        options: list[OptionSpec] | None = None,
        description: str = "",
        usage: str = "",
    ) -> Callable[[SubcommandHandler], SubcommandHandler]:
        primary = names[0] if names else ""

        def decorate(fn: SubcommandHandler) -> SubcommandHandler:
            for name in names:
                self._routes[name] = fn
                self._specs[name] = RouteSpec(
                    name=name,
                    summary=summary,
                    description=description,
                    options=list(options or []),
                    primary=primary,
                    usage=usage,
                )
            return fn

        return decorate

    def route_typed(
        self,
        *names: str,
        summary: str = "",
        options: list[OptionSpec] | None = None,
        description: str = "",
        usage: str = "",
        params_parser: TypedParamsParser,
    ) -> Callable[[TypedSubcommandHandler], TypedSubcommandHandler]:
        primary = names[0] if names else ""

        def decorate(fn: TypedSubcommandHandler) -> TypedSubcommandHandler:
            for name in names:
                self._typed_routes[name] = (fn, params_parser)
                self._specs[name] = RouteSpec(
                    name=name,
                    summary=summary,
                    description=description,
                    options=list(options or []),
                    primary=primary,
                    usage=usage,
                )
            return fn

        return decorate

    def dispatch(self, name: str, base_url: str, env: Dict[str, str], args: list[str]) -> int | None:
        typed = self._typed_routes.get(name)
        if typed is not None:
            if any(token in {"-h", "--help", "help"} for token in args):
                print_usage(self.route_usage_lines(name))
                return EXIT_OK
            typed_handler, parser = typed
            parsed = self.parse_options(name, args)
            if parsed.errors:
                for err in parsed.errors:
                    print(err, file=sys.stderr)
                return EXIT_USAGE
            if parsed.unknown:
                print(f"Unknown option(s): {' '.join(parsed.unknown)}", file=sys.stderr)
                spec = self._specs.get(name)
                if spec and spec.options:
                    valid = ["--help", *[o.flag for o in spec.options]]
                    print(f"Valid options: {', '.join(valid)}", file=sys.stderr)
                return EXIT_USAGE
            try:
                params = parser(parsed)
            except ValueError as exc:
                print(str(exc), file=sys.stderr)
                return EXIT_USAGE
            return typed_handler(base_url, env, params)

        route_handler = self._routes.get(name)
        if route_handler is None:
            return None
        return route_handler(base_url, env, args)

    def usage_lines(self, command_path: str, intro: str = "Usage:") -> list[str]:
        lines: list[str] = [intro]
        primary_specs: dict[str, RouteSpec] = {}
        for spec in self._specs.values():
            key = spec.primary or spec.name
            if key not in primary_specs:
                primary_specs[key] = spec
        for _, spec in sorted(primary_specs.items(), key=lambda kv: kv[0]):
            line = spec.usage.strip() if spec.usage else f"{command_path} {spec.name} [options]"
            lines.append(f"  {line}")
            if spec.summary:
                lines.append(f"    {spec.summary}")
            if spec.description:
                lines.append(f"    {spec.description}")
            if spec.options:
                lines.append("    Options:")
                for opt in spec.options:
                    opt_text = f"{opt.flag} {opt.value_name}".strip() if opt.takes_value else opt.flag
                    lines.append(f"      {opt_text:<28} {opt.description}".rstrip())
        return lines

    def route_usage_lines(self, route_name: str, intro: str = "Usage:") -> list[str]:
        spec = self._specs.get(route_name)
        if spec is None:
            return [intro]
        lines: list[str] = [intro]
        line = spec.usage.strip() if spec.usage else f"{route_name} [options]"
        lines.append(f"  {line}")
        if spec.summary:
            lines.append(f"    {spec.summary}")
        if spec.description:
            lines.append(f"    {spec.description}")
        if spec.options:
            lines.append("    Options:")
            lines.append(f"      {'--help':<28} Show this help.")
            for opt in spec.options:
                opt_text = f"{opt.flag} {opt.value_name}".strip() if opt.takes_value else opt.flag
                lines.append(f"      {opt_text:<28} {opt.description}".rstrip())
        return lines

    def parse_options(self, route_name: str, args: list[str]) -> ParsedRouteOptions:
        spec = self._specs.get(route_name)
        if spec is None:
            return ParsedRouteOptions(options={}, unknown=list(args), errors=[])

        by_flag: dict[str, OptionSpec] = {opt.flag: opt for opt in spec.options}
        values: dict[str, str | bool | None] = {}
        for declared_option in spec.options:
            values[declared_option.key or _flag_to_key(declared_option.flag)] = None if declared_option.takes_value else False

        unknown: list[str] = []
        errors: list[str] = []
        i = 0
        while i < len(args):
            token = args[i]
            matched_option = by_flag.get(token)
            if matched_option is None:
                unknown.append(token)
                i += 1
                continue
            key = matched_option.key or _flag_to_key(matched_option.flag)
            if matched_option.takes_value:
                if i + 1 >= len(args):
                    errors.append(f"Missing value for {matched_option.flag}")
                    i += 1
                    continue
                values[key] = args[i + 1]
                i += 2
                continue
            values[key] = True
            i += 1

        return ParsedRouteOptions(options=values, unknown=unknown, errors=errors)


@dataclass(frozen=True)
class OptionSpec:
    flag: str
    description: str
    takes_value: bool = False
    value_name: str = ""
    key: str = ""


@dataclass(frozen=True)
class RouteSpec:
    name: str
    summary: str
    description: str
    options: list[OptionSpec] = field(default_factory=list)
    primary: str = ""
    usage: str = ""


@dataclass(frozen=True)
class ParsedRouteOptions:
    options: dict[str, str | bool | None]
    unknown: list[str]
    errors: list[str]


def _flag_to_key(flag: str) -> str:
    return flag.strip().lstrip("-").replace("-", "_")
