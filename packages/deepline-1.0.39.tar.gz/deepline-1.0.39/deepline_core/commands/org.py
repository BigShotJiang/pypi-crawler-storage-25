from __future__ import annotations

from typing import Dict

from deepline_core.command_decorators import build_command_handler
from deepline_core.command_decorators import SubcommandRouter

from . import auth


router = SubcommandRouter()


def usage_org_computed() -> list[str]:
    lines = router.usage_lines("deepline org")
    lines.append("")
    lines.append("Tips:")
    lines.append("  Start with 'deepline org list' to see available organizations.")
    lines.append("  Then use 'deepline org switch <number>' to switch without prompts.")
    return lines


@router.route(
    "list",
    summary="List your organizations.",
    usage="deepline org list",
)
def handle_list(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    return auth.handle_orgs(base_url, env, args)


@router.route(
    "switch",
    summary="Switch to a different organization.",
    usage="deepline org switch [ORG_NUMBER]",
)
def handle_switch(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    return auth.handle_switch(base_url, env, args)


handle = build_command_handler(
    command_name="org",
    router=router,
    usage_factory=usage_org_computed,
)
