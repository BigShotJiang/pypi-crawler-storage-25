from __future__ import annotations

import sys
from dataclasses import dataclass
from typing import Dict

from deepline_core.command_common import (
    EXIT_USAGE,
    require_api_key,
)
from deepline_core.command_decorators import OptionSpec, ParsedRouteOptions, SubcommandRouter, build_command_handler

router = SubcommandRouter()


def usage_events_computed() -> list[str]:
    return router.usage_lines("deepline events")


@dataclass(frozen=True)
class ReplayParams:
    job_id: str
    delivery_id: str | None
    output_json: bool


def parse_replay(parsed: ParsedRouteOptions) -> ReplayParams:
    job_id = str(parsed.options.get("job") or "").strip()
    if not job_id:
        raise ValueError("Missing --job <ID>.")
    delivery_raw = str(parsed.options.get("delivery") or "").strip()
    return ReplayParams(
        job_id=job_id,
        delivery_id=delivery_raw or None,
        output_json=bool(parsed.options.get("json")),
    )


@router.route_typed(
    "replay",
    summary="Legacy event replay was removed in the workflow cutover.",
    usage="deepline events replay --job <ID> [--delivery <ID>] [--json]",
    options=[
        OptionSpec("--job", "Cloud job id.", takes_value=True, value_name="ID", key="job"),
        OptionSpec("--delivery", "Specific delivery id to replay.", takes_value=True, value_name="ID", key="delivery"),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=parse_replay,
)
def handle_replay(base_url: str, env: Dict[str, str], params: ReplayParams) -> int:
    missing = require_api_key(env)
    if missing is not None:
        return missing
    _ = base_url
    message = "Legacy event replay was removed in hard_cutover. Use workflow runs/dispatches instead."
    if params.output_json:
        print(f'{{"error":"{message}","migration_mode":"hard_cutover"}}')
        return EXIT_USAGE
    print(message, file=sys.stderr)
    return EXIT_USAGE


handle = build_command_handler(
    command_name="events",
    router=router,
    usage_factory=usage_events_computed,
)
