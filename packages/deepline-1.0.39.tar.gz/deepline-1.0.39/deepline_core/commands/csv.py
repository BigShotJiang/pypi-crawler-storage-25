from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict
from urllib.parse import parse_qsl, quote, urlencode, urlparse, urlunparse

from deepline_core.command_decorators import OptionSpec, SubcommandRouter
from deepline_core.command_decorators import build_command_handler
from deepline_core.browser import open_url_in_browser
from deepline_core.command_common import EXIT_OK, EXIT_SERVER, EXIT_USAGE
from deepline_core.failure_reporting import read_log_tail, set_cli_failure_context
from deepline_core import dataset as _dataset
from deepline_core.http import http_request
from deepline_core.playground_helpers import (
    ensure_runtime_playground as _ensure_runtime_playground,
    ensure_local_playground_backend as _ensure_local_playground_backend,
    compact_text as _compact_text,
    env_dir as _env_dir,
    playground_api_request as _playground_api_request,
    playground_default_api as _playground_default_api,
    playground_read_state as _playground_read_state,
    playground_write_state as _playground_write_state,
    read_csv_window as _read_csv_window,
    terminate_pid as _terminate_pid,
)

router = SubcommandRouter()


def _record_render_failure(
    *,
    failure_code: str,
    failure_stage: str,
    failure_message: str,
    log_path: str | None = None,
) -> None:
    tail = read_log_tail(log_path) if log_path else ""
    set_cli_failure_context(
        failure_code=failure_code,
        failure_stage=failure_stage,
        failure_message=failure_message,
        log_source=os.path.basename(log_path) if log_path else None,
        log_tail=tail or None,
    )

_RENDER_PROXY_BOOTSTRAP = r"""
import http.client
import http.server
import os
import posixpath
import sys
from pathlib import Path
from urllib.parse import urlsplit

dist_dir = Path(sys.argv[1]).resolve()
host = sys.argv[2]
port = int(sys.argv[3])
api_target = (sys.argv[4] or "http://127.0.0.1:4173").strip()
if "://" not in api_target:
    api_target = f"http://{api_target}"
parsed_api = urlsplit(api_target)
api_host = parsed_api.hostname or "127.0.0.1"
api_port = parsed_api.port or (443 if parsed_api.scheme == "https" else 4173)
api_scheme = parsed_api.scheme or "http"
api_base_path = (parsed_api.path or "").rstrip("/")
HOP_BY_HOP_HEADERS = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailers", "transfer-encoding", "upgrade",
}
dist_real = dist_dir.resolve()

class RenderRequestHandler(http.server.SimpleHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(dist_real), **kwargs)

    def _is_api_request(self, path):
        return path == "/events" or path.startswith("/api/")

    def _target_path(self, source_path, query):
        target_path = source_path
        if api_base_path:
            if target_path.startswith("/"):
                target_path = f"{api_base_path}{target_path}"
            else:
                target_path = f"{api_base_path}/{target_path}"
        if query:
            target_path = f"{target_path}?{query}"
        return target_path

    def _request_body(self):
        content_length = self.headers.get("Content-Length")
        if content_length and content_length.isdigit():
            length = int(content_length)
            if length > 0:
                return self.rfile.read(length)
        return None

    def _proxy(self):
        parsed = urlsplit(self.path)
        target_path = self._target_path(parsed.path, parsed.query)
        headers = {}
        for key, value in self.headers.items():
            lower = key.lower()
            if lower == "host" or lower in HOP_BY_HOP_HEADERS:
                continue
            headers[key] = value
        body = self._request_body()
        conn_cls = http.client.HTTPSConnection if api_scheme == "https" else http.client.HTTPConnection
        connection = conn_cls(api_host, api_port, timeout=10)
        try:
            connection.request(self.command, target_path, body=body, headers=headers)
            upstream = connection.getresponse()
            self.send_response(upstream.status, upstream.reason)
            upstream_headers = upstream.getheaders()
            content_type = ""
            has_content_length = False
            for key, value in upstream_headers:
                lower = key.lower()
                if lower == "content-type":
                    content_type = (value or "").lower()
                if lower == "content-length":
                    has_content_length = True
            is_event_stream = content_type.startswith("text/event-stream")
            for key, value in upstream_headers:
                if key.lower() in HOP_BY_HOP_HEADERS:
                    continue
                self.send_header(key, value)
            if not is_event_stream and not has_content_length:
                self.send_header("Connection", "close")
                self.close_connection = True
            self.end_headers()
            while True:
                chunk = upstream.read(8192)
                if not chunk:
                    break
                self.wfile.write(chunk)
        finally:
            connection.close()

    def _serve_spa(self):
        parsed = urlsplit(self.path)
        request_path = parsed.path or "/"
        if request_path == "/":
            self.path = "/index.html"
            super().do_GET()
            return
        # Use posixpath.normpath to keep forward slashes on Windows;
        # os.path.normpath converts / to \ which breaks URL path handling
        # in SimpleHTTPRequestHandler.
        candidate = posixpath.normpath(request_path.lstrip("/"))
        if candidate.startswith("..") or candidate.startswith("/"):
            self.send_error(403)
            return
        # Use os.path for local filesystem resolution (needs native separators)
        local_candidate = candidate.replace("/", os.sep) if os.sep != "/" else candidate
        local_path = (dist_real / local_candidate).resolve()
        if not str(local_path).startswith(str(dist_real)):
            self.send_error(403)
            return
        if local_path.is_dir():
            index_path = local_path / "index.html"
            if index_path.is_file():
                self.path = f"/{candidate}/index.html"
                super().do_GET()
                return
            self.send_error(404)
            return
        if local_path.is_file() and "." in local_path.name:
            self.path = f"/{candidate}"
            super().do_GET()
            return
        root_index = dist_real / "index.html"
        if root_index.is_file():
            self.path = "/index.html"
            super().do_GET()
            return
        self.send_error(404)

    def do_GET(self):
        parsed = urlsplit(self.path)
        if self._is_api_request(parsed.path):
            self._proxy()
            return
        self._serve_spa()

    def do_HEAD(self):
        parsed = urlsplit(self.path)
        if self._is_api_request(parsed.path):
            self._proxy()
            return
        super().do_HEAD()

    def do_POST(self):
        parsed = urlsplit(self.path)
        if self._is_api_request(parsed.path):
            self._proxy()
            return
        self.send_error(405)

    def do_OPTIONS(self):
        parsed = urlsplit(self.path)
        if self._is_api_request(parsed.path):
            self._proxy()
            return
        self.send_error(405)

    def do_PUT(self):
        parsed = urlsplit(self.path)
        if self._is_api_request(parsed.path):
            self._proxy()
            return
        self.send_error(405)

    def do_DELETE(self):
        parsed = urlsplit(self.path)
        if self._is_api_request(parsed.path):
            self._proxy()
            return
        self.send_error(405)

if not dist_real.is_dir():
    raise SystemExit(f"Missing dist directory: {dist_real}")
with http.server.ThreadingHTTPServer((host, port), RenderRequestHandler) as server:
    server.serve_forever()
"""


def _url_with_csv_param(base_url: str, csv_path: str) -> str:
    raw = str(base_url or "").strip()
    csv = str(csv_path or "").strip()
    if not raw or not csv:
        return raw
    try:
        parsed = urlparse(raw)
        query = dict(parse_qsl(parsed.query, keep_blank_values=True))
        encoded_csv = quote(csv, safe="")
        current_path = str(parsed.path or "").rstrip("/")
        query.pop("csv", None)
        query["view"] = "onboard"
        # Include session_id so the playground connects to the correct session.
        if "session_id" not in query:
            from deepline_core.commands.session import _resolve_cli_session_id
            query["session_id"] = _resolve_cli_session_id()
        rebuilt = parsed._replace(
            path=f"{current_path}/data/{encoded_csv}" if current_path else f"/data/{encoded_csv}",
            query=urlencode(query),
        )
        return urlunparse(rebuilt)
    except Exception:
        return raw


def _browser_target_url_for_render(display_url: str, state: Dict[str, Any] | None = None) -> str:
    """
    Keep render hosted on 4174, but open/focus the backend Session UI origin.
    This avoids switching users to the render proxy origin when --open is used.
    """
    target = str(display_url or "").strip()
    if not target:
        return target
    current_state = state if isinstance(state, dict) else _playground_read_state()
    backend_url = str(current_state.get("backend_api_url") or "").strip()
    if not backend_url:
        return target
    try:
        parsed_target = urlparse(target)
        parsed_backend = urlparse(backend_url)
        query = dict(parse_qsl(parsed_target.query, keep_blank_values=True))
        merged = parsed_backend._replace(
            path=parsed_target.path or parsed_backend.path,
            query=urlencode(query),
        )
        return urlunparse(merged)
    except Exception:
        return target


def _normalize_api_url(raw: str, fallback: str = "http://127.0.0.1:4173") -> str:
    value = str(raw or "").strip()
    if not value:
        return fallback
    if "://" in value:
        return value
    if value.startswith(":"):
        value = value[1:]
    if value.isdigit():
        return f"http://127.0.0.1:{value}"
    return f"http://{value}"


def _render_ui_ready(url: str, timeout_s: int = 2) -> bool:
    try:
        status, _ = http_request("GET", url, None, None, timeout=timeout_s)
    except RuntimeError:
        return False
    return status in (200, 404)


def _csv_show_render(
    snapshot: Dict[str, Any],
    window: Dict[str, Any],
    fmt: str,
    verbose: bool,
    summary: bool,
    fallback_row_start: int = 0,
    selected_columns: list[str] | None = None,
) -> str:
    def lift_common_ai_fields(value: Any) -> Any:
        if not isinstance(value, dict):
            return value
        normalized = dict(value)
        nested_candidates = []
        nested_result = normalized.get("result")
        if isinstance(nested_result, dict):
            nested_candidates.append(nested_result)
        nested_data = normalized.get("data")
        if isinstance(nested_data, dict):
            nested_candidates.append(nested_data)
        for nested in nested_candidates:
            for key in ("output", "extracted_json", "extractedJson"):
                if key not in normalized and key in nested:
                    normalized[key] = nested.get(key)
        return normalized

    def parse_cell(value: Any) -> Any:
        if not isinstance(value, str):
            return value
        text = value.strip()
        if not text:
            return ""
        if text[0] in "{[":
            try:
                return lift_common_ai_fields(json.loads(text))
            except Exception:
                return value
        return value

    def normalize_column_name(raw: Any, fallback: str) -> str:
        text = str(raw or "").strip()
        if not text:
            return fallback
        parsed = _dataset.parse_display_name(text)
        return parsed if parsed else fallback

    def is_block_column(col: Any) -> bool:
        return isinstance(col, dict) and bool(col.get("is_block"))

    def compact_scalar_text(text: Any, max_len: int = 120) -> str:
        value = " ".join(str(text).split())
        if len(value) <= max_len:
            return value
        return value[: max_len - 3] + "..."

    def is_empty_like(value: Any) -> bool:
        return value in (None, "", [], {})

    def compact_cell(value: Any, depth: int = 0) -> Any:
        if depth > 5:
            return compact_scalar_text(str(value))
        parsed = parse_cell(value)
        if parsed is None:
            return ""
        if isinstance(parsed, (int, float, bool)):
            return parsed
        if isinstance(parsed, str):
            return compact_scalar_text(parsed)
        if isinstance(parsed, list):
            if not parsed:
                return ""
            if all(isinstance(item, (str, int, float, bool)) for item in parsed[:3]):
                return compact_scalar_text(" | ".join(str(item) for item in parsed[:3]))
            first_compact = compact_cell(parsed[0], depth + 1)
            if first_compact not in (None, "", "{}", "[]"):
                suffix = f" (+{len(parsed) - 1} more)" if len(parsed) > 1 else ""
                return compact_scalar_text(f"{first_compact}{suffix}", max_len=160)
            return f"[{len(parsed)} items]"
        if isinstance(parsed, dict):
            for key in ("matched_result", "output"):
                if key in parsed and not is_empty_like(parsed[key]):
                    return compact_cell(parsed[key], depth + 1)
            for key in ("result", "data", "response", "body"):
                nested = parsed.get(key)
                if isinstance(nested, (dict, list)) and nested is not parsed and not is_empty_like(nested):
                    nested_compact = compact_cell(nested, depth + 1)
                    if nested_compact not in (None, "", "{}", "[]"):
                        return nested_compact
            preferred = [
                "output",
                "email",
                "business_email",
                "work_email",
                "primary_email",
                "professional_email",
                "full_name",
                "name",
                "first_name",
                "last_name",
                "title",
                "company_name",
                "domain",
                "linkedin_url",
                "status",
            ]
            parts: list[str] = []
            for key in preferred:
                if key in parsed and not is_empty_like(parsed[key]):
                    parts.append(f"{key}={compact_cell(parsed[key], depth + 1)}")
                if len(parts) >= 4:
                    break
            if parts:
                return compact_scalar_text(" | ".join(parts), max_len=160)
            fallback_parts: list[str] = []
            for key, nested in parsed.items():
                key_text = str(key).strip()
                if key_text in {"__dl", "meta", "metadata", "matched_result"}:
                    continue
                if is_empty_like(nested):
                    continue
                compact_nested = compact_cell(nested, depth + 1)
                if compact_nested in (None, "", "{}", "[]"):
                    continue
                fallback_parts.append(f"{key_text}={compact_nested}")
                if len(fallback_parts) >= 3:
                    break
            if fallback_parts:
                return compact_scalar_text(" | ".join(fallback_parts), max_len=160)
            keys = [str(key) for key in parsed.keys() if str(key) not in {"__dl", "meta", "metadata"}][:3]
            if keys:
                return "{" + ", ".join(keys) + "}"
            return "{}"
        return compact_scalar_text(str(parsed))

    def summarize_sample_value(value: Any, depth: int = 0) -> Any:
        parsed = parse_cell(value)
        if parsed is None:
            return ""
        if isinstance(parsed, (int, float, bool)):
            return parsed
        if isinstance(parsed, str):
            return compact_scalar_text(parsed, max_len=200)
        if depth >= 3:
            if isinstance(parsed, list):
                return []
            if isinstance(parsed, dict):
                return {}
            return compact_scalar_text(str(parsed), max_len=200)
        if isinstance(parsed, list):
            return [summarize_sample_value(item, depth + 1) for item in parsed[:3]]
        if isinstance(parsed, dict):
            sample_obj: Dict[str, Any] = {}
            kept = 0
            for key, nested in parsed.items():
                key_text = str(key).strip()
                if key_text in {"__dl", "meta", "metadata"}:
                    continue
                if is_empty_like(nested):
                    continue
                sample_obj[key_text] = summarize_sample_value(nested, depth + 1)
                kept += 1
                if kept >= 6:
                    break
            return sample_obj
        return compact_scalar_text(str(parsed), max_len=200)

    def cell_value(value: Any, use_verbose: bool) -> Any:
        if use_verbose:
            return parse_cell(value)
        return compact_cell(value)

    def summary_value_type(value: Any) -> str:
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "boolean"
        if isinstance(value, int):
            return "integer"
        if isinstance(value, float):
            return "number"
        if isinstance(value, list):
            return "array"
        if isinstance(value, dict):
            return "object"
        return "string"

    def csv_safe(value: Any) -> str:
        if value is None or value == "":
            return '""'
        s = str(value)
        return '"' + s.replace('"', '""') + '"'

    columns = snapshot.get("columns") if isinstance(snapshot, dict) else []
    if not isinstance(columns, list):
        columns = []
    waterfalls = snapshot.get("waterfalls") if isinstance(snapshot, dict) else []
    if not isinstance(waterfalls, list):
        waterfalls = []
    row_count = int(snapshot.get("rowCount") or 0) if isinstance(snapshot, dict) else 0
    csv_name = (snapshot.get("csvName") or "(unknown.csv)") if isinstance(snapshot, dict) else "(unknown.csv)"
    metadata = snapshot.get("_metadata") if isinstance(snapshot, dict) else None

    rows_raw = window.get("rows") if isinstance(window, dict) else []
    if not isinstance(rows_raw, list):
        rows_raw = []
    misses = window.get("misses") if isinstance(window, dict) else []
    if not isinstance(misses, list):
        misses = []
    full_results_raw = window.get("full_results") if isinstance(window, dict) else []
    if not isinstance(full_results_raw, list):
        full_results_raw = []
    row_start = int(window.get("rowStart") or fallback_row_start) if isinstance(window, dict) else fallback_row_start

    rows: list[list[Any]] = []
    for row in rows_raw:
        if isinstance(row, list):
            rows.append(row)
        elif isinstance(row, dict):
            values = row.get("values")
            rows.append(values if isinstance(values, list) else [])

    full_result_by_cell: Dict[tuple[int, int], Any] = {}
    for full_result in full_results_raw:
        if not isinstance(full_result, dict):
            continue
        row_idx = full_result.get("row")
        col_idx = full_result.get("col")
        if row_idx is None or col_idx is None:
            continue
        try:
            key = (int(row_idx), int(col_idx))
        except Exception:
            continue
        full_result_by_cell[key] = full_result.get("value")

    waterfall_names: set[str] = set()
    waterfall_step_indexes: set[int] = set()
    for wf in waterfalls:
        if isinstance(wf, dict):
            name = str(wf.get("display_name") or wf.get("name") or wf.get("group_id") or wf.get("id") or "").strip()
            if name:
                waterfall_names.add(name)
            for step in (wf.get("steps") or []):
                if isinstance(step, dict) and step.get("col_index") is not None:
                    try:
                        waterfall_step_indexes.add(int(step["col_index"]))
                    except Exception:
                        pass

    col_names_by_index: Dict[int, str] = {}
    for i, col in enumerate(columns):
        if isinstance(col, dict):
            col_names_by_index[i] = normalize_column_name(col.get("display_name") or col.get("header_text") or f"col_{i}", f"col_{i}")
        else:
            col_names_by_index[i] = f"col_{i}"

    input_cols: list[tuple[int, str]] = []
    step_cols: list[tuple[int, str]] = []
    resolver_cols: list[tuple[int, str]] = []
    other_cols: list[tuple[int, str]] = []

    for i, col in enumerate(columns):
        if not isinstance(col, dict):
            continue
        raw_name = col.get("display_name") or col.get("header_text") or f"col_{i}"
        name = normalize_column_name(raw_name, f"col_{i}")
        if name == "_metadata" or name.startswith("__dl_"):
            continue
        if name in waterfall_names:
            resolver_cols.append((i, name))
        elif i in waterfall_step_indexes:
            step_cols.append((i, name))
        elif is_block_column(col):
            raw_text = str(raw_name or "").strip()
            is_noisy = False
            if raw_text.startswith("{") and raw_text.endswith("}"):
                try:
                    parsed_header = json.loads(raw_text)
                    if isinstance(parsed_header, dict) and any(
                        k in parsed_header for k in ("payload", "tool_id", "operation", "result_path", "provider")
                    ):
                        is_noisy = True
                except Exception:
                    pass
            if is_noisy:
                step_cols.append((i, name))
            else:
                other_cols.append((i, name))
        else:
            input_cols.append((i, name))

    classified_indexes = set(idx for idx, _ in input_cols + step_cols + resolver_cols + other_cols)
    for i, col in enumerate(columns):
        if not isinstance(col, dict) or i in classified_indexes:
            continue
        raw_name = col.get("display_name") or col.get("header_text") or f"col_{i}"
        name = normalize_column_name(raw_name, f"col_{i}")
        if name == "_metadata" or name.startswith("__dl_"):
            continue
        other_cols.append((i, name))

    if verbose:
        visible_cols = input_cols + step_cols + resolver_cols + other_cols
    else:
        visible_cols = input_cols + resolver_cols + other_cols

    if selected_columns:
        requested: list[str] = []
        for raw in selected_columns:
            name = str(raw or "").strip()
            if name and name not in requested:
                requested.append(name)
        if not requested:
            raise ValueError("Invalid --columns value: provide at least one column name.")
        exact: Dict[str, tuple[int, str]] = {}
        folded: Dict[str, tuple[int, str]] = {}
        for idx, name in visible_cols:
            if name not in exact:
                exact[name] = (idx, name)
            lowered = name.lower()
            if lowered not in folded:
                folded[lowered] = (idx, name)
        filtered_cols: list[tuple[int, str]] = []
        unknown: list[str] = []
        for requested_name in requested:
            found = exact.get(requested_name) or folded.get(requested_name.lower())
            if not found:
                unknown.append(requested_name)
                continue
            if found not in filtered_cols:
                filtered_cols.append(found)
        if unknown:
            available = ", ".join(name for _, name in visible_cols) or "(none)"
            missing = ", ".join(unknown)
            raise ValueError(f"Unknown --columns value(s): {missing}. Available columns: {available}")
        visible_cols = filtered_cols

    miss_by_step: Dict[str, Dict[str, int]] = {}
    miss_detail_by_step: Dict[str, Dict[str, Dict[str, Any]]] = {}

    def miss_cell_value(abs_row: int, col_idx: int) -> Any:
        row_offset = abs_row - row_start
        if 0 <= row_offset < len(rows):
            row = rows[row_offset]
            if isinstance(row, list) and 0 <= col_idx < len(row):
                return row[col_idx]
        return full_result_by_cell.get((abs_row, col_idx))

    def extract_miss_detail(value: Any, reason: str, depth: int = 0) -> str:
        if depth > 5:
            return ""
        if value is None:
            return ""
        if isinstance(value, str):
            text = value.strip()
            if not text:
                return ""
            if text[0] in "{[":
                try:
                    parsed = json.loads(text)
                except Exception:
                    parsed = None
                if parsed is not None and parsed is not value:
                    nested_detail = extract_miss_detail(parsed, reason, depth + 1)
                    return nested_detail
            text = text.replace("\\r", " ").replace("\\n", " ")
            lowered = text.lower()
            boring = {
                str(reason or "").strip().lower(),
                "unknown",
                "tool_execution_error",
                "no matched result",
                "no value found",
            }
            if lowered in boring:
                return ""
            return _compact_text(text, 240)
        if isinstance(value, (int, float, bool)):
            return str(value)
        if isinstance(value, list):
            for item in value[:3]:
                nested_detail = extract_miss_detail(item, reason, depth + 1)
                if nested_detail:
                    return nested_detail
            return ""
        if isinstance(value, dict):
            preferred_keys = (
                "error",
                "message",
                "detail",
                "details",
                "reason",
                "miss_reason",
                "failure_reason",
                "filter_error",
                "status_text",
                "statusText",
                "email_status",
                "status",
                "result",
            )
            for key in preferred_keys:
                if key not in value:
                    continue
                nested_detail = extract_miss_detail(value.get(key), reason, depth + 1)
                if nested_detail:
                    return nested_detail
            for key in ("data", "response", "body"):
                if key not in value:
                    continue
                nested_detail = extract_miss_detail(value.get(key), reason, depth + 1)
                if nested_detail:
                    return nested_detail
            for key, nested in value.items():
                key_text = str(key).strip().lower()
                if key_text in {"__dl", "matched_result", "meta", "metadata"}:
                    continue
                nested_detail = extract_miss_detail(nested, reason, depth + 1)
                if nested_detail:
                    return nested_detail
            return ""
        return _compact_text(str(value), 240)

    for miss in misses:
        if not isinstance(miss, dict):
            continue
        col_idx = miss.get("col")
        reason = str(miss.get("reason") or "unknown").strip()
        row_idx = miss.get("row")
        if col_idx is None:
            continue
        step_name = col_names_by_index.get(col_idx, f"col_{col_idx}")
        if step_name not in miss_by_step:
            miss_by_step[step_name] = {}
        miss_by_step[step_name][reason] = miss_by_step[step_name].get(reason, 0) + 1
        if row_idx is None:
            continue
        try:
            abs_row = int(row_idx)
            abs_col = int(col_idx)
        except Exception:
            continue
        detail = extract_miss_detail(miss_cell_value(abs_row, abs_col), reason)
        if not detail:
            continue
        step_entry = miss_detail_by_step.setdefault(step_name, {})
        reason_entry = step_entry.setdefault(reason, {"count": 0, "examples": []})
        reason_entry["count"] = int(reason_entry.get("count") or 0) + 1
        examples = reason_entry.setdefault("examples", [])
        if (
            isinstance(examples, list)
            and len(examples) < 3
            and not any(
                isinstance(example, dict)
                and int(example.get("row") or -1) == abs_row
                and str(example.get("detail") or "") == detail
                for example in examples
            )
        ):
            examples.append({"row": abs_row, "detail": detail})

    if summary:
        summary_cols = input_cols + step_cols + resolver_cols + other_cols
        col_stats: Dict[str, Dict[str, Any]] = {}
        miss_cells: set[tuple[int, int]] = set()
        for miss in misses:
            if isinstance(miss, dict) and miss.get("row") is not None and miss.get("col") is not None:
                miss_cells.add((int(miss["row"]), int(miss["col"])))

        def pct(n: int, t: int) -> str:
            return f"{n}/{t} ({round(100 * n / t)}%)" if t > 0 else "0/0 (0%)"

        def cnt_pct(n: int, t: int) -> str:
            return f"{n} ({round(100 * n / t)}%)" if t > 0 else "0 (0%)"

        for idx, name in summary_cols:
            non_empty = 0
            empty = 0
            value_counts: Dict[str, int] = {}
            sample_value: Any = None
            sample_type: str | None = None
            for row_offset, row in enumerate(rows):
                abs_row = row_start + row_offset
                if (abs_row, idx) in miss_cells:
                    empty += 1
                    continue
                cell = row[idx] if idx < len(row) else ""
                val = compact_cell(cell)
                val_str = str(val) if val not in (None, "", 0, False) else ""
                if val_str:
                    non_empty += 1
                    value_counts[val_str] = value_counts.get(val_str, 0) + 1
                    if sample_value is None:
                        sample_value = summarize_sample_value(cell)
                        sample_type = summary_value_type(parse_cell(cell))
                else:
                    empty += 1
            total = non_empty + empty
            stat: Dict[str, Any] = {"non_empty": pct(non_empty, total), "unique": len(value_counts)}
            if sample_value is not None and sample_type is not None:
                stat["sample_value"] = sample_value
                stat["sample_type"] = sample_type
            if value_counts and len(value_counts) < non_empty:
                top = sorted(value_counts.items(), key=lambda x: -x[1])[:3]
                top_keys = set(k for k, _ in top)
                other_count = sum(v for k, v in value_counts.items() if k not in top_keys)
                tv: Dict[str, str] = {k: cnt_pct(v, total) for k, v in top}
                if other_count > 0:
                    tv["(other)"] = cnt_pct(other_count, total)
                if empty > 0:
                    tv["(null)"] = cnt_pct(empty, total)
                stat["top_values"] = tv
            elif empty > 0 and non_empty > 0:
                stat["top_values"] = {"(null)": cnt_pct(empty, total)}
            col_stats[name] = stat
        total = row_count if row_count > 0 else len(rows)
        result: Dict[str, Any] = {"total_rows": total, "columnStats": col_stats}
        if miss_by_step:
            result["miss_reasons"] = miss_by_step
        if miss_detail_by_step:
            result["miss_details"] = miss_detail_by_step
        return json.dumps(result, indent=2)

    if fmt == "json":
        rows_out: list[Dict[str, Any]] = []
        for offset, row in enumerate(rows):
            item: Dict[str, Any] = {"__row": row_start + offset}
            for idx, name in visible_cols:
                cell = row[idx] if idx < len(row) else ""
                item[name] = parse_cell(cell)
            rows_out.append(item)
        payload: Dict[str, Any] = {"rows": rows_out}
        if metadata is not None:
            payload["_metadata"] = metadata
        return json.dumps(payload, indent=2)

    if fmt == "csv":
        out_lines: list[str] = []
        col_names = [name for _, name in visible_cols]
        out_lines.append(",".join(csv_safe(n) for n in col_names))
        for row in rows:
            vals: list[str] = []
            for idx, _name in visible_cols:
                cell = row[idx] if idx < len(row) else ""
                val = compact_cell(cell)
                vals.append(csv_safe(str(val) if val not in (None,) else ""))
            out_lines.append(",".join(vals))
        return "\n".join(out_lines)

    if fmt == "table":
        table_cap = 40
        col_names = [name for _, name in visible_cols]
        cell_grid: list[list[str]] = []
        for row in rows:
            cells: list[str] = []
            for idx, _name in visible_cols:
                cell = row[idx] if idx < len(row) else ""
                val = compact_cell(cell)
                s = str(val) if val not in (None,) else ""
                if len(s) > table_cap:
                    s = s[: table_cap - 3] + "..."
                cells.append(s)
            cell_grid.append(cells)
        widths = [min(len(n), table_cap) for n in col_names]
        for cells in cell_grid:
            for j, c in enumerate(cells):
                if j < len(widths):
                    widths[j] = max(widths[j], min(len(c), table_cap))
        lines = []
        header = " | ".join(n.ljust(widths[j])[: widths[j]] for j, n in enumerate(col_names))
        lines.append(header)
        lines.append("-+-".join("-" * w for w in widths))
        for cells in cell_grid:
            line = " | ".join((cells[j] if j < len(cells) else "").ljust(widths[j])[: widths[j]] for j in range(len(col_names)))
            lines.append(line)
        shown = len(cell_grid)
        total = row_count if row_count > 0 else shown
        lines.append("")
        lines.append(f"{csv_name} ({total} rows total, showing {shown})")
        return "\n".join(lines)

    return json.dumps({"error": f"Unknown format: {fmt}"})


def usage_csv_computed() -> list[str]:
    return [
        "Usage:",
        "  deepline csv render start [--port PORT] [--csv /path/to/file.csv] [--open]",
        "  deepline csv render status [--json]",
        "  deepline csv render stop [--json]",
        "  deepline csv --execute_cells --csv /path/to/file.csv --rows START:END --cols START:END [--wait] [--wait-timeout SECONDS] [--immediate] [--dry-run] [--mock] [--json]",
        "  deepline csv --stop-column --csv /path/to/file.csv --col N [--json]",
        "  deepline csv show --csv /path/to/file.csv [--format csv|json|table] [--verbose] [--summary] [--rows START:END] [--columns NAME1,NAME2]",
    ]


def _csv_unknown(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    routed = router.dispatch("run", base_url, env, args)
    if routed is not None:
        return routed
    return EXIT_USAGE


@router.route(
    "run",
    summary="Run csv subcommands and compatibility flag flows.",
    options=[
        OptionSpec("render", "render start|status|stop"),
        OptionSpec("show", "show --csv PATH [--format csv|json|table]"),
        OptionSpec("--execute_cells", "execute csv cells with --csv/--rows/--cols"),
        OptionSpec("--stop-column", "stop a running column with --csv/--col"),
        OptionSpec("--rows", "Row range start:end", takes_value=True, value_name="RANGE"),
        OptionSpec("--columns", "Comma-separated column names for csv show", takes_value=True, value_name="NAMES"),
        OptionSpec("--cols", "Column range start:end", takes_value=True, value_name="RANGE"),
        OptionSpec("--json", "Emit JSON output where supported"),
    ],
)
def cmd_csv(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    if args[0] == "render":
        action = args[1] if len(args) > 1 and not args[1].startswith("-") else "start"
        if action == "start":
            try:
                runtime_pg_dir = _ensure_runtime_playground(base_url)
            except RuntimeError as exc:
                print(str(exc), file=sys.stderr)
                return EXIT_SERVER
            port = "4174"
            open_flag = "--open" in args
            csv_path = ""
            api_target = _normalize_api_url(os.environ.get("DEEPLINE_PLAYGROUND_API_URL", "4173"))
            i = 2 if len(args) > 1 and args[1] == "start" else 1
            while i < len(args):
                if args[i] == "--port" and i + 1 < len(args):
                    port = str(args[i + 1]).lstrip(":")
                    i += 2
                    continue
                if args[i] == "--csv" and i + 1 < len(args):
                    csv_path = str(args[i + 1])
                    i += 2
                    continue
                if args[i] == "--open":
                    i += 1
                    continue
                if args[i].startswith("-"):
                    print(f"Unknown option: {args[i]}", file=sys.stderr)
                    return EXIT_USAGE
                i += 1
            if csv_path and not Path(csv_path).is_file():
                print(f"CSV not found: {csv_path}", file=sys.stderr)
                return EXIT_USAGE
            render_url = f"http://127.0.0.1:{port}"
            display_url = _url_with_csv_param(render_url, csv_path)
            state = _playground_read_state()
            existing_pid = state.get("render_pid")
            if isinstance(existing_pid, int):
                try:
                    os.kill(existing_pid, 0)
                    if not _render_ui_ready(str(state.get("render_url") or render_url), timeout_s=1):
                        raise RuntimeError("render not healthy")
                    print("Playground render is already running; reusing current process.")
                    existing_url = str(state.get("render_url") or render_url)
                    existing_display_url = _url_with_csv_param(existing_url, csv_path)
                    print(f"Render URL: {existing_display_url}")
                    if open_flag:
                        try:
                            open_url_in_browser(_browser_target_url_for_render(existing_display_url, state))
                        except Exception:
                            pass
                    return EXIT_OK
                except Exception:
                    pass
            dist_dir = runtime_pg_dir / "dist"
            if not dist_dir.is_dir():
                print("Missing playground dist/. This CLI expects packaged prebuilt assets.", file=sys.stderr)
                _record_render_failure(
                    failure_code="playground_render_dist_missing",
                    failure_stage="render_runtime_validation",
                    failure_message="Missing playground dist/. This CLI expects packaged prebuilt assets.",
                )
                return EXIT_SERVER
            state_dir = _env_dir()
            state_dir.mkdir(parents=True, exist_ok=True)
            log_path = state_dir / "playground-render-python.log"
            cmd = [
                sys.executable,
                "-c",
                _RENDER_PROXY_BOOTSTRAP,
                str(dist_dir),
                "127.0.0.1",
                str(port),
                api_target,
            ]
            with open(log_path, "ab") as log:
                proc = subprocess.Popen(
                    cmd,
                    stdin=subprocess.DEVNULL,
                    stdout=log,
                    stderr=log,
                    start_new_session=True,
                    close_fds=True,
                    cwd=str(runtime_pg_dir),
                )
            started = False
            start_deadline = time.time() + 25
            while time.time() < start_deadline:
                if _render_ui_ready(render_url):
                    started = True
                    break
                if proc.poll() is not None:
                    break
                time.sleep(0.2)
            if not started:
                print(f"Timed out waiting for playground render to start. Check logs at {log_path}", file=sys.stderr)
                _record_render_failure(
                    failure_code="playground_render_start_timeout",
                    failure_stage="render_startup",
                    failure_message="Timed out waiting for playground render to start.",
                    log_path=str(log_path),
                )
                return EXIT_SERVER
            state.update(
                {
                    "render_pid": proc.pid,
                    "render_url": display_url,
                    "render_log_path": str(log_path),
                    "render_started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    "render_health_status": "unknown",
                    "render_health_checked_at": "",
                }
            )
            _playground_write_state(state)
            print("Playground render is running.")
            print(f"Render PID: {proc.pid}")
            print(f"Render URL: {display_url}")
            if open_flag:
                try:
                    open_url_in_browser(_browser_target_url_for_render(display_url, state))
                except Exception:
                    pass
            return EXIT_OK
        if action == "status":
            as_json = "--json" in args
            state = _playground_read_state()
            pid = state.get("render_pid")
            url = str(state.get("render_url") or "")
            alive = False
            if isinstance(pid, int):
                try:
                    os.kill(pid, 0)
                    alive = True
                except Exception:
                    alive = False
            health = "unknown"
            if alive and url:
                hs, _ = http_request("GET", url, None, None, timeout=2)
                health = "healthy" if hs in (200, 404) else "unhealthy"
            status = "running" if alive and health == "healthy" else ("unhealthy" if alive else "stopped")
            if as_json:
                print(
                    json.dumps(
                        {
                            "status": status,
                            "pid": pid if isinstance(pid, int) else None,
                            "process_alive": alive,
                            "url": url,
                            "log_path": state.get("render_log_path") or "",
                            "mode": state.get("render_mode") or "background",
                            "started_at": (state.get("render_started_at") or "") if isinstance(pid, int) else "",
                            "health_status": health,
                            "health_checked_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                            "stale_cleaned": True,
                        }
                    )
                )
            else:
                print(f"Render Status: {status}")
                if pid:
                    print(f"Render PID: {pid}")
                if url:
                    print(f"Render URL: {url}")
                print(f"Render Health: {health}")
            return EXIT_OK
        if action == "stop":
            as_json = "--json" in args
            state = _playground_read_state()
            pid = state.get("render_pid")
            stopped: list[int] = []
            failed: list[int] = []
            if isinstance(pid, int):
                if _terminate_pid(pid):
                    stopped.append(pid)
                else:
                    failed.append(pid)
            if stopped and not failed:
                state.pop("render_pid", None)
                state["render_health_status"] = "stopped"
                state["render_health_checked_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            _playground_write_state(state)
            if as_json:
                print(
                    json.dumps(
                        {
                            "ok": len(failed) == 0,
                            "stopped_count": len(stopped),
                            "failed_count": len(failed),
                            "stopped_pids": stopped,
                            "failed_pids": failed,
                        }
                    )
                )
                return EXIT_OK if not failed else EXIT_SERVER
            if stopped:
                print(f"Stopped playground render process(es): {' '.join(str(x) for x in stopped)}")
                return EXIT_OK
            print("No running playground render process found.")
            return EXIT_OK
        print(f"Unknown csv render action: {action}", file=sys.stderr)
        return EXIT_USAGE

    if "--execute_cells" in args:
        csv_path = ""
        rows = ""
        cols = ""
        output_json = "--json" in args
        wait = "--wait" in args
        wait_timeout = 60
        immediate = "--immediate" in args
        dry_run = "--dry-run" in args
        mock = "--mock" in args
        overwrite_existing = "--overwrite-existing" in args
        i = 0
        while i < len(args):
            if args[i] == "--csv" and i + 1 < len(args):
                csv_path = args[i + 1]
                i += 2
                continue
            if args[i] == "--rows" and i + 1 < len(args):
                rows = args[i + 1]
                i += 2
                continue
            if args[i] == "--cols" and i + 1 < len(args):
                cols = args[i + 1]
                i += 2
                continue
            if args[i] == "--wait-timeout" and i + 1 < len(args):
                try:
                    wait_timeout = int(args[i + 1])
                except Exception:
                    print("Invalid --wait-timeout value.", file=sys.stderr)
                    return EXIT_USAGE
                i += 2
                continue
            if args[i].startswith("-") and args[i] not in (
                "--execute_cells",
                "--wait",
                "--immediate",
                "--dry-run",
                "--mock",
                "--json",
                "--overwrite-existing",
            ):
                print(f"Unknown option: {args[i]}", file=sys.stderr)
                return EXIT_USAGE
            i += 1
        if not csv_path or not rows or not cols:
            print("Missing required options for --execute_cells: --csv, --rows, --cols.", file=sys.stderr)
            return EXIT_USAGE
        try:
            if ":" not in rows or ":" not in cols:
                raise ValueError("range")
            r0, r1 = [int(x) for x in rows.split(":", 1)]
            c0, c1 = [int(x) for x in cols.split(":", 1)]
            if r0 < 0 or r1 < r0 or c0 < 0 or c1 < c0:
                raise ValueError("range")
        except Exception:
            print("Invalid --rows/--cols value (expected start:end with non-negative ascending indexes).", file=sys.stderr)
            return EXIT_USAGE
        if wait_timeout < 0:
            print("Invalid --wait-timeout value.", file=sys.stderr)
            return EXIT_USAGE
        if immediate and r0 != r1:
            print("--immediate requires --row-start == --row-end.", file=sys.stderr)
            return EXIT_USAGE
        api = _playground_default_api()
        has_explicit_api = bool(os.environ.get("DEEPLINE_TEST_API_URL") or os.environ.get("DEEPLINE_PLAYGROUND_API_URL"))
        if not has_explicit_api:
            # Redirect stdout→stderr so backend status messages don't corrupt
            # structured output (e.g. csv show --format json piped to a file).
            _orig_stdout = sys.stdout
            sys.stdout = sys.stderr
            try:
                ensure_code, ensured_api = _ensure_local_playground_backend(base_url, install_mode="auto")
            finally:
                sys.stdout = _orig_stdout
            if ensure_code != EXIT_OK:
                return ensure_code
            if ensured_api:
                api = ensured_api
        responses: list[dict[str, Any]] = []
        for col in range(c0, c1 + 1):
            body = {
                "col": col,
                "row_start": r0,
                "row_end": r1,
                "wait": bool(wait),
                "wait_timeout": int(wait_timeout),
                "immediate": bool(immediate),
                "dry_run": bool(dry_run),
                "mock": bool(mock),
                "overwrite_existing": bool(overwrite_existing),
                # Also send camelCase for compatibility with mixed server versions.
                "overwriteExisting": bool(overwrite_existing),
            }
            status, resp = _playground_api_request("POST", api, "/api/run-block", body, csv_path)
            if status >= 400:
                print(f"Playground API error (status {status}) for POST /api/run-block.", file=sys.stderr)
                if resp.strip():
                    print(resp.strip(), file=sys.stderr)
                return EXIT_SERVER
            try:
                parsed = json.loads(resp or "{}")
            except Exception:
                parsed = {}
            responses.append(parsed if isinstance(parsed, dict) else {"raw": resp})
            if wait:
                wait_data = parsed.get("wait") if isinstance(parsed, dict) else {}
                jobs = wait_data.get("jobs") if isinstance(wait_data, dict) else []
                jobs = jobs if isinstance(jobs, list) else []
                failed_count = len([j for j in jobs if isinstance(j, dict) and j.get("status") == "failed"])
                canceled_count = len([j for j in jobs if isinstance(j, dict) and j.get("status") == "canceled"])
                pending = bool(wait_data.get("pending")) if isinstance(wait_data, dict) else False
                missing = wait_data.get("missing") if isinstance(wait_data, dict) else []
                missing_count = len(missing) if isinstance(missing, list) else 0
                if pending or failed_count > 0 or canceled_count > 0 or missing_count > 0:
                    print("Run-block wait did not fully complete.", file=sys.stderr)
                    if pending:
                        print("Pending jobs remain.", file=sys.stderr)
                    if failed_count > 0:
                        print(f"Failed jobs: {failed_count}", file=sys.stderr)
                    if canceled_count > 0:
                        print(f"Canceled jobs: {canceled_count}", file=sys.stderr)
                    if missing_count > 0:
                        print(f"Missing jobs: {missing_count}", file=sys.stderr)
                    if output_json:
                        print(json.dumps({"ok": False, "results": responses}))
                    return EXIT_SERVER
        if output_json:
            print(json.dumps({"ok": True, "results": responses}))
        else:
            total_jobs = 0
            total_skipped = 0
            total_skipped_existing = 0
            total_skipped_wf = 0
            for parsed in responses:
                jobs = parsed.get("jobs") if isinstance(parsed, dict) else []
                jobs = jobs if isinstance(jobs, list) else []
                skipped = parsed.get("skipped_rows") if isinstance(parsed, dict) else []
                skipped = skipped if isinstance(skipped, list) else []
                skipped_wf = parsed.get("skipped_rows_by_waterfall") if isinstance(parsed, dict) else []
                skipped_wf = skipped_wf if isinstance(skipped_wf, list) else []
                total_jobs += len(jobs)
                total_skipped_existing += len(skipped)
                total_skipped_wf += len(skipped_wf)
            total_skipped = total_skipped_existing + total_skipped_wf
            print(f"Run queued: {total_jobs} job(s).")
            print(f"Skipped rows (existing value): {total_skipped_existing}")
            print(f"Skipped rows (waterfall condition): {total_skipped_wf}")
            print(f"Skipped rows (total): {total_skipped}")
            if total_jobs == 0 and total_skipped > 0:
                print("No jobs queued because all targeted rows were skipped.")
            if wait:
                print("Wait result: completed")
        return EXIT_OK

    if "--stop-column" in args:
        csv_path = ""
        col = None
        output_json = "--json" in args
        i = 0
        while i < len(args):
            if args[i] == "--csv" and i + 1 < len(args):
                csv_path = args[i + 1]
                i += 2
                continue
            if args[i] == "--col" and i + 1 < len(args):
                try:
                    col = int(args[i + 1])
                except Exception:
                    col = None
                i += 2
                continue
            if args[i].startswith("-") and args[i] not in ("--stop-column", "--json"):
                print(f"Unknown option: {args[i]}", file=sys.stderr)
                return EXIT_USAGE
            i += 1
        if not csv_path or col is None:
            print("Missing required options for --stop-column: --csv, --col.", file=sys.stderr)
            return EXIT_USAGE
        if col < 0:
            print("Invalid --col value: expected non-negative integer.", file=sys.stderr)
            return EXIT_USAGE
        api = _playground_default_api()
        has_explicit_api = bool(os.environ.get("DEEPLINE_TEST_API_URL") or os.environ.get("DEEPLINE_PLAYGROUND_API_URL"))
        if not has_explicit_api:
            _orig_stdout = sys.stdout
            sys.stdout = sys.stderr
            try:
                ensure_code, ensured_api = _ensure_local_playground_backend(base_url, install_mode="auto")
            finally:
                sys.stdout = _orig_stdout
            if ensure_code != EXIT_OK:
                return ensure_code
            if ensured_api:
                api = ensured_api
        status, resp = _playground_api_request("POST", api, "/api/stop-column", {"col": col}, csv_path)
        if status >= 400:
            print(f"Playground API error (status {status}) for POST /api/stop-column.", file=sys.stderr)
            if resp.strip():
                print(resp.strip(), file=sys.stderr)
            return EXIT_SERVER
        if output_json:
            print(resp)
        else:
            canceled = 0
            try:
                parsed = json.loads(resp or "{}")
                canceled_raw = parsed.get("canceled") if isinstance(parsed, dict) else 0
                canceled = int(canceled_raw) if canceled_raw is not None else 0
            except Exception:
                canceled = 0
            print(f"Column {col} canceled jobs: {canceled}")
        return EXIT_OK

    if args[0] == "show":
        csv_path = ""
        show_format = "json"
        row_range = "0:19"
        show_verbose = False
        show_summary = False
        rows_explicit = False
        selected_columns: list[str] | None = None
        _show_valid_flags = ("--csv", "--format", "--rows", "--columns", "--verbose", "--summary")
        i = 1
        while i < len(args):
            if args[i] == "--csv" and i + 1 < len(args):
                csv_path = args[i + 1]
                i += 2
                continue
            if args[i] == "--format" and i + 1 < len(args):
                show_format = args[i + 1]
                i += 2
                continue
            if args[i] == "--rows" and i + 1 < len(args):
                row_range = args[i + 1]
                rows_explicit = True
                i += 2
                continue
            if args[i] == "--columns" and i + 1 < len(args):
                raw_columns = [part.strip() for part in str(args[i + 1]).split(",")]
                selected_columns = [part for part in raw_columns if part]
                i += 2
                continue
            if args[i] == "--verbose":
                show_verbose = True
                i += 1
                continue
            if args[i] == "--summary":
                show_summary = True
                i += 1
                continue
            if args[i].startswith("-"):
                print(f"Unknown option: {args[i]}", file=sys.stderr)
                print(f"Valid options: {', '.join(_show_valid_flags)}", file=sys.stderr)
                return EXIT_USAGE
            i += 1
        if not csv_path:
            print("Missing required option: --csv", file=sys.stderr)
            return EXIT_USAGE
        if selected_columns is not None and len(selected_columns) == 0:
            print("Invalid --columns value: provide at least one column name.", file=sys.stderr)
            return EXIT_USAGE
        if show_summary and not rows_explicit:
            row_range = "0:999999"
        try:
            rs, re = [int(x) for x in row_range.split(":", 1)]
            if rs < 0 or re < rs:
                raise ValueError("range")
        except Exception:
            print(f"Invalid --rows value: {row_range} (expected start:end, e.g. 0:19).", file=sys.stderr)
            return EXIT_USAGE
        if show_format not in ("json", "csv", "table"):
            print(f"Invalid --format value: {show_format} (expected csv, json, or table).", file=sys.stderr)
            return EXIT_USAGE
        api = _playground_default_api()
        has_explicit_api = bool(os.environ.get("DEEPLINE_TEST_API_URL") or os.environ.get("DEEPLINE_PLAYGROUND_API_URL"))
        if not has_explicit_api:
            _orig_stdout = sys.stdout
            sys.stdout = sys.stderr
            try:
                ensure_code, ensured_api = _ensure_local_playground_backend(base_url, install_mode="auto")
            finally:
                sys.stdout = _orig_stdout
            if ensure_code != EXIT_OK:
                return ensure_code
            if ensured_api:
                api = ensured_api
        s1, snap = _playground_api_request("GET", api, "/api/snapshot", None, csv_path)
        s2, win = _playground_api_request("GET", api, f"/api/window?row_start={rs}&row_end={re}", None, csv_path)
        if s1 >= 400 or s2 >= 400:
            if not Path(csv_path).is_file():
                print(f"File not found: {csv_path}", file=sys.stderr)
                return EXIT_SERVER
            headers, rows = _read_csv_window(csv_path, rs, re)
            _, all_rows = _read_csv_window(csv_path, 0, 999999)
            total_row_count = len(all_rows)
            snapshot_obj: Dict[str, Any] = {
                "columns": [{"display_name": h, "header_text": h, "is_block": False} for h in headers],
                "waterfalls": [],
                "rowCount": total_row_count,
                "csvName": csv_path,
            }
            window_obj: Dict[str, Any] = {
                "rowStart": rs,
                "rowEnd": re,
                "rows": rows,
                "misses": [],
            }
            try:
                print(
                    _csv_show_render(
                        snapshot_obj,
                        window_obj,
                        show_format,
                        show_verbose,
                        show_summary,
                        fallback_row_start=rs,
                        selected_columns=selected_columns,
                    )
                )
            except ValueError as exc:
                print(str(exc), file=sys.stderr)
                return EXIT_USAGE
            return EXIT_OK
        try:
            snapshot_obj = json.loads(snap)
            window_obj = json.loads(win)
            print(
                _csv_show_render(
                    snapshot_obj,
                    window_obj,
                    show_format,
                    show_verbose,
                    show_summary,
                    fallback_row_start=rs,
                    selected_columns=selected_columns,
                )
            )
            return EXIT_OK
        except ValueError as exc:
            print(str(exc), file=sys.stderr)
            return EXIT_USAGE
        except Exception:
            print(win)
            return EXIT_OK

    print("Unknown csv command", file=sys.stderr)
    return EXIT_USAGE


handle = build_command_handler(
    command_name="csv",
    router=router,
    usage_factory=usage_csv_computed,
    on_unknown=_csv_unknown,
)
