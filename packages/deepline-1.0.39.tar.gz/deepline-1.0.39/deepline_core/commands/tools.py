from __future__ import annotations

import csv
import difflib
import json
import os
import re
import sys
import time
from pathlib import Path
import urllib.parse
from typing import Any, Dict, Iterable

from deepline_core.cli_events import append_cli_event
from deepline_core.command_decorators import OptionSpec, SubcommandRouter
from deepline_core.command_decorators import build_command_handler
from deepline_core.command_common import require_api_key
from deepline_core.command_common import EXIT_AUTH, EXIT_NETWORK, EXIT_NOT_FOUND, EXIT_OK, EXIT_SERVER, EXIT_USAGE, EXIT_VALIDATION
from deepline_core.failure_reporting import set_cli_failure_context
from deepline_core.http import build_tool_execute_url, build_tool_get_url, http_request
from deepline_core.network_failures import classify_network_failure_exception
from deepline_core.tool_helpers import is_local_tool, normalize_tool_id

router = SubcommandRouter()
_PERSISTENT_DATA_DIR = Path("deepline") / "data"


def _record_tools_network_failure(exc: RuntimeError, *, stage: str) -> None:
    set_cli_failure_context(
        failure_code=classify_network_failure_exception(exc),
        failure_stage=stage,
        failure_message=str(exc),
    )


def _is_dev_cli_base_url(base_url: str) -> bool:
    parsed = urllib.parse.urlparse(str(base_url or "").strip())
    host = str(parsed.hostname or "").strip().lower()
    return host in {"localhost", "127.0.0.1", "0.0.0.0", "::1"}


def _ensure_persistent_data_dir() -> Path:
    data_dir = _PERSISTENT_DATA_DIR
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir


def _dev_only_local_tool_requested(base_url: str, tool_id: str) -> bool:
    return False

PAYLOAD_OUTPUT_FORMAT_ALIASES: dict[str, str] = {
    "auto": "auto",
    "csv": "csv_file",
    "csv_file": "csv_file",
    "json": "json_file",
    "json_file": "json_file",
}

TOOLS_SEARCH_COMMON_CATEGORIES: tuple[str, ...] = (
    "company_search",
    "people_search",
    "company_enrich",
    "people_enrich",
    "email_finder",
    "email_verify",
    "phone_finder",
    "research",
    "automation",
    "outbound_tools",
    "autocomplete",
    "admin",
)


def _parse_cli_category_list(raw: str) -> list[str]:
    return [part.strip().lower().replace("-", "_").replace(" ", "_") for part in raw.split(",") if part.strip()]


def _unknown_category_hints(raw_categories: str) -> tuple[list[str], list[str]]:
    requested = _parse_cli_category_list(raw_categories)
    known = set(TOOLS_SEARCH_COMMON_CATEGORIES)
    unknown = [category for category in requested if category not in known]
    suggestions: list[str] = []
    for category in unknown:
        suggestions.extend(difflib.get_close_matches(category, TOOLS_SEARCH_COMMON_CATEGORIES, n=3, cutoff=0.45))
    deduped_suggestions: list[str] = []
    for suggestion in suggestions:
        if suggestion not in deduped_suggestions:
            deduped_suggestions.append(suggestion)
    return unknown, deduped_suggestions


def _condense_search_match_value(value: str, search_terms: str, query: str, matched_term: str = "") -> str:
    text = " ".join(str(value).split())
    if not text:
        return text
    terms = [term.strip().lower() for term in [matched_term, query, *search_terms.split(",")] if term and term.strip()]
    lower = text.lower()
    for term in terms:
        idx = lower.find(term)
        if idx >= 0:
            start = max(0, idx - 36)
            end = min(len(text), idx + len(term) + 36)
            snippet = text[start:end]
            if start > 0:
                snippet = "..." + snippet
            if end < len(text):
                snippet = snippet + "..."
            return snippet
    if len(text) > 90:
        return text[:87] + "..."
    return text


def _highlight_search_terms(value: str, search_terms: str, query: str, matched_term: str = "") -> str:
    terms = [term.strip() for term in [matched_term, query, *search_terms.split(",")] if term and term.strip()]
    highlighted = value
    for term in sorted(terms, key=len, reverse=True):
        pattern = re.compile(re.escape(term), re.IGNORECASE)
        highlighted = pattern.sub(lambda match: f"\033[31m{match.group(0)}\033[0m", highlighted)
    return highlighted


def _tool_provider_name(tool: Dict[str, Any]) -> str:
    raw = str(tool.get("provider") or "").strip().lower()
    if raw:
        return raw
    tool_id = str(tool.get("toolId") or tool.get("tool_id") or "").strip().lower()
    if "_" in tool_id:
        return tool_id.split("_", 1)[0]
    return "other"


def _render_provider_tail_summary(
    shown_tools: list[Dict[str, Any]],
    remaining_tools: list[Dict[str, Any]],
    query: str,
) -> list[str]:
    if not remaining_tools:
        return []

    shown_counts: dict[str, int] = {}
    remaining_counts: dict[str, int] = {}
    for tool in shown_tools:
        provider = _tool_provider_name(tool)
        shown_counts[provider] = shown_counts.get(provider, 0) + 1
    for tool in remaining_tools:
        provider = _tool_provider_name(tool)
        remaining_counts[provider] = remaining_counts.get(provider, 0) + 1

    suggestions: list[str] = []
    for provider, count in sorted(remaining_counts.items(), key=lambda item: (-item[1], item[0]))[:4]:
        shown = shown_counts.get(provider, 0)
        total = shown + count
        query_suffix = f"\"{query}\" " if query else ""
        suggestions.append(
            f"- {count} other matches from {provider} ({total} total). Narrow with: deepline tools search {query_suffix}--prefix {provider}_"
        )
    return suggestions


def usage_tools_computed() -> list[str]:
    return router.usage_lines("deepline tools")


def _normalize_payload_output_format(raw: str) -> str | None:
    return PAYLOAD_OUTPUT_FORMAT_ALIASES.get(str(raw).strip().lower())


def _extract_execute_billing(response: Any) -> dict[str, float] | None:
    if not isinstance(response, dict):
        return None
    billing = response.get("billing")
    if not isinstance(billing, dict):
        return None

    def _to_non_negative_float(value: Any) -> float:
        try:
            parsed = float(value)
        except Exception:
            return 0.0
        if not (parsed >= 0):
            return 0.0
        return parsed

    credits = _to_non_negative_float(
        billing.get("credits_charged", billing.get("creditsCharged", 0)),
    )
    cost_usd = _to_non_negative_float(
        billing.get("cost_usd", billing.get("costUsd", 0)),
    )
    if credits <= 0 and cost_usd <= 0:
        return None
    return {
        "credits_charged": credits,
        "cost_usd": cost_usd,
    }


def _check_tools_execute_session_limit() -> dict[str, Any] | None:
    """Best-effort local session limit preflight for tools execute."""
    try:
        from deepline_core.playground_helpers import (
            is_local_playground_api,
            playground_api_request,
            playground_default_api,
        )
        from deepline_core.commands.session import _resolve_cli_session_id
    except Exception:
        return None

    playground_api = str(playground_default_api() or "").strip()
    if not playground_api or not is_local_playground_api(playground_api):
        return None

    session_id = str(_resolve_cli_session_id() or "").strip()
    if not session_id:
        return None

    status, raw = playground_api_request(
        "POST",
        playground_api,
        "/api/cli-event",
        {"action": "check_dollar_limit", "session_id": session_id},
        timeout=5,
    )
    if status >= 400:
        return None

    try:
        parsed = json.loads(raw or "{}")
    except Exception:
        return None
    if not isinstance(parsed, dict) or not parsed.get("ok"):
        return None

    exceeded = bool(parsed.get("exceeded"))
    try:
        used = float(parsed.get("used", 0))
    except Exception:
        used = 0.0
    try:
        limit = float(parsed.get("limit", 0))
    except Exception:
        limit = 0.0
    if not exceeded:
        return {
            "exceeded": False,
            "used": max(0.0, used),
            "limit": max(0.0, limit),
        }
    return {
        "exceeded": True,
        "used": max(0.0, used),
        "limit": max(0.0, limit),
    }


def _local_tool_get_json(tool_id: str) -> str:
    normalized = normalize_tool_id(tool_id)
    if normalized == "run_javascript":
        return json.dumps(
            {
                "tool_id": "run_javascript",
                "toolId": "run_javascript",
                "provider": "Local",
                "operation": "run_javascript",
                "display_name": "Run JavaScript",
                "displayName": "Run JavaScript",
                "categories": ["local", "js", "transform"],
                "input_schema": {
                    "description": "Execute JavaScript against payload data. The current row object is automatically available as `row`. Pure extractor globals are injected as `extract(tool, data, selector)` and `extractList(tool, data, selector)`.",
                    "fields": [
                        {"name": "code", "type": "code", "required": True, "description": "JavaScript body only. Return a value."},
                        {"name": "runInSandbox", "type": "boolean", "required": False, "description": "Set true to route execution into the Deepline-managed sandbox for heavier cloud runs. Sandboxed execution is billed by Deepline from allocated wall time."},
                        {"name": "toolMetadata", "type": "object", "required": False, "description": "Optional tool metadata registry keyed by tool id so extract/extractList can resolve provider getter paths in plain run_javascript."},
                    ],
                },
                "inputSchema": {
                    "description": "Execute JavaScript against payload data. The current row object is automatically available as `row`. Pure extractor globals are injected as `extract(tool, data, selector)` and `extractList(tool, data, selector)`.",
                    "fields": [
                        {"name": "code", "type": "code", "required": True, "description": "JavaScript body only. Return a value."},
                        {"name": "runInSandbox", "type": "boolean", "required": False, "description": "Set true to route execution into the Deepline-managed sandbox for heavier cloud runs. Sandboxed execution is billed by Deepline from allocated wall time."},
                        {"name": "toolMetadata", "type": "object", "required": False, "description": "Optional tool metadata registry keyed by tool id so extract/extractList can resolve provider getter paths in plain run_javascript."},
                    ],
                },
                "billing_source": "managed_by_deepline",
                "billingSource": "managed_by_deepline",
                "billing_source_label": "managed by Deepline when sandboxed",
                "billingSourceLabel": "managed by Deepline when sandboxed",
                "sandbox": {
                    "runtimeProvider": "deepline managed sandbox",
                    "pricingModel": "per_second_allocated_resources",
                    "descriptionSuffix": "For cloud workflows and tools execute, set `runInSandbox=true` to route execution into the Deepline-managed sandbox for heavier workloads. The default contract for that sandbox is: standard Node.js runtime only; extra npm libraries are available only if they are baked into the configured sandbox snapshot.",
                    "defaultSnapshotDependencyContract": "Standard Node.js runtime only. Deepline does not guarantee extra npm libraries unless they are baked into the configured sandbox snapshot.",
                    "defaultSnapshotDependencyHighlights": [
                        "Node.js runtime",
                        "Built-in Node standard library",
                    ],
                },
                "samples": {
                    "request": {"payload": {"code": "return extract('apollo_people_match', { person: { email: 'ada@example.com' } }, 'person.email')", "runInSandbox": True}, "context": {}, "row": {}},
                    "response": {"result": "ada@example.com"},
                },
            }
        )
    if normalized == "read_file":
        return json.dumps(
            {
                "tool_id": "read_file",
                "toolId": "read_file",
                "provider": "Local",
                "operation": "read_file",
                "display_name": "Read File",
                "displayName": "Read File",
                "categories": ["local", "file", "context"],
                "input_schema": {
                    "description": "Read a local text/markdown/json file and return structured content for downstream qualification or messaging tools.",
                    "fields": [
                        {"name": "path", "type": "string", "required": True, "description": "Absolute or relative file path (e.g. ./icp.md)."},
                        {"name": "max_bytes", "type": "number", "required": False, "description": "Optional max bytes to read from the start of the file. Default: 200000."},
                    ],
                },
                "inputSchema": {
                    "description": "Read a local text/markdown/json file and return structured content for downstream qualification or messaging tools.",
                    "fields": [
                        {"name": "path", "type": "string", "required": True, "description": "Absolute or relative file path (e.g. ./icp.md)."},
                        {"name": "max_bytes", "type": "number", "required": False, "description": "Optional max bytes to read from the start of the file. Default: 200000."},
                    ],
                },
                "samples": {
                    "request": {"payload": {"path": "./icp.md"}},
                    "response": {"payload": {"path": "./icp.md", "encoding": "utf-8", "bytes": 1234, "truncated": False, "content": "# ICP\\n..."}},
                },
            }
        )
    if normalized == "call_local_claude_code":
        claude_model_enum = ["sonnet-4-6", "sonnet", "opus", "haiku"]
        def enum_type(options: list[str]) -> str:
            return "|".join(json.dumps(option) for option in options)

        return json.dumps(
            {
                "tool_id": "call_local_claude_code",
                "toolId": "call_local_claude_code",
                "provider": "Local",
                "operation": "call_local_claude_code",
                "display_name": "Call Local Claude Code",
                "displayName": "Call Local Claude Code",
                "categories": ["local", "ai", "claude"],
                "input_schema": {
                    "description": "Run the local Claude CLI and return output text.",
                    "fields": [
                        {"name": "prompt", "type": "string", "required": True, "description": "Prompt to send to the AI CLI."},
                        {
                            "name": "model",
                            "type": enum_type(claude_model_enum),
                            "enum": claude_model_enum,
                            "required": False,
                            "description": "Optional model forwarded to the selected CLI. Default: haiku.",
                        },
                        {"name": "system", "type": "string", "required": False, "description": "Optional system instruction."},
                        {"name": "cwd", "type": "string", "required": False, "description": "Optional working directory."},
                        {
                            "name": "json_mode",
                            "type": "object|string",
                            "required": False,
                            "description": "Optional JSON Schema object (or stringified JSON object). When set, Deepline enforces strict JSON output with schema-aware system constraints.",
                        },
                        {
                            "name": "allowed_tools",
                            "type": "string",
                            "required": False,
                            "description": "Optional Claude CLI --allowedTools value (comma-separated), e.g. WebSearch,Bash.",
                        },
                    ],
                },
                "inputSchema": {
                    "description": "Run the local Claude CLI and return output text.",
                    "fields": [
                        {"name": "prompt", "type": "string", "required": True, "description": "Prompt to send to the AI CLI."},
                        {
                            "name": "model",
                            "type": enum_type(claude_model_enum),
                            "enum": claude_model_enum,
                            "required": False,
                            "description": "Optional model forwarded to the selected CLI. Default: haiku.",
                        },
                        {"name": "system", "type": "string", "required": False, "description": "Optional system instruction."},
                        {"name": "cwd", "type": "string", "required": False, "description": "Optional working directory."},
                        {
                            "name": "json_mode",
                            "type": "object|string",
                            "required": False,
                            "description": "Optional JSON Schema object (or stringified JSON object). When set, Deepline enforces strict JSON output with schema-aware system constraints.",
                        },
                        {
                            "name": "allowed_tools",
                            "type": "string",
                            "required": False,
                            "description": "Optional Claude CLI --allowedTools value (comma-separated), e.g. WebSearch,Bash.",
                        },
                    ],
                },
                "samples": {
                    "request": {"payload": {"prompt": "Reply with one short sentence."}},
                    "response": {"payload": {"output": "Done."}},
                },
            }
        )
    if normalized == "call_local_codex":
        codex_model_enum = ["gpt-5.3-codex", "gpt-5"]

        def enum_type(options: list[str]) -> str:
            return "|".join(json.dumps(option) for option in options)

        return json.dumps(
            {
                "tool_id": "call_local_codex",
                "toolId": "call_local_codex",
                "provider": "Local",
                "operation": "call_local_codex",
                "display_name": "Call Local Codex",
                "displayName": "Call Local Codex",
                "categories": ["local", "ai", "codex"],
                "input_schema": {
                    "description": "Run the local Codex CLI and return output text.",
                    "fields": [
                        {"name": "prompt", "type": "string", "required": True, "description": "Prompt to send to the AI CLI."},
                        {
                            "name": "model",
                            "type": enum_type(codex_model_enum),
                            "enum": codex_model_enum,
                            "required": False,
                            "description": "Optional model forwarded to the selected CLI. Default: haiku.",
                        },
                        {"name": "system", "type": "string", "required": False, "description": "Optional system instruction."},
                        {"name": "cwd", "type": "string", "required": False, "description": "Optional working directory."},
                        {
                            "name": "json_mode",
                            "type": "object|string",
                            "required": False,
                            "description": "Optional JSON Schema object (or stringified JSON object). When set, Deepline enforces strict JSON output with schema-aware system constraints.",
                        },
                    ],
                },
                "inputSchema": {
                    "description": "Run the local Codex CLI and return output text.",
                    "fields": [
                        {"name": "prompt", "type": "string", "required": True, "description": "Prompt to send to the AI CLI."},
                        {
                            "name": "model",
                            "type": enum_type(codex_model_enum),
                            "enum": codex_model_enum,
                            "required": False,
                            "description": "Optional model forwarded to the selected CLI. Default: haiku.",
                        },
                        {"name": "system", "type": "string", "required": False, "description": "Optional system instruction."},
                        {"name": "cwd", "type": "string", "required": False, "description": "Optional working directory."},
                        {
                            "name": "json_mode",
                            "type": "object|string",
                            "required": False,
                            "description": "Optional JSON Schema object (or stringified JSON object). When set, Deepline enforces strict JSON output with schema-aware system constraints.",
                        },
                    ],
                },
                "samples": {
                    "request": {"payload": {"prompt": "Reply with one short sentence."}},
                    "response": {"payload": {"output": "Done."}},
                },
            }
        )
    return ""


def _extract_embedded_status(response: Dict[str, Any]) -> int | None:
    value = response.get("status")
    if isinstance(value, int):
        return value if value >= 400 else None
    if isinstance(value, str) and value.isdigit():
        v = int(value)
        return v if v >= 400 else None
    if value in ("error", "failed"):
        return 500
    return None


def _render_execute_error(
    status: int,
    raw: str,
    output_json: bool,
    action: str = "execute",
) -> None:
    message = f"Tools {action} failed"
    hint = None
    detail = None
    parsed_payload: Dict[str, Any] | None = None
    request_id = None
    validation_issues: list[Dict[str, Any]] = []
    docs: list[Dict[str, Any]] = []
    if raw:
        try:
            payload = json.loads(raw)
            if isinstance(payload, dict):
                parsed_payload = payload
            message = str(payload.get("message") or payload.get("error") or payload.get("error_message") or message)
            det = payload.get("details")
            if isinstance(det, str) and det.strip():
                detail = det
            request_id_value = payload.get("request_id") or payload.get("requestId")
            if isinstance(request_id_value, str) and request_id_value.strip():
                request_id = request_id_value.strip()
            operator_hint = payload.get("operator_hint")
            if isinstance(operator_hint, str) and operator_hint.strip():
                hint = operator_hint
            else:
                hint = None
            issues_value = payload.get("validation_issues")
            if isinstance(issues_value, list):
                validation_issues = [issue for issue in issues_value if isinstance(issue, dict)]
            docs_value = payload.get("docs")
            if isinstance(docs_value, list):
                docs = [doc for doc in docs_value if isinstance(doc, dict)]
        except Exception:
            message = raw.strip() or message
    if output_json:
        out: Dict[str, Any] = dict(parsed_payload) if isinstance(parsed_payload, dict) else {}
        out["status"] = status
        out["message"] = message
        if detail:
            out["detail"] = detail
        if hint:
            out["operator_hint"] = hint
        print(json.dumps(out))
    else:
        print(f"Tools {action} failed (status {status}).")
        print(f"Message: {message}")
        if detail:
            print(f"Detail: {detail}")
        if request_id:
            print(f"Request ID: {request_id}")
        if hint:
            print(f"Hint: {hint}")
        if validation_issues:
            print("Validation issues:")
            for issue in validation_issues:
                path_value = issue.get("path")
                path = ""
                if isinstance(path_value, list):
                    path = ".".join(str(part) for part in path_value if str(part).strip())
                elif isinstance(path_value, str):
                    path = path_value.strip()
                issue_message = str(issue.get("message") or "Invalid value").strip()
                issue_code = str(issue.get("code") or "").strip()
                prefix = f"  - {path}: " if path else "  - "
                suffix = f" ({issue_code})" if issue_code else ""
                print(f"{prefix}{issue_message}{suffix}")
        if docs and not validation_issues:
            print("Docs:")
            for doc in docs[:5]:
                title = str(doc.get("title") or doc.get("operation") or doc.get("path") or "Related doc").strip()
                path = str(doc.get("path") or "").strip()
                excerpt = str(doc.get("excerpt") or "").strip()
                print(f"  - {title}")
                if path:
                    print(f"    {path}")
                if excerpt:
                    print(f"    {excerpt}")
        if raw and parsed_payload is None:
            print(raw)


def _strip_identity_match_payload(payload: Any) -> Any:
    if isinstance(payload, dict):
        cleaned: dict[str, Any] = {}
        for key, value in payload.items():
            if key == "identityMatch":
                continue
            cleaned[key] = _strip_identity_match_payload(value)
        return cleaned
    if isinstance(payload, list):
        return [_strip_identity_match_payload(item) for item in payload]
    return payload


def _extract_csv_rows(response: Dict[str, Any], extractor_paths: Iterable[str]) -> list[Dict[str, Any]] | None:
    if not isinstance(response, dict):
        return None

    def get_by_path(root: Any, dotted_path: str) -> Any:
        node = root
        for part in str(dotted_path).split("."):
            if not isinstance(node, dict) or part not in node:
                return None
            node = node[part]
        return node

    for path in extractor_paths:
        for candidate_root in (
            response,
            response.get("result") if isinstance(response.get("result"), dict) else None,
            (
                response.get("result", {}).get("data")
                if isinstance(response.get("result"), dict)
                and isinstance(response.get("result", {}).get("data"), dict)
                else None
            ),
        ):
            if candidate_root is None:
                continue
            node = get_by_path(candidate_root, str(path))
            if isinstance(node, list):
                rows: list[Dict[str, Any]] = []
                for row in node:
                    rows.append(row if isinstance(row, dict) else {"value": row})
                return rows
    return None


def _write_csv(rows: list[Dict[str, Any]], tool_id: str) -> tuple[str, int, list[str]]:
    headers: list[str] = []
    seen = set()
    for row in rows:
        for key in row.keys():
            if key not in seen:
                seen.add(key)
                headers.append(key)
    if not headers:
        headers = [f"{tool_id}_result"]
    output_dir = _ensure_persistent_data_dir()
    output_path = str(output_dir / f"{tool_id}_output_{int(time.time() * 1000)}.csv")
    with open(output_path, "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=headers)
        writer.writeheader()
        for row in rows:
            normalized = {}
            for key in headers:
                value = row.get(key)
                if value is None:
                    normalized[key] = ""
                elif isinstance(value, (str, int, float, bool)):
                    normalized[key] = str(value)
                else:
                    normalized[key] = json.dumps(value, ensure_ascii=False)
            writer.writerow(normalized)
    return output_path, len(rows), headers


def _write_json(payload: Dict[str, Any] | list[Any] | str | None, tool_id: str) -> str:
    output_dir = _ensure_persistent_data_dir()
    output_path = str(output_dir / f"payload_{tool_id}_{int(time.time() * 1000)}.json")
    with open(output_path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
    return output_path


def _merge_execute_json_output(
    response: Dict[str, Any] | Any,
    extra_fields: Dict[str, Any],
) -> Dict[str, Any]:
    merged = dict(response) if isinstance(response, dict) else {"result": response}
    merged.update(extra_fields)
    return merged


def _try_extract_rows_csv(response: Dict[str, Any], tool_id: str) -> tuple[str, int, list[str]] | None:
    """If the response contains rows_csv (pre-built CSV from DuckDB COPY TO), write it directly to a file."""
    if not isinstance(response, dict):
        return None
    # Walk response envelope: response.result.data.rows_csv or response.result.rows_csv
    for candidate in (
        response,
        response.get("result") if isinstance(response.get("result"), dict) else None,
        response.get("result", {}).get("data") if isinstance(response.get("result", {}).get("data"), dict) else None,
    ):
        if candidate is None:
            continue
        rows_csv = candidate.get("rows_csv")
        if not isinstance(rows_csv, str) or not rows_csv:
            continue

        output_dir = _ensure_persistent_data_dir()
        csv_path = str(output_dir / f"{tool_id}_output_{int(time.time() * 1000)}.csv")
        with open(csv_path, "w", encoding="utf-8") as f:
            f.write(rows_csv)

        # Parse columns from header + count rows
        row_count = int(candidate.get("row_count", 0))
        columns: list[str] = []
        header_end = rows_csv.find("\n")
        if header_end >= 0:
            columns = [c.strip() for c in rows_csv[:header_end].split(",")]
        if not row_count:
            row_count = rows_csv.count("\n") - (1 if rows_csv.endswith("\n") else 0)
        return csv_path, row_count, columns
    return None


MAX_INLINE_RESULT_CHARS = 24_000


def _serialized_result_size(value: Any) -> int:
    try:
        return len(json.dumps(value, ensure_ascii=False))
    except Exception:
        return len(str(value))


def _build_large_result_preview(response: Dict[str, Any]) -> list[str]:
    lines: list[str] = []
    result = response.get("result")
    if not isinstance(result, dict):
        return lines
    result_data = result.get("data")
    if isinstance(result_data, list):
        lines.append(f"Result items: {len(result_data)}")
        sample_types: list[str] = []
        for item in result_data:
            if not isinstance(item, dict):
                continue
            item_type = str(item.get("type") or "").strip()
            if item_type and item_type not in sample_types:
                sample_types.append(item_type)
            if len(sample_types) >= 5:
                break
        if sample_types:
            lines.append(f"Sample item types: {', '.join(sample_types)}")
        return lines
    if isinstance(result_data, dict):
        keys = list(result_data.keys())
        if keys:
            preview_keys = ", ".join(keys[:8])
            lines.append(f"Top-level result keys: {preview_keys}")
            if len(keys) > 8:
                lines.append(f"... and {len(keys) - 8} more")
    return lines


def _build_csv_preview(rows: list[Dict[str, Any]], headers: list[str], max_rows: int = 5, max_cols: int = 5) -> str:
    preview_rows = rows[:max_rows]
    preview_headers = headers[:max_cols]
    lines = [",".join(preview_headers)]
    for row in preview_rows:
        values: list[str] = []
        for key in preview_headers:
            value = row.get(key)
            if value is None:
                values.append("")
            elif isinstance(value, (str, int, float, bool)):
                values.append(str(value))
            else:
                values.append(json.dumps(value, ensure_ascii=False))
        lines.append(",".join(values))
    return "\n".join(lines)


def _build_csv_preview_rows(rows: list[Dict[str, Any]], max_rows: int = 5) -> list[Dict[str, Any]]:
    out: list[Dict[str, Any]] = []
    for row in rows[:max_rows]:
        if isinstance(row, dict):
            out.append(row)
    return out


def _tool_prefix_from_id(tool_id: str) -> str:
    raw = str(tool_id or "").strip()
    if not raw:
        return ""
    return raw.split("_", 1)[0] if "_" in raw else raw


def _print_unknown_tool_hints(tool_id: str) -> None:
    print("Tip: tool ids are provider-prefixed (for example: dropleads_search_people).")
    prefix = _tool_prefix_from_id(tool_id)
    if prefix:
        print(f"Next: deepline tools search {prefix}")
    else:
        print("Next: deepline tools list --json")


def _candidate_tool_ids(base_url: str, token: str | None, timeout: int = 10) -> list[str]:
    candidates: set[str] = set()
    if token:
        try:
            status, body = http_request(
                "GET",
                f"{base_url}/api/v2/integrations/list",
                token,
                timeout=timeout,
                deadline_timeout=timeout,
            )
        except RuntimeError:
            status, body = 0, ""
        if status == 200 and body:
            try:
                payload = json.loads(body)
            except Exception:
                payload = {}
            tools = payload.get("tools") if isinstance(payload, dict) else None
            if isinstance(tools, list):
                for t in tools:
                    if not isinstance(t, dict):
                        continue
                    tid = str(t.get("toolId") or t.get("tool_id") or "").strip()
                    if tid:
                        candidates.add(tid)
    return sorted(candidates)


def _print_tool_suggestions(base_url: str, token: str | None, tool_id: str) -> None:
    candidates = _candidate_tool_ids(base_url, token, timeout=8)
    if not candidates:
        return
    matches = difflib.get_close_matches(str(tool_id or ""), candidates, n=5, cutoff=0.25)
    if not matches:
        prefix = _tool_prefix_from_id(tool_id).lower()
        if prefix:
            matches = [c for c in candidates if c.lower().startswith(prefix)][:5]
    if not matches:
        return
    print("Suggestions:")
    for m in matches:
        print(f"  - {m}")


def _print_fuzzy_tool_suggestions(tool_id: str, known_tool_ids: list[str]) -> None:
    target = str(tool_id or "").strip()
    if not target or not known_tool_ids:
        return
    prefix = _tool_prefix_from_id(target)
    prefix_matches = [tid for tid in known_tool_ids if tid.startswith(prefix)] if prefix else []
    similar = difflib.get_close_matches(target, known_tool_ids, n=5, cutoff=0.4)
    ordered: list[str] = []
    seen: set[str] = set()
    for candidate in prefix_matches + similar:
        if candidate in seen:
            continue
        seen.add(candidate)
        ordered.append(candidate)
    if ordered:
        print("Suggestions:")
        for tid in ordered[:5]:
            print(f"  - {tid}")


def _response_has_validation_issues(raw_response: str) -> bool:
    try:
        payload = json.loads(raw_response or "{}")
    except Exception:
        return False
    issues = payload.get("validation_issues")
    return isinstance(issues, list) and len(issues) > 0


def _print_input_schema_hints(tool_id: str, raw_tool_meta: str) -> None:
    try:
        payload = json.loads(raw_tool_meta or "{}")
    except Exception:
        return
    input_schema = payload.get("input_schema") or payload.get("inputSchema") or {}
    fields = input_schema.get("fields") if isinstance(input_schema, dict) else []
    if not isinstance(fields, list):
        fields = []
    required = [str(field.get("name")) for field in fields if isinstance(field, dict) and field.get("required") and field.get("name")]
    if required:
        print("Required inputs:")
        print(f"  {', '.join(required)}")
        print(f"Tip: deepline tools get {tool_id} --json")


def _tokenize(text: str) -> list[str]:
    return [part for part in "".join(ch if ch.isalnum() else " " for ch in (text or "").lower()).split() if part]


def _top_level_field_name(name: str) -> str:
    raw = str(name or "").strip()
    if not raw:
        return ""
    if raw.startswith("input_schema.fields.") or raw.startswith("inputSchema.fields."):
        return raw.split(".")[-1]
    return raw.split(".", 1)[0]


def _build_payload_value_for_field(field_name: str, field_type: str, query: str) -> Any:
    lowered = str(field_type or "").lower()
    if "bool" in lowered:
        return True
    if "number" in lowered or "int" in lowered:
        return 1
    if "array" in lowered:
        return [query or "value"]
    if "object" in lowered:
        return {"query": query or "value"}
    name_lower = str(field_name or "").lower()
    if "email" in name_lower:
        return "person@example.com"
    if "domain" in name_lower:
        return "example.com"
    if "url" in name_lower:
        return "https://example.com"
    return query or "example"


def _build_search_fallback_payload(tool: Dict[str, Any], query: str) -> Dict[str, Any]:
    payload: Dict[str, Any] = {}
    input_schema = tool.get("inputSchema") or tool.get("input_schema") or {}
    fields = input_schema.get("fields") if isinstance(input_schema, dict) else []
    if not isinstance(fields, list):
        return payload
    for field in fields:
        if not isinstance(field, dict) or not field.get("required"):
            continue
        name = str(field.get("name") or "")
        top = _top_level_field_name(name)
        if not top or top in payload:
            continue
        payload[top] = _build_payload_value_for_field(name, str(field.get("type") or ""), query)
        if len(payload) >= 3:
            break
    return payload


def _select_search_example(tool: Dict[str, Any], query: str) -> Dict[str, Any]:
    examples = tool.get("search_examples")
    if not isinstance(examples, list) or not examples:
        return {}
    query_tokens = set(_tokenize(query))
    normalized_query = (query or "").strip().lower()
    best: Dict[str, Any] = {}
    best_score = 0
    for item in examples:
        if not isinstance(item, dict):
            continue
        payload = item.get("payload")
        terms = item.get("query_terms")
        if not isinstance(payload, dict) or not isinstance(terms, list):
            continue
        score = 0
        for term in terms:
            lowered = str(term).strip().lower()
            if not lowered:
                continue
            if lowered == normalized_query:
                score += 5
            elif lowered in query_tokens:
                score += 3
            elif lowered in normalized_query or normalized_query in lowered:
                score += 2
        if score > best_score:
            best_score = score
            best = {"payload": payload}
    return best if best_score > 0 else {}


def _build_search_execute_example(tool: Dict[str, Any], search_query: str) -> str:
    tool_id = str(tool.get("toolId") or tool.get("tool_id") or "")
    if not tool_id:
        return ""
    payload = {}
    selected = _select_search_example(tool, search_query)
    if isinstance(selected.get("payload"), dict):
        payload = dict(selected["payload"])
    if not payload:
        samples = tool.get("samples")
        if isinstance(samples, dict):
            req = samples.get("request")
            if isinstance(req, dict) and isinstance(req.get("payload"), dict):
                payload = dict(req.get("payload") or {})
    if not payload:
        payload = _build_search_fallback_payload(tool, search_query)
    if not payload:
        return ""
    if _is_play_tool(tool):
        enrich_spec = json.dumps(
            {"alias": "result", "tool": tool_id, "payload": payload},
            separators=(",", ":"),
            ensure_ascii=False,
        )
        return f"deepline enrich --with '{enrich_spec}'"
    payload_json = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    return f"deepline tools execute {tool_id} --payload '{payload_json}' --json"


def _is_play_tool(tool: Dict[str, Any]) -> bool:
    if tool.get("isPlay") is True:
        return True
    if tool.get("is_play") is True:
        return True
    play_expansion = tool.get("play_expansion") or tool.get("playExpansion")
    if isinstance(play_expansion, dict) and play_expansion:
        return True
    tool_id = str(tool.get("toolId") or tool.get("tool_id") or "")
    return tool_id.endswith("_waterfall")


def _extract_useful_inputs(tool: Dict[str, Any], max_items: int = 3) -> list[str]:
    matches = tool.get("search_matches")
    if not isinstance(matches, list):
        return []
    out: list[str] = []
    seen: set[str] = set()
    for item in matches:
        if not isinstance(item, dict):
            continue
        field = str(item.get("field") or "")
        if field in {"input_schema.fields.name", "inputSchema.fields.name"}:
            value = str(item.get("value") or "").strip()
            if value and value not in seen:
                seen.add(value)
                out.append(value)
        else:
            top = _top_level_field_name(field)
            if top and top not in seen:
                seen.add(top)
                out.append(top)
        if len(out) >= max_items:
            break
    return out


def _list_known_tool_ids(base_url: str, env: Dict[str, str], timeout: int = 20) -> list[str]:
    try:
        status, raw = http_request(
            "GET",
            f"{base_url}/api/v2/integrations/list",
            env.get("DEEPLINE_API_KEY"),
            timeout=timeout,
            deadline_timeout=timeout,
        )
    except RuntimeError:
        return []
    if status >= 400:
        return []
    try:
        data = json.loads(raw)
    except Exception:
        return []
    tools = data.get("tools") if isinstance(data, dict) else []
    out: list[str] = []
    if isinstance(tools, list):
        for item in tools:
            if not isinstance(item, dict):
                continue
            tid = str(item.get("toolId") or item.get("tool_id") or "").strip()
            if tid:
                out.append(tid)
    return out


def _to_positive_int(raw: str, flag_name: str) -> int:
    try:
        value = int(str(raw))
    except Exception:
        raise ValueError(f"Invalid {flag_name} value: {raw}")
    if value <= 0:
        raise ValueError(f"Invalid {flag_name} value: {raw}")
    return value


def _extract_apify_run_context(raw_response: str) -> tuple[str, str]:
    try:
        data = json.loads(raw_response or "{}")
    except Exception:
        return "", ""
    result = data.get("result")
    payload = result if isinstance(result, dict) else data
    run_id = str(payload.get("runId") or payload.get("id") or "")
    dataset_id = str(payload.get("defaultDatasetId") or payload.get("datasetId") or "")
    return run_id, dataset_id


def _extract_apify_run_snapshot(raw_response: str) -> tuple[str, str, str]:
    try:
        data = json.loads(raw_response or "{}")
    except Exception:
        return "UNKNOWN", "", ""
    result = data.get("result")
    run = result.get("data") if isinstance(result, dict) else None
    if not isinstance(run, dict):
        return "UNKNOWN", "", ""
    status = str(run.get("status") or "UNKNOWN").upper()
    dataset_count = ""
    stats = run.get("stats")
    if isinstance(stats, dict):
        for key in ("itemsOutputted", "itemCount", "outputItemCount", "items_outputted"):
            value = stats.get(key)
            if isinstance(value, (int, float)):
                dataset_count = str(int(value))
                break
    reason = ""
    for key in ("statusMessage", "status_message", "statusDetails", "exitCode", "exit_code", "errorMessage"):
        value = run.get(key)
        if value is None:
            continue
        text = str(value).strip()
        if text:
            reason = text
            break
    return status, dataset_count, reason


def _extract_apify_log_tail(raw_response: str) -> str:
    try:
        data = json.loads(raw_response or "{}")
    except Exception:
        return ""
    result = data.get("result")
    result_data = result.get("data") if isinstance(result, dict) else None
    text = ""
    if isinstance(result_data, dict) and isinstance(result_data.get("data"), str):
        text = result_data.get("data") or ""
    elif isinstance(result_data, str):
        text = result_data
    if not text.strip():
        return ""
    lines = text.rstrip("\n").splitlines()
    tail = lines[-12:] if len(lines) > 12 else lines
    return "\n".join(tail)


def _apify_wait_and_debug(
    base_url: str,
    token: str,
    run_id: str,
    debug_mode: bool,
    wait_timeout: int,
    poll_interval: int,
    timeout: int,
) -> bool:
    if not run_id:
        print("Wait/debug skipped: run id not found in response.")
        return True
    print(f"Wait/debug: monitoring Apify run {run_id}")
    started = time.time()
    last_log_tail = ""
    while True:
        elapsed = int(time.time() - started)
        if elapsed >= wait_timeout:
            print(f"Wait/debug timed out after {wait_timeout}s.")
            return False
        run_body = {"provider": "apify", "operation": "apify_get_actor_run", "payload": {"runId": run_id}}
        try:
            run_status, run_raw = http_request(
                "POST",
                build_tool_execute_url(base_url, "apify_get_actor_run"),
                token,
                run_body,
                timeout=timeout,
            )
        except RuntimeError as exc:
            print(str(exc))
            return False
        if run_status >= 400:
            print(f"Wait/debug run-status request failed (status {run_status}).")
            if run_raw:
                _render_execute_error(run_status, run_raw, False)
            return False
        actor_status, dataset_count, failure_reason = _extract_apify_run_snapshot(run_raw)
        if dataset_count:
            print(f"Run status: {actor_status} | dataset_count: {dataset_count} | elapsed: {elapsed}s")
        else:
            print(f"Run status: {actor_status} | dataset_count: (unknown) | elapsed: {elapsed}s")
        if debug_mode:
            log_body = {"provider": "apify", "operation": "apify_get_log", "payload": {"buildOrRunId": run_id}}
            try:
                log_status, log_raw = http_request(
                    "POST",
                    build_tool_execute_url(base_url, "apify_get_log"),
                    token,
                    log_body,
                    timeout=timeout,
                )
            except RuntimeError:
                log_status, log_raw = 599, ""
            if log_status < 400:
                log_tail = _extract_apify_log_tail(log_raw)
                if log_tail and log_tail != last_log_tail:
                    print("Log tail:")
                    print(log_tail)
                    last_log_tail = log_tail
        if actor_status == "SUCCEEDED":
            print("Wait/debug: run succeeded.")
            return True
        if actor_status in {"FAILED", "ABORTED", "TIMED-OUT", "TIMED_OUT", "TIMEOUT"}:
            if failure_reason:
                print(f"Wait/debug failure reason: {failure_reason}")
            else:
                print(f"Wait/debug failure reason: run ended with status {actor_status}.")
            return False
        time.sleep(poll_interval)


def _render_execute_output(tool_id: str, response: Dict[str, Any]) -> None:
    status = response.get("status") or response.get("job_status") or response.get("state") or "(unknown)"
    print(f"Status: {status}")
    job_id = response.get("job_id") or response.get("jobId")
    if job_id is not None:
        print(f"Job ID: {job_id}")
    result = response.get("result")
    result_data = result.get("data") if isinstance(result, dict) else None
    run_id = (
        response.get("run_id")
        or response.get("runId")
        or response.get("task_run_id")
        or response.get("taskRunId")
        or (result.get("run_id") if isinstance(result, dict) else None)
        or (result.get("runId") if isinstance(result, dict) else None)
        or (result_data.get("runId") if isinstance(result_data, dict) else None)
        or ((result_data.get("run") or {}).get("id") if isinstance(result_data, dict) and isinstance(result_data.get("run"), dict) else None)
    )
    dataset_id = (
        response.get("dataset_id")
        or response.get("datasetId")
        or response.get("defaultDatasetId")
        or (result.get("dataset_id") if isinstance(result, dict) else None)
        or (result.get("datasetId") if isinstance(result, dict) else None)
        or (result.get("defaultDatasetId") if isinstance(result, dict) else None)
        or (result_data.get("datasetId") if isinstance(result_data, dict) else None)
        or (result_data.get("defaultDatasetId") if isinstance(result_data, dict) else None)
        or ((result_data.get("run") or {}).get("defaultDatasetId") if isinstance(result_data, dict) and isinstance(result_data.get("run"), dict) else None)
    )
    if isinstance(result, list):
        print(f"Result items: {len(result)}")
    elif isinstance(result, dict):
        if "output" in result:
            value = result.get("output")
            if value is None:
                print("Result: (empty)")
            elif isinstance(value, (dict, list)):
                print("Result:")
                print(json.dumps(value, indent=2))
            else:
                print(f"Result: {value}")
        elif "text" in result and not isinstance(result.get("text"), (dict, list)):
            print(f"Result: {result.get('text')}")
        elif "data" in result and isinstance(result.get("data"), dict) and isinstance(result.get("data", {}).get("values"), list):
            values = result.get("data", {}).get("values") or []
            if not values:
                print("Result: No values found")
            else:
                print(f"Result: {len(values)} value(s)")
                for idx, value in enumerate(values[:10], 1):
                    print(f"  {idx}. {value}")
                if len(values) > 10:
                    print(f"  ... and {len(values) - 10} more")
        elif "data" in result and len(result.keys()) == 1:
            value = result.get("data")
            if value is None:
                print("Result: (empty)")
            elif isinstance(value, (dict, list)):
                print("Result:")
                print(json.dumps(value, indent=2))
            else:
                txt = str(value)
                if len(txt) > 140:
                    txt = txt[:137] + "..."
                print(f"Result: {txt}")
        elif result:
            print("Result:")
            print(json.dumps(result, indent=2))
        else:
            print("Result: (empty)")
    elif isinstance(result, str):
        preview = result[:137] + "..." if len(result) > 140 else result
        print(f"Result: {preview}")
    elif result is None:
        print("Result: (empty)")
    else:
        txt = str(result)
        if len(txt) > 140:
            txt = txt[:137] + "..."
        print(f"Result: {txt}")

    if tool_id == "apify_run_actor_sync":
        print("")
        print("Tip: For larger runs, increase both client and provider timeouts.")
        print("Tip: deepline tools execute apify_run_actor_sync --timeout 300 --payload '{\"actorId\":\"username/actor-name\",\"timeoutMs\":300000,\"input\":{...}}'")
        print("Tip: If sync still times out, use apify_run_actor then apify_get_dataset_items.")

    if run_id and tool_id.startswith("apify_"):
        payload = json.dumps({"runId": run_id}, ensure_ascii=False)
        print("")
        print("Async: Apify run detected.")
        print(f"Next: deepline tools execute apify_get_actor_run --payload '{payload}'")
        if dataset_id:
            dataset_payload = json.dumps({"datasetId": dataset_id, "params": {"limit": 5}}, ensure_ascii=False)
            print(f"Next: deepline tools execute apify_get_dataset_items --payload '{dataset_payload}'")


def _first_non_empty_string(*values: Any) -> str:
    for value in values:
        text = str(value or "").strip()
        if text:
            return text
    return ""


def _normalize_lookup_key(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(value or "").strip().lower())


def _collect_followup_candidates(value: Any, out: Dict[str, Any]) -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            key_text = str(key or "").strip()
            if not key_text:
                continue
            normalized = _normalize_lookup_key(key_text)
            if normalized and normalized not in out and item is not None:
                out[normalized] = item
            _collect_followup_candidates(item, out)
    elif isinstance(value, list):
        for item in value:
            _collect_followup_candidates(item, out)


def _fetch_tool_metadata(
    base_url: str,
    token: str,
    tool_id: str,
    *,
    timeout: int,
    connect_timeout: int,
) -> Dict[str, Any] | None:
    try:
        status, raw = http_request(
            "GET",
            build_tool_get_url(base_url, tool_id),
            token,
            timeout=timeout,
            connect_timeout=connect_timeout,
        )
    except RuntimeError:
        return None
    if status >= 400:
        return None
    try:
        parsed = json.loads(raw)
    except Exception:
        return None
    return parsed if isinstance(parsed, dict) else None


def _extract_async_followup_payload(
    async_meta: Dict[str, Any],
    response: Dict[str, Any],
    request_payload: Dict[str, Any],
) -> Dict[str, Any]:
    input_schema = async_meta.get("inputSchema") or async_meta.get("input_schema") or {}
    properties = input_schema.get("properties") if isinstance(input_schema, dict) else {}
    required = input_schema.get("required") if isinstance(input_schema, dict) else None
    candidate_keys = [
        str(item).strip()
        for item in (required if isinstance(required, list) else [])
        if str(item).strip()
    ]
    if not candidate_keys and isinstance(properties, dict):
        candidate_keys = [str(key).strip() for key in properties.keys() if str(key).strip()]

    payload: Dict[str, Any] = {}
    candidates: Dict[str, Any] = {}
    _collect_followup_candidates(request_payload, candidates)
    _collect_followup_candidates(response, candidates)

    alias_groups = {
        "id": ["id", "_id", "jobid", "runid", "requestid", "enrichid", "exportid", "trackid", "findallid"],
        "_id": ["_id", "id", "jobid", "runid", "requestid", "enrichid", "exportid", "trackid", "findallid"],
        "job_id": ["jobid", "id", "runid"],
        "run_id": ["runid", "id", "jobid"],
        "request_id": ["requestid", "id", "runid", "jobid"],
        "enrich_id": ["enrichid", "id", "jobid", "runid"],
        "export_id": ["exportid", "id", "jobid", "runid"],
        "track_id": ["trackid", "trackid", "id"],
        "trackid": ["trackid", "id"],
        "findall_id": ["findallid", "id", "runid"],
        "campaign_id": ["campaignid"],
    }

    for key in candidate_keys:
        normalized = _normalize_lookup_key(key)
        if not normalized:
            continue
        possible = [normalized, *alias_groups.get(normalized, [])]
        for candidate in possible:
            if candidate in candidates and candidates[candidate] is not None:
                payload[key] = candidates[candidate]
                break
    return payload


def _print_async_followup_hint(
    async_meta: Dict[str, Any],
    response: Dict[str, Any],
    request_payload: Dict[str, Any],
) -> None:
    action = str(async_meta.get("operation") or async_meta.get("toolId") or async_meta.get("tool_id") or "").strip()
    if not action:
        return
    followup_payload = _extract_async_followup_payload(async_meta, response, request_payload)
    print("")
    print(f"Get results with: deepline tools get {action}")
    if followup_payload:
        print(f"Get results with: deepline tools execute {action}")
        print("Pass the returned job/run id from this result into that follow-up tool.")
    else:
        print(f"Get results with: deepline tools execute {action}")


def _is_network_timeout_error(exc: RuntimeError) -> bool:
    message = str(exc).lower()
    return "failed to reach api: timeout" in message or "read operation timed out" in message


def _print_apify_sync_cli_timeout_error(
    exc: RuntimeError,
    *,
    request_timeout: int,
) -> None:
    print("CLI request timed out while waiting for `apify_run_actor_sync` to finish.")
    print("This does not necessarily mean Apify failed or the run stopped.")
    print(f"The CLI gave up after {request_timeout}s before the server returned a final result.")
    print(
        "Next: rerun with a longer client timeout, for example "
        "`deepline tools execute apify_run_actor_sync --timeout 300 --payload ...`"
    )
    print(
        "If the scrape is still too slow, switch to `apify_run_actor` and then poll "
        "with `apify_get_actor_run` / fetch results with `apify_get_dataset_items`."
    )
    print("")
    print(str(exc))


def _tools_compact_name(tool: Dict[str, Any]) -> str:
    operation = str(tool.get("operation") or "")
    group = str(tool.get("operationGroup") or tool.get("operation_group") or "")
    if operation:
        return operation.replace("_", " ").strip().title()
    if group:
        return group.replace("_", " ").strip().title()
    return ""


def _tool_summary_parts(tool: Dict[str, Any]) -> list[str]:
    use_when = str(tool.get("bestFor") or tool.get("best_for") or "").strip()
    description = str(tool.get("description") or "").strip()
    fallback = _tools_compact_name(tool).strip()

    def _normalize_candidate(value: str) -> str:
        return re.sub(r"[\W_]+", " ", value).strip().lower()

    def _is_redundant(candidate: str, existing: list[str]) -> bool:
        normalized = _normalize_candidate(candidate)
        if not normalized:
            return True
        for prior in existing:
            prior_normalized = _normalize_candidate(prior)
            if not prior_normalized:
                continue
            if normalized == prior_normalized:
                return True
            if normalized in prior_normalized or prior_normalized in normalized:
                return True
            if difflib.SequenceMatcher(None, normalized, prior_normalized).ratio() >= 0.86:
                return True
        return False

    def is_generic_boilerplate(candidate: str) -> bool:
        normalized = _normalize_candidate(candidate)
        if not normalized:
            return True
        generic_phrases = (
            " fixed get endpoint input",
            " fixed mutation endpoint input",
            " input",
        )
        return any(normalized.endswith(phrase) for phrase in generic_phrases)

    parts: list[str] = []
    seen_normalized: set[str] = set()
    candidates = [use_when, description]
    if not use_when and not description:
        candidates.append(fallback)
    for candidate in candidates:
        if not candidate:
            continue
        if candidate != use_when and is_generic_boilerplate(candidate):
            continue
        if _is_redundant(candidate, parts):
            continue
        normalized = _normalize_candidate(candidate)
        if normalized in seen_normalized:
            continue
        seen_normalized.add(normalized)
        parts.append(candidate)
    return parts


def _tool_categories_suffix(tool: Dict[str, Any]) -> str:
    categories = tool.get("categories")
    if not isinstance(categories, list):
        return ""
    rendered = [str(category).strip() for category in categories if str(category).strip()]
    if not rendered:
        return ""
    return f" [{','.join(rendered)}]"


def _tool_summary_line(tool: Dict[str, Any]) -> str:
    tool_id = str(tool.get("toolId") or tool.get("tool_id") or "").strip()
    parts = [part for part in [tool_id, *_tool_summary_parts(tool)] if part]
    return f"{' | '.join(parts)}{_tool_categories_suffix(tool)}"


def _title_case(value: str) -> str:
    if not value:
        return ""
    parts = value.replace("_", " ").replace("-", " ").split()
    special = {
        "companydb": "CompanyDB",
        "persondb": "PersonDB",
        "linkedin": "LinkedIn",
    }
    out: list[str] = []
    for part in parts:
        if not part:
            continue
        lower = part.lower()
        if lower in special:
            out.append(special[lower])
        else:
            out.append(part[:1].upper() + part[1:])
    return " ".join(out)


def _print_json_preview(label: str, payload: Any) -> None:
    if payload is None:
        return
    try:
        serialized = json.dumps(payload, indent=2, sort_keys=True)
    except Exception:
        serialized = str(payload)
    print(f"  {label}:")
    for row in serialized.splitlines():
        print(f"    {row}")


def _json_schema_display_type(schema: Dict[str, Any]) -> str:
    if not isinstance(schema, dict):
        return "unknown"
    if "const" in schema:
        try:
            return json.dumps(schema.get("const"))
        except Exception:
            return str(schema.get("const"))
    enum_values = schema.get("enum")
    if isinstance(enum_values, list) and enum_values:
        parts: list[str] = []
        for entry in enum_values:
            try:
                parts.append(json.dumps(entry))
            except Exception:
                parts.append(str(entry))
        return " | ".join(parts)
    raw_type = schema.get("type")
    if isinstance(raw_type, str):
        if raw_type == "object" and not isinstance(schema.get("properties"), dict) and isinstance(schema.get("additionalProperties"), dict):
            return "record"
        return raw_type
    if isinstance(raw_type, list):
        compact = [str(entry) for entry in raw_type if entry != "null"]
        if len(compact) == 1:
            if compact[0] == "object" and not isinstance(schema.get("properties"), dict) and isinstance(schema.get("additionalProperties"), dict):
                return "record"
            return compact[0]
        if compact:
            return " | ".join(compact)
    any_of = schema.get("anyOf")
    if isinstance(any_of, list) and any_of:
        parts: list[str] = []
        for option in any_of:
            option_type = _json_schema_display_type(option if isinstance(option, dict) else {})
            if option_type and option_type not in parts:
                parts.append(option_type)
        if parts:
            return " | ".join(parts)
    if isinstance(schema.get("properties"), dict):
        return "object"
    if schema.get("additionalProperties"):
        return "record"
    return "unknown"


def _index_json_schema_ids(schema: Any, out: dict[str, Dict[str, Any]] | None = None) -> dict[str, Dict[str, Any]]:
    if out is None:
        out = {}
    if not isinstance(schema, dict):
        return out
    schema_id = schema.get("$id")
    if isinstance(schema_id, str) and schema_id.strip() and schema_id not in out:
        out[schema_id] = schema
    defs = schema.get("$defs")
    if isinstance(defs, dict):
        for key, value in defs.items():
            if isinstance(value, dict):
                out.setdefault(key, value)
                _index_json_schema_ids(value, out)
    properties = schema.get("properties")
    if isinstance(properties, dict):
        for value in properties.values():
            _index_json_schema_ids(value, out)
    items = schema.get("items")
    if isinstance(items, dict):
        _index_json_schema_ids(items, out)
    any_of = schema.get("anyOf")
    if isinstance(any_of, list):
        for value in any_of:
            _index_json_schema_ids(value, out)
    additional = schema.get("additionalProperties")
    if isinstance(additional, dict):
        _index_json_schema_ids(additional, out)
    return out


def _resolve_json_schema_ref(
    schema: Dict[str, Any],
    root_schema: Dict[str, Any],
) -> Dict[str, Any] | None:
    ref = schema.get("$ref")
    if not isinstance(ref, str) or not ref.strip():
        return None
    if ref.startswith("#/$defs/"):
        key = ref.split("/", 2)[-1]
        defs = root_schema.get("$defs")
        if isinstance(defs, dict):
            value = defs.get(key)
            if isinstance(value, dict):
                return value
    index = _index_json_schema_ids(root_schema)
    resolved = index.get(ref)
    return resolved if isinstance(resolved, dict) else None


def _join_schema_field_path(parts: list[str]) -> str:
    joined: list[str] = []
    for part in parts:
        if part == "[]" and joined:
            joined[-1] = f"{joined[-1]}[]"
            continue
        joined.append(part)
    return ".".join(joined)


def _merge_schema_display_fields(fields: list[Dict[str, Any]]) -> list[Dict[str, Any]]:
    merged: dict[str, Dict[str, Any]] = {}
    for field in fields:
        name = str(field.get("name") or "").strip()
        if not name:
            continue
        existing = merged.get(name)
        if existing is None:
            merged[name] = dict(field)
            continue
        existing_desc = str(existing.get("description") or "").strip()
        next_desc = str(field.get("description") or "").strip()
        if not existing_desc and next_desc:
            existing["description"] = next_desc
        if not existing.get("required") and field.get("required"):
            existing["required"] = True
        existing_type = str(existing.get("type") or "")
        next_type = str(field.get("type") or "")
        if existing_type and next_type and existing_type != next_type:
            parts: list[str] = []
            for part in existing_type.split(" | ") + next_type.split(" | "):
                clean = part.strip()
                if clean and clean not in parts:
                    parts.append(clean)
            existing["type"] = " | ".join(parts)
    return list(merged.values())


def _collect_json_schema_display_fields(
    schema: Dict[str, Any],
    path: list[str] | None = None,
    required: bool = True,
    depth: int = 0,
    root_schema: Dict[str, Any] | None = None,
    ref_depths: dict[str, int] | None = None,
) -> list[Dict[str, Any]]:
    if not isinstance(schema, dict):
        return []
    if path is None:
        path = []
    if root_schema is None:
        root_schema = schema
    if ref_depths is None:
        ref_depths = {}
    max_depth = 10
    ref = schema.get("$ref")
    if isinstance(ref, str) and ref.strip():
        current_count = ref_depths.get(ref, 0)
        resolved = _resolve_json_schema_ref(schema, root_schema)
        if resolved is None:
            return []
        if current_count >= 2:
            schema = resolved
        else:
            next_ref_depths = dict(ref_depths)
            next_ref_depths[ref] = current_count + 1
            return _collect_json_schema_display_fields(
                resolved,
                path,
                required,
                depth,
                root_schema,
                next_ref_depths,
            )
    name = _join_schema_field_path(path)
    fields: list[Dict[str, Any]] = []
    if name:
        field: Dict[str, Any] = {
            "name": name,
            "type": _json_schema_display_type(schema),
            "required": required,
        }
        description = str(schema.get("description") or "").strip()
        if description:
            field["description"] = description
        if "default" in schema:
            field["default"] = schema.get("default")
        fields.append(field)
    if depth >= max_depth:
        return fields

    properties = schema.get("properties")
    if isinstance(properties, dict) and properties:
        required_fields = schema.get("required")
        required_names = (
            {
                str(entry)
                for entry in required_fields
            }
            if isinstance(required_fields, list)
            else set()
        )
        for key, child in properties.items():
            if not isinstance(child, dict):
                continue
            child_required = key in required_names
            fields.extend(
                _collect_json_schema_display_fields(
                    child,
                    [*path, str(key)],
                    child_required,
                    depth + 1,
                    root_schema,
                    ref_depths,
                )
            )
        return fields

    any_of = schema.get("anyOf")
    if isinstance(any_of, list) and any_of:
        option_fields: list[Dict[str, Any]] = []
        for option in any_of:
            if not isinstance(option, dict):
                continue
            option_fields.extend(
                _collect_json_schema_display_fields(
                    option,
                    path,
                    required,
                    depth + 1,
                    root_schema,
                    ref_depths,
                )
            )
        if option_fields:
            base_name = _join_schema_field_path(path)
            merged = _merge_schema_display_fields(option_fields)
            nested = [field for field in merged if str(field.get("name") or "") != base_name]
            return fields + nested
        return fields

    if schema.get("type") == "array" and isinstance(schema.get("items"), dict):
        item_fields = _collect_json_schema_display_fields(
            schema.get("items"),
            [*path, "[]"],
            False,
            depth + 1,
            root_schema,
            ref_depths,
        )
        return fields + item_fields

    return fields


def _tool_input_fields_for_display(input_schema: Dict[str, Any]) -> list[Dict[str, Any]]:
    raw_fields = input_schema.get("fields")
    explicit_fields = [field for field in raw_fields if isinstance(field, dict)] if isinstance(raw_fields, list) else []
    json_schema = input_schema.get("jsonSchema") if isinstance(input_schema.get("jsonSchema"), dict) else None
    if not json_schema:
        return explicit_fields

    derived_fields = _collect_json_schema_display_fields(json_schema)
    if not derived_fields:
        return explicit_fields

    explicit_has_nested = any("." in str(field.get("name") or "") for field in explicit_fields)
    derived_has_nested = any("." in str(field.get("name") or "") for field in derived_fields)
    explicit_complex = any(str(field.get("type") or "") in {"union", "object", "array"} for field in explicit_fields)
    if derived_has_nested and (not explicit_has_nested or explicit_complex):
        return derived_fields
    return explicit_fields


def _print_tool_details(data: Dict[str, Any], tool_id: str) -> None:
    def _coalesce_keys(*keys: str) -> Any:
        for key in keys:
            if key in data and data.get(key) is not None:
                return data.get(key)
        return None

    provider = str(data.get("provider") or "")
    operation = str(data.get("operation") or "")
    categories = data.get("categories") or []
    display_name = str(data.get("display_name") or data.get("displayName") or "")
    input_schema = data.get("input_schema") or data.get("inputSchema") or {}
    output_schema = data.get("output_schema") or {}
    cost = data.get("cost") if isinstance(data.get("cost"), dict) else None
    deepline_credits = _coalesce_keys("deepline_credits_per_pricing_unit", "deeplineCreditsPerPricingUnit")
    deepline_usd_per_pricing_unit = _coalesce_keys("deepline_usd_per_pricing_unit", "deeplineUsdPerPricingUnit")
    deepline_usd_per_credit = _coalesce_keys("deepline_usd_per_credit", "deeplineUsdPerCredit")
    deepline_pricing_summary = str(_coalesce_keys("deepline_pricing_summary", "deeplinePricingSummary") or "").strip()
    deepline_pricing_details_raw = _coalesce_keys("deepline_pricing_details", "deeplinePricingDetails") or []
    estimated_credits_range = _coalesce_keys("estimated_credits_range", "estimatedCreditsRange")
    estimated_usd_range = _coalesce_keys("estimated_usd_range", "estimatedUsdRange")
    play_expansion = _coalesce_keys("play_expansion", "playExpansion") or {}
    estimate_model_version = _coalesce_keys("estimate_model_version", "estimateModelVersion")
    estimate_based_on_tools = _coalesce_keys("estimate_based_on_tools", "estimateBasedOnTools") or []
    step_contributions = _coalesce_keys("step_contributions", "stepContributions") or []
    billing_source_label = str(_coalesce_keys("billing_source_label", "billingSourceLabel") or "").strip()
    billing_source = str(_coalesce_keys("billing_source", "billingSource") or "").strip()
    sandbox = data.get("sandbox") if isinstance(data.get("sandbox"), dict) else {}
    apify_actor_contract = data.get("apify_actor_contract") or data.get("apifyActorContract") or {}
    apify_known_actor_ids = data.get("apify_known_actor_ids") or data.get("apifyKnownActorIds") or []
    apify_known_actors = data.get("apify_known_actors") or data.get("apifyKnownActors") or []
    apify_selected_actor_id = str(data.get("apify_selected_actor_id") or data.get("apifySelectedActorId") or "").strip()
    samples = data.get("samples") or {}
    actions = data.get("actions") or []

    print(f"Tool: {tool_id}")
    if provider and operation:
        if operation.startswith(f"{provider}_"):
            base = operation[len(provider) + 1 :]
        else:
            base = f"{provider} {operation}".strip()
    else:
        base = tool_id or display_name
    if base:
        print("  Display name:")
        print(f"    {_title_case(base)}")
    if isinstance(categories, list) and categories:
        print("  Categories:")
        print(f"    {', '.join(str(c) for c in categories)}")

    free_local_tools = {"run_javascript", "call_local_codex", "call_local_claude_code"}
    printed_cost = False

    def _format_decimal(value: object) -> str | None:
        if not isinstance(value, (int, float)):
            return None
        text = f"{float(value):.12f}".rstrip("0").rstrip(".")
        return text or "0"

    def _format_usd(value: object) -> str | None:
        text = _format_decimal(value)
        return f"${text}" if text is not None else None

    def _format_actor_list(items: object) -> list[str]:
        if not isinstance(items, list):
            return []
        rendered: list[str] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            actor_id = str(item.get("actorId") or item.get("actor_id") or "").strip()
            if not actor_id:
                continue
            use_case = str(item.get("useCase") or item.get("use_case") or "").strip()
            label = str(item.get("label") or "").strip()
            parts = [part for part in (actor_id, use_case, label) if part]
            rendered.append(" | ".join(parts))
        return rendered

    def _format_known_typed_actor_list(items: object) -> list[str]:
        if not isinstance(items, list):
            return []
        rendered: list[str] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            actor_id = str(item.get("actorId") or item.get("actor_id") or "").strip()
            if not actor_id:
                continue
            use_case = str(item.get("useCase") or item.get("use_case") or "").strip()
            if use_case:
                rendered.append(f"{actor_id} ({use_case})")
            else:
                rendered.append(actor_id)
        return rendered

    if cost is not None:
        pricing_model = cost.get("pricingModel") or cost.get("pricing_model")
        billing_mode = cost.get("billingMode") or cost.get("billing_mode")
        provider_price = cost.get("providerPricePerPricingModel")
        estimate_quantity = cost.get("estimateQuantity") if isinstance(cost.get("estimateQuantity"), dict) else (
            cost.get("estimate_quantity") if isinstance(cost.get("estimate_quantity"), dict) else None
        )
        if pricing_model == "fixed" and provider_price == 0:
            print("  Cost: free")
            printed_cost = True
        elif billing_source == "own_provider_credentials":
            print("  Cost: free through Deepline")
            printed_cost = True
        elif pricing_model == "provider_usage" and billing_mode:
            print(f"  Cost: usage-based ({billing_mode})")
            notes = str(cost.get("notes") or "").strip()
            if notes:
                print(f"    {notes}")
            else:
                print("    Final charge is computed after execution from provider usage.")
            printed_cost = True
        elif pricing_model and billing_mode and isinstance(deepline_credits, (int, float)):
            unit = "call"
            if pricing_model == "per_page":
                unit = "page"
            elif pricing_model == "per_result":
                unit = "result"
            deepline_usd_text = _format_usd(deepline_usd_per_pricing_unit)
            if deepline_usd_text is not None:
                print(
                    f"  Cost: {deepline_credits} Deepline credits / {deepline_usd_text} per {unit} ({billing_mode})"
                )
            else:
                print(f"  Cost: {deepline_credits} Deepline credits per {unit} ({billing_mode})")
            printed_cost = True
        elif (
            pricing_model
            and billing_mode
            and isinstance(provider_price, (int, float))
            and not deepline_pricing_summary
        ):
            unit = "call"
            if pricing_model == "per_page":
                unit = "page"
            elif pricing_model == "per_result":
                unit = "result"
            print(f"  Cost: {provider_price} provider credits per {unit} ({billing_mode})")
            printed_cost = True
        else:
            kind = cost.get("kind") or "fixed"
            amount = cost.get("amount")
            unit = cost.get("unit") or "credit"
            if amount == 0:
                print("  Cost: free (0 credits per call)")
                printed_cost = True
            elif amount is not None:
                print(f"  Cost: {amount} {unit}(s) per call")
                printed_cost = True
            elif kind == "conditional":
                print("  Cost: conditional")
                printed_cost = True
        if isinstance(estimate_quantity, dict):
            strategy = str(estimate_quantity.get("strategy") or "").strip()
            field = str(estimate_quantity.get("field") or "").strip()
            default_value = estimate_quantity.get("defaultValue")
            description = str(estimate_quantity.get("description") or "").strip()
            if strategy and field:
                if strategy == "payload_value":
                    print(f"  Preflight estimate: billed quantity is estimated from `{field}` (default {default_value})")
                elif strategy == "payload_array_length":
                    print(f"  Preflight estimate: billed quantity is estimated from the length of `{field}` (default {default_value})")
            if description:
                print(f"    {description}")
            if (
                strategy == "payload_value"
                and field == "per_page"
                and isinstance(deepline_credits, (int, float))
            ):
                example_25 = round(25 * float(deepline_credits), 2)
                example_25_usd = (
                    round(25 * float(deepline_usd_per_pricing_unit), 12)
                    if isinstance(deepline_usd_per_pricing_unit, (int, float))
                    else None
                )
                if example_25_usd is not None:
                    print(
                        "    Example: `per_page=25` estimates about "
                        f"{example_25} Deepline credits / ${_format_decimal(example_25_usd)} "
                        "before the call runs."
                    )
                else:
                    print(
                        f"    Example: `per_page=25` estimates about {example_25} Deepline credits before the call runs."
                    )

    if not printed_cost and tool_id in free_local_tools:
        print("  Cost: free")

    if billing_source_label:
        print(f"  Billing source: {billing_source_label}")
    if isinstance(deepline_usd_per_credit, (int, float)):
        print(f"  Deepline rate: ${float(deepline_usd_per_credit):.2f} per credit")
    if deepline_pricing_summary:
        print(f"  Cost: {deepline_pricing_summary}")
    if isinstance(deepline_pricing_details_raw, list):
        deepline_pricing_details = [
            str(detail).strip()
            for detail in deepline_pricing_details_raw
            if str(detail).strip()
        ]
        if deepline_pricing_details:
            print("  Cost details:")
            for detail in deepline_pricing_details:
                print(f"    - {detail}")

    sandbox_runtime_provider = str(sandbox.get("runtimeProvider") or "").strip()
    sandbox_pricing_model = str(sandbox.get("pricingModel") or "").strip()
    sandbox_description_suffix = str(sandbox.get("descriptionSuffix") or "").strip()
    sandbox_dependency_contract = str(
        sandbox.get("defaultSnapshotDependencyContract") or ""
    ).strip()
    sandbox_dependency_highlights = (
        sandbox.get("defaultSnapshotDependencyHighlights")
        if isinstance(sandbox.get("defaultSnapshotDependencyHighlights"), list)
        else []
    )
    if (
        sandbox_runtime_provider
        or sandbox_pricing_model
        or sandbox_description_suffix
        or sandbox_dependency_contract
        or sandbox_dependency_highlights
    ):
        print("  Sandbox execution:")
        if sandbox_runtime_provider:
            print(f"    Runtime provider: {sandbox_runtime_provider}")
        if sandbox_pricing_model:
            print(f"    Pricing model: {sandbox_pricing_model}")
        if sandbox_dependency_contract:
            print(f"    Contract: {sandbox_dependency_contract}")
        if sandbox_dependency_highlights:
            print(
                "    Available by default: "
                + ", ".join(str(item).strip() for item in sandbox_dependency_highlights if str(item).strip())
            )
        if sandbox_description_suffix:
            print(f"    {sandbox_description_suffix}")

    if isinstance(apify_actor_contract, dict) and apify_actor_contract:
        actor_id = str(apify_actor_contract.get("actorId") or apify_actor_contract.get("actor_id") or "").strip()
        use_case = str(apify_actor_contract.get("useCase") or apify_actor_contract.get("use_case") or "").strip()
        pricing_model = str(apify_actor_contract.get("pricingModel") or apify_actor_contract.get("pricing_model") or "").strip()
        recommended_mode = str(apify_actor_contract.get("recommendedMode") or apify_actor_contract.get("recommended_mode") or "").strip()
        last_validated = str(apify_actor_contract.get("lastValidatedAt") or apify_actor_contract.get("last_validated_at") or "").strip()
        print("  Apify typed actor:")
        if actor_id:
            print(f"    actorId: {actor_id}")
        if use_case:
            print(f"    useCase: {use_case}")
        if pricing_model:
            print(f"    pricingModel: {pricing_model}")
        if recommended_mode:
            print(f"    recommendedMode: {recommended_mode}")
        if last_validated:
            print(f"    lastValidatedAt: {last_validated}")
    elif tool_id in {"apify_run_actor", "apify_run_actor_sync"}:
        print("  Apify typed actor:")
        print("    No typed actor selected.")
        print("    Use: deepline tools get " + tool_id + " --actor username/actor-name")
        print("    Generic mode does not know the actor-specific input shape.")
        if isinstance(apify_known_actors, list) and apify_known_actors:
            preview = _format_known_typed_actor_list(apify_known_actors)
            if preview:
                print(f"    Known typed actors: {', '.join(preview)}")
            else:
                preview = _format_actor_list(apify_known_actors)
                if preview:
                    print(f"    Available actors: {', '.join(preview)}")
        elif isinstance(apify_known_actor_ids, list) and apify_known_actor_ids:
            preview = [str(item).strip() for item in apify_known_actor_ids if str(item).strip()]
            if preview:
                print(f"    Available actors: {', '.join(preview)}")
        print("    Discovery path: apify_list_store_actors -> deepline tools get " + tool_id + " --actor username/actor-name -> apify_get_actor_input_schema (optional) -> " + tool_id)

    if isinstance(estimated_credits_range, str) and estimated_credits_range.strip():
        spend_label = estimated_credits_range.strip()
        if isinstance(estimated_usd_range, str) and estimated_usd_range.strip():
            spend_label += f" (~{estimated_usd_range.strip()})"
        print(f"  Estimated play spend: {spend_label}")
        if isinstance(estimate_model_version, str) and estimate_model_version.strip():
            print(f"    model: {estimate_model_version.strip()}")
        if isinstance(estimate_based_on_tools, list) and estimate_based_on_tools:
            rendered_tools = [str(item).strip() for item in estimate_based_on_tools if str(item).strip()]
            if rendered_tools:
                print(f"    based on: {', '.join(rendered_tools)}")
        if isinstance(step_contributions, list) and step_contributions:
            print("    step contributions:")
            for item in step_contributions:
                if not isinstance(item, dict):
                    continue
                step_tool = str(item.get("tool") or "").strip()
                low = item.get("lowCredits")
                high = item.get("highCredits")
                low_usd = item.get("lowUsd")
                high_usd = item.get("highUsd")
                if step_tool and isinstance(low, (int, float)) and isinstance(high, (int, float)):
                    usd_suffix = ""
                    if isinstance(low_usd, (int, float)) and isinstance(high_usd, (int, float)):
                        usd_suffix = f" (~${float(low_usd):.2f}-${float(high_usd):.2f})"
                    print(f"      - {step_tool}: {low}-{high} credits{usd_suffix}")

    if isinstance(play_expansion, dict) and play_expansion:
        group = str(play_expansion.get("group") or "").strip()
        steps = play_expansion.get("steps") if isinstance(play_expansion.get("steps"), list) else []
        print("  Play expansion:")
        if group:
            print(f"    group: {group}")
        for step in steps:
            if not isinstance(step, dict):
                continue
            block_type = str(step.get("type") or "").strip()
            if block_type == "waterfall":
                alias = str(step.get("alias") or "").strip()
                min_results = step.get("min_results")
                header = f"    - waterfall {alias}" if alias else "    - waterfall"
                if isinstance(min_results, int):
                    header += f" (min_results={min_results})"
                print(header)
                inner_steps = step.get("steps") if isinstance(step.get("steps"), list) else []
                for inner_step in inner_steps:
                    if not isinstance(inner_step, dict):
                        continue
                    inner_alias = str(inner_step.get("alias") or "").strip()
                    inner_tool = str(inner_step.get("tool") or "").strip()
                    if inner_alias and inner_tool:
                        print(f"      * {inner_alias}: {inner_tool}")
                continue
            if block_type == "step":
                inner_step = step.get("step") if isinstance(step.get("step"), dict) else {}
                alias = str(inner_step.get("alias") or "").strip()
                step_tool = str(inner_step.get("tool") or "").strip()
                if alias and step_tool:
                    print(f"    - step {alias}: {step_tool}")

    fields = _tool_input_fields_for_display(input_schema) if isinstance(input_schema, dict) else []
    if isinstance(fields, list) and fields:
        print("  Inputs (operation-specific):")
        for field in fields:
            if not isinstance(field, dict):
                continue
            name = str(field.get("name") or "")
            type_name = str(field.get("type") or "unknown")
            required_label = "required" if field.get("required") else "optional"
            default_suffix = ""
            if "default" in field:
                try:
                    default_suffix = f", default: {json.dumps(field.get('default'))}"
                except Exception:
                    default_suffix = f", default: {field.get('default')}"
            desc = str(field.get("description") or "")
            suffix = f" - {desc}" if desc else ""
            print(f"    - {name} ({type_name}, {required_label}{default_suffix}){suffix}")
        print("  Tip: pass --payload with a JSON object.")
    elif isinstance(input_schema, dict) and input_schema.get("description"):
        print("  Inputs (operation-specific):")
        print(f"    {input_schema.get('description')}")
        print("  Tip: pass --payload with a JSON object.")

    output_description = ""
    if isinstance(output_schema, dict):
        output_description = str(output_schema.get("description") or "").strip()
    if not output_description and isinstance(actions, list):
        for action in actions:
            if not isinstance(action, dict):
                continue
            content = action.get("content")
            if not isinstance(content, str) or "### Result JSON Schema" not in content:
                continue
            marker_pos = content.find("### Result JSON Schema")
            fence_start = content.find("```json", marker_pos)
            fence_end = content.find("```", fence_start + len("```json")) if fence_start >= 0 else -1
            if fence_start < 0 or fence_end < 0:
                continue
            json_block = content[fence_start + len("```json") : fence_end].strip()
            if not json_block:
                continue
            try:
                parsed = json.loads(json_block)
            except Exception:
                continue
            if isinstance(parsed, dict):
                desc = parsed.get("description")
                if isinstance(desc, str) and desc.strip():
                    output_description = desc.strip()
                    break
    if output_description:
        print("  Notes:")
        print(f"    {output_description}")

    request = samples.get("request") if isinstance(samples, dict) else None
    response = samples.get("response") if isinstance(samples, dict) else None
    request_payload = None
    if isinstance(request, dict):
        request_payload = request.get("payload")
        if request_payload is None:
            request_payload = request
    response_payload = None
    if isinstance(response, dict):
        response_payload = response.get("payload")
        if response_payload is None:
            response_payload = response

    if isinstance(request, dict) or isinstance(response, dict):
        print("  Samples:")
        if isinstance(request, dict):
            _print_json_preview("Example payload", request_payload)
        if isinstance(response, dict):
            _print_json_preview("Example response", response_payload)

    if _is_play_tool(data):
        print("  Play contract:")
        print("    - This is a deepline-native waterfall; the returned rows are extracted by target getters, not by hand-authored payload shape.")
        if isinstance(play_expansion, dict) and play_expansion:
            group = str(play_expansion.get("group") or "").strip()
            if group:
                print(f"    - Output alias/runtime group is: {group}")
        result_identity_getters = data.get("resultIdentityGetters") or {}
        if isinstance(result_identity_getters, dict) and result_identity_getters:
            printable_targets = [
                str(key) for key in result_identity_getters.keys() if key
            ]
            if printable_targets:
                print("    - Built-in extract targets:", ", ".join(sorted(printable_targets)))

    async_get_action = data.get("asyncGetAction") or data.get("async_get_action")
    if isinstance(async_get_action, str) and async_get_action.strip():
        print("  Async follow-up:")
        print(f"    Use `{async_get_action.strip()}` to fetch the final result if this returns a pending job/run id.")

    print("")
    print("Usage:")
    request_payload = request.get("payload") if isinstance(request, dict) else None
    if request_payload is None and isinstance(request, dict):
        request_payload = request
    if _is_play_tool(data):
        if request_payload is not None:
            compact = json.dumps(
                {"alias": "result", "tool": tool_id, "payload": request_payload},
                separators=(",", ":"),
                ensure_ascii=False,
            )
            print(f"  deepline enrich --with '{compact}'")
        else:
            print(f"  deepline enrich --with '{{\"alias\":\"result\",\"tool\":\"{tool_id}\",\"payload\":{{...}}}}'")
    elif request_payload is not None:
        compact = json.dumps(request_payload, separators=(",", ":"), ensure_ascii=False)
        print(f"  deepline tools execute {tool_id} --payload '{compact}'")
    elif tool_id in {"apify_run_actor", "apify_run_actor_sync"} and not apify_selected_actor_id:
        print(f"  deepline tools get {tool_id} --actor username/actor-name")
        print(f"  deepline tools execute apify_list_store_actors --payload '{{\"search\":\"linkedin jobs scraper\",\"limit\":10}}'")
        print(f"  deepline tools execute {tool_id} --payload '{{\"actorId\":\"username/actor-name\",\"input\":{{...}}}}'")
    else:
        print(f"  deepline tools execute {tool_id} --payload '{{...}}'")
    print("  deepline tools get <tool_id> --json  # full machine-readable output")


@router.route(
    "list",
    summary="List available tools.",
    usage="deepline tools list [PREFIX] [--prefix PREFIX] [--json]",
    options=[
        OptionSpec("--prefix", "Filter by prefix.", takes_value=True, value_name="PREFIX"),
        OptionSpec("--json", "Emit JSON output."),
    ],
)
def cmd_tools_list(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    if "--help" in args or "-h" in args:
        print("Usage:")
        print("  deepline tools list [PREFIX] [--prefix PREFIX] [--json]")
        return EXIT_OK

    prefix = ""
    output_json = False
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in {"--search", "--filter"}:
            print("Removed: deepline tools list --search is no longer supported.", file=sys.stderr)
            print('Use: deepline tools search "<query>"', file=sys.stderr)
            print("Usage:", file=sys.stderr)
            print("  deepline tools search QUERY [--prefix PREFIX] [--json]", file=sys.stderr)
            return EXIT_USAGE
        if arg == "--json":
            output_json = True
            i += 1
            continue
        if arg == "--prefix":
            if i + 1 >= len(args):
                print("Missing value for --prefix")
                return EXIT_USAGE
            prefix = args[i + 1]
            i += 2
            continue
        if arg.startswith("--"):
            print(f"Unknown tools list option: {arg}")
            return EXIT_USAGE
        if not prefix:
            prefix = arg
            i += 1
            continue
        print(f"Unknown tools list option: {arg}")
        return EXIT_USAGE

    missing = require_api_key(env)
    if missing is not None:
        return missing

    list_url = f"{base_url}/api/v2/integrations/list"
    try:
        status, body = http_request(
            "GET",
            list_url,
            env.get("DEEPLINE_API_KEY"),
            timeout=60,
            deadline_timeout=60,
        )
    except RuntimeError as exc:
        _record_tools_network_failure(exc, stage="tools_list")
        print(str(exc))
        return EXIT_NETWORK
    if status in (401, 403):
        print(f"Auth error (status {status}). Check DEEPLINE_API_KEY.")
        return EXIT_AUTH
    if status >= 400:
        print(f"Tools list failed (status {status}).")
        return EXIT_SERVER

    try:
        data = json.loads(body)
    except Exception:
        print(body)
        return EXIT_OK

    search_fallback_to_category = bool(data.get("search_fallback_to_category"))
    tools_raw = data.get("tools")
    tools = [t for t in tools_raw if isinstance(t, dict)] if isinstance(tools_raw, list) else []
    search_fallback_to_category = bool(data.get("search_fallback_to_category"))
    local_tool_ids = ["run_javascript", "read_file", "call_local_claude_code", "call_local_codex"]
    for tool_id in local_tool_ids:
        raw = _local_tool_get_json(tool_id)
        if not raw:
            continue
        try:
            local_tool = json.loads(raw)
        except Exception:
            continue
        local_id = str(local_tool.get("toolId") or local_tool.get("tool_id") or "")
        if local_id and all(str(t.get("toolId") or t.get("tool_id") or "") != local_id for t in tools):
            tools.insert(0, local_tool)

    if prefix:
        pref = prefix.lower()
        tools = [t for t in tools if str(t.get("toolId") or t.get("tool_id") or "").lower().startswith(pref)]

    if output_json:
        out = dict(data) if isinstance(data, dict) else {}
        out["tools"] = tools
        print(json.dumps(out))
        return EXIT_OK

    if not prefix:
        print("Tip: Use search for ranked results, e.g. 'deepline tools search email verify'.")
    print("Try 'deepline tools get <tool_id>' to get more info about the interesting tools.")
    if prefix:
        print(f"Prefix: {prefix}")
    print("")
    print("Tools:")
    if not tools:
        print("[]")
    for tool in tools:
        tool_id = str(tool.get("toolId") or tool.get("tool_id") or "")
        print(f"- {_tool_summary_line(tool)}")
        apify_custom_actors = tool.get("apifyCustomActors") or tool.get("apify_custom_actors") or []
        if tool_id in {"apify_run_actor", "apify_run_actor_sync", "apify_list_store_actors"} and isinstance(apify_custom_actors, list) and apify_custom_actors:
            rendered_custom_actors = []
            for item in apify_custom_actors[:8]:
                if not isinstance(item, dict):
                    continue
                actor_id = str(item.get("actorId") or item.get("actor_id") or "").strip()
                label = str(item.get("label") or "").strip()
                if actor_id and label and label != actor_id:
                    rendered_custom_actors.append(f"{actor_id} ({label})")
                elif actor_id:
                    rendered_custom_actors.append(actor_id)
            if rendered_custom_actors:
                print("  Your Apify actors:")
                print(f"    {', '.join(rendered_custom_actors)}")
    return EXIT_OK


@router.route(
    "search",
    summary="Search tools by query.",
    usage="deepline tools search [QUERY] [--prefix PREFIX] [--categories LIST] [--search_terms LIST] [--json] [--search-mode v1|v2]",
    options=[
        OptionSpec("--prefix", "Filter by prefix.", takes_value=True, value_name="PREFIX"),
        OptionSpec("--categories", "Comma-separated tool categories to filter before ranking.", takes_value=True, value_name="LIST"),
        OptionSpec("--search_terms", "Comma-separated ranking hints added to the query.", takes_value=True, value_name="LIST"),
        OptionSpec("--search-mode", "Use v1 or v2 ranking. Defaults to v2.", takes_value=True, value_name="MODE"),
        OptionSpec("--json", "Emit JSON output."),
    ],
)
def cmd_tools_search(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    if "--help" in args or "-h" in args:
        print("Usage:")
        print("  deepline tools search [QUERY] [--prefix PREFIX] [--categories LIST] [--search_terms LIST] [--json] [--search-mode v1|v2]")
        print("")
        print("Tip: use --categories to constrain tool type; use --search_terms for short intent hints.")
        print("")
        print("Common categories:")
        print(f"  {', '.join(TOOLS_SEARCH_COMMON_CATEGORIES)}")
        print("Good searches:")
        print("  deepline tools search --categories company_search --search_terms \"investors,funding\"")
        print("  deepline tools search --categories people_search --search_terms \"title filters,linkedin\"")
        print("Avoid:")
        print("  deepline tools search stuff")
        print("  deepline tools search search across filters")
        print("Examples:")
        print("  deepline tools search --categories company_search --search_terms \"structured filters,firmographics\"")
        print("  deepline tools search --categories research --search_terms \"ads,technographics\"")
        return EXIT_OK

    prefix = ""
    categories = ""
    search_terms = ""
    search_mode = "v2"
    output_json = False
    full = False
    query_parts: list[str] = []
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--prefix":
            if i + 1 >= len(args):
                print("Missing value for --prefix")
                return EXIT_USAGE
            prefix = args[i + 1]
            i += 2
            continue
        if arg == "--categories":
            if i + 1 >= len(args):
                print("Missing value for --categories")
                return EXIT_USAGE
            categories = args[i + 1].strip()
            i += 2
            continue
        if arg == "--search_terms":
            if i + 1 >= len(args):
                print("Missing value for --search_terms")
                return EXIT_USAGE
            search_terms = args[i + 1].strip()
            i += 2
            continue
        if arg == "--search-mode":
            if i + 1 >= len(args):
                print("Missing value for --search-mode")
                return EXIT_USAGE
            requested_mode = args[i + 1].strip().lower()
            if requested_mode not in {"v1", "v2"}:
                print("Invalid value for --search-mode. Use v1 or v2.")
                return EXIT_USAGE
            search_mode = requested_mode
            i += 2
            continue
        if arg == "--json":
            output_json = True
            i += 1
            continue
        if arg == "--query":
            if i + 1 >= len(args):
                print("Missing value for --query")
                return EXIT_USAGE
            query_parts.append(args[i + 1])
            i += 2
            continue
        if arg.startswith("--"):
            print(f"Unknown tools search option: {arg}")
            return EXIT_USAGE
        query_parts.append(arg)
        i += 1

    query = " ".join(part.strip() for part in query_parts if part.strip()).strip()
    if not query and not search_terms and not categories:
        print("Missing search query, --search_terms, or --categories.")
        return EXIT_USAGE

    missing = require_api_key(env)
    if missing is not None:
        return missing

    encoded_query = urllib.parse.quote(query, safe="")
    include_search_debug = "false"
    if output_json or search_terms or query:
        include_search_debug = "true"
    query_params = [
        f"q={encoded_query}",
        f"include_search_debug={include_search_debug}",
        f"search_mode={search_mode}",
    ]
    if categories:
        query_params.append(f"categories={urllib.parse.quote(categories, safe='')}")
    if search_terms:
        query_params.append(f"search_terms={urllib.parse.quote(search_terms, safe='')}")
    list_url = f"{base_url}/api/v2/integrations/list?{'&'.join(query_params)}"
    try:
        status, body = http_request(
            "GET",
            list_url,
            env.get("DEEPLINE_API_KEY"),
            timeout=60,
            deadline_timeout=60,
        )
    except RuntimeError as exc:
        _record_tools_network_failure(exc, stage="tools_search")
        print(str(exc))
        return EXIT_NETWORK
    if status in (401, 403):
        print(f"Auth error (status {status}). Check DEEPLINE_API_KEY.")
        return EXIT_AUTH
    if status >= 400:
        print(f"Tools search failed (status {status}).")
        return EXIT_SERVER

    try:
        data = json.loads(body)
    except Exception:
        print(body)
        return EXIT_OK

    search_fallback_to_category = bool(data.get("search_fallback_to_category"))
    tools_raw = data.get("tools")
    tools = [t for t in tools_raw if isinstance(t, dict)] if isinstance(tools_raw, list) else []
    ranked: list[tuple[float, int, Dict[str, Any]]] = []
    unranked: list[tuple[int, Dict[str, Any]]] = []
    for idx, tool in enumerate(tools):
        raw_score = tool.get("search_score")
        if isinstance(raw_score, (int, float)):
            ranked.append((float(raw_score), idx, tool))
        else:
            unranked.append((idx, tool))
    ranked.sort(key=lambda item: (-item[0], item[1]))
    matched = [item[2] for item in ranked] + [item[1] for item in unranked]
    if prefix:
        pref = prefix.lower()
        matched = [t for t in matched if str(t.get("toolId") or t.get("tool_id") or "").lower().startswith(pref)]
    full_matched = list(matched)
    total_matches = len(matched)
    truncated = 0
    should_truncate = (not output_json) and bool(query or search_terms)
    if should_truncate and len(matched) > 8:
        matched = matched[:8]
        truncated = total_matches - len(matched)

    if output_json:
        out = dict(data) if isinstance(data, dict) else {}
        out["tools"] = matched
        print(json.dumps(out))
        return EXIT_OK

    print("Try 'deepline tools get <tool_id>' to get more info about the interesting tools.")
    if query:
        print(f"Search: {query}")
    else:
        print("Search: <none>")
    print("Mode: compact search output")
    if categories:
        print(f"Categories: {categories}")
    if search_terms:
        print(f"Search terms: {search_terms}")
    if search_fallback_to_category and search_terms:
        print("No literal term matches found in this category subset; showing category matches instead.")
    if truncated > 0:
        print(f"Showing top {len(matched)} of {total_matches} matches.")
    print("")
    print("Tools:")
    if not matched:
        if categories:
            unknown_categories, suggestions = _unknown_category_hints(categories)
            if unknown_categories:
                print(f"No tools matched category filter: {', '.join(unknown_categories)}")
                if suggestions:
                    print(f"Did you mean: {', '.join(suggestions)}")
                print(f"Known categories: {', '.join(TOOLS_SEARCH_COMMON_CATEGORIES)}")
                print("")
        print("[]")
    for tool in matched:
        tool_id = str(tool.get("toolId") or tool.get("tool_id") or "")
        categories_list = tool.get("categories")
        categories_text = ""
        if isinstance(categories_list, list) and categories_list:
            categories_text = f" [{', '.join(str(c) for c in categories_list[:2])}]"
        print(f"- {tool_id}{categories_text}")
        matches = tool.get("search_matches")
        if isinstance(matches, list) and matches:
            condensed: list[str] = []
            for item in matches[:3]:
                if not isinstance(item, dict):
                    continue
                field = str(item.get("field") or "").replace("searchCorpus.", "").replace("inputSchema.", "")
                value = str(item.get("value") or "").strip()
                matched_term = str(item.get("term") or "").strip()
                if not value:
                    continue
                snippet = _condense_search_match_value(value, search_terms, query, matched_term)
                snippet = _highlight_search_terms(snippet, search_terms, query, matched_term)
                condensed.append(f"{field}: {snippet}")
            if condensed:
                print(f"    matches: {' | '.join(condensed)}")
        if tool_id in {"apify_run_actor", "apify_run_actor_sync", "apify_list_store_actors"}:
            apify_actors = tool.get("apifyCustomActors") or tool.get("apify_custom_actors") or []
            rendered = []
            if isinstance(apify_actors, list):
                for item in apify_actors:
                    if not isinstance(item, dict):
                        continue
                    actor_id = str(item.get("actorId") or item.get("actor_id") or "").strip()
                    if not actor_id:
                        continue
                    use_case = str(item.get("useCase") or item.get("use_case") or "").strip()
                    label = str(item.get("label") or "").strip()
                    parts = [part for part in (actor_id, use_case, label) if part]
                    rendered.append(" | ".join(parts))
            if rendered:
                print(f"    Available actors: {', '.join(rendered)}")
    print("")
    if truncated > 0:
        provider_tail = _render_provider_tail_summary(matched, full_matched[len(matched):], query)
        if provider_tail:
            print("More providers:")
            for line in provider_tail:
                print(line)
            print("")
    if not full:
        return EXIT_OK

    print("Tools Details:")
    for tool in matched:
        tool_id = str(tool.get("toolId") or tool.get("tool_id") or "")
        print(f"- {_tool_summary_line(tool)}")
        if _is_play_tool(tool):
            print("  Search enrichment example:")
        else:
            print("  Search execute example:")
        execute_example = _build_search_execute_example(tool, query)
        if execute_example:
            print(f"    {execute_example}")
        else:
            if _is_play_tool(tool):
                print(f"    deepline enrich --with '{{\"alias\":\"result\",\"tool\":\"{tool_id}\",\"payload\":{{...}}}}'")
            else:
                print(f"    deepline tools execute {tool_id} --payload '{{...}}' --json")
        if not full:
            useful_inputs = _extract_useful_inputs(tool, max_items=3)
            if useful_inputs:
                print("  Useful inputs:")
                print(f"    {', '.join(useful_inputs)}")
    return EXIT_OK


@router.route("get", "describe", summary="Get full details for a specific tool.", usage="deepline tools get <tool_id> [--json]")
def cmd_tools_get(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    if not args:
        print("Missing tool_id")
        return EXIT_USAGE

    import argparse

    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("tool_id")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--actor")
    parsed = parser.parse_args(args)

    tool_id = normalize_tool_id(parsed.tool_id)
    if _dev_only_local_tool_requested(base_url, tool_id):
        print(f"Unknown tool: {tool_id}")
        _print_fuzzy_tool_suggestions(tool_id, _list_known_tool_ids(base_url, env))
        return EXIT_NOT_FOUND
    if parsed.actor and tool_id not in {"apify_run_actor", "apify_run_actor_sync"}:
        print("--actor on tools get is only supported for apify_run_actor and apify_run_actor_sync.")
        return EXIT_USAGE

    if is_local_tool(tool_id):
        payload = _local_tool_get_json(tool_id)
        if not payload:
            print(f"Unknown tool: {tool_id}")
            _print_fuzzy_tool_suggestions(tool_id, _list_known_tool_ids(base_url, env))
            return EXIT_NOT_FOUND
        if parsed.json:
            print(payload)
            return EXIT_OK
        data = json.loads(payload)
        resolved = str(data.get("tool_id") or data.get("toolId") or tool_id)
        _print_tool_details(data, resolved)
        return EXIT_OK

    missing = require_api_key(env)
    if missing is not None:
        return missing

    api_url = build_tool_get_url(base_url, tool_id)
    if parsed.actor:
        separator = "&" if "?" in api_url else "?"
        api_url += f"{separator}actor={urllib.parse.quote(parsed.actor, safe='')}"

    try:
        status, raw = http_request("GET", api_url, env.get("DEEPLINE_API_KEY"))
    except RuntimeError as exc:
        _record_tools_network_failure(exc, stage="tools_get")
        print(str(exc))
        return EXIT_NETWORK

    if status in (401, 403):
        print(f"Auth error (status {status}). Check DEEPLINE_API_KEY.")
        return EXIT_AUTH
    if status == 404:
        print(f"Unknown tool: {tool_id}")
        _print_fuzzy_tool_suggestions(tool_id, _list_known_tool_ids(base_url, env))
        return EXIT_NOT_FOUND
    if status >= 400:
        print(f"Tools get failed (status {status}).")
        if raw:
            print(raw)
        return EXIT_SERVER

    if parsed.json:
        print(raw)
        return EXIT_OK

    try:
        data = json.loads(raw)
    except Exception:
        print(raw)
        return EXIT_OK
    resolved = str(data.get("tool_id") or data.get("toolId") or tool_id)
    _print_tool_details(data, resolved)
    return EXIT_OK


@router.route(
    "execute",
    summary="Execute a tool with payload.",
    usage="deepline tools execute <tool_id> --payload JSON [--json] [--payload-output-format auto|csv|csv_file|json|json_file] [--wait] [--debug] [--wait-timeout SECONDS] [--poll-interval SECONDS] [--timeout SECONDS] [--connect-timeout SECONDS]",
    options=[
        OptionSpec("--payload", "JSON payload object.", takes_value=True, value_name="JSON"),
        OptionSpec("--json", "Emit JSON output."),
        OptionSpec(
            "--payload-output-format",
            "Output payload format: auto (default), csv/csv_file, json/json_file.",
            takes_value=True,
            value_name="auto|csv|csv_file|json|json_file",
        ),
        OptionSpec("--wait", "Enable wait mode."),
        OptionSpec("--debug", "Enable debug wait mode."),
        OptionSpec("--wait-timeout", "Set wait timeout in seconds.", takes_value=True, value_name="SECONDS"),
        OptionSpec("--poll-interval", "Set wait poll interval in seconds.", takes_value=True, value_name="SECONDS"),
        OptionSpec("--timeout", "Set request timeout in seconds.", takes_value=True, value_name="SECONDS"),
        OptionSpec("--connect-timeout", "Set connection timeout in seconds.", takes_value=True, value_name="SECONDS"),
        OptionSpec("--no-preview", "Disable response preview output."),
    ],
)
def cmd_tools_execute(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    if args and (args[0] in {"help", "-h", "--help"} or "--help" in args or "-h" in args):
        print("Usage:")
        print(
            "  deepline tools execute <tool_id> --payload JSON [--json] [--payload-output-format auto|csv|csv_file|json|json_file] [--wait] [--debug] [--wait-timeout SECONDS] [--poll-interval SECONDS] [--timeout SECONDS] [--connect-timeout SECONDS] [--no-preview]"
        )
        print("")
        print("Options:")
        print("  --payload JSON           JSON payload object.")
        print("  --payload-output-format  auto|csv|csv_file|json|json_file    Output format for payload output. default: auto")
        print("  --json                   Emit JSON output.")
        print("  --wait                   Enable wait mode.")
        print("  --debug                  Enable debug wait mode.")
        print("  --wait-timeout SECONDS    Set wait timeout in seconds.")
        print("  --poll-interval SECONDS   Set wait poll interval in seconds.")
        print("  --timeout SECONDS         Set request timeout in seconds.")
        print("  --connect-timeout SECONDS  Set connection timeout in seconds.")
        print("  --no-preview             Disable response preview output.")
        return EXIT_OK

    if not args:
        print("Missing tool_id.")
        return EXIT_USAGE

    output_json = False
    no_preview = False
    wait = False
    debug = False
    wait_timeout = 300
    poll_interval = 2
    request_timeout = 40
    connect_timeout = 40
    request_timeout_explicit = False
    payload_raw = "{}"
    payload_output_format = "auto"
    # Parse args manually for legacy compatibility and alias support.
    it = iter(range(len(args)))
    tool_id = ""
    i = 0
    accepted_value_flags = {"--wait-timeout", "--poll-interval", "--timeout", "--connect-timeout"}
    accepted_bool_flags = {"--json", "--wait", "--debug", "--no-preview"}
    payload_from_stdin = False
    all_accepted_flags = accepted_bool_flags | accepted_value_flags | {"--payload", "--payload-stdin", "--payload-output-format"}
    while i < len(args):
        arg = args[i]
        if arg == "--json":
            output_json = True
            i += 1
            continue
        if arg == "--payload-output-format":
            if i + 1 >= len(args):
                print("Missing value for --payload-output-format.")
                return EXIT_USAGE
            normalized_value = _normalize_payload_output_format(args[i + 1])
            if normalized_value is None:
                print("Invalid value for --payload-output-format.")
                return EXIT_USAGE
            payload_output_format = normalized_value
            i += 2
            continue
        if arg == "--wait":
            wait = True
            i += 1
            continue
        if arg == "--debug":
            debug = True
            wait = True
            i += 1
            continue
        if arg in accepted_value_flags:
            if i + 1 >= len(args):
                print(f"Missing value for {arg}.")
                return EXIT_USAGE
            value_raw = args[i + 1]
            try:
                if arg == "--wait-timeout":
                    wait_timeout = _to_positive_int(value_raw, "--wait-timeout")
                elif arg == "--poll-interval":
                    poll_interval = _to_positive_int(value_raw, "--poll-interval")
                elif arg == "--timeout":
                    request_timeout = _to_positive_int(value_raw, "--timeout")
                    request_timeout_explicit = True
                elif arg == "--connect-timeout":
                    connect_timeout = _to_positive_int(value_raw, "--connect-timeout")
            except ValueError as exc:
                print(str(exc))
                return EXIT_USAGE
            i += 2
            continue
        if any(arg.startswith(f + "=") for f in accepted_value_flags):
            flag, value_raw = arg.split("=", 1)
            try:
                if flag == "--wait-timeout":
                    wait_timeout = _to_positive_int(value_raw, "--wait-timeout")
                elif flag == "--poll-interval":
                    poll_interval = _to_positive_int(value_raw, "--poll-interval")
                elif flag == "--timeout":
                    request_timeout = _to_positive_int(value_raw, "--timeout")
                    request_timeout_explicit = True
                elif flag == "--connect-timeout":
                    connect_timeout = _to_positive_int(value_raw, "--connect-timeout")
            except ValueError as exc:
                print(str(exc))
                return EXIT_USAGE
            i += 1
            continue
        if arg.startswith("--payload-output-format="):
            normalized_value = _normalize_payload_output_format(arg.split("=", 1)[1])
            if normalized_value is None:
                print("Invalid value for --payload-output-format.")
                return EXIT_USAGE
            payload_output_format = normalized_value
            i += 1
            continue
        if arg == "--no-preview":
            no_preview = True
            i += 1
            continue
        if arg == "--actor":
            print("--actor is not supported for tools execute. Set payload.actorId instead.")
            return EXIT_USAGE
        if arg == "--payload-stdin":
            payload_from_stdin = True
            i += 1
            continue
        if arg == "--payload":
            if i + 1 >= len(args):
                print("Missing value for --payload.")
                return EXIT_USAGE
            payload_raw = args[i + 1]
            i += 2
            continue
        if arg.startswith("--payload="):
            payload_raw = arg.split("=", 1)[1]
            i += 1
            continue
        if arg.startswith("--"):
            if arg == "--job" or arg.startswith("--job="):
                print("Cloud job CLI execution is disabled.")
                return EXIT_USAGE
            print(f"Unknown option: {arg}")
            print(f"Valid options: {', '.join(sorted(all_accepted_flags))}")
            return EXIT_USAGE
        if not tool_id:
            tool_id = arg
            i += 1
            continue
        print(f"Unknown option: {arg}")
        print(f"Valid options: {', '.join(sorted(all_accepted_flags))}")
        return EXIT_USAGE

    if not tool_id:
        print("Missing tool_id.")
        return EXIT_USAGE

    # Without this, `json_file` + `> file` writes a bare path that silently fails `json.load()`.
    if payload_output_format == "json_file" and not output_json and not sys.stdout.isatty():
        output_json = True

    normalized = normalize_tool_id(tool_id)
    if normalized.startswith("apify_") and not request_timeout_explicit:
        request_timeout = 300
    if _dev_only_local_tool_requested(base_url, normalized):
        print(f"Unknown tool: {normalized}")
        return EXIT_NOT_FOUND
    if payload_from_stdin:
        import sys as _sys
        payload_raw = _sys.stdin.read()
    try:
        payload = json.loads(payload_raw)
    except Exception:
        print("Invalid JSON in --payload.")
        return EXIT_VALIDATION
    if not isinstance(payload, dict):
        print("Invalid JSON in --payload.")
        return EXIT_VALIDATION

    # Resolve session_id via JSONL detection (not PPID) so billing events
    # are always routed to the correct session-scoped state.
    try:
        from deepline_core.commands.session import _resolve_cli_session_id
        execute_session_id: str | None = str(_resolve_cli_session_id() or "").strip() or None
    except Exception:
        execute_session_id = None

    def _emit_tool_execute_event(
        *,
        billing: dict[str, float] | None = None,
        csv_path: str | None = None,
        csv_rows: int | None = None,
    ) -> None:
        """Notify the Session UI about a completed tools-execute call."""
        meta: dict[str, Any] = {
            "tool_id": normalized,
            "with_specs": [{"tool": normalized, "payload": payload}],
        }
        if csv_rows is not None:
            meta["result_count"] = csv_rows
        if billing:
            meta["billing"] = billing
        append_cli_event(
            source="tools_execute",
            status="completed",
            kind="tool_execute",
            message=f"Executed {normalized}",
            csv_path=csv_path,
            meta=meta,
            session_id=execute_session_id,
        )

    missing = require_api_key(env)
    if missing is not None:
        return missing

    session_limit = _check_tools_execute_session_limit()
    if session_limit and bool(session_limit.get("exceeded")):
        used = float(session_limit.get("used", 0.0) or 0.0)
        limit = float(session_limit.get("limit", 0.0) or 0.0)
        limit_message = (
            f"Session spending limit reached (${used:.2f} / ${limit:.2f}). "
            "Increase or clear it with: deepline session limit --dollars <amount>"
        )
        append_cli_event(
            source="tools_execute",
            status="failed",
            kind="tool_execute",
            message=limit_message,
            meta={
                "tool_id": normalized,
                "blocked_by_session_limit": True,
                "session_limit": {
                    "used": used,
                    "limit": limit,
                },
            },
            session_id=execute_session_id,
        )
        print(limit_message)
        return EXIT_SERVER

    try:
        meta_timeout = min(request_timeout, connect_timeout) if connect_timeout > 0 else request_timeout
        status, raw_meta = http_request(
            "GET",
            build_tool_get_url(base_url, normalized),
            env.get("DEEPLINE_API_KEY"),
            timeout=meta_timeout,
            connect_timeout=connect_timeout,
        )
    except RuntimeError as exc:
        _record_tools_network_failure(exc, stage="tools_execute_metadata")
        print(str(exc))
        return EXIT_NETWORK
    if status in (401, 403):
        print(f"Auth error (status {status}). Check DEEPLINE_API_KEY.")
        return EXIT_AUTH
    if status == 404:
        print(f"Unknown tool: {normalized} (status 404).")
        _print_unknown_tool_hints(normalized)
        _print_fuzzy_tool_suggestions(normalized, _list_known_tool_ids(base_url, env, timeout=meta_timeout))
        return EXIT_NOT_FOUND
    if status >= 400:
        if output_json:
            _render_execute_error(status, raw_meta, True, "get")
        else:
            _render_execute_error(status, raw_meta, False, "get")
        return EXIT_SERVER

    try:
        meta = json.loads(raw_meta)
    except Exception:
        print("Failed to resolve tool metadata.")
        return EXIT_SERVER

    provider = meta.get("provider") or ""
    operation = meta.get("operation") or ""
    if not provider or not operation:
        print("Tool metadata missing provider/operation.")
        return EXIT_SERVER
    extractor_paths = meta.get("list_extractor_paths") or meta.get("listExtractorPaths") or []
    if not isinstance(extractor_paths, list):
        extractor_paths = []

    execute_body = {
        "provider": provider,
        "operation": operation,
        "payload": payload,
    }
    raw_env_metadata = str(os.environ.get("DEEPLINE_EXECUTE_METADATA_JSON", "") or "").strip()
    if raw_env_metadata:
        try:
            parsed_env_metadata = json.loads(raw_env_metadata)
        except Exception:
            parsed_env_metadata = None
        if isinstance(parsed_env_metadata, dict):
            existing_metadata = execute_body.get("metadata")
            metadata = dict(existing_metadata) if isinstance(existing_metadata, dict) else {}
            for key, value in parsed_env_metadata.items():
                if key not in metadata:
                    metadata[key] = value
            if metadata:
                execute_body["metadata"] = metadata

    try:
        status, raw_response = http_request(
            "POST",
            build_tool_execute_url(base_url, normalized),
            env.get("DEEPLINE_API_KEY"),
            execute_body,
            timeout=request_timeout,
            connect_timeout=connect_timeout,
        )
    except RuntimeError as exc:
        _record_tools_network_failure(exc, stage="tools_execute")
        if normalized == "apify_run_actor_sync" and _is_network_timeout_error(exc):
            _print_apify_sync_cli_timeout_error(
                exc,
                request_timeout=request_timeout,
            )
            return EXIT_NETWORK
        print(str(exc))
        return EXIT_NETWORK

    if status >= 400:
        _render_execute_error(status, raw_response, output_json)
        if (status in (400, 422)) and (not output_json) and (not _response_has_validation_issues(raw_response)):
            _print_input_schema_hints(normalized, raw_meta)
        if status in (400, 422):
            return EXIT_VALIDATION
        if status in (401, 403):
            return EXIT_AUTH
        if status == 404:
            if not output_json:
                _print_unknown_tool_hints(normalized)
                _print_fuzzy_tool_suggestions(normalized, _list_known_tool_ids(base_url, env, timeout=request_timeout))
            return EXIT_NOT_FOUND
        return EXIT_SERVER

    try:
        response = json.loads(raw_response)
    except Exception:
        response = {}
    response = _strip_identity_match_payload(response)
    execute_billing = _extract_execute_billing(response)

    embedded = _extract_embedded_status(response)
    if embedded is not None:
        _render_execute_error(embedded, raw_response, output_json)
        if (embedded in (400, 422)) and (not output_json) and (not _response_has_validation_issues(raw_response)):
            _print_input_schema_hints(normalized, raw_meta)
        if embedded in (400, 422):
            return EXIT_VALIDATION
        if embedded in (401, 403):
            return EXIT_AUTH
        if embedded == 404:
            if not output_json:
                _print_unknown_tool_hints(normalized)
                _print_fuzzy_tool_suggestions(normalized, _list_known_tool_ids(base_url, env, timeout=request_timeout))
            return EXIT_NOT_FOUND
        return EXIT_SERVER

    async_get_action = str(meta.get("asyncGetAction") or meta.get("async_get_action") or "").strip()
    async_get_meta = None
    if async_get_action:
        async_get_meta = _fetch_tool_metadata(
            base_url,
            str(env.get("DEEPLINE_API_KEY") or ""),
            async_get_action,
            timeout=meta_timeout,
            connect_timeout=connect_timeout,
        )

    if wait and normalized == "apify_run_actor":
        run_id, _ = _extract_apify_run_context(raw_response)
        if not _apify_wait_and_debug(
            base_url=base_url,
            token=str(env.get("DEEPLINE_API_KEY") or ""),
            run_id=run_id,
            debug_mode=debug,
            wait_timeout=wait_timeout,
            poll_interval=poll_interval,
            timeout=request_timeout,
        ):
            if output_json:
                print(json.dumps(response))
            else:
                _render_execute_output(normalized, response)
                if async_get_meta:
                    _print_async_followup_hint(async_get_meta, response, payload if isinstance(payload, dict) else {})
            return EXIT_SERVER
    elif wait and normalized != "apify_run_actor":
        # --wait is only meaningful for async Apify actor jobs. Silently
        # no-op for every other tool rather than polluting stderr/stdout.
        pass

    if output_json:
        if no_preview:
            _emit_tool_execute_event(billing=execute_billing)
            print(json.dumps(response))
            return EXIT_OK
        # Try parquet download for large result sets before CSV extraction
        csv_result = _try_extract_rows_csv(response, normalized)
        if csv_result is not None:
            csv_path, csv_rows, csv_columns = csv_result
            _emit_tool_execute_event(billing=execute_billing, csv_path=csv_path, csv_rows=csv_rows)
            out = _merge_execute_json_output(
                response,
                {
                    "extracted_csv": csv_path,
                    "extracted_csv_rows": csv_rows,
                    "extracted_csv_columns": csv_columns,
                    "preview": f"(streamed CSV, {csv_rows} rows)",
                },
            )
            print(json.dumps(out))
            return EXIT_OK
        extracted = _extract_csv_rows(response, extractor_paths)
        if payload_output_format == "json_file":
            _emit_tool_execute_event(billing=execute_billing)
            json_path = _write_json(response, normalized)
            print(json.dumps(_merge_execute_json_output(response, {"payload_file": json_path})))
        elif payload_output_format == "csv_file":
            if extracted:
                csv_path, csv_rows, csv_columns = _write_csv(extracted, normalized)
                _emit_tool_execute_event(
                    billing=execute_billing,
                    csv_path=csv_path,
                    csv_rows=csv_rows,
                )
                preview = _build_csv_preview(extracted, csv_columns)
                out = _merge_execute_json_output(
                    response,
                    {
                        "extracted_csv": csv_path,
                        "extracted_csv_rows": csv_rows,
                        "extracted_csv_columns": csv_columns,
                        "preview": preview,
                    },
                )
                print(json.dumps(out))
            else:
                _emit_tool_execute_event(billing=execute_billing)
                json_path = _write_json(response, normalized)
                print(json.dumps(_merge_execute_json_output(response, {"payload_file": json_path})))
        else:
            if extracted:
                csv_path, csv_rows, csv_columns = _write_csv(extracted, normalized)
                _emit_tool_execute_event(
                    billing=execute_billing,
                    csv_path=csv_path,
                    csv_rows=csv_rows,
                )
                preview = _build_csv_preview(extracted, csv_columns)
                out = _merge_execute_json_output(
                    response,
                    {
                        "extracted_csv": csv_path,
                        "extracted_csv_rows": csv_rows,
                        "extracted_csv_columns": csv_columns,
                        "preview": preview,
                    },
                )
                print(json.dumps(out))
            else:
                _emit_tool_execute_event(billing=execute_billing)
                print(json.dumps(response))
        return EXIT_OK

    # Try parquet download for large result sets before CSV extraction
    csv_result = _try_extract_rows_csv(response, normalized)
    if csv_result is not None:
        csv_path, csv_rows, csv_columns = csv_result
        _emit_tool_execute_event(billing=execute_billing, csv_path=csv_path, csv_rows=csv_rows)
        if not no_preview:
            print(f"{csv_path} ({csv_rows} rows)")
            if csv_columns:
                print(f"columns: {json.dumps(csv_columns)}")
            print(f"preview: \"(downloaded from parquet, {csv_rows} rows)\"")
        else:
            print(csv_path)
        return EXIT_OK

    extracted = _extract_csv_rows(response, extractor_paths)
    if payload_output_format == "json_file":
        _emit_tool_execute_event(billing=execute_billing)
        json_path = _write_json(response, normalized)
        print(json_path)
        return EXIT_OK
    if extracted:
        csv_path, csv_rows, columns = _write_csv(extracted, normalized)
        _emit_tool_execute_event(
            billing=execute_billing,
            csv_path=csv_path,
            csv_rows=csv_rows,
        )
        if not no_preview:
            print(f"{csv_path} ({csv_rows} rows)")
            if columns:
                print(f"columns: {json.dumps(columns)}")
            print(f"preview: {json.dumps(_build_csv_preview(extracted, columns))}")
        else:
            print(csv_path)
        return EXIT_OK
    if payload_output_format == "csv_file":
        _emit_tool_execute_event(billing=execute_billing)
        json_path = _write_json(response, normalized)
        print(json_path)
        return EXIT_OK

    result_size = _serialized_result_size(response.get("result"))
    if not no_preview and result_size > MAX_INLINE_RESULT_CHARS:
        _emit_tool_execute_event(billing=execute_billing)
        json_path = _write_json(response, normalized)
        status = response.get("status") or response.get("job_status") or response.get("state") or "(unknown)"
        job_id = response.get("job_id") or response.get("jobId")
        print(f"Status: {status}")
        if job_id is not None:
            print(f"Job ID: {job_id}")
        print("Result too large for terminal output; wrote full payload to:")
        print(json_path)
        for line in _build_large_result_preview(response):
            print(line)
        if async_get_meta:
            _print_async_followup_hint(async_get_meta, response, payload if isinstance(payload, dict) else {})
        return EXIT_OK

    _emit_tool_execute_event(billing=execute_billing)
    _render_execute_output(normalized, response)
    if async_get_meta:
        _print_async_followup_hint(async_get_meta, response, payload if isinstance(payload, dict) else {})
    return EXIT_OK


def _set_nested_field(target: Dict[str, Any], path: str, value: Any) -> None:
    parts = [part for part in str(path or "").split(".") if part]
    if not parts:
        return
    current: Dict[str, Any] = target
    for part in parts[:-1]:
        existing = current.get(part)
        if not isinstance(existing, dict):
            existing = {}
            current[part] = existing
        current = existing
    current[parts[-1]] = value




handle = build_command_handler(
    command_name="tools",
    router=router,
    usage_factory=usage_tools_computed,
)
