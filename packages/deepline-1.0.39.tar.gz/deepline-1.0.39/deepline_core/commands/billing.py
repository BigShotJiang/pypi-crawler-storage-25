from __future__ import annotations

import csv
import json
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict

from deepline_core.browser import open_url_in_browser
from deepline_core.command_decorators import OptionSpec, ParsedRouteOptions, SubcommandRouter
from deepline_core.command_common import require_api_key
from deepline_core.command_common import EXIT_AUTH, EXIT_OK, EXIT_SERVER, EXIT_USAGE
from deepline_core.http import http_request

router = SubcommandRouter()


def usage_billing_computed() -> list[str]:
    return router.usage_lines("deepline billing")


def _format_billing_error(status: int, body: str) -> None:
    if status in (401, 403):
        print(f"Auth error (status {status}). Check DEEPLINE_API_KEY.", file=sys.stderr)
        return
    print(f"API error (status {status}).", file=sys.stderr)
    try:
        parsed = json.loads(body)
        if isinstance(parsed, dict):
            if parsed.get("error"):
                print(parsed.get("error"), file=sys.stderr)
                return
            if parsed.get("message"):
                print(parsed.get("message"), file=sys.stderr)
            if parsed.get("details"):
                print(f"Details: {parsed.get('details')}", file=sys.stderr)
            return
    except Exception:
        pass
    if body:
        print(body, file=sys.stderr)


@dataclass(frozen=True)
class JsonOnly:
    output_json: bool


def parse_json_only(parsed: ParsedRouteOptions) -> JsonOnly:
    return JsonOnly(output_json=bool(parsed.options.get("json")))


def _coerce_float(value: object) -> float | None:
    try:
        parsed = float(value)
    except Exception:
        return None
    return parsed if parsed == parsed else None


def _format_deepline_credits(value: object) -> str:
    return f"{value} Deepline Credits"


def _format_deepline_credits_with_usd(
    credits: object,
    rough_usd: object,
    *,
    free_label: str = "free",
) -> str:
    credits_value = _coerce_float(credits)
    rough_usd_value = _coerce_float(rough_usd)
    if credits_value is not None and credits_value <= 0:
        return free_label
    base_label = _format_deepline_credits(credits)
    if rough_usd_value is None:
        return base_label
    return f"{base_label} (~${rough_usd_value:.2f})"


_HISTORY_WINDOWS: dict[str, tuple[int, str]] = {
    "1d": (24 * 60 * 60, "last 24 hours"),
    "1w": (7 * 24 * 60 * 60, "last 7 days"),
    "1m": (30 * 24 * 60 * 60, "last 30 days"),
    "1y": (365 * 24 * 60 * 60, "last 365 days"),
}


@dataclass(frozen=True)
class BillingHistoryParams:
    time_window: str
    output_path: str | None
    output_json: bool


def parse_billing_history(parsed: ParsedRouteOptions) -> BillingHistoryParams:
    raw_time_window = str(parsed.options.get("time") or "").strip().lower()
    if raw_time_window not in _HISTORY_WINDOWS:
        raise ValueError("Invalid --time value. Use one of: 1d, 1w, 1m, 1y.")
    raw_output_path = str(parsed.options.get("output") or "").strip()
    return BillingHistoryParams(
        time_window=raw_time_window,
        output_path=raw_output_path or None,
        output_json=bool(parsed.options.get("json")),
    )


def _default_billing_history_path(time_window: str) -> Path:
    timestamp = time.strftime("%Y%m%d-%H%M%S", time.localtime())
    return (Path.cwd() / "deepline" / "data" / f"billing-history-{time_window}-{timestamp}.csv").resolve()


def _normalize_csv_value(value: object) -> str:
    return str(value).strip() if value is not None else ""


@dataclass(frozen=True)
class UsageParams:
    output_json: bool
    limit: int | None
    offset: int


def parse_usage_params(parsed: ParsedRouteOptions) -> UsageParams:
    raw_limit = str(parsed.options.get("limit") or "").strip()
    raw_offset = str(parsed.options.get("offset") or "").strip()

    limit: int | None = None
    if raw_limit:
        if not raw_limit.isdigit():
            raise ValueError(f"Invalid limit value: {raw_limit} (must be a positive integer).")
        limit = int(raw_limit)
        if limit <= 0:
            raise ValueError(f"Invalid limit value: {limit} (must be > 0).")

    offset = 0
    if raw_offset:
        if not raw_offset.isdigit():
            raise ValueError(f"Invalid offset value: {raw_offset} (must be a non-negative integer).")
        offset = int(raw_offset)

    return UsageParams(
        output_json=bool(parsed.options.get("json")),
        limit=limit,
        offset=offset,
    )


def _humanize_operation_name(value: str | None) -> str:
    trimmed = str(value or "").strip()
    if not trimmed:
        return "Unknown operation"
    parts = [part for part in trimmed.split("_") if part]
    if len(parts) > 1:
        parts = parts[1:]
    normalized = " ".join(parts) if parts else trimmed
    return " ".join(token.capitalize() for token in normalized.split())


def _humanize_provider_name(value: str | None) -> str | None:
    trimmed = str(value or "").strip()
    if not trimmed:
        return None
    return " ".join(token.capitalize() for token in trimmed.split("_") if token)


def _format_relative_time(value: str | None) -> str:
    from datetime import datetime, timezone

    raw = str(value or "").strip()
    if not raw:
        return "(unknown)"
    try:
        normalized = raw.replace("Z", "+00:00")
        timestamp = datetime.fromisoformat(normalized)
        if timestamp.tzinfo is None:
            timestamp = timestamp.replace(tzinfo=timezone.utc)
        now = datetime.now(timezone.utc)
        seconds = max(0, int((now - timestamp).total_seconds()))
    except Exception:
        return raw

    if seconds < 60:
        return "now"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m"
    hours = minutes // 60
    if hours < 24:
        return f"{hours}h"
    days = hours // 24
    return f"{days}d"


def _format_recent_usage_entries(entries: object) -> list[str]:
    if not isinstance(entries, list) or not entries:
        return ["Recent activity: none yet"]

    lines = ["Recent activity (grouped when possible):"]
    for item in entries:
        if not isinstance(item, dict):
            continue
        operation = _humanize_operation_name(item.get("operation"))
        provider = _humanize_provider_name(item.get("provider"))
        if provider and operation:
            provider_norm = provider.strip().lower()
            operation_norm = operation.strip().lower()
            if (
                operation_norm == provider_norm
                or operation_norm.startswith(f"{provider_norm} ")
                or provider_norm.startswith(f"{operation_norm} ")
            ):
                operation_label = provider if len(provider) >= len(operation) else operation
            else:
                operation_label = f"{provider} {operation}".strip()
        else:
            operation_label = provider or operation
        raw_batch_count = item.get("batch_count")
        try:
            batch_count = int(raw_batch_count)
        except Exception:
            batch_count = 0
        if batch_count > 1:
            operation_label = f"{operation_label} x{batch_count}"
        raw_credits = item.get("credits", 0)
        credits_value = _coerce_float(raw_credits) or 0.0
        billing_mode = str(item.get("billing_mode") or "").strip().lower()
        rough_usd_cost = item.get("rough_usd_cost")
        charge_label = (
            "free"
            if billing_mode == "no_bill" or credits_value == 0
            else _format_deepline_credits_with_usd(raw_credits, rough_usd_cost)
        )
        status = str(item.get("status") or "").strip()
        when = _format_relative_time(item.get("created_at"))
        request_id = str(item.get("request_id") or "").strip()
        detail = f"{status}" if status else "completed"
        if request_id:
            detail = f"{detail}, {request_id}"
        lines.append(f"  {operation_label} | {charge_label} | {when} | {detail}")
    return lines


@router.route_typed("balance", summary="Show current billing balance.", usage="deepline billing balance [--json]", options=[OptionSpec("--json", "Emit raw JSON response.", key="json")], params_parser=parse_json_only)
def handle_balance(base_url: str, env: Dict[str, str], params: JsonOnly) -> int:
    status, body = http_request("GET", f"{base_url}/api/v2/billing/balance", env.get("DEEPLINE_API_KEY"))
    if status >= 400:
        _format_billing_error(status, body)
        return EXIT_AUTH if status in (401, 403) else EXIT_SERVER
    if params.output_json:
        print(body)
        return EXIT_OK
    try:
        parsed = json.loads(body)
    except Exception:
        print(body)
        return EXIT_OK

    balance = parsed.get("balance")
    balance_display = str(parsed.get("balance_display") or "").strip()
    balance_status = parsed.get("balance_status", "")
    has_payment = parsed.get("has_payment_method", False)
    rough_usd_balance = _coerce_float(parsed.get("rough_usd_balance"))

    if balance_status == "no_billing":
        print(f"Balance: {_format_deepline_credits(0)}")
        print("Billing: No billing account or payment method set up for this workspace.")
        print("  Run 'deepline billing checkout' to add credits.")
    elif balance_status == "zero_balance" and not has_payment:
        print(f"Balance: {_format_deepline_credits(0)}")
        print("  Run 'deepline billing checkout' to add credits.")
    else:
        display_value = balance_display or _format_deepline_credits(balance)
        print(f"Balance: {display_value}")
        if rough_usd_balance is not None:
            print(f"Approx. USD balance: ${rough_usd_balance:.2f}")
    return EXIT_OK


@dataclass(frozen=True)
class SetLimitParams:
    credits: int
    output_json: bool


def parse_set_limit(parsed: ParsedRouteOptions) -> SetLimitParams:
    raw = str(parsed.options.get("credits") or "").strip()
    if not raw or not raw.isdigit():
        raise ValueError(f"Invalid credits value: {raw or '(missing)'} (must be a positive integer).")
    credits = int(raw)
    if credits <= 0:
        raise ValueError(f"Invalid credits value: {credits} (must be > 0).")
    return SetLimitParams(credits=credits, output_json=bool(parsed.options.get("json")))


@router.route_typed(
    "--set-monthly-limit",
    summary="Set monthly credit cap.",
    usage="deepline billing --set-monthly-limit <credits> [--json]",
    options=[
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
        OptionSpec("--credits", "Monthly credits limit (>0).", takes_value=True, value_name="N", key="credits"),
    ],
    params_parser=parse_set_limit,
)
def handle_set_limit(base_url: str, env: Dict[str, str], params: SetLimitParams) -> int:
    status, body = http_request(
        "PUT",
        f"{base_url}/api/v2/billing/limit",
        env.get("DEEPLINE_API_KEY"),
        {"monthly_credits_limit": params.credits},
    )
    if status >= 400:
        _format_billing_error(status, body)
        return EXIT_AUTH if status in (401, 403) else EXIT_SERVER
    if params.output_json:
        print(body or "{}")
        return EXIT_OK
    print(f"Monthly billing limit set to {_format_deepline_credits(params.credits)}.")
    return handle_usage(base_url, env, UsageParams(output_json=False, limit=None, offset=0))


@router.route_typed("--off", summary="Disable monthly credit cap.", usage="deepline billing --off [--json]", options=[OptionSpec("--json", "Emit raw JSON response.", key="json")], params_parser=parse_json_only)
def handle_off(base_url: str, env: Dict[str, str], params: JsonOnly) -> int:
    status, body = http_request("DELETE", f"{base_url}/api/v2/billing/limit", env.get("DEEPLINE_API_KEY"))
    if status >= 400:
        _format_billing_error(status, body)
        return EXIT_AUTH if status in (401, 403) else EXIT_SERVER
    if params.output_json:
        print(body or "{}")
        return EXIT_OK
    print("Monthly billing limit is now off.")
    return handle_usage(base_url, env, UsageParams(output_json=False, limit=None, offset=0))


@router.route_typed(
    "usage",
    summary="Show current usage plus recent calls.",
    usage="deepline billing usage [--limit <N>] [--offset <N>] [--json]",
    options=[
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
        OptionSpec("--limit", "Recent-call page size.", takes_value=True, value_name="N", key="limit"),
        OptionSpec("--offset", "Recent-call offset.", takes_value=True, value_name="N", key="offset"),
    ],
    params_parser=parse_usage_params,
)
def handle_usage(base_url: str, env: Dict[str, str], params: UsageParams) -> int:
    query_parts: list[str] = []
    if params.limit is not None:
        query_parts.append(f"recent_limit={params.limit}")
    if params.offset > 0:
        query_parts.append(f"recent_offset={params.offset}")
    suffix = f"?{'&'.join(query_parts)}" if query_parts else ""
    status, body = http_request("GET", f"{base_url}/api/v2/billing/usage{suffix}", env.get("DEEPLINE_API_KEY"))
    if status >= 400:
        _format_billing_error(status, body)
        return EXIT_AUTH if status in (401, 403) else EXIT_SERVER
    if params.output_json:
        print(body)
        return EXIT_OK
    try:
        parsed = json.loads(body)
    except Exception:
        print(body)
        return EXIT_OK
    balance_display = str(parsed.get("balance_display") or "").strip()
    rough_usd_balance = _coerce_float(parsed.get("rough_usd_balance"))
    balance_value = parsed.get("balance", "(unknown)")
    print(f"Balance: {balance_display or _format_deepline_credits(balance_value)}")
    if rough_usd_balance is not None:
        print(f"Approx. USD balance: ${rough_usd_balance:.2f}")
    usage = parsed.get("usage", {}) or {}
    quota = parsed.get("quota", {}) or {}
    print(
        "Last 30 days spent: "
        + _format_deepline_credits_with_usd(
            usage.get("month_spent_credits", "(unknown)"),
            usage.get("rough_usd_spent"),
            free_label=_format_deepline_credits(0),
        )
    )
    if usage.get("period_start_at") and usage.get("period_end_at"):
        print(f"Period: {usage.get('period_start_at')} to {usage.get('period_end_at')}")
    if quota.get("enabled"):
        print(
            "Monthly limit: "
            + _format_deepline_credits_with_usd(
                quota.get("monthly_credits_limit", "(unknown)"),
                quota.get("monthly_rough_usd_limit"),
                free_label=_format_deepline_credits(0),
            )
        )
        print(
            "Remaining before cap: "
            + _format_deepline_credits_with_usd(
                quota.get("remaining_credits", "(unknown)"),
                quota.get("remaining_rough_usd"),
                free_label=_format_deepline_credits(0),
            )
        )
    else:
        print("Monthly limit: off")
    recent = parsed.get("recent", {}) or {}
    for line in _format_recent_usage_entries(recent.get("entries")):
        print(line)
    if recent.get("total") is not None:
        shown = len(recent.get("entries", []) or [])
        offset = int(recent.get("offset") or 0)
        next_offset = int(recent.get("next_offset") or (offset + shown))
        raw_events_on_page = max(0, next_offset - offset)
        print(
            f"Showing {shown} visible rows representing {raw_events_on_page} raw events "
            f"(events {offset + 1}-{next_offset} of {recent.get('total')})"
        )
        if recent.get("has_more"):
            print(
                "Next page of raw activity: deepline billing usage "
                f"--offset {next_offset}"
                + (f" --limit {params.limit}" if params.limit is not None else "")
            )
    return EXIT_OK


@router.route_typed(
    "history",
    summary="Export billing ledger history for the current org to CSV.",
    usage="deepline billing history --time {1d|1w|1m|1y} [--output PATH] [--json]",
    options=[
        OptionSpec("--time", "Rolling time window to export: 1d, 1w, 1m, or 1y.", takes_value=True, value_name="WINDOW", key="time"),
        OptionSpec("--output", "Write CSV to an explicit path.", takes_value=True, value_name="PATH", key="output"),
        OptionSpec("--json", "Emit JSON output with file path and row count.", key="json"),
    ],
    params_parser=parse_billing_history,
)
def handle_history(base_url: str, env: Dict[str, str], params: BillingHistoryParams) -> int:
    window_seconds, window_label = _HISTORY_WINDOWS[params.time_window]
    since_at = max(0, int(time.time()) - window_seconds) * 1000
    status, body = http_request(
        "GET",
        f"{base_url}/api/v2/billing/ledger?since_at={since_at}&limit=5000",
        env.get("DEEPLINE_API_KEY"),
    )
    if status >= 400:
        _format_billing_error(status, body)
        return EXIT_AUTH if status in (401, 403) else EXIT_SERVER

    try:
        parsed = json.loads(body)
    except Exception:
        print("Failed to parse billing history response.", file=sys.stderr)
        return EXIT_SERVER

    entries = parsed.get("entries")
    if not isinstance(entries, list):
        print("Billing history response did not include entries.", file=sys.stderr)
        return EXIT_SERVER

    output_path = Path(params.output_path).expanduser().resolve() if params.output_path else _default_billing_history_path(params.time_window)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    fieldnames = ["created_at", "delta_credits", "reason", "provider", "operation"]
    row_count = 0
    with output_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            metadata = entry.get("metadata")
            metadata_obj = metadata if isinstance(metadata, dict) else {}
            writer.writerow(
                {
                    "created_at": _normalize_csv_value(entry.get("created_at")),
                    "delta_credits": _normalize_csv_value(entry.get("delta")),
                    "reason": _normalize_csv_value(entry.get("reason")),
                    "provider": _normalize_csv_value(metadata_obj.get("provider")),
                    "operation": _normalize_csv_value(metadata_obj.get("operation")),
                }
            )
            row_count += 1

    result = {
        "output_path": str(output_path),
        "row_count": row_count,
        "time_window": params.time_window,
    }
    if params.output_json:
        print(json.dumps(result))
        return EXIT_OK

    print(f"Billing history written to {output_path}")
    print(f"{row_count} row(s) exported for {window_label}.")
    return EXIT_OK


@router.route_typed("limit", summary="Show configured limit state.", usage="deepline billing limit [--json]", options=[OptionSpec("--json", "Emit raw JSON response.", key="json")], params_parser=parse_json_only)
def handle_limit(base_url: str, env: Dict[str, str], params: JsonOnly) -> int:
    status, body = http_request("GET", f"{base_url}/api/v2/billing/limit", env.get("DEEPLINE_API_KEY"))
    if status >= 400:
        _format_billing_error(status, body)
        return EXIT_AUTH if status in (401, 403) else EXIT_SERVER
    if params.output_json:
        print(body)
        return EXIT_OK
    try:
        parsed = json.loads(body)
    except Exception:
        print(body)
        return EXIT_OK
    if bool(parsed.get("enabled")):
        print(
            "Monthly limit: "
            + _format_deepline_credits_with_usd(
                parsed.get("monthly_credits_limit", "(unknown)"),
                parsed.get("monthly_rough_usd_limit"),
                free_label=_format_deepline_credits(0),
            )
        )
        if parsed.get("remaining_credits") is not None:
            print(
                "Remaining before cap: "
                + _format_deepline_credits_with_usd(
                    parsed.get("remaining_credits"),
                    parsed.get("remaining_rough_usd"),
                    free_label=_format_deepline_credits(0),
                )
            )
    else:
        print("Monthly limit: off")
    if parsed.get("updated_at"):
        print(f"Updated at: {parsed.get('updated_at')}")
    return EXIT_OK


@dataclass(frozen=True)
class CheckoutParams:
    tier_id: str | None
    credits: int | None
    discount_code: str | None
    output_json: bool
    no_open: bool


def parse_checkout(parsed: ParsedRouteOptions) -> CheckoutParams:
    raw_tier = str(parsed.options.get("tier") or "").strip()
    raw_credits = str(parsed.options.get("credits") or "").strip()
    raw_discount_code = str(parsed.options.get("discount_code") or "").strip()

    tier_id = raw_tier or None
    credits = None
    if raw_credits:
        if not raw_credits.isdigit():
            raise ValueError(f"Invalid credits value: {raw_credits} (must be a positive integer).")
        credits = int(raw_credits)
        if credits <= 0:
            raise ValueError(f"Invalid credits value: {credits} (must be > 0).")

    if tier_id and credits is not None:
        raise ValueError("Choose either --tier <TIER_ID> or --credits <N>, not both.")
    if not tier_id and credits is None and not raw_discount_code:
        raise ValueError("Missing checkout amount. Pass --tier <TIER_ID>, --credits <N>, or --discount-code <CODE>.")

    return CheckoutParams(
        tier_id=tier_id,
        credits=credits,
        discount_code=raw_discount_code or None,
        output_json=bool(parsed.options.get("json")),
        no_open=bool(parsed.options.get("no_open")),
    )


@router.route_typed(
    "checkout",
    summary="Create a checkout session and open it in your browser.",
    usage="deepline billing checkout [--tier <TIER_ID> | --credits <N>] [--discount-code <CODE>] [--no-open] [--json]",
    options=[
        OptionSpec("--tier", "Named pricing tier (for example: starter).", takes_value=True, value_name="TIER_ID", key="tier"),
        OptionSpec("--credits", "Custom credit amount.", takes_value=True, value_name="N", key="credits"),
        OptionSpec("--discount-code", "Apply a Stripe checkout discount code. Some codes can infer the credit amount automatically.", takes_value=True, value_name="CODE", key="discount_code"),
        OptionSpec("--no-open", "Print the checkout URL without opening a browser.", key="no_open"),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=parse_checkout,
)
def handle_checkout(base_url: str, env: Dict[str, str], params: CheckoutParams) -> int:
    payload: Dict[str, object] = {}
    if params.tier_id:
        payload["tierId"] = params.tier_id
    if params.credits is not None:
        payload["credits"] = params.credits
    if params.discount_code:
        payload["discountCode"] = params.discount_code

    status, body = http_request(
        "POST",
        f"{base_url}/api/v2/billing/checkout",
        env.get("DEEPLINE_API_KEY"),
        payload,
    )
    if status >= 400:
        _format_billing_error(status, body)
        return EXIT_AUTH if status in (401, 403) else EXIT_SERVER
    if params.output_json:
        print(body)
        return EXIT_OK
    try:
        parsed = json.loads(body)
    except Exception:
        print(body)
        return EXIT_OK

    checkout_url = str(parsed.get("checkout_url") or "").strip()
    if not checkout_url:
        print("Checkout URL missing from API response.", file=sys.stderr)
        return EXIT_SERVER

    print(f"Checkout URL: {checkout_url}")
    if params.no_open:
        print("Open the URL above to complete checkout.")
        return EXIT_OK
    try:
        open_url_in_browser(checkout_url)
        print("Opened checkout in your browser.")
    except Exception:
        print("Could not open your browser automatically. Open the URL above to complete checkout.")
    return EXIT_OK


@dataclass(frozen=True)
class RedeemCodeParams:
    code: str
    output_json: bool
    no_open: bool


def parse_redeem_code(parsed: ParsedRouteOptions) -> RedeemCodeParams:
    code = str(parsed.options.get("code") or "").strip()
    if not code:
        raise ValueError("Missing --code <CODE>.")
    return RedeemCodeParams(
        code=code,
        output_json=bool(parsed.options.get("json")),
        no_open=bool(parsed.options.get("no_open")),
    )


@router.route_typed(
    "redeem-code",
    summary="Open Stripe checkout with a discount code applied.",
    usage="deepline billing redeem-code --code <CODE> [--no-open] [--json]",
    options=[
        OptionSpec("--code", "Discount code to apply at checkout.", takes_value=True, value_name="CODE", key="code"),
        OptionSpec("--no-open", "Print the checkout URL without opening a browser.", key="no_open"),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=parse_redeem_code,
)
def handle_redeem_code(base_url: str, env: Dict[str, str], params: RedeemCodeParams) -> int:
    return handle_checkout(
        base_url,
        env,
        CheckoutParams(
            tier_id=None,
            credits=None,
            discount_code=params.code,
            output_json=params.output_json,
            no_open=params.no_open,
        ),
    )


def _billing_unknown(base_url: str, env: Dict[str, str], args: list[str]) -> int:
  if not args:
    return EXIT_OK
  print(f"Unknown billing command: {args[0]}")
  return EXIT_USAGE

def handle(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    if not args or args[0] in {"-h", "--help", "help"}:
        for line in usage_billing_computed():
            print(line)
        return EXIT_OK

    if len(args) > 1 and any(token in {"-h", "--help", "help"} for token in args[1:]):
        routed = router.dispatch(args[0], base_url, env, args[1:])
        if routed is not None:
            return routed

    missing = require_api_key(env)
    if missing is not None:
        return missing

    normalized_args = list(args)
    # Preserve legacy form: deepline billing --set-monthly-limit 5000
    if (
        normalized_args
        and normalized_args[0] == "--set-monthly-limit"
        and len(normalized_args) > 1
        and not str(normalized_args[1]).startswith("--")
    ):
        normalized_args = [
            "--set-monthly-limit",
            "--credits",
            str(normalized_args[1]),
            *normalized_args[2:],
        ]

    if normalized_args and normalized_args[0] == "limit":
        limit_unknown = [arg for arg in normalized_args[1:] if arg != "--json"]
        if limit_unknown:
            print(f"Unknown billing limit option: {limit_unknown[0]}", file=sys.stderr)
            return EXIT_USAGE

    routed = router.dispatch(normalized_args[0], base_url, env, normalized_args[1:])
    if routed is not None:
        return routed
    return _billing_unknown(base_url, env, normalized_args)
