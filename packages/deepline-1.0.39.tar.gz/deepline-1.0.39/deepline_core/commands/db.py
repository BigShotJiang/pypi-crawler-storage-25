from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from typing import Dict

from deepline_core.command_common import EXIT_AUTH, EXIT_NETWORK, EXIT_OK, EXIT_SERVER, require_api_key
from deepline_core.command_decorators import OptionSpec, ParsedRouteOptions, SubcommandRouter, build_command_handler
from deepline_core.failure_reporting import set_cli_failure_context
from deepline_core.http import http_request
from deepline_core.network_failures import classify_network_failure_exception

router = SubcommandRouter()


def usage_db_computed() -> list[str]:
    return router.usage_lines("deepline customer-db")


@dataclass(frozen=True)
class QueryParams:
    sql: str
    max_rows: int | None
    output_json: bool


def _parse_query(parsed: ParsedRouteOptions) -> QueryParams:
    sql = str(parsed.options.get("sql") or "").strip()
    if not sql:
        raise ValueError("Missing --sql SQL.")

    max_rows_value = parsed.options.get("max_rows")
    max_rows = None
    if max_rows_value is not None:
        try:
            parsed_value = int(str(max_rows_value).strip())
        except Exception:
            raise ValueError("--max-rows must be a positive integer.")
        if parsed_value < 1:
            raise ValueError("--max-rows must be at least 1.")
        max_rows = parsed_value

    return QueryParams(sql=sql, max_rows=max_rows, output_json=bool(parsed.options.get("json")))


def _build_workflow_hint(params: QueryParams) -> str:
    payload: Dict[str, int | str] = {"sql": params.sql}
    if params.max_rows is not None:
        payload["max_rows"] = params.max_rows
    return (
        "Workflow hint: "
        f"deepline tools execute query_customer_db --payload {json.dumps(payload)} --json"
    )


def _parse_json_object(raw: str) -> dict | None:
    try:
        payload = json.loads(raw)
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


@router.route_typed(
    "query",
    "psql",
    summary="Run an SQL query against the tenant cloud DB.",
    usage='deepline customer-db query --sql "SQL" [--max-rows N] [--json]',
    options=[
        OptionSpec("--sql", "Tenant SQL statement.", takes_value=True, value_name="SQL", key="sql"),
        OptionSpec("--max-rows", "Limit returned rows (positive integer, default: 1000).", takes_value=True, value_name="N", key="max_rows"),
        OptionSpec("--json", "Emit raw JSON response.", key="json"),
    ],
    params_parser=_parse_query,
)
def handle_query(base_url: str, env: Dict[str, str], params: QueryParams) -> int:
    missing = require_api_key(env)
    if missing is not None:
        return missing

    body: Dict[str, int | str] = {"sql": params.sql}
    if params.max_rows is not None:
        body["max_rows"] = params.max_rows

    try:
        status, raw = http_request(
            "POST",
            f"{base_url}/api/v2/db/query",
            env.get("DEEPLINE_API_KEY"),
            body,
            timeout=60,
        )
    except RuntimeError as exc:
        set_cli_failure_context(
            failure_code=classify_network_failure_exception(exc),
            failure_stage="db_query",
            failure_message=str(exc),
        )
        print(str(exc), file=sys.stderr)
        return EXIT_NETWORK

    query_payload = _parse_json_object(raw)
    if status >= 400:
        if query_payload is not None:
            message = str(query_payload.get("error") or query_payload.get("message") or "").strip()
            details = query_payload.get("details")
            if message:
                print(message, file=sys.stderr)
            if isinstance(details, str) and details.strip():
                print(details.strip(), file=sys.stderr)
            elif isinstance(details, list):
                for detail in details:
                    if isinstance(detail, dict):
                        path = str(detail.get("path") or "").strip()
                        msg = str(detail.get("message") or "").strip()
                        if path and msg:
                            print(f"{path}: {msg}", file=sys.stderr)
                        elif msg:
                            print(msg, file=sys.stderr)
        elif raw:
            print(raw, file=sys.stderr)

        if status in (401, 403):
            return EXIT_AUTH
        return EXIT_SERVER

    if query_payload is None:
        print("customer-db query failed: unexpected db API response.", file=sys.stderr)
        if raw:
            print(raw, file=sys.stderr)
        return EXIT_SERVER

    if params.output_json:
        print(json.dumps(query_payload, separators=(",", ":")))
        return EXIT_OK

    print(_build_workflow_hint(params), file=sys.stderr)
    rows = query_payload.get("rows")
    if isinstance(rows, list) and rows:
        for row in rows:
            print(json.dumps(row, sort_keys=True))
        truncated = query_payload.get("truncated")
        if truncated:
            print(f"Truncated to {query_payload.get('row_count_returned')} rows.")
    else:
        print(json.dumps(query_payload))
    return EXIT_OK


handle = build_command_handler(
    command_name="customer-db",
    router=router,
    usage_factory=usage_db_computed,
)
