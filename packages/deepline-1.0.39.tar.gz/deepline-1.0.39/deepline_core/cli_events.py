from __future__ import annotations

from typing import Any

from deepline_core.http import http_request
from deepline_core.playground_helpers import (
    playground_default_api,
    playground_read_state,
)


def _cli_event_endpoint() -> str:
    playground_api = str(
        playground_read_state().get("backend_api_url") or playground_default_api()
    ).strip()
    return f"{playground_api.rstrip('/')}/api/cli-event"


def _inject_session_id(payload: dict[str, Any]) -> None:
    """Auto-inject session_id from the PPID-keyed cache if not already present."""
    if "session_id" in payload:
        return
    try:
        import os
        state = playground_read_state()
        ppid_key = str(os.getppid())

        # Primary cache shape used by the CLI.
        session_ids = state.get("session_ids")
        if isinstance(session_ids, dict):
            cached = str(session_ids.get(ppid_key, "")).strip()
            if cached:
                payload["session_id"] = cached
                return

        # Compatibility fallback: newer runtime state can store PPID-scoped
        # bindings under session_context_bindings (e.g. {"ppid:123": {...}}).
        bindings = state.get("session_context_bindings")
        if isinstance(bindings, dict):
            for binding_key in (f"ppid:{ppid_key}", ppid_key):
                entry = bindings.get(binding_key)
                if isinstance(entry, dict):
                    cached = str(
                        entry.get("session_id")
                        or entry.get("sessionId")
                        or ""
                    ).strip()
                else:
                    cached = str(entry or "").strip()
                if cached:
                    payload["session_id"] = cached
                    return
    except Exception:
        pass


def post_cli_event(payload: dict[str, Any]) -> None:
    try:
        _inject_session_id(payload)
        http_request("POST", _cli_event_endpoint(), None, payload, timeout=3)
    except Exception:
        # Best effort only; runtime feedback must never break enrich execution.
        pass


def update_cli_event(
    *,
    source: str,
    status: str,
    title: str,
    detail: str = "",
    command: str | None = None,
    csv_path: str | None = None,
    run_id: str | None = None,
    response: str | None = None,
    meta: dict[str, Any] | None = None,
    session_id: str | None = None,
) -> None:
    payload: dict[str, Any] = {
        "action": "update",
        "source": source,
        "status": status,
        "title": title,
        "detail": detail,
    }
    if command:
        payload["command"] = command
    if csv_path:
        payload["csv_path"] = csv_path
    if run_id:
        payload["run_id"] = run_id
    if response is not None:
        payload["response"] = response
    if meta:
        payload["meta"] = meta
    if session_id:
        payload["session_id"] = session_id
    post_cli_event(payload)


def append_cli_event(
    *,
    source: str,
    status: str,
    message: str,
    level: str = "info",
    kind: str = "event",
    command: str | None = None,
    csv_path: str | None = None,
    run_id: str | None = None,
    meta: dict[str, Any] | None = None,
    session_id: str | None = None,
) -> None:
    payload: dict[str, Any] = {
        "action": "append_event",
        "source": source,
        "status": status,
        "level": level,
        "kind": kind,
        "message": message,
    }
    if command:
        payload["command"] = command
    if csv_path:
        payload["csv_path"] = csv_path
    if run_id:
        payload["run_id"] = run_id
    if meta:
        payload["meta"] = meta
    if session_id:
        payload["session_id"] = session_id
    post_cli_event(payload)
