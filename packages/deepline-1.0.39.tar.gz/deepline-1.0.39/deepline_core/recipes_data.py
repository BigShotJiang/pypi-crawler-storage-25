"""Shared recipe definitions loaded from recipes.json (source of truth: src/lib/onboard/recipes.json)."""
from __future__ import annotations

import json
import importlib.resources
from typing import Any


def _load_recipes() -> dict[str, Any]:
    """Load recipes.json from the package data directory."""
    ref = importlib.resources.files("deepline_core").joinpath("recipes.json")
    return json.loads(ref.read_text(encoding="utf-8"))


_DATA: dict[str, Any] | None = None


def _get_data() -> dict[str, Any]:
    global _DATA
    if _DATA is None:
        _DATA = _load_recipes()
    return _DATA


def get_skip_suffix() -> str:
    return _get_data()["skipSuffix"]


def get_recipe(workflow_id: str) -> dict[str, Any] | None:
    for r in _get_data()["recipes"]:
        if r["id"] == workflow_id:
            return r
    return None


def build_prompt(workflow_id: str, slot_values: dict[str, str]) -> str:
    """Build a filled prompt from the shared recipe definitions."""
    recipe = get_recipe(workflow_id)
    if not recipe:
        return slot_values.get("freeform", "")

    if workflow_id == "chat":
        return slot_values.get("freeform", "")

    template: str = recipe["promptTemplate"]
    defaults: dict[str, str] = recipe.get("slotDefaults", {})

    for key, default_val in defaults.items():
        value = (slot_values.get(key, "") or "").strip() or default_val
        template = template.replace(f"{{{key}}}", value)

    if not recipe.get("noSkipSuffix", False):
        template += get_skip_suffix()

    return template
