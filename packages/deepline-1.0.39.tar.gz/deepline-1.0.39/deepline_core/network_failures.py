from __future__ import annotations

import http.client
import socket
import ssl
import urllib.error


def classify_network_failure_exception(exc: BaseException) -> str:
    current: BaseException | object | None = exc
    seen: set[int] = set()

    while current is not None and id(current) not in seen:
        seen.add(id(current))

        if isinstance(current, TimeoutError):
            return "network_timeout"
        if isinstance(current, socket.gaierror):
            return "network_dns_resolution_failed"
        if isinstance(current, ConnectionRefusedError):
            return "network_connection_refused"
        if isinstance(current, ConnectionResetError):
            return "network_connection_reset"
        if isinstance(current, ssl.SSLError):
            return "network_ssl_error"
        if isinstance(current, http.client.IncompleteRead):
            return "network_incomplete_read"
        if isinstance(current, http.client.RemoteDisconnected):
            return "network_remote_disconnected"

        text = str(current).lower()
        if "timed out" in text or "timeout" in text:
            return "network_timeout"
        if "name or service not known" in text or "temporary failure in name resolution" in text:
            return "network_dns_resolution_failed"
        if "connection refused" in text:
            return "network_connection_refused"
        if "connection reset" in text:
            return "network_connection_reset"
        if "incompleteread" in text or "incomplete read" in text:
            return "network_incomplete_read"
        if "remotedisconnected" in text or "remote end closed connection" in text:
            return "network_remote_disconnected"
        if "ssl" in text or "unexpected_eof_while_reading" in text:
            return "network_ssl_error"

        if isinstance(current, urllib.error.URLError):
            reason = getattr(current, "reason", None)
            current = reason if reason is not current else None
            continue
        if isinstance(current, BaseException):
            current = current.__cause__ or current.__context__
            continue
        current = None

    return "network_error"
