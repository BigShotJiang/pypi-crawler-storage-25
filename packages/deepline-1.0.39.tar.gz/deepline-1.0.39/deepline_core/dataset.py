from __future__ import annotations

import csv
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable


METADATA_PREFIXES: tuple[str, ...] = ("__dl_",)


def configure_csv_field_limit() -> None:
    limit = sys.maxsize
    while True:
        try:
            csv.field_size_limit(limit)
            return
        except OverflowError:
            limit //= 10


def normalize_alias(value: str) -> str:
    return "".join(ch for ch in str(value or "").lower() if ch.isalnum())


def parse_display_name(header_text: str) -> str:
    raw = str(header_text or "").strip()
    if not raw:
        return ""
    if raw.startswith("{") and raw.endswith("}"):
        try:
            parsed = json.loads(raw)
        except Exception:
            parsed = None
        if isinstance(parsed, dict):
            for key in ("name", "label", "tool_id"):
                value = parsed.get(key)
                if value:
                    return str(value)
    if raw.startswith("@block"):
        block = raw[len("@block") :].strip()
        if block.startswith("{") and block.endswith("}"):
            try:
                parsed = json.loads(block)
            except Exception:
                parsed = None
            if isinstance(parsed, dict):
                for key in ("name", "label", "tool_id"):
                    value = parsed.get(key)
                    if value:
                        return str(value)
    return raw


def sanitize_cell(value: Any) -> str:
    text = str(value or "")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", text)
    return text.strip()


@dataclass(frozen=True)
class CsvDataset:
    headers: list[str]
    rows: list[dict[str, str]]


def load_compacted_csv(
    path: str,
    *,
    metadata_prefixes: tuple[str, ...] = METADATA_PREFIXES,
    keep_metadata: bool = False,
    dedupe_aliases: bool = True,
    alias_fn: Callable[[str], str] = normalize_alias,
) -> tuple[list[str], list[dict[str, str]]]:
    configure_csv_field_limit()
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.reader(handle))

    if not rows:
        return [], []

    raw_headers = [str(h or "") for h in rows[0]]
    keep_indexes: list[int] = []
    seen_aliases: set[str] = set()
    seen_metadata = False

    for idx, header_text in enumerate(raw_headers):
        header = str(header_text or "").strip()
        display = parse_display_name(header)
        if header == "_metadata":
            if keep_metadata and not seen_metadata:
                seen_metadata = True
                keep_indexes.append(idx)
            continue
        if not keep_metadata and header.startswith(metadata_prefixes):
            continue

        alias = alias_fn(display) if dedupe_aliases else None
        if dedupe_aliases and alias and alias in seen_aliases:
            continue
        if dedupe_aliases and alias:
            seen_aliases.add(alias)
        keep_indexes.append(idx)

    compacted_headers = [parse_display_name(str(raw_headers[idx]).strip()) for idx in keep_indexes]
    compacted_rows: list[dict[str, str]] = []
    for row in rows[1:]:
        padded = list(row) + [""] * max(0, len(raw_headers) - len(row))
        row_cells = [sanitize_cell(padded[idx] if idx < len(padded) else "") for idx in keep_indexes]
        compacted_rows.append({compacted_headers[i]: row_cells[i] for i in range(len(compacted_headers))})

    return compacted_headers, compacted_rows


def load_compacted_csv_dataset(
    path: str,
    *,
    metadata_prefixes: tuple[str, ...] = METADATA_PREFIXES,
    keep_metadata: bool = False,
    dedupe_aliases: bool = True,
    alias_fn: Callable[[str], str] = normalize_alias,
) -> CsvDataset:
    headers, rows = load_compacted_csv(
        path,
        metadata_prefixes=metadata_prefixes,
        keep_metadata=keep_metadata,
        dedupe_aliases=dedupe_aliases,
        alias_fn=alias_fn,
    )
    return CsvDataset(headers=headers, rows=rows)


def load_csv_for_schema_validation(path: str) -> list[str]:
    configure_csv_field_limit()
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.reader(handle))

    if not rows:
        raise RuntimeError(f"CSV is empty: {path}")

    raw_headers = [str(h or "") for h in rows[0]]
    out: list[str] = []
    for header in raw_headers:
        if header == "_metadata":
            continue
        if header.startswith(METADATA_PREFIXES):
            continue
        out.append(parse_display_name(header))
    return out


def write_csv_rows(path: str, headers: list[str], rows: list[dict[str, Any]]) -> None:
    with Path(path).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=headers)
        writer.writeheader()
        for row in rows:
            normalized: dict[str, str] = {}
            for key in headers:
                value = row.get(key)
                if value is None:
                    normalized[str(key)] = ""
                elif isinstance(value, (str, int, float, bool)):
                    normalized[str(key)] = str(value)
                else:
                    normalized[str(key)] = json.dumps(value, ensure_ascii=False)
            writer.writerow(normalized)
