from __future__ import annotations

import os
import re
import json
import stat
import time
import hashlib
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import TYPE_CHECKING, NoReturn

if TYPE_CHECKING:
    from deepline_core.install_info import InstallInfo

from deepline_core.http import http_request
from .commands import backend as backend_commands
from deepline_core.playground_helpers import (
    backend_port_from_api_url,
    playground_default_api,
    playground_read_state,
    refresh_runtime_playground,
    runtime_playground_dir,
)
from deepline_core.command_common import (
    install_component_version_path,
    read_install_component_version,
    write_install_component_version,
)

_IS_WINDOWS = sys.platform == "win32"
_UPDATE_STATUS_FLAGS = {"--status", "--check", "--dry-run"}


def _resolve_install_info(base_url: str) -> "InstallInfo":
    """Detect install method/path, reconciling runtime detection with the persisted marker.

    Resolution rules:
    - Runtime detects pip/pipx (binary is NOT a zipapp) but marker says shiv AND
      the binary path could not be resolved → trust the marker.  When
      ``_resolve_binary_path`` returns ``None``, ``_is_zipapp`` defaults to
      ``False`` and detection falls through to "pip" — that is a false negative,
      not evidence the user switched install methods.
    - Runtime detects shiv (binary IS a zipapp) but marker says pip/pipx →
      trust the marker.  pip/pipx can distribute zipapps, so the zipapp check
      alone cannot distinguish the install channel.
    - No marker → use runtime detection and persist it.
    - Otherwise → runtime detection wins (env-var override, confirmed method
      switch with resolved binary path, etc.).
    """
    from deepline_core.install_info import detect as _detect_install, InstallInfo
    from deepline_core.command_common import read_install_method, write_install_method

    info = _detect_install()
    existing = read_install_method(base_url)

    if existing and existing in ("pip", "pipx") and info.method == "shiv":
        # Marker says pip/pipx but runtime sees a zipapp — trust the marker.
        return InstallInfo(method=existing, binary_path=info.binary_path)  # type: ignore[arg-type]

    if existing == "shiv" and info.method != "shiv" and not info.binary_path:
        # Marker says shiv but binary path couldn't be resolved, so _is_zipapp
        # defaulted to False and detection fell through to "pip".  Trust the
        # marker — path resolution failure isn't evidence of method change.
        return InstallInfo(method="shiv", binary_path=info.binary_path)

    # Runtime detection wins: first run (no marker), env-var override, or
    # confirmed method switch (binary path resolved, not a zipapp).
    if existing != info.method:
        try:
            write_install_method(base_url, info.method)
        except Exception:
            pass
    return info


def _is_truthy(raw: str | None) -> bool:
    if raw is None:
        return False
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _extract_remote_version(remote_script: bytes) -> str | None:
    text = remote_script.decode("utf-8", errors="replace")
    shell_match = re.search(r'^DEEPLINE_CLI_VERSION="([^"]+)"', text, re.MULTILINE)
    if shell_match:
        return shell_match.group(1).strip() or None
    py_match = re.search(r'^VERSION\s*=\s*"([^"]+)"', text, re.MULTILINE)
    if py_match:
        return py_match.group(1).strip() or None
    return None


def _to_non_negative_int(value: object) -> int:
    if isinstance(value, bool):
        return 1 if value else 0
    if isinstance(value, int):
        return value if value >= 0 else 0
    if isinstance(value, str):
        try:
            parsed = int(value.strip())
            return parsed if parsed >= 0 else 0
        except Exception:
            return 0
    return 0


def _backend_health(api_url: str) -> tuple[bool, int, int]:
    endpoint = (api_url or "").rstrip("/")
    if not endpoint:
        return False, 0, 0
    try:
        status, raw = http_request("GET", f"{endpoint}/api/health", None, None, timeout=3)
    except Exception:
        return False, 0, 0
    if status != 200:
        return False, 0, 0
    try:
        payload = json.loads(raw or "{}")
    except Exception:
        return False, 0, 0
    if not isinstance(payload, dict):
        return False, 0, 0
    return (
        True,
        _to_non_negative_int(payload.get("active_jobs")),
        _to_non_negative_int(payload.get("queued_jobs")),
    )


def _read_runtime_version_from_dir(version_dir: Path) -> str:
    try:
        version_path = version_dir / ".version"
        return version_path.read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def _local_runtime_version(base_url: str | None = None) -> str:
    scoped_dir = runtime_playground_dir(base_url=base_url)
    scoped_version = _read_runtime_version_from_dir(scoped_dir)
    if scoped_version:
        return scoped_version

    legacy_dir = Path.home() / ".local" / "deepline" / "runtime" / "playground"
    return _read_runtime_version_from_dir(legacy_dir)


def _parse_playground_version(version: str) -> tuple[int, int, int, int] | None:
    parts = (version or "").split("-")
    if len(parts) < 4:
        return None
    parsed: list[int] = []
    for index in range(4):
        try:
            parsed.append(int(parts[index]))
        except Exception:
            return None
    if len(parsed) != 4:
        return None
    return (parsed[0], parsed[1], parsed[2], parsed[3])


def _is_playground_version_newer(remote: str, local: str) -> bool:
    remote_parsed = _parse_playground_version(remote)
    local_parsed = _parse_playground_version(local)
    if remote_parsed is not None and local_parsed is not None:
        return remote_parsed > local_parsed
    return remote != local


def _local_cli_version_path(base_url: str) -> Path:
    return install_component_version_path(str(Path.home()), base_url, "cli")


def _write_local_cli_version(base_url: str, version: str) -> str:
    normalized = (version or "").strip()
    if not normalized:
        return ""
    try:
        write_install_component_version(base_url, "cli", normalized)
    except Exception as exc:
        print(
            f"Failed to write local CLI version file {_local_cli_version_path(base_url)}: {exc}",
            file=sys.stderr,
        )
    return normalized


def _is_placeholder_version(value: str) -> bool:
    """True for build-time placeholder strings like ``__DEEPLINE_PY_CLI_VERSION__``."""
    return bool(value) and value.startswith("__") and value.endswith("__")


def _local_cli_version(base_url: str, current_version: str) -> str:
    normalized_current = (current_version or "").strip()
    existing_version = read_install_component_version(base_url, "cli")
    # Skip placeholder versions — they should never be written to the version
    # file or sent to the server.  Fall back to the persisted version instead.
    if _is_placeholder_version(normalized_current):
        normalized_current = ""
    if normalized_current:
        if existing_version != normalized_current:
            _write_local_cli_version(base_url, normalized_current)
        return normalized_current
    if existing_version:
        return existing_version
    print(
        f"Local CLI version file missing: expected {_local_cli_version_path(base_url)}",
        file=sys.stderr,
    )
    return ""


def _local_skill_version_path(base_url: str) -> Path:
    return install_component_version_path(str(Path.home()), base_url, "skills")


def _read_local_skills_version(base_url: str) -> str:
    candidate = _local_skill_version_path(base_url)
    if not candidate.is_file():
        print(
            f"Local skills version file missing: expected {candidate}",
            file=sys.stderr,
        )
        return ""

    try:
        version = candidate.read_text(encoding="utf-8").strip()
        if version:
            return version
    except Exception as exc:
        print(f"Failed reading local skills version file {candidate}: {exc}", file=sys.stderr)

    print(
        f"Local skills version file {candidate} is empty or unreadable.",
        file=sys.stderr,
    )
    return ""


def _local_skill_lock_version(base_url: str) -> str:
    try:
        local_skills_version = _read_local_skills_version(base_url)
        if local_skills_version:
            return local_skills_version
        print(
            "No local skills version could be resolved from install metadata.",
            file=sys.stderr,
        )
        return ""
    except Exception as exc:
        print(f"Failed to resolve local skills version: {exc}", file=sys.stderr)
        return ""


def _local_playground_meta(base_url: str) -> str:
    return _local_runtime_version(base_url)


def _fetch_remote_playground_version(base_url: str) -> str | None:
    try:
        status, raw = http_request(
            "GET", f"{base_url.rstrip('/')}/api/v2/cli/playground?meta=1", None, None, timeout=5
        )
    except Exception:
        return None
    if status != 200:
        return None
    try:
        payload = json.loads(raw or "{}")
    except Exception:
        return None
    if not isinstance(payload, dict):
        return None
    return str(payload.get("version") or "").strip() or None


def _as_dict(value: object | None) -> dict[str, object]:
    return value if isinstance(value, dict) else {}


def _as_string(value: object | None) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (int, float)):
        if isinstance(value, bool):
            return ""
        if isinstance(value, float) and not value.is_integer():
            return str(value)
        return str(int(value))
    return ""


def _as_bool(value: object | None) -> bool:
    if not isinstance(value, dict):
        return False
    return value.get("needs_update") is True


def _normalize_cli_version(value: object | None) -> str:
    if value is None:
        return ""
    if not isinstance(value, str):
        return ""
    normalized = value.strip()
    return normalized


def _as_update_status_section(update_check: dict[str, object], section: str) -> dict[str, object]:
    section_value = _as_dict(update_check.get(section))
    if not isinstance(section_value, dict):
        return {}
    return section_value


def _read_update_check_status(update_check: dict[str, object]) -> tuple[
    bool,
    bool,
    bool,
    dict[str, object],
    dict[str, object],
    dict[str, object],
]:
    cli_section = _as_update_status_section(update_check, "cli")
    playground_section = _as_update_status_section(update_check, "playground")
    skills_section = _as_update_status_section(update_check, "skills")
    return (
        _as_bool(cli_section),
        _as_bool(playground_section),
        _as_bool(skills_section),
        cli_section,
        playground_section,
        skills_section,
    )


def _fetch_update_check_status(
    *,
    base_url: str,
    timeout: int,
    current_version: str,
    self_path: str | None = None,
) -> dict[str, object] | None:
    _ = self_path
    local_cli_version = _local_cli_version(base_url, current_version)
    local_playground_version = _local_playground_meta(base_url)
    local_skill_lock_version = _local_skill_lock_version(base_url)

    payload: dict[str, object] = {
        "cli": {
            "version": local_cli_version,
        },
        "playground": {
            "version": local_playground_version,
        },
        "skills": {
            "version": local_skill_lock_version,
        },
    }

    try:
        status, raw = http_request(
            "POST",
            f"{base_url.rstrip('/')}/api/v2/cli/update-check",
            None,
            payload,
            timeout=timeout,
        )
    except Exception:
        print(
            f"Self-update check failed to reach {base_url.rstrip('/')}/api/v2/cli/update-check",
            file=sys.stderr,
        )
        return None
    if status != 200:
        print(
            f"Self-update check returned HTTP {status} for {base_url.rstrip('/')}/api/v2/cli/update-check",
            file=sys.stderr,
        )
        return None
    if not raw:
        return None
    try:
        parsed = json.loads(raw)
    except Exception:
        return None
    return parsed if isinstance(parsed, dict) else None


def _is_update_status_request(passthrough_args: list[str]) -> bool:
    return any(arg in _UPDATE_STATUS_FLAGS for arg in passthrough_args)


def _playground_pending_path() -> Path:
    return Path.home() / ".local" / "deepline" / "runtime" / "state" / "playground-refresh-pending.json"


def _read_playground_pending_refresh() -> tuple[str, str]:
    pending = _playground_pending_path()
    if not pending.is_file():
        return "", ""
    try:
        data = json.loads(pending.read_text(encoding="utf-8"))
    except Exception:
        return "", ""
    if not isinstance(data, dict):
        return "", ""
    remote_version = str(data.get("remote_version") or "").strip()
    local_version = str(data.get("local_version") or "").strip()
    return remote_version, local_version


def _set_playground_pending_refresh(remote_version: str, local_version: str) -> None:
    pending = _playground_pending_path()
    try:
        pending.parent.mkdir(parents=True, exist_ok=True)
        pending.write_text(
            json.dumps(
                {
                    "remote_version": remote_version,
                    "local_version": local_version,
                    "set_at_ms": int(time.time() * 1000),
                }
            ),
            encoding="utf-8",
        )
    except Exception:
        pass


def _clear_playground_pending_refresh() -> None:
    pending = _playground_pending_path()
    try:
        pending.unlink()
    except Exception:
        pass


def _backend_command_context(passthrough_args: list[str]) -> str:
    if not passthrough_args:
        return "(current command)"
    return passthrough_args[0]


_SELF_UPDATE_ALREADY_ATTEMPTED = False


def _warn_playground_busy(passthrough_args: list[str], active_jobs: int, queued_jobs: int) -> None:
    command = _backend_command_context(passthrough_args)
    print("Warning: Playground runtime manifest changed while playground has active work.", file=sys.stderr)
    print(
        f"  Command `{command}` is running with {active_jobs} active and {queued_jobs} queued job(s).",
        file=sys.stderr,
    )
    print(
        "  Wait for the job to finish, then run: `deepline backend stop && deepline backend start`",
        file=sys.stderr,
    )
    print("  or `deepline backend refresh-runtime`.", file=sys.stderr)


def _run_pending_playground_refresh(
    base_url: str,
    passthrough_args: list[str],
    remote_version_override: str | None = None,
) -> None:
    pending_remote_version, pending_local_version = _read_playground_pending_refresh()
    if not pending_remote_version:
        print("No pending playground refresh marker found.", file=sys.stderr)
        return

    current_local_version = _local_runtime_version(base_url)
    if current_local_version == pending_remote_version:
        _clear_playground_pending_refresh()
        print(
            "Pending playground refresh is no longer needed (marker matches local runtime).",
            file=sys.stderr,
        )
        return

    effective_remote_version = remote_version_override or pending_remote_version
    if _is_playground_version_newer(current_local_version, effective_remote_version):
        _clear_playground_pending_refresh()
        print(
            f"Pending playground refresh marker is stale (local={current_local_version or '(missing)'} remote={effective_remote_version}).",
            file=sys.stderr,
        )
        return

    if not pending_local_version:
        _clear_playground_pending_refresh()
        print("Pending playground refresh marker is missing baseline local version; clearing.", file=sys.stderr)
        return

    state = playground_read_state()
    api = str(state.get("backend_api_url") or playground_default_api())
    running, active_jobs, queued_jobs = _backend_health(api)
    if running and (active_jobs > 0 or queued_jobs > 0):
        print(
            f"Pending playground refresh blocked by active work (running={running}, active={active_jobs}, queued={queued_jobs}).",
            file=sys.stderr,
        )
        _warn_playground_busy(passthrough_args, active_jobs, queued_jobs)
        return

    try:
        print(
            f"Applying pending playground refresh to {effective_remote_version or '(unknown)'}.",
            file=sys.stderr,
        )
        refresh_runtime_playground(base_url)
        _try_restart_playground_backend_if_running(base_url)
        _clear_playground_pending_refresh()
        print("Updated local playground runtime files from pending refresh.", file=sys.stderr)
    except Exception as exc:
        print(f"Playground pending refresh failed; update not applied: {exc}", file=sys.stderr)
        return


def _try_restart_playground_backend_if_running(base_url: str) -> None:
    state = playground_read_state()
    api = str(state.get("backend_api_url") or playground_default_api())
    running, active_jobs, queued_jobs = _backend_health(api)
    if not running:
        return
    if active_jobs > 0 or queued_jobs > 0:
        print(
            "Skipping auto backend restart because active/queued jobs are present.",
            file=sys.stderr,
        )
        return
    print("Restarting playground backend to apply updated runtime.", file=sys.stderr)
    port = backend_port_from_api_url(api)
    if not backend_commands.stop_backend(False, True, prefer_tracked_pid_only=True) == 0:
        print(
            "Auto backend restart failed during stop. Run manually: `deepline backend stop --just-backend && deepline backend start`",
            file=sys.stderr,
        )
        return
    start_code = backend_commands.start_backend(
        base_url,
        port,
        False,
        "auto",
        skip_runtime_refresh=True,
    )
    if start_code != 0:
        print(
            "Auto backend restart failed. Run manually: `deepline backend stop && deepline backend start`",
            file=sys.stderr,
        )


def _refresh_playground_runtime(
    base_url: str,
    passthrough_args: list[str],
    remote_version: str | None = None,
) -> None:
    remote_version = remote_version or _fetch_remote_playground_version(base_url)
    if not remote_version:
        print("Could not fetch playground runtime manifest version.", file=sys.stderr)
        return

    local_version = _local_runtime_version(base_url)
    if local_version == remote_version:
        _clear_playground_pending_refresh()
        print("Playground runtime already current; no refresh needed.", file=sys.stderr)
        return

    if not _is_playground_version_newer(remote_version, local_version):
        print(
            f"Skipping playground refresh because remote is not newer (local={local_version or '(missing)'}, remote={remote_version}).",
            file=sys.stderr,
        )
        return

    state = playground_read_state()
    api = str(state.get("backend_api_url") or playground_default_api())
    running, active_jobs, queued_jobs = _backend_health(api)
    if running and (active_jobs > 0 or queued_jobs > 0):
        _warn_playground_busy(passthrough_args, active_jobs, queued_jobs)
        _set_playground_pending_refresh(remote_version, local_version)
        print(
            "Playground refresh postponed because backend has active/queued jobs.",
            file=sys.stderr,
        )
        return

    try:
        print(
            f"Updating playground runtime from {local_version or '(missing)'} to {remote_version}.",
            file=sys.stderr,
        )
        refresh_runtime_playground(base_url)
        _try_restart_playground_backend_if_running(base_url)
        if running:
            print(
                "Updated local playground runtime files from changed manifest.",
                file=sys.stderr,
            )
        _clear_playground_pending_refresh()
    except Exception as exc:
        print(f"Playground refresh failed while update-check requested it: {exc}", file=sys.stderr)
        return


def _download_server_artifact(
    base_url: str,
    timeout: int = 20,
) -> tuple[bytes, str] | None:
    """Download the CLI artifact from the server and return (payload, version).

    Returns ``None`` on any network / parse failure (caller should handle).
    """
    update_url = f"{base_url.rstrip('/')}/api/v2/cli/python"
    req = urllib.request.Request(
        update_url,
        headers={"User-Agent": "deepline-python-cli-self-update"},
        method="GET",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            remote_script = response.read()
            header_version = response.info().get("X-Deepline-CLI-Version")
    except (urllib.error.URLError, TimeoutError) as exc:
        print(f"Failed to download CLI artifact: {exc}", file=sys.stderr)
        return None

    if not remote_script:
        print("Empty response from update server.", file=sys.stderr)
        return None

    extracted = _extract_remote_version(remote_script)
    effective = (extracted or header_version or "").strip()
    if not effective:
        print("Could not determine remote version.", file=sys.stderr)
        return None

    return remote_script, effective


def _replace_binary(
    cli_exec_path: str,
    payload: bytes,
) -> bool:
    """Atomically replace the CLI binary at *cli_exec_path* with *payload*.

    Returns ``True`` on success.
    """
    tmp_path = f"{cli_exec_path}.tmp.{os.getpid()}"
    try:
        with open(tmp_path, "wb") as handle:
            handle.write(payload)
        if _IS_WINDOWS:
            aside_path = f"{cli_exec_path}.old.{os.getpid()}"
            try:
                os.rename(cli_exec_path, aside_path)
            except OSError:
                pass
            try:
                os.rename(tmp_path, cli_exec_path)
            except OSError:
                if os.path.isfile(aside_path) and not os.path.isfile(cli_exec_path):
                    os.rename(aside_path, cli_exec_path)
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass
                print("Update failed: could not replace CLI binary.", file=sys.stderr)
                return False
            try:
                os.remove(aside_path)
            except OSError:
                pass
        else:
            try:
                mode = stat.S_IMODE(os.stat(cli_exec_path).st_mode)
            except OSError:
                mode = 0
            if mode == 0:
                mode = 0o755
            os.chmod(tmp_path, mode)
            os.replace(tmp_path, cli_exec_path)
    except OSError as exc:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        print(f"Update failed: {exc}", file=sys.stderr)
        return False
    return True


def _force_update_pip(
    install_method: str,
    base_url: str,
    current_version: str,
    binary_path: str | None,
    check_only: bool,
    timeout: int = 20,
) -> int:
    """Upgrade for pip/pipx installs.

    Strategy:
    1. Try ``pip install --upgrade`` (checks PyPI).
    2. If pip says "already satisfied" but the server still reports a newer
       artifact (hash-based version), download the shiv directly from the
       server and replace the binary — same mechanism the shiv path uses.
    """
    if check_only:
        print(f"Installed via {install_method}. Check PyPI or run 'deepline update' to upgrade.", file=sys.stderr)
        return 0

    # --- Phase 1: try pip/pipx -------------------------------------------
    if install_method == "pipx":
        cmd = ["pipx", "upgrade", "deepline"]
    else:
        cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "deepline"]

    print(f"Upgrading via {install_method}: {' '.join(cmd)}", file=sys.stderr)
    pip_result = subprocess.run(cmd, capture_output=True, text=True)

    # If pip actually installed something new, we're done.
    pip_output = (pip_result.stdout or "") + (pip_result.stderr or "")
    pip_already_satisfied = "already satisfied" in pip_output.lower()

    if pip_result.returncode == 0 and not pip_already_satisfied:
        print("Upgrade complete.", file=sys.stderr)
        return 0

    if pip_result.returncode != 0:
        # Print pip output so the user can see what went wrong.
        if pip_output.strip():
            print(pip_output.strip(), file=sys.stderr)

    # --- Phase 2: pip didn't change anything — fetch from server ----------
    print("pip found no update on PyPI; checking server artifact...", file=sys.stderr)

    artifact = _download_server_artifact(base_url, timeout=timeout)
    if artifact is None:
        if pip_result.returncode == 0:
            print("Upgrade complete (pip).", file=sys.stderr)
            return 0
        print(f"Upgrade failed (pip exit {pip_result.returncode}, server unreachable).", file=sys.stderr)
        return pip_result.returncode

    remote_script, remote_version = artifact
    local_version = (current_version or "").strip()
    if local_version and remote_version == local_version:
        print(f"Already up to date (version {local_version}).", file=sys.stderr)
        return 0

    # Resolve where to write the binary
    target_path = binary_path
    if not target_path:
        print("Could not resolve CLI binary path for server-side update.", file=sys.stderr)
        return 1

    if not _replace_binary(target_path, remote_script):
        return 1

    _write_local_cli_version(base_url, remote_version)
    print(f"Updated Deepline CLI to {remote_version} (from server artifact).", file=sys.stderr)
    return 0


def force_self_update(
    *,
    base_url: str,
    current_version: str,
    timeout: int = 20,
    passthrough_args: list[str] | None = None,
    check_only: bool = False,
) -> int:
    """Explicit 'deepline update' — always checks and applies an update."""
    info = _resolve_install_info(base_url)
    if info.is_pip:
        rc = _force_update_pip(
            info.method,
            base_url,
            current_version,
            info.binary_path,
            check_only,
            timeout=timeout,
        )
        if rc == 0:
            _refresh_playground_runtime(base_url, passthrough_args or ["update"])
            _refresh_agent_skills_for_explicit_update(base_url)
        return rc

    global _SELF_UPDATE_ALREADY_ATTEMPTED
    _SELF_UPDATE_ALREADY_ATTEMPTED = False

    if not info.binary_path:
        print("Could not resolve CLI binary path.", file=sys.stderr)
        return 1
    cli_exec_path: str = info.binary_path

    if check_only:
        print("Checking for updates...", file=sys.stderr)
        update_check = _fetch_update_check_status(
            base_url=base_url,
            timeout=timeout,
            current_version=current_version,
            self_path=cli_exec_path,
        )
        if update_check is None:
            return 1
        _log_update_check_response(update_check)
        return 0

    print("Checking for updates...", file=sys.stderr)
    artifact = _download_server_artifact(base_url, timeout=timeout)
    if artifact is None:
        return 1

    remote_script, effective = artifact
    local_version = (current_version or "").strip()
    remote_version = effective
    if not local_version or not remote_version:
        print(f"Could not resolve CLI version for comparison: local={local_version or '(missing)'} remote={remote_version or '(missing)'}.", file=sys.stderr)
    elif remote_version == local_version:
        print(f"Already up to date (version {current_version}).", file=sys.stderr)
        _refresh_agent_skills_for_explicit_update(base_url)
        return 0

    if not _replace_binary(cli_exec_path, remote_script):
        return 1

    _write_local_cli_version(base_url, remote_version)
    print(f"Updated Deepline CLI from {current_version} to {effective}.", file=sys.stderr)

    _refresh_playground_runtime(base_url, passthrough_args or ["update"])
    _refresh_agent_skills_for_explicit_update(base_url)

    return 0



def _warn_skills_update_needed() -> None:
    print(
        "Warning: Skills index manifest has changed. Run 'deepline update' to sync skills.",
        file=sys.stderr,
    )


def _refresh_agent_skills_for_explicit_update(base_url: str) -> None:
    """Keep explicit `deepline update` aligned with `auth status` skill health.

    `auth status` checks the actual installed skill files under `~/.agents`,
    while the update manifest only compares bundle versions. Reconciling skills
    here ensures `deepline update` repairs drift even when the manifest hash is
    unchanged.
    """
    try:
        from deepline_core import main as main_module
    except Exception as exc:
        print(f"Skipping Deepline agent skill refresh: {exc}", file=sys.stderr)
        return

    main_module._sync_agent_skill(base_url)
    main_module._cleanup_stale_skills(base_url)


def _fail_self_update(message: str) -> NoReturn:
    print(f"Self-update failed: {message}", file=sys.stderr)
    raise SystemExit(1)


def _log_update_section(name: str, section: dict[str, object]) -> bool:
    parsed = _as_dict(section)
    local = _as_dict(parsed.get("local"))
    remote = _as_dict(parsed.get("remote"))
    local_version = _as_string(local.get("version"))
    remote_version = _as_string(remote.get("version"))
    needs_update = _as_bool(parsed)
    print(
        f"{name}: {'needs update' if needs_update else 'up to date'} "
        f"(local={local_version or '(missing)'} remote={remote_version or '(missing)'})",
        file=sys.stderr,
    )
    return needs_update


def _log_update_check_response(update_check: dict[str, object]) -> tuple[bool, bool, bool]:
    cli_section = _as_update_status_section(update_check, "cli")
    playground_section = _as_update_status_section(update_check, "playground")
    skills_section = _as_update_status_section(update_check, "skills")

    print("Checked for CLI/playground/skills updates:", file=sys.stderr)
    needs_cli_update = _log_update_section("cli", cli_section)
    needs_playground_update = _log_update_section("playground", playground_section)
    needs_skills_update = _log_update_section("skills", skills_section)
    return needs_cli_update, needs_playground_update, needs_skills_update


def maybe_self_update(
    *,
    base_url: str,
    passthrough_args: list[str],
    current_version: str,
    override_url: str | None = None,
    timeout: int = 20,
    skip_forced_update_check: bool = False,
    disabled: bool = False,
) -> dict[str, bool]:
    result: dict[str, bool] = {
        "update_check_reached": False,
        "needs_cli_update": False,
        "needs_playground_update": False,
        "needs_skills_update": False,
    }
    global _SELF_UPDATE_ALREADY_ATTEMPTED
    if disabled:
        return result
    info = _resolve_install_info(base_url)
    json_mode = "--json" in passthrough_args
    command_context = passthrough_args[0] if passthrough_args else "(status/help)"
    command_is_update = passthrough_args and passthrough_args[0] == "update"
    is_update_status_request = command_is_update and _is_update_status_request(passthrough_args[1:])
    if skip_forced_update_check and is_update_status_request:
        return result
    should_log = command_is_update
    if should_log:
        print(f"Self-update flow start for {command_context}", file=sys.stderr)
    if _SELF_UPDATE_ALREADY_ATTEMPTED:
        if should_log:
            print("Self-update already attempted in this process; skipping.", file=sys.stderr)
        return result

    cli_exec_path: str | None = info.binary_path

    update_check = _fetch_update_check_status(
        base_url=base_url,
        timeout=timeout,
        current_version=current_version,
        self_path=cli_exec_path,
    )

    needs_cli_update = False
    if update_check is not None:
        result["update_check_reached"] = True
        (
            needs_cli_update,
            needs_playground_update,
            needs_skills_update,
            cli_status,
            playground_status,
            skills_status,
        ) = _read_update_check_status(update_check)
        if should_log:
            (
                needs_cli_update,
                needs_playground_update,
                needs_skills_update,
            ) = _log_update_check_response(update_check)
        local_cli_version = _normalize_cli_version(
            _as_dict(cli_status.get("local")).get("version") if cli_status else None,
        )
        remote_cli_version = _normalize_cli_version(
            _as_dict(cli_status.get("remote")).get("version") if cli_status else None,
        )
        if (
            needs_cli_update
            and local_cli_version
            and remote_cli_version
            and local_cli_version == remote_cli_version
        ):
            needs_cli_update = False
        result["needs_cli_update"] = needs_cli_update
        result["needs_playground_update"] = needs_playground_update
        result["needs_skills_update"] = needs_skills_update

        if needs_skills_update:
            if should_log and not json_mode:
                print("Skills manifest drift detected; sync is required.", file=sys.stderr)
            elif not should_log and not json_mode:
                print("Skills manifest changed; sync is required.", file=sys.stderr)
            if not json_mode:
                _warn_skills_update_needed()

        remote_playground = _as_string(_as_dict(playground_status.get("remote")).get("version"))

        if needs_playground_update:
            if not should_log and not json_mode:
                print("Playground runtime update required.", file=sys.stderr)
            if should_log:
                print(
                    f"Applying playground runtime update to {remote_playground or '(unknown)'}",
                    file=sys.stderr,
                )
            _refresh_playground_runtime(base_url, passthrough_args, remote_playground)
        elif _read_playground_pending_refresh()[0]:
            if not should_log and not json_mode:
                print("Checking pending playground update marker.", file=sys.stderr)
            if should_log:
                print("No active playground update required now; checking pending marker.", file=sys.stderr)
            _run_pending_playground_refresh(base_url, passthrough_args, remote_playground)

        if needs_cli_update:
            if info.is_pip:
                if not json_mode:
                    print(
                        "CRITICAL: Deepline CLI update required — this version has breaking changes. "
                        "Run `deepline update` to upgrade.",
                        file=sys.stderr,
                    )
                return result
            if not should_log:
                print("CLI update required.", file=sys.stderr)
        if not needs_cli_update:
            return result
    else:
        if should_log:
            print("Could not fetch /api/v2/cli/update-check; attempting local fallback refresh.", file=sys.stderr)
        _run_pending_playground_refresh(base_url, passthrough_args)
        _refresh_playground_runtime(base_url, passthrough_args)
        if info.is_pip:
            return result

    if not cli_exec_path:
        _fail_self_update("Could not resolve CLI binary path while CLI update is required.")

    update_url = (
        (override_url or "").strip()
        or f"{base_url.rstrip('/')}/api/v2/cli/python"
    )
    if not update_url:
        return result

    req = urllib.request.Request(
        update_url,
        headers={"User-Agent": "deepline-python-cli-self-update"},
        method="GET",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            remote_script = response.read()
            remote_version = response.info().get("X-Deepline-CLI-Version")
    except urllib.error.HTTPError as exc:
        print(
            f"Self-update skipped: CLI artifact endpoint returned HTTP {exc.code} from {update_url}",
            file=sys.stderr,
        )
        return result
    except (urllib.error.URLError, TimeoutError) as exc:
        print(
            f"Self-update skipped: Could not reach CLI artifact endpoint {update_url}: {exc}",
            file=sys.stderr,
        )
        return result

    if not remote_script:
        _fail_self_update("CLI artifact endpoint returned empty response.")
        return result

    extracted_remote_version = _extract_remote_version(remote_script)
    effective_remote_version = extracted_remote_version or remote_version
    if not effective_remote_version:
        _fail_self_update("Could not determine CLI version from artifact response.")
        return result

    remote_version = effective_remote_version
    local_version = (current_version or "").strip()
    remote_version = (remote_version or "").strip()
    if remote_version and local_version and remote_version == local_version:
        print(f"CLI already at latest version ({current_version}).", file=sys.stderr)
        return result

    debug = False
    if debug:
        print("Deepline CLI debug:", file=sys.stderr)
        print(f"  Self path: {cli_exec_path}", file=sys.stderr)
        print(f"  Remote version: {remote_version or '(unknown)'}", file=sys.stderr)
        print(f"  Local version: {current_version or '(unknown)'}", file=sys.stderr)

    tmp_path = f"{cli_exec_path}.tmp.{os.getpid()}"
    print("Updating Deepline CLI...", end="", file=sys.stderr, flush=True)
    try:
        with open(tmp_path, "wb") as handle:
            handle.write(remote_script)

        if _IS_WINDOWS:
            # On Windows the running exe/script may be locked.
            # Rename the current binary aside, then move the new one in.
            aside_path = f"{cli_exec_path}.old.{os.getpid()}"
            try:
                os.rename(cli_exec_path, aside_path)
            except OSError:
                # File may not be locked (shiv pyz); try direct replace.
                pass
            try:
                os.rename(tmp_path, cli_exec_path)
            except OSError:
                # Restore the original if we moved it aside.
                if os.path.isfile(aside_path) and not os.path.isfile(cli_exec_path):
                    os.rename(aside_path, cli_exec_path)
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass
                _fail_self_update("Could not replace CLI binary while updating.")
                return
            # Clean up the old binary (best-effort; may be locked).
            try:
                os.remove(aside_path)
            except OSError:
                pass
        else:
            mode = stat.S_IMODE(os.stat(cli_exec_path).st_mode)
            if mode == 0:
                mode = 0o755
            os.chmod(tmp_path, mode)
            os.replace(tmp_path, cli_exec_path)
    except OSError:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        _fail_self_update("Could not replace CLI binary on disk during update.")
        return result

    _write_local_cli_version(base_url, remote_version)
    print(f"\rUpdated Deepline CLI to {remote_version}", file=sys.stderr)

    _refresh_playground_runtime(base_url, passthrough_args)
    _SELF_UPDATE_ALREADY_ATTEMPTED = True

    next_env = os.environ.copy()
    next_env["DEEPLINE_SKIP_SELF_UPDATE"] = "1"

    if _IS_WINDOWS:
        # os.execve is Unix-only. Spawn a new process and exit this one.
        restart_args = [sys.executable, cli_exec_path, *passthrough_args]
        restart_result = subprocess.run(
            restart_args,
            env=next_env,
        )
        raise SystemExit(restart_result.returncode)
    else:
        os.execve(cli_exec_path, [cli_exec_path, *passthrough_args], next_env)
