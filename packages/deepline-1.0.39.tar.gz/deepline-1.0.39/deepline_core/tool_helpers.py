from __future__ import annotations

def normalize_tool_id(tool_id: str) -> str:
    raw = tool_id.strip()
    lowered = raw.lower()

    # Backward-compatible aliases kept for non-breaking legacy tooling.
    # These are intentionally strict to avoid turning unknown values into false positives.
    aliases = {
        "run-javascript": "run_javascript",
        "runjavascript": "run_javascript",
        "local.run_javascript": "run_javascript",
        "local.read-file": "read_file",
        "local.read_file": "read_file",
        "read-file": "read_file",
        "call_ai_claude_code": "call_local_claude_code",
        "call_ai_codex": "call_local_codex",
        "local.call_ai_claude_code": "call_local_claude_code",
        "local.call_ai_codex": "call_local_codex",
        "local.call_local_codex": "call_local_codex",
        "local.call_local_claude_code": "call_local_claude_code",
    }

    mapped = aliases.get(lowered, aliases.get(raw, raw))
    if mapped != raw:
        return mapped

    if lowered.startswith("plays/build/"):
        return lowered[len("plays/build/") :]
    if lowered.startswith("plays/"):
        return lowered[len("plays/") :]

    return lowered


def is_local_tool(tool_id: str) -> bool:
    return normalize_tool_id(tool_id) in {
        "run_javascript",
        "read_file",
        "call_local_codex",
        "call_local_claude_code",
    }
