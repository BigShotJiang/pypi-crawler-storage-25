"""Rich enrichment primitives used by the enrich CLI.

This package intentionally lives outside the command router layer.
"""

from .run_block import (
    RunBlockWaitSummary,
    completed_rows_from_wait,
    compute_poll_timeout_s,
    failure_like_jobs_from_wait,
    summarize_wait_outcome,
)

__all__ = [
    "RunBlockWaitSummary",
    "completed_rows_from_wait",
    "compute_poll_timeout_s",
    "failure_like_jobs_from_wait",
    "summarize_wait_outcome",
]
