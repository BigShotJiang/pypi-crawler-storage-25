from __future__ import annotations

"""Compatibility shim for legacy imports of ``deepline_core.enrich.core``.

The canonical implementation now lives in ``deepline_core.commands.enrich``.
"""

from ..commands import enrich as _enrich_commands


def __getattr__(name: str):  # pragma: no cover
    return getattr(_enrich_commands, name)


def __dir__() -> list[str]:  # pragma: no cover
    return sorted(set(globals().keys()) | set(dir(_enrich_commands)))


__all__ = [name for name in dir(_enrich_commands) if not name.startswith("_")]
