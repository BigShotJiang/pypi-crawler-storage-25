from __future__ import annotations

import dataclasses
from typing import Any


@dataclasses.dataclass(frozen=True)
class RunBlockWaitSummary:
    failed_count: int
    completed_count: int
    missed_count: int
    missing_count: int
    total_count: int
    failed_pct: float


def failure_like_jobs_from_wait(
    wait_jobs: Any,
    missing_jobs: Any,
    *,
    column_name: str,
    target_col_index: int,
    fallback_row: int,
) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    if isinstance(wait_jobs, list):
        for raw_job in wait_jobs:
            if not isinstance(raw_job, dict):
                continue
            status_text = str(raw_job.get("status") or "").strip().lower()
            if status_text not in {"failed", "canceled", "queued", "running"}:
                continue
            job = dict(raw_job)
            if not str(job.get("job_id") or "").strip():
                raw_id = job.get("id")
                if raw_id is not None:
                    job["job_id"] = str(raw_id)
            row_value = job.get("row_id")
            if not isinstance(row_value, int):
                row_value = job.get("row")
            job["row_id"] = row_value if isinstance(row_value, int) and row_value >= 0 else int(fallback_row)
            col_value = job.get("col_index")
            if not isinstance(col_value, int):
                col_value = job.get("col")
            job["col_index"] = col_value if isinstance(col_value, int) and col_value >= 0 else int(target_col_index)
            if not str(job.get("column") or "").strip():
                job["column"] = column_name
            if not str(job.get("last_error") or job.get("error") or "").strip():
                job["last_error"] = f"Job finished with status {status_text or 'failed'}."
            elif not str(job.get("last_error") or "").strip():
                job["last_error"] = str(job.get("error") or "").strip()
            entries.append(job)
    if isinstance(missing_jobs, list):
        for missing_job_id in missing_jobs:
            missing_id = str(missing_job_id or "").strip()
            if not missing_id:
                continue
            entries.append(
                {
                    "job_id": missing_id,
                    "row_id": int(fallback_row),
                    "col_index": int(target_col_index),
                    "column": column_name,
                    "status": "missing",
                    "last_error": "Job missing from wait results.",
                }
            )
    return entries


def rate_limited_jobs_from_wait(
    wait_jobs: Any,
    *,
    parse_rate_limit_meta: Any,
) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    if not isinstance(wait_jobs, list):
        return entries
    for raw_job in wait_jobs:
        if not isinstance(raw_job, dict):
            continue
        status_text = str(raw_job.get("status") or "").strip().lower()
        if status_text not in {"failed", "canceled", "queued", "running"}:
            continue
        parsed_meta = parse_rate_limit_meta(raw_job.get("last_error") or raw_job.get("error"))
        if parsed_meta:
            entries.append(dict(raw_job))
    return entries


def completed_rows_from_wait(wait_jobs: Any) -> list[int]:
    rows: list[int] = []
    if not isinstance(wait_jobs, list):
        return rows
    for raw_job in wait_jobs:
        if not isinstance(raw_job, dict):
            continue
        if str(raw_job.get("status") or "").strip().lower() != "completed":
            continue
        row_value = raw_job.get("row_id")
        if not isinstance(row_value, int):
            row_value = raw_job.get("row")
        if isinstance(row_value, int) and row_value >= 0:
            rows.append(row_value)
    return rows


def summarize_wait_outcome(wait_jobs: Any, missing_jobs: Any, waterfall_skipped: Any) -> RunBlockWaitSummary:
    failed_count = 0
    completed_count = 0
    missed_count = 0
    if isinstance(wait_jobs, list):
        for job in wait_jobs:
            if not isinstance(job, dict):
                continue
            status_text = str(job.get("status") or "").strip().lower()
            if status_text in {"failed", "canceled", "queued", "running"}:
                failed_count += 1
            elif status_text in {"completed", "skipped"}:
                completed_count += 1
            elif status_text == "missed":
                missed_count += 1
    missing_count = len(missing_jobs) if isinstance(missing_jobs, list) else 0
    failed_count += missing_count
    waterfall_skipped_count = len(waterfall_skipped) if isinstance(waterfall_skipped, list) else 0
    total_count = (len(wait_jobs) if isinstance(wait_jobs, list) else 0) + missing_count + waterfall_skipped_count
    if total_count <= 0:
        total_count = 1
    failed_pct = (failed_count * 100.0) / float(total_count)
    return RunBlockWaitSummary(
        failed_count=failed_count,
        completed_count=completed_count,
        missed_count=missed_count,
        missing_count=missing_count,
        total_count=total_count,
        failed_pct=failed_pct,
    )


# Minimum guaranteed wait regardless of row count (30 min).
_MIN_POLL_TIMEOUT_S = 1800

# Seconds per row: assumes worst-case ~15 rows/min for heavily rate-limited
# providers (e.g. LeadMagic at 100 req/min with retries), with 2x buffer.
_POLL_TIMEOUT_S_PER_ROW = 4


def compute_poll_timeout_s(row_start: int, row_end: int) -> int:
    """Return a poll timeout scaled to the number of rows being processed."""
    row_count = max(1, row_end - row_start + 1)
    return max(_MIN_POLL_TIMEOUT_S, row_count * _POLL_TIMEOUT_S_PER_ROW)
