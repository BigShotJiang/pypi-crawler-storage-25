from __future__ import annotations

import json
import math
import os
import plistlib
import subprocess
import time
from pathlib import Path
from typing import Protocol
from urllib.parse import parse_qs, quote, urlparse

MACOS_BROWSER_FOCUS_COOLDOWN_SECONDS = 30.0


class _SupportsFileno(Protocol):
    def fileno(self) -> int: ...


def _extract_url_host(raw: str) -> str:
    """Return host:port so tab retarget only matches the exact origin.

    Using hostname alone (no port) would match ANY localhost tab regardless of
    port, hijacking e.g. a session-UI tab at :4173 when targeting :4174.
    """
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    hostname = (parsed.hostname or "").strip().lower()
    if not hostname:
        return ""
    port = parsed.port
    if port:
        return f"{hostname}:{port}"
    return hostname


def _is_localhost_host(host: str) -> bool:
    normalized = str(host or "").strip().lower()
    return normalized == "localhost" or normalized.startswith("127.") or normalized == "0.0.0.0" or normalized == "::1"


def _is_local_playground_render_url(raw: str) -> bool:
    try:
        parsed = urlparse(str(raw or "").strip())
    except Exception:
        return False
    path = (parsed.path or "").strip()
    return _is_localhost_host(parsed.hostname or "") and path in {"", "/"}


def _extract_session_id(raw: str) -> str:
    try:
        parsed = urlparse(str(raw or "").strip())
    except Exception:
        return ""
    if not parsed.query:
        return ""
    query = parse_qs(parsed.query)
    return str((query.get("session_id") or [""])[0]).strip()


def _default_bundle_macos() -> str:
    plist_path = os.path.expanduser(
        "~/Library/Preferences/com.apple.LaunchServices/com.apple.launchservices.secure.plist"
    )
    if not os.path.isfile(plist_path):
        return ""
    try:
        with open(plist_path, "rb") as handle:
            payload = plistlib.load(handle) or {}
    except Exception:
        return ""
    handlers = payload.get("LSHandlers") or []
    if not isinstance(handlers, list):
        return ""

    def pick_bundle(scheme: str) -> str:
        for item in handlers:
            if not isinstance(item, dict):
                continue
            if str(item.get("LSHandlerURLScheme") or "").lower() != scheme:
                continue
            bundle = (
                item.get("LSHandlerRoleAll")
                or item.get("LSHandlerRoleViewer")
                or item.get("LSHandlerRoleEditor")
                or ""
            )
            bundle = str(bundle).strip()
            if bundle:
                return bundle
        return ""

    return pick_bundle("https") or pick_bundle("http")


def _browser_strategy_for_bundle(bundle_id: str) -> str:
    bundle = bundle_id.lower()
    if bundle in {
        "com.google.chrome",
        "com.google.chrome.canary",
        "com.microsoft.edgemac",
        "com.brave.browser",
        "com.operasoftware.opera",
        "com.operasoftware.operagx",
        "com.vivaldi.vivaldi",
        "company.thebrowser.browser",
    }:
        return "chromium"
    if bundle == "com.apple.safari":
        return "safari"
    return "fallback"


def _browser_app_name_for_bundle(bundle_id: str) -> str:
    names = {
        "com.google.chrome": "Google Chrome",
        "com.google.chrome.canary": "Google Chrome Canary",
        "com.microsoft.edgemac": "Microsoft Edge",
        "com.brave.browser": "Brave Browser",
        "com.operasoftware.opera": "Opera",
        "com.operasoftware.operagx": "Opera GX",
        "com.vivaldi.vivaldi": "Vivaldi",
        "company.thebrowser.browser": "Arc",
        "com.apple.safari": "Safari",
    }
    return names.get(bundle_id.lower(), "")


def _browser_focus_state_file() -> Path:
    home_dir = os.environ.get("HOME", str(Path.home()))
    return Path(home_dir) / ".local" / "deepline" / "runtime" / "state" / "browser-focus.json"


def _lock_focus_state(handle: _SupportsFileno) -> None:
    try:
        import fcntl
    except Exception:
        return
    fcntl.flock(handle.fileno(), fcntl.LOCK_EX)


def _unlock_focus_state(handle: _SupportsFileno) -> None:
    try:
        import fcntl
    except Exception:
        return
    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _claim_macos_browser_focus(now: float | None = None) -> bool:
    current_time = time.time() if now is None else float(now)
    state_path = _browser_focus_state_file()
    try:
        state_path.parent.mkdir(parents=True, exist_ok=True)
        state_path.touch(exist_ok=True)
        with state_path.open("r+", encoding="utf-8") as handle:
            _lock_focus_state(handle)
            try:
                handle.seek(0)
                payload_raw = handle.read().strip()
                last_focused_at = 0.0
                if payload_raw:
                    payload = json.loads(payload_raw)
                    if isinstance(payload, dict):
                        last_value = payload.get("last_focused_at")
                        if isinstance(last_value, (int, float)) and math.isfinite(last_value):
                            last_focused_at = float(last_value)
                if last_focused_at > current_time:
                    last_focused_at = 0.0
                if current_time - last_focused_at < MACOS_BROWSER_FOCUS_COOLDOWN_SECONDS:
                    return False
                handle.seek(0)
                handle.truncate()
                json.dump({"last_focused_at": current_time}, handle)
                handle.flush()
                os.fsync(handle.fileno())
                return True
            finally:
                _unlock_focus_state(handle)
    except Exception:
        return True


def _open_url_macos(
    target_url: str,
    *,
    allow_focus: bool,
    app_name: str = "",
    bundle_id: str = "",
) -> bool:
    args = ["open"]
    if not allow_focus:
        args.append("-g")
    if app_name:
        args.extend(["-a", app_name])
    elif bundle_id:
        args.extend(["-b", bundle_id])
    args.append(target_url)
    try:
        # Run synchronously so we can detect launch failures and fall back to
        # a generic `open <url>` invocation.
        result = subprocess.run(
            args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        return result.returncode == 0
    except Exception:
        return False


def _retarget_chromium_macos(
    app_name: str,
    target_url: str,
    *,
    allow_focus: bool,
    required_session_token: str = "",
) -> bool:
    host = _extract_url_host(target_url)
    if not host:
        return False
    escaped_app_name = app_name.replace('"', '\\"')
    activate_block = "    activate\n" if allow_focus else ""
    found_tab_block = (
        "          set active tab index of w to i\n"
        "          set index of w to 1\n"
        "          set URL of t to targetUrl\n"
        if allow_focus
        else "          set URL of t to targetUrl\n"
    )
    new_tab_block = (
        "      tell window 1\n"
        "        make new tab with properties {{URL:targetUrl}}\n"
        "        set active tab index to (count of tabs)\n"
        "        set index to 1\n"
        "      end tell\n"
        if allow_focus
        else "      tell window 1\n"
        "        make new tab with properties {{URL:targetUrl}}\n"
        "      end tell\n"
    )
    script = f"""
on run argv
  set targetUrl to item 1 of argv
  set targetHost to item 2 of argv
  set requiredSessionToken to item 3 of argv
  tell application "{escaped_app_name}"
{activate_block}    if (count of windows) is 0 then
      make new window
    end if
    set foundTab to false
    repeat with w in windows
      set tabCount to count of tabs of w
      repeat with i from 1 to tabCount
        set t to tab i of w
        set tabUrl to URL of t
        set tabMatchesSession to true
        if requiredSessionToken is not "" then
          if tabUrl does not contain requiredSessionToken then
            set tabMatchesSession to false
          end if
        end if
        if tabUrl contains targetHost and tabMatchesSession then
{found_tab_block}          set foundTab to true
          exit repeat
        end if
      end repeat
      if foundTab then exit repeat
    end repeat
    if not foundTab then
{new_tab_block}    end if
  end tell
end run
"""
    try:
        result = subprocess.run(
            ["osascript", "-", target_url, host, required_session_token],
            input=script,
            text=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
            timeout=5,
        )
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        return False


def _retarget_safari_macos(
    app_name: str,
    target_url: str,
    *,
    allow_focus: bool,
    required_session_token: str = "",
) -> bool:
    host = _extract_url_host(target_url)
    if not host:
        return False
    escaped_app_name = app_name.replace('"', '\\"')
    activate_block = "    activate\n" if allow_focus else ""
    found_tab_block = (
        "          set current tab of w to t\n"
        "          set index of w to 1\n"
        "          set URL of t to targetUrl\n"
        if allow_focus
        else "          set URL of t to targetUrl\n"
    )
    new_tab_block = (
        "      tell window 1\n"
        "        set current tab to (make new tab with properties {{URL:targetUrl}})\n"
        "        set index to 1\n"
        "      end tell\n"
        if allow_focus
        else "      tell window 1\n"
        "        make new tab with properties {{URL:targetUrl}}\n"
        "      end tell\n"
    )
    script = f"""
on run argv
  set targetUrl to item 1 of argv
  set targetHost to item 2 of argv
  set requiredSessionToken to item 3 of argv
  tell application "{escaped_app_name}"
{activate_block}    if (count of windows) is 0 then
      make new document
    end if
    set foundTab to false
    repeat with w in windows
      set tabCount to count of tabs of w
      repeat with i from 1 to tabCount
        set t to tab i of w
        set tabUrl to URL of t
        set tabMatchesSession to true
        if requiredSessionToken is not "" then
          if tabUrl does not contain requiredSessionToken then
            set tabMatchesSession to false
          end if
        end if
        if tabUrl contains targetHost and tabMatchesSession then
{found_tab_block}          set foundTab to true
          exit repeat
        end if
      end repeat
      if foundTab then exit repeat
    end repeat
    if not foundTab then
{new_tab_block}    end if
  end tell
end run
"""
    try:
        result = subprocess.run(
            ["osascript", "-", target_url, host, required_session_token],
            input=script,
            text=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
            timeout=5,
        )
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        return False


def open_url_in_browser(target_url: str, *, force_focus: bool = False) -> None:
    no_browser = str(os.environ.get("DEEPLINE_NO_BROWSER") or os.environ.get("PLAYGROUND_HEADLESS") or "").strip().lower()
    if no_browser in {"1", "true", "yes", "on"}:
        return

    target_url = str(target_url or "").strip()
    if not target_url:
        return

    uname = os.uname().sysname if hasattr(os, "uname") else ""
    allow_focus = True
    if uname == "Darwin":
        allow_focus = force_focus or _claim_macos_browser_focus()
        if not allow_focus and _is_local_playground_render_url(target_url):
            return
        required_session_token = ""
        if _is_local_playground_render_url(target_url):
            target_session_id = _extract_session_id(target_url)
            if target_session_id:
                required_session_token = f"session_id={quote(target_session_id, safe='')}"
        default_bundle = _default_bundle_macos()
        if default_bundle:
            app_name = _browser_app_name_for_bundle(default_bundle)
            strategy = _browser_strategy_for_bundle(default_bundle)
            if strategy == "chromium" and app_name and _retarget_chromium_macos(
                app_name,
                target_url,
                allow_focus=allow_focus,
                required_session_token=required_session_token,
            ):
                return
            if strategy == "safari" and app_name and _retarget_safari_macos(
                app_name,
                target_url,
                allow_focus=allow_focus,
                required_session_token=required_session_token,
            ):
                return

            if app_name and _open_url_macos(target_url, allow_focus=allow_focus, app_name=app_name):
                return
            if _open_url_macos(target_url, allow_focus=allow_focus, bundle_id=default_bundle):
                return

    if shutil_which("open"):
        if uname == "Darwin":
            _open_url_macos(target_url, allow_focus=allow_focus)
            return
        subprocess.Popen(["open", target_url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return
    if shutil_which("xdg-open"):
        subprocess.Popen(["xdg-open", target_url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return
    if shutil_which("cmd.exe"):
        subprocess.Popen(["cmd.exe", "/c", "start", "", target_url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def shutil_which(command: str) -> str | None:
    from shutil import which

    return which(command)
