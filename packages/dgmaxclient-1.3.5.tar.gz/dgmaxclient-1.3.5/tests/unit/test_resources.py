"""Unit tests for DGMax resources."""

import json
from unittest.mock import patch

import pytest

from dgmaxclient import DGMaxClient
from dgmaxclient.exceptions import (
    DGMaxRequestError,
    DGMaxServerError,
    DGMaxTimeoutError,
)
from dgmaxclient.models import CompanyURLs
from dgmaxclient.resources.base import DocumentResource
from dgmaxclient.resources.companies import CompaniesResource


class TestCompaniesResource:
    """Tests for CompaniesResource methods."""

    def test_get_urls(self, client: DGMaxClient) -> None:
        """Test get_urls method returns CompanyURLs."""
        company_id = "123e4567-e89b-12d3-a456-426614174000"
        mock_response = {
            "reception": "https://receptor.example.com/receive",
            "approval": "https://receptor.example.com/approve",
            "authentication": "https://auth.example.com/login",
        }

        with patch.object(client, "get", return_value=mock_response):
            urls = client.companies.get_urls(company_id)

        assert isinstance(urls, CompanyURLs)
        assert urls.reception == "https://receptor.example.com/receive"
        assert urls.approval == "https://receptor.example.com/approve"
        assert urls.authentication == "https://auth.example.com/login"

    def test_get_urls_invalid_company_id(self, client: DGMaxClient) -> None:
        """Test get_urls with invalid company ID format."""
        with pytest.raises(ValueError, match="Invalid resource ID format"):
            client.companies.get_urls("invalid-id")

    def test_get_urls_builds_correct_endpoint(self, client: DGMaxClient) -> None:
        """Test that get_urls calls the correct endpoint."""
        company_id = "abc12345-e89b-12d3-a456-426614174000"
        mock_response = {
            "reception": "https://example.com/r",
            "approval": "https://example.com/a",
            "authentication": "https://example.com/auth",
        }

        with patch.object(client, "get", return_value=mock_response) as mock_get:
            client.companies.get_urls(company_id)

        expected_endpoint = f"https://api.dgmax.do/api/v1/companies/{company_id}/urls"
        mock_get.assert_called_once_with(expected_endpoint)

    def test_get_urls_has_retry_decorator(self, client: DGMaxClient) -> None:
        """Test that get_urls method has retry decorator applied."""
        # The retry decorator wraps the method with tenacity
        method = CompaniesResource.get_urls
        # Tenacity-wrapped functions have a 'retry' attribute
        assert hasattr(method, "retry")


class TestDocumentResourceCreate:
    """Tests for DocumentResource.create() idempotent retry behavior."""

    EXISTING_ID = "069a1c8d-c3fe-7c4a-8000-cd065cd9c28e"
    ENCF = "E310000000872"

    def _make_payload(self) -> dict:
        return {
            "ecf": {
                "encabezado": {
                    "id_doc": {"e_ncf": self.ENCF},
                }
            }
        }

    def _make_doc_response(self) -> dict:
        return {
            "id": self.EXISTING_ID,
            "status": "COMPLETED",
            "rnc": "123456789",
            "encf": self.ENCF,
            "created_at": "2024-01-15T10:30:00Z",
            "updated_at": "2024-01-15T10:30:00Z",
        }

    def _make_409_error(self) -> DGMaxRequestError:
        body = json.dumps(
            {
                "detail": {
                    "code": "duplicate_document",
                    "message": "Document with this RNC and eNCF already exists",
                    "context": {
                        "rnc": "123456789",
                        "encf": self.ENCF,
                        "existing_document_id": self.EXISTING_ID,
                        "existing_document_status": "COMPLETED",
                    },
                }
            }
        )
        return DGMaxRequestError(
            "409 Conflict for url: ...", status_code=409, info=body
        )

    def test_409_on_retry_after_timeout_returns_existing_document(
        self, client: DGMaxClient
    ) -> None:
        doc = self._make_doc_response()
        post_side_effects = [
            DGMaxTimeoutError("read timeout"),
            self._make_409_error(),
        ]

        with (
            patch("tenacity.nap.sleep"),
            patch.object(client, "post", side_effect=post_side_effects) as mock_post,
            patch.object(client, "get", return_value=doc),
        ):
            result = client.fiscal_invoices.create(self._make_payload())

        assert result.encf == self.ENCF
        assert result.id == self.EXISTING_ID
        assert mock_post.call_count == 2

    def test_409_on_retry_after_server_error_returns_existing_document(
        self, client: DGMaxClient
    ) -> None:
        doc = self._make_doc_response()
        post_side_effects = [
            DGMaxServerError("500 Internal Server Error", status_code=500),
            self._make_409_error(),
        ]

        with (
            patch("tenacity.nap.sleep"),
            patch.object(client, "post", side_effect=post_side_effects),
            patch.object(client, "get", return_value=doc),
        ):
            result = client.fiscal_invoices.create(self._make_payload())

        assert result.encf == self.ENCF
        assert result.id == self.EXISTING_ID

    def test_409_on_first_attempt_raises(self, client: DGMaxClient) -> None:
        with (
            patch.object(
                client,
                "post",
                side_effect=self._make_409_error(),
            ),
            pytest.raises(DGMaxRequestError) as exc_info,
        ):
            client.fiscal_invoices.create(self._make_payload())

        assert exc_info.value.status_code == 409

    def test_409_on_retry_without_conflict_body_raises(
        self, client: DGMaxClient
    ) -> None:
        bare_409 = DGMaxRequestError("409 Conflict for url: ...", status_code=409)
        post_side_effects = [
            DGMaxTimeoutError("read timeout"),
            bare_409,
        ]

        with (
            patch("tenacity.nap.sleep"),
            patch.object(client, "post", side_effect=post_side_effects),
            pytest.raises(DGMaxRequestError) as exc_info,
        ):
            client.fiscal_invoices.create(self._make_payload())

        assert exc_info.value.status_code == 409

    def test_successful_create_returns_document(self, client: DGMaxClient) -> None:
        doc = self._make_doc_response()

        with patch.object(client, "post", return_value=doc) as mock_post:
            result = client.fiscal_invoices.create(self._make_payload())

        assert result.encf == self.ENCF
        assert mock_post.call_count == 1

    def test_existing_id_from_conflict_extracts_id(self) -> None:
        exc = TestDocumentResourceCreate._make_409_error(self)
        assert DocumentResource._existing_id_from_conflict(exc) == self.EXISTING_ID

    def test_existing_id_from_conflict_returns_none_for_bare_409(self) -> None:
        exc = DGMaxRequestError("409 Conflict for url: ...", status_code=409)
        assert DocumentResource._existing_id_from_conflict(exc) is None
