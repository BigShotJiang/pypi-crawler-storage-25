"""iTunes Transporter integration module."""
