# QQet

**QQet** — Fast quantum circuit simulator with Qiskit-style visualization.

No heavy dependencies — pure NumPy.

## Install

```bash
pip install qqet
```

## Quick Start

```python
from qqet import QuantumCircuit
from qqet.visualize import plot_histogram

qc = QuantumCircuit(2, name="Bell")
qc.h(0).cnot(0, 1).measure_all()

# Text diagram
print(qc.draw())

# MPL diagram
fig = qc.draw('mpl')
fig.savefig('circuit.png')

# Run & histogram
counts = qc.run(shots=1024)
fig2 = plot_histogram(counts, title="Bell State")
fig2.savefig('histogram.png')
```

## Features
- Qiskit-style ASCII and matplotlib circuit diagrams
- Multi-color academic-style histograms
- No Qiskit required — pure NumPy simulation
- Supports: H, X, Y, Z, S, T, RX, RY, RZ, CNOT, CZ, CCX, SWAP, and more
