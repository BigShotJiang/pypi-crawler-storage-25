"""
qqet.circuit
==============
Production-quality QuantumCircuit class with Qiskit-like API.
"""

import copy
import numpy as np
from .statevector import StateVector
from .gates import GATE_REGISTRY


# ─────────────────────────────────────────────────────────────
# _Diagram wrapper — prevents double-print in Jupyter
# ─────────────────────────────────────────────────────────────
class _Diagram:
    """Wraps ASCII diagram so Jupyter shows it once via __repr__."""
    def __init__(self, text: str):
        self._text = text
    def __repr__(self):
        return self._text
    def __str__(self):
        return self._text


# ─────────────────────────────────────────────────────────────
# QuantumCircuit
# ─────────────────────────────────────────────────────────────
class QuantumCircuit:
    """
    Quantum circuit simulator with Qiskit-like API.

    Parameters
    ----------
    n_qubits   : int   — number of qubits
    n_classical: int   — classical bits (default = n_qubits)
    name       : str   — circuit label

    Example
    -------
    >>> from qqet import QuantumCircuit
    >>> qc = QuantumCircuit(2)
    >>> qc.h(0).cnot(0, 1).measure_all()
    >>> print(qc.draw())
    >>> counts = qc.run(shots=1024)
    >>> print(counts)
    """

    def __init__(self, n_qubits: int,
                 n_classical: int = None,
                 name: str = "circuit"):
        if n_qubits < 1:
            raise ValueError("n_qubits must be >= 1")
        self.n_qubits    = n_qubits
        self.n_classical = n_classical if n_classical is not None else n_qubits
        self.name        = name
        self._ops            = []   # list of operation dicts
        self._measured_qubits = []  # flat list — no duplicates
        self._noise_model    = None
        self._sv             = StateVector(n_qubits)

    # ═══════════════════════════════════════════════════════
    # Single-qubit gates
    # ═══════════════════════════════════════════════════════
    def i(self, q):   return self._g('i',   [q])
    def x(self, q):   return self._g('x',   [q])
    def y(self, q):   return self._g('y',   [q])
    def z(self, q):   return self._g('z',   [q])
    def h(self, q):   return self._g('h',   [q])
    def s(self, q):   return self._g('s',   [q])
    def t(self, q):   return self._g('t',   [q])
    def sdg(self, q): return self._g('sdg', [q])
    def tdg(self, q): return self._g('tdg', [q])
    def sx(self, q):  return self._g('sx',  [q])

    def rx(self, theta, q): return self._g('rx', [q], [theta])
    def ry(self, theta, q): return self._g('ry', [q], [theta])
    def rz(self, theta, q): return self._g('rz', [q], [theta])
    def p(self, phi, q):    return self._g('p',  [q], [phi])
    def u(self, theta, phi, lam, q):
        return self._g('u', [q], [theta, phi, lam])

    # ═══════════════════════════════════════════════════════
    # Two-qubit gates
    # ═══════════════════════════════════════════════════════
    def cnot(self, ctrl, tgt):  return self._g('cnot',  [ctrl, tgt])
    def cx(self, ctrl, tgt):    return self.cnot(ctrl, tgt)
    def cy(self, ctrl, tgt):    return self._g('cy',    [ctrl, tgt])
    def cz(self, ctrl, tgt):    return self._g('cz',    [ctrl, tgt])
    def swap(self, q0, q1):     return self._g('swap',  [q0, q1])
    def iswap(self, q0, q1):    return self._g('iswap', [q0, q1])

    def crx(self, theta, ctrl, tgt): return self._g('crx', [ctrl, tgt], [theta])
    def cry(self, theta, ctrl, tgt): return self._g('cry', [ctrl, tgt], [theta])
    def crz(self, theta, ctrl, tgt): return self._g('crz', [ctrl, tgt], [theta])
    def cp(self, phi, ctrl, tgt):    return self._g('cp',  [ctrl, tgt], [phi])

    # ═══════════════════════════════════════════════════════
    # Three-qubit gates
    # ═══════════════════════════════════════════════════════
    def ccx(self, c0, c1, tgt):        return self._g('ccx',   [c0, c1, tgt])
    def toffoli(self, c0, c1, tgt):    return self.ccx(c0, c1, tgt)
    def cswap(self, ctrl, q0, q1):     return self._g('cswap', [ctrl, q0, q1])
    def fredkin(self, ctrl, q0, q1):   return self.cswap(ctrl, q0, q1)

    # ═══════════════════════════════════════════════════════
    # Barrier / Reset
    # ═══════════════════════════════════════════════════════
    def barrier(self, *qubits):
        """Visual separator (no physical effect)."""
        qs = list(qubits) if qubits else list(range(self.n_qubits))
        self._ops.append({'name': 'barrier', 'qubits': qs, 'params': []})
        return self

    def reset(self, qubit: int):
        """Reset qubit to |0⟩."""
        self._ops.append({'name': 'reset', 'qubits': [qubit], 'params': []})
        return self

    # ═══════════════════════════════════════════════════════
    # Measurement — Qiskit-like API
    # ═══════════════════════════════════════════════════════
    def measure(self, qubits, clbits=None):
        """
        Measure qubit(s) into classical bit(s).

        Usage
        -----
        qc.measure(0)               # single qubit
        qc.measure(0, 0)            # qubit 0 → clbit 0
        qc.measure([0,1], [0,1])    # list form
        """
        # Normalise to lists
        if isinstance(qubits, int):
            qubits = [qubits]
        if clbits is None:
            clbits = list(range(len(qubits)))
        elif isinstance(clbits, int):
            clbits = [clbits]

        for q, c in zip(qubits, clbits):
            if q not in self._measured_qubits:
                self._measured_qubits.append(q)   # flat, no nesting
            self._ops.append({
                'name': 'measure',
                'qubits': [q],
                'clbits': [c],
                'params': []
            })
        return self

    def measure_all(self):
        """Measure all qubits into corresponding classical bits."""
        return self.measure(
            list(range(self.n_qubits)),
            list(range(self.n_qubits))
        )

    # ═══════════════════════════════════════════════════════
    # Custom unitary
    # ═══════════════════════════════════════════════════════
    def unitary(self, matrix, qubits, label: str = 'U'):
        """Apply arbitrary unitary matrix."""
        self._ops.append({
            'name'  : label,
            'qubits': list(qubits),
            'params': [],
            'matrix': np.array(matrix, dtype=complex)
        })
        return self

    # ═══════════════════════════════════════════════════════
    # Noise model
    # ═══════════════════════════════════════════════════════
    def set_noise_model(self, noise_model):
        self._noise_model = noise_model
        return self

    # ═══════════════════════════════════════════════════════
    # Run / Execute
    # ═══════════════════════════════════════════════════════
    def run(self, shots: int = 1024, seed: int = None) -> dict:
        """
        Execute the circuit and return measurement counts.

        Parameters
        ----------
        shots : int  — number of samples
        seed  : int  — random seed for reproducibility

        Returns
        -------
        dict  — {'bitstring': count, ...}
        """
        if seed is not None:
            np.random.seed(seed)

        self._sv.reset()
        nm = self._noise_model

        for op in self._ops:
            name   = op['name']
            qubits = op['qubits']
            params = op.get('params', [])

            if name in ('barrier', 'measure'):
                continue

            if name == 'reset':
                self._sv.measure_qubit(qubits[0])
                continue

            # Custom unitary
            if 'matrix' in op:
                self._apply_matrix(op['matrix'], qubits)
                continue

            # Standard gate
            gate_fn = GATE_REGISTRY.get(name.lower())
            if gate_fn is None:
                raise ValueError(f"Unknown gate: '{name}'")

            mat = gate_fn(*params)
            self._apply_matrix(mat, qubits)

            if nm and len(qubits) == 1:
                nm.apply_gate_noise(name, self._sv, qubits[0])

        if not self._measured_qubits:
            return {}

        counts = self._sv.measure_all(shots)
        if nm:
            counts = nm.apply_readout_noise(counts)
        return counts

    def _apply_matrix(self, mat: np.ndarray, qubits: list):
        """Dispatch matrix application based on qubit count."""
        n = len(qubits)
        if n == 1:
            self._sv.apply_single(mat, qubits[0])
        elif n == 2:
            self._sv.apply_two(mat, qubits[0], qubits[1])
        elif n == 3:
            self._sv.apply_three(mat, qubits[0], qubits[1], qubits[2])
        else:
            raise ValueError(f"Gates with {n} qubits not supported")

    # ═══════════════════════════════════════════════════════
    # Statevector / Probabilities
    # ═══════════════════════════════════════════════════════
    def statevector(self) -> 'StateVector':
        """Run circuit without measurement and return statevector."""
        self._sv.reset()
        for op in self._ops:
            if op['name'] in ('barrier', 'measure', 'reset'):
                continue
            if 'matrix' in op:
                self._apply_matrix(op['matrix'], op['qubits'])
                continue
            gate_fn = GATE_REGISTRY.get(op['name'].lower())
            if gate_fn:
                mat = gate_fn(*op.get('params', []))
                self._apply_matrix(mat, op['qubits'])
        return self._sv

    def probabilities(self) -> dict:
        """State probabilities as dict without measurement collapse."""
        sv    = self.statevector()
        probs = sv.probabilities()
        return {
            format(i, f'0{self.n_qubits}b'): float(p)
            for i, p in enumerate(probs) if p > 1e-10
        }

    def bloch_vector(self, qubit: int) -> tuple:
        """Bloch sphere (x,y,z) for a single qubit."""
        return self.statevector().bloch_vector(qubit)

    # ═══════════════════════════════════════════════════════
    # Visualization
    # ═══════════════════════════════════════════════════════
    def draw(self, output: str = 'text', figsize=None, show: bool = True):
        """
        Draw the circuit.

        Parameters
        ----------
        output  : 'text' — Qiskit-style ASCII (default)
                  'mpl'  — matplotlib figure
        figsize : tuple  — (width, height) for mpl
        show    : bool   — call plt.show() automatically (mpl only)

        Jupyter  → qc.draw()         displays once via __repr__
        Script   → print(qc.draw())  prints the ASCII diagram
        """
        gate_ops = [op for op in self._ops
                    if op['name'] not in ('measure', 'barrier')]

        if output == 'text':
            from .visualize import draw_ascii
            return _Diagram(
                draw_ascii(gate_ops, self.n_qubits, self._measured_qubits)
            )

        elif output == 'mpl':
            from .visualize import draw_matplotlib
            import matplotlib.pyplot as plt
            fig = draw_matplotlib(
                gate_ops, self.n_qubits, self._measured_qubits,
                figsize=figsize, title=self.name
            )
            if show:
                plt.show()
            return fig

        else:
            raise ValueError("output must be 'text' or 'mpl'")

    def plot_histogram(self, counts: dict = None,
                       shots: int = 1024, show: bool = True):
        """Run circuit and plot measurement histogram."""
        from .visualize import plot_histogram
        import matplotlib.pyplot as plt
        if counts is None:
            counts = self.run(shots=shots)
        fig = plot_histogram(counts, title=self.name)
        if show:
            plt.show()
        return fig

    def plot_bloch(self, qubit: int = 0, show: bool = True):
        """Plot Bloch sphere for a qubit."""
        from .visualize import plot_bloch_sphere
        import matplotlib.pyplot as plt
        bx, by, bz = self.bloch_vector(qubit)
        fig = plot_bloch_sphere(bx, by, bz, qubit)
        if show:
            plt.show()
        return fig

    # ═══════════════════════════════════════════════════════
    # Circuit info
    # ═══════════════════════════════════════════════════════
    def depth(self) -> int:
        """Number of gate layers (excluding barriers)."""
        return sum(1 for op in self._ops if op['name'] != 'barrier')

    def count_ops(self) -> dict:
        """Count of each operation type."""
        counts = {}
        for op in self._ops:
            counts[op['name']] = counts.get(op['name'], 0) + 1
        return counts

    def copy(self) -> 'QuantumCircuit':
        """Deep copy of this circuit."""
        return copy.deepcopy(self)

    def inverse(self) -> 'QuantumCircuit':
        """Return the inverse (dagger) circuit."""
        dag_map = {'s':'sdg','sdg':'s','t':'tdg','tdg':'t'}
        inv = QuantumCircuit(self.n_qubits, self.n_classical,
                             self.name + '_inv')
        for op in reversed(self._ops):
            if op['name'] in ('measure','barrier','reset'):
                continue
            inv._ops.append({
                'name'  : dag_map.get(op['name'], op['name']),
                'qubits': op['qubits'],
                'params': [-p for p in op.get('params', [])]
            })
        return inv

    def compose(self, other: 'QuantumCircuit') -> 'QuantumCircuit':
        """Append another circuit onto this one."""
        if other.n_qubits != self.n_qubits:
            raise ValueError("Circuits must have same number of qubits")
        new = self.copy()
        new._ops.extend(copy.deepcopy(other._ops))
        new._measured_qubits = sorted(
            set(new._measured_qubits) | set(other._measured_qubits)
        )
        return new

    # ═══════════════════════════════════════════════════════
    # Internal helpers
    # ═══════════════════════════════════════════════════════
    def _g(self, name: str, qubits: list, params: list = None):
        """Add a gate operation."""
        self._ops.append({
            'name'  : name,
            'qubits': qubits,
            'params': params or []
        })
        return self

    def __repr__(self):
        return (f"QuantumCircuit(name='{self.name}', "
                f"n_qubits={self.n_qubits}, "
                f"depth={self.depth()}, "
                f"ops={self.count_ops()})")

    def __len__(self):
        return self.depth()
