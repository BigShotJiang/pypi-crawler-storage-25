"""
qqet.statevector - Custom statevector simulator (pure NumPy)
"""

import numpy as np
from .gates import GATE_REGISTRY, I


class StateVector:
    def __init__(self, n_qubits: int):
        self.n_qubits = n_qubits
        self.dim = 2 ** n_qubits
        self.state = np.zeros(self.dim, dtype=complex)
        self.state[0] = 1.0  # |00...0>

    def reset(self):
        self.state = np.zeros(self.dim, dtype=complex)
        self.state[0] = 1.0

    def apply_single(self, gate_matrix: np.ndarray, qubit: int):
        """Apply a single-qubit gate to the statevector."""
        n = self.n_qubits
        # Build full unitary via tensor product
        ops = []
        for q in range(n):
            if q == qubit:
                ops.append(gate_matrix)
            else:
                ops.append(I())
        full = ops[0]
        for op in ops[1:]:
            full = np.kron(full, op)
        self.state = full @ self.state

    def apply_two(self, gate_matrix: np.ndarray, control: int, target: int):
        """Apply a two-qubit gate."""
        n = self.n_qubits
        # Reorder: build full 2^n x 2^n unitary
        full = self._expand_two_qubit(gate_matrix, control, target, n)
        self.state = full @ self.state

    def apply_three(self, gate_matrix: np.ndarray, q0: int, q1: int, q2: int):
        """Apply a three-qubit gate."""
        n = self.n_qubits
        full = self._expand_three_qubit(gate_matrix, q0, q1, q2, n)
        self.state = full @ self.state

    def _expand_two_qubit(self, gate, q0, q1, n):
        """Expand 4x4 gate to full 2^n space."""
        dim = 2 ** n
        full = np.zeros((dim, dim), dtype=complex)
        for i in range(dim):
            for j in range(dim):
                # Extract bits for q0, q1
                bi0 = (i >> (n - 1 - q0)) & 1
                bi1 = (i >> (n - 1 - q1)) & 1
                bj0 = (j >> (n - 1 - q0)) & 1
                bj1 = (j >> (n - 1 - q1)) & 1
                # Check all other bits match
                mask = ~((1 << (n - 1 - q0)) | (1 << (n - 1 - q1)))
                if (i & mask) != (j & mask):
                    continue
                ri = bi0 * 2 + bi1
                rj = bj0 * 2 + bj1
                full[i, j] = gate[ri, rj]
        return full

    def _expand_three_qubit(self, gate, q0, q1, q2, n):
        """Expand 8x8 gate to full 2^n space."""
        dim = 2 ** n
        full = np.zeros((dim, dim), dtype=complex)
        for i in range(dim):
            for j in range(dim):
                bi0 = (i >> (n - 1 - q0)) & 1
                bi1 = (i >> (n - 1 - q1)) & 1
                bi2 = (i >> (n - 1 - q2)) & 1
                bj0 = (j >> (n - 1 - q0)) & 1
                bj1 = (j >> (n - 1 - q1)) & 1
                bj2 = (j >> (n - 1 - q2)) & 1
                mask = ~((1 << (n-1-q0)) | (1 << (n-1-q1)) | (1 << (n-1-q2)))
                if (i & mask) != (j & mask):
                    continue
                ri = bi0 * 4 + bi1 * 2 + bi2
                rj = bj0 * 4 + bj1 * 2 + bj2
                full[i, j] = gate[ri, rj]
        return full

    def probabilities(self) -> np.ndarray:
        return np.abs(self.state) ** 2

    def measure_all(self, shots: int = 1024) -> dict:
        probs = self.probabilities()
        outcomes = np.random.choice(self.dim, size=shots, p=probs)
        counts = {}
        for o in outcomes:
            key = format(o, f'0{self.n_qubits}b')
            counts[key] = counts.get(key, 0) + 1
        return dict(sorted(counts.items()))

    def measure_qubit(self, qubit: int) -> int:
        """Collapse a single qubit, update state."""
        probs = self.probabilities()
        prob_0 = sum(
            probs[i] for i in range(self.dim)
            if not (i >> (self.n_qubits - 1 - qubit)) & 1
        )
        outcome = 0 if np.random.random() < prob_0 else 1
        # Project state
        new_state = np.zeros(self.dim, dtype=complex)
        for i in range(self.dim):
            bit = (i >> (self.n_qubits - 1 - qubit)) & 1
            if bit == outcome:
                new_state[i] = self.state[i]
        # Normalize
        norm = np.linalg.norm(new_state)
        if norm > 1e-10:
            new_state /= norm
        self.state = new_state
        return outcome

    def get_statevector(self) -> np.ndarray:
        return self.state.copy()

    def bloch_vector(self, qubit: int) -> tuple:
        """Bloch sphere coordinates for a single qubit (reduced density matrix)."""
        rho = np.outer(self.state, self.state.conj())
        # Trace out all qubits except target
        from .gates import X, Y, Z
        n = self.n_qubits
        dim = 2 ** n
        # Build single-qubit density matrix
        rho_q = np.zeros((2, 2), dtype=complex)
        for i in range(2):
            for j in range(2):
                for k in range(dim // 2):
                    row = self._insert_bit(k, qubit, i, n)
                    col = self._insert_bit(k, qubit, j, n)
                    rho_q[i, j] += rho[row, col]
        bx = float(np.real(np.trace(X() @ rho_q)))
        by = float(np.real(np.trace(Y() @ rho_q)))
        bz = float(np.real(np.trace(Z() @ rho_q)))
        return bx, by, bz

    def _insert_bit(self, k, qubit, bit, n):
        """Insert a bit into position qubit within n-bit index k."""
        pos = n - 1 - qubit
        lower = k & ((1 << pos) - 1)
        upper = (k >> pos) << (pos + 1)
        return upper | (bit << pos) | lower

    def __repr__(self):
        lines = [f"StateVector ({self.n_qubits} qubits):"]
        for i, amp in enumerate(self.state):
            if abs(amp) > 1e-10:
                basis = format(i, f'0{self.n_qubits}b')
                lines.append(f"  |{basis}⟩: {amp:.4f}  (p={abs(amp)**2:.4f})")
        return "\n".join(lines)
