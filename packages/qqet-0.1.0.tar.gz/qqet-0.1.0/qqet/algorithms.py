"""
qqet.algorithms - Pre-built quantum algorithms
"""

import numpy as np
from .circuit import QuantumCircuit


def bell_state(state: str = '00') -> QuantumCircuit:
    """
    Generate one of the 4 Bell states.
    state: '00' | '01' | '10' | '11'
    """
    qc = QuantumCircuit(2, name=f'bell_{state}')
    if state[0] == '1':
        qc.x(0)
    if state[1] == '1':
        qc.x(1)
    qc.h(0)
    qc.cnot(0, 1)
    return qc


def ghz_state(n: int) -> QuantumCircuit:
    """GHZ state: (|000...0> + |111...1>) / sqrt(2)"""
    qc = QuantumCircuit(n, name=f'ghz_{n}')
    qc.h(0)
    for i in range(n - 1):
        qc.cnot(i, i + 1)
    return qc


def qft(n: int) -> QuantumCircuit:
    """Quantum Fourier Transform on n qubits."""
    qc = QuantumCircuit(n, name=f'qft_{n}')
    for j in range(n):
        qc.h(j)
        for k in range(j + 1, n):
            qc.cp(np.pi / (2 ** (k - j)), k, j)
    # Swap qubits
    for i in range(n // 2):
        qc.swap(i, n - 1 - i)
    return qc


def qft_inverse(n: int) -> QuantumCircuit:
    """Inverse QFT on n qubits."""
    return qft(n).inverse()


def grover_diffusion(n: int) -> QuantumCircuit:
    """Grover's diffusion operator."""
    qc = QuantumCircuit(n, name='grover_diffusion')
    for i in range(n):
        qc.h(i)
    for i in range(n):
        qc.x(i)
    qc.h(n - 1)
    # Multi-controlled X (approximated for n<=3)
    if n == 2:
        qc.cnot(0, 1)
    elif n == 3:
        qc.ccx(0, 1, 2)
    qc.h(n - 1)
    for i in range(n):
        qc.x(i)
    for i in range(n):
        qc.h(i)
    return qc


def deutsch_jozsa(oracle_type: str = 'balanced', n: int = 3) -> QuantumCircuit:
    """
    Deutsch-Jozsa algorithm.
    oracle_type: 'constant_0' | 'constant_1' | 'balanced'
    """
    qc = QuantumCircuit(n + 1, name='deutsch_jozsa')
    # Init ancilla to |1>
    qc.x(n)
    # Hadamard all
    for i in range(n + 1):
        qc.h(i)
    # Oracle
    if oracle_type == 'constant_1':
        qc.x(n)
    elif oracle_type == 'balanced':
        for i in range(n):
            qc.cnot(i, n)
    # Final Hadamard on input qubits
    for i in range(n):
        qc.h(i)
    for i in range(n):
        qc.measure(i)
    return qc


def bernstein_vazirani(secret: str) -> QuantumCircuit:
    """
    Bernstein-Vazirani algorithm.
    secret: binary string, e.g. '101'
    """
    n = len(secret)
    qc = QuantumCircuit(n + 1, name='bernstein_vazirani')
    qc.x(n)
    for i in range(n + 1):
        qc.h(i)
    # Oracle: CNOT for each '1' in secret
    for i, bit in enumerate(secret):
        if bit == '1':
            qc.cnot(i, n)
    for i in range(n):
        qc.h(i)
    for i in range(n):
        qc.measure(i)
    return qc


def simon(n: int, s: str) -> QuantumCircuit:
    """
    Simon's algorithm (one round).
    s: secret binary string of length n
    """
    qc = QuantumCircuit(2 * n, name='simon')
    for i in range(n):
        qc.h(i)
    # Simple oracle
    for i in range(n):
        qc.cnot(i, n + i)
    if s != '0' * n:
        idx = s.index('1')
        for i, bit in enumerate(s):
            if bit == '1':
                qc.cnot(idx, n + i)
    for i in range(n):
        qc.h(i)
    for i in range(n):
        qc.measure(i)
    return qc


def teleportation() -> QuantumCircuit:
    """Quantum teleportation circuit (3 qubits)."""
    qc = QuantumCircuit(3, name='teleportation')
    # Prepare Bell pair on q1, q2
    qc.h(1)
    qc.cnot(1, 2)
    # Encode message qubit (q0 already in some state)
    qc.cnot(0, 1)
    qc.h(0)
    # Measure q0, q1
    qc.measure(0)
    qc.measure(1)
    # Classically conditioned corrections (approximated)
    qc.cnot(1, 2)
    qc.cz(0, 2)
    return qc


def superdense_coding() -> QuantumCircuit:
    """Superdense coding circuit."""
    qc = QuantumCircuit(2, name='superdense_coding')
    # Create entanglement
    qc.h(0)
    qc.cnot(0, 1)
    # Encode (example: message '11')
    qc.x(0)
    qc.z(0)
    # Decode
    qc.cnot(0, 1)
    qc.h(0)
    qc.measure_all()
    return qc


def phase_estimation(n_count: int, theta: float) -> QuantumCircuit:
    """
    Quantum Phase Estimation for e^(2πi*theta).
    n_count: number of counting qubits
    theta: phase to estimate (0 < theta < 1)
    """
    qc = QuantumCircuit(n_count + 1, name='phase_estimation')
    # Init eigenstate
    qc.x(n_count)
    # Superposition on counting qubits
    for i in range(n_count):
        qc.h(i)
    # Controlled unitary applications
    for i in range(n_count):
        angle = 2 * np.pi * theta * (2 ** i)
        qc.cp(angle, i, n_count)
    # Inverse QFT
    inv_qft = qft_inverse(n_count)
    for op in inv_qft._ops:
        qc._ops.append(op)
    for i in range(n_count):
        qc.measure(i)
    return qc


def random_circuit(n_qubits: int, depth: int, seed: int = None) -> QuantumCircuit:
    """Generate a random quantum circuit."""
    if seed is not None:
        np.random.seed(seed)
    qc = QuantumCircuit(n_qubits, name='random')
    single_gates = ['h', 'x', 'y', 'z', 's', 't', 'sx']
    rot_gates = ['rx', 'ry', 'rz']
    for _ in range(depth):
        for q in range(n_qubits):
            choice = np.random.choice(['single', 'rot', 'two'], p=[0.4, 0.3, 0.3])
            if choice == 'single':
                gate = np.random.choice(single_gates)
                getattr(qc, gate)(q)
            elif choice == 'rot':
                gate = np.random.choice(rot_gates)
                theta = np.random.uniform(0, 2 * np.pi)
                getattr(qc, gate)(theta, q)
            elif choice == 'two' and n_qubits > 1:
                tgt = (q + 1) % n_qubits
                qc.cnot(q, tgt)
    return qc
