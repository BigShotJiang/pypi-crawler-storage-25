#!/usr/bin/env python3
"""
XYZ CLI Tool - API-based Vulnerability Scanner
Unified command-line interface for vulnerability scanning via XYZ API
"""

import os
import sys
import json
import socket
import platform
import subprocess
import stat
import click
import requests as _requests
from typing import Optional, List, Dict, Any
from tabulate import tabulate
from datetime import datetime
from rich.console import Console
from rich.table import Table
from rich.text import Text
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from xyz_cli.client import XYZAPIClient

# Initialize Rich console for better formatting
console = Console()

# Global client instance
client = None

def get_computer_name():
    system = platform.system()
    if system == "Darwin":
        try:
            return subprocess.check_output(['scutil', '--get', 'ComputerName']).decode().strip()
        except Exception:
            return platform.node()
    elif system == "Windows":
        return platform.node()
    else:
        return socket.gethostname()

def init_client():
    """Initialize the API client"""
    global client
    if client is None:
        try:
            client = XYZAPIClient()
        except ValueError as e:
            console.print(f"[red]Error:[/red] {e}")
            console.print("\n[yellow]Setup Instructions:[/yellow]")
            console.print("1. Login using: [bold]xyz login[/bold]")
            console.print("2. (or) Set your API key: [bold]export XYZ_API_KEY=sk_xyz_your_key_here[/bold]")
            console.print("3. Set API URL (optional): [bold]export XYZ_API_URL=https://api.cyberxyz.io/[/bold]")
            console.print("4. Contact support@xyz-security.com for access.")
            sys.exit(1)
        
        # Check if client is authenticated
        if 'Authorization' not in client.session.headers:
            console.print("[red]Error:[/red] You are not logged in and no API key is configured.")
            console.print("Please run [bold]xyz login[/bold] or set the [bold]XYZ_API_KEY[/bold] environment variable.")
            sys.exit(1)

def format_vulnerability_table(vulnerabilities: List[Dict], include_exploits: bool = False, package_version: Optional[str] = None) -> Table:
    """Format vulnerabilities as a Rich table with deduplication and optimized layout"""
    # Deduplicate vulnerabilities by ID (CVE, GHSA, etc.)
    seen_ids = set()
    unique_vulns = []
    
    for vuln in vulnerabilities:
        # Use multiple ID fields to identify duplicates
        vuln_id = vuln.get('cve_id') or vuln.get('id') or vuln.get('ghsa_id') or vuln.get('osv_id')
        if vuln_id and vuln_id != 'N/A' and vuln_id not in seen_ids:
            seen_ids.add(vuln_id)
            unique_vulns.append(vuln)
        elif not vuln_id or vuln_id == 'N/A':
            # Keep entries without IDs but check for duplicate descriptions
            desc = vuln.get('description', '')[:50]  # First 50 chars as identifier
            if desc and desc not in seen_ids:
                seen_ids.add(desc)
                unique_vulns.append(vuln)
    
    title = f"Vulnerability Results ({len(unique_vulns)} unique)"
    if package_version:
        title += f" for version {package_version}"
    table = Table(title=title, show_lines=True, expand=False)
    
    # Optimized columns — no fixed widths so Rich auto-sizes to terminal
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Package", style="magenta", no_wrap=True)
    table.add_column("Severity", style="red", justify="center", no_wrap=True)
    table.add_column("XYZ Score", justify="center", no_wrap=True)
    table.add_column("EPSS", justify="center", no_wrap=True)
    table.add_column("Published", style="yellow", no_wrap=True)
    table.add_column("Summary", style="dim", ratio=2)
    
    if include_exploits:
        table.add_column("Exploits", style="red")
    
    for vuln in unique_vulns:
        # Get the best available ID
        vuln_id = vuln.get('cve_id') or vuln.get('id') or vuln.get('ghsa_id') or vuln.get('osv_id') or 'Unknown'
        
        # Get package name, handle missing data better
        package_name = vuln.get('package_name') or vuln.get('affected', [{}])[0].get('package', {}).get('name', 'Unknown')
        
        # Format severity with color and status indicators
        severity = (vuln.get('severity') or 'UNKNOWN').upper()
        status_indicators = []
        
        # Check if this is a malicious package (MAL- ID prefix)
        vuln_id = vuln.get('cve_id') or vuln.get('id') or vuln.get('ghsa_id') or vuln.get('osv_id') or ''
        is_malicious = isinstance(vuln_id, str) and vuln_id.startswith('MAL-')
        
        if is_malicious or vuln.get('malicious_info', {}).get('is_malicious'):
            status_indicators.append("🦠")
        if vuln.get('exploit_info', {}).get('has_exploits'):
            status_indicators.append("🔓")
        # Mark malicious packages as exploited in wild (supply chain attacks are active threats)
        if vuln.get('exploited_in_wild') or is_malicious:
            status_indicators.append("⚠️")
        
        # Determine severity from CVSS if available
        cvss_score = vuln.get('cvss_score')
        cvss_display = 'N/A'
        if cvss_score:
            try:
                score = float(cvss_score)
                cvss_display = f"{score:.1f}"
                if score >= 9.0:
                    severity = "CRITICAL"
                elif score >= 7.0:
                    severity = "HIGH"
                elif score >= 4.0:
                    severity = "MEDIUM"
                else:
                    severity = "LOW"
            except (ValueError, TypeError):
                cvss_display = str(cvss_score)
        
        # Color-code severity
        if severity == 'CRITICAL':
            severity_colored = f"[red bold]{severity}[/red bold]"
        elif severity == 'HIGH':
            severity_colored = f"[red]{severity}[/red]"
        elif severity == 'MEDIUM' or severity == 'MODERATE':
            severity_colored = f"[yellow]{severity}[/yellow]"
        elif severity == 'LOW':
            severity_colored = f"[green]{severity}[/green]"
        else:
            severity_colored = f"[dim]{severity}[/dim]"
        
        # Add status indicators to severity on new line to prevent table misalignment
        if status_indicators:
            severity_colored += f"\n{''.join(status_indicators)}"
        
        # Format publication date
        pub_date = vuln.get('publication_date') or vuln.get('published_at') or vuln.get('published')
        if pub_date and pub_date != 'N/A':
            try:
                # Try to format date nicely
                from datetime import datetime
                if 'T' in pub_date:
                    dt = datetime.fromisoformat(pub_date.replace('Z', '+00:00'))
                    pub_date = dt.strftime('%Y-%m-%d')
            except:
                pass  # Keep original format if parsing fails
        else:
            pub_date = 'Unknown'
        
        # Format description/summary
        description = vuln.get('description') or vuln.get('summary') or 'No description available'
        if len(description) > 80:
            description = description[:77] + "..."
        
        # Format XYZ Score with color gradient (orange theme)
        xyz_score = vuln.get('xyz_score') or vuln.get('xyz_score_stored')
        if xyz_score is not None:
            try:
                score_val = float(xyz_score)
                if score_val >= 8.0:
                    xyz_display = f"[bold red]{score_val:.1f}[/bold red]"
                elif score_val >= 6.0:
                    xyz_display = f"[bold orange3]{score_val:.1f}[/bold orange3]"
                elif score_val >= 4.0:
                    xyz_display = f"[orange3]{score_val:.1f}[/orange3]"
                else:
                    xyz_display = f"[dark_orange3]{score_val:.1f}[/dark_orange3]"
            except (ValueError, TypeError):
                xyz_display = "[dim]—[/dim]"
        else:
            xyz_display = "[dim]—[/dim]"
        
        # Format EPSS with color (blue theme)
        epss_score = vuln.get('epss_score')
        if epss_score is not None:
            try:
                epss_val = float(epss_score)
                epss_pct = epss_val * 100
                if epss_pct >= 50:
                    epss_display = f"[bold red]{epss_pct:.1f}%[/bold red]"
                elif epss_pct >= 10:
                    epss_display = f"[bold dodger_blue2]{epss_pct:.1f}%[/bold dodger_blue2]"
                elif epss_pct >= 1:
                    epss_display = f"[dodger_blue2]{epss_pct:.1f}%[/dodger_blue2]"
                else:
                    epss_display = f"[steel_blue1]{epss_pct:.2f}%[/steel_blue1]"
            except (ValueError, TypeError):
                epss_display = "[dim]—[/dim]"
        else:
            epss_display = "[dim]—[/dim]"
        
        # Build row
        row = [
            vuln_id,
            package_name,
            severity_colored,
            xyz_display,
            epss_display,
            pub_date,
            description
        ]
        
        table.add_row(*row)
    
    return table

def print_vulnerability_details(vuln: Dict, include_exploits: bool = False):
    """Print detailed vulnerability information"""
    console.print(f"\n[bold cyan]Vulnerability Details: {vuln.get('id', 'N/A')}[/bold cyan]")
    
    # Basic info
    info_table = Table(show_header=False, box=None)
    info_table.add_column("Field", style="bold")
    info_table.add_column("Value")
    
    info_table.add_row("Package", vuln.get('package_name') or 'N/A')
    info_table.add_row("Ecosystem", vuln.get('ecosystem') or 'N/A')
    info_table.add_row("Severity", vuln.get('severity') or 'N/A')
    info_table.add_row("CVSS Score", str(vuln.get('cvss_score') or 'N/A'))
    info_table.add_row("Description", (vuln.get('description') or 'N/A')[:100] + "..." if len(vuln.get('description', '')) > 100 else (vuln.get('description') or 'N/A'))
    
    console.print(info_table)
    
    # Malicious package info
    if vuln.get('malicious_info', {}).get('is_malicious'):
        console.print("\n[red]⚠️  MALICIOUS PACKAGE DETECTED[/red]")
        malicious_info = vuln['malicious_info']
        console.print(f"Source: {malicious_info.get('source', 'N/A')}")
        console.print(f"Detected: {malicious_info.get('detection_date', 'N/A')}")
        if malicious_info.get('references'):
            console.print(f"References: {', '.join(malicious_info['references'][:3])}")
    
    # Exploit info
    if include_exploits and vuln.get('exploit_info', {}).get('has_exploits'):
        console.print("\n[orange1]🔓 EXPLOIT INFORMATION[/orange1]")
        exploits = vuln['exploit_info'].get('exploits', [])
        
        exploit_table = Table()
        exploit_table.add_column("Author", style="cyan")
        exploit_table.add_column("Type", style="magenta")
        exploit_table.add_column("Platform", style="blue")
        exploit_table.add_column("Verified", style="green")
        
        for exploit in exploits[:5]:  # Show first 5 exploits
            exploit_table.add_row(
                exploit.get('author', 'N/A'),
                exploit.get('type', 'N/A'),
                exploit.get('platform', 'N/A'),
                "✅" if exploit.get('verified') else "❌"
            )
        
        console.print(exploit_table)
        
        if len(exploits) > 5:
            console.print(f"... and {len(exploits) - 5} more exploits")

@click.group()
@click.option('--api-key', envvar='XYZ_API_KEY', help='API key for XYZ Vulnerability API')
@click.option('--api-url', envvar='XYZ_API_URL', help='API base URL')
@click.option('--debug', is_flag=True, help='Enable debug output')
@click.pass_context
def cli(ctx, api_key, api_url, debug):
    """XYZ Vulnerability Scanner - API-based CLI tool"""
    ctx.ensure_object(dict)
    ctx.obj['api_key'] = api_key
    ctx.obj['api_url'] = api_url
    ctx.obj['debug'] = debug
    
    if debug:
        console.print(f"[dim]API URL: {api_url}[/dim]")
        console.print(f"[dim]API Key: {'Set' if api_key else 'Not set'}[/dim]")

@cli.command()
@click.pass_context
def info(ctx):
    """Show API information and capabilities"""
    init_client()
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description="Fetching API info...", total=None)
            
            api_info = client.get_api_info()
            health = client.health_check()
        
        # User status
        user_info = client.get_user_info()
        if user_info and 'email' in user_info:
            login_status = f"[green]Logged in as: {user_info['email']}[/green]"
        else:
            login_status = "[yellow]Not logged in[/yellow]"

        console.print(Panel.fit(f"[bold green]XYZ Vulnerability API[/bold green]\nVersion: {api_info.get('api_version', 'N/A')}\nStatus: {health.get('status', 'Unknown')}\nUser: {login_status}"))
        
        # Features
        console.print("\n[bold]Features:[/bold]")
        features = api_info.get('features', {})
        features['apt_zero_day'] = True  # Manually add this feature
        for feature, enabled in features.items():
            status = "✅" if enabled else "❌"
            feature_text = feature.replace('_', ' ').title()
            if feature == 'apt_zero_day':
                feature_text = "APT Zero-Day Vulnerabilities Detection + Exploitatbility"
            console.print(f"  {status} {feature_text}")
        
        # Supported formats
        console.print(f"\n[bold]Supported Vulnerability Types:[/bold]")
        for vuln_type in api_info.get('supported_vulnerabilities', []):
            console.print(f"  • {vuln_type}")
        
        # Rate limits
        console.print(f"\n[bold]Rate Limits:[/bold]")
        for tier, limit in api_info.get('rate_limits', {}).items():
            console.print(f"  • {tier.title()}: {limit}")
        
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.argument('vuln_id')
@click.option('-x', '--exploits', is_flag=True, help='Include exploit information')
@click.option('--affected', is_flag=True, help='Show affected packages')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
@click.pass_context
def vuln(ctx, vuln_id, exploits, affected, output_json):
    """Search for a specific vulnerability by ID (CVE, GHSA, OSV, etc.)"""
    init_client()
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description=f"Searching for {vuln_id}...", total=None)
            
            result = client.search_vulnerability_by_id(vuln_id, include_exploits=exploits)
        
        if output_json:
            console.print(json.dumps(result, indent=2))
        else:
            vulnerabilities = result.get('vulnerabilities', [])
            scores = result.get('scores', {})
            
            # Inject scores into each vulnerability for table display
            if scores:
                for v in vulnerabilities:
                    if 'xyz_score' not in v and scores.get('xyz_score') is not None:
                        v['xyz_score'] = scores['xyz_score']
                    if 'epss_score' not in v and scores.get('epss_score') is not None:
                        v['epss_score'] = scores['epss_score']
            
            if vulnerabilities:
                table = format_vulnerability_table(vulnerabilities, include_exploits=exploits)
                console.print(table)
                
                # Show scores summary
                if scores:
                    score_parts = []
                    if scores.get('xyz_score') is not None:
                        score_parts.append(f"[bold orange3]XYZ Score: {scores['xyz_score']:.1f}/10[/bold orange3]")
                    if scores.get('epss_score') is not None:
                        epss_pct = scores['epss_score'] * 100
                        score_parts.append(f"[bold dodger_blue2]EPSS: {epss_pct:.2f}%[/bold dodger_blue2]")
                    if scores.get('epss_percentile') is not None:
                        pctile = scores['epss_percentile'] * 100
                        score_parts.append(f"[dim]Percentile: {pctile:.0f}th[/dim]")
                    if score_parts:
                        console.print(" | ".join(score_parts))
                
                # Show detailed info for first vulnerability
                if vulnerabilities:
                    print_vulnerability_details(vulnerabilities[0], include_exploits=exploits)
                    
                    # Show affected packages if requested
                    if affected:
                        console.print("\n[bold cyan]🎯 Affected Packages:[/bold cyan]")
                        affected_packages = set()
                        for vuln in vulnerabilities:
                            if vuln.get('package_name'):
                                pkg_name = vuln.get('package_name')
                                ecosystem = vuln.get('ecosystem', 'Unknown')
                                affected_packages.add(f"{pkg_name} ({ecosystem})")
                        
                        if affected_packages:
                            for package in sorted(affected_packages):
                                console.print(f"  • {package}")
                        else:
                            console.print("  [dim]No specific package information available[/dim]")
            else:
                console.print(f"[yellow]No vulnerabilities found for {vuln_id}[/yellow]")
        
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.argument('package_name')
@click.option('-e', '--ecosystem', help='Filter by ecosystem (npm, pypi, maven, etc.)')
@click.option('-v', '--version', help='Filter by package version')
@click.option('-s', '--severity', help='Filter by severity (critical, high, medium, low)')
@click.option('-x', '--exploits', is_flag=True, help='Include exploit information')
@click.option('--limit', default=50, help='Maximum results to return')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
@click.pass_context
def package(ctx, package_name, ecosystem, version, severity, exploits, limit, output_json):
    """Search for vulnerabilities affecting a specific package"""
    init_client()
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description=f"Scanning package {package_name}...", total=None)
            
            result = client.search_package_vulnerabilities(
                package_name=package_name,
                ecosystem=ecosystem,
                version=version,
                severity=severity,
                limit=limit,
                include_exploits=exploits,
                machine_name=socket.gethostname(),
                os_type=platform.system(),
                computer_name=get_computer_name(),
                scan_command=f"xyz package {package_name}" + (f" -v {version}" if version else "")
            )
        
        if output_json:
            console.print(json.dumps(result, indent=2))
        else:
            packages = result.get('packages', [])
            if packages:
                # Show summary
                summary = result.get('summary', {})
                console.print(f"\n[bold]Scan Results for '{package_name}'[/bold]")
                console.print(f"Packages found: {summary.get('total_packages', 0)}")
                console.print(f"Total vulnerabilities: {summary.get('total_vulnerabilities', 0)}")
                
                # Show each package's vulnerabilities
                for pkg in packages:
                    console.print(f"\n[bold cyan]📦 {pkg['package_name']} ({pkg['ecosystem']})[/bold cyan]")
                    console.print(f"Vulnerabilities: {pkg['vulnerability_count']}")
                    
                    # Show severity breakdown
                    severity_summary = pkg.get('severity_summary', {})
                    if severity_summary:
                        console.print("Severity breakdown:")
                        for sev, count in severity_summary.items():
                            console.print(f"  • {sev.title()}: {count}")
                    
                    # Show vulnerability table
                    if pkg['vulnerabilities']:
                        table = format_vulnerability_table(pkg['vulnerabilities'], include_exploits=exploits, package_version=version)
                        console.print(table)
                        
                        # Show detailed information for malicious packages
                        for vuln in pkg['vulnerabilities']:
                            vuln_id = vuln.get('id') or vuln.get('cve_id') or vuln.get('ghsa_id') or vuln.get('osv_id') or ''
                            is_malicious = isinstance(vuln_id, str) and vuln_id.startswith('MAL-')
                            
                            if is_malicious or vuln.get('details') or vuln.get('affected'):
                                console.print(f"\n[bold red]⚠️  Vulnerability Details: {vuln_id}[/bold red]")
                                
                                # Show affected versions
                                affected = vuln.get('affected', [])
                                if affected and len(affected) > 0:
                                    versions = affected[0].get('versions', [])
                                    if versions:
                                        console.print(f"[yellow]Affected Versions:[/yellow] {', '.join(versions)}")
                                
                                # Show details for malicious packages
                                details = vuln.get('details', '')
                                if details:
                                    console.print(f"\n[bold]Details:[/bold]")
                                    # Extract the important parts of the details
                                    if 'Sha1-Hulud' in details or 'SHA1Hulud' in details:
                                        console.print("[red bold]🦠 MALICIOUS PACKAGE - SUPPLY CHAIN ATTACK[/red bold]")
                                    
                                    # Show details (truncate if too long)
                                    detail_lines = details.split('\n')
                                    for line in detail_lines[:15]:  # Show first 15 lines
                                        if line.strip() and not line.startswith('---') and not line.startswith('_-='):
                                            console.print(f"  {line}")
                                    
                                    if len(detail_lines) > 15:
                                        console.print(f"  [dim]... ({len(detail_lines) - 15} more lines)[/dim]")
                                
                                console.print()  # Add spacing
            else:
                console.print(f"[yellow]No vulnerabilities found for package '{package_name}'[/yellow]")
        
        # Upload scan results to the platform
        if packages:  # Only upload if we found results
            console.print("Sending package scan results to the platform...")
            try:
                client.send_package_scan({
                    **result,
                    "machine_name": socket.gethostname(),
                    "os_type": platform.system(),
                    "computer_name": get_computer_name(),
                    "scan_command": f"xyz package {package_name}" + (f" -v {version}" if version else "")
                })
                console.print("[green]Successfully uploaded package scan results.[/green]")
            except Exception as upload_error:
                console.print(f"[yellow]Warning: Failed to upload scan results: {upload_error}[/yellow]")
        
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.option('--python', 'scan_python', is_flag=True, help='Scan Python packages')
@click.option('--npm', 'scan_npm', is_flag=True, help='Scan npm packages')
@click.option('-i', '--system', 'scan_system', is_flag=True, help='Scan system packages')
@click.option('--java', 'scan_java', is_flag=True, help='Scan Java packages')
@click.option('--go', 'scan_go', is_flag=True, help='Scan Go packages')
@click.option('--php', 'scan_php', is_flag=True, help='Scan PHP packages')
@click.option('--microsoft', 'scan_microsoft', is_flag=True, help='Scan Microsoft packages')
@click.option('--all', 'scan_all', is_flag=True, help='Scan all package types')
@click.option('-x', '--exploits', is_flag=True, help='Include exploit information')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
@click.option('--list-packages', is_flag=True, help='Only list installed packages, do not scan for vulnerabilities')
@click.option('-p', '--package', 'specific_package', help='Scan a specific package by name')
@click.pass_context
def scan(ctx, scan_python, scan_npm, scan_system, scan_java, scan_go, scan_php, scan_microsoft, scan_all, exploits, output_json, list_packages, specific_package):
    """Scan installed packages for vulnerabilities"""
    init_client()
    
    if list_packages:
        console.print("[bold]Listing installed packages...[/bold]")
        
        package_types = []
        if scan_python or scan_all:
            package_types.append("python")
        if scan_npm or scan_all:
            package_types.append("npm")
        if scan_system or scan_all:
            package_types.append("system")
        if scan_java or scan_all:
            package_types.append("java")
        if scan_go or scan_all:
            package_types.append("go")
        if scan_php or scan_all:
            package_types.append("php")
        if scan_microsoft or scan_all:
            package_types.append("microsoft")
            
        results = client.list_packages(
            package_types=package_types,
            machine_name=socket.gethostname(),
            os_type=platform.system(),
            computer_name=get_computer_name()
        )
        
        for pkg_type, pkgs in results.items():
            console.print(f"\n[bold cyan]{pkg_type.title()} Packages[/bold cyan]")
            if pkgs:
                for pkg in pkgs:
                    if 'type' in pkg:
                        console.print(f"  - {pkg['name']} ({pkg['version']}) [{pkg['type']}]")
                    else:
                        console.print(f"  - {pkg['name']} ({pkg['version']})")
            else:
                console.print("  [dim]No packages found.[/dim]")
        return

    # Handle specific package scanning
    if specific_package:
        console.print(f"[bold]Scanning specific package: {specific_package}[/bold]")
        
        try:
            # Search for vulnerabilities in the specific package
            vulnerabilities = client.search_package_vulnerabilities(
                package_name=specific_package,
                include_exploits=exploits
            )
            
            if output_json:
                import json
                print(json.dumps(vulnerabilities, indent=2))
                return
            
            if vulnerabilities and vulnerabilities.get('vulnerabilities'):
                vulns = vulnerabilities['vulnerabilities']
                console.print(f"\n[bold red]Found {len(vulns)} vulnerabilities for {specific_package}:[/bold red]")
                
                for vuln in vulns:
                    severity = vuln.get('severity', 'Unknown').upper()
                    severity_color = {
                        'CRITICAL': 'bold red',
                        'HIGH': 'red',
                        'MEDIUM': 'yellow',
                        'LOW': 'green',
                        'UNKNOWN': 'dim'
                    }.get(severity, 'dim')
                    
                    console.print(f"  • [{severity_color}]{vuln.get('id', 'N/A')}[/{severity_color}] - {severity}")
                    console.print(f"    Summary: {vuln.get('summary', 'No summary available')}")
                    if vuln.get('affected_versions'):
                        console.print(f"    Affected: {vuln.get('affected_versions')}")
                    if exploits and vuln.get('exploits'):
                        console.print(f"    [bold red]Exploits available: {len(vuln['exploits'])}[/bold red]")
                    console.print()
            else:
                console.print(f"[green]No vulnerabilities found for {specific_package}[/green]")
                
        except Exception as e:
            console.print(f"[red]Error scanning package {specific_package}: {e}[/red]")
            sys.exit(1)
        return

    # Handle scan type selection
    if scan_all:
        scan_python = scan_npm = scan_system = scan_java = scan_go = scan_php = scan_microsoft = True
    elif not any([scan_python, scan_npm, scan_system, scan_java, scan_go, scan_php, scan_microsoft]):
        # Default to Python and npm if none specified (matching legacy behavior)
        scan_python = True
        scan_npm = True
    
    results = {}
    
    try:
        if scan_python:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                progress.add_task(description="Scanning Python packages...", total=None)
                
                results['python'] = client.scan_python_packages(include_exploits=exploits, machine_name=socket.gethostname(), os_type=platform.system(), computer_name=get_computer_name())
        
        if scan_npm:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                progress.add_task(description="Scanning npm packages...", total=None)
                
                results['npm'] = client.scan_npm_packages(include_exploits=exploits, machine_name=socket.gethostname(), os_type=platform.system(), computer_name=get_computer_name())
        
        if scan_system:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                progress.add_task(description="Scanning system packages...", total=None)
                
                try:
                    # For now, system scanning is not implemented in API backend
                    # This is a placeholder that matches the legacy CLI behavior
                    console.print("\n[yellow]⚠️  System package scanning not yet implemented in API backend[/yellow]")
                    console.print("[dim]Use the legacy CLI for system package scanning: ./xyz scan -i[/dim]")
                    results['system'] = {'scan_results': {'vulnerabilities': []}, 'message': 'Not implemented'}
                except Exception as e:
                    console.print(f"[red]Error scanning system packages:[/red] {e}")
                    results['system'] = {'error': str(e)}
        
        if scan_java:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                progress.add_task(description="Scanning Java packages...", total=None)
                
                results['java'] = client.scan_java_packages(include_exploits=exploits, machine_name=socket.gethostname(), os_type=platform.system(), computer_name=get_computer_name())
        
        if scan_go:
            console.print("\n[yellow]⚠️  Go package scanning not yet implemented.[/yellow]")
            results['go'] = {'scan_results': {'vulnerabilities': []}, 'message': 'Not implemented'}
        
        if scan_php:
            console.print("\n[yellow]⚠️  PHP package scanning not yet implemented.[/yellow]")
            results['php'] = {'scan_results': {'vulnerabilities': []}, 'message': 'Not implemented'}

        if scan_microsoft:
            console.print("\n[yellow]⚠️  Microsoft package scanning not yet implemented.[/yellow]")
            results['microsoft'] = {'scan_results': {'vulnerabilities': []}, 'message': 'Not implemented'}
        
        if output_json:
            console.print(json.dumps(results, indent=2))
        else:
            # Display results for each scan type
            for scan_type, result in results.items():
                console.print(f"\n[bold]🔍 {scan_type.title()} Package Scan Results[/bold]")
                
                scan_results = result.get('scan_results', {})
                if scan_results.get('vulnerabilities'):
                    console.print(f"Vulnerabilities found: {len(scan_results['vulnerabilities'])}")
                    
                    # Show summary
                    if scan_results.get('summary'):
                        summary = scan_results['summary']
                        console.print(f"Critical: {summary.get('critical', 0)}")
                        console.print(f"High: {summary.get('high', 0)}")
                        console.print(f"Medium: {summary.get('medium', 0)}")
                        console.print(f"Low: {summary.get('low', 0)}")
                    
                    # Show vulnerability table
                    table = format_vulnerability_table(scan_results['vulnerabilities'][:20], include_exploits=exploits)
                    console.print(table)
                    
                    if len(scan_results['vulnerabilities']) > 20:
                        console.print(f"[dim]... and {len(scan_results['vulnerabilities']) - 20} more vulnerabilities[/dim]")
                else:
                    console.print("[green]✅ No vulnerabilities found[/green]")
        
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.option('--days', default=7, help='Number of days to look back')
@click.option('--limit', default=20, help='Maximum results to return')
@click.option('-x', '--exploits', is_flag=True, help='Include exploit information')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
@click.pass_context
def recent(ctx, days, limit, exploits, output_json):
    """Show recent vulnerabilities"""
    init_client()
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description=f"Fetching recent vulnerabilities ({days} days)...", total=None)
            
            result = client.get_recent_vulnerabilities(days=days, limit=limit, include_exploits=exploits)
        
        if output_json:
            console.print(json.dumps(result, indent=2))
        else:
            vulnerabilities = result.get('recent_vulnerabilities', result.get('vulnerabilities', []))
            if vulnerabilities:
                console.print(f"\n[bold]📅 Recent Vulnerabilities (Last {days} days)[/bold]")
                console.print(f"Total found: {len(vulnerabilities)}")
                
                table = format_vulnerability_table(vulnerabilities, include_exploits=exploits)
                console.print(table)
            else:
                console.print(f"[yellow]No recent vulnerabilities found in the last {days} days[/yellow]")
        
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.pass_context
def stats(ctx):
    """Show database and API statistics"""
    init_client()
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description="Fetching statistics...", total=None)
            
            # Get database stats with improved error handling
            try:
                db_response = client.get_database_stats()
                db_stats = db_response.get('database_stats', {})
                data_source = db_response.get('data_source', 'unknown')
                status = db_response.get('status', 'unknown')
                
                # Check if we have fallback data
                if status == 'partial' or data_source == 'fallback':
                    console.print("[yellow]⚠️  Database temporarily unavailable - showing cached/fallback data[/yellow]")
                    if 'message' in db_response:
                        console.print(f"[dim]{db_response['message']}[/dim]")
                    console.print()
                    
            except Exception as e:
                console.print(f"[red]Error fetching database stats:[/red] {e}")
                return
            
            # Get ecosystem stats
            try:
                eco_stats = client.get_ecosystem_stats()
            except Exception as e:
                console.print(f"[yellow]Warning:[/yellow] Could not fetch ecosystem stats: {e}")
                eco_stats = {}
        
        # Display database statistics
        console.print("[bold]📊 Database Statistics[/bold]")
        
        stats_table = Table(show_header=False, box=None)
        stats_table.add_column("Metric", style="bold")
        stats_table.add_column("Value", style="cyan")
        
        # Handle both old and new API response formats
        vulnerability_data = db_stats.get('vulnerability_counts', db_stats)
        
        # Display main vulnerability counts
        main_stats = {
            'Total CVE Records': vulnerability_data.get('Total CVE Records', 0),
            'GitHub Advisories': vulnerability_data.get('GitHub Advisories', 0),
            'OSV Records': vulnerability_data.get('OSV Records', 0),
            'RedHat Advisories': vulnerability_data.get('RedHat Advisories', 0),
            'Exploit Records': vulnerability_data.get('Exploit Records', 0),
            'Malicious Packages': vulnerability_data.get('Malicious Packages', 0)
        }
        
        for key, value in main_stats.items():
            if value == 'unavailable':
                stats_table.add_row(key, "[dim]unavailable[/dim]")
            else:
                stats_table.add_row(key, f"{value:,}" if isinstance(value, int) else str(value))
        
        console.print(stats_table)
        
        # Display severity distribution if available
        severity_dist = db_stats.get('severity_distribution', {})
        if severity_dist and severity_dist != {'CRITICAL': 'unavailable', 'HIGH': 'unavailable', 'MEDIUM': 'unavailable', 'LOW': 'unavailable'}:
            console.print("\n[bold]🚨 Severity Distribution[/bold]")
            severity_table = Table()
            severity_table.add_column("Severity", style="bold")
            severity_table.add_column("Count", style="magenta", justify="right")
            
            severity_colors = {
                'CRITICAL': 'red',
                'HIGH': 'orange3', 
                'MEDIUM': 'yellow',
                'LOW': 'green'
            }
            
            for severity in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']:
                if severity in severity_dist:
                    value = severity_dist[severity]
                    color = severity_colors.get(severity, 'white')
                    if value == 'unavailable':
                        severity_table.add_row(f"[{color}]{severity}[/{color}]", "[dim]unavailable[/dim]")
                    else:
                        severity_table.add_row(f"[{color}]{severity}[/{color}]", f"{value:,}" if isinstance(value, int) else str(value))
            
            console.print(severity_table)
        
        # Display ecosystem stats
        if eco_stats and eco_stats.get('ecosystem_stats'):
            console.print("\n[bold]🌍 Top Ecosystems[/bold]")
            ecosystem_table = Table()
            ecosystem_table.add_column("Ecosystem", style="cyan")
            ecosystem_table.add_column("Packages", style="magenta", justify="right")
            
            for ecosystem, count in sorted(eco_stats.get('ecosystem_stats', {}).items(), key=lambda x: x[1], reverse=True)[:10]:
                ecosystem_table.add_row(ecosystem, f"{count:,}" if isinstance(count, int) else str(count))
            
            console.print(ecosystem_table)
        elif db_stats.get('top_ecosystems'):
            # Handle new API format for ecosystems
            console.print("\n[bold]🌍 Top Ecosystems[/bold]")
            ecosystem_table = Table()
            ecosystem_table.add_column("Ecosystem", style="cyan")
            ecosystem_table.add_column("Packages", style="magenta", justify="right")
            
            top_ecosystems = db_stats.get('top_ecosystems', {})
            for ecosystem, count in top_ecosystems.items():
                if count == 'unavailable':
                    ecosystem_table.add_row(ecosystem, "[dim]unavailable[/dim]")
                else:
                    ecosystem_table.add_row(ecosystem, f"{count:,}" if isinstance(count, int) else str(count))
            
            console.print(ecosystem_table)
        
        # Show data source info
        if data_source and data_source != 'unknown':
            console.print(f"\n[dim]Data source: {data_source}[/dim]")
            if 'last_updated' in db_response:
                console.print(f"[dim]Last updated: {db_response['last_updated']}[/dim]")
        
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.option('--email', prompt=True, help='Your email address')
@click.password_option(help='Your password')
@click.pass_context
def login(ctx, email, password):
    """Login to the XYZ API"""
    init_client()
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description="Logging in...", total=None)
            result = client.login(email, password)
            client.session.headers['Authorization'] = f"Bearer {result['access_token']}"
            client.session.headers['Authorization'] = f"Bearer {result['access_token']}"
        
        console.print(f"[green]✅ Login successful![/green]")
        console.print(f"Welcome, {result['user_info']['email']}")
        console.print(f"Organization ID: {result['user_info']['organization_id']}")
        console.print("Your session is now active.")
        
    except ValueError as e:
        console.print(f"[red]Login failed:[/red] {e}")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]An unexpected error occurred:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.pass_context
def logout(ctx):
    """Logout and clear your session"""
    init_client()
    try:
        client.logout()
        console.print("[green]✅ You have been successfully logged out.[/green]")
    except Exception as e:
        console.print(f"[red]Error during logout:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.pass_context
def status(ctx):
    """Check login status"""
    init_client()
    
    user_info = client.get_user_info()
    
    if user_info and 'email' in user_info:
        console.print(f"[green]✅ Logged in as: {user_info['email']}[/green]")
        console.print(f"Organization ID: {user_info.get('organization_id', 'N/A')}")
    else:
        console.print("[yellow]You are not logged in.[/yellow]")
        console.print("Use [bold]xyz login[/bold] to authenticate.")

@cli.group()
def audit():
    """Audit local development environments."""
    pass

@audit.command()
@click.option('--json', 'output_json', is_flag=True, help='Output audit results as JSON')
def python(output_json):
    """Audit Python environment for vulnerabilities and dependency tree."""
    init_client()
    console.print("🐍 Starting comprehensive Python audit...")

    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    script_path = os.path.join(project_root, 'audit_python_deps.py')

    if not os.path.exists(script_path):
        console.print(f"[red]Error:[/red] Audit script not found at {script_path}")
        sys.exit(1)
        
    # Ensure the script is executable
    if not os.access(script_path, os.X_OK):
        st = os.stat(script_path)
        os.chmod(script_path, st.st_mode | stat.S_IEXEC)

    try:
        # Using subprocess.run is simpler and less prone to deadlocks
        result = subprocess.run(
            ['python3', script_path],
            capture_output=True,
            text=True,
            encoding='utf-8',
            timeout=300 # 5 minute timeout
        )

        if result.returncode != 0:
            console.print(f"[red]❌ Python audit script failed.[/red]")
            console.print("[bold]Stderr:[/bold]")
            console.print(result.stderr)
            return

        try:
            report_data = json.loads(result.stdout)
        except json.JSONDecodeError:
            console.print("[red]❌ Error: Failed to parse audit script JSON output.[/red]")
            console.print("[bold]Stdout:[/bold]")
            console.print(result.stdout)
            return

        if output_json:
            console.print(json.dumps(report_data, indent=2))
        else:
            console.print("[green]✅ Comprehensive Python audit complete.[/green]")

        # Now, send the data to the backend
        console.print("Uploading comprehensive Python audit report to the platform...")
        summary = {
            "total_vulnerabilities": len(report_data),
            "severity_distribution": {}
        }
        for vuln in report_data:
            severity = vuln.get("severity", "unknown").lower()
            summary["severity_distribution"][severity] = summary["severity_distribution"].get(severity, 0) + 1
        
        client.send_python_audit({
            "scan_results": {"dependency_tree": report_data},
            "summary": summary,
            "machine_name": socket.gethostname(),
            "os_type": platform.system(),
            "computer_name": get_computer_name(),
            "scan_command": "xyz audit python"
        })
        console.print("[green]✅ Successfully uploaded Python audit report.[/green]")

    except subprocess.TimeoutExpired:
        console.print("[red]❌ Error: The Python audit script timed out after 5 minutes.[/red]")
    except FileNotFoundError:
        console.print(f"[red]❌ Error: Could not find the '{script_path}' script.[/red]")
    except Exception as e:
        console.print(f"[red]An unexpected error occurred during Python audit:[/red] {e}")
        sys.exit(1)

@audit.command()
@click.option('--json', 'output_json', is_flag=True, help='Output audit results as JSON')
def go(output_json):
    """Audit Go modules"""
    init_client()
    console.print("Starting Go module audit...")
    
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    script_path = os.path.join(project_root, 'audit_go_modules.py')

    if not os.path.exists(script_path):
        console.print(f"[red]Error:[/red] Audit script not found at {script_path}")
        sys.exit(1)

    try:
        result = subprocess.run(
            ['python3', script_path, '--json', '--stdout', '--quiet'],
            capture_output=True, text=True, timeout=120, check=False
        )
        
        if not result.stdout:
            console.print(f"[red]Go audit script failed to produce output.[/red]")
            if result.stderr:
                console.print("[bold]Error details:[/bold]")
                console.print(result.stderr)
            sys.exit(1)
        
        if result.stderr:
            console.print("[bold]Audit script output:[/bold]")
            console.print(result.stderr)

        try:
            audit_data = json.loads(result.stdout)
        except json.JSONDecodeError:
            console.print("[red]Error: Could not parse JSON output from audit script.[/red]")
            console.print("[bold]Script output:[/bold]")
            console.print(result.stdout)
            sys.exit(1)

        if output_json:
            console.print(json.dumps(audit_data, indent=2))
        else:
            console.print("[green]Go module audit complete.[/green]")
            summary = audit_data.get('summary', {})
            console.print(f"  Total modules: {summary.get('total')}")
            console.print(f"  [red]With advisories: {summary.get('with_advisories')}[/red]")
            console.print(f"  [yellow]Unverified: {summary.get('untrusted')}[/yellow]")


        # Now, send the data to the backend
        console.print("Sending audit results to the platform...")
        client.send_go_audit({
            **audit_data,
            "scan_command": "xyz audit go"
        })
        console.print("[green]Successfully uploaded Go audit results.[/green]")

    except Exception as e:
        console.print(f"[red]An error occurred during Go audit:[/red] {e}")
        sys.exit(1)


@audit.command()
@click.option('--global', 'include_global', is_flag=True, default=True,
              help='Include globally installed npm packages (default: true)')
@click.option('--no-global', 'include_global', flag_value=False,
              help='Skip globally installed npm packages')
@click.option('--json', 'output_json', is_flag=True, help='Output audit results as JSON')
def npm(include_global, output_json):
    """Audit npm packages actually installed on this machine.

    Scans node_modules (not just the lock file) so it catches packages
    that were installed before the proxy was configured, orphaned deps,
    and globally installed tools.
    """
    init_client()
    console.print("📦 Starting npm audit (reading actual node_modules, not lock file)…")

    def run_npm_ls(args):
        try:
            result = subprocess.run(
                ['npm', 'ls'] + args + ['--json'],
                capture_output=True, text=True, timeout=60, check=False
            )
            # npm ls exits non-zero if there are peer-dep issues but still emits valid JSON
            if result.stdout.strip():
                return json.loads(result.stdout)
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass
        except json.JSONDecodeError:
            pass
        return {}

    def flatten_deps(node, packages=None, depth=0):
        """Recursively flatten npm ls --json dependency tree into a list."""
        if packages is None:
            packages = []
        deps = node.get('dependencies', {})
        for name, info in deps.items():
            version = info.get('version', 'unknown')
            packages.append({'name': name, 'version': version, 'depth': depth})
            flatten_deps(info, packages, depth + 1)
        return packages

    # ── Scan local node_modules (current dir) ────────────────────────────
    local_tree = run_npm_ls(['--all'])
    local_pkgs = flatten_deps(local_tree)

    # ── Scan global npm packages ──────────────────────────────────────────
    global_pkgs = []
    if include_global:
        global_tree = run_npm_ls(['-g', '--all'])
        global_pkgs = flatten_deps(global_tree)
        for p in global_pkgs:
            p['scope'] = 'global'

    for p in local_pkgs:
        p.setdefault('scope', 'local')

    all_pkgs = local_pkgs + global_pkgs
    total = len(all_pkgs)

    if total == 0:
        console.print("[yellow]⚠️  No npm packages found. Run inside a project directory or install packages first.[/yellow]")
        return

    # Deduplicate by name@version — same package can appear many times in deep dep trees
    seen_versions: set = set()
    unique_pkgs, skipped_dupes = [], []
    for pkg in all_pkgs:
        key = f"{pkg['name']}@{pkg.get('version', 'unknown')}"
        if key not in seen_versions:
            seen_versions.add(key)
            unique_pkgs.append(pkg)
        else:
            skipped_dupes.append(pkg)

    checkable = [p for p in unique_pkgs if p.get('version') and p['version'] != 'unknown']
    uncheckable = [p for p in unique_pkgs if not p.get('version') or p['version'] == 'unknown']

    console.print(
        f"Found [bold]{total}[/bold] packages "
        f"({len(local_pkgs)} local, {len(global_pkgs)} global). "
        f"[dim]{len(skipped_dupes)} duplicate name@version skipped[/dim]. "
        f"Checking [bold]{len(checkable)}[/bold] unique against XYZ…\n"
    )

    # ── Batch proxy check (1 HTTP call for all packages) ─────────────────
    machine = get_computer_name() or socket.gethostname()
    os_type = platform.system()
    risky, clean, errors = [], [], []
    results_map: dict = {}

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task(f"Checking {len(checkable)} packages via XYZ batch API…", total=None)
        batch_input = [{'package': p['name'], 'version': p['version'], 'ecosystem': 'npm'}
                       for p in checkable]
        batch_results = client.proxy_check_batch(
            batch_input,
            machine_name=machine,
            os_type=os_type,
        )

    for i, result in enumerate(batch_results):
        pkg = checkable[i]
        if isinstance(result, dict) and 'error' in result and 'decision' not in result:
            errors.append({'name': pkg['name'], 'version': pkg['version'], 'error': result['error']})
        else:
            decision = result.get('decision', 'allow')
            pkg['decision'] = decision
            pkg['signals'] = result.get('signals', [])
            pkg['safe_version'] = result.get('safe_version')
            results_map[f"{pkg['name']}@{pkg['version']}"] = decision
            if decision in ('block', 'quarantine'):
                risky.append(pkg)
            else:
                clean.append(pkg)

    # Propagate decisions to duplicate entries
    for pkg in skipped_dupes:
        key = f"{pkg['name']}@{pkg.get('version', 'unknown')}"
        pkg['decision'] = results_map.get(key, 'allow')

    # ── Summary ───────────────────────────────────────────────────────────
    if output_json:
        console.print(json.dumps({'risky': risky, 'clean': clean, 'errors': errors}, indent=2))
    else:
        if risky:
            table = Table(title=f"⚠️  Risky Packages ({len(risky)})", show_header=True)
            table.add_column("Package", style="red bold")
            table.add_column("Version", style="yellow")
            table.add_column("Scope")
            table.add_column("Decision", style="red")
            table.add_column("Safe Version", style="green")
            for p in risky:
                table.add_row(p['name'], p['version'], p.get('scope','local'),
                              p['decision'], p.get('safe_version') or '—')
            console.print(table)
        else:
            console.print(f"[green]✅ All {len(clean)} packages clean.[/green]")

        console.print(f"\n  Total scanned: {total}  |  Risky: {len(risky)}  |  Clean: {len(clean)}  |  Errors: {len(errors)}")

    # ── Upload to platform ────────────────────────────────────────────────
    try:
        console.print("\nUploading npm audit report to the platform…")
        client.send_npm_audit({
            'packages': all_pkgs,
            'summary': {
                'total_packages': total,
                'risky': len(risky),
                'clean': len(clean),
                'errors': len(errors),
            },
            'machine_name': socket.gethostname(),
            'os_type': platform.system(),
            'computer_name': get_computer_name(),
            'scan_command': 'xyz audit npm',
        })
        console.print("[green]✅ Successfully uploaded npm audit report.[/green]")
    except Exception as e:
        console.print(f"[yellow]⚠️  Upload failed (non-fatal): {e}[/yellow]")


# ── Proxy commands ────────────────────────────────────────────────────────────

@cli.group()
def proxy():
    """Manage the XYZ npm safety proxy."""
    pass


@proxy.command()
@click.option('--machine-name', default=None,
              help='Human-readable name for this machine (e.g. "amro-macbook"). '
                   'Defaults to hostname.')
@click.option('--proxy-url', default='https://xyz-npm-proxy-243883377485.us-central1.run.app',
              show_default=True, help='XYZ npm proxy URL.')
@click.option('--pip-proxy-url', default='https://xyz-pip-proxy-243883377485.us-central1.run.app',
              show_default=True, help='XYZ pip proxy URL.')
@click.option('--local', 'use_local', is_flag=True,
              help='Point to local proxy (http://localhost:4873) for testing.')
def setup(machine_name, proxy_url, pip_proxy_url, use_local):
    """Configure npm and pip to route installs through the XYZ safety proxy.

    Your API key is sent as the auth token so the platform can attribute
    proxy activity to your account and organisation — org_id is resolved
    server-side from your key, never from a client-supplied env var.

    \b
    What this writes:
      ~/.npmrc        → registry + _authToken (npm proxy)
      pip global config → index-url with embedded token (pip proxy)

    Run this once per machine. Every subsequent npm/pip install will be
    checked and logged under your org automatically.
    """
    init_client()

    if use_local:
        proxy_url = 'http://localhost:4873'

    # ── Get token from config (login saves access_token JWT) ────────────────
    import json as _json
    token = None
    config_file = os.path.join(os.path.expanduser('~/.xyz'), 'config.json')
    if os.path.exists(config_file):
        with open(config_file) as f:
            cfg = _json.load(f)
        # Prefer sk_xyz_ API key if present, fall back to JWT access_token
        token = cfg.get('api_key') or cfg.get('sk_xyz_key') or cfg.get('access_token')

    if not token:
        token = os.getenv('XYZ_API_KEY')

    if not token:
        console.print("[red]❌ Not logged in. No credentials found.[/red]")
        console.print("Run [bold]xyz login[/bold] first.")
        sys.exit(1)

    # ── Resolve machine name ──────────────────────────────────────────────
    if not machine_name:
        machine_name = get_computer_name() or socket.gethostname()

    # ── Register machine server-side → get a px_xyz_ token ───────────────
    # This stores machine_name in the proxy_tokens table so that every
    # npm install through the proxy is attributed to this machine by name.
    api_url = os.getenv('XYZ_API_URL', 'https://api.cyberxyz.io').rstrip('/')
    proxy_token = None
    try:
        resp = _requests.post(
            f'{api_url}/api/v1/proxy/register-machine',
            json={'machine_name': machine_name, 'description': f'Registered by xyz proxy setup on {socket.gethostname()}'},
            headers={'Authorization': f'Bearer {token}'},
            timeout=30,
        )
        if resp.status_code == 200:
            proxy_token = resp.json()['token']
            console.print(f"[green]✅ Machine registered:[/green] [cyan]{machine_name}[/cyan] → token [dim]{proxy_token[:20]}…[/dim]")
        elif resp.status_code == 401:
            console.print("[red]❌ Your session has expired.[/red]")
            console.print("   Run [bold]xyz login[/bold] and then re-run [bold]xyz proxy setup[/bold].")
            sys.exit(1)
        else:
            console.print(f"[red]❌ Could not register machine ({resp.status_code}): {resp.text[:200]}[/red]")
            console.print("   Aborting setup to avoid writing a dead token to npm/pip config.")
            sys.exit(1)
    except _requests.RequestException as e:
        console.print(f"[red]❌ Registration API unavailable: {e}[/red]")
        console.print("   Aborting setup. Check network / API status and retry.")
        sys.exit(1)

    # ── Write .npmrc ──────────────────────────────────────────────────────
    from urllib.parse import urlparse
    parsed = urlparse(proxy_url)
    proxy_host = parsed.netloc  # e.g. xyz-npm-proxy-243883377485.us-central1.run.app

    npmrc_path = os.path.expanduser('~/.npmrc')
    proxy_registry_line = f'registry={proxy_url}'
    proxy_auth_line = f'//{proxy_host}/:_authToken={proxy_token}'

    existing = ''
    if os.path.exists(npmrc_path):
        with open(npmrc_path) as f:
            existing = f.read()

    # Remove any existing xyz proxy lines to avoid duplicates
    lines = [l for l in existing.splitlines()
             if 'xyz-npm-proxy' not in l and 'localhost:4873' not in l
             and not l.strip().startswith('registry=')]
    lines = [proxy_registry_line, proxy_auth_line] + lines

    with open(npmrc_path, 'w') as f:
        f.write('\n'.join(lines) + '\n')

    console.print(f"\n[green]✅ .npmrc updated:[/green]")
    console.print(f"   registry     → [cyan]{proxy_url}[/cyan]")
    token_type = 'machine proxy token' if proxy_token.startswith('px_xyz_') else 'login token'
    console.print(f"   _authToken   → [dim]{proxy_token[:20]}…[/dim] ({token_type})")
    console.print(f"   machine name → [cyan]{machine_name}[/cyan]")

    # ── Configure pip proxy ──────────────────────────────────────────────
    # Embed the proxy token as Basic auth credentials in the index URL.
    # pip sends these as Authorization: Basic base64(__token__:<token>)
    # which the pip proxy extracts and forwards to the API for attribution.
    pip_parsed = urlparse(pip_proxy_url)
    pip_index_url = f"{pip_parsed.scheme}://__token__:{proxy_token}@{pip_parsed.netloc}/simple/"

    import subprocess as _sp
    try:
        _sp.run(['pip3', 'config', 'set', 'global.index-url', pip_index_url],
                capture_output=True, timeout=10)
        _sp.run(['pip3', 'config', 'set', 'global.timeout', '120'],
                capture_output=True, timeout=10)
        console.print(f"\n[green]✅ pip config updated:[/green]")
        console.print(f"   index-url    → [cyan]{pip_proxy_url}/simple/[/cyan] (token embedded)")
        console.print(f"   timeout      → 120s (handles Cloud Run cold starts)")
    except Exception as e:
        console.print(f"\n[yellow]⚠️  Could not configure pip ({e}).[/yellow]")
        console.print(f"   Run manually: [dim]pip3 config set global.index-url {pip_index_url}[/dim]")

    console.print()
    console.print("Every [bold]npm install[/bold] and [bold]pip install[/bold] will now be checked and logged under your org.")


@proxy.command()
def status():
    """Show current proxy configuration from .npmrc."""
    npmrc_path = os.path.expanduser('~/.npmrc')
    if not os.path.exists(npmrc_path):
        console.print("[yellow]No ~/.npmrc found. Run [bold]xyz proxy setup[/bold] first.[/yellow]")
        return

    with open(npmrc_path) as f:
        lines = f.read().splitlines()

    registry = next((l for l in lines if l.startswith('registry=')), None)
    token_line = next((l for l in lines if '_authToken=' in l), None)
    machine = os.getenv('XYZ_MACHINE_NAME') or socket.gethostname()

    console.print("[bold]XYZ Proxy Status[/bold]")
    console.print(f"  Registry    : {registry or '[red]not set[/red]'}")
    console.print(f"  Auth token  : {'[green]set[/green]' if token_line else '[red]not set[/red]'}")
    console.print(f"  Machine name: {machine}")

    if registry and 'xyz-npm-proxy' in (registry or ''):
        console.print("\n[green]✅ Proxy is configured.[/green]")
    else:
        console.print("\n[yellow]⚠️  Proxy not configured. Run [bold]xyz proxy setup[/bold].[/yellow]")


@proxy.command()
def remove():
    """Remove XYZ proxy configuration from .npmrc, restoring default npm registry."""
    npmrc_path = os.path.expanduser('~/.npmrc')
    if not os.path.exists(npmrc_path):
        console.print("[yellow]No ~/.npmrc found — nothing to remove.[/yellow]")
        return

    with open(npmrc_path) as f:
        lines = f.read().splitlines()

    cleaned = [l for l in lines
               if 'xyz-npm-proxy' not in l
               and 'localhost:4873' not in l
               and not l.strip().startswith('registry=')]

    with open(npmrc_path, 'w') as f:
        f.write('\n'.join(cleaned) + '\n')

    console.print("[green]✅ XYZ proxy removed from .npmrc. npm will use the default registry.[/green]")


# Log Viewer Commands
@cli.group()
@click.pass_context
def logs(ctx):
    """Log viewer and management commands."""
    init_client()

@logs.command()
@click.option('--file-type', type=click.Choice(['csv', 'evtx', 'txt', 'log', 'json']), help='Filter by file type')
@click.option('--status', default='active', type=click.Choice(['active', 'archived', 'deleted']), help='Filter by status')
@click.option('--limit', default=50, help='Maximum number of files to show')
@click.option('--output-json', is_flag=True, help='Output in JSON format')
@click.pass_context
def list(ctx, file_type, status, limit, output_json):
    """List available log files."""
    try:
        result = client.list_log_files(file_type=file_type, status=status, limit=limit)
        
        if output_json:
            console.print(json.dumps(result, indent=2))
            return
        
        if not result.get('log_files'):
            console.print("[yellow]No log files found.[/yellow]")
            return
        
        table = Table(title="Log Files")
        table.add_column("ID", style="cyan")
        table.add_column("Filename", style="magenta")
        table.add_column("Type", style="blue")
        table.add_column("Size", justify="right")
        table.add_column("Entries", justify="right")
        table.add_column("Created", style="green")
        table.add_column("Status", style="yellow")
        
        for log_file in result['log_files']:
            size_mb = f"{log_file.get('file_size', 0) / 1024 / 1024:.2f} MB"
            created = log_file.get('created_at', '')[:19] if log_file.get('created_at') else 'Unknown'
            
            table.add_row(
                str(log_file.get('id', '')),
                log_file.get('filename', ''),
                log_file.get('file_type', '').upper(),
                size_mb,
                str(log_file.get('total_entries', 0)),
                created,
                log_file.get('status', '').upper()
            )
        
        console.print(table)
        
    except Exception as e:
        console.print(f"[red]Error listing log files:[/red] {e}")
        sys.exit(1)

@logs.command()
@click.argument('log_id', type=int)
@click.option('--level', type=click.Choice(['DEBUG', 'INFO', 'WARN', 'WARNING', 'ERROR', 'CRITICAL', 'FATAL']), help='Filter by log level')
@click.option('--search', help='Search for specific text in log entries')
@click.option('--start-time', help='Start time filter (ISO format)')
@click.option('--end-time', help='End time filter (ISO format)')
@click.option('--limit', default=100, help='Maximum number of entries to show')
@click.option('--tail', is_flag=True, help='Show latest entries first')
@click.option('--output-json', is_flag=True, help='Output in JSON format')
@click.pass_context
def view(ctx, log_id, level, search, start_time, end_time, limit, tail, output_json):
    """View log entries from a specific log file."""
    try:
        # Get log file info first
        log_file = client.get_log_file(log_id)
        
        # Get log entries
        entries_result = client.get_log_entries(
            log_id=log_id,
            level=level,
            search=search,
            start_time=start_time,
            end_time=end_time,
            limit=limit
        )
        
        if output_json:
            console.print(json.dumps({
                'log_file': log_file,
                'entries': entries_result
            }, indent=2))
            return
        
        # Display log file info
        console.print(Panel(
            f"[bold]File:[/bold] {log_file.get('filename')}\n"
            f"[bold]Type:[/bold] {log_file.get('file_type', '').upper()}\n"
            f"[bold]Total Entries:[/bold] {log_file.get('total_entries', 0):,}\n"
            f"[bold]Size:[/bold] {log_file.get('file_size', 0) / 1024 / 1024:.2f} MB",
            title="Log File Information"
        ))
        
        entries = entries_result.get('entries', [])
        if not entries:
            console.print("[yellow]No log entries found matching the criteria.[/yellow]")
            return
        
        # Handle CSV files with table view
        if log_file.get('file_type') == 'csv':
            console.print(f"\n[bold]Showing {len(entries)} entries:[/bold]")
            table = Table(show_header=True, header_style="bold magenta")
            
            # Add columns dynamically based on CSV structure
            if entries and entries[0].get('parsed_data'):
                parsed = entries[0]['parsed_data']
                if isinstance(parsed, dict) and 'columns' in parsed:
                    for col in parsed['columns']:
                        table.add_column(col, overflow="fold")
                    
                    for entry in entries:
                        if entry.get('parsed_data', {}).get('values'):
                            table.add_row(*[str(v) for v in entry['parsed_data']['values']])
                else:
                    # Fallback to raw display
                    table.add_column("Line", style="cyan")
                    table.add_column("Content", overflow="fold")
                    for entry in entries:
                        table.add_row(str(entry.get('entry_number', '')), entry.get('raw_line', ''))
            else:
                table.add_column("Line", style="cyan")
                table.add_column("Content", overflow="fold")
                for entry in entries:
                    table.add_row(str(entry.get('entry_number', '')), entry.get('raw_line', ''))
            
            console.print(table)
        else:
            # Regular log display
            console.print(f"\n[bold]Showing {len(entries)} entries:[/bold]")
            for entry in entries:
                timestamp = entry.get('timestamp_parsed', '')[:19] if entry.get('timestamp_parsed') else ''
                level_str = entry.get('log_level', '')
                message = entry.get('message') or entry.get('raw_line', '')
                
                # Color code by level
                level_color = {
                    'DEBUG': 'dim',
                    'INFO': 'blue',
                    'WARN': 'yellow',
                    'WARNING': 'yellow',
                    'ERROR': 'red',
                    'CRITICAL': 'bold red',
                    'FATAL': 'bold red'
                }.get(level_str, 'white')
                
                console.print(f"[dim]{timestamp}[/dim] [{level_color}]{level_str:8}[/{level_color}] {message}")
        
    except Exception as e:
        console.print(f"[red]Error viewing log file:[/red] {e}")
        sys.exit(1)

@logs.command()
@click.argument('file_path', type=click.Path(exists=True))
@click.option('--filename', help='Custom filename for the uploaded file')
@click.option('--file-type', type=click.Choice(['csv', 'evtx', 'txt', 'log', 'json']), help='Specify file type')
@click.option('--output-json', is_flag=True, help='Output in JSON format')
@click.pass_context
def upload(ctx, file_path, filename, file_type, output_json):
    """Upload a log file for analysis."""
    try:
        result = client.upload_log_file(file_path=file_path, filename=filename, file_type=file_type)
        
        if output_json:
            console.print(json.dumps(result, indent=2))
            return
        
        console.print(f"[green]✓[/green] Successfully uploaded log file: {result.get('filename')}")
        console.print(f"[blue]Log ID:[/blue] {result.get('id')}")
        console.print(f"[blue]File Type:[/blue] {result.get('file_type', '').upper()}")
        console.print(f"[blue]Size:[/blue] {result.get('file_size', 0) / 1024 / 1024:.2f} MB")
        
    except Exception as e:
        console.print(f"[red]Error uploading log file:[/red] {e}")
        sys.exit(1)

@logs.command()
@click.argument('log_id', type=int)
@click.option('--format', 'download_format', default='original', type=click.Choice(['original', 'json', 'csv']), help='Download format')
@click.option('--output-file', help='Output file path')
@click.pass_context
def download(ctx, log_id, download_format, output_file):
    """Download a log file."""
    try:
        result = client.download_log_file(log_id=log_id, format=download_format)
        
        if not output_file:
            log_file = client.get_log_file(log_id)
            filename = log_file.get('filename', f'log_{log_id}')
            if download_format != 'original':
                filename = f"{filename}.{download_format}"
            output_file = filename
        
        # In a real implementation, this would handle file download
        console.print(f"[green]✓[/green] Log file download initiated")
        console.print(f"[blue]Format:[/blue] {download_format}")
        console.print(f"[blue]Output:[/blue] {output_file}")
        console.print(f"[dim]Note: Download URL: {result.get('download_url', 'N/A')}[/dim]")
        
    except Exception as e:
        console.print(f"[red]Error downloading log file:[/red] {e}")
        sys.exit(1)

@logs.command()
@click.argument('log_id', type=int)
@click.option('--confirm', is_flag=True, help='Skip confirmation prompt')
@click.pass_context
def clear(ctx, log_id, confirm):
    """Clear all entries from a log file."""
    try:
        if not confirm:
            log_file = client.get_log_file(log_id)
            filename = log_file.get('filename', f'Log {log_id}')
            if not click.confirm(f"Are you sure you want to clear all entries from '{filename}'?"):
                console.print("[yellow]Operation cancelled.[/yellow]")
                return
        
        result = client.clear_log_entries(log_id)
        console.print(f"[green]✓[/green] Successfully cleared log entries")
        console.print(f"[blue]Entries cleared:[/blue] {result.get('entries_cleared', 0)}")
        
    except Exception as e:
        console.print(f"[red]Error clearing log entries:[/red] {e}")
        sys.exit(1)

@logs.command()
@click.argument('log_id', type=int)
@click.option('--confirm', is_flag=True, help='Skip confirmation prompt')
@click.pass_context
def delete(ctx, log_id, confirm):
    """Delete a log file and all its entries."""
    try:
        if not confirm:
            log_file = client.get_log_file(log_id)
            filename = log_file.get('filename', f'Log {log_id}')
            if not click.confirm(f"Are you sure you want to permanently delete '{filename}'?"):
                console.print("[yellow]Operation cancelled.[/yellow]")
                return
        
        result = client.delete_log_file(log_id)
        console.print(f"[green]✓[/green] Successfully deleted log file")
        
    except Exception as e:
        console.print(f"[red]Error deleting log file:[/red] {e}")
        sys.exit(1)

@logs.command()
@click.argument('query')
@click.option('--file-type', type=click.Choice(['csv', 'evtx', 'txt', 'log', 'json']), help='Filter by file type')
@click.option('--level', type=click.Choice(['DEBUG', 'INFO', 'WARN', 'WARNING', 'ERROR', 'CRITICAL', 'FATAL']), help='Filter by log level')
@click.option('--limit', default=100, help='Maximum number of results')
@click.option('--output-json', is_flag=True, help='Output in JSON format')
@click.pass_context
def search(ctx, query, file_type, level, limit, output_json):
    """Search across all log files."""
    try:
        result = client.search_logs(query=query, file_type=file_type, level=level, limit=limit)
        
        if output_json:
            console.print(json.dumps(result, indent=2))
            return
        
        results = result.get('results', [])
        if not results:
            console.print(f"[yellow]No results found for query: '{query}'[/yellow]")
            return
        
        console.print(f"[bold]Found {len(results)} results for '{query}':[/bold]\n")
        
        for item in results:
            log_file = item.get('log_file', {})
            entry = item.get('entry', {})
            
            console.print(Panel(
                f"[bold]File:[/bold] {log_file.get('filename', 'Unknown')}\n"
                f"[bold]Line:[/bold] {entry.get('entry_number', 'N/A')}\n"
                f"[bold]Level:[/bold] {entry.get('log_level', 'N/A')}\n"
                f"[bold]Content:[/bold] {entry.get('message') or entry.get('raw_line', '')}",
                title=f"Result {results.index(item) + 1}"
            ))
        
    except Exception as e:
        console.print(f"[red]Error searching logs:[/red] {e}")
        sys.exit(1)

@logs.command()
@click.argument('log_id', type=int)
@click.option('--output-json', is_flag=True, help='Output in JSON format')
@click.pass_context
def stats(ctx, log_id, output_json):
    """Show statistics for a log file."""
    try:
        result = client.get_log_stats(log_id)
        
        if output_json:
            console.print(json.dumps(result, indent=2))
            return
        
        log_file = result.get('log_file', {})
        stats = result.get('stats', {})
        
        console.print(Panel(
            f"[bold]Filename:[/bold] {log_file.get('filename', 'Unknown')}\n"
            f"[bold]Total Entries:[/bold] {stats.get('total_entries', 0):,}\n"
            f"[bold]File Size:[/bold] {log_file.get('file_size', 0) / 1024 / 1024:.2f} MB\n"
            f"[bold]Log Levels:[/bold]\n" +
            "\n".join([f"  {level}: {count:,}" for level, count in stats.get('level_counts', {}).items()]) +
            f"\n[bold]Date Range:[/bold] {stats.get('date_range', {}).get('start', 'N/A')} to {stats.get('date_range', {}).get('end', 'N/A')}",
            title="Log File Statistics"
        ))
        
    except Exception as e:
        console.print(f"[red]Error getting log statistics:[/red] {e}")
        sys.exit(1)

# Scan History Commands
@cli.group()
def scans():
    """Scan history and management commands."""
    pass

@scans.command()
@click.option('--limit', default=20, help='Maximum number of scans to show')
@click.option('--user', help='Filter by user email')
@click.option('--type', 'scan_type', help='Filter by scan type (python, npm, system, etc.)')
@click.option('--output-json', is_flag=True, help='Output in JSON format')
@click.pass_context
def list(ctx, limit, user, scan_type, output_json):
    """List scan history for your organization."""
    init_client()
    
    try:
        scans = client.get_scan_history(limit=limit)
        
        # Apply filters
        if user:
            scans = [s for s in scans if user.lower() in s.get('user_email', '').lower()]
        if scan_type:
            scans = [s for s in scans if scan_type.lower() in s.get('scan_type', '').lower()]
        
        if output_json:
            console.print(json.dumps(scans, indent=2))
            return
        
        if not scans:
            console.print("[yellow]No scans found.[/yellow]")
            return
        
        # Create formatted table
        table = Table(title="Scan History")
        table.add_column("ID", style="cyan")
        table.add_column("User", style="magenta")
        table.add_column("Type", style="blue")
        table.add_column("Machine", style="green")
        table.add_column("Vulnerabilities", justify="right")
        table.add_column("Date", style="dim")
        
        for scan in scans:
            # Format vulnerability count
            summary = scan.get('summary', {})
            total_vulns = summary.get('total_vulnerabilities', 0)
            
            # Format severity distribution
            severity_dist = summary.get('severity_distribution', {})
            vuln_display = f"{total_vulns}"
            if severity_dist:
                critical = severity_dist.get('critical', 0)
                high = severity_dist.get('high', 0)
                if critical > 0 or high > 0:
                    vuln_display += f" (C:{critical}, H:{high})"
            
            # Format date
            created_at = scan.get('created_at', '')
            if created_at:
                try:
                    from datetime import datetime
                    dt = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                    date_str = dt.strftime('%Y-%m-%d %H:%M')
                except:
                    date_str = created_at[:16]
            else:
                date_str = 'Unknown'
            
            table.add_row(
                str(scan.get('id', '')),
                scan.get('user_email', 'Unknown'),
                scan.get('scan_type', 'Unknown').title(),
                scan.get('computer_name', scan.get('machine_name', 'Unknown')),
                vuln_display,
                date_str
            )
        
        console.print(table)
        console.print(f"\n[dim]Showing {len(scans)} scans[/dim]")
        
    except Exception as e:
        console.print(f"[red]Error fetching scan history:[/red] {e}")
        sys.exit(1)

@scans.command()
@click.argument('scan_id', type=int)
@click.option('--output-json', is_flag=True, help='Output in JSON format')
@click.pass_context
def show(ctx, scan_id, output_json):
    """Show detailed information about a specific scan."""
    init_client()
    
    try:
        scan = client.get_scan_details(scan_id)
        
        if output_json:
            console.print(json.dumps(scan, indent=2))
            return
        
        # Display scan details
        console.print(f"\n[bold]Scan Details - ID: {scan.get('id')}[/bold]")
        console.print(f"[blue]User:[/blue] {scan.get('user_email')}")
        console.print(f"[blue]Type:[/blue] {scan.get('scan_type', 'Unknown').title()}")
        console.print(f"[blue]Machine:[/blue] {scan.get('computer_name', scan.get('machine_name', 'Unknown'))}")
        console.print(f"[blue]OS:[/blue] {scan.get('os_type', 'Unknown')}")
        
        # Format date
        created_at = scan.get('created_at', '')
        if created_at:
            try:
                from datetime import datetime
                dt = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                date_str = dt.strftime('%Y-%m-%d %H:%M:%S')
            except:
                date_str = created_at
        else:
            date_str = 'Unknown'
        console.print(f"[blue]Date:[/blue] {date_str}")
        
        # Display scan command if available
        if scan.get('scan_command'):
            console.print(f"[blue]Command:[/blue] {scan.get('scan_command')}")
        
        # Display summary
        summary = scan.get('summary', {})
        scan_results = scan.get('scan_results', {})
        
        # Count packages from scan results if not in summary
        total_packages = summary.get('total_packages', 0)
        if total_packages == 0:
            # Try different data structures
            if scan_results.get('packages'):
                total_packages = len(scan_results.get('packages', []))
            elif scan_results.get('dependency_tree'):
                # Count packages recursively from dependency tree
                def count_packages_recursive(packages):
                    count = 0
                    for pkg in packages:
                        count += 1  # Count this package
                        # Count dependencies recursively
                        deps = pkg.get('dependencies', [])
                        if deps:
                            count += count_packages_recursive(deps)
                    return count
                
                dependency_tree = scan_results.get('dependency_tree', [])
                total_packages = count_packages_recursive(dependency_tree)
        
        if summary:
            console.print(f"\n[bold]Summary:[/bold]")
            console.print(f"[green]Total Vulnerabilities:[/green] {summary.get('total_vulnerabilities', 0)}")
            console.print(f"[green]Packages Scanned:[/green] {total_packages}")
            
            # Severity distribution
            severity_dist = summary.get('severity_distribution', {})
            if severity_dist:
                console.print(f"\n[bold]Severity Distribution:[/bold]")
                for severity, count in severity_dist.items():
                    if count > 0:
                        severity_color = {
                            'critical': 'bold red',
                            'high': 'red',
                            'medium': 'yellow',
                            'low': 'blue',
                            'unknown': 'dim'
                        }.get(severity.lower(), 'white')
                        console.print(f"  [{severity_color}]{severity.title()}:[/{severity_color}] {count}")
        
        # Display scan results summary
        scan_results = scan.get('scan_results', {})
        if scan_results:
            packages = scan_results.get('packages', [])
            if packages:
                console.print(f"\n[bold]Packages with Vulnerabilities:[/bold]")
                vuln_packages = [pkg for pkg in packages if pkg.get('vulnerabilities')]
                console.print(f"[yellow]{len(vuln_packages)} out of {len(packages)} packages have vulnerabilities[/yellow]")
                
                # Show top vulnerable packages
                if vuln_packages:
                    console.print(f"\n[bold]Top Vulnerable Packages:[/bold]")
                    sorted_packages = sorted(vuln_packages, key=lambda x: len(x.get('vulnerabilities', [])), reverse=True)[:5]
                    for pkg in sorted_packages:
                        pkg_name = pkg.get('name', 'Unknown')
                        vuln_count = len(pkg.get('vulnerabilities', []))
                        console.print(f"  • [cyan]{pkg_name}[/cyan]: {vuln_count} vulnerabilities")
        
    except Exception as e:
        console.print(f"[red]Error fetching scan details:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.option('--limit', default=10, help='Maximum number of scans to show')
@click.option('--output-json', is_flag=True, help='Output in JSON format')
@click.pass_context
def history(ctx, limit, output_json):
    """Show recent scan history (shortcut for 'scans list')."""
    init_client()
    
    try:
        scans = client.get_scan_history(limit=limit)
        
        if output_json:
            console.print(json.dumps(scans, indent=2))
            return
        
        if not scans:
            console.print("[yellow]No scan history found.[/yellow]")
            console.print("Run [bold]xyz scan --help[/bold] to see available scan options.")
            return
        
        console.print(f"[bold]Recent Scan History ({len(scans)} scans)[/bold]\n")
        
        for scan in scans:
            # Format date
            created_at = scan.get('created_at', '')
            if created_at:
                try:
                    from datetime import datetime
                    dt = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                    date_str = dt.strftime('%Y-%m-%d %H:%M')
                except:
                    date_str = created_at[:16]
            else:
                date_str = 'Unknown'
            
            # Format vulnerability summary
            summary = scan.get('summary', {})
            total_vulns = summary.get('total_vulnerabilities', 0)
            severity_dist = summary.get('severity_distribution', {})
            
            vuln_summary = f"{total_vulns} vulnerabilities"
            if severity_dist:
                critical = severity_dist.get('critical', 0)
                high = severity_dist.get('high', 0)
                if critical > 0:
                    vuln_summary += f" ([bold red]{critical} critical[/bold red]"
                    if high > 0:
                        vuln_summary += f", [red]{high} high[/red])"
                    else:
                        vuln_summary += ")"
                elif high > 0:
                    vuln_summary += f" ([red]{high} high[/red])"
            
            console.print(f"[cyan]#{scan.get('id')}[/cyan] {scan.get('user_email')} - {scan.get('scan_type', 'Unknown').title()} Scan")
            console.print(f"  [dim]{date_str}[/dim] • [green]{scan.get('computer_name', 'Unknown')}[/green] • {vuln_summary}")
            console.print()
        
        console.print(f"[dim]Use [bold]scans show <id>[/bold] for detailed information about a specific scan.[/dim]")
        
    except Exception as e:
        console.print(f"[red]Error fetching scan history:[/red] {e}")
        sys.exit(1)

@cli.command()
@click.argument("package")
@click.argument("version")
@click.option("-e", "--ecosystem", default="npm", show_default=True,
              help="Package ecosystem (npm, pypi, maven, nuget, etc.)")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
@click.pass_context
def check(ctx, package, version, ecosystem, output_json):
    """Run an XYZ proxy safety check on PACKAGE@VERSION.

    \b
    Examples:
      xyz check axios 1.14.1
      xyz check lodash 4.17.21 --ecosystem npm
      xyz check forcechatter 1.0.0 --json
    """
    init_client()
    try:
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
                      console=console) as progress:
            progress.add_task(description=f"Checking {package}@{version}…", total=None)
            result = client.proxy_check(package, version, ecosystem)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)

    if output_json:
        console.print(json.dumps(result, indent=2))
        return

    decision = result.get("decision", "unknown").upper()
    confidence = result.get("confidence", 0) or 0
    safe_ver = result.get("safe_version") or ""
    signals = result.get("signals", []) or []

    DECISION_COLOR = {
        "BLOCK": "bold red",
        "QUARANTINE": "bold yellow",
        "ALERT": "bold blue",
        "ALLOW": "bold green",
    }
    DECISION_ICON = {
        "BLOCK": "🚫",
        "QUARANTINE": "⚠️",
        "ALERT": "ℹ️",
        "ALLOW": "✅",
    }
    color = DECISION_COLOR.get(decision, "white")
    icon  = DECISION_ICON.get(decision, "❓")

    console.print()
    console.print(Panel(
        f"[{color}]{icon}  {decision}[/{color}]"
        + (f"  [dim](confidence: {confidence:.0%})[/dim]" if confidence else ""),
        title=f"[cyan]{package}[/cyan][dim]@[/dim][magenta]{version}[/magenta]  ·  {ecosystem}",
        expand=False,
    ))

    if safe_ver:
        console.print(f"  [green]✓ Safe version:[/green] {safe_ver}")

    if signals:
        console.print(f"\n  [bold]Signals ({len(signals)}):[/bold]")
        for s in signals:
            sig_decision = s.get("decision", "").upper()
            sig_color = DECISION_COLOR.get(sig_decision, "dim")
            console.print(
                f"    [{sig_color}]{sig_decision:12}[/{sig_color}]"
                f"  [{s.get('signal_type','?')}]  {s.get('detail', '')[:120]}"
            )
    else:
        console.print("  [dim]No signals fired — clean.[/dim]")

    console.print()
    if decision == "BLOCK":
        raise SystemExit(1)
    elif decision == "QUARANTINE":
        raise SystemExit(2)


# ─── xyz depalert ──────────────────────────────────────────────────────────────

@cli.group()
def depalert():
    """CI/CD gate: scan a manifest or lockfile and exit non-zero on threats.

    \b
    Exit codes:
      0  All clean
      1  MALWARE / block detected
      2  QUARANTINE detected
      3  ALERT-only (suspicious but not confirmed malicious)
    """


@depalert.command("scan")
@click.option("--package-lock", "package_lock", type=click.Path(exists=True),
              help="Path to package-lock.json")
@click.option("--requirements", "requirements", type=click.Path(exists=True),
              help="Path to requirements.txt")
@click.option("--packages", "-p", multiple=True,
              help="Inline package specs, e.g. --packages axios@1.14.1")
@click.option("--ecosystem", "-e", default="npm", show_default=True,
              help="Ecosystem for --packages input")
@click.option("--fail-on", default="block", show_default=True,
              type=click.Choice(["block", "quarantine", "alert"], case_sensitive=False),
              help="Minimum decision level that causes non-zero exit")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
@click.pass_context
def depalert_scan(ctx, package_lock, requirements, packages, ecosystem,
                  fail_on, output_json):
    """Scan dependencies and gate on threats.

    \b
    Examples:
      xyz depalert scan --package-lock package-lock.json
      xyz depalert scan --requirements requirements.txt --fail-on quarantine
      xyz depalert scan -p axios@1.14.1 -p lodash@4.17.21
    """
    import re

    init_client()

    pkg_list: list[dict] = []

    if package_lock:
        try:
            with open(package_lock) as f:
                lock = json.load(f)
            deps = lock.get("packages") or lock.get("dependencies") or {}
            for name, meta in deps.items():
                clean_name = name.lstrip("node_modules/")
                if not clean_name:
                    continue
                ver = meta.get("version", "0.0.0") if isinstance(meta, dict) else str(meta)
                pkg_list.append({"package": clean_name, "version": ver, "ecosystem": "npm"})
        except Exception as e:
            console.print(f"[red]Failed to parse package-lock.json:[/red] {e}")
            raise SystemExit(1)

    if requirements:
        try:
            eco = "pypi"
            with open(requirements) as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    m = re.match(r"^([A-Za-z0-9_.\-]+)[=><!\s]+=+\s*([\d.]+)", line)
                    if m:
                        pkg_list.append({"package": m.group(1), "version": m.group(2), "ecosystem": eco})
        except Exception as e:
            console.print(f"[red]Failed to parse requirements.txt:[/red] {e}")
            raise SystemExit(1)

    for spec in packages:
        if "@" in spec:
            parts = spec.rsplit("@", 1)
            pkg_list.append({"package": parts[0], "version": parts[1], "ecosystem": ecosystem})
        else:
            pkg_list.append({"package": spec, "version": "latest", "ecosystem": ecosystem})

    if not pkg_list:
        console.print("[yellow]No packages to scan. Provide --package-lock, --requirements, or --packages.[/yellow]")
        raise SystemExit(0)

    console.print(f"[bold]XYZ DepAlert[/bold] — scanning [cyan]{len(pkg_list)}[/cyan] packages…\n")

    results = client.proxy_check_batch(pkg_list)

    if output_json:
        console.print(json.dumps(results, indent=2))
    else:
        _print_depalert_table(results)

    # Determine exit code
    decisions = [r.get("decision", "allow").lower() for r in results]
    if "block" in decisions:
        worst = "block"
    elif "quarantine" in decisions:
        worst = "quarantine"
    elif "alert" in decisions:
        worst = "alert"
    else:
        worst = "allow"

    EXIT_CODE = {"block": 1, "quarantine": 2, "alert": 3, "allow": 0}
    THRESHOLD = {"block": 1, "quarantine": 2, "alert": 3}

    threshold = THRESHOLD.get(fail_on.lower(), 1)
    worst_code = EXIT_CODE.get(worst, 0)

    if worst_code >= threshold:
        count = sum(1 for d in decisions if d in ("block", "quarantine", "alert"))
        console.print(f"\n[bold red]✖ Gate FAILED:[/bold red] {count} threat(s) detected (worst: {worst.upper()})\n")
        raise SystemExit(worst_code)
    else:
        console.print(f"\n[bold green]✓ Gate PASSED[/bold green] — no threats at or above '{fail_on}' level.\n")


def _format_score_cell(scores: dict) -> str:
    """Format CVSS/EPSS/XYZ scores into a compact Rich-colored cell."""
    if not scores:
        return "[dim]—[/dim]"
    parts = []
    cvss = scores.get("cvss")
    if cvss is not None:
        c = float(cvss)
        if c >= 9.0:
            parts.append(f"[bold red]CVSS {c:.1f}[/bold red]")
        elif c >= 7.0:
            parts.append(f"[red]CVSS {c:.1f}[/red]")
        elif c >= 4.0:
            parts.append(f"[yellow]CVSS {c:.1f}[/yellow]")
        else:
            parts.append(f"[dim]CVSS {c:.1f}[/dim]")
    xyz = scores.get("xyz_score")
    if xyz is not None:
        x = float(xyz)
        if x >= 7.0:
            parts.append(f"[bold orange3]XYZ {x:.1f}[/bold orange3]")
        elif x >= 4.0:
            parts.append(f"[orange3]XYZ {x:.1f}[/orange3]")
        else:
            parts.append(f"[dim]XYZ {x:.1f}[/dim]")
    epss = scores.get("epss")
    if epss is not None:
        e = float(epss) * 100
        if e >= 10:
            parts.append(f"[bold dodger_blue2]EPSS {e:.1f}%[/bold dodger_blue2]")
        elif e >= 1:
            parts.append(f"[dodger_blue2]EPSS {e:.1f}%[/dodger_blue2]")
        else:
            parts.append(f"[steel_blue1]EPSS {e:.2f}%[/steel_blue1]")
    return "\n".join(parts) if parts else "[dim]—[/dim]"


def _print_depalert_table(results: list):
    ICON = {"block": "🚫", "quarantine": "⚠️", "alert": "ℹ️", "allow": "✅", "error": "❌"}
    COLOR = {"block": "red", "quarantine": "yellow", "alert": "blue", "allow": "green", "error": "dim"}

    threats = [r for r in results if r.get("decision", "allow") not in ("allow", "error")]
    clean   = [r for r in results if r.get("decision", "allow") == "allow"]
    errors  = [r for r in results if r.get("decision") == "error"]

    if threats:
        table = Table(title=f"⚠️  {len(threats)} Threat(s) Detected", show_lines=True)
        table.add_column("Package@Version", style="cyan")
        table.add_column("Decision", justify="center")
        table.add_column("Scores", justify="left")
        table.add_column("Signals", justify="right")
        table.add_column("Safe Version", style="green")
        for r in threats:
            inp = r.get("_input", r)
            pkg_ver = f"{inp.get('package','?')}@{inp.get('version','?')}"
            d = r.get("decision", "?")
            icon = ICON.get(d, "?")
            color = COLOR.get(d, "white")
            table.add_row(
                pkg_ver,
                f"[{color}]{icon} {d.upper()}[/{color}]",
                _format_score_cell(r.get("scores")),
                str(len(r.get("signals", []))),
                r.get("safe_version") or "—",
            )
        console.print(table)

    console.print(
        f"[green]✅ {len(clean)} clean[/green]  "
        f"[red]🚫 {sum(1 for r in results if r.get('decision')=='block')} blocked[/red]  "
        f"[yellow]⚠️  {sum(1 for r in results if r.get('decision')=='quarantine')} quarantined[/yellow]  "
        f"[blue]ℹ️  {sum(1 for r in results if r.get('decision')=='alert')} alerted[/blue]"
        + (f"  [dim]❌ {len(errors)} errors[/dim]" if errors else "")
    )


def main():
    """Main entry point for setuptools console_scripts"""
    cli()
 
if __name__ == '__main__':
    main()
