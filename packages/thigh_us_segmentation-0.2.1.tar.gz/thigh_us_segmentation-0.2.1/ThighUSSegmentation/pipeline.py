from pathlib import Path

from .io_conversion import convert_to_mha
from .model_download import ensure_model_exists
from .preprocessing import preprocess_active_region
from .nnunet_inference import run_nnunet_inference
from .distances import extract_distances_dataframe


def run_full_pipeline(
    input_image_path: str,
    output_root: str,
    case_id: str = "case001",
    device: str | None = None,
    models_root: str | None = None,
    rectus_label: int = 3,
    epi_label: int = 1,
    femur_label: int = 2,
    keep_temp_files: bool = False,
    create_seg_nrrd: bool = True,
):
    """
    Ejecuta el pipeline completo de segmentación y cálculo de distancias.

    Genera:
    - {case_id}_image_converted.mha
    - {case_id}_preprocessed.mha
    - {case_id}_labelmap.mha
    - {case_id}_segmentation.seg.nrrd
    - markups/*.mrk.json
    - inference_log.txt
    """

    output_root = Path(output_root)
    case_dir = output_root / case_id
    case_dir.mkdir(parents=True, exist_ok=True)

    model_folder = ensure_model_exists(models_root=models_root)

    converted_image = convert_to_mha(
        input_path=input_image_path,
        output_dir=str(case_dir),
        output_filename=f"{case_id}_image_converted.mha",
    )

    preprocessed_image = case_dir / f"{case_id}_preprocessed.mha"

    preprocess_active_region(
        input_image_path=str(converted_image),
        output_image_path=str(preprocessed_image),
    )

    segment_info = {
        epi_label: {
            "name": "Epidermis",
            "color": (1.0, 0.0, 0.0),
        },
        femur_label: {
            "name": "Femur",
            "color": (1.0, 1.0, 0.0),
        },
        rectus_label: {
            "name": "Rectus Femoris",
            "color": (0.0, 1.0, 0.0),
        },
    }

    segmentation_path = run_nnunet_inference(
        input_image=str(preprocessed_image),
        output_root=str(output_root),
        model_folder=model_folder,
        case_id=case_id,
        device=device,
        keep_temp_files=keep_temp_files,
        create_seg_nrrd=create_seg_nrrd,
        segment_info=segment_info,
    )

    segmentation_path = Path(segmentation_path)

    if create_seg_nrrd:
        seg_nrrd_path = case_dir / f"{case_id}_segmentation.seg.nrrd"
    else:
        seg_nrrd_path = None

    markups_dir = case_dir / "markups"

    df_distances, mrk_paths = extract_distances_dataframe(
        image_path=str(preprocessed_image),
        mask_path=str(segmentation_path),
        output_mrk_json_path=str(markups_dir),
        case_id=case_id,
        epi_label=epi_label,
        femur_label=femur_label,
        rf_label=rectus_label,
    )

    return {
        "case_id": case_id,
        "case_dir": case_dir,
        "model_folder": Path(model_folder),
        "converted_image": Path(converted_image),
        "preprocessed_image": preprocessed_image,
        "segmentation_path": segmentation_path,
        "labelmap_path": segmentation_path,
        "seg_nrrd_path": seg_nrrd_path,
        "markups_dir": markups_dir,
        "mrk_paths": mrk_paths,
        "df_distances": df_distances,
        "df_results": df_distances,
    }