"""Free cloud provider runtime — uses Pollinations (no API key required)
as a fallback when no local models are available."""

import json

import httpx

from ..schemas import ChatMessage
from .base import RuntimeAdapter


class CloudRuntime(RuntimeAdapter):
    """Uses free OpenAI-compatible APIs (Pollinations, OpenRouter free tier)."""

    def __init__(self) -> None:
        self._model_name: str | None = None
        self._base_url = "https://text.pollinations.ai/openai/v1"

    def load(self, model_path: str, threads: int | None = None) -> None:
        self._model_name = model_path

    def chat(
        self,
        messages: list[ChatMessage],
        temperature: float,
        max_tokens: int,
    ) -> str:
        if not self._model_name:
            raise RuntimeError("No cloud model loaded")
        payload = {
            "model": self._model_name,
            "messages": [m.model_dump() for m in messages],
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,
        }
        with httpx.Client(timeout=120) as client:
            resp = client.post(
                f"{self._base_url}/chat/completions",
                json=payload,
                headers={"Content-Type": "application/json"},
            )
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"]

    def stream_chat(
        self,
        messages: list[ChatMessage],
        temperature: float,
        max_tokens: int,
    ):
        if not self._model_name:
            raise RuntimeError("No cloud model loaded")
        payload = {
            "model": self._model_name,
            "messages": [m.model_dump() for m in messages],
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True,
        }
        with httpx.Client(timeout=120) as client:
            with client.stream(
                "POST",
                f"{self._base_url}/chat/completions",
                json=payload,
                headers={"Content-Type": "application/json"},
            ) as resp:
                resp.raise_for_status()
                for line in resp.iter_lines():
                    if not line.startswith("data: "):
                        continue
                    data_str = line[6:]
                    if data_str.strip() == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue
                    delta = chunk.get("choices", [{}])[0].get("delta", {})
                    content = delta.get("content")
                    if content:
                        yield content
