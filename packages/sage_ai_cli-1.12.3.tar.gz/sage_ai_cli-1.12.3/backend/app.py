import json
import logging
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles

from .auto_updater import AutoUpdater
from .config import runtime_defaults, settings
from .conversations import ConversationStore
from .hardware import detect_hardware_summary
from .model_catalog import (
    filter_by_ram,
    get_recommended_models,
    list_catalog_models,
)
from sage.models.catalog import (
    OLLAMA_CATALOG,
    search_ollama_catalog,
    get_recommended_ollama_models,
    get_ollama_models_by_category,
)
from .model_registry import ModelRegistry
from .runtime_manager import RuntimeManager
from .schemas import (
    AddSourceReq,
    ChatMessage,
    ChatReq,
    CreateConversationReq,
    DownloadModelReq,
    LoadModelReq,
)

settings.ensure_dirs()
logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))
logger = logging.getLogger("ai-platform")

app = FastAPI(title="Local AI Platform", version="3.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

registry = ModelRegistry()
runtime_manager = RuntimeManager()
conversation_store = ConversationStore()
updater = AutoUpdater(registry)


@app.get("/health")
def health():
    return {
        "ok": True,
        "version": "3.0.0",
        "loaded_model_id": runtime_manager.loaded_model_id,
        "loaded_runtime": runtime_manager.loaded_runtime,
    }


@app.get("/hardware")
def hardware():
    return detect_hardware_summary()


@app.get("/models")
def list_models():
    return {"ok": True, "models": [m.model_dump() for m in registry.list_models()]}


@app.get("/models/names")
def model_names():
    names = {m.model_id for m in registry.list_models()}
    for source in updater.list_sources():
        names.add(source.model_id)
    return {"ok": True, "names": sorted(names)}


@app.get("/models/{model_id}")
def get_model(model_id: str):
    try:
        record = registry.get_model(model_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Model not found")
    return {"ok": True, "model": record.model_dump()}


@app.post("/models/download")
def download_model(req: DownloadModelReq):
    try:
        record = registry.download_and_register(req)
    except ValueError as exc:
        detail = str(exc)
        if "GitHub" in detail or "allowed" in detail:
            detail = f"source not allowed: {detail}"
        raise HTTPException(status_code=400, detail=detail)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    return {"ok": True, "model": record.model_dump()}


@app.post("/models/load")
def load_model(req: LoadModelReq):
    model_id = req.model_id

    # Check if it's an Ollama model (prefixed with "ollama:" or matches catalog)
    if model_id.startswith("ollama:"):
        ollama_name = model_id.removeprefix("ollama:")
        try:
            runtime_manager.load("ollama", model_id, ollama_name, threads=None)
        except Exception as exc:
            raise HTTPException(status_code=500, detail=str(exc))
        return {
            "ok": True,
            "loaded_model_id": runtime_manager.loaded_model_id,
            "loaded_runtime": "ollama",
            "threads": 0,
        }

    # Check if it's a cloud/free model
    if model_id.startswith("cloud:"):
        cloud_name = model_id.removeprefix("cloud:")
        try:
            runtime_manager.load("cloud", model_id, cloud_name, threads=None)
        except Exception as exc:
            raise HTTPException(status_code=500, detail=str(exc))
        return {
            "ok": True,
            "loaded_model_id": runtime_manager.loaded_model_id,
            "loaded_runtime": "cloud",
            "threads": 0,
        }

    # Standard GGUF/local model
    try:
        record = registry.get_model(model_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    try:
        active = record.active()
        threads = (
            req.threads
            or runtime_defaults.default_threads
            or detect_hardware_summary().get("cpu_threads", 1)
        )
        runtime_manager.load(
            record.runtime, model_id, active.file_path, threads=threads
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    return {
        "ok": True,
        "loaded_model_id": runtime_manager.loaded_model_id,
        "loaded_runtime": runtime_manager.loaded_runtime,
        "threads": threads,
    }


@app.post("/chat")
def chat(req: ChatReq):
    # Auto-load model if not loaded or different model requested
    if runtime_manager.runtime is None or runtime_manager.loaded_model_id != req.model_id:
        model_id = req.model_id
        try:
            if model_id.startswith("ollama:"):
                runtime_manager.load("ollama", model_id, model_id.removeprefix("ollama:"), threads=None)
            elif model_id.startswith("cloud:"):
                runtime_manager.load("cloud", model_id, model_id.removeprefix("cloud:"), threads=None)
            else:
                # Try loading as registered GGUF model
                try:
                    record = registry.get_model(model_id)
                    active = record.active()
                    threads = detect_hardware_summary().get("cpu_threads", 1)
                    runtime_manager.load(record.runtime, model_id, active.file_path, threads=threads)
                except KeyError:
                    # Fall back to cloud provider
                    runtime_manager.load("cloud", model_id, model_id, threads=None)
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to load model: {exc}")

    conv_id = req.conversation_id
    if conv_id:
        for msg in req.messages:
            conversation_store.append_message(conv_id, msg.role, msg.content)

    messages = [
        (
            ChatMessage(**m.model_dump())
            if isinstance(m, ChatMessage)
            else ChatMessage(**m)
        )
        for m in req.messages
    ]

    def stream():
        chunks = []
        # Send initial step indicator
        yield f"data: {json.dumps({'step': 'thinking', 'message': 'Processing your message...'})}\n\n"
        yield f"data: {json.dumps({'step': 'generating', 'message': 'Generating response...'})}\n\n"
        for token in runtime_manager.runtime.stream_chat(
            messages,
            temperature=req.temperature,
            max_tokens=req.max_tokens,
        ):
            chunks.append(token)
            yield f"data: {json.dumps({'token': token})}\n\n"
        final = "".join(chunks).strip()
        if conv_id:
            conversation_store.append_message(conv_id, "assistant", final)
        yield f"data: {json.dumps({'step': 'complete', 'message': 'Done'})}\n\n"
        yield f"data: {json.dumps({'done': True, 'conversation_id': conv_id})}\n\n"

    if req.stream:
        return StreamingResponse(stream(), media_type="text/event-stream")
    text = runtime_manager.runtime.chat(
        messages,
        temperature=req.temperature,
        max_tokens=req.max_tokens,
    )
    if conv_id:
        conversation_store.append_message(conv_id, "assistant", text)
    return {"ok": True, "output": text, "conversation_id": conv_id}


@app.post("/conversations")
def create_conversation(req: CreateConversationReq):
    conversation = conversation_store.create(req.title)
    return {"ok": True, "conversation": conversation}


@app.get("/conversations")
def list_conversations():
    return {"ok": True, "conversations": conversation_store.list_all()}


@app.get("/conversations/{conversation_id}")
def get_conversation(conversation_id: str):
    try:
        conversation = conversation_store.get(conversation_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return {"ok": True, "conversation": conversation}


@app.delete("/conversations/{conversation_id}")
def delete_conversation(conversation_id: str):
    conversation_store.delete(conversation_id)
    return {"ok": True}


@app.get("/sources")
def list_sources():
    return {"ok": True, "sources": [s.__dict__ for s in updater.list_sources()]}


@app.post("/sources/add")
def add_source(req: AddSourceReq):
    try:
        source = updater.add_source(
            repo_url=req.repo_url,
            model_id=req.model_id,
            runtime=req.runtime,
            asset_pattern=req.asset_pattern,
            license=req.license,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True, "source": source.__dict__}


@app.delete("/sources/{model_id}")
def remove_source(model_id: str):
    updater.remove_source(model_id)
    return {"ok": True}


@app.get("/catalog")
def catalog():
    """List GGUF models from the Sage catalog (with GCS download URLs)."""
    from sage.models.catalog import MODEL_CATALOG
    gguf_models = [
        {
            "model_id": m.name,
            "name": m.display_name,
            "description": m.description,
            "params": m.params,
            "size_gb": m.size_gb,
            "family": m.family,
            "filename": m.filename,
            "url": m.url,
            "default": m.default,
        }
        for m in MODEL_CATALOG if m.backend == "gguf"
    ]
    return {"ok": True, "models": gguf_models}


@app.get("/catalog/recommended")
def catalog_recommended():
    return {"ok": True, "models": get_recommended_models()}


@app.get("/catalog/fits-ram")
def catalog_fits_ram(max_gb: float):
    return {"ok": True, "models": filter_by_ram(max_gb)}


@app.get("/ollama/catalog")
def ollama_catalog(category: str | None = None, search: str | None = None):
    """List all Ollama models available to pull."""
    if search:
        results = search_ollama_catalog(search)
    elif category:
        results = get_ollama_models_by_category(category)
    else:
        results = OLLAMA_CATALOG
    return {
        "ok": True,
        "models": [
            {
                "name": m.name,
                "display_name": m.display_name,
                "sizes": m.params,
                "tags": list(m.tags),
                "description": m.description,
                "pulls": "",
                "category": m.category,
            }
            for m in results
        ],
    }


@app.get("/ollama/status")
def ollama_status():
    """Check if Ollama is running and list pulled models."""
    import httpx
    try:
        with httpx.Client(timeout=3) as client:
            resp = client.get("http://localhost:11434/api/tags")
            resp.raise_for_status()
            data = resp.json()
            models = [
                {"name": m["name"], "size": m.get("size", 0), "modified": m.get("modified_at", "")}
                for m in data.get("models", [])
            ]
            return {"ok": True, "running": True, "models": models}
    except Exception:
        return {"ok": True, "running": False, "models": []}


@app.get("/free-models")
def free_models():
    """List free cloud models that work without any setup."""
    return {
        "ok": True,
        "models": [
            {"model_id": "cloud:openai", "name": "GPT-4o Mini (Free)", "provider": "pollinations"},
            {"model_id": "cloud:openai-large", "name": "GPT-4o (Free)", "provider": "pollinations"},
            {"model_id": "cloud:qwen2.5-coder-3b", "name": "Qwen 2.5 Coder 3B (Free)", "provider": "pollinations"},
            {"model_id": "cloud:mistral", "name": "Mistral Nemo (Free)", "provider": "pollinations"},
            {"model_id": "cloud:deepseek-r1", "name": "DeepSeek R1 (Free)", "provider": "pollinations"},
            {"model_id": "cloud:llama", "name": "Llama 3.3 (Free)", "provider": "pollinations"},
            {"model_id": "cloud:openai-fast", "name": "GPT-4o Mini Fast (Free)", "provider": "pollinations"},
        ],
    }


@app.get("/ollama/recommended")
def ollama_recommended():
    """Return recommended Ollama models for Sage."""
    results = get_recommended_ollama_models()
    return {
        "ok": True,
        "models": [
            {
                "name": m.name,
                "display_name": m.display_name,
                "sizes": m.params,
                "tags": list(m.tags),
                "description": m.description,
                "category": m.category,
            }
            for m in results
        ],
    }


_frontend_dist = Path(__file__).resolve().parent.parent / "frontend" / "dist"
if _frontend_dist.is_dir():
    app.mount("/", StaticFiles(directory=str(_frontend_dist), html=True), name="frontend")


def main():
    uvicorn.run(app, host="0.0.0.0", port=8080)


if __name__ == "__main__":
    main()
