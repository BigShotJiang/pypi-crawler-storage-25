# domainai

<!-- [![CI](https://github.com/domainai/domainai/actions/workflows/ci.yml/badge.svg)](https://github.com/domainai/domainai/actions/workflows/ci.yml) -->
[![PyPI](https://img.shields.io/pypi/v/domainai)](https://pypi.org/project/domainai)
[![Python 3.9+](https://img.shields.io/badge/python-3.9%2B-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

AI-powered domain name generator and availability checker. Describe what you want in plain English, and domainai generates creative domain names, checks their availability, and shows results in a beautiful terminal UI.

## Features

- **AI-Powered** — Uses LLMs to brainstorm creative, brandable domain names
- **Provider-Agnostic** — Supports OpenAI, Anthropic, Google Gemini, and Groq (BYOK)
- **Dual Availability Check** — Domainr API + WHOIS for accurate results
- **Smart Search** — `--batch` and `--until` modes for flexible searching
- **Watch Mode** — Continuous background scanning with configurable intervals
- **History** — SQLite database prevents rechecking the same domains
- **Beautiful Output** — Rich terminal UI with colored results
- **CSV Export** — Append-mode CSV for tracking all results

## Quick Start

```bash
# Install (Groq is included by default — free tier!)
pip install domainai

# First-time setup (interactive)
domainai setup

# Search for domains
domainai search "url shortener, short, energetic" --tlds com,io
```

## Requirements

- Python 3.9 or higher
- An API key from at least one supported AI provider

## Installation

```bash
# Default install — includes Groq (free tier, recommended)
pip install domainai

# Add another provider on top of the default
pip install "domainai[openai]"      # OpenAI / ChatGPT
pip install "domainai[anthropic]"   # Anthropic / Claude
pip install "domainai[gemini]"      # Google Gemini
pip install "domainai[all]"         # All providers at once
```

> **Note (macOS/zsh):** Only the optional extras (`[openai]`, `[all]`, etc.) need quoting on zsh. The default `pip install domainai` works without any brackets.

## Setup

Run the interactive setup wizard:

```bash
domainai setup
```

This will:
1. Ask which AI provider you want to use
2. Show where to get an API key
3. Test the connection
4. Save config to `~/.domainai/config.json`

### Manual Configuration

You can also configure via `.env` file:

```env
AI_PROVIDER=groq
AI_API_KEY=gsk_your_key_here
AI_MODEL=llama-3.3-70b-versatile    # optional
```

Or via CLI flags:

```bash
domainai search "my idea" --provider groq --api-key gsk_xxx
```

**Priority order:** CLI flags > `.env` file > `~/.domainai/config.json`

## Usage

### Search (Batch Mode)

Generate names, check them, done:

```bash
# Generate 20 names (default), check with .com TLD
domainai search "url shortener, short, energetic"

# Specify TLDs and batch size
domainai search "url shortener, short" --tlds com,io,link --batch 30
```

### Search (Until Mode)

Keep searching until N available domains are found:

```bash
# Search until 5 available domains are found
domainai search "url shortener, short" --tlds com,io --until 5

# Combine: generate up to 50 names, but stop at 3 available
domainai search "url shortener" --tlds com,io --batch 50 --until 3
```

### Watch Mode

Continuous background scanning:

```bash
# Check every 30 seconds, stop at 5 available
domainai watch "url shortener, short" --tlds com,io --interval 30 --until 5
```

Press `Ctrl+C` to stop gracefully.

### History & Results

```bash
# View check history from SQLite
domainai history

# View saved CSV results
domainai results
```

## Output

### Terminal

Real example — finding domains for an AI personal trainer app:

```
$ domainai search "AI personal trainer app, energetic, motivating, modern" \
    --tlds com,io,ai --until 5

🔍  Searching domains...
   Prompt: "AI personal trainer app, energetic, motivating, modern"
   TLDs: com, io, ai | Batch: 15 | Until: 5 available

  ❌ fitzone.com         → taken
  ❌ fitzone.io          → taken
  ❌ fitzone.ai          → taken
  ❌ motivo.com          → taken
  ❌ paxter.com          → taken
  ❌ elevat.com          → taken
  ❌ fitmax.com          → taken
  ❌ zinga.com           → taken
  ❌ coreio.com          → taken
  ✅ coreio.io           → available   → namecheap.com/...?domain=coreio.io
  ✅ coreio.ai           → available   → namecheap.com/...?domain=coreio.ai
  ❌ vitali.com          → taken
  ❌ pulso.com           → taken
  ✅ fitbita.com         → available   → namecheap.com/...?domain=fitbita.com
  ✅ fitbita.io          → available   → namecheap.com/...?domain=fitbita.io
  ✅ fitbita.ai          → available   → namecheap.com/...?domain=fitbita.ai

Done! Checked 33 domains, 5 available.
```

### CSV (results.csv)

```csv
domain,tld,available,checked_at,buy_url
coreio.io,io,true,2026-05-16 14:32,https://www.namecheap.com/domains/registration/results/?domain=coreio.io
fitzone.com,com,false,2026-05-16 14:32,
```

Results are appended — old data is never overwritten.

## Supported Providers

| Provider | Default Model | Free Tier | Setup Link |
|----------|--------------|-----------|------------|
| **Groq** (recommended) | `llama-3.3-70b-versatile` | ✅ Yes | [console.groq.com](https://console.groq.com) |
| OpenAI | `gpt-4o` | ❌ Paid | [platform.openai.com](https://platform.openai.com/api-keys) |
| Google Gemini | `gemini-2.5-flash` | ✅ Yes | [aistudio.google.com](https://aistudio.google.com/apikey) |
| Anthropic | `claude-sonnet-4-5` | ❌ Paid | [console.anthropic.com](https://console.anthropic.com) |

See all recommended models per provider:

```bash
domainai models
```

## Docker

### 1. Create your `.env` file

```bash
cp .env.example .env
# Edit .env and set your API key:
#   AI_PROVIDER=groq
#   AI_API_KEY=gsk_xxxxx
```

### 2a. Docker Compose (recommended)

```bash
# Build and run the default search command
docker compose up --build

# Run any command interactively
docker compose run --rm domainai search "url shortener, short" --tlds com,io
docker compose run --rm domainai setup
docker compose run --rm domainai history
docker compose run --rm domainai watch "crypto names" --interval 60
```

### 2b. Docker (manual)

```bash
# Build the image
docker build -t domainai .

# Run a search
docker run --rm --env-file .env domainai search "AI startup names" --tlds com,io

# Persist history and results with volumes
docker run --rm --env-file .env \
  -v domainai-data:/root/.domainai \
  -v "$(pwd)/results.csv:/app/results.csv" \
  domainai search "short brandable names" --tlds com,ai --batch 30
```

### Volumes

| Volume | Purpose |
|---|---|
| `domainai-data:/root/.domainai` | SQLite history persists across container restarts |
| `./results.csv:/app/results.csv` | CSV results written directly to your host machine |

## Project Structure

```
domainai/
├── src/domainai/          # Main package
│   ├── providers/         # AI provider adapters (Groq, OpenAI, Anthropic, Gemini)
│   ├── checker.py         # Domain availability checking (WHOIS + Domainr)
│   ├── generator.py       # Provider factory and name generation
│   ├── scheduler.py       # Batch/until/watch orchestration
│   ├── storage.py         # SQLite history database
│   ├── exporter.py        # CSV export
│   └── cli.py             # CLI entry point
├── tests/                 # Test suite
├── .github/workflows/     # CI/CD
├── Dockerfile             # Container support
└── pyproject.toml         # Package configuration
```

## Development

```bash
git clone https://github.com/domainai/domainai.git
cd domainai
pip install -e ".[all,dev]"
python -m pytest tests/ -v
```

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## License

MIT — see [LICENSE](LICENSE) for details.
