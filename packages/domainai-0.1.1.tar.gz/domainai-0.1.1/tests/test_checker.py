"""Tests for the domain availability checker."""

from datetime import datetime, timezone

from domainai.checker import DomainResult, BUY_URL_TEMPLATE


class TestDomainResult:
    def test_available_domain_gets_buy_url(self):
        result = DomainResult(
            domain="tronq.io",
            name="tronq",
            tld="io",
            available=True,
        )
        assert result.buy_url == BUY_URL_TEMPLATE.format(domain="tronq.io")

    def test_unavailable_domain_no_buy_url(self):
        result = DomainResult(
            domain="google.com",
            name="google",
            tld="com",
            available=False,
        )
        assert result.buy_url == ""

    def test_checked_at_is_utc(self):
        result = DomainResult(
            domain="test.com",
            name="test",
            tld="com",
            available=True,
        )
        assert result.checked_at.tzinfo is not None

    def test_custom_buy_url_preserved(self):
        result = DomainResult(
            domain="test.io",
            name="test",
            tld="io",
            available=True,
            buy_url="https://custom.registrar.com/test.io",
        )
        assert result.buy_url == "https://custom.registrar.com/test.io"
