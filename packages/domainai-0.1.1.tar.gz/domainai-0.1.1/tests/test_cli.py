"""Tests for domainai.cli — argument parsing and config resolution."""

from __future__ import annotations

import json

import pytest

from domainai.cli import build_parser, _load_config, _resolve_config


class TestBuildParser:
    """Verify parser structure and defaults."""

    def test_no_command_returns_none(self):
        parser = build_parser()
        args = parser.parse_args([])
        assert args.command is None

    def test_search_defaults(self):
        parser = build_parser()
        args = parser.parse_args(["search", "AI startup names"])
        assert args.command == "search"
        assert args.prompt == "AI startup names"
        assert args.tlds == "com"
        assert args.batch == 20
        assert args.until is None
        assert args.delay == 1.0
        assert args.output == "results.csv"
        assert args.provider is None

    def test_search_custom_flags(self):
        parser = build_parser()
        args = parser.parse_args([
            "search", "pet names",
            "--tlds", "io,ai",
            "--batch", "10",
            "--until", "3",
            "--delay", "0.5",
            "--output", "out.csv",
            "--provider", "openai",
            "--api-key", "sk-test",
            "--model", "gpt-4o",
        ])
        assert args.tlds == "io,ai"
        assert args.batch == 10
        assert args.until == 3
        assert args.delay == 0.5
        assert args.output == "out.csv"
        assert args.provider == "openai"
        assert args.api_key == "sk-test"
        assert args.model == "gpt-4o"

    def test_watch_defaults(self):
        parser = build_parser()
        args = parser.parse_args(["watch", "crypto domains"])
        assert args.command == "watch"
        assert args.interval == 30

    def test_history_defaults(self):
        parser = build_parser()
        args = parser.parse_args(["history"])
        assert args.command == "history"
        assert args.limit == 50

    def test_results_defaults(self):
        parser = build_parser()
        args = parser.parse_args(["results"])
        assert args.command == "results"
        assert args.output == "results.csv"


class TestResolveConfig:
    """Verify config merge priority: CLI > .env > config.json."""

    def test_cli_overrides_all(self, tmp_path, monkeypatch):
        # Write a config file
        config_dir = tmp_path / ".domainai"
        config_dir.mkdir()
        config_file = config_dir / "config.json"
        config_file.write_text(json.dumps({
            "provider": "groq",
            "api_key": "from-config",
            "model": "config-model",
        }))

        # Patch config path
        monkeypatch.setattr("domainai.cli.CONFIG_FILE", config_file)
        monkeypatch.delenv("AI_PROVIDER", raising=False)
        monkeypatch.delenv("AI_API_KEY", raising=False)
        monkeypatch.delenv("AI_MODEL", raising=False)

        parser = build_parser()
        args = parser.parse_args([
            "search", "test",
            "--provider", "openai",
            "--api-key", "from-cli",
            "--model", "cli-model",
        ])

        cfg = _resolve_config(args)
        assert cfg["provider"] == "openai"
        assert cfg["api_key"] == "from-cli"
        assert cfg["model"] == "cli-model"

    def test_env_overrides_config(self, tmp_path, monkeypatch):
        config_dir = tmp_path / ".domainai"
        config_dir.mkdir()
        config_file = config_dir / "config.json"
        config_file.write_text(json.dumps({
            "provider": "groq",
            "api_key": "from-config",
        }))

        monkeypatch.setattr("domainai.cli.CONFIG_FILE", config_file)
        monkeypatch.setenv("AI_PROVIDER", "anthropic")
        monkeypatch.setenv("AI_API_KEY", "from-env")

        parser = build_parser()
        args = parser.parse_args(["search", "test"])

        cfg = _resolve_config(args)
        assert cfg["provider"] == "anthropic"
        assert cfg["api_key"] == "from-env"

    def test_config_fallback(self, tmp_path, monkeypatch):
        config_dir = tmp_path / ".domainai"
        config_dir.mkdir()
        config_file = config_dir / "config.json"
        config_file.write_text(json.dumps({
            "provider": "gemini",
            "api_key": "from-config",
        }))

        monkeypatch.setattr("domainai.cli.CONFIG_FILE", config_file)
        monkeypatch.setattr("domainai.cli._load_env", lambda: {})
        monkeypatch.delenv("AI_PROVIDER", raising=False)
        monkeypatch.delenv("AI_API_KEY", raising=False)
        monkeypatch.delenv("AI_MODEL", raising=False)

        parser = build_parser()
        args = parser.parse_args(["search", "domains"])

        cfg = _resolve_config(args)
        assert cfg["provider"] == "gemini"
        assert cfg["api_key"] == "from-config"
