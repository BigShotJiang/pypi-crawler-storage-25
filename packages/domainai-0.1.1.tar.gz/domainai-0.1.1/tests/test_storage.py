"""Tests for domainai.storage — SQLite history storage."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from domainai.checker import DomainResult
from domainai.storage import Storage


@pytest.fixture()
def storage(tmp_path):
    """Return a Storage instance backed by a temporary database."""
    db = tmp_path / "test.db"
    s = Storage(db_path=db)
    yield s
    s.close()


def _make_result(domain: str = "tronq.io", available: bool = True) -> DomainResult:
    parts = domain.split(".", 1)
    return DomainResult(
        domain=domain,
        name=parts[0],
        tld=parts[1],
        available=available,
        checked_at=datetime(2025, 1, 1, tzinfo=timezone.utc),
    )


class TestSaveAndRetrieve:
    def test_save_single_result(self, storage):
        result = _make_result()
        storage.save_result(result, prompt="test AI startup")

        rows = storage.get_history(limit=10)
        assert len(rows) == 1
        assert rows[0]["domain"] == "tronq.io"
        assert rows[0]["available"] == 1
        assert rows[0]["prompt"] == "test AI startup"

    def test_save_multiple_results(self, storage):
        results = [
            _make_result("tronq.io", available=True),
            _make_result("acmex.com", available=False),
        ]
        storage.save_results(results, prompt="batch")

        assert storage.count() == 2
        assert storage.count_available() == 1

    def test_upsert_updates_existing(self, storage):
        r1 = _make_result("tronq.io", available=False)
        storage.save_result(r1)

        r2 = _make_result("tronq.io", available=True)
        storage.save_result(r2)

        assert storage.count() == 1
        rows = storage.get_history()
        assert rows[0]["available"] == 1  # updated


class TestDedup:
    def test_is_checked_true(self, storage):
        storage.save_result(_make_result("abc.com"))
        assert storage.is_checked("abc.com") is True

    def test_is_checked_false(self, storage):
        assert storage.is_checked("xyz.net") is False

    def test_get_unchecked_filters(self, storage):
        storage.save_result(_make_result("abc.com"))

        unchecked = storage.get_unchecked(["abc", "newname"], ["com"])
        assert ("abc", "com") not in unchecked
        assert ("newname", "com") in unchecked


class TestQueries:
    def test_get_available_only(self, storage):
        storage.save_results([
            _make_result("yes.io", available=True),
            _make_result("no.com", available=False),
        ])

        available = storage.get_available()
        assert len(available) == 1
        assert available[0]["domain"] == "yes.io"

    def test_count_zero_on_empty(self, storage):
        assert storage.count() == 0
        assert storage.count_available() == 0

    def test_history_limit(self, storage):
        for i in range(10):
            storage.save_result(_make_result(f"d{i}.com"))

        rows = storage.get_history(limit=5)
        assert len(rows) == 5


class TestContextManager:
    def test_works_as_context_manager(self, tmp_path):
        db = tmp_path / "ctx.db"
        with Storage(db_path=db) as s:
            s.save_result(_make_result())
            assert s.count() == 1
