"""Tests for the AI name generator and provider factory."""

import json
import pytest

from domainai.providers.base import (
    BaseProvider,
    ProviderError,
    APIKeyError,
    RateLimitError,
    ModelNotFoundError,
)
from domainai.generator import (
    get_provider,
    list_providers,
    DEFAULT_MODELS,
    _PROVIDER_ALIASES,
)


# ---------------------------------------------------------------------------
# Dummy provider for testing
# ---------------------------------------------------------------------------

class DummyProvider(BaseProvider):
    PROVIDER_NAME = "dummy"

    def generate_names(self, prompt, count=20):
        return [
            {"name": f"test{i}", "reason": "test reason", "score": 7}
            for i in range(count)
        ]

    def validate_api_key(self):
        return True

    def get_default_model(self):
        return "dummy-v1"


# ---------------------------------------------------------------------------
# BaseProvider tests
# ---------------------------------------------------------------------------

class TestBaseProvider:
    def test_cannot_instantiate_directly(self):
        with pytest.raises(TypeError):
            BaseProvider(api_key="test")

    def test_empty_api_key_raises_error(self):
        with pytest.raises(APIKeyError):
            DummyProvider(api_key="")

    def test_default_model_used_when_none(self):
        p = DummyProvider(api_key="sk-test")
        assert p.model == "dummy-v1"

    def test_custom_model_used(self):
        p = DummyProvider(api_key="sk-test", model="custom-model")
        assert p.model == "custom-model"

    def test_repr(self):
        p = DummyProvider(api_key="sk-test")
        r = repr(p)
        assert "dummy" in r
        assert "dummy-v1" in r

    def test_system_prompt_contains_count(self):
        p = DummyProvider(api_key="sk-test")
        prompt = p._build_system_prompt(15)
        assert "15" in prompt
        assert "JSON" in prompt

    def test_user_prompt_contains_description(self):
        p = DummyProvider(api_key="sk-test")
        prompt = p._build_user_prompt("url shortener, short", 10)
        assert "url shortener" in prompt

    def test_generate_names_returns_list(self):
        p = DummyProvider(api_key="sk-test")
        results = p.generate_names("test", count=5)
        assert len(results) == 5
        assert all("name" in r and "reason" in r and "score" in r for r in results)


# ---------------------------------------------------------------------------
# Exception tests
# ---------------------------------------------------------------------------

class TestExceptions:
    def test_provider_error_message(self):
        err = ProviderError("something broke", provider="test")
        assert "test" in str(err)
        assert "something broke" in str(err)

    def test_api_key_error_hierarchy(self):
        assert issubclass(APIKeyError, ProviderError)

    def test_rate_limit_error_retry_after(self):
        err = RateLimitError(provider="openai", retry_after=30)
        assert err.retry_after == 30
        assert "30" in str(err)

    def test_model_not_found_error(self):
        err = ModelNotFoundError(model="gpt-99", provider="openai")
        assert "gpt-99" in str(err)


# ---------------------------------------------------------------------------
# Generator factory tests
# ---------------------------------------------------------------------------

class TestGeneratorFactory:
    def test_list_providers(self):
        providers = list_providers()
        assert set(providers) == {"groq", "openai", "anthropic", "gemini"}

    def test_default_models_complete(self):
        for provider in list_providers():
            assert provider in DEFAULT_MODELS

    def test_unknown_provider_raises_error(self):
        with pytest.raises(ProviderError, match="Unknown provider"):
            get_provider("nonexistent", api_key="test")

    def test_aliases_defined(self):
        assert _PROVIDER_ALIASES["chatgpt"] == "openai"
        assert _PROVIDER_ALIASES["claude"] == "anthropic"
        assert _PROVIDER_ALIASES["google"] == "gemini"
