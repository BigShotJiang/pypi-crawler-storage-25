"""Tests for the CSV exporter."""

import csv
import tempfile
from pathlib import Path
from datetime import datetime, timezone

from domainai.checker import DomainResult
from domainai.exporter import export_results, read_results


def _make_result(domain: str, available: bool) -> DomainResult:
    name, tld = domain.rsplit(".", 1)
    return DomainResult(
        domain=domain,
        name=name,
        tld=tld,
        available=available,
        checked_at=datetime(2024, 1, 15, 14, 32, tzinfo=timezone.utc),
    )


class TestExporter:
    def test_creates_csv_with_header(self, tmp_path):
        csv_path = tmp_path / "test_results.csv"
        results = [_make_result("tronq.io", True)]

        export_results(results, path=csv_path)

        lines = csv_path.read_text().strip().split("\n")
        assert len(lines) == 2  # header + 1 row
        assert "domain" in lines[0]
        assert "tronq.io" in lines[1]

    def test_appends_without_overwriting(self, tmp_path):
        csv_path = tmp_path / "test_results.csv"

        export_results([_make_result("a.com", True)], path=csv_path)
        export_results([_make_result("b.com", False)], path=csv_path)

        lines = csv_path.read_text().strip().split("\n")
        assert len(lines) == 3  # 1 header + 2 data rows

    def test_available_domain_has_buy_url(self, tmp_path):
        csv_path = tmp_path / "test_results.csv"
        export_results([_make_result("test.io", True)], path=csv_path)

        rows = read_results(path=csv_path)
        assert len(rows) == 1
        assert rows[0]["buy_url"] != ""
        assert "namecheap" in rows[0]["buy_url"]

    def test_unavailable_domain_empty_buy_url(self, tmp_path):
        csv_path = tmp_path / "test_results.csv"
        export_results([_make_result("taken.com", False)], path=csv_path)

        rows = read_results(path=csv_path)
        assert rows[0]["buy_url"] == ""

    def test_read_nonexistent_file(self, tmp_path):
        csv_path = tmp_path / "does_not_exist.csv"
        rows = read_results(path=csv_path)
        assert rows == []
