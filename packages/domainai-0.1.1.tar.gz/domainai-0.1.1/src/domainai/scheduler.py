"""Background scheduler for continuous domain watching (watch mode).

Uses APScheduler to periodically generate new batches of domain names,
check their availability, and stream results to the terminal + CSV.

Usage from CLI::

    python -m domainai watch "url shortener, short" --tlds com,io --interval 30 --until 5
"""

from __future__ import annotations

import re
import signal
import sys
import time
from typing import Any, Callable

from domainai.checker import DomainResult, check_domain
from domainai.exporter import export_results
from domainai.generator import generate_names
from domainai.storage import Storage

# Maximum number of batches before giving up (prevents infinite loops)
MAX_ATTEMPTS = 10


def _run_batch(
    prompt: str,
    tlds: list[str],
    provider: str,
    api_key: str,
    model: str | None,
    batch_size: int,
    storage: Storage,
    rapidapi_key: str | None,
    rate_limit_delay: float,
    on_result: Callable[[DomainResult], None] | None,
    csv_path: str | None,
    until_target: int | None = None,
    current_available: int = 0,
) -> list[DomainResult]:
    """Generate one batch of names, check them, save results.

    Parameters:
        prompt: User's search criteria.
        tlds: TLDs to check.
        provider: AI provider name.
        api_key: AI provider API key.
        model: AI model override (or ``None``).
        batch_size: Number of names to generate.
        storage: SQLite storage instance.
        rapidapi_key: Optional Domainr RapidAPI key.
        rate_limit_delay: Delay between domain checks.
        on_result: Callback after each domain check.
        csv_path: Path for CSV export.
        until_target: Stop checking after this many total available.
        current_available: How many available found so far across batches.

    Returns:
        List of :class:`DomainResult` from this batch.
    """
    # 1. Generate names via AI
    suggestions = generate_names(
        prompt=prompt,
        count=batch_size,
        provider=provider,
        api_key=api_key,
        model=model,
    )

    names = [
        re.sub(r"[^a-zA-Z0-9]", "", s["name"])
        for s in suggestions
        if s.get("name") and re.fullmatch(r"[a-zA-Z0-9]+", re.sub(r"[^a-zA-Z0-9]", "", s["name"]))
    ]

    # 2. Filter out already-checked domains
    unchecked = storage.get_unchecked(names, tlds)

    if not unchecked:
        return []

    # 3. Check each domain
    batch_results: list[DomainResult] = []
    for name, tld in unchecked:
        result = check_domain(
            name=name,
            tld=tld,
            rapidapi_key=rapidapi_key,
            rate_limit_delay=rate_limit_delay,
        )
        batch_results.append(result)
        storage.save_result(result, prompt=prompt)

        if on_result:
            on_result(result)

        # Early stop when until target reached (checked by caller)
        if until_target is not None:
            avail = sum(1 for r in batch_results if r.available)
            if current_available + avail >= until_target:
                break

    # 4. Export to CSV
    if batch_results:
        export_results(batch_results, path=csv_path)

    return batch_results


def run_search(
    prompt: str,
    tlds: list[str],
    provider: str,
    api_key: str,
    model: str | None = None,
    batch_size: int = 20,
    until: int | None = None,
    max_attempts: int = MAX_ATTEMPTS,
    storage: Storage | None = None,
    rapidapi_key: str | None = None,
    rate_limit_delay: float = 1.0,
    on_result: Callable[[DomainResult], None] | None = None,
    csv_path: str | None = None,
) -> list[DomainResult]:
    """Run a domain search with batch / until logic.

    Supports three modes:
    - **batch only**: Generate ``batch_size`` names, check all, done.
    - **until only**: Keep generating batches until ``until`` available
      domains are found.
    - **both**: Generate up to ``batch_size`` names, but stop early if
      ``until`` available domains are found.

    Parameters:
        prompt: Natural-language search criteria.
        tlds: TLDs to check (e.g. ``["com", "io"]``).
        provider: AI provider name.
        api_key: AI provider API key.
        model: AI model override.
        batch_size: Names per AI batch.
        until: Stop after finding this many available domains.
            ``None`` = no target, just run ``batch_size`` names.
        max_attempts: Maximum number of batches to prevent infinite loops.
        storage: SQLite storage.  A default is created if ``None``.
        rapidapi_key: Optional Domainr RapidAPI key.
        rate_limit_delay: Seconds between domain checks.
        on_result: Callback ``(DomainResult) -> None`` after each check.
        csv_path: Output CSV path.

    Returns:
        All :class:`DomainResult` objects collected across batches.
    """
    own_storage = storage is None
    if own_storage:
        storage = Storage()

    all_results: list[DomainResult] = []
    available_count = 0

    try:
        for attempt in range(1, max_attempts + 1):
            batch_results = _run_batch(
                prompt=prompt,
                tlds=tlds,
                provider=provider,
                api_key=api_key,
                model=model,
                batch_size=batch_size,
                storage=storage,
                rapidapi_key=rapidapi_key,
                rate_limit_delay=rate_limit_delay,
                on_result=on_result,
                csv_path=csv_path,
                until_target=until,
                current_available=available_count,
            )

            all_results.extend(batch_results)
            available_count += sum(1 for r in batch_results if r.available)

            # --- Stop conditions ---
            if until is None:
                # Batch mode: one batch is enough
                break

            if available_count >= until:
                # Until mode: target reached
                break

            # Brief pause before next AI batch
            time.sleep(2)

    finally:
        if own_storage:
            storage.close()

    return all_results


def run_watch(
    prompt: str,
    tlds: list[str],
    provider: str,
    api_key: str,
    model: str | None = None,
    batch_size: int = 20,
    until: int | None = None,
    interval: int = 30,
    max_attempts: int = MAX_ATTEMPTS,
    storage: Storage | None = None,
    rapidapi_key: str | None = None,
    rate_limit_delay: float = 1.0,
    on_result: Callable[[DomainResult], None] | None = None,
    on_cycle_done: Callable[[int, int], None] | None = None,
    csv_path: str | None = None,
) -> list[DomainResult]:
    """Run continuous watch mode with periodic batches.

    Similar to :func:`run_search` but repeats on a timer.  Stops when
    the ``until`` target is met or ``max_attempts`` cycles are exhausted.
    Press Ctrl+C to stop gracefully.

    Parameters:
        prompt: Search criteria.
        tlds: TLDs to check.
        provider: AI provider name.
        api_key: AI provider API key.
        model: AI model override.
        batch_size: Names per AI batch.
        until: Target number of available domains.
        interval: Seconds between cycles.
        max_attempts: Maximum cycles.
        storage: SQLite storage.
        rapidapi_key: Domainr RapidAPI key.
        rate_limit_delay: Delay between domain checks.
        on_result: Callback after each domain check.
        on_cycle_done: Callback ``(cycle_number, total_available)``
            at the end of each cycle.
        csv_path: Output CSV path.

    Returns:
        All :class:`DomainResult` objects collected.
    """
    own_storage = storage is None
    if own_storage:
        storage = Storage()

    all_results: list[DomainResult] = []
    available_count = 0
    _stop = False

    def _signal_handler(sig: int, frame: Any) -> None:
        nonlocal _stop
        _stop = True

    original_handler = signal.getsignal(signal.SIGINT)
    signal.signal(signal.SIGINT, _signal_handler)

    try:
        for cycle in range(1, max_attempts + 1):
            if _stop:
                break

            batch_results = _run_batch(
                prompt=prompt,
                tlds=tlds,
                provider=provider,
                api_key=api_key,
                model=model,
                batch_size=batch_size,
                storage=storage,
                rapidapi_key=rapidapi_key,
                rate_limit_delay=rate_limit_delay,
                on_result=on_result,
                csv_path=csv_path,
                until_target=until,
                current_available=available_count,
            )

            all_results.extend(batch_results)
            available_count += sum(1 for r in batch_results if r.available)

            if on_cycle_done:
                on_cycle_done(cycle, available_count)

            # --- Stop conditions ---
            if until is not None and available_count >= until:
                break

            if cycle < max_attempts and not _stop:
                time.sleep(interval)

    finally:
        signal.signal(signal.SIGINT, original_handler)
        if own_storage:
            storage.close()

    return all_results
