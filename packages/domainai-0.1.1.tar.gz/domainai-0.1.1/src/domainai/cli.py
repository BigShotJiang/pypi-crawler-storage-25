"""domainai CLI — AI-powered domain name generator and availability checker.

Entry point: ``python -m domainai``

Commands:
    setup     Interactive first-time configuration
    search    Generate and check domain names
    watch     Continuous background search
    history   Show past domain checks
    results   Show saved CSV results
"""

from __future__ import annotations

import argparse
import getpass
import json
import os
import sys
from pathlib import Path

from rich.console import Console
from rich.table import Table

from domainai.checker import DomainResult
from domainai.exporter import export_results, read_results
from domainai.generator import (
    DEFAULT_MODELS,
    RECOMMENDED_MODELS,
    get_provider,
    list_providers,
    validate_provider,
)
from domainai.scheduler import run_search, run_watch
from domainai.storage import Storage

# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

CONFIG_DIR = Path.home() / ".domainai"
CONFIG_FILE = CONFIG_DIR / "config.json"

console = Console()


def _load_config() -> dict:
    """Load config from ``~/.domainai/config.json``."""
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    return {}


def _save_config(data: dict) -> None:
    """Save config to ``~/.domainai/config.json``."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


def _load_env() -> dict:
    """Read provider settings from .env file or environment variables."""
    env: dict = {}

    # Try loading .env file from cwd
    dotenv_path = Path(".env")
    if dotenv_path.exists():
        for line in dotenv_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                key, _, value = line.partition("=")
                env[key.strip()] = value.strip()

    # Environment variables override .env
    for key in ("AI_PROVIDER", "AI_API_KEY", "AI_MODEL", "DOMAINR_API_KEY"):
        val = os.environ.get(key)
        if val:
            env[key] = val

    return env


def _resolve_config(args: argparse.Namespace) -> dict:
    """Merge config sources in priority order: CLI > .env > config.json.

    Returns a dict with keys: provider, api_key, model, rapidapi_key.
    """
    config = _load_config()
    env = _load_env()

    provider = (
        getattr(args, "provider", None)
        or env.get("AI_PROVIDER")
        or config.get("provider")
    )
    api_key = (
        getattr(args, "api_key", None)
        or env.get("AI_API_KEY")
        or config.get("api_key")
    )
    model = (
        getattr(args, "model", None)
        or env.get("AI_MODEL")
        or config.get("model")
    )
    rapidapi_key = (
        env.get("DOMAINR_API_KEY")
        or config.get("rapidapi_key")
    )

    return {
        "provider": provider,
        "api_key": api_key,
        "model": model,
        "rapidapi_key": rapidapi_key,
    }


# ---------------------------------------------------------------------------
# Result display
# ---------------------------------------------------------------------------

def _print_result(result: DomainResult) -> None:
    """Print a single domain check result with rich formatting."""
    if result.available:
        console.print(
            f"  [bold green]✅ {result.domain:<20}[/] → available   → [link={result.buy_url}]{result.buy_url}[/link]"
        )
    else:
        console.print(
            f"  [bold red]❌ {result.domain:<20}[/] → taken"
        )


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_setup(args: argparse.Namespace) -> None:
    """Interactive setup wizard."""
    console.print("\n[bold cyan]🔧  domainai setup[/]\n")

    providers_info = {
        "groq": ("Groq (free, recommended)", "https://console.groq.com"),
        "openai": ("OpenAI / ChatGPT", "https://platform.openai.com/api-keys"),
        "gemini": ("Google Gemini", "https://aistudio.google.com/apikey"),
        "anthropic": ("Anthropic / Claude", "https://console.anthropic.com"),
    }

    console.print("Which AI provider would you like to use?\n")
    choices = list(providers_info.keys())
    for i, key in enumerate(choices, 1):
        label, url = providers_info[key]
        console.print(f"  [bold][{i}][/] {label}")
    console.print()

    while True:
        choice = input("Enter number (1-4): ").strip()
        if choice in ("1", "2", "3", "4"):
            break
        console.print("[red]Invalid choice. Enter 1-4.[/]")

    provider = choices[int(choice) - 1]
    label, url = providers_info[provider]

    console.print(f"\n[cyan]Get your API key here:[/] [link={url}]{url}[/link]\n")

    api_key = getpass.getpass("Enter your API key (hidden): ").strip()
    if not api_key:
        console.print("[red]API key cannot be empty.[/]")
        sys.exit(1)

    console.print("\n[dim]Testing connection...[/]")
    try:
        validate_provider(provider=provider, api_key=api_key)
        console.print(f"[bold green]✅ {label} connection successful![/]\n")
    except Exception as e:
        console.print(f"[bold red]❌ Connection failed: {e}[/]")
        sys.exit(1)

    config = _load_config()
    config["provider"] = provider
    config["api_key"] = api_key
    config["model"] = DEFAULT_MODELS.get(provider, "")
    _save_config(config)

    console.print(f"[green]Config saved to {CONFIG_FILE}[/]")
    console.print("[dim]You can now run: python -m domainai search \"your idea\"[/]\n")


def cmd_search(args: argparse.Namespace) -> None:
    """Generate and check domain names."""
    cfg = _resolve_config(args)

    if not cfg["provider"] or not cfg["api_key"]:
        console.print(
            "[red]No AI provider configured. Run:[/] [bold]python -m domainai setup[/]"
        )
        sys.exit(1)

    tlds = [t.strip().lstrip(".") for t in args.tlds.split(",")]
    batch_size = args.batch
    until = args.until

    console.print(f"\n[bold cyan]🔍  Searching domains...[/]")
    console.print(f"[dim]   Prompt: \"{args.prompt}\"[/]")
    console.print(f"[dim]   TLDs: {', '.join(tlds)} | Batch: {batch_size}"
                  + (f" | Until: {until} available" if until else "")
                  + "[/]\n")

    storage = Storage()

    try:
        results = run_search(
            prompt=args.prompt,
            tlds=tlds,
            provider=cfg["provider"],
            api_key=cfg["api_key"],
            model=cfg["model"],
            batch_size=batch_size,
            until=until,
            storage=storage,
            rapidapi_key=cfg["rapidapi_key"],
            rate_limit_delay=args.delay,
            on_result=_print_result,
            csv_path=args.output,
        )
    finally:
        storage.close()

    available = sum(1 for r in results if r.available)
    console.print(f"\n[bold]Done![/] Checked {len(results)} domains, "
                  f"[green]{available} available[/].\n")


def cmd_watch(args: argparse.Namespace) -> None:
    """Continuous background search."""
    cfg = _resolve_config(args)

    if not cfg["provider"] or not cfg["api_key"]:
        console.print(
            "[red]No AI provider configured. Run:[/] [bold]python -m domainai setup[/]"
        )
        sys.exit(1)

    tlds = [t.strip().lstrip(".") for t in args.tlds.split(",")]

    console.print(f"\n[bold cyan]👁  Watch mode[/]")
    console.print(f"[dim]   Prompt: \"{args.prompt}\"[/]")
    console.print(f"[dim]   Interval: {args.interval}s | "
                  + (f"Until: {args.until} available" if args.until else "No limit")
                  + "[/]")
    console.print("[dim]   Press Ctrl+C to stop.[/]\n")

    storage = Storage()

    def on_cycle_done(cycle: int, total_available: int) -> None:
        console.print(
            f"\n[dim]--- Cycle {cycle} complete. "
            f"{total_available} available so far. "
            f"Next check in {args.interval}s ---[/]\n"
        )

    try:
        results = run_watch(
            prompt=args.prompt,
            tlds=tlds,
            provider=cfg["provider"],
            api_key=cfg["api_key"],
            model=cfg["model"],
            batch_size=args.batch,
            until=args.until,
            interval=args.interval,
            storage=storage,
            rapidapi_key=cfg["rapidapi_key"],
            rate_limit_delay=args.delay,
            on_result=_print_result,
            on_cycle_done=on_cycle_done,
            csv_path=args.output,
        )
    finally:
        storage.close()

    available = sum(1 for r in results if r.available)
    console.print(f"\n[bold]Watch stopped.[/] Checked {len(results)} domains, "
                  f"[green]{available} available[/].\n")


def cmd_history(args: argparse.Namespace) -> None:
    """Show past domain checks from SQLite."""
    storage = Storage()
    rows = storage.get_history(limit=args.limit)
    storage.close()

    if not rows:
        console.print("[dim]No history yet. Run a search first.[/]")
        return

    table = Table(title="Domain Check History", show_lines=False)
    table.add_column("Domain", style="bold")
    table.add_column("Available", justify="center")
    table.add_column("Checked At")
    table.add_column("Prompt", max_width=40)

    for row in rows:
        avail = "[green]✅[/]" if row["available"] else "[red]❌[/]"
        table.add_row(
            row["domain"],
            avail,
            row["checked_at"][:16],
            row.get("prompt", ""),
        )

    console.print(table)


def cmd_results(args: argparse.Namespace) -> None:
    """Show saved CSV results."""
    rows = read_results(path=args.output)

    if not rows:
        console.print("[dim]No results file found. Run a search first.[/]")
        return

    table = Table(title="Saved Results", show_lines=False)
    table.add_column("Domain", style="bold")
    table.add_column("TLD")
    table.add_column("Available", justify="center")
    table.add_column("Checked At")
    table.add_column("Buy URL")

    for row in rows:
        avail = "[green]✅[/]" if row.get("available") == "true" else "[red]❌[/]"
        table.add_row(
            row.get("domain", ""),
            row.get("tld", ""),
            avail,
            row.get("checked_at", ""),
            row.get("buy_url", ""),
        )

    console.print(table)


def cmd_models(args: argparse.Namespace) -> None:
    """List recommended models for each provider."""
    table = Table(title="Recommended Models", show_lines=True)
    table.add_column("Provider", style="bold cyan")
    table.add_column("Default", style="green")
    table.add_column("Alternatives", style="dim")

    for provider in sorted(RECOMMENDED_MODELS.keys()):
        default = DEFAULT_MODELS.get(provider, "-")
        alternatives = [m for m in RECOMMENDED_MODELS[provider] if m != default]
        table.add_row(provider, default, "\n".join(alternatives) or "-")

    console.print(table)
    console.print(
        "\n[dim]Use a specific model with: "
        "[bold]--model MODEL_NAME[/][/]\n"
    )


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="domainai",
        description="AI-powered domain name generator and availability checker.",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- setup ---
    subparsers.add_parser("setup", help="Interactive first-time configuration")

    # --- search ---
    p_search = subparsers.add_parser("search", help="Generate and check domain names")
    p_search.add_argument("prompt", help="Natural-language description of desired domain")
    p_search.add_argument("--tlds", default="com", help="Comma-separated TLDs (default: com)")
    p_search.add_argument("--batch", type=int, default=20, help="Number of names per batch (default: 20)")
    p_search.add_argument("--until", type=int, default=None, help="Stop after N available domains")
    p_search.add_argument("--delay", type=float, default=1.0, help="Seconds between checks (default: 1.0)")
    p_search.add_argument("--output", default="results.csv", help="Output CSV path (default: results.csv)")
    p_search.add_argument("--provider", default=None, help="AI provider override")
    p_search.add_argument("--api-key", dest="api_key", default=None, help="API key override")
    p_search.add_argument("--model", default=None, help="Model override")

    # --- watch ---
    p_watch = subparsers.add_parser("watch", help="Continuous background search")
    p_watch.add_argument("prompt", help="Natural-language description of desired domain")
    p_watch.add_argument("--tlds", default="com", help="Comma-separated TLDs (default: com)")
    p_watch.add_argument("--batch", type=int, default=20, help="Names per batch (default: 20)")
    p_watch.add_argument("--until", type=int, default=None, help="Stop after N available domains")
    p_watch.add_argument("--interval", type=int, default=30, help="Seconds between cycles (default: 30)")
    p_watch.add_argument("--delay", type=float, default=1.0, help="Seconds between checks (default: 1.0)")
    p_watch.add_argument("--output", default="results.csv", help="Output CSV path")
    p_watch.add_argument("--provider", default=None, help="AI provider override")
    p_watch.add_argument("--api-key", dest="api_key", default=None, help="API key override")
    p_watch.add_argument("--model", default=None, help="Model override")

    # --- history ---
    p_history = subparsers.add_parser("history", help="Show past domain checks")
    p_history.add_argument("--limit", type=int, default=50, help="Max rows to display (default: 50)")

    # --- results ---
    p_results = subparsers.add_parser("results", help="Show saved CSV results")
    p_results.add_argument("--output", default="results.csv", help="CSV file path")

    # --- models ---
    subparsers.add_parser("models", help="List recommended models per provider")

    return parser


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    """CLI entry point."""
    parser = build_parser()
    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    commands = {
        "setup": cmd_setup,
        "search": cmd_search,
        "watch": cmd_watch,
        "history": cmd_history,
        "results": cmd_results,
        "models": cmd_models,
    }

    cmd_fn = commands.get(args.command)
    if cmd_fn:
        cmd_fn(args)
    else:
        parser.print_help()
