"""Allow running domainai as ``python -m domainai``."""

from domainai.cli import main

main()
