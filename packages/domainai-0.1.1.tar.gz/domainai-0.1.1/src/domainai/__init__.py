"""domainai — AI-powered domain name generator and availability checker."""

__version__ = "0.1.0"
