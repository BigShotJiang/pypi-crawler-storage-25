"""CSV exporter for domain check results.

Appends results to a CSV file (default: ``results.csv`` in the current
directory).  The file is created with headers if it doesn't exist yet;
subsequent runs append without overwriting.
"""

from __future__ import annotations

import csv
from pathlib import Path

from domainai.checker import DomainResult

DEFAULT_CSV_PATH = Path("results.csv")

_FIELDNAMES = ["domain", "tld", "available", "checked_at", "buy_url"]


def export_results(
    results: list[DomainResult],
    path: Path | str | None = None,
) -> Path:
    """Append domain check results to a CSV file.

    Creates the file with a header row if it doesn't already exist.
    Subsequent calls append rows — old data is never overwritten.

    Parameters:
        results: List of :class:`DomainResult` objects to write.
        path: Output file path.  Defaults to ``results.csv``.

    Returns:
        The resolved :class:`Path` of the CSV file.
    """
    csv_path = Path(path) if path else DEFAULT_CSV_PATH
    file_exists = csv_path.exists()

    with csv_path.open("a", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=_FIELDNAMES)

        if not file_exists:
            writer.writeheader()

        for r in results:
            writer.writerow({
                "domain": r.domain,
                "tld": r.tld,
                "available": str(r.available).lower(),
                "checked_at": r.checked_at.strftime("%Y-%m-%d %H:%M"),
                "buy_url": r.buy_url if r.available else "",
            })

    return csv_path


def read_results(path: Path | str | None = None) -> list[dict[str, str]]:
    """Read all rows from the results CSV.

    Parameters:
        path: Path to the CSV file.  Defaults to ``results.csv``.

    Returns:
        List of dicts with keys matching the CSV header.
    """
    csv_path = Path(path) if path else DEFAULT_CSV_PATH

    if not csv_path.exists():
        return []

    with csv_path.open("r", newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        return list(reader)
