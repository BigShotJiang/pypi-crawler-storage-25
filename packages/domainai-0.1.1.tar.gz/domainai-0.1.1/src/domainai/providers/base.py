"""Abstract base class and error definitions for AI providers.

All AI providers (OpenAI, Anthropic, Gemini, Groq) must inherit from
``BaseProvider`` and implement its abstract methods. This ensures a
consistent interface for domain-name generation across different LLM
backends.

Custom exceptions are provided so callers can handle provider-specific
failures (missing API key, rate limiting, generic errors) in a uniform
way.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


# ---------------------------------------------------------------------------
# Custom Exceptions
# ---------------------------------------------------------------------------

class ProviderError(Exception):
    """Base exception for all provider-related errors.

    Attributes:
        provider: Name of the provider that raised the error.
        message: Human-readable error description.
    """

    def __init__(self, message: str, provider: str = "unknown") -> None:
        self.provider = provider
        self.message = message
        super().__init__(f"[{provider}] {message}")


class APIKeyError(ProviderError):
    """Raised when the API key is missing, invalid, or rejected.

    Examples:
        * The user forgot to set ``AI_API_KEY``.
        * The provider returned a 401 / 403 response.
    """

    def __init__(self, provider: str = "unknown") -> None:
        super().__init__(
            "API key is missing or invalid. "
            "Run `domainai setup` or set AI_API_KEY in your .env file.",
            provider=provider,
        )


class RateLimitError(ProviderError):
    """Raised when the provider signals a rate-limit / quota exceeded error.

    Attributes:
        retry_after: Suggested wait time in seconds (``None`` if unknown).
    """

    def __init__(
        self,
        provider: str = "unknown",
        retry_after: float | None = None,
    ) -> None:
        self.retry_after = retry_after
        wait_msg = f" Retry after {retry_after}s." if retry_after else ""
        super().__init__(
            f"Rate limit exceeded.{wait_msg} Please wait and try again.",
            provider=provider,
        )


class ModelNotFoundError(ProviderError):
    """Raised when the requested model is not available on the provider."""

    def __init__(self, model: str, provider: str = "unknown") -> None:
        self.model = model
        super().__init__(
            f"Model '{model}' is not available. "
            "Check the provider docs for supported models.",
            provider=provider,
        )


# ---------------------------------------------------------------------------
# Abstract Base Provider
# ---------------------------------------------------------------------------

class BaseProvider(ABC):
    """Abstract base class that every AI provider adapter must implement.

    Subclasses are responsible for:
    1. Authenticating with the provider's API.
    2. Sending a prompt that asks the LLM to generate creative domain names.
    3. Parsing the response into a standardised list of dictionaries.

    Parameters:
        api_key: Provider API key.
        model: Model identifier to use. If ``None``, the provider's default
            model (returned by :meth:`get_default_model`) is used.
    """

    # Friendly display name — override in each subclass.
    PROVIDER_NAME: str = "base"

    def __init__(self, api_key: str, model: str | None = None) -> None:
        if not api_key:
            raise APIKeyError(provider=self.PROVIDER_NAME)
        self.api_key: str = api_key
        self.model: str = model or self.get_default_model()

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    @abstractmethod
    def generate_names(
        self,
        prompt: str,
        count: int = 20,
    ) -> list[dict[str, Any]]:
        """Generate domain name suggestions using the AI model.

        The provider must instruct the LLM to return *exactly* ``count``
        suggestions.  Each suggestion is a dictionary with:

        * ``name``  (str) — the proposed domain name (without TLD).
        * ``reason`` (str) — a short explanation of why this name fits.
        * ``score``  (int) — a creativity / relevance score from 1-10.

        Parameters:
            prompt: Natural-language description of the desired domain
                (e.g. ``"url shortener, short, energetic, starts with T"``).
            count: Number of names to generate.

        Returns:
            A list of dictionaries, each with keys ``name``, ``reason``,
            and ``score``.

        Raises:
            APIKeyError: If the API key is rejected.
            RateLimitError: If the provider throttles the request.
            ProviderError: For any other provider-side failure.
        """
        ...

    @abstractmethod
    def validate_api_key(self) -> bool:
        """Test whether the configured API key is accepted by the provider.

        Implementations should make a lightweight API call (e.g. list models)
        and return ``True`` on success.  On failure they should raise
        :class:`APIKeyError` rather than returning ``False``, so callers get
        a meaningful error message.

        Returns:
            ``True`` if the key is valid.

        Raises:
            APIKeyError: If the key is invalid or missing.
        """
        ...

    @abstractmethod
    def get_default_model(self) -> str:
        """Return the default model identifier for this provider.

        This is used when the user hasn't explicitly set ``AI_MODEL``.
        Each provider should return its best cheap / free-tier model.

        Returns:
            Model identifier string (e.g. ``"gpt-4o-mini"``).
        """
        ...

    # ------------------------------------------------------------------
    # Shared helpers (available to all subclasses)
    # ------------------------------------------------------------------

    def _build_system_prompt(self, count: int) -> str:
        """Return the system prompt that instructs the LLM to act as a domain-name generator.

        Parameters:
            count: How many names the LLM should produce.

        Returns:
            A system-level instruction string.
        """
        return (
            "You are an expert domain-name brainstorming assistant. "
            "The user will describe the kind of domain they want. "
            f"Generate exactly {count} creative domain name suggestions.\n\n"
            "Rules:\n"
            "- Names must be short, memorable, and brandable.\n"
            "- Names must be a single word with NO spaces or hyphens.\n"
            "- Do NOT include TLDs (like .com) — just the base name.\n"
            "- Respond ONLY with valid JSON — no markdown, no commentary.\n"
            "- Use this exact schema:\n"
            "[\n"
            '  {"name": "example", "reason": "why this name fits", "score": 8},\n'
            "  ...\n"
            "]\n"
            '- "score" is an integer from 1 to 10 rating creativity and '
            "relevance.\n"
        )

    def _build_user_prompt(self, prompt: str, count: int) -> str:
        """Return the user-facing prompt sent to the LLM.

        Parameters:
            prompt: The raw user criteria.
            count: Number of names requested.

        Returns:
            Formatted user prompt string.
        """
        return (
            f"Generate {count} domain name ideas based on this description:\n"
            f'"{prompt}"\n\n'
            "Return ONLY a JSON array, no extra text."
        )

    def __repr__(self) -> str:
        return (
            f"<{self.__class__.__name__} provider={self.PROVIDER_NAME!r} "
            f"model={self.model!r}>"
        )
