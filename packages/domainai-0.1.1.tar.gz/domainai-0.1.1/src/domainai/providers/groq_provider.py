"""Groq provider adapter for domain name generation.

Groq offers free-tier access to open-source models with extremely fast
inference.  This is the recommended default provider for domainai.

Requires: ``pip install groq``
"""

from __future__ import annotations

import json
import time
from typing import Any

from domainai.providers.base import (
    APIKeyError,
    BaseProvider,
    ProviderError,
    RateLimitError,
)

# Default model — fast, free, high quality
_DEFAULT_MODEL = "llama-3.3-70b-versatile"


class GroqProvider(BaseProvider):
    """Groq adapter using the official ``groq`` Python SDK.

    Parameters:
        api_key: Groq API key (starts with ``gsk_``).
        model: Model identifier.  Defaults to ``llama-3.3-70b-versatile``.
    """

    PROVIDER_NAME: str = "groq"

    def __init__(self, api_key: str, model: str | None = None) -> None:
        super().__init__(api_key=api_key, model=model)
        try:
            from groq import Groq  # type: ignore[import-untyped]
        except ImportError:
            raise ProviderError(
                "Groq SDK is not installed. Run: pip install domainai[groq]",
                provider=self.PROVIDER_NAME,
            )
        self._client = Groq(api_key=self.api_key)

    # ------------------------------------------------------------------
    # Abstract interface implementation
    # ------------------------------------------------------------------

    def get_default_model(self) -> str:
        """Return Groq's recommended free-tier model."""
        return _DEFAULT_MODEL

    def validate_api_key(self) -> bool:
        """Validate the API key by listing available models.

        Returns:
            ``True`` if the key is accepted.

        Raises:
            APIKeyError: If the key is rejected.
        """
        try:
            self._client.models.list()
            return True
        except Exception as exc:
            if _is_auth_error(exc):
                raise APIKeyError(provider=self.PROVIDER_NAME) from exc
            raise ProviderError(str(exc), provider=self.PROVIDER_NAME) from exc

    def generate_names(
        self,
        prompt: str,
        count: int = 20,
    ) -> list[dict[str, Any]]:
        """Generate domain names via the Groq chat completions API.

        Parameters:
            prompt: Natural-language description of the desired domain.
            count: Number of names to generate.

        Returns:
            List of ``{"name": str, "reason": str, "score": int}`` dicts.
        """
        system_prompt = self._build_system_prompt(count)
        user_prompt = self._build_user_prompt(prompt, count)

        try:
            response = self._client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.9,
                max_tokens=4096,
            )
        except Exception as exc:
            _handle_api_error(exc, self.PROVIDER_NAME)

        raw = response.choices[0].message.content or ""
        return _parse_json_response(raw, self.PROVIDER_NAME)


# ---------------------------------------------------------------------------
# Helpers (module-private)
# ---------------------------------------------------------------------------

def _is_auth_error(exc: Exception) -> bool:
    """Return ``True`` if the exception indicates an authentication failure."""
    error_str = str(exc).lower()
    return any(
        keyword in error_str
        for keyword in ("authentication", "unauthorized", "401", "invalid api key")
    )


def _is_rate_limit_error(exc: Exception) -> bool:
    """Return ``True`` if the exception indicates rate-limiting."""
    error_str = str(exc).lower()
    return any(
        keyword in error_str
        for keyword in ("rate_limit", "rate limit", "429", "too many requests")
    )


def _handle_api_error(exc: Exception, provider: str) -> None:
    """Translate SDK exceptions into domainai exception types.

    Always raises — never returns normally.
    """
    if _is_auth_error(exc):
        raise APIKeyError(provider=provider) from exc
    if _is_rate_limit_error(exc):
        retry_after = getattr(exc, "retry_after", None)
        raise RateLimitError(provider=provider, retry_after=retry_after) from exc
    raise ProviderError(str(exc), provider=provider) from exc


def _parse_json_response(raw: str, provider: str) -> list[dict[str, Any]]:
    """Parse the LLM's raw text into a validated list of name dicts.

    Handles common quirks like markdown code fences around JSON.

    Parameters:
        raw: Raw text from the LLM response.
        provider: Provider name for error messages.

    Returns:
        List of validated name dictionaries.

    Raises:
        ProviderError: If the response cannot be parsed.
    """
    # Strip markdown code fences if present
    text = raw.strip()
    if text.startswith("```"):
        # Remove opening fence (```json or ```)
        first_newline = text.index("\n") if "\n" in text else 3
        text = text[first_newline + 1:]
    if text.endswith("```"):
        text = text[:-3]
    text = text.strip()

    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ProviderError(
            f"Failed to parse AI response as JSON: {exc}",
            provider=provider,
        ) from exc

    if not isinstance(data, list):
        raise ProviderError(
            "AI response is not a JSON array.",
            provider=provider,
        )

    results: list[dict[str, Any]] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        results.append({
            "name": str(item.get("name", "")).strip().lower(),
            "reason": str(item.get("reason", "")),
            "score": int(item.get("score", 5)),
        })

    return results
