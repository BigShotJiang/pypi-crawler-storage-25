"""OpenAI provider adapter for domain name generation.

Supports GPT-4o-mini (default) and any other chat-completion model
available on the OpenAI platform.

Requires: ``pip install openai``
"""

from __future__ import annotations

import json
from typing import Any

from domainai.providers.base import (
    APIKeyError,
    BaseProvider,
    ProviderError,
    RateLimitError,
)

_DEFAULT_MODEL = "gpt-4o"


class OpenAIProvider(BaseProvider):
    """OpenAI / ChatGPT adapter using the official ``openai`` Python SDK.

    Parameters:
        api_key: OpenAI API key (starts with ``sk-``).
        model: Model identifier.  Defaults to ``gpt-4o-mini``.
    """

    PROVIDER_NAME: str = "openai"

    def __init__(self, api_key: str, model: str | None = None) -> None:
        super().__init__(api_key=api_key, model=model)
        try:
            from openai import OpenAI  # type: ignore[import-untyped]
        except ImportError:
            raise ProviderError(
                "OpenAI SDK is not installed. Run: pip install domainai[openai]",
                provider=self.PROVIDER_NAME,
            )
        self._client = OpenAI(api_key=self.api_key)

    # ------------------------------------------------------------------
    # Abstract interface implementation
    # ------------------------------------------------------------------

    def get_default_model(self) -> str:
        """Return OpenAI's recommended cheap model."""
        return _DEFAULT_MODEL

    def validate_api_key(self) -> bool:
        """Validate the API key by listing models.

        Returns:
            ``True`` if the key is accepted.

        Raises:
            APIKeyError: If the key is rejected.
        """
        try:
            self._client.models.list()
            return True
        except Exception as exc:
            if _is_auth_error(exc):
                raise APIKeyError(provider=self.PROVIDER_NAME) from exc
            raise ProviderError(str(exc), provider=self.PROVIDER_NAME) from exc

    def generate_names(
        self,
        prompt: str,
        count: int = 20,
    ) -> list[dict[str, Any]]:
        """Generate domain names via the OpenAI chat completions API.

        Parameters:
            prompt: Natural-language description of the desired domain.
            count: Number of names to generate.

        Returns:
            List of ``{"name": str, "reason": str, "score": int}`` dicts.
        """
        system_prompt = self._build_system_prompt(count)
        user_prompt = self._build_user_prompt(prompt, count)

        try:
            response = self._client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.9,
                max_tokens=4096,
            )
        except Exception as exc:
            _handle_api_error(exc, self.PROVIDER_NAME)

        raw = response.choices[0].message.content or ""
        return _parse_json_response(raw, self.PROVIDER_NAME)


# ---------------------------------------------------------------------------
# Helpers (module-private)
# ---------------------------------------------------------------------------

def _is_auth_error(exc: Exception) -> bool:
    """Return ``True`` if the exception indicates an authentication failure."""
    error_str = str(exc).lower()
    return any(
        keyword in error_str
        for keyword in ("authentication", "unauthorized", "401", "invalid api key", "incorrect api key")
    )


def _is_rate_limit_error(exc: Exception) -> bool:
    """Return ``True`` if the exception indicates rate-limiting."""
    error_str = str(exc).lower()
    return any(
        keyword in error_str
        for keyword in ("rate_limit", "rate limit", "429", "too many requests")
    )


def _handle_api_error(exc: Exception, provider: str) -> None:
    """Translate SDK exceptions into domainai exception types."""
    if _is_auth_error(exc):
        raise APIKeyError(provider=provider) from exc
    if _is_rate_limit_error(exc):
        retry_after = getattr(exc, "retry_after", None)
        raise RateLimitError(provider=provider, retry_after=retry_after) from exc
    raise ProviderError(str(exc), provider=provider) from exc


def _parse_json_response(raw: str, provider: str) -> list[dict[str, Any]]:
    """Parse the LLM's raw text into a validated list of name dicts."""
    text = raw.strip()
    if text.startswith("```"):
        first_newline = text.index("\n") if "\n" in text else 3
        text = text[first_newline + 1:]
    if text.endswith("```"):
        text = text[:-3]
    text = text.strip()

    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ProviderError(
            f"Failed to parse AI response as JSON: {exc}",
            provider=provider,
        ) from exc

    if not isinstance(data, list):
        raise ProviderError(
            "AI response is not a JSON array.",
            provider=provider,
        )

    results: list[dict[str, Any]] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        results.append({
            "name": str(item.get("name", "")).strip().lower(),
            "reason": str(item.get("reason", "")),
            "score": int(item.get("score", 5)),
        })

    return results
