"""AI provider adapters for domain name generation."""
