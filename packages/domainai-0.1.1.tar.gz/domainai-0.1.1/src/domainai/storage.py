"""SQLite storage for domain check history.

Keeps a persistent record of every domain checked so that:
- The same domain is never checked twice (deduplication).
- Users can view their search history later.

The database file lives at ``~/.domainai/history.db`` by default.
"""

from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from domainai.checker import DomainResult

# Default database location
DEFAULT_DB_DIR = Path.home() / ".domainai"
DEFAULT_DB_PATH = DEFAULT_DB_DIR / "history.db"

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS domain_checks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    domain      TEXT    NOT NULL,
    name        TEXT    NOT NULL,
    tld         TEXT    NOT NULL,
    available   INTEGER NOT NULL,
    checked_at  TEXT    NOT NULL,
    buy_url     TEXT    DEFAULT '',
    prompt      TEXT    DEFAULT '',
    UNIQUE(domain)
);
"""

_CREATE_INDEX = """
CREATE INDEX IF NOT EXISTS idx_domain ON domain_checks(domain);
"""


class Storage:
    """SQLite-backed storage for domain check history.

    Parameters:
        db_path: Path to the SQLite database file.  If ``None``,
            defaults to ``~/.domainai/history.db``.
    """

    def __init__(self, db_path: Path | str | None = None) -> None:
        self.db_path = Path(db_path) if db_path else DEFAULT_DB_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path))
        self._conn.row_factory = sqlite3.Row
        self._init_db()

    def _init_db(self) -> None:
        """Create tables and indexes if they don't exist."""
        with self._conn:
            self._conn.execute(_CREATE_TABLE)
            self._conn.execute(_CREATE_INDEX)

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    def save_result(self, result: DomainResult, prompt: str = "") -> None:
        """Save a single domain check result.

        If the domain already exists, the record is updated with the
        latest check data.

        Parameters:
            result: The domain check result to store.
            prompt: The original search prompt (for history display).
        """
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO domain_checks (domain, name, tld, available, checked_at, buy_url, prompt)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(domain) DO UPDATE SET
                    available  = excluded.available,
                    checked_at = excluded.checked_at,
                    buy_url    = excluded.buy_url,
                    prompt     = excluded.prompt
                """,
                (
                    result.domain,
                    result.name,
                    result.tld,
                    int(result.available),
                    result.checked_at.isoformat(),
                    result.buy_url,
                    prompt,
                ),
            )

    def save_results(self, results: list[DomainResult], prompt: str = "") -> None:
        """Save multiple domain check results in a single transaction.

        Parameters:
            results: List of domain check results.
            prompt: The original search prompt.
        """
        with self._conn:
            self._conn.executemany(
                """
                INSERT INTO domain_checks (domain, name, tld, available, checked_at, buy_url, prompt)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(domain) DO UPDATE SET
                    available  = excluded.available,
                    checked_at = excluded.checked_at,
                    buy_url    = excluded.buy_url,
                    prompt     = excluded.prompt
                """,
                [
                    (
                        r.domain,
                        r.name,
                        r.tld,
                        int(r.available),
                        r.checked_at.isoformat(),
                        r.buy_url,
                        prompt,
                    )
                    for r in results
                ],
            )

    # ------------------------------------------------------------------
    # Read operations
    # ------------------------------------------------------------------

    def is_checked(self, domain: str) -> bool:
        """Return ``True`` if the domain has already been checked.

        Parameters:
            domain: Full domain string (e.g. ``"tronq.io"``).
        """
        row = self._conn.execute(
            "SELECT 1 FROM domain_checks WHERE domain = ?", (domain,)
        ).fetchone()
        return row is not None

    def get_unchecked(self, names: list[str], tlds: list[str]) -> list[tuple[str, str]]:
        """Filter out name+TLD pairs that have already been checked.

        Parameters:
            names: Base domain names.
            tlds: TLDs to combine with each name.

        Returns:
            List of ``(name, tld)`` tuples that are NOT yet in the database.
        """
        unchecked: list[tuple[str, str]] = []
        for name in names:
            for tld in tlds:
                domain = f"{name}.{tld}"
                if not self.is_checked(domain):
                    unchecked.append((name, tld))
        return unchecked

    def get_history(self, limit: int = 100) -> list[dict[str, Any]]:
        """Return the most recent domain checks.

        Parameters:
            limit: Maximum number of records to return.

        Returns:
            List of dicts with keys matching the table columns.
        """
        rows = self._conn.execute(
            "SELECT * FROM domain_checks ORDER BY checked_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(row) for row in rows]

    def get_available(self, limit: int = 100) -> list[dict[str, Any]]:
        """Return only the domains that were found to be available.

        Parameters:
            limit: Maximum number of records.

        Returns:
            List of dicts for available domains.
        """
        rows = self._conn.execute(
            "SELECT * FROM domain_checks WHERE available = 1 ORDER BY checked_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(row) for row in rows]

    def count(self) -> int:
        """Return the total number of checked domains."""
        row = self._conn.execute("SELECT COUNT(*) FROM domain_checks").fetchone()
        return row[0] if row else 0

    def count_available(self) -> int:
        """Return the number of available domains found."""
        row = self._conn.execute(
            "SELECT COUNT(*) FROM domain_checks WHERE available = 1"
        ).fetchone()
        return row[0] if row else 0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Close the database connection."""
        self._conn.close()

    def __enter__(self) -> Storage:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
