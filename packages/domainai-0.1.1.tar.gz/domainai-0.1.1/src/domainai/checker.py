"""Domain availability checker using Domainr API and python-whois.

Provides a dual-check strategy:

1. **Domainr API** (fast, rate-limited) — primary check via the Domainr
   JSON API.  Requires a RapidAPI key for production use but works for
   basic lookups.
2. **python-whois** (slower, no key needed) — fallback / confirmation
   check via WHOIS protocol.

The public API is :func:`check_domains`, which accepts a list of base
names and TLDs and returns availability results.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

# Optional imports — gracefully degrade if not installed
try:
    import whois as python_whois  # type: ignore[import-untyped]

    _HAS_WHOIS = True
except ImportError:
    _HAS_WHOIS = False

try:
    import httpx  # type: ignore[import-untyped]

    _HAS_HTTPX = True
except ImportError:
    try:
        import requests  # type: ignore[import-untyped]

        _HAS_HTTPX = False
    except ImportError:
        raise ImportError(
            "Either 'httpx' or 'requests' must be installed. "
            "Run: pip install httpx"
        )

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

BUY_URL_TEMPLATE = "https://www.namecheap.com/domains/registration/results/?domain={domain}"


@dataclass
class DomainResult:
    """Result of a single domain availability check.

    Attributes:
        domain: Full domain string (e.g. ``"tronq.io"``).
        name: Base name without TLD (e.g. ``"tronq"``).
        tld: Top-level domain (e.g. ``"io"``).
        available: ``True`` if the domain appears to be available.
        checked_at: UTC timestamp of the check.
        buy_url: Affiliate/registrar link if the domain is available.
    """

    domain: str
    name: str
    tld: str
    available: bool
    checked_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    buy_url: str = ""

    def __post_init__(self) -> None:
        if self.available and not self.buy_url:
            self.buy_url = BUY_URL_TEMPLATE.format(domain=self.domain)


# ---------------------------------------------------------------------------
# Low-level check functions
# ---------------------------------------------------------------------------

def _check_whois(domain: str) -> bool | None:
    """Check domain availability via WHOIS lookup.

    Parameters:
        domain: Full domain (e.g. ``"example.com"``).

    Returns:
        ``True`` if available, ``False`` if taken, ``None`` if
        the check failed or the library is missing.
    """
    if not _HAS_WHOIS:
        return None

    try:
        w = python_whois.whois(domain)
        # If domain_name is None / empty, the domain is likely available
        if w.domain_name is None:
            return True
        return False
    except Exception as exc:
        # "Domain not found" / "No match" type responses indicate availability
        exc_name = type(exc).__name__.lower()
        exc_str = str(exc).lower()
        if "not found" in exc_str or "no match" in exc_str or "notfound" in exc_name:
            return True
        # Network issues, unsupported TLD, etc.
        return None


def _check_domainr(domain: str, rapidapi_key: str | None = None) -> bool | None:
    """Check domain availability via the Domainr API (RapidAPI).

    Parameters:
        domain: Full domain (e.g. ``"example.com"``).
        rapidapi_key: RapidAPI key for Domainr.  If ``None``, this
            check is skipped.

    Returns:
        ``True`` if available, ``False`` if taken, ``None`` if
        the check was skipped or failed.
    """
    if not rapidapi_key:
        return None

    url = "https://domainr.p.rapidapi.com/v2/status"
    params = {"domain": domain}
    headers = {
        "x-rapidapi-host": "domainr.p.rapidapi.com",
        "x-rapidapi-key": rapidapi_key,
    }

    try:
        if _HAS_HTTPX:
            resp = httpx.get(url, params=params, headers=headers, timeout=10)
            resp.raise_for_status()
            data = resp.json()
        else:
            resp = requests.get(url, params=params, headers=headers, timeout=10)  # type: ignore[possibly-undefined]
            resp.raise_for_status()
            data = resp.json()

        # Domainr returns a "status" array
        statuses = data.get("status", [])
        for entry in statuses:
            summary = entry.get("summary", "").lower()
            if "inactive" in summary or "available" in summary:
                return True
            if "active" in summary or "marketed" in summary:
                return False

        return None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def check_domain(
    name: str,
    tld: str,
    rapidapi_key: str | None = None,
    rate_limit_delay: float = 1.0,
) -> DomainResult:
    """Check availability of a single domain.

    Uses a dual-check strategy: Domainr first, then WHOIS as fallback.

    Parameters:
        name: Base domain name (e.g. ``"tronq"``).
        tld: Top-level domain without dot (e.g. ``"io"``).
        rapidapi_key: Optional RapidAPI key for Domainr.
        rate_limit_delay: Seconds to wait between external API calls.

    Returns:
        A :class:`DomainResult` with the availability verdict.
    """
    domain = f"{name}.{tld}"

    # --- Primary: Domainr API ---
    domainr_result = _check_domainr(domain, rapidapi_key)

    if rate_limit_delay > 0:
        time.sleep(rate_limit_delay)

    # --- Fallback: WHOIS ---
    whois_result = _check_whois(domain)

    # --- Decision logic ---
    if domainr_result is not None:
        available = domainr_result
    elif whois_result is not None:
        available = whois_result
    else:
        # Both checks failed — assume not available to be safe
        available = False

    return DomainResult(
        domain=domain,
        name=name,
        tld=tld,
        available=available,
    )


def check_domains(
    names: list[str],
    tlds: list[str],
    rapidapi_key: str | None = None,
    rate_limit_delay: float = 1.0,
    on_result: Any = None,
) -> list[DomainResult]:
    """Check availability of multiple domain name + TLD combinations.

    For each ``(name, tld)`` pair a :class:`DomainResult` is produced.

    Parameters:
        names: Base domain names (e.g. ``["tronq", "sniplo"]``).
        tlds: TLDs to test (e.g. ``["com", "io"]``).
        rapidapi_key: Optional RapidAPI key.
        rate_limit_delay: Seconds to wait between checks.
        on_result: Optional callback ``(DomainResult) -> None`` that is
            invoked after every single check — useful for streaming
            results to the terminal in real time.

    Returns:
        List of :class:`DomainResult` objects.
    """
    results: list[DomainResult] = []

    for name in names:
        for tld in tlds:
            result = check_domain(
                name=name,
                tld=tld,
                rapidapi_key=rapidapi_key,
                rate_limit_delay=rate_limit_delay,
            )
            results.append(result)

            if on_result is not None:
                on_result(result)

    return results
