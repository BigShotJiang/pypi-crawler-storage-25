"""Provider-agnostic name generator with factory pattern.

This module is the single entry point for generating domain names.  It
reads the user's configuration, instantiates the correct provider adapter,
and delegates the actual LLM call.

Usage::

    from domainai.generator import generate_names

    names = generate_names(
        prompt="url shortener, short, energetic",
        count=20,
        provider="groq",
        api_key="gsk_xxx",
        model=None,      # uses provider default
    )
"""

from __future__ import annotations

from typing import Any

from domainai.providers.base import BaseProvider, ProviderError

# ---------------------------------------------------------------------------
# Provider registry — maps config string → (module_path, class_name)
# ---------------------------------------------------------------------------

_PROVIDER_MAP: dict[str, tuple[str, str]] = {
    "groq": ("domainai.providers.groq_provider", "GroqProvider"),
    "openai": ("domainai.providers.openai_provider", "OpenAIProvider"),
    "anthropic": ("domainai.providers.anthropic_provider", "AnthropicProvider"),
    "gemini": ("domainai.providers.gemini_provider", "GeminiProvider"),
}

# Aliases for convenience
_PROVIDER_ALIASES: dict[str, str] = {
    "chatgpt": "openai",
    "claude": "anthropic",
    "google": "gemini",
}

# Default models per provider (kept in sync with each adapter)
DEFAULT_MODELS: dict[str, str] = {
    "openai": "gpt-4o",
    "anthropic": "claude-sonnet-4-5",
    "gemini": "gemini-2.5-flash",
    "groq": "llama-3.3-70b-versatile",
}

# Curated alternative models shown by `domainai models`
RECOMMENDED_MODELS: dict[str, list[str]] = {
    "openai": ["gpt-4o", "gpt-4o-mini", "gpt-5", "gpt-5-mini", "gpt-4-turbo"],
    "anthropic": [
        "claude-sonnet-4-5",
        "claude-sonnet-4-6",
        "claude-opus-4-5",
        "claude-opus-4-6",
        "claude-3-5-haiku-latest",
    ],
    "gemini": [
        "gemini-2.5-pro",
        "gemini-2.5-flash",
        "gemini-2.5-flash-lite",
        "gemini-2.0-flash",
        "gemini-1.5-flash",
    ],
    "groq": [
        "llama-3.3-70b-versatile",
        "llama-3.1-8b-instant",
        "mixtral-8x7b-32768",
    ],
}


def get_provider(
    provider: str,
    api_key: str,
    model: str | None = None,
) -> BaseProvider:
    """Instantiate and return the requested AI provider adapter.

    Parameters:
        provider: Provider name (``"groq"``, ``"openai"``, ``"anthropic"``,
            ``"gemini"``).  Aliases like ``"chatgpt"`` are also accepted.
        api_key: The user's API key for that provider.
        model: Optional model override.  If ``None``, the provider's
            built-in default is used.

    Returns:
        A :class:`BaseProvider` subclass instance ready to call
        :meth:`generate_names`.

    Raises:
        ProviderError: If the provider name is unknown or the SDK is not
            installed.
    """
    name = provider.lower().strip()
    name = _PROVIDER_ALIASES.get(name, name)

    if name not in _PROVIDER_MAP:
        supported = ", ".join(sorted(_PROVIDER_MAP.keys()))
        raise ProviderError(
            f"Unknown provider '{provider}'. Supported: {supported}",
            provider=provider,
        )

    module_path, class_name = _PROVIDER_MAP[name]

    # Lazy import so we only load SDKs the user actually needs
    import importlib

    try:
        module = importlib.import_module(module_path)
    except ImportError as exc:
        raise ProviderError(
            f"Could not import provider module '{module_path}'. "
            f"Install the SDK: pip install domainai[{name}]",
            provider=name,
        ) from exc

    cls = getattr(module, class_name)
    return cls(api_key=api_key, model=model)


def generate_names(
    prompt: str,
    count: int = 20,
    *,
    provider: str,
    api_key: str,
    model: str | None = None,
) -> list[dict[str, Any]]:
    """Generate domain name suggestions using the specified AI provider.

    This is the main high-level function most callers should use.

    Parameters:
        prompt: Natural-language description of the desired domain.
        count: Number of names to generate per batch.
        provider: Provider name (``"groq"``, ``"openai"``, etc.).
        api_key: API key for the chosen provider.
        model: Optional model override.

    Returns:
        List of ``{"name": str, "reason": str, "score": int}`` dicts.
    """
    adapter = get_provider(provider=provider, api_key=api_key, model=model)
    return adapter.generate_names(prompt=prompt, count=count)


def list_providers() -> list[str]:
    """Return a sorted list of supported provider names."""
    return sorted(_PROVIDER_MAP.keys())


def validate_provider(
    provider: str,
    api_key: str,
    model: str | None = None,
) -> bool:
    """Validate an API key for the given provider.

    Parameters:
        provider: Provider name.
        api_key: API key to validate.
        model: Optional model override.

    Returns:
        ``True`` if connection succeeds.

    Raises:
        APIKeyError: If the key is rejected.
        ProviderError: For other failures.
    """
    adapter = get_provider(provider=provider, api_key=api_key, model=model)
    return adapter.validate_api_key()
