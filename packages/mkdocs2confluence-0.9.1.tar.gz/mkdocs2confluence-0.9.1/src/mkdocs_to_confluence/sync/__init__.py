"""Confluence ↔ GitHub comment synchronisation."""
