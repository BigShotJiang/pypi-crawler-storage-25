"""Batch ingestion from transcript files.

Reads a session transcript and pipes it through ``Memotether.remember`` so the
extractor produces atomic memories from a complete conversation after the
fact — the backstop for moments when the live agent didn't call
``remember`` itself.

Supported inputs:
  - .txt / unknown extension : raw text, passed verbatim to remember().
  - .json                    : structured transcript. Auto-detects common
                               shapes — top-level list of messages, or a
                               dict with a ``messages`` / ``turns`` /
                               ``parts`` key. Each message is rendered as
                               ``[turn:tNNN] (role): content``.
  - .jsonl                   : one JSON object per line, each treated as
                               a message with ``role`` / ``content``.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

from memotether import Memotether
from memotether.mcp_server import _resolve_db_path


def _detect_format(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".json":
        return "json"
    if suffix == ".jsonl":
        return "jsonl"
    return "text"


def _extract_content(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        parts: list[str] = []
        for block in value:
            if isinstance(block, dict):
                if block.get("type") == "text" and isinstance(block.get("text"), str):
                    parts.append(block["text"])
                elif isinstance(block.get("content"), str):
                    parts.append(block["content"])
        return "\n".join(parts)
    if isinstance(value, dict):
        for key in ("text", "content"):
            if isinstance(value.get(key), str):
                return value[key]
    return ""


def _flatten_messages(messages: list[Any]) -> str:
    lines: list[str] = []
    for i, msg in enumerate(messages):
        if not isinstance(msg, dict):
            continue
        role = msg.get("role") or msg.get("type") or "unknown"
        content = _extract_content(msg.get("content", msg.get("text", "")))
        if not content.strip():
            continue
        lines.append(f"[turn:t{i:03d}] ({role}): {content}")
    return "\n\n".join(lines)


def _flatten_json(raw: str) -> str:
    data = json.loads(raw)
    if isinstance(data, list):
        return _flatten_messages(data)
    if isinstance(data, dict):
        for key in ("messages", "turns", "parts"):
            value = data.get(key)
            if isinstance(value, list):
                return _flatten_messages(value)
        return json.dumps(data, indent=2, ensure_ascii=False)
    return str(data)


def _flatten_jsonl(raw: str) -> str:
    messages: list[Any] = []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            messages.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return _flatten_messages(messages)


def _load_text(path: Path, format: str) -> str:
    raw = path.read_text(encoding="utf-8")
    if format == "auto":
        format = _detect_format(path)
    if format == "text":
        return raw
    if format == "json":
        return _flatten_json(raw)
    if format == "jsonl":
        return _flatten_jsonl(raw)
    raise ValueError(f"unknown format: {format!r}")


def ingest_file(
    file: str,
    *,
    db: str | None,
    conversation: str | None,
    format: str = "auto",
    store_chunks: bool = True,
) -> dict[str, Any]:
    load_dotenv()
    path = Path(file).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(path)

    text = _load_text(path, format)
    if not text.strip():
        print(f"ingest: {path.name} is empty after parsing — nothing to do.", file=sys.stderr)
        return {"stored": 0, "chunks_stored": 0}

    conv_id = conversation or path.stem
    db_path = _resolve_db_path(db)

    mt = Memotether.from_env(db_path)
    try:
        result = mt.remember(text, conversation_id=conv_id, store_chunks=store_chunks)
    finally:
        mt.close()

    print(
        f"ingested {path.name} → {result['stored']} memories, "
        f"{result['chunks_stored']} chunks (conversation={conv_id}, db={db_path})"
    )
    return result
