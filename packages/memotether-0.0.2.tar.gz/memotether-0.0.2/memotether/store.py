import json
import math
import re
import sqlite3
import struct
import threading
from collections.abc import Iterable
from datetime import datetime
from pathlib import Path
from typing import Callable, Literal

from memotether.embedders import Embedder, call_document, call_documents, call_query
from memotether.schema import AtomicMemory, Chunk, MemoryType


SearchMode = Literal["keyword", "fuzzy", "vector"]


SCHEMA = """
CREATE TABLE IF NOT EXISTS memories (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    content TEXT NOT NULL,
    entities TEXT NOT NULL,
    source_turn_ids TEXT NOT NULL,
    extracted_at TEXT NOT NULL,
    valid_from TEXT,
    confidence REAL NOT NULL,
    conversation_id TEXT,
    embedding BLOB,
    embedding_dim INTEGER
);

CREATE INDEX IF NOT EXISTS idx_memories_type ON memories(type);
CREATE INDEX IF NOT EXISTS idx_memories_conversation ON memories(conversation_id);

CREATE TABLE IF NOT EXISTS supersedes (
    new_id TEXT NOT NULL,
    old_id TEXT NOT NULL,
    PRIMARY KEY (new_id, old_id)
);
CREATE INDEX IF NOT EXISTS idx_supersedes_old ON supersedes(old_id);

CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
    id UNINDEXED,
    content,
    entity_text,
    tokenize='porter unicode61'
);

CREATE VIRTUAL TABLE IF NOT EXISTS memories_trigram USING fts5(
    id UNINDEXED,
    content,
    entity_text,
    tokenize='trigram'
);

CREATE TABLE IF NOT EXISTS chunks (
    id TEXT PRIMARY KEY,
    conversation_id TEXT,
    sequence INTEGER,
    content TEXT NOT NULL,
    char_offset_start INTEGER,
    char_offset_end INTEGER,
    embedding BLOB,
    embedding_dim INTEGER
);

CREATE INDEX IF NOT EXISTS idx_chunks_conversation ON chunks(conversation_id, sequence);

CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
    id UNINDEXED,
    content,
    tokenize='porter unicode61'
);

CREATE VIRTUAL TABLE IF NOT EXISTS chunks_trigram USING fts5(
    id UNINDEXED,
    content,
    tokenize='trigram'
);
"""


_FTS_TOKEN = re.compile(r"\w+", re.UNICODE)


def _safe_fts_query(query: str) -> str:
    tokens = _FTS_TOKEN.findall(query)
    if not tokens:
        return ""
    escaped = [t.replace('"', '""') for t in tokens]
    return " OR ".join(f'"{t}"' for t in escaped)


def _trigram_fts_query(query: str) -> str:
    grams: set[str] = set()
    for word in _FTS_TOKEN.findall(query.lower()):
        if len(word) <= 3:
            grams.add(word)
            continue
        for i in range(len(word) - 2):
            grams.add(word[i : i + 3])
    if not grams:
        return ""
    escaped = [g.replace('"', '""') for g in grams]
    return " OR ".join(f'"{g}"' for g in escaped)


def _vec_to_blob(vec: list[float]) -> bytes:
    return struct.pack(f"{len(vec)}f", *vec)


def _blob_to_vec(blob: bytes) -> list[float]:
    n = len(blob) // 4
    return list(struct.unpack(f"{n}f", blob))


def _cosine(a: list[float], b: list[float]) -> float:
    if len(a) != len(b) or not a:
        return 0.0
    dot = 0.0
    na = 0.0
    nb = 0.0
    for x, y in zip(a, b):
        dot += x * y
        na += x * x
        nb += y * y
    if na == 0.0 or nb == 0.0:
        return 0.0
    return dot / (math.sqrt(na) * math.sqrt(nb))


def _entity_text(entities: list[str]) -> str:
    return " ".join(entities)


class MemoryStore:
    """SQLite-backed memory store with per-thread connections.

    SQLite supports concurrent connections to the same file; each thread
    gets its own connection lazily. This matters because the MCP server
    runs ``remember`` on a background thread (via ``JobQueue``) while
    ``recall`` continues to serve queries on the main thread — sharing a
    single connection across threads would either error
    (``check_same_thread=True``) or race on cursor state.
    """

    def __init__(
        self,
        path: str | Path,
        embedder: Embedder | None = None,
    ):
        self.path = str(path)
        self.embedder = embedder
        self._tls = threading.local()
        # Bootstrap schema on the calling thread; each subsequent thread
        # re-runs CREATE IF NOT EXISTS on first use, which is a no-op.
        self._ensure_connection()

    def _ensure_connection(self) -> sqlite3.Connection:
        conn = getattr(self._tls, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self.path)
            conn.row_factory = sqlite3.Row
            conn.executescript(SCHEMA)
            conn.commit()
            self._tls.conn = conn
        return conn

    @property
    def db(self) -> sqlite3.Connection:
        return self._ensure_connection()

    def close(self) -> None:
        conn = getattr(self._tls, "conn", None)
        if conn is not None:
            conn.close()
            self._tls.conn = None

    def __enter__(self) -> "MemoryStore":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    def add(
        self,
        memories: Iterable[AtomicMemory],
        conversation_id: str | None = None,
    ) -> int:
        cur = self.db.cursor()
        count = 0
        for m in memories:
            ent_text = _entity_text(m.entities)
            blob: bytes | None = None
            dim: int | None = None
            if self.embedder is not None:
                vec = call_document(self.embedder, m.content)
                blob = _vec_to_blob(vec)
                dim = len(vec)
            cur.execute(
                """INSERT OR REPLACE INTO memories
                (id, type, content, entities, source_turn_ids,
                 extracted_at, valid_from, confidence, conversation_id,
                 embedding, embedding_dim)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    m.id,
                    m.type.value,
                    m.content,
                    json.dumps(m.entities),
                    json.dumps(m.source_turn_ids),
                    m.extracted_at.isoformat(),
                    m.valid_from.isoformat() if m.valid_from else None,
                    m.confidence,
                    conversation_id,
                    blob,
                    dim,
                ),
            )
            cur.execute("DELETE FROM memories_fts WHERE id = ?", (m.id,))
            cur.execute(
                "INSERT INTO memories_fts (id, content, entity_text) VALUES (?, ?, ?)",
                (m.id, m.content, ent_text),
            )
            cur.execute("DELETE FROM memories_trigram WHERE id = ?", (m.id,))
            cur.execute(
                "INSERT INTO memories_trigram (id, content, entity_text) VALUES (?, ?, ?)",
                (m.id, m.content, ent_text),
            )
            cur.execute("DELETE FROM supersedes WHERE new_id = ?", (m.id,))
            for old_id in m.supersedes:
                cur.execute(
                    "INSERT OR IGNORE INTO supersedes (new_id, old_id) VALUES (?, ?)",
                    (m.id, old_id),
                )
            count += 1
        self.db.commit()
        return count

    def update_supersedes(
        self, memory_id: str, supersedes: list[str]
    ) -> None:
        """Replace the supersedes links for a memory without touching its
        content or embedding. Use after reconciliation to persist the new
        supersedes set for memories that were already added to the store.
        """
        cur = self.db.cursor()
        cur.execute("DELETE FROM supersedes WHERE new_id = ?", (memory_id,))
        for old_id in supersedes:
            if old_id and old_id != memory_id:
                cur.execute(
                    "INSERT OR IGNORE INTO supersedes (new_id, old_id) VALUES (?, ?)",
                    (memory_id, old_id),
                )
        self.db.commit()

    def delete(self, memory_id: str) -> None:
        cur = self.db.cursor()
        cur.execute("DELETE FROM memories WHERE id = ?", (memory_id,))
        cur.execute("DELETE FROM memories_fts WHERE id = ?", (memory_id,))
        cur.execute("DELETE FROM memories_trigram WHERE id = ?", (memory_id,))
        cur.execute(
            "DELETE FROM supersedes WHERE new_id = ? OR old_id = ?",
            (memory_id, memory_id),
        )
        self.db.commit()

    def get(self, memory_id: str) -> AtomicMemory | None:
        row = self.db.execute(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()
        if row is None:
            return None
        return self._row_to_memory(row)

    def all(self, include_superseded: bool = True) -> list[AtomicMemory]:
        rows = self._filtered_rows("1=1", [], include_superseded, None)
        return [self._row_to_memory(r) for r in rows]

    def by_entity(
        self, entity: str, include_superseded: bool = False
    ) -> list[AtomicMemory]:
        like = f'%"{entity}"%'
        rows = self._filtered_rows(
            "entities LIKE ? COLLATE NOCASE",
            [like],
            include_superseded,
            None,
        )
        return [self._row_to_memory(r) for r in rows]

    def count(self, include_superseded: bool = True) -> int:
        sql = "SELECT COUNT(*) FROM memories"
        if not include_superseded:
            sql += " WHERE id NOT IN (SELECT old_id FROM supersedes)"
        return int(self.db.execute(sql).fetchone()[0])

    def search_keyword(
        self,
        query: str,
        k: int = 10,
        include_superseded: bool = False,
        types: list[MemoryType] | None = None,
    ) -> list[tuple[AtomicMemory, float]]:
        return self._fts_search("memories_fts", query, k, include_superseded, types)

    def search_fuzzy(
        self,
        query: str,
        k: int = 10,
        include_superseded: bool = False,
        types: list[MemoryType] | None = None,
    ) -> list[tuple[AtomicMemory, float]]:
        return self._fts_search(
            "memories_trigram", query, k, include_superseded, types
        )

    def search_vector(
        self,
        query: str | list[float],
        k: int = 10,
        include_superseded: bool = False,
        types: list[MemoryType] | None = None,
    ) -> list[tuple[AtomicMemory, float]]:
        if isinstance(query, str):
            if self.embedder is None:
                raise RuntimeError(
                    "Vector search with a text query requires an embedder."
                )
            qvec = call_query(self.embedder, query)
        else:
            qvec = list(query)
        qdim = len(qvec)

        # Filter to memories whose embedding has the same dim as the query —
        # this is what makes embedder swaps non-fatal: rows from older embedders
        # are simply skipped until reembed_all() migrates them.
        sql = (
            "SELECT * FROM memories WHERE embedding IS NOT NULL "
            "AND embedding_dim = ?"
        )
        params: list = [qdim]
        if not include_superseded:
            sql += " AND id NOT IN (SELECT old_id FROM supersedes)"
        if types:
            placeholders = ",".join("?" * len(types))
            sql += f" AND type IN ({placeholders})"
            params.extend(t.value for t in types)
        rows = self.db.execute(sql, params).fetchall()

        scored: list[tuple[AtomicMemory, float]] = []
        for row in rows:
            score = _cosine(qvec, _blob_to_vec(row["embedding"]))
            scored.append((self._row_to_memory(row), score))
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:k]

    def embedding_dim_counts(self) -> dict[int | None, int]:
        rows = self.db.execute(
            "SELECT embedding_dim, COUNT(*) AS n FROM memories GROUP BY embedding_dim"
        ).fetchall()
        return {row["embedding_dim"]: row["n"] for row in rows}

    def set_embedder(
        self, embedder: Embedder | None, reembed: bool = False
    ) -> int:
        """Swap the embedder. If reembed=True, re-runs every memory through the
        new embedder and rewrites the stored vectors. Returns the number of
        memories re-embedded (0 if reembed=False or embedder is None).
        """
        self.embedder = embedder
        if reembed and embedder is not None:
            return self.reembed_all()
        return 0

    def reembed_all(self, embedder: Embedder | None = None) -> int:
        """Re-embed every memory using ``embedder`` (or self.embedder).
        Overwrites existing embedding blobs and dims. Returns count.
        """
        use = embedder if embedder is not None else self.embedder
        if use is None:
            raise RuntimeError("no embedder set; pass one explicitly or set on the store")
        if embedder is not None:
            self.embedder = embedder
        rows = self.db.execute("SELECT id, content FROM memories").fetchall()
        cur = self.db.cursor()
        count = 0
        for row in rows:
            vec = call_document(use, row["content"])
            cur.execute(
                "UPDATE memories SET embedding = ?, embedding_dim = ? WHERE id = ?",
                (_vec_to_blob(vec), len(vec), row["id"]),
            )
            count += 1
        self.db.commit()
        return count

    # -- Chunk tier (raw text fallback for verbatim recall) --

    def add_chunks(
        self,
        chunks: Iterable[Chunk],
        conversation_id: str | None = None,
        embed_batch_size: int = 8,
        progress: "Callable[[int, int], None] | None" = None,
    ) -> int:
        """Persist raw text chunks alongside atomic memories. Embeds in
        batches to amortize ONNX setup cost — single-call-per-chunk takes
        ~10–30 minutes on a CPU for a Shakespeare-sized corpus; batched it's
        a couple of minutes.

        ``progress(done, total)`` is invoked after each embedding batch and
        after the SQL inserts complete (twice with ``done == total`` total).
        """
        chunks_list = list(chunks)
        total = len(chunks_list)
        if total == 0:
            return 0

        # Phase 1: embed in batches (skipped if no embedder).
        embeddings: list[bytes | None] = [None] * total
        dims: list[int | None] = [None] * total
        if self.embedder is not None:
            for start in range(0, total, embed_batch_size):
                end = min(start + embed_batch_size, total)
                batch_texts = [c.content for c in chunks_list[start:end]]
                vecs = call_documents(self.embedder, batch_texts)
                for i, v in enumerate(vecs):
                    embeddings[start + i] = _vec_to_blob(v)
                    dims[start + i] = len(v)
                if progress is not None:
                    progress(end, total)

        # Phase 2: write all rows in one transaction.
        cur = self.db.cursor()
        for i, c in enumerate(chunks_list):
            cur.execute(
                """INSERT OR REPLACE INTO chunks
                (id, conversation_id, sequence, content,
                 char_offset_start, char_offset_end,
                 embedding, embedding_dim)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    c.id,
                    conversation_id or c.conversation_id,
                    c.sequence,
                    c.content,
                    c.char_offset_start,
                    c.char_offset_end,
                    embeddings[i],
                    dims[i],
                ),
            )
            cur.execute("DELETE FROM chunks_fts WHERE id = ?", (c.id,))
            cur.execute(
                "INSERT INTO chunks_fts (id, content) VALUES (?, ?)",
                (c.id, c.content),
            )
            cur.execute("DELETE FROM chunks_trigram WHERE id = ?", (c.id,))
            cur.execute(
                "INSERT INTO chunks_trigram (id, content) VALUES (?, ?)",
                (c.id, c.content),
            )
        self.db.commit()
        return total

    def chunk_count(self) -> int:
        return int(self.db.execute("SELECT COUNT(*) FROM chunks").fetchone()[0])

    def get_chunk(self, chunk_id: str) -> Chunk | None:
        row = self.db.execute(
            "SELECT * FROM chunks WHERE id = ?", (chunk_id,)
        ).fetchone()
        if row is None:
            return None
        return self._row_to_chunk(row)

    def search_chunks_keyword(
        self, query: str, k: int = 5
    ) -> list[tuple[Chunk, float]]:
        return self._fts_chunk_search("chunks_fts", query, k)

    def search_chunks_fuzzy(
        self, query: str, k: int = 5
    ) -> list[tuple[Chunk, float]]:
        return self._fts_chunk_search("chunks_trigram", query, k)

    def search_chunks_vector(
        self, query: str | list[float], k: int = 5
    ) -> list[tuple[Chunk, float]]:
        if isinstance(query, str):
            if self.embedder is None:
                raise RuntimeError(
                    "Vector chunk search with a text query requires an embedder."
                )
            qvec = call_query(self.embedder, query)
        else:
            qvec = list(query)
        qdim = len(qvec)

        rows = self.db.execute(
            "SELECT * FROM chunks WHERE embedding IS NOT NULL "
            "AND embedding_dim = ?",
            (qdim,),
        ).fetchall()
        scored: list[tuple[Chunk, float]] = []
        for row in rows:
            score = _cosine(qvec, _blob_to_vec(row["embedding"]))
            scored.append((self._row_to_chunk(row), score))
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:k]

    def search_chunks(
        self,
        query: str,
        k: int = 5,
        modes: tuple[SearchMode, ...] = ("keyword", "fuzzy", "vector"),
    ) -> list[tuple[Chunk, float]]:
        per_mode: list[list[tuple[Chunk, float]]] = []
        for mode in modes:
            if mode == "keyword":
                per_mode.append(self.search_chunks_keyword(query, k * 4))
            elif mode == "fuzzy":
                per_mode.append(self.search_chunks_fuzzy(query, k * 4))
            elif mode == "vector":
                if self.embedder is None:
                    continue
                per_mode.append(self.search_chunks_vector(query, k * 4))
        rrf_c = 60.0
        scores: dict[str, float] = {}
        chunk_by_id: dict[str, Chunk] = {}
        for results in per_mode:
            for rank, (c, _) in enumerate(results):
                chunk_by_id[c.id] = c
                scores[c.id] = scores.get(c.id, 0.0) + 1.0 / (rrf_c + rank)
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [(chunk_by_id[cid], s) for cid, s in ranked[:k]]

    def reembed_chunks_all(self, embedder: Embedder | None = None) -> int:
        use = embedder if embedder is not None else self.embedder
        if use is None:
            raise RuntimeError("no embedder set")
        if embedder is not None:
            self.embedder = embedder
        rows = self.db.execute("SELECT id, content FROM chunks").fetchall()
        cur = self.db.cursor()
        count = 0
        for row in rows:
            vec = call_document(use, row["content"])
            cur.execute(
                "UPDATE chunks SET embedding = ?, embedding_dim = ? WHERE id = ?",
                (_vec_to_blob(vec), len(vec), row["id"]),
            )
            count += 1
        self.db.commit()
        return count

    def _fts_chunk_search(
        self, table: str, query: str, k: int
    ) -> list[tuple[Chunk, float]]:
        if table == "chunks_trigram":
            match_query = _trigram_fts_query(query)
        else:
            match_query = _safe_fts_query(query)
        if not match_query:
            return []
        candidates = self.db.execute(
            f"SELECT id, -bm25({table}) AS score FROM {table} "
            f"WHERE {table} MATCH ? ORDER BY score DESC LIMIT ?",
            (match_query, k * 4),
        ).fetchall()
        if not candidates:
            return []
        score_by_id = {row["id"]: row["score"] for row in candidates}
        ids = list(score_by_id.keys())
        rows = self.db.execute(
            f"SELECT * FROM chunks WHERE id IN ({','.join('?' * len(ids))})",
            ids,
        ).fetchall()
        results = [(self._row_to_chunk(r), score_by_id[r["id"]]) for r in rows]
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:k]

    def _row_to_chunk(self, row: sqlite3.Row) -> Chunk:
        return Chunk(
            id=row["id"],
            conversation_id=row["conversation_id"],
            sequence=row["sequence"],
            content=row["content"],
            char_offset_start=row["char_offset_start"],
            char_offset_end=row["char_offset_end"],
        )

    def search(
        self,
        query: str,
        k: int = 10,
        include_superseded: bool = False,
        types: list[MemoryType] | None = None,
        modes: tuple[SearchMode, ...] = ("keyword", "fuzzy", "vector"),
    ) -> list[tuple[AtomicMemory, float]]:
        per_mode: list[list[tuple[AtomicMemory, float]]] = []
        for mode in modes:
            if mode == "keyword":
                per_mode.append(
                    self.search_keyword(query, k * 4, include_superseded, types)
                )
            elif mode == "fuzzy":
                per_mode.append(
                    self.search_fuzzy(query, k * 4, include_superseded, types)
                )
            elif mode == "vector":
                if self.embedder is None:
                    continue
                per_mode.append(
                    self.search_vector(query, k * 4, include_superseded, types)
                )

        # Reciprocal rank fusion — merges rankings without score normalization.
        rrf_c = 60.0
        scores: dict[str, float] = {}
        memory_by_id: dict[str, AtomicMemory] = {}
        for results in per_mode:
            for rank, (mem, _) in enumerate(results):
                memory_by_id[mem.id] = mem
                scores[mem.id] = scores.get(mem.id, 0.0) + 1.0 / (rrf_c + rank)
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [(memory_by_id[mid], s) for mid, s in ranked[:k]]

    def _fts_search(
        self,
        table: str,
        query: str,
        k: int,
        include_superseded: bool,
        types: list[MemoryType] | None,
    ) -> list[tuple[AtomicMemory, float]]:
        if table == "memories_trigram":
            match_query = _trigram_fts_query(query)
        else:
            match_query = _safe_fts_query(query)
        if not match_query:
            return []
        candidates = self.db.execute(
            f"SELECT id, -bm25({table}) AS score FROM {table} "
            f"WHERE {table} MATCH ? ORDER BY score DESC LIMIT ?",
            (match_query, k * 4),
        ).fetchall()
        if not candidates:
            return []
        score_by_id = {row["id"]: row["score"] for row in candidates}
        ids = list(score_by_id.keys())
        rows = self._filtered_rows(
            f"id IN ({','.join('?' * len(ids))})",
            ids,
            include_superseded,
            types,
        )
        results = [(self._row_to_memory(r), score_by_id[r["id"]]) for r in rows]
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:k]

    def _filtered_rows(
        self,
        where: str,
        params: list,
        include_superseded: bool,
        types: list[MemoryType] | None,
    ) -> list[sqlite3.Row]:
        sql = f"SELECT * FROM memories WHERE {where}"
        bind = list(params)
        if not include_superseded:
            sql += " AND id NOT IN (SELECT old_id FROM supersedes)"
        if types:
            placeholders = ",".join("?" * len(types))
            sql += f" AND type IN ({placeholders})"
            bind.extend(t.value for t in types)
        return self.db.execute(sql, bind).fetchall()

    def _row_to_memory(self, row: sqlite3.Row) -> AtomicMemory:
        supersedes = [
            r["old_id"]
            for r in self.db.execute(
                "SELECT old_id FROM supersedes WHERE new_id = ?", (row["id"],)
            ).fetchall()
        ]
        valid_from = (
            datetime.fromisoformat(row["valid_from"])
            if row["valid_from"]
            else None
        )
        return AtomicMemory(
            id=row["id"],
            type=MemoryType(row["type"]),
            content=row["content"],
            entities=json.loads(row["entities"]),
            source_turn_ids=json.loads(row["source_turn_ids"]),
            extracted_at=datetime.fromisoformat(row["extracted_at"]),
            valid_from=valid_from,
            confidence=row["confidence"],
            supersedes=supersedes,
        )
