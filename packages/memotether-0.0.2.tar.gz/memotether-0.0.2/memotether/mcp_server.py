from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
from pathlib import Path

from importlib.resources import files

from dotenv import load_dotenv
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    GetPromptResult,
    Prompt,
    PromptMessage,
    TextContent,
    Tool,
)

from memotether import Memotether

_AGENT_PROMPT_NAME = "memotether-system"
_AGENT_PROMPT_FILE = "agent_system.md"
_AGENT_PROMPT_DESCRIPTION = (
    "System-prompt fragment that teaches the model to use Memotether's memory "
    "tools ambiently. Insert at the start of a session."
)

logger = logging.getLogger("memotether.mcp")


# Defaults applied at MCP boot so a fresh install only needs OPENROUTER_API_KEY.
# Extractor itself stays defaultless (per CLAUDE.md); these are user-facing.
_ENV_DEFAULTS = {
    "MEMOTETHER_BASE_URL": "https://openrouter.ai/api/v1",
    "MEMOTETHER_MODEL": "qwen/qwen3.6-flash",
    "MEMOTETHER_MAX_CHUNK_CHARS": "16000",
}


def _apply_env_defaults() -> None:
    for k, v in _ENV_DEFAULTS.items():
        os.environ.setdefault(k, v)


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="memotether",
        description="MCP server exposing Memotether memory tools over stdio.",
    )
    p.add_argument(
        "--db",
        default=None,
        help="SQLite path (overrides $MEMOTETHER_DB_PATH).",
    )
    p.add_argument(
        "--embedder",
        default=None,
        help="Embedder spec: 'none', 'nomic', 'openai', "
        "'nomic:<model>', 'openai:<model>' (overrides $MEMOTETHER_EMBEDDER).",
    )
    p.add_argument(
        "--conversation",
        default=None,
        help="Default conversation_id for remember() (overrides $MEMOTETHER_CONVERSATION).",
    )
    return p.parse_args(argv)


def _resolve_db_path(cli_value: str | None) -> Path:
    raw = cli_value or os.environ.get(
        "MEMOTETHER_DB_PATH",
        str(Path.home() / ".memotether" / "memories.db"),
    )
    path = Path(os.path.expanduser(raw))
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _resolve_embedder_spec(cli_value: str | None) -> str | None:
    spec = cli_value or os.environ.get("MEMOTETHER_EMBEDDER", "nomic")
    if spec.lower() == "none":
        return None
    return spec


def _resolve_conversation(cli_value: str | None) -> str:
    return cli_value or os.environ.get("MEMOTETHER_CONVERSATION", "default")


async def main(argv: list[str] | None = None) -> None:
    load_dotenv()
    _apply_env_defaults()
    logging.basicConfig(level=logging.INFO, stream=sys.stderr)

    args = _parse_args(argv)
    db_path = _resolve_db_path(args.db)
    embedder_spec = _resolve_embedder_spec(args.embedder)
    default_conversation = _resolve_conversation(args.conversation)

    mt = Memotether.from_env(db_path, embedder=embedder_spec)
    logger.info(
        "Memotether MCP up: db=%s memories=%d chunks=%d embedder=%s conversation=%s",
        db_path,
        mt.store.count(),
        mt.store.chunk_count(),
        embedder_spec,
        default_conversation,
    )

    server: Server = Server("memotether")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name=t["function"]["name"],
                description=t["function"]["description"],
                inputSchema=t["function"]["parameters"],
            )
            for t in mt.tools
        ]

    @server.list_prompts()
    async def list_prompts() -> list[Prompt]:
        return [
            Prompt(
                name=_AGENT_PROMPT_NAME,
                description=_AGENT_PROMPT_DESCRIPTION,
                arguments=[],
            )
        ]

    @server.get_prompt()
    async def get_prompt(name: str, arguments: dict | None = None) -> GetPromptResult:
        if name != _AGENT_PROMPT_NAME:
            raise ValueError(f"unknown prompt: {name!r}")
        text = files("memotether.prompts").joinpath(_AGENT_PROMPT_FILE).read_text(encoding="utf-8")
        return GetPromptResult(
            description=_AGENT_PROMPT_DESCRIPTION,
            messages=[
                PromptMessage(role="user", content=TextContent(type="text", text=text))
            ],
        )

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        try:
            if name == "remember" and "conversation_id" not in arguments:
                arguments = {**arguments, "conversation_id": default_conversation}
            # Run dispatch on a worker thread so blocking I/O (LLM calls,
            # SQLite writes, embedding) doesn't stall the MCP event loop —
            # otherwise concurrent tool calls (e.g. recall while a
            # background remember is running) queue behind each other.
            result = await asyncio.to_thread(mt.dispatch, name, arguments)
        except Exception as e:
            logger.exception("tool %s failed", name)
            result = {"error": str(e), "type": type(e).__name__}
        return [TextContent(type="text", text=json.dumps(result, default=str))]

    try:
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )
    finally:
        mt.close()


def run() -> None:
    asyncio.run(main())


if __name__ == "__main__":
    run()
