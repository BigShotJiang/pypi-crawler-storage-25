"""Wire memotether into MCP host configurations.

Currently only opencode is supported. The function reads the host's existing
config (if any), splices in a minimal ``mcp.memotether`` entry, and writes it
back. Anything else the user already had in the file is preserved.

The entry is intentionally minimal: with the boot-time env defaults in
``mcp_server.py``, ``OPENROUTER_API_KEY`` is the only var the user has to
supply, and that's expected to live in their shell environment (which
opencode's child processes inherit) — not in the JSON config.
"""

from __future__ import annotations

import json
import os
import shutil
import sys
from importlib.resources import files
from pathlib import Path
from typing import Any


_OPENCODE_GLOBAL_CONFIG = Path("~/.config/opencode/opencode.json").expanduser()
_OPENCODE_SCHEMA = "https://opencode.ai/config.json"


def _load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise SystemExit(f"existing config at {path} is not valid JSON: {e}")
    if not isinstance(data, dict):
        raise SystemExit(f"existing config at {path} is not a JSON object")
    return data


def _resolve_command(uvx: bool) -> list[str]:
    if uvx:
        return ["uvx", "--from", "memotether[local-embed]", "memotether-mcp"]
    found = shutil.which("memotether-mcp")
    if not found:
        raise SystemExit(
            "memotether-mcp is not on PATH. Either run "
            "`pipx install \"memotether[local-embed]\"` first, or rerun this "
            "command with --uvx to use uvx instead."
        )
    return [found]


def install_opencode(
    *,
    scope: str = "global",
    db_path: str | None = None,
    name: str = "memotether",
    uvx: bool = False,
) -> Path:
    if scope == "global":
        config_path = _OPENCODE_GLOBAL_CONFIG
    elif scope == "project":
        config_path = (Path.cwd() / "opencode.json").resolve()
    else:
        raise ValueError(f"unknown scope: {scope!r}")

    config = _load_json(config_path)
    config.setdefault("$schema", _OPENCODE_SCHEMA)
    mcp = config.setdefault("mcp", {})
    if not isinstance(mcp, dict):
        raise SystemExit(f"'mcp' field in {config_path} is not an object")

    entry: dict[str, Any] = {
        "type": "local",
        "command": _resolve_command(uvx),
        "enabled": True,
    }
    if db_path:
        entry["environment"] = {
            "MEMOTETHER_DB_PATH": str(Path(db_path).expanduser().resolve())
        }
    mcp[name] = entry

    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")

    if scope == "project":
        _drop_agents_md(Path.cwd() / "AGENTS.md")

    if not os.environ.get("OPENROUTER_API_KEY"):
        sys.stderr.write(
            "warning: OPENROUTER_API_KEY is not set in this shell. Add it to "
            "your shell rc (e.g. ~/.zshrc) so opencode child processes "
            "inherit it.\n"
        )

    return config_path


def _drop_agents_md(target: Path) -> None:
    if target.exists():
        sys.stderr.write(
            f"note: {target} already exists; not overwriting. Run "
            "`memotether prompt >> AGENTS.md` to append the memotether agent "
            "prompt.\n"
        )
        return
    text = (
        files("memotether.prompts")
        .joinpath("agent_system.md")
        .read_text(encoding="utf-8")
    )
    target.write_text(text, encoding="utf-8")
