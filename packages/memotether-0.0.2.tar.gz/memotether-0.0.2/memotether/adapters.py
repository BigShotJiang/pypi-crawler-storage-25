import json
from typing import Any

Provider = str  # "openai" | "openrouter" | "anthropic" | "gemini"


_GEMINI_TYPE_MAP = {
    "string": "STRING",
    "object": "OBJECT",
    "array": "ARRAY",
    "integer": "INTEGER",
    "number": "NUMBER",
    "boolean": "BOOLEAN",
    "null": "NULL",
}


def _attr_or_key(obj: Any, key: str, default: Any = None) -> Any:
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _normalize_provider(provider: Provider) -> str:
    p = provider.lower()
    if p not in ("openai", "openrouter", "anthropic", "gemini"):
        raise ValueError(f"unknown provider: {provider!r}")
    return p


def to_anthropic(openai_tool: dict[str, Any]) -> dict[str, Any]:
    fn = openai_tool["function"]
    return {
        "name": fn["name"],
        "description": fn.get("description", ""),
        "input_schema": fn.get("parameters", {"type": "object", "properties": {}}),
    }


def _jsonschema_to_gemini(schema: Any) -> Any:
    if not isinstance(schema, dict):
        return schema
    out: dict[str, Any] = {}
    for k, v in schema.items():
        if k == "additionalProperties":
            continue
        if k == "type" and isinstance(v, str):
            out[k] = _GEMINI_TYPE_MAP.get(v.lower(), v.upper())
        elif k == "properties" and isinstance(v, dict):
            out[k] = {pk: _jsonschema_to_gemini(pv) for pk, pv in v.items()}
        elif k == "items" and isinstance(v, dict):
            out[k] = _jsonschema_to_gemini(v)
        elif k in ("anyOf", "oneOf", "allOf") and isinstance(v, list):
            out[k] = [_jsonschema_to_gemini(s) for s in v]
        else:
            out[k] = v
    return out


def to_gemini(openai_tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Wrap all declarations in a single Tool object, matching what
    ``google-genai`` expects for ``tools=[...]``.
    """
    decls: list[dict[str, Any]] = []
    for t in openai_tools:
        fn = t["function"]
        decls.append(
            {
                "name": fn["name"],
                "description": fn.get("description", ""),
                "parameters": _jsonschema_to_gemini(
                    fn.get("parameters", {"type": "object", "properties": {}})
                ),
            }
        )
    return [{"function_declarations": decls}]


def tools_for(
    provider: Provider, openai_tools: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    p = _normalize_provider(provider)
    if p in ("openai", "openrouter"):
        return openai_tools
    if p == "anthropic":
        return [to_anthropic(t) for t in openai_tools]
    return to_gemini(openai_tools)


def parse_call(provider: Provider, raw: Any) -> tuple[str, dict[str, Any]]:
    """Extract ``(name, args_dict)`` from a provider's tool-call object.

    Accepts both SDK objects (attribute access) and plain dicts.
    """
    p = _normalize_provider(provider)
    if p in ("openai", "openrouter"):
        fn = _attr_or_key(raw, "function")
        if fn is None:
            raise ValueError("OpenAI tool call missing 'function'")
        name = _attr_or_key(fn, "name")
        args = _attr_or_key(fn, "arguments")
        if isinstance(args, str):
            args = json.loads(args) if args else {}
        elif args is None:
            args = {}
        return name, args
    if p == "anthropic":
        name = _attr_or_key(raw, "name")
        args = _attr_or_key(raw, "input")
        if args is None:
            args = {}
        elif isinstance(args, str):
            args = json.loads(args) if args else {}
        return name, args
    # gemini
    fc = _attr_or_key(raw, "function_call")
    if fc is None:
        fc = raw
    name = _attr_or_key(fc, "name")
    args = _attr_or_key(fc, "args")
    if args is None:
        args = {}
    elif isinstance(args, str):
        args = json.loads(args) if args else {}
    elif not isinstance(args, dict) and hasattr(args, "items"):
        args = dict(args)
    return name, args


def format_result(provider: Provider, call: Any, result: Any) -> dict[str, Any]:
    """Format a dispatch result as a message ready to append to the
    provider's conversation history.

    ``call`` may be the original tool-call object or its id/name as a
    string. For OpenAI/Anthropic the id is used; for Gemini the function
    name is used.
    """
    p = _normalize_provider(provider)
    if p in ("openai", "openrouter"):
        call_id = call if isinstance(call, str) else _attr_or_key(call, "id")
        content = result if isinstance(result, str) else json.dumps(result)
        return {
            "role": "tool",
            "tool_call_id": call_id,
            "content": content,
        }
    if p == "anthropic":
        use_id = call if isinstance(call, str) else _attr_or_key(call, "id")
        content = result if isinstance(result, str) else json.dumps(result)
        return {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": use_id,
                    "content": content,
                }
            ],
        }
    # gemini
    if isinstance(call, str):
        name = call
    else:
        name = _attr_or_key(call, "name")
        if name is None:
            fc = _attr_or_key(call, "function_call")
            name = _attr_or_key(fc, "name") if fc is not None else None
    response = result if isinstance(result, dict) else {"result": result}
    return {
        "role": "function",
        "parts": [
            {
                "function_response": {
                    "name": name,
                    "response": response,
                }
            }
        ],
    }
