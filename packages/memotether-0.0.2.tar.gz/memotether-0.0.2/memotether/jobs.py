"""Background job queue for fire-and-forget tool calls.

The MCP integration calls ``remember`` while the user is mid-conversation,
and extraction is slow (multiple LLM calls per chunk + reconciliation).
``JobQueue`` lets the tool method return a ``job_id`` immediately and run
the actual work on a background thread, so the agent isn't blocked waiting
for a multi-second LLM round trip before it can answer the user.

Status is tracked in-memory; jobs are not persisted across restarts. That's
intentional — extraction is idempotent enough that "lost" jobs can be
re-submitted by re-running ``remember`` with the same text.
"""

from __future__ import annotations

import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Callable
from uuid import uuid4


JobStatus = str  # "queued" | "running" | "completed" | "failed"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class JobQueue:
    """Tracks fire-and-forget jobs run on a thread pool. Submission returns
    immediately; results land in ``self._jobs`` when the work finishes.

    ``max_workers=1`` (the default) serializes jobs, which is the right
    choice for ``remember`` against a single SQLite file — concurrent writes
    would contend on the same connection. Bump it if your workload uses
    independent stores or you've moved off SQLite.
    """

    def __init__(self, max_workers: int = 1, max_history: int = 256):
        self._executor = ThreadPoolExecutor(
            max_workers=max_workers,
            thread_name_prefix="memotether-job",
        )
        self._jobs: dict[str, dict[str, Any]] = {}
        self._lock = threading.Lock()
        self._max_history = max_history
        self._closed = False

    def submit(
        self,
        fn: Callable[..., Any],
        *args: Any,
        label: str | None = None,
        **kwargs: Any,
    ) -> str:
        if self._closed:
            raise RuntimeError("JobQueue is closed")
        job_id = str(uuid4())
        with self._lock:
            self._jobs[job_id] = {
                "id": job_id,
                "label": label,
                "status": "queued",
                "submitted_at": _now_iso(),
            }
            self._evict_old_entries_locked()
        self._executor.submit(self._run, job_id, fn, args, kwargs)
        return job_id

    def _run(
        self,
        job_id: str,
        fn: Callable[..., Any],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> None:
        with self._lock:
            entry = self._jobs.get(job_id)
            if entry is not None:
                entry["status"] = "running"
                entry["started_at"] = _now_iso()
        try:
            result = fn(*args, **kwargs)
        except Exception as e:
            with self._lock:
                entry = self._jobs.get(job_id)
                if entry is not None:
                    entry["status"] = "failed"
                    entry["error"] = str(e)
                    entry["error_type"] = type(e).__name__
                    entry["finished_at"] = _now_iso()
            return
        with self._lock:
            entry = self._jobs.get(job_id)
            if entry is not None:
                entry["status"] = "completed"
                entry["result"] = result
                entry["finished_at"] = _now_iso()

    def status(self, job_id: str) -> dict[str, Any] | None:
        with self._lock:
            entry = self._jobs.get(job_id)
            if entry is None:
                return None
            return dict(entry)

    def counts(self) -> dict[str, int]:
        out = {"queued": 0, "running": 0, "completed": 0, "failed": 0}
        with self._lock:
            for entry in self._jobs.values():
                status = entry.get("status", "queued")
                if status in out:
                    out[status] += 1
        return out

    def list_recent(self, limit: int = 20) -> list[dict[str, Any]]:
        """Return the most recently submitted jobs (newest first)."""
        with self._lock:
            entries = sorted(
                self._jobs.values(),
                key=lambda e: e.get("submitted_at", ""),
                reverse=True,
            )
            return [dict(e) for e in entries[:limit]]

    def shutdown(self, wait: bool = True) -> None:
        if self._closed:
            return
        self._closed = True
        self._executor.shutdown(wait=wait)

    def _evict_old_entries_locked(self) -> None:
        if len(self._jobs) <= self._max_history:
            return
        # Drop the oldest TERMINAL entries first; keep queued/running.
        terminal = [
            (eid, e.get("submitted_at", ""))
            for eid, e in self._jobs.items()
            if e.get("status") in ("completed", "failed")
        ]
        terminal.sort(key=lambda x: x[1])
        excess = len(self._jobs) - self._max_history
        for eid, _ in terminal[:excess]:
            self._jobs.pop(eid, None)
