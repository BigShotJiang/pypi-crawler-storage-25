import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from memotether.adapters import (
    format_result as _adapter_format_result,
)
from memotether.adapters import (
    parse_call as _adapter_parse_call,
)
from memotether.adapters import (
    tools_for as _adapter_tools_for,
)
from memotether.embedders import Embedder, resolve_embedder
from memotether.extractor import Extractor
from memotether.jobs import JobQueue
from memotether.schema import AtomicMemory, Chunk, MemoryType
from memotether.store import MemoryStore


def _memory_to_dict(m: AtomicMemory) -> dict[str, Any]:
    return {
        "id": m.id,
        "type": m.type.value,
        "content": m.content,
        "entities": m.entities,
        "confidence": m.confidence,
        "supersedes": m.supersedes,
    }


def _chunk_to_dict(c: Chunk) -> dict[str, Any]:
    return {
        "id": c.id,
        "sequence": c.sequence,
        "content": c.content,
        "conversation_id": c.conversation_id,
    }


class Memotether:
    """Memory-layer tool. Wraps extraction and storage behind a small set of
    methods designed for OpenAI-compatible tool calling.

    Typical wiring with the OpenAI SDK::

        mt = Memotether.from_env("memories.db")
        resp = client.chat.completions.create(
            model=..., messages=..., tools=mt.tools,
        )
        for call in resp.choices[0].message.tool_calls or []:
            args = json.loads(call.function.arguments)
            result = mt.dispatch(call.function.name, args)
            # send json.dumps(result) back as the tool message
    """

    def __init__(
        self,
        db_path: str | Path,
        *,
        model: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        max_chunk_chars: int | None = None,
        reconcile: bool = True,
        reconcile_model: str | None = None,
        reconcile_group_size: int = 30,
        cache_system_prompt: bool = True,
        concurrency: int = 1,
        embedder: str | Embedder | None = None,
    ):
        self._extractor_config: dict[str, Any] = {
            "model": model,
            "api_key": api_key,
            "base_url": base_url,
            "max_chunk_chars": max_chunk_chars,
            "concurrency": concurrency,
            "reconcile": reconcile,
            "reconcile_model": reconcile_model,
            "reconcile_group_size": reconcile_group_size,
            "cache_system_prompt": cache_system_prompt,
        }
        self._extractor: Extractor | None = None
        self.store = MemoryStore(db_path, embedder=resolve_embedder(embedder))
        self._job_queue: JobQueue | None = None

    @property
    def extractor(self) -> Extractor:
        if self._extractor is None:
            cfg = self._extractor_config
            missing = [
                k for k in ("model", "api_key", "base_url", "max_chunk_chars")
                if cfg.get(k) is None
            ]
            if missing:
                raise RuntimeError(
                    "Memotether extractor is not configured (missing: "
                    f"{', '.join(missing)}). Set MEMOTETHER_MODEL, "
                    "OPENROUTER_API_KEY, MEMOTETHER_BASE_URL, and "
                    "MEMOTETHER_MAX_CHUNK_CHARS to enable remember()."
                )
            self._extractor = Extractor(**cfg)
        return self._extractor

    @classmethod
    def from_env(
        cls,
        db_path: str | Path,
        *,
        embedder: str | Embedder | None = None,
        **overrides: Any,
    ) -> "Memotether":
        chunk_chars = os.environ.get("MEMOTETHER_MAX_CHUNK_CHARS")
        config: dict[str, Any] = {
            "model": os.environ.get("MEMOTETHER_MODEL"),
            "api_key": os.environ.get("OPENROUTER_API_KEY"),
            "base_url": os.environ.get("MEMOTETHER_BASE_URL"),
            "max_chunk_chars": int(chunk_chars) if chunk_chars else None,
            "reconcile_model": os.environ.get("MEMOTETHER_RECONCILE_MODEL"),
        }
        config.update(overrides)
        return cls(db_path, embedder=embedder, **config)

    def close(self) -> None:
        if self._job_queue is not None:
            self._job_queue.shutdown(wait=True)
            self._job_queue = None
        self.store.close()

    def _ensure_jobs(self) -> JobQueue:
        if self._job_queue is None:
            self._job_queue = JobQueue(max_workers=1)
        return self._job_queue

    def __enter__(self) -> "Memotether":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    def remember(
        self,
        text: str,
        conversation_id: str = "default",
        store_chunks: bool = True,
    ) -> dict[str, Any]:
        """Extract atomic memories AND (by default) persist the raw chunks
        used by the extractor. The chunks are stored in a parallel tier so
        ``recall`` can fall back to verbatim text when memories are
        insufficient. Set ``store_chunks=False`` to skip the verbatim tier.
        """
        result = self.extractor.extract(text, conversation_id=conversation_id)
        self.store.add(result.memories, conversation_id=conversation_id)

        chunk_count = 0
        if store_chunks:
            planned = self.extractor.plan_chunks(text)
            chunks: list[Chunk] = []
            offset = 0
            for i, turn_list in enumerate(planned):
                raw = "\n\n".join(t.content for t in turn_list)
                chunk = Chunk(
                    id=f"{conversation_id}:chunk:{i:04d}",
                    conversation_id=conversation_id,
                    sequence=i,
                    content=raw,
                    char_offset_start=offset,
                    char_offset_end=offset + len(raw),
                )
                offset += len(raw)
                chunks.append(chunk)
            chunk_count = self.store.add_chunks(
                chunks, conversation_id=conversation_id
            )

        return {
            "stored": len(result.memories),
            "chunks_stored": chunk_count,
            "conversation_id": conversation_id,
            "memories": [_memory_to_dict(m) for m in result.memories],
        }

    def remember_async(
        self,
        text: str,
        conversation_id: str = "default",
        store_chunks: bool = True,
    ) -> dict[str, Any]:
        """Submit a remember() job to the background queue and return
        immediately with a ``job_id``. The agent should treat this as
        fire-and-forget; use ``job_status(job_id)`` only if you need to
        confirm completion. Extraction can take many seconds (multiple LLM
        calls), so blocking the agent on it is a poor UX in MCP contexts.
        """
        queue = self._ensure_jobs()
        job_id = queue.submit(
            self.remember,
            text,
            conversation_id=conversation_id,
            store_chunks=store_chunks,
            label=f"remember:{conversation_id}",
        )
        return {
            "job_id": job_id,
            "status": "queued",
            "conversation_id": conversation_id,
            "queued_at": datetime.now(timezone.utc).isoformat(),
        }

    def job_status(self, job_id: str) -> dict[str, Any]:
        """Inspect a background job submitted via ``remember_async``.

        For completed jobs the returned ``result`` is slimmed to
        ``stored``/``chunks_stored``/``conversation_id`` — the full memory
        list is dropped so the agent doesn't blow up its context polling.
        """
        if self._job_queue is None:
            return {"status": "unknown", "reason": "no_jobs_submitted", "id": job_id}
        entry = self._job_queue.status(job_id)
        if entry is None:
            return {"status": "unknown", "reason": "not_found", "id": job_id}
        result = entry.get("result")
        if isinstance(result, dict):
            entry["result"] = {
                "stored": result.get("stored"),
                "chunks_stored": result.get("chunks_stored"),
                "conversation_id": result.get("conversation_id"),
            }
        return entry

    def recall(
        self,
        query: str,
        k: int = 10,
        mode: str = "hybrid",
        types: list[str] | None = None,
        include_superseded: bool = False,
        tier: str = "memories",
        chunk_k: int | None = None,
    ) -> dict[str, Any]:
        """Retrieve from the memory tier, the chunk tier, or both.

        ``tier`` options:
          - "memories" (default): atomic memory tier only.
          - "chunks": raw chunk tier only — verbatim text recall.
          - "both": memory tier first, plus chunks (a default of k//2 chunks
            unless ``chunk_k`` is given) for verbatim fallback context.
        """
        if tier not in ("memories", "chunks", "both"):
            raise ValueError(f"unknown tier: {tier!r}")
        type_filter = [MemoryType(t) for t in types] if types else None

        memories: list[tuple[AtomicMemory, float]] = []
        chunks: list[tuple[Chunk, float]] = []

        if tier in ("memories", "both"):
            mem_kwargs: dict[str, Any] = {
                "k": k,
                "include_superseded": include_superseded,
                "types": type_filter,
            }
            if mode == "keyword":
                memories = self.store.search_keyword(query, **mem_kwargs)
            elif mode == "fuzzy":
                memories = self.store.search_fuzzy(query, **mem_kwargs)
            elif mode == "vector":
                memories = self.store.search_vector(query, **mem_kwargs)
            elif mode == "hybrid":
                memories = self.store.search(query, **mem_kwargs)
            else:
                raise ValueError(f"unknown mode: {mode!r}")

        if tier in ("chunks", "both"):
            ck = chunk_k if chunk_k is not None else max(1, k // 2)
            if mode == "keyword":
                chunks = self.store.search_chunks_keyword(query, k=ck)
            elif mode == "fuzzy":
                chunks = self.store.search_chunks_fuzzy(query, k=ck)
            elif mode == "vector":
                chunks = self.store.search_chunks_vector(query, k=ck)
            elif mode == "hybrid":
                chunks = self.store.search_chunks(query, k=ck)
            else:
                raise ValueError(f"unknown mode: {mode!r}")

        return {
            "query": query,
            "mode": mode,
            "tier": tier,
            "memory_count": len(memories),
            "chunk_count": len(chunks),
            "memories": [
                {**_memory_to_dict(m), "score": score} for m, score in memories
            ],
            "chunks": [
                {**_chunk_to_dict(c), "score": score} for c, score in chunks
            ],
        }

    def forget(self, memory_id: str) -> dict[str, Any]:
        existing = self.store.get(memory_id)
        if existing is None:
            return {"deleted": False, "reason": "not_found", "id": memory_id}
        self.store.delete(memory_id)
        return {"deleted": True, "id": memory_id}

    def list_by_entity(
        self, entity: str, include_superseded: bool = False
    ) -> dict[str, Any]:
        results = self.store.by_entity(
            entity, include_superseded=include_superseded
        )
        return {
            "entity": entity,
            "count": len(results),
            "memories": [_memory_to_dict(m) for m in results],
        }

    def stats(self) -> dict[str, Any]:
        total = self.store.count(include_superseded=True)
        active = self.store.count(include_superseded=False)
        dim_counts = {
            ("none" if k is None else str(k)): v
            for k, v in self.store.embedding_dim_counts().items()
        }
        out: dict[str, Any] = {
            "total": total,
            "active": active,
            "superseded": total - active,
            "chunks": self.store.chunk_count(),
            "embedding_dims": dim_counts,
        }
        if self._job_queue is not None:
            out["jobs"] = self._job_queue.counts()
        return out

    def set_embedder(
        self, embedder: str | Embedder | None, reembed: bool = True
    ) -> dict[str, Any]:
        """Swap the embedder. By default, re-embeds every stored memory so
        vector search keeps working after a dim change. Set reembed=False if
        you only want to wire a new embedder without rewriting blobs.
        """
        resolved = resolve_embedder(embedder)
        n = self.store.set_embedder(resolved, reembed=reembed)
        sample_dim: int | None = None
        if resolved is not None:
            try:
                sample_dim = len(resolved("dim probe"))
            except Exception:
                sample_dim = None
        return {
            "embedder_set": resolved is not None,
            "reembedded": n,
            "embedding_dim": sample_dim,
        }

    def reembed(
        self, embedder: str | Embedder | None = None
    ) -> dict[str, Any]:
        """Re-embed every memory using ``embedder`` (or the current one)."""
        resolved = resolve_embedder(embedder) if embedder is not None else None
        n = self.store.reembed_all(embedder=resolved)
        return {"reembedded": n}

    @property
    def tools(self) -> list[dict[str, Any]]:
        return TOOL_SCHEMAS

    def tools_for(self, provider: str) -> list[dict[str, Any]]:
        """Return tool schemas in the given provider's format.

        Supported: ``openai`` / ``openrouter`` (canonical), ``anthropic``,
        ``gemini``. Gemini returns a single Tool object wrapping all
        function declarations, matching ``google-genai``'s expected shape.
        """
        return _adapter_tools_for(provider, self.tools)

    def parse_call(
        self, provider: str, raw: Any
    ) -> tuple[str, dict[str, Any]]:
        """Extract ``(name, args)`` from a provider's tool-call object.

        Pass the result straight to :meth:`dispatch`. Accepts SDK objects
        (attribute access) or plain dicts.
        """
        return _adapter_parse_call(provider, raw)

    def format_result(
        self, provider: str, call: Any, result: Any
    ) -> dict[str, Any]:
        """Format a dispatch result as a message ready to append to the
        provider's conversation history. ``call`` may be the original
        tool-call object or its id/name as a string.
        """
        return _adapter_format_result(provider, call, result)

    def dispatch(
        self, name: str, args: dict[str, Any] | str | None = None
    ) -> dict[str, Any]:
        if isinstance(args, str):
            args = json.loads(args) if args else {}
        if args is None:
            args = {}
        method = _DISPATCH.get(name)
        if method is None:
            raise ValueError(f"unknown tool: {name!r}")
        return method(self, **args)


TOOL_SCHEMAS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "remember",
            "description": (
                "Submit text for atomic-memory extraction and persistence. "
                "Returns a job_id immediately; extraction runs on a background "
                "thread (multiple LLM calls — typically several seconds). "
                "Treat as fire-and-forget: do NOT poll job_status unless you "
                "specifically need to confirm completion before answering. "
                "Use when the user shares facts, preferences, events, "
                "relationships, decisions, bugs, or procedures worth recalling "
                "later. Multi-turn input may use [turn:<id>] (role): markers."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "Raw text or conversation transcript.",
                    },
                    "conversation_id": {
                        "type": "string",
                        "description": "Optional tag for grouping memories.",
                    },
                },
                "required": ["text"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "job_status",
            "description": (
                "Check the status of a background remember() job. Returns "
                "{status: queued|running|completed|failed, ...}. The completed "
                "result is slimmed to counts (no memory list) — use recall to "
                "retrieve actual memories. Call sparingly: remember is meant "
                "to be fire-and-forget."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "job_id": {
                        "type": "string",
                        "description": "Job id returned by remember().",
                    }
                },
                "required": ["job_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "recall",
            "description": (
                "Search stored memories. Use to retrieve facts, preferences, or "
                "prior context relevant to the current task. Returns ranked "
                "memories with ids and scores."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query (keywords or natural language).",
                    },
                    "k": {
                        "type": "integer",
                        "description": "Max results (default 10).",
                    },
                    "mode": {
                        "type": "string",
                        "enum": ["keyword", "fuzzy", "vector", "hybrid"],
                        "description": (
                            "'keyword' = stemmed exact match, 'fuzzy' = typo-tolerant, "
                            "'vector' = semantic (requires embedder), "
                            "'hybrid' (default) combines all available modes."
                        ),
                    },
                    "types": {
                        "type": "array",
                        "items": {
                            "type": "string",
                            "enum": [t.value for t in MemoryType],
                        },
                        "description": "Optional filter by memory type.",
                    },
                    "include_superseded": {
                        "type": "boolean",
                        "description": "Include memories invalidated by newer ones (default false).",
                    },
                    "tier": {
                        "type": "string",
                        "enum": ["memories", "chunks", "both"],
                        "description": (
                            "'memories' (default) = compressed atomic memory tier. "
                            "'chunks' = raw source-text tier for verbatim recall. "
                            "'both' = memory tier plus chunk fallback context, "
                            "useful when the question targets specific phrasings or "
                            "obscure details that may not have survived extraction."
                        ),
                    },
                    "chunk_k": {
                        "type": "integer",
                        "description": "Max chunks to return when tier is 'chunks' or 'both' (default k//2).",
                    },
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "forget",
            "description": "Delete a single memory by id.",
            "parameters": {
                "type": "object",
                "properties": {
                    "memory_id": {
                        "type": "string",
                        "description": "Id of the memory to delete.",
                    }
                },
                "required": ["memory_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_by_entity",
            "description": (
                "List all memories that mention a specific entity (person, "
                "project, technology, etc.). Case-insensitive match."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "entity": {
                        "type": "string",
                        "description": "Entity name to look up.",
                    },
                    "include_superseded": {"type": "boolean"},
                },
                "required": ["entity"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "stats",
            "description": "Return the size of the memory store (total / active / superseded).",
            "parameters": {"type": "object", "properties": {}},
        },
    },
]


_DISPATCH: dict[str, Callable[..., dict[str, Any]]] = {
    "remember": Memotether.remember_async,
    "job_status": Memotether.job_status,
    "recall": Memotether.recall,
    "forget": Memotether.forget,
    "list_by_entity": Memotether.list_by_entity,
    "stats": Memotether.stats,
}
