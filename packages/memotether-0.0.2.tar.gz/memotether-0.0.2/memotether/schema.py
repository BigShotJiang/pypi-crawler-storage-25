from datetime import datetime, timezone
from enum import Enum
from uuid import uuid4

from pydantic import BaseModel, Field


class MemoryType(str, Enum):
    FACT = "fact"
    PREFERENCE = "preference"
    EVENT = "event"
    RELATIONSHIP = "relationship"
    PROCEDURE = "procedure"
    OPEN_QUESTION = "open_question"
    QUOTE = "quote"
    # Coding-mode types. These coexist with the conversational types so a
    # single store can hold both kinds of memory; the active extraction
    # prompt determines which the LLM is encouraged to emit.
    CODE_DECISION = "code_decision"
    BUG = "bug"
    API_CONTRACT = "api_contract"
    REQUIREMENT = "requirement"
    TODO = "todo"


class Chunk(BaseModel):
    """Raw text chunk from the source corpus, persisted alongside atomic
    memories for verbatim recall when the lossy memory layer doesn't carry
    enough signal.
    """

    id: str
    conversation_id: str | None = None
    sequence: int
    content: str
    char_offset_start: int | None = None
    char_offset_end: int | None = None


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _new_id() -> str:
    return str(uuid4())


class ConversationTurn(BaseModel):
    id: str
    role: str
    content: str
    timestamp: datetime | None = None


class AtomicMemory(BaseModel):
    id: str = Field(default_factory=_new_id)
    type: MemoryType
    content: str
    entities: list[str] = Field(default_factory=list)
    source_turn_ids: list[str] = Field(default_factory=list)
    extracted_at: datetime = Field(default_factory=_now)
    valid_from: datetime | None = None
    confidence: float = 1.0
    supersedes: list[str] = Field(default_factory=list)


class ExtractionResult(BaseModel):
    memories: list[AtomicMemory]
    conversation_id: str
    processed_turn_ids: list[str]
