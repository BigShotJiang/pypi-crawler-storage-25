import json
import random
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from importlib.resources import files
from typing import Any, Callable

from openai import (
    APIConnectionError,
    APITimeoutError,
    InternalServerError,
    OpenAI,
    RateLimitError,
)

from memotether.schema import (
    AtomicMemory,
    ConversationTurn,
    ExtractionResult,
    MemoryType,
)

DEFAULT_RECONCILE_GROUP_SIZE = 30
DEFAULT_MAX_RETRIES = 6
DEFAULT_RETRY_BASE_DELAY = 2.0
DEFAULT_RETRY_MAX_DELAY = 60.0
DEFAULT_FALLBACK_AFTER_ATTEMPT = 3

_RETRYABLE_EXCEPTIONS: tuple[type[BaseException], ...] = (
    RateLimitError,
    APIConnectionError,
    APITimeoutError,
    InternalServerError,
)


def _retry(
    fn: Callable[[str], Any],
    *,
    primary_model: str,
    fallback_model: str | None,
    fallback_after_attempt: int,
    max_attempts: int,
    base_delay: float,
    max_delay: float,
    label: str = "api call",
) -> Any:
    """Exponential backoff with jitter on transient OpenAI errors. After
    ``fallback_after_attempt`` failed attempts on ``primary_model``, swap to
    ``fallback_model`` for the remaining retries (if one is configured).
    Re-raises the original exception after ``max_attempts`` failed tries.

    ``fn`` is called with the current model id so it can be re-issued against
    the fallback without rebuilding the closure.
    """
    for attempt in range(max_attempts):
        using_fallback = (
            bool(fallback_model) and attempt >= fallback_after_attempt
        )
        model = fallback_model if using_fallback else primary_model
        assert model is not None
        try:
            return fn(model)
        except _RETRYABLE_EXCEPTIONS as e:
            if attempt == max_attempts - 1:
                raise
            delay = min(max_delay, base_delay * (2**attempt))
            delay += random.uniform(0, delay * 0.25)
            next_uses_fallback = (
                bool(fallback_model)
                and (attempt + 1) >= fallback_after_attempt
            )
            switching = next_uses_fallback and not using_fallback
            tag = (
                f" → switching to fallback {fallback_model!r}"
                if switching
                else ""
            )
            print(
                f"  retry {label} (attempt {attempt + 1}/{max_attempts}, "
                f"model={model}) after {type(e).__name__}: "
                f"sleeping {delay:.1f}s{tag}",
                flush=True,
            )
            time.sleep(delay)

_MEMORY_TYPES_PLACEHOLDER = "__MEMORY_TYPES__"
_PROMPTS = files("memotether") / "prompts"


def _load_prompt(name: str) -> str:
    return (_PROMPTS / name).read_text(encoding="utf-8").rstrip()


SYSTEM_PROMPT = _load_prompt("extract_system.md").replace(
    _MEMORY_TYPES_PLACEHOLDER, str([t.value for t in MemoryType])
)
RECONCILE_SYSTEM_PROMPT = _load_prompt("reconcile_system.md")


def _format_turns(turns: list[ConversationTurn]) -> str:
    return "\n\n".join(
        f"[turn:{t.id}] ({t.role}): {t.content}" for t in turns
    )


def _coerce_turns(input_data: str | list[ConversationTurn]) -> list[ConversationTurn]:
    if isinstance(input_data, str):
        return [ConversationTurn(id="t1", role="user", content=input_data)]
    return list(input_data)


def _split_oversized_turn(
    turn: ConversationTurn, max_chars: int
) -> list[ConversationTurn]:
    if len(turn.content) <= max_chars:
        return [turn]
    parts: list[ConversationTurn] = []
    text = turn.content
    idx = 0
    part_idx = 0
    while idx < len(text):
        parts.append(
            ConversationTurn(
                id=f"{turn.id}#part{part_idx}",
                role=turn.role,
                content=text[idx : idx + max_chars],
                timestamp=turn.timestamp,
            )
        )
        idx += max_chars
        part_idx += 1
    return parts


def _chunk_turns(
    turns: list[ConversationTurn], max_chars: int
) -> list[list[ConversationTurn]]:
    chunks: list[list[ConversationTurn]] = []
    current: list[ConversationTurn] = []
    size = 0
    for turn in turns:
        turn_size = len(turn.content) + len(turn.role) + len(turn.id) + 16
        if current and size + turn_size > max_chars:
            chunks.append(current)
            current = []
            size = 0
        current.append(turn)
        size += turn_size
    if current:
        chunks.append(current)
    return chunks


def _cached_system_content(prompt: str, cache: bool) -> Any:
    if not cache:
        return prompt
    return [
        {
            "type": "text",
            "text": prompt,
            "cache_control": {"type": "ephemeral"},
        }
    ]


def _format_group_for_reconcile(memories: list[AtomicMemory]) -> str:
    items = [
        {
            "id": m.id,
            "type": m.type.value,
            "content": m.content,
            "entities": m.entities,
        }
        for m in memories
    ]
    return json.dumps(items, indent=2)


def _build_entity_index(memories: list[AtomicMemory]) -> dict[str, list[int]]:
    idx: dict[str, list[int]] = {}
    for i, m in enumerate(memories):
        for e in m.entities:
            key = e.strip().lower()
            if key:
                idx.setdefault(key, []).append(i)
    return idx


def _candidate_groups(memories: list[AtomicMemory]) -> list[list[int]]:
    n = len(memories)
    parent = list(range(n))

    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    for indices in _build_entity_index(memories).values():
        for j in range(1, len(indices)):
            union(indices[0], indices[j])

    groups: dict[int, list[int]] = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(i)

    return [sorted(g) for g in groups.values() if len(g) > 1]


class Extractor:
    def __init__(
        self,
        model: str,
        api_key: str,
        base_url: str,
        max_chunk_chars: int,
        concurrency: int = 1,
        reconcile: bool = True,
        reconcile_model: str | None = None,
        reconcile_group_size: int = DEFAULT_RECONCILE_GROUP_SIZE,
        cache_system_prompt: bool = True,
        max_retries: int = DEFAULT_MAX_RETRIES,
        retry_base_delay: float = DEFAULT_RETRY_BASE_DELAY,
        retry_max_delay: float = DEFAULT_RETRY_MAX_DELAY,
        fallback_model: str | None = None,
        fallback_after_attempt: int = DEFAULT_FALLBACK_AFTER_ATTEMPT,
    ):
        self.client = OpenAI(api_key=api_key, base_url=base_url)
        self.model = model
        self.reconcile_model = reconcile_model or model
        self.max_chunk_chars = max_chunk_chars
        self.concurrency = max(1, concurrency)
        self.reconcile = reconcile
        self.reconcile_group_size = max(2, reconcile_group_size)
        self.cache_system_prompt = cache_system_prompt
        self.max_retries = max(1, max_retries)
        self.retry_base_delay = retry_base_delay
        self.retry_max_delay = retry_max_delay
        self.fallback_model = fallback_model
        self.fallback_after_attempt = max(0, fallback_after_attempt)

    def plan_chunks(
        self, input_data: str | list[ConversationTurn]
    ) -> list[list[ConversationTurn]]:
        turns = _coerce_turns(input_data)
        prepared: list[ConversationTurn] = []
        for t in turns:
            prepared.extend(_split_oversized_turn(t, self.max_chunk_chars))
        return _chunk_turns(prepared, self.max_chunk_chars)

    def extract(
        self,
        input_data: str | list[ConversationTurn],
        conversation_id: str = "default",
        progress: Callable[[int, int, int], None] | None = None,
        reconcile_progress: Callable[[int, int, int], None] | None = None,
        on_chunk: Callable[[int, list[AtomicMemory]], None] | None = None,
    ) -> ExtractionResult:
        """Extract memories from input.

        ``on_chunk(index, memories)`` fires for each chunk as it completes —
        use this to persist incrementally so a mid-run failure on chunk N
        doesn't lose chunks 1..N-1. The ``index`` is the chunk's position in
        the original sequence (not completion order). Reconciliation runs
        after all chunks; supersedes added there are NOT visible in the
        per-chunk callback — read them off the returned ExtractionResult or
        re-persist after extract() returns.
        """
        chunks = self.plan_chunks(input_data)
        total = len(chunks)
        all_turn_ids = [t.id for chunk in chunks for t in chunk]

        per_chunk: dict[int, list[AtomicMemory]] = {}

        if self.concurrency == 1 or total <= 1:
            for i, chunk in enumerate(chunks):
                mems = self._extract_chunk(chunk)
                per_chunk[i] = mems
                if on_chunk is not None:
                    on_chunk(i, mems)
                if progress is not None:
                    progress(i + 1, total, len(mems))
        else:
            with ThreadPoolExecutor(max_workers=self.concurrency) as exe:
                future_to_idx = {
                    exe.submit(self._extract_chunk, chunk): i
                    for i, chunk in enumerate(chunks)
                }
                completed = 0
                for fut in as_completed(future_to_idx):
                    i = future_to_idx[fut]
                    mems = fut.result()
                    per_chunk[i] = mems
                    if on_chunk is not None:
                        on_chunk(i, mems)
                    completed += 1
                    if progress is not None:
                        progress(completed, total, len(mems))

        all_memories: list[AtomicMemory] = []
        for i in range(total):
            all_memories.extend(per_chunk[i])

        if self.reconcile and len(all_memories) >= 2:
            all_memories = self._reconcile_all(all_memories, reconcile_progress)

        return ExtractionResult(
            memories=all_memories,
            conversation_id=conversation_id,
            processed_turn_ids=all_turn_ids,
        )

    def _extract_chunk(self, turns: list[ConversationTurn]) -> list[AtomicMemory]:
        def call(active_model: str) -> Any:
            return self.client.chat.completions.create(
                model=active_model,
                messages=[
                    {
                        "role": "system",
                        "content": _cached_system_content(
                            SYSTEM_PROMPT, self.cache_system_prompt
                        ),
                    },
                    {"role": "user", "content": _format_turns(turns)},
                ],
            )

        response = _retry(
            call,
            primary_model=self.model,
            fallback_model=self.fallback_model,
            fallback_after_attempt=self.fallback_after_attempt,
            max_attempts=self.max_retries,
            base_delay=self.retry_base_delay,
            max_delay=self.retry_max_delay,
            label="extract chunk",
        )
        content = response.choices[0].message.content or ""
        raw = _parse_memories_json(content)
        memories: list[AtomicMemory] = []
        for item in raw:
            if not isinstance(item, dict):
                continue
            try:
                memories.append(AtomicMemory(**item))
            except Exception:
                continue
        return memories

    def _reconcile_all(
        self,
        memories: list[AtomicMemory],
        progress: Callable[[int, int, int], None] | None,
    ) -> list[AtomicMemory]:
        groups = _candidate_groups(memories)
        if not groups:
            return memories

        # Cap group size by splitting into ordered, non-overlapping windows.
        # Cross-window contradictions in oversized groups are accepted as a
        # known tradeoff; raise reconcile_group_size to widen coverage.
        windows: list[list[int]] = []
        step = self.reconcile_group_size
        for g in groups:
            if len(g) <= step:
                windows.append(g)
            else:
                for start in range(0, len(g), step):
                    windows.append(g[start : start + step])

        total = len(windows)
        results: list[list[dict]] = []

        def run(window: list[int]) -> list[dict]:
            return self._reconcile_group([memories[i] for i in window])

        if self.concurrency == 1 or total <= 1:
            for i, window in enumerate(windows):
                res = run(window)
                results.append(res)
                if progress is not None:
                    progress(i + 1, total, len(res))
        else:
            with ThreadPoolExecutor(max_workers=self.concurrency) as exe:
                futures = [exe.submit(run, w) for w in windows]
                completed = 0
                for fut in as_completed(futures):
                    res = fut.result()
                    results.append(res)
                    completed += 1
                    if progress is not None:
                        progress(completed, total, len(res))

        super_map: dict[str, set[str]] = {}
        for entries in results:
            for entry in entries:
                new_id = entry.get("new_id")
                old_ids = entry.get("old_ids") or []
                if not isinstance(new_id, str):
                    continue
                bucket = super_map.setdefault(new_id, set())
                for oid in old_ids:
                    if isinstance(oid, str) and oid != new_id:
                        bucket.add(oid)

        if not super_map:
            return memories

        out: list[AtomicMemory] = []
        for m in memories:
            if m.id in super_map:
                merged = sorted(set(m.supersedes) | super_map[m.id])
                out.append(m.model_copy(update={"supersedes": merged}))
            else:
                out.append(m)
        return out

    def _reconcile_group(self, group: list[AtomicMemory]) -> list[dict]:
        def call(active_model: str) -> Any:
            return self.client.chat.completions.create(
                model=active_model,
                messages=[
                    {
                        "role": "system",
                        "content": _cached_system_content(
                            RECONCILE_SYSTEM_PROMPT, self.cache_system_prompt
                        ),
                    },
                    {"role": "user", "content": _format_group_for_reconcile(group)},
                ],
            )

        response = _retry(
            call,
            primary_model=self.reconcile_model,
            fallback_model=self.fallback_model,
            fallback_after_attempt=self.fallback_after_attempt,
            max_attempts=self.max_retries,
            base_delay=self.retry_base_delay,
            max_delay=self.retry_max_delay,
            label="reconcile window",
        )
        content = response.choices[0].message.content or ""
        return _parse_supersedes_json(content)


def _parse_json(content: str) -> Any | None:
    text = content.strip()
    fenced = re.search(r"```(?:json)?\s*(.+?)\s*```", text, re.DOTALL)
    if fenced:
        text = fenced.group(1).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if not match:
            return None
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            return None


def _parse_memories_json(content: str) -> list[Any]:
    data = _parse_json(content)
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        items = data.get("memories")
        if isinstance(items, list):
            return items
    return []


def _parse_supersedes_json(content: str) -> list[dict]:
    data = _parse_json(content)
    if isinstance(data, dict):
        items = data.get("supersedes")
        if isinstance(items, list):
            return [x for x in items if isinstance(x, dict)]
    return []
