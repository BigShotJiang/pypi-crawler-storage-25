from __future__ import annotations

import os
from typing import Any, Callable

Embedder = Callable[[str], list[float]] | Any


def call_document(embedder: Embedder, text: str) -> list[float]:
    fn = getattr(embedder, "embed_document", None)
    if callable(fn):
        return fn(text)
    return embedder(text)


def call_query(embedder: Embedder, text: str) -> list[float]:
    fn = getattr(embedder, "embed_query", None)
    if callable(fn):
        return fn(text)
    return embedder(text)


def call_documents(embedder: Embedder, texts: list[str]) -> list[list[float]]:
    """Batch-embed many documents. Falls back to per-text calls if the
    embedder doesn't expose a batch method.
    """
    fn = getattr(embedder, "embed_documents", None)
    if callable(fn):
        return fn(texts)
    return [call_document(embedder, t) for t in texts]


class NomicEmbedder:
    """Local embedder using fastembed + ``nomic-ai/nomic-embed-text-v1.5``.

    768-dim, ~550MB, Apache 2.0. Asymmetric prefixes are applied
    automatically — documents get ``search_document:`` and queries get
    ``search_query:``.
    """

    def __init__(
        self,
        model_name: str = "nomic-ai/nomic-embed-text-v1.5",
    ):
        try:
            from fastembed import TextEmbedding
        except ImportError as e:
            raise ImportError(
                "fastembed is required for NomicEmbedder. "
                "Install with `pip install fastembed` or `pip install memotether[local-embed]`."
            ) from e
        self.model_name = model_name
        self._model = TextEmbedding(model_name=model_name)

    def _embed(self, prefixed: str) -> list[float]:
        vec = next(self._model.embed([prefixed]))
        return vec.tolist() if hasattr(vec, "tolist") else list(vec)

    def _embed_many(self, prefixed: list[str]) -> list[list[float]]:
        out: list[list[float]] = []
        for vec in self._model.embed(prefixed):
            out.append(vec.tolist() if hasattr(vec, "tolist") else list(vec))
        return out

    def embed_document(self, text: str) -> list[float]:
        return self._embed(f"search_document: {text}")

    def embed_query(self, text: str) -> list[float]:
        return self._embed(f"search_query: {text}")

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return self._embed_many([f"search_document: {t}" for t in texts])

    def embed_queries(self, texts: list[str]) -> list[list[float]]:
        return self._embed_many([f"search_query: {t}" for t in texts])

    def __call__(self, text: str) -> list[float]:
        return self.embed_document(text)


class OpenAIEmbedder:
    """OpenAI-compatible embedder. Symmetric — same call for docs and queries."""

    def __init__(
        self,
        model: str = "text-embedding-3-small",
        api_key: str | None = None,
        base_url: str | None = None,
        dimensions: int | None = None,
    ):
        from openai import OpenAI

        self.model = model
        self.dimensions = dimensions
        self._client = OpenAI(
            api_key=api_key or os.environ.get("OPENAI_API_KEY"),
            base_url=base_url,
        )

    def __call__(self, text: str) -> list[float]:
        kwargs: dict[str, Any] = {"model": self.model, "input": text}
        if self.dimensions is not None:
            kwargs["dimensions"] = self.dimensions
        resp = self._client.embeddings.create(**kwargs)
        return resp.data[0].embedding


def resolve_embedder(spec: str | Embedder | None) -> Embedder | None:
    """Resolve a string shorthand to an embedder instance, or pass through."""
    if spec is None:
        return None
    if not isinstance(spec, str):
        return spec
    name = spec.lower()
    if name in ("nomic", "local"):
        return NomicEmbedder()
    if name == "openai":
        return OpenAIEmbedder()
    if name.startswith("nomic:"):
        return NomicEmbedder(model_name=spec.split(":", 1)[1])
    if name.startswith("openai:"):
        return OpenAIEmbedder(model=spec.split(":", 1)[1])
    raise ValueError(
        f"unknown embedder spec: {spec!r}. "
        "Use 'nomic', 'openai', 'nomic:<model>', 'openai:<model>', "
        "or pass an Embedder instance."
    )
