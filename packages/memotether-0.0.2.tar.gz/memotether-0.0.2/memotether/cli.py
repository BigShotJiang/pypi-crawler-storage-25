"""Top-level Memotether CLI.

Subcommands:
  mcp     Run the stdio MCP server (default if no subcommand is given).
  ingest  Batch-ingest a transcript file into the store.

Bare ``memotether`` (or ``memotether --db ...``) keeps booting the MCP
server, so existing host configurations (Claude Code, opencode) continue
to work.
"""

from __future__ import annotations

import argparse
import asyncio
import sys

_KNOWN_SUBCOMMANDS = {"mcp", "ingest", "prompt", "install"}


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="memotether",
        description="Memotether: local-first memory layer for LLMs.",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    mcp_p = sub.add_parser(
        "mcp",
        help="Run the stdio MCP server (also the default with no subcommand).",
    )
    mcp_p.add_argument("--db", default=None, help="SQLite path (overrides $MEMOTETHER_DB_PATH).")
    mcp_p.add_argument(
        "--embedder",
        default=None,
        help="Embedder spec: 'none', 'nomic', 'openai', 'nomic:<model>', 'openai:<model>' (overrides $MEMOTETHER_EMBEDDER).",
    )
    mcp_p.add_argument(
        "--conversation",
        default=None,
        help="Default conversation_id for remember() (overrides $MEMOTETHER_CONVERSATION).",
    )

    ing_p = sub.add_parser(
        "ingest",
        help="Batch-ingest a transcript file (text, JSON, JSONL, or opencode export).",
    )
    ing_p.add_argument("file", help="Path to transcript file.")
    ing_p.add_argument("--db", default=None, help="SQLite path (overrides $MEMOTETHER_DB_PATH).")
    ing_p.add_argument(
        "--conversation",
        default=None,
        help="conversation_id (default: derived from filename stem).",
    )
    ing_p.add_argument(
        "--format",
        choices=["auto", "text", "json", "jsonl"],
        default="auto",
        help="Input format. 'auto' picks based on file extension.",
    )
    ing_p.add_argument(
        "--no-chunks",
        action="store_true",
        help="Skip persisting raw chunks in the verbatim tier.",
    )

    sub.add_parser(
        "prompt",
        help=(
            "Print the agent system prompt to stdout. Useful for hosts "
            "that don't yet support MCP prompts (e.g. opencode) — pipe "
            "into AGENTS.md or paste into your system instructions so the "
            "model still gets the Memotether usage rules."
        ),
    )

    inst_p = sub.add_parser(
        "install",
        help="Wire memotether into an MCP host config.",
    )
    inst_sub = inst_p.add_subparsers(dest="host", required=True)

    oc_p = inst_sub.add_parser(
        "opencode",
        help="Add memotether to opencode's MCP config (global or project).",
    )
    scope_group = oc_p.add_mutually_exclusive_group()
    scope_group.add_argument(
        "--global",
        dest="scope",
        action="store_const",
        const="global",
        help="Write to ~/.config/opencode/opencode.json (default).",
    )
    scope_group.add_argument(
        "--project",
        dest="scope",
        action="store_const",
        const="project",
        help="Write to ./opencode.json and drop AGENTS.md in the cwd.",
    )
    oc_p.set_defaults(scope="global")
    oc_p.add_argument(
        "--db",
        default=None,
        help="MEMOTETHER_DB_PATH for this host (omit to share the default ~/.memotether/memories.db).",
    )
    oc_p.add_argument(
        "--name",
        default="memotether",
        help="MCP entry name (default: memotether).",
    )
    oc_p.add_argument(
        "--uvx",
        action="store_true",
        help="Launch via `uvx` instead of an installed memotether-mcp binary.",
    )

    return parser


def main(argv: list[str] | None = None) -> None:
    if argv is None:
        argv = sys.argv[1:]

    if not argv:
        argv = ["mcp"]
    elif argv[0] not in _KNOWN_SUBCOMMANDS and argv[0] not in ("-h", "--help"):
        argv = ["mcp", *argv]

    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.cmd == "mcp":
        from memotether.mcp_server import main as mcp_main
        asyncio.run(mcp_main([
            *(("--db", args.db) if args.db else ()),
            *(("--embedder", args.embedder) if args.embedder else ()),
            *(("--conversation", args.conversation) if args.conversation else ()),
        ]))
    elif args.cmd == "ingest":
        from memotether.ingest import ingest_file
        ingest_file(
            args.file,
            db=args.db,
            conversation=args.conversation,
            format=args.format,
            store_chunks=not args.no_chunks,
        )
    elif args.cmd == "prompt":
        from importlib.resources import files
        from memotether.mcp_server import _AGENT_PROMPT_FILE

        text = (
            files("memotether.prompts")
            .joinpath(_AGENT_PROMPT_FILE)
            .read_text(encoding="utf-8")
        )
        sys.stdout.write(text)
        if not text.endswith("\n"):
            sys.stdout.write("\n")
    elif args.cmd == "install":
        if args.host == "opencode":
            from memotether.install import install_opencode

            path = install_opencode(
                scope=args.scope,
                db_path=args.db,
                name=args.name,
                uvx=args.uvx,
            )
            sys.stdout.write(
                f"wrote opencode config at {path}\n"
                f"restart opencode; /mcp will list '{args.name}'.\n"
            )


if __name__ == "__main__":
    main()
