#!/usr/bin/env python3
import argparse
import json
import os
import sys
import time
from pathlib import Path

import tiktoken
from dotenv import load_dotenv
from pypdf import PdfReader

from memotether import Extractor, MemoryStore

TOKENIZER = "cl100k_base"


def count_tokens(text: str) -> int:
    return len(tiktoken.get_encoding(TOKENIZER).encode(text))


def format_memories(result) -> str:
    lines = []
    for m in result.memories:
        ents = f" [entities: {', '.join(m.entities)}]" if m.entities else ""
        lines.append(f"- {m.type.value}: {m.content}{ents}")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Run the Memotether extractor on a text file and report token compression."
    )
    parser.add_argument("input", type=Path, help="Path to input text file")
    parser.add_argument(
        "--max-chars",
        type=int,
        default=None,
        help="Truncate input to this many chars (cost control for large files)",
    )
    parser.add_argument(
        "--chunk-chars",
        type=int,
        default=None,
        help="Override extractor max_chunk_chars",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=None,
        help="Write extracted memories + stats to this JSON path",
    )
    parser.add_argument(
        "--concurrency",
        type=int,
        default=1,
        help="Number of chunks to extract in parallel (default: 1)",
    )
    parser.add_argument(
        "--no-reconcile",
        action="store_true",
        help="Skip the cross-chunk reconciliation pass",
    )
    parser.add_argument(
        "--reconcile-model",
        default=None,
        help="Model for the reconciliation pass (default: MEMOTETHER_RECONCILE_MODEL or main model)",
    )
    parser.add_argument(
        "--reconcile-group-size",
        type=int,
        default=30,
        help="Max memories per reconciliation window (default: 30)",
    )
    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="Disable Anthropic prompt caching on system prompts",
    )
    parser.add_argument(
        "--count-only",
        action="store_true",
        help="Print input chars/tokens/chunk-count and exit; no API calls",
    )
    parser.add_argument(
        "--db",
        type=Path,
        default=None,
        help="Persist extracted memories to this SQLite path",
    )
    args = parser.parse_args()

    load_dotenv()

    try:
        api_key = os.environ["OPENROUTER_API_KEY"]
        model = os.environ["MEMOTETHER_MODEL"]
        base_url = os.environ["MEMOTETHER_BASE_URL"]
        env_max_chunk_chars = int(os.environ["MEMOTETHER_MAX_CHUNK_CHARS"])
    except KeyError as e:
        print(f"error: required env var not set: {e.args[0]}", file=sys.stderr)
        return 2

    reconcile_model = args.reconcile_model or os.environ.get("MEMOTETHER_RECONCILE_MODEL")

    if not args.input.exists():
        print(f"error: input not found: {args.input}", file=sys.stderr)
        return 2

    if args.input.suffix.lower() == ".pdf":
        reader = PdfReader(str(args.input))
        text = "\n\n".join(page.extract_text() or "" for page in reader.pages)
    else:
        text = args.input.read_text()

    if args.max_chars is not None:
        text = text[: args.max_chars]

    input_chars = len(text)
    input_tokens = count_tokens(text)

    if args.count_only:
        max_chunk = args.chunk_chars or env_max_chunk_chars
        n_chunks = max(1, -(-input_chars // max_chunk))
        print(f"Input file:    {args.input}")
        print(f"Input chars:   {input_chars:,}")
        print(f"Input tokens:  {input_tokens:,} ({TOKENIZER})")
        print(f"Chunk size:    {max_chunk:,} chars")
        print(f"Chunks:        {n_chunks}")
        return 0

    extractor = Extractor(
        model=model,
        api_key=api_key,
        base_url=base_url,
        max_chunk_chars=args.chunk_chars or env_max_chunk_chars,
        concurrency=args.concurrency,
        reconcile=not args.no_reconcile,
        reconcile_model=reconcile_model,
        reconcile_group_size=args.reconcile_group_size,
        cache_system_prompt=not args.no_cache,
    )

    print(f"Input file:    {args.input}")
    print(f"Input chars:   {input_chars:,}")
    print(f"Input tokens:  {input_tokens:,} ({TOKENIZER})")
    print(f"Model:         {extractor.model}")
    print(f"Chunk size:    {extractor.max_chunk_chars:,} chars")
    print(f"Concurrency:   {extractor.concurrency}")
    print(f"Reconcile:     {extractor.reconcile} (model: {extractor.reconcile_model})")
    print(f"Cache prompts: {extractor.cache_system_prompt}")
    print()
    print("Extracting...", flush=True)

    def on_progress(i: int, total: int, n_mem: int) -> None:
        print(f"  chunk {i}/{total} -> {n_mem} memories", flush=True)

    reconcile_announced = {"done": False}

    def on_reconcile(i: int, total: int, n_super: int) -> None:
        if not reconcile_announced["done"]:
            print("\nReconciling...", flush=True)
            reconcile_announced["done"] = True
        print(f"  window {i}/{total} -> {n_super} supersedes", flush=True)

    t0 = time.monotonic()
    result = extractor.extract(
        text,
        conversation_id=args.input.stem,
        progress=on_progress,
        reconcile_progress=on_reconcile,
    )
    elapsed = time.monotonic() - t0

    formatted = format_memories(result)
    output_chars = len(formatted)
    output_tokens = count_tokens(formatted)

    type_counts: dict[str, int] = {}
    for m in result.memories:
        type_counts[m.type.value] = type_counts.get(m.type.value, 0) + 1

    superseding = sum(1 for m in result.memories if m.supersedes)
    superseded_ids: set[str] = set()
    for m in result.memories:
        superseded_ids.update(m.supersedes)

    print()
    print(f"Elapsed:       {elapsed:.1f}s")
    print(f"Memories:      {len(result.memories)}")
    for t, c in sorted(type_counts.items()):
        print(f"  - {t}: {c}")
    if extractor.reconcile:
        print(f"Reconciled:    {superseding} memories supersede {len(superseded_ids)} earlier ones")
    print()
    print(f"Output chars:  {output_chars:,}")
    print(f"Output tokens: {output_tokens:,}")
    print()
    if input_tokens > 0 and output_tokens > 0:
        ratio = output_tokens / input_tokens
        reduction = input_tokens / output_tokens
        print(f"Compression:   {ratio:.4f}  ({reduction:.1f}x reduction)")

    if args.db is not None:
        args.db.parent.mkdir(parents=True, exist_ok=True)
        with MemoryStore(args.db) as store:
            store.add(result.memories, conversation_id=args.input.stem)
        print(f"\nPersisted {len(result.memories)} memories to: {args.db}")

    if args.out is not None:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "input_path": str(args.input),
            "input_chars": input_chars,
            "input_tokens": input_tokens,
            "output_chars": output_chars,
            "output_tokens": output_tokens,
            "elapsed_seconds": elapsed,
            "tokenizer": TOKENIZER,
            "model": extractor.model,
            "reconcile_model": extractor.reconcile_model if extractor.reconcile else None,
            "reconciled": {
                "superseding_memories": superseding,
                "superseded_memories": len(superseded_ids),
            },
            "type_counts": type_counts,
            "memories": [m.model_dump(mode="json") for m in result.memories],
        }
        args.out.write_text(json.dumps(payload, indent=2, default=str))
        print(f"\nWrote: {args.out}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
