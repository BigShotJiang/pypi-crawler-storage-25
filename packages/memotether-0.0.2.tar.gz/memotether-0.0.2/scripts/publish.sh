#!/usr/bin/env bash
# Publish memotether to PyPI (or TestPyPI).
#
# One-time setup:
#   1. Create accounts:    https://pypi.org/account/register/  and  https://test.pypi.org/account/register/
#   2. Generate API tokens: https://pypi.org/manage/account/token/  (scope=all-projects for first upload)
#                           https://test.pypi.org/manage/account/token/
#   3. Export them in your shell rc (so `direnv` / new shells pick them up):
#        export PYPI_API_TOKEN=pypi-AgEI...
#        export TEST_PYPI_API_TOKEN=pypi-AgEI...
#
# Usage:
#   scripts/publish.sh                       # build + upload to TestPyPI (default, safe)
#   scripts/publish.sh --bump patch          # 0.0.1 -> 0.0.2, commit, then TestPyPI
#   scripts/publish.sh --version 0.1.0       # explicit version, commit, then TestPyPI
#   scripts/publish.sh --bump patch --prod   # bump + commit + tag + upload to real PyPI
#   scripts/publish.sh --prod                # upload current version to real PyPI (no bump)
#   scripts/publish.sh --no-tag --prod       # skip the git tag step
#   scripts/publish.sh --dry-run             # build + check, no upload
#
# After a TestPyPI upload, verify with:
#   pipx install --pip-args="--index-url https://test.pypi.org/simple/ \
#     --extra-index-url https://pypi.org/simple/" "memotether[local-embed]"
#
# After a prod upload, push the tag:
#   git push origin v$(grep -E '^version' pyproject.toml | cut -d'"' -f2)

set -euo pipefail

target=test
bump=""
explicit_version=""
skip_tag=false
dry_run=false

usage() {
    grep -E '^# ' "$0" | sed 's/^# \{0,1\}//'
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --prod)        target=prod ;;
        --test)        target=test ;;
        --bump)        bump="${2:?--bump requires patch|minor|major}"; shift ;;
        --version)     explicit_version="${2:?--version requires X.Y.Z}"; shift ;;
        --no-tag)      skip_tag=true ;;
        --dry-run)     dry_run=true ;;
        -h|--help)     usage; exit 0 ;;
        *)             echo "unknown arg: $1" >&2; usage >&2; exit 1 ;;
    esac
    shift
done

cd "$(dirname "$0")/.."

# ─── Locate Python (prefer venv) ───────────────────────────────────────────
if [[ -x .venv/bin/python ]]; then
    PY=.venv/bin/python
else
    PY=$(command -v python3 || command -v python)
fi
echo "using python: $PY ($($PY --version))"

# ─── Ensure build + twine are installed ────────────────────────────────────
"$PY" -c "import build"  >/dev/null 2>&1 || "$PY" -m pip install --quiet build
"$PY" -c "import twine"  >/dev/null 2>&1 || "$PY" -m pip install --quiet twine

# ─── Read current version ──────────────────────────────────────────────────
current=$(grep -E '^version[[:space:]]*=' pyproject.toml | head -n1 | sed -E 's/.*"([^"]+)".*/\1/')
[[ -z $current ]] && { echo "could not read version from pyproject.toml" >&2; exit 1; }
echo "current version: $current"

# ─── Compute new version ───────────────────────────────────────────────────
new_version="$current"
if [[ -n $explicit_version && -n $bump ]]; then
    echo "--version and --bump are mutually exclusive" >&2; exit 1
fi
if [[ -n $explicit_version ]]; then
    new_version="$explicit_version"
elif [[ -n $bump ]]; then
    IFS=. read -r maj min pat <<<"$current"
    case "$bump" in
        patch) pat=$((pat + 1)) ;;
        minor) min=$((min + 1)); pat=0 ;;
        major) maj=$((maj + 1)); min=0; pat=0 ;;
        *) echo "invalid --bump: $bump (use patch|minor|major)" >&2; exit 1 ;;
    esac
    new_version="$maj.$min.$pat"
fi

# ─── Apply version bump (if any) ───────────────────────────────────────────
if [[ $new_version != "$current" ]]; then
    echo "bumping version: $current -> $new_version"
    # macOS/BSD sed needs the empty '' after -i; this form also works on GNU sed.
    sed -i.bak -E "s/^version = \".*\"/version = \"$new_version\"/" pyproject.toml
    rm -f pyproject.toml.bak
    if $dry_run; then
        echo "dry-run: not committing version bump"
    else
        git add pyproject.toml
        git commit -m "release: v$new_version" >/dev/null
        echo "committed: release: v$new_version"
    fi
fi

# ─── Token check ───────────────────────────────────────────────────────────
case "$target" in
    test) token="${TEST_PYPI_API_TOKEN:-}";  repo="testpypi"; repo_url="https://test.pypi.org/" ;;
    prod) token="${PYPI_API_TOKEN:-}";       repo="pypi";     repo_url="https://pypi.org/"      ;;
esac
if [[ -z $token && $dry_run = false ]]; then
    echo "missing $(echo ${target} | tr a-z A-Z)_PYPI_API_TOKEN env var. See header of this script." >&2
    exit 1
fi

# ─── Clean + build ─────────────────────────────────────────────────────────
echo "cleaning dist/ build/ ..."
rm -rf dist build ./*.egg-info memotether.egg-info

echo "building wheel + sdist ..."
"$PY" -m build

echo "validating artifacts ..."
"$PY" -m twine check dist/*

ls -lh dist/

if $dry_run; then
    echo "dry-run: skipping upload"
    exit 0
fi

# ─── Upload ────────────────────────────────────────────────────────────────
echo "uploading to $repo ($repo_url) ..."
TWINE_USERNAME=__token__ TWINE_PASSWORD="$token" \
    "$PY" -m twine upload --repository "$repo" dist/*

# ─── Tag (prod only by default; TestPyPI uploads aren't tagged) ────────────
if [[ $target = prod && $skip_tag = false ]]; then
    tag="v$new_version"
    if git rev-parse "$tag" >/dev/null 2>&1; then
        echo "tag $tag already exists; skipping"
    else
        git tag -a "$tag" -m "release $tag"
        echo "tagged $tag (push with: git push origin $tag)"
    fi
fi

echo "done. installed name on $repo: memotether==$new_version"
