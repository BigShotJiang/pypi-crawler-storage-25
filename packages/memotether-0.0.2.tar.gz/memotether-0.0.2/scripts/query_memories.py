#!/usr/bin/env python3
import argparse
import sys
from pathlib import Path

from memotether import MemoryStore, MemoryType


def print_memory(m, score: float | None = None) -> None:
    prefix = f"[{score:+.4f}] " if score is not None else ""
    ents = f"  entities: {', '.join(m.entities)}" if m.entities else ""
    sup = f"  supersedes: {', '.join(m.supersedes)}" if m.supersedes else ""
    print(f"{prefix}{m.type.value}: {m.content}")
    if ents:
        print(f"   {ents.strip()}")
    if sup:
        print(f"   {sup.strip()}")
    print(f"   id={m.id}  confidence={m.confidence:.2f}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Query a Memotether SQLite memory store."
    )
    parser.add_argument("db", type=Path, help="Path to SQLite store")
    parser.add_argument("query", nargs="?", default=None, help="Search query")
    parser.add_argument(
        "--mode",
        choices=["keyword", "fuzzy", "vector", "hybrid"],
        default="hybrid",
        help="Search mode (default: hybrid)",
    )
    parser.add_argument("-k", "--top-k", type=int, default=10)
    parser.add_argument(
        "--type",
        action="append",
        default=None,
        help="Filter by memory type (repeatable: fact, preference, event, ...)",
    )
    parser.add_argument(
        "--include-superseded",
        action="store_true",
        help="Include memories that have been superseded by newer ones",
    )
    parser.add_argument(
        "--list", action="store_true", help="Dump all memories instead of searching"
    )
    parser.add_argument(
        "--count", action="store_true", help="Print store size and exit"
    )
    parser.add_argument(
        "--by-entity", default=None, help="List memories mentioning this entity"
    )
    args = parser.parse_args()

    if not args.db.exists():
        print(f"error: db not found: {args.db}", file=sys.stderr)
        return 2

    type_filter = (
        [MemoryType(t) for t in args.type] if args.type else None
    )

    with MemoryStore(args.db) as store:
        if args.count:
            total = store.count(include_superseded=True)
            active = store.count(include_superseded=False)
            print(f"total:  {total}")
            print(f"active: {active}  (superseded: {total - active})")
            return 0

        if args.list:
            for m in store.all(include_superseded=args.include_superseded):
                print_memory(m)
                print()
            return 0

        if args.by_entity:
            results = store.by_entity(
                args.by_entity, include_superseded=args.include_superseded
            )
            print(f"{len(results)} memory(ies) for entity '{args.by_entity}':\n")
            for m in results:
                print_memory(m)
                print()
            return 0

        if not args.query:
            parser.error("query is required (or use --list / --count / --by-entity)")

        kwargs = dict(
            k=args.top_k,
            include_superseded=args.include_superseded,
            types=type_filter,
        )
        if args.mode == "keyword":
            results = store.search_keyword(args.query, **kwargs)
        elif args.mode == "fuzzy":
            results = store.search_fuzzy(args.query, **kwargs)
        elif args.mode == "vector":
            results = store.search_vector(args.query, **kwargs)
        else:
            results = store.search(args.query, **kwargs)

        if not results:
            print("(no matches)")
            return 0

        print(f"{len(results)} result(s) for '{args.query}' [{args.mode}]:\n")
        for m, score in results:
            print_memory(m, score)
            print()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
