#!/usr/bin/env python3
import argparse
import json
import os
import sys
import time
from pathlib import Path

import tiktoken
from dotenv import load_dotenv
from openai import OpenAI
from pypdf import PdfReader

from memotether.extractor import _parse_json

DEFAULT_MODEL = "qwen/qwen3.6-plus"
DEFAULT_BATCHES = 3
DEFAULT_QUESTIONS_PER_BATCH = 25
TOKENIZER = "cl100k_base"
_ENC = tiktoken.get_encoding(TOKENIZER)

SYSTEM_PROMPT = """You generate needle-in-the-haystack evaluation questions for a long literary corpus.

Given a chunk of text, produce questions that meet ALL of the following:
  - Each question targets a SPECIFIC, VERIFIABLE fact in the text — a character name, a line of dialogue, a stage direction, a named place, a specific number, a single-line speaker.
  - Each fact must be locatable by exact string match in the source. Avoid thematic, interpretive, or summary questions.
  - Prefer obscure but unambiguous needles: minor characters, named props, unusual word choices, specific quantities.
  - Spread the questions across the entire batch — do not cluster them in one section or play.
  - Each item must include the EXACT verbatim text snippet from the source that contains the answer (~10-30 words). This snippet is the needle used to verify retrieval.
  - Each item's answer must be exactly grounded in the snippet — no paraphrasing.

Output ONLY a single JSON object of this exact shape, with no prose, no markdown fences:
{"questions": [
  {"question": "...", "answer": "...", "needle": "...verbatim snippet from the text..."},
  ...
]}

Generate exactly the number of questions requested. If a candidate fact is too generic, skip it and find a more specific one."""


def count_tokens(text: str) -> int:
    return len(_ENC.encode(text))


def extract_pdf_text(path: Path) -> str:
    reader = PdfReader(str(path))
    n_pages = len(reader.pages)
    print(f"Extracting {n_pages:,} pages from {path.name}...", flush=True)
    parts: list[str] = []
    for i, page in enumerate(reader.pages):
        parts.append(page.extract_text() or "")
        if (i + 1) % 200 == 0 or i + 1 == n_pages:
            print(f"  {i + 1:,}/{n_pages:,} pages", flush=True)
    return "\n\n".join(parts)


def split_by_tokens(text: str, n_batches: int) -> tuple[list[str], list[int]]:
    """Returns (batch_texts, batch_token_counts). Counts come from boundary
    diffs so they exactly match the cl100k_base tokenization of the source —
    no decode/re-encode round-trip drift."""
    print("Tokenizing full corpus...", flush=True)
    tokens = _ENC.encode(text)
    total = len(tokens)
    boundaries = [round(i * total / n_batches) for i in range(n_batches + 1)]
    pieces = [
        _ENC.decode(tokens[boundaries[i] : boundaries[i + 1]]) for i in range(n_batches)
    ]
    counts = [boundaries[i + 1] - boundaries[i] for i in range(n_batches)]
    return pieces, counts


def parse_questions(content: str) -> list[dict]:
    data = _parse_json(content)
    if isinstance(data, dict):
        items = data.get("questions")
        if isinstance(items, list):
            return [x for x in items if isinstance(x, dict)]
    return []


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Generate needle-in-the-haystack questions from a PDF using a long-context model."
    )
    parser.add_argument("input", type=Path, help="Input PDF path")
    parser.add_argument("--out", type=Path, required=True, help="Output JSON path")
    parser.add_argument(
        "--model",
        default=DEFAULT_MODEL,
        help=f"OpenRouter model id (default: {DEFAULT_MODEL})",
    )
    parser.add_argument(
        "--batches",
        type=int,
        default=DEFAULT_BATCHES,
        help=f"Number of token batches (default: {DEFAULT_BATCHES})",
    )
    parser.add_argument(
        "--questions-per-batch",
        type=int,
        default=DEFAULT_QUESTIONS_PER_BATCH,
        help=f"Questions to generate per batch (default: {DEFAULT_QUESTIONS_PER_BATCH})",
    )
    parser.add_argument(
        "--total-questions",
        type=int,
        default=None,
        help="Total questions across all batches; overrides --questions-per-batch and distributes evenly.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Report total / per-batch token counts and exit; no API calls",
    )
    args = parser.parse_args()

    if args.total_questions is not None and args.total_questions < args.batches:
        print(
            f"error: --total-questions ({args.total_questions}) must be >= --batches ({args.batches})",
            file=sys.stderr,
        )
        return 2

    load_dotenv()

    if not args.input.exists():
        print(f"error: input not found: {args.input}", file=sys.stderr)
        return 2

    text = extract_pdf_text(args.input)
    batches, batch_token_counts = split_by_tokens(text, args.batches)
    total_tokens = sum(batch_token_counts)

    if args.total_questions is not None:
        base, rem = divmod(args.total_questions, args.batches)
        per_batch_questions = [
            base + (1 if i < rem else 0) for i in range(args.batches)
        ]
    else:
        per_batch_questions = [args.questions_per_batch] * args.batches
    total_questions = sum(per_batch_questions)

    print()
    print(f"Input file:    {args.input}")
    print(f"Total tokens:  {total_tokens:,}")
    print(f"Batches:       {args.batches}")
    for i, (n_tok, n_q) in enumerate(zip(batch_token_counts, per_batch_questions)):
        print(f"  batch {i + 1}: {n_tok:,} tokens -> {n_q} questions")
    print(f"Total questions to generate: {total_questions}")

    if args.dry_run:
        return 0

    try:
        api_key = os.environ["OPENROUTER_API_KEY"]
    except KeyError:
        print("error: OPENROUTER_API_KEY is not set", file=sys.stderr)
        return 2
    base_url = os.environ.get("MEMOTETHER_BASE_URL", "https://openrouter.ai/api/v1")

    client = OpenAI(api_key=api_key, base_url=base_url)
    print()
    print(f"Model:         {args.model}")
    print(f"Output:        {args.out}")
    print()

    all_questions: list[dict] = []
    for i, batch in enumerate(batches):
        n_tokens = batch_token_counts[i]
        n_questions = per_batch_questions[i]
        print(
            f"Batch {i + 1}/{len(batches)} ({n_tokens:,} tokens) -> "
            f"generating {n_questions} questions...",
            flush=True,
        )
        user_prompt = (
            f"Generate exactly {n_questions} needle-in-the-haystack "
            f"questions from the following text. Cover the batch evenly — do not "
            f"cluster all questions in one section.\n\n---\n\n{batch}"
        )

        t0 = time.monotonic()
        response = client.chat.completions.create(
            model=args.model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
        )
        elapsed = time.monotonic() - t0

        if not response.choices:
            # OpenRouter returns errors as a non-standard `error` field on the
            # response body instead of raising. Surface it so the user can see
            # what the upstream actually said (bad model id, context too small,
            # rate limit, provider error, ...).
            err = getattr(response, "error", None)
            print(
                f"\n  ERROR: model returned no choices ({elapsed:.1f}s).",
                file=sys.stderr,
            )
            if err:
                print(f"  upstream error: {err}", file=sys.stderr)
            else:
                print(
                    f"  raw response: {json.dumps(response.model_dump(), default=str)[:1000]}",
                    file=sys.stderr,
                )
            return 1

        content = response.choices[0].message.content or ""
        raw = parse_questions(content)
        verified: list[dict] = []
        for q in raw:
            needle = q.get("needle")
            if isinstance(needle, str) and needle and needle in batch:
                q["batch"] = i + 1
                verified.append(q)
        dropped = len(raw) - len(verified)
        all_questions.extend(verified)
        print(
            f"  {len(verified)} verified ({dropped} dropped as unverifiable), "
            f"{elapsed:.1f}s",
            flush=True,
        )

    args.out.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "input_path": str(args.input),
        "model": args.model,
        "total_tokens": total_tokens,
        "batches": args.batches,
        "batch_token_counts": batch_token_counts,
        "questions_requested_per_batch": per_batch_questions,
        "questions_requested_total": total_questions,
        "questions": all_questions,
    }
    args.out.write_text(json.dumps(payload, indent=2))
    print()
    print(f"Wrote {len(all_questions)} verified questions to {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
