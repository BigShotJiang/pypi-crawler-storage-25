#!/usr/bin/env python3
import argparse
import json
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI
from pypdf import PdfReader

from memotether import Chunk, MemoryStore, MemoryType
from memotether.embedders import resolve_embedder
from memotether.extractor import Extractor, _parse_json


def load_questions(path: Path) -> tuple[list[dict], dict]:
    data = json.loads(path.read_text())
    return data.get("questions", []), data


def resolve_source_path(input_path: str, json_path: Path) -> Path:
    """The haystack JSON stores ``input_path`` as the user originally typed it
    (often relative). Try the obvious places before giving up.
    """
    candidates = [
        Path(input_path),
        json_path.parent / input_path,
        Path.cwd() / input_path,
    ]
    for c in candidates:
        if c.exists():
            return c.resolve()
    raise FileNotFoundError(
        f"could not locate source for input_path={input_path!r}; pass --source PATH"
    )


def read_corpus(source: Path) -> str:
    if source.suffix.lower() == ".pdf":
        reader = PdfReader(str(source))
        return "\n\n".join(page.extract_text() or "" for page in reader.pages)
    return source.read_text()


def ingest_source(
    source: Path,
    store: MemoryStore,
    *,
    model: str,
    api_key: str,
    base_url: str,
    max_chunk_chars: int,
    reconcile_model: str | None,
    concurrency: int,
    fallback_model: str | None = None,
) -> int:
    print(f"Reading corpus from {source.name}...", flush=True)
    text = read_corpus(source)
    chars = len(text)
    print(f"  {chars:,} chars", flush=True)

    extractor = Extractor(
        model=model,
        api_key=api_key,
        base_url=base_url,
        max_chunk_chars=max_chunk_chars,
        reconcile_model=reconcile_model,
        concurrency=concurrency,
        fallback_model=fallback_model,
    )
    if fallback_model:
        print(
            f"  fallback model: {fallback_model} "
            f"(after {extractor.fallback_after_attempt} retries)",
            flush=True,
        )

    # Skip extraction if memories are already populated — lets a prior crash
    # during the chunk-embed phase recover without re-paying for extraction.
    if store.count() > 0:
        print(
            f"Skipping extraction: store already has {store.count()} memories.",
            flush=True,
        )
    else:
        persisted = {"count": 0}

        def on_chunk_persist(idx: int, mems: list) -> None:
            # Persist (and embed) each chunk's memories the moment its API call
            # returns. A later chunk's failure can no longer wipe earlier work.
            if mems:
                store.add(mems, conversation_id=source.stem)
                persisted["count"] += len(mems)

        def on_extract(i: int, total: int, n: int) -> None:
            print(
                f"  extract chunk {i}/{total} -> {n} memories "
                f"(persisted: {persisted['count']})",
                flush=True,
            )

        def on_reconcile(i: int, total: int, n: int) -> None:
            print(f"  reconcile window {i}/{total} -> {n} supersedes", flush=True)

        print(f"Extracting (model={model})...", flush=True)
        t0 = time.monotonic()
        result = extractor.extract(
            text,
            conversation_id=source.stem,
            progress=on_extract,
            reconcile_progress=on_reconcile,
            on_chunk=on_chunk_persist,
        )
        print(
            f"  {len(result.memories)} memories in {time.monotonic() - t0:.1f}s "
            f"(persisted: {persisted['count']})",
            flush=True,
        )

        # Reconciliation runs after all chunks; any supersedes it added aren't in
        # the store yet. Push them in via the supersedes-only path so we don't
        # re-embed everything.
        super_count = sum(1 for m in result.memories if m.supersedes)
        if super_count:
            print(
                f"Writing {super_count} supersedes links from reconciliation...",
                flush=True,
            )
            for m in result.memories:
                if m.supersedes:
                    store.update_supersedes(m.id, m.supersedes)

    # Persist raw chunks alongside memories (Tier 2 / verbatim recall).
    if store.chunk_count() == 0:
        print("Persisting raw chunks for verbatim-recall fallback...", flush=True)
        t0 = time.monotonic()
        planned = extractor.plan_chunks(text)
        chunk_records: list[Chunk] = []
        offset = 0
        for i, turn_list in enumerate(planned):
            raw = "\n\n".join(t.content for t in turn_list)
            chunk_records.append(
                Chunk(
                    id=f"{source.stem}:chunk:{i:04d}",
                    conversation_id=source.stem,
                    sequence=i,
                    content=raw,
                    char_offset_start=offset,
                    char_offset_end=offset + len(raw),
                )
            )
            offset += len(raw)

        def on_embed(done: int, total: int) -> None:
            elapsed = time.monotonic() - t0
            print(
                f"  embed chunks {done}/{total} ({elapsed:.1f}s)",
                flush=True,
            )

        n = store.add_chunks(
            chunk_records, conversation_id=source.stem, progress=on_embed
        )
        print(
            f"  added {n} chunks in {time.monotonic() - t0:.1f}s",
            flush=True,
        )

    return store.count()


SYNTH_SYSTEM_PROMPT = """You answer questions using ONLY the provided context.

Rules:
  - Be concise — typically a few words to one sentence. No prose, no preamble.
  - Use ONLY information present in the context. Do not infer beyond it, do not supply outside knowledge.
  - If the context is insufficient to answer, respond with exactly: I don't know.

Examples:

Question: Who is Helena's father?
Context:
- Gerard de Narbon was a highly skilled physician and the father of Helena.
- Helena travels to Paris to offer a medicinal prescription from her father.

Answer: Gerard de Narbon

---

Question: What ailment plagues the King of France?
Context:
- The King of France suffers from a fistula that his physicians have declared incurable.

Answer: An incurable fistula

---

Question: Who painted the Mona Lisa?
Context:
- Bertram is the young Count of Rousillon.
- Helena cures the King.

Answer: I don't know
"""


GRADE_SYSTEM_PROMPT = """You grade whether candidate answers match the expected answer to a question.

A candidate matches if it conveys the same factual content as the expected answer. Allow paraphrases, additional surrounding context, or different phrasing. Reject candidates that contradict the expected answer, are missing the critical fact, or substitute a different fact.

"I don't know" is always a non-match.

Output ONLY a single JSON object, no prose, no markdown fences:
{"verdicts": [{"id": "<id>", "match": true|false}, ...]}

Examples:

Question: "Who is Helena's father?"
Expected: "Gerard de Narbon"
Candidates:
[c1] Gerard de Narbon
[c2] her father, a physician
[c3] I don't know

Output:
{"verdicts": [
  {"id": "c1", "match": true},
  {"id": "c2", "match": false},
  {"id": "c3", "match": false}
]}
"""


def judge_substring_fn(answer: str, memory_content: str) -> bool:
    a = answer.strip().lower()
    return bool(a) and a in memory_content.lower()


class Judge:
    """LLM mode: synthesize an answer from each mode's top-k context and grade
    it against the gold answer. The substring path stays as a deterministic
    relevance check used to compute recall@k diagnostics in both modes.
    """

    def __init__(
        self,
        mode: str = "substring",
        client: OpenAI | None = None,
        llm_model: str | None = None,
        cache_system_prompt: bool = True,
    ):
        self.mode = mode
        self.client = client
        self.llm_model = llm_model
        self.cache_system_prompt = cache_system_prompt
        # synthesis cache: (question, "|".join(mem_id ordered)) -> answer
        self.synth_cache: dict[tuple[str, str], str] = {}
        self.api_calls = 0
        self.fallback_count = 0

    # Used for recall@k diagnostics in both modes.
    def is_relevant_substring(self, gold_answer: str, mem_content: str) -> bool:
        return judge_substring_fn(gold_answer, mem_content)

    def synthesize(
        self,
        question: str,
        memories: list,
    ) -> str:
        """Generate an answer to ``question`` using only the given memories
        as context. Returns the predicted answer string.
        """
        if self.mode != "llm" or self.client is None:
            raise RuntimeError("synthesize requires --judge llm")
        signature = "|".join(m.id for m in memories)
        key = (question, signature)
        if key in self.synth_cache:
            return self.synth_cache[key]
        context = "\n".join(f"- {m.content}" for m in memories) or "(empty)"
        user = f"Question: {question}\n\nContext:\n{context}\n\nAnswer:"
        try:
            resp = self._call(SYNTH_SYSTEM_PROMPT, user)
        except Exception as e:
            print(
                f"  synth LLM call failed ({type(e).__name__}: {e}); "
                f"recording 'I don't know' for this candidate",
                file=sys.stderr,
            )
            self.fallback_count += 1
            answer = "I don't know"
            self.synth_cache[key] = answer
            return answer
        answer = (resp.choices[0].message.content or "").strip()
        self.synth_cache[key] = answer
        return answer

    def grade_batch(
        self,
        question: str,
        gold_answer: str,
        candidates: dict[str, str],
    ) -> dict[str, bool]:
        """Grade candidate answers in one LLM call. Keys are arbitrary ids
        (e.g. mode names) used to map verdicts back to their source.
        """
        if self.mode != "llm" or self.client is None:
            raise RuntimeError("grade_batch requires --judge llm")
        if not candidates:
            return {}
        # Dedupe by answer string — many modes will produce the same answer.
        # Grade the unique strings, then fan out the verdicts.
        answer_to_ids: dict[str, list[str]] = {}
        for cid, ans in candidates.items():
            answer_to_ids.setdefault(ans, []).append(cid)
        unique = list(answer_to_ids.keys())
        items_text = "\n".join(f'[c{i}] "{ans}"' for i, ans in enumerate(unique))
        user = (
            f"Question: {question}\n"
            f'Expected: "{gold_answer}"\n\n'
            f"Candidates:\n{items_text}"
        )
        try:
            resp = self._call(GRADE_SYSTEM_PROMPT, user)
        except Exception as e:
            print(
                f"  grade LLM call failed ({type(e).__name__}: {e}); "
                f"falling back to substring for this question",
                file=sys.stderr,
            )
            self.fallback_count += 1
            return {
                cid: judge_substring_fn(gold_answer, ans)
                for cid, ans in candidates.items()
            }
        content = resp.choices[0].message.content or ""
        data = _parse_json(content)
        if not isinstance(data, dict) or not isinstance(data.get("verdicts"), list):
            print(
                f"  grade returned malformed output; falling back to substring",
                file=sys.stderr,
            )
            self.fallback_count += 1
            return {
                cid: judge_substring_fn(gold_answer, ans)
                for cid, ans in candidates.items()
            }
        # Map [c0], [c1], ... -> match
        unique_verdicts: dict[int, bool] = {}
        for v in data["verdicts"]:
            if not isinstance(v, dict):
                continue
            cid = v.get("id")
            match = v.get("match")
            if isinstance(cid, str) and cid.startswith("c") and isinstance(match, bool):
                try:
                    idx = int(cid[1:])
                except ValueError:
                    continue
                unique_verdicts[idx] = match
        out: dict[str, bool] = {}
        for i, ans in enumerate(unique):
            verdict = unique_verdicts.get(i, False)
            for cid in answer_to_ids[ans]:
                out[cid] = verdict
        return out

    def _call(self, system_prompt: str, user: str):
        sys_content: object = system_prompt
        if self.cache_system_prompt:
            sys_content = [
                {
                    "type": "text",
                    "text": system_prompt,
                    "cache_control": {"type": "ephemeral"},
                }
            ]
        assert self.client is not None
        assert self.llm_model is not None
        self.api_calls += 1
        resp = self.client.chat.completions.create(
            model=self.llm_model,
            messages=[
                {"role": "system", "content": sys_content},
                {"role": "user", "content": user},
            ],
        )
        if not resp.choices:
            raise RuntimeError("judge model returned no choices")
        return resp


@dataclass
class Candidate:
    """Unified retrieval result. ``kind`` is "memory" or "chunk", letting the
    eval treat memory-tier and chunk-tier results identically downstream
    (synthesis, substring rank, output shape).
    """

    id: str
    content: str
    kind: str
    score: float
    mem_type: str | None = None


def find_substring_rank(gold_answer: str, candidates: list[Candidate]) -> int | None:
    for i, c in enumerate(candidates):
        if judge_substring_fn(gold_answer, c.content):
            return i + 1
    return None


def search_in_mode_tier(
    store: MemoryStore,
    query: str,
    mode: str,
    k: int,
    tier: str,
) -> list[Candidate]:
    """Run retrieval in the requested mode and return a unified Candidate list.
    ``tier`` selects which side of the store to search:
      - "memories": atomic memory tier only.
      - "chunks":   raw text tier only (verbatim recall).
      - "both":     memories + chunks; chunks at half-k by default.
    """
    if tier not in ("memories", "chunks", "both"):
        raise ValueError(f"unknown tier: {tier!r}")
    out: list[Candidate] = []

    if tier in ("memories", "both"):
        if mode == "keyword":
            mr = store.search_keyword(query, k=k)
        elif mode == "fuzzy":
            mr = store.search_fuzzy(query, k=k)
        elif mode == "vector":
            mr = store.search_vector(query, k=k)
        elif mode == "hybrid":
            mr = store.search(query, k=k)
        else:
            raise ValueError(f"unknown mode: {mode!r}")
        for m, s in mr:
            out.append(
                Candidate(
                    id=m.id,
                    content=m.content,
                    kind="memory",
                    score=float(s),
                    mem_type=m.type.value,
                )
            )

    if tier in ("chunks", "both"):
        ck = max(1, k // 2) if tier == "both" else k
        if mode == "keyword":
            cr = store.search_chunks_keyword(query, k=ck)
        elif mode == "fuzzy":
            cr = store.search_chunks_fuzzy(query, k=ck)
        elif mode == "vector":
            cr = store.search_chunks_vector(query, k=ck)
        elif mode == "hybrid":
            cr = store.search_chunks(query, k=ck)
        else:
            raise ValueError(f"unknown mode: {mode!r}")
        for c, s in cr:
            out.append(
                Candidate(
                    id=c.id,
                    content=c.content,
                    kind="chunk",
                    score=float(s),
                )
            )

    return out


def compute_ceiling(store: MemoryStore, questions: list[dict], tier: str) -> int:
    """Questions whose answer appears as a substring in any stored content
    in the active tier. Substring is a cheap proxy — paraphrases the LLM
    judge would credit aren't counted, so this is a lower bound.
    """
    contents: list[str] = []
    if tier in ("memories", "both"):
        contents.extend(m.content.lower() for m in store.all(include_superseded=True))
    if tier in ("chunks", "both"):
        rows = store.db.execute("SELECT content FROM chunks").fetchall()
        contents.extend(r["content"].lower() for r in rows)
    hits = 0
    for q in questions:
        ans = q.get("answer", "").strip().lower()
        if not ans:
            continue
        if any(ans in c for c in contents):
            hits += 1
    return hits


def run_eval(
    store: MemoryStore,
    questions: list[dict],
    modes: list[str],
    k: int,
    judge: Judge,
    tier: str,
) -> list[dict]:
    # Phase 1: run retrieval for every question x mode, collect raw top-k.
    raw: list[dict] = []
    t_start = time.monotonic()
    for i, q in enumerate(questions):
        question_text = q.get("question", "")
        answer = q.get("answer", "")
        per_mode: dict[str, dict] = {}
        for mode in modes:
            try:
                candidates = search_in_mode_tier(store, question_text, mode, k, tier)
            except RuntimeError as e:
                per_mode[mode] = {"error": str(e)}
                continue
            per_mode[mode] = {"candidates": candidates}
        raw.append(
            {
                "question": question_text,
                "answer": answer,
                "needle": q.get("needle", ""),
                "batch": q.get("batch"),
                "modes": per_mode,
            }
        )
        if (i + 1) % 25 == 0 or i + 1 == len(questions):
            elapsed = time.monotonic() - t_start
            print(
                f"  retrieval: {i + 1}/{len(questions)} ({elapsed:.1f}s)",
                flush=True,
            )

    # Phase 2 (LLM mode only): synthesize an answer per (question, mode) using
    # that mode's top-k as context, then batch-grade all four mode answers in
    # one call per question. The substring path skips this entirely.
    if judge.mode == "llm":
        print("Synthesizing answers per (question, mode)...", flush=True)
        t_synth = time.monotonic()
        for i, rec in enumerate(raw):
            for mode, data in rec["modes"].items():
                if "candidates" not in data:
                    continue
                data["predicted_answer"] = judge.synthesize(
                    rec["question"], data["candidates"]
                )
            if (i + 1) % 10 == 0 or i + 1 == len(raw):
                elapsed = time.monotonic() - t_synth
                print(
                    f"  synth: {i + 1}/{len(raw)} ({elapsed:.1f}s, "
                    f"{judge.api_calls} api calls)",
                    flush=True,
                )

        print("Grading answers vs. gold...", flush=True)
        t_grade = time.monotonic()
        for i, rec in enumerate(raw):
            mode_answers = {
                mode: data["predicted_answer"]
                for mode, data in rec["modes"].items()
                if "predicted_answer" in data
            }
            verdicts = judge.grade_batch(rec["question"], rec["answer"], mode_answers)
            for mode, match in verdicts.items():
                rec["modes"][mode]["match"] = match
            if (i + 1) % 25 == 0 or i + 1 == len(raw):
                elapsed = time.monotonic() - t_grade
                print(
                    f"  grade: {i + 1}/{len(raw)} ({elapsed:.1f}s)",
                    flush=True,
                )

    # Phase 3: shape the per-question record. We always compute a substring
    # rank as a free retrieval-quality diagnostic regardless of judge mode.
    per_question: list[dict] = []
    for rec in raw:
        out_modes: dict[str, dict] = {}
        for mode, data in rec["modes"].items():
            if "error" in data:
                out_modes[mode] = {"error": data["error"]}
                continue
            candidates: list[Candidate] = data["candidates"]
            sub_rank = find_substring_rank(rec["answer"], candidates)
            entry: dict = {
                "rank": sub_rank,
                "hit": sub_rank is not None,
                "top_k": [
                    {
                        "id": c.id,
                        "kind": c.kind,
                        "type": c.mem_type,
                        # Truncate chunk content for output readability —
                        # chunks can be many KB; the full text is in the DB.
                        "content": (
                            c.content
                            if c.kind == "memory" or len(c.content) <= 500
                            else c.content[:500] + "..."
                        ),
                        "score": c.score,
                        "contains_answer": judge.is_relevant_substring(
                            rec["answer"], c.content
                        ),
                    }
                    for c in candidates
                ],
            }
            if "predicted_answer" in data:
                entry["predicted_answer"] = data["predicted_answer"]
                entry["match"] = bool(data.get("match", False))
            out_modes[mode] = entry
        per_question.append(
            {
                "question": rec["question"],
                "answer": rec["answer"],
                "needle": rec["needle"],
                "batch": rec["batch"],
                "modes": out_modes,
            }
        )
    return per_question


def aggregate(
    per_question: list[dict], modes: list[str], k: int, judge_mode: str
) -> dict[str, dict]:
    n = len(per_question)
    totals: dict[str, dict] = {}
    cutoffs = [c for c in (1, 3, 5, 10) if c <= k]
    for mode in modes:
        evaluated = 0
        ranks: list[int | None] = []
        matches: list[bool] = []
        for rec in per_question:
            r = rec["modes"].get(mode, {})
            if "error" in r:
                continue
            evaluated += 1
            ranks.append(r.get("rank"))
            if "match" in r:
                matches.append(bool(r["match"]))
        recall_at = {
            f"recall@{c}": sum(1 for r in ranks if r is not None and r <= c) / n
            if n
            else 0.0
            for c in cutoffs
        }
        mrr = sum(1.0 / r for r in ranks if r is not None) / n if n else 0.0
        entry: dict = {
            **recall_at,
            "mrr": mrr,
            "evaluated": evaluated,
            "hits": sum(1 for r in ranks if r is not None),
        }
        if judge_mode == "llm":
            entry["accuracy"] = sum(matches) / n if n else 0.0
            entry["correct"] = sum(matches)
        totals[mode] = entry
    return totals


def print_summary(
    totals: dict[str, dict],
    modes: list[str],
    k: int,
    n_questions: int,
    ceiling: int,
    judge_mode: str,
) -> None:
    cutoffs = [c for c in (1, 3, 5, 10) if c <= k]
    has_accuracy = judge_mode == "llm"

    headers = ["Mode"]
    if has_accuracy:
        headers.append("Accuracy")
    headers += [f"R@{c}" for c in cutoffs] + ["MRR", "Hits"]
    widths = [10]
    if has_accuracy:
        widths.append(9)
    widths += [7] * len(cutoffs) + [7, 7]
    sep = "  ".join("-" * w for w in widths)
    line = "  ".join(
        f"{h:<{w}}" if i == 0 else f"{h:>{w}}"
        for i, (h, w) in enumerate(zip(headers, widths))
    )
    print()
    print(line)
    print(sep)
    for mode in modes:
        t = totals.get(mode, {})
        if not t:
            continue
        cells = [mode]
        if has_accuracy:
            cells.append(f"{t.get('accuracy', 0):.3f}")
        for c in cutoffs:
            cells.append(f"{t.get(f'recall@{c}', 0):.3f}")
        cells.append(f"{t.get('mrr', 0):.3f}")
        cells.append(f"{t.get('hits', 0)}/{t.get('evaluated', 0)}")
        print(
            "  ".join(
                f"{cell:<{w}}" if i == 0 else f"{cell:>{w}}"
                for i, (cell, w) in enumerate(zip(cells, widths))
            )
        )
    print()
    if has_accuracy:
        print(
            "Accuracy = fraction of questions where an LLM answering from "
            "the mode's top-k context produced an answer judged to match "
            "the gold answer."
        )
        print(
            "R@k / MRR / Hits use deterministic substring matching as a "
            "free retrieval-quality diagnostic."
        )
        print()
    ceiling_pct = (ceiling / n_questions * 100) if n_questions else 0
    print(
        f"Extraction ceiling (substring): {ceiling}/{n_questions} "
        f"({ceiling_pct:.1f}%) — answer string present in at least one memory."
    )
    print(
        "  This bounds R@k from above. Accuracy can exceed it when the "
        "synthesizer paraphrases or combines partial information."
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="One-shot Memotether retrieval eval over a haystack questions JSON.",
    )
    parser.add_argument(
        "questions",
        type=Path,
        help="Haystack questions JSON (output of generate_haystack_questions.py)",
    )
    parser.add_argument(
        "--db",
        type=Path,
        default=None,
        help="SQLite store path. Default: <questions-stem>.db next to the JSON.",
    )
    parser.add_argument(
        "--source",
        type=Path,
        default=None,
        help="Override the corpus path (PDF or text). "
        "Default: resolved from the JSON's 'input_path' field.",
    )
    parser.add_argument(
        "--embedder",
        default="nomic",
        help="Embedder spec: 'nomic' (default, local), 'openai', "
        "'nomic:<model>', 'openai:<model>', or 'none' to disable.",
    )
    parser.add_argument(
        "--modes",
        default="keyword,fuzzy,vector,hybrid",
        help="Comma-separated retrieval modes to evaluate.",
    )
    parser.add_argument(
        "--tier",
        choices=["memories", "chunks", "both"],
        default="memories",
        help="Retrieval tier. 'memories' (default) = compressed atomic tier "
        "only. 'chunks' = raw text tier (verbatim recall). 'both' = "
        "memories + half-k chunks (memory-layer with verbatim fallback).",
    )
    parser.add_argument("-k", "--top-k", type=int, default=10)
    parser.add_argument(
        "--out",
        type=Path,
        default=None,
        help="Detailed JSON output. Default: <questions-stem>_results.json.",
    )
    parser.add_argument(
        "--limit", type=int, default=None, help="Evaluate only first N questions."
    )
    parser.add_argument(
        "--force-reingest",
        action="store_true",
        help="Re-extract from source even if the DB already has memories.",
    )
    parser.add_argument(
        "--no-reembed",
        action="store_true",
        help="Skip auto re-embed even when embedder dim doesn't match stored dim.",
    )
    parser.add_argument(
        "--concurrency",
        type=int,
        default=8,
        help="Parallel API calls during ingestion (default 8). "
        "Applies to both extraction chunks and reconciliation windows. "
        "Lower if you hit OpenRouter rate limits.",
    )
    parser.add_argument(
        "--fallback-model",
        default=None,
        help="Model to swap to after repeated transient failures on the "
        "primary. Defaults to MEMOTETHER_FALLBACK_MODEL or 'xiaomi/mimo-v2.5-pro'. "
        "Pass 'none' to disable fallback.",
    )
    parser.add_argument(
        "--judge",
        choices=["substring", "llm"],
        default="substring",
        help="Relevance judge. 'substring' = case-insensitive answer substring "
        "(fast, deterministic). 'llm' = batched LLM grader (one call per "
        "question, more reliable on paraphrase).",
    )
    parser.add_argument(
        "--judge-model",
        default=None,
        help="Model id for --judge llm. Falls back to MEMOTETHER_JUDGE_MODEL, "
        "MEMOTETHER_RECONCILE_MODEL, then MEMOTETHER_MODEL.",
    )
    parser.add_argument(
        "--no-cache-judge",
        action="store_true",
        help="Disable Anthropic prompt caching on the judge system prompt.",
    )
    args = parser.parse_args()

    load_dotenv()

    if not args.questions.exists():
        print(f"error: questions file not found: {args.questions}", file=sys.stderr)
        return 2

    questions, qmeta = load_questions(args.questions)
    if not questions:
        print(f"error: no questions in {args.questions}", file=sys.stderr)
        return 2
    if args.limit:
        questions = questions[: args.limit]

    db_path = args.db or args.questions.with_suffix(".db")
    out_path = args.out or args.questions.with_name(
        f"{args.questions.stem}_results.json"
    )

    embedder_spec: str | None = args.embedder
    if embedder_spec and embedder_spec.lower() == "none":
        embedder_spec = None
    embedder = resolve_embedder(embedder_spec) if embedder_spec else None

    store = MemoryStore(db_path, embedder=embedder)

    if args.force_reingest and (store.count() > 0 or store.chunk_count() > 0):
        print(
            f"--force-reingest: clearing {store.count()} memories + "
            f"{store.chunk_count()} chunks..."
        )
        store.db.execute("DELETE FROM memories")
        store.db.execute("DELETE FROM memories_fts")
        store.db.execute("DELETE FROM memories_trigram")
        store.db.execute("DELETE FROM supersedes")
        store.db.execute("DELETE FROM chunks")
        store.db.execute("DELETE FROM chunks_fts")
        store.db.execute("DELETE FROM chunks_trigram")
        store.db.commit()

    if store.count() == 0 or store.chunk_count() == 0:
        # Ingestion path — needs API key + extractor config from env.
        try:
            ingest_api_key = os.environ["OPENROUTER_API_KEY"]
            ingest_model = os.environ["MEMOTETHER_MODEL"]
            ingest_base_url = os.environ["MEMOTETHER_BASE_URL"]
            ingest_max_chunk = int(os.environ["MEMOTETHER_MAX_CHUNK_CHARS"])
        except KeyError as e:
            print(
                f"error: ingestion requires {e.args[0]} in env "
                f"(or pass an existing --db)",
                file=sys.stderr,
            )
            return 2
        ingest_reconcile = os.environ.get("MEMOTETHER_RECONCILE_MODEL")
        fallback_spec = (
            args.fallback_model
            or os.environ.get("MEMOTETHER_FALLBACK_MODEL")
            or "xiaomi/mimo-v2.5-pro"
        )
        ingest_fallback = None if fallback_spec.lower() == "none" else fallback_spec

        if args.source:
            source_path = args.source
            if not source_path.exists():
                print(f"error: --source not found: {source_path}", file=sys.stderr)
                return 2
        else:
            input_path = qmeta.get("input_path")
            if not input_path:
                print(
                    "error: questions JSON has no 'input_path'; pass --source",
                    file=sys.stderr,
                )
                return 2
            try:
                source_path = resolve_source_path(input_path, args.questions)
            except FileNotFoundError as e:
                print(f"error: {e}", file=sys.stderr)
                return 2

        ingest_source(
            source_path,
            store,
            model=ingest_model,
            api_key=ingest_api_key,
            base_url=ingest_base_url,
            max_chunk_chars=ingest_max_chunk,
            reconcile_model=ingest_reconcile,
            concurrency=args.concurrency,
            fallback_model=ingest_fallback,
        )

    requested_modes = [m.strip() for m in args.modes.split(",") if m.strip()]
    needs_vector = any(m in ("vector", "hybrid") for m in requested_modes)

    if embedder is not None and needs_vector and not args.no_reembed:
        try:
            probe_dim = len(embedder("dim probe"))
        except Exception:
            probe_dim = None
        dim_counts = store.embedding_dim_counts()
        total = store.count()
        if probe_dim and dim_counts.get(probe_dim, 0) < total:
            print(f"Re-embedding {total} memories ({dim_counts} -> dim {probe_dim})...")
            t0 = time.monotonic()
            n = store.reembed_all()
            print(f"  re-embedded {n} in {time.monotonic() - t0:.1f}s")

    if "vector" in requested_modes and embedder is None:
        print("(skipping vector mode: no embedder configured)")
        requested_modes = [m for m in requested_modes if m != "vector"]
    if "hybrid" in requested_modes and embedder is None:
        # Hybrid still works without vectors — store.search drops the vector
        # arm internally — but mention it so the user knows.
        print("(hybrid will run without vector arm: no embedder configured)")

    print()
    print(
        f"Store:    {store.path} ({store.count()} memories, "
        f"{store.chunk_count()} chunks)"
    )
    print(f"Modes:    {', '.join(requested_modes)}")
    print(f"Tier:     {args.tier}")
    print(f"k:        {args.top_k}")
    print(f"Question: {len(questions)}")
    print()

    if args.tier in ("chunks", "both") and store.chunk_count() == 0:
        print(
            f"error: --tier {args.tier} but store has no chunks. "
            "Re-ingest with --force-reingest to populate the chunk tier.",
            file=sys.stderr,
        )
        return 2

    print("Computing extraction ceiling...", flush=True)
    ceiling = compute_ceiling(store, questions, args.tier)
    print(
        f"  ceiling ({args.tier}): {ceiling}/{len(questions)} "
        f"answers present somewhere\n"
    )

    judge: Judge
    if args.judge == "llm":
        judge_model = (
            args.judge_model
            or os.environ.get("MEMOTETHER_JUDGE_MODEL")
            or os.environ.get("MEMOTETHER_RECONCILE_MODEL")
            or os.environ.get("MEMOTETHER_MODEL")
        )
        if not judge_model:
            print(
                "error: --judge llm requires MEMOTETHER_MODEL (or MEMOTETHER_JUDGE_MODEL / "
                "MEMOTETHER_RECONCILE_MODEL) in env, or pass --judge-model",
                file=sys.stderr,
            )
            return 2
        try:
            api_key = os.environ["OPENROUTER_API_KEY"]
            base_url = os.environ["MEMOTETHER_BASE_URL"]
        except KeyError as e:
            print(
                f"error: --judge llm requires {e.args[0]} in env",
                file=sys.stderr,
            )
            return 2
        judge_client = OpenAI(api_key=api_key, base_url=base_url)
        judge = Judge(
            mode="llm",
            client=judge_client,
            llm_model=judge_model,
            cache_system_prompt=not args.no_cache_judge,
        )
        print(f"Judge:    llm (model: {judge_model})\n")
    else:
        judge = Judge(mode="substring")
        print("Judge:    substring\n")

    print("Running retrieval eval...", flush=True)
    per_question = run_eval(
        store, questions, requested_modes, args.top_k, judge, args.tier
    )
    totals = aggregate(per_question, requested_modes, args.top_k, judge.mode)

    print_summary(
        totals, requested_modes, args.top_k, len(questions), ceiling, judge.mode
    )

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(
            {
                "questions_path": str(args.questions),
                "store_path": str(store.path),
                "memories_count": store.count(),
                "chunks_count": store.chunk_count(),
                "modes": requested_modes,
                "tier": args.tier,
                "k": args.top_k,
                "embedder": embedder_spec,
                "judge": args.judge,
                "judge_model": (judge.llm_model if judge.mode == "llm" else None),
                "judge_api_calls": judge.api_calls,
                "judge_fallbacks": judge.fallback_count,
                "ceiling_count": ceiling,
                "ceiling_rate": ceiling / len(questions),
                "totals": totals,
                "per_question": per_question,
            },
            indent=2,
            default=str,
        )
    )
    print(f"\nDetailed results: {out_path}")

    store.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
