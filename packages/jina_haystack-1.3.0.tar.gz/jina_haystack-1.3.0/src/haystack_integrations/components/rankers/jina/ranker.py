# SPDX-FileCopyrightText: 2023-present deepset GmbH <info@deepset.ai>
#
# SPDX-License-Identifier: Apache-2.0
from dataclasses import replace
from typing import Any

import httpx
from haystack import Document, component, default_from_dict, default_to_dict
from haystack.utils import Secret, deserialize_secrets_inplace

JINA_API_URL: str = "https://api.jina.ai/v1/rerank"


@component
class JinaRanker:
    """
    Ranks Documents based on their similarity to the query using Jina AI models.

    Usage example:
    ```python
    from haystack import Document
    from haystack_integrations.components.rankers.jina import JinaRanker

    ranker = JinaRanker()
    docs = [Document(content="Paris"), Document(content="Berlin")]
    query = "City in Germany"
    result = ranker.run(query=query, documents=docs)
    docs = result["documents"]
    print(docs[0].content)
    ```
    """

    def __init__(
        self,
        model: str = "jina-reranker-v1-base-en",
        api_key: Secret = Secret.from_env_var("JINA_API_KEY"),  # noqa: B008,
        top_k: int | None = None,
        score_threshold: float | None = None,
        *,
        base_url: str = JINA_API_URL,
    ) -> None:
        """
        Creates an instance of JinaRanker.

        :param api_key: The Jina API key. It can be explicitly provided or automatically read from the
            environment variable JINA_API_KEY (recommended).
        :param model: The name of the Jina model to use. Check the list of available models on `https://jina.ai/reranker/`
        :param top_k:
            The maximum number of Documents to return per query. If `None`, all documents are returned
        :param score_threshold:
            If provided only returns documents with a score above this threshold.
        :param base_url: The base URL of the Jina API.

        :raises ValueError:
            If `top_k` is not > 0.
        """
        # if the user does not provide the API key, check if it is set in the module client
        resolved_api_key = api_key.resolve_value()
        self.api_key = api_key
        self.model = model
        self.top_k = top_k
        self.score_threshold = score_threshold
        self.base_url = base_url

        if self.top_k is not None and self.top_k <= 0:
            msg = f"top_k must be > 0, but got {top_k}"
            raise ValueError(msg)

        self._headers = {
            "Authorization": f"Bearer {resolved_api_key}",
            "Accept-Encoding": "identity",
            "Content-type": "application/json",
        }

    def to_dict(self) -> dict[str, Any]:
        """
        Serializes the component to a dictionary.

        :returns:
            Dictionary with serialized data.
        """
        return default_to_dict(
            self,
            api_key=self.api_key.to_dict(),
            model=self.model,
            base_url=self.base_url,
            top_k=self.top_k,
            score_threshold=self.score_threshold,
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "JinaRanker":
        """
        Deserializes the component from a dictionary.

        :param data:
            Dictionary to deserialize from.
        :returns:
            Deserialized component.
        """
        deserialize_secrets_inplace(data["init_parameters"], keys=["api_key"])
        return default_from_dict(cls, data)

    def _get_telemetry_data(self) -> dict[str, Any]:
        """
        Data that is sent to Posthog for usage analytics.
        """
        return {"model": self.model}

    def _prepare_request_data(
        self,
        query: str,
        documents: list[Document],
        top_k: int | None = None,
        score_threshold: float | None = None,
    ) -> tuple[dict[str, Any], int | None, float | None]:
        if top_k is not None and top_k <= 0:
            msg = f"top_k must be > 0, but got {top_k}"
            raise ValueError(msg)

        top_k = top_k or self.top_k
        score_threshold = score_threshold or self.score_threshold

        data = {
            "query": query,
            "documents": [doc.content or "" for doc in documents],
            "model": self.model,
            "top_n": top_k,
        }
        return data, top_k, score_threshold

    @staticmethod
    def _parse_response(
        resp: dict[str, Any],
        documents: list[Document],
        top_k: int | None,
        score_threshold: float | None,
    ) -> dict[str, Any]:
        if "results" not in resp:
            raise RuntimeError(resp["detail"])

        results = resp["results"]

        ranked_docs: list[Document] = []
        for result in results:
            index = result["index"]
            relevance_score = result["relevance_score"]
            doc = documents[index]
            if top_k is None or len(ranked_docs) < top_k:
                scored_doc = replace(doc, score=relevance_score)
                if score_threshold is not None:
                    if relevance_score >= score_threshold:
                        ranked_docs.append(scored_doc)
                else:
                    ranked_docs.append(scored_doc)
            else:
                break

        return {"documents": ranked_docs, "meta": {"model": resp["model"], "usage": resp["usage"]}}

    @component.output_types(documents=list[Document])
    def run(
        self,
        query: str,
        documents: list[Document],
        top_k: int | None = None,
        score_threshold: float | None = None,
    ) -> dict[str, list[Document]]:
        """
        Returns a list of Documents ranked by their similarity to the given query.

        :param query:
            Query string.
        :param documents:
            List of Documents.
        :param top_k:
            The maximum number of Documents you want the Ranker to return.
        :param score_threshold:
            If provided only returns documents with a score above this threshold.
        :returns:
            A dictionary with the following keys:
            - `documents`: List of Documents most similar to the given query in descending order of similarity.

        :raises ValueError:
            If `top_k` is not > 0.
        """
        if not documents:
            return {"documents": []}

        data, top_k, score_threshold = self._prepare_request_data(query, documents, top_k, score_threshold)

        with httpx.Client() as client:
            response = client.post(self.base_url, json=data, headers=self._headers)
        resp = response.json()

        return self._parse_response(resp, documents, top_k, score_threshold)

    @component.output_types(documents=list[Document])
    async def run_async(
        self,
        query: str,
        documents: list[Document],
        top_k: int | None = None,
        score_threshold: float | None = None,
    ) -> dict[str, list[Document]]:
        """
        Asynchronously returns a list of Documents ranked by their similarity to the given query.

        This is the asynchronous version of the `run` method. It has the same parameters and return values
        but can be used with `await` in async code.

        :param query:
            Query string.
        :param documents:
            List of Documents.
        :param top_k:
            The maximum number of Documents you want the Ranker to return.
        :param score_threshold:
            If provided only returns documents with a score above this threshold.
        :returns:
            A dictionary with the following keys:
            - `documents`: List of Documents most similar to the given query in descending order of similarity.

        :raises ValueError:
            If `top_k` is not > 0.
        """
        if not documents:
            return {"documents": []}

        data, top_k, score_threshold = self._prepare_request_data(query, documents, top_k, score_threshold)

        async with httpx.AsyncClient() as client:
            response = await client.post(self.base_url, json=data, headers=self._headers)
        resp = response.json()

        return self._parse_response(resp, documents, top_k, score_threshold)
