# SPDX-FileCopyrightText: 2023-present deepset GmbH <info@deepset.ai>
#
# SPDX-License-Identifier: Apache-2.0
import os
from unittest.mock import patch

import httpx
import pytest
from haystack import Document
from haystack.utils import Secret

from haystack_integrations.components.embedders.jina import JinaDocumentEmbedder


def mock_httpx_post_response(*args, **kwargs):  # noqa: ARG001
    inputs = kwargs["json"]["input"]
    model = kwargs["json"]["model"]
    data = [{"object": "embedding", "index": i, "embedding": [0.1, 0.2, 0.3]} for i in range(len(inputs))]
    return httpx.Response(
        200,
        json={"model": model, "object": "list", "usage": {"total_tokens": 4, "prompt_tokens": 4}, "data": data},
    )


class TestJinaDocumentEmbedder:
    def test_init_default(self, monkeypatch):
        monkeypatch.setenv("JINA_API_KEY", "fake-api-key")
        embedder = JinaDocumentEmbedder()

        assert embedder.api_key == Secret.from_env_var("JINA_API_KEY")
        assert embedder.model_name == "jina-embeddings-v3"
        assert embedder.base_url == "https://api.jina.ai/v1/embeddings"
        assert embedder.prefix == ""
        assert embedder.suffix == ""
        assert embedder.batch_size == 32
        assert embedder.progress_bar is True
        assert embedder.meta_fields_to_embed == []
        assert embedder.embedding_separator == "\n"

    def test_init_with_parameters(self):
        embedder = JinaDocumentEmbedder(
            api_key=Secret.from_token("fake-api-key"),
            model="model",
            base_url="https://my.custom.url/v1/embeddings",
            prefix="prefix",
            suffix="suffix",
            batch_size=64,
            progress_bar=False,
            meta_fields_to_embed=["test_field"],
            embedding_separator=" | ",
            task="retrieval.query",
            dimensions=1024,
            late_chunking=True,
        )

        assert embedder.api_key == Secret.from_token("fake-api-key")
        assert embedder.model_name == "model"
        assert embedder.base_url == "https://my.custom.url/v1/embeddings"
        assert embedder.prefix == "prefix"
        assert embedder.suffix == "suffix"
        assert embedder.batch_size == 64
        assert embedder.progress_bar is False
        assert embedder.meta_fields_to_embed == ["test_field"]
        assert embedder.embedding_separator == " | "
        assert embedder.task == "retrieval.query"
        assert embedder.dimensions == 1024
        assert embedder.late_chunking is True

    def test_init_fail_wo_api_key(self, monkeypatch):
        monkeypatch.delenv("JINA_API_KEY", raising=False)
        with pytest.raises(ValueError):
            JinaDocumentEmbedder()

    def test_to_dict(self, monkeypatch):
        monkeypatch.setenv("JINA_API_KEY", "fake-api-key")
        component = JinaDocumentEmbedder()
        data = component.to_dict()
        assert data == {
            "type": "haystack_integrations.components.embedders.jina.document_embedder.JinaDocumentEmbedder",
            "init_parameters": {
                "api_key": {"env_vars": ["JINA_API_KEY"], "strict": True, "type": "env_var"},
                "model": "jina-embeddings-v3",
                "base_url": "https://api.jina.ai/v1/embeddings",
                "prefix": "",
                "suffix": "",
                "batch_size": 32,
                "progress_bar": True,
                "meta_fields_to_embed": [],
                "embedding_separator": "\n",
            },
        }

    def test_to_dict_with_custom_init_parameters(self, monkeypatch):
        monkeypatch.setenv("JINA_API_KEY", "fake-api-key")
        component = JinaDocumentEmbedder(
            model="model",
            base_url="https://my.custom.url/v1/embeddings",
            prefix="prefix",
            suffix="suffix",
            batch_size=64,
            progress_bar=False,
            meta_fields_to_embed=["test_field"],
            embedding_separator=" | ",
            task="retrieval.query",
            dimensions=1024,
        )
        data = component.to_dict()
        assert data == {
            "type": "haystack_integrations.components.embedders.jina.document_embedder.JinaDocumentEmbedder",
            "init_parameters": {
                "api_key": {"env_vars": ["JINA_API_KEY"], "strict": True, "type": "env_var"},
                "model": "model",
                "base_url": "https://my.custom.url/v1/embeddings",
                "prefix": "prefix",
                "suffix": "suffix",
                "batch_size": 64,
                "progress_bar": False,
                "meta_fields_to_embed": ["test_field"],
                "embedding_separator": " | ",
                "task": "retrieval.query",
                "dimensions": 1024,
            },
        }

    def test_prepare_texts_to_embed_w_metadata(self):
        documents = [
            Document(content=f"document number {i}:\ncontent", meta={"meta_field": f"meta_value {i}"}) for i in range(5)
        ]

        embedder = JinaDocumentEmbedder(
            api_key=Secret.from_token("fake-api-key"), meta_fields_to_embed=["meta_field"], embedding_separator=" | "
        )

        prepared_texts = embedder._prepare_texts_to_embed(documents)

        # note that newline is replaced by space
        assert prepared_texts == [
            "meta_value 0 | document number 0:\ncontent",
            "meta_value 1 | document number 1:\ncontent",
            "meta_value 2 | document number 2:\ncontent",
            "meta_value 3 | document number 3:\ncontent",
            "meta_value 4 | document number 4:\ncontent",
        ]

    def test_prepare_texts_to_embed_w_suffix(self):
        documents = [Document(content=f"document number {i}") for i in range(5)]

        embedder = JinaDocumentEmbedder(
            api_key=Secret.from_token("fake-api-key"), prefix="my_prefix ", suffix=" my_suffix"
        )

        prepared_texts = embedder._prepare_texts_to_embed(documents)

        assert prepared_texts == [
            "my_prefix document number 0 my_suffix",
            "my_prefix document number 1 my_suffix",
            "my_prefix document number 2 my_suffix",
            "my_prefix document number 3 my_suffix",
            "my_prefix document number 4 my_suffix",
        ]

    def test_embed_batch(self):
        texts = ["text 1", "text 2", "text 3", "text 4", "text 5"]

        with patch("httpx.Client.post", side_effect=mock_httpx_post_response):
            embedder = JinaDocumentEmbedder(api_key=Secret.from_token("fake-api-key"), model="model")

            embeddings, metadata = embedder._embed_batch(texts_to_embed=texts, batch_size=2)

        assert isinstance(embeddings, list)
        assert len(embeddings) == len(texts)
        for embedding in embeddings:
            assert isinstance(embedding, list)
            assert len(embedding) == 3
            assert all(isinstance(x, float) for x in embedding)

        assert metadata == {"model": "model", "usage": {"prompt_tokens": 3 * 4, "total_tokens": 3 * 4}}

    def test_run(self):
        docs = [
            Document(content="I love cheese", meta={"topic": "Cuisine"}),
            Document(content="A transformer is a deep learning architecture", meta={"topic": "ML"}),
        ]

        model = "jina-embeddings-v2-base-en"
        with patch("httpx.Client.post", side_effect=mock_httpx_post_response):
            embedder = JinaDocumentEmbedder(
                api_key=Secret.from_token("fake-api-key"),
                model=model,
                prefix="prefix ",
                suffix=" suffix",
                meta_fields_to_embed=["topic"],
                embedding_separator=" | ",
            )

            result = embedder.run(documents=docs)

        documents_with_embeddings = result["documents"]
        metadata = result["meta"]

        assert isinstance(documents_with_embeddings, list)
        assert len(documents_with_embeddings) == len(docs)
        for doc in documents_with_embeddings:
            assert isinstance(doc, Document)
            assert isinstance(doc.embedding, list)
            assert len(doc.embedding) == 3
            assert all(isinstance(x, float) for x in doc.embedding)
        assert metadata == {"model": model, "usage": {"prompt_tokens": 4, "total_tokens": 4}}

    def test_run_does_not_modify_original_documents(self):
        docs = [
            Document(content="I love cheese", meta={"topic": "Cuisine"}),
            Document(content="A transformer is a deep learning architecture", meta={"topic": "ML"}),
        ]

        model = "jina-embeddings-v2-base-en"
        with patch("httpx.Client.post", side_effect=mock_httpx_post_response):
            embedder = JinaDocumentEmbedder(
                api_key=Secret.from_token("fake-api-key"),
                model=model,
            )

            result = embedder.run(documents=docs)

        # originals remain unchanged
        for doc in docs:
            assert doc.embedding is None

        # returned docs carry embeddings
        for doc_with_embedding in result["documents"]:
            assert doc_with_embedding.embedding is not None

    def test_run_custom_batch_size(self):
        docs = [
            Document(content="I love cheese", meta={"topic": "Cuisine"}),
            Document(content="A transformer is a deep learning architecture", meta={"topic": "ML"}),
        ]
        model = "jina-embeddings-v2-base-en"
        with patch("httpx.Client.post", side_effect=mock_httpx_post_response):
            embedder = JinaDocumentEmbedder(
                api_key=Secret.from_token("fake-api-key"),
                model=model,
                prefix="prefix ",
                suffix=" suffix",
                meta_fields_to_embed=["topic"],
                embedding_separator=" | ",
                batch_size=1,
            )

            result = embedder.run(documents=docs)

        documents_with_embeddings = result["documents"]
        metadata = result["meta"]

        assert isinstance(documents_with_embeddings, list)
        assert len(documents_with_embeddings) == len(docs)
        for doc in documents_with_embeddings:
            assert isinstance(doc, Document)
            assert isinstance(doc.embedding, list)
            assert len(doc.embedding) == 3
            assert all(isinstance(x, float) for x in doc.embedding)

        assert metadata == {"model": model, "usage": {"prompt_tokens": 2 * 4, "total_tokens": 2 * 4}}

    def test_run_wrong_input_format(self):
        embedder = JinaDocumentEmbedder(api_key=Secret.from_token("fake-api-key"))

        string_input = "text"
        list_integers_input = [1, 2, 3]

        with pytest.raises(TypeError, match="JinaDocumentEmbedder expects a list of Documents as input"):
            embedder.run(documents=string_input)

        with pytest.raises(TypeError, match="JinaDocumentEmbedder expects a list of Documents as input"):
            embedder.run(documents=list_integers_input)

    def test_run_on_empty_list(self):
        embedder = JinaDocumentEmbedder(api_key=Secret.from_token("fake-api-key"))

        empty_list_input = []
        result = embedder.run(documents=empty_list_input)

        assert result["documents"] is not None
        assert not result["documents"]  # empty list

    @pytest.mark.asyncio
    async def test_run_async(self):
        docs = [
            Document(content="I love cheese", meta={"topic": "Cuisine"}),
            Document(content="A transformer is a deep learning architecture", meta={"topic": "ML"}),
        ]

        model = "jina-embeddings-v2-base-en"
        with patch("httpx.AsyncClient.post", side_effect=mock_httpx_post_response):
            embedder = JinaDocumentEmbedder(
                api_key=Secret.from_token("fake-api-key"),
                model=model,
                prefix="prefix ",
                suffix=" suffix",
                meta_fields_to_embed=["topic"],
                embedding_separator=" | ",
            )

            result = await embedder.run_async(documents=docs)

        documents_with_embeddings = result["documents"]
        metadata = result["meta"]

        assert isinstance(documents_with_embeddings, list)
        assert len(documents_with_embeddings) == len(docs)
        for doc in documents_with_embeddings:
            assert isinstance(doc, Document)
            assert isinstance(doc.embedding, list)
            assert len(doc.embedding) == 3
            assert all(isinstance(x, float) for x in doc.embedding)
        assert metadata == {"model": model, "usage": {"prompt_tokens": 4, "total_tokens": 4}}

    @pytest.mark.asyncio
    async def test_run_async_wrong_input_format(self):
        embedder = JinaDocumentEmbedder(api_key=Secret.from_token("fake-api-key"))

        string_input = "text"
        list_integers_input = [1, 2, 3]

        with pytest.raises(TypeError, match="JinaDocumentEmbedder expects a list of Documents as input"):
            await embedder.run_async(documents=string_input)

        with pytest.raises(TypeError, match="JinaDocumentEmbedder expects a list of Documents as input"):
            await embedder.run_async(documents=list_integers_input)

    def test_run_with_v3(self):
        docs = [
            Document(content="I love cheese", meta={"topic": "Cuisine"}),
            Document(content="A transformer is a deep learning architecture", meta={"topic": "ML"}),
        ]

        model = "jina-embeddings-v3"
        with patch("httpx.Client.post", side_effect=mock_httpx_post_response):
            embedder = JinaDocumentEmbedder(
                api_key=Secret.from_token("fake-api-key"),
                model=model,
                prefix="prefix ",
                suffix=" suffix",
                meta_fields_to_embed=["topic"],
                embedding_separator=" | ",
                batch_size=1,
                task="retrieval.query",
            )
            result = embedder.run(documents=docs)

        documents_with_embeddings = result["documents"]
        metadata = result["meta"]

        assert isinstance(documents_with_embeddings, list)
        assert len(documents_with_embeddings) == len(docs)
        for doc in documents_with_embeddings:
            assert isinstance(doc, Document)
            assert isinstance(doc.embedding, list)
            assert len(doc.embedding) == 3
            assert all(isinstance(x, float) for x in doc.embedding)
        assert metadata == {"model": model, "usage": {"prompt_tokens": 2 * 4, "total_tokens": 2 * 4}}

    @pytest.mark.skipif(not os.environ.get("JINA_API_KEY", None), reason="JINA_API_KEY env var not set")
    @pytest.mark.integration
    def test_run_integration(self):
        embedder = JinaDocumentEmbedder(model="jina-embeddings-v3", task="retrieval.passage")
        docs = [
            Document(content="Paris is the capital of France."),
            Document(content="Berlin is the capital of Germany."),
        ]

        result = embedder.run(documents=docs)

        assert "documents" in result
        assert len(result["documents"]) == 2
        for doc in result["documents"]:
            assert isinstance(doc, Document)
            assert isinstance(doc.embedding, list)
            assert len(doc.embedding) > 0
            assert all(isinstance(x, (int, float)) for x in doc.embedding)

        assert "meta" in result
        assert isinstance(result["meta"], dict)
        assert "model" in result["meta"]
        assert "usage" in result["meta"]

    @pytest.mark.skipif(not os.environ.get("JINA_API_KEY", None), reason="JINA_API_KEY env var not set")
    @pytest.mark.integration
    @pytest.mark.asyncio
    async def test_run_async_integration(self):
        embedder = JinaDocumentEmbedder(model="jina-embeddings-v3", task="retrieval.passage")
        docs = [
            Document(content="Paris is the capital of France."),
            Document(content="Berlin is the capital of Germany."),
        ]

        result = await embedder.run_async(documents=docs)

        assert "documents" in result
        assert len(result["documents"]) == 2
        for doc in result["documents"]:
            assert isinstance(doc, Document)
            assert isinstance(doc.embedding, list)
            assert len(doc.embedding) > 0
            assert all(isinstance(x, (int, float)) for x in doc.embedding)

        assert "meta" in result
        assert isinstance(result["meta"], dict)
        assert "model" in result["meta"]
        assert "usage" in result["meta"]
