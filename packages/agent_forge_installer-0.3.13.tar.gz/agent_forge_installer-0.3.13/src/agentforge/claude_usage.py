"""Claude Code usage retrieval helpers."""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

try:
    import requests
except ImportError:  # pragma: no cover
    requests = None


OAUTH_USAGE_URL = "https://api.anthropic.com/api/oauth/usage"
OAUTH_BETA_HEADER = "oauth-2025-04-20"


class ClaudeUsageError(RuntimeError):
    """Raised when real Claude usage cannot be retrieved."""


def _candidate_credentials_paths(
    *,
    root: str | Path | None = None,
    home_dir: str | Path | None = None,
) -> list[Path]:
    home = Path(home_dir) if home_dir is not None else Path.home()
    candidates = [home / ".claude" / ".credentials.json"]

    root_path = root or os.environ.get("AGENTFORGE_ROOT")
    if root_path:
        root_candidate = Path(root_path) / ".claude" / ".credentials.json"
        if root_candidate not in candidates:
            candidates.append(root_candidate)

    return candidates


def get_claude_oauth_token(
    *,
    root: str | Path | None = None,
    home_dir: str | Path | None = None,
) -> str:
    """Return the Claude OAuth access token from the first valid credentials file.

    Handles two credential file formats:
    - Flat:  {"accessToken": "...", ...}
    - Nested: {"claudeAiOauth": {"accessToken": "...", ...}}
    """
    for path in _candidate_credentials_paths(root=root, home_dir=home_dir):
        if not path.exists():
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ClaudeUsageError(f"Could not read Claude credentials from {path}: {exc}") from exc

        # Flat format
        token = str(payload.get("accessToken") or payload.get("access_token") or "").strip()
        if token:
            return token

        # Nested format (claudeAiOauth wrapper used by Claude Code CLI)
        nested = payload.get("claudeAiOauth", {})
        if isinstance(nested, dict):
            token = str(nested.get("accessToken") or nested.get("access_token") or "").strip()
            if token:
                return token

    raise ClaudeUsageError("Claude OAuth token not found in .credentials.json.")


def _default_http_get_json(url: str, headers: dict[str, str], timeout: int) -> dict:
    if requests is not None:
        response = requests.get(url, headers=headers, timeout=timeout)
        response.raise_for_status()
        return response.json()

    request = Request(url, headers=headers, method="GET")
    with urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def fetch_claude_oauth_usage(
    token: str,
    *,
    timeout: int = 10,
    http_get_json_fn=None,
) -> dict:
    """Fetch real Claude usage from Anthropic's OAuth usage endpoint."""
    headers = {
        "Authorization": f"Bearer {token}",
        "anthropic-beta": OAUTH_BETA_HEADER,
    }
    getter = http_get_json_fn or _default_http_get_json
    try:
        payload = getter(OAUTH_USAGE_URL, headers, timeout)
    except (HTTPError, URLError) as exc:
        raise ClaudeUsageError(f"Claude usage API request failed: {exc}") from exc
    except Exception as exc:
        raise ClaudeUsageError(f"Claude usage API request failed: {exc}") from exc

    if not isinstance(payload, dict):
        raise ClaudeUsageError("Claude usage API returned an unexpected payload.")
    return payload


def get_claude_oauth_usage(
    *,
    root: str | Path | None = None,
    home_dir: str | Path | None = None,
    timeout: int = 10,
    http_get_json_fn=None,
) -> dict:
    """Load credentials then fetch real Claude usage data."""
    token = get_claude_oauth_token(root=root, home_dir=home_dir)
    return fetch_claude_oauth_usage(token, timeout=timeout, http_get_json_fn=http_get_json_fn)


def parse_usage_reset(value: str | None) -> datetime | None:
    """Parse an ISO-8601 reset timestamp from the usage payload."""
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
