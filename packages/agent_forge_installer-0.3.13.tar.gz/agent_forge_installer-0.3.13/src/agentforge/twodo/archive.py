"""Helpers for reading and writing 2Do NSKeyedArchiver payloads."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
import gzip
import plistlib
from plistlib import UID
from pathlib import Path
from typing import Any


DICT_CLASS = {
    "$classname": "NSMutableDictionary",
    "$classes": ["NSMutableDictionary", "NSDictionary", "NSObject"],
}
ARRAY_CLASS = {
    "$classname": "NSMutableArray",
    "$classes": ["NSMutableArray", "NSArray", "NSObject"],
}


def load_archive(path: Path) -> dict[str, Any]:
    with gzip.open(path, "rb") as handle:
        return plistlib.load(handle)


def dump_archive(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(path, "wb") as handle:
        plistlib.dump(payload, handle, fmt=plistlib.FMT_BINARY, sort_keys=False)


def unpack_archive(archive: Mapping[str, Any]) -> Any:
    objects = archive["$objects"]
    top = archive["$top"]["data"]
    cache: dict[int, Any] = {}
    return _unpack_object(objects, top.data, cache)


def _unpack_object(objects: Sequence[Any], index: int, cache: dict[int, Any]) -> Any:
    if index in cache:
        return cache[index]

    if index == 0:
        cache[index] = None
        return None

    value = objects[index]
    if isinstance(value, UID):
        unpacked = _unpack_object(objects, value.data, cache)
    elif isinstance(value, dict) and "NS.keys" in value and "NS.objects" in value:
        unpacked = {
            str(_unpack_object(objects, key.data, cache)): _unpack_object(objects, obj.data, cache)
            for key, obj in zip(value["NS.keys"], value["NS.objects"], strict=True)
        }
    elif isinstance(value, dict) and "NS.objects" in value:
        unpacked = [_unpack_object(objects, item.data, cache) for item in value["NS.objects"]]
    elif isinstance(value, list):
        unpacked = [(_unpack_object(objects, item.data, cache) if isinstance(item, UID) else item) for item in value]
    else:
        unpacked = value

    cache[index] = unpacked
    return unpacked


class ArchiveBuilder:
    """Build a small NSKeyedArchiver payload compatible with 2Do files."""

    def __init__(self) -> None:
        self.objects: list[Any] = ["$null"]
        self._strings: dict[str, int] = {"$null": 0}
        self._classes: dict[str, int] = {}

    def add(self, value: Any) -> UID:
        if value is None:
            return UID(0)
        if isinstance(value, UID):
            return value
        if isinstance(value, str):
            return self.add_string(value)
        if isinstance(value, Mapping):
            return self.add_dict(value)
        if isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray, str)):
            return self.add_array(list(value))
        return self.add_string(str(value))

    def add_string(self, value: str) -> UID:
        existing = self._strings.get(value)
        if existing is not None:
            return UID(existing)
        self.objects.append(value)
        index = len(self.objects) - 1
        self._strings[value] = index
        return UID(index)

    def add_class(self, kind: str) -> UID:
        if kind in self._classes:
            return UID(self._classes[kind])
        data = DICT_CLASS if kind == "dict" else ARRAY_CLASS
        self.objects.append(data)
        index = len(self.objects) - 1
        self._classes[kind] = index
        return UID(index)

    def add_dict(self, value: Mapping[str, Any]) -> UID:
        key_refs = [self.add_string(str(key)) for key in value.keys()]
        value_refs = [self.add(item) for item in value.values()]
        payload = {
            "NS.keys": key_refs,
            "NS.objects": value_refs,
            "$class": self.add_class("dict"),
        }
        self.objects.append(payload)
        return UID(len(self.objects) - 1)

    def add_array(self, value: Sequence[Any]) -> UID:
        payload = {
            "NS.objects": [self.add(item) for item in value],
            "$class": self.add_class("array"),
        }
        self.objects.append(payload)
        return UID(len(self.objects) - 1)

    def build(self, root: Mapping[str, Any]) -> dict[str, Any]:
        root_uid = self.add_dict(root)
        return {
            "$version": 100000,
            "$archiver": "NSKeyedArchiver",
            "$top": {"data": root_uid},
            "$objects": self.objects,
        }
