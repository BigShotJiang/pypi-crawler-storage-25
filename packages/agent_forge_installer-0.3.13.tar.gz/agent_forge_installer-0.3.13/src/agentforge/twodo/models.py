"""Normalized 2Do models."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path


@dataclass(slots=True)
class TwoDoAlarm:
    trigger_offset_seconds: int | None = None
    sound: str | None = None
    action: str | None = None
    raw: dict[str, object] = field(default_factory=dict)


@dataclass(slots=True)
class TwoDoLocation:
    raw_value: str
    name: str | None = None
    latitude: float | None = None
    longitude: float | None = None


@dataclass(slots=True)
class TwoDoList:
    list_id: str
    title: str
    group_id: str | None = None
    color: str | None = None
    is_readonly: bool = False
    is_inbox: bool = False
    raw: dict[str, object] = field(default_factory=dict)
    path: Path | None = None


@dataclass(slots=True)
class TwoDoTask:
    task_id: str
    title: str
    notes: str
    list_id: str
    list_name: str | None = None
    actor_id: str | None = None
    due_at: datetime | None = None
    all_day: bool = False
    recurrence_rule: str | None = None
    repeat_type: str | None = None
    repeat_value: str | None = None
    priority: str = "medium"
    status: str = "open"
    is_completed: bool = False
    is_deleted: bool = False
    starred: bool = False
    task_type: str = "task"
    created_at: datetime | None = None
    updated_at: datetime | None = None
    last_completed_at: datetime | None = None
    next_run_override: datetime | None = None
    alarms: list[TwoDoAlarm] = field(default_factory=list)
    locations: list[TwoDoLocation] = field(default_factory=list)
    url: str | None = None
    action_type: str | None = None
    action_value: str | None = None
    image_uuid: str | None = None
    audio_uuid: str | None = None
    parent_id: str | None = None
    tags: list[str] = field(default_factory=list)
    prompt: str | None = None
    prompt_ref: str | None = None
    repeat_from: str = "schedule"
    raw: dict[str, object] = field(default_factory=dict)
    path: Path | None = None
