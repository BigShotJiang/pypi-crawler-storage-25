"""Filesystem-backed 2Do integration."""

from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timedelta
import json
import os
from pathlib import Path
from typing import Any
from uuid import uuid4
from zoneinfo import ZoneInfo

from .archive import ArchiveBuilder, dump_archive, load_archive, unpack_archive
from .models import TwoDoAlarm, TwoDoList, TwoDoLocation, TwoDoTask

LOCAL_TZ = ZoneInfo("America/Montreal")
GROUP_LISTS = "2DoCalGroupLists"


def resolve_twodo_root(root: Path) -> Path:
    if "AGENTFORGE_2DO_ROOT" in os.environ:
        return Path(os.environ["AGENTFORGE_2DO_ROOT"])
    default = Path("/home/agentforge/Dropbox/Apps/2Do")
    if root == Path("/home/agentforge/AgentForge") and default.exists():
        return default
    return root / "data" / "2do"


def _now() -> datetime:
    return datetime.now(LOCAL_TZ).replace(second=0, microsecond=0, tzinfo=None)


def _parse_floatish(value: object) -> float | None:
    if value in (None, "", "0"):
        return None
    try:
        return float(str(value))
    except (TypeError, ValueError):
        return None


def _parse_dt(raw_date: object, raw_time: object, raw_abs: object) -> tuple[datetime | None, bool]:
    date_text = str(raw_date).strip() if raw_date not in (None, "", "0", "$null") else ""
    if not date_text:
        return None, False

    parsed_date = datetime.strptime(date_text, "%Y-%m-%d")
    time_value = str(raw_time).strip() if raw_time is not None else "999999.000000"
    if time_value.startswith("999999"):
        return parsed_date.replace(hour=0, minute=0), True

    compact = time_value.split(".", 1)[0].zfill(4)
    hours = int(compact[:-2] or "0")
    minutes = int(compact[-2:])
    return parsed_date.replace(hour=hours, minute=minutes), False


def _format_due(due_at: datetime | None, *, all_day: bool) -> tuple[str | None, str, str | None]:
    if due_at is None:
        return None, "999999.000000", None
    local = due_at.replace(tzinfo=LOCAL_TZ)
    due = local.strftime("%Y-%m-%d")
    duetime = "999999.000000" if all_day else local.strftime("%H%M") + ".000000"
    midnight = local.replace(hour=0, minute=0, second=0, microsecond=0)
    return due, duetime, f"{midnight.timestamp():.6f}"


def _add_months(value: datetime, months: int = 1) -> datetime:
    month_index = value.month - 1 + months
    year = value.year + month_index // 12
    month = month_index % 12 + 1
    # Clamp to the target month's valid day without drifting by fixed day counts.
    if month == 12:
        next_month = datetime(year + 1, 1, 1)
    else:
        next_month = datetime(year, month + 1, 1)
    last_day = (next_month - timedelta(days=1)).day
    return value.replace(year=year, month=month, day=min(value.day, last_day))


def _parse_priority(value: object) -> str:
    mapping = {"0": "medium", "1": "high", "2": "low", "3": "medium", "5": "medium"}
    return mapping.get(str(value), "medium")


def _dump_priority(value: str) -> str:
    mapping = {"high": "1", "medium": "0", "low": "2"}
    return mapping.get(value, "0")


def _parse_recurrence(raw: object, repeat_type: object) -> str | None:
    raw_text = str(raw).strip() if raw not in (None, "") else ""
    if raw_text in ("", "0"):
        return None
    lowered = raw_text.lower()
    aliases = {
        "daily": "daily",
        "weekly": "weekly",
        "monthly": "monthly",
        "1": "daily",
        "2": "weekly",
        "3": "monthly",
    }
    return aliases.get(lowered) or aliases.get(str(repeat_type).strip().lower()) or lowered


def _parse_alarm(value: object) -> list[TwoDoAlarm]:
    if not isinstance(value, list):
        return []
    alarms: list[TwoDoAlarm] = []
    for item in value:
        if not isinstance(item, dict):
            continue
        trigger = _parse_floatish(item.get("relduetrig") or item.get("reltrig"))
        alarms.append(
            TwoDoAlarm(
                trigger_offset_seconds=int(trigger) if trigger is not None else None,
                sound=str(item.get("sound")) if item.get("sound") not in (None, "") else None,
                action=str(item.get("action")) if item.get("action") not in (None, "") else None,
                raw=dict(item),
            )
        )
    return alarms


def _parse_location(raw: object) -> list[TwoDoLocation]:
    if raw in (None, "", "0"):
        return []
    values = raw if isinstance(raw, list) else [raw]
    result: list[TwoDoLocation] = []
    for item in values:
        text = str(item)
        parts = text.split("_~|$$@$$|~_")
        name = parts[0] if parts else None
        latitude = None
        longitude = None
        if len(parts) >= 4:
            try:
                latitude = float(parts[2])
                longitude = float(parts[3])
            except ValueError:
                latitude = None
                longitude = None
        result.append(TwoDoLocation(raw_value=text, name=name, latitude=latitude, longitude=longitude))
    return result


def _dump_locations(locations: list[TwoDoLocation]) -> str | None:
    if not locations:
        return None
    return locations[0].raw_value


def split_note_block(notes: str) -> tuple[str, dict[str, Any]]:
    marker = "--- AgentForge ---"
    if marker not in notes:
        return notes.strip(), {}
    human, _, tail = notes.partition(marker)
    lines = [line.rstrip() for line in tail.strip().splitlines()]
    metadata: dict[str, Any] = {}
    key: str | None = None
    buffer: list[str] = []
    for line in lines:
        if ":" in line and not line.startswith(" "):
            if key is not None:
                metadata[key] = "\n".join(buffer).strip()
                buffer = []
            key, value = line.split(":", 1)
            key = key.strip()
            value = value.strip()
            if value:
                metadata[key] = value
                key = None
            continue
        buffer.append(line.lstrip())
    if key is not None:
        metadata[key] = "\n".join(buffer).strip()
    if "metadata" in metadata:
        try:
            metadata["metadata"] = json.loads(metadata["metadata"])
        except json.JSONDecodeError:
            pass
    return human.strip(), metadata


def render_note_block(content: str) -> str:
    """Return the notes content for a task.  No metadata block — prompt text goes directly in notes."""
    return content.strip()


class TwoDoBackend:
    def __init__(self, root: Path) -> None:
        self.instance_root = root
        self.root = resolve_twodo_root(root)
        self.tod_dir = self.root / "tod"
        self.col_dir = self.root / "col"
        self.cal_dir = self.root / "cal"
        for path in (self.tod_dir, self.col_dir, self.cal_dir):
            path.mkdir(parents=True, exist_ok=True)

    def read_groups(self) -> dict[str, str]:
        groups: dict[str, str] = {}
        for path in sorted(self.cal_dir.glob("*.cal")):
            payload = unpack_archive(load_archive(path))
            if isinstance(payload, dict):
                groups[str(payload.get("uuid") or payload.get("uid") or path.stem)] = str(payload.get("name") or "")
        return groups

    def read_lists(self) -> list[TwoDoList]:
        lists: list[TwoDoList] = []
        for path in sorted(self.col_dir.glob("*.col")):
            payload = unpack_archive(load_archive(path))
            if not isinstance(payload, dict):
                continue
            list_id = str(payload.get("uid") or path.stem)
            lists.append(
                TwoDoList(
                    list_id=list_id,
                    title=str(payload.get("title") or list_id),
                    group_id=str(payload.get("calendar") or payload.get("parentname") or GROUP_LISTS),
                    color=str(payload.get("color")) if payload.get("color") not in (None, "") else None,
                    is_readonly=str(payload.get("readonly", "0")) == "1",
                    is_inbox=str(payload.get("isinboxcal", "0")) == "1" or str(payload.get("title")) == "Inbox",
                    raw=dict(payload),
                    path=path,
                )
            )
        return lists

    def resolve_list(self, name: str, *, create: bool = False) -> TwoDoList:
        normalized = name.strip().lower()
        for item in self.read_lists():
            if item.title.strip().lower() == normalized or item.list_id == name:
                return item
        if not create:
            raise KeyError(f"Unknown 2Do list: {name}")
        return self.create_list(name)

    def create_list(self, title: str) -> TwoDoList:
        list_id = uuid4().hex
        payload = {
            "uid": list_id,
            "mobilemeisshared": "0",
            "donecal": "0",
            "smartrangeexcludesstart": "0",
            "mobilemeissharedowner": "0",
            "combinelist": "0",
            "isshowingall": "1",
            "datestampnorm": "0.000000",
            "sortfield": "0",
            "hidden": "0",
            "smartsearchusesoundex": "0",
            "canshowintoday": "1",
            "type": "CalCalendarTypeLocal",
            "istodaycal": "0",
            "expanded": "1",
            "specialfolder": "0",
            "isscheduled": "0",
            "readonly": "0",
            "sortorder": "0",
            "isarchived": "0",
            "position": "0",
            "smartrangeto": "0",
            "isallcal": "0",
            "entity": "calendar",
            "autotweet": "0",
            "status": "1",
            "parentuid": "0",
            "color": "0.364706,0.486275,0.568627",
            "isanniversary": "0",
            "excludecompleted": "0",
            "starred": "0",
            "issmartcalendar": "0",
            "isbirth": "0",
            "deleted": "0",
            "smartrangefrom": "0",
            "canshowindone": "1",
            "datestamp": "0.000000",
            "title": title,
            "isinboxcal": "0",
            "canshowinall": "1",
            "calendar": GROUP_LISTS,
        }
        path = self.col_dir / f"o_u_k_{list_id}_p__i__d_.col"
        dump_archive(path, ArchiveBuilder().build(payload))
        return TwoDoList(list_id=list_id, title=title, group_id=GROUP_LISTS, path=path, raw=payload)

    def read_task(self, task_id: str) -> TwoDoTask | None:
        for path in self.tod_dir.glob(f"*i_{task_id}_d_.tod"):
            task = self._parse_task_file(path)
            for item in self.read_lists():
                if item.list_id == task.list_id:
                    task.list_name = item.title
                    break
            return task
        return None

    def read_tasks(self, *, list_id: str | None = None, include_completed: bool = False) -> list[TwoDoTask]:
        lists = {item.list_id: item for item in self.read_lists()}
        tasks: list[TwoDoTask] = []
        for path in sorted(self.tod_dir.glob("*.tod")):
            task = self._parse_task_file(path)
            if list_id and task.list_id != list_id:
                continue
            if not include_completed and task.is_completed:
                continue
            list_item = lists.get(task.list_id)
            task.list_name = list_item.title if list_item else task.list_id
            tasks.append(task)
        return tasks

    def _parse_task_file(self, path: Path) -> TwoDoTask:
        payload = unpack_archive(load_archive(path))
        if not isinstance(payload, dict):
            raise ValueError(f"Malformed 2Do task archive at {path}: expected dict payload, got {type(payload).__name__}")
        due_at, all_day = _parse_dt(payload.get("due"), payload.get("duetime"), payload.get("duedateabs"))
        human_notes, block = split_note_block(str(payload.get("notes") or ""))
        # Detect repeat_from from native repeattype bitmask (bit 8 = from completion).
        # Fall back to block field for old tasks not yet migrated.
        rt_raw = payload.get("repeattype", "0")
        try:
            repeat_from_native = "completion" if (int(rt_raw) & 256) else "schedule"
        except (ValueError, TypeError):
            repeat_from_native = "schedule"
        repeat_from = str(block.get("repeat_from", repeat_from_native))
        task = TwoDoTask(
            task_id=str(payload.get("uid") or path.stem),
            title=str(payload.get("title") or ""),
            notes=human_notes,
            list_id=str(payload.get("caluid") or ""),
            due_at=due_at,
            actor_id=str(block.get("actor_id")) if block.get("actor_id") else None,
            all_day=all_day,
            recurrence_rule=_parse_recurrence(payload.get("recurrence"), payload.get("repeattype")),
            repeat_type=str(payload.get("repeattype")) if payload.get("repeattype") not in (None, "") else None,
            repeat_value=str(payload.get("repeatval")) if payload.get("repeatval") not in (None, "") else None,
            priority=_parse_priority(payload.get("priority")),
            status="done" if str(payload.get("iscomp", "0")) == "1" else "open",
            is_completed=str(payload.get("iscomp", "0")) == "1",
            is_deleted=str(payload.get("deleted", "0")) == "1",
            starred=str(payload.get("starred", "0")) == "1",
            task_type=str(payload.get("tasktype") or "task"),
            created_at=datetime.fromtimestamp(float(payload["createdate"])) if payload.get("createdate") else None,
            updated_at=datetime.fromtimestamp(float(payload["datestamp"])) if payload.get("datestamp") else None,
            last_completed_at=datetime.fromisoformat(str(payload["af_completed_at"])) if payload.get("af_completed_at") else (datetime.fromisoformat(str(block["last_completed_at"])) if block.get("last_completed_at") else None),
            next_run_override=datetime.fromisoformat(str(payload["af_deferred_until"])) if payload.get("af_deferred_until") else (datetime.fromisoformat(str(block["next_run_override"])) if block.get("next_run_override") else None),
            alarms=_parse_alarm(payload.get("alarms")),
            locations=_parse_location(payload.get("locations")),
            url=str(payload.get("url")) if payload.get("url") not in (None, "") else None,
            action_type=str(payload.get("acttype")) if payload.get("acttype") not in (None, "", "0") else None,
            action_value=str(payload.get("actvalue")) if payload.get("actvalue") not in (None, "", "0") else None,
            image_uuid=str(payload.get("imageuuid")) if payload.get("imageuuid") not in (None, "") else None,
            audio_uuid=str(payload.get("audiouuid")) if payload.get("audiouuid") not in (None, "") else None,
            parent_id=self._extract_parent_id(path.name),
            tags=str(block.get("tags", "")).split() if block.get("tags") else [],
            prompt=str(block.get("prompt")) if block.get("prompt") else None,
            prompt_ref=str(block.get("prompt_ref")) if block.get("prompt_ref") else None,
            repeat_from=repeat_from,
            raw=dict(payload),
            path=path,
        )
        return task

    def _extract_parent_id(self, filename: str) -> str | None:
        marker = "_p_"
        if marker not in filename or "_i_" not in filename:
            return None
        parent = filename.split("_p_", 1)[1].split("_i_", 1)[0]
        return parent or None

    def create_task(
        self,
        *,
        list_name: str,
        title: str,
        notes: str = "",
        due_at: datetime | None = None,
        all_day: bool | None = None,
        recurrence_rule: str | None = None,
        priority: str = "medium",
        tags: list[str] | None = None,
        actor_id: str | None = None,
        prompt: str | None = None,
        prompt_ref: str | None = None,
        repeat_from: str = "schedule",
    ) -> TwoDoTask:
        list_item = self.resolve_list(list_name, create=True)
        task_id = uuid4().hex
        now = _now()
        task = TwoDoTask(
            task_id=task_id,
            title=title,
            notes=notes,
            list_id=list_item.list_id,
            list_name=list_item.title,
            actor_id=actor_id,
            due_at=due_at,
            all_day=(all_day if all_day is not None else (due_at is not None and due_at.hour == 0 and due_at.minute == 0)),
            recurrence_rule=recurrence_rule,
            repeat_type=recurrence_rule,
            priority=priority,
            created_at=now,
            updated_at=now,
            tags=tags or [],
            prompt=prompt,
            prompt_ref=prompt_ref,
            repeat_from=repeat_from,
        )
        self._write_task(task, actor_id=actor_id)
        return task

    def update_task(
        self,
        task_id: str,
        *,
        title: str | None = None,
        notes: str | None = None,
        due_at: datetime | None = None,
        recurrence_rule: str | None = None,
        priority: str | None = None,
        tags: list[str] | None = None,
        prompt: str | None = None,
        prompt_ref: str | None = None,
        actor_id: str | None = None,
    ) -> bool:
        task = self.read_task(task_id)
        if task is None:
            return False
        if title is not None:
            task.title = title
        if notes is not None:
            task.notes = notes
        if due_at is not None:
            task.due_at = due_at
            task.all_day = due_at.hour == 0 and due_at.minute == 0
        if recurrence_rule is not None:
            task.recurrence_rule = recurrence_rule
            task.repeat_type = recurrence_rule
        if priority is not None:
            task.priority = priority
        if tags is not None:
            task.tags = tags
        if prompt is not None:
            task.prompt = prompt
        if prompt_ref is not None:
            task.prompt_ref = prompt_ref
        task.updated_at = _now()
        self._write_task(task, actor_id=actor_id)
        return True

    def complete_task(self, task_id: str, *, completed_at: datetime | None = None) -> bool:
        task = self.read_task(task_id)
        if task is None:
            return False
        completed_value = completed_at or _now()
        # Mark the existing task as done regardless of recurrence.
        task.is_completed = True
        task.status = "done"
        task.last_completed_at = completed_value
        task.updated_at = _now()
        self._write_task(task)
        if task.recurrence_rule:
            # Create a new task for the next occurrence — mirrors 2Do app behaviour
            # (old task stays as a completed record; new task gets a fresh ID).
            # When repeat_from == "completion", advance from completed_value; otherwise from due_at.
            base = completed_value if task.repeat_from == "completion" else task.due_at
            if base is not None:
                increments = {
                    "hourly": timedelta(hours=1),
                    "daily": timedelta(days=1),
                    "weekly": timedelta(days=7),
                }
                if task.recurrence_rule == "monthly":
                    next_due = _add_months(base, 1)
                else:
                    next_due = base + increments.get(task.recurrence_rule, timedelta(days=1))
                now = _now()
                next_task = TwoDoTask(
                    task_id=uuid4().hex,
                    title=task.title,
                    notes=task.notes,
                    list_id=task.list_id,
                    list_name=task.list_name,
                    actor_id=task.actor_id,
                    due_at=next_due,
                    all_day=task.all_day,
                    recurrence_rule=task.recurrence_rule,
                    repeat_type=task.repeat_type,
                    repeat_value=task.repeat_value,
                    priority=task.priority,
                    tags=list(task.tags),
                    prompt=task.prompt,
                    prompt_ref=task.prompt_ref,
                    repeat_from=task.repeat_from,
                    alarms=task.alarms,
                    locations=task.locations,
                    task_type=task.task_type,
                    url=task.url,
                    starred=task.starred,
                    created_at=now,
                    updated_at=now,
                    raw=dict(task.raw),
                )
                self._write_task(next_task, actor_id=task.actor_id)
        return True

    def defer_task(self, task_id: str, *, due_at: datetime) -> bool:
        task = self.read_task(task_id)
        if task is None:
            return False
        task.due_at = due_at
        task.all_day = due_at.hour == 0 and due_at.minute == 0
        task.next_run_override = due_at  # stored as af_deferred_until in archive
        task.updated_at = _now()
        self._write_task(task)
        return True

    def _task_payload(self, task: TwoDoTask, *, actor_id: str | None = None) -> dict[str, Any]:
        due, duetime, duedateabs = _format_due(task.due_at, all_day=task.all_day)
        notes = render_note_block(task.prompt or task.notes or "")
        created_at = task.created_at or _now()
        updated_at = task.updated_at or created_at
        locations = _dump_locations(task.locations)
        payload = {
            "recurrence": task.recurrence_rule or "0",
            "uid": task.task_id,
            "wasreceived": "0",
            "taskduration": "0",
            "recurrenceendrepeatsorig": "0",
            "createdate": f"{created_at.timestamp():.6f}",
            "due": due,
            "hasaudio": "1" if task.audio_uuid else "0",
            "datestampnorm": f"{updated_at.timestamp():.6f}",
            "audiodur": "0",
            "alarms": [alarm.raw or {"action": alarm.action or "", "sound": alarm.sound or ""} for alarm in task.alarms] if task.alarms else [],
            "url": task.url or "",
            "sortfield": "0",
            "caluid": task.list_id,
            "tasktype": task.task_type or "task",
            "expanded": "1",
            "repeatval": task.repeat_value or "0",
            "startdaydelay": "0",
            "repeattype": str(256 if task.repeat_from == "completion" else 0),
            "sortorder": "0",
            "priority": _dump_priority(task.priority),
            "duedateabs": duedateabs,
            "recurrenceendrepeats": "0",
            "hasimage": "1" if task.image_uuid else "0",
            "wassent": "0",
            "entity": "task",
            "duetime": duetime,
            "audiouuid": task.audio_uuid or "",
            "status": "1",
            "isanniversary": "0",
            "starred": "1" if task.starred else "0",
            "isbirth": "0",
            "deleted": "1" if task.is_deleted else "0",
            "recurrenceendtype": "0",
            "locationalerttype": "0",
            "ruid": task.task_id,
            "displayorder": "0",
            "datestamp": f"{updated_at.timestamp():.6f}",
            "title": task.title,
            "notes": notes,
            "iscomp": "1" if task.is_completed else "0",
            "actvalue": task.action_value or "",
            "acttype": task.action_type or "0",
            "imageuuid": task.image_uuid or "",
        }
        if task.last_completed_at:
            payload["af_completed_at"] = task.last_completed_at.isoformat(timespec="seconds")
        if task.next_run_override:
            payload["af_deferred_until"] = task.next_run_override.isoformat(timespec="minutes")
        if locations:
            payload["locations"] = locations
        for key, value in task.raw.items():
            if key == "locations":
                continue
            payload.setdefault(key, value)
        return payload

    def _write_task(self, task: TwoDoTask, *, actor_id: str | None = None) -> None:
        payload = self._task_payload(task, actor_id=actor_id)
        parent_id = task.parent_id or ""
        filename = f"o_u_k_{task.list_id}_p_{parent_id}_i_{task.task_id}_d_.tod"
        path = self.tod_dir / filename
        dump_archive(path, ArchiveBuilder().build(payload))
        task.path = path
