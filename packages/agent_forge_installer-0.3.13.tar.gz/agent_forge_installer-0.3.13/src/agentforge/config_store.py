"""Thread-safe runtime config reloader."""

from __future__ import annotations

import json
import threading
import time
from pathlib import Path
from typing import Callable


class RuntimeConfigStore:
    """Keep a normalized config in memory and hot-reload safe changes."""

    def __init__(
        self,
        path: str | Path,
        *,
        normalizer: Callable[[dict], dict],
        debounce_seconds: float = 1.0,
        log_warning: Callable[[str], None] | None = None,
    ) -> None:
        self.path = Path(path)
        self._normalizer = normalizer
        self._debounce_seconds = debounce_seconds
        self._log_warning = log_warning or (lambda _msg: None)
        self._lock = threading.Lock()
        self._last_reload_at = 0.0
        self._mtime_ns: int | None = None

        raw = self._read_json()
        self._raw_config = raw
        self._config = self._normalizer(raw)
        self._mtime_ns = self._current_mtime_ns()

    def get_config(self) -> dict:
        with self._lock:
            return self._config

    def reload_if_needed(self) -> tuple[dict, bool]:
        with self._lock:
            mtime_ns = self._current_mtime_ns()
            if mtime_ns is None or mtime_ns == self._mtime_ns:
                return self._config, False

            now = time.monotonic()
            if now - self._last_reload_at < self._debounce_seconds:
                return self._config, False

            self._last_reload_at = now
            try:
                candidate_raw = self._read_json()
            except Exception as exc:
                self._log_warning(f"Config reload skipped; keeping previous config: {exc}")
                self._mtime_ns = mtime_ns
                return self._config, False

            merged = self._merge_safe_changes(self._raw_config, candidate_raw)
            self._raw_config = merged
            self._config = self._normalizer(merged)
            self._mtime_ns = mtime_ns
            return self._config, True

    def _current_mtime_ns(self) -> int | None:
        try:
            return self.path.stat().st_mtime_ns
        except OSError:
            return None

    def _read_json(self) -> dict:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _merge_safe_changes(self, current: dict, candidate: dict) -> dict:
        merged = dict(candidate)
        current_tg = dict(current.get("telegram", {}))
        candidate_tg = dict(candidate.get("telegram", {}))

        unsafe_changes: list[str] = []
        for field in ("token_env_var", "allowed_chat_ids"):
            if current_tg.get(field) != candidate_tg.get(field):
                unsafe_changes.append(field)
                candidate_tg[field] = current_tg.get(field)

        if unsafe_changes:
            joined = ", ".join(unsafe_changes)
            self._log_warning(
                f"Detected non-hot-reloadable Telegram config change ({joined}); restart required."
            )

        merged["telegram"] = candidate_tg
        return merged
