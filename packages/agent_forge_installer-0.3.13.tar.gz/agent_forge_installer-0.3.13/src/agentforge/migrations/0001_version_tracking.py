"""Bootstrap migration: ensure version.json exists with proper structure."""

from __future__ import annotations

from pathlib import Path

MIGRATION_ID = "0001"
DESCRIPTION = "Initialize version tracking (version.json)"


def up(root: Path) -> None:
    """Create data directory and ensure version.json structure."""
    data_dir = root / "data"
    data_dir.mkdir(parents=True, exist_ok=True)

    # Create backups directory for rollback support
    backups_dir = data_dir / "backups"
    backups_dir.mkdir(exist_ok=True)


def down(root: Path) -> None:
    """Remove backups directory (version.json is managed by framework)."""
    backups_dir = root / "data" / "backups"
    if backups_dir.exists() and not any(backups_dir.iterdir()):
        backups_dir.rmdir()
