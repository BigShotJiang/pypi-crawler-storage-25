"""AgentForge migrations framework.

Versioned migrations that run automatically during updates to handle
schema changes, new config fields, and data transformations.

Each migration is a Python module in this package with:
- MIGRATION_ID: str — unique sequential ID (e.g. "0001")
- DESCRIPTION: str — human-readable description
- def up(root: Path) -> None — apply the migration
- def down(root: Path) -> None — rollback (optional, best-effort)
"""

from __future__ import annotations

import importlib
import json
import logging
import pkgutil
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def get_version_file(root: Path) -> Path:
    """Return path to version.json tracking file."""
    return root / "data" / "version.json"


def read_version_state(root: Path) -> dict[str, Any]:
    """Read the current version tracking state."""
    vf = get_version_file(root)
    if vf.exists():
        try:
            return json.loads(vf.read_text())
        except (json.JSONDecodeError, OSError):
            logger.warning("Corrupted version.json, starting fresh")
    return {
        "installed_version": "0.0.0",
        "applied_migrations": [],
        "last_update": None,
        "previous_version": None,
        "update_channel": "stable",
    }


def write_version_state(root: Path, state: dict[str, Any]) -> None:
    """Persist the version tracking state."""
    vf = get_version_file(root)
    vf.parent.mkdir(parents=True, exist_ok=True)
    vf.write_text(json.dumps(state, indent=2) + "\n")


def discover_migrations() -> list[dict[str, Any]]:
    """Discover all migration modules in this package, sorted by ID."""
    migrations = []
    package_path = Path(__file__).parent

    for importer, modname, ispkg in pkgutil.iter_modules([str(package_path)]):
        if modname.startswith("_"):
            continue
        try:
            mod = importlib.import_module(f"agentforge.migrations.{modname}")
            if hasattr(mod, "MIGRATION_ID") and hasattr(mod, "up"):
                migrations.append({
                    "id": mod.MIGRATION_ID,
                    "description": getattr(mod, "DESCRIPTION", ""),
                    "module": mod,
                })
        except Exception as e:
            logger.warning(f"Failed to load migration {modname}: {e}")

    return sorted(migrations, key=lambda m: m["id"])


def get_pending_migrations(root: Path) -> list[dict[str, Any]]:
    """Return migrations that haven't been applied yet."""
    state = read_version_state(root)
    applied = set(state.get("applied_migrations", []))
    all_migrations = discover_migrations()
    return [m for m in all_migrations if m["id"] not in applied]


def run_migrations(root: Path, *, dry_run: bool = False) -> list[str]:
    """Run all pending migrations. Returns list of applied migration IDs."""
    pending = get_pending_migrations(root)
    if not pending:
        logger.info("No pending migrations.")
        return []

    state = read_version_state(root)
    applied = []

    for migration in pending:
        mid = migration["id"]
        desc = migration["description"]

        if dry_run:
            logger.info(f"  [DRY RUN] Would apply: {mid} — {desc}")
            applied.append(mid)
            continue

        logger.info(f"  Applying migration {mid}: {desc}")
        try:
            migration["module"].up(root)
            state["applied_migrations"].append(mid)
            write_version_state(root, state)
            applied.append(mid)
            logger.info(f"  ✓ Migration {mid} applied successfully")
        except Exception as e:
            logger.error(f"  ✗ Migration {mid} failed: {e}")
            raise RuntimeError(
                f"Migration {mid} failed: {e}. "
                f"System may be in an inconsistent state. "
                f"Fix the issue and retry `agentforge update`."
            ) from e

    return applied


def rollback_last_migration(root: Path) -> str | None:
    """Rollback the most recently applied migration. Returns its ID or None."""
    state = read_version_state(root)
    applied = state.get("applied_migrations", [])
    if not applied:
        logger.info("No migrations to rollback.")
        return None

    last_id = applied[-1]
    all_migrations = discover_migrations()
    target = None
    for m in all_migrations:
        if m["id"] == last_id:
            target = m
            break

    if target is None:
        logger.warning(f"Migration {last_id} not found in codebase, removing from tracking only.")
        applied.pop()
        write_version_state(root, state)
        return last_id

    down_fn = getattr(target["module"], "down", None)
    if down_fn is None:
        logger.warning(f"Migration {last_id} has no down() function — removing from tracking only.")
    else:
        logger.info(f"Rolling back migration {last_id}: {target['description']}")
        try:
            down_fn(root)
            logger.info(f"  ✓ Rollback of {last_id} completed")
        except Exception as e:
            logger.error(f"  ✗ Rollback of {last_id} failed: {e}")
            raise

    applied.pop()
    write_version_state(root, state)
    return last_id
