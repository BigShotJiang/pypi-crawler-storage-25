"""agentforge init — bootstrap a new AgentForge instance."""

from __future__ import annotations

import importlib.resources
import json
import shutil
import sqlite3
import subprocess
import sys
import time
from dataclasses import dataclass
from getpass import getpass
from pathlib import Path

from agentforge.http_client import http_get
from agentforge.paths import resolve_git_repos_root, resolve_runtime_root, resolve_runtime_scripts_dir, resolve_vault_root
from agentforge.team_docs import TEAM_CLAUDE_DEFAULT, write_system_state_note

CONFIG_TEMPLATE = {
    "telegram": {
        "token_env_var": "AGENTFORGE_TELEGRAM_TOKEN",
        "allowed_chat_ids": [],
        "group_chat_id": 0,
        "private_chat_id": 0,
        "topics": {},
        "poll_interval_seconds": 1,
        "max_message_length": 4096,
    },
    "claude": {
        "model": "sonnet",
        "max_budget_usd": 1.0,
    },
    "memory": {
        "db_path": "",
    },
    "heartbeat": {
        "interval_minutes": 30,
        "max_budget_usd": 0.1,
    },
    "monitoring": {
        "interval_minutes": 5,
        "sentry_monitor_url_env_var": "SENTRY_MONITOR_URL",
        "services": [],
    },
    "logging": {
        "sheets_id": "",
    },
    "threads": {
        "default": {
            "model": "sonnet",
        }
    },
    "project_topics": {},
}

DIRS = [
    "agents/shared",
    "agents/_template/cron/heartbeat",
    "agents/architect/cron/heartbeat",
    "agents/architect/daily",
    "agents/architect/logs",
    "agents/architect/data",
    "commands",
    "cron",
    "data",
    "logs",
]

DEFAULT_SOUL_BODY = (
    "# Soul\n\n"
    "Define your main agent's identity and personality here.\n\n"
    "## Shared Workspace\n\n"
    "- Shared git repositories live in `git-repos/` at the AgentForge root.\n"
    "- Use that folder for cloning and working on repositories that should be accessible to all agents.\n"
)


@dataclass
class TelegramValidationResult:
    ok: bool
    username: str = ""
    error: str = ""


@dataclass
class ChatDetectionResult:
    chat_id: int
    chat_type: str
    title: str = ""


@dataclass
class ClaudeCliStatus:
    installed: bool
    authenticated: bool
    message: str
    install_instructions: str = (
        "Install Claude Code CLI, then run `claude auth login` before starting AgentForge."
    )


@dataclass
class GitHubCliStatus:
    installed: bool
    authenticated: bool
    message: str
    remediation: str = (
        "Run `gh auth login` or export `GH_TOKEN` in .env before using GitHub actions."
    )


@dataclass
class WizardAnswers:
    telegram_token: str
    telegram_username: str
    chat: ChatDetectionResult
    bot_name: str
    bot_personality: str
    openai_api_key: str = ""
    brave_api_key: str = ""
    claude_status: ClaudeCliStatus | None = None


def validate_python_version() -> None:
    """Ensure the interpreter is new enough for AgentForge."""
    if sys.version_info < (3, 10):
        raise RuntimeError("AgentForge requires Python 3.10 or newer.")


def ensure_target_writable(root: Path) -> None:
    """Verify the target directory can be created and written to."""
    root.mkdir(parents=True, exist_ok=True)
    probe = root / ".agentforge-write-test"
    try:
        probe.write_text("ok", encoding="utf-8")
    finally:
        probe.unlink(missing_ok=True)


def validate_telegram_token(
    token: str,
    http_get_fn=None,
) -> TelegramValidationResult:
    """Validate a Telegram bot token via getMe."""
    http_get_fn = http_get if http_get_fn is None else http_get_fn
    token = token.strip()
    if not token:
        return TelegramValidationResult(ok=False, error="Telegram token cannot be empty.")

    try:
        payload = http_get_fn(f"https://api.telegram.org/bot{token}/getMe")
    except Exception as exc:  # pragma: no cover - network/backend specific
        return TelegramValidationResult(
            ok=False,
            error=f"Telegram validation request failed: {exc}",
        )

    if payload.get("ok") and payload.get("result", {}).get("username"):
        return TelegramValidationResult(
            ok=True,
            username=payload["result"]["username"],
        )

    description = payload.get("description", "Telegram rejected the provided token.")
    return TelegramValidationResult(ok=False, error=description)


def detect_chat_id(
    token: str,
    *,
    http_get_fn=None,
    timeout_seconds: int = 60,
    poll_interval_seconds: int = 2,
    printer=print,
    sleep_fn=time.sleep,
) -> ChatDetectionResult:
    """Poll Telegram updates until a /start message is observed."""
    http_get_fn = http_get if http_get_fn is None else http_get_fn
    api_base = f"https://api.telegram.org/bot{token}"
    deadline = time.time() + timeout_seconds
    offset = 0

    printer("Send `/start` to your bot now. Waiting for Telegram to report the chat...")

    while time.time() < deadline:
        payload = http_get_fn(
            f"{api_base}/getUpdates",
            params={"offset": offset, "timeout": min(poll_interval_seconds, 5)},
            timeout=max(poll_interval_seconds + 2, 5),
        )
        for update in payload.get("result", []):
            offset = max(offset, update.get("update_id", 0) + 1)
            message = update.get("message") or {}
            text = (message.get("text") or "").strip()
            chat = message.get("chat") or {}
            if text.startswith("/start") and chat.get("id") is not None:
                return ChatDetectionResult(
                    chat_id=int(chat["id"]),
                    chat_type=chat.get("type", "private"),
                    title=chat.get("title") or chat.get("username") or "",
                )
        sleep_fn(poll_interval_seconds)

    raise RuntimeError(
        "Timed out waiting for `/start`. Send the command to your bot and try again."
    )


def check_claude_cli() -> ClaudeCliStatus:
    """Check whether Claude Code CLI is installed and authenticated."""
    if shutil.which("claude") is None:
        return ClaudeCliStatus(
            installed=False,
            authenticated=False,
            message="Claude Code CLI was not found on PATH.",
        )

    try:
        result = subprocess.run(
            ["claude", "auth", "status"],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError as exc:
        return ClaudeCliStatus(
            installed=False,
            authenticated=False,
            message=f"Unable to execute Claude Code CLI: {exc}",
        )

    combined = f"{result.stdout}\n{result.stderr}".strip().lower()
    if result.returncode == 0:
        return ClaudeCliStatus(
            installed=True,
            authenticated=True,
            message="Claude Code CLI is installed and authenticated.",
        )
    if "not logged" in combined or "not authenticated" in combined or "login" in combined:
        return ClaudeCliStatus(
            installed=True,
            authenticated=False,
            message="Claude Code CLI is installed but not authenticated.",
        )
    return ClaudeCliStatus(
        installed=True,
        authenticated=False,
        message=(
            "Claude Code CLI is installed, but authentication could not be confirmed. "
            "Run `claude auth status` manually to verify."
        ),
    )


def check_github_cli() -> GitHubCliStatus:
    """Check whether GitHub CLI is installed and authenticated."""
    if shutil.which("gh") is None:
        return GitHubCliStatus(
            installed=False,
            authenticated=False,
            message="GitHub CLI (`gh`) was not found on PATH.",
        )

    try:
        result = subprocess.run(
            ["gh", "auth", "status"],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError as exc:
        return GitHubCliStatus(
            installed=False,
            authenticated=False,
            message=f"Unable to execute GitHub CLI: {exc}",
        )

    combined = f"{result.stdout}\n{result.stderr}".strip().lower()
    if result.returncode == 0:
        return GitHubCliStatus(
            installed=True,
            authenticated=True,
            message="GitHub CLI is installed and authenticated.",
        )
    if "not logged into any hosts" in combined or "authenticate" in combined:
        return GitHubCliStatus(
            installed=True,
            authenticated=False,
            message="GitHub CLI is installed but not authenticated.",
        )
    return GitHubCliStatus(
        installed=True,
        authenticated=False,
        message=(
            "GitHub CLI is installed, but authentication could not be confirmed. "
            "Run `gh auth status` manually to verify."
        ),
    )


def prompt_text(label: str, *, default: str | None = None, secret: bool = False) -> str:
    """Prompt for free-form text, optionally using a default or hidden input."""
    suffix = f" [{default}]" if default else ""
    prompt = f"{label}{suffix}: "

    while True:
        value = (getpass(prompt) if secret else input(prompt)).strip()
        if value:
            return value
        if default is not None:
            return default
        print("This field is required.")


def prompt_yes_no(label: str, *, default: bool = True) -> bool:
    """Prompt for a yes/no answer."""
    hint = "Y/n" if default else "y/N"
    while True:
        raw = input(f"{label} [{hint}]: ").strip().lower()
        if not raw:
            return default
        if raw in {"y", "yes"}:
            return True
        if raw in {"n", "no"}:
            return False
        print("Please answer yes or no.")


def build_config(root: Path, answers: WizardAnswers | None = None) -> dict:
    """Build the generated agents/architect/config.json payload."""
    chat_id = answers.chat.chat_id if answers else 0
    chat_type = answers.chat.chat_type if answers else "private"
    bot_name = (answers.bot_name.lower().strip() if answers else "architect") or "architect"
    return {
        "name": bot_name,
        "telegram": {
            "token_env_var": f"{bot_name.upper()}_TELEGRAM_TOKEN",
            "allowed_chat_ids": [str(chat_id)] if chat_id else [],
            "private_chat_id": str(chat_id) if chat_type == "private" and chat_id else "",
            "poll_interval_seconds": 2,
        },
        "claude": {
            "model": "opus",
            "max_budget_usd": 5.0,
        },
        "context": {
            "messages": 10,
            "hours": 48,
        },
    }


def build_env_text(
    answers: WizardAnswers | None = None,
    *,
    include_secrets: bool = True,
) -> str:
    """Build the generated .env content."""
    lines = [
        "# AgentForge environment variables",
        "# Generated by `agentforge init`.",
        "",
        "# Telegram bot token (from @BotFather)",
        (
            f"AGENTFORGE_TELEGRAM_TOKEN={answers.telegram_token}"
            if answers and include_secrets
            else "AGENTFORGE_TELEGRAM_TOKEN="
        ),
        "",
        "# Optional: Claude API key (if not using Claude Code CLI)",
        "# ANTHROPIC_API_KEY=",
        "",
        "# Optional: GitHub token for gh/API calls (recommended for automation)",
        "# GH_TOKEN=",
        "# Compatibility only (prefer GH_TOKEN when possible)",
        "# GITHUB_TOKEN=",
        "# Optional: keep GitHub auth lookup stable when HOME is overridden",
        "# GH_CONFIG_DIR=$HOME/.config/gh",
    ]

    if answers:
        lines.extend(
            [
                "",
                "# Optional provider API keys",
                (
                    f"OPENAI_API_KEY={answers.openai_api_key}"
                    if include_secrets
                    else "OPENAI_API_KEY="
                ),
                (
                    f"BRAVE_SEARCH_API_KEY={answers.brave_api_key}"
                    if include_secrets
                    else "BRAVE_SEARCH_API_KEY="
                ),
            ]
        )

    return "\n".join(lines) + "\n"


def build_soul_text(answers: WizardAnswers | None = None) -> str:
    """Build the generated soul.md content."""
    if answers is None:
        return DEFAULT_SOUL_BODY

    return (
        f"# Soul: {answers.bot_name}\n\n"
        "## Identity\n\n"
        f"- Name: {answers.bot_name}\n"
        "- Role: Primary AgentForge assistant\n\n"
        "## Personality\n\n"
        f"{answers.bot_personality}\n\n"
        "## Operating notes\n\n"
        "- Be concise, direct, and useful.\n"
        "- Use the configured Telegram chat as the primary operator channel.\n"
        "- Shared repositories live in `git-repos/` at the AgentForge root; use that folder for clones and collaborative repo work.\n"
        "- Escalate clearly when a task needs human action.\n"
    )


def initialize_database(db_path: Path) -> None:
    """Initialize the SQLite storage used by AgentForge."""
    conn = sqlite3.connect(str(db_path))
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            timestamp TEXT NOT NULL DEFAULT (datetime('now')),
            role TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system')),
            content TEXT NOT NULL,
            source TEXT NOT NULL DEFAULT 'telegram',
            telegram_chat_id TEXT,
            telegram_message_id TEXT,
            metadata TEXT
        );
        CREATE TABLE IF NOT EXISTS pending_retries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            user_text TEXT NOT NULL,
            thread_cfg TEXT NOT NULL,
            chat_id TEXT NOT NULL,
            thread_id TEXT,
            created_at TEXT NOT NULL,
            retry_after TEXT NOT NULL,
            attempts INTEGER DEFAULT 0
        );
        CREATE VIRTUAL TABLE IF NOT EXISTS conversations_fts USING fts5(
            content, content='conversations', content_rowid='id'
        );
        CREATE TRIGGER IF NOT EXISTS conversations_ai
            AFTER INSERT ON conversations BEGIN
            INSERT INTO conversations_fts(rowid, content)
                VALUES (new.id, new.content);
        END;
        CREATE TRIGGER IF NOT EXISTS conversations_ad
            AFTER DELETE ON conversations BEGIN
            INSERT INTO conversations_fts(conversations_fts, rowid, content)
                VALUES('delete', old.id, old.content);
        END;
    """)
    conn.commit()
    conn.close()


def _scaffold_main_agent(root: Path, bot_name: str, soul_text: str, printer=print) -> None:
    """Create the main bot agent under agents/<bot_name>/."""
    name = bot_name.lower().strip() or "assistant"
    agent_dir = root / "agents" / name
    if agent_dir.exists():
        printer(f"  skipped agents/{name}/ (already exists)")
        return

    agent_dir.mkdir(parents=True, exist_ok=True)
    (agent_dir / "plans").mkdir(exist_ok=True)
    vault_agent_dir = resolve_vault_root(root) / "Agents" / name
    (vault_agent_dir / "daily").mkdir(parents=True, exist_ok=True)

    (vault_agent_dir / "soul.md").write_text(soul_text, encoding="utf-8")
    (vault_agent_dir / "memory.md").write_text(
        f"# Mémoire de {name.capitalize()}\n\n"
        "Faits et apprentissages accumulés au fil du temps.\n"
        "Mis à jour automatiquement par le cron de consolidation (dimanche 23h).\n"
        "Ne pas modifier manuellement — le cron consolide depuis les fichiers daily/.\n\n"
        "---\n",
        encoding="utf-8",
    )
    printer(f"  created agents/{name}/ and vault/Agents/{name}/")


def _copy_template_file(dest: Path, template_name: str, printer=print) -> None:
    """Copy a template file from the package templates/ dir to dest."""
    if dest.exists():
        printer(f"  skipped {dest.relative_to(dest.parent.parent)} (already exists)")
        return
    try:
        pkg = importlib.resources.files("agentforge") / "templates" / template_name
        dest.write_text(pkg.read_text(encoding="utf-8"), encoding="utf-8")
        printer(f"  wrote {dest.relative_to(dest.parent.parent)}")
    except Exception as exc:
        printer(f"  warning: could not copy template {template_name}: {exc}")


def sync_scripts(root: Path, *, printer=print) -> None:
    """Copy bundled shell scripts from the package to $AGENTFORGE_ROOT/scripts/.

    Scripts are always overwritten so that ``agentforge init`` and
    ``agentforge update`` keep them in sync with the installed package version.
    Existing scripts with local modifications will be replaced — the canonical
    source of truth is the package, not the instance copy.
    """
    scripts_dir = resolve_runtime_scripts_dir(root)
    scripts_dir.mkdir(parents=True, exist_ok=True)

    try:
        pkg_scripts = importlib.resources.files("agentforge") / "templates" / "scripts"
    except Exception as exc:
        printer(f"  warning: could not locate bundled scripts: {exc}")
        return

    copied = 0
    for entry in pkg_scripts.iterdir():
        if entry.name.endswith(".sh"):
            dest = scripts_dir / entry.name
            dest.write_text(entry.read_text(encoding="utf-8"), encoding="utf-8")
            dest.chmod(0o755)
            copied += 1

    if copied:
        printer(f"  synced {copied} script(s) to scripts/")
    else:
        printer("  warning: no scripts found in package templates")


def sync_commands(root: Path, *, printer=print, overwrite: bool = False) -> None:
    """Copy bundled slash-command scripts to $AGENTFORGE_ROOT/commands/."""
    commands_dir = root / "commands"
    commands_dir.mkdir(parents=True, exist_ok=True)

    try:
        pkg_commands = importlib.resources.files("agentforge") / "templates" / "commands"
    except Exception as exc:
        printer(f"  warning: could not locate bundled command templates: {exc}")
        return

    copied = 0
    for command_dir in pkg_commands.iterdir():
        if not command_dir.is_dir():
            continue
        dest_dir = commands_dir / command_dir.name
        dest_dir.mkdir(parents=True, exist_ok=True)
        for entry in command_dir.iterdir():
            if not entry.is_file():
                continue
            dest = dest_dir / entry.name
            if dest.exists() and not overwrite:
                continue
            dest.write_text(entry.read_text(encoding="utf-8"), encoding="utf-8")
            if entry.name.endswith(".sh"):
                dest.chmod(0o755)
            copied += 1

    if copied:
        printer(f"  synced {copied} command file(s) to commands/")


def sync_builtin_crons(root: Path, *, printer=print, overwrite: bool = False) -> None:
    """Copy bundled built-in cron definitions to $AGENTFORGE_ROOT/cron/."""
    cron_dir = root / "cron"
    cron_dir.mkdir(parents=True, exist_ok=True)

    try:
        pkg_cron = importlib.resources.files("agentforge") / "templates" / "cron"
    except Exception as exc:
        printer(f"  warning: could not locate bundled cron templates: {exc}")
        return

    copied = 0
    for cron_name in ("daily_consolidation", "daily_learning", "weekly_consolidation", "proactive_check"):
        source_dir = pkg_cron / cron_name
        if not source_dir.is_dir():
            continue
        dest_dir = cron_dir / cron_name
        dest_dir.mkdir(parents=True, exist_ok=True)
        for entry in source_dir.iterdir():
            if not entry.is_file():
                continue
            dest = dest_dir / entry.name
            if dest.exists() and not overwrite:
                continue
            dest.write_text(entry.read_text(encoding="utf-8"), encoding="utf-8")
            if entry.name.endswith(".sh"):
                dest.chmod(0o755)
            copied += 1

    if copied:
        printer(f"  synced {copied} built-in cron file(s) to cron/")


def ensure_todo_system_docs(root: Path, *, printer=print) -> None:
    """Ensure the team handbook contains the todo system page."""
    team_dir = resolve_vault_root(root) / "Agents" / "_team"
    team_dir.mkdir(parents=True, exist_ok=True)
    todo_page = team_dir / "todo-system.md"
    if not todo_page.exists():
        todo_page.write_text(
            "# Todo System\n\n"
            "## Canonical system\n\n"
            "- Structured tasks live in each actor's 2Do list.\n"
            "- Delegated machine task queue: `agents/<agent>/tasks/*.json`\n"
            "- The vault is for durable docs and task prompt files, not a task database.\n\n"
            "## Heartbeat behavior\n\n"
            "- `proactive_check` injects only actionable tasks from 2Do.\n"
            "- Actionable means overdue, due now, or recurrence due now.\n\n"
            "## Command surface\n\n"
            "- `/todo-add` — create a task in the target actor's 2Do list.\n"
            "- `/todo-all` — show open tasks.\n"
            "- `/todo-next` and `/todo-nexts` — show the current actionable slice.\n"
            "- `/todo-projets`, `/todo-projet`, `/todo-goals`, `/todo-goal`, `/todo-autres` — filtered views.\n"
            "- `/todo-migrer` is deprecated.\n",
            encoding="utf-8",
        )
        printer("  wrote vault/Agents/_team/todo-system.md")

    index_path = team_dir / "index.md"
    if index_path.exists():
        index_text = index_path.read_text(encoding="utf-8")
        line = "- `todo-system.md` — canonical todo syntax, recurrence, due dates, and heartbeat behavior.\n"
        if "todo-system.md" not in index_text:
            index_path.write_text(index_text.rstrip() + "\n" + line, encoding="utf-8")
            printer("  updated vault/Agents/_team/index.md")


def scaffold_instance(
    root: Path,
    *,
    config: dict,
    env_text: str,
    env_example_text: str,
    soul_text: str,
    bot_name: str = "architect",
    printer=print,
) -> None:
    """Create the AgentForge instance files on disk (new 0.2.x structure)."""
    printer(f"Initializing AgentForge in {root}/\n")

    # ── Directories ──────────────────────────────────────────────────────────
    for relative_dir in DIRS:
        (root / relative_dir).mkdir(parents=True, exist_ok=True)
        printer(f"  created {relative_dir}/")

    resolve_git_repos_root(root).mkdir(parents=True, exist_ok=True)
    printer(f"  created {resolve_git_repos_root(root).relative_to(root)}/")
    resolve_runtime_root(root).mkdir(parents=True, exist_ok=True)
    printer("  created runtime/")
    (resolve_vault_root(root) / "Agents" / "_team").mkdir(parents=True, exist_ok=True)
    printer(f"  created {resolve_vault_root(root).relative_to(root)}/Agents/_team/")

    # ── Runtime CLAUDE.md (lean operational guide) ────────────────────────────
    claude_dest = root / "CLAUDE.md"
    if not claude_dest.exists():
        _copy_template_file(claude_dest, "CLAUDE.md", printer)

    # ── Canonical shared team docs (vault/Agents/_team/) ─────────────────────
    team_dir = resolve_vault_root(root) / "Agents" / "_team"
    team_claude = team_dir / "CLAUDE.md"
    if not team_claude.exists():
        team_claude.write_text(TEAM_CLAUDE_DEFAULT, encoding="utf-8")
        printer("  wrote vault/Agents/_team/CLAUDE.md")

    team_index = team_dir / "index.md"
    if not team_index.exists():
        team_index.write_text(
            "# Team Knowledge Index\n\n"
            "- `CLAUDE.md` — shared operating rules for all agents.\n"
            "- `memory.md` — compact shared facts injected into all agents.\n"
            "- `system-state.md` — generated read-only snapshot of current system/runtime facts.\n"
            "- `memory-policy.md` — what belongs in soul, memory, daily, and vault.\n"
            "- `engineering-playbook.md` — operational procedures and system workflows.\n"
            "- `product-context.md` — compact product and architecture context.\n"
            "- `coordination.md` — active agents, roles, and routing notes.\n",
            encoding="utf-8",
        )
        printer("  wrote vault/Agents/_team/index.md")
    else:
        index_text = team_index.read_text(encoding="utf-8")
        line = "- `system-state.md` — generated read-only snapshot of current system/runtime facts.\n"
        if "system-state.md" not in index_text:
            team_index.write_text(index_text.rstrip() + "\n" + line, encoding="utf-8")
            printer("  updated vault/Agents/_team/index.md")

    team_memory = team_dir / "memory.md"
    if not team_memory.exists():
        team_memory.write_text(
            "# Shared Knowledge\n\n"
            "This is the canonical shared injected memory layer for the instance.\n"
            "Keep it compact, durable, and safe to inject on every run.\n\n"
            "## Identity\n\n"
            "- Add instance-wide account disambiguation only when it truly helps multiple agents.\n"
            "- Prefer placeholders in the installer and add real facts only after installation.\n\n"
            "## Calendar Rules\n\n"
            "- Add your timezone and booking rules here if multiple agents need them often.\n"
            "- Keep sensitive account details out of package defaults.\n\n"
            "## Communication\n\n"
            "- If the user often relies on dictation or shorthand, document the interpretation rule here.\n"
            "- Use the same language as the user.\n\n"
            "## Autonomy\n\n"
            "- If unsure about autonomy level, default to level 2.\n",
            encoding="utf-8",
        )
        printer("  wrote vault/Agents/_team/memory.md")

    team_pages = {
        "memory-policy.md": (
            "# Memory Policy\n\n"
            "## Roles\n\n"
            "- `soul.md` — identity, tone, mission, and durable role boundaries.\n"
            "- `memory.md` — compact durable facts that affect future behavior.\n"
            "- `daily/YYYY-MM-DD.md` — working notes and consolidation input only.\n"
            "- `_team/*.md` — handbook/reference pages shared across agents.\n\n"
            "## Rules\n\n"
            "- Do not dump raw daily logs into `memory.md`.\n"
            "- Do not copy large procedures into injected memory files.\n"
            "- Move stable shared procedures into `_team/*.md` handbook pages.\n"
            "- Shared injected memory should keep only critical facts that many agents need often.\n"
        ),
        "engineering-playbook.md": (
            "# Engineering Playbook\n\n"
            "## Inter-agent delegation\n\n"
            "- Use each agent's Telegram bot when another agent must actually execute work.\n"
            "- Use project topics only for shared multi-agent coordination.\n"
            "- Do not use `telegram_send.sh` as a replacement for delegation.\n\n"
            "## Todos and tasks\n\n"
            "- Structured tasks live in each actor's 2Do list.\n"
            "- `proactive_check` may inject actionable 2Do context during heartbeat runs.\n"
            "- Delegated runtime task payloads live under `agents/<agent>/tasks/`.\n"
            "- See `todo-system.md` for current task-system rules.\n"
            "- Do not create legacy `agents/<agent>/todos.md` files.\n\n"
            "## Operations\n\n"
            "- Document create/remove agent procedures here.\n"
            "- Document cron and slash-command conventions here.\n"
            "- Document update and restart flow here.\n"
            "- Add rollback and incident procedures here.\n"
        ),
        "product-context.md": (
            "# Product Context\n\n"
            "- AgentForge is a multi-agent Telegram workspace backed by Claude Code and a shared Obsidian-style vault.\n"
            "- The system includes Telegram bots, cron/heartbeat automation, SQLite conversation state, and a searchable vault.\n"
            "- Shared git repositories live under `git-repos/` at the instance root.\n"
            "- Refer to `ARCHITECTURE.md` for the full runbook and system layout.\n"
        ),
        "coordination.md": (
            "# Coordination\n\n"
            "## Active agents\n\n"
            "- Add your agents and their responsibilities here.\n"
            "- Keep this list human-readable and update it when responsibilities shift.\n\n"
            "Example format:\n\n"
            "- `assistant` — end-user support and routine coordination.\n"
            "- `researcher` — research, synthesis, and discovery work.\n"
            "- `builder` — implementation and delivery support.\n"
            "- `architect` — system administration and framework maintenance.\n\n"
            "## Routing notes\n\n"
            "- In conversation, topic/thread/channel/chat may all refer to a Telegram topic.\n"
            "- Mentioning an agent by `@name` routes responsibility to that agent when applicable.\n"
        ),
        "todo-system.md": (
            "# Todo System\n\n"
            "See this page for canonical task file locations, due-date syntax, recurrence rules, and command behavior.\n"
        ),
    }
    for filename, text in team_pages.items():
        dest = team_dir / filename
        if not dest.exists():
            dest.write_text(text, encoding="utf-8")
            printer(f"  wrote vault/Agents/_team/{filename}")

    # ── agents/shared/ (legacy fallback during migration) ────────────────────
    shared_claude = root / "agents" / "shared" / "CLAUDE.md"
    if not shared_claude.exists():
        shared_claude.write_text(
            "# Instance Rules\n\n"
            "Legacy fallback for shared instance rules.\n"
            "Preferred canonical file: `vault/Agents/_team/CLAUDE.md`.\n",
            encoding="utf-8",
        )
        printer("  wrote agents/shared/CLAUDE.md")

    # ── agents/_template/ ─────────────────────────────────────────────────────
    _tpl = root / "agents" / "_template"
    for fname, text in [
        ("cron/heartbeat/config.json",
         '{"interval_minutes": 30, "model": "haiku", "max_budget_usd": 0.5, "enabled": true}'),
        ("cron/heartbeat/task.md",
         "# Heartbeat\n\nCheck for pending tasks. Respond HEARTBEAT_OK if nothing needs attention.\n"),
    ]:
        dest = _tpl / fname
        dest.parent.mkdir(parents=True, exist_ok=True)
        if not dest.exists():
            dest.write_text(text, encoding="utf-8")
            printer(f"  wrote agents/_template/{fname}")

    template_vault_dir = resolve_vault_root(root) / "Agents" / "_template"
    for fname, text in [
        ("soul.md", "# Soul\n\nPersonality, tone, and communication style.\n"),
        (
            "memory.md",
            "# Memory\n\n"
            "Keep only durable facts that will improve future decisions.\n\n"
            "See `vault/Agents/_team/index.md` for shared handbook pages.\n",
        ),
    ]:
        dest = template_vault_dir / fname
        dest.parent.mkdir(parents=True, exist_ok=True)
        if not dest.exists():
            dest.write_text(text, encoding="utf-8")
            printer(f"  wrote vault/Agents/_template/{fname}")

    # ── agents/<bot_name>/ (The Architect) ────────────────────────────────────
    name = (bot_name.lower().strip() or "architect")
    agent_dir = root / "agents" / name
    agent_dir.mkdir(parents=True, exist_ok=True)
    for subdir in ("logs", "data", "cron/heartbeat"):
        (agent_dir / subdir).mkdir(parents=True, exist_ok=True)
    vault_agent_dir = resolve_vault_root(root) / "Agents" / name
    for subdir in ("daily",):
        (vault_agent_dir / subdir).mkdir(parents=True, exist_ok=True)

    agent_config_path = agent_dir / "config.json"
    if not agent_config_path.exists():
        agent_config_path.write_text(
            json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )
        printer(f"  wrote agents/{name}/config.json")

    soul_path = vault_agent_dir / "soul.md"
    if not soul_path.exists():
        soul_path.write_text(soul_text, encoding="utf-8")
        printer(f"  wrote vault/Agents/{name}/soul.md")

    memory_path = vault_agent_dir / "memory.md"
    if not memory_path.exists():
        memory_path.write_text(
            f"# Memory: {name.capitalize()}\n\n"
            "Durable facts and accumulated knowledge.\n",
            encoding="utf-8",
        )
        printer(f"  wrote vault/Agents/{name}/memory.md")

    hb_config = agent_dir / "cron" / "heartbeat" / "config.json"
    if not hb_config.exists():
        hb_config.write_text(
            '{"interval_minutes": 30, "model": "opus", "max_budget_usd": 1.0, "enabled": true}\n',
            encoding="utf-8",
        )
        printer(f"  wrote agents/{name}/cron/heartbeat/config.json")

    hb_task = agent_dir / "cron" / "heartbeat" / "task.md"
    if not hb_task.exists():
        hb_task.write_text(
            "# Heartbeat\n\nCheck for pending tasks and system health.\n"
            "If nothing requires attention, respond with HEARTBEAT_OK.\n",
            encoding="utf-8",
        )
        printer(f"  wrote agents/{name}/cron/heartbeat/task.md")

    # ── .env ─────────────────────────────────────────────────────────────────
    env_example = root / ".env.example"
    if not env_example.exists():
        env_example.write_text(env_example_text, encoding="utf-8")
        printer("  wrote .env.example")

    env_path = root / ".env"
    if not env_path.exists():
        env_path.write_text(env_text, encoding="utf-8")
        printer("  wrote .env")
    else:
        printer("  skipped .env (already exists)")

    # ── Scripts (real files, no symlinks) ────────────────────────────────────
    sync_scripts(root, printer=printer)
    sync_commands(root, printer=printer)
    sync_builtin_crons(root, printer=printer)
    ensure_todo_system_docs(root, printer=printer)
    write_system_state_note(root=root, printer=printer)

    # ── Database ──────────────────────────────────────────────────────────────
    db_path = root / "data" / "conversations.db"
    if not db_path.exists():
        initialize_database(db_path)
        printer("  initialized data/conversations.db")
    else:
        printer("  skipped data/conversations.db (already exists)")


def collect_wizard_answers(
    *,
    validate_token_fn=None,
    detect_chat_fn=None,
    check_claude_fn=None,
    check_github_fn=None,
    printer=print,
) -> WizardAnswers:
    """Collect and validate interactive wizard answers."""
    validate_token_fn = validate_telegram_token if validate_token_fn is None else validate_token_fn
    detect_chat_fn = detect_chat_id if detect_chat_fn is None else detect_chat_fn
    check_claude_fn = check_claude_cli if check_claude_fn is None else check_claude_fn
    check_github_fn = check_github_cli if check_github_fn is None else check_github_fn

    printer("Interactive setup wizard\n")

    while True:
        token = prompt_text("Telegram bot token", secret=True)
        token_result = validate_token_fn(token)
        if token_result.ok:
            printer(f"Telegram token validated for @{token_result.username}.")
            break
        printer(f"Validation failed: {token_result.error}")
        if not prompt_yes_no("Try a different Telegram token?", default=True):
            raise RuntimeError("Setup cancelled during Telegram bot validation.")

    while True:
        try:
            chat = detect_chat_fn(token, printer=printer)
            printer(f"Detected chat id {chat.chat_id} ({chat.chat_type}).")
            break
        except RuntimeError as exc:
            printer(str(exc))
            if not prompt_yes_no("Retry chat detection?", default=True):
                raise RuntimeError("Setup cancelled during chat ID detection.")

    claude_status = check_claude_fn()
    printer(claude_status.message)
    if not claude_status.installed:
        printer(claude_status.install_instructions)
        if not prompt_yes_no("Continue setup without Claude Code CLI?", default=False):
            raise RuntimeError("Setup cancelled until Claude Code CLI is installed.")
    elif not claude_status.authenticated:
        printer("Run `claude auth login` after setup if you want CLI-backed execution.")
        if not prompt_yes_no("Continue setup with a warning?", default=True):
            raise RuntimeError("Setup cancelled until Claude Code CLI authentication is fixed.")

    github_status = check_github_fn()
    printer(github_status.message)
    if not github_status.authenticated:
        printer(
            "Warning: GitHub CLI auth is not ready. "
            "Run `gh auth login` and/or set `GH_TOKEN` in .env."
        )

    bot_name = prompt_text("Bot name", default="AgentForge")
    bot_personality = prompt_text(
        "Bot personality / tone",
        default="Direct, pragmatic, and reliable.",
    )

    openai_api_key = ""
    brave_api_key = ""
    if prompt_yes_no("Configure optional API keys now?", default=True):
        openai_api_key = prompt_text(
            "OpenAI API key",
            default="",
            secret=True,
        )
        brave_api_key = prompt_text(
            "Brave Search API key",
            default="",
            secret=True,
        )

    return WizardAnswers(
        telegram_token=token,
        telegram_username=token_result.username,
        chat=chat,
        bot_name=bot_name,
        bot_personality=bot_personality,
        openai_api_key=openai_api_key,
        brave_api_key=brave_api_key,
        claude_status=claude_status,
    )


def forge_init(target_dir: str = ".", *, interactive: bool = True) -> None:
    """Initialize a new AgentForge instance in target_dir."""
    validate_python_version()
    root = Path(target_dir).resolve()
    ensure_target_writable(root)

    answers = collect_wizard_answers() if interactive else None
    bot_name = answers.bot_name if answers else "assistant"
    scaffold_instance(
        root,
        config=build_config(root, answers),
        env_text=build_env_text(answers),
        env_example_text=build_env_text(answers, include_secrets=False),
        soul_text=build_soul_text(answers),
        bot_name=bot_name,
    )

    agent_name = bot_name.lower().strip() or "architect"
    print("\nAgentForge instance initialized.")
    print("\nNext steps:")
    if interactive and answers is not None:
        print("  1. Review .env and confirm token variables")
        print(f"  2. Review vault/Agents/{agent_name}/soul.md and adjust the agent identity")
        print("  3. Edit vault/Agents/_team/CLAUDE.md with shared instance rules")
        print("  4. Edit vault/Agents/_team/memory.md with shared injected facts")
        print("  5. Use git-repos/ for repositories shared across all agents")
        print(f"  6. Run: AGENTFORGE_ROOT={root} AGENT_NAME={agent_name} AGENT_DIR={root}/agents/{agent_name} agentforge bot")
    else:
        print(f"  1. Edit .env — add {agent_name.upper()}_TELEGRAM_TOKEN=<your_token>")
        print(f"  2. Edit agents/{agent_name}/config.json with your chat IDs")
        print(f"  3. Edit vault/Agents/{agent_name}/soul.md to define your bot's personality")
        print("  4. Edit vault/Agents/_team/CLAUDE.md with shared instance rules")
        print("  5. Edit vault/Agents/_team/memory.md with shared injected facts")
        print("  6. Add structured tasks via 2Do or /todo-add")
        print("  7. Use git-repos/ for repositories shared across all agents")
        print(f"  8. Run: AGENTFORGE_ROOT={root} AGENT_NAME={agent_name} AGENT_DIR={root}/agents/{agent_name} agentforge bot")
