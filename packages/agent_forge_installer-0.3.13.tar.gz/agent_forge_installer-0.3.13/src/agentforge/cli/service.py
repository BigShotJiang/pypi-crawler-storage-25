"""agentforge service — systemd service management."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from agentforge.paths import resolve_root, resolve_runtime_bin_dir, resolve_runtime_root, resolve_runtime_scripts_dir

SERVICE_TEMPLATE = """\
[Unit]
Description=AgentForge Telegram Bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory={root}
ExecStart={venv_bin}/agentforge bot
EnvironmentFile={root}/.env
Environment=AGENTFORGE_ROOT={root}
Environment=AGENTFORGE_RUNTIME_ROOT={runtime_root}
Restart=on-failure
RestartSec=10

[Install]
WantedBy=default.target
"""

HEARTBEAT_TIMER_TEMPLATE = """\
[Unit]
Description=AgentForge Heartbeat Timer

[Timer]
OnCalendar=*:0/{interval_minutes}
Persistent=true

[Install]
WantedBy=timers.target
"""

HEARTBEAT_SERVICE_TEMPLATE = """\
[Unit]
Description=AgentForge Heartbeat
After=network-online.target

[Service]
Type=oneshot
WorkingDirectory={root}
ExecStart={scripts}/heartbeat.sh
EnvironmentFile={root}/.env
Environment=AGENTFORGE_ROOT={root}
Environment=AGENTFORGE_RUNTIME_ROOT={runtime_root}
"""

MONITORING_TIMER_TEMPLATE = """\
[Unit]
Description=AgentForge Monitoring Heartbeat Timer

[Timer]
OnCalendar=*:0/{interval_minutes}
Persistent=true

[Install]
WantedBy=timers.target
"""

MONITORING_SERVICE_TEMPLATE = """\
[Unit]
Description=AgentForge Monitoring Heartbeat
After=network-online.target

[Service]
Type=oneshot
WorkingDirectory={root}
ExecStart={scripts}/monitoring_heartbeat.sh
EnvironmentFile={root}/.env
Environment=AGENTFORGE_ROOT={root}
Environment=AGENTFORGE_RUNTIME_ROOT={runtime_root}
"""


def _resolve_root() -> Path:
    return resolve_root()


def _find_venv_bin(root: Path) -> Path:
    """Find the venv bin directory."""
    venv = resolve_runtime_bin_dir(root)
    if venv.exists():
        return venv
    # Check if we're in a venv right now
    if os.environ.get("VIRTUAL_ENV"):
        return Path(os.environ["VIRTUAL_ENV"]) / "bin"
    return venv  # default even if doesn't exist yet


def service_generate(
    *,
    name: str = "agentforge",
    heartbeat: bool = True,
    heartbeat_interval: int = 60,
    monitoring: bool = True,
    monitoring_interval: int = 5,
) -> None:
    """Generate systemd user service files."""
    root = _resolve_root()
    service_dir = Path.home() / ".config" / "systemd" / "user"
    service_dir.mkdir(parents=True, exist_ok=True)

    runtime_root = resolve_runtime_root(root)
    venv_bin = _find_venv_bin(root)
    scripts_dir = resolve_runtime_scripts_dir(root)

    # Main bot service
    service_file = service_dir / f"{name}.service"
    service_file.write_text(SERVICE_TEMPLATE.format(
        root=root,
        venv_bin=venv_bin,
        runtime_root=runtime_root,
    ))
    print(f"  Created {service_file}")

    # Heartbeat timer + service
    if heartbeat:
        hb_service = service_dir / f"{name}-heartbeat.service"
        hb_timer = service_dir / f"{name}-heartbeat.timer"

        hb_service.write_text(HEARTBEAT_SERVICE_TEMPLATE.format(
            root=root,
            scripts=scripts_dir,
            runtime_root=runtime_root,
        ))
        hb_timer.write_text(HEARTBEAT_TIMER_TEMPLATE.format(
            interval_minutes=heartbeat_interval,
        ))
        print(f"  Created {hb_service}")
        print(f"  Created {hb_timer}")

    if monitoring:
        monitor_service = service_dir / f"{name}-monitoring.service"
        monitor_timer = service_dir / f"{name}-monitoring.timer"
        monitor_service.write_text(MONITORING_SERVICE_TEMPLATE.format(
            root=root,
            scripts=scripts_dir,
            runtime_root=runtime_root,
        ))
        monitor_timer.write_text(MONITORING_TIMER_TEMPLATE.format(
            interval_minutes=monitoring_interval,
        ))
        print(f"  Created {monitor_service}")
        print(f"  Created {monitor_timer}")

    print()
    print("Enable and start with:")
    print(f"  systemctl --user daemon-reload")
    print(f"  systemctl --user enable --now {name}")
    if heartbeat:
        print(f"  systemctl --user enable --now {name}-heartbeat.timer")
    if monitoring:
        print(f"  systemctl --user enable --now {name}-monitoring.timer")
    print()
    print("View logs:")
    print(f"  journalctl --user -u {name} -f")


def service_status(*, name: str = "agentforge") -> None:
    """Show service status."""
    try:
        result = subprocess.run(
            ["systemctl", "--user", "status", f"{name}.service"],
            capture_output=True, text=True,
        )
        print(result.stdout)
        if result.stderr:
            print(result.stderr)
    except FileNotFoundError:
        print("systemctl not found — systemd is not available on this system.")
        sys.exit(1)


def service_logs(*, name: str = "agentforge", lines: int = 50) -> None:
    """Show recent service logs."""
    try:
        subprocess.run(
            ["journalctl", "--user", "-u", f"{name}.service",
             "-n", str(lines), "--no-pager"],
        )
    except FileNotFoundError:
        print("journalctl not found — systemd is not available on this system.")
        sys.exit(1)
