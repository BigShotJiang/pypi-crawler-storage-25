"""agentforge sync — Syncthing-based knowledge vault sync."""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

from agentforge.paths import resolve_root, resolve_vault_root

SYNCTHING_SERVICE_TEMPLATE = """\
[Unit]
Description=Syncthing for AgentForge
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/syncthing serve --no-browser --no-default-folder --home={config_dir}
Restart=on-failure
RestartSec=10

[Install]
WantedBy=default.target
"""


def _resolve_root() -> Path:
    return resolve_root()


def _find_syncthing() -> str | None:
    """Find syncthing binary."""
    for candidate in ["/usr/bin/syncthing", "/usr/local/bin/syncthing"]:
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    # Try PATH
    try:
        result = subprocess.run(["which", "syncthing"], capture_output=True, text=True)
        if result.returncode == 0:
            return result.stdout.strip()
    except FileNotFoundError:
        pass
    return None


def sync_setup() -> None:
    """Interactive Syncthing setup for knowledge vault syncing."""
    root = _resolve_root()

    print("── AgentForge Sync Setup ──")
    print()

    # 1. Check Syncthing
    syncthing_bin = _find_syncthing()
    if not syncthing_bin:
        print("❌ Syncthing is not installed.")
        print()
        print("Install it first:")
        print("  sudo apt install syncthing      # Debian/Ubuntu")
        print("  brew install syncthing           # macOS")
        print("  https://syncthing.net/downloads/ # Other")
        sys.exit(1)

    version_result = subprocess.run(
        [syncthing_bin, "--version"], capture_output=True, text=True,
    )
    version = version_result.stdout.split()[1] if version_result.returncode == 0 else "unknown"
    print(f"✅ Syncthing found: {version}")

    # 2. Determine vault path
    vault_path = resolve_vault_root(root)
    obsidian_path = root / "obsidian-brain"

    # Check if obsidian vault exists (migration path)
    if obsidian_path.exists() and not vault_path.exists():
        print(f"ℹ️  Found existing Obsidian vault at {obsidian_path}")
        print(f"   Will sync: {obsidian_path}")
        sync_path = obsidian_path
    elif vault_path.exists():
        print(f"✅ Vault directory: {vault_path}")
        sync_path = vault_path
    else:
        vault_path.mkdir(parents=True, exist_ok=True)
        print(f"📁 Created vault directory: {vault_path}")
        sync_path = vault_path

    # 3. Generate Syncthing config directory
    config_dir = root / ".syncthing"
    config_dir.mkdir(parents=True, exist_ok=True)

    # 4. Generate systemd service
    service_dir = Path.home() / ".config" / "systemd" / "user"
    service_dir.mkdir(parents=True, exist_ok=True)
    service_file = service_dir / "agentforge-sync.service"

    service_content = SYNCTHING_SERVICE_TEMPLATE.format(
        config_dir=config_dir,
    ).replace("/usr/bin/syncthing", syncthing_bin)

    service_file.write_text(service_content)
    print(f"✅ Created systemd service: {service_file}")

    # 5. Create a sync info file
    sync_info = {
        "sync_path": str(sync_path),
        "syncthing_config": str(config_dir),
        "syncthing_bin": syncthing_bin,
        "setup_complete": True,
    }
    info_file = root / "data" / "sync_config.json"
    info_file.parent.mkdir(parents=True, exist_ok=True)
    info_file.write_text(json.dumps(sync_info, indent=2) + "\n")
    print(f"✅ Saved sync config: {info_file}")

    # 6. Instructions
    print()
    print("── Next Steps ──")
    print()
    print("1. Start Syncthing:")
    print("   systemctl --user daemon-reload")
    print("   systemctl --user enable --now agentforge-sync")
    print()
    print("2. Open the Syncthing web UI:")
    print("   http://localhost:8384")
    print()
    print("3. In the web UI, add a folder pointing to:")
    print(f"   {sync_path}")
    print()
    print("4. On your other devices (phone, laptop):")
    print("   - Install Syncthing")
    print("   - Add this server as a remote device (use the Device ID from the web UI)")
    print("   - Share the folder")
    print()
    print("Tip: For Android, use 'Syncthing-Fork' from F-Droid.")
    print("     For iOS, use 'Möbius Sync' from the App Store.")
    print()
    print(f"Vault to sync: {sync_path}")


def sync_status() -> None:
    """Show Syncthing sync status."""
    syncthing_bin = _find_syncthing()
    if not syncthing_bin:
        print("Syncthing is not installed.")
        sys.exit(1)

    # Check if the service is running
    result = subprocess.run(
        ["systemctl", "--user", "is-active", "agentforge-sync"],
        capture_output=True, text=True,
    )
    status = result.stdout.strip()

    if status == "active":
        print("✅ Syncthing is running")
    else:
        print(f"⚠️  Syncthing service status: {status}")
        print("   Start with: systemctl --user start agentforge-sync")

    # Show sync config if it exists
    root = _resolve_root()
    info_file = root / "data" / "sync_config.json"
    if info_file.exists():
        info = json.loads(info_file.read_text())
        print(f"   Synced folder: {info.get('sync_path', 'unknown')}")
    else:
        print("   No sync configured. Run: agentforge sync setup")
