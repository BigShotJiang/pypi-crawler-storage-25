"""LLM backend selection helpers."""

from __future__ import annotations

BACKEND_CLAUDE = "claude"
BACKEND_OLLAMA = "ollama"
BACKEND_CODEX = "codex"
VALID_BACKENDS = {BACKEND_CLAUDE, BACKEND_OLLAMA, BACKEND_CODEX}

_CLAUDE_MODEL_ALIASES = {
    "sonnet",
    "opus",
    "haiku",
    "claude-opus-4-6",
    "claude-sonnet-4-6",
    "claude-haiku-4-5",
    "claude-haiku-4-5-20251001",
}


def infer_backend(model: str) -> str | None:
    """Infer a backend from a model string when legacy config omits it."""
    normalized = (model or "").strip().lower()
    if not normalized:
        return None
    if normalized in _CLAUDE_MODEL_ALIASES or normalized.startswith("claude-"):
        return BACKEND_CLAUDE
    if ":" in normalized:
        return BACKEND_OLLAMA
    return None


def resolve_backend(configured_backend: str | None, model: str) -> str:
    """Resolve a concrete backend from config, falling back to legacy inference."""
    normalized = (configured_backend or "").strip().lower()
    if normalized:
        if normalized not in VALID_BACKENDS:
            raise ValueError(f"Unsupported backend '{configured_backend}'")
        return normalized
    inferred = infer_backend(model)
    if inferred:
        return inferred
    # Backward compatibility: unknown model strings historically flowed through
    # the Claude runner. Codex should be configured explicitly.
    return BACKEND_CLAUDE

