#!/usr/bin/env python3
"""Memory manager — CLI interface to Clawdia's conversation database.

Usage:
  python3 memory_manager.py init          # Initialize database
  python3 memory_manager.py search "text" # Full-text search
  python3 memory_manager.py recent [N]    # Last N messages
  python3 memory_manager.py stats         # Database statistics
"""

import json
import os
import sqlite3
import sys
from pathlib import Path

AGENTFORGE_ROOT = os.environ.get('AGENTFORGE_ROOT', '/home/clawdia')
DB_PATH = os.path.join(AGENTFORGE_ROOT, 'data', 'conversations.db')


def get_db():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(DB_PATH)


def init_db():
    conn = get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            timestamp TEXT NOT NULL DEFAULT (datetime('now')),
            role TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system')),
            content TEXT NOT NULL,
            source TEXT NOT NULL DEFAULT 'telegram',
            telegram_chat_id TEXT,
            telegram_message_id TEXT,
            metadata TEXT
        );

        CREATE INDEX IF NOT EXISTS idx_conversations_session
            ON conversations(session_id);
        CREATE INDEX IF NOT EXISTS idx_conversations_timestamp
            ON conversations(timestamp);
        CREATE INDEX IF NOT EXISTS idx_conversations_source
            ON conversations(source);
    """)

    # Create FTS table if it doesn't exist
    cur = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='conversations_fts'"
    )
    if not cur.fetchone():
        conn.executescript("""
            CREATE VIRTUAL TABLE conversations_fts USING fts5(
                content,
                content='conversations',
                content_rowid='id'
            );

            CREATE TRIGGER IF NOT EXISTS conversations_ai
                AFTER INSERT ON conversations BEGIN
                INSERT INTO conversations_fts(rowid, content)
                    VALUES (new.id, new.content);
            END;

            CREATE TRIGGER IF NOT EXISTS conversations_ad
                AFTER DELETE ON conversations BEGIN
                INSERT INTO conversations_fts(conversations_fts, rowid, content)
                    VALUES('delete', old.id, old.content);
            END;
        """)

    conn.commit()
    conn.close()
    print("Database initialized at", DB_PATH)


def search(query):
    conn = get_db()
    try:
        cur = conn.execute("""
            SELECT c.timestamp, c.role, c.content, c.source
            FROM conversations_fts fts
            JOIN conversations c ON c.id = fts.rowid
            WHERE conversations_fts MATCH ?
            ORDER BY c.timestamp DESC
            LIMIT 20
        """, (query,))
        rows = cur.fetchall()
        if not rows:
            print("No results found.")
            return
        for ts, role, content, source in rows:
            preview = content[:200].replace("\n", " ")
            print(f"[{ts}] ({source}) {role}: {preview}")
    finally:
        conn.close()


def recent(n=20):
    conn = get_db()
    try:
        cur = conn.execute("""
            SELECT timestamp, role, content, source
            FROM conversations ORDER BY id DESC LIMIT ?
        """, (n,))
        rows = cur.fetchall()
        if not rows:
            print("No messages yet.")
            return
        for ts, role, content, source in reversed(rows):
            preview = content[:200].replace("\n", " ")
            print(f"[{ts}] ({source}) {role}: {preview}")
    finally:
        conn.close()


def stats():
    conn = get_db()
    try:
        total = conn.execute("SELECT COUNT(*) FROM conversations").fetchone()[0]
        by_source = conn.execute(
            "SELECT source, COUNT(*) FROM conversations GROUP BY source"
        ).fetchall()
        by_role = conn.execute(
            "SELECT role, COUNT(*) FROM conversations GROUP BY role"
        ).fetchall()
        print(f"Total messages: {total}")
        if by_source:
            print("By source:")
            for source, count in by_source:
                print(f"  {source}: {count}")
        if by_role:
            print("By role:")
            for role, count in by_role:
                print(f"  {role}: {count}")
    finally:
        conn.close()


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "help"
    if cmd == "init":
        init_db()
    elif cmd == "search":
        if len(sys.argv) < 3:
            print("Usage: memory_manager.py search \"query\"")
            sys.exit(1)
        search(sys.argv[2])
    elif cmd == "recent":
        n = int(sys.argv[2]) if len(sys.argv) > 2 else 20
        recent(n)
    elif cmd == "stats":
        stats()
    else:
        print(__doc__)
