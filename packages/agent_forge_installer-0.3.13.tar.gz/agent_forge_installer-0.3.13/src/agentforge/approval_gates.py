"""Approval gate helpers for potentially dangerous operations."""

from __future__ import annotations

import json
import re
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

DANGEROUS_PATTERNS: tuple[str, ...] = (
    r"rm\s+-rf\b",
    r"rm\s+.*--no-preserve-root\b",
    r"git\s+push\s+.*--force\b",
    r"git\s+reset\s+--hard\b",
    r"git\s+clean\s+-f\b",
    r"systemctl\s+.*\b(?:stop|restart|disable)\b",
    r"gog\s+gmail\s+send\b",
    r"curl.*api.*payment",
    r">\s*\.env\b",
    r"echo.*>\s*.*\.env\b",
)

ALWAYS_BLOCKED_PATTERNS: tuple[str, ...] = (
    r"\bsudo\b",
    r"chmod\s+777\b",
    r"curl.*\|.*bash",
    r"wget.*\|.*sh",
)


@dataclass(frozen=True)
class ApprovalPolicyResult:
    status: str
    reason: str


@dataclass
class ApprovalRequest:
    request_id: str
    chat_id: str
    thread_id: int | None
    command_text: str
    created_at: float
    decision: str | None = None
    decided_at: float | None = None
    actor_id: str | None = None
    event: threading.Event | None = None


class ApprovalGates:
    """Tracks dangerous operations and coordinates Telegram approvals."""

    def __init__(
        self,
        *,
        root: str,
        timeout_seconds: int = 300,
        dangerous_patterns: tuple[str, ...] = DANGEROUS_PATTERNS,
        always_blocked_patterns: tuple[str, ...] = ALWAYS_BLOCKED_PATTERNS,
    ) -> None:
        self.timeout_seconds = timeout_seconds
        self._dangerous_re = tuple(re.compile(p, re.IGNORECASE) for p in dangerous_patterns)
        self._blocked_re = tuple(re.compile(p, re.IGNORECASE) for p in always_blocked_patterns)
        self._pending: dict[str, ApprovalRequest] = {}
        self._lock = threading.Lock()
        self._audit_lock = threading.Lock()
        self._audit_path = Path(root) / "logs" / "approval_audit.log"

    def evaluate_command(self, command_text: str) -> ApprovalPolicyResult:
        text = (command_text or "").strip()
        if not text:
            return ApprovalPolicyResult(status="safe", reason="empty")

        for pattern in self._blocked_re:
            if pattern.search(text):
                return ApprovalPolicyResult(status="blocked", reason=pattern.pattern)

        for pattern in self._dangerous_re:
            if pattern.search(text):
                return ApprovalPolicyResult(status="approval_required", reason=pattern.pattern)

        return ApprovalPolicyResult(status="safe", reason="no_match")

    def request_and_wait(
        self,
        *,
        chat_id: str,
        thread_id: int | None,
        command_text: str,
        actor_label: str,
        send_message_fn,
    ) -> ApprovalPolicyResult:
        request_id = uuid.uuid4().hex[:10]
        event = threading.Event()
        request = ApprovalRequest(
            request_id=request_id,
            chat_id=chat_id,
            thread_id=thread_id,
            command_text=command_text,
            created_at=time.time(),
            event=event,
        )
        with self._lock:
            self._pending[request_id] = request

        preview = " ".join(command_text.strip().split())
        if len(preview) > 140:
            preview = preview[:137] + "..."
        reply_markup = {
            "inline_keyboard": [[
                {"text": "Approve", "callback_data": f"approval:{request_id}:approve"},
                {"text": "Deny", "callback_data": f"approval:{request_id}:deny"},
            ]]
        }
        send_message_fn(
            chat_id,
            (
                f"Approval required for `{actor_label}` operation.\n"
                f"Pattern matched: `{self.evaluate_command(command_text).reason}`\n"
                f"Preview: `{preview}`\n"
                f"Request ID: `{request_id}` (expires in {self.timeout_seconds}s)"
            ),
            thread_id,
            reply_markup=reply_markup,
        )

        approved = event.wait(timeout=self.timeout_seconds)
        with self._lock:
            resolved = self._pending.pop(request_id, request)

        if not approved or resolved.decision is None:
            self._write_audit(
                request_id=request_id,
                status="timeout",
                actor_label=actor_label,
                chat_id=chat_id,
                thread_id=thread_id,
                command_text=command_text,
                decided_by=None,
                decision_latency_ms=int((time.time() - request.created_at) * 1000),
            )
            return ApprovalPolicyResult(status="timeout", reason="no_decision")

        latency_ms = int(((resolved.decided_at or time.time()) - request.created_at) * 1000)
        status = "approved" if resolved.decision == "approve" else "denied"
        self._write_audit(
            request_id=request_id,
            status=status,
            actor_label=actor_label,
            chat_id=chat_id,
            thread_id=thread_id,
            command_text=command_text,
            decided_by=resolved.actor_id,
            decision_latency_ms=latency_ms,
        )
        if resolved.decision == "approve":
            return ApprovalPolicyResult(status="approved", reason="approved_by_user")
        return ApprovalPolicyResult(status="denied", reason="denied_by_user")

    def resolve_callback(
        self,
        callback_data: str,
        *,
        actor_id: str | None = None,
    ) -> ApprovalPolicyResult | None:
        parts = (callback_data or "").split(":")
        if len(parts) != 3 or parts[0] != "approval":
            return None
        request_id, decision = parts[1], parts[2].lower()
        if decision not in {"approve", "deny"}:
            return ApprovalPolicyResult(status="invalid", reason="invalid_decision")

        with self._lock:
            req = self._pending.get(request_id)
            if req is None:
                return ApprovalPolicyResult(status="not_found", reason="expired_or_missing")
            req.decision = decision
            req.decided_at = time.time()
            req.actor_id = actor_id
            if req.event:
                req.event.set()
        return ApprovalPolicyResult(status="handled", reason=decision)

    def record_auto_decision(
        self,
        *,
        status: str,
        actor_label: str,
        chat_id: str,
        thread_id: int | None,
        command_text: str,
        reason: str,
    ) -> None:
        self._write_audit(
            request_id="auto-" + uuid.uuid4().hex[:8],
            status=status,
            actor_label=actor_label,
            chat_id=chat_id,
            thread_id=thread_id,
            command_text=command_text,
            decided_by=reason,
            decision_latency_ms=0,
        )

    def _write_audit(
        self,
        *,
        request_id: str,
        status: str,
        actor_label: str,
        chat_id: str,
        thread_id: int | None,
        command_text: str,
        decided_by: str | None,
        decision_latency_ms: int,
    ) -> None:
        self._audit_path.parent.mkdir(parents=True, exist_ok=True)
        record = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "request_id": request_id,
            "status": status,
            "actor": actor_label,
            "chat_id": chat_id,
            "thread_id": thread_id,
            "command_preview": " ".join(command_text.strip().split())[:200],
            "decided_by": decided_by,
            "decision_latency_ms": decision_latency_ms,
        }
        with self._audit_lock:
            with self._audit_path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, ensure_ascii=True) + "\n")
