"""Local embedding utilities with optional sentence-transformers backend."""

from __future__ import annotations

import hashlib
import math
import re
import struct
from dataclasses import dataclass


_TOKEN_RE = re.compile(r"[a-z0-9]+")
_SYNONYMS = {
    "budget": "finance",
    "budgeting": "finance",
    "financial": "finance",
    "finance": "finance",
    "money": "finance",
    "expense": "finance",
    "expenses": "finance",
    "tracking": "track",
    "tracker": "track",
    "track": "track",
    "app": "app",
    "apps": "app",
    "tool": "app",
    "tools": "app",
}


@dataclass(frozen=True)
class EmbeddingBackend:
    name: str
    model_name: str


class EmbeddingManager:
    """Compute embeddings and cosine similarity without external APIs."""

    def __init__(self, model_name: str = "all-MiniLM-L6-v2", fallback_dim: int = 256):
        self.model_name = model_name
        self.fallback_dim = fallback_dim
        self._model = None
        self.backend = EmbeddingBackend(name="fallback-hash", model_name=f"hash-{fallback_dim}")
        self._try_load_sentence_transformers(model_name)

    def _try_load_sentence_transformers(self, model_name: str) -> None:
        try:
            from sentence_transformers import SentenceTransformer  # type: ignore
        except Exception:
            return
        try:
            self._model = SentenceTransformer(model_name)
            self.backend = EmbeddingBackend(name="sentence-transformers", model_name=model_name)
        except Exception:
            self._model = None

    def encode(self, text: str) -> list[float]:
        payload = (text or "").strip()
        if self._model is not None:
            vec = self._model.encode(payload)
            return [float(x) for x in vec]
        return self._fallback_encode(payload)

    def serialize(self, vector: list[float]) -> bytes:
        return struct.pack(f"<{len(vector)}f", *vector)

    def deserialize(self, blob: bytes) -> list[float]:
        if not blob:
            return []
        if len(blob) % 4 != 0:
            raise ValueError("embedding blob length must be a multiple of 4")
        size = len(blob) // 4
        return list(struct.unpack(f"<{size}f", blob))

    @staticmethod
    def cosine_similarity(left: list[float], right: list[float]) -> float:
        if not left or not right or len(left) != len(right):
            return 0.0
        dot = sum(a * b for a, b in zip(left, right))
        left_norm = math.sqrt(sum(a * a for a in left))
        right_norm = math.sqrt(sum(b * b for b in right))
        if left_norm == 0 or right_norm == 0:
            return 0.0
        return dot / (left_norm * right_norm)

    def _fallback_encode(self, text: str) -> list[float]:
        vec = [0.0] * self.fallback_dim
        tokens = _TOKEN_RE.findall(text.lower())
        if not tokens:
            return vec
        for token in tokens:
            canonical = _SYNONYMS.get(token, token)
            idx = int(hashlib.sha256(canonical.encode("utf-8")).hexdigest(), 16) % self.fallback_dim
            vec[idx] += 1.0
        norm = math.sqrt(sum(v * v for v in vec))
        if norm == 0:
            return vec
        return [v / norm for v in vec]
