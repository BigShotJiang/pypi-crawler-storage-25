#!/usr/bin/env bash
# invoke_claude.sh — Invoke the configured LLM backend
# Usage: ./invoke_claude.sh "Your prompt here"

set -euo pipefail

AGENTFORGE_ROOT="${AGENTFORGE_ROOT:?AGENTFORGE_ROOT is not set}"
CONFIG="$AGENTFORGE_ROOT/bot/config.json"

if [ -z "${1:-}" ]; then
    echo "Usage: $0 \"Your prompt here\""
    exit 1
fi

PROMPT="$1"

# Read config values
BACKEND=$(python3 -c "import json; print(json.load(open('$CONFIG'))['claude'].get('backend', 'claude'))")
MODEL=$(python3 -c "import json; print(json.load(open('$CONFIG'))['claude'].get('model', 'sonnet'))")
MAX_BUDGET=$(python3 -c "import json; print(json.load(open('$CONFIG'))['claude'].get('max_budget_usd', 5))")

if [ "$BACKEND" = "ollama" ]; then
    exec ollama launch claude --model "$MODEL" -- \
        -p \
        --dangerously-skip-permissions \
        --output-format text \
        "$PROMPT"
fi

if [ "$BACKEND" = "codex" ]; then
    exec codex exec \
        --model "$MODEL" \
        --full-auto \
        --skip-git-repo-check \
        -C "$AGENTFORGE_ROOT" \
        "$PROMPT"
fi

exec "$AGENTFORGE_RUNTIME_ROOT/.local/bin/claude" -p \
    --model "$MODEL" \
    --dangerously-skip-permissions \
    --output-format text \
    --max-budget-usd "$MAX_BUDGET" \
    "$PROMPT"
