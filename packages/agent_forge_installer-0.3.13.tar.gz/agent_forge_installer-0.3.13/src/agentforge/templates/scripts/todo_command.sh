#!/usr/bin/env bash
set -euo pipefail

AGENTFORGE_ROOT="${AGENTFORGE_ROOT:?AGENTFORGE_ROOT is not set}"
PYTHON_BIN="$AGENTFORGE_RUNTIME_ROOT/.venv/bin/python3"
[ -x "$PYTHON_BIN" ] || PYTHON_BIN="python3"

COMMAND_NAME="${1:-}"
shift || true

CMD_RAW="${CMD_ARGS:-$*}" exec "$PYTHON_BIN" -m agentforge.todo_cli command "$COMMAND_NAME" --root "$AGENTFORGE_ROOT" --agent "${AGENT_NAME:-architect}"
