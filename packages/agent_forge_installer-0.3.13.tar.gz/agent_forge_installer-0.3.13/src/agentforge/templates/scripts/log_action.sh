#!/usr/bin/env bash
# log_action.sh -- Log an external action to Google Sheets "Actions" tab
# Usage: log_action.sh <agent> <type> <target> [details]
#
# agent:   <agent_name> | heartbeat | etc.
# type:    telegram_send | git_push | api_call | email | gog | etc.
# target:  telegram | github | gmail | sheets | etc.
# details: optional short description (max ~200 chars)
#
# Examples:
#   log_action.sh heartbeat git_push github "Ops sync"
#   log_action.sh victor telegram_send "user" "Response to a question"
#   log_action.sh catherine gog sheets "Append row to Heartbeat"

set -euo pipefail
export TZ=America/Montreal

AGENTFORGE_ROOT="${AGENTFORGE_ROOT:?AGENTFORGE_ROOT is not set}"
CONFIG="$AGENTFORGE_ROOT/bot/config.json"
LOG="$AGENTFORGE_ROOT/logs/actions.log"

AGENT="${1:-unknown}"
TYPE="${2:-unknown}"
TARGET="${3:-unknown}"
DETAILS="${4:-}"

NOW=$(date +"%Y-%m-%d %H:%M")

# Log locally always
echo "[$NOW] $AGENT | $TYPE | $TARGET | $DETAILS" >> "$LOG"

# Skip telegram_send calls — too noisy for the sheet
if [ "$TYPE" = "telegram_send" ]; then
    exit 0
fi

# Log to Google Sheets if configured
[ -f "$AGENTFORGE_ROOT/.env" ] && source "$AGENTFORGE_ROOT/.env" 2>/dev/null || true

SHEETS_ID=$(python3 -c "import json; print(json.load(open('$CONFIG')).get('logging', {}).get('sheets_id', ''))" 2>/dev/null || echo "")

if [ -n "$SHEETS_ID" ]; then
    # Prefer google_sa.py (service account, never expires) over gog (OAuth, expires weekly)
    GOOGLE_SA_SCRIPT="$AGENTFORGE_RUNTIME_ROOT/scripts/google_sa.py"
    if [ -f "$GOOGLE_SA_SCRIPT" ] && [ -n "${GOOGLE_SA_JSON:-}" ]; then
        python3 "$GOOGLE_SA_SCRIPT" sheets append "$SHEETS_ID" "Actions!A:E" "$NOW" "$AGENT" "$TYPE" "$TARGET" "$DETAILS" 2>> "$LOG" || \
            echo "[$NOW] WARNING: Sheets append failed (google_sa) for action: $TYPE" >> "$LOG"
    else
        # Fallback to gog if service account not configured
        gog sheets append "$SHEETS_ID" "Actions!A:E" "$NOW" "$AGENT" "$TYPE" "$TARGET" "$DETAILS" 2>> "$LOG" || \
            echo "[$NOW] WARNING: Sheets append failed (gog) for action: $TYPE" >> "$LOG"
    fi
fi
