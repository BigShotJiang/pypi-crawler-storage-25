#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
cd "$ROOT_DIR"

RUN_IOS=1
RUN_MACOS=1
RUN_TESTS=0
RUN_XCODEGEN=0
DO_CLEAR=1

usage() {
  cat <<'EOF'
Usage: ./scripts/dev-loop.sh [options]

Runs the local native app development loop from the project root.

Options:
  --ios-only       Run only the iOS simulator flow
  --macos-only     Run only the macOS rebuild + relaunch flow
  --with-tests     Run Swift package tests before launching apps
  --with-xcodegen  Regenerate the Xcode project before building
  --no-clear       Keep the current terminal contents
  --help           Show this help
EOF
}

while (($# > 0)); do
  case "$1" in
    --ios-only)
      RUN_IOS=1
      RUN_MACOS=0
      ;;
    --macos-only)
      RUN_IOS=0
      RUN_MACOS=1
      ;;
    --with-tests)
      RUN_TESTS=1
      ;;
    --with-xcodegen)
      RUN_XCODEGEN=1
      ;;
    --no-clear)
      DO_CLEAR=0
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
  shift
done

if [[ "$DO_CLEAR" -eq 1 ]] && [[ -t 1 ]]; then
  clear
fi

echo "== AgentForge dev loop =="

if [[ "$RUN_XCODEGEN" -eq 1 ]]; then
  echo
  echo "-- Regenerating Xcode project"
  make xcodegen
fi

if [[ "$RUN_TESTS" -eq 1 ]]; then
  echo
  echo "-- Running Swift package tests"
  make native-test
fi

if [[ "$RUN_IOS" -eq 1 ]] && [[ "$RUN_MACOS" -eq 1 ]]; then
  echo
  echo "-- iOS Simulator + macOS (make app-dev)"
  make app-dev
elif [[ "$RUN_IOS" -eq 1 ]]; then
  echo
  echo "-- Building, installing, and launching iOS simulator app"
  make ios-sim
elif [[ "$RUN_MACOS" -eq 1 ]]; then
  echo
  echo "-- Building and relaunching macOS app"
  make macos-run
fi

echo
echo "Done."
