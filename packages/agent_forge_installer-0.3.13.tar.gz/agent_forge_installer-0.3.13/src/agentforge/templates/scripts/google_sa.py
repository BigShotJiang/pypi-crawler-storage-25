#!/usr/bin/env python3
"""
google_sa.py — Google APIs via Service Account + Gmail SMTP App Password.

Drop-in replacement for the `gog` CLI used in AgentForge scripts.
Never expires — no OAuth tokens to renew.

SETUP (one-time):
  1. Google Cloud Console → Create Service Account → Download JSON key
     Share your Google Calendars and Sheets with the service account email.
     Set env var: GOOGLE_SA_JSON=/path/to/service-account.json
  2. Google Account → Security → 2-Step Verification → App Passwords
     Create an App Password for "Mail".
     Set env vars: GMAIL_APP_PASSWORD=xxxx xxxx xxxx xxxx
                   GMAIL_FROM=your-address@example.com

USAGE (mirrors gog interface):
  google_sa.py calendar list <calendar_id> [--today | --date YYYY-MM-DD]
  google_sa.py calendar create --title X --date YYYY-MM-DD --time HH:MM
                               --duration MINUTES --timezone TZ
                               [--attendees email1,email2]
  google_sa.py gmail send --to X --subject X [--body X] [--body-html X]
                          [--from X]
  google_sa.py gmail search "query"
  google_sa.py sheets append <sheets_id> <range> <val1> [val2 ...]
  google_sa.py sheets get <sheets_id> <range>

EXIT CODES: 0 = success, 1 = error (prints to stderr)
"""

import argparse
import json
import os
import smtplib
import sys
from datetime import date, datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _env(key, required=False):
    val = os.environ.get(key, "")
    if required and not val:
        print(f"ERROR: environment variable {key} is not set.", file=sys.stderr)
        sys.exit(1)
    return val


def _sa_creds(scopes):
    """Return google.oauth2.service_account.Credentials for the given scopes."""
    try:
        from google.oauth2 import service_account
    except ImportError:
        print(
            "ERROR: google-auth not installed. Run: pip install google-auth google-api-python-client",
            file=sys.stderr,
        )
        sys.exit(1)

    sa_json = _env("GOOGLE_SA_JSON", required=True)
    if not os.path.isfile(sa_json):
        print(f"ERROR: Service account file not found: {sa_json}", file=sys.stderr)
        sys.exit(1)

    return service_account.Credentials.from_service_account_file(sa_json, scopes=scopes)


def _build(service_name, version, scopes):
    """Build a Google API client."""
    try:
        from googleapiclient.discovery import build
    except ImportError:
        print(
            "ERROR: google-api-python-client not installed. Run: pip install google-api-python-client",
            file=sys.stderr,
        )
        sys.exit(1)
    creds = _sa_creds(scopes)
    return build(service_name, version, credentials=creds)


# ---------------------------------------------------------------------------
# Calendar
# ---------------------------------------------------------------------------

CALENDAR_SCOPES = ["https://www.googleapis.com/auth/calendar"]


def calendar_list(args):
    service = _build("calendar", "v3", CALENDAR_SCOPES)

    if args.today:
        target = date.today()
    elif args.date:
        target = datetime.strptime(args.date, "%Y-%m-%d").date()
    else:
        target = date.today()

    tz = "America/Toronto"
    time_min = f"{target}T00:00:00-05:00"
    time_max = f"{target}T23:59:59-05:00"

    result = (
        service.events()
        .list(
            calendarId=args.calendar_id,
            timeMin=time_min,
            timeMax=time_max,
            singleEvents=True,
            orderBy="startTime",
        )
        .execute()
    )

    events = result.get("items", [])
    if not events:
        print(f"No events on {target}.")
        return

    for ev in events:
        start = ev["start"].get("dateTime", ev["start"].get("date", ""))
        summary = ev.get("summary", "(no title)")
        # Format: HH:MM — Summary
        try:
            dt = datetime.fromisoformat(start)
            print(f"{dt.strftime('%H:%M')} — {summary}")
        except ValueError:
            print(f"{start} — {summary}")


def calendar_create(args):
    service = _build("calendar", "v3", CALENDAR_SCOPES)

    start_dt = datetime.strptime(f"{args.date} {args.time}", "%Y-%m-%d %H:%M")
    end_dt = start_dt + timedelta(minutes=int(args.duration))

    tz = args.timezone or "America/Toronto"
    fmt = "%Y-%m-%dT%H:%M:%S"

    event = {
        "summary": args.title,
        "start": {"dateTime": start_dt.strftime(fmt), "timeZone": tz},
        "end": {"dateTime": end_dt.strftime(fmt), "timeZone": tz},
    }

    if args.attendees:
        event["attendees"] = [
            {"email": e.strip()} for e in args.attendees.split(",") if e.strip()
        ]

    if args.description:
        event["description"] = args.description

    cal_id = args.calendar or "primary"
    created = service.events().insert(calendarId=cal_id, body=event, sendUpdates="all").execute()
    print(f"Created: {created.get('summary')} — {created.get('htmlLink')}")


# ---------------------------------------------------------------------------
# Gmail (SMTP with App Password — works with personal Gmail)
# ---------------------------------------------------------------------------

def gmail_send(args):
    smtp_user = args.from_addr or _env("GMAIL_FROM", required=True)
    app_password = _env("GMAIL_APP_PASSWORD", required=True)

    msg = MIMEMultipart("alternative")
    msg["Subject"] = args.subject
    msg["From"] = smtp_user
    msg["To"] = args.to

    if args.body:
        msg.attach(MIMEText(args.body, "plain"))
    if args.body_html:
        msg.attach(MIMEText(args.body_html, "html"))
    if not args.body and not args.body_html:
        print("ERROR: provide --body or --body-html", file=sys.stderr)
        sys.exit(1)

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
        smtp.login(smtp_user, app_password)
        smtp.sendmail(smtp_user, args.to, msg.as_string())

    print(f"Sent to {args.to}: {args.subject}")


def gmail_search(args):
    """
    Gmail search via IMAP (uses App Password).
    Prints matching message subjects (up to 20).
    """
    import imaplib
    import email as email_lib

    smtp_user = _env("GMAIL_FROM", required=True)
    app_password = _env("GMAIL_APP_PASSWORD", required=True)

    with imaplib.IMAP4_SSL("imap.gmail.com") as imap:
        imap.login(smtp_user, app_password)
        imap.select("INBOX")

        # Convert gog-style query to IMAP search criteria
        query = args.query
        if query in ("in:INBOX", ""):
            imap_criteria = "ALL"
        elif query.startswith("subject:"):
            subj = query[8:].strip('"')
            imap_criteria = f'SUBJECT "{subj}"'
        else:
            imap_criteria = f'TEXT "{query}"'

        _, data = imap.search(None, imap_criteria)
        msg_ids = data[0].split()[-20:]  # last 20

        for mid in reversed(msg_ids):
            _, msg_data = imap.fetch(mid, "(RFC822.SIZE BODY[HEADER.FIELDS (SUBJECT FROM DATE)])")
            if msg_data and msg_data[0]:
                raw = msg_data[0][1]
                parsed = email_lib.message_from_bytes(raw)
                print(f"{parsed.get('Date', '')} | {parsed.get('From', '')} | {parsed.get('Subject', '')}")


# ---------------------------------------------------------------------------
# Sheets
# ---------------------------------------------------------------------------

SHEETS_SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]


def sheets_append(args):
    service = _build("sheets", "v4", SHEETS_SCOPES)
    body = {"values": [args.values]}
    service.spreadsheets().values().append(
        spreadsheetId=args.sheets_id,
        range=args.range,
        valueInputOption="USER_ENTERED",
        body=body,
    ).execute()
    print(f"Appended to {args.range}: {args.values}")


def sheets_get(args):
    service = _build("sheets", "v4", SHEETS_SCOPES)
    result = (
        service.spreadsheets()
        .values()
        .get(spreadsheetId=args.sheets_id, range=args.range)
        .execute()
    )
    rows = result.get("values", [])
    for row in rows:
        print("\t".join(row))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="google_sa.py — Google APIs via Service Account / App Password"
    )
    sub = parser.add_subparsers(dest="service", required=True)

    # --- calendar ---
    cal = sub.add_parser("calendar", aliases=["cal"])
    cal_sub = cal.add_subparsers(dest="action", required=True)

    cal_list = cal_sub.add_parser("list")
    cal_list.add_argument("calendar_id")
    cal_list.add_argument("--today", action="store_true")
    cal_list.add_argument("--date", default=None)

    cal_create = cal_sub.add_parser("create")
    cal_create.add_argument("--title", required=True)
    cal_create.add_argument("--date", required=True)
    cal_create.add_argument("--time", required=True)
    cal_create.add_argument("--duration", default="60")
    cal_create.add_argument("--timezone", default="America/Toronto")
    cal_create.add_argument("--attendees", default="")
    cal_create.add_argument("--description", default="")
    cal_create.add_argument("--calendar", default="primary")

    # --- gmail ---
    gm = sub.add_parser("gmail")
    gm_sub = gm.add_subparsers(dest="action", required=True)

    gm_send = gm_sub.add_parser("send")
    gm_send.add_argument("--from", dest="from_addr", default="")
    gm_send.add_argument("--to", required=True)
    gm_send.add_argument("--subject", required=True)
    gm_send.add_argument("--body", default="")
    gm_send.add_argument("--body-html", dest="body_html", default="")

    gm_search = gm_sub.add_parser("search")
    gm_search.add_argument("query", nargs="?", default="in:INBOX")

    gm_list = gm_sub.add_parser("list")
    gm_list.add_argument("folder", nargs="?", default="inbox")

    # --- sheets ---
    sh = sub.add_parser("sheets")
    sh_sub = sh.add_subparsers(dest="action", required=True)

    sh_append = sh_sub.add_parser("append")
    sh_append.add_argument("sheets_id")
    sh_append.add_argument("range")
    sh_append.add_argument("values", nargs="+")

    sh_get = sh_sub.add_parser("get")
    sh_get.add_argument("sheets_id")
    sh_get.add_argument("range")

    args = parser.parse_args()
    service = args.service

    # Dispatch
    if service in ("calendar", "cal"):
        if args.action == "list":
            calendar_list(args)
        elif args.action == "create":
            calendar_create(args)

    elif service == "gmail":
        if args.action == "send":
            gmail_send(args)
        elif args.action in ("search", "list"):
            gmail_search(args)

    elif service == "sheets":
        if args.action == "append":
            sheets_append(args)
        elif args.action == "get":
            sheets_get(args)


if __name__ == "__main__":
    main()
