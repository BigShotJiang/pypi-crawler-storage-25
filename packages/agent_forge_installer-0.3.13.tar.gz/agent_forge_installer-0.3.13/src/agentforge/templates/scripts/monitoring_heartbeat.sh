#!/usr/bin/env bash
set -euo pipefail

AGENTFORGE_ROOT="${AGENTFORGE_ROOT:?AGENTFORGE_ROOT is not set}"
LOG_DIR="$AGENTFORGE_ROOT/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/monitoring-heartbeat.log"

if [ -f "$AGENTFORGE_RUNTIME_ROOT/.venv/bin/activate" ]; then
  # shellcheck disable=SC1090
  source "$AGENTFORGE_RUNTIME_ROOT/.venv/bin/activate"
fi

cd "$AGENTFORGE_ROOT"

echo "[$(date -u +'%Y-%m-%d %H:%M:%S')] monitoring heartbeat starting" >> "$LOG_FILE"
python3 -m agentforge.monitoring_job >> "$LOG_FILE" 2>&1
