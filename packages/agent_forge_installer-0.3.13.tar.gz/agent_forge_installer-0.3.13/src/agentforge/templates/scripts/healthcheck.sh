#!/usr/bin/env bash
# healthcheck.sh — Daily system health check
set -euo pipefail
export TZ=America/Montreal
AGENTFORGE_ROOT="${AGENTFORGE_ROOT:?AGENTFORGE_ROOT is not set}"
source "$AGENTFORGE_ROOT/.env"

LOG="$AGENTFORGE_ROOT/logs/healthcheck.log"
TODAY=$(date +%Y-%m-%d)
NOW=$(date +%H:%M)
ISSUES=()

echo "[$TODAY $NOW] Health check starting" >> "$LOG"

# 1. Telegram adapter running?
if pgrep -f "telegram_adapter.py" > /dev/null; then
    echo "[$TODAY $NOW] telegram_adapter: OK" >> "$LOG"
else
    ISSUES+=("- Telegram adapter NOT running")
    echo "[$TODAY $NOW] telegram_adapter: DOWN" >> "$LOG"
fi

# 2. Last heartbeat recent? (within last 2 hours)
LAST_HB=$(grep "Heartbeat starting" "$AGENTFORGE_ROOT/logs/heartbeat.log" 2>/dev/null | tail -1 | grep -o '\[.*\]' | tr -d '[]' || echo "never")
LAST_HB_TS=$(date -d "$LAST_HB" +%s 2>/dev/null || echo 0)
NOW_TS=$(date +%s)
AGE=$(( (NOW_TS - LAST_HB_TS) / 60 ))
if [ "$AGE" -lt 120 ]; then
    echo "[$TODAY $NOW] last heartbeat: ${AGE}min ago -- OK" >> "$LOG"
else
    ISSUES+=("- Last heartbeat was ${AGE}min ago (expected <120min)")
    echo "[$TODAY $NOW] last heartbeat: ${AGE}min ago -- STALE" >> "$LOG"
fi

# 3. Heartbeat cron errors in last 24h?
if tail -50 "$AGENTFORGE_ROOT/logs/heartbeat-cron.log" 2>/dev/null | grep -q "syntax error\|command not found"; then
    RECENT_ERRORS=$(tail -50 "$AGENTFORGE_ROOT/logs/heartbeat-cron.log" | grep "syntax error\|command not found" | tail -3 | tr '\n' ' ')
    ISSUES+=("- Heartbeat cron errors: $RECENT_ERRORS")
fi

# 4. Vault git status
if git -C "$AGENTFORGE_ROOT/obsidian-brain" status > /dev/null 2>&1; then
    git -C "$AGENTFORGE_ROOT/obsidian-brain" fetch origin --quiet 2>/dev/null || true
    BEHIND=$(git -C "$AGENTFORGE_ROOT/obsidian-brain" rev-list HEAD..origin/main --count 2>/dev/null || echo 0)
    if [ "$BEHIND" = "0" ]; then
        echo "[$TODAY $NOW] vault git: OK" >> "$LOG"
    else
        ISSUES+=("- Vault is ${BEHIND} commits behind GitHub")
    fi
else
    ISSUES+=("- Vault git repo not accessible")
fi

# 5. Disk space (warn if > 85%)
DISK_USE=$(df / | awk 'NR==2 {print $5}' | tr -d '%')
if [ "$DISK_USE" -lt 85 ]; then
    echo "[$TODAY $NOW] disk: ${DISK_USE}% -- OK" >> "$LOG"
else
    ISSUES+=("- Disk usage at ${DISK_USE}%")
fi

# 6. Inbox stuck? (files older than 3h = Catherine not processing)
STUCK=$(find "$AGENTFORGE_ROOT/obsidian-brain/Inbox/" -name "*.md" -not -name ".gitkeep" -mmin +180 2>/dev/null | wc -l)
if [ "$STUCK" -gt 0 ]; then
    STUCK_FILES=$(find "$AGENTFORGE_ROOT/obsidian-brain/Inbox/" -name "*.md" -not -name ".gitkeep" -mmin +180 | xargs -I{} basename {} | tr '\n' ', ' | sed 's/,$//')
    ISSUES+=("- Inbox stuck (${STUCK} file(s) >3h old): $STUCK_FILES")
fi

# Build and send report
if [ ${#ISSUES[@]} -gt 0 ]; then
    ISSUE_LIST=$(printf '\n%s' "${ISSUES[@]}")
    MSG="$(printf '⚠️ *Health Check %s %s*\n\nIssues detected:%s' "$TODAY" "$NOW" "$ISSUE_LIST")"
else
    MSG="$(printf '🏥 *Health Check %s %s*\n- Telegram adapter: OK\n- Heartbeat: OK (%smin ago)\n- Vault git: OK\n- Disk: %s%%\n- Inbox: clear' "$TODAY" "$NOW" "$AGE" "$DISK_USE")"
fi

echo "[$TODAY $NOW] Done -- ${#ISSUES[@]} issue(s)" >> "$LOG"
echo "---" >> "$LOG"

"$AGENTFORGE_ROOT/bot/telegram_send.sh" heartbeat "$MSG" 2>/dev/null || true
