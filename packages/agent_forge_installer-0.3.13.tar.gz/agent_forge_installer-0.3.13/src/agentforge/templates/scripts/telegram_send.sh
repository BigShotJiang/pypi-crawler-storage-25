#!/usr/bin/env bash
# Usage: telegram_send.sh <topic> <message> [--from <agent>]
# Topics: <agent-name>  (reads thread ID from agents/<topic>/config.json when available)
#         or bot/config.json telegram.topics, or TELEGRAM_THREAD_<TOPIC> for special topics
# --from : optional sender name (kept for compatibility, no longer prefixes)
set -euo pipefail
AGENTFORGE_ROOT="${AGENTFORGE_ROOT:?AGENTFORGE_ROOT is not set}"
source "$AGENTFORGE_ROOT/.env"

TOPIC="$1"
MSG="$2"
# Parse and ignore optional --from argument (kept for compatibility)
shift 2
while [[ $# -gt 0 ]]; do
    case "$1" in
        --from) shift 2 ;;
        *) shift ;;
    esac
done
GROUP_CHAT_ID="${TELEGRAM_GROUP_CHAT_ID:?TELEGRAM_GROUP_CHAT_ID is not set}"

# Resolve thread ID: try agent config.json first, then legacy bot/config.json, then env var fallback.
AGENT_CONFIG="$AGENTFORGE_ROOT/agents/$TOPIC/config.json"
LEGACY_CONFIG="$AGENTFORGE_ROOT/bot/config.json"
THREAD_ID=""
if [ -f "$AGENT_CONFIG" ]; then
    THREAD_ID=$(python3 -c "
import json, sys
c = json.load(open(sys.argv[1]))
threads = c.get('telegram', {}).get('default_for_threads', [])
t = next((x for x in threads if x is not None), None)
print(t if t is not None else '')
" "$AGENT_CONFIG" 2>/dev/null || echo "")
fi

if [ -z "$THREAD_ID" ] && [ -f "$LEGACY_CONFIG" ]; then
    THREAD_ID=$(python3 -c "
import json, sys
c = json.load(open(sys.argv[1]))
topics = c.get('telegram', {}).get('topics', {})
print(topics.get(sys.argv[2], ''))
" "$LEGACY_CONFIG" "$TOPIC" 2>/dev/null || echo "")
fi

if [ -z "$THREAD_ID" ]; then
    # No config-based mapping for this topic — fall back to TELEGRAM_THREAD_<TOPIC> env var
    _THREAD_VAR="TELEGRAM_THREAD_${TOPIC^^}"
    THREAD_ID="${!_THREAD_VAR:-}"
fi

if [ -z "$THREAD_ID" ]; then
    echo "Unknown topic: $TOPIC (no agent config thread, no bot/config.json telegram.topics entry, and no TELEGRAM_THREAD_${TOPIC^^} env var)" >&2
    exit 1
fi

# Use the calling agent's token (from $AGENT_NAME env var)
AGENT_TOKEN_VAR="${AGENT_NAME^^}_TELEGRAM_TOKEN"
TOKEN="${!AGENT_TOKEN_VAR:?${AGENT_TOKEN_VAR} is not set}"

# Dedup: prevent sending identical message to same topic within 60 seconds
DEDUP_LOG="$AGENTFORGE_ROOT/logs/telegram_send.log"
MSG_HASH=$(echo "${TOPIC}:${MSG}" | md5sum | cut -d' ' -f1)
NOW=$(date +%s)
if [ -f "$DEDUP_LOG" ]; then
    RECENT=$(tail -20 "$DEDUP_LOG" | grep "hash=$MSG_HASH" | tail -1 || true)
    if [ -n "$RECENT" ]; then
        LAST_TS=$(echo "$RECENT" | grep -oP 'ts=\K[0-9]+' || echo "0")
        if [ $((NOW - LAST_TS)) -lt 60 ]; then
            echo "[telegram_send] DEDUP SKIP: identical message to $TOPIC within 60s" >&2
            exit 0
        fi
    fi
fi

RESPONSE=$(curl -s -X POST "https://api.telegram.org/bot${TOKEN}/sendMessage" \
    -d "chat_id=${GROUP_CHAT_ID}" \
    -d "message_thread_id=${THREAD_ID}" \
    --data-urlencode "text=${MSG}" \
    -d "parse_mode=Markdown")
# Log message_id for potential future deletion
MSG_ID=$(echo "$RESPONSE" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('result',{}).get('message_id','?'))" 2>/dev/null || echo "?")
echo "[telegram_send] topic=$TOPIC thread=$THREAD_ID msg_id=$MSG_ID ts=$NOW hash=$MSG_HASH" >> "$AGENTFORGE_ROOT/logs/telegram_send.log"

# Log external action
PREVIEW=$(echo "$MSG" | head -c 100 | tr '\n' ' ')
"$AGENTFORGE_ROOT/bot/log_action.sh" "$TOPIC" telegram_send "telegram" "$PREVIEW" 2>/dev/null || true
