#!/usr/bin/env bash
# memory_consolidation.sh — Weekly memory consolidation for all agents
# Runs every Sunday at 23h via cron
set -euo pipefail
export TZ=America/Montreal

AGENTFORGE_ROOT="${AGENTFORGE_ROOT:?AGENTFORGE_ROOT is not set}"
export HOME="$AGENTFORGE_ROOT"
LOG="$AGENTFORGE_ROOT/logs/memory-consolidation.log"
TODAY=$(date +%Y-%m-%d)
NOW=$(date +%H:%M)
CLAUDE="$AGENTFORGE_RUNTIME_ROOT/.local/bin/claude"
MAX_BUDGET="2"

# Source environment
[ -f "$AGENTFORGE_ROOT/.env" ] && set -a && source "$AGENTFORGE_ROOT/.env" && set +a

echo "[$TODAY $NOW] === Memory consolidation starting ===" >> "$LOG"

# Discover all agents from agents/ directory
discover_agents() {
    local agents_dir="$AGENTFORGE_ROOT/agents"
    if [ ! -d "$agents_dir" ]; then
        echo ""
        return
    fi
    local agents=""
    for dir in "$agents_dir"/*/; do
        [ -d "$dir" ] || continue
        local name
        name=$(basename "$dir")
        local vault_dir="$AGENTFORGE_ROOT/vault/Agents/$name"
        local soul_file="$vault_dir/soul.md"
        local daily_dir="$vault_dir/daily"
        [ -f "$soul_file" ] || { [ -f "$dir/soul.md" ] && soul_file="$dir/soul.md"; }
        [ -d "$daily_dir" ] || { [ -d "$dir/daily" ] && daily_dir="$dir/daily"; }
        # Only include agents that have a soul.md and daily/ directory
        if [ -f "$soul_file" ] && [ -d "$daily_dir" ]; then
            agents+="$name "
        fi
    done
    echo "$agents"
}

# Collect daily logs from the past 7 days for a given daily dir
collect_daily_logs() {
    local daily_dir="$1"
    local content=""
    for i in $(seq 1 7); do
        local date
        date=$(date -d "$i days ago" +%Y-%m-%d)
        local f="$daily_dir/$date.md"
        if [ -f "$f" ] && [ -s "$f" ]; then
            content+="=== $date ===
$(cat "$f")

"
        fi
    done
    echo "$content"
}

# Run consolidation for one agent
consolidate() {
    local name="$1"
    local agent_dir="$AGENTFORGE_ROOT/agents/$name"
    local vault_dir="$AGENTFORGE_ROOT/vault/Agents/$name"
    local daily_dir="$vault_dir/daily"
    local memory_file="$vault_dir/memory.md"
    local soul_file="$vault_dir/soul.md"
    [ -d "$daily_dir" ] || { [ -d "$agent_dir/daily" ] && daily_dir="$agent_dir/daily"; }
    [ -f "$memory_file" ] || { [ -f "$agent_dir/memory.md" ] && memory_file="$agent_dir/memory.md"; }
    [ -f "$soul_file" ] || { [ -f "$agent_dir/soul.md" ] && soul_file="$agent_dir/soul.md"; }

    local daily_content
    daily_content=$(collect_daily_logs "$daily_dir")

    if [ -z "$daily_content" ]; then
        echo "[$TODAY $NOW] $name — no daily logs this week, skipping" >> "$LOG"
        return
    fi

    local current_memory
    current_memory=$(cat "$memory_file" 2>/dev/null || echo "(vide)")

    local soul
    soul=$(cat "$soul_file" 2>/dev/null || echo "")

    local prompt
    prompt="Tu es $name. Voici tes notes des 7 derniers jours :

$daily_content

Et voici ta mémoire actuelle :

$current_memory

Tâche : consolide ces informations. Détermine ce qui mérite d'être mémorisé de façon permanente dans ta memory.md.

Règles :
- Garde seulement ce qui influencera tes futures actions (préférences de Martin, faits récurrents, patterns, décisions structurantes)
- Supprime les détails ponctuels et anecdotes qui ne se réappliquent pas
- Fusionne les faits similaires — pas de doublons
- Une mémoire concise est plus utile qu'une mémoire exhaustive
- Préserve tout ce qui était déjà dans la mémoire actuelle et qui reste pertinent

Réponds UNIQUEMENT avec le contenu complet du nouveau fichier memory.md (markdown), en commençant par le header existant. Aucun commentaire, aucune explication — juste le fichier."

    local result
    result=$("$CLAUDE" -p \
        --model "sonnet" \
        --dangerously-skip-permissions \
        --output-format text \
        --max-budget-usd "$MAX_BUDGET" \
        "$prompt" 2>&1) || {
        echo "[$TODAY $NOW] $name — claude error: ${result:0:200}" >> "$LOG"
        return
    }

    if [ -n "$result" ]; then
        echo "$result" > "$memory_file"
        local line_count
        line_count=$(echo "$result" | wc -l)
        echo "[$TODAY $NOW] $name — consolidated ($line_count lines in memory.md)" >> "$LOG"
    else
        echo "[$TODAY $NOW] $name — empty result, skipping" >> "$LOG"
    fi
}

# Discover and consolidate all agents
AGENTS=$(discover_agents)
if [ -z "$AGENTS" ]; then
    echo "[$TODAY $NOW] No agents found in $AGENTFORGE_ROOT/agents/" >> "$LOG"
else
    for agent in $AGENTS; do
        consolidate "$agent"
    done
fi

# Push changes to GitHub (ops repo)
if [ -d "$AGENTFORGE_ROOT/.git" ] && [ -n "${GITHUB_TOKEN:-}" ]; then
    cd "$AGENTFORGE_ROOT"
    git add agents/ vault/ 2>/dev/null || true
    git diff --cached --quiet || git commit -m "Memory consolidation $TODAY" --quiet
    git push origin main --quiet >> "$LOG" 2>&1 || echo "[$TODAY $NOW] git push failed" >> "$LOG"
fi

echo "[$TODAY $NOW] === Memory consolidation done ===" >> "$LOG"
