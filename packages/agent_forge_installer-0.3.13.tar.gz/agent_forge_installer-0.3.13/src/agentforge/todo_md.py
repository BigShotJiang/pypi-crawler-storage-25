"""Markdown todo parsing and scheduling helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta
from pathlib import Path

import re


_CHECKBOX_RE = re.compile(r"^\s*-\s\[(?P<mark>[ xX])\]\s+(?P<body>.+?)\s*$")
_HEADING_RE = re.compile(r"^\s*##\s+(?P<title>.+?)\s*$")
_FIELD_RE = re.compile(r"^\s{2,}(?P<key>[a-z_]+)::\s*(?P<value>.+?)\s*$", re.IGNORECASE)
_DUE_INLINE_RE = re.compile(r"📅\s*(\d{4}-\d{2}-\d{2}(?:[ T]\d{2}:\d{2})?)")
_RECUR_INLINE_RE = re.compile(r"🔁\s*every\s+([A-Za-z]+(?:\s+[A-Za-z]+)?)", re.IGNORECASE)
_TAG_RE = re.compile(r"(?<!\w)#(?:project|projet|goal|objectif|autre)/[A-Za-z0-9._-]+")
_TIME_RE = re.compile(r"^\d{2}:\d{2}$")

_WEEKDAYS = {
    "mon": 0,
    "monday": 0,
    "tue": 1,
    "tues": 1,
    "tuesday": 1,
    "wed": 2,
    "wednesday": 2,
    "thu": 3,
    "thur": 3,
    "thurs": 3,
    "thursday": 3,
    "fri": 4,
    "friday": 4,
    "sat": 5,
    "saturday": 5,
    "sun": 6,
    "sunday": 6,
}

_PRIORITY_RANK = {"high": 0, "medium": 1, "low": 2}


@dataclass(slots=True)
class TodoItem:
    text: str
    completed: bool
    section: str
    source_path: Path | None = None
    source_line: int = 0
    due_at: datetime | None = None
    recur: str | None = None
    priority: str = "medium"
    tags: list[str] = field(default_factory=list)
    last_done: datetime | None = None
    metadata: dict[str, str] = field(default_factory=dict)

    @property
    def is_open(self) -> bool:
        return not self.completed

    def project_tags(self) -> list[str]:
        return [tag for tag in self.tags if tag.startswith("#project/") or tag.startswith("#projet/")]

    def goal_tags(self) -> list[str]:
        return [tag for tag in self.tags if tag.startswith("#goal/") or tag.startswith("#objectif/")]


def _parse_datetime(value: str | None) -> datetime | None:
    if not value:
        return None
    value = value.strip()
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(value, fmt)
            if fmt == "%Y-%m-%d":
                return datetime.combine(dt.date(), time.min)
            return dt
        except ValueError:
            continue
    if _TIME_RE.match(value):
        hours, minutes = value.split(":")
        return datetime.combine(date.today(), time(int(hours), int(minutes)))
    return None


def _normalize_recur(value: str | None) -> str | None:
    if not value:
        return None
    value = value.strip().lower()
    value = value.removeprefix("every ").strip()
    aliases = {
        "day": "daily",
        "daily": "daily",
        "week": "weekly",
        "weekly": "weekly",
        "month": "monthly",
        "monthly": "monthly",
    }
    if value in aliases:
        return aliases[value]
    if value in _WEEKDAYS:
        return value
    return value


def _strip_inline_markers(body: str) -> tuple[str, datetime | None, str | None, list[str]]:
    due_match = _DUE_INLINE_RE.search(body)
    recur_match = _RECUR_INLINE_RE.search(body)
    due_at = _parse_datetime(due_match.group(1)) if due_match else None
    recur = _normalize_recur(recur_match.group(1)) if recur_match else None
    tags = _TAG_RE.findall(body)

    cleaned = body
    if due_match:
        cleaned = cleaned.replace(due_match.group(0), "").strip()
    if recur_match:
        cleaned = cleaned.replace(recur_match.group(0), "").strip()
    cleaned = re.sub(r"\s{2,}", " ", cleaned).strip()
    return cleaned, due_at, recur, tags


def parse_tasks_text(text: str, *, source_path: Path | None = None) -> list[TodoItem]:
    """Parse a markdown tasks file into TodoItem objects."""
    items: list[TodoItem] = []
    current_section = "Inbox"
    current_item: TodoItem | None = None

    for line_no, line in enumerate(text.splitlines(), start=1):
        heading_match = _HEADING_RE.match(line)
        if heading_match:
            current_section = heading_match.group("title").strip()
            current_item = None
            continue

        checkbox_match = _CHECKBOX_RE.match(line)
        if checkbox_match:
            body = checkbox_match.group("body").strip()
            text_value, due_at, recur, tags = _strip_inline_markers(body)
            current_item = TodoItem(
                text=text_value,
                completed=checkbox_match.group("mark").lower() == "x",
                section=current_section,
                source_path=source_path,
                source_line=line_no,
                due_at=due_at,
                recur=recur,
                tags=tags,
            )
            items.append(current_item)
            continue

        field_match = _FIELD_RE.match(line)
        if field_match and current_item is not None:
            key = field_match.group("key").strip().lower()
            value = field_match.group("value").strip()
            current_item.metadata[key] = value
            if key == "due":
                current_item.due_at = _parse_datetime(value) or current_item.due_at
            elif key == "recur":
                current_item.recur = _normalize_recur(value) or current_item.recur
            elif key == "priority":
                current_item.priority = value.lower()
            elif key == "tags":
                current_item.tags = sorted(set(current_item.tags + _TAG_RE.findall(value)))
            elif key == "last_done":
                current_item.last_done = _parse_datetime(value)

    return items


def is_task_due(item: TodoItem, now: datetime) -> bool:
    if not item.is_open:
        return False
    if item.due_at and item.due_at <= now:
        return True

    recur = item.recur
    if not recur:
        return False

    today = now.date()
    if recur == "daily":
        if item.last_done:
            return item.last_done.date() < today
        return True
    if recur == "weekly":
        if item.last_done:
            return item.last_done.date() <= today - timedelta(days=7)
        if item.due_at:
            return item.due_at.date() <= today
        return True
    if recur == "monthly":
        if item.last_done:
            return (item.last_done.year, item.last_done.month) != (today.year, today.month)
        if item.due_at:
            return (item.due_at.year, item.due_at.month) <= (today.year, today.month)
        return True
    if recur in _WEEKDAYS:
        return now.weekday() == _WEEKDAYS[recur] and (
            item.last_done is None or item.last_done.date() < today
        )
    return False


def priority_rank(item: TodoItem) -> int:
    return _PRIORITY_RANK.get(item.priority, 1)


def select_actionable_tasks(
    items: list[TodoItem],
    *,
    now: datetime | None = None,
    limit: int = 8,
) -> list[TodoItem]:
    now = now or datetime.now()
    open_items = [item for item in items if item.is_open]

    def sort_key(item: TodoItem) -> tuple[int, datetime, int, int]:
        due_bucket = 0 if is_task_due(item, now) else 1
        next_bucket = 0 if item.section.strip().lower() == "next" else 1
        due_at = item.due_at or datetime.max
        return (due_bucket, next_bucket, due_at, priority_rank(item))

    actionable: list[TodoItem] = []
    for item in sorted(open_items, key=sort_key):
        section = item.section.strip().lower()
        if is_task_due(item, now) or section == "next":
            actionable.append(item)
        elif not actionable and section == "inbox":
            actionable.append(item)
        if len(actionable) >= limit:
            break
    return actionable


def format_items_markdown(items: list[TodoItem], *, title: str = "Actionable Tasks") -> str:
    if not items:
        return ""
    lines = [f"## {title}", ""]
    for item in items:
        lines.append(f"- [ ] {item.text}")
        lines.append(f"  section:: {item.section}")
        if item.due_at:
            lines.append(f"  due:: {item.due_at.strftime('%Y-%m-%d %H:%M') if item.due_at.time() != time.min else item.due_at.strftime('%Y-%m-%d')}")
        if item.recur:
            lines.append(f"  recur:: {item.recur}")
        if item.priority and item.priority != "medium":
            lines.append(f"  priority:: {item.priority}")
        if item.tags:
            lines.append(f"  tags:: {' '.join(item.tags)}")
        if item.source_line:
            lines.append(f"  source_line:: {item.source_line}")
        lines.append("")
    return "\n".join(lines).rstrip()


def collect_project_tags(items: list[TodoItem]) -> list[str]:
    tags = {tag for item in items for tag in item.project_tags()}
    return sorted(tags)


def collect_goal_tags(items: list[TodoItem]) -> list[str]:
    tags = {tag for item in items for tag in item.goal_tags()}
    return sorted(tags)
