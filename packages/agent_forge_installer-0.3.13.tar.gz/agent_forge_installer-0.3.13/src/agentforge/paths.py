"""Canonical path helpers for AgentForge instance and runtime layout."""

from __future__ import annotations

import os
import shutil
from pathlib import Path


def resolve_root(root: str | Path | None = None) -> Path:
    if root is not None:
        return Path(root)
    return Path(os.environ.get("AGENTFORGE_ROOT", os.path.expanduser("~")))


def resolve_runtime_root(root: str | Path | None = None) -> Path:
    if "AGENTFORGE_RUNTIME_ROOT" in os.environ:
        return Path(os.environ["AGENTFORGE_RUNTIME_ROOT"])
    instance_root = resolve_root(root)
    return instance_root / "runtime"


def resolve_vault_root(root: str | Path | None = None) -> Path:
    if "AGENTFORGE_VAULT_ROOT" in os.environ:
        return Path(os.environ["AGENTFORGE_VAULT_ROOT"])
    return resolve_root(root) / "vault"


def resolve_git_repos_root(root: str | Path | None = None) -> Path:
    if "AGENTFORGE_GIT_REPOS_ROOT" in os.environ:
        return Path(os.environ["AGENTFORGE_GIT_REPOS_ROOT"])
    return resolve_root(root) / "git-repos"


def resolve_runtime_bin_dir(root: str | Path | None = None) -> Path:
    return resolve_runtime_root(root) / ".venv" / "bin"


def resolve_runtime_scripts_dir(root: str | Path | None = None) -> Path:
    return resolve_runtime_root(root) / "scripts"


def resolve_runtime_local_bin(root: str | Path | None = None) -> Path:
    return resolve_runtime_root(root) / ".local" / "bin"


def resolve_claude_bin(root: str | Path | None = None) -> str:
    runtime_local_bin = resolve_runtime_local_bin(root)
    candidates = [
        runtime_local_bin / "claude",
        resolve_runtime_root(root) / ".claude" / "local" / "claude",
    ]
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    system_claude = shutil.which("claude")
    if system_claude:
        import warnings
        warnings.warn(
            f"claude binary not found under runtime root {resolve_runtime_root(root)}; "
            f"falling back to system claude at {system_claude}",
            stacklevel=2,
        )
        return system_claude
    raise RuntimeError(
        f"claude binary not found. Expected at {runtime_local_bin / 'claude'} "
        f"(AGENTFORGE_RUNTIME_ROOT={os.environ.get('AGENTFORGE_RUNTIME_ROOT', 'not set')})"
    )
