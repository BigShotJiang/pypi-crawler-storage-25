"""HTTP client abstraction — uses requests if available, falls back to urllib."""

from __future__ import annotations

import json

# Try to use requests, fall back to urllib if not available
try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    import urllib.request
    import urllib.parse
    import urllib.error
    HAS_REQUESTS = False


def http_get(url: str, params: dict | None = None, timeout: int = 35) -> dict:
    """HTTP GET that works with or without requests library."""
    if HAS_REQUESTS:
        resp = requests.get(url, params=params, timeout=timeout)
        return resp.json()
    else:
        if params:
            query = urllib.parse.urlencode(params)
            url = f"{url}?{query}"
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode())


def http_post_json(url: str, data: dict, timeout: int = 10) -> dict:
    """HTTP POST JSON that works with or without requests library."""
    if HAS_REQUESTS:
        resp = requests.post(url, json=data, timeout=timeout)
        if not resp.ok:
            raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:500]}")
        return resp.json()
    else:
        body = json.dumps(data).encode()
        req = urllib.request.Request(
            url, data=body,
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            detail = ""
            try:
                detail = e.read().decode("utf-8", errors="replace")[:500]
            except Exception:
                pass
            raise RuntimeError(f"HTTP {e.code} {e.reason}: {detail}") from e


def http_download(url: str, dest_path: str, timeout: int = 30) -> None:
    """Download a file from URL to dest_path."""
    if HAS_REQUESTS:
        r = requests.get(url, timeout=timeout)
        with open(dest_path, "wb") as f:
            f.write(r.content)
    else:
        import urllib.request as ureq
        ureq.urlretrieve(url, dest_path)
