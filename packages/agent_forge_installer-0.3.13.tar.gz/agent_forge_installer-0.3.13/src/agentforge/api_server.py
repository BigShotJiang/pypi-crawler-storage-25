"""FastAPI server for app-to-bot communication."""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import uvicorn
from fastapi import Depends, FastAPI, Header, HTTPException, Query, WebSocket, WebSocketDisconnect, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field

from agentforge.claude_runner import (
    ClaudeCodeLimitError,
    InvokeResult,
    RateLimitError,
    format_claude_code_limit_user_message,
    format_rate_limit_user_message,
    invoke_claude,
)
from agentforge.conversation_store import ConversationMessage, ConversationStore
from agentforge.http_client import http_post_json
from agentforge.message_router import build_topic_context, get_agent_thread_config, parse_mention
from agentforge.monitoring import collect_agent_heartbeats, collect_monitoring_status, list_agent_runtime_details
from agentforge.paths import resolve_root, resolve_vault_root
from agentforge.config_models import ValidationError, load_legacy_global_config
from agentforge.team_docs import write_system_state_note

AUTH_SCHEME = HTTPBearer(auto_error=False)


class MessageRequest(BaseModel):
    channel: str = Field(..., min_length=1)
    message: str = Field(..., min_length=1)
    agent: str | None = None
    parent_message_id: int | None = None


class TopicCreateRequest(BaseModel):
    name: str = Field(..., min_length=1)
    label: str | None = None
    default_agent: str | None = None


class VaultNoteUpdate(BaseModel):
    content: str


class ConnectionManager:
    def __init__(self) -> None:
        self._connections: list[tuple[WebSocket, str | None]] = []

    async def connect(self, websocket: WebSocket, channel: str | None) -> None:
        await websocket.accept()
        self._connections.append((websocket, channel))

    def disconnect(self, websocket: WebSocket) -> None:
        self._connections = [(ws, channel) for ws, channel in self._connections if ws != websocket]

    async def broadcast(self, event: dict[str, Any], *, channel: str | None = None) -> None:
        stale: list[WebSocket] = []
        for websocket, subscribed_channel in list(self._connections):
            if subscribed_channel and channel and subscribed_channel != channel:
                continue
            try:
                await websocket.send_json(event)
            except Exception:
                stale.append(websocket)
        for websocket in stale:
            self.disconnect(websocket)


def _load_runtime_config(config_path: str | None = None) -> dict[str, Any]:
    root = resolve_root()
    env_path = root / ".env"
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                os.environ.setdefault(key.strip(), value.strip())
    resolved_path = Path(config_path) if config_path else root / "bot" / "config.json"
    try:
        return load_legacy_global_config(resolved_path).model_dump()
    except ValidationError as exc:
        raise RuntimeError(f"Invalid config at {resolved_path}: {exc}") from exc


def _resolve_api_key(config: dict[str, Any]) -> str:
    api_cfg = config.get("api", {})
    env_var = api_cfg.get("token_env_var", "AGENTFORGE_API_KEY")
    token = os.environ.get(env_var, "")
    if not token:
        raise RuntimeError(f"API key not found in env var {env_var}")
    return token


def _resolve_config_path(config_path: str | None = None) -> Path:
    root = resolve_root()
    return Path(config_path) if config_path else root / "bot" / "config.json"


def _save_runtime_config(config: dict[str, Any], config_path: str | None = None) -> None:
    path = _resolve_config_path(config_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    write_system_state_note(root=path.parent.parent, config_path=str(path), printer=lambda *_args, **_kwargs: None)


def _build_store(config: dict[str, Any]) -> ConversationStore:
    db_path = config["memory"]["db_path"]
    return ConversationStore(db_path)


def _serialize_message(message: ConversationMessage) -> dict[str, Any]:
    payload = message.to_dict()
    payload["channel"] = message.metadata.get("channel")
    payload["agent"] = message.metadata.get("agent")
    payload["parent_message_id"] = message.parent_message_id
    payload["thread_reply_count"] = message.thread_reply_count
    return payload


def _list_agents(config: dict[str, Any]) -> list[dict[str, str]]:
    seen: set[str] = set()
    agents: list[dict[str, str]] = []
    for thread_id, thread_cfg in config.get("threads", {}).items():
        if thread_id == "default":
            continue
        name = thread_cfg.get("name")
        if not name or name in seen:
            continue
        seen.add(name)
        agents.append({"id": name, "name": name, "thread_id": str(thread_id)})
    return agents


def _list_channels(config: dict[str, Any]) -> list[dict[str, Any]]:
    channels: list[dict[str, Any]] = []
    seen: set[str] = set()
    for thread_id, thread_cfg in config.get("threads", {}).items():
        if thread_id == "default":
            continue
        channel_id = str(thread_id)
        channels.append(
            {
                "id": channel_id,
                "name": thread_cfg.get("name", f"thread-{channel_id}"),
                "label": thread_cfg.get("name", f"thread-{channel_id}"),
                "type": "thread",
                "agent": thread_cfg.get("name", "clawdia"),
            }
        )
        seen.add(channel_id)
    for topic_id, topic_cfg in config.get("project_topics", {}).items():
        channel_id = str(topic_id)
        if channel_id in seen:
            continue
        channels.append(
            {
                "id": channel_id,
                "name": topic_cfg.get("name", f"topic-{channel_id}"),
                "label": topic_cfg.get("label", topic_cfg.get("name", f"topic-{channel_id}")),
                "type": "project_topic",
                "agent": topic_cfg.get("default_agent", "clawdia"),
            }
        )
    return channels


def _available_agent_names(config: dict[str, Any]) -> list[str]:
    return [agent["id"] for agent in _list_agents(config)]


def _next_project_topic_id(config: dict[str, Any]) -> str:
    numeric_ids: list[int] = []
    for collection_name in ("threads", "project_topics"):
        for key in config.get(collection_name, {}):
            if key == "default":
                continue
            try:
                numeric_ids.append(int(str(key)))
            except ValueError:
                continue
    return str(max(numeric_ids, default=0) + 1)


def _create_project_topic(
    request: TopicCreateRequest,
    *,
    config: dict[str, Any],
    config_path: str | None = None,
) -> dict[str, Any]:
    name = request.name.strip()
    if not name:
        raise HTTPException(status_code=400, detail="Topic name is required")

    agents = _available_agent_names(config)
    if not agents:
        raise HTTPException(status_code=400, detail="No agents available to attach to topic")

    topic_id = _next_project_topic_id(config)
    default_agent = request.default_agent or agents[0]
    if default_agent not in agents:
        raise HTTPException(status_code=400, detail="Unknown default agent")

    topic_cfg = {
        "name": name,
        "label": (request.label or name).strip() or name,
        "agents": agents,
        "default_agent": default_agent,
    }
    config.setdefault("project_topics", {})[topic_id] = topic_cfg
    _save_runtime_config(config, config_path)

    return {
        "id": topic_id,
        "name": topic_cfg["name"],
        "label": topic_cfg["label"],
        "type": "project_topic",
        "agent": topic_cfg["default_agent"],
    }


def _resolve_thread_config(channel: str, agent: str | None, config: dict[str, Any]) -> tuple[dict[str, Any], str]:
    project_cfg = config.get("project_topics", {}).get(str(channel))
    if project_cfg:
        message_text = "placeholder"
        if agent:
            message_text = f"@{agent} {message_text}"
        resolved_agent, _ = parse_mention(message_text, project_cfg) if agent else (
            project_cfg.get("default_agent", "clawdia"),
            message_text,
        )
        thread_cfg = get_agent_thread_config(resolved_agent, config)
        thread_cfg["topic_context"] = build_topic_context(project_cfg, resolved_agent)
        return thread_cfg, resolved_agent
    thread_cfg = dict(config.get("threads", {}).get(str(channel), {}))
    if not thread_cfg:
        raise HTTPException(status_code=404, detail=f"Unknown channel '{channel}'")
    resolved_agent = agent or thread_cfg.get("name", "clawdia")
    thread_cfg.setdefault("name", resolved_agent)
    thread_cfg.setdefault("backend", config["claude"].get("backend", ""))
    thread_cfg.setdefault("model", config["claude"]["model"])
    return thread_cfg, resolved_agent


def _vault_root(root: str) -> Path:
    return resolve_vault_root(root)


def _agent_root(root: str) -> Path:
    return Path(root) / "agents"


def _validate_agent_name(agent_name: str) -> str:
    cleaned = agent_name.strip()
    if not cleaned or any(part in cleaned for part in ("/", "\\", "..")):
        raise HTTPException(status_code=400, detail="Invalid agent name")
    return cleaned


def _resolve_agent_dir(agent_root: Path, agent_name: str) -> Path:
    validated = _validate_agent_name(agent_name)
    resolved = (agent_root / validated).resolve()
    root_resolved = agent_root.resolve()
    if str(resolved) != str(root_resolved) and not str(resolved).startswith(str(root_resolved) + "/"):
        raise HTTPException(status_code=400, detail="Path traversal not allowed")
    return resolved


def _resolve_note_path(vault_root: Path, note_path: str) -> Path:
    try:
        resolved = (vault_root / note_path).resolve()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid path")
    vault_str = str(vault_root.resolve())
    if str(resolved) != vault_str and not str(resolved).startswith(vault_str + "/"):
        raise HTTPException(status_code=400, detail="Path traversal not allowed")
    return resolved


def _resolve_agent_note_path(agent_root: Path, agent_name: str, note_kind: str, daily_name: str | None = None) -> Path:
    agent_dir = _resolve_agent_dir(agent_root, agent_name)
    if note_kind not in {"soul", "memory", "daily"}:
        raise HTTPException(status_code=400, detail="Invalid note kind")

    if note_kind == "daily":
        if daily_name is None:
            raise HTTPException(status_code=400, detail="Missing daily note name")
        if any(part in daily_name for part in ("/", "\\", "..")) or not daily_name.endswith(".md"):
            raise HTTPException(status_code=400, detail="Invalid daily note name")
        return agent_dir / "daily" / daily_name

    file_name = "soul.md" if note_kind == "soul" else "memory.md"
    return agent_dir / file_name


def _build_tree(base: Path, current: Path | None = None) -> list[dict[str, Any]]:
    dir_path = base if current is None else current
    nodes: list[dict[str, Any]] = []
    try:
        entries = sorted(dir_path.iterdir(), key=lambda p: (p.is_file(), p.name.lower()))
    except PermissionError:
        return nodes
    for entry in entries:
        if entry.name.startswith("."):
            continue
        rel = str(entry.relative_to(base))
        if entry.is_dir():
            nodes.append({"name": entry.name, "path": rel, "type": "folder", "children": _build_tree(base, entry)})
        elif entry.suffix == ".md":
            nodes.append({"name": entry.name, "path": rel, "type": "file"})
    return nodes


def _utc_iso(timestamp: float) -> str:
    return datetime.fromtimestamp(timestamp, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _mirror_app_message_to_telegram(
    *,
    config: dict[str, Any],
    channel: str,
    message: str,
    timeout: int = 8,
) -> None:
    telegram_cfg = config.get("telegram", {})
    chat_id = telegram_cfg.get("group_chat_id") or telegram_cfg.get("private_chat_id")
    if not chat_id:
        return
    token_env = telegram_cfg.get("token_env_var")
    token = os.environ.get(token_env, "") if token_env else telegram_cfg.get("token", "")
    if not token:
        return
    payload: dict[str, Any] = {"chat_id": str(chat_id), "text": f"📱 App: {message}"}
    if channel.isdigit():
        payload["message_thread_id"] = int(channel)
    api_base = f"https://api.telegram.org/bot{token}"
    try:
        http_post_json(f"{api_base}/sendMessage", payload, timeout=timeout)
    except Exception as exc:  # pragma: no cover - best effort network call
        logging.warning("Could not mirror app message to Telegram: %s", exc)


def create_app(
    *,
    config_path: str | None = None,
    store: ConversationStore | None = None,
    invoke_claude_fn=invoke_claude,
    mirror_message_fn=_mirror_app_message_to_telegram,
) -> FastAPI:
    config = _load_runtime_config(config_path)
    api_key = _resolve_api_key(config)
    store = store or _build_store(config)
    root = os.environ.get("AGENTFORGE_ROOT", "/home/clawdia")
    manager = ConnectionManager()

    app = FastAPI(title="AgentForge HTTP API")
    app.state.config = config
    app.state.store = store

    def require_auth(
        credentials: HTTPAuthorizationCredentials | None = Depends(AUTH_SCHEME),
    ) -> None:
        if credentials is None or credentials.scheme.lower() != "bearer" or credentials.credentials != api_key:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized")

    @app.get("/api/health", dependencies=[Depends(require_auth)])
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/api/channels", dependencies=[Depends(require_auth)])
    def list_channels() -> dict[str, Any]:
        return {"channels": _list_channels(config)}

    @app.post("/api/channels/topics", dependencies=[Depends(require_auth)])
    def create_topic(request: TopicCreateRequest) -> dict[str, Any]:
        channel = _create_project_topic(request, config=config, config_path=config_path)
        return {"channel": channel}

    @app.get("/api/monitoring/status", dependencies=[Depends(require_auth)])
    def monitoring_status() -> dict[str, Any]:
        return collect_monitoring_status(root=root, config=config)

    @app.get("/api/monitoring/agents", dependencies=[Depends(require_auth)])
    def monitoring_agents() -> dict[str, Any]:
        return collect_agent_heartbeats(root=root, config=config)

    @app.get("/api/agents", dependencies=[Depends(require_auth)])
    def list_runtime_agents() -> dict[str, Any]:
        return {"agents": list_agent_runtime_details(root=root, config=config)}

    @app.get("/api/agents/{agent_name}", dependencies=[Depends(require_auth)])
    def get_runtime_agent(agent_name: str) -> dict[str, Any]:
        details = list_agent_runtime_details(root=root, config=config)
        normalized = _validate_agent_name(agent_name)
        agent = next((item for item in details if item["name"] == normalized), None)
        if agent is None:
            raise HTTPException(status_code=404, detail="Agent not found")
        return {"agent": agent}

    @app.get("/api/messages", dependencies=[Depends(require_auth)])
    def get_messages(
        channel: str = Query(..., min_length=1),
        limit: int = Query(50, ge=1, le=200),
        before: str | None = Query(default=None),
    ) -> dict[str, Any]:
        messages = store.list_messages(channel_id=channel, limit=limit, before=before)
        return {"messages": [_serialize_message(message) for message in messages]}

    @app.get("/api/messages/{message_id}/thread", dependencies=[Depends(require_auth)])
    def get_thread_messages(
        message_id: int,
        channel: str = Query(..., min_length=1),
    ) -> dict[str, Any]:
        parent = store.get_message_by_id(message_id)
        if parent is None:
            raise HTTPException(status_code=404, detail="Message not found")
        parent_channel = parent.metadata.get("channel")
        if parent_channel != channel:
            raise HTTPException(status_code=403, detail="Message does not belong to this channel")
        messages = store.list_thread_messages(message_id)
        return {"messages": [_serialize_message(message) for message in messages]}

    @app.post("/api/messages", dependencies=[Depends(require_auth)])
    async def post_message(request: MessageRequest) -> dict[str, Any]:
        thread_cfg, resolved_agent = _resolve_thread_config(request.channel, request.agent, config)
        if request.parent_message_id is not None:
            parent = store.get_message_by_id(request.parent_message_id)
            if parent is None:
                raise HTTPException(status_code=404, detail="Parent message not found")
            if parent.parent_message_id is not None:
                raise HTTPException(status_code=400, detail="Cannot reply to a reply")
            parent_channel = parent.metadata.get("channel")
            if parent_channel != request.channel:
                raise HTTPException(status_code=403, detail="Parent message does not belong to this channel")
        session_id = f"api-channel-{request.channel}"
        user_message = store.save_message(
            session_id,
            "user",
            request.message,
            source="api",
            metadata={"channel": request.channel, "agent": resolved_agent},
            parent_message_id=request.parent_message_id,
        )
        await manager.broadcast(
            {"type": "message_created", "message": _serialize_message(user_message)},
            channel=request.channel,
        )
        await manager.broadcast(
            {"type": "typing", "channel": request.channel, "agent": resolved_agent, "active": True},
            channel=request.channel,
        )
        if request.parent_message_id is None:
            mirror_message_fn(config=config, channel=request.channel, message=request.message)
        thread_messages = None
        exclude_message_ids = {user_message.id}
        if request.parent_message_id is not None:
            thread_messages, thread_ids = store.get_thread_context(
                request.parent_message_id,
                exclude_message_ids=exclude_message_ids,
            )
            exclude_message_ids.update(thread_ids)
        recent_messages = store.get_dynamic_messages(
            session_id,
            min_msgs=3,
            max_msgs=100,
            hours=4,
            exclude_message_ids=exclude_message_ids,
        )
        try:
            response = invoke_claude_fn(
                session_id=session_id,
                user_text=request.message,
                thread_cfg=thread_cfg,
                config=config,
                recent_messages=recent_messages,
                thread_messages=thread_messages,
                root=root,
            )
            response_text = response.text if isinstance(response, InvokeResult) else str(response)
        except ClaudeCodeLimitError as exc:
            response_text = format_claude_code_limit_user_message(exc.restore_at)
        except RateLimitError as exc:
            response_text = format_rate_limit_user_message(exc.retry_after_seconds)
        assistant_message = store.save_message(
            session_id,
            "assistant",
            response_text,
            source="api",
            metadata={"channel": request.channel, "agent": resolved_agent},
            parent_message_id=request.parent_message_id,
        )
        await manager.broadcast(
            {"type": "typing", "channel": request.channel, "agent": resolved_agent, "active": False},
            channel=request.channel,
        )
        await manager.broadcast(
            {"type": "message_created", "message": _serialize_message(assistant_message)},
            channel=request.channel,
        )
        if request.parent_message_id is not None:
            await manager.broadcast(
                {
                    "type": "thread_reply",
                    "channel": request.channel,
                    "parent_message_id": request.parent_message_id,
                },
                channel=request.channel,
            )
        return {
            "channel": request.channel,
            "agent": resolved_agent,
            "session_id": session_id,
            "message": _serialize_message(user_message),
            "response": _serialize_message(assistant_message),
        }

    # -- Vault endpoints --------------------------------------------------

    vault_dir = _vault_root(root)
    agent_dir = _agent_root(root)

    @app.get("/vault/tree", dependencies=[Depends(require_auth)])
    def vault_tree() -> dict[str, Any]:
        if not vault_dir.exists():
            return {"tree": []}
        return {"tree": _build_tree(vault_dir)}

    @app.get("/vault/notes", dependencies=[Depends(require_auth)])
    def vault_list_notes() -> dict[str, Any]:
        if not vault_dir.exists():
            return {"notes": []}
        notes = []
        for md_file in sorted(vault_dir.rglob("*.md")):
            if any(part.startswith(".") for part in md_file.relative_to(vault_dir).parts):
                continue
            stat = md_file.stat()
            notes.append({
                "path": str(md_file.relative_to(vault_dir)),
                "name": md_file.name,
                "modified_at": _utc_iso(stat.st_mtime),
                "size_bytes": stat.st_size,
            })
        return {"notes": notes}

    @app.get("/vault/notes/{note_path:path}", dependencies=[Depends(require_auth)])
    def vault_get_note(note_path: str) -> dict[str, Any]:
        path = _resolve_note_path(vault_dir, note_path)
        if not path.exists():
            raise HTTPException(status_code=404, detail="Note not found")
        return {"path": note_path, "content": path.read_text(encoding="utf-8")}

    @app.post("/vault/notes/{note_path:path}", dependencies=[Depends(require_auth)])
    def vault_save_note(note_path: str, body: VaultNoteUpdate) -> dict[str, Any]:
        path = _resolve_note_path(vault_dir, note_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(body.content, encoding="utf-8")
        stat = path.stat()
        return {"path": note_path, "modified_at": _utc_iso(stat.st_mtime)}

    @app.get("/api/agents/{agent_name}/documents/{note_kind}", dependencies=[Depends(require_auth)])
    def get_agent_document(agent_name: str, note_kind: str) -> dict[str, Any]:
        path = _resolve_agent_note_path(agent_dir, agent_name, note_kind)
        if not path.exists():
            raise HTTPException(status_code=404, detail="Document not found")
        stat = path.stat()
        relative = str(path.relative_to(Path(root)))
        return {
            "path": relative,
            "content": path.read_text(encoding="utf-8"),
            "modified_at": _utc_iso(stat.st_mtime),
            "size_bytes": stat.st_size,
        }

    @app.post("/api/agents/{agent_name}/documents/{note_kind}", dependencies=[Depends(require_auth)])
    def save_agent_document(agent_name: str, note_kind: str, body: VaultNoteUpdate) -> dict[str, Any]:
        path = _resolve_agent_note_path(agent_dir, agent_name, note_kind)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(body.content, encoding="utf-8")
        stat = path.stat()
        relative = str(path.relative_to(Path(root)))
        return {"path": relative, "modified_at": _utc_iso(stat.st_mtime)}

    @app.get("/api/agents/{agent_name}/daily", dependencies=[Depends(require_auth)])
    def list_agent_daily_notes(agent_name: str) -> dict[str, Any]:
        normalized = _validate_agent_name(agent_name)
        details = list_agent_runtime_details(root=root, config=config)
        agent = next((item for item in details if item["name"] == normalized), None)
        if agent is None:
            raise HTTPException(status_code=404, detail="Agent not found")
        return {"notes": agent["daily_notes"]}

    @app.get("/api/agents/{agent_name}/daily/{daily_name}", dependencies=[Depends(require_auth)])
    def get_agent_daily_note(agent_name: str, daily_name: str) -> dict[str, Any]:
        path = _resolve_agent_note_path(agent_dir, agent_name, "daily", daily_name=daily_name)
        if not path.exists():
            raise HTTPException(status_code=404, detail="Document not found")
        stat = path.stat()
        relative = str(path.relative_to(Path(root)))
        return {
            "path": relative,
            "content": path.read_text(encoding="utf-8"),
            "modified_at": _utc_iso(stat.st_mtime),
            "size_bytes": stat.st_size,
        }

    @app.post("/api/agents/{agent_name}/daily/{daily_name}", dependencies=[Depends(require_auth)])
    def save_agent_daily_note(agent_name: str, daily_name: str, body: VaultNoteUpdate) -> dict[str, Any]:
        path = _resolve_agent_note_path(agent_dir, agent_name, "daily", daily_name=daily_name)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(body.content, encoding="utf-8")
        stat = path.stat()
        relative = str(path.relative_to(Path(root)))
        return {"path": relative, "modified_at": _utc_iso(stat.st_mtime)}

    # -- WebSocket --------------------------------------------------------

    @app.websocket("/api/ws")
    async def websocket_endpoint(
        websocket: WebSocket,
        channel: str | None = Query(default=None),
        authorization: str | None = Header(default=None),
        token: str | None = Query(default=None),
    ) -> None:
        bearer = authorization
        if token:
            bearer = f"Bearer {token}"
        if not bearer or not bearer.lower().startswith("bearer ") or bearer.split(" ", 1)[1] != api_key:
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
            return
        await manager.connect(websocket, channel)
        await websocket.send_json({"type": "connected", "channel": channel})
        try:
            while True:
                await websocket.receive_text()
        except WebSocketDisconnect:
            manager.disconnect(websocket)

    return app


def run_api_server(*, host: str = "0.0.0.0", port: int | None = None, config_path: str | None = None) -> None:
    resolved_port = port or int(os.environ.get("AGENTFORGE_API_PORT", "8080"))
    app = create_app(config_path=config_path)
    uvicorn.run(app, host=host, port=resolved_port)
