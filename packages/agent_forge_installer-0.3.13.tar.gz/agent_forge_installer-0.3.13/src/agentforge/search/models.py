from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class SearchRequest:
    query: str
    sources: list[str]
    depth: str
    max_results_per_source: int = 10


@dataclass
class SearchResult:
    title: str
    url: str
    snippet: str
    source: str
    published_at: str | None = None
    relevance_score: float | None = None


@dataclass
class SearchReport:
    query: str
    summary: str
    results: list[SearchResult]
    sources_used: list[str]
    generated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))
