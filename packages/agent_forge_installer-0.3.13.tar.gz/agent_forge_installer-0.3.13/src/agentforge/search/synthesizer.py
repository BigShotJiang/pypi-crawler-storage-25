from __future__ import annotations

from agentforge.claude_runner import invoke_claude
from agentforge.llm_backends import BACKEND_CLAUDE, resolve_backend
from agentforge.search.models import SearchReport, SearchRequest, SearchResult


class SearchSynthesizer:
    def synthesize(
        self,
        request: SearchRequest,
        raw_results: list[SearchResult],
        *,
        root: str,
        config: dict,
        thread_cfg: dict,
    ) -> SearchReport:
        if not raw_results:
            return SearchReport(
                query=request.query,
                summary="No results found for the requested query.",
                results=[],
                sources_used=request.sources,
            )

        source_blocks: list[str] = []
        for idx, item in enumerate(raw_results, start=1):
            source_blocks.append(
                f"{idx}. [{item.source}] {item.title}\nURL: {item.url}\nSnippet: {item.snippet}"
            )
        prompt = (
            f"You are preparing a research brief.\nQuery: {request.query}\n"
            f"Depth: {request.depth}\n"
            f"Write an executive summary in 4-8 bullet points. Focus on signal over noise.\n\n"
            f"Sources:\n" + "\n\n".join(source_blocks[:40])
        )
        model_cfg = dict(thread_cfg)
        model_cfg["backend"] = resolve_backend(
            model_cfg.get("backend", ""),
            model_cfg.get("model", config["claude"]["model"]),
        )
        if request.depth == "deep":
            if model_cfg["backend"] == BACKEND_CLAUDE:
                model_cfg["model"] = "opus"
        else:
            model_cfg["model"] = model_cfg.get("model", "sonnet")
        try:
            result = invoke_claude(
                session_id=f"search-{request.depth}",
                user_text=prompt,
                thread_cfg=model_cfg,
                config=config,
                recent_messages=[],
                root=root,
            )
            summary = (result.text or "").strip()
        except Exception:
            summary = ""

        if not summary:
            summary = "\n".join(f"- {r.title}: {r.snippet[:140]}" for r in raw_results[:5])
        return SearchReport(
            query=request.query,
            summary=summary,
            results=raw_results,
            sources_used=request.sources,
        )
