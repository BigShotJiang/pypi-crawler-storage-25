from __future__ import annotations

import asyncio
import json
import os
import urllib.parse
import urllib.request

from agentforge.search.collectors.base import BaseCollector
from agentforge.search.models import SearchResult


class BraveCollector(BaseCollector):
    @property
    def source_name(self) -> str:
        return "brave"

    async def collect(self, query: str, max_results: int) -> list[SearchResult]:
        return await asyncio.to_thread(self._collect_sync, query, max_results)

    def _collect_sync(self, query: str, max_results: int) -> list[SearchResult]:
        api_key = os.environ.get("BRAVE_API_KEY", "").strip()
        if not api_key:
            raise RuntimeError("BRAVE_API_KEY is not set")

        params = urllib.parse.urlencode({"q": query, "count": max_results})
        url = f"https://api.search.brave.com/res/v1/web/search?{params}"
        req = urllib.request.Request(
            url,
            headers={
                "Accept": "application/json",
                "X-Subscription-Token": api_key,
                "User-Agent": "AgentForge/1.0",
            },
        )
        with urllib.request.urlopen(req, timeout=30) as response:
            payload = json.loads(response.read().decode("utf-8"))

        results: list[SearchResult] = []
        for item in payload.get("web", {}).get("results", []):
            results.append(
                SearchResult(
                    title=item.get("title", "(untitled)"),
                    url=item.get("url", ""),
                    snippet=item.get("description", ""),
                    source=self.source_name,
                    published_at=item.get("age") or item.get("page_age"),
                )
            )
        return results
