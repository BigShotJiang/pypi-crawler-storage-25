"""Voice note transcription using faster-whisper."""

from __future__ import annotations

import logging
import os
import tempfile

from agentforge.http_client import http_get, http_download


def transcribe_voice_note(
    voice: dict,
    api_base: str,
    token: str,
) -> str | None:
    """
    Download a Telegram voice note and transcribe it with faster-whisper.

    Args:
        voice: Telegram voice message dict (must contain 'file_id')
        api_base: Telegram API base URL
        token: Bot token for file download

    Returns:
        Transcribed text, or None if transcription failed/unavailable.
    """
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        logging.warning("faster-whisper not installed — voice transcription unavailable")
        return None

    try:
        file_id = voice["file_id"]
        file_info = http_get(f"{api_base}/getFile", params={"file_id": file_id})
        file_path = file_info["result"]["file_path"]
        file_url = f"https://api.telegram.org/file/bot{token}/{file_path}"

        with tempfile.NamedTemporaryFile(suffix=".ogg", delete=False) as tmp:
            ogg_path = tmp.name

        http_download(file_url, ogg_path)

        # Transcribe with faster-whisper tiny model (CPU, int8 quantized, ~75MB)
        model = WhisperModel("tiny", device="cpu", compute_type="int8")
        segments, _ = model.transcribe(ogg_path)
        text = " ".join(seg.text for seg in segments).strip()
        os.unlink(ogg_path)

        return text if text else None

    except Exception as e:
        logging.error(f"Voice transcription error: {e}", exc_info=True)
        return None
