from __future__ import annotations

import json

from agentforge.team_docs import ensure_team_claude_guidance, render_system_state_markdown, write_system_state_note


def test_render_system_state_markdown_describes_dynamic_runtime_context(tmp_root, config_file) -> None:
    agent_dir = tmp_root / "agents" / "victor"
    agent_dir.mkdir(parents=True)
    (agent_dir / "config.json").write_text(
        json.dumps(
            {
                "name": "victor",
                "telegram": {
                    "token_env_var": "VICTOR_TELEGRAM_TOKEN",
                    "allowed_chat_ids": ["1"],
                    "private_chat_id": "1",
                    "topics": {"victor": 12},
                },
                "claude": {"model": "sonnet"},
                "context": {"messages": 7, "hours": 24},
            }
        ),
        encoding="utf-8",
    )

    content = render_system_state_markdown(root=tmp_root, config_path=config_file)

    assert "last 4 hours, capped at 20 messages, with backfill to 3 messages" in content
    assert "do not treat legacy per-agent `context.messages` values as the current runtime truth" in content
    assert "| `victor` | `sonnet` | `12` | `messages=7; hours=24` |" in content


def test_write_system_state_note_creates_team_note(tmp_root, config_file) -> None:
    dest = write_system_state_note(root=tmp_root, config_path=config_file, printer=lambda *_args, **_kwargs: None)

    assert dest == tmp_root / "vault" / "Agents" / "_team" / "system-state.md"
    assert dest.exists()
    assert "## Verification Rules" in dest.read_text(encoding="utf-8")


def test_render_system_state_markdown_includes_agent_without_thread_config(tmp_root, config_file) -> None:
    agent_dir = tmp_root / "agents" / "christophe"
    agent_dir.mkdir(parents=True)
    (agent_dir / "config.json").write_text(
        json.dumps(
            {
                "name": "christophe",
                "telegram": {
                    "token_env_var": "CHRISTOPHE_TELEGRAM_TOKEN",
                    "allowed_chat_ids": ["1"],
                    "private_chat_id": "1",
                    "topics": {"christophe": 27},
                },
                "claude": {"model": "haiku"},
                "context": {"messages": 5},
            }
        ),
        encoding="utf-8",
    )

    content = render_system_state_markdown(root=tmp_root, config_path=config_file)

    assert "| `christophe` | `haiku` | `27` | `messages=5; hours=?` | per-agent config present |" in content


def test_render_system_state_markdown_prefers_runtime_fields_when_thread_and_agent_overlap(tmp_root, config_file) -> None:
    agent_dir = tmp_root / "agents" / "victor"
    agent_dir.mkdir(parents=True, exist_ok=True)
    (agent_dir / "config.json").write_text(
        json.dumps(
            {
                "name": "victor",
                "telegram": {
                    "token_env_var": "VICTOR_TELEGRAM_TOKEN",
                    "allowed_chat_ids": ["1"],
                    "private_chat_id": "1",
                    "topics": {"victor": 12},
                },
                "claude": {"model": "opus"},
                "context": {"messages": 9, "hours": 48},
            }
        ),
        encoding="utf-8",
    )

    content = render_system_state_markdown(root=tmp_root, config_path=config_file)

    assert "| `victor` | `opus` | `12` | `messages=9; hours=48` | per-agent config present |" in content


def test_ensure_team_claude_guidance_backfills_verification_rules(tmp_root) -> None:
    team_claude = tmp_root / "vault" / "Agents" / "_team" / "CLAUDE.md"
    team_claude.parent.mkdir(parents=True, exist_ok=True)
    team_claude.write_text("# Team Rules\n\n## Communication\n\n- Keep it short.\n", encoding="utf-8")

    dest = ensure_team_claude_guidance(root=tmp_root, printer=lambda *_args, **_kwargs: None)
    content = dest.read_text(encoding="utf-8")

    assert dest == team_claude
    assert "## Verification" in content
    assert "verify against `vault/Agents/_team/system-state.md`" in content
