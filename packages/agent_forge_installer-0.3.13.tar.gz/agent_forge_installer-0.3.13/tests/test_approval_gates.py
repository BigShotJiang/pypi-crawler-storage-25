from __future__ import annotations

import threading
import time
from pathlib import Path

from agentforge.approval_gates import ApprovalGates


def test_evaluate_command_detects_blocked_and_dangerous(tmp_path: Path) -> None:
    gates = ApprovalGates(root=str(tmp_path))
    blocked = gates.evaluate_command("sudo rm -rf /tmp/demo")
    dangerous = gates.evaluate_command("git reset --hard HEAD~1")
    safe = gates.evaluate_command("git status")

    assert blocked.status == "blocked"
    assert dangerous.status == "approval_required"
    assert safe.status == "safe"


def test_request_and_wait_approve_via_callback(tmp_path: Path) -> None:
    gates = ApprovalGates(root=str(tmp_path), timeout_seconds=2)
    sent: list[dict] = []

    def send(chat_id, text, thread_id, reply_markup=None):  # type: ignore[no-untyped-def]
        sent.append({
            "chat_id": chat_id,
            "text": text,
            "thread_id": thread_id,
            "reply_markup": reply_markup,
        })

    holder: dict[str, object] = {}

    def run_wait() -> None:
        holder["result"] = gates.request_and_wait(
            chat_id="123",
            thread_id=456,
            command_text="rm -rf /tmp/demo",
            actor_label="archie",
            send_message_fn=send,
        )

    t = threading.Thread(target=run_wait, daemon=True)
    t.start()
    deadline = time.time() + 2
    while not sent and time.time() < deadline:
        time.sleep(0.01)
    assert sent
    callback_data = sent[0]["reply_markup"]["inline_keyboard"][0][0]["callback_data"]
    resolved = gates.resolve_callback(callback_data, actor_id="42")
    t.join(timeout=3)

    assert resolved is not None
    assert resolved.status == "handled"
    assert holder["result"].status == "approved"


def test_request_and_wait_times_out(tmp_path: Path) -> None:
    gates = ApprovalGates(root=str(tmp_path), timeout_seconds=1)
    result = gates.request_and_wait(
        chat_id="123",
        thread_id=None,
        command_text="rm -rf /tmp/demo",
        actor_label="archie",
        send_message_fn=lambda *args, **kwargs: None,
    )
    assert result.status == "timeout"
