from __future__ import annotations

from agentforge.rate_limiter import RateLimiter


def test_rate_limiter_blocks_minute_limit() -> None:
    now = [1000.0]
    limiter = RateLimiter(max_per_minute=1, max_per_hour=10, max_concurrent_sessions=2, clock=lambda: now[0])

    assert limiter.allow("chat", "clawdia") == (True, "ok")
    assert limiter.allow("chat", "clawdia")[0] is False


def test_rate_limiter_blocks_concurrent_limit() -> None:
    limiter = RateLimiter(max_per_minute=10, max_per_hour=10, max_concurrent_sessions=1)

    assert limiter.allow("chat", "clawdia") == (True, "ok")
    limiter.session_start("clawdia")
    allowed, reason = limiter.allow("chat-2", "clawdia")

    assert allowed is False
    assert "sessions en cours" in reason
    limiter.session_end("clawdia")
