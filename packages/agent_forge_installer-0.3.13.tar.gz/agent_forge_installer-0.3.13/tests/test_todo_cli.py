from __future__ import annotations

from datetime import datetime
from pathlib import Path

from agentforge.todo_md import (
    collect_goal_tags,
    collect_project_tags,
    format_items_markdown,
    parse_tasks_text,
    select_actionable_tasks,
)


def test_parse_tasks_text_supports_metadata_blocks_and_inline_markers() -> None:
    items = parse_tasks_text(
        """
# Todos

## Next

- [ ] Review PR #136 📅 2026-04-12 🔁 every week #project/agentforge
  priority:: high
  last_done:: 2026-04-05

## Waiting

- [ ] Wait for Claude review
  due:: 2026-04-20
  tags:: #goal/review
""".strip()
    )

    assert len(items) == 2
    assert items[0].text == "Review PR #136 #project/agentforge"
    assert items[0].recur == "weekly"
    assert items[0].priority == "high"
    assert "#project/agentforge" in items[0].tags
    assert items[1].section == "Waiting"
    assert "#goal/review" in items[1].tags


def test_select_actionable_tasks_prefers_due_and_next_items() -> None:
    items = parse_tasks_text(
        """
## Inbox
- [ ] Old inbox task

## Next
- [ ] Next section task

- [ ] Explicitly due
  due:: 2026-04-12 09:00

## Waiting
- [ ] Waiting task
  due:: 2026-04-20
""".strip()
    )

    selected = select_actionable_tasks(items, now=datetime(2026, 4, 12, 10, 0), limit=3)
    assert [item.text for item in selected] == [
        "Explicitly due",
        "Next section task",
    ]


def test_project_and_goal_tag_helpers() -> None:
    items = parse_tasks_text(
        """
## Inbox
- [ ] Task one #project/agentforge
- [ ] Task two
  tags:: #goal/review #project/system
""".strip()
    )

    assert collect_project_tags(items) == ["#project/agentforge", "#project/system"]
    assert collect_goal_tags(items) == ["#goal/review"]


def test_format_items_markdown_is_stable() -> None:
    items = parse_tasks_text(
        """
## Next
- [ ] Write docs
  due:: 2026-04-15
  recur:: weekly
  tags:: #project/docs
""".strip(),
        source_path=Path("/tmp/tasks.md"),
    )
    rendered = format_items_markdown(items)
    assert "## Actionable Tasks" in rendered
    assert "due:: 2026-04-15" in rendered
    assert "recur:: weekly" in rendered
