from __future__ import annotations

from datetime import datetime, timedelta, timezone

from agentforge.monitoring import collect_agent_heartbeats, collect_monitoring_status


def test_collect_monitoring_status_reports_global_and_services(tmp_root, sample_config_dict, monkeypatch):
    now = datetime.now(timezone.utc)
    stamp = now.strftime("%Y-%m-%d %H:%M:%S")
    (tmp_root / "logs" / "heartbeat.log").write_text(f"[{stamp}] Heartbeat starting\n")

    config = dict(sample_config_dict)
    config["threads"] = {
        "default": {"model": "sonnet"},
        "11": {"name": "clawdia", "model": "sonnet"},
    }

    monkeypatch.setattr("agentforge.monitoring._process_running", lambda pattern: True)

    payload = collect_monitoring_status(root=tmp_root, config=config)

    assert payload["status"] == "ok"
    assert payload["checked_at"]
    assert {service["id"] for service in payload["services"]} >= {
        "cron",
        "telegram-adapter",
        "api-server",
        "agent-runtime",
    }


def test_collect_monitoring_status_marks_stale_cron_as_error(tmp_root, sample_config_dict, monkeypatch):
    old = datetime.now(timezone.utc) - timedelta(minutes=10)
    (tmp_root / "logs" / "heartbeat.log").write_text(
        f"[{old.strftime('%Y-%m-%d %H:%M:%S')}] Heartbeat starting\n"
    )

    config = dict(sample_config_dict)
    config["heartbeat"] = {"interval_minutes": 1, "max_budget_usd": 0.1}

    monkeypatch.setattr("agentforge.monitoring._process_running", lambda pattern: True)

    payload = collect_monitoring_status(root=tmp_root, config=config)

    cron = next(service for service in payload["services"] if service["id"] == "cron")
    assert cron["status"] == "error"
    assert cron["is_late"] is True
    assert payload["status"] == "error"


def test_collect_agent_heartbeats_reports_last_agent_activity(tmp_root, sample_config_dict):
    agent_dir = tmp_root / "agents" / "clawdia"
    (agent_dir / "daily").mkdir(parents=True)
    (agent_dir / "soul.md").write_text("# soul")
    (agent_dir / "memory.md").write_text("# memory")
    (agent_dir / "daily" / "2026-03-19.md").write_text("# day")
    (tmp_root / "logs" / "actions.log").write_text(
        "[2026-03-19 09:30] clawdia | git_push | github | synced\n"
        "[2026-03-19 09:45] victor | gog | sheets | append\n"
    )

    payload = collect_agent_heartbeats(root=tmp_root, config=sample_config_dict)

    clawdia = next(agent for agent in payload["agents"] if agent["name"] == "clawdia")
    assert payload["checked_at"]
    assert clawdia["last_heartbeat_at"] == "2026-03-19T09:30:00Z"
    assert clawdia["status"] == "ok"
    assert clawdia["has_soul"] is True
    assert clawdia["has_memory"] is True
    assert clawdia["daily_note_count"] == 1
