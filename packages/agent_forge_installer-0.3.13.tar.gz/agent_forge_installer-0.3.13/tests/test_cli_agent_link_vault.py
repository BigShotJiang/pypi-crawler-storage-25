from __future__ import annotations

from pathlib import Path

import pytest

from agentforge.cli.agent import agent_link_vault


def _make_agent(agents_root: Path, name: str) -> Path:
    agent_dir = agents_root / name
    agent_dir.mkdir(parents=True)
    (agent_dir / "soul.md").write_text(f"# {name}\n", encoding="utf-8")
    (agent_dir / "memory.md").write_text("memory\n", encoding="utf-8")
    (agent_dir / "tasks.md").write_text("tasks\n", encoding="utf-8")
    daily = agent_dir / "daily"
    daily.mkdir()
    (daily / "2026-01-01.md").write_text("today\n", encoding="utf-8")
    return agent_dir


def test_link_vault_moves_files_and_creates_symlinks(monkeypatch, tmp_path: Path) -> None:
    root = tmp_path
    vault = root / "vault"
    vault.mkdir()
    _make_agent(root / "agents", "alice")

    monkeypatch.setenv("AGENTFORGE_ROOT", str(root))
    agent_link_vault(["alice"], vault_dir=str(vault))

    vault_dir = vault / "Agents" / "alice"
    agent_dir = root / "agents" / "alice"

    # Files moved to vault
    assert (vault_dir / "soul.md").is_file()
    assert (vault_dir / "memory.md").is_file()
    assert (vault_dir / "tasks.md").is_file()
    assert (vault_dir / "daily" / "2026-01-01.md").is_file()

    # Symlinks remain in agent dir
    assert (agent_dir / "soul.md").is_symlink()
    assert (agent_dir / "memory.md").is_symlink()
    assert (agent_dir / "tasks.md").is_symlink()
    assert (agent_dir / "daily").is_symlink()

    # Symlinks resolve correctly
    assert (agent_dir / "soul.md").read_text(encoding="utf-8") == "# alice\n"
    assert (agent_dir / "daily" / "2026-01-01.md").read_text(encoding="utf-8") == "today\n"


def test_link_vault_uses_relative_targets_for_custom_vault_dir(
    monkeypatch, tmp_path: Path
) -> None:
    root = tmp_path / "instance"
    vault = tmp_path / "external-vault"
    root.mkdir()
    vault.mkdir()
    _make_agent(root / "agents", "eve")

    monkeypatch.setenv("AGENTFORGE_ROOT", str(root))
    agent_link_vault(["eve"], vault_dir=str(vault))

    agent_dir = root / "agents" / "eve"
    assert (agent_dir / "soul.md").is_symlink()
    assert (agent_dir / "soul.md").read_text(encoding="utf-8") == "# eve\n"
    assert (agent_dir / "daily" / "2026-01-01.md").read_text(encoding="utf-8") == "today\n"


def test_link_vault_dry_run_does_not_move(monkeypatch, tmp_path: Path) -> None:
    root = tmp_path
    vault = root / "vault"
    vault.mkdir()
    _make_agent(root / "agents", "bob")

    monkeypatch.setenv("AGENTFORGE_ROOT", str(root))
    agent_link_vault(["bob"], vault_dir=str(vault), dry_run=True)

    # Nothing should have moved
    assert (root / "agents" / "bob" / "soul.md").is_file()
    assert not (root / "agents" / "bob" / "soul.md").is_symlink()
    assert not (vault / "Agents" / "bob" / "soul.md").exists()


def test_link_vault_idempotent(monkeypatch, tmp_path: Path) -> None:
    root = tmp_path
    vault = root / "vault"
    vault.mkdir()
    _make_agent(root / "agents", "carol")

    monkeypatch.setenv("AGENTFORGE_ROOT", str(root))
    agent_link_vault(["carol"], vault_dir=str(vault))
    # Running again should not raise
    agent_link_vault(["carol"], vault_dir=str(vault))

    assert (root / "agents" / "carol" / "soul.md").is_symlink()


def test_link_vault_aborts_on_existing_vault_content(monkeypatch, tmp_path: Path) -> None:
    root = tmp_path
    vault = root / "vault"
    vault_agent = vault / "Agents" / "dana"
    vault_agent.mkdir(parents=True)
    _make_agent(root / "agents", "dana")
    (vault_agent / "soul.md").write_text("vault copy\n", encoding="utf-8")

    monkeypatch.setenv("AGENTFORGE_ROOT", str(root))

    with pytest.raises(SystemExit):
        agent_link_vault(["dana"], vault_dir=str(vault))

    assert (root / "agents" / "dana" / "soul.md").is_file()
    assert not (root / "agents" / "dana" / "soul.md").is_symlink()
    assert (vault_agent / "soul.md").read_text(encoding="utf-8") == "vault copy\n"


def test_link_vault_default_run_skips_shared_agent_dir(
    monkeypatch, tmp_path: Path
) -> None:
    root = tmp_path
    vault = root / "vault"
    vault.mkdir()
    _make_agent(root / "agents", "alice")
    shared_dir = _make_agent(root / "agents", "shared")

    monkeypatch.setenv("AGENTFORGE_ROOT", str(root))
    agent_link_vault(vault_dir=str(vault))

    assert (root / "agents" / "alice" / "soul.md").is_symlink()
    assert (shared_dir / "soul.md").is_file()
    assert not (vault / "Agents" / "shared").exists()
