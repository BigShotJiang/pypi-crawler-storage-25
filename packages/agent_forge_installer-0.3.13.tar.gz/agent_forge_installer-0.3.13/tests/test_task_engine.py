from __future__ import annotations

from datetime import datetime

from agentforge.task_engine import TaskEngine


def test_create_task_and_render_heartbeat_payload(tmp_path) -> None:
    root = tmp_path
    (root / "agents" / "christophe").mkdir(parents=True)
    (root / "agents" / "christophe" / "config.json").write_text("{}", encoding="utf-8")
    prompt_path = root / "vault" / "Agents" / "christophe" / "morning-brief.md"
    prompt_path.parent.mkdir(parents=True, exist_ok=True)
    prompt_path.write_text("Send the morning brief.", encoding="utf-8")

    engine = TaskEngine(root)
    engine.create_task(
        assignee_id="christophe",
        title="Send morning brief",
        due_at=datetime(2026, 4, 14, 9, 0),
        recurrence_rule="daily",
        prompt_ref="morning-brief.md",
        source="test",
    )

    payload = engine.render_heartbeat_payload("christophe", now=datetime(2026, 4, 14, 8, 50))
    assert "Relevant Structured Tasks" in payload
    assert "Send the morning brief." in payload
    assert "TASK_DONE" in payload


def test_complete_recurring_task_advances_next_run(tmp_path) -> None:
    root = tmp_path
    (root / "agents" / "christophe").mkdir(parents=True)
    (root / "agents" / "christophe" / "config.json").write_text("{}", encoding="utf-8")

    engine = TaskEngine(root)
    task_id = engine.create_task(
        assignee_id="christophe",
        title="Send morning brief",
        due_at=datetime(2026, 4, 14, 9, 0),
        recurrence_rule="daily",
        source="test",
    )

    assert engine.complete_task(task_id, completed_at=datetime(2026, 4, 14, 9, 5))

    # Original task is now a completed record.
    all_tasks = engine.list_tasks("christophe")
    original = next((t for t in all_tasks if t.task_id == task_id), None)
    assert original is not None
    assert original.status == "done"
    assert original.last_completed_at == datetime(2026, 4, 14, 9, 5)

    # New task carries the next occurrence.
    next_task = next((t for t in all_tasks if t.task_id != task_id and t.status == "open"), None)
    assert next_task is not None
    assert next_task.next_run_at == datetime(2026, 4, 15, 9, 0)


def test_bootstrap_actor_removes_legacy_tasks_view(tmp_path) -> None:
    root = tmp_path
    (root / "agents" / "christophe").mkdir(parents=True)
    (root / "agents" / "christophe" / "config.json").write_text("{}", encoding="utf-8")
    tasks_path = root / "vault" / "Agents" / "christophe" / "tasks.md"
    tasks_path.parent.mkdir(parents=True, exist_ok=True)
    tasks_path.write_text("legacy\n", encoding="utf-8")

    engine = TaskEngine(root)
    engine.bootstrap_actor("christophe")

    assert not tasks_path.exists()
    assert engine.list_tasks("christophe") == []


def test_one_shot_task_without_due_date_is_always_actionable(tmp_path) -> None:
    root = tmp_path
    (root / "agents" / "christophe").mkdir(parents=True)
    (root / "agents" / "christophe" / "config.json").write_text("{}", encoding="utf-8")

    engine = TaskEngine(root)
    engine.create_task(
        assignee_id="christophe",
        title="Background task",
        source="test",
    )

    # Tasks without a due date are always actionable — background work, lowest priority.
    actionable = engine.select_actionable("christophe", now=datetime(2026, 4, 14, 9, 0))
    assert len(actionable) == 1
    assert actionable[0].title == "Background task"


def test_defer_task_pushes_next_run_forward(tmp_path) -> None:
    root = tmp_path
    (root / "agents" / "christophe").mkdir(parents=True)
    (root / "agents" / "christophe" / "config.json").write_text("{}", encoding="utf-8")

    engine = TaskEngine(root)
    task_id = engine.create_task(
        assignee_id="christophe",
        title="Due task",
        due_at=datetime(2026, 4, 14, 9, 0),
        source="test",
    )

    before = engine.list_tasks("christophe")[0]
    assert before.next_run_at == datetime(2026, 4, 14, 8, 0)
    assert engine.defer_task(task_id, deferred_until=datetime(2026, 4, 14, 9, 30))
    after = engine.list_tasks("christophe")[0]
    assert after.next_run_at == datetime(2026, 4, 14, 9, 30)
