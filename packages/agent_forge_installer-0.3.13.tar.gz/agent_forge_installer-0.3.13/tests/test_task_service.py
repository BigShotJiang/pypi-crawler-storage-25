from __future__ import annotations

from datetime import datetime
from pathlib import Path

from agentforge.task_service import TaskService


def test_update_task_loads_prompt_from_prompt_ref(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    root = tmp_path
    (root / "agents" / "architect").mkdir(parents=True)
    (root / "agents" / "architect" / "config.json").write_text("{}", encoding="utf-8")
    prompt_path = root / "vault" / "Agents" / "architect" / "brief.md"
    prompt_path.parent.mkdir(parents=True, exist_ok=True)
    prompt_path.write_text("Updated prompt body.", encoding="utf-8")

    service = TaskService(root)
    task_id = service.create_task(assignee_id="architect", title="Prompted task")
    assert service.update_task(task_id, prompt_ref="brief.md")

    record = next(task for task in service.list_tasks("architect") if task.task_id == task_id)
    # prompt_ref is no longer serialized; the loaded content lives directly in notes.
    assert record.notes == "Updated prompt body."


def test_render_heartbeat_payload_includes_prompt_ref(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    root = tmp_path
    (root / "agents" / "architect").mkdir(parents=True)
    (root / "agents" / "architect" / "config.json").write_text("{}", encoding="utf-8")
    prompt_path = root / "vault" / "Agents" / "architect" / "brief.md"
    prompt_path.parent.mkdir(parents=True, exist_ok=True)
    prompt_path.write_text("Heartbeat prompt.", encoding="utf-8")

    service = TaskService(root)
    task_id = service.create_task(
        assignee_id="architect",
        title="Heartbeat task",
        due_at=datetime(2026, 4, 15, 10, 0),
        prompt_ref="brief.md",
    )
    payload = service.render_heartbeat_payload("architect", now=datetime(2026, 4, 15, 9, 50))
    assert task_id in payload
    # Prompt content is now directly in notes — no prompt_ref metadata line in payload.
    assert "Heartbeat prompt." in payload


def test_cleanup_legacy_tasks_view_removes_legacy_tasks_file(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    root = tmp_path
    (root / "agents" / "architect").mkdir(parents=True)
    (root / "agents" / "architect" / "config.json").write_text("{}", encoding="utf-8")
    legacy_path = root / "vault" / "Agents" / "architect" / "tasks.md"
    legacy_path.parent.mkdir(parents=True, exist_ok=True)
    legacy_path.write_text("legacy\n", encoding="utf-8")

    service = TaskService(root)
    path = service.cleanup_legacy_tasks_view("architect")
    assert path == legacy_path
    assert not path.exists()


def test_bootstrap_actor_idempotent(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    root = tmp_path
    (root / "agents" / "architect").mkdir(parents=True)
    (root / "agents" / "architect" / "config.json").write_text("{}", encoding="utf-8")

    service = TaskService(root)
    service.bootstrap_actor("architect")
    # Second call must not raise — resolve_list with create=True is idempotent.
    service.bootstrap_actor("architect")
