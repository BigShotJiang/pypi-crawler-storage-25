from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path

import pytest

from agentforge.claude_runner import (
    MAX_CONTEXT_SECTION_CHARS,
    ClaudeCodeLimitError,
    RateLimitError,
    invoke_claude,
    parse_quota_restore_at,
    parse_retry_after_seconds,
)


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def _seed_runtime_claude(root: Path) -> None:
    runtime_claude = root / "runtime" / ".local" / "bin" / "claude"
    _write(runtime_claude, "#!/bin/sh\nexit 0\n")
    runtime_claude.chmod(0o755)


@pytest.fixture(autouse=True)
def runtime_claude_bin(tmp_path: Path) -> None:
    _seed_runtime_claude(tmp_path)


def test_invoke_claude_prefers_team_rules_and_skips_daily_notes(monkeypatch, tmp_path: Path) -> None:
    _write(tmp_path / "CLAUDE.md", "shared instructions")
    _write(tmp_path / "vault" / "Agents" / "_team" / "CLAUDE.md", "team rules")
    _write(tmp_path / "CLAUDE.local.md", "local instructions")
    _write(tmp_path / "vault" / "Agents" / "clawdia" / "soul.md", "soul section")
    _write(tmp_path / "vault" / "Agents" / "clawdia" / "memory.md", "memory section")
    _write(tmp_path / "agents" / "clawdia" / "daily" / "2026-03-17.md", "older daily")
    _write(tmp_path / "agents" / "clawdia" / "daily" / "2026-03-18.md", "latest daily")

    captured: dict[str, object] = {}

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = cmd
        captured["kwargs"] = kwargs

        class Result:
            returncode = 0
            stdout = "ok"
            stderr = ""

        return Result()

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)

    response = invoke_claude(
        session_id="sess-1",
        user_text="hello",
        thread_cfg={"name": "clawdia", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    assert response.text == "ok"
    cmd = captured["cmd"]
    prompt_index = cmd.index("--system-prompt") + 1
    assert (
        cmd[prompt_index]
        == "shared instructions\n\nteam rules\n\n## Soul\nsoul section\n\n## Memory\nmemory section"
    )


def test_invoke_claude_routes_named_agent_context(monkeypatch, tmp_path: Path) -> None:
    _write(tmp_path / "CLAUDE.md", "shared instructions")
    _write(tmp_path / "agents" / "researcher" / "soul.md", "agent soul")
    _write(tmp_path / "agents" / "researcher" / "memory.md", "agent memory")

    captured: dict[str, object] = {}

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = cmd

        class Result:
            returncode = 0
            stdout = "ok"
            stderr = ""

        return Result()

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)

    invoke_claude(
        session_id="sess-2",
        user_text="hello",
        thread_cfg={"name": "researcher", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    cmd = captured["cmd"]
    prompt_index = cmd.index("--system-prompt") + 1
    assert cmd[prompt_index] == "shared instructions\n\n## Soul\nagent soul\n\n## Memory\nagent memory"


def test_invoke_claude_prefers_vault_agent_context(monkeypatch, tmp_path: Path) -> None:
    _write(tmp_path / "CLAUDE.md", "shared instructions")
    _write(tmp_path / "vault" / "Agents" / "researcher" / "soul.md", "vault soul")
    _write(tmp_path / "vault" / "Agents" / "researcher" / "memory.md", "vault memory")
    _write(tmp_path / "agents" / "researcher" / "soul.md", "legacy soul")
    _write(tmp_path / "agents" / "researcher" / "memory.md", "legacy memory")

    captured: dict[str, object] = {}

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = cmd

        class Result:
            returncode = 0
            stdout = "ok"
            stderr = ""

        return Result()

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)

    invoke_claude(
        session_id="sess-vault-agent",
        user_text="hello",
        thread_cfg={"name": "researcher", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    cmd = captured["cmd"]
    prompt_index = cmd.index("--system-prompt") + 1
    assert cmd[prompt_index] == "shared instructions\n\n## Soul\nvault soul\n\n## Memory\nvault memory"


def test_invoke_claude_skips_missing_context_files(monkeypatch, tmp_path: Path) -> None:
    _write(tmp_path / "CLAUDE.md", "shared instructions")
    _write(tmp_path / "agents" / "writer" / "soul.md", "writer soul")

    captured: dict[str, object] = {}

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = cmd

        class Result:
            returncode = 0
            stdout = "ok"
            stderr = ""

        return Result()

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)

    invoke_claude(
        session_id="sess-3",
        user_text="hello",
        thread_cfg={"name": "writer", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    cmd = captured["cmd"]
    prompt_index = cmd.index("--system-prompt") + 1
    assert cmd[prompt_index] == "shared instructions\n\n## Soul\nwriter soul"


def test_invoke_claude_caps_large_context_sections(monkeypatch, tmp_path: Path) -> None:
    _write(tmp_path / "CLAUDE.md", "shared instructions")
    _write(tmp_path / "agents" / "writer" / "soul.md", "writer soul")
    _write(
        tmp_path / "agents" / "writer" / "memory.md",
        "m" * (MAX_CONTEXT_SECTION_CHARS + 50),
    )

    captured: dict[str, object] = {}

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = cmd

        class Result:
            returncode = 0
            stdout = "ok"
            stderr = ""

        return Result()

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)

    invoke_claude(
        session_id="sess-4",
        user_text="hello",
        thread_cfg={"name": "writer", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    cmd = captured["cmd"]
    prompt_index = cmd.index("--system-prompt") + 1
    expected_memory = "m" * MAX_CONTEXT_SECTION_CHARS
    assert cmd[prompt_index] == f"shared instructions\n\n## Soul\nwriter soul\n\n## Memory\n{expected_memory}"


def test_invoke_claude_uses_root_claude_files_without_agent_context(
    monkeypatch, tmp_path: Path
) -> None:
    _write(tmp_path / "CLAUDE.md", "shared instructions")
    _write(tmp_path / "CLAUDE.local.md", "local instructions")

    captured: dict[str, object] = {}

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = cmd

        class Result:
            returncode = 0
            stdout = "ok"
            stderr = ""

        return Result()

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)

    invoke_claude(
        session_id="sess-root-only",
        user_text="hello",
        thread_cfg={"model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    cmd = captured["cmd"]
    prompt_index = cmd.index("--system-prompt") + 1
    assert cmd[prompt_index] == "shared instructions\n\nlocal instructions"


def test_invoke_claude_routes_ollama_backend(monkeypatch, tmp_path: Path) -> None:
    _write(tmp_path / "CLAUDE.md", "shared instructions")
    captured: dict[str, object] = {}

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = cmd

        class Result:
            returncode = 0
            stdout = '{"result":"OK","total_cost_usd":0.12,"usage":{"input_tokens":10,"output_tokens":2}}'
            stderr = ""

        return Result()

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)

    response = invoke_claude(
        session_id="sess-ollama",
        user_text="hello",
        thread_cfg={"name": "catherine", "backend": "ollama", "model": "gemma4:e4b"},
        config={"claude": {"backend": "claude", "model": "sonnet", "max_budget_usd": 5.0}},
        recent_messages=[],
        root=str(tmp_path),
    )

    cmd = captured["cmd"]
    assert cmd[:4] == ["ollama", "launch", "claude", "--model"]
    assert "--max-budget-usd" not in cmd
    assert response.text == "OK"
    assert response.cost_usd == 0.12


def test_invoke_claude_routes_codex_backend(monkeypatch, tmp_path: Path) -> None:
    _write(tmp_path / "CLAUDE.md", "shared instructions")
    captured: dict[str, object] = {}

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = cmd
        output_path = Path(cmd[cmd.index("-o") + 1])
        output_path.write_text("OK FROM CODEX", encoding="utf-8")

        class Result:
            returncode = 0
            stdout = ""
            stderr = ""

        return Result()

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)

    response = invoke_claude(
        session_id="sess-codex",
        user_text="hello",
        thread_cfg={"name": "porter", "backend": "codex", "model": "gpt-5.4"},
        config={"claude": {"backend": "claude", "model": "sonnet", "max_budget_usd": 5.0}},
        recent_messages=[],
        root=str(tmp_path),
    )

    cmd = captured["cmd"]
    assert cmd[:3] == ["codex", "exec", "--model"]
    assert response.text == "OK FROM CODEX"


def test_invoke_claude_infers_ollama_backend_from_model(monkeypatch, tmp_path: Path) -> None:
    _write(tmp_path / "CLAUDE.md", "shared instructions")
    captured: dict[str, object] = {}

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = cmd

        class Result:
            returncode = 0
            stdout = '{"result":"OK"}'
            stderr = ""

        return Result()

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)

    response = invoke_claude(
        session_id="sess-legacy-ollama",
        user_text="hello",
        thread_cfg={"name": "catherine", "model": "gemma4:e4b"},
        config={"claude": {"model": "sonnet", "max_budget_usd": 5.0}},
        recent_messages=[],
        root=str(tmp_path),
    )

    cmd = captured["cmd"]
    assert cmd[:3] == ["ollama", "launch", "claude"]
    assert response.text == "OK"


def test_parse_quota_restore_at_usage_limit_reset_time_ms() -> None:
    raw = '{"usageLimitResetTime": 2000000000000}'
    got = parse_quota_restore_at(raw)
    assert got == datetime.fromtimestamp(2_000_000_000, tz=timezone.utc)


def test_parse_quota_restore_at_iso_z() -> None:
    raw = "Please retry after 2030-06-01T15:30:00Z"
    got = parse_quota_restore_at(raw)
    assert got == datetime(2030, 6, 1, 15, 30, tzinfo=timezone.utc)


def test_parse_retry_after_seconds() -> None:
    assert parse_retry_after_seconds("Retry-After: 90") == 90
    assert parse_retry_after_seconds('{"retry_after": 45}') == 45
    assert parse_retry_after_seconds("no hints") is None


def test_invoke_claude_raises_claude_code_limit_with_restore_at(monkeypatch, tmp_path: Path) -> None:
    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        class Result:
            returncode = 1
            stdout = ""
            stderr = (
                "Error: usage limit reached for your plan. "
                '{"usageLimitResetTime": 2000000000000}'
            )

        return Result()

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)

    with pytest.raises(ClaudeCodeLimitError) as excinfo:
        invoke_claude(
            session_id="sess-quota",
            user_text="hello",
            thread_cfg={"name": "writer", "model": "sonnet"},
            config={"claude": {"model": "sonnet"}},
            recent_messages=[],
            root=str(tmp_path),
        )

    assert excinfo.value.restore_at == datetime.fromtimestamp(2_000_000_000, tz=timezone.utc)


def test_invoke_claude_raises_rate_limit_with_parsed_retry(monkeypatch, tmp_path: Path) -> None:
    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        class Result:
            returncode = 1
            stdout = ""
            stderr = "429 Too Many Requests retry_after: 42"

        return Result()

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)

    with pytest.raises(RateLimitError) as excinfo:
        invoke_claude(
            session_id="sess-rl",
            user_text="hello",
            thread_cfg={"name": "writer", "model": "sonnet"},
            config={"claude": {"model": "sonnet"}},
            recent_messages=[],
            root=str(tmp_path),
        )

    assert excinfo.value.retry_after_seconds == 42


def test_invoke_claude_injects_semantic_vault_memories(monkeypatch, tmp_path: Path) -> None:
    _write(tmp_path / "CLAUDE.md", "shared instructions")
    _write(tmp_path / "agents" / "writer" / "soul.md", "writer soul")

    captured: dict[str, object] = {}

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = cmd

        class Result:
            returncode = 0
            stdout = "ok"
            stderr = ""

        return Result()

    def fake_semantic(*args, **kwargs):  # type: ignore[no-untyped-def]
        return [({"id": 7, "agent": "shared", "category": "memory", "title": "Budget", "content": "Martin likes budgeting apps"}, 0.77)]

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)
    monkeypatch.setattr("agentforge.vault.semantic_search_entries", fake_semantic)

    invoke_claude(
        session_id="sess-semantic",
        user_text="Find my financial tracking preferences",
        thread_cfg={"name": "writer", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    cmd = captured["cmd"]
    prompt = cmd[-1]
    assert "## Relevant Vault Memories" in prompt
    assert "budgeting apps" in prompt.lower()


def test_invoke_claude_includes_full_thread_section_before_recent_conversation(monkeypatch, tmp_path: Path) -> None:
    _write(tmp_path / "CLAUDE.md", "shared instructions")

    captured: dict[str, object] = {}

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = cmd

        class Result:
            returncode = 0
            stdout = "ok"
            stderr = ""

        return Result()

    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", fake_run)

    invoke_claude(
        session_id="sess-thread",
        user_text="latest reply",
        thread_cfg={"name": "writer", "model": "sonnet", "topic_context": "Shared topic"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[("user", "topic post", "2026-03-14 10:00:00")],
        thread_messages=[
            ("user", "thread root", "2026-03-14 10:05:00"),
            ("assistant", "prior reply", "2026-03-14 10:06:00"),
        ],
        root=str(tmp_path),
    )

    prompt = captured["cmd"][-1]
    assert "## Current Thread" in prompt
    assert "thread root" in prompt
    assert "prior reply" in prompt
    assert prompt.index("## Current Thread") < prompt.index("## Recent Conversation")
    assert "## Contexte du topic" in prompt


# ---------------------------------------------------------------------------
# Fallback chain — three-level coverage
# ---------------------------------------------------------------------------

def _make_fake_run(captured: dict) -> object:  # type: ignore[type-arg]
    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = cmd

        class Result:
            returncode = 0
            stdout = "ok"
            stderr = ""

        return Result()

    return fake_run


def test_fallback_chain_uses_shared_when_vault_absent(monkeypatch, tmp_path: Path) -> None:
    """vault/Agents/_team/CLAUDE.md absent → agents/shared/CLAUDE.md used, CLAUDE.local.md skipped."""
    _write(tmp_path / "CLAUDE.md", "framework")
    _write(tmp_path / "agents" / "shared" / "CLAUDE.md", "shared rules")
    _write(tmp_path / "CLAUDE.local.md", "local rules")  # must not appear
    _write(tmp_path / "agents" / "alpha" / "soul.md", "soul")

    captured: dict[str, object] = {}
    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", _make_fake_run(captured))

    invoke_claude(
        session_id="s-fb-shared",
        user_text="hi",
        thread_cfg={"name": "alpha", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    prompt_index = captured["cmd"].index("--system-prompt") + 1
    assert captured["cmd"][prompt_index] == "framework\n\nshared rules\n\n## Soul\nsoul"


def test_fallback_chain_uses_local_when_vault_and_shared_absent(monkeypatch, tmp_path: Path) -> None:
    """vault and agents/shared/CLAUDE.md both absent → CLAUDE.local.md used."""
    _write(tmp_path / "CLAUDE.md", "framework")
    _write(tmp_path / "CLAUDE.local.md", "local rules")
    _write(tmp_path / "agents" / "alpha" / "soul.md", "soul")

    captured: dict[str, object] = {}
    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", _make_fake_run(captured))

    invoke_claude(
        session_id="s-fb-local",
        user_text="hi",
        thread_cfg={"name": "alpha", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    prompt_index = captured["cmd"].index("--system-prompt") + 1
    assert captured["cmd"][prompt_index] == "framework\n\nlocal rules\n\n## Soul\nsoul"


def test_fallback_chain_uses_nothing_when_all_three_absent(monkeypatch, tmp_path: Path) -> None:
    """All three instance-rules files absent → no instance-rules section in system prompt."""
    _write(tmp_path / "CLAUDE.md", "framework")
    _write(tmp_path / "agents" / "alpha" / "soul.md", "soul")

    captured: dict[str, object] = {}
    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", _make_fake_run(captured))

    invoke_claude(
        session_id="s-fb-none",
        user_text="hi",
        thread_cfg={"name": "alpha", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    prompt_index = captured["cmd"].index("--system-prompt") + 1
    assert captured["cmd"][prompt_index] == "framework\n\n## Soul\nsoul"


# ---------------------------------------------------------------------------
# Vault-preferred shared memory (layer 3) — coverage
# ---------------------------------------------------------------------------

def test_shared_memory_prefers_vault_over_agents_shared(monkeypatch, tmp_path: Path) -> None:
    """vault/Agents/_team/memory.md present → used as Shared Knowledge; agents/shared ignored."""
    _write(tmp_path / "CLAUDE.md", "framework")
    _write(tmp_path / "vault" / "Agents" / "_team" / "memory.md", "vault facts")
    _write(tmp_path / "agents" / "shared" / "memory.md", "legacy facts")  # must NOT appear
    _write(tmp_path / "agents" / "alpha" / "soul.md", "soul")

    captured: dict[str, object] = {}
    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", _make_fake_run(captured))

    invoke_claude(
        session_id="s-mem-vault",
        user_text="hi",
        thread_cfg={"name": "alpha", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    prompt_index = captured["cmd"].index("--system-prompt") + 1
    system = captured["cmd"][prompt_index]
    assert "## Shared Knowledge\nvault facts" in system
    assert "legacy facts" not in system


def test_shared_memory_falls_back_to_agents_shared_when_vault_absent(monkeypatch, tmp_path: Path) -> None:
    """vault memory absent → agents/shared/memory.md used as Shared Knowledge."""
    _write(tmp_path / "CLAUDE.md", "framework")
    _write(tmp_path / "agents" / "shared" / "memory.md", "legacy facts")
    _write(tmp_path / "agents" / "alpha" / "soul.md", "soul")

    captured: dict[str, object] = {}
    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", _make_fake_run(captured))

    invoke_claude(
        session_id="s-mem-legacy",
        user_text="hi",
        thread_cfg={"name": "alpha", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    prompt_index = captured["cmd"].index("--system-prompt") + 1
    system = captured["cmd"][prompt_index]
    assert "## Shared Knowledge\nlegacy facts" in system


def test_shared_memory_absent_when_both_paths_missing(monkeypatch, tmp_path: Path) -> None:
    """Both memory paths absent → no Shared Knowledge section in system prompt."""
    _write(tmp_path / "CLAUDE.md", "framework")
    _write(tmp_path / "agents" / "alpha" / "soul.md", "soul")

    captured: dict[str, object] = {}
    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", _make_fake_run(captured))

    invoke_claude(
        session_id="s-mem-none",
        user_text="hi",
        thread_cfg={"name": "alpha", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    prompt_index = captured["cmd"].index("--system-prompt") + 1
    system = captured["cmd"][prompt_index]
    assert "Shared Knowledge" not in system


def test_invoke_claude_warns_when_system_state_missing(monkeypatch, tmp_path: Path) -> None:
    _write(tmp_path / "CLAUDE.md", "framework")
    _write(tmp_path / "bot" / "config.json", '{"claude": {"model": "sonnet"}}')

    captured: dict[str, object] = {}
    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", _make_fake_run(captured))

    invoke_claude(
        session_id="s-stale-missing",
        user_text="hi",
        thread_cfg={"model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    prompt_index = captured["cmd"].index("--system-prompt") + 1
    system = captured["cmd"][prompt_index]
    assert "## System State Warning" in system
    assert "is missing" in system


def test_invoke_claude_warns_when_system_state_is_older_than_config(monkeypatch, tmp_path: Path) -> None:
    _write(tmp_path / "CLAUDE.md", "framework")
    system_state = tmp_path / "vault" / "Agents" / "_team" / "system-state.md"
    _write(system_state, "# System State\n")
    _write(tmp_path / "bot" / "config.json", '{"claude": {"model": "sonnet"}}')
    newer_agent_config = tmp_path / "agents" / "alpha" / "config.json"
    _write(newer_agent_config, '{"claude": {"model": "opus"}}')
    os.utime(system_state, (1_000, 1_000))
    os.utime(newer_agent_config, (2_000, 2_000))

    captured: dict[str, object] = {}
    monkeypatch.setattr("agentforge.claude_runner.subprocess.run", _make_fake_run(captured))

    invoke_claude(
        session_id="s-stale-old",
        user_text="hi",
        thread_cfg={"name": "alpha", "model": "sonnet"},
        config={"claude": {"model": "sonnet"}},
        recent_messages=[],
        root=str(tmp_path),
    )

    prompt_index = captured["cmd"].index("--system-prompt") + 1
    system = captured["cmd"][prompt_index]
    assert "## System State Warning" in system
    assert "may be stale relative to current config files" in system
