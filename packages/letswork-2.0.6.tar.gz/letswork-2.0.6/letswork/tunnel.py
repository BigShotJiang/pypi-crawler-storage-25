import subprocess
import shutil
import re
import time
import threading


def start_tunnel(port: int) -> tuple[str, subprocess.Popen]:
    """Start a Cloudflare tunnel pointing to the local MCP server port. Returns the HTTPS URL and the subprocess handle."""
    if shutil.which("cloudflared") is None:
        raise RuntimeError("cloudflared is not installed. Install it from https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/")

    command = ["cloudflared", "tunnel", "--url", f"http://localhost:{port}"]
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    url_found = threading.Event()
    result: list[str] = []

    def _read_stderr():
        deadline = time.monotonic() + 60  # 60s timeout
        while time.monotonic() < deadline:
            line = process.stderr.readline()
            if not line:
                if process.poll() is not None:
                    break
                continue
            text = line.decode("utf-8", errors="replace").strip()
            match = re.search(r"https://[a-zA-Z0-9\-]+\.trycloudflare\.com", text)
            if match:
                result.append(match.group(0))
                url_found.set()
                return

    reader = threading.Thread(target=_read_stderr, daemon=True)
    reader.start()

    if url_found.wait(timeout=60):
        return result[0], process

    process.terminate()
    if process.poll() is None:
        process.wait(timeout=5)
    raise RuntimeError("Failed to start tunnel: could not find tunnel URL within 60 seconds")


def stop_tunnel(process: subprocess.Popen) -> None:
    """Gracefully terminate the cloudflared subprocess."""
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
