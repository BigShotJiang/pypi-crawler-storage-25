import shlex
import subprocess
import shutil
import sys


def _open_terminal(command: str, project_root: str) -> bool:
    """
    Open a new terminal window running `command` in `project_root`.
    Returns True if a terminal was launched, False if we fell back to printing.
    """
    if sys.platform == "darwin":
        script = f'tell application "Terminal" to do script "cd {shlex.quote(project_root)} && {command}"'
        subprocess.Popen(["osascript", "-e", script])
        return True

    if sys.platform.startswith("linux"):
        quoted = shlex.quote(project_root)
        for term, args in [
            ("gnome-terminal", ["--", "bash", "-c", f"cd {quoted} && {command}; exec bash"]),
            ("xfce4-terminal", ["-e", f"bash -c 'cd {quoted} && {command}; exec bash'"]),
            ("konsole", ["--noclose", "-e", "bash", "-c", f"cd {quoted} && {command}"]),
            ("xterm", ["-e", f"bash -c 'cd {quoted} && {command}; exec bash'"]),
        ]:
            if shutil.which(term):
                subprocess.Popen([term] + args)
                return True
        return False

    if sys.platform == "win32":
        # Windows Terminal (wt) or fallback to cmd
        if shutil.which("wt"):
            subprocess.Popen(["wt", "new-tab", "--title", "LetsWork",
                              "cmd", "/k", f"cd /d {project_root} && {command}"])
        else:
            subprocess.Popen(["cmd", "/c", "start", "cmd", "/k",
                              f"cd /d {project_root} && {command}"])
        return True

    return False


def _make_banner(mcp_url: str, token: str) -> str:
    """Shell command that prints the LetsWork banner then launches claude."""
    return (
        f"clear && "
        f"echo '╔══════════════════════════════════════════════════╗' && "
        f"echo '║  Claude Code — Connected to LetsWork             ║' && "
        f"echo '║                                                  ║' && "
        f"echo '║  MCP URL: {mcp_url}' && "
        f"echo '║  Token:   {token}' && "
        f"echo '║                                                  ║' && "
        f"echo '║  Try: list_files, read_file, write_file          ║' && "
        f"echo '╚══════════════════════════════════════════════════╝' && "
        f"echo '' && claude"
    )


def launch_claude_code(project_root: str, tunnel_url: str, token: str) -> None:
    """Open a new terminal window with Claude Code for the host."""
    if not shutil.which("claude"):
        print("⚠️  Claude Code not found. Install: npm install -g @anthropic-ai/claude-code")
        return

    mcp_url = f"{tunnel_url}/mcp"
    launched = _open_terminal(_make_banner(mcp_url, token), project_root)
    if not launched:
        print("Open a new terminal, cd to your project, and run: claude")


def register_guest_mcp(url: str, token: str) -> None:
    """Register LetsWork as a stdio proxy MCP with Claude Code (blocking).

    Uses stdio transport (always works) rather than HTTP transport (unreliable
    over Cloudflare SSE). The proxy forwards tool calls to the host via HTTP.
    """
    if not shutil.which("claude"):
        print("⚠️  Claude Code not found. Install: npm install -g @anthropic-ai/claude-code")
        return

    proxy_path = shutil.which("letswork-proxy")
    if not proxy_path:
        print("⚠️  letswork-proxy not found. Try: pip install --upgrade letswork")
        return

    # Remove any stale entry from all scopes
    for scope in ("user", "local", "project"):
        subprocess.run(
            ["claude", "mcp", "remove", "letswork", "--scope", scope],
            check=False, capture_output=True, text=True,
        )
    subprocess.run(
        [
            "claude", "mcp", "add", "letswork",
            "--scope", "user",
            "--", proxy_path, "--url", url, "--token", token,
        ],
        check=False, capture_output=True, text=True,
    )


def launch_guest_claude_code(project_root: str, url: str, token: str) -> None:
    """Open a new terminal window with Claude Code for the guest."""
    if not shutil.which("claude"):
        print("⚠️  Claude Code not found. Install: npm install -g @anthropic-ai/claude-code")
        return

    launched = _open_terminal(_make_banner(url, token), project_root)
    if not launched:
        print(f"\n✅ MCP registered. Now open a new terminal and run:")
        print(f"   cd {project_root} && claude")


