"""cklib — CKP v3.5 Python runtime for Concept Kernels.

Usage:
    from cklib import KernelProcessor, on, emit
    from cklib.urn import parse_urn, validate_urn, build_urn
    from cklib.instance import create_instance, seal_instance
    from cklib.dispatch import send_action
    from cklib.serve import KernelServer
    from cklib.auth import CKAuth
    from cklib.entities import EntityManager
    from cklib.actions import resolve_action_type, check_access
    from cklib.context import build_context
    from cklib.prov import ProvChain, Session, ActionRecord, verified_action, list_sessions, get_session
    from cklib.ledger import log_action, read_ledger
    from cklib.schema import load_schema, validate_instance, has_schema
    from cklib.capacity import check_capacity
"""
from cklib.processor import KernelProcessor
from cklib.events import on, emit
from cklib.entities import EntityManager
from cklib.actions import resolve_action_type, check_access
from cklib.context import build_context
from cklib.prov import ProvChain, Session, ActionRecord, verified_action, list_sessions, get_session
from cklib.ledger import log_action, read_ledger
from cklib.schema import load_schema, validate_instance, has_schema
from cklib.capacity import check_capacity

__version__ = "1.0.0"
__all__ = [
    "KernelProcessor", "on", "emit", "EntityManager",
    "resolve_action_type", "check_access",
    "build_context",
    "ProvChain", "Session", "ActionRecord", "verified_action",
    "list_sessions", "get_session",
    "log_action", "read_ledger",
    "load_schema", "validate_instance", "has_schema",
    "check_capacity",
]
