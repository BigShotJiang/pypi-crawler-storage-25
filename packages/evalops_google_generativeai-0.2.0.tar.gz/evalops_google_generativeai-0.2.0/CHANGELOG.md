# Changelog

## [0.2.0](https://github.com/evalops/evalops-google-generativeai/compare/evalops-google-generativeai-v0.1.0...evalops-google-generativeai-v0.2.0) (2026-04-29)


### Features

* add PyPI publish workflow ([872eb61](https://github.com/evalops/evalops-google-generativeai/commit/872eb6176a985f08e7c9bf9151122ce4078bad8b))


### Bug Fixes

* use bot token for release PRs ([efa8dec](https://github.com/evalops/evalops-google-generativeai/commit/efa8dec7624c0b8acc5c21e9256649f8f08c504e))
