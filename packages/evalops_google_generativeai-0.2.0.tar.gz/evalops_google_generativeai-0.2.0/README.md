# evalops-google-generativeai

Drop-in `google-generativeai` shim for stamping EvalOps organization scope,
principal attribution, trace IDs, and provider references onto Google
Generative AI calls.

This package is part of the G1 shim wedge from `evalops/platform#1133`. It
ships the Python package and conformance surface while `llm-gateway` grows
Google-native endpoint coverage.

## Python

```bash
pip install evalops-google-generativeai
```

```python
import evalops_google_generativeai as genai

genai.configure(
    organization_id="org_123",
    principal="user:ada@example.com",
)

model = genai.GenerativeModel("gemini-2.0-flash")
response = model.generate_content("hello")
```

## Environment

- `EVALOPS_API_KEY` or `GOOGLE_API_KEY`: Platform-issued bearer token.
- `EVALOPS_ORGANIZATION_ID`: organization scope stamped into requests.
- `EVALOPS_PRINCIPAL`: optional actor string for audit attribution.
- `EVALOPS_TRACE_ID`: optional trace correlation ID.
- `EVALOPS_LLM_GATEWAY_GOOGLE_URL`: Google-compatible gateway base URL.
- `EVALOPS_LLM_GATEWAY_URL`: fallback gateway base URL.
- `EVALOPS_PROVIDER_ENVIRONMENT`: defaults to `prod`.
- `EVALOPS_PROVIDER_CREDENTIAL_NAME`: optional provider ref credential name.
- `EVALOPS_PROVIDER_TEAM_ID`: optional provider ref team ID.

## Gateway Status

`llm-gateway` currently exposes OpenAI-compatible `/v1/chat/completions` and
`/v1/responses`. This shim establishes the Google package contract and metadata
injection layer; full import-only parity depends on gateway-side Google adapter
support.

