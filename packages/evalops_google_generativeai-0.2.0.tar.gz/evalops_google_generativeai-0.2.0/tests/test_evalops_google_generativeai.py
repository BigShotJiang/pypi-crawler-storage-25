import pytest

from evalops_google_generativeai import build_evalops_metadata, build_provider_ref


def test_metadata_stamp_org_and_principal() -> None:
    assert build_evalops_metadata(
        organization_id="org_123",
        principal="user:ada",
    ) == (
        ("x-organization-id", "org_123"),
        ("x-evalops-organization-id", "org_123"),
        ("x-evalops-principal", "user:ada"),
    )


def test_metadata_require_org() -> None:
    with pytest.raises(ValueError):
        build_evalops_metadata()


def test_default_provider_ref() -> None:
    assert build_provider_ref() == {
        "provider": "google-generativeai",
        "environment": "prod",
    }

