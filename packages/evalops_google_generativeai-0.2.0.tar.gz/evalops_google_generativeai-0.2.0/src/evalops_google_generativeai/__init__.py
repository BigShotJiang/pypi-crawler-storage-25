from __future__ import annotations

import os
import json
from collections.abc import Mapping
from typing import Any

import google.generativeai as _genai

DEFAULT_GATEWAY_BASE_URL = "https://llm-gateway.internal.evalops.dev"

ProviderRef = dict[str, str]


def _first_value(*values: str | None) -> str | None:
    return next((value for value in values if value and value.strip()), None)


def build_evalops_metadata(
    *,
    organization_id: str | None = None,
    principal: str | None = None,
    trace_id: str | None = None,
    default_metadata: tuple[tuple[str, str], ...] | None = None,
) -> tuple[tuple[str, str], ...]:
    org_id = _first_value(
        organization_id,
        os.getenv("EVALOPS_ORGANIZATION_ID"),
        os.getenv("EVALOPS_WORKSPACE_ID"),
    )
    if not org_id:
        raise ValueError("EVALOPS_ORGANIZATION_ID or organization_id is required")

    metadata = list(default_metadata or ())
    metadata.append(("x-organization-id", org_id))
    metadata.append(("x-evalops-organization-id", org_id))

    resolved_principal = _first_value(principal, os.getenv("EVALOPS_PRINCIPAL"))
    if resolved_principal:
        metadata.append(("x-evalops-principal", resolved_principal))

    resolved_trace_id = _first_value(trace_id, os.getenv("EVALOPS_TRACE_ID"))
    if resolved_trace_id:
        metadata.append(("x-evalops-trace-id", resolved_trace_id))

    return tuple(metadata)


def build_provider_ref(provider_ref: Mapping[str, str] | None = None) -> ProviderRef:
    provider_ref = provider_ref or {}
    result: ProviderRef = {
        "provider": provider_ref.get("provider") or "google-generativeai",
        "environment": provider_ref.get("environment")
        or os.getenv("EVALOPS_PROVIDER_ENVIRONMENT")
        or "prod",
    }
    credential_name = provider_ref.get("credential_name") or os.getenv(
        "EVALOPS_PROVIDER_CREDENTIAL_NAME"
    )
    if credential_name:
        result["credential_name"] = credential_name
    team_id = provider_ref.get("team_id") or os.getenv("EVALOPS_PROVIDER_TEAM_ID")
    if team_id:
        result["team_id"] = team_id
    return result


def configure(
    *,
    api_key: str | None = None,
    organization_id: str | None = None,
    principal: str | None = None,
    trace_id: str | None = None,
    evalops_base_url: str | None = None,
    provider_ref: Mapping[str, str] | None = None,
    client_options: Mapping[str, Any] | None = None,
    default_metadata: tuple[tuple[str, str], ...] | None = None,
    **kwargs: Any,
) -> None:
    options = dict(client_options or {})
    options.setdefault(
        "api_endpoint",
        evalops_base_url
        or os.getenv("EVALOPS_LLM_GATEWAY_GOOGLE_URL")
        or os.getenv("EVALOPS_LLM_GATEWAY_URL")
        or DEFAULT_GATEWAY_BASE_URL,
    )
    metadata = build_evalops_metadata(
        organization_id=organization_id,
        principal=principal,
        trace_id=trace_id,
        default_metadata=default_metadata,
    )
    metadata = metadata + (
        ("x-evalops-provider-ref", json.dumps(build_provider_ref(provider_ref), sort_keys=True)),
    )

    _genai.configure(
        api_key=api_key or os.getenv("EVALOPS_API_KEY") or os.getenv("GOOGLE_API_KEY"),
        client_options=options,
        default_metadata=metadata,
        **kwargs,
    )


def __getattr__(name: str) -> Any:
    return getattr(_genai, name)


__all__ = [
    "DEFAULT_GATEWAY_BASE_URL",
    "build_evalops_metadata",
    "build_provider_ref",
    "configure",
]
