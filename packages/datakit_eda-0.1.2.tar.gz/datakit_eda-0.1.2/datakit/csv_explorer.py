import pandas as pd
from typing import Optional, Union, Dict
from pathlib import Path
from pprint import pprint
from .utils import __read_parquet_nrows__

class CSVExplorer:

    """
    A lightweight utility class for exploring CSV and Parquet datasets.

    Supports quick loading, summarization, and exploratory data analysis (EDA)
    workflows with both programmatic outputs and optional pretty printing.
    """

    def __init__(
        self, 
        file_path: Union[str, Path]
    ):

        """
        Initialize the CSVExplorer.

        Args:
            file_path (Union[str, Path]): Path to the CSV or Parquet file.
        """

        if not isinstance(file_path, Path):
            file_path = Path(file_path)

        self.file_path = file_path
        self.df: Optional[pd.DataFrame] = None

    def load_data(
        self,
        nrows: Optional[int] = None
    ) -> pd.DataFrame:

        """
        Load data from CSV or Parquet file.

        Args:
            nrows (Optional[int]): Number of rows to load (only applies to CSV).

        Returns:
            pd.DataFrame: Loaded dataframe.

        Raises:
            RuntimeError: If file loading fails.
        """

        try:
            suffix = self.file_path.suffix.lower()
            assert suffix in [".parquet", ".csv"], f"Unsupported filetype: {suffix}"

            if suffix == ".parquet":

                if nrows is None:
                    self.df = pd.read_parquet(self.file_path)
                else:
                    self.df = __read_parquet_nrows__(self.file_path, nrows)

            else:
                self.df = pd.read_csv(self.file_path, nrows=nrows)

            return self.df

        except Exception as e:
            raise RuntimeError(f"Failed to load file: {e}")

    def basic_info(
        self
    ) -> Dict:

        """
        Get basic dataset information.

        Returns:
            Dict: Dictionary containing shape, dtypes, and memory usage.
        """
    
        self._check_loaded()

        return {
            "shape": self.df.shape,
            "dtypes": self.df.dtypes,
            "memory_usage": self.df.memory_usage(deep=True),
        }

    def preview(self, n: int = 5) -> Dict[str, pd.DataFrame]:

        """
        Get head and tail preview of dataset.

        Args:
            n (int): Number of rows for head and tail.

        Returns:
            Dict[str, pd.DataFrame]: Head and tail DataFrames.
        """

        self._check_loaded()

        return {
            "head": self.df.head(n),
            "tail": self.df.tail(n),
        }

    def missing_values(self) -> pd.DataFrame:

        """
        Compute missing values summary.

        Returns:
            pd.DataFrame: Missing count and percentage per column.
        """
        
        self._check_loaded()

        missing = self.df.isnull().sum()
        missing_pct = (missing / len(self.df)) * 100

        return pd.DataFrame({
            "missing_count": missing,
            "missing_percent": missing_pct,
        }).sort_values(by="missing_percent", ascending=False)

    def numerical_summary(
        self
    ) -> pd.DataFrame:

        """
        Generate descriptive statistics for numerical columns.

        Returns:
            pd.DataFrame: Summary statistics.
        """
     
        self._check_loaded()

        num_cols = self.df.select_dtypes(include=["int64", "float64"]).columns
        return self.df[num_cols].describe()

    def categorical_summary(
        self, 
        top_n: int = 5
    ) -> Dict[str, pd.Series]:
    
        """
        Get top value counts for categorical columns.

        Args:
            top_n (int): Number of top values to display per column.

        Returns:
            Dict[str, pd.Series]: Value counts per categorical column.
        """

        self._check_loaded()

        cat_cols = self.df.select_dtypes(include=["object", "category"]).columns

        result = {}
        for col in cat_cols:
            result[col] = self.df[col].value_counts().head(top_n)

        return result

    def unique_values(
        self
    ) -> Dict[str, int]:
     
        """
        Get number of unique values per column.

        Returns:
            Dict[str, int]: Column-wise unique counts.
        """

        self._check_loaded()

        return {col: self.df[col].nunique() for col in self.df.columns}

    def correlation(
        self
    ) -> pd.DataFrame:
     
        """
        Compute correlation matrix for numerical columns.

        Returns:
            pd.DataFrame: Correlation matrix.
        """
     
        self._check_loaded()
        return self.df.corr(numeric_only=True)

    def run_all(
        self
    ) -> Dict:
     
        """
        Run all EDA steps sequentially.

        Returns:
            Dict: Aggregated EDA outputs.
        """
     
        self.load_data()

        return {
            "basic_info": self.basic_info(),
            "preview": self.preview(),
            "missing": self.missing_values(),
            "numerical": self.numerical_summary(),
            "categorical": self.categorical_summary(),
            "unique": self.unique_values(),
            "correlation": self.correlation(),
        }

    def show_basic_info(
        self
    ):
        
        """Pretty print basic dataset information."""
        
        info = self.basic_info()

        def _header(title: str) -> None:
            title = str(title).strip()
            bar = "─" * max(12, len(title))
            print(f"\n{title}\n{bar}")

        _header("BASIC INFO")
        print(f"shape: {info['shape']}")

        _header("DTYPES")
        dtypes_df = info["dtypes"].rename("dtype").to_frame()
        with pd.option_context("display.max_rows", None, "display.max_columns", None):
            print(dtypes_df.to_string())

        _header("MEMORY USAGE (BY COLUMN)")
        mem_df = info["memory_usage"].rename("bytes").to_frame()
        with pd.option_context("display.max_rows", None, "display.max_columns", None):
            print(mem_df.to_string())

    def show_preview(
        self, 
        n: int = 5
    ):
        
        """Pretty print dataset preview."""
        
        preview = self.preview(n)

        def _header(title: str) -> None:
            title = str(title).strip()
            bar = "─" * max(12, len(title))
            print(f"\n{title}\n{bar}")

        with pd.option_context("display.max_rows", None, "display.max_columns", None):
            _header(f"PREVIEW (HEAD, n={n})")
            print(preview["head"].to_string())
            _header(f"PREVIEW (TAIL, n={n})")
            print(preview["tail"].to_string())

    def show_missing(
        self
    ):
     
        """Pretty print missing values summary."""
     
        missing = self.missing_values()

        title = "MISSING VALUES"
        bar = "─" * max(12, len(title))
        print(f"\n{title}\n{bar}")
        with pd.option_context("display.max_rows", None, "display.max_columns", None):
            print(missing.to_string())

    def show_numerical_summary(
        self
    ):
     
        """Pretty print numerical summary."""
     
        summary = self.numerical_summary()
        title = "NUMERICAL SUMMARY"
        bar = "─" * max(12, len(title))
        print(f"\n{title}\n{bar}")
        with pd.option_context("display.max_rows", None, "display.max_columns", None):
            print(summary.to_string())

    def show_categorical_summary(
        self, 
        top_n: int = 5
    ):
     
        """Pretty print categorical summary."""
     
        result = self.categorical_summary(top_n)

        title = f"CATEGORICAL SUMMARY (top_n={top_n})"
        bar = "─" * max(12, len(title))
        print(f"\n{title}\n{bar}")

        for col in sorted(result.keys(), key=str):
            values = result[col]
            col_title = f"COLUMN: {col}"
            col_bar = "─" * max(12, len(col_title))
            print(f"\n{col_title}\n{col_bar}")
            with pd.option_context("display.max_rows", None, "display.max_columns", None):
                print(values.to_string())

    def show_correlation(
        self
    ):
      
        """Pretty print correlation matrix."""
      
        corr = self.correlation()
        title = "CORRELATION MATRIX"
        bar = "─" * max(12, len(title))
        print(f"\n{title}\n{bar}")
        with pd.option_context("display.max_rows", None, "display.max_columns", None):
            print(corr.to_string())

    def _check_loaded(
        self
    ):
     
        """Ensure data is loaded before performing operations."""
     
        if self.df is None:
            raise ValueError("Data not loaded. Call load_data() first.")