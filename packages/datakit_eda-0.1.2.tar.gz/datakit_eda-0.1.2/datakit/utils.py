import pyarrow.parquet as pq
import pandas as pd

def __read_parquet_nrows__(
    parquet_filepath,
    nrows
):

    """
    Reads a parquet file only for given number of rows (nrows).
    
    """

    parquet_file = pq.ParquetFile(parquet_filepath)

    batches = []
    rows_read = 0

    for batch in parquet_file.iter_batches():
        
        batch_df = batch.to_pandas()
        batches.append(batch_df)

        rows_read += len(batch_df)

        if rows_read >= nrows:
            break
            
    return pd.concat(batches, ignore_index=True).iloc[:nrows]