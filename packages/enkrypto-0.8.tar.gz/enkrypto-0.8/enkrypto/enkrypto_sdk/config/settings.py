class ConfigValidator:
    REQUIRED_FIELDS = ["type", "endpoint", "api_key"]

    TYPE_FIELDS = {
        "json": ["path"],
        "csv": ["path"],
        "excel": ["path"],
        "mongo": ["uri", "db", "collection"],
        "sql": ["url"]
    }

    @classmethod
    def validate(cls, config):
        for field in cls.REQUIRED_FIELDS:
            if field not in config:
                raise ValueError(f"missing field: {field}")

        db_type = config.get("type")

        if db_type not in cls.TYPE_FIELDS:
            raise ValueError("unsupported type")

        for field in cls.TYPE_FIELDS[db_type]:
            if field not in config:
                raise ValueError(f"missing field for {db_type}: {field}")