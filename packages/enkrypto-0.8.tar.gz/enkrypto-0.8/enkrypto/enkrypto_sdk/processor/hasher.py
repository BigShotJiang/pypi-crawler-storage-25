import hashlib

def generate_hash(payload: str) -> str:
    return hashlib.sha256(payload.encode()).hexdigest()