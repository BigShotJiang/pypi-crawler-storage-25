import json

def canonicalize(data: dict) -> str:
    return json.dumps(data, sort_keys=True, separators=(",", ":"))