from .canonicalizer import canonicalize
from .hasher import generate_hash
from .chain import chain_hash

def verify_chain(events):
    prev_hash = "GENESIS"

    for event in events:
        canonical = canonicalize(event["data"])
        curr_hash = generate_hash(canonical)
        chained = chain_hash(prev_hash, curr_hash)

        if chained != event["chain_hash"]:
            return False

        prev_hash = chained

    return True