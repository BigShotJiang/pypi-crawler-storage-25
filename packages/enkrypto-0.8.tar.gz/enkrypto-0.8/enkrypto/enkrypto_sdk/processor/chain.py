from .hasher import generate_hash

def chain_hash(prev_hash: str, current_hash: str) -> str:
    combined = f"{prev_hash}:{current_hash}"
    return generate_hash(combined)