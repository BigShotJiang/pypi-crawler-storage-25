import asyncio
import threading

from enkrypto.enkrypto_sdk.processor.canonicalizer import canonicalize
from enkrypto.enkrypto_sdk.processor.hasher import generate_hash
from enkrypto.enkrypto_sdk.processor.chain import chain_hash
from enkrypto.enkrypto_sdk.transport.retry import RetryQueue
from enkrypto.enkrypto_sdk.utils.logger import get_logger


class Dispatcher:
    def __init__(self, client):
        self.client = client
        self.prev_hash = None
        self.retry = RetryQueue(client)
        self.logger = get_logger("Dispatcher")

        self.loop = asyncio.new_event_loop()

        threading.Thread(target=self._start_loop, daemon=True).start()

    def _start_loop(self):
        asyncio.set_event_loop(self.loop)
        self.loop.create_task(self.retry.worker())
        self.loop.run_forever()

    def handle_event(self, event):
        asyncio.run_coroutine_threadsafe(self.process(event), self.loop)

    async def process(self, event):
        # ensure chain starts properly (fix race condition)
        if self.prev_hash is None:
            self.prev_hash = "GENESIS"

        self.logger.info(f"event from {event['source']}")

        canonical = canonicalize(event["data"])
        curr_hash = generate_hash(canonical)
        chained = chain_hash(self.prev_hash, curr_hash)

        payload = {
            "data_hash": curr_hash,
            "prev_hash": self.prev_hash,
            "chain_hash": chained,
            "source": event["source"],
            "operation": event.get("operation", "update"),
            "timestamp": event["timestamp"]
        }

        # clean readable output in CLI
        print("\n--- EVENT ---")
        print(f"source: {event['source']}")
        print(f"operation: {event.get('operation', 'update')}")
        print(f"data_hash: {curr_hash}")
        print(f"chain_hash: {chained}")
        print(f"prev_hash: {self.prev_hash}")
        print("-------------\n")

        try:
            await self.client.send(payload)
            self.logger.info("sent")
        except Exception:
            self.logger.warning("retry queued")
            await self.retry.add(payload)

        # update chain
        self.prev_hash = chained