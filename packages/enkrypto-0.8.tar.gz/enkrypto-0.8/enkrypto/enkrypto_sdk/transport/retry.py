import asyncio

class RetryQueue:
    def __init__(self, client):
        self.client = client
        self.queue = asyncio.Queue()

    async def add(self, payload):
        await self.queue.put(payload)

    async def worker(self):
        while True:
            payload = await self.queue.get()
            try:
                await self.client.send(payload)
            except Exception:
                await asyncio.sleep(2)
                await self.queue.put(payload)