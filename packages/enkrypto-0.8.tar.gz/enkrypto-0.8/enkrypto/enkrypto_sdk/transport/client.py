import httpx

class EnkryptoClient:
    def __init__(self, endpoint, api_key):
        self.endpoint = endpoint
        self.api_key = api_key

    async def send(self, payload: dict):
        async with httpx.AsyncClient() as client:
            await client.post(
                self.endpoint,
                json=payload,
                headers={"Authorization": f"Bearer {self.api_key}"}
            )

    async def get_chain_head(self):
        async with httpx.AsyncClient() as client:
            res = await client.get(
                f"{self.endpoint}/head",
                headers={"Authorization": f"Bearer {self.api_key}"}
            )
            return res.json().get("chain_hash", "GENESIS")