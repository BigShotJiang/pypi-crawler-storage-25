import pandas as pd
import time
import os
from .base import BaseAdapter

class ExcelAdapter(BaseAdapter):
    def __init__(self, config):
        super().__init__(config)
        self.file_path = config["path"]
        self.last_modified = None

    def connect(self):
        if not os.path.exists(self.file_path):
            raise FileNotFoundError("excel file not found")
        self.last_modified = os.path.getmtime(self.file_path)

    def watch(self, callback):
        while True:
            current_modified = os.path.getmtime(self.file_path)

            if current_modified != self.last_modified:
                self.last_modified = current_modified

                df = pd.read_excel(self.file_path)
                data = df.to_dict(orient="records")

                event = {
                    "source": "excel",
                    "operation": "update",
                    "data": data,
                    "timestamp": time.time()
                }

                callback(event)

            time.sleep(1)