import json
import time
import os
from .base import BaseAdapter

class JSONAdapter(BaseAdapter):
    def __init__(self, config):
        super().__init__(config)
        self.file_path = config["path"]
        self.last_modified = None

    def connect(self):
        if not os.path.exists(self.file_path):
            raise FileNotFoundError("json file not found")
        self.last_modified = os.path.getmtime(self.file_path)

    def watch(self, callback):
        while True:
            current_modified = os.path.getmtime(self.file_path)

            if current_modified != self.last_modified:
                self.last_modified = current_modified

                with open(self.file_path, "r") as f:
                    data = json.load(f)

                event = {
                    "source": "json",
                    "operation": "update",
                    "data": data,
                    "timestamp": time.time()
                }

                callback(event)

            time.sleep(1)