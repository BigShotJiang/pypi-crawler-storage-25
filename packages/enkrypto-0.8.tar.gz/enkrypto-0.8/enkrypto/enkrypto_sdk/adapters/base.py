class BaseAdapter:
    def __init__(self, config):
        self.config = config

    def connect(self):
        raise NotImplementedError

    def watch(self, callback):
        raise NotImplementedError