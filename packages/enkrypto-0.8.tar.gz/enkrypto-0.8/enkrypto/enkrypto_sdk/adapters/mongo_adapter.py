import time
from pymongo import MongoClient
from .base import BaseAdapter

class MongoAdapter(BaseAdapter):
    def __init__(self, config):
        super().__init__(config)
        self.uri = config["uri"]
        self.db_name = config["db"]
        self.collection_name = config["collection"]
        self.client = None
        self.collection = None

    def connect(self):
        self.client = MongoClient(self.uri)
        db = self.client[self.db_name]
        self.collection = db[self.collection_name]

    def watch(self, callback):
        with self.collection.watch() as stream:
            for change in stream:
                event = {
                    "source": "mongo",
                    "operation": change["operationType"],
                    "data": change.get("fullDocument", {}),
                    "timestamp": time.time()
                }

                callback(event)