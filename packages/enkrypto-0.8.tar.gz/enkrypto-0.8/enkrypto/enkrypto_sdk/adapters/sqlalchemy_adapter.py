import time
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from sqlalchemy import event
from .base import BaseAdapter
import asyncio

class SQLAlchemyAdapter(BaseAdapter):
    def __init__(self, config):
        super().__init__(config)
        self.db_url = config["url"]
        self.engine = None
        self.Session = None

    def connect(self):
        self.engine = create_async_engine(self.db_url, echo=False)
        self.Session = async_sessionmaker(self.engine, expire_on_commit=False)

    def watch(self, callback):
        @event.listens_for(self.Session.sync_session_class, "after_flush")
        def after_flush(session, flush_context):
            for instance in session.new.union(session.dirty):
                data = {
                    k: v for k, v in instance.__dict__.items()
                    if not k.startswith("_")
                }

                event_data = {
                    "source": "sql",
                    "operation": "update",
                    "data": data,
                    "timestamp": time.time()
                }

                callback(event_data)