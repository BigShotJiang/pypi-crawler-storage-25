import numpy as np
from typing import Tuple, List, Literal
from numpy import ndarray
from pandas import DataFrame
from joblib import Parallel, delayed
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import warnings

def _bound(value: float, range: Tuple[float, float]) -> float:
    """Bound a value between two values
    
    Args:
        range (Tuple[float, float]): The lower and upper bounds
        value (float): The value to bound
    
    Returns:
        float: The bounded value
    
    Example:
    >>> _bound(0.5,(0, 1))
    0.5
    """
    low, high = range
    return max(low, min(high, value))

def PCAMetric(data_base: ndarray | DataFrame, data_comp: ndarray | DataFrame, num_components: int = None, normalization: Literal['precise', 'approx'] = 'precise',  preprocess: Literal['std', 'mean'] = 'std') -> Tuple[dict, ndarray, ndarray]:
    """Function for claculating the difference in eigenvalues and eigenvectors 
    of the principal components of the two datasets.
    
    Args:
        data_base (array | DataFrame): The original data to use as a base
        data_comp (array | DataFrame): The data that are being compared to the base
        num_components (int): int, the number of components to consider for explained variance difference (default is all)
        normalization (Literal['precise', 'approx']): The normalization method used
            'precise': use the normalization factor as mentioned in the paper = d/(d+p-2)
            'approx': set the normalizaton factor to 0.5
        preprocess (Literal['std', 'mean']): The type of preprocessing to use
            'std': rescale by dividing standard deviation (default) 
            'mean': mean-subtracted data
    
    Returns:
        Dict[str, float]: The results of the comparison (explained variance difference and component angle difference)
        array: the projection of the base data
        array: the projection of the comparison data

    Example:
    >>> import pandas as pd
    >>> from sklearn.datasets import load_iris
    >>> iris = load_iris()
    >>> X = pd.DataFrame(iris.data, columns=iris.feature_names)
    >>> results, r_pca, f_pca = PCAMetric(X, X)
    >>> results['exp_var_diff']
    0.0
    >>> results['comp_angle_diff']
    0.0
    """
    if num_components is None:
        num_components = data_base.shape[1]
    if data_base.shape[1] == 1:
        raise ValueError("Cannot use a dataset with d = 1.")
    if num_components > data_base.shape[1]:
        warnings.warn("Number of principal components is set to a value larger than d. Automatically setting it to d.", UserWarning)
        num_components = data_base.shape[1]
    match normalization:
        case 'precise':
            factor = data_base.shape[1] / (data_base.shape[1] + num_components - 2)
        case 'approx':
            factor = 0.5
        case _:
            raise ValueError("Invalid normalization keyword")
            
    match preprocess:
        case 'std':
            b_scaled = StandardScaler().fit_transform(data_base)
            c_scaled = StandardScaler().fit_transform(data_comp)
        case 'mean':
            b_scaled = data_base - np.mean(data_base, axis=0)
            c_scaled = data_comp - np.mean(data_comp, axis=0)
        case _:
            raise ValueError("Invalid scaling keyword")

    b_pca = PCA(n_components=num_components)
    c_pca = PCA(n_components=num_components)

    b_proj = b_pca.fit_transform(b_scaled)
    c_proj = c_pca.fit_transform(c_scaled)

    var_difference = factor * sum(abs(b_pca.explained_variance_ratio_- c_pca.explained_variance_ratio_))

    # len_b = np.sqrt(b_pca.components_[0].dot(b_pca.components_[0]))
    # len_c = np.sqrt(c_pca.components_[0].dot(c_pca.components_[0]))

    angle_diff = min([np.arccos(_bound(b_pca.components_[0] @ (s*c_pca.components_[0]),(-1,1))) for s in [1,-1]])#/(len_r*len_f)

    results = {'exp_var_diff': var_difference, 'comp_angle_diff': (angle_diff*2)/np.pi}
    return results, b_proj, c_proj


def _calc_single_aad(p, X_scaled, base_vector, solver, num_components):
    """Helper function to calculate AAD for a single dropped feature."""
    X_comp = X_scaled.copy()
    X_comp[:, p] = 0 
    
    comp_pca = PCA(n_components=num_components, svd_solver=solver)
    comp_pca.fit(X_comp)
    
    # Calculate angle difference
    dot_product = np.dot(base_vector, comp_pca.components_[0])
    # Using np.clip as a replacement for the custom _bound function
    angle_diff = np.arccos(np.clip(abs(dot_product), 0, 1))
    
    return (angle_diff * 2) / np.pi


def AAD(X: DataFrame, selected_features: list, num_components: int = 1, n_jobs: int = -1) -> float:
    """
    Function for calculating the average angle difference using parallel processing.
    
    Args:
        X: The full dataset
        selected_features: List of selected feature names or indices
        num_components: Number of PCA components
        n_jobs: Number of CPU cores to use. -1 uses all, 1 is sequential.
    """
    n_samples, n_features = X.shape
    
    # Index resolution logic
    if all(isinstance(f, str) for f in selected_features):
        selected_indices = [X.columns.get_loc(f) for f in selected_features]
    else:
        selected_indices = selected_features
        
    not_selected_indices = [i for i in range(n_features) if i not in selected_indices]
    
    if not not_selected_indices:
        return 0.0

    solver = 'randomized' if (max(n_samples, n_features)) > 500 else 'full'

    # Pre-scale once to avoid redundant work in workers
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Calculate global base vector
    base_pca = PCA(n_components=num_components, svd_solver=solver)
    base_pca.fit(X_scaled)
    base_vector = base_pca.components_[0]

    # Parallel Switch: 
    # Parallel(n_jobs=n_jobs) handles the logic of 1 core vs many cores.
    results = Parallel(n_jobs=n_jobs)(
        delayed(_calc_single_aad)(p, X_scaled, base_vector, solver, num_components) 
        for p in not_selected_indices
    )

    return sum(results) / len(not_selected_indices)


if __name__ == "__main__":
    import doctest
    doctest.testmod()