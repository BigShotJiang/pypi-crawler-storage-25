import argparse
import requests
import sys
import json
import os
from dotenv import load_dotenv

load_dotenv()

SERVER_URL = os.getenv("PROXY_SERVER_URL", "https://provider-proxy-server-production.up.railway.app")

SESSION_FILE = os.path.expanduser("~/.republic_session.json")

def load_session():
    if os.path.exists(SESSION_FILE):
        with open(SESSION_FILE, "r") as f:
            return json.load(f)
    return {}

def save_session(wallet, pubkey, sig, hex=None):
    with open(SESSION_FILE, "w") as f:
        json.dump({"wallet": wallet, "pubkey": pubkey, "signature": sig, "wallet_hex": hex}, f)

def main():
    # Common auth arguments
    auth_parser = argparse.ArgumentParser(add_help=False)
    auth_parser.add_argument("--auth-wallet", help="Ethereum-compatible bech32 address (ethsecp256k1)", required=False)
    auth_parser.add_argument("--auth-wallet-hex", help="Ethereum hex address", required=False)
    auth_parser.add_argument("--auth-pubkey", help="Ethereum-compatible public key (base64)", required=False)
    auth_parser.add_argument("--auth-sig", help="Ethereum-compatible signature (base64)", required=False)

    parser = argparse.ArgumentParser(description="Republic Compute Proxy CLI")
    # Still allow at root level
    parser.add_argument("--auth-wallet", help=argparse.SUPPRESS)
    parser.add_argument("--auth-wallet-hex", help=argparse.SUPPRESS)
    parser.add_argument("--auth-pubkey", help=argparse.SUPPRESS)
    parser.add_argument("--auth-sig", help=argparse.SUPPRESS)
    
    subparsers = parser.add_subparsers(dest="command", required=True, help="Host management actions")
    
    # 1. Login
    sp_login = subparsers.add_parser("login", parents=[auth_parser], help="Authenticate and save session locally")

    # 2. Auth Verify
    sp_auth = subparsers.add_parser("auth-verify", parents=[auth_parser], help="Verify credentials with the proxy server")

    # 3. Install Provider Machine
    sp_install = subparsers.add_parser("install", parents=[auth_parser], help="Register a new provider machine")
    sp_install.add_argument("--provider-slug", default="vast", help="Slug of the provider (e.g. vast)")

    # 4. Host Metrics
    sp_metrics = subparsers.add_parser("host-metrics", parents=[auth_parser], help="View earnings and metrics for your hosted machines")

    # 5. Host Update
    sp_update = subparsers.add_parser("host-update", parents=[auth_parser], help="Update your hosted machine (e.g., set rental price)")
    sp_update.add_argument("--machine-id", required=True, help="Your Host Machine ID")
    sp_update.add_argument("--price-gpu", type=float, help="GPU Price ($/hr)")
    sp_update.add_argument("--price-disk", type=float, help="Disk Price ($/hr)")

    # 6. Generate Test Credentials
    sp_gen = subparsers.add_parser("generate-test-credentials", help="Generate a new ethsecp256k1 test wallet and signature")
    
    args = parser.parse_args()
    
    session = load_session()
    auth_wallet = args.auth_wallet or session.get("wallet")
    auth_pubkey = args.auth_pubkey or session.get("pubkey")
    auth_sig = args.auth_sig or session.get("signature")
    auth_wallet_hex = args.auth_wallet_hex or session.get("wallet_hex")

    if args.command == "login":
        if not auth_wallet or not auth_pubkey or not auth_sig:
            print("Missing authentication material! Provide --auth-wallet, --auth-pubkey, and --auth-sig.", file=sys.stderr)
            sys.exit(1)
        save_session(auth_wallet, auth_pubkey, auth_sig, auth_wallet_hex)
        print(f"Session saved successfully for wallet {auth_wallet} at {SESSION_FILE}")
        sys.exit(0)

    if args.command == "generate-test-credentials":
        import ecdsa
        import base64
        import bech32
        import hashlib
        from eth_hash.auto import keccak

        # 1. Generate private key
        sk = ecdsa.SigningKey.generate(curve=ecdsa.SECP256k1)
        vk = sk.get_verifying_key()
        
        # 2. Get uncompressed pubkey (64 bytes)
        pubkey_bytes = vk.to_string() # 64 bytes
        pubkey_b64 = base64.b64encode(pubkey_bytes).decode('utf-8')
        
        # 3. Derive address (last 20 bytes of keccak256(uncompressed_pubkey))
        pubkey_hash = keccak(pubkey_bytes)[-20:]
        
        # 4. Encode to bech32 (republic1...)
        five_bit_words = bech32.convertbits(pubkey_hash, 8, 5)
        wallet_bech32 = bech32.bech32_encode("republic", five_bit_words)
        wallet_hex = "0x" + pubkey_hash.hex()
        
        # 5. Sign "republic-verify"
        message = "republic-verify"
        msg_hash = keccak(message.encode('utf-8'))
        sig = sk.sign_digest(msg_hash)
        sig_b64 = base64.b64encode(sig).decode('utf-8')
        
        print("\n=== Test Credentials Generated ===")
        print(f"Wallet (Bech32): {wallet_bech32}")
        print(f"Wallet (Hex):    {wallet_hex}")
        print(f"Public Key (b64): {pubkey_b64}")
        print(f"Signature (b64):  {sig_b64}")
        print(f"Message Signed:   {message}")
        print("\nTo login with these credentials, run:")
        print(f"raicompute login --auth-wallet {wallet_bech32} --auth-pubkey {pubkey_b64} --auth-sig {sig_b64}")
        print("==================================\n")
        sys.exit(0)

    # Commands below this point require authentication
    if not auth_wallet or not auth_pubkey or not auth_sig:
        print("Missing authentication material! Provide --auth-wallet, --auth-pubkey, --auth-sig or use 'login'.", file=sys.stderr)
        sys.exit(1)
    
    if args.command == "install":
        import subprocess
        install_script_path = os.path.join(os.path.dirname(__file__), "providers", "install.py")
        cmd = [
            sys.executable, install_script_path,
            "--auth-wallet", auth_wallet,
            "--auth-pubkey", auth_pubkey,
            "--auth-sig", auth_sig,
            "--provider-slug", args.provider_slug
        ]
        try:
            subprocess.run(cmd, check=True)
        except subprocess.CalledProcessError as e:
            print(f"Install script failed with exit code {e.returncode}", file=sys.stderr)
            sys.exit(e.returncode)
        sys.exit(0)
        
    params = {}
    if args.command == "host-update":
        params["machine_id"] = args.machine_id
        updates = {}
        if args.price_gpu is not None:
            updates["price_gpu"] = args.price_gpu
        if args.price_disk is not None:
            updates["price_disk"] = args.price_disk
        params["updates"] = updates
    
    payload = {
        "action": args.command,
        "params": params,
        "auth": {
            "wallet": auth_wallet,
            "wallet_hex": auth_wallet_hex,
            "pubkey": auth_pubkey,
            "signature": auth_sig
        }
    }
    
    try:
        response = requests.post(f"{SERVER_URL}/api/compute", json=payload)
        
        if response.status_code == 200:
            result = response.json()
            if "output" in result:
                if isinstance(result["output"], (dict, list)):
                    print(json.dumps(result["output"], indent=2))
                else:
                    print(result["output"])
            else:
                print(json.dumps(result, indent=2))
        else:
            print(f"Error ({response.status_code}):", response.text, file=sys.stderr)
            sys.exit(1)
            
    except requests.exceptions.RequestException as e:
        print(f"Connection error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
