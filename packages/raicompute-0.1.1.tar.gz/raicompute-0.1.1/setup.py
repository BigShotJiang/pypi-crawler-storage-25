from setuptools import setup, find_packages

setup(
    name="raicompute",
    version="0.1.0",
    packages=find_packages(),
    py_modules=["cli"],
    install_requires=[
        "pydantic",
        "requests",
        "bech32",
        "ecdsa",
        "eth-hash[pycryptodome]",
        "python-dotenv"
    ],
    entry_points={
        "console_scripts": [
            "raicompute=cli:main"
        ]
    },
    author="Republic Protocol",
    description="Republic Proxy Command Line Interface",
)
