# Republic Compute CLI

The Republic Compute CLI (`raicompute`) is a lightweight, stateless interface for **GPU providers** to register and manage their hosted machines on the Republic network, using Ethereum-compatible (ethsecp256k1) wallet authentication.

> This tool is exclusively for **GPU hosts** — operators who are contributing compute resources to the network. It is not a tool for renting or consuming compute.

## Installation

```bash
pip install raicompute
```

This will install the CLI under the `raicompute` command.

## Authentication & Session Management

The CLI uses Ethereum-compatible ECDSA signatures (ethsecp256k1) for authentication. To avoid passing credentials with every command, use the `login` command to save your session locally.

### Login
Saves your wallet address, public key, and signature to `~/.republic_session.json`.

```bash
raicompute login --auth-wallet <bech32_address> --auth-pubkey <base64_pubkey> --auth-sig <base64_signature>
```

**Example:**
```bash
raicompute login \
  --auth-wallet republic1h9p5vxyurq7p0kqw... \
  --auth-pubkey BKj3v5U9... \
  --auth-sig 3045022100...
```

Once logged in, all subsequent commands will automatically use these credentials.

### Auth Verify
Diagnostic tool to verify your current authentication session with the proxy server.

```bash
raicompute auth-verify
```

### Generate Test Credentials
Utility for developers to generate a valid `ethsecp256k1` wallet and signature for testing.

```bash
raicompute generate-test-credentials
```

---

## Host Commands

These commands are for operators who are hosting GPU machines on the network.

### Install Provider Machine
Registers your machine with the proxy server, linking it to your wallet for earnings tracking. This command is typically called by the automated install script.

```bash
raicompute install [--provider-slug vast]
```

### Host Metrics
View earnings, reliability, and active rental status for machines registered to your wallet.

```bash
raicompute host-metrics
```

### Host Update
Update settings for your hosted machine, such as rental prices.

```bash
raicompute host-update --machine-id <id> [--price-gpu <float>] [--price-disk <float>]
```

---

## Environment Variables

| Variable | Description |
|---|---|
| `PROXY_SERVER_URL` | URL of the Republic Proxy Server (default: `https://provider-proxy-server-production.up.railway.app`) |
