from setuptools import setup, find_packages

setup(
    name="kinu-ai",
    version="1.8.0",
    author="Alex Kinuthia",
    author_email="bettalex33@gmail.com",
    description="Local AI assistant with screen awareness, document reading, web search, voice, and persistent memory",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/bettalex33-prog/ai-cli-chatbot",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "kinu-ai=kinu_ai.chatbot:main",
        ],
    },
    python_requires=">=3.10",
    install_requires=[
        "requests",
        "ollama",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
