import{c as o}from"./index-K40M3dDH.js";const t=[["path",{d:"M17 7 7 17",key:"15tmo1"}],["path",{d:"M17 17H7V7",key:"1org7z"}]],r=o("arrow-down-left",t);export{t as __iconNode,r as default};
