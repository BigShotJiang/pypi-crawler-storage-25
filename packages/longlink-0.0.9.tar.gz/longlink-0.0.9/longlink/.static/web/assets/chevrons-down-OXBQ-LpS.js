import{c as o}from"./index-K40M3dDH.js";const e=[["path",{d:"m7 6 5 5 5-5",key:"1lc07p"}],["path",{d:"m7 13 5 5 5-5",key:"1d48rs"}]],n=o("chevrons-down",e);export{e as __iconNode,n as default};
