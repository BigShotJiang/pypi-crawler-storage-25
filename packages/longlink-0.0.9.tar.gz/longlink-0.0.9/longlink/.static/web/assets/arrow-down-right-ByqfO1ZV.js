import{c as o}from"./index-K40M3dDH.js";const t=[["path",{d:"m7 7 10 10",key:"1fmybs"}],["path",{d:"M17 7v10H7",key:"6fjiku"}]],e=o("arrow-down-right",t);export{t as __iconNode,e as default};
