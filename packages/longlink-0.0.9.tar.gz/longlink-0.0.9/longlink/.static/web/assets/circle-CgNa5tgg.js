import{c}from"./index-K40M3dDH.js";const e=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],r=c("circle",e);export{e as __iconNode,r as default};
