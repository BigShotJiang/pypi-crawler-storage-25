# fb_scraper_request

Scrape public Facebook posts without login. Simple requests-based scraper.

## Example

```python
from fb_scraper_request import FacebookGraphqlScraper

fb = FacebookGraphqlScraper()
result = fb.get_user_posts("honghotduongpho.official00", days_limit=3)

for post in result["data"]:
    print(post["context"])
    print(f"Likes: {post['reaction_count.count']}")
```

Install: `pip install fb_scraper_request`
