import asyncio
from datetime import timedelta

import a2s
from nonebot import on_message
from nonebot.adapters.onebot.v11 import Bot, GroupMessageEvent, Message
from nonebot.exception import FinishedException
from nonebot.log import logger
from nonebot.params import EventMessage
from nonebot.rule import keyword

from .config import config


player_query = on_message(rule=keyword("!players"), priority=10, block=True)
A2STimeoutException = getattr(
    getattr(a2s, "exceptions", None),
    "TimeoutException",
    TimeoutError,
)


@player_query.handle()
async def handle_players(
    _bot: Bot, event: GroupMessageEvent, _msg: Message = EventMessage()
) -> None:
    if event.group_id not in config.qq_group_ids:
        return

    plain_text = event.get_plaintext().strip()
    if "!players" not in plain_text:
        return

    if not config.server_host:
        await player_query.finish("未配置 CS2_SERVER_HOST，无法查询在线玩家")

    await player_query.send("查询中，请稍等...")

    try:
        address = (config.server_host, config.query_port)
        info = await asyncio.to_thread(a2s.info, address, timeout=3.0, encoding="utf-8")
        players = await asyncio.to_thread(
            a2s.players,
            address,
            timeout=3.0,
            encoding="utf-8",
        )

        if not players:
            await player_query.finish("服务器当前无人在线")

        t_players: list[str] = []
        ct_players: list[str] = []
        other_players: list[str] = []

        for player in players:
            name = (player.name or "").strip() or "无名氏"
            steamid = "未知"
            duration_seconds = int(getattr(player, "duration", 0) or 0)
            duration = str(timedelta(seconds=duration_seconds))
            item = f"{name} | {steamid} | {duration}"

            team = getattr(player, "team", None)
            if team == 2:
                t_players.append(item)
            elif team == 3:
                ct_players.append(item)
            else:
                other_players.append(item)

        reply = [
            f"【CS2服务器在线玩家】 {len(players)}/{getattr(info, 'max_players', '?')}",
        ]

        if t_players:
            reply.append("T 队伍：")
            reply.extend(t_players)

        if ct_players:
            reply.append("CT 队伍：")
            reply.extend(ct_players)

        if other_players:
            reply.append("其他/观察者：")
            reply.extend(other_players)

        await player_query.finish("\n".join(reply))
    except FinishedException:
        raise
    except A2STimeoutException:
        await player_query.finish("服务器已断开连接，请联系服主检查服务器状态")
    except Exception as exception:  # noqa: BLE001
        logger.error("查询玩家失败: {}", exception)
        await player_query.finish("查询出错，请稍后再试或联系服主")
