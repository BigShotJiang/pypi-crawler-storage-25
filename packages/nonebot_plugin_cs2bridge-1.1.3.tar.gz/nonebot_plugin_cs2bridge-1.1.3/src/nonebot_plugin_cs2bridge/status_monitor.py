import asyncio
from typing import Optional

import a2s
from nonebot import get_driver
from nonebot.log import logger

from .config import config
from .sender import send_status_to_all_groups


driver = get_driver()
last_online: Optional[bool] = None
last_map = ""
last_players = ""
status_checker_task: Optional[asyncio.Task[None]] = None
A2STimeoutException = getattr(
    getattr(a2s, "exceptions", None),
    "TimeoutException",
    TimeoutError,
)


async def check_server_status() -> None:
    global last_online, last_map, last_players

    if not config.server_host:
        return

    address = (config.server_host, config.query_port)

    try:
        info = await asyncio.to_thread(a2s.info, address, 3.0, "utf-8")
        current_map = getattr(info, "map_name", "") or "未知"
        current_players = (
            f"{getattr(info, 'player_count', '?')}/{getattr(info, 'max_players', '?')}"
        )

        if last_online is False:
            message = (
                "【服务器上线】 CS2 服务器已恢复在线！\n"
                f"当前地图：{current_map}\n"
                f"在线：{current_players}"
            )
            await send_status_to_all_groups(message)
        elif last_online is None:
            logger.info("服务器状态首次探测为在线，跳过首次通知")

        last_online = True
        last_map = current_map
        last_players = current_players
    except A2STimeoutException:
        if last_online is True:
            await send_status_to_all_groups(
                "【服务器下线】 CS2 服务器已断开连接，请服主检查状态"
            )
        elif last_online is None:
            logger.info("服务器状态首次探测为离线，跳过首次通知")

        last_online = False
    except Exception as exception:  # noqa: BLE001
        logger.warning("服务器状态轮询异常: {}", exception)
        if last_online is True:
            await send_status_to_all_groups(
                "【服务器下线】 CS2 服务器已断开连接，请服主检查状态"
            )
        elif last_online is None:
            logger.info("服务器状态首次探测异常，暂不推送")

        last_online = False


async def status_checker_loop() -> None:
    while True:
        await check_server_status()
        await asyncio.sleep(config.status_interval)


@driver.on_startup
async def _start_status_checker() -> None:
    global status_checker_task

    if status_checker_task is not None and not status_checker_task.done():
        return

    status_checker_task = asyncio.create_task(status_checker_loop())
    logger.info("CS2 服务器状态轮询任务已启动，间隔 {} 秒", config.status_interval)


@driver.on_shutdown
async def _stop_status_checker() -> None:
    global status_checker_task

    if status_checker_task is None:
        return

    status_checker_task.cancel()
    try:
        await status_checker_task
    except asyncio.CancelledError:
        pass
    finally:
        status_checker_task = None
