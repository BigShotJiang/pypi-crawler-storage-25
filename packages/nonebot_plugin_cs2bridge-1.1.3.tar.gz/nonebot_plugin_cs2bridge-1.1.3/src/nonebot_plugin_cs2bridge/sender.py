from typing import Optional

from nonebot import get_bots
from nonebot.adapters.onebot.v11 import Bot as OneBotV11Bot
from nonebot.log import logger

from .config import config


def _get_onebot_v11_bot() -> Optional[OneBotV11Bot]:
    for bot in get_bots().values():
        if isinstance(bot, OneBotV11Bot):
            return bot
    return None


async def send_event_to_groups(event: str, message: str) -> None:
    if not config.qq_group_ids:
        logger.warning("没有配置任何 QQ 群号，跳过发送")
        return

    bot = _get_onebot_v11_bot()
    if bot is None:
        logger.warning("[cs2bridge] no active OneBot V11 bot for sending")
        return

    for group_id in config.qq_group_ids:
        try:
            await bot.send_group_msg(group_id=group_id, message=message)
            logger.info("事件 {} 已发送到群 {} (bot={})", event, group_id, bot.self_id)
        except Exception as exception:  # noqa: BLE001
            logger.error(
                "发送群消息失败 group={} bot={}: {}",
                group_id,
                bot.self_id,
                exception,
            )


async def send_status_to_all_groups(message: str) -> None:
    if not config.qq_group_ids:
        logger.warning("未配置 qq_group_ids，跳过服务器状态推送")
        return

    bot = _get_onebot_v11_bot()
    if bot is None:
        logger.warning("[cs2bridge] status push skipped, no active OneBot V11 bot")
        return

    for group_id in config.qq_group_ids:
        try:
            await bot.send_group_msg(group_id=group_id, message=message)
            logger.info("服务器状态推送成功 -> 群 {} (bot={})", group_id, bot.self_id)
        except Exception as exception:  # noqa: BLE001
            logger.error(
                "推送失败 -> 群 {} bot={} : {}", group_id, bot.self_id, exception
            )
