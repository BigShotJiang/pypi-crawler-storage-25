from nonebot.log import logger
from nonebot.plugin import PluginMetadata

from .config import Config, config
from .players_command import player_query as player_query
from .status_monitor import check_server_status as check_server_status
from .webhook import cs2bridge_webhook as cs2bridge_webhook

__plugin_meta__ = PluginMetadata(
    name="CS2 Bridge",
    description="CS2 服务器与 QQ 群桥接插件（事件推送、玩家查询等）",
    homepage="https://github.com/Akiyy-hub/nonebot-plugin-cs2bridge",
    usage="发送 !players 查询在线玩家；通过 webhook 接收 CS2 事件。",
    config=Config,
    supported_adapters={"~onebot.v11"},
    type="application",
)

logger.info("[cs2bridge] plugin initialized, groups={}", config.qq_group_ids)
