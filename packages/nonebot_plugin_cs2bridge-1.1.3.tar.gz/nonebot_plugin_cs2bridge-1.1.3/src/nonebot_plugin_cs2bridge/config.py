from pydantic import BaseModel, Field

from nonebot import get_plugin_config


class Config(BaseModel):
    cs2_qq_group_ids: list[int] = Field(default_factory=list)
    cs2_webhook_secret: str = ""
    cs2_webhook_path: str = "/cs2/event"

    cs2_server_host: str = ""
    cs2_query_port: int = 27015
    cs2_status_interval: int = Field(default=45, ge=30, le=60)

    cs2_rcon_host: str = ""
    cs2_rcon_port: int = 27015
    cs2_rcon_password: str = ""

    @property
    def qq_group_ids(self) -> list[int]:
        return self.cs2_qq_group_ids

    @property
    def webhook_secret(self) -> str:
        return self.cs2_webhook_secret

    @property
    def webhook_path(self) -> str:
        return self.cs2_webhook_path

    @property
    def server_host(self) -> str:
        return self.cs2_server_host

    @property
    def query_port(self) -> int:
        return self.cs2_query_port

    @property
    def status_interval(self) -> int:
        return self.cs2_status_interval

    @property
    def rcon_host(self) -> str:
        return self.cs2_rcon_host

    @property
    def rcon_port(self) -> int:
        return self.cs2_rcon_port

    @property
    def rcon_password(self) -> str:
        return self.cs2_rcon_password


config = get_plugin_config(Config)
