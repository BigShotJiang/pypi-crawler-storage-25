import time
from asyncio import Lock
from typing import Any, Optional

from nonebot import get_driver
from nonebot.log import logger

from .config import config
from .sender import send_event_to_groups


driver = get_driver()
recent_events: dict[str, float] = {}
recent_lock = Lock()
REPEAT_WINDOW = 30.0


def _build_event_message(event: str, data: dict[str, Any]) -> Optional[str]:
    if event == "test":
        return f"测试成功！收到 webhook: {data.get('message', '无消息')}"

    if event == "player_connect":
        return (
            f"【玩家加入】 {data.get('player_name', '未知玩家')} 进入了服务器\n"
            f"SteamID: {data.get('steamid', '未知')}\n"
            f"当前在线: {data.get('player_count', '?')}/{data.get('max_players', '?')}"
        )

    if event == "player_disconnect":
        return (
            f"【玩家离开】 {data.get('player_name', '未知玩家')} 离开了服务器\n"
            f"SteamID: {data.get('steamid', '未知')}\n"
            f"原因: {data.get('reason', '正常断开')}\n"
            f"当前在线: {data.get('player_count', '?')}/{data.get('max_players', '?')}"
        )

    if event == "player_kick":
        return (
            f"【踢出玩家】 {data.get('player_name', '未知')} 被踢出服务器\n"
            f"SteamID: {data.get('steamid', '未知')}\n"
            f"管理员: {data.get('admin_name', '控制台')}\n"
            f"原因: {data.get('reason', '未说明')}"
        )

    if event == "map_changed":
        return (
            f"【地图切换】 服务器已切换到 {data.get('new_map', '未知地图')}\n"
            f"上一张地图: {data.get('old_map', '未知')}\n"
            f"切换时间: {data.get('time', '未知')}"
        )

    return None


def _json_response(content: dict[str, Any], status_code: int = 200) -> Any:
    from fastapi.responses import JSONResponse

    return JSONResponse(content=content, status_code=status_code)


async def cs2bridge_webhook(request: Any) -> Any:
    try:
        secret_from_header = request.headers.get("X-Webhook-Secret", "")
        if config.webhook_secret and secret_from_header != config.webhook_secret:
            logger.warning("[cs2bridge] webhook secret mismatch")
            return _json_response(content={"status": "ok"}, status_code=200)

        try:
            payload = await request.json()
        except Exception:  # noqa: BLE001
            logger.warning("[cs2bridge] invalid json payload")
            return _json_response(content={"status": "bad request"}, status_code=400)

        if not isinstance(payload, dict):
            logger.warning("[cs2bridge] payload is not a JSON object")
            return _json_response(content={"status": "bad request"}, status_code=400)

        event = str(payload.get("event") or "")
        data = payload.get("data", {})
        if not isinstance(data, dict):
            data = {"raw_data": data}

        steamid = data.get("steamid")
        player_name = data.get("player_name", "未知")
        if event == "map_changed":
            key = f"{event}:{data.get('new_map', '')}"
        elif steamid:
            key = f"{event}:{steamid}"
        else:
            key = f"{event}:{player_name}"

        async with recent_lock:
            last_time = recent_events.get(key, 0.0)
            now = time.time()
            if now - last_time < REPEAT_WINDOW:
                logger.info(
                    "忽略重复事件: {} (距上次 {:.1f} 秒)",
                    key,
                    now - last_time,
                )
                return _json_response(
                    content={"status": "ok", "ignored": "duplicate"},
                    status_code=200,
                )
            recent_events[key] = now

        logger.info("处理 CS2 事件: {} | 数据: {}", event, data)

        message = _build_event_message(event, data)
        if message is None:
            logger.info("收到未知事件: {}  数据: {}", event, data)
            return _json_response(content={"status": "ok"}, status_code=200)

        await send_event_to_groups(event, message)
    except Exception:  # noqa: BLE001
        logger.exception("[cs2bridge] failed while processing webhook")

    return _json_response(content={"status": "ok"}, status_code=200)


webhook_path = (
    config.webhook_path
    if config.webhook_path.startswith("/")
    else f"/{config.webhook_path}"
)
app = None
app = getattr(driver, "app", None) or getattr(driver, "server_app", None)
if app is None:
    get_app = getattr(driver, "get_app", None)
    if callable(get_app):
        try:
            app = get_app()
        except Exception:  # noqa: BLE001
            logger.warning("[cs2bridge] failed to get app from driver")

try:
    from fastapi import FastAPI
except Exception:  # noqa: BLE001
    FastAPI = None  # type: ignore[assignment]

if app is None:
    logger.warning(
        "[cs2bridge] app is unavailable from current driver, skip webhook route"
    )
elif FastAPI is None or not isinstance(app, FastAPI):
    logger.warning(
        "[cs2bridge] unsupported app type {}, skip webhook route registration",
        type(app).__name__,
    )
else:
    existing_route = any(
        getattr(route, "path", None) == webhook_path
        and "POST" in getattr(route, "methods", set())
        for route in app.routes
    )

    if not existing_route:
        app.post(webhook_path)(cs2bridge_webhook)

    logger.info(
        "[cs2bridge] loaded, path={}, groups={}", webhook_path, config.qq_group_ids
    )
