<div align="center">
  <a href="https://v2.nonebot.dev/store"><img src="https://github.com/A-kirami/nonebot-plugin-template/blob/resources/nbp_logo.png" width="180" height="180" alt="NoneBotPluginLogo"></a>
  <br>
  <p><img src="https://github.com/A-kirami/nonebot-plugin-template/blob/resources/NoneBotPlugin.svg" width="240" alt="NoneBotPluginText"></p>
</div>

<div align="center">

# nonebot-plugin-cs2bridge

_✨ CS2 服务器与 QQ 群桥接插件（事件推送、玩家查询、状态轮询） ✨_


<a href="./LICENSE">
    <img src="https://img.shields.io/github/license/Akiyy-hub/nonebot-plugin-cs2bridge.svg" alt="license">
</a>
<a href="https://pypi.python.org/pypi/nonebot-plugin-cs2bridge">
    <img src="https://img.shields.io/pypi/v/nonebot-plugin-cs2bridge.svg" alt="pypi">
</a>
<img src="https://img.shields.io/badge/python-3.9+-blue.svg" alt="python">

</div>

# CS2-Bridge
基于 `NoneBot` 的与 `CS2 Server` 互通消息插件

- 支持 QQ 群(OneBot V11适配器)
- 支持服务器与多个群聊的互通

## 🔧 服务端对接

CS2服务器端插件/Mod：[`CS2-Bridge`](https://github.com/Akiyy-hub/CS2-Bridge#readme)

<details open>
<summary>快速开始</summary>

1. 安装插件并在 NoneBot2 中加载。
2. 在 `.env` 中配置 `CS2_QQ_GROUP_IDS`、`CS2_SERVER_HOST`、`CS2_WEBHOOK_SECRET` 等配置项。
3. 通过 CS2 服务端向 webhook 地址发送事件，或在群里发送 `!players` 查询玩家列表。

</details>

> [!NOTE]
> 本插件在搭配 [`CS2-Bridge`](https://github.com/Akiyy-hub/CS2-Bridge) 的情况下将实现功能最大化
> 可以实现 CS2 服务器事件的自动推送到 QQ 群，极大提升了服务器管理的便利性和玩家互动体验。

## 📖 介绍

`nonebot-plugin-cs2bridge` 提供以下能力：

- 接收 CS2 事件 Webhook（玩家加入/离开、地图切换等）并推送至多个 QQ 群。
- 支持基于密钥的 webhook 校验（`X-Webhook-Secret`）。
- 支持短时间重复事件抑制，避免刷屏。
- 支持群内指令 `!players` 查询在线玩家（通过 A2S 查询）。
- 后台轮询服务器状态，仅在在线/离线状态变化时通知群聊。

## 💿 安装

<details open>
<summary>使用 nb-cli 安装</summary>
在 nonebot2 项目的根目录下打开命令行, 输入以下指令即可安装

    nb plugin install nonebot-plugin-cs2bridge

</details>

<details>
<summary>使用包管理器安装</summary>
在 nonebot2 项目的插件目录下, 打开命令行, 输入相应的安装命令

    pip install nonebot-plugin-cs2bridge


打开 nonebot2 项目根目录下的 `pyproject.toml` 文件, 在 `[tool.nonebot.plugins]` 部分追加写入

    nonebot-plugin-cs2bridge = ["nonebot_plugin_cs2bridge"]

</details>

## ⚙️ 配置

在 nonebot2 项目的 `.env` 文件中添加下表配置：

| 配置项 | 必填 | 默认值 | 说明 |
|:-----:|:----:|:----:|:----:|
| CS2_QQ_GROUP_IDS | 是 | [] | 接收推送的群号列表，例如 `[123456789,987654321]` |
| CS2_WEBHOOK_SECRET | 是 | 空 | Webhook 密钥，需与请求头 `X-Webhook-Secret` 一致 |
| CS2_WEBHOOK_PATH | 否 | /cs2/event | Webhook 路径 |
| CS2_SERVER_HOST | 否 | 空 | CS2 服务器地址，用于在线玩家查询与状态轮询 |
| CS2_QUERY_PORT | 否 | 27015 | A2S 查询端口 |
| CS2_STATUS_INTERVAL | 否 | 45 | 状态轮询间隔，范围 30-60 秒 |
| CS2_RCON_HOST | 否 | 空 | RCON 主机地址 |
| CS2_RCON_PORT | 否 | 27015 | RCON 端口 |
| CS2_RCON_PASSWORD | 否 | 空 | RCON 密码 |

## 🎉 使用
### 指令表
| 指令 | 权限 | 需要@ | 范围 | 说明 |
|:-----:|:----:|:----:|:----:|:----:|
| !players | 群员 | 否 | 指定群聊 | 查询 CS2 服务器在线玩家并按队伍展示 |

### Webhook 事件

- 请求方式：`POST`
- Header：`X-Webhook-Secret: <密钥>`
- 默认路径：`/cs2/event`

请求体示例：

```json
{
    "event": "player_connect",
    "data": {
        "player_name": "Akiyy",
        "steamid": "76561198000000000",
        "player_count": 8,
        "max_players": 20
    }
}
```

支持事件包括：`test`、`player_connect`、`player_disconnect`、`player_kick`、`map_changed`。
