"""iBeam local automation recorder (Playwright codegen + upload)."""

__version__ = "1.0.0"
