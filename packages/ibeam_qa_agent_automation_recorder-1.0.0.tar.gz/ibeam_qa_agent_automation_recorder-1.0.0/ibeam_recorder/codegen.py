"""Run Playwright codegen locally via npx."""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

from ibeam_recorder.config import CODEGEN_TMP_DIR

CODEGEN_TIMEOUT_SEC = 2 * 60 * 60


class CodegenEmptyError(Exception):
    """No recording was captured (missing or empty output file)."""


class NodeNotFoundError(Exception):
    """Node.js / npx not available."""


class PlaywrightNotFoundError(Exception):
    """Playwright CLI missing or not installed."""


class CodegenTimeoutError(Exception):
    """Codegen exceeded the maximum wait time."""


def _safe_segment(name: str, default: str) -> str:
    s = "".join(c for c in name if c.isalnum() or c in "_-")
    return s or default


def run(url: str, form: str, suite_type: str) -> str:
    """
    Run playwright codegen on the user's machine.
    Blocks until the user closes Chrome.
    Returns raw .ts content as a string.
    Raises CodegenEmptyError if nothing was recorded.
    """
    url = (url or "").strip()
    if not url:
        raise CodegenEmptyError("URL is empty.")

    fseg = _safe_segment(form.upper(), "FORM")
    sseg = _safe_segment(suite_type.lower(), "suite")
    tmp_file = CODEGEN_TMP_DIR / f"{fseg}_{sseg}_raw.ts"
    tmp_file.parent.mkdir(parents=True, exist_ok=True)
    if tmp_file.exists():
        tmp_file.unlink()

    cwd_env = os.environ.get("IBEAM_PLAYWRIGHT_CWD", "").strip()
    workdir = Path(cwd_env).expanduser().resolve() if cwd_env else Path.home()
    if cwd_env and not workdir.is_dir():
        workdir = Path.home()

    cmd = ["npx", "playwright", "codegen", url, "--output", str(tmp_file)]

    try:
        proc = subprocess.run(
            cmd,
            cwd=str(workdir),
            timeout=CODEGEN_TIMEOUT_SEC,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError as e:
        raise NodeNotFoundError(
            "Node.js is required. Install from https://nodejs.org"
        ) from e
    except subprocess.TimeoutExpired as e:
        raise CodegenTimeoutError(
            "Recording timed out (over 2 hours). Close Chrome and try again."
        ) from e

    err = (proc.stderr or "") + (proc.stdout or "")
    if proc.returncode != 0:
        tmp_file.unlink(missing_ok=True)
        el = err.lower()
        if "playwright" in el and (
            "install" in el
            or "not found" in el
            or "cannot find" in el
            or "enoent" in el
        ):
            raise PlaywrightNotFoundError("Run: npx playwright install")
        if "playwright" in el or "npx" in el:
            raise PlaywrightNotFoundError(
                "Playwright codegen failed. Try: npx playwright install"
            )
        raise CodegenEmptyError("Recording did not complete successfully.")

    if not tmp_file.exists():
        try:
            tmp_file.unlink(missing_ok=True)
        except OSError:
            pass
        raise CodegenEmptyError("No recording file was produced.")

    raw = tmp_file.read_text(encoding="utf-8", errors="replace")
    try:
        tmp_file.unlink(missing_ok=True)
    except OSError:
        pass

    if not raw.strip():
        raise CodegenEmptyError("Recording file was empty.")

    return raw
