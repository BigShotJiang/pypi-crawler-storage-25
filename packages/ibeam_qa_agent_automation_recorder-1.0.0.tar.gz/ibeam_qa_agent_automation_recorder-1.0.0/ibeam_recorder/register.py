"""Register ibeam-record:// URL scheme (Windows + macOS)."""

from __future__ import annotations

import os
import shutil
import stat
import subprocess
import sys
from pathlib import Path


def _recorder_exe_path() -> str:
    """Path to ibeam-recorder executable, or Python for -m fallback."""
    w = shutil.which("ibeam-recorder")
    if w:
        return w
    return sys.executable


def _windows_open_command() -> str:
    exe = _recorder_exe_path()
    if exe.lower().endswith(".exe") or os.path.basename(exe).lower() == "ibeam-recorder.exe":
        return f'"{exe}" "%1"'
    return f'"{exe}" -m ibeam_recorder.main "%1"'


def _lsregister() -> str:
    p = (
        "/System/Library/Frameworks/CoreServices.framework/Versions/A/"
        "Frameworks/LaunchServices.framework/Versions/A/Support/lsregister"
    )
    if Path(p).is_file():
        return p
    return (
        "/System/Library/Frameworks/CoreServices.framework/Frameworks/"
        "LaunchServices.framework/Support/lsregister"
    )


def register_windows() -> None:
    import winreg

    exe = _recorder_exe_path()
    cmd = _windows_open_command()

    key_path = r"ibeam-record"
    with winreg.CreateKey(winreg.HKEY_CLASSES_ROOT, key_path) as k:
        winreg.SetValue(k, "", winreg.REG_SZ, "iBeam Recorder Protocol")
        winreg.SetValueEx(k, "URL Protocol", 0, winreg.REG_SZ, "")
        with winreg.CreateKey(k, "DefaultIcon") as di:
            winreg.SetValue(di, "", winreg.REG_SZ, f"{exe},1")
        with winreg.CreateKey(k, r"shell\open\command") as c:
            winreg.SetValue(c, "", winreg.REG_SZ, cmd)


def unregister_windows() -> None:
    import winreg

    def _try_delete_subkey(parent: str, child: str) -> None:
        try:
            winreg.DeleteKey(winreg.HKEY_CLASSES_ROOT, f"{parent}\\{child}")
        except OSError:
            pass

    base = r"ibeam-record"
    for path in (
        r"ibeam-record\shell\open\command",
        r"ibeam-record\shell\open",
        r"ibeam-record\shell",
        r"ibeam-record\DefaultIcon",
    ):
        try:
            winreg.DeleteKey(winreg.HKEY_CLASSES_ROOT, path)
        except OSError:
            pass
    _try_delete_subkey(base, "URL Protocol")
    try:
        winreg.DeleteKey(winreg.HKEY_CLASSES_ROOT, base)
    except OSError:
        pass


def _mac_app_dir() -> Path:
    return Path.home() / "Applications" / "iBeamRecorder.app"


def register_macos() -> None:
    app = _mac_app_dir()
    contents = app / "Contents"
    macos = contents / "MacOS"
    macos.mkdir(parents=True, exist_ok=True)

    launcher = macos / "iBeamRecorder"
    py = sys.executable
    launcher.write_text(
        f"""#!/bin/bash
exec "{py}" -m ibeam_recorder.main "$@"
""",
        encoding="utf-8",
    )
    launcher.chmod(launcher.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    plist = contents / "Info.plist"
    plist.write_text(
        """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key>
    <string>iBeamRecorder</string>
    <key>CFBundleIdentifier</key>
    <string>com.ibeam.recorder</string>
    <key>CFBundleName</key>
    <string>iBeamRecorder</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleURLTypes</key>
    <array>
        <dict>
            <key>CFBundleURLName</key>
            <string>com.ibeam.recorder</string>
            <key>CFBundleURLSchemes</key>
            <array>
                <string>ibeam-record</string>
            </array>
        </dict>
    </array>
</dict>
</plist>
""",
        encoding="utf-8",
    )
    subprocess.run([_lsregister(), "-f", str(app)], check=False)


def unregister_macos() -> None:
    app = _mac_app_dir()
    if app.exists():
        subprocess.run([_lsregister(), "-u", str(app)], check=False)
        shutil.rmtree(app, ignore_errors=True)
    legacy = Path.home() / "Applications" / "IbeamRecorder.app"
    if legacy.exists():
        subprocess.run([_lsregister(), "-u", str(legacy)], check=False)
        shutil.rmtree(legacy, ignore_errors=True)


def register() -> None:
    if sys.platform == "win32":
        register_windows()
    elif sys.platform == "darwin":
        register_macos()
    else:
        raise RuntimeError("URL scheme registration is only supported on Windows and macOS.")


def unregister() -> None:
    if sys.platform == "win32":
        unregister_windows()
    elif sys.platform == "darwin":
        unregister_macos()
    else:
        raise RuntimeError("URL scheme unregistration is only supported on Windows and macOS.")


def is_registered() -> bool:
    if sys.platform == "win32":
        import winreg

        try:
            winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, r"ibeam-record")
            return True
        except OSError:
            return False
    if sys.platform == "darwin":
        return _mac_app_dir().is_dir()
    return False
