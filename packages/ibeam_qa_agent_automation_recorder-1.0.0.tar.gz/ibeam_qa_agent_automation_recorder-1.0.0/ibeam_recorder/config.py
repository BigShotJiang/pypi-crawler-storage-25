"""Paths and constants for ibeam-recorder."""

from pathlib import Path

IBEAM_HOME = Path.home() / ".ibeam"
CODEGEN_TMP_DIR = IBEAM_HOME / "codegen_tmp"
FAILED_UPLOADS_DIR = IBEAM_HOME / "failed_uploads"
CONFIG_FILE = IBEAM_HOME / "config.json"

PROTOCOL_SCHEME = "ibeam-record"
APP_NAME = "iBeamRecorder"
PACKAGE_NAME = "ibeam-qa-agent-automation-recorder"

CODEGEN_TMP_DIR.mkdir(parents=True, exist_ok=True)
FAILED_UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
