"""CLI entry: ibeam-record:// handler, ping, register."""

from __future__ import annotations

import socket
import sys
import threading
from typing import Optional
from urllib.parse import parse_qs, urlparse

import click
import requests

from ibeam_recorder.codegen import (
    CodegenEmptyError,
    CodegenTimeoutError,
    NodeNotFoundError,
    PlaywrightNotFoundError,
)


class RecorderCLI(click.Group):
    """So the OS can invoke `ibeam-recorder <ibeam-record://...>` without a `handle` subcommand."""

    def parse_args(self, ctx: click.Context, args: List[str]) -> List[str]:
        args = list(args)
        if (
            args
            and not args[0].startswith("-")
            and args[0].startswith("ibeam-record:")
        ):
            args.insert(0, "handle")
        return super().parse_args(ctx, args)


@click.group(cls=RecorderCLI, invoke_without_command=True)
@click.pass_context
def cli(ctx: click.Context) -> None:
    """iBeam local recorder (Playwright codegen + upload)."""
    if ctx.invoked_subcommand is not None:
        return
    click.echo(ctx.get_help())


@cli.command("register")
def cmd_register() -> None:
    """Register ibeam-record:// protocol on this machine."""
    from ibeam_recorder.register import register as do_register

    do_register()
    click.echo("✅ iBeam Recorder registered successfully.")
    click.echo("You can now use the Build Suite feature in the iBeam web app.")


@cli.command("unregister")
def cmd_unregister() -> None:
    """Unregister ibeam-record:// protocol."""
    from ibeam_recorder.register import unregister as do_unregister

    do_unregister()
    click.echo("✅ iBeam Recorder unregistered.")


@cli.command("status")
def cmd_status() -> None:
    """Check if ibeam-record:// is registered."""
    from ibeam_recorder.register import is_registered

    if is_registered():
        click.echo("✅ iBeam Recorder is registered and ready.")
    else:
        click.echo("❌ Not registered. Run: ibeam-recorder register")


@cli.command(name="handle")
@click.argument("url")
def handle_protocol(url: str) -> None:
    """
    Handle ibeam-record:// URL (called automatically by the OS).
    Not intended for manual use.
    """
    parsed = urlparse(url)
    params = parse_qs(parsed.query)

    def get(key: str) -> Optional[str]:
        v = params.get(key, [None])[0]
        return v

    action = (parsed.netloc or "").lower()
    pl_path = parsed.path.lower()
    if action == "ping" or pl_path == "/ping" or pl_path.endswith("/ping"):
        _handle_ping()
        return

    if action == "start":
        job_id = get("job_id")
        token = get("token")
        form = get("form")
        suite_type = get("suite_type") or get("suite")
        app_url = get("url")
        server = get("server")

        if not all([job_id, token, form, suite_type, app_url, server]):
            click.echo("❌ Invalid protocol URL — missing parameters.")
            return

        click.echo("🎬 Opening Chrome for recording...")
        click.echo(f"   Form: {form} | Suite: {suite_type}")
        click.echo("   Record your steps, then close Chrome when done.")

        try:
            from ibeam_recorder.codegen import run

            raw = run(url=app_url, form=form, suite_type=suite_type)
        except CodegenEmptyError:
            _notify_server_failed(
                server,
                job_id,
                token,
                form,
                suite_type,
                "No recording captured",
            )
            return
        except NodeNotFoundError as e:
            click.echo(f"❌ {e}")
            return
        except PlaywrightNotFoundError as e:
            click.echo(f"❌ {e}")
            return
        except CodegenTimeoutError as e:
            click.echo(f"❌ {e}")
            _notify_server_failed(
                server,
                job_id,
                token,
                form,
                suite_type,
                str(e),
            )
            return

        click.echo("✅ Recording captured. Uploading to server...")

        from ibeam_recorder.uploader import upload

        success = upload(server, job_id, token, form, suite_type, raw)

        if success:
            click.echo("✅ Upload complete. Check your web app for results.")
        else:
            click.echo("❌ Upload failed. Saved locally for retry.")
            click.echo(f"   Location: ~/.ibeam/failed_uploads/{job_id}.json")
        return

    click.echo("❌ Unrecognized ibeam-record URL.", err=True)


def _handle_ping() -> None:
    """Briefly listen on localhost:17234 so web UI can detect install."""

    def respond() -> None:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("127.0.0.1", 17234))
            s.listen(1)
            s.settimeout(3)
            try:
                conn, _ = s.accept()
                try:
                    conn.sendall(b"HTTP/1.1 200 OK\r\n\r\nibeam-recorder:ok")
                finally:
                    conn.close()
            except OSError:
                pass

    t = threading.Thread(target=respond, daemon=True)
    t.start()
    t.join(timeout=4)


def _notify_server_failed(
    server: str,
    job_id: str,
    token: str,
    form: str,
    suite_type: str,
    reason: str,
) -> None:
    """Tell server recording failed so chat UI can update."""
    base = server.rstrip("/")
    url = f"{base}/automation/upload-recording"
    try:
        requests.post(
            url,
            json={
                "job_id": job_id,
                "token": token,
                "form": form,
                "suite_type": suite_type,
                "raw_script": "",
                "status": "failed",
                "failure_message": reason,
            },
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {token}",
            },
            timeout=10,
        )
    except Exception:
        pass


if __name__ == "__main__":
    cli()
