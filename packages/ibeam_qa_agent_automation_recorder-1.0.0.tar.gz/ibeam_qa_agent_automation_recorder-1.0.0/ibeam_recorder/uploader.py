"""Upload raw codegen script to validation API."""

from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import click
import requests

from ibeam_recorder.config import FAILED_UPLOADS_DIR

logger = logging.getLogger(__name__)

REQUEST_TIMEOUT_SEC = 120


def upload(
    server: str,
    job_id: str,
    token: str,
    form: str,
    suite_type: str,
    raw_script: str,
) -> bool:
    """
    POSTs raw script to server.
    Retries 3 times with exponential backoff (wait 2s before 2nd, 4s before 3rd).
    Saves to failed_uploads/ if all retries fail.
    Returns True on success, False on failure.
    """
    base = server.rstrip("/")
    url = f"{base}/automation/upload-recording"
    payload: Dict[str, Any] = {
        "job_id": job_id,
        "token": token,
        "form": form,
        "suite_type": suite_type,
        "raw_script": raw_script,
        "status": "success",
    }
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": f"Bearer {token}",
    }

    last_exc: Optional[Exception] = None
    for attempt in range(3):
        if attempt == 1:
            time.sleep(2)
        elif attempt == 2:
            time.sleep(4)
        try:
            r = requests.post(
                url,
                json=payload,
                headers=headers,
                timeout=REQUEST_TIMEOUT_SEC,
            )
            if r.status_code == 200:
                return True
            if r.status_code == 410:
                click.echo("Session expired. Please start a new recording.")
                return False
            if r.status_code == 401:
                click.echo("Invalid session. Please try again from the web app.")
                return False
            last_exc = RuntimeError(f"HTTP {r.status_code}: {r.text[:500]}")
            logger.warning("Upload attempt %s failed: %s", attempt + 1, last_exc)
        except requests.RequestException as e:
            last_exc = e
            logger.warning("Upload attempt %s failed: %s", attempt + 1, e)

    _save_failed_upload(
        job_id=job_id,
        token=token,
        server=server,
        form=form,
        suite_type=suite_type,
        raw_script=raw_script,
    )
    return False


def _save_failed_upload(
    *,
    job_id: str,
    token: str,
    server: str,
    form: str,
    suite_type: str,
    raw_script: str,
) -> None:
    FAILED_UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
    path = FAILED_UPLOADS_DIR / f"{job_id}.json"
    data = {
        "job_id": job_id,
        "token": token,
        "server": server,
        "form": form,
        "suite_type": suite_type,
        "raw_script": raw_script,
        "failed_at": datetime.now(timezone.utc).isoformat(),
    }
    try:
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        logger.error("Saved failed upload to %s", path)
    except OSError as e:
        logger.error("Could not save failed upload: %s", e)
