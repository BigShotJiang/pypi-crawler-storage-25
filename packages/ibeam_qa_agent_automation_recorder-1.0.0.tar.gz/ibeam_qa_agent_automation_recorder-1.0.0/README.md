# ibeam-qa-agent-automation-recorder

Local recorder for iBeam QA Automation platform.

## Install (one time)

```bash
pip install ibeam-qa-agent-automation-recorder
ibeam-recorder register
```

## That's it

Chrome will open automatically when you use Build Suite in the iBeam web app.

## Check status

```bash
ibeam-recorder status
```

## Uninstall

```bash
ibeam-recorder unregister
pip uninstall ibeam-qa-agent-automation-recorder
```

## Publishing to PyPI

### Create PyPI account

Go to https://pypi.org/account/register/

### Install build tools

```bash
pip install build twine
```

### Build package

```bash
cd ibeam-qa-agent-automation-recorder/
python -m build
```

This creates `dist/` with `.tar.gz` and `.whl`.

### Test on TestPyPI first

```bash
twine upload --repository testpypi dist/*
pip install --index-url https://test.pypi.org/simple/ ibeam-qa-agent-automation-recorder
```

### Publish to PyPI

```bash
twine upload dist/*
```

Use an API token when prompted (recommended).

### Updating the package

1. Bump version in `setup.py`
2. `python -m build`
3. `twine upload dist/*`
4. Team: `pip install --upgrade ibeam-qa-agent-automation-recorder`
