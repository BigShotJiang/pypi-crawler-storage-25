from pathlib import Path

from setuptools import find_packages, setup

_README = Path(__file__).with_name("README.md").read_text(encoding="utf-8")

setup(
    name="ibeam-qa-agent-automation-recorder",
    version="1.0.0",
    description="Local recorder for iBeam QA automation — captures Playwright codegen and uploads to server",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "click>=8.0",
        "requests>=2.28",
    ],
    entry_points={
        "console_scripts": [
            "ibeam-recorder=ibeam_recorder.main:cli",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    long_description=_README,
    long_description_content_type="text/markdown",
)
