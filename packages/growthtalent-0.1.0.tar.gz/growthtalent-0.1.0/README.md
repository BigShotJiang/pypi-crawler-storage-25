# growthtalent

[![PyPI version](https://img.shields.io/pypi/v/growthtalent.svg)](https://pypi.org/project/growthtalent/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Python: 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://pypi.org/project/growthtalent/)

Type-safe Python client for the [Growth.Talent](https://www.growthtalent.org) API. Auto-generated from the [OpenAPI 3.1 spec](https://www.growthtalent.org/api/v1/openapi.json), works in async + sync, dataclass-typed models, ships with httpx.

## Install

```bash
pip install growthtalent
# or
uv add growthtalent
# or
poetry add growthtalent
```

## Quickstart

### Public read (no API key)

```python
from growthtalent import Client
from growthtalent.api.default import get_jobs

with Client(base_url="https://www.growthtalent.org/api/v1") as client:
    response = get_jobs.sync_detailed(client=client, q="head of growth", market="usa", limit=5)
    print(response.parsed)
```

### Authenticated (apply, post, profile)

```python
from growthtalent import AuthenticatedClient
from growthtalent.api.default import get_me, post_applications
from growthtalent.models import PostApplicationsBody

with AuthenticatedClient(
    base_url="https://www.growthtalent.org/api/v1",
    token="gt_live_...",  # from /settings/api-keys
) as client:
    me = get_me.sync(client=client)
    print(f"Signed in as {me.candidate.name}")

    result = post_applications.sync(
        client=client,
        body=PostApplicationsBody(
            job_slug_or_id="head-of-growth-the-mobile-first-company",
            message="Hi — built growth at Spendesk #4 to unicorn.",
            via="magic",
        ),
    )
    print(result)
```

### Async

Every endpoint also exposes `.asyncio` and `.asyncio_detailed` variants:

```python
import asyncio
from growthtalent import Client
from growthtalent.api.default import get_jobs

async def main():
    async with Client(base_url="https://www.growthtalent.org/api/v1") as client:
        jobs = await get_jobs.asyncio(client=client, q="growth", limit=5)
        print(jobs)

asyncio.run(main())
```

## What you get

- Every endpoint as a typed function (`get_jobs`, `patch_me`, `post_applications`, …) with sync + async variants
- Full request/response models as `attrs` dataclasses (`Candidate`, `JobShort`, `JobFull`, …)
- httpx under the hood — supports custom transports, retries, proxy, mTLS
- Works in Python 3.9+

## Auth

Mint a key at https://www.growthtalent.org/settings/api-keys (verified Growth.Talent members only). Keys are SHA-256 hashed at rest, plaintext shown once. Pass via `AuthenticatedClient(token="gt_live_...")`.

## Regenerate from latest spec

This client is auto-generated. To rebuild:

```bash
uvx --from openapi-python-client openapi-python-client generate \
  --url https://www.growthtalent.org/api/v1/openapi.json \
  --output-path . \
  --overwrite
```

Then update `pyproject.toml` to match the metadata above.

## License

MIT — © The Mobile First Company
