from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_error import ApiError
from ...models.post_job_body import PostJobBody
from ...models.post_jobs_response_201 import PostJobsResponse201
from ...types import Response


def _get_kwargs(
    *,
    body: PostJobBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/jobs",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[ApiError, PostJobsResponse201]]:
    if response.status_code == 201:
        response_201 = PostJobsResponse201.from_dict(response.json())

        return response_201

    if response.status_code == 403:
        response_403 = ApiError.from_dict(response.json())

        return response_403

    if response.status_code == 409:
        response_409 = ApiError.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = ApiError.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ApiError.from_dict(response.json())

        return response_429

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[ApiError, PostJobsResponse201]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: PostJobBody,
) -> Response[Union[ApiError, PostJobsResponse201]]:
    """Post a new job (companies only)

     Requires `jobs:post` scope on a company-owned API key. AI moderation runs async; jobs scoring under
    7 are flagged. Published immediately at /{market}/{category}/{companySlug}/{slug}.

    Args:
        body (PostJobBody):  Example: {'title': 'Head of Growth', 'category': 'head-of-growth',
            'applyUrl': 'https://jobs.example.com/head-of-growth', 'description': "We're hiring a Head
            of Growth to own acquisition, activation, and retention across paid, organic, and
            lifecycle channels. 5+ years scaling a B2B or PLG product from $1M to $10M+ ARR. Mixpanel,
            paid ads, attribution.", 'seniority': 'VP', 'remote': 'HYBRID', 'market': 'USA', 'city':
            'New York', 'country': 'US', 'salaryMin': 180000, 'salaryMax': 240000, 'salaryCurrency':
            'USD'}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ApiError, PostJobsResponse201]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: PostJobBody,
) -> Optional[Union[ApiError, PostJobsResponse201]]:
    """Post a new job (companies only)

     Requires `jobs:post` scope on a company-owned API key. AI moderation runs async; jobs scoring under
    7 are flagged. Published immediately at /{market}/{category}/{companySlug}/{slug}.

    Args:
        body (PostJobBody):  Example: {'title': 'Head of Growth', 'category': 'head-of-growth',
            'applyUrl': 'https://jobs.example.com/head-of-growth', 'description': "We're hiring a Head
            of Growth to own acquisition, activation, and retention across paid, organic, and
            lifecycle channels. 5+ years scaling a B2B or PLG product from $1M to $10M+ ARR. Mixpanel,
            paid ads, attribution.", 'seniority': 'VP', 'remote': 'HYBRID', 'market': 'USA', 'city':
            'New York', 'country': 'US', 'salaryMin': 180000, 'salaryMax': 240000, 'salaryCurrency':
            'USD'}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ApiError, PostJobsResponse201]
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: PostJobBody,
) -> Response[Union[ApiError, PostJobsResponse201]]:
    """Post a new job (companies only)

     Requires `jobs:post` scope on a company-owned API key. AI moderation runs async; jobs scoring under
    7 are flagged. Published immediately at /{market}/{category}/{companySlug}/{slug}.

    Args:
        body (PostJobBody):  Example: {'title': 'Head of Growth', 'category': 'head-of-growth',
            'applyUrl': 'https://jobs.example.com/head-of-growth', 'description': "We're hiring a Head
            of Growth to own acquisition, activation, and retention across paid, organic, and
            lifecycle channels. 5+ years scaling a B2B or PLG product from $1M to $10M+ ARR. Mixpanel,
            paid ads, attribution.", 'seniority': 'VP', 'remote': 'HYBRID', 'market': 'USA', 'city':
            'New York', 'country': 'US', 'salaryMin': 180000, 'salaryMax': 240000, 'salaryCurrency':
            'USD'}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ApiError, PostJobsResponse201]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: PostJobBody,
) -> Optional[Union[ApiError, PostJobsResponse201]]:
    """Post a new job (companies only)

     Requires `jobs:post` scope on a company-owned API key. AI moderation runs async; jobs scoring under
    7 are flagged. Published immediately at /{market}/{category}/{companySlug}/{slug}.

    Args:
        body (PostJobBody):  Example: {'title': 'Head of Growth', 'category': 'head-of-growth',
            'applyUrl': 'https://jobs.example.com/head-of-growth', 'description': "We're hiring a Head
            of Growth to own acquisition, activation, and retention across paid, organic, and
            lifecycle channels. 5+ years scaling a B2B or PLG product from $1M to $10M+ ARR. Mixpanel,
            paid ads, attribution.", 'seniority': 'VP', 'remote': 'HYBRID', 'market': 'USA', 'city':
            'New York', 'country': 'US', 'salaryMin': 180000, 'salaryMax': 240000, 'salaryCurrency':
            'USD'}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ApiError, PostJobsResponse201]
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
