from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_error import ApiError
from ...models.patch_job_body import PatchJobBody
from ...models.patch_jobs_slug_response_200 import PatchJobsSlugResponse200
from ...types import Response


def _get_kwargs(
    slug: str,
    *,
    body: PatchJobBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": f"/jobs/{slug}",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[ApiError, PatchJobsSlugResponse200]]:
    if response.status_code == 200:
        response_200 = PatchJobsSlugResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ApiError.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = ApiError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = ApiError.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = ApiError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[ApiError, PatchJobsSlugResponse200]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    slug: str,
    *,
    client: AuthenticatedClient,
    body: PatchJobBody,
) -> Response[Union[ApiError, PatchJobsSlugResponse200]]:
    r"""Update or close a job (companies only — must own this job)

     Requires `jobs:post` scope on a company-owned API key. The job's companyId must match the key's
    company. Use `status: \"EXPIRED\"` to close, `status: \"APPROVED\"` to reopen.

    Args:
        slug (str):
        body (PatchJobBody):  Example: {'status': 'EXPIRED'}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ApiError, PatchJobsSlugResponse200]]
    """

    kwargs = _get_kwargs(
        slug=slug,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    slug: str,
    *,
    client: AuthenticatedClient,
    body: PatchJobBody,
) -> Optional[Union[ApiError, PatchJobsSlugResponse200]]:
    r"""Update or close a job (companies only — must own this job)

     Requires `jobs:post` scope on a company-owned API key. The job's companyId must match the key's
    company. Use `status: \"EXPIRED\"` to close, `status: \"APPROVED\"` to reopen.

    Args:
        slug (str):
        body (PatchJobBody):  Example: {'status': 'EXPIRED'}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ApiError, PatchJobsSlugResponse200]
    """

    return sync_detailed(
        slug=slug,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    slug: str,
    *,
    client: AuthenticatedClient,
    body: PatchJobBody,
) -> Response[Union[ApiError, PatchJobsSlugResponse200]]:
    r"""Update or close a job (companies only — must own this job)

     Requires `jobs:post` scope on a company-owned API key. The job's companyId must match the key's
    company. Use `status: \"EXPIRED\"` to close, `status: \"APPROVED\"` to reopen.

    Args:
        slug (str):
        body (PatchJobBody):  Example: {'status': 'EXPIRED'}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ApiError, PatchJobsSlugResponse200]]
    """

    kwargs = _get_kwargs(
        slug=slug,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    slug: str,
    *,
    client: AuthenticatedClient,
    body: PatchJobBody,
) -> Optional[Union[ApiError, PatchJobsSlugResponse200]]:
    r"""Update or close a job (companies only — must own this job)

     Requires `jobs:post` scope on a company-owned API key. The job's companyId must match the key's
    company. Use `status: \"EXPIRED\"` to close, `status: \"APPROVED\"` to reopen.

    Args:
        slug (str):
        body (PatchJobBody):  Example: {'status': 'EXPIRED'}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ApiError, PatchJobsSlugResponse200]
    """

    return (
        await asyncio_detailed(
            slug=slug,
            client=client,
            body=body,
        )
    ).parsed
