from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_talent_response_200 import GetTalentResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    seniority: Union[Unset, str] = UNSET,
    city: Union[Unset, str] = UNSET,
    tool: Union[Unset, str] = UNSET,
    open_to_work: Union[Unset, bool] = UNSET,
    q: Union[Unset, str] = UNSET,
    page: Union[Unset, int] = 1,
    limit: Union[Unset, int] = 30,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["seniority"] = seniority

    params["city"] = city

    params["tool"] = tool

    params["openToWork"] = open_to_work

    params["q"] = q

    params["page"] = page

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/talent",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[GetTalentResponse200]:
    if response.status_code == 200:
        response_200 = GetTalentResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[GetTalentResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    seniority: Union[Unset, str] = UNSET,
    city: Union[Unset, str] = UNSET,
    tool: Union[Unset, str] = UNSET,
    open_to_work: Union[Unset, bool] = UNSET,
    q: Union[Unset, str] = UNSET,
    page: Union[Unset, int] = 1,
    limit: Union[Unset, int] = 30,
) -> Response[GetTalentResponse200]:
    """Search talent profiles

    Args:
        seniority (Union[Unset, str]):
        city (Union[Unset, str]):
        tool (Union[Unset, str]): e.g. HubSpot, Mixpanel
        open_to_work (Union[Unset, bool]):
        q (Union[Unset, str]):
        page (Union[Unset, int]):  Default: 1.
        limit (Union[Unset, int]):  Default: 30.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetTalentResponse200]
    """

    kwargs = _get_kwargs(
        seniority=seniority,
        city=city,
        tool=tool,
        open_to_work=open_to_work,
        q=q,
        page=page,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    seniority: Union[Unset, str] = UNSET,
    city: Union[Unset, str] = UNSET,
    tool: Union[Unset, str] = UNSET,
    open_to_work: Union[Unset, bool] = UNSET,
    q: Union[Unset, str] = UNSET,
    page: Union[Unset, int] = 1,
    limit: Union[Unset, int] = 30,
) -> Optional[GetTalentResponse200]:
    """Search talent profiles

    Args:
        seniority (Union[Unset, str]):
        city (Union[Unset, str]):
        tool (Union[Unset, str]): e.g. HubSpot, Mixpanel
        open_to_work (Union[Unset, bool]):
        q (Union[Unset, str]):
        page (Union[Unset, int]):  Default: 1.
        limit (Union[Unset, int]):  Default: 30.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetTalentResponse200
    """

    return sync_detailed(
        client=client,
        seniority=seniority,
        city=city,
        tool=tool,
        open_to_work=open_to_work,
        q=q,
        page=page,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    seniority: Union[Unset, str] = UNSET,
    city: Union[Unset, str] = UNSET,
    tool: Union[Unset, str] = UNSET,
    open_to_work: Union[Unset, bool] = UNSET,
    q: Union[Unset, str] = UNSET,
    page: Union[Unset, int] = 1,
    limit: Union[Unset, int] = 30,
) -> Response[GetTalentResponse200]:
    """Search talent profiles

    Args:
        seniority (Union[Unset, str]):
        city (Union[Unset, str]):
        tool (Union[Unset, str]): e.g. HubSpot, Mixpanel
        open_to_work (Union[Unset, bool]):
        q (Union[Unset, str]):
        page (Union[Unset, int]):  Default: 1.
        limit (Union[Unset, int]):  Default: 30.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetTalentResponse200]
    """

    kwargs = _get_kwargs(
        seniority=seniority,
        city=city,
        tool=tool,
        open_to_work=open_to_work,
        q=q,
        page=page,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    seniority: Union[Unset, str] = UNSET,
    city: Union[Unset, str] = UNSET,
    tool: Union[Unset, str] = UNSET,
    open_to_work: Union[Unset, bool] = UNSET,
    q: Union[Unset, str] = UNSET,
    page: Union[Unset, int] = 1,
    limit: Union[Unset, int] = 30,
) -> Optional[GetTalentResponse200]:
    """Search talent profiles

    Args:
        seniority (Union[Unset, str]):
        city (Union[Unset, str]):
        tool (Union[Unset, str]): e.g. HubSpot, Mixpanel
        open_to_work (Union[Unset, bool]):
        q (Union[Unset, str]):
        page (Union[Unset, int]):  Default: 1.
        limit (Union[Unset, int]):  Default: 30.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetTalentResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
            seniority=seniority,
            city=city,
            tool=tool,
            open_to_work=open_to_work,
            q=q,
            page=page,
            limit=limit,
        )
    ).parsed
