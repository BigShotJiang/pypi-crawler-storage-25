from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_error import ApiError
from ...models.post_application_body import PostApplicationBody
from ...models.post_applications_response_201 import PostApplicationsResponse201
from ...types import Response


def _get_kwargs(
    *,
    body: PostApplicationBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/applications",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[ApiError, PostApplicationsResponse201]]:
    if response.status_code == 201:
        response_201 = PostApplicationsResponse201.from_dict(response.json())

        return response_201

    if response.status_code == 403:
        response_403 = ApiError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = ApiError.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = ApiError.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ApiError.from_dict(response.json())

        return response_429

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[ApiError, PostApplicationsResponse201]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: PostApplicationBody,
) -> Response[Union[ApiError, PostApplicationsResponse201]]:
    """Apply to a job on behalf of the authenticated candidate

     Requires `jobs:apply` scope. If `via=magic` and the company has a contact email, the company
    receives a direct email with the candidate's profile and message; otherwise the application is
    recorded as `external` and the agent should also direct the user to `applyUrl`.

    Note: to LIST past applications you also need the `me:read` scope (GET /me/applications).

    Args:
        body (PostApplicationBody):  Example: {'jobSlugOrId': 'head-of-growth-the-mobile-first-
            company', 'message': 'Hi — I built growth at Spendesk #4 to unicorn. Would love to chat
            about Allo.', 'via': 'magic'}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ApiError, PostApplicationsResponse201]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: PostApplicationBody,
) -> Optional[Union[ApiError, PostApplicationsResponse201]]:
    """Apply to a job on behalf of the authenticated candidate

     Requires `jobs:apply` scope. If `via=magic` and the company has a contact email, the company
    receives a direct email with the candidate's profile and message; otherwise the application is
    recorded as `external` and the agent should also direct the user to `applyUrl`.

    Note: to LIST past applications you also need the `me:read` scope (GET /me/applications).

    Args:
        body (PostApplicationBody):  Example: {'jobSlugOrId': 'head-of-growth-the-mobile-first-
            company', 'message': 'Hi — I built growth at Spendesk #4 to unicorn. Would love to chat
            about Allo.', 'via': 'magic'}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ApiError, PostApplicationsResponse201]
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: PostApplicationBody,
) -> Response[Union[ApiError, PostApplicationsResponse201]]:
    """Apply to a job on behalf of the authenticated candidate

     Requires `jobs:apply` scope. If `via=magic` and the company has a contact email, the company
    receives a direct email with the candidate's profile and message; otherwise the application is
    recorded as `external` and the agent should also direct the user to `applyUrl`.

    Note: to LIST past applications you also need the `me:read` scope (GET /me/applications).

    Args:
        body (PostApplicationBody):  Example: {'jobSlugOrId': 'head-of-growth-the-mobile-first-
            company', 'message': 'Hi — I built growth at Spendesk #4 to unicorn. Would love to chat
            about Allo.', 'via': 'magic'}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ApiError, PostApplicationsResponse201]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: PostApplicationBody,
) -> Optional[Union[ApiError, PostApplicationsResponse201]]:
    """Apply to a job on behalf of the authenticated candidate

     Requires `jobs:apply` scope. If `via=magic` and the company has a contact email, the company
    receives a direct email with the candidate's profile and message; otherwise the application is
    recorded as `external` and the agent should also direct the user to `applyUrl`.

    Note: to LIST past applications you also need the `me:read` scope (GET /me/applications).

    Args:
        body (PostApplicationBody):  Example: {'jobSlugOrId': 'head-of-growth-the-mobile-first-
            company', 'message': 'Hi — I built growth at Spendesk #4 to unicorn. Would love to chat
            about Allo.', 'via': 'magic'}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ApiError, PostApplicationsResponse201]
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
