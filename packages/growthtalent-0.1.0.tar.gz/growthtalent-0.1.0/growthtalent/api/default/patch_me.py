from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_error import ApiError
from ...models.patch_me_body import PatchMeBody
from ...models.patch_me_response_200 import PatchMeResponse200
from ...types import Response


def _get_kwargs(
    *,
    body: PatchMeBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/me",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[ApiError, PatchMeResponse200]]:
    if response.status_code == 200:
        response_200 = PatchMeResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ApiError.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = ApiError.from_dict(response.json())

        return response_403

    if response.status_code == 422:
        response_422 = ApiError.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = ApiError.from_dict(response.json())

        return response_429

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[ApiError, PatchMeResponse200]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: PatchMeBody,
) -> Response[Union[ApiError, PatchMeResponse200]]:
    """Update the authenticated candidate's own profile

     Requires `me:write` scope. Whitelisted fields only. Pass `null` to clear a string field.

    Args:
        body (PatchMeBody):  Example: {'isOpenToWork': True, 'headline': 'VP Growth at Spendesk →
            CEO at The Mobile First Company', 'salaryMin': 200000, 'salaryMax': 280000,
            'salaryCurrency': 'USD', 'tools': ['HubSpot', 'Mixpanel', 'Segment', 'Braze']}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ApiError, PatchMeResponse200]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: PatchMeBody,
) -> Optional[Union[ApiError, PatchMeResponse200]]:
    """Update the authenticated candidate's own profile

     Requires `me:write` scope. Whitelisted fields only. Pass `null` to clear a string field.

    Args:
        body (PatchMeBody):  Example: {'isOpenToWork': True, 'headline': 'VP Growth at Spendesk →
            CEO at The Mobile First Company', 'salaryMin': 200000, 'salaryMax': 280000,
            'salaryCurrency': 'USD', 'tools': ['HubSpot', 'Mixpanel', 'Segment', 'Braze']}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ApiError, PatchMeResponse200]
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: PatchMeBody,
) -> Response[Union[ApiError, PatchMeResponse200]]:
    """Update the authenticated candidate's own profile

     Requires `me:write` scope. Whitelisted fields only. Pass `null` to clear a string field.

    Args:
        body (PatchMeBody):  Example: {'isOpenToWork': True, 'headline': 'VP Growth at Spendesk →
            CEO at The Mobile First Company', 'salaryMin': 200000, 'salaryMax': 280000,
            'salaryCurrency': 'USD', 'tools': ['HubSpot', 'Mixpanel', 'Segment', 'Braze']}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ApiError, PatchMeResponse200]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: PatchMeBody,
) -> Optional[Union[ApiError, PatchMeResponse200]]:
    """Update the authenticated candidate's own profile

     Requires `me:write` scope. Whitelisted fields only. Pass `null` to clear a string field.

    Args:
        body (PatchMeBody):  Example: {'isOpenToWork': True, 'headline': 'VP Growth at Spendesk →
            CEO at The Mobile First Company', 'salaryMin': 200000, 'salaryMax': 280000,
            'salaryCurrency': 'USD', 'tools': ['HubSpot', 'Mixpanel', 'Segment', 'Braze']}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ApiError, PatchMeResponse200]
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
