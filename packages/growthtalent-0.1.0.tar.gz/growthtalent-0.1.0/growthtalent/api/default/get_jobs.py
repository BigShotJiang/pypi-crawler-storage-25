from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_jobs_market import GetJobsMarket
from ...models.get_jobs_response_200 import GetJobsResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    market: Union[Unset, GetJobsMarket] = UNSET,
    category: Union[Unset, str] = UNSET,
    city: Union[Unset, str] = UNSET,
    seniority: Union[Unset, str] = UNSET,
    contract_type: Union[Unset, str] = UNSET,
    remote: Union[Unset, bool] = UNSET,
    salary_min: Union[Unset, int] = UNSET,
    q: Union[Unset, str] = UNSET,
    page: Union[Unset, int] = 1,
    limit: Union[Unset, int] = 30,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    json_market: Union[Unset, str] = UNSET
    if not isinstance(market, Unset):
        json_market = market.value

    params["market"] = json_market

    params["category"] = category

    params["city"] = city

    params["seniority"] = seniority

    params["contractType"] = contract_type

    params["remote"] = remote

    params["salaryMin"] = salary_min

    params["q"] = q

    params["page"] = page

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/jobs",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[GetJobsResponse200]:
    if response.status_code == 200:
        response_200 = GetJobsResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[GetJobsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    market: Union[Unset, GetJobsMarket] = UNSET,
    category: Union[Unset, str] = UNSET,
    city: Union[Unset, str] = UNSET,
    seniority: Union[Unset, str] = UNSET,
    contract_type: Union[Unset, str] = UNSET,
    remote: Union[Unset, bool] = UNSET,
    salary_min: Union[Unset, int] = UNSET,
    q: Union[Unset, str] = UNSET,
    page: Union[Unset, int] = 1,
    limit: Union[Unset, int] = 30,
) -> Response[GetJobsResponse200]:
    """Search jobs

     Public read. Filter by category, city, market, seniority, contract, salary, remote, free-text q.
    Returns the standard {data, pagination, meta} envelope. Cached for 1800s at the edge.

    Args:
        market (Union[Unset, GetJobsMarket]):
        category (Union[Unset, str]): Comma-separated category slugs
        city (Union[Unset, str]): Comma-separated city slugs
        seniority (Union[Unset, str]):
        contract_type (Union[Unset, str]):
        remote (Union[Unset, bool]):
        salary_min (Union[Unset, int]):
        q (Union[Unset, str]): Free-text search across title + description + company
        page (Union[Unset, int]):  Default: 1.
        limit (Union[Unset, int]):  Default: 30.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetJobsResponse200]
    """

    kwargs = _get_kwargs(
        market=market,
        category=category,
        city=city,
        seniority=seniority,
        contract_type=contract_type,
        remote=remote,
        salary_min=salary_min,
        q=q,
        page=page,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    market: Union[Unset, GetJobsMarket] = UNSET,
    category: Union[Unset, str] = UNSET,
    city: Union[Unset, str] = UNSET,
    seniority: Union[Unset, str] = UNSET,
    contract_type: Union[Unset, str] = UNSET,
    remote: Union[Unset, bool] = UNSET,
    salary_min: Union[Unset, int] = UNSET,
    q: Union[Unset, str] = UNSET,
    page: Union[Unset, int] = 1,
    limit: Union[Unset, int] = 30,
) -> Optional[GetJobsResponse200]:
    """Search jobs

     Public read. Filter by category, city, market, seniority, contract, salary, remote, free-text q.
    Returns the standard {data, pagination, meta} envelope. Cached for 1800s at the edge.

    Args:
        market (Union[Unset, GetJobsMarket]):
        category (Union[Unset, str]): Comma-separated category slugs
        city (Union[Unset, str]): Comma-separated city slugs
        seniority (Union[Unset, str]):
        contract_type (Union[Unset, str]):
        remote (Union[Unset, bool]):
        salary_min (Union[Unset, int]):
        q (Union[Unset, str]): Free-text search across title + description + company
        page (Union[Unset, int]):  Default: 1.
        limit (Union[Unset, int]):  Default: 30.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetJobsResponse200
    """

    return sync_detailed(
        client=client,
        market=market,
        category=category,
        city=city,
        seniority=seniority,
        contract_type=contract_type,
        remote=remote,
        salary_min=salary_min,
        q=q,
        page=page,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    market: Union[Unset, GetJobsMarket] = UNSET,
    category: Union[Unset, str] = UNSET,
    city: Union[Unset, str] = UNSET,
    seniority: Union[Unset, str] = UNSET,
    contract_type: Union[Unset, str] = UNSET,
    remote: Union[Unset, bool] = UNSET,
    salary_min: Union[Unset, int] = UNSET,
    q: Union[Unset, str] = UNSET,
    page: Union[Unset, int] = 1,
    limit: Union[Unset, int] = 30,
) -> Response[GetJobsResponse200]:
    """Search jobs

     Public read. Filter by category, city, market, seniority, contract, salary, remote, free-text q.
    Returns the standard {data, pagination, meta} envelope. Cached for 1800s at the edge.

    Args:
        market (Union[Unset, GetJobsMarket]):
        category (Union[Unset, str]): Comma-separated category slugs
        city (Union[Unset, str]): Comma-separated city slugs
        seniority (Union[Unset, str]):
        contract_type (Union[Unset, str]):
        remote (Union[Unset, bool]):
        salary_min (Union[Unset, int]):
        q (Union[Unset, str]): Free-text search across title + description + company
        page (Union[Unset, int]):  Default: 1.
        limit (Union[Unset, int]):  Default: 30.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetJobsResponse200]
    """

    kwargs = _get_kwargs(
        market=market,
        category=category,
        city=city,
        seniority=seniority,
        contract_type=contract_type,
        remote=remote,
        salary_min=salary_min,
        q=q,
        page=page,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    market: Union[Unset, GetJobsMarket] = UNSET,
    category: Union[Unset, str] = UNSET,
    city: Union[Unset, str] = UNSET,
    seniority: Union[Unset, str] = UNSET,
    contract_type: Union[Unset, str] = UNSET,
    remote: Union[Unset, bool] = UNSET,
    salary_min: Union[Unset, int] = UNSET,
    q: Union[Unset, str] = UNSET,
    page: Union[Unset, int] = 1,
    limit: Union[Unset, int] = 30,
) -> Optional[GetJobsResponse200]:
    """Search jobs

     Public read. Filter by category, city, market, seniority, contract, salary, remote, free-text q.
    Returns the standard {data, pagination, meta} envelope. Cached for 1800s at the edge.

    Args:
        market (Union[Unset, GetJobsMarket]):
        category (Union[Unset, str]): Comma-separated category slugs
        city (Union[Unset, str]): Comma-separated city slugs
        seniority (Union[Unset, str]):
        contract_type (Union[Unset, str]):
        remote (Union[Unset, bool]):
        salary_min (Union[Unset, int]):
        q (Union[Unset, str]): Free-text search across title + description + company
        page (Union[Unset, int]):  Default: 1.
        limit (Union[Unset, int]):  Default: 30.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetJobsResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
            market=market,
            category=category,
            city=city,
            seniority=seniority,
            contract_type=contract_type,
            remote=remote,
            salary_min=salary_min,
            q=q,
            page=page,
            limit=limit,
        )
    ).parsed
