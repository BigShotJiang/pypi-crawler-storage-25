from enum import Enum


class JobStatus(str, Enum):
    APPROVED = "APPROVED"
    EXPIRED = "EXPIRED"

    def __str__(self) -> str:
        return str(self.value)
