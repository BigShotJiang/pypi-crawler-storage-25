from enum import Enum


class ProfileVisibility(str, Enum):
    EMPLOYERS_ONLY = "EMPLOYERS_ONLY"
    PRIVATE = "PRIVATE"
    PUBLIC = "PUBLIC"

    def __str__(self) -> str:
        return str(self.value)
