from enum import Enum


class GetCompaniesMarket(str, Enum):
    FRANCE = "france"
    LATAM = "latam"
    USA = "usa"

    def __str__(self) -> str:
        return str(self.value)
