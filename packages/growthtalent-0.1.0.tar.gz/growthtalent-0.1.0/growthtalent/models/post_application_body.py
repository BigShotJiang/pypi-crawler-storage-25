from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.apply_via import ApplyVia
from ..types import UNSET, Unset

T = TypeVar("T", bound="PostApplicationBody")


@_attrs_define
class PostApplicationBody:
    """
    Example:
        {'jobSlugOrId': 'head-of-growth-the-mobile-first-company', 'message': 'Hi — I built growth at Spendesk #4 to
            unicorn. Would love to chat about Allo.', 'via': 'magic'}

    Attributes:
        job_slug_or_id (str):
        message (Union[None, Unset, str]):
        via (Union[Unset, ApplyVia]): magic: we email the company directly with the candidate profile + cover note.
            external: agent records the apply but the user is still expected to click through to applyUrl.
    """

    job_slug_or_id: str
    message: Union[None, Unset, str] = UNSET
    via: Union[Unset, ApplyVia] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        job_slug_or_id = self.job_slug_or_id

        message: Union[None, Unset, str]
        if isinstance(self.message, Unset):
            message = UNSET
        else:
            message = self.message

        via: Union[Unset, str] = UNSET
        if not isinstance(self.via, Unset):
            via = self.via.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "jobSlugOrId": job_slug_or_id,
            }
        )
        if message is not UNSET:
            field_dict["message"] = message
        if via is not UNSET:
            field_dict["via"] = via

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        job_slug_or_id = d.pop("jobSlugOrId")

        def _parse_message(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        message = _parse_message(d.pop("message", UNSET))

        _via = d.pop("via", UNSET)
        via: Union[Unset, ApplyVia]
        if isinstance(_via, Unset):
            via = UNSET
        else:
            via = ApplyVia(_via)

        post_application_body = cls(
            job_slug_or_id=job_slug_or_id,
            message=message,
            via=via,
        )

        post_application_body.additional_properties = d
        return post_application_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
