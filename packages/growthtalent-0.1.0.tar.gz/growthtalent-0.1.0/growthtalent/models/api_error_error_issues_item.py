from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="ApiErrorErrorIssuesItem")


@_attrs_define
class ApiErrorErrorIssuesItem:
    """
    Attributes:
        path (list[Union[float, str]]):
        message (str):
        code (str):
    """

    path: list[Union[float, str]]
    message: str
    code: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        path = []
        for path_item_data in self.path:
            path_item: Union[float, str]
            path_item = path_item_data
            path.append(path_item)

        message = self.message

        code = self.code

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "path": path,
                "message": message,
                "code": code,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        path = []
        _path = d.pop("path")
        for path_item_data in _path:

            def _parse_path_item(data: object) -> Union[float, str]:
                return cast(Union[float, str], data)

            path_item = _parse_path_item(path_item_data)

            path.append(path_item)

        message = d.pop("message")

        code = d.pop("code")

        api_error_error_issues_item = cls(
            path=path,
            message=message,
            code=code,
        )

        api_error_error_issues_item.additional_properties = d
        return api_error_error_issues_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
