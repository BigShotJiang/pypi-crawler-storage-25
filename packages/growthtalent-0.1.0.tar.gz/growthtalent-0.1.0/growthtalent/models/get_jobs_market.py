from enum import Enum


class GetJobsMarket(str, Enum):
    FRANCE = "france"
    LATAM = "latam"
    USA = "usa"

    def __str__(self) -> str:
        return str(self.value)
