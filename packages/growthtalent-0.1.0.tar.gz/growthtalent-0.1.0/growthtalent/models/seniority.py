from enum import Enum


class Seniority(str, Enum):
    C_LEVEL = "C_LEVEL"
    DIRECTOR = "DIRECTOR"
    INTERN = "INTERN"
    JUNIOR = "JUNIOR"
    LEAD = "LEAD"
    MANAGER = "MANAGER"
    MID = "MID"
    SENIOR = "SENIOR"
    VP = "VP"

    def __str__(self) -> str:
        return str(self.value)
