from collections.abc import Mapping
from typing import Any, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.contract_type import ContractType
from ..models.market import Market
from ..models.remote import Remote
from ..models.seniority import Seniority
from ..types import UNSET, Unset

T = TypeVar("T", bound="PostJobBody")


@_attrs_define
class PostJobBody:
    """
    Example:
        {'title': 'Head of Growth', 'category': 'head-of-growth', 'applyUrl': 'https://jobs.example.com/head-of-growth',
            'description': "We're hiring a Head of Growth to own acquisition, activation, and retention across paid,
            organic, and lifecycle channels. 5+ years scaling a B2B or PLG product from $1M to $10M+ ARR. Mixpanel, paid
            ads, attribution.", 'seniority': 'VP', 'remote': 'HYBRID', 'market': 'USA', 'city': 'New York', 'country': 'US',
            'salaryMin': 180000, 'salaryMax': 240000, 'salaryCurrency': 'USD'}

    Attributes:
        title (str):
        category (str):
        apply_url (str):
        description (str):
        seniority (Union[Unset, Seniority]): Career level
        contract_type (Union[Unset, ContractType]):
        remote (Union[Unset, Remote]): Work location model
        market (Union[Unset, Market]):
        city (Union[Unset, str]):
        country (Union[Unset, str]):
        salary_min (Union[Unset, int]):
        salary_max (Union[Unset, int]):
        salary_currency (Union[Unset, str]):
    """

    title: str
    category: str
    apply_url: str
    description: str
    seniority: Union[Unset, Seniority] = UNSET
    contract_type: Union[Unset, ContractType] = UNSET
    remote: Union[Unset, Remote] = UNSET
    market: Union[Unset, Market] = UNSET
    city: Union[Unset, str] = UNSET
    country: Union[Unset, str] = UNSET
    salary_min: Union[Unset, int] = UNSET
    salary_max: Union[Unset, int] = UNSET
    salary_currency: Union[Unset, str] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        title = self.title

        category = self.category

        apply_url = self.apply_url

        description = self.description

        seniority: Union[Unset, str] = UNSET
        if not isinstance(self.seniority, Unset):
            seniority = self.seniority.value

        contract_type: Union[Unset, str] = UNSET
        if not isinstance(self.contract_type, Unset):
            contract_type = self.contract_type.value

        remote: Union[Unset, str] = UNSET
        if not isinstance(self.remote, Unset):
            remote = self.remote.value

        market: Union[Unset, str] = UNSET
        if not isinstance(self.market, Unset):
            market = self.market.value

        city = self.city

        country = self.country

        salary_min = self.salary_min

        salary_max = self.salary_max

        salary_currency = self.salary_currency

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "title": title,
                "category": category,
                "applyUrl": apply_url,
                "description": description,
            }
        )
        if seniority is not UNSET:
            field_dict["seniority"] = seniority
        if contract_type is not UNSET:
            field_dict["contractType"] = contract_type
        if remote is not UNSET:
            field_dict["remote"] = remote
        if market is not UNSET:
            field_dict["market"] = market
        if city is not UNSET:
            field_dict["city"] = city
        if country is not UNSET:
            field_dict["country"] = country
        if salary_min is not UNSET:
            field_dict["salaryMin"] = salary_min
        if salary_max is not UNSET:
            field_dict["salaryMax"] = salary_max
        if salary_currency is not UNSET:
            field_dict["salaryCurrency"] = salary_currency

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        title = d.pop("title")

        category = d.pop("category")

        apply_url = d.pop("applyUrl")

        description = d.pop("description")

        _seniority = d.pop("seniority", UNSET)
        seniority: Union[Unset, Seniority]
        if isinstance(_seniority, Unset):
            seniority = UNSET
        else:
            seniority = Seniority(_seniority)

        _contract_type = d.pop("contractType", UNSET)
        contract_type: Union[Unset, ContractType]
        if isinstance(_contract_type, Unset):
            contract_type = UNSET
        else:
            contract_type = ContractType(_contract_type)

        _remote = d.pop("remote", UNSET)
        remote: Union[Unset, Remote]
        if isinstance(_remote, Unset):
            remote = UNSET
        else:
            remote = Remote(_remote)

        _market = d.pop("market", UNSET)
        market: Union[Unset, Market]
        if isinstance(_market, Unset):
            market = UNSET
        else:
            market = Market(_market)

        city = d.pop("city", UNSET)

        country = d.pop("country", UNSET)

        salary_min = d.pop("salaryMin", UNSET)

        salary_max = d.pop("salaryMax", UNSET)

        salary_currency = d.pop("salaryCurrency", UNSET)

        post_job_body = cls(
            title=title,
            category=category,
            apply_url=apply_url,
            description=description,
            seniority=seniority,
            contract_type=contract_type,
            remote=remote,
            market=market,
            city=city,
            country=country,
            salary_min=salary_min,
            salary_max=salary_max,
            salary_currency=salary_currency,
        )

        post_job_body.additional_properties = d
        return post_job_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
