from enum import Enum


class Market(str, Enum):
    FRANCE = "FRANCE"
    LATAM = "LATAM"
    USA = "USA"

    def __str__(self) -> str:
        return str(self.value)
