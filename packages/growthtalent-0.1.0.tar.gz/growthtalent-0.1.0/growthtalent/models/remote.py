from enum import Enum


class Remote(str, Enum):
    HYBRID = "HYBRID"
    ONSITE = "ONSITE"
    REMOTE = "REMOTE"

    def __str__(self) -> str:
        return str(self.value)
