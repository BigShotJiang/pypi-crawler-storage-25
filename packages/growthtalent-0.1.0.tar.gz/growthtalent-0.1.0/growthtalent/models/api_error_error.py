from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.api_error_error_issues_item import ApiErrorErrorIssuesItem


T = TypeVar("T", bound="ApiErrorError")


@_attrs_define
class ApiErrorError:
    """
    Attributes:
        code (str):  Example: validation_error.
        message (str):  Example: Invalid request body.
        issues (Union[Unset, list['ApiErrorErrorIssuesItem']]): Present on 422 validation errors — zod issue list.
        required_scope (Union[Unset, str]):
        key_scopes (Union[Unset, list[str]]):
        retry_after_sec (Union[Unset, float]):
    """

    code: str
    message: str
    issues: Union[Unset, list["ApiErrorErrorIssuesItem"]] = UNSET
    required_scope: Union[Unset, str] = UNSET
    key_scopes: Union[Unset, list[str]] = UNSET
    retry_after_sec: Union[Unset, float] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        code = self.code

        message = self.message

        issues: Union[Unset, list[dict[str, Any]]] = UNSET
        if not isinstance(self.issues, Unset):
            issues = []
            for issues_item_data in self.issues:
                issues_item = issues_item_data.to_dict()
                issues.append(issues_item)

        required_scope = self.required_scope

        key_scopes: Union[Unset, list[str]] = UNSET
        if not isinstance(self.key_scopes, Unset):
            key_scopes = self.key_scopes

        retry_after_sec = self.retry_after_sec

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "code": code,
                "message": message,
            }
        )
        if issues is not UNSET:
            field_dict["issues"] = issues
        if required_scope is not UNSET:
            field_dict["requiredScope"] = required_scope
        if key_scopes is not UNSET:
            field_dict["keyScopes"] = key_scopes
        if retry_after_sec is not UNSET:
            field_dict["retryAfterSec"] = retry_after_sec

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_error_error_issues_item import ApiErrorErrorIssuesItem

        d = dict(src_dict)
        code = d.pop("code")

        message = d.pop("message")

        issues = []
        _issues = d.pop("issues", UNSET)
        for issues_item_data in _issues or []:
            issues_item = ApiErrorErrorIssuesItem.from_dict(issues_item_data)

            issues.append(issues_item)

        required_scope = d.pop("requiredScope", UNSET)

        key_scopes = cast(list[str], d.pop("keyScopes", UNSET))

        retry_after_sec = d.pop("retryAfterSec", UNSET)

        api_error_error = cls(
            code=code,
            message=message,
            issues=issues,
            required_scope=required_scope,
            key_scopes=key_scopes,
            retry_after_sec=retry_after_sec,
        )

        api_error_error.additional_properties = d
        return api_error_error

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
