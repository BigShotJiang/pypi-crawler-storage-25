from enum import Enum


class ApplyVia(str, Enum):
    EXTERNAL = "external"
    MAGIC = "magic"

    def __str__(self) -> str:
        return str(self.value)
