from enum import Enum


class TeamScope(str, Enum):
    SOLO = "solo"
    VALUE_1 = "1-5"
    VALUE_2 = "5-15"
    VALUE_3 = "15-50"
    VALUE_4 = "50+"

    def __str__(self) -> str:
        return str(self.value)
