from enum import Enum


class ContractType(str, Enum):
    CONTRACT = "CONTRACT"
    FREELANCE = "FREELANCE"
    FULL_TIME = "FULL_TIME"
    INTERNSHIP = "INTERNSHIP"
    PART_TIME = "PART_TIME"

    def __str__(self) -> str:
        return str(self.value)
