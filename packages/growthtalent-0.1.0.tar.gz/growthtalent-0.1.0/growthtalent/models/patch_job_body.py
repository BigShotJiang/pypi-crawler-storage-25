from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.contract_type import ContractType
from ..models.job_status import JobStatus
from ..models.remote import Remote
from ..models.seniority import Seniority
from ..types import UNSET, Unset

T = TypeVar("T", bound="PatchJobBody")


@_attrs_define
class PatchJobBody:
    """
    Example:
        {'status': 'EXPIRED'}

    Attributes:
        title (Union[Unset, str]):
        description (Union[Unset, str]):
        apply_url (Union[Unset, str]):
        salary_min (Union[None, Unset, int]):
        salary_max (Union[None, Unset, int]):
        salary_currency (Union[None, Unset, str]):
        seniority (Union[Unset, Seniority]): Career level
        remote (Union[Unset, Remote]): Work location model
        contract_type (Union[Unset, ContractType]):
        status (Union[Unset, JobStatus]): Use EXPIRED to close a job, APPROVED to reopen it.
        city (Union[None, Unset, str]):
        country (Union[None, Unset, str]):
    """

    title: Union[Unset, str] = UNSET
    description: Union[Unset, str] = UNSET
    apply_url: Union[Unset, str] = UNSET
    salary_min: Union[None, Unset, int] = UNSET
    salary_max: Union[None, Unset, int] = UNSET
    salary_currency: Union[None, Unset, str] = UNSET
    seniority: Union[Unset, Seniority] = UNSET
    remote: Union[Unset, Remote] = UNSET
    contract_type: Union[Unset, ContractType] = UNSET
    status: Union[Unset, JobStatus] = UNSET
    city: Union[None, Unset, str] = UNSET
    country: Union[None, Unset, str] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        title = self.title

        description = self.description

        apply_url = self.apply_url

        salary_min: Union[None, Unset, int]
        if isinstance(self.salary_min, Unset):
            salary_min = UNSET
        else:
            salary_min = self.salary_min

        salary_max: Union[None, Unset, int]
        if isinstance(self.salary_max, Unset):
            salary_max = UNSET
        else:
            salary_max = self.salary_max

        salary_currency: Union[None, Unset, str]
        if isinstance(self.salary_currency, Unset):
            salary_currency = UNSET
        else:
            salary_currency = self.salary_currency

        seniority: Union[Unset, str] = UNSET
        if not isinstance(self.seniority, Unset):
            seniority = self.seniority.value

        remote: Union[Unset, str] = UNSET
        if not isinstance(self.remote, Unset):
            remote = self.remote.value

        contract_type: Union[Unset, str] = UNSET
        if not isinstance(self.contract_type, Unset):
            contract_type = self.contract_type.value

        status: Union[Unset, str] = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        city: Union[None, Unset, str]
        if isinstance(self.city, Unset):
            city = UNSET
        else:
            city = self.city

        country: Union[None, Unset, str]
        if isinstance(self.country, Unset):
            country = UNSET
        else:
            country = self.country

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if title is not UNSET:
            field_dict["title"] = title
        if description is not UNSET:
            field_dict["description"] = description
        if apply_url is not UNSET:
            field_dict["applyUrl"] = apply_url
        if salary_min is not UNSET:
            field_dict["salaryMin"] = salary_min
        if salary_max is not UNSET:
            field_dict["salaryMax"] = salary_max
        if salary_currency is not UNSET:
            field_dict["salaryCurrency"] = salary_currency
        if seniority is not UNSET:
            field_dict["seniority"] = seniority
        if remote is not UNSET:
            field_dict["remote"] = remote
        if contract_type is not UNSET:
            field_dict["contractType"] = contract_type
        if status is not UNSET:
            field_dict["status"] = status
        if city is not UNSET:
            field_dict["city"] = city
        if country is not UNSET:
            field_dict["country"] = country

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        title = d.pop("title", UNSET)

        description = d.pop("description", UNSET)

        apply_url = d.pop("applyUrl", UNSET)

        def _parse_salary_min(data: object) -> Union[None, Unset, int]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, int], data)

        salary_min = _parse_salary_min(d.pop("salaryMin", UNSET))

        def _parse_salary_max(data: object) -> Union[None, Unset, int]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, int], data)

        salary_max = _parse_salary_max(d.pop("salaryMax", UNSET))

        def _parse_salary_currency(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        salary_currency = _parse_salary_currency(d.pop("salaryCurrency", UNSET))

        _seniority = d.pop("seniority", UNSET)
        seniority: Union[Unset, Seniority]
        if isinstance(_seniority, Unset):
            seniority = UNSET
        else:
            seniority = Seniority(_seniority)

        _remote = d.pop("remote", UNSET)
        remote: Union[Unset, Remote]
        if isinstance(_remote, Unset):
            remote = UNSET
        else:
            remote = Remote(_remote)

        _contract_type = d.pop("contractType", UNSET)
        contract_type: Union[Unset, ContractType]
        if isinstance(_contract_type, Unset):
            contract_type = UNSET
        else:
            contract_type = ContractType(_contract_type)

        _status = d.pop("status", UNSET)
        status: Union[Unset, JobStatus]
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = JobStatus(_status)

        def _parse_city(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        city = _parse_city(d.pop("city", UNSET))

        def _parse_country(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        country = _parse_country(d.pop("country", UNSET))

        patch_job_body = cls(
            title=title,
            description=description,
            apply_url=apply_url,
            salary_min=salary_min,
            salary_max=salary_max,
            salary_currency=salary_currency,
            seniority=seniority,
            remote=remote,
            contract_type=contract_type,
            status=status,
            city=city,
            country=country,
        )

        patch_job_body.additional_properties = d
        return patch_job_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
