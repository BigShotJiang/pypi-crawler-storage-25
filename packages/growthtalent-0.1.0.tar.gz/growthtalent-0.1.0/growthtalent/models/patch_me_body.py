from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.market import Market
from ..models.profile_visibility import ProfileVisibility
from ..models.seniority import Seniority
from ..models.team_scope import TeamScope
from ..types import UNSET, Unset

T = TypeVar("T", bound="PatchMeBody")


@_attrs_define
class PatchMeBody:
    """
    Example:
        {'isOpenToWork': True, 'headline': 'VP Growth at Spendesk → CEO at The Mobile First Company', 'salaryMin':
            200000, 'salaryMax': 280000, 'salaryCurrency': 'USD', 'tools': ['HubSpot', 'Mixpanel', 'Segment', 'Braze']}

    Attributes:
        name (Union[None, Unset, str]):
        headline (Union[None, Unset, str]):
        bio (Union[None, Unset, str]):
        current_title (Union[None, Unset, str]):
        city (Union[None, Unset, str]):
        country (Union[None, Unset, str]):
        linkedin_url (Union[None, Unset, str]):
        resume_url (Union[None, Unset, str]):
        reports_to (Union[None, Unset, str]):
        salary_min (Union[None, Unset, int]):
        salary_max (Union[None, Unset, int]):
        salary_currency (Union[None, Unset, str]):
        is_open_to_work (Union[Unset, bool]):
        is_in_growth_team (Union[Unset, bool]):
        seniority (Union[Unset, Seniority]): Career level
        profile_visibility (Union[Unset, ProfileVisibility]):
        team_scope (Union[Unset, TeamScope]):
        tools (Union[Unset, list[str]]):
        markets (Union[Unset, list[Market]]):
    """

    name: Union[None, Unset, str] = UNSET
    headline: Union[None, Unset, str] = UNSET
    bio: Union[None, Unset, str] = UNSET
    current_title: Union[None, Unset, str] = UNSET
    city: Union[None, Unset, str] = UNSET
    country: Union[None, Unset, str] = UNSET
    linkedin_url: Union[None, Unset, str] = UNSET
    resume_url: Union[None, Unset, str] = UNSET
    reports_to: Union[None, Unset, str] = UNSET
    salary_min: Union[None, Unset, int] = UNSET
    salary_max: Union[None, Unset, int] = UNSET
    salary_currency: Union[None, Unset, str] = UNSET
    is_open_to_work: Union[Unset, bool] = UNSET
    is_in_growth_team: Union[Unset, bool] = UNSET
    seniority: Union[Unset, Seniority] = UNSET
    profile_visibility: Union[Unset, ProfileVisibility] = UNSET
    team_scope: Union[Unset, TeamScope] = UNSET
    tools: Union[Unset, list[str]] = UNSET
    markets: Union[Unset, list[Market]] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name: Union[None, Unset, str]
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        headline: Union[None, Unset, str]
        if isinstance(self.headline, Unset):
            headline = UNSET
        else:
            headline = self.headline

        bio: Union[None, Unset, str]
        if isinstance(self.bio, Unset):
            bio = UNSET
        else:
            bio = self.bio

        current_title: Union[None, Unset, str]
        if isinstance(self.current_title, Unset):
            current_title = UNSET
        else:
            current_title = self.current_title

        city: Union[None, Unset, str]
        if isinstance(self.city, Unset):
            city = UNSET
        else:
            city = self.city

        country: Union[None, Unset, str]
        if isinstance(self.country, Unset):
            country = UNSET
        else:
            country = self.country

        linkedin_url: Union[None, Unset, str]
        if isinstance(self.linkedin_url, Unset):
            linkedin_url = UNSET
        else:
            linkedin_url = self.linkedin_url

        resume_url: Union[None, Unset, str]
        if isinstance(self.resume_url, Unset):
            resume_url = UNSET
        else:
            resume_url = self.resume_url

        reports_to: Union[None, Unset, str]
        if isinstance(self.reports_to, Unset):
            reports_to = UNSET
        else:
            reports_to = self.reports_to

        salary_min: Union[None, Unset, int]
        if isinstance(self.salary_min, Unset):
            salary_min = UNSET
        else:
            salary_min = self.salary_min

        salary_max: Union[None, Unset, int]
        if isinstance(self.salary_max, Unset):
            salary_max = UNSET
        else:
            salary_max = self.salary_max

        salary_currency: Union[None, Unset, str]
        if isinstance(self.salary_currency, Unset):
            salary_currency = UNSET
        else:
            salary_currency = self.salary_currency

        is_open_to_work = self.is_open_to_work

        is_in_growth_team = self.is_in_growth_team

        seniority: Union[Unset, str] = UNSET
        if not isinstance(self.seniority, Unset):
            seniority = self.seniority.value

        profile_visibility: Union[Unset, str] = UNSET
        if not isinstance(self.profile_visibility, Unset):
            profile_visibility = self.profile_visibility.value

        team_scope: Union[Unset, str] = UNSET
        if not isinstance(self.team_scope, Unset):
            team_scope = self.team_scope.value

        tools: Union[Unset, list[str]] = UNSET
        if not isinstance(self.tools, Unset):
            tools = self.tools

        markets: Union[Unset, list[str]] = UNSET
        if not isinstance(self.markets, Unset):
            markets = []
            for markets_item_data in self.markets:
                markets_item = markets_item_data.value
                markets.append(markets_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if headline is not UNSET:
            field_dict["headline"] = headline
        if bio is not UNSET:
            field_dict["bio"] = bio
        if current_title is not UNSET:
            field_dict["currentTitle"] = current_title
        if city is not UNSET:
            field_dict["city"] = city
        if country is not UNSET:
            field_dict["country"] = country
        if linkedin_url is not UNSET:
            field_dict["linkedinUrl"] = linkedin_url
        if resume_url is not UNSET:
            field_dict["resumeUrl"] = resume_url
        if reports_to is not UNSET:
            field_dict["reportsTo"] = reports_to
        if salary_min is not UNSET:
            field_dict["salaryMin"] = salary_min
        if salary_max is not UNSET:
            field_dict["salaryMax"] = salary_max
        if salary_currency is not UNSET:
            field_dict["salaryCurrency"] = salary_currency
        if is_open_to_work is not UNSET:
            field_dict["isOpenToWork"] = is_open_to_work
        if is_in_growth_team is not UNSET:
            field_dict["isInGrowthTeam"] = is_in_growth_team
        if seniority is not UNSET:
            field_dict["seniority"] = seniority
        if profile_visibility is not UNSET:
            field_dict["profileVisibility"] = profile_visibility
        if team_scope is not UNSET:
            field_dict["teamScope"] = team_scope
        if tools is not UNSET:
            field_dict["tools"] = tools
        if markets is not UNSET:
            field_dict["markets"] = markets

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_name(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_headline(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        headline = _parse_headline(d.pop("headline", UNSET))

        def _parse_bio(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        bio = _parse_bio(d.pop("bio", UNSET))

        def _parse_current_title(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        current_title = _parse_current_title(d.pop("currentTitle", UNSET))

        def _parse_city(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        city = _parse_city(d.pop("city", UNSET))

        def _parse_country(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        country = _parse_country(d.pop("country", UNSET))

        def _parse_linkedin_url(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        linkedin_url = _parse_linkedin_url(d.pop("linkedinUrl", UNSET))

        def _parse_resume_url(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        resume_url = _parse_resume_url(d.pop("resumeUrl", UNSET))

        def _parse_reports_to(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        reports_to = _parse_reports_to(d.pop("reportsTo", UNSET))

        def _parse_salary_min(data: object) -> Union[None, Unset, int]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, int], data)

        salary_min = _parse_salary_min(d.pop("salaryMin", UNSET))

        def _parse_salary_max(data: object) -> Union[None, Unset, int]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, int], data)

        salary_max = _parse_salary_max(d.pop("salaryMax", UNSET))

        def _parse_salary_currency(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        salary_currency = _parse_salary_currency(d.pop("salaryCurrency", UNSET))

        is_open_to_work = d.pop("isOpenToWork", UNSET)

        is_in_growth_team = d.pop("isInGrowthTeam", UNSET)

        _seniority = d.pop("seniority", UNSET)
        seniority: Union[Unset, Seniority]
        if isinstance(_seniority, Unset):
            seniority = UNSET
        else:
            seniority = Seniority(_seniority)

        _profile_visibility = d.pop("profileVisibility", UNSET)
        profile_visibility: Union[Unset, ProfileVisibility]
        if isinstance(_profile_visibility, Unset):
            profile_visibility = UNSET
        else:
            profile_visibility = ProfileVisibility(_profile_visibility)

        _team_scope = d.pop("teamScope", UNSET)
        team_scope: Union[Unset, TeamScope]
        if isinstance(_team_scope, Unset):
            team_scope = UNSET
        else:
            team_scope = TeamScope(_team_scope)

        tools = cast(list[str], d.pop("tools", UNSET))

        markets = []
        _markets = d.pop("markets", UNSET)
        for markets_item_data in _markets or []:
            markets_item = Market(markets_item_data)

            markets.append(markets_item)

        patch_me_body = cls(
            name=name,
            headline=headline,
            bio=bio,
            current_title=current_title,
            city=city,
            country=country,
            linkedin_url=linkedin_url,
            resume_url=resume_url,
            reports_to=reports_to,
            salary_min=salary_min,
            salary_max=salary_max,
            salary_currency=salary_currency,
            is_open_to_work=is_open_to_work,
            is_in_growth_team=is_in_growth_team,
            seniority=seniority,
            profile_visibility=profile_visibility,
            team_scope=team_scope,
            tools=tools,
            markets=markets,
        )

        patch_me_body.additional_properties = d
        return patch_me_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
