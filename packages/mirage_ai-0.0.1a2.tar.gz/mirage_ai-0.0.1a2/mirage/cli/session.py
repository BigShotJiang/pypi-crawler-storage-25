# ========= Copyright 2026 @ Strukto.AI All Rights Reserved. =========
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ========= Copyright 2026 @ Strukto.AI All Rights Reserved. =========

import typer

from mirage.cli.client import make_client
from mirage.cli.output import emit, handle_response

app = typer.Typer(no_args_is_help=True, help="Manage workspace sessions.")


@app.command("create")
def create_cmd(
    workspace_id: str = typer.Argument(...),
    session_id: str | None = typer.Option(None,
                                          "--id",
                                          help="Explicit session id."),
) -> None:
    body: dict = {}
    if session_id:
        body["session_id"] = session_id
    with make_client() as client:
        client.ensure_running(allow_spawn=False)
        r = client.request("POST",
                           f"/v1/workspaces/{workspace_id}/sessions",
                           json=body)
    emit(handle_response(r))


@app.command("list")
def list_cmd(workspace_id: str = typer.Argument(...)) -> None:
    with make_client() as client:
        client.ensure_running(allow_spawn=False)
        r = client.request("GET", f"/v1/workspaces/{workspace_id}/sessions")
    emit(handle_response(r))


@app.command("delete")
def delete_cmd(
        workspace_id: str = typer.Argument(...),
        session_id: str = typer.Argument(...),
) -> None:
    with make_client() as client:
        client.ensure_running(allow_spawn=False)
        r = client.request(
            "DELETE", f"/v1/workspaces/{workspace_id}/sessions/{session_id}")
    emit(handle_response(r))
