# ========= Copyright 2026 @ Strukto.AI All Rights Reserved. =========
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ========= Copyright 2026 @ Strukto.AI All Rights Reserved. =========

import os

from mirage.server import build_app

_persist_dir = os.environ.get("MIRAGE_PERSIST_DIR") or None
_idle_grace = float(os.environ.get("MIRAGE_IDLE_GRACE_SECONDS", "30"))

app = build_app(idle_grace_seconds=_idle_grace, persist_dir=_persist_dir)
