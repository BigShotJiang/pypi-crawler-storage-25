# ========= Copyright 2026 @ Strukto.AI All Rights Reserved. =========
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ========= Copyright 2026 @ Strukto.AI All Rights Reserved. =========

from mirage.cache.file import CacheEntry, FileCacheMixin
from mirage.cache.index import IndexCacheStore, RAMIndexCacheStore
from mirage.cache.lock import KeyLockMixin

__all__ = [
    "CacheEntry",
    "FileCacheMixin",
    "IndexCacheStore",
    "KeyLockMixin",
    "RAMIndexCacheStore",
    "RedisIndexCacheStore",
]


def __getattr__(name: str):
    if name == "RedisIndexCacheStore":
        from mirage.cache.index import RedisIndexCacheStore
        return RedisIndexCacheStore
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
