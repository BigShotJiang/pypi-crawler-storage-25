# ========= Copyright 2026 @ Strukto.AI All Rights Reserved. =========
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ========= Copyright 2026 @ Strukto.AI All Rights Reserved. =========

import textwrap
from collections.abc import AsyncIterator

from mirage.accessor.disk import DiskAccessor
from mirage.cache.index import IndexCacheStore
from mirage.commands.builtin.utils.stream import _read_stdin_async
from mirage.commands.registry import command
from mirage.commands.spec import SPECS
from mirage.core.disk.glob import resolve_glob
from mirage.core.disk.read import read_bytes
from mirage.io.types import ByteSource, IOResult
from mirage.types import PathSpec


def _fmt_text(text: str, width: int) -> str:
    paragraphs = text.split("\n\n")
    formatted = []
    for para in paragraphs:
        para = para.strip()
        if para:
            formatted.append(textwrap.fill(para, width=width))
        else:
            formatted.append("")
    return "\n\n".join(formatted) + "\n"


@command("fmt", resource="disk", spec=SPECS["fmt"])
async def fmt(
    accessor: DiskAccessor,
    paths: list[PathSpec],
    *texts: str,
    stdin: AsyncIterator[bytes] | bytes | None = None,
    w: str | None = None,
    index: IndexCacheStore = None,
    **_extra: object,
) -> tuple[ByteSource | None, IOResult]:
    width = int(w) if w is not None else 75
    if paths and accessor.root is not None:
        paths = await resolve_glob(accessor, paths, index)
        all_text: list[str] = []
        for p in paths:
            data = (await read_bytes(accessor, p)).decode(errors="replace")
            all_text.append(data)
        return _fmt_text("".join(all_text), width).encode(), IOResult()
    raw = await _read_stdin_async(stdin)
    if raw is None:
        raise ValueError("fmt: missing operand")
    text = raw.decode(errors="replace")
    return _fmt_text(text, width).encode(), IOResult()
