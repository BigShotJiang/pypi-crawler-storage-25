# ========= Copyright 2026 @ Strukto.AI All Rights Reserved. =========
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ========= Copyright 2026 @ Strukto.AI All Rights Reserved. =========

from mirage.accessor.disk import DiskAccessor
from mirage.cache.index import IndexCacheStore
from mirage.commands.registry import command
from mirage.commands.spec import SPECS
from mirage.core.disk.glob import resolve_glob
from mirage.core.disk.read import read_bytes
from mirage.core.filetype.hdf5 import _read_df
from mirage.io.types import ByteSource, IOResult
from mirage.types import PathSpec


@command("file", resource="disk", spec=SPECS["file"], filetype=".hdf5")
@command("file", resource="disk", spec=SPECS["file"], filetype=".h5")
async def file_hdf5(
    accessor: DiskAccessor,
    paths: list[PathSpec],
    *texts: str,
    stdin: bytes | None = None,
    index: IndexCacheStore = None,
    **_extra: object,
) -> tuple[ByteSource | None, IOResult]:
    if accessor.root is None or not paths:
        raise ValueError("file: missing operand")
    paths = await resolve_glob(accessor, paths, index)
    try:
        raw = await read_bytes(accessor, paths[0])
        df = _read_df(raw)
        cols = ", ".join(f"{c}: {df[c].dtype}" for c in df.columns)
        result = (f"hdf5, {len(df)} rows, {len(df.columns)} columns"
                  f" ({cols})")
        return result.encode(), IOResult(reads={paths[0].strip_prefix: raw},
                                         cache=[paths[0].strip_prefix])
    except Exception as e:
        return None, IOResult(
            exit_code=1,
            stderr=f"file: {paths[0].original}: failed to read as hdf5: {e}".
            encode(),
        )
