# ========= Copyright 2026 @ Strukto.AI All Rights Reserved. =========
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ========= Copyright 2026 @ Strukto.AI All Rights Reserved. =========

from collections.abc import AsyncIterator

from mirage.accessor.gdrive import GDriveAccessor
from mirage.commands.builtin.gdrive._provision import file_read_provision
from mirage.commands.registry import command
from mirage.commands.spec import SPECS
from mirage.core.filetype.hdf5 import tail as hdf5_tail
from mirage.core.gdrive.glob import resolve_glob
from mirage.core.gdrive.read import read as gdrive_read
from mirage.io.types import ByteSource, IOResult
from mirage.provision.types import ProvisionResult
from mirage.types import PathSpec


async def tail_hdf5_provision(
    accessor: GDriveAccessor,
    paths: list[PathSpec],
    *texts: str,
    **_extra: object,
) -> ProvisionResult:
    return await file_read_provision(accessor,
                                     paths,
                                     f"tail {paths[0]}" if paths else "tail",
                                     index=_extra.get("index"))


@command("tail",
         resource="gdrive",
         spec=SPECS["tail"],
         filetype=".hdf5",
         provision=tail_hdf5_provision)
@command("tail",
         resource="gdrive",
         spec=SPECS["tail"],
         filetype=".h5",
         provision=tail_hdf5_provision)
async def tail_hdf5(
    accessor: GDriveAccessor,
    paths: list[PathSpec],
    *texts: str,
    stdin: AsyncIterator[bytes] | bytes | None = None,
    n: str | None = None,
    c: str | None = None,
    **_extra: object,
) -> tuple[ByteSource | None, IOResult]:
    if not paths:
        raise ValueError("tail: missing operand")
    paths = await resolve_glob(accessor, paths, _extra.get("index"))
    p = paths[0]
    if c is not None:
        return None, IOResult(
            exit_code=1,
            stderr=b"tail: -c not supported for hdf5 files",
        )
    try:
        lines = int(n) if n is not None else 10
        raw = await gdrive_read(accessor, p, _extra.get("index"))
        result = hdf5_tail(raw, n=lines)
        return result, IOResult(reads={p.strip_prefix: raw},
                                cache=[p.strip_prefix])
    except Exception as e:
        return None, IOResult(
            exit_code=1,
            stderr=f"tail: {p.original}: failed to read as hdf5: {e}".encode(),
        )
