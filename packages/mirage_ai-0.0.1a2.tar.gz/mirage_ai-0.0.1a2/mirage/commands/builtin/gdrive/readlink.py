# ========= Copyright 2026 @ Strukto.AI All Rights Reserved. =========
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ========= Copyright 2026 @ Strukto.AI All Rights Reserved. =========

import posixpath
from collections.abc import AsyncIterator

from mirage.accessor.gdrive import GDriveAccessor
from mirage.commands.registry import command
from mirage.commands.spec import SPECS
from mirage.core.gdrive.glob import resolve_glob
from mirage.io.types import ByteSource, IOResult
from mirage.types import PathSpec


@command("readlink", resource="gdrive", spec=SPECS["readlink"])
async def readlink(
    accessor: GDriveAccessor,
    paths: list[PathSpec],
    *texts: str,
    stdin: AsyncIterator[bytes] | bytes | None = None,
    f: bool = False,
    e: bool = False,
    m: bool = False,
    n: bool = False,
    prefix: str = "",
    **_extra: object,
) -> tuple[ByteSource | None, IOResult]:
    if not paths:
        raise ValueError("readlink: missing operand")
    paths = await resolve_glob(accessor, paths, _extra.get("index"))
    normalize = f or e or m
    results: list[str] = []
    for p in paths:
        vp = prefix + "/" + p.original.lstrip("/") if prefix else p.original
        if normalize:
            vp = posixpath.normpath(vp)
        results.append(vp)
    text = "\n".join(results)
    if not n:
        text += "\n"
    return text.encode(), IOResult()
