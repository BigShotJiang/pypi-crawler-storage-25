"""Antigravity conversation exporter — uses antigravity-history API directly."""

from __future__ import annotations

import hashlib
import json
import logging
import re
from pathlib import Path
from urllib.parse import unquote

logger = logging.getLogger("collector.antigravity_export")

# Cache: cascade_id → content_hash
_last_hashes: dict[str, str] = {}
_ROLE_PREFIX_RE = re.compile(r"^\s*(?:[-*]\s*)?(user|assistant|ai|model|system)\s*:\s*(.*)$", re.I)
_TRANSCRIPT_KEYS = {"transcript", "conversation_transcript", "formatted_transcript"}
_TEXT_KEYS = (
    "response", "assistantResponse", "finalResponse", "outputText", "text",
    "content", "message", "renderedText", "renderedOutput", "full", "value",
)
_TIMESTAMP_KEYS = ("timestamp", "createdAt", "updatedAt", "lastModifiedTime")


def _format_tool_call(tool_name: str, args_json: str) -> tuple[str, str]:
    """Format a toolCall into human-readable (tool_input, content)."""
    try:
        args = json.loads(args_json) if isinstance(args_json, str) else args_json
    except (json.JSONDecodeError, TypeError):
        return (args_json[:300], args_json[:500])

    if not isinstance(args, dict):
        return (str(args)[:300], str(args)[:500])

    # write_to_file / multi_replace_file_content — show file path + content
    if tool_name in ("write_to_file", "multi_replace_file_content", "replace_file_content"):
        target = args.get("TargetFile", "")
        description = args.get("Description", "")
        code = args.get("CodeContent", args.get("ReplacementContent", ""))
        summary = args.get("ArtifactMetadata", {}).get("Summary", "")
        parts = []
        if description:
            parts.append(description)
        if summary:
            parts.append(f"*{summary}*")
        if code:
            lang = args.get("CodeMarkdownLanguage", "")
            parts.append(f"```{lang}\n{code[:1500]}\n```")
        return (target or description, "\n".join(parts) if parts else description)

    # task_boundary — progress update
    if tool_name == "task_boundary":
        name = args.get("TaskName", "")
        status = args.get("TaskStatus", "")
        summary = args.get("TaskSummary", "")
        mode = args.get("Mode", "")
        if name == "%SAME%":
            name = ""
        parts = []
        if mode and mode != "%SAME%":
            parts.append(f"**[{mode}]**")
        if name:
            parts.append(f"**{name}**")
        if status:
            parts.append(status)
        if summary:
            parts.append(f"\n{summary}")
        return ("", "\n".join(parts) if parts else "")

    # find_by_name
    if tool_name in ("find_by_name", "find"):
        pattern = args.get("Pattern", args.get("pattern", ""))
        search_dir = args.get("SearchDirectory", args.get("searchDirectory", ""))
        return (f"{pattern} in {search_dir}", f"Find `{pattern}` in `{search_dir}`")

    # list_dir
    if tool_name in ("list_dir", "list_directory"):
        path = args.get("DirectoryPath", args.get("directoryPath", ""))
        return (path, f"`{path}`")

    # grep_search
    if tool_name in ("grep_search", "codebase_search"):
        query = args.get("Query", args.get("query", args.get("Pattern", "")))
        target = args.get("TargetDirectory", args.get("Directory", ""))
        return (query, f"Search `{query}`" + (f" in `{target}`" if target else ""))

    # view_file
    if tool_name in ("view_file", "read_file"):
        path = args.get("AbsolutePath", args.get("TargetFile", args.get("absolutePathUri", "")))
        return (path, f"`{path}`")

    # Generic: extract the most meaningful field
    for key in ("Description", "Summary", "description", "summary", "message", "text"):
        if args.get(key):
            return (args[key][:100], args[key])
    display = args.get("DirectoryPath") or args.get("TargetFile") or args.get("Pattern") or ""
    if display:
        return (display, f"`{display}`")
    return ("", json.dumps(args, ensure_ascii=False, indent=2)[:300])


def _normalize_text(value: object, *, limit: int = 20_000) -> str:
    """Convert nested payloads into readable text."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (int, float, bool)):
        return str(value)
    if isinstance(value, list):
        parts = [_normalize_text(item, limit=limit) for item in value]
        return "\n".join(part for part in parts if part).strip()[:limit]
    if isinstance(value, dict):
        # Common content shapes: {text}, {parts: [...]}, {content: "..."}
        for key in ("text", "response", "content", "message", "output", "summary"):
            if key in value:
                text = _normalize_text(value.get(key), limit=limit)
                if text:
                    return text[:limit]
        parts = [_normalize_text(item, limit=limit) for item in value.values()]
        return "\n".join(part for part in parts if part).strip()[:limit]
    try:
        return json.dumps(value, ensure_ascii=False)[:limit]
    except TypeError:
        return str(value)[:limit]


def _normalize_role(value: object) -> str:
    text = str(value or "").strip().lower()
    if text in {"assistant", "ai", "model", "planner"}:
        return "assistant"
    if text in {"user", "human"}:
        return "user"
    if text in {"system"}:
        return "system"
    return ""


def _get_timestamp(node: dict, fallback: str = "") -> str:
    for key in _TIMESTAMP_KEYS:
        value = node.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return fallback


def _walk_nodes(value: object):
    if isinstance(value, dict):
        yield value
        for item in value.values():
            yield from _walk_nodes(item)
    elif isinstance(value, list):
        for item in value:
            yield from _walk_nodes(item)


def _parse_transcript_messages(text: str, fallback_ts: str) -> list[dict]:
    """Parse a plain transcript into synthetic user/assistant/system messages."""
    messages: list[dict] = []
    current_role = ""
    current_lines: list[str] = []

    def flush() -> None:
        nonlocal current_role, current_lines
        if not current_role or not current_lines:
            current_role = ""
            current_lines = []
            return
        content = "\n".join(current_lines).strip()
        if content:
            messages.append({
                "type": current_role,
                "message": {"role": current_role, "content": [{"type": "text", "text": content}]},
                "timestamp": fallback_ts,
                "fallback_source": "transcript",
                "content_source": "transcript",
            })
        current_role = ""
        current_lines = []

    for raw_line in text.splitlines():
        line = raw_line.rstrip()
        if not line.strip():
            if current_lines:
                current_lines.append("")
            continue
        match = _ROLE_PREFIX_RE.match(line)
        if match:
            flush()
            role = _normalize_role(match.group(1))
            content = match.group(2).strip()
            if role:
                current_role = role
                current_lines = [content] if content else []
            continue
        if current_role:
            current_lines.append(line)

    flush()
    return messages


def _extract_generator_fallbacks(payload: object, fallback_ts: str) -> tuple[list[dict], dict]:
    """Recover assistant messages from generator metadata / transcript-like payloads."""
    messages: list[dict] = []
    transcript_count = 0
    metadata_count = 0
    messages_truncated = False
    seen_texts: set[str] = set()

    for node in _walk_nodes(payload):
        if not isinstance(node, dict):
            continue

        if node.get("messagesTruncated") is True:
            messages_truncated = True

        for key, value in node.items():
            if key in _TRANSCRIPT_KEYS and isinstance(value, str):
                for msg in _parse_transcript_messages(value, _get_timestamp(node, fallback_ts)):
                    content = _normalize_text(msg.get("message", {}).get("content", ""))
                    dedupe_key = "assistant:" + content
                    if msg["type"] == "assistant" and content and dedupe_key not in seen_texts:
                        seen_texts.add(dedupe_key)
                        messages.append(msg)
                        transcript_count += 1

        role = _normalize_role(
            node.get("role") or node.get("author") or node.get("speaker") or node.get("sender"),
        )
        if role != "assistant":
            continue

        text = ""
        for key in _TEXT_KEYS:
            if key in node:
                text = _normalize_text(node.get(key))
                if text:
                    break
        if not text:
            continue

        dedupe_key = "assistant:" + text
        if dedupe_key in seen_texts:
            continue
        seen_texts.add(dedupe_key)
        messages.append({
            "type": "assistant",
            "message": {"role": "assistant", "content": [{"type": "text", "text": text}]},
            "timestamp": _get_timestamp(node, fallback_ts),
            "response_text": text,
            "fallback_source": "generator_metadata",
            "content_source": "generator_metadata",
        })
        metadata_count += 1

    return messages, {
        "generator_metadata_messages": metadata_count,
        "transcript_messages": transcript_count,
        "messages_truncated": messages_truncated,
    }


def _dedupe_fallback_messages(
    candidates: list[dict], existing_texts: set[str],
) -> list[dict]:
    deduped: list[dict] = []
    for msg in candidates:
        content = _normalize_text(msg.get("message", {}).get("content", ""))
        if not content:
            continue
        key = f"{msg.get('type', 'assistant')}:{content}"
        if key in existing_texts:
            continue
        existing_texts.add(key)
        deduped.append(msg)
    return deduped


def _step_to_jsonl_line(step: dict, cascade_id: str, fallback_ts: str) -> dict | None:
    """Convert an Antigravity trajectory step to a JSONL message."""
    step_type = step.get("type", "")
    ts = step.get("metadata", {}).get("createdAt", "") or fallback_ts

    if step_type == "CORTEX_STEP_TYPE_USER_INPUT":
        text = step.get("userInput", {}).get("userResponse", "")
        if text:
            return {"type": "user", "message": {"role": "user", "content": text}, "timestamp": ts, "cwd": ""}

    elif step_type == "CORTEX_STEP_TYPE_PLANNER_RESPONSE":
        pr = step.get("plannerResponse", {})
        response_text = _normalize_text(pr.get("response", ""))
        thinking_text = _normalize_text(pr.get("thinking", ""))
        text = response_text or thinking_text
        if text:
            return {
                "type": "assistant",
                "message": {"role": "assistant", "content": [{"type": "text", "text": text}]},
                "timestamp": ts,
                "response_text": response_text,
                "thinking_text": thinking_text,
                "content_source": "response" if response_text else "thinking",
                "fallback_source": "thinking_fallback" if thinking_text and not response_text else "",
            }

    elif step_type == "CORTEX_STEP_TYPE_NOTIFY_USER":
        payload = step.get("notifyUser", {})
        text = payload.get("message") or payload.get("text") or ""
        if text:
            return {"type": "assistant", "message": {"role": "assistant", "content": [{"type": "text", "text": text}]}, "timestamp": ts}

    elif step_type == "CORTEX_STEP_TYPE_ERROR_MESSAGE":
        payload = step.get("errorMessage", {})
        text = payload.get("shortError") or payload.get("text") or ""
        if text:
            return {"type": "system", "message": {"role": "system", "content": text}, "timestamp": ts}

    elif step_type in ("CORTEX_STEP_TYPE_TASK_BOUNDARY", "CORTEX_STEP_TYPE_CHECKPOINT",
                        "CORTEX_STEP_TYPE_CONVERSATION_HISTORY", "CORTEX_STEP_TYPE_EPHEMERAL_MESSAGE"):
        # Task boundary: show as progress update (not skip)
        if step_type == "CORTEX_STEP_TYPE_TASK_BOUNDARY":
            meta = step.get("metadata", {})
            tool_call = meta.get("toolCall", {})
            args_json = tool_call.get("argumentsJson", "")
            if args_json:
                tool_input, content = _format_tool_call("task_boundary", args_json)
                if content:
                    return {"type": "system", "message": {"role": "system", "content": content}, "timestamp": ts}
        return None  # Skip other internal types

    else:
        # All tool-like steps: RUN_COMMAND, VIEW_FILE, CODE_ACTION, LIST_DIR, GREP, FIND, etc.
        # First try metadata.toolCall
        meta = step.get("metadata", {})
        tool_call = meta.get("toolCall", {})
        tool_name = tool_call.get("name", "")
        args_json = tool_call.get("argumentsJson", "")

        # Fallback for specific step types
        if not tool_name:
            if step_type == "CORTEX_STEP_TYPE_RUN_COMMAND":
                payload = step.get("runCommand", {})
                cmd = payload.get("command") or payload.get("commandLine") or ""
                output = payload.get("renderedOutput", {})
                out_text = output.get("full", "") if isinstance(output, dict) else str(output or "")
                if cmd:
                    return {"type": "tool", "role": "tool", "tool_name": "run_command", "tool_input": cmd, "content": out_text[:2000], "timestamp": ts}
                return None
            elif step_type == "CORTEX_STEP_TYPE_VIEW_FILE":
                payload = step.get("viewFile", {})
                path = payload.get("absolutePath") or payload.get("absolutePathUri") or ""
                if path:
                    return {"type": "tool", "role": "tool", "tool_name": "view_file", "tool_input": path, "content": f"`{path}`", "timestamp": ts}
                return None
            else:
                return None

        tool_input, content = _format_tool_call(tool_name, args_json)
        return {"type": "tool", "role": "tool", "tool_name": tool_name, "tool_input": tool_input, "content": content[:3000], "timestamp": ts}

    return None


def export_conversations() -> list[dict]:
    """Export Antigravity conversations as JSONL (compatible with conversation parser).

    Requires: pip install antigravity-history
    Requires: Antigravity IDE to be running

    Returns list of changed conversations with JSONL content.
    """
    try:
        from antigravity_history.discovery import discover_language_servers, find_all_endpoints
        from antigravity_history.api import get_all_trajectories, call_api
    except ImportError:
        logger.debug("antigravity-history not installed, skipping")
        return []

    try:
        servers = discover_language_servers()
        if not servers:
            return []
        endpoints = find_all_endpoints(servers)
        if not endpoints:
            return []
    except Exception as e:
        logger.debug("Antigravity discovery failed: %s", e)
        return []

    conversations = []

    for ep in endpoints:
        # Layer 1: Get summaries from live API (recent conversations)
        try:
            summaries = get_all_trajectories(ep["port"], ep["csrf"])
        except Exception:
            summaries = {}

        # Layer 2: Scan .pb files for ALL cascade IDs, then fetch individually
        import re
        import platform
        home = Path.home()
        if platform.system() == "Windows":
            import os
            appdata = Path(os.environ.get("APPDATA", str(home / "AppData" / "Roaming")))
            gemini_root = appdata / ".gemini" if (appdata / ".gemini").exists() else home / ".gemini"
        else:
            gemini_root = home / ".gemini"
        conv_root = gemini_root / "antigravity" / "conversations"

        uuid_re = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)
        pb_count = 0
        fetched = 0
        if conv_root.exists():
            from antigravity_history.api import call_api
            for pb_file in conv_root.glob("*.pb"):
                cid = pb_file.stem
                if uuid_re.match(cid) and cid not in summaries:
                    pb_count += 1
                    try:
                        payload = call_api(ep["port"], ep["csrf"], "GetCascadeTrajectory", {"cascadeId": cid}, timeout=15)
                        if payload:
                            traj = payload.get("trajectory", payload)
                            if traj.get("summary") or traj.get("cascadeId"):
                                summaries[cid] = {
                                    "summary": traj.get("summary", cid[:8]),
                                    "stepCount": traj.get("stepCount") or len(traj.get("steps", [])),
                                    "lastModifiedTime": traj.get("lastModifiedTime", ""),
                                    "createdTime": traj.get("createdAt", traj.get("createdTime", "")),
                                    "status": traj.get("status", ""),
                                    "workspaces": traj.get("workspaces", []),
                                }
                                fetched += 1
                    except Exception as e:
                        logger.debug("Failed to fetch cascade %s: %s", cid[:8], e)
        if pb_count > 0:
            logger.info("Scanned %d .pb files, fetched %d additional conversations", pb_count, fetched)

        for cascade_id, info in summaries.items():
            title = info.get("summary", cascade_id[:8])
            step_count = info.get("stepCount", 0)
            last_modified = info.get("lastModifiedTime", "")
            created = info.get("createdTime", "")

            # Extract workspace
            workspace = ""
            workspaces = info.get("workspaces", [])
            if workspaces and isinstance(workspaces[0], dict):
                workspace = workspaces[0].get("workspaceFolderAbsoluteUri", "")

            # Incremental: skip unchanged (v2 = format version, forces re-export on format change)
            summary_key = f"v9:{cascade_id}:{step_count}:{last_modified}"
            content_hash = hashlib.sha256(summary_key.encode()).hexdigest()[:16]
            if _last_hashes.get(cascade_id) == content_hash:
                continue
            _last_hashes[cascade_id] = content_hash

            # Resolve workspace to cwd path
            cwd = ""
            if workspace:
                cwd = unquote(workspace).replace("\\", "/")
                if cwd.startswith("file:///"):
                    cwd = cwd[7:] if cwd[8:9] != ":" else cwd[8:]

            # Build JSONL content — fetch all steps
            jsonl_lines = []
            existing_message_texts: set[str] = set()
            assistant_response_count = 0
            assistant_thinking_count = 0
            assistant_thinking_only_count = 0
            assistant_fallback_count = 0
            generator_diag: dict[str, object] = {
                "generator_metadata_messages": 0,
                "transcript_messages": 0,
                "messages_truncated": False,
            }

            # First line: session metadata (like Codex format)
            jsonl_lines.append(json.dumps({
                "type": "session_meta",
                "timestamp": created,
                "payload": {
                    "id": cascade_id,
                    "timestamp": created,
                    "cwd": cwd,
                    "originator": "Antigravity",
                    "model_provider": "google",
                    "title": title,
                    "step_count": step_count,
                    "status": info.get("status", ""),
                },
            }, ensure_ascii=False))

            try:
                # Use startIndex/endIndex to get steps WITH response text
                # verbosity=1 strips plannerResponse.response, so we use default verbosity
                steps_response = call_api(
                    ep["port"], ep["csrf"], "GetCascadeTrajectorySteps",
                    {"cascadeId": cascade_id, "startIndex": 0, "endIndex": step_count + 100},
                    timeout=120,
                )
                steps = (steps_response or {}).get("steps", []) if steps_response else []
                for step in steps:
                    if step.get("type") == "CORTEX_STEP_TYPE_PLANNER_RESPONSE":
                        planner_response = step.get("plannerResponse", {})
                        response_text = _normalize_text(planner_response.get("response", ""))
                        thinking_text = _normalize_text(planner_response.get("thinking", ""))
                        if response_text:
                            assistant_response_count += 1
                        if thinking_text:
                            assistant_thinking_count += 1
                        if thinking_text and not response_text:
                            assistant_thinking_only_count += 1
                    msg = _step_to_jsonl_line(step, cascade_id, last_modified)
                    if msg:
                        if msg["type"] == "user" and cwd and not msg.get("cwd"):
                            msg["cwd"] = cwd
                        content = _normalize_text(msg.get("message", {}).get("content", msg.get("content", "")))
                        if content:
                            existing_message_texts.add(f"{msg.get('type', 'assistant')}:{content}")
                        jsonl_lines.append(json.dumps(msg, ensure_ascii=False))
            except Exception as e:
                logger.debug("Failed to fetch steps for %s: %s", cascade_id, e)

            # Fallback: recover assistant text from generator metadata / transcript-like payloads
            if assistant_thinking_only_count > 0 or assistant_response_count == 0:
                metadata_payload = None
                for payload in (
                    {"cascadeId": cascade_id, "includeMessages": True},
                    {"cascadeId": cascade_id},
                ):
                    try:
                        metadata_payload = call_api(
                            ep["port"],
                            ep["csrf"],
                            "GetCascadeTrajectoryGeneratorMetadata",
                            payload,
                            timeout=60,
                        )
                    except Exception as e:
                        logger.debug("Generator metadata fetch failed for %s with %s: %s", cascade_id[:8], payload, e)
                        continue
                    if metadata_payload:
                        break

                if metadata_payload:
                    fallback_messages, generator_diag = _extract_generator_fallbacks(metadata_payload, last_modified)
                    fallback_messages = _dedupe_fallback_messages(fallback_messages, existing_message_texts)
                    assistant_fallback_count = len(fallback_messages)
                    for msg in fallback_messages:
                        jsonl_lines.append(json.dumps(msg, ensure_ascii=False))

            content = "\n".join(jsonl_lines)

            # Project name from workspace
            project_name = cwd.rstrip("/").split("/")[-1] if cwd else None
            diagnostics = {
                "step_count": step_count,
                "assistant_response_count": assistant_response_count,
                "assistant_thinking_count": assistant_thinking_count,
                "assistant_thinking_only_count": assistant_thinking_only_count,
                "assistant_fallback_count": assistant_fallback_count,
                **generator_diag,
            }

            if assistant_thinking_only_count > 0 or assistant_fallback_count > 0 or generator_diag.get("messages_truncated"):
                logger.warning(
                    "Antigravity %s: planner responses=%d, thinking_only=%d, recovered=%d, transcript=%d, metadata=%d, truncated=%s",
                    cascade_id[:8],
                    assistant_response_count,
                    assistant_thinking_only_count,
                    assistant_fallback_count,
                    int(generator_diag.get("transcript_messages", 0)),
                    int(generator_diag.get("generator_metadata_messages", 0)),
                    bool(generator_diag.get("messages_truncated", False)),
                )

            conversations.append({
                "title": title,
                "cascade_id": cascade_id,
                "workspace": workspace,
                "project_name": project_name,
                "size": len(content),
                "content": content,
                "content_hash": content_hash,
                "export_diagnostics": diagnostics,
            })

    if conversations:
        logger.info("Exported %d changed Antigravity conversations", len(conversations))
    return conversations
