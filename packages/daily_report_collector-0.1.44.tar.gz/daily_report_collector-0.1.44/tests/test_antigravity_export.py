from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "collector"))

from collector.parsers.antigravity_export import (  # noqa: E402
    _extract_generator_fallbacks,
    _step_to_jsonl_line,
)


class AntigravityExportTests(unittest.TestCase):
    def test_planner_response_keeps_response_and_thinking(self) -> None:
        step = {
            "type": "CORTEX_STEP_TYPE_PLANNER_RESPONSE",
            "metadata": {"createdAt": "2026-04-05T10:00:00Z"},
            "plannerResponse": {
                "response": "Final answer",
                "thinking": "Internal reasoning",
            },
        }

        msg = _step_to_jsonl_line(step, "cascade-id", "2026-04-05T09:59:59Z")

        self.assertIsNotNone(msg)
        assert msg is not None
        self.assertEqual(msg["type"], "assistant")
        self.assertEqual(msg["response_text"], "Final answer")
        self.assertEqual(msg["thinking_text"], "Internal reasoning")
        self.assertEqual(msg["fallback_source"], "")
        self.assertEqual(msg["message"]["content"][0]["text"], "Final answer")

    def test_generator_metadata_recovers_transcript_and_metadata_messages(self) -> None:
        payload = {
            "messagesTruncated": True,
            "transcript": "User: hello\nAssistant: recovered from transcript",
            "items": [
                {"role": "assistant", "text": "recovered from metadata"},
                {"role": "assistant", "text": "recovered from metadata"},
            ],
        }

        messages, diagnostics = _extract_generator_fallbacks(payload, "2026-04-05T10:00:00Z")
        contents = [msg["message"]["content"][0]["text"] for msg in messages]

        self.assertIn("recovered from transcript", contents)
        self.assertIn("recovered from metadata", contents)
        self.assertEqual(diagnostics["transcript_messages"], 1)
        self.assertEqual(diagnostics["generator_metadata_messages"], 1)
        self.assertTrue(diagnostics["messages_truncated"])


if __name__ == "__main__":
    unittest.main()
