"""Command-line interface for Agent Berlin SDK.

This module provides CLI commands for managing workflows and reports through
a single manifest-driven surface (apply / publish / submit, plus workflow-only
run). Both kinds share the same verbs.
"""

import json
import os
import sys
from pathlib import Path
from typing import Any, Optional

import click
import requests

from . import __version__
from .config import DEFAULT_BASE_URL
from .session import configure_session as _configure_session
from .session import load_session_config


@click.group()
@click.version_option(version=__version__, prog_name="agentberlin")
def main() -> None:
    """Agent Berlin CLI - manage workflows and reports."""
    pass


@main.command()
@click.option("--token", "-t", required=True, help="Authentication token from get_auth_token MCP tool")
@click.option("--domain", "-d", required=True, help="Project domain (e.g., example.com)")
@click.option("--config-path", help="Custom config file path")
def configure(token: str, domain: str, config_path: Optional[str]) -> None:
    """Configure session credentials for Agent Berlin."""
    _configure_session(token, domain, config_path)
    click.echo(f"Session configured for domain: {domain}")


def _resolve_project_domain(project_domain: Optional[str]) -> str:
    """Resolve project_domain from CLI arg or session config."""
    if project_domain:
        return project_domain
    config = load_session_config()
    resolved = config.get("project_domain")
    if not resolved:
        raise click.ClickException(
            "No project domain found. Use --project-domain or configure session first."
        )
    return resolved


@main.group("brand")
def brand_group() -> None:
    """Inspect the project's brand profile and download brand context files."""
    pass


def _fetch_brand_profile(
    base_url: str, headers: dict[str, str], project_domain: str
) -> dict[str, Any]:
    try:
        resp = requests.post(
            f"{base_url}/brand/profile",
            headers=headers,
            json={"project_domain": project_domain},
            timeout=30,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _handle_api_error(resp, "Brand profile")
    return resp.json()


def _fetch_brand_files(
    base_url: str, headers: dict[str, str], project_domain: str
) -> list[dict[str, Any]]:
    try:
        resp = requests.post(
            f"{base_url}/brand/files/list",
            headers=headers,
            json={"project_domain": project_domain},
            timeout=30,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _handle_api_error(resp, "Brand file list")
    return resp.json().get("files", []) or []


@brand_group.command("info")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON instead of a key-value table")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def brand_info(
    project_domain: Optional[str],
    token: Optional[str],
    as_json: bool,
    base_url: str,
) -> None:
    """Print the brand profile and the catalog of brand context files.

    File contents aren't fetched here — use `agentberlin brand download <file_id>`
    to pull a specific file's bytes onto disk.
    """
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    profile = _fetch_brand_profile(base_url, headers, project_domain)
    files = _fetch_brand_files(base_url, headers, project_domain)

    if as_json:
        click.echo(json.dumps({"profile": profile, "files": files}, indent=2))
        return

    def _fmt_list(values: Any) -> str:
        if not values:
            return "(none)"
        return ", ".join(str(v) for v in values)

    rows: list[tuple[str, str]] = [
        ("domain", profile.get("domain") or "(empty)"),
        ("name", profile.get("name") or "(empty)"),
        ("industries", _fmt_list(profile.get("industries"))),
        ("business_models", _fmt_list(profile.get("business_models"))),
        ("company_size", profile.get("company_size") or "(empty)"),
        ("target_customer_segments", _fmt_list(profile.get("target_customer_segments"))),
        ("geographies", _fmt_list(profile.get("geographies"))),
        ("competitors", _fmt_list(profile.get("competitors"))),
        ("domain_authority", str(profile.get("domain_authority")) if profile.get("domain_authority") else "(none)"),
        ("sitemaps", _fmt_list(profile.get("sitemaps"))),
        ("profile_urls", _fmt_list(profile.get("profile_urls"))),
    ]
    key_w = max(len(k) for k, _ in rows)
    for key, val in rows:
        click.echo(f"{key:<{key_w}}  {val}")

    topics = profile.get("topics") or []
    click.echo(f"{'topics':<{key_w}}  {f'{len(topics)} tracked' if topics else '(none)'}")
    for t in topics:
        value = t.get("value", "")
        extras: list[str] = []
        if t.get("pillar_page_url"):
            extras.append(f"pillar={t['pillar_page_url']}")
        if t.get("landing_page_url"):
            extras.append(f"landing={t['landing_page_url']}")
        line = f"  - {value}"
        if extras:
            line += f"  ({', '.join(extras)})"
        click.echo(line)

    context = profile.get("search_analysis_context")
    if context:
        click.echo("search_analysis_context:")
        click.echo(context)

    click.echo("")
    if not files:
        click.echo("brand files: (none)")
        return

    click.echo(f"brand files ({len(files)}):")
    id_w = max(len("ID"), max(len(f["id"]) for f in files))
    name_w = max(len("FILENAME"), max(len(f["filename"]) for f in files))
    click.echo(f"  {'ID':<{id_w}}  {'FILENAME':<{name_w}}  {'SIZE':>10}  DESCRIPTION")
    for f in files:
        size_kb = f.get("size_bytes", 0) / 1024
        size_str = f"{size_kb:.1f} KB"
        desc = f.get("description", "") or ""
        click.echo(f"  {f['id']:<{id_w}}  {f['filename']:<{name_w}}  {size_str:>10}  {desc}")


@brand_group.command("download")
@click.argument("file_id")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    help="Output file path. Defaults to the original filename in the current directory.",
)
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def brand_download(
    file_id: str,
    project_domain: Optional[str],
    token: Optional[str],
    output: Optional[str],
    base_url: str,
) -> None:
    """Download a brand file's contents by its ID.

    FILE_ID is the file identifier shown by `agentberlin brand info`.
    """
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    try:
        resp = requests.post(
            f"{base_url}/brand/files/content",
            headers=headers,
            json={"project_domain": project_domain, "file_id": file_id},
            timeout=120,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 404:
        raise click.ClickException(f"Brand file '{file_id}' not found.")
    _handle_api_error(resp, "Brand file download")

    if output:
        out_path = Path(output)
    else:
        # Extract filename from Content-Disposition, fall back to file_id.
        disposition = resp.headers.get("Content-Disposition", "")
        filename = file_id
        if "filename=" in disposition:
            filename = disposition.split("filename=", 1)[1].strip().strip('"')
        out_path = Path.cwd() / filename

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(resp.content)
    click.echo(f"Downloaded: {out_path} ({len(resp.content)} bytes)")


WORKFLOW_GROUP_HELP = """Manage workflows (apply, publish, submit).

A workflow is one Python script that runs on a schedule and writes
output.json. Lifecycle: `apply` upserts metadata → the workflow_builder agent
calls `publish` with the built artefacts → the runtime processor calls
`submit` after each run.

\b
Commands:
  apply     Upsert metadata from a manifest. POST if the manifest has no `id`,
            PATCH otherwise. Editing `details` bumps the version and triggers
            a rebuild.
  publish   Upload built artefacts (main.py + spec.json + api_estimate.json)
            onto the latest version. Used by the workflow_builder agent.
  submit    Upload a run's output.json (and stdout/stderr) to the artifacts
            endpoint. Invoked by the runtime processor; rare for direct use.

MANIFEST FILE FORMAT
====================

\b
{
  "kind": "workflow",
  "id": "wfl_abc123xyz",
  "name": "My Workflow",
  "description": "Optional description",
  "details": "Natural-language spec describing what the workflow does",
  "schedule": {"type": "cron", "cron_expression": "...", "timezone": "UTC"}
}

REQUIRED FIELDS
===============
  kind  - Must be "workflow"
  name  - Required on first apply
  id    - Absent on first apply (CLI writes it back); required for every
          subsequent call (apply, publish, submit, run).

OPTIONAL FIELDS
===============
  description - Workflow description
  details     - Natural-language spec the builder turns into an executable
                spec on the server.
  schedule    - {type: "cron"|"one_time"|"manual", cron_expression?, timezone?}

SCHEDULE SEMANTICS
==================
  - `cron` requires `cron_expression`; `timezone` is optional (defaults to UTC).
  - `one_time` and `manual` need no additional fields.
  - Schedules are stored disabled on creation and only begin running once the
    workflow reaches the "ready" phase.
  - On the PATCH path, `apply` upserts the schedule; sending `"manual"` is a
    no-op (does not delete an existing schedule).

EXAMPLE
=======

\b
# plan.json
{
  "kind": "workflow",
  "name": "Weekly Keyword Rank Tracking",
  "description": "Track target keyword positions weekly",
  "details": "Read target keywords from the keywords resource. Every Monday query GSC for rank data for the past 7 days. Flag any keyword that dropped more than 3 positions WoW.",
  "schedule": { "type": "cron", "cron_expression": "0 9 * * 1", "timezone": "UTC" }
}

\b
agentberlin workflow apply -m plan.json   # first call: creates the row, writes id back
agentberlin workflow apply -m plan.json   # subsequent calls: patches metadata
"""


REPORT_GROUP_HELP = """Manage reports (apply, publish, submit).

A report is an HTML viewer paired with a JSON spec. The HTML fetches
`./data.json` at runtime and renders it; the spec describes the shape
data.json must take.

LIFECYCLE / THREE PRINCIPALS
============================
  - Operator (e.g. the seoaudit agent) — runs `apply` with `details` (the
    data-shape brief). Editing `details` and re-applying re-enqueues the
    report_builder.
  - report_builder agent — runs `publish` with the built layout artefacts
    (index.html + spec.json). Direct write, no enqueue.
  - Downstream data job — runs `submit` with a fresh data.json conforming
    to the spec.

\b
Commands:
  apply     Upsert metadata from a manifest. POST if the manifest has no `id`,
            PATCH otherwise. Editing `details` re-enqueues a report_builder
            run.
  publish   Upload built layout artefacts (index.html + spec.json) onto an
            existing report. Used by the report_builder agent.
  submit    Upload a fresh data.json conforming to the report's spec.

MANIFEST FILE FORMAT
====================

\b
{
  "kind": "report",
  "id": "rpt_abc123xyz",
  "slug": "audit",
  "name": "Audit",
  "description": "Optional description",
  "details": "Data-shape brief for the report_builder agent."
}

REQUIRED FIELDS
===============
  kind  - Must be "report"
  slug  - URL-safe identifier; immutable post-create. Required on every call.
  id    - Absent on first apply (CLI writes it back); required for every
          subsequent call (apply, publish, submit).

OPTIONAL FIELDS
===============
  name        - Display title (maps to the report's `title` column)
  description - Report description
  details     - Data-shape brief for the builder. On apply, editing `details`
                re-enqueues a report_builder run. Required on first apply.

BEHAVIOR
========
  - First `apply` returns HTTP 409 if the slug already exists in the project
    — fetch its `id` and add it to the manifest, or pick a new slug.
"""


def _handle_api_error(resp: requests.Response, context: str = "API request") -> None:
    """Handle API error responses with appropriate messages."""
    if resp.status_code == 401:
        raise click.ClickException("Authentication failed. Check your token.")
    if resp.status_code == 400:
        error_data = resp.json()
        # Check for validation errors (syntax/type check failures)
        if "validation_errors" in error_data:
            click.echo("Script validation failed:", err=True)
            for err in error_data["validation_errors"]:
                click.echo(f"  - {err}", err=True)
            raise click.ClickException("Fix the errors above and try again")
        error_msg = error_data.get("error", "Bad request")
        raise click.ClickException(f"{context} failed: {error_msg}")
    try:
        resp.raise_for_status()
    except requests.HTTPError as e:
        raise click.ClickException(f"{context} failed: {e}")


def _resolve_token(token: Optional[str]) -> str:
    """Resolve API token from CLI arg, env, or session config."""
    if token:
        return token
    config = load_session_config()
    resolved = config.get("token")
    if not resolved:
        raise click.ClickException("No API token found. Set AGENTBERLIN_TOKEN or configure session first.")
    return resolved


def _load_manifest(manifest: str, expected_kind: str) -> tuple[dict[str, Any], Path]:
    """Load and validate a manifest JSON file for the given kind.

    Validates `kind` matches the calling CLI group, and rejects fields that
    don't apply to that kind (schedule on report, slug on workflow). Does NOT
    enforce id presence — callers decide whether id is required (e.g. publish
    requires it; apply does not).
    """
    manifest_path = Path(manifest)
    try:
        data = json.loads(manifest_path.read_text())
    except json.JSONDecodeError as e:
        raise click.ClickException(f"Invalid manifest JSON: {e}")
    if not isinstance(data, dict):
        raise click.ClickException("Manifest must be a JSON object")

    kind = data.get("kind")
    if kind != expected_kind:
        if kind is None:
            raise click.ClickException(
                f"manifest is missing 'kind'. Add `\"kind\": \"{expected_kind}\"`."
            )
        raise click.ClickException(
            f"manifest kind is {kind!r}; this command requires kind={expected_kind!r}."
        )

    if expected_kind == "workflow":
        if "slug" in data:
            raise click.ClickException(
                "'slug' is a report-only field. Remove it from a workflow manifest."
            )
    elif expected_kind == "report":
        if "schedule" in data:
            raise click.ClickException(
                "'schedule' is a workflow-only field. Remove it from a report manifest."
            )
        if not data.get("slug"):
            raise click.ClickException("report manifest must include 'slug'.")

    return data, manifest_path


def _build_workflow_payload(manifest_data: dict[str, Any]) -> dict[str, Any]:
    """Extract workflow metadata fields (name, description, details, schedule)
    from a manifest. Only includes keys present and non-empty.

    Used as the body for POST /workflows and PATCH /workflows/:id.
    """
    if not manifest_data.get("name"):
        raise click.ClickException("workflow manifest must include 'name'.")
    payload: dict[str, Any] = {"name": manifest_data["name"]}
    description = manifest_data.get("description")
    if description:
        payload["description"] = description
    details = manifest_data.get("details")
    if details:
        payload["details"] = details
    schedule = manifest_data.get("schedule")
    if schedule:
        payload["schedule"] = schedule
    return payload


def _build_report_form(manifest_data: dict[str, Any], project_domain: str) -> dict[str, str]:
    """Extract report metadata fields (slug, name→title, description, details)
    into a form-encoded dict for POST /reports and PATCH /reports/:slug.

    The report DB column is `title`; the manifest field is `name` (so both
    kinds share one human-readable label key). Maps name → title here.
    """
    form: dict[str, str] = {
        "slug": manifest_data["slug"],
        "project_domain": project_domain,
    }
    title = manifest_data.get("name")
    if title:
        form["title"] = title
    description = manifest_data.get("description")
    if description:
        form["description"] = description
    details = manifest_data.get("details")
    if details:
        form["details"] = details
    return form


def _post_create_workflow(base_url: str, headers: dict[str, str], payload: dict[str, Any]) -> str:
    """Call POST /workflows. Returns the new workflow_id."""
    try:
        resp = requests.post(f"{base_url}/workflows", headers=headers, json=payload, timeout=60)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _handle_api_error(resp, "Workflow creation")
    return resp.json()["workflow_id"]


def _patch_workflow(
    base_url: str, headers: dict[str, str], workflow_id: str, payload: dict[str, Any]
) -> dict[str, Any]:
    """Call PATCH /workflows/:id. Returns the response JSON."""
    try:
        resp = requests.patch(f"{base_url}/workflows/{workflow_id}", headers=headers, json=payload, timeout=60)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    if resp.status_code == 404:
        raise click.ClickException(f"Workflow '{workflow_id}' not found.")
    _handle_api_error(resp, "Workflow update")
    return resp.json()


def _post_publish_workflow_version(
    base_url: str,
    headers: dict[str, str],
    workflow_id: str,
    files_map: dict[str, str],
    cost_estimate: Optional[dict[str, Any]],
) -> dict[str, Any]:
    """Call POST /workflows/:id/versions/current/files. Returns the response JSON."""
    body: dict[str, Any] = {"files": files_map}
    if cost_estimate is not None:
        body["cost_estimate"] = cost_estimate
    try:
        resp = requests.post(
            f"{base_url}/workflows/{workflow_id}/versions/current/files",
            headers=headers,
            json=body,
            timeout=60,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    if resp.status_code == 404:
        raise click.ClickException(
            f"Workflow '{workflow_id}' not found, or no version exists yet."
        )
    _handle_api_error(resp, "Workflow publish")
    return resp.json()


def _post_create_report(
    base_url: str, headers: dict[str, str], form: dict[str, str]
) -> dict[str, Any]:
    """Call POST /reports. Returns the response JSON (includes report_id, url)."""
    try:
        resp = requests.post(f"{base_url}/reports", headers=headers, data=form, timeout=120)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    if resp.status_code == 409:
        error_msg = resp.json().get("error", "Report already exists")
        raise click.ClickException(error_msg)
    _handle_api_error(resp, "Report create")
    return resp.json()


def _patch_report(
    base_url: str,
    headers: dict[str, str],
    slug: str,
    form: dict[str, str],
    files: Optional[dict[str, tuple[str, Any, str]]] = None,
) -> dict[str, Any]:
    """Call PATCH /reports/:slug. Returns the response JSON."""
    try:
        resp = requests.patch(
            f"{base_url}/reports/{slug}",
            headers=headers,
            data=form,
            files=files if files else None,
            timeout=120,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    if resp.status_code == 404:
        raise click.ClickException(
            f"Report '{slug}' not found. Run `agentberlin report apply -m manifest.json` first."
        )
    _handle_api_error(resp, "Report update")
    return resp.json()


def _write_id_to_manifest(manifest_path: Path, manifest_data: dict[str, Any], new_id: str) -> None:
    """Persist the assigned id back to the manifest file (workflow or report)."""
    manifest_data["id"] = new_id
    manifest_path.write_text(json.dumps(manifest_data, indent=2))


def _load_json_file(path: str, field_name: str, require_object: bool) -> None:
    """Validate a path is a readable JSON file (and optionally a top-level object).

    Raises click.ClickException with a friendly message on failure. Does not
    return the parsed JSON — callers upload the raw bytes, this is only a
    fail-fast check before hitting the network.
    """
    p = Path(path)
    if p.suffix.lower() != ".json":
        raise click.ClickException(f"--{field_name} must be a .json file")
    try:
        parsed = json.loads(p.read_bytes())
    except json.JSONDecodeError as e:
        raise click.ClickException(f"--{field_name} is not valid JSON: {e}")
    if require_object and not isinstance(parsed, dict):
        raise click.ClickException(f"--{field_name} must be a JSON object at the top level")


@main.group("workflow", help=WORKFLOW_GROUP_HELP)
def workflow_group() -> None:
    pass


_WORKFLOW_APPLY_HELP = """Upsert workflow metadata from a manifest.

If the manifest has no `id`, POSTs a new workflow row and writes the assigned
`id` back to the manifest file. If the manifest already has an `id`, PATCHes
the existing row. Subsequent calls (apply, publish, submit, run) all require
the manifest to carry an `id`.

Editing `details` bumps the workflow version and flags it for rebuild.

See `agentberlin workflow --help` for the manifest format reference.
"""


@workflow_group.command("apply", help=_WORKFLOW_APPLY_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_apply(manifest: str, token: Optional[str], base_url: str) -> None:
    token = _resolve_token(token)
    manifest_data, manifest_path = _load_manifest(manifest, "workflow")
    payload = _build_workflow_payload(manifest_data)
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    workflow_id = manifest_data.get("id")
    if workflow_id:
        result = _patch_workflow(base_url, headers, workflow_id, payload)
        click.echo(f"Workflow updated: {result.get('name', payload['name'])} ({workflow_id})")
        phase = result.get("phase")
        if phase:
            click.echo(f"Phase: {phase}")
    else:
        new_id = _post_create_workflow(base_url, headers, payload)
        _write_id_to_manifest(manifest_path, manifest_data, new_id)
        click.echo(f"Created workflow: {payload['name']} ({new_id})")


_WORKFLOW_PUBLISH_HELP = """Publish built workflow files to the latest version.

Pass either --file (single file) or --dir (every regular file in the
directory). Workflow id is read from the manifest's `id` field.

The server stores files under their basename. Status is not changed by this
call — the agent's terminal-status hook flips the version from `building` to
`ready` when the agent reports done.

When --dir is used, dotfiles, __pycache__, and *.pyc are skipped.

--cost-estimate-file is required and points to a JSON file carrying the
per-resource SDK call estimate (must be a JSON object containing an
`estimates` array). Its parsed contents are sent in the request body as
`cost_estimate`; if the file lives inside --dir, its basename is dropped
from the files map so it isn't double-shipped. The manifest file itself,
if it lives inside --dir, is also dropped from the files map.

\b
Example:
    agentberlin workflow publish -m manifest.json --dir . --cost-estimate-file api_estimate.json
"""


def _load_cost_estimate(path: str) -> dict[str, Any]:
    """Read & parse the cost-estimate JSON file. Validates the top-level shape.

    The contract (see workflow_builder agent prompt): a JSON object with an
    `estimates` array. Server-side parsing is strict-typed, so failing fast
    here gives the agent a clear error before the network round-trip.
    """
    try:
        parsed = json.loads(Path(path).read_text())
    except json.JSONDecodeError as e:
        raise click.ClickException(f"--cost-estimate-file is not valid JSON: {e}")
    if not isinstance(parsed, dict):
        raise click.ClickException("--cost-estimate-file must be a JSON object")
    if not isinstance(parsed.get("estimates"), list):
        raise click.ClickException(
            "--cost-estimate-file must contain an 'estimates' array"
        )
    return parsed


def _collect_dir_files(dir_path: Path) -> dict[str, str]:
    """Read every regular file in dir_path (non-recursive) into a basename→content map.

    Skips dotfiles, __pycache__ entries, and *.pyc — these would never be
    intentional build artefacts and trip up server-side validation.
    """
    files_map: dict[str, str] = {}
    for entry in sorted(dir_path.iterdir()):
        if not entry.is_file():
            continue
        if entry.name.startswith(".") or entry.name == "__pycache__" or entry.suffix == ".pyc":
            continue
        try:
            files_map[entry.name] = entry.read_text()
        except OSError as e:
            raise click.ClickException(f"Failed to read {entry}: {e}")
    if not files_map:
        raise click.ClickException(f"No publishable files found in {dir_path}.")
    return files_map


@workflow_group.command("publish", help=_WORKFLOW_PUBLISH_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file (kind=workflow, id required).",
)
@click.option(
    "--file",
    "-f",
    "file_path",
    type=click.Path(exists=True, dir_okay=False),
    help="Path to a single file to publish (e.g. main.py).",
)
@click.option(
    "--dir",
    "-d",
    "dir_path",
    type=click.Path(exists=True, file_okay=False),
    help="Directory whose regular files (non-recursive) should be published together.",
)
@click.option(
    "--cost-estimate-file",
    "cost_estimate_path",
    type=click.Path(exists=True, dir_okay=False),
    required=True,
    help=(
        "Path to a JSON file with the workflow's per-resource SDK cost estimate. "
        "Sent in the request body as cost_estimate; excluded from the files map "
        "when --dir is used."
    ),
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_publish(
    manifest: str,
    file_path: Optional[str],
    dir_path: Optional[str],
    cost_estimate_path: str,
    token: Optional[str],
    base_url: str,
) -> None:
    if bool(file_path) == bool(dir_path):
        raise click.ClickException("Pass exactly one of --file or --dir.")
    manifest_data, manifest_path = _load_manifest(manifest, "workflow")
    workflow_id = manifest_data.get("id")
    if not workflow_id:
        raise click.ClickException(
            "manifest must include 'id'. Run `agentberlin workflow apply -m manifest.json` first."
        )
    token = _resolve_token(token)

    cost_estimate = _load_cost_estimate(cost_estimate_path)

    if file_path:
        path = Path(file_path)
        try:
            content = path.read_text()
        except OSError as e:
            raise click.ClickException(f"Failed to read {file_path}: {e}")
        files_map = {path.name: content}
        label = path.name
    else:
        assert dir_path is not None  # for type checker; click guarantees one of the two
        files_map = _collect_dir_files(Path(dir_path))
        # The cost estimate is published via its own column, not as a file —
        # drop it from the files map if it happened to live in --dir. Same for
        # the manifest file: a sibling concern, not a build artefact.
        files_map.pop(Path(cost_estimate_path).name, None)
        files_map.pop(manifest_path.name, None)
        if not files_map:
            raise click.ClickException(f"No publishable files found in {dir_path}.")
        label = f"{len(files_map)} files from {dir_path}"

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    result = _post_publish_workflow_version(
        base_url, headers, workflow_id, files_map, cost_estimate
    )
    version = result.get("version")
    if version is not None:
        click.echo(f"Published {label} to workflow {workflow_id} (version {version})")
    else:
        click.echo(f"Published {label} to workflow {workflow_id}")


_WORKFLOW_SUBMIT_HELP = """Upload a workflow run's output.json (and optional logs) artefacts.

Auto-invoked by `workflow run` after the script exits. Standalone use is rare.
"""


def _post_workflow_run_artifacts(
    base_url: str,
    token: str,
    output_bytes: Optional[bytes],
    stdout_bytes: bytes,
    stderr_bytes: bytes,
    exit_code: int,
) -> None:
    """POST stdout/stderr/output to /workflow-runs/artifacts.

    Shared by `workflow run` (in-process buffers from the script subprocess)
    and `workflow submit` (bytes read from disk). Failures print a warning
    but do not raise — the caller decides the process exit code.
    """
    files: dict[str, tuple[str, bytes, str]] = {
        "stdout": ("stdout.log", stdout_bytes, "text/plain"),
        "stderr": ("stderr.log", stderr_bytes, "text/plain"),
    }
    if output_bytes is not None:
        files["output"] = ("output.json", output_bytes, "application/json")

    headers = {"Authorization": f"Bearer {token}"}
    try:
        resp = requests.post(
            f"{base_url}/workflow-runs/artifacts",
            headers=headers,
            files=files,
            data={"exit_code": str(exit_code)},
            timeout=60,
        )
    except requests.RequestException as e:
        click.echo(f"warning: artifact upload failed (network): {e}", err=True)
        return

    if resp.status_code != 200:
        try:
            err_msg = resp.json().get("error", resp.text)
        except ValueError:
            err_msg = resp.text
        click.echo(
            f"warning: artifact upload failed (HTTP {resp.status_code}): {err_msg}",
            err=True,
        )


@workflow_group.command("submit", help=_WORKFLOW_SUBMIT_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file (kind=workflow, id required).",
)
@click.option(
    "--file",
    "output_path",
    type=click.Path(exists=True, dir_okay=False),
    required=True,
    help="Path to the run's output.json.",
)
@click.option(
    "--stdout-file",
    "stdout_path",
    type=click.Path(exists=True, dir_okay=False),
    help="Path to the run's stdout log. Defaults to empty bytes.",
)
@click.option(
    "--stderr-file",
    "stderr_path",
    type=click.Path(exists=True, dir_okay=False),
    help="Path to the run's stderr log. Defaults to empty bytes.",
)
@click.option(
    "--exit-code",
    type=int,
    default=0,
    show_default=True,
    help="Script exit code to record on the run row.",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="Sandbox token.")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_submit(
    manifest: str,
    output_path: str,
    stdout_path: Optional[str],
    stderr_path: Optional[str],
    exit_code: int,
    token: Optional[str],
    base_url: str,
) -> None:
    _load_manifest(manifest, "workflow")  # kind validation only
    token = _resolve_token(token)
    try:
        output_bytes = Path(output_path).read_bytes()
    except OSError as e:
        raise click.ClickException(f"Failed to read --file {output_path}: {e}")
    stdout_bytes = Path(stdout_path).read_bytes() if stdout_path else b""
    stderr_bytes = Path(stderr_path).read_bytes() if stderr_path else b""

    _post_workflow_run_artifacts(base_url, token, output_bytes, stdout_bytes, stderr_bytes, exit_code)
    click.echo(f"Submitted output.json ({len(output_bytes)} bytes)")


def _stream_tee(
    src: Any, sink: Any, buf: bytearray, lock: Any
) -> None:
    """Read bytes from src line-by-line, append to buf, and mirror to sink.

    Runs in a daemon thread per stream so the parent can wait on the
    process while output flows live. Bytes (not str) keep encoding
    clean for non-UTF-8 script output.
    """
    while True:
        chunk = src.readline()
        if not chunk:
            return
        with lock:
            buf.extend(chunk)
        try:
            sink.write(chunk)
            sink.flush()
        except (OSError, ValueError):
            # Parent's stdout/stderr was closed — keep buffering.
            pass


@workflow_group.command("run", hidden=True)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
)
@click.option(
    "--main",
    "main_path",
    type=click.Path(exists=True),
    default="main.py",
    show_default=True,
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_run(manifest: str, main_path: str, token: Optional[str], base_url: str) -> None:
    import subprocess
    import threading

    _load_manifest(manifest, "workflow")  # kind validation only
    token = _resolve_token(token)
    main_resolved = Path(main_path).resolve()
    cwd = main_resolved.parent

    stdout_buf = bytearray()
    stderr_buf = bytearray()
    stdout_lock = threading.Lock()
    stderr_lock = threading.Lock()

    # `-u` forces the child's stdout/stderr to be unbuffered. Without it,
    # CPython block-buffers writes to a pipe and we'd see nothing live —
    # output would only appear when the buffer filled or the process
    # exited. PYTHONUNBUFFERED is set as a belt-and-braces in case the
    # script re-execs or spawns its own python helpers.
    child_env = os.environ.copy()
    child_env["PYTHONUNBUFFERED"] = "1"
    proc = subprocess.Popen(
        [sys.executable, "-u", str(main_resolved)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd),
        env=child_env,
    )

    stdout_thread = threading.Thread(
        target=_stream_tee,
        args=(proc.stdout, sys.stdout.buffer, stdout_buf, stdout_lock),
        daemon=True,
    )
    stderr_thread = threading.Thread(
        target=_stream_tee,
        args=(proc.stderr, sys.stderr.buffer, stderr_buf, stderr_lock),
        daemon=True,
    )
    stdout_thread.start()
    stderr_thread.start()

    return_code = proc.wait()
    stdout_thread.join()
    stderr_thread.join()

    output_path = cwd / "output.json"
    output_bytes: Optional[bytes] = None
    if output_path.is_file():
        try:
            output_bytes = output_path.read_bytes()
        except OSError as e:
            click.echo(f"warning: failed to read output.json: {e}", err=True)

    _post_workflow_run_artifacts(
        base_url, token, output_bytes, bytes(stdout_buf), bytes(stderr_buf), return_code
    )
    sys.exit(return_code)


@main.group("report", help=REPORT_GROUP_HELP)
def report_group() -> None:
    pass


def _check_html_file(path: str, field_name: str) -> None:
    if Path(path).suffix.lower() != ".html":
        raise click.ClickException(f"--{field_name} must be a .html file")


_REPORT_APPLY_HELP = """Upsert report metadata from a manifest.

If the manifest has no `id`, POSTs a new report row (and enqueues a
report_builder run to author HTML + spec) and writes the assigned id back
to the manifest. First apply requires `details` in the manifest (the
data-shape brief the report_builder reads).

If the manifest has an `id`, PATCHes the existing row. Editing `details`
re-enqueues a report_builder run.

See `agentberlin report --help` for the manifest format reference.
"""


@report_group.command("apply", help=_REPORT_APPLY_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file (kind=report).",
)
@click.option(
    "--project-domain",
    envvar="PROJECT_DOMAIN",
    help="Project domain (reads from PROJECT_DOMAIN env or config if not set).",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def report_apply(
    manifest: str,
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)
    manifest_data, manifest_path = _load_manifest(manifest, "report")
    slug = manifest_data["slug"]
    form = _build_report_form(manifest_data, project_domain)
    headers = {"Authorization": f"Bearer {token}"}

    report_id = manifest_data.get("id")
    if report_id:
        # PATCH path: drop slug from form (it's in the URL).
        form.pop("slug", None)
        if not form:
            raise click.ClickException(
                "manifest has no fields to update besides slug. Add a name/description/details change first."
            )
        result = _patch_report(base_url, headers, slug, form)
        if "details" in form:
            click.echo(f"Report build enqueued: {slug} ({result.get('report_id', '')})")
        else:
            click.echo(f"Report updated: {slug} ({result.get('report_id', '')})")
    else:
        if not form.get("details"):
            raise click.ClickException(
                "first apply requires 'details' in the manifest (the data-shape brief for the report_builder)."
            )
        result = _post_create_report(base_url, headers, form)
        new_id = result.get("report_id", "")
        if new_id:
            _write_id_to_manifest(manifest_path, manifest_data, new_id)
        click.echo(f"Report build enqueued: {slug} ({new_id})")
    if result.get("url"):
        click.echo(f"URL: {result['url']}")


_REPORT_PUBLISH_HELP = """Publish built report layout artefacts (index.html + spec.json).

Reads index.html and spec.json from --dir and uploads them via PATCH
/reports/:slug. The CLI checks the .html extension on index.html and
parses spec.json to verify it's a JSON object before hitting the network.
Direct write — does not enqueue another build.

Used by the report_builder agent.
"""


@report_group.command("publish", help=_REPORT_PUBLISH_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file (kind=report, id required).",
)
@click.option(
    "--dir",
    "-d",
    "dir_path",
    type=click.Path(exists=True, file_okay=False),
    required=True,
    help="Directory containing index.html and spec.json.",
)
@click.option(
    "--project-domain",
    envvar="PROJECT_DOMAIN",
    help="Project domain (reads from PROJECT_DOMAIN env or config if not set).",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def report_publish(
    manifest: str,
    dir_path: str,
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    manifest_data, _ = _load_manifest(manifest, "report")
    if not manifest_data.get("id"):
        raise click.ClickException(
            "manifest must include 'id'. Run `agentberlin report apply -m manifest.json` first."
        )
    slug = manifest_data["slug"]

    html_path = Path(dir_path) / "index.html"
    spec_path = Path(dir_path) / "spec.json"
    if not html_path.is_file():
        raise click.ClickException(f"index.html not found in {dir_path}")
    if not spec_path.is_file():
        raise click.ClickException(f"spec.json not found in {dir_path}")
    _check_html_file(str(html_path), "index.html")
    _load_json_file(str(spec_path), "spec.json", require_object=True)

    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    form = {"project_domain": project_domain}
    headers = {"Authorization": f"Bearer {token}"}
    with open(html_path, "rb") as html_f, open(spec_path, "rb") as spec_f:
        files: dict[str, tuple[str, Any, str]] = {
            "file": ("index.html", html_f, "text/html"),
            "spec": ("spec.json", spec_f, "application/json"),
        }
        result = _patch_report(base_url, headers, slug, form, files)

    click.echo(f"Published index.html + spec.json to report {slug} ({result.get('report_id', '')})")
    if result.get("url"):
        click.echo(f"URL: {result['url']}")


_REPORT_SUBMIT_HELP = """Upload a fresh data.json for an existing report.

The data must conform to the report's spec. The CLI parse-checks the JSON
to fail fast; the spec contract is opaque server-side.
"""


@report_group.command("submit", help=_REPORT_SUBMIT_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file (kind=report, id required).",
)
@click.option(
    "--file",
    "data_path",
    type=click.Path(exists=True, dir_okay=False),
    required=True,
    help="Path to the JSON data file conforming to the spec.",
)
@click.option(
    "--project-domain",
    envvar="PROJECT_DOMAIN",
    help="Project domain (reads from PROJECT_DOMAIN env or config if not set).",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def report_submit(
    manifest: str,
    data_path: str,
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    manifest_data, _ = _load_manifest(manifest, "report")
    if not manifest_data.get("id"):
        raise click.ClickException(
            "manifest must include 'id'. Run `agentberlin report apply -m manifest.json` first."
        )
    slug = manifest_data["slug"]
    _load_json_file(data_path, "file", require_object=False)

    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    headers = {"Authorization": f"Bearer {token}"}
    try:
        with open(data_path, "rb") as data_f:
            files = {"file": (Path(data_path).name, data_f, "application/json")}
            resp = requests.post(
                f"{base_url}/reports/{slug}/publish",
                headers=headers,
                files=files,
                data={"project_domain": project_domain},
                timeout=120,
            )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 404:
        raise click.ClickException(
            f"Report '{slug}' not found. Run `agentberlin report apply -m manifest.json` first."
        )
    _handle_api_error(resp, "Report submit")

    result = resp.json()
    click.echo(f"Report data submitted: {slug} ({result.get('report_id', '')})")
    if result.get("url"):
        click.echo(f"URL: {result['url']}")


@main.group("strategies")
def strategies_group() -> None:
    """List and inspect SEO strategies from the curated catalog."""
    pass


def _format_strategy_markdown(s: dict[str, Any]) -> str:
    """Render a strategy as markdown.

    Mirrors backend/internal/strategies/tool.go's formatStrategyDetails so
    output stays byte-compatible with the legacy in-process tool that
    `seoaudit` and any successor agent learned to parse.
    """
    parts: list[str] = []
    parts.append(f"# {s['name']}\n")
    parts.append(f"ID: {s['id']}\nCategory: {s['category']}\nIntent: {s['intent']}\n")
    parts.append(f"## Summary\n{s['summary']}\n")
    caps = s.get("required_capabilities") or []
    if caps:
        parts.append(f"## Required capabilities\n{', '.join(caps)}\n")
    parts.append(f"## Cadence guidance\n{(s.get('cadence') or '').strip()}\n")
    parts.append(
        f"## Details (use as the basis for the workflow manifest `details` field)\n{(s.get('details') or '').strip()}"
    )
    return "\n".join(parts)


@strategies_group.command("list")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def strategies_list(token: Optional[str], base_url: str) -> None:
    """List every strategy in the catalog as a markdown table."""
    token = _resolve_token(token)
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    try:
        resp = requests.post(f"{base_url}/strategies/list", headers=headers, json={}, timeout=30)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _handle_api_error(resp, "Strategy list")

    items = resp.json().get("strategies", [])
    if not items:
        click.echo("No strategies found.")
        return

    click.echo("| ID | Name | Category | Intent | Summary |")
    click.echo("|---|---|---|---|---|")
    for s in items:
        summary = (s.get("summary") or "").replace("|", "\\|").replace("\n", " ")
        click.echo(
            f"| {s['id']} | {s['name']} | {s.get('category', '')} | {s.get('intent', '')} | {summary} |"
        )


@strategies_group.command("get")
@click.argument("strategy_id")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def strategies_get(strategy_id: str, token: Optional[str], base_url: str) -> None:
    """Fetch the full body of one strategy as markdown.

    STRATEGY_ID is the kebab-case identifier shown by `agentberlin strategies list`.
    """
    token = _resolve_token(token)
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    try:
        resp = requests.post(
            f"{base_url}/strategies/get",
            headers=headers,
            json={"id": strategy_id},
            timeout=30,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 404:
        raise click.ClickException(f"Strategy '{strategy_id}' not found.")
    _handle_api_error(resp, "Strategy get")

    click.echo(_format_strategy_markdown(resp.json()))


if __name__ == "__main__":
    main()
