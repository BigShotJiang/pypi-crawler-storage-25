# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, List, Optional
from typing_extensions import Literal

import httpx

from .tags import (
    TagsResource,
    AsyncTagsResource,
    TagsResourceWithRawResponse,
    AsyncTagsResourceWithRawResponse,
    TagsResourceWithStreamingResponse,
    AsyncTagsResourceWithStreamingResponse,
)
from ...types import task_list_params, task_create_params, task_update_params, task_trigger_params
from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncOffsetPagination, AsyncOffsetPagination
from ..._base_client import AsyncPaginator, make_request_options
from ...types.task_list_response import TaskListResponse
from ...types.task_create_response import TaskCreateResponse
from ...types.task_update_response import TaskUpdateResponse
from ...types.task_retrieve_response import TaskRetrieveResponse

__all__ = ["TasksResource", "AsyncTasksResource"]


class TasksResource(SyncAPIResource):
    @cached_property
    def tags(self) -> TagsResource:
        return TagsResource(self._client)

    @cached_property
    def with_raw_response(self) -> TasksResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return TasksResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> TasksResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return TasksResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        description: str,
        title: str,
        input_examples: SequenceNotStr[str] | Omit = omit,
        metadata: Dict[str, object] | Omit = omit,
        quickstart_id: str | Omit = omit,
        simulated_prompt_schema: Dict[str, object] | Omit = omit,
        topic_id: str | Omit = omit,
        type: Literal["STATIC", "NORMAL"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TaskCreateResponse:
        """
        Creates a new task.

        Args:
          description: A short description of the task

          title: The title of the task

          input_examples: Static user prompts for the task. Required when type is STATIC.

          metadata: Optional metadata to associate with the task when creating it (e.g., external
              identifiers).

          quickstart_id: ID of the quickstart this task was generated from

          simulated_prompt_schema: JSON schema that defines the structure for user prompts that should be generated
              for tests

          topic_id: ID of the topic this task belongs to

          type: The type of task

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v0/tasks",
            body=maybe_transform(
                {
                    "description": description,
                    "title": title,
                    "input_examples": input_examples,
                    "metadata": metadata,
                    "quickstart_id": quickstart_id,
                    "simulated_prompt_schema": simulated_prompt_schema,
                    "topic_id": topic_id,
                    "type": type,
                },
                task_create_params.TaskCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TaskCreateResponse,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TaskRetrieveResponse:
        """
        Retrieves detailed information about a specific task.

        Args:
          id: The unique identifier of the task

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/v0/tasks/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TaskRetrieveResponse,
        )

    def update(
        self,
        id: str,
        *,
        delete_empty_source_topic: bool | Omit = omit,
        description: str | Omit = omit,
        input_examples: SequenceNotStr[str] | Omit = omit,
        is_verified: bool | Omit = omit,
        metadata: Optional[Dict[str, object]] | Omit = omit,
        simulated_prompt_schema: Optional[Dict[str, object]] | Omit = omit,
        title: str | Omit = omit,
        topic_id: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TaskUpdateResponse:
        """
        Updates an existing task with the provided information.

        Args:
          id: The unique identifier of the task

          delete_empty_source_topic: If true and the task is moved to a different topic, the source topic will be
              deleted if it has no remaining tasks. Warning: this is a destructive operation —
              the source topic will be permanently removed when empty.

          description: A short description of the task

          input_examples: Example inputs for the task

          is_verified: Whether the task has been verified

          metadata: Replace the existing task metadata. Use null to clear all metadata for the task.

          simulated_prompt_schema: JSON schema that defines the structure for user prompts that should be generated
              for tests

          title: The title of the task

          topic_id: ID of the topic this task belongs to

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            path_template("/v0/tasks/{id}", id=id),
            body=maybe_transform(
                {
                    "delete_empty_source_topic": delete_empty_source_topic,
                    "description": description,
                    "input_examples": input_examples,
                    "is_verified": is_verified,
                    "metadata": metadata,
                    "simulated_prompt_schema": simulated_prompt_schema,
                    "title": title,
                    "topic_id": topic_id,
                },
                task_update_params.TaskUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TaskUpdateResponse,
        )

    def list(
        self,
        *,
        confidence_level: List[Literal["HIGH", "MEDIUM", "LOW"]] | Omit = omit,
        eval_definition_id: SequenceNotStr[str] | Omit = omit,
        limit: int | Omit = omit,
        order_by: Literal["createdAt", "modifiedAt", "title", "status", "type", "lastTest", "id"] | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        search: str | Omit = omit,
        skip: int | Omit = omit,
        stability_level: List[Literal["HIGH", "MEDIUM", "LOW"]] | Omit = omit,
        status: List[Literal["success", "warning", "error", "no-tests"]] | Omit = omit,
        tag_id: SequenceNotStr[str] | Omit = omit,
        topic_id: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPagination[TaskListResponse]:
        """
        Retrieves a paginated list of tasks with optional filtering.

        Args:
          confidence_level: Filter tasks by confidence level.

          eval_definition_id: Filter tasks by eval definition ID

          limit: Number of items to include in the result set.

          order_by: Field to order the result set by.

          order_dir: Order direction.

          search: Search tasks by title or description (case-insensitive partial match)

          skip: Number of items to skip before starting to collect the result set.

          stability_level: Filter tasks by stability level.

          status: Filter tasks by status

          tag_id: Filter tasks by tag ID

          topic_id: Filter tasks by topic ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/tasks",
            page=SyncOffsetPagination[TaskListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "confidence_level": confidence_level,
                        "eval_definition_id": eval_definition_id,
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "search": search,
                        "skip": skip,
                        "stability_level": stability_level,
                        "status": status,
                        "tag_id": tag_id,
                        "topic_id": topic_id,
                    },
                    task_list_params.TaskListParams,
                ),
            ),
            model=TaskListResponse,
        )

    def trigger(
        self,
        *,
        task_ids: SequenceNotStr[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Triggers the execution of a task.

        Args:
          task_ids: Array of task IDs to trigger

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/v0/tasks/trigger",
            body=maybe_transform({"task_ids": task_ids}, task_trigger_params.TaskTriggerParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncTasksResource(AsyncAPIResource):
    @cached_property
    def tags(self) -> AsyncTagsResource:
        return AsyncTagsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncTasksResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return AsyncTasksResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncTasksResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return AsyncTasksResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        description: str,
        title: str,
        input_examples: SequenceNotStr[str] | Omit = omit,
        metadata: Dict[str, object] | Omit = omit,
        quickstart_id: str | Omit = omit,
        simulated_prompt_schema: Dict[str, object] | Omit = omit,
        topic_id: str | Omit = omit,
        type: Literal["STATIC", "NORMAL"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TaskCreateResponse:
        """
        Creates a new task.

        Args:
          description: A short description of the task

          title: The title of the task

          input_examples: Static user prompts for the task. Required when type is STATIC.

          metadata: Optional metadata to associate with the task when creating it (e.g., external
              identifiers).

          quickstart_id: ID of the quickstart this task was generated from

          simulated_prompt_schema: JSON schema that defines the structure for user prompts that should be generated
              for tests

          topic_id: ID of the topic this task belongs to

          type: The type of task

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v0/tasks",
            body=await async_maybe_transform(
                {
                    "description": description,
                    "title": title,
                    "input_examples": input_examples,
                    "metadata": metadata,
                    "quickstart_id": quickstart_id,
                    "simulated_prompt_schema": simulated_prompt_schema,
                    "topic_id": topic_id,
                    "type": type,
                },
                task_create_params.TaskCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TaskCreateResponse,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TaskRetrieveResponse:
        """
        Retrieves detailed information about a specific task.

        Args:
          id: The unique identifier of the task

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/v0/tasks/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TaskRetrieveResponse,
        )

    async def update(
        self,
        id: str,
        *,
        delete_empty_source_topic: bool | Omit = omit,
        description: str | Omit = omit,
        input_examples: SequenceNotStr[str] | Omit = omit,
        is_verified: bool | Omit = omit,
        metadata: Optional[Dict[str, object]] | Omit = omit,
        simulated_prompt_schema: Optional[Dict[str, object]] | Omit = omit,
        title: str | Omit = omit,
        topic_id: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TaskUpdateResponse:
        """
        Updates an existing task with the provided information.

        Args:
          id: The unique identifier of the task

          delete_empty_source_topic: If true and the task is moved to a different topic, the source topic will be
              deleted if it has no remaining tasks. Warning: this is a destructive operation —
              the source topic will be permanently removed when empty.

          description: A short description of the task

          input_examples: Example inputs for the task

          is_verified: Whether the task has been verified

          metadata: Replace the existing task metadata. Use null to clear all metadata for the task.

          simulated_prompt_schema: JSON schema that defines the structure for user prompts that should be generated
              for tests

          title: The title of the task

          topic_id: ID of the topic this task belongs to

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            path_template("/v0/tasks/{id}", id=id),
            body=await async_maybe_transform(
                {
                    "delete_empty_source_topic": delete_empty_source_topic,
                    "description": description,
                    "input_examples": input_examples,
                    "is_verified": is_verified,
                    "metadata": metadata,
                    "simulated_prompt_schema": simulated_prompt_schema,
                    "title": title,
                    "topic_id": topic_id,
                },
                task_update_params.TaskUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TaskUpdateResponse,
        )

    def list(
        self,
        *,
        confidence_level: List[Literal["HIGH", "MEDIUM", "LOW"]] | Omit = omit,
        eval_definition_id: SequenceNotStr[str] | Omit = omit,
        limit: int | Omit = omit,
        order_by: Literal["createdAt", "modifiedAt", "title", "status", "type", "lastTest", "id"] | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        search: str | Omit = omit,
        skip: int | Omit = omit,
        stability_level: List[Literal["HIGH", "MEDIUM", "LOW"]] | Omit = omit,
        status: List[Literal["success", "warning", "error", "no-tests"]] | Omit = omit,
        tag_id: SequenceNotStr[str] | Omit = omit,
        topic_id: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[TaskListResponse, AsyncOffsetPagination[TaskListResponse]]:
        """
        Retrieves a paginated list of tasks with optional filtering.

        Args:
          confidence_level: Filter tasks by confidence level.

          eval_definition_id: Filter tasks by eval definition ID

          limit: Number of items to include in the result set.

          order_by: Field to order the result set by.

          order_dir: Order direction.

          search: Search tasks by title or description (case-insensitive partial match)

          skip: Number of items to skip before starting to collect the result set.

          stability_level: Filter tasks by stability level.

          status: Filter tasks by status

          tag_id: Filter tasks by tag ID

          topic_id: Filter tasks by topic ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/tasks",
            page=AsyncOffsetPagination[TaskListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "confidence_level": confidence_level,
                        "eval_definition_id": eval_definition_id,
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "search": search,
                        "skip": skip,
                        "stability_level": stability_level,
                        "status": status,
                        "tag_id": tag_id,
                        "topic_id": topic_id,
                    },
                    task_list_params.TaskListParams,
                ),
            ),
            model=TaskListResponse,
        )

    async def trigger(
        self,
        *,
        task_ids: SequenceNotStr[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Triggers the execution of a task.

        Args:
          task_ids: Array of task IDs to trigger

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/v0/tasks/trigger",
            body=await async_maybe_transform({"task_ids": task_ids}, task_trigger_params.TaskTriggerParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class TasksResourceWithRawResponse:
    def __init__(self, tasks: TasksResource) -> None:
        self._tasks = tasks

        self.create = to_raw_response_wrapper(
            tasks.create,
        )
        self.retrieve = to_raw_response_wrapper(
            tasks.retrieve,
        )
        self.update = to_raw_response_wrapper(
            tasks.update,
        )
        self.list = to_raw_response_wrapper(
            tasks.list,
        )
        self.trigger = to_raw_response_wrapper(
            tasks.trigger,
        )

    @cached_property
    def tags(self) -> TagsResourceWithRawResponse:
        return TagsResourceWithRawResponse(self._tasks.tags)


class AsyncTasksResourceWithRawResponse:
    def __init__(self, tasks: AsyncTasksResource) -> None:
        self._tasks = tasks

        self.create = async_to_raw_response_wrapper(
            tasks.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            tasks.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            tasks.update,
        )
        self.list = async_to_raw_response_wrapper(
            tasks.list,
        )
        self.trigger = async_to_raw_response_wrapper(
            tasks.trigger,
        )

    @cached_property
    def tags(self) -> AsyncTagsResourceWithRawResponse:
        return AsyncTagsResourceWithRawResponse(self._tasks.tags)


class TasksResourceWithStreamingResponse:
    def __init__(self, tasks: TasksResource) -> None:
        self._tasks = tasks

        self.create = to_streamed_response_wrapper(
            tasks.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            tasks.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            tasks.update,
        )
        self.list = to_streamed_response_wrapper(
            tasks.list,
        )
        self.trigger = to_streamed_response_wrapper(
            tasks.trigger,
        )

    @cached_property
    def tags(self) -> TagsResourceWithStreamingResponse:
        return TagsResourceWithStreamingResponse(self._tasks.tags)


class AsyncTasksResourceWithStreamingResponse:
    def __init__(self, tasks: AsyncTasksResource) -> None:
        self._tasks = tasks

        self.create = async_to_streamed_response_wrapper(
            tasks.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            tasks.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            tasks.update,
        )
        self.list = async_to_streamed_response_wrapper(
            tasks.list,
        )
        self.trigger = async_to_streamed_response_wrapper(
            tasks.trigger,
        )

    @cached_property
    def tags(self) -> AsyncTagsResourceWithStreamingResponse:
        return AsyncTagsResourceWithStreamingResponse(self._tasks.tags)
