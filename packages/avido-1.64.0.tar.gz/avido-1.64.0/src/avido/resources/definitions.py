# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import (
    EvalType,
    definition_link_params,
    definition_list_params,
    definition_create_params,
    definition_unlink_params,
    definition_update_params,
)
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, SequenceNotStr, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncOffsetPagination, AsyncOffsetPagination
from .._base_client import AsyncPaginator, make_request_options
from ..types.eval_type import EvalType
from ..types.eval_definition import EvalDefinition
from ..types.definition_create_response import DefinitionCreateResponse
from ..types.definition_update_response import DefinitionUpdateResponse

__all__ = ["DefinitionsResource", "AsyncDefinitionsResource"]


class DefinitionsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> DefinitionsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return DefinitionsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> DefinitionsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return DefinitionsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        name: str,
        type: EvalType,
        global_config: definition_create_params.GlobalConfig | Omit = omit,
        quickstart_id: str | Omit = omit,
        style_guide_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DefinitionCreateResponse:
        """
        Creates a new evaluation definition for an application.

        Args:
          quickstart_id: Optional quickstart ID. When provided, the eval definition is linked to the
              quickstart and created with status DRAFT.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v0/definitions",
            body=maybe_transform(
                {
                    "name": name,
                    "type": type,
                    "global_config": global_config,
                    "quickstart_id": quickstart_id,
                    "style_guide_id": style_guide_id,
                },
                definition_create_params.DefinitionCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DefinitionCreateResponse,
        )

    def update(
        self,
        id: str,
        *,
        global_config: definition_update_params.GlobalConfig | Omit = omit,
        name: str | Omit = omit,
        style_guide_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DefinitionUpdateResponse:
        """
        Updates an existing evaluation definition.

        Args:
          id: The unique identifier of the evaluation definition

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            path_template("/v0/definitions/{id}", id=id),
            body=maybe_transform(
                {
                    "global_config": global_config,
                    "name": name,
                    "style_guide_id": style_guide_id,
                },
                definition_update_params.DefinitionUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DefinitionUpdateResponse,
        )

    def list(
        self,
        *,
        definition_status: Literal["DRAFT", "ACTIVE"] | Omit = omit,
        limit: int | Omit = omit,
        order_by: Literal["createdAt", "modifiedAt", "name", "type", "id"] | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        quickstart_id: str | Omit = omit,
        scope_type: Literal["topic", "application"] | Omit = omit,
        skip: int | Omit = omit,
        status: Literal["PENDING", "IN_PROGRESS", "COMPLETED", "FAILED", "SKIPPED"] | Omit = omit,
        task_id: str | Omit = omit,
        topic_id: str | Omit = omit,
        trace_id: str | Omit = omit,
        type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPagination[EvalDefinition]:
        """
        Retrieves a paginated list of evaluation definitions for an application.

        Args:
          definition_status: Filter by eval definition status (DRAFT or ACTIVE). Defaults to ACTIVE when not
              provided.

          limit: Number of items to include in the result set.

          order_by: Field to order the result set by.

          order_dir: Order direction.

          quickstart_id: Filter by quickstart ID (for quickstart-scoped evals)

          scope_type: Filter by eval definition scope (topic-scoped or application-wide). Ignored if
              'topicId' is specified.

          skip: Number of items to skip before starting to collect the result set.

          status: Filter by evaluation status (e.g. COMPLETED)

          task_id: Filter by task ID

          topic_id: Filter by specific topic ID. When provided, 'scopeType' parameter is ignored as
              this inherently filters topic-scoped evals.

          trace_id: Filter by trace ID

          type: Filter by evaluation type (e.g. NATURALNESS)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/definitions",
            page=SyncOffsetPagination[EvalDefinition],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "definition_status": definition_status,
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "quickstart_id": quickstart_id,
                        "scope_type": scope_type,
                        "skip": skip,
                        "status": status,
                        "task_id": task_id,
                        "topic_id": topic_id,
                        "trace_id": trace_id,
                        "type": type,
                    },
                    definition_list_params.DefinitionListParams,
                ),
            ),
            model=EvalDefinition,
        )

    def link(
        self,
        *,
        eval_ids: SequenceNotStr[str],
        task_ids: SequenceNotStr[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Associates an evaluation definition with a task for automatic evaluation.

        Args:
          eval_ids: Array of evaluation definition IDs to link/unlink. Can be a single ID or
              multiple IDs.

          task_ids: Array of task IDs to link/unlink the evaluation definitions to/from. Can be a
              single ID or multiple IDs.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/v0/definitions/link",
            body=maybe_transform(
                {
                    "eval_ids": eval_ids,
                    "task_ids": task_ids,
                },
                definition_link_params.DefinitionLinkParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def unlink(
        self,
        *,
        eval_ids: SequenceNotStr[str],
        task_ids: SequenceNotStr[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Removes the association between an evaluation definition and a task.

        Args:
          eval_ids: Array of evaluation definition IDs to link/unlink. Can be a single ID or
              multiple IDs.

          task_ids: Array of task IDs to link/unlink the evaluation definitions to/from. Can be a
              single ID or multiple IDs.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/v0/definitions/unlink",
            body=maybe_transform(
                {
                    "eval_ids": eval_ids,
                    "task_ids": task_ids,
                },
                definition_unlink_params.DefinitionUnlinkParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncDefinitionsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncDefinitionsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Avido-AI/avido-py#accessing-raw-response-data-eg-headers
        """
        return AsyncDefinitionsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncDefinitionsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Avido-AI/avido-py#with_streaming_response
        """
        return AsyncDefinitionsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        name: str,
        type: EvalType,
        global_config: definition_create_params.GlobalConfig | Omit = omit,
        quickstart_id: str | Omit = omit,
        style_guide_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DefinitionCreateResponse:
        """
        Creates a new evaluation definition for an application.

        Args:
          quickstart_id: Optional quickstart ID. When provided, the eval definition is linked to the
              quickstart and created with status DRAFT.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v0/definitions",
            body=await async_maybe_transform(
                {
                    "name": name,
                    "type": type,
                    "global_config": global_config,
                    "quickstart_id": quickstart_id,
                    "style_guide_id": style_guide_id,
                },
                definition_create_params.DefinitionCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DefinitionCreateResponse,
        )

    async def update(
        self,
        id: str,
        *,
        global_config: definition_update_params.GlobalConfig | Omit = omit,
        name: str | Omit = omit,
        style_guide_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DefinitionUpdateResponse:
        """
        Updates an existing evaluation definition.

        Args:
          id: The unique identifier of the evaluation definition

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            path_template("/v0/definitions/{id}", id=id),
            body=await async_maybe_transform(
                {
                    "global_config": global_config,
                    "name": name,
                    "style_guide_id": style_guide_id,
                },
                definition_update_params.DefinitionUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DefinitionUpdateResponse,
        )

    def list(
        self,
        *,
        definition_status: Literal["DRAFT", "ACTIVE"] | Omit = omit,
        limit: int | Omit = omit,
        order_by: Literal["createdAt", "modifiedAt", "name", "type", "id"] | Omit = omit,
        order_dir: Literal["asc", "desc"] | Omit = omit,
        quickstart_id: str | Omit = omit,
        scope_type: Literal["topic", "application"] | Omit = omit,
        skip: int | Omit = omit,
        status: Literal["PENDING", "IN_PROGRESS", "COMPLETED", "FAILED", "SKIPPED"] | Omit = omit,
        task_id: str | Omit = omit,
        topic_id: str | Omit = omit,
        trace_id: str | Omit = omit,
        type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[EvalDefinition, AsyncOffsetPagination[EvalDefinition]]:
        """
        Retrieves a paginated list of evaluation definitions for an application.

        Args:
          definition_status: Filter by eval definition status (DRAFT or ACTIVE). Defaults to ACTIVE when not
              provided.

          limit: Number of items to include in the result set.

          order_by: Field to order the result set by.

          order_dir: Order direction.

          quickstart_id: Filter by quickstart ID (for quickstart-scoped evals)

          scope_type: Filter by eval definition scope (topic-scoped or application-wide). Ignored if
              'topicId' is specified.

          skip: Number of items to skip before starting to collect the result set.

          status: Filter by evaluation status (e.g. COMPLETED)

          task_id: Filter by task ID

          topic_id: Filter by specific topic ID. When provided, 'scopeType' parameter is ignored as
              this inherently filters topic-scoped evals.

          trace_id: Filter by trace ID

          type: Filter by evaluation type (e.g. NATURALNESS)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v0/definitions",
            page=AsyncOffsetPagination[EvalDefinition],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "definition_status": definition_status,
                        "limit": limit,
                        "order_by": order_by,
                        "order_dir": order_dir,
                        "quickstart_id": quickstart_id,
                        "scope_type": scope_type,
                        "skip": skip,
                        "status": status,
                        "task_id": task_id,
                        "topic_id": topic_id,
                        "trace_id": trace_id,
                        "type": type,
                    },
                    definition_list_params.DefinitionListParams,
                ),
            ),
            model=EvalDefinition,
        )

    async def link(
        self,
        *,
        eval_ids: SequenceNotStr[str],
        task_ids: SequenceNotStr[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Associates an evaluation definition with a task for automatic evaluation.

        Args:
          eval_ids: Array of evaluation definition IDs to link/unlink. Can be a single ID or
              multiple IDs.

          task_ids: Array of task IDs to link/unlink the evaluation definitions to/from. Can be a
              single ID or multiple IDs.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/v0/definitions/link",
            body=await async_maybe_transform(
                {
                    "eval_ids": eval_ids,
                    "task_ids": task_ids,
                },
                definition_link_params.DefinitionLinkParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def unlink(
        self,
        *,
        eval_ids: SequenceNotStr[str],
        task_ids: SequenceNotStr[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Removes the association between an evaluation definition and a task.

        Args:
          eval_ids: Array of evaluation definition IDs to link/unlink. Can be a single ID or
              multiple IDs.

          task_ids: Array of task IDs to link/unlink the evaluation definitions to/from. Can be a
              single ID or multiple IDs.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/v0/definitions/unlink",
            body=await async_maybe_transform(
                {
                    "eval_ids": eval_ids,
                    "task_ids": task_ids,
                },
                definition_unlink_params.DefinitionUnlinkParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class DefinitionsResourceWithRawResponse:
    def __init__(self, definitions: DefinitionsResource) -> None:
        self._definitions = definitions

        self.create = to_raw_response_wrapper(
            definitions.create,
        )
        self.update = to_raw_response_wrapper(
            definitions.update,
        )
        self.list = to_raw_response_wrapper(
            definitions.list,
        )
        self.link = to_raw_response_wrapper(
            definitions.link,
        )
        self.unlink = to_raw_response_wrapper(
            definitions.unlink,
        )


class AsyncDefinitionsResourceWithRawResponse:
    def __init__(self, definitions: AsyncDefinitionsResource) -> None:
        self._definitions = definitions

        self.create = async_to_raw_response_wrapper(
            definitions.create,
        )
        self.update = async_to_raw_response_wrapper(
            definitions.update,
        )
        self.list = async_to_raw_response_wrapper(
            definitions.list,
        )
        self.link = async_to_raw_response_wrapper(
            definitions.link,
        )
        self.unlink = async_to_raw_response_wrapper(
            definitions.unlink,
        )


class DefinitionsResourceWithStreamingResponse:
    def __init__(self, definitions: DefinitionsResource) -> None:
        self._definitions = definitions

        self.create = to_streamed_response_wrapper(
            definitions.create,
        )
        self.update = to_streamed_response_wrapper(
            definitions.update,
        )
        self.list = to_streamed_response_wrapper(
            definitions.list,
        )
        self.link = to_streamed_response_wrapper(
            definitions.link,
        )
        self.unlink = to_streamed_response_wrapper(
            definitions.unlink,
        )


class AsyncDefinitionsResourceWithStreamingResponse:
    def __init__(self, definitions: AsyncDefinitionsResource) -> None:
        self._definitions = definitions

        self.create = async_to_streamed_response_wrapper(
            definitions.create,
        )
        self.update = async_to_streamed_response_wrapper(
            definitions.update,
        )
        self.list = async_to_streamed_response_wrapper(
            definitions.list,
        )
        self.link = async_to_streamed_response_wrapper(
            definitions.link,
        )
        self.unlink = async_to_streamed_response_wrapper(
            definitions.unlink,
        )
