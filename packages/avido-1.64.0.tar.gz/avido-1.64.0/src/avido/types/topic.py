# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from . import eval_definition as _eval_definition
from .._models import BaseModel

__all__ = ["Topic", "AssignedUser", "EvalDefinition", "EvalDefinitionConfig"]


class AssignedUser(BaseModel):
    """Information about the assigned user"""

    id: str
    """User ID"""

    email: str
    """User email"""

    name: str
    """User full name"""

    image: Optional[str] = None
    """User profile image URL"""


class EvalDefinitionConfig(BaseModel):
    expected: Union[str, List[str]]


class EvalDefinition(BaseModel):
    eval_definition: _eval_definition.EvalDefinition = FieldInfo(alias="evalDefinition")

    topic_id: str = FieldInfo(alias="topicId")

    config: Optional[EvalDefinitionConfig] = None


class Topic(BaseModel):
    """Details about a single Topic"""

    id: str
    """Unique identifier of the topic"""

    application_id: str = FieldInfo(alias="applicationId")
    """Application ID this topic belongs to"""

    baseline: Optional[float] = None
    """Optional baseline score for this topic"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the topic was created"""

    is_documents_verified: bool = FieldInfo(alias="isDocumentsVerified")
    """Whether all documents assigned to the topic are signed off"""

    is_knowledge_base_verified: bool = FieldInfo(alias="isKnowledgeBaseVerified")
    """
    Whether the knowledge base for this topic has been fully verified (facts and
    coverage reviewed)
    """

    is_policies_verified: bool = FieldInfo(alias="isPoliciesVerified")
    """
    Whether the policies for this topic (eval definitions and style guide) have been
    fully verified
    """

    is_tasks_verified: bool = FieldInfo(alias="isTasksVerified")
    """Whether all tasks in the topic are verified (excludes deduced tasks)"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the topic was last modified"""

    org_id: str = FieldInfo(alias="orgId")
    """Organization ID that owns this topic"""

    status: Literal["DRAFT", "ACTIVE", "ARCHIVED"]
    """Status of the topic (DRAFT or ACTIVE)"""

    title: str
    """Title of the topic"""

    assigned_to: Optional[str] = FieldInfo(alias="assignedTo", default=None)
    """User ID of the assigned user"""

    assigned_user: Optional[AssignedUser] = FieldInfo(alias="assignedUser", default=None)
    """Information about the assigned user"""

    document_count: Optional[int] = FieldInfo(alias="documentCount", default=None)
    """Number of documents assigned to this topic"""

    eval_definitions: Optional[List[EvalDefinition]] = FieldInfo(alias="evalDefinitions", default=None)
    """Evaluation definitions linked to this topic"""

    task_count: Optional[int] = FieldInfo(alias="taskCount", default=None)
    """Number of active tasks in this topic"""
