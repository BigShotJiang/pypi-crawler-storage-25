# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .core_tag import CoreTag
from .eval_definition import EvalDefinition

__all__ = [
    "TaskListResponse",
    "Combined",
    "CombinedConfidence",
    "CombinedConfidenceInterval",
    "CombinedStability",
    "Monitoring",
    "MonitoringConfidence",
    "MonitoringConfidenceInterval",
    "MonitoringStability",
    "Synthetic",
    "SyntheticConfidence",
    "SyntheticConfidenceInterval",
    "SyntheticStability",
    "Breakdown",
    "BreakdownMonitoring",
    "BreakdownMonitoringMetrics",
    "BreakdownMonitoringMetricsConfidence",
    "BreakdownMonitoringMetricsConfidenceInterval",
    "BreakdownMonitoringMetricsStability",
    "BreakdownSynthetic",
    "BreakdownSyntheticMetrics",
    "BreakdownSyntheticMetricsConfidence",
    "BreakdownSyntheticMetricsConfidenceInterval",
    "BreakdownSyntheticMetricsStability",
    "TaskSchedule",
]


class CombinedConfidenceInterval(BaseModel):
    lower: float
    """Lower bound of the 95% confidence interval (0-100)."""

    upper: float
    """Upper bound of the 95% confidence interval (0-100)."""


class CombinedConfidence(BaseModel):
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    half_width: float = FieldInfo(alias="halfWidth")
    """
    Half-width of the 95% confidence interval around the pass rate (percentage
    points).
    """

    interval: CombinedConfidenceInterval

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """
    Statistical confidence level based on the width of the 95% confidence interval
    around the pass rate.
    """


class CombinedStability(BaseModel):
    """Score stability based on the standard deviation of evaluation scores."""

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """Score stability level based on the standard deviation of evaluation scores."""

    stddev: Optional[float] = None
    """Sample standard deviation of evaluation scores.

    Null when fewer than 2 evaluations exist.
    """


class Combined(BaseModel):
    """Combined metrics across synthetic and monitoring runs."""

    confidence: CombinedConfidence
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    evaluations: int
    """Total number of evaluations in this bucket."""

    health_score: Optional[float] = FieldInfo(alias="healthScore", default=None)
    """
    Overall health score (0-100) combining pass rate (60%), confidence (20%), and
    stability (20%). Null when confidence is LOW (unreliable measurement with >15pp
    margin of error). Green: 90-100, Yellow: 60-89, Red: 0-59.
    """

    passed: int
    """Number of evaluations that passed in this bucket."""

    pass_rate: Optional[float] = FieldInfo(alias="passRate", default=None)
    """Pass rate as a percentage (0-100). Null when no evaluations exist."""

    recommended_additional_evaluations: int = FieldInfo(alias="recommendedAdditionalEvaluations")
    """Number of additional evaluations recommended to reach High confidence."""

    stability: CombinedStability
    """Score stability based on the standard deviation of evaluation scores."""


class MonitoringConfidenceInterval(BaseModel):
    lower: float
    """Lower bound of the 95% confidence interval (0-100)."""

    upper: float
    """Upper bound of the 95% confidence interval (0-100)."""


class MonitoringConfidence(BaseModel):
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    half_width: float = FieldInfo(alias="halfWidth")
    """
    Half-width of the 95% confidence interval around the pass rate (percentage
    points).
    """

    interval: MonitoringConfidenceInterval

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """
    Statistical confidence level based on the width of the 95% confidence interval
    around the pass rate.
    """


class MonitoringStability(BaseModel):
    """Score stability based on the standard deviation of evaluation scores."""

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """Score stability level based on the standard deviation of evaluation scores."""

    stddev: Optional[float] = None
    """Sample standard deviation of evaluation scores.

    Null when fewer than 2 evaluations exist.
    """


class Monitoring(BaseModel):
    """Metrics for monitoring (production traffic) runs."""

    confidence: MonitoringConfidence
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    evaluations: int
    """Total number of evaluations in this bucket."""

    health_score: Optional[float] = FieldInfo(alias="healthScore", default=None)
    """
    Overall health score (0-100) combining pass rate (60%), confidence (20%), and
    stability (20%). Null when confidence is LOW (unreliable measurement with >15pp
    margin of error). Green: 90-100, Yellow: 60-89, Red: 0-59.
    """

    passed: int
    """Number of evaluations that passed in this bucket."""

    pass_rate: Optional[float] = FieldInfo(alias="passRate", default=None)
    """Pass rate as a percentage (0-100). Null when no evaluations exist."""

    recommended_additional_evaluations: int = FieldInfo(alias="recommendedAdditionalEvaluations")
    """Number of additional evaluations recommended to reach High confidence."""

    stability: MonitoringStability
    """Score stability based on the standard deviation of evaluation scores."""


class SyntheticConfidenceInterval(BaseModel):
    lower: float
    """Lower bound of the 95% confidence interval (0-100)."""

    upper: float
    """Upper bound of the 95% confidence interval (0-100)."""


class SyntheticConfidence(BaseModel):
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    half_width: float = FieldInfo(alias="halfWidth")
    """
    Half-width of the 95% confidence interval around the pass rate (percentage
    points).
    """

    interval: SyntheticConfidenceInterval

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """
    Statistical confidence level based on the width of the 95% confidence interval
    around the pass rate.
    """


class SyntheticStability(BaseModel):
    """Score stability based on the standard deviation of evaluation scores."""

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """Score stability level based on the standard deviation of evaluation scores."""

    stddev: Optional[float] = None
    """Sample standard deviation of evaluation scores.

    Null when fewer than 2 evaluations exist.
    """


class Synthetic(BaseModel):
    """Metrics for synthetic (controlled test) runs."""

    confidence: SyntheticConfidence
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    evaluations: int
    """Total number of evaluations in this bucket."""

    health_score: Optional[float] = FieldInfo(alias="healthScore", default=None)
    """
    Overall health score (0-100) combining pass rate (60%), confidence (20%), and
    stability (20%). Null when confidence is LOW (unreliable measurement with >15pp
    margin of error). Green: 90-100, Yellow: 60-89, Red: 0-59.
    """

    passed: int
    """Number of evaluations that passed in this bucket."""

    pass_rate: Optional[float] = FieldInfo(alias="passRate", default=None)
    """Pass rate as a percentage (0-100). Null when no evaluations exist."""

    recommended_additional_evaluations: int = FieldInfo(alias="recommendedAdditionalEvaluations")
    """Number of additional evaluations recommended to reach High confidence."""

    stability: SyntheticStability
    """Score stability based on the standard deviation of evaluation scores."""


class BreakdownMonitoringMetricsConfidenceInterval(BaseModel):
    lower: float
    """Lower bound of the 95% confidence interval (0-100)."""

    upper: float
    """Upper bound of the 95% confidence interval (0-100)."""


class BreakdownMonitoringMetricsConfidence(BaseModel):
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    half_width: float = FieldInfo(alias="halfWidth")
    """
    Half-width of the 95% confidence interval around the pass rate (percentage
    points).
    """

    interval: BreakdownMonitoringMetricsConfidenceInterval

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """
    Statistical confidence level based on the width of the 95% confidence interval
    around the pass rate.
    """


class BreakdownMonitoringMetricsStability(BaseModel):
    """Score stability based on the standard deviation of evaluation scores."""

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """Score stability level based on the standard deviation of evaluation scores."""

    stddev: Optional[float] = None
    """Sample standard deviation of evaluation scores.

    Null when fewer than 2 evaluations exist.
    """


class BreakdownMonitoringMetrics(BaseModel):
    """
    Aggregated evaluation metrics for a single run-type bucket (synthetic, monitoring, or combined).
    """

    confidence: BreakdownMonitoringMetricsConfidence
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    evaluations: int
    """Total number of evaluations in this bucket."""

    health_score: Optional[float] = FieldInfo(alias="healthScore", default=None)
    """
    Overall health score (0-100) combining pass rate (60%), confidence (20%), and
    stability (20%). Null when confidence is LOW (unreliable measurement with >15pp
    margin of error). Green: 90-100, Yellow: 60-89, Red: 0-59.
    """

    passed: int
    """Number of evaluations that passed in this bucket."""

    pass_rate: Optional[float] = FieldInfo(alias="passRate", default=None)
    """Pass rate as a percentage (0-100). Null when no evaluations exist."""

    recommended_additional_evaluations: int = FieldInfo(alias="recommendedAdditionalEvaluations")
    """Number of additional evaluations recommended to reach High confidence."""

    stability: BreakdownMonitoringMetricsStability
    """Score stability based on the standard deviation of evaluation scores."""


class BreakdownMonitoring(BaseModel):
    """
    Evaluation metrics broken down by a single eval definition within a run-type bucket.
    """

    eval_definition_id: str = FieldInfo(alias="evalDefinitionId")
    """ID of the eval definition."""

    eval_definition_name: str = FieldInfo(alias="evalDefinitionName")
    """Display name of the eval definition."""

    metrics: BreakdownMonitoringMetrics
    """
    Aggregated evaluation metrics for a single run-type bucket (synthetic,
    monitoring, or combined).
    """


class BreakdownSyntheticMetricsConfidenceInterval(BaseModel):
    lower: float
    """Lower bound of the 95% confidence interval (0-100)."""

    upper: float
    """Upper bound of the 95% confidence interval (0-100)."""


class BreakdownSyntheticMetricsConfidence(BaseModel):
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    half_width: float = FieldInfo(alias="halfWidth")
    """
    Half-width of the 95% confidence interval around the pass rate (percentage
    points).
    """

    interval: BreakdownSyntheticMetricsConfidenceInterval

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """
    Statistical confidence level based on the width of the 95% confidence interval
    around the pass rate.
    """


class BreakdownSyntheticMetricsStability(BaseModel):
    """Score stability based on the standard deviation of evaluation scores."""

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """Score stability level based on the standard deviation of evaluation scores."""

    stddev: Optional[float] = None
    """Sample standard deviation of evaluation scores.

    Null when fewer than 2 evaluations exist.
    """


class BreakdownSyntheticMetrics(BaseModel):
    """
    Aggregated evaluation metrics for a single run-type bucket (synthetic, monitoring, or combined).
    """

    confidence: BreakdownSyntheticMetricsConfidence
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    evaluations: int
    """Total number of evaluations in this bucket."""

    health_score: Optional[float] = FieldInfo(alias="healthScore", default=None)
    """
    Overall health score (0-100) combining pass rate (60%), confidence (20%), and
    stability (20%). Null when confidence is LOW (unreliable measurement with >15pp
    margin of error). Green: 90-100, Yellow: 60-89, Red: 0-59.
    """

    passed: int
    """Number of evaluations that passed in this bucket."""

    pass_rate: Optional[float] = FieldInfo(alias="passRate", default=None)
    """Pass rate as a percentage (0-100). Null when no evaluations exist."""

    recommended_additional_evaluations: int = FieldInfo(alias="recommendedAdditionalEvaluations")
    """Number of additional evaluations recommended to reach High confidence."""

    stability: BreakdownSyntheticMetricsStability
    """Score stability based on the standard deviation of evaluation scores."""


class BreakdownSynthetic(BaseModel):
    """
    Evaluation metrics broken down by a single eval definition within a run-type bucket.
    """

    eval_definition_id: str = FieldInfo(alias="evalDefinitionId")
    """ID of the eval definition."""

    eval_definition_name: str = FieldInfo(alias="evalDefinitionName")
    """Display name of the eval definition."""

    metrics: BreakdownSyntheticMetrics
    """
    Aggregated evaluation metrics for a single run-type bucket (synthetic,
    monitoring, or combined).
    """


class Breakdown(BaseModel):
    """Per-eval-definition breakdown by run-type bucket.

    Present on detail endpoint only.
    """

    monitoring: List[BreakdownMonitoring]
    """Per-eval-definition breakdown for monitoring (production traffic) runs."""

    synthetic: List[BreakdownSynthetic]
    """Per-eval-definition breakdown for synthetic (controlled test) runs."""


class TaskSchedule(BaseModel):
    """Task schedule schema"""

    application_id: str = FieldInfo(alias="applicationId")

    criticality: Literal["LOW", "MEDIUM", "HIGH"]

    cron: str

    task_id: str = FieldInfo(alias="taskId")

    last_run_at: Optional[datetime] = FieldInfo(alias="lastRunAt", default=None)

    next_run_at: Optional[datetime] = FieldInfo(alias="nextRunAt", default=None)


class TaskListResponse(BaseModel):
    id: str
    """The unique identifier of the task"""

    combined: Combined
    """Combined metrics across synthetic and monitoring runs."""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the task was created"""

    description: str
    """The task description"""

    eval_definitions: List[EvalDefinition] = FieldInfo(alias="evalDefinitions")

    input_examples: List[str] = FieldInfo(alias="inputExamples")
    """Example inputs for the task"""

    is_verified: bool = FieldInfo(alias="isVerified")
    """Whether the task has been verified"""

    metadata: Dict[str, object]
    """Optional metadata associated with the task.

    Returns null when no metadata is stored.
    """

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the task was last modified"""

    monitoring: Monitoring
    """Metrics for monitoring (production traffic) runs."""

    monitoring_pass_rate: Optional[float] = FieldInfo(alias="monitoringPassRate", default=None)
    """Deprecated: use monitoring.passRate instead.

    The 30 day pass rate for monitoring runs only, measured in percentage. Null when
    no monitoring runs exist.
    """

    pass_rate: Optional[float] = FieldInfo(alias="passRate", default=None)
    """Deprecated: use synthetic.passRate instead.

    The 30 day pass rate for the task measured in percentage (excludes monitoring
    runs). Null when no tests have been run.
    """

    status: Literal["DEDUCED", "DRAFT", "ACTIVE", "ARCHIVED"]
    """The status of the task.

    DEDUCED tasks are created from unmatched traces, DRAFT tasks are user-facing
    drafts, and ACTIVE tasks are production tasks.
    """

    synthetic: Synthetic
    """Metrics for synthetic (controlled test) runs."""

    tags: List[CoreTag]

    title: str
    """The title of the task"""

    type: Literal["STATIC", "NORMAL"]
    """The type of task.

    Normal tasks have a dynamic user prompt, while adversarial tasks have a fixed
    user prompt.
    """

    breakdown: Optional[Breakdown] = None
    """Per-eval-definition breakdown by run-type bucket.

    Present on detail endpoint only.
    """

    last_test: Optional[datetime] = FieldInfo(alias="lastTest", default=None)
    """The date and time this task was last tested"""

    parent_id: Optional[str] = FieldInfo(alias="parentId", default=None)
    """The ID of the parent task (for DEDUCED tasks linked to a DRAFT)"""

    simulated_prompt_schema: Optional[Dict[str, object]] = FieldInfo(alias="simulatedPromptSchema", default=None)
    """
    JSON schema that defines the structure for user prompts that should be generated
    for tests
    """

    task_schedule: Optional[TaskSchedule] = FieldInfo(alias="taskSchedule", default=None)
    """Task schedule schema"""

    topic_id: Optional[str] = FieldInfo(alias="topicId", default=None)
    """The ID of the topic this task belongs to"""

    trace_id: Optional[str] = FieldInfo(alias="traceId", default=None)
    """The ID of the trace this task was deduced from (only for DEDUCED tasks)"""
