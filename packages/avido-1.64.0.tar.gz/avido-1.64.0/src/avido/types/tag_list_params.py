# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["TagListParams"]


class TagListParams(TypedDict, total=False):
    limit: int
    """Number of items to include in the result set."""

    order_by: Annotated[Literal["createdAt", "modifiedAt", "name", "status", "id"], PropertyInfo(alias="orderBy")]
    """Field to order the result set by."""

    order_dir: Annotated[Literal["asc", "desc"], PropertyInfo(alias="orderDir")]
    """Order direction."""

    search: str
    """Search in tag name and description"""

    skip: int
    """Number of items to skip before starting to collect the result set."""
