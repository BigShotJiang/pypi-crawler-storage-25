# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["IssueSource"]

IssueSource: TypeAlias = Literal["TEST", "TASK", "TOPIC", "SYSTEM", "MONITORING", "API", "HUMAN_ANNOTATION"]
