# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List
from typing_extensions import Literal, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["TaskListParams"]


class TaskListParams(TypedDict, total=False):
    confidence_level: Annotated[List[Literal["HIGH", "MEDIUM", "LOW"]], PropertyInfo(alias="confidenceLevel")]
    """Filter tasks by confidence level."""

    eval_definition_id: Annotated[SequenceNotStr[str], PropertyInfo(alias="evalDefinitionId")]
    """Filter tasks by eval definition ID"""

    limit: int
    """Number of items to include in the result set."""

    order_by: Annotated[
        Literal["createdAt", "modifiedAt", "title", "status", "type", "lastTest", "id"], PropertyInfo(alias="orderBy")
    ]
    """Field to order the result set by."""

    order_dir: Annotated[Literal["asc", "desc"], PropertyInfo(alias="orderDir")]
    """Order direction."""

    search: str
    """Search tasks by title or description (case-insensitive partial match)"""

    skip: int
    """Number of items to skip before starting to collect the result set."""

    stability_level: Annotated[List[Literal["HIGH", "MEDIUM", "LOW"]], PropertyInfo(alias="stabilityLevel")]
    """Filter tasks by stability level."""

    status: List[Literal["success", "warning", "error", "no-tests"]]
    """Filter tasks by status"""

    tag_id: Annotated[SequenceNotStr[str], PropertyInfo(alias="tagId")]
    """Filter tasks by tag ID"""

    topic_id: Annotated[SequenceNotStr[str], PropertyInfo(alias="topicId")]
    """Filter tasks by topic ID"""
