# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .eval_definition import EvalDefinition

__all__ = [
    "TaskRetrieveResponse",
    "Task",
    "TaskEvalDefinition",
    "TaskEvalDefinitionConfig",
    "TaskMonitoring",
    "TaskMonitoringConfidence",
    "TaskMonitoringConfidenceInterval",
    "TaskMonitoringStability",
    "TaskSynthetic",
    "TaskSyntheticConfidence",
    "TaskSyntheticConfidenceInterval",
    "TaskSyntheticStability",
    "TaskBreakdown",
    "TaskBreakdownMonitoring",
    "TaskBreakdownMonitoringMetrics",
    "TaskBreakdownMonitoringMetricsConfidence",
    "TaskBreakdownMonitoringMetricsConfidenceInterval",
    "TaskBreakdownMonitoringMetricsStability",
    "TaskBreakdownSynthetic",
    "TaskBreakdownSyntheticMetrics",
    "TaskBreakdownSyntheticMetricsConfidence",
    "TaskBreakdownSyntheticMetricsConfidenceInterval",
    "TaskBreakdownSyntheticMetricsStability",
    "TaskTaskSchedule",
]


class TaskEvalDefinitionConfig(BaseModel):
    expected: Union[str, List[str]]


class TaskEvalDefinition(BaseModel):
    eval_definition: EvalDefinition = FieldInfo(alias="evalDefinition")

    config: Optional[TaskEvalDefinitionConfig] = None


class TaskMonitoringConfidenceInterval(BaseModel):
    lower: float
    """Lower bound of the 95% confidence interval (0-100)."""

    upper: float
    """Upper bound of the 95% confidence interval (0-100)."""


class TaskMonitoringConfidence(BaseModel):
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    half_width: float = FieldInfo(alias="halfWidth")
    """
    Half-width of the 95% confidence interval around the pass rate (percentage
    points).
    """

    interval: TaskMonitoringConfidenceInterval

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """
    Statistical confidence level based on the width of the 95% confidence interval
    around the pass rate.
    """


class TaskMonitoringStability(BaseModel):
    """Score stability based on the standard deviation of evaluation scores."""

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """Score stability level based on the standard deviation of evaluation scores."""

    stddev: Optional[float] = None
    """Sample standard deviation of evaluation scores.

    Null when fewer than 2 evaluations exist.
    """


class TaskMonitoring(BaseModel):
    """Metrics for monitoring (production traffic) runs."""

    confidence: TaskMonitoringConfidence
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    evaluations: int
    """Total number of evaluations in this bucket."""

    health_score: Optional[float] = FieldInfo(alias="healthScore", default=None)
    """
    Overall health score (0-100) combining pass rate (60%), confidence (20%), and
    stability (20%). Null when confidence is LOW (unreliable measurement with >15pp
    margin of error). Green: 90-100, Yellow: 60-89, Red: 0-59.
    """

    passed: int
    """Number of evaluations that passed in this bucket."""

    pass_rate: Optional[float] = FieldInfo(alias="passRate", default=None)
    """Pass rate as a percentage (0-100). Null when no evaluations exist."""

    recommended_additional_evaluations: int = FieldInfo(alias="recommendedAdditionalEvaluations")
    """Number of additional evaluations recommended to reach High confidence."""

    stability: TaskMonitoringStability
    """Score stability based on the standard deviation of evaluation scores."""


class TaskSyntheticConfidenceInterval(BaseModel):
    lower: float
    """Lower bound of the 95% confidence interval (0-100)."""

    upper: float
    """Upper bound of the 95% confidence interval (0-100)."""


class TaskSyntheticConfidence(BaseModel):
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    half_width: float = FieldInfo(alias="halfWidth")
    """
    Half-width of the 95% confidence interval around the pass rate (percentage
    points).
    """

    interval: TaskSyntheticConfidenceInterval

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """
    Statistical confidence level based on the width of the 95% confidence interval
    around the pass rate.
    """


class TaskSyntheticStability(BaseModel):
    """Score stability based on the standard deviation of evaluation scores."""

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """Score stability level based on the standard deviation of evaluation scores."""

    stddev: Optional[float] = None
    """Sample standard deviation of evaluation scores.

    Null when fewer than 2 evaluations exist.
    """


class TaskSynthetic(BaseModel):
    """Metrics for synthetic (controlled test) runs."""

    confidence: TaskSyntheticConfidence
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    evaluations: int
    """Total number of evaluations in this bucket."""

    health_score: Optional[float] = FieldInfo(alias="healthScore", default=None)
    """
    Overall health score (0-100) combining pass rate (60%), confidence (20%), and
    stability (20%). Null when confidence is LOW (unreliable measurement with >15pp
    margin of error). Green: 90-100, Yellow: 60-89, Red: 0-59.
    """

    passed: int
    """Number of evaluations that passed in this bucket."""

    pass_rate: Optional[float] = FieldInfo(alias="passRate", default=None)
    """Pass rate as a percentage (0-100). Null when no evaluations exist."""

    recommended_additional_evaluations: int = FieldInfo(alias="recommendedAdditionalEvaluations")
    """Number of additional evaluations recommended to reach High confidence."""

    stability: TaskSyntheticStability
    """Score stability based on the standard deviation of evaluation scores."""


class TaskBreakdownMonitoringMetricsConfidenceInterval(BaseModel):
    lower: float
    """Lower bound of the 95% confidence interval (0-100)."""

    upper: float
    """Upper bound of the 95% confidence interval (0-100)."""


class TaskBreakdownMonitoringMetricsConfidence(BaseModel):
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    half_width: float = FieldInfo(alias="halfWidth")
    """
    Half-width of the 95% confidence interval around the pass rate (percentage
    points).
    """

    interval: TaskBreakdownMonitoringMetricsConfidenceInterval

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """
    Statistical confidence level based on the width of the 95% confidence interval
    around the pass rate.
    """


class TaskBreakdownMonitoringMetricsStability(BaseModel):
    """Score stability based on the standard deviation of evaluation scores."""

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """Score stability level based on the standard deviation of evaluation scores."""

    stddev: Optional[float] = None
    """Sample standard deviation of evaluation scores.

    Null when fewer than 2 evaluations exist.
    """


class TaskBreakdownMonitoringMetrics(BaseModel):
    """
    Aggregated evaluation metrics for a single run-type bucket (synthetic, monitoring, or combined).
    """

    confidence: TaskBreakdownMonitoringMetricsConfidence
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    evaluations: int
    """Total number of evaluations in this bucket."""

    health_score: Optional[float] = FieldInfo(alias="healthScore", default=None)
    """
    Overall health score (0-100) combining pass rate (60%), confidence (20%), and
    stability (20%). Null when confidence is LOW (unreliable measurement with >15pp
    margin of error). Green: 90-100, Yellow: 60-89, Red: 0-59.
    """

    passed: int
    """Number of evaluations that passed in this bucket."""

    pass_rate: Optional[float] = FieldInfo(alias="passRate", default=None)
    """Pass rate as a percentage (0-100). Null when no evaluations exist."""

    recommended_additional_evaluations: int = FieldInfo(alias="recommendedAdditionalEvaluations")
    """Number of additional evaluations recommended to reach High confidence."""

    stability: TaskBreakdownMonitoringMetricsStability
    """Score stability based on the standard deviation of evaluation scores."""


class TaskBreakdownMonitoring(BaseModel):
    """
    Evaluation metrics broken down by a single eval definition within a run-type bucket.
    """

    eval_definition_id: str = FieldInfo(alias="evalDefinitionId")
    """ID of the eval definition."""

    eval_definition_name: str = FieldInfo(alias="evalDefinitionName")
    """Display name of the eval definition."""

    metrics: TaskBreakdownMonitoringMetrics
    """
    Aggregated evaluation metrics for a single run-type bucket (synthetic,
    monitoring, or combined).
    """


class TaskBreakdownSyntheticMetricsConfidenceInterval(BaseModel):
    lower: float
    """Lower bound of the 95% confidence interval (0-100)."""

    upper: float
    """Upper bound of the 95% confidence interval (0-100)."""


class TaskBreakdownSyntheticMetricsConfidence(BaseModel):
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    half_width: float = FieldInfo(alias="halfWidth")
    """
    Half-width of the 95% confidence interval around the pass rate (percentage
    points).
    """

    interval: TaskBreakdownSyntheticMetricsConfidenceInterval

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """
    Statistical confidence level based on the width of the 95% confidence interval
    around the pass rate.
    """


class TaskBreakdownSyntheticMetricsStability(BaseModel):
    """Score stability based on the standard deviation of evaluation scores."""

    level: Literal["HIGH", "MEDIUM", "LOW"]
    """Score stability level based on the standard deviation of evaluation scores."""

    stddev: Optional[float] = None
    """Sample standard deviation of evaluation scores.

    Null when fewer than 2 evaluations exist.
    """


class TaskBreakdownSyntheticMetrics(BaseModel):
    """
    Aggregated evaluation metrics for a single run-type bucket (synthetic, monitoring, or combined).
    """

    confidence: TaskBreakdownSyntheticMetricsConfidence
    """Statistical confidence in the pass rate based on a Wilson 95% interval."""

    evaluations: int
    """Total number of evaluations in this bucket."""

    health_score: Optional[float] = FieldInfo(alias="healthScore", default=None)
    """
    Overall health score (0-100) combining pass rate (60%), confidence (20%), and
    stability (20%). Null when confidence is LOW (unreliable measurement with >15pp
    margin of error). Green: 90-100, Yellow: 60-89, Red: 0-59.
    """

    passed: int
    """Number of evaluations that passed in this bucket."""

    pass_rate: Optional[float] = FieldInfo(alias="passRate", default=None)
    """Pass rate as a percentage (0-100). Null when no evaluations exist."""

    recommended_additional_evaluations: int = FieldInfo(alias="recommendedAdditionalEvaluations")
    """Number of additional evaluations recommended to reach High confidence."""

    stability: TaskBreakdownSyntheticMetricsStability
    """Score stability based on the standard deviation of evaluation scores."""


class TaskBreakdownSynthetic(BaseModel):
    """
    Evaluation metrics broken down by a single eval definition within a run-type bucket.
    """

    eval_definition_id: str = FieldInfo(alias="evalDefinitionId")
    """ID of the eval definition."""

    eval_definition_name: str = FieldInfo(alias="evalDefinitionName")
    """Display name of the eval definition."""

    metrics: TaskBreakdownSyntheticMetrics
    """
    Aggregated evaluation metrics for a single run-type bucket (synthetic,
    monitoring, or combined).
    """


class TaskBreakdown(BaseModel):
    """Per-eval-definition breakdown by run-type bucket.

    Present on detail endpoint only.
    """

    monitoring: List[TaskBreakdownMonitoring]
    """Per-eval-definition breakdown for monitoring (production traffic) runs."""

    synthetic: List[TaskBreakdownSynthetic]
    """Per-eval-definition breakdown for synthetic (controlled test) runs."""


class TaskTaskSchedule(BaseModel):
    """Task schedule schema"""

    application_id: str = FieldInfo(alias="applicationId")

    criticality: Literal["LOW", "MEDIUM", "HIGH"]

    cron: str

    task_id: str = FieldInfo(alias="taskId")

    last_run_at: Optional[datetime] = FieldInfo(alias="lastRunAt", default=None)

    next_run_at: Optional[datetime] = FieldInfo(alias="nextRunAt", default=None)


class Task(BaseModel):
    id: str
    """The unique identifier of the task"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the task was created"""

    description: str
    """The task description"""

    eval_definitions: List[TaskEvalDefinition] = FieldInfo(alias="evalDefinitions")

    input_examples: List[str] = FieldInfo(alias="inputExamples")
    """Example inputs for the task"""

    is_verified: bool = FieldInfo(alias="isVerified")
    """Whether the task has been verified"""

    metadata: Dict[str, object]
    """Optional metadata associated with the task.

    Returns null when no metadata is stored.
    """

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the task was last modified"""

    monitoring: TaskMonitoring
    """Metrics for monitoring (production traffic) runs."""

    monitoring_pass_rate: Optional[float] = FieldInfo(alias="monitoringPassRate", default=None)
    """Deprecated: use monitoring.passRate instead.

    The 30 day pass rate for monitoring runs only, measured in percentage. Null when
    no monitoring runs exist.
    """

    pass_rate: Optional[float] = FieldInfo(alias="passRate", default=None)
    """Deprecated: use synthetic.passRate instead.

    The 30 day pass rate for the task measured in percentage (excludes monitoring
    runs). Null when no tests have been run.
    """

    status: Literal["DEDUCED", "DRAFT", "ACTIVE", "ARCHIVED"]
    """The status of the task.

    DEDUCED tasks are created from unmatched traces, DRAFT tasks are user-facing
    drafts, and ACTIVE tasks are production tasks.
    """

    synthetic: TaskSynthetic
    """Metrics for synthetic (controlled test) runs."""

    title: str
    """The title of the task"""

    type: Literal["STATIC", "NORMAL"]
    """The type of task.

    Normal tasks have a dynamic user prompt, while adversarial tasks have a fixed
    user prompt.
    """

    breakdown: Optional[TaskBreakdown] = None
    """Per-eval-definition breakdown by run-type bucket.

    Present on detail endpoint only.
    """

    last_test: Optional[datetime] = FieldInfo(alias="lastTest", default=None)
    """The date and time this task was last tested"""

    parent_id: Optional[str] = FieldInfo(alias="parentId", default=None)
    """The ID of the parent task (for DEDUCED tasks linked to a DRAFT)"""

    simulated_prompt_schema: Optional[Dict[str, object]] = FieldInfo(alias="simulatedPromptSchema", default=None)
    """
    JSON schema that defines the structure for user prompts that should be generated
    for tests
    """

    task_schedule: Optional[TaskTaskSchedule] = FieldInfo(alias="taskSchedule", default=None)
    """Task schedule schema"""

    topic_id: Optional[str] = FieldInfo(alias="topicId", default=None)
    """The ID of the topic this task belongs to"""

    trace_id: Optional[str] = FieldInfo(alias="traceId", default=None)
    """The ID of the trace this task was deduced from (only for DEDUCED tasks)"""


class TaskRetrieveResponse(BaseModel):
    """Successful response containing the task data with metrics"""

    task: Task
