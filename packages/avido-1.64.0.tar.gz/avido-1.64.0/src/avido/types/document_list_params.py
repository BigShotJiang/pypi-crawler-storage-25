# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List, Union
from datetime import datetime
from typing_extensions import Literal, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["DocumentListParams"]


class DocumentListParams(TypedDict, total=False):
    assignee: str
    """Filter by assignee user ID"""

    end_date: Annotated[Union[str, datetime], PropertyInfo(alias="endDate", format="iso8601")]
    """Filter documents created before this date (inclusive)."""

    limit: int
    """Number of items to include in the result set."""

    metadata_step: Annotated[str, PropertyInfo(alias="metadataStep")]
    """Filter documents whose active version metadata contains this step value."""

    order_by: Annotated[Literal["createdAt", "modifiedAt", "type", "assignee", "id"], PropertyInfo(alias="orderBy")]
    """Field to order the result set by."""

    order_dir: Annotated[Literal["asc", "desc"], PropertyInfo(alias="orderDir")]
    """Order direction."""

    quickstart_id: Annotated[str, PropertyInfo(alias="quickstartId")]
    """Filter documents linked to a specific quickstart."""

    scrape_job_id: Annotated[SequenceNotStr[str], PropertyInfo(alias="scrapeJobId")]
    """Filter by scrape job ID. Supports multiple values."""

    search: str
    """Search in document version title and content"""

    skip: int
    """Number of items to skip before starting to collect the result set."""

    start_date: Annotated[Union[str, datetime], PropertyInfo(alias="startDate", format="iso8601")]
    """Filter documents created after this date (inclusive)."""

    status: List[Literal["DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "ACTIVE"]]
    """
    Filter by document version status (filters documents by their active version
    status). Supports multiple values.
    """

    tag_id: Annotated[SequenceNotStr[str], PropertyInfo(alias="tagId")]
    """Filter documents by tag ID"""

    topic_id: Annotated[str, PropertyInfo(alias="topicId")]
    """Filter documents by topic ID"""

    type: Literal["KNOWLEDGE", "POLICY"]
    """Filter by document type. Defaults to KNOWLEDGE if not specified."""
