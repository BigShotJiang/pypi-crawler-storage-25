# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["ApplicationListParams"]


class ApplicationListParams(TypedDict, total=False):
    environment: Literal["DEV", "PROD"]
    """Filter by application environment"""

    human_annotation_enabled: Annotated[bool, PropertyInfo(alias="humanAnnotationEnabled")]
    """Filter by human annotation enabled status"""

    limit: int
    """Number of items to include in the result set."""

    order_by: Annotated[
        Literal["createdAt", "modifiedAt", "title", "slug", "type", "environment", "id"], PropertyInfo(alias="orderBy")
    ]
    """Field to order the result set by."""

    order_dir: Annotated[Literal["asc", "desc"], PropertyInfo(alias="orderDir")]
    """Order direction."""

    skip: int
    """Number of items to skip before starting to collect the result set."""

    slug: str
    """Filter by application slug"""

    type: Literal["CHATBOT", "AGENT"]
    """Filter by application type"""
