# Contributing

Thanks for your interest. The easiest and most valuable contribution is **adding a
new journal profile**. That's what this guide focuses on; code contributions follow
standard Python project conventions.

## Adding a journal profile

A journal profile is a YAML file describing the journal's submission requirements.
The pipeline reads it declaratively — no code changes are needed to add a journal.

### 1. Copy an existing profile

Start from [`src/manuscript_formatter/journals/journal-of-urology.yaml`](src/manuscript_formatter/journals/journal-of-urology.yaml)
and rename to `<journal-slug>.yaml` (lowercase, hyphenated).

### 2. Fill in the rules

Every field is documented inline. The main sections are:

- `reference_style` — a [CSL](https://citationstyles.org) style name. Find the
  official style in the [Zotero CSL repo](https://github.com/citation-style-language/styles).
- `abstract` — structured vs unstructured, required sections, word limit.
- `main_text` — word limit, required sections, section aliases (e.g., "Materials
  and Methods" → "Methods").
- `title_page` — required fields and whether it's a separate file.
- `cover_letter` — required statements (novelty, non-duplicate submission, etc.).
- `figures` / `tables` — counts and accepted formats.
- `disclosures` — form type (e.g., ICMJE).

**Always cite the source.** Include a comment at the top of the YAML with a link
to the journal's author guidelines and the date checked. Journal rules change.

### 3. Add a golden test

Under `tests/golden/<journal-slug>/`, add:

- `input.docx` — a synthetic manuscript that exercises the profile's rules
- `expected/main.docx` — what the pipeline should produce
- `expected/title_page.docx`, `expected/cover_letter.docx`, `expected/checklist.md`

CI runs the pipeline against every profile and diffs against these goldens. If
your profile changes output, the diff makes it visible for review.

### 4. Open a PR

Title: `Add <Journal Name> profile`. In the body, include a link to the journal's
author guidelines. A maintainer will review.

## Code contributions

```bash
git clone https://github.com/sortacat-company/manuscript-formatter
cd manuscript-formatter
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest
ruff check .
```

- Python 3.11+.
- `ruff` for lint/format, `mypy --strict` for typing, `pytest` for tests.
- Keep LLM calls out of deterministic transform modules.
- Never silently rewrite scientific claims; unresolved ambiguity goes into the
  checklist.

## Reporting bugs

Include the journal profile, a minimal manuscript that reproduces the issue, and
the diff between expected and actual output.
