"""Generate a minimal sample manuscript as .docx for smoke-testing.

Run from repo root:
    python tests/fixtures/make_sample_docx.py
"""

from __future__ import annotations

from pathlib import Path

from docx import Document


def build() -> Path:
    doc = Document()

    doc.add_heading("A Prospective Study of Widget Efficacy in Adult Urology Patients", level=0)

    doc.add_heading("Abstract", level=1)
    doc.add_paragraph(
        "We studied 100 patients and found that widgets are associated with "
        "reduced operative time. Conclusions are preliminary."
    )

    doc.add_heading("Introduction", level=1)
    doc.add_paragraph("Widgets are widely used but their efficacy is debated.")

    doc.add_heading("Materials and Methods", level=1)
    doc.add_paragraph("This was a single-center prospective cohort study...")

    doc.add_heading("Results", level=1)
    doc.add_paragraph("Operative time was reduced by 12 minutes on average (p<0.05).")

    doc.add_heading("Discussion", level=1)
    doc.add_paragraph("Our findings are consistent with prior literature.")

    doc.add_heading("Conclusions", level=1)
    doc.add_paragraph("Widgets may reduce operative time; further study is needed.")

    doc.add_heading("References", level=1)
    doc.add_paragraph("1. Smith J, et al. Widget efficacy. J Urol 2020;204:123-130.")
    doc.add_paragraph("2. Jones A. A history of widgets. BJU Int 2019;123:45-52.")

    out_path = Path(__file__).parent / "sample_manuscript.docx"
    doc.save(out_path)
    return out_path


if __name__ == "__main__":
    p = build()
    print(f"wrote {p}")
