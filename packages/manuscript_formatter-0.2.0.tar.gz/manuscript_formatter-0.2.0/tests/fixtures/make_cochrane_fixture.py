"""Generate a synthetic .docx mimicking a Cochrane systematic review abstract.

The abstract text is transcribed from a real Cochrane review
(Ergun et al, 'Low-intensity shockwave therapy for erectile dysfunction',
Cochrane Database of Systematic Reviews 2025, Issue 7, CD013166.pub3) to
serve as a realistic test fixture for the Cochrane -> journal abstract
restructuring use case.

The fixture exercises three things the restructurer must handle:
    - 11 structured abstract sections (far more than any target journal)
    - Nested sub-outcomes inside 'Synthesis of results'
    - ~700-word total length (target journals want 250-300)

Run from repo root:
    python tests/fixtures/make_cochrane_fixture.py
"""

from __future__ import annotations

from pathlib import Path

from docx import Document

SECTIONS: list[tuple[str, str]] = [
    (
        "Rationale",
        "Low-intensity shockwave therapy (LiSWT) is a new way of treating erectile "
        "dysfunction using sound waves to help improve blood flow to the penis. No "
        "existing systematic reviews comparing LiSWT to placebo or other therapies "
        "for treating erectile dysfunction have used rigorous Cochrane methodology. "
        "Many existing studies appear to be of poor methodological quality, and "
        "several trials are ongoing, reflecting an evolving evidence base. Therefore, "
        "it is unclear whether LiSWT truly helps men who have erectile dysfunction. "
        "Furthermore, there is very limited focus on patient-important outcomes in "
        "the existing systematic reviews. In this comprehensive Cochrane review, we "
        "compared LiSWT to sham therapy to evaluate its efficacy and safety.",
    ),
    (
        "Objectives",
        "To evaluate the benefits and harms of low-intensity shockwave therapy for "
        "erectile dysfunction in men compared to sham treatment.",
    ),
    (
        "Search methods",
        "We performed a comprehensive search of the Cochrane Library, MEDLINE, "
        "Embase, Scopus, and two trial registries up to 7 July 2024. We applied no "
        "restrictions on publication status or language.",
    ),
    (
        "Eligibility criteria",
        "We included randomized controlled trials (RCTs) that compared LiSWT to "
        "either sham or no treatment. We excluded trials involving people with prior "
        "kidney transplants or who had surgical procedures to remove the prostate "
        "gland (i.e. radical prostatectomy).",
    ),
    (
        "Outcomes",
        "Critical outcomes were erectile function, discontinuation from treatment, "
        "and treatment-related adverse events; important outcomes were "
        "patient/partner satisfaction, penile rigidity, and quality of sexual life. "
        "We assessed all outcomes in the short term (<= 3 months) and long term "
        "(> 3 months).",
    ),
    (
        "Risk of bias",
        "We assessed the risk of bias using Cochrane's risk of bias assessment tool "
        "(RoB1).",
    ),
    (
        "Synthesis methods",
        "We performed statistical analyses following Cochrane Handbook of Systematic "
        "Reviews of Interventions guidance. We synthesized results for each outcome "
        "using meta-analysis using a random-effects model. We used GRADE to assess "
        "the certainty of evidence.",
    ),
    (
        "Included studies",
        "We focused on RCTs that applied LiSWT treatment utilizing electrohydraulic, "
        "electromagnetic, or piezoelectric energy. We included 21 RCTs, including "
        "1357 randomized participants (men aged 39 to 65 years old with erectile "
        "dysfunction between 3 and 68 months); 16 were published in full text, and "
        "the rest as abstract proceedings. The baseline International Index of "
        "Erectile Function-Erectile Function domain (IIEF-EF) scores of participants "
        "in these studies ranged from seven to 20. Based on this scale, most men had "
        "mild-to-moderate (12 to 16) and mild (17 to 21) erectile dysfunction.",
    ),
    (
        "Synthesis of results",
        "We included 21 RCTs that randomized 1357 participants. The certainty of the "
        "evidence for reported outcomes was low, mostly due to inconsistency, "
        "imprecision, and study limitations.\n\n"
        "Erectile function. Based on the IIEF-EF scale (6 to 30; higher score "
        "indicates higher erectile function; minimal clinically important difference "
        "(MCID): 4 point change), LiSWT, compared to sham treatment, may have a "
        "small effect on erectile function in the short term (mean difference (MD) "
        "3.89 points higher, 95% confidence interval (CI) 2.89 higher to 4.89 "
        "higher; I2 = 62%; 15 studies, 937 participants; low-certainty evidence). "
        "However, based on the selected MCID, this small effect may not be "
        "clinically important. In the long term, it may improve erectile function "
        "(MD 5.25 points higher, 95% CI 2.47 higher to 8.04 higher; I2 = 87%; 5 "
        "studies, 276 participants; low-certainty evidence).\n\n"
        "Discontinuation from treatment. LiSWT, compared to sham treatment, may have "
        "little to no effect on discontinuation from treatment in the short term "
        "(RR 0.77, 95% CI 0.47 to 1.27 higher; I2 = 0%; 17 studies, 1132 "
        "participants; low-certainty evidence). This corresponds to 15 fewer (34 "
        "fewer to 17 more) discontinuations from treatment with the use of LiSWT "
        "per 1000 patients. There were no studies with an active treatment period "
        "longer than three months; therefore, we found no eligible data on this "
        "outcome in the long term.\n\n"
        "Treatment-related adverse events. LiSWT, compared to sham treatment, may "
        "have little to no effect on treatment-related adverse events in the short "
        "term (risk difference (RD) 0.00, 95% CI -0.01 to 0.02; I2 = 0%; 20 studies, "
        "1400 participants; low-certainty evidence). Long term, it may also have "
        "little to no effect on treatment-related adverse events (RD 0.00, 95% CI "
        "-0.02 to 0.02; I2 = 0%; 6 studies, 411 participants; low-certainty "
        "evidence).\n\n"
        "Patient/partner satisfaction. We found no evidence on patient or partner "
        "satisfaction in either the short or long term.\n\n"
        "Penile rigidity. Based on the Erectile Hardness Scale (EHS) (1 to 4; "
        "higher score indicates higher penile rigidity; MCID: 1 point change), "
        "LiSWT compared to sham treatment may improve penile rigidity in the short "
        "term (MD 1.06 points higher, 95% CI 0.83 higher to 1.28 higher; I2 = 53%; "
        "4 studies, 252 participants; low-certainty evidence). In the long term, it "
        "may have a small improving effect on penile rigidity (MD 0.91 points "
        "higher, 95% CI 0.36 higher to 1.46 higher; I2 = 89%; 3 studies, 169 "
        "participants; low-certainty evidence). However, based on the selected "
        "MCID, this small effect may not be clinically important.\n\n"
        "Sexual quality of life. We found no evidence on sexual quality of life in "
        "either the short or long term.",
    ),
    (
        "Authors' conclusions",
        "LiSWT may have a small effect on erectile function in the short term, "
        "although it may not be perceived to be clinically important by men with "
        "erectile dysfunction. It may improve erectile function in the long term. "
        "There may be little to no difference in treatment discontinuations in the "
        "short term. Since all eligible trials applied a treatment duration of "
        "three months or less, we found no data to compare treatment "
        "discontinuations in the long term. LiSWT may have little to no effect on "
        "treatment-related adverse events in the short or long term, and may "
        "improve penile rigidity in the short term. In the long term, LiSWT may "
        "have a small improving effect on penile rigidity that may not be "
        "clinically important. We found no evidence on patient/partner "
        "satisfaction or sexual quality of life, either short or long term. The "
        "certainty of evidence was low for all outcomes due to shortcomings in the "
        "methodology of the included studies. Several studies were industry-funded, "
        "mainly by device makers.",
    ),
    (
        "Funding",
        "This Cochrane review had no dedicated funding.",
    ),
    (
        "Registration",
        "Protocol (2023): doi.org/10.1002/14651858.CD013166.pub2.",
    ),
]


def _bold(doc: Document, text: str) -> None:
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = True


def build() -> Path:
    doc = Document()

    # Preamble
    doc.add_paragraph(
        "Low-intensity shockwave therapy for erectile dysfunction: a systematic review"
    )
    doc.add_paragraph(
        "Author A, Author B, Author C, Author D, Author E, Author F, Author G, and Author H"
    )
    doc.add_paragraph("Keywords: erectile dysfunction; shockwave therapy; systematic review")

    # Abstract with Cochrane-style section structure
    _bold(doc, "Abstract")
    for heading, text in SECTIONS:
        _bold(doc, heading)
        for paragraph in text.split("\n\n"):
            doc.add_paragraph(paragraph)

    # Minimal body so the manuscript is structurally complete for ingest
    _bold(doc, "Introduction")
    doc.add_paragraph(
        "[Body intentionally abbreviated in this fixture; the Cochrane-to-journal "
        "translation pain point is concentrated in the abstract.]"
    )
    _bold(doc, "Methods")
    doc.add_paragraph("See Cochrane Handbook.")
    _bold(doc, "Results")
    doc.add_paragraph("See abstract.")
    _bold(doc, "Discussion")
    doc.add_paragraph("See abstract.")
    _bold(doc, "Conclusion")
    doc.add_paragraph("See authors' conclusions above.")

    out_path = Path(__file__).parent / "cochrane_sample.docx"
    doc.save(out_path)
    return out_path


if __name__ == "__main__":
    p = build()
    print(f"wrote {p}")
