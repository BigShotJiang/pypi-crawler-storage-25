from __future__ import annotations

from pathlib import Path

import pytest
from docx import Document  # type: ignore[import-untyped]

from manuscript_formatter.manuscript import (
    Abstract,
    Author,
    Manuscript,
    Reference,
    Section,
)
from manuscript_formatter.output import (
    write_cover_letter,
    write_disclosures_placeholder,
    write_main_docx,
    write_title_page,
)
from manuscript_formatter.profile import load_profile


@pytest.fixture
def manuscript() -> Manuscript:
    return Manuscript(
        title="Widget Efficacy in Adult Urology",
        short_title="Widgets in Urology",
        authors=[Author(name="Jane Doe", corresponding=True, email="jd@example.com")],
        abstract=Abstract(
            structured=True,
            sections={
                "Purpose": "Evaluate widgets.",
                "Materials and Methods": "Cohort of 100.",
                "Results": "Time reduced.",
                "Conclusions": "Promising.",
            },
        ),
        keywords=["urology", "widgets"],
        body_sections=[
            Section("Introduction", ["Widgets matter."]),
            Section("Methods", ["We did a study."]),
            Section("Results", ["Found a thing."]),
            Section("Discussion", ["Interesting."]),
            Section("Conclusions", ["Good."]),
        ],
        references=[Reference(raw="Smith J. Widgets. J Urol 2020;204:123.")],
        figures=[],
        tables=[],
    )


def test_write_main_docx(manuscript: Manuscript, tmp_path: Path) -> None:
    profile = load_profile("journal-of-urology")
    out = write_main_docx(manuscript, profile, tmp_path / "main.docx")
    assert out.exists() and out.stat().st_size > 0

    doc = Document(str(out))
    headings = [p.text for p in doc.paragraphs if p.style.name.startswith("Heading")]
    assert "Abstract" in headings
    assert "Introduction" in headings
    assert "References" in headings


def test_write_title_page(manuscript: Manuscript, tmp_path: Path) -> None:
    profile = load_profile("journal-of-urology")
    out = write_title_page(manuscript, profile, tmp_path / "title_page.docx")
    doc = Document(str(out))
    body = "\n".join(p.text for p in doc.paragraphs)
    assert "Widget Efficacy" in body
    assert "Jane Doe" in body


def test_write_cover_letter_includes_required_statements(
    manuscript: Manuscript, tmp_path: Path
) -> None:
    profile = load_profile("journal-of-urology")
    out = write_cover_letter(manuscript, profile, tmp_path / "cover_letter.docx")
    doc = Document(str(out))
    body = "\n".join(p.text for p in doc.paragraphs)
    assert "Journal of Urology" in body
    assert "not been published elsewhere" in body
    assert "all" in body.lower() and "authors" in body.lower()


def test_write_disclosures_placeholder(tmp_path: Path) -> None:
    profile = load_profile("journal-of-urology")
    out = write_disclosures_placeholder(profile, tmp_path / "disclosures.md")
    assert "ICMJE" in out.read_text()
