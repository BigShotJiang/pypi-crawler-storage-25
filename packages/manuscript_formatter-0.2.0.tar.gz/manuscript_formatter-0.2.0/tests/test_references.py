from __future__ import annotations

from pathlib import Path

import pytest

from manuscript_formatter.manuscript import (
    Abstract,
    Manuscript,
    Reference,
)
from manuscript_formatter.profile import load_profile
from manuscript_formatter.transforms.deterministic.references import (
    reformat_bibliography,
    reformat_references,
)

BIBTEX_FIXTURE = """@article{smith2020widget,
  title={Widget efficacy in adult urology},
  author={Smith, John and Doe, Jane},
  journal={Journal of Urology},
  volume={204},
  pages={123--130},
  year={2020}
}
@article{jones2019history,
  title={A history of widgets},
  author={Jones, Alice},
  journal={BJU International},
  volume={123},
  pages={45--52},
  year={2019}
}
"""


@pytest.fixture
def bib_file(tmp_path: Path) -> Path:
    p = tmp_path / "refs.bib"
    p.write_text(BIBTEX_FIXTURE)
    return p


def _blank_manuscript() -> Manuscript:
    return Manuscript(
        title="t",
        short_title=None,
        authors=[],
        abstract=Abstract(structured=False, text=""),
        keywords=[],
        body_sections=[],
        references=[Reference(raw="old 1"), Reference(raw="old 2")],
        figures=[],
        tables=[],
    )


@pytest.mark.network
def test_reformat_bibliography_ama(bib_file: Path) -> None:
    entries = reformat_bibliography(bib_file, "american-medical-association")
    assert len(entries) == 2
    combined = "\n".join(entries)
    assert "Smith" in combined
    assert "Jones" in combined


@pytest.mark.network
def test_reformat_references_replaces_raw_when_bib_supplied(bib_file: Path) -> None:
    profile = load_profile("journal-of-urology")
    m = reformat_references(_blank_manuscript(), profile, bib_path=bib_file)
    assert len(m.references) == 2
    assert all("old" not in r.raw for r in m.references)


def test_reformat_references_no_bib_is_noop() -> None:
    profile = load_profile("journal-of-urology")
    m = reformat_references(_blank_manuscript(), profile, bib_path=None)
    assert [r.raw for r in m.references] == ["old 1", "old 2"]
