"""Tests for the LLM-assisted raw→CSL-JSON reference parser.

The Anthropic client is stubbed so these tests don't touch the network or
require an API key; see tests/test_references.py for the
network-backed tests of the Pandoc+CSL rendering path.
"""

from __future__ import annotations

import json
from types import SimpleNamespace

import pytest
from anthropic.types import TextBlock

from manuscript_formatter.transforms.llm.references import (
    estimate_cost,
    parse_raw_references_to_csl_json,
)


class _StubClient:
    """Minimal stand-in for the Anthropic client's .messages.create() call.

    Uses a real ``TextBlock`` for the response content so that
    ``isinstance(b, TextBlock)`` narrows correctly in the parser.
    """

    def __init__(self, response_text: str):
        self._response_text = response_text
        self.last_call: dict | None = None
        self.messages = SimpleNamespace(create=self._create)

    def _create(self, **kwargs: object) -> object:
        self.last_call = kwargs
        return SimpleNamespace(
            content=[TextBlock(type="text", text=self._response_text, citations=None)]
        )


SAMPLE_REFS = [
    "1. Dickersin K. To reform U.S. health care, start with systematic reviews. Science, 311: 1399, 2006.",
    "2. Jones A, Smith J. Widgets in urology. J Urol 2020;204:123-130.",
]


def test_parse_raw_references_to_csl_json_happy_path() -> None:
    client = _StubClient(
        json.dumps(
            [
                {
                    "id": "ref1",
                    "type": "article-journal",
                    "author": [{"family": "Dickersin", "given": "K."}],
                    "title": "To reform U.S. health care, start with systematic reviews",
                    "container-title": "Science",
                    "volume": "311",
                    "page": "1399",
                    "issued": {"date-parts": [[2006]]},
                },
                {
                    "id": "ref2",
                    "type": "article-journal",
                    "author": [
                        {"family": "Jones", "given": "A"},
                        {"family": "Smith", "given": "J"},
                    ],
                    "title": "Widgets in urology",
                    "container-title": "Journal of Urology",
                    "volume": "204",
                    "page": "123-130",
                    "issued": {"date-parts": [[2020]]},
                },
            ]
        )
    )

    records = parse_raw_references_to_csl_json(SAMPLE_REFS, client=client)  # type: ignore[arg-type]
    assert len(records) == 2
    assert records[0]["id"] == "ref1"
    assert records[1]["author"][1]["family"] == "Smith"
    assert records[1]["issued"] == {"date-parts": [[2020]]}


def test_parse_fills_missing_id_and_type() -> None:
    client = _StubClient(
        json.dumps(
            [
                {"title": "A", "author": [{"family": "A", "given": ""}]},
                {"title": "B", "author": [{"family": "B", "given": ""}]},
            ]
        )
    )
    records = parse_raw_references_to_csl_json(SAMPLE_REFS, client=client)  # type: ignore[arg-type]
    assert records[0]["id"] == "ref1"
    assert records[1]["id"] == "ref2"
    assert all(r["type"] == "article-journal" for r in records)


def test_parse_tolerates_markdown_fenced_output() -> None:
    client = _StubClient(
        "```json\n"
        + json.dumps(
            [
                {"id": "ref1", "type": "article-journal", "title": "A"},
                {"id": "ref2", "type": "article-journal", "title": "B"},
            ]
        )
        + "\n```"
    )
    records = parse_raw_references_to_csl_json(SAMPLE_REFS, client=client)  # type: ignore[arg-type]
    assert len(records) == 2


def test_parse_raises_on_length_mismatch() -> None:
    client = _StubClient(json.dumps([{"id": "ref1", "type": "article-journal", "title": "A"}]))
    with pytest.raises(ValueError, match="Expected 2 CSL-JSON records"):
        parse_raw_references_to_csl_json(SAMPLE_REFS, client=client)  # type: ignore[arg-type]


def test_parse_raises_on_non_array_output() -> None:
    client = _StubClient('{"id": "ref1"}')
    with pytest.raises(ValueError, match="Expected a JSON array"):
        parse_raw_references_to_csl_json(SAMPLE_REFS, client=client)  # type: ignore[arg-type]


def test_empty_input_short_circuits_without_api_call() -> None:
    records = parse_raw_references_to_csl_json([])
    assert records == []


def test_cost_estimate_scales_with_inputs() -> None:
    small = estimate_cost(["one short ref"])
    large = estimate_cost(["one short ref"] * 50)
    assert large.total_usd > small.total_usd
    assert large.output_tokens > small.output_tokens


@pytest.mark.network
def test_csl_json_rendered_end_to_end_via_pandoc() -> None:
    """Full round-trip: stub Claude → reformat_from_csl_json → formatted string."""
    from manuscript_formatter.transforms.deterministic.references import (
        reformat_from_csl_json,
    )

    records = [
        {
            "id": "ref1",
            "type": "article-journal",
            "author": [{"family": "Jones", "given": "A"}],
            "title": "Widgets in urology",
            "container-title": "Journal of Urology",
            "volume": "204",
            "page": "123-130",
            "issued": {"date-parts": [[2020]]},
        }
    ]
    rendered = reformat_from_csl_json(records, "american-medical-association")
    assert len(rendered) == 1
    assert "Jones" in rendered[0]
    assert "Widgets" in rendered[0]
    assert "2020" in rendered[0]
