"""Tests for the LLM abstract restructurer.

The Anthropic client is stubbed so these tests don't hit the network or
require an API key. The Cochrane fixture is used to exercise the realistic
12-section input that the restructurer must handle.
"""

from __future__ import annotations

import json
from types import SimpleNamespace

import pytest
from anthropic.types import TextBlock

from manuscript_formatter.manuscript import Abstract
from manuscript_formatter.profile import load_profile
from manuscript_formatter.transforms.llm.abstract import (
    estimate_cost,
    render_side_by_side_diff,
    restructure_abstract,
)


class _StubClient:
    def __init__(self, response_text: str):
        self._response_text = response_text
        self.last_call: dict | None = None
        self.messages = SimpleNamespace(create=self._create)

    def _create(self, **kwargs: object) -> object:
        self.last_call = kwargs
        return SimpleNamespace(
            content=[TextBlock(type="text", text=self._response_text, citations=None)]
        )


def _bjui_profile():
    return load_profile("bjui")


def _response(restructured, mapping=None, dropped=None, warnings=None):
    return json.dumps(
        {
            "restructured": restructured,
            "mapping": mapping or {},
            "dropped": dropped or {},
            "warnings": warnings or [],
        }
    )


SAMPLE_STRUCTURED_ABSTRACT = Abstract(
    structured=True,
    sections={
        "Rationale": "The rationale for studying widgets in urology.",
        "Objectives": "To assess widget efficacy.",
        "Methods": "Prospective cohort of 100.",
        "Results": "Widgets reduced operative time by 12 minutes.",
        "Conclusions": "Widgets work.",
    },
)


def test_restructure_happy_path_fills_target_sections() -> None:
    profile = _bjui_profile()  # 4 target sections: Objectives / Subjects and Methods / Results / Conclusion

    client = _StubClient(
        _response(
            restructured={
                "Objectives": "To assess widget efficacy.",
                "Subjects and Methods": "Prospective cohort of 100.",
                "Results": "Widgets reduced operative time by 12 minutes.",
                "Conclusion": "Widgets work.",
            },
            mapping={
                "Objectives": ["Rationale", "Objectives"],
                "Subjects and Methods": ["Methods"],
                "Results": ["Results"],
                "Conclusion": ["Conclusions"],
            },
            dropped={},
            warnings=[],
        )
    )
    new_abstract, report = restructure_abstract(
        SAMPLE_STRUCTURED_ABSTRACT, profile, client=client  # type: ignore[arg-type]
    )
    assert new_abstract.structured is True
    assert set(new_abstract.sections.keys()) == set(profile.abstract.sections)
    assert report.source_word_count > 0
    assert report.actual_word_count > 0
    assert report.warnings == []
    assert report.mapping["Subjects and Methods"] == ["Methods"]


def test_missing_target_section_gets_placeholder_and_warning() -> None:
    profile = _bjui_profile()

    # Stub only populates 3 of the 4 target sections
    client = _StubClient(
        _response(
            restructured={
                "Objectives": "To assess.",
                "Subjects and Methods": "Methods.",
                "Results": "Results.",
                # Conclusion deliberately missing
            }
        )
    )
    new_abstract, report = restructure_abstract(
        SAMPLE_STRUCTURED_ABSTRACT, profile, client=client  # type: ignore[arg-type]
    )
    assert "Conclusion" in new_abstract.sections
    assert new_abstract.sections["Conclusion"].startswith("[TBD:")
    assert any("Conclusion" in w for w in report.warnings)


def test_malformed_response_raises() -> None:
    profile = _bjui_profile()
    client = _StubClient("not valid json at all")
    with pytest.raises(json.JSONDecodeError):
        restructure_abstract(
            SAMPLE_STRUCTURED_ABSTRACT, profile, client=client  # type: ignore[arg-type]
        )


def test_tolerates_fenced_json_output() -> None:
    profile = _bjui_profile()
    payload = _response(
        restructured={
            "Objectives": "a",
            "Subjects and Methods": "b",
            "Results": "c",
            "Conclusion": "d",
        }
    )
    client = _StubClient(f"```json\n{payload}\n```")
    new_abstract, _ = restructure_abstract(
        SAMPLE_STRUCTURED_ABSTRACT, profile, client=client  # type: ignore[arg-type]
    )
    assert new_abstract.sections["Objectives"] == "a"


def test_unstructured_target_profile_refused() -> None:
    """If a profile says abstract is unstructured, we can't restructure into it."""
    profile = _bjui_profile()
    # Force structured=False for the test
    profile.abstract.structured = False
    with pytest.raises(ValueError, match="unstructured"):
        restructure_abstract(
            SAMPLE_STRUCTURED_ABSTRACT, profile, client=_StubClient("{}")  # type: ignore[arg-type]
        )


def test_cost_estimate_scales_with_input() -> None:
    profile = _bjui_profile()
    short = Abstract(structured=True, sections={"S": "a" * 10})
    long = Abstract(structured=True, sections={"S": "a" * 5000})
    assert estimate_cost(long, profile).total_usd > estimate_cost(short, profile).total_usd


def test_side_by_side_diff_includes_both_sides() -> None:
    profile = _bjui_profile()
    client = _StubClient(
        _response(
            restructured={
                "Objectives": "O.",
                "Subjects and Methods": "M.",
                "Results": "R.",
                "Conclusion": "C.",
            }
        )
    )
    _, report = restructure_abstract(
        SAMPLE_STRUCTURED_ABSTRACT, profile, client=client  # type: ignore[arg-type]
    )
    md = render_side_by_side_diff(SAMPLE_STRUCTURED_ABSTRACT, report)
    # Both original section names and target section names appear
    assert "### Rationale" in md
    assert "### Conclusion" in md
    assert "Source" in md and "Restructured" in md


def test_end_to_end_on_cochrane_fixture_structure() -> None:
    """Structural test: feed the Cochrane fixture's 12-section abstract to the
    restructurer (stubbed) targeting BJUI. Verify the API call payload has
    the 12 source sections and 4 target sections, and the returned Abstract
    has exactly the 4 target sections.
    """
    from manuscript_formatter.ingest import ingest_docx

    m = ingest_docx("tests/fixtures/cochrane_sample.docx")
    assert len(m.abstract.sections) == 12  # sanity: Cochrane structure

    profile = _bjui_profile()
    client = _StubClient(
        _response(
            restructured={
                "Objectives": "Compressed objective.",
                "Subjects and Methods": "Compressed methods.",
                "Results": "Compressed results with 95% CI 2.89 to 4.89.",
                "Conclusion": "Compressed conclusion.",
            },
            mapping={
                "Objectives": ["Rationale", "Objectives"],
                "Subjects and Methods": [
                    "Search methods",
                    "Eligibility criteria",
                    "Outcomes",
                    "Risk of bias",
                    "Synthesis methods",
                    "Included studies",
                ],
                "Results": ["Synthesis of results"],
                "Conclusion": ["Authors' conclusions"],
            },
            dropped={
                "Funding": "metadata not required by BJUI abstract",
                "Registration": "metadata not required by BJUI abstract",
            },
        )
    )
    new_abstract, report = restructure_abstract(
        m.abstract, profile, client=client  # type: ignore[arg-type]
    )
    assert set(new_abstract.sections.keys()) == set(profile.abstract.sections)
    # Verify the stub received the structured Cochrane sections
    assert client.last_call is not None
    sent = json.loads(client.last_call["messages"][0]["content"])
    assert len(sent["source_sections"]) == 12
    assert sent["target_sections"] == profile.abstract.sections
    assert sent["target_word_limit"] == profile.abstract.word_limit
    assert report.compression_ratio < 1.0  # compressed
    assert "Funding" in report.dropped
