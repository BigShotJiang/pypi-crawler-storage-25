"""Tests for .docx ingest, covering the clinical-manuscript style where all
paragraphs share the ``Normal`` style and section headings are marked by bold
text rather than by Word's Heading styles.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from docx import Document  # type: ignore[import-untyped]
from docx.oxml import OxmlElement  # type: ignore[import-untyped]
from docx.oxml.ns import qn  # type: ignore[import-untyped]

from manuscript_formatter.ingest import ingest_docx


def _bold(doc: Document, text: str) -> None:
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = True


def _italic(doc: Document, text: str) -> None:
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.italic = True


def _register_endnote_bibliography_style(doc: Document) -> None:
    """Register a paragraph style named 'EndNote Bibliography' at the docx level.

    python-docx's style registry doesn't include EndNote's style by default,
    so we add a minimal custom paragraph style under the same name the real
    EndNote plugin uses.
    """
    styles_el = doc.styles.element
    style_el = OxmlElement("w:style")
    style_el.set(qn("w:type"), "paragraph")
    style_el.set(qn("w:styleId"), "EndNoteBibliography")
    name_el = OxmlElement("w:name")
    name_el.set(qn("w:val"), "EndNote Bibliography")
    style_el.append(name_el)
    styles_el.append(style_el)


@pytest.fixture
def bold_heading_docx(tmp_path: Path) -> Path:
    """Build a .docx that mimics the formatting used by many clinical
    manuscripts: no Heading styles, bold section names inline, structured
    abstract whose subsections overlap with the body's section names, and
    references tagged with the EndNote Bibliography paragraph style.
    """
    doc = Document()
    _register_endnote_bibliography_style(doc)

    # Preamble
    doc.add_paragraph("A Study of Widgets in Adult Urology")
    doc.add_paragraph("Jane Doe, John Smith, and Alice Jones")
    doc.add_paragraph("Keywords: widgets; urology; cohort")

    # Structured abstract (subsections named the same as body sections)
    _bold(doc, "Abstract")
    _bold(doc, "Introduction")
    doc.add_paragraph("We investigated widgets.")
    _bold(doc, "Methods")
    doc.add_paragraph("Prospective cohort.")
    _bold(doc, "Results")
    doc.add_paragraph("Widgets were fast.")
    _bold(doc, "Conclusions")
    doc.add_paragraph("Widgets work.")

    # Body — repeats the names used as abstract subsections, which is the
    # signal ingest uses to close the abstract.
    _bold(doc, "Introduction")
    doc.add_paragraph("Widgets are important.")
    doc.add_paragraph("Prior work is limited.")

    _bold(doc, "Methods")
    doc.add_paragraph("Study design details.")

    _bold(doc, "Results")
    doc.add_paragraph("A result paragraph.")

    _bold(doc, "Discussion")
    doc.add_paragraph("Interpretation of findings.")

    _bold(doc, "Conclusion")
    doc.add_paragraph("Widgets are promising.")

    # References — EndNote-styled paragraphs without a preceding heading
    for ref_text in (
        "1. Smith J. Widgets. J Urol 2020;204:123.",
        "2. Jones A. More widgets. BJU Int 2019;123:45.",
    ):
        p = doc.add_paragraph(ref_text)
        p.style = doc.styles["EndNote Bibliography"]

    out = tmp_path / "bold_headings.docx"
    doc.save(out)
    return out


def test_bold_heading_ingest_extracts_structure(bold_heading_docx: Path) -> None:
    m = ingest_docx(bold_heading_docx)

    assert m.title == "A Study of Widgets in Adult Urology"
    assert [a.name for a in m.authors] == ["Jane Doe", "John Smith", "Alice Jones"]
    assert m.keywords == ["widgets", "urology", "cohort"]

    assert m.abstract.structured is True
    assert set(m.abstract.sections.keys()) == {
        "Introduction",
        "Methods",
        "Results",
        "Conclusions",
    }
    assert "investigated widgets" in m.abstract.sections["Introduction"]

    body_headings = [s.heading for s in m.body_sections]
    assert body_headings == [
        "Introduction",
        "Methods",
        "Results",
        "Discussion",
        "Conclusion",
    ]

    assert len(m.references) == 2
    assert "Smith" in m.references[0].raw
    assert "Jones" in m.references[1].raw


def test_italic_subheadings_nest_under_body_sections(tmp_path: Path) -> None:
    """Clinical manuscripts commonly mark Discussion subheadings with italic
    (not bold) Normal paragraphs. These should nest under the enclosing body
    section as Heading-2-level subsections, not break out as new sections.
    """
    doc = Document()
    doc.add_paragraph("A Paper")
    _bold(doc, "Abstract")
    doc.add_paragraph("Short summary.")

    _bold(doc, "Introduction")
    doc.add_paragraph("Intro paragraph.")

    _bold(doc, "Discussion")
    doc.add_paragraph("Opening discussion paragraph.")
    _italic(doc, "Statement of Principal Findings")
    doc.add_paragraph("The main finding was X.")
    doc.add_paragraph("Supporting evidence.")
    _italic(doc, "Strengths and Limitations")
    doc.add_paragraph("A limitation is Y.")
    _italic(doc, "Implications for Practice")
    doc.add_paragraph("Practitioners should Z.")

    _bold(doc, "Conclusion")
    doc.add_paragraph("Final thought.")

    out = tmp_path / "italic_sub.docx"
    doc.save(out)

    m = ingest_docx(out)
    headings = [s.heading for s in m.body_sections]
    assert headings == ["Introduction", "Discussion", "Conclusion"]

    discussion = m.body_sections[1]
    assert discussion.paragraphs == ["Opening discussion paragraph."]
    sub_headings = [s.heading for s in discussion.subsections]
    assert sub_headings == [
        "Statement of Principal Findings",
        "Strengths and Limitations",
        "Implications for Practice",
    ]
    # Word count includes lede + all subsection paragraphs
    assert discussion.word_count == sum(
        len(p.split())
        for p in [
            "Opening discussion paragraph.",
            "The main finding was X.",
            "Supporting evidence.",
            "A limitation is Y.",
            "Practitioners should Z.",
        ]
    )
    assert discussion.subsections[0].paragraphs == [
        "The main finding was X.",
        "Supporting evidence.",
    ]


def test_ingest_still_handles_word_heading_styles(tmp_path: Path) -> None:
    """The original Heading-style path must keep working."""
    doc = Document()
    doc.add_heading("Widgets for Urology", level=0)
    doc.add_heading("Abstract", level=1)
    doc.add_paragraph("An unstructured abstract.")
    doc.add_heading("Introduction", level=1)
    doc.add_paragraph("Intro text.")
    doc.add_heading("References", level=1)
    doc.add_paragraph("1. Smith J. Widgets. J Urol 2020;204:123.")
    out = tmp_path / "heading_styles.docx"
    doc.save(out)

    m = ingest_docx(out)
    assert m.title == "Widgets for Urology"
    assert m.abstract.text.strip() == "An unstructured abstract."
    assert [s.heading for s in m.body_sections] == ["Introduction"]
    assert len(m.references) == 1
