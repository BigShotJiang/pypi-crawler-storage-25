import pytest

from manuscript_formatter.profile import load_profile

ALL_PROFILES = [
    "journal-of-urology",
    "bjui",
    "journal-of-endourology",
    "european-urology",
]


@pytest.mark.parametrize("slug", ALL_PROFILES)
def test_profile_loads(slug: str) -> None:
    profile = load_profile(slug)
    assert profile.slug == slug
    assert profile.name
    assert profile.reference_style
    assert profile.abstract.word_limit > 0
    assert profile.main_text.word_limit > 0
    assert profile.main_text.required_sections


def test_journal_of_urology_specifics() -> None:
    profile = load_profile("journal-of-urology")
    assert profile.abstract.structured is True
    assert "Purpose" in profile.abstract.sections
    # PDF author guidelines: 3,000 words / 30 references for Original Articles
    assert profile.main_text.word_limit == 3000
    assert profile.references.max == 30
    assert profile.figures.max == 10
    # JU's canonical body heading is "Materials and Methods" (not "Methods");
    # aliases collapse shorter variants to the full form.
    assert profile.main_text.section_aliases["Methods"] == "Materials and Methods"
    assert "Materials and Methods" in profile.main_text.required_sections
    assert profile.reference_style == "american-medical-association"


def test_european_urology_has_patient_summary_and_caps() -> None:
    profile = load_profile("european-urology")
    assert profile.patient_summary is not None
    assert profile.patient_summary.required is True
    assert profile.patient_summary.word_limit == 40
    assert profile.references.max == 40
    assert profile.figures.combined_with_tables_max == 5


def test_section_rules_reorder_and_alias() -> None:
    from manuscript_formatter.manuscript import Abstract, Manuscript, Section
    from manuscript_formatter.transforms.deterministic import apply_section_rules

    profile = load_profile("journal-of-urology")
    m = Manuscript(
        title="t",
        short_title=None,
        authors=[],
        abstract=Abstract(structured=False, text=""),
        keywords=[],
        body_sections=[
            Section("Discussion", ["d"]),
            Section("Materials and Methods", ["m"]),
            Section("Introduction", ["i"]),
            Section("Results", ["r"]),
            Section("Conclusions", ["c"]),
            Section("Appendix", ["a"]),
        ],
        references=[],
        figures=[],
        tables=[],
    )
    m = apply_section_rules(m, profile)
    headings = [s.heading for s in m.body_sections]
    # "Methods" and "Materials and Methods" both collapse to JU's canonical
    # "Materials and Methods" form; Conclusion → Conclusions; required order
    # is Introduction → Materials and Methods → Results → Discussion →
    # Conclusions; trailing sections keep original order.
    assert headings == [
        "Introduction",
        "Materials and Methods",
        "Results",
        "Discussion",
        "Conclusions",
        "Appendix",
    ]
