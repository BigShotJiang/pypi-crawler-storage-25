# Releasing

`manuscript-formatter` is published to PyPI via GitHub Actions using
[PyPI trusted publishing](https://docs.pypi.org/trusted-publishers/). No
long-lived API tokens are stored anywhere; the workflow authenticates to
PyPI over OIDC at release time.

## One-time setup (done once per project)

1. **Create a PyPI account** at https://pypi.org/account/register/ and verify
   the email. 2FA is required for anyone who publishes.
2. **Register a pending trusted publisher** at
   https://pypi.org/manage/account/publishing/ → *Add a new pending publisher*.
   Fill in exactly:
   - PyPI Project Name: `manuscript-formatter`
   - Owner: `sortacat-company`
   - Repository name: `manuscript-formatter`
   - Workflow name: `release.yml`
   - Environment name: `pypi`
3. **Create the `pypi` GitHub environment** on the repo at
   *Settings → Environments → New environment*. Name it `pypi`.
   - Optional but recommended: restrict to the `main` branch and tag pushes.

After the first successful release, the "pending" publisher becomes a
regular trusted publisher and requires no further setup.

## Cutting a release

1. Bump `version` in [`pyproject.toml`](../pyproject.toml).
2. Commit on `main`: `git commit -am "Release v0.X.Y"` and push.
3. Tag: `git tag v0.X.Y && git push origin v0.X.Y`.
4. The [`Release to PyPI`](../.github/workflows/release.yml) workflow runs:
   tests → build → publish → GitHub release.
5. Within a few minutes, the new version is live at
   https://pypi.org/project/manuscript-formatter/ and installable with
   `pip install manuscript-formatter`.

If the workflow fails, fix the issue, bump to the next patch version, and
retag. PyPI never allows reusing a version number, even for deleted releases.

## Versioning

We follow [semver](https://semver.org/). While the tool is pre-1.0:

- `0.X.0` bumps for new features or profile additions
- `0.X.Y` patches for bug fixes
- Breaking changes are allowed in any `0.X.0` bump

Moving to `1.0.0` signals the CLI interface and profile schema are stable
enough that downstream users can rely on them across releases.
