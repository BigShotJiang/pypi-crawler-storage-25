# manuscript-formatter

Reformat medical manuscripts to journal-specific submission requirements.

Manuscript submission to peer-reviewed journals is painful because every journal has
its own rules: reference style, abstract structure, word limits, section ordering,
title page layout, cover letter requirements, and disclosure forms. Authors spend
hours massaging a single manuscript into each journal's shape, often for multiple
journals before acceptance.

`manuscript-formatter` takes a manuscript and a target journal profile, and produces
a submission-ready package: a reformatted main document, title page, cover letter,
disclosure form, and a pre-submission checklist flagging anything that still needs
human review.

## Status

Early alpha. The first journal profile in development is **Journal of Urology**.
Additional urology journals (BJUI, Journal of Endourology, European Urology) are
planned. See [issues](https://github.com/sortacat-company/manuscript-formatter/issues)
for what's next.

## Scope

**In scope**

- `.docx` and `.pdf` manuscript ingest
- Reference reformatting (via Pandoc + CSL — thousands of styles already exist)
- Section reordering and renaming per journal profile
- Abstract restructuring and word-limit trimming (LLM-assisted)
- Title page and cover letter generation
- Pre-submission checklist
- Urology journals first; extensible to any specialty

**Out of scope**

- Automated submission to journal systems (ScholarOne, Editorial Manager, etc.)
- Layout-preserving PDF → Word conversion
- Rewriting scientific claims (LLM edits are confined to structure, phrasing, and
  length; anything ambiguous is flagged for human review)

## Quickstart

> Not yet functional — skeleton only. Check back after v0.1.

```bash
# Install
pip install manuscript-formatter

# System deps
brew install pandoc    # macOS
# apt-get install pandoc    # Debian/Ubuntu

# Run
manuscript-format path/to/manuscript.docx \
    --journal journal-of-urology \
    --out ./submission/
```

The output directory will contain:

- `main.docx` — reformatted main manuscript
- `title_page.docx` — separate title page
- `cover_letter.docx` — draft cover letter
- `disclosures.md` — ICMJE disclosure placeholder
- `checklist.md` — what passed, what failed, what needs human review

## Architecture

```
manuscript-formatter/
├── src/manuscript_formatter/
│   ├── journals/                # YAML profile per journal (community-contributable)
│   ├── ingest/                  # .docx and .pdf → structured Manuscript object
│   ├── profile/                 # Load/validate journal YAML profiles
│   ├── transforms/
│   │   ├── deterministic/       # Rule-based: sections, references, counts
│   │   └── llm/                 # LLM-assisted: abstract, trim, cover letter
│   ├── output/                  # Emit .docx, title page, cover letter, checklist
│   ├── checklist/               # Pre-submission validation
│   └── cli.py
├── tests/
│   ├── fixtures/                # Synthetic manuscripts
│   └── golden/                  # Input → expected output per journal
└── docs/
```

### Design principles

- **Deterministic first, LLM second.** Reference conversion, section renaming, word
  counting — all rule-based. Reserve LLM calls for genuinely fuzzy tasks.
- **Never silently rewrite claims.** LLM edits are confined to structure, phrasing,
  and length. Ambiguous content goes into the checklist, not a silent edit.
- **Prompt caching** on the journal profile to keep per-run costs low.
- **Golden-file tests per journal** so profile changes can't silently regress output.

## Adding a new journal

See [CONTRIBUTING.md](CONTRIBUTING.md). In short: copy an existing YAML profile in
[`src/manuscript_formatter/journals/`](src/manuscript_formatter/journals/), fill
in the target journal's rules, add a synthetic manuscript + expected output
under `tests/golden/<journal>/`, and open a PR.

## License

MIT. See [LICENSE](LICENSE).
