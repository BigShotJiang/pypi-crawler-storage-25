"""Internal representation of a manuscript, independent of input format."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Author:
    name: str
    affiliations: list[str] = field(default_factory=list)
    corresponding: bool = False
    email: str | None = None
    orcid: str | None = None


@dataclass
class Subsection:
    heading: str
    paragraphs: list[str]

    @property
    def word_count(self) -> int:
        return sum(len(p.split()) for p in self.paragraphs)


@dataclass
class Section:
    heading: str
    paragraphs: list[str]
    # Paragraphs that appear AFTER a Heading-2-like subheading inside this
    # section live in ``subsections``. Paragraphs that appear *before* the
    # first subheading stay in ``paragraphs`` (the section's lede).
    subsections: list[Subsection] = field(default_factory=list)

    @property
    def word_count(self) -> int:
        direct = sum(len(p.split()) for p in self.paragraphs)
        nested = sum(s.word_count for s in self.subsections)
        return direct + nested


@dataclass
class Abstract:
    structured: bool
    # When structured, maps section heading -> text (e.g., Purpose -> "...")
    sections: dict[str, str] = field(default_factory=dict)
    # When unstructured, the whole abstract as one block
    text: str = ""

    @property
    def word_count(self) -> int:
        if self.structured:
            return sum(len(v.split()) for v in self.sections.values())
        return len(self.text.split())


@dataclass
class Reference:
    """One bibliographic entry. Stored as raw text until a CSL pass parses it."""

    raw: str
    # Optional parsed fields — populated during ingest when recoverable
    authors: list[str] = field(default_factory=list)
    title: str | None = None
    journal: str | None = None
    year: int | None = None
    doi: str | None = None


@dataclass
class Figure:
    number: int
    caption: str
    file_path: str | None = None


@dataclass
class Table:
    number: int
    caption: str
    # Rows stored as plain strings for now; structured parsing is a later concern
    raw: str = ""


@dataclass
class Manuscript:
    title: str
    short_title: str | None
    authors: list[Author]
    abstract: Abstract
    keywords: list[str]
    body_sections: list[Section]
    references: list[Reference]
    figures: list[Figure]
    tables: list[Table]
    # Anything we couldn't confidently classify during ingest
    unclassified: list[str] = field(default_factory=list)

    @property
    def body_word_count(self) -> int:
        return sum(s.word_count for s in self.body_sections)
