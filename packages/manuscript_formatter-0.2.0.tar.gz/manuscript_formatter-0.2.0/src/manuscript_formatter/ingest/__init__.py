from manuscript_formatter.ingest.docx import ingest_docx

__all__ = ["ingest_docx"]
