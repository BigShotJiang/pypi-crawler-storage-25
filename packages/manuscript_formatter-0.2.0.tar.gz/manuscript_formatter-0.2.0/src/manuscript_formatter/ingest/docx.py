"""Parse a .docx manuscript into the internal Manuscript representation.

Heading detection uses three signals, in order:

1. Paragraph style — ``Heading 1``/``Heading 2`` etc. (the Word-idiomatic path).
2. Paragraph style that carries its own semantic meaning — e.g. EndNote's
   ``EndNote Bibliography`` style flags reference entries directly.
3. Visual/textual heuristics for ``Normal``-styled manuscripts (common in
   clinical writing): short, fully-bold paragraphs whose text matches a known
   section name, or an exact text match against that name list.

Structured abstracts are handled by scoping: once an ``Abstract`` heading is
seen, subsequent headings are treated as *subsections of the abstract* until
we see a second ``Introduction`` (or any body heading that comes after the
abstract has already accumulated subsections).

TODOs, tracked separately — author/affiliation parsing, figure/table caption
extraction, inline citation detection.
"""

from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.text.paragraph import Paragraph

from manuscript_formatter.manuscript import (
    Abstract,
    Author,
    Manuscript,
    Reference,
    Section,
    Subsection,
)

# Canonical section names we'll recognize as headings by text alone. Kept
# deliberately broad so we can detect structure in manuscripts authored for
# any common journal style; journal-specific canonicalization happens later
# in apply_section_rules.
KNOWN_SECTIONS = {
    "abstract",
    "summary",
    "background",
    "introduction",
    "purpose",
    "objective",
    "objectives",
    "aim",
    "aims",
    "methods",
    "materials and methods",
    "material and methods",
    "patients and methods",
    "subjects and methods",
    "methodology",
    "study design",
    "design",
    "results",
    "findings",
    "key findings and limitations",
    "discussion",
    "limitations",
    "conclusion",
    "conclusions",
    "conclusions and clinical implications",
    "acknowledgments",
    "acknowledgements",
    "funding",
    "disclosures",
    "conflict of interest",
    "conflicts of interest",
    "author contributions",
    "references",
    "bibliography",
    "literature cited",
    "patient summary",
}

REFERENCE_HEADINGS = {"references", "bibliography", "literature cited"}
ABSTRACT_HEADINGS = {"abstract", "summary"}
BIBLIOGRAPHY_STYLES = ("bibliography",)  # matched via substring, case-insensitive

# Canonical IMRaD body section names. Unqualified (no "Search methods", no
# "Authors' conclusions") — those qualified forms signal abstract subsections.
# When a heading in this set appears while we're inside an abstract and the
# name has NOT already been used as an abstract subsection, it marks the
# transition to the body. Catches Cochrane-style abstracts (12+ distinctive
# subsection names, then a plain 'Introduction' starts the body) while still
# letting the existing duplicate-name rule handle IMRaD-shaped structured
# abstracts (where the body's 'Introduction' matches the abstract's).
IMRAD_BODY_HEADINGS = {
    "introduction",
    "background",
    "methods",
    "materials and methods",
    "results",
    "discussion",
    "conclusion",
    "conclusions",
}


def _paragraph_is_fully_bold(p: Paragraph) -> bool:
    runs = [r for r in p.runs if r.text.strip()]
    if not runs:
        return False
    return all(r.bold for r in runs)


def _paragraph_is_fully_italic(p: Paragraph) -> bool:
    runs = [r for r in p.runs if r.text.strip()]
    if not runs:
        return False
    return all(r.italic for r in runs)


def _looks_like_subheading(p: Paragraph) -> bool:
    """A Heading-2-style cue: italic, short, capitalized, no trailing punctuation.

    Clinical manuscripts commonly mark Discussion subheadings
    (``Statement of Principal Findings``, ``Strengths and Limitations``, etc.)
    as italic Normal paragraphs rather than using a Heading 2 style.
    """
    text = p.text.strip()
    if not text:
        return False
    if not _paragraph_is_fully_italic(p):
        return False
    if _paragraph_is_fully_bold(p):
        # Bold-italic is treated as a main heading by _looks_like_heading
        return False
    if len(text.split()) > 12:
        return False
    if not text[0].isupper():
        return False
    return not text.endswith((".", "!", "?", ",", ":", ";"))


def _style_is_heading(style_name: str) -> bool:
    return style_name.lower().startswith("heading")


def _style_is_bibliography(style_name: str) -> bool:
    s = style_name.lower()
    return any(token in s for token in BIBLIOGRAPHY_STYLES)


def _looks_like_heading(p: Paragraph) -> bool:
    text = p.text.strip()
    if not text:
        return False
    # Word's native heading styles
    if _style_is_heading(p.style.name if p.style else ""):
        return True
    # Text-only match (bold or not) against the known-section list
    if text.lower() in KNOWN_SECTIONS and len(text.split()) <= 6:
        return True
    # Short + fully bold + starts with capital: likely a heading even if the
    # text isn't in the known-section list (handles journal-specific names).
    return (
        _paragraph_is_fully_bold(p)
        and len(text.split()) <= 8
        and text[0].isupper()
        and not text.endswith(".")
    )


def _parse_preamble(
    paragraphs: list[Paragraph],
) -> tuple[str, list[Author], list[str], int]:
    """Extract title, authors, keywords from the paragraphs before the first heading.

    Returns (title, authors, keywords, index_of_first_heading).
    """
    title = ""
    authors: list[Author] = []
    keywords: list[str] = []
    first_heading_idx = 0

    non_empty: list[tuple[int, Paragraph]] = [
        (i, p) for i, p in enumerate(paragraphs) if p.text.strip()
    ]

    for i, p in non_empty:
        if _looks_like_heading(p):
            first_heading_idx = i
            break
        text = p.text.strip()
        lower = text.lower()
        if not title:
            title = text
            continue
        if lower.startswith("keywords"):
            # "Keywords: a; b; c" or "Keywords: a, b, c"
            rest = text.split(":", 1)[-1]
            keywords = [
                kw.strip().rstrip(".;,") for kw in rest.replace(";", ",").split(",") if kw.strip()
            ]
            continue
        if not authors and ("," in text or " and " in text):
            # Heuristic: the authors line typically contains multiple names
            parts = [
                n.strip().rstrip(".")
                for n in text.replace(" and ", ",").split(",")
                if n.strip()
            ]
            # Filter out things that don't look like names (digits, long text)
            if all(
                len(part.split()) <= 6 and not any(ch.isdigit() for ch in part)
                for part in parts
            ):
                authors = [Author(name=name) for name in parts]
                continue

    return title, authors, keywords, first_heading_idx


def ingest_docx(path: str | Path) -> Manuscript:
    doc = Document(str(path))
    paragraphs = list(doc.paragraphs)

    title, authors, keywords, start_idx = _parse_preamble(paragraphs)

    abstract = Abstract(structured=False, text="")
    body_sections: list[Section] = []
    references: list[Reference] = []
    unclassified: list[str] = []

    # State machine: "preamble" -> "abstract" -> "body" -> "references".
    # Within "body", a pending Section is held open in current_body_section so
    # italic Heading-2 subheadings can nest paragraphs under it.
    state: str = "preamble"
    current_heading: str | None = None
    current_paragraphs: list[str] = []
    abstract_subsections: dict[str, str] = {}
    current_abstract_subsection: str | None = None
    current_body_section: Section | None = None
    current_subsection_heading: str | None = None

    def flush_current_paragraphs_to_body() -> None:
        nonlocal current_paragraphs, current_subsection_heading
        if not current_body_section:
            return
        chunks = [p for p in current_paragraphs if p.strip()]
        current_paragraphs = []
        if not chunks:
            current_subsection_heading = None
            return
        if current_subsection_heading is not None:
            current_body_section.subsections.append(
                Subsection(heading=current_subsection_heading, paragraphs=chunks)
            )
            current_subsection_heading = None
        else:
            current_body_section.paragraphs.extend(chunks)

    def flush_into_current_scope() -> None:
        nonlocal current_paragraphs, current_abstract_subsection, current_body_section
        joined_chunks = [p for p in current_paragraphs if p.strip()]
        if state == "body":
            flush_current_paragraphs_to_body()
            if current_body_section is not None:
                body_sections.append(current_body_section)
                current_body_section = None
            return

        joined = "\n\n".join(joined_chunks).strip()
        current_paragraphs = []
        if not joined and current_heading is None:
            return
        if state == "abstract":
            if current_abstract_subsection is not None:
                abstract_subsections[current_abstract_subsection] = joined
                current_abstract_subsection = None
            else:
                abstract.text = (abstract.text + "\n\n" + joined).strip() if abstract.text else joined
        elif state == "references":
            for line in joined_chunks:
                references.append(Reference(raw=line.strip()))
        else:
            if joined:
                unclassified.append(joined)

    for i, p in enumerate(paragraphs):
        if i < start_idx:
            continue
        text = p.text.strip()
        style_name = p.style.name if p.style else ""

        # EndNote Bibliography paragraphs always become references, no matter
        # where they appear — EndNote applies this style to each entry in
        # the bibliography list.
        if _style_is_bibliography(style_name) and text:
            if state != "references":
                flush_into_current_scope()
                state = "references"
                current_heading = "References"
            references.append(Reference(raw=text))
            continue

        # Italic subheadings nest inside the currently-open body section.
        # Only honored once we're in body state (Discussion subheadings etc.).
        if state == "body" and current_body_section is not None and _looks_like_subheading(p):
            flush_current_paragraphs_to_body()
            current_subsection_heading = text
            continue

        if _looks_like_heading(p):
            flush_into_current_scope()
            current_heading = text
            lower = text.lower()

            if state == "preamble" and lower in ABSTRACT_HEADINGS:
                state = "abstract"
                continue

            if state == "abstract":
                if lower in REFERENCE_HEADINGS:
                    state = "references"
                    continue
                # Unstructured abstract: once we've collected free-text content
                # under the Abstract heading, the next heading begins the body.
                if abstract.text:
                    state = "body"
                    current_body_section = Section(heading=text, paragraphs=[])
                    continue
                prev_subs_lower = {k.lower() for k in abstract_subsections}
                # Structured abstract with IMRaD-shaped subsections: body begins
                # when a repeated subsection name appears (e.g. body's
                # "Introduction" after the abstract's "Introduction").
                if abstract_subsections and lower in prev_subs_lower:
                    abstract.structured = True
                    abstract.sections = dict(abstract_subsections)
                    state = "body"
                    current_body_section = Section(heading=text, paragraphs=[])
                    continue
                # Cochrane-style abstract: distinctive subsection names (none
                # match IMRaD). When a plain IMRaD body heading appears, the
                # abstract is done. Only fires when the abstract's existing
                # subsections contain NO IMRaD names — otherwise the duplicate
                # rule above handles the transition correctly.
                abstract_uses_imrad_names = bool(prev_subs_lower & IMRAD_BODY_HEADINGS)
                if (
                    abstract_subsections
                    and not abstract_uses_imrad_names
                    and lower in IMRAD_BODY_HEADINGS
                ):
                    abstract.structured = True
                    abstract.sections = dict(abstract_subsections)
                    state = "body"
                    current_body_section = Section(heading=text, paragraphs=[])
                    continue
                # Otherwise treat the heading as a new abstract subsection.
                current_abstract_subsection = text
                continue

            if lower in REFERENCE_HEADINGS:
                state = "references"
                continue

            # Any heading outside abstract/references is a body heading.
            # Open a fresh Section so subsequent subheadings nest under it.
            state = "body"
            current_body_section = Section(heading=text, paragraphs=[])
            continue

        # Non-heading paragraph: accumulate text in current scope
        if text:
            current_paragraphs.append(text)

    # Finalize
    if state == "abstract" and abstract_subsections and not abstract.structured:
        abstract.structured = True
        abstract.sections = dict(abstract_subsections)
    if state == "body":
        flush_current_paragraphs_to_body()
        if current_body_section is not None:
            body_sections.append(current_body_section)
            current_body_section = None
    else:
        flush_into_current_scope()

    return Manuscript(
        title=title,
        short_title=None,
        authors=authors,
        abstract=abstract,
        keywords=keywords,
        body_sections=body_sections,
        references=references,
        figures=[],
        tables=[],
        unclassified=unclassified,
    )
