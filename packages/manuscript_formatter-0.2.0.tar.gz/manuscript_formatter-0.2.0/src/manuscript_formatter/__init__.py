"""Reformat medical manuscripts to journal-specific submission requirements."""

__version__ = "0.2.0"
