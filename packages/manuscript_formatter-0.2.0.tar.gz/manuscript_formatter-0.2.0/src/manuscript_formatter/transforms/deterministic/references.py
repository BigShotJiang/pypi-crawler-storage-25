"""Reformat references to a journal's CSL style using Pandoc's citeproc.

The v0.1 contract: we can only reformat references when the caller supplies a
**structured** bibliography (BibTeX, CSL-JSON, or RIS). Free-text reference
lists pulled from a .docx cannot be reliably parsed into citation data, so
those pass through untouched and the checklist flags them for the user.

Phase 2 will add an LLM-assisted step that parses raw reference strings into
CSL-JSON so this function can operate end-to-end without a separate .bib file.
"""

from __future__ import annotations

import json
import tempfile
import urllib.error
import urllib.request
from pathlib import Path

import pypandoc

from manuscript_formatter.manuscript import Manuscript, Reference
from manuscript_formatter.profile.schema import JournalProfile

ZOTERO_CSL_BASE = "https://raw.githubusercontent.com/citation-style-language/styles/master"


def _cache_dir() -> Path:
    path = Path.home() / ".cache" / "manuscript-formatter" / "styles"
    path.mkdir(parents=True, exist_ok=True)
    return path


def ensure_csl_style(style_name: str) -> Path:
    """Return a local path to the requested CSL file, downloading if absent.

    Style names match Zotero's CSL repository slugs. The Zotero repo stores
    "independent" styles at the root and "dependent" styles (which reuse
    another style's formatting) under ``dependent/``; both are tried.
    Examples: ``"american-medical-association"``, ``"mary-ann-liebert-vancouver"``,
    ``"european-urology"`` (found under ``dependent/``).
    """
    path = _cache_dir() / f"{style_name}.csl"
    if path.exists():
        return path

    tried: list[str] = []
    for candidate in (f"{style_name}.csl", f"dependent/{style_name}.csl"):
        url = f"{ZOTERO_CSL_BASE}/{candidate}"
        tried.append(url)
        try:
            with urllib.request.urlopen(url, timeout=15) as resp:
                path.write_bytes(resp.read())
            return path
        except urllib.error.HTTPError:
            continue

    raise FileNotFoundError(
        f"CSL style '{style_name}' not found in Zotero repo. Tried: {', '.join(tried)}. "
        "Check the slug against https://github.com/citation-style-language/styles."
    )


def reformat_bibliography(bib_path: Path, style_name: str) -> list[str]:
    """Render an entire structured bibliography in a CSL style.

    Uses Pandoc's ``nocite: '@*'`` trick to force every entry in the bibliography
    to be emitted, regardless of whether it was cited in-text. Returns one
    formatted reference per list entry, in the order Pandoc produces them.
    """
    style_path = ensure_csl_style(style_name)
    md_source = (
        "---\n"
        f"bibliography: {bib_path}\n"
        "nocite: '@*'\n"
        "---\n"
    )
    rendered = pypandoc.convert_text(
        md_source,
        "plain",
        format="markdown",
        extra_args=["--citeproc", "--csl", str(style_path), "--wrap=none"],
    )
    # Pandoc separates entries with blank lines
    entries = [chunk.strip() for chunk in rendered.strip().split("\n\n") if chunk.strip()]
    return entries


def reformat_from_csl_json(csl_json_records: list[dict], style_name: str) -> list[str]:
    """Render a list of CSL-JSON records in the target CSL style via Pandoc."""
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False, encoding="utf-8"
    ) as f:
        json.dump(csl_json_records, f)
        csl_json_path = Path(f.name)
    try:
        return reformat_bibliography(csl_json_path, style_name)
    finally:
        csl_json_path.unlink(missing_ok=True)


def reformat_references(
    manuscript: Manuscript,
    profile: JournalProfile,
    bib_path: Path | None = None,
    csl_json_records: list[dict] | None = None,
) -> Manuscript:
    """Reformat manuscript references to ``profile.reference_style``.

    Precedence:
    1. ``csl_json_records`` (e.g., from the LLM-assisted parser) — rendered
       via Pandoc using a temp CSL-JSON file.
    2. ``bib_path`` — any bibliography format Pandoc understands
       (.bib/.json/.ris/.yaml).
    3. Otherwise the raw references pass through unchanged and the checklist
       flags them as not reformatted.
    """
    if csl_json_records is not None:
        formatted = reformat_from_csl_json(csl_json_records, profile.reference_style)
        manuscript.references = [Reference(raw=text) for text in formatted]
        return manuscript
    if bib_path is not None:
        formatted = reformat_bibliography(bib_path, profile.reference_style)
        manuscript.references = [Reference(raw=text) for text in formatted]
        return manuscript
    return manuscript
