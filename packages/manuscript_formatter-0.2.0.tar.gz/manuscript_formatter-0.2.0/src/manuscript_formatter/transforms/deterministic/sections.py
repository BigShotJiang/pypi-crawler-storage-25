"""Rename and reorder manuscript sections to match a journal profile."""

from __future__ import annotations

from manuscript_formatter.manuscript import Manuscript, Section
from manuscript_formatter.profile.schema import JournalProfile


def apply_section_rules(manuscript: Manuscript, profile: JournalProfile) -> Manuscript:
    """Rename sections via aliases, then reorder to the profile's required order.

    Sections not listed in ``required_sections`` are appended after the required
    ones, in original order. Missing required sections are *not* fabricated —
    they become a checklist warning elsewhere in the pipeline.
    """
    aliases = profile.main_text.section_aliases
    renamed: list[Section] = []
    for section in manuscript.body_sections:
        canonical = aliases.get(section.heading, section.heading)
        renamed.append(
            Section(
                heading=canonical,
                paragraphs=list(section.paragraphs),
                subsections=list(section.subsections),
            )
        )

    required = profile.main_text.required_sections
    by_heading = {s.heading: s for s in renamed}

    ordered: list[Section] = []
    for heading in required:
        if heading in by_heading:
            ordered.append(by_heading.pop(heading))

    # Anything left over keeps its relative order but trails required sections
    leftovers = [s for s in renamed if s.heading in by_heading]
    ordered.extend(leftovers)

    manuscript.body_sections = ordered
    return manuscript
