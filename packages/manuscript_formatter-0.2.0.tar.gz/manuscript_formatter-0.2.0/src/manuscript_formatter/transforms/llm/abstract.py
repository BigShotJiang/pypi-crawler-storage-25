"""Restructure a manuscript's abstract to match a target journal's sections.

The deterministic pipeline (``apply_section_rules``) can alias and reorder
body sections using YAML-defined rules, but it cannot compress a 12-section,
700-word Cochrane-style abstract into a 4-section, 300-word BJUI abstract.
That requires semantic understanding of which sentences map to which target
sections and how to compress each without inventing findings.

This module asks Claude to do that mapping + compression, with strict rules:

- Preserve every numeric result (effect sizes, CIs, p-values, I², N,
  percentages) verbatim.
- Preserve claim direction. "may improve" stays "may improve"; "no evidence"
  stays "no evidence". No strengthening, no weakening.
- Compression comes from removing methodology detail, redundancy between
  sections, and search/eligibility content that doesn't belong in a
  non-Cochrane abstract.
- If a target section has no clear source content, emit a "[TBD: ...]"
  placeholder rather than fabricating.
- Output a structured report showing which source sections fed each target
  section, which sources were dropped, and any warnings — so authors can
  review before submitting.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass

from anthropic import Anthropic
from anthropic.types import TextBlock

from manuscript_formatter.manuscript import Abstract
from manuscript_formatter.profile.schema import JournalProfile

DEFAULT_MODEL = "claude-sonnet-4-6"

# Rough Sonnet 4.6 pricing. Update if the public rate card moves.
PRICE_PER_MTOK_INPUT_USD = 3.0
PRICE_PER_MTOK_OUTPUT_USD = 15.0

SYSTEM_PROMPT = """You restructure a scientific manuscript's abstract to match a target journal's \
required section structure and word limit, without inventing findings or \
altering scientific claims.

INPUT (in the user message): a JSON object with three fields —
- source_sections: ordered list of {name, text} pairs from the author's abstract
- target_sections: ordered list of section names the target journal requires
- target_word_limit: integer word cap

OUTPUT (your response): a JSON object only, no prose, no markdown fences.
Shape:
{
  "restructured": { "<target_section>": "<text>", ... },
  "mapping": { "<target_section>": ["<source_section>", ...], ... },
  "dropped": { "<source_section>": "<reason>", ... },
  "warnings": [ "<string>", ... ]
}

RULES (strict):

1. Preserve all numeric results verbatim — effect sizes, confidence
   intervals, p-values, I² values, participant counts, percentages,
   scale ranges, MCID thresholds. Do not round, reformat, or reinterpret.

2. Preserve claim direction. Hedged claims stay hedged. "may have a small
   effect" does not become "has an effect" or "has no effect." "No evidence
   on X" stays "no evidence on X" — do not replace with "insufficient data"
   unless the source said exactly that.

3. Compress by removing, not by rewording into false confidence:
   - Drop search-methodology detail not needed in a non-Cochrane target
     (database names, search dates, registry names — unless the target
     journal's Methods abstract section explicitly requires it).
   - Merge per-outcome subsections of 'Synthesis of results' or equivalent
     into the target 'Results' section, keeping every numeric estimate but
     trimming narrative.
   - Drop meta-metadata (Funding, Registration) unless the target requires it.
   - Remove redundancy between sections that restated each other.

4. Never invent participants, interventions, comparisons, outcomes, or
   certainty ratings not present in the source.

5. If a target section has no clear source content to populate it, emit:
   "[TBD: authors to add <brief description of what's missing>]"
   Do not leave the value empty.

6. Each target section's word count should roughly follow the target_word_limit
   apportioned by section importance (Objectives and Conclusion typically
   shortest, Methods and Results longest). Stay within the word limit overall.

7. For every target section, record in `mapping` the ordered list of source
   section names whose content contributed to it (verbatim names from
   source_sections). For every source section whose content was entirely
   omitted, record it in `dropped` with a brief reason ("Cochrane-specific
   metadata not required by target" or "content merged into Results", etc.).

8. Use `warnings` to surface anything that required a judgment call an
   author should review — e.g. "Source 'Outcomes' listed critical vs
   important outcomes; target abstract has no natural home for this
   distinction — collapsed into Methods."
"""


@dataclass
class AbstractRestructureReport:
    """Artifact alongside the restructured Abstract that authors review."""

    restructured: dict[str, str]
    mapping: dict[str, list[str]]
    dropped: dict[str, str]
    warnings: list[str]
    target_word_limit: int
    actual_word_count: int
    source_word_count: int

    @property
    def compression_ratio(self) -> float:
        if self.source_word_count == 0:
            return 1.0
        return self.actual_word_count / self.source_word_count

    def to_markdown(self, profile_name: str) -> str:
        icon = {"kept": "→", "dropped": "✗", "warn": "?"}
        lines = [
            f"# Abstract restructuring report — {profile_name}",
            "",
            f"Source abstract: {self.source_word_count} words",
            f"Restructured: {self.actual_word_count} words (target ≤ {self.target_word_limit})",
            f"Compression: {self.compression_ratio:.0%} retained",
            "",
            "## Section mapping",
            "",
        ]
        for target, sources in self.mapping.items():
            lines.append(f"**{target}** {icon['kept']} drew from: {', '.join(sources) or '[none — TBD placeholder]'}")
        if self.dropped:
            lines.extend(["", "## Source sections dropped", ""])
            for src, reason in self.dropped.items():
                lines.append(f"- {icon['dropped']} **{src}** — {reason}")
        if self.warnings:
            lines.extend(["", "## Warnings — please review", ""])
            for w in self.warnings:
                lines.append(f"- {icon['warn']} {w}")
        return "\n".join(lines) + "\n"


@dataclass
class CostEstimate:
    input_tokens: int
    output_tokens: int
    input_cost_usd: float
    output_cost_usd: float

    @property
    def total_usd(self) -> float:
        return self.input_cost_usd + self.output_cost_usd

    def format(self) -> str:
        return (
            f"~{self.input_tokens} input + ~{self.output_tokens} output tokens "
            f"= ~${self.total_usd:.3f} (Sonnet 4.6)"
        )


def estimate_cost(source: Abstract, profile: JournalProfile) -> CostEstimate:
    """Rough token estimate. Uses 4-chars-per-token heuristic."""
    source_chars = len(SYSTEM_PROMPT) + sum(
        len(k) + len(v) + 10 for k, v in source.sections.items()
    ) + len(source.text) + 200
    input_tokens = source_chars // 4
    # Output budget: target word limit x ~1.5 tokens/word + mapping/dropped/warnings overhead
    output_tokens = int(profile.abstract.word_limit * 1.5) + 600
    return CostEstimate(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        input_cost_usd=input_tokens / 1_000_000 * PRICE_PER_MTOK_INPUT_USD,
        output_cost_usd=output_tokens / 1_000_000 * PRICE_PER_MTOK_OUTPUT_USD,
    )


def _extract_json_object(text: str) -> dict:
    stripped = text.strip()
    fence = re.match(r"^```(?:json)?\s*(.*?)\s*```$", stripped, re.DOTALL)
    if fence:
        stripped = fence.group(1).strip()
    parsed = json.loads(stripped)
    if not isinstance(parsed, dict):
        raise ValueError(f"Expected a JSON object, got {type(parsed).__name__}")
    return parsed


def _source_as_pairs(source: Abstract) -> list[dict[str, str]]:
    if source.structured and source.sections:
        return [{"name": k, "text": v} for k, v in source.sections.items()]
    return [{"name": "Abstract", "text": source.text}]


def render_side_by_side_diff(
    source: Abstract, report: AbstractRestructureReport
) -> str:
    """Markdown doc showing source sections on the left, restructured on the right.

    Not a word-level diff (medical content doesn't read well that way) — a
    section-by-section view so an author can read both columns and verify the
    restructuring preserved every finding.
    """
    lines = [
        "# Abstract — source vs. restructured",
        "",
        f"Source: {report.source_word_count} words "
        f"across {len(source.sections) if source.structured else 1} section(s)",
        f"Restructured: {report.actual_word_count} words "
        f"across {len(report.restructured)} section(s) "
        f"(target ≤ {report.target_word_limit})",
        "",
        "## Source",
        "",
    ]
    if source.structured and source.sections:
        for name, text in source.sections.items():
            word_count = len(text.split())
            lines.append(f"### {name} ({word_count} words)")
            lines.append("")
            lines.append(text.strip())
            lines.append("")
    else:
        lines.append(source.text.strip())
        lines.append("")

    lines.extend(["## Restructured", ""])
    for name, text in report.restructured.items():
        word_count = len(text.split())
        lines.append(f"### {name} ({word_count} words)")
        lines.append("")
        lines.append(text.strip())
        lines.append("")

    return "\n".join(lines)


def restructure_abstract(
    source: Abstract,
    profile: JournalProfile,
    *,
    client: Anthropic | None = None,
    model: str = DEFAULT_MODEL,
) -> tuple[Abstract, AbstractRestructureReport]:
    """Restructure ``source`` to the profile's required abstract sections.

    Raises ``ValueError`` if the response is malformed. Raises
    ``RuntimeError`` if ANTHROPIC_API_KEY is missing when no client is
    supplied.
    """
    if not profile.abstract.structured:
        # Nothing to restructure against — target is unstructured
        raise ValueError(
            f"Profile '{profile.slug}' has an unstructured abstract; "
            "restructuring requires a target with defined sections."
        )

    if client is None:
        if not os.environ.get("ANTHROPIC_API_KEY"):
            raise RuntimeError(
                "ANTHROPIC_API_KEY is not set. Export it before using "
                "--restructure-abstract, or skip the flag to leave the "
                "abstract unchanged (the checklist will flag the mismatch)."
            )
        client = Anthropic()

    user_payload = {
        "source_sections": _source_as_pairs(source),
        "target_sections": profile.abstract.sections,
        "target_word_limit": profile.abstract.word_limit,
    }

    response = client.messages.create(
        model=model,
        max_tokens=4096,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": json.dumps(user_payload)}],
    )
    parts = [b.text for b in response.content if isinstance(b, TextBlock)]
    raw = "".join(parts)
    data = _extract_json_object(raw)

    restructured = data.get("restructured", {})
    if not isinstance(restructured, dict):
        raise ValueError("Response 'restructured' must be an object")
    mapping = data.get("mapping", {})
    dropped = data.get("dropped", {})
    warnings = data.get("warnings", [])

    # Ensure every target section is present (fill with placeholder if missing)
    for section_name in profile.abstract.sections:
        if section_name not in restructured:
            restructured[section_name] = (
                f"[TBD: authors to add {section_name} content — LLM did not produce this section]"
            )
            warnings = [
                *warnings,
                f"Target section '{section_name}' was not populated by the restructurer",
            ]

    new_abstract = Abstract(structured=True, sections=dict(restructured), text="")

    source_words = source.word_count
    actual_words = new_abstract.word_count
    report = AbstractRestructureReport(
        restructured=dict(restructured),
        mapping={k: list(v) for k, v in mapping.items()} if isinstance(mapping, dict) else {},
        dropped=dict(dropped) if isinstance(dropped, dict) else {},
        warnings=list(warnings),
        target_word_limit=profile.abstract.word_limit,
        actual_word_count=actual_words,
        source_word_count=source_words,
    )
    return new_abstract, report
