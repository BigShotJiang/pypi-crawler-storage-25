"""Parse raw reference strings into CSL-JSON using Claude.

The deterministic reference pipeline (see
``transforms.deterministic.references``) can only reformat references when a
structured bibliography is supplied. Most manuscripts arrive with references
as free-text strings pulled from a .docx. This module bridges the gap: it
sends the raw strings to Claude and asks for validated CSL-JSON that the
downstream Pandoc+citeproc step can consume.

Design principles:
- Never fabricate data. The prompt explicitly forbids inventing fields and
  provides a graceful-degradation path for entries Claude can't parse.
- Preserve input order and count. Callers align the Claude output with the
  manuscript's original reference list by index.
- Fail closed. If Claude returns malformed JSON or a length mismatch, the
  caller receives an error and reformatting is skipped (raw refs pass
  through, the checklist flags them).
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass

from anthropic import Anthropic
from anthropic.types import TextBlock

DEFAULT_MODEL = "claude-sonnet-4-6"

# Rough Sonnet 4.6 pricing as of 2026-04. Update if the public rate card moves.
PRICE_PER_MTOK_INPUT_USD = 3.0
PRICE_PER_MTOK_OUTPUT_USD = 15.0

SYSTEM_PROMPT = """You convert raw bibliographic citation strings into CSL-JSON records.

Output format (strict):
- Output a single JSON array. No prose, no markdown fences, no commentary.
- The array length MUST equal the number of input citations.
- Preserve input order; each record's "id" is "ref1", "ref2", ... matching
  its 1-indexed input position.

Each CSL-JSON record must include these fields when extractable:
- id: "ref<N>" (required)
- type: one of "article-journal", "book", "chapter", "report", "webpage",
  "thesis", "paper-conference" (required; default to "article-journal" if
  unclear)
- author: array of {"family": "<lastname>", "given": "<initials or first names>"}
  preserving author order. Use "" for missing given names when the family
  name is clearly present.
  IMPORTANT: if the raw citation ends with "et al." (or "et al", "et al,"),
  the author list was truncated by the source. Append a final sentinel
  entry {"literal": "et al."} after the explicitly-named authors. CSL's
  "literal" field bypasses name parsing and is rendered verbatim, so
  citeproc emits the authors followed by ", et al." — the format AMA and
  Vancouver both expect for truncated author lists. Do not invent authors
  beyond what is literally in the raw text.
- title: article or chapter title, no trailing period
- container-title: the journal name in its **PubMed-abbreviated form**
  (e.g. "J Urol", "Eur Urol", "BMC Med Res Methodol", "JAMA"). Most
  clinical and biomedical journals use PubMed abbreviations as their
  canonical citation style, so emit the abbreviation whenever you know
  it — even if the raw text spelled the journal out in full. Examples
  of the canonical abbreviation to prefer:
    Journal of Urology → J Urol
    European Urology → Eur Urol
    New England Journal of Medicine → N Engl J Med
    The Lancet → Lancet
    JAMA → JAMA
  Only fall back to the raw's form if you are not confident of the
  canonical PubMed abbreviation (e.g. an obscure or non-indexed journal).
  Never invent an abbreviation you are uncertain of.
- container-title-short: mirror container-title when you abbreviated,
  so downstream styles that look up the short form get a consistent
  answer. Omit if you don't know an abbreviation.
- volume, issue, page: strings. Page ranges like "123-130"; single pages
  like "e12345" or "123".
- issued: {"date-parts": [[<year as integer>]]}
- DOI: bare DOI, without the "https://doi.org/" prefix, if present
- URL: only when no DOI is available

Rules:
1. Never fabricate a field you can't extract. Omit unknown fields entirely.
2. If a citation is too malformed to parse confidently, emit
   {"id": "ref<N>", "type": "article-journal", "title": "<the raw text>"}
   so the entry survives rather than being lost.
3. Strip leading numbering ("1.", "[1]") from the raw input before parsing —
   it belongs to the surrounding list, not the citation. Also strip any
   trailing "et al." from the RAW text when extracting — it is not part of
   any field; its presence is instead encoded by appending {"family":
   "others"} to the author array (see above).
4. Respond with the JSON array only."""


@dataclass
class CostEstimate:
    input_tokens: int
    output_tokens: int
    input_cost_usd: float
    output_cost_usd: float

    @property
    def total_usd(self) -> float:
        return self.input_cost_usd + self.output_cost_usd

    def format(self) -> str:
        return (
            f"~{self.input_tokens} input + ~{self.output_tokens} output tokens "
            f"= ~${self.total_usd:.3f} (Sonnet 4.6)"
        )


def estimate_cost(raw_strings: list[str]) -> CostEstimate:
    """Rough token estimate for a single parse call.

    Uses a 4-chars-per-token approximation, which is within ~20% for English
    scientific prose. Output budget assumes ~220 tokens per CSL-JSON record.
    """
    system_chars = len(SYSTEM_PROMPT)
    user_chars = sum(len(s) for s in raw_strings) + 8 * len(raw_strings)  # prefix overhead
    input_tokens = (system_chars + user_chars) // 4
    output_tokens = 220 * len(raw_strings)
    return CostEstimate(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        input_cost_usd=input_tokens / 1_000_000 * PRICE_PER_MTOK_INPUT_USD,
        output_cost_usd=output_tokens / 1_000_000 * PRICE_PER_MTOK_OUTPUT_USD,
    )


def _extract_json_array(text: str) -> list[dict]:
    """Pull the JSON array out of Claude's response, tolerating markdown fences."""
    stripped = text.strip()
    # If Claude wrapped in a code fence despite the instruction, strip it.
    fence_match = re.match(r"^```(?:json)?\s*(.*?)\s*```$", stripped, re.DOTALL)
    if fence_match:
        stripped = fence_match.group(1).strip()
    parsed = json.loads(stripped)
    if not isinstance(parsed, list):
        raise ValueError(f"Expected a JSON array, got {type(parsed).__name__}")
    return parsed


def parse_raw_references_to_csl_json(
    raw_strings: list[str],
    *,
    client: Anthropic | None = None,
    model: str = DEFAULT_MODEL,
) -> list[dict]:
    """Parse a list of raw citation strings into CSL-JSON records.

    Raises ``ValueError`` if the response can't be parsed, length-mismatches,
    or is missing required fields on every entry. Caller handles the error
    (typically by skipping LLM reformatting and flagging in the checklist).
    """
    if not raw_strings:
        return []
    if client is None:
        if not os.environ.get("ANTHROPIC_API_KEY"):
            raise RuntimeError(
                "ANTHROPIC_API_KEY is not set. Export it before using --use-llm, "
                "or skip --use-llm to pass references through unchanged."
            )
        client = Anthropic()

    user_message = "\n".join(f"[{i + 1}] {s.strip()}" for i, s in enumerate(raw_strings))

    response = client.messages.create(
        model=model,
        max_tokens=8192,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_message}],
    )

    # Concatenate text blocks (typically just one)
    parts = [b.text for b in response.content if isinstance(b, TextBlock)]
    raw_text = "".join(parts)
    records = _extract_json_array(raw_text)

    if len(records) != len(raw_strings):
        raise ValueError(
            f"Expected {len(raw_strings)} CSL-JSON records, got {len(records)}."
        )

    # Enforce id/type minimums. Mutate the records in place so the caller
    # always receives citeproc-valid entries.
    for i, rec in enumerate(records, start=1):
        if not isinstance(rec, dict):
            raise ValueError(f"Record #{i} is not an object: {rec!r}")
        rec.setdefault("id", f"ref{i}")
        rec.setdefault("type", "article-journal")

    return records
