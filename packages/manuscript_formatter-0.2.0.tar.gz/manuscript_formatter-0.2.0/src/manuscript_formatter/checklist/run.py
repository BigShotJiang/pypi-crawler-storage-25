"""Pre-submission checklist.

Runs deterministic validations against the manuscript *after* transforms have
been applied, and emits a Markdown report showing what passed, what failed,
and what still needs human review.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from manuscript_formatter.manuscript import Manuscript
from manuscript_formatter.profile.schema import JournalProfile

Status = Literal["pass", "fail", "review"]


@dataclass
class ChecklistItem:
    name: str
    status: Status
    detail: str = ""


def build_checklist(
    manuscript: Manuscript,
    profile: JournalProfile,
    references_reformatted: bool = False,
    abstract_restructured: bool = False,
) -> list[ChecklistItem]:
    items: list[ChecklistItem] = []

    # Main text word count
    body_words = manuscript.body_word_count
    limit = profile.main_text.word_limit
    items.append(
        ChecklistItem(
            name=f"Main text ≤ {limit} words",
            status="pass" if body_words <= limit else "fail",
            detail=f"{body_words} words",
        )
    )

    # Abstract word count
    abs_words = manuscript.abstract.word_count
    abs_limit = profile.abstract.word_limit
    items.append(
        ChecklistItem(
            name=f"Abstract ≤ {abs_limit} words",
            status="pass" if abs_words <= abs_limit else "fail",
            detail=f"{abs_words} words",
        )
    )

    # Abstract structure
    if profile.abstract.structured:
        expected = set(profile.abstract.sections)
        got = set(manuscript.abstract.sections.keys())
        missing = expected - got
        extra = got - expected
        if not missing and abstract_restructured:
            detail = (
                "restructured by LLM — verify findings preserved "
                "(see abstract_mapping.md and abstract_diff.md)"
            )
            status: Status = "review"
        elif not missing:
            detail = "all present (native match)"
            status = "pass"
        else:
            parts = [f"missing: {', '.join(sorted(missing))}"]
            if extra:
                parts.append(f"author used instead: {', '.join(sorted(extra))}")
            parts.append(
                "pass --restructure-abstract to have Claude map source sections to target"
            )
            detail = "; ".join(parts)
            status = "review"
        items.append(
            ChecklistItem(
                name=f"Structured abstract sections: {', '.join(profile.abstract.sections)}",
                status=status,
                detail=detail,
            )
        )

    # Required body sections
    present = {s.heading for s in manuscript.body_sections}
    missing_sections = [s for s in profile.main_text.required_sections if s not in present]
    items.append(
        ChecklistItem(
            name=f"Required sections: {', '.join(profile.main_text.required_sections)}",
            status="pass" if not missing_sections else "fail",
            detail="all present"
            if not missing_sections
            else f"missing: {', '.join(missing_sections)}",
        )
    )

    # Figure & table counts
    items.append(
        ChecklistItem(
            name=f"Figures ≤ {profile.figures.max}",
            status="pass" if len(manuscript.figures) <= profile.figures.max else "fail",
            detail=f"{len(manuscript.figures)} figure(s)",
        )
    )
    items.append(
        ChecklistItem(
            name=f"Tables ≤ {profile.tables.max}",
            status="pass" if len(manuscript.tables) <= profile.tables.max else "fail",
            detail=f"{len(manuscript.tables)} table(s)",
        )
    )
    if profile.figures.combined_with_tables_max is not None:
        cap = profile.figures.combined_with_tables_max
        combined = len(manuscript.figures) + len(manuscript.tables)
        items.append(
            ChecklistItem(
                name=f"Figures + tables ≤ {cap}",
                status="pass" if combined <= cap else "fail",
                detail=f"{combined} total",
            )
        )

    # Reference cap
    if profile.references.max is not None:
        items.append(
            ChecklistItem(
                name=f"References ≤ {profile.references.max}",
                status="pass" if len(manuscript.references) <= profile.references.max else "fail",
                detail=f"{len(manuscript.references)} reference(s)",
            )
        )

    # References were reformatted? Flag for review if raw .docx references passed through
    if references_reformatted:
        items.append(
            ChecklistItem(
                name=f"References formatted in {profile.reference_style}",
                status="review",
                detail=(
                    "reformatted via Pandoc+CSL — spot-check that Claude's extraction "
                    "preserved authors, titles, page ranges, and DOIs"
                ),
            )
        )
    else:
        items.append(
            ChecklistItem(
                name=f"References formatted in {profile.reference_style}",
                status="review",
                detail=(
                    "not reformatted — pass --use-llm to parse raw refs via Claude, or "
                    "supply a structured bibliography with --bib (.bib/.json/.ris)"
                ),
            )
        )

    # Patient summary (journals like European Urology)
    if profile.patient_summary and profile.patient_summary.required:
        items.append(
            ChecklistItem(
                name=f"Patient summary (≤ {profile.patient_summary.word_limit} words)",
                status="review",
                detail="required by this journal; not auto-generated in v0.1",
            )
        )

    return items


def render_markdown(items: list[ChecklistItem], profile: JournalProfile) -> str:
    icon = {"pass": "✓", "fail": "✗", "review": "?"}
    lines = [f"# Pre-submission checklist — {profile.name}", ""]
    for item in items:
        detail = f" — {item.detail}" if item.detail else ""
        lines.append(f"- [{icon[item.status]}] {item.name}{detail}")
    lines.append("")
    lines.append(
        "Legend: ✓ passed, ✗ failed (blocks submission), ? needs human review."
    )
    return "\n".join(lines)
