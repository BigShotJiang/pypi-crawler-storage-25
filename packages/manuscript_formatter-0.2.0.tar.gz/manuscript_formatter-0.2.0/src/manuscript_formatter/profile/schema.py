from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class AbstractRules(BaseModel):
    model_config = ConfigDict(extra="forbid")

    structured: bool
    sections: list[str] = Field(default_factory=list)
    word_limit: int


class MainTextRules(BaseModel):
    model_config = ConfigDict(extra="forbid")

    word_limit: int
    required_sections: list[str]
    section_aliases: dict[str, str] = Field(default_factory=dict)


class PatientSummaryRules(BaseModel):
    """Plain-language summary required by some journals (e.g., European Urology)."""

    model_config = ConfigDict(extra="forbid")

    required: bool
    word_limit: int
    sentence_limit: int | None = None
    separate_file: bool = False


class ReferenceRules(BaseModel):
    model_config = ConfigDict(extra="forbid")

    max: int | None = None


class TitlePageRules(BaseModel):
    model_config = ConfigDict(extra="forbid")

    separate_file: bool
    fields: list[str]


class CoverLetterRules(BaseModel):
    model_config = ConfigDict(extra="forbid")

    required: bool
    must_state: list[str] = Field(default_factory=list)


class FigureRules(BaseModel):
    model_config = ConfigDict(extra="forbid")

    max: int
    accepted_formats: list[str]
    resolution_dpi_min: int | None = None
    # Some journals cap the combined count of figures + tables (e.g., European Urology)
    combined_with_tables_max: int | None = None


class TableRules(BaseModel):
    model_config = ConfigDict(extra="forbid")

    max: int


class DisclosureRules(BaseModel):
    model_config = ConfigDict(extra="forbid")

    form: str


class JournalProfile(BaseModel):
    """Declarative description of a journal's submission requirements."""

    model_config = ConfigDict(extra="forbid")

    slug: str
    name: str
    issn: str | None = None
    publisher: str | None = None
    guidelines_url: str | None = None

    reference_style: str

    abstract: AbstractRules
    main_text: MainTextRules
    patient_summary: PatientSummaryRules | None = None
    title_page: TitlePageRules
    cover_letter: CoverLetterRules
    figures: FigureRules
    tables: TableRules
    references: ReferenceRules = Field(default_factory=ReferenceRules)
    disclosures: DisclosureRules
