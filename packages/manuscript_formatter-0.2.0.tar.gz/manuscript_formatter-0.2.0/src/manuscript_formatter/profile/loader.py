from __future__ import annotations

from pathlib import Path

import yaml

from manuscript_formatter.profile.schema import JournalProfile


def profiles_dir() -> Path:
    """Return the directory holding bundled journal YAML profiles.

    Profiles live alongside the package at ``manuscript_formatter/journals/``
    so they work identically in dev-mode (editable install) and after
    ``pip install manuscript-formatter``.
    """
    return Path(__file__).resolve().parent.parent / "journals"


def load_profile(slug_or_path: str | Path) -> JournalProfile:
    """Load a journal profile by slug (e.g., ``"journal-of-urology"``) or path."""
    path = Path(slug_or_path)
    if not path.exists() or path.is_dir():
        path = profiles_dir() / f"{slug_or_path}.yaml"
    if not path.exists():
        raise FileNotFoundError(f"Journal profile not found: {slug_or_path}")

    with path.open() as f:
        data = yaml.safe_load(f)
    return JournalProfile.model_validate(data)
