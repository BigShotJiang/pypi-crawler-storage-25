"""Emit the submission package as .docx files plus a Markdown checklist.

Produces:
- ``main.docx``         — reformatted main manuscript (title, abstract, body, references)
- ``title_page.docx``   — separate title page if the profile asks for one
- ``cover_letter.docx`` — templated cover letter with required statements
- ``disclosures.md``    — placeholder pointing at the required disclosure form
"""

from __future__ import annotations

from pathlib import Path

from docx import Document

from manuscript_formatter.manuscript import Manuscript
from manuscript_formatter.profile.schema import JournalProfile


def _add_section(doc: Document, heading: str, paragraphs: list[str], level: int = 1) -> None:
    doc.add_heading(heading, level=level)
    for p in paragraphs:
        doc.add_paragraph(p)


def _add_body_section(doc: Document, section) -> None:  # type: ignore[no-untyped-def]
    doc.add_heading(section.heading, level=1)
    for p in section.paragraphs:
        doc.add_paragraph(p)
    for sub in section.subsections:
        doc.add_heading(sub.heading, level=2)
        for p in sub.paragraphs:
            doc.add_paragraph(p)


def write_main_docx(manuscript: Manuscript, profile: JournalProfile, out: Path) -> Path:
    doc = Document()

    if manuscript.title:
        doc.add_heading(manuscript.title, level=0)

    # Abstract. We never silently drop author content:
    # - If the author's structured abstract covers every section the journal
    #   requires, render in the journal's canonical order (names match).
    # - Otherwise render the author's subsections as they wrote them. The
    #   checklist surfaces the mismatch so a human can reshape it.
    doc.add_heading("Abstract", level=1)
    if manuscript.abstract.structured and manuscript.abstract.sections:
        expected = profile.abstract.sections
        author_has_all = all(name in manuscript.abstract.sections for name in expected)
        if author_has_all:
            pairs = [(name, manuscript.abstract.sections[name]) for name in expected]
        else:
            pairs = list(manuscript.abstract.sections.items())
        for name, text in pairs:
            doc.add_heading(name, level=2)
            doc.add_paragraph(text)
    else:
        doc.add_paragraph(manuscript.abstract.text)

    # Body
    for section in manuscript.body_sections:
        _add_body_section(doc, section)

    # References. Emitted as-is: both Pandoc's citeproc output and raw .docx
    # references typically carry their own numbering ("1. Smith..."), so we
    # avoid adding another prefix that would double up.
    if manuscript.references:
        doc.add_heading("References", level=1)
        for ref in manuscript.references:
            doc.add_paragraph(ref.raw)

    doc.save(out)
    return out


def write_title_page(manuscript: Manuscript, profile: JournalProfile, out: Path) -> Path:
    """Emit a separate title page when the profile requires one.

    Many fields (short_title, keywords, corresponding_author details) aren't
    reliably extractable from a raw .docx, so unknown fields are written as
    ``[TBD: <field>]`` placeholders so authors can fill them in.
    """
    doc = Document()
    doc.add_heading("Title Page", level=0)

    fields = profile.title_page.fields
    placeholders = {
        "title": manuscript.title or "[TBD: title]",
        "short_title": manuscript.short_title or "[TBD: short title]",
        "authors": ", ".join(a.name for a in manuscript.authors) or "[TBD: authors]",
        "affiliations": "; ".join(
            f"{a.name}: {'; '.join(a.affiliations)}"
            for a in manuscript.authors
            if a.affiliations
        )
        or "[TBD: affiliations]",
        "corresponding_author": next(
            (a.name for a in manuscript.authors if a.corresponding),
            "[TBD: corresponding author]",
        ),
        "keywords": ", ".join(manuscript.keywords) or "[TBD: 3-6 keywords]",
        "word_count": str(manuscript.body_word_count),
        "abstract_word_count": str(manuscript.abstract.word_count),
        "reference_count": str(len(manuscript.references)),
        "figure_count": str(len(manuscript.figures)),
        "table_count": str(len(manuscript.tables)),
    }

    for field in fields:
        label = field.replace("_", " ").title()
        value = placeholders.get(field, f"[TBD: {field}]")
        p = doc.add_paragraph()
        p.add_run(f"{label}: ").bold = True
        p.add_run(value)

    doc.save(out)
    return out


def write_cover_letter(manuscript: Manuscript, profile: JournalProfile, out: Path) -> Path:
    """Emit a cover letter templated with the journal's required statements."""
    doc = Document()

    doc.add_paragraph("[Date]")
    doc.add_paragraph()
    doc.add_paragraph(f"Editor-in-Chief\n{profile.name}")
    doc.add_paragraph()

    doc.add_paragraph("Dear Editor,")
    doc.add_paragraph()

    title = manuscript.title or "[TBD: manuscript title]"
    doc.add_paragraph(
        f'We are pleased to submit our manuscript, "{title}", for consideration '
        f"as an original article in {profile.name}."
    )
    doc.add_paragraph(
        "[TBD: one paragraph summarizing the study's question, methods, main finding, "
        "and why it matters to this journal's readership.]"
    )

    statement_templates = {
        "novelty": "We believe this work is novel and represents a meaningful advance "
        "because [TBD: state novelty and contribution].",
        "non_duplicate_submission": "This manuscript has not been published elsewhere "
        "and is not under consideration by another journal.",
        "all_authors_approve": "All listed authors have reviewed and approved the "
        "final manuscript and agree to its submission.",
        "no_conflicts_undisclosed": "All potential conflicts of interest are disclosed "
        "in the accompanying ICMJE forms; there are no undisclosed conflicts.",
    }

    if profile.cover_letter.must_state:
        doc.add_paragraph()
        for key in profile.cover_letter.must_state:
            doc.add_paragraph(
                statement_templates.get(
                    key, f"[TBD: statement for '{key}' required by {profile.name}.]"
                )
            )

    doc.add_paragraph()
    doc.add_paragraph("Thank you for your consideration.")
    doc.add_paragraph()
    doc.add_paragraph("Sincerely,")
    doc.add_paragraph("[TBD: corresponding author name]")
    doc.add_paragraph("[TBD: affiliation]")
    doc.add_paragraph("[TBD: email]")

    doc.save(out)
    return out


def write_disclosures_placeholder(profile: JournalProfile, out: Path) -> Path:
    form = profile.disclosures.form
    text = (
        f"# Disclosures — {profile.name}\n\n"
        f"This journal requires the **{form.upper()}** disclosure form.\n\n"
    )
    if form.lower() == "icmje":
        text += (
            "Generate the form at https://www.icmje.org/disclosure-of-interest/ "
            "for each author and attach to the submission.\n"
        )
    else:
        text += f"Obtain the current {form} form from the journal's submission site.\n"
    out.write_text(text)
    return out
