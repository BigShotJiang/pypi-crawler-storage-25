"""Command-line entry point.

Usage:
    manuscript-format INPUT.docx --journal SLUG --out OUTPUT_DIR
        [--bib PATH] [--use-llm] [--restructure-abstract] [--yes]
"""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console

from manuscript_formatter.checklist import build_checklist, render_markdown
from manuscript_formatter.ingest import ingest_docx
from manuscript_formatter.output import (
    write_cover_letter,
    write_disclosures_placeholder,
    write_main_docx,
    write_title_page,
)
from manuscript_formatter.profile import load_profile
from manuscript_formatter.transforms.deterministic import (
    apply_section_rules,
    reformat_references,
)

app = typer.Typer(add_completion=False, help=__doc__)
console = Console()


@app.command()
def main(
    input_path: Path = typer.Argument(..., exists=True, readable=True, help="Input .docx"),
    journal: str = typer.Option(..., "--journal", "-j", help="Journal profile slug"),
    out: Path = typer.Option(Path("./submission"), "--out", "-o", help="Output directory"),
    bib: Path | None = typer.Option(
        None,
        "--bib",
        "-b",
        exists=True,
        readable=True,
        help="Structured bibliography (.bib, .json, .ris) for reference reformatting",
    ),
    use_llm: bool = typer.Option(
        False,
        "--use-llm",
        help=(
            "Use Claude to parse raw references into CSL-JSON, then Pandoc-reformat "
            "to the journal's style. Overridden by --bib when both are supplied."
        ),
    ),
    restructure_abstract: bool = typer.Option(
        False,
        "--restructure-abstract",
        help=(
            "Use Claude to restructure the abstract to the target journal's sections + "
            "word limit. Emits abstract_mapping.md and abstract_diff.md alongside the "
            "checklist so authors can review what moved where. Never rewrites findings."
        ),
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip the cost-confirmation prompt before an LLM call.",
    ),
) -> None:
    if input_path.suffix.lower() != ".docx":
        raise typer.BadParameter(
            f"Only .docx is supported in v0.1 (got {input_path.suffix}). "
            "PDF ingest is planned for Phase 2."
        )

    profile = load_profile(journal)
    console.print(f"[bold]Loaded profile:[/bold] {profile.name}")

    manuscript = ingest_docx(input_path)
    console.print(
        f"[bold]Parsed manuscript:[/bold] {len(manuscript.body_sections)} section(s), "
        f"{len(manuscript.references)} reference(s), "
        f"{manuscript.body_word_count} body words, "
        f"{manuscript.abstract.word_count} abstract words across "
        f"{len(manuscript.abstract.sections) if manuscript.abstract.structured else 1} section(s)"
    )

    manuscript = apply_section_rules(manuscript, profile)

    # Abstract restructuring — opt-in LLM call. Done before everything else so
    # the new abstract flows into main.docx, title page word counts, checklist.
    abstract_report = None
    if restructure_abstract:
        from manuscript_formatter.transforms.llm import (
            estimate_abstract_cost,
        )
        from manuscript_formatter.transforms.llm import (
            restructure_abstract as _restructure,
        )
        from manuscript_formatter.transforms.llm.abstract import render_side_by_side_diff

        abstract_estimate = estimate_abstract_cost(manuscript.abstract, profile)
        console.print(
            f"[yellow]Planned LLM call:[/yellow] restructure abstract to "
            f"{len(profile.abstract.sections)} section(s) ≤ "
            f"{profile.abstract.word_limit} words — {abstract_estimate.format()}"
        )
        if not yes and not typer.confirm("Proceed with the API call?", default=True):
            console.print("[red]Skipped abstract restructure.[/red]")
        else:
            try:
                new_abstract, abstract_report = _restructure(manuscript.abstract, profile)
                manuscript.abstract = new_abstract
                console.print(
                    f"[green]Restructured abstract:[/green] "
                    f"{abstract_report.source_word_count} → "
                    f"{abstract_report.actual_word_count} words "
                    f"({abstract_report.compression_ratio:.0%} retained)"
                )
                out.mkdir(parents=True, exist_ok=True)
                (out / "abstract_mapping.md").write_text(
                    abstract_report.to_markdown(profile.name)
                )
                (out / "abstract_diff.md").write_text(
                    render_side_by_side_diff(
                        # ingest had already captured the pre-restructure abstract
                        # in the fresh ingest at the top of the run; to surface it
                        # on the diff we re-ingest — tiny cost, avoids stashing state
                        ingest_docx(input_path).abstract,
                        abstract_report,
                    )
                )
            except Exception as e:
                console.print(f"[red]Abstract restructure failed:[/red] {e}")
                console.print("Falling back to the source abstract; checklist will flag.")

    csl_json_records: list[dict] | None = None
    if use_llm and bib is None and manuscript.references:
        from manuscript_formatter.transforms.llm import (
            estimate_cost,
            parse_raw_references_to_csl_json,
        )

        ref_estimate = estimate_cost([r.raw for r in manuscript.references])
        console.print(
            f"[yellow]Planned LLM call:[/yellow] parse "
            f"{len(manuscript.references)} references — {ref_estimate.format()}"
        )
        if not yes and not typer.confirm("Proceed with the API call?", default=True):
            console.print("[red]Skipped LLM parse.[/red] References will pass through.")
        else:
            try:
                csl_json_records = parse_raw_references_to_csl_json(
                    [r.raw for r in manuscript.references]
                )
                console.print(
                    f"[green]Parsed {len(csl_json_records)} references into CSL-JSON.[/green]"
                )
            except Exception as e:
                console.print(f"[red]LLM parse failed:[/red] {e}")
                console.print("Falling back to raw references; checklist will flag.")

    manuscript = reformat_references(
        manuscript,
        profile,
        bib_path=bib,
        csl_json_records=csl_json_records,
    )
    if bib is not None or csl_json_records is not None:
        console.print(f"[bold]Reformatted {len(manuscript.references)} references[/bold]")

    out.mkdir(parents=True, exist_ok=True)
    write_main_docx(manuscript, profile, out / "main.docx")
    if profile.title_page.separate_file:
        write_title_page(manuscript, profile, out / "title_page.docx")
    if profile.cover_letter.required:
        write_cover_letter(manuscript, profile, out / "cover_letter.docx")
    write_disclosures_placeholder(profile, out / "disclosures.md")

    items = build_checklist(
        manuscript,
        profile,
        references_reformatted=bib is not None or csl_json_records is not None,
        abstract_restructured=abstract_report is not None,
    )
    (out / "checklist.md").write_text(render_markdown(items, profile))

    console.print(f"[green]Wrote submission package to:[/green] {out}")
    for path in sorted(out.iterdir()):
        console.print(f"  • {path.name}")


if __name__ == "__main__":
    app()
