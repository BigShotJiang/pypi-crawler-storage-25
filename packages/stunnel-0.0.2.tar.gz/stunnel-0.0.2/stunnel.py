import asyncio
import ssl
import os
import subprocess
import logging
import time
import random
from datetime import datetime

# ================================================
# ADVANCED SSL/TLS TUNNEL with AUTO-RECONNECT
# Interactive • Forged SNI • DPI evasion • CSV logging
# Ready for PyPI — run with: ssltunnel
# ================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger(__name__)

CSV_LOG = "tunnel_traffic_log.csv"
if not os.path.exists(CSV_LOG):
    with open(CSV_LOG, "w") as f:
        f.write("timestamp,mode,connection_id,bytes_sent,bytes_received\n")


async def relay(reader: asyncio.StreamReader, writer: asyncio.StreamWriter, direction: str, conn_id: str):
    bytes_sent = bytes_received = 0
    try:
        while True:
            data = await reader.read(16384)
            if not data:
                break

            if direction.startswith("CLIENT"):
                bytes_sent += len(data)
            else:
                bytes_received += len(data)

            if hasattr(relay, "jitter_ms") and relay.jitter_ms > 0:
                delay = (relay.jitter_ms * random.random()) / 1000
                await asyncio.sleep(delay)

            writer.write(data)
            await writer.drain()
    except (ConnectionResetError, BrokenPipeError, asyncio.IncompleteReadError, OSError):
        pass
    except Exception as e:
        logger.debug(f"Relay error {direction}: {e}")
    finally:
        if writer.transport:
            writer.close()
            try:
                await writer.wait_closed()
            except:
                pass
        with open(CSV_LOG, "a") as f:
            f.write(f"{datetime.now().isoformat()},{direction.split('→')[0]},{conn_id},{bytes_sent},{bytes_received}\n")
        logger.info(f"[{direction}] Closed — sent:{bytes_sent} recv:{bytes_received}")


def generate_realistic_cert(cert_file="cert.pem", key_file="key.pem", cn="api.microsoft.com"):
    if os.path.exists(cert_file) and os.path.exists(key_file):
        logger.info(f"✅ Using existing cert/key for {cn}")
        return True

    logger.info(f"🔧 Auto-generating realistic cert (CN={cn}) ...")
    try:
        subprocess.run([
            "openssl", "req", "-x509", "-newkey", "rsa:4096",
            "-keyout", key_file, "-out", cert_file,
            "-days", "365", "-nodes",
            "-subj", f"/C=US/ST=California/L=San Francisco/O=Microsoft Corporation/CN={cn}"
        ], check=True, capture_output=True, text=True)
        logger.info("✅ Cert generated successfully!")
        return True
    except FileNotFoundError:
        logger.error("❌ openssl not found. Install it with: sudo apt install openssl -y (or equivalent)")
        return False
    except subprocess.CalledProcessError as e:
        logger.error(f"❌ Cert generation failed: {e.stderr.strip()}")
        return False


async def create_tls_connection(remote_host, remote_port, sni_forge, proxy_host=None, proxy_port=None):
    ssl_context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE
    ssl_context.set_ciphers("ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES128-GCM-SHA256")
    ssl_context.set_alpn_protocols(["h2", "http/1.1"])
    ssl_context.options |= ssl.OP_NO_SSLv2 | ssl.OP_NO_SSLv3 | ssl.OP_NO_COMPRESSION

    padding = os.urandom(32) if random.random() > 0.5 else b""

    if proxy_host and proxy_port:
        plain_reader, plain_writer = await asyncio.open_connection(proxy_host, proxy_port)
        connect_req = (
            f"CONNECT {remote_host}:{remote_port} HTTP/1.1\r\n"
            f"Host: {remote_host}\r\n"
            f"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\n\r\n"
        )
        plain_writer.write(connect_req.encode())
        await plain_writer.drain()
        response = await plain_reader.readuntil(b'\r\n\r\n')
        if b"200 Connection established" not in response:
            raise ConnectionError("Proxy CONNECT failed")

        loop = asyncio.get_running_loop()
        transport = plain_writer.transport
        tls_transport = await loop.start_tls(transport, plain_reader, ssl_context,
                                             server_hostname=sni_forge, ssl_handshake_timeout=10)
        remote_reader = asyncio.StreamReader()
        remote_writer = asyncio.StreamWriter(tls_transport, None, remote_reader, loop)
    else:
        remote_reader, remote_writer = await asyncio.open_connection(
            remote_host, remote_port, ssl=ssl_context,
            server_hostname=sni_forge, ssl_handshake_timeout=10
        )

    if padding:
        remote_writer.write(padding)
        await remote_writer.drain()

    return remote_reader, remote_writer


async def handle_client(local_reader, local_writer, remote_host, remote_port,
                        sni_forge, jitter_ms, proxy_host=None, proxy_port=None):
    peer = local_writer.get_extra_info('peername')
    conn_id = f"{peer[0]}:{peer[1]}-{int(time.time())}"
    logger.info(f"[CLIENT] New local connection from {peer} → forging TLS (SNI={sni_forge})")

    try:
        remote_reader, remote_writer = await create_tls_connection(remote_host, remote_port, sni_forge, proxy_host, proxy_port)
        relay.jitter_ms = jitter_ms
        tasks = [
            asyncio.create_task(relay(local_reader, remote_writer, "CLIENT→REMOTE", conn_id)),
            asyncio.create_task(relay(remote_reader, local_writer, "REMOTE→CLIENT", conn_id))
        ]
        await asyncio.gather(*tasks, return_exceptions=True)
    except Exception as e:
        logger.warning(f"[CLIENT] Tunnel error from {peer}: {e}")
    finally:
        local_writer.close()
        try:
            await local_writer.wait_closed()
        except:
            pass


async def run_server(listen_host, listen_port, forward_host, forward_port, cert, key):
    if not generate_realistic_cert(cert, key):
        logger.error("Cannot start without valid certificate.")
        return

    ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ssl_context.load_cert_chain(certfile=cert, keyfile=key)
    ssl_context.set_ciphers("ECDHE-RSA-AES256-GCM-SHA384")
    ssl_context.options |= ssl.OP_NO_COMPRESSION

    async def handler(reader, writer):
        peer = writer.get_extra_info('peername')
        conn_id = f"{peer[0]}:{peer[1]}"
        logger.info(f"[SERVER] New TLS connection from {peer}")
        try:
            target_reader, target_writer = await asyncio.open_connection(forward_host, forward_port)
            tasks = [
                asyncio.create_task(relay(reader, target_writer, "SERVER→INTERNAL", conn_id)),
                asyncio.create_task(relay(target_reader, writer, "INTERNAL→SERVER", conn_id))
            ]
            await asyncio.gather(*tasks, return_exceptions=True)
        except Exception as e:
            logger.warning(f"[SERVER] Forward error: {e}")
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except:
                pass

    server = await asyncio.start_server(handler, listen_host, listen_port, ssl=ssl_context, reuse_address=True)
    logger.info(f"🚀 SERVER MODE — Listening on {listen_host}:{listen_port} (TLS) → forwarding to {forward_host}:{forward_port}")
    logger.info(f"   Traffic logged to {CSV_LOG}")
    async with server:
        await server.serve_forever()


async def run_client_with_reconnect(local_host, local_port, remote_host, remote_port,
                                    sni_forge, jitter_ms, proxy_host=None, proxy_port=None):
    logger.info(f"🚀 CLIENT MODE with AUTO-RECONNECT — Local listener on {local_host}:{local_port}")
    logger.info(f"   Remote: {remote_host}:{remote_port} | Forged SNI: {sni_forge} | Jitter: {jitter_ms}ms")
    if proxy_host:
        logger.info(f"   Upstream proxy: {proxy_host}:{proxy_port}")

    async def local_handler(reader, writer):
        await handle_client(reader, writer, remote_host, remote_port,
                            sni_forge, jitter_ms, proxy_host, proxy_port)

    while True:
        try:
            local_server = await asyncio.start_server(local_handler, local_host, local_port, reuse_address=True)
            logger.info(f"✅ Local server started on {local_host}:{local_port} — ready for SSH/tools")
            async with local_server:
                await local_server.serve_forever()
        except Exception as e:
            logger.warning(f"Local listener error: {e}. Restarting soon...")
        except asyncio.CancelledError:
            break

        backoff = min(30, 5 * (2 ** random.randint(0, 3)))
        await asyncio.sleep(backoff + random.random() * 2)
        logger.info(f"🔄 Attempting auto-reconnect...")


async def interactive_main():
    print("\n" + "="*75)
    print("🔥 ADVANCED SSL/TLS TUNNEL with AUTO-RECONNECT")
    print("   Forged SNI • DPI evasion • CSV logging • PyPI ready")
    print("="*75 + "\n")

    mode = input("Run as [S]erver or [C]lient with auto-reconnect? [C]: ").strip().lower()
    mode = "server" if mode == "s" else "client"

    if mode == "server":
        print("\n=== SERVER MODE ===")
        listen_port = input("TLS listen port (443 recommended) [443]: ").strip() or "443"
        forward_host = input("Internal service IP [127.0.0.1]: ").strip() or "127.0.0.1"
        forward_port = input("Internal port (e.g. 22) [22]: ").strip() or "22"
        cn = input("Certificate CN [api.microsoft.com]: ").strip() or "api.microsoft.com"

        await run_server("0.0.0.0", int(listen_port), forward_host, int(forward_port), "cert.pem", "key.pem")

    else:
        print("\n=== CLIENT MODE with AUTO-RECONNECT ===")
        local_port = input("Local port for tools (SSH etc.) [1080]: ").strip() or "1080"
        remote_host = input("Remote server IP/hostname: ").strip()
        if not remote_host:
            print("❌ Remote host is required.")
            return
        remote_port = input("Remote TLS port [443]: ").strip() or "443"
        sni_forge = input("Forged SNI [api.microsoft.com]: ").strip() or "api.microsoft.com"
        jitter = input("Jitter ms (0 = none) [50]: ").strip() or "50"

        use_proxy = input("Use upstream HTTP proxy? (y/N) [N]: ").strip().lower()
        proxy_host = proxy_port = None
        if use_proxy == "y":
            proxy_host = input("Proxy host: ").strip()
            proxy_port_str = input("Proxy port [8080]: ").strip() or "8080"
            proxy_port = int(proxy_port_str)

        await run_client_with_reconnect("127.0.0.1", int(local_port), remote_host, int(remote_port),
                                        sni_forge, int(jitter), proxy_host, proxy_port)


def main3():
    """Entry point for PyPI console script"""
    try:
        asyncio.run(interactive_main())
    except KeyboardInterrupt:
        print("\n\n👋 Tunnel stopped. Check tunnel_traffic_log.csv for analysis.")
    except Exception as e:
        logger.error(f"Fatal error: {e}")


main3()
