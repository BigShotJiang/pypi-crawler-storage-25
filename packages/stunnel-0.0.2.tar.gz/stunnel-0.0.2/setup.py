from setuptools import setup

setup(
    name='stunnel',  # Lowercase, unique on PyPI
    version='0.0.2',
    py_modules=['stunnel'],  # Matches your filename
    entry_points={
        'console_scripts': [
            'stunnel = stunnel:main',  # CLI command: maps to bhp_pro.py:main()
        ],
    },
    author='ssskingsss12',
    author_email='smalls3000i@gmail.com',
    description='SSL Tunnel Tool',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    classifiers=[
        'Programming Language :: Python :: 3',
    ],
    python_requires='>=3.10',
)

