# This file is part of sympy2c.
#
# Copyright (C) 2013-2022 ETH Zurich, Institute for Particle and Astrophysics and SIS
# ID.
#
# This program is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this
# program.  If not, see <http://www.gnu.org/licenses/>.

import sympy as sp

from .registry import RegistryKeys, register
from .utils import Hasher, align, concat_generator_results
from .wrapper import WrapperBase


class InterpolationFunction1DInstance(
    sp.Function("_InterpolationFunction1D", nargs=2, real=True)
):
    @property
    def free_symbols(self):
        return self.argument.free_symbols

    @property
    def argument(self):
        return self.args[1]

    def __hash__(self):
        return hash(self.args)

    def __eq__(self, other):
        if type(self) != type(other):  # noqa: E721
            return False
        return self.args[0] == other.args[0] and self.args[1] == other.args[1]

    def __str__(self):
        return "{}({})".format(self.args[0], self.args[1])

    def _subs(self, old, new, **hints):
        return InterpolationFunction1DInstance(
            self.args[0], self.args[1]._subs(old, new, **hints)
        )


class InterpolationFunction1D(
    sp.Function("_InterpolationFunction1D", nargs=1, real=True)
):
    @property
    def free_symbols(self):
        return {self}

    def __hash__(self):
        return hash(self.args)

    def __eq__(self, other):
        if type(self) != type(other):  # noqa: E721
            return False
        return self.args[0] == other.args[0]

    def __call__(self, argument):
        return InterpolationFunction1DInstance(self.args[0], argument)

    def _subs(self, old, new, **hints):
        return InterpolationFunction1D(self.args[0]._subs(old, new, **hints))


def get_unique_id_interpolation_function_1d(self):
    return Hasher().update(self.args[0]).hexdigest()


register(
    RegistryKeys.UNIQUE_ID,
    InterpolationFunction1D,
    get_unique_id_interpolation_function_1d,
)


class InterpolationFunction1DWrapper(WrapperBase):
    def __init__(self, interpolation_function_1d, visitor):
        self.name = interpolation_function_1d.args[0]
        self.visitor = visitor

    def setup_code_generation(self):
        pass

    def c_header(self):
        return align(
            """
            |extern "C" {{
            |   void         _set_{name}_values(double *, double *, size_t);
            |}}
            |
            |extern "C" double __ip_{name}(double);
            |extern "C" void   __ip_sorted_{name}(double *, size_t, double *);
            |extern "C" double  * _{name}_x_min_p, * _{name}_x_max_p;
            |extern "C" double * _get_x_{name}();
            |extern "C" double * _get_y_{name}();
            |extern "C" int _get_n_{name}();
            """.format(name=self.name)
        )

    def c_code(self, header_file_path):
        return align(
            """
            |cspline::Spline<double>     _{name}_spline;
            |static double    _{name}_x_min, _{name}_x_max;
            |double           * _{name}_x_min_p = NULL, * _{name}_x_max_p = NULL;
            |static int       _{name}_n{{-1}};
            |static std::vector<double>  _{name}_x, _{name}_y;
            |
            |
            |extern "C" int _get_n_{name}() {{
            |    return _{name}_n;
            |}}
            |
            |extern "C" void _set_{name}_values(double *x, double *y, size_t n) {{
            |
            |     if (n < 1 ) {{
            |         set_error_message("the vectors must contain at least one element");
            |         return;
            |     }}
            |     _{name}_x = std::vector<double>(x, x + n);
            |     _{name}_y = std::vector<double>(y, y + n);
            |
            |     _{name}_spline = cspline::make_spline(_{name}_x, _{name}_y);
            |     _{name}_x_min = _{name}_x_max = x[0];
            |     for (size_t i = 1; i < n; ++i)
            |     {{
            |         if (x[i] > _{name}_x_max) _{name}_x_max = x[i];
            |         if (x[i] < _{name}_x_min) _{name}_x_min = x[i];
            |     }}
            |     _{name}_n = n;
            |
            |     _{name}_x_min_p = & _{name}_x_min;
            |     _{name}_x_max_p = & _{name}_x_max;
            |
            |}}
            |
            |extern "C" double * _get_x_{name}() {{
            |     return _{name}_x.data();
            |}}
            |
            |extern "C" double * _get_y_{name}() {{
            |     return _{name}_y.data();
            |}}
            |
            |extern "C" double __ip_{name}(double x) {{
            |       if (_{name}_x_min_p == NULL) {{
            |            set_error_message("you must call set_{name}_values first");
            |            return 0;
            |       }}
            |       return cspline::ispline(x, _{name}_spline);
            |}}
            |
            |extern "C" void __ip_sorted_{name}(double *x, size_t n, double* y) {{
            |       if (_{name}_x_min_p == NULL) {{
            |            set_error_message("you must call set_{name}_values first");
            |            return;
            |       }}
            |       std::vector<double> y_values = cspline::evaluate_many(std::vector<double>(x, x + n), _{name}_spline);
            |       std::copy(y_values.begin(), y_values.end(), y);
            |}}
            """.format(name=self.name)
        )

    @concat_generator_results
    def cython_code(self, header_file_path):
        # we insert "_" at beginning of c functions to avoid clash with
        # cython functions:
        for code in self.cython_header(header_file_path):
            yield code
        for code in self.cython_function_wrapper():
            yield code
        return
        for code in self.cython_ufunc_wrapper():
            yield code

    def cython_header(self, header_file_path):
        yield align(
            """
        |cdef extern from "{header_file_path}":
        |    double __ip_{name}(double);
        |    void   __ip_sorted_{name}(double *, size_t, double *);
        |    double _set_{name}_values(double *, double *, size_t);
        |    double  * _{name}_x_min_p, * _{name}_x_max_p;
        |    int _get_n_{name}();
        |    double * _get_x_{name}();
        |    double * _get_y_{name}();
        """.lstrip().format(header_file_path=header_file_path, name=self.name)
        )

    def cython_function_wrapper(self):
        yield align(
            """
        |def set_{name}_values(np.ndarray[np.double_t, ndim=1, cast=True, mode="c"] x,
        |                      np.ndarray[np.double_t, ndim=1, cast=True, mode="c"] y):
        |
        |    assert len(x) == len(y), "x and y must be of same size"
        |    assert len(x) > 0, "empty array not allowed"
        |    _set_{name}_values(&x[0], &y[0], len(x))
        |
        |def ip_sorted_{name}(np.ndarray[np.double_t, ndim=1, cast=True] x):
        |    cdef result = np.zeros_like(x, np.float64)
        |    cdef double[:] _result = result
        |    cdef double[:] _x = x.ravel()
        |    __ip_sorted_{name}(&_x[0], x.shape[0], &_result[0])
        |    return result
        |
        |def get_x_{name}():
        |    cdef int n = _get_n_{name}();
        |    return None if n <= 0 else np.asarray(<np.float64_t[:n]> _get_x_{name}())
        |
        |def get_y_{name}():
        |    cdef int n = _get_n_{name}();
        |    return None if n <= 0 else np.asarray(<np.float64_t[:n]> _get_y_{name}())
        """
        ).format(name=self.name)

    def determine_required_extra_wrappers(self):
        pass


def get_unique_id_interpolation_function_1d_wrapper(self):
    return Hasher().update(self.name).hexdigest()


register(
    RegistryKeys.UNIQUE_ID,
    InterpolationFunction1DWrapper,
    get_unique_id_interpolation_function_1d_wrapper,
)
