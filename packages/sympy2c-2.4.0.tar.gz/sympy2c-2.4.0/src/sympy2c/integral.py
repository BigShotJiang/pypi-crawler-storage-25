# This file is part of sympy2c.
#
# Copyright (C) 2013-2022 ETH Zurich, Institute for Particle and Astrophysics and SIS
# ID.
#
# This program is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this
# program.  If not, see <http://www.gnu.org/licenses/>.

import sympy as sp
from sympy.matrices.matrices import MatrixBase

from .create_curry_class import create_curry_class
from .registry import RegistryKeys, register
from .utils import Hasher, align, concat_generator_results
from .wrapper import WrapperBase


def Integral(integrand, integration_variable, low, high, id_="default"):
    if "[" in str(integration_variable):
        raise ValueError("dont use array or array elements as integration variable")
    if not isinstance(low, (int, float)):
        assert integration_variable not in low.free_symbols

    if not isinstance(high, (int, float)):
        assert integration_variable not in high.free_symbols

    if isinstance(integrand, MatrixBase):
        integrands = list(integrand)
        assert len(integrands) == 1, "no implementation for vector valued integrals"
        integrand = integrands[0]

    if isinstance(low, (int, float)):
        low = sp.Number(low)
    if isinstance(high, (int, float)):
        high = sp.Number(high)

    integrand = Integrand(integrand, integration_variable)

    unique_id = (
        Hasher()
        .update(integrand.sort_key())
        .update(low.sort_key())
        .update(high.sort_key())
        .update(integration_variable)
        .update(id_)
        .hexdigest()
    )

    # all args must be "sympy"-fiable:
    result = _Integral(
        integrand, integration_variable, low, high, id_, sp.Symbol(unique_id)
    )
    return result


class _Integral(sp.Integral):
    __slots__ = ("id_", "unique_id")

    def __new__(cls, *a):
        if len(a) == 2:
            function, (variable, low, high) = a
            id_ = 0
            unique_id = 0
        else:
            function, variable, low, high, id_, unique_id = a
        ii = super().__new__(cls, function, (variable, low, high))
        ii.id_ = id_
        ii.unique_id = unique_id
        return ii

    @property
    def free_symbols(self):
        integrand, (integration_variable, low, high) = self.args
        return integrand.free_symbols | low.free_symbols | high.free_symbols

    def atoms(self, what=None):
        return (
            self.integrand.atoms(what)
            | self.low.atoms(what)
            | self.high.atoms(what)
            | self.integration_variable.atoms(what)
        )

    def func(self, integrand, args):
        (variable, low, high) = args
        unique_id = (
            Hasher()
            .update(integrand.sort_key())
            .update(low.sort_key())
            .update(high.sort_key())
            .update(variable)
            .update(self.id_)
            .hexdigest()
        )

        return _Integral(integrand, variable, low, high, self.id_, unique_id)

    def doit(self):
        return self.func(
            self.integrand.doit(),
            (self.integration_variable, self.low.doit(), self.high.doit()),
        )

    @property
    def integrand(self):
        return self.args[0]

    @property
    def integration_variable(self):
        return self.args[1][0]

    @property
    def low(self):
        return self.args[1][1]

    @property
    def high(self):
        return self.args[1][2]


def get_unique_id_integral(self):
    return self.args[-1]


register(RegistryKeys.UNIQUE_ID, _Integral, get_unique_id_integral)


class Integrand(sp.Expr):
    def __init__(self, expression, integration_variable):
        self.expression = expression
        self.integration_variable = integration_variable

    @property
    def free_symbols(self):
        return self.expression.free_symbols - {self.integration_variable}

    def atoms(self, what=None):
        return self.expression.atoms(what) | self.integration_variable.atoms(what)

    def __getstate__(self):
        return (self.expression, self.integration_variable)

    def __setstate__(self, data):
        self.expression, self.integration_variable = data


IfThenElse = sp.Function("IfThenElse", nargs=3, real=True)


class ERROR(sp.Expr):
    def __new__(clz, message=None):
        # default value None required for unpickling!
        # we can not implement __init__ because sympy does some magick which
        # avoids setting new attributes within __init__
        instance = super().__new__(clz)
        instance.message = message
        return instance

    def __str__(self):
        return 'ERROR("{}")'.format(self.message)

    def __getstate__(self):
        return self.__dict__

    def __setstate__(self, dd):
        self.__dict__.update(dd)


def Checked(expr, message):
    return IfThenElse(expr, expr.lhs, ERROR(message))


class IntegralFunctionWrapper(WrapperBase):
    seen = set()

    @classmethod
    def reset(clz):
        clz.seen = set()

    def __init__(self, name, free_vars, integrand_name, id_):
        self.name = name
        self.free_vars = free_vars
        # self.low = low
        # self.high = high
        self.integrand_name = integrand_name
        self.id_ = id_

    def setup_code_generation(self):
        pass

    def c_header(self):
        args = ", ".join(
            "double {}".format(var) for var in self.free_vars + ["_low", "_high"]
        )

        return "double {name}({args});".format(name=self.name, args=args)

    def cython_code(self, header_file_path):
        return ""

    @concat_generator_results
    def c_code(self, header_file_path):
        curry_class_name, curry_class_code = create_curry_class(len(self.free_vars))

        # don't craeate same currying abstract base class multiple
        # times:
        if curry_class_name not in self.seen:
            self.seen.add(curry_class_name)
            yield curry_class_code

        args = ", ".join(
            "double {}".format(var) for var in self.free_vars + ["_low", "_high"]
        )

        # we insert "_" at beginning of c functions to avoid clash with
        # cython functions:
        cons_args = ", ".join(
            ["_" + self.integrand_name] + list(map(str, self.free_vars))
        )

        yield align(
            """
        |inline double {name}({args}) {{
        |    {curry_class_name} curried_function({cons_args});
        |    return quadpack_integration(&curried_function, "{id_}", _low, _high);
        |}}
        |"""
        ).format(
            name=self.name,
            id_=self.id_,
            # low=self.low,
            # high=self.high,
            args=args,
            curry_class_name=curry_class_name,
            cons_args=cons_args,
        )

    def determine_required_extra_wrappers(self):
        pass
