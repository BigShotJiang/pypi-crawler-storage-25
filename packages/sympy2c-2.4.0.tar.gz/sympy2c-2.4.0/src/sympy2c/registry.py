import pickle
from enum import Enum, auto


class RegistryKeys(Enum):
    UNIQUE_ID = auto()


class Registry:
    def __init__(self):
        self._registry = {}

    def register(self, key, class_, method):
        self._registry[key, class_] = method

    def lookup(self, key, kind):
        if not isinstance(kind, type):
            # instance passed and not class:
            kind = kind.__class__
        return self._registry.get((key, kind))

    def _update(self, other):
        assert isinstance(other, Registry)
        self._registry.update(other._registry)


_registry = Registry()
register = _registry.register
lookup = _registry.lookup

_unique_id_cache = {}


def get_registry():
    return _registry


def get_unique_id(obj):
    method = lookup(RegistryKeys.UNIQUE_ID, obj)
    if method is None:
        raise ValueError(f"no get_unique_id implementation registered for {obj}")
    key = (id(method), pickle.dumps(obj), id(obj))
    if key not in _unique_id_cache:
        _unique_id_cache[key] = method(obj)
    return _unique_id_cache[key]
