from __future__ import annotations

import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .config import JobConfig, load_job_config
from .utils import sha256_file, utc_now_iso, write_json


@dataclass
class BuildResult:
    zip_path: Path
    manifest_path: Path
    manifest: dict[str, Any] = field(default_factory=dict)


def _copy_included_files(project_dir: Path, build_dir: Path, config: JobConfig) -> None:
    for relative in config.build.include:
        src = project_dir / relative
        if not src.exists():
            raise FileNotFoundError(f"Included file not found: {src}")

        dest = build_dir / relative
        dest.parent.mkdir(parents=True, exist_ok=True)

        if src.is_dir():
            shutil.copytree(src, dest, dirs_exist_ok=True)
        else:
            shutil.copy2(src, dest)


def _install_requirements(project_dir: Path, build_dir: Path, config: JobConfig) -> None:
    req_path = project_dir / config.build.requirements
    if not req_path.exists():
        return

    uv = shutil.which("uv")
    if uv:
        cmd = [uv, "pip", "install", "-r", str(req_path), "--target", str(build_dir)]
    else:
        cmd = [sys.executable, "-m", "pip", "install", "-r", str(req_path), "-t", str(build_dir)]

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(
            f"dependency install failed (exit {result.returncode}):\n{result.stderr}"
        )


def validate_project(project_dir: Path) -> JobConfig:
    if not project_dir.exists():
        raise FileNotFoundError(f"Project directory not found: {project_dir}")

    config = load_job_config(project_dir)

    module_name, function_name = config.entrypoint.split(":", 1)
    expected_file = project_dir / f"{module_name}.py"
    if not expected_file.exists():
        raise FileNotFoundError(
            f"Entrypoint module file not found: {expected_file} "
            f"(from entrypoint '{config.entrypoint}')"
        )

    req = project_dir / config.build.requirements
    if req.exists() and not req.is_file():
        raise ValueError(f"Requirements path is not a file: {req}")

    return config


def build_project(project_dir: Path, dist_dir: Path | None = None) -> BuildResult:
    project_dir = project_dir.resolve()
    config = validate_project(project_dir)

    if dist_dir is None:
        dist_dir = project_dir / "dist"
    dist_dir.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="goliath_jobpack_build_") as tmp:
        build_dir = Path(tmp) / "package"
        build_dir.mkdir(parents=True, exist_ok=True)

        _copy_included_files(project_dir, build_dir, config)
        _install_requirements(project_dir, build_dir, config)

        zip_base = dist_dir / config.name
        zip_path = Path(shutil.make_archive(str(zip_base), "zip", root_dir=build_dir))

        manifest = {
            "name": config.name,
            "runtime": config.runtime,
            "entrypoint": config.entrypoint,
            "timeout_seconds": config.timeout_seconds,
            "built_at_utc": utc_now_iso(),
            "zip_filename": zip_path.name,
            "zip_sha256": sha256_file(zip_path),
        }

        manifest_path = dist_dir / f"{config.name}.manifest.json"
        write_json(manifest_path, manifest)

        return BuildResult(
            zip_path=zip_path,
            manifest_path=manifest_path,
            manifest=manifest,
        )