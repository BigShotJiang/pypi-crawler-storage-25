"""Tests for agentshive.memory — memory tag extraction, YAML parsing, and guardrails."""

import pytest
from agentshive.memory import extract_memory_tags


class TestYamlMemoryBlocks:
    """Tests for <<<MEMORY>>>...<<<END_MEMORY>>> YAML parsing."""

    def test_single_save(self):
        text = (
            "Here is my response.\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: project\n"
            "  content: We decided to use WebSocket.\n"
            "<<<END_MEMORY>>>"
        )
        clean, memories, corrections, deletions = extract_memory_tags(text)
        assert "Here is my response." in clean
        assert "<<<MEMORY>>>" not in clean
        assert len(memories) == 1
        assert memories[0]["domain"] == "project"
        assert memories[0]["content"] == "We decided to use WebSocket."
        assert corrections == []
        assert deletions == []

    def test_multiline_content(self):
        text = (
            "Response.\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: self\n"
            "  content: |\n"
            "    Breaking PRDs into user stories first works better.\n"
            "    Estimating without stories leads to underestimation.\n"
            "<<<END_MEMORY>>>"
        )
        clean, memories, _, _ = extract_memory_tags(text)
        assert len(memories) == 1
        assert "Breaking PRDs" in memories[0]["content"]
        assert "underestimation" in memories[0]["content"]

    def test_multiple_operations(self):
        text = (
            "Response.\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: peer\n"
            "  subject: claude-eng\n"
            "  content: Prefers TypeScript.\n"
            "- action: correct\n"
            "  domain: learned\n"
            "  replaces: uses SQLite with WAL mode\n"
            "  content: Uses SQLite with WAL mode and aiosqlite.\n"
            "- action: delete\n"
            "  domain: project\n"
            "  content: Initial plan to use REST\n"
            "<<<END_MEMORY>>>"
        )
        clean, memories, corrections, deletions = extract_memory_tags(text)
        assert len(memories) == 1
        assert len(corrections) == 1
        assert len(deletions) == 1
        assert corrections[0]["replaces"] == "uses SQLite with WAL mode"
        assert deletions[0]["content"] == "Initial plan to use REST"

    def test_memory_wrapper_dict(self):
        text = (
            "Response.\n"
            "<<<MEMORY>>>\n"
            "memory:\n"
            "  - action: save\n"
            "    domain: self\n"
            "    content: Something learned.\n"
            "<<<END_MEMORY>>>"
        )
        _, memories, _, _ = extract_memory_tags(text)
        assert len(memories) == 1
        assert memories[0]["content"] == "Something learned."

    def test_peer_at_prefix_stripped(self):
        text = (
            "Response.\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: peer\n"
            "  subject: '@claude-eng'\n"
            "  content: Prefers TypeScript.\n"
            "<<<END_MEMORY>>>"
        )
        _, memories, _, _ = extract_memory_tags(text)
        assert memories[0]["subject"] == "claude-eng"

    def test_invalid_action_skipped(self):
        text = (
            "Response.\n"
            "<<<MEMORY>>>\n"
            "- action: update\n"
            "  domain: self\n"
            "  content: Invalid.\n"
            "- action: save\n"
            "  domain: self\n"
            "  content: Valid.\n"
            "<<<END_MEMORY>>>"
        )
        _, memories, _, _ = extract_memory_tags(text)
        assert len(memories) == 1
        assert memories[0]["content"] == "Valid."

    def test_invalid_domain_skipped(self):
        text = (
            "Response.\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: personal\n"
            "  content: Invalid domain.\n"
            "<<<END_MEMORY>>>"
        )
        _, memories, _, _ = extract_memory_tags(text)
        assert len(memories) == 0

    def test_invalid_yaml_items_do_not_fall_back_to_legacy(self):
        """When YAML block has no valid memory items, legacy tags are NOT used.

        The parser finds <<<MEMORY>>> blocks and processes them (even if
        they yield zero valid items). Legacy fallback only kicks in when
        there are NO <<<MEMORY>>> blocks at all.
        """
        text = (
            "Response.\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: personal\n"
            "  content: Invalid domain.\n"
            "<<<END_MEMORY>>>\n"
            "---\n"
            "[MEMORY: self | | Legacy memory]"
        )
        _, memories, _, _ = extract_memory_tags(text)
        assert len(memories) == 0

    def test_artifact_blocks_stripped(self):
        text = (
            "Response.\n"
            '<<<ARTIFACT title="Guide" type="markdown">>>\n'
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: learned\n"
            "  content: This should be ignored.\n"
            "<<<END_MEMORY>>>\n"
            "<<<END_ARTIFACT>>>\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: self\n"
            "  content: Real memory.\n"
            "<<<END_MEMORY>>>"
        )
        _, memories, _, _ = extract_memory_tags(text)
        assert len(memories) == 1
        assert memories[0]["content"] == "Real memory."

    def test_clean_text_stripped_of_memory_blocks(self):
        text = (
            "Before.\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: self\n"
            "  content: Note.\n"
            "<<<END_MEMORY>>>\n"
            "After."
        )
        clean, _, _, _ = extract_memory_tags(text)
        assert "<<<MEMORY>>>" not in clean
        assert "Before" in clean
        assert "After" in clean


class TestLegacyFallback:
    """Tests for [MEMORY: ...] tag backward compatibility."""

    def test_no_delimiter_returns_original_text(self):
        text = "Hello world, this is a response."
        clean, memories, _, _ = extract_memory_tags(text)
        assert clean == text
        assert memories == []

    def test_empty_string(self):
        clean, memories, _, _ = extract_memory_tags("")
        assert clean == ""
        assert memories == []

    def test_single_memory_tag(self):
        text = (
            "Here is my response.\n"
            "---\n"
            "[MEMORY: project | my-project | The API uses REST endpoints]"
        )
        clean, memories, _, _ = extract_memory_tags(text)
        assert clean == "Here is my response."
        assert len(memories) == 1
        assert memories[0]["domain"] == "project"
        assert memories[0]["subject"] == "my-project"

    def test_multiple_memory_tags(self):
        text = (
            "Done.\n"
            "---\n"
            "[MEMORY: self | | I prefer concise code reviews]\n"
            "[MEMORY: learned | | Python 3.12 has better error messages]\n"
            "[MEMORY: project | backend | Uses FastAPI with SQLAlchemy]"
        )
        clean, memories, _, _ = extract_memory_tags(text)
        assert clean == "Done."
        assert len(memories) == 3

    def test_delimiter_no_tags_preserves_text(self):
        text = "Some response.\n---\nJust some notes without tags."
        clean, memories, _, _ = extract_memory_tags(text)
        assert clean == text
        assert memories == []

    def test_markdown_hr_not_stripped(self):
        response = (
            "Here's my assessment:\n\n---\n\n**Priority**: High\n\n---\n\nSummary."
        )
        clean, memories, _, _ = extract_memory_tags(response)
        assert clean == response
        assert memories == []

    def test_legacy_corrections(self):
        text = "Done.\n---\n[MEMORY:correct | peer | alice | Alice specializes in Go, not Python]"
        _, memories, corrections, _ = extract_memory_tags(text)
        assert memories == []
        assert len(corrections) == 1
        assert corrections[0]["domain"] == "peer"

    def test_legacy_returns_empty_deletions(self):
        text = "Response.\n---\n[MEMORY: self | | Note]"
        _, _, _, deletions = extract_memory_tags(text)
        assert deletions == []


class TestSubjectiveGuardrail:
    """Peer memories with subjective language should be filtered out."""

    @pytest.mark.parametrize(
        "subjective_word",
        ["slow", "fast", "lazy", "brilliant", "terrible", "great", "mediocre"],
    )
    def test_filters_subjective_adjectives_yaml(self, subjective_word):
        text = (
            "Response.\n"
            "<<<MEMORY>>>\n"
            f"- action: save\n"
            f"  domain: peer\n"
            f"  subject: bob\n"
            f"  content: Bob is {subjective_word} at code reviews.\n"
            "<<<END_MEMORY>>>"
        )
        _, memories, _, _ = extract_memory_tags(text)
        assert memories == []

    @pytest.mark.parametrize(
        "subjective_word",
        ["slow", "fast", "lazy", "brilliant"],
    )
    def test_filters_subjective_adjectives_legacy(self, subjective_word):
        text = f"Done.\n---\n[MEMORY: peer | bob | Bob is {subjective_word} at code reviews]"
        _, memories, _, _ = extract_memory_tags(text)
        assert memories == []

    def test_allows_factual_peer_yaml(self):
        text = (
            "Response.\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: peer\n"
            "  subject: alice\n"
            "  content: Alice specializes in database optimization.\n"
            "<<<END_MEMORY>>>"
        )
        _, memories, _, _ = extract_memory_tags(text)
        assert len(memories) == 1


class TestSelfIdentityGuardrail:
    """Self-identity rewrites should be filtered out."""

    def test_filters_identity_yaml(self):
        text = (
            "Response.\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: self\n"
            "  content: I am a senior engineer.\n"
            "<<<END_MEMORY>>>"
        )
        _, memories, _, _ = extract_memory_tags(text)
        assert memories == []

    def test_allows_non_identity_self_yaml(self):
        text = (
            "Response.\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: self\n"
            "  content: I prefer using pytest over unittest.\n"
            "<<<END_MEMORY>>>"
        )
        _, memories, _, _ = extract_memory_tags(text)
        assert len(memories) == 1


class TestDeleteAction:
    """Tests for action: delete extraction."""

    def test_delete_extracted(self):
        text = (
            "Response.\n"
            "<<<MEMORY>>>\n"
            "- action: delete\n"
            "  domain: project\n"
            "  content: Initial plan to use REST.\n"
            "<<<END_MEMORY>>>"
        )
        _, memories, _, deletions = extract_memory_tags(text)
        assert memories == []
        assert len(deletions) == 1
        assert deletions[0]["domain"] == "project"
        assert deletions[0]["content"] == "Initial plan to use REST."

    def test_delete_no_content_skipped(self):
        text = "Response.\n<<<MEMORY>>>\n- action: delete\n  domain: project\n<<<END_MEMORY>>>"
        _, _, _, deletions = extract_memory_tags(text)
        assert deletions == []


class TestCorrectionWithReplaces:
    """Tests for action: correct with replaces field."""

    def test_correct_with_replaces(self):
        text = (
            "Response.\n"
            "<<<MEMORY>>>\n"
            "- action: correct\n"
            "  domain: learned\n"
            "  replaces: uses SQLite with WAL mode\n"
            "  content: Uses SQLite with WAL mode and aiosqlite.\n"
            "<<<END_MEMORY>>>"
        )
        _, _, corrections, _ = extract_memory_tags(text)
        assert len(corrections) == 1
        assert corrections[0]["replaces"] == "uses SQLite with WAL mode"
        assert "aiosqlite" in corrections[0]["content"]

    def test_correct_without_replaces(self):
        text = (
            "Response.\n"
            "<<<MEMORY>>>\n"
            "- action: correct\n"
            "  domain: self\n"
            "  content: Updated understanding.\n"
            "<<<END_MEMORY>>>"
        )
        _, _, corrections, _ = extract_memory_tags(text)
        assert len(corrections) == 1
        assert "replaces" not in corrections[0]


class TestArtifactBoundaryRespect:
    """Clean-text stripping must not mutate artifact interiors."""

    def test_memory_inside_artifact_preserved_in_clean(self):
        """Memory blocks inside artifacts are part of the artifact content —
        they must be preserved in the clean text, not stripped."""
        text = (
            "Before.\n"
            '<<<ARTIFACT title="Guide" type="markdown">>>\n'
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: learned\n"
            "  content: Example memory inside artifact.\n"
            "<<<END_MEMORY>>>\n"
            "<<<END_ARTIFACT>>>\n"
            "After."
        )
        clean, memories, _, _ = extract_memory_tags(text)
        assert "<<<ARTIFACT" in clean
        assert "<<<MEMORY>>>" in clean
        assert "Example memory inside artifact." in clean
        assert len(memories) == 0

    def test_real_memory_outside_artifact_extracted(self):
        text = (
            '<<<ARTIFACT title="Doc" type="markdown">>>\n'
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: learned\n"
            "  content: Inside artifact.\n"
            "<<<END_MEMORY>>>\n"
            "<<<END_ARTIFACT>>>\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: self\n"
            "  content: Real memory.\n"
            "<<<END_MEMORY>>>"
        )
        _, memories, _, _ = extract_memory_tags(text)
        assert len(memories) == 1
        assert memories[0]["content"] == "Real memory."

    def test_memory_between_artifacts_stripped_from_clean(self):
        """Memory blocks between artifacts are stripped, artifact interiors preserved."""
        text = (
            '<<<ARTIFACT title="A" type="markdown">>>\n'
            "Artifact content.\n"
            "<<<END_ARTIFACT>>>\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: self\n"
            "  content: Between artifacts.\n"
            "<<<END_MEMORY>>>\n"
            '<<<ARTIFACT title="B" type="markdown">>>\n'
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: learned\n"
            "  content: Inside second artifact.\n"
            "<<<END_MEMORY>>>\n"
            "<<<END_ARTIFACT>>>"
        )
        clean, memories, _, _ = extract_memory_tags(text)
        assert len(memories) == 1
        assert memories[0]["content"] == "Between artifacts."
        assert "Inside second artifact." not in memories[0]["content"]
        assert "Between artifacts." not in clean
        assert "Inside second artifact." in clean


class TestEdgeCases:
    """Edge cases and robustness."""

    def test_unterminated_memory_block(self):
        text = (
            "Response.\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: self\n"
            "  content: This block has no end.\n"
        )
        clean, memories, _, _ = extract_memory_tags(text)
        assert "<<<MEMORY>>>" in clean
        assert len(memories) == 0

    def test_multiple_separate_memory_blocks(self):
        text = (
            "Part 1.\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: self\n"
            "  content: First memory.\n"
            "<<<END_MEMORY>>>\n"
            "Part 2.\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: learned\n"
            "  content: Second memory.\n"
            "<<<END_MEMORY>>>\n"
            "Part 3."
        )
        clean, memories, _, _ = extract_memory_tags(text)
        assert len(memories) == 2
        assert "Part 1" in clean
        assert "Part 2" in clean
        assert "Part 3" in clean
        assert "<<<MEMORY>>>" not in clean

    def test_empty_content_skipped(self):
        text = (
            "Response.\n"
            "<<<MEMORY>>>\n"
            "- action: save\n"
            "  domain: self\n"
            "  content: ''\n"
            "- action: save\n"
            "  domain: learned\n"
            "  content: Valid content.\n"
            "<<<END_MEMORY>>>"
        )
        _, memories, _, _ = extract_memory_tags(text)
        assert len(memories) == 1
        assert memories[0]["content"] == "Valid content."


class TestLegacyPeerAtStripping:
    """Legacy path should strip @ from peer subjects, matching YAML path."""

    def test_legacy_peer_at_stripped(self):
        text = "Response.\n---\n[MEMORY: peer | @claude-eng | Prefers TypeScript]"
        _, memories, _, _ = extract_memory_tags(text)
        assert len(memories) == 1
        assert memories[0]["subject"] == "claude-eng"

    def test_legacy_correction_peer_at_stripped(self):
        text = "Response.\n---\n[MEMORY:correct | peer | @claude-eng | Updated fact]"
        _, _, corrections, _ = extract_memory_tags(text)
        assert len(corrections) == 1
        assert corrections[0]["subject"] == "claude-eng"

    def test_stray_memory_start_does_not_suppress_legacy(self):
        """A stray <<<MEMORY>>> in prose (no END) should not block legacy fallback."""
        text = (
            "Response mentioning <<<MEMORY>>> as a concept.\n"
            "---\n[MEMORY: self | | Real legacy memory]"
        )
        _, memories, _, _ = extract_memory_tags(text)
        assert len(memories) == 1
        assert memories[0]["content"] == "Real legacy memory"
