"""REST client for the AgentsHive server API."""

from __future__ import annotations

import json
import logging
import mimetypes
from pathlib import Path
from typing import Any

import httpx

from agentshive.backends.base import MEDIA_EXTENSIONS
from agentshive.models import Message

logger = logging.getLogger(__name__)


class AgentsHiveAPIError(Exception):
    """Raised for any non-2xx response or transport error from the AgentsHive API.

    Attributes:
        status_code: HTTP status (``None`` if the request never reached the server).
        method: HTTP method of the failing request.
        path: Request path (relative to the server base URL).
        body: Response body text, truncated to 1 KiB (``""`` on transport error).
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None,
        method: str,
        path: str,
        body: str = "",
    ):
        super().__init__(message)
        self.status_code = status_code
        self.method = method
        self.path = path
        self.body = body


def _raise_for_response(resp: httpx.Response, method: str, path: str) -> None:
    """Validate a response; raise :class:`AgentsHiveAPIError` on non-2xx."""
    if 200 <= resp.status_code < 300:
        return
    body = resp.text[:1024] if resp.content else ""
    raise AgentsHiveAPIError(
        f"{method} {path} -> {resp.status_code}: {body}",
        status_code=resp.status_code,
        method=method,
        path=path,
        body=body,
    )


# Fallback MIME types for extensions that mimetypes may not know.
_MIME_FALLBACK = {
    ".apng": "image/apng",
    ".avif": "image/avif",
    ".heic": "image/heic",
    ".heif": "image/heif",
    ".mp4": "video/mp4",
    ".webm": "video/webm",
    ".mov": "video/quicktime",
    ".avi": "video/x-msvideo",
    ".mkv": "video/x-matroska",
}


def _mime_from_ext(ext: str) -> str:
    """Derive MIME type from extension. Only allows extensions in IMAGE_EXTENSIONS."""
    if ext not in MEDIA_EXTENSIONS:
        return "application/octet-stream"
    mime, _ = mimetypes.guess_type(f"file{ext}")
    return mime or _MIME_FALLBACK.get(ext, "application/octet-stream")


class AgentAPI:
    """Async REST client for the AgentsHive server API.

    Used internally by :class:`~agenthive.client.BackendClient` and also
    available directly via ``client.api`` for custom API calls.
    """

    def __init__(self, server_url: str, token: str):
        """Create a new API client.

        Args:
            server_url: Base URL of the AgentsHive server.
            token: Backend machine token (``ahv_...``).
        """
        self._base = server_url.rstrip("/")
        self._headers = {"Authorization": f"Bearer {token}"}
        self._client = httpx.AsyncClient(
            base_url=self._base, headers=self._headers, timeout=30.0
        )

    async def close(self):
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | list[Any] | None = None,
        data: dict[str, Any] | None = None,
        files: list[Any] | None = None,
        timeout: float | None = None,
    ) -> httpx.Response:
        """Issue an HTTP request. Raises :class:`AgentsHiveAPIError` on non-2xx
        responses or transport errors. Only the listed kwargs are forwarded to
        httpx — callers cannot override auth, base URL, or other client state.
        """
        logger.debug("API %s %s", method, path)
        try:
            resp = await self._client.request(
                method,
                path,
                params=params,
                json=json,
                data=data,
                files=files,
                timeout=timeout if timeout is not None else self._client.timeout,
            )
        except httpx.HTTPError as e:
            raise AgentsHiveAPIError(
                f"{method} {path} failed: {e.__class__.__name__}: {e}",
                status_code=None,
                method=method,
                path=path,
            ) from e
        logger.debug(
            "API %s %s -> %d (%d bytes)",
            method,
            path,
            resp.status_code,
            len(resp.content),
        )
        _raise_for_response(resp, method, path)
        return resp

    async def get_me(self) -> dict:
        """Return the authenticated backend machine's metadata."""
        resp = await self._request("GET", "/api/backends/me")
        return resp.json()

    async def get_tasks(self, status: str = "queued") -> list[dict]:
        """List tasks assigned to this backend, filtered by status."""
        resp = await self._request(
            "GET", "/api/backends/me/tasks", params={"status": status}
        )
        return resp.json()

    async def ack_task(self, task_id: str) -> dict:
        """Acknowledge a task (transition from queued to processing)."""
        resp = await self._request("POST", f"/api/backends/me/tasks/{task_id}/ack")
        return resp.json()

    async def complete_task(self, task_id: str) -> dict:
        """Mark a task as successfully completed."""
        resp = await self._request("POST", f"/api/backends/me/tasks/{task_id}/complete")
        return resp.json()

    async def fail_task(self, task_id: str, error: str = "") -> dict:
        """Mark a task as failed with an optional error message."""
        resp = await self._request(
            "POST", f"/api/backends/me/tasks/{task_id}/fail", json={"error": error}
        )
        return resp.json()

    async def get_messages(
        self, thread_id: str, limit: int = 50, after: str | None = None
    ) -> list[Message]:
        """Fetch messages from a thread, most recent last.

        Args:
            thread_id: Thread to fetch messages from.
            limit: Maximum number of messages to return.
            after: Only return messages created after this message ID.
        """
        params = {}
        if after:
            params["after"] = after
        resp = await self._request(
            "GET", f"/api/threads/{thread_id}/messages", params=params
        )
        return [Message.from_dict(m, api=self) for m in resp.json()[-limit:]]

    async def get_attachment_bytes(self, attachment_id: str) -> bytes:
        """Download attachment file bytes via the backend-token endpoint.

        Uses /api/backends/me/attachments/{id} which is scoped to backends
        that have an agent in the attachment's thread space.
        """
        resp = await self._request(
            "GET", f"/api/backends/me/attachments/{attachment_id}"
        )
        return resp.content

    async def post_message(
        self,
        thread_id: str,
        text: str,
        agent_handle: str = "",
        mentions: list[str] | None = None,
        quoted_message_id: str | None = None,
        task_id: str | None = None,
    ) -> Message | None:
        """Post a message to a thread on behalf of an agent.

        Args:
            thread_id: Target thread.
            text: Message body (supports markdown).
            agent_handle: The agent posting this message.
            mentions: Explicit @mentions to include (triggers those agents).
            quoted_message_id: ID of a message to quote.
            task_id: The dispatch task this reply is for (links message to batch).
        """
        data = {"text": text}
        if agent_handle:
            data["agent_handle"] = agent_handle
        if mentions:
            data["explicit_mentions"] = json.dumps(mentions)
        if quoted_message_id:
            data["quoted_message_id"] = quoted_message_id
        if task_id:
            data["task_id"] = task_id
        resp = await self._request(
            "POST", f"/api/threads/{thread_id}/messages", data=data
        )
        body = resp.json()
        # Server may filter non-substantive agent replies (soft-PASSes)
        if body.get("filtered"):
            return None
        return Message.from_dict(body, api=self)

    async def post_message_with_files(
        self,
        thread_id: str,
        text: str,
        file_paths: list[str],
        agent_handle: str = "",
        mentions: list[str] | None = None,
        quoted_message_id: str | None = None,
        task_id: str | None = None,
    ) -> Message | None:
        """Post a message with file attachments (multipart upload).

        Args:
            thread_id: Target thread.
            text: Message body.
            file_paths: Local file paths to upload as attachments.
            agent_handle: The agent posting this message.
            mentions: Explicit @mentions to include.
            quoted_message_id: ID of a message to quote.
            task_id: The dispatch task this reply is for.
        """
        data = {"text": text}
        if agent_handle:
            data["agent_handle"] = agent_handle
        if mentions:
            data["explicit_mentions"] = json.dumps(mentions)
        if quoted_message_id:
            data["quoted_message_id"] = quoted_message_id
        if task_id:
            data["task_id"] = task_id

        files = []
        open_handles = []
        try:
            for fp in file_paths:
                p = Path(fp)
                if not p.exists():
                    logger.warning("Skipping missing file: %s", fp)
                    continue
                fh = open(p, "rb")  # noqa: SIM115
                open_handles.append(fh)
                # httpx expects (field_name, (filename, file_obj, content_type))
                mime = _mime_from_ext(p.suffix.lower())
                files.append(("files", (p.name, fh, mime)))

            resp = await self._request(
                "POST",
                f"/api/threads/{thread_id}/messages",
                data=data,
                files=files,
                timeout=60.0,
            )
            body = resp.json()
            if body.get("filtered"):
                return None
            return Message.from_dict(body, api=self)
        finally:
            for fh in open_handles:
                fh.close()

    # ------------------------------------------------------------------
    # Memory endpoints
    # ------------------------------------------------------------------

    async def save_memories(
        self,
        memories: list[dict],
        space_id: str = "",
        thread_id: str = "",
        agent_handle: str = "",
        corrections: list[dict] | None = None,
        deletions: list[dict] | None = None,
        participants: list[str] | None = None,
    ) -> dict:
        """Persist extracted memories, corrections, and deletions to the server."""
        logger.info(
            "Saving %d memories, %d corrections, %d deletions for @%s",
            len(memories),
            len(corrections or []),
            len(deletions or []),
            agent_handle,
        )
        body: dict = {
            "memories": memories,
            "space_id": space_id,
            "thread_id": thread_id,
        }
        if agent_handle:
            body["agent_handle"] = agent_handle
        if corrections:
            body["corrections"] = corrections
        if deletions:
            body["deletions"] = deletions
        if participants:
            body["participants"] = participants
        resp = await self._request("POST", "/api/backends/me/memories", json=body)
        return resp.json()

    async def get_memory_context(
        self,
        space_id: str = "",
        participants: list[str] | None = None,
        agent_handle: str = "",
        recent_context: str = "",
    ) -> tuple[str, str]:
        """Fetch formatted memory context and project rules for prompt injection.

        When recent_context is provided (recent message text), the server
        uses LLM-based relevance scoring to select the most pertinent
        memories instead of greedy priority fill.

        Returns:
            (memory_context, space_rules) tuple.
        """
        logger.info(
            "Fetching memory context for @%s (space=%s)", agent_handle, space_id[:8]
        )
        body: dict[str, str | list[str]] = {"space_id": space_id}
        if participants:
            body["participants"] = participants
        if agent_handle:
            body["agent_handle"] = agent_handle
        if recent_context:
            body["recent_context"] = recent_context[:3000]
        resp = await self._request(
            "POST", "/api/backends/me/memories/context", json=body
        )
        data = resp.json()
        return data.get("context", ""), data.get("space_rules", "")

    # ------------------------------------------------------------------
    # Artifact endpoints
    # ------------------------------------------------------------------

    async def list_artifacts(self, thread_id: str) -> list[dict]:
        """List artifacts in a thread."""
        resp = await self._request("GET", f"/api/threads/{thread_id}/artifacts")
        return resp.json()

    async def create_artifact(
        self,
        thread_id: str,
        title: str,
        content: str,
        content_type: str = "markdown",
        *,
        author_handle: str = "",
        author_display_name: str = "",
        message_id: str | None = None,
        status: str = "draft",
    ) -> dict:
        """Create an artifact in a thread.

        Args:
            thread_id: Thread to attach the artifact to.
            title: Display title.
            content: Artifact body.
            content_type: One of markdown, code, html, mermaid.
            author_handle: Agent handle creating this artifact.
            author_display_name: Agent display name.
            message_id: Optional message to link the artifact to.
            status: draft or published.
        """
        body = {
            "thread_id": thread_id,
            "title": title,
            "content": content,
            "content_type": content_type,
            "author_handle": author_handle,
            "author_display_name": author_display_name,
            "status": status,
        }
        if message_id:
            body["message_id"] = message_id
        resp = await self._request("POST", "/api/artifacts", json=body)
        return resp.json()

    async def update_artifact(
        self,
        artifact_id: str,
        content: str,
        *,
        author_handle: str = "",
        summary: str = "",
    ) -> dict:
        """Update an artifact's content (creates a new version).

        Args:
            artifact_id: Artifact to update.
            content: New content.
            author_handle: Agent handle making the update.
            summary: Optional change summary.
        """
        body = {
            "content": content,
            "author_handle": author_handle,
            "summary": summary,
        }
        resp = await self._request("PUT", f"/api/artifacts/{artifact_id}", json=body)
        return resp.json()

    async def create_artifact_comment(
        self,
        artifact_id: str,
        text: str,
        *,
        author_handle: str = "",
        author_display_name: str = "",
        role: str = "agent",
    ) -> dict:
        """Add a comment to an artifact.

        Args:
            artifact_id: Artifact to comment on.
            text: Comment text (supports @mentions).
            author_handle: Agent handle posting the comment.
            author_display_name: Agent display name.
            role: Comment role (agent or human).
        """
        body = {
            "text": text,
            "author_handle": author_handle,
            "author_display_name": author_display_name,
            "role": role,
        }
        resp = await self._request(
            "POST", f"/api/artifacts/{artifact_id}/comments", json=body
        )
        return resp.json()

    # ------------------------------------------------------------------
    # Stats endpoint
    # ------------------------------------------------------------------

    async def report_stats(self, stats: dict) -> dict:
        """Report token usage / invocation stats to the server."""
        logger.info(
            "Reporting stats: %d input, %d output tokens",
            stats.get("input_tokens", 0),
            stats.get("output_tokens", 0),
        )
        resp = await self._request("POST", "/api/backends/me/stats", json=stats)
        return resp.json()
