"""Memory tag extraction from agent responses.

Supports two formats:
1. YAML blocks wrapped in <<<MEMORY>>>...<<<END_MEMORY>>> sentinels (preferred)
2. Legacy [MEMORY: domain | subject | content] tags after --- delimiter (fallback)
"""

from __future__ import annotations

import logging
import re

import yaml

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Sentinel pattern for YAML memory blocks
# ---------------------------------------------------------------------------

_MEMORY_START = "<<<MEMORY>>>"
_MEMORY_END = "<<<END_MEMORY>>>"
_ARTIFACT_RE = re.compile(r"<<<ARTIFACT\b.*?<<<END_ARTIFACT>>>", re.DOTALL)

# ---------------------------------------------------------------------------
# Legacy regex patterns (backward compatibility)
# ---------------------------------------------------------------------------

MEMORY_DELIMITER = "\n---\n"

MEMORY_TAG_RE = re.compile(
    r"^\[MEMORY:\s*(self|peer|project|learned)\s*\|\s*([^|]*?)\s*\|\s*(.+?)\s*\]$",
    re.MULTILINE,
)

CORRECTION_TAG_RE = re.compile(
    r"^\[MEMORY:correct\s*\|\s*(self|peer|project|learned)\s*\|\s*([^|]*?)\s*\|\s*(.+?)\s*\]$",
    re.MULTILINE,
)

SUBJECTIVE_PATTERNS = [
    re.compile(
        r"\b(slow|fast|bad|good|terrible|great|lazy|brilliant|mediocre|incompetent|careless|sloppy|unreliable|difficult)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(tends to|always|never|usually|often fails|struggles with|not great at|needs hand-holding)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(overcomplicates|over-engineers|too (slow|verbose|aggressive|cautious)|doesn't listen|hard to work with)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(worst|best|most annoying|frustrating|disappointing|impressive)\b",
        re.IGNORECASE,
    ),
]

SELF_IDENTITY_KEYWORDS = ("i am a", "my role is", "i'm a")

VALID_ACTIONS = {"save", "correct", "delete"}
VALID_DOMAINS = {"self", "peer", "project", "learned"}


def _strip_artifact_blocks(text: str) -> str:
    """Remove <<<ARTIFACT...>>>...<<<END_ARTIFACT>>> blocks from text."""
    return _ARTIFACT_RE.sub("", text)


def _passes_guardrails(domain: str, content: str) -> bool:
    """Return True if the memory passes guardrail checks."""
    if domain == "peer" and any(p.search(content) for p in SUBJECTIVE_PATTERNS):
        logger.debug("Filtered subjective peer memory: %s", content[:80])
        return False
    if domain == "self" and any(kw in content.lower() for kw in SELF_IDENTITY_KEYWORDS):
        logger.debug("Filtered self-identity memory: %s", content[:80])
        return False
    return True


def _strip_memory_blocks(text: str) -> str:
    """Remove <<<MEMORY>>>...<<<END_MEMORY>>> blocks, respecting artifact spans."""
    parts = []
    last = 0
    for m in _ARTIFACT_RE.finditer(text):
        region = text[last : m.start()]
        parts.append(_do_strip_memory_blocks(region))
        parts.append(m.group())
        last = m.end()
    parts.append(_do_strip_memory_blocks(text[last:]))
    return "".join(parts)


def _do_strip_memory_blocks(text: str) -> str:
    """Remove <<<MEMORY>>>...<<<END_MEMORY>>> blocks from text."""
    result = []
    i = 0
    while i < len(text):
        start = text.find(_MEMORY_START, i)
        if start == -1:
            result.append(text[i:])
            break
        result.append(text[i:start])
        end = text.find(_MEMORY_END, start)
        if end == -1:
            result.append(text[start:])
            break
        i = end + len(_MEMORY_END)
    return "".join(result).rstrip()


def _parse_yaml_block(yaml_text: str) -> list[dict]:
    """Parse a YAML memory block into a list of memory dicts.

    Handles both bare-list and memory:-wrapped dict format.
    Returns list of valid items; invalid items are skipped with a warning.
    """
    try:
        data = yaml.safe_load(yaml_text)
    except yaml.YAMLError as e:
        logger.warning("Failed to parse YAML memory block: %s", e)
        return []

    if isinstance(data, dict) and "memory" in data:
        data = data["memory"]

    if not isinstance(data, list):
        logger.warning("YAML memory block root is not a list: %s", type(data).__name__)
        return []

    items = []
    for entry in data:
        if not isinstance(entry, dict):
            logger.warning("Skipping non-dict memory entry: %s", entry)
            continue

        action = entry.get("action", "")
        domain = entry.get("domain", "")

        if action not in VALID_ACTIONS:
            logger.warning("Skipping memory entry with invalid action '%s'", action)
            continue
        if domain not in VALID_DOMAINS:
            logger.warning("Skipping memory entry with invalid domain '%s'", domain)
            continue

        subject = entry.get("subject")
        if subject and domain == "peer":
            subject = str(subject).lstrip("@") or None

        item: dict = {"action": action, "domain": domain}
        if subject:
            item["subject"] = subject

        content = entry.get("content")
        if content is not None:
            item["content"] = str(content).strip()

        replaces = entry.get("replaces")
        if replaces:
            item["replaces"] = str(replaces).strip()

        items.append(item)

    return items


def _apply_guardrails(items: list[dict]) -> tuple[list[dict], list[dict], list[dict]]:
    """Route items by action and apply guardrails.

    Returns (memories, corrections, deletions).
    """
    memories = []
    corrections = []
    deletions = []

    for item in items:
        action = item["action"]
        domain = item["domain"]
        content = item.get("content", "")

        if action == "delete":
            if content:
                deletions.append(
                    {
                        "domain": domain,
                        "subject": item.get("subject"),
                        "content": content,
                    }
                )
            continue

        if action == "correct":
            if content:
                corr = {
                    "domain": domain,
                    "subject": item.get("subject"),
                    "content": content,
                }
                if item.get("replaces"):
                    corr["replaces"] = item["replaces"]
                corrections.append(corr)
            continue

        if not _passes_guardrails(domain, content):
            continue

        if content:
            memories.append(
                {"domain": domain, "subject": item.get("subject"), "content": content}
            )

    return memories, corrections, deletions


def _extract_legacy(text: str) -> tuple[str, list[dict], list[dict]]:
    """Extract legacy [MEMORY: ...] tags after --- delimiter.

    Returns (clean_text, memories, corrections).
    """
    delimiter_pos = text.rfind(MEMORY_DELIMITER)
    if delimiter_pos == -1:
        return text, [], []

    suffix = text[delimiter_pos + len(MEMORY_DELIMITER) :]

    if not MEMORY_TAG_RE.search(suffix) and not CORRECTION_TAG_RE.search(suffix):
        return text, [], []

    body = text[:delimiter_pos].rstrip()
    memories = []
    corrections = []

    for match in CORRECTION_TAG_RE.finditer(suffix):
        domain = match.group(1)
        subject = match.group(2).strip().lstrip("@") or None
        content = match.group(3).strip()
        corrections.append({"domain": domain, "subject": subject, "content": content})

    for match in MEMORY_TAG_RE.finditer(suffix):
        domain = match.group(1)
        subject = match.group(2).strip().lstrip("@") or None
        content = match.group(3).strip()

        if not _passes_guardrails(domain, content):
            continue

        memories.append({"domain": domain, "subject": subject, "content": content})

    return body, memories, corrections


def extract_memory_tags(
    response_text: str,
) -> tuple[str, list[dict], list[dict], list[dict]]:
    """Extract memory operations from agent response.

    Parses <<<MEMORY>>>...<<<END_MEMORY>>> YAML blocks first.
    Falls back to legacy [MEMORY: ...] tags if no YAML blocks found.

    Returns:
        (clean_response_text, memories, corrections, deletions).
        Each dict has keys: domain, subject, content.
        Correction dicts may also have 'replaces'.
    """
    stripped = _strip_artifact_blocks(response_text)

    has_yaml_blocks = _MEMORY_START in stripped and _MEMORY_END in stripped
    if not has_yaml_blocks:
        clean, mems, corrs = _extract_legacy(response_text)
        return clean, mems, corrs, []

    items = []
    remaining = stripped
    while _MEMORY_START in remaining:
        start = remaining.find(_MEMORY_START)
        end = remaining.find(_MEMORY_END, start)
        if end == -1:
            break
        yaml_text = remaining[start + len(_MEMORY_START) : end].strip()
        items.extend(_parse_yaml_block(yaml_text))
        remaining = remaining[end + len(_MEMORY_END) :]

    memories, corrections, deletions = _apply_guardrails(items)

    clean = _strip_memory_blocks(response_text)

    return clean.rstrip(), memories, corrections, deletions
