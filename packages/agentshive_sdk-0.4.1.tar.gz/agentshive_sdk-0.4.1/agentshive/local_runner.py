"""Local runner: wraps CLI backends as remote agents via the AgentsHive SDK.

Connects as a backend machine (one token for all agents), discovers its
assigned agents from ``GET /api/backends/me``, and routes incoming tasks
to the appropriate CLI based on the ``backend`` field.

Usage:
    python3 -m agenthive.local_runner \
        --server http://localhost:8000 \
        --token ahv_... \
        --repo-path /path/to/repo \
        --timeout 300
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import re
import tempfile

from agentshive import BackendClient, Message
from agentshive.backends import create_backend, list_available
from agentshive.memory import extract_memory_tags
from agentshive.rate_limit import (
    BASE_DELAY_S,
    MAX_RETRIES,
    RateLimitError,
    is_truncated,
)

logger = logging.getLogger(__name__)

_ARTIFACT_UPDATE_RE = re.compile(
    r"<<<ARTIFACT_UPDATE>>>\s*\n(.*?)\n\s*<<<END_ARTIFACT_UPDATE>>>",
    re.DOTALL,
)

_ARTIFACT_RE = re.compile(
    r'<<<ARTIFACT\s+title="([^"]+)"(?:\s+type="([^"]*)")?\s*>>>\s*\n(.*?)\n\s*<<<END_ARTIFACT>>>',
    re.DOTALL,
)

# Attachment filename sanitisation for local temp files.
_SAFE_ATT_NAME_RE = re.compile(r"[^A-Za-z0-9._-]")


def _safe_attachment_name(name: str) -> str:
    cleaned = _SAFE_ATT_NAME_RE.sub("_", (name or "").strip())
    cleaned = cleaned[:120]
    return cleaned or "file"


# Attachments are cached in a single shared directory, not per-task, so the
# local paths rendered into the prompt on turn 1 are still valid when the
# same session resumes on turn N. Pruning is age-based, and `_touch_cached`
# bumps mtime on every reference so an active session keeps its files alive.
_ATTACHMENT_CACHE_SUBDIR = "agentshive_att"
_ATTACHMENT_CACHE_MAX_AGE_S = 24 * 60 * 60  # 24h of idleness; mtime-bumped on use


def _attachment_cache_dir() -> str:
    """Return the shared on-disk cache directory for attachments.

    The directory itself is created lazily in :func:`_download_attachments`
    only when something is about to be written — threads with no attachments
    leave no trace under ``$TMPDIR``.
    """
    return os.path.join(tempfile.gettempdir(), _ATTACHMENT_CACHE_SUBDIR)


def _prune_stale_attachments() -> None:
    """Remove cached attachment files whose mtime is older than the TTL.

    Called at the start of every task run. No-op when the cache directory
    does not exist (no attachments have been downloaded yet). Files in use
    by active sessions are kept alive by :func:`_touch_cached` bumping
    their mtime on every cache hit, so pruning only catches files that
    have been idle for the full TTL window.
    """
    import time

    cache_dir = _attachment_cache_dir()
    if not os.path.isdir(cache_dir):
        return
    cutoff = time.time() - _ATTACHMENT_CACHE_MAX_AGE_S
    try:
        entries = os.listdir(cache_dir)
    except OSError:
        return
    for name in entries:
        path = os.path.join(cache_dir, name)
        try:
            if os.path.getmtime(path) < cutoff:
                os.remove(path)
        except OSError:
            pass


def _touch_cached(path: str) -> None:
    """Bump mtime on a cached attachment so the pruner treats it as fresh."""
    try:
        os.utime(path, None)
    except OSError:
        pass


def _is_valid_cached_file(local: str, expected_size: int) -> bool:
    """Return True if ``local`` is a usable cached copy for an attachment.

    When the caller knows ``expected_size`` (from ``Attachment.size_bytes``
    populated by the server), the cached file must match it exactly. This
    catches both truncated files left behind by a crashed writer and any
    out-of-band tampering at the cache path.

    When ``expected_size`` is 0 (legacy payloads that don't carry a size)
    we fall back to the weaker "non-empty" check. That is still safe in
    practice because all fresh SDK writes go through :func:`_atomic_write`,
    so anything at the cache path was either written completely by this
    SDK or pre-existed from before the size was known.
    """
    try:
        actual = os.path.getsize(local)
    except OSError:
        return False
    if expected_size > 0:
        return actual == expected_size
    return actual > 0


def _atomic_write(local: str, data: bytes) -> None:
    """Write ``data`` to ``local`` atomically.

    Streams into a sibling temp file and then ``os.replace``s it into the
    final path. If anything goes wrong in the middle (disk full, SIGKILL,
    concurrent writer crash), the cache path is either absent or contains
    the previous complete version — never a truncated half-written file.
    The temp file is unlinked on any failure.
    """
    cache_dir = os.path.dirname(local)
    os.makedirs(cache_dir, exist_ok=True)
    tmp_fd, tmp_path = tempfile.mkstemp(
        prefix=f".{os.path.basename(local)}.",
        suffix=".partial",
        dir=cache_dir,
    )
    try:
        with os.fdopen(tmp_fd, "wb") as fh:
            fh.write(data)
        os.replace(tmp_path, local)
    except BaseException:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


async def _download_attachments(
    messages: list[Message],
    api,
) -> dict[str, str]:
    """Ensure every attachment on ``messages`` is present in the local cache.

    Returns a mapping ``{attachment_id: absolute_local_path}``. Files live at
    a stable per-id path under :func:`_attachment_cache_dir` so:

    * Successive tasks in the same session resolve to the same filesystem
      path — Claude can still Read files it was shown on earlier turns.
    * Cache hits skip the HTTP fetch entirely. A follow-up task that does
      not introduce new attachments only pays O(n) ``stat`` calls, not
      O(n * file_size) backend I/O.
    * Cache validity is verified against the server-provided
      ``size_bytes`` when available; a mismatched file (truncated by a
      crashed writer, tampered, or otherwise corrupted) is re-fetched.

    Writes are atomic (see :func:`_atomic_write`), so the cache path
    never holds a partial file that a future run could trust.

    The cache directory is created lazily on the first write, so threads
    with no attachments leave no trace. Attachments that fail to download
    are omitted from the mapping — the prompt renderer records that their
    content is unavailable.
    """
    cache_dir = _attachment_cache_dir()
    paths: dict[str, str] = {}
    for m in messages:
        for a in m.attachments or []:
            if not a.id or a.id in paths:
                continue
            local = os.path.abspath(
                os.path.join(cache_dir, f"{a.id}_{_safe_attachment_name(a.filename)}")
            )
            expected_size = getattr(a, "size_bytes", 0) or 0
            if os.path.exists(local):
                if _is_valid_cached_file(local, expected_size):
                    _touch_cached(local)
                    paths[a.id] = local
                    continue
                logger.warning(
                    "[attachment] cache file %s failed validation (expected_size=%d), re-fetching",
                    local,
                    expected_size,
                )
            try:
                data = await api.get_attachment_bytes(a.id)
                if expected_size > 0 and len(data) != expected_size:
                    logger.warning(
                        "[attachment] server returned %d bytes for id=%s but "
                        "metadata said %d; writing what we got",
                        len(data),
                        a.id,
                        expected_size,
                    )
                _atomic_write(local, data)
                paths[a.id] = local
                logger.info(
                    "[attachment] downloaded %s (%d bytes) -> %s",
                    a.filename,
                    len(data),
                    local,
                )
            except Exception as exc:
                logger.warning(
                    "[attachment] failed to download id=%s filename=%s: %s",
                    a.id,
                    a.filename,
                    exc,
                )
    return paths


def _extract_artifacts(text: str) -> tuple[str, list[dict]]:
    """Extract <<<ARTIFACT>>> blocks from agent response, return (chat_text, artifacts)."""
    artifacts = []
    for match in _ARTIFACT_RE.finditer(text):
        artifacts.append(
            {
                "title": match.group(1),
                "content": match.group(3).strip(),
                "content_type": match.group(2) or "markdown",
            }
        )
    chat_text = _ARTIFACT_RE.sub("", text).strip()
    return chat_text, artifacts


def _extract_artifact_update(text: str) -> tuple[str, str | None, str | None]:
    """Extract <<<ARTIFACT_UPDATE>>> block from agent response.

    Returns (comment_text, update_content, update_summary).
    """
    match = _ARTIFACT_UPDATE_RE.search(text)
    if not match:
        return text.strip(), None, None
    update_block = match.group(1).strip()
    lines = update_block.split("\n", 1)
    summary = ""
    content = update_block
    if lines[0].lower().startswith("summary"):
        _, _, after = lines[0].partition(":")
        summary = after.strip()
        content = lines[1].strip() if len(lines) > 1 else ""
    comment = _ARTIFACT_UPDATE_RE.sub("", text).strip()
    return comment, content or None, summary or None


def build_artifact_review_prompt(
    agent_handle: str,
    system_instruction: str,
    artifact_context: dict,
    *,
    memory_context: str = "",
    space_rules: str = "",
) -> str:
    """Build a prompt for artifact review tasks."""
    ctx = artifact_context
    lines = [
        f"You are @{agent_handle} reviewing an artifact in a multi-agent chatroom.",
        "",
        system_instruction,
        "",
        f"Space: #{ctx.get('space_name', '')} — {ctx.get('space_description', '')}",
    ]

    if space_rules:
        lines.append(f"Project Rules:\n{space_rules}")

    lines.extend(
        [
            f'Artifact: "{ctx.get("title", "")}" (type: {ctx.get("content_type", "")}, by @{ctx.get("author_handle", "")})',
            "",
            "You have been notified about activity on this artifact. You MUST respond.",
            "",
            f"== ARTIFACT CONTENT (version {ctx.get('version', 1)}) ==",
            ctx.get("content", ""),
            "== END ARTIFACT CONTENT ==",
            "",
            "== COMMENTS ==",
        ]
    )

    comments = ctx.get("comments", [])
    if comments:
        for c in comments:
            lines.append(f"@{c['author_handle']}: {c['text']}")
    else:
        lines.append("(none)")

    status_ctx = ctx.get("status_context")
    if status_ctx:
        lines.extend(
            [
                "",
                "== STATUS CHANGE ==",
                f"{status_ctx.get('caller_display_name', 'Someone')} has performed "
                f"'{status_ctx.get('verb', 'changed status')}' on this artifact "
                f"(new status: {status_ctx.get('new_status', 'unknown')}). "
                "Please review and respond.",
                "== END STATUS CHANGE ==",
            ]
        )

    lines.extend(
        [
            "",
            "== END COMMENTS ==",
            "",
            "Instructions:",
            "- Reply with a comment on the artifact. Be specific and reference parts of the content.",
            "- If the artifact should be updated, wrap the new version in:",
            "  <<<ARTIFACT_UPDATE>>>",
            "  Summary: brief description of changes",
            "  (new content here)",
            "  <<<END_ARTIFACT_UPDATE>>>",
            "- If no update is needed, just reply with your comment.",
            "- You may @mention other agents.",
            "- Keep feedback constructive and actionable.",
            '- If you have nothing to add, output exactly "PASS".',
        ]
    )

    if memory_context:
        lines.extend(["", memory_context])

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Prompt building
# ---------------------------------------------------------------------------


def build_system_prompt(
    system_instruction: str,
    handle: str,
    *,
    memory_context: str = "",
    space_rules: str = "",
) -> str:
    """Stable system prompt — cached across calls by LLM API."""
    lines = [system_instruction, ""]
    lines.append(f"You are @{handle} in a multi-agent chatroom.")
    lines.append("")
    if space_rules:
        lines.append("## Project Rules")
        lines.append(space_rules)
        lines.append("")
    lines.append("")
    lines.append("WHEN TO RESPOND:")
    lines.append("- If MANDATORY_REPLY is YES: you MUST reply (you were @mentioned).")
    lines.append(
        '- If MANDATORY_REPLY is NO: only reply if you have something concrete and NEW to add. Otherwise output exactly "PASS".'
    )
    lines.append(
        '- Output EXACTLY "PASS" — not "Standing by", "Nothing to add", "Acknowledged", or "+1". Those create real messages and trigger other agents.'
    )
    lines.append(
        '- When referring to another agent, do NOT @mention them unless you need them to act. Use their role ("the engineer") instead of @handle to avoid triggering cascades.'
    )
    lines.append("")
    lines.append("OUTPUT FORMAT:")
    lines.append(
        "- Never echo MANDATORY_REPLY in your response — it is an internal instruction."
    )
    lines.append(
        '- To create a shared document, wrap it in: <<<ARTIFACT title="Title" type="markdown">>>\\ncontent\\n<<<END_ARTIFACT>>>'
    )
    lines.append("  Supported types: markdown, code, html, mermaid.")
    lines.append("- Your chat message goes OUTSIDE the artifact block.")
    lines.append("")
    lines.append("MEMORY INSTRUCTIONS:")
    lines.append(
        "- You can save, correct, or delete memories by adding a YAML block "
        "wrapped in <<<MEMORY>>>...<<<END_MEMORY>>> tags."
    )
    lines.append("- Example:")
    lines.append("  <<<MEMORY>>>")
    lines.append("  - action: save")
    lines.append("    domain: self")
    lines.append("    content: |")
    lines.append("      Breaking PRDs into user stories first works better.")
    lines.append("  - action: save")
    lines.append("    domain: peer")
    lines.append("    subject: claude-eng")
    lines.append("    content: Prefers TypeScript, flags edge cases early.")
    lines.append("  - action: correct")
    lines.append("    domain: learned")
    lines.append("    replaces: <substring of old memory content>")
    lines.append("    content: <corrected content>")
    lines.append("  - action: delete")
    lines.append("    domain: project")
    lines.append("    content: <substring of memory to remove>")
    lines.append("  <<<END_MEMORY>>>")
    lines.append("- Actions:")
    lines.append("  * save — store a new memory (deduped automatically)")
    lines.append(
        '  * correct — replace an existing memory (include "replaces" '
        "with a substring of the old content, at least 10 chars)"
    )
    lines.append(
        '  * delete — remove an outdated memory (include "content" with a substring to match)'
    )
    lines.append("- Domains:")
    lines.append(
        "  * self — your own experience and lessons (omit subject). "
        'Example: "Breaking PRDs into user stories first works better"'
    )
    lines.append(
        "  * peer — factual observations about a workmate (subject: their handle). "
        'Example: "Prefers TypeScript, flags edge cases early". Stick to facts.'
    )
    lines.append(
        "  * project — decisions, goals, status, blockers (subject: leave empty or space context)"
    )
    lines.append(
        "  * learned — technical facts, codebase patterns, domain knowledge "
        "(subject: leave empty or space context)"
    )
    lines.append("- Only save things worth remembering across future conversations.")
    if memory_context:
        lines.append("")
        lines.append(memory_context)
    return "\n".join(lines)


_FALLBACK_MIME = "application/octet-stream"


def _render_attachment_lines(
    msg: Message,
    attachment_paths: dict[str, str] | None,
) -> list[str]:
    """Render one '  [attachment: ...]' line per attachment on a message.

    If ``attachment_paths`` has a local path for the attachment's id, the line
    points the agent at the local file so it can Read it directly. Otherwise
    the line records that the download failed so the agent does not pretend
    the file is unavailable.
    """
    out: list[str] = []
    paths = attachment_paths or {}
    for a in msg.attachments or []:
        mime = a.content_type or _FALLBACK_MIME
        local = paths.get(a.id)
        if local:
            out.append(
                f"  [attachment: {a.filename} ({mime}) — local path: {local}. "
                f"Use your Read tool to open it.]"
            )
        else:
            out.append(
                f"  [attachment: {a.filename} ({mime}) — download failed, "
                f"content is NOT available to you]"
            )
    return out


def build_user_prompt(
    history: list[Message],
    *,
    must_reply: bool = False,
    attachment_paths: dict[str, str] | None = None,
) -> str:
    """Per-call user prompt — conversation + directive."""
    lines = ["Conversation:"]
    for m in history:
        quote_part = ""
        if m.quoted_message:
            q = m.quoted_message
            quote_part = (
                f' (In response to @{q.get("author_handle")}: "{q.get("text")}")'
            )
        lines.append(f"@{m.author_handle}:{quote_part} {m.text}")
        lines.extend(_render_attachment_lines(m, attachment_paths))
    lines.append("")
    if must_reply:
        lines.append("MANDATORY_REPLY: YES")
    else:
        lines.append("MANDATORY_REPLY: NO")
    return "\n".join(lines)


def build_prompt(
    history: list[Message],
    system: str,
    handle: str,
    *,
    memory_context: str = "",
    space_rules: str = "",
    must_reply: bool = False,
    attachment_paths: dict[str, str] | None = None,
) -> str:
    """Flat prompt fallback for backends that don't support system/user split."""
    sys_part = build_system_prompt(
        system,
        handle,
        memory_context=memory_context,
        space_rules=space_rules,
    )
    user_part = build_user_prompt(
        history,
        must_reply=must_reply,
        attachment_paths=attachment_paths,
    )
    return f"{sys_part}\n\n{user_part}"


def build_resume_prompt(
    new_messages: list[Message],
    handle: str,
    *,
    must_reply: bool = False,
    memory_context: str = "",
    space_rules: str = "",
    attachment_paths: dict[str, str] | None = None,
) -> str:
    """Build a shorter prompt for session-resume (only new messages).

    Includes a context reminder with project rules and memory so that
    these survive even if the original system prompt is compressed away
    in long conversations.
    """
    lines = []
    # Context reminder — keeps rules and memory alive across long sessions
    if space_rules or memory_context:
        lines.append("Context reminder (still in effect):")
        if space_rules:
            lines.append(f"Project Rules: {space_rules}")
        if memory_context:
            lines.append(memory_context)
        lines.append("")
    lines.append("New messages in the conversation:")
    lines.append("")
    for m in new_messages:
        quote_part = ""
        if m.quoted_message:
            q = m.quoted_message
            quote_part = (
                f' (In response to @{q.get("author_handle")}: "{q.get("text")}")'
            )
        lines.append(f"@{m.author_handle}:{quote_part} {m.text}")
        lines.extend(_render_attachment_lines(m, attachment_paths))
    lines.append("")
    if must_reply:
        lines.append(
            "You were directly addressed. You MUST reply — do not output PASS."
        )
    else:
        lines.append(
            'Respond to the above. If you have nothing to add, output exactly "PASS".'
        )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Local runner: wraps CLI backends as remote AgentsHive agents.",
    )
    parser.add_argument(
        "--server",
        required=True,
        help="AgentsHive server URL (e.g. http://localhost:8000)",
    )
    parser.add_argument(
        "--token",
        required=True,
        help="Backend API token (e.g. ahv_...)",
    )
    parser.add_argument(
        "--system",
        default="You are a helpful assistant.",
        help="Fallback system instruction (used when server doesn't provide per-agent instruction)",
    )
    parser.add_argument(
        "--repo-path",
        default=None,
        help="Working directory for the subprocess",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=300,
        help="Subprocess timeout in seconds (default: 300)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable debug logging",
    )
    return parser.parse_args(argv)


def create_task_handler(
    daemon: BackendClient,
    *,
    system_instruction: str = "You are a helpful assistant.",
    repo_path: str | None = None,
    timeout: int = 300,
) -> None:
    """Create and register a task handler on the given BackendClient.

    This is the core logic used by both the legacy CLI and the new
    ``agentshive start`` command.
    """
    api = daemon.api
    sessions: dict[tuple[str, str], str] = {}
    last_seen: dict[tuple[str, str], str] = {}

    @daemon.on_task
    async def handle(agent_handle: str, backend: str, message: Message) -> None:
        if getattr(message, "_task_type", "") == "artifact_review":
            await _handle_artifact_review(agent_handle, backend, message)
            return

        thread_id = message.thread_id
        session_key = (agent_handle, thread_id)
        logger.info(
            "[%s@%s] Task received (backend=%s, thread=%s)",
            agent_handle,
            thread_id[:8],
            backend,
            thread_id,
        )
        history = await message.get_thread_history()

        # Resolve the backend from the registry
        try:
            cli = create_backend(backend)
        except ValueError:
            logger.error(
                "Unknown backend %r for agent %s, skipping", backend, agent_handle
            )
            return

        # Ensure any attachments referenced by the transcript are present in
        # the shared on-disk cache so the CLI backend can Read them. Paths
        # are stable across tasks (see ``_attachment_cache_dir``) so a
        # resumed session continues to resolve files it saw on earlier
        # turns, and cache hits skip the HTTP fetch.
        _prune_stale_attachments()
        attachment_paths: dict[str, str] = {}
        try:
            attachment_paths = await _download_attachments(history, api)
        except Exception as exc:
            logger.warning(
                "[%s@%s] Attachment download pass failed: %s",
                agent_handle,
                thread_id[:8],
                exc,
            )

        session_id = sessions.get(session_key)
        resumed = bool(session_id)
        logger.info(
            "[%s@%s] Session: %s",
            agent_handle,
            thread_id[:8],
            session_id[:8] if session_id else "new",
        )

        # 1. Fetch memory context + space rules
        memory_ctx = ""
        space_rules = ""
        try:
            participants = list({m.author_handle for m in history})
            recent_text = "\n".join(
                f"{m.author_handle}: {m.text}" for m in history[-6:] if m.text
            )
            memory_ctx, space_rules = await api.get_memory_context(
                space_id=message.space_id,
                participants=participants,
                agent_handle=agent_handle,
                recent_context=recent_text,
            )
        except Exception as exc:
            logger.warning("Failed to fetch memory context: %s", exc)

        logger.info(
            "[%s@%s] Memory: %d chars, rules: %d chars",
            agent_handle,
            thread_id[:8],
            len(memory_ctx),
            len(space_rules),
        )

        # Server tells us whether a reply is mandatory (e.g. DM or @mention)
        must_reply = getattr(message, "_must_reply", False)

        # Use per-agent system_instruction from the server if available,
        # otherwise fall back to the global --system CLI arg.
        agent_instruction = (
            getattr(message, "_system_instruction", "") or system_instruction
        )

        # 2. Build prompt
        if session_id and cli.supports_resume:
            # Resume: only send messages after our last response
            last_id = last_seen.get(session_key)
            if last_id:
                new_msgs = []
                found = False
                for m in history:
                    if found:
                        new_msgs.append(m)
                    elif m.id == last_id:
                        found = True
                if new_msgs:
                    prompt = build_resume_prompt(
                        new_msgs,
                        agent_handle,
                        must_reply=must_reply,
                        memory_context=memory_ctx,
                        space_rules=space_rules,
                        attachment_paths=attachment_paths,
                    )
                else:
                    prompt = build_prompt(
                        history,
                        agent_instruction,
                        agent_handle,
                        memory_context=memory_ctx,
                        space_rules=space_rules,
                        must_reply=must_reply,
                        attachment_paths=attachment_paths,
                    )
            else:
                prompt = build_prompt(
                    history,
                    agent_instruction,
                    agent_handle,
                    memory_context=memory_ctx,
                    space_rules=space_rules,
                    must_reply=must_reply,
                    attachment_paths=attachment_paths,
                )
        else:
            prompt = build_prompt(
                history,
                agent_instruction,
                agent_handle,
                memory_context=memory_ctx,
                space_rules=space_rules,
                must_reply=must_reply,
                attachment_paths=attachment_paths,
            )

        logger.debug(
            "[%s@%s] Prompt (%d chars): %s...",
            agent_handle,
            thread_id[:8],
            len(prompt),
            prompt[:200],
        )

        # 3. Run subprocess with retry logic
        delay = BASE_DELAY_S
        result = None
        truncation_retried = False

        for attempt in range(MAX_RETRIES + 1):
            logger.info(
                "Running %s for @%s thread %s (attempt %d, resume=%s)",
                backend,
                agent_handle,
                thread_id,
                attempt + 1,
                bool(session_id),
            )

            try:
                result = await cli.invoke(
                    prompt,
                    session_id=session_id,
                    timeout=timeout,
                    cwd=repo_path,
                )
                break

            except RateLimitError:
                if attempt < MAX_RETRIES:
                    logger.warning(
                        "[%s@%s] Rate limit (attempt %d/%d), waiting %.0fs",
                        agent_handle,
                        thread_id[:8],
                        attempt + 1,
                        MAX_RETRIES,
                        delay,
                    )
                    await asyncio.sleep(delay)
                    delay *= 3
                    continue
                # Exhausted retries
                sessions.pop(session_key, None)
                last_seen.pop(session_key, None)
                raise

            except TimeoutError as exc:
                sessions.pop(session_key, None)
                last_seen.pop(session_key, None)
                await message.reply(f"[error] {exc}")
                raise

            except RuntimeError:
                # Resume failure -> clear session and retry with full prompt
                if session_id and attempt == 0:
                    logger.warning(
                        "[%s@%s] Resume failed, falling back to full prompt",
                        agent_handle,
                        thread_id[:8],
                    )
                    sessions.pop(session_key, None)
                    session_id = None
                    prompt = build_prompt(
                        history,
                        agent_instruction,
                        agent_handle,
                        memory_context=memory_ctx,
                        space_rules=space_rules,
                        must_reply=must_reply,
                        attachment_paths=attachment_paths,
                    )
                    continue
                sessions.pop(session_key, None)
                last_seen.pop(session_key, None)
                raise

        # 4. Extract results
        logger.info(
            "[%s@%s] CLI result: %d chars, session=%s",
            agent_handle,
            thread_id[:8],
            len(result.text),
            result.session_id[:8] if result.session_id else None,
        )
        reply_text = result.text
        new_session_id = result.session_id
        usage = {
            "input_tokens": result.input_tokens,
            "output_tokens": result.output_tokens,
            "cache_read_tokens": result.cache_read_tokens,
            "cost_usd": result.cost_usd,
        }

        if new_session_id:
            sessions[session_key] = new_session_id

        # 5. Truncation check -> retry if needed
        first_run_files = result.generated_files or []
        if not truncation_retried and is_truncated(reply_text, result.stop_reason):
            logger.warning(
                "[%s@%s] Response truncated, retrying with full prompt",
                agent_handle,
                thread_id[:8],
            )
            truncation_retried = True
            sessions.pop(session_key, None)
            session_id = None
            resumed = False
            prompt = build_prompt(
                history,
                agent_instruction,
                agent_handle,
                memory_context=memory_ctx,
                space_rules=space_rules,
                must_reply=must_reply,
                attachment_paths=attachment_paths,
            )
            try:
                result = await cli.invoke(
                    prompt,
                    session_id=None,
                    timeout=timeout,
                    cwd=repo_path,
                )
                reply_text = result.text
                new_session_id = result.session_id
                usage = {
                    "input_tokens": result.input_tokens,
                    "output_tokens": result.output_tokens,
                    "cache_read_tokens": result.cache_read_tokens,
                    "cost_usd": result.cost_usd,
                }
                if new_session_id:
                    sessions[session_key] = new_session_id
                # Merge generated files from both runs (dedup by path)
                retry_files = result.generated_files or []
                seen = set(first_run_files)
                merged = list(first_run_files)
                for f in retry_files:
                    if f not in seen:
                        merged.append(f)
                        seen.add(f)
                result.generated_files = merged
            except Exception as exc:
                logger.warning("Truncation retry failed: %s", exc)
                result.generated_files = first_run_files

        # 6. Extract memory tags
        clean_text, memories, corrections, deletions = extract_memory_tags(reply_text)
        logger.info(
            "[%s@%s] Extracted %d memories, %d corrections, %d deletions",
            agent_handle,
            thread_id[:8],
            len(memories),
            len(corrections),
            len(deletions),
        )

        # 7. Extract artifacts from response
        clean_text, artifacts = _extract_artifacts(clean_text)
        if artifacts:
            logger.info(
                "[%s@%s] Extracted %d artifacts",
                agent_handle,
                thread_id[:8],
                len(artifacts),
            )

        # 8. Reply (skip if PASS or empty)
        reply_msg = None
        generated_files = result.generated_files or []
        if not clean_text or clean_text.strip() == "PASS":
            if generated_files:
                # Agent PASSed on text but generated images — still upload them
                logger.info(
                    "[%s@%s] PASS with %d generated files, uploading",
                    agent_handle,
                    thread_id[:8],
                    len(generated_files),
                )
                reply_msg = await message.reply_with_files(
                    "Generated images:",
                    generated_files,
                )
                generated_files = []  # Already uploaded
            else:
                logger.info(
                    "[%s@%s] PASS — no reply needed", agent_handle, thread_id[:8]
                )
            last_seen[session_key] = message.id
        else:
            if generated_files:
                # Upload reply text with attached image files
                reply_msg = await message.reply_with_files(clean_text, generated_files)
                generated_files = []  # Already uploaded
            else:
                reply_msg = await message.reply(clean_text)
            last_seen[session_key] = message.id
            if reply_msg is None:
                # Server filtered as non-substantive (soft-PASS)
                logger.info(
                    "[%s@%s] Reply filtered by server", agent_handle, thread_id[:8]
                )
            else:
                logger.info(
                    "[%s@%s] Reply posted (%d chars, %d files)",
                    agent_handle,
                    thread_id[:8],
                    len(clean_text),
                    len(result.generated_files or []),
                )

        # 9. Upload artifacts (fire-and-forget)
        for art in artifacts:
            try:
                await api.create_artifact(
                    thread_id=thread_id,
                    title=art["title"],
                    content=art["content"],
                    content_type=art["content_type"],
                    author_handle=agent_handle,
                    author_display_name=agent_handle,
                    message_id=reply_msg.id if reply_msg else None,
                )
                logger.info(
                    "[%s@%s] Artifact created: %s",
                    agent_handle,
                    thread_id[:8],
                    art["title"],
                )
            except Exception as exc:
                logger.warning(
                    "[%s@%s] Failed to create artifact: %s",
                    agent_handle,
                    thread_id[:8],
                    exc,
                )

        # 10. Create a companion artifact for generated images using attachment URLs
        if reply_msg and reply_msg.attachments and (result.generated_files or []):
            image_atts = [a for a in reply_msg.attachments if a.url]
            if image_atts:
                image_md = "\n\n".join(f"![{a.filename}]({a.url})" for a in image_atts)
                try:
                    await api.create_artifact(
                        thread_id=thread_id,
                        title="Generated Images",
                        content=image_md,
                        content_type="markdown",
                        author_handle=agent_handle,
                        author_display_name=agent_handle,
                        message_id=reply_msg.id,
                    )
                    logger.info(
                        "[%s@%s] Image artifact created (%d images)",
                        agent_handle,
                        thread_id[:8],
                        len(image_atts),
                    )
                except Exception as exc:
                    logger.warning(
                        "[%s@%s] Failed to create image artifact: %s",
                        agent_handle,
                        thread_id[:8],
                        exc,
                    )

        # 11. Save memories (fire-and-forget)
        if memories or corrections or deletions:
            try:
                await api.save_memories(
                    memories,
                    message.space_id,
                    thread_id,
                    agent_handle=agent_handle,
                    corrections=corrections or None,
                    deletions=deletions or None,
                    participants=participants if participants else None,
                )
                logger.info(
                    "Saved %d memories, %d corrections, %d deletions for @%s thread %s",
                    len(memories),
                    len(corrections),
                    len(deletions),
                    agent_handle,
                    thread_id,
                )
            except Exception as exc:
                logger.warning("Failed to save memories: %s", exc)

        # 12. Report stats (fire-and-forget)
        if usage:
            try:
                await api.report_stats(
                    {
                        "thread_id": thread_id,
                        "space_id": message.space_id,
                        "backend": backend,
                        "agent_handle": agent_handle,
                        "resumed": resumed,
                        **usage,
                    }
                )
            except Exception as exc:
                logger.warning("Failed to report stats: %s", exc)

    async def _handle_artifact_review(
        agent_handle: str, backend: str, message: Message
    ) -> None:
        """Handle an artifact review task."""
        task_id = message._task_id or ""
        ctx = getattr(message, "_artifact_context", {})
        agent_instruction = (
            getattr(message, "_system_instruction", "") or system_instruction
        )

        try:
            cli = create_backend(backend)
        except ValueError:
            logger.error("Unknown backend %r for agent %s", backend, agent_handle)
            await api.fail_task(task_id, error=f"Unknown backend: {backend}")
            return

        memory_ctx = ""
        space_rules = ""
        try:
            memory_ctx, space_rules = await api.get_memory_context(
                space_id=message.space_id,
                participants=[],
                agent_handle=agent_handle,
            )
        except Exception as exc:
            logger.warning("Failed to fetch memory for artifact review: %s", exc)

        prompt = build_artifact_review_prompt(
            agent_handle,
            agent_instruction,
            ctx,
            memory_context=memory_ctx,
            space_rules=space_rules,
        )

        delay = BASE_DELAY_S
        result = None
        for attempt in range(MAX_RETRIES + 1):
            try:
                result = await cli.invoke(prompt, timeout=timeout, cwd=repo_path)
                break
            except RateLimitError:
                if attempt < MAX_RETRIES:
                    await asyncio.sleep(delay)
                    delay *= 3
                    continue
                await api.fail_task(task_id, error="Rate limit exhausted")
                return
            except (TimeoutError, RuntimeError) as exc:
                await api.fail_task(task_id, error=str(exc))
                return

        if result is None:
            await api.fail_task(task_id, error="No result from CLI")
            return

        # Truncation check — retry once with explicit instruction
        if is_truncated(result.text, result.stop_reason):
            logger.warning(
                "[%s] Artifact review response truncated, retrying", agent_handle
            )
            try:
                result = await cli.invoke(prompt, timeout=timeout, cwd=repo_path)
            except Exception as exc:
                logger.warning("Truncation retry failed: %s", exc)

        reply_text = result.text.strip()
        clean_text, _, _, _ = extract_memory_tags(reply_text)
        clean_text, _ = _extract_artifacts(clean_text)

        if not clean_text or clean_text.upper() == "PASS":
            await api.complete_artifact_task(task_id, comment_text="PASS")
            return

        comment_text, update_content, update_summary = _extract_artifact_update(
            clean_text
        )

        mentions = []
        if comment_text:
            mentions = re.findall(r"@([A-Za-z0-9_.-]+)", comment_text)

        await api.complete_artifact_task(
            task_id,
            comment_text=comment_text or "Reviewed.",
            artifact_update_content=update_content,
            artifact_update_summary=update_summary,
            mentions=mentions if mentions else None,
        )

        logger.info(
            "[%s] Artifact review complete (comment=%d chars, update=%s)",
            agent_handle,
            len(comment_text or ""),
            bool(update_content),
        )


def run_daemon(
    server_url: str,
    token: str,
    supported_backends: list[str] | None = None,
    *,
    system_instruction: str = "You are a helpful assistant.",
    repo_path: str | None = None,
    timeout: int = 300,
    log_level: str = "INFO",
) -> None:
    """Run the backend daemon. Called by both legacy CLI and ``agentshive start``."""
    logging.basicConfig(
        level=getattr(logging, log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
        datefmt="%H:%M:%S",
    )
    daemon = BackendClient(server_url=server_url, token=token)
    create_task_handler(
        daemon,
        system_instruction=system_instruction,
        repo_path=repo_path,
        timeout=timeout,
    )
    if supported_backends is None:
        supported_backends = list_available()
    daemon.run(supported_backends=supported_backends)


def main(argv: list[str] | None = None) -> None:
    """Legacy CLI entry point (python -m agentshive.local_runner)."""
    args = parse_args(argv)
    run_daemon(
        server_url=args.server,
        token=args.token,
        system_instruction=args.system,
        repo_path=args.repo_path,
        timeout=args.timeout,
        log_level="DEBUG" if args.verbose else "INFO",
    )


if __name__ == "__main__":
    main()
