"""Extract cookies directly from Firefox browser database.

This module reads cookies from Firefox's SQLite database, eliminating the need
for users to log in again in a separate browser window.
"""

from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

from rich.console import Console

console = Console()


def get_firefox_profiles_dir() -> Path | None:
    """Get Firefox profiles directory based on OS."""
    if sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support" / "Firefox" / "Profiles"
    elif sys.platform == "win32":
        base = Path.home() / "AppData" / "Roaming" / "Mozilla" / "Firefox" / "Profiles"
    else:
        base = Path.home() / ".mozilla" / "firefox" / "Profiles"

    if not base.exists():
        return None
    return base


def get_firefox_profile() -> Path | None:
    """Get the default Firefox profile directory."""
    profiles_dir = get_firefox_profiles_dir()
    if not profiles_dir:
        return None

    profiles = list(profiles_dir.iterdir())
    if not profiles:
        return None

    for profile in profiles:
        if profile.is_dir() and (profile / "cookies.sqlite").exists():
            return profile

    return None


def extract_cookies_from_firefox(domains: list[str]) -> dict[str, str]:
    """Extract cookies for domains from Firefox.

    Args:
        domains: List of domains to extract cookies for

    Returns:
        Dict of cookie names to values
    """
    profile = get_firefox_profile()
    if not profile:
        console.print("[yellow]No Firefox profile found[/yellow]")
        return {}

    cookie_db = profile / "cookies.sqlite"
    if not cookie_db.exists():
        console.print(f"[yellow]No cookies.sqlite found in {profile}[/yellow]")
        return {}

    cookies = {}
    try:
        conn = sqlite3.connect(str(cookie_db))
        cursor = conn.cursor()

        for domain in domains:
            cursor.execute(
                """
                SELECT name, value
                FROM moz_cookies
                WHERE host LIKE ?
                """,
                (f"%{domain}%",),
            )

            for name, value in cursor.fetchall():
                cookies[name] = value

        conn.close()
    except sqlite3.Error as e:
        console.print(f"[red]Error reading Firefox cookies: {e}[/red]")
        return {}

    return cookies


async def extract_firefox_cookies(service: str) -> dict | None:
    """Extract cookies from Firefox for a given service.

    Args:
        service: Service type (e.g., 'deepseek-chat', 'qwen-web', 'glm-web')

    Returns:
        Auth data dict or None
    """
    from .types import WEB_PROVIDERS

    config = WEB_PROVIDERS.get(service)
    if not config:
        console.print(f"[red]Unknown service: {service}[/red]")
        return None

    console.print(f"[cyan]Reading cookies from Firefox for {config.name}...[/cyan]")

    domains = config.cookie_domains
    console.print(f"[dim]Looking for cookies from: {domains}[/dim]")

    cookies = extract_cookies_from_firefox(domains)

    if not cookies:
        console.print("[yellow]No cookies found in Firefox for this domain[/yellow]")
        console.print("[dim]Make sure you are logged into the website in Firefox[/dim]")
        return None

    console.print(f"[green]Found {len(cookies)} cookies[/green]")
    console.print(f"[dim]Cookie names: {list(cookies.keys())}[/dim]")

    cookie_string = "; ".join(f"{name}={value}" for name, value in cookies.items())

    auth_data = {
        "provider_type": service,
        "cookie": cookie_string,
        "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "saved_at": "2026-04-08T00:00:00",
        "browser": "firefox-direct",
    }

    return auth_data


if __name__ == "__main__":
    import asyncio

    if len(sys.argv) < 2:
        print("Usage: python firefox_cookie_reader.py <service>")
        print("Services: deepseek-chat, qwen-web, glm-web, kimi-web")
        sys.exit(1)

    service = sys.argv[1]

    async def main():
        result = await extract_firefox_cookies(service)
        if result:
            print(f"\n[green]Success![/green]")
            print(f"Cookie length: {len(result['cookie'])}")
        else:
            print("\n[red]Failed to extract cookies[/red]")

    asyncio.run(main())
