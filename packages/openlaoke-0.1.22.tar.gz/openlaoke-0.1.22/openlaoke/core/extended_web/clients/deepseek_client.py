"""DeepSeek Web API client - Full implementation reference ZeroToken."""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import zlib
from typing import Any

import httpx


class DeepSeekPoWSolver:
    """Solve DeepSeek Proof-of-Work challenges."""

    @staticmethod
    def solve_sha256(challenge: str, salt: str, difficulty: int, max_nonce: int = 1000000) -> int:
        """Solve SHA256 PoW challenge."""
        target_bits = (
            difficulty
            if difficulty <= 1000
            else int(hashlib.log2(difficulty))
            if difficulty > 1
            else difficulty
        )

        for nonce in range(max_nonce):
            input_str = f"{salt}{challenge}{nonce}"
            hash_hex = hashlib.sha256(input_str.encode()).hexdigest()

            # Count leading zero bits
            zero_bits = 0
            for char in hash_hex:
                val = int(char, 16)
                if val == 0:
                    zero_bits += 4
                else:
                    zero_bits += val.bit_length() ^ 3
                    break

            if zero_bits >= target_bits:
                return nonce

        raise TimeoutError(f"SHA256 PoW timeout after {max_nonce} attempts")

    @staticmethod
    def solve_deepseek_hash_v1(challenge: str, prefix: str, difficulty: int) -> int:
        """Solve DeepSeekHashV1 PoW challenge using optimized approach."""
        # Simplified implementation - in production would use WASM
        for nonce in range(min(int(difficulty) * 100, 1000000)):
            input_str = f"{prefix}{challenge}{nonce}"
            hash_val = zlib.crc32(input_str.encode()) & 0xFFFFFFFF

            if hash_val % difficulty == 0:
                return nonce

        raise TimeoutError("DeepSeekHashV1 PoW timeout")


class DeepSeekWebClient:
    """DeepSeek Web API client with PoW support."""

    def __init__(
        self,
        cookie: str,
        user_agent: str = "",
        bearer_token: str = "",
    ) -> None:
        self.cookie = cookie
        self.user_agent = user_agent or (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )
        self.bearer_token = bearer_token
        self.base_url = "https://chat.deepseek.com"
        self.session_id: str | None = None
        self._client: httpx.AsyncClient | None = None
        self.pow_solver = DeepSeekPoWSolver()

    async def init(self) -> None:
        """Initialize client."""
        pass

    def _build_headers(self, include_pow: bool = False, pow_response: str = "") -> dict[str, str]:
        """Build HTTP headers."""
        headers = {
            "Cookie": self.cookie,
            "User-Agent": self.user_agent,
            "Content-Type": "application/json",
            "Accept": "*/*",
            "Referer": f"{self.base_url}/",
            "Origin": self.base_url,
            "x-client-platform": "web",
            "x-client-version": "1.7.0",
            "x-app-version": "20241129.1",
            "x-client-locale": "zh_CN",
        }

        if self.bearer_token:
            headers["Authorization"] = f"Bearer {self.bearer_token}"

        if include_pow and pow_response:
            headers["x-ds-pow-response"] = pow_response

        return headers

    async def _get_client(self) -> httpx.AsyncClient:
        """Get HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(300.0, connect=30.0),
            )
        return self._client

    async def close(self) -> None:
        """Close client."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def create_pow_challenge(self, target_path: str) -> dict[str, Any]:
        """Create PoW challenge."""
        client = await self._get_client()

        response = await client.post(
            f"{self.base_url}/api/v0/chat/create_pow_challenge",
            headers=self._build_headers(),
            json={"target_path": target_path},
        )

        if response.status_code >= 400:
            raise httpx.HTTPStatusError(
                f"Failed to create PoW challenge: {response.status_code}",
                request=response.request,
                response=response,
            )

        data = response.json()
        challenge = (
            data.get("data", {}).get("biz_data", {}).get("challenge")
            or data.get("data", {}).get("challenge")
            or data.get("challenge")
        )

        if not challenge:
            raise ValueError("PoW challenge missing in response")

        return challenge

    async def solve_pow(self, challenge: dict[str, Any]) -> int:
        """Solve PoW challenge."""
        algorithm = challenge.get("algorithm", "sha256")
        challenge_str = challenge.get("challenge", "")
        salt = challenge.get("salt", "")
        difficulty = challenge.get("difficulty", 10)
        expire_at = challenge.get("expire_at", 0)

        if algorithm == "sha256":
            return self.pow_solver.solve_sha256(challenge_str, salt, difficulty)
        elif algorithm == "DeepSeekHashV1":
            prefix = f"{salt}_{expire_at}_"
            return self.pow_solver.solve_deepseek_hash_v1(challenge_str, prefix, difficulty)
        else:
            raise ValueError(f"Unsupported PoW algorithm: {algorithm}")

    async def create_chat_session(self) -> str:
        """Create new chat session."""
        client = await self._get_client()

        response = await client.post(
            f"{self.base_url}/api/v0/chat_session/create",
            headers=self._build_headers(),
            json={},
        )

        if response.status_code >= 400:
            raise httpx.HTTPStatusError(
                f"Failed to create chat session: {response.status_code}",
                request=response.request,
                response=response,
            )

        data = response.json()
        session_id = (
            data.get("data", {}).get("biz_data", {}).get("chat_session_id")
            or data.get("data", {}).get("biz_data", {}).get("id")
            or data.get("chat_session_id")
            or data.get("id")
            or ""
        )

        if not session_id:
            raise ValueError("No session ID in response")

        self.session_id = session_id
        return session_id

    async def chat_completions(
        self,
        messages: list[dict[str, Any]],
        model: str = "deepseek-chat",
        temperature: float = 1.0,
        max_tokens: int = 4096,
        stream: bool = False,
    ) -> dict[str, Any]:
        """Send chat completion request with PoW."""
        client = await self._get_client()

        # Create session if needed
        if not self.session_id:
            self.session_id = await self.create_chat_session()

        # Create and solve PoW challenge
        target_path = "/api/v0/chat/completion"
        challenge = await self.create_pow_challenge(target_path)
        nonce = await asyncio.get_event_loop().run_in_executor(
            None, lambda: self.solve_pow(challenge)
        )

        # Build PoW response
        pow_data = {
            **challenge,
            "answer": nonce,
            "target_path": target_path,
        }
        pow_response = base64.b64encode(json.dumps(pow_data).encode()).decode()

        # Build request body
        body = {
            "chat_session_id": self.session_id,
            "parent_message_id": None,
            "prompt": messages[-1]["content"] if messages else "",
            "ref_file_ids": [],
            "thinking_enabled": model != "deepseek-chat",
            "search_enabled": True,
            "preempt": False,
        }

        # Send request
        response = await client.post(
            f"{self.base_url}{target_path}",
            headers=self._build_headers(include_pow=True, pow_response=pow_response),
            json=body,
        )

        if response.status_code >= 400:
            error_text = response.text[:500]
            if response.status_code in (401, 403):
                raise httpx.HTTPStatusError(
                    "DeepSeek authentication expired. Please re-login.",
                    request=response.request,
                    response=response,
                )
            raise httpx.HTTPStatusError(
                f"DeepSeek API error: {response.status_code}\n{error_text}",
                request=response.request,
                response=response,
            )

        data = response.json()

        if data is None:
            return {"content": "", "error": "Empty or invalid response from DeepSeek API"}

        # Parse response
        choices = data.get("choices", [])
        if not choices:
            return {"content": "", "error": "No choices in response"}

        choice = choices[0]
        message = choice.get("message", {})
        content = message.get("content", "")

        return {
            "content": content,
            "model": data.get("model", model),
            "usage": data.get("usage", {}),
            "finish_reason": choice.get("finish_reason", "stop"),
            "session_id": self.session_id,
        }

    async def chat_completions_stream(
        self,
        messages: list[dict[str, Any]],
        model: str = "deepseek-chat",
        temperature: float = 1.0,
        max_tokens: int = 4096,
    ) -> Any:
        """Send streaming chat completion request."""
        client = await self._get_client()

        if not self.session_id:
            self.session_id = await self.create_chat_session()

        # Create and solve PoW
        target_path = "/api/v0/chat/completion"
        challenge = await self.create_pow_challenge(target_path)
        nonce = await asyncio.get_event_loop().run_in_executor(
            None, lambda: self.solve_pow(challenge)
        )

        pow_data = {
            **challenge,
            "answer": nonce,
            "target_path": target_path,
        }
        pow_response = base64.b64encode(json.dumps(pow_data).encode()).decode()

        body = {
            "chat_session_id": self.session_id,
            "parent_message_id": None,
            "prompt": messages[-1]["content"] if messages else "",
            "ref_file_ids": [],
            "thinking_enabled": model != "deepseek-chat",
            "search_enabled": True,
            "preempt": False,
            "stream": True,
        }

        async with client.stream(
            "POST",
            f"{self.base_url}{target_path}",
            headers=self._build_headers(include_pow=True, pow_response=pow_response),
            json=body,
        ) as response:
            response.raise_for_status()

            async for line in response.aiter_lines():
                if not line:
                    continue

                if line.startswith("data: "):
                    data_str = line[6:]
                    if data_str == "[DONE]":
                        break

                    try:
                        data = json.loads(data_str)
                        choices = data.get("choices", [])
                        if choices:
                            delta = choices[0].get("delta", {})
                            content = delta.get("content", "")
                            if content:
                                yield content
                    except json.JSONDecodeError:
                        continue
