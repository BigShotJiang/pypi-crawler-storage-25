"""Terminal rendering — Rich markdown, code highlighting, streaming display, status indicators."""

from __future__ import annotations

import signal
import sys
import threading
import time
from contextlib import contextmanager
from typing import Iterator

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text
from rich.live import Live
from rich.spinner import Spinner
from rich.columns import Columns
from rich.rule import Rule
from rich.table import Table
from rich.progress import Progress, BarColumn, TextColumn, SpinnerColumn, TaskID

from sage.core.thinking_filter import ThinkingSuppressionFilter
import re

# Back-compat alias for internal use
_ThinkingSuppressionFilter = ThinkingSuppressionFilter


# =============================================================================
# EARLY STREAMING REJECTION - Detect bad patterns during streaming
# =============================================================================

# Check interval (every N tokens)
_STREAM_CHECK_INTERVAL = 50

def _detect_bad_streaming_patterns(content: str) -> tuple[bool, str]:
    """Detect patterns that should abort streaming early.

    Checks for:
    1. Invalid tool syntax (XML tags, YAML tool declarations, function calls)
    2. Garbage repetitive paths (same segment repeated many times)
    3. Tool refusal patterns (claims tools don't work)
    4. Argumentative/blocking behavior (asking for input instead of working)
    5. Non-standard tool syntax (read_file(), Command:, Action:)

    Returns:
        Tuple of (is_bad, reason) - if is_bad, streaming should abort
    """
    content_lower = content.lower()

    # 1. Invalid tool syntax - XML-style tags
    xml_tool_patterns = [
        r"<execute_tool>",
        r"<tool_call>",
        r"<function_call",  # Match <function_call with or without attributes
        r"</execute_tool>",
        r"</tool_call>",
        r"</function_call>",
    ]
    for pattern in xml_tool_patterns:
        if re.search(pattern, content, re.IGNORECASE):
            return True, f"Invalid XML tool syntax detected: {pattern}"

    # 2. Invalid tool syntax - YAML-style
    yaml_tool_patterns = [
        r"tool_name:\s*\w+",
        r"parameters:\s*\n",
        r"function:\s*\w+",
    ]
    for pattern in yaml_tool_patterns:
        if re.search(pattern, content, re.IGNORECASE):
            return True, f"Invalid YAML tool syntax detected"

    # 3. NON-STANDARD TOOL SYNTAX - function call style
    # Detects: read_file("path"), Command: read_file(), Action: Read, etc.
    nonstandard_tool_patterns = [
        r"\bread_file\s*\(",                    # read_file("...")
        r"\bsearch_files?\s*\(",                # search_file("...")
        r"\brun_command\s*\(",                  # run_command("...")
        r"\bexecute_command\s*\(",              # execute_command("...")
        r"\*\*Command:\*\*\s*\w+",              # **Command:** read_file
        r"\*\*Action:\*\*\s*\w+",               # **Action:** Read
        r"^Command:\s*\w+",                     # Command: read_file
        r"^Action:\s*\w+",                      # Action: Read
        r"Tool:\s*read",                        # Tool: read
        r"Tool:\s*search",                      # Tool: search
        r"Tool:\s*run",                         # Tool: run
        r"I (?:will|would) (?:use|call|invoke)\s+(?:the\s+)?read",  # I will use read
        r"I (?:will|would) (?:use|call|invoke)\s+(?:the\s+)?search",
        r"Let me (?:use|call|invoke)\s+(?:the\s+)?(?:read|search|run)",
        # Note: Removed print() detection - it triggers false positives on code in markdown blocks
        # r'^print\s*\(',                         # print("...")
        # r'^\s*print\s*\(',                      # print with leading whitespace
        # CRITICAL: Detect missing colon in tool commands
        # These patterns catch "READ sage/main.py" instead of "READ: sage/main.py"
        r"^READ\s+[a-zA-Z]",                    # READ followed by path (no colon)
        r"^SEARCH\s+[a-zA-Z*]",                 # SEARCH followed by pattern (no colon)
        r"^RUN\s+[a-zA-Z]",                     # RUN followed by command (no colon)
        # Detect "ls -F" and "cat README.md" style shell commands (model confused about tool format)
        r"^ls\s+-[a-zA-Z]",                     # ls -F (shell command style)
        r"^cat\s+\w",                           # cat file.txt (shell command style)
        r"^tree\s*$",                           # tree command
    ]
    for pattern in nonstandard_tool_patterns:
        if re.search(pattern, content, re.MULTILINE | re.IGNORECASE):
            return True, f"Non-standard tool syntax detected. Use READ:, SEARCH:, RUN: format instead."

    # 4. Garbage repetitive paths - same directory repeated many times
    # Match patterns like "ai-platform/ai-platform/ai-platform/..."
    # Threshold: 4 or more repetitions (e.g., foo/foo/foo/foo/ = 4 repeats)
    repetitive_path = re.search(r"([\w-]+/)(\1){3,}", content)
    if repetitive_path:
        return True, f"Garbage repetitive path detected: {repetitive_path.group(0)[:50]}..."

    # 4b. HYPOTHETICAL/SPECULATIVE CONTENT
    # Detect when model generates hypothetical plans or asks for files instead of reading
    hypothetical_patterns = [
        r"hypothetical\s+(?:structure|plan|analysis|codebase)",
        r"if you can provide",
        r"if you cannot provide",
        r"once the context is established",
        r"once the code is available",
        r"please provide the code",
        r"please upload",
        r"i require the actual",
        r"i need the actual source",
        r"without the actual (?:code|files|source)",
        r"no actual file system",
        r"no actual context",
        r"purely speculative",
        r"would typically exist",
        r"would typically include",
        r"would typically have",
        r"assuming a standard",
        r"assuming the existence",
        r"i will assume",
    ]
    for pattern in hypothetical_patterns:
        if re.search(pattern, content_lower):
            return True, f"Hypothetical/speculative content detected. Use READ: to get actual file contents."

    # 4c. DETECT GUESSED CONVENTIONAL PATHS
    # Model often guesses paths like src/main.py, ./src/utils/ that don't exist
    # This is a heuristic - if we see many "conventional" paths without any actual reads, flag it
    guessed_path_patterns = [
        r"\./src/",                     # ./src/ prefix
        r"src/main\.py",                # src/main.py
        r"src/utils/",                  # src/utils/
        r"src/services/",               # src/services/
        r"src/models/",                 # src/models/
        r"src/api/",                    # src/api/
        r"src/config/",                 # src/config/
        r"src/components/",             # src/components/
        r"app/main\.py",                # app/main.py
        r"app/utils/",                  # app/utils/
        r"lib/main",                    # lib/main
    ]
    guessed_count = sum(1 for p in guessed_path_patterns if re.search(p, content))
    # If 3+ conventional paths are mentioned without any READ: commands, likely guessing
    if guessed_count >= 3 and not re.search(r"^READ:\s+", content, re.MULTILINE):
        return True, f"Detected {guessed_count} conventional path patterns (src/main.py, etc.) without reading files. These paths likely don't exist. Use SEARCH: *.py to find actual files."

    # 5. Tool refusal during streaming
    refusal_patterns = [
        "cannot execute the read",
        "cannot perform read",
        "tool commands will not",
        "tool commands don't work",
        "tool commands do not work",
        "cannot run the read",
        "cannot access the file",
        "since i cannot read",
        "since i cannot execute",
    ]
    for pattern in refusal_patterns:
        if pattern in content_lower:
            return True, f"Tool refusal detected: '{pattern}'"

    # 6. ARGUMENTATIVE/BLOCKING BEHAVIOR - Model asking for input instead of working
    argumentative_patterns = [
        "please provide the output",
        "please share the output",
        "please paste the output",
        "please provide the file contents",
        "please share the file contents",
        "please share the contents",
        "i need the output of",
        "i need you to provide",
        "i need the file contents",
        "could you provide the",
        "could you share the",
        "can you provide the",
        "can you share the",
        "waiting for the output",
        "waiting for you to",
        "please run the command",
        "please execute the",
        "once you provide",
        "once you share",
        "before i can proceed",
        "before i can continue",
        "before proceeding",
        "i cannot proceed without",
        "cannot continue without",
        "need you to run",
        "need you to execute",
        "shall i proceed",
        "should i proceed",
        "do you want me to",
        "would you like me to",
        # NEW: Patterns from the log
        "please provide the following",
        "i need to know which files",
        "awaiting the file contents",
        "please provide the context",
        "i need the list of tasks",
        "i am ready to proceed",
        "i cannot regenerate",
        "i understand the request",
        "i understand the requirement",
        "no file structure or initial context",
        "since no file structure",
        "has not been provided",
        "have not yet received",
        "i have not yet received",
        "to provide the detailed",
        "without the code context",
        "without the actual contents",
        "i cannot generate",
        "any list i generate would be",
        "pure speculation",
    ]
    for pattern in argumentative_patterns:
        if pattern in content_lower:
            return True, f"Argumentative behavior detected: '{pattern}'. Execute tools directly with READ:/SEARCH:/RUN:"

    # 7. FABRICATION DETECTION - Model generating numbered lists without context
    # If we see many numbered items early in streaming without any READ: commands first
    numbered_items = re.findall(r"^\s*\d+\.\s+", content, re.MULTILINE)
    has_read_commands = bool(re.search(r"^READ:\s+", content, re.MULTILINE))

    # If model generates 5+ numbered items without any READ: commands, it's likely fabricating
    if len(numbered_items) >= 5 and not has_read_commands:
        # Check if there's any indication of actual file reading
        # Extended list includes phrases indicating the model has context from previously read files
        has_file_evidence = any(phrase in content_lower for phrase in [
            "based on reading",
            "in the file",
            "at line",
            "found in",
            ":line",
            # NEW: Phrases indicating the model has context from files read earlier
            "based on the provided",
            "from the provided",
            "the provided file",
            "the provided code",
            "provided code snippets",
            "provided snippets",
            "based on the code",
            "from the files",
            "from the code",
            "in the code",
            "visible in",
            "the structure and",
            "system appears",
            "system demonstrates",
            "architecture",  # Analysis of architecture implies reading files
            "the module",
            "the function",
            "the class",
            "imports from",
            "defined in",
            "implemented in",
            "line numbers",
            "sage/",  # Reference to specific project paths
            "backend/",
            ".py",  # Reference to specific file types
        ])
        if not has_file_evidence:
            return True, f"Fabrication detected: {len(numbered_items)} numbered items without reading any files. Use READ: first."

    return False, ""


console = Console()
err_console = Console(stderr=True)

# Indicator-only mode is now integrated with clean mode - no separate flag needed


# ── Thread Safety ──────────────────────────────────────────────

def _is_main_thread() -> bool:
    """Check if the current thread is the main thread.

    Returns:
        True if running on the main thread, False otherwise
    """
    return threading.current_thread() == threading.main_thread()


def set_no_color(enabled: bool) -> None:
    """Disable ANSI colors (e.g. ``--no-color``). Recreates Rich consoles."""
    global console, err_console
    if not enabled:
        return
    console = Console(no_color=True)
    err_console = Console(stderr=True, no_color=True)


# ── Output Mode Control ────────────────────────────────────
# Controls verbosity of output:
# - "clean": Default mode - only final output, no thinking/planning noise
# - "normal": Show progress phases but suppress thinking blocks
# - "verbose": Show all messages including thinking blocks (for debugging)

_output_mode: str = "clean"


def set_output_mode(mode: str) -> None:
    """Set the global output verbosity mode.

    Args:
        mode: One of "clean", "normal", or "verbose"
    """
    global _output_mode
    if mode not in ("clean", "normal", "verbose"):
        raise ValueError(f"Invalid output mode: {mode}. Must be 'clean', 'normal', or 'verbose'")
    _output_mode = mode


def get_output_mode() -> str:
    """Get the current output verbosity mode."""
    return _output_mode


def is_verbose() -> bool:
    """Check if output is in verbose mode (show everything including thinking)."""
    return _output_mode == "verbose"


def is_clean() -> bool:
    """Check if output is in clean mode (minimal output, no noise)."""
    return _output_mode == "clean"


def suppress_thinking() -> bool:
    """Check if thinking blocks should be suppressed (default: yes)."""
    return _output_mode != "verbose"


def strip_thinking_blocks(text: str) -> str:
    """Strip <thinking>...</thinking> blocks from text.

    This ensures thinking blocks are completely removed from any output,
    not just suppressed during streaming.

    Args:
        text: The text to process

    Returns:
        Text with thinking blocks removed
    """
    import re
    # Remove <thinking>...</thinking> blocks and any trailing whitespace
    cleaned = re.sub(r"<thinking>[\s\S]*?</thinking>\s*", "", text)
    return cleaned.strip()


def suppress_phases() -> bool:
    """Check if phase messages should be suppressed."""
    return _output_mode == "clean"


# Legacy compatibility
def is_quiet() -> bool:
    """Legacy: Check if in quiet mode (maps to clean)."""
    return _output_mode == "clean"


def is_minimal() -> bool:
    """Legacy: Check if in minimal mode (maps to clean/normal)."""
    return _output_mode in ("clean", "normal")


# ── Phase & Status Display ─────────────────────────────────


# Phase icons and colors for the agent workflow
_PHASE_STYLES = {
    "thinking": ("bold yellow", "⟡"),
    "planning": ("bold blue", "◈"),
    "reading": ("bold cyan", "◉"),
    "coding": ("bold magenta", "◆"),
    "writing": ("bold green", "▶"),
    "testing": ("bold yellow", "⧫"),
    "fixing": ("bold red", "⟐"),
    "executing": ("bold cyan", "▷"),
    "validating": ("bold yellow", "◇"),
    "done": ("bold green", "✓"),
    "error": ("bold red", "✗"),
}


def phase(name: str, detail: str = "") -> None:
    """Print a phase indicator with icon and optional detail.

    Respects output mode:
    - clean: Only shows critical phases (done, error)
    - normal: Shows important phases (done, error, writing, reading)
    - verbose: Shows all phases
    """
    if is_clean():
        # In clean mode, only show done/error
        if name not in ("done", "error"):
            return
    elif not is_verbose():
        # In normal mode, show essential phases only
        if name not in ("done", "error", "writing", "reading"):
            return
    style, icon = _PHASE_STYLES.get(name, ("dim", "·"))
    detail_str = f"  [dim]{detail}[/dim]" if detail else ""
    console.print(f"  [{style}]{icon} {name.capitalize()}[/{style}]{detail_str}")


@contextmanager
def status_spinner(message: str, phase_name: str = "thinking"):
    """Context manager that shows a Rich spinner with a message.

    Usage:
        with status_spinner("Analyzing your request..."):
            do_work()
    """
    style, icon = _PHASE_STYLES.get(phase_name, ("dim", "·"))
    spinner = Spinner(
        "dots", text=Text.from_markup(f"  [{style}]{icon} {message}[/{style}]")
    )
    with Live(spinner, console=console, refresh_per_second=12, transient=True):
        yield


def step(number: int, total: int, description: str, style: str = "bold cyan") -> None:
    """Print a numbered step indicator."""
    console.print(
        f"  [{style}]Step {number}/{total}[/{style}] [dim]─[/dim] {description}"
    )


def step_done(description: str) -> None:
    """Print a completed step."""
    console.print(f"  [green]✓[/green] {description}")


def step_fail(description: str) -> None:
    """Print a failed step."""
    console.print(f"  [red]✗[/red] {description}")


def divider(title: str = "", style: str = "dim") -> None:
    """Print a horizontal divider."""
    if title:
        console.print(Rule(title, style=style))
    else:
        console.print(Rule(style=style))


# ── Indicator-Only Mode Progress ──────────────────────────

@contextmanager
def sage_operation(operation: str, show_spinner: bool = True):
    """Context manager for SAGE operations - shows indicators in clean mode.

    Args:
        operation: Description of the operation (e.g., "Analyzing codebase")
        show_spinner: Whether to show a spinner during the operation

    Usage:
        with sage_operation("Reading files"):
            # do work
            pass
    """
    if is_clean():
        # Clean mode: show progress indicator only
        if show_spinner:
            spinner = Spinner("dots", text=Text.from_markup(f"  [bold cyan]●[/bold cyan] {operation}..."))
            with Live(spinner, console=console, refresh_per_second=12, transient=True):
                yield
        else:
            console.print(f"  [bold cyan]●[/bold cyan] {operation}...")
            yield
    else:
        # Normal/verbose mode: no extra output (calling code handles it)
        yield


def sage_step_complete(operation: str, result: str = "") -> None:
    """Mark a SAGE operation step as complete - only shown in clean mode.

    Args:
        operation: Description of what completed
        result: Optional result description
    """
    if is_clean():
        if result:
            console.print(f"  [green]✓[/green] {operation} → {result}")
        else:
            console.print(f"  [green]✓[/green] {operation}")


def sage_step_failed(operation: str, reason: str = "") -> None:
    """Mark a SAGE operation step as failed - only shown in clean mode.

    Args:
        operation: Description of what failed
        reason: Optional failure reason
    """
    if is_clean():
        if reason:
            console.print(f"  [red]✗[/red] {operation} → {reason}")
        else:
            console.print(f"  [red]✗[/red] {operation}")


def sage_final_output(content: str) -> None:
    """Show final output in clean mode.

    Args:
        content: The final output content to display
    """
    if is_clean():
        console.print()
        console.print(Panel(content, title="[bold green]Final Output[/bold green]", border_style="green"))
    else:
        # In normal/verbose mode, output is already shown
        pass


# ── Streaming with stats ───────────────────────────────────

# Streaming buffer settings for optimal performance
_STREAM_BUFFER_SIZE = 8  # Flush after this many tokens
_STREAM_FLUSH_INTERVAL = 0.05  # Or flush after this many seconds


def stream_tokens(tokens: Iterator[str], show_stats: bool = True) -> str:
    """Print tokens to stdout in real-time and return the full text.

    Uses buffered output with periodic flushes for better performance
    while maintaining responsiveness. Flushes every 8 tokens or 50ms.

    Tracks timing and token count for display after streaming completes.
    Ctrl+C cancels generation and returns what was collected so far.
    """
    parts: list[str] = []
    token_count = 0
    t0 = time.monotonic()
    last_flush = t0
    buffer: list[str] = []
    cancelled = False

    def _flush_buffer() -> None:
        nonlocal last_flush
        if buffer:
            sys.stdout.write("".join(buffer))
            sys.stdout.flush()
            buffer.clear()
            last_flush = time.monotonic()

    try:
        for token in tokens:
            buffer.append(token)
            parts.append(token)
            token_count += 1

            # Flush on buffer size or time interval
            now = time.monotonic()
            if len(buffer) >= _STREAM_BUFFER_SIZE or (now - last_flush) >= _STREAM_FLUSH_INTERVAL:
                _flush_buffer()

    except KeyboardInterrupt:
        cancelled = True

    # Final flush
    _flush_buffer()

    elapsed = time.monotonic() - t0
    sys.stdout.write("\n")
    sys.stdout.flush()

    if cancelled:
        console.print("  [dim yellow]─ Cancelled (Ctrl+C)[/dim yellow]")
    elif show_stats and token_count > 0 and elapsed > 0.1:
        tps = token_count / elapsed if elapsed > 0 else 0
        console.print(
            f"  [dim]─ {token_count} tokens · {elapsed:.1f}s · {tps:.0f} tok/s[/dim]"
        )

    return "".join(parts)


def stream_tokens_with_phase(
    tokens: Iterator[str],
    model_id: str = "",
    return_rejection_info: bool = False
) -> str | tuple[str, bool, str]:
    """Stream tokens with a thinking spinner that transitions to output.

    Shows 'Thinking...' spinner until first token arrives, then streams normally.
    Uses buffered output with periodic flushes for better performance.
    Ctrl+C cancels generation at any point — during thinking or streaming.

    Output mode behavior:
    - clean: Show only a spinner, suppress ALL streaming output. Returns full response.
    - normal: Show progress phases, suppress thinking blocks, stream output.
    - verbose: Show everything including thinking blocks.

    Args:
        tokens: Iterator of tokens from the model
        model_id: Model identifier for display
        return_rejection_info: If True, returns (response, was_rejected, reason)

    Returns:
        If return_rejection_info is False: response string (empty if rejected)
        If return_rejection_info is True: (response, was_rejected, rejection_reason)

    Uses a SIGINT handler to reliably catch Ctrl+C even inside Rich.Live,
    which can swallow KeyboardInterrupt in its refresh thread.
    """
    parts: list[str] = []
    buffer: list[str] = []
    token_count = 0
    t0 = time.monotonic()
    last_flush = t0
    first_token_time = None
    cancelled = False

    # In clean mode, suppress ALL streaming output - just show spinner
    clean_mode = is_clean()
    should_suppress_thinking = suppress_thinking()  # Suppress unless verbose mode
    think_filter: _ThinkingSuppressionFilter | None = (
        _ThinkingSuppressionFilter() if should_suppress_thinking else None
    )

    def _flush_buffer() -> None:
        nonlocal last_flush
        if buffer and not clean_mode:  # Don't flush in clean mode
            sys.stdout.write("".join(buffer))
            sys.stdout.flush()
            buffer.clear()
            last_flush = time.monotonic()

    # Install a SIGINT handler that sets a flag — Rich.Live can swallow
    # KeyboardInterrupt, but our handler always fires.
    # CRITICAL: Only install signal handlers on the main thread to avoid crashes
    _sigint_received = False
    _original_handler = None
    _on_main_thread = _is_main_thread()

    def _handle_sigint(signum, frame):
        nonlocal _sigint_received
        _sigint_received = True

    # Only install signal handler if we're on the main thread
    if _on_main_thread:
        _original_handler = signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGINT, _handle_sigint)

    # In clean mode, always show spinner (processing indicator)
    # In verbose mode, show thinking spinner
    # In normal mode, no spinner (phases shown by caller)
    show_spinner = clean_mode or is_verbose()
    spinner_text = (
        f"  [bold cyan]● Processing...[/bold cyan]  [dim](Ctrl+C to cancel)[/dim]"
        if clean_mode else
        f"  [bold yellow]⟡ Thinking...[/bold yellow]  [dim](Ctrl+C to cancel)[/dim]"
        + (f"  [dim]({model_id})[/dim]" if model_id else "")
    )
    spinner = Spinner("dots", text=Text.from_markup(spinner_text))
    live = Live(spinner, console=console, refresh_per_second=12, transient=True)
    if show_spinner:
        live.start()

    # Track if response was rejected due to bad patterns
    streaming_rejected = False
    rejection_reason = ""

    try:
        for token in tokens:
            if _sigint_received:
                cancelled = True
                break

            # Always capture the full response (including thinking) for callers
            parts.append(token)
            token_count += 1

            # EARLY PATTERN DETECTION - check periodically during streaming
            # This catches bad patterns BEFORE the full response is generated
            if token_count % _STREAM_CHECK_INTERVAL == 0:
                current_content = "".join(parts)
                is_bad, reason = _detect_bad_streaming_patterns(current_content)
                if is_bad:
                    streaming_rejected = True
                    rejection_reason = reason
                    # Stop the spinner and show rejection message
                    if live.is_started:
                        live.stop()
                    console.print()
                    console.print(f"  [bold red]❌ STREAMING ABORTED:[/bold red] {reason}")
                    console.print("  [dim]The model produced invalid output. Stopping generation.[/dim]")
                    break

            # In clean mode, don't process for display - just collect
            if clean_mode:
                continue

            display_chunk = think_filter.feed(token) if think_filter else token
            if think_filter and not display_chunk:
                continue

            if first_token_time is None and display_chunk:
                first_token_time = time.monotonic()
                if live.is_started:
                    live.stop()
                ttft = first_token_time - t0
                if is_verbose():
                    console.print(f"  [dim]─ First token in {ttft:.1f}s[/dim]")
                console.print("[bold green]sage>[/bold green] ", end="")

            buffer.append(display_chunk)

            # Buffered flush for better performance
            now = time.monotonic()
            if len(buffer) >= _STREAM_BUFFER_SIZE or (now - last_flush) >= _STREAM_FLUSH_INTERVAL:
                _flush_buffer()

            if _sigint_received:
                cancelled = True
                break

        # Handle remaining thinking filter content (not in clean mode)
        if think_filter and not clean_mode:
            tail = think_filter.flush_display_tail()
            if tail:
                if first_token_time is None:
                    first_token_time = time.monotonic()
                    if live.is_started:
                        live.stop()
                    ttft = first_token_time - t0
                    if is_verbose():
                        console.print(f"  [dim]─ First token in {ttft:.1f}s[/dim]")
                    console.print("[bold green]sage>[/bold green] ", end="")
                buffer.append(tail)
    except KeyboardInterrupt:
        cancelled = True
    finally:
        if live.is_started:
            live.stop()
        # Restore the original signal handler (only if we installed one)
        if _on_main_thread and _original_handler is not None:
            signal.signal(signal.SIGINT, _original_handler)

    # If streaming was rejected due to bad patterns, signal to caller
    if streaming_rejected:
        console.print()
        if return_rejection_info:
            return "", True, rejection_reason
        return ""  # Return empty to signal rejection

    # Final flush (only in non-clean mode)
    if not clean_mode:
        _flush_buffer()
        elapsed = time.monotonic() - t0
        sys.stdout.write("\n")
        sys.stdout.flush()

        if cancelled:
            console.print("  [dim yellow]─ Cancelled (Ctrl+C)[/dim yellow]")
        elif token_count > 0 and elapsed > 0.1 and is_verbose():
            tps = token_count / elapsed if elapsed > 0 else 0
            console.print(
                f"  [dim]─ {token_count} tokens · {elapsed:.1f}s · {tps:.0f} tok/s[/dim]"
            )
    else:
        # In clean mode, show final response after stripping thinking blocks
        if cancelled:
            console.print("  [dim yellow]● Cancelled[/dim yellow]")
        else:
            # Show the cleaned response (without thinking blocks)
            full_response = "".join(parts)
            cleaned_response = strip_thinking_blocks(full_response)
            if cleaned_response:
                console.print()
                console.print("[bold green]sage>[/bold green] ", end="")
                console.print(cleaned_response)
                console.print()

    result = "".join(parts)
    if return_rejection_info:
        return result, False, ""  # Not rejected
    return result


def stream_tokens_minimal(tokens: Iterator[str], model_id: str = "") -> str:
    """Stream tokens with minimal output - collapses thinking blocks.

    This provides a cleaner output by:
    - Showing a brief "thinking..." indicator instead of full thinking content
    - Only displaying the actual response content
    - Keeping stats minimal

    Returns the full response (including thinking) for processing.
    """
    parts: list[str] = []
    buffer: list[str] = []
    token_count = 0
    t0 = time.monotonic()
    last_flush = t0
    first_token_time = None
    cancelled = False
    think_filter = _ThinkingSuppressionFilter()

    def _flush_buffer() -> None:
        nonlocal last_flush
        if buffer:
            sys.stdout.write("".join(buffer))
            sys.stdout.flush()
            buffer.clear()
            last_flush = time.monotonic()

    # Signal handler for Ctrl+C
    # CRITICAL: Only install signal handlers on the main thread to avoid crashes
    _sigint_received = False
    _original_handler = None
    _on_main_thread = _is_main_thread()

    def _handle_sigint(signum, frame):
        nonlocal _sigint_received
        _sigint_received = True

    # Only install signal handler if we're on the main thread
    if _on_main_thread:
        _original_handler = signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGINT, _handle_sigint)

    # Show thinking spinner
    spinner = Spinner(
        "dots",
        text=Text.from_markup(
            f"  [bold yellow]⟡ Thinking...[/bold yellow]"
            + (f"  [dim]({model_id})[/dim]" if model_id else "")
        ),
    )
    live = Live(spinner, console=console, refresh_per_second=12, transient=True)
    live.start()

    try:
        for token in tokens:
            if _sigint_received:
                cancelled = True
                break

            parts.append(token)
            token_count += 1

            display_chunk = think_filter.feed(token)
            if not display_chunk:
                continue

            if first_token_time is None:
                first_token_time = time.monotonic()
                live.stop()
                ttft = first_token_time - t0
                console.print(f"  [dim]─ First token in {ttft:.1f}s[/dim]")
                console.print("[bold green]sage>[/bold green] ", end="")

            buffer.append(display_chunk)
            now = time.monotonic()
            if len(buffer) >= _STREAM_BUFFER_SIZE or (now - last_flush) >= _STREAM_FLUSH_INTERVAL:
                _flush_buffer()

            if _sigint_received:
                cancelled = True
                break

        tail = think_filter.flush_display_tail()
        if tail:
            if first_token_time is None:
                first_token_time = time.monotonic()
                live.stop()
                ttft = first_token_time - t0
                console.print(f"  [dim]─ First token in {ttft:.1f}s[/dim]")
                console.print("[bold green]sage>[/bold green] ", end="")
            buffer.append(tail)
    except KeyboardInterrupt:
        cancelled = True
    finally:
        if live.is_started:
            live.stop()
        # Restore the original signal handler (only if we installed one)
        if _on_main_thread and _original_handler is not None:
            signal.signal(signal.SIGINT, _original_handler)

    # Final flush
    _flush_buffer()

    elapsed = time.monotonic() - t0
    sys.stdout.write("\n")
    sys.stdout.flush()

    if cancelled:
        console.print("  [dim yellow]─ Cancelled (Ctrl+C)[/dim yellow]")
    elif token_count > 0 and elapsed > 0.1:
        tps = token_count / elapsed if elapsed > 0 else 0
        console.print(
            f"  [dim]─ {token_count} tokens · {elapsed:.1f}s · {tps:.0f} tok/s[/dim]"
        )

    return "".join(parts)


# ── Todo/Progress display ──────────────────────────────────


def print_todos(todos: list[dict]) -> None:
    """Print a minimal todo list showing task progress."""
    if not todos:
        return

    console.print()
    console.print("  [bold cyan]📋 Tasks:[/bold cyan]")
    for todo in todos:
        status = todo.get("status", "pending")
        content = todo.get("content", "")
        if status == "completed":
            icon = "[green]✓[/green]"
        elif status == "in_progress":
            icon = "[yellow]►[/yellow]"
        else:
            icon = "[dim]○[/dim]"
        console.print(f"    {icon} {content}")


def print_step_progress(current: int, total: int, description: str) -> None:
    """Print a minimal step progress indicator."""
    console.print(f"  [cyan]Step {current}/{total}:[/cyan] {description}")


# ── File operation display ─────────────────────────────────


def print_files_written(files: list[str]) -> None:
    """Print a styled list of written files."""
    console.print()
    phase("writing", f"{len(files)} file(s)")
    for f in files:
        console.print(f"    [green]+ {f}[/green]")


def print_files_deleted(files: list[str]) -> None:
    """Print a styled list of deleted files."""
    for f in files:
        console.print(f"    [red]- {f}[/red]")


def print_file_read(filepath: str, line_count: int) -> None:
    """Print a styled file-read indicator."""
    phase("reading", f"{filepath} ({line_count} lines)")


# ── Test result display ────────────────────────────────────


def print_test_results(output: str, passed: bool) -> None:
    """Print test results with pass/fail styling."""
    if passed:
        console.print()
        phase("done", "All tests passed")
        # Extract summary line if present
        for line in output.splitlines():
            if "passed" in line.lower():
                console.print(f"    [green]{line.strip()}[/green]")
                break
    else:
        console.print()
        phase("error", "Tests failed")
        # Show the failure summary
        in_failures = False
        shown = 0
        for line in output.splitlines():
            if "FAILED" in line or "ERROR" in line:
                console.print(f"    [red]{line.strip()}[/red]")
                shown += 1
            elif "short test summary" in line.lower():
                in_failures = True
            elif in_failures and line.strip() and shown < 10:
                console.print(f"    [red]{line.strip()}[/red]")
                shown += 1


def print_validation_start(cmd: str) -> None:
    """Print the start of a validation step."""
    console.print()
    phase("validating", cmd)


def print_retry(attempt: int, max_retries: int) -> None:
    """Print a retry indicator."""
    console.print()
    phase("fixing", f"Auto-fixing (attempt {attempt}/{max_retries})")


# ── Command execution display ──────────────────────────────


def print_shell_start(cmd: str) -> None:
    """Print shell command being executed."""
    phase("executing", cmd[:100] + ("..." if len(cmd) > 100 else ""))


def print_shell_output(output: str, max_lines: int = 30) -> None:
    """Print shell output, truncated if too long."""
    lines = output.splitlines()
    if len(lines) > max_lines:
        for line in lines[:10]:
            console.print(f"    [dim]{line}[/dim]")
        console.print(f"    [dim]... ({len(lines) - 20} lines hidden) ...[/dim]")
        for line in lines[-10:]:
            console.print(f"    [dim]{line}[/dim]")
    else:
        for line in lines:
            console.print(f"    [dim]{line}[/dim]")


# ── Existing functions (upgraded) ──────────────────────────


def render_markdown(text: str) -> None:
    """Render a complete response as Rich Markdown with code highlighting."""
    console.print(Markdown(text))


def print_model_table(
    models: list[dict],
    *,
    max_rows: int = 45,
    filter_hint: str | None = None,
) -> None:
    """Print a formatted table of available models.

    Large catalogs are truncated with a hint to use CLI ``sage models --search`` or ``/models <kw>``.
    """
    title = "Available Models"
    if filter_hint:
        title = f"{title} (filter: {filter_hint})"
    table = Table(title=title, show_lines=False)
    table.add_column("Model ID", style="cyan bold")
    table.add_column("Provider", style="green")
    table.add_column("Name", style="white")
    table.add_column("Type", style="yellow")

    shown = models[:max_rows]
    for m in shown:
        table.add_row(
            m["id"],
            m["provider"],
            m["name"],
            "local" if m["local"] else "API",
        )
    console.print(table)
    remaining = len(models) - len(shown)
    if remaining > 0:
        console.print(
            f"[dim]… {remaining} more not shown. "
            "Narrow the list: in sage run use [cyan]/models[/cyan] plus a keyword, "
            "or [cyan]sage models --search[/cyan] …[/dim]"
        )


def print_catalog_table(models: list[dict], show_status: bool = True) -> None:
    """Print a formatted table of models from the catalog."""
    table = Table(title="Downloadable Models", show_lines=False)
    table.add_column("Name", style="cyan bold")
    table.add_column("Size", style="yellow", justify="right")
    table.add_column("Params", style="green")
    table.add_column("Family", style="magenta")
    table.add_column("Description", style="white")
    if show_status:
        table.add_column("Status", style="bold")

    for m in models:
        row = [m["name"], m["size"], m["params"], m["family"], m["description"]]
        if show_status:
            row.append(m.get("status", ""))
        table.add_row(*row)
    console.print(table)


def print_download_complete(name: str, path: str, size_gb: float) -> None:
    """Print a success message after a model download."""
    console.print()
    console.print(
        Panel(
            f"[bold green]Downloaded:[/bold green] {name}\n"
            f"[dim]Path:[/dim] {path}\n"
            f"[dim]Size:[/dim] {size_gb:.1f} GB\n\n"
            f"Run with: [bold cyan]sage run --model llama_cpp:{name}[/bold cyan]",
            title="Model Ready",
            border_style="green",
        )
    )


def print_config(data: dict) -> None:
    """Pretty-print config as a panel."""
    import json

    text = json.dumps(data, indent=2)
    console.print(Panel(text, title="~/.sage/config.json", border_style="dim"))


def header(msg: str) -> None:
    """Print a header/title message."""
    console.print(f"[bold cyan]{msg}[/bold cyan]")


def info(msg: str) -> None:
    """Print an info message.

    Only shown in verbose mode.
    """
    if not is_verbose():
        return
    console.print(f"[dim]{msg}[/dim]")


def success(msg: str) -> None:
    """Print a success message."""
    console.print(f"[green]{msg}[/green]")


def error(msg: str) -> None:
    """Print an error message to stderr."""
    err_console.print(f"[red bold]Error:[/red bold] {msg}")


def warning(msg: str) -> None:
    """Print a warning to stderr.

    Important warnings that should show even in clean mode.
    For debug/validation warnings, use debug_warning() instead.
    """
    err_console.print(f"[yellow]Warning:[/yellow] {msg}")


def debug_warning(msg: str) -> None:
    """Print a debug warning (only in verbose mode).

    Use this for non-critical validation messages like:
    - File rejection reasons
    - Import validation failures
    - Garbage content rejections

    These are useful for debugging but noisy in clean mode.
    """
    if not is_verbose():
        return
    err_console.print(f"[dim yellow]Debug:[/dim yellow] {msg}")


def print_welcome(model_id: str) -> None:
    """Print the REPL welcome banner."""
    console.print(
        Panel(
            Text.from_markup(
                f"[bold cyan]Sage[/bold cyan] — local-first AI assistant\n"
                f"[dim]Model: {model_id}[/dim]\n\n"
                f"[dim]Commands: /help /clear /model /system /exit[/dim]\n"
                f'[dim]Multi-line: start with """ and end with """[/dim]'
            ),
            border_style="cyan",
        )
    )


def print_help() -> None:
    """Print REPL command reference."""
    help_text = (
        "[bold]Commands:[/bold]\n"
        "  [cyan]/help[/cyan]           Show this help\n"
        "  [cyan]/clear[/cyan]          Clear conversation history\n"
        "  [cyan]/model[/cyan] [id]     Show or change active model\n"
        "  [cyan]/system[/cyan] [text]  Show or set system prompt\n"
        "  [cyan]/history[/cyan]        Show conversation turn count\n"
        "  [cyan]/exit[/cyan]           Quit\n"
    )
    console.print(Panel(help_text, title="Help", border_style="dim"))


def print_agent_welcome(model_id: str, cwd: str, *, is_local: bool = False) -> None:
    """Print the agent-mode welcome banner (Claude Code–style interactive agent)."""
    kind = "local (Ollama / llama.cpp / etc.)" if is_local else "cloud / API"
    console.print()
    console.print(
        Panel(
            Text.from_markup(
                f"[bold cyan]  ╔═╗┌─┐┌─┐┌─┐[/bold cyan]\n"
                f"[bold cyan]  ╚═╗├─┤│ ┬├┤ [/bold cyan]\n"
                f"[bold cyan]  ╚═╝┴ ┴└─┘└─┘[/bold cyan]\n"
                f"\n"
                f"  [bold]SAGE — Interactive coding agent[/bold]\n"
                f"\n"
                f"  [dim]Active model:[/dim] [bold]{model_id}[/bold]\n"
                f"  [dim]Backend:[/dim]      {kind}\n"
                f"  [dim]Project:[/dim]      {cwd}\n"
                f"\n"
                f"  [dim]READ / SEARCH / edit / run — like Claude Code, using your model catalog.[/dim]\n"
                f"  [dim]Switch model with /model  ·  List or search: /models[/dim]\n"
                f"\n"
                f"  [dim cyan]Commands:[/dim cyan] /help /models /prompts /autopolit /think /test /read /files /compact /clear /exit\n"
                f'  [dim cyan]Shell:[/dim cyan]    !<command>    [dim cyan]Multi-line:[/dim cyan] """..."""\n'
                f"  [dim cyan]Models:[/dim cyan]   sage pull --list    sage pull <name>"
            ),
            border_style="cyan",
            padding=(0, 2),
        )
    )
    console.print()


def print_agent_help() -> None:
    """Print agent-mode command reference."""
    help_text = (
        "[bold]Agent Commands:[/bold]\n"
        "  [cyan]/help[/cyan]           Show this help\n"
        "  [cyan]/models[/cyan]         List all available AI models\n"
        "  [cyan]/prompts[/cyan]        Browse and reuse previous prompts\n"
        "  [cyan]/autopolit[/cyan] [n]  Endless autonomous loop (optional max cycles)\n"
        "  [cyan]/workflow[/cyan] <task> 15-step procedural AI workflow (TDD, plan, review)\n"
        "  [cyan]/phd[/cyan] <task>     PhD-level agent with multi-loop architecture\n"
        "  [cyan]/think[/cyan] <task>   Force step-by-step planning before implementing\n"
        "  [cyan]/read[/cyan] <file>    Read a file into conversation context\n"
        "  [cyan]/test[/cyan] [cmd]     Run tests (default: pytest -v --tb=short)\n"
        "  [cyan]/files[/cyan]          Show all written files this session\n"
        "  [cyan]/undo[/cyan]           Delete last written files\n"
        "  [cyan]/compact[/cyan]        Trim conversation to free context space\n"
        "  [cyan]/clear[/cyan]          Clear conversation + file history\n"
        "  [cyan]/model[/cyan] [id]     Show or change active model\n"
        "  [cyan]/history[/cyan]        Show conversation turns + recent prompts\n"
        "  [cyan]/exit[/cyan]           Quit\n"
        "\n[bold]Shell:[/bold]\n"
        "  [cyan]!<command>[/cyan]      Run a shell command (e.g. !python test.py)\n"
        "\n[bold]Download Models (no API key needed):[/bold]\n"
        "  [cyan]sage pull --list[/cyan]          See all downloadable models\n"
        "  [cyan]sage pull <name>[/cyan]           Download a model\n"
        "  [cyan]sage pull --search code[/cyan]    Find code-focused models\n"
        "  [cyan]sage pull --recommended[/cyan]    Top picks for getting started\n"
        "\n[bold]How Sage Works:[/bold]\n"
        "  [dim]⟡ Thinking[/dim]     Analyzing your request\n"
        "  [dim]◈ Planning[/dim]     Breaking the task into steps\n"
        "  [dim]◆ Coding[/dim]       Generating code\n"
        "  [dim]▶ Writing[/dim]      Saving files to disk\n"
        "  [dim]⧫ Testing[/dim]      Running tests automatically\n"
        "  [dim]⟐ Fixing[/dim]       Auto-fixing failures\n"
        "  [dim]✓ Done[/dim]         Task complete\n"
        "\n[bold]Flags:[/bold]\n"
        "  [dim]--output clean|normal|verbose  Terminal verbosity (default: clean)[/dim]\n"
        "  [dim]-v / --verbose                 Same as --output verbose[/dim]\n"
        "  [dim]--no-color                     Disable ANSI colors[/dim]\n"
        "  [dim]--auto-run       Skip bash execution prompts[/dim]\n"
        "  [dim]--max-retries N  Auto-fix retry limit (default: 10)[/dim]\n"
        "\n[bold]Autopolit Controls:[/bold]\n"
        "  [dim]Ctrl+C once      Stop after current task finishes[/dim]\n"
        "  [dim]Ctrl+C twice     Cancel immediately[/dim]\n"
    )
    console.print(Panel(help_text, title="Agent Help", border_style="dim"))


# ── Pull-Update-Delete Cycle Progress Bar ──────────────────


class SyncProgress:
    """Multi-phase progress bar for pull-update-delete sync cycles.

    Displays a rich progress bar that tracks three phases:
    1. Pull   - Fetching/downloading new items
    2. Update - Updating existing items
    3. Delete - Removing stale items

    Usage:
        with SyncProgress() as progress:
            # Pull phase
            progress.start_pull(total=10)
            for item in items_to_pull:
                pull(item)
                progress.advance_pull()

            # Update phase
            progress.start_update(total=5)
            for item in items_to_update:
                update(item)
                progress.advance_update()

            # Delete phase
            progress.start_delete(total=3)
            for item in items_to_delete:
                delete(item)
                progress.advance_delete()
    """

    _PHASE_ICONS = {
        "pull": ("cyan", "↓"),
        "update": ("yellow", "↻"),
        "delete": ("red", "×"),
    }

    def __init__(self, title: str = "Syncing") -> None:
        self._title = title
        self._progress: Progress | None = None
        self._overall_task: TaskID | None = None
        self._phase_task: TaskID | None = None
        self._current_phase: str | None = None
        self._phases_completed = 0
        self._total_phases = 3

    def __enter__(self) -> "SyncProgress":
        self._progress = Progress(
            SpinnerColumn(),
            TextColumn("[bold]{task.description}[/bold]"),
            BarColumn(bar_width=30),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TextColumn("[dim]{task.fields[status]}[/dim]"),
            console=console,
            transient=False,
        )
        self._progress.start()

        # Overall progress bar
        self._overall_task = self._progress.add_task(
            f"[bold cyan]{self._title}[/bold cyan]",
            total=self._total_phases,
            status="starting...",
        )
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if self._progress and self._overall_task is not None:
            if exc_type is None:
                # Success - mark complete
                self._progress.update(
                    self._overall_task,
                    completed=self._total_phases,
                    status="[green]complete[/green]",
                )
            else:
                # Error occurred
                self._progress.update(
                    self._overall_task,
                    status=f"[red]failed ({exc_type.__name__})[/red]",
                )
            self._progress.stop()

    def _start_phase(self, phase: str, total: int, description: str = "") -> None:
        """Start a new phase with its own progress bar."""
        color, icon = self._PHASE_ICONS.get(phase, ("white", "·"))
        desc = description or phase.capitalize()

        # Complete previous phase task if exists
        if self._phase_task is not None and self._progress:
            self._progress.remove_task(self._phase_task)

        self._current_phase = phase

        if self._progress and self._overall_task is not None:
            # Update overall status
            self._progress.update(
                self._overall_task,
                status=f"[{color}]{icon} {desc}[/{color}]",
            )

            # Create phase-specific task
            self._phase_task = self._progress.add_task(
                f"  [{color}]{icon}[/{color}] {desc}",
                total=total,
                status="",
            )

    def _advance_phase(self, amount: int = 1, status: str = "") -> None:
        """Advance the current phase progress."""
        if self._progress and self._phase_task is not None:
            self._progress.update(self._phase_task, advance=amount, status=status)

    def _complete_phase(self) -> None:
        """Mark the current phase as complete and update overall progress."""
        if self._progress and self._phase_task is not None:
            # Mark phase task complete
            task = self._progress.tasks[self._phase_task]
            self._progress.update(self._phase_task, completed=task.total or 0)

        self._phases_completed += 1
        if self._progress and self._overall_task is not None:
            self._progress.update(self._overall_task, completed=self._phases_completed)

    # ── Pull Phase ─────────────────────────────────────────

    def start_pull(self, total: int, description: str = "Pulling") -> None:
        """Start the pull phase."""
        self._start_phase("pull", total, description)

    def advance_pull(self, amount: int = 1, item: str = "") -> None:
        """Advance pull progress."""
        status = f"[dim]{item}[/dim]" if item else ""
        self._advance_phase(amount, status)

    def complete_pull(self) -> None:
        """Complete the pull phase."""
        self._complete_phase()

    # ── Update Phase ───────────────────────────────────────

    def start_update(self, total: int, description: str = "Updating") -> None:
        """Start the update phase."""
        self._start_phase("update", total, description)

    def advance_update(self, amount: int = 1, item: str = "") -> None:
        """Advance update progress."""
        status = f"[dim]{item}[/dim]" if item else ""
        self._advance_phase(amount, status)

    def complete_update(self) -> None:
        """Complete the update phase."""
        self._complete_phase()

    # ── Delete Phase ───────────────────────────────────────

    def start_delete(self, total: int, description: str = "Cleaning up") -> None:
        """Start the delete phase."""
        self._start_phase("delete", total, description)

    def advance_delete(self, amount: int = 1, item: str = "") -> None:
        """Advance delete progress."""
        status = f"[dim]{item}[/dim]" if item else ""
        self._advance_phase(amount, status)

    def complete_delete(self) -> None:
        """Complete the delete phase."""
        self._complete_phase()


@contextmanager
def sync_progress(title: str = "Syncing") -> Iterator[SyncProgress]:
    """Context manager for pull-update-delete sync progress.

    Usage:
        with sync_progress("Syncing models") as progress:
            progress.start_pull(total=10)
            for model in models_to_pull:
                download(model)
                progress.advance_pull(item=model.name)
            progress.complete_pull()

            progress.start_update(total=5)
            for model in models_to_update:
                update(model)
                progress.advance_update(item=model.name)
            progress.complete_update()

            progress.start_delete(total=3)
            for model in models_to_delete:
                remove(model)
                progress.advance_delete(item=model.name)
            progress.complete_delete()
    """
    sp = SyncProgress(title)
    with sp:
        yield sp


# ── Autopolit Progress Tracking (P1-28, P1-30) ──────────────


class AutopolitProgress:
    """Progress tracker for autopolit cycles.

    Tracks:
    - Current cycle number
    - Files written per cycle
    - Tests passed/failed
    - Time elapsed
    - Errors encountered
    """

    def __init__(self, max_cycles: int | None = None):
        self.max_cycles = max_cycles
        self.current_cycle = 0
        self.start_time = time.time()
        self.cycle_stats: list[dict] = []
        self._current_cycle_stats: dict = {}

    def start_cycle(self, cycle: int) -> None:
        """Start a new cycle."""
        self.current_cycle = cycle
        self._current_cycle_stats = {
            "cycle": cycle,
            "start_time": time.time(),
            "files_written": [],
            "tests_passed": False,
            "errors": [],
            "phase": "starting",
        }

        max_str = f"/{self.max_cycles}" if self.max_cycles else ""
        elapsed = time.time() - self.start_time
        elapsed_str = f"{elapsed:.0f}s" if elapsed < 60 else f"{elapsed/60:.1f}m"

        console.print()
        console.print(
            Rule(
                f"[bold cyan]Autopolit Cycle {cycle}{max_str}[/bold cyan] "
                f"[dim]({elapsed_str} elapsed)[/dim]",
                style="cyan",
            )
        )

    def update_phase(self, phase: str, detail: str = "") -> None:
        """Update current phase."""
        self._current_cycle_stats["phase"] = phase
        _phase(phase, detail)

    def add_file(self, filepath: str) -> None:
        """Record a file written."""
        self._current_cycle_stats["files_written"].append(filepath)

    def add_error(self, error: str) -> None:
        """Record an error."""
        self._current_cycle_stats["errors"].append(error)

    def set_tests_passed(self, passed: bool) -> None:
        """Record test result."""
        self._current_cycle_stats["tests_passed"] = passed

    def end_cycle(self) -> None:
        """End the current cycle and record stats."""
        self._current_cycle_stats["end_time"] = time.time()
        self._current_cycle_stats["duration"] = (
            self._current_cycle_stats["end_time"] -
            self._current_cycle_stats["start_time"]
        )
        self.cycle_stats.append(self._current_cycle_stats.copy())

        # Print cycle summary
        stats = self._current_cycle_stats
        files = len(stats["files_written"])
        errors = len(stats["errors"])
        duration = stats["duration"]

        status_parts = []
        if files > 0:
            status_parts.append(f"[green]{files} file(s)[/green]")
        if stats["tests_passed"]:
            status_parts.append("[green]tests ✓[/green]")
        elif errors > 0:
            status_parts.append(f"[red]{errors} error(s)[/red]")

        status = " · ".join(status_parts) if status_parts else "[dim]no changes[/dim]"
        console.print(f"  [dim]Cycle {self.current_cycle} completed in {duration:.1f}s[/dim] — {status}")

    def print_summary(self) -> None:
        """Print final autopolit summary (P1-30)."""
        total_time = time.time() - self.start_time
        total_cycles = len(self.cycle_stats)
        total_files = sum(len(s["files_written"]) for s in self.cycle_stats)
        total_errors = sum(len(s["errors"]) for s in self.cycle_stats)
        successful_cycles = sum(1 for s in self.cycle_stats if s["tests_passed"])

        time_str = f"{total_time:.0f}s" if total_time < 60 else f"{total_time/60:.1f}m"

        console.print()
        console.print(Rule("[bold]Autopolit Summary[/bold]", style="cyan"))
        console.print()

        # Create summary table
        table = Table(show_header=False, box=None, padding=(0, 2))
        table.add_column(style="dim")
        table.add_column(style="bold")

        table.add_row("Total cycles", str(total_cycles))
        table.add_row("Successful cycles", f"[green]{successful_cycles}[/green]")
        table.add_row("Files written", f"[cyan]{total_files}[/cyan]")
        table.add_row("Errors encountered", f"[red]{total_errors}[/red]" if total_errors else "[green]0[/green]")
        table.add_row("Total time", time_str)

        console.print(table)

        # List files written
        if total_files > 0:
            console.print()
            console.print("[dim]Files written:[/dim]")
            all_files = set()
            for s in self.cycle_stats:
                all_files.update(s["files_written"])
            for f in sorted(all_files)[:20]:
                console.print(f"  [green]+ {f}[/green]")
            if len(all_files) > 20:
                console.print(f"  [dim]... and {len(all_files) - 20} more[/dim]")

        console.print()


def _phase(name: str, detail: str = "") -> None:
    """Internal phase printer (avoids name conflict)."""
    style, icon = _PHASE_STYLES.get(name, ("dim", "·"))
    detail_str = f"  [dim]{detail}[/dim]" if detail else ""
    console.print(f"  [{style}]{icon} {name.capitalize()}[/{style}]{detail_str}")
