import yaml, platform
from argparse import Namespace, _ArgumentGroup
from typing import Self, Tuple, Dict
from pathlib import Path
from pathlike_typing import PathLike
from .base import BaseParser
from .decorators import dataclass
from .builder import NuitkaBuilder
from .i18n import gettext
from .models import NuitkaConfig
from .typings import NullStr, StrList
from .typings.models import NuitkaConfigDict
from .utils import get_os

__all__ = ['GeneratorParser', 'GeneratorArgs', 'NuitkaGenerator', 'main']


@dataclass
class GeneratorArgs:
    output_file: str
    compile: bool


class GeneratorParser(BaseParser):
    class RawDict(dict):
        _os_extra_dest = 'non_config__os_extra'

        def __init__(self, args: Namespace, extra: StrList, /, parser: 'GeneratorParser', *,
                     validate_main: bool = True, create_extra: bool = True):
            super().__init__(vars(args))
            self.args = args
            self.extra = extra
            self.parser = parser
            if validate_main: self.validate_main()
            if create_extra: self.create_extra()

        def validate_main(self) -> str:
            main_opt = self.get('main', None)
            main_pos = self.pop('main_pos', None)
            if not main_pos and not main_opt:
                self.parser.error(gettext("'main' option is required"))
            elif main_pos and main_opt:
                self.parser.error(gettext("Use either just --main or just the positional argument"))
            output = main_pos or main_opt
            self['main'] = output
            return output

        @classmethod
        def create_os_extra_argument(cls, group: _ArgumentGroup):
            return group.add_argument('--os-extra', '-X', action='store_true', dest=cls._os_extra_dest,
                                      help=gettext("Extra flags will be written to the extra_flags section of your OS, not the general one"))

        def create_extra(self):
            os_extra = self.get(self._os_extra_dest, False)
            extra = self.extra
            os_name = get_os()
            params_param = f'{os_name}_params'
            dct = self[params_param] if os_extra and os_name is not None and params_param in self else self
            dct['extra_flags'] = extra
            return self.extra

    def __init__(self, *args, epilog: NullStr = None, **kwargs):
        if epilog is None: epilog = gettext("Extra arguments are added to extra_flags")
        super().__init__(*args, **kwargs, epilog=epilog)

    def _add_config_root_arguments(self):
        type_group = self.add_mutually_exclusive_group()
        type_group.add_argument('--mode', dest='type',
                          help=gettext("Compilation mode: 'accelerated' (with Python dependency), 'standalone' (folder with exe), "
                                       "'onefile' (single exe), 'module' (extension module), 'app' (onefile for macOS with .app), "
                                       "'app-dist' (standalone for macOS with .app), 'package' (package as module), 'dll' (experimental)"))
        type_group.add_argument('--standalone', action='store_const', const='standalone', dest='type')
        type_group.add_argument('--onefile', action='store_const', const='onefile', dest='type')
        type_group.add_argument('--module', action='store_const', const='module', dest='type')
        type_group.add_argument('--package', action='store_const', const='package', dest='type')
        type_group.add_argument('--dll', action='store_const', const='dll', dest='type')

        self.add_argument('--run', dest='run', action='store_true',
                          help=gettext("Run the compiled binary immediately after compilation (--run)"))

        follow_imports_group = self.add_mutually_exclusive_group()
        follow_imports_group.add_argument('--follow-imports', action='store_const', const=True, dest='follow_imports',
                                          help=gettext("Follow all imported modules. In standalone mode defaults to True"))
        follow_imports_group.add_argument('--nofollow-imports', action='store_const', const=False, dest='follow_imports',
                                          help=gettext("DO NOT follow all imported modules"))

        self.add_argument('--follow-import-to', action='append', dest='follow_import_to',
                          help=gettext("Follow into the specified modules/packages. Example: 'requests', 'numpy'"))
        self.add_argument('--nofollow-import-to', action='append', dest='nofollow_import_to',
                          help=gettext("DO NOT follow into the specified modules/packages. Supports patterns, e.g. '*.tests'"))
        self.add_argument('--enable-plugins', action='append', dest='plugins',
                          help=gettext("List of plugins to enable. Example: 'tk-inter', 'anti-bloat'"))
        self.add_argument('--disable-plugins', action='append', dest='disable_plugins',
                          help=gettext("List of plugins to disable"))
        self.add_argument('--main', type=Path, dest='main',
                          help=gettext("Main file to compile (alternative to positional argument --main)"))
        self.add_argument('main_pos', type=Path, metavar='MAIN', nargs='?',
                          help=gettext("Main file to compile (positional argument)"))
        self.add_argument('--python-flag', action='append', dest='python_flags',
                          help=gettext("Python flags: '-S' (no_site), '-O' (no_asserts), 'no_warnings', 'no_docstrings', '-u' (unbuffered)"))
        self.add_argument('--jobs', type=int, dest='jobs',
                          help=gettext("Number of parallel compilation jobs. Negative values = CPU cores minus value (--jobs)"))
        self.add_argument('--debug', action='store_true', dest='debug',
                          help=gettext("Enable debug mode: self-checks, additional checks (--debug)"))
        self.add_argument('--report', type=Path, dest='report',
                          help=gettext("Create an XML compilation report (--report)"))
        self.add_argument('--output-dir', type=Path, dest='output_dir',
                          help=gettext("Directory for output files (build, dist, binaries) (--output-dir)"))
        self.add_argument('--output-name', '--output-file', dest='output_name',
                          help=gettext("Name of the output executable. For onefile may include path (--output-filename)"))
        self.add_argument('--remove-output', action='store_true', dest='remove_output',
                          help=gettext("Remove the build directory after creating the binary (--remove-output)"))
        self.add_argument('--module-parameter', action='append', dest='module_parameters',
                          help=gettext("Module parameters (--module-parameter)"))

        verbosity_group = self.add_mutually_exclusive_group()
        verbosity_group.add_argument('--verbose', action='store_const', const='verbose', dest='verbosity',
                                     help=gettext("Console output verbosity level: verbose"))
        verbosity_group.add_argument('--quiet', action='store_const', const='quiet', dest='verbosity',
                                     help=gettext("Console output verbosity level: quiet"))
        self.set_defaults(verbosity='info', type='accelerated')

    def _add_includes_arguments(self):
        includes_group = self.add_argument_group("Includes",
                                                 description=gettext("Settings for including additional modules, packages and data files"))
        includes_group.add_argument('--include-package', action='append', dest='include__packages',
                                    metavar='PACKAGES', help=gettext("List of packages to include in the build (--include-package)"))
        includes_group.add_argument('--include-module', action='append', dest='include__modules',
                                    metavar='MODULES', help=gettext("List of modules to include in the build (--include-module)"))
        includes_group.add_argument('--include-package-data', action='append', dest='include__package_data',
                                    metavar='PACKAGE_DATA',
                                    help=gettext("Packages whose data files should be included (--include-package-data)"))
        includes_group.add_argument('--include-data-files', action='append', dest='include__files',
                                    metavar='FILES', help=gettext("File patterns to include (--include-data-files)"))
        includes_group.add_argument('--include-data-dir', action='append', dest='include__directories',
                                    metavar='DIRECTORIES', help=gettext("Data directories to include (--include-data-dir)"))
        includes_group.add_argument('--noinclude-data-files', action='append', dest='include__noinclude_data_files',
                                    metavar='NOINCLUDE_DATA_FILES', help=gettext("File patterns to exclude from data (--noinclude-data-files)"))
        includes_group.add_argument('--include-distribution-metadata', action='append', dest='include__distribution_metadata',
                                    metavar='DISTRIBUTION_METADATA', help=gettext("Packages distribution metadata (--include-distribution-metadata)"))

    def _add_windows_arguments(self):
        windows_group = self.add_argument_group("Windows parameters")
        windows_params__icon = windows_group.add_mutually_exclusive_group()
        windows_params__icon.add_argument('--windows-icon-from-ico', dest='windows_params__icon', type=Path,
                                          metavar='ICON', help=gettext("Path to icon file (ICO format)"))
        windows_params__icon.add_argument('--windows-icon-from-exe', dest='windows_params__icon', type=Path,
                                          metavar='ICON', help=gettext("Extract icon from existing EXE file"))
        windows_group.add_argument('--windows-console-mode', dest='windows_params__console_mode',
                                   choices=['disable', 'force'], metavar='CONSOLE_MODE',
                                   help=gettext("Windows console mode: 'force' - create a console window (if not started from console), "
                                                "'disable' - do not create a console (--windows-console-mode)"))
        windows_group.add_argument('--windows-uac-admin', action='store_true', dest='windows_params__uac_admin',
                                   help=gettext("Request administrator privileges via UAC on launch (--windows-uac-admin)"))
        windows_group.add_argument('--windows-uac-uiaccess', action='store_true', dest='windows_params__uac_uiaccess',
                                   help=gettext("Request UAC to launch only from specific folders and remote access (--windows-uac-uiaccess)"))

    def _add_macos_arguments(self):
        macos_group = self.add_argument_group("MacOS parameters")
        macos_group.add_argument('--macos-app-icon', dest='macos_params__icon', type=Path,
                                 metavar='ICON',
                                 help=gettext("Path to icon file for macOS .app bundle (--macos-app-icon)"))
        macos_group.add_argument('--macos-create-app-bundle', dest='macos_params__create_app_bundle', action='store_true',
                                 help=gettext("Create a .app bundle instead of a regular binary. Enables standalone mode (--macos-create-app-bundle)"))
        macos_group.add_argument('--macos-signed-app-name', dest='macos_params__signed_app_name',
                                 metavar='SIGNED_APP_NAME',
                                 help=gettext("Application name for macOS signing in 'com.YourCompany.AppName' format. "
                                              "Globally unique identifier for accessing protected APIs (--macos-signed-app-name)"))

    def _add_linux_arguments(self):
        linux_group = self.add_argument_group("Linux parameters")
        linux_group.add_argument('--linux-icon', dest='linux_params__icon', type=Path,
                                 metavar='ICON', help=gettext("Path to icon file for Linux (--linux-icon)"))

    def _add_version_info_arguments(self):
        version_info_group = self.add_argument_group("Version info")
        version_info_group.add_argument('--company-name', dest='version_info__company_name',
                                        metavar='COMPANY_NAME',
                                        help=gettext("Company name in version info (--company-name)"))
        version_info_group.add_argument('--product-name', dest='version_info__product_name',
                                        metavar='PRODUCT_NAME',
                                        help=gettext("Product name in version info (--product-name)"))
        version_info_group.add_argument('--file-version', dest='version_info__file_version',
                                        metavar='FILE_VERSION',
                                        help=gettext("File version in X.X.X.X format (--file-version)"))
        version_info_group.add_argument('--copyright', dest='version_info__copyright_text',
                                        metavar='COPYRIGHT_TEXT',
                                        help=gettext("Copyright text (--copyright)"))

    def _add_actions_arguments(self):
        actions_group = self.add_argument_group(gettext("Commands"), gettext("Add commands to run before or after compilation"))
        actions_group.add_argument('--add-pre-compile-action', '-b', action='append',
                                   dest='pre_compile_actions', help=gettext("Commands executed before compilation"))
        actions_group.add_argument('--add-post-compile-action', '-p', action='append',
                                   dest='post_compile_actions', help=gettext("Commands executed after compilation"))

    def _add_non_cli_arguments(self):
        non_cli_group = self.add_argument_group(gettext("Non-CLI parameters"),
                                                gettext("Parameters that are not passed to Nuitka, but are written to the configuration file"))
        non_cli_group.add_argument('--time', '-t', dest='time', action='store_true',
                                   help=gettext("Show how long it took for the program to complete"))

    def _add_non_config_arguments(self):
        non_config_group = self.add_argument_group(gettext("Non-config arguments"),
                                                   gettext("Arguments that are not written to the configuration file"))
        non_config_group.add_argument('--output', '-o', default='nbc-config.yaml',
                                      dest='non_config__output_file', metavar='FILE', help=gettext("Path to output file"))
        non_config_group.add_argument('--compile', '-c', action='store_true',
                                      dest='non_config__compile', help=gettext("Compile the application after generating the configuration file"))
        self.RawDict.create_os_extra_argument(non_config_group)

    def add_arguments(self) -> Self:
        self._add_config_root_arguments()
        self._add_includes_arguments()
        self._add_windows_arguments()
        self._add_macos_arguments()
        self._add_linux_arguments()
        self._add_version_info_arguments()
        self._add_actions_arguments()
        self._add_non_cli_arguments()
        self._add_non_config_arguments()
        return self

    def parse_to_dicts(self, args=None, add_nones: bool = False) -> Tuple[NuitkaConfigDict, Dict[str, str]]:
        args, extra = self.parse_known_args(args)
        raw_dict = self.RawDict(args, extra, self)
        output = dict()
        non_config_items = dict()
        for key, value in raw_dict.items():
            if value is None and not add_nones: continue
            if '__' not in key: output[key] = value
            else:
                namespace, key = key.split('__', 1)
                if namespace == 'non_config': non_config_items[key] = value
                if namespace not in output: output[namespace] = dict()
                output[namespace][key] = value
        return output, non_config_items # type: ignore

    def parse_to_objects(self, args=None, add_nones: bool = False) -> Tuple[NuitkaConfig, GeneratorArgs]:
        config, non_config_items = self.parse_to_dicts(args, add_nones)
        return NuitkaConfig.model_validate(config), GeneratorArgs(**non_config_items)


class NuitkaGenerator:
    @staticmethod
    def generate_file(config: NuitkaConfig, path: PathLike, compile: bool):
        with open(path, 'w', encoding='utf-8') as file:
            file.write("# $schema: https://raw.githubusercontent.com/MagIlyasDOMA/nuitka-build-config/refs/heads/main/schema.json\n\n")
            yaml.safe_dump(config.to_dict(), file, allow_unicode=True)
        if compile: NuitkaBuilder().run(path)

    @classmethod
    def cli_run(cls, args=None):
        parser = GeneratorParser()
        config, non_config = parser.parse_to_objects(args)
        cls.generate_file(config, non_config.output_file, non_config.compile)


def main(): NuitkaGenerator.cli_run()

if __name__ == '__main__': main()
