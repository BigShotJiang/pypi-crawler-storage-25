import platform
from abc import ABCMeta, abstractmethod
from argparse_help_i18n import HelpI18nMixin
from pathlib import Path
from typing import Set, Optional, Self
from pathlike_typing import PathLike
from .decorators import argv_add, os_params
from .typings import *
from .typings.models import *

__all__ = ['BaseBuilder', 'DecoratorMixin', 'BaseParser']


class BaseBuilder:
    def __init__(self, config_path: PathLike = 'nbc-config.yaml', main: NullPathLike = None):
        self.config_path = Path(config_path)
        self.main = main

    @staticmethod
    def _parse_include_file(file: FileType) -> str:
        if isinstance(file, PathLike): return str(file)
        return '='.join(file)


class DecoratorMixin(BaseBuilder):
    _quote_marker: str = '\uE000'
    _use_quotes: bool = False

    @argv_add
    def _add_type(self, argv: StrList, arg: str) -> StrList:
        return [f'--mode={self._quote_marker}{arg}{self._quote_marker}']

    @argv_add
    def _add_run(self, argv: StrList, arg: bool) -> StrList: return ['--run'] if arg else []

    @argv_add
    def _add_include(self, argv: StrList, arg: IncludesDict) -> StrList:
        output = list()
        q = self._quote_marker
        output.extend([f'--include-package={q}{package}{q}' for package in arg['packages']])
        output.extend([f'--include-module={q}{module}{q}' for module in arg['modules']])
        output.extend([f'--include-package-data={q}{package}{q}' for package in arg['package_data']])
        output.extend([f'--include-data-files={q}{self._parse_include_file(file)}{q}' for file in arg['files']])
        output.extend([f'--include-data-dir={q}{self._parse_include_file(directory)}{q}' for directory in arg['directories']])
        output.extend([f'--noinclude-data-files={q}{pattern}{q}' for pattern in arg['noinclude_data_files']])
        output.extend([f'--include-distribution-metadata={q}{package}{q}' for package in arg['distribution_metadata']])
        return output

    @argv_add
    def _add_follow_imports(self, argv: StrList, arg: Optional[bool]) -> StrList:
        if arg is None: return []
        elif arg: return ['--follow-imports']
        else: return ['--nofollow-imports']

    @argv_add
    def _add_follow_import_to(self, argv: StrList, arg: StrList) -> StrList:
        return [f'--follow-import-to={self._quote_marker}{value}{self._quote_marker}' for value in arg]

    @argv_add
    def _add_nofollow_import_to(self, argv: StrList, arg: StrList) -> StrList:
        return [f'--nofollow-import-to={self._quote_marker}{value}{self._quote_marker}' for value in arg]

    @argv_add
    def _add_plugins(self, argv: StrList, arg: StrList) -> StrList:
        return [f'--enable-plugins={self._quote_marker}{plugin}{self._quote_marker}' for plugin in arg]

    @argv_add
    def _add_disable_plugins(self, argv: StrList, arg: StrList) -> StrList:
        return [f'--disable-plugins={self._quote_marker}{plugin}{self._quote_marker}' for plugin in arg]

    @argv_add
    def _add_main(self, argv: StrList, arg: NullPathLike) -> StrList:
        main = arg or self.main
        return [f'--main={self._quote_marker}{main}{self._quote_marker}'] if main is not None else []

    @argv_add
    def _add_follow_stdlib(self, argv: StrList, arg: bool) -> StrList:
        return ['--follow-stdlib'] if arg else []

    @os_params
    def _add_windows_params(self, argv: StrList, arg: WindowsParamsDict) -> StrList:
        output = list()
        if platform.system() == 'Windows':
            icon = arg['icon']
            if icon:
                option = '--windows-icon-from-exe' if icon.endswith('.exe') \
                    else '--windows-icon-from-ico'
                output.append('='.join((option, str(icon))))
            output.append(f"--windows-console-mode={self._quote_marker}{arg['console_mode']}{self._quote_marker}")
            if arg['uac_admin']: output.append('--windows-uac-admin')
            if arg['uac_uiaccess']: output.append('--windows-uac-access')
        return output

    @os_params
    def _add_macos_params(self, argv: StrList, arg: MacOSParamsDict) -> StrList:
        output = list()
        if platform.system() == 'Darwin':
            icon = arg['icon']
            if icon: output.append(f'--macos-app-icon={self._quote_marker}{icon}{self._quote_marker}')
            if arg['create_app_bundle']: output.append('--macos-create-app-bundle')
            signed_app_name = arg['signed_app_name']
            if signed_app_name: output.append(f'--macos-signed-app-name={self._quote_marker}{signed_app_name}{self._quote_marker}')
        return output

    @os_params
    def _add_linux_params(self, argv: StrList, arg: LinuxParamsDict) -> StrList:
        output = list()
        if platform.system() == 'Linux':
            icon = arg['icon']
            if icon: output.append(f'--linux-icon={self._quote_marker}{icon}{self._quote_marker}')
        return output

    @argv_add
    def _add_python_flags(self, argv: StrList, arg: Set[PythonFlagType]) -> StrList:
        return [f'--python-flag={self._quote_marker}{flag}{self._quote_marker}' for flag in arg]

    @argv_add
    def _add_jobs(self, argv: StrList, arg: Optional[int]) -> StrList:
        return [f'--jobs={self._quote_marker}{arg}{self._quote_marker}'] if arg else []

    @argv_add
    def _add_debug(self, argv: StrList, arg: bool) -> StrList: return ['--debug'] if arg else []

    @argv_add
    def _add_report(self, argv: StrList, arg: NullPathLike) -> StrList: return ['--report'] if arg else []

    @argv_add
    def _add_output_dir(self, argv: StrList, arg: NullPathLike) -> StrList:
        return [f'--output-dir={self._quote_marker}{arg}{self._quote_marker}'] if arg else []

    @argv_add
    def _add_output_name(self, argv: StrList, arg: str) -> StrList:
        return [f'--output-file={self._quote_marker}{arg}{self._quote_marker}'] if arg else []

    @argv_add
    def _add_remove_output(self, argv: StrList, arg: bool) -> StrList:
        return ['--remove-output'] if arg else []

    @argv_add
    def _add_verbosity(self, argv: StrList, arg: Verbosity) -> StrList:
        match arg:
            case 'info': return []
            case 'quiet': return ['--quiet']
            case 'verbose': return ['--verbose']
            case _: raise KeyError(arg)

    @argv_add
    def _add_extra_flags(self, argv: StrList, arg: StrList) -> StrList:
        return arg

    @argv_add
    def _add_version_info(self, argv: StrList, arg: VersionInfoDict) -> StrList:
        output = list()
        for key in VersionInfoDict.__annotations__.keys():
            match key:
                case 'copyright_text':
                    option_name = '--copyright'
                case _:
                    option_name = f'--{key.replace('_', '-')}'
            value = arg[key]  # type: ignore
            if value: output.append(f'{option_name}={self._quote_marker}{value}{self._quote_marker}')
        return output

    @argv_add
    def _add_module_parameters(self, argv: StrList, arg: StrList) -> StrList:
        return [f'--module-parameter={self._quote_marker}{param}{self._quote_marker}' for param in arg]


class BaseParser(HelpI18nMixin, metaclass=ABCMeta):
    def __init__(self, *args, add_arguments: bool = True, **kwargs):
        kwargs.setdefault('add_version', False)
        super().__init__(*args, **kwargs)
        if add_arguments: self.add_arguments()

    @abstractmethod
    def add_arguments(self) -> Self: return self
