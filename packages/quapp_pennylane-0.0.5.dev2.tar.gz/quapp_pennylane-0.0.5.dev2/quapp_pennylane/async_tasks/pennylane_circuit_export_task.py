#  Quapp Platform Project
#  pennylane_circuit_export_task.py
#  Copyright © CITYNOW Co. Ltd. All rights reserved.
import pennylane as qml
import sys
import time
from abc import ABC
from quapp_common.async_tasks.export_circuit_task import CircuitExportTask


class _PennylaneDrawableCircuit:
    """Adapter wrapping a PennyLane circuit to satisfy CircuitExportTask's .draw() contract."""

    def __init__(self, circuit):
        self._circuit = circuit

    def draw(self, **kwargs):
        """
        Generate a visual representation of a quantum circuit.

        This method constructs a quantum circuit by invoking the internal `_circuit`
         method and then creates a corresponding visualization using matplotlib.
        QuantumTape is used to capture the quantum circuit, while the `qml.draw_mpl`
        function is used to render the visualization.

        :param kwargs: Optional keyword arguments to be passed to internal
            operations or specific quantum circuit functionality.
        :return: A matplotlib figure containing the visualization of the quantum
            circuit generated.
        :rtype: matplotlib.figure.Figure
        """
        with qml.tape.QuantumTape() as tape:
            self._circuit()
        wires = tape.wires.tolist() or [0]
        dev = qml.device("default.qubit", wires=wires)
        qnode = qml.QNode(self._circuit, dev)
        fig, _ = qml.draw_mpl(qnode)()
        return fig


class PennylaneCircuitExportTask(CircuitExportTask, ABC):
    """
    Handles the exportation of Pennylane circuits.

    This class is responsible for transpiling quantum circuits using Pennylane's
    framework. It provides functionality to translate circuit data into a format
    that can be handled and processed efficiently. The transpilation process is
    monitored and logged for debugging, performance tracking, and error handling.

    :ivar circuit_data_holder: Holder object containing circuit-related data,
        such as the quantum circuit to be transpiled.
    :type circuit_data_holder: CircuitDataHolder
    :ivar logger: Logger instance used for logging information, warnings,
        debugging details, and errors during circuit export and transpilation.
    :type logger: logging.Logger
    """

    def _transpile_circuit(self):
        self.logger.info("Transpiling circuit: start")
        try:
            self.logger.debug(
                    f"Runtime | python_impl={getattr(sys.implementation, 'name', 'unknown')}"
                    f" | version={sys.version.split()[0]}")
        except Exception as env_err:
            self.logger.warning(f"Unable to log Python runtime info: {env_err}")

        start = time.perf_counter()
        try:
            circuit = self.circuit_data_holder.circuit
            if circuit is None:
                raise ValueError("No circuit found in circuit_data_holder")

            transpiled_circuit = _PennylaneDrawableCircuit(circuit)
            self.logger.info("Transpiling circuit: completed successfully")
            return transpiled_circuit
        except Exception as e:
            self.logger.exception(f"Transpiling circuit failed: {e}")
            raise
        finally:
            duration = time.perf_counter() - start
            self.logger.debug(f"Transpiling circuit: duration_s={duration:.6f}")
