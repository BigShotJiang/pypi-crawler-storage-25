import pennylane as _pl
import pennylane.measurements as _pl_measurements
import pennylane.operation as _pl_operation

# pennylane-rigetti==0.36.0 compatibility shims for PennyLane 0.37+
#
# PennyLane 0.37+: measurements.Expectation renamed to ExpectationMP
if not hasattr(_pl_measurements, 'Expectation'):
    _pl_measurements.Expectation = _pl_measurements.ExpectationMP

# PennyLane 0.40+: operation.Tensor removed; replaced by ops.Prod for tensor
# product observables. Rigetti uses Tensor only in isinstance() checks alongside
# Prod, so aliasing is correct — no Tensor instances exist in PL 0.40+.
if not hasattr(_pl_operation, 'Tensor'):
    from pennylane.ops import Prod as _Prod
    _pl_operation.Tensor = _Prod

# PennyLane ~0.40+: QubitDevice moved from pennylane top-level to pennylane.devices.
# Rigetti device.py does: from pennylane import QubitDevice
if not hasattr(_pl, 'QubitDevice'):
    from pennylane.devices import QubitDevice as _QubitDevice
    _pl.QubitDevice = _QubitDevice

# Pydantic v2 removed __config__ from BaseModel instances.
# qcs-api-client<0.22.0 (required by pennylane-rigetti==0.36.0) accesses
# self.__config__.env_prefix in _EnvironmentBaseModel._read_env. In Pydantic v2,
# __getattr__ raises AttributeError instead of falling through to class MRO.
# Setting __config__ directly on BaseModel lets the instance lookup resolve it via
# the class without hitting __getattr__. env_prefix='' (falsy) makes _read_env()
# return {} immediately — safe because QCSClientConfiguration.load() already
# reads QCS_* env vars via os.getenv before constructing model instances.
import pydantic as _pydantic
if not hasattr(_pydantic.BaseModel, '__config__'):
    class _PydanticV1Config:
        env_prefix: str = ''
    _pydantic.BaseModel.__config__ = _PydanticV1Config
