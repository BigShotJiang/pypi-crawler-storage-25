"""frameio.auth — OAuth 2.0 authentication for the Frame.io V4 SDK.

Provides three authentication flows (sync and async):

- :class:`ServerToServerAuth` / :class:`AsyncServerToServerAuth` — client_credentials
- :class:`WebAppAuth` / :class:`AsyncWebAppAuth` — authorization_code
- :class:`SPAAuth` / :class:`AsyncSPAAuth` — authorization_code + PKCE

Usage::

    from frameio import Frameio
    from frameio.auth import ServerToServerAuth

    auth = ServerToServerAuth(client_id="...", client_secret="...")
    client = Frameio(token=auth.get_token)
"""

from ._errors import (
    AuthenticationError,
    ConfigurationError,
    FrameioAuthError,
    NetworkError,
    PKCEError,
    RateLimitError,
    TokenExpiredError,
)
from ._http import DEFAULT_IMS_BASE_URL, aclose_clients, close_clients
from .server_to_server import AsyncServerToServerAuth, ServerToServerAuth
from .spa import AsyncSPAAuth, AuthorizationUrlResult, SPAAuth
from .web_app import AsyncWebAppAuth, WebAppAuth

__all__ = [
    # Auth flows (sync)
    "ServerToServerAuth",
    "WebAppAuth",
    "SPAAuth",
    # Auth flows (async)
    "AsyncServerToServerAuth",
    "AsyncWebAppAuth",
    "AsyncSPAAuth",
    # Data classes
    "AuthorizationUrlResult",
    # Config
    "DEFAULT_IMS_BASE_URL",
    # Client lifecycle
    "close_clients",
    "aclose_clients",
    # Errors
    "FrameioAuthError",
    "AuthenticationError",
    "TokenExpiredError",
    "NetworkError",
    "RateLimitError",
    "PKCEError",
    "ConfigurationError",
]
