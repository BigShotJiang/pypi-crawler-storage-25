"""
sim/engine.py — Thread-safe MuJoCo simulation engine.

Loads an MJCF model, runs mj_step() in a background thread,
and exposes state read/write through a lock.
Optionally launches the passive viewer for visual debugging.

Usage:
    engine = SimEngine("sim/models/xarm6/xarm6.xml")
    engine.start(viewer=True)
    # ... read/write via engine.get_qpos(), engine.set_ctrl() ...
    engine.stop()
"""

import math
import time
import threading
import logging
from pathlib import Path
from typing import Optional

log = logging.getLogger("orion_bridge.sim.engine")

# Only import the core mujoco module at top level.
# mujoco.viewer is imported lazily inside start() to avoid
# AttributeError crashes on Python 3.13 / Windows where the
# viewer's _simulate binding may fail to load (MjrRect bug).
try:
    import mujoco
except ImportError:
    mujoco = None


class SimEngine:
    """
    Self-contained MuJoCo physics loop.

    Runs simulation in a daemon thread at the model's timestep rate.
    All public methods are thread-safe (protected by self._lock).
    """

    def __init__(self, mjcf_path: str, realtime: bool = True):
        if mujoco is None:
            raise ImportError(
                "MuJoCo Python bindings required: pip install mujoco"
            )

        resolved = Path(mjcf_path).resolve()
        if not resolved.exists():
            raise FileNotFoundError(f"MJCF not found: {resolved}")

        log.info(f"Loading MJCF: {resolved}")
        self._model = mujoco.MjModel.from_xml_path(str(resolved))
        self._data = mujoco.MjData(self._model)

        self._lock = threading.Lock()
        self._running = False
        self._realtime = realtime
        self._sim_thread: Optional[threading.Thread] = None
        self._viewer_handle = None

        # cache useful sizes
        self.nq = self._model.nq      # qpos dimension
        self.nv = self._model.nv      # qvel dimension
        self.nu = self._model.nu      # ctrl dimension
        self.dt = self._model.opt.timestep

        log.info(
            f"Model loaded: nq={self.nq}, nv={self.nv}, nu={self.nu}, "
            f"dt={self.dt*1000:.1f}ms"
        )

    # ── lifecycle ─────────────────────────────────────────────

    def start(self, viewer: bool = False) -> None:
        """Start physics thread + optional passive viewer."""
        if self._running:
            log.warning("SimEngine already running")
            return

        self._running = True

        if viewer:
            self._try_launch_viewer()

        self._sim_thread = threading.Thread(
            target=self._physics_loop, daemon=True, name="mj-physics"
        )
        self._sim_thread.start()
        log.info("Physics thread started")

    def _try_launch_viewer(self) -> None:
        """
        Attempt to launch the MuJoCo passive viewer.

        Handles three failure modes:
        1. mujoco.viewer import fails (ImportError)
        2. Viewer binding is broken — AttributeError on MjrRect etc.
        3. Any other runtime error (OpenGL, GLFW, etc.)

        On failure, the engine continues in headless mode.
        """
        try:
            import mujoco.viewer as mj_viewer
            self._viewer_handle = mj_viewer.launch_passive(
                self._model, self._data
            )
            log.info("MuJoCo passive viewer launched")
        except ImportError:
            log.warning(
                "mujoco.viewer not available — running headless"
            )
            self._viewer_handle = None
        except AttributeError as e:
            # Known issue: Python 3.13 + mujoco 3.6.0 on Windows
            # raises AttributeError: module 'mujoco' has no attribute 'MjrRect'
            log.warning(
                f"Viewer binding broken ({e}) — running headless. "
                f"Try: pip install mujoco==3.5.0"
            )
            self._viewer_handle = None
        except Exception as e:
            log.warning(f"Could not launch viewer: {e} — running headless")
            self._viewer_handle = None

    def stop(self) -> None:
        """Stop physics and close viewer."""
        self._running = False
        if self._sim_thread and self._sim_thread.is_alive():
            self._sim_thread.join(timeout=3.0)
        if self._viewer_handle is not None:
            try:
                self._viewer_handle.close()
            except Exception:
                pass
            self._viewer_handle = None
        log.info("SimEngine stopped")

    @property
    def is_running(self) -> bool:
        return self._running

    # ── thread-safe accessors ─────────────────────────────────

    def get_qpos(self) -> list:
        """Return copy of qpos (joint positions)."""
        with self._lock:
            return list(self._data.qpos)

    def get_qvel(self) -> list:
        """Return copy of qvel (joint velocities)."""
        with self._lock:
            return list(self._data.qvel)

    def get_ctrl(self) -> list:
        """Return copy of ctrl (actuator commands)."""
        with self._lock:
            return list(self._data.ctrl)

    def set_ctrl(self, ctrl: list) -> None:
        """Set actuator commands (length must match self.nu)."""
        if len(ctrl) != self.nu:
            raise ValueError(f"ctrl length {len(ctrl)} != nu {self.nu}")
        with self._lock:
            for i, v in enumerate(ctrl):
                self._data.ctrl[i] = v

    def set_ctrl_index(self, index: int, value: float) -> None:
        """Set a single actuator command by index."""
        if index < 0 or index >= self.nu:
            raise ValueError(f"ctrl index {index} out of range [0, {self.nu})")
        with self._lock:
            self._data.ctrl[index] = value

    def get_sensor_data(self) -> list:
        """Return copy of sensor data."""
        with self._lock:
            return list(self._data.sensordata)

    def get_time(self) -> float:
        """Return simulation time in seconds."""
        with self._lock:
            return float(self._data.time)

    def reset(self) -> None:
        """Reset simulation to initial state."""
        with self._lock:
            mujoco.mj_resetData(self._model, self._data)
        log.info("Simulation reset")

    # ── named joint helpers ───────────────────────────────────

    def joint_name_to_qpos_index(self, name: str) -> int:
        """Get qpos index for a named joint."""
        jnt_id = mujoco.mj_name2id(
            self._model, mujoco.mjtObj.mjOBJ_JOINT, name
        )
        if jnt_id < 0:
            raise KeyError(f"Joint '{name}' not found in model")
        return self._model.jnt_qposadr[jnt_id]

    def actuator_name_to_index(self, name: str) -> int:
        """Get ctrl index for a named actuator."""
        act_id = mujoco.mj_name2id(
            self._model, mujoco.mjtObj.mjOBJ_ACTUATOR, name
        )
        if act_id < 0:
            raise KeyError(f"Actuator '{name}' not found in model")
        return act_id

    # ── physics loop ──────────────────────────────────────────

    def _physics_loop(self) -> None:
        """Main simulation loop — runs in background thread."""
        wall_start = time.perf_counter()
        sim_start = self._data.time

        while self._running:
            with self._lock:
                mujoco.mj_step(self._model, self._data)

            # sync viewer if active
            if self._viewer_handle is not None:
                try:
                    if not self._viewer_handle.is_running():
                        log.info("Viewer closed by user")
                        self._viewer_handle = None
                    else:
                        self._viewer_handle.sync()
                except Exception:
                    self._viewer_handle = None

            # real-time pacing
            if self._realtime:
                sim_elapsed = self._data.time - sim_start
                wall_elapsed = time.perf_counter() - wall_start
                sleep_time = sim_elapsed - wall_elapsed
                if sleep_time > 0:
                    time.sleep(sleep_time)

        log.debug("Physics loop exited")