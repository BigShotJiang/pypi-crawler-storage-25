"""
sim/collision.py — Read-only self-collision checker for MuJoCo xArm models.

Loads a separate MjModel/MjData (independent of SimEngine) and uses
mj_forward() to sweep a linearly-interpolated trajectory for contacts
that fall outside the expected structural / resting-contact baseline.
"""

import math
import threading
from pathlib import Path

import numpy as np

try:
    import mujoco
except ImportError:
    mujoco = None  # type: ignore[assignment]

_DEFAULT_MJCF       = "sim/models/xarm6/scene_xarm6.xml"
_IK_LAMBDA          = 0.01   # damping factor λ for pseudoinverse (avoids singularities)
_IK_MAX_RESIDUAL_MM = 5.0    # maximum allowed final position error in mm


class CollisionChecker:
    """
    Read-only MuJoCo self-collision checker — no physics thread.

    Instantiate once per MJCF and reuse across calls. All public
    methods are thread-safe (a single lock serialises mj_forward calls
    on the shared MjData scratch buffer).

    Args:
        mjcf_path: Path to the MJCF scene file.  Accepts absolute paths,
                   paths relative to the package root, or paths relative
                   to CWD.  Defaults to sim/models/xarm6/scene_xarm6.xml.
    """

    def __init__(self, mjcf_path: str = "") -> None:
        if mujoco is None:
            raise ImportError("MuJoCo Python bindings required: pip install mujoco")

        resolved = self._resolve(mjcf_path)
        self._model = mujoco.MjModel.from_xml_path(str(resolved))
        self._data  = mujoco.MjData(self._model)
        self._lock  = threading.Lock()

        # qpos / dof / joint-ID arrays for arm joints (joint1 .. joint6 or joint7)
        self._qpos_idx:  list[int] = []   # index into data.qpos
        self._dof_idx:   list[int] = []   # index into data.qvel / Jacobian columns
        self._joint_ids: list[int] = []   # model joint id (for jnt_range clamping)
        for i in range(1, 8):
            jid = mujoco.mj_name2id(
                self._model, mujoco.mjtObj.mjOBJ_JOINT, f"joint{i}"
            )
            if jid < 0:
                break
            self._qpos_idx.append(int(self._model.jnt_qposadr[jid]))
            self._dof_idx.append(int(self._model.jnt_dofadr[jid]))
            self._joint_ids.append(jid)
        self._n = len(self._qpos_idx)

        # TCP site for IK — prefer the named site, fall back to a known arm body
        self._site_id: int = mujoco.mj_name2id(
            self._model, mujoco.mjtObj.mjOBJ_SITE, "link_tcp"
        )
        self._eef_body_id: int = -1
        if self._site_id < 0:
            for name in ("xarm_gripper_base_link", "link7", "link6"):
                bid = mujoco.mj_name2id(
                    self._model, mujoco.mjtObj.mjOBJ_BODY, name
                )
                if bid >= 0:
                    self._eef_body_id = bid
                    break

        # pairs to ignore: structural + resting contacts at q = 0
        self._excluded: set[frozenset] = self._build_excluded_pairs()

    # ── init helpers ──────────────────────────────────────────────────────────

    @staticmethod
    def _resolve(path: str) -> Path:
        """Resolve MJCF path to an absolute Path."""
        pkg = Path(__file__).resolve().parent.parent  # orion_bridge/
        if path:
            p = Path(path)
            if p.is_absolute() and p.exists():
                return p
            if (pkg / path).exists():
                return pkg / path
            if p.exists():
                return p.resolve()
        return pkg / _DEFAULT_MJCF

    def _build_excluded_pairs(self) -> set[frozenset]:
        """
        Build the set of geom-index frozensets that should never trigger
        a collision alert:

        1. Same-body geom pairs (intra-body structure).
        2. Adjacent-body pairs (parent ↔ child links that naturally touch).
        3. Any contact active at the zero pose (resting contacts — e.g.
           gripper pads resting against knuckle geometry).
        """
        m = self._model
        excluded: set[frozenset] = set()

        # Passes 1 & 2 — structural adjacency
        for i in range(m.ngeom):
            bi = int(m.geom_bodyid[i])
            for j in range(i + 1, m.ngeom):
                bj = int(m.geom_bodyid[j])
                if bi == bj:
                    excluded.add(frozenset((i, j)))
                    continue
                # adjacent if one body is the direct parent of the other
                if int(m.body_parentid[bi]) == bj or int(m.body_parentid[bj]) == bi:
                    excluded.add(frozenset((i, j)))

        # Pass 3 — resting contacts at q = 0 (MjData already zero-initialised)
        mujoco.mj_forward(m, self._data)
        for k in range(self._data.ncon):
            c = self._data.contact[k]
            excluded.add(frozenset((int(c.geom1), int(c.geom2))))

        return excluded

    # ── internal helpers ──────────────────────────────────────────────────────

    def _geom_name(self, geom_id: int) -> str:
        name = mujoco.mj_id2name(self._model, mujoco.mjtObj.mjOBJ_GEOM, geom_id)
        return name if name else f"geom_{geom_id}"

    def _get_eef_pos(self) -> np.ndarray:
        """TCP position in metres (world frame) from current data state."""
        if self._site_id >= 0:
            return self._data.site_xpos[self._site_id].copy()
        return self._data.xpos[self._eef_body_id].copy()

    def _get_eef_jac(self) -> np.ndarray:
        """
        Translational Jacobian restricted to arm joints, shape (3, n).

        Uses mj_jacSite when a TCP site is available (more accurate —
        accounts for the gripper offset), otherwise falls back to mj_jacBody
        at the end-effector body origin.
        """
        jacp = np.zeros((3, self._model.nv))
        if self._site_id >= 0:
            mujoco.mj_jacSite(self._model, self._data, jacp, None, self._site_id)
        else:
            mujoco.mj_jacBody(self._model, self._data, jacp, None, self._eef_body_id)
        return jacp[:, self._dof_idx]  # (3, n) — arm columns only

    # ── public API ────────────────────────────────────────────────────────────

    def check_trajectory(
        self,
        current_angles_deg: list[float],
        target_angles_deg: list[float],
        steps: int = 20,
    ) -> dict:
        """
        Sweep a straight-line joint-space trajectory for self-collisions.

        Linearly interpolates from *current_angles_deg* to *target_angles_deg*
        in *steps* increments.  At each step mj_forward() is called and active
        contacts are checked against the excluded baseline.

        Returns:
            ``{"safe": True}`` when the full trajectory is clear, or on the
            first detected collision::

                {
                    "safe": False,
                    "collision_at_step": int,   # 1-indexed step number
                    "progress": float,          # fraction of trajectory (0–1)
                    "geom1": str,
                    "geom2": str,
                    "collision_angles_deg": list[float],
                }
        """
        current_rad = [math.radians(a) for a in current_angles_deg]
        target_rad  = [math.radians(a) for a in target_angles_deg]
        n = self._n

        with self._lock:
            for step in range(1, steps + 1):
                t = step / steps
                for i in range(n):
                    self._data.qpos[self._qpos_idx[i]] = (
                        current_rad[i] + t * (target_rad[i] - current_rad[i])
                    )
                mujoco.mj_forward(self._model, self._data)

                for k in range(self._data.ncon):
                    c = self._data.contact[k]
                    pair = frozenset((int(c.geom1), int(c.geom2)))
                    if pair not in self._excluded:
                        return {
                            "safe": False,
                            "collision_at_step": step,
                            "progress": round(t, 3),
                            "geom1": self._geom_name(int(c.geom1)),
                            "geom2": self._geom_name(int(c.geom2)),
                            "collision_angles_deg": [
                                round(math.degrees(self._data.qpos[self._qpos_idx[i]]), 3)
                                for i in range(n)
                            ],
                        }

        return {"safe": True}

    def check_joint_move(
        self,
        current_angles_deg: list[float],
        joint_id: int,
        target_angle: float,
        steps: int = 20,
    ) -> dict:
        """
        Check a single-joint move for self-collisions.

        Builds the full target array from *current_angles_deg* with only
        joint *joint_id* (1-indexed, matching xArm convention) changed to
        *target_angle* degrees, then delegates to :meth:`check_trajectory`.
        """
        target = list(current_angles_deg)
        target[joint_id - 1] = target_angle
        return self.check_trajectory(current_angles_deg, target, steps=steps)

    def check_linear_move(
        self,
        current_angles_deg: list[float],
        target_tcp: dict,
        steps: int = 20,
    ) -> dict:
        """
        Validate a Cartesian straight-line move using Jacobian-based IK.

        Interpolates the TCP linearly from its current position to
        *target_tcp* in *steps* increments.  At each waypoint one
        damped-pseudoinverse IK step is applied to follow the path, then
        contacts are checked against the excluded baseline.

        Args:
            current_angles_deg: Current joint angles in degrees (N elements).
            target_tcp: Target TCP position in mm — ``{"x": float, "y": float, "z": float}``.
                        Matches the format of ``_get_position()["tcp"]``.
            steps: Number of Cartesian interpolation steps.

        Returns:
            ``{"safe": True, "final_angles_deg": list[float]}`` — path clear,
            IK converged, caller may use the angles directly for joint-space
            execution.

            ``{"safe": False, "reason": "ik_failed", "residual_mm": float}``
            — IK diverged; the final TCP is more than 5 mm from the target.

            ``{"safe": False, "collision_at_step": int, "progress": float,
            "geom1": str, "geom2": str, "collision_angles_deg": list[float]}``
            — collision detected mid-path (same schema as check_trajectory).
        """
        # Target in metres (MuJoCo world frame)
        target_m = np.array([
            target_tcp["x"] / 1000.0,
            target_tcp["y"] / 1000.0,
            target_tcp["z"] / 1000.0,
        ])
        n     = self._n
        lam2I = _IK_LAMBDA ** 2 * np.eye(3)  # pre-built damping term

        with self._lock:
            # ── seed qpos from current joint angles ───────────────────────────
            for i in range(n):
                self._data.qpos[self._qpos_idx[i]] = math.radians(current_angles_deg[i])
            mujoco.mj_forward(self._model, self._data)

            start_pos = self._get_eef_pos()  # TCP at t=0, metres

            for step in range(1, steps + 1):
                t  = step / steps
                wp = start_pos + t * (target_m - start_pos)  # Cartesian waypoint

                # ── one damped-pseudoinverse IK step ──────────────────────────
                dx    = wp - self._get_eef_pos()              # position error (m)
                J     = self._get_eef_jac()                   # (3, n)
                JJT   = J @ J.T                               # (3, 3)
                J_inv = J.T @ np.linalg.inv(JJT + lam2I)     # (n, 3) pseudoinverse
                dq    = J_inv @ dx                            # (n,)

                # Apply delta and clamp to model joint limits
                for i in range(n):
                    lo = float(self._model.jnt_range[self._joint_ids[i], 0])
                    hi = float(self._model.jnt_range[self._joint_ids[i], 1])
                    q  = self._data.qpos[self._qpos_idx[i]] + float(dq[i])
                    self._data.qpos[self._qpos_idx[i]] = max(lo, min(hi, q))

                mujoco.mj_forward(self._model, self._data)

                # ── collision check ───────────────────────────────────────────
                for k in range(self._data.ncon):
                    c    = self._data.contact[k]
                    pair = frozenset((int(c.geom1), int(c.geom2)))
                    if pair not in self._excluded:
                        return {
                            "safe": False,
                            "collision_at_step": step,
                            "progress": round(t, 3),
                            "geom1": self._geom_name(int(c.geom1)),
                            "geom2": self._geom_name(int(c.geom2)),
                            "collision_angles_deg": [
                                round(math.degrees(self._data.qpos[self._qpos_idx[i]]), 3)
                                for i in range(n)
                            ],
                        }

            # ── final residual check ──────────────────────────────────────────
            residual_mm = float(np.linalg.norm(self._get_eef_pos() - target_m) * 1000.0)
            if residual_mm > _IK_MAX_RESIDUAL_MM:
                return {
                    "safe": False,
                    "reason": "ik_failed",
                    "residual_mm": round(residual_mm, 2),
                }

            return {
                "safe": True,
                "final_angles_deg": [
                    round(math.degrees(self._data.qpos[self._qpos_idx[i]]), 3)
                    for i in range(n)
                ],
            }
