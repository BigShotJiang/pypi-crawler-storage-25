"""
orion_bridge/cli.py — Interactive CLI and bridge entry point.

Extracted from bridge.py (Phase 3, Step 7).
Connects all modules: config, ui, dispatcher, transport, logger, http.

Usage:
    orion                       # interactive menu
    orion --local               # skip server, local only
    orion --config lab.json     # autostart from saved config
    python -m orion_bridge      # same as 'orion'
"""

import os
import sys
import time
import asyncio
import argparse
import logging
import threading

from orion_bridge import __version__, __codename__
from orion_bridge.config import (
    LABS, DEVICE_TYPES, CONFIG_FILE,
    load_config, save_config,
)
from orion_bridge.ui import (
    RICH_UI,
    print_header, print_devices, print_connection_panel,
    print_menu, print_device_types, pick_lab, prompt,
    msg_success, msg_error, msg_warning, msg_info,
    print_bridge_active,
)
from orion_bridge.dispatcher import build_dispatcher
from orion_bridge.logger import sb_logger

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("orion_bridge")

try:
    import roslibpy
except ImportError:
    roslibpy = None


# ── Back exception for menu navigation ────────────────────────

class _BackException(Exception):
    pass


def _prompt(label="", default=""):
    """Prompt with 'back' support."""
    value = prompt(label, default)
    if value.lower() in ("back", "b"):
        raise _BackException()
    return value


# ── PLC HTTP sidecar ──────────────────────────────────────────

PLC_HTTP_PORT    = int(os.getenv("PLC_HTTP_PORT", "5000"))
PLC_HTTP_ENABLED = os.getenv("PLC_HTTP_ENABLED", "true").lower() == "true"
_plc_ref = None


def _start_plc_http(dispatcher):
    global _plc_ref
    plc_handlers = dispatcher.handlers.get("plc", {})
    if not plc_handlers:
        log.info("PLC HTTP API: no PLCs, skipping")
        return
    _plc_ref = next(iter(plc_handlers.values()))
    try:
        from orion_bridge.http.plc_api import make_plc_app
        app = make_plc_app(_plc_ref)
        t = threading.Thread(
            target=lambda: app.run(
                host="0.0.0.0", port=PLC_HTTP_PORT,
                debug=False, use_reloader=False,
            ),
            daemon=True,
        )
        t.start()
        log.info(f"PLC HTTP API on :{PLC_HTTP_PORT}")
    except ImportError:
        log.warning("Flask not installed — PLC HTTP API off")
    except Exception as e:
        log.error(f"PLC HTTP API failed: {e}")


# ── Menu actions ──────────────────────────────────────────────

def _add_device(config):
    try:
        print_device_types(DEVICE_TYPES)
        choice = _prompt("Select type")
        dt = DEVICE_TYPES.get(choice)
        if not dt:
            msg_error("Invalid type.")
            return

        dtype = dt["type"]
        name  = _prompt("Device name/ID (e.g. 'xarm-lab1')")
        if not name:
            msg_error("Name required.")
            return

        existing = [d.get("id") for d in config.get("devices", [])]
        if name in existing:
            msg_error(f"'{name}' already exists.")
            return

        dev = {"type": dtype, "id": name}

        if dtype == "xarm":
            dev["ip"] = _prompt("xArm IP", "192.168.1.185")
        elif dtype == "abb":
            dev["ip"]   = _prompt("ABB IP", "192.168.125.1")
            dev["port"] = int(_prompt("Port", "1025"))
        elif dtype == "plc":
            msg_info("Enter PLC IPs one by one (empty to finish):")
            ips = []
            while True:
                ip = _prompt("PLC IP")
                if not ip:
                    break
                ips.append(ip)
            if not ips:
                msg_error("Need at least one IP.")
                return
            dev["ips"] = ips
        elif dtype == "shell":
            dev["ip"] = "localhost"

        config.setdefault("devices", []).append(dev)
        msg_success(f"Added {dtype} '{name}'")
    except _BackException:
        msg_info("Cancelled.")


def _remove_device(config):
    devices = config.get("devices", [])
    if not devices:
        msg_info("Nothing to remove.")
        return
    try:
        print_devices(config)
        idx = int(_prompt("Device # to remove (0=cancel)")) - 1
        if idx < 0 or idx >= len(devices):
            msg_info("Cancelled.")
            return
        removed = devices.pop(idx)
        msg_success(f"Removed {removed['type']}/{removed['id']}")
    except _BackException:
        msg_info("Cancelled.")
    except ValueError:
        msg_error("Invalid number.")


def _configure_server(config):
    try:
        lab = pick_lab(LABS)

        if lab is None:
            config.update({"server": None, "token": None, "lab_name": "Local"})
            msg_success("Local mode")
            return

        config["server"]   = lab["server"]
        config["token"]    = lab.get("token", "")
        config["lab_name"] = lab.get("lab_name", lab.get("name", "Custom"))

        if "devices" in lab:
            config["devices"] = lab["devices"]
            device_summary = ", ".join(
                d.get("id", d.get("type", "?")) for d in lab["devices"]
            )
            msg_success(f"Lab: {config['lab_name']}")
            msg_info(f"Devices: {device_summary}")
        else:
            msg_success(f"Lab: {config['lab_name']}")

    except _BackException:
        msg_info("Cancelled.")


def _save(config):
    save_config(config)
    msg_success(f"Config saved → {CONFIG_FILE}")


# ── Interactive menu ──────────────────────────────────────────

def interactive_cli():
    config = load_config()
    print_header()
    print_connection_panel(config)
    print_devices(config)

    while True:
        print_menu()
        choice = prompt()

        if choice == "1":
            _add_device(config)
        elif choice == "2":
            _remove_device(config)
        elif choice == "3":
            _configure_server(config)
        elif choice == "4":
            print_devices(config)
            print_connection_panel(config)
        elif choice == "5":
            _save(config)
        elif choice == "6":
            _save(config)
            return config
        elif choice == "0":
            save_q = prompt("Save before exit? (y/n)", "y")
            if save_q != "n":
                _save(config)
            return None
        elif choice.lower() in ("back", "b"):
            msg_info("Already at main menu.")
        else:
            msg_error("Invalid option.")


# ── Bridge startup ────────────────────────────────────────────

def start_bridge(config, local=False):
    if local:
        config["server"] = None

    dispatcher = build_dispatcher(config.get("devices", []), sb_logger=sb_logger)
    dispatcher.connect_all()

    if PLC_HTTP_ENABLED:
        _start_plc_http(dispatcher)

    status = dispatcher.get_status()
    print_bridge_active(
        config, status,
        plc_http_port=PLC_HTTP_PORT if PLC_HTTP_ENABLED and _plc_ref else None,
    )

    try:
        if config.get("server") and config.get("token"):
            from orion_bridge.transport import ws_all_devices
            asyncio.run(
                ws_all_devices(
                    dispatcher,
                    config["server"],
                    config["token"],
                    config.get("devices", []),
                )
            )
        else:
            print("  Running local. Ctrl+C to stop.\n")
            while True:
                time.sleep(1)
    except KeyboardInterrupt:
        print("\n\nStopping...")
    finally:
        dispatcher.disconnect_all()
        print("Done.")


# ── Entry point ───────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="ORION Lab Bridge")
    parser.add_argument("--local",  action="store_true", help="No server, local only")
    parser.add_argument("--config", type=str,            help="Config file (skip interactive menu)")
    args = parser.parse_args()

    if args.config:
        import json
        with open(args.config) as f:
            config = json.load(f)
        start_bridge(config, local=args.local)
    else:
        config = interactive_cli()
        if config:
            start_bridge(config, local=args.local)
        else:
            print("  Bye.")


if __name__ == "__main__":
    main()