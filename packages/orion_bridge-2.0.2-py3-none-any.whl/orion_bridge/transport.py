"""
transport.py — WebSocket client, telemetry push, reactive event drain.

One WS connection per device, all running in parallel.
Extracted from bridge.py (Phase 3, Step 6).
"""

import json
import asyncio
import logging
from datetime import datetime, timezone
from typing import Optional

import websockets

from .dispatcher import BridgeDispatcher
from .reactive import ReactiveContextManager, MovementObserver

log = logging.getLogger("orion_bridge.transport")

# Try to import UI logging (optional)
try:
    from .ui import log_ws_event, RICH_AVAILABLE
except ImportError:
    RICH_AVAILABLE = False
    log_ws_event = None


def _get_device_model(dispatcher: BridgeDispatcher, device_type: str, device_id: str) -> str:
    """
    Extract the model name from the handler for WS registration.
    This allows the agent to look up the correct skill card in Supabase.

    Returns e.g. "xarm7", "xarm6", "lite6", "abb_irb1100", "s7-1200".
    """
    try:
        handler = dispatcher.get_handler(device_type, device_id)

        # xArm handlers expose num_joints — derive model name
        if device_type == "xarm" and hasattr(handler, "num_joints"):
            n = handler.num_joints
            return f"xarm{n}"

        # For other device types, use device_type as fallback
        return device_type

    except Exception:
        return device_type


def _get_device_metadata(dispatcher: BridgeDispatcher, device_type: str, device_id: str) -> dict:
    """
    Build extended metadata dict for WS registration.
    Includes the handler's capability_card so the agent knows what
    actions and parameters are available without hardcoding.
    """
    meta = {}
    try:
        handler = dispatcher.get_handler(device_type, device_id)

        if hasattr(handler, "is_connected"):
            meta["connected"] = handler.is_connected

        
        if hasattr(handler, "capability_card"):
            try:
                meta["capability_card"] = handler.capability_card()
            except Exception as e:
                log.warning(f"capability_card() failed for {device_id}: {e}")

   
        if device_type == "xarm" and hasattr(handler, "num_joints"):
            meta["num_joints"] = handler.num_joints

    except Exception:
        pass

    return meta

async def _ws_loop(
    device_id: str,
    device_type: str,
    device_ips: list,
    dispatcher: BridgeDispatcher,
    server_url: str,
    token: str,
    ctx_mgr: ReactiveContextManager,
    event_queue: asyncio.Queue,
):
    """Keep a WS connection alive for one device. Reconnects forever."""
    while True:
        try:
            log.info(f"[{device_id}] connecting {server_url}...")
            async with websockets.connect(
                server_url, ping_interval=20, ping_timeout=10
            ) as ws:
                # ── register ──────────────────────────────────
                model_name = _get_device_model(dispatcher, device_type, device_id)
                device_meta = _get_device_metadata(dispatcher, device_type, device_id)

                await ws.send(
                    json.dumps(
                        {
                            "token": token,
                            "robot_id": device_id,
                            "type": model_name,
                            "model": model_name,
                            "capabilities": [device_type],
                            "ips": device_ips,
                            **device_meta,
                        }
                    )
                )
                raw = await asyncio.wait_for(ws.recv(), timeout=10)
                reg = json.loads(raw)
                if reg.get("type") != "registered":
                    log.warning(
                        f"[{device_id}] bad registration: {raw[:200]}"
                    )
                    continue
                log.info(f"[{device_id}] registered as {model_name} (ips={device_ips})")

                # ── background tasks ──────────────────────────
                observer: Optional[MovementObserver] = None
                try:
                    handler = dispatcher.get_handler(device_type, device_id)
                    loop = asyncio.get_event_loop()
                    observer = MovementObserver(
                        device_id, device_type, handler,
                        ctx_mgr, event_queue, loop,
                    )
                    observer.start()
                except Exception as e:
                    log.warning(
                        f"[{device_id}] MovementObserver not started: {e}"
                    )

                telem_task = asyncio.create_task(
                    _telemetry_loop(ws, device_id, device_type, dispatcher)
                )
                drain_task = asyncio.create_task(
                    _event_drain(ws, device_id, event_queue)
                )

                try:
                    await _command_loop(
                        ws, device_id, device_type, dispatcher, ctx_mgr
                    )
                finally:
                    telem_task.cancel()
                    drain_task.cancel()
                    if observer:
                        observer.stop()

        except websockets.ConnectionClosed as e:
            log.warning(f"[{device_id}] closed: {e}, reconnecting 5s...")
        except asyncio.TimeoutError:
            log.warning(f"[{device_id}] registration timeout, retry 5s...")
        except ConnectionRefusedError:
            log.warning(f"[{device_id}] refused, retry 10s...")
            await asyncio.sleep(5)
        except Exception as e:
            log.error(f"[{device_id}] unexpected: {e}, reconnecting 5s...")
        await asyncio.sleep(5)


async def _command_loop(
    ws, device_id, device_type, dispatcher, ctx_mgr
):
    """Process incoming commands from the server."""
    async for raw in ws:
        try:
            msg = json.loads(raw)

            # handle context updates
            if msg.get("type") == "bridge_context_update":
                ctx_mgr.update(msg)
                await ws.send(
                    json.dumps(
                        {
                            "type": "bridge_context_ack",
                            "device_id": device_id,
                            "mode": msg.get("mode"),
                            "reactive": msg.get("reactive_enabled"),
                            "timestamp": datetime.now(
                                timezone.utc
                            ).isoformat()
                            + "Z",
                        }
                    )
                )
                log.info(
                    f"[{device_id}] context updated → mode={msg.get('mode')}"
                )
                continue

            action = msg.get("action", msg.get("command", ""))
            rid = msg.get("id", "")

            if RICH_AVAILABLE and log_ws_event:
                log_ws_event(device_id, "in", action, request_id=rid)
            log.info(f"[{device_id}] ← {action} (id={rid})")

            # ensure routing info
            msg.setdefault("device_type", device_type)
            msg.setdefault("device_id", device_id)
            params = msg.get("params", {})
            if not msg.get("device_type") and isinstance(params, dict):
                msg["device_type"] = params.pop("_device_type", device_type)
            if not msg.get("device_id") and isinstance(params, dict):
                msg["device_id"] = params.pop("_device_id", device_id)

            result = dispatcher.dispatch(msg)
            await ws.send(json.dumps(result, default=str))

            if RICH_AVAILABLE and log_ws_event:
                log_ws_event(
                    device_id, "out", action,
                    status=result["status"],
                    request_id=result.get("id", ""),
                )
            log.info(f"[{device_id}] → {result['status']}")

        except json.JSONDecodeError:
            log.warning(f"[{device_id}] bad JSON: {raw[:100]}")
        except Exception as e:
            log.error(f"[{device_id}] cmd error: {e}")
            err_id = msg.get("id") if "msg" in dir() else None
            await ws.send(
                json.dumps({"id": err_id, "status": "error", "error": str(e)})
            )


async def _telemetry_loop(ws, device_id, device_type, dispatcher):
    """Push telemetry at ~10Hz."""
    while True:
        try:
            h = dispatcher.get_handler(device_type, device_id)
            if hasattr(h, "get_telemetry") and h.is_connected:
                t = h.get_telemetry()
                if t:
                    await ws.send(
                        json.dumps(
                            {
                                "type": "telemetry",
                                "device_id": device_id,
                                "device_type": device_type,
                                "data": t,
                                "timestamp": datetime.now(
                                    timezone.utc
                                ).isoformat()
                                + "Z",
                            }
                        )
                    )
        except Exception:
            pass
        await asyncio.sleep(0.1)


async def _event_drain(ws, device_id, event_queue):
    """Drain reactive events from the shared queue and send over WS."""
    while True:
        try:
            event = await asyncio.wait_for(event_queue.get(), timeout=0.5)
            if event.get("device_id") == device_id:
                await ws.send(json.dumps(event, default=str))
                log.info(
                    f"[{device_id}] → bridge_event "
                    f"'{event['data'].get('movement_kind')}'"
                )
            else:
                await event_queue.put(event)
        except asyncio.TimeoutError:
            pass
        except Exception as e:
            log.debug(f"[{device_id}] event_drain error: {e}")


async def ws_all_devices(
    dispatcher: BridgeDispatcher,
    server_url: str,
    token: str,
    device_configs: list = None,
):
    """Launch one WS connection per registered device."""
    ip_map = {}
    for dev in (device_configs or []):
        did = dev.get("id", "")
        ip_map[did] = [dev["ip"]] if dev.get("ip") else dev.get("ips", [])

    ctx_mgr = ReactiveContextManager()
    event_queue: asyncio.Queue = asyncio.Queue(maxsize=100)

    tasks = []
    for dtype, handlers in dispatcher.handlers.items():
        for did in handlers:
            tasks.append(
                _ws_loop(
                    did, dtype, ip_map.get(did, []),
                    dispatcher, server_url, token,
                    ctx_mgr, event_queue,
                )
            )

    if not tasks:
        log.warning("No devices to connect")
        return

    log.info(f"Starting {len(tasks)} WS connection(s)...")
    await asyncio.gather(*tasks)