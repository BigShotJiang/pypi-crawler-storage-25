"""ORION Lab Bridge — Modular device bridge for industrial robotics."""

__version__ = "2.0.0"
__codename__ = "unified"
