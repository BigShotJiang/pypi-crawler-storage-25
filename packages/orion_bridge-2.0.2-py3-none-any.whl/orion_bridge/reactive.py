"""
reactive.py — Reactive event system for practice mode.

Outbound bridge_event messages — practice mode only.
Does NOT touch request/response pipeline.

Extracted from bridge.py (Phase 3, Step 5).
"""

import math
import time
import threading
import asyncio
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from .handlers.base import DeviceHandler

log = logging.getLogger("orion_bridge.reactive")


# ── Reactive context ──────────────────────────────────────────

class ReactiveContextManager:
    """
    Holds the active session/practice context for one bridge process.
    Updated by bridge_context_update messages from the agent.
    Queried by MovementObserver before emitting any event.
    Thread-safe.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._ctx: Dict[str, Any] = {}

    def update(self, msg: dict) -> None:
        with self._lock:
            self._ctx = {
                "mode": msg.get("mode"),
                "reactive_enabled": bool(msg.get("reactive_enabled", False)),
                "session_id": msg.get("session_id", ""),
                "thread_id": msg.get("thread_id", ""),
                "user_id": msg.get("user_id", ""),
                "device_id": msg.get("device_id", ""),
                "practice": msg.get("practice", {}),
            }
        log.info(
            f"[ctx] updated → mode={msg.get('mode')} "
            f"reactive={msg.get('reactive_enabled')} "
            f"session={msg.get('session_id')}"
        )

    def clear(self) -> None:
        with self._lock:
            self._ctx = {}

    def is_active(self) -> bool:
        with self._lock:
            return (
                self._ctx.get("reactive_enabled") is True
                and self._ctx.get("mode") == "practice"
                and bool(self._ctx.get("session_id"))
                and bool(self._ctx.get("thread_id"))
                and bool(self._ctx.get("device_id"))
            )

    def snapshot(self) -> dict:
        with self._lock:
            return dict(self._ctx)


# ── Helper functions ──────────────────────────────────────────

def _position_error_mm(actual_tcp: dict, expected_pose: dict) -> Optional[float]:
    try:
        dx = actual_tcp["x"] - expected_pose["x"]
        dy = actual_tcp["y"] - expected_pose["y"]
        dz = actual_tcp["z"] - expected_pose["z"]
        return round(math.sqrt(dx * dx + dy * dy + dz * dz), 2)
    except Exception:
        return None


def _orientation_error_deg(actual_tcp: dict, expected_pose: dict) -> Optional[float]:
    try:
        axes = ["roll", "pitch", "yaw"]
        errors = [abs(actual_tcp[a] - expected_pose[a]) for a in axes]
        return round(sum(errors) / len(errors), 2)
    except Exception:
        return None


def _tcp_distance(a: dict, b: dict) -> float:
    try:
        dx = a["x"] - b["x"]
        dy = a["y"] - b["y"]
        dz = a["z"] - b["z"]
        return math.sqrt(dx * dx + dy * dy + dz * dz)
    except Exception:
        return 0.0


def _movement_summary(prev_tcp: Optional[dict], cur_tcp: dict) -> str:
    if prev_tcp is None:
        return "User initiated robot movement"
    try:
        dx = cur_tcp["x"] - prev_tcp["x"]
        dy = cur_tcp["y"] - prev_tcp["y"]
        dz = cur_tcp["z"] - prev_tcp["z"]
        threshold = 2.0
        parts: List[str] = []
        if abs(dz) > threshold:
            parts.append("upward" if dz > 0 else "downward")
        if abs(dx) > threshold:
            parts.append("forward" if dx > 0 else "backward")
        if abs(dy) > threshold:
            parts.append("left" if dy > 0 else "right")
        if parts:
            return "User moved robot " + ", ".join(parts)
        return "User made minor robot adjustment"
    except Exception:
        return "User made minor robot adjustment"


# ── Movement observer ─────────────────────────────────────────

class MovementObserver:
    """
    Background thread per device.
    Polls handler state, applies threshold + debounce + settle detection,
    pushes events to the shared asyncio.Queue only when context is active.
    """

    POLL_HZ = 5
    TCP_THRESHOLD_MM = 3.0
    SETTLE_SECS = 0.6
    DEBOUNCE_SECS = 1.5
    MAX_MOVING_SECS = 30.0

    def __init__(
        self,
        device_id: str,
        device_type: str,
        handler: DeviceHandler,
        ctx_mgr: ReactiveContextManager,
        event_queue: asyncio.Queue,
        loop: asyncio.AbstractEventLoop,
    ) -> None:
        self._device_id = device_id
        self._device_type = device_type
        self._handler = handler
        self._ctx_mgr = ctx_mgr
        self._queue = event_queue
        self._loop = loop

        self._prev_tcp: Optional[dict] = None
        self._prev_joints: Optional[list] = None
        self._motion_start_ts: Optional[float] = None
        self._last_emitted_ts: float = 0.0
        self._last_settled_tcp: Optional[dict] = None
        self._stop_evt = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        self._stop_evt.clear()
        self._thread = threading.Thread(
            target=self._run, daemon=True, name=f"observer-{self._device_id}"
        )
        self._thread.start()
        log.info(f"[{self._device_id}] MovementObserver started")

    def stop(self) -> None:
        self._stop_evt.set()
        if self._thread:
            self._thread.join(timeout=3)
            self._thread = None
        log.info(f"[{self._device_id}] MovementObserver stopped")

    def _run(self) -> None:
        interval = 1.0 / self.POLL_HZ
        while not self._stop_evt.is_set():
            try:
                if self._ctx_mgr.is_active() and self._handler.is_connected:
                    ctx = self._ctx_mgr.snapshot()
                    self._tick(ctx)
            except Exception as e:
                log.warning(f"[{self._device_id}] observer error: {e}")
            self._stop_evt.wait(interval)

    def _tick(self, ctx: dict) -> None:
        cur_tcp, cur_joints = self._read_state()
        if cur_tcp is None:
            return

        now = time.time()
        dist = (
            _tcp_distance(self._prev_tcp, cur_tcp) if self._prev_tcp else 0.0
        )
        moving = dist > self.TCP_THRESHOLD_MM

        if moving and self._motion_start_ts is None:
            self._motion_start_ts = now
            self._last_settled_tcp = self._prev_tcp

        if not moving and self._motion_start_ts is not None:
            idle_secs = now - max(
                self._last_emitted_ts, self._motion_start_ts
            )
            if idle_secs >= self.SETTLE_SECS:
                duration_ms = round((now - self._motion_start_ts) * 1000)
                self._maybe_emit(
                    cur_tcp, cur_joints, "settled", now, duration_ms, ctx
                )
                self._motion_start_ts = None

        elif moving and self._motion_start_ts is not None:
            elapsed = now - self._motion_start_ts
            if elapsed >= self.MAX_MOVING_SECS:
                duration_ms = round(elapsed * 1000)
                self._maybe_emit(
                    cur_tcp, cur_joints, "still_moving", now, duration_ms, ctx
                )
                self._motion_start_ts = now

        self._prev_tcp = cur_tcp
        self._prev_joints = cur_joints

    def _maybe_emit(self, cur_tcp, cur_joints, movement_kind, now, duration_ms, ctx):
        if (now - self._last_emitted_ts) < self.DEBOUNCE_SECS:
            return

        event = self._build_event(
            cur_tcp, cur_joints, movement_kind, duration_ms, ctx
        )
        self._loop.call_soon_threadsafe(
            lambda e=event: self._queue.put_nowait(e)
        )
        self._last_emitted_ts = now
        log.info(
            f"[{self._device_id}] emitted bridge_event "
            f"kind={movement_kind} session={ctx.get('session_id')}"
        )

    def _read_state(self) -> Tuple[Optional[dict], Optional[list]]:
        try:
            tcp = None
            joints = None
            if hasattr(self._handler, "_read_tcp"):
                tcp = self._handler._read_tcp()
            if hasattr(self._handler, "_read_joints"):
                joints = self._handler._read_joints()
            if tcp is None:
                data = self._handler.handle("get_position", {})
                tcp = data.get("tcp")
                joints = data.get("joints")
            return tcp, joints
        except Exception as e:
            log.debug(f"[{self._device_id}] _read_state error: {e}")
            return None, None

    def _build_event(self, cur_tcp, cur_joints, movement_kind, duration_ms, ctx):
        practice = ctx.get("practice") or {}
        step = practice.get("current_step") or {}
        expected_pose = step.get("expected_pose")

        pos_err = (
            _position_error_mm(cur_tcp, expected_pose) if expected_pose else None
        )
        ori_err = (
            _orientation_error_deg(cur_tcp, expected_pose) if expected_pose else None
        )
        within = (
            (pos_err is not None and pos_err <= 10.0) if expected_pose else None
        )

        expected_ref = None
        evaluation = None
        if expected_pose is not None:
            expected_ref = {
                "practice_id": practice.get("practice_id", ""),
                "step_id": step.get("step_id", ""),
                "expected_pose": expected_pose,
            }
            evaluation = {
                "position_error_mm": pos_err or 0.0,
                "orientation_error_deg": ori_err or 0.0,
                "within_tolerance": bool(within),
                "duration_ms": duration_ms,
            }

        return {
            "type": "bridge_event",
            "event_name": "user_robot_movement",
            "source": "bridge",
            "session_id": ctx.get("session_id", ""),
            "thread_id": ctx.get("thread_id", ""),
            "user_id": ctx.get("user_id", ""),
            "device_id": self._device_id,
            "device_type": self._device_type,
            "mode": "practice",
            "timestamp": datetime.now(timezone.utc).isoformat() + "Z",
            "data": {
                "tcp": cur_tcp,
                "joints": cur_joints,
                "state": (
                    "moving" if movement_kind == "still_moving" else "idle"
                ),
                "movement_kind": movement_kind,
                "movement_summary": _movement_summary(
                    self._last_settled_tcp, cur_tcp
                ),
                "expected_reference": expected_ref,
                "evaluation": evaluation,
            },
        }