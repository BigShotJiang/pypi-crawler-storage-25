"""
handlers/abb.py — ABB IRB via TCP socket to RAPID SocketServer.

Extracted from bridge.py (Phase 3).
"""

import logging

from .base import DeviceHandler, euler_to_quat, quat_to_euler

log = logging.getLogger("orion_bridge.handlers.abb")


class ABBHandler(DeviceHandler):
    device_type = "abb"

    def __init__(
        self,
        ip="192.168.125.1",
        port=1025,
        timeout=30.0,
        default_euler=(180.0, 0.0, 0.0),
    ):
        self.ip = ip
        self.port = port
        self.timeout = timeout
        self.default_euler = default_euler
        self._sock = None
        self._speed = 100

    def connect(self) -> bool:
        import socket

        try:
            log.info(f"ABB: connecting {self.ip}:{self.port}...")
            self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._sock.settimeout(self.timeout)
            self._sock.connect((self.ip, self.port))
            log.info("ABB: connected")
            return True
        except Exception as e:
            log.error(f"ABB connect failed: {e}")
            self._sock = None
            return False

    def disconnect(self):
        if self._sock:
            try:
                self._send("STOP")
                self._recv()
            except Exception:
                pass
            finally:
                self._sock.close()
                self._sock = None

    @property
    def is_connected(self) -> bool:
        return self._sock is not None

    def _get_dispatch_map(self) -> dict:
        """Single source of truth for dispatchable actions."""
        return {
            "get_position": self._get_position,
            "move_linear":  self._move_linear,
            "move_joint":   self._move_joint,
            "home":         self._home,
            "set_speed":    self._set_speed,
        }

    def handle(self, action: str, params: dict) -> dict:
        fn = self._get_dispatch_map().get(action)
        if not fn:
            raise ValueError(f"ABB: unknown action '{action}'")
        return fn(params)

    def capability_card(self) -> dict:
        """ABB capability card: TCP cartesian moves with quaternion/Euler orientation."""
        return {
            "device_type": self.device_type,
            "model": "abb_irb",
            "backend": "tcp_socket",
            "ip": self.ip,
            "port": self.port,
            "actions": list(self._get_dispatch_map().keys()),
            "action_schemas": {
                "move_linear": {
                    "x": "float (mm)",
                    "y": "float (mm)",
                    "z": "float (mm)",
                    "q1": "float? (quaternion w, optional)",
                    "q2": "float?",
                    "q3": "float?",
                    "q4": "float?",
                    "ex": "float? (Euler X deg, default 180)",
                    "ey": "float? (Euler Y deg, default 0)",
                    "ez": "float? (Euler Z deg, default 0)",
                },
                "move_joint": {
                    "x": "float (mm)",
                    "y": "float (mm)",
                    "z": "float (mm)",
                    "q1": "float? (quaternion w)",
                    "q2": "float?",
                    "q3": "float?",
                    "q4": "float?",
                },
                "set_speed": {"speed": "int (mm/s, typical 50-500)"},
                "home": {},
                "get_position": {},
            },
            "default_euler": {
                "ex": self.default_euler[0],
                "ey": self.default_euler[1],
                "ez": self.default_euler[2],
            },
            "current_speed": self._speed,
            "units": {
                "position": "mm",
                "speed": "mm/s",
                "orientation": "quaternion (q1=w, q2=x, q3=y, q4=z) or Euler deg",
            },
        }

    # ── protocol helpers ──────────────────────────────────────

    def _send(self, msg):
        self._sock.sendall((msg.strip() + ";").encode("ascii"))

    def _recv(self):
        buf = b""
        while not buf.endswith(b";"):
            chunk = self._sock.recv(1024)
            if not chunk:
                raise ConnectionError("ABB closed the connection")
            buf += chunk
        resp = buf.decode("ascii").rstrip(";").strip()
        if resp.startswith("ERROR"):
            raise RuntimeError(f"ABB: {resp[6:]}")
        return resp

    def _parse_pos(self, resp):
        nums = [float(p) for p in resp.split()[1:8]]
        ex, ey, ez = quat_to_euler(nums[3], nums[4], nums[5], nums[6])
        return {
            "x": nums[0], "y": nums[1], "z": nums[2],
            "q1": nums[3], "q2": nums[4], "q3": nums[5], "q4": nums[6],
            "euler": {"ex": ex, "ey": ey, "ez": ez},
        }

    def _resolve_quat(self, p):
        if "q1" in p:
            return (p["q1"], p.get("q2", 0), p.get("q3", 0), p.get("q4", 0))
        ex = p.get("ex", self.default_euler[0])
        ey = p.get("ey", self.default_euler[1])
        ez = p.get("ez", self.default_euler[2])
        return euler_to_quat(ex, ey, ez)

    # ── actions ───────────────────────────────────────────────

    def _get_position(self, p):
        self._send("GETPOS")
        return {"position": self._parse_pos(self._recv()), "state": "static"}

    def _move_linear(self, p):
        q = self._resolve_quat(p)
        self._send(
            f"MOVEL {p['x']:.3f} {p['y']:.3f} {p['z']:.3f} "
            f"{q[0]:.6f} {q[1]:.6f} {q[2]:.6f} {q[3]:.6f}"
        )
        return {
            "command": "MOVEL",
            "position": self._parse_pos(self._recv()),
            "state": "static",
        }

    def _move_joint(self, p):
        q = self._resolve_quat(p)
        self._send(
            f"MOVEJ {p['x']:.3f} {p['y']:.3f} {p['z']:.3f} "
            f"{q[0]:.6f} {q[1]:.6f} {q[2]:.6f} {q[3]:.6f}"
        )
        return {
            "command": "MOVEJ",
            "position": self._parse_pos(self._recv()),
            "state": "static",
        }

    def _home(self, p):
        self._send("HOME")
        return {
            "command": "HOME",
            "position": self._parse_pos(self._recv()),
            "state": "static",
        }

    def _set_speed(self, p):
        speed = int(p.get("speed", 100))
        self._send(f"SPEED {speed}")
        self._recv()
        self._speed = speed
        return {"speed_set": speed}