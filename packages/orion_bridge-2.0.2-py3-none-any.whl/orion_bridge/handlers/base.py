"""
handlers/base.py — Base classes and shared constants for device handlers.

Extracted from bridge.py (Phase 3, Step 1).
Updated Phase 4: supports both xArm 6 and xArm 7 via num_joints property.
"""

import math
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Optional
import ikpy.chain
import numpy as np

if TYPE_CHECKING:
    from ..sim.collision import CollisionChecker



JOINT_NAMES_6 = {
    1: "Base",
    2: "Shoulder",
    3: "Elbow",
    4: "Wrist Roll",
    5: "Wrist Pitch",
    6: "Wrist Yaw",
}

JOINT_NAMES_7 = {
    1: "Base",
    2: "Shoulder",
    3: "Elbow Roll",
    4: "Elbow Pitch",
    5: "Wrist Roll",
    6: "Wrist Pitch",
    7: "Wrist Yaw",
}

JOINT_LIMITS_6 = {
    1: (-360, 360),
    2: (-118, 120),
    3: (-225, 11),
    4: (-360, 360),
    5: (-97, 180),
    6: (-360, 360),
}

JOINT_LIMITS_7 = {
    1: (-360, 360),
    2: (-118, 120),
    3: (-360, 360),
    4: (-11, 225),
    5: (-360, 360),
    6: (-97, 180),
    7: (-360, 360),
}

# Legacy aliases (default to 6-DOF for backward compat)
JOINT_NAMES = JOINT_NAMES_6
JOINT_LIMITS = JOINT_LIMITS_6

STATE_MAP = {1: "moving", 2: "sleeping", 3: "suspended", 4: "stopping"}

MODE_MAP = {
    0: "position control",
    1: "servo joint",
    2: "manual/teach",
    3: "servo cartesian",
    4: "joint velocity",
    5: "cartesian velocity",
    6: "joint online",
    7: "cartesian online",
}

NAMED_POSES_6 = {
    "home":    [0, -45, -25, 0, 70, 0],
    "pick":    [0, -30, 60, 0, 90, 0],
    "place":   [90, -30, 60, 0, 90, 0],
    "ready":   [0, -45, 30, 0, 45, 0],
    "inspect": [0, -60, 90, 0, 30, 0],
}

NAMED_POSES_7 = {
    "home":    [0, -45, 0, 25, 0, 70, 0],
    "pick":    [0, -30, 0, 60, 0, 90, 0],
    "place":   [90, -30, 0, 60, 0, 90, 0],
    "ready":   [0, -45, 0, 30, 0, 45, 0],
    "inspect": [0, -60, 0, 90, 0, 30, 0],
}

NAMED_POSES = NAMED_POSES_6  

_LINK_L = [267.0, 289.6, 77.5, 342.5, 97.0, 76.0]

HOME_TCP = [206.0, 0.0, 120.5, 180.0, 0.0, 0.0]



def approx_fk(joints_deg: list) -> list:
    """
    Rough FK for the xArm 6.
    Good enough for UI display and telemetry, not for path planning.
    Returns [x, y, z, roll, pitch, yaw] in mm / degrees.
    For xArm 7, pass a 7-element list — joint 3 (elbow roll) is ignored.
    """
    # If 7 joints, collapse to 6 by dropping joint3 (redundant elbow roll)
    if len(joints_deg) == 7:
        j6 = [joints_deg[0], joints_deg[1], joints_deg[3],
              joints_deg[4], joints_deg[5], joints_deg[6]]
    else:
        j6 = joints_deg

    j = [math.radians(a) for a in j6]
    L1, L2, L3, L4, L5, L6 = _LINK_L

    r = (
        L2 * math.cos(j[1])
        + L3 * math.cos(j[1] + j[2])
        + (L4 + L5) * math.cos(j[1] + j[2] + j[4])
    )
    z = (
        L1
        + L2 * math.sin(j[1])
        + L3 * math.sin(j[1] + j[2])
        + (L4 + L5) * math.sin(j[1] + j[2] + j[4])
        + L6
    )
    x = r * math.cos(j[0])
    y = r * math.sin(j[0])

    roll = 180.0
    pitch = j6[1] + j6[2] + j6[4]
    yaw = j6[3] + j6[5]
    return [round(v, 2) for v in [x, y, z, roll, pitch, yaw]]



def euler_to_quat(ex, ey, ez):
    """Euler angles (degrees) → quaternion (q1, q2, q3, q4)."""
    hx = math.radians(ex / 2)
    hy = math.radians(ey / 2)
    hz = math.radians(ez / 2)
    cx, sx = math.cos(hx), math.sin(hx)
    cy, sy = math.cos(hy), math.sin(hy)
    cz, sz = math.cos(hz), math.sin(hz)
    return (
        cz * cy * cx + sz * sy * sx,
        cz * cy * sx - sz * sy * cx,
        cz * sy * cx + sz * cy * sx,
        sz * cy * cx - cz * sy * sx,
    )


def quat_to_euler(q1, q2, q3, q4):
    """Quaternion → Euler angles (ex, ey, ez) in degrees."""
    sinp = max(-1.0, min(1.0, 2.0 * (q1 * q3 - q4 * q2)))
    ey = math.degrees(math.asin(sinp))
    if abs(sinp) > 0.9999:
        ex = math.degrees(
            math.atan2(2 * (q2 * q3 + q1 * q4), 1 - 2 * (q3**2 + q4**2))
        )
        ez = 0.0
    else:
        ex = math.degrees(
            math.atan2(2 * (q1 * q2 + q3 * q4), 1 - 2 * (q2**2 + q3**2))
        )
        ez = math.degrees(
            math.atan2(2 * (q1 * q4 + q2 * q3), 1 - 2 * (q3**2 + q4**2))
        )
    return round(ex, 2), round(ey, 2), round(ez, 2)



class DeviceHandler(ABC):
    """
    Base class for all device handlers.
    Each handler connects to one physical or simulated device,
    and exposes a uniform handle(action, params) to dict API.
    """

    device_type: str = "unknown"

    @abstractmethod
    def connect(self) -> bool:
        ...

    @abstractmethod
    def disconnect(self) -> None:
        ...

    @abstractmethod
    def handle(self, action: str, params: dict) -> dict:
        ...

    @property
    @abstractmethod
    def is_connected(self) -> bool:
        ...

    def capability_card(self) -> dict:
        """
        Self-describing metadata for the agent.

        Each handler overrides this to expose what actions it can execute
        and any device-specific context (joint limits, IPs, etc.).

        Returns:
            dict with at least {device_type, actions}. May include
            device-specific extras (joint_names, joint_limits, etc.).
        """
        return {
            "device_type": self.device_type,
            "actions": [],
        }

class BaseXArmHandler(DeviceHandler):
    """
    Shared logic between XArmHandler (physical), GazeboXArmHandler, and
    MuJoCoXArmHandler.

    Supports both xArm 6 (6 joints) and xArm 7 (7 joints) via the
    num_joints property. Subclasses set self._num_joints in __init__
    or connect().

    Subclasses must implement:
        connect, disconnect, is_connected,
        _read_joints() → list[float]   (N angles in degrees)
        _read_tcp() → dict             ({x,y,z,roll,pitch,yaw})
        _move_to(angles_deg, speed) → None   (blocking move)
        _get_state() → str
        _get_mode() → str
    """

    device_type = "xarm"

    def __init__(self, num_joints: int = 6):
        self._gripper_pos: float = 850.0
        self._num_joints: int = num_joints
        self._collision_checker: Optional["CollisionChecker"] = None
        self._ik_chain = None
        self._urdf_path: Optional[str] = None

    def enable_collision_check(self, mjcf_path: Optional[str] = None) -> None:
        """
        Attach a CollisionChecker to this handler.

        Safe to call on any subclass, including XArmHandler (physical robot).
        The checker loads its own MjModel/MjData and runs no physics thread,
        so it works independently of whether SimEngine is running.

        Args:
            mjcf_path: Path to an MJCF scene file.  Accepts absolute paths or
                       paths relative to the orion_bridge package root.
                       Defaults to sim/models/xarm6/scene_xarm6.xml.
        """
        from ..sim.collision import CollisionChecker
        self._collision_checker = CollisionChecker(mjcf_path or "")

    @property
    def num_joints(self) -> int:
        return self._num_joints

    @property
    def joint_names(self) -> dict:
        return JOINT_NAMES_7 if self._num_joints == 7 else JOINT_NAMES_6

    @property
    def joint_limits(self) -> dict:
        return JOINT_LIMITS_7 if self._num_joints == 7 else JOINT_LIMITS_6

    @property
    def named_poses(self) -> dict:
        return NAMED_POSES_7 if self._num_joints == 7 else NAMED_POSES_6

    def _get_dispatch_map(self) -> dict:
        return {
            "get_position":    self._get_position,
            "get_full_status": self._get_full_status,
            "move_joint":      self._move_joint,
            "move_linear":     self._move_linear,
            "home":            self._home,
            "go_to_pose":      self._go_to_pose,
            "set_gripper":     self._gripper,
            "emergency_stop":  self._estop,
            "run_recipe":      self._run_recipe,
            "go_to":           self._go_to,
        }

    def handle(self, action: str, params: dict) -> dict:
        fn = self._get_dispatch_map().get(action)
        if not fn:
            raise ValueError(f"xArm: unknown action '{action}'")
        return fn(params)

    def capability_card(self) -> dict:
        """xArm capability card with joints, limits, poses, and dispatchable actions.

        Generated from the handler's own state — joint_names, joint_limits,
        and named_poses adapt to num_joints (6 vs 7).
        """
        n = self._num_joints
        return {
            "device_type": self.device_type,
            "model": f"xarm{n}",
            "num_joints": n,
            "joint_names": self.joint_names,
            "joint_limits": self.joint_limits,
            "named_poses": list[Any](self.named_poses.keys()),
            "actions": list[Any](self._get_dispatch_map().keys()),
            "action_schemas": {
                "move_joint": {"joint_id": "int[1..N]", "angle": "float (deg)", "speed": "int? (deg/s)"},
                "move_linear": {"x": "float (mm)", "y": "float (mm)", "z": "float (mm)", "speed": "int? (mm/s)"},
                "go_to_pose": {"pose": "str (one of named_poses)", "speed": "int? (deg/s)"},
                "set_gripper": {"action": "str ('open'|'close'|'toggle')"},
                "home": {"speed": "int? (deg/s)"},
                "go_to": {"x": "float (mm)", "y": "float (mm)", "z": "float (mm)", "speed": "int? (deg/s)"},
                "get_position": {},
                "get_full_status": {},
                "emergency_stop": {},
            },
            "units": {
                "joint": "deg",
                "position": "mm",
                "speed_joint": "deg/s",
                "speed_cart": "mm/s",
            },
            "has_collision_checker": self._collision_checker is not None,
        }
    @abstractmethod
    def _read_joints(self) -> list:
        """Return N joint angles in degrees."""
        ...

    @abstractmethod
    def _read_tcp(self) -> dict:
        """Return {x, y, z, roll, pitch, yaw} in mm/degrees."""
        ...

    @abstractmethod
    def _move_to(self, angles_deg: list, speed: float = 30) -> None:
        """Move to target joint angles. Block until done."""
        ...

    @abstractmethod
    def _get_state(self) -> str:
        ...

    @abstractmethod
    def _get_mode(self) -> str:
        ...

    @abstractmethod
    def _estop(self, p: dict) -> dict:
        ...


    def _get_position(self, p):
        return {
            "tcp": self._read_tcp(),
            "joints": self._read_joints(),
            "state": self._get_state(),
            "mode": self._get_mode(),
            "num_joints": self._num_joints,
        }

    def _get_full_status(self, p):
        """Override in subclass for real telemetry (temps, currents, etc)."""
        n = self._num_joints
        return {
            **self._get_position(p),
            "joint_velocities": [0.0] * n,
            "joint_efforts": [0.0] * n,
            "temperatures": [25.0] * n,
            "currents": [0.0] * n,
            "error_code": 0,
            "warning_code": 0,
            "gripper_position": self._gripper_pos,
        }

    def _move_joint(self, p):
        n = self._num_joints
        jid = p.get("joint_id", p.get("joint", 1))
        angle = float(p.get("angle", 0))
        speed = p.get("speed", 30)

        if jid < 1 or jid > n:
            raise ValueError(f"Joint {jid} doesn't exist (1-{n})")
        lo, hi = self.joint_limits[jid]
        if not (lo <= angle <= hi):
            raise ValueError(
                f"J{jid} ({self.joint_names[jid]}): {angle}° is outside [{lo}°, {hi}°]"
            )

        current = self._read_joints()
        prev = current[jid - 1]

        print(f"[CollisionChecker] gate check: checker={self._collision_checker is not None}")
        if self._collision_checker is not None:
            check = self._collision_checker.check_joint_move(current, jid, angle)
            if not check["safe"]:
                return {
                    "status": "error",
                    "error_code": "collision_detected",
                    "error": check.get("reason", "Movement would cause a collision"),
                    "detail": check,
                }

        current[jid - 1] = angle
        self._move_to(current, speed)

        final = self._read_joints()
        TOLERANCE_DEG = 3.0
        err = abs(final[jid - 1] - angle)
        if err > TOLERANCE_DEG:
            return {
                "status": "error",
                "error_code": "did_not_converge",
                "error": (
                    f"J{jid} requested {angle}°, only reached {final[jid-1]:.1f}° "
                    f"(error {err:.1f}°). Likely hit a limit, collision or torque saturation."
                ),
                "detail": {
                    "joint_id": jid,
                    "joint_name": self.joint_names[jid],
                    "requested": angle,
                    "reached": round(final[jid - 1], 2),
                    "error_deg": round(err, 2),
                    "tolerance_deg": TOLERANCE_DEG,
                },
            }

        return {
            "code": 0,
            "target_joint": jid,
            "joint_name": self.joint_names[jid],
            "target_angle": angle,
            "previous_angle": prev,
            "final_angles": final,
            "state": self._get_state(),
        }

    def _move_linear(self, p):
        """
        Cartesian move gated by the collision checker's IK solution.

        When a CollisionChecker is attached, check_linear_move() validates the
        path AND returns solved joint angles, which are then executed via
        _move_to().  This gives MuJoCo and Gazebo backends free Cartesian-move
        support without requiring a separate IK library.

        Without a CollisionChecker the call is rejected — callers should use
        move_joint or go_to_pose instead.
        """
        if self._collision_checker is None:
            raise ValueError(
                "Cartesian moves need IK. Attach a CollisionChecker via "
                "enable_collision_check() or use move_joint / go_to_pose."
            )

        speed      = p.get("speed", 30)
        cur_tcp    = self._read_tcp()                      # {x,y,z,roll,pitch,yaw} in mm
        target_tcp = {
            "x": float(p.get("x", cur_tcp["x"])),
            "y": float(p.get("y", cur_tcp["y"])),
            "z": float(p.get("z", cur_tcp["z"])),
        }
        current    = self._read_joints()

        result = self._collision_checker.check_linear_move(current, target_tcp)
        if not result["safe"]:
            return {
                "status": "error",
                "error":  result.get("reason", "collision_detected"),
                "detail": result,
            }

        self._move_to(result["final_angles_deg"], speed)
        return {
            "code":             0,
            "target_tcp":       target_tcp,
            "final_angles_deg": result["final_angles_deg"],
            "final_tcp":        self._read_tcp(),
            "state":            self._get_state(),
        }

    def _home(self, p):
            return self._go_to_pose({**p, "pose": "home"})

    def _go_to_pose(self, p):
        pose = p.get("pose")
        if not pose:
            return {
                "status": "error",
                "error_code": "missing_parameter",
                "error": "go_to_pose requires 'pose' parameter (not 'pose_name' or similar)",
                "detail": {"received_keys": list(p.keys()), "expected": "pose"},
            }
        if pose not in self.named_poses:
            return {
                "status": "error",
                "error_code": "unknown_pose",
                "error": f"Pose '{pose}' not defined. Available: {list(self.named_poses.keys())}",
                "detail": {"requested": pose, "available": list(self.named_poses.keys())},
            }

        joints = self.named_poses[pose]
        self._move_to(joints, p.get("speed", 30))
        return {
            "code": 0,
            "pose": pose,
            "final_angles": joints,
            "state": self._get_state(),
        }
    def _gripper(self, p):
        action = p.get("action", "toggle")
        if action == "open":
            pos = 850
        elif action == "close":
            pos = 0
        else:
            pos = 0 if self._gripper_pos > 400 else 850
        self._gripper_pos = pos
        return {
            "code": 0,
            "target_position": pos,
            "current_position": pos,
            "is_open": pos > 400,
        }

    def _run_recipe(self, p: dict) -> dict:
        """Interpret and execute a recipe's step sequence atomically.
        
        Recipe steps come from lab.recipes in Supabase. Each step is a
        dict with a 'type' field and type-specific parameters.
        
        Supported step types:
        - move_joints: {angles: list, speed: int, comment?: str}
        - move_to_pose: {pose: str, speed?: int, comment?: str}
        - gripper: {action: "open"|"close"|"toggle"}
        - pause: {seconds: float}
        """
        import time

        recipe_name = p.get("recipe_name", "unnamed")
        steps = p.get("steps", [])
        multiplier = float(p.get("speed_multiplier", 1.0))

        if not steps:
            return {
                "status": "error",
                "error_code": "empty_recipe",
                "error": f"Recipe '{recipe_name}' has no steps",
            }

        if not (0.2 <= multiplier <= 2.0):
            return {
                "status": "error",
                "error_code": "invalid_parameter",
                "error": f"speed_multiplier must be 0.2-2.0, got {multiplier}",
            }

        completed = 0
        for idx, step in enumerate(steps):
            step_type = step.get("type")
            try:
                if step_type == "move_joints":
                    angles = step.get("angles", [])
                    if len(angles) != self._num_joints:
                        return {
                            "status": "error",
                            "error_code": "invalid_step",
                            "error": f"Step {idx}: angles length {len(angles)} != num_joints {self._num_joints}",
                            "step_index": idx,
                            "steps_completed": completed,
                        }
                    speed = int(step.get("speed", 25) * multiplier)
                    self._move_to(angles, max(speed, 5))

                elif step_type == "move_to_pose":
                    pose = step.get("pose")
                    if pose not in self.named_poses:
                        return {
                            "status": "error",
                            "error_code": "unknown_pose",
                            "error": f"Step {idx}: pose '{pose}' not defined. Available: {list(self.named_poses.keys())}",
                            "step_index": idx,
                            "steps_completed": completed,
                        }
                    speed = int(step.get("speed", 25) * multiplier)
                    self._move_to(self.named_poses[pose], max(speed, 5))

                elif step_type == "gripper":
                    action = step.get("action", "toggle")
                    self._gripper({"action": action})

                elif step_type == "pause":
                    seconds = float(step.get("seconds", 0.5))
                    time.sleep(min(seconds / multiplier, 10.0))  # cap at 10s for safety

                else:
                    return {
                        "status": "error",
                        "error_code": "unknown_step_type",
                        "error": f"Step {idx}: unknown type '{step_type}'. Supported: move_joints, move_to_pose, gripper, pause",
                        "step_index": idx,
                        "steps_completed": completed,
                    }

                completed += 1

            except Exception as e:
                return {
                    "status": "error",
                    "error_code": "step_execution_failed",
                    "error": f"Step {idx} ({step_type}) failed: {e}",
                    "step_index": idx,
                    "steps_completed": completed,
                    "detail": {"step": step},
                }

        return {
            "code": 0,
            "recipe_name": recipe_name,
            "steps_completed": completed,
            "total_steps": len(steps),
            "speed_multiplier": multiplier,
            "state": self._get_state(),
        }

    def _go_to(self, p: dict) -> dict:
        """Move to cartesian <x, y, z> using ikpy for inverse kinematics.
        
        Alternative to _move_linear for backends without CollisionChecker.
        
        p keys:
            x, y, z - target position in mm
            speed - joint speed in deg/s (default 30)
        """
        x_mm = float(p.get("x", 0.0))
        y_mm = float(p.get("y", 0.0))
        z_mm = float(p.get("z", 0.0))
        speed = float(p.get("speed", 30))
        
        if self._urdf_path is None:
            return {
                "status": "error",
                "error_code": "urdf_not_configured",
                "error": "This handler has no URDF path set. Cannot use ikpy.",
            }
        
        chain = self._load_ik_chain()
        
        target_m = [x_mm / 1000.0, y_mm / 1000.0, z_mm / 1000.0]
        angles_rad = chain.inverse_kinematics(target_m)
        
        angles_deg = [
            math.degrees(angles_rad[i])
            for i in range(1, self._num_joints + 1)
        ]
        
        self._move_to(angles_deg, speed)
        
        return {
            "code": 0,
            "target_xyz_mm": {"x": x_mm, "y": y_mm, "z": z_mm},
            "computed_angles_deg": [round(a, 2) for a in angles_deg],
            "final_angles": self._read_joints(),
            "state": self._get_state(),
        }


    def _load_ik_chain(self):
        """Lazy-load the ikpy chain for the current robot's URDF."""
        if self._ik_chain is None:
            import ikpy.chain
            self._ik_chain = ikpy.chain.Chain.from_urdf_file(self._urdf_path)
        return self._ik_chain