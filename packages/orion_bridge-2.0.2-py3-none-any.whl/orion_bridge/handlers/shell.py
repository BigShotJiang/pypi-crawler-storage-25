"""
handlers/shell.py — Local shell commands via subprocess (whitelisted).

Extracted from bridge.py (Phase 3).
"""

import re
import time
import platform
import subprocess
import shlex
import logging

from .base import DeviceHandler

log = logging.getLogger("orion_bridge.handlers.shell")

IS_WINDOWS = platform.system().lower() == "windows"


class ShellHandler(DeviceHandler):
    device_type = "shell"

    def __init__(self, whitelist=None, blocked=None, timeout=30):
        self._whitelist = whitelist or [
            "ping", "ipconfig", "ifconfig", "netstat", "nslookup",
            "tracert", "traceroute", "systeminfo", "hostname", "dir",
            "ls", "type", "cat", "echo", "python", "pip", "whoami",
            "tasklist", "ps",
        ]
        self._blocked = blocked or [
            r"\brm\s+-rf\b", r"\bformat\b", r"\bdel\s+/[sfq]\b",
            r"\bshutdown\b", r"\breboot\b", r"\bmkfs\b", r"\bdd\s+if=\b",
            r"\b:(){", r"\breg\s+delete\b", r"\bnet\s+user\b.*\/add",
        ]
        self._timeout = timeout

    def connect(self) -> bool:
        return True

    def disconnect(self) -> None:
        pass

    @property
    def is_connected(self) -> bool:
        return True

    def _get_dispatch_map(self) -> dict:
        """Single source of truth for dispatchable actions."""
        return {
            "ping":         self._ping,
            "exec_command": self._exec_command,
        }

    def handle(self, action: str, params: dict) -> dict:
        fn = self._get_dispatch_map().get(action)
        if not fn:
            raise ValueError(f"Shell: unknown action '{action}'")
        return fn(params)

    def _ping(self, p: dict) -> dict:
        ip = p.get("ip", "")
        count = p.get("count", 4)
        flag = "-n" if IS_WINDOWS else "-c"
        return self._exec(f"ping {flag} {count} {ip}", timeout=min(count * 5, 30))

    def _exec_command(self, p: dict) -> dict:
        cmd = p.get("command", "").strip()
        timeout = min(p.get("timeout", self._timeout), 120)
        ok, reason = self._check_allowed(cmd)
        if not ok:
            raise PermissionError(reason)
        return self._exec(cmd, timeout)

    def capability_card(self) -> dict:
        """Shell capability card: whitelisted local command execution."""
        return {
            "device_type": self.device_type,
            "model": "shell-local",
            "backend": "subprocess",
            "platform": platform.system(),
            "actions": list(self._get_dispatch_map().keys()),
            "action_schemas": {
                "ping": {
                    "ip": "str (target host or IP)",
                    "count": "int? (default 4)",
                },
                "exec_command": {
                    "command": "str (must start with a whitelisted binary)",
                    "timeout": "int? (seconds, max 120)",
                },
            },
            "whitelist": list(self._whitelist),
            "blocked_patterns": list(self._blocked),
            "default_timeout": self._timeout,
            "notes": (
                "Only whitelisted binaries can run. Blocked patterns are regex "
                "matched against the command to prevent destructive operations."
            ),
        }

    # ── security ──────────────────────────────────────────────

    def _check_allowed(self, command):
        cmd_lower = command.lower().strip()
        for pat in self._blocked:
            if re.search(pat, cmd_lower):
                return False, "Blocked for security"
        first = cmd_lower.split()[0] if cmd_lower.split() else ""
        base = first.split("\\")[-1].split("/")[-1]
        if base.endswith(".exe"):
            base = base[:-4]
        if any(base == a or first == a for a in self._whitelist):
            return True, "ok"
        return False, f"'{base}' not whitelisted"

    # ── execution ─────────────────────────────────────────────

    def _exec(self, command, timeout=30):
        t0 = time.time()
        try:
            if IS_WINDOWS:
                result = subprocess.run(
                    command, capture_output=True, text=True,
                    timeout=timeout, shell=True,
                )
            else:
                result = subprocess.run(
                    shlex.split(command), capture_output=True, text=True,
                    timeout=timeout,
                )
            elapsed = (time.time() - t0) * 1000

            if command.startswith("ping"):
                return self._parse_ping(result.stdout, command, elapsed)

            return {
                "command": command,
                "exit_code": result.returncode,
                "stdout": result.stdout[:10000],
                "stderr": result.stderr[:5000],
                "duration_ms": round(elapsed, 1),
                "platform": platform.system(),
            }
        except subprocess.TimeoutExpired:
            return {
                "command": command,
                "exit_code": -1,
                "stdout": "",
                "stderr": f"Timeout after {timeout}s",
                "duration_ms": round((time.time() - t0) * 1000, 1),
            }
        except FileNotFoundError:
            return {
                "command": command,
                "exit_code": -1,
                "stdout": "",
                "stderr": f"Not found: {command.split()[0]}",
                "duration_ms": 0,
            }

    def _parse_ping(self, stdout, command, duration_ms):
        ip = command.split()[-1] if " " in command else ""
        times = []
        for line in stdout.strip().split("\n"):
            m = re.search(r"(?:time|tiempo)[=<](\d+\.?\d*)\s*ms", line, re.IGNORECASE)
            if m:
                times.append(float(m.group(1)))
        count = max(len(times), 1)
        return {
            "ip": ip,
            "reachable": len(times) > 0,
            "packets_sent": count,
            "packets_received": len(times),
            "packet_loss": (
                round((1 - len(times) / count) * 100, 1) if count else 100
            ),
            "times_ms": times,
            "avg_ms": round(sum(times) / len(times), 1) if times else None,
            "min_ms": min(times) if times else None,
            "max_ms": max(times) if times else None,
            "duration_ms": round(duration_ms, 1),
        }