"""
handlers/xarm_physical.py — Physical xArm 6 via UFACTORY SDK.

Extracted from bridge.py (Phase 3).
Now extends BaseXArmHandler — only implements the transport layer.
"""

import time
import logging

from .base import (
    BaseXArmHandler,
    JOINT_NAMES,
    JOINT_LIMITS,
    STATE_MAP,
    MODE_MAP,
)

log = logging.getLogger("orion_bridge.handlers.xarm_physical")


class XArmHandler(BaseXArmHandler):
    """Physical xArm 6 connected via UFACTORY SDK (direct IP)."""

    def __init__(self, ip: str):
        super().__init__()
        self.ip = ip
        self.arm = None
        self._connected = False

    # ── connection ────────────────────────────────────────────

    def connect(self) -> bool:
        try:
            from xarm.wrapper import XArmAPI

            log.info(f"xArm: connecting {self.ip}...")
            self.arm = XArmAPI(self.ip, is_radian=False)
            self.arm.clean_error()
            self.arm.clean_warn()
            time.sleep(0.3)
            self.arm.motion_enable(True)
            time.sleep(0.3)
            self.arm.set_mode(0)
            time.sleep(0.1)
            self.arm.set_state(0)
            time.sleep(0.3)
            self._connected = True

            # Detect 6 vs 7 DOF from the SDK, update base-class attribute
            detected = int(getattr(self.arm, "axis", 6) or 6)
            if detected not in (6, 7):
                detected = 6
            self._num_joints = detected

            # Attach collision checker (independent MuJoCo instance — no SimEngine needed)
            mjcf = (
                "sim/models/xarm7/scene_xarm7.xml"
                if detected == 7
                else "sim/models/xarm6/scene_xarm6.xml"
            )
            try:
                self.enable_collision_check(mjcf)
                log.info(f"xArm: collision checker enabled (xArm{detected})")
            except Exception as ce:
                log.warning(f"xArm: collision checker unavailable — {ce}")

            log.info(f"xArm: connected @ {self.ip}")
            return True
        except Exception as e:
            log.error(f"xArm connect failed: {e}")
            self._connected = False
            return False

    def disconnect(self):
        if self.arm:
            self.arm.disconnect()
        self._connected = False

    @property
    def is_connected(self) -> bool:
        return self._connected and self.arm is not None

    # ── transport layer (BaseXArmHandler contract) ────────────

    def _read_joints(self) -> list:
        _, angles = self.arm.get_servo_angle()
        return list(angles) if angles else [0.0] * 6

    def _read_tcp(self) -> dict:
        _, pos = self.arm.get_position()
        if pos:
            return {
                "x": pos[0], "y": pos[1], "z": pos[2],
                "roll": pos[3], "pitch": pos[4], "yaw": pos[5],
            }
        return {"x": 0, "y": 0, "z": 0, "roll": 0, "pitch": 0, "yaw": 0}

    def _move_to(self, angles_deg: list, speed: float = 30) -> None:
        code = self.arm.set_servo_angle(angle=angles_deg, speed=speed, wait=True)
        if code != 0:
            self.arm.clean_error()
            self.arm.clean_warn()
            time.sleep(0.2)
            self.arm.motion_enable(True)
            time.sleep(0.1)
            self.arm.set_mode(0)
            time.sleep(0.1)
            self.arm.set_state(0)
            time.sleep(0.2)
            raise RuntimeError(f"Move failed (code={code})")

    def _get_state(self) -> str:
        return STATE_MAP.get(self.arm.state, "ready")

    def _get_mode(self) -> str:
        return MODE_MAP.get(self.arm.mode, "unknown")

    # ── overrides with richer data from SDK ───────────────────

    def get_telemetry(self) -> dict:
        """Real telemetry from the physical robot."""
        if not self.arm:
            return {}
        _, angles = self.arm.get_servo_angle()
        return {
            "joints_deg": [round(a, 3) for a in angles] if angles else [0.0] * 6,
            "velocities": [0.0] * 6,
            "efforts": (
                [round(c, 4) for c in self.arm.currents]
                if self.arm.currents
                else [0.0] * 6
            ),
            "temperatures": (
                list(self.arm.temperatures)
                if self.arm.temperatures
                else [0.0] * 6
            ),
            "state": self._get_state(),
        }

    def _get_full_status(self, p):
        """Full status with real sensor data."""
        _, pos = self.arm.get_position()
        _, angles = self.arm.get_servo_angle()
        code3, states = self.arm.get_joint_states(is_radian=False, num=3)
        positions, velocities, efforts = (
            states if code3 == 0 and states else ([], [], [])
        )
        code4, grip = self.arm.get_gripper_position()
        return {
            "tcp": (
                {
                    "x": pos[0], "y": pos[1], "z": pos[2],
                    "roll": pos[3], "pitch": pos[4], "yaw": pos[5],
                }
                if pos
                else None
            ),
            "joints": list(angles) if angles else None,
            "joint_velocities": list(velocities) if velocities else None,
            "joint_efforts": list(efforts) if efforts else None,
            "temperatures": (
                list(self.arm.temperatures) if self.arm.temperatures else None
            ),
            "currents": (
                list(self.arm.currents) if self.arm.currents else None
            ),
            "state": self._get_state(),
            "mode": self._get_mode(),
            "error_code": self.arm.error_code,
            "warning_code": self.arm.warn_code,
            "gripper_position": grip if code4 == 0 else None,
        }

    def _move_linear(self, p):
        """
        Physical robot Cartesian move via UFACTORY SDK.

        Validates the path with the collision checker (MuJoCo IK) before
        delegating execution to the SDK's own trajectory planner.  The IK
        solution is used only for validation — the real robot uses its own IK.
        """
        speed = p.get("speed", 50)
        _, pos = self.arm.get_position()
        if not pos:
            raise RuntimeError("Can't read current TCP")
        target = list(pos)
        for i, axis in enumerate(["x", "y", "z"]):
            if axis in p:
                target[i] = p[axis]

        if self._collision_checker is not None:
            check = self._collision_checker.check_linear_move(
                self._read_joints(),
                {"x": target[0], "y": target[1], "z": target[2]},
            )
            if not check["safe"]:
                return {
                    "status": "error",
                    "error":  check.get("reason", "collision_detected"),
                    "detail": check,
                }

        code = self.arm.set_position(*target[:6], speed=speed, wait=True)
        if code != 0:
            raise RuntimeError(f"Linear move failed (code={code})")
        _, new_pos = self.arm.get_position()
        return {
            "code": 0,
            "target": {"x": target[0], "y": target[1], "z": target[2]},
            "final_tcp": (
                {"x": new_pos[0], "y": new_pos[1], "z": new_pos[2]}
                if new_pos
                else None
            ),
            "state": self._get_state(),
        }

    def _gripper(self, p):
        """Physical gripper via SDK."""
        action = p.get("action", "toggle")
        if action == "open":
            pos = 850
        elif action == "close":
            pos = 0
        else:
            _, cur = self.arm.get_gripper_position()
            pos = 0 if (cur or 0) > 400 else 850
        self.arm.set_gripper_enable(True)
        self.arm.set_gripper_speed(p.get("speed", 3000))
        code = self.arm.set_gripper_position(pos, wait=True)
        _, current = self.arm.get_gripper_position()
        self._gripper_pos = current or pos
        return {
            "code": code,
            "target_position": pos,
            "current_position": current,
            "is_open": (current or 0) > 400,
        }

    def _estop(self, p):
        self.arm.emergency_stop()
        return {"stopped": True, "state": "emergency_stop"}

    def capability_card(self) -> dict:
        """Physical xArm card — extends base with connection info."""
        card = super().capability_card()
        card["backend"] = "physical"
        card["ip"] = self.ip
        return card