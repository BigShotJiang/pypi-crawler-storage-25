"""
handlers/__init__.py — Device handler registry.

NOTE: MuJoCoXArmHandler is NOT imported here to avoid a hard mujoco
dependency at package import time. It's lazy-imported in dispatcher.py
only when handler="mujoco" is configured.
"""

from .base import DeviceHandler, BaseXArmHandler
from .xarm_physical import XArmHandler
from .xarm_gazebo import GazeboXArmHandler
from .abb import ABBHandler
from .plc import PLCHandler
from .shell import ShellHandler

__all__ = [
    "DeviceHandler",
    "BaseXArmHandler",
    "XArmHandler",
    "GazeboXArmHandler",
    "ABBHandler",
    "PLCHandler",
    "ShellHandler",
]