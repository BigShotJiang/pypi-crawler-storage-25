"""
handlers/plc.py — Siemens S7-1200 PLC via snap7 / S7comm.

Extracted from bridge.py (Phase 3).
"""

import logging

from .base import DeviceHandler

log = logging.getLogger("orion_bridge.handlers.plc")


class PLCHandler(DeviceHandler):
    device_type = "plc"

    def __init__(self, plc_ips=None):
        self.plc_ips = plc_ips or []
        self._connections = {}  # ip → snap7 Client
        self._status = {}      # ip → bool
        self._Areas = None

    def connect(self) -> bool:
        try:
            import snap7
            from snap7.type import Areas

            self._Areas = Areas
        except ImportError:
            log.error("snap7 not installed: pip install python-snap7")
            return False

        for ip in self.plc_ips:
            try:
                plc = snap7.client.Client()
                plc.connect(ip, 0, 1)
                self._connections[ip] = plc
                self._status[ip] = True
                log.info(f"PLC connected: {ip}")
            except Exception as e:
                log.warning(f"PLC {ip} failed: {e}")
                self._status[ip] = False
        return any(self._status.values())

    def disconnect(self):
        for plc in self._connections.values():
            try:
                plc.disconnect()
            except Exception:
                pass
        self._connections.clear()
        self._status.clear()

    @property
    def is_connected(self) -> bool:
        return any(self._status.values())

    def _get_dispatch_map(self) -> dict:
        """Single source of truth for dispatchable actions."""
        return {
            "list_connections": self._list_connections,
            "read_area":        self._read_area,
            "write_bit":        self._write_bit,
        }

    
    def handle(self, action: str, params: dict) -> dict:
        fn = self._get_dispatch_map().get(action)
        if not fn:
            raise ValueError(f"PLC: unknown action '{action}'")
        return fn(params)

    def _list_connections(self, p: dict) -> dict:
        return {
            "plcs": {
                ip: {"connected": st} for ip, st in self._status.items()
            },
            "connected_count": sum(1 for s in self._status.values() if s),
            "total_count": len(self._status),
        }

    def _read_area(self, p: dict) -> dict:
        from snap7.util import get_bool

        ip = p["plc_ip"]
        area = p.get("area", "input")
        byte_addr = p.get("byte_address", 0)
        plc = self._get_plc(ip)
        result = plc.read_area(self._area_enum(area), 0, byte_addr, 1)
        bits = {f"bit_{i}": get_bool(result, 0, i) for i in range(8)}
        return {"ip": ip, "area": area, "byte": byte_addr, "bits": bits}

    def _write_bit(self, p: dict) -> dict:
        from snap7.util import set_bool

        ip = p["plc_ip"]
        area = p.get("area", "output")
        byte_addr = p.get("byte_address", 0)
        bit_num = p.get("bit", 0)
        value = p.get("value", False)
        if not (0 <= bit_num <= 7):
            raise ValueError(f"Bit must be 0-7, got {bit_num}")
        plc = self._get_plc(ip)
        ae = self._area_enum(area)
        data = plc.read_area(ae, 0, byte_addr, 1)
        set_bool(data, 0, bit_num, bool(value))
        plc.write_area(ae, 0, byte_addr, data)
        return {
            "ip": ip, "area": area, "byte": byte_addr,
            "bit": bit_num, "success": True,
            "value_written": bool(value),
        }

    def capability_card(self) -> dict:
        """PLC capability card: Siemens S7 I/O + memory access per-IP."""
        return {
            "device_type": self.device_type,
            "model": "s7-1200",
            "backend": "snap7",
            "connected_ips": [ip for ip, st in self._status.items() if st],
            "all_ips": list(self._status.keys()),
            "areas": ["input", "output", "memory"],
            "actions": list(self._get_dispatch_map().keys()),
            "action_schemas": {
                "list_connections": {},
                "read_area": {
                    "plc_ip": "str (IP of target PLC)",
                    "area": "str ('input'|'output'|'memory')",
                    "byte_address": "int (byte offset, default 0)",
                },
                "write_bit": {
                    "plc_ip": "str (IP of target PLC)",
                    "area": "str ('input'|'output'|'memory', default 'output')",
                    "byte_address": "int",
                    "bit": "int[0..7]",
                    "value": "bool",
                },
            },
            "notes": (
                "Each action targets a specific PLC by IP. Multiple PLCs may "
                "be connected; always pass plc_ip explicitly."
            ),
        }

    # ── helpers ───────────────────────────────────────────────

    def _get_plc(self, ip):
        plc = self._connections.get(ip)
        if not plc or not self._status.get(ip):
            raise ConnectionError(f"PLC {ip} not connected")
        return plc

    def _area_enum(self, area):
        return {
            "input": self._Areas.PE,
            "output": self._Areas.PA,
            "memory": self._Areas.MK,
        }[area]