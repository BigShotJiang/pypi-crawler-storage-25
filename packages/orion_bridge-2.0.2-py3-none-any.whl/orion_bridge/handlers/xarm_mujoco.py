"""
handlers/xarm_mujoco.py — MuJoCo digital twin for xArm 6 or xArm 7.

Extends BaseXArmHandler with a native MuJoCo backend.
Auto-detects 6 vs 7 joints from the loaded MJCF model.

Architecture:
    SimEngine (background thread)
        ↕ thread-safe lock
    MuJoCoXArmHandler (this file)
        ↕ BaseXArmHandler dispatch
    BridgeDispatcher → WebSocket → Cloud agent
"""

import math
import time
import logging
from pathlib import Path
from typing import Optional

from .base import BaseXArmHandler, approx_fk

log = logging.getLogger("orion_bridge.handlers.xarm_mujoco")

_GRIPPER_ACTUATOR = "gripper"


class MuJoCoXArmHandler(BaseXArmHandler):
    """
    xArm digital twin driven by MuJoCo Python bindings.
    Supports both xArm 6 and xArm 7 — auto-detected from the MJCF.
    """

    def __init__(self, mjcf_path: str = "", viewer: bool = True):
        super().__init__(num_joints=6)
        self._mjcf_path = self._resolve_mjcf(mjcf_path)
        self._viewer = viewer
        self._engine = None
        self._ctrl_idx: list = []
        self._qpos_idx: list = []
        self._grip_idx: Optional[int] = None
        self._state = "idle"


        

    @staticmethod
    def _resolve_mjcf(mjcf_path: str) -> str:
        """Resolve MJCF path: absolute, relative to package, or auto-detect."""
        if not mjcf_path:
            return MuJoCoXArmHandler._default_mjcf()

        p = Path(mjcf_path)
        if p.is_absolute() and p.exists():
            return str(p)

        # Try relative to package root (orion_bridge/)
        pkg = Path(__file__).resolve().parent.parent
        candidate = pkg / mjcf_path
        if candidate.exists():
            return str(candidate)

        # Try relative to CWD
        if p.exists():
            return str(p.resolve())

        # Fall back to auto-detect
        return MuJoCoXArmHandler._default_mjcf()

    @staticmethod
    def _default_mjcf() -> str:
        pkg = Path(__file__).resolve().parent.parent
        for sub in [
            "sim/models/xarm6/scene_xarm6.xml",
            "sim/models/xarm6/xarm6.xml",
            "sim/models/xarm7/scene.xml",
            "sim/models/xarm7/xarm7.xml",
        ]:
            p = pkg / sub
            if p.exists():
                return str(p)
        return str(pkg / "sim/models/xarm6/scene_xarm6.xml")

    def connect(self) -> bool:
        from ..sim.engine import SimEngine
        try:
            log.info(f"MuJoCo xArm: loading {self._mjcf_path}")
            self._engine = SimEngine(self._mjcf_path, realtime=True)

            # Auto-detect arm joints (joint1..joint6 or joint1..joint7)
            detected = 0
            for i in range(1, 8):
                try:
                    self._engine.joint_name_to_qpos_index(f"joint{i}")
                    detected = i
                except KeyError:
                    break

            if detected < 6:
                raise RuntimeError(f"Only {detected} arm joints found — need 6+")

            self._num_joints = detected
            models_dir = Path(__file__).resolve().parent.parent / "sim" / "models"
            urdf_file = models_dir / f"xarm{detected}" / f"xarm{detected}.urdf"
            if urdf_file.exists():
                self._urdf_path = str(urdf_file)
                log.info(f"URDF loaded for IK: {urdf_file.name}")
            else:
                self._urdf_path = None
                log.warning(f"No URDF at {urdf_file} — go_to will be unavailable")

            # Resolve indices (Menagerie: actuators=act1..N, joints=joint1..N)
            self._ctrl_idx = []
            self._qpos_idx = []
            for i in range(1, detected + 1):
                self._ctrl_idx.append(
                    self._engine.actuator_name_to_index(f"act{i}")
                )
                self._qpos_idx.append(
                    self._engine.joint_name_to_qpos_index(f"joint{i}")
                )

            try:
                self._grip_idx = self._engine.actuator_name_to_index(_GRIPPER_ACTUATOR)
            except KeyError:
                self._grip_idx = None

            self._engine.start(viewer=self._viewer)
            self._state = "ready"

            # Attach collision checker (separate MjModel/MjData from SimEngine)
            mjcf = (
                "sim/models/xarm7/scene_xarm7.xml"
                if detected == 7
                else "sim/models/xarm6/scene_xarm6.xml"
            )
            try:
                self.enable_collision_check(mjcf)
                log.info(f"MuJoCo xArm{detected}: collision checker enabled")
                print(f"[CollisionChecker] enabled for xarm{self._num_joints}")
            except Exception as ce:
                log.warning(f"MuJoCo xArm: collision checker unavailable — {ce}")
                print(f"[CollisionChecker] FAILED: {ce}")
            print(f"[CollisionChecker] checker is {self._collision_checker}")

            log.info(f"MuJoCo xArm{detected}: connected ({detected} joints)")
            return True
        except Exception as e:
            log.error(f"MuJoCo xArm connect failed: {e}")
            self._engine = None
            return False

    def disconnect(self) -> None:
        if self._engine:
            self._engine.stop()
            self._engine = None
        self._state = "idle"

    @property
    def is_connected(self) -> bool:
        return self._engine is not None and self._engine.is_running

    def _read_joints(self) -> list:
        qpos = self._engine.get_qpos()
        return [
            round(math.degrees(qpos[self._qpos_idx[i]]), 3)
            for i in range(self._num_joints)
        ]

    def _read_tcp(self) -> dict:
        tcp = approx_fk(self._read_joints())
        return {"x": tcp[0], "y": tcp[1], "z": tcp[2],
                "roll": tcp[3], "pitch": tcp[4], "yaw": tcp[5]}

    def _move_to(self, angles_deg: list, speed: float = 30) -> None:
        n = self._num_joints
        current = self._read_joints()
        for i in range(n):
            self._engine.set_ctrl_index(self._ctrl_idx[i], math.radians(angles_deg[i]))
        self._state = "moving"
        max_delta = max(abs(angles_deg[i] - current[i]) for i in range(n))
        timeout = max(4.0, (max_delta / max(speed, 1)) * 1.5 + 3.0)
        self._wait_converge(angles_deg, timeout=timeout)
        self._state = "ready"

    def _get_state(self) -> str:
        return self._state

    def _get_mode(self) -> str:
        return "position control"

    def _estop(self, p: dict) -> dict:
        n = self._num_joints
        current_rad = [math.radians(a) for a in self._read_joints()]
        for i in range(n):
            self._engine.set_ctrl_index(self._ctrl_idx[i], current_rad[i])
        self._state = "emergency_stop"
        return {"stopped": True, "state": "emergency_stop"}

    def _wait_converge(self, target_deg, timeout=8.0, tolerance_deg=3.0):
        n = self._num_joints
        deadline = time.time() + timeout
        settled = 0
        while time.time() < deadline:
            time.sleep(0.05)
            current = self._read_joints()
            if all(abs(current[i] - target_deg[i]) < tolerance_deg for i in range(n)):
                settled += 1
                if settled >= 2:
                    return
            else:
                settled = 0
        final = self._read_joints()
        max_err = max(abs(final[i] - target_deg[i]) for i in range(n))
        raise RuntimeError(f"Converge timeout: max_err={max_err:.1f}° (target not reached)")

    def _get_full_status(self, p: dict) -> dict:
        n = self._num_joints
        qvel = self._engine.get_qvel()
        base = self._get_position(p)
        base.update({
            "joint_velocities": [round(math.degrees(qvel[self._qpos_idx[i]]), 3) for i in range(n)],
            "joint_efforts": [0.0] * n,
            "temperatures": [25.0] * n,
            "currents": [0.0] * n,
            "error_code": 0, "warning_code": 0,
            "gripper_position": self._gripper_pos,
        })
        return base

    def _gripper(self, p: dict) -> dict:
        result = super()._gripper(p)
        if self._grip_idx is not None:
            mujoco_value = 255.0 - ((self._gripper_pos / 850.0) * 255.0)
            self._engine.set_ctrl_index(self._grip_idx, mujoco_value)
        return result

    
        
    def capability_card(self) -> dict:
        """MuJoCo xArm card — extends base with simulator info."""
        card = super().capability_card()
        card["backend"] = "mujoco"
        card["mjcf_path"] = self._mjcf_path
        card["viewer_enabled"] = self._viewer
        return card