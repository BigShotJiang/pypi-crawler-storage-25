"""Allow running as: python -m orion_bridge"""
from orion_bridge.cli import main
main()
