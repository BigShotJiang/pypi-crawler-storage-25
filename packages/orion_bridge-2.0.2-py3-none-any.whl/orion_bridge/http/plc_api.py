"""
orion_bridge/http/plc_api.py — PLC HTTP REST API for Tulip/dashboards.

Extracted from bridge.py. Runs as a sidecar thread via Flask.
Expose with: ngrok http 5000
"""

import time


def make_plc_app(plc_handler):
    """Create a Flask app bound to the given PLCHandler instance."""
    from flask import Flask, jsonify, request as req

    app = Flask("plc_api")

    @app.route("/api/health")
    def health():
        if not plc_handler or not plc_handler.is_connected:
            return jsonify({"status": "no PLCs", "connected_plcs": 0, "total_plcs": 0})
        return jsonify({
            "status": "running",
            "connected_plcs": sum(1 for s in plc_handler._status.values() if s),
            "total_plcs": len(plc_handler._status),
        })

    @app.route("/api/plcs")
    def list_plcs():
        if not plc_handler:
            return jsonify({})
        return jsonify({
            ip: {"connected": st} for ip, st in plc_handler._status.items()
        })

    def _read_handler(ip, byte_address, area):
        try:
            result = plc_handler.handle(
                "read_area",
                {"plc_ip": ip, "area": area, "byte_address": byte_address},
            )
            result["timestamp"] = time.time()
            return jsonify(result)
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    def _write_handler(ip, byte_address, area):
        data = req.get_json()
        if not data or "bit" not in data or "value" not in data:
            return jsonify({"error": "need 'bit' and 'value'"}), 400
        try:
            result = plc_handler.handle(
                "write_bit",
                {
                    "plc_ip": ip, "area": area,
                    "byte_address": byte_address,
                    "bit": data["bit"], "value": data["value"],
                },
            )
            result["timestamp"] = time.time()
            return jsonify(result)
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    # read endpoints
    app.add_url_rule(
        "/api/plc/<ip>/input/<int:ba>/read", "ri",
        lambda ip, ba: _read_handler(ip, ba, "input"),
    )
    app.add_url_rule(
        "/api/plc/<ip>/output/<int:ba>/read", "ro",
        lambda ip, ba: _read_handler(ip, ba, "output"),
    )
    app.add_url_rule(
        "/api/plc/<ip>/memory/<int:ba>/read", "rm",
        lambda ip, ba: _read_handler(ip, ba, "memory"),
    )
    # write endpoints
    app.add_url_rule(
        "/api/plc/<ip>/output/<int:ba>/write", "wo",
        lambda ip, ba: _write_handler(ip, ba, "output"),
        methods=["POST"],
    )
    app.add_url_rule(
        "/api/plc/<ip>/memory/<int:ba>/write", "wm",
        lambda ip, ba: _write_handler(ip, ba, "memory"),
        methods=["POST"],
    )

    return app