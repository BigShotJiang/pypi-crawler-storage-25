"""
orion_bridge/config.py — Configuration, presets, and persistence.
"""
import os
import json
import platform

__all__ = [
    "WS_SERVER_URL", "WS_TOKEN", "BRIDGE_ID",
    "SUPABASE_URL", "SUPABASE_KEY",
    "IS_WINDOWS", "SHELL_WHITELIST", "SHELL_BLOCKED", "SHELL_TIMEOUT",
    "LABS", "DEVICE_TYPES", "CONFIG_FILE",
    "load_config", "save_config",
]

# ── Environment constants ─────────────────────────────────────

WS_SERVER_URL = os.getenv("WS_SERVER_URL", "")
WS_TOKEN      = os.getenv("WS_TOKEN", "")
BRIDGE_ID     = os.getenv("BRIDGE_ID", "lab-bridge-01")

SUPABASE_URL = os.getenv("SUPABASE_URL", "")
SUPABASE_KEY = os.getenv("SUPABASE_KEY", "")

IS_WINDOWS = platform.system().lower() == "windows"

# ── Shell security ────────────────────────────────────────────

SHELL_WHITELIST = [
    c.strip().lower() for c in os.getenv(
        "SHELL_WHITELIST",
        "ping,ipconfig,ifconfig,netstat,nslookup,tracert,traceroute,"
        "systeminfo,hostname,dir,ls,type,cat,echo,python,pip,whoami,tasklist,ps"
    ).split(",") if c.strip()
]

SHELL_BLOCKED = [
    r"\brm\s+-rf\b", r"\bformat\b", r"\bdel\s+/[sfq]\b",
    r"\bshutdown\b", r"\breboot\b", r"\bmkfs\b", r"\bdd\s+if=\b",
    r"\b:(){", r"\breg\s+delete\b", r"\bnet\s+user\b.*\/add",
]
SHELL_TIMEOUT = int(os.getenv("SHELL_TIMEOUT", "30"))

# ── Lab presets ───────────────────────────────────────────────
#
# Structure:
#   top-level key → lab entry
#
# A lab entry can be:
#   - A concrete lab:  has "name", "server", "token", optionally "devices"
#   - A group:         has "name", "group": True, "children": { key: lab_entry, ... }
#
# Groups can nest arbitrarily. print_lab_options() in menus.py handles the
# drill-down automatically.

LABS = {
    "1": {
        "name": "Mezzanine Connect",
        "server": "wss://sentinela-909652673285.us-central1.run.app/ws/robot",
        "token": "UAvKvdXHcWkeE5hocHupBSd95DTuGBUIcsMmxa-UbUc",
        "subnet": "192.168.1.",
        "default_host": "185",
    },
    "2": {
        "name": "Dev",
        "group": True,
        "children": {
            "1": {
                "name": "MuJoCo",
                "group": True,
                "children": {
                    "1": {
                        "name": "xArm 6",
                        "server": "ws://localhost:8000/ws/robot",
                        "token": "dev-bridge-token",
                        "lab_name": "Dev Digital Twin — xArm 6 (MuJoCo)",
                        "devices": [
                            {
                                "type": "xarm",
                                "id": "xarm6-mujoco",
                                "handler": "mujoco",
                                "viewer": True,
                                "mjcf_path": "sim/models/xarm6/scene_xarm6.xml",
                            },
                            {"type": "shell", "id": "shell-local"},
                        ],
                    },
                    "2": {
                        "name": "xArm 7",
                        "server": "ws://localhost:8000/ws/robot",
                        "token": "dev-bridge-token",
                        "lab_name": "Dev Digital Twin — xArm 7 (MuJoCo)",
                        "devices": [
                            {
                                "type": "xarm",
                                "id": "xarm7-mujoco",
                                "handler": "mujoco",
                                "viewer": True,
                                "mjcf_path": "sim/models/xarm7/scene_xarm7.xml",
                            },
                            {"type": "shell", "id": "shell-local"},
                        ],
                    },
                },
            },
            "2": {
                "name": "Gazebo",
                "group": True,
                "children": {
                    "1": {
                        "name": "xArm 6",
                        "server": "ws://localhost:8000/ws/robot",
                        "token": "dev-bridge-token",
                        "lab_name": "Dev Digital Twin — xArm 6 (Gazebo)",
                        "devices": [
                            {
                                "type": "xarm",
                                "id": "xarm6-gazebo",
                                "handler": "gazebo",
                            },
                            {"type": "shell", "id": "shell-local"},
                        ],
                    },
                    "2": {
                        "name": "xArm 7",
                        "server": "ws://localhost:8000/ws/robot",
                        "token": "dev-bridge-token",
                        "lab_name": "Dev Digital Twin — xArm 7 (Gazebo)",
                        "devices": [
                            {
                                "type": "xarm",
                                "id": "xarm7-gazebo",
                                "handler": "gazebo",
                            },
                            {"type": "shell", "id": "shell-local"},
                        ],
                    },
                },
            },
        },
    },
}

# ── Device type definitions ───────────────────────────────────

DEVICE_TYPES = {
    "1": {"type": "xarm",  "label": "xArm (UFACTORY)"},
    "2": {"type": "abb",   "label": "ABB IRB"},
    "3": {"type": "plc",   "label": "Siemens PLC (S7)"},
    "4": {"type": "shell", "label": "Shell / Network"},
}

# ── Config persistence ────────────────────────────────────────

CONFIG_FILE = "lab_config.json"

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {"server": None, "token": None, "lab_name": "Local",
            "devices": [{"type": "shell", "id": "shell-local"}]}

def save_config(config):
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)