"""orion_bridge/ui/menus.py — Interactive menus and prompt."""

from rich.rule import Rule
from rich.text import Text

from orion_bridge.ui.theme import console, DEVICE_ICONS, DEVICE_STYLES

__all__ = ["print_menu", "print_device_types", "pick_lab", "print_lab_options", "prompt"]


def print_menu():
    """Print the interactive main menu."""
    console.print()
    console.print(Rule("[bold white]Menu[/bold white]", style="dim white"))
    console.print()

    items = [
        ("1", "Add device"),
        ("2", "Remove device"),
        ("3", "Configure server"),
        ("4", "Show config"),
        ("5", "Save config"),
        ("6", "Start bridge"),
        ("0", "Exit"),
    ]

    for key, label in items:
        if key == "6":
            console.print(f"  [bold white]> {key}[/bold white]  [bold white]{label}[/bold white]")
        elif key == "0":
            console.print(f"  [muted]  {key}[/muted]  [muted]{label}[/muted]")
        else:
            console.print(f"  [menu.key]  {key}[/menu.key]  [menu.label]{label}[/menu.label]")

    console.print()


def print_device_types(device_types: dict):
    """Print device types for selection."""
    console.print()
    console.print("  [label]Device types:[/label]")
    for key, info in device_types.items():
        dtype = info["type"]
        icon  = DEVICE_ICONS.get(dtype, "-")
        style = DEVICE_STYLES.get(dtype, "white")
        console.print(f"    [{style}]{icon}[/{style}] [menu.key]{key}[/menu.key]  {info['label']}")
    console.print()


# ── Lab picker ────────────────────────────────────────────────────────────────

def _print_lab_level(entries: dict, breadcrumb: str = ""):
    """Render one level of the lab menu."""
    console.print()
    if breadcrumb:
        console.print(f"  [dim white]{breadcrumb}[/dim white]")
    console.print("  [label]Available labs:[/label]")
    console.print()

    for key, lab in entries.items():
        if lab.get("group"):
            console.print(
                f"  [menu.key]  {key}[/menu.key]  [menu.label]{lab['name']}[/menu.label]"
                f"  [dim white]›[/dim white]"
            )
        else:
            console.print(f"  [menu.key]  {key}[/menu.key]  [menu.label]{lab['name']}[/menu.label]")

    console.print(f"  [muted]  0[/muted]  [muted]Local only (no server)[/muted]")
    console.print(f"  [menu.key]  c[/menu.key]  [menu.label]Custom URL[/menu.label]")
    console.print()


def _resolve_choice(raw: str, entries: dict) -> str | None:
    """
    Match user input to a key in entries.
    Accepts: exact key ("2"), case-insensitive full or prefix name ("dev", "mujoco", "xarm 7").
    Returns the matched key or None.
    """
    raw = raw.strip()

    # Exact key match first
    if raw in entries:
        return raw

    # Name match — case-insensitive, prefix ok
    raw_lower = raw.lower()
    for key, lab in entries.items():
        name = lab.get("name", "").lower()
        if name == raw_lower or name.startswith(raw_lower):
            return key

    return None


def pick_lab(labs: dict) -> dict | None:
    """
    Interactive drill-down lab picker.

    Accepts both numeric keys ("2") and names ("dev", "mujoco", "xarm 7").
    Returns a concrete lab dict (guaranteed to have "server", "token", "lab_name"),
    or None for local-only.
    """
    current: dict = labs
    breadcrumb_parts: list[str] = []

    while True:
        _print_lab_level(current, " › ".join(breadcrumb_parts) if breadcrumb_parts else "")

        raw = prompt("Select").strip()

        if raw in ("0", ""):
            return None

        if raw.lower() == "c":
            url   = prompt("Server URL")
            token = prompt("Token (leave blank if none)")
            return {"server": url, "token": token or "", "lab_name": "Custom"}

        key = _resolve_choice(raw, current)
        if key is None:
            console.print("  [muted]Invalid option.[/muted]")
            continue

        selected = current[key]

        if selected.get("group"):
            # Drill into subgroup — never return a group dict
            breadcrumb_parts.append(selected["name"])
            current = selected["children"]
        else:
            # Concrete lab — ensure lab_name exists
            if "lab_name" not in selected:
                selected = dict(selected)
                selected["lab_name"] = " › ".join(breadcrumb_parts + [selected["name"]])
            return selected


def print_lab_options(labs: dict):
    """Backward-compat shim. Use pick_lab() for interactive selection."""
    _print_lab_level(labs)


def prompt(text: str = "> ", default: str = "") -> str:
    """Styled input prompt."""
    suffix = f" [{default}]" if default else ""
    try:
        result = console.input(f"  [bold white]>[/bold white] {text}{suffix}: ").strip()
        return result or default
    except (EOFError, KeyboardInterrupt):
        return default