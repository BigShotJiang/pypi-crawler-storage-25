"""orion_bridge/ui/tables.py — Device table and connection panel."""

from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.padding import Padding
from rich import box

from orion_bridge.ui.theme import console, DEVICE_ICONS, DEVICE_STYLES

__all__ = ["print_devices", "print_connection_panel"]


def print_connection_panel(config: dict):
    """Show connection info panel."""
    server = config.get("server", None)
    lab = config.get("lab_name", "Local")
    device_count = len(config.get("devices", []))

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("key", style="label", width=22)
    table.add_column("value", style="value")

    if server:
        display_url = server
        if len(display_url) > 50:
            display_url = display_url[:47] + "..."
        table.add_row("Server Connection:", display_url)
    else:
        table.add_row("Server Connection:", "[muted]local only[/muted]")

    table.add_row("Lab:", lab)
    table.add_row("Devices:", str(device_count))
    table.add_row("Bridge ID:", config.get("bridge_id", "lab-bridge-01"))

    panel = Panel(
        table,
        title="[bold white]Connection[/bold white]",
        title_align="left",
        border_style="dim white",
        box=box.ROUNDED,
        padding=(1, 2),
        width=min(70, console.width - 6),
    )
    console.print(Padding(panel, (0, 0, 0, 2)))


def print_devices(config: dict, show_status: bool = False):
    """Print registered devices as a styled table."""
    devices = config.get("devices", [])

    if not devices:
        console.print(
            Panel(
                "[muted]No devices registered. Add one from the menu.[/muted]",
                border_style="dim white",
                box=box.ROUNDED,
                padding=(1, 2),
            )
        )
        return

    table = Table(
        title=f"[label]Registered Devices[/label]  [muted]({len(devices)})[/muted]",
        box=box.SIMPLE,
        border_style="dim white",
        header_style="bold white",
        title_style="",
        padding=(0, 1),
        show_lines=False,
    )

    table.add_column("#", style="muted", width=4, justify="right")
    table.add_column("Device", style="label", min_width=18)
    table.add_column("Type", min_width=10)
    table.add_column("IP / Target", style="value", min_width=20)
    table.add_column("Details", style="muted")
    if show_status:
        table.add_column("Status", justify="center", width=8)

    for i, dev in enumerate(devices, 1):
        dtype = dev.get("type", "?")
        did = dev.get("id", "?")
        icon = DEVICE_ICONS.get(dtype, "-")
        style = DEVICE_STYLES.get(dtype, "white")

        ip = dev.get("ip", "")
        if not ip and isinstance(dev.get("ips"), list):
            ips_list = dev["ips"]
            ip = ips_list[0] + ("..." if len(ips_list) > 1 else "")
        if dtype == "shell":
            ip = "localhost"

        extra = ""
        if dtype == "abb":
            extra = f"port {dev.get('port', 1025)}"
        elif dtype == "plc" and isinstance(dev.get("ips"), list):
            extra = f"{len(dev['ips'])} PLC(s)"

        type_text = Text(f"{icon} {dtype}", style=style)

        row = [str(i), did, type_text, ip or "-", extra]
        if show_status:
            row.append(Text("+ ON", style="status.on") if dev.get("_connected") else Text("- OFF", style="status.off"))

        table.add_row(*row)

    console.print(Padding(table, (0, 0, 0, 2)))
