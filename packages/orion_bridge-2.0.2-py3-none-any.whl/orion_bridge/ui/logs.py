"""orion_bridge/ui/logs.py — WebSocket event logging."""

from datetime import datetime

from orion_bridge.ui.theme import console

__all__ = ["log_ws_event"]


def log_ws_event(device_id: str, direction: str, action: str, status: str = "", request_id: str = ""):
    """Print a styled WebSocket event log line."""
    now = datetime.now().strftime("%H:%M:%S")
    arrow = "[bold white]<-[/bold white]" if direction == "in" else "[bold white]->[/bold white]"

    status_style = "bold white" if status == "ok" else "dim white" if status == "error" else "muted"
    status_text = f" [{status_style}]{status}[/{status_style}]" if status else ""
    rid = f" [muted](id={request_id})[/muted]" if request_id else ""

    console.print(f"  [muted]{now}[/muted] [white]{device_id}[/white] {arrow} {action}{status_text}{rid}")
