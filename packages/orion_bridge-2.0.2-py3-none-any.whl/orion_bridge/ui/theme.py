"""orion_bridge/ui/theme.py — Theme, console instance, and shared constants."""

from rich.console import Console
from rich.theme import Theme

from orion_bridge import __version__ as VERSION, __codename__ as CODENAME

__all__ = [
    "console", "ORION_THEME", "RICH_AVAILABLE",
    "VERSION", "CODENAME",
    "DEVICE_ICONS", "DEVICE_STYLES",
    "BANNER", "BANNER_COMPACT", "SUBTITLE",
]

RICH_AVAILABLE = True

ORION_THEME = Theme({
    "header":       "bold white",
    "accent":       "bold white",
    "accent.dim":   "dim white",
    "success":      "bold white",
    "warning":      "bold white",
    "danger":       "bold white",
    "muted":        "dim white",
    "label":        "bold white",
    "value":        "white",
    "device.xarm":  "bold white",
    "device.abb":   "bold white",
    "device.plc":   "bold white",
    "device.shell": "dim white",
    "status.on":    "bold white",
    "status.off":   "dim white",
    "menu.key":     "bold white",
    "menu.label":   "white",
    "info":         "dim white",
})

console = Console(theme=ORION_THEME)

DEVICE_ICONS = {
    "xarm":  ">",
    "abb":   ">",
    "plc":   "*",
    "shell": "-",
}

DEVICE_STYLES = {
    "xarm":  "device.xarm",
    "abb":   "device.abb",
    "plc":   "device.plc",
    "shell": "device.shell",
}

BANNER = r"""[bold white]
   ___  ____  ___ ___  _  _
  / _ \|  _ \|_ _/ _ \| \| |
 | | | | |_) || | | | |  ` |
 | |_| |  _ < | | |_| | |\ |
  \___/|_| \_|___\___/|_| \_|[/bold white]"""

BANNER_COMPACT = r"""[bold white]
  ORION[/bold white]"""

SUBTITLE = "[dim white]Lab Bridge[/dim white]  [white]v{version}[/white]  [dim white]|[/dim white]  [white]{codename}[/white]"
