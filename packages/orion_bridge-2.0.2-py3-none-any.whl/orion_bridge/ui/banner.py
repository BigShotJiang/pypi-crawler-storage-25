"""orion_bridge/ui/banner.py — ORION startup header."""

import platform
from datetime import datetime

from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.padding import Padding
from rich.console import Group
from rich.rule import Rule
from rich import box

from orion_bridge.ui.theme import console, DEVICE_ICONS, DEVICE_STYLES, VERSION, CODENAME, BANNER

__all__ = ["print_header"]


def _build_main_panel(config: dict) -> Panel:
    """
    Single unified panel — logo top, connection info bottom, devices inside.
    Title shows version, subtitle shows 'New Session' on the right.
    """
    # ── Logo block ────────────────────────────────────────────────
    banner_text = Text.from_markup(BANNER)

    # ── Divider ───────────────────────────────────────────────────
    divider = Rule(style="dim white")

    # ── Connection table ──────────────────────────────────────────
    server  = config.get("server", None)
    lab     = config.get("lab_name", "Local")
    bridge_id = config.get("bridge_id", "lab-bridge-01")
    devices = config.get("devices", [])

    display = (server[:52] + "...") if server and len(server) > 52 else (server or "local only")

    conn = Table(show_header=False, box=None, padding=(0, 1))
    conn.add_column("key",   style="dim white", min_width=22)
    conn.add_column("value", style="white")
    conn.add_row("Server Connection:", display)
    conn.add_row("Lab:",               lab)
    conn.add_row("Devices:",           str(len(devices)))
    conn.add_row("Bridge ID:",         bridge_id)

    # ── Sysinfo footer ────────────────────────────────────────────
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    sysinfo = Text()
    sysinfo.append(f"\n  {platform.node()}  ", style="dim white")
    sysinfo.append("|", style="dim white")
    sysinfo.append(f"  {platform.system()} {platform.release()}  ", style="dim white")
    sysinfo.append("|", style="dim white")
    sysinfo.append(f"  {now}", style="dim white")

    content = Group(banner_text, divider, conn, sysinfo)

    return Panel(
        content,
        title=f"[dim white]Lab Bridge[/dim white]  [white]v{VERSION}[/white]  [dim white]|[/dim white]  [white]{CODENAME}[/white]",
        title_align="left",
        subtitle="[bold white underline]New Session[/bold white underline]",
        subtitle_align="right",
        border_style="dim white",
        box=box.ROUNDED,
        padding=(1, 2),
    )


def _build_devices_panel(config: dict) -> Panel:
    """Full-width devices table, shown below the main panel."""
    devices = config.get("devices", [])

    if not devices:
        return Panel(
            Text("  No devices configured.", style="dim white"),
            title="[bold white]Registered Devices[/bold white]",
            title_align="left",
            border_style="dim white",
            box=box.ROUNDED,
            padding=(0, 1),
        )

    table = Table(show_header=True, box=None, padding=(0, 1), header_style="dim white")
    table.add_column("#",           width=3, justify="right")
    table.add_column("Device",      min_width=16)
    table.add_column("Type",        min_width=10)
    table.add_column("IP / Target", min_width=14)

    for i, dev in enumerate(devices, 1):
        dtype = dev.get("type", "?")
        did   = dev.get("id",   "?")
        icon  = DEVICE_ICONS.get(dtype, "-")
        style = DEVICE_STYLES.get(dtype, "white")

        ip = dev.get("ip", "")
        if not ip and isinstance(dev.get("ips"), list):
            ip = dev["ips"][0] + ("..." if len(dev["ips"]) > 1 else "")
        if dtype == "shell":
            ip = "localhost"

        table.add_row(
            Text(str(i),            style="dim white"),
            Text(did,               style=style),
            Text(f"{icon} {dtype}", style=style),
            Text(ip or "-",         style="white"),
        )

    return Panel(
        table,
        title=f"[bold white]Registered Devices[/bold white]  [dim white]({len(devices)})[/dim white]",
        title_align="left",
        border_style="dim white",
        box=box.ROUNDED,
        padding=(0, 1),
    )


def print_header(config: dict = None, compact: bool = False):
    """
    Print the ORION startup header — single panel, always reactive to terminal width.

    Parameters
    ----------
    config : dict, optional
        Bridge config: server, lab_name, devices, bridge_id.
    compact : bool
        Unused (kept for API compat). Layout is always single-column.
    """
    if config is None:
        config = {}

    main    = _build_main_panel(config)
    devices = _build_devices_panel(config)

    console.print()
    console.print(Padding(main,    (0, 2)))
    console.print(Padding(devices, (0, 2)))
    console.print()