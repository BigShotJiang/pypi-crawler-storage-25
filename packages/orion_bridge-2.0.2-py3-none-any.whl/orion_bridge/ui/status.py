"""orion_bridge/ui/status.py — Status messages and bridge active panel."""

from typing import Optional

from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.padding import Padding
from rich.rule import Rule
from rich import box

from orion_bridge.ui.theme import console, DEVICE_ICONS, DEVICE_STYLES

__all__ = [
    "msg_success", "msg_error", "msg_warning", "msg_info",
    "print_bridge_active", "connecting_spinner",
]


def msg_success(text: str):
    console.print(f"  [bold white]+[/bold white] {text}")

def msg_error(text: str):
    console.print(f"  [bold white]x[/bold white] {text}")

def msg_warning(text: str):
    console.print(f"  [bold white]![/bold white] {text}")

def msg_info(text: str):
    console.print(f"  [muted]-[/muted] {text}")


def print_bridge_active(config: dict, dispatcher_status: dict, plc_http_port: Optional[int] = None):
    """
    Print the 'bridge is active' status panel.

    dispatcher_status: {device_id: {"type": str, "connected": bool}, ...}
    """
    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("icon", width=3)
    table.add_column("device", min_width=20)
    table.add_column("status", width=12)

    for did, info in dispatcher_status.items():
        dtype = info.get("type", "?")
        connected = info.get("connected", False)
        icon = DEVICE_ICONS.get(dtype, "-")
        style = DEVICE_STYLES.get(dtype, "white")

        status_text = Text("+ online", style="status.on") if connected else Text("- offline", style="status.off")
        table.add_row(
            Text(icon, style=style),
            Text(f"{dtype}/{did}", style=style),
            status_text,
        )

    server = config.get("server")
    lab = config.get("lab_name", "Local")

    sections = []
    sections.append(f"[label]Lab[/label]        [value]{lab}[/value]")
    if server:
        display = server[:50] + "..." if len(server) > 50 else server
        sections.append(f"[label]Server[/label]     [value]{display}[/value]")
    else:
        sections.append(f"[label]Mode[/label]       [muted]LOCAL (no server)[/muted]")

    if plc_http_port:
        sections.append(f"[label]PLC API[/label]    [value]http://0.0.0.0:{plc_http_port}[/value]")
        sections.append(f"[muted]           expose with: ngrok http {plc_http_port}[/muted]")

    inner = Panel(
        table,
        title="[label]Devices[/label]",
        title_align="left",
        border_style="dim white",
        box=box.ROUNDED,
        padding=(0, 1),
    )

    console.print()
    console.print(Rule("[bold white]ORION Lab Bridge -- ACTIVE[/bold white]", style="dim white"))
    console.print()
    for line in sections:
        console.print(f"  {line}")
    console.print()
    console.print(Padding(inner, (0, 0, 0, 2)))
    console.print()
    console.print("  [muted]Press Ctrl+C to stop[/muted]")
    console.print()


def connecting_spinner(device_id: str, device_type: str):
    """Return a context manager for a connecting spinner."""
    style = DEVICE_STYLES.get(device_type, "white")
    icon = DEVICE_ICONS.get(device_type, "-")
    return console.status(
        f"[{style}]{icon} Connecting {device_type}/{device_id}...[/{style}]",
        spinner="dots",
        spinner_style="white",
    )
