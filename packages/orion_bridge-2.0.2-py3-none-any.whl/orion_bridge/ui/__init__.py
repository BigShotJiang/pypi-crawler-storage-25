"""
orion_bridge/ui — Rich TUI for ORION Lab Bridge.
Graceful fallback to plain text if Rich is not installed.
"""

try:
    from orion_bridge.ui.theme import console, RICH_AVAILABLE
    from orion_bridge.ui.banner import print_header
    from orion_bridge.ui.tables import print_devices, print_connection_panel
    from orion_bridge.ui.menus import print_menu, print_device_types, pick_lab, print_lab_options, prompt
    from orion_bridge.ui.status import (
        msg_success, msg_error, msg_warning, msg_info,
        print_bridge_active, connecting_spinner,
    )
    from orion_bridge.ui.logs import log_ws_event
    RICH_UI = True
except ImportError:
    RICH_UI = False

    def print_header(config: dict = None, compact: bool = False):
        print("  ORION Lab Bridge")

    def print_devices(config: dict, show_status: bool = False):
        devices = config.get("devices", [])
        if not devices:
            print("  No devices registered.")
            return
        print(f"\n  Devices ({len(devices)}):")
        for i, dev in enumerate(devices, 1):
            print(f"    {i}) [{dev.get('type','?')}] {dev.get('id','?')}  {dev.get('ip','')} ")

    def print_connection_panel(config: dict):
        server = config.get("server") or "local only"
        print(f"  Server: {server}")
        print(f"  Lab: {config.get('lab_name', 'Local')}")

    def print_menu():
        print("\n  1) Add device")
        print("  2) Remove device")
        print("  3) Configure server")
        print("  4) Show config")
        print("  5) Save config")
        print("  6) Start bridge")
        print("  0) Exit\n")

    def print_device_types(device_types: dict):
        print("\n  Device types:")
        for k, info in device_types.items():
            print(f"    {k}) {info['label']}")

    def pick_lab(labs: dict):
        """Plain-text fallback for pick_lab."""
        def _show(entries, crumb=""):
            print(f"\n  {'  ' + crumb if crumb else ''}Available labs:")
            for key, lab in entries.items():
                suffix = " >" if lab.get("group") else ""
                print(f"    {key}) {lab['name']}{suffix}")
            print("    0) Local only")
            print("    c) Custom URL")

        current = labs
        breadcrumb = []
        while True:
            _show(current, " › ".join(breadcrumb))
            raw = input("  Select: ").strip()
            if raw in ("0", ""):
                return None
            if raw.lower() == "c":
                url   = input("  Server URL: ").strip()
                token = input("  Token: ").strip()
                return {"server": url, "token": token, "lab_name": "Custom"}
            # key or name match
            key = raw if raw in current else next(
                (k for k, v in current.items() if v.get("name","").lower().startswith(raw.lower())), None
            )
            if key is None:
                print("  Invalid.")
                continue
            sel = current[key]
            if sel.get("group"):
                breadcrumb.append(sel["name"])
                current = sel["children"]
            else:
                if "lab_name" not in sel:
                    sel = dict(sel)
                    sel["lab_name"] = " › ".join(breadcrumb + [sel["name"]])
                return sel

    def print_lab_options(labs: dict):
        print("\n  Available labs:")
        for key, lab in labs.items():
            print(f"    {key}) {lab['name']}")
        print("    0) Local only (no server)")
        print("    c) Custom URL")

    def prompt(text: str = "> ", default: str = "") -> str:
        if default:
            value = input(f"  {text} [{default}]: ").strip()
        elif text:
            value = input(f"  {text}: ").strip()
        else:
            value = input("  > ").strip()
        return value or default

    def msg_success(text: str):
        print(f"  + {text}")

    def msg_error(text: str):
        print(f"  x {text}")

    def msg_warning(text: str):
        print(f"  ! {text}")

    def msg_info(text: str):
        print(f"  - {text}")

    def print_bridge_active(config: dict, dispatcher_status: dict, plc_http_port=None):
        print("\n  -- ORION Lab Bridge ACTIVE --")
        print(f"  Lab: {config.get('lab_name', 'Local')}")
        server = config.get("server")
        if server:
            print(f"  Server: {server}")
        else:
            print("  Mode: LOCAL (no server)")
        if plc_http_port:
            print(f"  PLC API: http://0.0.0.0:{plc_http_port}")
        for did, info in dispatcher_status.items():
            state = "+ online" if info.get("connected") else "- offline"
            print(f"    [{info.get('type','?')}] {did}  {state}")
        print("\n  Press Ctrl+C to stop\n")

    from contextlib import contextmanager

    @contextmanager
    def connecting_spinner(device_id: str, device_type: str):
        print(f"  Connecting {device_type}/{device_id}...")
        yield

    def log_ws_event(device_id: str, direction: str, action: str, status: str = "", request_id: str = ""):
        from datetime import datetime
        now = datetime.now().strftime("%H:%M:%S")
        arrow = "<-" if direction == "in" else "->"
        rid = f" (id={request_id})" if request_id else ""
        st = f" {status}" if status else ""
        print(f"  {now} {device_id} {arrow} {action}{st}{rid}")


__all__ = [
    "RICH_UI", "print_header", "print_devices", "print_connection_panel",
    "print_menu", "print_device_types", "pick_lab", "print_lab_options", "prompt",
    "msg_success", "msg_error", "msg_warning", "msg_info",
    "print_bridge_active", "connecting_spinner", "log_ws_event",
]