"""
logger.py — Supabase telemetry logger (optional, won't crash if missing).

Extracted from bridge.py (Phase 3, Step 2).
"""

import json
import os
import logging
from datetime import datetime, timezone

log = logging.getLogger("orion_bridge.logger")

SUPABASE_URL = os.getenv("SUPABASE_URL", "")
SUPABASE_KEY = os.getenv("SUPABASE_KEY", "")


class SupabaseLogger:
    def __init__(self):
        self._client = None
        if SUPABASE_URL and SUPABASE_KEY:
            try:
                from supabase import create_client

                self._client = create_client(SUPABASE_URL, SUPABASE_KEY)
                log.info("Supabase logger ready")
            except Exception as e:
                log.warning(f"Supabase init failed: {e}")

    def log_movement(self, device_id, command, data):
        if not self._client:
            return
        try:
            row = {
                "device_id": device_id,
                "command": command,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            if isinstance(data.get("tcp"), dict):
                tcp = data["tcp"]
                row["actual_x"] = tcp.get("x")
                row["actual_y"] = tcp.get("y")
                row["actual_z"] = tcp.get("z")
            if isinstance(data.get("target"), dict):
                t = data["target"]
                row["target_x"] = t.get("x")
                row["target_y"] = t.get("y")
                row["target_z"] = t.get("z")
            if "speed" in data:
                row["speed"] = data["speed"]
            if isinstance(data.get("euler"), dict):
                e = data["euler"]
                row["actual_ex"] = e.get("ex")
                row["actual_ey"] = e.get("ey")
                row["actual_ez"] = e.get("ez")
            self._client.table("robot_movements").insert(row).execute()
        except Exception as e:
            log.error(f"Supabase log_movement failed: {e}")

    def log_diagnostic(self, device_id, action, result):
        if not self._client:
            return
        try:
            self._client.table("bridge_command_log").insert(
                {
                    "device_id": device_id,
                    "action": action,
                    "success": result.get("status") == "ok",
                    "result_summary": json.dumps(
                        result.get("data", result.get("error", ""))
                    )[:500],
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
            ).execute()
        except Exception:
            pass


# Global instance — safe to import even without Supabase credentials
sb_logger = SupabaseLogger()