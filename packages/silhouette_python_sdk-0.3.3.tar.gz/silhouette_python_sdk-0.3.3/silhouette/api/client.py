"""Silhouette API client for integrating with the enclave API."""

import asyncio
import json
import logging
import threading
from collections.abc import Callable
from functools import wraps
from typing import Any, cast
from urllib.parse import urlparse, urlunparse

import requests
import websockets

from silhouette.api.auth import AuthConfig, AuthManager
from silhouette.api.generated import (
    BatchGetDelegatedOrdersRequest,
    BatchGetDelegatedOrdersResponse,
    CancelOrderRequest,
    CancelOrderResponse,
    CreateOrderRequest,
    CreateOrderResponse,
    CreateRfqIntentRequest,
    CreateRfqIntentResponse,
    GetActiveRfqsRequest,
    GetActiveRfqsResponse,
    GetBalancesResponse,
    GetDelegatedOrderRequest,
    GetDelegatedOrderResponse,
    GetExistingUserDetailsRequest,
    GetExistingUserDetailsResponse,
    GetHealthFeaturesResponse,
    GetHealthInfoResponse,
    GetHealthReadyResponse,
    GetHealthResponse,
    GetQuotesRequest,
    GetQuotesResponse,
    GetRfqsRequest,
    GetRfqsResponse,
    GetUserOrdersRequest,
    GetUserOrdersResponse,
    GetUserWithdrawalsRequest,
    GetUserWithdrawalsResponse,
    GetWithdrawalStatusRequest,
    GetWithdrawalStatusResponse,
    InitiateWithdrawalRequest,
    InitiateWithdrawalResponse,
    ListDelegatedOrdersRequest,
    ListDelegatedOrdersResponse,
    RegisterNewUserRequest,
    RegisterNewUserResponse,
    SetReferrerResponse,
    SubmitRfqQuoteRequest,
    SubmitRfqQuoteResponse,
)
from silhouette.api.rfq_types import RfqEvent

logger = logging.getLogger(__name__)


def parse_response(
    model_class: type[Any],
) -> Callable[..., Callable[..., dict[str, Any]]]:
    """Decorator that parses API responses using a Pydantic model and returns a clean dict.

    This decorator:
    1. Validates the response using the specified Pydantic model
    2. Converts the model to a dict with camelCase keys (by_alias=True)
    3. Removes the redundant 'operation' field from the response
    4. Returns a clean dict that clients can use without importing generated models

    Args:
        model_class: The Pydantic model class to use for validation

    Returns:
        A decorator function that wraps API operation methods
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., dict[str, Any]]:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> dict[str, Any]:
            response: Any = func(*args, **kwargs)
            result = model_class.model_validate(response)
            result_dict: dict[str, Any] = result.model_dump(by_alias=True, exclude_none=True)
            result_dict.pop("operation", None)  # Remove redundant operation field
            return result_dict

        return wrapper

    return decorator


def build_request(model_class: type[Any], **kwargs: Any) -> dict[str, Any]:
    """Build and serialize a request model with snake_case params converted to camelCase."""
    filtered = {k: v for k, v in kwargs.items() if v is not None}
    request = model_class(**filtered)
    return request.model_dump(by_alias=True, exclude_none=True)  # type: ignore[no-any-return]


class SilhouetteApiError(Exception):
    """Custom exception for Silhouette API errors."""

    def __init__(self, code: str, message: str, status: int | None):
        super().__init__(f"API Error [{code}]: {message} (HTTP {status})")
        self.code = code
        self.message = message
        self.status = status


class HealthOperations:
    """Health endpoint operations for the enclave API."""

    def __init__(self, client: "SilhouetteApiClient"):
        self._client = client

    @parse_response(GetHealthResponse)
    def get_health(self) -> dict[str, Any]:
        """Get basic health check information.

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - status: str (e.g., "healthy")
        """
        return self._client._request_operation("getHealth")

    @parse_response(GetHealthFeaturesResponse)
    def get_features(self) -> dict[str, Any]:
        """Get health features discovery information.

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - features: dict (enabled feature flags)
        """
        return self._client._request_operation("getHealthFeatures")

    @parse_response(GetHealthInfoResponse)
    def get_info(self) -> dict[str, Any]:
        """Get detailed system info (debug mode only).

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - info: dict (system information)
        """
        return self._client._request_operation("getHealthInfo")

    @parse_response(GetHealthReadyResponse)
    def get_ready(self) -> dict[str, Any]:
        """Get health readiness check.

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - ready: bool
        """
        return self._client._request_operation("getHealthReady")


class MarketOperations:
    """Market endpoint operations for the enclave API."""

    def __init__(self, client: "SilhouetteApiClient"):
        self._client = client

    def get_tokens(self) -> dict[str, Any]:
        """Returns metadata for all supported tokens.

        Returns:
            dict with 'tokens' list containing metadata (name, fullName, tokenId, etc.)
        """
        response = self._client._request_operation("getTokens")
        result = response.get("result", response)
        return cast(dict[str, Any], result)

    def get_markets(self) -> dict[str, Any]:
        """Returns metadata for all supported trading pairs.

        Returns:
            dict with 'markets' list containing metadata (name, baseToken, quoteToken, etc.)
        """
        response = self._client._request_operation("getMarkets")
        result = response.get("result", response)
        return cast(dict[str, Any], result)


class TestOperations:
    """Test endpoint operations for the enclave API."""

    __test__ = False

    def __init__(self, client: "SilhouetteApiClient"):
        self._client = client

    def get_test_balance(self, address: str) -> dict[str, Any]:
        """Get test balances for a given address."""
        return self._client._request_operation("getTestBalance", {"address": address})

    def wal_stream_test(self) -> dict[str, Any]:
        """Test WAL streaming by flushing pending operations to Kinesis."""
        return self._client._request_operation("testWalStream")

    def wal_capture_state(self, output_path: str | None = None) -> dict[str, Any]:
        """Capture the current database state to a JSON file.

        Args:
            output_path: Optional custom path for the capture file (must be under /tmp/).

        Returns:
            dict with filePath, capturedAt, walSequence, and rowCounts.
        """
        params: dict[str, Any] = {}
        if output_path is not None:
            params["outputPath"] = output_path
        return self._client._request_operation("testWalCaptureState", params)

    def wal_verify_reconstruction(self, capture_file_path: str, from_minutes_ago: int | None = None) -> dict[str, Any]:
        """Verify WAL reconstruction against a previously captured state.

        Args:
            capture_file_path: Path to the capture file from wal_capture_state.
            from_minutes_ago: How far back to fetch WAL records (default: 60).

        Returns:
            dict with verified flag and comparison details.
        """
        params: dict[str, Any] = {"captureFilePath": capture_file_path}
        if from_minutes_ago is not None:
            params["fromMinutesAgo"] = from_minutes_ago
        return self._client._request_operation("testWalVerifyReconstruction", params)

    def wal_reconstruct(self, from_minutes_ago: int | None = None) -> dict[str, Any]:
        """Test WAL reconstruction from Kinesis deltas.

        Args:
            from_minutes_ago: How far back to fetch WAL records (default: 60).

        Returns:
            dict with deltasApplied, comparison results, and any gaps detected.
        """
        params: dict[str, Any] = {}
        if from_minutes_ago is not None:
            params["fromMinutesAgo"] = from_minutes_ago
        return self._client._request_operation("testWalReconstruct", params)


class UserOperations:
    """Authenticated user endpoint operations for the enclave API."""

    __test__ = False

    def __init__(self, client: "SilhouetteApiClient"):
        self._client = client

    @parse_response(GetBalancesResponse)
    def get_balances(self) -> dict[str, Any]:
        """Get user balances.

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - balances: list[dict] (token balances with 'available', 'locked', 'total', etc.)
        """
        return self._client._request_operation("getBalances")

    def get_balance(self, token_symbol: str) -> int:
        """
        Get the available balance for a specific token from the Silhouette enclave.

        This safely handles cases where the user or token is not found, returning 0
        instead of raising an error.

        Args:
            token_symbol: The symbol of the token (e.g., "USDC")

        Returns:
            The available balance as an integer in Silhouette's fixed-point format.

        Raises:
            SilhouetteApiError: For unexpected API errors (not ACCOUNT_NOT_INITIALIZED)
        """
        try:
            balances_response = self.get_balances()
            if balances_response.get("balances"):
                balance_info = next(
                    (b for b in balances_response["balances"] if b.get("token") == token_symbol),
                    None,
                )
                if balance_info and balance_info.get("available"):
                    return int(balance_info["available"])
        except SilhouetteApiError as e:
            if e.code == "ACCOUNT_NOT_INITIALIZED":
                return 0  # User doesn't exist yet, so balance is 0
            raise  # Re-raise other unexpected API errors
        return 0

    def get_balance_float(self, token_symbol: str) -> float:
        """
        Get the available balance for a specific token as a float.

        This uses the `availableFloat` field from the API, returning 0.0 if the
        account is not yet initialized or the token has no balance.

        Args:
            token_symbol: The symbol of the token (e.g., "USDC")

        Returns:
            The available balance as a float.

        Raises:
            SilhouetteApiError: For unexpected API errors (not ACCOUNT_NOT_INITIALIZED)
        """
        try:
            balances_response = self.get_balances()
            if balances_response.get("balances"):
                balance_info = next(
                    (b for b in balances_response["balances"] if b.get("token") == token_symbol),
                    None,
                )
                if balance_info and balance_info.get("availableFloat"):
                    return float(balance_info["availableFloat"])
            return 0.0
        except SilhouetteApiError as e:
            if e.code == "ACCOUNT_NOT_INITIALIZED":
                return 0.0  # User doesn't exist yet, so balance is 0
            raise  # Re-raise other unexpected API errors

    @parse_response(InitiateWithdrawalResponse)
    def initiate_withdrawal(self, token_symbol: str, amount: str) -> dict[str, Any]:
        """Initiate a withdrawal for the authenticated user.

        Args:
            token_symbol: The symbol of the token (e.g., "USDC")
            amount: The amount to withdraw

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - message: str (success message)
                - withdrawalId: str (unique identifier for the withdrawal)
        """
        params = build_request(
            InitiateWithdrawalRequest,
            operation="initiateWithdrawal",
            token_symbol=token_symbol,
            amount=amount,
        )
        return self._client._request_operation("initiateWithdrawal", params)

    @parse_response(GetWithdrawalStatusResponse)
    def get_withdrawal_status(self, withdrawal_id: str) -> dict[str, Any]:
        """Get the status of a specific withdrawal by ID."""
        params = build_request(
            GetWithdrawalStatusRequest,
            operation="getWithdrawalStatus",
            withdrawal_id=withdrawal_id,
        )
        return self._client._request_operation("getWithdrawalStatus", params)

    @parse_response(GetUserWithdrawalsResponse)
    def get_user_withdrawals(self) -> dict[str, Any]:
        """Get all withdrawals for the authenticated user."""
        params = build_request(GetUserWithdrawalsRequest, operation="getUserWithdrawals")
        return self._client._request_operation("getUserWithdrawals", params)


class OrderOperations:
    """Authenticated order endpoint operations for the enclave API."""

    def __init__(self, client: "SilhouetteApiClient"):
        self._client = client

    @parse_response(CreateOrderResponse)
    def create_order(
        self,
        side: str,
        order_type: str,
        base_token: str,
        quote_token: str,
        amount: str | None = None,
        quote_amount: str | None = None,
        slippage: str | None = None,
        price: str | None = None,
    ) -> dict[str, Any]:
        """Create a new order.

        Args:
            side: Order side ("buy" or "sell")
            order_type: Order type ("market" or "limit")
            base_token: Base token symbol (e.g., "HYPE")
            quote_token: Quote token symbol (e.g., "USDC")
            amount: Base token amount (e.g., "1.5" for 1.5 HYPE). Mutually exclusive with quote_amount.
            quote_amount: Quote token amount (e.g., "150" for 150 USDC). Market orders only. Mutually exclusive with amount.
            slippage: Slippage tolerance as a decimal fraction (e.g. "0.0800" for 8%). Defaults to 0.08 server-side.
            price: Limit price as a human-readable decimal (e.g., "25.50"). Required for limit orders, ignored for market orders.

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - orderId: str (unique identifier for the order)
                - message: str (success message)
        """
        params = build_request(
            CreateOrderRequest,
            operation="createOrder",
            side=side,
            order_type=order_type,
            base_token=base_token,
            quote_token=quote_token,
            amount=amount,
            quote_amount=quote_amount,
            slippage=slippage,
            price=price,
        )
        return self._client._request_operation("createOrder", params)

    @parse_response(CancelOrderResponse)
    def cancel_order(self, order_id: str) -> dict[str, Any]:
        """Cancel an open order.

        Args:
            order_id: The order ID (cloid) to cancel. Must be a 0x-prefixed 32-character hex string.

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - orderId: str (the cancelled order ID)
                - message: str (success message)
        """
        params = build_request(
            CancelOrderRequest,
            operation="cancelOrder",
            order_id=order_id,
        )
        return self._client._request_operation("cancelOrder", params)

    @parse_response(GetUserOrdersResponse)
    def get_user_orders(self, status: str | None = None) -> dict[str, Any]:
        """Get all orders for the authenticated user.

        Args:
            status: Optional status filter (e.g., "open", "filled", "cancelled")

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - orders: list[dict] (order records)
        """
        params = build_request(GetUserOrdersRequest, operation="getUserOrders", status=status)
        return self._client._request_operation("getUserOrders", params)


class DelegatedOrderOperations:
    """Authenticated delegated order endpoint operations for the enclave API."""

    def __init__(self, client: "SilhouetteApiClient"):
        self._client = client

    @parse_response(ListDelegatedOrdersResponse)
    def list_delegated_orders(
        self,
        status: str | None = None,
        order_type: str | None = None,
        created_after: int | None = None,
        created_before: int | None = None,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """List delegated orders with filters and pagination.

        Args:
            status: Filter by order status (e.g., "open", "filled", "cancelled")
            order_type: Filter by order type ("limit" or "market")
            created_after: Filter orders created after this timestamp (ms)
            created_before: Filter orders created before this timestamp (ms)
            limit: Maximum number of orders to return (1-100)
            cursor: Pagination cursor for next page

        Returns:
            dict with keys:
                - orders: list[dict] (order records)
                - pagination: dict (hasMore, nextCursor)
                - responseMetadata: dict (timestamp)
        """
        params = build_request(
            ListDelegatedOrdersRequest,
            operation="listDelegatedOrders",
            status=status,
            order_type=order_type,
            created_after=created_after,
            created_before=created_before,
            limit=limit,
            cursor=cursor,
        )
        return self._client._request_operation("listDelegatedOrders", params)

    @parse_response(GetDelegatedOrderResponse)
    def get_delegated_order(self, order_id: str) -> dict[str, Any]:
        """Get a single delegated order by ID.

        Args:
            order_id: The unique identifier of the order

        Returns:
            dict with keys:
                - order: dict (order details)
                - responseMetadata: dict (timestamp)
        """
        params = build_request(
            GetDelegatedOrderRequest,
            operation="getDelegatedOrder",
            order_id=order_id,
        )
        return self._client._request_operation("getDelegatedOrder", params)

    @parse_response(BatchGetDelegatedOrdersResponse)
    def batch_get_delegated_orders(self, order_ids: list[str]) -> dict[str, Any]:
        """Batch get multiple delegated orders by IDs (max 100).

        Args:
            order_ids: List of order IDs to retrieve

        Returns:
            dict with keys:
                - orders: list[dict] (found orders)
                - notFound: list[str] (IDs that weren't found)
                - responseMetadata: dict (timestamp)
        """
        params = build_request(
            BatchGetDelegatedOrdersRequest,
            operation="batchGetDelegatedOrders",
            order_ids=order_ids,
        )
        return self._client._request_operation("batchGetDelegatedOrders", params)


class ReferralOperations:
    """Referral operations for the enclave API."""

    __test__ = False

    def __init__(self, client: "SilhouetteApiClient"):
        self._client = client

    @parse_response(RegisterNewUserResponse)
    def register_new_user(self, referrer_code: str | None = None) -> dict[str, Any]:
        """Register a new user and optionally link a referrer.

        Args:
            referrer_code: Optional referral code of the referrer.

        Returns:
            dict with user details.
        """
        params = build_request(
            RegisterNewUserRequest,
            operation="registerNewUser",
            referrer_code=referrer_code,
        )
        return self._client._request_operation("registerNewUser", params)

    @parse_response(SetReferrerResponse)
    def set_referrer(self, referrer_code: str) -> dict[str, Any]:
        """Set a referrer for an existing user."""
        return self._client._request_operation("setReferrer", {"referrerCode": referrer_code})

    @parse_response(GetExistingUserDetailsResponse)
    def get_existing_user_details(self) -> dict[str, Any]:
        """Get existing user details including referral code."""
        params = build_request(GetExistingUserDetailsRequest, operation="getExistingUserDetails")
        return self._client._request_operation("getExistingUserDetails", params)


class SilhouetteApiClient:
    """
    Silhouette API client for interacting with the enclave API.

    Provides access to health and history operations through a simple,
    synchronous interface that follows Hyperliquid SDK patterns.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8081",
        timeout: float = 30.0,
        private_key: str | None = None,
        keystore_path: str | None = None,
        auto_auth: bool = True,
        max_login_retries: int = 3,
        login_retry_base_delay: float = 1.0,
        login_retry_max_delay: float = 10.0,
        verify_ssl: bool = True,
        chain_id: int = 1,
    ):
        """
        Initialize the Silhouette API client.

        Args:
            base_url: Base URL for the enclave API
            timeout: Request timeout in seconds
            private_key: Private key for auto-authentication (hex string with or without 0x prefix)
            keystore_path: Path to encrypted keystore file (alternative to private_key)
            auto_auth: Enable automatic authentication and token refresh on 401
            max_login_retries: Maximum login retry attempts on failure
            login_retry_base_delay: Base delay for exponential backoff (seconds)
            login_retry_max_delay: Maximum delay for exponential backoff (seconds)
            verify_ssl: Enable SSL certificate verification (defaults to True for production)
            chain_id: Chain ID for SIWE authentication (1 for mainnet, 421614 for Arbitrum Sepolia)
        """
        self.base_url = base_url
        self.timeout = timeout
        self.verify_ssl = verify_ssl

        # Configure connection pooling and retries
        from requests.adapters import HTTPAdapter
        from urllib3.util.retry import Retry

        self._session = requests.Session()
        retry_strategy = Retry(
            total=3,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "OPTIONS"],
            backoff_factor=0.5,
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self._session.mount("https://", adapter)
        self._session.mount("http://", adapter)

        # Initialize auth manager
        auth_config = AuthConfig(
            auto_auth=auto_auth,
            max_login_retries=max_login_retries,
            login_retry_base_delay=login_retry_base_delay,
            login_retry_max_delay=login_retry_max_delay,
            chain_id=chain_id,
        )
        self._auth = AuthManager(
            client=self,
            config=auth_config,
            private_key=private_key,
            keystore_path=keystore_path,
        )

        # Backwards compatibility: expose _jwt_token property
        self._jwt_token: str | None = None

        # Initialize operation groups
        self.health = HealthOperations(self)
        self.market = MarketOperations(self)
        self.test = TestOperations(self)
        self.user = UserOperations(self)
        self.order = OrderOperations(self)
        self.delegated_order = DelegatedOrderOperations(self)
        self.referral = ReferralOperations(self)
        self.rfq = RfqOperations(self)
        self.rfqWs = RfqWebsocketOperations(self)

    def __enter__(self) -> "SilhouetteApiClient":
        """Enter context manager."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any | None,
    ) -> None:
        """Exit context manager and close session."""
        self.close()

    def close(self) -> None:
        """Close the underlying HTTP session to release resources."""
        self._session.close()

    @property
    def wallet(self):
        """Get the wallet used for authentication."""
        return self._auth.wallet

    def login(self, message: str, signature: str) -> str:
        """
        Authenticate with the enclave using a SIWE message and signature.

        Args:
            message: The SIWE message.
            signature: The signature of the message.

        Returns:
            The JWT token string.
        """
        token = self._raw_login(message, signature)
        self._auth.set_token(token)
        self._jwt_token = token  # Backwards compatibility
        return token

    def _raw_login(self, message: str, signature: str) -> str:
        """
        Perform raw login API call without updating auth state.

        This is used internally by AuthManager to avoid circular dependencies.

        Args:
            message: The SIWE message.
            signature: The signature of the message.

        Returns:
            The JWT token string.

        Raises:
            SilhouetteApiError: If login fails
        """
        params = {"message": message, "signature": signature}
        # Use _raw_request to bypass auth logic
        response = self._raw_request("login", params, token=None)
        token_value = response.get("token")
        if not isinstance(token_value, str) or not token_value:
            raise SilhouetteApiError("LOGIN_FAILED", "No token in response", None)
        return token_value

    def _request_operation(
        self,
        operation: str,
        params: dict[str, Any] | None = None,
        token: str | None = None,
    ) -> dict[str, Any]:
        """
        Make a request to the enclave API with the envelope pattern.

        This method handles automatic authentication and 401 retry logic.

        Args:
            operation: The operation name to execute
            params: Optional parameters for the operation
            token: Optional JWT token to use for this specific request

        Returns:
            Response data with responseMetadata excluded

        Raises:
            requests.Timeout: On request timeout
            requests.ConnectionError: On connection failure
            SilhouetteApiError: On API error responses (JSON with code/error)
            ValueError: On malformed or non-JSON responses
        """
        # Operations that don't require authentication
        unauthenticated_ops = {
            "login",
            "getHealth",
            "getHealthFeatures",
            "getHealthInfo",
            "getHealthReady",
            "getTokens",
            "getMarkets",
        }

        requires_auth = operation not in unauthenticated_ops

        # Auto-login if needed and no explicit token provided
        if requires_auth and token is None:
            # Check for existing token (backwards compatibility)
            token = self._auth.get_token() or self._jwt_token
            if token is None:
                # No token exists, try to auto-authenticate
                self._auth.ensure_authenticated()
                token = self._auth.get_token()

        # Make the request
        try:
            return self._raw_request(operation, params, token)
        except SilhouetteApiError as e:
            # Handle 401 by attempting re-login and retry
            if e.status == 401 and requires_auth:
                if self._auth.handle_auth_error(e.status):
                    # Login succeeded, retry with new token
                    token = self._auth.get_token()
                    return self._raw_request(operation, params, token)
            # Re-raise if not 401 or if login failed
            raise

    def _raw_request(
        self,
        operation: str,
        params: dict[str, Any] | None = None,
        token: str | None = None,
    ) -> dict[str, Any]:
        """
        Make a raw HTTP request to the enclave API without auth logic.

        Args:
            operation: The operation name to execute
            params: Optional parameters for the operation
            token: Optional JWT token to use for this request

        Returns:
            Response data with responseMetadata excluded

        Raises:
            requests.Timeout: On request timeout
            requests.ConnectionError: On connection failure
            SilhouetteApiError: On API error responses (JSON with code/error)
            ValueError: On malformed or non-JSON responses
        """
        # Build request payload with envelope pattern
        payload = {"operation": operation}
        if params:
            payload.update(params)

        url = f"{self.base_url}/v0"
        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        # Make the HTTP request using the configured session
        try:
            response = self._session.post(
                url,
                json=payload,
                headers=headers,
                timeout=self.timeout,
                verify=self.verify_ssl,
            )
        except requests.exceptions.RetryError as e:
            # Re-raise retry exhaustion as a SilhouetteApiError
            raise SilhouetteApiError("RETRY_ERROR", f"Max retries exceeded: {e}", None) from e

        # Parse JSON response (best-effort)
        try:
            response_data = response.json()
        except json.JSONDecodeError as e:
            # If HTTP error with non-JSON body, surface concise status
            if not response.ok:
                raise ValueError(f"HTTP {response.status_code} error with non-JSON response") from e
            raise ValueError("Failed to parse response JSON") from e

        # Handle error responses
        if not response.ok:
            error_msg = response_data.get("error", f"HTTP {response.status_code}")
            error_code = response_data.get("code", "UNKNOWN_ERROR")
            raise SilhouetteApiError(error_code, error_msg, response.status_code)

        # Return full response for Pydantic validation
        return dict(response_data)


class RfqOperations:
    """RFQ / block trading endpoint operations for the enclave API."""

    def __init__(self, client: "SilhouetteApiClient"):
        self._client = client

    @parse_response(CreateRfqIntentResponse)
    def create_rfq_intent(
        self,
        side: str,
        base_token: str,
        quote_token: str,
        amount: str,
        price_limit: str,
        expiry: int | float,
    ) -> dict[str, Any]:
        """Create a new RFQ intent as taker.

        Args:
            side: Order side ("buy" or "sell")
            base_token: Base token symbol (e.g., "HYPE")
            quote_token: Quote token symbol (e.g., "USDC")
            amount: Base token amount as decimal string (e.g., "1.5")
            price_limit: Max price for buys or min for sells as decimal string (e.g., "25.0")
            expiry: Expiry as Unix timestamp in seconds

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - rfqId: str (unique identifier for the created RFQ intent)
                - expiry: number (expiry Unix timestamp)
                - createdAt: number (creation timestamp)
                - amountHeld: str (collateral held in smallest units)
                - amountHeldFloat: str (human-readable collateral amount)
        """
        params = build_request(
            CreateRfqIntentRequest,
            operation="createRfqIntent",
            side=side,
            base_token=base_token,
            quote_token=quote_token,
            amount=amount,
            price_limit=price_limit,
            expiry=expiry,
        )
        return self._client._request_operation("createRfqIntent", params)

    @parse_response(SubmitRfqQuoteResponse)
    def submit_rfq_quote(self, rfq_id: str, amount: str) -> dict[str, Any]:
        """Submit a quote for an active RFQ as maker.

        Args:
            rfq_id: Identifier of the RFQ to quote on
            amount: Quote amount in quote token units as decimal string (e.g., "78.0")

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - quoteId: str (unique identifier for the submitted quote)
        """
        params = build_request(
            SubmitRfqQuoteRequest,
            operation="submitRfqQuote",
            rfq_id=rfq_id,
            amount=amount,
        )
        return self._client._request_operation("submitRfqQuote", params)

    @parse_response(GetActiveRfqsResponse)
    def get_active_rfqs(
        self,
        pairs: list[str] | None = None,
        min_size: str | None = None,
        cursor: str | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Get active RFQs where the authenticated user is eligible as maker.

        Args:
            pairs: Filter by trading pairs in 'BASE/QUOTE' format
            min_size: Minimum base token amount as decimal string (e.g., "1.5")
            cursor: Pagination cursor from a previous response
            limit: Maximum number of results to return (1-1000)

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - rfqs: list[dict] (active RFQ summaries)
                - cursor: str | None (pagination cursor)
        """
        params = build_request(
            GetActiveRfqsRequest,
            operation="getActiveRfqs",
            pairs=pairs,
            min_size=min_size,
            cursor=cursor,
            limit=limit,
        )
        return self._client._request_operation("getActiveRfqs", params)

    @parse_response(GetRfqsResponse)
    def get_rfqs(
        self,
        status: str | None = None,
        cursor: str | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Get RFQs created by the authenticated taker.

        Args:
            status: Filter by RFQ status (active, accepted, system_cancelled, expired, all)
            cursor: Pagination cursor from a previous response
            limit: Maximum number of results to return (1-1000)

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - rfqs: list[dict] (RFQ summaries with full details)
                - cursor: str | None (pagination cursor)
        """
        params = build_request(
            GetRfqsRequest,
            operation="getRfqs",
            status=status,
            cursor=cursor,
            limit=limit,
        )
        return self._client._request_operation("getRfqs", params)

    @parse_response(GetQuotesResponse)
    def get_quotes(
        self,
        status: str | None = None,
        cursor: str | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Get quotes submitted by the authenticated maker.

        Args:
            status: Filter by quote status (active, accepted, rejected, expired, system_cancelled, all)
            cursor: Pagination cursor from a previous response
            limit: Maximum number of results to return (1-1000)

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - quotes: list[dict] (quote summaries)
                - cursor: str | None (pagination cursor)
        """
        params = build_request(
            GetQuotesRequest,
            operation="getQuotes",
            status=status,
            cursor=cursor,
            limit=limit,
        )
        return self._client._request_operation("getQuotes", params)


RfqEventCallback = Callable[[str, dict[str, Any]], None]
RfqCallbackErrorHandler = Callable[[str, dict[str, Any], Exception], None]


class RfqWebsocketOperations:
    """
    WebSocket operations for subscribing to RFQ events.

    This provides a lightweight subscription API used by the RFQ SDK examples:

        client.rfqWs.subscribe(RfqEvent.INTENT_FILLED, handler)
        client.rfqWs.subscribe(RfqEvent.QUOTE_ACCEPTED, handler)

    Network handling is performed via the `websockets` library when `start()` is called.
    Tests interact only with the subscription and dispatch logic to avoid real sockets.
    """

    _MAX_RECONNECT_DELAY = 60  # Maximum delay for exponential backoff (seconds)
    _PING_INTERVAL = 20  # Send ping every 20 seconds
    _PING_TIMEOUT = 10  # Wait 10 seconds for pong response

    def __init__(
        self,
        client: "SilhouetteApiClient",
        max_reconnect_attempts: int | None = None,
    ):
        """
        Initialize RFQ WebSocket operations.

        Args:
            client: The SilhouetteApiClient instance.
            max_reconnect_attempts: Maximum reconnection attempts. None (default) means unlimited retries.
                For critical trading connections, unlimited retries are recommended.
                Set a limit (e.g., 100) if you want to stop after persistent failures.
        """
        self._client = client
        # Store (callback, error_handler) tuples for each event
        self._subscriptions: dict[str, list[tuple[RfqEventCallback, RfqCallbackErrorHandler | None]]] = {}
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._reconnect_delay = 1
        self._is_connected = False
        self._lock = threading.Lock()  # Protects thread/loop state from concurrent access
        self._max_reconnect_attempts = max_reconnect_attempts
        self._reconnect_attempts = 0
        self._websocket: Any | None = None

    def subscribe(
        self,
        event: RfqEvent,
        callback: RfqEventCallback,
        on_error: RfqCallbackErrorHandler | None = None,
    ) -> None:
        """
        Subscribe to RFQ WebSocket events.

        Args:
            event: RFQ event type from RfqEvent enum.
            callback: Callable taking (event_name, data_dict).
            on_error: Optional error handler for this specific callback. If provided, will be called
                when this callback raises an exception. Receives (event_name, event_data, exception).
                If not provided, errors are only logged.
        """
        event_str = event.value
        with self._lock:
            self._subscriptions.setdefault(event_str, []).append((callback, on_error))

    def unsubscribe(self, event: RfqEvent, callback: RfqEventCallback) -> None:
        """Unsubscribe a previously registered callback."""
        event_str = event.value
        with self._lock:
            callbacks = self._subscriptions.get(event_str)
            if callbacks:
                # Remove the tuple matching this callback
                self._subscriptions[event_str] = [
                    (cb, err_handler) for cb, err_handler in callbacks if cb is not callback
                ]
                if not self._subscriptions[event_str]:
                    self._subscriptions.pop(event_str, None)

    def start(self) -> None:
        """
        Start background WebSocket listener for RFQ events.

        This method is optional; if not called, subscriptions can still be used
        with manual dispatching in tests or custom integrations.
        """
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                # Thread exists and is still alive, don't start a new one
                return
            elif self._thread is not None:
                # Thread exists but is dead (zombie), clean it up
                self._thread = None

            self._stop_event.clear()
            self._reconnect_delay = 1
            self._thread = threading.Thread(target=self._run_loop, daemon=True)
            self._thread.start()

    def close(self) -> None:
        """Signal the WebSocket listener to stop and wait for the thread to exit.

        Safe to call from any thread, including the WebSocket worker thread
        (e.g. from inside a subscription callback).
        """
        with self._lock:
            self._stop_event.set()
            loop = self._loop
            websocket = self._websocket
            thread = self._thread
            called_from_worker = thread is not None and thread is threading.current_thread()

        if websocket is not None and loop is not None and loop.is_running():
            if called_from_worker:
                # Worker-thread path: don't schedule an explicit ws.close() —
                # it races with loop shutdown and may never execute.  The
                # websockets.connect CM __aexit__ closes the socket when
                # _connect_and_listen exits due to _stop_event.
                pass
            else:
                try:
                    future = asyncio.run_coroutine_threadsafe(websocket.close(), loop)
                    future.result(timeout=1.0)
                except Exception as e:
                    logger.warning("Error closing WebSocket: %s", e, exc_info=True)

        # Never join the current thread — it would raise RuntimeError.
        if not called_from_worker and thread is not None:
            thread.join(timeout=5.0)

        with self._lock:
            if self._thread is thread:
                if called_from_worker:
                    # Thread is still running (it's us); clear the reference so
                    # start() can launch a fresh thread after we return.
                    self._thread = None
                elif thread is not None and not thread.is_alive():
                    self._thread = None
                elif thread is not None:
                    logger.error("WebSocket thread did not stop within timeout - thread reference retained")
            self._websocket = None
            self._is_connected = False

    @property
    def is_connected(self) -> bool:
        """Check if WebSocket is currently connected."""
        with self._lock:
            return self._is_connected and self._thread is not None and self._thread.is_alive()

    def _run_loop(self) -> None:
        """Background thread entrypoint: create event loop and connect."""
        loop = asyncio.new_event_loop()
        with self._lock:
            self._loop = loop

        try:
            loop.run_until_complete(self._connect_and_listen())
        finally:
            loop.close()
            with self._lock:
                self._loop = None

    async def _connect_and_listen(self) -> None:
        """Connect to the RFQ WebSocket endpoint and dispatch events."""
        ws_url = self._build_ws_url()
        self._reconnect_attempts = 0

        while not self._stop_event.is_set():
            try:
                headers = self._build_headers()

                async with websockets.connect(
                    ws_url,
                    additional_headers=headers,
                    ping_interval=self._PING_INTERVAL,
                    ping_timeout=self._PING_TIMEOUT,
                ) as websocket:
                    with self._lock:
                        self._websocket = websocket
                    self._on_connection_established()

                    try:
                        while not self._stop_event.is_set():
                            try:
                                raw = await websocket.recv()
                            except asyncio.CancelledError:
                                break
                            except websockets.exceptions.ConnectionClosed:
                                if self._stop_event.is_set():
                                    break
                                raise

                            parsed = self._parse_message(raw)
                            if parsed is None:
                                continue

                            try:
                                event, data = self._validate_message_structure(parsed)
                                self._dispatch_event(event, data)
                            except ValueError as e:
                                logger.warning(f"Invalid WebSocket message structure: {e}")
                                continue
                    finally:
                        with self._lock:
                            self._websocket = None
                            self._is_connected = False

            except asyncio.CancelledError:
                break
            except Exception as e:
                if not await self._handle_error(e):
                    break

    def _build_headers(self) -> dict[str, str]:
        """Build WebSocket connection headers with authentication token."""
        token = self._client._auth.get_token() or self._client._jwt_token  # noqa: SLF001
        if token is None:
            self._client._auth.ensure_authenticated()  # noqa: SLF001
            token = self._client._auth.get_token()  # noqa: SLF001
        headers = {}
        if token is not None:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    def _on_connection_established(self) -> None:
        """Handle successful WebSocket connection."""
        with self._lock:
            self._is_connected = True
            self._reconnect_delay = 1
        self._reconnect_attempts = 0

    def _parse_message(self, raw: str | bytes) -> dict[str, Any] | None:
        """Parse raw WebSocket message as JSON."""
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")

        try:
            parsed = json.loads(raw)
            if not isinstance(parsed, dict):
                logger.warning(f"WebSocket message is not a dict, got {type(parsed)}")
                return None
            return parsed
        except json.JSONDecodeError:
            logger.warning("Failed to parse WebSocket message as JSON")
            return None

    def _validate_message_structure(self, message: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        """Validate WebSocket message structure and extract event/data."""
        event = message.get("event")
        data = message.get("data")

        if not isinstance(event, str):
            raise ValueError(f"WebSocket message 'event' field must be a string, got {type(event)}")
        if not isinstance(data, dict):
            raise ValueError(f"WebSocket message 'data' field must be a dict, got {type(data)}")

        return (event, data)

    async def _handle_error(self, error: Exception) -> bool:
        """
        Handle WebSocket errors with exponential backoff and reconnection attempt tracking.

        Args:
            error: The exception that occurred.

        Returns:
            True if reconnection should continue, False if it should stop.
        """
        with self._lock:
            self._is_connected = False
            if self._stop_event.is_set():
                return False
            reconnect_delay = self._reconnect_delay
            max_attempts = self._max_reconnect_attempts

        self._reconnect_attempts += 1
        reconnect_attempts = self._reconnect_attempts

        if max_attempts is not None and reconnect_attempts > max_attempts:
            logger.error(
                f"WebSocket reconnection failed after {reconnect_attempts} attempts. "
                f"Stopping reconnection attempts. Last error: {error}",
                exc_info=True,
            )
            return False

        attempt_info = (
            f"WebSocket error (attempt {reconnect_attempts}"
            + (f"/{max_attempts}" if max_attempts else "")
            + f"): {error}, reconnecting in {reconnect_delay}s"
        )

        logger.error(attempt_info, exc_info=True)

        await self._wait_and_backoff()
        return True

    async def _wait_and_backoff(self) -> None:
        """Wait with exponential backoff before reconnecting.

        Polls ``_stop_event`` in short intervals so that ``close()`` can
        interrupt the wait promptly instead of blocking for the full delay.
        Only advances the backoff delay when the wait completes normally
        (i.e. shutdown was not requested mid-sleep).
        """
        with self._lock:
            delay = self._reconnect_delay

        poll_interval = 0.25
        loop = asyncio.get_event_loop()
        deadline = loop.time() + delay
        while loop.time() < deadline:
            if self._stop_event.is_set():
                return
            remaining = deadline - loop.time()
            await asyncio.sleep(min(poll_interval, remaining))

        if self._stop_event.is_set():
            return
        with self._lock:
            self._reconnect_delay = min(delay * 2, self._MAX_RECONNECT_DELAY)

    def _build_ws_url(self) -> str:
        """Derive WebSocket URL for RFQ events from the HTTP base_url."""
        parsed = urlparse(self._client.base_url)
        scheme = {"https": "wss", "http": "ws"}.get(parsed.scheme)
        if not scheme:
            raise ValueError(
                f"base_url must start with 'http://' or 'https://', got: {self._client.base_url}",
            )
        return urlunparse(parsed._replace(scheme=scheme, path="/rfq/events"))

    def _dispatch_event(self, event: str, data: dict[str, Any]) -> None:
        """Dispatch an event to all matching subscribers."""
        # Copy subscriptions under lock to avoid holding lock during callbacks
        with self._lock:
            subscriptions = list(self._subscriptions.get(event, []))

        # Callbacks run outside lock to avoid deadlocks
        for callback, on_error in subscriptions:
            try:
                callback(event, data)
            except Exception as e:
                logger.error(
                    "Error in WebSocket event callback for '%s': %s",
                    event,
                    e,
                    exc_info=True,
                )
                # Invoke callback-specific error handler if provided
                if on_error is not None:
                    on_error(event, data, e)
