import sys
import platform
import numpy as np
import io
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QPushButton, QHBoxLayout
from PyQt5.QtCore import QTimer, Qt, QByteArray, QIODevice, QBuffer
from PyQt5.QtGui import QFont
from PyQt5.QtMultimedia import QAudioOutput, QAudioFormat


class CountdownTimer(QWidget):
    def __init__(self, hours=0, minutes=0, seconds=0):
        super().__init__()

        # Store initial time
        self.initial_hours = hours
        self.initial_minutes = minutes
        self.initial_seconds = seconds

        # Calculate total seconds
        self.total_seconds = hours * 3600 + minutes * 60 + seconds
        self.remaining_seconds = self.total_seconds

        # Timer running state
        self.is_running = False

        self.init_ui()
        self.update_display()

    def init_ui(self):
        # Set window to stay on top
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)

        # Main layout
        layout = QVBoxLayout()

        # Time display label
        self.time_label = QLabel()
        self.time_label.setAlignment(Qt.AlignCenter)
        self.time_label.setFont(QFont('Arial', 48, QFont.Bold))
        layout.addWidget(self.time_label)

        # Buttons layout
        button_layout = QHBoxLayout()

        # Start/Pause button
        self.start_pause_btn = QPushButton('Start')
        self.start_pause_btn.clicked.connect(self.toggle_timer)
        button_layout.addWidget(self.start_pause_btn)

        # Reset button
        self.reset_btn = QPushButton('Reset')
        self.reset_btn.clicked.connect(self.reset_timer)
        button_layout.addWidget(self.reset_btn)

        layout.addLayout(button_layout)

        self.setLayout(layout)

        # QTimer for countdown
        self.timer = QTimer()
        self.timer.timeout.connect(self.countdown)

    def update_display(self):
        """Update the time display label"""
        hours = self.remaining_seconds // 3600
        minutes = (self.remaining_seconds % 3600) // 60
        seconds = self.remaining_seconds % 60

        time_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        self.time_label.setText(time_str)

        # Change color when time is running out
        if self.remaining_seconds <= 10 and self.remaining_seconds > 0:
            self.time_label.setStyleSheet("color: orange;")
        elif self.remaining_seconds == 0:
            self.time_label.setStyleSheet("color: red;")
        else:
            self.time_label.setStyleSheet("color: black;")

    def countdown(self):
        """Decrease time by 1 second"""
        if self.remaining_seconds > 0:
            self.remaining_seconds -= 1
            self.update_display()
        else:
            self.timer.stop()
            self.is_running = False
            self.start_pause_btn.setText('Start')
            print("Timer finished!")

    def generate_beep(self, frequency=800, duration=0.3, sample_rate=44100):
        """Generate a beep sound wave as bytes"""
        # Generate time array
        t = np.linspace(0, duration, int(sample_rate * duration))

        # Generate sine wave
        wave = np.sin(2 * np.pi * frequency * t)

        # Apply fade in/out to avoid clicks
        fade_samples = int(sample_rate * 0.01)  # 10ms fade
        fade_in = np.linspace(0, 1, fade_samples)
        fade_out = np.linspace(1, 0, fade_samples)
        wave[:fade_samples] *= fade_in
        wave[-fade_samples:] *= fade_out

        # Convert to 16-bit PCM
        wave = (wave * 32767).astype(np.int16)

        return wave.tobytes()

    def toggle_timer(self):
        """Start or pause the timer"""
        if self.is_running:
            self.timer.stop()
            self.is_running = False
            self.start_pause_btn.setText('Resume')
        else:
            if self.remaining_seconds > 0:
                self.timer.start(1000)  # Update every 1000ms (1 second)
                self.is_running = True
                self.start_pause_btn.setText('Pause')

    def reset_timer(self):
        """Reset timer to initial value"""
        self.timer.stop()
        self.is_running = False
        self.remaining_seconds = self.total_seconds
        self.start_pause_btn.setText('Start')
        self.update_display()


# Example usage
if __name__ == '__main__':
    app = QApplication(sys.argv)

    # Create a timer widget with 0 hours, 5 minutes, 30 seconds
    timer_widget = CountdownTimer(hours=0, minutes=0, seconds=3)
    timer_widget.setWindowTitle('Countdown Timer')
    timer_widget.resize(400, 200)
    timer_widget.show()

    sys.exit(app.exec_())
