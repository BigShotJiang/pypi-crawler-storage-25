# bonanza labs pay 

💳 Stripe + Stablecoin payment framework

Part of [Bonanza Labs](https://github.com/c6zks4gssn-droid) — open source AI tools for builders.

## Install

```bash
pip install bonanza-labs-pay
```

## Quick Start

```bash
bonanza-pay --help
```

## Features

- Open source (Apache 2.0)
- CLI + REST API
- Built for AI agents

## Documentation

Full docs at [bonanza-labs.tiiny.site](https://bonanza-labs.tiiny.site)

## License

Apache License 2.0
