# LastPass Vault Py

An unofficial, Pythonic wrapper for the [LastPass CLI (`lpass`)](https://github.com/lastpass/lastpass-cli).

> **Disclaimer:** This project is an unofficial, community-driven tool. It is not affiliated with, maintained, or endorsed by LastPass, LogMeIn, or GoTo Technologies. No claim is made to the LastPass name, brand, trademarks, or intellectual property.

## Features

- Secure authentication via the official `lpass` CLI
- Full vault management — list, search, retrieve, add, edit, move, delete, and duplicate entries
- Password generation via `lpass generate`
- Vault backup and restore via CSV export/import
- All sensitive values (passwords, CSV data) transmitted to `lpass` via stdin — never via command-line arguments
- Sync control, background sync, and trust/plaintext-key login options
- Robust error handling and mock-friendly design for testing

## Prerequisites

The LastPass CLI must be installed:

- **Ubuntu/Debian:** `sudo apt install lastpass-cli`
- **macOS:** `brew install lastpass-cli`

## Installation

```bash
pip install lastpass-vault-py
```

## Quick Start

```python
from lastpass_vault import LastPassVault

vault = LastPassVault()

if not vault.is_logged_in():
    vault.login("user@example.com")

items = vault.list_items()
for item in items:
    print(item['name'])

password = vault.get_password("My Site")
```

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for details.

## License

The project code is licensed under the **GNU General Public License v3 (GPLv3)**.
See [LICENSE](LICENSE) for the full text.

