"""A submodule containing utility functions for working with emissions.

This module contains functions for converting between different line
identifiers, calculating attenuation and transmission, and
flattening lists of lines. It also includes functions for working with
spectral energy distributions (SEDs) and calculating attenuation at
specific wavelengths.

Example usage:

    # Example usage of the functions
    line_id = ["H 1 4861.32A", "H 1 6562.80A"]
    composite_line_id = get_composite_line_id_from_list(line_id)
    print(composite_line_id)  # Output: "H 1 4861.32A, H 1 6562.80A"

    # Example usage of the get_line_label function
    line_label = get_line_label(line_id)
    print(line_label)  # Output: "HII4861.32A+HII6562.80A"

    # Example usage of the flatten_linelist function
    list_to_flatten = [["H 1 4861.32A"], ["H 1 6562.80A"]]
    flattened_list = flatten_linelist(list_to_flatten)
    print(flattened_list)  # Output: ["H 1 4861.32A", "H 1 6562.80A"]

    # Example usage of the get_transmission function
    intrinsic_sed = Sed(...)
    attenuated_sed = Sed(...)
    transmission = get_transmission(intrinsic_sed, attenuated_sed)

    # Example usage of the get_attenuation function
    intrinsic_sed = Sed(...)
    attenuated_sed = Sed(...)
    attenuation = get_attenuation(intrinsic_sed, attenuated_sed)

    # Example usage of the get_attenuation_at_lam function
    lam = 5500.0 * angstrom
    intrinsic_sed = Sed(...)
    attenuated_sed = Sed(...)
    attenuation_at_lam = get_attenuation_at_lam(
        lam, intrinsic_sed, attenuated_sed
    )

"""

from functools import lru_cache
from types import MappingProxyType

import numpy as np
from unyt import angstrom

from synthesizer import exceptions
from synthesizer.units import accepts


def get_composite_line_id_from_list(id):
    """Convert a list of line ids to a string describing a composite line.

    A composite line is a line that is made up of multiple lines, e.g.
    a doublet or triplet. This function takes a list of line ids and converts
    them to a single string.

    e.g. ["H 1 4861.32A", "H 1 6562.80A"] -> "H 1 4861.32A, H 1 6562.80A"

    Args:
        id (list, tuple):
            a str, list, or tuple containing the id(s) of the lines

    Returns:
        id (str):
            string representation of the id
    """
    if isinstance(id, list):
        return ", ".join(id)
    else:
        return id


# Dictionary of common line labels to use by default
line_labels = {
    "C 4 1548.19A, C 4 1550.77A": (
        r"[\mathrm{C\,IV}]\,\lambda\lambda1548,1551"
    ),
    "O 3 1660.81A, O 3 1666.15A": (
        r"\mathrm{O\,III}]\,\lambda\lambda1661,1666"
    ),
    "C 3 1906.68A, C 3 1908.73A": (
        r"\mathrm{C\,III}]\,\lambda\lambda1907,1909"
    ),
    "He 2 1640.41A": r"\mathrm{He\,II}\,\lambda1640",
    "O 2 3726.03A, O 2 3728.81A": (
        r"[\mathrm{O\,II}]\,\lambda\lambda3726,3729"
    ),
    "Ne 3 3868.76A": r"[\mathrm{Ne\,III}]\,\lambda3869",
    "H 1 4101.73A": r"\mathrm{H}\delta",
    "H 1 4340.46A": r"\mathrm{H}\gamma",
    "H 1 4861.32A": r"\mathrm{H}\beta",
    "O 3 5006.84A": r"[\mathrm{O\,III}]\,\lambda5007",
    "O 3 4958.91A, O 3 5006.84A": (
        r"[\mathrm{O\,III}]\,\lambda\lambda4959,5007"
    ),
    "H 1 6562.80A": r"\mathrm{H}\alpha",
    "N 2 6583.45A": r"[\mathrm{N\,II}]\,\lambda6583",
    "O 1 6300.30A": r"[\mathrm{O\,I}]\,\lambda6300",
    "S 2 6716.44A, S 2 6730.82A": (
        r"[\mathrm{S\,II}]\,\lambda\lambda6716,6731"
    ),
    "S 2 6730.82A": r"[\mathrm{S\,II}]\,\lambda6731",
    "S 2 6716.44A": r"[\mathrm{S\,II}]\,\lambda6716",
}


def get_line_label(line_id):
    """Get a line label for a given line_id, ratio, or diagram.

    Where the line_id is one of several predifined lines in line_labels this
    label is used, otherwise the label is constructed from the line_id.

    Argumnents
        line_id (str):
            The line_id either as a list of individual lines or a string. If
            provided as a list this is automatically converted to a single
            string so it can be used as a key.

    Returns:
        line_label (str):
            A nicely formatted line label.
    """
    # if the line_id is a list (denoting a doublet or higher)
    if isinstance(line_id, list):
        line_id = ", ".join(line_id)

    if line_id in line_labels.keys():
        line_label = line_labels[line_id]
    else:
        line_id = [li.strip() for li in line_id.split(",")]
        _line_labels = []
        for line_id_ in line_id:
            # get the element, ion, and wavelength
            element, ion, wavelength = line_id_.split(" ")

            # extract unit and convert to latex str
            unit = wavelength[-1]

            if unit == "A":
                unit = r"\AA"
            if unit == "m":
                unit = r"\mu m"
            wavelength = wavelength[:-1] + unit

            _line_labels.append(
                f"{element}{get_roman_numeral(int(ion))}{wavelength}"
            )

        line_label = "+".join(_line_labels)

    return line_label


def flatten_linelist(list_to_flatten):
    """Flatten a mixed list of lists and strings and remove duplicates.

    Used when converting a line list which may contain single lines
    and doublets.

    Args:
        list_to_flatten (list):
            list containing lists and/or strings and integers

    Returns:
        (list):
            flattened list
    """
    flattened_list = []
    for lst in list_to_flatten:
        if isinstance(lst, list) or isinstance(lst, tuple):
            for ll in lst:
                flattened_list.append(ll)

        elif isinstance(lst, str):
            # If the line is a doublet, resolve it and add each line
            # individually
            if len(lst.split(",")) > 1:
                flattened_list += lst.split(",")
            else:
                flattened_list.append(lst)

        else:
            raise Exception(
                (
                    "Unrecognised type provided. Please provide"
                    "a list of lists and strings"
                )
            )

    return list(set(flattened_list))


@lru_cache(maxsize=1)
def get_ratio_requirements():
    """Precompute required line ids for each ratio definition.

    Returns:
        dict:
            A mapping from ratio id to the frozen set of required line ids.
    """
    # Import lazily to avoid a module cycle: line_ratios imports alias helpers
    # from this module while LineCollection imports these cached requirements.
    from synthesizer.emissions import line_ratios

    # Build a mapping from ratio id to the full set of line ids required to
    # evaluate that ratio.
    requirements = {}
    for ratio_id, ratio in line_ratios.ratios.items():
        # Collect the individual constituent line ids for this ratio.
        ratio_line_ids = set()

        # Expand any composite entries so each ratio maps to the individual
        # line ids that must be present in a LineCollection.
        for line_ids in ratio:
            ratio_line_ids.update(
                line_id.strip() for line_id in line_ids.split(",")
            )

        # Freeze the required-id set so it is safe to cache and reuse.
        requirements[ratio_id] = frozenset(ratio_line_ids)

    # Return the full ratio requirement lookup for module-level reuse.
    return requirements


@lru_cache(maxsize=1)
def get_diagram_requirements():
    """Precompute required line ids for each diagram definition.

    Returns:
        dict:
            A mapping from diagram id to the frozen set of required line ids.
    """
    # Import lazily to avoid a module cycle: line_ratios imports alias helpers
    # from this module while LineCollection imports these cached requirements.
    from synthesizer.emissions import line_ratios

    # Build a mapping from diagram id to the full set of line ids required to
    # evaluate all ratios in that diagnostic diagram.
    requirements = {}
    for diagram_id, diagram in line_ratios.diagrams.items():
        # Collect the individual constituent line ids used anywhere in this
        # diagram's component ratios.
        diagram_line_ids = set()

        # Diagrams are defined in terms of ratios, so flatten both the ratio
        # pairs and any composite line entries into one required-id set.
        for ratio in diagram:
            for line_ids in ratio:
                diagram_line_ids.update(
                    line_id.strip() for line_id in line_ids.split(",")
                )

        # Freeze the required-id set so it is safe to cache and reuse.
        requirements[diagram_id] = frozenset(diagram_line_ids)

    # Return the full diagram requirement lookup for module-level reuse.
    return requirements


def get_line_id_signature(line_ids):
    """Return the canonical cache key for a line-id sequence.

    Args:
        line_ids (array-like):
            The ordered sequence of line ids describing the collection.

    Returns:
        tuple:
            The ordered line ids converted into a hashable cache key.
    """
    # Use the exact ordered line-id tuple as the cache key. This preserves the
    # collection ordering used by LineCollection and any array-based lookups.
    return tuple(line_ids)


@lru_cache(maxsize=100)
def get_line2index(signature):
    """Get a cached line-id to index mapping.

    Args:
        signature (tuple):
            The ordered tuple of line ids describing the collection.

    Returns:
        MappingProxyType:
            A mapping from each stored line id to its array index.
    """
    # Build the mapping from each stored line id to its array index.
    line2index = {line_id: index for index, line_id in enumerate(signature)}

    # Wrap the mapping in a read-only proxy so callers cannot mutate the
    # shared cached object by accident.
    return MappingProxyType(line2index)


@lru_cache(maxsize=100)
def get_available_ratio_ids(signature):
    """Get the cached ratio ids for a line-id signature.

    Args:
        signature (tuple):
            The ordered tuple of line ids describing the collection.

    Returns:
        tuple:
            The tuple of predefined ratio ids available for these lines.
    """
    # Split any composite entries such as doublets into their individual
    # constituent line ids
    individual_line_ids = {
        line_id.strip()
        for line_ids in signature
        for line_id in line_ids.split(",")
    }

    # Determine which predefined ratios are available by checking whether each
    # ratio's required constituent ids are present
    return tuple(
        ratio_id
        for ratio_id, ratio_line_ids in get_ratio_requirements().items()
        if ratio_line_ids.issubset(individual_line_ids)
    )


@lru_cache(maxsize=100)
def get_available_diagram_ids(signature):
    """Get the cached diagram ids for a line-id signature.

    Args:
        signature (tuple):
            The ordered tuple of line ids describing the collection.

    Returns:
        tuple:
            The tuple of predefined diagram ids available for these lines.
    """
    # Expand any composite stored ids such as doublets into their individual
    # constituent line ids so diagrams can match against the atomic
    # requirements defined in line_ratios.
    expanded_line_id_set = {
        line_id.strip()
        for line_ids in signature
        for line_id in line_ids.split(",")
    }

    # Determine which predefined diagrams are available by checking whether
    # each diagram's required line ids are present in the collection
    return tuple(
        diagram_id
        for diagram_id, diagram_line_ids in get_diagram_requirements().items()
        if diagram_line_ids.issubset(expanded_line_id_set)
    )


def get_roman_numeral(number):
    """Convert an integer into a roman numeral str.

    Used for renaming emission lines from the cloudy defaults.

    Args:
        number (int):
            The number to convert into a roman numeral.

    Returns:
        number_representation (str):
            String reprensentation of the roman numeral.
    """
    num = [1, 4, 5, 9, 10, 40, 50, 90, 100, 400, 500, 900, 1000]
    sym = [
        "I",
        "IV",
        "V",
        "IX",
        "X",
        "XL",
        "L",
        "XC",
        "C",
        "CD",
        "D",
        "CM",
        "M",
    ]
    i = 12

    roman = ""
    while number:
        div = number // num[i]
        number %= num[i]

        while div:
            roman += sym[i]
            div -= 1
        i -= 1
    return roman


# Shorthand for common lines
aliases = {
    "Hb": "H 1 4861.32A",
    "Ha": "H 1 6562.80A",
    "Hg": "H 1 4340.46A",
    "O1": "O 1 6300.30A",
    "O2b": "O 2 3726.03A",
    "O2r": "O 2 3728.81A",
    "O2": "O 2 3726.03A, O 2 3728.81A",
    "O3b": "O 3 4958.91A",
    "O3r": "O 3 5006.84A",
    "O3": "O 3 4958.91A, O 3 5006.84A",
    "Ne3": "Ne 3 3868.76A",
    "N2": "N 2 6583.45A",
    "S2": "S 2 6730.82A, S 2 6716.44A",
}


# Standard names
Ha = aliases["Ha"]
Hb = aliases["Hb"]
O1 = aliases["O1"]
O2b = aliases["O2b"]
O2r = aliases["O2r"]
O2 = aliases["O2"]
O3b = aliases["O3b"]
O3r = aliases["O3r"]
O3 = aliases["O3"]
Ne3 = aliases["Ne3"]
N2 = aliases["N2"]
S2 = aliases["S2"]


def alias_to_line_id(alias):
    """Convert a line alias to a line id.

    Args:
        alias (str):
            The line alias.

    Returns:
        line_id (str):
            The line id.
    """
    if alias in aliases:
        return aliases[alias]
    return alias


def get_transmission(intrinsic_sed, attenuated_sed):
    """Calculate transmission as a function of wavelength.

    The transmission is defined as the ratio between an attenuated and
    an intrinsic sed.

    Args:
        intrinsic_sed (Sed):
            The intrinsic spectra object.
        attenuated_sed (Sed):
            The attenuated spectra object.

    Returns:
        np.ndarray of float:
            The transmission array.
    """
    # Ensure wavelength arrays are equal
    if not np.array_equal(attenuated_sed._lam, intrinsic_sed._lam):
        raise exceptions.InconsistentArguments(
            "Wavelength arrays of input spectra must be the same!"
        )

    return attenuated_sed.lnu / intrinsic_sed.lnu


def get_attenuation(intrinsic_sed, attenuated_sed):
    """Calculate attenuation as a function of wavelength.

    Args:
        intrinsic_sed (Sed):
            The intrinsic spectra object.
        attenuated_sed (Sed):
            The attenuated spectra object.

    Returns:
        np.ndarray of float
            The attenuation array in magnitudes.
    """
    # Calculate the transmission array
    transmission = get_transmission(intrinsic_sed, attenuated_sed)

    return -2.5 * np.log10(transmission)


@accepts(lam=angstrom)
def get_attenuation_at_lam(lam, intrinsic_sed, attenuated_sed):
    """Calculate attenuation at a given wavelength.

    Args:
        lam (float/np.ndarray of float):
            The wavelength/s at which to evaluate the attenuation in
            the same units as sed.lam (by default angstrom).
        intrinsic_sed (Sed):
            The intrinsic spectra object.
        attenuated_sed (Sed):
            The attenuated spectra object.

    Returns:
        float/np.ndarray of float
            The attenuation at the passed wavelength/s in magnitudes.
    """
    # Ensure lam is in the same units as the sed
    if lam.units != intrinsic_sed.lam.units:
        lam = lam.to(intrinsic_sed.lam.units)

    # Calcilate the transmission array
    attenuation = get_attenuation(intrinsic_sed, attenuated_sed)

    return np.interp(lam.value, intrinsic_sed._lam, attenuation)


def get_attenuation_at_5500(intrinsic_sed, attenuated_sed):
    """Calculate rest-frame FUV attenuation at 5500 angstrom.

    Args:
        intrinsic_sed (Sed):
            The intrinsic spectra object.
        attenuated_sed (Sed):
            The attenuated spectra object.

    Returns:
         float
            The attenuation at rest-frame 5500 angstrom in magnitudes.
    """
    return get_attenuation_at_lam(
        5500.0 * angstrom,
        intrinsic_sed,
        attenuated_sed,
    )


def get_attenuation_at_1500(intrinsic_sed, attenuated_sed):
    """Calculate rest-frame FUV attenuation at 1500 angstrom.

    Args:
        intrinsic_sed (Sed):
            The intrinsic spectra object.
        attenuated_sed (Sed):
            The attenuated spectra object.

    Returns:
         float
            The attenuation at rest-frame 1500 angstrom in magnitudes.
    """
    return get_attenuation_at_lam(
        1500.0 * angstrom,
        intrinsic_sed,
        attenuated_sed,
    )


def combine_list_of_seds(sed_list):
    """Convert a list of Seds into a single Sed object.

    Combines a list of `Sed` objects (length `Ngal`) into a single
    `Sed` object, with dimensions `Ngal x Nlam`. Each `Sed` object
    in the list should have an identical wavelength range.

    Args:
        sed_list (list):
            list of `Sed` objects
    """
    out_sed = sed_list[0]
    for sed in sed_list[1:]:
        out_sed = out_sed.concat(sed)

    return out_sed
