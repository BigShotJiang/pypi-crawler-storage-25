"""Queue machinery for executing emission model dependency graphs.

This module defines the runtime queue used by
``EmissionModel._get_spectra`` and ``EmissionModel._get_lines``. The queue is
responsible for constructing the executable closure of models for a single
call, compiling the direct dependency graph between those models, and then
tracking when each model becomes ready to execute.

The queue first discovers the full model closure, including any related model
trees that may contribute saved outputs. It then identifies the active subset
of that closure by starting from saved models and recursively marking the
dependencies they require. Active state is stored explicitly as a boolean
mapping keyed by model label, and only active models are queued. This means
dead unsaved branches can be skipped entirely before any emission generation
work is done.

The queue also manages emission lifetimes. Once a model's emission has been
consumed by all downstream dependents, and the model is not marked to be
saved, the queue deletes that emission from the working output dictionaries.
Keeping this logic in a dedicated module keeps execution-specific state out of
``EmissionModel`` and makes the scheduling logic easier to reason about.
"""

from collections import deque

import numpy as np

from synthesizer import exceptions
from synthesizer.utils.operation_timers import timer


class ModelQueue:
    """Runtime queue for executing an emission model dependency graph.

    The queue performs three related tasks for a single execution:

    - walk the model tree and collect the full executable closure
    - compile the dependency graph between models in that closure
    - prune the graph down to the active models needed by saved outputs
    - manage ready-to-run models and eagerly delete expired unsaved emissions

    Args:
        root_model (EmissionModel):
            The root emission model being executed.

    Attributes:
        models (dict):
            Mapping from model label to the ``EmissionModel`` instance in the
            executable closure for this run.
        dependencies (dict):
            Mapping from model label to the labels of its direct upstream
            dependencies.
        dependents (dict):
            Mapping from model label to the labels of its direct downstream
            dependents.
        execution_rank (dict):
            Mapping from model label to its stable discovery order in the
            queue. This is used to keep execution deterministic when multiple
            models become ready at the same time.
        active (dict):
            Mapping from model label to a boolean flag indicating whether that
            model is required to produce a saved output for this execution.
        pending_dependencies (dict):
            Mapping from model label to the number of upstream dependencies
            that are still unresolved.
        lifetime (dict):
            Mapping from model label to the number of downstream consumers that
            still need the model's emission.
        _queue (collections.deque):
            The ready queue containing the labels of active models whose
            dependencies have all been satisfied.
        _processed (set):
            The set of active model labels that have already been processed.
    """

    def __init__(self, root_model):
        """Initialise the queue for an emission model execution.

        Args:
            root_model (EmissionModel):
                The root model for the emission calculation being executed.

        Returns:
            None
        """
        # Keep a reference to the root model for error messages and checks.
        self._root_model = root_model

        # Build the executable model closure before compiling dependencies.
        with timer("ModelQueue.__init__.collect_tree"):
            self.models = {}
            self._related_models = set()
            self._collect_model_tree(root_model)

            # Keep walking newly discovered related models until the full
            # closure of additional roots has been exhausted.
            related_labels = set()
            while True:
                pending_related_models = [
                    model
                    for model in self._related_models
                    if model.label not in related_labels
                ]
                if len(pending_related_models) == 0:
                    break

                for model in pending_related_models:
                    related_labels.add(model.label)
                    if model.label not in self.models:
                        self._collect_model_tree(model)

        # Compile the dependency graph and runtime counters for this closure.
        with timer("ModelQueue.__init__.compile"):
            full_dependencies = {}
            full_dependents = {label: [] for label in self.models}
            self.execution_rank = {}

            # Compile the full dependency graph before pruning inactive
            # branches.
            for rank, (label, model) in enumerate(self.models.items()):
                self.execution_rank[label] = rank
                model_dependencies = self._get_model_dependencies(model)
                full_dependencies[label] = tuple(
                    dependency.label for dependency in model_dependencies
                )

                for dependency in model_dependencies:
                    full_dependents[dependency.label].append(label)

            # Mark only models needed to produce saved outputs as active. This
            # backwards walk lets us skip unsaved branches that do not
            # contribute to any saved emission.
            self.active = self._get_active(self.models, full_dependencies)

            # Prune the graph down to the active subgraph before queueing it so
            # inactive models do not contribute to queue state or lifetimes.
            self.models = {
                label: model
                for label, model in self.models.items()
                if self.is_active(label)
            }
            self.dependencies = {
                label: tuple(
                    dependency_label
                    for dependency_label in full_dependencies[label]
                    if self.is_active(dependency_label)
                )
                for label in self.models
            }
            self.dependents = {
                label: tuple(
                    dependent_label
                    for dependent_label in full_dependents[label]
                    if self.is_active(dependent_label)
                )
                for label in self.models
            }

            # Initialise the pending dependency counts and model lifetimes
            # using only the active subgraph that will actually be executed.
            self.pending_dependencies = {
                label: len(dep_labels)
                for label, dep_labels in self.dependencies.items()
            }
            self.lifetime = {
                label: len(dep_labels)
                for label, dep_labels in self.dependents.items()
            }

            # Seed the ready queue using the compiled execution ordering so
            # independent branches still run deterministically.
            ready_labels = sorted(
                [
                    label
                    for label, count in self.pending_dependencies.items()
                    if count == 0
                ],
                key=self.execution_rank.get,
            )
            self._queue = deque(ready_labels)
            self._processed = set()

    def __len__(self):
        """Return the number of models currently ready to execute.

        Args:
            None

        Returns:
            int:
                The number of models currently waiting in the ready queue.
        """
        return len(self._queue)

    def pop(self):
        """Pop and return the next ready model from the queue.

        Args:
            None

        Returns:
            EmissionModel:
                The next model that is ready to be executed.
        """
        # Pop the next ready label and resolve it back to the model object.
        return self.models[self._queue.popleft()]

    def is_active(self, label):
        """Return whether a discovered model label is active.

        Args:
            label (str):
                The model label to query.

        Returns:
            bool:
                ``True`` if the model is required to produce a saved output,
                otherwise ``False``.
        """
        # Default to inactive for any label outside the discovered closure.
        return self.active.get(label, False)

    def done(self, model, emissions, particle_emissions):
        """Mark a model as processed and update queue state.

        Args:
            model (EmissionModel):
                The model that has just finished execution.
            emissions (dict):
                The integrated emission dictionary to clean up.
            particle_emissions (dict):
                The particle emission dictionary to clean up.

        Returns:
            None
        """
        # Record completion so we can verify the whole graph ran later.
        label = model.label
        self._processed.add(label)

        # Unlock any direct dependents whose upstream work is now complete.
        newly_ready = []
        for dependent_label in self.dependents[label]:
            self.pending_dependencies[dependent_label] -= 1
            if self.pending_dependencies[dependent_label] == 0:
                newly_ready.append(dependent_label)

        # Keep the queue order deterministic for independent branches.
        for dependent_label in sorted(
            newly_ready, key=self.execution_rank.get
        ):
            self._queue.append(dependent_label)

        # Decrement dependency lifetimes because this model has consumed them.
        for dependency_label in self.dependencies[label]:
            self.lifetime[dependency_label] -= 1
            if self.lifetime[dependency_label] == 0:
                self._delete_expired_emission(
                    dependency_label,
                    emissions,
                    particle_emissions,
                )

        # Delete the model itself once nobody downstream needs it anymore.
        if self.lifetime[label] == 0:
            self._delete_expired_emission(
                label,
                emissions,
                particle_emissions,
            )

    def assert_finished(self):
        """Ensure the dependency graph was fully traversed.

        Args:
            None

        Returns:
            None

        Raises:
            exceptions.InconsistentArguments:
                Raised if some models were never processed, which indicates the
                dependency graph could not be fully resolved.
        """
        # Raise a clear error if some models could never be unlocked.
        if len(self._processed) != len(self.models):
            remaining = sorted(set(self.models) - self._processed)
            raise exceptions.InconsistentArguments(
                "Emission model dependency graph could not be fully "
                f"resolved. Remaining models: {remaining}"
            )

    def _collect_model_tree(self, model):
        """Walk the model tree reachable through true dependencies.

        Args:
            model (EmissionModel):
                The model currently being visited.

        Returns:
            None
        """
        # Store this model while enforcing unique labels within the closure.
        if model.label not in self.models:
            self.models[model.label] = model
        elif self.models[model.label] is model:
            # Stop immediately when this exact model object was already seen.
            return
        else:
            existing_model = self.models[model.label]

            # Reuse an existing node when another object encodes the same
            # logical model, as happens when the root model is shallow-copied
            # but related models still point at the original instance.
            if self._models_are_equivalent(existing_model, model):
                return

            # Reuse an existing node when another model points at the same
            # logical label and masked variants must be split into distinct
            # labels to remain addressable in the execution graph.
            if len(model.masks) == 0:
                raise exceptions.InconsistentArguments(
                    f"Label {model.label} is already in use by another "
                    f"model. Existing model: \n{existing_model}, "
                    f"\nNew model: \n{model})"
                )

            # Mirror the existing masked-model behaviour by extending the
            # label when the collision is caused by a masked variant.
            for mask_dict in model.masks:
                model.label += (
                    f"_{mask_dict['attr']}"
                    f"{mask_dict['op']}"
                    f"{mask_dict['thresh']}"
                ).replace(" ", "-")

            self.models[model.label] = model

        # Walk all direct model dependencies for this model.
        for dependency in self._get_model_dependencies(model):
            self._collect_model_tree(dependency)

        # Record related models so they can be added as extra roots later.
        self._related_models.update(model.related_models)

    def _get_model_dependencies(self, model):
        """Return the direct in-graph model dependencies for a model.

        Args:
            model (EmissionModel):
                The model whose dependencies should be inspected.

        Returns:
            list[EmissionModel]:
                The direct dependencies represented by ``EmissionModel``
                instances in the execution graph.
        """
        # Define a local container for model dependencies.
        model_dependencies = []

        # Transformations depend on the model they are applied to.
        if model._is_transforming and self._is_model_instance(model.apply_to):
            model_dependencies.append(model.apply_to)

        # Combinations depend on every contributing child model.
        if model._is_combining:
            for child in model.combine:
                if self._is_model_instance(child):
                    model_dependencies.append(child)

        # Generators can depend on intrinsic, attenuated, and scaler models.
        if model._is_generating:
            generator_dependencies = ()

            if hasattr(model.generator, "_intrinsic"):
                generator_dependencies += (model.generator._intrinsic,)
            if hasattr(model.generator, "_attenuated"):
                generator_dependencies += (model.generator._attenuated,)
            if hasattr(model.generator, "_scaler"):
                generator_dependencies += (model.generator._scaler,)

            for dependency in generator_dependencies:
                if self._is_model_instance(dependency):
                    model_dependencies.append(dependency)

        # Scaling by another model object is also a true dependency because the
        # downstream model reads that emission during execution.
        for scaler in model.scale_by:
            if self._is_model_instance(scaler):
                model_dependencies.append(scaler)

        # Scaling by another model label is also a true dependency if that
        # label resolves within the compiled closure.
        for scaler in model.scale_by:
            if isinstance(scaler, str) and scaler in self.models:
                model_dependencies.append(self.models[scaler])

        # Deduplicate while preserving discovery order.
        ordered_model_dependencies = []
        seen_model_labels = set()

        for dependency in model_dependencies:
            if dependency.label in seen_model_labels:
                continue
            seen_model_labels.add(dependency.label)
            ordered_model_dependencies.append(dependency)

        return ordered_model_dependencies

    def _get_active(self, models, dependencies):
        """Return active flags for models required by saved outputs.

        Active flags define the subgraph that will actually be queued. A
        model is active if it is saved itself, or if it lies on a dependency
        path feeding a saved model.

        Args:
            models (dict):
                Mapping from model label to ``EmissionModel`` instance for the
                full discovered graph.
            dependencies (dict):
                Mapping from model label to the labels of its direct
                dependencies in the full discovered graph.

        Returns:
            dict:
                Mapping from model label to a boolean active flag.
        """
        # Seed activation from models whose emissions must survive execution.
        active = {label: False for label in models}
        pending_labels = [
            label for label, model in models.items() if model.save
        ]

        # Walk backwards through dependencies to activate every required input.
        while len(pending_labels) > 0:
            label = pending_labels.pop()
            if active[label]:
                continue

            active[label] = True
            pending_labels.extend(dependencies[label])

        return active

    def _delete_expired_emission(
        self,
        label,
        emissions,
        particle_emissions,
    ):
        """Delete an unsaved emission once its lifetime has expired.

        Args:
            label (str):
                The label to delete.
            emissions (dict):
                The integrated emissions dictionary.
            particle_emissions (dict):
                The particle emissions dictionary.

        Returns:
            None
        """
        # Skip labels that are explicitly requested to survive execution.
        if self.models[label].save:
            return

        # Remove the integrated emission if it is still present.
        if label in emissions:
            del emissions[label]

        # Remove the particle emission when that representation exists.
        if label in particle_emissions:
            del particle_emissions[label]

    def _models_are_equivalent(self, existing_model, new_model):
        """Return whether two models encode the same logical node.

        Args:
            existing_model (EmissionModel):
                The model already stored in the queue.
            new_model (EmissionModel):
                The newly encountered model with the same label.

        Returns:
            bool:
                ``True`` when both models describe the same logical emission
                node and can safely share a single queue entry.
        """
        # Compare the key attributes that define the model operation and output
        # identity so accidental label collisions still raise an error.
        existing_combine = tuple(
            child.label if self._is_model_instance(child) else child
            for child in existing_model.combine
        )
        new_combine = tuple(
            child.label if self._is_model_instance(child) else child
            for child in new_model.combine
        )
        existing_scale_by = tuple(
            scaler.label if self._is_model_instance(scaler) else scaler
            for scaler in existing_model.scale_by
        )
        new_scale_by = tuple(
            scaler.label if self._is_model_instance(scaler) else scaler
            for scaler in new_model.scale_by
        )
        existing_apply_to = self._get_apply_to_label(existing_model)
        new_apply_to = self._get_apply_to_label(new_model)

        return (
            existing_model.emitter == new_model.emitter
            and existing_model.extract == new_model.extract
            and existing_model.grid is new_model.grid
            and existing_model.generator is new_model.generator
            and existing_model.transformer is new_model.transformer
            and existing_apply_to == new_apply_to
            and existing_combine == new_combine
            and existing_scale_by == new_scale_by
            and self._values_equal(
                existing_model.fixed_parameters,
                new_model.fixed_parameters,
            )
            and self._values_equal(
                existing_model.lam_mask,
                new_model.lam_mask,
            )
            and self._values_equal(
                existing_model.vel_shift,
                new_model.vel_shift,
            )
            and existing_model._is_extracting == new_model._is_extracting
            and existing_model._is_generating == new_model._is_generating
            and existing_model._is_transforming == new_model._is_transforming
            and existing_model._is_combining == new_model._is_combining
            and existing_model.per_particle == new_model.per_particle
            and existing_model.save == new_model.save
            and existing_model.masks == new_model.masks
        )

    def _get_apply_to_label(self, model):
        """Return the label of the model a transformation applies to.

        Args:
            model (EmissionModel):
                The model whose transformation target should be resolved.

        Returns:
            str or None:
                The target label for transformation models, otherwise ``None``.
        """
        # Non-transforming models do not carry an apply-to dependency.
        if not model._is_transforming:
            return None

        # Resolve the apply_to target without assuming private attributes have
        # already been initialised on every logically equivalent object.
        if isinstance(model.apply_to, str):
            return model.apply_to
        return model.apply_to.label

    def _values_equal(self, existing_value, new_value):
        """Return whether two nested values are equal by value.

        Args:
            existing_value (Any):
                The existing value attached to the stored model.
            new_value (Any):
                The new value attached to the candidate model.

        Returns:
            bool:
                ``True`` when both values are equivalent by value, otherwise
                ``False``.
        """
        # Recursively compare dictionary keys and values.
        if isinstance(existing_value, dict) and isinstance(new_value, dict):
            if set(existing_value) != set(new_value):
                return False
            return all(
                self._values_equal(existing_value[key], new_value[key])
                for key in existing_value
            )

        # Recursively compare tuple and list contents.
        if isinstance(existing_value, (list, tuple)) and isinstance(
            new_value, (list, tuple)
        ):
            if len(existing_value) != len(new_value):
                return False
            return all(
                self._values_equal(existing_item, new_item)
                for existing_item, new_item in zip(existing_value, new_value)
            )

        # Compare array-like values element-by-element.
        if isinstance(existing_value, np.ndarray) or isinstance(
            new_value, np.ndarray
        ):
            try:
                return np.array_equal(existing_value, new_value)
            except Exception:
                return False

        # Fall back to regular equality for scalar or object values.
        try:
            result = existing_value == new_value
        except Exception:
            return False

        # Collapse array-like equality results into a single boolean.
        if isinstance(result, np.ndarray):
            return bool(np.all(result))

        return bool(result)

    @staticmethod
    def _is_model_instance(obj):
        """Return whether an object is an ``EmissionModel`` instance.

        Args:
            obj (Any):
                The object to test.

        Returns:
            bool:
                ``True`` if ``obj`` is an ``EmissionModel`` instance,
                otherwise ``False``.
        """
        # Import lazily so this module does not create a circular import.
        from synthesizer.emission_models.base_model import EmissionModel

        # Return whether this object participates in the model graph.
        return isinstance(obj, EmissionModel)
