"""A module defining a class for observational instruments.

This module contains the `Instrument` class, which is used to define
observational instruments for use in the Synthesizer package. The
`Instrument` class contains everything needed to define a telescope or
spectrograph, including the filters, resolution, wavelength array, depth,
depth aperture radius, signal-to-noise ratios, PSFs, fixed noise_maps and
correlated-noise source maps.

`Instrument` objects can define instruments to be used for synthetic:
    - Photometry (with or without noise)
    - Imaging (with or without PSFs and noise)
    - Spectroscopy (with or without noise)
    - Resolved Spectroscopy (with or without PSFs and noise)

Example usage:
    # Create an Instrument object
    instrument = Instrument(
        label="HST",
        filters=FilterCollection(...),
        resolution=0.1 * kpc,
        noise_maps={...},
        noise_source_maps={...},
        psfs={...},
        )
    print(instrument)
"""

import h5py
import numpy as np
from unyt import angstrom, arcsecond, kpc, unyt_array, unyt_quantity

from synthesizer import exceptions
from synthesizer.instruments.filters import FilterCollection
from synthesizer.instruments.instrument_collection import InstrumentCollection
from synthesizer.instruments.photometric_noise import CorrelatedNoiseModel
from synthesizer.units import Quantity, accepts
from synthesizer.utils.ascii_table import TableFormatter
from synthesizer.utils.util_funcs import obj_to_hashable


class Instrument:
    """A class containing the properties defining an observational instrument.

    This class contains everything needed to define a telescope or
    spectrograph, including the filters, resolution, wavelength array,
    depth, depth aperture radius, signal-to-noise ratios, PSFs, fixed noise
    arrays and correlated-noise source maps.

    `Instrument` objects can define instruments to be used for synthetic:
        - Photometry (with or without noise)
        - Imaging (with or without PSFs and noise)
        - Spectroscopy (with or without noise)
        - Resolved Spectroscopy (with or without PSFs and noise)

    Attributes:
        label (str):
            The label of the Instrument.
        filters (FilterCollection):
            The filters of the Instrument.
        resolution (unyt_array):
            The resolution of the Instrument.
        lam (unyt_array):
            The wavelength array of the Instrument.
        depth (unyt_array):
            The depth of the Instrument.
        depth_app_radius (unyt_array):
            The depth aperture radius of the Instrument.
        snrs (unyt_array):
            The signal-to-noise ratios of the Instrument.
        psfs (unyt_array):
            The PSFs of the Instrument.
        noise_maps (unyt_array):
            Fixed noise arrays to apply directly.
        noise_source_maps (unyt_array):
            Source maps used to build correlated-noise models.
    """

    # Define quantities
    lam = Quantity("wavelength")

    @accepts(resolution=(kpc, arcsecond), lam=angstrom)
    def __init__(
        self,
        label,
        filters=None,
        resolution=None,
        lam=None,
        depth=None,
        depth_app_radius=None,
        snrs=None,
        psfs=None,
        noise_maps=None,
        noise_source_maps=None,
    ):
        """Initialize an Instrument object.

        Args:
            label (str):
                The label for the Instrument, e.g. HST-WFC3, JWST-NIRCam, etc.
            filters (FilterCollection, optional):
                The filters of the Instrument. Default is None.
            resolution (unyt_quantity, optional):
                The resolution of the Instrument (with units). Default is None.
            lam (unyt_array, optional):
                The wavelength array of the Instrument (with units). Default
                is None.
            depth (dict/float/unyt_quantity, optional):
                The depth of the Instrument. Can be specified as:
                - float: apparent magnitude (dimensionless)
                - unyt_quantity: flux or luminosity with units
                - dict: mapping of filter names to depths (float or
                  unyt_quantity)
                If filters are passed, depth must be a dictionary with an
                entry per filter. Default is None.
            depth_app_radius (unyt_quantity, optional):
                The depth aperture radius of the Instrument (with units).
                If this is omitted but SNRs and depths are provided, it is
                assumed that the depth is a point source depth.
                Default is None.
            snrs (unyt_array, optional):
                The signal-to-noise ratios of the Instrument.
                Default is None.
            psfs (unyt_array, optional):
                The PSFs of the Instrument. If doing imaging this should be
                a dictionary of PSFs with an entry for each filter. If doing
                resolved spectroscopy this should be an array.
                Default is None.
            noise_maps (dict/unyt_array, optional):
                Fixed noise arrays for the Instrument (must have units). Can
                be:
                - unyt_array: noise as a function of wavelength (spectroscopy)
                - dict: mapping of filter names to fixed noise arrays
                  (imaging)
                These arrays are applied directly when noise is requested.
                Units must be compatible with the image type (flux or
                luminosity). Default is None.
            noise_source_maps (dict, optional):
                Source maps used to model correlated imaging noise. These must
                be provided as a dict mapping filter names to 2D source noise
                arrays, with units compatible with the image type. Fresh noise
                realisations are generated from these templates each time
                correlated noise is applied. Default is None.
        """
        # Set the label of the Instrument
        self.label = label

        # Set the filters of the Instrument (applicable for photometry and
        # imaging)
        self.filters = filters

        # Set the resolution of the Instrument (applicable for imaging)
        if (
            isinstance(resolution, (unyt_array, unyt_quantity))
            or resolution is None
        ):
            self.resolution = resolution
        else:
            raise exceptions.InconsistentArguments(
                "Resolution must have units."
            )

        # Set the wavelength array for the Instrument (applicable for
        # spectroscopy)
        self.lam = lam

        # Set the depth of the Instrument (applicable for imaging)
        self.depth = depth

        # Set the depth aperture radius of the Instrument (applicable for
        # imaging)
        self.depth_app_radius = depth_app_radius

        # Set the signal-to-noise ratio of the Instrument (applicable for
        # spectroscopy and imaging)
        self.snrs = snrs

        # Set the PSFs of the Instrument (applicable for imaging and resolved
        # spectroscopy)
        self.psfs = psfs

        # Set the noise maps of the Instrument (applicable for imaging and
        # resolved spectroscopy)
        self.noise_maps = noise_maps

        # Set the source maps used to build correlated-noise models for
        # imaging. These are separate from ``noise_maps``, which represent
        # fixed noise arrays to be applied directly. The property setter keeps
        # the per-filter models in sync with the currently assigned templates.
        self.noise_source_maps = noise_source_maps

        self._validate()

    def _build_correlated_noise_models(self):
        """Build per-filter correlated noise models from source maps.

        Returns:
            dict or None:
                A dictionary mapping filter codes to correlated-noise models,
                or None when the instrument is not configured for imaging
                correlated noise.

        Raises:
            InconsistentArguments:
                If ``noise_source_maps`` is neither a dictionary nor None when
                correlated imaging noise is requested.
        """
        if self.noise_source_maps is None:
            return None

        if not isinstance(self.noise_source_maps, dict):
            raise exceptions.InconsistentArguments(
                "noise_source_maps must be a dict keyed by filter code for "
                "correlated noise generation."
            )

        return {
            filter_code: CorrelatedNoiseModel(noise_map)
            for filter_code, noise_map in self.noise_source_maps.items()
        }

    @property
    def noise_source_maps(self):
        """Return the correlated-noise source maps.

        Returns:
            dict or None:
                The dictionary of per-filter correlated-noise source maps, or
                None if no correlated-noise templates are configured.
        """
        return self._noise_source_maps

    @noise_source_maps.setter
    def noise_source_maps(self, value):
        """Set correlated-noise source maps and rebuild their models.

        Args:
            value (dict or None):
                Dictionary of per-filter correlated-noise source maps, or None
                to remove the current correlated-noise configuration.
        """
        self._noise_source_maps = value

        # Keep the models in lockstep with the source templates so callers can
        # update ``instrument.noise_source_maps`` after construction without
        # manually rebuilding any caches.
        self.correlated_noise_models = self._build_correlated_noise_models()

    def _validate(self):
        """Validate the Instrument object."""
        # If we have a depth make sure we have a SNR
        if self.depth is not None and self.snrs is None:
            raise exceptions.MissingArgument(
                "If you set a depth you must also set the SNRs"
            )

        # If we have a SNR make sure we have a depth
        if self.snrs is not None and self.depth is None:
            raise exceptions.MissingArgument(
                "If you set a SNR you must also set the depth"
            )

        # Make sure we don't have both a SNR and a direct/fixed noise map.
        # Only one noise definition can be active at a time.
        if self.snrs is not None and self.noise_maps is not None:
            raise exceptions.MissingArgument(
                "You cannot set depths and SNRs at the same time as "
                " noise maps"
            )

        # Correlated-noise source maps are an alternative noise definition in
        # the same way as fixed arrays or SNR/depth.
        if self.snrs is not None and self.noise_source_maps is not None:
            raise exceptions.MissingArgument(
                "You cannot set depths and SNRs at the same time as "
                "noise source maps"
            )

        if self.noise_maps is not None and self.noise_source_maps is not None:
            raise exceptions.MissingArgument(
                "You cannot set fixed noise maps and correlated noise source "
                "maps at the same time"
            )

    @property
    def _resolution(self):
        """Return the resolution of the Instrument without the units.

        This emulates the behaviour of a Quantity object but here we can
        have either angular or Cartesian resolutions. There's no need for
        any complex unit handling here so we instead just introduced
        this special case property.

        Returns:
            float:
                The resolution of the Instrument.
        """
        return None if self.resolution is None else self.resolution.value

    @property
    def can_do_photometry(self):
        """Return whether the Instrument do photometry.

        Returns:
            bool:
                Whether the Instrument do photometry.
        """
        return self.filters is not None

    @property
    def can_do_imaging(self):
        """Return whether the Instrument do simple imaging.

        This flags whether the Instrument do imaging basic
        imaging without PSFs and noise.

        Returns:
            bool:
                Whether the Instrument do simple imaging.
        """
        return self.can_do_photometry and self.resolution is not None

    @property
    def can_do_psf_imaging(self):
        """Return whether the Instrument do imaging with PSFs.

        Returns:
            bool:
                Whether the Instrument do imaging with PSFs.
        """
        return self.can_do_imaging and self.psfs is not None

    @property
    def can_do_noisy_imaging(self):
        """Return whether the Instrument do imaging with noise.

        This is a bit more complex than the other flags as it can be true
        for various different noise definitions.

        We ignore the depth aperature radius here since a depth and SNR
        without it is assumed to be a point source depth.

        Returns:
            bool:
                Whether the Instrument do imaging with noise.
        """
        # Check we have a compatible noise definition
        have_noise = self.noise_maps is not None
        have_noise |= self.noise_source_maps is not None
        have_noise |= self.snrs is not None and self.depth is not None

        return self.can_do_imaging and have_noise

    @property
    def can_do_spectroscopy(self):
        """Return whether the Instrument do spectroscopy.

        Returns:
            bool:
                Whether the Instrument do spectroscopy.
        """
        return self.lam is not None

    @property
    def can_do_noisy_spectroscopy(self):
        """Return whether the Instrument can do spectroscopy with noise.

        This is a bit more complex than the other flags as it can be true
        for various different noise definitions.

        We ignore the depth aperature radius here since a depth and SNR
        without it is assumed to be a point source depth.

        Returns:
            bool:
                Whether the Instrument do spectroscopy
                with noise.
        """
        # Check we have a compatible noise definition
        have_noise = self.noise_maps is not None
        have_noise |= self.snrs is not None and self.depth is not None

        return self.can_do_spectroscopy and have_noise

    @property
    def can_do_resolved_spectroscopy(self):
        """Return whether the Instrument do resolved spectroscopy.

        Returns:
            bool:
                Whether the Instrument do simple resolved
                spectroscopy.
        """
        return self.can_do_spectroscopy and self.resolution is not None

    @property
    def can_do_psf_spectroscopy(self):
        """Return whether the Instrument can do smoothed resolved spectroscopy.

        Returns:
            bool:
                Whether the Instrument do smoothed resolved
                spectroscopy.
        """
        return self.can_do_resolved_spectroscopy and self.psfs is not None

    @property
    def can_do_noisy_resolved_spectroscopy(self):
        """Return whether the Instrument can do noisy resolved spectroscopy.

        This is a bit more complex than the other flags as it can be true
        for various different noise definitions.

        We ignore the depth aperature radius here since a depth and SNR
        without it is assumed to be a point source depth.

        Returns:
            bool:
                Whether the Instrument do noisy resolved
                spectroscopy.
        """
        # Check we have a compatible noise definition
        have_noise = self.noise_maps is not None
        have_noise |= self.snrs is not None and self.depth is not None

        return self.can_do_resolved_spectroscopy and have_noise

    @classmethod
    def _from_hdf5(cls, group, **kwargs):
        """Create an Instrument from an HDF5 group.

        Args:
            group (h5py.Group):
                The group containing the Instrument attributes.
            **kwargs:
                Keyword arguments to override the attributes stored in the
                HDF5 file.

        Returns:
            Instrument:
                The Instrument created from the HDF5 group.
        """
        # Unpack the filters if they are present
        if "Filters" in group:
            filters = FilterCollection._from_hdf5(group["Filters"])
        else:
            filters = None

        #  Unpack the resolution
        if "Resolution" in group:
            resolution = unyt_array(
                group["Resolution"][...], group["Resolution"].attrs["units"]
            )
        else:
            resolution = None

        # Unpack the wavelenths
        if "Wavelength" in group:
            lam = unyt_array(
                group["Wavelength"][...], group["Wavelength"].attrs["units"]
            )
        else:
            lam = None

        # Unpack the depths, these can be either a group of datasets, a
        # single dataset or not present
        if "Depth" in group and isinstance(group["Depth"], h5py.Group):
            depth = {
                key: unyt_array(value[...], value.attrs["units"])
                for key, value in group["Depth"].items()
            }
        elif "Depth" in group:
            depth = unyt_array(
                group["Depth"][...], group["Depth"].attrs["units"]
            )
        else:
            depth = None

        # Unpack the depth aperture radius
        if "DepthApertureRadius" in group:
            depth_app_radius = unyt_array(
                group["DepthApertureRadius"][...],
                group["DepthApertureRadius"].attrs["units"],
            )
        else:
            depth_app_radius = None

        # Unpack the SNRs, these can be either a group of datasets, a
        # single dataset or not present
        if "SNRs" in group and isinstance(group["SNRs"], h5py.Group):
            snrs = {
                key: unyt_array(value[...], value.attrs["units"])
                for key, value in group["SNRs"].items()
            }
        elif "SNRs" in group:
            snrs = unyt_array(group["SNRs"][...], group["SNRs"].attrs["units"])
        else:
            snrs = None

        # Unpack the PSFs, these can be either a group of datasets, a
        # single dataset or not present
        if "PSFs" in group and isinstance(group["PSFs"], h5py.Group):
            psfs = {}
            for key in group["PSFs"]:
                # We can also have a group of datasets or a single dataset here
                if isinstance(group["PSFs"][key], h5py.Group):
                    for subkey in group["PSFs"][key]:
                        psfs[f"{key}/{subkey}"] = unyt_array(
                            group["PSFs"][key][subkey][...],
                            group["PSFs"][key][subkey].attrs["units"],
                        )
                else:
                    psfs[key] = unyt_array(
                        group["PSFs"][key][...],
                        group["PSFs"][key].attrs["units"],
                    )
        elif "PSFs" in group:
            psfs = unyt_array(group["PSFs"][...], group["PSFs"].attrs["units"])
        else:
            psfs = None

        # Unpack the noise maps, these can be either a group of datasets, a
        # single dataset or not present
        if "NoiseMaps" in group and isinstance(group["NoiseMaps"], h5py.Group):
            noise_maps = {
                key: unyt_array(value[...], value.attrs["units"])
                for key, value in group["NoiseMaps"].items()
            }
        elif "NoiseMaps" in group:
            noise_maps = unyt_array(
                group["NoiseMaps"][...], group["NoiseMaps"].attrs["units"]
            )
        else:
            noise_maps = None

        # Unpack the correlated-noise source maps. These are only defined for
        # imaging and are stored separately from fixed noise arrays.
        if "NoiseSourceMaps" in group and isinstance(
            group["NoiseSourceMaps"], h5py.Group
        ):
            noise_source_maps = {
                key: unyt_array(value[...], value.attrs["units"])
                for key, value in group["NoiseSourceMaps"].items()
            }
        else:
            noise_source_maps = None

        # Overrise any of the attributes with the kwargs if they are present
        # in the kwargs
        if "filters" in kwargs:
            filters = kwargs["filters"]
        if "resolution" in kwargs:
            resolution = kwargs["resolution"]
        if "lam" in kwargs:
            lam = kwargs["lam"]
        if "depth" in kwargs:
            depth = kwargs["depth"]
        if "depth_app_radius" in kwargs:
            depth_app_radius = kwargs["depth_app_radius"]
        if "snrs" in kwargs:
            snrs = kwargs["snrs"]
        if "psfs" in kwargs:
            psfs = kwargs["psfs"]
        if "noise_maps" in kwargs:
            noise_maps = kwargs["noise_maps"]
        if "noise_source_maps" in kwargs:
            noise_source_maps = kwargs["noise_source_maps"]

        # Create a new instance of the Instrument class
        instance = cls.__new__(cls)

        # Set the label of the Instrument
        instance.label = group.attrs["label"]
        instance.filters = filters
        instance.resolution = resolution
        instance.lam = lam
        instance.depth = depth
        instance.depth_app_radius = depth_app_radius
        instance.snrs = snrs
        instance.psfs = psfs
        instance.noise_maps = noise_maps
        instance.noise_source_maps = noise_source_maps

        instance._validate()

        return instance

    def to_hdf5(self, group):
        """Save the Instrument to an HDF5 group.

        Args:
            group (h5py.Group):
                The group in which to save the Instrument.

        """
        # Write out the label, technically pointless because the group is
        # named with the label but makes loading easier
        group.attrs["label"] = self.label

        # Write out the filters into a Filters group
        if self.filters is not None:
            filters_group = group.create_group("Filters")
            self.filters._write_filters_to_group(filters_group)

        # Write out the simple datasets
        if self.resolution is not None:
            ds = group.create_dataset(
                "Resolution", data=self.resolution.value, dtype=float
            )
            ds.attrs["units"] = str(self.resolution.units)
        if self.lam is not None:
            ds = group.create_dataset(
                "Wavelength", data=self.lam.value, dtype=float
            )
            ds.attrs["units"] = str(self.lam.units)
        if self.depth_app_radius is not None:
            ds = group.create_dataset(
                "DepthApertureRadius",
                data=self.depth_app_radius.value,
                dtype=float,
            )
            ds.attrs["units"] = str(self.depth_app_radius.units)

        # Write out the depth, SNRs, PSFs and noise which may be a group of
        # datasets or a single datasets or not present
        if self.depth is not None:
            if isinstance(self.depth, dict):
                depth_group = group.create_group("Depth")
                for key, value in self.depth.items():
                    ds = depth_group.create_dataset(
                        key, data=value.value, dtype=float
                    )
                    ds.attrs["units"] = "dimensionless"
            else:
                ds = group.create_dataset(
                    "Depth", data=self.depth.value, dtype=float
                )
                ds.attrs["units"] = "dimensionless"

        if self.snrs is not None:
            if isinstance(self.snrs, dict):
                snrs_group = group.create_group("SNRs")
                for key, value in self.snrs.items():
                    ds = snrs_group.create_dataset(
                        key, data=value.value, dtype=float
                    )
                    ds.attrs["units"] = "dimensionless"
            else:
                ds = group.create_dataset(
                    "SNRs", data=self.snrs.value, dtype=float
                )
                ds.attrs["units"] = "dimensionless"

        if self.psfs is not None:
            if isinstance(self.psfs, dict):
                psfs_group = group.create_group("PSFs")
                for key, value in self.psfs.items():
                    ds = psfs_group.create_dataset(
                        key, data=value, dtype=float
                    )
                    ds.attrs["units"] = "dimensionless"
            else:
                ds = group.create_dataset("PSFs", data=self.psfs, dtype=float)
                ds.attrs["units"] = "dimensionless"

        if self.noise_maps is not None:
            if isinstance(self.noise_maps, dict):
                noise_group = group.create_group("NoiseMaps")
                for key, value in self.noise_maps.items():
                    ds = noise_group.create_dataset(
                        key, data=value.value, dtype=float
                    )
                    ds.attrs["units"] = str(value.units)
            else:
                ds = group.create_dataset(
                    "NoiseMaps", data=self.noise_maps.value, dtype=float
                )
                ds.attrs["units"] = str(self.noise_maps.units)

        if self.noise_source_maps is not None:
            noise_source_group = group.create_group("NoiseSourceMaps")
            for key, value in self.noise_source_maps.items():
                ds = noise_source_group.create_dataset(
                    key, data=value.value, dtype=float
                )
                ds.attrs["units"] = str(value.units)

    def __str__(self):
        """Return a string representation of the Instrument.

        Returns:
               str:
                   The string representation of the Instrument.
        """
        formatter = TableFormatter(self)

        return formatter.get_table("Instrument")

    def __add__(self, other):
        """Combine two Instruments into an Instrument Collection.

        Note, the combined instruments must have different labels, combining
        two instruments together into a new single instrument would be
        ill-defined since the only thing that could differ would be the
        filters, in which case the new filters should be added to the
        filter collection itself.

        Args:
            other (Instrument):
                The Instrument to combine with this one.

        Returns:
            InstrumentCollection:
                The Instrument Collection containing the two Instruments.
        """
        # Ensure other is an Instrument or InstrumentCollection
        if not isinstance(other, (Instrument, InstrumentCollection)):
            raise exceptions.InconsistentAddition(
                f"Cannot combine Instrument with {type(other)}."
            )

        # If we have an instrument collection just use the instrument
        # collection add method
        if isinstance(other, InstrumentCollection):
            return other + self

        # Check if the labels are the same
        if self.label == other.label:
            raise exceptions.InconsistentAddition(
                "Adding two instruments with the same label is ill-defined. "
                "If you want to add extra filters to an instrument, use the "
                "add_filters method."
            )

        # Create a new instrument Collection
        collection = InstrumentCollection()

        # Add the two instruments to the Collection
        collection.add_instruments(self, other)

        return collection

    def __hash__(self):
        """Enable hashing of Instrument objects.

        This enables instruments to be able to placed into a set for quick
        removal of duplicates.
        """
        # Unpack all the annoyingly flexible options to a consistent hashable
        # state
        filters_hash = obj_to_hashable(
            self.filters.filter_codes if self.filters else None
        )
        lam_hash = obj_to_hashable(self._lam)
        depth_hash = obj_to_hashable(self.depth)
        depth_app_radius_hash = obj_to_hashable(self.depth_app_radius)
        snrs_hash = obj_to_hashable(self.snrs)
        psfs_hash = obj_to_hashable(self.psfs)
        noise_maps_hash = obj_to_hashable(self.noise_maps)
        noise_source_maps_hash = obj_to_hashable(self.noise_source_maps)
        resolution_hash = obj_to_hashable(self.resolution)

        # Define the hash based on the label and properties of the object
        return hash(
            (
                self.label,
                filters_hash,
                resolution_hash,
                lam_hash,
                depth_hash,
                depth_app_radius_hash,
                snrs_hash,
                psfs_hash,
                noise_maps_hash,
                noise_source_maps_hash,
            )
        )

    def __eq__(self, other):
        """Enable equality comparison of Instrument objects.

        Two Instruments are considered equal if all their defining
        properties match. This is consistent with __hash__ to ensure
        proper behavior in sets and dictionaries.

        Args:
            other: The object to compare with.

        Returns:
            bool: True if the instruments are equal, False otherwise.
            NotImplemented: If other is not an Instrument.
        """
        # Return NotImplemented for non-Instrument objects so Python
        # can try the reverse comparison
        if not isinstance(other, Instrument):
            return NotImplemented

        # Compare all fields used in __hash__ using the same normalized
        # representations
        return (
            self.label == other.label
            and obj_to_hashable(
                self.filters.filter_codes if self.filters else None
            )
            == obj_to_hashable(
                other.filters.filter_codes if other.filters else None
            )
            and obj_to_hashable(self._lam) == obj_to_hashable(other._lam)
            and obj_to_hashable(self.depth) == obj_to_hashable(other.depth)
            and obj_to_hashable(self.depth_app_radius)
            == obj_to_hashable(other.depth_app_radius)
            and obj_to_hashable(self.snrs) == obj_to_hashable(other.snrs)
            and obj_to_hashable(self.psfs) == obj_to_hashable(other.psfs)
            and obj_to_hashable(self.noise_maps)
            == obj_to_hashable(other.noise_maps)
            and obj_to_hashable(self.noise_source_maps)
            == obj_to_hashable(other.noise_source_maps)
            and obj_to_hashable(self.resolution)
            == obj_to_hashable(other.resolution)
        )

    def get_correlated_noise_model(self, filter_code):
        """Return the correlated-noise model for a given filter.

        Args:
            filter_code (str):
                Key into ``self.correlated_noise_models`` identifying the
                model to use.

        Returns:
            CorrelatedNoiseModel:
                The correlated-noise model associated with ``filter_code``.

        Raises:
            MissingArgument:
                If no correlated-noise models are configured on the
                instrument.
            InconsistentArguments:
                If ``filter_code`` is not present in the configured models.
        """
        if self.correlated_noise_models is None:
            raise exceptions.MissingArgument(
                "No correlated noise models are set on this Instrument. "
                "Provide noise_source_maps when constructing the Instrument."
            )

        if filter_code not in self.correlated_noise_models:
            raise exceptions.InconsistentArguments(
                "No correlated noise model found for filter "
                f"'{filter_code}'. Available filters: "
                f"{list(self.correlated_noise_models.keys())}"
            )

        return self.correlated_noise_models[filter_code]

    def apply_noise(
        self,
        image,
        filter_code,
        correct_periodicity=True,
        rng_seed=None,
        aperture_radius=None,
    ):
        """Apply noise to a single image using the instrument's noise model.

        Dispatches automatically to the appropriate noise mode based on what
        is configured on the instrument:

        - ``noise_maps`` present → apply the stored fixed noise array.
        - ``noise_source_maps`` dict present → correlated noise modelled from
          the observed template for ``filter_code``.
        - ``snrs`` + ``depth`` set → white noise scaled from the instrument's
          depth and signal-to-noise ratio.

        Args:
            image (Image):
                The image to apply noise to.
            filter_code (str):
                The filter code identifying which noise array, source map, or
                SNR entry to use.
            correct_periodicity (bool):
                Passed to the correlated-noise path: if True a
                periodicity-dilution correction is applied. Default is True.
            rng_seed (int, optional):
                Seed for the random number generator (correlated noise only).
            aperture_radius (unyt_quantity, optional):
                Aperture radius for the SNR/depth noise path.  If None a
                point-source depth is assumed.

        Returns:
            Image:
                A new Image with noise added.  ``noise_arr`` and
                ``weight_map`` are set on the returned object.

        Raises:
            MissingArgument:
                If the instrument has no noise configuration.
        """
        if self.noise_maps is not None:
            noise_arr = (
                self.noise_maps[filter_code]
                if isinstance(self.noise_maps, dict)
                else self.noise_maps
            )
            return image.apply_noise_array(noise_arr)
        elif self.correlated_noise_models is not None:
            return image.apply_correlated_noise(
                self,
                filter_code,
                correct_periodicity=correct_periodicity,
                rng_seed=rng_seed,
            )
        elif self.snrs is not None and self.depth is not None:
            snr = (
                self.snrs[filter_code]
                if isinstance(self.snrs, dict)
                else self.snrs
            )
            depth = (
                self.depth[filter_code]
                if isinstance(self.depth, dict)
                else self.depth
            )
            return image.apply_noise_from_snr(
                snr=snr, depth=depth, aperture_radius=aperture_radius
            )
        else:
            raise exceptions.MissingArgument(
                "The instrument has no noise configuration. Set either "
                "noise_maps, noise_source_maps, or snrs and depth before "
                "calling apply_noise."
            )

    def apply_noises(
        self,
        image_collection,
        correct_periodicity=True,
        rng_seed=None,
        aperture_radius=None,
    ):
        """Apply noise to every image in a collection.

        Calls :meth:`apply_noise` for each filter in the collection. When
        correlated-noise source maps are used, the expensive correlation-
        function estimation is cached on the per-filter model so the FFT step
        runs at most once per filter regardless of how many images share the
        same instrument.

        Args:
            image_collection (ImageCollection):
                The collection to apply noise to.
            correct_periodicity (bool):
                Passed to the correlated-noise path. Default is True.
            rng_seed (int, optional):
                Seed for the random number generator (correlated noise only).
            aperture_radius (unyt_quantity, optional):
                Aperture radius for the SNR/depth noise path.

        Returns:
            ImageCollection:
                A new ImageCollection with noise applied to each image.
        """
        from synthesizer.imaging.image_collection import ImageCollection

        rng = np.random.default_rng(rng_seed)

        noisy_imgs = {}
        for f in image_collection.filter_codes:
            filter_rng_seed = (
                None
                if rng_seed is None
                else int(rng.integers(0, np.iinfo(np.uint32).max))
            )
            noisy_imgs[f] = self.apply_noise(
                image_collection.imgs[f],
                f,
                correct_periodicity=correct_periodicity,
                rng_seed=filter_rng_seed,
                aperture_radius=aperture_radius,
            )

        return ImageCollection(
            resolution=image_collection.resolution,
            fov=image_collection.fov,
            imgs=noisy_imgs,
        )

    def add_filters(
        self,
        filters,
        psfs=None,
        noise_maps=None,
        noise_source_maps=None,
    ):
        """Add filters to the Instrument.

        If PSFs, fixed noise arrays, or correlated-noise source maps are
        provided, an entry for each new filter must be provided in the
        corresponding dictionary.

        Args:
            filters (FilterCollection):
                The filters to add to the Instrument.
            psfs (dict, optional):
                The PSFs for the new filters. Default is None.
            noise_maps (dict, optional):
                Fixed noise arrays for the new filters. Default is None.
            noise_source_maps (dict, optional):
                Correlated-noise source maps for the new filters.
                Default is None.
        """
        # Ensure we have an entry for each filter code in the PSF and noise
        # dictionaries.
        if psfs is not None and set(psfs.keys()) != set(filters.filter_codes):
            raise exceptions.InconsistentAddition(
                "PSFs missing for filters: "
                f"{set(filters.filter_codes) - set(psfs.keys())}"
            )
        if noise_maps is not None and set(noise_maps.keys()) != set(
            filters.filter_codes
        ):
            raise exceptions.InconsistentAddition(
                "Noise maps missing for filters: "
                f"{set(filters.filter_codes) - set(noise_maps.keys())}"
            )
        if noise_source_maps is not None and set(
            noise_source_maps.keys()
        ) != set(filters.filter_codes):
            raise exceptions.InconsistentAddition(
                "Noise source maps missing for filters: "
                f"{set(filters.filter_codes) - set(noise_source_maps.keys())}"
            )

        # Validate that any new noise payload would not create an invalid mixed
        # noise configuration before mutating the instrument.
        if self.snrs is not None and noise_maps is not None:
            raise exceptions.MissingArgument(
                "You cannot set depths and SNRs at the same time as noise maps"
            )
        if self.snrs is not None and noise_source_maps is not None:
            raise exceptions.MissingArgument(
                "You cannot set depths and SNRs at the same time as "
                "noise source maps"
            )
        if noise_maps is not None and self.noise_source_maps is not None:
            raise exceptions.MissingArgument(
                "You cannot set fixed noise maps and correlated noise source "
                "maps at the same time"
            )
        if noise_source_maps is not None and self.noise_maps is not None:
            raise exceptions.MissingArgument(
                "You cannot set fixed noise maps and correlated noise source "
                "maps at the same time"
            )

        # Combine the filters together only after validation succeeds.
        self.filters += filters

        # If PSFs are provided, add them to the psfs
        if psfs is not None:
            self.psfs.update(psfs)

        # If fixed noise arrays are provided, add them to the
        # direct-application noise maps.
        if noise_maps is not None:
            if self.noise_maps is None:
                self.noise_maps = {}
            self.noise_maps.update(noise_maps)

        # If correlated-noise source maps are provided, add them and build the
        # matching per-filter models.
        if noise_source_maps is not None:
            if self.noise_source_maps is None:
                self.noise_source_maps = {}
            self.noise_source_maps.update(noise_source_maps)

        self._validate()
