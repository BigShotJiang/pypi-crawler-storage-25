General examples
----------------
