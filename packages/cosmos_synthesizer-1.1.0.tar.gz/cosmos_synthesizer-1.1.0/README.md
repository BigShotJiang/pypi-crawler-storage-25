# Synthesizer

<img src="https://raw.githubusercontent.com/synthesizer-project/synthesizer/main/docs/source/img/synthesizer_logo.png" align="right" width="140px"/>

[![workflow](https://github.com/synthesizer-project/synthesizer/actions/workflows/python-app.yml/badge.svg?branch=main)](https://github.com/synthesizer-project/synthesizer/actions)
[![Documentation Status](https://github.com/synthesizer-project/synthesizer/actions/workflows/static.yml/badge.svg)](https://synthesizer-project.github.io/synthesizer/)
[![Contributions welcome](https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat)](https://github.com/synthesizer-project/synthesizer/blob/main/docs/CONTRIBUTING.md)
[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)](https://github.com/pre-commit/pre-commit)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![License: GPLv3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![PyPI version](https://img.shields.io/pypi/v/cosmos-synthesizer.svg)](https://pypi.org/project/cosmos-synthesizer/)
[![Downloads](https://img.shields.io/pypi/dm/cosmos-synthesizer.svg)](https://pypi.org/project/cosmos-synthesizer/)
[![DOI](https://joss.theoj.org/papers/10.21105/joss.09436/status.svg)](https://doi.org/10.21105/joss.09436)
[![DOI](https://zenodo.org/badge/483867728.svg)](https://doi.org/10.5281/zenodo.18910098)

Synthesizer is a Python package for generating synthetic astrophysical observables. It is modular, flexible, extensible and fast.

Read the documentation [here](https://synthesizer-project.github.io/synthesizer/).

## Getting Started

The latest stable release of Synthesizer can be installed directly using pip,

```bash
pip install cosmos-synthesizer
```

Please refer to the [installation documentation](https://synthesizer-project.github.io/synthesizer/getting_started/installation.html) for further information.

**Note**: We do not currently support Windows, to use Synthesizer on Windows please install the Windows Subsystem for Linux (WSL).

Various configuration options can also be set at installation (see [here](https://synthesizer-project.github.io/synthesizer/advanced/config_options.html)).

## Getting Grids

In most use cases you will need a grid of theoretical spectra. Premade grids can be downloaded from the [grids data server](https://sussex.app.box.com/folder/316830966925?v=SynthesizerGrids).

Note that you can also create your own grids using (or adapting) the [`grid-generation` repo](https://github.com/synthesizer-project/grid-generation).

## Contributing

Please see [here](docs/CONTRIBUTING.md) for contribution guidelines.

## Citation & Acknowledgement

Please cite **both** of the following papers ([Lovell et al. 2025](https://astro.theoj.org/article/145766-synthesizer-a-software-package-for-synthetic-astronomical-observables), [Roper et al. 2026](https://ui.adsabs.harvard.edu/abs/2025arXiv250615811R/abstract)) if you use Synthesizer in your research:

    @article{Lovell2025Synthesizer,
    	author = {Lovell, Christopher C. and Roper, William J. and Vijayan, Aswin P. and Wilkins, Stephen M. and Newman, Sophie and Seeyave, Louise},
    	journal = {The Open Journal of Astrophysics},
    	doi = {10.33232/001c.145766},
    	year = {2025},
    	month = {oct 9},
    	publisher = {Maynooth Academic Publishing},
    	title = {Synthesizer: a {Software} {Package} for {Synthetic} {Astronomical} {Observables}},
    	volume = {8},
    }

    @article{Roper2026Synthesizer,
        author = {Roper, Will J. and Lovell, Christopher C. and Vijayan, Aswin and Wilkins, Stephen and Akins, Hollis and Berger, Sabrina and Sant Fournier, Connor and Harvey, Thomas and Iyer, Kartheik and Leonardi, Marco and Newman, Sophie and Pautasso, Borja and Perry, Ashley and Seeyave, Louise and Sommovigo, Laura and Punyasheel, Paurush and d'Hautefort, Adrien Aufan Stoffels and Rawlings, Alex},
        journal = {Journal of Open Source Software},
        doi = {10.21105/joss.09436},
        year = {2026},
        publisher = {Open Journals},
        title = {Synthesizer: Synthetic Observables for Modern Astronomy},
        volume = {11},
        number = {119},
        pages = {9436},
    }

## Licence

[GNU General Public License v3.0](https://github.com/synthesizer-project/synthesizer/blob/main/LICENSE.md)
