"""NMP — NeuroMessage Protocol. Standalone reference implementation."""
__version__ = "1.0.0"
from .message import (
    NMPMessage, NMPSignals, TrustLevel, SystemMode,
    Budget, TraceEntry,
    create_message, validate_message,
)
