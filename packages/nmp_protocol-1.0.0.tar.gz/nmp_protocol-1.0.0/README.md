# NMP — NeuroMessage Protocol

**Open communication protocol for multi-agent AI systems with behavioral modulation.**

NMP is to agent communication what HTTP is to web communication — but with built-in behavioral signals. While MCP handles tool access and A2A handles agent coordination, NMP carries **intention**, **modulation**, and **accountability** alongside data.

## Quick Start

```bash
pip install nmp-protocol
```

```python
from nmp import create_message, TrustLevel, validate_message

# Create an NMP message with behavioral signals
msg = create_message(
    from_agent="router",
    to_agent="legal-analyzer",
    content="Analyze this contract for risk clauses",
    trust=TrustLevel.VERIFIED,
)

# Modulate behavioral signals
msg.signals.urgency = 0.7      # Time-critical
msg.signals.quality = 0.9      # High analysis depth needed
msg.signals.inhibition = 0.0   # No blocking needed

# Validate
errors = validate_message(msg)
assert not errors

# Serialize
json_str = msg.to_json()
```

## 6 Behavioral Signals

| Signal | Range | Biological Analog | Purpose |
|--------|-------|-------------------|---------|
| `urgency` | [0, 1] | Noradrenaline | Processing speed (Yerkes-Dodson curve) |
| `quality` | [0, 1] | Serotonin | Analysis depth |
| `inhibition` | [0, 1] | GABA | Blocking / pausing |
| `activation` | [0, 1] | Glutamate | Processing intensity |
| `focus` | [0, 1] | Acetylcholine | Context narrowing |
| `reward` | [-0.5, 1] | Dopamine | Feedback signal |

## Trust Levels

Trust can only decrease through a pipeline: `min(current_trust, source_trust)`

| Level | Value | Meaning |
|-------|-------|---------|
| `HOSTILE` | 0 | Known malicious source |
| `UNTRUSTED` | 1 | Unknown / unverified |
| `VERIFIED` | 2 | Authenticated but not fully trusted |
| `TRUSTED` | 3 | Fully trusted internal agent |

## Specification

Full spec: [nmp-protocol.org](https://nmp-protocol.org)

Reference implementations: Python (this package), [TypeScript](https://www.npmjs.com/package/nmp-protocol), [Go](https://pkg.go.dev/github.com/AIP-Labs/nmp-protocol)

## License

Apache 2.0. Spec licensed under CC BY-SA 4.0.
