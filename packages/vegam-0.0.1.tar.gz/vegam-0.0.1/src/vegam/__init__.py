# credits: https://github.com/deependujha
"""vegam python module"""
