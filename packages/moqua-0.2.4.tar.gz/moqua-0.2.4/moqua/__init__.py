"""
Moqua - Quantitative Finance Tools
"""

# ==========================================
# 1. CORE (Maths & Statistiques)
# ==========================================
from .core import (
    pdf, 
    cdf, 
    z_score, 
    adf, 
    kpss, 
    kalman_dynamic_beta, 
    johansen_test,
    coint_pvalue,
    test_beta_stability,
    moving_average,
    rolling_std,
    log_returns
)

# Explicitly expose subpackages for better discovery
from . import contracts, engine, instruments

# ==========================================
# 2. PRICING (Moteurs & Instruments)
# ==========================================
from .pricing import (
    bs_price,
    bs_delta,
    bs_gamma,
    bs_vega,
    bs_theta,
    bs_rho,
    implied_volatility,
    EuropeanOption,
    Option,
    Bond,
    BondOption,
    cboe_vix,
    heston_call_price
)

# ==========================================
# 2.5 NEW ARCHITECTURE (Pricers & Engines)
# ==========================================
from .pricing.instruments.european_option import EuropeanOptionPricer
from .pricing.engine.black_scholes import BlackScholesEngine, BlackScholesCalculator
from .pricing.engine.black76 import Black76Engine, Black76Calculator
from .pricing.engine.bachelier import BachelierEngine, BachelierCalculator
from .pricing.contracts import Market, Engine, Calculator

# ==========================================
# 3. OPTIMIZATION (Calibration)
# ==========================================
from .optimization import (
    levenberg_marquardt,
    differential_evolution,
    calibrate_heston_hybrid
)

# ==========================================
# 4. OUTPUTS (Visualisation)
# ==========================================
from .outputs import (
    PairPlotter,
    create_excel_report
)

__version__ = "0.2.4"
