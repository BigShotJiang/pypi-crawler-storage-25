import numpy as np
from dataclasses import dataclass
from abc import ABC, abstractmethod
from typing import Optional
from functools import cached_property

@dataclass
class Option:
    K : float | np.ndarray
    T : float | np.ndarray
    w : float | np.ndarray # Call -> 1 Put | -> -1

@dataclass
class Market:
    r : float | np.ndarray
    sigma : float | np.ndarray
    S: Optional[float] = None
    F: Optional[float] = None
    dividend_yield: Optional[float] = 0.0

class Calculator(ABC):

    def _result(self, arr):
        arr = np.asarray(arr)
        return arr.item() if arr.ndim == 0 else arr

    @property
    @abstractmethod
    def price(self):
        pass

    @property
    @abstractmethod
    def delta(self):
        pass

    @property
    @abstractmethod
    def gamma(self):
        pass

    @property
    @abstractmethod
    def vega(self):
        pass

    @property
    @abstractmethod
    def rho(self):
        pass

    @property
    @abstractmethod
    def theta(self):
        pass

class Engine(ABC):

    @abstractmethod
    def calculator(self, option: Option, market: Market) -> Calculator:
        pass

        

