import numpy as np
from moqua.pricing.contracts import Calculator, Engine, Option, Market

class EuropeanOptionPricer:

    def __init__(self, engine: Engine, yield_curve=None, vol_surface=None):
        self.engine = engine
        self.yield_curve = yield_curve
        self.vol_surface = vol_surface

    def set_engine(self, new_engine: Engine):
        self.engine = new_engine

    def get_calculator(self, K, T, spot=None, forward=None, r=None, sigma=None, option_type='call') -> Calculator:
        w = np.where(np.asarray(option_type) == 'call', 1.0, -1.0)
        option = Option(K=K, T=T, w=w)
        
        if r is not None:
            r_val = r
        elif self.yield_curve is not None:
            r_val = self.yield_curve.get_rate(T)
        else:
            raise ValueError("You must provide 'r' directly or configure a 'yield_curve'.")
            
        if sigma is not None:
            sigma_val = sigma
        elif self.vol_surface is not None:
            sigma_val = self.vol_surface.get_vol(K, T)
        else:
            raise ValueError("You must provide 'sigma' directly or configure a 'vol_surface'.")

        market = Market(
            r=r_val,
            sigma=sigma_val,
            S=spot, F=forward
        )
        return self.engine.calculator(option, market)