# ABOUTME: floom Python SDK. Exposes app, storage, remember, artifacts, and context.
# ABOUTME: Usage: from floom import app, remember; @app.action; remember("key", value)

from floom._app import App, app
from floom._db import get_db
from floom._storage import forget, remember, storage
from floom.artifacts import save_artifact, save_dataframe, save_json
from floom.context import Context, context

__version__ = "0.1.4"
__all__ = [
    "app",
    "App",
    "storage",
    "remember",
    "forget",
    "db",
    "get_db",
    "save_artifact",
    "save_dataframe",
    "save_json",
    "context",
    "Context",
]


def __getattr__(name):
    if name == "db":
        return get_db()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
