# ABOUTME: Per-project SQLite database for relational storage inside runner containers.
# ABOUTME: Stores DB at /storage/.floom.db (inside existing storage volume). WAL mode, Row factory.

import os
import sqlite3

_conn = None


def get_db() -> sqlite3.Connection:
    """Get the per-project SQLite connection (singleton).

    The database file lives at {FLOOM_STORAGE_DIR}/.floom.db,
    inside the existing per-project storage volume. It persists
    across runs via the host mount.

    Returns:
        sqlite3.Connection with Row factory and WAL mode enabled.
    """
    global _conn
    if _conn is None:
        storage_dir = os.environ.get("FLOOM_STORAGE_DIR", "/storage")
        os.makedirs(storage_dir, exist_ok=True)
        db_path = os.path.join(storage_dir, ".floom.db")
        _conn = sqlite3.connect(db_path)
        _conn.row_factory = sqlite3.Row
        _conn.execute("PRAGMA journal_mode=WAL")
        _conn.execute("PRAGMA busy_timeout=5000")
    return _conn


def __getattr__(name):
    if name == "db":
        return get_db()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
