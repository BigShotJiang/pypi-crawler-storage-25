# ABOUTME: floom app class with @app.action decorator and app.stream().
# ABOUTME: Syntactic sugar that makes intent explicit.
# ABOUTME: Runner checks _floom_action attribute on functions.

import os


class App:
    """floom application container.

    Use @app.action to mark functions as floom actions.
    The runner uses this to discover which functions to expose.

    Example:
        from floom import app

        @app.action
        def greet(name: str) -> dict:
            return {"message": f"Hello, {name}!"}

        @app.action(name="custom_name")
        def my_func(x: int) -> dict:
            return {"result": x * 2}
    """

    def __init__(self):
        self._actions = []

    def action(self, func=None, *, name=None):
        """Mark a function as a floom action.

        Can be used with or without arguments:
            @app.action
            def my_func(): ...

            @app.action(name="custom")
            def my_func(): ...
        """

        def decorator(f):
            f._floom_action = True
            f._floom_name = name or f.__name__
            self._actions.append(f)
            return f

        if func is not None:
            return decorator(func)
        return decorator

    def stream(self, key: str, chunk: str):
        """Stream partial output back to the UI in real-time.

        Call this repeatedly during long-running actions to show
        progressive results instead of waiting for the full response.

        Example:
            @app.action
            def generate(topic: str):
                full_text = ""
                for chunk in model.generate(topic, stream=True):
                    full_text += chunk.text
                    app.stream("draft", chunk.text)
                return {"draft": full_text}
        """
        stream_url = os.environ.get("FLOOM_STREAM_URL")
        stream_token = os.environ.get("FLOOM_STREAM_TOKEN")
        run_id = os.environ.get("EL_RUN_ID")
        if not stream_url or not run_id or not stream_token:
            return  # Silently skip if not in streaming context

        try:
            import requests as _requests

            _requests.post(
                f"{stream_url}/v1/runs/{run_id}/chunks",
                json={"key": key, "chunk": chunk},
                headers={"Authorization": f"Bearer {stream_token}"},
                timeout=2,
            )
        except Exception:
            pass  # Non-fatal: don't break user code if streaming fails

    def schedule(self, cron: str, *, timezone: str = "UTC"):
        """Mark an action to run on a cron schedule.

        Sets metadata on the function. The schedule is created automatically
        when the app is deployed (via floom.yaml or API).

        Must be applied before @app.action:
            @app.schedule("0 9 * * *", timezone="UTC")
            @app.action
            def daily_report() -> dict:
                return {"summary": "..."}

        Args:
            cron: Cron expression (e.g. "0 9 * * *" for daily at 9am)
            timezone: IANA timezone name (default: "UTC")
        """

        def decorator(f):
            f._floom_schedule = cron
            f._floom_schedule_timezone = timezone
            return f

        return decorator

    @property
    def actions(self):
        """List of registered action functions."""
        return list(self._actions)


# Singleton instance
app = App()
