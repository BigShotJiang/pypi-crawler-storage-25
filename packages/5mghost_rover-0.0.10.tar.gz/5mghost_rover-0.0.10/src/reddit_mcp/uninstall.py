"""Uninstall helpers for reddit-mcp client registrations and local config."""

from __future__ import annotations

import shutil

from fivemghost_shared_client.registration import unregister_all

from .console import console_print
from .config import CONFIG_DIR


def run_uninstall() -> None:
    """Remove reddit-mcp registrations and local config."""
    console_print("\n🧹 reddit-mcp uninstall\n")
    unregister_all(server_name="reddit-mcp")

    if CONFIG_DIR.exists():
        # Why: ~/.reddit-mcp is owned by this package and only stores its launcher/auth/cookies/cache.
        shutil.rmtree(CONFIG_DIR)
        console_print(f"  ✅ Removed local reddit-mcp config: {CONFIG_DIR}")
    else:
        console_print(f"  ℹ️  Local reddit-mcp config already absent: {CONFIG_DIR}")

    console_print("  ℹ️  If you installed globally, remove the package with: pip uninstall 5mghost-rover")
    console_print("")
