---
name: use-reddit-mcp
preamble-tier: 3
version: 1.0.0
description: |
  Use when the user wants Reddit post/subreddit search, thread analysis, or batch Reddit lookups.
  Also use when the user pastes Reddit URLs (reddit.com/r/.../comments/...).
  Keywords: Reddit, subreddit, 帖子, 评论, 热门, 搜索, batch, reddit.com.
---

# use-reddit-mcp

Use reddit-mcp tools for Reddit data retrieval and analysis workflows.

## 0. Hard Constraints
- Use `mcp__reddit_mcp__*` tools only for Reddit data.
- If tool access fails, stop and surface the setup/check command instead of falling back to scraping.

## Trigger Hints
- User provides subreddit names (`r/python`, `AskReddit`) or Reddit links.
- User asks for subreddit trends, post details, or Reddit search results.

## 1. Intent -> Tool Routing
| User Intent | Tool(s) |
|---|---|
| Browse posts from a subreddit | `get_subreddit_posts` |
| Inspect one Reddit thread with comments | `get_post_content` |
| Search Reddit globally or in one subreddit | `search_reddit` |
| Fetch subreddit metadata | `get_subreddit_info` |
| Batch fetch many posts | `batch_get_posts` |
| Batch fetch many subreddits | `batch_get_subreddits` |
| Check cookie health / account identity | `check_cookies` |
| Check API quota status | `get_rate_limit_status` |

## 2. Analysis Rules
- Prefer batch tools when the user provides multiple URLs/IDs.
- Preserve pagination cursors (`after`) when continuing list/search requests.
- Respect tool limits (`max 25` for batch, bounded comment depth/limit).
- For post/thread analytics, return key metrics first (score, comments, subreddit, recency) before deeper commentary.

## 3. Common Workflows
### Workflow A: Subreddit Scan
1. `get_subreddit_posts` for baseline sample.
2. If needed, `search_reddit` with focused queries in the same subreddit.
3. Summarize patterns and include follow-up cursor instructions when `after` is present.

### Workflow B: URL Batch Analysis
1. Normalize incoming URLs/IDs.
2. `batch_get_posts` for thread detail extraction.
3. Optionally enrich with `get_subreddit_info` for context.
4. Return structured comparison (engagement, themes, outliers).

### Workflow C: Health + Quota Check
1. `check_cookies` to verify Reddit auth cookies.
2. `get_rate_limit_status` before large batch calls.
3. If invalid/expired, instruct `reddit-mcp setup-cookies` and stop.

## 4. Output Rules
- Answer the user question first, then include supporting data.
- Use concise tables for multi-item comparisons.
- Surface tool errors directly with actionable next step.

## 5. Setup Boundary
- Only discuss setup when user asks or a tool fails due auth/cookies.
- Useful commands: `reddit-mcp setup`, `reddit-mcp setup-cookies`, `reddit-mcp check`, `reddit-mcp install-skills`.
