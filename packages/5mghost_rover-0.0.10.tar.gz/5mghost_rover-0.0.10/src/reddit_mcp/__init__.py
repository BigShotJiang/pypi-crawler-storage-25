"""reddit-mcp — Reddit MCP server for batch Reddit data access."""

from . import console

__version__ = "0.0.6"
