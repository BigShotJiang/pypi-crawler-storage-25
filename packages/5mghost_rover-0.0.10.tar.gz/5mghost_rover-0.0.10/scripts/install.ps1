$ErrorActionPreference = "Stop"

irm https://mkterswingman.com/install/reddit-mcp.ps1 | iex
