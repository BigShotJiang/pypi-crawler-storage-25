#!/usr/bin/env bash
set -euo pipefail

curl -fsSL https://mkterswingman.com/install/reddit-mcp.sh | bash
