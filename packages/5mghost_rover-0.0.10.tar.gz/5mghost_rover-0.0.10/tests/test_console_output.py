from __future__ import annotations

from reddit_mcp import console


def test_safe_console_text_strips_unencodable_gbk_symbols() -> None:
    text = "✅ Shared auth already configured: C:/tmp/auth.json"

    result = console.safe_console_text(text, encoding="gbk")

    assert result == "Shared auth already configured: C:/tmp/auth.json"


def test_safe_console_text_preserves_utf8_output() -> None:
    text = "✅ Shared auth already configured"

    result = console.safe_console_text(text, encoding="utf-8")

    assert result == text
