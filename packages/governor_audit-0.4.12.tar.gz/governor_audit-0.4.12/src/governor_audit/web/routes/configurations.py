"""/admin/configurations — single-config + run-scan page.

  GET  /admin/configurations         → detail (or 303 to /setup if no config)
  GET  /admin/configurations/new     → form
  POST /admin/configurations         → save config + run a scan inline

The single submit on the detail page does both: persists the project /
region / dbt-only default and immediately kicks off a scan of the chosen
period. Errors render inline on the originating template.

Project picker behaviour
------------------------
On render, both new.html and detail.html call ``gcp_projects_for_picker()``
to populate a ``<datalist>`` of projects the active gcloud principal can
see. This mirrors the cloud version's autocomplete pattern (which uses the
same ``governor_core.gcp.clients.list_gcp_projects`` helper). Free-text
input is preserved as a fallback for cases where the principal lacks
``resourcemanager.projects.list`` (the project audit READ permission is
narrower than the project LIST permission).
"""

from __future__ import annotations

import concurrent.futures
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Annotated

from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from pydantic import ValidationError

from governor_audit.auth.adc import ProbeStatus, probe_adc
from governor_audit.config.loader import ConfigNotFoundError, load_config, save_config
from governor_audit.config.schema import (
    AuditConfig,
    ScanDefaults,
    WebUIConfig,
)

logger = logging.getLogger("governor_audit.web.configurations")
router = APIRouter()
_ALLOWED_SCAN_DAYS = (1, 7, 30, 180)

# INFORMATION_SCHEMA.JOBS_BY_PROJECT requires ``bigquery.jobs.listAll`` at
# the project level. We probe the active ADC against every accessible
# project to filter the picker down to projects the user can actually
# audit, instead of showing all 734 of an org's projects.
_AUDIT_REQUIRED_PERMISSION = "bigquery.jobs.listAll"
# Concurrency for the probe pool. Each probe is a single
# ``projects.testIamPermissions`` API call (~50-150ms). 16 keeps wall
# time under ~10s for 700-project orgs without tripping per-user quota.
_PROBE_CONCURRENCY = 16
# Per-call timeout — the probe should fail fast for slow / broken
# projects so the slowest tail doesn't hold up the whole picker.
_PROBE_TIMEOUT_S = 5.0
# In-process cache, keyed on the active gcloud principal so switching
# accounts re-probes. Survives across requests, dies with the worker.
_PROBE_CACHE: dict[str, list[dict[str, str]]] = {}


@dataclass(frozen=True)
class PickerContext:
    """Context the configuration form needs to render the project picker."""

    projects: list[dict[str, str]]
    principal: str | None
    discovery_error: str | None  # human-readable; None when projects[] is fresh


def gcp_projects_for_picker() -> PickerContext:
    """Best-effort listing of projects the active gcloud ADC can see.

    Never raises. Failure modes are surfaced via ``discovery_error`` so the
    template can render the manual-input fallback with an explanatory note.

    Three failure modes worth distinguishing:

    1. ADC missing entirely → user hasn't run gcloud auth.
    2. ADC present but lacks ``resourcemanager.projects.list`` → common in
       narrow-scoped audit principals (consultant has read-only on a single
       project but no org-wide list permission). Free-text input still works.
    3. Network / API error → transient; user can retry.
    """
    try:
        from governor_core.gcp.clients import (
            GCPCredentialsError,
            list_gcp_projects,
        )
    except ImportError as exc:
        return PickerContext(
            projects=[],
            principal=None,
            discovery_error=f"Project discovery unavailable: {exc}",
        )

    principal = _active_principal()

    try:
        projects = list_gcp_projects()
    except GCPCredentialsError as exc:
        return PickerContext(
            projects=[],
            principal=principal,
            discovery_error=(
                "No Application Default Credentials found. Run "
                "`gcloud auth application-default login` and reload this page. "
                f"({exc})"
            ),
        )
    except Exception as exc:  # noqa: BLE001
        # PermissionDenied / Forbidden / network errors all bucket here.
        # Most common: principal can read jobs in their target project but
        # doesn't have org-wide resourcemanager.projects.list. The form keeps
        # working — they just have to type the project ID.
        msg = str(exc).lower()
        if "permission" in msg or "forbidden" in msg or "denied" in msg:
            note = (
                "The active gcloud principal can't list projects. This is "
                "fine — narrow audit principals often lack "
                "resourcemanager.projects.list while still having read access "
                "to a specific project. Type the project ID manually below."
            )
        else:
            note = f"Project discovery failed: {exc}"
        return PickerContext(projects=[], principal=principal, discovery_error=note)

    # Filter to the subset where ADC actually has
    # ``bigquery.jobs.listAll`` — the permission INFORMATION_SCHEMA.
    # JOBS_BY_PROJECT requires. Without this an org-admin principal
    # would see all 700+ projects in the picker even though only a
    # handful are actually auditable.
    projects = _filter_to_audit_accessible(projects, principal)

    # Sort projects for stable rendering (stable IDs first).
    projects.sort(key=lambda p: (p.get("display_name", "") or "", p["project_id"]))
    return PickerContext(projects=projects, principal=principal, discovery_error=None)


def _probe_project_access(client, project_id: str) -> bool:
    """Return True if the active ADC has ``bigquery.jobs.listAll`` on the project.

    Uses ``ProjectsClient.test_iam_permissions`` — a single API call per
    project that returns the subset of requested permissions the caller
    actually holds. Empty result, Forbidden, or any other error all map
    to "not accessible" so a single broken project doesn't tank the
    whole picker.
    """
    try:
        result = client.test_iam_permissions(
            resource=f"projects/{project_id}",
            permissions=[_AUDIT_REQUIRED_PERMISSION],
            timeout=_PROBE_TIMEOUT_S,
        )
        return _AUDIT_REQUIRED_PERMISSION in (result.permissions or [])
    except Exception:  # noqa: BLE001
        return False


def _filter_to_audit_accessible(
    projects: list[dict[str, str]], principal: str | None
) -> list[dict[str, str]]:
    """Probe each project's IAM permissions in parallel and keep only the
    ones the active ADC can actually audit.

    Cached per-principal in ``_PROBE_CACHE`` so the probe runs once per
    process per logged-in user. Falls back to the unfiltered list on
    any cache lookup mismatch or probe-pool failure — a noisy picker
    is better than an empty one.
    """
    if not projects:
        return projects

    cache_key = principal or "<unknown>"
    cached = _PROBE_CACHE.get(cache_key)
    if cached is not None:
        cached_ids = {p["project_id"] for p in cached}
        current_ids = {p["project_id"] for p in projects}
        if cached_ids == current_ids:
            # Same project set as last probe — return the filtered cache.
            return [p for p in projects if any(c["project_id"] == p["project_id"] for c in cached)]

    try:
        from governor_core.gcp.clients import get_resource_manager_client

        client = get_resource_manager_client()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Skipping project probe — resource manager unavailable: %s", exc)
        return projects

    project_ids = [p["project_id"] for p in projects]
    accessible_ids: set[str] = set()

    with concurrent.futures.ThreadPoolExecutor(max_workers=_PROBE_CONCURRENCY) as pool:
        futures = {
            pool.submit(_probe_project_access, client, pid): pid for pid in project_ids
        }
        for future in concurrent.futures.as_completed(futures):
            pid = futures[future]
            try:
                if future.result():
                    accessible_ids.add(pid)
            except Exception as exc:  # noqa: BLE001
                logger.debug("Probe failed for %s: %s", pid, exc)

    filtered = [p for p in projects if p["project_id"] in accessible_ids]
    _PROBE_CACHE[cache_key] = filtered
    logger.info(
        "Filtered project picker: %d of %d projects have %s",
        len(filtered),
        len(projects),
        _AUDIT_REQUIRED_PERMISSION,
    )
    return filtered


def _has_adc() -> bool:
    """True iff Application Default Credentials are present and loadable.

    The wizard's "Continue" button gates on this, NOT on
    ``_active_principal()`` — because user OAuth credentials produced by
    ``gcloud auth application-default login`` don't expose any email
    field on the credential object (the JSON file is just
    ``{"type": "authorized_user", "client_id": ..., "refresh_token": ...}``).
    Insisting on a known principal stranded users with otherwise-valid
    ADC at step 1 of setup.
    """
    try:
        from google.auth import default as google_auth_default
    except ImportError:
        return False
    try:
        creds, _ = google_auth_default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"],
        )
        return creds is not None
    except Exception:  # noqa: BLE001
        return False


def _active_principal() -> str | None:
    """Return the active gcloud principal email, or ``None`` if unknowable.

    Best-effort — never raises. Used for "you're signed in as <email>"
    hints so the user knows whose ADC the audit will be running with.
    Returning None is fine — the wizard advances on ``_has_adc()``, not
    on this. Order of attempts:

    1. Service-account fields (``service_account_email``,
       ``_service_account_email``).
    2. The ``.account`` attr that some credential types expose.
    3. ``gcloud config get-value account`` via subprocess — covers the
       common ``gcloud auth application-default login`` case where the
       cred object has no email but the gcloud config does.
    """
    try:
        from google.auth import default as google_auth_default
    except ImportError:
        return None
    try:
        creds, _ = google_auth_default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"],
        )
    except Exception:  # noqa: BLE001
        return None
    via_creds = (
        getattr(creds, "service_account_email", None)
        or getattr(creds, "_service_account_email", None)
        or getattr(creds, "account", None)
    )
    if via_creds:
        return via_creds
    return _gcloud_config_account()


def _gcloud_config_account() -> str | None:
    """Best-effort: ask `gcloud config get-value account` for the active
    principal email. Returns None if gcloud isn't on PATH or returns
    nothing — never raises."""
    import shutil
    import subprocess

    if not shutil.which("gcloud"):
        return None
    try:
        result = subprocess.run(
            ["gcloud", "config", "get-value", "account"],
            capture_output=True,
            text=True,
            timeout=2.0,
        )
    except Exception:  # noqa: BLE001
        return None
    value = (result.stdout or "").strip()
    # gcloud prints "(unset)" to stdout when no account is set.
    if not value or value == "(unset)":
        return None
    return value


def _render_new(
    request: Request,
    *,
    errors: dict | None = None,
    form_data: dict | None = None,
    status_code: int = 200,
) -> HTMLResponse:
    picker = gcp_projects_for_picker()
    return request.app.state.templates.TemplateResponse(
        request,
        "configurations/new.html",
        {
            "title": "Configure Audit Target — Governor Audit",
            "errors": errors or {},
            "form_data": form_data or {},
            "gcp_projects": picker.projects,
            "active_principal": picker.principal,
            "discovery_error": picker.discovery_error,
        },
        status_code=status_code,
    )


def _scan_banner_for(scan_status: str | None, scan_detail: str | None) -> dict | None:
    """Translate ?scan_status=...&scan_detail=... into a template banner."""
    if not scan_status:
        return None
    mapping = {
        "succeeded": ("success", "Scan succeeded."),
        "started": ("info", "Scan started — running in the background."),
        "lock_held": ("warning", "Another scan is already running."),
        "bad_args": ("error", "Invalid scan parameters."),
        "error": ("error", "Scan failed."),
    }
    level, headline = mapping.get(scan_status, ("info", "Scan finished."))
    return {"level": level, "headline": headline, "detail": scan_detail or ""}


def _load_scan_history(limit: int = 20) -> list[dict]:
    """Load recent ScanRun rows for display on the configuration page."""
    from governor_audit.db.models import ScanRun
    from governor_audit.db.session import (
        build_engine,
        create_all,
        make_session_factory,
    )
    from sqlalchemy import desc

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        rows = (
            session.query(ScanRun).order_by(desc(ScanRun.started_at)).limit(limit).all()
        )
        return [
            {
                "id": s.id,
                "started_at": s.started_at,
                "completed_at": s.completed_at,
                "status": s.status,
                "gcp_project_id": s.gcp_project_id,
                "bigquery_region": s.bigquery_region,
                "requested_lookback_days": s.requested_lookback_days,
                "fetched_job_count": s.fetched_job_count,
                "opportunity_count": s.opportunity_count,
                "dbt_only_filter": s.dbt_only_filter,
                "failure_reason": s.failure_reason,
            }
            for s in rows
        ]


def _cache_stats() -> dict:
    """Snapshot the cache for the configuration page's stats strip:
    cached job count + active opportunity count + last scan timestamp.

    Mirrors governor-web's "Last BigQuery Jobs Sync / Last Manifest
    Change" header strip — except audit only has scans, no manifest.
    """
    from governor_audit.db.models import ScanRun
    from governor_audit.db.session import (
        build_engine,
        create_all,
        make_session_factory,
    )
    from governor_core.opportunities.models import Opportunity
    from governor_core.sync.models import BigQueryJob
    from sqlalchemy import desc

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        last_scan = (
            session.query(ScanRun)
            .filter(ScanRun.status == "succeeded")
            .order_by(desc(ScanRun.completed_at))
            .first()
        )
        return {
            "cached_jobs": session.query(BigQueryJob).count(),
            "active_opps": (
                session.query(Opportunity)
                .filter(Opportunity.status == "active")
                .count()
            ),
            "last_scan_at": (last_scan.completed_at if last_scan else None),
        }


def _scan_query_preview(config: AuditConfig) -> dict[str, object]:
    """Build the INFORMATION_SCHEMA query shapes the scan submits.

    The preview is informational: the actual timestamp parameters are
    recomputed at scan time, but the SQL text and predicates match the scan
    path. The scan uses JOBS_BY_PROJECT for job data, then best-effort syncs
    INFORMATION_SCHEMA.COLUMNS for column metadata used by deterministic
    suggestions.
    """
    from governor_audit.scan.information_schema import build_information_schema_query
    from governor_audit.scan.orchestrator import compute_window

    lookback_days = (
        config.scan_defaults.lookback_days
        if config.scan_defaults.lookback_days in _ALLOWED_SCAN_DAYS
        else 1
    )
    window_start, window_end = compute_window(
        lookback_days=lookback_days,
        now=datetime.now(timezone.utc),
    )
    sql, params = build_information_schema_query(
        project_id=config.gcp_project_id,
        region=config.bigquery_region,
        window_start=window_start,
        window_end=window_end,
        dbt_only=config.scan_defaults.dbt_only,
    )
    preview_params = {
        key: value.isoformat() if isinstance(value, datetime) else value
        for key, value in params.items()
    }
    sql = sql.replace(
        "@window_start", f'TIMESTAMP("{preview_params["window_start"]}")'
    ).replace("@window_end", f'TIMESTAMP("{preview_params["window_end"]}")')
    columns_sql = f"""
        SELECT
            table_schema AS dataset_name,
            table_name,
            column_name,
            data_type,
            ordinal_position
        FROM `{config.gcp_project_id}`.`region-{config.bigquery_region.strip().lower()}`.INFORMATION_SCHEMA.COLUMNS
        WHERE NOT STARTS_WITH(table_schema, '_')
    """.strip()
    return {
        "sql": sql,
        "columns_sql": columns_sql,
        "params": preview_params,
    }


def _render_detail(
    request: Request,
    config: AuditConfig,
    *,
    errors: dict | None = None,
    form_data: dict | None = None,
    flash_message: str | None = None,
    scan_status: str | None = None,
    scan_detail: str | None = None,
    status_code: int = 200,
) -> HTMLResponse:
    picker = gcp_projects_for_picker()
    scans = _load_scan_history()
    stats = _cache_stats()

    # Lightweight ADC status pill — never raises.
    try:
        from governor_audit.auth.adc import probe_adc

        probe = probe_adc(config.gcp_project_id, config.bigquery_region)
        adc_state = {"ok": probe.ok, "label": "ADC ok" if probe.ok else "ADC issue"}
    except Exception:  # noqa: BLE001
        adc_state = {"ok": False, "label": "ADC unknown"}

    return request.app.state.templates.TemplateResponse(
        request,
        "configurations/detail.html",
        {
            "title": "Configuration — Governor Audit",
            "config": config,
            "errors": errors or {},
            "form_data": form_data or {},
            "flash_message": flash_message,
            "gcp_projects": picker.projects,
            "active_principal": picker.principal,
            "discovery_error": picker.discovery_error,
            "scans": scans,
            # ``scan_in_progress`` drives the form-disabled / spinner state.
            # The most-recent ScanRun row carries ``status="running"``
            # while the background daemon thread is mid-flight; the page
            # auto-refreshes every 5s (see template) so this flips back
            # to False as soon as the scan finishes.
            "scan_in_progress": bool(scans and scans[0].get("status") == "running"),
            "scan_banner": _scan_banner_for(scan_status, scan_detail),
            "allowed_scan_days": [1, 7, 30, 180],
            "default_scan_days": (
                config.scan_defaults.lookback_days
                if config.scan_defaults.lookback_days in (1, 7, 30, 180)
                else 1
            ),
            "has_scan_data": any(s["status"] == "succeeded" for s in scans),
            "cache_stats": stats,
            "adc_state": adc_state,
            "scan_query_preview": _scan_query_preview(config),
        },
        status_code=status_code,
    )


@router.get("/admin/configurations", response_class=HTMLResponse)
def configurations_index(
    request: Request,
    scan_status: str | None = None,
    scan_detail: str | None = None,
):
    """For governor-audit there's exactly one config; this route always
    redirects to /new (no config) or renders the detail page (single config).

    When the user arrived via ``?scan_status=started`` (set by the
    setup wizard / Run-scan POST after the daemon was spawned) and the
    most-recent ScanRun has flipped to ``succeeded``, follow through to
    ``/dashboard`` so the page meta-refresh chain ends on the place the
    user actually wants to be — without intermediate clicks.
    """
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    if scan_status == "started":
        scans = _load_scan_history(limit=1)
        if scans and scans[0]["status"] == "succeeded":
            return RedirectResponse(
                url="/dashboard?scan_status=succeeded",
                status_code=303,
            )
        if scans and scans[0]["status"] == "failed":
            return _render_detail(
                request,
                config,
                scan_status="error",
                scan_detail=scans[0].get("failure_reason") or "Scan failed.",
            )

    return _render_detail(
        request, config, scan_status=scan_status, scan_detail=scan_detail
    )


@router.get("/admin/configurations/new", response_class=HTMLResponse)
def configurations_new(request: Request):
    return _render_new(request)


@router.post("/admin/configurations", response_class=HTMLResponse)
def configurations_submit(
    request: Request,
    gcp_project_id: Annotated[str, Form()],
    bigquery_region: Annotated[str, Form()],
    dbt_only_default: Annotated[bool, Form()] = False,
    days: Annotated[int | None, Form()] = None,
):
    """Save the active config and (optionally) run a scan inline.

    The configuration page's single form supplies ``days`` so a click on
    "Run scan" both persists project/region/dbt-only and immediately
    fires the scan. The legacy /new form omits ``days`` and just saves.
    """
    project = (gcp_project_id or "").strip()
    region = (bigquery_region or "").strip()
    form_data = {
        "gcp_project_id": project,
        "bigquery_region": region,
        "dbt_only_default": dbt_only_default,
    }

    field_errors: dict[str, str] = {}
    if not project:
        field_errors["gcp_project_id"] = "GCP project ID is required."
    if not region:
        field_errors["bigquery_region"] = "BigQuery region is required."
    if days is not None and days not in _ALLOWED_SCAN_DAYS:
        field_errors["_general"] = (
            f"Lookback must be one of {sorted(_ALLOWED_SCAN_DAYS)} days. Got {days}."
        )

    try:
        existing = load_config()
    except ConfigNotFoundError:
        existing = None

    def _render_error(errors: dict, *, status: int) -> HTMLResponse:
        if existing:
            return _render_detail(
                request,
                existing,
                errors=errors,
                form_data=form_data,
                status_code=status,
            )
        return _render_new(
            request, errors=errors, form_data=form_data, status_code=status
        )

    if field_errors:
        return _render_error(field_errors, status=422)

    # ADC probe (same path the CLI's `init` runs).
    logger.info("UI configurations: probing ADC against %s / %s", project, region)
    probe = probe_adc(project, region)
    if probe.status is ProbeStatus.ADC_MISSING:
        return _render_error(
            {
                "_general": (
                    "No Application Default Credentials found. "
                    "Run this in your terminal first, then come back and submit:\n"
                    "  gcloud auth application-default login"
                ),
            },
            status=400,
        )
    if probe.status is ProbeStatus.IAM_INSUFFICIENT:
        return _render_error(
            {
                "_general": (
                    f"Permission denied on project '{project}'. The active "
                    f"gcloud principal{' (' + probe.principal + ')' if probe.principal else ''} "
                    "needs roles/bigquery.resourceViewer + roles/bigquery.jobUser "
                    "on this project."
                ),
            },
            status=403,
        )
    if probe.status is ProbeStatus.REGION_UNKNOWN:
        return _render_error(
            {
                "bigquery_region": (
                    f"Region '{region}' or project '{project}' not found by "
                    "BigQuery. Check the region matches a real BigQuery location "
                    "(e.g. 'us', 'eu', 'australia-southeast1')."
                ),
            },
            status=422,
        )
    if not probe.ok:
        return _render_error(
            {"_general": f"ADC probe failed: {probe.message}"},
            status=500,
        )

    # Persist config — preserve any existing LLM block / detection overrides.
    try:
        update_kwargs = {
            "gcp_project_id": project,
            "bigquery_region": region,
            "scan_defaults": ScanDefaults(dbt_only=dbt_only_default),
        }
        if existing is None:
            new_config = AuditConfig.model_validate(
                {
                    **update_kwargs,
                    "web_ui": WebUIConfig(),
                }
            )
        else:
            new_config = existing.model_copy(update=update_kwargs)
            # Re-validate so the field validators (project-id grammar,
            # region normalisation) run on the merged record.
            new_config = AuditConfig.model_validate(new_config.model_dump())
    except ValidationError as exc:
        return _render_error(
            {"_general": f"Config validation failed: {exc}"},
            status=422,
        )

    save_config(new_config)
    logger.info("UI configurations: config saved for %s / %s", project, region)

    # No `days` → save-only (used by /new wizard); otherwise kick off
    # the scan in the background and redirect immediately. The
    # configurations page renders ``scan_in_progress=True`` (driven by
    # the most-recent ScanRun's ``running`` status) so the button shows
    # the spinner card while the daemon thread finishes the work, and
    # the page meta-refreshes every 5s until completion.
    if days is None:
        return RedirectResponse(url="/admin/configurations?saved=1", status_code=303)

    _spawn_scan_in_background(new_config, days=days, dbt_only=dbt_only_default)
    return RedirectResponse(
        url="/admin/configurations?scan_status=started",
        status_code=303,
    )


def _spawn_scan_in_background(
    config: AuditConfig, *, days: int, dbt_only: bool
) -> str:
    """Persist a ``running`` ScanRun row synchronously and kick off the
    actual scan in a daemon thread. Returns the new scan_run_id.

    The synchronous pre-creation is critical: the user expects to see a
    "running" entry in the scan-history table the instant they click
    Run scan. If we relied on the daemon thread to write the row, the
    redirected page might re-render before the thread had even started,
    and we'd lose the auto-refresh hook (``scan_in_progress`` is driven
    by the most-recent ScanRun's status). Pre-creating means the row is
    visible on the very next render — the orchestrator merges the row
    into its own session and updates it as the scan progresses.

    On failure (build_default_client / build_engine / acquire_scan_lock
    / run_scan all raise), the worker marks the ScanRun as ``failed``
    in a short fresh session so the history table reflects the outcome
    instead of leaving the row stuck in ``running`` forever.

    Daemon thread = no pid tracking and no shutdown coordination. If
    the user kills the server mid-scan the daemon dies with the process
    and the ``ScanRun`` row stays as ``running``. We accept that —
    re-running the scan from the UI clears it (each new scan wipes
    previous data for the same config_id; running ScanRun rows from a
    crash will linger until the next successful scan flips them).
    """
    import threading
    from datetime import datetime, timezone

    from governor_audit.db.models import ScanRun
    from governor_audit.db.session import (
        build_engine,
        create_all,
        make_session_factory,
        session_scope,
    )
    from governor_audit.scan.bigquery_client import build_default_client
    from governor_audit.scan.lock import ScanLockHeldError, acquire_scan_lock
    from governor_audit.scan.orchestrator import (
        create_running_scan_run,
        run_scan,
    )

    # 1. Synchronous: create the running ScanRun row up front. Use a
    #    short-lived session so we commit before returning the response.
    engine = build_engine()
    create_all(engine)
    session_factory = make_session_factory(engine)
    with session_scope(session_factory) as session:
        scan_run = create_running_scan_run(
            session,
            config=config,
            lookback_days=days,
            dbt_only=dbt_only,
        )
        scan_run_id = scan_run.id

    # 2. Daemon thread: do the actual scan. On any failure flip the row
    #    to ``failed`` with a short reason so it shows up in the
    #    history table instead of staying ``running``.
    def _mark_failed(reason: str) -> None:
        try:
            with session_scope(session_factory) as session:
                row = session.get(ScanRun, scan_run_id)
                if row is not None and row.status == "running":
                    row.status = "failed"
                    row.failure_reason = (reason or "")[:500]
                    row.completed_at = datetime.now(timezone.utc)
        except Exception:  # noqa: BLE001
            logger.exception("could not mark ScanRun %s as failed", scan_run_id)

    def _worker() -> None:
        try:
            bq_client = build_default_client(
                project_id=config.gcp_project_id,
                region=config.bigquery_region,
            )
            with acquire_scan_lock():
                with session_scope(session_factory) as session:
                    run_scan(
                        config=config,
                        session=session,
                        bq_client=bq_client,
                        lookback_days=days,
                        dbt_only=dbt_only,
                        scan_run=scan_run,
                    )
        except ScanLockHeldError as exc:
            logger.warning("background scan skipped — lock held: %s", exc)
            _mark_failed(f"Scan lock held: {exc}")
        except Exception as exc:  # noqa: BLE001
            logger.exception("background scan failed")
            _mark_failed(str(exc))

    logger.info(
        "background scan spawn: project=%s region=%s days=%d dbt_only=%s scan_run_id=%s",
        config.gcp_project_id,
        config.bigquery_region,
        days,
        dbt_only,
        scan_run_id,
    )
    threading.Thread(target=_worker, name="governor-audit-bg-scan", daemon=True).start()
    return scan_run_id
