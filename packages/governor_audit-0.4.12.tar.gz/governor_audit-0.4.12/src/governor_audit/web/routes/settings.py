"""/admin/settings/* — vendored from governor_web's `/settings/*` namespace.

Four tabs, one per template, all rendered through ``settings/layout.html``:

  GET  /admin/settings                 → Profile (gcloud principal + ADC)
  GET  /admin/settings/appearance      → Theme picker (browser localStorage)
  GET  /admin/settings/llm             → LLM provider / model / params
  POST /admin/settings/llm             → save LLMConfig
  GET  /admin/settings/detection-rules → per-rule enable/disable
  POST /admin/settings/detection-rules → save detection_rule_overrides

The audit doesn't have organisations or users, so cloud-only tabs
(Profile display name, Security, Installation, Auto-PR, Verification)
are dropped. What remains mirrors governor-web's templates 1:1.
"""

from __future__ import annotations

import logging
import os
from typing import Annotated

from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from pydantic import ValidationError
from starlette.datastructures import FormData

from governor_audit.auth.adc import probe_adc
from governor_audit.config.loader import (
    ConfigNotFoundError,
    load_config,
    save_config,
)
from governor_audit.config.schema import LLMConfig
from governor_audit.web.routes.configurations import _active_principal

logger = logging.getLogger("governor_audit.web.settings")
router = APIRouter()


_LLM_PROVIDERS = (
    ("gemini", "Google Gemini"),
)


def _llm_api_key_set(config, provider: str) -> bool:
    """True if a key is available — either persisted in config.llm.api_key
    or supplied via the GEMINI_API_KEY / GOOGLE_API_KEY env var."""
    del provider  # gemini-only since v0.0.14; arg kept for call-site stability
    if config and (config.llm.api_key or "").strip():
        return True
    return bool(os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY"))


def _mask_api_key(key: str | None) -> str | None:
    if not key:
        return None
    return "••••••••" + key[-4:] if len(key) > 4 else "••••"


def _adc_status(config) -> dict:
    try:
        probe = probe_adc(config.gcp_project_id, config.bigquery_region)
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "status": "UNKNOWN", "message": f"probe failed: {exc}"}
    return {
        "ok": probe.ok,
        "status": probe.status.name if probe.status else "UNKNOWN",
        "message": probe.message or "",
    }


def _load_config_or_redirect():
    try:
        return load_config(), None
    except ConfigNotFoundError:
        return None, RedirectResponse(
            url="/setup", status_code=303
        )


# ─── Profile (default tab) ───────────────────────────────────────────


@router.get("/admin/settings", response_class=HTMLResponse)
def settings_profile(request: Request):
    config, redirect = _load_config_or_redirect()
    if redirect:
        return redirect
    return request.app.state.templates.TemplateResponse(
        request,
        "settings/profile.html",
        {
            "title": "Profile — Governor Audit",
            "active_tab": "profile",
            "config": config,
            "principal": _active_principal(),
            "adc": _adc_status(config),
        },
    )


# ─── Appearance ──────────────────────────────────────────────────────


@router.get("/admin/settings/appearance", response_class=HTMLResponse)
def settings_appearance(request: Request):
    config, redirect = _load_config_or_redirect()
    if redirect:
        return redirect
    return request.app.state.templates.TemplateResponse(
        request,
        "settings/appearance.html",
        {
            "title": "Appearance — Governor Audit",
            "active_tab": "appearance",
            "config": config,
        },
    )


# ─── AI / LLM ─────────────────────────────────────────────────────────


@router.get("/admin/settings/llm", response_class=HTMLResponse)
def settings_llm(request: Request, saved: int | None = None):
    config, redirect = _load_config_or_redirect()
    if redirect:
        return redirect
    return request.app.state.templates.TemplateResponse(
        request,
        "settings/llm.html",
        {
            "title": "AI / LLM — Governor Audit",
            "active_tab": "llm",
            "config": config,
            "llm_providers": _LLM_PROVIDERS,
            "api_key_set": _llm_api_key_set(config, config.llm.provider),
            "api_key_masked": _mask_api_key(config.llm.api_key),
            "saved": bool(saved),
            "errors": {},
        },
    )


@router.post("/admin/settings/llm", response_class=HTMLResponse)
def settings_llm_submit(
    request: Request,
    llm_enabled: Annotated[bool, Form()] = False,
    llm_provider: Annotated[str, Form()] = "gemini",
    llm_api_key: Annotated[str, Form()] = "",
    llm_model: Annotated[str, Form()] = "gemini-3.1-pro-preview",
    llm_routing_model: Annotated[str, Form()] = "gemini-3.1-pro-preview",
    llm_temperature: Annotated[float, Form()] = 0.2,
    llm_max_tokens: Annotated[int, Form()] = 4096,
    llm_timeout_ms: Annotated[int, Form()] = 60_000,
    llm_top_n: Annotated[int, Form()] = 20,
    llm_min_confidence: Annotated[float, Form()] = 0.7,
):
    config, redirect = _load_config_or_redirect()
    if redirect:
        return redirect

    # Blank api_key field → preserve the existing persisted value.
    new_key = (llm_api_key or "").strip() or config.llm.api_key

    try:
        new_llm = LLMConfig(
            enabled=llm_enabled,
            provider=llm_provider.strip(),
            api_key=new_key,
            model=llm_model.strip(),
            routing_model=llm_routing_model.strip(),
            temperature=llm_temperature,
            max_tokens=llm_max_tokens,
            timeout_ms=llm_timeout_ms,
            top_n=llm_top_n,
            min_confidence=llm_min_confidence,
        )
    except ValidationError as exc:
        return request.app.state.templates.TemplateResponse(
            request,
            "settings/llm.html",
            {
                "title": "AI / LLM — Governor Audit",
                "active_tab": "llm",
                "config": config,
                "llm_providers": _LLM_PROVIDERS,
                "api_key_set": _llm_api_key_set(config, llm_provider),
                "api_key_masked": _mask_api_key(config.llm.api_key),
                "saved": False,
                "errors": {"_general": str(exc)},
            },
        )

    config = config.model_copy(update={"llm": new_llm})
    save_config(config)
    logger.info(
        "settings: llm provider=%s model=%s enabled=%s key_set=%s",
        new_llm.provider,
        new_llm.model,
        new_llm.enabled,
        bool(new_llm.api_key),
    )
    return RedirectResponse(url="/admin/settings/llm?saved=1", status_code=303)


# ─── Detection Rules — split into three pages ────────────────────────
#
# Issues:        cost / performance findings (slot_contention, etc.)
# Suggestions:   SQL-rewrite templates (dead_cte, select_star, etc.)
# Storage Billing: dataset-level physical-vs-logical billing toggle —
#                  placeholder for the dedicated per-dataset view.


def _rules_view(config, *, include: frozenset[str]) -> list[dict]:
    """Build the per-rule view-model, filtered to the rules listed in
    ``include``.

    Audit owns its own enable defaults — every rule is ON unless the
    user has explicitly toggled it off in
    ``config.detection_rule_overrides``. We deliberately ignore the
    cloud catalog's ``entry.enabled`` flag here because some shipped
    governor-core wheels (0.7.x) return False for rules audit always
    wants on, and that was leaking through and presenting them as
    disabled even on fresh installs.
    """
    from governor_core.opportunities.catalog import get_detection_rule_catalog

    overrides = config.detection_rule_overrides or {}
    out: list[dict] = []
    for entry in get_detection_rule_catalog():
        if entry.rule_type not in include:
            continue
        if entry.rule_type in overrides:
            is_enabled = bool(overrides[entry.rule_type])
        else:
            # Audit's own default: every rule is enabled unless the
            # user has flipped it off. Don't trust the cloud catalog's
            # ``entry.enabled`` — see docstring.
            is_enabled = True
        try:
            rule = entry.rule_class()
            display_name = rule.display_name
            description = rule.description or ""
        except Exception:  # noqa: BLE001
            display_name = entry.rule_type.replace("_", " ").title()
            description = ""
        out.append(
            {
                "rule_type": entry.rule_type,
                "display_name": display_name,
                "description": description,
                "is_enabled": is_enabled,
            }
        )
    return out


def _save_rule_overrides(config, form: FormData, *, include: frozenset[str]):
    """Update ``config.detection_rule_overrides`` from a submitted toggle
    form, only touching rules listed in ``include``. Other rules'
    overrides are left as-is so each page only governs its own slice."""
    overrides = dict(config.detection_rule_overrides or {})
    for rule_type in include:
        # Checkbox absent → user toggled it off; present → on.
        overrides[rule_type] = f"rule_{rule_type}" in form
    return config.model_copy(update={"detection_rule_overrides": overrides})


# Storage billing is its own conceptual category, not part of "issues".
_STORAGE_BILLING_RULES: frozenset[str] = frozenset({"storage_billing_optimization"})


def _issue_rule_types() -> frozenset[str]:
    """Issue rules excluding storage_billing — that lives on its own page."""
    from governor_audit.scan.categorization import ISSUE_RULE_TYPES

    return ISSUE_RULE_TYPES - _STORAGE_BILLING_RULES


def _suggestion_rule_types() -> frozenset[str]:
    from governor_audit.scan.categorization import IMPROVEMENT_RULE_TYPES

    return IMPROVEMENT_RULE_TYPES


# ─── Issues ───────────────────────────────────────────────────────────


@router.get("/admin/settings/issues", response_class=HTMLResponse)
def settings_issues(request: Request, saved: int | None = None):
    config, redirect = _load_config_or_redirect()
    if redirect:
        return redirect
    return request.app.state.templates.TemplateResponse(
        request,
        "settings/issues.html",
        {
            "title": "Issues — Governor Audit",
            "active_tab": "issues",
            "config": config,
            "rules": _rules_view(config, include=_issue_rule_types()),
            "saved": bool(saved),
            "errors": {},
        },
    )


@router.post("/admin/settings/issues", response_class=HTMLResponse)
async def settings_issues_submit(request: Request):
    config, redirect = _load_config_or_redirect()
    if redirect:
        return redirect
    form: FormData = await request.form()
    config = _save_rule_overrides(config, form, include=_issue_rule_types())
    save_config(config)
    logger.info("settings: issues overrides updated")
    return RedirectResponse(url="/admin/settings/issues?saved=1", status_code=303)


# ─── Suggestions ─────────────────────────────────────────────────────


@router.get("/admin/settings/suggestions", response_class=HTMLResponse)
def settings_suggestions(request: Request, saved: int | None = None):
    config, redirect = _load_config_or_redirect()
    if redirect:
        return redirect
    return request.app.state.templates.TemplateResponse(
        request,
        "settings/suggestions.html",
        {
            "title": "Suggestions — Governor Audit",
            "active_tab": "suggestions",
            "config": config,
            "rules": _rules_view(config, include=_suggestion_rule_types()),
            "saved": bool(saved),
            "errors": {},
        },
    )


@router.post("/admin/settings/suggestions", response_class=HTMLResponse)
async def settings_suggestions_submit(request: Request):
    config, redirect = _load_config_or_redirect()
    if redirect:
        return redirect
    form: FormData = await request.form()
    config = _save_rule_overrides(config, form, include=_suggestion_rule_types())
    save_config(config)
    logger.info("settings: suggestions overrides updated")
    return RedirectResponse(
        url="/admin/settings/suggestions?saved=1", status_code=303
    )


# ─── Storage Billing ─────────────────────────────────────────────────


@router.get("/admin/settings/storage-billing", response_class=HTMLResponse)
def settings_storage_billing(request: Request, saved: int | None = None):
    config, redirect = _load_config_or_redirect()
    if redirect:
        return redirect
    return request.app.state.templates.TemplateResponse(
        request,
        "settings/storage_billing.html",
        {
            "title": "Storage Billing — Governor Audit",
            "active_tab": "storage_billing",
            "config": config,
            "rules": _rules_view(config, include=_STORAGE_BILLING_RULES),
            "saved": bool(saved),
            "errors": {},
        },
    )


@router.post("/admin/settings/storage-billing", response_class=HTMLResponse)
async def settings_storage_billing_submit(request: Request):
    config, redirect = _load_config_or_redirect()
    if redirect:
        return redirect
    form: FormData = await request.form()
    config = _save_rule_overrides(config, form, include=_STORAGE_BILLING_RULES)
    save_config(config)
    logger.info("settings: storage-billing overrides updated")
    return RedirectResponse(
        url="/admin/settings/storage-billing?saved=1", status_code=303
    )


# ─── Backward-compat redirect ────────────────────────────────────────
# The old combined ``/admin/settings/detection-rules`` page is replaced
# by the three above. Redirect any in-flight bookmarks to Issues.


@router.get("/admin/settings/detection-rules")
def settings_detection_rules_redirect():
    return RedirectResponse(url="/admin/settings/issues", status_code=308)


__all__ = ["router"]
