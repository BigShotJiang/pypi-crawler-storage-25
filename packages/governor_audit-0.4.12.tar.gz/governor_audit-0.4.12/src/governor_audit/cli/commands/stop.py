"""``governor-audit stop`` — terminate the managed audit web server.

Reads the PID from ``~/.governor-audit/server.pid``, sends SIGTERM
(POSIX) or calls TerminateProcess via ctypes (Windows), and clears
the pidfile. If no pidfile is present, says so and exits 0.

Why the platform split: Python's ``os.kill(pid, signal.SIGTERM)`` on
Windows raises ``WinError 87`` ("parameter is incorrect") because the
Win32 implementation only accepts ``CTRL_C_EVENT`` /
``CTRL_BREAK_EVENT`` for that path. ``TerminateProcess`` is the
straight-forward "kill this PID" syscall.
"""

from __future__ import annotations

import os
import signal

import typer

from governor_audit.cli import state as _state


def _terminate_pid(pid: int) -> None:
    """Cross-platform PID termination. Raises ``ProcessLookupError``
    when the process is already gone."""
    if os.name == "nt":
        _windows_terminate(pid)
        return
    os.kill(pid, signal.SIGTERM)


def _windows_terminate(pid: int) -> None:
    """Windows-only ``TerminateProcess`` via kernel32 ctypes. No extra
    dependencies needed.

    Raises ``ProcessLookupError`` if the PID isn't reachable (already
    exited, or never existed) so the caller's POSIX-style except
    branch works on both platforms.
    """
    import ctypes
    from ctypes import wintypes

    PROCESS_TERMINATE = 0x0001

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
    kernel32.TerminateProcess.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL

    handle = kernel32.OpenProcess(PROCESS_TERMINATE, False, pid)
    if not handle:
        raise ProcessLookupError(f"No such process: {pid}")
    try:
        ok = kernel32.TerminateProcess(handle, 0)
        if not ok:
            err = ctypes.get_last_error()
            # ERROR_INVALID_PARAMETER (87) typically means the process
            # already exited between OpenProcess and TerminateProcess.
            if err in (87, 5):  # invalid parameter, access denied
                raise ProcessLookupError(f"Could not terminate {pid}: WinError {err}")
            raise OSError(err, ctypes.FormatError(err))
    finally:
        kernel32.CloseHandle(handle)


def stop_command() -> None:
    """Stop the audit web server started by ``governor-audit start``."""
    pid = _state.read_pid()
    if not pid:
        typer.echo("No server PID on file — nothing to stop.")
        return

    try:
        _terminate_pid(pid)
        typer.secho(f"Server stopped (PID {pid})", fg=typer.colors.GREEN)
    except ProcessLookupError:
        typer.echo(f"Server PID {pid} already gone; clearing pidfile.")

    _state.clear_pid()


__all__ = ["stop_command"]
