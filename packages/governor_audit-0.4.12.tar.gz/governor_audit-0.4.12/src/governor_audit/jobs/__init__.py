"""Job-detail cohort view: groups every cached execution of the same
``destination_table`` into a single page with cost trend + query-version
history + latest-version-only suggestions.

See [specs/146-audit-job-history-trend/spec.md](../../../specs/146-audit-job-history-trend/spec.md).
"""
