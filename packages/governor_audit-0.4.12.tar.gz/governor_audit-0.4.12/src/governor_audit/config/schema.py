"""Pydantic schema for ``AuditConfig`` — the single source-of-truth file
at ``~/.governor-audit/config.json``. Hand-editable; the
``governor-audit config`` command is a convenience wrapper.

See [data-model.md § AuditConfig](../../../../specs/141-production-audit/data-model.md#auditconfig-configjson)
for the field reference and validator rationale.

**v2 change**: ``manifest`` field removed (manifest no longer required).
``scan_defaults.dbt_only`` field added for the optional
``--dbt-only`` filter default.
"""

from __future__ import annotations

import re
from decimal import Decimal
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

# GCP project ID grammar per
# https://cloud.google.com/resource-manager/reference/rest/v1/projects
_GCP_PROJECT_ID_RE = re.compile(r"^[a-z][-a-z0-9]{4,28}[a-z0-9]$")
_LOOPBACK_BIND_ADDRESSES = frozenset({"127.0.0.1", "::1", "localhost"})

CURRENT_SCHEMA_VERSION = 5  # bumped from 4 (v5 force-enables EVERY rule + clears stale False overrides)
DEFAULT_LOOKBACK_DAYS = 1
DEFAULT_PORT = 8765


class ScanDefaults(BaseModel):
    # `extra="ignore"` so existing configs with the now-deprecated
    # `max_scan_bytes` field load cleanly (the field is silently dropped
    # on next save).
    model_config = ConfigDict(strict=False, extra="ignore")

    lookback_days: int = Field(
        default=DEFAULT_LOOKBACK_DAYS, ge=1, le=365,
        description="Default --days for scan when not specified.",
    )
    min_solution_cost_usd: Decimal = Field(
        default=Decimal("0.00"), ge=Decimal("0"),
        description="Filter findings below this current-cost USD.",
    )
    dbt_only: bool = Field(
        default=False,
        description=(
            "Default value of --dbt-only for scan. When True, scans add "
            "a STARTS_WITH(query, '/* {\"app\": \"dbt\"') predicate."
        ),
    )


class WebUIConfig(BaseModel):
    model_config = ConfigDict(strict=False)

    port: int = Field(default=DEFAULT_PORT, ge=1024, le=65535)
    bind_address: str = Field(default="127.0.0.1")

    @field_validator("bind_address")
    @classmethod
    def _validate_loopback_only(cls, v: str) -> str:
        if v not in _LOOPBACK_BIND_ADDRESSES:
            raise ValueError(
                f"bind_address must be one of {sorted(_LOOPBACK_BIND_ADDRESSES)}; "
                f"got {v!r}. Non-loopback binds are rejected as a security policy."
            )
        return v


class LLMConfig(BaseModel):
    """LLM-driven best-practices review settings (planned for v0.0.2 +).

    Field shape mirrors ``governor_web/.../settings/llm.html`` so the
    audit settings page can be a near-1:1 vendoring of the cloud's
    template. The actual review code lands in a follow-up spec; the
    settings page reads + writes this struct now so the user's choices
    survive the implementation cut-over.
    """

    model_config = ConfigDict(strict=False)

    enabled: bool = Field(default=False)
    provider: str = Field(default="gemini")
    api_key: str | None = Field(
        default=None,
        description=(
            "Provider API key persisted to ~/.governor-audit/config.json. "
            "When set, takes precedence over the GEMINI_API_KEY env var. "
            "File mode is 0600."
        ),
    )
    model: str = Field(
        default="gemini-3.1-pro-preview",
        description="Solution / review model — mirrors governor-web `llm_model`.",
    )
    routing_model: str = Field(
        default="gemini-3.1-pro-preview",
        description="Lighter model for classification / routing.",
    )
    temperature: float = Field(default=0.2, ge=0.0, le=2.0)
    max_tokens: int = Field(default=4096, ge=256, le=65536)
    timeout_ms: int = Field(default=60_000, ge=5000, le=600_000)
    top_n: int = Field(default=20, ge=1, le=200)
    min_confidence: float = Field(default=0.7, ge=0.0, le=1.0)


class AuditConfig(BaseModel):
    """Top-level config file shape for ``~/.governor-audit/config.json``."""

    model_config = ConfigDict(strict=False)

    schema_version: int = Field(default=CURRENT_SCHEMA_VERSION)
    gcp_project_id: str
    bigquery_region: str
    scan_defaults: ScanDefaults = Field(default_factory=ScanDefaults)
    detection_rule_overrides: dict[str, bool] = Field(default_factory=dict)
    web_ui: WebUIConfig = Field(default_factory=WebUIConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)

    @field_validator("schema_version")
    @classmethod
    def _validate_schema_version(cls, v: int) -> int:
        if v > CURRENT_SCHEMA_VERSION:
            raise ValueError(
                f"config.json was written by a newer governor-audit "
                f"(schema_version={v}); upgrade governor-audit to read it. "
                f"This binary supports up to schema_version={CURRENT_SCHEMA_VERSION}."
            )
        return v

    @field_validator("gcp_project_id")
    @classmethod
    def _validate_project_id(cls, v: str) -> str:
        v = v.strip()
        if not _GCP_PROJECT_ID_RE.match(v):
            raise ValueError(
                f"gcp_project_id must match GCP project ID grammar "
                f"(^[a-z][-a-z0-9]{{4,28}}[a-z0-9]$); got {v!r}"
            )
        return v

    @field_validator("bigquery_region")
    @classmethod
    def _normalise_region(cls, v: str) -> str:
        v = v.strip().lower()
        if not v:
            raise ValueError("bigquery_region cannot be empty")
        return v


def stable_config_id(config: AuditConfig) -> str:
    """Derive a stable config_id from (project, region) for use as
    ``Opportunity.config_id``. Re-scanning the same project + region
    produces stable IDs across scans.
    """
    import hashlib

    payload = "|".join([config.gcp_project_id, config.bigquery_region])
    return hashlib.sha256(payload.encode()).hexdigest()[:36]


def migrate_v1_to_v2(payload: dict) -> dict:
    """Drop deprecated v1 fields (``manifest``) and bump schema_version."""
    if payload.get("schema_version", 1) >= 2:
        return payload
    payload = dict(payload)
    payload.pop("manifest", None)
    payload["schema_version"] = 2
    return payload


def migrate_v2_to_v3(payload: dict) -> dict:
    """Reset ``detection_rule_overrides`` so catalog defaults take effect.

    Earlier audit releases shipped before the curated default-enabled set
    landed (PR #288 — "enable 6 templated rules by default"). Configs from
    those builds carry stale per-rule choices that mask the new defaults.
    Wiping the dict on upgrade is the simplest way to surface the new
    catalog state without asking the user to reset by hand. They can
    re-toggle whatever they want afterwards.
    """
    if payload.get("schema_version", 1) >= 3:
        return payload
    payload = dict(payload)
    payload["detection_rule_overrides"] = {}
    payload["schema_version"] = 3
    return payload


def migrate_v3_to_v4(payload: dict) -> dict:
    """Force-enable every SQL-rewrite suggestion rule on upgrade.

    Audit's listing now surfaces an Opportunity row for each suggestion
    rule that fires (not just for the five issue rules), so users who
    upgraded from a build that disabled some suggestions would see a
    less-useful workspace until they re-toggled each one by hand. This
    migration writes ``detection_rule_overrides[rule_type] = True`` for
    every rule in ``IMPROVEMENT_RULE_TYPES`` so the next scan picks them
    all up. Issue rule overrides and any other persisted state are left
    intact — the user's previous choices for issues stick.
    """
    if payload.get("schema_version", 1) >= 4:
        return payload
    # Late import to avoid a top-level cycle (categorization → schema).
    from governor_audit.scan.categorization import IMPROVEMENT_RULE_TYPES

    payload = dict(payload)
    overrides = dict(payload.get("detection_rule_overrides") or {})
    for rule_type in IMPROVEMENT_RULE_TYPES:
        overrides[rule_type] = True
    payload["detection_rule_overrides"] = overrides
    payload["schema_version"] = 4
    return payload


def migrate_v4_to_v5(payload: dict) -> dict:
    """Reset detection_rule_overrides so audit's "everything on by
    default" is what the user sees — wiping any stale False entries
    persisted by older builds where the cloud catalog leaked through.

    Required because audit now ignores the cloud catalog's
    ``entry.enabled`` flag entirely (some governor-core 0.7.x wheels
    return False for rules audit wants live). Anyone whose config
    carried explicit False overrides from a previous toggle, or empty
    overrides plus a False cloud default, was seeing entire rule
    classes silently suppressed even after the v3→v4 migration. This
    migration nukes the dict — everything goes back to audit's default
    of ``enabled``. The user can re-toggle individual rules afterwards.
    """
    if payload.get("schema_version", 1) >= 5:
        return payload
    payload = dict(payload)
    payload["detection_rule_overrides"] = {}
    payload["schema_version"] = 5
    return payload


__all__: list[Any] = [
    "AuditConfig",
    "LLMConfig",
    "ScanDefaults",
    "WebUIConfig",
    "CURRENT_SCHEMA_VERSION",
    "DEFAULT_LOOKBACK_DAYS",
    "DEFAULT_PORT",
    "stable_config_id",
    "migrate_v1_to_v2",
    "migrate_v2_to_v3",
    "migrate_v3_to_v4",
    "migrate_v4_to_v5",
]
