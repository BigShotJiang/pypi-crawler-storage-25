# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), 
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.5.2] - 2026-04-17 23:50:09

### Changed

- Versioning workflow now mints a GitHub App token instead of using the expired POLICYENGINE_GITHUB PAT.

## [0.5.1] - 2025-08-22 10:20:56

### Fixed

- Logic to add calculated variables (not input variables) to SingleYearDataset when loading from a microsim.

## [0.5.0] - 2025-08-20 08:27:42

### Added

- Logic to create estimate matrix for calibration from a database.
- Conversion functions between dataset classes to enable stacking datasets.
- Logic to calibrate for multiple geographic levels with two different routines.
- Calibration documentation.

## [0.4.0] - 2025-08-07 09:28:18

### Added

- Key normalisation functionality.

## [0.3.0] - 2025-08-06 14:12:21

### Changed

- Added logic to rescale calibration targets from a database.

## [0.2.0] - 2025-07-28 16:55:16

### Changed

- Added Single and Multi Year Dataset classes.
- Added data download and upload functionality.
- Make .sh files executable.

## [0.1.0] - 2025-07-22 00:00:00

### Added

- Initialized project.



[0.5.2]: https://github.com/PolicyEngine/policyengine_data/compare/0.5.1...0.5.2
[0.5.1]: https://github.com/PolicyEngine/policyengine_data/compare/0.5.0...0.5.1
[0.5.0]: https://github.com/PolicyEngine/policyengine_data/compare/0.4.0...0.5.0
[0.4.0]: https://github.com/PolicyEngine/policyengine_data/compare/0.3.0...0.4.0
[0.3.0]: https://github.com/PolicyEngine/policyengine_data/compare/0.2.0...0.3.0
[0.2.0]: https://github.com/PolicyEngine/policyengine_data/compare/0.1.0...0.2.0
