"""Public API for the sigmorphon package."""

from .dataset import MorphBatch, MorphDataset, MorphRow, load_tsv, load_tsv_pattern
from .download import DATASETS, download_all, get_available_languages, merge_tsv

__all__: list[str] = [
    "DATASETS",
    "MorphBatch",
    "MorphDataset",
    "MorphRow",
    "download_all",
    "get_available_languages",
    "load_tsv",
    "load_tsv_pattern",
    "merge_tsv",
]

__version__: str = "2.1.0"
