"""livechord-beat-refiner — bidirectional Transformer beat / downbeat /
chord-boundary refiner.

Public API
----------
::

    from livechord_beat_refiner import refine

    out = refine(
        audio_path="song.flac",
        beats=[0.0, 0.5, 1.0, ...],          # initial beat times in seconds
        downbeats=[0.0, 2.0, 4.0, ...],      # initial downbeat times
    )
    print(out["refined_beats"], out["refined_downbeats"], out["applied"])

The model checkpoint is fetched from Hugging Face Hub
(``livechord-music/livechord-beat-refiner``) on first call. Pass
``checkpoint_path`` to override with a local file.

See ``examples/example_usage.py`` and the project README for end-to-end
usage with beat_this or madmom as the upstream beat tracker.
"""

from .infer import refine
from .model import MODEL_VERSION, BeatRefiner, build_default_model
from .features import (
    FEATURE_VERSION,
    FRAMES_PER_SEC,
    N_AUDIO_CHANNELS,
    N_MODEL_CHANNELS,
    extract_features,
    build_initial_grid_channels,
)

__version__ = "0.1.0"
__all__ = [
    "refine",
    "MODEL_VERSION",
    "BeatRefiner",
    "build_default_model",
    "FEATURE_VERSION",
    "FRAMES_PER_SEC",
    "N_AUDIO_CHANNELS",
    "N_MODEL_CHANNELS",
    "extract_features",
    "build_initial_grid_channels",
    "__version__",
]
