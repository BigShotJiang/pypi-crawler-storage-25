from django.test import TestCase, override_settings
from rest_framework.test import APIRequestFactory

from blog.views import SyncConfig, build_media_description, get_content_mime_type


class SyncConfigTests(TestCase):
    def setUp(self):
        self.factory = APIRequestFactory()

    def test_sync_config_contains_compatibility_metadata(self):
        request = self.factory.get("/blog_api/sync_config/")
        response = SyncConfig.as_view()(request)

        self.assertEqual(response.status_code, 200)
        self.assertIn("api_contract_version", response.data)
        self.assertIn("supported_frontend_versions", response.data)
        self.assertIn("upload_default_public", response.data)
        self.assertEqual(response.data["images_endpoint"], "")
        self.assertTrue(response.data["upload_default_public"])


class MediaSupportTests(TestCase):
    def setUp(self):
        self.factory = APIRequestFactory()

    def test_get_content_mime_type_reads_additional_metadata(self):
        content = {
            "additional": [
                {"key": "foo", "value": "bar"},
                {"key": "mimeType", "value": "audio/mpeg"},
            ]
        }

        self.assertEqual(get_content_mime_type(content), "audio/mpeg")

    def test_build_media_description_uses_audio_tag(self):
        desc = build_media_description("https://example.com/a.mp3", "audio/mpeg")
        self.assertIn("<audio", desc)

    def test_build_media_description_uses_video_tag(self):
        desc = build_media_description("https://example.com/v.mp4", "video/mp4")
        self.assertIn("<video", desc)

    @override_settings(
        TCB_BLOG_SETTINGS={
            "API_CONTRACT_VERSION": "2.0.0",
            "SUPPORTED_FRONTEND_VERSIONS": ">=0.31.0 <0.32.0",
            "IMAGES_ENDPOINT": "blog_api/uploads/create_image/",
        },
        UPLOAD_DEFAULT_PUBLIC=False,
    )
    def test_sync_config_uses_configured_compatibility_metadata(self):
        request = self.factory.get("/blog_api/sync_config/")
        response = SyncConfig.as_view()(request)

        self.assertEqual(response.data["api_contract_version"], "2.0.0")
        self.assertEqual(
            response.data["supported_frontend_versions"], ">=0.31.0 <0.32.0"
        )
        self.assertEqual(
            response.data["images_endpoint"], "blog_api/uploads/create_image/"
        )
        self.assertFalse(response.data["upload_default_public"])
