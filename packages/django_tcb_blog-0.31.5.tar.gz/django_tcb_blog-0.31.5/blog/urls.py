from django.urls import include, path
from django.apps import apps
import importlib.util
from rest_framework.routers import DefaultRouter

from blog.views import ( EntryViewSet, ListUser, CommentViewSet, SyncConfig, TagViewSet, ViewViewSet,
                        InteractionViewSet, VisitorProfileViewSet, EntriesFeed, AdminEntryViewSet, AdminCommentViewSet )

router = DefaultRouter()

router.register(r'entries', EntryViewSet, basename='entries')
router.register(r'admin/entries', AdminEntryViewSet, basename='admin_entries')

router.register(r'comments', CommentViewSet, basename='comments')
router.register(r'admin/comments', AdminCommentViewSet, basename='admin_comments')

router.register(r'tags', TagViewSet, basename='tags')
router.register(r'views', ViewViewSet, basename='views')
router.register(r'interactions', InteractionViewSet, basename='interactions')
router.register(r'visitor_profiles', VisitorProfileViewSet, basename='visitor_profiles')

urlpatterns = [
    path('me/', ListUser.as_view()),
    path('sync_config/', SyncConfig.as_view()),
    path('rss/', EntriesFeed()),
] + router.urls

if importlib.util.find_spec("upload") is not None and apps.is_installed("upload"):
    urlpatterns += [
        path('', include('upload.urls')),
    ]
