==========================
TheCodeBlogs Blog Backend
==========================

Blogging made easy

Settings
-----------

These should go into your settings.py file.

.. code-block:: python

    TCB_BLOG_SETTINGS = {
        'RSS_FEED_TITLE': 'Title of the blog',
        'RSS_FEED_LINK': '/blog/',
        'RSS_FEED_ITEM_DESC_TEMPLATE': 'feed/entries.html',
        'API_CONTRACT_VERSION': '1.0.0',
        'SUPPORTED_FRONTEND_VERSIONS': '>=0.31.0 <0.32.0'
    }

If you enable ``django-upload``, you can enforce backend upload policy in ``settings.py``:

.. code-block:: python

    UPLOAD_ALLOWED_MIME_TYPES = [
        # Images
        'image/jpeg', 'image/png', 'image/gif',
        # Video
        'video/mp4', 'video/webm', 'video/ogg', 'video/quicktime',
        'video/x-msvideo', 'video/x-ms-wmv', 'video/mpeg',
        'video/3gpp', 'video/3gpp2', 'video/x-matroska', 'video/mp2t',
        # Audio
        'audio/mpeg', 'audio/mp4', 'audio/x-m4a', 'audio/aac',
        'audio/ogg', 'audio/wav', 'audio/x-wav', 'audio/webm',
        'audio/flac', 'audio/x-flac', 'audio/3gpp', 'audio/3gpp2',
        'audio/aiff', 'audio/x-aiff',
    ]

    UPLOAD_ALLOWED_EXTENSIONS = [
        'jpg', 'jpeg', 'png', 'gif',
        'mp4', 'webm', 'ogv', 'mov', 'avi', 'wmv', 'mpeg', 'mpg', 'mkv', 'ts',
        'mp3', 'm4a', 'aac', 'ogg', 'wav', 'flac', 'aif', 'aiff',
    ]

    # Default visibility when clients do not send the public flag
    UPLOAD_DEFAULT_PUBLIC = True


Quick start
-----------

1. Add "blog" to your INSTALLED_APPS setting like this

.. code-block:: python

   INSTALLED_APPS = [
   ...
   'blog',
   ]

2. (Optional) Install django-upload from git and add "upload" to INSTALLED_APPS to enable media uploads

.. code-block:: bash

   pip install "django-upload @ git+https://git.jamesonnetworks.com/JamesonNetworks/django-upload.git@main"

.. code-block:: python

   INSTALLED_APPS = [
   ...
   'blog',
   'upload',
   ]

3. Include the polls URLconf in your project urls.py like this

.. code-block:: python

   path('blog_api/', include('blog.urls')),

4. Setup a module named 'backend'

5. Using celery.py.sample as a guide, setup celery do that tasks will work

6. Run ``python manage.py migrate`` to create the blog models.

7. Start the development server and visit http://127.0.0.1:8000/admin/
     to create a poll (you'll need the Admin app enabled).

8. Visit http://127.0.0.1:8000/blog_api/ to see something.


Running tests locally
---------------------

The repository includes a standalone pytest configuration.

1. Install test dependencies:

.. code-block:: bash

   pip install pytest pytest-django

2. Run tests from the repository root:

.. code-block:: bash

   pytest -q
