from typing import Generic
from .mixins.filter import RangeFilters
from .mixins.identity import IdentifierMixin, IdentifierT
from .mixins.parameter import (
    OrdinalT,
    Ordinal,
    MandatorySimpleDataStatusesMixin,
    Search,
    UseCache,
)
from .mixins.sort import SortColumns
from .operation.action.status import StatusUpdateOperationAction
from .pagination import BaseFlexiblePagination, BaseStrictPagination


class ReadSingleParameter(
    UseCache,
    MandatorySimpleDataStatusesMixin,
    IdentifierMixin[IdentifierT],
    Generic[IdentifierT],
):
    pass


class ReadOrdinalParameter(
    UseCache,
    MandatorySimpleDataStatusesMixin,
    Ordinal[OrdinalT],
    Generic[OrdinalT],
):
    pass


class CountParameter(
    UseCache,
    Search,
    MandatorySimpleDataStatusesMixin,
    RangeFilters,
):
    pass


class ReadUnpaginatedMultipleParameter(
    BaseFlexiblePagination,
    SortColumns,
    CountParameter,
):
    pass


class ReadPaginatedMultipleParameter(
    BaseStrictPagination,
    SortColumns,
    CountParameter,
):
    pass


class StatusUpdateParameter(
    StatusUpdateOperationAction,
    IdentifierMixin[IdentifierT],
    Generic[IdentifierT],
):
    pass


class DeleteSingleParameter(
    IdentifierMixin[IdentifierT],
    Generic[IdentifierT],
):
    pass
