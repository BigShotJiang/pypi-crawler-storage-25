from pydantic import BaseModel, Field
from typing import (
    Annotated,
    Any,
    Generic,
    Literal,
    Type,
    TypeVar,
    overload,
)
from nexo.types.boolean import BoolT
from nexo.types.dict import StrToAnyDict
from nexo.types.misc import IntOrStr, StrOrStrEnumT
from nexo.types.string import OptStr, OptListOfDoubleStrs
from .data import DataPair, DataT, HealthData, PingData, CheckData, CountData
from .error.descriptor import (
    ErrorDescriptor,
    BadRequestErrorDescriptor,
    UnauthorizedErrorDescriptor,
    ForbiddenErrorDescriptor,
    NotFoundErrorDescriptor,
    MethodNotAllowedErrorDescriptor,
    ConflictErrorDescriptor,
    UnprocessableEntityErrorDescriptor,
    TooManyRequestsErrorDescriptor,
    InternalServerErrorDescriptor,
    NotImplementedErrorDescriptor,
    BadGatewayErrorDescriptor,
    ServiceUnavailableErrorDescriptor,
)
from .error.enums import ErrorCode
from .metadata import MetadataT
from .mixins.general import Success, Descriptor
from .pagination import OptPaginationT, PaginationT
from .payload import (
    Payload,
    NoDataPayload,
    SingleDataPayload,
    SingleDataPairPayload,
    MultipleDataPayload,
    MultipleDataPairPayload,
)
from .success.descriptor import (
    SuccessDescriptor,
    AnyDataSuccessDescriptor,
    NoDataSuccessDescriptor,
    SingleDataSuccessDescriptor,
    SingleDataPairSuccessDescriptor,
    MultipleDataSuccessDescriptor,
    MultipleDataPairSuccessDescriptor,
)
from .success.enums import SuccessCode


class ResponseContext(BaseModel):
    status_code: Annotated[int, Field(..., description="Status code")]
    media_type: Annotated[OptStr, Field(None, description="Media type (Optional)")] = (
        None
    )
    headers: Annotated[
        OptListOfDoubleStrs, Field(None, description="Response's headers")
    ] = None


OptResponseContext = ResponseContext | None
OptResponseContextT = TypeVar("OptResponseContextT", bound=OptResponseContext)


class ResponseContextMixin(BaseModel, Generic[OptResponseContextT]):
    response_context: OptResponseContextT = Field(..., description="Response's context")


class Response(
    Payload[DataT, OptPaginationT, MetadataT],
    Descriptor[StrOrStrEnumT],
    Success[BoolT],
    BaseModel,
    Generic[BoolT, StrOrStrEnumT, DataT, OptPaginationT, MetadataT],
):
    pass


OptResponse = Response | None


# Error Response
class ErrorResponse(
    NoDataPayload[None],
    ErrorDescriptor,
    Response[Literal[False], ErrorCode, None, None, None],
):
    success: Literal[False] = False
    data: None = None
    pagination: None = None
    metadata: None = None
    other: Any = "Please try again later or contact administrator"


OptErrorResponse = ErrorResponse | None


class BadRequestResponse(
    BadRequestErrorDescriptor,
    ErrorResponse,
):
    pass


OptBadRequestResponse = BadRequestResponse | None


class UnauthorizedResponse(
    UnauthorizedErrorDescriptor,
    ErrorResponse,
):
    pass


OptUnauthorizedResponse = UnauthorizedResponse | None


class ForbiddenResponse(
    ForbiddenErrorDescriptor,
    ErrorResponse,
):
    pass


OptForbiddenResponse = ForbiddenResponse | None


class NotFoundResponse(
    NotFoundErrorDescriptor,
    ErrorResponse,
):
    pass


OptNotFoundResponse = NotFoundResponse | None


class MethodNotAllowedResponse(
    MethodNotAllowedErrorDescriptor,
    ErrorResponse,
):
    pass


OptMethodNotAllowedResponse = MethodNotAllowedResponse | None


class ConflictResponse(
    ConflictErrorDescriptor,
    ErrorResponse,
):
    pass


OptConflictResponse = ConflictResponse | None


class UnprocessableEntityResponse(
    UnprocessableEntityErrorDescriptor,
    ErrorResponse,
):
    pass


OptUnprocessableEntityResponse = UnprocessableEntityResponse | None


class TooManyRequestsResponse(
    TooManyRequestsErrorDescriptor,
    ErrorResponse,
):
    pass


OptTooManyRequestsResponse = TooManyRequestsResponse | None


class InternalServerErrorResponse(
    InternalServerErrorDescriptor,
    ErrorResponse,
):
    pass


OptInternalServerErrorResponse = InternalServerErrorResponse | None


class NotImplementedResponse(
    NotImplementedErrorDescriptor,
    ErrorResponse,
):
    pass


OptNotImplementedResponse = NotImplementedResponse | None


class BadGatewayResponse(
    BadGatewayErrorDescriptor,
    ErrorResponse,
):
    pass


OptBadGatewayResponse = BadGatewayResponse | None


class ServiceUnavailableResponse(
    ServiceUnavailableErrorDescriptor,
    ErrorResponse,
):
    pass


OptServiceUnavailableResponse = ServiceUnavailableResponse | None


AnyErrorResponseType = (
    Type[BadRequestResponse]
    | Type[UnauthorizedResponse]
    | Type[ForbiddenResponse]
    | Type[NotFoundResponse]
    | Type[MethodNotAllowedResponse]
    | Type[ConflictResponse]
    | Type[UnprocessableEntityResponse]
    | Type[TooManyRequestsResponse]
    | Type[InternalServerErrorResponse]
    | Type[NotImplementedResponse]
    | Type[BadGatewayResponse]
    | Type[ServiceUnavailableResponse]
)
AnyErrorResponse = (
    BadRequestResponse
    | UnauthorizedResponse
    | ForbiddenResponse
    | NotFoundResponse
    | MethodNotAllowedResponse
    | ConflictResponse
    | UnprocessableEntityResponse
    | TooManyRequestsResponse
    | InternalServerErrorResponse
    | NotImplementedResponse
    | BadGatewayResponse
    | ServiceUnavailableResponse
)
ErrorResponseT = TypeVar("ErrorResponseT", bound=AnyErrorResponse)
OptAnyErrorResponse = AnyErrorResponse | None
OptErrorResponseT = TypeVar("OptErrorResponseT", bound=OptAnyErrorResponse)


class ErrorResponseFactory:
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.BAD_REQUEST, 400],
        /,
    ) -> Type[BadRequestResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.UNAUTHORIZED, 401],
        /,
    ) -> Type[UnauthorizedResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.FORBIDDEN, 403],
        /,
    ) -> Type[ForbiddenResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.NOT_FOUND, 404],
        /,
    ) -> Type[NotFoundResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.METHOD_NOT_ALLOWED, 405],
        /,
    ) -> Type[MethodNotAllowedResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.CONFLICT, 409],
        /,
    ) -> Type[ConflictResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.UNPROCESSABLE_ENTITY, 422],
        /,
    ) -> Type[UnprocessableEntityResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.TOO_MANY_REQUESTS, 429],
        /,
    ) -> Type[TooManyRequestsResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.INTERNAL_SERVER_ERROR, 500],
        /,
    ) -> Type[InternalServerErrorResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.NOT_IMPLEMENTED, 501],
        /,
    ) -> Type[NotImplementedResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.BAD_GATEWAY, 502],
        /,
    ) -> Type[BadGatewayResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.SERVICE_UNAVAILABLE, 503],
        /,
    ) -> Type[ServiceUnavailableResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: ErrorCode | int,
        /,
    ) -> AnyErrorResponseType: ...
    @staticmethod
    def cls_from_code(
        code: ErrorCode | int,
        /,
    ) -> AnyErrorResponseType:
        if code is ErrorCode.BAD_REQUEST or code == 400:
            return BadRequestResponse
        elif code is ErrorCode.UNAUTHORIZED or code == 401:
            return UnauthorizedResponse
        elif code is ErrorCode.FORBIDDEN or code == 403:
            return ForbiddenResponse
        elif code is ErrorCode.NOT_FOUND or code == 404:
            return NotFoundResponse
        elif code is ErrorCode.METHOD_NOT_ALLOWED or code == 405:
            return MethodNotAllowedResponse
        elif code is ErrorCode.CONFLICT or code == 409:
            return ConflictResponse
        elif code is ErrorCode.UNPROCESSABLE_ENTITY or code == 422:
            return UnprocessableEntityResponse
        elif code is ErrorCode.TOO_MANY_REQUESTS or code == 429:
            return TooManyRequestsResponse
        elif code is ErrorCode.INTERNAL_SERVER_ERROR or code == 500:
            return InternalServerErrorResponse
        elif code is ErrorCode.NOT_IMPLEMENTED or code == 501:
            return NotImplementedResponse
        elif code is ErrorCode.BAD_GATEWAY or code == 502:
            return BadGatewayResponse
        elif code is ErrorCode.SERVICE_UNAVAILABLE or code == 503:
            return ServiceUnavailableResponse
        raise ValueError(f"Unable to determine error response class for code: {code}")

    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.BAD_REQUEST, 400],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> BadRequestResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.UNAUTHORIZED, 401],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> UnauthorizedResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.FORBIDDEN, 403],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> ForbiddenResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.NOT_FOUND, 404],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> NotFoundResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.METHOD_NOT_ALLOWED, 405],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> MethodNotAllowedResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.CONFLICT, 409],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> ConflictResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.UNPROCESSABLE_ENTITY, 422],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> UnprocessableEntityResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.TOO_MANY_REQUESTS, 429],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> TooManyRequestsResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.INTERNAL_SERVER_ERROR, 500],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> InternalServerErrorResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.NOT_IMPLEMENTED, 501],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> NotImplementedResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.BAD_GATEWAY, 502],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> BadGatewayResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.SERVICE_UNAVAILABLE, 503],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> ServiceUnavailableResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: ErrorCode | int,
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> AnyErrorResponse: ...
    @staticmethod
    def from_code(
        code: ErrorCode | int,
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> AnyErrorResponse:
        obj = {}
        if message is not None:
            obj["message"] = message
        if description is not None:
            obj["description"] = description
        if other is not None:
            obj["other"] = other
        return ErrorResponseFactory.cls_from_code(code).model_validate(obj)


OTHER_RESPONSES: dict[
    IntOrStr,
    StrToAnyDict,
] = {
    400: {
        "description": "Bad Request Response",
        "model": BadRequestResponse,
    },
    401: {
        "description": "Unauthorized Response",
        "model": UnauthorizedResponse,
    },
    403: {
        "description": "Forbidden Response",
        "model": ForbiddenResponse,
    },
    404: {
        "description": "Not Found Response",
        "model": NotFoundResponse,
    },
    405: {
        "description": "Method Not Allowed Response",
        "model": MethodNotAllowedResponse,
    },
    409: {
        "description": "Conflict Response",
        "model": ConflictResponse,
    },
    422: {
        "description": "Unprocessable Entity Response",
        "model": UnprocessableEntityResponse,
    },
    429: {
        "description": "Too Many Requests Response",
        "model": TooManyRequestsResponse,
    },
    500: {
        "description": "Internal Server Error Response",
        "model": InternalServerErrorResponse,
    },
    501: {
        "description": "Not Implemented Response",
        "model": NotImplementedResponse,
    },
    502: {
        "description": "Bad Gateway Response",
        "model": BadGatewayResponse,
    },
    503: {
        "description": "Service Unavailable Response",
        "model": ServiceUnavailableResponse,
    },
}


class SuccessResponse(
    SuccessDescriptor,
    Response[Literal[True], SuccessCode, DataT, OptPaginationT, MetadataT],
    Generic[DataT, OptPaginationT, MetadataT],
):
    success: Literal[True] = True


class AnyDataResponse(
    AnyDataSuccessDescriptor,
    SuccessResponse[DataT, OptPaginationT, MetadataT],
    Generic[DataT, OptPaginationT, MetadataT],
):
    pass


class NoDataResponse(
    NoDataPayload[MetadataT],
    NoDataSuccessDescriptor,
    SuccessResponse[None, None, MetadataT],
    Generic[MetadataT],
):
    data: None = None
    pagination: None = None

    @classmethod
    def new(
        cls,
        *,
        message: OptStr = None,
        description: OptStr = None,
        metadata: MetadataT = None,
        other: Any = None,
    ) -> "NoDataResponse[MetadataT]":
        descriptor = NoDataSuccessDescriptor()
        return cls(
            message=message if message is not None else descriptor.message,
            description=(
                description if description is not None else descriptor.description
            ),
            metadata=metadata,
            other=other,
        )


class SingleDataResponse(
    SingleDataPayload[DataT, MetadataT],
    SingleDataSuccessDescriptor,
    SuccessResponse[DataT, None, MetadataT],
    Generic[DataT, MetadataT],
):
    pagination: None = None

    @classmethod
    def new(
        cls,
        *,
        message: OptStr = None,
        description: OptStr = None,
        data: DataT,
        metadata: MetadataT = None,
        other: Any = None,
    ) -> "SingleDataResponse[DataT, MetadataT]":
        descriptor = SingleDataSuccessDescriptor()
        return cls(
            message=message if message is not None else descriptor.message,
            description=(
                description if description is not None else descriptor.description
            ),
            data=data,
            metadata=metadata,
            other=other,
        )


class HealthResponse(SingleDataResponse[HealthData, None]):
    data: Annotated[
        HealthData, Field(HealthData(), description="Health response's data")
    ] = HealthData()
    metadata: Annotated[None, Field(None, description="Health response's metadata")] = (
        None
    )


class PingResponse(SingleDataResponse[PingData, None]):
    data: Annotated[PingData, Field(PingData(), description="Ping response's data")] = (
        PingData()
    )
    metadata: Annotated[None, Field(None, description="Ping response's metadata")] = (
        None
    )


class CheckDataResponse(SingleDataResponse[CheckData, MetadataT], Generic[MetadataT]):
    pass


class CountDataResponse(SingleDataResponse[CountData, MetadataT], Generic[MetadataT]):
    pass


class SingleDataPairResponse(
    SingleDataPairPayload[DataT, MetadataT],
    SingleDataPairSuccessDescriptor,
    SuccessResponse[DataPair[DataT, DataT], None, MetadataT],
    Generic[DataT, MetadataT],
):
    pagination: None = None

    @classmethod
    def new(
        cls,
        *,
        message: OptStr = None,
        description: OptStr = None,
        old_data: DataT,
        new_data: DataT,
        metadata: MetadataT = None,
        other: Any = None,
    ) -> "SingleDataPairResponse[DataT, MetadataT]":
        descriptor = SingleDataPairSuccessDescriptor()
        return cls(
            message=message if message is not None else descriptor.message,
            description=(
                description if description is not None else descriptor.description
            ),
            data=DataPair[DataT, DataT](
                old=old_data,
                new=new_data,
            ),
            metadata=metadata,
            other=other,
        )


class MultipleDataResponse(
    MultipleDataPayload[DataT, PaginationT, MetadataT],
    MultipleDataSuccessDescriptor,
    SuccessResponse[list[DataT], PaginationT, MetadataT],
    Generic[DataT, PaginationT, MetadataT],
):
    @classmethod
    def new(
        cls,
        *,
        message: OptStr = None,
        description: OptStr = None,
        data: list[DataT],
        pagination: PaginationT,
        metadata: MetadataT = None,
        other: Any = None,
    ) -> "MultipleDataResponse[DataT, PaginationT, MetadataT]":
        descriptor = MultipleDataSuccessDescriptor()
        return cls(
            message=message if message is not None else descriptor.message,
            description=(
                description if description is not None else descriptor.description
            ),
            data=data,
            pagination=pagination,
            metadata=metadata,
            other=other,
        )


class MultipleDataPairResponse(
    MultipleDataPairPayload[DataT, PaginationT, MetadataT],
    MultipleDataPairSuccessDescriptor,
    SuccessResponse[DataPair[list[DataT], list[DataT]], PaginationT, MetadataT],
    Generic[DataT, PaginationT, MetadataT],
):
    @classmethod
    def new(
        cls,
        *,
        message: OptStr = None,
        description: OptStr = None,
        old_data: list[DataT],
        new_data: list[DataT],
        pagination: PaginationT,
        metadata: MetadataT = None,
        other: Any = None,
    ) -> "MultipleDataPairResponse[DataT, PaginationT, MetadataT]":
        descriptor = MultipleDataPairSuccessDescriptor()
        return cls(
            message=message if message is not None else descriptor.message,
            description=(
                description if description is not None else descriptor.description
            ),
            data=DataPair[list[DataT], list[DataT]](
                old=old_data,
                new=new_data,
            ),
            pagination=pagination,
            metadata=metadata,
            other=other,
        )


AnySuccessResponse = (
    AnyDataResponse[DataT, OptPaginationT, MetadataT]
    | NoDataResponse[MetadataT]
    | SingleDataResponse[DataT, MetadataT]
    | SingleDataPairResponse[DataT, MetadataT]
    | MultipleDataResponse[DataT, PaginationT, MetadataT]
    | MultipleDataPairResponse[DataT, PaginationT, MetadataT]
)
SuccessResponseT = TypeVar("SuccessResponseT", bound=AnySuccessResponse)
OptAnySuccessResponse = AnySuccessResponse | None
OptSuccessResponseT = TypeVar("OptSuccessResponseT", bound=OptAnySuccessResponse)


AnyResponse = AnyErrorResponse | AnySuccessResponse
ResponseT = TypeVar("ResponseT", bound=AnyResponse)
OptAnyResponse = AnyResponse | None
OptResponseT = TypeVar("OptResponseT", bound=OptAnyResponse)


class ResponseMixin(BaseModel, Generic[OptResponseT]):
    response: OptResponseT = Field(..., description="Response")
