from datetime import datetime
from fastapi import Header, Query
from fastapi.requests import HTTPConnection, Request
from fastapi.websockets import WebSocket
from pydantic import Field
from typing import Annotated, Callable, Literal, overload
from uuid import UUID
from nexo.enums.connection import Header as HeaderEnum, Protocol, OptProtocol
from nexo.types.datetime import OptDatetime
from nexo.types.string import OptStr
from nexo.types.uuid import OptUUID
from ..mixins.identity import UUIDClientId
from ..mixins.timestamp import ExecutionTimestamp


class ClientContext(
    ExecutionTimestamp[datetime],
    UUIDClientId[UUID],
):
    signature: Annotated[str, Field(..., description="Signature")]

    @classmethod
    def from_header(cls, conn: HTTPConnection) -> "ClientContext | None":
        client_id = conn.headers.get(HeaderEnum.X_CLIENT_ID, None)
        executed_at = conn.headers.get(HeaderEnum.X_EXECUTED_AT, None)
        signature = conn.headers.get(HeaderEnum.X_SIGNATURE, None)

        if client_id is not None and executed_at is not None and signature is not None:
            client_id = UUID(client_id)
            executed_at = datetime.fromisoformat(executed_at)
            return cls(
                client_id=client_id,
                executed_at=executed_at,
                signature=signature,
            )

        return None

    @classmethod
    def from_query(cls, conn: HTTPConnection) -> "ClientContext | None":
        client_id = conn.query_params.get(HeaderEnum.X_CLIENT_ID.value, None)
        executed_at = conn.query_params.get(HeaderEnum.X_EXECUTED_AT.value, None)
        signature = conn.query_params.get(HeaderEnum.X_SIGNATURE.value, None)

        if client_id is not None and executed_at is not None and signature is not None:
            client_id = UUID(client_id)
            executed_at = datetime.fromisoformat(executed_at)
            return cls(
                client_id=client_id,
                executed_at=executed_at,
                signature=signature,
            )

        return None

    @classmethod
    def extract(cls, conn: HTTPConnection) -> "ClientContext | None":
        client_context = getattr(conn.state, "client_context", None)
        if isinstance(client_context, ClientContext):
            return client_context

        client_context = cls.from_header(conn)
        if client_context is not None:
            return client_context

        client_context = cls.from_query(conn)
        if client_context is not None:
            return client_context

        return None

    @overload
    @classmethod
    def as_dependency(
        cls,
        protocol: None = None,
        /,
    ) -> Callable[[HTTPConnection, OptUUID], "ClientContext | None"]: ...
    @overload
    @classmethod
    def as_dependency(
        cls,
        protocol: Literal[Protocol.HTTP],
        /,
    ) -> Callable[[Request, OptUUID], "ClientContext | None"]: ...
    @overload
    @classmethod
    def as_dependency(
        cls,
        protocol: Literal[Protocol.WEBSOCKET],
        /,
    ) -> Callable[[WebSocket, OptUUID], "ClientContext | None"]: ...
    @classmethod
    def as_dependency(
        cls,
        protocol: OptProtocol = None,
        /,
    ) -> (
        Callable[[HTTPConnection, OptUUID], "ClientContext | None"]
        | Callable[[Request, OptUUID], "ClientContext | None"]
        | Callable[[WebSocket, OptUUID], "ClientContext | None"]
    ):
        def _dependency(
            conn: HTTPConnection,
            # These are for documentation purpose only
            _client_id: OptUUID = Header(
                None,
                alias=HeaderEnum.X_CLIENT_ID.value,
                description="Client's ID",
            ),
            _executed_at: OptDatetime = Header(
                None,
                alias=HeaderEnum.X_EXECUTED_AT.value,
                description="Executed At",
            ),
            _signature: OptStr = Header(
                None,
                alias=HeaderEnum.X_SIGNATURE.value,
                description="Signature",
            ),
        ) -> "ClientContext | None":
            return cls.extract(conn)

        def _request_dependency(
            request: Request,
            # These are for documentation purpose only
            _client_id: OptUUID = Header(
                None,
                alias=HeaderEnum.X_CLIENT_ID.value,
                description="Client's ID",
            ),
            _executed_at: OptDatetime = Header(
                None,
                alias=HeaderEnum.X_EXECUTED_AT.value,
                description="Executed At",
            ),
            _signature: OptStr = Header(
                None,
                alias=HeaderEnum.X_SIGNATURE.value,
                description="Signature",
            ),
        ) -> "ClientContext | None":
            return cls.extract(request)

        def _websocket_dependency(
            websocket: WebSocket,
            # These are for documentation purpose only
            _client_id: OptUUID = Query(
                None,
                alias=HeaderEnum.X_CLIENT_ID.value,
                description="Client's ID",
            ),
            _executed_at: OptDatetime = Query(
                None,
                alias=HeaderEnum.X_EXECUTED_AT.value,
                description="Executed At",
            ),
            _signature: OptStr = Query(
                None,
                alias=HeaderEnum.X_SIGNATURE.value,
                description="Signature",
            ),
        ) -> "ClientContext | None":
            return cls.extract(websocket)

        if protocol is None:
            return _dependency
        elif protocol is Protocol.HTTP:
            return _request_dependency
        elif protocol is Protocol.WEBSOCKET:
            return _websocket_dependency
