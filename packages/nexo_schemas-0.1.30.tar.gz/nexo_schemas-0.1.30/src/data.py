from pydantic import BaseModel, Field
from typing import Annotated, Generic, Literal, TypeVar


OldDataT = TypeVar("OldDataT")
NewDataT = TypeVar("NewDataT")


class DataPair(BaseModel, Generic[OldDataT, NewDataT]):
    old: OldDataT = Field(..., description="Old data")
    new: NewDataT = Field(..., description="New data")


DataT = TypeVar("DataT")


class DataMixin(BaseModel, Generic[DataT]):
    data: DataT = Field(..., description="Data")


class HealthData(BaseModel):
    status: Annotated[Literal["ok"], Field("ok", description="Health data")] = "ok"


class PingData(BaseModel):
    ping: Annotated[Literal["pong"], Field("pong", description="Ping data")] = "pong"


class CheckData(BaseModel):
    check: Annotated[bool, Field(..., description="Check data")]


class CountData(BaseModel):
    count: Annotated[int, Field(0, description="Count data", ge=0)] = 0
