from pydantic import BaseModel, Field
from typing import Generic, TypeVar
from .data import DataPair, DataT, DataMixin
from .metadata import MetadataT, MetadataMixin
from .mixins.general import Other
from .pagination import OptPaginationT, PaginationT, PaginationMixin


class Payload(
    Other,
    MetadataMixin[MetadataT],
    PaginationMixin[OptPaginationT],
    DataMixin[DataT],
    BaseModel,
    Generic[DataT, OptPaginationT, MetadataT],
):
    pass


PayloadT = TypeVar("PayloadT", bound=Payload)


class PayloadMixin(BaseModel, Generic[PayloadT]):
    payload: PayloadT = Field(..., description="Payload")


class NoDataPayload(
    Payload[None, None, MetadataT],
    Generic[MetadataT],
):
    data: None = None
    pagination: None = None


class SingleDataPayload(
    Payload[DataT, None, MetadataT],
    Generic[DataT, MetadataT],
):
    pagination: None = None


class SingleDataPairPayload(
    Payload[DataPair[DataT, DataT], None, MetadataT],
    Generic[DataT, MetadataT],
):
    pagination: None = None


class MultipleDataPayload(
    Payload[list[DataT], PaginationT, MetadataT],
    Generic[DataT, PaginationT, MetadataT],
):
    pass


class MultipleDataPairPayload(
    Payload[DataPair[list[DataT], list[DataT]], PaginationT, MetadataT],
    Generic[DataT, PaginationT, MetadataT],
):
    pass
