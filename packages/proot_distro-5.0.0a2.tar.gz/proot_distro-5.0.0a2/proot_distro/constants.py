import os

PROGRAM_VERSION = "5.0.0-alpha.2"
PROGRAM_NAME = "proot-distro"

os.umask(0o022)

# Keep LD_PRELOAD for restoring after proot invocations.
_SAVED_LD_PRELOAD = os.environ.get("LD_PRELOAD", "")

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

PREFIX = os.environ.get("PREFIX", "/data/data/com.termux/files/usr")
TERMUX_HOME = os.environ.get("HOME", "/data/data/com.termux/files/home")
TERMUX_APP_PACKAGE = os.environ.get("TERMUX_APP_PACKAGE", "com.termux")

DISTRO_CONFIGS_DIR = os.path.join(PREFIX, "etc", "proot-distro")
RUNTIME_DIR = os.path.join(PREFIX, "var", "lib", "proot-distro")
DOWNLOAD_CACHE_DIR = os.path.join(RUNTIME_DIR, "dlcache")
INSTALLED_ROOTFS_DIR = os.path.join(RUNTIME_DIR, "installed-rootfs")

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_PRIMARY_NS = "8.8.8.8"
DEFAULT_SECONDARY_NS = "8.8.4.4"
DEFAULT_PATH_ENV = (
    "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
    ":/usr/local/games:/usr/games"
    f":{PREFIX}/bin:/system/bin:/system/xbin"
)
DEFAULT_FAKE_KERNEL_RELEASE = "6.17.0-PRoot-Distro"
DEFAULT_FAKE_KERNEL_VERSION = "#1 SMP PREEMPT_DYNAMIC Fri, 10 Oct 2025 00:00:00 +0000"

PROOT_DISTRO_X64_EMULATOR = os.environ.get("PROOT_DISTRO_X64_EMULATOR", "QEMU")
