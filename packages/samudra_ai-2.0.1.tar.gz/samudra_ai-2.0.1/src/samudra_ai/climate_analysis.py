# # File: src/samudra_ai/climate_analysis.py

# import os
# import numpy as np
# import pandas as pd
# import xarray as xr
# import matplotlib.pyplot as plt

# # Optional cartopy
# try:
#     import cartopy.crs as ccrs
#     HAS_CARTOPY = True
# except:
#     HAS_CARTOPY = False


# # =========================
# # 🔹 UTIL: SAFE FILENAME
# # =========================
# def safe_filename(name: str) -> str:
#     return (
#         name.replace(" ", "_")
#         .replace("(", "")
#         .replace(")", "")
#         .replace("/", "_")
#         .lower()
#     )


# # =========================
# # 🔹 AUTO DATETIME
# # =========================
# def ensure_datetime(da):
#     if "time" not in da.coords:
#         raise ValueError("❌ Tidak ada dimensi time")

#     try:
#         _ = da.time.dt.year
#         return da
#     except Exception:
#         pass

#     # 🔥 HANDLE CFTime
#     if hasattr(da.time.values[0], "year"):
#         # sudah datetime-like (cftime), aman
#         return da

#     # fallback ke pandas
#     try:
#         da = da.assign_coords(time=pd.to_datetime(da.time.values))
#     except Exception:
#         raise ValueError("❌ Time tidak bisa dikonversi ke datetime")

#     return da

# # =========================
# # 🔹 DETECT LAT LON
# # =========================
# def detect_lat_lon(da):
#     lat_candidates = ["lat", "latitude", "y", "j"]
#     lon_candidates = ["lon", "longitude", "x", "i"]

#     lat_name = next((d for d in da.dims if d.lower() in lat_candidates), None)
#     lon_name = next((d for d in da.dims if d.lower() in lon_candidates), None)

#     if lat_name is None or lon_name is None:
#         raise ValueError("❌ Tidak bisa detect dimensi lat/lon")

#     return lat_name, lon_name


# # =========================
# # 🔹 SAFE YEAR EXTRACTION
# # =========================
# def get_years(time):
#     try:
#         return np.unique(time.dt.year)
#     except Exception:
#         return np.unique(pd.to_datetime(time.values).year)


# # =========================
# # 🔹 PERIOD LOGIC
# # =========================
# def detect_climate_period(da):
#     n_months = da.time.size

#     print(f"🧪 Total months: {n_months} (~{n_months/12:.1f} years)")

#     if n_months >= (30 * 12 - 12):   # toleransi max 1 tahun hilang
#         return 30
#     elif n_months >= (20 * 12):
#         return 20
#     else:
#         return 10


# def select_last_years(da, n_years):
#     da = ensure_datetime(da)

#     end_time = da.time.max()

#     # gunakan year-based slicing (lebih stabil)
#     end_year = int(end_time.dt.year)
#     start_year = end_year - n_years + 1

#     return da.where(
#         (da.time.dt.year >= start_year) &
#         (da.time.dt.year <= end_year),
#         drop=True
#     )


# # =========================
# # 🔹 CLIMATE CALCULATION
# # =========================
# def compute_annual_mean(da):
#     return da.mean("time")


# def compute_seasonal_mean(da):
#     da = ensure_datetime(da)

#     season_order = ["DJF", "MAM", "JJA", "SON"]

#     da = da.groupby("time.season").mean("time")

#     # aman kalau ada missing season
#     available = [s for s in season_order if s in da.season.values]

#     return da.sel(season=available)


# # =========================
# # 🔹 GRID ALIGNMENT (SAFE)
# # =========================
# def align_to_reference(target, reference):
#     try:
#         aligned = target.interp_like(reference, method="nearest")

#         # 🔥 VALIDATION
#         nan_ratio = float(np.isnan(aligned.values).mean())

#         if nan_ratio > 0.95:
#             print("⚠️ Alignment menghasilkan >95% NaN → skip alignment")
#             return target

#         return aligned

#     except Exception:
#         print("⚠️ Interp gagal → skip alignment")
#         return target


# # =========================
# # 🔹 SAFE PLOT MAP
# # =========================
# def plot_map(ax, da, title, cmap="coolwarm"):
#     try:
#         lat, lon = detect_lat_lon(da)

#         if HAS_CARTOPY:
#             im = ax.pcolormesh(
#                 da[lon], da[lat], da,
#                 cmap=cmap,
#                 shading="auto",
#                 transform=ccrs.PlateCarree()
#             )
#             ax.coastlines()
#         else:
#             im = ax.pcolormesh(
#                 da[lon], da[lat], da,
#                 cmap=cmap,
#                 shading="auto"
#             )

#     except Exception:
#         # fallback aman untuk curvilinear
#         im = da.plot(ax=ax, cmap=cmap, add_colorbar=False)

#     ax.set_title(title)
#     return im


# # =========================
# # 🔹 PLOT ANNUAL
# # =========================
# def plot_annual(hist, future, delta, var_label, output_dir):

#     fname = safe_filename(var_label)

#     if HAS_CARTOPY:
#         fig, axes = plt.subplots(
#             1, 3, figsize=(18, 6),
#             subplot_kw={"projection": ccrs.PlateCarree()}
#         )
#     else:
#         fig, axes = plt.subplots(1, 3, figsize=(18, 6))

#     im = plot_map(axes[0], hist, "Historical")
#     plot_map(axes[1], future, "Future")
#     plot_map(axes[2], delta, "Delta (Future - Hist)")

#     cbar = fig.colorbar(im, ax=axes, orientation="horizontal", fraction=0.05)
#     cbar.set_label(var_label)

#     plt.suptitle(f"Annual Mean {var_label}")

#     path = os.path.join(output_dir, f"annual_{fname}.png")
#     plt.savefig(path, dpi=300, bbox_inches="tight")
#     plt.close()

#     print(f"✅ Saved: {path}")


# # =========================
# # 🔹 PLOT SEASONAL
# # =========================
# def plot_seasonal(hist, future, delta, var_label, output_dir):

#     fname = safe_filename(var_label)
#     seasons = ["DJF", "MAM", "JJA", "SON"]

#     if HAS_CARTOPY:
#         fig, axes = plt.subplots(
#             3, 4, figsize=(20, 12),
#             subplot_kw={"projection": ccrs.PlateCarree()}
#         )
#     else:
#         fig, axes = plt.subplots(3, 4, figsize=(20, 12))

#     for i, season in enumerate(seasons):

#         if (
#             season not in hist.season.values or
#             season not in future.season.values or
#             season not in delta.season.values
#         ):
#             axes[0, i].set_title(f"Hist {season} (no data)")
#             axes[1, i].set_title(f"Future {season} (no data)")
#             axes[2, i].set_title(f"Delta {season} (no data)")
#             continue

#         im = plot_map(axes[0, i], hist.sel(season=season), f"Hist {season}")
#         plot_map(axes[1, i], future.sel(season=season), f"Future {season}")
#         plot_map(axes[2, i], delta.sel(season=season), f"Delta {season}")

#     cbar = fig.colorbar(im, ax=axes, orientation="horizontal", fraction=0.03)
#     cbar.set_label(var_label)

#     plt.suptitle(f"Seasonal Mean {var_label}")

#     path = os.path.join(output_dir, f"seasonal_{fname}.png")
#     plt.savefig(path, dpi=300, bbox_inches="tight")
#     plt.close()

#     print(f"✅ Saved: {path}")


# # =========================
# # 🔹 MAIN FUNCTION
# # =========================
# def generate_climate_analysis(hist_da, future_da, var_label, output_dir):

#     print("🌍 Climate analysis started...")
#     print("🧪 BEFORE climate_analysis:")
#     print("Future std:", float(future_da.std().values))

#     os.makedirs(output_dir, exist_ok=True)

#     # =========================
#     # 🔹 AUTO LABEL
#     # =========================
#     if var_label is None:
#         var_label = "Variable"

#     hist_da = hist_da.copy(deep=True)
#     future_da = future_da.copy(deep=True)

#     # 🔹 FIX TIME (CRITICAL)
#     hist_da = ensure_datetime(hist_da)
#     future_da = ensure_datetime(future_da)

#     # =========================
#     # 🔹 CLEAN DATA
#     # =========================
#     hist_da = hist_da.dropna("time", how="all")
#     future_da = future_da.dropna("time", how="all")

#     # =========================
#     # 🔹 PERIOD DETECTION
#     # =========================
#     n_years = detect_climate_period(hist_da)
#     print(f"📆 Using last {n_years} years")

#     hist_sel = select_last_years(hist_da, n_years)
#     future_sel = select_last_years(future_da, n_years)

#     # =========================
#     # 🔹 ANNUAL
#     # =========================
#     hist_annual = compute_annual_mean(hist_sel)
#     future_annual = compute_annual_mean(future_sel)
#     delta_annual = future_annual - hist_annual

#     print("🧪 HIST annual std:", float(hist_annual.std().values))
#     print("🧪 FUTURE annual std:", float(future_annual.std().values))
#     print("🧪 DELTA annual std:", float(delta_annual.std().values))

#     plot_annual(hist_annual, future_annual, delta_annual, var_label, output_dir)

#     # =========================
#     # 🔹 SEASONAL
#     # =========================
#     hist_season = compute_seasonal_mean(hist_sel)
#     future_season = compute_seasonal_mean(future_sel)
#     delta_season = future_season - hist_season

#     plot_seasonal(hist_season, future_season, delta_season, var_label, output_dir)

#     print("🧪 AFTER climate_analysis:")
#     print("Future std:", float(future_da.std().values))
#     print("🎉 Climate analysis done!")

#     return {
#         "hist_annual": hist_annual,
#         "future_annual": future_annual,
#         "delta_annual": delta_annual,
#         "hist_season": hist_season,
#         "future_season": future_season,
#         "delta_season": delta_season,
#     }

################################
# 🌍 CLIMATE ANALYSIS (ROBUST ML + GCM SAFE)
################################

import os
import numpy as np
import pandas as pd
import cftime
import matplotlib.pyplot as plt
from samudra_ai.utils import to_time_str

try:
    import cartopy.crs as ccrs
    HAS_CARTOPY = True
except:
    HAS_CARTOPY = False


# =========================
# 🔹 SAFE FILENAME
# =========================
def safe_filename(name: str) -> str:
    return name.replace(" ", "_").replace("(", "").replace(")", "").replace("/", "_").lower()


# =========================
# 🔹 TIME NORMALIZATION
# =========================
# def ensure_datetime(da):
#     da = da.copy()

#     if "time" not in da.coords:
#         raise ValueError("❌ No time dimension")

#     da["time"] = pd.to_datetime(da.time.values)
#     return da.sortby("time")

def ensure_datetime(da):
    if "time" not in da.dims:
        raise ValueError("❌ No time dimension")

    time_vals = da.time.values

    # 🔥 DETECT CFTime
    if isinstance(time_vals[0], cftime.datetime):
        print("⚠️ CFTime detected → converting via string")

        time_str = to_time_str(time_vals)
        da["time"] = pd.to_datetime(time_str)

    else:
        da["time"] = pd.to_datetime(time_vals)

    return da.sortby("time")


# =========================
# 🔹 DETECT COVERAGE (IMPORTANT)
# =========================
def get_year_coverage(da, name="dataset"):
    da = ensure_datetime(da)

    years = np.unique(da.time.dt.year)
    start, end = years.min(), years.max()

    print(f"📊 {name} coverage: {start} → {end} ({len(years)} years)")

    return da, years


# =========================
# 🔹 EQUALIZED WINDOW (CORE LOGIC)
# =========================
def select_equalized_last_window(hist, future, max_years=30):
    hist, hist_years = get_year_coverage(hist, "HIST")
    future, fut_years = get_year_coverage(future, "FUTURE")

    N = min(len(hist_years), len(fut_years), max_years)

    print(f"📆 Periode yang digunakan : {N} years")

    def select_last_n(da, N):
        years = np.unique(da.time.dt.year)
        last_years = years[-N:]
        return da.where(da.time.dt.year.isin(last_years), drop=True)

    return select_last_n(hist, N), select_last_n(future, N)


# =========================
# 🔹 CLIMATE METRICS
# =========================
def compute_annual_mean(da):
    return da.mean("time", skipna=True)


def compute_seasonal_mean(da):
    da = ensure_datetime(da)
    seasonal = da.groupby("time.season").mean("time")

    order = ["DJF", "MAM", "JJA", "SON"]
    available = [s for s in order if s in seasonal.season.values]

    return seasonal.sel(season=available)


# =========================
# 🔹 LAT LON DETECTION
# =========================
def detect_lat_lon(da):
    lat = next(c for c in da.coords if "lat" in c.lower())
    lon = next(c for c in da.coords if "lon" in c.lower())
    return lat, lon


# =========================
# 🔹 SAFE PLOT
# =========================
def plot_map(ax, da, title, cmap="coolwarm"):
    try:
        lat, lon = detect_lat_lon(da)

        if HAS_CARTOPY:
            im = ax.pcolormesh(
                da[lon], da[lat], da,
                cmap=cmap,
                shading="auto",
                transform=ccrs.PlateCarree()
            )
            ax.coastlines()
        else:
            im = ax.pcolormesh(da[lon], da[lat], da, cmap=cmap)

    except Exception:
        im = da.plot(ax=ax, cmap=cmap, add_colorbar=False)

    ax.set_title(title)
    return im


# =========================
# 🔹 ANNUAL PLOT
# =========================
def plot_annual(hist, future, delta, var_label, output_dir):

    fname = safe_filename(var_label)

    if HAS_CARTOPY:
        fig, axes = plt.subplots(
            1, 3, figsize=(18, 6),
            subplot_kw={"projection": ccrs.PlateCarree()}
        )
    else:
        fig, axes = plt.subplots(1, 3, figsize=(18, 6))

    # auto scale (important biar comparable)
    vmin = min(hist.min(), future.min())
    vmax = max(hist.max(), future.max())

    im1 = plot_map(axes[0], hist, "Historical", cmap="Blues")
    im1.set_clim(vmin, vmax)

    im2 = plot_map(axes[1], future, "Future", cmap="Blues")
    im2.set_clim(vmin, vmax)

    im3 = plot_map(axes[2], delta, "Delta (Future - Hist)", cmap="RdBu_r")

    # colorbar utama
    cbar = fig.colorbar(im1, ax=axes[:2], orientation="horizontal", fraction=0.05, pad=0.08)
    cbar.set_label(var_label)

    # colorbar delta
    cbar2 = fig.colorbar(im3, ax=axes[2], orientation="horizontal", fraction=0.05, pad=0.08)
    cbar2.set_label(f"Δ {var_label}")

    plt.suptitle(f"Annual Mean {var_label}", fontsize=14, fontweight="bold")

    path = os.path.join(output_dir, f"annual_{fname}.png")
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.show()

    print(f"✅ Saved: {path}")


# =========================
# 🔹 SEASONAL PLOT
# =========================
def plot_seasonal(hist, future, delta, var_label, output_dir):

    fname = safe_filename(var_label)
    seasons = ["DJF", "MAM", "JJA", "SON"]

    if HAS_CARTOPY:
        fig, axes = plt.subplots(
            3, 4, figsize=(20, 12),
            subplot_kw={"projection": ccrs.PlateCarree()}
        )
    else:
        fig, axes = plt.subplots(3, 4, figsize=(20, 12))

    im_main = None
    im_delta = None

    for i, season in enumerate(seasons):

        if season not in hist.season.values:
            continue

        h = hist.sel(season=season)
        f = future.sel(season=season)
        d = delta.sel(season=season)

        vmin = float(min(h.min(), f.min()))
        vmax = float(max(h.max(), f.max()))

        im_main = plot_map(axes[0, i], h, f"Hist {season}", cmap="Blues")
        im_main.set_clim(vmin, vmax)

        im_tmp = plot_map(axes[1, i], f, f"Future {season}", cmap="Blues")
        im_tmp.set_clim(vmin, vmax)

        im_delta = plot_map(axes[2, i], d, f"Delta {season}", cmap="RdBu_r")

    # colorbar utama
    cbar = fig.colorbar(im_main, ax=axes[:2, :], orientation="horizontal", fraction=0.05, pad=0.08)
    cbar.set_label(var_label)

    # colorbar delta (FIXED)
    cbar2 = fig.colorbar(im_delta, ax=axes[2, :], orientation="horizontal", fraction=0.05, pad=0.08)
    cbar2.set_label(f"Δ {var_label}")

    plt.suptitle(f"Seasonal Mean {var_label}", fontsize=14, fontweight="bold")

    path = os.path.join(output_dir, f"seasonal_{fname}.png")
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.show()

    print(f"✅ Saved: {path}")


# =========================
# 🔹 MAIN PIPELINE
# =========================
def generate_climate_analysis(hist_da, future_da, var_label, output_dir):

    print("🌍 Plot Climate analysis ")

    os.makedirs(output_dir, exist_ok=True)

    hist_da = ensure_datetime(hist_da)
    future_da = ensure_datetime(future_da)

    # =========================
    # 🔥 CORE FIX: EQUALIZED WINDOW
    # =========================
    hist_sel, future_sel = select_equalized_last_window(hist_da, future_da)

    # print(f"📦 Hist final: {len(hist_sel.time)} steps")
    # print(f"📦 Future final: {len(future_sel.time)} steps")

    # =========================
    # ANNUAL
    # =========================
    hist_annual = compute_annual_mean(hist_sel)
    future_annual = compute_annual_mean(future_sel)
    delta_annual = future_annual - hist_annual

    # print("🧪 HIST std:", float(hist_annual.std().values))
    # print("🧪 FUTURE std:", float(future_annual.std().values))

    plot_annual(hist_annual, future_annual, delta_annual, var_label, output_dir)

    # =========================
    # SEASONAL
    # =========================
    hist_season = compute_seasonal_mean(hist_sel)
    future_season = compute_seasonal_mean(future_sel)
    delta_season = future_season - hist_season

    plot_seasonal(hist_season, future_season, delta_season, var_label, output_dir)

    print("🎉 DONE")

    return {
        "hist_annual": hist_annual,
        "future_annual": future_annual,
        "delta_annual": delta_annual,
        "hist_season": hist_season,
        "future_season": future_season,
        "delta_season": delta_season,
    }