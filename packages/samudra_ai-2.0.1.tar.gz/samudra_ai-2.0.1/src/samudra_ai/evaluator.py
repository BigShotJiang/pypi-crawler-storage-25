# # File: src/samudra_ai/evaluator.py
# import pandas as pd
# import numpy as np
# import os
# import matplotlib.pyplot as plt
# import seaborn as sns
# import xarray as xr
# import cartopy.crs as ccrs
# import cartopy.feature as cfeature
# from shapely.geometry import Point
# from shapely.prepared import prep
# from scipy.interpolate import interpn
# from .utils import compute_metrics, standardize_dims

# def ensure_latlon_for_plot(da):
#     da = da.copy()

#     # kalau sudah ada → aman
#     if "lat" in da.coords and "lon" in da.coords:
#         return da

#     # kalau pakai y,x → rename sementara
#     if "y" in da.dims and "x" in da.dims:
#         print("⚠️ Rename y,x → lat,lon (plot only)")
#         da = da.rename({"y": "lat", "x": "lon"})

#     return da

# def evaluate_model(ref_data, raw_gcm_data, corrected_data, var_name, output_dir):
#     print("\n🔎 Memulai proses evaluasi dan plotting otomatis...")

#     # Standarisasi dimensi time-lat-lon
#     try:
#         ref_data = standardize_dims(ref_data)
#         raw_gcm_data = standardize_dims(raw_gcm_data)
#         corrected_data = standardize_dims(corrected_data)
#     except:
#         print("⚠️ Skip standardize_dims in evaluator")

#     # ✅ CLEAN GLOBAL (WAJIB BANGET)
#     ref_data = _clean_da(ref_data)
#     raw_gcm_data = _clean_da(raw_gcm_data)
#     corrected_data = _clean_da(corrected_data)

#     # Potong ke time length minimum
#     time_len = min(len(ref_data.time), len(raw_gcm_data.time), len(corrected_data.time))
#     ref_sliced = ref_data.isel(time=slice(0, time_len))
#     raw_sliced = raw_gcm_data.isel(time=slice(0, time_len))
#     corr_sliced = corrected_data.isel(time=slice(0, time_len))

#     ref_sliced = ensure_latlon_for_plot(ref_sliced)
#     raw_sliced = ensure_latlon_for_plot(raw_sliced)
#     corr_sliced = ensure_latlon_for_plot(corr_sliced)

#     # Ambil grid target dari referensi
#     target_lat = ref_sliced['lat'].values
#     target_lon = ref_sliced['lon'].values
#     target_grid_lat, target_grid_lon = np.meshgrid(target_lat, target_lon, indexing='ij')
#     target_points = np.array([target_grid_lat.ravel(), target_grid_lon.ravel()]).T

#     def manual_interp(source_da, target_da):
#         # ✅ FIX: pastikan 3D
#         if "channel" in source_da.dims:
#             source_da = source_da.squeeze("channel", drop=True)

#         if source_da.dims[-2:] != ("lat", "lon"):
#             source_da = source_da.transpose("time", "lat", "lon")

#         if source_da.ndim != 3:
#             raise ValueError(f"Source data harus 3D (time, lat, lon), dapat: {source_da.shape}")
        
#         if source_da["lat"].ndim != 1:
#             print("⚠️ Skip interpolation: curvilinear grid")
#             return source_da

#         source_lat = source_da['lat'].values
#         source_lon = source_da['lon'].values

#         # Validasi monoton
#         if not (np.all(np.diff(source_lat) > 0) or np.all(np.diff(source_lat) < 0)):
#             raise ValueError("Latitude harus monoton. Urutkan ulang dimensi 'lat'.")
#         if not (np.all(np.diff(source_lon) > 0) or np.all(np.diff(source_lon) < 0)):
#             raise ValueError("Longitude harus monoton. Urutkan ulang dimensi 'lon'.")

#         source_points = (source_lat, source_lon)
#         interpolated_values = np.array([
#             interpn(
#                 source_points, source_da.isel(time=t).values, target_points,
#                 method='linear', bounds_error=False, fill_value=np.nan
#             ).reshape(target_grid_lat.shape)
#             for t in range(source_da.shape[0])
#         ])
#         # return xr.DataArray(interpolated_values, coords=ref_sliced.coords, dims=ref_sliced.dims)
#         return xr.DataArray(
#             interpolated_values,
#             coords={"time": target_da["time"], "lat": target_da["lat"], "lon": target_da["lon"]},
#             dims=["time", "lat", "lon"]
#         )

#     # Interpolasi raw GCM ke grid ref
#     raw_aligned = manual_interp(raw_sliced, ref_sliced)

#     # kalau gagal interp (curvilinear)
#     if raw_aligned.shape != ref_sliced.shape:
#         print("⚠️ Skip interpolation → pakai spatial mean masing-masing grid")

#         ref_series = ref_sliced.mean(dim=['lat', 'lon'])
#         raw_series = raw_sliced.mean(dim=['lat', 'lon'])
#     else:
#         ref_series = ref_sliced.mean(dim=['lat', 'lon'])
#         raw_series = raw_aligned.mean(dim=['lat', 'lon'])

#     # Rata-rata spasial jadi timeseries
#     ref_series = ref_sliced.mean(dim=['lat', 'lon'])
#     raw_series = raw_aligned.mean(dim=['lat', 'lon'])
#     corr_series = corr_sliced.mean(dim=['lat', 'lon'])

#     # Hitung metrik evaluasi
#     metrics_raw = compute_metrics(ref_series.values, raw_series.values)
#     metrics_corr = compute_metrics(ref_series.values, corr_series.values)
#     results_df = pd.DataFrame([
#         {'Source': 'GCM Asli', **dict(zip(['Correlation', 'RMSE', 'Bias', 'MAE'], metrics_raw))},
#         {'Source': 'GCM Terkoreksi', **dict(zip(['Correlation', 'RMSE', 'Bias', 'MAE'], metrics_corr))},
#     ])

#     # Simpan summary metrics
#     if output_dir:
#         os.makedirs(output_dir, exist_ok=True)
#         results_df.to_excel(os.path.join(output_dir, "summary_metrics.xlsx"), index=False)

#     # Simpan timeseries per timestep
#     df_line = pd.DataFrame({
#         "Time": ref_series.time.values,
#         "GCM Asli": raw_series.values,
#         "GCM Terkoreksi": corr_series.values,
#         "Reanalysis (Obs)": ref_series.values
#     })

#     if output_dir:
#         df_line.to_excel(os.path.join(output_dir, "timeseries_comparison.xlsx"), index=False)

#     # Plot timeseries
#     plt.figure(figsize=(15, 6))
#     sns.lineplot(data=df_line)
#     plt.title(f"Grafik Perbandingan Time Series {var_name.upper()}")
#     plt.grid(True)
#     if output_dir:
#         plt.savefig(os.path.join(output_dir, "timeseries_comparison.png"), dpi=300)
#     plt.show()

#     # Plot bar metrik
#     df_melt = results_df.melt(id_vars=['Source'], var_name='Metric', value_name='Value')
#     plt.figure(figsize=(10, 7))
#     sns.barplot(data=df_melt, x='Metric', y='Value', hue='Source', palette='viridis')
#     plt.title("Perbandingan Metrik Evaluasi")
#     if output_dir:
#         plt.savefig(os.path.join(output_dir, "metrics_barplot.png"), dpi=300)
#     plt.show()

#     return results_df, corr_sliced

# def _create_land_mask(lat, lon, resolution="10m"):
#     """Buat masker daratan berdasarkan NaturalEarthFeature."""
#     land_feature = cfeature.NaturalEarthFeature("physical", "land", resolution)
#     land_geom = list(land_feature.geometries())
#     land_prep = [prep(g) for g in land_geom]

#     mask = np.zeros((len(lat), len(lon)), dtype=bool)
#     for i, la in enumerate(lat):
#         for j, lo in enumerate(lon):
#             pt = Point(lo, la)
#             if any(g.contains(pt) for g in land_prep):
#                 mask[i, j] = True
#     return mask

# def mask_land(da, resolution="10m"):
#     da = ensure_latlon_for_plot(da)

#     if "channel" in da.dims:
#         da = da.squeeze("channel", drop=True)

#     lat = da["lat"].values
#     lon = da["lon"].values

#     mask = _create_land_mask(lat, lon, resolution)

#     return da.where(mask)

# def mask_ocean(da, resolution="10m"):
#     da = ensure_latlon_for_plot(da)
    
#     # ✅ FIX: squeeze channel kalau ada
#     if "channel" in da.dims:
#         da = da.squeeze("channel", drop=True)

#     lat = da["lat"].values
#     lon = da["lon"].values

#     mask = _create_land_mask(lat, lon, resolution)

#     return da.where(~mask)

# # ✅ FIX GLOBAL (WAJIB)
# def _clean_da(da):
#     if "channel" in da.dims:
#         da = da.squeeze("channel", drop=True)
#     return da

# def plot_spatial_comparison(corrected_da, raw_gcm_da, ref_da, var_name, output_dir=None,
#                             units="", mask_type=None):
    
#     print("🌍 Membuat plot spasial perbandingan rata-rata...")

#     # Hitung rata-rata sepanjang waktu
#     out_mean = _clean_da(corrected_da.mean(dim="time"))
#     gcm_mean = _clean_da(raw_gcm_da.mean(dim="time"))
#     ref_mean = _clean_da(ref_da.mean(dim="time"))

#     # baru rename kalau perlu
#     out_mean = ensure_latlon_for_plot(out_mean)
#     gcm_mean = ensure_latlon_for_plot(gcm_mean)
#     ref_mean = ensure_latlon_for_plot(ref_mean)

#     # Masking opsional
#     if mask_type == "land":
#         out_mean, gcm_mean, ref_mean = mask_land(out_mean), mask_land(gcm_mean), mask_land(ref_mean)
#     elif mask_type == "ocean":
#         out_mean, gcm_mean, ref_mean = mask_ocean(out_mean), mask_ocean(gcm_mean), mask_ocean(ref_mean)

#     datasets = [out_mean, gcm_mean, ref_mean]
#     titles = ["Model Terkoreksi", "GCM Asli", "Observasi (Reanalysis)"]

#     fig, axes = plt.subplots(1, 3, figsize=(18, 6), subplot_kw={"projection": ccrs.PlateCarree()})

#     for ax, da, title in zip(axes, datasets, titles):
#         im = ax.pcolormesh(
#             da["lon"], da["lat"], da,
#             cmap="coolwarm", transform=ccrs.PlateCarree()
#         )
#         # ax.set_aspect('auto')
#         ax.coastlines()
#         ax.set_title(title)

#     # === buat axis khusus untuk colorbar di bawah ===
#     cbar_ax = fig.add_axes([0.25, 0.1, 0.5, 0.03])  
#     # [left, bottom, width, height] dalam koordinat figure (0–1)
#     cbar = fig.colorbar(im, cax=cbar_ax, orientation="horizontal")
#     cbar.set_label(units)

#     plt.suptitle(f"Peta Perbandingan Rata-rata Spasial {var_name.upper()}", fontsize=14)
#     plt.tight_layout(rect=[0, 0.15, 1, 0.95])
#     fig.subplots_adjust(left=0.05, right=0.95, top=0.9, bottom=0.2, wspace=0.25)

#     save_path = None
#     if output_dir:
#         os.makedirs(output_dir, exist_ok=True)
#         save_path = os.path.join(output_dir, f"spatial_comparison_{var_name}_{mask_type or 'global'}.jpg")
#         plt.savefig(save_path, dpi=300, bbox_inches="tight", format="jpg")
#         print(f"✅ Peta spasial disimpan ke: {save_path}")

#     plt.show()
#     return save_path

# File: src/samudra_ai/evaluator.py

import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import seaborn as sns
import xarray as xr
import cartopy.crs as ccrs
from .utils import compute_metrics

# =========================
# 🔹 UTIL: AUTO DIM DETECTION
# =========================
def get_spatial_dims(da):
    return [d for d in da.dims if d != "time"]

# =========================
# 🔹 UTIL: SAFE MEAN (GRID AGNOSTIC)
# =========================
def spatial_mean(da):
    dims = get_spatial_dims(da)
    return da.mean(dim=dims)

def safe_interp_like(mask, target):
    try:
        return mask.interp_like(target, method="nearest")
    except Exception:
        print("⚠️ Mask interp gagal → fallback tanpa alignment")
        return mask

def create_mask_from_reference(ref_da):
    """
    Mask berbasis NaN dari observasi (lebih cepat & konsisten)
    """
    mask = xr.where(np.isnan(ref_da.isel(time=0)), 0, 1)
    return mask

# =========================
# 🔹 UTIL: RENAME FOR PLOT ONLY
# =========================
def ensure_latlon_for_plot(da):
    da = da.copy()

    # sudah ada
    if "lat" in da.dims and "lon" in da.dims:
        return da

    rename_map = {}

    for d in da.dims:
        if d.lower() in ["y", "j", "latitude"]:
            rename_map[d] = "lat"
        elif d.lower() in ["x", "i", "longitude"]:
            rename_map[d] = "lon"

    if rename_map:
        print(f"⚠️ Rename dim untuk plot: {rename_map}")
        da = da.rename(rename_map)

    return da

# =========================
# 🔹 UTIL: MASK FROM REFERENCE (FAST & CONSISTENT)
# =========================
def apply_mask(da, ref_da, mode="ocean"):
    mask = create_mask_from_reference(ref_da)
    mask = safe_interp_like(mask, da)

    if mode == "ocean":
        return da.where(mask == 1)
    elif mode == "land":
        return da.where(mask == 0)
    else:
        return da

# =========================
# 🔹 MAIN EVALUATION
# =========================
def evaluate_model(ref_data, raw_gcm_data, corrected_data, var_name, output_dir=None):

    print("\n🔎 Evaluasi model ...")

    # === SAMAKAN PANJANG TIME ===
    time_len = min(len(ref_data.time), len(raw_gcm_data.time), len(corrected_data.time))

    ref = ref_data.isel(time=slice(0, time_len))
    raw = raw_gcm_data.isel(time=slice(0, time_len))
    corr = corrected_data.isel(time=slice(0, time_len))

    # =========================
    # 🔹 TIMESERIES (NO GRID MATCHING)
    # =========================
    ref_series = spatial_mean(ref)
    raw_series = spatial_mean(raw)
    corr_series = spatial_mean(corr)

    # =========================
    # 🔹 METRICS
    # =========================
    metrics_raw = compute_metrics(ref_series.values, raw_series.values)
    metrics_corr = compute_metrics(ref_series.values, corr_series.values)

    results_df = pd.DataFrame([
        {'Source': 'GCM Asli', **dict(zip(['Correlation', 'RMSE', 'Bias', 'MAE'], metrics_raw))},
        {'Source': 'GCM Terkoreksi', **dict(zip(['Correlation', 'RMSE', 'Bias', 'MAE'], metrics_corr))},
    ])

    # =========================
    # 🔹 SAVE
    # =========================
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        results_df.to_excel(os.path.join(output_dir, "summary_metrics.xlsx"), index=False)

    # =========================
    # 🔹 TIMESERIES PLOT
    # =========================
    df_line = pd.DataFrame({
        "Time": ref_series.time.values,
        "GCM Asli": raw_series.values,
        "GCM Terkoreksi": corr_series.values,
        "Observasi": ref_series.values
    })

    plt.figure(figsize=(15, 6))
    sns.lineplot(data=df_line)
    plt.title(f"Time Series Comparison {var_name.upper()}")
    plt.grid(True)

    if output_dir:
        plt.savefig(os.path.join(output_dir, "timeseries.png"), dpi=300)

    plt.show()

    # =========================
    # 🔹 METRIC BAR
    # =========================
    df_melt = results_df.melt(id_vars=['Source'], var_name='Metric', value_name='Value')

    plt.figure(figsize=(10, 6))
    sns.barplot(data=df_melt, x='Metric', y='Value', hue='Source')
    plt.title("Evaluation Metrics")

    if output_dir:
        plt.savefig(os.path.join(output_dir, "metrics.png"), dpi=300)

    plt.show()

    return results_df, corr

def ensure_2d(da):
    keep_dims = [d for d in da.dims if d.lower() in ["lat", "lon"]]

    if len(keep_dims) != 2:
        print(f"Reducing extra dims: {da.dims}")
        da = da.mean(dim=[d for d in da.dims if d not in keep_dims])
    return da

# =========================
# 🔹 SPATIAL PLOT (SAFE)
# =========================
def plot_spatial_comparison(
    corrected_da, raw_gcm_da, ref_da,
    var_name, output_dir=None, units="",
    mask_type=None  # "land", "ocean", None
):

    print("🌍 Plot spasial ...")

    out_mean = corrected_da.mean(dim="time")
    gcm_mean = raw_gcm_da.mean(dim="time")
    ref_mean = ref_da.mean(dim="time")

    out_mean = ensure_2d(out_mean)
    gcm_mean = ensure_2d(gcm_mean)
    ref_mean = ensure_2d(ref_mean)

    # 🔥 APPLY MASK
    if mask_type in ["land", "ocean"]:
        out_mean = apply_mask(out_mean, ref_da, mask_type)
        gcm_mean = apply_mask(gcm_mean, ref_da, mask_type)
        ref_mean = apply_mask(ref_mean, ref_da, mask_type)

    # rename untuk plot
    out_mean = ensure_latlon_for_plot(out_mean)
    gcm_mean = ensure_latlon_for_plot(gcm_mean)
    ref_mean = ensure_latlon_for_plot(ref_mean)

    datasets = [out_mean, gcm_mean, ref_mean]
    titles = ["Corrected", "Raw GCM", "Reference"]

    fig, axes = plt.subplots(
        1, 3, figsize=(18, 6),
        subplot_kw={"projection": ccrs.PlateCarree()}
    )

    for ax, da, title in zip(axes, datasets, titles):

        im = ax.pcolormesh(
            da["lon"], da["lat"], da,
            cmap="coolwarm",
            transform=ccrs.PlateCarree()
        )

        ax.coastlines()
        ax.set_title(title)

    # === COLORBAR ===
    cbar = fig.colorbar(im, ax=axes, orientation="horizontal", fraction=0.05)
    cbar.set_label(units)

    plt.suptitle(f"Spatial Comparison {var_name.upper()}")

    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        path = os.path.join(output_dir, f"spatial_{var_name}.png")
        plt.savefig(path, dpi=300)
        print(f"✅ Saved: {path}")

    plt.show()