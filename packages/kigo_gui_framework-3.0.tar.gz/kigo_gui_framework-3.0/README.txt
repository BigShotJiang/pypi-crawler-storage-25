Kigo now has support for networking and
SunOS
Solaris
FreeBSD
Android
Linux
Mac 
Windous
ChromeOS
Do  not use v2.8 (missing __init__.py)