import json
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from pydantic import BaseModel, field_validator
from sqlalchemy import Column as SAColumn
from sqlalchemy import String, Text, UniqueConstraint
from sqlmodel import Field, SQLModel

from ..core.constants import RecoverableToolError
from ..utils.clock import utc_now


@dataclass
class ToolCall:
    """
    OpenAI formatting for tool calls
    """

    id: str
    function: dict[str, Any]
    type: str = "function"

    def to_json(self) -> dict[str, Any]:
        return {"id": self.id, "function": self.function, "type": self.type}


class FunctionCall(BaseModel):
    """
    Internal representation of a tool call, formatted for simpler execution logic
    """

    # Formatted for ease of execution
    id: str
    function_name: str
    arguments: dict

    def __str__(self):
        return json.dumps({self.function_name: self.arguments})

    def to_tool_call(self) -> ToolCall:
        return ToolCall(id=self.id, function={"name": self.function_name, "arguments": json.dumps(self.arguments)})


class MemorySource(ABC):
    """Abstract base class for memory sources"""

    id: int | None
    user_id: int

    @abstractmethod
    def get_name(self) -> str:
        raise NotImplementedError

    @abstractmethod
    def to_fact(self) -> str:
        raise NotImplementedError

    @classmethod
    def source_type(cls) -> str:
        return cls.__name__

    def to_memory_source_d(self) -> dict[str, Any]:
        return {"source_type": self.source_type(), "id": self.id}


class EmbeddableSqlModel(ABC, SQLModel):
    id: int | None
    user_id: int
    is_active: bool | None

    @abstractmethod
    def get_name(self) -> str:
        pass

    @abstractmethod
    def to_fact(self) -> str:
        raise NotImplementedError


class User(SQLModel, table=True):
    __table_args__ = {"extend_existing": True}
    id: int | None = Field(default=None, primary_key=True)
    token: str = Field(..., description="The unique token for the user")
    created_at: datetime = Field(default_factory=utc_now, nullable=False)
    updated_at: datetime = Field(default_factory=utc_now, nullable=False)


class Memory(EmbeddableSqlModel, MemorySource, SQLModel, table=True):
    __table_args__ = {"extend_existing": True}
    id: int | None = Field(default=None, primary_key=True)
    created_at: datetime = Field(default_factory=utc_now, nullable=False)
    updated_at: datetime = Field(default_factory=utc_now, nullable=False)
    user_id: int = Field(..., description="Elroy user for context")
    name: str = Field(..., description="The name of the context")
    file_path: str | None = Field(default=None, description="Path to markdown file storing memory content")
    source_metadata: str = Field(sa_column=SAColumn(Text), default="[]", description="Metadata for the memory as JSON string")
    is_active: bool | None = Field(default=True, description="Whether the context is active")

    def get_name(self) -> str:
        return self.name

    def to_fact(self) -> str:
        import re

        if not self.file_path:
            return f"#{self.name}\n"
        try:
            content = Path(self.file_path).read_text()
        except OSError:
            return f"#{self.name}\n"
        m = re.match(r"^---\n.*?\n---\n?", content, re.DOTALL)
        text = content[m.end() :] if m else content
        return f"#{self.name}\n{text}"


class SourceDocument(SQLModel, table=True):
    __table_args__ = (UniqueConstraint("user_id", "address"), {"extend_existing": True})
    id: int | None = Field(default=None, primary_key=True)
    created_at: datetime = Field(default_factory=utc_now, nullable=False)
    updated_at: datetime = Field(default_factory=utc_now, nullable=False)
    user_id: int = Field(..., description="Elroy user for context")
    address: str = Field(..., description="The address of the document")
    name: str = Field(..., description="The name of the document")
    content: str | None = Field(..., description="The extracted content of the document")
    extracted_at: datetime = Field(default_factory=utc_now, nullable=False)
    content_md5: str | None = Field(..., description="The MD5 hash of the extracted content")


class DocumentExcerpt(EmbeddableSqlModel, MemorySource, table=True):
    __table_args__ = (UniqueConstraint("user_id", "source_document_id", "chunk_index", "is_active"), {"extend_existing": True})
    id: int | None = Field(default=None, primary_key=True)
    created_at: datetime = Field(default_factory=utc_now, nullable=False)
    updated_at: datetime = Field(default_factory=utc_now, nullable=False)
    user_id: int = Field(..., description="Elroy user for context")
    name: str = Field(..., description="The name of the document")
    content: str = Field(..., description="The text of the document")
    source_document_id: int = Field(..., description="The source document ID")
    chunk_index: int = Field(..., description="The index of the chunk in the source document")
    content_md5: str = Field(..., description="The MD5 hash of the text")
    is_active: bool | None = Field(default=True, description="Whether the context is active")

    def get_name(self) -> str:
        return self.name

    def to_fact(self) -> str:
        return f"#{self.name}\n{self.content}"


class AgendaItem(EmbeddableSqlModel, MemorySource, SQLModel, table=True):
    __table_args__ = {"extend_existing": True}
    id: int | None = Field(default=None, primary_key=True)
    created_at: datetime = Field(default_factory=utc_now, nullable=False)
    updated_at: datetime = Field(default_factory=utc_now, nullable=False)
    user_id: int = Field(..., description="Elroy user for context")
    name: str = Field(..., description="The name of the agenda item")
    file_path: str = Field(..., description="Path to the agenda item markdown file")
    trigger_datetime: datetime | None = Field(default=None, description="When the item should trigger")
    trigger_context: str | None = Field(
        default=None,
        sa_column=SAColumn("reminder_context", String, nullable=True),
        description="Context that should trigger this item",
    )
    is_active: bool | None = Field(default=True, description="Whether the agenda item is active")
    status: str = Field(default="created", description="Status of agenda item")
    closing_comment: str | None = Field(default=None, description="Comment on why the item was deleted or marked complete.")

    @field_validator("status")
    @classmethod
    def validate_status(cls, v: str) -> str:
        allowed_statuses = {"created", "deleted", "completed"}
        if v not in allowed_statuses:
            raise ValueError(f"Status must be one of {allowed_statuses}, got {v}")
        return v

    def get_name(self) -> str:
        return self.name

    @property
    def reminder_context(self) -> str | None:
        return self.trigger_context

    @reminder_context.setter
    def reminder_context(self, value: str | None) -> None:
        self.trigger_context = value

    @property
    def text(self) -> str:
        import re

        try:
            content = Path(self.file_path).read_text()
        except OSError:
            return ""
        m = re.match(r"^---\n.*?\n---\n?", content, re.DOTALL)
        return (content[m.end() :] if m else content).strip()

    def to_fact(self) -> str:
        text = self.text
        if self.trigger_datetime:
            return f"#{self.name} (Timed: {self.trigger_datetime.strftime('%Y-%m-%d %H:%M:%S')})\n{text}"
        if self.trigger_context:
            return f"#{self.name} (Context: {self.trigger_context})\n{text}"
        return f"#Agenda: {self.name}\n{text}"


class MemoryOperationTracker(SQLModel, table=True):
    __table_args__ = (UniqueConstraint("user_id"), {"extend_existing": True})
    id: int | None = Field(default=None, primary_key=True)
    user_id: int = Field(..., description="User associated with the memory operations")
    memories_since_consolidation: int = Field(
        default=0, description="Number of new memories created since the last consolidation operation"
    )
    messages_since_memory: int = Field(default=0, description="Number of messages processed since the last memory creation")
    created_at: datetime = Field(default_factory=utc_now, nullable=False)
    updated_at: datetime = Field(default_factory=utc_now, nullable=False)


class Message(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    created_at: datetime = Field(default_factory=utc_now, nullable=False)
    updated_at: datetime = Field(default_factory=utc_now, nullable=False)
    user_id: int = Field(..., description="Elroy user for context")
    role: str = Field(..., description="The role of the message")
    content: str | None = Field(..., description="The text of the message")
    model: str | None = Field(None, description="The model used to generate the message")
    tool_calls: str | None = Field(sa_column=SAColumn(Text), description="Tool calls as JSON string")
    tool_call_id: str | None = Field(None, description="The id of the tool call")


class UserPreference(SQLModel, table=True):
    __table_args__ = (UniqueConstraint("user_id", "is_active"), {"extend_existing": True})
    id: int | None = Field(default=None, primary_key=True)
    created_at: datetime = Field(default_factory=utc_now, nullable=False)
    updated_at: datetime = Field(default_factory=utc_now, nullable=False)
    user_id: int = Field(..., description="User for context")
    preferred_name: str | None = Field(default=None, description="The preferred name for the user")
    system_persona: str | None = Field(
        default=None, description="The system persona for the user, included in the system instruction. If unset, a default is used"
    )
    full_name: str | None = Field(default=None, description="The full name for the user")
    is_active: bool | None = Field(default=True, description="Whether the context is active")
    assistant_name: str | None = Field(default=None, description="The assistant name for the user")
    background_ingest_last_run: datetime | None = Field(default=None, description="Timestamp of the last background ingestion run")


class ContextMessageSet(SQLModel, table=True):
    __table_args__ = (UniqueConstraint("user_id", "is_active"), {"extend_existing": True})
    id: int | None = Field(default=None, primary_key=True)
    created_at: datetime = Field(default_factory=utc_now, nullable=False)
    updated_at: datetime = Field(default_factory=utc_now, nullable=False)
    user_id: int = Field(..., description="Elroy user for context")
    message_ids: str = Field(sa_column=SAColumn(Text), description="The messages in the context window as JSON string")
    is_active: bool | None = Field(True, description="Whether the context is active")


def get_mem_source_options() -> dict[str, type[MemorySource]]:
    # Note, this is brittle! Should be replaced in the future with a registration process.
    from ..repository.context_messages.transforms import ContextMessageSetWithMessages

    return {source_class.source_type(): source_class for source_class in [*MemorySource.__subclasses__(), ContextMessageSetWithMessages]}


class InvalidMemorySourceTypeError(RecoverableToolError):
    def __init__(self, source_type: str):
        super().__init__(f"Invalid memory source type: {source_type}. Valid options are: {get_mem_source_options().keys()}")


def get_memory_source_class(source_type: str) -> type[MemorySource]:

    options = get_mem_source_options()

    if source_type in options:
        return options[source_type]
    raise InvalidMemorySourceTypeError(source_type)
