import json
from collections.abc import Callable, Iterable, Sequence
from functools import partial
from typing import Any, TypeVar, cast

from pydantic import BaseModel, Field
from sqlmodel import col, select
from toolz import concat, juxt, pipe, unique
from toolz.curried import filter, map, remove, tail

from ...core.constants import SYSTEM, TOOL
from ...core.ctx import ElroyContext
from ...core.logging import get_logger, log_execution_time
from ...core.tracing import tracer
from ...db.db_models import (
    AgendaItem,
    EmbeddableSqlModel,
    Memory,
    MemorySource,
    get_memory_source_class,
)
from ...llm.client import LlmClient
from ..context_messages.data_models import ContextMessage
from ..context_messages.tools import to_synthetic_tool_call
from ..context_messages.transforms import (
    ContextMessageSetWithMessages,
    format_context_messages,
)
from ..data_models import RecallMetadata, RecallResponse
from ..recall.queries import (
    get_most_relevant_agenda_items,
    get_most_relevant_due_items,
    get_most_relevant_memories,
    get_recall_metadata,
    is_in_context,
)
from ..user.queries import do_get_user_preferred_name, get_assistant_name
from .transforms import to_fast_recall_tool_call

logger = get_logger()


def db_get_memory_source_by_name(ctx: ElroyContext, source_type: str, name: str) -> MemorySource | None:
    source_class = get_memory_source_class(source_type)

    if source_class == ContextMessageSetWithMessages:
        return ContextMessageSetWithMessages(ctx.db.session, int(name), ctx.user_id)
    if hasattr(source_class, "name"):
        return ctx.db.exec(select(source_class).where(source_class.name == name, source_class.user_id == ctx.user_id)).first()
    raise NotImplementedError(f"Cannot get source of type {source_type}")


def db_get_source_list_for_memory(ctx: ElroyContext, memory: Memory) -> Sequence[MemorySource]:
    if not memory.source_metadata:
        return []
    return pipe(
        memory.source_metadata,
        json.loads,
        map(lambda x: db_get_memory_source(ctx, x["source_type"], x["id"])),
        remove(lambda x: x is None),
        list,
    )


def db_get_memory_source(ctx: ElroyContext, source_type: str, id: int) -> MemorySource | None:
    source_class = get_memory_source_class(source_type)

    if source_class == ContextMessageSetWithMessages:
        return ContextMessageSetWithMessages(ctx.db.session, id, ctx.user_id)
    return ctx.db.exec(select(source_class).where(source_class.id == id, source_class.user_id == ctx.user_id)).first()


def get_active_memories(ctx: ElroyContext) -> list[Memory]:
    """Fetch all active memories for the user"""
    return list(
        ctx.db.exec(
            select(Memory).where(
                Memory.user_id == ctx.user_id,
                cast(Any, Memory.is_active),
            )
        ).all()
    )


@tracer.chain
def get_relevant_memories_and_due_items(ctx: ElroyContext, query: str) -> list[Memory | AgendaItem]:
    query_embedding = ctx.llm.get_embedding(query)

    relevant_memories = [
        memory
        for memory in ctx.db.query_vector(ctx.l2_memory_relevance_distance_threshold, Memory, ctx.user_id, query_embedding)
        if isinstance(memory, Memory)
    ]

    relevant_due_items = list(get_most_relevant_due_items(ctx, query_embedding))

    return relevant_memories + relevant_due_items


def get_memory_by_name(ctx: ElroyContext, memory_name: str) -> Memory | None:
    return ctx.db.exec(
        select(Memory).where(
            Memory.user_id == ctx.user_id,
            Memory.name == memory_name,
            cast(Any, Memory.is_active),
        )
    ).first()


T = TypeVar("T")


@tracer.chain
@log_execution_time
def filter_for_relevance(
    fast_llm: LlmClient,
    query: str,
    memories: list[T],
    extraction_fn: Callable[[T], str],
) -> list[T]:
    """Filter memories for relevance using fast model for efficiency."""

    memories_str = "\n\n".join(f"{i}. {extraction_fn(memory)}" for i, memory in enumerate(memories))

    class RelevanceResponse(BaseModel):
        answers: list[bool]
        reasoning: str

    resp = fast_llm.query_llm_with_response_format(
        prompt=f"""
        Query: {query}
        Responses:
        {memories_str}
        """,
        system="""Your job is to determine which of a set of memories are relevant to a query.
        Given a query and a list of memories, output:
        - a list of boolean values indicating whether each memory is relevant to the query.
        - a brief explanation of your reasoning.

        """,
        response_format=RelevanceResponse,
    )

    return [mem for mem, r in zip(list(memories), resp.answers, strict=False) if r]


def get_message_content(context_messages: list[ContextMessage], n: int) -> str:
    return pipe(
        context_messages,
        remove(lambda x: x.role == SYSTEM),
        remove(lambda x: x.role == TOOL),
        tail(n),
        map(lambda x: f"{x.role}: {x.content}" if x.content else None),
        remove(lambda x: x is None),
        list,
        "\n".join,
    )


@tracer.chain
def get_relevant_memory_context_msgs(ctx: ElroyContext, context_messages: list[ContextMessage]) -> list[ContextMessage]:
    message_content = get_message_content(context_messages, 6)

    if not message_content:
        return []

    assert isinstance(message_content, str)

    return pipe(
        message_content,
        lambda x: ctx.llm.get_embedding(x, ctx=ctx),
        lambda x: juxt(get_most_relevant_memories, get_most_relevant_due_items, get_most_relevant_agenda_items)(ctx, x),
        concat,
        filter(lambda x: x is not None),
        remove(partial(is_in_context, context_messages)),
        list,
        lambda mems: get_reflective_recall(ctx, context_messages, mems) if ctx.reflect else get_fast_recall(mems),
    )


@tracer.chain
def get_fast_recall(memories: Iterable[EmbeddableSqlModel]) -> list[ContextMessage]:
    """Add recalled content to context, unprocessed."""
    if not memories:
        return []

    return to_fast_recall_tool_call(list(memories))


@tracer.chain
@log_execution_time
def get_reflective_recall(
    ctx: ElroyContext, context_messages: Iterable[ContextMessage], memories: Iterable[EmbeddableSqlModel]
) -> list[ContextMessage]:
    """More process memory into more reflective recall message"""
    if not memories:
        return []

    class ReflectionResponse(BaseModel):
        content: str | None = Field(
            description="The content of the reflection on the memories, written in the first person. If memories are irrelevant, this field should be empty"
        )
        is_relevant: bool = Field(description="Whether or not any of the recalled information is relevant to the conversation.")

    output: str = pipe(
        memories,
        map(lambda x: x.to_fact()),
        "\n\n".join,
        lambda x: (
            "Recalled Memory Content\n\n"
            + x
            + "#Converstaion Transcript:\n"
            + format_context_messages(
                tail(3, list(context_messages)[1:]),
                do_get_user_preferred_name(ctx.db.session, ctx.user_id),
                get_assistant_name(ctx),
            )
        ),
        lambda x: ctx.llm.query_llm_with_response_format(
            x,
            """#Identity and Purpose

        I am the internal thoughts of an AI assistant. I am reflecting on memories that have entered my awareness.

        I am considering recalled context, as well as the transcript of a recent conversation. I am:
        - Re-stating the most relevant context from the recalled content
        - Reflecting on how the recalled content relates to the conversation transcript

        Specific examples are most helpful. For example, if the recalled content is:

        "USER mentioned that when playing basketball, they struggle to remember to follow through on their shots."

        and the conversation transcript includes:
        "USER: I'm going to play basketball next week"

        a good response would be:
        "I remember that USER struggles to remember to follow through on their shots when playing basketball. I should remind USER about following through on their shots for next week's game."


        My response will be in the first person, and will be transmitted to an AI assistant to inform their response. My response will NOT be transmitted to the user.

        My response is brief and to the point, no more than 100 words.
        """,
            response_format=ReflectionResponse,
        ),
    )

    assert isinstance(output, ReflectionResponse)
    if not output.is_relevant:
        return []
    if output.is_relevant and not output.content:
        logger.warning("Memories deemed relevant, but not content returned.")
        return []
    assert output.content
    return to_synthetic_tool_call(
        "get_reflective_recall",
        RecallResponse(content=output.content, recall_metadata=_build_recall_metadata(cast(list[MemorySource], list(memories)))),
    )


def _build_recall_metadata(memories: list[MemorySource]) -> list[RecallMetadata]:
    recall_metadata: list[RecallMetadata] = []
    for memory in memories:
        memory_id = memory.id
        assert memory_id is not None
        recall_metadata.append(
            RecallMetadata(
                memory_type=memory.__class__.__name__,
                memory_id=memory_id,
                name=memory.get_name(),
            )
        )
    return recall_metadata


def get_in_context_memories_metadata(context_messages: Iterable[ContextMessage]) -> list[str]:
    return pipe(
        context_messages,
        map(get_recall_metadata),
        concat,
        map(lambda m: f"{m.memory_type}: {m.name}"),
        unique,
        list,
        sorted,
    )


def get_memories(ctx: ElroyContext, memory_ids: list[int]) -> list[Memory]:
    return list(ctx.db.exec(select(Memory).where(Memory.user_id == ctx.user_id, col(Memory.id).in_(memory_ids))).all())
