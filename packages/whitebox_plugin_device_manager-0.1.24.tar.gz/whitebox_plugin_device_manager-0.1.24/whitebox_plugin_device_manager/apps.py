from whitebox.plugins import AppConfig


class WhiteboxPluginDeviceManagerConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "whitebox_plugin_device_manager"
    verbose_name = "Device Manager"
