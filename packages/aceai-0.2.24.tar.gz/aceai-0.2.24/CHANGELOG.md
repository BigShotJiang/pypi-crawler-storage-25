# Changelog

## AceAI v0.2.24

### Features

- `tui`: Add static screenshot demos for the multi-agent and trajectory views so release docs can show real terminal states without calling a live model.
- `docs`: Add README screenshots for the home screen, configuration tools, multi-agent coordination, and trajectory audit trail.

### Improvements

- `tui`: Add startup shortcut help and improve the Tools configuration UI with clearer agent-skill labeling, card-style skill entries, richer empty states, and a button-based `Allow all` action.
- `tui`: Polish queued-input and stream rendering details so interactive controls read more cleanly in the terminal.

### Fixes

- `demo`: Keep static demo tool-call payloads aligned with the current trajectory renderer so the screenshot demos open without runtime errors.

### Breaking Changes

- None.

## AceAI v0.2.23

### Improvements

- `agent-app`: Move model metadata, reasoning effort, config persistence, tool summaries, and request metadata ownership into `AceAgentApp` so the TUI consumes app-layer state instead of rebuilding provider details itself.
- `tui`: Simplify the interactive runner around app-layer events, add cancellable queued messages, and make the subagent selector clearer about main-thread versus child-thread activation.
- `docs`: Stop tracking obsolete design specs now that the app-layer/TUI boundary and multi-agent thread phases have been implemented.

### Fixes

- `subagents`: Allow steering an active delegated child thread by recording a child steer event, canceling stale child runtime tasks, and keeping the delegated handoff attached to the current child run.
- `sessions`: Preserve active thread state and subagent session replay behavior when switching sessions or replaying thread-aware histories.

### Breaking Changes

- `tui`: `AceAIInteractiveTUI` now constructs and reads runtime/provider state through `AceAgentApp`; callers that reached into runner-owned provider metadata or request-meta internals must use the app-layer accessors instead.
- `delegation`: Sending normal input while a delegated child thread is active is treated as child-thread steering; callers that want a new parent turn must switch back to the main thread before submitting input.

## AceAI v0.2.22

### Features

- `threads`: Add realtime app-layer child thread events so delegated subagent runs can stream and persist independently while the parent waits for a bounded handoff.
- `tui`: Add a `/subagents` thread selector that can switch the active main stream, input, queue, and approval target between the main thread and child subagent threads.
- `export`: Add `aceai export <session_id> --threads` to emit thread-aware transcripts with diagnostic event, thread, run, step, and tool-call identifiers.
- `skills`: Add project skills for launching AceAI in Ghostty and capturing TUI screenshots for visual validation workflows.

### Improvements

- `delegation`: Track child thread runtime completion, failure, and suspension through the app layer so parent tool calls resolve cleanly instead of hanging on child failures.
- `approvals`: Scope pending approvals and approved tool names by thread, and validate explicit thread, run, and tool-call targets before resuming a suspended run.
- `docs`: Update the multi-agent thread plan and layer-boundary review with completed runtime, approval, selector, export, and diagnostics phases.
- `packaging`: Clarify framework-only versus terminal-app installation paths in the README, including the `aceai[tui]` tool install flow.

### Fixes

- `tui`: Preserve active thread state across session switches and route stream rendering through the selected thread instead of mixing child output into the main transcript.
- `provider-auth`: Keep OpenAI/Codex authentication and provider setup behavior aligned with the app-layer runtime flow.

### Breaking Changes

- `app`: `AceAgentApp.start_turn_events()` now exposes `AgentAppEvent` envelopes for thread-aware consumers, while legacy `start_turn()` intentionally yields only the selected active thread's bare `AgentEvent` stream.
- `approvals`: `approve_tool()` and `reject_tool()` now validate concrete thread/run/tool-call targets when supplied; callers resuming non-active threads must pass matching identifiers instead of relying on global pending-approval state.
- `export`: Default `SessionStore.export_text()` now exports the main thread transcript only; callers that need child thread logs must pass `include_threads=True`.

## AceAI v0.2.21

### Features

- `subagents`: Add session-archived subagent audit artifacts so delegated runs can return compact model-facing handoffs while preserving the full child run result and tool outputs for export and replay.
- `context`: Add durable context checkpoint and compaction boundary support so oversized active runs can summarize older steps while keeping recent tool and response context available.

### Improvements

- `delegation`: Keep child agents unlimited by default by using `UNSET` for `child_max_steps`; explicit max-step budgets remain available for deliberate execution limits only.
- `tui`: Track delegated subagents with structured state and render subagent details, evidence, status, and archived results without flooding the main stream.
- `llm`: Improve streaming retry and context-window handling around compacted runs so provider failures and oversized context paths surface as structured AceAI events.

### Fixes

- `session`: Preserve subagent task, allowed tools, run id, summary, and tool-result metadata across session storage, export, and replay.
- `core`: Keep context compression from losing the current active step or reordering current-run summaries ahead of raw retained steps.

### Breaking Changes

- `delegation`: `delegate_to_subagent` now returns a `ToolExecutionOutput` with compact `model_output` and full JSON `output` instead of returning the child-result struct directly; callers must read the desired payload field explicitly.
- `context`: The compression policy now uses `recent_step_budget` instead of `keep_recent_messages`; callers constructing `ContextCompressionPolicy` must pass the new concrete argument.

## AceAI v0.2.20

### Improvements

- `llm`: Retry OpenAI `APIError` streaming failures such as overloaded-server responses so transient provider errors can recover through the existing retry path.
- `tui`: Show compact tool argument previews in work history rows so file paths, commands, and short parameters are visible without expanding raw details.

### Fixes

- `core`: Convert provider stream errors and failed LLM completions into structured run failures so the TUI and session state receive a `run_failed` event instead of an uncaught exception.
- `tui`: Support keyboard approval and rejection while a run is suspended for tool approval.

### Breaking Changes

- None.

## AceAI v0.2.19

### Features

- `tui`: Show compact context, cache-rate, cost, and elapsed-time status details while using provider catalog context windows to show usage percentage in the status bar and metadata view.
- `diagnostics`: Add a design spec for automatic Markdown diagnostic reports covering failed runs, sanitized transcripts, tool context, and CLI/TUI report entry points.

### Improvements

- `providers`: Record context-window sizes for OpenAI and DeepSeek models so UI and metadata can reason about model capacity without hard-coded status-bar logic.
- `tui`: Reset the current cache-rate indicator when switching models so stale cache metrics do not follow a new model selection.

### Fixes

- `tui`: Persist TUI model switches back to the project `.aceai/config.yml`, updating both `model` and `default_model` so restarted sessions use the model selected in the UI.
- `core`: Convert tool argument decode and validation failures into `ToolExecutionError`, allowing invalid model-supplied arguments to return as structured tool failures instead of crashing the run.

### Breaking Changes

- None.

## AceAI v0.2.18

### Improvements

- `tui`: Label skill entries by source in the Tools tab so global, project, and AceAI built-in skills are visible without inspecting filesystem paths.

### Fixes

- `llm`: Split streaming timeouts into a longer first-event window and a shorter post-start idle window so slower OpenAI Responses startup does not trigger repeated retries while stalled streams still fail promptly after output begins.

### Breaking Changes

- `llm`: `LLMService` now accepts `stream_start_timeout_seconds` before `stream_event_timeout_seconds`; callers using positional timeout arguments must pass these values with keywords or update the positional order.

## AceAI v0.2.17

### Features

- `tui`: Move skill selection into the Tools tab and add a project-skill discovery flow that searches the current workspace for new `SKILL.md` files and loads selected candidates on demand.

### Improvements

- `skills`: Change the default project skill directory to `.agents/skills` under the current working directory to align project-level skill links with Codex.
- `tui`: Hide already loaded skills from the new-skill candidate list and remove the deprecated saved path controls from the configuration screen.

### Fixes

- `tui`: Report invalid or unreadable skill paths as configuration notices instead of crashing when opening the config screen.

### Breaking Changes

- `skills`: Replace the default project auto-scan path `.agent/skills` with `.agents/skills`; project operators must move or link project skills into `.agents/skills` for automatic loading.

## AceAI v0.2.16

### Features

- `skills`: Ship Anthropic's public `skill-creator` as an AceAI built-in skill so installed AceAI apps include `$skill-creator` without a separate user install.
- `agent`: Rename the sub-agent delegation tool to `delegate_to_subagent`, making the model-facing tool name describe both the delegation action and the sub-agent target.

### Improvements

- `skills`: Add app-layer built-in skill paths behind `build_ace_agent(...)` while keeping `skill_path="disable"` as the explicit way to turn off all skills.
- `release`: Add third-party notices for the vendored `skill-creator` source, upstream commit, and Apache 2.0 license path.

### Fixes

- `tui`: Keep built-in skills enabled by default in selected-skill configurations, including older configs that only listed project skills such as `aceai-release`.
- `skills`: Let user-installed skills override same-name built-ins so global or project `skill-creator` installs take precedence over the packaged default.

### Breaking Changes

- `agent`: Replace the model-facing `delegate_task` tool and `build_delegate_task_tool()` helper with `delegate_to_subagent` and `build_delegate_to_subagent_tool()`.

## AceAI v0.2.15

### Features

- `tui`: Replace `/idea` list output with an interactive idea picker that supports keyboard selection, Enter-to-reference, `e` editing, and `d` deletion from the highlighted idea.

### Improvements

- `ideas`: List, search, edit, and delete ideas in FIFO order so the oldest saved idea remains first and picker numbering stays stable.
- `tui`: Render ideas as bordered panels in the picker while keeping creation timestamps aligned with terminal-cell-aware title truncation.

### Fixes

- `tui`: Intercept TextArea Enter handling before it inserts a newline so normal prompts submit, slash-command candidates complete, and completed slash commands execute.
- `tui`: Intercept slash-command up/down keys before TextArea cursor movement so command candidates can be selected with the keyboard.

### Breaking Changes

- `core`: Rename `AgentBase` to `Agent`; import from `aceai` or `aceai.core`.

## AceAI v0.2.14

### Features

- `tui`: Add a compact custom top bar with dedicated quit, config, debug, and clock controls while removing the default footer shortcut strip.
- `tui`: Add a Labrador pixel-art empty state in the main stream pane so new sessions start with a centered visual prompt instead of `No events yet`.
- `tui`: Add an interactive slash-command palette with one command per row, descriptions, keyboard navigation, and Enter/Tab selection.
- `tools`: Add per-tool enabled-state and maximum-call configuration so app tools can be disabled or capped independently from approval policy.

### Improvements

- `tui`: Simplify command names by keeping `/config`, `/sessions`, and `/stats` as the primary configuration, session, and usage commands.
- `tui`: Move runtime statistics behind `/stats` and clickable usage/cost chrome while keeping model display read-only in the status bar.
- `config`: Remove the System Prompt tab from the TUI config screen and focus configuration on provider, model, skills, and app tool controls.
- `tools`: Remove built-in max-call defaults from app tools so limits are explicit user configuration instead of hidden tool metadata.

### Fixes

- `tui`: Avoid startup layout artifacts where empty-state text or top-bar controls could collapse into unreadable vertical or ellipsized fragments.
- `tui`: Ensure Enter in slash-command mode completes the selected command instead of inserting a newline.

### Breaking Changes

- `config`: `tool_permissions` now accepts only `always` or `ask`; disable tools with `tool_enabled: {tool_name: false}` instead of `tool_permissions: {tool_name: never}`.

## AceAI v0.2.13

### Features

- `tui`: Add queued-turn workflow — type a new question while the agent is running and it automatically runs after the current turn completes, with a clickable queue widget above the input bar.
- `tui`: Add escape-to-cancel with a two-press arming pattern — first Escape arms the cancel, second Escape cancels the running turn, with a status-bar notice during the arm window.
- `tui`: Add `/steer <message>` command to cancel the active run in-place and replace it with a new prompt while preserving the queued turn backlog.

### Improvements

- `tui`: Render saved ideas as a formatted idea list with title, creation date, and body panel instead of a plain-text session notice.
- `tui`: Show `/idea` output as a dedicated `idea_list` transcript entry with styled group rendering instead of a single `session_notice` line.
- `agent`: Expose `cancel_active_turn`, `enqueue_turn`, `pop_queued_turn`, and `take_queued_turn` on `AceAgentApp` so TUI layer can manage active-run lifecycle with a typed contract.

### Fixes

- `tui`: Keep terminal run-control events (`run_completed`, `run_failed`, `run_suspended`) from being treated as restored-transcript events so they correctly update the run status in state transitions.

### Breaking Changes

- None.

## AceAI v0.2.12

### Features

- `ideas`: Add persistent idea capture with `IdeaStore` and `/idea` commands — agents and users can save, list, and delete ideas scoped to the current workspace, with ideas surfaced in the TUI transcript.
- `release`: Add project-local `aceai-release` skill with the release sequence, PR message template, category rules, tag timing, and PyPI publishing verification.

### Improvements

- `tui`: Add `/idea` command with `save`, `list`, and `delete` sub-commands, including idea capture from agent runs.
- `ci`: Restrict GitHub Pages deployment to `master` so version branches can build docs without attempting protected Pages deployments.
- `ci`: Add `v*` tag-push trigger for the PyPI publish job.

### Fixes

- `repo`: Remove `.cache/plugin/social` from git tracking and ignore local plugin cache files.

### Breaking Changes

- None.

## AceAI v0.2.11

### Improvements

- `llm`: Standardize provider cache accounting around cache hits divided by cache-accounted input tokens, with OpenAI and DeepSeek adapting their provider-specific usage fields into one AceAI-owned `LLMUsage` contract.
- `tui`: Move run status and model to the left side of the status bar, rename `ctx` to `context`, add cache-rate display, and render running/completed states with compact symbols.
- `tui`: Show session resume, model-switch, and provider-switch feedback as short-lived queued status-bar notices instead of persistent transcript events.
- `dev`: Add Ruff to the managed development dependency set.

### Fixes

- `sessions`: Migrate legacy usage payloads when loading saved events so older assistant messages derive cache miss and hit-rate fields from existing token data.
- `tui`: Keep replayed historical sessions from displaying a running status unless replay includes a terminal run-control event.
- `tui`: Queue multiple short-lived notices so consecutive resume/model-switch notifications display in order instead of overwriting each other.

### Breaking Changes

- None.

## AceAI v0.2.10

### Fixes

- `tui`: Keep collapsed work history directly below the user input and above the assistant answer after a run completes, including replay orders where assistant text is seen before the tool activity.

### Breaking Changes

- None.

## AceAI v0.2.9

### Fixes

- `tui`: Remove the `packaging` runtime import from the update checker so `aceai` can start in the published `uv tool` environment.
- `packaging`: Move `httpx` into runtime dependencies because `aceai.llm.service` imports it directly for provider transport retry handling.

### Breaking Changes

- None.

## AceAI v0.2.8

### Features

- `tui`: Add automatic update checks against PyPI on startup so users are notified when a newer AceAI release is available.
- `tui`: Add `/update` self-upgrade flow that runs `uv tool upgrade aceai` and restarts the current AceAI process after a successful upgrade.

### Improvements

- `llm`: Add exponential retry for retryable provider transport, timeout, rate-limit, and 5xx failures, with structured retry progress events for streaming runs.
- `tui`: Render LLM retry progress in the transcript so interrupted provider streams show visible recovery attempts instead of appearing stuck.
- `tui`: Improve session replay and tool work history rendering so restored sessions preserve more of the original execution timeline.
- `sessions`: Persist and replay LLM retry events so transient provider failures remain visible in saved transcripts.

### Fixes

- `llm`: Recover from incomplete streamed HTTP responses such as `RemoteProtocolError: peer closed connection without sending complete message body` by retrying the stream request.
- `llm`: Treat stalled streaming reads as retryable after a 3-second per-event timeout so network disconnects do not wait indefinitely for the next provider chunk.
- `tui`: Show a final "please try again later" assistant message after retry exhaustion instead of letting provider transport failures crash the TUI with a traceback.
- `tui`: Report self-update command failures in the transcript instead of silently failing when `uv` or the upgrade command cannot run.

### Breaking Changes

- `llm`: `LLMStreamEvent.event_type` now includes `response.retrying`; stream consumers with exhaustive event handling must handle or ignore this new event type.
- `core`: Agent event consumers may now receive `agent.llm.retrying` events during streaming runs.

## AceAI v0.2.7

### Features

- `config`: Add project-level `.aceai/config.yml` support with startup precedence over the global `~/.aceai/config.yaml` fallback.
- `permissions`: Add per-tool app permissions with `always`, `ask`, and `never` policies that control whether tools execute directly, require approval, or stay hidden from the model.
- `tui`: Add a dedicated Tools tab in the config screen with per-tool permission dropdowns plus `Allow all` and `Disable all` bulk actions.

### Improvements

- `config`: Persist config changes from the TUI back into the current project while preserving explicit path overrides for tests and tooling.
- `agent`: Apply configured tool permissions when building the default Ace agent without mutating the module-level tool objects.
- `docs`: Document project config precedence and the user-facing semantics of tool permission values.

### Fixes

- `tests`: Isolate CLI config tests from a developer machine's real saved AceAI config so local `~/.aceai/config.yaml` cannot change expected behavior.
- `packaging`: Keep the `aceai.agent` package import light enough for the base `aceai` command to show the optional TUI dependency hint instead of importing session storage dependencies too early.

### Breaking Changes

- `config`: `save_config()` without an explicit path now writes `.aceai/config.yml` in the current project instead of `~/.aceai/config.yaml`; callers that need global config writes must pass `default_config_path()` explicitly.
- `agent`: Remove session and app facade re-exports from `aceai.agent`; callers must import `AceAgentApp`, session models, event stores, and `SessionService` from their concrete modules.

## AceAI v0.2.6

### Features

- `core`: Add `AgentRuntime` with explicit runtime state, pending approval tracking, and resumable human-in-the-loop tool approval flow.
- `tools`: Add approval policy metadata for app tools, including filesystem write and shell command approval requirements.
- `tui`: Add inline approval controls for suspended tool calls with clickable `A Approve` / `R Reject` actions and keyboard shortcuts.
- `sessions`: Persist and export tool approval requested/resolved events so saved runs show the human-in-the-loop decision chain.

### Improvements

- `runtime`: Collapse executor-owned pending approval fields into core runtime state so tool approval, resume, and run status share one source of truth.
- `tui`: Route initial runtime execution and approval resume streams through one shared event consumer so suspended/completed handling cannot drift between paths.
- `tui`: Keep approval controls compact and near the input area while preserving readable transcript rendering.
- `sessions`: Mark unresolved restored approvals as expired in the transcript instead of showing non-actionable approval buttons.

### Fixes

- `sessions`: Omit unresolved assistant tool calls from replayed LLM history so resumed conversations no longer trigger provider errors about missing tool messages.
- `tui`: Show the next approval prompt when a resumed approval flow suspends again for a subsequent tool call.
- `tui`: Keep restored pending approval history visible without pretending old approvals can still be clicked.

### Breaking Changes

- `core`: Rename `AgentRun` to `AgentRuntime` and `AgentRunState` to `AgentRuntimeState`; callers must use the new runtime naming.
- `executor`: Replace executor-owned run state with `ToolRunState`; custom executors must accept the updated `tool_state` contract.

## AceAI v0.2.5

### Features

- `cli`: Add `aceai export <session_id> --file=<path>` to write session exports to a new file without overwriting existing files.
- `agent`: Let default Ace agents run without a fixed step cap unless callers set `max_steps`.
- `tui`: Add a metadata/config screen for runtime state, usage, loaded skills, local tools, and hosted tools via `i`, `/config`, `/metadata`, and `/info`.
- `sessions`: Persist per-session app state such as the selected provider and model so resumed sessions restore their runtime choice.

### Improvements

- `sessions`: Decouple durable session storage from TUI display events with explicit session/TUI adapters.
- `cost`: Move usage-cost estimates out of the TUI layer so session recording and display can share the same app-layer cost model.
- `tui`: Batch small streaming text deltas before rendering to reduce full-transcript redraw pressure for long answers.
- `tui`: Restyle the main transcript with full-width prompt bands, lighter assistant text, compact tool summaries, and a shorter right-aligned status bar.
- `tools`: Report app tool filesystem, shell, timeout, and text-replacement failures as tool results the model can observe and recover from.

### Fixes

- `tui`: Preserve masked API keys when applying model/provider selection so switching no longer reports a missing key after showing one.
- `tui`: Require provider, model, and API key before applying model-selection changes.
- `tui`: Keep metadata/config content scrollable while leaving the close action visible.

### Breaking Changes

- `sessions`: Remove the storage-layer `SessionStore.load_tui_events()` and `messages_to_tui_events()` TUI helpers; TUI callers must use `aceai.agent.tui.session_adapter`.
- `core`: `AgentBase.max_steps` now defaults to unset/unlimited instead of `5`, and `build_ace_agent()` no longer sets an app-specific step cap.

## AceAI v0.2.4

### Features

- `deepseek`: Add DeepSeek as a supported provider using the OpenAI-compatible chat completions API, including streaming text, reasoning content, tool calls, and token usage.
- `models`: Move supported providers, default models, model lists, and token pricing into a provider catalog so app defaults can be maintained outside provider code.
- `tui`: Replace model selection with provider and model text inputs that support progressive autocomplete, keyboard selection, and provider-specific API key lookup.

### Improvements

- `tui`: Show masked API keys as `*****************xxxx` and automatically reuse stored provider keys without exposing secrets in the selector.
- `tui`: Render streamed reasoning before the answer content it belongs to, and keep reasoning visible for models that expose thinking output.
- `cost`: Restore live cost estimates for DeepSeek by consuming streamed usage chunks and centralizing model pricing through the provider catalog.
- `ci`: Add wheel build and install smoke tests, including the base install hint for users who launch the TUI without the optional `tui` dependencies.

### Fixes

- `cli`: Keep TUI dependencies optional and show the correct `aceai[tui]` installation hint instead of failing with a raw missing-module traceback.
- `tui`: Restore command-input cleanup after submitting a prompt and preserve API keys when switching between providers.

### Breaking Changes

- `config`: Replace the legacy top-level `api_key` config field with provider-scoped `api_keys`; users should store keys under `api_keys.<provider>`.

## AceAI v0.2.3

### Features

- `tui`: Add token usage and estimated cost tracking to live runs, restored sessions, the status bar, and session browsing.
- `cli`: Add `aceai cost` for the total estimated cost across saved sessions, and allow `aceai resume` to reopen the latest updated session when no session id is provided.

### Improvements

- `sessions`: Persist assistant usage and cost metadata with compact session messages so restored transcripts keep their accounting context.
- `openai`: Capture cached input token usage from OpenAI Responses usage details.
- `tui`: Keep restored transcript events out of the execution timeline and improve stream rendering coverage for restored sessions and long content.

### Breaking Changes

- `cli`: Remove direct one-shot question execution from `aceai <question>`; launch `aceai` and submit the question inside the TUI instead.

## AceAI v0.2.0

### Features

- `skills`: Add filesystem skill discovery and loading through `Skill`, `SkillLoader`, and `SkillRegistry`, including support for `SKILL.md` frontmatter and bundled `references/`, `scripts/`, and `assets/` resources.
- `agent`: Register `skills_list` and `skill_view` tools on `ToolExecutor` so agents can discover matching skills and progressively load full instructions or supporting files during a run.
- `tools`: Expand built-in tooling and schemas used by skill-aware agent workflows.

### Improvements

- `skills-e2e`: Add deep progressive-disclosure e2e coverage based on a mature skill pattern, including multi-step loading of entry instructions, references, scripts, and assets.
- `docs-ci`: Restrict GitHub Pages deployment to `master`, allowing `version/**` branches to build docs without attempting protected Pages deployments.
- `release`: Add an `aceai-release` project skill documenting the release sequence, PR message format, category rules, tag timing, and PyPI publishing checks.
- `repo hygiene`: Ignore local plugin cache files and remove `.cache/plugin/social` from git tracking.

### Fixes

- `skills`: Validate malformed skill frontmatter and duplicate skill names with explicit configuration errors.
- `agent`: Keep skill tools scoped to tool-enabled agents and preserve existing executor behavior when no skills are configured.

### Breaking Changes

- None.

## AceAI v0.1.9

### Features

1. support "self"  arg in tool

```python

@tool
def off_load_context(self: AgentBase, )
```

2. support tool tag for grouping tools
3. support max tool usage per run 
4. tool registry & dynamic tool description

## AceAI v0.1.8

### Highlights
- Release automation now infers the target version from the current `version/<x.y.z>` branch when `--version` is omitted, and `make release` no longer forces a placeholder `VERSION`.
- Agent surface simplified: `BufferedStreamingAgent` export removed, streaming deltas remain unbuffered and no longer hydrate `reasoning_log` by default.
- Agent instruction handling now deduplicates added instructions while keeping `system_message` in sync.

### Tooling
- `scripts/release.py` adds branch-based version parsing with validation and keeps `--version` optional; `make release` conditionally forwards the flag and avoids fake defaults.
- Added regression coverage for release version inference from branch names.

### Breaking
- `aceai.agent.BufferedStreamingAgent` is gone; importers must use `AgentBase`.
- `AgentBase.instructions` attribute was removed; consumers should rely on `add_instruction` + `system_message`.

## AceAI v0.1.7

### Highlights
- `Tool` description precedence now prefers `tool(description=...)` over `func.__doc__` (also reflected in `tool_schema["description"]`).
- `AgentBase` prompt handling refactor: `prompt` seeds an `instructions` list, with `system_message` derived from accumulated instructions.
- Tracing overhaul: `agent.run` → `agent.step` → `llm.*` / `tool.*` spans are now parented via explicit `trace_ctx`, avoiding async-generator context detach errors and root-span fragmentation.
- OpenAI Responses support now surfaces structured output `segments` (reasoning/tool/media) and richer `LLMStreamEvent` mapping (tool deltas + image generation).

### Tracing / Observability
- `trace_ctx` is now threaded through `AgentBase`, `LLMService`, provider adapters, and `ToolExecutor` so downstream spans consistently inherit the same trace.
- Adds Langfuse-friendly span attributes: `langfuse.trace.name`, `langfuse.trace.input`, `langfuse.trace.output`.

### Docs / DX
- Added regression coverage for trace parenting and async-generator cancellation edge cases.
- Refactored agent tests for the `AgentBase` API changes and expanded tool description/schema coverage.

### Notes
- Breaking: `AgentBase.__init__` renamed `sys_prompt` -> `prompt`; max-step runtime error message changed to “Agent exceeded maximum steps: N without answering”.
- Breaking: provider implementers and tool executors must accept/pass through `trace_ctx` to keep spans correctly chained.
- Tracing: `ToolExecutor` span attribute changed from `tool.arguments.raw_len` to `tool.arguments` (larger attribute payloads).
