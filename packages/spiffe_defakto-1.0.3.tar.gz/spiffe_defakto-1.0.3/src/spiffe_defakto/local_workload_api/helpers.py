"""Internal helpers shared by the local and attesting Workload API clients.

These functions translate between the generated protobuf types and the SDK's
public value classes. They are not part of the public API.
"""

from __future__ import annotations

import base64
import json
import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

import grpc
from cryptography import x509
from cryptography.hazmat.primitives import serialization

from ..errors import SpiffeError, SpiffeErrorCode
from ..jwtsvid.types import JwtBundle, JwtSVID
from ..spiffe_id import SpiffeID, TrustDomain
from ..x509svid.marshal import extract_spiffe_id_from_cert
from ..x509svid.types import X509SVID, X509Bundle

if TYPE_CHECKING:
    from collections.abc import Mapping

_log = logging.getLogger(__name__)


def _split_der_chain(data: bytes) -> list[bytes]:
    """Split a buffer of concatenated DER SEQUENCEs into individual entries.

    The SPIFFE Workload API encodes both certificate chains and trust bundles
    as the concatenation of DER-encoded ``SEQUENCE`` structures (see RFC 5280).
    Each element begins with tag ``0x30`` followed by a DER length (short or
    long form). We walk the buffer, yielding each framed SEQUENCE.
    """
    certs: list[bytes] = []
    offset = 0
    length = len(data)

    while offset < length:
        if data[offset] != 0x30:
            break
        if offset + 2 > length:
            break

        first_len_byte = data[offset + 1]
        if (first_len_byte & 0x80) == 0:
            content_len = first_len_byte
            header_len = 2
        else:
            num_len_bytes = first_len_byte & 0x7F
            if offset + 2 + num_len_bytes > length:
                break
            content_len = int.from_bytes(data[offset + 2 : offset + 2 + num_len_bytes], "big")
            header_len = 2 + num_len_bytes

        total_len = header_len + content_len
        if offset + total_len > length:
            break
        certs.append(bytes(data[offset : offset + total_len]))
        offset += total_len

    return certs


def _load_private_key(der: bytes) -> Any:
    try:
        return serialization.load_der_private_key(der, password=None)
    except ValueError as exc:
        raise SpiffeError(
            SpiffeErrorCode.SVID_INVALID,
            "Cannot load private key from PKCS#8 DER",
            cause=exc,
        ) from exc


def parse_proto_x509_svid(proto: Any) -> X509SVID:
    """Translate a proto ``X509SVID`` message into the SDK's :class:`X509SVID`.

    Cross-checks the SPIFFE ID declared by the Workload API against the one
    encoded into the leaf certificate's SubjectAltName. A mismatch means
    either the agent is buggy or the channel has been tampered with — either
    way the caller should not trust the declared identity.
    """
    der_chain = _split_der_chain(bytes(proto.x509_svid))
    if not der_chain:
        raise SpiffeError(SpiffeErrorCode.SVID_INVALID, "Empty certificate chain in SVID")

    certificates = tuple(x509.load_der_x509_certificate(der) for der in der_chain)
    leaf = certificates[0]

    try:
        declared_id = SpiffeID.parse(proto.spiffe_id)
    except SpiffeError as exc:
        raise SpiffeError(
            SpiffeErrorCode.SVID_INVALID,
            f"Invalid SPIFFE ID in SVID: {proto.spiffe_id}",
            cause=exc,
        ) from exc

    cert_id = extract_spiffe_id_from_cert(leaf)
    if cert_id != declared_id:
        raise SpiffeError(
            SpiffeErrorCode.SVID_INVALID,
            f"SPIFFE ID mismatch: response declared {declared_id!s} but "
            f"leaf certificate SAN carries {cert_id!s}",
        )

    private_key = _load_private_key(bytes(proto.x509_svid_key))
    return X509SVID(
        id=declared_id,
        certificates=certificates,
        private_key=private_key,
        expires_at=leaf.not_valid_after_utc,
    )


def parse_x509_bundle(trust_domain: TrustDomain, data: bytes) -> X509Bundle:
    if not data:
        return X509Bundle(trust_domain=trust_domain, x509_authorities=())
    # DER SEQUENCEs (the encoding the SPIFFE Workload API spec calls for) start
    # with tag byte 0x30. Anything else we route through the PEM loader, which
    # handles leading whitespace and any of the BEGIN-marker variants. Some
    # signers (notably go-spiffe's x509bundle.Bundle.Marshal()) emit PEM, so we
    # accept it rather than fail closed on the encoding.
    if data[0] == 0x30:
        der_chain = _split_der_chain(data)
        authorities = tuple(x509.load_der_x509_certificate(der) for der in der_chain)
    else:
        authorities = tuple(x509.load_pem_x509_certificates(data))
    return X509Bundle(trust_domain=trust_domain, x509_authorities=authorities)


def parse_x509_bundles_map(bundles_map: Mapping[str, bytes]) -> dict[str, X509Bundle]:
    """Turn a ``{trust_domain_name: bundle_der}`` proto map into our bundle map.

    Malformed individual entries are silently skipped — matching the TS SDK's
    behaviour so that a single bad federated bundle can't break the rest.
    """
    result: dict[str, X509Bundle] = {}
    for domain_name, der_bytes in bundles_map.items():
        try:
            td = TrustDomain.parse(domain_name)
            result[td.name] = parse_x509_bundle(td, bytes(der_bytes))
        except (SpiffeError, ValueError) as exc:
            _log.warning("Skipping malformed X.509 bundle for %r: %s", domain_name, exc)
    return result


def parse_x509_svid_response(
    svids: list[Any], federated: Mapping[str, bytes]
) -> tuple[tuple[X509SVID, ...], dict[str, X509Bundle]]:
    """Extract SVIDs + combined own/federated bundles from the proto response."""
    parsed_svids = tuple(parse_proto_x509_svid(s) for s in svids)

    bundles: dict[str, X509Bundle] = {}

    for proto_svid in svids:
        bundle_bytes = bytes(proto_svid.bundle)
        if not bundle_bytes:
            continue
        try:
            td = SpiffeID.parse(proto_svid.spiffe_id).trust_domain
            bundles[td.name] = parse_x509_bundle(td, bundle_bytes)
        except SpiffeError:
            continue

    bundles.update(parse_x509_bundles_map(federated))
    return parsed_svids, bundles


def parse_jwt_bundle(trust_domain: TrustDomain, data: bytes) -> JwtBundle:
    try:
        jwks = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise SpiffeError(
            SpiffeErrorCode.WORKLOAD_API_ERROR,
            "Malformed JWT bundle payload",
            cause=exc,
        ) from exc

    authorities: dict[str, Mapping[str, Any]] = {}
    for key in jwks.get("keys", []):
        kid = key.get("kid") if isinstance(key, dict) else None
        if isinstance(kid, str) and kid:
            authorities[kid] = key
    return JwtBundle(trust_domain=trust_domain, jwt_authorities=authorities)


def parse_jwt_bundles_map(bundles_map: Mapping[str, bytes]) -> dict[str, JwtBundle]:
    result: dict[str, JwtBundle] = {}
    for domain_name, data in bundles_map.items():
        try:
            td = TrustDomain.parse(domain_name)
            result[td.name] = parse_jwt_bundle(td, bytes(data))
        except SpiffeError as exc:
            _log.warning("Skipping malformed JWT bundle for %r: %s", domain_name, exc)
    return result


def parse_jwt_svid_from_proto(proto: Any) -> JwtSVID:
    token = proto.svid
    parts = token.split(".")
    if len(parts) != 3:
        raise SpiffeError(
            SpiffeErrorCode.SVID_INVALID,
            "Invalid JWT format in SVID response",
        )

    try:
        spiffe_id = SpiffeID.parse(proto.spiffe_id)
    except SpiffeError as exc:
        raise SpiffeError(
            SpiffeErrorCode.SVID_INVALID,
            f"Invalid SPIFFE ID in JWT-SVID: {proto.spiffe_id}",
            cause=exc,
        ) from exc

    try:
        padded = parts[1] + "=" * (-len(parts[1]) % 4)
        payload_bytes = base64.urlsafe_b64decode(padded)
        payload: dict[str, Any] = json.loads(payload_bytes)
    except (ValueError, UnicodeDecodeError) as exc:
        raise SpiffeError(
            SpiffeErrorCode.SVID_INVALID,
            "Cannot decode JWT payload in SVID response",
            cause=exc,
        ) from exc

    exp = payload.get("exp")
    expires_at = (
        datetime.fromtimestamp(float(exp), tz=timezone.utc)
        if isinstance(exp, (int, float))
        else datetime.fromtimestamp(0, tz=timezone.utc)
    )

    raw_aud = payload.get("aud")
    if isinstance(raw_aud, list):
        audience = tuple(a for a in raw_aud if isinstance(a, str))
    elif isinstance(raw_aud, str):
        audience = (raw_aud,)
    else:
        audience = ()

    return JwtSVID(
        id=spiffe_id,
        audience=audience,
        expires_at=expires_at,
        token=token,
        claims=payload,
    )


def parse_first_jwt_svid(svids: list[Any]) -> JwtSVID:
    if not svids:
        raise SpiffeError(SpiffeErrorCode.WORKLOAD_API_ERROR, "No JWT SVIDs in response")
    return parse_jwt_svid_from_proto(svids[0])


def wrap_rpc_error(exc: BaseException, *, for_attestation: bool = False) -> SpiffeError:
    """Convert a ``grpc.aio`` error into the appropriate :class:`SpiffeError`.

    When ``for_attestation`` is ``True``, authentication/permission failures
    are surfaced as ``ATTESTATION_FAILED`` — the endpoint rejected the
    attestation rather than the transport failing.
    """
    code = getattr(exc, "code", None)
    try:
        code_value = code() if callable(code) else code
    except TypeError:
        code_value = code

    if code_value is grpc.StatusCode.UNAVAILABLE:
        return SpiffeError(
            SpiffeErrorCode.WORKLOAD_API_UNAVAILABLE,
            "SPIFFE endpoint is unavailable",
            cause=exc,
        )
    if for_attestation and code_value in (
        grpc.StatusCode.PERMISSION_DENIED,
        grpc.StatusCode.UNAUTHENTICATED,
    ):
        return SpiffeError(
            SpiffeErrorCode.ATTESTATION_FAILED,
            "Attestation rejected by endpoint",
            cause=exc,
        )
    return SpiffeError(
        SpiffeErrorCode.WORKLOAD_API_ERROR,
        str(exc),
        cause=exc,
    )
