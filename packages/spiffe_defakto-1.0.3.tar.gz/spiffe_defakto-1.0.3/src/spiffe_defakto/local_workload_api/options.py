"""Transport options for :class:`LocalWorkloadAPIClient`."""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Union

from ..errors import SpiffeError, SpiffeErrorCode

_SOCKET_ENV = "SPIFFE_ENDPOINT_SOCKET"


@dataclass(frozen=True, slots=True)
class UnixOptions:
    """Connect to a local Defakto agent over a Unix domain socket."""

    socket_path: str
    transport: str = "unix"


@dataclass(frozen=True, slots=True)
class TcpOptions:
    """Connect to a SPIFFE endpoint over TCP, optionally with TLS disabled."""

    address: str
    port: int
    insecure_skip_tls: bool = False
    transport: str = "tcp"


ClientOptions = Union[UnixOptions, TcpOptions]


def resolve_client_options(options: ClientOptions | None) -> ClientOptions:
    """Return a concrete ``ClientOptions``.

    Priority:

    1. An explicit ``options`` argument wins.
    2. Otherwise consults the ``SPIFFE_ENDPOINT_SOCKET`` env var, accepting the
       SPIFFE endpoint URI schemes ``unix:///path``, ``unix://path``, and
       ``unix:path``.
    3. If neither is configured, raises :class:`SpiffeError` with code
       ``SOCKET_PATH_NOT_CONFIGURED``.
    """
    if options is not None:
        return options

    env_socket = os.environ.get(_SOCKET_ENV)
    if not env_socket:
        raise SpiffeError(
            SpiffeErrorCode.SOCKET_PATH_NOT_CONFIGURED,
            f"No socket path configured. Set {_SOCKET_ENV} or pass socket_path explicitly.",
        )
    return UnixOptions(socket_path=_strip_unix_prefix(env_socket))


def _strip_unix_prefix(value: str) -> str:
    # Matches the SPIFFE endpoint URI forms supported by the TS SDK:
    #   unix:///abs/path    -> /abs/path  (absolute)
    #   unix://rel/path     -> rel/path   (relative)
    #   unix:rel/path       -> rel/path   (relative)
    if value.startswith("unix://"):
        return value[len("unix://") :]  # retains leading "/" if present
    if value.startswith("unix:"):
        return value[len("unix:") :]
    return value
