"""GCP Workload Identity Federation credentials backed by a SPIFFE JWT SVID."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from .._internal.extras import missing_extra
from .._internal.sync_bridge import run_coro
from ..jwtsvid.types import JwtSVIDSource
from ..workload_api.client import WorkloadAPIClient

if TYPE_CHECKING:
    from google.auth.identity_pool import Credentials


@dataclass(frozen=True, slots=True)
class SPIFFEIdentityPoolClientOptions:
    """Options for :class:`SPIFFEIdentityPoolClient`."""

    source: JwtSVIDSource | None = None
    """JWT SVID source. Defaults to ``WorkloadAPIClient().jwt`` eagerly."""

    audience: str | None = None
    """Workload Identity Pool audience. Falls back to
    ``GOOGLE_CLOUD_WORKLOAD_IDENTITY_POOL``."""

    svid_audience: str | tuple[str, ...] | None = None
    service_account_impersonation_url: str | None = None
    project_id: str | None = None
    universe_domain: str | None = None
    quota_project_id: str | None = None

    extra_info: dict[str, object] = field(default_factory=dict)


def SPIFFEIdentityPoolClient(  # noqa: N802 - class-like factory
    options: SPIFFEIdentityPoolClientOptions | None = None,
) -> Credentials:
    """Return a ``google-auth`` ``Credentials`` instance that authenticates via SPIFFE.

    The object is usable anywhere ``google-auth`` credentials are accepted —
    pass it as ``credentials=`` to any Google Cloud client library.
    """
    try:
        from google.auth import identity_pool
    except ImportError:
        missing_extra("gcp", "spiffe_defakto.gcp.SPIFFEIdentityPoolClient")

    opts = options or SPIFFEIdentityPoolClientOptions()
    audience = opts.audience or os.environ.get("GOOGLE_CLOUD_WORKLOAD_IDENTITY_POOL")
    if not audience:
        raise ValueError(
            "audience must be provided via options or GOOGLE_CLOUD_WORKLOAD_IDENTITY_POOL "
            "environment variable"
        )

    # Construct the default source on the shared :class:`SyncRunner` loop so
    # its gRPC channel binds to the same loop :func:`run_coro` dispatches
    # refresh callbacks on. Otherwise — when the factory is invoked from
    # inside an already-running loop like ADK's or uvicorn's — the channel
    # ends up loop-bound to the caller while refreshes run on the runner,
    # and ``grpc.aio`` raises ``Task ... got Future ... attached to a
    # different loop`` on the first STS exchange.
    source = opts.source if opts.source is not None else run_coro(_build_default_source())
    svid_audience = opts.svid_audience or audience
    audiences = [svid_audience] if isinstance(svid_audience, str) else list(svid_audience)

    impersonation_url = opts.service_account_impersonation_url
    if impersonation_url is None:
        sa_email = os.environ.get("CLOUDSDK_AUTH_IMPERSONATE_SERVICE_ACCOUNT")
        if sa_email:
            impersonation_url = (
                f"https://iamcredentials.googleapis.com/v1/projects/-/serviceAccounts/"
                f"{sa_email}:generateAccessToken"
            )

    class _SpiffeSupplier(identity_pool.SubjectTokenSupplier):
        def get_subject_token(self, context: Any, request: Any) -> str:
            del context, request  # unused — requirement of google-auth supplier interface
            return run_coro(source.fetch_svid(audiences)).token

    credentials = identity_pool.Credentials(  # type: ignore[no-untyped-call]
        audience=audience,
        subject_token_type="urn:ietf:params:oauth:token-type:jwt",
        token_url="https://sts.googleapis.com/v1/token",
        subject_token_supplier=_SpiffeSupplier(),
        service_account_impersonation_url=impersonation_url,
    )

    project_id = opts.project_id or os.environ.get("GOOGLE_CLOUD_PROJECT")
    if project_id:
        credentials._project_id = project_id
    if opts.universe_domain is not None:
        credentials._universe_domain = opts.universe_domain
    quota_project = opts.quota_project_id or os.environ.get("GOOGLE_CLOUD_QUOTA_PROJECT")
    if quota_project:
        credentials = credentials.with_quota_project(quota_project)

    return credentials


async def _build_default_source() -> JwtSVIDSource:
    """Build :class:`WorkloadAPIClient` from within the shared runner loop."""
    return WorkloadAPIClient().jwt
