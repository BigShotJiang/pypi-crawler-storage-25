"""The auto-selecting Workload API client.

Chooses between :class:`LocalWorkloadAPIClient` and
:class:`AttestingWorkloadAPIClient` based on the environment, so the same
application code works unchanged whether it runs next to a Defakto agent or on
AWS Lambda.
"""

from __future__ import annotations

import os
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Union

from ..attesting_workload_api import AttestingClientOptions, AttestingWorkloadAPIClient
from ..local_workload_api import LocalWorkloadAPIClient

if TYPE_CHECKING:
    from ..jwtsvid.types import JwtBundle, JwtSVID
    from ..spiffe_id import TrustDomain
    from ..x509svid.types import X509SVID, X509Bundle
    from .context import X509Context


_SOCKET_ENV = "SPIFFE_ENDPOINT_SOCKET"
_ATTESTORS_ENV = "DEFAKTO_ATTESTORS"

_InnerClient = Union[LocalWorkloadAPIClient, AttestingWorkloadAPIClient]


class WorkloadAPIClient:
    """Environment-driven smart wrapper.

    Selection priority:

    1. ``SPIFFE_ENDPOINT_SOCKET`` set → :class:`LocalWorkloadAPIClient`.
    2. ``DEFAKTO_ATTESTORS`` set → :class:`AttestingWorkloadAPIClient`.
    3. Otherwise :class:`LocalWorkloadAPIClient` is constructed, which in turn
       raises :class:`SpiffeError` with code ``SOCKET_PATH_NOT_CONFIGURED``.

    Both inner clients expose the same ``x509``, ``jwt``,
    :meth:`watch_x509_context`, and :meth:`close` surface, so this wrapper is
    a drop-in for either.
    """

    def __init__(self) -> None:
        if os.environ.get(_SOCKET_ENV):
            self._inner: _InnerClient = LocalWorkloadAPIClient()
        elif os.environ.get(_ATTESTORS_ENV):
            self._inner = AttestingWorkloadAPIClient(AttestingClientOptions())
        else:
            # Let LocalWorkloadAPIClient raise the canonical error.
            self._inner = LocalWorkloadAPIClient()

        self.x509 = self._inner.x509
        self.jwt = self._inner.jwt

    async def get_svid(self) -> X509SVID:  # convenience short-cut
        return await self.x509.get_svid()

    async def get_bundle_for_trust_domain(self, trust_domain: TrustDomain) -> X509Bundle:
        return await self.x509.get_bundle_for_trust_domain(trust_domain)

    async def fetch_jwt_svid(self, audiences: list[str]) -> JwtSVID:
        return await self.jwt.fetch_svid(audiences)

    async def get_jwt_bundle(self, trust_domain: TrustDomain) -> JwtBundle:
        return await self.jwt.get_bundle_for_trust_domain(trust_domain)

    def watch_x509_context(self) -> AsyncIterator[X509Context]:
        return self._inner.watch_x509_context()

    async def close(self) -> None:
        await self._inner.close()

    async def __aenter__(self) -> WorkloadAPIClient:
        return self

    async def __aexit__(self, *_exc_info: object) -> None:
        await self.close()
