"""The Defakto attesting Workload API client.

Designed for serverless and ephemeral environments where a persistent Defakto
agent is not practical. Each operation runs the full attestation handshake:
evidence is collected from every configured :class:`Attestor` concurrently,
sent to the Defakto endpoint, and exchanged for an SVID.

:meth:`watch_x509_context` polls rather than streams — it yields a context,
then waits until 85 % of the SVID lifetime has elapsed before re-attesting.
"""

from __future__ import annotations

import asyncio
import os
import re
from collections.abc import AsyncIterator
from datetime import datetime, timezone
from typing import TYPE_CHECKING

import grpc

from .._generated.alpha.serverlessapi import api_pb2, api_pb2_grpc
from .._internal.channel import build_channel
from ..attestation.types import AttestationEvidence, Attestor
from ..errors import SpiffeError, SpiffeErrorCode
from ..jwtsvid.types import JwtBundle, JwtSVID
from ..local_workload_api.helpers import wrap_rpc_error
from ..local_workload_api.options import TcpOptions
from ..spiffe_id import TrustDomain
from ..workload_api.context import X509Context
from ..x509svid.types import X509SVID, X509Bundle
from .helpers import (
    parse_serverless_jwt_bundles,
    parse_serverless_jwt_svid,
    parse_serverless_x509_bundles,
    parse_serverless_x509_response,
)
from .options import AttestingClientOptions

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable


_ATTESTORS_ENV = "DEFAKTO_ATTESTORS"
_TRUST_DOMAIN_ID_ENV = "DEFAKTO_TRUST_DOMAIN_ID"
_MIN_REFRESH_DELAY = 1.0  # seconds
_REFRESH_RATIO = 0.85


def _build_attestors_from_env() -> tuple[Attestor, ...]:
    value = os.environ.get(_ATTESTORS_ENV)
    if not value:
        return ()
    names = [n.strip().lower() for n in value.split(",") if n.strip()]
    if not names:
        return ()

    factories = _builtin_attestor_factories()
    attestors: list[Attestor] = []
    for name in names:
        factory = factories.get(name)
        if factory is None:
            raise SpiffeError(
                SpiffeErrorCode.NO_ATTESTORS_CONFIGURED,
                f"Unknown attestor name {name!r} in {_ATTESTORS_ENV}. Valid names: "
                f"{', '.join(factories)}.",
            )
        attestors.append(factory())
    return tuple(attestors)


def _builtin_attestor_factories() -> dict[str, Callable[[], Attestor]]:
    """Factory map for the string values accepted in ``DEFAKTO_ATTESTORS``.

    Imports are lazy so callers who only want (say) GCP attestation don't pay
    the boto3 / azure-identity import cost.
    """
    factories: dict[str, Callable[[], Attestor]] = {}

    def _aws() -> Attestor:
        from ..attestors.aws_token import AwsTokenAttestor

        return AwsTokenAttestor()

    def _azure() -> Attestor:
        from ..attestors.azure_msi import AzureMSIAttestor

        return AzureMSIAttestor()

    def _gcp() -> Attestor:
        from ..attestors.gcp_iit import GcpIITAttestor

        return GcpIITAttestor()

    factories["aws_external_identity"] = _aws
    factories["azure_managed_identity"] = _azure
    factories["gcp_service_account"] = _gcp
    return factories


async def _collect_attestations(
    attestors: Iterable[Attestor],
) -> list[api_pb2.MethodAttestation]:
    try:
        evidences = await asyncio.gather(*(a.collect_evidence() for a in attestors))
    except SpiffeError:
        raise
    except Exception as exc:
        raise SpiffeError(
            SpiffeErrorCode.ATTESTOR_COLLECTION_FAILED,
            "One or more attestors failed to collect evidence",
            cause=exc,
        ) from exc
    return [_evidence_to_proto(e) for e in evidences]


def _evidence_to_proto(evidence: AttestationEvidence) -> api_pb2.MethodAttestation:
    return api_pb2.MethodAttestation(
        method_type=evidence.plugin_name,
        method_version=evidence.plugin_version,
        evidence=evidence.payload,
    )


_TRUST_DOMAIN_ID_PATTERN = re.compile(r"^[a-z0-9][a-z0-9\-]*$")


def _validate_trust_domain_id(value: str) -> str:
    if not _TRUST_DOMAIN_ID_PATTERN.fullmatch(value):
        raise SpiffeError(
            SpiffeErrorCode.INVALID_TRUST_DOMAIN,
            f"Invalid DEFAKTO_TRUST_DOMAIN_ID {value!r}: must match ^[a-z0-9][a-z0-9-]*$",
        )
    return value


class _X509Source:
    __slots__ = ("_client",)

    def __init__(self, client: AttestingWorkloadAPIClient) -> None:
        self._client = client

    async def get_svid(self) -> X509SVID:
        ctx = await self._client._fetch_x509_context()
        return ctx.default_svid()

    async def get_bundle_for_trust_domain(self, trust_domain: TrustDomain) -> X509Bundle:
        return await self._client._get_x509_bundle(trust_domain)

    def watch_svid(self) -> AsyncIterator[X509SVID]:
        async def _iter() -> AsyncIterator[X509SVID]:
            async for ctx in self._client.watch_x509_context():
                yield ctx.default_svid()

        return _iter()


class _JwtSource:
    __slots__ = ("_client",)

    def __init__(self, client: AttestingWorkloadAPIClient) -> None:
        self._client = client

    async def fetch_svid(self, audiences: list[str]) -> JwtSVID:
        return await self._client._fetch_jwt_svid(audiences)

    async def get_bundle_for_trust_domain(self, trust_domain: TrustDomain) -> JwtBundle:
        return await self._client._get_jwt_bundle(trust_domain)


class AttestingWorkloadAPIClient:
    """Client for Defakto's attesting Workload API."""

    x509: _X509Source
    jwt: _JwtSource

    def __init__(self, options: AttestingClientOptions | None = None) -> None:
        opts = options or AttestingClientOptions()

        attestors = opts.attestors or _build_attestors_from_env()
        if not attestors:
            raise SpiffeError(
                SpiffeErrorCode.NO_ATTESTORS_CONFIGURED,
                "At least one attestor must be configured "
                f"(via options.attestors or {_ATTESTORS_ENV})",
            )

        transport = opts.transport
        if transport is None:
            trust_domain_id = opts.trust_domain_id or os.environ.get(_TRUST_DOMAIN_ID_ENV)
            if trust_domain_id:
                transport = TcpOptions(
                    address=f"{_validate_trust_domain_id(trust_domain_id)}.agent.spirl.com",
                    port=443,
                )
            else:
                raise SpiffeError(
                    SpiffeErrorCode.SOCKET_PATH_NOT_CONFIGURED,
                    "trust_domain_id or transport must be provided (or set "
                    f"{_TRUST_DOMAIN_ID_ENV})",
                )

        self._channel = build_channel(transport)
        self._stub = api_pb2_grpc.SpiffeWorkloadAPIStub(self._channel)
        self._attestors = tuple(attestors)
        self._closed = False
        self._cancel_events: set[asyncio.Event] = set()

        self.x509 = _X509Source(self)
        self.jwt = _JwtSource(self)

    # ------------------------------------------------------------------ X.509
    async def _fetch_x509_context(self) -> X509Context:
        attestations = await _collect_attestations(self._attestors)
        try:
            response = await self._stub.FetchX509SVID(
                api_pb2.FetchX509SVIDRequest(attestations=attestations)
            )
        except grpc.aio.AioRpcError as exc:
            raise wrap_rpc_error(exc, for_attestation=True) from exc
        svids, bundles = parse_serverless_x509_response(response)
        return X509Context(svids=svids, bundles=bundles)

    async def _get_x509_bundle(self, trust_domain: TrustDomain) -> X509Bundle:
        attestations = await _collect_attestations(self._attestors)
        try:
            response = await self._stub.FetchX509Bundles(
                api_pb2.FetchX509BundlesRequest(attestations=attestations)
            )
        except grpc.aio.AioRpcError as exc:
            raise wrap_rpc_error(exc, for_attestation=True) from exc
        bundles = parse_serverless_x509_bundles(response)
        bundle = bundles.get(trust_domain.name)
        if bundle is None:
            raise SpiffeError(
                SpiffeErrorCode.BUNDLE_NOT_FOUND,
                f"No X.509 bundle found for trust domain {trust_domain.name!r}",
            )
        return bundle

    # ------------------------------------------------------------------ JWT
    async def _fetch_jwt_svid(self, audiences: list[str]) -> JwtSVID:
        attestations = await _collect_attestations(self._attestors)
        try:
            response = await self._stub.FetchJWTSVID(
                api_pb2.FetchJWTSVIDRequest(attestations=attestations, audience=audiences)
            )
        except grpc.aio.AioRpcError as exc:
            raise wrap_rpc_error(exc, for_attestation=True) from exc
        return parse_serverless_jwt_svid(response)

    async def _get_jwt_bundle(self, trust_domain: TrustDomain) -> JwtBundle:
        attestations = await _collect_attestations(self._attestors)
        try:
            response = await self._stub.FetchJWTBundles(
                api_pb2.FetchJWTBundlesRequest(attestations=attestations)
            )
        except grpc.aio.AioRpcError as exc:
            raise wrap_rpc_error(exc, for_attestation=True) from exc
        bundles = parse_serverless_jwt_bundles(response)
        bundle = bundles.get(trust_domain.name)
        if bundle is None:
            raise SpiffeError(
                SpiffeErrorCode.BUNDLE_NOT_FOUND,
                f"No JWT bundle found for trust domain {trust_domain.name!r}",
            )
        return bundle

    # ------------------------------------------------------------------ watch
    async def watch_x509_context(self) -> AsyncIterator[X509Context]:
        """Yield a new :class:`X509Context` as each SVID nears expiry.

        Re-attestation fires when 85 % of the current SVID's remaining
        lifetime has elapsed, subject to a 1-second floor. The loop ends when
        :meth:`close` is called.
        """
        cancel = asyncio.Event()
        self._cancel_events.add(cancel)
        try:
            while not self._closed:
                try:
                    ctx = await self._fetch_x509_context()
                except asyncio.CancelledError:
                    return
                yield ctx
                delay = _refresh_delay(ctx.default_svid().expires_at)
                if await _wait_with_cancel(delay, cancel):
                    return
        finally:
            self._cancel_events.discard(cancel)

    # ------------------------------------------------------------------ cleanup
    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        for event in list(self._cancel_events):
            event.set()
        self._cancel_events.clear()
        # Close any attestor that holds external resources (e.g. AzureMSI's
        # aiohttp session). Best-effort — one attestor failing to close
        # shouldn't prevent the others from cleaning up.
        for attestor in self._attestors:
            closer = getattr(attestor, "close", None)
            if callable(closer):
                try:
                    result = closer()
                    if asyncio.iscoroutine(result):
                        await result
                except Exception:
                    pass
        await self._channel.close()

    async def __aenter__(self) -> AttestingWorkloadAPIClient:
        return self

    async def __aexit__(self, *_exc_info: object) -> None:
        await self.close()


def _refresh_delay(expires_at: datetime) -> float:
    remaining = (expires_at - datetime.now(tz=timezone.utc)).total_seconds()
    return max(_MIN_REFRESH_DELAY, remaining * _REFRESH_RATIO)


async def _wait_with_cancel(seconds: float, cancel: asyncio.Event) -> bool:
    """Sleep ``seconds`` unless ``cancel`` is set. Returns ``True`` if cancelled."""
    try:
        await asyncio.wait_for(cancel.wait(), timeout=seconds)
    except asyncio.TimeoutError:
        return False
    return True
