"""An Azure :class:`~azure.core.credentials.TokenCredential` backed by a SPIFFE SVID.

Enables Azure workload identity federation: no secrets or certificates — the
SPIFFE SVID proves the workload's identity to Azure AD via
:class:`azure.identity.ClientAssertionCredential`.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from .._internal.extras import missing_extra
from .._internal.sync_bridge import run_coro
from ..jwtsvid.types import JwtSVIDSource
from ..workload_api.client import WorkloadAPIClient

if TYPE_CHECKING:
    from typing import Any

_DEFAULT_AUDIENCE = "api://AzureADTokenExchange"


@dataclass(frozen=True, slots=True)
class SPIFFECredentialOptions:
    """Options for :class:`SPIFFECredential`."""

    source: JwtSVIDSource | None = None
    """JWT SVID source. Defaults to ``WorkloadAPIClient().jwt`` constructed eagerly."""

    tenant_id: str | None = None
    """Azure AD tenant. Falls back to ``AZURE_TENANT_ID``."""

    client_id: str | None = None
    """Azure AD application (client) ID. Falls back to ``AZURE_CLIENT_ID``."""

    svid_audience: str | tuple[str, ...] = _DEFAULT_AUDIENCE

    credential_kwargs: dict[str, object] = field(default_factory=dict)
    """Extra keyword arguments passed to the inner ``ClientAssertionCredential``."""


class SPIFFECredential:
    """A drop-in replacement for :class:`DefaultAzureCredential` using a SPIFFE SVID."""

    def __init__(self, options: SPIFFECredentialOptions | None = None) -> None:
        try:
            from azure.identity import ClientAssertionCredential
        except ImportError:
            missing_extra("azure", "spiffe_defakto.azure.SPIFFECredential")

        opts = options or SPIFFECredentialOptions()
        tenant_id = opts.tenant_id or os.environ.get("AZURE_TENANT_ID")
        if not tenant_id:
            raise ValueError(
                "tenant_id must be provided via options or AZURE_TENANT_ID environment variable"
            )
        client_id = opts.client_id or os.environ.get("AZURE_CLIENT_ID")
        if not client_id:
            raise ValueError(
                "client_id must be provided via options or AZURE_CLIENT_ID environment variable"
            )

        # Build the default source inside the shared :class:`SyncRunner` loop
        # so its gRPC channel binds to the same loop :func:`run_coro` uses
        # for refresh callbacks. See ``spiffe_defakto.gcp.identity_pool`` for
        # the full rationale.
        source = opts.source if opts.source is not None else run_coro(_build_default_source())
        audiences = (
            [opts.svid_audience]
            if isinstance(opts.svid_audience, str)
            else list(opts.svid_audience)
        )

        credential_kwargs = dict(opts.credential_kwargs)
        if "authority" not in credential_kwargs:
            authority = os.environ.get("AZURE_AUTHORITY_HOST")
            if authority:
                credential_kwargs["authority"] = authority

        def _assertion() -> str:
            return run_coro(source.fetch_svid(audiences)).token

        self._inner = ClientAssertionCredential(
            tenant_id=tenant_id,
            client_id=client_id,
            func=_assertion,
            **credential_kwargs,
        )

    def get_token(self, *scopes: str, **kwargs: Any) -> Any:
        """Delegate to the wrapped :class:`ClientAssertionCredential`."""
        return self._inner.get_token(*scopes, **kwargs)

    def close(self) -> None:
        close = getattr(self._inner, "close", None)
        if callable(close):
            close()

    def __enter__(self) -> SPIFFECredential:
        return self

    def __exit__(self, *_exc_info: object) -> None:
        self.close()


async def _build_default_source() -> JwtSVIDSource:
    """Build :class:`WorkloadAPIClient` from within the shared runner loop."""
    return WorkloadAPIClient().jwt
