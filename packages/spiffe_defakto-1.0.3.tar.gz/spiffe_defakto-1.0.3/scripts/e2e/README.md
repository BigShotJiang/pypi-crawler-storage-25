# End-to-end tests against a real Defakto agent

These scripts validate the SDK against a **real** Defakto agent running in a
Kubernetes cluster (rather than the in-process gRPC fake used by the unit
suite). Run them when changing anything that touches the wire format or
transport: chain parsing, private-key decoding, JWT verification,
reconnect logic, etc.

## What's verified

| Script | Scenario |
| --- | --- |
| `test_sdk.py`        | `x509.get_svid`, `x509.get_bundle_for_trust_domain`, `jwt.fetch_svid`, `jwt.get_bundle_for_trust_domain`, `watch_x509_context`, PEM marshal/parse round-trip |
| `test_jwt_verify.py` | Fetch a JWT-SVID, verify it against the same agent's bundle, and assert the audience-mismatch rejection path |
| `test_fastapi.py`    | Drive a FastAPI app against the real agent via `httpx.ASGITransport` |
| `test_sync.py`       | Full `SyncWorkloadAPIClient` surface: `get_svid`, `fetch_jwt_svid`, blocking `watch_x509_context` iterator |
| `test_verify.py`     | Fetch the current SVID's DER chain and validate it through `verify_x509_svid` against the agent's own bundle |

## Prerequisites

- `kubectl` configured against a cluster with the Defakto agent DaemonSet
  and the `csi.spiffe.io` CSI driver installed. During development this is
  typically a kind cluster brought up by `tilt up` against the Defakto
  customer cluster setup.
- A namespace + ServiceAccount that the Defakto controller has a matching
  attestation policy for (the demo installation uses
  `namespace: spiffe-demo`, `serviceAccount: spiffe-demo-app`).

## Running

```sh
# From the repo root.

# 1) Build a wheel.
uv build

# 2) Spin up a test pod. Adjust the namespace/ServiceAccount in pod.yaml
#    if your cluster uses different attestation names.
kubectl --context kind-spirl-customer-k8s apply -f scripts/e2e/pod.yaml
kubectl --context kind-spirl-customer-k8s wait --for=condition=Ready \
    pod/spiffe-python-e2e -n spiffe-demo --timeout=60s

# 3) Ship the wheel in, install it, run each test.
kubectl --context kind-spirl-customer-k8s cp \
    dist/spiffe_defakto-0.1.0-py3-none-any.whl \
    spiffe-demo/spiffe-python-e2e:/tmp/spiffe_defakto-0.1.0-py3-none-any.whl

kubectl --context kind-spirl-customer-k8s exec -n spiffe-demo \
    spiffe-python-e2e -- pip install --quiet \
        /tmp/spiffe_defakto-0.1.0-py3-none-any.whl fastapi httpx

for script in scripts/e2e/test_*.py; do
    name=$(basename "$script")
    kubectl --context kind-spirl-customer-k8s cp "$script" \
        "spiffe-demo/spiffe-python-e2e:/tmp/$name"
    kubectl --context kind-spirl-customer-k8s exec -n spiffe-demo \
        spiffe-python-e2e -- python "/tmp/$name" || exit 1
done

# 4) Clean up.
kubectl --context kind-spirl-customer-k8s delete -f scripts/e2e/pod.yaml
```

## Last validation run

Date: 2026-04-20
Cluster: `kind-spirl-customer-k8s` (Defakto customer Tiltfile)
Trust domain: `example.com`
SVID path: `/tilt-realm/dev-helm-cluster/ns/spiffe-demo/sa/spiffe-demo-app`

All four scripts passed with zero errors.
