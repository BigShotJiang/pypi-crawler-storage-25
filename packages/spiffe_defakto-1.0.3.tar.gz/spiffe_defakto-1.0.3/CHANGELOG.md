# Changelog

All notable changes to `spiffe-defakto` are documented here.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/)
and the project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.3] — 2026-04-30

### Fixed

- **`parse_x509_bundle`**: accept PEM-encoded X.509 trust bundles in addition
  to the spec-required concatenated DER. Some Workload API signers — notably
  go-spiffe's `x509bundle.Bundle.Marshal()` — emit PEM, which the DER-only
  parser was silently turning into an empty `X509Bundle`. Affects every
  X.509 bundle path: `client.x509.get_bundle_for_trust_domain(...)`, the
  per-SVID embedded bundle on `FetchX509SVID`, and the federated bundles
  map. mTLS verification against peers in such trust domains now works
  without a workaround. Discrimination is by the leading byte (`0x30` =
  DER `SEQUENCE` tag); anything else is routed through cryptography's PEM
  loader, which handles whitespace and the various BEGIN-marker variants.

## [1.0.2] — 2026-04-30

### Changed

- **Docs**: rebrand `SPIRE` references to `Defakto` across the README,
  framework guides, examples, and source-code docstrings. Neutralize
  prose `spirl-agent` / `SPIRL Tilt` mentions in the demo app and e2e
  scripts. Real infrastructure identifiers (`agent.spirl.com` hostname,
  `kind-spirl-customer-k8s` cluster, `spirl-agent-socket` volume names,
  generated `com.spirl.serverless.alpha` proto package) are unchanged.
- **Docs**: example socket paths now use the canonical CSI mount
  `unix:///run/spirl/socket/agent.sock` rather than placeholder values.
- **Docs**: drop two leaked local-machine paths (`~/Code/spirl`) from
  `examples/demo-app/README.md` and `scripts/e2e/README.md`.

No code changes; package contents are byte-identical to 1.0.1 apart
from documentation strings.

## [1.0.1] — 2026-04-22

### Fixed

- **`SPIFFEIdentityPoolClient`, `SPIFFECredential`, `from_spiffe`**: the
  default `WorkloadAPIClient` is now constructed on the shared
  `SyncRunner` loop (via `run_coro`) instead of the caller's ambient
  loop. Fixes `RuntimeError: Task ... got Future ... attached to a
  different loop` when any of the three cloud credential factories are
  invoked from inside an already-running event loop (e.g. ADK, uvicorn,
  Starlette, FastAPI) and `google-auth` / `azure-identity` / `boto3`
  later fires a refresh callback. Users who pass an explicit `source=`
  are unaffected.

## [1.0.0] — 2026-04-21

First stable release. Published to PyPI as
[`spiffe-defakto`](https://pypi.org/project/spiffe-defakto/).

### Added

#### Core clients
- `WorkloadAPIClient` — smart wrapper that auto-selects between the local
  and the attesting clients based on the environment
  (`SPIFFE_ENDPOINT_SOCKET` → local, `DEFAKTO_ATTESTORS` → attesting).
- `LocalWorkloadAPIClient` — SPIFFE Workload API gRPC client over Unix
  socket or TCP, with streaming `watch_x509_context()` and automatic
  reconnect with jittered backoff.
- `AttestingWorkloadAPIClient` — inline attestation for serverless and
  ephemeral environments, with polling rotation at 85 % of the SVID
  lifetime.
- `SyncWorkloadAPIClient` — blocking facade over the async API for
  scripts, Flask, Django sync views, Celery workers, and other non-async
  frameworks.

#### Attestation
- Built-in attestors: `AwsTokenAttestor` (STS `GetWebIdentityToken`),
  `AzureMSIAttestor` (Azure Managed Identity), `GcpIITAttestor` (GCE
  Instance Identity Token).
- Custom attestor support via the `Attestor` protocol (concurrent
  evidence collection through `asyncio.gather`).

#### SVID types and utilities
- X.509 and JWT SVID value types (frozen dataclasses), trust-bundle
  types, and source protocols (`X509SVIDSource`, `X509BundleSource`,
  `JwtSVIDSource`, `JwtBundleSource`).
- `X509Context` with `default_svid()`.
- PEM marshal/parse (`marshal_x509_svid`, `parse_marshaled_x509_svid`).
- `verify_x509_svid(raw_certs, bundle_source, options=None)` — validate
  a peer's X.509 SVID chain against a trust bundle. Enforces the SPIFFE
  leaf-SVID constraints (non-root path, non-CA leaf, no `keyCertSign` /
  `cRLSign` key usage), expiry on every certificate in the chain, and
  chain-signature verification back to one of the bundle's trust
  authorities. Supports RSA, ECDSA, and Ed25519 leaf keys.
- `parse_and_validate_jwt_svid(token, bundle_source, expected_audiences)`
  — JWT-SVID verification with the SPIFFE algorithm allowlist.
- `JwtClaims` — `TypedDict` for the standard JWT-SVID claim shape
  (`sub`, `aud`, `exp`, `iat`, `iss`, `jti`, `nbf`). Gives IDE
  autocomplete and static typing for the well-known claim names;
  custom claims stay accessible via `JwtSVID.claims`.

#### Identity value types
- `SpiffeID` and `TrustDomain` with strict parsing.
- `SpiffeError` + `SpiffeErrorCode` (14-code enum) for structured error
  handling.

#### Cloud credential integrations (optional extras)
- `spiffe_defakto.aws.from_spiffe` → `botocore.RefreshableCredentials`
  via STS `AssumeRoleWithWebIdentity` (`pip install 'spiffe-defakto[aws]'`).
- `spiffe_defakto.azure.SPIFFECredential` → Azure `TokenCredential`
  backed by `ClientAssertionCredential`
  (`pip install 'spiffe-defakto[azure]'`).
- `spiffe_defakto.gcp.SPIFFEIdentityPoolClient` → `google-auth`
  identity-pool credentials with optional service-account impersonation
  (`pip install 'spiffe-defakto[gcp]'`).

#### Tooling and docs
- Framework integration guides for FastAPI, Starlette, aiohttp, Quart,
  Flask, Django (sync + async), Celery, AnyIO, Trio, and plain
  `asyncio`, with runnable examples.
- Demo app at `examples/demo-app/` — a FastAPI service with a browser
  UI that renders the current SPIFFE ID, a live expiry countdown,
  trust-bundle details, and a JWT-SVID minting form.
- Real-agent end-to-end test scripts at `scripts/e2e/` that run against
  a real Defakto agent in a kind cluster.
- `py.typed` marker shipped; strict `mypy` enforcement across the SDK,
  tests, examples, and scripts.
- CI matrix across Python 3.10 – 3.13 on Ubuntu and macOS, plus a
  dedicated framework-integration job and a full-repo strict-typecheck
  job.

### Security hardening (vs. the TypeScript SDK)
- Cross-check the declared SPIFFE ID in each X509 SVID response against
  the leaf certificate's SubjectAltName — rejects tampered responses.
- Regex-validate `DEFAKTO_TRUST_DOMAIN_ID` before hostname
  interpolation into the attesting endpoint.
- Warn on `insecure_skip_tls` against non-loopback addresses.
- Case-insensitive SPIFFE URI scheme matching (RFC 3986 § 3.1).
- Reconnect backoff on `watch_x509_context` to prevent CPU-spinning
  against a misbehaving agent.
