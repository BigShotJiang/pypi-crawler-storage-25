#!/usr/bin/env python3
"""
TFGaurd Standalone — Portable Terraform Security Scanner
========================================================
Version: 1.0.0
Author: TFGaurd Team
License: MIT
Download: curl -sSL https://tfgaurd.com/install.sh | bash

Usage:
  tfgaurd scan .                  # Free scan (Terminal output only)
  tfgaurd scan . --api-key XXX     # Premium scan + Cloud Visibility
  tfgaurd version                 # Check version
"""

import sys, os, json, time, argparse, platform, socket, glob, gzip, hashlib
from pathlib import Path
from datetime import datetime, timezone

# ── 1. INLINED CORE LOGIC (from utils/parser.py) ─────────────────────────────
import hcl2  # Only external dependency

def parse_terraform(input_data):
    """Standalone HCL2 parser"""
    try:
        # If input_data is a multiline string or has 'resource '
        if '\n' in input_data or 'resource ' in input_data:
            tf_dict = hcl2.loads(input_data)
        else:
            with open(input_data, 'r', encoding='utf-8') as f:
                tf_dict = hcl2.load(f)
        
        raw_resources = tf_dict.get('resource', [])
        flattened = []
        
        # Consistent format: [{type: {name: config}}, ...]
        if isinstance(raw_resources, list):
            for item in raw_resources:
                for r_type, r_map in item.items():
                    for name, config in r_map.items():
                        flattened.append({r_type: {name: config}})
        else:
            for r_type, r_map in raw_resources.items():
                for name, config in r_map.items():
                    flattened.append({r_type: {name: config}})
        return flattened
    except Exception as e:
        return []

# ── 2. INLINED FREE AWS RULES ────────────────────────────────────────────────
# These run entirely offline, no API key needed.

def _ingress_open(r, port):
    for rule in (r.get('ingress') or []):
        if not rule: continue
        cidrs = rule.get('cidr_blocks', []) or []
        fp = int(rule.get('from_port', 0) or 0)
        tp = int(rule.get('to_port', 0) or 0)
        if ('0.0.0.0/0' in cidrs or '::/0' in (rule.get('ipv6_cidr_blocks') or [])) and fp <= port <= tp:
            return True
    return False

# ── 2. CORE AWS SECURITY RULES (FREE) ──────────────────────────────────────────

# S3 Rules
def check_s3_public(r):
    if r.get('acl') in ['public-read', 'public-read-write']: return 'S3 bucket is public (acl: ' + r.get('acl') + ')'
    if not r.get('block_public_acls', True): return 'S3 bucket does not block public ACLs'
    return None
def check_s3_mfa_delete(r):
    v = r.get('versioning', {}); v = (v[0] if isinstance(v, list) else v) or {}
    if not v.get('mfa_delete', False): return 'S3 MFA Delete not enabled'
def check_s3_logging_disabled(r):
    if not r.get('logging'): return 'S3 access logging is disabled'
def check_s3_versioning_disabled(r):
    v = r.get('versioning', {}); v = (v[0] if isinstance(v, list) else v) or {}
    if not v.get('enabled', False): return 'S3 bucket versioning is disabled'
def check_s3_kms_not_used(r):
    sse = (r.get('server_side_encryption_configuration') or [{}])[0].get('rule', [{}])[0].get('apply_server_side_encryption_by_default', {})
    if sse.get('sse_algorithm') == 'AES256': return 'S3 uses AES256, prefer aws:kms'

# EC2 Rules
def check_ec2_public(r):
    if r.get('associate_public_ip_address', False): return 'EC2 instance has public IP'
    return None
def check_ec2_root_unencrypted(r):
    rbd = (r.get('root_block_device') or [{}])[0]
    if not rbd.get('encrypted', False): return 'EC2 root volume not encrypted'
def check_ec2_imds_v2_required(r):
    mo = (r.get('metadata_options') or [{}])[0]
    if mo.get('http_tokens') != 'required': return 'EC2 does not require IMDSv2'
def check_ec2_no_instance_profile(r):
    if not r.get('iam_instance_profile'): return 'EC2 missing IAM instance profile'

# RDS Rules
def check_db_encrypted(r):
    if not r.get('storage_encrypted', False): return 'RDS Database not encrypted'
    return None
def check_db_public(r):
    if r.get('publicly_accessible', False): return 'RDS is publicly accessible'
def check_db_no_iam_auth(r):
    if not r.get('iam_database_authentication_enabled', False): return 'RDS IAM DB authentication disabled'
def check_db_no_performance_insights(r):
    if not r.get('performance_insights_enabled'): return 'RDS Performance Insights disabled'

# SG Rules
def check_sg_ssh_open(r):
    if _ingress_open(r, 22): return 'SSH (Port 22) open to world'
def check_sg_rdp_open(r):
    if _ingress_open(r, 3389): return 'RDP (Port 3389) open to world'
def check_sg_db_open(r):
    for p in [3306, 5432, 1433, 1521, 27017]:
        if _ingress_open(r, p): return f'Database port ({p}) open to world'
def check_sg_all_ports_open(r):
    for rule in (r.get('ingress') or []):
        if not rule: continue
        if '0.0.0.0/0' in (rule.get('cidr_blocks') or []) and int(rule.get('from_port', 1) or 1) == 0:
            return 'All ports open to world'

# Mapping for the free engine
FREE_REGISTRY = {
    'aws_s3_bucket': [check_s3_public, check_s3_mfa_delete, check_s3_logging_disabled, check_s3_versioning_disabled, check_s3_kms_not_used],
    'aws_instance': [check_ec2_public, check_ec2_root_unencrypted, check_ec2_imds_v2_required, check_ec2_no_instance_profile],
    'aws_db_instance': [check_db_encrypted, check_db_public, check_db_no_iam_auth, check_db_no_performance_insights],
    'aws_security_group': [check_sg_ssh_open, check_sg_rdp_open, check_sg_db_open, check_sg_all_ports_open],
}

# ── 3. SCAN ENGINE ──────────────────────────────────────────────────────────

def get_severity(msg):
    m = msg.upper()
    if 'CRITICAL' in m: return 'CRITICAL'
    if 'HIGH' in m: return 'HIGH'
    if 'PUBLIC' in m or 'ENCRYPT' in m: return 'HIGH'
    return 'MEDIUM'

def local_free_scan(resources):
    violations = []
    for item in resources:
        for r_type, r_map in item.items():
            checks = FREE_REGISTRY.get(r_type, [])
            for r_name, r_config in r_map.items():
                for check in checks:
                    res = check(r_config)
                    if res:
                        violations.append({
                            "resource_type": r_type,
                            "resource_name": r_name,
                            "rule": check.__name__,
                            "violation": res,
                            "severity": get_severity(res)
                        })
    return violations

# ── 4. PREMIUM BUNDLE SUPPORT (Decryption + Exec) ────────────────────────────

def fetch_and_load_premium(api_key, server_url):
    """Download, decrypt, and load the premium registry into memory."""
    try:
        import requests as req
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        
        # Download
        resp = req.get(f"{server_url}/api/rules/bundle", headers={"X-API-Key": api_key}, timeout=20)
        if resp.status_code != 200: return None
        
        # Decrypt
        key = hashlib.sha256(api_key.encode()).digest()
        blob = resp.content
        nonce, ciphertext = blob[:12], blob[12:]
        aesgcm = AESGCM(key)
        source = gzip.decompress(aesgcm.decrypt(nonce, ciphertext, None)).decode("utf-8")
        
        # Execute
        ns = {"__builtins__": __builtins__}
        exec(source, ns)
        return ns.get("RULE_REGISTRY")
    except: return None

# ── 5. TERMINAL UI ────────────────────────────────────────────────────────────

def log(text, color=""):
    print(text)

# ── 6. MAIN ───────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(prog="tfgaurd")
    sub = parser.add_subparsers(dest="command")
    
    scan_p = sub.add_parser("scan")
    scan_p.add_argument("path", default=".")
    scan_p.add_argument("--api-key", default=os.getenv("TFGAURD_API_KEY"))
    scan_p.add_argument("--server", default="https://tfgaurd.com")
    
    args = parser.parse_args()
    
    if args.command == "scan":
        path = Path(args.path)
        files = [str(f) for f in path.rglob("*.tf")] if path.is_dir() else [str(path)]
        
        print(f"\nScanning {len(files)} files...")
        
        # ── SILENT TELEMETRY (Growth Tracking) ───────────────────────────────
        try:
            import requests as req
            # Determine if we are running from PyPI or Shell
            # We assume the standalone script itself can report as pypi for simplicity
            # since it's the heart of 'tfgaurd-engine'
            req.post(f"{args.server}/api/track-install", 
                   json={
                       "type": "pypi", 
                       "source": "cli_run", 
                       "os": platform.system()
                   }, 
                   timeout=2)
        except: pass

        
        # Try premium
        engine_fn = local_free_scan
        has_premium = False
        if args.api_key:
            print("☁ Downloading Premium rules...")
            registry = fetch_and_load_premium(args.api_key, args.server)
            if registry:
                has_premium = True
                print("✔ Premium rules loaded (GCP/Azure/OCI active).")
                # Wrap registry in a checker
                def premium_engine(resources):
                    v = []
                    for item in resources:
                        for rt, rm in item.items():
                            rules = registry.get(rt, [])
                            for rn, rc in rm.items():
                                for rule in rules:
                                    res = rule(rc)
                                    if res: v.append({
                                        "resource_type": rt, "resource_name": rn,
                                        "rule": rule.__name__, "violation": res,
                                        "severity": get_severity(res)
                                    })
                    return v
                engine_fn = premium_engine

        all_v = []
        for f in files:
            resources = parse_terraform(f)
            violations = engine_fn(resources)
            all_v.extend(violations)
            for v in violations:
                print(f"  [{v['severity']}] {v['resource_type']}.{v['resource_name']}: {v['violation']}")

        if not all_v:
             print("\n✔ PASSED: No security issues found.")
        else:
             print(f"\nFAILED: Found {len(all_v)} security issues.")
             
        # Upload metadata
        if args.api_key:
             try:
                 import requests as req
                 req.post(f"{args.server}/api/ingest", json={"total_files": len(files), "passed": not all_v, "total_violations": len(all_v), "files": []}, headers={"X-API-Key": args.api_key})
             except: pass

if __name__ == "__main__":
    main()
