"""Road Racer — dodge traffic in a top-down terminal racer."""

import curses
import math
import os
import random
import signal
import time

from ...constants import STOP_FILE

# ── Road layout (all widths in terminal columns) ──────────────────────────────
GRASS_W   = 4     # grass strip on each side
LANE_W    = 9     # width of each lane (must fit a 5-wide car + 2 padding each side)
N_LANES   = 3
N_DIVS    = N_LANES - 1   # lane dividers
ROAD_W    = GRASS_W + 1 + LANE_W * N_LANES + N_DIVS + 1 + GRASS_W   # = 39

# Positions relative to road_x (left edge of the full road+grass block)
_LEFT_BORDER  = GRASS_W                                        # col of left  ║
_RIGHT_BORDER = GRASS_W + 1 + LANE_W * N_LANES + N_DIVS       # col of right ║

def _lane_cx(lane: int) -> int:
    """Centre column of a lane, relative to road_x."""
    return GRASS_W + 1 + lane * (LANE_W + 1) + LANE_W // 2

LANE_CX = [_lane_cx(i) for i in range(N_LANES)]   # [9, 19, 29]

# ── Car sprites (5 wide × 4 tall, top-down view) ─────────────────────────────
CAR_W = 5
CAR_H = 4

PLAYER_SPRITE = [
    "▐▄█▄▌",   # front bumper  (▄ curves = rounded hood)
    "▐█░█▌",   # windshield    (░ = glass texture)
    "▐█░█▌",   # rear window
    "▐▀█▀▌",   # rear bumper   (▀ curves)
]

# Three enemy types — drawn in different colours
ENEMY_SPRITES = [
    ["▐▄▓▄▌", "▐▓░▓▌", "▐▓░▓▌", "▐▀▓▀▌"],   # Sedan   → red
    ["▐███▌",  "▐█ █▌", "▐█ █▌", "▐███▌"],   # Truck   → yellow (boxy)
    ["▐▄▄▄▌",  "▐░░░▌", "▐░░░▌", "▐▀▀▀▌"],   # Sports  → white  (wide glass)
]

# ── Physics constants ─────────────────────────────────────────────────────────
SPEED_INIT        = 10.0   # rows / sec (scroll speed)
SPEED_MAX         = 48.0
SPEED_ACCEL       = 1.2    # speed gain per real second
LANE_CHANGE_SPD   = 22.0   # cols / sec for smooth lane slide
SPAWN_INTERVAL    = 2.2    # initial seconds between enemy spawns
INVINCIBLE_T      = 2.0    # post-crash invincibility window (seconds)
LIVES_START       = 3
TARGET_FPS        = 30
FRAME_DT          = 1.0 / TARGET_FPS

TREE_PERIOD       = 7      # rows between roadside trees
DASH_PERIOD       = 5      # dash+gap length for lane dividers
DASH_LEN          = 2      # rows the dash is visible within each period


# ── Enemy car ─────────────────────────────────────────────────────────────────

class EnemyCar:
    def __init__(self, lane: int, y: float) -> None:
        self.lane       = lane
        self.y          = y
        self.spr_idx    = random.randint(0, len(ENEMY_SPRITES) - 1)

    def update(self, dt: float, speed: float) -> None:
        self.y += speed * dt

    def is_offscreen(self, h: int) -> bool:
        return self.y > h + CAR_H

    def draw(self, stdscr, road_x: int, color: int) -> None:
        h, w = stdscr.getmaxyx()
        x0   = road_x + LANE_CX[self.lane] - CAR_W // 2
        for dy, row in enumerate(ENEMY_SPRITES[self.spr_idx]):
            ry = int(self.y) + dy
            if 1 <= ry < h - 1 and 0 <= x0 and x0 + CAR_W < w:
                try:
                    stdscr.addstr(ry, x0, row, color)
                except curses.error:
                    pass

    def overlaps_player(self, player_x: float, player_y: int, road_x: int) -> bool:
        ex0 = road_x + LANE_CX[self.lane] - CAR_W // 2
        px0 = int(player_x)              - CAR_W // 2
        # x overlap
        if ex0 + CAR_W <= px0 or px0 + CAR_W <= ex0:
            return False
        # y overlap
        ey0 = int(self.y)
        if ey0 + CAR_H <= player_y or player_y + CAR_H <= ey0:
            return False
        return True


# ── Main game ─────────────────────────────────────────────────────────────────

def race_game(stdscr) -> None:
    curses.curs_set(0)
    stdscr.nodelay(True)
    stdscr.keypad(True)

    # ── colours ──
    if curses.has_colors():
        curses.start_color()
        curses.use_default_colors()
        curses.init_pair(1, curses.COLOR_CYAN,    -1)                    # player
        curses.init_pair(2, curses.COLOR_RED,     -1)                    # sedan
        curses.init_pair(3, curses.COLOR_YELLOW,  -1)                    # truck
        curses.init_pair(4, curses.COLOR_WHITE,   -1)                    # sports + dividers
        curses.init_pair(5, curses.COLOR_GREEN,   -1)                    # grass
        curses.init_pair(6, curses.COLOR_BLACK,   curses.COLOR_CYAN)     # HUD bar
        curses.init_pair(7, curses.COLOR_WHITE,   curses.COLOR_RED)      # crash flash
        C_PLAYER   = curses.color_pair(1) | curses.A_BOLD
        C_ENEMY    = [curses.color_pair(2) | curses.A_BOLD,
                      curses.color_pair(3) | curses.A_BOLD,
                      curses.color_pair(4) | curses.A_BOLD]
        C_GRASS    = curses.color_pair(5)
        C_TREE     = curses.color_pair(5) | curses.A_BOLD
        C_HUD      = curses.color_pair(6)
        C_DIV      = curses.color_pair(4) | curses.A_DIM
        C_BORDER   = curses.color_pair(4)
        C_CRASH    = curses.color_pair(7) | curses.A_BOLD
    else:
        C_PLAYER = curses.A_BOLD
        C_ENEMY  = [curses.A_NORMAL] * 3
        C_GRASS  = C_TREE = C_HUD = C_DIV = C_BORDER = C_CRASH = curses.A_NORMAL

    # ── state ──
    running       = True
    speed         = SPEED_INIT
    distance      = 0.0
    lives         = LIVES_START
    scroll_off    = 0.0   # scrolling offset for lane dividers
    tree_off      = 0.0   # scrolling offset for roadside trees

    player_lane   = 1                         # 0=left, 1=mid, 2=right
    h0, w0        = stdscr.getmaxyx()
    rx0           = max(0, (w0 - ROAD_W) // 2)
    player_x      = float(rx0 + LANE_CX[player_lane])
    player_tgt    = player_x

    invincible    = 0.0   # countdown: post-crash invincibility
    crash_flash   = 0.0   # countdown: crash label shown
    spawn_timer   = 0.0
    spawn_iv      = SPAWN_INTERVAL
    enemies: list = []

    last_tick  = time.monotonic()
    accumulate = 0.0

    def on_signal(sig, frame):
        nonlocal running
        running = False

    signal.signal(signal.SIGTERM, on_signal)
    signal.signal(signal.SIGINT,  on_signal)

    def _rx(w: int) -> int:
        return max(0, (w - ROAD_W) // 2)

    def _py(h: int) -> int:
        return h - CAR_H - 2

    # ── loop ──────────────────────────────────────────────────────────────────
    while running:
        if os.path.exists(STOP_FILE):
            try:
                os.unlink(STOP_FILE)
            except OSError:
                pass
            break

        now        = time.monotonic()
        frame_time = now - last_tick
        last_tick  = now
        accumulate += frame_time

        # ── drain input ──
        quit_pressed = False
        while True:
            key = stdscr.getch()
            if key == -1:
                break
            if key in (curses.KEY_LEFT, ord('a'), ord('A')):
                if player_lane > 0:
                    player_lane -= 1
            elif key in (curses.KEY_RIGHT, ord('d'), ord('D')):
                if player_lane < N_LANES - 1:
                    player_lane += 1
            elif key in (ord('q'), ord('Q')):
                quit_pressed = True
        if quit_pressed:
            break

        # ── fixed physics steps ──
        steps = 0
        while accumulate >= FRAME_DT and steps < 3:
            accumulate -= FRAME_DT
            dt = FRAME_DT
            steps += 1

            h, w = stdscr.getmaxyx()
            rx   = _rx(w)
            py   = _py(h)

            # Re-sync player target whenever lane or screen changes
            player_tgt = float(rx + LANE_CX[player_lane])

            # Smooth lane slide
            diff = player_tgt - player_x
            step = LANE_CHANGE_SPD * dt
            player_x = player_tgt if abs(diff) <= step else player_x + math.copysign(step, diff)

            # Speed ramp & distance
            speed    = min(SPEED_MAX, speed + SPEED_ACCEL * dt)
            distance += speed * dt * 0.05   # scale to km

            # Road animation offsets
            scroll_off += speed * dt
            tree_off   += speed * dt * 0.6

            # Timers
            invincible  = max(0.0, invincible  - dt)
            crash_flash = max(0.0, crash_flash - dt)

            # Enemy spawning
            spawn_timer -= dt
            if spawn_timer <= 0:
                # Pick a lane different from the last enemy if possible
                occ = {e.lane for e in enemies if e.y < 5}
                choices = [l for l in range(N_LANES) if l not in occ] or list(range(N_LANES))
                enemies.append(EnemyCar(random.choice(choices), 1.0))
                spawn_timer = max(0.35, spawn_iv - speed * 0.025)
                spawn_iv    = max(0.5,  spawn_iv - 0.015)

            # Update enemies
            for e in enemies[:]:
                e.update(dt, speed)
                if e.is_offscreen(h):
                    enemies.remove(e)

            # Collision
            if invincible <= 0:
                for e in enemies[:]:
                    if e.overlaps_player(player_x, py, rx):
                        lives      -= 1
                        invincible  = INVINCIBLE_T
                        crash_flash = 0.6
                        enemies.remove(e)
                        if lives <= 0:
                            running = False
                        break

        # ── draw ──────────────────────────────────────────────────────────────
        h, w = stdscr.getmaxyx()
        rx   = _rx(w)
        py   = _py(h)
        play_top    = 1
        play_bottom = h - 2

        stdscr.erase()

        # ── HUD ──
        score  = int(distance * 10)
        kmh    = int(speed * 3.6)
        hearts = "♥" * lives + "♡" * (LIVES_START - lives)
        hud    = f"  {hearts}   {kmh} km/h   {distance:.1f} km   Score: {score}  "
        try:
            stdscr.addstr(0, 0, hud[:w - 1].ljust(w - 1), C_HUD)
        except curses.error:
            pass

        # ── grass ──
        for y in range(play_top, play_bottom + 1):
            # left strip
            for x in range(rx, rx + GRASS_W):
                if 0 <= x < w:
                    try:
                        stdscr.addstr(y, x, "▓", C_GRASS)
                    except curses.error:
                        pass
            # right strip
            for x in range(rx + _RIGHT_BORDER + 1, rx + ROAD_W):
                if 0 <= x < w:
                    try:
                        stdscr.addstr(y, x, "▓", C_GRASS)
                    except curses.error:
                        pass

        # ── scrolling roadside trees ──
        for y in range(play_top, play_bottom + 1):
            if (y + int(tree_off)) % TREE_PERIOD == 0:
                lx = rx + 1
                rx2 = rx + ROAD_W - 2
                if 0 <= lx < w:
                    try:
                        stdscr.addstr(y, lx, "▲", C_TREE)
                    except curses.error:
                        pass
                if 0 <= rx2 < w:
                    try:
                        stdscr.addstr(y, rx2, "▲", C_TREE)
                    except curses.error:
                        pass

        # ── road borders ──
        for y in range(play_top, play_bottom + 1):
            lb = rx + _LEFT_BORDER
            rb = rx + _RIGHT_BORDER
            if 0 <= lb < w:
                try:
                    stdscr.addstr(y, lb, "║", C_BORDER)
                except curses.error:
                    pass
            if 0 <= rb < w:
                try:
                    stdscr.addstr(y, rb, "║", C_BORDER)
                except curses.error:
                    pass

        # ── scrolling lane dividers ──
        for div in range(N_DIVS):
            dx = rx + GRASS_W + 1 + (div + 1) * LANE_W + div
            for y in range(play_top, play_bottom + 1):
                if (y + int(scroll_off)) % DASH_PERIOD < DASH_LEN:
                    if 0 <= dx < w:
                        try:
                            stdscr.addstr(y, dx, "┊", C_DIV)
                        except curses.error:
                            pass

        # ── enemy cars ──
        for e in enemies:
            e.draw(stdscr, rx, C_ENEMY[e.spr_idx])

        # ── player car (flashes during invincibility) ──
        show_player = invincible <= 0 or int(invincible * 8) % 2 == 0
        if show_player:
            px0 = int(player_x) - CAR_W // 2
            for dy, row in enumerate(PLAYER_SPRITE):
                ry = py + dy
                if play_top <= ry < play_bottom and 0 <= px0 and px0 + CAR_W < w:
                    try:
                        stdscr.addstr(ry, px0, row, C_PLAYER)
                    except curses.error:
                        pass

        # ── crash label ──
        if crash_flash > 0:
            msg = "  CRASH!  "
            mx  = int(player_x) - len(msg) // 2
            if 0 <= mx < w - len(msg) and play_top <= py - 1 < play_bottom:
                try:
                    stdscr.addstr(py - 1, mx, msg, C_CRASH)
                except curses.error:
                    pass

        # ── footer ──
        foot = "  ← → or A D  Change lane    Q  Quit  "
        try:
            stdscr.addstr(h - 1, 0, foot[:w - 1].ljust(w - 1), C_HUD)
        except curses.error:
            pass

        stdscr.refresh()

        # ── game over ──
        if lives <= 0:
            msg = f"  GAME OVER   Score: {score}   Press any key  "
            try:
                stdscr.addstr(h // 2, max(0, (w - len(msg)) // 2), msg, C_CRASH)
            except curses.error:
                pass
            stdscr.refresh()
            stdscr.nodelay(False)
            stdscr.getch()
            break

        # ── precise sleep ──
        sleep_for = FRAME_DT - (time.monotonic() - now)
        if sleep_for > 0:
            time.sleep(sleep_for)
