"""Pong — classic paddle battle for claude-arcade."""

import curses
import math
import os
import random
import signal
import time

from ...constants import STOP_FILE

WIN_SCORE  = 5
PADDLE_H   = 4
PAD_MARGIN = 2      # cols from screen edge
PADDLE_SPD = 22.0   # chars / sec
BALL_START = 18.0   # chars / sec (initial)
BALL_MAX   = 42.0   # chars / sec (cap)
TARGET_FPS = 30
FRAME_DT   = 1.0 / TARGET_FPS
KEY_WINDOW = 0.09   # seconds — keep moving after last keypress (bridges key-repeat gap)


def pong_game(stdscr) -> None:
    curses.curs_set(0)
    stdscr.nodelay(True)
    stdscr.keypad(True)

    if curses.has_colors():
        curses.start_color()
        curses.use_default_colors()
        curses.init_pair(1, curses.COLOR_WHITE,  -1)
        curses.init_pair(2, curses.COLOR_CYAN,   -1)
        curses.init_pair(3, curses.COLOR_BLACK,  curses.COLOR_CYAN)
        curses.init_pair(4, curses.COLOR_YELLOW, -1)
        C_PAD  = curses.color_pair(1) | curses.A_BOLD
        C_BALL = curses.color_pair(2) | curses.A_BOLD
        C_HDR  = curses.color_pair(3)
        C_WIN  = curses.color_pair(4) | curses.A_BOLD
        C_NET  = curses.color_pair(1) | curses.A_DIM
    else:
        C_PAD = C_BALL = C_HDR = C_WIN = curses.A_BOLD
        C_NET = curses.A_DIM

    running      = True
    player_score = 0
    cpu_score    = 0

    def on_signal(signum, frame):
        nonlocal running
        running = False

    signal.signal(signal.SIGTERM, on_signal)
    signal.signal(signal.SIGINT,  on_signal)

    # ── physics ──────────────────────────────────────────────────────────────

    def _reset(h: int, w: int):
        bx   = float(w // 2)
        by   = float(h // 2)
        ang  = random.uniform(-0.45, 0.45)
        dirx = random.choice([-1, 1])
        return bx, by, dirx * BALL_START * math.cos(ang), BALL_START * math.sin(ang)

    h, w = stdscr.getmaxyx()
    player_y = float(h // 2 - PADDLE_H // 2)
    cpu_y    = float(h // 2 - PADDLE_H // 2)
    bx, by, bvx, bvy = _reset(h, w)

    # ── input state (momentum-window approach for smooth hold-to-move) ───────
    move_dir   = 0      # -1 = up, 1 = down
    move_until = 0.0    # absolute time until which we keep moving

    # ── CPU AI state ─────────────────────────────────────────────────────────
    # The CPU does NOT track the ball in real-time every frame.
    # Instead it:
    #   1. Has a reaction delay  — only re-evaluates target every 0.28 s
    #   2. Has positional error  — aims at ball ± a random offset
    #   3. Has a blind spot      — returns to centre when ball moves away
    #   4. Has limited speed     — moves at 12 ch/s vs player's 22 ch/s
    cpu_target      = float(h // 2)   # row the CPU is trying to centre on
    cpu_react_timer = 0.0             # counts down to next AI decision

    # ── fixed-timestep loop ───────────────────────────────────────────────────
    last_tick  = time.monotonic()
    accumulate = 0.0

    while running:
        # stop-file from hook
        if os.path.exists(STOP_FILE):
            try:
                os.unlink(STOP_FILE)
            except OSError:
                pass
            break

        now        = time.monotonic()
        frame_time = now - last_tick
        last_tick  = now
        accumulate += frame_time

        # ── drain ALL pending key events this frame ───────────────────────────
        quit_game = False
        while True:
            key = stdscr.getch()
            if key == -1:
                break
            if key in (curses.KEY_UP, ord('w'), ord('W')):
                move_dir   = -1
                move_until = time.monotonic() + KEY_WINDOW
            elif key in (curses.KEY_DOWN, ord('s'), ord('S')):
                move_dir   = 1
                move_until = time.monotonic() + KEY_WINDOW
            elif key in (ord('q'), ord('Q')):
                quit_game = True
        if quit_game:
            break

        # ── fixed physics steps (catch up if lagging) ────────────────────────
        steps = 0
        while accumulate >= FRAME_DT and steps < 3:
            accumulate -= FRAME_DT
            dt = FRAME_DT
            steps += 1

            h, w = stdscr.getmaxyx()
            play_top    = 1
            play_bottom = h - 2

            # player paddle — smooth as long as key held
            if time.monotonic() < move_until:
                player_y += move_dir * PADDLE_SPD * dt
                player_y  = max(float(play_top),
                                min(float(play_bottom - PADDLE_H), player_y))

            # ── CPU AI ───────────────────────────────────────────────────────
            # Reaction delay: re-evaluate target at most every 0.28 s.
            cpu_react_timer -= dt
            if cpu_react_timer <= 0:
                cpu_react_timer = 0.28

                if bvx > 0:
                    # Ball heading toward CPU — aim for it but with error.
                    # Error grows with ball speed so fast rallies become harder
                    # for the CPU to handle (more misses at high speed).
                    spd        = math.hypot(bvx, bvy)
                    err_scale  = min(spd / BALL_START, 2.8)
                    error      = random.uniform(-2.5 * err_scale, 2.5 * err_scale)
                    cpu_target = by + error
                else:
                    # Ball moving away — drift back toward centre (blind spot)
                    cpu_target = float((play_top + play_bottom) / 2)

            # Move toward current target at limited speed (12 ch/s).
            # Player can move at 22 ch/s so a sharp angled shot beats the CPU.
            cpu_cx   = cpu_y + PADDLE_H / 2.0
            cpu_step = 12.0 * dt
            if   cpu_cx < cpu_target - 0.5:
                cpu_y = min(cpu_y + cpu_step, float(play_bottom - PADDLE_H))
            elif cpu_cx > cpu_target + 0.5:
                cpu_y = max(cpu_y - cpu_step, float(play_top))

            # ball
            bx += bvx * dt
            by += bvy * dt

            # top / bottom wall bounce
            if by <= play_top:
                by  = float(play_top)
                bvy = abs(bvy)
            elif by >= play_bottom:
                by  = float(play_bottom)
                bvy = -abs(bvy)

            # left (player) paddle
            if bvx < 0 and PAD_MARGIN <= int(bx) <= PAD_MARGIN + 1:
                py0 = int(player_y)
                py1 = py0 + PADDLE_H
                if py0 - 1 <= int(by) <= py1:
                    # angle deflection based on hit position relative to paddle centre
                    rel   = (by - (py0 + PADDLE_H / 2)) / (PADDLE_H / 2)  # -1..1
                    spd   = min(math.hypot(bvx, bvy) * 1.06, BALL_MAX)
                    angle = rel * 0.65
                    bvx   =  abs(spd * math.cos(angle))
                    bvy   =  spd * math.sin(angle)
                    bx    =  float(PAD_MARGIN + 2)

            # right (cpu) paddle
            rpx = w - PAD_MARGIN - 1
            if bvx > 0 and rpx - 1 <= int(bx) <= rpx:
                cy0 = int(cpu_y)
                cy1 = cy0 + PADDLE_H
                if cy0 - 1 <= int(by) <= cy1:
                    rel   = (by - (cy0 + PADDLE_H / 2)) / (PADDLE_H / 2)
                    spd   = min(math.hypot(bvx, bvy) * 1.06, BALL_MAX)
                    angle = rel * 0.65
                    bvx   = -abs(spd * math.cos(angle))
                    bvy   =  spd * math.sin(angle)
                    bx    =  float(rpx - 2)

            # scoring
            if bx < 0:
                cpu_score += 1
                bx, by, bvx, bvy = _reset(h, w)
                player_y = float(h // 2 - PADDLE_H // 2)
                cpu_y    = float(h // 2 - PADDLE_H // 2)
            elif bx >= w:
                player_score += 1
                bx, by, bvx, bvy = _reset(h, w)
                player_y = float(h // 2 - PADDLE_H // 2)
                cpu_y    = float(h // 2 - PADDLE_H // 2)

        # ── draw ─────────────────────────────────────────────────────────────
        h, w = stdscr.getmaxyx()
        play_top    = 1
        play_bottom = h - 2

        stdscr.erase()

        # header
        stars_p = "★" * player_score + "☆" * (WIN_SCORE - player_score)
        stars_c = "★" * cpu_score    + "☆" * (WIN_SCORE - cpu_score)
        header  = f"  YOU  {stars_p}   ╏   {stars_c}  CPU  "
        hx      = max(0, (w - len(header)) // 2)
        try:
            stdscr.addstr(0, 0, " " * (w - 1), C_HDR)
            stdscr.addstr(0, hx, header[:w - 1], C_HDR)
        except curses.error:
            pass

        # centre net
        for y in range(play_top, play_bottom + 1):
            ch = "┃" if y % 2 == 0 else " "
            try:
                stdscr.addstr(y, w // 2, ch, C_NET)
            except curses.error:
                pass

        # player paddle
        for dy in range(PADDLE_H):
            py = int(player_y) + dy
            if play_top <= py <= play_bottom:
                try:
                    stdscr.addstr(py, PAD_MARGIN, "█", C_PAD)
                except curses.error:
                    pass

        # cpu paddle
        for dy in range(PADDLE_H):
            cy = int(cpu_y) + dy
            if play_top <= cy <= play_bottom:
                try:
                    stdscr.addstr(cy, w - PAD_MARGIN - 1, "█", C_PAD)
                except curses.error:
                    pass

        # ball
        ibx, iby = int(bx), int(by)
        if play_top <= iby <= play_bottom and 0 <= ibx < w:
            try:
                stdscr.addstr(iby, ibx, "●", C_BALL)
            except curses.error:
                pass

        # footer
        foot = "  W / S  or  ↑ / ↓   Move    Q  Quit  "
        try:
            stdscr.addstr(h - 1, 0, foot[:w - 1].ljust(w - 1), C_HDR)
        except curses.error:
            pass

        stdscr.refresh()

        # win screen
        if player_score >= WIN_SCORE or cpu_score >= WIN_SCORE:
            msg = "  YOU WIN!  Press any key  " if player_score >= WIN_SCORE \
                  else "  CPU WINS!  Press any key  "
            try:
                stdscr.addstr(h // 2, max(0, (w - len(msg)) // 2), msg, C_WIN)
            except curses.error:
                pass
            stdscr.refresh()
            stdscr.nodelay(False)
            stdscr.getch()
            break

        # ── precise sleep to hit target FPS ──────────────────────────────────
        sleep_for = FRAME_DT - (time.monotonic() - now)
        if sleep_for > 0:
            time.sleep(sleep_for)
