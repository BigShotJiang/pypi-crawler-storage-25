"""Bird Hunt — shoot sprite birds flying across your terminal."""

import curses
import os
import random
import signal
import sys
import time

from ...constants import PID_FILE, STOP_FILE

# ---------------------------------------------------------------------------
# Game objects
# ---------------------------------------------------------------------------

class Bird:
    # Block-character sprites, 2 animation frames each (wings up / wings down).
    # Each frame is a list of rows (strings). All rows within a bird type are
    # the same width so hit-detection and drawing stay simple.
    # _r = flying right  |  _l = flying left (mirrored)
    TYPES = [
        {
            # ── Sparrow ── small & fast, 4 wide × 2 tall, 3 pts
            "frames_r": [["▄▀  ", "*██>"], ["▀▄  ", "*██>"]],
            "frames_l": [["  ▀▄", "<██*"], ["  ▄▀", "<██*"]],
            "speed": 2.0, "points": 3, "anim_rate": 5,
        },
        {
            # ── Seagull ── medium, 7 wide × 2 tall, 1 pt
            "frames_r": [["▄▀▀▀▀▀ ", "*████> "], ["▀▄▄▄▄▀ ", "*████> "]],
            "frames_l": [[" ▀▀▀▀▄ ", " <████*"], [" ▀▄▄▄▄▀", " <████*"]],
            "speed": 1.0, "points": 1, "anim_rate": 8,
        },
        {
            # ── Pterodactyl ── large & slow, 9 wide × 3 tall, 2 pts
            "frames_r": [
                ["▄▀▀▀▀▀▀▀ ", "*██████▄>", "    ▌▌   "],
                ["         ", "*██████▄>", "▀▀▀▀▌▌   "],
            ],
            "frames_l": [
                [" ▀▀▀▀▀▀▄▄", "<▄██████*", "   ▐▐    "],
                ["         ", "<▄██████*", "   ▐▐▀▀▀▀"],
            ],
            "speed": 0.6, "points": 2, "anim_rate": 10,
        },
    ]

    def __init__(self, width: int, height: int) -> None:
        t = random.choice(Bird.TYPES)
        self._frames_r   = t["frames_r"]
        self._frames_l   = t["frames_l"]
        self.speed       = t["speed"]
        self.points      = t["points"]
        self._anim_rate  = t["anim_rate"]
        self._anim_frame = 0
        self._tick       = 0
        self.direction   = random.choice(("right", "left"))
        self._frac_x: float

        num_rows = max(len(f) for f in self._frames_r)
        self.y = random.randint(2, max(3, height - 2 - num_rows))

        w = self.width
        self._frac_x = float(-w - 1) if self.direction == "right" else float(width + 1)

    @property
    def _frames(self):
        return self._frames_r if self.direction == "right" else self._frames_l

    @property
    def frame(self):
        return self._frames[self._anim_frame]

    @property
    def width(self) -> int:
        return max(len(row) for row in self._frames_r[0])

    @property
    def x(self) -> int:
        return int(self._frac_x)

    def update(self, dt: float) -> None:
        if self.direction == "right":
            self._frac_x += self.speed * dt * 20
        else:
            self._frac_x -= self.speed * dt * 20
        self._tick += 1
        if self._tick >= self._anim_rate:
            self._tick = 0
            self._anim_frame = (self._anim_frame + 1) % len(self._frames)

    def is_offscreen(self, width: int) -> bool:
        if self.direction == "right":
            return self.x > width
        return self.x + self.width < 0

    def draw(self, stdscr, color: int) -> None:
        h, w = stdscr.getmaxyx()
        for dy, row_art in enumerate(self.frame):
            ry, rx = self.y + dy, self.x
            if 1 <= ry < h - 1 and 0 <= rx < w - len(row_art):
                try:
                    stdscr.addstr(ry, rx, row_art, color)
                except curses.error:
                    pass


class Bullet:
    def __init__(self, x: int, y: int) -> None:
        self.x = x
        self.y = float(y)

    def update(self, dt: float) -> None:
        self.y -= 40 * dt

    @property
    def iy(self) -> int:
        return int(self.y)

    def is_offscreen(self) -> bool:
        return self.iy < 1

    def hits(self, bird: Bird) -> bool:
        if not (bird.x <= self.x <= bird.x + bird.width - 1):
            return False
        for dy in range(len(bird.frame)):
            if self.iy == bird.y + dy:
                return True
        return False

    def draw(self, stdscr, color: int) -> None:
        h, w = stdscr.getmaxyx()
        if 1 <= self.iy < h - 1 and 0 <= self.x < w:
            try:
                stdscr.addstr(self.iy, self.x, "|", color)
            except curses.error:
                pass


class Explosion:
    FRAMES = ["***", " * ", "   "]

    def __init__(self, x: int, y: int) -> None:
        self.x = x
        self.y = y
        self.frame = 0

    def update(self) -> None:
        self.frame += 1

    @property
    def done(self) -> bool:
        return self.frame >= len(self.FRAMES)

    def draw(self, stdscr, color: int) -> None:
        if self.done:
            return
        h, w = stdscr.getmaxyx()
        art = self.FRAMES[self.frame]
        if 1 <= self.y < h - 1 and 0 <= self.x < w - len(art):
            try:
                stdscr.addstr(self.y, self.x, art, color | curses.A_BOLD)
            except curses.error:
                pass


# ---------------------------------------------------------------------------
# Main game loop
# ---------------------------------------------------------------------------

def bird_game(stdscr) -> None:
    curses.curs_set(0)
    stdscr.nodelay(True)
    stdscr.keypad(True)

    if curses.has_colors():
        curses.start_color()
        curses.use_default_colors()
        curses.init_pair(1, curses.COLOR_YELLOW,  -1)
        curses.init_pair(2, curses.COLOR_GREEN,   -1)
        curses.init_pair(3, curses.COLOR_RED,     -1)
        curses.init_pair(4, curses.COLOR_CYAN,    -1)
        curses.init_pair(5, curses.COLOR_BLACK, curses.COLOR_CYAN)
        curses.init_pair(6, curses.COLOR_MAGENTA, -1)
        C_BIRD = curses.color_pair(1)
        C_AIM  = curses.color_pair(2) | curses.A_BOLD
        C_SHOT = curses.color_pair(3)
        C_HDR  = curses.color_pair(4) | curses.A_BOLD
        C_BAR  = curses.color_pair(5)
        C_BOOM = curses.color_pair(6)
    else:
        C_BIRD = C_AIM = C_SHOT = C_HDR = C_BAR = C_BOOM = curses.A_NORMAL

    h, w = stdscr.getmaxyx()
    score  = 0
    birds: list = []
    bullets: list = []
    booms: list = []
    cx = w // 2
    cy = h // 2
    spawn_interval = 1.8
    last_spawn = time.monotonic()
    last_tick  = time.monotonic()
    running    = True

    def on_signal(signum, frame):
        nonlocal running
        running = False

    signal.signal(signal.SIGTERM, on_signal)
    signal.signal(signal.SIGINT,  on_signal)

    while running:
        if os.path.exists(STOP_FILE):
            try:
                os.unlink(STOP_FILE)
            except OSError:
                pass
            break

        now = time.monotonic()
        dt  = now - last_tick
        last_tick = now
        h, w = stdscr.getmaxyx()

        if now - last_spawn >= spawn_interval:
            birds.append(Bird(w, h))
            last_spawn = now
            spawn_interval = max(0.7, spawn_interval - 0.04)

        for bird in birds[:]:
            bird.update(dt)
            if bird.is_offscreen(w):
                birds.remove(bird)

        for blt in bullets[:]:
            blt.update(dt)
            if blt.is_offscreen():
                bullets.remove(blt)
                continue
            hit = False
            for bird in birds[:]:
                if blt.hits(bird):
                    score += bird.points
                    booms.append(Explosion(bird.x + bird.width // 2, bird.y))
                    birds.remove(bird)
                    hit = True
                    break
            if hit and blt in bullets:
                bullets.remove(blt)

        for b in booms[:]:
            b.update()
            if b.done:
                booms.remove(b)

        stdscr.erase()
        header = f" BIRD HUNT  |  Score: {score}  |  Arrows/WASD: Aim  |  SPACE: Shoot  |  Q: Quit "
        try:
            stdscr.addstr(0, 0, header[:w - 1].ljust(w - 1), C_HDR)
        except curses.error:
            pass

        for bird in birds:
            bird.draw(stdscr, C_BIRD)
        for blt in bullets:
            blt.draw(stdscr, C_SHOT)
        for boom in booms:
            boom.draw(stdscr, C_BOOM)

        for dx, ch in [(-1, "["), (0, "+"), (1, "]")]:
            nx = cx + dx
            if 1 <= cy < h - 1 and 0 <= nx < w:
                try:
                    stdscr.addstr(cy, nx, ch, C_AIM)
                except curses.error:
                    pass

        footer = " Claude is thinking...  Hang tight and shoot some birds! "
        try:
            stdscr.addstr(h - 1, 0, footer[:w - 1].ljust(w - 1), C_BAR)
        except curses.error:
            pass

        stdscr.refresh()

        key = stdscr.getch()
        if key in (curses.KEY_UP,    ord("w"), ord("W")) and cy > 1:
            cy -= 1
        elif key in (curses.KEY_DOWN,  ord("s"), ord("S")) and cy < h - 2:
            cy += 1
        elif key in (curses.KEY_LEFT,  ord("a"), ord("A")) and cx > 1:
            cx -= 1
        elif key in (curses.KEY_RIGHT, ord("d"), ord("D")) and cx < w - 2:
            cx += 1
        elif key == ord(" "):
            bullets.append(Bullet(cx, cy - 1))
        elif key in (ord("q"), ord("Q")):
            break

        time.sleep(0.033)


# ---------------------------------------------------------------------------
# Hook integration — start / stop game from Claude Code hooks
# ---------------------------------------------------------------------------

def _has_real_tty() -> bool:
    try:
        fd = os.open("/dev/tty", os.O_RDWR)
        os.close(fd)
        return True
    except OSError:
        return False


def _open_new_terminal(cmd: str) -> bool:
    import subprocess, shutil
    if sys.platform == "darwin":
        if shutil.which("osascript"):
            for app, script in [
                ("iTerm2",   f'tell application "iTerm2" to create window with default profile command "{cmd}"'),
                ("Terminal", f'tell application "Terminal" to do script "{cmd}"'),
            ]:
                try:
                    r = subprocess.run(["osascript", "-e", f'tell application "{app}" to activate'],
                                       capture_output=True, timeout=2)
                    if r.returncode == 0:
                        subprocess.Popen(["osascript", "-e", script])
                        return True
                except Exception:
                    continue
    else:
        for term, flag in [("gnome-terminal", "--"), ("xterm", "-e"),
                            ("konsole", "-e"), ("xfce4-terminal", "-e")]:
            import shutil
            if shutil.which(term):
                try:
                    subprocess.Popen([term, flag] + cmd.split())
                    return True
                except Exception:
                    continue
    return False


def start_background() -> None:
    """Launch the bird game when a Claude Code PreToolUse hook fires."""
    if os.path.exists(PID_FILE):
        try:
            with open(PID_FILE) as fh:
                pid = int(fh.read().strip())
            os.kill(pid, 0)
            return
        except (OSError, ValueError):
            pass

    try:
        os.unlink(STOP_FILE)
    except OSError:
        pass

    import shutil
    cmd = shutil.which("claude-arcade") or "claude-arcade"

    if _has_real_tty():
        pid = os.fork()
        if pid > 0:
            with open(PID_FILE, "w") as fh:
                fh.write(str(pid))
            sys.exit(0)
        try:
            os.setsid()
            tty_fd = os.open("/dev/tty", os.O_RDWR)
            for fd in (0, 1, 2):
                os.dup2(tty_fd, fd)
            if tty_fd > 2:
                os.close(tty_fd)
            curses.wrapper(bird_game)
        except Exception:
            pass
        finally:
            try:
                os.unlink(PID_FILE)
            except OSError:
                pass
            os._exit(0)
    else:
        _open_new_terminal(f"{cmd} _play_direct")


def stop_background() -> None:
    """Stop the background game when a Claude Code PostToolUse/Stop hook fires."""
    try:
        open(STOP_FILE, "w").close()
    except OSError:
        pass
    if os.path.exists(PID_FILE):
        try:
            with open(PID_FILE) as fh:
                pid = int(fh.read().strip())
            os.kill(pid, signal.SIGTERM)
        except (OSError, ValueError):
            pass
        try:
            os.unlink(PID_FILE)
        except OSError:
            pass
