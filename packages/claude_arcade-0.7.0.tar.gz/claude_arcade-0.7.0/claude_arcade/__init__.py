"""claude-arcade: Play games while Claude thinks."""

__version__ = "0.7.0"
