"""rtxclaw-telegram — the standalone Telegram gateway service.

Independent of any one rtxclaw agent: the bot lives at
``~/.rtxclaw/telegram/`` (config + sessions + offset + logs) and
routes each chat to whichever agent ``TelegramConfig.agent_for(...)``
resolves — per-(chat,thread) override → bare-chat override →
``default_agent``. ACP client over the rtxclaw_agent stdio surface
(or WebSocket if ``RTXCLAW_TELEGRAM_ACP_URL`` is set). One AcpClient
per ``(chat,thread)`` so the ``ClientCapabilities`` advertisement
reflects per-chat trust — public chats stay text-only, trusted chats
(in ``TelegramConfig.trusted_chat_ids`` or
``RTXCLAW_TELEGRAM_TRUSTED_CHATS``) get ``fs.readTextFile`` (never
``writeTextFile``, never terminal). Maps each Telegram chat to one
ACP session, persists the binding at
``~/.rtxclaw/telegram/sessions.json`` and reattaches saved chats
through ``session/load`` on startup.
"""
from __future__ import annotations

__version__ = "0.3.0.dev0"

__all__ = ["__version__"]
