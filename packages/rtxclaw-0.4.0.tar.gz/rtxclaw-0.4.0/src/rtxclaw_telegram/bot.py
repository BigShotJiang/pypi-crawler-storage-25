"""Telegram bot frontend for rtxclaw — ACP-only.

The bot is a STANDALONE service (no longer spawned by an agent
gateway). It owns its own home at ``~/.rtxclaw/telegram/`` and talks
to whichever rtxclaw agent the chat picks. Phase A binds every chat
to one default agent (``TelegramConfig.default_agent``); Phase B will
add per-(chat,agent) sessions and a ``/agent <name>`` switch.

Long-polls Telegram ``getUpdates``, maps each chat to one ACP session
running on a child ``rtxclaw_agent acp-stdio`` process, and streams
the agent's ``session/update`` notifications back to Telegram as
in-place message edits.

On-disk state (under ``~/.rtxclaw/telegram/``):

    config.json
        ``bot_token``, ``allowed_chat_ids``, ``trusted_chat_ids``,
        ``default_agent``. Edited by ``rtxclaw telegram setup`` /
        directly with an editor; bot reads it once at boot.

    sessions.json
        ``{"<chat_key>": "<acp_session_id>"}`` — the chat → session
        binding that survives bot restarts. The bot calls
        ``session/load`` on each entry at startup and falls through
        to ``session/new`` for any the agent has forgotten.

    offset.json
        ``{"update_offset": <int>}`` — the ``getUpdates`` ack cursor.
        Persisted before dispatching each update so a crash
        mid-handler doesn't replay the same message on restart.

    logs/telegram.log
        Structured stdout/stderr of the poller. Separate from each
        agent's ``logs/gateway.log`` so the bot's own noise doesn't
        drown a gateway log.

Auth: :attr:`TelegramConfig.allowed_chat_ids` is the allowlist; an
empty list denies everyone. The first message from a non-whitelisted
chat is logged once and gets one ``⛔ this bot is private`` reply
(with the offending ``chat_id`` so the operator can copy-paste it
into ``~/.rtxclaw/telegram/config.json``). Subsequent messages from
the same chat are silently dropped.

Streaming UX: each user message gets a ``💭 thinking…`` placeholder reply
that is edited as ``session/update`` events arrive from the agent. Edits
are throttled to ~1/sec; the rolling-message helper rolls into a fresh
follow-up message when the buffer crosses Telegram's 4000-char cap rather
than truncating the tail.

Slash commands (text-only, no inline keyboards):

    /start   — greet, force-create a fresh session for this chat
    /new     — drop this chat's session binding; next message opens a
               fresh ACP session via ``session/new``
    /status  — agent name, capabilities advertisement, bound session id
    /stop    — fire ``session/cancel`` on the chat's in-flight prompt
    /cancel  — alias for /stop
    /help    — list commands
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import json
import logging
import os
import secrets
import signal
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import httpx

from rtxclaw_acp.client.client import AcpClientError, AcpRemoteError
from rtxclaw_core.agent import AgentConfig
from rtxclaw_telegram.config import TelegramConfig


# Substrings the gateway uses when a session id is no longer attached
# to a live child (idle-reaped, or the gateway restarted between turns).
# Matched case-insensitively against ``AcpRemoteError.message`` so the
# bot can recover by re-loading the session before re-issuing the
# prompt — see ``_reopen_session_after_loss``. The full message looks
# like ``backend error: LookupError: no live child owns session …``.
_RECOVERABLE_SESSION_ERROR_PHRASES = (
    "no live child owns session",
    "idle-reaped",
    "session not found",
    "unknown session",
)


def _is_recoverable_session_error(exc: BaseException) -> bool:
    """Return True for errors that just mean "the session id you sent
    is not live on the gateway anymore" — recoverable by re-loading or
    re-creating the session, not by surfacing the failure.

    Two error families count as recoverable:
      * :class:`AcpRemoteError` whose ``message`` matches one of the
        gateway's "session not attached" phrases — the gateway is
        alive but our sid is stale.
      * :class:`AcpTransportClosed` — the transport itself died
        (SSE stream torn down by an OOM-kill, network blip, etc.).
        Reopening the client + session puts us back in business.
    """
    from rtxclaw_acp.client.client import AcpTransportClosed
    if isinstance(exc, AcpTransportClosed):
        return True
    if not isinstance(exc, AcpRemoteError):
        return False
    msg = (getattr(exc, "message", "") or "").lower()
    return any(phrase in msg for phrase in _RECOVERABLE_SESSION_ERROR_PHRASES)


def _format_relative_age(iso_ts: str) -> str:
    """Render an ISO 8601 timestamp as a compact relative age
    (``5m``, ``2h``, ``3d``). Empty / unparseable input returns ``?``
    so the picker line still renders without a hole.
    """
    if not iso_ts:
        return "?"
    try:
        dt = datetime.fromisoformat(iso_ts)
    except (TypeError, ValueError):
        return "?"
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    delta_s = max(0, int((datetime.now(timezone.utc) - dt).total_seconds()))
    if delta_s < 60:
        return f"{delta_s}s"
    if delta_s < 3600:
        return f"{delta_s // 60}m"
    if delta_s < 86400:
        return f"{delta_s // 3600}h"
    return f"{delta_s // 86400}d"


TELEGRAM_API = "https://api.telegram.org"

# Initial throttle for in-place message edits. Telegram's *practical* edit
# limit is around 1 edit/sec/message; bursts above that get 429-throttled
# fast. Start at 2.0s and back off adaptively when Telegram returns 429.
EDIT_THROTTLE_S = 2.0
# Cap how far the adaptive backoff can stretch. If we hit this we just
# stop editing the current placeholder mid-turn and let the final paint
# (force=True) carry the result.
EDIT_THROTTLE_MAX_S = 30.0

# Cap on image upload size forwarded to upstream vision models. Matches
# the legacy bot's threshold; keeps a single base64 payload below
# upstream HTTP body limits even after the ~33% inflation.
_MAX_IMAGE_BYTES = 8 * 1024 * 1024  # 8 MiB

# Long-poll timeout sent to Telegram. Inside this window getUpdates blocks
# server-side until a new update arrives, so the poller is effectively
# idle (no spinning). 25s is well under Telegram's 50s ceiling.
LONG_POLL_TIMEOUT_S = 25

# How long a ``session/request_permission`` inline-keyboard prompt waits
# for a button press before defaulting to deny. Matches the agent-side
# ``_PERMISSION_PROMPT_TIMEOUT_S`` backstop — the user walked away, and
# on a destructive op "no answer" means "no".
_PERMISSION_PROMPT_TIMEOUT_S = 30.0

# Hard ceiling on a single Telegram message we render. Telegram caps text
# at 4096; we leave headroom for the ``\n\n[…]`` truncation marker.
TELEGRAM_MAX_TEXT = 4000

# Telegram's CLOUD Bot API caps ``getFile`` (and thus any bot-side file
# download) at 20 MB. A larger voice/audio attachment cannot be fetched
# at all — getFile returns ``{"ok": false, "description": "file is too
# big"}``. Detect it from the message's ``file_size`` up front so we can
# tell the user clearly instead of emitting a generic download failure.
# (A self-hosted ``telegram-bot-api`` server raises this to ~2 GB.)
TG_GETFILE_MAX_BYTES = 20 * 1024 * 1024
# Self-hosted telegram-bot-api (--local) lifts the download cap; uploads
# (and thus practical file size) top out at ~2 GB.
TG_LOCAL_MAX_BYTES = 2000 * 1024 * 1024

# Two-press hard-kill window for ``/stop``/``/cancel``/``/abort``.
# Mirrors the bridge's ``_HARD_KILL_WINDOW_S`` (acp_bridge.py) so the
# Telegram ack reflects whether the server will escalate from SIGTERM
# to SIGKILL on this press. Kept slightly *wider* than the bridge value
# because the Telegram round-trip adds ~100–300 ms vs the TUI's local
# transport — a strict 1.0 s window would under-report force-kills.
_ABORT_DOUBLE_PRESS_S = 1.5

# Commands registered with Telegram's ``setMyCommands`` at startup so the
# "/" autocomplete popup in every chat shows what the bot actually handles.
# These are the persistent built-in commands — file-based commands from
# ``commands/*.md`` are NOT pre-registered (they vary per operator and
# ``setMyCommands`` has a 100-command ceiling). The ``/help`` card and
# ``/commands`` listing remain the canonical discovery surface for those.
_PERSISTENT_COMMANDS: list[dict[str, str]] = [
    {"command": "help", "description": "Show this help card"},
    {"command": "new", "description": "Start a fresh session"},
    {"command": "status", "description": "Show agent and session info"},
    {"command": "stop", "description": "Abort the in-flight prompt"},
    {"command": "cancel", "description": "Alias for /stop"},
    {"command": "abort", "description": "Force-kill the running prompt"},
    {"command": "steer", "description": "Redirect the running turn: /steer <text>"},
    {"command": "sessions", "description": "List saved sessions"},
    {"command": "history", "description": "Show recent turns"},
    {"command": "todo", "description": "Show the model's todo list"},
    {"command": "compact", "description": "Squeeze the running prompt"},
    {"command": "skills", "description": "List installed skills"},
    {"command": "skill", "description": "Show a skill's SKILL.md body"},
    {"command": "commands", "description": "List file-based commands"},
    {"command": "refresh", "description": "Reload session state from disk"},
    {"command": "mode", "description": "Set permission mode: plan|ask|auto"},
    {"command": "models", "description": "List configured models"},
    {"command": "model", "description": "Switch the live model"},
    {"command": "reasoning", "description": "Toggle thinking-token visibility"},
    {"command": "reason", "description": "Alias for /reasoning"},
    {"command": "on", "description": "Shortcut: /reasoning on"},
    {"command": "off", "description": "Shortcut: /reasoning off"},
    {"command": "stream", "description": "Shortcut: /reasoning stream"},
    {"command": "thinking", "description": "Toggle model thinking"},
    {"command": "tools", "description": "Toggle tool call visibility"},
    {"command": "tool", "description": "Alias for /tools"},
    {"command": "claude", "description": "Bridge to Claude Code"},
    {"command": "codex", "description": "Bridge to Codex CLI"},
    {"command": "antigravity", "description": "Bridge to Antigravity CLI"},
    {"command": "agents", "description": "List configured agents"},
    {"command": "agent", "description": "Switch to a different agent"},
    {"command": "plugin", "description": "Manage plugin bundles"},
    {"command": "plugins", "description": "Alias for /plugin"},
    {"command": "mcp", "description": "List MCP servers"},
    {"command": "mcps", "description": "Alias for /mcp"},
    {"command": "start", "description": "Show help + new session"},
    {"command": "restart", "description": "Restart the rtxclaw gateway"},
    {"command": "context", "description": "Show context detail report"},
    {"command": "ctx", "description": "Alias for /context"},
    {"command": "todos", "description": "Alias for /todo"},
]

# Hint the user sees on first contact when they're not whitelisted.
DENY_LOG_TEMPLATE = (
    "DENIED chat_id={chat_id} username=@{username} ({first_name!r}) — "
    "not in telegram allowed_chat_ids. To whitelist, edit "
    "{config_path} and add {chat_id} to allowed_chat_ids, "
    "then `rtxclaw telegram restart`."
)

# Env var overrides. ``ACP_DEFAULT_WS_URL_ENV`` is consulted only when the
# constructor's ``acp_url`` is None. The production default is the
# rtxclaw single-process gateway over Streamable HTTP — set this to
# ``http://127.0.0.1:<gateway-port>`` (the gateway routes by URL path,
# so the bot appends ``/acp/<agent>`` per chat). ``ws://`` is still
# accepted for legacy / fake-server tests; empty disables and falls
# back to a stdio child spawn (kept solely as a unit-test fallback).
ACP_DEFAULT_WS_URL_ENV = "RTXCLAW_TELEGRAM_ACP_URL"
ACP_BEARER_TOKEN_ENV = "RTXCLAW_TELEGRAM_ACP_TOKEN"
ACP_TRUSTED_CHATS_ENV = "RTXCLAW_TELEGRAM_TRUSTED_CHATS"

# Replies for inputs ACP-v1 doesn't yet route to the agent. Surfaced as
# constants so tests can assert on them by symbol rather than string.
ACP_IMAGE_UNSUPPORTED_REPLY = (
    "📎 image input not yet supported on this bot — send the question as "
    "text instead."
)
ACP_DOCUMENT_UNSUPPORTED_REPLY = (
    "📎 file input not yet supported on this bot — paste the contents as "
    "text instead."
)
ACP_STICKER_UNSUPPORTED_REPLY = (
    "🖼️ stickers aren't routed to the agent — send the question as text."
)


def _truncate_for_telegram(text: str) -> str:
    """Last-line-of-defense truncation for one-shot ``sendMessage`` calls.

    The streaming flow rolls into multiple messages via
    :class:`_RollingMessage` instead — this function only ever fires for
    ad-hoc text (slash-command replies, error markers) that exceeds
    ``TELEGRAM_MAX_TEXT`` despite all callers being short.
    """
    if len(text) <= TELEGRAM_MAX_TEXT:
        return text
    return text[: TELEGRAM_MAX_TEXT - 6] + "\n\n[…]"


def _split_at(text: str, max_len: int) -> int:
    """Pick a clean break index ≤ ``max_len`` for splitting a long reply.

    Prefers (in order): the last newline, then the last space, both only
    when they fall in the right half of ``max_len`` so we don't fragment
    a paragraph at the very start. Falls back to a hard cut at ``max_len``
    when the chunk is one giant unbroken token (a base64 blob, etc.).
    """
    if len(text) <= max_len:
        return len(text)
    half = max_len // 2
    cut = text.rfind("\n", 0, max_len)
    if cut >= half:
        return cut
    cut = text.rfind(" ", 0, max_len)
    if cut >= half:
        return cut
    return max_len


# ---------------------------------------------------------------------------
# Persistence helpers (chatId → ACP session id; getUpdates offset cursor)
# ---------------------------------------------------------------------------


def _parse_chat_key(key: str) -> tuple[Optional[int], Optional[int]]:
    """Inverse of :meth:`TelegramConfig.chat_key`.

    ``"-1003916299625:4"`` → ``(-1003916299625, 4)``;
    ``"8484692594"`` → ``(8484692594, None)``;
    ``"garbage"`` → ``(None, None)`` so the caller can mark the entry
    stale instead of crashing on a malformed map.
    """
    if not key:
        return None, None
    if ":" in key:
        chat_part, _, thread_part = key.partition(":")
        try:
            return int(chat_part), int(thread_part)
        except ValueError:
            return None, None
    try:
        return int(key), None
    except ValueError:
        return None, None


def _acp_sessions_path(tg_cfg: TelegramConfig) -> Path:
    return tg_cfg.sessions_path


def _offset_path(tg_cfg: TelegramConfig) -> Path:
    return tg_cfg.offset_path


def _load_acp_session_map(
    tg_cfg: TelegramConfig,
) -> dict[str, dict[str, str]]:
    """Load ``{chat_key: {agent_name: session_id}}`` from disk.

    Two shapes are accepted:

    1. **Nested** (current) — ``{chat_key: {agent: sid}}``.
    2. **Flat** (legacy from Phase A) — ``{chat_key: sid_string}``.
       Each entry is hoisted into ``{tg_cfg.default_agent: sid}``
       so old installs migrate transparently.

    Malformed entries are dropped silently — better to lose one
    binding than crash the bot's boot path.
    """
    p = _acp_sessions_path(tg_cfg)
    if not p.exists():
        return {}
    try:
        raw = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(raw, dict):
        return {}
    default_agent = tg_cfg.default_agent or "main"
    out: dict[str, dict[str, str]] = {}
    for chat_key, val in raw.items():
        if not isinstance(chat_key, str):
            continue
        if isinstance(val, str) and val:
            # Legacy flat record — assume the default agent.
            out[chat_key] = {default_agent: val}
            continue
        if not isinstance(val, dict):
            continue
        agent_map: dict[str, str] = {}
        for agent_name, sid in val.items():
            if not isinstance(agent_name, str) or not isinstance(sid, str):
                continue
            if not agent_name or not sid:
                continue
            agent_map[agent_name] = sid
        if agent_map:
            out[chat_key] = agent_map
    return out


def _load_visibility_map(
    tg_cfg: TelegramConfig,
) -> dict[str, dict[str, Any]]:
    """Load ``{chat_key: {reasoning_visibility, tool_output}}`` from
    disk. Missing file or malformed JSON ⇒ empty dict (every chat
    falls through to the off/off defaults). Bad per-chat entries are
    dropped silently — better to reset one chat's display state than
    to brick the bot's startup."""
    p = tg_cfg.visibility_path
    if not p.exists():
        return {}
    try:
        raw = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(raw, dict):
        return {}
    out: dict[str, dict[str, Any]] = {}
    for chat_key, val in raw.items():
        if not isinstance(chat_key, str) or not isinstance(val, dict):
            continue
        entry: dict[str, Any] = {}
        # ``reasoning_visibility`` is a string token (off/on/stream);
        # tolerate the legacy bool ``tool_output_visible`` shape too
        # so an old visibility.json from before the 3-state /tools
        # rework still loads.
        rv = val.get("reasoning_visibility")
        if isinstance(rv, str) and rv:
            entry["reasoning_visibility"] = rv
        to = val.get("tool_output")
        if isinstance(to, str) and to:
            entry["tool_output"] = to
        elif "tool_output_visible" in val:
            entry["tool_output"] = (
                "on" if val.get("tool_output_visible") else "off"
            )
        if entry:
            out[chat_key] = entry
    return out


def _save_visibility_map(
    tg_cfg: TelegramConfig, mapping: dict[str, dict[str, Any]],
) -> None:
    """Persist the per-(chat,thread) visibility map. Atomic-ish via
    plain ``write_text``; matches the chat→session map's ergonomics."""
    p = tg_cfg.visibility_path
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(
            json.dumps(mapping, indent=2, ensure_ascii=False, sort_keys=True)
            + "\n",
            encoding="utf-8",
        )
    except OSError:
        logging.getLogger("rtxclaw.telegram").exception(
            "%s save failed", p.name,
        )


def _save_acp_session_map(
    tg_cfg: TelegramConfig, mapping: dict[str, dict[str, str]],
) -> None:
    """Persist the nested chat→agent→session map.

    Atomic-ish via plain ``write_text`` — the file is small and torn
    writes rare; the worst case is one lost mapping which the next
    save overwrites.
    """
    p = _acp_sessions_path(tg_cfg)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(
            json.dumps(mapping, indent=2, ensure_ascii=False, sort_keys=True)
            + "\n",
            encoding="utf-8",
        )
    except OSError:
        logging.getLogger("rtxclaw.telegram").exception(
            "%s save failed", p.name,
        )


def _load_update_offset(tg_cfg: TelegramConfig) -> int:
    p = _offset_path(tg_cfg)
    if not p.exists():
        return 0
    try:
        raw = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return 0
    if isinstance(raw, dict):
        v = raw.get("update_offset")
        if isinstance(v, int):
            return v
    return 0


def _save_update_offset(tg_cfg: TelegramConfig, offset: int) -> None:
    p = _offset_path(tg_cfg)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(
            json.dumps({"update_offset": int(offset)}) + "\n",
            encoding="utf-8",
        )
    except OSError:
        logging.getLogger("rtxclaw.telegram").exception(
            "%s save failed", p.name,
        )


def _trusted_chats_from_env_or_cfg(tg_cfg: TelegramConfig) -> set[int]:
    """Resolve the trusted-chats set from the bot config + env var.

    ``TelegramConfig.trusted_chat_ids`` is the canonical source. The
    legacy env var ``RTXCLAW_TELEGRAM_TRUSTED_CHATS`` is still merged
    in as a comma-separated list of int chat ids so existing test
    setups that export it keep working without writing config.
    """
    chats: set[int] = set(int(x) for x in (tg_cfg.trusted_chat_ids or []))
    raw = os.environ.get(ACP_TRUSTED_CHATS_ENV, "").strip()
    if raw:
        for piece in raw.split(","):
            piece = piece.strip()
            if not piece:
                continue
            try:
                chats.add(int(piece))
            except ValueError:
                pass
    return chats


OPENROUTER_STT_URL = "https://openrouter.ai/api/v1/audio/transcriptions"
OPENROUTER_STT_MODEL = "openai/gpt-4o-transcribe"
# OpenRouter gpt-4o-transcribe accepts only `mp3` and `wav` for the
# `input_audio.format` field. OGG / Opus / m4a aren't supported and
# return HTTP 400 on the wire. We map known formats here; OGG (the
# default Telegram voice_note container) needs transcoding before
# upload — see `_transcode_to_mp3` below.
_STT_FORMAT_BY_MIME = {
    "audio/mpeg": "mp3",
    "audio/mp3": "mp3",
    "audio/wav": "wav",
    "audio/x-wav": "wav",
}
_STT_FORMAT_BY_EXT = {
    ".mp3": "mp3",
    ".wav": "wav",
}
# Formats we know how to transcode to mp3 if `ffmpeg` is on PATH.
_STT_TRANSCODE_FROM_MIME = frozenset({
    "audio/ogg", "audio/oga", "audio/opus",
    "audio/mp4", "audio/x-m4a", "audio/m4a", "audio/aac",
    "video/mp4", "video/quicktime", "video/webm",
})
_STT_TRANSCODE_FROM_EXT = frozenset({
    ".ogg", ".oga", ".opus",
    ".m4a", ".aac", ".mp4", ".mov", ".webm",
})


def _stt_format_for(mime: str, filename: str) -> Optional[str]:
    """Pick OpenRouter input_audio.format from mime first, then file
    extension. Returns ``None`` when the input format is one OpenRouter
    can't handle natively (e.g. OGG/Opus from Telegram voice notes) —
    callers should transcode first or surface a clear error.
    """
    if mime:
        f = _STT_FORMAT_BY_MIME.get(mime.lower().split(";")[0].strip())
        if f:
            return f
    if filename:
        from pathlib import Path as _P
        f = _STT_FORMAT_BY_EXT.get(_P(filename).suffix.lower())
        if f:
            return f
    return None


def _stt_needs_transcode(mime: str, filename: str) -> bool:
    """True if the input is a known format we'd need to transcode
    (via ffmpeg) before sending to OpenRouter."""
    if mime and mime.lower().split(";")[0].strip() in _STT_TRANSCODE_FROM_MIME:
        return True
    if filename:
        from pathlib import Path as _P
        if _P(filename).suffix.lower() in _STT_TRANSCODE_FROM_EXT:
            return True
    return False


def _resolve_ffmpeg() -> Optional[str]:
    """Locate an ``ffmpeg`` binary.

    Order: system PATH (operator install / distro package) →
    ``imageio_ffmpeg.get_ffmpeg_exe()`` (static binary shipped with
    the ``imageio-ffmpeg`` wheel that ``src/requirements.txt`` pins).
    Returns the absolute path or ``None`` if neither is available.

    The ``imageio_ffmpeg`` fallback is what makes Telegram voice notes
    work out of the box on machines without a system ffmpeg —
    ``pip install`` is the only setup step the operator has to take.
    """
    import shutil as _shutil
    p = _shutil.which("ffmpeg")
    if p:
        return p
    try:
        import imageio_ffmpeg  # type: ignore[import-not-found]
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:  # noqa: BLE001
        return None


def _transcode_to_mp3(
    audio_bytes: bytes,
    *,
    sample_rate: Optional[int] = None,
    channels: Optional[int] = None,
    timeout: int = 60,
) -> Optional[bytes]:
    """Best-effort: run audio through ``ffmpeg`` to produce MP3.
    Returns the transcoded bytes or ``None`` if ffmpeg is missing or
    fails. Used to normalize incoming audio for STT endpoints that
    can't decode the original container (OGG/Opus, m4a/aac, mp4).

    Optional ``sample_rate`` / ``channels`` force resampling — needed
    for Qwen3-ASR via vLLM which only accepts 16 kHz mono. Default
    None preserves the source rate (what OpenRouter wants).

    The input is written to a temp file and handed to ffmpeg by path
    rather than piped on stdin. MP4 / M4A / MOV containers from phones
    and apps put the ``moov`` index atom at the END of the file (i.e.
    NOT ``+faststart``); decoding those needs ffmpeg to seek back to
    the audio ``mdat`` after it finally reads the index — impossible
    over a non-seekable stdin pipe. On a pipe ffmpeg bails ("partial
    file" / "Error during demuxing: Invalid data found") and emits a
    header-only MP3 (~140-220 bytes) *while still exiting 0*, which the
    downstream STT endpoint rejects as "Invalid or unsupported audio
    file". A seekable temp file lets ffmpeg decode moov-at-end inputs;
    OGG/Opus voice notes (already streamable) keep working unchanged."""
    import subprocess as _sub
    import tempfile as _tempfile
    ffmpeg = _resolve_ffmpeg()
    if not ffmpeg:
        return None
    try:
        with _tempfile.NamedTemporaryFile(suffix=".audio") as src:
            src.write(audio_bytes)
            src.flush()
            cmd = [ffmpeg, "-loglevel", "error", "-i", src.name]
            if sample_rate is not None:
                cmd += ["-ar", str(sample_rate)]
            if channels is not None:
                cmd += ["-ac", str(channels)]
            cmd += [
                "-codec:a", "libmp3lame", "-q:a", "4", "-f", "mp3", "pipe:1",
            ]
            try:
                proc = _sub.run(cmd, capture_output=True, timeout=timeout)
            except (_sub.TimeoutExpired, FileNotFoundError, OSError):
                return None
    except OSError:
        return None
    if proc.returncode != 0 or not proc.stdout:
        return None
    return proc.stdout


def _segment_audio(audio_bytes: bytes, *, seconds: int = 300) -> list[bytes]:
    """Split an MP3 into <=``seconds`` chunks via ffmpeg's segment muxer.
    Returns chunk bytes in order; a short clip yields a single chunk.
    Empty list if ffmpeg is unavailable or fails."""
    import subprocess as _sub, tempfile as _tf
    from pathlib import Path as _P
    ffmpeg = _resolve_ffmpeg()
    if not ffmpeg or not audio_bytes:
        return []
    with _tf.TemporaryDirectory() as d:
        src = _P(d) / "in.mp3"
        src.write_bytes(audio_bytes)
        pat = str(_P(d) / "seg_%04d.mp3")
        cmd = [ffmpeg, "-loglevel", "error", "-i", str(src),
               "-f", "segment", "-segment_time", str(seconds),
               "-c", "copy", pat]
        try:
            proc = _sub.run(cmd, capture_output=True, timeout=600)
        except (_sub.TimeoutExpired, OSError):
            return []
        if proc.returncode != 0:
            return []
        return [p.read_bytes() for p in sorted(_P(d).glob("seg_*.mp3"))]


async def _transcribe_segments(segments, post, on_progress=None) -> str:
    """POST each segment via async ``post(bytes)->str`` sequentially and
    join the non-empty transcripts with newlines. ``on_progress(k, n)``
    is awaited (if given) before each segment. One retry per segment."""
    parts: list[str] = []
    n = len(segments)
    for i, seg in enumerate(segments, 1):
        if on_progress is not None:
            await on_progress(i, n)
        try:
            txt = await post(seg)
        except Exception:  # noqa: BLE001
            txt = ""
        if not txt:
            try:
                txt = await post(seg)
            except Exception:  # noqa: BLE001
                txt = ""
        parts.append(txt or f"[segment {i} unavailable]")
    return "\n".join(parts).strip()


def _make_default_audio_downloader(api: "_TelegramAPI"):
    """Return an async ``download_audio(file_id) -> (bytes, filename)`` that
    pulls the file off the Telegram bot-file CDN.

    Used for both voice input (run through STT) and photos (forwarded
    as ACP ImageContent). Telegram's two-step flow: ``getFile`` returns
    a ``file_path``; the file itself lives at
    ``<api_base>/file/bot<token>/<file_path>``.
    """
    async def _dl(file_id: str):
        meta = await api.call("getFile", file_id=file_id)
        if not isinstance(meta, dict) or not meta.get("ok"):
            # Surface the reason instead of failing silently — the most
            # common one is "file is too big" (cloud Bot API's 20 MB
            # getFile cap), which the caller's size-guard normally
            # catches first, but log it here for anything that slips
            # through (e.g. file_size absent from the message).
            api._log.warning(
                "getFile failed: %s",
                meta.get("description") if isinstance(meta, dict) else meta,
            )
            return None
        result = meta.get("result")
        if not isinstance(result, dict):
            return None
        file_path = result.get("file_path")
        if not file_path:
            return None
        if getattr(api, "local_mode", False):
            # Self-hosted server returns an absolute on-disk path. Read it
            # directly (off the event loop — files can be large). Guard:
            # must be an existing absolute path, and must be confined to the
            # bot-api data root (default /var/lib/telegram-bot-api, overridable
            # via RTXCLAW_TELEGRAM_FILE_ROOT for testing). p.resolve() defeats
            # symlink / ".." traversal before the root check.
            from pathlib import Path as _P
            p = _P(file_path)
            if not p.is_absolute() or not p.is_file():
                api._log.warning("local getFile path not readable: %r", file_path)
                return None
            _root = _P(os.environ.get(
                "RTXCLAW_TELEGRAM_FILE_ROOT", "/var/lib/telegram-bot-api"))
            try:
                p.resolve().relative_to(_root.resolve())
            except ValueError:
                api._log.warning("local getFile path outside data root: %r", file_path)
                return None
            try:
                data = await asyncio.to_thread(p.read_bytes)
            except OSError as exc:
                api._log.warning("local file read failed: %s", exc)
                return None
            return data, p.name
        url = f"{api._api_base}/file/bot{api._token}/{file_path}"
        try:
            r = await api._http.get(url)
        except httpx.HTTPError as exc:
            api._log.warning("file download transport error: %s", exc)
            return None
        if r.status_code != 200 or not r.content:
            api._log.warning(
                "file download HTTP %s len=%d",
                r.status_code, len(r.content or b""),
            )
            return None
        # Path's basename gives a stable filename (e.g. voice/file_123.oga).
        from pathlib import Path as _P
        return r.content, _P(file_path).name

    return _dl


# ---------------------------------------------------------------------------
# TTS — voice-note replies for chats where the user spoke
# ---------------------------------------------------------------------------
#
# Mirrors the STT factory shape: env-driven, async callable returned by a
# factory. Used by ``_stream_turn_for_chat`` AFTER the assembled text reply
# is finalized, when the original user message was voice — so a spoken
# question gets a spoken answer alongside the text bubble.
#
# Provider: OpenRouter's ``/v1/audio/speech`` endpoint (announced 2026-05;
# same provider STT uses). Auth: ``OPENROUTER_API_KEY`` env var by default,
# with ``RTXCLAW_TTS_API_KEY`` and ``OPENAI_API_KEY`` as fallbacks for
# operators who want to point at OpenAI direct or another gateway. Override
# the upstream URL via ``RTXCLAW_TTS_BASE_URL``.
#
# Model id requires the **dated** slug — ``openai/gpt-4o-mini-tts``
# without the date returns HTTP 400 from OpenRouter. The dated slug pins
# the upstream snapshot so behaviour stays stable across upstream
# rolling-version bumps.

OPENROUTER_TTS_DEFAULT_URL = "https://openrouter.ai/api/v1/audio/speech"
OPENROUTER_TTS_DEFAULT_MODEL = "openai/gpt-4o-mini-tts-2025-12-15"
OPENROUTER_TTS_DEFAULT_VOICE = "alloy"
# How much text to bother with — TTS for a 5-page wall is wasteful, costly,
# and Telegram caps voice-note duration anyway. Hard cap at the OpenAI
# spec input limit (4096 chars).
TTS_MAX_INPUT_CHARS = 4000


def _make_default_openrouter_tts(api_key: str, log: logging.Logger):
    """Return an async ``tts(text, *, voice, model) -> Optional[bytes]``
    callable that synthesises ``text`` to MP3 via OpenRouter's
    ``/v1/audio/speech``. Returns the audio bytes on success or
    ``None`` on any failure (transport error, non-200, empty body).
    Failure is non-fatal — the text bubble already landed; the voice
    reply is bonus.

    ``api_key`` is captured at factory time so the caller can fail
    early when the env var is missing — see :func:`acp_main`.
    """
    base_url = (os.environ.get("RTXCLAW_TTS_BASE_URL") or OPENROUTER_TTS_DEFAULT_URL).rstrip("/")
    if base_url.endswith("/v1"):
        base_url = base_url + "/audio/speech"

    async def _tts(
        text: str,
        *,
        voice: str = OPENROUTER_TTS_DEFAULT_VOICE,
        model: str = OPENROUTER_TTS_DEFAULT_MODEL,
    ) -> Optional[bytes]:
        if not text or not text.strip():
            return None
        body = json.dumps({
            "model": model,
            "voice": voice,
            "input": text[:TTS_MAX_INPUT_CHARS],
            "response_format": "wav",
        })
        try:
            async with httpx.AsyncClient(
                timeout=httpx.Timeout(120.0, connect=10.0),
            ) as client:
                r = await client.post(
                    base_url,
                    content=body,
                    headers={
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                        "X-Title": "rtxclaw-telegram",
                    },
                )
        except httpx.HTTPError as exc:
            log.warning("TTS transport error: %s", exc)
            return None
        if r.status_code != 200:
            log.warning(
                "TTS HTTP %s detail=%s", r.status_code, r.text[:300],
            )
            return None
        if not r.content:
            log.warning("TTS empty response body")
            return None
        return r.content

    return _tts


def _make_default_openrouter_stt(api_key: str, log: logging.Logger):
    """Return an async ``stt(audio_bytes, *, mime, filename) -> transcript``
    callable that sends audio to OpenRouter's whisper-compatible
    transcription endpoint (gpt-4o-transcribe).

    ``api_key`` is captured at factory time so the caller can fail
    early if the env var is missing — see :func:`acp_main`.
    """
    async def _stt(audio_bytes: bytes, *, mime: str = "", filename: str = "") -> str:
        if not audio_bytes:
            return ""
        fmt = _stt_format_for(mime, filename)
        if fmt is None:
            # Input format isn't directly accepted by OpenRouter
            # (e.g. OGG/Opus from a Telegram voice note). Transcode
            # via ffmpeg if available.
            if _stt_needs_transcode(mime, filename):
                transcoded = _transcode_to_mp3(audio_bytes)
                if transcoded:
                    audio_bytes = transcoded
                    fmt = "mp3"
                else:
                    log.warning(
                        "STT skipped: input format %r needs transcode but "
                        "ffmpeg unavailable. `pip install imageio-ffmpeg` "
                        "(in src/requirements.txt) bundles a static "
                        "binary; rerun ./rtxclaw to reinstall the venv.",
                        mime or filename,
                    )
                    return ""
            else:
                log.warning("STT skipped: unknown audio format mime=%r file=%r",
                            mime, filename)
                return ""
        body = json.dumps({
            "model": OPENROUTER_STT_MODEL,
            "input_audio": {
                "data": base64.b64encode(audio_bytes).decode("ascii"),
                "format": fmt,
            },
        })
        try:
            async with httpx.AsyncClient(
                timeout=httpx.Timeout(120.0, connect=10.0),
            ) as client:
                r = await client.post(
                    OPENROUTER_STT_URL,
                    content=body,
                    headers={
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                        "X-Title": "rtxclaw-telegram",
                    },
                )
        except httpx.HTTPError as exc:
            log.warning("STT transport error: %s", exc)
            return ""
        if r.status_code != 200:
            log.warning(
                "STT HTTP %s detail=%s", r.status_code, r.text[:300],
            )
            return ""
        try:
            payload = r.json()
        except json.JSONDecodeError:
            log.warning("STT non-json: %s", r.text[:300])
            return ""
        return (payload.get("text") or "").strip()

    return _stt


def _make_default_qwen_stt(api_key: str, log: logging.Logger):
    """Return an async ``stt(audio_bytes, *, mime, filename) -> transcript``
    callable that POSTs to an OpenAI-compatible /v1/audio/transcriptions
    endpoint (standard Whisper API, multipart/form-data).

    Used when ``RTXCLAW_STT_BASE_URL`` is set (e.g. our TB07 Qwen3-ASR
    vLLM at http://192.168.0.70:8004/v1). Format routing differs from
    the OpenRouter chat-completions path:
        * mp3 / wav / ogg / opus  → POSTed directly (Qwen3-ASR accepts
          these natively via vLLM's ffmpeg-backed decoder).
        * m4a / aac / mp4 / mov / webm → transcoded to mp3 via the
          shared ``_transcode_to_mp3`` helper first (Qwen3-ASR rejects
          m4a containers with "Invalid or unsupported audio file").
    """
    base_url = (
        os.environ.get("RTXCLAW_STT_BASE_URL")
        or "http://192.168.0.70:8004/v1"
    ).rstrip("/")
    if not base_url.endswith("/audio/transcriptions"):
        base_url = base_url + "/audio/transcriptions"
    model = os.environ.get("RTXCLAW_STT_MODEL") or "qwen3-asr-1.7b"

    # Formats Qwen3-ASR (vLLM) accepts directly — verified by probe on
    # 2026-05-19. m4a / aac / mp4 still need bot-side transcode.
    _QWEN_STT_DIRECT_MIME = frozenset({
        "audio/mpeg", "audio/mp3", "audio/wav", "audio/x-wav",
        "audio/ogg", "audio/oga", "audio/opus",
    })
    _QWEN_STT_DIRECT_EXT = frozenset({
        ".mp3", ".wav", ".ogg", ".oga", ".opus",
    })

    async def _stt(audio_bytes: bytes, *, mime: str = "", filename: str = "", on_progress=None) -> str:
        if not audio_bytes:
            return ""
        transcoded = await asyncio.to_thread(
            _transcode_to_mp3, audio_bytes,
            sample_rate=16000, channels=1, timeout=600,
        )
        if not transcoded:
            log.warning("STT skipped: ffmpeg unavailable for resample-to-16k.")
            return ""
        segments = await asyncio.to_thread(_segment_audio, transcoded, seconds=300)
        if not segments:
            segments = [transcoded]

        async def _post_one(mp3_bytes: bytes) -> str:
            files = {"file": ("audio.mp3", mp3_bytes, "audio/mpeg")}
            data = {"model": model}
            headers = {"X-Title": "rtxclaw-telegram"}
            if api_key:
                headers["Authorization"] = f"Bearer {api_key}"
            log.info("STT → %s model=%s bytes=%d", base_url, model, len(mp3_bytes))
            try:
                async with httpx.AsyncClient(
                    timeout=httpx.Timeout(120.0, connect=10.0),
                ) as client:
                    r = await client.post(base_url, files=files, data=data, headers=headers)
            except httpx.HTTPError as exc:
                log.warning("STT transport error: %s", exc)
                return ""
            if r.status_code != 200:
                log.warning("STT HTTP %s detail=%s", r.status_code, r.text[:300])
                return ""
            try:
                return (r.json().get("text") or "").strip()
            except json.JSONDecodeError:
                log.warning("STT non-json: %s", r.text[:300])
                return ""

        return await _transcribe_segments(segments, _post_one, on_progress)

    return _stt


def _capabilities_for_chat(chat_id: int, *, trusted_chats: set[int]):
    """Return :class:`acp.schema.ClientCapabilities` for one chat.

    Public-internet inputs default to **text-only**: no fs read, no fs
    write, no terminal. A chat in ``trusted_chats`` gets
    ``fs.readTextFile=True`` so the operator can ask the agent to look at
    local files; we deliberately do NOT enable ``fs.writeTextFile`` or
    ``terminal`` even for trusted chats — those need a more deliberate
    uplift than the comma-separated env var policy.
    """
    # Lazy import — keep module-import cost low. ``acp.schema`` pulls in
    # pydantic + the SDK's full dataclass tree.
    import acp.schema as _acp

    fs = _acp.FileSystemCapabilities(
        read_text_file=chat_id in trusted_chats,
        write_text_file=False,
    )
    return _acp.ClientCapabilities(fs=fs, terminal=False)


# ---------------------------------------------------------------------------
# Telegram HTTP client (slim wrapper around httpx)
# ---------------------------------------------------------------------------


class _TelegramAPI:
    """Minimal Telegram Bot API client.

    Owns the ``httpx.AsyncClient`` and builds the bot-token URL lazily so
    the token never enters a stack trace or repr. Used by both
    :class:`AcpTelegramBot` (for the long-poll loop) and
    :class:`_RollingMessage` (for streaming edits).
    """

    def __init__(
        self,
        token: str,
        *,
        api_base: str = TELEGRAM_API,
        log: Optional[logging.Logger] = None,
    ) -> None:
        self._token = token
        self._api_base = api_base.rstrip("/")
        # "local mode" = pointed at a self-hosted telegram-bot-api server
        # (not the public cloud). In local mode getFile returns an
        # absolute on-disk path and the 20 MB download cap is lifted.
        self.local_mode = not self._api_base.startswith("https://api.telegram.org")
        self._http = httpx.AsyncClient(
            timeout=httpx.Timeout(60.0, connect=10.0),
        )
        self._log = log or logging.getLogger("rtxclaw.telegram")

    async def close(self) -> None:
        await self._http.aclose()

    async def call(self, method: str, **params: Any) -> dict:
        """Call a Telegram Bot API method. Telegram-side errors come
        back as ``{"ok": false, ...}``; we surface them to the caller
        without raising so most callers can log-and-continue.
        """
        url = f"{self._api_base}/bot{self._token}/{method}"
        try:
            r = await self._http.post(url, json=params)
        except httpx.HTTPError as e:
            self._log.warning("telegram %s: transport error: %s", method, e)
            return {"ok": False, "description": str(e)}
        try:
            return r.json()
        except json.JSONDecodeError:
            self._log.warning(
                "telegram %s: non-json response (status=%s): %s",
                method, r.status_code, r.text[:300],
            )
            return {"ok": False, "description": f"http {r.status_code}"}

    async def send_message(
        self,
        chat_id: int,
        text: str,
        *,
        message_thread_id: Optional[int] = None,
        parse_mode: Optional[str] = None,
    ) -> Optional[int]:
        """Send ``text`` to ``chat_id``; return the new message_id or None.

        ``parse_mode`` is optional (default: plain text). Pass
        ``"MarkdownV2"`` or ``"HTML"`` when the caller has explicitly
        prepared the body to satisfy Telegram's strict escaping rules —
        an unescaped special character will 400 the whole reply. Plain
        text remains the right default for anything carrying user /
        model output (tool args, error blobs, etc.) where escaping is
        impractical.
        """
        truncated = _truncate_for_telegram(text)
        t0 = time.monotonic()
        params: dict[str, Any] = {
            "chat_id": chat_id,
            "text": truncated,
            "disable_web_page_preview": True,
        }
        if message_thread_id is not None:
            params["message_thread_id"] = message_thread_id
        if parse_mode is not None:
            params["parse_mode"] = parse_mode
        res = await self.call("sendMessage", **params)
        elapsed_ms = (time.monotonic() - t0) * 1000
        if not res.get("ok"):
            self._log.warning(
                "TX FAIL chat=%s len=%d t=%.0fms err=%s",
                chat_id, len(truncated), elapsed_ms, res.get("description"),
            )
            return None
        msg_id = (res.get("result") or {}).get("message_id")
        preview = truncated[:120].replace("\n", " ")
        self._log.info(
            "TX chat=%s msg=%s len=%d t=%.0fms text=%r%s",
            chat_id, msg_id, len(truncated), elapsed_ms, preview,
            "…" if len(truncated) > 120 else "",
        )
        return msg_id

    async def send_voice(
        self,
        chat_id: int,
        audio_bytes: bytes,
        *,
        message_thread_id: Optional[int] = None,
        caption: Optional[str] = None,
        mime: str = "audio/mpeg",
        filename: str = "voice.mp3",
    ) -> Optional[int]:
        """Upload ``audio_bytes`` as a Telegram voice/audio message.

        Sends via the ``sendAudio`` Bot API method (multipart upload) —
        ``sendVoice`` requires OGG/Opus framing which would mean an
        extra ffmpeg pass. ``sendAudio`` accepts MP3 directly and the
        Telegram client renders it with a play-button bubble next to
        the text reply, which is the same UX users expect from a
        voice reply.

        Returns the new message_id or None on failure.
        """
        url = f"{self._api_base}/bot{self._token}/sendAudio"
        data: dict[str, str] = {"chat_id": str(chat_id)}
        if message_thread_id is not None:
            data["message_thread_id"] = str(message_thread_id)
        if caption:
            data["caption"] = _truncate_for_telegram(caption)
        files = {"audio": (filename, audio_bytes, mime)}
        t0 = time.monotonic()
        try:
            r = await self._http.post(url, data=data, files=files)
        except httpx.HTTPError as e:
            self._log.warning("telegram sendAudio: transport error: %s", e)
            return None
        elapsed_ms = (time.monotonic() - t0) * 1000
        try:
            res = r.json()
        except json.JSONDecodeError:
            self._log.warning(
                "telegram sendAudio: non-json (status=%s): %s",
                r.status_code, r.text[:300],
            )
            return None
        if not res.get("ok"):
            self._log.warning(
                "TX-AUDIO FAIL chat=%s bytes=%d t=%.0fms err=%s",
                chat_id, len(audio_bytes), elapsed_ms, res.get("description"),
            )
            return None
        msg_id = (res.get("result") or {}).get("message_id")
        self._log.info(
            "TX-AUDIO chat=%s msg=%s bytes=%d t=%.0fms",
            chat_id, msg_id, len(audio_bytes), elapsed_ms,
        )
        return msg_id

    async def send_document(
        self, chat_id, document_bytes, *, filename="file.txt",
        caption=None, mime="text/plain; charset=utf-8",
        message_thread_id=None,
    ):
        """Upload bytes as a Telegram document. Returns message_id or None."""
        url = f"{self._api_base}/bot{self._token}/sendDocument"
        data = {"chat_id": str(chat_id)}
        if message_thread_id is not None:
            data["message_thread_id"] = str(message_thread_id)
        if caption:
            data["caption"] = _truncate_for_telegram(caption)
        files = {"document": (filename, document_bytes, mime)}
        try:
            r = await self._http.post(url, data=data, files=files)
        except httpx.HTTPError as exc:
            self._log.warning("sendDocument transport error: %s", exc)
            return None
        if r.status_code != 200:
            self._log.warning("sendDocument HTTP %s: %s", r.status_code, r.text[:200])
            return None
        try:
            return (r.json().get("result") or {}).get("message_id")
        except json.JSONDecodeError:
            return None

    async def edit_message(
        self, chat_id: int, message_id: int, text: str,
    ) -> tuple[bool, float]:
        """In-place edit. Returns ``(ok, retry_after_s)``.

        ``retry_after_s > 0`` only when Telegram explicitly returned 429
        with ``parameters.retry_after``. The caller uses it to bump the
        adaptive throttle. ``ok=True`` covers both real success and the
        benign "message is not modified" reject (same text).
        """
        truncated = _truncate_for_telegram(text)
        t0 = time.monotonic()
        res = await self.call(
            "editMessageText",
            chat_id=chat_id,
            message_id=message_id,
            text=truncated,
            disable_web_page_preview=True,
        )
        elapsed_ms = (time.monotonic() - t0) * 1000
        if not res.get("ok"):
            desc = (res.get("description") or "")
            desc_lc = desc.lower()
            if "not modified" in desc_lc:
                return (True, 0.0)
            retry_after = 0.0
            params = res.get("parameters") or {}
            if isinstance(params, dict):
                ra = params.get("retry_after")
                if isinstance(ra, (int, float)) and ra > 0:
                    retry_after = float(ra)
            if retry_after > 0:
                self._log.warning(
                    "EDIT 429 chat=%s msg=%s retry_after=%.1fs",
                    chat_id, message_id, retry_after,
                )
            else:
                self._log.warning(
                    "EDIT FAIL chat=%s msg=%s len=%d t=%.0fms err=%s",
                    chat_id, message_id, len(truncated), elapsed_ms, desc,
                )
            return (False, retry_after)
        self._log.debug(
            "EDIT chat=%s msg=%s len=%d t=%.0fms",
            chat_id, message_id, len(truncated), elapsed_ms,
        )
        return (True, 0.0)


# ---------------------------------------------------------------------------
# Rolling-message renderer (streams ACP updates into in-place edits)
# ---------------------------------------------------------------------------


class _RollingMessage:
    """Streaming renderer that rolls a long reply across messages.

    Telegram caps text at 4096 chars per message. Once the rendered
    buffer outgrows the cap we:

      1. Pick a clean break point (``_split_at``: newline > space > hard).
      2. Force-edit the current placeholder to that head text.
      3. Send a fresh placeholder.
      4. Continue streaming into the new placeholder.

    Throttle/embargo state resets per placeholder because Telegram's
    per-message edit limit is independent. Earlier (frozen) messages
    are never re-edited.
    """

    def __init__(
        self,
        api: _TelegramAPI,
        chat_id: int,
        *,
        placeholder_id: int,
        idle_text: str = "💭 thinking…",
        log: Optional[logging.Logger] = None,
        thread_id: Optional[int] = None,
    ) -> None:
        self.api = api
        self.chat_id = chat_id
        self.thread_id = thread_id
        self.idle_text = idle_text
        self._log = log or logging.getLogger("rtxclaw.telegram")
        # message_ids[-1] is the active rolling placeholder; earlier
        # entries are frozen and read-only.
        self.message_ids: list[int] = [placeholder_id]
        self.frozen_chars: int = 0
        self.last_edit_at: float = 0.0
        self.last_rendered: str = idle_text
        self.cur_throttle: float = EDIT_THROTTLE_S
        self.embargo_until: float = 0.0
        self.n_edits_ok: int = 0
        self.n_edits_429: int = 0
        self.n_rollovers: int = 0
        self._last_full_text: str = ""

    async def _commit_and_rollover(self, head: str) -> bool:
        ok, retry_after = await self.api.edit_message(
            self.chat_id, self.message_ids[-1], head,
        )
        if not ok and retry_after > 0:
            try:
                await asyncio.wait_for(
                    asyncio.sleep(retry_after + 0.5),
                    timeout=min(retry_after + 1.0, 30.0),
                )
            except asyncio.TimeoutError:
                pass
            await self.api.edit_message(
                self.chat_id, self.message_ids[-1], head,
            )
        new_id = await self.api.send_message(
            self.chat_id, "…", message_thread_id=self.thread_id,
        )
        if new_id is None:
            self._log.warning(
                "rollover: send failed chat=%s — overflow held back; "
                "next paint will retry",
                self.chat_id,
            )
            return False
        self.frozen_chars += len(head)
        self.message_ids.append(new_id)
        self.last_edit_at = 0.0
        self.last_rendered = "…"
        self.cur_throttle = EDIT_THROTTLE_S
        self.embargo_until = 0.0
        self.n_rollovers += 1
        return True

    async def _drain_overflow(self) -> bool:
        full = self._last_full_text or ""
        while True:
            pending = full[self.frozen_chars:]
            if len(pending) <= TELEGRAM_MAX_TEXT:
                return True
            cut = _split_at(pending, TELEGRAM_MAX_TEXT)
            head = pending[:cut].rstrip()
            if not head:
                head = pending[:TELEGRAM_MAX_TEXT]
                cut = TELEGRAM_MAX_TEXT
            if not await self._commit_and_rollover(head):
                return False

    async def update(self, text: str, *, force: bool = False) -> None:
        if not text:
            text = self.idle_text
        self._last_full_text = text
        if not await self._drain_overflow():
            return
        pending = text[self.frozen_chars:] or self.idle_text
        # Telegram's ``editMessageText`` rejects whitespace-only bodies
        # with ``Bad Request: text must be non-empty``. Models often
        # emit a few leading ``\n``s before real content lands; skip
        # the edit until non-whitespace shows up so we don't burn an
        # EDIT FAIL per chunk and leave the chat stuck on the idle
        # placeholder.
        if not pending.strip():
            return
        if pending == self.last_rendered and not force:
            return
        now = time.monotonic()
        if not force and now < self.embargo_until:
            return
        if not force and now - self.last_edit_at < self.cur_throttle:
            return
        ok, retry_after = await self.api.edit_message(
            self.chat_id, self.message_ids[-1], pending,
        )
        now = time.monotonic()
        if ok:
            self.last_edit_at = now
            self.last_rendered = pending
            self.n_edits_ok += 1
            if self.cur_throttle > EDIT_THROTTLE_S:
                self.cur_throttle = max(
                    EDIT_THROTTLE_S, self.cur_throttle * 0.8,
                )
            return
        if retry_after > 0:
            self.n_edits_429 += 1
            self.embargo_until = now + retry_after
        self.cur_throttle = min(
            EDIT_THROTTLE_MAX_S, self.cur_throttle * 2,
        )
        self.last_edit_at = now

    async def finalize(self, text: str) -> None:
        if not text:
            text = self.idle_text
        self._last_full_text = text
        await self._drain_overflow()
        pending = text[self.frozen_chars:] or self.idle_text
        # Same Telegram constraint as ``update``: an all-whitespace
        # final reply 400s. If the model produced only newlines /
        # spaces (or nothing), fall back to the idle placeholder so
        # the user at least sees that the turn finished without an
        # API error.
        if not pending.strip():
            pending = self.idle_text
        ok, retry_after = await self.api.edit_message(
            self.chat_id, self.message_ids[-1], pending,
        )
        if not ok and retry_after > 0:
            try:
                await asyncio.wait_for(
                    asyncio.sleep(retry_after + 0.5),
                    timeout=min(retry_after + 1.0, 30.0),
                )
            except asyncio.TimeoutError:
                pass
            await self.api.edit_message(
                self.chat_id, self.message_ids[-1], pending,
            )
        self.last_rendered = pending


# ---------------------------------------------------------------------------
# AcpTelegramBot
# ---------------------------------------------------------------------------


class AcpTelegramBot:
    """ACP-driven Telegram bot.

    Connects to one rtxclaw agent per chat over the ACP transport
    (WebSocket if ``acp_url`` is set, otherwise stdio-spawned
    ``rtxclaw_agent acp-stdio``). Maps each Telegram chat to one ACP
    session; per-chat :class:`acp.schema.ClientCapabilities` so trusted
    chats can opt into ``fs.readTextFile`` while the public default stays
    text-only.

    Concurrency model:

    * One :class:`AcpClient` per chat, cached in ``self._clients``.
      Reusing one client across chats would force a single capability
      profile on the whole process; per-chat clients let the trusted
      uplift survive next to the locked-down default.
    * One ``asyncio.Lock`` per chat in ``self._chat_locks`` so two
      messages from the same chat serialize on the same session. The
      agent does not enforce per-session serialization, so we have to.
    * Telegram I/O is plain JSON-over-HTTP through :class:`_TelegramAPI`.

    Test seam: every external dependency is injectable.
    ``client_factory`` is an async callable
    ``(chat_id, capabilities) -> AcpClient`` that returns an
    already-initialized client (no ``initialize()`` call from the bot).
    ``api`` is the Telegram-side bridge. ``stt``, ``download_audio`` are
    the audio path stubs. Tests pass stubs and never open a network
    socket.
    """

    def __init__(
        self,
        tg_cfg: TelegramConfig,
        *,
        acp_url: Optional[str] = None,
        acp_bearer_token: Optional[str] = None,
        trusted_chats: Optional[set[int]] = None,
        log: Optional[logging.Logger] = None,
        client_factory: Optional[Any] = None,
        api: Optional[_TelegramAPI] = None,
        stt: Optional[Any] = None,
        tts: Optional[Any] = None,
        download_audio: Optional[Any] = None,
        download_image: Optional[Any] = None,
    ) -> None:
        self.tg_cfg = tg_cfg
        self._log = log or logging.getLogger("rtxclaw.telegram")
        self.acp_url = (
            acp_url
            if acp_url is not None
            else os.environ.get(ACP_DEFAULT_WS_URL_ENV, "").strip()
        )
        self.acp_bearer_token = (
            acp_bearer_token
            if acp_bearer_token is not None
            else os.environ.get(ACP_BEARER_TOKEN_ENV, "").strip() or None
        )
        self.trusted_chats = (
            set(trusted_chats)
            if trusted_chats is not None
            else _trusted_chats_from_env_or_cfg(tg_cfg)
        )
        self._client_factory = client_factory or self._default_client_factory
        # ``api`` defaults to ``None`` so unit tests that never run the
        # long-poll loop (and thus never need outbound Telegram I/O)
        # don't have to construct one. ``run()`` instantiates a real
        # ``_TelegramAPI`` if ``api`` is None.
        self._api = api
        self._stt = stt
        self._tts = tts
        self._download_audio = download_audio
        # Photo download factory — mirrors the audio path. Defaults
        # to the bot-file CDN downloader if the AcpTelegramBot is
        # constructed via :meth:`from_config`; tests inject a stub.
        self._download_image = download_image or download_audio

        # ``_sessions`` is nested chat_key → agent_name → session_id
        # so a chat that switches agents back and forth resumes the
        # right session for each. The on-disk map auto-migrates from
        # the Phase-A flat shape on first read.
        self._sessions: dict[str, dict[str, str]] = (
            _load_acp_session_map(tg_cfg)
        )
        self._stale: set[str] = set()
        # ACP clients keyed by chat_key — each chat gets its own
        # connection to whichever agent the route resolves to. When a
        # chat switches agents (Phase B), the cached entry is dropped
        # and the next message rebuilds against the new target.
        self._clients: dict[str, Any] = {}
        # Subprocess handles for stdio-spawned children, keyed on the
        # same chat_id string. Held so ``close()`` can ``terminate()`` /
        # ``wait()`` them — orderly stdin EOF first, then SIGTERM.
        self._child_procs: dict[str, Any] = {}
        # Monotonic timestamp of the most recent ``/stop``/``/cancel``/
        # ``/abort`` per (chat, thread). Used purely for UX visibility:
        # if the user double-taps within ``_ABORT_DOUBLE_PRESS_S``, the
        # ack reply notes that the bridge will have escalated to
        # SIGKILL on its side (see acp_bridge.py ``_HARD_KILL_WINDOW_S``,
        # fix D). The escalation happens server-side regardless of
        # whether we surface it here — this dict just powers the
        # "(force-kill escalation)" suffix on the second ack.
        self._last_abort_at: dict[tuple[int, Optional[int]], float] = {}
        # AgentConfig cache so we don't re-read disk per-message.
        # Keyed by agent name; bot restart picks up edits.
        self._agent_cfg_cache: dict[str, AgentConfig] = {}
        self._chat_locks: dict[str, asyncio.Lock] = {}
        # Per-(chat,thread) display visibility — frontend-side state,
        # never on the ACP wire. The agent always emits
        # ``agent_thought_chunk`` and ``tool_call_update`` regardless;
        # we decide whether to render. Mirrors the TUI's
        # ``reasoning_visibility`` / ``tool_output_visible`` toggles.
        # Defaults: thoughts hidden, tool headers hidden — match the
        # legacy per-chat defaults so a fresh chat behaves the same.
        # Hydrated from disk so ``/tools on`` and ``/reasoning stream``
        # outlive a bot restart — without this, redeploying the bot
        # silently flips every chat back to off/off and the operator
        # has to retype every toggle.
        self._visibility: dict[str, dict[str, Any]] = (
            _load_visibility_map(tg_cfg)
        )

        # Long-poll loop state.
        self._stop = asyncio.Event()
        self._dispatched: set[asyncio.Task] = set()
        # Chats we've already bounced once with a deny reply, so a
        # script-kiddie can't get us to flood Telegram.
        self._denied_chats: set[int] = set()
        # Bot's @username, populated by ``getMe`` at startup. Used to
        # strip ``@<botname>`` from inbound text — Telegram delivers
        # ``/cmd@<botname>`` for slash commands in groups and a bare
        # leading ``@<botname>`` for natural-language mentions, neither
        # of which the agent should see verbatim. ``""`` until ``run()``
        # has connected; ``_strip_bot_mention`` is a no-op until then.
        self._bot_username: str = ""
        # Bot's numeric user id, also from ``getMe``. Used by
        # ``mention_required_in_groups`` to recognise direct replies
        # to the bot's own messages as an implicit mention — common
        # Telegram convention is that "swipe to reply" addresses the
        # author without typing the @handle.
        self._bot_user_id: int = 0
        # In-flight ``session/request_permission`` prompts awaiting a
        # button press. token → asyncio.Future[str]; the per-client
        # permission handler (see ``_make_permission_handler``) parks a
        # future here and ``_handle_callback_query`` resolves it with
        # the chosen ACP optionId when the user taps an inline button.
        self._pending_permissions: dict[str, asyncio.Future] = {}

    # ---- per-chat agent resolution -------------------------------------

    def _agent_cfg(
        self, chat_id: int, thread_id: Optional[int] = None,
    ) -> AgentConfig:
        """Resolve the :class:`AgentConfig` that handles
        ``(chat_id, thread_id)`` and memoize it.

        Routing comes from :meth:`TelegramConfig.agent_for` —
        per-(chat,thread) override, then bare-chat override, then
        ``default_agent``. Agents are loaded lazily; a config edit
        on disk is picked up by the next bot restart, not the next
        message (intentional — multi-agent routing means we don't
        want to file-stat every agent on every dispatch).
        """
        name = self.tg_cfg.agent_for(chat_id, thread_id)
        cached = self._agent_cfg_cache.get(name)
        if cached is not None:
            return cached
        cfg = AgentConfig.load(name)
        self._agent_cfg_cache[name] = cfg
        return cfg

    @staticmethod
    def _list_configured_agents() -> list[str]:
        """Walk ``agents_root()`` and return every directory that
        carries a ``config.json`` (i.e. is a configured agent).

        Sorted alphabetically — operators see a stable list across
        ``/agents`` invocations regardless of filesystem walk order.
        """
        from rtxclaw_core.agent import agents_root
        root = agents_root()
        if not root.is_dir():
            return []
        names: list[str] = []
        for entry in root.iterdir():
            if not entry.is_dir():
                continue
            if (entry / "config.json").is_file():
                names.append(entry.name)
        names.sort()
        return names

    def _is_known_agent(self, name: str) -> bool:
        """Quick membership check for the slash-command dispatcher.

        Memoised in ``_agent_cfg_cache`` once an agent is loaded;
        otherwise probed directly against the on-disk config so a
        freshly-scaffolded agent shows up without a bot restart.
        """
        if not name:
            return False
        if name in self._agent_cfg_cache:
            return True
        try:
            from rtxclaw_core.agent import agents_root
            return (agents_root() / name / "config.json").is_file()
        except Exception:  # noqa: BLE001
            return False

    # ---- chat → session persistence ------------------------------------

    async def _reply(
        self, chat_id: int, text: str,
        thread_id: Optional[int] = None,
    ) -> None:
        """One-line wrapper around ``send_message`` that propagates
        ``thread_id`` so replies in a Telegram forum topic stay in
        that topic. No-op when ``self._api`` is None (unit-test path).
        """
        if self._api is None:
            return
        await self._api.send_message(
            chat_id, text, message_thread_id=thread_id,
        )

    @staticmethod
    def _session_key(chat_id: int, thread_id: Optional[int] = None) -> str:
        """Compose the persistence key for a (chat, topic) pair.

        Forum topics need separate sessions so messages in different
        topics don't conflate. Non-forum chats and the General topic
        (Telegram doesn't set ``message_thread_id`` there) keep the
        legacy bare-chat-id key, so existing on-disk mappings survive.
        """
        if thread_id is None:
            return str(chat_id)
        return f"{chat_id}:{thread_id}"

    def _stale_key(self, chat_key: str, agent_name: str) -> str:
        """Compose the per-(chat, agent) staleness key.

        ``_stale`` is a flat set of strings; staleness is per-(chat,
        agent) so a chat that switched agents doesn't drag the new
        agent's binding into "needs session_new" the next message.
        """
        return f"{chat_key}@{agent_name}"

    def get_session_id(
        self, chat_id: int, thread_id: Optional[int] = None,
        agent_name: Optional[str] = None,
    ) -> Optional[str]:
        """Persisted session id for ``(chat, thread, agent)`` or None.

        ``agent_name`` defaults to the route resolved by
        :meth:`TelegramConfig.agent_for` so callers that don't care
        about explicit overrides keep working unchanged. Returns
        ``None`` for the (chat, agent) tuple if it was marked stale
        by :meth:`verify_sessions_on_startup` — the next message
        opens a fresh session.
        """
        key = self._session_key(chat_id, thread_id)
        agent = agent_name or self.tg_cfg.agent_for(chat_id, thread_id)
        if self._stale_key(key, agent) in self._stale:
            return None
        per_agent = self._sessions.get(key) or {}
        return per_agent.get(agent)

    def _set_session_id(
        self, chat_id: int, session_id: str,
        thread_id: Optional[int] = None,
        agent_name: Optional[str] = None,
    ) -> None:
        key = self._session_key(chat_id, thread_id)
        agent = agent_name or self.tg_cfg.agent_for(chat_id, thread_id)
        per_agent = self._sessions.setdefault(key, {})
        per_agent[agent] = session_id
        self._stale.discard(self._stale_key(key, agent))
        _save_acp_session_map(self.tg_cfg, self._sessions)

    async def _reopen_session_after_loss(
        self,
        client: Any,
        chat_id: int,
        thread_id: Optional[int],
        sid: Optional[str],
    ) -> str:
        """Recover when the gateway no longer recognizes ``sid``.

        Two failure modes share this path:
          * the gateway's child idle-reaped the session between turns;
          * the gateway parent itself restarted (OOM, redeploy) so the
            in-memory ``child.sessions`` set is empty for everyone.

        Strategy: try ``session/load`` first — if persistence still
        has the turn history, the gateway re-attaches the id to a
        fresh child and we keep continuity. If load fails (no record
        on disk, schema mismatch, agent forgot), allocate a new id
        via ``session/new`` and rebind the chat. Either way the
        caller gets a session id that's live on the gateway right
        now.

        On success the chat's persisted session map is updated so
        the next turn doesn't repeat the recovery dance. The old
        ``sid`` (if reused) stays in place; a brand-new id replaces
        it.
        """
        agent_cfg = self._agent_cfg(chat_id, thread_id)
        cwd = str(agent_cfg.home)
        if sid:
            try:
                await client.session_load(sid, cwd=cwd)
                self._log.info(
                    "session reopen via session/load chat=%s sid=%s",
                    chat_id, sid,
                )
                return sid
            except Exception as exc:  # noqa: BLE001
                self._log.warning(
                    "session/load after loss failed chat=%s sid=%s err=%s "
                    "— falling back to session/new",
                    chat_id, sid, exc,
                )
        new_sid = await client.session_new(cwd=cwd)
        self._set_session_id(chat_id, new_sid, thread_id)
        self._log.info(
            "session reopen via session/new chat=%s old_sid=%s new_sid=%s",
            chat_id, sid, new_sid,
        )
        return new_sid

    def _drop_session_id(
        self, chat_id: int, thread_id: Optional[int] = None,
        agent_name: Optional[str] = None,
        all_agents: bool = False,
    ) -> None:
        """Drop the session binding for ``(chat, thread, agent)``.

        With ``all_agents=True`` clears every per-agent binding for
        that chat — matches the legacy "/new wipes the chat" UX.
        Otherwise only the routed (or named) agent's binding is
        cleared, so switching agents back later resumes the OTHER
        agent's session intact.
        """
        key = self._session_key(chat_id, thread_id)
        per_agent = self._sessions.get(key)
        changed = False
        if per_agent is not None:
            if all_agents:
                self._sessions.pop(key, None)
                changed = True
            else:
                agent = (
                    agent_name
                    or self.tg_cfg.agent_for(chat_id, thread_id)
                )
                if agent in per_agent:
                    per_agent.pop(agent, None)
                    if not per_agent:
                        self._sessions.pop(key, None)
                    changed = True
        if changed:
            _save_acp_session_map(self.tg_cfg, self._sessions)
        # Stale set: scoped to (chat, agent). Clear matching entries.
        if all_agents:
            self._stale = {
                s for s in self._stale if not s.startswith(f"{key}@")
            }
        else:
            agent = (
                agent_name
                or self.tg_cfg.agent_for(chat_id, thread_id)
            )
            self._stale.discard(self._stale_key(key, agent))
        # Drop the visibility cache too — a fresh /new should land on
        # default (off/off) just like the TUI does.
        self._visibility.pop(key, None)

    # ---- per-(chat,thread) display visibility --------------------------

    def _get_visibility(
        self, chat_id: int, thread_id: Optional[int] = None,
    ) -> dict[str, Any]:
        """Return the ``{reasoning_visibility, tool_output}`` map for
        ``(chat, thread)``. Auto-initializes to defaults (``"off"``)
        on first access so callers can read without checking presence.

        ``tool_output`` is a 3-state string: ``"off"`` / ``"on"`` /
        ``"stream"`` — see ``normalize_tool_output`` for semantics.
        Migrates legacy bool ``tool_output_visible`` records on read.
        """
        key = self._session_key(chat_id, thread_id)
        cur = self._visibility.setdefault(key, {
            "reasoning_visibility": "off",
            "tool_output": "off",
        })
        # Backwards-compat: an old session record may still carry the
        # legacy bool ``tool_output_visible``. Translate True → "on",
        # False → "off" so the new gate-by-string code path doesn't
        # crash on stale state.
        if "tool_output" not in cur and "tool_output_visible" in cur:
            cur["tool_output"] = "on" if cur.get("tool_output_visible") else "off"
        cur.setdefault("tool_output", "off")
        return cur

    def _set_reasoning_visibility(
        self, chat_id: int, thread_id: Optional[int], level: str,
    ) -> None:
        """Set the per-(chat,thread) reasoning visibility. Caller is
        expected to validate ``level`` against
        ``normalize_reasoning_level`` first.
        """
        self._get_visibility(chat_id, thread_id)["reasoning_visibility"] = level
        _save_visibility_map(self.tg_cfg, self._visibility)

    def _set_tool_output_level(
        self, chat_id: int, thread_id: Optional[int], level: str,
    ) -> None:
        """Set the per-(chat,thread) tool-output visibility level.

        Caller validates ``level`` against ``normalize_tool_output``
        first; the engine accepts ``"off"`` / ``"on"`` / ``"stream"``.
        """
        self._get_visibility(chat_id, thread_id)["tool_output"] = level
        _save_visibility_map(self.tg_cfg, self._visibility)

    async def verify_sessions_on_startup(self) -> None:
        """For each persisted ``(chat, agent)`` pair, call
        ``session/load`` to verify.

        With per-(chat, agent) routing the same chat may carry one
        binding per agent it has used; we only verify the binding
        for the agent the chat is CURRENTLY routed to. Other-agent
        bindings are left untouched on disk — switching back later
        will pick them up and verify lazily.
        """
        if not self._sessions:
            return
        for key in list(self._sessions.keys()):
            # ``key`` is the chat_key — bare chat_id or
            # ``"<chat_id>:<thread_id>"`` for forum topics. Parse the
            # thread_id back out so the per-chat agent resolver picks
            # the right route (a thread-pinned agent must be honored
            # at startup verification too).
            chat_id, thread_id = _parse_chat_key(key)
            if chat_id is None:
                # Malformed key — mark every per-agent binding stale.
                for agent_name in (self._sessions.get(key) or {}).keys():
                    self._stale.add(self._stale_key(key, agent_name))
                continue
            agent_cfg = self._agent_cfg(chat_id, thread_id)
            sid = (self._sessions.get(key) or {}).get(agent_cfg.name)
            if not sid:
                # No binding for the routed agent — nothing to
                # verify. Other agents' bindings will be lazily
                # verified the first time the chat switches to
                # them.
                continue
            try:
                client = await self._get_or_open_client(chat_id, thread_id)
            except Exception:  # noqa: BLE001
                self._log.exception(
                    "verify_sessions_on_startup: open client failed "
                    "for chat=%s agent=%s; marking stale",
                    key, agent_cfg.name,
                )
                self._stale.add(self._stale_key(key, agent_cfg.name))
                continue
            try:
                await client.session_load(sid, cwd=str(agent_cfg.home))
            except Exception as e:  # noqa: BLE001
                self._log.warning(
                    "verify_sessions_on_startup: session_load failed "
                    "chat=%s agent=%s sid=%s err=%s — marking stale",
                    key, agent_cfg.name, sid, e,
                )
                self._stale.add(self._stale_key(key, agent_cfg.name))

    # ---- client / capability wiring ------------------------------------

    async def _default_client_factory(
        self, chat_id: int, capabilities,
        thread_id: Optional[int] = None,
    ):
        """Open one ``AcpClient`` for ``(chat_id, thread_id)``.

        Production path (the only deployed shape): the gateway —
        a single ``rtxclaw gateway-serve`` process hosting every
        agent under ``/acp/<name>`` — is reachable over Streamable
        HTTP at ``self.acp_url``. We open one HTTP connection per
        ``(chat, thread)`` pair against the agent the chat is
        routed to. The gateway holds each agent in-memory via its
        :class:`AgentRegistry`; we never spawn a per-agent child.

        ``acp_url`` accepts ``http(s)://host:port`` (gateway) or
        ``ws(s)://host:port/acp`` (legacy WS endpoint, preserved for
        tests that fake an ACP server). Empty / unset falls through to
        a stdio spawn — kept solely as a test-time fallback so
        unit tests that don't run the gateway can still drive the bot
        end-to-end.
        """
        agent_cfg = self._agent_cfg(chat_id, thread_id)

        if self.acp_url:
            scheme = self.acp_url.split("://", 1)[0].lower()
            if scheme in ("http", "https"):
                from rtxclaw_acp.client.http_spawn import connect_http

                # Gateway routes by mount path; per-agent endpoint is
                # ``<gateway-url>/acp/<agent>``. ``connect_http`` then
                # appends ``/acp`` for the actual JSON-RPC route, so
                # the wire URL ends up at ``…/acp/<agent>/acp`` —
                # matches gateway.py's ``Mount("/acp/<agent>", …)``
                # over a sub-app whose own routes live under ``/acp``.
                agent_url = (
                    f"{self.acp_url.rstrip('/')}/acp/{agent_cfg.name}"
                )
                client = await connect_http(
                    agent_url,
                    client_capabilities=capabilities,
                    bearer_token=self.acp_bearer_token or None,
                )
                # ``connect_http`` already runs initialize() during
                # connect (it has to — the connection id is in the
                # initialize response headers).
                return client
            if scheme in ("ws", "wss"):
                from rtxclaw_acp.client.ws_spawn import connect_ws

                client, ws_session = await connect_ws(
                    self.acp_url,
                    client_capabilities=capabilities,
                )
                await client.initialize()
                setattr(client, "_telegram_ws_session", ws_session)
                return client
            raise ValueError(
                f"unsupported acp_url scheme {scheme!r} — expected "
                "http/https (gateway) or ws/wss"
            )

        # Test-only fallback: spawn a stdio child of the bot. Production
        # always sets ``acp_url`` so the gateway owns the agent process.
        from rtxclaw_acp.client.spawn import spawn_stdio_agent

        cmd = [
            sys.executable, "-m", "rtxclaw_agent", "acp-stdio", agent_cfg.name,
        ]
        client, proc = await spawn_stdio_agent(
            cmd,
            cwd=str(agent_cfg.home),
            client_capabilities=capabilities,
        )
        await client.initialize()
        self._child_procs[
            TelegramConfig.chat_key(chat_id, thread_id)
        ] = proc
        return client

    async def _get_or_open_client(
        self, chat_id: int, thread_id: Optional[int] = None,
    ):
        key = TelegramConfig.chat_key(chat_id, thread_id)
        client = self._clients.get(key)
        if client is not None:
            # ``AcpClient._closed`` flips True in two cases:
            #   * explicit ``close()`` (we did it) — caller is reopening,
            #   * read-loop exited on transport error (gateway crashed,
            #     SSE stream torn down, OOM-kill etc.) — the cached
            #     instance can't service requests anymore.
            # Either way, evict + recreate. Without this the next
            # ``session_prompt`` would either hang on a future the
            # dead read loop will never resolve, or fail with
            # ``AcpTransportClosed`` on every retry.
            if not getattr(client, "_closed", False):
                return client
            self._log.warning(
                "evicting closed ACP client for chat_key=%s; reopening",
                key,
            )
            self._clients.pop(key, None)
            try:
                await client.close()
            except Exception:  # noqa: BLE001
                pass
        capabilities = _capabilities_for_chat(
            chat_id, trusted_chats=self.trusted_chats,
        )
        # Default factory accepts ``thread_id`` so per-thread agent
        # routing can resolve the right stdio target. Test stubs that
        # override ``client_factory`` without the kwarg keep working
        # because we pass it positionally only when supported.
        try:
            client = await self._client_factory(
                chat_id, capabilities, thread_id=thread_id,
            )
        except TypeError:
            # Legacy two-arg stub — drop thread_id so test fixtures
            # don't have to be updated in lockstep.
            client = await self._client_factory(chat_id, capabilities)
        # Wire the permission-prompt UI on every freshly built client,
        # regardless of which factory produced it. Destructive tool
        # calls round-trip ``session/request_permission`` through an
        # inline-keyboard message in THIS chat (the handler closes over
        # chat_id / thread_id). Best-effort — a client stub without the
        # method just doesn't get the hook, and the agent's no-channel
        # path then safely defaults to deny.
        register = getattr(client, "register_request_permission", None)
        if callable(register):
            try:
                register(self._make_permission_handler(chat_id, thread_id))
            except Exception:  # noqa: BLE001
                self._log.debug(
                    "register_request_permission failed for chat_key=%s",
                    key, exc_info=True,
                )
        self._clients[key] = client
        return client

    # ---- permission prompt (session/request_permission) ----------------

    def _make_permission_handler(self, chat_id: int, thread_id: Optional[int]):
        """Build the per-client ``session/request_permission`` handler.

        The returned async callable is registered on the chat's
        :class:`AcpClient`; it closes over ``(chat_id, thread_id)`` so
        the prompt always lands in the chat that owns the session — no
        sid→chat reverse map needed.
        """
        async def _handler(params: dict) -> dict:
            return await self._prompt_permission(chat_id, thread_id, params)
        return _handler

    async def _prompt_permission(
        self, chat_id: int, thread_id: Optional[int], params: dict,
    ) -> dict:
        """Surface an ACP permission request as an inline-keyboard prompt.

        Sends a 3-button message (Allow once / Allow always / Reject),
        parks a future keyed by an opaque token, and awaits the user's
        tap. On a 30s timeout — or any send / await failure — defaults
        to ``reject_once``: the agent only asks because the op is
        destructive, so "no answer" means "no". Returns the ACP
        ``RequestPermissionResponse`` mapping verbatim.

        Runs inline in the chat's AcpClient read loop (same as
        ``_inbound_ask_user``); that's fine — the agent's turn is
        parked on this very decision, so nothing else is inbound on
        that client until we answer.
        """
        def _outcome(option_id: str) -> dict:
            return {"outcome": {"outcome": "selected", "optionId": option_id}}

        tool_call = params.get("toolCall") if isinstance(params, dict) else {}
        if not isinstance(tool_call, dict):
            tool_call = {}
        title = str(tool_call.get("title") or "tool")
        raw_input = tool_call.get("rawInput")
        args_preview = ""
        if isinstance(raw_input, dict) and raw_input:
            try:
                args_preview = json.dumps(raw_input, ensure_ascii=False)
            except (TypeError, ValueError):
                args_preview = str(raw_input)
            if len(args_preview) > 600:
                args_preview = args_preview[:600] + " …"

        if self._api is None:
            # No transport (shouldn't happen once run() has started) —
            # default to deny rather than hang the agent's turn.
            return _outcome("reject_once")

        # Plain text deliberately — no parse_mode. Tool args routinely
        # contain ``_`` / ``*`` / backticks that would break Telegram's
        # fragile legacy Markdown and could fail the send outright.
        text = f"⛔ Destructive tool call needs approval\n\ntool: {title}"
        if args_preview:
            text += f"\nargs: {args_preview}"
        text += (
            f"\n\nAuto-deny in {int(_PERMISSION_PROMPT_TIMEOUT_S)}s "
            "if unanswered."
        )
        token = secrets.token_urlsafe(8)
        keyboard = {
            "inline_keyboard": [[
                {"text": "✅ Allow once",
                 "callback_data": f"perm:{token}:allow_once"},
                {"text": "🔓 Allow always",
                 "callback_data": f"perm:{token}:allow_always"},
                {"text": "⛔ Reject",
                 "callback_data": f"perm:{token}:reject_once"},
            ]]
        }
        send_params: dict[str, Any] = {
            "chat_id": chat_id,
            "text": _truncate_for_telegram(text),
            "reply_markup": keyboard,
            "disable_web_page_preview": True,
        }
        if thread_id is not None:
            send_params["message_thread_id"] = thread_id

        res = await self._api.call("sendMessage", **send_params)
        if not res.get("ok"):
            self._log.warning(
                "permission prompt sendMessage failed chat=%s err=%s "
                "— defaulting to deny",
                chat_id, res.get("description"),
            )
            return _outcome("reject_once")
        message_id = (res.get("result") or {}).get("message_id")

        loop = asyncio.get_running_loop()
        fut: asyncio.Future = loop.create_future()
        self._pending_permissions[token] = fut
        try:
            option_id = await asyncio.wait_for(
                fut, timeout=_PERMISSION_PROMPT_TIMEOUT_S,
            )
        except asyncio.TimeoutError:
            option_id = "reject_once"
            self._log.info(
                "permission prompt timed out chat=%s tool=%s — denying",
                chat_id, title,
            )
        except Exception:  # noqa: BLE001
            option_id = "reject_once"
        finally:
            self._pending_permissions.pop(token, None)

        # Reflect the verdict back into the chat and drop the keyboard
        # so a stale prompt can't be tapped a second time.
        if isinstance(message_id, int):
            verdict = {
                "allow_once": "✅ Allowed once",
                "allow_always": "✅ Allowed (always)",
                "reject_once": "⛔ Rejected",
                "reject_always": "⛔ Rejected (always)",
            }.get(option_id, "⛔ Rejected")
            try:
                await self._api.call(
                    "editMessageText",
                    chat_id=chat_id,
                    message_id=message_id,
                    text=_truncate_for_telegram(f"{verdict} — {title}"),
                    disable_web_page_preview=True,
                )
            except Exception:  # noqa: BLE001
                self._log.debug(
                    "permission prompt edit failed", exc_info=True,
                )

        return _outcome(option_id)

    async def _handle_callback_query(self, update: dict) -> None:
        """Resolve an inline-keyboard tap on a permission prompt.

        Parses ``perm:<token>:<optionId>`` callback data, acks the
        callback query (so Telegram clears the button spinner), and
        completes the parked future so ``_prompt_permission`` returns
        the user's choice. Unknown / stale tokens are acked and dropped.
        """
        cq = update.get("callback_query") or {}
        cq_id = cq.get("id")
        data = cq.get("data") or ""
        msg = cq.get("message") or {}
        chat = msg.get("chat") or {}
        chat_id = chat.get("id")

        async def _ack(note: str = "") -> None:
            if not cq_id or self._api is None:
                return
            try:
                ack_params: dict[str, Any] = {"callback_query_id": cq_id}
                if note:
                    ack_params["text"] = note
                await self._api.call("answerCallbackQuery", **ack_params)
            except Exception:  # noqa: BLE001
                self._log.debug("answerCallbackQuery failed", exc_info=True)

        # Authorize — only allowed chats can answer prompts.
        if not isinstance(chat_id, int) or not self._is_authorized(chat_id):
            await _ack()
            return
        if not data.startswith("perm:"):
            # Not one of ours — ack so the client stops spinning, ignore.
            await _ack()
            return
        parts = data.split(":", 2)
        if len(parts) != 3:
            await _ack()
            return
        _, token, option_id = parts
        if option_id not in (
            "allow_once", "allow_always", "reject_once", "reject_always"
        ):
            option_id = "reject_once"
        fut = self._pending_permissions.get(token)
        if fut is None or fut.done():
            # Stale prompt — bot restarted, or already resolved / timed out.
            await _ack("This prompt has expired.")
            return
        fut.set_result(option_id)
        await _ack()

    def chat_lock(
        self, chat_id: int, thread_id: Optional[int] = None,
    ) -> asyncio.Lock:
        # Per-(chat,topic) lock so two topics in the same forum can run
        # turns concurrently without serializing on each other.
        key = self._session_key(chat_id, thread_id)
        lock = self._chat_locks.get(key)
        if lock is None:
            lock = asyncio.Lock()
            self._chat_locks[key] = lock
        return lock

    # ---- inbound dispatch (testable seams) -----------------------------

    async def handle_text_message(
        self, chat_id: int, text: str,
        *, thread_id: Optional[int] = None,
    ) -> str:
        """Process an inbound text message; return the assembled reply.

        Returning the reply (rather than calling ``send_text`` directly)
        keeps this method trivially testable: the test asserts on the
        return value plus the recorded calls on the stub
        :class:`AcpClient`. The long-poll loop in :meth:`run` is what
        wires the real Telegram POST.
        """
        text = (text or "").strip()
        if not text:
            return ""
        import acp.schema as _acp

        return await self._dispatch_blocks(
            chat_id, [_acp.TextContentBlock(type="text", text=text)],
            thread_id=thread_id,
        )

    async def handle_voice_message(
        self,
        chat_id: int,
        file_id: str,
        *,
        mime: str = "",
        filename: str = "",
    ) -> str:
        """Resolve the voice file → STT → forward as text."""
        if self._stt is None or self._download_audio is None:
            self._log.warning(
                "voice received chat=%s but STT not configured", chat_id,
            )
            return ""
        result = await self._download_audio(file_id)
        if not result:
            return ""
        audio_bytes, fname = result
        if not filename:
            filename = fname
        transcript = await self._stt(
            audio_bytes, mime=mime, filename=filename,
        )
        if not transcript:
            return ""
        return await self.handle_text_message(chat_id, transcript)

    async def handle_image_message(
        self,
        chat_id: int,
        msg: Optional[Mapping[str, Any]] = None,
        *,
        thread_id: Optional[int] = None,
    ) -> str:
        """Forward a Telegram photo to the agent as an ACP ImageContent block.

        Picks the largest photo size (Telegram delivers an array sorted
        ascending), downloads it via the bot-file CDN, and emits a
        ContentBlock list ``[TextContentBlock(caption), ImageContent(data,
        mimeType)]`` to the agent through ``_dispatch_blocks``. The
        agent's bridge translates that into the OpenAI multipart
        ``image_url`` format upstreams (vLLM / openrouter) accept
        natively, so vision-capable models like ``kimi`` can read the
        image without any additional plumbing.

        ``msg`` is the raw Telegram message dict; required to pull the
        ``photo[]`` array + optional ``caption``. Falls back to the old
        not-supported reply if anything fails (download error, unauth,
        etc.) so a single broken upload doesn't kill the chat.
        """
        if msg is None or not isinstance(msg.get("photo"), list) or not msg["photo"]:
            return ACP_IMAGE_UNSUPPORTED_REPLY
        # Telegram's `photo[]` is sorted ascending by size; pick the
        # largest so the model sees the highest-quality version it has.
        largest = msg["photo"][-1]
        file_id = largest.get("file_id") if isinstance(largest, dict) else None
        if not isinstance(file_id, str) or not file_id:
            return ACP_IMAGE_UNSUPPORTED_REPLY
        if self._download_image is None:
            return ACP_IMAGE_UNSUPPORTED_REPLY
        downloaded = await self._download_image(file_id)
        if downloaded is None:
            return "❌ couldn't download the photo from Telegram"
        img_bytes, _file_path = downloaded
        if len(img_bytes) > _MAX_IMAGE_BYTES:
            mb = len(img_bytes) / (1024 * 1024)
            cap_mb = _MAX_IMAGE_BYTES // (1024 * 1024)
            return (
                f"❌ image too large ({mb:.1f} MB > {cap_mb} MB cap). "
                "Send a smaller image or compress it before forwarding."
            )
        import base64 as _b64
        import acp.schema as _acp
        mime = "image/jpeg"  # Telegram always sends JPEG
        b64 = _b64.b64encode(img_bytes).decode("ascii")
        caption = str((msg.get("caption") or "")).strip()
        blocks: list = []
        if caption:
            blocks.append(_acp.TextContentBlock(type="text", text=caption))
        # Must be `ImageContentBlock` (the discriminated-union member
        # accepted by `PromptRequest.prompt`), not the bare
        # `ImageContent` schema model — the latter looks identical at
        # the field level but pydantic rejects it as the wrong type
        # ("Input should be a valid dictionary or instance of
        # ImageContentBlock") and the prompt never lands.
        blocks.append(_acp.ImageContentBlock(
            type="image",
            data=b64,
            mime_type=mime,
        ))
        return await self._dispatch_blocks(
            chat_id, blocks, thread_id=thread_id,
        )

    async def handle_document_message(self, chat_id: int) -> str:
        return ACP_DOCUMENT_UNSUPPORTED_REPLY

    async def handle_sticker_message(self, chat_id: int) -> str:
        return ACP_STICKER_UNSUPPORTED_REPLY

    async def cancel_chat(
        self, chat_id: int, thread_id: Optional[int] = None,
        *, via: str = "stop",
    ) -> tuple[bool, bool]:
        """Imperative cancel — backs ``/stop``, ``/cancel``, ``/abort``.

        Looks up the (chat, topic)'s session id, fires
        ``session/cancel`` on the cached client (a fire-and-forget
        JSON-RPC notification, so the wire write returns the moment
        bytes are flushed — no waiting for the agent to do anything).

        Returns ``(stopped, force_escalated)``:

        * ``stopped`` — ``True`` when a cancel was dispatched; ``False``
          when there is no session or no client to dispatch through.
        * ``force_escalated`` — ``True`` when this call landed within
          ``_ABORT_DOUBLE_PRESS_S`` of the previous abort on the same
          (chat, thread). The bridge's own double-press window
          (acp_bridge.py ``_HARD_KILL_WINDOW_S``) is what *actually*
          escalates SIGTERM→SIGKILL on the runner subprocesses; this
          flag is purely so the Telegram ack reply can surface that
          the server-side escalation has fired. We always send the
          ``session/cancel`` regardless — even on the first press —
          so a single ``/abort`` still gets the same imperative
          behaviour it had before.
        """
        sid = self.get_session_id(chat_id, thread_id)
        if sid is None:
            return False, False
        # Clients are cached per (chat, topic) — ``_get_or_open_client``
        # keys them on ``chat_key(chat_id, thread_id)`` ("<chat>:<thread>"
        # for forum topics). Look up with the SAME key: a bare
        # ``str(chat_id)`` misses the topic-keyed client, so a turn
        # running in a topic would get the bogus "no in-flight prompt to
        # cancel" while it kept running (2026-05-22 incident).
        client_key = TelegramConfig.chat_key(chat_id, thread_id)
        client = self._clients.get(client_key)
        # A cached client whose read-loop died (gateway crash / SSE
        # teardown flips ``_closed``) can't deliver the cancel — drop it
        # so the reopen path below replaces it.
        if client is not None and getattr(client, "_closed", False):
            self._clients.pop(client_key, None)
            client = None
        # When a turn is actually in flight (the per-(chat,topic) lock is
        # held) but we have no usable cached client, reopen one so
        # ``/abort`` ALWAYS reaches the gateway. The gateway routes
        # ``session/cancel`` by sid regardless of which connection
        # carries it, so a fresh connection still kills the running turn.
        # We only reopen when a turn is live — otherwise a stray
        # ``/abort`` with nothing running would needlessly spin up a
        # connection instead of replying "no in-flight prompt to cancel".
        if client is None and self.chat_lock(chat_id, thread_id).locked():
            try:
                client = await self._get_or_open_client(chat_id, thread_id)
            except Exception:  # noqa: BLE001
                self._log.exception(
                    "cancel_chat reopen failed chat=%s thread=%s",
                    chat_id, thread_id,
                )
                client = None
        if client is None:
            return False, False
        now_mono = time.monotonic()
        key = (chat_id, thread_id)
        is_abort = via == "abort"
        # ``/abort`` is the imperative HARD kill — SIGKILL + killpg the
        # worker and every runner / subagent. ``/stop`` / ``/cancel`` are
        # graceful by contract (let the in-flight op finish, then end the
        # turn), so mashing them must NOT silently upgrade to a kill. The
        # double-press escalation is therefore tracked for ``/abort`` only;
        # ``force_escalated`` is purely the flag the ack reply uses to
        # surface that a second abort landed inside the window.
        if is_abort:
            last_mono = self._last_abort_at.get(key)
            force_escalated = bool(
                last_mono is not None
                and (now_mono - last_mono) <= _ABORT_DOUBLE_PRESS_S
            )
            self._last_abort_at[key] = now_mono
        else:
            force_escalated = False
        force = is_abort
        try:
            await client.session_cancel(sid, force=force)
        except Exception:  # noqa: BLE001
            self._log.exception(
                "session_cancel failed chat=%s thread=%s via=%s",
                chat_id, thread_id, via,
            )
            return False, force_escalated
        # Log the ACTUAL force flag sent (a first ``/abort`` is forceful);
        # ``escalated`` separately records the double-press window hit.
        self._log.info(
            "abort_dispatched chat=%s thread=%s via=%s force=%s "
            "escalated=%s sid=%s",
            chat_id, thread_id, via, force, force_escalated, sid[:12],
        )
        return True, force_escalated

    async def _dispatch_abort(
        self,
        chat_id: int,
        thread_id: Optional[int],
        *,
        via: str,
        reply: Any,
    ) -> None:
        """Shared imperative cancel path for ``/stop``, ``/cancel``,
        ``/abort``.

        Fires ``session/cancel`` immediately (no chat-lock wait — the
        caller has already routed slash commands outside the lock so
        the cancel is dispatched even while a turn is mid-stream),
        then echoes a wall-clock-stamped ack. A second press within
        ``_ABORT_DOUBLE_PRESS_S`` flags the bridge-side force-kill
        escalation in the reply so the operator can tell which press
        upgraded SIGTERM→SIGKILL.

        ``reply`` is the per-command reply closure built by the
        outer handler (it carries the thread routing for forum
        topics so we don't have to re-derive it).
        """
        sent_at = time.strftime("%H:%M:%S")
        stopped, escalated = await self.cancel_chat(
            chat_id, thread_id, via=via,
        )
        if not stopped:
            await reply("no in-flight prompt to cancel")
            return
        suffix = " · force-kill escalation" if escalated else ""
        await reply(f"⏹ session/cancel sent at {sent_at} (/{via}){suffix}")

    async def _dispatch_steer(
        self,
        chat_id: int,
        thread_id: Optional[int],
        text: str,
        reply: Any,
    ) -> None:
        """Redirect the running turn with a steering message (``/steer``).

        Routed OUTSIDE the per-chat lock (like ``/stop``) so it lands
        even while a turn is mid-stream. Two backends, chosen by the
        chat's engine kind:

        * **local-LLM turn in flight** → push the text into the engine's
          mid-turn inject buffer via ``session/inject_user_message``; it
          drains at the next round boundary so the model pivots without
          aborting.
        * **CLI-bridge turn in flight** (claude/codex/antigravity) → the
          CLI can't accept a live inject, so gracefully abort the
          current turn (SIGINT → 15s → kill, preserving its ``--resume``
          state) and re-dispatch the text as the next turn, which the
          per-chat lock naturally sequences after the wind-down.

        With **no turn in flight** (either engine) ``/steer <text>`` is
        just a normal prompt. Empty ``/steer`` prints usage.
        """
        text = (text or "").strip()
        if not text:
            await reply("usage: /steer <text> — redirect the running turn")
            return

        sid = self.get_session_id(chat_id, thread_id)
        agent_cfg = self._agent_cfg(chat_id, thread_id)
        engine = (getattr(agent_cfg, "engine", "") or "").strip().lower()
        is_cli = engine in ("claude_cli", "codex_cli", "antigravity_cli")
        live = self.chat_lock(chat_id, thread_id).locked()

        if live and not is_cli and sid:
            # Local-LLM turn → true mid-turn inject. Same per-topic
            # client keying as cancel_chat — bare str(chat_id) would
            # miss a forum-topic client.
            client = self._clients.get(
                TelegramConfig.chat_key(chat_id, thread_id)
            )
            if client is not None:
                inject = getattr(client, "session_inject_user_message", None)
                if callable(inject):
                    try:
                        ack = await inject(sid, text)
                    except Exception as exc:  # noqa: BLE001
                        ack = {"ok": False, "reason": str(exc)}
                    if hasattr(ack, "get") and ack.get("ok"):
                        await reply(
                            "↳ steering current turn — lands at the next "
                            "round boundary"
                        )
                        return
                    # inject unavailable/failed → fall through to a normal
                    # dispatch so the message is never lost.
        elif live and is_cli:
            # CLI bridge → graceful abort, then pivot to the new prompt.
            stopped, _ = await self.cancel_chat(
                chat_id, thread_id, via="steer",
            )
            if stopped:
                await reply(
                    "↳ steering — winding down the current turn, then "
                    "pivoting to your message"
                )

        # No live turn, CLI pivot, or a failed inject: run the steer text
        # as a normal turn. When a CLI turn is still winding down this
        # blocks on the per-chat lock until it releases — i.e. the new
        # turn lands right after, with full --resume context.
        reply_text = await self.handle_text_message(
            chat_id, text, thread_id=thread_id,
        )
        if reply_text:
            await self._reply(chat_id, reply_text, thread_id)

    async def _dispatch_blocks(
        self, chat_id: int, blocks: list,
        *, on_chunk: Optional[Any] = None,
        on_tool_status: Optional[Any] = None,
        thread_id: Optional[int] = None,
    ) -> str:
        """Send ``blocks`` to the agent on the chat's session, render reply.

        ``on_chunk`` is an optional async callable invoked with the
        running visible-text buffer (cumulative ``str``) every time an
        ``AgentMessageChunk`` arrives. The long-poll loop wires it to
        :class:`_RollingMessage` so streaming edits land on Telegram in
        real time. Tests typically leave it ``None`` and assert on the
        final return value.

        Returns the assembled visible reply (concatenated
        ``agent_message_chunk`` content + any thoughts / tool headers
        the user has opted into). Rendering is gated by the per-
        (chat,thread) visibility map:

        * ``reasoning_visibility`` ∈ ``{"off", "on", "stream"}`` — when
          not ``"off"``, ``agent_thought_chunk`` content is rendered
          inline with a ``💭`` prefix. ``"stream"`` lets thoughts paint
          live; ``"on"`` buffers them until the first message chunk so
          the user sees the answer prefixed by the thinking that led
          to it. Toggle via ``/reasoning``.
        * ``tool_output_visible`` (bool) — when ``True``, every
          ``tool_call``/``tool_call_update`` plants a ``🔧 title…``
          header inline so tool runs are visible in scrollback even
          after they fall off the placeholder. Toggle via ``/tools``.

        Tool-call body deltas (the ``content`` array on
        ``tool_call_update``) always stream into the visible reply
        regardless of ``/tools`` — they ARE the answer for
        direct-dispatch turns like ``/claude`` and ``/codex``. The
        ``/tools`` toggle only governs the inline-header noise.

        The final ``PromptResponse`` adds a ``_(stopped: <reason>)_``
        marker when the stop reason is not ``end_turn`` so the user
        can see what happened.
        """
        import acp.schema as _acp

        async with self.chat_lock(chat_id, thread_id):
            client = await self._get_or_open_client(chat_id, thread_id)
            sid = self.get_session_id(chat_id, thread_id)
            visibility = self._get_visibility(chat_id, thread_id)
            reasoning_level = str(
                visibility.get("reasoning_visibility") or "off"
            )
            if sid is None:
                agent_cfg = self._agent_cfg(chat_id, thread_id)
                sid = await client.session_new(cwd=str(agent_cfg.home))
                self._set_session_id(chat_id, sid, thread_id)
                # Seed the engine's per-session gate from this chat's
                # remembered preference (defaults to "off" — Telegram's
                # per-frontend default). Without this seed the engine
                # would swallow ``thinking`` deltas even when the chat
                # had previously set ``/reasoning on`` — the per-chat
                # visibility map is per-frontend, the engine's gate is
                # per-session.
                if reasoning_level != "off":
                    try:
                        await client.session_set_config_option(
                            sid, "reasoning", reasoning_level,
                        )
                    except Exception:  # noqa: BLE001
                        pass
            # 3-state tool-output level: "off" / "on" / "stream".
            #   off    → no header, no body
            #   on     → header only (body suppressed)
            #   stream → header + raw body streamed inline
            # Direct-dispatch tools (delegate_*, compact_context)
            # ignore this gate — see the body-push site below.
            tool_output_level = str(
                visibility.get("tool_output") or "off"
            ).lower()
            tool_show_header = tool_output_level in ("on", "stream")
            tool_show_body = tool_output_level == "stream"
            # Legacy bool kept for backwards-compat with any caller
            # outside this method that still reads the old name.
            tool_output_visible = tool_show_header

            visible_parts: list[str] = []
            # Tracks the most recent rendered "kind" so transitions
            # between thinking / content / tool plant a section
            # separator (``\n\n💭`` / ``\n\n💬`` / ``\n\n🔧``) without
            # restacking duplicate prefixes when many small chunks
            # arrive in a row.
            last_kind: Optional[str] = None
            # ``"on"``-mode buffer: thoughts collected while no
            # content has streamed yet. Flushed (with a ``💭`` prefix)
            # the moment the first ``AgentMessageChunk`` lands, so
            # the user sees both the reasoning and the answer in one
            # rolling message.
            pending_thoughts: list[str] = []
            content_seen = False
            # Per-tool-call ids that already had their header planted
            # — keyed so repeated ``tool_call_update`` events for the
            # same call don't restamp ``🔧 title…``.
            headers_emitted: set[str] = set()
            # Per-tool-call titles seen on the initial ``tool_call`` /
            # ``ToolCallStart`` event. ``ToolCallProgress`` updates omit
            # ``title``, so without this map a delegate_claude/codex
            # update would fall back to the generic ``"tool"`` and
            # miss the ``_DIRECT_DISPATCH_TITLES`` gate — the body
            # would be dropped and the chat would render
            # ``⚠️ empty reply``.
            tool_titles: dict[str, str] = {}
            # Per-tool-call ids that already streamed in_progress
            # body deltas; the matching ``completed`` event then skips
            # its final body so we don't double-append.
            streamed_tools: set[str] = set()

            def _flush_pending_thoughts() -> None:
                nonlocal last_kind
                if not pending_thoughts:
                    return
                if visible_parts:
                    visible_parts.append("\n\n")
                visible_parts.append("💭 ")
                visible_parts.append("".join(pending_thoughts))
                pending_thoughts.clear()
                last_kind = "thinking"

            def _push_thought(text: str) -> None:
                nonlocal last_kind
                if not text or reasoning_level == "off":
                    return
                if reasoning_level == "on" and not content_seen:
                    # Buffer until first content chunk; mirrors the
                    # legacy bot's `buffering` flag for level "on".
                    pending_thoughts.append(text)
                    return
                # ``"stream"``, OR ``"on"`` after content already
                # appeared — render live with a section header.
                if last_kind != "thinking":
                    if visible_parts:
                        visible_parts.append("\n\n")
                    visible_parts.append("💭 ")
                    last_kind = "thinking"
                visible_parts.append(text)

            def _push_content(text: str) -> None:
                nonlocal last_kind, content_seen
                if not text:
                    return
                if pending_thoughts:
                    _flush_pending_thoughts()
                if last_kind == "thinking":
                    visible_parts.append("\n\n💬 ")
                    last_kind = "content"
                elif last_kind in (None, "tool", "tool_body"):
                    if visible_parts:
                        visible_parts.append("\n\n")
                    last_kind = "content"
                content_seen = True
                visible_parts.append(text)

            # Tools whose body IS the user-visible answer (the model
            # delegated and we stream the delegate's reply directly).
            # These get a subtle ``↳ via <delegate>`` badge instead of
            # the regular ``🔧 <title>…`` header so the chat reads as a
            # normal rtxclaw turn with one extra italic line marking
            # the delegation.
            _DELEGATE_BADGES = {
                "delegate_claude": "↳ via claude",
                "delegate_codex": "↳ via codex",
                "delegate_antigravity": "↳ via antigravity",
            }

            def _push_tool_header(title: str) -> None:
                nonlocal last_kind
                badge = _DELEGATE_BADGES.get(title)
                if badge is not None:
                    # Always show the badge for delegate tools — it's
                    # a one-line attribution, not raw tool output, so
                    # the /tools gate doesn't apply. Render as
                    # markdown italic so it reads as a quiet footnote.
                    if visible_parts:
                        visible_parts.append("\n\n")
                    visible_parts.append(f"_{badge}_")
                    last_kind = "tool"
                    return
                if not tool_output_visible:
                    return
                if visible_parts:
                    visible_parts.append("\n\n")
                visible_parts.append(f"🔧 {title}…")
                last_kind = "tool"

            def _push_tool_body(text: str) -> None:
                """Append a streaming tool-output chunk.

                The ``🔧 title…`` header (gated by /tools) lands first
                via ``_push_tool_header``; the body itself lands here
                regardless of /tools — it IS the answer for direct-
                dispatch turns. We only insert a leading newline when
                the previous render kind was a header so the body
                starts on its own line under it.
                """
                nonlocal last_kind
                if not text:
                    return
                if last_kind == "tool":
                    visible_parts.append("\n")
                    last_kind = "tool_body"
                elif last_kind not in ("tool_body", None):
                    pass  # mid-stream within a tool body — no separator
                visible_parts.append(text)

            stop_reason: Optional[str] = None

            async def _run_iter(target_sid: str) -> None:
                """Drive one ``session/prompt`` iteration on ``target_sid``.

                The closure captures every render buffer
                (``visible_parts`` / ``pending_thoughts`` /
                ``headers_emitted`` / ``tool_titles`` /
                ``streamed_tools``) so the retry path doesn't have to
                replumb them. ``stop_reason`` is the only value
                assigned directly in here, hence the lone ``nonlocal``.
                Recoverable errors propagate to the caller — the
                outer loop classifies them and decides whether to
                re-issue the prompt against a freshly opened
                session id.
                """
                nonlocal stop_reason
                async for item in client.session_prompt(target_sid, blocks):
                    if isinstance(item, _acp.SessionNotification):
                        upd = item.update
                        if isinstance(upd, _acp.AgentMessageChunk):
                            content = upd.content
                            piece = (
                                content.text
                                if isinstance(content, _acp.TextContentBlock)
                                else ""
                            )
                            if piece:
                                _push_content(piece)
                                if on_chunk is not None:
                                    await on_chunk("".join(visible_parts))
                        elif isinstance(upd, _acp.AgentThoughtChunk):
                            content = upd.content
                            piece = (
                                content.text
                                if isinstance(content, _acp.TextContentBlock)
                                else ""
                            )
                            if piece:
                                _push_thought(piece)
                                # Only paint when we actually rendered
                                # — "on"-mode buffering returns early
                                # so the placeholder stays as-is until
                                # content lands.
                                if (
                                    on_chunk is not None
                                    and reasoning_level != "off"
                                    and not (
                                        reasoning_level == "on"
                                        and not content_seen
                                    )
                                ):
                                    await on_chunk("".join(visible_parts))
                        elif isinstance(upd, _acp.ToolCallStart):
                            title = getattr(upd, "title", None) or "tool"
                            tool_id = getattr(upd, "tool_call_id", "") or ""
                            if tool_id:
                                tool_titles[tool_id] = title
                            if tool_id and tool_id not in headers_emitted:
                                headers_emitted.add(tool_id)
                                if tool_output_visible:
                                    _push_tool_header(title)
                                if on_chunk is not None:
                                    # FORCE the flush regardless of
                                    # header visibility: the agent is
                                    # about to enter the tool which may
                                    # block for seconds-to-minutes with
                                    # no further chunks. A throttled
                                    # drop here would strand the
                                    # assistant's prose tail (and the
                                    # tool header when visible) until
                                    # tool completion. With ``/tools
                                    # off`` (the default) there is no
                                    # header to flush, but the prose
                                    # tail still needs to land NOW.
                                    await on_chunk(
                                        "".join(visible_parts),
                                        force=True,
                                    )
                            if on_tool_status is not None:
                                await on_tool_status(title, "in_progress")
                        elif isinstance(upd, _acp.ToolCallProgress):
                            status_val = getattr(upd, "status", "") or ""
                            tool_id = getattr(upd, "tool_call_id", "") or ""
                            # ``tool_call_update`` events omit ``title``;
                            # remember it from the original ``tool_call``
                            # so the direct-dispatch gate below works.
                            update_title = getattr(upd, "title", None) or ""
                            title = (
                                update_title
                                or tool_titles.get(tool_id)
                                or "tool"
                            )
                            if tool_id and update_title:
                                tool_titles[tool_id] = update_title
                            # First sighting of this call id (short-
                            # running tool that skipped ``ToolCallStart``)
                            # — plant the header if /tools is visible,
                            # and force-flush the assistant prose tail
                            # regardless. Same boundary semantics as
                            # ToolCallStart above: the tool may block
                            # the agent for seconds-to-minutes with no
                            # further chunks, so the throttled drop
                            # would otherwise strand the prose tail.
                            if tool_id and tool_id not in headers_emitted:
                                headers_emitted.add(tool_id)
                                if tool_output_visible:
                                    _push_tool_header(title)
                                if on_chunk is not None:
                                    await on_chunk(
                                        "".join(visible_parts),
                                        force=True,
                                    )
                            # Internal classifier/scaffold tools shouldn't
                            # leak their body into the user-visible reply
                            # — those bodies are diagnostic strings like
                            # "plan_pass=False reason=Simple greeting…",
                            # not user-facing content. Header (🔧 …) still
                            # honors the /tools toggle separately.
                            _INTERNAL_TOOL_TITLES = {
                                "plan_classify", "plan_pass",
                            }
                            # Direct-dispatch tools where the body IS the
                            # answer — /claude, /codex, /compact stream
                            # the subprocess output directly into the
                            # chat reply. For these, the body must
                            # ALWAYS land regardless of /tools (the user
                            # would see no reply otherwise). Every
                            # other tool (web_search, exec, read_file,
                            # …) emits raw tool output that the model
                            # then summarizes; with /tools off, the raw
                            # body is noise — only render it when the
                            # operator opted in.
                            _DIRECT_DISPATCH_TITLES = {
                                "delegate_claude", "delegate_codex",
                                "delegate_antigravity", "compact_context",
                            }
                            content_list = list(
                                getattr(upd, "content", None) or [],
                            )
                            for entry in content_list:
                                inner = getattr(entry, "content", None)
                                if not isinstance(inner, _acp.TextContentBlock):
                                    continue
                                text_piece = inner.text or ""
                                if not text_piece:
                                    continue
                                if title in _INTERNAL_TOOL_TITLES:
                                    # Skip body push; the header — when
                                    # /tools on — already tells the user
                                    # the classifier ran.
                                    continue
                                # Gate non-direct tool bodies on the
                                # 3-state /tools level:
                                #   off / on  → suppress raw body
                                #   stream    → render raw body
                                # Direct-dispatch (delegate_*,
                                # compact_context) always streams —
                                # its body IS the answer.
                                if (
                                    title not in _DIRECT_DISPATCH_TITLES
                                    and not tool_show_body
                                ):
                                    continue
                                if status_val == "in_progress":
                                    streamed_tools.add(tool_id)
                                    _push_tool_body(text_piece)
                                elif status_val in ("completed", "failed"):
                                    if tool_id not in streamed_tools:
                                        _push_tool_body(text_piece)
                                if on_chunk is not None:
                                    # FORCE on terminal status: the
                                    # next event may be another heavy
                                    # tool — a throttled drop here
                                    # would hide the tool's final body
                                    # for the entire next gap. Mid-
                                    # stream ``in_progress`` deltas
                                    # stay throttled to avoid 429s on
                                    # chatty tools.
                                    await on_chunk(
                                        "".join(visible_parts),
                                        force=status_val in (
                                            "completed", "failed",
                                        ),
                                    )
                            if on_tool_status is not None:
                                await on_tool_status(title, status_val)
                    else:
                        stop_reason = item.stop_reason

            # ---- iterate, with one recovery retry for stale sessions ----
            #
            # The gateway raises ``LookupError: no live child owns
            # session …`` when the session id we send was idle-reaped
            # or the gateway parent itself restarted between turns.
            # The bot's stored sid is fine; the gateway just hasn't
            # re-attached it to a child yet. Recover by issuing
            # ``session/load`` (or ``session/new`` as a fallback) and
            # re-running the prompt once. Only safe BEFORE any
            # content / thoughts / tool headers have streamed —
            # otherwise the retry would re-emit the visible buffer
            # the user has already seen.
            recover_attempted = False
            while True:
                try:
                    await _run_iter(sid)
                    break
                except Exception as exc:  # noqa: BLE001
                    can_recover = (
                        not recover_attempted
                        and _is_recoverable_session_error(exc)
                        and not visible_parts
                        and not pending_thoughts
                        and not headers_emitted
                    )
                    if not can_recover:
                        self._log.exception(
                            "session_prompt failed chat=%s sid=%s",
                            chat_id, sid,
                        )
                        return "⚠️ agent error — see telegram.log"
                    recover_attempted = True
                    self._log.warning(
                        "session_prompt: gateway lost session chat=%s "
                        "sid=%s — attempting reopen (%s)",
                        chat_id, sid, exc,
                    )
                    # If the failure came from a dead transport (SSE
                    # stream torn down by an OOM-kill, etc.) the
                    # cached AcpClient is unusable — its read loop
                    # exited, ``_closed`` is True. Drop it so
                    # ``_get_or_open_client`` builds a fresh
                    # connection on the very next call.
                    if getattr(client, "_closed", False):
                        chat_key = TelegramConfig.chat_key(chat_id, thread_id)
                        self._clients.pop(chat_key, None)
                        try:
                            await client.close()
                        except Exception:  # noqa: BLE001
                            pass
                        try:
                            client = await self._get_or_open_client(
                                chat_id, thread_id,
                            )
                        except Exception:  # noqa: BLE001
                            self._log.exception(
                                "client reopen failed chat=%s",
                                chat_id,
                            )
                            return "⚠️ agent error — see telegram.log"
                    try:
                        sid = await self._reopen_session_after_loss(
                            client, chat_id, thread_id, sid,
                        )
                    except Exception:  # noqa: BLE001
                        self._log.exception(
                            "session reopen failed chat=%s",
                            chat_id,
                        )
                        return "⚠️ agent error — see telegram.log"
                    # Loop: re-issue the prompt against the fresh sid.

            # Flush any thoughts that were buffered for ``"on"`` mode
            # but never paired with a content chunk (e.g. the model
            # finished mid-thought, or stopped on max_tokens).
            if pending_thoughts:
                _flush_pending_thoughts()

            assembled = "".join(visible_parts).strip()
            if stop_reason and stop_reason != "end_turn":
                assembled = (
                    (assembled + "\n\n").lstrip("\n")
                    + f"_(stopped: {stop_reason})_"
                )
            if not assembled:
                assembled = "⚠️ empty reply"
            return assembled

    async def close(self) -> None:
        """Tear down every cached client + its child process / WS session."""
        for client in list(self._clients.values()):
            try:
                await client.close()
            except Exception:  # noqa: BLE001
                pass
            ws_session = getattr(client, "_telegram_ws_session", None)
            if ws_session is not None:
                try:
                    await ws_session.close()
                except Exception:  # noqa: BLE001
                    pass
        self._clients.clear()
        # SIGTERM any stdio children that didn't exit on stdin EOF.
        for proc in list(self._child_procs.values()):
            try:
                if proc.returncode is None:
                    proc.terminate()
                    try:
                        await asyncio.wait_for(proc.wait(), timeout=2.0)
                    except asyncio.TimeoutError:
                        proc.kill()
            except Exception:  # noqa: BLE001
                pass
        self._child_procs.clear()
        if self._api is not None:
            try:
                await self._api.close()
            except Exception:  # noqa: BLE001
                pass

    # ---- long-poll loop -----------------------------------------------

    def request_stop(self) -> None:
        """SIGTERM-handler hook. Wakes the long-poll loop."""
        self._stop.set()

    def _is_authorized(self, chat_id: int) -> bool:
        return chat_id in set(self.tg_cfg.allowed_chat_ids or [])

    def _user_allowed(self, user_id: Optional[int]) -> bool:
        """Per-user allowlist gate.

        Empty ``allowed_user_ids`` ⇒ feature disabled, every member of
        an allowed chat may interact (legacy behavior). Non-empty list
        ⇒ strict — only those user ids' messages are processed; every
        other sender is dropped silently (no reply, no log spam) so
        the bot doesn't advertise its presence to non-permitted
        members of a shared group.
        """
        allowed = self.tg_cfg.allowed_user_ids or []
        if not allowed:
            return True
        if user_id is None:
            return False
        return int(user_id) in set(allowed)

    def _addressed_to_bot(self, raw_text: str, msg: dict) -> bool:
        """True when an inbound group message is targeted at this bot.

        Recognises three signals:
          1. ``@<botname>`` anywhere in the raw (un-stripped) text —
             covers both ``/cmd@<botname>`` and conversational
             mentions.
          2. Direct reply (``msg.reply_to_message``) whose author is
             this bot. Telegram's "swipe to reply" UX is the
             standard way to address a user without typing the
             @handle; treat it as an implicit mention.
          3. ``message.entities`` of type ``mention``/``text_mention``
             targeting this bot — covers cases where the client
             splits the @handle across formatting (rare but
             possible) and `text_mention` mentions of the bot's
             user id without an @handle.
        """
        if self._bot_username:
            handle = "@" + self._bot_username
            if handle.lower() in (raw_text or "").lower():
                return True
        reply_to = msg.get("reply_to_message") or {}
        reply_from = (reply_to.get("from") or {}).get("id")
        if (
            self._bot_user_id
            and isinstance(reply_from, int)
            and reply_from == self._bot_user_id
        ):
            return True
        for ent in (msg.get("entities") or []):
            if not isinstance(ent, dict):
                continue
            etype = ent.get("type")
            if etype == "text_mention":
                target = (ent.get("user") or {}).get("id")
                if (
                    self._bot_user_id
                    and isinstance(target, int)
                    and target == self._bot_user_id
                ):
                    return True
        return False

    def _strip_bot_mention(self, text: str) -> str:
        """Strip ``@<botname>`` from inbound message text.

        Telegram delivers two flavors of bot mention that the agent
        should NOT see verbatim:

        * Slash commands in groups arrive as ``/cmd@<botname> [args]``
          (group members must disambiguate which bot the command is
          for). The literal ``cmd == "/new"`` checks in
          ``_handle_command`` would miss ``/new@<botname>`` and fall
          through to "unknown command".
        * Natural-language mentions arrive as ``@<botname> rest of
          message`` — the user is addressing the bot conversationally;
          the model should see only ``rest of message``.

        We strip the @<botname> token wherever it appears (both
        forms), case-insensitive, and collapse the surrounding
        whitespace. No-op until ``getMe`` populates
        ``self._bot_username`` (early-message edge case during a
        cold restart) so we never mangle text by accident.
        """
        if not self._bot_username:
            return text
        token = "@" + self._bot_username
        token_lower = token.lower()
        text_lower = text.lower()
        if token_lower not in text_lower:
            return text
        # Locate every occurrence in the original text by walking
        # the lower-cased copy in lockstep, then splice them out.
        out: list[str] = []
        i = 0
        n = len(text)
        while i < n:
            idx = text_lower.find(token_lower, i)
            if idx == -1:
                out.append(text[i:])
                break
            out.append(text[i:idx])
            i = idx + len(token)
        stripped = "".join(out)
        # Collapse runs of whitespace introduced by the splice (e.g.
        # ``"hi @bot there"`` → ``"hi  there"`` → ``"hi there"``)
        # without touching newlines that may carry meaning.
        import re
        stripped = re.sub(r"[ \t]+", " ", stripped).strip()
        return stripped

    async def _deny(self, chat_id: int, msg: dict) -> None:
        """One-shot deny reply. Logs at WARNING the first time, then
        silently drops further messages from the same chat.
        """
        if chat_id in self._denied_chats:
            return
        self._denied_chats.add(chat_id)
        sender = msg.get("from") or {}
        # The deny template still has an ``{agent}`` slot for legacy
        # log-grep compatibility; with multi-agent routing the deny
        # decision is bot-wide (allowlist applies before agent
        # resolution), so report the route the chat *would* have
        # taken if it had been allowed in.
        would_route_to = self.tg_cfg.agent_for(chat_id)
        self._log.warning(
            DENY_LOG_TEMPLATE.format(
                chat_id=chat_id,
                username=sender.get("username") or "",
                first_name=sender.get("first_name") or "",
                config_path=str(self.tg_cfg.config_path),
                agent=would_route_to,
            ),
        )
        thread_id_raw = (msg or {}).get("message_thread_id")
        deny_thread_id: Optional[int] = (
            int(thread_id_raw)
            if isinstance(thread_id_raw, (int, str))
            and str(thread_id_raw).lstrip("-").isdigit()
            else None
        )
        await self._reply(
            chat_id,
            "⛔ This bot is private. Your chat is not on the allowlist.\n\n"
            f"Your chat_id is `{chat_id}`. The bot operator can add it "
            "to the allowlist to grant access.",
            deny_thread_id,
        )

    async def _handle_command(
        self, chat_id: int, cmd: str,
        thread_id: Optional[int] = None,
    ) -> None:
        """Route a slash command. ``thread_id`` is propagated to every
        reply so messages in a forum topic stay in that topic.
        """
        if self._api is None:
            return  # purely a unit-test path

        async def reply(text: str) -> None:
            await self._api.send_message(
                chat_id, text, message_thread_id=thread_id,
            )
        if cmd in ("/help", "/start"):
            caps_state = (
                "fs.readTextFile=on (trusted)"
                if chat_id in self.trusted_chats
                else "text-only"
            )
            # Live listing of file-based slash commands so bundled
            # ones (e.g. /goal) AND any operator-installed
            # ``commands/*.md`` show up in /help. The total reply has
            # to fit Telegram's 4096-char ceiling though, so cap the
            # inline listing at ``_HELP_FILE_CMDS_SHOW`` and point at
            # /commands for the full list when there's overflow —
            # otherwise a 80-file ``commands/`` dir pushes the rest of
            # the card past the truncation boundary and the user only
            # sees a half-listed file-commands section. Fail-soft: a
            # malformed commands dir falls back to the generic hint.
            _HELP_FILE_CMDS_SHOW = 10
            try:
                from rtxclaw_core.file_commands import discover_commands
                _file_cmds = discover_commands()
            except Exception:  # noqa: BLE001
                _file_cmds = []
            if _file_cmds:
                fc_lines = ["", "File-based commands (commands/*.md):"]
                for c in _file_cmds[:_HELP_FILE_CMDS_SHOW]:
                    hint = f" {c.argument_hint}" if c.argument_hint else ""
                    fc_lines.append(
                        f"  /{c.name}{hint}  — {c.short_description}"
                    )
                extra = len(_file_cmds) - _HELP_FILE_CMDS_SHOW
                if extra > 0:
                    fc_lines.append(
                        f"  … {extra} more — see /commands for the full list"
                    )
                file_commands_block = "\n".join(fc_lines) + "\n"
            else:
                file_commands_block = (
                    "  /<command> [args]      — run a file command "
                    "(commands/*.md)\n"
                )
            body = (
                "rtxclaw — local-LLM agent on Telegram (ACP).\n\n"
                "Slash commands:\n"
                "  /help                  — this card\n"
                "  /new                   — drop session, next msg starts fresh\n"
                "  /status                — agent + bound session id\n"
                "  /stop, /cancel, /abort — abort the in-flight prompt\n"
                "  /steer <text>          — redirect the running turn\n"
                "  /sessions              — list saved sessions\n"
                "  /history [N]           — last N turns (default 5)\n"
                "  /todo, /todos          — todos from the model's todo tool\n"
                "  /compact               — squeeze the running prompt now\n"
                "  /context [list|detail|json] — context tokens & turns report\n"
                "  /skills                — list installed skills\n"
                "  /skill <name>          — show one skill's SKILL.md body\n"
                "  /commands              — list file-based slash commands\n"
                + file_commands_block
                + "  /refresh               — re-load session state from disk\n"
                + "  /restart               — restart the rtxclaw gateway\n"
                "  /mode [plan|ask|auto]  — permission mode for tool calls\n"
                "  /models                — list configured models\n"
                "  /model <alias|url>     — switch the live session model\n"
                "  /reasoning [on|off|stream] — thinking-token visibility\n"
                "  /on, /off, /stream     — shortcuts for /reasoning <level>\n"
                "  /thinking [on|off]     — enable model thinking\n"
                "  /tools [on|off|stream] — tool visibility (off=none, "
                "on=header only, stream=header+output)\n"
                "  /plugin {list|install|enable|disable|remove} — manage plugin bundles\n"
                "  /mcp [filter]          — list MCP servers\n"
                "  /claude <prompt>       — bridge to Claude Code via delegate_claude\n"
                "  /codex <prompt>        — bridge to Codex CLI via delegate_codex\n"
                "  /antigravity <prompt>       — bridge to Antigravity CLI via delegate_antigravity\n"
                "  /agents                — list configured rtxclaw agents\n"
                "  /agent <name>          — switch this chat to <name> "
                "(new session in target)\n"
                "  /<agent> <task>        — one-shot delegation to <agent> "
                "via delegate_agent\n\n"
                f"Capabilities: {caps_state}\n"
                f"Your chat_id is {chat_id}."
            )
            # Wrap in a MarkdownV2 fenced code block so Telegram
            # renders the body in MONOSPACE — that's the only way the
            # space-padded column alignment (``  /cmd <spaces> —``)
            # looks right; Telegram's default proportional font
            # destroyed the layout under plain text and the user saw a
            # ragged blob. Inside ``` ... ``` only ``\`` and ``` ` ```
            # need escaping per Telegram's MarkdownV2 spec; everything
            # else (—, *, _, |, etc.) is rendered as-is.
            escaped = body.replace("\\", "\\\\").replace("`", "\\`")
            fenced = f"```\n{escaped}\n```"
            await self._api.send_message(
                chat_id, fenced,
                message_thread_id=thread_id,
                parse_mode="MarkdownV2",
            )
            if cmd == "/start":
                # Force-create a fresh session for this (chat,topic).
                self._drop_session_id(chat_id, thread_id)
            return
        if cmd == "/new":
            self._drop_session_id(chat_id, thread_id)
            agent_cfg = self._agent_cfg(chat_id, thread_id)
            # CLI-engine agents (claude/codex/antigravity) don't drive an
            # HTTP upstream — the CLI itself owns the model call, and
            # ``upstream_model`` belongs to a different (local-LLM)
            # deployment. Mirror the TUI status-bar rendering
            # (app.py:5911-5921) so we don't falsely advertise the
            # global config's upstream id.
            engine = (getattr(agent_cfg, "engine", "") or "").strip()
            if engine in ("claude_cli", "codex_cli", "antigravity_cli"):
                model = engine[:-4]  # "claude" / "codex" / "antigravity"
            else:
                model = getattr(agent_cfg, "upstream_model", "") or "(default)"
            await reply(
                f"✨ new session started with agent `{agent_cfg.name}` "
                f"model `{model}`."
            )
            return
        if cmd == "/status":
            sid = self.get_session_id(chat_id, thread_id)
            sid_disp = sid[:12] + "…" if sid else "(none — next message creates one)"
            topic_line = f"\ntopic: {thread_id}" if thread_id is not None else ""
            # Context-length probe: only meaningful when a session is
            # open. Reads the persisted session JSON directly off
            # disk — the SDK's ``LoadSessionResponse`` doesn't carry
            # ``turns`` or ``system_prompt`` (it was returning 0
            # tokens even on a freshly-bootstrapped agent that has
            # SOUL/AGENTS/TOOLS context worth thousands of tokens).
            #
            # Path: ``<agent_home>/sessions/<sid>.json``. The session
            # file is the canonical source of truth — ``Session.save``
            # writes it atomically — so reading it here costs one
            # ``stat`` + ``read`` and stays consistent with what the
            # next prompt round will replay.
            ctx_line = ""
            agent_cfg = self._agent_cfg(chat_id, thread_id)
            if sid is not None:
                try:
                    from rtxclaw_core.session_reader import load_session_dict
                    raw = load_session_dict(agent_cfg.sessions_dir, sid) or {}
                    turns = list(raw.get("turns") or [])
                    system_prompt = str(raw.get("system_prompt") or "")
                    # Count chars across system prompt + every turn's
                    # user/content/thinking text. 4 chars ≈ 1 token,
                    # matches turn_runtime._approx_tokens.
                    char_count = len(system_prompt)
                    for t in turns:
                        if not isinstance(t, dict):
                            continue
                        for key in ("user", "content", "thinking"):
                            v = t.get(key)
                            if isinstance(v, str):
                                char_count += len(v)
                            elif isinstance(v, list):
                                for blk in v:
                                    if isinstance(blk, dict):
                                        char_count += len(
                                            blk.get("text") or ""
                                        )
                    approx_tokens = char_count // 4
                    # Per-session contextWindow takes precedence over
                    # the global default (different models have
                    # different windows).
                    sess_ctx = int(raw.get("context_window") or 0)
                    if not sess_ctx:
                        sess_endpoint = str(raw.get("endpoint") or "")
                        for m in (getattr(agent_cfg, "models", None) or []):
                            if not isinstance(m, dict):
                                m = m.__dict__ if hasattr(m, "__dict__") else {}
                            if (m.get("baseUrl") or "").rstrip("/") == sess_endpoint.rstrip("/"):
                                sess_ctx = int(m.get("contextWindow") or 0)
                                break
                    if not sess_ctx:
                        sess_ctx = int(
                            getattr(agent_cfg, "upstream_max_context", 0) or 0
                        )
                    pct = (approx_tokens * 100 / sess_ctx) if sess_ctx else 0.0
                    if sess_ctx:
                        ctx_line = (
                            f"\ncontext: ~{approx_tokens} / {sess_ctx} tokens "
                            f"({pct:.1f}%, {len(turns)} turns)"
                        )
                    else:
                        ctx_line = (
                            f"\ncontext: ~{approx_tokens} tokens "
                            f"({len(turns)} turns)"
                        )
                except Exception as exc:  # noqa: BLE001
                    ctx_line = f"\ncontext: (probe failed: {type(exc).__name__})"
            await reply(
                f"agent: {agent_cfg.name}\n"
                f"session: {sid_disp}{topic_line}{ctx_line}\n"
                f"capabilities: "
                + (
                    "fs.readTextFile (trusted)"
                    if chat_id in self.trusted_chats
                    else "text-only"
                ),
            )
            return
        if cmd in ("/stop", "/cancel"):
            await self._dispatch_abort(
                chat_id, thread_id, via=cmd.lstrip("/"), reply=reply,
            )
            return

        # /steer <text> — redirect the running turn. Carries its own
        # argument, so split before the generic head/arg handling below.
        _steer_head, _, _steer_arg = cmd.partition(" ")
        if _steer_head.split("@", 1)[0].lower() == "/steer":
            await self._dispatch_steer(chat_id, thread_id, _steer_arg, reply)
            return

        # Skills — list installed skills, or show one skill's SKILL.md.
        # Handled before the generic head/arg split below since
        # ``/skill <name>`` carries its own argument.
        _sk_head, _, _sk_arg = cmd.partition(" ")
        _sk_norm = _sk_head.split("@", 1)[0].lower()
        if _sk_norm in ("/skills", "/skill"):
            await self._handle_skills_command(
                chat_id, _sk_arg.strip(), thread_id,
            )
            return
        if _sk_norm in ("/plugin", "/plugins"):
            await self._handle_plugin_command(
                chat_id, _sk_arg.strip(), thread_id,
            )
            return
        if _sk_norm in ("/mcp", "/mcps"):
            await self._handle_mcp_command(
                chat_id, _sk_arg.strip(), thread_id,
            )
            return

        # Configuration commands — route through ACP. ``cmd`` here is
        # the full text including any argument (e.g. "/model kimi"),
        # not just the verb. parse_command handles the head + arg
        # split and the alias collapse (/on → /reasoning on, etc.).
        head, _, arg = cmd.partition(" ")
        head_lower = head.split("@", 1)[0].lower()
        cfg_cmds = {
            "/mode", "/model", "/models",
            "/reasoning", "/reason", "/on", "/off", "/stream",
            "/thinking", "/tools", "/tool",
        }
        if head_lower in cfg_cmds:
            await self._handle_config_command(chat_id, cmd, thread_id)
            return
        session_cmds = {
            "/sessions", "/history", "/todo", "/todos",
            "/abort", "/refresh", "/restart", "/compact",
            "/context", "/ctx",
        }
        if head_lower in session_cmds:
            await self._handle_session_command(chat_id, cmd, thread_id)
            return
        # Delegate sugars — same shape the TUI uses (synthesize a user
        # message that biases the local model to emit delegate_claude /
        # delegate_codex / delegate_antigravity). Keeps "external bridges
        # are tools, not slash commands" while giving the same UX on
        # every frontend.
        if head_lower in ("/claude", "/codex", "/antigravity"):
            await self._handle_delegate_command(
                chat_id, head_lower, arg, thread_id,
            )
            return

        # Multi-agent routing commands.
        if head_lower in ("/agents",):
            await self._handle_agents_list(chat_id, thread_id)
            return
        if head_lower == "/agent":
            await self._handle_agent_switch(
                chat_id, arg.strip(), thread_id,
            )
            return
        # ``/<agent_name> <task>`` — delegate sugar that targets a
        # rtxclaw agent the way ``/claude`` targets Claude Code.
        # Resolved against the configured agent list so a typo
        # falls through to the "unknown command" reply instead of
        # spawning a phantom child.
        agent_target = head_lower[1:] if head_lower.startswith("/") else ""
        if agent_target and self._is_known_agent(agent_target):
            await self._handle_agent_delegate(
                chat_id, agent_target, arg, thread_id,
            )
            return

        # File-based slash commands (Claude Code ``commands/*.md``,
        # including everything-claude-code). ``/commands`` lists them;
        # ``/<name> [args]`` expands the command's prompt body (with
        # $ARGUMENTS / $1… substitution) and runs it as a normal turn.
        if head_lower == "/commands":
            await self._handle_commands_list(chat_id, thread_id)
            return
        _fc_name = agent_target
        if _fc_name:
            try:
                from rtxclaw_core.file_commands import (
                    expand_command, find_command,
                )
                _fc = find_command(_fc_name)
            except Exception:  # noqa: BLE001
                _fc = None
            if _fc is not None:
                expanded = expand_command(_fc, arg.strip())
                await self._stream_turn_for_chat(
                    chat_id, text=expanded, thread_id=thread_id,
                )
                return

        await reply(f"unknown command: {cmd}\nsend /help to list commands")

    async def _handle_plugin_command(
        self, chat_id: int, arg: str,
        thread_id: Optional[int] = None,
    ) -> None:
        """``/plugin {list|install|enable|disable|remove}`` — manage
        plugin bundles (one dir packaging skills + commands + agents +
        hooks). Same surface as the TUI ``/plugin``.
        """
        if self._api is None:
            return
        from rtxclaw_core import plugins as _plug

        async def reply(text: str) -> None:
            await self._api.send_message(
                chat_id, text, message_thread_id=thread_id,
            )

        parts = (arg or "list").strip().split(None, 1)
        sub = parts[0].lower() if parts else "list"
        rest = parts[1].strip() if len(parts) > 1 else ""

        if sub == "list":
            items = _plug.list_plugins()
            if not items:
                await reply(
                    "no plugins installed — try "
                    "`/plugin search <query>` then "
                    "`/plugin install <name-or-git-url>`",
                )
                return
            lines = [f"{len(items)} plugin(s) at ~/.rtxclaw/plugins/:", ""]
            for p in items:
                mark = "" if p.enabled else "✗ "
                comps = p.components()
                summary = ", ".join(f"{k}={v}" for k, v in comps.items()) or "(empty)"
                lines.append(
                    f"• {mark}{p.name} ({p.version or '-'}) — {summary}"
                )
                if p.description:
                    lines.append(f"     {p.description[:80]}")
                if p.source:
                    lines.append(f"     source: {p.source}")
            await reply("\n".join(lines))
            return

        if sub == "search":
            results = _plug.search(rest or "")
            if not results:
                await reply(
                    f"no marketplace matches for {rest!r}\n"
                    "tip: try a broader keyword like `skill`, `hook`, `mcp`, "
                    "or drop ~/.rtxclaw/plugin-marketplace.json with your "
                    "own entries"
                )
                return
            label = f"matches for {rest!r}" if rest else "marketplace listing"
            lines = [f"{len(results)} {label}:", ""]
            for e in results:
                comps = ",".join(e.components) or "-"
                tags = ",".join(e.tags) or "-"
                lines.append(f"• {e.name} [{comps}]  tags={tags}")
                if e.description:
                    lines.append(f"     {e.description[:90]}")
                lines.append(f"     install: {e.install_hint()}")
            lines.append("")
            lines.append(
                "tip: `/plugin install <name>` installs by marketplace name, "
                "or paste any git URL / local path"
            )
            await reply("\n".join(lines))
            return

        if sub == "install":
            if not rest:
                await reply("usage: /plugin install <git-url|local-path>")
                return
            try:
                p = _plug.install(rest.strip())
            except Exception as exc:  # noqa: BLE001
                await reply(f"install failed: {exc}")
                return
            comps = ", ".join(
                f"{k}={v}" for k, v in p.components().items()
            ) or "(no components detected)"
            await reply(
                f"installed {p.name} → {p.path}\n  components: {comps}"
            )
            return

        if sub in ("enable", "disable"):
            if not rest:
                await reply(f"usage: /plugin {sub} <name>")
                return
            try:
                fn = _plug.enable if sub == "enable" else _plug.disable
                p = fn(rest)
            except Exception as exc:  # noqa: BLE001
                await reply(f"{sub} failed: {exc}")
                return
            await reply(
                f"{p.name}: {'enabled' if p.enabled else 'disabled'}"
            )
            return

        if sub == "remove":
            if not rest:
                await reply("usage: /plugin remove <name> [--purge]")
                return
            purge = " --purge" in rest or rest.endswith(" --purge")
            name = rest.replace(" --purge", "").strip()
            try:
                where = _plug.remove(name, purge=purge)
            except Exception as exc:  # noqa: BLE001
                await reply(f"remove failed: {exc}")
                return
            await reply(
                f"removed {name} → {where}"
                + ("" if purge else " (in .trash/)")
            )
            return

        await reply(
            f"unknown /plugin subcommand: {sub!r}\n"
            "usage: /plugin {list|search|install|enable|disable|remove} [args]"
        )

    async def _handle_mcp_command(
        self, chat_id: int, arg: str, thread_id: Optional[int] = None,
    ) -> None:
        """``/mcp [filter]`` — list MCP servers visible to the agent.

        Mirrors the TUI's ``_cmd_mcp`` so Telegram operators see the
        same Claude-Code-compatible view: name, transport, discovery
        source. A filter argument scopes by substring against name +
        transport + description.
        """
        if self._api is None:
            return

        async def reply(text: str) -> None:
            await self._api.send_message(
                chat_id, text, message_thread_id=thread_id,
            )

        from rtxclaw_mcp.mcp_client import list_mcp_servers_with_source

        servers = list_mcp_servers_with_source()
        flt = (arg or "").strip().lower()
        if flt:
            servers = [
                (s, src) for (s, src) in servers
                if flt in s.name.lower()
                or flt in (s.transport or "").lower()
                or flt in (s.description or "").lower()
            ]
        if not servers:
            if flt:
                await reply(
                    f"no MCP servers match {arg!r}.\n"
                    "configured servers can be listed with `/mcp` "
                    "(no argument)."
                )
            else:
                await reply(
                    "no MCP servers configured.\n"
                    "tip: add one in ~/.rtxclaw/config.json under "
                    "`mcpServers`, drop ~/.claude/.mcp.json, or "
                    "install a plugin bundle that ships an `.mcp.json`."
                )
            return
        lines = [f"{len(servers)} MCP server(s):", ""]
        for server, src in servers:
            head = f"• {server.name} [{server.transport}] [{src}]"
            lines.append(head)
            if server.transport == "stdio":
                cmd_line = server.command
                if server.args:
                    cmd_line += " " + " ".join(server.args)
                if cmd_line:
                    lines.append(f"     exec: {cmd_line}")
            else:
                if server.url:
                    lines.append(f"     url:  {server.url}")
            if server.description:
                lines.append(f"     desc: {server.description[:80]}")
        lines.append("")
        lines.append(
            "sources: [config]=~/.rtxclaw/config.json  "
            "[claude]=~/.claude/.mcp.json  [plugin]=bundle .mcp.json"
        )
        await reply("\n".join(lines))

    async def _handle_commands_list(
        self, chat_id: int, thread_id: Optional[int] = None,
    ) -> None:
        """``/commands`` — list file-based slash commands (Claude Code
        ``commands/*.md``, including everything-claude-code). Each
        ``/<name> [args]`` expands that command's prompt body into a
        normal user turn.
        """
        if self._api is None:
            return
        from rtxclaw_core import file_commands as _fc

        async def reply(text: str) -> None:
            await self._api.send_message(
                chat_id, text, message_thread_id=thread_id,
            )

        cmds = _fc.discover_commands()
        if not cmds:
            await reply(
                "no file commands installed — add a dir to "
                "`commands_dirs` in ~/.rtxclaw/config.json, or drop one "
                "in ~/.rtxclaw/commands/<name>.md",
            )
            return
        lines = [f"{len(cmds)} command(s) — type /<name> [args] to run one:", ""]
        for c in cmds:
            hint = f" {c.argument_hint}" if c.argument_hint else ""
            lines.append(f"• /{c.name}{hint} — {c.short_description}")
        text = "\n".join(lines)
        limit = 3800
        buf = ""
        for line in text.split("\n"):
            if buf and len(buf) + len(line) + 1 > limit:
                await reply(buf)
                buf = ""
            buf = f"{buf}\n{line}" if buf else line
        if buf:
            await reply(buf)

    async def _handle_skills_command(
        self, chat_id: int, arg: str,
        thread_id: Optional[int] = None,
    ) -> None:
        """``/skills`` — list installed skills; ``/skill <name>`` — show
        one skill's SKILL.md body.

        Skills are the agent's on-demand runbooks. This is the
        operator-facing view of the same discovery chain the agent
        sees (per-agent → ``~/.rtxclaw/skills`` → config
        ``skills_dirs`` bundles → builtin), so it doubles as a quick
        check that an everything-claude-code / OpenClaw bundle
        registered. Long output is chunked on line boundaries to fit
        Telegram's ~4 KB message cap.
        """
        if self._api is None:
            return
        from rtxclaw_core import skills as _skills_mod

        async def reply(text: str) -> None:
            await self._api.send_message(
                chat_id, text, message_thread_id=thread_id,
            )

        async def reply_chunked(text: str, limit: int = 3800) -> None:
            # Split on line boundaries so a skill row is never cut mid-word.
            buf = ""
            for line in text.split("\n"):
                if buf and len(buf) + len(line) + 1 > limit:
                    await reply(buf)
                    buf = ""
                buf = f"{buf}\n{line}" if buf else line
            if buf:
                await reply(buf)

        arg = (arg or "").strip()
        if arg:
            skill = _skills_mod.find_skill(arg)
            if skill is None:
                await reply(
                    f"skill not found: {arg!r}\nsend /skills to list "
                    "what's installed",
                )
                return
            head = [f"# {skill.name}", skill.short_description, ""]
            if skill.version:
                head.append(f"version: {skill.version}")
            if skill.requires_env:
                head.append(f"requires env: {', '.join(skill.requires_env)}")
            if skill.requires_bins:
                head.append(f"requires bins: {', '.join(skill.requires_bins)}")
            head.append(f"source: {skill.source}")
            head.append("")
            body = skill.body or "(SKILL.md has frontmatter only — no body)"
            await reply_chunked("\n".join(head) + "\n" + body)
            return
        skills = _skills_mod.discover_skills(include_disabled=True)
        if not skills:
            await reply(
                "no skills installed — add a dir to `skills_dirs` in "
                "~/.rtxclaw/config.json, or drop one in "
                "~/.rtxclaw/skills/<name>/",
            )
            return
        enabled = {s.name for s in _skills_mod.discover_skills()}
        lines = [f"{len(skills)} skill(s) — /skill <name> to read one:", ""]
        for s in skills:
            mark = "" if s.name in enabled else "✗ "
            lines.append(f"• {mark}{s.name} — {s.short_description}")
        if len(enabled) < len(skills):
            lines.append("")
            lines.append(
                "✗ = disabled via the `skills` map in ~/.rtxclaw/config.json"
            )
        await reply_chunked("\n".join(lines))

    async def _handle_session_command(
        self, chat_id: int, text: str,
        thread_id: Optional[int] = None,
    ) -> None:
        """Apply session-management slash commands.

        ``/sessions`` — list saved sessions (most recent first).
        ``/history [N]`` — show last N turns from the cached view.
        ``/todo[s]`` — list session todos written by the ``todo`` tool.
        ``/abort`` — alias for /stop.
        ``/refresh`` — re-bind the chat to the current session id (no-op
        on Telegram since we're always synced via the wire).
        ``/restart`` — TUI-only (daemon respawn); on Telegram, ack with
        a hint.
        """
        from rtxclaw_core.commands import parse_command

        if self._api is None:
            return

        async def reply(t: str) -> None:
            await self._reply(chat_id, t, thread_id)

        parsed = parse_command(text)
        if parsed is None:
            await reply(f"unknown command: {text}")
            return

        if parsed.name == "abort":
            await self._dispatch_abort(
                chat_id, thread_id, via="abort", reply=reply,
            )
            return

        if parsed.name == "restart":
            # /restart bounces the rtxclaw gateway — the single
            # process hosting every agent — and drops this chat's
            # cached client so the next message reconnects against
            # the respawned gateway. Bouncing the gateway cascades
            # to every child (every agent), so all chats see a brief
            # reconnect; per-chat session ids are persisted on disk
            # and re-loaded by the gateway's children on the next
            # ``session/load``. Allowed for any allowlisted chat —
            # the allowlist is the trust boundary.
            #
            # ``/restart --hard`` extends the bounce to THIS bot's own
            # systemd service (rtxclaw-telegram). The restart helper
            # runs detached and sleeps ~1s, so the "restarting…" reply
            # below flushes before systemd stops us — the same trick
            # the gateway bounce already relies on.
            from rtxclaw_core.restart import restart_agent_detached

            hard = "--hard" in (parsed.arg or "").split()
            agent_cfg = self._agent_cfg(chat_id, thread_id)
            res = restart_agent_detached(agent_cfg.name, hard=hard)
            if not res.get("ok"):
                await reply(f"⚠️ restart failed: {res.get('error')}")
                return
            chat_key = TelegramConfig.chat_key(chat_id, thread_id)
            client = self._clients.pop(chat_key, None)
            try:
                if client is not None and hasattr(client, "close"):
                    await client.close()
            except Exception:  # noqa: BLE001
                pass
            # Stdio fallback only — production path (HTTP-to-gateway)
            # has no per-chat child process; ``_child_procs`` stays
            # empty for HTTP-mode chats.
            proc = self._child_procs.pop(chat_key, None)
            if proc is not None:
                try:
                    proc.terminate()
                except Exception:  # noqa: BLE001
                    pass
            if res.get("telegram"):
                await reply(
                    "♻ restarting rtxclaw gateway AND this Telegram bot "
                    "(graceful, via systemd). The bot will go quiet for a "
                    "few seconds and reconnect — your session is preserved.",
                )
            elif hard:
                # --hard asked for, but the bot isn't under systemd here
                # (or the unit is missing): only the gateway can bounce.
                await reply(
                    "♻ restarting rtxclaw gateway. The Telegram bot isn't "
                    "under systemd here, so it stays up — restart "
                    "rtxclaw-telegram manually if you need it bounced. "
                    "Your session is preserved.",
                )
            else:
                await reply(
                    "♻ restarting rtxclaw gateway. "
                    "Your session is preserved — the next message will "
                    "land on the respawned agent.",
                )
            return

        try:
            client = await self._get_or_open_client(chat_id, thread_id)
        except Exception as exc:  # noqa: BLE001
            self._log.exception(
                "session command client open failed chat=%s thread=%s",
                chat_id, thread_id,
            )
            await reply(f"⚠️ agent unreachable: {exc}")
            return
        agent_cfg = self._agent_cfg(chat_id, thread_id)

        if parsed.name == "sessions":
            try:
                resp = await client.session_list()
            except Exception as exc:  # noqa: BLE001
                await reply(f"⚠️ session/list failed: {exc}")
                return
            entries = list(getattr(resp, "sessions", None) or [])
            if not entries:
                await reply("no sessions yet — send a message to start one.")
                return
            current_sid = self.get_session_id(chat_id, thread_id)

            def _entry_sid(entry: Any) -> str:
                return (
                    getattr(entry, "session_id", None)
                    or getattr(entry, "sessionId", None)
                    or ""
                )

            def _entry_title(entry: Any) -> str:
                meta = (
                    getattr(entry, "field_meta", None)
                    or getattr(entry, "meta", None)
                    or getattr(entry, "_meta", None)
                    or {}
                )
                rt = (meta or {}).get("rtxclaw", {}) if isinstance(meta, dict) else {}
                return (
                    getattr(entry, "title", None)
                    or rt.get("title")
                    or "(untitled)"
                )

            displayed = entries[:20]

            arg = (parsed.arg or "").strip()
            if arg:
                target: Optional[Any] = None
                if arg.isdigit():
                    idx = int(arg)
                    if 1 <= idx <= len(displayed):
                        target = displayed[idx - 1]
                if target is None:
                    matches = [
                        e for e in entries if _entry_sid(e).startswith(arg)
                    ]
                    if len(matches) == 1:
                        target = matches[0]
                    elif len(matches) > 1:
                        await reply(
                            f"/sessions: ambiguous prefix {arg!r}, "
                            f"{len(matches)} matches — use a longer prefix"
                        )
                        return
                if target is None:
                    await reply(f"/sessions: no match for {arg!r}")
                    return
                new_sid = _entry_sid(target)
                if not new_sid:
                    await reply("/sessions: matched entry has no session_id")
                    return
                if new_sid == (current_sid or ""):
                    await reply(f"already on session [{new_sid[:12]}]")
                    return
                # Validate the session is loadable for this agent before
                # rebinding — surfaces a clear error instead of silently
                # writing a binding the next message will fail to use.
                try:
                    await client.session_load(new_sid, cwd=str(agent_cfg.home))
                except Exception as exc:  # noqa: BLE001
                    await reply(f"⚠️ session/load failed: {exc}")
                    return
                # Abort any in-flight turn so the rebind doesn't strand a
                # streaming response on the old session.
                await self.cancel_chat(chat_id, thread_id, via="session_switch")
                self._set_session_id(chat_id, new_sid, thread_id)
                title = _entry_title(target)
                await reply(
                    f"switched to [{new_sid[:12]}] — {title}"
                )
                return

            lines = ["saved sessions:"]
            for i, entry in enumerate(displayed, 1):
                sid = _entry_sid(entry) or "?"
                # The SDK's ``SessionInfo`` exposes ``_meta`` under the
                # python-side attr ``field_meta`` (pydantic alias). The
                # ``meta`` / ``_meta`` getattrs stay as forward-compat
                # fallbacks for SDKs that don't apply the alias rename.
                meta = (
                    getattr(entry, "field_meta", None)
                    or getattr(entry, "meta", None)
                    or getattr(entry, "_meta", None)
                    or {}
                )
                rt = (meta or {}).get("rtxclaw", {}) if isinstance(meta, dict) else {}
                title = _entry_title(entry)
                turns = rt.get("turn_count") or 0
                updated_at = (
                    getattr(entry, "updated_at", None)
                    or getattr(entry, "updatedAt", None)
                    or rt.get("last_activity")
                    or ""
                )
                mark = "→ " if sid == current_sid else "  "
                age = _format_relative_age(updated_at)
                lines.append(f"{mark}{i}. {age} · {title} ({turns} turns)")
            lines.append("")
            lines.append("switch: /sessions <index|hash-prefix>")
            await reply("\n".join(lines))
            return

        if parsed.name == "history":
            sid = self.get_session_id(chat_id, thread_id)
            if sid is None:
                await reply("no session yet.")
                return
            try:
                n = int(parsed.arg) if parsed.arg.strip() else 5
            except ValueError:
                await reply(f"usage: /history [N]; got {parsed.arg!r}")
                return
            # ACP ``LoadSessionResponse`` carries ``modes`` and
            # ``configOptions`` only — turns are not on the wire. Use
            # ``session/load`` to verify the session is loadable on
            # the agent (so a stale binding surfaces an error here
            # instead of confusing "no turns yet"), then read the
            # persisted JSON directly. The agent's own ``Session.save``
            # is the authoritative writer for ``turns``; the bridge
            # never re-projects it through ACP.
            try:
                await client.session_load(sid, cwd=str(agent_cfg.home))
            except Exception as exc:  # noqa: BLE001
                await reply(f"⚠️ session/load failed: {exc}")
                return
            from rtxclaw_core.session_reader import load_session_dict
            blob = load_session_dict(agent_cfg.sessions_dir, sid)
            if blob is None:
                await reply("⚠️ couldn't read session.")
                return
            all_turns = blob.get("turns") if isinstance(blob, dict) else None
            turns = list(all_turns or [])[-max(1, n):]
            if not turns:
                await reply("no turns yet.")
                return
            lines = [f"last {len(turns)} turn(s):"]
            for i, t in enumerate(turns, 1):
                user = ""
                assistant = ""
                if isinstance(t, dict):
                    # Persisted turns use ``content`` for the model's
                    # reply (``Session.save`` shape); ``assistant`` is
                    # an older field-name kept here as a back-compat
                    # fallback so historic JSONs still render.
                    user = str(t.get("user") or "")[:80]
                    assistant = str(
                        t.get("content")
                        or t.get("assistant")
                        or "",
                    )[:80]
                lines.append(f"  {i}. ❯ {user}")
                if assistant:
                    lines.append(f"     ↳ {assistant}")
            await reply("\n".join(lines))
            return

        if parsed.name == "todo":
            sid = self.get_session_id(chat_id, thread_id)
            if sid is None:
                await reply(
                    "no session yet — todos appear once the model writes "
                    "them via the `todo` tool.",
                )
                return
            try:
                resp = await client.session_load(sid, cwd=str(agent_cfg.home))
            except Exception as exc:  # noqa: BLE001
                await reply(f"⚠️ session/load failed: {exc}")
                return
            todos: list[Any] = []
            meta = getattr(resp, "meta", None) or getattr(resp, "_meta", None) or {}
            rt = (meta or {}).get("rtxclaw", {}) if isinstance(meta, dict) else {}
            if isinstance(rt, dict):
                todos = list(rt.get("todos") or [])
            if not todos:
                # Fall back to scanning saved turns for `todo` tool
                # results — covers older sessions that pre-date the
                # session-meta channel.
                turns = list(getattr(resp, "turns", None) or [])
                for t in reversed(turns):
                    rounds = (t or {}).get("tool_rounds") if isinstance(t, dict) else None
                    if not rounds:
                        continue
                    for r in reversed(rounds):
                        for c in (r or {}).get("calls") or []:
                            if (c or {}).get("name") == "todo" and c.get("ok"):
                                # The runner persists the rendered list
                                # in `result`; surface that verbatim.
                                content = c.get("result") or ""
                                if content:
                                    await reply(content[:3500])
                                    return
            if not todos:
                await reply(
                    "no todos yet — the model adds them via the `todo` tool "
                    "when planning multi-step work.",
                )
                return
            lines = ["session todos:"]
            for i, item in enumerate(todos[:50], 1):
                if isinstance(item, dict):
                    state = item.get("state", "?")
                    body = item.get("text") or item.get("body") or ""
                    box = "[x]" if state == "done" else "[ ]"
                    lines.append(f"  {i}. {box} {body}")
                else:
                    lines.append(f"  {i}. {item}")
            await reply("\n".join(lines))
            return

        if parsed.name == "refresh":
            sid = self.get_session_id(chat_id, thread_id)
            if sid is None:
                await reply("no session yet — send a message to open one.")
                return
            try:
                resp = await client.session_load(sid, cwd=str(agent_cfg.home))
            except Exception as exc:  # noqa: BLE001
                await reply(f"⚠️ session/load failed: {exc}")
                return
            turns = list(getattr(resp, "turns", None) or [])
            await reply(
                f"🔄 synced — {len(turns)} turn(s) loaded for session "
                f"{sid[:12]}…",
            )
            return

        if parsed.name == "context":
            from rtxclaw_core.commands import normalize_context_subcommand
            from rtxclaw_core.context_report import (
                SessionTokens,
                build_context_report,
                format_context_detail,
                format_context_help,
                format_context_json,
                format_context_list,
            )

            sub = normalize_context_subcommand(parsed.arg)
            if not sub or sub == "help":
                await reply(format_context_help())
                return
            if sub not in {"list", "show", "detail", "deep", "json"}:
                await reply(
                    "Unknown /context mode.\n"
                    "Use: /context, /context list, /context detail, "
                    "or /context json"
                )
                return

            sid = self.get_session_id(chat_id, thread_id)
            if sid is None:
                await reply("no session yet — send a message to open one.")
                return

            system_prompt = ""
            ctx_window = 0
            model = ""
            permission_mode = ""
            workspace_cwd = ""
            turns: list[dict[str, Any]] = []
            try:
                from rtxclaw_core.session_reader import load_session_dict
                raw = load_session_dict(agent_cfg.sessions_dir, sid)
                if isinstance(raw, dict):
                    turns = list(raw.get("turns") or [])
                    ctx_window = int(raw.get("context_window") or 0)
                    model = raw.get("model") or ""
                    system_prompt = raw.get("system_prompt") or ""
                    permission_mode = raw.get("system_mode") or ""
                    workspace_cwd = raw.get("workspace_cwd") or ""
            except Exception as exc:  # noqa: BLE001
                self._log.debug("/context disk read failed: %s", exc)

            latest: dict[str, Any] = {}
            for t in reversed(turns):
                m = t.get("metrics") if isinstance(t, dict) else None
                if isinstance(m, dict) and m:
                    latest = m
                    break

            tools_schemas: list[dict[str, Any]] = []
            tool_summaries: list[tuple[str, str]] = []
            deferred_catalog_text = ""
            skills_block_text = ""
            skills_list: list[Any] = []
            try:
                from rtxclaw_core.tools import BUILTIN_TOOLS, ToolRegistry
                registry = ToolRegistry(BUILTIN_TOOLS)
                tools_schemas = registry.openai_schemas()
                tool_summaries = [
                    (t.name, t.description or "") for t in registry.tools
                ]
                deferred_catalog_text = registry.deferred_catalog_block()
            except Exception as exc:  # noqa: BLE001
                self._log.debug("/context tool registry read failed: %s", exc)
            try:
                from rtxclaw_core.skills import (
                    discover_skills,
                    skills_summary_block,
                )
                skills_block_text = skills_summary_block(agent_cfg.home)
                skills_list = list(discover_skills(agent_cfg.home))
            except Exception as exc:  # noqa: BLE001
                self._log.debug("/context skills read failed: %s", exc)

            report = build_context_report(
                agent_home=agent_cfg.home,
                mode=permission_mode or "auto",
                system_prompt=system_prompt,
                tools_schemas=tools_schemas,
                tool_summaries=tool_summaries,
                deferred_catalog_text=deferred_catalog_text,
                skills_block_text=skills_block_text,
                skills=skills_list,
                model=model,
                workspace_cwd=workspace_cwd,
                permission_mode=permission_mode,
                source="run" if system_prompt else "estimate",
            )
            session_tok = SessionTokens(
                total_tokens=(
                    int(latest.get("prompt_tokens"))
                    if isinstance(latest.get("prompt_tokens"), (int, float))
                    else None
                ),
                total_tokens_fresh=(
                    int(latest.get("prompt_tokens_fresh"))
                    if isinstance(latest.get("prompt_tokens_fresh"), (int, float))
                    else None
                ),
                input_tokens=(
                    int(latest.get("prompt_tokens"))
                    if isinstance(latest.get("prompt_tokens"), (int, float))
                    else None
                ),
                output_tokens=(
                    int(latest.get("completion_tokens"))
                    if isinstance(latest.get("completion_tokens"), (int, float))
                    else None
                ),
                context_tokens=ctx_window or None,
            )

            if sub == "json":
                # Telegram MarkdownV2 escapes break JSON output — wrap in
                # a code fence so the structure renders verbatim.
                payload = format_context_json(report, session_tok)
                await reply(f"```\n{payload}\n```")
            elif sub in ("detail", "deep"):
                await reply(format_context_detail(report, session_tok))
            else:
                await reply(format_context_list(report, session_tok))
            return

        if parsed.name == "compact":
            sid = self.get_session_id(chat_id, thread_id)
            if sid is None:
                await reply("no session yet — nothing to compact.")
                return
            wrapped = (
                "Call the `compact_context` tool now to squeeze the "
                "running message list. Then briefly confirm in one "
                "sentence what was trimmed."
            )
            # Route through the same rolling-message pipeline a normal
            # text prompt uses so the user sees a placeholder, the
            # tool-call header, and the assistant's confirmation —
            # ``_dispatch_blocks`` alone returns the assembled string
            # into the void (same bug pattern as the original
            # /claude /codex handlers had).
            await self._stream_turn_for_chat(
                chat_id, text=wrapped, thread_id=thread_id,
            )
            return

        await reply(f"unknown command: {text}\nsend /help to list commands")

    async def _handle_delegate_command(
        self, chat_id: int, head: str, arg: str,
        thread_id: Optional[int] = None,
    ) -> None:
        """Apply ``/claude <prompt>`` and ``/codex <prompt>`` on Telegram.

        Per CLAUDE.md "external bridges are tools, not slash commands":
        we synthesize a user prompt that biases the local model to
        emit a ``delegate_claude`` / ``delegate_codex`` tool call, then
        let the regular session_prompt stream surface the tool call +
        result. Same shape the TUI uses — one path, one runner, ESC
        kills via ``session/cancel`` like every other turn.
        """
        if self._api is None:
            return
        prompt = (arg or "").strip()
        if not prompt:
            await self._reply(chat_id, f"usage: {head} <prompt>", thread_id)
            return
        tool_name = {
            "/claude": "delegate_claude",
            "/codex": "delegate_codex",
            "/antigravity": "delegate_antigravity",
        }.get(head, "delegate_claude")
        # Direct dispatch sentinel — bridge intercepts and runs the
        # delegate tool without an LLM round. Route through the same
        # rolling-message turn pipeline a normal text prompt uses so
        # the user sees a placeholder, live tool deltas, stats footer
        # and a finalized reply — instead of _dispatch_blocks
        # returning an assembled string into the void.
        args = {"prompt": prompt}
        marker = f"__RTXCLAW_DELEGATE__:{tool_name}:{json.dumps(args)}"
        await self._stream_turn_for_chat(
            chat_id, text=marker, thread_id=thread_id,
        )

    async def _handle_agents_list(
        self, chat_id: int, thread_id: Optional[int] = None,
    ) -> None:
        """``/agents`` — list configured agents with the chat's
        current selection marked.

        Walks ``~/.rtxclaw/agents/*`` for every directory carrying a
        ``config.json``. The chat's CURRENT routed agent (per-thread
        override → bare-chat override → ``default_agent``) is shown
        with a ``▶`` marker so the operator sees where messages
        land right now.
        """
        agents = self._list_configured_agents()
        if not agents:
            await self._reply(
                chat_id,
                "no agents configured. Run `rtxclaw agent init <name>` "
                "on the server to scaffold one.",
                thread_id,
            )
            return
        current = self.tg_cfg.agent_for(chat_id, thread_id)
        lines = ["agents:"]
        for name in agents:
            marker = "▶" if name == current else " "
            lines.append(f"  {marker} {name}")
        lines.append("")
        lines.append(
            f"current: {current} (use `/agent <name>` to switch — "
            "next message starts a fresh session there).",
        )
        await self._reply(chat_id, "\n".join(lines), thread_id)

    async def _handle_agent_switch(
        self, chat_id: int, name: str,
        thread_id: Optional[int] = None,
    ) -> None:
        """``/agent <name>`` — pin this chat to ``<name>``.

        Writes the route into ``TelegramConfig.agent_routes`` keyed
        on the chat_key (chat:thread for forum topics, bare chat
        otherwise) so the binding survives bot restarts. Drops the
        cached ACP client + stdio child for the chat so the next
        message connects against the new agent. The previous agent's
        per-(chat, agent) session id stays on disk — switching back
        with another ``/agent <prev>`` resumes that session.
        """
        if not name:
            await self._reply(
                chat_id,
                "usage: /agent <name>. Use /agents to list configured "
                "agents.",
                thread_id,
            )
            return
        if not self._is_known_agent(name):
            agents = ", ".join(self._list_configured_agents()) or "(none)"
            await self._reply(
                chat_id,
                f"unknown agent {name!r}. Configured: {agents}",
                thread_id,
            )
            return
        chat_key = TelegramConfig.chat_key(chat_id, thread_id)
        prev = self.tg_cfg.agent_for(chat_id, thread_id)
        if prev == name:
            await self._reply(
                chat_id, f"already on {name}.", thread_id,
            )
            return
        # Persist the new route. The on-disk
        # ``agent_routes[chat_key]`` overrides ``default_agent`` for
        # this chat; per-thread overrides keep working untouched.
        self.tg_cfg.agent_routes[chat_key] = name
        try:
            self.tg_cfg.save()
        except OSError as e:
            await self._reply(
                chat_id,
                f"⚠️ couldn't persist route ({e}). Switch is local "
                "to this bot run.",
                thread_id,
            )
        # Drop bot-side caches so the next message lands on a fresh
        # client / stdio child against the new agent.
        client = self._clients.pop(chat_key, None)
        try:
            if client is not None and hasattr(client, "close"):
                await client.close()
        except Exception:  # noqa: BLE001
            pass
        proc = self._child_procs.pop(chat_key, None)
        if proc is not None:
            try:
                proc.terminate()
            except Exception:  # noqa: BLE001
                pass
        self._visibility.pop(chat_key, None)
        # Nudge the AgentConfig cache so /status etc. show the new
        # agent's models immediately.
        if name not in self._agent_cfg_cache:
            try:
                self._agent_cfg_cache[name] = AgentConfig.load(name)
            except Exception:  # noqa: BLE001
                pass
        # Existing session for the new agent? Preserve it (next
        # message resumes); otherwise the session_new path will open
        # a fresh one on first prompt.
        #
        # If the chat has a saved session for the new agent, verify it
        # is still loadable on the gateway BEFORE telling the user
        # we're "Resuming saved session …". The gateway can't resume
        # an idle-reaped or unknown session on the next prompt without
        # an explicit ``session/load``, so an unverified resume would
        # fail at first message with the recoverable-error path. This
        # turns that into a clean "fresh session" message instead.
        existing = (self._sessions.get(chat_key) or {}).get(name)
        resumed = False
        if existing:
            try:
                load_client = await self._get_or_open_client(chat_id, thread_id)
                target_cfg = self._agent_cfg(chat_id, thread_id)
                await load_client.session_load(
                    existing, cwd=str(target_cfg.home),
                )
                resumed = True
            except Exception as exc:  # noqa: BLE001
                self._log.warning(
                    "session_load on agent switch failed chat=%s "
                    "agent=%s sid=%s err=%s — dropping stale binding",
                    chat_key, name, existing, exc,
                )
                self._drop_session_id(
                    chat_id, thread_id, agent_name=name,
                )
                existing = None
        await self._reply(
            chat_id,
            f"switched {prev} → {name}. "
            + (
                f"Resuming saved session "
                f"{(existing or '')[:12]}…"
                if resumed
                else "Next message starts a fresh session."
            ),
            thread_id,
        )

    async def _handle_agent_delegate(
        self, chat_id: int, agent_name: str, arg: str,
        thread_id: Optional[int] = None,
    ) -> None:
        """``/<agent_name> <task>`` — one-shot delegate to ``<agent_name>``.

        Parallels ``/claude`` / ``/codex``: the chat stays on its
        currently-routed agent; we synthesize a user message that
        biases the local model to emit ``delegate_agent(name=...,
        task=...)``. The bridge intercepts the marker and runs the
        delegate tool without an LLM round, returning the spawned
        agent's reply as a tool result inline. Result is rendered
        through the same rolling-message pipeline the rest of the
        bot uses.
        """
        if self._api is None:
            return
        task = (arg or "").strip()
        if not task:
            await self._reply(
                chat_id,
                f"usage: /{agent_name} <task>",
                thread_id,
            )
            return
        args = {"name": agent_name, "task": task}
        marker = f"__RTXCLAW_DELEGATE__:delegate_agent:{json.dumps(args)}"
        await self._stream_turn_for_chat(
            chat_id, text=marker, thread_id=thread_id,
        )

    async def _handle_config_command(
        self, chat_id: int, text: str,
        thread_id: Optional[int] = None,
    ) -> None:
        """Apply a configuration slash command via the ACP wire.

        ``/mode <id>`` → ``session/set_mode``.
        ``/model <alias|url>`` → ``session/set_config_option``
        (option_id="model").
        ``/reasoning`` and ``/tools`` mutate per-(chat,thread) display
        state on the bot — the agent always emits
        ``agent_thought_chunk`` / ``tool_call_update`` over the ACP
        wire; the bot decides whether to render them inline. Mirrors
        the TUI's ``state_patch`` flow for the same toggles.
        ``/thinking`` is a model-side flag that only takes effect at
        ``session/new`` time and so just acks here.
        """
        from rtxclaw_core.commands import (
            normalize_mode,
            normalize_reasoning_level,
            normalize_thinking,
            normalize_tool_output,
            parse_command,
        )

        if self._api is None:
            return

        async def reply(t: str) -> None:
            await self._reply(chat_id, t, thread_id)

        parsed = parse_command(text)
        if parsed is None:
            await reply(f"unknown command: {text}")
            return

        try:
            client = await self._get_or_open_client(chat_id, thread_id)
        except Exception as exc:  # noqa: BLE001
            self._log.exception(
                "config command client open failed chat=%s thread=%s",
                chat_id, thread_id,
            )
            await reply(f"⚠️ agent unreachable: {exc}")
            return

        agent_cfg = self._agent_cfg(chat_id, thread_id)
        sid = self.get_session_id(chat_id, thread_id)
        if sid is None:
            # Auto-open a fresh session so config commands like /mode,
            # /model, /reasoning, /tools work straight after /new (or
            # on a brand-new chat). Previous behaviour was to reject
            # with "no session yet — send a message first…", which made
            # the natural sequence "/new → /reasoning stream → prompt"
            # fail on step 2.
            try:
                sid = await client.session_new(cwd=str(agent_cfg.home))
            except Exception as exc:  # noqa: BLE001
                self._log.exception(
                    "auto-open session for config command failed chat=%s",
                    chat_id,
                )
                await reply(f"⚠️ couldn't open a new session: {exc}")
                return
            self._set_session_id(chat_id, sid, thread_id)

        if parsed.name == "mode":
            level = normalize_mode(parsed.arg)
            if not parsed.arg:
                await reply("usage: /mode [plan|ask|auto]")
                return
            if level is None:
                await reply(
                    f"unknown mode {parsed.arg!r}. use plan, ask, or auto",
                )
                return
            try:
                await client.session_set_mode(sid, level)
            except Exception as exc:  # noqa: BLE001
                await reply(f"⚠️ set_mode failed: {exc}")
                return
            await reply(f"mode → {level}")
            return

        if parsed.name == "model":
            if not parsed.arg:
                await reply("usage: /model <alias|url>")
                return
            try:
                await client.session_set_config_option(sid, "model", parsed.arg)
            except Exception as exc:  # noqa: BLE001
                await reply(f"⚠️ model switch failed: {exc}")
                return
            await reply(f"model → {parsed.arg}")
            return

        if parsed.name == "reasoning":
            level = normalize_reasoning_level(parsed.arg) if parsed.arg else None
            if not parsed.arg:
                cur = self._get_visibility(chat_id, thread_id).get(
                    "reasoning_visibility", "off",
                )
                await reply(
                    f"reasoning is {cur} — usage: /reasoning [on|off|stream]",
                )
                return
            if level is None:
                await reply(
                    f"unknown reasoning level {parsed.arg!r}. use on, off, or stream",
                )
                return
            self._set_reasoning_visibility(chat_id, thread_id, level)
            # Push to the agent: the engine's per-session gate decides
            # whether ``thinking`` deltas reach Telegram at all (defense
            # in depth — Telegram also gates client-side via the per-chat
            # ``reasoning_visibility`` map). Without this, flipping to
            # "on" only changes the local rendering policy for a stream
            # that never carries any thinking events.
            try:
                await client.session_set_config_option(sid, "reasoning", level)
            except Exception as exc:  # noqa: BLE001
                await reply(f"⚠️ reasoning push to agent failed: {exc}")
                return
            await reply(f"reasoning → {level}")
            return

        if parsed.name == "thinking":
            val = normalize_thinking(parsed.arg) if parsed.arg else None
            if not parsed.arg:
                await reply("usage: /thinking [on|off]")
                return
            if val is None:
                await reply(
                    f"unknown thinking value {parsed.arg!r}. use on or off",
                )
                return
            await reply(
                f"thinking → {'on' if val else 'off'} (model-side flag; "
                "applies to the next session via the agent runtime)",
            )
            return

        if parsed.name == "tool":
            val = normalize_tool_output(parsed.arg) if parsed.arg else None
            if not parsed.arg:
                cur = self._get_visibility(chat_id, thread_id).get(
                    "tool_output", "off",
                )
                await reply(
                    f"tools is {cur} — usage: /tools [on|off|stream]\n"
                    "  off    — hide tool calls and results\n"
                    "  on     — show tool-call header only "
                    "(🔧 web_search…)\n"
                    "  stream — show header + raw tool output",
                )
                return
            if val is None:
                await reply(
                    f"unknown tool visibility {parsed.arg!r}. "
                    "use on, off, or stream",
                )
                return
            self._set_tool_output_level(chat_id, thread_id, val)
            await reply(f"tools → {val}")
            return

        if parsed.name == "models":
            from rtxclaw_core.commands import format_model_list

            rows = list(getattr(agent_cfg, "models", None) or [])
            if not rows:
                await reply(
                    "no models configured — add some via "
                    "`rtxclaw agent setup` or by editing "
                    f"{agent_cfg.config_path}",
                )
                return
            current_model = (
                getattr(agent_cfg, "upstream_model", "") or ""
            )
            text_out = format_model_list(rows, current_model=current_model)
            # Telegram has a 4096-char message cap. Multi-model configs
            # rarely cross 1KB, but truncate defensively.
            await reply(text_out[:3500])
            return

        await reply(f"unknown command: {text}\nsend /help to list commands")

    async def _handle_update(self, update: dict) -> None:
        """Resolve one ``getUpdates`` entry — text/voice/photo/etc.

        Per-chat lock is taken inside :meth:`_dispatch_blocks` so slash
        commands (cancel etc.) bypass it and stay responsive while a
        turn is running.
        """
        # Inline-keyboard taps (permission prompts) arrive as
        # ``callback_query`` updates, not messages — route them out
        # before the message-shaped handling below.
        if update.get("callback_query"):
            await self._handle_callback_query(update)
            return
        msg = update.get("message") or update.get("edited_message")
        # DEBUG: dump the message shape so we can see what Telegram sent
        # for forwarded / photo / document edge cases. Remove after we
        # diagnose the missing-photo bug.
        if msg:
            self._log.info(
                "update keys=%s update.keys=%s",
                sorted(msg.keys()),
                sorted(update.keys()),
            )
        if not msg:
            return
        chat = msg.get("chat") or {}
        chat_id = chat.get("id")
        if not isinstance(chat_id, int):
            return
        # Forum topics: messages in a non-General topic carry
        # ``message_thread_id``. Non-forum chats and the General topic
        # leave it absent; we treat ``None`` as "reply at top level".
        thread_id_raw = msg.get("message_thread_id")
        thread_id: Optional[int] = (
            int(thread_id_raw)
            if isinstance(thread_id_raw, (int, str))
            and str(thread_id_raw).lstrip("-").isdigit()
            else None
        )
        raw_text = msg.get("text") or msg.get("caption") or ""
        raw_text = raw_text.strip()
        # In groups Telegram appends ``@<botname>`` to slash commands
        # and users prepend ``@<botname>`` for natural-language
        # addressing. Strip both BEFORE logging + dispatch so the
        # downstream literal command checks (``cmd == "/new"`` etc.)
        # match and the model doesn't see its own handle in every
        # turn's user message. ``raw_text`` is preserved separately
        # because the mention-required gate below needs to see the
        # ORIGINAL text to detect the @handle.
        text = self._strip_bot_mention(raw_text)
        sender = msg.get("from") or {}
        preview = text[:120].replace("\n", " ")
        self._log.info(
            "RX chat=%s thread=%s user=@%s len=%d text=%r%s",
            chat_id, thread_id,
            sender.get("username") or sender.get("id") or "",
            len(text), preview,
            "…" if len(text) > 120 else "",
        )
        if not self._is_authorized(chat_id):
            await self._deny(chat_id, msg)
            return
        # Per-user allowlist (silent drop). Distinct from
        # ``allowed_chat_ids``: a chat may be on the allowlist while
        # the operator only wants the bot to respond to a specific
        # subset of members. Drop silently — replying with "you're
        # not allowed" would advertise the bot to every group member
        # who can read messages.
        sender_id_raw = sender.get("id")
        sender_id = int(sender_id_raw) if isinstance(sender_id_raw, int) else None
        if not self._user_allowed(sender_id):
            self._log.info(
                "drop chat=%s user=%s — not in allowed_user_ids",
                chat_id, sender_id,
            )
            return
        # Mention-required gate (silent drop) — only in non-private
        # chats. DMs are 1:1 by definition, so requiring a mention
        # there would just be friction. In groups / supergroups /
        # channels the operator can opt in to "only when called"
        # via ``mention_required_in_groups: true`` in
        # ``<telegram_home>/config.json``; we then ignore everything
        # the user didn't explicitly @-mention or reply-to-bot.
        chat_type = str(chat.get("type") or "").lower()
        is_private = chat_type == "private"
        if (
            self.tg_cfg.mention_required_in_groups
            and not is_private
            and not self._addressed_to_bot(raw_text, msg)
        ):
            self._log.info(
                "drop chat=%s thread=%s — mention required and not "
                "addressed to bot",
                chat_id, thread_id,
            )
            return
        # Acknowledge receipt with a 👀 reaction so the user gets
        # immediate visual confirmation that the bot saw the message
        # (independent of however long the model takes to reply).
        # Fire-and-forget — never block the turn on a reaction.
        msg_id = msg.get("message_id")
        if isinstance(msg_id, int) and self._api is not None:
            import asyncio as _asyncio
            _asyncio.create_task(self._api.call(
                "setMessageReaction",
                chat_id=chat_id,
                message_id=msg_id,
                reaction=[{"type": "emoji", "emoji": "👀"}],
                is_big=False,
            ))

        # Image / sticker / document — explicit unsupported reply, no
        # AcpClient touch.
        if msg.get("photo"):
            reply_text = await self.handle_image_message(
                chat_id, msg, thread_id=thread_id,
            )
            if self._api is not None and reply_text:
                await self._reply(chat_id, reply_text, thread_id)
            return
        if msg.get("sticker"):
            if self._api is not None:
                await self._reply(
                    chat_id, await self.handle_sticker_message(chat_id),
                    thread_id,
                )
            return
        if msg.get("document"):
            if self._api is not None:
                await self._reply(
                    chat_id, await self.handle_document_message(chat_id),
                    thread_id,
                )
            return

        # Voice / audio / video_note — go through STT, then text path.
        voice = msg.get("voice") or msg.get("audio") or msg.get("video_note")
        if voice:
            if self._stt is None or self._download_audio is None:
                if self._api is not None:
                    await self._reply(
                        chat_id,
                        "🎙 voice input received but STT is not configured. "
                        "Set OPENROUTER_API_KEY in "
                        f"{self.tg_cfg.home / '.env'} (or in the agent's "
                        ".env) and restart the bot.",
                        thread_id,
                    )
                return
            file_id = voice.get("file_id")
            if not file_id:
                return
            # Telegram's cloud Bot API can't download files over 20 MB,
            # so reject oversized audio up front with an actionable
            # message rather than the generic "couldn't download voice"
            # the silent getFile failure would otherwise produce.
            file_size = voice.get("file_size")
            _local = getattr(self._api, "local_mode", False)
            _cap = TG_LOCAL_MAX_BYTES if _local else TG_GETFILE_MAX_BYTES
            if isinstance(file_size, int) and file_size > _cap:
                self._log.info(
                    "voice rejected chat=%s file_size=%d cap=%d local=%s",
                    chat_id, file_size, _cap, _local,
                )
                if self._api is not None:
                    _human = f"{file_size / 1_048_576:.0f} MB"
                    _limit = "2 GB" if _local else "20 MB"
                    await self._reply(
                        chat_id,
                        f"⚠️ that audio is {_human} — over my {_limit} limit, "
                        "so I can't transcribe it. Send a shorter clip.",
                        thread_id,
                    )
                return
            mime = (voice.get("mime_type") or "").lower()
            original_name = voice.get("file_name")  # present for audio, absent for voice/video_note
            await self._stream_turn_for_chat(
                chat_id,
                voice_file_id=file_id, voice_mime=mime,
                original_filename=original_name,
                thread_id=thread_id,
            )
            return

        if not text:
            return

        # Slash commands run outside the chat lock so /stop, /cancel,
        # and /abort stay responsive while a turn is in-flight — they
        # share the imperative cancel path in ``_dispatch_abort`` and
        # MUST land even if the chat lock is held by a streaming turn.
        if text.startswith("/"):
            await self._handle_command(chat_id, text, thread_id)
            return

        await self._stream_turn_for_chat(
            chat_id, text=text, thread_id=thread_id,
        )

    async def _stream_turn_for_chat(
        self,
        chat_id: int,
        *,
        text: Optional[str] = None,
        voice_file_id: Optional[str] = None,
        voice_mime: str = "",
        original_filename: Optional[str] = None,
        thread_id: Optional[int] = None,
    ) -> None:
        """Wire one Telegram message → one ACP turn → streaming edits.

        Sends a placeholder, opens the AcpClient (lazy on first message),
        builds the ``ContentBlock`` list (text or transcribed voice), and
        feeds ``session_prompt`` updates into a :class:`_RollingMessage`
        for in-place edits. The final ``PromptResponse`` triggers
        ``finalize`` so the placeholder ends in a meaningful state.

        ``thread_id`` (Telegram ``message_thread_id``) is propagated to
        every send/edit so replies in a forum topic land in the same
        topic, not the General room.
        """
        if self._api is None:
            return

        placeholder_id = await self._api.send_message(
            chat_id, "💭 thinking…", message_thread_id=thread_id,
        )
        if placeholder_id is None:
            self._log.warning(
                "TURN abort chat=%s thread=%s — placeholder send failed",
                chat_id, thread_id,
            )
            return

        roller = _RollingMessage(
            self._api, chat_id,
            placeholder_id=placeholder_id,
            log=self._log,
            thread_id=thread_id,
        )
        t0 = time.monotonic()

        # Build content blocks. Voice → STT → text block; text → text
        # block. Image / document already short-circuited above.
        import acp.schema as _acp
        blocks: list = []

        if voice_file_id:
            if (
                self._download_audio is None or self._stt is None
            ):  # pragma: no cover — guarded by _handle_update
                await roller.finalize("⚠️ STT not configured")
                return
            try:
                dl = await self._download_audio(voice_file_id)
            except Exception:  # noqa: BLE001
                self._log.exception("voice download failed chat=%s", chat_id)
                await roller.finalize("⚠️ couldn't download voice")
                return
            if not dl:
                await roller.finalize("⚠️ couldn't download voice")
                return
            audio_bytes, filename = dl
            async def _on_stt_progress(k, n):
                if n > 1:
                    try:
                        await self._api.edit_message(
                            chat_id, placeholder_id, f"🎙️ transcribing {k}/{n}…")
                    except Exception:  # noqa: BLE001
                        pass
            try:
                transcript = await self._stt(
                    audio_bytes, mime=voice_mime, filename=filename,
                    on_progress=_on_stt_progress,
                )
            except Exception:  # noqa: BLE001
                self._log.exception("stt failed chat=%s", chat_id)
                await roller.finalize("⚠️ transcription failed")
                return
            if not transcript:
                await roller.finalize("⚠️ empty transcription")
                return
            self._log.info(
                "STT chat=%s len=%d preview=%r",
                chat_id, len(transcript), transcript[:120],
            )
            # Persist transcript to disk so call transcripts survive
            # across bot restarts and agent memory sweeps.
            try:
                agent_cfg = self._agent_cfg(chat_id, thread_id)
                xdir = agent_cfg.home / "transcriptions"
                xdir.mkdir(parents=True, exist_ok=True)
                now = datetime.now(timezone.utc)
                ts = now.strftime("%Y-%m-%d_%H-%M-%S")
                # Prefer the original filename from the Telegram message;
                # fall back to the getFile-derived name when absent (voice notes).
                display_stem = (
                    Path(original_filename).stem
                    if original_filename else Path(filename).stem
                )
                xpath = xdir / f"{ts}_{display_stem}.md"
                xpath.write_text(
                    f"# {display_stem}\n\n"
                    f"*Transcribed {now.isoformat()} | "
                    f"source: `{filename}`*\n\n"
                    f"{transcript}\n",
                    encoding="utf-8",
                )
                self._log.info("transcript saved to %s", xpath)
            except Exception:  # noqa: BLE001
                self._log.exception("transcript save failed chat=%s", chat_id)
            # Echo the transcript back so the user sees what the model
            # actually received — surfaces STT errors immediately.
            #
            # Telegram orders bubbles by message_id, not by edit time.
            # The reply streams INTO the placeholder, so the echo must
            # occupy an EARLIER message_id to render above it. Sending
            # the echo as a separate message gave it a LATER id — it
            # landed below the reply. Instead, reuse the first
            # placeholder (its earlier id) for the echo, then open a
            # fresh placeholder for the reply.
            _LONG = 1500
            if len(transcript) > _LONG:
                _words = len(transcript.split())
                # Preserve the original filename the user sent; swap extension to .txt.
                doc_name = (
                    f"{Path(original_filename).stem}.txt"
                    if original_filename else "transcript.txt"
                )
                try:
                    await self._api.send_document(
                        chat_id, transcript.encode("utf-8"),
                        filename=doc_name,
                        caption=f"🎙️ transcript ({_words} words)",
                        message_thread_id=thread_id,
                    )
                except Exception:  # noqa: BLE001
                    self._log.warning("transcript doc send failed chat=%s", chat_id)
                try:
                    await self._api.edit_message(
                        chat_id, placeholder_id,
                        f"🎙️ heard ({_words} words) — full transcript attached",
                    )
                except Exception:  # noqa: BLE001
                    pass
            else:
                try:
                    await self._api.edit_message(
                        chat_id, placeholder_id, f'🎙️ heard: "{transcript}"',
                    )
                except Exception:  # noqa: BLE001
                    self._log.warning("transcript echo edit failed chat=%s", chat_id)
            reply_placeholder_id = await self._api.send_message(
                chat_id, "💭 thinking…", message_thread_id=thread_id,
            )
            if reply_placeholder_id is None:
                self._log.warning(
                    "TURN abort chat=%s thread=%s — reply placeholder "
                    "send failed",
                    chat_id, thread_id,
                )
                return
            placeholder_id = reply_placeholder_id
            roller = _RollingMessage(
                self._api, chat_id,
                placeholder_id=placeholder_id,
                log=self._log,
                thread_id=thread_id,
            )
            blocks.append(
                _acp.TextContentBlock(type="text", text=transcript),
            )
        elif text:
            blocks.append(_acp.TextContentBlock(type="text", text=text))
        else:
            # Nothing to send.
            await roller.finalize("(no input)")
            return

        # Track whether the agent has streamed any visible content; we
        # use this to decide whether tool-status ticks may safely
        # overwrite the placeholder line.
        content_state = {"streamed": False}

        async def _on_chunk(buf: str, *, force: bool = False) -> None:
            if buf:
                content_state["streamed"] = True
            # ``force=True`` bypasses the throttle/embargo gates inside
            # ``_RollingMessage.update`` (lines 1088-1094). Callers pass
            # it at tool-boundary transitions where the next event is
            # a (potentially heavy) tool that blocks the agent for
            # seconds-to-minutes: without a forced flush, the throttle
            # silently drops the edit (``now - last_edit_at <
            # cur_throttle``) and the tail of the assistant's prose +
            # the tool header stay hidden until the tool completes and
            # another chunk arrives to retry. With ``force``, the
            # edit lands immediately.
            await roller.update(buf, force=force)

        async def _on_tool_status(title: str, status: str) -> None:
            # Once real content has streamed in, never let a tool-
            # status tick overwrite it. Pre-prompt phases (plan_classify
            # / plan_pass) tick BEFORE any chunks so they always pass.
            if content_state["streamed"]:
                return
            if title in ("plan_classify", "plan_pass"):
                emoji = "🧠" if title == "plan_classify" else "📐"
                if status == "in_progress":
                    await roller.update(f"{emoji} {title}…")
                elif status in ("completed", "failed"):
                    # Phase ended before any real content; restore the
                    # idle placeholder so the user knows the next phase
                    # (real prefill) has started.
                    await roller.update("💭 thinking…")
            else:
                # Other tool calls (web_search, exec, etc.) — show in
                # the placeholder until content lands. Consistent UX.
                if status == "in_progress":
                    await roller.update(f"🔧 {title}…")

        try:
            assembled = await self._dispatch_blocks(
                chat_id, blocks,
                on_chunk=_on_chunk,
                on_tool_status=_on_tool_status,
                thread_id=thread_id,
            )
        except asyncio.CancelledError:
            assembled = "⏹ aborted"
            raise
        finally:
            elapsed = time.monotonic() - t0
            self._log.info(
                "TURN done chat=%s edits_ok=%d edits_429=%d "
                "rollovers=%d throttle=%.1fs t=%.1fs",
                chat_id, roller.n_edits_ok, roller.n_edits_429,
                roller.n_rollovers, roller.cur_throttle, elapsed,
            )
            try:
                await roller.finalize(assembled or "(no content)")
            except Exception:  # noqa: BLE001
                self._log.exception("finalize failed chat=%s", chat_id)
            # Voice reply: when the user spoke, also synthesise the
            # assembled text reply and send it as an audio bubble next
            # to the text. Skips silently if TTS isn't wired, the reply
            # is just an error envelope, or the agent produced nothing.
            if (
                voice_file_id
                and self._tts is not None
                and assembled
                and not assembled.startswith(("⚠️", "(no content)", "⏹"))
            ):
                try:
                    audio_bytes = await self._tts(assembled)
                except Exception:  # noqa: BLE001
                    self._log.exception("TTS reply failed chat=%s", chat_id)
                    audio_bytes = None
                if audio_bytes:
                    # WAV-from-TB07 proxy needs honest mime/filename
                    # (send_voice's MP3 defaults would mislabel and break
                    # Telegram delivery). When we later switch the proxy
                    # to MP3 (or move to OGG/Opus + true sendVoice) these
                    # overrides go away.
                    try:
                        await self._api.send_voice(
                            chat_id, audio_bytes,
                            message_thread_id=thread_id,
                            mime="audio/wav",
                            filename="voice.wav",
                        )
                    except Exception:  # noqa: BLE001
                        self._log.exception(
                            "voice-reply send failed chat=%s", chat_id,
                        )

    async def _drain_backlog(self) -> int:
        """Skip every Telegram update queued from before this startup.

        If the bot was offline for any length of time, Telegram has been
        accumulating updates server-side. Replaying them would mean
        responding to questions the user might have asked hours ago and
        already given up on.
        """
        if self._api is None:
            return 0
        skipped = 0
        offset = _load_update_offset(self.tg_cfg)
        while not self._stop.is_set():
            res = await self._api.call(
                "getUpdates",
                offset=offset,
                timeout=0,
                limit=100,
                allowed_updates=["message", "edited_message", "callback_query"],
            )
            if not res.get("ok"):
                self._log.warning(
                    "drain: getUpdates failed: %s", res.get("description"),
                )
                break
            batch = res.get("result") or []
            if not batch:
                break
            last = batch[-1].get("update_id")
            if isinstance(last, int):
                offset = last + 1
                _save_update_offset(self.tg_cfg, offset)
            skipped += len(batch)
        if skipped:
            self._log.info(
                "drain: skipped %d backlog update(s) — bot only replies to "
                "new messages from now on", skipped,
            )
        return skipped

    async def _handle_update_safe(self, update: dict) -> None:
        try:
            await self._handle_update(update)
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001
            self._log.exception("handler crashed on update: %s", update)

    async def run(self) -> int:
        """Main long-poll loop. Honors ``request_stop`` (SIGTERM)."""
        # Write the pidfile from inside the bot so both the daemonised
        # ``rtxclaw telegram start`` path and the systemd-managed
        # ``ExecStart=python -m rtxclaw_telegram.bot`` path produce
        # the same on-disk artefacts (status / stop subcommands rely
        # on the file existing).
        try:
            self.tg_cfg.pidfile.parent.mkdir(parents=True, exist_ok=True)
            self.tg_cfg.pidfile.write_text(str(os.getpid()), encoding="utf-8")
        except OSError:
            self._log.exception("failed to write pidfile")
        if self._api is None:
            self._api = _TelegramAPI(
                self.tg_cfg.bot_token,
                api_base=os.environ.get("RTXCLAW_TELEGRAM_API_BASE", TELEGRAM_API),
                log=self._log,
            )
        # Wire default audio download (always — uses the bot-file CDN)
        # and STT (only if OPENROUTER_API_KEY is set). Tests inject
        # their own; the production path lands here.
        if self._download_audio is None:
            self._download_audio = _make_default_audio_downloader(self._api)
        if self._download_image is None:
            self._download_image = self._download_audio
        if self._stt is None:
            qwen_stt_url = os.environ.get("RTXCLAW_STT_BASE_URL", "").strip()
            if qwen_stt_url:
                # TB07 mode: standard multipart Whisper API.
                stt_key = (
                    os.environ.get("RTXCLAW_STT_API_KEY", "").strip()
                    or os.environ.get("OPENROUTER_API_KEY", "").strip()
                    or "tb07-no-auth"
                )
                self._stt = _make_default_qwen_stt(stt_key, self._log)
                self._log.info(
                    "STT wired: multipart %s model=%s",
                    qwen_stt_url,
                    os.environ.get("RTXCLAW_STT_MODEL", "qwen3-asr-1.7b"),
                )
            else:
                api_key = os.environ.get("OPENROUTER_API_KEY", "").strip()
                if api_key:
                    self._stt = _make_default_openrouter_stt(api_key, self._log)
                    self._log.info(
                        "STT wired: OpenRouter %s", OPENROUTER_STT_MODEL,
                    )
                else:
                    self._log.warning(
                        "OPENROUTER_API_KEY unset — voice input will be "
                        "rejected. Set it in %s or %s to enable STT.",
                        self.tg_cfg.home / ".env",
                        f"~/.rtxclaw/agents/{self.tg_cfg.default_agent}/.env",
                    )
        # TTS wires when an OpenRouter (or compatible) key is present.
        # Defaults to the same OPENROUTER_API_KEY that drives STT so a
        # single env var enables both directions of the voice path.
        # RTXCLAW_TTS_API_KEY / OPENAI_API_KEY are fallbacks for
        # operators who want to point at OpenAI direct via
        # RTXCLAW_TTS_BASE_URL. Failure to wire is non-fatal — voice
        # replies just don't fire; text reply path stays unaffected.
        if self._tts is None:
            tts_key = (
                os.environ.get("OPENROUTER_API_KEY")
                or os.environ.get("RTXCLAW_TTS_API_KEY")
                or os.environ.get("OPENAI_API_KEY")
                or ""
            ).strip()
            if tts_key:
                self._tts = _make_default_openrouter_tts(tts_key, self._log)
                self._log.info(
                    "TTS wired: TB07 %s voice=%s",
                    OPENROUTER_TTS_DEFAULT_MODEL, OPENROUTER_TTS_DEFAULT_VOICE,
                )
            else:
                self._log.info(
                    "TTS unwired — set OPENROUTER_API_KEY to enable voice "
                    "replies for voice-input chats.",
                )
        # ``default_agent`` shown so operators can see which agent the
        # bot will route brand-new chats to; per-(chat,thread) routes
        # in ``agent_routes`` override that and are logged on first
        # use.
        self._log.info(
            "rtxclaw-telegram-acp poller started default_agent=%s "
            "allow=%s trusted=%s acp_url=%s routes=%d",
            self.tg_cfg.default_agent,
            self.tg_cfg.allowed_chat_ids,
            sorted(self.trusted_chats),
            self.acp_url or "(stdio)",
            len(self.tg_cfg.agent_routes or {}),
        )
        if not self.tg_cfg.allowed_chat_ids:
            self._log.warning(
                "allowed_chat_ids is EMPTY — every incoming message "
                "will be denied. Add your Telegram chat_id to %s "
                "and `rtxclaw telegram restart` to enable.",
                self.tg_cfg.config_path,
            )
        # Identify the bot.
        me = await self._api.call("getMe")
        if me.get("ok"):
            u = me["result"]
            self._bot_username = str(u.get("username") or "")
            try:
                self._bot_user_id = int(u.get("id") or 0)
            except (TypeError, ValueError):
                self._bot_user_id = 0
            self._log.info(
                "bot connected: @%s id=%s", u.get("username"), u.get("id"),
            )
            # Register slash commands with Telegram's Bot API so the
            # "/" autocomplete popup shows the actual commands the bot
            # handles. This runs every startup — Telegram persists the
            # last set; there's no stale-state concern.
            try:
                cmds_result = await self._api.call(
                    "setMyCommands",
                    commands=_PERSISTENT_COMMANDS,
                )
                if cmds_result.get("ok"):
                    self._log.info(
                        "registered %d commands via setMyCommands",
                        len(_PERSISTENT_COMMANDS),
                    )
                else:
                    self._log.warning(
                        "setMyCommands failed: %s",
                        cmds_result.get("description"),
                    )
            except Exception:  # noqa: BLE001
                self._log.exception("setMyCommands raised")
        else:
            self._log.error(
                "getMe failed: %s — token may be invalid",
                me.get("description"),
            )
            return 1

        # Verify any persisted chat→session bindings are still alive on
        # the agent side. Failures mark the chat stale; the next message
        # starts a fresh session.
        try:
            await self.verify_sessions_on_startup()
        except Exception:  # noqa: BLE001
            self._log.exception("verify_sessions_on_startup raised")

        # Skip backlog so an offline bot doesn't replay stale conversation.
        await self._drain_backlog()

        try:
            while not self._stop.is_set():
                if self._dispatched:
                    self._dispatched = {
                        t for t in self._dispatched if not t.done()
                    }

                offset = _load_update_offset(self.tg_cfg)
                stop_wait = asyncio.create_task(self._stop.wait())
                poll_task = asyncio.create_task(self._api.call(
                    "getUpdates",
                    offset=offset,
                    timeout=LONG_POLL_TIMEOUT_S,
                    allowed_updates=["message", "edited_message", "callback_query"],
                ))
                done, _pending = await asyncio.wait(
                    {stop_wait, poll_task},
                    return_when=asyncio.FIRST_COMPLETED,
                )
                if stop_wait in done:
                    poll_task.cancel()
                    try:
                        await poll_task
                    except (asyncio.CancelledError, Exception):  # noqa: BLE001
                        pass
                    break
                stop_wait.cancel()
                try:
                    res = poll_task.result()
                except Exception as e:  # noqa: BLE001
                    self._log.warning("getUpdates raised: %s", e)
                    await asyncio.sleep(2.0)
                    continue
                if not res.get("ok"):
                    self._log.warning(
                        "getUpdates failed: %s", res.get("description"),
                    )
                    await asyncio.sleep(2.0)
                    continue
                updates = res.get("result") or []
                for upd in updates:
                    uid = upd.get("update_id")
                    if isinstance(uid, int):
                        _save_update_offset(self.tg_cfg, uid + 1)
                    task = asyncio.create_task(
                        self._handle_update_safe(upd),
                    )
                    self._dispatched.add(task)
        finally:
            for task in list(self._dispatched):
                if not task.done():
                    task.cancel()
            if self._dispatched:
                try:
                    await asyncio.wait_for(
                        asyncio.gather(
                            *self._dispatched, return_exceptions=True,
                        ),
                        timeout=5.0,
                    )
                except asyncio.TimeoutError:
                    pass
            await self.close()
            # Clean up the pidfile so ``status`` reports stopped
            # without a stale entry. Best-effort — if another process
            # already replaced it, leave the new one alone.
            try:
                if self.tg_cfg.pidfile.is_file():
                    pid_text = self.tg_cfg.pidfile.read_text(encoding="utf-8").strip()
                    if pid_text == str(os.getpid()):
                        self.tg_cfg.pidfile.unlink()
            except OSError:
                pass
            self._log.info("rtxclaw-telegram-acp poller stopped")
        return 0


# ---------------------------------------------------------------------------
# Entry points
# ---------------------------------------------------------------------------


def _setup_logging(tg_cfg: TelegramConfig) -> logging.Logger:
    log = logging.getLogger("rtxclaw.telegram")
    log.setLevel(logging.INFO)
    log.propagate = False
    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    log_path = tg_cfg.logfile
    log_path.parent.mkdir(parents=True, exist_ok=True)
    fh = logging.FileHandler(log_path, encoding="utf-8")
    fh.setFormatter(fmt)
    log.addHandler(fh)
    sh = logging.StreamHandler(sys.stderr)
    sh.setFormatter(fmt)
    log.addHandler(sh)
    return log


def _load_env_file(path: Path) -> int:
    """Merge ``KEY=value`` lines from ``path`` into ``os.environ``.

    Mirrors ``rtxclaw_agent.runtime._load_agent_env_file`` so the
    Telegram bot picks up secrets the same way an agent does. Vars
    already set non-empty in ``os.environ`` win over the file (so an
    explicit ``Environment=`` on a systemd unit / shell-exported var
    can still override). Returns the number of vars added.
    """
    if not path.is_file():
        return 0
    added = 0
    try:
        for raw in path.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            if not key:
                continue
            if os.environ.get(key):
                continue
            value = value.strip()
            if (
                len(value) >= 2
                and value[0] == value[-1]
                and value[0] in ("'", '"')
            ):
                value = value[1:-1]
            os.environ[key] = value
            added += 1
    except OSError:
        pass
    return added


def _bootstrap_env(tg_cfg: TelegramConfig) -> list[tuple[Path, int]]:
    """Load ``.env`` files into ``os.environ`` before the bot starts.

    Order (lowest priority first; later loads don't overwrite already
    populated vars):

      1. ``<telegram_home>/.env`` — bot-specific secrets.
      2. ``<agents_root>/<default_agent>/.env`` — falls back to the
         agent's own credential set so a Telegram operator who put
         ``OPENROUTER_API_KEY=...`` in ``agents/main/.env`` (the most
         common layout) gets STT for free without having to duplicate
         the key into the telegram home.

    Returns ``[(path, vars_added), …]`` so the caller can log which
    files contributed which secrets.
    """
    loaded: list[tuple[Path, int]] = []
    tg_env = tg_cfg.home / ".env"
    n = _load_env_file(tg_env)
    if n or tg_env.is_file():
        loaded.append((tg_env, n))
    # Agent .env: best-effort — the AgentConfig.load can fail (no
    # config.json yet, malformed file, etc.); a missing default-agent
    # config shouldn't block the bot from booting on its own .env.
    try:
        agent_cfg = AgentConfig.load(tg_cfg.default_agent or "main")
        agent_env = agent_cfg.home / ".env"
        n = _load_env_file(agent_env)
        if n or agent_env.is_file():
            loaded.append((agent_env, n))
    except Exception:  # noqa: BLE001
        pass
    return loaded


def acp_main(argv: Optional[list[str]] = None) -> int:
    """Module entry point. Run as ``python -m rtxclaw_telegram.bot``
    (no agent arg — routing comes from
    ``~/.rtxclaw/telegram/config.json``).
    """
    parser = argparse.ArgumentParser(
        prog="rtxclaw-telegram",
        description=(
            "Standalone Telegram bot service for rtxclaw. Routes each "
            "chat to the agent named in TelegramConfig.agent_routes "
            "(or default_agent for new chats)."
        ),
    )
    parser.add_argument(
        "--acp-url",
        default=None,
        help=(
            "ACP gateway URL, e.g. http://127.0.0.1:7700 (Streamable "
            "HTTP). Per-chat routing appends /acp/<agent>. ws:// "
            f"accepted for legacy/test servers. Falls back to "
            f"${ACP_DEFAULT_WS_URL_ENV} or, if unset, a stdio child "
            "spawn (test-only fallback)."
        ),
    )
    parser.add_argument(
        "--acp-token",
        default=None,
        help=(
            "Bearer token for the gateway, if it was started with "
            f"auth_token. Falls back to ${ACP_BEARER_TOKEN_ENV}."
        ),
    )
    args = parser.parse_args(argv)

    tg_cfg = TelegramConfig.load()
    if not tg_cfg.bot_token:
        sys.stderr.write(
            "no Telegram bot_token configured in "
            f"{tg_cfg.config_path}\n"
            "Run `rtxclaw telegram setup` to create one, or edit the "
            "file directly.\n",
        )
        return 1

    # Populate os.environ from .env files BEFORE _setup_logging /
    # AcpTelegramBot.run reads them. Without this, a fresh shell with
    # no exported OPENROUTER_API_KEY would boot the bot with STT
    # disabled even when the operator already configured the key in
    # their agent's .env.
    env_loaded = _bootstrap_env(tg_cfg)

    log = _setup_logging(tg_cfg)
    for path, n in env_loaded:
        if n:
            log.info(".env: loaded %d var(s) from %s", n, path)
        else:
            log.debug(".env: %s present but no new vars added", path)

    async def _go() -> int:
        bot = AcpTelegramBot(
            tg_cfg,
            acp_url=args.acp_url,
            acp_bearer_token=args.acp_token,
            log=log,
        )
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                loop.add_signal_handler(sig, bot.request_stop)
            except (NotImplementedError, RuntimeError):
                pass
        return await bot.run()

    try:
        return asyncio.run(_go())
    except KeyboardInterrupt:
        return 0


# Backwards-compatible alias. The gateway-spawn path is
# ``python -m rtxclaw_telegram.bot``; that lands on ``__main__`` below.
# ``main`` is exported so existing callers (operators with shell aliases,
# external tooling) that imported it continue to work.
main = acp_main


if __name__ == "__main__":
    sys.exit(acp_main())
