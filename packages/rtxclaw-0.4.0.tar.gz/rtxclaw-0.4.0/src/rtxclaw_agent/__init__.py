"""rtxclaw-agent — the gateway distribution.

This package owns:

- the single-process agent gateway (``rtxclaw_agent.gateway``) — one
  Streamable HTTP ACP listener that mounts ``/acp/<agent>`` per
  configured agent and lazy-spawns each agent as a stdio child,
- ACP-stdio entry point used by the gateway to host each child,
- gateway-side concerns that are not ACP-expressible (doctor, etc.).

Modules of interest:

- ``gateway`` — the single-process gateway parent + child manager.
- ``gateway_cli`` — ``rtxclaw gateway {start,stop,status,...}`` CLI
  (also the entrypoint systemd's ``rtxclaw-gateway.service`` calls).
- ``acp_bridge.CoreBackend`` — adapts the rtxclaw-core session/turn
  machinery to :class:`rtxclaw_acp.server.AgentBackend`.
- ``acp_stdio_main`` — stdio entry point spawned by the gateway as a
  child per agent.
- ``agent_cli`` — config-only ``rtxclaw agent {init,list,status,...}``
  surface (no per-agent daemon lifecycle — gateway owns that).
- ``runtime`` — shared ``_autodetect_display_env`` /
  ``_load_agent_env_file`` helpers used by ``acp_stdio_main``.
- ``heartbeat``, ``doctor``, ``worker``.

Sibling packages: ``rtxclaw_memory`` (fact / vector / synth memory) and
``rtxclaw_mcp`` (MCP client + bundled servers, including the YouTube
transcript server).
"""
from __future__ import annotations

__version__ = "0.1.0.dev0"

__all__ = ["__version__"]
