"""rtxclaw-core — the transport-agnostic shared library.

This package is the home for everything below the ACP wire and below
the daemon: model dispatch, sessions, tools, memory, skills,
permissions, providers. It imports nothing from ``rtxclaw_acp``,
``rtxclaw_agent``, ``rtxclaw_tui``, or ``rtxclaw_telegram`` — the
dependency arrow points one way only.
"""
from __future__ import annotations

__version__ = "0.1.0.dev0"

__all__ = ["__version__"]
