"""rtxclaw-tui — terminal UI distribution.

Generic ACP client; drives any compliant agent. ``agent_client`` is
an adapter over :mod:`rtxclaw_acp.client`.
"""
from __future__ import annotations

__version__ = "0.4.0"

__all__ = ["__version__"]
