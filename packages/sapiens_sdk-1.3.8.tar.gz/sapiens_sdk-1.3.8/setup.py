"""
The Sapiens-SDK is a software development kit that provides all the algorithms from Sapiens Technology®️
necessary for the development, training, fine-tuning, inference, and testing of the company's Artificial Intelligence models.
The module also includes tools and utility resources that facilitate the architecture and engineering of AI systems and distributed programs.

The Sapiens Technology®️ does not allow the copying, sharing, editing, customization,
or manipulation of this and all its other algorithms by third parties without the company's prior authorization.
Reverse engineering, or public posts and comments that in any way reveal the company's technical concepts,
are also strictly prohibited. Failure to comply with these guidelines will result in legal action taken by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from setuptools import setup, find_packages
package_name = 'sapiens_sdk'
version = '1.3.8'
setup(
    name=package_name,
    version=version,
    author='SAPIENS TECHNOLOGY',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'dotenv',
        'pillow',
        'huggingface-hub',
        'utilities-nlp',
        'SUBMODELS',
        'FRANKENSTEIN-MODEL',
        'SAPI-ARCHITECTURE',
        'sapiens-bench',
        'sapiens-dataset',
        'sapiens-stack',
        'tqdm'
    ],
    url='https://github.com/sapiens-technology/SapiensSDK',
    license='Proprietary Software'
)
"""
The Sapiens-SDK is a software development kit that provides all the algorithms from Sapiens Technology®️
necessary for the development, training, fine-tuning, inference, and testing of the company's Artificial Intelligence models.
The module also includes tools and utility resources that facilitate the architecture and engineering of AI systems and distributed programs.

The Sapiens Technology®️ does not allow the copying, sharing, editing, customization,
or manipulation of this and all its other algorithms by third parties without the company's prior authorization.
Reverse engineering, or public posts and comments that in any way reveal the company's technical concepts,
are also strictly prohibited. Failure to comply with these guidelines will result in legal action taken by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
