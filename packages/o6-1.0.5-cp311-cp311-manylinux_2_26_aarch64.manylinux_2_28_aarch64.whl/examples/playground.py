import o6
import time

s = o6.Server(port=4840)
s.start()

n = s.add_variable(
    "IntegerVariable", s.objects_node, o6.Int32(42), nodeid="ns=1;s=IntegerVariable"
)

print(n)

r = s.read_node_info("ns=1;s=IntegerVariable")

print(r)


s.stop()


quit()


c = o6.Client("opc.tcp://localhost:4840")
c.connect()

v = c.read("ns=1;s=IntegerVariable", as_datavalue=True)
print(v)

c.monitor(
    "ns=1;s=IntegerVariable", lambda dv: print("Value changed:", dv), as_datavalue=True
)

c.write("ns=1;s=IntegerVariable", 123)
time.sleep(2)

c.disconnect()
