from typing import Any, IO

def safe_close(file: IO[Any] | int | Any | None) -> None:
    """ Safely close a file object (or file descriptor) after flushing, ignoring any exceptions.

\tArgs:
\t\tfile (IO[Any] | int | None): The file object or file descriptor to close
\t"""
