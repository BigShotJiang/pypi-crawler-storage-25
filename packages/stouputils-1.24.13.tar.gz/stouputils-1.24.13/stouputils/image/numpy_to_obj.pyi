import numpy as np
from ..io.path import super_open as super_open
from ..print.message import debug as debug, info as info
from numpy.typing import NDArray as NDArray
from typing import Any

def extract_verts_faces_from_segment(array: NDArray[Any], spacing: tuple[float, float, float], threshold: float, step_size: int, pad_array: bool) -> tuple['NDArray[np.floating]', 'NDArray[np.integer]']:
    """ Extract vertices and faces from a single segmentation array using marching cubes.

\tArgs:
\t\tarray     (NDArray): 3D numpy array containing the segmentation mask.
\t\tspacing   (tuple):   Voxel spacing along each axis, passed to marching cubes.
\t\tthreshold (float):   Threshold level for marching cubes (0.5 for binary data).
\t\tstep_size (int):     Step size for marching cubes (higher = simpler mesh, faster generation).
\t\tpad_array (bool):    If True, pad array with zeros to ensure closed volumes for border cells.

\tReturns:
\t\ttuple[NDArray[np.floating], NDArray[np.integer]]: Vertices and faces of the extracted mesh.
\t"""
def numpy_to_obj(path: str, array: NDArray[Any], spacing: tuple[float, float, float] = (1.0, 1.0, 1.0), threshold: float = 0.5, step_size: int = 1, pad_array: bool = True, verbose: int = 0) -> None:
    ''' Generate a \'.obj\' file from a numpy array for 3D visualization using marching cubes.

\tArgs:
\t\tpath      (str):     Path to the output .obj file.
\t\tarray     (NDArray): Numpy array to be dumped (must be 3D).
\t\tspacing   (tuple):   Voxel spacing along each axis, passed to marching cubes.
\t\tthreshold (float):   Threshold level for marching cubes (0.5 for binary data).
\t\tstep_size (int):     Step size for marching cubes (higher = simpler mesh, faster generation).
\t\tpad_array (bool):    If True, pad array with zeros to ensure closed volumes for border cells.
\t\tverbose   (int):     Verbosity level (0 = no output, 1 = some output, 2 = full output).

\tExamples:

\t\t.. code-block:: python

\t\t\t> array = np.random.rand(64, 64, 64) > 0.5
\t\t\t> numpy_to_obj("output_mesh.obj", array, threshold=0.5, step_size=2, pad_array=True, verbose=1)

\t\t\t> array = my_3d_data
\t\t\t> numpy_to_obj("output_mesh.obj", array, spacing=(1.0, 1.0, 2.5), threshold=0.3)
\t'''
