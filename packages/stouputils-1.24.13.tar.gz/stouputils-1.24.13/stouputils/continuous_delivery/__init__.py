""" Continuous delivery and deployment utilities.

This module provides tools for automating software delivery and deployment:

Key Features:
- GitHub release management and uploads
- GitLab release management and uploads
- PyPI package publishing utilities
- pyproject.toml file management
- Common CD/CI utilities
- Local git changelog generation

Components:

- :py:mod:`~cd_utils`: Common utilities for continuous delivery
- :py:mod:`~git`: Local git changelog utilities (:py:func:`~git.generate_local_changelog`, :py:func:`~git.changelog_cli`)
- :py:mod:`~github`: GitHub-specific utilities (:py:func:`~github.upload_to_github`)
- :py:mod:`~gitlab`: GitLab-specific utilities (:py:func:`~gitlab.upload_to_gitlab`)
- :py:mod:`~pypi`: PyPI publishing tools (:py:func:`~pypi.pypi_full_routine`)
- :py:mod:`~pyproject`: pyproject.toml file management
- :py:mod:`~stubs`: Stub file generation using pyright (:py:func:`~stubs.stubs_full_routine`)

"""
# Imports
from .cd_utils import *
from .git import *
from .github import *
from .gitlab import *
from .pypi import *
from .pyproject import *
from .stubs import *

