from ..print.message import info as info, warning as warning
from .main import install_program as install_program

def download_executable(download_urls: dict[str, str], program_name: str, append_to_path: str = '') -> bool:
    ''' Ask the user if they want to download the program (ex: waifu2x-ncnn-vulkan).
\tIf yes, try to download the program from the GitHub releases page.

\tArgs:
\t\tdownload_urls  (dict[str, str]):  The URLs to download the program from.
\t\tprogram_name   (str):             The name of the program to download.
\t\tappend_to_path (str):             String to append to installation path when adding to PATH.

\tReturns:
\t\tbool: True if the program is now ready to use, False otherwise.

\tExamples:
\t\t.. code-block:: python

\t\t\t> # Download waifu2x-ncnn-vulkan for the current platform
\t\t\t> urls = {
\t\t\t>     "Windows": "https://github.com/.../waifu2x-windows.zip",
\t\t\t>     "Linux": "https://github.com/.../waifu2x-ubuntu.zip",
\t\t\t> }
\t\t\t> success = download_executable(urls, "waifu2x-ncnn-vulkan")
\t\t\t> # User is prompted: "Program executable not found, would you like to download it? (Y/n)"
\t\t\t> # If yes, downloads and installs the program

\t\t\t> # Download FFmpeg with executables in bin/ subdirectory
\t\t\t> ffmpeg_urls = {
\t\t\t>     "Windows": "https://github.com/.../ffmpeg-win64.zip",
\t\t\t>     "Linux": "https://github.com/.../ffmpeg-linux64.tar.xz",
\t\t\t> }
\t\t\t> download_executable(ffmpeg_urls, "ffmpeg", append_to_path="bin")
\t\t\tTrue
\t'''
def check_executable(executable: str, executable_help_text: str, download_urls: dict[str, str], append_to_path: str = '') -> None:
    ''' Check if the executable exists, optionally download it if it doesn\'t.

\tThis function runs the executable with ``-h`` flag and checks if the help text matches.
\tIf the executable is not found or the help text doesn\'t match, it prompts the user
\tto download it automatically from the provided URLs.

\tArgs:
\t\texecutable            (str):             The path to the executable.
\t\texecutable_help_text  (str):             The help text to check for in the executable\'s output.
\t\tdownload_urls         (dict[str, str]):  The URLs to download the executable from.
\t\tappend_to_path        (str):             The path to append to the executable\'s path.
\t\t\t(ex: "bin" if executables are in the bin folder)

\tExamples:
\t\t.. code-block:: python

\t\t\t> from stouputils.installer import check_executable
\t\t\t>
\t\t\t> # Check if waifu2x-ncnn-vulkan is installed
\t\t\t> WAIFU2X_RELEASES = {
\t\t\t>     "Windows": "https://github.com/.../waifu2x-windows.zip",
\t\t\t>     "Linux": "https://github.com/.../waifu2x-ubuntu.zip",
\t\t\t> }
\t\t\t> check_executable(
\t\t\t>     "waifu2x-ncnn-vulkan",
\t\t\t>     "waifu2x-ncnn-vulkan",  # Text expected in help output
\t\t\t>     WAIFU2X_RELEASES
\t\t\t> )
\t\t\t> # If not found, user is prompted to download

\t\t\t> # Check FFmpeg (executables in bin/ subdirectory)
\t\t\t> FFMPEG_RELEASES = {
\t\t\t>     "Windows": "https://github.com/.../ffmpeg-win64.zip",
\t\t\t> }
\t\t\t> check_executable(
\t\t\t>     "ffmpeg",
\t\t\t>     "ffmpeg version",
\t\t\t>     FFMPEG_RELEASES,
\t\t\t>     append_to_path="bin"
\t\t\t> )
\t'''
