#!/usr/bin/env python3
"""
Neuron Engine v3.0 MCP Server 使用示例

演示两种使用方式:
1. 编程式集成 (Python代码调用)
2. stdio模式 (与Claude Desktop / AI Agent平台集成)
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import json
from neuron_engine.workflow import NeuronEngine
from neuron_engine.db import NeuronDB
from neuron_engine.mcp_server import NeuronMCPServer


def example_programmatic():
    """示例1: 编程式调用MCP Server"""
    print("=" * 60)
    print("示例1: 编程式调用MCP Server")
    print("=" * 60)

    engine = NeuronEngine(db=NeuronDB(":memory:"))
    server = NeuronMCPServer(engine)

    # 1. 初始化握手
    resp = server.handle_request({
        "jsonrpc": "2.0", "id": 1,
        "method": "initialize", "params": {}
    })
    print(f"  Protocol: {resp['result']['protocolVersion']}")
    print(f"  Server: {resp['result']['serverInfo']['name']} v{resp['result']['serverInfo']['version']}")

    # 2. 列出可用工具
    resp = server.handle_request({
        "jsonrpc": "2.0", "id": 2,
        "method": "tools/list", "params": {}
    })
    tools = resp["result"]["tools"]
    print(f"\n  Available tools ({len(tools)}):")
    for t in tools:
        print(f"    - {t['name']}: {t['description']}")

    # 3. 执行任务
    resp = server.handle_request({
        "jsonrpc": "2.0", "id": 3,
        "method": "tools/call",
        "params": {
            "name": "neuron_execute_task",
            "arguments": {"task_input": "分析这段文本的情感倾向", "priority": "5"}
        }
    })
    result_text = resp["result"]["content"][0]["text"]
    result_data = json.loads(result_text)
    print(f"\n  Task executed:")
    print(f"    trace_id: {result_data.get('trace_id', 'N/A')}")
    print(f"    status: {result_data.get('status', 'N/A')}")
    print(f"    steps: {result_data.get('steps_completed', 0)}/{result_data.get('steps_total', 10)}")

    # 4. 注册技能
    resp = server.handle_request({
        "jsonrpc": "2.0", "id": 4,
        "method": "tools/call",
        "params": {
            "name": "neuron_register_skill",
            "arguments": {
                "name": "sentiment_analyzer",
                "domain_tag": "NLP",
                "description": "情感分析技能"
            }
        }
    })
    skill_data = json.loads(resp["result"]["content"][0]["text"])
    print(f"\n  Skill registered: {skill_data.get('neuron_id', 'N/A')}")

    # 5. 查询治理状态
    resp = server.handle_request({
        "jsonrpc": "2.0", "id": 5,
        "method": "tools/call",
        "params": {"name": "neuron_governance_state", "arguments": {}}
    })
    gov_data = json.loads(resp["result"]["content"][0]["text"])
    print(f"\n  Governance state:")
    print(f"    mode: {gov_data.get('run_mode', 'N/A')}")
    gs = gov_data.get("global_state", {})
    print(f"    arousal: {gs.get('arousal', 0):.2f}")
    print(f"    attention: {gs.get('attention', 0):.2f}")

    # 6. 获取引擎统计
    resp = server.handle_request({
        "jsonrpc": "2.0", "id": 6,
        "method": "tools/call",
        "params": {"name": "neuron_stats", "arguments": {}}
    })
    stats_data = json.loads(resp["result"]["content"][0]["text"])
    print(f"\n  Engine stats:")
    print(f"    neurons: {stats_data.get('total_neurons', 0)}")
    print(f"    synapses: {stats_data.get('total_synapses', 0)}")
    print()


def example_custom_tool():
    """示例2: 注册自定义MCP工具"""
    print("=" * 60)
    print("示例2: 自定义MCP工具注册")
    print("=" * 60)

    engine = NeuronEngine()
    server = NeuronMCPServer(engine)

    # 注册自定义工具: 天气查询模拟
    def weather_handler(params):
        city = params.get("city", "北京")
        return json.dumps({
            "city": city,
            "temperature": 22,
            "condition": "晴",
            "humidity": 45,
        }, ensure_ascii=False)

    server.register_tool_simple(
        name="get_weather",
        description="查询城市天气信息",
        params={
            "city": "城市名称"
        },
        handler=weather_handler,
    )
    print("  Registered custom tool: get_weather")

    # 调用自定义工具
    resp = server.handle_request({
        "jsonrpc": "2.0", "id": 1,
        "method": "tools/call",
        "params": {
            "name": "get_weather",
            "arguments": {"city": "上海"}
        }
    })
    weather = json.loads(resp["result"]["content"][0]["text"])
    print(f"  Shanghai weather: {weather['temperature']}C, {weather['condition']}")
    print()


def example_claude_desktop_config():
    """示例3: Claude Desktop集成配置"""
    print("=" * 60)
    print("示例3: Claude Desktop MCP配置")
    print("=" * 60)

    config = {
        "mcpServers": {
            "neuron-engine": {
                "command": "python",
                "args": ["-m", "neuron_engine.mcp_server"],
                "cwd": "/path/to/neuron-engine",
                "env": {}
            }
        }
    }
    print("  claude_desktop_config.json:")
    print(json.dumps(config, indent=2, ensure_ascii=False))
    print("\n  使用步骤:")
    print("  1. pip install -e .")
    print("  2. 将上述配置添加到 Claude Desktop 配置文件")
    print("  3. 重启 Claude Desktop")
    print("  4. 在对话中即可使用 neuron_execute_task 等工具")
    print()


if __name__ == "__main__":
    example_programmatic()
    example_custom_tool()
    example_claude_desktop_config()
    print("All MCP examples completed!")
