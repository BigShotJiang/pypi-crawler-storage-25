#!/usr/bin/env python3
"""
Neuron Engine v3.0 基础使用示例
演示: 注册神经元 -> 连接突触 -> 信号传递 -> STDP学习 -> 记忆存储 -> 任务执行
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from neuron_engine.workflow import NeuronEngine
from neuron_engine.core.signal import Signal, SignalType, ModulationType
from neuron_engine.core.neuron import Neuron
from neuron_engine.core.synapse import Synapse
from neuron_engine.learning import STDPLearner, RPEEvaluator
from neuron_engine.memory import MemoryManager
from neuron_engine.db import NeuronDB
from neuron_engine.governance import GovernanceSystem


def example_basic():
    """示例1: 基础引擎使用"""
    print("=" * 60)
    print("示例1: 基础引擎 - 注册神经元与任务执行")
    print("=" * 60)

    engine = NeuronEngine()

    # 注册带执行器的技能
    def greet(neuron, **kwargs):
        name = kwargs.get("task_input", "World")
        return f"Hello, {name}!"

    nid = engine.register_neuron(
        neuron_type="skill",
        domain_tag="demo",
        executor=greet,
        description="问候技能"
    )
    print(f"  Registered neuron: {nid}")

    # 执行任务 (10步闭环)
    result = engine.execute_task("Neuron Engine")
    print(f"  Task result: {result}")

    # 查看状态
    status = engine.get_status()
    print(f"  Engine stats: {status}")
    print()


def example_signals():
    """示例2: 信号系统"""
    print("=" * 60)
    print("示例2: 三分类信号协议")
    print("=" * 60)

    # 兴奋信号
    exc = Signal(
        signal_type=SignalType.EXCITATION,
        source_neuron_id="N-01",
        target_neuron_id="N-02",
        intensity=0.8,
        priority=3
    )
    # 抑制信号
    inh = Signal(
        signal_type=SignalType.INHIBITION,
        source_neuron_id="N-02",
        target_neuron_id="N-03",
        intensity=0.4
    )
    # 调控信号 (多巴胺)
    mod = Signal(
        signal_type=SignalType.MODULATION,
        source_neuron_id="G1",
        target_neuron_id="N-01",
        modulation_type=ModulationType.DOPAMINE,
        intensity=0.6
    )

    print(f"  Excitation: type={exc.signal_type.value}, intensity={exc.intensity}")
    print(f"  Inhibition:  type={inh.signal_type.value}, intensity={inh.intensity}")
    print(f"  Modulation:  type={mod.modulation_type.value}, intensity={mod.intensity}")
    print()


def example_stdp():
    """示例3: STDP学习"""
    print("=" * 60)
    print("示例3: STDP脉冲时序可塑性")
    print("=" * 60)

    learner = STDPLearner()
    synapse = Synapse(source_neuron_id="N-01", target_neuron_id="N-02", weight=0.500)

    print(f"  Initial weight: {synapse.weight:.4f}")

    # pre-before-post (LTP - 增强)
    learner.update_single(synapse, delta_t=-100, learning_rate=1.0)
    print(f"  After LTP (dt=-100ms): {synapse.weight:.4f}")

    # post-before-pre (LTD - 减弱)
    learner.update_single(synapse, delta_t=200, learning_rate=1.0)
    print(f"  After LTD (dt=+200ms): {synapse.weight:.4f}")

    # RPE奖励评估
    evaluator = RPEEvaluator()
    quality = evaluator.evaluate_quality({
        "completeness": 0.9,
        "success_rate": 0.8,
        "latency_ms": 200,
        "user_feedback": 0.7,
    })
    rpe = evaluator.calc_rpe(quality, expected_value=0.5)
    print(f"  Quality: {quality:.3f}, RPE: {rpe:+.3f}")
    print()


def example_memory():
    """示例4: 记忆系统"""
    print("=" * 60)
    print("示例4: 四级层级记忆")
    print("=" * 60)

    mgr = MemoryManager()

    atom = mgr.store("Python是动态类型语言", domain_tag="编程", keywords=["Python", "动态类型"])
    print(f"  Stored atom: {atom.atom_id}, grade={atom.grade}")

    # 多次访问
    for _ in range(5):
        atom.access()
    print(f"  After 5 accesses: count={atom.access_count}")

    # 搜索
    results = mgr.search(domain_tag="编程", keyword="Python")
    print(f"  Search 'Python': found {len(results)} atoms")

    stats = mgr.get_stats()
    print(f"  Memory stats: {stats}")
    print()


def example_governance():
    """示例5: 全局调控系统"""
    print("=" * 60)
    print("示例5: 全局调控 + 人格 + 情绪")
    print("=" * 60)

    gov = GovernanceSystem()

    # 调节四维状态
    gov.global_state.update(arousal=0.8, learning_mode=0.7)
    gov.infer_mode()
    print(f"  Run mode: {gov.run_mode}")

    # 三维协同向量
    synergy = gov.calc_synergy_vector()
    print(f"  Synergy vector: {synergy}")

    # 人格特征
    p = gov.personality
    print(f"  Personality: O={p.openness:.2f} C={p.conscientiousness:.2f} "
          f"E={p.extraversion:.2f} A={p.agreeableness:.2f} N={p.neuroticism:.2f}")

    # 情绪状态
    e = gov.emotion
    print(f"  Emotion: valence={e.valence:.2f} arousal={e.arousal:.2f} "
          f"dominance={e.dominance:.2f} primary={e.primary_emotion}")
    print()


def example_with_db():
    """示例6: 数据库持久化"""
    print("=" * 60)
    print("示例6: SQLite数据库持久化")
    print("=" * 60)

    db = NeuronDB(":memory:")
    engine = NeuronEngine(db=db)

    # 注册并持久化
    nid = engine.register_neuron(neuron_type="skill", domain_tag="NLP", description="文本分析")
    n2 = engine.register_neuron(neuron_type="skill", domain_tag="NLP", description="情感分析")
    engine.connect(nid, n2, weight=0.7)

    # 查询数据库统计
    stats = db.get_stats()
    print(f"  DB Stats: {stats}")

    # 搜索神经元
    neurons = db.list_neurons(domain_tag="NLP")
    print(f"  NLP neurons: {len(neurons)}")

    db.close()
    print()


if __name__ == "__main__":
    example_basic()
    example_signals()
    example_stdp()
    example_memory()
    example_governance()
    example_with_db()
    print("All examples completed!")
