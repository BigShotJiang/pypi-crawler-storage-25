"""
信号总线 — 白皮书第6章
全局信号路由与广播，支持兴奋/抑制/调控三分类分发
"""

import time
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Callable, Any
from enum import Enum

from neuron_engine.core.signal import Signal, SignalType, ModulationType


class DeliveryStatus(str, Enum):
    PENDING = "pending"
    DELIVERED = "delivered"
    FILTERED = "filtered"
    EXPIRED = "expired"
    FAILED = "failed"


@dataclass
class SignalTrace:
    """信号追踪记录"""
    trace_id: str
    signal_id: str
    source_neuron_id: str
    target_neuron_id: str
    signal_type: SignalType
    delivery_status: DeliveryStatus
    delivered_at: Optional[float] = None
    filter_reason: Optional[str] = None

    def to_dict(self):
        return {
            "trace_id": self.trace_id,
            "signal_id": self.signal_id,
            "source_neuron_id": self.source_neuron_id,
            "target_neuron_id": self.target_neuron_id,
            "signal_type": self.signal_type.value,
            "delivery_status": self.delivery_status.value,
            "delivered_at": self.delivered_at,
            "filter_reason": self.filter_reason,
        }


class SignalBus:
    """
    信号总线 (白皮书6.2节)
    
    职责:
    1. 信号注册与广播路由
    2. 三分类分发: 兴奋→膜电位/抑制→膜电位/调控→旁路
    3. 信号追踪与日志
    4. 信号TTL过期管理
    """
    
    def __init__(self, max_traces: int = 1000, default_ttl_ms: int = 5000):
        self._subscribers: Dict[str, List[Callable]] = {}
        self._modulation_handlers: Dict[str, Callable] = {}
        self._traces: List[SignalTrace] = []
        self._max_traces = max_traces
        self._default_ttl_ms = default_ttl_ms
        self._stats = {
            "total_sent": 0,
            "total_delivered": 0,
            "total_filtered": 0,
            "total_expired": 0,
        }

    def subscribe(self, neuron_id: str, handler: Callable[[Signal], Any]):
        """注册神经元信号处理器"""
        if neuron_id not in self._subscribers:
            self._subscribers[neuron_id] = []
        self._subscribers[neuron_id].append(handler)

    def subscribe_modulation(self, handler: Callable[[Signal], Any]):
        """注册调控信号全局处理器 (旁路)"""
        handler_id = str(uuid.uuid4())[:8]
        self._modulation_handlers[handler_id] = handler
        return handler_id

    def unsubscribe_modulation(self, handler_id: str):
        self._modulation_handlers.pop(handler_id, None)

    def emit(self, signal: Signal) -> List[SignalTrace]:
        """
        发射信号到目标神经元
        
        三分类路由:
        - excitation/inhibition: 投递到目标神经元
        - modulation: 仅投递到调控旁路处理器
        """
        self._stats["total_sent"] += 1
        traces = []

        # TTL检查
        if signal.create_time:
            age_ms = (time.time() - signal.create_time) * 1000
            if age_ms > self._default_ttl_ms:
                trace = SignalTrace(
                    trace_id=str(uuid.uuid4())[:12],
                    signal_id=signal.signal_id,
                    source_neuron_id=signal.source_neuron_id,
                    target_neuron_id=signal.target_neuron_id or "N/A",
                    signal_type=signal.signal_type,
                    delivery_status=DeliveryStatus.EXPIRED,
                )
                traces.append(trace)
                self._traces.append(trace)
                self._stats["total_expired"] += 1
                self._trim_traces()
                return traces

        # 调控信号走旁路
        if signal.signal_type == SignalType.MODULATION:
            for handler_id, handler in self._modulation_handlers.items():
                try:
                    handler(signal)
                except Exception:
                    pass
            trace = SignalTrace(
                trace_id=str(uuid.uuid4())[:12],
                signal_id=signal.signal_id,
                source_neuron_id=signal.source_neuron_id,
                target_neuron_id=signal.target_neuron_id or "modulation_bus",
                signal_type=signal.signal_type,
                delivery_status=DeliveryStatus.DELIVERED,
                delivered_at=time.time(),
            )
            traces.append(trace)
            self._traces.append(trace)
            self._stats["total_delivered"] += 1
            self._trim_traces()
            return traces

        # 兴奋/抑制信号投递到目标
        target = signal.target_neuron_id
        if target and target in self._subscribers:
            for handler in self._subscribers[target]:
                try:
                    handler(signal)
                except Exception:
                    pass
            trace = SignalTrace(
                trace_id=str(uuid.uuid4())[:12],
                signal_id=signal.signal_id,
                source_neuron_id=signal.source_neuron_id,
                target_neuron_id=target,
                signal_type=signal.signal_type,
                delivery_status=DeliveryStatus.DELIVERED,
                delivered_at=time.time(),
            )
            self._stats["total_delivered"] += 1
        else:
            trace = SignalTrace(
                trace_id=str(uuid.uuid4())[:12],
                signal_id=signal.signal_id,
                source_neuron_id=signal.source_neuron_id,
                target_neuron_id=target or "unknown",
                signal_type=signal.signal_type,
                delivery_status=DeliveryStatus.FILTERED,
                filter_reason="no_subscriber",
            )
            self._stats["total_filtered"] += 1

        traces.append(trace)
        self._traces.append(trace)
        self._trim_traces()
        return traces

    def broadcast(self, signal: Signal, exclude_source: bool = True) -> List[SignalTrace]:
        """广播信号到所有订阅者"""
        all_traces = []
        targets = list(self._subscribers.keys())
        if exclude_source:
            targets = [t for t in targets if t != signal.source_neuron_id]
        
        for target in targets:
            sig = Signal(
                source_neuron_id=signal.source_neuron_id,
                target_neuron_id=target,
                signal_type=signal.signal_type,
                intensity=signal.intensity,
                priority=signal.priority,
                create_time=signal.create_time,
            )
            all_traces.extend(self.emit(sig))
        return all_traces

    def get_traces(self, neuron_id: Optional[str] = None, 
                   limit: int = 50) -> List[Dict]:
        """查询信号追踪记录"""
        traces = self._traces
        if neuron_id:
            traces = [t for t in traces 
                      if t.source_neuron_id == neuron_id or t.target_neuron_id == neuron_id]
        return [t.to_dict() for t in traces[-limit:]]

    def get_stats(self) -> Dict:
        return dict(self._stats)

    def clear_traces(self):
        self._traces.clear()

    def _trim_traces(self):
        if len(self._traces) > self._max_traces:
            self._traces = self._traces[-self._max_traces:]
