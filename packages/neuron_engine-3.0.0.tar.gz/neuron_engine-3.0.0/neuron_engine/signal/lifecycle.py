"""
信号生命周期管理 — 白皮书第6章 6.3节
信号创建→传输→处理→归档 的完整生命周期
"""

import time
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from enum import Enum

from neuron_engine.core.signal import Signal, SignalType


class LifecyclePhase(str, Enum):
    CREATED = "created"
    QUEUED = "queued"
    TRANSMITTING = "transmitting"
    DELIVERED = "delivered"
    PROCESSED = "processed"
    ARCHIVED = "archived"
    EXPIRED = "expired"
    FAILED = "failed"


@dataclass
class LifecycleRecord:
    """信号生命周期记录"""
    signal_id: str
    phase: LifecyclePhase
    timestamp: float
    metadata: Dict = field(default_factory=dict)

    def to_dict(self):
        return {
            "signal_id": self.signal_id,
            "phase": self.phase.value,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }


class SignalLifecycle:
    """
    信号生命周期管理器 (白皮书6.3节)
    
    管理信号从创建到归档的完整阶段:
    CREATED → QUEUED → TRANSMITTING → DELIVERED → PROCESSED → ARCHIVED
    
    异常路径:
    - 任何阶段 → EXPIRED (TTL超时)
    - 任何阶段 → FAILED (处理异常)
    """
    
    def __init__(self, default_ttl_ms: int = 5000, max_records: int = 5000):
        self.default_ttl_ms = default_ttl_ms
        self.max_records = max_records
        # 活跃信号: {signal_id: {records, created_at, current_phase}}
        self._active: Dict[str, Dict] = {}
        # 归档记录
        self._archive: List[Dict] = []
        # 统计
        self._stats = {
            "total_created": 0,
            "total_completed": 0,
            "total_expired": 0,
            "total_failed": 0,
            "avg_lifetime_ms": 0.0,
        }

    def create(self, signal: Signal) -> str:
        """注册信号生命周期"""
        now = time.time()
        record = LifecycleRecord(
            signal_id=signal.signal_id,
            phase=LifecyclePhase.CREATED,
            timestamp=now,
            metadata={"source": signal.source_neuron_id, "target": signal.target_neuron_id,
                      "type": signal.signal_type.value},
        )
        self._active[signal.signal_id] = {
            "records": [record],
            "created_at": now,
            "current_phase": LifecyclePhase.CREATED,
        }
        self._stats["total_created"] += 1
        return signal.signal_id

    def advance(self, signal_id: str, phase: LifecyclePhase,
                metadata: Optional[Dict] = None) -> bool:
        """推进信号到下一阶段"""
        if signal_id not in self._active:
            return False
        
        entry = self._active[signal_id]
        now = time.time()
        
        record = LifecycleRecord(
            signal_id=signal_id,
            phase=phase,
            timestamp=now,
            metadata=metadata or {},
        )
        entry["records"].append(record)
        entry["current_phase"] = phase
        
        # 终态处理
        if phase in (LifecyclePhase.ARCHIVED, LifecyclePhase.EXPIRED, LifecyclePhase.FAILED):
            self._finalize(signal_id)
            if phase == LifecyclePhase.ARCHIVED:
                self._stats["total_completed"] += 1
            elif phase == LifecyclePhase.EXPIRED:
                self._stats["total_expired"] += 1
            elif phase == LifecyclePhase.FAILED:
                self._stats["total_failed"] += 1
        
        return True

    def get_phase(self, signal_id: str) -> Optional[LifecyclePhase]:
        """获取信号当前阶段"""
        entry = self._active.get(signal_id)
        if entry:
            return entry["current_phase"]
        return None

    def get_history(self, signal_id: str) -> List[Dict]:
        """获取信号生命周期历史"""
        entry = self._active.get(signal_id)
        if entry:
            return [r.to_dict() for r in entry["records"]]
        # 检查归档
        for archived in self._archive:
            if archived.get("signal_id") == signal_id:
                return archived.get("records", [])
        return []

    def check_ttl(self) -> List[str]:
        """检查并标记超时信号"""
        now = time.time()
        expired = []
        ttl_sec = self.default_ttl_ms / 1000.0
        
        for sid, entry in list(self._active.items()):
            if entry["current_phase"] in (LifecyclePhase.ARCHIVED, 
                                          LifecyclePhase.EXPIRED, 
                                          LifecyclePhase.FAILED):
                continue
            age = now - entry["created_at"]
            if age > ttl_sec:
                self.advance(sid, LifecyclePhase.EXPIRED, 
                           {"reason": "ttl_expired", "age_ms": age * 1000})
                expired.append(sid)
        
        return expired

    def get_active_count(self) -> int:
        """当前活跃信号数"""
        return len([e for e in self._active.values() 
                    if e["current_phase"] not in (
                        LifecyclePhase.ARCHIVED, LifecyclePhase.EXPIRED, LifecyclePhase.FAILED)])

    def get_stats(self) -> Dict:
        stats = dict(self._stats)
        stats["active_signals"] = self.get_active_count()
        stats["archived_records"] = len(self._archive)
        return stats

    def _finalize(self, signal_id: str):
        """归档终态信号"""
        entry = self._active.pop(signal_id, None)
        if not entry:
            return
        now = time.time()
        lifetime = (now - entry["created_at"]) * 1000
        
        # 更新平均生命周期
        completed = self._stats["total_completed"] + self._stats["total_expired"] + self._stats["total_failed"]
        if completed > 0:
            self._stats["avg_lifetime_ms"] = (
                (self._stats["avg_lifetime_ms"] * (completed - 1) + lifetime) / completed
            )
        
        # 归档
        archive_entry = {
            "signal_id": signal_id,
            "records": [r.to_dict() for r in entry["records"]],
            "final_phase": entry["current_phase"].value,
            "lifetime_ms": round(lifetime, 2),
        }
        self._archive.append(archive_entry)
        
        # 限制归档大小
        if len(self._archive) > self.max_records:
            self._archive = self._archive[-self.max_records:]
