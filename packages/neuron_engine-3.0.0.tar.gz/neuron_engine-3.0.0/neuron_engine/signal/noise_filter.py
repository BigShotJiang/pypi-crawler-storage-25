"""
噪声过滤器 — 白皮书第6章 6.4节
多层噪声过滤: 频率限制 · 强度衰减 · 异常检测
"""

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from enum import Enum

from neuron_engine.core.signal import Signal, SignalType


class FilterAction(str, Enum):
    PASS = "pass"
    ATTENUATE = "attenuate"
    BLOCK = "block"


@dataclass
class FilterResult:
    """过滤结果"""
    action: FilterAction
    original_intensity: float
    filtered_intensity: float
    reason: str
    filter_type: str

    def to_dict(self):
        return {
            "action": self.action.value,
            "original_intensity": round(self.original_intensity, 4),
            "filtered_intensity": round(self.filtered_intensity, 4),
            "reason": self.reason,
            "filter_type": self.filter_type,
        }


class NoiseFilter:
    """
    噪声过滤器 (白皮书6.4节)
    
    三层过滤机制:
    1. 频率过滤: 限制单位时间信号频率
    2. 强度过滤: 削减过低/过高强度信号
    3. 异常过滤: 检测信号风暴和死锁模式
    """
    
    def __init__(self,
                 max_freq_per_second: float = 100.0,
                 min_intensity: float = 0.05,
                 max_intensity: float = 1.0,
                 storm_threshold: int = 50,
                 storm_window_ms: int = 1000,
                 attenuation_factor: float = 0.5):
        self.max_freq = max_freq_per_second
        self.min_intensity = min_intensity
        self.max_intensity = max_intensity
        self.storm_threshold = storm_threshold
        self.storm_window_ms = storm_window_ms
        self.attenuation_factor = attenuation_factor
        
        # 频率追踪: {source_id: [timestamp, ...]}
        self._freq_tracker: Dict[str, List[float]] = {}
        # 全局信号时间线
        self._global_timeline: List[float] = []
        # 统计
        self._stats = {
            "total_filtered": 0,
            "total_passed": 0,
            "total_attenuated": 0,
            "storms_detected": 0,
        }

    def filter(self, signal: Signal) -> FilterResult:
        """
        对信号执行三层噪声过滤
        返回过滤结果，不修改原始信号
        """
        now = time.time()
        original = signal.intensity
        filtered = original
        action = FilterAction.PASS
        reasons = []

        # 第1层: 频率过滤
        freq_result = self._check_frequency(signal.source_neuron_id, now)
        if freq_result[0] == FilterAction.BLOCK:
            action = FilterAction.BLOCK
            filtered = 0.0
            reasons.append(freq_result[1])
            self._stats["total_filtered"] += 1
            self._record_global(now)
            return FilterResult(
                action=action, original_intensity=original,
                filtered_intensity=filtered, reason="; ".join(reasons),
                filter_type="frequency"
            )

        # 第2层: 强度过滤
        if filtered < self.min_intensity:
            action = FilterAction.ATTENUATE
            filtered = self.min_intensity * self.attenuation_factor
            reasons.append(f"below_min({self.min_intensity})")
            self._stats["total_attenuated"] += 1
        elif filtered > self.max_intensity:
            action = FilterAction.ATTENUATE
            filtered = self.max_intensity
            reasons.append(f"above_max({self.max_intensity})")
            self._stats["total_attenuated"] += 1

        # 第3层: 异常过滤 (信号风暴检测)
        if self._detect_storm(now):
            # 风暴模式下大幅衰减
            if action == FilterAction.PASS:
                action = FilterAction.ATTENUATE
            filtered *= 0.3
            reasons.append("storm_attenuation")
            self._stats["storms_detected"] += 1

        if action == FilterAction.PASS:
            self._stats["total_passed"] += 1

        self._record_global(now)
        return FilterResult(
            action=action, original_intensity=original,
            filtered_intensity=filtered, reason="; ".join(reasons) or "ok",
            filter_type="multi_layer"
        )

    def _check_frequency(self, source_id: str, now: float) -> Tuple[FilterAction, str]:
        """检查信号频率是否超限"""
        if source_id not in self._freq_tracker:
            self._freq_tracker[source_id] = []
        
        timeline = self._freq_tracker[source_id]
        # 清理旧记录
        cutoff = now - 1.0  # 1秒窗口
        self._freq_tracker[source_id] = [t for t in timeline if t > cutoff]
        timeline = self._freq_tracker[source_id]
        
        if len(timeline) >= int(self.max_freq):
            return (FilterAction.BLOCK, f"freq_limit({len(timeline)}/{int(self.max_freq)}ps)")
        
        timeline.append(now)
        return (FilterAction.PASS, "ok")

    def _detect_storm(self, now: float) -> bool:
        """检测信号风暴"""
        cutoff = now - (self.storm_window_ms / 1000.0)
        self._global_timeline = [t for t in self._global_timeline if t > cutoff]
        return len(self._global_timeline) >= self.storm_threshold

    def _record_global(self, now: float):
        self._global_timeline.append(now)
        # 限制全局时间线长度
        if len(self._global_timeline) > 10000:
            self._global_timeline = self._global_timeline[-5000:]

    def get_stats(self) -> Dict:
        return dict(self._stats)

    def get_source_freq(self, source_id: str) -> float:
        """获取指定源的当前信号频率"""
        now = time.time()
        timeline = self._freq_tracker.get(source_id, [])
        cutoff = now - 1.0
        recent = [t for t in timeline if t > cutoff]
        return len(recent)

    def is_storm_mode(self) -> bool:
        """当前是否处于风暴模式"""
        return self._detect_storm(time.time())
