"""
学习机制 (白皮书第7章7.3+7.5)
STDP脉冲时序依赖可塑性 · 多巴胺RPE奖励预测误差
"""

import math
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any

from neuron_engine.core.synapse import Synapse
from neuron_engine.core.neuron import Neuron
from neuron_engine.config import NeuronConfig


@dataclass
class STDPResult:
    """STDP调整结果"""
    synapse_key: str
    delta_t: int
    delta_w: float
    old_weight: float
    new_weight: float
    direction: str  # "LTP" 或 "LTD" 或 "HEBBIAN"

    def to_dict(self):
        return {
            "synapse": self.synapse_key,
            "delta_t_ms": self.delta_t,
            "delta_w": round(self.delta_w, 6),
            "weight_change": f"{self.old_weight:.3f} → {self.new_weight:.3f}",
            "direction": self.direction,
        }


class STDPLearner:
    """
    STDP脉冲时序依赖可塑性 (白皮书7.3节)
    
    基于Bi & Poo (1998)生物参数:
      A+ = 0.08 (LTP最大增量)
      A- = 0.04 (LTD最大减量)
      τ+ = 10000ms (LTP时间常数)
      τ- = 15000ms (LTD时间常数)
      
    不对称特性: 增强比减弱更容易 (符合生物特性)
    """

    DEFAULT_PARAMS = {
        "a_plus": 0.08,
        "a_minus": 0.04,
        "tau_plus": 10000,
        "tau_minus": 15000,
        "stdp_window_ms": 30000,
    }

    def __init__(self, config: Optional[NeuronConfig] = None):
        self.config = config
        self._results: List[STDPResult] = []

    def _get_params(self) -> Dict[str, float]:
        """获取STDP参数 (可从配置覆盖)"""
        params = dict(self.DEFAULT_PARAMS)
        if self.config:
            if self.config.get("stdp_biological_params"):
                pass  # 使用默认生物参数
            params["a_plus"] = self.config.get("stdp_a_plus")
            params["a_minus"] = self.config.get("stdp_a_minus")
            params["tau_plus"] = self.config.get("stdp_tau_plus")
            params["tau_minus"] = self.config.get("stdp_tau_minus")
        return params

    def update_synapse(self, synapse: Synapse, pre_fire_ts: int,
                       post_fire_ts: int) -> STDPResult:
        """
        对单个突触执行STDP权重调整
        
        Args:
            synapse: 突触连接
            pre_fire_ts: 前神经元放电时间戳(ms)
            post_fire_ts: 后神经元放电时间戳(ms)
        
        Returns:
            STDP调整结果
        """
        delta_t = pre_fire_ts - post_fire_ts
        params = self._get_params()
        old_weight = synapse.synapse_weight

        if abs(delta_t) > params["stdp_window_ms"]:
            # 超出窗口: 退回简单赫布规则
            delta_w = 0.05
            synapse.adjust_weight(delta_w)
            direction = "HEBBIAN"
        elif delta_t > 0:
            # LTP: 因果关联 (前神经元先放电)
            delta_w = params["a_plus"] * math.exp(-delta_t / params["tau_plus"])
            synapse.adjust_weight(delta_w)
            direction = "LTP"
        else:
            # LTD: 反向因果
            delta_w = -params["a_minus"] * math.exp(delta_t / params["tau_minus"])
            synapse.adjust_weight(delta_w)
            direction = "LTD"

        result = STDPResult(
            synapse_key=f"{synapse.source_neuron_id}→{synapse.target_neuron_id}",
            delta_t=delta_t, delta_w=delta_w,
            old_weight=old_weight, new_weight=synapse.synapse_weight,
            direction=direction,
        )
        self._results.append(result)
        return result

    def batch_update(self, fire_times: Dict[str, int],
                     synapses: List[Synapse]) -> List[STDPResult]:
        """
        批量STDP更新 (公理五: 异步隔离)
        
        Args:
            fire_times: {neuron_id: fire_timestamp_ms}
            synapses: 需要更新的突触列表
        """
        results = []
        for synapse in synapses:
            pre_ts = fire_times.get(synapse.source_neuron_id)
            post_ts = fire_times.get(synapse.target_neuron_id)
            if pre_ts is not None and post_ts is not None:
                result = self.update_synapse(synapse, pre_ts, post_ts)
                results.append(result)
        return results

    def get_results(self) -> List[Dict]:
        return [r.to_dict() for r in self._results]

    def clear_results(self):
        self._results.clear()

    def update_single(self, synapse, delta_t: int, learning_rate: float = 1.0):
        """
        兼容旧API: 单个突触STDP更新
        
        delta_t 语义: 与Bi&Poo 1998一致
          delta_t < 0 (pre-before-post) => LTP增强
          delta_t > 0 (post-before-pre) => LTD减弱
          delta_t = 0 (同时激发) => 轻微LTP
        """
        # 构造 pre/post 时间戳使得 update_synapse 内部 delta_t = pre_ts - post_ts = delta_t
        # update_synapse: delta_t > 0 => LTP, delta_t < 0 => LTD
        # 外部约定: delta_t < 0 => LTP (pre先), delta_t > 0 => LTD (post先)
        # 语义翻转: 传入 -delta_t 给 update_synapse
        pre_ts = 1000
        post_ts = 1000 + delta_t  # delta_t<0 => post_ts<1000 => pre后 => update_synapse中delta_t>0 => LTP
        result = self.update_synapse(synapse, pre_ts, post_ts)
        if learning_rate != 1.0:
            extra = (learning_rate - 1.0) * result.delta_w
            synapse.adjust_weight(extra)
        return result

    def update_batch(self, updates):
        """兼容旧API: 批量更新 [(synapse, delta_t, learning_rate), ...]"""
        results = []
        for synapse, delta_t, lr in updates:
            result = self.update_single(synapse, delta_t, lr)
            results.append(result)
        return results

    @property
    def A_plus(self) -> float:
        return self.DEFAULT_PARAMS["a_plus"]

    @property
    def A_minus(self) -> float:
        return self.DEFAULT_PARAMS["a_minus"]

    @property
    def tau_plus(self) -> int:
        return self.DEFAULT_PARAMS["tau_plus"]

    @property
    def tau_minus(self) -> int:
        return self.DEFAULT_PARAMS["tau_minus"]


@dataclass
class RPEResult:
    """RPE奖励评估结果"""
    trace_id: str
    actual_reward: float
    expected_reward: float
    rpe: float
    dopamine_type: str  # "reward" / "punish" / "none"
    intensity: float
    affected_neurons: List[str]

    def to_dict(self):
        return {
            "trace_id": self.trace_id,
            "actual_reward": round(self.actual_reward, 3),
            "expected_reward": round(self.expected_reward, 3),
            "rpe": round(self.rpe, 3),
            "dopamine_type": self.dopamine_type,
            "intensity": round(self.intensity, 3),
            "affected_neurons": len(self.affected_neurons),
        }


class RPEEvaluator:
    """
    多巴胺奖励预测误差 (白皮书7.5节)
    
    RPE = actual_reward - expected_reward  ∈ [-1, 1]
    |RPE| < 0.1: 符合预期，不调整
    """

    QUALITY_WEIGHTS = {
        "completeness": 0.4,
        "success_rate": 0.3,
        "latency_score": 0.2,
        "user_feedback": 0.1,
    }

    def compute_task_quality(self, task_result: Dict[str, Any]) -> float:
        """
        任务质量评估 (白皮书7.5)
        quality = 0.4*完整性 + 0.3*成功率 + 0.2*延迟得分 + 0.1*用户反馈
        """
        completeness = task_result.get("completed_steps", 0) / max(1, task_result.get("total_steps", 1))
        success_rate = task_result.get("skill_success_rate", 0.5)
        latency_score = 1.0 - min(1.0, task_result.get("latency_ms", 0) / max(1, task_result.get("timeout_ms", 30000)))
        user_feedback = task_result.get("user_rating", 0.5)

        quality = (self.QUALITY_WEIGHTS["completeness"] * completeness +
                   self.QUALITY_WEIGHTS["success_rate"] * success_rate +
                   self.QUALITY_WEIGHTS["latency_score"] * latency_score +
                   self.QUALITY_WEIGHTS["user_feedback"] * user_feedback)
        return max(0.0, min(1.0, quality))

    def evaluate(self, trace_id: str, task_result: Dict[str, Any],
                 expected_reward: float = 0.5,
                 affected_neurons: Optional[List[str]] = None) -> RPEResult:
        """
        执行RPE奖励评估 (公理七)
        """
        actual_reward = self.compute_task_quality(task_result)
        rpe = actual_reward - expected_reward

        if rpe > 0.1:
            dopamine_type = "dopamine_reward"
            intensity = min(1.0, rpe)
        elif rpe < -0.1:
            dopamine_type = "dopamine_punish"
            intensity = min(1.0, abs(rpe))
        else:
            dopamine_type = "none"
            intensity = 0.0

        return RPEResult(
            trace_id=trace_id,
            actual_reward=actual_reward,
            expected_reward=expected_reward,
            rpe=rpe,
            dopamine_type=dopamine_type,
            intensity=intensity,
            affected_neurons=affected_neurons or [],
        )



    def evaluate_quality(self, metrics: Dict[str, Any]) -> float:
        """兼容旧API: 质量评估 (支持metrics键名)"""
        completeness = metrics.get("completeness", 0.5)
        success_rate = metrics.get("success_rate", 0.5)
        latency_score = 1.0 - min(1.0, metrics.get("latency_ms", 0) / max(1, metrics.get("timeout_ms", 30000)))
        user_feedback = metrics.get("user_feedback", 0.5)
        
        quality = (self.QUALITY_WEIGHTS["completeness"] * completeness +
                   self.QUALITY_WEIGHTS["success_rate"] * success_rate +
                   self.QUALITY_WEIGHTS["latency_score"] * latency_score +
                   self.QUALITY_WEIGHTS["user_feedback"] * user_feedback)
        return max(0.0, min(1.0, quality))

    def calc_rpe(self, quality_score: float = None, expected_value: float = 0.5,
                 task_result: Dict[str, Any] = None) -> float:
        """兼容旧API: 计算RPE值"""
        if quality_score is not None:
            actual = quality_score
        elif task_result is not None:
            actual = self.compute_task_quality(task_result)
        else:
            actual = 0.5
        return actual - expected_value

    def rpe_to_dopamine(self, rpe: float) -> float:
        """RPE映射到多巴胺水平 [0, 1]"""
        return max(0.0, min(1.0, 0.5 + rpe * 0.5))

    @property
    def w_completeness(self) -> float:
        return self.QUALITY_WEIGHTS["completeness"]

    @property
    def w_success(self) -> float:
        return self.QUALITY_WEIGHTS["success_rate"]

    @property
    def w_latency(self) -> float:
        return self.QUALITY_WEIGHTS["latency_score"]

    @property
    def w_feedback(self) -> float:
        return self.QUALITY_WEIGHTS["user_feedback"]

