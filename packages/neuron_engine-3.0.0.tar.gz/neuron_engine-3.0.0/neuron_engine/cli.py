"""
Neuron Engine v3.0 CLI 命令行工具

子命令:
  neuron-engine serve       启动REST API服务器
  neuron-engine mcp         启动MCP Server (stdio)
  neuron-engine run         执行单次任务
  neuron-engine stats       查看引擎统计
  neuron-engine test        运行测试套件
  neuron-engine version     版本信息

示例:
  neuron-engine serve --port 8100 --db neurons.db
  neuron-engine mcp
  neuron-engine run "分析这段文本" --priority 5
  neuron-engine stats --db neurons.db
  neuron-engine test
"""

from __future__ import annotations

import argparse
import json
import sys
import os


def cmd_serve(args):
    """启动REST API服务器"""
    try:
        from neuron_engine.api import NeuronAPIServer
        from neuron_engine.db import NeuronDB
        from neuron_engine.workflow import NeuronEngine
        from neuron_engine.logging import setup_logging
    except ImportError as e:
        print(f"错误: 缺少依赖 - {e}", file=sys.stderr)
        sys.exit(1)

    import logging
    setup_logging(level=logging.INFO)

    db_path = args.db or ":memory:"
    db = NeuronDB(db_path)
    engine = NeuronEngine(db=db)

    print(f"Neuron Engine v{get_version()} REST API Server", file=sys.stderr)
    print(f"  Host: {args.host}", file=sys.stderr)
    print(f"  Port: {args.port}", file=sys.stderr)
    print(f"  DB: {db_path}", file=sys.stderr)
    print(f"  PID: {os.getpid()}", file=sys.stderr)

    server = NeuronAPIServer(engine, db, host=args.host, port=args.port)
    server.start()


def cmd_mcp(args):
    """启动MCP Server (stdio传输)"""
    from neuron_engine.mcp_server import NeuronMCPServer
    from neuron_engine.db import NeuronDB
    from neuron_engine.workflow import NeuronEngine

    engine = NeuronEngine(db=NeuronDB(":memory:"))
    server = NeuronMCPServer(engine)
    server.run_stdio()


def cmd_run(args):
    """执行单次任务"""
    from neuron_engine.workflow import NeuronEngine
    from neuron_engine.db import NeuronDB
    from neuron_engine.logging import setup_logging

    import logging
    setup_logging(level=logging.WARNING)

    db = NeuronDB(args.db) if args.db else None
    engine = NeuronEngine(db=db)

    if not args.task:
        print("错误: 请指定任务内容 (neuron-engine run \"任务内容\")", file=sys.stderr)
        sys.exit(1)

    result = engine.execute_task(args.task, priority=args.priority)
    d = result.to_dict()
    d["version"] = get_version()

    if args.json:
        print(json.dumps(d, ensure_ascii=False, default=str, indent=2))
    else:
        print(f"Neuron Engine v{get_version()}")
        print(f"  Trace: {d['trace_id']}")
        print(f"  Status: {d['status']}")
        print(f"  Steps: {d['steps_completed']}/10")
        print(f"  Latency: {d['latency_ms']}ms")
        if d.get("output"):
            if isinstance(d["output"], dict):
                print(f"  Output: {json.dumps(d['output'], ensure_ascii=False)}")
            else:
                print(f"  Output: {d['output']}")


def cmd_stats(args):
    """查看引擎统计"""
    from neuron_engine.workflow import NeuronEngine
    from neuron_engine.db import NeuronDB

    db = NeuronDB(args.db) if args.db else None
    engine = NeuronEngine(db=db)

    status = engine.get_status()
    status["version"] = get_version()

    print(json.dumps(status, ensure_ascii=False, default=str, indent=2))


def cmd_test(args):
    """运行测试套件"""
    import subprocess

    cmd = [sys.executable, "-m", "pytest", "tests/", "-v", "--tb=short"]
    if args.coverage:
        cmd.extend(["--cov=neuron_engine", "--cov-report=term-missing"])

    # 切换到包根目录
    pkg_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    result = subprocess.run(cmd, cwd=pkg_dir)
    sys.exit(result.returncode)


def cmd_version(args):
    """版本信息"""
    v = get_version()
    print(f"neuron-engine {v}")
    print(f"Python {sys.version.split()[0]}")


def get_version() -> str:
    try:
        from neuron_engine import __version__
        return __version__
    except ImportError:
        return "unknown"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="neuron-engine",
        description="类脑神经元全域智能体引擎 v3.0 — CLI命令行工具",
    )
    parser.add_argument("-V", "--version", action="store_true",
                        help="显示版本信息")

    sub = parser.add_subparsers(dest="command", help="可用子命令")

    # serve
    p_serve = sub.add_parser("serve", help="启动REST API服务器")
    p_serve.add_argument("--host", default="0.0.0.0", help="监听地址 (默认: 0.0.0.0)")
    p_serve.add_argument("--port", type=int, default=8100, help="监听端口 (默认: 8100)")
    p_serve.add_argument("--db", default=None, help="SQLite数据库路径 (默认: 内存)")

    # mcp
    p_mcp = sub.add_parser("mcp", help="启动MCP Server (stdio传输)")

    # run
    p_run = sub.add_parser("run", help="执行单次任务")
    p_run.add_argument("task", nargs="?", help="任务内容")
    p_run.add_argument("--priority", type=int, default=0, help="优先级 0-10 (默认: 0)")
    p_run.add_argument("--db", default=None, help="SQLite数据库路径")
    p_run.add_argument("--json", action="store_true", help="JSON格式输出")

    # stats
    p_stats = sub.add_parser("stats", help="查看引擎统计")
    p_stats.add_argument("--db", default=None, help="SQLite数据库路径")

    # test
    p_test = sub.add_parser("test", help="运行测试套件")
    p_test.add_argument("--coverage", action="store_true", help="生成覆盖率报告")

    # version
    p_ver = sub.add_parser("version", help="版本信息")

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    if args.version:
        cmd_version(args)
        return

    if not args.command:
        parser.print_help()
        return

    commands = {
        "serve": cmd_serve,
        "mcp": cmd_mcp,
        "run": cmd_run,
        "stats": cmd_stats,
        "test": cmd_test,
        "version": cmd_version,
    }

    handler = commands.get(args.command)
    if handler:
        handler(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
