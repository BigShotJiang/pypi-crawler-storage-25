"""
统一错误码规范 (白皮书第23章)
支持5级错误分级: 致命级/阻断级/可恢复级/警告级/信息级
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, Dict, Any


class ErrorSeverity(Enum):
    """错误严重程度"""
    FATAL = "fatal"          # 致命级: 终止当前任务
    BLOCKING = "blocking"    # 阻断级: 阻断当前信号
    RECOVERABLE = "recoverable"  # 可恢复级: 重试
    WARNING = "warning"      # 警告级: 记录日志
    INFO = "info"            # 信息级: 后续审查


class ErrorCategory(Enum):
    """错误分类 (前缀)"""
    NEURON = "N"       # 神经元错误
    SIGNAL = "S"       # 信号错误
    SYNAPSE = "W"      # 突触错误
    MEMORY = "M"       # 记忆错误
    CONSENSUS = "C"    # 共识错误
    ANOMALY = "A"      # 异常错误
    SKILL = "SK"       # 技能错误
    MEMORY_ATOM = "MA"  # 原子记忆错误
    SYNERGY = "SY"     # 协同错误


@dataclass
class NeuronError(Exception):
    """类脑神经元引擎统一异常"""
    code: str
    message: str
    category: ErrorCategory = ErrorCategory.NEURON
    severity: ErrorSeverity = ErrorSeverity.BLOCKING
    detail: Optional[str] = None
    context: Dict[str, Any] = field(default_factory=dict)

    def __str__(self):
        return f"[{self.code}] {self.category.value}0000 | {self.severity.value}: {self.message}"


# ============================================================
# 错误码常量 (白皮书第23章完整定义)
# ============================================================

# N0001 - 神经元不存在
class NeuronNotFoundError(NeuronError):
    def __init__(self, neuron_id: str):
        super().__init__(
            code="N0001", message="神经元不存在",
            category=ErrorCategory.NEURON, severity=ErrorSeverity.FATAL,
            detail=f"neuron_id={neuron_id}", context={"neuron_id": neuron_id}
        )

# N0002 - 神经元状态非法
class NeuronStateError(NeuronError):
    def __init__(self, neuron_id: str, current: str, expected: str):
        super().__init__(
            code="N0002", message="神经元状态非法",
            category=ErrorCategory.NEURON, severity=ErrorSeverity.FATAL,
            detail=f"neuron_id={neuron_id}, current={current}, expected={expected}"
        )

# N0003 - 熔断打开拒绝激活
class CircuitBreakerOpenError(NeuronError):
    def __init__(self, neuron_id: str, remaining_ms: int):
        super().__init__(
            code="N0003", message="熔断打开，拒绝激活",
            category=ErrorCategory.NEURON, severity=ErrorSeverity.BLOCKING,
            detail=f"neuron_id={neuron_id}, remaining={remaining_ms}ms"
        )

# S0001 - 信号超时
class SignalTimeoutError(NeuronError):
    def __init__(self, signal_id: str):
        super().__init__(
            code="S0001", message="信号超时",
            category=ErrorCategory.SIGNAL, severity=ErrorSeverity.RECOVERABLE,
            detail=f"signal_id={signal_id}"
        )

# S0002 - 信号被丢弃
class SignalDroppedError(NeuronError):
    def __init__(self, signal_id: str, reason: str = "目标处于熔断打开态"):
        super().__init__(
            code="S0002", message="信号被丢弃",
            category=ErrorCategory.SIGNAL, severity=ErrorSeverity.RECOVERABLE,
            detail=f"signal_id={signal_id}, reason={reason}"
        )

# S0003 - 信号类型非法
class SignalTypeError(NeuronError):
    def __init__(self, signal_type: str):
        super().__init__(
            code="S0003", message="信号类型非法",
            category=ErrorCategory.SIGNAL, severity=ErrorSeverity.BLOCKING,
            detail=f"非三分类信号类型: {signal_type}"
        )

# S0004 - 噪声信号被过滤
class SignalFilteredError(NeuronError):
    def __init__(self, signal_id: str, filter_type: str):
        super().__init__(
            code="S0004", message="噪声信号被过滤",
            category=ErrorCategory.SIGNAL, severity=ErrorSeverity.RECOVERABLE,
            detail=f"signal_id={signal_id}, filter={filter_type}"
        )

# W0001 - 突触不存在
class SynapseNotFoundError(NeuronError):
    def __init__(self, source_id: str, target_id: str):
        super().__init__(
            code="W0001", message="突触不存在",
            category=ErrorCategory.SYNAPSE, severity=ErrorSeverity.BLOCKING,
            detail=f"source={source_id} → target={target_id}"
        )

# W0002 - 权重越界拒绝
class WeightOutOfBoundsError(NeuronError):
    def __init__(self, weight: float):
        super().__init__(
            code="W0002", message="权重越界拒绝",
            category=ErrorCategory.SYNAPSE, severity=ErrorSeverity.WARNING,
            detail=f"权重 {weight:.3f} 不在 [0.100, 0.900] 区间"
        )

# M0001 - 工作记忆溢出
class WorkingMemoryOverflowError(NeuronError):
    def __init__(self, capacity: int):
        super().__init__(
            code="M0001", message="工作记忆溢出",
            category=ErrorCategory.MEMORY, severity=ErrorSeverity.BLOCKING,
            detail=f"超过容量上限({capacity})"
        )

# M0002 - 巩固失败
class MemoryConsolidationError(NeuronError):
    def __init__(self, reason: str = "情景→程序记忆转化条件不满足"):
        super().__init__(
            code="M0002", message="巩固失败",
            category=ErrorCategory.MEMORY, severity=ErrorSeverity.WARNING,
            detail=reason
        )

# C0001 - 同步冲突
class ConsensusConflictError(NeuronError):
    def __init__(self, neuron_id: str, versions: tuple):
        super().__init__(
            code="C0001", message="同步冲突",
            category=ErrorCategory.CONSENSUS, severity=ErrorSeverity.FATAL,
            detail=f"neuron_id={neuron_id}, versions={versions}"
        )

# C0002 - 配置依赖不满足
class ConfigDependencyError(NeuronError):
    def __init__(self, config_key: str, missing_deps: list):
        super().__init__(
            code="C0002", message="配置依赖不满足",
            category=ErrorCategory.CONSENSUS, severity=ErrorSeverity.INFO,
            detail=f"启用 {config_key} 需要先启用: {missing_deps}"
        )

# C0003 - 配置热加载失败
class ConfigHotReloadError(NeuronError):
    def __init__(self, keys: list, reason: str):
        super().__init__(
            code="C0003", message="配置热加载失败",
            category=ErrorCategory.CONSENSUS, severity=ErrorSeverity.INFO,
            detail=f"keys={keys}, reason={reason}"
        )

# A0001 - 异常检测触发
class AnomalyDetectedError(NeuronError):
    def __init__(self, anomaly_type: str, metrics: dict):
        super().__init__(
            code="A0001", message="异常检测触发",
            category=ErrorCategory.ANOMALY, severity=ErrorSeverity.BLOCKING,
            detail=f"type={anomaly_type}, metrics={metrics}"
        )

# A0002 - 自愈失败
class SelfHealFailedError(NeuronError):
    def __init__(self, reason: str):
        super().__init__(
            code="A0002", message="自愈失败",
            category=ErrorCategory.ANOMALY, severity=ErrorSeverity.BLOCKING,
            detail=reason
        )

# SK0001 - 技能状态非法
class SkillStateError(NeuronError):
    def __init__(self, skill_id: str, current: str, target: str):
        super().__init__(
            code="SK0001", message="技能状态非法",
            category=ErrorCategory.SKILL, severity=ErrorSeverity.WARNING,
            detail=f"skill={skill_id}, {current}→{target}"
        )

# SK0002 - 技能激活超时
class SkillTimeoutError(NeuronError):
    def __init__(self, skill_id: str, timeout_ms: int):
        super().__init__(
            code="SK0002", message="技能激活超时",
            category=ErrorCategory.SKILL, severity=ErrorSeverity.RECOVERABLE,
            detail=f"skill={skill_id}, timeout={timeout_ms}ms"
        )

# SK0003 - 模板匹配冲突
class SkillTemplateConflictError(NeuronError):
    def __init__(self, skill_id: str, matched_templates: list):
        super().__init__(
            code="SK0003", message="模板匹配冲突",
            category=ErrorCategory.SKILL, severity=ErrorSeverity.WARNING,
            detail=f"skill={skill_id}, matched={matched_templates}"
        )

# MA0001 - 原子节点不存在
class MemoryAtomNotFoundError(NeuronError):
    def __init__(self, atom_id: str):
        super().__init__(
            code="MA0001", message="原子节点不存在",
            category=ErrorCategory.MEMORY_ATOM, severity=ErrorSeverity.WARNING,
            detail=f"atom_id={atom_id}"
        )

# MA0002 - 晋升条件不满足
class MemoryPromotionError(NeuronError):
    def __init__(self, atom_id: str, reason: str):
        super().__init__(
            code="MA0002", message="晋升条件不满足",
            category=ErrorCategory.MEMORY_ATOM, severity=ErrorSeverity.WARNING,
            detail=f"atom_id={atom_id}, {reason}"
        )

# MA0003 - 双向连通创建失败
class MemoryAtomLinkError(NeuronError):
    def __init__(self, atom_id: str, reason: str):
        super().__init__(
            code="MA0003", message="双向连通创建失败",
            category=ErrorCategory.MEMORY_ATOM, severity=ErrorSeverity.INFO,
            detail=f"atom_id={atom_id}, {reason}"
        )

# SY0001 - 三维协同失衡
class SynergyImbalanceError(NeuronError):
    def __init__(self, deviation: float):
        super().__init__(
            code="SY0001", message="三维协同失衡",
            category=ErrorCategory.SYNERGY, severity=ErrorSeverity.INFO,
            detail=f"协同向量偏差={deviation:.3f} (阈值0.5)"
        )
