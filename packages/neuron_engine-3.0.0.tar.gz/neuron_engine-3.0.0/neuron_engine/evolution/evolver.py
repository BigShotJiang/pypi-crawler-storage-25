"""
自演化引擎 — 白皮书第21章
基于RPE反馈的技能权重自动调整、突触拓扑优化、规则进化
"""

import time
import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum

from neuron_engine.core.synapse import Synapse
from neuron_engine.core.neuron import Neuron
from neuron_engine.learning import STDPLearner, RPEEvaluator


class SkillPhase(str, Enum):
    """技能生命周期阶段 (白皮书第14章扩展)"""
    DRAFT = "draft"
    ACTIVE = "active"
    OPTIMIZING = "optimizing"
    MATURE = "mature"
    DEPRECATED = "deprecated"
    RETIRED = "retired"


class EvolutionTrigger(str, Enum):
    RPE_POSITIVE = "rpe_positive"
    RPE_NEGATIVE = "rpe_negative"
    STORM_DETECTED = "storm_detected"
    DEADLOCK_DETECTED = "deadlock_detected"
    PERIODIC = "periodic"


@dataclass
class EvolutionRecord:
    """演化记录"""
    record_id: str
    trigger: EvolutionTrigger
    action: str
    target_id: str
    description: str
    timestamp: float
    metadata: Dict = field(default_factory=dict)

    def to_dict(self):
        return {
            "record_id": self.record_id,
            "trigger": self.trigger.value,
            "action": self.action,
            "target_id": self.target_id,
            "description": self.description,
            "timestamp": self.timestamp,
        }


class Evolver:
    """
    自演化引擎 (白皮书第21章)
    
    公理五: 自适应泄漏与自愈
    公理八: 自适应泄漏因子
    
    演化策略:
    1. RPE正向 → 强化成功通路 (STDP LTP放大)
    2. RPE负向 → 弱化失败通路 (STDP LTD放大)
    3. 异常触发 → 调控参数自调节
    4. 周期性 → 技能生命周期推进
    """
    
    def __init__(self, stdp_learner: Optional[STDPLearner] = None,
                 rpe_evaluator: Optional[RPEEvaluator] = None,
                 evolution_rate: float = 0.1,
                 min_synapses_per_neuron: int = 1,
                 max_synapses_per_neuron: int = 20):
        self.stdp = stdp_learner or STDPLearner()
        self.rpe = rpe_evaluator or RPEEvaluator()
        self.evolution_rate = evolution_rate
        self.min_synapses = min_synapses_per_neuron
        self.max_synapses = max_synapses_per_neuron
        
        self._records: List[EvolutionRecord] = []
        self._skill_phases: Dict[str, SkillPhase] = {}
        self._usage_counts: Dict[str, int] = {}
        self._success_counts: Dict[str, int] = {}
        self._stats = {
            "total_evolutions": 0,
            "reinforcements": 0,
            "prunings": 0,
            "phase_transitions": 0,
            "parameter_adjustments": 0,
        }

    def evolve_on_rpe(self, neuron_id: str, rpe_value: float,
                      synapses: Optional[List[Synapse]] = None):
        """
        基于RPE奖励信号执行演化
        
        RPE > 0: 正向强化 — 增强相关突触
        RPE < 0: 负向调节 — 弱化相关突触
        """
        now = time.time()
        
        if rpe_value > 0.1:
            # 正向强化: 放大STDP学习率
            lr = 1.0 + abs(rpe_value) * self.evolution_rate
            if synapses:
                for syn in synapses:
                    if syn.target_neuron_id == neuron_id:
                        old_w = syn.synapse_weight
                        delta_w = lr * 0.02  # 小幅增强
                        syn.adjust_weight(delta_w)
                        if syn.synapse_weight > old_w:
                            self._stats["reinforcements"] += 1
            
            self._add_record(EvolutionTrigger.RPE_POSITIVE, "reinforce",
                           neuron_id, f"RPE={rpe_value:.3f}, lr={lr:.3f}", now)
        
        elif rpe_value < -0.1:
            # 负向调节: 小幅衰减
            if synapses:
                for syn in synapses:
                    if syn.target_neuron_id == neuron_id:
                        old_w = syn.synapse_weight
                        delta_w = -abs(rpe_value) * self.evolution_rate * 0.01
                        syn.adjust_weight(delta_w)
                        if syn.synapse_weight < old_w:
                            self._stats["prunings"] += 1
            
            self._add_record(EvolutionTrigger.RPE_NEGATIVE, "attenuate",
                           neuron_id, f"RPE={rpe_value:.3f}", now)
        
        self._stats["total_evolutions"] += 1

    def evolve_on_anomaly(self, trigger: EvolutionTrigger, target_id: str,
                          metadata: Optional[Dict] = None):
        """异常触发演化"""
        now = time.time()
        action = "parameter_adjust"
        
        if trigger == EvolutionTrigger.STORM_DETECTED:
            action = "increase_noise_filter"
        elif trigger == EvolutionTrigger.DEADLOCK_DETECTED:
            action = "reset_membrane"
        
        self._add_record(trigger, action, target_id,
                        metadata.get("description", action) if metadata else action, now)
        self._stats["total_evolutions"] += 1
        self._stats["parameter_adjustments"] += 1

    def advance_skill_lifecycle(self, skill_id: str) -> Optional[SkillPhase]:
        """
        推进技能生命周期 (白皮书第14章扩展)
        
        DRAFT → ACTIVE → OPTIMIZING → MATURE → DEPRECATED → RETIRED
        推进条件基于使用频率和成功率
        """
        current = self._skill_phases.get(skill_id, SkillPhase.DRAFT)
        usage = self._usage_counts.get(skill_id, 0)
        success = self._success_counts.get(skill_id, 0)
        success_rate = success / max(1, usage)
        
        next_phase = current
        transition_rule = ""
        
        if current == SkillPhase.DRAFT and usage >= 5:
            next_phase = SkillPhase.ACTIVE
            transition_rule = f"usage={usage}>=5"
        elif current == SkillPhase.ACTIVE and usage >= 50 and success_rate > 0.8:
            next_phase = SkillPhase.OPTIMIZING
            transition_rule = f"usage={usage}>=50, rate={success_rate:.2f}"
        elif current == SkillPhase.OPTIMIZING and usage >= 200 and success_rate > 0.9:
            next_phase = SkillPhase.MATURE
            transition_rule = f"usage={usage}>=200, rate={success_rate:.2f}"
        elif current == SkillPhase.MATURE and success_rate < 0.5 and usage > 10:
            next_phase = SkillPhase.DEPRECATED
            transition_rule = f"rate={success_rate:.2f}<0.5"
        elif current == SkillPhase.DEPRECATED and usage == 0:
            next_phase = SkillPhase.RETIRED
            transition_rule = "no_usage"
        
        if next_phase != current:
            self._skill_phases[skill_id] = next_phase
            self._stats["phase_transitions"] += 1
            self._add_record(EvolutionTrigger.PERIODIC, "phase_transition",
                           skill_id, f"{current.value} -> {next_phase.value} ({transition_rule})",
                           time.time())
        
        return next_phase

    def record_usage(self, skill_id: str, success: bool):
        """记录技能使用"""
        self._usage_counts[skill_id] = self._usage_counts.get(skill_id, 0) + 1
        if success:
            self._success_counts[skill_id] = self._success_counts.get(skill_id, 0) + 1

    def get_skill_phase(self, skill_id: str) -> SkillPhase:
        return self._skill_phases.get(skill_id, SkillPhase.DRAFT)

    def get_all_skill_phases(self) -> Dict[str, str]:
        return {k: v.value for k, v in self._skill_phases.items()}

    def get_records(self, limit: int = 50) -> List[Dict]:
        return [r.to_dict() for r in self._records[-limit:]]

    def get_stats(self) -> Dict:
        stats = dict(self._stats)
        stats["active_skills"] = len([p for p in self._skill_phases.values() 
                                       if p in (SkillPhase.ACTIVE, SkillPhase.OPTIMIZING)])
        stats["total_skills"] = len(self._skill_phases)
        return stats

    def _add_record(self, trigger, action, target_id, description, timestamp):
        self._records.append(EvolutionRecord(
            record_id=f"E-{int(timestamp * 1000) % 1000000:06d}",
            trigger=trigger, action=action,
            target_id=target_id, description=description,
            timestamp=timestamp,
        ))
        if len(self._records) > 500:
            self._records = self._records[-300:]
