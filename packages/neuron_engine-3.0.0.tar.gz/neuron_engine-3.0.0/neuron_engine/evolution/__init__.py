"""
自演化系统 (白皮书第21章)
自适应演化引擎 · 技能生命周期 · 规则自优化
"""
from neuron_engine.evolution.evolver import Evolver

__all__ = ["Evolver"]
