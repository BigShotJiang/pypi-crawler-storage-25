"""
python -m neuron_engine 入口
等价于: neuron-engine CLI
"""
from neuron_engine.cli import main

if __name__ == "__main__":
    main()
