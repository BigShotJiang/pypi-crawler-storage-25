"""
工作流引擎 (白皮书第11章 + 第12章)
10步标准闭环 · 信号总线 · 任务追踪
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Any, Callable
import uuid
import time

from neuron_engine.core.neuron import Neuron
from neuron_engine.core.synapse import Synapse
from neuron_engine.core.signal import Signal, SignalType
from neuron_engine.memory import MemoryManager
from neuron_engine.governance import GovernanceSystem
from neuron_engine.learning import STDPLearner, RPEEvaluator
from neuron_engine.config import NeuronConfig


@dataclass
class TaskResult:
    """任务执行结果"""
    trace_id: str
    status: str = "success"  # "success" / "error" / "degraded"
    output: Any = None
    steps_completed: int = 0
    steps_total: int = 0
    signals_created: int = 0
    neurons_activated: int = 0
    latency_ms: int = 0
    fire_times: Dict[str, int] = field(default_factory=dict)
    rpe_result: Optional[Dict] = None
    stdp_results: List[Dict] = field(default_factory=list)

    def __contains__(self, key):
        return hasattr(self, key)

    def __getitem__(self, key):
        return getattr(self, key)

    def to_dict(self):
        return {
            "trace_id": self.trace_id,
            "status": self.status,
            "output": self.output,
            "steps_completed": self.steps_completed,
            "signals_created": self.signals_created,
            "neurons_activated": self.neurons_activated,
            "latency_ms": self.latency_ms,
            "rpe": self.rpe_result,
            "stdp_count": len(self.stdp_results),
        }


class NeuronEngine:
    """
    类脑神经元全域智能体引擎 (白皮书V2.7完整实现)
    
    五层神经圈层 · 三分类信号 · STDP · RPE · 层级记忆
    全局调控 · 人格情绪 · 异常自愈 · 10步闭环
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None, db=None):
        self.config = NeuronConfig(config)
        self.memory = MemoryManager()
        self.governance = GovernanceSystem()
        self.stdp_learner = STDPLearner(self.config)
        self.rpe_evaluator = RPEEvaluator()

        # 神经元注册表
        self._neurons: Dict[str, Neuron] = {}
        # 突触连接图
        self._synapses: Dict[str, Synapse] = {}  # "src→tgt" -> Synapse
        # 信号日志
        self._signal_log: List[Dict] = []

        # 五层神经元索引
        self._layers: Dict[str, List[str]] = {
            "perception": [], "cognition": [], "ability": [],
            "schedule": [], "decision": [], "evolution": [],
        }

        # 持久化后端
        self.db = db

    # ============================================================
    # 神经元注册
    # ============================================================

    def register_neuron(self, neuron=None, layer: str = "ability",
                        executor: Optional[Callable] = None, neuron_type: str = "skill",
                        domain_tag: str = "通用", **kwargs):
        """注册神经元到引擎 (支持两种调用方式)"""
        # 自动检测: neuron是字符串则视为neuron_type
        if isinstance(neuron, str):
            neuron_type = neuron
            neuron = None
        if neuron is None:
            neuron = Neuron(neuron_type=neuron_type, domain_tag=domain_tag, **kwargs)
        if executor is not None:
            neuron._executor = executor
        self._neurons[neuron.neuron_id] = neuron
        if layer in self._layers:
            self._layers[layer].append(neuron.neuron_id)
        # 持久化到DB
        if self.db is not None:
            try:
                self.db.insert_neuron(
                    neuron_id=neuron.neuron_id,
                    neuron_type=neuron.neuron_type,
                    domain_tag=neuron.domain_tag,
                    state=neuron.state,
                    base_threshold=neuron.base_threshold,
                    description=kwargs.get("description", ""),
                )
            except Exception:
                pass  # DB写入失败不影响内存注册
        return neuron.neuron_id

    def connect(self, source_id: str, target_id: str,
                weight: float = 0.5, is_feedback: bool = False,
                is_modulation: bool = False, is_bidirectional: bool = False,
                signal_type: str = None, **kwargs) -> Synapse:
        """建立突触连接"""
        key = f"{source_id}→{target_id}"
        synapse = Synapse(
            source_neuron_id=source_id, target_neuron_id=target_id,
            synapse_weight=weight, is_feedback=is_feedback,
            is_modulation=is_modulation, is_bidirectional=is_bidirectional,
        )
        self._synapses[key] = synapse
        # 持久化到DB
        if self.db is not None:
            try:
                self.db.insert_synapse(
                    source_id=source_id, target_id=target_id,
                    weight=weight,
                    signal_type="modulation" if is_modulation else ("inhibition" if is_feedback else "excitation"),
                )
            except Exception:
                pass  # DB写入失败不影响内存连接
        return key

    def get_neuron(self, neuron_id: str) -> Optional[Neuron]:
        return self._neurons.get(neuron_id)

    def get_synapse(self, source_id: str, target_id: str) -> Optional[Synapse]:
        return self._synapses.get(f"{source_id}→{target_id}")

    # ============================================================
    # 10步闭环工作流 (白皮书第11章)
    # ============================================================

    def execute_task(self, user_input: str, priority: int = 0) -> TaskResult:
        """
        执行完整10步闭环 (白皮书第12章)
        """
        trace_id = f"TRC-{uuid.uuid4().hex[:12]}"
        start_ms = int(time.time() * 1000)
        result = TaskResult(trace_id=trace_id, steps_total=10)
        fire_times: Dict[str, int] = {}

        try:
            # Step 0: Bootstrap
            init_signals = self._broadcast_init(priority, trace_id)
            result.signals_created += len(init_signals)

            # Step 1: 感知输入层
            perception_signals = self._run_perception(user_input, priority, trace_id)
            result.signals_created += len(perception_signals)

            # Step 2: 认知解析层
            cognition_signals = self._run_cognition(perception_signals, trace_id)
            result.signals_created += len(cognition_signals)

            # Step 3: 核心能力层 (三态熔断)
            active_skills = self._run_ability(cognition_signals, trace_id, fire_times)
            result.neurons_activated = len(active_skills)

            # Step 4: 全局调控
            if self.config.get("enable_global_state"):
                self.governance.adapt(system_load=len(active_skills)/max(1, len(self._layers["ability"])),
                                      idle_ms=0)

            # Step 5: 中枢调度
            execution_plan = active_skills  # 简化: 全部激活的技能

            # Step 6: 技能执行
            outputs = self._execute_skills(execution_plan, trace_id, fire_times)

            # Step 7: 决策融合
            final_output = self._decision_fusion(outputs)
            result.output = final_output
            result.steps_completed = 7

            # Step 8: 奖励评估 (RPE)
            if self.config.get("enable_rpe"):
                task_data = {
                    "completed_steps": 7, "total_steps": 10,
                    "skill_success_rate": sum(1 for o in outputs if o.get("status") == "success") / max(1, len(outputs)),
                    "latency_ms": int(time.time() * 1000) - start_ms,
                    "timeout_ms": 30000,
                }
                rpe = self.rpe_evaluator.evaluate(trace_id, task_data,
                                                  affected_neurons=list(fire_times.keys()))
                result.rpe_result = rpe.to_dict()

            # Step 9: 异步演化 (STDP)
            if self.config.get("enable_stdp") and fire_times:
                active_synapses = [s for s in self._synapses.values()
                                   if s.source_neuron_id in fire_times or
                                   s.target_neuron_id in fire_times]
                stdp_results = self.stdp_learner.batch_update(fire_times, active_synapses)
                result.stdp_results = [r.to_dict() for r in stdp_results]

            result.status = "success"

        except Exception as e:
            result.status = "error"
            result.output = {"error": str(e)}

        result.latency_ms = int(time.time() * 1000) - start_ms
        result.fire_times = fire_times
        return result

    # ============================================================
    # 层级处理方法
    # ============================================================

    def _broadcast_init(self, priority: int, trace_id: str) -> List[Signal]:
        """Step 0: Bootstrap"""
        signals = []
        for nid in self._layers["perception"]:
            sig = Signal.create_excitation("system", nid, intensity=0.5,
                                           priority=priority, trace_id=trace_id)
            signals.append(sig)
            self._log_signal(sig)
        return signals

    def _run_perception(self, user_input: str, priority: int, trace_id: str) -> List[Signal]:
        """Step 1: 感知输入层"""
        signals = []
        for nid in self._layers["perception"]:
            neuron = self._neurons.get(nid)
            if not neuron:
                continue
            neuron.apply_leak()
            # 简化: 将输入作为兴奋信号
            neuron.membrane_potential = min(1.0, 0.3 + len(user_input) / 500.0)
            if neuron.check_fire():
                for target_id in self._layers["cognition"]:
                    sig = Signal.create_excitation(nid, target_id,
                                                   intensity=neuron.membrane_potential,
                                                   priority=priority, trace_id=trace_id,
                                                   context_payload={"input": user_input})
                    signals.append(sig)
                    self._log_signal(sig)
        return signals

    def _run_cognition(self, signals: List[Signal], trace_id: str) -> List[Signal]:
        """Step 2: 认知解析层"""
        cognition_signals = []
        for nid in self._layers["cognition"]:
            neuron = self._neurons.get(nid)
            if not neuron:
                continue
            neuron.calc_membrane_potential(signals, priority=0)
            if neuron.check_fire():
                for target_id in self._layers["ability"]:
                    sig = Signal.create_excitation(nid, target_id,
                                                   intensity=neuron.membrane_potential,
                                                   trace_id=trace_id)
                    cognition_signals.append(sig)
                    self._log_signal(sig)
        return cognition_signals

    def _run_ability(self, signals: List[Signal], trace_id: str,
                     fire_times: Dict[str, int]) -> List[Neuron]:
        """Step 3: 核心能力层 (三态熔断)"""
        active = []
        for nid in self._layers["ability"]:
            neuron = self._neurons.get(nid)
            if not neuron:
                continue
            neuron.calc_membrane_potential(signals)
            if neuron.check_fire():
                fire_times[nid] = int(time.time() * 1000)
                active.append(neuron)
        return active

    def _execute_skills(self, skills: List[Neuron], trace_id: str,
                        fire_times: Dict[str, int]) -> List[Dict]:
        """Step 6: 技能协同执行"""
        results = []
        for skill in skills:
            exec_result = skill.execute(trace_id=trace_id)
            results.append(exec_result)
            # 将执行结果写入工作记忆
            if self.config.get("enable_memory_consolidation"):
                self.memory.create_atom(
                    content=str(exec_result.get("result", "")),
                    domain_tag=skill.domain_tag,
                    source_neuron_id=skill.neuron_id,
                    trace_id=trace_id,
                )
        return results

    def _decision_fusion(self, outputs: List[Dict]) -> Any:
        """Step 7: 决策融合"""
        if not outputs:
            return {"status": "no_output", "message": "无有效输出，降级为最简通路"}
        successes = [o for o in outputs if o.get("status") == "success"]
        if successes:
            return {"status": "success", "results": [s.get("result") for s in successes],
                    "count": len(successes)}
        return {"status": "degraded", "results": outputs}

    # ============================================================
    # 辅助方法
    # ============================================================

    def _log_signal(self, signal: Signal):
        self._signal_log.append(signal.to_dict())

    def get_status(self) -> Dict[str, Any]:
        """获取引擎完整状态"""
        neurons_by_state = {}
        for n in self._neurons.values():
            neurons_by_state[n.state] = neurons_by_state.get(n.state, 0) + 1

        status = {
            "version": "3.0.0",
            "total_neurons": len(self._neurons),
            "total_synapses": len(self._synapses),
            "total_signals": len(self._signal_log),
            "neurons_by_state": neurons_by_state,
        }
        
        try:
            status["memory"] = self.memory.get_stats()
        except Exception:
            pass
        try:
            gov_status = self.governance.get_full_status()
            if gov_status:
                status["governance"] = gov_status
        except Exception:
            pass
        try:
            status["config"] = self.config.to_dict()
        except Exception:
            pass
        
        return status
