"""
核心模型：信号 (Signal) — 白皮书第6章
三分类信号协议: excitation / inhibition / modulation
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional, Dict, Any
import uuid
import time


class SignalType(Enum):
    """三分类信号类型 (公理一)"""
    EXCITATION = "excitation"    # 兴奋信号
    INHIBITION = "inhibition"    # 抑制信号
    MODULATION = "modulation"    # 调控信号 (V2.3新增第三类)


class ModulationType(Enum):
    """调控信号子类型 (白皮书7.4节)"""
    DOPAMINE = "dopamine"          # 多巴胺: 调节突触学习速率
    NOREPINEPHRINE = "norepinephrine"  # NE: 调节信号增益
    ACETYLCHOLINE = "acetylcholine"    # ACh: 调节阈值
    SEROTONIN = "serotonin"        # 5-HT: 调节抑制因子
    HISTAMINE = "histamine"        # 组胺: 全局觉醒度


@dataclass
class Signal:
    """
    神经信号载体 (白皮书第6章)
    三分类: 兴奋(excitation) / 抑制(inhibition) / 调控(modulation)
    """
    signal_type: SignalType
    source_neuron_id: str
    target_neuron_id: str
    intensity: float = 0.5
    priority: int = 0
    is_feedback: bool = False
    trace_id: Optional[str] = None
    modulation_type: Optional[ModulationType] = None
    context_payload: Optional[Dict[str, Any]] = None

    # 系统自动填充
    signal_id: str = field(default_factory=lambda: f"SIG-{uuid.uuid4().hex[:8]}")
    create_time: int = field(default_factory=lambda: int(time.time() * 1000))
    duration_ms: Optional[int] = None

    def __post_init__(self):
        """信号创建校验 (公理一)"""
        if not isinstance(self.signal_type, SignalType):
            raise ValueError(f"signal_type必须是SignalType枚举，得到: {type(self.signal_type)}")
        if self.signal_type == SignalType.MODULATION and self.modulation_type is None:
            raise ValueError("调控信号必须指定 modulation_type")
        if self.signal_type != SignalType.MODULATION and self.modulation_type is not None:
            self.modulation_type = None  # 非调控信号忽略调制类型
        # 强度范围约束
        self.intensity = max(0.0, min(1.0, self.intensity))
        # 自动生成trace_id
        if self.trace_id is None:
            self.trace_id = f"TRC-{uuid.uuid4().hex[:12]}"

    @property
    def is_excitation(self) -> bool:
        return self.signal_type == SignalType.EXCITATION

    @property
    def is_inhibition(self) -> bool:
        return self.signal_type == SignalType.INHIBITION

    @property
    def is_modulation(self) -> bool:
        return self.signal_type == SignalType.MODULATION

    def to_dict(self) -> Dict[str, Any]:
        return {
            "signal_id": self.signal_id,
            "signal_type": self.signal_type.value,
            "source_neuron_id": self.source_neuron_id,
            "target_neuron_id": self.target_neuron_id,
            "intensity": round(self.intensity, 3),
            "priority": self.priority,
            "is_feedback": self.is_feedback,
            "trace_id": self.trace_id,
            "modulation_type": self.modulation_type.value if self.modulation_type else None,
            "context_payload": self.context_payload,
            "create_time": self.create_time,
            "duration_ms": self.duration_ms,
        }

    @classmethod
    def create_excitation(cls, source: str, target: str, intensity: float = 0.5,
                          priority: int = 0, trace_id: str = None, **kwargs) -> "Signal":
        return cls(
            signal_type=SignalType.EXCITATION, source_neuron_id=source,
            target_neuron_id=target, intensity=intensity, priority=priority,
            trace_id=trace_id, **kwargs
        )

    @classmethod
    def create_inhibition(cls, source: str, target: str, intensity: float = 0.5,
                          priority: int = 0, trace_id: str = None, **kwargs) -> "Signal":
        return cls(
            signal_type=SignalType.INHIBITION, source_neuron_id=source,
            target_neuron_id=target, intensity=intensity, priority=priority,
            trace_id=trace_id, **kwargs
        )

    @classmethod
    def create_modulation(cls, source: str, target: str, mod_type: ModulationType,
                          intensity: float = 0.5, trace_id: str = None, **kwargs) -> "Signal":
        return cls(
            signal_type=SignalType.MODULATION, source_neuron_id=source,
            target_neuron_id=target, intensity=intensity, modulation_type=mod_type,
            trace_id=trace_id, **kwargs
        )
