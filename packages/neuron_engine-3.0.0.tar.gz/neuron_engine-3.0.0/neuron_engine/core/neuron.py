"""
核心模型：神经元 (Neuron) — 白皮书第5章 + 第7章
LIF膜电位模型 · 三态熔断 · 点火放电
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional, Dict, Any, List, Callable
import uuid
import time
import math

from neuron_engine.core.signal import Signal, SignalType, ModulationType
from neuron_engine.exceptions import (
    NeuronNotFoundError, NeuronStateError, CircuitBreakerOpenError, WeightOutOfBoundsError
)


class NeuronState(Enum):
    """神经元状态"""
    SILENT = "静默"           # 未激活
    FIRING = "点火放电"       # 激活输出
    BREAKER_CLOSED = "熔断关闭"  # 正常
    BREAKER_OPEN = "熔断打开"    # 过载保护
    BREAKER_HALF_OPEN = "熔断半开"  # 探测恢复
    ACTIVE = "已激活"         # 已选中执行


class NeuronType(Enum):
    """五层圈层神经元类型 (白皮书第4章)"""
    PERCEPTION = "perception"    # 感知输入层
    COGNITION = "cognition"      # 认知解析层
    SKILL = "skill"              # 核心能力层-技能
    MEMORY_WORKING = "memory_working"   # 工作记忆
    MEMORY_EPISODIC = "memory_episodic" # 情景记忆
    MEMORY_PROCEDURAL = "memory_procedural"  # 程序记忆
    KNOWLEDGE = "knowledge"      # 知识神经元
    SCHEDULE = "schedule"        # 调度神经元
    RULE_MUTEX = "rule_mutex"    # 规则-互斥
    RULE_PRIORITY = "rule_priority"  # 规则-优先级
    RULE_LIMIT = "rule_limit"    # 规则-限流
    REWARD = "reward"            # 奖励评估
    DECISION = "decision"        # 决策融合
    EVOLUTION = "evolution"      # 自演化


# 常量
COOLDOWN_MS = 60000  # 熔断冷却期60秒 (白皮书7.2)
WEIGHT_MIN = 0.100   # 公理四: 权重区间下界
WEIGHT_MAX = 0.900   # 公理四: 权重区间上界


@dataclass
class Neuron:
    """
    神经元 (白皮书第5章 neuron_base)
    LIF膜电位模型 + 三态熔断 + 点火放电
    """
    neuron_id: str = field(default_factory=lambda: f"N-{uuid.uuid4().hex[:8]}")
    neuron_type: str = "skill"
    domain_tag: str = "通用"
    state: str = "静默"
    base_threshold: float = 0.600
    dynamic_threshold: float = 0.600
    membrane_potential: float = 0.000
    rest_potential: float = 0.000
    leak_factor: float = 0.950
    excitation_factor: float = 1.000
    inhibition_factor: float = 1.000
    learning_rate: float = 1.000
    signal_gain: float = 1.000
    modulated_threshold: Optional[float] = None
    awareness_level: float = 0.500
    memory_sub_type: Optional[str] = None
    is_consolidated: bool = False
    memory_capacity: Optional[int] = None
    memory_grade: str = "temp"
    keywords: Optional[list] = None
    related_ids: Optional[list] = None
    description: str = ""
    timeout_ms: int = 30000
    instance_id: str = "default"

    # 统计字段
    activate_times: int = 0
    success_count: int = 0
    total_execute_count: int = 0
    error_count: int = 0
    last_activate_ts: int = 0
    breaker_open_ts: int = 0

    # V2.5原子记忆关联
    task_pattern_hash: Optional[str] = None

    # 时间戳
    version: int = 1
    create_time: str = field(default_factory=lambda: datetime.now().isoformat())
    update_time: str = field(default_factory=lambda: datetime.now().isoformat())

    # 执行函数 (技能接入点)
    _executor: Optional[Callable] = field(default=None, repr=False)

    @property
    def effective_threshold(self) -> float:
        """有效阈值 (V2.3: ACh调控可修改)"""
        if self.modulated_threshold is not None:
            return self.modulated_threshold
        return self.dynamic_threshold

    @property
    def is_breaker_open(self) -> bool:
        """熔断是否打开"""
        return self.state == "熔断打开"

    @property
    def is_breaker_half_open(self) -> bool:
        """熔断是否半开"""
        return self.state == "熔断半开"

    def calc_membrane_potential(self, signals: List[Signal], priority: int = 0):
        """
        膜电位计算 (白皮书7.1节 LIF模型)
        离散近似: V(t+1) = λ * V(t) + (1 - λ) * I_syn(t)
        """
        potential_exc = 0.0
        potential_inh = 0.0

        for signal in signals:
            # 【公理一】调控信号走旁路，不进入膜电位计算
            if signal.is_modulation:
                self._apply_modulation(signal)
                continue

            weight = 0.5  # 默认权重，实际从synapse获取
            priority_boost = 1.0 + signal.priority * 0.2

            # 【V2.3】应用全局信号增益 (NE调控)
            weight *= self.signal_gain

            if signal.is_excitation:
                potential_exc += (signal.intensity * weight *
                                  self.excitation_factor * priority_boost)
            elif signal.is_inhibition:
                potential_inh += (signal.intensity * weight *
                                  self.inhibition_factor * priority_boost)

        i_syn = potential_exc - potential_inh

        # 泄漏衰减 (公理六: 泄漏衰减永恒)
        self.membrane_potential = (self.leak_factor * self.membrane_potential +
                                   (1 - self.leak_factor) * i_syn)

        # 约束: 膜电位不低于静息电位
        if self.membrane_potential < self.rest_potential:
            self.membrane_potential = self.rest_potential

    def check_fire(self) -> bool:
        """
        激活判定 + 三态熔断 (白皮书7.2节)
        公理二: 只有膜电位 ≥ 动态阈值才激活点火
        """
        now_ms = int(time.time() * 1000)

        # 三态熔断状态转换
        if self.state == "熔断关闭":
            if self.error_count >= 3:
                self.state = "熔断打开"
                self.breaker_open_ts = now_ms
                return False

        if self.state == "熔断打开":
            if now_ms - self.breaker_open_ts >= COOLDOWN_MS:
                self.state = "熔断半开"
            else:
                return False

        # 公理二: 激活条件唯一
        if self.membrane_potential >= self.effective_threshold:
            self.state = "点火放电"
            self.activate_times += 1
            self.last_activate_ts = now_ms
            return True
        else:
            self.state = "静默"
            return False

    def execute(self, **kwargs) -> Any:
        """
        技能执行 (白皮书Step 6)
        支持熔断半开探测模式
        """
        if self._executor is None:
            return {"status": "no_executor", "neuron_id": self.neuron_id}

        is_probe = (self.state == "熔断半开")
        start_ms = int(time.time() * 1000)

        try:
            result = self._executor(self, **kwargs)
            duration = int(time.time() * 1000) - start_ms

            self.error_count = 0
            self.success_count += 1
            self.total_execute_count += 1

            if is_probe:
                self.state = "熔断关闭"

            return {"status": "success", "result": result, "duration_ms": duration}
        except Exception as e:
            self.error_count += 1
            self.total_execute_count += 1

            if is_probe:
                self.state = "熔断打开"
                self.breaker_open_ts = int(time.time() * 1000)

            return {"status": "error", "error": str(e)}

    def _apply_modulation(self, signal: Signal):
        """
        调控信号旁路处理 (白皮书7.4节)
        调控信号不触发点火放电路径，仅调节参数
        """
        if signal.modulation_type is None:
            return

        intensity = signal.intensity

        match signal.modulation_type:
            case ModulationType.DOPAMINE:
                # 多巴胺: 调节突触学习速率
                self.learning_rate *= (1 + intensity * 0.5)
            case ModulationType.NOREPINEPHRINE:
                # NE: 调节信号增益
                self.signal_gain = 1.0 + intensity * 0.3
            case ModulationType.ACETYLCHOLINE:
                # ACh: 调节阈值 (降低=更容易激活=探索模式)
                self.modulated_threshold = self.dynamic_threshold * (1 - intensity * 0.2)
            case ModulationType.SEROTONIN:
                # 5-HT: 调节抑制因子 (降低=更大胆)
                self.inhibition_factor *= (1 - intensity * 0.3)
            case ModulationType.HISTAMINE:
                # 组胺: 全局觉醒度
                self.awareness_level = intensity

    def apply_leak(self):
        """
        泄漏衰减 (公理六)
        无新信号输入时，膜电位按泄漏因子自动衰减
        """
        self.membrane_potential = self.leak_factor * self.membrane_potential
        if self.membrane_potential < self.rest_potential:
            self.membrane_potential = self.rest_potential

    def reset_modulation(self):
        """重置调控参数 (信号周期结束后)"""
        self.signal_gain = 1.000
        self.inhibition_factor = 1.000
        self.learning_rate = 1.000
        self.modulated_threshold = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "neuron_id": self.neuron_id,
            "neuron_type": self.neuron_type,
            "domain_tag": self.domain_tag,
            "state": self.state,
            "membrane_potential": round(self.membrane_potential, 3),
            "effective_threshold": round(self.effective_threshold, 3),
            "base_threshold": self.base_threshold,
            "dynamic_threshold": round(self.dynamic_threshold, 3),
            "leak_factor": self.leak_factor,
            "activate_times": self.activate_times,
            "success_count": self.success_count,
            "error_count": self.error_count,
            "last_activate_ts": self.last_activate_ts,
            "version": self.version,
        }
