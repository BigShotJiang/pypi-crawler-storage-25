"""
核心模型：突触 (Synapse) — 白皮书第5章 + 第7章
权重区间锁定 [0.100, 0.900] (公理四) · STDP权重调整
"""

from datetime import datetime
from typing import Optional, Dict, Any
import uuid
import math

from neuron_engine.exceptions import WeightOutOfBoundsError


WEIGHT_MIN = 0.100
WEIGHT_MAX = 0.900


class Synapse:
    """
    突触连接 (白皮书第5章 neuron_synapse)
    神经元间有向连接，携带权重和信号类型
    """
    def __init__(self, source_neuron_id: str = "", target_neuron_id: str = "",
                 synapse_weight: float = 0.500, weight: float = None,
                 source_id: str = None, target_id: str = None,
                 relation_type: str = "双向",
                 is_feedback: bool = False,
                 is_modulation: bool = False,
                 is_cooperate: bool = False,
                 is_bidirectional: bool = False,
                 cooperate_score: float = 0.000,
                 last_stdp_delta_t: Optional[int] = None,
                 id: Optional[int] = None,
                 create_time: str = None,
                 update_time: str = None,
                 **kwargs):
        # 参数别名
        self.source_neuron_id = source_id if source_id is not None else source_neuron_id
        self.target_neuron_id = target_id if target_id is not None else target_neuron_id
        self.synapse_weight = weight if weight is not None else synapse_weight
        self.relation_type = relation_type
        self.is_feedback = is_feedback
        self.is_modulation = is_modulation
        self.is_cooperate = is_cooperate
        self.is_bidirectional = is_bidirectional
        self.cooperate_score = cooperate_score
        self.last_stdp_delta_t = last_stdp_delta_t
        self.id = id
        self.create_time = create_time or datetime.now().isoformat()
        self.update_time = update_time or datetime.now().isoformat()
        # 确保权重在合法范围
        self.synapse_weight = max(WEIGHT_MIN, min(WEIGHT_MAX, self.synapse_weight))

    @property
    def weight(self) -> float:
        return self.synapse_weight

    @weight.setter
    def weight(self, value: float):
        """公理四: 权重区间锁定 [0.100, 0.900]"""
        clamped = max(WEIGHT_MIN, min(WEIGHT_MAX, value))
        self.synapse_weight = clamped

    @property
    def source_id(self) -> str:
        """协议别名: source_neuron_id"""
        return self.source_neuron_id

    @property
    def target_id(self) -> str:
        """协议别名: target_neuron_id"""
        return self.target_neuron_id

    @property
    def synapse_id(self) -> str:
        """协议兼容: 返回ID"""
        return str(self.id) if self.id is not None else ""

    @property
    def last_fire_ts(self) -> int:
        """协议兼容: 返回最后STDP时间戳"""
        return self.last_stdp_delta_t if self.last_stdp_delta_t is not None else 0

    @property
    def signal_type(self) -> str:
        """协议兼容: 根据关系类型推断信号类型"""
        if self.is_modulation:
            return "modulation"
        if self.is_feedback:
            return "inhibition"
        return "excitation"

    def adjust_weight(self, delta: float) -> float:
        """
        调整突触权重 (带区间钳位)
        返回实际变化量
        """
        old_weight = self.synapse_weight
        self.weight = self.synapse_weight + delta
        return self.synapse_weight - old_weight

    def stdp_update(self, delta_t: int, learning_rate: float = 1.0,
                    a_plus: float = 0.08, a_minus: float = 0.04,
                    tau_plus: int = 10000, tau_minus: int = 15000,
                    stdp_window_ms: int = 30000):
        """
        STDP脉冲时序依赖可塑性 (白皮书7.3节)
        Delta_t = pre_fire_ts - post_fire_ts (毫秒)
        
        参数默认值来自Bi & Poo (1998):
          A+ = 0.08, A- = 0.04
          tau+ = 10000ms, tau- = 15000ms
        """
        if abs(delta_t) > stdp_window_ms:
            # 超出窗口，退回v2.1简单赫布规则
            delta_w = 0.05
            if learning_rate != 1.0:
                delta_w *= learning_rate
            self.last_stdp_delta_t = delta_t
            return self.adjust_weight(delta_w)

        if delta_t > 0:
            # 因果关联: 前神经元先放电 -> LTP (增强)
            delta_w = a_plus * math.exp(-delta_t / tau_plus)
        elif delta_t == 0:
            # 同时激发: 轻微LTP
            delta_w = a_plus * math.exp(0)  # = a_plus = 0.08
        else:
            # 反向因果: 后神经元先放电 -> LTD (减弱)
            delta_w = -a_minus * math.exp(delta_t / tau_minus)

        if learning_rate != 1.0:
            delta_w *= learning_rate

        self.last_stdp_delta_t = delta_t
        return self.adjust_weight(delta_w)

    def clamp_weight(self) -> None:
        """公理四: 钳位权重到合法区间"""
        self.synapse_weight = max(WEIGHT_MIN, min(WEIGHT_MAX, self.synapse_weight))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "source_neuron_id": self.source_neuron_id,
            "target_neuron_id": self.target_neuron_id,
            "synapse_weight": round(self.synapse_weight, 3),
            "relation_type": self.relation_type,
            "is_feedback": self.is_feedback,
            "is_modulation": self.is_modulation,
            "is_bidirectional": self.is_bidirectional,
            "last_stdp_delta_t": self.last_stdp_delta_t,
        }
