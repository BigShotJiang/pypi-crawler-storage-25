"""
结构化日志系统 — v3.0工程化
五层圈层对应五级Logger + JSON结构化输出 + 信号追踪关联
"""

from __future__ import annotations

import json
import logging
import sys
import time
import uuid
from typing import Any, Dict, Optional
from datetime import datetime
from contextvars import ContextVar


# ============================================================
# 上下文变量 — 请求级别trace关联
# ============================================================

_trace_id: ContextVar[str] = ContextVar("trace_id", default="")
_workflow_id: ContextVar[str] = ContextVar("workflow_id", default="")


def get_trace_id() -> str:
    return _trace_id.get("")


def set_trace_id(tid: str) -> None:
    _trace_id.set(tid)


def get_workflow_id() -> str:
    return _workflow_id.get("")


def set_workflow_id(wid: str) -> None:
    _workflow_id.set(wid)


# ============================================================
# 五层圈层Logger名称映射
# ============================================================

LAYER_LOGGERS = {
    "perception": "neuron.perception",     # 感知层
    "cognition": "neuron.cognition",       # 认知层
    "skill": "neuron.skill",               # 能力层
    "schedule": "neuron.schedule",         # 调度层
    "decision": "neuron.decision",         # 决策层
    "memory": "neuron.memory",             # 记忆
    "governance": "neuron.governance",     # 调控
    "learning": "neuron.learning",         # 学习
    "evolution": "neuron.evolution",       # 演化
    "monitor": "neuron.monitor",           # 监控
    "api": "neuron.api",                   # API
    "db": "neuron.db",                     # 数据库
}


def get_layer_logger(layer: str) -> logging.Logger:
    """获取圈层Logger"""
    name = LAYER_LOGGERS.get(layer, f"neuron.{layer}")
    return logging.getLogger(name)


# ============================================================
# JSON格式化器
# ============================================================

class NeuronJSONFormatter(logging.Formatter):
    """
    结构化JSON日志格式化器
    输出格式: {"timestamp":...,"level":...,"logger":...,"trace_id":...,"message":...,"extra":...}
    """
    
    # 默认字段（不出现在extra中）
    RESERVED = {"timestamp", "level", "logger", "trace_id", "workflow_id", "message"}
    
    def format(self, record: logging.LogRecord) -> str:
        log_entry: Dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "trace_id": get_trace_id(),
            "workflow_id": get_workflow_id(),
            "message": record.getMessage(),
        }
        
        # 附加异常信息
        if record.exc_info and record.exc_info[1]:
            log_entry["exception"] = self.formatException(record.exc_info)
        
        # 附加自定义字段
        extra = {k: v for k, v in record.__dict__.items()
                 if k not in logging.LogRecord.__dict__ and k not in self.RESERVED}
        if extra:
            log_entry["extra"] = extra
        
        return json.dumps(log_entry, ensure_ascii=False, default=str)


# ============================================================
# 文本格式化器 (带trace_id)
# ============================================================

class NeuronTextFormatter(logging.Formatter):
    """
    开发友好文本格式: [TIMESTAMP] [LEVEL] [TRACE_ID] [LOGGER] message
    """
    
    COLORS = {
        "DEBUG": "[36m",      # Cyan
        "INFO": "[32m",       # Green
        "WARNING": "[33m",    # Yellow
        "ERROR": "[31m",      # Red
        "CRITICAL": "[35m",   # Magenta
    }
    RESET = "[0m"
    
    def __init__(self, use_color: bool = True):
        super().__init__()
        self.use_color = use_color
    
    def format(self, record: logging.LogRecord) -> str:
        tid = get_trace_id() or "-"
        wid = get_workflow_id() or "-"
        ts = datetime.fromtimestamp(record.created).strftime("%H:%M:%S.%f")[:-3]
        
        color = self.COLORS.get(record.levelname, "")
        reset = self.RESET if self.use_color else ""
        
        return f"{ts} {color}{record.levelname:8s}{reset} [{tid[:12]}] [{wid[:8]}] [{record.name}] {record.getMessage()}"


# ============================================================
# 日志配置
# ============================================================

def setup_logging(
    level: int = logging.INFO,
    format_type: str = "text",  # "text" | "json"
    use_color: bool = True,
    output_file: Optional[str] = None,
) -> None:
    """
    初始化日志系统
    
    Args:
        level: 全局日志级别 (DEBUG/INFO/WARNING/ERROR)
        format_type: 输出格式 ("text"=开发, "json"=生产)
        use_color: 终端彩色输出
        output_file: 可选日志文件路径
    """
    root_logger = logging.getLogger("neuron")
    root_logger.setLevel(level)
    
    # 清除已有handler
    root_logger.handlers.clear()
    
    # 控制台handler
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(level)
    
    if format_type == "json":
        console.setFormatter(NeuronJSONFormatter())
    else:
        console.setFormatter(NeuronTextFormatter(use_color=use_color))
    
    root_logger.addHandler(console)
    
    # 文件handler (可选)
    if output_file:
        file_handler = logging.FileHandler(output_file, encoding="utf-8")
        file_handler.setLevel(level)
        file_handler.setFormatter(NeuronJSONFormatter())
        root_logger.addHandler(file_handler)
    
    # 抑制第三方库的噪音日志
    for noisy in ["urllib3", "httpx", "asyncio"]:
        logging.getLogger(noisy).setLevel(logging.WARNING)
    
    root_logger.info("Neuron Engine logging initialized (level=%s, format=%s)", 
                     logging.getLevelName(level), format_type)


# ============================================================
# 快捷函数
# ============================================================

def log_signal_emit(source: str, target: str, signal_type: str, 
                    intensity: float, trace_id: str = "") -> None:
    """记录信号发射"""
    if trace_id:
        set_trace_id(trace_id)
    logger = get_layer_logger("perception")
    logger.info("信号发射 %s→%s type=%s intensity=%.3f", source, target, signal_type, intensity)


def log_neuron_fire(neuron_id: str, potential: float, threshold: float) -> None:
    """记录神经元点火"""
    logger = get_layer_logger("skill")
    logger.info("神经元点火 %s potential=%.4f threshold=%.4f", neuron_id, potential, threshold)


def log_circuit_breaker(neuron_id: str, state: str, error_count: int) -> None:
    """记录熔断状态变化"""
    logger = get_layer_logger("monitor")
    logger.warning("熔断状态 %s → %s (errors=%d)", neuron_id, state, error_count)


def log_memory_promote(atom_id: str, old_grade: str, new_grade: str, reason: str = "") -> None:
    """记录记忆晋升"""
    logger = get_layer_logger("memory")
    logger.info("记忆晋升 %s %s→%s reason=%s", atom_id, old_grade, new_grade, reason)


def log_workflow_step(workflow_id: str, step: str, status: str = "ok", 
                      duration_ms: float = 0) -> None:
    """记录工作流步骤"""
    set_workflow_id(workflow_id)
    logger = get_layer_logger("schedule")
    logger.info("工作流步骤 %s step=%s status=%s duration=%.1fms", 
                workflow_id, step, status, duration_ms)
