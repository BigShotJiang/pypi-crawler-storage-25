"""
工具函数模块
时间工具 · ID生成 · 序列化 · 指标计算 · 日志
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Callable
from enum import Enum
import hashlib
import json
import time
import uuid
import logging
import os
import functools


# ============================================================
# ID生成器
# ============================================================

class IDGenerator:
    """统一ID生成器，支持多前缀"""

    PREFIXES = {
        "neuron": "N",
        "synapse": "S",
        "signal": "SIG",
        "memory": "MA",
        "task": "T",
        "workflow": "WF",
        "goal": "G",
        "error": "E",
        "log": "L",
        "snapshot": "CS",
    }

    @classmethod
    def generate(cls, prefix_type: str = "neuron") -> str:
        prefix = cls.PREFIXES.get(prefix_type, "X")
        return f"{prefix}-{uuid.uuid4().hex[:12]}"

    @classmethod
    def generate_short(cls) -> str:
        return uuid.uuid4().hex[:8]


# ============================================================
# 时间工具
# ============================================================

class TimeUtils:
    """时间相关工具函数"""

    @staticmethod
    def now_ms() -> int:
        """当前时间戳(毫秒)"""
        return int(time.time() * 1000)

    @staticmethod
    def now_iso() -> str:
        """当前ISO格式时间"""
        return datetime.now().isoformat()

    @staticmethod
    def elapsed_ms(start_ms: int) -> int:
        """计算已过毫秒数"""
        return TimeUtils.now_ms() - start_ms

    @staticmethod
    def duration_ms(start: str, end: str) -> int:
        """计算两个ISO时间之间的毫秒差"""
        try:
            dt_start = datetime.fromisoformat(start)
            dt_end = datetime.fromisoformat(end)
            return int((dt_end - dt_start).total_seconds() * 1000)
        except (ValueError, TypeError):
            return 0

    @staticmethod
    def time_ago_ms(create_time: str) -> int:
        """距创建时间已过毫秒数"""
        return TimeUtils.duration_ms(create_time, TimeUtils.now_iso())

    @staticmethod
    def is_expired(create_time: str, ttl_ms: int) -> bool:
        """是否已过期"""
        return TimeUtils.time_ago_ms(create_time) > ttl_ms

    @staticmethod
    def cooldown_remaining(open_ts: int, cooldown_ms: int = 60000) -> int:
        """熔断冷却剩余毫秒"""
        elapsed = TimeUtils.now_ms() - open_ts
        return max(0, cooldown_ms - elapsed)


# ============================================================
# 记忆等级晋升工具 (白皮书第9章)
# ============================================================

class MemoryGradeUtils:
    """四级记忆等级晋升判定"""

    GRADES = ("temp", "short_term", "long_term", "permanent")

    # 晋升阈值 (白皮书9章)
    PROMOTION_RULES = {
        ("temp", "short_term"): {"min_access": 3, "min_hours": 1},
        ("short_term", "long_term"): {"min_access": 10, "min_hours": 24},
        ("long_term", "permanent"): {"min_access": 50, "min_hours": 168},
    }

    # 降级阈值 (逆向衰减)
    DEMOTION_RULES = {
        ("short_term", "temp"): {"max_hours_without_access": 72},
        ("long_term", "short_term"): {"max_hours_without_access": 168},
    }

    @classmethod
    def can_promote(cls, from_grade: str, to_grade: str,
                    access_count: int, create_time: str) -> tuple:
        """
        判断是否满足晋升条件
        Returns: (can_promote: bool, reason: str)
        """
        key = (from_grade, to_grade)
        rule = cls.PROMOTION_RULES.get(key)
        if rule is None:
            return False, f"无晋升规则: {from_grade} -> {to_grade}"

        if access_count < rule["min_access"]:
            return False, f"访问次数不足: {access_count} < {rule['min_access']}"

        hours_elapsed = TimeUtils.time_ago_ms(create_time) / 3600000
        if hours_elapsed < rule["min_hours"]:
            return False, f"时间不足: {hours_elapsed:.1f}h < {rule['min_hours']}h"

        return True, f"满足晋升条件: access={access_count}, hours={hours_elapsed:.1f}"

    @classmethod
    def should_demote(cls, current_grade: str, access_count: int,
                      last_access_time: str) -> tuple:
        """
        判断是否应该降级
        Returns: (should_demote: bool, target_grade: str, reason: str)
        """
        for (high, low), rule in cls.DEMOTION_RULES.items():
            if current_grade == high:
                hours = TimeUtils.time_ago_ms(last_access_time) / 3600000
                if hours > rule["max_hours_without_access"] and access_count == 0:
                    return True, low, f"长期未访问({hours:.0f}h)降级"
        return False, current_grade, ""


# ============================================================
# 序列化工具
# ============================================================

class Serializer:
    """数据序列化/反序列化"""

    @staticmethod
    def to_json(obj: Any, pretty: bool = False) -> str:
        """对象转JSON字符串"""
        if hasattr(obj, "to_dict"):
            obj = obj.to_dict()
        indent = 2 if pretty else None
        return json.dumps(obj, ensure_ascii=False, indent=indent, default=str)

    @staticmethod
    def from_json(text: str) -> Any:
        """JSON字符串解析"""
        return json.loads(text)

    @staticmethod
    def safe_dict(data: Any) -> Dict[str, Any]:
        """安全转换为字典"""
        if isinstance(data, dict):
            return data
        if hasattr(data, "__dataclass_fields__"):
            return {k: getattr(data, k) for k in data.__dataclass_fields__ if not k.startswith("_")}
        if hasattr(data, "to_dict"):
            return data.to_dict()
        return {}


# ============================================================
# 指标计算
# ============================================================

@dataclass
class PerformanceMetrics:
    """性能指标容器"""
    name: str
    count: int = 0
    total_ms: int = 0
    min_ms: int = 999999
    max_ms: int = 0
    errors: int = 0
    _last_start: int = 0

    def start(self):
        self._last_start = TimeUtils.now_ms()

    def stop(self, success: bool = True):
        elapsed = TimeUtils.now_ms() - self._last_start
        self.count += 1
        self.total_ms += elapsed
        self.min_ms = min(self.min_ms, elapsed)
        self.max_ms = max(self.max_ms, elapsed)
        if not success:
            self.errors += 1

    @property
    def avg_ms(self) -> float:
        return self.total_ms / self.count if self.count > 0 else 0

    @property
    def error_rate(self) -> float:
        return self.errors / self.count if self.count > 0 else 0

    @property
    def throughput(self) -> float:
        """QPS (基于总耗时)"""
        return self.count / (self.total_ms / 1000) if self.total_ms > 0 else 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "count": self.count,
            "avg_ms": round(self.avg_ms, 1),
            "min_ms": self.min_ms,
            "max_ms": self.max_ms,
            "total_ms": self.total_ms,
            "errors": self.errors,
            "error_rate": round(self.error_rate, 4),
            "throughput": round(self.throughput, 2),
        }


class MetricsRegistry:
    """全局指标注册表"""

    def __init__(self):
        self._metrics: Dict[str, PerformanceMetrics] = {}

    def get(self, name: str) -> PerformanceMetrics:
        if name not in self._metrics:
            self._metrics[name] = PerformanceMetrics(name=name)
        return self._metrics[name]

    def all(self) -> Dict[str, Dict]:
        return {k: v.to_dict() for k, v in self._metrics.items()}

    def reset(self):
        self._metrics.clear()


# 全局单例
metrics = MetricsRegistry()


def track_performance(metric_name: str):
    """装饰器: 自动追踪函数执行性能"""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            m = metrics.get(metric_name)
            m.start()
            try:
                result = func(*args, **kwargs)
                m.stop(success=True)
                return result
            except Exception:
                m.stop(success=False)
                raise
        return wrapper
    return decorator


# ============================================================
# 哈希工具
# ============================================================

class HashUtils:
    """哈希计算工具"""

    @staticmethod
    def md5(text: str) -> str:
        return hashlib.md5(text.encode("utf-8")).hexdigest()

    @staticmethod
    def sha256(text: str) -> str:
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    @staticmethod
    def task_pattern_hash(task_input: str) -> str:
        """任务模式哈希 (白皮书V2.5 原子记忆节点)"""
        normalized = " ".join(task_input.lower().split())
        return HashUtils.md5(normalized)[:16]


# ============================================================
# 日志工具
# ============================================================

class NeuronLogger:
    """
    类脑引擎专用日志
    支持结构化输出和文件轮转
    """

    LEVELS = {"DEBUG": 10, "INFO": 20, "WARNING": 30, "ERROR": 40, "FATAL": 50}

    def __init__(self, name: str = "neuron_engine", level: str = "INFO",
                 log_file: Optional[str] = None):
        self.name = name
        self._level = self.LEVELS.get(level, 20)
        self._logger = logging.getLogger(name)
        self._logger.setLevel(self._level)
        self._logger.handlers.clear()

        # 控制台handler
        ch = logging.StreamHandler()
        ch.setLevel(self._level)
        ch.setFormatter(logging.Formatter(
            "[%(asctime)s] %(levelname)s %(name)s: %(message)s",
            datefmt="%H:%M:%S"
        ))
        self._logger.addHandler(ch)

        # 文件handler
        if log_file:
            os.makedirs(os.path.dirname(log_file) or ".", exist_ok=True)
            fh = logging.FileHandler(log_file, encoding="utf-8")
            fh.setLevel(self._level)
            fh.setFormatter(logging.Formatter(
                "[%(asctime)s] %(levelname)s %(name)s: %(message)s"
            ))
            self._logger.addHandler(fh)

    def debug(self, msg, **ctx):
        self._log("DEBUG", msg, ctx)

    def info(self, msg, **ctx):
        self._log("INFO", msg, ctx)

    def warning(self, msg, **ctx):
        self._log("WARNING", msg, ctx)

    def error(self, msg, **ctx):
        self._log("ERROR", msg, ctx)

    def fatal(self, msg, **ctx):
        self._log("FATAL", msg, ctx)

    def _log(self, level: str, msg: str, ctx: dict):
        log_fn = getattr(self._logger, level.lower(), self._logger.info)
        if ctx:
            structured = f"{msg} | {json.dumps(ctx, ensure_ascii=False, default=str)}"
        else:
            structured = msg
        log_fn(structured)


# 全局日志实例
logger = NeuronLogger()


# ============================================================
# 验证工具
# ============================================================

class Validators:
    """参数验证工具"""

    @staticmethod
    def validate_weight(weight: float) -> float:
        """权重区间校验 [0.1, 0.9]"""
        if not (0.1 <= weight <= 0.9):
            raise ValueError(f"Weight {weight} out of range [0.1, 0.9]")
        return round(weight, 4)

    @staticmethod
    def validate_intensity(intensity: float) -> float:
        """信号强度校验 [0.0, 1.0]"""
        if not (0.0 <= intensity <= 1.0):
            raise ValueError(f"Intensity {intensity} out of range [0.0, 1.0]")
        return round(intensity, 4)

    @staticmethod
    def validate_threshold(threshold: float) -> float:
        """阈值校验 [0.0, 1.0]"""
        if not (0.0 <= threshold <= 1.0):
            raise ValueError(f"Threshold {threshold} out of range [0.0, 1.0]")
        return round(threshold, 4)

    @staticmethod
    def validate_leak_factor(leak: float) -> float:
        """泄漏因子校验 [0.5, 0.999]"""
        if not (0.5 <= leak <= 0.999):
            raise ValueError(f"Leak factor {leak} out of range [0.5, 0.999]")
        return round(leak, 4)
