"""
接口协议层 (Protocol Interfaces) — v3.0工程化
定义所有核心组件的类型协议，支持静态类型检查和依赖注入
"""

from __future__ import annotations

from typing import Protocol, Any, Dict, List, Optional, Callable
from typing import runtime_checkable
from enum import Enum
from dataclasses import dataclass


# ============================================================
# 枚举协议 (共享类型)
# ============================================================

class SignalCategory(str, Enum):
    """信号三分类"""
    EXCITATION = "excitation"
    INHIBITION = "inhibition"
    MODULATION = "modulation"


class NeuronGrade(str, Enum):
    """神经元/记忆等级"""
    TEMP = "temp"
    SHORT_TERM = "short_term"
    LONG_TERM = "long_term"
    PERMANENT = "permanent"


class BreakerState(str, Enum):
    """熔断器三态"""
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class LifecyclePhase(str, Enum):
    """信号生命周期阶段"""
    CREATED = "created"
    QUEUED = "queued"
    TRANSMITTING = "transmitting"
    DELIVERED = "delivered"
    PROCESSED = "processed"
    ARCHIVED = "archived"
    EXPIRED = "expired"
    FAILED = "failed"


# ============================================================
# ISignal — 信号协议
# ============================================================

@runtime_checkable
class ISignal(Protocol):
    """信号载体协议"""
    
    @property
    def signal_id(self) -> str: ...
    
    @property
    def signal_type(self) -> SignalCategory: ...
    
    @property
    def source_neuron_id(self) -> str: ...
    
    @property
    def target_neuron_id(self) -> Optional[str]: ...
    
    @property
    def intensity(self) -> float: ...
    
    @property
    def priority(self) -> int: ...
    
    @property
    def is_excitation(self) -> bool: ...
    
    @property
    def is_inhibition(self) -> bool: ...
    
    @property
    def is_modulation(self) -> bool: ...
    
    def to_dict(self) -> Dict[str, Any]: ...


# ============================================================
# ISynapse — 突触协议
# ============================================================

@runtime_checkable
class ISynapse(Protocol):
    """突触连接协议"""
    
    @property
    def synapse_id(self) -> str: ...
    
    @property
    def source_id(self) -> str: ...
    
    @property
    def target_id(self) -> str: ...
    
    @property
    def weight(self) -> float: ...
    
    @weight.setter
    def weight(self, value: float) -> None: ...
    
    @property
    def signal_type(self) -> str: ...
    
    @property
    def last_fire_ts(self) -> int: ...
    
    def adjust_weight(self, delta: float) -> float: ...
    
    def clamp_weight(self) -> None: ...
    
    def to_dict(self) -> Dict[str, Any]: ...


# ============================================================
# INeuron — 神经元协议
# ============================================================

@runtime_checkable
class INeuron(Protocol):
    """神经元协议"""
    
    @property
    def neuron_id(self) -> str: ...
    
    @property
    def neuron_type(self) -> str: ...
    
    @property
    def domain_tag(self) -> str: ...
    
    @property
    def state(self) -> str: ...
    
    @property
    def membrane_potential(self) -> float: ...
    
    @property
    def base_threshold(self) -> float: ...
    
    @property
    def effective_threshold(self) -> float: ...
    
    @property
    def is_breaker_open(self) -> bool: ...
    
    def calc_membrane_potential(self, signals: List[ISignal], priority: int = 0) -> None: ...
    
    def check_fire(self) -> bool: ...
    
    def execute(self, **kwargs: Any) -> Any: ...
    
    def to_dict(self) -> Dict[str, Any]: ...


# ============================================================
# IMemoryAtom — 记忆原子协议
# ============================================================

@runtime_checkable
class IMemoryAtom(Protocol):
    """记忆原子节点协议 (白皮书第9章)"""
    
    @property
    def atom_id(self) -> str: ...
    
    @property
    def content(self) -> str: ...
    
    @property
    def domain_tag(self) -> str: ...
    
    @property
    def memory_grade(self) -> NeuronGrade: ...
    
    @property
    def access_count(self) -> int: ...
    
    def access(self) -> None: ...
    
    def promote(self, new_grade: NeuronGrade, reason: str = "") -> bool: ...
    
    def add_related(self, related_id: str) -> None: ...
    
    def to_dict(self) -> Dict[str, Any]: ...


# ============================================================
# IMemoryManager — 记忆管理器协议
# ============================================================

@runtime_checkable
class IMemoryManager(Protocol):
    """记忆管理器协议"""
    
    def store(self, content: str, domain_tag: str = "", 
              keywords: Optional[List[str]] = None) -> IMemoryAtom: ...
    
    def search(self, domain_tag: str = "", keyword: str = "",
               grade: Optional[str] = None, limit: int = 20) -> List[IMemoryAtom]: ...
    
    def retrieve(self, atom_id: str) -> Optional[IMemoryAtom]: ...
    
    def consolidate(self, atom_id: str) -> bool: ...
    
    def chain_retrieve(self, atom_id: str, max_depth: int = 3) -> List[IMemoryAtom]: ...
    
    def get_stats(self) -> Dict[str, Any]: ...


# ============================================================
# AbstractNeuronBackend — 持久化后端抽象
# ============================================================

class AbstractNeuronBackend:
    """
    神经元持久化后端抽象基类
    SQLite/PostgreSQL/其他后端需实现此接口
    """
    
    def insert_neuron(self, **kwargs: Any) -> str:
        """创建神经元，返回ID"""
        raise NotImplementedError
    
    def get_neuron(self, neuron_id: str) -> Optional[Dict[str, Any]]:
        raise NotImplementedError
    
    def update_neuron(self, neuron_id: str, **kwargs: Any) -> bool:
        raise NotImplementedError
    
    def delete_neuron(self, neuron_id: str) -> bool:
        raise NotImplementedError
    
    def list_neurons(self, domain_tag: str = "", limit: int = 100) -> List[Dict[str, Any]]:
        raise NotImplementedError
    
    def insert_synapse(self, **kwargs: Any) -> str:
        """创建突触，返回ID"""
        raise NotImplementedError
    
    def get_synapse(self, source_id: str, target_id: str) -> Optional[Dict[str, Any]]:
        raise NotImplementedError
    
    def upsert_synapse(self, **kwargs: Any) -> str:
        raise NotImplementedError
    
    def list_synapses(self, neuron_id: str = "", limit: int = 100) -> List[Dict[str, Any]]:
        raise NotImplementedError
    
    def insert_memory_atom(self, **kwargs: Any) -> str:
        raise NotImplementedError
    
    def search_memory(self, domain_tag: str = "", keyword: str = "",
                      limit: int = 20) -> List[Dict[str, Any]]:
        raise NotImplementedError
    
    def promote_atom(self, atom_id: str, new_grade: str, reason: str = "") -> bool:
        raise NotImplementedError
    
    def increment_atom_access(self, atom_id: str) -> bool:
        raise NotImplementedError
    
    def log_signal(self, **kwargs: Any) -> None:
        raise NotImplementedError
    
    def log_reward(self, **kwargs: Any) -> None:
        raise NotImplementedError
    
    def get_stats(self) -> Dict[str, Any]:
        raise NotImplementedError
    
    def get_global_state(self) -> Optional[Dict[str, Any]]:
        raise NotImplementedError
    
    def save_global_state(self, state: Dict[str, Any]) -> bool:
        raise NotImplementedError
    
    def upsert_workflow(self, **kwargs: Any) -> str:
        raise NotImplementedError
    
    def get_workflow(self, workflow_id: str) -> Optional[Dict[str, Any]]:
        raise NotImplementedError
    
    def close(self) -> None:
        """关闭连接"""
        pass
