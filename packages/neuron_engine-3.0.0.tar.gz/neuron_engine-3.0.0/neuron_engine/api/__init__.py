"""
REST API层 — 类脑神经元引擎HTTP接口
基于标准库 http.server (零外部依赖)
提供神经元/突触/记忆/工作流/调控/配置的完整RESTful接口
"""

from dataclasses import dataclass, field
from http.server import HTTPServer, BaseHTTPRequestHandler
from json import JSONEncoder, JSONDecoder
from typing import Optional, Dict, Any, List, Callable, Type
import threading
import json
import traceback
import urllib.parse

from neuron_engine.core.signal import Signal, SignalType
from neuron_engine.core.neuron import Neuron, NeuronType, NeuronState
from neuron_engine.core.synapse import Synapse
from neuron_engine.db import NeuronDB, NeuronRow, SynapseRow, MemoryAtomRow
from neuron_engine.workflow import NeuronEngine
from neuron_engine.exceptions import NeuronError, ErrorSeverity


# ============================================================
# 自定义JSON编码器
# ============================================================

class NeuronJSONEncoder(JSONEncoder):
    """支持dataclass + Enum + datetime的JSON编码"""
    def default(self, obj):
        if hasattr(obj, "to_dict"):
            return obj.to_dict()
        if hasattr(obj, "__dataclass_fields__"):
            return {k: getattr(obj, k) for k in obj.__dataclass_fields__ if not k.startswith("_")}
        if isinstance(obj, Enum):
            return obj.value
        return super().default(obj)


# ============================================================
# 请求上下文
# ============================================================

@dataclass
class RequestContext:
    method: str
    path: str
    query_params: Dict[str, str]
    body: Optional[Dict[str, Any]]
    headers: Dict[str, str]
    client_ip: str


# ============================================================
# 路由注册
# ============================================================

@dataclass
class Route:
    method: str
    path_pattern: str
    handler: Callable
    description: str = ""


class Router:
    """轻量路由器，支持路径参数 /neurons/{neuron_id}"""

    def __init__(self):
        self._routes: List[Route] = []

    def add(self, method: str, path: str, description: str = ""):
        """装饰器: 注册路由"""
        def decorator(handler):
            self._routes.append(Route(method.upper(), path, handler, description))
            return handler
        return decorator

    def match(self, method: str, path: str) -> Optional[tuple]:
        """匹配路由，返回 (handler, path_params) 或 None"""
        for route in self._routes:
            if route.method != method.upper():
                continue
            params = self._match_pattern(route.path_pattern, path)
            if params is not None:
                return route.handler, params
        return None

    @staticmethod
    def _match_pattern(pattern: str, path: str) -> Optional[Dict[str, str]]:
        pat_parts = pattern.strip("/").split("/")
        path_parts = path.strip("/").split("/")
        if len(pat_parts) != len(path_parts):
            return None
        params = {}
        for p, u in zip(pat_parts, path_parts):
            if p.startswith("{") and p.endswith("}"):
                params[p[1:-1]] = urllib.parse.unquote(u)
            elif p != u:
                return None
        return params

    def get_openapi_spec(self) -> Dict:
        """生成OpenAPI 3.0规范"""
        paths = {}
        for route in self._routes:
            path = route.path_pattern
            if path not in paths:
                paths[path] = {}
            method = route.method.lower()
            paths[path][method] = {
                "summary": route.description,
                "responses": {"200": {"description": "OK"}, "400": {"description": "Bad Request"}, "500": {"description": "Internal Error"}}
            }
        return {
            "openapi": "3.0.0",
            "info": {"title": "Neuron Engine API", "version": "3.0.0"},
            "paths": paths
        }


# ============================================================
# API处理器基类
# ============================================================

class NeuronAPIHandler(BaseHTTPRequestHandler):
    """HTTP请求处理器，注入引擎和数据库引用"""

    engine: Optional[NeuronEngine] = None
    db: Optional[NeuronDB] = None
    router: Optional[Router] = None
    encoder: Type[JSONEncoder] = NeuronJSONEncoder

    def log_message(self, fmt, *args):
        """静默HTTP日志（由引擎统一管理日志）"""
        pass

    def _send_json(self, status: int, data: Any = None, error: str = None):
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()
        if error:
            body = {"success": False, "error": error}
        else:
            body = {"success": True, "data": data}
        self.wfile.write(json.dumps(body, ensure_ascii=False, cls=self.encoder).encode("utf-8"))

    def _read_body(self) -> Optional[Dict]:
        try:
            length = int(self.headers.get("Content-Length", 0))
            if length == 0:
                return None
            raw = self.rfile.read(length)
            return json.loads(raw.decode("utf-8"))
        except (json.JSONDecodeError, ValueError):
            return None

    def _parse_query(self) -> Dict[str, str]:
        qs = urllib.parse.urlparse(self.path).query
        return dict(urllib.parse.parse_qsl(qs))

    def do_OPTIONS(self):
        self._send_json(204)

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    def do_DELETE(self):
        self._dispatch("DELETE")

    def _dispatch(self, method: str):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = self._parse_query()
        body = self._read_body()

        if self.router is None:
            self._send_json(503, error="Router not initialized")
            return

        match = self.router.match(method, path)
        if match is None:
            self._send_json(404, error=f"No route: {method} {path}")
            return

        handler, path_params = match
        ctx = RequestContext(
            method=method, path=path, query_params=query,
            body=body, headers=dict(self.headers),
            client_ip=self.client_address[0]
        )
        try:
            result = handler(ctx, path_params)
            self._send_json(200, data=result)
        except NeuronError as e:
            status = 400
            if e.severity == ErrorSeverity.FATAL:
                status = 500
            elif e.severity == ErrorSeverity.RECOVERABLE:
                status = 429
            self._send_json(status, error=str(e))
        except Exception as e:
            traceback.print_exc()
            self._send_json(500, error=f"Internal: {str(e)}")


# ============================================================
# API路由注册 — 完整RESTful端点
# ============================================================

def create_router(engine: NeuronEngine, db: NeuronDB) -> Router:
    """创建并注册所有API路由"""

    router = Router()

    # ---- 健康检查 ----
    @router.add("GET", "/health", "健康检查")
    def health(ctx, params):
        stats = db.get_stats()
        return {
            "status": "healthy",
            "version": "3.0.0",
            "stats": stats,
        }

    # ---- OpenAPI规范 ----
    @router.add("GET", "/openapi.json", "OpenAPI规范")
    def openapi(ctx, params):
        return router.get_openapi_spec()

    # ============================================================
    # 神经元 Neurons
    # ============================================================

    @router.add("GET", "/neurons", "列出所有神经元")
    def list_neurons(ctx, params):
        neuron_type = ctx.query_params.get("type")
        domain_tag = ctx.query_params.get("domain")
        state = ctx.query_params.get("state")
        limit = int(ctx.query_params.get("limit", 100))
        rows = db.list_neurons(neuron_type=neuron_type, domain_tag=domain_tag,
                               state=state, limit=limit)
        return [r.__dict__ for r in rows]

    @router.add("GET", "/neurons/{neuron_id}", "获取单个神经元")
    def get_neuron(ctx, params):
        nid = params["neuron_id"]
        row = db.get_neuron(nid)
        if row is None:
            raise NeuronError(code="N0001", message=f"Neuron {nid} not found",
                              category=None, severity=ErrorSeverity.FATAL)
        return row.__dict__

    @router.add("POST", "/neurons", "创建神经元")
    def create_neuron(ctx, params):
        body = ctx.body or {}
        row = NeuronRow(**{k: v for k, v in body.items() if k in NeuronRow.__dataclass_fields__})
        nid = db.insert_neuron(row)
        # 注册到内存引擎
        neuron = Neuron(neuron_id=nid, neuron_type=row.neuron_type, domain_tag=row.domain_tag,
                        description=row.description, base_threshold=row.base_threshold)
        engine._neurons[nid] = neuron
        return {"neuron_id": nid}

    @router.add("PUT", "/neurons/{neuron_id}", "更新神经元")
    def update_neuron(ctx, params):
        nid = params["neuron_id"]
        updates = ctx.body or {}
        allowed = {k for k in NeuronRow.__dataclass_fields__ if k not in ("neuron_id", "create_time")}
        filtered = {k: v for k, v in updates.items() if k in allowed}
        ok = db.update_neuron(nid, filtered)
        return {"updated": ok}

    @router.add("DELETE", "/neurons/{neuron_id}", "删除神经元")
    def delete_neuron(ctx, params):
        nid = params["neuron_id"]
        ok = db.delete_neuron(nid)
        engine._neurons.pop(nid, None)
        return {"deleted": ok}

    # ---- 神经元激活 ----
    @router.add("POST", "/neurons/{neuron_id}/activate", "激活神经元")
    def activate_neuron(ctx, params):
        nid = params["neuron_id"]
        signals_data = (ctx.body or {}).get("signals", [])
        signals = []
        for sd in signals_data:
            signals.append(Signal(
                signal_type=SignalType(sd.get("type", "excitation")),
                intensity=sd.get("intensity", 0.5),
                source_id=sd.get("source_id", "api"),
                priority=sd.get("priority", 0),
            ))
        result = engine._activate_single(nid, signals)
        return result

    # ============================================================
    # 突触 Synapses
    # ============================================================

    @router.add("GET", "/synapses", "列出突触")
    def list_synapses(ctx, params):
        neuron_id = ctx.query_params.get("neuron_id")
        direction = ctx.query_params.get("direction", "outgoing")
        if neuron_id:
            rows = db.list_synapses(neuron_id=neuron_id, direction=direction)
        else:
            rows = db.list_synapses(direction="all")
        return [r.__dict__ for r in rows]

    @router.add("GET", "/synapses/{source_id}/{target_id}", "获取突触")
    def get_synapse(ctx, params):
        row = db.get_synapse(params["source_id"], params["target_id"])
        if row is None:
            raise NeuronError(code="W0001", message="Synapse not found",
                              category=None, severity=ErrorSeverity.BLOCKING)
        return row.__dict__

    @router.add("POST", "/synapses", "创建突触")
    def create_synapse(ctx, params):
        body = ctx.body or {}
        row = SynapseRow(**{k: v for k, v in body.items() if k in SynapseRow.__dataclass_fields__})
        sid = db.insert_synapse(row)
        return {"synapse_id": sid}

    @router.add("PUT", "/synapses/{source_id}/{target_id}/weight", "更新突触权重")
    def update_weight(ctx, params):
        body = ctx.body or {}
        weight = body.get("weight", 0.5)
        ok = db.update_synapse_weight(params["source_id"], params["target_id"], weight)
        return {"updated": ok, "weight": weight}

    @router.add("DELETE", "/synapses/{source_id}/{target_id}", "删除突触")
    def delete_synapse(ctx, params):
        ok = db.delete_synapse(params["source_id"], params["target_id"])
        return {"deleted": ok}

    # ============================================================
    # 记忆 Memory
    # ============================================================

    @router.add("GET", "/memories", "搜索记忆原子")
    def search_memories(ctx, params):
        domain_tag = ctx.query_params.get("domain")
        grade = ctx.query_params.get("grade")
        keyword = ctx.query_params.get("keyword")
        limit = int(ctx.query_params.get("limit", 50))
        rows = db.search_memory_atoms(domain_tag=domain_tag, grade=grade,
                                       keyword=keyword, limit=limit)
        return [r.__dict__ for r in rows]

    @router.add("GET", "/memories/{atom_id}", "获取记忆原子")
    def get_memory(ctx, params):
        row = db.get_memory_atom(params["atom_id"])
        if row is None:
            raise NeuronError(code="MA0001", message="Memory atom not found",
                              category=None, severity=ErrorSeverity.WARNING)
        return row.__dict__

    @router.add("POST", "/memories", "创建记忆原子")
    def create_memory(ctx, params):
        body = ctx.body or {}
        row = MemoryAtomRow(**{k: v for k, v in body.items() if k in MemoryAtomRow.__dataclass_fields__})
        aid = db.insert_memory_atom(row)
        return {"atom_id": aid}

    @router.add("POST", "/memories/{atom_id}/access", "记录访问")
    def access_memory(ctx, params):
        ok = db.increment_atom_access(params["atom_id"])
        return {"accessed": ok}

    @router.add("POST", "/memories/{atom_id}/promote", "晋升记忆等级")
    def promote_memory(ctx, params):
        body = ctx.body or {}
        new_grade = body.get("grade", "short_term")
        reason = body.get("reason", "manual")
        ok = db.promote_atom(params["atom_id"], new_grade, reason)
        return {"promoted": ok, "new_grade": new_grade}

    # ============================================================
    # 任务工作流 Workflows
    # ============================================================

    @router.add("POST", "/tasks/execute", "执行任务（10步闭环）")
    def execute_task(ctx, params):
        body = ctx.body or {}
        task_input = body.get("input", "")
        task_type = body.get("type", "general")
        result = engine.execute_task(task_input, task_type=task_type)
        return result

    @router.add("GET", "/workflows/{workflow_id}", "获取工作流状态")
    def get_workflow(ctx, params):
        wf = db.get_workflow(params["workflow_id"])
        if wf is None:
            raise NeuronError(code="W0001", message="Workflow not found",
                              category=None, severity=ErrorSeverity.WARNING)
        return wf

    # ============================================================
    # 全局调控 Governance
    # ============================================================

    @router.add("GET", "/governance/state", "获取全局调控状态")
    def get_gov_state(ctx, params):
        gs = engine.governance.global_state
        return {
            "arousal": round(gs.arousal, 3),
            "attention": round(gs.attention, 3),
            "learning_mode": round(gs.learning_mode, 3),
            "stability": round(gs.stability, 3),
            "run_mode": engine.governance.run_mode,
        }

    @router.add("GET", "/governance/personality", "获取人格特征")
    def get_personality(ctx, params):
        p = engine.governance.personality
        return {
            "openness": round(p.openness, 3),
            "conscientiousness": round(p.conscientiousness, 3),
            "extraversion": round(p.extraversion, 3),
            "agreeableness": round(p.agreeableness, 3),
            "neuroticism": round(p.neuroticism, 3),
        }

    @router.add("GET", "/governance/emotion", "获取当前情绪")
    def get_emotion(ctx, params):
        e = engine.governance.emotion
        return {
            "valence": round(e.valence, 3),
            "arousal": round(e.arousal, 3),
            "dominance": round(e.dominance, 3),
            "primary_emotion": e.primary_emotion,
        }

    # ============================================================
    # 配置 Config
    # ============================================================

    @router.add("GET", "/config", "获取所有配置")
    def get_config(ctx, params):
        return engine.config.get_all()

    @router.add("PUT", "/config", "更新配置")
    def update_config(ctx, params):
        updates = ctx.body or {}
        results = {}
        for key, value in updates.items():
            ok = engine.config.set(key, value)
            results[key] = ok
        return results

    @router.add("POST", "/config/reload", "热加载配置")
    def reload_config(ctx, params):
        engine.config.reload()
        return {"reloaded": True}

    @router.add("GET", "/config/groups", "获取配置分组")
    def get_config_groups(ctx, params):
        return engine.config.get_groups()

    # ============================================================
    # 统计 Stats
    # ============================================================

    @router.add("GET", "/stats", "引擎统计")
    def get_stats(ctx, params):
        stats = db.get_stats()
        status = engine.get_status()
        return {"database": stats, "engine": status}

    return router


# ============================================================
# API服务器
# ============================================================

class NeuronAPIServer:
    """
    类脑神经元引擎API服务器
    零外部依赖，基于标准库http.server
    """

    def __init__(self, engine: NeuronEngine, db: NeuronDB,
                 host: str = "0.0.0.0", port: int = 8100):
        self.engine = engine
        self.db = db
        self.host = host
        self.port = port
        self._server: Optional[HTTPServer] = None
        self._thread: Optional[threading.Thread] = None

        # 注入到handler类
        NeuronAPIHandler.engine = engine
        NeuronAPIHandler.db = db
        NeuronAPIHandler.router = create_router(engine, db)

    def start(self, blocking: bool = True):
        """启动API服务器"""
        self._server = HTTPServer((self.host, self.port), NeuronAPIHandler)
        if blocking:
            print(f"[NeuronEngine API] Listening on {self.host}:{self.port}")
            self._server.serve_forever()
        else:
            self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
            self._thread.start()
            print(f"[NeuronEngine API] Background thread started on {self.host}:{self.port}")

    def stop(self):
        """停止API服务器"""
        if self._server:
            self._server.shutdown()
            print("[NeuronEngine API] Server stopped")
