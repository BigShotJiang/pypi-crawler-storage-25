"""
层级记忆系统 (白皮书第9章)
四级层级记忆 · 原子记忆节点(V2.5) · 双向连通 · 链式检索 · 记忆巩固
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Any, Set
import uuid
import time
import math
import json


class MemoryType(Enum):
    """四级记忆等级 (白皮书9.3.2)"""
    TEMP = "temp"                    # 临时 (泄漏因子0.70)
    SHORT_TERM = "short_term"        # 短期 (泄漏因子0.85)
    LONG_TERM = "long_term"          # 长期 (泄漏因子0.95)
    PERMANENT = "permanent"          # 永久 (泄漏因子0.99)


# 泄漏因子与等级联动 (V2.5)
LEAK_FACTOR_MAP = {
    MemoryType.TEMP: 0.70,
    MemoryType.SHORT_TERM: 0.85,
    MemoryType.LONG_TERM: 0.95,
    MemoryType.PERMANENT: 0.99,
}

# 晋升条件
PROMOTION_CONDITIONS = {
    MemoryType.SHORT_TERM: {"min_access_count": 3, "min_age_hours": 1},
    MemoryType.LONG_TERM: {"min_access_count": 10, "min_age_hours": 24},
    MemoryType.PERMANENT: {"min_access_count": 50, "min_age_hours": 168},
}


@dataclass
class MemoryAtom:
    """
    原子记忆节点 (白皮书9.3.1)
    最小不可分割的记忆单元
    """
    content: str
    atom_id: str = field(default_factory=lambda: f"MA-{uuid.uuid4().hex[:8]}")
    memory_type: MemoryType = MemoryType.TEMP
    domain_tag: str = "通用"
    keywords: List[str] = field(default_factory=list)
    related_ids: List[str] = field(default_factory=list)
    source_neuron_id: Optional[str] = None
    trace_id: Optional[str] = None
    access_count: int = 0
    leak_factor: float = 0.70
    importance: float = 0.500
    embedding: Optional[List[float]] = None

    create_time: str = field(default_factory=lambda: datetime.now().isoformat())
    update_time: str = field(default_factory=lambda: datetime.now().isoformat())

    def __post_init__(self):
        if isinstance(self.memory_type, MemoryType):
            self.leak_factor = LEAK_FACTOR_MAP[self.memory_type]
        elif isinstance(self.memory_type, str):
            # 尝试匹配枚举，不匹配则降级TEMP
            matched = False
            for mt in MemoryType:
                if mt.value == self.memory_type:
                    self.memory_type = mt
                    self.leak_factor = LEAK_FACTOR_MAP[mt]
                    matched = True
                    break
            if not matched:
                self.memory_type = MemoryType.TEMP
                self.leak_factor = LEAK_FACTOR_MAP[MemoryType.TEMP]
        else:
            self.memory_type = MemoryType.TEMP
            self.leak_factor = LEAK_FACTOR_MAP[MemoryType.TEMP]

    @property
    def importance_score(self) -> float:
        return self.importance

    @importance_score.setter
    def importance_score(self, value: float):
        self.importance = value

    def touch(self):
        """访问记忆 (增加计数)"""
        self.access_count += 1
        self.update_time = datetime.now().isoformat()

    def add_keyword(self, keyword: str):
        """添加关键词 (标签匹配检索)"""
        if keyword not in self.keywords:
            self.keywords.append(keyword)
            self.update_time = datetime.now().isoformat()

    def link(self, other_atom_id: str):
        """建立双向连通关联"""
        if other_atom_id not in self.related_ids:
            self.related_ids.append(other_atom_id)
            self.update_time = datetime.now().isoformat()

    def unlink(self, other_atom_id: str):
        """解除关联"""
        if other_atom_id in self.related_ids:
            self.related_ids.remove(other_atom_id)

    def can_promote(self):
        """检查是否满足晋升条件，返回(can_promote, reason)"""
        current_rank = list(MemoryType).index(self.memory_type)
        if current_rank >= len(MemoryType) - 1:
            return (False, "已是最高级")

        next_type = list(MemoryType)[current_rank + 1]
        conditions = PROMOTION_CONDITIONS.get(next_type, {})
        age_hours = (datetime.now() - datetime.fromisoformat(self.create_time)).total_seconds() / 3600

        if self.access_count < conditions.get("min_access_count", 999):
            return (False, f"访问次数不足: {self.access_count}/{conditions.get('min_access_count', 999)}")
        if age_hours < conditions.get("min_age_hours", 999):
            return (False, f"时间不足: {age_hours:.1f}h/{conditions.get('min_age_hours', 999)}h")
        return (True, "满足晋升条件")

    def promote(self) -> Optional[str]:
        """
        等级晋升 (不可降级)
        Returns: 新等级 or None(已是最高级)
        """
        can, _ = self.can_promote()
        if not can:
            return None

        current_rank = list(MemoryType).index(self.memory_type)
        new_type = list(MemoryType)[current_rank + 1]
        old_type = self.memory_type.value
        self.memory_type = new_type
        self.leak_factor = LEAK_FACTOR_MAP[new_type]
        self.update_time = datetime.now().isoformat()
        return f"{old_type} → {new_type.value}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "atom_id": self.atom_id,
            "memory_type": self.memory_type.value if isinstance(self.memory_type, MemoryType) else self.memory_type,
            "domain_tag": self.domain_tag,
            "content": self.content[:200] + "..." if len(self.content) > 200 else self.content,
            "keywords": self.keywords,
            "related_count": len(self.related_ids),
            "access_count": self.access_count,
            "leak_factor": self.leak_factor,
            "importance": self.importance,
            "grade": self.grade,
            "create_time": self.create_time,
            "update_time": self.update_time,
        }



    @property
    def grade(self) -> str:
        """兼容旧API: grade = memory_type.value (字符串)"""
        if isinstance(self.memory_type, MemoryType):
            return self.memory_type.value
        return str(self.memory_type)

    @grade.setter
    def grade(self, value):
        if isinstance(value, MemoryType):
            self.memory_type = value
            self.leak_factor = LEAK_FACTOR_MAP[value]
        elif isinstance(value, str):
            # 尝试匹配枚举值
            for mt in MemoryType:
                if mt.value == value:
                    self.memory_type = mt
                    self.leak_factor = LEAK_FACTOR_MAP[mt]
                    return
            # 未匹配: 保持TEMP (不抛异常)

    def access(self):
        """兼容旧API: 记录访问"""
        self.touch()

    def add_related(self, atom_id: str):
        """兼容旧API: 添加关联"""
        self.link(atom_id)

    @classmethod
    def create(cls, content: str, **kwargs) -> "MemoryAtom":
        """兼容旧API: 简化创建"""
        # 映射旧参数名
        if 'importance' in kwargs:
            kwargs.setdefault('importance_score', kwargs.pop('importance'))
        if 'domain_tag' in kwargs:
            kwargs.setdefault('domain', kwargs.pop('domain_tag'))
        if 'memory_type' not in kwargs and 'grade' in kwargs:
            kwargs['memory_type'] = kwargs.pop('grade')
        if 'domain' not in kwargs:
            kwargs['domain'] = '通用'
        return cls(content=content, **kwargs)

class MemoryManager:
    """
    记忆管理器 (白皮书第9章)
    原子记忆节点存储 + 四级自动晋升 + 双向连通 + 链式检索
    """

    def __init__(self, capacity: int = 1000):
        self._atoms: Dict[str, MemoryAtom] = {}
        self._domain_index: Dict[str, Set[str]] = {}  # domain -> atom_ids
        self._keyword_index: Dict[str, Set[str]] = {}  # keyword -> atom_ids
        self._capacity = capacity

    def create_atom(self, content: str, domain_tag: str = "通用",
                    keywords: List[str] = None,
                    source_neuron_id: str = None,
                    trace_id: str = None) -> MemoryAtom:
        """创建原子记忆节点"""
        atom = MemoryAtom(
            content=content, domain_tag=domain_tag,
            keywords=keywords or [], source_neuron_id=source_neuron_id,
            trace_id=trace_id,
        )
        self._atoms[atom.atom_id] = atom
        self._index_atom(atom)
        return atom

    def get_atom(self, atom_id: str) -> Optional[MemoryAtom]:
        """获取单个原子节点"""
        atom = self._atoms.get(atom_id)
        if atom:
            atom.touch()
        return atom

    def search_by_keyword(self, keyword: str, limit: int = 10, **kwargs) -> List[MemoryAtom]:
        """标签匹配检索"""
        ids = self._keyword_index.get(keyword, set())
        results = []
        for aid in ids:
            atom = self._atoms.get(aid)
            if atom:
                atom.touch()
                results.append(atom)
        # 按访问次数和泄漏因子排序
        results.sort(key=lambda a: (a.access_count * a.leak_factor), reverse=True)
        return results[:limit]

    def chain_retrieve(self, start_atom_id: str, max_depth: int = 3,
                       max_results: int = 20) -> List[MemoryAtom]:
        """
        链式精准检索 (白皮书9.3)
        从匹配的少量节点沿关联ID链式调取，禁止全量遍历
        """
        visited = set()
        results = []
        queue = [(start_atom_id, 0)]

        while queue and len(results) < max_results:
            current_id, depth = queue.pop(0)
            if current_id in visited or depth > max_depth:
                continue
            visited.add(current_id)

            atom = self._atoms.get(current_id)
            if atom:
                atom.touch()
                results.append(atom)
                for related_id in atom.related_ids:
                    if related_id not in visited:
                        queue.append((related_id, depth + 1))

        return results

    def auto_link(self, atom_a: MemoryAtom, atom_b: MemoryAtom):
        """自动双向连通"""
        atom_a.link(atom_b.atom_id)
        atom_b.link(atom_a.atom_id)
        self._index_atom(atom_b)  # 确保索引更新

    def try_promote_all(self) -> List[Dict]:
        """批量尝试晋升"""
        results = []
        for atom in self._atoms.values():
            promotion = atom.promote()
            if promotion:
                results.append({
                    "atom_id": atom.atom_id,
                    "promotion": promotion,
                    "access_count": atom.access_count,
                })
        return results

    def consolidate(self, atom_id: str = None) -> Any:
        """
        记忆巩固 (白皮书9.2)
        支持两种调用: consolidate() 全量 / consolidate(atom_id) 单个
        """
        if atom_id is not None:
            # 单个原子尝试晋升
            atom = self._atoms.get(atom_id)
            if atom is None:
                return False
            result = atom.promote()
            return result is not None
        promoted = self.try_promote_all()
        
        # 遗忘清理: 删除access_count=0且超过90天的temp节点
        pruned = []
        now = datetime.now()
        for atom_id, atom in list(self._atoms.items()):
            if (atom.memory_type == MemoryType.TEMP and
                    atom.access_count == 0 and
                    (now - datetime.fromisoformat(atom.create_time)).days > 90):
                del self._atoms[atom_id]
                pruned.append(atom_id)

        return {"promoted": len(promoted), "pruned": len(pruned),
                "promotions": promoted}

    def search_by_domain(self, domain: str, limit: int = 20) -> List[MemoryAtom]:
        """按领域检索"""
        ids = self._domain_index.get(domain, set())
        return [self._atoms[aid] for aid in ids if aid in self._atoms][:limit]

    def get_stats(self) -> Dict[str, Any]:
        """记忆统计"""
        type_counts = {}
        for atom in self._atoms.values():
            t = atom.memory_type.value
            type_counts[t] = type_counts.get(t, 0) + 1
        return {
            "total_atoms": len(self._atoms),
            "by_type": type_counts,
            "capacity": self._capacity,
            "utilization": f"{len(self._atoms)/self._capacity*100:.1f}%",
        }

    def _index_atom(self, atom: MemoryAtom):
        """建立索引"""
        if atom.domain_tag not in self._domain_index:
            self._domain_index[atom.domain_tag] = set()
        self._domain_index[atom.domain_tag].add(atom.atom_id)

        for kw in atom.keywords:
            if kw not in self._keyword_index:
                self._keyword_index[kw] = set()
            self._keyword_index[kw].add(atom.atom_id)


    def store(self, content: str, domain_tag: str = "通用", **kwargs) -> "MemoryAtom":
        """兼容旧API: 存储记忆原子"""
        atom = self.create_atom(content=content, domain_tag=domain_tag, **kwargs)
        return atom

    def get(self, atom_id: str):
        """兼容旧API: 获取记忆原子"""
        return self.get_atom(atom_id)

    def store_atom(self, atom: "MemoryAtom"):
        """兼容旧API: 存储已有原子(重新索引)"""
        self._index_atom(atom)

    def search(self, domain_tag: str = None, keyword: str = None, **kwargs):
        """兼容旧API: 搜索记忆"""
        if keyword:
            return self.search_by_keyword(keyword, domain=domain_tag)
        if domain_tag:
            return self.search_by_domain(domain_tag)
        return list(self._atoms.values())

