"""
配置管理 (白皮书第21章)
13+9项配置开关 · 分组依赖 · 动态热加载 · 审计日志
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Callable, Tuple
from datetime import datetime
import copy
import json


# ============================================================
# 配置分组与依赖关系 (白皮书21.2)
# ============================================================

CONFIG_GROUPS = {
    "signal": {
        "name": "信号组",
        "configs": ["enable_modulation_signal", "enable_signal_noise_filter"],
        "depends_on": [],
    },
    "learning": {
        "name": "学习组",
        "configs": ["enable_stdp", "stdp_biological_params", "enable_rpe"],
        "depends_on": ["signal"],
    },
    "modulation": {
        "name": "调控组",
        "configs": ["enable_global_state", "enable_personality", "enable_3d_synergy"],
        "depends_on": ["signal"],
    },
    "governance": {
        "name": "治理组",
        "configs": ["enable_memory_consolidation", "enable_distributed_consensus",
                     "enable_anomaly_detection"],
        "depends_on": ["learning", "modulation"],
    },
}

# 依赖图 (group -> required groups)
GROUP_DEPENDS = {g: info["depends_on"] for g, info in CONFIG_GROUPS.items()}

# 反查: config_key -> group
CONFIG_TO_GROUP = {}
for group, info in CONFIG_GROUPS.items():
    for key in info["configs"]:
        CONFIG_TO_GROUP[key] = group


# ============================================================
# 默认配置值 (白皮书21+21.1)
# ============================================================

DEFAULT_CONFIG = {
    # V2.3 原始开关
    "enable_stdp": {"value": False, "type": "bool", "desc": "STDP时序可塑性", "version": "V2.3"},
    "enable_rpe": {"value": False, "type": "bool", "desc": "多巴胺RPE奖励", "version": "V2.3"},
    "enable_modulation_signal": {"value": False, "type": "bool", "desc": "调控信号(第三类)", "version": "V2.3"},
    "enable_memory_consolidation": {"value": False, "type": "bool", "desc": "记忆巩固机制", "version": "V2.3"},
    "enable_global_state": {"value": False, "type": "bool", "desc": "全局调控系统", "version": "V2.3"},
    "enable_personality": {"value": False, "type": "bool", "desc": "人格-情绪-动机", "version": "V2.3"},
    "enable_distributed_consensus": {"value": False, "type": "bool", "desc": "分布式共识协议", "version": "V2.3"},
    "enable_anomaly_detection": {"value": False, "type": "bool", "desc": "异常检测与自愈", "version": "V2.3"},
    
    # STDP参数
    "stdp_a_plus": {"value": 0.08, "type": "float", "range": [0.01, 0.20], "desc": "LTP最大增量", "version": "V2.3"},
    "stdp_a_minus": {"value": 0.04, "type": "float", "range": [0.01, 0.20], "desc": "LTD最大减量", "version": "V2.3"},
    "stdp_tau_plus": {"value": 10000, "type": "int", "range": [1000, 60000], "desc": "LTP时间常数(ms)", "version": "V2.3"},
    "stdp_tau_minus": {"value": 15000, "type": "int", "range": [1000, 60000], "desc": "LTD时间常数(ms)", "version": "V2.4"},
    "stdp_biological_params": {"value": False, "type": "bool", "desc": "使用Bi&Poo(1998)生物参数", "version": "V2.6"},
    
    # 记忆巩固
    "memory_consolidation_trigger_min": {"value": 300000, "type": "int", "range": [60000, 600000],
                                          "desc": "空闲触发巩固阈值(ms)", "version": "V2.3"},
    
    # V2.6 新增
    "enable_signal_noise_filter": {"value": False, "type": "bool", "desc": "信号噪声过滤", "version": "V2.6"},
    "noise_threshold_entropy": {"value": 0.5, "type": "float", "range": [0.1, 1.0], "desc": "信息熵噪声阈值", "version": "V2.6"},
    "skill_lifecycle_enabled": {"value": False, "type": "bool", "desc": "技能生命周期7状态管理", "version": "V2.6"},
    "skill_max_activation_timeout_ms": {"value": 30000, "type": "int", "range": [5000, 120000],
                                          "desc": "技能最大激活超时", "version": "V2.6"},
    "enable_3d_synergy": {"value": False, "type": "bool", "desc": "人格-调控-记忆三维协同", "version": "V2.6"},
    "synergy_personality_weight": {"value": 0.3, "type": "float", "range": [0.1, 0.5], "desc": "三维协同人格权重", "version": "V2.6"},
    "synergy_modulation_weight": {"value": 0.4, "type": "float", "range": [0.1, 0.5], "desc": "三维协同调控权重", "version": "V2.6"},
    "synergy_memory_weight": {"value": 0.3, "type": "float", "range": [0.1, 0.5], "desc": "三维协同记忆权重", "version": "V2.6"},
}


@dataclass
class ConfigAudit:
    """配置变更审计记录"""
    key: str
    old_value: Any
    new_value: Any
    operator: str = "system"
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self):
        return {
            "key": self.key, "old_value": self.old_value,
            "new_value": self.new_value, "operator": self.operator,
            "timestamp": self.timestamp,
        }


class NeuronConfig:
    """
    类脑神经元配置管理器 (白皮书第21章)
    - 13+9项配置开关，默认关闭 (向后兼容)
    - 分组依赖关系检查
    - 动态热加载 (运行时修改立即生效)
    - 配置变更审计日志
    """

    def __init__(self, overrides: Optional[Dict[str, Any]] = None):
        self._values: Dict[str, Any] = {}
        self._audit_log: List[ConfigAudit] = []
        self._change_listeners: Dict[str, List[Callable]] = {}

        # 加载默认值
        for key, meta in DEFAULT_CONFIG.items():
            self._values[key] = meta["value"]

        # 应用覆盖
        if overrides:
            self.batch_set(overrides, operator="init")

    def get(self, key: str) -> Any:
        """获取配置值"""
        if key not in self._values:
            raise KeyError(f"未知配置键: {key}")
        return self._values[key]

    def get_meta(self, key: str) -> Dict[str, Any]:
        """获取配置元信息"""
        return DEFAULT_CONFIG.get(key, {})

    def set(self, key: str, value: Any, operator: str = "system") -> ConfigAudit:
        """
        设置配置值 (单个，含依赖检查)
        白皮书21.3: 运行时热加载
        """
        if key not in DEFAULT_CONFIG:
            raise KeyError(f"未知配置键: {key}")

        meta = DEFAULT_CONFIG[key]
        old_value = self._values.get(key)

        # 类型检查
        if meta["type"] == "bool" and not isinstance(value, bool):
            raise TypeError(f"{key} 必须是bool类型")
        if meta["type"] == "float" and not isinstance(value, (int, float)):
            raise TypeError(f"{key} 必须是float类型")

        # 范围检查
        if "range" in meta:
            lo, hi = meta["range"]
            if not (lo <= value <= hi):
                raise ValueError(f"{key} 值 {value} 不在范围 [{lo}, {hi}]")

        # 依赖检查 (bool开关)
        if meta["type"] == "bool" and value is True:
            self._check_dependencies(key)

        # 影子表平滑过渡 (数值类)
        if meta["type"] in ("float", "int") and old_value is not None:
            value = old_value + (value - old_value)  # 立即应用（简化版）

        self._values[key] = value

        # 审计
        audit = ConfigAudit(key=key, old_value=old_value, new_value=value, operator=operator)
        self._audit_log.append(audit)

        # 通知监听器
        self._notify_listeners(key, value, old_value)

        return audit

    def batch_set(self, changes: Dict[str, Any], operator: str = "system",
                  atomic: bool = True) -> List[ConfigAudit]:
        """
        批量修改配置 (原子性: 全部成功或全部回滚)
        """
        old_values = {k: self._values.get(k) for k in changes}
        audits = []
        applied_keys = []

        try:
            for key, value in changes.items():
                audit = self.set(key, value, operator)
                audits.append(audit)
                applied_keys.append(key)
            return audits
        except Exception:
            # 原子性回滚
            if atomic:
                for key in applied_keys:
                    if old_values[key] is not None:
                        self._values[key] = old_values[key]
            raise

    def _check_dependencies(self, key: str):
        """检查配置依赖 (白皮书21.2)"""
        group = CONFIG_TO_GROUP.get(key)
        if group is None:
            return

        required_groups = GROUP_DEPENDS.get(group, [])
        for req_group in required_groups:
            for req_key in CONFIG_GROUPS[req_group]["configs"]:
                if not self._values.get(req_key, False):
                    from neuron_engine.exceptions import ConfigDependencyError
                    missing = CONFIG_GROUPS[req_group]["configs"]
                    raise ConfigDependencyError(key, missing)

    def on_change(self, key: str, callback: Callable):
        """注册配置变更监听器"""
        if key not in self._change_listeners:
            self._change_listeners[key] = []
        self._change_listeners[key].append(callback)

    def _notify_listeners(self, key: str, new_value: Any, old_value: Any):
        for cb in self._change_listeners.get(key, []):
            try:
                cb(key, new_value, old_value)
            except Exception:
                pass

    def get_audit_log(self, limit: int = 100) -> List[Dict]:
        return [a.to_dict() for a in self._audit_log[-limit:]]

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in self._values.items()}

    def get_all_meta(self) -> Dict[str, Dict]:
        result = {}
        for key, meta in DEFAULT_CONFIG.items():
            result[key] = {**meta, "current_value": self._values.get(key)}
        return result
