"""
数据库持久化层 (白皮书第13章 · 14张核心表)
支持 SQLite（开发/嵌入式）和 PostgreSQL（生产）双后端
所有DDL严格对标白皮书13章定义
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional, Dict, Any, List, Tuple
import json
import sqlite3
import threading
import uuid
import time

from neuron_engine.exceptions import (
    NeuronNotFoundError, SynapseNotFoundError, MemoryAtomNotFoundError,
    ConfigDependencyError, MemoryConsolidationError,
)


class DatabaseBackend(Enum):
    """数据库后端"""
    SQLITE = "sqlite"
    POSTGRESQL = "postgresql"


# ============================================================
# 14张核心表DDL — 白皮书第13章完整定义
# ============================================================

DDL_SQLITE = """
-- ============================================================
-- 表1: neuron_base 神经元基表 (30字段)
-- ============================================================
CREATE TABLE IF NOT EXISTS neuron_base (
    neuron_id         TEXT PRIMARY KEY,
    neuron_type       TEXT NOT NULL DEFAULT 'skill',
    domain_tag        TEXT NOT NULL DEFAULT '通用',
    state             TEXT NOT NULL DEFAULT '静默',
    base_threshold    REAL NOT NULL DEFAULT 0.600,
    dynamic_threshold REAL NOT NULL DEFAULT 0.600,
    membrane_potential REAL NOT NULL DEFAULT 0.000,
    rest_potential    REAL NOT NULL DEFAULT 0.000,
    leak_factor       REAL NOT NULL DEFAULT 0.950,
    excitation_factor REAL NOT NULL DEFAULT 1.000,
    inhibition_factor REAL NOT NULL DEFAULT 1.000,
    learning_rate     REAL NOT NULL DEFAULT 1.000,
    signal_gain       REAL NOT NULL DEFAULT 1.000,
    awareness_level   REAL NOT NULL DEFAULT 0.500,
    memory_sub_type   TEXT,
    memory_grade      TEXT DEFAULT 'temp',
    memory_capacity   INTEGER,
    is_consolidated   INTEGER NOT NULL DEFAULT 0,
    task_pattern_hash TEXT,
    description       TEXT DEFAULT '',
    timeout_ms        INTEGER NOT NULL DEFAULT 30000,
    instance_id       TEXT DEFAULT 'default',
    activate_times    INTEGER NOT NULL DEFAULT 0,
    success_count     INTEGER NOT NULL DEFAULT 0,
    error_count       INTEGER NOT NULL DEFAULT 0,
    last_activate_ts  INTEGER NOT NULL DEFAULT 0,
    breaker_open_ts   INTEGER NOT NULL DEFAULT 0,
    version           INTEGER NOT NULL DEFAULT 1,
    create_time       TEXT NOT NULL,
    update_time       TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_neuron_type ON neuron_base(neuron_type);
CREATE INDEX IF NOT EXISTS idx_neuron_domain ON neuron_base(domain_tag);
CREATE INDEX IF NOT EXISTS idx_neuron_state ON neuron_base(state);

-- ============================================================
-- 表2: neuron_synapse 突触连接表 (8字段)
-- ============================================================
CREATE TABLE IF NOT EXISTS neuron_synapse (
    synapse_id    TEXT PRIMARY KEY,
    source_id     TEXT NOT NULL,
    target_id     TEXT NOT NULL,
    weight        REAL NOT NULL DEFAULT 0.500,
    signal_type   TEXT NOT NULL DEFAULT 'excitation',
    created_at    TEXT NOT NULL,
    last_stdp_ts  INTEGER NOT NULL DEFAULT 0,
    version       INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT uk_synapse UNIQUE (source_id, target_id)
);

CREATE INDEX IF NOT EXISTS idx_synapse_source ON neuron_synapse(source_id);
CREATE INDEX IF NOT EXISTS idx_synapse_target ON neuron_synapse(target_id);

-- ============================================================
-- 表3: memory_atom 原子记忆节点表 (14字段)
-- ============================================================
CREATE TABLE IF NOT EXISTS memory_atom (
    atom_id       TEXT PRIMARY KEY,
    content       TEXT NOT NULL,
    memory_type   TEXT NOT NULL DEFAULT 'episodic',
    domain_tag    TEXT NOT NULL DEFAULT '通用',
    grade         TEXT NOT NULL DEFAULT 'temp',
    access_count  INTEGER NOT NULL DEFAULT 0,
    importance    REAL NOT NULL DEFAULT 0.500,
    emotion_valence   REAL DEFAULT 0.0,
    emotion_arousal   REAL DEFAULT 0.0,
    keywords      TEXT DEFAULT '[]',
    related_ids   TEXT DEFAULT '[]',
    consolidate_log_id TEXT,
    create_time   TEXT NOT NULL,
    update_time   TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_atom_grade ON memory_atom(grade);
CREATE INDEX IF NOT EXISTS idx_atom_domain ON memory_atom(domain_tag);
CREATE INDEX IF NOT EXISTS idx_atom_access ON memory_atom(access_count);

-- ============================================================
-- 表4: signal_log 信号日志表
-- ============================================================
CREATE TABLE IF NOT EXISTS signal_log (
    log_id       TEXT PRIMARY KEY,
    signal_id    TEXT NOT NULL,
    signal_type  TEXT NOT NULL,
    source_id    TEXT NOT NULL,
    target_id    TEXT NOT NULL,
    intensity    REAL NOT NULL,
    priority     INTEGER NOT NULL DEFAULT 0,
    status       TEXT NOT NULL DEFAULT 'pending',
    created_at   TEXT NOT NULL,
    processed_at TEXT,
    duration_ms  INTEGER,
    error_msg    TEXT
);

CREATE INDEX IF NOT EXISTS idx_signal_source ON signal_log(source_id);
CREATE INDEX IF NOT EXISTS idx_signal_target ON signal_log(target_id);
CREATE INDEX IF NOT EXISTS idx_signal_status ON signal_log(status);
CREATE INDEX IF NOT EXISTS idx_signal_created ON signal_log(created_at);

-- ============================================================
-- 表5: task_workflow 任务工作流表
-- ============================================================
CREATE TABLE IF NOT EXISTS task_workflow (
    workflow_id   TEXT PRIMARY KEY,
    task_id       TEXT NOT NULL,
    task_input    TEXT,
    current_step  INTEGER NOT NULL DEFAULT 0,
    status        TEXT NOT NULL DEFAULT 'pending',
    step_results  TEXT DEFAULT '{}',
    error_msg     TEXT,
    start_time    TEXT NOT NULL,
    end_time      TEXT,
    version       INTEGER NOT NULL DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_workflow_task ON task_workflow(task_id);
CREATE INDEX IF NOT EXISTS idx_workflow_status ON task_workflow(status);

-- ============================================================
-- 表6: neuron_global_state 全局调控状态表 (四维)
-- ============================================================
CREATE TABLE IF NOT EXISTS neuron_global_state (
    instance_id   TEXT PRIMARY KEY DEFAULT 'default',
    arousal       REAL NOT NULL DEFAULT 0.500,
    attention     REAL NOT NULL DEFAULT 0.500,
    learning_mode REAL NOT NULL DEFAULT 0.500,
    stability     REAL NOT NULL DEFAULT 0.700,
    run_mode      TEXT DEFAULT 'normal',
    update_time   TEXT NOT NULL
);

-- ============================================================
-- 表7: neuron_personality 人格特征表 (大五模型)
-- ============================================================
CREATE TABLE IF NOT EXISTS neuron_personality (
    instance_id   TEXT PRIMARY KEY DEFAULT 'default',
    openness      REAL NOT NULL DEFAULT 0.500,
    conscientiousness REAL NOT NULL DEFAULT 0.500,
    extraversion REAL NOT NULL DEFAULT 0.500,
    agreeableness REAL NOT NULL DEFAULT 0.500,
    neuroticism   REAL NOT NULL DEFAULT 0.500,
    update_time   TEXT NOT NULL
);

-- ============================================================
-- 表8: neuron_emotion_log 情绪日志表 (VAD三维)
-- ============================================================
CREATE TABLE IF NOT EXISTS neuron_emotion_log (
    log_id        TEXT PRIMARY KEY,
    valence       REAL NOT NULL DEFAULT 0.0,
    arousal       REAL NOT NULL DEFAULT 0.0,
    dominance     REAL NOT NULL DEFAULT 0.0,
    trigger_type  TEXT,
    trigger_id    TEXT,
    created_at    TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_emotion_created ON neuron_emotion_log(created_at);

-- ============================================================
-- 表9: neuron_goal 目标表
-- ============================================================
CREATE TABLE IF NOT EXISTS neuron_goal (
    goal_id       TEXT PRIMARY KEY,
    goal_type     TEXT NOT NULL DEFAULT 'task',
    content       TEXT NOT NULL,
    priority      INTEGER NOT NULL DEFAULT 5,
    status        TEXT NOT NULL DEFAULT 'active',
    progress      REAL NOT NULL DEFAULT 0.0,
    deadline      TEXT,
    create_time   TEXT NOT NULL,
    update_time   TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_goal_status ON neuron_goal(status);
CREATE INDEX IF NOT EXISTS idx_goal_priority ON neuron_goal(priority DESC);

-- ============================================================
-- 表10: memory_consolidation_log 记忆巩固日志表
-- ============================================================
CREATE TABLE IF NOT EXISTS memory_consolidation_log (
    log_id        TEXT PRIMARY KEY,
    source_atom_id TEXT NOT NULL,
    from_grade    TEXT NOT NULL,
    to_grade      TEXT NOT NULL,
    trigger_reason TEXT NOT NULL,
    created_at    TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_consolidation_created ON memory_consolidation_log(created_at);

-- ============================================================
-- 表11: reward_signal_log 奖励信号日志表
-- ============================================================
CREATE TABLE IF NOT EXISTS reward_signal_log (
    log_id        TEXT PRIMARY KEY,
    task_id       TEXT NOT NULL,
    quality_score REAL NOT NULL,
    expected_value REAL NOT NULL,
    rpe           REAL NOT NULL,
    dopamine_level REAL NOT NULL,
    created_at    TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_reward_task ON reward_signal_log(task_id);
CREATE INDEX IF NOT EXISTS idx_reward_created ON reward_signal_log(created_at);

-- ============================================================
-- 表12: neuron_anomaly_log 异常检测日志表
-- ============================================================
CREATE TABLE IF NOT EXISTS neuron_anomaly_log (
    log_id        TEXT PRIMARY KEY,
    anomaly_type  TEXT NOT NULL,
    severity      TEXT NOT NULL DEFAULT 'warning',
    metrics       TEXT DEFAULT '{}',
    action_taken  TEXT DEFAULT 'none',
    resolved      INTEGER NOT NULL DEFAULT 0,
    created_at    TEXT NOT NULL,
    resolved_at   TEXT
);

CREATE INDEX IF NOT EXISTS idx_anomaly_resolved ON neuron_anomaly_log(resolved);

-- ============================================================
-- 表13: instance_sync_log 实例同步日志表
-- ============================================================
CREATE TABLE IF NOT EXISTS instance_sync_log (
    log_id        TEXT PRIMARY KEY,
    source_instance TEXT NOT NULL,
    target_instance TEXT NOT NULL,
    sync_type     TEXT NOT NULL,
    data_hash     TEXT,
    conflict_resolved INTEGER NOT NULL DEFAULT 0,
    created_at    TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sync_created ON instance_sync_log(created_at);

-- ============================================================
-- 表14: neuron_config_snapshot 配置快照表
-- ============================================================
CREATE TABLE IF NOT EXISTS neuron_config_snapshot (
    snapshot_id   TEXT PRIMARY KEY,
    config_json   TEXT NOT NULL,
    trigger       TEXT NOT NULL DEFAULT 'manual',
    create_time   TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_config_created ON neuron_config_snapshot(create_time);
"""


# ============================================================
# ORM风格数据访问对象
# ============================================================

@dataclass
class NeuronRow:
    """neuron_base 行映射"""
    neuron_id: str
    neuron_type: str = "skill"
    domain_tag: str = "通用"
    state: str = "静默"
    base_threshold: float = 0.600
    dynamic_threshold: float = 0.600
    membrane_potential: float = 0.000
    rest_potential: float = 0.000
    leak_factor: float = 0.950
    excitation_factor: float = 1.000
    inhibition_factor: float = 1.000
    learning_rate: float = 1.000
    signal_gain: float = 1.000
    awareness_level: float = 0.500
    memory_sub_type: Optional[str] = None
    memory_grade: str = "temp"
    memory_capacity: Optional[int] = None
    is_consolidated: bool = False
    task_pattern_hash: Optional[str] = None
    description: str = ""
    timeout_ms: int = 30000
    instance_id: str = "default"
    activate_times: int = 0
    success_count: int = 0
    error_count: int = 0
    last_activate_ts: int = 0
    breaker_open_ts: int = 0
    version: int = 1
    create_time: str = ""
    update_time: str = ""

    @classmethod
    def from_dict(cls, d: dict) -> "NeuronRow":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class SynapseRow:
    """neuron_synapse 行映射"""
    source_id: str
    target_id: str
    weight: float = 0.500
    signal_type: str = "excitation"
    created_at: str = ""
    last_stdp_ts: int = 0
    version: int = 1

    @classmethod
    def from_dict(cls, d: dict) -> "SynapseRow":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class MemoryAtomRow:
    """memory_atom 行映射"""
    content: str
    atom_id: str = ""
    memory_type: str = "episodic"
    domain_tag: str = "通用"
    grade: str = "temp"
    access_count: int = 0
    importance: float = 0.500
    emotion_valence: float = 0.0
    emotion_arousal: float = 0.0
    keywords: str = "[]"
    related_ids: str = "[]"
    consolidate_log_id: Optional[str] = None
    create_time: str = ""
    update_time: str = ""

    @classmethod
    def from_dict(cls, d: dict) -> "MemoryAtomRow":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


class NeuronDB:
    """
    神经元引擎数据库管理器
    SQLite后端 (线程安全，支持多实例)
    """

    def __init__(self, db_path: str = ":memory:"):
        self._db_path = db_path
        self._local = threading.local()
        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn") or self._local.conn is None:
            conn = sqlite3.connect(self._db_path, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA foreign_keys=ON")
            self._local.conn = conn
        return self._local.conn

    def _init_db(self):
        conn = self._get_conn()
        conn.executescript(DDL_SQLITE)
        conn.commit()

    def close(self):
        if hasattr(self._local, "conn") and self._local.conn:
            self._local.conn.close()
            self._local.conn = None

    # ----------------------------------------------------------
    # neuron_base CRUD
    # ----------------------------------------------------------

    def insert_neuron(self, row: NeuronRow) -> str:
        now = datetime.now().isoformat()
        if not row.create_time:
            row.create_time = now
        if not row.update_time:
            row.update_time = now
        if not row.neuron_id:
            row.neuron_id = f"N-{uuid.uuid4().hex[:8]}"

        conn = self._get_conn()
        conn.execute("""
            INSERT OR REPLACE INTO neuron_base (
                neuron_id, neuron_type, domain_tag, state,
                base_threshold, dynamic_threshold, membrane_potential,
                rest_potential, leak_factor, excitation_factor, inhibition_factor,
                learning_rate, signal_gain, awareness_level,
                memory_sub_type, memory_grade, memory_capacity, is_consolidated,
                task_pattern_hash, description, timeout_ms, instance_id,
                activate_times, success_count, error_count,
                last_activate_ts, breaker_open_ts, version,
                create_time, update_time
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            row.neuron_id, row.neuron_type, row.domain_tag, row.state,
            row.base_threshold, row.dynamic_threshold, row.membrane_potential,
            row.rest_potential, row.leak_factor, row.excitation_factor, row.inhibition_factor,
            row.learning_rate, row.signal_gain, row.awareness_level,
            row.memory_sub_type, row.memory_grade, row.memory_capacity, int(row.is_consolidated),
            row.task_pattern_hash, row.description, row.timeout_ms, row.instance_id,
            row.activate_times, row.success_count, row.error_count,
            row.last_activate_ts, row.breaker_open_ts, row.version,
            row.create_time, row.update_time
        ))
        conn.commit()
        return row.neuron_id

    def get_neuron(self, neuron_id: str) -> Optional[NeuronRow]:
        conn = self._get_conn()
        row = conn.execute(
            "SELECT * FROM neuron_base WHERE neuron_id = ?", (neuron_id,)
        ).fetchone()
        if row is None:
            return None
        return NeuronRow.from_dict(dict(row))

    def list_neurons(self, neuron_type: str = None, domain_tag: str = None,
                     state: str = None, limit: int = 100) -> List[NeuronRow]:
        conn = self._get_conn()
        clauses = []
        params = []
        if neuron_type:
            clauses.append("neuron_type = ?")
            params.append(neuron_type)
        if domain_tag:
            clauses.append("domain_tag = ?")
            params.append(domain_tag)
        if state:
            clauses.append("state = ?")
            params.append(state)

        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        params.append(limit)

        rows = conn.execute(
            f"SELECT * FROM neuron_base{where} ORDER BY update_time DESC LIMIT ?",
            params
        ).fetchall()
        return [NeuronRow.from_dict(dict(r)) for r in rows]

    def update_neuron(self, neuron_id: str, updates: Dict[str, Any]) -> bool:
        if not updates:
            return False
        updates["update_time"] = datetime.now().isoformat()
        updates["version"] = (updates.get("version") or 0) + 1

        set_clause = ", ".join(f"{k} = ?" for k in updates)
        params = list(updates.values()) + [neuron_id]
        conn = self._get_conn()
        cursor = conn.execute(
            f"UPDATE neuron_base SET {set_clause} WHERE neuron_id = ?", params
        )
        conn.commit()
        return cursor.rowcount > 0

    def delete_neuron(self, neuron_id: str) -> bool:
        conn = self._get_conn()
        cursor = conn.execute("DELETE FROM neuron_base WHERE neuron_id = ?", (neuron_id,))
        conn.execute("DELETE FROM neuron_synapse WHERE source_id = ? OR target_id = ?", (neuron_id, neuron_id))
        conn.commit()
        return cursor.rowcount > 0

    # ----------------------------------------------------------
    # neuron_synapse CRUD
    # ----------------------------------------------------------

    def insert_synapse(self, row: SynapseRow) -> str:
        now = datetime.now().isoformat()
        if not row.created_at:
            row.created_at = now
        synapse_id = f"SYN-{uuid.uuid4().hex[:8]}"

        conn = self._get_conn()
        # Check if exists (upsert)
        existing = conn.execute(
            "SELECT synapse_id FROM neuron_synapse WHERE source_id = ? AND target_id = ?",
            (row.source_id, row.target_id)
        ).fetchone()

        if existing:
            conn.execute("""
                UPDATE neuron_synapse SET weight = ?, signal_type = ?,
                    last_stdp_ts = ?, version = version + 1
                WHERE source_id = ? AND target_id = ?
            """, (row.weight, row.signal_type, row.last_stdp_ts, row.source_id, row.target_id))
            synapse_id = existing["synapse_id"]
        else:
            conn.execute("""
                INSERT INTO neuron_synapse (synapse_id, source_id, target_id, weight, signal_type, created_at, last_stdp_ts, version)
                VALUES (?,?,?,?,?,?,?,?)
            """, (synapse_id, row.source_id, row.target_id, row.weight, row.signal_type, row.created_at, row.last_stdp_ts, row.version))

        conn.commit()
        return synapse_id

    def get_synapse(self, source_id: str, target_id: str) -> Optional[SynapseRow]:
        conn = self._get_conn()
        row = conn.execute(
            "SELECT * FROM neuron_synapse WHERE source_id = ? AND target_id = ?",
            (source_id, target_id)
        ).fetchone()
        if row is None:
            return None
        return SynapseRow.from_dict(dict(row))

    # ----------------------------------------------------------
    # memory_atom CRUD
    # ----------------------------------------------------------

    def insert_memory_atom(self, row: MemoryAtomRow) -> str:
        now = datetime.now().isoformat()
        if not row.create_time:
            row.create_time = now
        if not row.update_time:
            row.update_time = now
        if not row.atom_id:
            row.atom_id = f"ATOM-{uuid.uuid4().hex[:8]}"

        conn = self._get_conn()
        conn.execute("""
            INSERT INTO memory_atom (
                atom_id, content, memory_type, domain_tag, grade,
                access_count, importance, emotion_valence, emotion_arousal,
                keywords, related_ids, consolidate_log_id,
                create_time, update_time
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            row.atom_id, row.content, row.memory_type, row.domain_tag, row.grade,
            row.access_count, row.importance, row.emotion_valence, row.emotion_arousal,
            row.keywords, row.related_ids, row.consolidate_log_id,
            row.create_time, row.update_time,
        ))
        conn.commit()
        return row.atom_id

    def get_memory_atom(self, atom_id: str) -> Optional[MemoryAtomRow]:
        conn = self._get_conn()
        row = conn.execute(
            "SELECT * FROM memory_atom WHERE atom_id = ?", (atom_id,)
        ).fetchone()
        if row is None:
            return None
        return MemoryAtomRow.from_dict(dict(row))

    def search_memory_atoms(self, domain_tag: str = None, keyword: str = None,
                            grade: str = None, limit: int = 20) -> List[MemoryAtomRow]:
        conn = self._get_conn()
        clauses = []
        params = []
        if domain_tag:
            clauses.append("domain_tag = ?")
            params.append(domain_tag)
        if grade:
            clauses.append("grade = ?")
            params.append(grade)
        if keyword:
            clauses.append("keywords LIKE ?")
            params.append(f'%"{keyword}"%')

        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        params.append(limit)

        rows = conn.execute(
            f"SELECT * FROM memory_atom{where} ORDER BY update_time DESC LIMIT ?",
            params
        ).fetchall()
        return [MemoryAtomRow.from_dict(dict(r)) for r in rows]

    def promote_atom(self, atom_id: str, new_grade: str, reason: str = "") -> bool:
        valid_grades = ["temp", "short_term", "long_term", "permanent"]
        if new_grade not in valid_grades:
            return False
        conn = self._get_conn()
        cursor = conn.execute(
            "UPDATE memory_atom SET grade = ?, update_time = ? WHERE atom_id = ?",
            (new_grade, datetime.now().isoformat(), atom_id)
        )
        # Log promotion
        if cursor.rowcount > 0:
            old = conn.execute("SELECT grade FROM memory_atom WHERE atom_id = ?", (atom_id,)).fetchone()
            old_grade = old["grade"] if old else "temp"
            log_id = f"CL-{uuid.uuid4().hex[:8]}"
            conn.execute("""
                INSERT INTO memory_consolidation_log (log_id, source_atom_id, from_grade, to_grade, trigger_reason, created_at)
                VALUES (?,?,?,?,?,?)
            """, (log_id, atom_id, old_grade, new_grade, reason or "manual_promote", datetime.now().isoformat()))
        conn.commit()
        return cursor.rowcount > 0

    # ----------------------------------------------------------
    # signal_log
    # ----------------------------------------------------------

    def log_signal(self, signal_id: str, signal_type: str, source_id: str,
                   target_id: str, intensity: float, priority: int = 0) -> str:
        log_id = f"SLOG-{uuid.uuid4().hex[:8]}"
        conn = self._get_conn()
        conn.execute("""
            INSERT INTO signal_log (log_id, signal_id, signal_type, source_id, target_id, intensity, priority, created_at)
            VALUES (?,?,?,?,?,?,?,?)
        """, (log_id, signal_id, signal_type, source_id, target_id, intensity, priority, datetime.now().isoformat()))
        conn.commit()
        return log_id

    def update_signal_log(self, log_id: str, status: str, duration_ms: int = None,
                          error_msg: str = None):
        conn = self._get_conn()
        conn.execute("""
            UPDATE signal_log SET status = ?, processed_at = ?, duration_ms = ?, error_msg = ?
            WHERE log_id = ?
        """, (status, datetime.now().isoformat(), duration_ms, error_msg, log_id))
        conn.commit()

    # ----------------------------------------------------------
    # task_workflow
    # ----------------------------------------------------------

    def create_workflow(self, task_id: str, task_input: Any = None) -> str:
        workflow_id = f"WF-{uuid.uuid4().hex[:8]}"
        conn = self._get_conn()
        conn.execute("""
            INSERT INTO task_workflow (workflow_id, task_id, task_input, start_time)
            VALUES (?,?,?,?)
        """, (workflow_id, task_id, json.dumps(task_input) if task_input else None, datetime.now().isoformat()))
        conn.commit()
        return workflow_id

    def update_workflow(self, workflow_id: str, current_step: int = None,
                        status: str = None, step_results: Dict = None):
        conn = self._get_conn()
        sets = []
        params = []
        if current_step is not None:
            sets.append("current_step = ?")
            params.append(current_step)
        if status:
            sets.append("status = ?")
            params.append(status)
        if step_results:
            sets.append("step_results = ?")
            params.append(json.dumps(step_results))
        if sets:
            params.append(workflow_id)
            conn.execute(f"UPDATE task_workflow SET {', '.join(sets)} WHERE workflow_id = ?", params)
            conn.commit()

    def get_workflow(self, workflow_id: str) -> Optional[Dict]:
        conn = self._get_conn()
        row = conn.execute(
            "SELECT * FROM task_workflow WHERE workflow_id = ?", (workflow_id,)
        ).fetchone()
        if row is None:
            return None
        d = dict(row)
        if d.get("step_results"):
            d["step_results"] = json.loads(d["step_results"])
        return d

    # ----------------------------------------------------------
    # global_state
    # ----------------------------------------------------------

    def save_global_state(self, instance_id: str, arousal: float, attention: float,
                          learning_mode: float, stability: float, run_mode: str):
        conn = self._get_conn()
        conn.execute("""
            INSERT OR REPLACE INTO neuron_global_state (instance_id, arousal, attention, learning_mode, stability, run_mode, update_time)
            VALUES (?,?,?,?,?,?,?)
        """, (instance_id, arousal, attention, learning_mode, stability, run_mode, datetime.now().isoformat()))
        conn.commit()

    def get_global_state(self, instance_id: str = "default") -> Optional[Dict]:
        conn = self._get_conn()
        row = conn.execute(
            "SELECT * FROM neuron_global_state WHERE instance_id = ?", (instance_id,)
        ).fetchone()
        return dict(row) if row else None

    # ----------------------------------------------------------
    # reward_log
    # ----------------------------------------------------------

    def log_reward(self, task_id: str, quality_score: float, expected_value: float,
                   rpe: float, dopamine_level: float) -> str:
        log_id = f"REW-{uuid.uuid4().hex[:8]}"
        conn = self._get_conn()
        conn.execute("""
            INSERT INTO reward_signal_log (log_id, task_id, quality_score, expected_value, rpe, dopamine_level, created_at)
            VALUES (?,?,?,?,?,?,?)
        """, (log_id, task_id, quality_score, expected_value, rpe, dopamine_level, datetime.now().isoformat()))
        conn.commit()
        return log_id

    # ----------------------------------------------------------
    # config_snapshot
    # ----------------------------------------------------------

    def save_config_snapshot(self, config_json: str, trigger: str = "manual") -> str:
        snapshot_id = f"CFG-{uuid.uuid4().hex[:8]}"
        conn = self._get_conn()
        conn.execute("""
            INSERT INTO neuron_config_snapshot (snapshot_id, config_json, trigger, create_time)
            VALUES (?,?,?,?)
        """, (snapshot_id, config_json, trigger, datetime.now().isoformat()))
        conn.commit()
        return snapshot_id

    def get_latest_snapshot(self) -> Optional[Dict]:
        conn = self._get_conn()
        row = conn.execute(
            "SELECT * FROM neuron_config_snapshot ORDER BY create_time DESC LIMIT 1"
        ).fetchone()
        return dict(row) if row else None

    # ----------------------------------------------------------
    # stats
    # ----------------------------------------------------------

    def get_stats(self) -> Dict[str, Any]:
        conn = self._get_conn()
        return {
            "total_neurons": conn.execute("SELECT COUNT(*) FROM neuron_base").fetchone()[0],
            "total_synapses": conn.execute("SELECT COUNT(*) FROM neuron_synapse").fetchone()[0],
            "total_memory_atoms": conn.execute("SELECT COUNT(*) FROM memory_atom").fetchone()[0],
            "total_workflows": conn.execute("SELECT COUNT(*) FROM task_workflow").fetchone()[0],
            "total_signals": conn.execute("SELECT COUNT(*) FROM signal_log").fetchone()[0],
            "total_rewards": conn.execute("SELECT COUNT(*) FROM reward_signal_log").fetchone()[0],
        }
