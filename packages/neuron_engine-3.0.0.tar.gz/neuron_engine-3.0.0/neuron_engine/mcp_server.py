"""
MCP Server适配器 — v3.0生态扩展
将Neuron Engine作为MCP Server暴露给Claude/OpenAI等Agent平台
基于stdio传输协议，零外部依赖
"""

from __future__ import annotations

import json
import sys
import traceback
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Callable
import logging


# ============================================================
# MCP协议工具定义
# ============================================================

@dataclass
class MCPTool:
    """MCP工具定义"""
    name: str
    description: str
    input_schema: Dict[str, Any]
    handler: Callable[[Dict[str, Any]], Any]


def _json_schema_type(py_type: type) -> str:
    """Python类型 -> JSON Schema类型映射"""
    mapping = {
        str: "string",
        int: "integer",
        float: "number",
        bool: "boolean",
        list: "array",
        dict: "object",
    }
    return mapping.get(py_type, "string")


# ============================================================
# MCP Server实现
# ============================================================

class NeuronMCPServer:
    """
    Neuron Engine MCP Server
    
    基于JSON-RPC over stdio协议，与Claude/OpenAI等Agent平台集成。
    
    协议格式:
    - 请求: {"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}
    - 响应: {"jsonrpc":"2.0","id":1,"result":{"tools":[...]}}
    """
    
    PROTOCOL_VERSION = "2024-11-05"
    SERVER_NAME = "neuron-engine"
    SERVER_VERSION = "3.0.0"
    
    def __init__(self, engine=None):
        """
        初始化MCP Server
        
        Args:
            engine: NeuronEngine实例 (可选，延迟绑定)
        """
        self._engine = engine
        self._tools: Dict[str, MCPTool] = {}
        self._resources: Dict[str, Dict] = {}
        self._request_id = 0
        
        # 注册默认工具
        self._register_default_tools()
    
    def bind_engine(self, engine) -> None:
        """绑定NeuronEngine实例"""
        self._engine = engine
    
    def register_tool(self, tool: MCPTool) -> None:
        """注册工具"""
        self._tools[tool.name] = tool
    
    def register_tool_simple(
        self,
        name: str,
        description: str,
        params: Dict[str, str],  # {param_name: "description"}
        handler: Callable[[Dict[str, Any]], Any],
    ) -> None:
        """
        简化工具注册
        
        Args:
            name: 工具名
            description: 描述
            params: 参数描述 {参数名: 参数说明}
            handler: 处理函数
        """
        properties = {}
        required = []
        for pname, pdesc in params.items():
            properties[pname] = {
                "type": "string",
                "description": pdesc,
            }
            required.append(pname)
        
        tool = MCPTool(
            name=name,
            description=description,
            input_schema={
                "type": "object",
                "properties": properties,
                "required": required,
            },
            handler=handler,
        )
        self.register_tool(tool)
    
    def _register_default_tools(self) -> None:
        """注册默认工具集"""
        
        # 1. execute_task — 执行任务
        self.register_tool_simple(
            name="neuron_execute_task",
            description="通过类脑神经元引擎执行任务（10步闭环工作流）",
            params={
                "task_input": "任务输入文本",
                "priority": "任务优先级(0-10, 默认0)",
            },
            handler=self._handle_execute_task,
        )
        
        # 2. register_skill — 注册技能
        self.register_tool_simple(
            name="neuron_register_skill",
            description="注册一个新的技能神经元到引擎中",
            params={
                "name": "技能名称",
                "domain_tag": "领域标签",
                "description": "技能描述",
            },
            handler=self._handle_register_skill,
        )
        
        # 3. activate_neuron — 激活神经元
        self.register_tool_simple(
            name="neuron_activate",
            description="手动激活指定神经元",
            params={
                "neuron_id": "神经元ID",
            },
            handler=self._handle_activate,
        )
        
        # 4. query_memory — 查询记忆
        self.register_tool_simple(
            name="neuron_query_memory",
            description="从层级记忆系统中检索记忆",
            params={
                "keyword": "关键词",
                "domain_tag": "领域标签(可选)",
            },
            handler=self._handle_query_memory,
        )
        
        # 5. get_governance_state — 获取全局调控状态
        self.register_tool_simple(
            name="neuron_governance_state",
            description="获取引擎的全局调控状态(觉醒/注意/学习/稳定/人格/情绪)",
            params={},
            handler=self._handle_governance_state,
        )
        
        # 6. get_engine_stats — 获取引擎统计
        self.register_tool_simple(
            name="neuron_stats",
            description="获取引擎运行统计(神经元数/突触数/记忆数/任务成功率等)",
            params={},
            handler=self._handle_stats,
        )
    
    # --- 默认工具处理器 ---
    
    def _handle_execute_task(self, params: Dict[str, Any]) -> str:
        if not self._engine:
            return json.dumps({"error": "Engine not bound"}, ensure_ascii=False)
        result = self._engine.execute_task(
            params.get("task_input", ""),
            priority=int(params.get("priority", 0)),
        )
        return json.dumps(result.to_dict(), ensure_ascii=False, default=str)
    
    def _handle_register_skill(self, params: Dict[str, Any]) -> str:
        if not self._engine:
            return json.dumps({"error": "Engine not bound"}, ensure_ascii=False)
        nid = self._engine.register_neuron(
            neuron_type="skill",
            domain_tag=params.get("domain_tag", "general"),
            description=params.get("description", ""),
        )
        return json.dumps({"neuron_id": nid, "status": "registered"}, ensure_ascii=False)
    
    def _handle_activate(self, params: Dict[str, Any]) -> str:
        if not self._engine:
            return json.dumps({"error": "Engine not bound"}, ensure_ascii=False)
        try:
            result = self._engine.activate_neuron(params["neuron_id"])
            return json.dumps({"status": "activated", "result": result}, ensure_ascii=False, default=str)
        except Exception as e:
            return json.dumps({"error": str(e)}, ensure_ascii=False)
    
    def _handle_query_memory(self, params: Dict[str, Any]) -> str:
        if not self._engine:
            return json.dumps({"error": "Engine not bound"}, ensure_ascii=False)
        results = self._engine.memory.search(
            keyword=params.get("keyword", ""),
            domain_tag=params.get("domain_tag", ""),
        )
        return json.dumps(
            [{"content": a.content, "grade": a.memory_grade, "access_count": a.access_count} for a in results],
            ensure_ascii=False,
        )
    
    def _handle_governance_state(self, params: Dict[str, Any]) -> str:
        if not self._engine:
            return json.dumps({"error": "Engine not bound"}, ensure_ascii=False)
        gs = self._engine.governance.global_state
        p = self._engine.governance.personality
        e = self._engine.governance.emotion
        return json.dumps({
            "global_state": {
                "arousal": gs.arousal, "attention": gs.attention,
                "learning_mode": gs.learning_mode, "stability": gs.stability,
            },
            "personality": {
                "openness": p.openness, "conscientiousness": p.conscientiousness,
                "extraversion": p.extraversion, "agreeableness": p.agreeableness,
                "neuroticism": p.neuroticism,
            },
            "emotion": {
                "valence": e.valence, "arousal": e.arousal,
                "dominance": e.dominance, "primary_emotion": e.primary_emotion,
            },
            "run_mode": self._engine.governance.run_mode,
        }, ensure_ascii=False, default=str)
    
    def _handle_stats(self, params: Dict[str, Any]) -> str:
        if not self._engine:
            return json.dumps({"error": "Engine not bound"}, ensure_ascii=False)
        return json.dumps(self._engine.get_status(), ensure_ascii=False, default=str)
    
    # ============================================================
    # JSON-RPC消息处理
    # ============================================================
    
    def handle_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """
        处理单个JSON-RPC请求
        
        支持的方法:
        - initialize: 握手
        - tools/list: 列出工具
        - tools/call: 调用工具
        - resources/list: 列出资源
        """
        method = request.get("method", "")
        req_id = request.get("id")
        params = request.get("params", {})
        
        try:
            if method == "initialize":
                return self._respond(req_id, {
                    "protocolVersion": self.PROTOCOL_VERSION,
                    "capabilities": {"tools": {"listChanged": False}},
                    "serverInfo": {
                        "name": self.SERVER_NAME,
                        "version": self.SERVER_VERSION,
                    },
                })
            
            elif method == "notifications/initialized":
                return {}  # 通知无响应
            
            elif method == "tools/list":
                tools = [
                    {
                        "name": t.name,
                        "description": t.description,
                        "inputSchema": t.input_schema,
                    }
                    for t in self._tools.values()
                ]
                return self._respond(req_id, {"tools": tools})
            
            elif method == "tools/call":
                tool_name = params.get("name", "")
                arguments = params.get("arguments", {})
                return self._call_tool(req_id, tool_name, arguments)
            
            elif method == "resources/list":
                return self._respond(req_id, {"resources": list(self._resources.values())})
            
            elif method == "ping":
                return self._respond(req_id, {})
            
            else:
                return self._error(req_id, -32601, f"Method not found: {method}")
        
        except Exception as e:
            traceback.print_exc(file=sys.stderr)
            return self._error(req_id, -32603, f"Internal error: {e}")
    
    def _call_tool(self, req_id: Any, tool_name: str, arguments: Dict) -> Dict:
        """调用工具"""
        tool = self._tools.get(tool_name)
        if not tool:
            return self._error(req_id, -32602, f"Unknown tool: {tool_name}")
        
        try:
            result = tool.handler(arguments)
            # 自动序列化: dict/list -> JSON字符串, 其他 -> str
            if isinstance(result, (dict, list)):
                text = json.dumps(result, ensure_ascii=False, default=str)
            else:
                text = str(result)
            return self._respond(req_id, {
                "content": [
                    {"type": "text", "text": text}
                ],
            })
        except Exception as e:
            return self._error(req_id, -32603, f"Tool error: {e}")
    
    def _respond(self, req_id: Any, result: Any) -> Dict:
        return {"jsonrpc": "2.0", "id": req_id, "result": result}
    
    def _error(self, req_id: Any, code: int, message: str) -> Dict:
        return {"jsonrpc": "2.0", "id": req_id, "error": {"code": code, "message": message}}
    
    # ============================================================
    # stdio运行循环
    # ============================================================
    
    def run_stdio(self) -> None:
        """
        启动stdio MCP服务器（阻塞）
        读取stdin的JSON-RPC请求，写入stdout的JSON-RPC响应
        """
        import sys
        
        sys.stderr.write(f"[Neuron MCP Server {self.SERVER_VERSION}] Starting stdio transport...\n")
        sys.stderr.flush()
        
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            
            try:
                request = json.loads(line)
                response = self.handle_request(request)
                if response:  # 通知不返回响应
                    sys.stdout.write(json.dumps(response, ensure_ascii=False) + "\n")
                    sys.stdout.flush()
            except json.JSONDecodeError as e:
                error_resp = self._error(None, -32700, f"Parse error: {e}")
                sys.stdout.write(json.dumps(error_resp, ensure_ascii=False) + "\n")
                sys.stdout.flush()


# ============================================================
# CLI入口
# ============================================================

def main():
    """MCP Server CLI入口: python -m neuron_engine.mcp"""
    from neuron_engine.workflow import NeuronEngine
    from neuron_engine.db import NeuronDB
    from neuron_engine.logging import setup_logging
    
    setup_logging(level=logging.WARNING)
    
    engine = NeuronEngine(db=NeuronDB(":memory:"))
    server = NeuronMCPServer(engine)
    server.run_stdio()


if __name__ == "__main__":
    main()
