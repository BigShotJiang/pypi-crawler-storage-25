"""
全局调控系统 (白皮书第8章 + 第10章)
四维全局状态 · 人格情绪动机 · 运行模式推断 · 拮抗约束 · 三维协同
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any, Optional, List, Tuple
import math


# 运行模式 (白皮书8.2)
class RunMode:
    DEEP_FOCUS = "deep_focus"
    EXPLORATORY = "exploration"
    RAPID_RESPONSE = "rapid_response"
    REST_CONSOLIDATE = "rest_consolidate"


@dataclass
class GlobalState:
    """四维全局状态 (白皮书8.1)"""
    arousal: float = 0.500       # 组胺→觉醒度
    attention: float = 0.500     # NE→注意力
    learning_mode: float = 0.300  # ACh→学习模式
    stability: float = 0.700     # 5-HT→稳定性
    current_mode: str = RunMode.EXPLORATORY
    update_reason: Optional[str] = None

    def update(self, **kwargs):
        """更新状态字段"""
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, k, v)

    def to_dict(self):
        return {
            "arousal": round(self.arousal, 3),
            "attention": round(self.attention, 3),
            "learning_mode": round(self.learning_mode, 3),
            "stability": round(self.stability, 3),
            "current_mode": self.current_mode,
        }

    def to_vector(self) -> List[float]:
        return [self.arousal, self.attention, self.learning_mode, self.stability]

    def clamp_all(self):
        for attr in ["arousal", "attention", "learning_mode", "stability"]:
            val = getattr(self, attr)
            setattr(self, attr, max(0.1, min(1.0, val)))


@dataclass
class Personality:
    """大五人格参数 (白皮书第10章)"""
    openness: float = 0.500
    conscientiousness: float = 0.500
    extraversion: float = 0.500
    agreeableness: float = 0.500
    neuroticism: float = 0.500

    def to_dict(self):
        return {k: round(v, 3) for k, v in self.__dict__.items()}

    def threshold_adjustment(self) -> float:
        """人格对阈值的影响 (外向性高 -> 低阈值)"""
        return -0.1 * (self.extraversion - 0.5)

    def adapt(self, dopamine: float = 0.0, novelty: float = 0.0):
        """人格微调 (由调控信号驱动)"""
        self.openness += novelty * 0.01
        self.openness = max(0.1, min(1.0, self.openness))
        self.neuroticism -= dopamine * 0.01
        self.neuroticism = max(0.1, min(1.0, self.neuroticism))


@dataclass
class EmotionState:
    """情绪状态 VAD模型 (白皮书第10章)"""
    valence: float = 0.0       # 效价
    arousal: float = 0.500     # 唤醒
    dominance: float = 0.500   # 自信/控制感 (测试兼容)
    confidence: float = 0.700  # 自信心
    trigger_type: Optional[str] = None
    primary_emotion: str = "平静"

    def to_dict(self):
        return {
            "valence": round(self.valence, 3),
            "arousal": round(self.arousal, 3),
            "dominance": round(self.dominance, 3),
            "primary_emotion": self.primary_emotion,
        }

    def update_from_rpe(self, rpe: float):
        """由RPE奖励预测误差更新情绪"""
        self.valence += rpe * 0.3
        self.valence = max(-1.0, min(1.0, self.valence))
        self.arousal += abs(rpe) * 0.2
        self.arousal = max(0.1, min(1.0, self.arousal))
        self._update_primary_emotion()

    def _update_primary_emotion(self):
        """根据VAD推断主要情绪"""
        if self.valence > 0.3 and self.arousal > 0.6:
            self.primary_emotion = "兴奋"
        elif self.valence > 0.3:
            self.primary_emotion = "愉快"
        elif self.valence < -0.3 and self.arousal > 0.6:
            self.primary_emotion = "焦虑"
        elif self.valence < -0.3:
            self.primary_emotion = "悲伤"
        elif self.arousal < 0.2:
            self.primary_emotion = "平静"
        else:
            self.primary_emotion = "放松"


class GovernanceSystem:
    """
    全局调控系统 (白皮书第8章)
    四维状态自适应 + 运行模式推断 + 递质拮抗约束 + 三维协同
    """

    def __init__(self):
        self.state = GlobalState()
        self.personality = Personality()
        self.emotion = EmotionState()
        self._system_load = 0.0
        self._idle_ms = 0
        self._mode_confidence = 0.5
        self.run_mode = "normal"

    def infer_mode(self):
        """推断运行模式 (白皮书8.2)"""
        gs = self.state
        if gs.arousal > 0.7 and gs.attention > 0.7 and gs.stability > 0.6:
            self.run_mode = "deep_focus"
            gs.current_mode = RunMode.DEEP_FOCUS
        elif gs.arousal > 0.6 and gs.learning_mode > 0.6:
            self.run_mode = "exploration"
            gs.current_mode = RunMode.EXPLORATORY
        elif gs.arousal > 0.8 and gs.stability < 0.4:
            self.run_mode = "rapid_response"
            gs.current_mode = RunMode.RAPID_RESPONSE
        else:
            self.run_mode = "rest_consolidate"
            gs.current_mode = RunMode.REST_CONSOLIDATE

    def apply_modulation(self, signal):
        """应用调控信号"""
        if not hasattr(signal, 'modulation_type') or signal.modulation_type is None:
            return
        mt = signal.modulation_type
        mt_str = mt.value if hasattr(mt, 'value') else str(mt)
        intensity = getattr(signal, 'intensity', 0.5)

        if 'dopamine' in mt_str:
            self.personality.adapt(dopamine=intensity)
        elif 'norepinephrine' in mt_str:
            self.state.update(attention=min(1.0, self.state.attention + intensity * 0.2))
        elif 'acetylcholine' in mt_str:
            self.state.update(learning_mode=min(1.0, self.state.learning_mode + intensity * 0.2))

    def apply_antagonist(self):
        """拮抗约束: 高attention压制stability"""
        gs = self.state
        if gs.attention > 0.8:
            gs.stability = min(gs.stability, 0.8 - (gs.attention - 0.8) * 0.5)
        if gs.arousal > 0.85:
            gs.stability = min(gs.stability, 1.0 - gs.arousal * 0.3)
        gs.clamp_all()

    def calc_synergy_vector(self):
        """三维协同向量 (白皮书V2.6)"""
        gs = self.state
        p = self.personality
        return {
            "cognition": {
                "arousal": round(gs.arousal, 3),
                "attention": round(gs.attention, 3),
                "learning_mode": round(gs.learning_mode, 3),
                "stability": round(gs.stability, 3),
            },
            "emotion": {
                "openness": round(p.openness, 3),
                "conscientiousness": round(p.conscientiousness, 3),
                "extraversion": round(p.extraversion, 3),
                "neuroticism": round(p.neuroticism, 3),
            },
            "governance": {
                "run_mode": self.run_mode,
                "mode_confidence": round(self._mode_confidence, 3),
            },
        }

    def apply_personality_effects(self) -> Dict[str, float]:
        """人格对全局状态的影响"""
        p = self.personality
        adjustments = {}
        adjustments["threshold"] = p.threshold_adjustment()
        # 高开放性 -> 提高学习模式
        adjustments["learning_mode"] = (p.openness - 0.5) * 0.1
        # 高外向性 -> 提高觉醒度
        adjustments["arousal"] = (p.extraversion - 0.5) * 0.1
        # 高尽责性 -> 提高稳定性
        adjustments["stability"] = (p.conscientiousness - 0.5) * 0.1
        return adjustments

    def compute_3d_synergy(self, memory_density: float = 0.0) -> Dict[str, Any]:
        """三维协同计算 (人格 + 调控 + 记忆)"""
        p = self.personality
        gs = self.state
        p_vec = p.to_vector() if hasattr(p, 'to_vector') else [
            p.openness, p.conscientiousness, p.extraversion,
            p.agreeableness, p.neuroticism
        ]
        g_vec = gs.to_vector()
        synergy = {
            "personality_influence": sum(p_vec) / len(p_vec),
            "governance_influence": sum(g_vec) / len(g_vec),
            "memory_density": memory_density,
            "combined": round(
                (sum(p_vec) / len(p_vec) * 0.3 +
                 sum(g_vec) / len(g_vec) * 0.4 +
                 memory_density * 0.3), 3
            ),
        }
        return synergy

    def get_full_status(self) -> Dict[str, Any]:
        """完整状态快照"""
        return {
            "global_state": self.state.to_dict(),
            "personality": self.personality.to_dict(),
            "emotion": self.emotion.to_dict(),
            "mode": self.run_mode,
        }

    @property
    def global_state(self):
        return self.state
