"""
指标采集器 — 白皮书第18章 SLI/SLO
核心指标: 引擎延迟 · 任务成功率 · 信号吞吐 · 膜电位均值
"""

import time
import threading
from collections import deque
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any


@dataclass
class MetricPoint:
    """指标数据点"""
    name: str
    value: float
    timestamp: float
    tags: Dict[str, str] = field(default_factory=dict)


class MetricsCollector:
    """
    指标采集器 (白皮书第18章)
    
    内置指标:
    - engine.task_latency_ms: 任务执行延迟
    - engine.task_success_rate: 任务成功率
    - engine.signal_throughput: 信号吞吐量
    - engine.neuron_firing_rate: 神经元点火率
    - engine.membrane_potential_avg: 平均膜电位
    - engine.memory_utilization: 记忆利用率
    """
    
    def __init__(self, history_size: int = 1000):
        self._history_size = history_size
        self._metrics: Dict[str, deque] = {}
        self._counters: Dict[str, int] = {}
        self._gauges: Dict[str, float] = {}
        self._lock = threading.Lock()

    def record(self, name: str, value: float, tags: Optional[Dict] = None):
        """记录指标数据点"""
        with self._lock:
            if name not in self._metrics:
                self._metrics[name] = deque(maxlen=self._history_size)
            self._metrics[name].append(MetricPoint(
                name=name, value=value, timestamp=time.time(),
                tags=tags or {},
            ))

    def increment(self, name: str, value: int = 1):
        """递增计数器"""
        with self._lock:
            self._counters[name] = self._counters.get(name, 0) + value

    def set_gauge(self, name: str, value: float):
        """设置仪表值"""
        with self._lock:
            self._gauges[name] = value

    def get_counter(self, name: str) -> int:
        return self._counters.get(name, 0)

    def get_gauge(self, name: str) -> float:
        return self._gauges.get(name, 0.0)

    def get_recent(self, name: str, seconds: float = 60.0) -> List[MetricPoint]:
        """获取最近N秒的指标"""
        cutoff = time.time() - seconds
        with self._lock:
            points = list(self._metrics.get(name, []))
        return [p for p in points if p.timestamp >= cutoff]

    def get_summary(self, name: str, seconds: float = 60.0) -> Dict[str, Any]:
        """获取指标摘要 (均值/最大/最小/分位数)"""
        points = self.get_recent(name, seconds)
        if not points:
            return {"name": name, "count": 0}
        values = [p.value for p in points]
        sorted_vals = sorted(values)
        n = len(sorted_vals)
        return {
            "name": name,
            "count": n,
            "mean": sum(values) / n,
            "min": sorted_vals[0],
            "max": sorted_vals[-1],
            "p50": sorted_vals[int(n * 0.5)] if n > 0 else 0,
            "p95": sorted_vals[int(n * 0.95)] if n > 0 else 0,
            "p99": sorted_vals[min(int(n * 0.99), n - 1)] if n > 0 else 0,
        }

    def get_all_summaries(self, seconds: float = 60.0) -> Dict[str, Dict]:
        """获取所有指标摘要"""
        with self._lock:
            names = list(self._metrics.keys())
        return {name: self.get_summary(name, seconds) for name in names}

    def get_counters(self) -> Dict[str, int]:
        with self._lock:
            return dict(self._counters)

    def get_gauges(self) -> Dict[str, float]:
        with self._lock:
            return dict(self._gauges)

    def record_task_latency(self, latency_ms: float):
        self.record("engine.task_latency_ms", latency_ms)

    def record_task_result(self, success: bool):
        self.increment("engine.task_total")
        if success:
            self.increment("engine.task_success")
        else:
            self.increment("engine.task_failure")

    def get_task_success_rate(self) -> float:
        total = self.get_counter("engine.task_total")
        if total == 0:
            return 1.0
        return self.get_counter("engine.task_success") / total

    def reset(self):
        """重置所有指标"""
        with self._lock:
            self._metrics.clear()
            self._counters.clear()
            self._gauges.clear()
