"""
自愈引擎 — 白皮书第15章 15.3节
自动修复策略: 熔断冷却 · 突触重置 · 记忆清理 · 阈值调节
"""

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Callable, Any
from enum import Enum

from neuron_engine.monitor.detector import AnomalyType, SeverityLevel


class HealAction(str, Enum):
    CIRCUIT_BREAK = "circuit_break"
    SYNAPSE_RESET = "synapse_reset"
    MEMORY_CLEANUP = "memory_cleanup"
    THRESHOLD_ADJUST = "threshold_adjust"
    SIGNAL_THROTTLE = "signal_throttle"
    NONE = "none"


@dataclass
class HealResult:
    """自愈结果"""
    anomaly_type: AnomalyType
    action: HealAction
    success: bool
    description: str
    executed_at: float
    metadata: Dict = field(default_factory=dict)

    def to_dict(self):
        return {
            "anomaly_type": self.anomaly_type.value,
            "action": self.action.value,
            "success": self.success,
            "description": self.description,
            "executed_at": self.executed_at,
        }


class SelfHealer:
    """
    自愈引擎 (白皮书15.3节)
    
    公理五: 自适应泄漏与自愈
    策略映射:
    - SIGNAL_STORM → signal_throttle
    - NEURON_DEADLOCK → circuit_break
    - MEMBRANE_NOISE → threshold_adjust
    - MEMORY_OVERFLOW → memory_cleanup
    - SYNAPSE_DEGRADATION → synapse_reset
    """
    
    STRATEGY_MAP = {
        AnomalyType.SIGNAL_STORM: HealAction.SIGNAL_THROTTLE,
        AnomalyType.NEURON_DEADLOCK: HealAction.CIRCUIT_BREAK,
        AnomalyType.MEMBRANE_NOISE: HealAction.THRESHOLD_ADJUST,
        AnomalyType.MEMORY_OVERFLOW: HealAction.MEMORY_CLEANUP,
        AnomalyType.SYNAPSE_DEGRADATION: HealAction.SYNAPSE_RESET,
    }
    
    def __init__(self, auto_heal: bool = True, cooldown_sec: float = 60.0):
        self.auto_heal = auto_heal
        self.cooldown_sec = cooldown_sec
        self._last_heal: Dict[str, float] = {}  # {source_id: timestamp}
        self._heal_history: List[HealResult] = []
        self._action_handlers: Dict[HealAction, Callable] = {}
        self._stats = {
            "total_heals": 0,
            "successful": 0,
            "failed": 0,
            "skipped_cooldown": 0,
        }

    def register_action(self, action: HealAction, handler: Callable):
        """注册自愈动作处理器"""
        self._action_handlers[action] = handler

    def heal(self, anomaly_type: AnomalyType, source_id: str,
             severity: SeverityLevel, metadata: Dict = None) -> HealResult:
        """
        对异常执行自愈策略
        
        规则:
        - CRITICAL 级别立即自愈
        - MEDIUM/HIGH 级别在冷却期外自动自愈
        - LOW 级别仅记录不执行
        """
        now = time.time()
        
        # LOW级别不自动修复
        if severity == SeverityLevel.LOW:
            return HealResult(
                anomaly_type=anomaly_type, action=HealAction.NONE,
                success=True, description="LOW级别仅监控不修复",
                executed_at=now,
            )
        
        # 冷却期检查
        if source_id in self._last_heal:
            elapsed = now - self._last_heal[source_id]
            if elapsed < self.cooldown_sec:
                self._stats["skipped_cooldown"] += 1
                return HealResult(
                    anomaly_type=anomaly_type, action=HealAction.NONE,
                    success=False, 
                    description=f"冷却中 ({self.cooldown_sec - elapsed:.0f}s剩余)",
                    executed_at=now,
                )
        
        # 确定策略
        action = self.STRATEGY_MAP.get(anomaly_type, HealAction.NONE)
        
        # 执行修复
        success = False
        description = ""
        handler = self._action_handlers.get(action)
        
        if handler and self.auto_heal:
            try:
                result = handler(source_id, metadata or {})
                success = result.get("success", False) if isinstance(result, dict) else bool(result)
                description = result.get("description", action.value) if isinstance(result, dict) else str(result)
            except Exception as e:
                description = f"handler_error: {e}"
                success = False
        elif self.auto_heal:
            success = True
            description = f"auto_{action.value}_applied"
        else:
            description = "auto_heal_disabled"
        
        self._last_heal[source_id] = now
        self._stats["total_heals"] += 1
        if success:
            self._stats["successful"] += 1
        else:
            self._stats["failed"] += 1
        
        result = HealResult(
            anomaly_type=anomaly_type, action=action,
            success=success, description=description,
            executed_at=now, metadata=metadata or {},
        )
        self._heal_history.append(result)
        if len(self._heal_history) > 500:
            self._heal_history = self._heal_history[-300:]
        
        return result

    def get_history(self, limit: int = 50) -> List[Dict]:
        return [r.to_dict() for r in self._heal_history[-limit:]]

    def get_stats(self) -> Dict:
        return dict(self._stats)
