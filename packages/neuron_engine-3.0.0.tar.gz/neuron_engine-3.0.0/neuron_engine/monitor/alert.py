"""
告警管理器 — 白皮书第15章 15.4节
多通道告警: 日志 · 回调 · 摘要
"""

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Callable, Any
from enum import Enum

from neuron_engine.monitor.detector import AnomalyEvent, AnomalyType, SeverityLevel


class AlertChannel(str, Enum):
    LOG = "log"
    CALLBACK = "callback"
    SUMMARY = "summary"


@dataclass
class AlertRecord:
    """告警记录"""
    alert_id: str
    anomaly_type: AnomalyType
    severity: SeverityLevel
    source_id: str
    message: str
    channels: List[str]
    created_at: float
    acknowledged: bool = False

    def to_dict(self):
        return {
            "alert_id": self.alert_id,
            "anomaly_type": self.anomaly_type.value,
            "severity": self.severity.value,
            "source_id": self.source_id,
            "message": self.message,
            "channels": self.channels,
            "created_at": self.created_at,
            "acknowledged": self.acknowledged,
        }


class AlertManager:
    """
    告警管理器 (白皮书15.4节)
    
    支持:
    1. 多通道告警 (日志/回调/摘要)
    2. 告警去重 (同源同类型冷却期)
    3. 告警确认与统计
    """
    
    def __init__(self, dedup_window_sec: float = 300.0, max_alerts: int = 1000):
        self.dedup_window = dedup_window_sec
        self.max_alerts = max_alerts
        self._alerts: List[AlertRecord] = []
        self._callbacks: Dict[str, Callable] = {}
        self._dedup_cache: Dict[str, float] = {}  # {dedup_key: timestamp}
        self._stats = {
            "total_alerts": 0,
            "deduped": 0,
            "acknowledged": 0,
        }

    def add_channel(self, name: str, callback: Callable[[AlertRecord], None]):
        """添加告警通道"""
        self._callbacks[name] = callback

    def remove_channel(self, name: str):
        self._callbacks.pop(name, None)

    def alert(self, event: AnomalyEvent, channels: Optional[List[str]] = None):
        """从异常事件生成告警"""
        # 去重检查
        dedup_key = f"{event.source_id}:{event.anomaly_type.value}"
        now = time.time()
        if dedup_key in self._dedup_cache:
            if now - self._dedup_cache[dedup_key] < self.dedup_window:
                self._stats["deduped"] += 1
                return
        self._dedup_cache[dedup_key] = now
        
        # 创建告警
        alert = AlertRecord(
            alert_id=f"A-{int(now * 1000) % 1000000:06d}",
            anomaly_type=event.anomaly_type,
            severity=event.severity,
            source_id=event.source_id,
            message=event.description,
            channels=channels or [c.value for c in AlertChannel],
            created_at=now,
        )
        
        self._alerts.append(alert)
        self._stats["total_alerts"] += 1
        
        # 分发到通道
        active_channels = channels or [c.value for c in AlertChannel]
        for ch_name in active_channels:
            callback = self._callbacks.get(ch_name)
            if callback:
                try:
                    callback(alert)
                except Exception:
                    pass
        
        # 限制数量
        if len(self._alerts) > self.max_alerts:
            self._alerts = self._alerts[-self.max_alerts:]

    def acknowledge(self, alert_id: str) -> bool:
        """确认告警"""
        for alert in self._alerts:
            if alert.alert_id == alert_id:
                alert.acknowledged = True
                self._stats["acknowledged"] += 1
                return True
        return False

    def get_alerts(self, severity: Optional[SeverityLevel] = None,
                   acknowledged: Optional[bool] = None,
                   limit: int = 50) -> List[Dict]:
        """查询告警"""
        results = self._alerts
        if severity:
            results = [a for a in results if a.severity == severity]
        if acknowledged is not None:
            results = [a for a in results if a.acknowledged == acknowledged]
        return [a.to_dict() for a in results[-limit:]]

    def get_channels(self) -> List[str]:
        """获取已注册通道"""
        return list(self._callbacks.keys())

    def get_stats(self) -> Dict:
        stats = dict(self._stats)
        stats["active_unacknowledged"] = len(
            [a for a in self._alerts if not a.acknowledged])
        return stats
