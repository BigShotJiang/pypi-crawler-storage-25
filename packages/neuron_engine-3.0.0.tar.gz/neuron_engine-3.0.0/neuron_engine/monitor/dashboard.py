"""
监控面板 — 白皮书第15章
聚合监控数据为面板视图
"""

from typing import Dict, Any, Optional
from neuron_engine.monitor.detector import AnomalyDetector
from neuron_engine.monitor.healer import SelfHealer
from neuron_engine.monitor.alert import AlertManager
from neuron_engine.monitor.metrics import MetricsCollector


class Dashboard:
    """
    监控面板 (白皮书第15章)
    
    聚合四个子系统的数据为统一视图:
    - 异常检测统计
    - 自愈执行记录
    - 告警概览
    - 核心指标
    """
    
    def __init__(self, detector: Optional[AnomalyDetector] = None,
                 healer: Optional[SelfHealer] = None,
                 alert_manager: Optional[AlertManager] = None,
                 metrics: Optional[MetricsCollector] = None):
        self.detector = detector
        self.healer = healer
        self.alert_manager = alert_manager
        self.metrics = metrics

    def get_overview(self) -> Dict[str, Any]:
        """获取监控面板总览"""
        overview = {
            "anomaly_detection": self.detector.get_stats() if self.detector else {},
            "self_healing": self.healer.get_stats() if self.healer else {},
            "alerts": self.alert_manager.get_stats() if self.alert_manager else {},
        }
        
        if self.metrics:
            overview["metrics"] = {
                "task_success_rate": round(self.metrics.get_task_success_rate(), 4),
                "task_total": self.metrics.get_counter("engine.task_total"),
                "gauges": self.metrics.get_gauges(),
                "metric_summaries": self.metrics.get_all_summaries(60),
            }
        
        return overview

    def get_health_status(self) -> Dict[str, Any]:
        """获取系统健康状态"""
        status = "healthy"
        issues = []
        
        if self.alert_manager:
            alerts = self.alert_manager.get_alerts(acknowledged=False, limit=10)
            if alerts:
                status = "degraded"
                issues.extend([a["message"] for a in alerts[:5]])
        
        if self.metrics:
            success_rate = self.metrics.get_task_success_rate()
            if success_rate < 0.8:
                status = "unhealthy"
                issues.append(f"任务成功率过低: {success_rate:.1%}")
        
        return {
            "status": status,
            "issues": issues,
            "active_alerts": len(issues),
        }
