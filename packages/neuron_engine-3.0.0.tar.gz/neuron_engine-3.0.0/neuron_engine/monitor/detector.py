"""
异常检测器 — 白皮书第15章 15.2节
三类异常检测: 信号风暴 · 神经元死锁 · 膜电位噪声
"""

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Callable
from enum import Enum


class AnomalyType(str, Enum):
    SIGNAL_STORM = "signal_storm"
    NEURON_DEADLOCK = "neuron_deadlock"
    MEMBRANE_NOISE = "membrane_noise"
    MEMORY_OVERFLOW = "memory_overflow"
    SYNAPSE_DEGRADATION = "synapse_degradation"


class SeverityLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class AnomalyEvent:
    """异常事件"""
    anomaly_type: AnomalyType
    severity: SeverityLevel
    source_id: str
    description: str
    detected_at: float
    metadata: Dict = field(default_factory=dict)
    resolved: bool = False

    def to_dict(self):
        return {
            "anomaly_type": self.anomaly_type.value,
            "severity": self.severity.value,
            "source_id": self.source_id,
            "description": self.description,
            "detected_at": self.detected_at,
            "metadata": self.metadata,
            "resolved": self.resolved,
        }


class AnomalyDetector:
    """
    异常检测器 (白皮书15.2节)
    
    检测规则:
    1. 信号风暴: 单源 >50信号/秒
    2. 神经元死锁: 膜电位>30秒无变化
    3. 膜电位噪声: 标准差 > 0.3 (1秒窗口)
    4. 记忆溢出: 活跃记忆 > 阈值
    5. 突触退化: 权重 < 0.15
    """
    
    def __init__(self,
                 storm_threshold: int = 50,
                 deadlock_timeout_sec: float = 30.0,
                 noise_std_threshold: float = 0.3,
                 memory_overflow_threshold: int = 10000):
        self.storm_threshold = storm_threshold
        self.deadlock_timeout = deadlock_timeout_sec
        self.noise_std_threshold = noise_std_threshold
        self.memory_overflow_threshold = memory_overflow_threshold
        
        # 追踪数据
        self._signal_counts: Dict[str, List[float]] = {}
        self._membrane_history: Dict[str, List[tuple]] = {}  # {id: [(timestamp, value)]}
        self._synapse_weights: Dict[str, float] = {}
        
        # 事件回调
        self._handlers: List[Callable[[AnomalyEvent], None]] = []
        
        # 统计
        self._stats = {
            "total_detected": 0,
            "storms": 0,
            "deadlocks": 0,
            "noise_events": 0,
            "memory_overflows": 0,
            "synapse_degradations": 0,
        }

    def on_anomaly(self, handler: Callable[[AnomalyEvent], None]):
        """注册异常事件处理器"""
        self._handlers.append(handler)

    def record_signal(self, source_id: str, intensity: float = 0.0):
        """记录信号事件"""
        now = time.time()
        if source_id not in self._signal_counts:
            self._signal_counts[source_id] = []
        self._signal_counts[source_id].append(now)
        # 限制长度
        if len(self._signal_counts[source_id]) > 1000:
            self._signal_counts[source_id] = self._signal_counts[source_id][-500:]
        
        # 同步检测风暴
        self._check_storm(source_id)

    def record_membrane(self, neuron_id: str, potential: float):
        """记录膜电位"""
        now = time.time()
        if neuron_id not in self._membrane_history:
            self._membrane_history[neuron_id] = []
        self._membrane_history[neuron_id].append((now, potential))
        if len(self._membrane_history[neuron_id]) > 1000:
            self._membrane_history[neuron_id] = self._membrane_history[neuron_id][-500:]
        
        self._check_deadlock(neuron_id)
        self._check_noise(neuron_id)

    def record_synapse_weight(self, synapse_key: str, weight: float):
        """记录突触权重"""
        self._synapse_weights[synapse_key] = weight

    def check_memory_overflow(self, active_memory_count: int):
        """检查记忆溢出"""
        if active_memory_count > self.memory_overflow_threshold:
            self._emit(AnomalyEvent(
                anomaly_type=AnomalyType.MEMORY_OVERFLOW,
                severity=SeverityLevel.HIGH,
                source_id="memory_system",
                description=f"活跃记忆数 {active_memory_count} 超过阈值 {self.memory_overflow_threshold}",
                detected_at=time.time(),
                metadata={"count": active_memory_count, "threshold": self.memory_overflow_threshold},
            ))

    def check_all(self) -> List[AnomalyEvent]:
        """执行全量检测"""
        events = []
        now = time.time()
        
        for sid in list(self._signal_counts.keys()):
            event = self._check_storm(sid)
            if event:
                events.append(event)
        
        for nid in list(self._membrane_history.keys()):
            event = self._check_deadlock(nid)
            if event:
                events.append(event)
            event = self._check_noise(nid)
            if event:
                events.append(event)
        
        for sk, w in list(self._synapse_weights.items()):
            if w < 0.15:
                self._emit(AnomalyEvent(
                    anomaly_type=AnomalyType.SYNAPSE_DEGRADATION,
                    severity=SeverityLevel.MEDIUM,
                    source_id=sk,
                    description=f"突触 {sk} 权重退化至 {w:.3f}",
                    detected_at=now,
                    metadata={"weight": w, "threshold": 0.15},
                ))
        
        return events

    def _check_storm(self, source_id: str) -> Optional[AnomalyEvent]:
        """检测信号风暴"""
        now = time.time()
        timeline = self._signal_counts.get(source_id, [])
        recent = [t for t in timeline if now - t < 1.0]
        count = len(recent)
        
        if count >= self.storm_threshold:
            event = AnomalyEvent(
                anomaly_type=AnomalyType.SIGNAL_STORM,
                severity=SeverityLevel.HIGH if count > self.storm_threshold * 2 else SeverityLevel.MEDIUM,
                source_id=source_id,
                description=f"信号风暴: {source_id} 频率 {count}/s",
                detected_at=now,
                metadata={"frequency": count},
            )
            self._emit(event)
            self._stats["storms"] += 1
            return event
        return None

    def _check_deadlock(self, neuron_id: str) -> Optional[AnomalyEvent]:
        """检测神经元死锁"""
        now = time.time()
        history = self._membrane_history.get(neuron_id, [])
        if len(history) < 2:
            return None
        
        recent = [(t, v) for t, v in history if now - t < self.deadlock_timeout]
        if len(recent) < 2:
            return None
        
        values = [v for _, v in recent]
        if max(values) - min(values) < 0.001:
            event = AnomalyEvent(
                anomaly_type=AnomalyType.NEURON_DEADLOCK,
                severity=SeverityLevel.CRITICAL,
                source_id=neuron_id,
                description=f"神经元死锁: {neuron_id} 膜电位 {self.deadlock_timeout}s 无变化",
                detected_at=now,
                metadata={"potential": values[-1], "duration": self.deadlock_timeout},
            )
            self._emit(event)
            self._stats["deadlocks"] += 1
            return event
        return None

    def _check_noise(self, neuron_id: str) -> Optional[AnomalyEvent]:
        """检测膜电位噪声"""
        now = time.time()
        history = self._membrane_history.get(neuron_id, [])
        recent = [(t, v) for t, v in history if now - t < 1.0]
        
        if len(recent) < 10:
            return None
        
        values = [v for _, v in recent]
        mean = sum(values) / len(values)
        variance = sum((v - mean) ** 2 for v in values) / len(values)
        std = variance ** 0.5
        
        if std > self.noise_std_threshold:
            event = AnomalyEvent(
                anomaly_type=AnomalyType.MEMBRANE_NOISE,
                severity=SeverityLevel.LOW,
                source_id=neuron_id,
                description=f"膜电位噪声: {neuron_id} std={std:.3f}",
                detected_at=now,
                metadata={"std": round(std, 4), "mean": round(mean, 4)},
            )
            self._emit(event)
            self._stats["noise_events"] += 1
            return event
        return None

    def _emit(self, event: AnomalyEvent):
        self._stats["total_detected"] += 1
        for handler in self._handlers:
            try:
                handler(event)
            except Exception:
                pass

    def get_stats(self) -> Dict:
        return dict(self._stats)

    def get_recent_events(self, limit: int = 50) -> List[Dict]:
        """暂不保留事件历史，由AlertManager负责"""
        return []
