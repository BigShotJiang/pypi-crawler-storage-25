"""日志系统测试"""
import logging
import json
from neuron_engine.logging import (
    setup_logging, get_layer_logger, NeuronJSONFormatter,
    NeuronTextFormatter, set_trace_id, get_trace_id,
    set_workflow_id, get_workflow_id,
    log_signal_emit, log_neuron_fire, log_circuit_breaker,
)
from neuron_engine.logging import LAYER_LOGGERS


class TestLayerLoggers:
    def test_get_known_layer(self):
        assert get_layer_logger("perception").name == "neuron.perception"

    def test_get_unknown_layer(self):
        assert get_layer_logger("custom").name == "neuron.custom"

    def test_all_layers_defined(self):
        assert len(LAYER_LOGGERS) >= 10


class TestContextVars:
    def test_trace_id_roundtrip(self):
        set_trace_id("TRC-test123")
        assert get_trace_id() == "TRC-test123"

    def test_workflow_id_roundtrip(self):
        set_workflow_id("WF-001")
        assert get_workflow_id() == "WF-001"


class TestJSONFormatter:
    def test_output_is_valid_json(self):
        formatter = NeuronJSONFormatter()
        record = logging.LogRecord("test", logging.INFO, "t.py", 1, "hello", None, None)
        data = json.loads(formatter.format(record))
        assert data["level"] == "INFO"
        assert data["message"] == "hello"
        assert "timestamp" in data

    def test_trace_id_in_output(self):
        set_trace_id("TRC-abc")
        formatter = NeuronJSONFormatter()
        record = logging.LogRecord("test", logging.INFO, "t.py", 1, "x", None, None)
        data = json.loads(formatter.format(record))
        assert data["trace_id"] == "TRC-abc"


class TestTextFormatter:
    def test_format_contains_fields(self):
        formatter = NeuronTextFormatter(use_color=False)
        record = logging.LogRecord("neuron.skill", logging.INFO, "t.py", 1, "fired", None, None)
        output = formatter.format(record)
        assert "INFO" in output
        assert "neuron.skill" in output


class TestSetupLogging:
    def test_setup_clears_and_adds(self):
        logger = logging.getLogger("neuron")
        logger.handlers.clear()
        setup_logging(level=logging.DEBUG, format_type="text", use_color=False)
        assert len(logger.handlers) >= 1
        logger.handlers.clear()


class TestLogHelpers:
    def test_log_signal_emit(self):
        logger = get_layer_logger("perception")
        logger.handlers = [logging.NullHandler()]
        set_trace_id("TRC-t")
        log_signal_emit("N-01", "N-02", "excitation", 0.8)
        logger.handlers.clear()

    def test_log_neuron_fire(self):
        logger = get_layer_logger("skill")
        logger.handlers = [logging.NullHandler()]
        log_neuron_fire("N-001", 0.75, 0.6)
        logger.handlers.clear()

    def test_log_circuit_breaker(self):
        logger = get_layer_logger("monitor")
        logger.handlers = [logging.NullHandler()]
        log_circuit_breaker("N-001", "open", 3)
        logger.handlers.clear()
