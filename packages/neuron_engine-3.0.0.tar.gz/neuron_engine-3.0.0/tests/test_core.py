"""
核心模型单元测试 — Signal / Neuron / Synapse
覆盖: LIF膜电位 · 三态熔断 · STDP · 权重锁定 · 调控旁路
"""

import sys
import os
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from neuron_engine.core.signal import Signal, SignalType, ModulationType
from neuron_engine.core.neuron import Neuron, COOLDOWN_MS, WEIGHT_MIN, WEIGHT_MAX
from neuron_engine.core.synapse import Synapse


class TestSignal(unittest.TestCase):
    """信号协议测试"""

    def test_create_excitation(self):
        sig = Signal.create_excitation(source="N1", target="N2", intensity=0.8)
        self.assertEqual(sig.signal_type, SignalType.EXCITATION)
        self.assertTrue(sig.is_excitation)
        self.assertFalse(sig.is_inhibition)
        self.assertFalse(sig.is_modulation)
        self.assertEqual(sig.intensity, 0.8)

    def test_create_inhibition(self):
        sig = Signal.create_inhibition(source="N1", target="N2", intensity=0.6)
        self.assertEqual(sig.signal_type, SignalType.INHIBITION)
        self.assertTrue(sig.is_inhibition)
        self.assertFalse(sig.is_excitation)

    def test_create_modulation_dopamine(self):
        sig = Signal.create_modulation(
            source="G1", target="N1", mod_type=ModulationType.DOPAMINE, intensity=0.7
        )
        self.assertTrue(sig.is_modulation)
        self.assertEqual(sig.modulation_type, ModulationType.DOPAMINE)

    def test_signal_priority(self):
        sig = Signal.create_excitation(source="N1", target="N2", intensity=0.5, priority=5)
        self.assertEqual(sig.priority, 5)

    def test_signal_auto_id(self):
        sig = Signal.create_excitation(source="N1", target="N2")
        self.assertTrue(sig.signal_id.startswith("SIG-"))

    def test_invalid_signal_type(self):
        with self.assertRaises((ValueError, TypeError)):
            Signal(signal_type="invalid_type", source_neuron_id="N1", target_neuron_id="N2")

    def test_signal_has_source_and_target(self):
        sig = Signal.create_excitation(source="SRC", target="TGT")
        self.assertEqual(sig.source_neuron_id, "SRC")
        self.assertEqual(sig.target_neuron_id, "TGT")


class TestNeuron(unittest.TestCase):
    """神经元模型测试"""

    def setUp(self):
        self.neuron = Neuron(
            neuron_id="N-TEST01",
            neuron_type="skill",
            domain_tag="test",
            base_threshold=0.6,
            leak_factor=0.95,
        )

    def test_default_state(self):
        self.assertEqual(self.neuron.state, "静默")
        self.assertEqual(self.neuron.membrane_potential, 0.0)
        self.assertEqual(self.neuron.activate_times, 0)

    def test_lif_calc_potential_excitation(self):
        """LIF: 兴奋信号应增加膜电位"""
        signals = [Signal.create_excitation(source="N1", target="N-TEST01", intensity=0.8)]
        self.neuron.calc_membrane_potential(signals)
        # V(t+1) = 0.95 * 0 + 0.05 * (0.8 * 0.5 * 1.0 * 1.0) = 0.02
        self.assertGreater(self.neuron.membrane_potential, 0.0)

    def test_lif_calc_potential_inhibition(self):
        """LIF: 抑制信号应减少膜电位"""
        signals = [Signal.create_inhibition(source="N2", target="N-TEST01", intensity=0.5)]
        self.neuron.calc_membrane_potential(signals)
        # 膜电位应>=静息电位
        self.assertGreaterEqual(self.neuron.membrane_potential, self.neuron.rest_potential)

    def test_lif_leak_decay(self):
        """公理六: 泄漏衰减永恒"""
        self.neuron.membrane_potential = 0.5
        for _ in range(100):
            self.neuron.apply_leak()
        # 100次衰减后膜电位应趋近0
        self.assertLess(self.neuron.membrane_potential, 0.01)

    def test_fire_above_threshold(self):
        """公理二: 膜电位 >= 阈值才激活"""
        self.neuron.membrane_potential = 0.7
        self.assertTrue(self.neuron.check_fire())
        self.assertEqual(self.neuron.state, "点火放电")
        self.assertEqual(self.neuron.activate_times, 1)

    def test_no_fire_below_threshold(self):
        self.neuron.membrane_potential = 0.3
        self.assertFalse(self.neuron.check_fire())
        self.assertEqual(self.neuron.state, "静默")

    def test_breaker_open_after_3_errors(self):
        """三态熔断: 3次错误后打开"""
        self.neuron.error_count = 3
        self.neuron.state = "熔断关闭"
        fired = self.neuron.check_fire()
        self.assertFalse(fired)
        self.assertEqual(self.neuron.state, "熔断打开")

    def test_breaker_half_open_after_cooldown(self):
        """三态熔断: 冷却后半开"""
        import time as _time
        self.neuron.state = "熔断打开"
        self.neuron.breaker_open_ts = int(_time.time() * 1000) - COOLDOWN_MS - 1000
        self.neuron.membrane_potential = 0.8
        # 半开时不阻止检查，但需膜电位达标
        self.assertTrue(self.neuron.check_fire())

    def test_modulation_dopamine(self):
        """调控旁路: 多巴胺调节学习速率"""
        sig = Signal.create_modulation(source="G1", target="N-TEST01", mod_type=ModulationType.DOPAMINE, intensity=0.5)
        self.neuron.calc_membrane_potential([sig])
        self.assertGreater(self.neuron.learning_rate, 1.0)

    def test_modulation_ne(self):
        """调控旁路: NE调节信号增益"""
        sig = Signal.create_modulation(source="G1", target="N-TEST01", mod_type=ModulationType.NOREPINEPHRINE, intensity=0.5)
        self.neuron.calc_membrane_potential([sig])
        self.assertGreater(self.neuron.signal_gain, 1.0)

    def test_modulation_ach(self):
        """调控旁路: ACh降低阈值(探索模式)"""
        sig = Signal.create_modulation(source="G1", target="N-TEST01", mod_type=ModulationType.ACETYLCHOLINE, intensity=0.5)
        self.neuron.calc_membrane_potential([sig])
        self.assertIsNotNone(self.neuron.modulated_threshold)
        self.assertLess(self.neuron.modulated_threshold, self.neuron.dynamic_threshold)

    def test_execute_success(self):
        """技能执行: 成功"""
        call_count = {"n": 0}
        def executor(neuron, **kw):
            call_count["n"] += 1
            return {"result": "ok"}

        self.neuron._executor = executor
        result = self.neuron.execute()
        self.assertEqual(result["status"], "success")
        self.assertEqual(self.neuron.success_count, 1)
        self.assertEqual(call_count["n"], 1)

    def test_execute_no_executor(self):
        result = self.neuron.execute()
        self.assertEqual(result["status"], "no_executor")

    def test_to_dict(self):
        d = self.neuron.to_dict()
        self.assertIn("neuron_id", d)
        self.assertIn("membrane_potential", d)
        self.assertEqual(d["neuron_id"], "N-TEST01")

    def test_effective_threshold_with_modulation(self):
        sig = Signal.create_modulation(source="G1", target="N-TEST01", mod_type=ModulationType.ACETYLCHOLINE, intensity=0.5)
        self.neuron.calc_membrane_potential([sig])
        self.assertLess(self.neuron.effective_threshold, self.neuron.base_threshold)

    def test_reset_modulation(self):
        sig = Signal.create_modulation(source="G1", target="N-TEST01", mod_type=ModulationType.DOPAMINE, intensity=0.8)
        self.neuron.calc_membrane_potential([sig])
        self.neuron.reset_modulation()
        self.assertEqual(self.neuron.learning_rate, 1.0)
        self.assertEqual(self.neuron.signal_gain, 1.0)
        self.assertIsNone(self.neuron.modulated_threshold)


class TestSynapse(unittest.TestCase):
    """突触模型测试"""

    def setUp(self):
        self.synapse = Synapse(
            source_neuron_id="N-01", target_neuron_id="N-02",
            synapse_weight=0.5
        )

    def test_default_weight(self):
        self.assertAlmostEqual(self.synapse.weight, 0.5, places=3)

    def test_weight_clamp_lower(self):
        """公理四: 权重不低于0.1"""
        self.synapse.weight = 0.05
        self.assertAlmostEqual(self.synapse.weight, WEIGHT_MIN, places=3)

    def test_weight_clamp_upper(self):
        """公理四: 权重不高于0.9"""
        self.synapse.weight = 0.99
        self.assertAlmostEqual(self.synapse.weight, WEIGHT_MAX, places=3)

    def test_stdp_update_positive(self):
        """STDP: 正向更新 (pre before post, delta_t > 0 因果)"""
        delta_t = 100  # pre fires 100ms before post => LTP
        old_weight = self.synapse.weight
        self.synapse.stdp_update(delta_t, learning_rate=1.0)
        self.assertGreater(self.synapse.weight, old_weight)

    def test_stdp_update_negative(self):
        """STDP: 负向更新 (post before pre, delta_t < 0)"""
        delta_t = -200
        old_weight = self.synapse.weight
        self.synapse.stdp_update(delta_t, learning_rate=1.0)
        self.assertLess(self.synapse.weight, old_weight)

    def test_stdp_no_change_simultaneous(self):
        """STDP: 同时激发(delta_t=0) 轻微增强(LTP路径)"""
        old_weight = self.synapse.weight
        self.synapse.stdp_update(0, learning_rate=1.0)
        # delta_t=0 走 delta_t>0 的 LTP 分支 (exp(0)=1)
        self.assertGreaterEqual(self.synapse.weight, old_weight)

    def test_weight_stays_in_range_after_stdp(self):
        """STDP多次更新后权重仍在[0.1, 0.9]"""
        for dt in [-5000, -1000, -100, 0, 100, 1000, 5000]:
            self.synapse.stdp_update(dt, learning_rate=2.0)
        self.assertGreaterEqual(self.synapse.weight, WEIGHT_MIN)
        self.assertLessEqual(self.synapse.weight, WEIGHT_MAX)

    def test_to_dict(self):
        d = self.synapse.to_dict()
        self.assertIn("source_neuron_id", d)
        self.assertIn("target_neuron_id", d)
        self.assertIn("synapse_weight", d)

    def test_adjust_weight(self):
        """adjust_weight 返回实际变化量"""
        actual_delta = self.synapse.adjust_weight(0.1)
        self.assertAlmostEqual(self.synapse.weight, 0.6, places=3)
        self.assertAlmostEqual(actual_delta, 0.1, places=3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
