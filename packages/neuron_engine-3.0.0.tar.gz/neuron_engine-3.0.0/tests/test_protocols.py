"""Protocol接口层测试"""
import pytest
from neuron_engine.protocols import (
    SignalCategory, NeuronGrade, BreakerState, LifecyclePhase,
    ISignal, ISynapse, INeuron, AbstractNeuronBackend,
)
from neuron_engine.core.signal import Signal
from neuron_engine.core.synapse import Synapse
from neuron_engine.core.neuron import Neuron


class TestEnums:
    def test_signal_category_values(self):
        assert SignalCategory.EXCITATION.value == "excitation"
        assert SignalCategory.INHIBITION.value == "inhibition"
        assert SignalCategory.MODULATION.value == "modulation"

    def test_neuron_grade_values(self):
        assert NeuronGrade.TEMP.value == "temp"
        assert NeuronGrade.PERMANENT.value == "permanent"

    def test_breaker_state_values(self):
        assert BreakerState.CLOSED.value == "closed"
        assert BreakerState.OPEN.value == "open"


class TestProtocolConformance:
    def test_signal_satisfies_protocol(self):
        signal = Signal.create_excitation("N-01", "N-02", intensity=0.8)
        assert isinstance(signal, ISignal)
        assert signal.is_excitation is True

    def test_synapse_satisfies_protocol(self):
        syn = Synapse(source_id="N-01", target_id="N-02")
        assert isinstance(syn, ISynapse)

    def test_neuron_satisfies_protocol(self):
        neuron = Neuron(neuron_id="N-001", domain_tag="test")
        assert isinstance(neuron, INeuron)


class TestAbstractBackend:
    def test_abstract_methods_raise(self):
        backend = AbstractNeuronBackend()
        with pytest.raises(NotImplementedError):
            backend.insert_neuron()
        with pytest.raises(NotImplementedError):
            backend.get_neuron("x")

    def test_close_is_noop(self):
        AbstractNeuronBackend().close()
