"""MCP Server测试"""
import json
import pytest
from neuron_engine.mcp_server import NeuronMCPServer
from neuron_engine.workflow import NeuronEngine
from neuron_engine.db import NeuronDB


@pytest.fixture
def mcp_server():
    engine = NeuronEngine(db=NeuronDB(":memory:"))
    return NeuronMCPServer(engine)


class TestMCPProtocol:
    def test_initialize(self, mcp_server):
        resp = mcp_server.handle_request({
            "jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}
        })
        assert resp["result"]["protocolVersion"] == "2024-11-05"
        assert resp["result"]["serverInfo"]["name"] == "neuron-engine"

    def test_ping(self, mcp_server):
        resp = mcp_server.handle_request({
            "jsonrpc": "2.0", "id": 2, "method": "ping", "params": {}
        })
        assert resp["result"] == {}

    def test_unknown_method(self, mcp_server):
        resp = mcp_server.handle_request({
            "jsonrpc": "2.0", "id": 3, "method": "nonexistent", "params": {}
        })
        assert resp["error"]["code"] == -32601

    def test_initialized_no_response(self, mcp_server):
        resp = mcp_server.handle_request({
            "jsonrpc": "2.0", "id": None, "method": "notifications/initialized", "params": {}
        })
        assert resp == {}


class TestToolsList:
    def test_six_default_tools(self, mcp_server):
        resp = mcp_server.handle_request({
            "jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}
        })
        tools = resp["result"]["tools"]
        assert len(tools) >= 6
        names = [t["name"] for t in tools]
        assert "neuron_execute_task" in names
        assert "neuron_query_memory" in names

    def test_tool_schemas_valid(self, mcp_server):
        resp = mcp_server.handle_request({
            "jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}
        })
        for tool in resp["result"]["tools"]:
            assert "name" in tool
            assert "inputSchema" in tool


class TestToolsCall:
    def test_execute_task(self, mcp_server):
        resp = mcp_server.handle_request({
            "jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "neuron_execute_task",
                       "arguments": {"task_input": "hello", "priority": "0"}}
        })
        assert "result" in resp
        assert resp["result"]["content"][0]["type"] == "text"

    def test_register_skill(self, mcp_server):
        resp = mcp_server.handle_request({
            "jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "neuron_register_skill",
                       "arguments": {"name": "t", "domain_tag": "d", "description": "t"}}
        })
        assert "result" in resp

    def test_governance_state(self, mcp_server):
        resp = mcp_server.handle_request({
            "jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "neuron_governance_state", "arguments": {}}
        })
        data = json.loads(resp["result"]["content"][0]["text"])
        assert "global_state" in data
        assert "personality" in data

    def test_unknown_tool(self, mcp_server):
        resp = mcp_server.handle_request({
            "jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "nonexistent", "arguments": {}}
        })
        assert resp["error"]["code"] == -32602


class TestCustomTool:
    def test_register_and_call_custom(self, mcp_server):
        mcp_server.register_tool_simple(
            name="echo", description="Echo", params={"text": "Text"},
            handler=lambda p: json.dumps({"echo": p.get("text", "")}),
        )
        resp = mcp_server.handle_request({
            "jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": "echo", "arguments": {"text": "hi"}}
        })
        data = json.loads(resp["result"]["content"][0]["text"])
        assert data["echo"] == "hi"
