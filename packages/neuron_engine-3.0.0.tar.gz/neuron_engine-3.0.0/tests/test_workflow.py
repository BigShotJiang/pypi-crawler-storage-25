"""
工作流引擎单元测试 — NeuronEngine
覆盖: 注册神经元 · 连接突触 · 任务执行 · 状态查询
"""

import sys
import os
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from neuron_engine.workflow import NeuronEngine


class TestNeuronEngine(unittest.TestCase):

    def setUp(self):
        self.engine = NeuronEngine()

    def test_register_neuron(self):
        nid = self.engine.register_neuron("skill", domain_tag="test")
        self.assertIsNotNone(nid)
        self.assertIn(nid, self.engine._neurons)

    def test_register_with_executor(self):
        def my_skill(neuron, **kw):
            return {"hello": "world"}
        nid = self.engine.register_neuron("skill", executor=my_skill, domain_tag="test")
        neuron = self.engine._neurons[nid]
        self.assertIsNotNone(neuron._executor)

    def test_connect(self):
        n1 = self.engine.register_neuron("skill", domain_tag="test")
        n2 = self.engine.register_neuron("skill", domain_tag="test")
        sid = self.engine.connect(n1, n2, weight=0.7, signal_type="excitation")
        self.assertIsNotNone(sid)
        self.assertIn(sid, self.engine._synapses)

    def test_get_status(self):
        status = self.engine.get_status()
        self.assertIn("total_neurons", status)
        self.assertIn("total_synapses", status)
        self.assertIn("version", status)

    def test_execute_task(self):
        def my_skill(neuron, **kw):
            return {"result": "executed"}
        self.engine.register_neuron("skill", executor=my_skill, domain_tag="test")
        result = self.engine.execute_task("test task")
        self.assertIsNotNone(result)
        self.assertIn("status", result)

    def test_execute_task_with_db(self):
        """使用数据库后端执行任务"""
        from neuron_engine.db import NeuronDB
        db = NeuronDB(":memory:")
        engine = NeuronEngine(db=db)
        engine.register_neuron("skill", domain_tag="test")
        result = engine.execute_task("test")
        self.assertIsNotNone(result)
        db.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
