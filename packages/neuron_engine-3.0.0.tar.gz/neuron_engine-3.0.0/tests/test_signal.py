"""
信号子系统单元测试 — SignalBus / NoiseFilter / SignalLifecycle
"""
import sys
import os
import unittest
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from neuron_engine.core.signal import Signal, SignalType, ModulationType
from neuron_engine.signal import SignalBus, NoiseFilter, SignalLifecycle
from neuron_engine.signal.bus import DeliveryStatus
from neuron_engine.signal.noise_filter import FilterAction
from neuron_engine.signal.lifecycle import LifecyclePhase


class TestSignalBus(unittest.TestCase):
    def setUp(self):
        self.bus = SignalBus()
        self.received = []

    def test_subscribe_and_emit(self):
        self.bus.subscribe("N-02", lambda s: self.received.append(s))
        signal = Signal(source_neuron_id="N-01", target_neuron_id="N-02",
                       signal_type=SignalType.EXCITATION, intensity=0.8)
        traces = self.bus.emit(signal)
        self.assertEqual(len(traces), 1)
        self.assertEqual(traces[0].delivery_status, DeliveryStatus.DELIVERED)
        self.assertEqual(len(self.received), 1)

    def test_modulation_bypass(self):
        mod_received = []
        self.bus.subscribe_modulation(lambda s: mod_received.append(s))
        signal = Signal(source_neuron_id="G1", target_neuron_id=None,
                       signal_type=SignalType.MODULATION, intensity=0.5,
                       modulation_type=ModulationType.DOPAMINE)
        traces = self.bus.emit(signal)
        self.assertEqual(len(traces), 1)
        self.assertEqual(traces[0].delivery_status, DeliveryStatus.DELIVERED)
        self.assertEqual(len(mod_received), 1)

    def test_no_subscriber_filtered(self):
        signal = Signal(source_neuron_id="N-01", target_neuron_id="N-99",
                       signal_type=SignalType.EXCITATION, intensity=0.5)
        traces = self.bus.emit(signal)
        self.assertEqual(traces[0].delivery_status, DeliveryStatus.FILTERED)

    def test_broadcast(self):
        self.bus.subscribe("N-02", lambda s: self.received.append(s))
        self.bus.subscribe("N-03", lambda s: self.received.append(s))
        signal = Signal(source_neuron_id="N-01", target_neuron_id="N-02",
                       signal_type=SignalType.EXCITATION, intensity=0.5)
        traces = self.bus.broadcast(signal)
        self.assertEqual(len(self.received), 2)

    def test_get_stats(self):
        self.bus.subscribe("N-02", lambda s: None)
        signal = Signal(source_neuron_id="N-01", target_neuron_id="N-02",
                       signal_type=SignalType.EXCITATION, intensity=0.5)
        self.bus.emit(signal)
        stats = self.bus.get_stats()
        self.assertEqual(stats["total_sent"], 1)
        self.assertEqual(stats["total_delivered"], 1)

    def test_get_traces(self):
        self.bus.subscribe("N-02", lambda s: None)
        signal = Signal(source_neuron_id="N-01", target_neuron_id="N-02",
                       signal_type=SignalType.EXCITATION, intensity=0.5)
        self.bus.emit(signal)
        traces = self.bus.get_traces("N-01")
        self.assertGreater(len(traces), 0)


class TestNoiseFilter(unittest.TestCase):
    def setUp(self):
        self.filter = NoiseFilter(
            max_freq_per_second=5,
            min_intensity=0.05,
            storm_threshold=50,
        )

    def test_pass_normal_signal(self):
        signal = Signal(source_neuron_id="N-01", target_neuron_id="N-02",
                       signal_type=SignalType.EXCITATION, intensity=0.5)
        result = self.filter.filter(signal)
        self.assertEqual(result.action, FilterAction.PASS)

    def test_block_high_frequency(self):
        signal = Signal(source_neuron_id="N-01", target_neuron_id="N-02",
                       signal_type=SignalType.EXCITATION, intensity=0.5)
        for _ in range(10):
            self.filter.filter(signal)
        # 第10次应该被频率限制
        # (max_freq=5, 但实际是int(5)=5)
        stats = self.filter.get_stats()
        self.assertGreater(stats["total_filtered"], 0)

    def test_attenuate_low_intensity(self):
        signal = Signal(source_neuron_id="N-01", target_neuron_id="N-02",
                       signal_type=SignalType.EXCITATION, intensity=0.01)
        result = self.filter.filter(signal)
        self.assertIn(result.action, (FilterAction.ATTENUATE, FilterAction.PASS))

    def test_storm_detection(self):
        tiny_filter = NoiseFilter(storm_threshold=5, storm_window_ms=1000)
        signal = Signal(source_neuron_id="N-01", target_neuron_id="N-02",
                       signal_type=SignalType.EXCITATION, intensity=0.5)
        for _ in range(10):
            tiny_filter.filter(signal)
        # 风暴模式应被触发
        self.assertTrue(tiny_filter.is_storm_mode())

    def test_get_stats(self):
        signal = Signal(source_neuron_id="N-01", target_neuron_id="N-02",
                       signal_type=SignalType.EXCITATION, intensity=0.5)
        self.filter.filter(signal)
        stats = self.filter.get_stats()
        self.assertIn("total_passed", stats)


class TestSignalLifecycle(unittest.TestCase):
    def setUp(self):
        self.lifecycle = SignalLifecycle(default_ttl_ms=5000)

    def test_create_and_advance(self):
        signal = Signal(source_neuron_id="N-01", target_neuron_id="N-02",
                       signal_type=SignalType.EXCITATION, intensity=0.5)
        self.lifecycle.create(signal)
        self.assertEqual(self.lifecycle.get_phase(signal.signal_id), LifecyclePhase.CREATED)
        
        self.lifecycle.advance(signal.signal_id, LifecyclePhase.DELIVERED)
        self.assertEqual(self.lifecycle.get_phase(signal.signal_id), LifecyclePhase.DELIVERED)

    def test_terminal_phases(self):
        signal = Signal(source_neuron_id="N-01", target_neuron_id="N-02",
                       signal_type=SignalType.EXCITATION, intensity=0.5)
        self.lifecycle.create(signal)
        self.lifecycle.advance(signal.signal_id, LifecyclePhase.PROCESSED)
        self.lifecycle.advance(signal.signal_id, LifecyclePhase.ARCHIVED)
        
        # 终态后阶段应仍可查询
        history = self.lifecycle.get_history(signal.signal_id)
        self.assertEqual(len(history), 3)

    def test_get_stats(self):
        signal = Signal(source_neuron_id="N-01", target_neuron_id="N-02",
                       signal_type=SignalType.EXCITATION, intensity=0.5)
        self.lifecycle.create(signal)
        self.lifecycle.advance(signal.signal_id, LifecyclePhase.ARCHIVED)
        stats = self.lifecycle.get_stats()
        self.assertEqual(stats["total_created"], 1)
        self.assertEqual(stats["total_completed"], 1)

    def test_active_count(self):
        for i in range(3):
            signal = Signal(source_neuron_id=f"N-{i}", target_neuron_id="N-T",
                           signal_type=SignalType.EXCITATION, intensity=0.5)
            self.lifecycle.create(signal)
        self.assertEqual(self.lifecycle.get_active_count(), 3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
