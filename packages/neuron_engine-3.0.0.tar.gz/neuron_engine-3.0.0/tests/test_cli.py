"""CLI命令行工具测试"""

import json
import os
import subprocess
import sys

# 自动检测包根目录
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _run(*args, timeout=15):
    """辅助: 运行CLI命令"""
    cmd = [sys.executable, "-m", "neuron_engine"] + list(args)
    result = subprocess.run(
        cmd, capture_output=True, text=True, timeout=timeout,
        encoding="utf-8", errors="replace",
        cwd=PKG_DIR,
    )
    return result


def test_version_flag():
    r = _run("--version")
    assert r.returncode == 0
    assert "3.0.0" in r.stdout


def test_version_command():
    r = _run("version")
    assert r.returncode == 0
    assert "3.0.0" in r.stdout
    assert "Python" in r.stdout


def test_run_task_json():
    r = _run("run", "hello world", "--json")
    assert r.returncode == 0
    data = json.loads(r.stdout)
    assert "trace_id" in data
    assert data["status"] in ("success", "error", "degraded")
    assert data["version"] == "3.0.0"


def test_run_task_human():
    r = _run("run", "测试任务")
    assert r.returncode == 0
    assert "Trace:" in r.stdout or "trace" in r.stdout.lower()


def test_run_with_priority():
    r = _run("run", "测试", "--priority", "5", "--json")
    assert r.returncode == 0
    data = json.loads(r.stdout)
    assert data["trace_id"]


def test_run_no_task():
    r = _run("run")
    assert r.returncode != 0


def test_stats_output():
    r = _run("stats")
    assert r.returncode == 0
    data = json.loads(r.stdout)
    assert "version" in data
    assert data["version"] == "3.0.0"
    assert "total_neurons" in data
    assert "memory" in data


def test_help_shown():
    r = _run()
    assert r.returncode == 0


def test_serve_help():
    r = _run("serve", "--help")
    assert r.returncode == 0
