"""
学习系统单元测试 — STDPLearner / RPEEvaluator
覆盖: STDP权重调整 · 批量更新 · RPE计算 · 质量评估
"""

import sys
import os
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from neuron_engine.learning import STDPLearner, RPEEvaluator
from neuron_engine.core.synapse import Synapse


class TestSTDPLearner(unittest.TestCase):
    """STDP学习器测试"""

    def setUp(self):
        self.learner = STDPLearner()
        self.synapse = Synapse(source_id="N-01", target_id="N-02", weight=0.5)

    def test_single_update_positive(self):
        """pre-before-post: 权重增加"""
        pre_time = 1000
        post_time = 1100  # pre先激发
        delta_t = pre_time - post_time  # -100

        old_weight = self.synapse.weight
        self.learner.update_single(self.synapse, delta_t, learning_rate=1.0)
        self.assertGreater(self.synapse.weight, old_weight)

    def test_single_update_negative(self):
        """post-before-pre: 权重减少"""
        pre_time = 1100
        post_time = 1000  # post先激发
        delta_t = pre_time - post_time  # 100

        old_weight = self.synapse.weight
        self.learner.update_single(self.synapse, delta_t, learning_rate=1.0)
        self.assertLess(self.synapse.weight, old_weight)

    def test_weight_stays_in_range(self):
        """无论STDP如何更新，权重始终在[0.1, 0.9]"""
        for _ in range(1000):
            delta_t = (hash(str(_)) % 20000) - 10000
            self.learner.update_single(self.synapse, delta_t, learning_rate=2.0)
        self.assertGreaterEqual(self.synapse.weight, 0.1)
        self.assertLessEqual(self.synapse.weight, 0.9)

    def test_batch_update(self):
        """批量更新"""
        synapses = [
            Synapse(source_id=f"N-{i}", target_id=f"N-{i+1}", weight=0.5)
            for i in range(5)
        ]
        updates = [
            (s, -100, 1.0) for s in synapses
        ]
        self.learner.update_batch(updates)
        for s in synapses:
            self.assertGreater(s.weight, 0.5)

    def test_stdp_constants(self):
        """验证Bi&Poo 1998参数"""
        self.assertAlmostEqual(self.learner.A_plus, 0.08, places=3)
        self.assertAlmostEqual(self.learner.A_minus, 0.04, places=3)
        self.assertEqual(self.learner.tau_plus, 10000)
        self.assertEqual(self.learner.tau_minus, 15000)


class TestRPEEvaluator(unittest.TestCase):
    """RPE奖励预测误差评估器测试"""

    def setUp(self):
        self.evaluator = RPEEvaluator()

    def test_evaluate_quality_high(self):
        """高质量任务"""
        metrics = {
            "completeness": 1.0,
            "success_rate": 1.0,
            "latency_ms": 100,
            "user_feedback": 0.9,
        }
        quality = self.evaluator.evaluate_quality(metrics)
        # quality = 0.4*1.0 + 0.3*1.0 + 0.2*(1-100/30000) + 0.1*0.9 ≈ 0.99
        self.assertGreater(quality, 0.9)

    def test_evaluate_quality_low(self):
        """低质量任务"""
        metrics = {
            "completeness": 0.2,
            "success_rate": 0.0,
            "latency_ms": 29000,
            "user_feedback": 0.0,
        }
        quality = self.evaluator.evaluate_quality(metrics)
        self.assertLess(quality, 0.3)

    def test_calc_rpe_positive(self):
        """正向RPE (惊喜)"""
        rpe = self.evaluator.calc_rpe(quality_score=0.9, expected_value=0.5)
        self.assertGreater(rpe, 0)

    def test_calc_rpe_negative(self):
        """负向RPE (失望)"""
        rpe = self.evaluator.calc_rpe(quality_score=0.2, expected_value=0.7)
        self.assertLess(rpe, 0)

    def test_calc_rpe_zero(self):
        """零RPE (预期一致)"""
        rpe = self.evaluator.calc_rpe(quality_score=0.5, expected_value=0.5)
        self.assertAlmostEqual(rpe, 0.0, places=4)

    def test_dopamine_from_rpe(self):
        """多巴胺水平映射"""
        rpe = 0.4
        dopamine = self.evaluator.rpe_to_dopamine(rpe)
        # 正RPE -> dopamine > 0.5
        self.assertGreater(dopamine, 0.5)

    def test_quality_weights_sum(self):
        """质量评估权重和为1.0"""
        total = (self.evaluator.w_completeness + self.evaluator.w_success +
                 self.evaluator.w_latency + self.evaluator.w_feedback)
        self.assertAlmostEqual(total, 1.0, places=3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
