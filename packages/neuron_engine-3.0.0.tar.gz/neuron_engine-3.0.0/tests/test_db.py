"""
数据库层单元测试 — NeuronDB
覆盖: 14张表DDL · CRUD · ORM行映射 · 统计查询
"""

import sys
import os
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from neuron_engine.db import NeuronDB, NeuronRow, SynapseRow, MemoryAtomRow


class TestNeuronDB(unittest.TestCase):
    """数据库持久化层测试"""

    def setUp(self):
        self.db = NeuronDB(":memory:")

    def tearDown(self):
        self.db.close()

    def test_insert_and_get_neuron(self):
        row = NeuronRow(neuron_id="N-DB01", neuron_type="skill", domain_tag="test")
        self.db.insert_neuron(row)
        retrieved = self.db.get_neuron("N-DB01")
        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved.neuron_type, "skill")

    def test_list_neurons(self):
        for i in range(3):
            self.db.insert_neuron(NeuronRow(neuron_id=f"N-L{i:03d}", neuron_type="skill"))
        rows = self.db.list_neurons(neuron_type="skill")
        self.assertEqual(len(rows), 3)

    def test_update_neuron(self):
        self.db.insert_neuron(NeuronRow(neuron_id="N-UP01"))
        ok = self.db.update_neuron("N-UP01", {"state": "点火放电", "activate_times": 5})
        self.assertTrue(ok)
        updated = self.db.get_neuron("N-UP01")
        self.assertEqual(updated.state, "点火放电")

    def test_delete_neuron(self):
        self.db.insert_neuron(NeuronRow(neuron_id="N-DEL01"))
        ok = self.db.delete_neuron("N-DEL01")
        self.assertTrue(ok)
        self.assertIsNone(self.db.get_neuron("N-DEL01"))

    def test_insert_and_get_synapse(self):
        self.db.insert_neuron(NeuronRow(neuron_id="N-S01"))
        self.db.insert_neuron(NeuronRow(neuron_id="N-S02"))
        row = SynapseRow(source_id="N-S01", target_id="N-S02", weight=0.7)
        sid = self.db.insert_synapse(row)
        self.assertIsNotNone(sid)
        retrieved = self.db.get_synapse("N-S01", "N-S02")
        self.assertIsNotNone(retrieved)
        self.assertAlmostEqual(retrieved.weight, 0.7)

    def test_upsert_synapse(self):
        self.db.insert_neuron(NeuronRow(neuron_id="N-U01"))
        self.db.insert_neuron(NeuronRow(neuron_id="N-U02"))
        self.db.insert_synapse(SynapseRow(source_id="N-U01", target_id="N-U02", weight=0.3))
        # 重复插入应更新
        self.db.insert_synapse(SynapseRow(source_id="N-U01", target_id="N-U02", weight=0.6))
        retrieved = self.db.get_synapse("N-U01", "N-U02")
        self.assertAlmostEqual(retrieved.weight, 0.6)

    def test_insert_and_search_memory(self):
        self.db.insert_memory_atom(MemoryAtomRow(content="AI知识", domain_tag="AI", keywords='["AI","知识"]'))
        self.db.insert_memory_atom(MemoryAtomRow(content="医学知识", domain_tag="医学"))
        results = self.db.search_memory_atoms(domain_tag="AI")
        self.assertEqual(len(results), 1)

    def test_promote_atom(self):
        aid = self.db.insert_memory_atom(MemoryAtomRow(content="重要记忆"))
        ok = self.db.promote_atom(aid, "short_term", "测试晋升")
        self.assertTrue(ok)
        updated = self.db.get_memory_atom(aid)
        self.assertEqual(updated.grade, "short_term")

    def test_signal_log(self):
        log_id = self.db.log_signal("SIG-01", "excitation", "N-01", "N-02", 0.8)
        self.assertIsNotNone(log_id)
        self.db.update_signal_log(log_id, "processed", duration_ms=50)

    def test_workflow(self):
        wf_id = self.db.create_workflow("T-01", {"input": "test"})
        self.db.update_workflow(wf_id, current_step=3, status="running")
        wf = self.db.get_workflow(wf_id)
        self.assertIsNotNone(wf)
        self.assertEqual(wf["current_step"], 3)

    def test_global_state(self):
        self.db.save_global_state("default", 0.8, 0.6, 0.7, 0.5, "exploration")
        gs = self.db.get_global_state()
        self.assertIsNotNone(gs)
        self.assertAlmostEqual(gs["arousal"], 0.8)

    def test_reward_log(self):
        log_id = self.db.log_reward("T-01", 0.85, 0.5, 0.35, 0.7)
        self.assertIsNotNone(log_id)

    def test_stats(self):
        stats = self.db.get_stats()
        self.assertIn("total_neurons", stats)
        self.assertIn("total_synapses", stats)

    def test_config_snapshot(self):
        sid = self.db.save_config_snapshot('{"key": "value"}', "manual")
        self.assertIsNotNone(sid)
        latest = self.db.get_latest_snapshot()
        self.assertIsNotNone(latest)


if __name__ == "__main__":
    unittest.main(verbosity=2)
