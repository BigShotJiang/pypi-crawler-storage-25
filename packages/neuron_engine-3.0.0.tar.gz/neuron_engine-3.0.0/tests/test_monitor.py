"""
监控子系统单元测试 — AnomalyDetector / SelfHealer / AlertManager / MetricsCollector / Dashboard
"""
import sys
import os
import unittest
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from neuron_engine.monitor import (
    AnomalyDetector, SelfHealer, AlertManager, MetricsCollector, Dashboard
)
from neuron_engine.monitor.detector import AnomalyType, SeverityLevel
from neuron_engine.monitor.healer import HealAction


class TestAnomalyDetector(unittest.TestCase):
    def setUp(self):
        self.detector = AnomalyDetector(storm_threshold=5, noise_std_threshold=10.0)
        self.detected = []

    def test_detect_storm(self):
        self.detector.on_anomaly(lambda e: self.detected.append(e))
        for _ in range(10):
            self.detector.record_signal("N-01")
        # 高频信号应触发风暴
        stats = self.detector.get_stats()
        self.assertGreater(stats["total_detected"], 0)

    def test_detect_deadlock(self):
        self.detector.on_anomaly(lambda e: self.detected.append(e))
        # 记录不变的膜电位
        for _ in range(100):
            self.detector.record_membrane("N-01", 0.5)
        # 不应死锁 (值在变化, 只是没有变)
        # 死锁检测需要时间窗口

    def test_check_all(self):
        self.detector.record_signal("N-01")
        events = self.detector.check_all()
        self.assertIsInstance(events, list)

    def test_get_stats(self):
        self.detector.record_signal("N-01")
        stats = self.detector.get_stats()
        self.assertIn("total_detected", stats)


class TestSelfHealer(unittest.TestCase):
    def setUp(self):
        self.healer = SelfHealer(auto_heal=True, cooldown_sec=0.1)

    def test_heal_critical(self):
        result = self.healer.heal(
            AnomalyType.NEURON_DEADLOCK, "N-01",
            SeverityLevel.CRITICAL
        )
        self.assertEqual(result.action, HealAction.CIRCUIT_BREAK)
        self.assertTrue(result.success)

    def test_heal_low_skipped(self):
        result = self.healer.heal(
            AnomalyType.MEMBRANE_NOISE, "N-01",
            SeverityLevel.LOW
        )
        self.assertEqual(result.action, HealAction.NONE)

    def test_heal_cooldown(self):
        self.healer.heal(AnomalyType.SIGNAL_STORM, "N-01", SeverityLevel.HIGH)
        result2 = self.healer.heal(AnomalyType.SIGNAL_STORM, "N-01", SeverityLevel.HIGH)
        # 冷却期内应跳过
        self.assertFalse(result2.success)

    def test_heal_strategy_map(self):
        result = self.healer.heal(
            AnomalyType.MEMORY_OVERFLOW, "mem", SeverityLevel.HIGH
        )
        self.assertEqual(result.action, HealAction.MEMORY_CLEANUP)

    def test_get_stats(self):
        self.healer.heal(AnomalyType.SIGNAL_STORM, "N-01", SeverityLevel.HIGH)
        stats = self.healer.get_stats()
        self.assertEqual(stats["total_heals"], 1)


class TestAlertManager(unittest.TestCase):
    def setUp(self):
        self.alert_mgr = AlertManager(dedup_window_sec=0.1)
        self.alerts_received = []

    def test_create_alert(self):
        from neuron_engine.monitor.detector import AnomalyEvent
        event = AnomalyEvent(
            anomaly_type=AnomalyType.SIGNAL_STORM,
            severity=SeverityLevel.HIGH,
            source_id="N-01",
            description="test alert",
            detected_at=time.time(),
        )
        self.alert_mgr.alert(event)
        stats = self.alert_mgr.get_stats()
        self.assertEqual(stats["total_alerts"], 1)

    def test_dedup(self):
        from neuron_engine.monitor.detector import AnomalyEvent
        event = AnomalyEvent(
            anomaly_type=AnomalyType.SIGNAL_STORM,
            severity=SeverityLevel.HIGH,
            source_id="N-01",
            description="test",
            detected_at=time.time(),
        )
        self.alert_mgr.alert(event)
        self.alert_mgr.alert(event)
        stats = self.alert_mgr.get_stats()
        self.assertGreater(stats["deduped"], 0)

    def test_callback_channel(self):
        self.alert_mgr.add_channel("test", lambda a: self.alerts_received.append(a))
        from neuron_engine.monitor.detector import AnomalyEvent
        event = AnomalyEvent(
            anomaly_type=AnomalyType.SIGNAL_STORM,
            severity=SeverityLevel.HIGH,
            source_id="N-01",
            description="test",
            detected_at=time.time(),
        )
        self.alert_mgr.alert(event, channels=["test"])
        self.assertEqual(len(self.alerts_received), 1)

    def test_acknowledge(self):
        from neuron_engine.monitor.detector import AnomalyEvent
        event = AnomalyEvent(
            anomaly_type=AnomalyType.SIGNAL_STORM,
            severity=SeverityLevel.HIGH,
            source_id="N-01",
            description="test",
            detected_at=time.time(),
        )
        self.alert_mgr.alert(event)
        alerts = self.alert_mgr.get_alerts(limit=1)
        if alerts:
            self.assertTrue(self.alert_mgr.acknowledge(alerts[0]["alert_id"]))


class TestMetricsCollector(unittest.TestCase):
    def setUp(self):
        self.metrics = MetricsCollector()

    def test_record_and_get(self):
        self.metrics.record("test_metric", 42.0)
        summary = self.metrics.get_summary("test_metric")
        self.assertEqual(summary["count"], 1)
        self.assertAlmostEqual(summary["mean"], 42.0)

    def test_counter(self):
        self.metrics.increment("requests")
        self.metrics.increment("requests", 5)
        self.assertEqual(self.metrics.get_counter("requests"), 6)

    def test_gauge(self):
        self.metrics.set_gauge("temperature", 36.5)
        self.assertAlmostEqual(self.metrics.get_gauge("temperature"), 36.5)

    def test_task_success_rate(self):
        self.metrics.record_task_result(True)
        self.metrics.record_task_result(True)
        self.metrics.record_task_result(False)
        self.assertAlmostEqual(self.metrics.get_task_success_rate(), 2/3, places=2)

    def test_all_summaries(self):
        self.metrics.record("m1", 1.0)
        self.metrics.record("m2", 2.0)
        summaries = self.metrics.get_all_summaries()
        self.assertIn("m1", summaries)
        self.assertIn("m2", summaries)


class TestDashboard(unittest.TestCase):
    def test_overview(self):
        detector = AnomalyDetector()
        healer = SelfHealer()
        alert_mgr = AlertManager()
        metrics = MetricsCollector()
        
        dashboard = Dashboard(detector=detector, healer=healer,
                             alert_manager=alert_mgr, metrics=metrics)
        overview = dashboard.get_overview()
        self.assertIn("anomaly_detection", overview)
        self.assertIn("self_healing", overview)
        self.assertIn("alerts", overview)
        self.assertIn("metrics", overview)

    def test_health_status(self):
        metrics = MetricsCollector()
        metrics.record_task_result(True)
        dashboard = Dashboard(metrics=metrics)
        health = dashboard.get_health_status()
        self.assertEqual(health["status"], "healthy")


if __name__ == "__main__":
    unittest.main(verbosity=2)
