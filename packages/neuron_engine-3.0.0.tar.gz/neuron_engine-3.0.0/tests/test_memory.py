"""
记忆系统单元测试 — MemoryAtom / MemoryManager
覆盖: 四级晋升 · 双向连通 · 标签检索 · 链式检索 · 记忆巩固
"""

import sys
import os
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from neuron_engine.memory import MemoryAtom, MemoryManager


class TestMemoryAtom(unittest.TestCase):
    """原子记忆节点测试"""

    def test_create_default(self):
        atom = MemoryAtom(content="测试记忆内容")
        self.assertEqual(atom.grade, "temp")
        self.assertEqual(atom.access_count, 0)
        self.assertTrue(atom.atom_id.startswith("MA-"))

    def test_create_with_params(self):
        atom = MemoryAtom(
            content="重要知识",
            domain_tag="AI",
            memory_type="semantic",
            importance=0.9,
        )
        self.assertEqual(atom.domain_tag, "AI")
        self.assertEqual(atom.importance, 0.9)

    def test_access(self):
        atom = MemoryAtom(content="test")
        atom.access()
        self.assertEqual(atom.access_count, 1)
        atom.access()
        atom.access()
        self.assertEqual(atom.access_count, 3)

    def test_promotion_temp_to_short(self):
        """temp -> short_term: access >= 3"""
        atom = MemoryAtom(content="frequent", access_count=3)
        can, reason = atom.can_promote()
        # 时间条件需满足（创建后至少1小时），此处测试仅检查次数
        self.assertEqual(atom.access_count, 3)

    def test_add_related(self):
        atom1 = MemoryAtom(content="A")
        atom2 = MemoryAtom(content="B")
        atom1.add_related(atom2.atom_id)
        self.assertIn(atom2.atom_id, atom1.related_ids)

    def test_keywords(self):
        atom = MemoryAtom(content="Python编程", keywords=["编程", "Python"])
        self.assertIn("编程", atom.keywords)
        self.assertIn("Python", atom.keywords)

    def test_to_dict(self):
        atom = MemoryAtom(content="test")
        d = atom.to_dict()
        self.assertIn("atom_id", d)
        self.assertIn("grade", d)
        self.assertIn("content", d)


class TestMemoryManager(unittest.TestCase):
    """记忆管理器测试"""

    def setUp(self):
        self.mgr = MemoryManager()

    def test_store_and_retrieve(self):
        atom = self.mgr.store("测试记忆", domain_tag="test")
        retrieved = self.mgr.get(atom.atom_id)
        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved.content, "测试记忆")

    def test_search_by_tag(self):
        self.mgr.store("AI知识", domain_tag="AI")
        self.mgr.store("医学知识", domain_tag="医学")
        self.mgr.store("更多AI", domain_tag="AI")

        results = self.mgr.search(domain_tag="AI")
        self.assertEqual(len(results), 2)

    def test_search_by_keyword(self):
        self.mgr.store("深度学习算法", keywords=["深度学习", "算法"])
        self.mgr.store("机器学习方法", keywords=["机器学习", "方法"])
        self.mgr.store("深度学习应用", keywords=["深度学习", "应用"])

        results = self.mgr.search(keyword="深度学习")
        self.assertEqual(len(results), 2)

    def test_chain_retrieve(self):
        atom1 = self.mgr.store("概念A", keywords=["A"])
        atom2 = self.mgr.store("概念B", keywords=["B"])
        atom1.add_related(atom2.atom_id)
        self.mgr.store_atom(atom1)

        chain = self.mgr.chain_retrieve(atom1.atom_id, max_depth=1)
        # 应至少包含atom2
        ids = [a.atom_id for a in chain]
        self.assertIn(atom2.atom_id, ids)

    def test_consolidate(self):
        atom = self.mgr.store("反复记忆", domain_tag="test")
        for _ in range(10):
            atom.access()
        # 检查巩固尝试不抛错
        promoted = self.mgr.consolidate(atom.atom_id)
        # 注意：时间条件可能不满足，所以promoted可能为False
        # 主要测试不抛异常
        self.assertIsInstance(promoted, bool)

    def test_get_stats(self):
        self.mgr.store("a")
        self.mgr.store("b")
        stats = self.mgr.get_stats()
        self.assertEqual(stats["total_atoms"], 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
