"""
全局调控系统单元测试 — GovernanceSystem
覆盖: 四维状态 · 人格 · 情绪VAD · 运行模式 · 拮抗约束 · 三维协同
"""

import sys
import os
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from neuron_engine.governance import (
    GlobalState, Personality, EmotionState, GovernanceSystem
)


class TestGlobalState(unittest.TestCase):

    def test_default_values(self):
        gs = GlobalState()
        self.assertEqual(gs.arousal, 0.500)
        self.assertEqual(gs.stability, 0.700)

    def test_update(self):
        gs = GlobalState()
        gs.update(arousal=0.8)
        self.assertAlmostEqual(gs.arousal, 0.8, places=3)

    def test_to_dict(self):
        gs = GlobalState()
        d = gs.to_dict()
        self.assertIn("arousal", d)
        self.assertIn("attention", d)


class TestPersonality(unittest.TestCase):

    def test_big_five_defaults(self):
        p = Personality()
        self.assertAlmostEqual(p.openness, 0.5, places=3)
        self.assertAlmostEqual(p.neuroticism, 0.5, places=3)

    def test_influence_on_threshold(self):
        """高外向性 -> 低阈值"""
        p = Personality(extraversion=0.9)
        adjustment = p.threshold_adjustment()
        # 高外向性应降低阈值
        self.assertLess(adjustment, 0)


class TestEmotionState(unittest.TestCase):

    def test_vad_defaults(self):
        e = EmotionState()
        self.assertAlmostEqual(e.valence, 0.0)
        self.assertAlmostEqual(e.arousal, 0.5)

    def test_update_from_rpe(self):
        e = EmotionState()
        e.update_from_rpe(rpe=0.5)
        self.assertGreater(e.valence, 0)
        self.assertGreater(e.arousal, 0.5)

    def test_primary_emotion_calm(self):
        e = EmotionState(valence=0.0, arousal=0.1)
        self.assertIn(e.primary_emotion, ["平静", "无聊", "放松"])


class TestGovernanceSystem(unittest.TestCase):

    def setUp(self):
        self.gov = GovernanceSystem()

    def test_initial_state(self):
        self.assertEqual(self.gov.run_mode, "normal")

    def test_infer_mode(self):
        self.gov.global_state.update(arousal=0.9, learning_mode=0.9, stability=0.3)
        self.gov.infer_mode()
        self.assertEqual(self.gov.run_mode, "exploration")

    def test_apply_modulation(self):
        from neuron_engine.core.signal import Signal, ModulationType
        sig = Signal.create_modulation(source="G1", target="N-01", mod_type=ModulationType.DOPAMINE, intensity=0.5)
        self.gov.apply_modulation(sig)
        # 应有变化

    def test_antagonist_constraint(self):
        """拮抗约束: attention高则stability应下降"""
        self.gov.global_state.update(attention=0.9)
        self.gov.apply_antagonist()
        # stability应被约束
        self.assertLessEqual(self.gov.global_state.stability, 0.8)

    def test_synergy_vector(self):
        sv = self.gov.calc_synergy_vector()
        self.assertIn("cognition", sv)
        self.assertIn("emotion", sv)
        self.assertIn("governance", sv)


if __name__ == "__main__":
    unittest.main(verbosity=2)
