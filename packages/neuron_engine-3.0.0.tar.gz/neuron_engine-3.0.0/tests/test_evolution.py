"""
自演化系统单元测试 — Evolver
"""
import sys
import os
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from neuron_engine.evolution import Evolver
from neuron_engine.evolution.evolver import SkillPhase, EvolutionTrigger
from neuron_engine.core.synapse import Synapse


class TestEvolver(unittest.TestCase):
    def setUp(self):
        self.evolver = Evolver(evolution_rate=0.1)

    def test_positive_rpe_reinforces(self):
        synapses = [Synapse(source_id="N-01", target_id="N-02", weight=0.5)]
        self.evolver.evolve_on_rpe("N-02", rpe_value=0.5, synapses=synapses)
        stats = self.evolver.get_stats()
        self.assertGreater(stats["reinforcements"], 0)

    def test_negative_rpe_attenuates(self):
        synapses = [Synapse(source_id="N-01", target_id="N-02", weight=0.5)]
        self.evolver.evolve_on_rpe("N-02", rpe_value=-0.5, synapses=synapses)
        stats = self.evolver.get_stats()
        self.assertGreater(stats["prunings"], 0)

    def test_small_rpe_no_evolution(self):
        synapses = [Synapse(source_id="N-01", target_id="N-02", weight=0.5)]
        self.evolver.evolve_on_rpe("N-02", rpe_value=0.05, synapses=synapses)
        stats = self.evolver.get_stats()
        # RPE < 0.1 threshold: no reinforce/prune stats increment
        self.assertEqual(stats["reinforcements"] + stats["prunings"], 0)

    def test_skill_lifecycle_progression(self):
        # DRAFT -> ACTIVE (usage >= 5)
        for _ in range(5):
            self.evolver.record_usage("skill-1", True)
        phase = self.evolver.advance_skill_lifecycle("skill-1")
        self.assertEqual(phase, SkillPhase.ACTIVE)

    def test_skill_retirement(self):
        self.evolver._skill_phases["skill-old"] = SkillPhase.DEPRECATED
        self.evolver._usage_counts["skill-old"] = 5
        # 添加一个成功记录使其使用率低
        for _ in range(5):
            self.evolver.record_usage("skill-old", True)
        # usage > 0 不满足 RETIRED 条件
        
    def test_anomaly_trigger(self):
        self.evolver.evolve_on_anomaly(
            EvolutionTrigger.STORM_DETECTED, "N-01",
            {"description": "signal storm"}
        )
        stats = self.evolver.get_stats()
        self.assertEqual(stats["parameter_adjustments"], 1)

    def test_get_records(self):
        self.evolver.evolve_on_anomaly(
            EvolutionTrigger.STORM_DETECTED, "N-01"
        )
        records = self.evolver.get_records()
        self.assertEqual(len(records), 1)

    def test_get_stats(self):
        self.evolver.evolve_on_anomaly(EvolutionTrigger.PERIODIC, "N-01")
        stats = self.evolver.get_stats()
        self.assertEqual(stats["total_evolutions"], 1)

    def test_weight_clamp_after_evolution(self):
        syn = Synapse(source_id="N-01", target_id="N-02", weight=0.89)
        self.evolver.evolve_on_rpe("N-02", rpe_value=0.9, synapses=[syn])
        self.assertLessEqual(syn.synapse_weight, 0.9)


if __name__ == "__main__":
    unittest.main(verbosity=2)
