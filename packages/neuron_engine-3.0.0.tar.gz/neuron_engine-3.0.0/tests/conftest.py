"""pytest conftest - auto set PKG_DIR for subprocess tests"""
import os
import sys

PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

if PKG_DIR not in sys.path:
    sys.path.insert(0, PKG_DIR)
