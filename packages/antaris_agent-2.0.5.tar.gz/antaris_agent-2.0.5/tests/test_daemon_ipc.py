"""
Tests for daemon IPC system.

Covers:
- DaemonIPC server lifecycle
- DaemonClient communication 
- Command dispatch and routing
- Error handling
- Socket cleanup
"""
from __future__ import annotations

import asyncio
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from antaris_agent.daemon.ipc import DaemonIPC, DaemonClient, SOCKET_PATH


@pytest.mark.filterwarnings("ignore::RuntimeWarning")
class TestDaemonIPC:
    """Test the daemon-side IPC server."""

    @pytest.fixture
    def mock_bot(self):
        """Create a mock bot with common attributes."""
        bot = MagicMock()
        bot._start_time = 1000.0
        bot.security_lock = None  # No security lock by default
        bot.config = MagicMock()
        bot.config.security_mode = "sandboxed"
        bot.config.guard_mode = "monitor" 
        bot.config.rate_limit_messages = 20
        bot.config.rate_limit_window_seconds = 60
        bot.config.api_key = "test-key"
        bot.config.memory_store = "/tmp/test_memory"
        bot.config.discord_enabled = True
        bot.config.discord_token = "test-token"
        bot.config.telegram_enabled = False
        bot.config.telegram_token = ""
        bot.config.slack_enabled = False
        bot.config.slack_bot_token = ""
        bot.config.slack_app_token = ""
        
        # Mock sessions using real SessionState attributes
        bot.sessions = MagicMock()
        bot.sessions.active_count = 2
        session1 = MagicMock(
            session_id="session1",
            user_id="user1",
            channel_id="channel1", 
            platform="discord",
            status="active",
            created_at=1000.0,
            last_active=1100.0,
            message_count=5,
            context_pct=12.5,
            max_history=20,
            conversation_buffer=["buf1", "buf2"],
            compaction_notified=False,
            pre_compaction_flushed=False,
        )
        session1.history = ["msg1", "msg2"]
        
        session2 = MagicMock(
            session_id="session2",
            user_id="user2",
            channel_id="channel2",
            platform="telegram", 
            status="idle",
            created_at=1050.0,
            last_active=1150.0,
            message_count=3,
            context_pct=8.0,
            max_history=20,
            conversation_buffer=["buf1"],
            compaction_notified=False,
            pre_compaction_flushed=False,
        )
        session2.history = ["msg1"]
        
        bot.sessions._sessions = {
            "session1": session1,
            "session2": session2,
        }
        # Wire async methods for SessionManager
        bot.sessions.list_sessions = AsyncMock(return_value=[session1, session2])
        bot.sessions.get_session = AsyncMock(side_effect=lambda sid: bot.sessions._sessions.get(sid))

        async def _mock_kill_all():
            count = len(bot.sessions._sessions)
            bot.sessions._sessions.clear()
            return count
        bot.sessions.kill_all = _mock_kill_all
        bot.sessions.kill_session = AsyncMock(return_value=True)
        bot.sessions.reset_session = AsyncMock(return_value=True)
        bot.sessions.compact_session = AsyncMock(return_value="summary text")
        
        # Mock tool registry using real ToolRegistry interface
        bot.tool_registry = MagicMock()
        bot.tool_registry.list_tools = MagicMock(return_value=["web_search", "file_read"])
        bot.tool_registry._tool_definitions = {
            "web_search": MagicMock(source="native", description="Search the web"),
            "file_read": MagicMock(source="native", description="Read files"),
        }
        bot.tool_registry.get_server_status = AsyncMock(return_value={})
        
        # Mock guard
        bot.guard = MagicMock()
        
        return bot

    @pytest.fixture
    def daemon_ipc(self, mock_bot):
        """Create DaemonIPC instance with mock bot."""
        ipc = DaemonIPC()
        ipc._bot = mock_bot
        return ipc

    @pytest.fixture
    def temp_socket_path(self):
        """Create a temporary socket path for testing."""
        with tempfile.TemporaryDirectory() as temp_dir:
            socket_path = Path(temp_dir) / "test.sock"
            original_path = SOCKET_PATH
            
            # Patch the module-level SOCKET_PATH
            with patch("antaris_agent.daemon.ipc.SOCKET_PATH", socket_path):
                yield socket_path
    
    @pytest.mark.asyncio
    async def test_daemon_ipc_lifecycle(self, daemon_ipc, mock_bot, temp_socket_path):
        """Test starting and stopping the IPC server."""
        # Test start
        await daemon_ipc.start(mock_bot)
        assert daemon_ipc._server is not None
        assert daemon_ipc._bot is mock_bot
        assert temp_socket_path.exists()
        
        # Test stop
        await daemon_ipc.stop()
        assert not temp_socket_path.exists()

    @pytest.mark.asyncio
    async def test_stale_socket_cleanup(self, daemon_ipc, mock_bot, temp_socket_path):
        """Test that stale socket files are removed on start."""
        # Create a fake stale socket file
        temp_socket_path.parent.mkdir(parents=True, exist_ok=True)
        temp_socket_path.write_text("stale")
        assert temp_socket_path.exists()
        
        # Start should remove it
        await daemon_ipc.start(mock_bot)
        assert temp_socket_path.exists()  # But now it's the real socket
        
        await daemon_ipc.stop()

    @pytest.mark.asyncio
    async def test_cmd_status(self, daemon_ipc):
        """Test status command."""
        with patch("time.time", return_value=1500.0), \
             patch("os.getpid", return_value=12345):
            
            result = await daemon_ipc._cmd_status({})
            
            assert result["status"] == "running"
            assert result["pid"] == 12345
            assert result["uptime_seconds"] == 500.0
            assert result["sessions"] == 2
            assert result["version"] == "1.2.5"
            assert result["security_level"] == "sandboxed"

    @pytest.mark.asyncio
    async def test_cmd_status_with_psutil(self, daemon_ipc):
        """Test status command with psutil available."""
        mock_process = MagicMock()
        mock_process.memory_info.return_value.rss = 100 * 1024 * 1024  # 100 MB
        
        # Mock importing psutil and patch the module
        mock_psutil = MagicMock()
        mock_psutil.Process.return_value = mock_process
        
        with patch("time.time", return_value=1500.0), \
             patch("os.getpid", return_value=12345), \
             patch.dict("sys.modules", {"psutil": mock_psutil}), \
             patch("builtins.__import__", side_effect=lambda name, *args: mock_psutil if name == "psutil" else __import__(name, *args)):
            
            result = await daemon_ipc._cmd_status({})
            assert result["memory_mb"] == 100.0

    @pytest.mark.asyncio
    async def test_cmd_sessions_list(self, daemon_ipc):
        """Test listing sessions."""
        result = await daemon_ipc._cmd_sessions_list({})
        
        assert "sessions" in result
        sessions = result["sessions"]
        assert len(sessions) == 2
        
        session1 = next(s for s in sessions if s["id"] == "session1")
        assert session1["user_id"] == "user1"
        assert session1["platform"] == "discord"
        assert session1["message_count"] == 5
        assert session1["status"] == "active"

    @pytest.mark.asyncio
    async def test_cmd_sessions_show(self, daemon_ipc):
        """Test showing session details."""
        result = await daemon_ipc._cmd_sessions_show({"session_id": "session1"})
        
        assert result["id"] == "session1"
        assert result["user_id"] == "user1"
        assert result["message_count"] == 5
        assert result["context_pct"] == 12.5
        assert result["status"] == "active"
        assert result["buffer_length"] == 2
        assert result["history_length"] == 2

    @pytest.mark.asyncio
    async def test_cmd_sessions_show_not_found(self, daemon_ipc):
        """Test showing non-existent session."""
        result = await daemon_ipc._cmd_sessions_show({"session_id": "nonexistent"})
        assert "error" in result
        assert "not found" in result["error"]

    @pytest.mark.asyncio
    async def test_cmd_sessions_kill(self, daemon_ipc):
        """Test killing a session."""
        result = await daemon_ipc._cmd_sessions_kill({"session_id": "session1"})
        
        assert "message" in result
        assert "session1" in result["message"]
        daemon_ipc._bot.sessions.kill_session.assert_called_once_with("session1")

    @pytest.mark.asyncio
    async def test_cmd_sessions_kill_all(self, daemon_ipc):
        """Test killing all sessions."""
        result = await daemon_ipc._cmd_sessions_kill_all({})
        
        assert "message" in result
        assert "2 sessions" in result["message"]
        assert len(daemon_ipc._bot.sessions._sessions) == 0

    @pytest.mark.asyncio
    async def test_cmd_sessions_reset(self, daemon_ipc):
        """Test resetting a session."""
        result = await daemon_ipc._cmd_sessions_reset({"session_id": "session1"})
        
        assert "message" in result
        assert "session1" in result["message"]
        daemon_ipc._bot.sessions.reset_session.assert_called_once_with("session1")

    @pytest.mark.asyncio
    async def test_cmd_sessions_compact(self, daemon_ipc):
        """Test compacting a session."""
        result = await daemon_ipc._cmd_sessions_compact({"session_id": "session1"})
        
        assert "message" in result
        assert "compacted" in result["message"]
        daemon_ipc._bot.sessions.compact_session.assert_called_once_with("session1")

    @pytest.mark.asyncio
    async def test_cmd_security_status(self, daemon_ipc):
        """Test security status command."""
        result = await daemon_ipc._cmd_security_status({})
        
        assert result["security_mode"] == "sandboxed"
        assert result["guard_mode"] == "monitor"
        assert result["guard_active"] is True
        assert result["rate_limit_messages"] == 20

    @pytest.mark.asyncio
    async def test_cmd_security_set_escalation(self, daemon_ipc):
        """Test escalating security level."""
        with patch('antaris_agent.security.audit_hook.current_level', return_value=1), \
             patch('antaris_agent.security.audit_hook.escalate', return_value=True):
            result = await daemon_ipc._cmd_security_set({"level": 3})
        assert "message" in result
        assert "escalated" in result["message"].lower()
        assert result["level"] == 3

    @pytest.mark.asyncio
    async def test_cmd_security_set_downgrade_rejected(self, daemon_ipc):
        """Test that downgrade returns restart-required error."""
        with patch('antaris_agent.security.audit_hook.current_level', return_value=3), \
             patch('antaris_agent.security.audit_hook.escalate', return_value=False):
            result = await daemon_ipc._cmd_security_set({"level": 1})
        assert "error" in result
        assert result["error"] == "downgrade_requires_restart"
        assert result["current_level"] == 3
        assert result["target_level"] == 1

    @pytest.mark.asyncio
    async def test_cmd_security_set_same_level(self, daemon_ipc):
        """Test setting the same level is a no-op."""
        with patch('antaris_agent.security.audit_hook.current_level', return_value=2), \
             patch('antaris_agent.security.audit_hook.escalate', return_value=False):
            result = await daemon_ipc._cmd_security_set({"level": 2})
        assert "message" in result
        assert result["level"] == 2

    @pytest.mark.asyncio
    async def test_cmd_security_set_legacy_string(self, daemon_ipc):
        """Test setting security level via legacy string mode."""
        with patch('antaris_agent.security.audit_hook.current_level', return_value=0), \
             patch('antaris_agent.security.audit_hook.escalate', return_value=True):
            result = await daemon_ipc._cmd_security_set({"level": "sandboxed"})
        assert "message" in result
        assert result["level"] == 2

    @pytest.mark.asyncio
    async def test_cmd_security_set_with_lock_engaged(self, daemon_ipc):
        """Test that security lock blocks unauthorized downgrade."""
        from antaris_agent.security.security_lock import SecurityLock
        lock = SecurityLock()
        lock.set_lock(min_level=2, auth="none")
        daemon_ipc._bot.security_lock = lock
        with patch('antaris_agent.security.audit_hook.current_level', return_value=3):
            result = await daemon_ipc._cmd_security_set({"level": 1})
        assert "error" in result
        assert "locked" in result["error"].lower() or "floor" in result["error"].lower() or "lock" in result["error"].lower()
        # Restore
        daemon_ipc._bot.security_lock = None

    @pytest.mark.asyncio
    async def test_cmd_security_set_missing_param(self, daemon_ipc):
        """Test that missing level param returns error."""
        result = await daemon_ipc._cmd_security_set({})
        assert "error" in result

    @pytest.mark.asyncio 
    async def test_cmd_security_set_invalid(self, daemon_ipc):
        """Test setting invalid security level string."""
        result = await daemon_ipc._cmd_security_set({"level": "invalid_string"})
        assert "error" in result

    @pytest.mark.asyncio
    async def test_cmd_security_set_out_of_range(self, daemon_ipc):
        """Test setting out-of-range integer level."""
        result = await daemon_ipc._cmd_security_set({"level": 9})
        assert "error" in result
        assert "0-4" in result["error"]

    @pytest.mark.asyncio
    async def test_cmd_tools_list(self, daemon_ipc):
        """Test listing tools."""
        result = await daemon_ipc._cmd_tools_list({})
        
        assert "tools" in result
        tools = result["tools"]
        assert len(tools) == 2
        
        web_search = next(t for t in tools if t["name"] == "web_search")
        assert web_search["source"] == "native"

    @pytest.mark.asyncio
    async def test_cmd_tools_status(self, daemon_ipc):
        """Test tool status."""
        result = await daemon_ipc._cmd_tools_status({})
        
        assert result["available"] is True
        assert result["total_tools"] == 2
        assert result["native_tools"] == 2

    @pytest.mark.asyncio
    async def test_cmd_config_get_specific(self, daemon_ipc):
        """Test getting specific config value."""
        result = await daemon_ipc._cmd_config_get({"key": "security_mode"})
        
        assert result["key"] == "security_mode"
        assert result["value"] == "sandboxed"

    @pytest.mark.asyncio
    async def test_cmd_config_get_all(self, daemon_ipc):
        """Test getting all config values."""
        result = await daemon_ipc._cmd_config_get({})
        
        assert "config" in result
        config = result["config"]
        assert "security_mode" in config
        # Sensitive keys should not be included
        assert "api_key" not in config
        assert "discord_token" not in config

    @pytest.mark.asyncio
    async def test_cmd_config_validate(self, daemon_ipc):
        """Test config validation."""
        with patch("pathlib.Path.exists", return_value=True):
            result = await daemon_ipc._cmd_config_validate({})
            
            assert result["valid"] is True
            assert len(result["issues"]) == 0

    @pytest.mark.asyncio
    async def test_cmd_config_validate_issues(self, daemon_ipc):
        """Test config validation with issues."""
        daemon_ipc._bot.config.api_key = ""  # Missing API key
        daemon_ipc._bot.config.discord_token = ""  # Discord enabled but no token
        
        with patch("pathlib.Path.exists", return_value=False):
            result = await daemon_ipc._cmd_config_validate({})
            
            assert result["valid"] is False
            assert len(result["issues"]) >= 2

    @pytest.mark.asyncio
    async def test_dispatch_unknown_command(self, daemon_ipc):
        """Test dispatching unknown command."""
        result = await daemon_ipc._dispatch("unknown", {})
        
        assert "error" in result
        assert "Unknown command" in result["error"]

    @pytest.mark.asyncio
    async def test_dispatch_command_exception(self, daemon_ipc):
        """Test command handler exception."""
        # Make status command raise an exception by breaking getattr
        daemon_ipc._bot = None
        
        result = await daemon_ipc._dispatch("status", {})
        assert "error" in result
        assert "Command failed" in result["error"]

    @pytest.mark.asyncio
    async def test_no_sessions_manager(self, mock_bot):
        """Test commands when sessions manager is not available."""
        delattr(mock_bot, 'sessions')  # Remove sessions attribute
        ipc = DaemonIPC()
        ipc._bot = mock_bot
        
        result = await ipc._cmd_sessions_list({})
        assert "error" in result
        assert "not available" in result["error"]

    @pytest.mark.asyncio
    async def test_no_tool_registry(self, mock_bot):
        """Test tool commands when tool registry is not available.""" 
        mock_bot.tool_registry = None
        ipc = DaemonIPC()
        ipc._bot = mock_bot
        
        result = await ipc._cmd_tools_list({})
        assert "tools" in result
        assert len(result["tools"]) == 0

        result = await ipc._cmd_tools_status({})
        assert result["available"] is False


@pytest.mark.filterwarnings("ignore::RuntimeWarning")
class TestDaemonClient:
    """Test the client-side IPC communication."""

    @pytest.fixture
    def temp_socket_path(self):
        """Create a temporary socket path for testing."""
        with tempfile.TemporaryDirectory() as temp_dir:
            socket_path = Path(temp_dir) / "test.sock"
            
            # Patch the module-level SOCKET_PATH
            with patch("antaris_agent.daemon.ipc.SOCKET_PATH", socket_path):
                yield socket_path

    @pytest.mark.asyncio
    async def test_client_daemon_not_running(self, temp_socket_path):
        """Test client when daemon is not running."""
        result = await DaemonClient.send("status")
        
        assert "error" in result
        assert "not running" in result["error"]

    @pytest.mark.asyncio
    async def test_client_successful_communication(self, temp_socket_path):
        """Test successful client-daemon communication."""
        # Start a mock server
        async def mock_handler(reader, writer):
            data = await reader.readline()
            request = json.loads(data.decode().strip())
            
            if request["command"] == "status":
                response = {"status": "running", "pid": 12345}
            else:
                response = {"error": "Unknown command"}
            
            writer.write((json.dumps(response) + "\n").encode())
            await writer.drain()
            writer.close()
            await writer.wait_closed()

        server = await asyncio.start_unix_server(mock_handler, path=str(temp_socket_path))
        
        try:
            result = await DaemonClient.send("status")
            assert result["status"] == "running"
            assert result["pid"] == 12345
        finally:
            server.close()
            await server.wait_closed()

    @pytest.mark.asyncio
    async def test_client_timeout(self, temp_socket_path):
        """Test client timeout."""
        # Start a server that doesn't respond
        writers_to_close: list = []

        async def slow_handler(reader, writer):
            writers_to_close.append(writer)
            await asyncio.sleep(15)  # Longer than timeout

        server = await asyncio.start_unix_server(slow_handler, path=str(temp_socket_path))
        
        try:
            result = await DaemonClient.send("status")
            assert "error" in result
            assert "did not respond" in result["error"]
        finally:
            for w in writers_to_close:
                try:
                    w.close()
                except Exception:
                    pass
            server.close()
            await server.wait_closed()

    @pytest.mark.asyncio
    async def test_client_connection_refused(self, temp_socket_path):
        """Test client when connection is refused."""
        # Create socket file but no server listening
        temp_socket_path.touch()
        
        result = await DaemonClient.send("status")
        # Avoid unawaited coroutine warning from DaemonClient.send_sync using asyncio.run
        await asyncio.sleep(0)
        assert "error" in result
        assert ("connection refused" in result["error"] or "Socket operation" in result["error"])

    @pytest.mark.asyncio
    async def test_client_invalid_response(self, temp_socket_path):
        """Test client with invalid JSON response."""
        async def bad_handler(reader, writer):
            await reader.readline()
            writer.write(b"invalid json\n")
            await writer.drain()
            writer.close()
            await writer.wait_closed()

        server = await asyncio.start_unix_server(bad_handler, path=str(temp_socket_path))
        
        try:
            result = await DaemonClient.send("status")
            assert "error" in result
            assert "Invalid response" in result["error"]
        finally:
            server.close()
            await server.wait_closed()

    @pytest.mark.asyncio
    async def test_client_empty_response(self, temp_socket_path):
        """Test client with empty response."""
        async def empty_handler(reader, writer):
            await reader.readline()
            writer.close()
            await writer.wait_closed()

        server = await asyncio.start_unix_server(empty_handler, path=str(temp_socket_path))
        
        try:
            result = await DaemonClient.send("status")
            assert "error" in result
            assert "Empty response" in result["error"]
        finally:
            server.close()
            await server.wait_closed()

    def test_client_send_sync(self):
        """Test synchronous client wrapper."""
        async def fake_send(*args, **kwargs):
            return {"status": "running"}

        # DaemonClient.send is async; patch with an async function so asyncio.run
        # doesn't receive a plain dict.
        with patch.object(DaemonClient, 'send', side_effect=fake_send):
            result = DaemonClient.send_sync("status")
            assert result["status"] == "running"

    def test_client_send_sync_exercises_asyncio_run(self):
        """Test send_sync uses asyncio.run to invoke the async send coroutine."""
        import gc
        import warnings
        expected = {"status": "ok", "command": "status"}

        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            with patch("asyncio.run", return_value=expected) as mock_run:
                result = DaemonClient.send_sync("status", {"key": "val"})
                # asyncio.run normally consumes the coroutine; our patch doesn't.
                # Close it immediately AND force GC inside the warnings filter
                # to prevent the "coroutine never awaited" warning from leaking
                # into pytest's unraisable-exception handler at teardown.
                coro = mock_run.call_args[0][0]
                coro.close()
            gc.collect()

        assert result["status"] == "ok"
        assert result["command"] == "status"
        mock_run.assert_called_once()

    def test_client_send_sync_exception(self):
        """Test synchronous client wrapper with exception."""
        with patch("asyncio.run", side_effect=Exception("test error")):
            result = DaemonClient.send_sync("status")
            assert "error" in result
            assert "Failed to send command" in result["error"]


class TestHandleClient:
    """Test the _handle_client method specifically."""

    @pytest.fixture
    def daemon_ipc(self):
        """Create basic DaemonIPC instance."""
        ipc = DaemonIPC()
        ipc._bot = MagicMock()
        return ipc

    @pytest.mark.asyncio
    async def test_handle_client_timeout(self, daemon_ipc):
        """Test client handler with timeout."""
        reader = AsyncMock()
        writer = MagicMock()
        writer.write = MagicMock()
        writer.drain = AsyncMock()
        writer.close = MagicMock()
        writer.wait_closed = AsyncMock()
        
        reader.readline.side_effect = asyncio.TimeoutError()
        
        await daemon_ipc._handle_client(reader, writer)
        
        # Should write timeout error
        assert writer.write.called
        call_args = writer.write.call_args[0][0]
        response = json.loads(call_args.decode().strip())
        assert "error" in response
        assert "timeout" in response["error"].lower()

    @pytest.mark.asyncio
    async def test_handle_client_invalid_json(self, daemon_ipc):
        """Test client handler with invalid JSON."""
        reader = AsyncMock()
        writer = MagicMock()
        writer.write = MagicMock()
        writer.drain = AsyncMock()
        writer.close = MagicMock()
        writer.wait_closed = AsyncMock()
        
        reader.readline.return_value = b"invalid json\n"
        
        await daemon_ipc._handle_client(reader, writer)
        
        # Should write JSON error
        assert writer.write.called
        call_args = writer.write.call_args[0][0]
        response = json.loads(call_args.decode().strip())
        assert "error" in response
        assert "Invalid JSON" in response["error"]

    @pytest.mark.asyncio
    async def test_handle_client_empty_data(self, daemon_ipc):
        """Test client handler with empty data."""
        reader = AsyncMock()
        writer = MagicMock()
        writer.close = MagicMock()
        writer.wait_closed = AsyncMock()
        
        reader.readline.return_value = b""
        
        await daemon_ipc._handle_client(reader, writer)
        
        # Should close without error
        writer.close.assert_called_once()

    @pytest.mark.asyncio
    async def test_handle_client_success(self, daemon_ipc):
        """Test successful client handling."""
        reader = AsyncMock()
        writer = MagicMock()
        writer.write = MagicMock()
        writer.drain = AsyncMock()
        writer.close = MagicMock()
        writer.wait_closed = AsyncMock()
        
        request = {"command": "status", "params": {}}
        reader.readline.return_value = (json.dumps(request) + "\n").encode()
        
        # Mock the dispatch method
        daemon_ipc._dispatch = AsyncMock(return_value={"status": "running"})
        
        await daemon_ipc._handle_client(reader, writer)
        
        # Should write success response
        assert writer.write.called
        call_args = writer.write.call_args[0][0]
        response = json.loads(call_args.decode().strip())
        assert response["status"] == "running"