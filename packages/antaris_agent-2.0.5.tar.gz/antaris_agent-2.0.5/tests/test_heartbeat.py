"""
Tests for HeartbeatManager.
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch

from antaris_agent.core.heartbeat import HeartbeatManager
from antaris_agent.core.config import Config
from antaris_agent.core.cron import CronJob


class MockBot:
    """Mock Bot for testing"""
    def __init__(self):
        self.config = Config()
        self.config.heartbeat_enabled = True
        self.config.heartbeat_interval_minutes = 30
        self.config.owner_user_id = "123456789"
        
        self.memory = Mock()
        self.memory.stats.return_value = {"total": 100, "status": "ok"}
        
        self.cron = Mock()
        self.cron.add_job = Mock()
        self.cron.remove_job = Mock(return_value=True)
        self.cron.get_job = Mock(return_value=None)  # no existing jobs by default
        self.cron.list_jobs = Mock(return_value=[])   # no stale jobs
        
        self.daily_log = Mock()
        self.daily_log.write = Mock()
        
        self._channels = []


@pytest.fixture
def mock_bot():
    return MockBot()


@pytest.fixture
def heartbeat_manager(mock_bot):
    return HeartbeatManager(mock_bot)


def test_heartbeat_manager_init(heartbeat_manager, mock_bot):
    """Test HeartbeatManager initialization"""
    assert heartbeat_manager.bot == mock_bot
    assert heartbeat_manager.config == mock_bot.config
    assert heartbeat_manager.memory == mock_bot.memory
    assert heartbeat_manager.cron == mock_bot.cron
    assert heartbeat_manager._enabled is True
    assert heartbeat_manager._interval_minutes == 30


def test_heartbeat_manager_disabled(mock_bot):
    """Test HeartbeatManager when disabled"""
    mock_bot.config.heartbeat_enabled = False
    heartbeat_manager = HeartbeatManager(mock_bot)
    assert heartbeat_manager.is_enabled() is False


def test_start_disabled(heartbeat_manager, mock_bot):
    """Test start() when heartbeat is disabled"""
    mock_bot.config.heartbeat_enabled = False
    heartbeat_manager._enabled = False
    
    heartbeat_manager.start()
    
    mock_bot.cron.add_job.assert_not_called()


def test_start_no_cron(heartbeat_manager, mock_bot):
    """Test start() when cron is not available"""
    mock_bot.cron = None
    heartbeat_manager.cron = None
    
    heartbeat_manager.start()
    
    # Should not raise an error


def test_start_enabled(heartbeat_manager, mock_bot):
    """Test start() when enabled"""
    heartbeat_manager.start()
    
    mock_bot.cron.add_job.assert_called_once()
    
    # Check the job that was added
    call_args = mock_bot.cron.add_job.call_args[0]
    job = call_args[0]
    
    assert isinstance(job, CronJob)
    assert job.name == "Heartbeat Check"
    assert job.schedule_kind == "every"
    assert job.schedule_every_ms == 30 * 60 * 1000  # 30 minutes in ms
    assert job.payload_kind == "systemEvent"
    assert job.payload_text == "heartbeat_tick"
    assert job.enabled is True


def test_stop(heartbeat_manager, mock_bot):
    """Test stop() method"""
    # Start first to get a job ID
    heartbeat_manager.start()
    
    heartbeat_manager.stop()
    
    mock_bot.cron.remove_job.assert_called_once()
    assert heartbeat_manager._job_id is None


@pytest.mark.asyncio
async def test_tick_disabled(heartbeat_manager, mock_bot):
    """Test tick() when disabled"""
    mock_bot.config.heartbeat_enabled = False
    heartbeat_manager._enabled = False
    
    result = await heartbeat_manager.tick()
    
    assert result == {"error": "heartbeat_disabled"}


@pytest.mark.asyncio
async def test_tick_enabled(heartbeat_manager, mock_bot):
    """Test tick() when enabled"""
    result = await heartbeat_manager.tick()
    
    assert "timestamp" in result
    assert "checks" in result
    assert "urgent_items" in result
    assert "session_state" in result
    assert "duration_seconds" in result
    
    # Should have run all checks
    assert "email" in result["checks"]
    assert "calendar" in result["checks"]
    assert "memory" in result["checks"]


@pytest.mark.asyncio
async def test_check_email(heartbeat_manager):
    """Test _check_email() placeholder"""
    result = await heartbeat_manager._check_email()
    
    assert result["status"] == "placeholder"
    assert "Email check not implemented" in result["message"]
    assert result["urgent"] is False


@pytest.mark.asyncio
async def test_check_calendar(heartbeat_manager):
    """Test _check_calendar() placeholder"""
    result = await heartbeat_manager._check_calendar()
    
    assert result["status"] == "placeholder"
    assert "Calendar check not implemented" in result["message"]
    assert result["urgent"] is False


def test_check_memory_health_success(heartbeat_manager, mock_bot):
    """Test _check_memory_health() with healthy memory"""
    result = heartbeat_manager._check_memory_health()
    
    assert result["status"] == "ok"
    assert result["total_memories"] == 100
    assert result["urgent"] is False
    assert "Memory system healthy" in result["message"]


def test_check_memory_health_no_memory(heartbeat_manager):
    """Test _check_memory_health() with no memory system"""
    heartbeat_manager.memory = None
    
    result = heartbeat_manager._check_memory_health()
    
    assert result["status"] == "error"
    assert "Memory system not available" in result["message"]
    assert result["urgent"] is False


def test_check_memory_health_high_count(heartbeat_manager, mock_bot):
    """Test _check_memory_health() with high memory count"""
    mock_bot.memory.stats.return_value = {"total": 60000}
    
    result = heartbeat_manager._check_memory_health()
    
    assert result["status"] == "ok"
    assert result["total_memories"] == 60000
    assert result["urgent"] is True
    assert "High memory count" in str(result["warnings"])


def test_check_memory_health_error(heartbeat_manager, mock_bot):
    """Test _check_memory_health() with memory error"""
    mock_bot.memory.stats.side_effect = Exception("Memory error")
    
    result = heartbeat_manager._check_memory_health()
    
    assert result["status"] == "error"
    assert "Failed to get memory stats" in result["message"]
    assert result["urgent"] is True


@pytest.mark.asyncio
async def test_save_session_state_success(heartbeat_manager, mock_bot):
    """Test _save_session_state() success"""
    result = await heartbeat_manager._save_session_state()
    
    assert result["status"] == "ok"
    assert "Session state saved" in result["message"]
    mock_bot.daily_log.write.assert_called_once()


@pytest.mark.asyncio
async def test_save_session_state_no_daily_log(heartbeat_manager, mock_bot):
    """Test _save_session_state() without daily log"""
    mock_bot.daily_log = None
    heartbeat_manager.bot.daily_log = None
    
    result = await heartbeat_manager._save_session_state()
    
    assert result["status"] == "ok"


@pytest.mark.asyncio 
async def test_notify_urgent_items_no_owner(heartbeat_manager, mock_bot):
    """Test _notify_urgent_items() with no owner configured"""
    mock_bot.config.owner_user_id = ""
    
    urgent_items = [{"source": "memory", "message": "High memory usage"}]
    
    # Should not raise an error
    await heartbeat_manager._notify_urgent_items(urgent_items)


@pytest.mark.asyncio
async def test_notify_urgent_items_no_discord(heartbeat_manager, mock_bot):
    """Test _notify_urgent_items() with no Discord adapter"""
    urgent_items = [{"source": "memory", "message": "High memory usage"}]
    
    # Should not raise an error
    await heartbeat_manager._notify_urgent_items(urgent_items)


@pytest.mark.asyncio
async def test_tick_with_urgent_items(heartbeat_manager, mock_bot):
    """Test tick() with urgent memory issue"""
    # Set up high memory count to trigger urgent
    mock_bot.memory.stats.return_value = {"total": 60000}
    
    with patch.object(heartbeat_manager, '_notify_urgent_items', new_callable=AsyncMock) as mock_notify:
        result = await heartbeat_manager.tick()
    
    assert len(result["urgent_items"]) == 1
    assert result["urgent_items"][0]["source"] == "memory"
    mock_notify.assert_called_once()


@pytest.mark.asyncio
async def test_tick_error_handling(heartbeat_manager, mock_bot):
    """Test tick() error handling"""
    # Make memory check fail
    mock_bot.memory.stats.side_effect = Exception("Memory error")
    
    result = await heartbeat_manager.tick()
    
    # Should still complete and return results
    assert "checks" in result
    assert "memory" in result["checks"]
    assert result["checks"]["memory"]["status"] == "error"


def test_heartbeat_manager_no_memory(mock_bot):
    """Test HeartbeatManager when bot has no memory"""
    mock_bot.memory = None
    heartbeat_manager = HeartbeatManager(mock_bot)
    assert heartbeat_manager.memory is None


def test_heartbeat_manager_no_cron(mock_bot):
    """Test HeartbeatManager when bot has no cron"""
    mock_bot.cron = None
    heartbeat_manager = HeartbeatManager(mock_bot)
    assert heartbeat_manager.cron is None


def test_heartbeat_manager_no_channels(mock_bot):
    """Test HeartbeatManager when bot has no channels"""
    delattr(mock_bot, '_channels')
    heartbeat_manager = HeartbeatManager(mock_bot)
    # Should not crash


def test_start_invalid_interval(heartbeat_manager, mock_bot):
    """Test start() with invalid interval"""
    mock_bot.config.heartbeat_interval_minutes = 0
    heartbeat_manager._interval_minutes = 0
    
    heartbeat_manager.start()
    
    # Should not call add_job due to invalid interval
    mock_bot.cron.add_job.assert_not_called()


def test_start_cron_no_add_job(heartbeat_manager, mock_bot):
    """Test start() when cron doesn't have add_job method"""
    delattr(mock_bot.cron, 'add_job')
    
    heartbeat_manager.start()
    
    # Should not crash


def test_start_add_job_exception(heartbeat_manager, mock_bot):
    """Test start() when add_job raises exception"""
    mock_bot.cron.add_job.side_effect = Exception("Cron error")
    
    heartbeat_manager.start()
    
    assert heartbeat_manager._job_id is None


def test_stop_no_remove_job(heartbeat_manager, mock_bot):
    """Test stop() when cron doesn't have remove_job method"""
    heartbeat_manager._job_id = "test_job"
    delattr(mock_bot.cron, 'remove_job')
    
    # Should not crash
    heartbeat_manager.stop()
    assert heartbeat_manager._job_id is None


def test_stop_remove_job_exception(heartbeat_manager, mock_bot):
    """Test stop() when remove_job raises exception"""
    heartbeat_manager._job_id = "test_job"
    mock_bot.cron.remove_job.side_effect = Exception("Cron error")
    
    heartbeat_manager.stop()
    
    assert heartbeat_manager._job_id is None


@pytest.mark.asyncio
async def test_notify_urgent_items_invalid_owner_id(heartbeat_manager, mock_bot):
    """Test _notify_urgent_items() with invalid owner ID"""
    mock_bot.config.owner_user_id = "not_a_number"
    
    urgent_items = [{"source": "memory", "message": "High memory usage"}]
    
    # Should not raise an error, but log error
    await heartbeat_manager._notify_urgent_items(urgent_items)


@pytest.mark.asyncio
async def test_notify_urgent_items_empty_list(heartbeat_manager, mock_bot):
    """Test _notify_urgent_items() with empty urgent items list"""
    urgent_items = []
    
    # Should not raise an error or do anything
    await heartbeat_manager._notify_urgent_items(urgent_items)


@pytest.mark.asyncio
async def test_save_session_state_no_write_method(heartbeat_manager, mock_bot):
    """Test _save_session_state() when daily_log has no write method"""
    mock_bot.daily_log = object()  # Object with no write method
    
    result = await heartbeat_manager._save_session_state()
    
    assert result["status"] == "ok"
    assert "Daily log not available" in result["message"]


@pytest.mark.asyncio
async def test_save_session_state_write_exception(heartbeat_manager, mock_bot):
    """Test _save_session_state() when write method raises exception"""
    mock_bot.daily_log.write.side_effect = Exception("Write error")
    
    result = await heartbeat_manager._save_session_state()
    
    assert result["status"] == "error"
    assert "Failed to save session state" in result["message"]


def test_check_memory_health_no_total_in_stats(heartbeat_manager, mock_bot):
    """Test _check_memory_health() when stats doesn't have total"""
    mock_bot.memory.stats.return_value = {"status": "ok"}  # No total field
    
    result = heartbeat_manager._check_memory_health()
    
    assert result["status"] == "ok"
    assert result["total_memories"] == 0
    assert "No memories stored" in str(result["warnings"])