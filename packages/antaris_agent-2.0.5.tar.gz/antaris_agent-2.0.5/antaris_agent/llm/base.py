from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, Union, List, Dict, Any


@dataclass
class Message:
    role: str  # "user" | "assistant" | "system"
    content: Union[str, List[Dict[str, Any]]]  # Support both text and structured content


@dataclass
class LLMResponse:
    content: str
    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    tool_use: Optional[list[dict]] = None  # List of tool use blocks from LLM
    thinking_content: Optional[str] = None  # Extended thinking output (if enabled)


@dataclass
class ThinkingConfig:
    """Configuration for extended thinking / reasoning mode.
    
    Propagated from ModelController through the pipeline into provider calls.
    Each provider maps this to its own API format:
      - Anthropic: thinking.type="enabled", thinking.budget_tokens
      - OpenAI: reasoning.effort (o-series models)
      - Google: thinkingConfig.thinkingBudget
    """
    enabled: bool = False
    budget_tokens: int = 0
    level: str = "off"  # off | low | medium | high | max

    @classmethod
    def from_level(cls, level: str, budget: int = 0) -> 'ThinkingConfig':
        """Create from a thinking level string."""
        if level == "off" or not level:
            return cls(enabled=False, budget_tokens=0, level="off")
        return cls(enabled=True, budget_tokens=budget, level=level)


class LLMProvider(ABC):
    def __init__(self, api_key: str, model: str):
        self.api_key = api_key
        self.model = model

    @abstractmethod
    async def complete(
        self,
        messages: list[Message],
        system: str,
        model: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        tools: Optional[list[dict]] = None,
        thinking: Optional[ThinkingConfig] = None,
    ) -> LLMResponse:
        """Send messages, return response.
        
        Args:
            thinking: Optional thinking/reasoning configuration.
                      When enabled, the provider should use extended thinking
                      according to its API capabilities.
        """
        pass

    @abstractmethod
    def estimate_tokens(self, text: str) -> int:
        """Rough token estimate (chars / 4)."""
        pass
