"""Single source of truth for the Antaris package version."""

__version__ = "2.0.5"
