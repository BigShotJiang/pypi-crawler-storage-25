class DecodeError(ValueError):
    pass
