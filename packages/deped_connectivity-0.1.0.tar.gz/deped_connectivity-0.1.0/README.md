# deped-connectivity

`deped-connectivity` extracts workbook rows and builds a standalone connectivity SQLite database. It consumes the lookup artifact from `deped-template` and the entity artifact from `deped-entity`.

## What This Package Owns

- Extracting flattened CSV rows from the connectivity workbook
- Building the connectivity database from extracted rows
- Matching rows to governance entities using the upstream entity artifact
- Connectivity-specific views and audit commands

This package owns both the extractor contract and the connectivity database contract.

## Inputs And Outputs

Required inputs:

- a connectivity workbook for extraction
- an extracted connectivity CSV for the build step
- a lookup database produced by `deped-template`
- an entity database produced by `deped-entity`

Primary outputs:

- extracted connectivity CSV
- `connectivity.db`

The connectivity database includes staging rows, matched submissions, option lookup tables, and unmatched-stage diagnostics.

## CLI

Extract workbook rows:

```bash
uv run web extract \
  --xlsx data/2026-04-01-connectivity.xlsx \
  --csv artifacts/connectivity.csv
```

Build the connectivity database:

```bash
uv run web build \
  --connectivity artifacts/connectivity.csv \
  --lookups artifacts/lookups.db \
  --entities-db artifacts/entities.db \
  --db artifacts/connectivity.db
```

Run the lightweight audit command:

```bash
uv run web audit \
  --db artifacts/connectivity.db
```

## Nuances

- Extraction and build are intentionally separate. If the workbook header layout changes, the fix belongs in the extractor layer, not in the database loader.
- Entity loading is artifact-driven. This package imports entities from `entities.db` and matches connectivity rows against that upstream dimension.
- This package does not own school staffing or equipment enrichment views. Those were monolith surfaces and are no longer part of the supported contract.

## Tests

Run the package tests from this directory:

```bash
uv run pytest -q
```

Package-local coverage is split between:

- [tests/test_connectivity_extractor.py](tests/test_connectivity_extractor.py) for workbook extraction
- [tests/test_connectivity_build.py](tests/test_connectivity_build.py) for governance matching and database build behavior
