CREATE VIEW v_connectivity_stage_unmatched AS
SELECT *
FROM connectivity_stage
WHERE stage_status = 'unmatched';
