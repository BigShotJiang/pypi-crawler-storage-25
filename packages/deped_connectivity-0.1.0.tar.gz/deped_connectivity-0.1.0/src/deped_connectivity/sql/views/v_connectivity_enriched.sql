CREATE VIEW v_connectivity_enriched AS
SELECT
    cs.*,
    e.entity_type,
    e.entity_name,
    e.region AS entity_region,
    e.division AS entity_division
FROM connectivity_submissions cs
JOIN entities e ON e.entity_id = cs.entity_id;
