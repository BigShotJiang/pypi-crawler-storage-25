CREATE TABLE build_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    build_type TEXT NOT NULL,
    started_at TEXT NOT NULL,
    completed_at TEXT NULL,
    schema_version TEXT NOT NULL,
    lookups_source_file TEXT NOT NULL,
    lookups_source_hash TEXT NOT NULL,
    entities_source_file TEXT NOT NULL,
    entities_source_hash TEXT NOT NULL,
    connectivity_source_file TEXT NULL,
    connectivity_source_hash TEXT NULL,
    connectivity_source_rows INTEGER NULL,
    entity_count INTEGER NULL,
    connectivity_stage_count INTEGER NULL,
    connectivity_submission_count INTEGER NULL
);
