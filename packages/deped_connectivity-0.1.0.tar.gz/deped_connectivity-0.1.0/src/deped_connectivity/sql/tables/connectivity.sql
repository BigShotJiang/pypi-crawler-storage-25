CREATE TABLE connectivity_stage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    natural_key TEXT NULL,
    entity_id INTEGER NULL REFERENCES entities(entity_id),
    stage_status TEXT NOT NULL,
    error_reason TEXT NULL,
    source_file TEXT NOT NULL,
    source_sheet TEXT NOT NULL,
    source_row_num INTEGER NOT NULL,
    source_record_id INTEGER NULL,
    governance_level TEXT,
    region TEXT,
    division TEXT,
    school_id INTEGER NULL,
    school_name TEXT,
    has_isp_in_area INTEGER NOT NULL DEFAULT 0,
    has_mobile_data_connectivity INTEGER NOT NULL DEFAULT 0,
    mobile_connectivity_quality INTEGER NULL,
    subscribes_to_isp INTEGER NOT NULL DEFAULT 0,
    total_isps INTEGER NULL,
    monthly_isp_cost REAL NULL,
    internet_access_spend_total REAL NULL,
    internet_access_projected_spend REAL NULL,
    use_admin INTEGER NOT NULL DEFAULT 0,
    use_classroom INTEGER NOT NULL DEFAULT 0,
    use_both INTEGER NOT NULL DEFAULT 0,
    rooms_admin INTEGER NULL,
    rooms_classroom INTEGER NULL,
    rooms_other INTEGER NULL,
    rooms_total INTEGER NULL,
    access_points_total INTEGER NULL,
    bandwidth_challenges TEXT,
    dict_free_wifi_recipient INTEGER NOT NULL DEFAULT 0,
    dict_free_wifi_rating INTEGER NULL,
    has_sufficient_bandwidth INTEGER NOT NULL DEFAULT 0,
    no_subscription_reason TEXT,
    has_electricity INTEGER NOT NULL DEFAULT 0,
    primarily_solar_powered INTEGER NOT NULL DEFAULT 0,
    frequent_brownouts INTEGER NOT NULL DEFAULT 0,
    available_isp_globe INTEGER NOT NULL DEFAULT 0,
    available_isp_smart INTEGER NOT NULL DEFAULT 0,
    available_isp_pldt INTEGER NOT NULL DEFAULT 0,
    available_isp_skycable INTEGER NOT NULL DEFAULT 0,
    available_isp_converge INTEGER NOT NULL DEFAULT 0,
    available_isp_starlink INTEGER NOT NULL DEFAULT 0,
    available_isp_eastern_communications INTEGER NOT NULL DEFAULT 0,
    available_isp_dito_telecommunity INTEGER NOT NULL DEFAULT 0,
    available_isp_other INTEGER NOT NULL DEFAULT 0,
    subscribed_isp_globe INTEGER NOT NULL DEFAULT 0,
    subscribed_isp_smart INTEGER NOT NULL DEFAULT 0,
    subscribed_isp_pldt INTEGER NOT NULL DEFAULT 0,
    subscribed_isp_skycable INTEGER NOT NULL DEFAULT 0,
    subscribed_isp_converge INTEGER NOT NULL DEFAULT 0,
    subscribed_isp_starlink INTEGER NOT NULL DEFAULT 0,
    subscribed_isp_eastern_communications INTEGER NOT NULL DEFAULT 0,
    subscribed_isp_dito_telecommunity INTEGER NOT NULL DEFAULT 0,
    subscribed_isp_dict INTEGER NOT NULL DEFAULT 0,
    mobile_signal_3g INTEGER NOT NULL DEFAULT 0,
    mobile_signal_lte_4g_lte INTEGER NOT NULL DEFAULT 0,
    mobile_signal_lte_advanced_true_4g INTEGER NOT NULL DEFAULT 0,
    mobile_signal_5g INTEGER NOT NULL DEFAULT 0,
    mobile_signal_no_signal INTEGER NOT NULL DEFAULT 0,
    coverage_area_building_office_wide INTEGER NOT NULL DEFAULT 0,
    coverage_area_school_wide INTEGER NOT NULL DEFAULT 0,
    coverage_area_faculty_area INTEGER NOT NULL DEFAULT 0,
    coverage_area_principal_office INTEGER NOT NULL DEFAULT 0,
    coverage_area_elementary_school INTEGER NOT NULL DEFAULT 0,
    coverage_area_junior_high_school_area INTEGER NOT NULL DEFAULT 0,
    coverage_area_senior_high_school_area INTEGER NOT NULL DEFAULT 0,
    coverage_area_ict_room_laboratory INTEGER NOT NULL DEFAULT 0,
    coverage_area_library INTEGER NOT NULL DEFAULT 0,
    coverage_area_other_area INTEGER NOT NULL DEFAULT 0,
    electricity_source_grid INTEGER NOT NULL DEFAULT 0,
    electricity_source_generator INTEGER NOT NULL DEFAULT 0,
    electricity_source_solar INTEGER NOT NULL DEFAULT 0,
    electricity_source_none INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE connectivity_submissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_stage_id INTEGER NOT NULL UNIQUE REFERENCES connectivity_stage(id),
    entity_id INTEGER NOT NULL REFERENCES entities(entity_id),
    natural_key TEXT NOT NULL,
    source_file TEXT NOT NULL,
    source_sheet TEXT NOT NULL,
    source_row_num INTEGER NOT NULL,
    source_record_id INTEGER NULL,
    governance_level TEXT,
    region TEXT,
    division TEXT,
    school_id INTEGER NULL,
    school_name TEXT,
    has_isp_in_area INTEGER NOT NULL DEFAULT 0,
    has_mobile_data_connectivity INTEGER NOT NULL DEFAULT 0,
    mobile_connectivity_quality INTEGER NULL,
    subscribes_to_isp INTEGER NOT NULL DEFAULT 0,
    total_isps INTEGER NULL,
    monthly_isp_cost REAL NULL,
    internet_access_spend_total REAL NULL,
    internet_access_projected_spend REAL NULL,
    use_admin INTEGER NOT NULL DEFAULT 0,
    use_classroom INTEGER NOT NULL DEFAULT 0,
    use_both INTEGER NOT NULL DEFAULT 0,
    rooms_admin INTEGER NULL,
    rooms_classroom INTEGER NULL,
    rooms_other INTEGER NULL,
    rooms_total INTEGER NULL,
    access_points_total INTEGER NULL,
    bandwidth_challenges TEXT,
    dict_free_wifi_recipient INTEGER NOT NULL DEFAULT 0,
    dict_free_wifi_rating INTEGER NULL,
    has_sufficient_bandwidth INTEGER NOT NULL DEFAULT 0,
    no_subscription_reason TEXT,
    has_electricity INTEGER NOT NULL DEFAULT 0,
    primarily_solar_powered INTEGER NOT NULL DEFAULT 0,
    frequent_brownouts INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE connectivity_isp_options (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL
);

CREATE TABLE connectivity_mobile_signal_options (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL
);

CREATE TABLE connectivity_coverage_area_options (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL
);

CREATE TABLE connectivity_electricity_source_options (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL
);

CREATE TABLE connectivity_available_isps (
    submission_id INTEGER NOT NULL REFERENCES connectivity_submissions(id),
    isp_option_id INTEGER NOT NULL REFERENCES connectivity_isp_options(id),
    PRIMARY KEY (submission_id, isp_option_id)
);

CREATE TABLE connectivity_subscribed_isps (
    submission_id INTEGER NOT NULL REFERENCES connectivity_submissions(id),
    isp_option_id INTEGER NOT NULL REFERENCES connectivity_isp_options(id),
    PRIMARY KEY (submission_id, isp_option_id)
);

CREATE TABLE connectivity_mobile_signals (
    submission_id INTEGER NOT NULL REFERENCES connectivity_submissions(id),
    signal_option_id INTEGER NOT NULL REFERENCES connectivity_mobile_signal_options(id),
    PRIMARY KEY (submission_id, signal_option_id)
);

CREATE TABLE connectivity_coverage_areas (
    submission_id INTEGER NOT NULL REFERENCES connectivity_submissions(id),
    area_option_id INTEGER NOT NULL REFERENCES connectivity_coverage_area_options(id),
    PRIMARY KEY (submission_id, area_option_id)
);

CREATE TABLE connectivity_electricity_sources (
    submission_id INTEGER NOT NULL REFERENCES connectivity_submissions(id),
    source_option_id INTEGER NOT NULL REFERENCES connectivity_electricity_source_options(id),
    PRIMARY KEY (submission_id, source_option_id)
);
