CREATE INDEX idx_connectivity_stage_status
ON connectivity_stage(stage_status);

CREATE INDEX idx_connectivity_stage_entity_id
ON connectivity_stage(entity_id);

CREATE INDEX idx_connectivity_stage_natural_key
ON connectivity_stage(natural_key);

CREATE INDEX idx_connectivity_submissions_entity_id
ON connectivity_submissions(entity_id);

CREATE INDEX idx_connectivity_submissions_natural_key
ON connectivity_submissions(natural_key);
