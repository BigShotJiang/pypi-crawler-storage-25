"""Extract normalized connectivity CSV rows from the source workbook."""

from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path
from typing import Iterable

from deped_dcp_template.cleaners import (
    clean_text,
    normalize_identifier,
    normalize_school_id,
)
from openpyxl import load_workbook
from openpyxl.worksheet.worksheet import Worksheet
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
)

from .constants import (
    CONNECTIVITY_BOOLEAN_FIELDS,
    CONNECTIVITY_EXTRACTED_HEADERS,
    CONNECTIVITY_WORKBOOK_HEADER_MAP,
)


def normalize_workbook_header(value: object) -> str:
    """Normalize workbook header text without treating literal labels as nulls."""
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value).replace("\ufeff", "").strip()).strip()


def flatten_grouped_headers(worksheet: Worksheet) -> list[str]:
    """Return worksheet headers flattened from the first two rows."""
    max_col = worksheet.max_column
    row1 = {
        col: normalize_workbook_header(worksheet.cell(row=1, column=col).value)
        for col in range(1, max_col + 1)
    }
    row2 = {
        col: normalize_workbook_header(worksheet.cell(row=2, column=col).value)
        for col in range(1, max_col + 1)
    }
    merged_prefixes: dict[int, str] = {}
    for merged_range in worksheet.merged_cells.ranges:
        if merged_range.min_row != 1 or merged_range.max_row != 1:
            continue
        prefix = row1.get(merged_range.min_col) or ""
        for col in range(merged_range.min_col, merged_range.max_col + 1):
            merged_prefixes[col] = prefix

    last_col = 0
    for col in range(1, max_col + 1):
        if row1.get(col) or row2.get(col) or merged_prefixes.get(col):
            last_col = col

    flattened: list[str] = []
    for col in range(1, last_col + 1):
        prefix = row1.get(col) or merged_prefixes.get(col) or ""
        leaf = row2.get(col) or ""
        if prefix and leaf and prefix != leaf:
            flattened.append(f"{prefix} | {leaf}")
        else:
            flattened.append(leaf or prefix)
    return flattened


def build_header_mapping(flattened_headers: list[str]) -> dict[int, str]:
    """Map flattened workbook headers to stable extracted column names."""
    workbook_header_map = {
        normalize_workbook_header(raw_header): stable_name
        for raw_header, stable_name in CONNECTIVITY_WORKBOOK_HEADER_MAP
    }
    mapped: dict[int, str] = {}
    unexpected: list[str] = []
    for idx, header in enumerate(flattened_headers, start=1):
        stable_name = workbook_header_map.get(normalize_workbook_header(header))
        if stable_name is None:
            unexpected.append(header)
            continue
        mapped[idx] = stable_name
    if unexpected:
        raise ValueError(f"Unexpected connectivity headers: {unexpected}")
    missing = [
        raw_header
        for raw_header, stable_name in CONNECTIVITY_WORKBOOK_HEADER_MAP
        if stable_name not in mapped.values()
    ]
    if missing:
        raise ValueError(f"Missing connectivity headers: {missing}")
    return mapped


def normalize_extracted_value(column_name: str, raw_value: object) -> str:
    """Normalize one extracted CSV value for stable downstream loading."""
    if column_name in CONNECTIVITY_BOOLEAN_FIELDS:
        return "1" if clean_text(raw_value) in {"1", "1.0", "TRUE", "YES", "Y"} else "0"
    if column_name == "school_id":
        school_id = normalize_school_id(raw_value)
        return str(school_id) if school_id is not None else ""
    if column_name == "source_record_id":
        record_id = normalize_identifier(raw_value)
        return record_id or ""
    return clean_text(raw_value) or ""


def iter_extracted_connectivity_rows(
    xlsx_path: str | Path,
    sheet_name: str = "InternetConnectivity",
    progress: Progress | None = None,
) -> Iterable[dict[str, str]]:
    """Yield normalized connectivity rows from the workbook."""
    task_id = None
    if progress is not None:
        task_id = progress.add_task(
            f"Extract connectivity: {Path(xlsx_path).name} (preparing workbook)",
            total=None,
        )
    workbook = load_workbook(xlsx_path, read_only=False, data_only=True)
    try:
        worksheet = workbook[sheet_name]
        flattened_headers = flatten_grouped_headers(worksheet)
        header_mapping = build_header_mapping(flattened_headers)
        total_rows = max(worksheet.max_row - 2, 0)
        if progress is not None and task_id is not None:
            progress.update(
                task_id,
                total=total_rows,
                completed=0,
                description=f"Extract connectivity: {Path(xlsx_path).name} (0 rows)",
            )
        for row_num in range(3, worksheet.max_row + 1):
            if progress is not None and task_id is not None:
                scanned_rows = row_num - 2
                if scanned_rows % 1000 == 0 or scanned_rows == total_rows:
                    progress.update(
                        task_id,
                        description=(
                            f"Extract connectivity: {Path(xlsx_path).name} "
                            f"({scanned_rows:,} rows)"
                        ),
                    )
                progress.update(task_id, advance=1)
            row_values = {
                col: worksheet.cell(row=row_num, column=col).value
                for col in range(1, len(flattened_headers) + 1)
            }
            if not any(clean_text(value) is not None for value in row_values.values()):
                continue
            extracted = dict.fromkeys(CONNECTIVITY_EXTRACTED_HEADERS, "")
            extracted["source_sheet"] = worksheet.title
            extracted["source_row_num"] = str(row_num)
            for col_idx, column_name in header_mapping.items():
                extracted[column_name] = normalize_extracted_value(
                    column_name, row_values.get(col_idx)
                )
            yield extracted
    finally:
        workbook.close()


def extract_connectivity_workbook(
    xlsx_path: str | Path,
    csv_path: str | Path,
    sheet_name: str = "InternetConnectivity",
) -> None:
    """Write a normalized CSV artifact from the connectivity workbook."""
    with open(csv_path, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CONNECTIVITY_EXTRACTED_HEADERS)
        writer.writeheader()
        progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            TimeElapsedColumn(),
        )
        with progress:
            for row in iter_extracted_connectivity_rows(
                xlsx_path,
                sheet_name=sheet_name,
                progress=progress,
            ):
                writer.writerow(row)


def parse_args() -> argparse.Namespace:
    """Parse CLI arguments for the connectivity extractor."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--xlsx", required=True, help="Path to the connectivity XLSX.")
    parser.add_argument(
        "--csv", required=True, help="Path to the normalized CSV output."
    )
    parser.add_argument(
        "--sheet",
        default="InternetConnectivity",
        help="Worksheet name to extract from the workbook.",
    )
    return parser.parse_args()


def main() -> None:
    """Run the connectivity extractor CLI."""
    args = parse_args()
    extract_connectivity_workbook(args.xlsx, args.csv, sheet_name=args.sheet)


if __name__ == "__main__":
    main()
