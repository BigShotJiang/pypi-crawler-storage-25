from __future__ import annotations

import sqlite3
from pathlib import Path

import click
from rich.console import Console
from rich.progress import Progress

from .connectivity import load_connectivity
from .constants import (
    CONNECTIVITY_COVERAGE_AREA_OPTIONS,
    CONNECTIVITY_ELECTRICITY_SOURCE_OPTIONS,
    CONNECTIVITY_EXTRACTED_HEADERS,
    CONNECTIVITY_ISP_OPTIONS,
    CONNECTIVITY_MOBILE_SIGNAL_OPTIONS,
)
from .entities import load_entities
from .extract_connectivity import extract_connectivity_workbook
from .schema import (
    complete_build_run,
    create_indexes,
    create_schema,
    create_views,
    seed_connectivity_option_table,
    start_build_run,
)

CONSOLE = Console(stderr=True)


def prepare_output_db(db_path: str | Path) -> None:
    base = Path(db_path)
    for suffix in ("", "-wal", "-shm"):
        candidate = Path(f"{base}{suffix}")
        if candidate.exists():
            candidate.unlink()


def build_connectivity_db(
    connectivity_path: str | Path,
    lookups_path: str | Path,
    entities_db_path: str | Path,
    db_path: str | Path,
) -> None:
    conn: sqlite3.Connection | None = None
    try:
        with CONSOLE.status("Preparing connectivity build...", spinner="dots"):
            prepare_output_db(db_path)
            conn = sqlite3.connect(db_path)
            create_schema(conn)
            build_run_id = start_build_run(
                conn, connectivity_path, lookups_path, entities_db_path
            )
            entity_lookup = load_entities(conn, entities_db_path)
            option_lookups = {
                "connectivity_isp_options": seed_connectivity_option_table(
                    conn, "connectivity_isp_options", list(CONNECTIVITY_ISP_OPTIONS)
                ),
                "connectivity_mobile_signal_options": seed_connectivity_option_table(
                    conn,
                    "connectivity_mobile_signal_options",
                    list(CONNECTIVITY_MOBILE_SIGNAL_OPTIONS),
                ),
                "connectivity_coverage_area_options": seed_connectivity_option_table(
                    conn,
                    "connectivity_coverage_area_options",
                    list(CONNECTIVITY_COVERAGE_AREA_OPTIONS),
                ),
                "connectivity_electricity_source_options": (
                    seed_connectivity_option_table(
                        conn,
                        "connectivity_electricity_source_options",
                        list(CONNECTIVITY_ELECTRICITY_SOURCE_OPTIONS),
                    )
                ),
            }
        progress = Progress(console=CONSOLE)
        with progress:
            load_connectivity(
                conn,
                connectivity_path,
                entity_lookup,
                option_lookups,
                progress,
            )
        with CONSOLE.status("Finalizing connectivity build...", spinner="dots"):
            create_indexes(conn)
            create_views(conn)
            complete_build_run(conn, build_run_id)
    finally:
        if conn is not None:
            conn.close()


@click.group()
def main() -> None:
    """Connectivity extraction and build utilities."""


@main.command("extract")
@click.option("--xlsx", required=True, type=click.Path(exists=True, dir_okay=False))
@click.option("--csv", "csv_path", required=True, type=click.Path(dir_okay=False))
def extract_command(xlsx: str, csv_path: str) -> None:
    extract_connectivity_workbook(xlsx, csv_path)
    click.echo(csv_path)


@main.command("build")
@click.option(
    "--connectivity", required=True, type=click.Path(exists=True, dir_okay=False)
)
@click.option("--lookups", required=True, type=click.Path(exists=True, dir_okay=False))
@click.option(
    "--entities-db", required=True, type=click.Path(exists=True, dir_okay=False)
)
@click.option("--db", "db_path", required=True, type=click.Path(dir_okay=False))
def build_command(
    connectivity: str, lookups: str, entities_db: str, db_path: str
) -> None:
    build_connectivity_db(connectivity, lookups, entities_db, db_path)
    click.echo(db_path)


@main.command("audit")
@click.option(
    "--db", "db_path", required=True, type=click.Path(exists=True, dir_okay=False)
)
def audit_command(db_path: str) -> None:
    with CONSOLE.status("Auditing connectivity database...", spinner="dots"):
        with sqlite3.connect(db_path) as conn:
            stage_rows = conn.execute(
                "SELECT COUNT(*) FROM connectivity_stage"
            ).fetchone()[0]
            matched_rows = conn.execute(
                "SELECT COUNT(*) FROM connectivity_submissions"
            ).fetchone()[0]
    click.echo(f"stage_rows={stage_rows}")
    click.echo(f"matched_rows={matched_rows}")


if __name__ == "__main__":
    main()
