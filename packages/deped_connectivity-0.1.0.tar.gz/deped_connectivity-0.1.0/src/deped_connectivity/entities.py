"""Entity import helpers and natural-key logic."""

from __future__ import annotations

import sqlite3
from contextlib import closing
from pathlib import Path

from deped_dcp_template.cleaners import clean_text

REQUIRED_ENTITY_COLUMNS = {
    "entity_id",
    "entity_type",
    "natural_key",
    "regional_office",
    "school_division_office",
    "school_name",
    "school_id",
    "date_time_submitted",
}


def _table_columns(conn: sqlite3.Connection, table_name: str) -> set[str]:
    rows = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
    return {str(row[1]) for row in rows}


def _require_table_columns(
    conn: sqlite3.Connection, table_name: str, required_columns: set[str]
) -> None:
    columns = _table_columns(conn, table_name)
    if not columns:
        raise ValueError(f"entities.db is missing required table: {table_name}")
    missing_columns = sorted(required_columns - columns)
    if missing_columns:
        raise ValueError(
            f"entities.db table {table_name} is missing required columns: "
            f"{', '.join(missing_columns)}"
        )


def _source_entity_name(row: sqlite3.Row) -> str:
    candidates = (
        clean_text(row["school_name"]),
        clean_text(row["school_division_office"]),
        clean_text(row["regional_office"]),
        clean_text(row["natural_key"]),
    )
    for candidate in candidates:
        if candidate is not None:
            return candidate
    raise ValueError(
        "entities.db row is missing entity naming fields for "
        f"entity_id={row['entity_id']}"
    )


def _source_region(row: sqlite3.Row) -> str:
    region = clean_text(row["regional_office"])
    if region is None:
        raise ValueError(
            "entities.db row is missing regional_office for "
            f"entity_id={row['entity_id']}"
        )
    return region


def _source_division(row: sqlite3.Row) -> str | None:
    return clean_text(row["school_division_office"])


def load_entities(
    conn: sqlite3.Connection, entities_path: str | Path
) -> dict[str, int]:
    """Import entity rows from the upstream deped-entity artifact."""
    entities_path = Path(entities_path)
    with closing(sqlite3.connect(entities_path)) as source_conn:
        source_conn.row_factory = sqlite3.Row
        _require_table_columns(source_conn, "entities", REQUIRED_ENTITY_COLUMNS)

        entity_rows = source_conn.execute(
            """--sql
            SELECT entity_id, entity_type, school_id, natural_key,
                   regional_office, school_division_office, school_name
            FROM (
                SELECT
                    entity_id,
                    entity_type,
                    school_id,
                    natural_key,
                    regional_office,
                    school_division_office,
                    school_name,
                    ROW_NUMBER() OVER (
                        PARTITION BY natural_key
                        ORDER BY
                            CASE
                                WHEN datetime(date_time_submitted) IS NULL THEN 1
                                ELSE 0
                            END,
                            datetime(date_time_submitted) DESC,
                            entity_id DESC
                    ) AS row_num
                FROM entities
            )
            WHERE row_num = 1
            ORDER BY entity_id;
            """
        ).fetchall()

    conn.executemany(
        """--sql
        INSERT INTO entities(
            entity_id, entity_type, school_id, entity_name, region,
            division, natural_key
        ) VALUES (?, ?, ?, ?, ?, ?, ?);
        """,
        [
            (
                int(row["entity_id"]),
                str(row["entity_type"]),
                int(row["school_id"]) if row["school_id"] is not None else None,
                _source_entity_name(row),
                _source_region(row),
                _source_division(row),
                str(row["natural_key"]),
            )
            for row in entity_rows
        ],
    )
    conn.commit()
    return {
        natural_key: entity_id
        for entity_id, natural_key in conn.execute(
            "SELECT entity_id, natural_key FROM entities"
        )
    }
