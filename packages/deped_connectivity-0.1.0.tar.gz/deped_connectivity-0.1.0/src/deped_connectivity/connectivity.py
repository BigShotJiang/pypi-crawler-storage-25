"""Connectivity staging and promotion."""

from __future__ import annotations

from collections import Counter
from pathlib import Path

from deped_dcp_template.cleaners import (
    clean_text,
    normalize_school_id,
    parse_float,
    to_bool_int,
)
from deped_dcp_template.constants import BATCH_SIZE
from deped_dcp_template.entities import build_natural_key, determine_entity_type
from deped_dcp_template.io import iter_csv_rows
from deped_dcp_template.personnel import flush_batch
from rich.progress import Progress

from .constants import (
    CONNECTIVITY_AVAILABLE_ISP_COLUMNS,
    CONNECTIVITY_COVERAGE_AREA_COLUMNS,
    CONNECTIVITY_ELECTRICITY_SOURCE_COLUMNS,
    CONNECTIVITY_INTEGER_FIELDS,
    CONNECTIVITY_MOBILE_SIGNAL_COLUMNS,
    CONNECTIVITY_REAL_FIELDS,
    CONNECTIVITY_SUBSCRIBED_ISP_COLUMNS,
)

STAGE_REPEATED_GROUP_FIELDS = [
    *(column_name for column_name, _ in CONNECTIVITY_AVAILABLE_ISP_COLUMNS),
    *(column_name for column_name, _ in CONNECTIVITY_SUBSCRIBED_ISP_COLUMNS),
    *(column_name for column_name, _ in CONNECTIVITY_MOBILE_SIGNAL_COLUMNS),
    *(column_name for column_name, _ in CONNECTIVITY_COVERAGE_AREA_COLUMNS),
    *(column_name for column_name, _ in CONNECTIVITY_ELECTRICITY_SOURCE_COLUMNS),
]

CONNECTIVITY_SCALAR_FIELDS = [
    "governance_level",
    "region",
    "division",
    "school_id",
    "school_name",
    "has_isp_in_area",
    "has_mobile_data_connectivity",
    "mobile_connectivity_quality",
    "subscribes_to_isp",
    "total_isps",
    "monthly_isp_cost",
    "internet_access_spend_total",
    "internet_access_projected_spend",
    "use_admin",
    "use_classroom",
    "use_both",
    "rooms_admin",
    "rooms_classroom",
    "rooms_other",
    "rooms_total",
    "access_points_total",
    "bandwidth_challenges",
    "dict_free_wifi_recipient",
    "dict_free_wifi_rating",
    "has_sufficient_bandwidth",
    "no_subscription_reason",
    "has_electricity",
    "primarily_solar_powered",
    "frequent_brownouts",
]


def parse_int_field(value: str | None) -> int | None:
    """Parse an integer-like field from extracted connectivity CSV."""
    parsed = parse_float(value)
    if parsed is None:
        return None
    return int(round(parsed))


def parse_real_field(value: str | None) -> float | None:
    """Parse a real-valued field from extracted connectivity CSV."""
    return parse_float(value)


def derive_stage_resolution(
    row: dict[str, str], entity_lookup: dict[str, int]
) -> tuple[str | None, int | None, str, str | None]:
    """Resolve row identity against the existing entity dimension."""
    try:
        entity_type = determine_entity_type(row.get("governance_level"))
        school_id = normalize_school_id(row.get("school_id"))
        region = clean_text(row.get("region"))
        division = clean_text(row.get("division"))
        natural_key = build_natural_key(entity_type, school_id, region, division)
    except Exception as exc:
        return None, None, "invalid", str(exc)
    entity_id = entity_lookup.get(natural_key)
    if entity_id is None:
        return natural_key, None, "unmatched", None
    return natural_key, entity_id, "matched", None


def build_stage_row(
    row: dict[str, str],
    *,
    source_file: str,
    entity_lookup: dict[str, int],
) -> tuple[object, ...]:
    """Build one staged connectivity row tuple."""
    natural_key, entity_id, stage_status, error_reason = derive_stage_resolution(
        row, entity_lookup
    )
    values: dict[str, object] = {
        "natural_key": natural_key,
        "entity_id": entity_id,
        "stage_status": stage_status,
        "error_reason": error_reason,
        "source_file": source_file,
        "source_sheet": clean_text(row.get("source_sheet")),
        "source_row_num": parse_int_field(row.get("source_row_num")),
        "source_record_id": normalize_school_id(row.get("source_record_id")),
        "governance_level": clean_text(row.get("governance_level")),
        "region": clean_text(row.get("region")),
        "division": clean_text(row.get("division")),
        "school_id": normalize_school_id(row.get("school_id")),
        "school_name": clean_text(row.get("school_name")),
        "bandwidth_challenges": clean_text(row.get("bandwidth_challenges")),
        "no_subscription_reason": clean_text(row.get("no_subscription_reason")),
    }
    for field_name in (
        "has_isp_in_area",
        "has_mobile_data_connectivity",
        "subscribes_to_isp",
        "use_admin",
        "use_classroom",
        "use_both",
        "dict_free_wifi_recipient",
        "has_sufficient_bandwidth",
        "has_electricity",
        "primarily_solar_powered",
        "frequent_brownouts",
        *STAGE_REPEATED_GROUP_FIELDS,
    ):
        values[field_name] = to_bool_int(row.get(field_name))
    for field_name in CONNECTIVITY_INTEGER_FIELDS:
        values[field_name] = parse_int_field(row.get(field_name))
    for field_name in CONNECTIVITY_REAL_FIELDS:
        values[field_name] = parse_real_field(row.get(field_name))
    return tuple(values[column_name] for column_name in stage_columns())


def stage_columns() -> list[str]:
    """Return staged connectivity insert columns in a stable order."""
    return [
        "natural_key",
        "entity_id",
        "stage_status",
        "error_reason",
        "source_file",
        "source_sheet",
        "source_row_num",
        "source_record_id",
        *CONNECTIVITY_SCALAR_FIELDS,
        *STAGE_REPEATED_GROUP_FIELDS,
    ]


def collect_child_rows(
    submission_id: int,
    flags: dict[str, int],
    option_columns: list[tuple[str, str]],
    option_lookup: dict[str, int],
) -> list[tuple[int, int]]:
    """Collect selected option rows for one child table."""
    rows: list[tuple[int, int]] = []
    for column_name, option_code in option_columns:
        if flags.get(column_name):
            rows.append((submission_id, option_lookup[option_code]))
    return rows


def promote_connectivity_submissions(
    conn,
    option_lookups: dict[str, dict[str, int]],
) -> None:
    """Promote matched staged rows into final submissions and child tables."""
    conn.execute(
        f"""
        INSERT INTO connectivity_submissions(
            source_stage_id, entity_id, natural_key, source_file, source_sheet,
            source_row_num, source_record_id, {", ".join(CONNECTIVITY_SCALAR_FIELDS)}
        )
        SELECT
            id, entity_id, natural_key, source_file, source_sheet,
            source_row_num, source_record_id, {", ".join(CONNECTIVITY_SCALAR_FIELDS)}
        FROM connectivity_stage
        WHERE stage_status = 'matched'
        """
    )

    submission_lookup = {
        source_stage_id: submission_id
        for submission_id, source_stage_id in conn.execute(
            "SELECT id, source_stage_id FROM connectivity_submissions"
        )
    }

    select_columns = ["id", *STAGE_REPEATED_GROUP_FIELDS]
    child_rows: dict[str, list[tuple[int, int]]] = {
        "connectivity_available_isps": [],
        "connectivity_subscribed_isps": [],
        "connectivity_mobile_signals": [],
        "connectivity_coverage_areas": [],
        "connectivity_electricity_sources": [],
    }

    for stage_row in conn.execute(
        f"""
        SELECT {", ".join(select_columns)}
        FROM connectivity_stage
        WHERE stage_status = 'matched'
        ORDER BY id
        """
    ):
        stage_id = stage_row[0]
        submission_id = submission_lookup[stage_id]
        flags = dict(zip(select_columns[1:], stage_row[1:], strict=True))
        child_rows["connectivity_available_isps"].extend(
            collect_child_rows(
                submission_id,
                flags,
                CONNECTIVITY_AVAILABLE_ISP_COLUMNS,
                option_lookups["connectivity_isp_options"],
            )
        )
        child_rows["connectivity_subscribed_isps"].extend(
            collect_child_rows(
                submission_id,
                flags,
                CONNECTIVITY_SUBSCRIBED_ISP_COLUMNS,
                option_lookups["connectivity_isp_options"],
            )
        )
        child_rows["connectivity_mobile_signals"].extend(
            collect_child_rows(
                submission_id,
                flags,
                CONNECTIVITY_MOBILE_SIGNAL_COLUMNS,
                option_lookups["connectivity_mobile_signal_options"],
            )
        )
        child_rows["connectivity_coverage_areas"].extend(
            collect_child_rows(
                submission_id,
                flags,
                CONNECTIVITY_COVERAGE_AREA_COLUMNS,
                option_lookups["connectivity_coverage_area_options"],
            )
        )
        child_rows["connectivity_electricity_sources"].extend(
            collect_child_rows(
                submission_id,
                flags,
                CONNECTIVITY_ELECTRICITY_SOURCE_COLUMNS,
                option_lookups["connectivity_electricity_source_options"],
            )
        )

    conn.executemany(
        """
        INSERT INTO connectivity_available_isps(submission_id, isp_option_id)
        VALUES (?, ?)
        """,
        child_rows["connectivity_available_isps"],
    )
    conn.executemany(
        """
        INSERT INTO connectivity_subscribed_isps(submission_id, isp_option_id)
        VALUES (?, ?)
        """,
        child_rows["connectivity_subscribed_isps"],
    )
    conn.executemany(
        """
        INSERT INTO connectivity_mobile_signals(submission_id, signal_option_id)
        VALUES (?, ?)
        """,
        child_rows["connectivity_mobile_signals"],
    )
    conn.executemany(
        """
        INSERT INTO connectivity_coverage_areas(submission_id, area_option_id)
        VALUES (?, ?)
        """,
        child_rows["connectivity_coverage_areas"],
    )
    conn.executemany(
        """
        INSERT INTO connectivity_electricity_sources(submission_id, source_option_id)
        VALUES (?, ?)
        """,
        child_rows["connectivity_electricity_sources"],
    )


def load_connectivity(
    conn,
    path: str | Path,
    entity_lookup: dict[str, int],
    option_lookups: dict[str, dict[str, int]],
    progress: Progress | None = None,
) -> Counter[str]:
    """Load extracted connectivity CSV rows into stage and matched tables."""
    stage_rows: list[tuple[object, ...]] = []
    stage_status_counts: Counter[str] = Counter()
    source_file = Path(path).name
    task_id = None

    if progress is not None:
        task_id = progress.add_task(
            f"Load connectivity: {Path(path).name} (0 rows)",
            total=Path(path).stat().st_size,
        )

    for _, row in iter_csv_rows(path, progress, task_id):
        stage_row = build_stage_row(
            row, source_file=source_file, entity_lookup=entity_lookup
        )
        status = stage_row[stage_columns().index("stage_status")]
        stage_status_counts[str(status)] += 1
        stage_rows.append(stage_row)
        if len(stage_rows) >= BATCH_SIZE:
            flush_batch(conn, "connectivity_stage", stage_columns(), stage_rows)
            conn.commit()
            stage_rows.clear()

    if stage_rows:
        flush_batch(conn, "connectivity_stage", stage_columns(), stage_rows)
        conn.commit()

    promote_connectivity_submissions(conn, option_lookups)
    conn.commit()
    return stage_status_counts
