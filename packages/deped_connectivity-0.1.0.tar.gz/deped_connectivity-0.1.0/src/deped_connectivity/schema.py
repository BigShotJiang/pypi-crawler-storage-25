from __future__ import annotations

import csv
import sqlite3
from hashlib import sha256
from importlib.resources import files
from pathlib import Path

from deped_dcp_template.constants import SCHEMA_VERSION

_SQL = files("deped_connectivity.sql")


def _read_sql(name: str) -> str:
    return _SQL.joinpath(name).read_text()


def create_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(_read_sql("pragmas.sql"))
    for filename in (
        "tables/entities.sql",
        "tables/connectivity.sql",
        "tables/build_runs.sql",
    ):
        conn.executescript(_read_sql(filename))


def create_indexes(conn: sqlite3.Connection) -> None:
    conn.executescript(_read_sql("indexes/entities.sql"))
    conn.executescript(_read_sql("indexes/connectivity.sql"))


def create_views(conn: sqlite3.Connection) -> None:
    for filename in (
        "views/v_connectivity_enriched.sql",
        "views/v_connectivity_stage_unmatched.sql",
    ):
        conn.executescript(_read_sql(filename))


def seed_connectivity_option_table(
    conn: sqlite3.Connection,
    table_name: str,
    options: list[tuple[str, str]],
) -> dict[str, int]:
    conn.executemany(
        f"INSERT INTO {table_name}(code, display_name) VALUES (?, ?)",
        options,
    )
    return {
        code: row_id
        for row_id, code in conn.execute(f"SELECT id, code FROM {table_name}")
    }


def start_build_run(
    conn: sqlite3.Connection,
    connectivity_path: str | Path,
    lookups_path: str | Path,
    entities_db_path: str | Path,
) -> int:
    connectivity_path = Path(connectivity_path)
    lookups_path = Path(lookups_path)
    entities_db_path = Path(entities_db_path)
    connectivity_hash = sha256(connectivity_path.read_bytes()).hexdigest()
    lookups_hash = sha256(lookups_path.read_bytes()).hexdigest()
    entities_hash = sha256(entities_db_path.read_bytes()).hexdigest()
    with open(connectivity_path, "r", encoding="utf-8-sig", newline="") as handle:
        connectivity_rows = sum(1 for _ in csv.DictReader(handle))
    cursor = conn.execute(
        """--sql
        INSERT INTO build_runs(
            build_type, started_at, schema_version,
            lookups_source_file, lookups_source_hash,
            entities_source_file, entities_source_hash,
            connectivity_source_file, connectivity_source_hash, connectivity_source_rows
        ) VALUES (?, datetime('now'), ?, ?, ?, ?, ?, ?, ?, ?);
        """,
        (
            "full_rebuild",
            SCHEMA_VERSION,
            lookups_path.name,
            lookups_hash,
            entities_db_path.name,
            entities_hash,
            connectivity_path.name,
            connectivity_hash,
            connectivity_rows,
        ),
    )
    conn.commit()
    if (v := cursor.lastrowid) is None:
        raise RuntimeError("Failed to create build run record")
    return int(v)


def complete_build_run(conn: sqlite3.Connection, build_run_id: int) -> None:
    conn.execute(
        """--sql
        UPDATE build_runs
        SET completed_at = datetime('now'),
            entity_count = (SELECT COUNT(*) FROM entities),
            connectivity_stage_count = (SELECT COUNT(*) FROM connectivity_stage),
            connectivity_submission_count = (
                SELECT COUNT(*) FROM connectivity_submissions
            )
        WHERE id = ?;
        """,
        (build_run_id,),
    )
    conn.commit()
