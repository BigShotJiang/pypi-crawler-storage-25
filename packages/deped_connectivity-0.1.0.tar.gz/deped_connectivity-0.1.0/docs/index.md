# DepEd Connectivity

`deped-connectivity` extracts workbook rows and builds a standalone connectivity SQLite database. It consumes lookup data from `deped-dcp-template` and the entity artifact from `deped-entity`.

## What This Package Owns

- Extracting flattened CSV rows from the connectivity workbook
- Building the connectivity database from extracted rows
- Matching rows to governance entities using the upstream entity artifact
- Connectivity-specific views and audit commands

This package is the source of truth for both the extractor contract and the `connectivity.db` artifact.

## Inputs

- A connectivity workbook under `data/` for extraction
- An extracted connectivity CSV for the build step
- A lookup database produced by `deped-dcp-template`
- An entity database produced by `deped-entity`

## Outputs

- `artifacts/connectivity.csv`
- `artifacts/connectivity.db`

## Main Commands

Build the lookup database:

```sh
uv run deped-dcp-template extract \
  --templates-dir templates \
  --output artifacts/lookups.db
```

Extract workbook rows:

```sh
uv run web extract \
  --xlsx data/2026-04-01-connectivity.xlsx \
  --csv artifacts/connectivity.csv
```

Build the connectivity database:

```sh
uv run deped-connectivity build \
  --connectivity artifacts/connectivity.csv \
  --lookups artifacts/lookups.db \
  --entities-db artifacts/entities.db \
  --db artifacts/connectivity.db
```

Audit a built database:

```sh
uv run deped-connectivity audit \
  --db artifacts/connectivity.db
```

## Behavioral Notes

- Extraction and build are intentionally separate. Workbook layout fixes belong in the extractor layer.
- Entity loading is artifact-driven and scoped to the connectivity domain.
- Unmatched stage rows remain queryable through connectivity-owned diagnostics instead of being silently dropped.
- Other systems should consume `connectivity.db` as an artifact instead of importing internal modules.
