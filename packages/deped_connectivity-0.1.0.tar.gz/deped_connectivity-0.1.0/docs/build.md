# Build Guide

This page covers the expected workflow for producing the connectivity artifacts.

## Prerequisites

- Python 3.14+
- `uv`
- A valid connectivity workbook
- A lookup database produced by `deped-dcp-template`
- An entity database produced by `deped-entity`

## 1. Build The Lookup Database

The connectivity build expects a lookup database with governance metadata.

```sh
uv run deped-dcp-template extract \
  --templates-dir templates \
  --output artifacts/lookups.db
```

## 2. Extract The Workbook

Flatten the workbook into CSV from the repository root:

```sh
uv run deped-connectivity extract \
  --xlsx data/2026-04-01-connectivity.xlsx \
  --csv artifacts/connectivity.csv
```

## 3. Build The Connectivity Database

```sh
uv run deped-connectivity build \
  --connectivity artifacts/connectivity.csv \
  --lookups artifacts/lookups.db \
  --entities-db artifacts/entities.db \
  --db artifacts/connectivity.db
```

Arguments:

- `--connectivity`: extracted CSV file
- `--lookups`: lookup SQLite database
- `--entities-db`: upstream entity SQLite database
- `--db`: destination SQLite database

The command prints the output database path on success.

## 4. Audit The Result

Run the lightweight audit command after a build:

```sh
uv run deped-connectivity audit \
  --db artifacts/connectivity.db
```

Current audit output includes:

- `stage_rows`
- `matched_rows`

## Generated Files

The workflow produces:

- `artifacts/connectivity.csv`
- `artifacts/connectivity.db`
