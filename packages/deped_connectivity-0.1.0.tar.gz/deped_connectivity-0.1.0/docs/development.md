# Development

## Local Setup

Install project dependencies with `uv` and work from the repository root.

The package code lives under `src/deped_connectivity`.

## Tests

Run the test suite:

```sh
uv run pytest -q
```

Current test coverage is focused on:

- workbook extraction behavior in `tests/test_connectivity_extractor.py`
- database build behavior in `tests/test_connectivity_build.py`

## Documentation

This repository uses Zensical for documentation. The site configuration lives in `zensical.toml`, and Markdown sources live in `docs/`.

Build the documentation site locally with:

```sh
uv run zensical build
```

## Publishing

The `justfile` includes a `publish` target that builds and publishes the Python package:

```sh
just publish
```

This expects the appropriate PyPI token to be available in the environment.
