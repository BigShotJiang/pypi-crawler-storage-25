# Data Contract

The `deped_connectivity` package owns the structure and semantics of the connectivity artifacts.

## Core Tables

The SQLite schema includes these primary tables:

- `entities`
- `connectivity_stage`
- `connectivity_submissions`
- `isp_options`
- `technology_options`
- `build_runs`

## Views

The build creates connectivity-owned analytical views and diagnostics over the staged and matched data. These views are part of the artifact contract exposed to downstream consumers.

## Build Metadata

`build_runs` records provenance for each build, including the lookup artifact, upstream entity artifact, source file names, hashes, row counts, and completion timestamps.

## Matching Semantics

Governance matching reads from the supplied upstream entity artifact. During the build:

- stage rows are normalized and matched to entities
- matched rows become connectivity submissions
- unmatched rows remain visible for diagnostics and remediation

## Extractor Contract

The CSV extraction step is part of the supported contract. If workbook headers or sheet layout change, fixes belong in the extractor rather than in downstream consumers.
