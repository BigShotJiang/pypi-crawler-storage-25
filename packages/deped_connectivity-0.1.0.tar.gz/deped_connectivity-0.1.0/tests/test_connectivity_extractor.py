import csv
from pathlib import Path

from openpyxl import Workbook

from deped_connectivity.constants import CONNECTIVITY_EXTRACTED_HEADERS
from deped_connectivity.extract_connectivity import (
    build_header_mapping,
    extract_connectivity_workbook,
    flatten_grouped_headers,
)

LEAF_HEADERS = [
    "ID",
    "Governance Level",
    "Region",
    "Division",
    "School ID",
    "School Name",
    "Are there any internet service provider/s available in the area?",
    "GLOBE",
    "SMART",
    "PLDT",
    "SKYCABLE",
    "CONVERGE",
    "STARLINK",
    "Eastern Communications",
    "DITO Telecommunity",
    "Other ISP",
    "3G",
    "LTE (4G LTE)",
    "LTE-Advanced/True 4G",
    "5G",
    "No Signal",
    "Area has mobile data connectivity",
    "Quality of mobile data connectivity in the area",
    "Do you subscribe to any Internet Service Provider/s",
    "GLOBE (ISP)",
    "SMART (ISP)",
    "PLDT (ISP)",
    "SKYCABLE (ISP)",
    "CONVERGE (ISP)",
    "STARLINK (ISP)",
    "Eastern Communications (ISP)",
    "DITO Telecommunity (ISP)",
    "DICT",
    "Total ISPs",
    "Total cost of Internet Service Provider/s per month",
    "Total amount spent for internet access",
    "Total projected expenditure for internet access",
    "For Administrative Use",
    "For Classroom Instruction Use",
    "For Both Administrative And Classroom Instruction Use",
    "How many rooms are utilizing the internet service for administrative use?",
    "How many rooms are utilizing the internet service for classroom instruction use?",
    "How many rooms are utilizing the internet service for other use?",
    "Total Number Of Rooms Utilizing The Internet Service",
    "Total Number Of Access Points",
    "Is the available bandwidth insufficient to support the operation? Please specify the reasons or challenges?",
    "Building Office Wide",
    "School Wide",
    "Faculty Area",
    "Principal Office",
    "Elementary School",
    "Junior High School Jhs Area",
    "Senior High School Shs Area",
    "Ict Room Laboratory",
    "Library",
    "Other Area",
    "Recipient of the DICT free Wi-Fi Program?",
    "Rate DICT Free Wi-Fi",
    "Has Sufficient Bandwidth For Internet Needs",
    "If No Subscription: What prevents you from subscribing to internet services?",
    "Does the area have a source of electricity?",
    "Grid",
    "Generator",
    "Solar",
    "None",
    "School is Primarily/Exclusively Powered by Solar Energy",
    "Frequent Brownouts in School?",
]


def make_connectivity_workbook(path: Path) -> None:
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "InternetConnectivity"

    worksheet["H1"] = "What internet service provider/s are available in the area?"
    worksheet["Q1"] = "What types of mobile network signals are available in the area?"
    worksheet["Y1"] = "Please specify your Internet Service Provider/s"
    worksheet["AU1"] = "What is the coverage area?"
    worksheet["BJ1"] = "Source of Electricity"
    worksheet.merge_cells("H1:P1")
    worksheet.merge_cells("Q1:U1")
    worksheet.merge_cells("Y1:AG1")
    worksheet.merge_cells("AU1:BD1")
    worksheet.merge_cells("BJ1:BM1")

    for col_idx, header in enumerate(LEAF_HEADERS, start=1):
        worksheet.cell(row=2, column=col_idx, value=header)

    row3 = {
        1: "62460",
        2: "SCHOOL",
        3: "Region III",
        4: "Tarlac",
        5: "106645",
        6: "San Pedro ES",
        7: "1",
        8: "1",
        10: "1",
        17: "1",
        20: "1",
        22: "1",
        23: "3",
        24: "1",
        25: "1",
        33: "1",
        34: "2",
        35: "1998",
        36: "2500",
        37: "3000",
        38: "1",
        40: "1",
        41: "2",
        42: "7",
        43: "1",
        44: "10",
        45: "3",
        46: "Bandwidth is limited",
        48: "1",
        54: "1",
        57: "1",
        58: "4",
        59: "1",
        60: "Budget",
        61: "1",
        62: "1",
        64: "1",
        66: "1",
        67: "1",
    }
    for col_idx, value in row3.items():
        worksheet.cell(row=3, column=col_idx, value=value)

    row5 = {
        1: "70000",
        2: "DIVISION_OFFICE",
        3: "NCR",
        4: "Quezon City",
        6: "Ignored Name",
        21: "1",
        23: "0",
        61: "1",
        62: "1",
    }
    for col_idx, value in row5.items():
        worksheet.cell(row=5, column=col_idx, value=value)

    workbook.save(path)


def test_extract_connectivity_workbook_flattens_headers_and_skips_blank_rows(
    tmp_path: Path,
) -> None:
    workbook_path = tmp_path / "connectivity.xlsx"
    csv_path = tmp_path / "connectivity.csv"
    make_connectivity_workbook(workbook_path)

    from openpyxl import load_workbook

    loaded = load_workbook(workbook_path)
    try:
        worksheet = loaded["InternetConnectivity"]
        flattened = flatten_grouped_headers(worksheet)
        header_mapping = build_header_mapping(flattened)
    finally:
        loaded.close()

    assert (
        flattened[7]
        == "What internet service provider/s are available in the area? | GLOBE"
    )
    assert header_mapping[8] == "available_isp_globe"
    assert header_mapping[61] == "has_electricity"

    extract_connectivity_workbook(workbook_path, csv_path)

    with open(csv_path, "r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)

    assert reader.fieldnames == CONNECTIVITY_EXTRACTED_HEADERS
    assert len(rows) == 2
    assert rows[0]["source_row_num"] == "3"
    assert rows[0]["available_isp_globe"] == "1"
    assert rows[0]["subscribed_isp_dict"] == "1"
    assert rows[1]["governance_level"] == "DIVISION_OFFICE"
