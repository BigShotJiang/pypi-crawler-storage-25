import csv
import sqlite3
from pathlib import Path

from deped_connectivity.cli import build_connectivity_db
from deped_connectivity.constants import CONNECTIVITY_EXTRACTED_HEADERS


def write_csv(path: Path, headers: list[str], rows: list[list[str]]) -> None:
    with open(path, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(headers)
        writer.writerows(rows)


def row_from_mapping(headers: list[str], values: dict[str, str]) -> list[str]:
    return [values.get(header, "") for header in headers]


def make_lookup_db(path: Path) -> None:
    conn = sqlite3.connect(path)
    try:
        conn.executescript(
            """
            CREATE TABLE regions(id INTEGER PRIMARY KEY, name TEXT NOT NULL);
            CREATE TABLE divisions(
                id INTEGER PRIMARY KEY,
                region_id INTEGER NOT NULL,
                name TEXT NOT NULL
            );
            """
        )
        conn.executemany(
            "INSERT INTO regions(id, name) VALUES (?, ?)",
            [(1, "Region I"), (2, "NCR")],
        )
        conn.executemany(
            "INSERT INTO divisions(region_id, name) VALUES (?, ?)",
            [(1, "Alaminos City"), (2, "Quezon City")],
        )
        conn.commit()
    finally:
        conn.close()


def make_entities_db(path: Path) -> None:
    conn = sqlite3.connect(path)
    try:
        conn.executescript(
            """
            CREATE TABLE entities(
                entity_id INTEGER PRIMARY KEY,
                entity_type TEXT NOT NULL,
                natural_key TEXT NOT NULL,
                regional_office TEXT,
                school_division_office TEXT,
                school_name TEXT,
                school_id INTEGER,
                date_time_submitted TEXT
            );
            """
        )
        conn.executemany(
            """
            INSERT INTO entities(
                entity_id, entity_type, natural_key, regional_office,
                school_division_office, school_name, school_id, date_time_submitted
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [
                (
                    10,
                    "DIVISION_OFFICE",
                    "DIVISION_OFFICE:Region I:Alaminos City",
                    "Region I",
                    "Alaminos City",
                    None,
                    None,
                    "2026-04-01 09:00:00",
                ),
                (
                    11,
                    "REGIONAL_OFFICE",
                    "REGIONAL_OFFICE:Region I",
                    "Region I",
                    None,
                    None,
                    None,
                    "2026-04-01 09:00:00",
                ),
            ],
        )
        conn.commit()
    finally:
        conn.close()


def test_build_connectivity_db_matches_only_lookup_supported_governance_rows(
    tmp_path: Path,
) -> None:
    lookups_db = tmp_path / "lookups.db"
    entities_db = tmp_path / "entities.db"
    connectivity_csv = tmp_path / "connectivity.csv"
    connectivity_db = tmp_path / "connectivity.db"
    make_lookup_db(lookups_db)
    make_entities_db(entities_db)

    write_csv(
        connectivity_csv,
        CONNECTIVITY_EXTRACTED_HEADERS,
        [
            row_from_mapping(
                CONNECTIVITY_EXTRACTED_HEADERS,
                {
                    "source_sheet": "InternetConnectivity",
                    "source_row_num": "3",
                    "source_record_id": "62460",
                    "governance_level": "DIVISION_OFFICE",
                    "region": "Region I",
                    "division": "Alaminos City",
                    "has_isp_in_area": "1",
                    "available_isp_globe": "1",
                    "has_electricity": "1",
                    "electricity_source_grid": "1",
                },
            ),
            row_from_mapping(
                CONNECTIVITY_EXTRACTED_HEADERS,
                {
                    "source_sheet": "InternetConnectivity",
                    "source_row_num": "5",
                    "source_record_id": "70000",
                    "governance_level": "DIVISION_OFFICE",
                    "region": "Region I",
                    "division": "Missing Division",
                    "has_electricity": "1",
                    "electricity_source_grid": "1",
                },
            ),
        ],
    )

    build_connectivity_db(connectivity_csv, lookups_db, entities_db, connectivity_db)

    with sqlite3.connect(connectivity_db) as conn:
        assert (
            conn.execute("SELECT COUNT(*) FROM connectivity_stage").fetchone()[0] == 2
        )
        assert (
            conn.execute("SELECT COUNT(*) FROM connectivity_submissions").fetchone()[0]
            == 1
        )
        assert (
            conn.execute(
                "SELECT COUNT(*) FROM v_connectivity_stage_unmatched"
            ).fetchone()[0]
            == 1
        )
        assert (
            conn.execute("SELECT entity_name FROM v_connectivity_enriched").fetchone()[
                0
            ]
            == "Alaminos City"
        )
        build_run = conn.execute(
            """
            SELECT build_type, lookups_source_file, entities_source_file, connectivity_source_file,
                   connectivity_source_rows, entity_count,
                   connectivity_stage_count, connectivity_submission_count,
                   completed_at IS NOT NULL
            FROM build_runs
            """
        ).fetchone()
        assert build_run == (
            "full_rebuild",
            "lookups.db",
            "entities.db",
            "connectivity.csv",
            2,
            2,
            2,
            1,
            1,
        )
