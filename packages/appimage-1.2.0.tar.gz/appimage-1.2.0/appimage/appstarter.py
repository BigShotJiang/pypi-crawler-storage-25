"""Module for initializing applications within an AppImage via AppRun.

This module is designed to be invoked by the AppRun script of an AppImage and is not intended
for direct execution. The module includes the AppStarter class, which orchestrates the application
startup process based on command line arguments, controlling environment variables, interpreter
access, entry point restrictions, and default commands.

The provided AppRun bash script sets up the necessary environment and invokes the application
using this module. It should be located at the root of the AppImage filesystem.

Command Line Usage:
-------------------

    ./<appimage> --python-help
    ./<appimage> --python-appimage-debug
    ./<appimage> --python-list-entry-points
    ./<appimage> --python-interpreter
    ./<appimage> --python-interpreter -m venv <VENV_DIR>
    ./<appimage> --python-entry-point <PYTHON_ENTRY_POINT>

Arguments:
---------
- **default_entry_point**: The entry point to start the application.
- **--python-help**: Show help message and exit.
- **--python-appimage-debug**: Print debug information to stderr during startup.
- **--python-list-entry-points**: List all available console script entry points and exit.
- **--python-interpreter**: Start the Python interpreter.
- **--python-interpreter -m venv <VENV_DIR>**: Create a virtual environment in the specified
  directory that points to the Python installation within the AppImage. Supported options:
  ``--clear``, ``--upgrade``, ``--prompt``.
  On Python ≥ 3.13 also: ``--without-scm-ignore-files``.
  Note: ``--system-site-packages``, ``--copies``, ``--upgrade-deps``, ``--without-pip``, and
  ``--symlinks`` are not supported in the AppImage context.
- **--python-entry-point <PYTHON_ENTRY_POINT>**: Execute a specified Python entry point from the
  console scripts (e.g., "ssh-mitm" or "ssmitm.cli:main"). This allows you to run specific
  commands or scripts packaged within the AppImage.

Intended Usage:
---------------

This module is used within an AppImage environment, with the AppRun entry point calling the
`start_entry_point` function provided by this module. AppStarter reads the command line arguments,
determines the appropriate entry point, and initiates the application.

Example AppRun Script:
----------------------

The AppRun script is a bash script located at the root of the AppImage filesystem. It sets up
the necessary environment and calls the `appimage` module to start the application. Below is
an example AppRun script:

    #!/bin/bash

    set -e

    if [ -z $APPDIR ]; then
        export APPDIR=$(dirname $(readlink -f "$0"))
    fi

    exec "$APPDIR/python/bin/python3" -P -m appimage --python-main ssh-mitm "$@"

This script ensures that the APPDIR environment variable is set and then executes the Python
interpreter within the AppImage, invoking the `appimage` module to start the application.

"""

import argparse
import os
import shutil
import site
import sys
import sysconfig
from functools import cached_property
from importlib.metadata import EntryPoint, entry_points
from pathlib import Path
from typing import TYPE_CHECKING
from venv import EnvBuilder

if TYPE_CHECKING:
    from types import SimpleNamespace


def get_entry_points(group: str) -> list[EntryPoint]:
    """Retrieve a list of entry points for a specified group.

    This function fetches entry points from the current Python environment. It is compatible
    with different Python versions, handling the retrieval process accordingly.

    Attributes
    ----------
        group (str): The entry point group to filter and retrieve.

    Returns
    -------
        List[EntryPoint]: A list of entry points belonging to the specified group.

    """
    eps = entry_points()
    return list(eps.select(group=group))


def patch_appimage_venv(context: "SimpleNamespace") -> None:
    """Patches the virtual environment within an AppImage.

    This function modifies the virtual environment by replacing the Python symlink
    with the AppImage path. It also creates symlinks for console script entry points
    within the virtual environment's bin directory.

    Attributes
    ----------
        context (SimpleNamespace): A namespace object containing the bin_path attribute
                                   which specifies the path to the virtual environment's
                                   bin directory.

    """
    symlink_target = "python3"
    appimage_path = os.environ.get("APPIMAGE", None)
    if not appimage_path:
        # AppImage extracted, so we need to create a fake APPIMAGE variable
        appidir = os.environ.get("APPDIR", None)
        if not appidir:
            # AppImage not properly configured, because APPDIR variable is missing - abort
            sys.exit("APPDIR environment variable missing!")
        appimage_path = str(Path(appidir) / "AppRun")

    # replace symlink to appimage instead of python executable
    venv_python_path = Path(context.bin_path) / symlink_target
    venv_python_path.unlink()
    venv_python_path.symlink_to(appimage_path)

    scripts = get_entry_points(group="console_scripts")
    for ep in scripts:
        ep_path = Path(context.bin_path) / ep.name
        if ep_path.is_file():
            continue
        ep_path.symlink_to(symlink_target)


class _AppImageEnvBuilder(EnvBuilder):
    def setup_python(self, context: "SimpleNamespace") -> None:
        super().setup_python(context)
        patch_appimage_venv(context)


def _make_venv_parser() -> argparse.ArgumentParser:
    """Return a parser for venv creation inside an AppImage.

    Only options that are compatible with the AppImage environment are exposed:

    - ``--clear`` / ``--upgrade``: standard lifecycle operations, work as expected.
    - ``--prompt``: cosmetic shell-prompt label.
    - ``--without-scm-ignore-files``: exposed only on Python ≥ 3.13 where EnvBuilder supports it.

    Intentionally excluded options:
    - ``--system-site-packages``: has no effect in AppImage venvs. Python detects a venv by
      looking for ``pyvenv.cfg`` one level above ``sys.executable``. Because ``sys.executable``
      is the AppImage's own Python binary (``APPDIR/python/bin/python3``), Python never finds
      the venv's ``pyvenv.cfg`` and therefore never reads ``include-system-site-packages``.
      The AppImage's bundled packages are always accessible via Python's compiled-in
      ``sys.prefix`` (``APPDIR/python/``), regardless of this flag.
    - ``--copies``: AppImage venvs require symlinks; ``_AppImageEnvBuilder`` always uses
      ``symlinks=True`` and ``patch_appimage_venv`` replaces the python3 entry with a symlink
      to the AppImage regardless.
    - ``--upgrade-deps``: downloads pip from PyPI, which conflicts with the AppImage's bundled pip.
    - ``--without-pip``: pip is accessible via the AppImage symlink in the venv's bin; skipping
      ensurepip would leave the venv in an inconsistent state for tools that inspect site-packages.
    - ``--symlinks``: always enabled; no need to expose.
    """
    parser = argparse.ArgumentParser(
        description="Creates virtual Python environments in one or more target directories.",
        epilog="Once an environment has been created, you may wish to activate it, e.g. by "
        "sourcing an activate script in its bin directory.",
    )
    parser.add_argument(
        "dirs",
        metavar="ENV_DIR",
        nargs="+",
        help="A directory to create the environment in.",
    )
    parser.add_argument(
        "--clear",
        default=False,
        action="store_true",
        dest="clear",
        help="Delete the contents of the environment directory if it already exists.",
    )
    parser.add_argument(
        "--upgrade",
        default=False,
        action="store_true",
        dest="upgrade",
        help="Upgrade the environment directory to use this version of Python, "
        "assuming the AppImage has been updated in-place.",
    )
    parser.add_argument(
        "--prompt",
        default=None,
        dest="prompt",
        help="Provides an alternative prompt prefix for this environment.",
    )
    if sys.version_info >= (3, 13):
        parser.add_argument(
            "--without-scm-ignore-files",
            default=False,
            action="store_true",
            dest="without_scm_ignore_files",
            help="Skips adding SCM ignore files to the environment directory.",
        )
    return parser


class AppStartExceptionError(Exception):
    """Base exception class for errors during the app start process."""


class InvalidEntryPointError(AppStartExceptionError):
    """Exception raised for invalid entry point."""


class AppStarter:
    """Class responsible for managing the application start process.

    This class handles reading command-line arguments, determining the correct entry point,
    and executing the application. It ensures that the application is initialized
    properly based on the provided command-line arguments and entry points.
    """

    def __init__(self) -> None:
        """Initialize the AppStarter instance.

        Initializes attributes based on the current environment variables.

        Attributes
        ----------
            default_ep (Optional[str]): The default entry point, initially set to None.
            subprocess_args (Optional[List[str]]): Arguments for subprocesses, initially set to None.
            appimage (Optional[str]): The absolute path to the AppImage, if the APPIMAGE environment
                                    variable is set.
            argv0 (Optional[str]): The base name of the initial command used to invoke the script,
                                if the ARGV0 environment variable is set.
            env_ep (Optional[str]): The entry point specified in the environment variable APP_ENTRY_POINT.
            virtual_env (Optional[str]): The path to the virtual environment, if the VIRTUAL_ENV
                                        environment variable is set.

        """
        self.default_ep: str | None = None
        self.subprocess_args: list[str] | None = None
        appimage_env = os.environ.get("APPIMAGE", None)
        self.appimage = str(Path(appimage_env).resolve()) if appimage_env else None
        argv0_complete = os.environ.get("ARGV0", None)
        self.argv0 = Path(argv0_complete).name if argv0_complete else None
        self.env_ep = os.environ.get("APP_ENTRY_POINT")
        self.virtual_env = os.environ.get("VIRTUAL_ENV")
        self.debug: bool = "--python-appimage-debug" in sys.argv

    def _debug(self, msg: str) -> None:
        if self.debug:
            sys.stderr.write(f"[appimage debug] {msg}\n")

    @cached_property
    def python_path(self) -> str:
        """Return the path to the python binary included in the AppImage."""
        return sys.executable

    @cached_property
    def appdir(self) -> str:
        """Get the application directory from the 'APPDIR' environment variable.

        If 'APPDIR' is not set in the environment, it defaults to the directory
        containing the current file (__file__).

        Returns
        -------
            str: The application directory specified by 'APPDIR'.

        Raises
        ------
            ValueError: If 'APPDIR' is not set in the environment.

        """
        if "APPDIR" not in os.environ:
            msg = "APPDIR not set - please export APPDIR variable in AppRun"
            raise ValueError(msg)
        return os.environ["APPDIR"]

    @cached_property
    def entry_points(self) -> dict[str, EntryPoint]:
        """Retrieve and cache the entry points for console scripts.

        This cached property method fetches and stores entry points for console scripts, organizing
        them into a dictionary. Each entry point is indexed by both its name and its value, allowing
        for quick access by either identifier.

        Returns
        -------
            Dict[str, EntryPoint]: A dictionary where the keys are the names and values of the entry
            points, and the values are the EntryPoint objects themselves.

        """
        scripts = get_entry_points(group="console_scripts")
        script_eps = {}
        for ep in scripts:
            script_eps[ep.name] = ep
            script_eps[ep.value] = ep
        return script_eps

    def get_entry_point(self, *, ignore_default: bool = False) -> EntryPoint | None:
        """Retrieve the appropriate entry point based on environment variables and defaults.

        This method determines the entry point to use by checking in the following order:
        1. Environment-specified entry point (`env_ep`).
        2. Command-line argument entry point (`argv0`).
        3. Default entry point (`default_ep`), unless `ignore_default` is True.

        Args:
        ----
            ignore_default (bool): If True, the default entry point (`default_ep`) will be
            ignored. Defaults to False.

        Returns:
        -------
            Optional[EntryPoint]: The selected entry point if found, otherwise None.

        """
        if self.env_ep and self.env_ep in self.entry_points:
            self._debug(f"get_entry_point: {self.env_ep!r} via APP_ENTRY_POINT")
            return self.entry_points[self.env_ep]
        if self.argv0 and self.argv0 in self.entry_points:
            self._debug(f"get_entry_point: {self.argv0!r} via argv0")
            return self.entry_points[self.argv0]
        if (
            not ignore_default
            and self.default_ep
            and self.default_ep in self.entry_points
        ):
            self._debug(f"get_entry_point: {self.default_ep!r} via --python-main")
            return self.entry_points[self.default_ep]
        self._debug("get_entry_point: no matching entry point found")
        return None

    def start_entry_point(self) -> None:
        """Load a module and execute the function specified by the entry point.

        The entry point is a string in the 'module:function' format.

        Raises
        ------
            InvalidEntryPointError: If the entry point does not exist.

        """
        if self.virtual_env:
            sys.executable = str(Path(self.virtual_env) / "bin/python3")
        entry_point = self.get_entry_point()
        if entry_point:
            self._debug(
                f"start_entry_point: loading {entry_point.name!r} ({entry_point.value!r})",
            )
            entry_point_loaded = entry_point.load()
            sys.exit(entry_point_loaded())

        error_msg = f"'{self.env_ep or self.default_ep or self.argv0}' is not a valid entry point!"
        raise InvalidEntryPointError(error_msg)

    def start_interpreter(self) -> None:
        """Start an interactive Python interpreter using the current Python executable.

        It passes any additional arguments provided in the command line to the interpreter.
        """
        args = [self.python_path, "-P"]
        if self.subprocess_args and len(self.subprocess_args) > 1:
            args.extend(self.subprocess_args[1:])
        self._debug(f"start_interpreter: exec {args!r}")
        os.execvp(  # nosec # noqa: S606 # Starting a process without a shell
            self.python_path,
            args,
        )

    def create_venv(
        self,
        *,
        venv_dirs: list[str],
        clear: bool = False,
        upgrade: bool = False,
        prompt: str | None = None,
        without_scm_ignore_files: bool = False,
    ) -> None:
        """Create a virtual environment in the specified directory.

        Args:
        ----
            venv_dirs: The directories where the virtual environments should be created.
            clear: Delete the environment directory contents before creation.
            upgrade: Upgrade the environment to use this version of Python.
            prompt: Alternative prompt prefix for the environment.
            without_scm_ignore_files: Skip adding SCM ignore files (e.g. .gitignore).

        """
        self._debug(f"create_venv: dirs={venv_dirs!r} clear={clear} upgrade={upgrade}")
        if sys.version_info >= (3, 13):
            builder = _AppImageEnvBuilder(  # pylint: disable=unexpected-keyword-arg
                symlinks=True,
                clear=clear,
                upgrade=upgrade,
                prompt=prompt,
                scm_ignore_files=(
                    frozenset() if without_scm_ignore_files else frozenset({"git"})
                ),
            )
        else:
            builder = _AppImageEnvBuilder(
                symlinks=True,
                clear=clear,
                upgrade=upgrade,
                prompt=prompt,
            )
        for venv_dir in venv_dirs:
            builder.create(venv_dir)
        sys.exit()

    def parse_venv_command(self) -> None:
        """Intercept ``python3 -m venv`` invocations and delegate to :meth:`create_venv`.

        Detects ``-m venv`` in ``sys.argv`` and, if found, strips those tokens and
        parses the remaining arguments with all standard ``python -m venv`` options.
        """
        try:
            index = sys.argv.index("-m")
        except ValueError:
            return
        if index + 1 >= len(sys.argv) or sys.argv[index + 1] != "venv":
            return
        remaining = sys.argv[1:index] + sys.argv[index + 2 :]
        args = _make_venv_parser().parse_args(remaining)
        self.create_venv(
            venv_dirs=args.dirs,
            clear=args.clear,
            upgrade=args.upgrade,
            prompt=args.prompt,
            without_scm_ignore_files=getattr(args, "without_scm_ignore_files", False),
        )

    def parse_python_args(self) -> None:
        """Parse command-line arguments for the AppImage execution.

        This function sets up an argument parser to handle various command-line options and
        configures the environment based on the parsed arguments. It supports options for displaying
        help, starting the Python interpreter, creating a virtual environment, and starting a Python
        entry point from console scripts.

        The `default_entry_point` argument is required and specifies the main entry point to start.
        """
        parser = argparse.ArgumentParser(
            prog=self.argv0,
            add_help=False,
            allow_abbrev=False,
        )
        parser.add_argument(
            "--python-help",
            action="help",
            default=argparse.SUPPRESS,
            help="Show this help message and exit.",
        )
        parser.add_argument(
            "--python-main",
            dest="default_entry_point",
            help="entry point to start.",
        )
        parser.add_argument(
            "--python-appimage-debug",
            dest="python_appimage_debug",
            action="store_true",
            help="print debug information to stderr during startup",
        )
        group = parser.add_mutually_exclusive_group()
        group.add_argument(
            "--python-interpreter",
            dest="python_interpreter",
            action="store_true",
            help="start the python interpreter",
        )
        group.add_argument(
            "--python-entry-point",
            dest="python_entry_point",
            metavar="ENTRY_POINT",
            help="start a python entry point from console scripts (e.g. ssh-mitm)",
        )
        group.add_argument(
            "--python-list-entry-points",
            dest="list_entry_points",
            action="store_true",
            help="list available console script entry points and exit",
        )

        args, subprocess_args = parser.parse_known_args()
        unknown_python_args = [
            arg for arg in subprocess_args if arg.startswith("--python-")
        ]
        if unknown_python_args:
            sys.exit(
                f"{self.argv0}: error: unrecognized python arguments:'{' '.join(unknown_python_args)}'",
            )

        if args.list_entry_points:
            sys.stdout.writelines(
                f"{ep.name} = {ep.value}\n"
                for ep in get_entry_points(group="console_scripts")
            )
            sys.exit(0)

        self.default_ep = args.default_entry_point
        sys.argv = self.subprocess_args = sys.argv[:1] + subprocess_args
        self._debug(
            f"parse_python_args: default_ep={self.default_ep!r} "
            f"env_ep={self.env_ep!r} subprocess_args={subprocess_args!r}",
        )
        if args.python_interpreter:
            self.parse_venv_command()
            self.start_interpreter()
        if args.python_entry_point:
            self.env_ep = args.python_entry_point

    def start(self) -> None:
        """Determine the entry point and start it.

        This method determines the appropriate entry point for the application and starts it.
        If an interpreter is requested via environment variables, or if no entry point is found,
        it starts an interpreter. Otherwise, it starts the determined entry point.

        It performs the following steps:
        1. Parses Python arguments to configure the environment.
        2. Checks if a default entry point, environment entry point, or any entry point is available.
        3. If no entry point is found or an interpreter is requested, starts the Python interpreter.
        4. If an entry point is found, starts the determined entry point.
        """
        self.parse_python_args()
        if (
            not self.default_ep and not self.env_ep and not self.get_entry_point()
        ) or self.argv0 in ["python", "python3", f"python3.{sys.version_info[1]}"]:
            self.parse_venv_command()
            self.start_interpreter()
        self.start_entry_point()

    def setup_virtualenv(self) -> None:
        """Set up the virtual environment for the application.

        Checks if VIRTUAL_ENV is active and its python3 symlink resolves to this AppImage,
        then configures the environment accordingly. If not, checks whether the command used
        to invoke the AppImage is itself a symlink inside a venv that points back to this
        AppImage, and activates that venv.
        """
        self._debug(
            f"setup_virtualenv: VIRTUAL_ENV={os.environ.get('VIRTUAL_ENV')!r} "
            f"appimage={self.appimage!r}",
        )
        if "VIRTUAL_ENV" in os.environ:
            resolved_python3 = os.path.realpath(
                str(Path(os.environ["VIRTUAL_ENV"]) / "bin" / "python3"),
            )
            self._debug(f"setup_virtualenv: resolved python3 → {resolved_python3!r}")
            if resolved_python3 == self.appimage:
                self._debug("setup_virtualenv: activating via VIRTUAL_ENV")
                self._activate_venv(os.environ["VIRTUAL_ENV"])
                return

        if not self.argv0:
            return

        argv0_full = os.environ.get("ARGV0", "")
        if "/" in argv0_full:
            cmd_path = argv0_full
        else:
            cmd_path = shutil.which(self.argv0) or "AppRun"

        if not Path(cmd_path).is_symlink():
            return

        venv_dir = self._find_venv_dir_from_symlink(cmd_path)
        if venv_dir:
            self._debug(
                f"setup_virtualenv: activating via symlink traversal: {venv_dir}",
            )
            self._activate_venv(venv_dir)

    def _find_venv_dir_from_symlink(self, cmd_path: str) -> str | None:
        """Traverse the symlink chain starting at cmd_path to find a venv root.

        Returns the venv directory path if a valid venv pointing to this AppImage is found,
        or None if the chain ends, no venv is found, or the depth limit is exceeded.
        """
        symlink_path = Path(cmd_path)
        depth_limit_reached = True
        for _ in range(20):
            if not symlink_path.is_symlink():
                depth_limit_reached = False
                break
            venv_dir = symlink_path.parent.parent
            pyvenv_cfg = venv_dir / "pyvenv.cfg"
            activate_script = venv_dir / "bin" / "activate"
            python_symlink = venv_dir / "bin" / "python3"

            if (
                pyvenv_cfg.is_file()
                and activate_script.is_file()
                and python_symlink.is_symlink()
                and os.path.realpath(str(python_symlink)) == self.appimage
            ):
                return str(venv_dir)

            self._debug(f"_find_venv_dir_from_symlink: following {symlink_path!s}")
            # pylint: disable-next=assignment-from-no-return
            raw_link = symlink_path.readlink()
            if not raw_link.is_absolute():
                raw_link = symlink_path.parent / raw_link
            symlink_path = raw_link.resolve()

        if depth_limit_reached:
            sys.stderr.write(
                f"warning: symlink depth limit (20) exceeded while resolving {cmd_path!r}; "
                "virtual environment not activated\n",
            )
        return None

    def _activate_venv(self, venv_dir: str) -> None:
        """Configure environment variables to use the given venv directory."""
        self._debug(f"_activate_venv: {venv_dir!r}")
        os.environ.pop("PYTHONNOUSERSITE", None)
        os.environ["VIRTUAL_ENV"] = venv_dir
        os.environ["PYTHONUSERBASE"] = venv_dir
        os.environ["PATH"] = f"{venv_dir}/bin:{os.environ['PATH']}"
        site.USER_BASE = venv_dir
        site.USER_SITE = str(
            Path(venv_dir)
            / "lib"
            / f"python{sys.version_info[0]}.{sys.version_info[1]}"
            / "site-packages",
        )
        sys.path.insert(0, site.USER_SITE)
        sys.prefix = venv_dir
        sys.exec_prefix = venv_dir
        config_vars = sysconfig.get_config_vars()
        config_vars["base"] = venv_dir
        config_vars["platbase"] = venv_dir


def start_entry_point() -> None:
    """Start the application initialization process.

    This function creates an instance of the AppStarter class and calls its start method.
    It acts as an entry point to begin the application's execution flow.

    The `start` method of the AppStarter instance will determine the appropriate entry point
    from the available configurations and proceed to execute it. If the `start` method encounters
    any issues that it cannot handle (such as configuration errors, missing entry points, etc.),
    it will raise an AppStartExceptionError.

    Raises
    ------
        AppStartExceptionError: If the application fails to start due to configuration errors
        or missing entry points.

    """
    if not os.environ.get("APPDIR"):
        sys.exit("This module must be started from an AppImage!")
    appstarter = AppStarter()
    try:
        appstarter.setup_virtualenv()
        appstarter.start()
    except AppStartExceptionError as exc:
        sys.exit(str(exc))


if __name__ == "__main__":
    start_entry_point()
