from frformat import CodeDepartement, Millesime, Options

proportion = 1
description = "French département code"
tags = ["fr", "geo"]
mandatory_label = True
labels = {
    "code departement": 1,
    "code_departement": 1,
    "dep": 0.5,
    "departement": 1,
    "dept": 0.75,
}

_options = Options(
    ignore_case=True,
    ignore_accents=True,
    replace_non_alphanumeric_with_space=True,
    ignore_extra_whitespace=True,
)
_code_departement = CodeDepartement(Millesime.LATEST, _options)


def _is(val) -> bool:
    return isinstance(val, str) and _code_departement.is_valid(val)


_test_values = {
    True: ["75", "2A", "2b", "974", "01"],
    False: ["00", "96", "101"],
}
