from pathlib import Path

import pytest

from app.history import SessionHistory, default_history_path


def test_visit_records_current_directory(tmp_path: Path) -> None:
    history = SessionHistory()
    first = tmp_path / "first"
    first.mkdir()

    visited = history.visit(first)

    assert visited == first.resolve()
    assert history.current == first.resolve()
    assert history.entries() == (first.resolve(),)


def test_visit_drops_forward_history_after_new_branch(tmp_path: Path) -> None:
    history = SessionHistory()
    first = tmp_path / "first"
    second = tmp_path / "second"
    third = tmp_path / "third"
    for path in (first, second, third):
        path.mkdir()

    history.visit(first)
    history.visit(second)
    assert history.back() == first.resolve()

    history.visit(third)

    assert history.entries() == (first.resolve(), third.resolve())
    assert history.current == third.resolve()
    assert history.forward() is None


def test_visit_does_not_duplicate_current_entry(tmp_path: Path) -> None:
    history = SessionHistory()
    directory = tmp_path / "directory"
    directory.mkdir()

    history.visit(directory)
    history.visit(directory)

    assert history.entries() == (directory.resolve(),)


def test_back_and_forward_move_through_history(tmp_path: Path) -> None:
    history = SessionHistory()
    first = tmp_path / "first"
    second = tmp_path / "second"
    for path in (first, second):
        path.mkdir()

    history.visit(first)
    history.visit(second)

    assert history.back() == first.resolve()
    assert history.back() is None
    assert history.forward() == second.resolve()
    assert history.forward() is None


def test_select_moves_to_specific_history_entry(tmp_path: Path) -> None:
    history = SessionHistory()
    first = tmp_path / "first"
    second = tmp_path / "second"
    for path in (first, second):
        path.mkdir()

    history.visit(first)
    history.visit(second)

    assert history.select(0) == first.resolve()
    assert history.current == first.resolve()


def test_select_raises_for_invalid_index() -> None:
    history = SessionHistory()

    with pytest.raises(IndexError):
        history.select(0)


def test_persistent_history_loads_entries_from_disk(tmp_path: Path) -> None:
    first = tmp_path / "first"
    second = tmp_path / "second"
    for directory in (first, second):
        directory.mkdir()
    history_file = tmp_path / "history.txt"
    history_file.write_text(f"{first}\n{second}\n", encoding="utf-8")

    history = SessionHistory.persistent(storage_path=history_file)

    assert history.entries() == (first.resolve(), second.resolve())
    assert history.current == second.resolve()


def test_persistent_history_visit_writes_to_disk_and_applies_limit(
    tmp_path: Path,
) -> None:
    first = tmp_path / "first"
    second = tmp_path / "second"
    third = tmp_path / "third"
    for directory in (first, second, third):
        directory.mkdir()
    history_file = tmp_path / "state" / "history.txt"

    history = SessionHistory.persistent(storage_path=history_file, max_entries=2)
    history.visit(first)
    history.visit(second)
    history.visit(third)

    assert history.entries() == (second.resolve(), third.resolve())
    assert history_file.read_text(encoding="utf-8").splitlines() == [
        str(second.resolve()),
        str(third.resolve()),
    ]


def test_default_history_path_uses_override_env(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    override = tmp_path / "custom-history.txt"
    monkeypatch.setenv("CD_BROWSER_HISTORY_FILE", str(override))

    assert default_history_path() == override
