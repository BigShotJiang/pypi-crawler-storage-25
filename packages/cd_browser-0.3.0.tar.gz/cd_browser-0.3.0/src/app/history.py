from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


def default_history_path() -> Path:
    """Return the default on-disk history location."""

    override = os.environ.get("CD_BROWSER_HISTORY_FILE")
    if override:
        return Path(override).expanduser()

    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming")))
    else:
        base = Path(os.environ.get("XDG_STATE_HOME", str(Path.home() / ".local/state")))

    return base / "cd-browser" / "history.txt"


@dataclass(slots=True)
class SessionHistory:
    """In-memory session history for visited directories."""

    _entries: list[Path] = field(default_factory=list)
    _index: int = -1
    storage_path: Path | None = None
    max_entries: int = 500

    @classmethod
    def persistent(
        cls, storage_path: Path | None = None, max_entries: int = 500
    ) -> SessionHistory:
        """Create a history instance backed by an on-disk file."""

        history = cls(
            storage_path=storage_path or default_history_path(),
            max_entries=max_entries,
        )
        history._load()
        return history

    def visit(self, path: Path) -> Path:
        """Record a directory visit and discard forward history when needed."""

        resolved_path = path.expanduser().resolve()

        if self.current == resolved_path:
            return resolved_path

        if self._index < len(self._entries) - 1:
            self._entries = self._entries[: self._index + 1]

        self._entries.append(resolved_path)
        self._trim_to_limit()
        self._index = len(self._entries) - 1
        self._persist()
        return resolved_path

    @property
    def current(self) -> Path | None:
        """Return the current history entry."""

        if self._index == -1:
            return None

        return self._entries[self._index]

    def back(self) -> Path | None:
        """Move backward in history when possible."""

        if self._index <= 0:
            return None

        self._index -= 1
        return self._entries[self._index]

    def forward(self) -> Path | None:
        """Move forward in history when possible."""

        if self._index == -1 or self._index >= len(self._entries) - 1:
            return None

        self._index += 1
        return self._entries[self._index]

    def select(self, index: int) -> Path:
        """Jump to a previously visited directory by history index."""

        if index < 0 or index >= len(self._entries):
            raise IndexError("History index out of range")

        self._index = index
        return self._entries[self._index]

    def entries(self) -> tuple[Path, ...]:
        """Return the full history as an immutable sequence."""

        return tuple(self._entries)

    def _load(self) -> None:
        if self.storage_path is None:
            return

        try:
            lines = self.storage_path.read_text(encoding="utf-8").splitlines()
        except FileNotFoundError:
            return
        except OSError:
            return

        loaded_entries: list[Path] = []
        for line in lines:
            raw = line.strip()
            if not raw:
                continue

            resolved = Path(raw).expanduser().resolve()
            if loaded_entries and loaded_entries[-1] == resolved:
                continue

            loaded_entries.append(resolved)

        self._entries = loaded_entries
        self._trim_to_limit()
        self._index = len(self._entries) - 1

    def _persist(self) -> None:
        if self.storage_path is None:
            return

        try:
            self.storage_path.parent.mkdir(parents=True, exist_ok=True)
            contents = "".join(f"{entry}\n" for entry in self._entries)
            self.storage_path.write_text(contents, encoding="utf-8")
        except OSError:
            return

    def _trim_to_limit(self) -> None:
        limit = max(1, self.max_entries)
        if len(self._entries) <= limit:
            return

        self._entries = self._entries[-limit:]
