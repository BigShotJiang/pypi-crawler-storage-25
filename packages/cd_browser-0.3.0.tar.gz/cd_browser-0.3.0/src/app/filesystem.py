from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class DirectoryEntry:
    """Directory metadata used by the navigator layer."""

    name: str
    path: Path
    has_children: bool


@dataclass(frozen=True, slots=True)
class FileSystemEntry:
    """Filesystem entry metadata for tree rendering."""

    name: str
    path: Path
    is_directory: bool
    has_children: bool


def list_directories(path: Path, show_hidden: bool = False) -> list[DirectoryEntry]:
    """Return direct child directories sorted by name."""

    entries = list_entries(path, show_hidden=show_hidden, include_files=False)
    return [
        DirectoryEntry(
            name=entry.name,
            path=entry.path,
            has_children=entry.has_children,
        )
        for entry in entries
    ]


def list_entries(
    path: Path, show_hidden: bool = False, include_files: bool = False
) -> list[FileSystemEntry]:
    """Return direct child entries sorted by type and name."""

    directory_path = path.expanduser().resolve()
    entries: list[FileSystemEntry] = []

    try:
        children = list(directory_path.iterdir())
    except PermissionError:
        return []

    for child in children:
        try:
            is_directory = child.is_dir()
        except OSError:
            continue

        if not is_directory and not include_files:
            continue
        if not show_hidden and child.name.startswith("."):
            continue

        entries.append(
            FileSystemEntry(
                name=child.name,
                path=child,
                is_directory=is_directory,
                has_children=(
                    has_subdirectories(child, show_hidden=show_hidden)
                    if is_directory
                    else False
                ),
            )
        )

    return sorted(
        entries,
        key=lambda entry: (not entry.is_directory, entry.name.casefold()),
    )


def has_subdirectories(path: Path, show_hidden: bool = False) -> bool:
    """Return whether the directory contains at least one subdirectory."""

    directory_path = path.expanduser().resolve()

    try:
        children = list(directory_path.iterdir())
    except PermissionError:
        return False

    for child in children:
        try:
            is_directory = child.is_dir()
        except OSError:
            continue

        if not is_directory:
            continue

        if not show_hidden and child.name.startswith("."):
            continue

        return True

    return False
