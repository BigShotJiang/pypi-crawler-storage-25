from __future__ import annotations

import subprocess
import time
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class DevSnapshot:
    """Development context for a path."""

    repo_root: Path | None
    git_branch: str | None
    git_dirty: bool
    last_commit: str | None
    stack: tuple[str, ...]
    commands: tuple[str, ...]

    @property
    def header_summary(self) -> str:
        git_part = "git:-"
        if self.git_branch:
            dirty_marker = "*" if self.git_dirty else ""
            git_part = f"git:{self.git_branch}{dirty_marker}"

        stack_part = ",".join(self.stack[:2]) if self.stack else "-"
        return f"{git_part} stack:{stack_part}"

    def detail_lines(self, current_path: Path) -> list[str]:
        lines = [f"Current path: {current_path}"]
        if self.repo_root is None:
            lines.append("Git: not a repository")
        else:
            dirty_text = "dirty" if self.git_dirty else "clean"
            lines.append(f"Git root: {self.repo_root}")
            lines.append(f"Git branch: {self.git_branch or '-'} ({dirty_text})")
            if self.last_commit:
                lines.append(f"Last commit: {self.last_commit}")

        stack_text = ", ".join(self.stack) if self.stack else "-"
        lines.append(f"Detected stack: {stack_text}")

        if self.commands:
            lines.append("Suggested commands:")
            for command in self.commands:
                lines.append(f"  - {command}")

        return lines


class DevInfoCache:
    """Simple TTL cache for development snapshots."""

    def __init__(self, ttl_seconds: float = 3.0) -> None:
        self._ttl_seconds = ttl_seconds
        self._cached_path: Path | None = None
        self._cached_at: float = 0.0
        self._cached_snapshot: DevSnapshot | None = None

    def get(self, path: Path) -> DevSnapshot:
        resolved_path = path.expanduser().resolve()
        now = time.monotonic()
        if (
            self._cached_snapshot is not None
            and self._cached_path == resolved_path
            and (now - self._cached_at) <= self._ttl_seconds
        ):
            return self._cached_snapshot

        snapshot = collect_dev_snapshot(resolved_path)
        self._cached_path = resolved_path
        self._cached_snapshot = snapshot
        self._cached_at = now
        return snapshot


def collect_dev_snapshot(path: Path) -> DevSnapshot:
    """Collect git and stack metadata for a path."""

    repo_root = _git_repo_root(path)
    git_branch: str | None = None
    git_dirty = False
    last_commit: str | None = None

    if repo_root is not None:
        git_branch = _run_command(
            ["git", "-C", str(repo_root), "rev-parse", "--abbrev-ref", "HEAD"]
        )
        status_output = _run_command(
            ["git", "-C", str(repo_root), "status", "--porcelain"]
        )
        git_dirty = bool(status_output)
        last_commit = _run_command(
            ["git", "-C", str(repo_root), "log", "-1", "--pretty=format:%h %s"]
        )

    stack = _detect_stack(path)
    return DevSnapshot(
        repo_root=repo_root,
        git_branch=git_branch,
        git_dirty=git_dirty,
        last_commit=last_commit,
        stack=stack,
        commands=_suggested_commands(stack, repo_root is not None),
    )


def _git_repo_root(path: Path) -> Path | None:
    result = _run_command(["git", "-C", str(path), "rev-parse", "--show-toplevel"])
    if not result:
        return None
    return Path(result).expanduser().resolve()


def _detect_stack(path: Path) -> tuple[str, ...]:
    markers = (
        ("pyproject.toml", "python"),
        ("requirements.txt", "python"),
        ("package.json", "node"),
        ("go.mod", "go"),
        ("Cargo.toml", "rust"),
    )
    found: list[str] = []
    for marker, stack_name in markers:
        if (path / marker).exists() and stack_name not in found:
            found.append(stack_name)

    return tuple(found)


def _suggested_commands(stack: tuple[str, ...], has_git: bool) -> tuple[str, ...]:
    commands: list[str] = []
    if has_git:
        commands.append("git status -sb")

    if "python" in stack:
        commands.extend(["pytest -q", "ruff check src tests"])
    if "node" in stack:
        commands.extend(["npm test", "npm run lint"])
    if "go" in stack:
        commands.append("go test ./...")
    if "rust" in stack:
        commands.append("cargo test")

    return tuple(commands)


def _run_command(command: list[str]) -> str | None:
    try:
        result = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            timeout=0.35,
        )
    except (OSError, subprocess.SubprocessError):
        return None

    if result.returncode != 0:
        return None

    output = result.stdout.strip()
    if not output:
        return None

    return output
