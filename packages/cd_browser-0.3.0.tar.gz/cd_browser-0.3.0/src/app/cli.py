from __future__ import annotations

from pathlib import Path

from app.history import SessionHistory
from app.navigator import Navigator
from app.ui import TerminalUI


def run_cli(start_path: Path | None = None, ui: TerminalUI | None = None) -> Path:
    """Run the interactive directory browser and return the selected path."""

    initial_path = (start_path or Path.cwd()).expanduser().resolve()
    navigator = Navigator(initial_path, history=SessionHistory.persistent())
    terminal_ui = ui or TerminalUI()
    return terminal_ui.run(navigator)
