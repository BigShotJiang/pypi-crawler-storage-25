from __future__ import annotations

import os
import shlex
import shutil
import subprocess
import sys
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Literal

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - python < 3.11
    tomllib = None  # type: ignore[assignment]

LaunchMode = Literal["background", "blocking"]
DEFAULT_FILE_OPENERS = ("code", "open", "antigravity", "nvim", "nano", "less", "bat")
DEFAULT_DIRECTORY_OPENERS = ("code", "opencode", "antigravity", "nvim")


@dataclass(frozen=True, slots=True)
class OpenWithOption:
    """Candidate application command for opening a path."""

    label: str
    command_template: str
    executable: str
    launch_mode: LaunchMode
    requires_gui: bool = False
    supports_files: bool = True
    supports_directories: bool = True


def available_openers(path: Path) -> list[OpenWithOption]:
    """Return available open-with options for a file or directory path."""

    is_directory = path.is_dir()
    has_gui = _has_gui_session()
    options: list[OpenWithOption] = []
    catalog = _options_catalog()
    configured_option_ids = _configured_option_ids(is_directory, catalog)

    for option_id in configured_option_ids:
        option = catalog[option_id]
        if is_directory and not option.supports_directories:
            continue
        if not is_directory and not option.supports_files:
            continue
        if option.requires_gui and not has_gui:
            continue
        if not shutil.which(option.executable):
            continue

        options.append(option)

    return options


def launch_background_option(path: Path, option: OpenWithOption) -> tuple[bool, str]:
    """Launch a non-blocking option and return status/message."""

    command = _command_parts(option.command_template, path)
    if not command:
        return False, "Invalid open command"

    try:
        subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError as error:
        return False, f"Open failed: {error}"

    return True, f"Opened with {option.label}"


def launch_blocking_option(path: Path, option: OpenWithOption) -> tuple[bool, str]:
    """Launch a blocking terminal option and return status/message."""

    command = _command_parts(option.command_template, path)
    if not command:
        return False, "Invalid open command"

    try:
        result = subprocess.run(command, check=False)
    except OSError as error:
        return False, f"Open failed: {error}"

    if result.returncode != 0:
        return (
            False,
            f"Open failed: {option.label} exited with code {result.returncode}",
        )

    return True, f"Opened with {option.label}"


def is_blocking_option(option: OpenWithOption) -> bool:
    """Return whether the option should block the current terminal session."""

    return option.launch_mode == "blocking"


def _options_catalog() -> dict[str, OpenWithOption]:
    return {
        "code": OpenWithOption(
            label="VS Code",
            command_template="code {path}",
            executable="code",
            launch_mode="background",
            requires_gui=True,
        ),
        "open": OpenWithOption(
            label="Open (system)",
            command_template=_system_open_template(),
            executable=_system_open_executable(),
            launch_mode="background",
            requires_gui=True,
            supports_directories=False,
        ),
        "opencode": OpenWithOption(
            label="OpenCode",
            command_template="opencode {path}",
            executable="opencode",
            launch_mode="background",
            supports_files=False,
        ),
        "antigravity": OpenWithOption(
            label="Antigravity",
            command_template="antigravity {path}",
            executable="antigravity",
            launch_mode="background",
        ),
        "nvim": OpenWithOption(
            label="Neovim",
            command_template="nvim {path}",
            executable="nvim",
            launch_mode="blocking",
        ),
        "nano": OpenWithOption(
            label="Nano",
            command_template="nano {path}",
            executable="nano",
            launch_mode="blocking",
            supports_directories=False,
        ),
        "less": OpenWithOption(
            label="Less",
            command_template="less {path}",
            executable="less",
            launch_mode="blocking",
            supports_directories=False,
        ),
        "bat": OpenWithOption(
            label="Bat",
            command_template="bat {path}",
            executable="bat",
            launch_mode="blocking",
            supports_directories=False,
        ),
    }


def _configured_option_ids(
    is_directory: bool, catalog: dict[str, OpenWithOption]
) -> list[str]:
    config = _load_openers_config()
    defaults = (
        list(DEFAULT_DIRECTORY_OPENERS) if is_directory else list(DEFAULT_FILE_OPENERS)
    )
    configured = config["directories"] if is_directory else config["files"]

    seen: set[str] = set()
    option_ids: list[str] = []
    for option_id in configured:
        if option_id not in catalog or option_id in seen:
            continue
        seen.add(option_id)
        option_ids.append(option_id)

    if option_ids:
        return option_ids

    return [option_id for option_id in defaults if option_id in catalog]


def _openers_config_path() -> Path:
    override = os.environ.get("CD_BROWSER_CONFIG_FILE")
    if override:
        return Path(override).expanduser()

    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming")))
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config")))

    return base / "cd-browser" / "config.toml"


@lru_cache(maxsize=1)
def _load_openers_config() -> dict[str, list[str]]:
    defaults = {
        "files": list(DEFAULT_FILE_OPENERS),
        "directories": list(DEFAULT_DIRECTORY_OPENERS),
    }
    config_path = _openers_config_path()
    _ensure_default_config_file(config_path)
    if tomllib is None or not config_path.exists():
        return defaults

    try:
        raw_data = tomllib.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError):
        return defaults

    if not isinstance(raw_data, dict):
        return defaults

    open_with = raw_data.get("open_with")
    if not isinstance(open_with, dict):
        return defaults

    files = open_with.get("files")
    directories = open_with.get("directories")
    return {
        "files": _normalize_ids(files, defaults["files"]),
        "directories": _normalize_ids(directories, defaults["directories"]),
    }


def _normalize_ids(value: object, fallback: list[str]) -> list[str]:
    if not isinstance(value, list):
        return fallback

    normalized = [
        item.strip() for item in value if isinstance(item, str) and item.strip()
    ]
    return normalized if normalized else fallback


def _ensure_default_config_file(path: Path) -> None:
    if path.exists():
        return

    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(_default_config_toml(), encoding="utf-8")
    except OSError:
        return


def _default_config_toml() -> str:
    file_ids = '", "'.join(DEFAULT_FILE_OPENERS)
    directory_ids = '", "'.join(DEFAULT_DIRECTORY_OPENERS)
    return (
        "# cd-browser opener configuration\n"
        "# Reorder or remove items to customize menu priority.\n"
        "[open_with]\n"
        f'files = ["{file_ids}"]\n'
        f'directories = ["{directory_ids}"]\n'
    )


def _reset_openers_config_cache() -> None:
    _load_openers_config.cache_clear()


def _has_gui_session() -> bool:
    if os.environ.get("SSH_CONNECTION") or os.environ.get("SSH_TTY"):
        return False

    if sys.platform == "darwin":
        return True

    if sys.platform.startswith("linux"):
        return bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))

    if sys.platform.startswith("win"):
        return True

    return False


def _system_open_template() -> str:
    if sys.platform == "darwin":
        return "open {path}"

    if sys.platform.startswith("linux"):
        return "xdg-open {path}"

    if sys.platform.startswith("win"):
        return 'cmd /c start "" {path}'

    return "open {path}"


def _system_open_executable() -> str:
    if sys.platform == "darwin":
        return "open"

    if sys.platform.startswith("linux"):
        return "xdg-open"

    if sys.platform.startswith("win"):
        return "cmd"

    return "open"


def _command_parts(command_template: str, path: Path) -> list[str]:
    rendered = command_template.format(path=shlex.quote(str(path)))
    return shlex.split(rendered)
