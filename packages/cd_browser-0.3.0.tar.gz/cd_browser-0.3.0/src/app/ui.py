from __future__ import annotations

import curses
import os
import sys
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from importlib import metadata
from pathlib import Path
from typing import TextIO

from app.devinfo import DevInfoCache, DevSnapshot
from app.navigator import Navigator, VisibleEntry
from app.opener import (
    OpenWithOption,
    available_openers,
    is_blocking_option,
    launch_background_option,
    launch_blocking_option,
)

ESCAPE_KEY = 27
BACKSPACE_KEYS = (curses.KEY_BACKSPACE, 127, 8)
DEFAULT_APP_VERSION = "0.3.0"
FILTER_COLOR_PAIR = 1
NORMAL_COLOR_PAIR = 2


def _app_version() -> str:
    """Return installed package version when available."""

    try:
        return metadata.version("cd-browser")
    except metadata.PackageNotFoundError:
        return DEFAULT_APP_VERSION


@dataclass(frozen=True, slots=True)
class RenderLine:
    """A rendered navigator row ready for terminal output."""

    text: str
    is_selected: bool


@dataclass(frozen=True, slots=True)
class HistoryLine:
    """A rendered history row ready for terminal output."""

    text: str
    is_selected: bool


def move_selection(current_index: int, step: int, entry_count: int) -> int:
    """Move the selected index within the available entry range."""

    if entry_count <= 0:
        return 0

    return max(0, min(current_index + step, entry_count - 1))


def format_entry(entry: VisibleEntry) -> str:
    """Format a visible entry for terminal display."""

    if entry.is_parent:
        return entry.name

    indent = "    " * entry.depth

    if entry.is_file:
        indicator = "•"
    elif entry.has_children:
        indicator = "▼" if entry.is_expanded else "▶"
    else:
        indicator = " "

    return f"{indent}{indicator} {entry.name}"


def build_render_lines(navigator: Navigator) -> list[RenderLine]:
    """Build all visible lines for the current navigator state."""

    return [
        RenderLine(
            text=format_entry(entry),
            is_selected=index == navigator.selected_index,
        )
        for index, entry in enumerate(navigator.visible_entries)
    ]


def build_history_lines(
    entries: tuple[Path, ...], selected_index: int
) -> list[HistoryLine]:
    """Build all visible lines for history mode."""

    return [
        HistoryLine(text=str(path), is_selected=index == selected_index)
        for index, path in enumerate(entries)
    ]


def build_status_line(
    navigator: Navigator, filter_mode: bool, filter_query: str, dev_summary: str
) -> str:
    """Build first header line with version and live session toggles."""

    hidden_status = "on" if navigator.show_hidden else "off"
    file_status = "on" if navigator.show_files else "off"
    if filter_mode:
        filter_segment = f"filter: {filter_query}" if filter_query else "filter:"
    else:
        filter_segment = "filter: off"
    history_count = len(navigator.history.entries())
    return (
        f"cd-browser v{_app_version()} | hist: {history_count} | "
        f"{filter_segment} | hidden: {hidden_status} | files: {file_status} | "
        f"dev: {dev_summary}"
    )


def build_path_line(path: Path) -> str:
    """Build second header line with current path."""

    return f"path: {path}"


def clamp_scroll_offset(
    selected_index: int, scroll_offset: int, visible_count: int, total_count: int
) -> int:
    """Keep the selected row within the visible scrolling window."""

    if visible_count <= 0 or total_count <= visible_count:
        return 0

    max_offset = total_count - visible_count
    offset = max(0, min(scroll_offset, max_offset))

    if selected_index < offset:
        return selected_index

    if selected_index >= offset + visible_count:
        return selected_index - visible_count + 1

    return offset


class TerminalUI:
    """Minimal curses UI for the directory navigator MVP."""

    def __init__(self) -> None:
        self._history_mode = False
        self._history_selected_index = 0
        self._tree_scroll_offset = 0
        self._history_scroll_offset = 0
        self._history_filter_mode = False
        self._history_filter_query = ""
        self._history_filter_selected_index = 0
        self._history_filter_scroll_offset = 0
        self._info_mode = False
        self._filter_mode = False
        self._filter_query = ""
        self._filter_selected_index = 0
        self._filter_scroll_offset = 0
        self._status_message: str | None = None
        self._normal_attr = curses.A_NORMAL
        self._filter_label_attr = curses.A_BOLD
        self._dev_info = DevInfoCache()

    def run(self, navigator: Navigator) -> Path:
        """Start the interactive session and return the final directory path."""

        with open_terminal_streams() as (input_stream, output_stream):
            with redirect_standard_streams(input_stream, output_stream):
                return curses.wrapper(self._run_session, navigator)

    def _run_session(self, stdscr: curses.window, navigator: Navigator) -> Path:
        curses.curs_set(0)
        stdscr.keypad(True)
        self._initialize_colors()
        original_path = navigator.current_path

        while True:
            self._render(stdscr, navigator)
            key = stdscr.getch()

            if self._info_mode:
                self._handle_info_key(key)
                continue

            if self._history_mode:
                self._handle_history_key(key, navigator, stdscr=stdscr)
                continue

            if self._filter_mode:
                filter_result = self._handle_filter_key(key, navigator, stdscr)
                if filter_result is not None:
                    return filter_result
                continue

            if key == ESCAPE_KEY:
                return original_path

            if key == ord("h"):
                self._toggle_history_mode(navigator)
                continue

            tree_result = self._handle_tree_key(key, navigator, stdscr=stdscr)
            if tree_result is not None:
                return tree_result

    def _render(self, stdscr: curses.window, navigator: Navigator) -> None:
        stdscr.attrset(self._normal_attr)
        stdscr.erase()
        height, width = stdscr.getmaxyx()
        snapshot = self._dev_info.get(navigator.current_path)

        if self._history_mode:
            self._render_history_mode(
                stdscr,
                navigator,
                snapshot=snapshot,
                width=width,
                height=height,
            )
            stdscr.refresh()
            return

        if self._info_mode:
            self._render_info_mode(
                stdscr,
                navigator,
                snapshot=snapshot,
                width=width,
                height=height,
            )
            stdscr.refresh()
            return

        status_line = build_status_line(
            navigator,
            filter_mode=self._filter_mode,
            filter_query=self._filter_query,
            dev_summary=snapshot.header_summary,
        )
        path_line = build_path_line(navigator.current_path)
        self._render_status_line(
            stdscr,
            0,
            width,
            status_line,
            filter_active=self._filter_mode,
        )
        stdscr.addnstr(
            1, 0, path_line, max(0, width - 1), self._normal_attr | curses.A_DIM
        )
        start_row = 2

        lines, selected_index = self._build_tree_lines_for_render(navigator)
        footer_rows = 1 if self._status_message else 0
        visible_count = max(0, height - start_row - footer_rows)

        if self._filter_mode:
            self._filter_scroll_offset = clamp_scroll_offset(
                selected_index,
                self._filter_scroll_offset,
                visible_count,
                len(lines),
            )
            scroll_offset = self._filter_scroll_offset
        else:
            self._tree_scroll_offset = clamp_scroll_offset(
                selected_index,
                self._tree_scroll_offset,
                visible_count,
                len(lines),
            )
            scroll_offset = self._tree_scroll_offset

        if self._filter_mode and self._filter_query and not lines:
            stdscr.addnstr(
                start_row,
                0,
                "No matches",
                max(0, width - 1),
                self._normal_attr | curses.A_DIM,
            )
        else:
            for row, line in enumerate(
                lines[scroll_offset : scroll_offset + visible_count],
                start=start_row,
            ):
                if row >= height:
                    break

                attributes = (
                    self._normal_attr | curses.A_REVERSE
                    if line.is_selected
                    else self._normal_attr
                )
                stdscr.addnstr(row, 0, line.text, max(0, width - 1), attributes)

        if self._status_message and height > 0:
            stdscr.addnstr(
                height - 1,
                0,
                self._status_message,
                max(0, width - 1),
                self._normal_attr | curses.A_DIM,
            )

        stdscr.refresh()

    def _build_tree_lines_for_render(
        self, navigator: Navigator
    ) -> tuple[list[RenderLine], int]:
        if not self._filter_mode:
            return build_render_lines(navigator), navigator.selected_index

        entries = navigator.visible_entries
        matches = self._matching_indices(entries)
        if not matches:
            self._filter_selected_index = 0
            return [], 0

        self._filter_selected_index = max(
            0, min(self._filter_selected_index, len(matches) - 1)
        )

        return [
            RenderLine(
                text=format_entry(entries[entry_index]),
                is_selected=match_index == self._filter_selected_index,
            )
            for match_index, entry_index in enumerate(matches)
        ], self._filter_selected_index

    def _render_history_mode(
        self,
        stdscr: curses.window,
        navigator: Navigator,
        snapshot: DevSnapshot,
        width: int,
        height: int,
    ) -> None:
        stdscr.attrset(self._normal_attr)
        status_line = build_status_line(
            navigator,
            filter_mode=self._history_filter_mode,
            filter_query=self._history_filter_query,
            dev_summary=snapshot.header_summary,
        )
        path_line = build_path_line(navigator.current_path)
        self._render_status_line(
            stdscr,
            0,
            width,
            status_line,
            filter_active=self._history_filter_mode,
        )
        stdscr.addnstr(
            1, 0, path_line, max(0, width - 1), self._normal_attr | curses.A_DIM
        )

        history_entries = navigator.history.entries()
        history_lines, selected_index = self._build_history_lines_for_render(
            history_entries
        )
        start_row = 2
        footer_rows = 1 if self._status_message else 0
        visible_count = max(0, height - start_row - 1 - footer_rows)
        if self._history_filter_mode:
            self._history_filter_scroll_offset = clamp_scroll_offset(
                selected_index,
                self._history_filter_scroll_offset,
                visible_count,
                len(history_lines),
            )
            scroll_offset = self._history_filter_scroll_offset
        else:
            self._history_scroll_offset = clamp_scroll_offset(
                selected_index,
                self._history_scroll_offset,
                visible_count,
                len(history_lines),
            )
            scroll_offset = self._history_scroll_offset

        stdscr.addnstr(
            start_row,
            0,
            "History:",
            max(0, width - 1),
            self._normal_attr | curses.A_BOLD,
        )

        for index, line in enumerate(
            history_lines[scroll_offset : scroll_offset + visible_count],
            start=1,
        ):
            row = start_row + index
            if row >= height:
                break

            attributes = (
                self._normal_attr | curses.A_REVERSE
                if line.is_selected
                else self._normal_attr
            )
            stdscr.addnstr(row, 0, line.text, max(0, width - 1), attributes)

        if (
            self._history_filter_mode
            and self._history_filter_query
            and not history_lines
        ):
            stdscr.addnstr(
                start_row + 1,
                0,
                "No matches",
                max(0, width - 1),
                self._normal_attr | curses.A_DIM,
            )

        if self._status_message and height > 0:
            stdscr.addnstr(
                height - 1,
                0,
                self._status_message,
                max(0, width - 1),
                self._normal_attr | curses.A_DIM,
            )

    def _toggle_history_mode(self, navigator: Navigator) -> None:
        self._history_mode = not self._history_mode
        self._status_message = None
        if self._history_mode:
            self._history_selected_index = self._get_current_history_index(navigator)
            self._history_scroll_offset = 0
            self._history_filter_mode = False
            self._history_filter_query = ""
            self._history_filter_selected_index = 0
            self._history_filter_scroll_offset = 0
            return

        self._history_filter_mode = False
        self._history_filter_query = ""
        self._history_filter_selected_index = 0
        self._history_filter_scroll_offset = 0

    def _render_info_mode(
        self,
        stdscr: curses.window,
        navigator: Navigator,
        snapshot: DevSnapshot,
        width: int,
        height: int,
    ) -> None:
        status_line = build_status_line(
            navigator,
            filter_mode=False,
            filter_query="",
            dev_summary=snapshot.header_summary,
        )
        path_line = build_path_line(navigator.current_path)
        self._render_status_line(stdscr, 0, width, status_line, filter_active=False)
        stdscr.addnstr(
            1, 0, path_line, max(0, width - 1), self._normal_attr | curses.A_DIM
        )
        stdscr.addnstr(
            2,
            0,
            "Dev info (Esc/i to close)",
            max(0, width - 1),
            self._normal_attr | curses.A_BOLD,
        )
        detail_lines = snapshot.detail_lines(navigator.current_path)
        for row, line in enumerate(detail_lines, start=3):
            if row >= height:
                break
            stdscr.addnstr(row, 0, line, max(0, width - 1), self._normal_attr)

    def _initialize_colors(self) -> None:
        self._normal_attr = curses.A_NORMAL
        self._filter_label_attr = curses.A_BOLD
        if not curses.has_colors():
            return

        try:
            curses.start_color()
            curses.use_default_colors()
            curses.init_pair(NORMAL_COLOR_PAIR, curses.COLOR_WHITE, -1)
            curses.init_pair(FILTER_COLOR_PAIR, curses.COLOR_GREEN, -1)
            self._normal_attr = curses.color_pair(NORMAL_COLOR_PAIR)
            self._filter_label_attr = (
                curses.color_pair(FILTER_COLOR_PAIR) | curses.A_BOLD
            )
        except curses.error:
            self._normal_attr = curses.A_NORMAL
            self._filter_label_attr = curses.A_BOLD

    def _render_status_line(
        self,
        stdscr: curses.window,
        row: int,
        width: int,
        status_line: str,
        filter_active: bool,
    ) -> None:
        max_width = max(0, width - 1)
        if not filter_active:
            stdscr.attrset(self._normal_attr)
            stdscr.addnstr(row, 0, status_line, max_width)
            stdscr.attrset(self._normal_attr)
            return

        prefix, marker, suffix = status_line.partition("filter:")
        if not marker:
            stdscr.attrset(self._normal_attr)
            stdscr.addnstr(row, 0, status_line, max_width)
            stdscr.attrset(self._normal_attr)
            return

        x = 0
        stdscr.attrset(self._normal_attr)
        stdscr.addnstr(row, x, prefix, max_width)
        x += min(len(prefix), max_width)
        if x >= max_width:
            return

        marker_width = max_width - x
        stdscr.attrset(self._filter_label_attr)
        stdscr.addnstr(row, x, marker, marker_width)
        x += min(len(marker), marker_width)
        if x >= max_width:
            return

        stdscr.attrset(self._normal_attr)
        stdscr.addnstr(row, x, suffix, max_width - x)
        stdscr.attrset(self._normal_attr)

    def _handle_history_key(
        self, key: int, navigator: Navigator, stdscr: curses.window | None = None
    ) -> None:
        history_entries = navigator.history.entries()
        matches = self._matching_history_indices(history_entries)

        if self._history_filter_mode:
            if key == ESCAPE_KEY:
                self._history_filter_mode = False
                self._history_filter_query = ""
                self._history_filter_selected_index = 0
                self._history_filter_scroll_offset = 0
                return

            if key in (curses.KEY_ENTER, 10, 13):
                if not matches:
                    return

                selected_entry_index = matches[self._history_filter_selected_index]
                navigator.select_history_entry(selected_entry_index)
                self._history_mode = False
                self._history_filter_mode = False
                self._history_filter_query = ""
                self._history_filter_selected_index = 0
                self._history_filter_scroll_offset = 0
                self._tree_scroll_offset = 0
                return

            if key == curses.KEY_UP:
                self._history_filter_selected_index = move_selection(
                    self._history_filter_selected_index,
                    step=-1,
                    entry_count=len(matches),
                )
                return

            if key == curses.KEY_DOWN:
                self._history_filter_selected_index = move_selection(
                    self._history_filter_selected_index,
                    step=1,
                    entry_count=len(matches),
                )
                return

            if key == curses.KEY_PPAGE:
                step = -self._page_step(stdscr, start_row=3)
                self._history_filter_selected_index = move_selection(
                    self._history_filter_selected_index,
                    step=step,
                    entry_count=len(matches),
                )
                return

            if key == curses.KEY_NPAGE:
                step = self._page_step(stdscr, start_row=3)
                self._history_filter_selected_index = move_selection(
                    self._history_filter_selected_index,
                    step=step,
                    entry_count=len(matches),
                )
                return

            if key == curses.KEY_HOME:
                self._history_filter_selected_index = 0
                return

            if key == curses.KEY_END and matches:
                self._history_filter_selected_index = len(matches) - 1
                return

            if key in BACKSPACE_KEYS:
                self._history_filter_query = self._history_filter_query[:-1]
                self._history_filter_selected_index = 0
                self._history_filter_scroll_offset = 0
                return

            if 32 <= key <= 126:
                self._history_filter_query += chr(key)
                self._history_filter_selected_index = 0
                self._history_filter_scroll_offset = 0

            return

        if key in (ESCAPE_KEY, ord("h")):
            self._history_mode = False
            self._history_filter_mode = False
            self._history_filter_query = ""
            self._history_filter_selected_index = 0
            self._history_filter_scroll_offset = 0
            return

        if key == ord("i"):
            self._history_mode = False
            self._history_filter_mode = False
            self._history_filter_query = ""
            self._history_filter_selected_index = 0
            self._history_filter_scroll_offset = 0
            self._info_mode = True
            return

        if key == ord("/"):
            self._history_filter_mode = True
            self._history_filter_query = ""
            self._history_filter_selected_index = 0
            self._history_filter_scroll_offset = 0
            return

        if key == curses.KEY_UP:
            self._history_selected_index = move_selection(
                self._history_selected_index,
                step=-1,
                entry_count=len(history_entries),
            )
            return

        if key == curses.KEY_DOWN:
            self._history_selected_index = move_selection(
                self._history_selected_index,
                step=1,
                entry_count=len(history_entries),
            )
            return

        if key == curses.KEY_PPAGE:
            step = -self._page_step(stdscr, start_row=3)
            self._history_selected_index = move_selection(
                self._history_selected_index,
                step=step,
                entry_count=len(history_entries),
            )
            return

        if key == curses.KEY_NPAGE:
            step = self._page_step(stdscr, start_row=3)
            self._history_selected_index = move_selection(
                self._history_selected_index,
                step=step,
                entry_count=len(history_entries),
            )
            return

        if key in (curses.KEY_HOME, ord("g")):
            self._history_selected_index = 0
            return

        if key in (curses.KEY_END, ord("G")) and history_entries:
            self._history_selected_index = len(history_entries) - 1
            return

        if key in (curses.KEY_ENTER, 10, 13) and history_entries:
            selected_entry_index = self._history_display_indices(history_entries)[
                self._history_selected_index
            ]
            navigator.select_history_entry(selected_entry_index)
            self._history_mode = False
            self._history_filter_mode = False
            self._history_filter_query = ""
            self._history_filter_selected_index = 0
            self._history_filter_scroll_offset = 0
            self._tree_scroll_offset = 0

    def _handle_filter_key(
        self, key: int, navigator: Navigator, stdscr: curses.window | None = None
    ) -> Path | None:
        entries = navigator.visible_entries
        matches = self._matching_indices(entries)

        if key == ESCAPE_KEY:
            self._filter_mode = False
            self._filter_query = ""
            self._filter_selected_index = 0
            self._filter_scroll_offset = 0
            return None

        if key in (curses.KEY_ENTER, 10, 13):
            if not matches:
                return None

            selected_entry_index = matches[self._filter_selected_index]
            navigator.set_selected_index(selected_entry_index)
            selected = entries[selected_entry_index]

            self._filter_mode = False
            self._filter_query = ""
            self._filter_selected_index = 0
            self._filter_scroll_offset = 0

            if selected.is_file:
                self._open_with_selected(navigator, stdscr)
                return None

            navigator.enter_selected_directory()
            self._tree_scroll_offset = 0
            return None

        if key == curses.KEY_UP:
            self._filter_selected_index = move_selection(
                self._filter_selected_index,
                step=-1,
                entry_count=len(matches),
            )
            return None

        if key == curses.KEY_DOWN:
            self._filter_selected_index = move_selection(
                self._filter_selected_index,
                step=1,
                entry_count=len(matches),
            )
            return None

        if key == curses.KEY_PPAGE:
            step = -self._page_step(stdscr, start_row=3)
            self._filter_selected_index = move_selection(
                self._filter_selected_index,
                step=step,
                entry_count=len(matches),
            )
            return None

        if key == curses.KEY_NPAGE:
            step = self._page_step(stdscr, start_row=3)
            self._filter_selected_index = move_selection(
                self._filter_selected_index,
                step=step,
                entry_count=len(matches),
            )
            return None

        if key == curses.KEY_HOME:
            self._filter_selected_index = 0
            return None

        if key == curses.KEY_END and matches:
            self._filter_selected_index = len(matches) - 1
            return None

        if key in BACKSPACE_KEYS:
            self._filter_query = self._filter_query[:-1]
            self._filter_selected_index = 0
            self._filter_scroll_offset = 0
            return None

        if 32 <= key <= 126:
            self._filter_query += chr(key)
            self._filter_selected_index = 0
            self._filter_scroll_offset = 0

        return None

    def _handle_tree_key(
        self,
        key: int,
        navigator: Navigator,
        stdscr: curses.window | None = None,
    ) -> Path | None:
        self._status_message = None

        if key == curses.KEY_UP:
            navigator.set_selected_index(
                move_selection(
                    navigator.selected_index,
                    step=-1,
                    entry_count=len(navigator.visible_entries),
                )
            )
            return None

        if key == curses.KEY_DOWN:
            navigator.set_selected_index(
                move_selection(
                    navigator.selected_index,
                    step=1,
                    entry_count=len(navigator.visible_entries),
                )
            )
            return None

        if key == curses.KEY_PPAGE:
            navigator.set_selected_index(
                move_selection(
                    navigator.selected_index,
                    step=-self._page_step(stdscr, start_row=2),
                    entry_count=len(navigator.visible_entries),
                )
            )
            return None

        if key == curses.KEY_NPAGE:
            navigator.set_selected_index(
                move_selection(
                    navigator.selected_index,
                    step=self._page_step(stdscr, start_row=2),
                    entry_count=len(navigator.visible_entries),
                )
            )
            return None

        if key in (curses.KEY_HOME, ord("g")):
            navigator.set_selected_index(0)
            return None

        if key in (curses.KEY_END, ord("G")):
            navigator.set_selected_index(len(navigator.visible_entries) - 1)
            return None

        if key == curses.KEY_RIGHT:
            selected = navigator.selected_entry
            if selected.is_file:
                return None

            was_expanded = selected.is_expanded

            if not navigator.expand_selected_directory():
                navigator.enter_selected_directory()
                self._tree_scroll_offset = 0
                return None

            if was_expanded:
                navigator.enter_selected_directory()
                self._tree_scroll_offset = 0

            return None

        if key == curses.KEY_LEFT:
            if not navigator.collapse_selected_directory():
                navigator.go_to_parent_directory()
                self._tree_scroll_offset = 0

            return None

        if key == ord("b"):
            navigator.go_back()
            self._tree_scroll_offset = 0
            return None

        if key == ord("f"):
            navigator.go_forward()
            self._tree_scroll_offset = 0
            return None

        if key == ord("."):
            navigator.toggle_hidden()
            self._tree_scroll_offset = 0
            return None

        if key == ord("a"):
            navigator.toggle_files()
            self._tree_scroll_offset = 0
            return None

        if key == ord("/"):
            self._filter_mode = True
            self._filter_query = ""
            self._filter_selected_index = 0
            self._filter_scroll_offset = 0
            return None

        if key == ord("o"):
            self._open_with_selected(navigator, stdscr)
            return None

        if key == ord("i"):
            self._info_mode = True
            return None

        if key in (curses.KEY_ENTER, 10, 13):
            return navigator.selected_entry.path

        return None

    def _handle_info_key(self, key: int) -> None:
        if key in (ESCAPE_KEY, ord("i")):
            self._info_mode = False

    def _matching_indices(self, entries: tuple[VisibleEntry, ...]) -> list[int]:
        if not self._filter_query:
            return list(range(len(entries)))

        query = self._filter_query.casefold()
        return [
            index
            for index, entry in enumerate(entries)
            if query in entry.name.casefold()
        ]

    def _matching_history_indices(self, entries: tuple[Path, ...]) -> list[int]:
        display_indices = self._history_display_indices(entries)
        if not self._history_filter_query:
            return display_indices

        query = self._history_filter_query.casefold()
        return [
            entry_index
            for entry_index in display_indices
            if query in str(entries[entry_index]).casefold()
        ]

    def _build_history_lines_for_render(
        self, entries: tuple[Path, ...]
    ) -> tuple[list[HistoryLine], int]:
        if not self._history_filter_mode:
            display_indices = self._history_display_indices(entries)
            if not display_indices:
                self._history_selected_index = 0
                return [], 0

            self._history_selected_index = max(
                0, min(self._history_selected_index, len(display_indices) - 1)
            )
            return [
                HistoryLine(
                    text=str(entries[entry_index]),
                    is_selected=index == self._history_selected_index,
                )
                for index, entry_index in enumerate(display_indices)
            ], self._history_selected_index

        matches = self._matching_history_indices(entries)
        if not matches:
            self._history_filter_selected_index = 0
            return [], 0

        self._history_filter_selected_index = max(
            0, min(self._history_filter_selected_index, len(matches) - 1)
        )
        return [
            HistoryLine(
                text=str(entries[entry_index]),
                is_selected=match_index == self._history_filter_selected_index,
            )
            for match_index, entry_index in enumerate(matches)
        ], self._history_filter_selected_index

    def _history_display_indices(self, entries: tuple[Path, ...]) -> list[int]:
        return list(range(len(entries) - 1, -1, -1))

    def _page_step(self, stdscr: curses.window | None, start_row: int) -> int:
        if stdscr is None:
            return 10

        height, _width = stdscr.getmaxyx()
        footer_rows = 1 if self._status_message else 0
        return max(1, height - start_row - footer_rows)

    def _open_with_selected(
        self, navigator: Navigator, stdscr: curses.window | None
    ) -> None:
        selected = navigator.selected_entry
        options = available_openers(selected.path)
        if not options:
            self._status_message = "No applications available for this entry"
            return

        option_index = 0
        if stdscr is not None:
            choice = self._prompt_open_with_choice(stdscr, options, selected.name)
            if choice is None:
                self._status_message = "Open cancelled"
                return

            option_index = choice

        option = options[option_index]
        if is_blocking_option(option):
            success, message = self._launch_blocking_with_terminal_restore(
                stdscr, selected.path, option
            )
        else:
            success, message = launch_background_option(selected.path, option)

        self._status_message = message
        if not success:
            self._status_message = message

    def _prompt_open_with_choice(
        self,
        stdscr: curses.window,
        options: list[OpenWithOption],
        entry_name: str,
    ) -> int | None:
        selected_index = 0

        while True:
            height, width = stdscr.getmaxyx()
            title_row = max(0, height - len(options) - 2)
            title = f"Open '{entry_name}' with (↑/↓, Enter, Esc):"

            stdscr.addnstr(
                title_row,
                0,
                " " * max(0, width - 1),
                max(0, width - 1),
            )
            stdscr.addnstr(
                title_row,
                0,
                title,
                max(0, width - 1),
                curses.A_BOLD,
            )

            for index, option in enumerate(options):
                row = title_row + index + 1
                if row >= height:
                    break

                attributes = (
                    curses.A_REVERSE if index == selected_index else curses.A_NORMAL
                )
                label = f"  {option.label}"
                stdscr.addnstr(
                    row,
                    0,
                    " " * max(0, width - 1),
                    max(0, width - 1),
                )
                stdscr.addnstr(row, 0, label, max(0, width - 1), attributes)

            stdscr.refresh()
            key = stdscr.getch()

            if key == ESCAPE_KEY:
                return None

            if key == curses.KEY_UP:
                selected_index = move_selection(
                    selected_index,
                    step=-1,
                    entry_count=len(options),
                )
                continue

            if key == curses.KEY_DOWN:
                selected_index = move_selection(
                    selected_index,
                    step=1,
                    entry_count=len(options),
                )
                continue

            if key in (curses.KEY_ENTER, 10, 13):
                return selected_index

    def _launch_blocking_with_terminal_restore(
        self,
        stdscr: curses.window | None,
        path: Path,
        option: OpenWithOption,
    ) -> tuple[bool, str]:
        if stdscr is None:
            return launch_blocking_option(path, option)

        curses.def_prog_mode()
        curses.endwin()

        try:
            success, message = launch_blocking_option(path, option)
        finally:
            curses.reset_prog_mode()
            stdscr.keypad(True)
            stdscr.clear()
            stdscr.refresh()

        return success, message

    def _get_current_history_index(self, navigator: Navigator) -> int:
        history_entries = navigator.history.entries()

        for index in range(len(history_entries) - 1, -1, -1):
            if history_entries[index] == navigator.current_path:
                return len(history_entries) - index - 1

        return 0


@contextmanager
def open_terminal_streams() -> Iterator[tuple[TextIO, TextIO]]:
    """Open terminal streams suitable for interactive rendering."""

    try:
        with (
            open("/dev/tty", encoding="utf-8") as input_stream,
            open("/dev/tty", "w", encoding="utf-8") as output_stream,
        ):
            yield input_stream, output_stream
            return
    except OSError:
        if not sys.stdin.isatty() or not sys.stderr.isatty():
            raise RuntimeError("Interactive terminal is required") from None

    yield sys.stdin, sys.stderr


@contextmanager
def redirect_standard_streams(
    input_stream: TextIO, output_stream: TextIO
) -> Iterator[None]:
    """Temporarily redirect stdin and stdout to terminal-backed streams."""

    sys.stdout.flush()
    sys.stderr.flush()

    original_stdin = os.dup(0)
    original_stdout = os.dup(1)

    try:
        os.dup2(input_stream.fileno(), 0)
        os.dup2(output_stream.fileno(), 1)
        yield
    finally:
        os.dup2(original_stdin, 0)
        os.dup2(original_stdout, 1)
        os.close(original_stdin)
        os.close(original_stdout)
