import hashlib
from pathlib import Path
from typing import AsyncIterator, Optional

from .base import FileMetadata, Storage, StorageCapabilities


class FilesystemStorage(Storage):
    """Built-in filesystem storage backend."""

    storage_type = "filesystem"
    capabilities = StorageCapabilities(
        can_upload=True,
        can_delete=True,
        can_list=True,
        can_generate_signed_urls=False,
        requires_proxy_download=True,
    )

    async def configure(self, config: dict, get_secret) -> None:
        self.root = Path(config["root"]).resolve()
        self.max_file_size = config.get("max_file_size")
        self.root.mkdir(parents=True, exist_ok=True)

    def _safe_path(self, path: str) -> Path:
        target = (self.root / path).resolve()
        if not target.is_relative_to(self.root):
            raise ValueError(f"Path {path!r} resolves outside storage root")
        return target

    async def get_file_metadata(self, path: str) -> Optional[FileMetadata]:
        target = self._safe_path(path)
        if not target.exists():
            return None
        stat = target.stat()
        return FileMetadata(
            path=path,
            filename=target.name,
            size=stat.st_size,
        )

    async def read_file(self, path: str) -> bytes:
        target = self._safe_path(path)
        if not target.exists():
            raise FileNotFoundError(f"File not found: {path}")
        return target.read_bytes()

    async def stream_file(self, path: str) -> AsyncIterator[bytes]:
        target = self._safe_path(path)
        if not target.exists():
            raise FileNotFoundError(f"File not found: {path}")
        with open(target, "rb") as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                yield chunk

    async def list_files(
        self,
        prefix: str = "",
        cursor: Optional[str] = None,
        limit: int = 100,
    ) -> tuple[list[FileMetadata], Optional[str]]:
        files = []
        search_root = self._safe_path(prefix) if prefix else self.root
        for file_path in sorted(search_root.rglob("*")):
            if file_path.is_file():
                rel_path = str(file_path.relative_to(self.root))
                stat = file_path.stat()
                files.append(
                    FileMetadata(
                        path=rel_path,
                        filename=file_path.name,
                        size=stat.st_size,
                    )
                )
                if len(files) >= limit:
                    break
        return files, None

    async def receive_upload(
        self, path: str, stream, content_type: str
    ) -> FileMetadata:
        target = self._safe_path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        sha256 = hashlib.sha256()
        size = 0
        with open(target, "wb") as f:
            async for chunk in stream:
                f.write(chunk)
                sha256.update(chunk)
                size += len(chunk)
        content_hash = "sha256:" + sha256.hexdigest()
        return FileMetadata(
            path=path,
            filename=Path(path).name,
            content_type=content_type,
            content_hash=content_hash,
            size=size,
        )

    async def delete_file(self, path: str) -> None:
        target = self._safe_path(path)
        if not target.exists():
            raise FileNotFoundError(f"File not found: {path}")
        target.unlink()
