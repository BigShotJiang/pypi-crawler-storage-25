from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image

from ..debug import PipelineDebugRecorder
from ..detection import ComicTextDetection
from ..pipeline import run_pipeline
from ..translation import VisionBlockResult
from .result import TranslationResult
from .translator import MangaTranslator


@dataclass
class DebugResult(TranslationResult):
    detection: ComicTextDetection
    inpainted: Image.Image
    vision_results: list[VisionBlockResult]
    mask_final: np.ndarray

    def save_all(self, dir: str | Path) -> None:
        d = Path(dir)
        d.mkdir(parents=True, exist_ok=True)
        self.image.save(d / "final.png")
        self.inpainted.save(d / "inpainted.png")
        Image.fromarray(self.mask_final, mode="L").save(d / "mask_final.png")


class DebugTranslator(MangaTranslator):
    def translate(
        self,
        image: Image.Image,
        *,
        debug_dir: str | Path | None = None,
    ) -> DebugResult:
        self._ensure_prepared()

        rgb = image.convert("RGB")
        recorder = None
        if debug_dir is not None:
            out_path = Path(debug_dir)
            out_path.mkdir(parents=True, exist_ok=True)
            recorder = PipelineDebugRecorder(out_path)

        result = run_pipeline(
            image=rgb,
            ctd=self._ctd,
            aot=self._aot,
            client=self._client,
            stack=self._stack,
            recorder=recorder,
        )

        return DebugResult(
            image=result.final,
            detection=result.detection,
            inpainted=result.inpainted,
            vision_results=result.vision_results,
            mask_final=result.mask_final,
        )
