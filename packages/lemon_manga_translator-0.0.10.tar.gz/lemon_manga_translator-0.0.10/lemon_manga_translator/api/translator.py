from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Optional, Sequence

import numpy as np
from PIL import Image

from ..detection import ComicTextDetector
from ..inpainting.aot import AotInpainter
from ..pipeline import run_pipeline
from ..renderer import default_font_stack
from ..renderer.fonts import FontStack
from ..translation import BackgroundMaskMode, VisionLlmClient
from ..translation.openrouter import PageAnnotator
from .result import TranslationResult
from .sources import DEFAULT_HF_REPO, resolve_model_paths

logger = logging.getLogger(__name__)


class MangaTranslator:
    def __init__(
        self,
        openrouter_api_key: str,
        openrouter_model: str,
        *,
        model_source: str | Path = DEFAULT_HF_REPO,
        cache_dir: str | Path | None = None,
        hf_token: str | None = None,
        openrouter_base_url: str = "https://openrouter.ai/api/v1",
        vision_max_long_edge: int = 1024,
        bg_mask_mode: BackgroundMaskMode | str = BackgroundMaskMode.NONE,
        device: str = "cpu",
        openrouter_fallback_model: str | None = None,
        openrouter_fallback_max_attempts: int = 1,
    ):
        self._openrouter_api_key = openrouter_api_key
        self._openrouter_model = openrouter_model
        self._model_source = model_source
        self._cache_dir = cache_dir
        self._hf_token = hf_token
        self._openrouter_base_url = openrouter_base_url
        self._vision_max_long_edge = vision_max_long_edge
        self._bg_mask_mode = BackgroundMaskMode(bg_mask_mode)
        self._device = device
        self._openrouter_fallback_model = openrouter_fallback_model or None
        self._openrouter_fallback_max_attempts = openrouter_fallback_max_attempts

        self._ctd: ComicTextDetector | None = None
        self._aot: AotInpainter | None = None
        self._client: VisionLlmClient | None = None
        self._stack: FontStack | None = None
        self._prepared = False

    @staticmethod
    def pre_download(
        model_source: str | Path = DEFAULT_HF_REPO,
        cache_dir: str | Path | None = None,
        hf_token: str | None = None,
    ) -> None:
        resolve_model_paths(
            model_source=model_source,
            cache_dir=cache_dir,
            hf_token=hf_token,
        )

    def prepare(self) -> None:
        paths = resolve_model_paths(
            model_source=self._model_source,
            cache_dir=self._cache_dir,
            hf_token=self._hf_token,
        )

        self._ctd = ComicTextDetector.load(paths["ctd_onnx"], device=self._device)
        self._aot = AotInpainter.load(paths["aot_onnx"], paths["aot_config"], device=self._device)
        annotator = PageAnnotator(
            max_long_edge=self._vision_max_long_edge,
            bg_mask_mode=self._bg_mask_mode,
        )
        self._client = VisionLlmClient(
            api_key=self._openrouter_api_key,
            model=self._openrouter_model,
            base_url=self._openrouter_base_url,
            annotator=annotator,
            fallback_model=self._openrouter_fallback_model,
            fallback_max_attempts=self._openrouter_fallback_max_attempts,
        )
        self._stack = default_font_stack()
        self._prepared = True

    def translate(self, image: Image.Image) -> TranslationResult:
        self._ensure_prepared()
        return self._run_one(image)

    def translate_batch(
        self,
        images: Sequence[Image.Image],
        *,
        max_workers: int = 4,
    ) -> list[TranslationResult]:
        self._ensure_prepared()
        if not images:
            return []

        total = len(images)

        def _process(idx: int, image: Image.Image) -> TranslationResult:
            logger.info("배치 페이지 %d/%d 시작", idx + 1, total)
            result = self._run_one(image)
            logger.info("배치 페이지 %d/%d 완료", idx + 1, total)
            return result

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [executor.submit(_process, i, img) for i, img in enumerate(images)]
            return [f.result() for f in futures]

    def _ensure_prepared(self) -> None:
        if not self._prepared:
            raise RuntimeError(
                f"{type(self).__name__}.prepare()를 먼저 호출하세요."
            )

    def _run_one(self, image: Image.Image) -> TranslationResult:
        rgb = image.convert("RGB")
        result = run_pipeline(
            image=rgb,
            ctd=self._ctd,
            aot=self._aot,
            client=self._client,
            stack=self._stack,
        )
        return TranslationResult(image=result.final)
