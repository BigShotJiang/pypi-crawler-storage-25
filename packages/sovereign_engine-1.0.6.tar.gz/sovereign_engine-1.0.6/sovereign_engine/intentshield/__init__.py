﻿"""
IntentShield — Lightweight Game Engine Gateway
"""
from .shield import IntentShield
__all__ = ["IntentShield"]
