﻿class IntentShield:
    """
    Lightweight Action Gatekeeper for Sovereign Engine.
    Validates that returned procedural intents match expected game mechanics.
    """
    def __init__(self, exempt_actions=None, **kwargs):
        self.allowed_actions = set(exempt_actions) if exempt_actions else set()
        
    def initialize(self):
        pass
        
    def audit(self, intent: str, payload: str = "") -> tuple[bool, str]:
        intent = str(intent).upper().strip()
        if not self.allowed_actions or intent in self.allowed_actions:
            return True, "Action approved."
            
        return False, f"Action '{intent}' is not in the allowed game mechanics whitelist: {list(self.allowed_actions)}"
