﻿import os
import requests
from .intentshield.shield import IntentShield
from .logicshield.shield import LogicShield
from .logicshield.rules import Rule
from .logicshield.repair import repair_json

class ProceduralDialogueEngine:
    def __init__(self, api_key: str = None, custom_actions: list = None, custom_rules: list = None, llm_provider=None, ollama_model="llama3.1:8b"):
        self.llm_provider = llm_provider
        self.api_key = api_key or os.environ.get("OPENROUTER_API_KEY")
        self.ollama_model = ollama_model
        
        base_actions = ["ATTACK", "TALK", "FLEE", "EXPLORE", "TRADE", "LOOT", "COMBAT", "DEFEND"]
        if custom_actions:
            base_actions.extend(custom_actions)
            
        self.intent_shield = IntentShield(exempt_actions=base_actions)
        self.intent_shield.initialize()
        
        base_rules = [
            Rule.type_check("intent", str),
            Rule.type_check("narrative", str),
            Rule.type_check("choices", list),
            Rule.custom("has_choices", lambda p, s: len(p.get("choices", [])) >= 2, "Must generate at least TWO choices."),
            Rule.less_than("npc_level", "max_allowed_level")
        ]
        if custom_rules:
            base_rules.extend(custom_rules)
            
        self.logic_shield = LogicShield(rules=base_rules)

    def _fetch_llm_response(self, prompt: str) -> str:
        # 1. Custom Provider Override
        if self.llm_provider:
            return self.llm_provider(prompt)
            
        # 2. OpenRouter API Fallback
        if self.api_key:
            headers = {"Authorization": f"Bearer {self.api_key}", "HTTP-Referer": "http://localhost", "Content-Type": "application/json"}
            payload = {"model": "openrouter/auto", "messages": [{"role": "user", "content": prompt}], "temperature": 0.7}
            response = requests.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=payload)
            response.raise_for_status()
            return response.json()['choices'][0]['message']['content']
            
        # 3. Default: Local Ollama Execution
        try:
            res = requests.post(
                "http://localhost:11434/api/generate", 
                json={"model": self.ollama_model, "prompt": prompt, "stream": False}
            )
            res.raise_for_status()
            return res.json()["response"]
        except requests.exceptions.ConnectionError:
            raise RuntimeError(f"Ollama is not running on localhost:11434. Start Ollama with model '{self.ollama_model}', or provide an OPENROUTER_API_KEY.")

    def generate_node(self, player_state: dict, recent_history: list, player_action: str) -> dict:
        history_text = "\n".join(recent_history[-8:])
        inventory_text = ", ".join(player_state.get('inventory', []))
        
        prompt = f"""You are a procedural game engine. Maintain strict world consistency.
LONG-TERM MEMORY: Location: {player_state.get('location')} | Level: {player_state.get('level')} | Inventory: {inventory_text}
SHORT-TERM MEMORY: {history_text}
NEW PLAYER ACTION: "{player_action}"

Generate next scene. VALID JSON format ONLY:
{{
    "intent": "TALK", 
    "npc_level": <int, strictly less than {player_state.get('level', 1) + 5}>,
    "narrative": "<the story text>",
    "choices": ["choice 1", "choice 2"]
}}"""

        feedback = ""
        proposal = None
        for _ in range(3):
            current_prompt = prompt + f"\n\n[SYSTEM FEEDBACK FROM PREVIOUS ERROR]:\n{feedback}" if feedback else prompt
            raw_output = self._fetch_llm_response(current_prompt)
            try:
                proposal = repair_json(raw_output)
            except ValueError as e:
                feedback = f"Format error: {e}"
                continue 
            safe, reason = self.intent_shield.audit(proposal.get("intent", "TALK"), payload=proposal.get("narrative", ""))
            if not safe:
                feedback = f"Action REJECTED by IntentShield.\nREASON: {reason}"
                continue 
            result = self.logic_shield.validate(proposal, state={"max_allowed_level": player_state.get('level', 1) + 5})
            if not result.valid:
                feedback = f"Output failed:\n" + "\n".join(result.errors)
                continue 
            break 
            
        if not proposal or not result or not result.valid:
             raise RuntimeError("Max correction attempts reached. Engine failure.")
        return proposal
