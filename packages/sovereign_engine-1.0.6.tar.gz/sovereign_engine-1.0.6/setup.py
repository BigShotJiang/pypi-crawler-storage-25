from setuptools import setup, find_packages

setup(
    name="sovereign-engine",
    version="1.0.6",
    description="Procedural Game Engine powered by IntentShield and LogicShield (BSL 1.1)",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="SovereignShield",
    author_email="support@sovereignshield.com",
    url="https://github.com/sovereign-shield/sovereign-engine",
    packages=find_packages(),
    install_requires=[
        "requests>=2.31.0"
    ],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: Other/Proprietary License",
        "Programming Language :: Python :: 3",
        "Topic :: Games/Entertainment",
        "Topic :: Security"
    ],
    python_requires=">=3.8",
)
