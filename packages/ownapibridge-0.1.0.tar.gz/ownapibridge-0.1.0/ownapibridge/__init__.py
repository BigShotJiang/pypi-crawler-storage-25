"""
ownAPIbridge Python SDK
~~~~~~~~~~~~~~~~~~~~~~~

A simple Python client for the ownAPIbridge API.

Usage:
    from ownapibridge import OABClient

    client = OABClient(api_key="sk-oab-...")

    # Chat
    response = client.chat.create(
        model="claude-sonnet-4",
        messages=[{"role": "user", "content": "Hello!"}]
    )
    print(response.content)

    # Streaming
    for chunk in client.chat.stream(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Write a poem"}]
    ):
        print(chunk, end="", flush=True)

    # Image generation
    image = client.images.generate(
        model="dall-e-3",
        prompt="A sunset over mountains"
    )
    print(image.url)
"""

from .client import OABClient
from .exceptions import OABError, AuthenticationError, ModelNotFoundError, ProviderError

__version__ = "0.1.0"
__all__ = ["OABClient", "OABError", "AuthenticationError", "ModelNotFoundError", "ProviderError"]
