"""Response data classes — plain dataclasses, no pydantic dependency."""
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ChatResponse:
    """Response from a non-streaming chat call."""
    content: str
    model: str
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0

    def __str__(self) -> str:
        return self.content


@dataclass
class ModelInfo:
    id: str
    name: str
    description: str
    provider: str
    category: str
    category_label: str
    badge: Optional[str]
    aa_score: Optional[int]
    speed_tps: Optional[int]
    price_per_1m_input: float
    price_per_1m_output: float
    context_length: int
    supports_streaming: bool
    open_weight: bool
    available: bool
    model_type: str = "text"

    def __repr__(self) -> str:
        return f"<ModelInfo id={self.id!r} name={self.name!r} provider={self.provider!r}>"


@dataclass
class ImageResult:
    """A single generated image."""
    url: Optional[str] = None
    b64_json: Optional[str] = None
    revised_prompt: Optional[str] = None

    def __repr__(self) -> str:
        return f"<ImageResult url={self.url!r}>"


@dataclass
class ImageResponse:
    """Response from an image generation call."""
    images: list[ImageResult] = field(default_factory=list)
    created: int = 0

    @property
    def url(self) -> Optional[str]:
        """Shortcut: URL of the first generated image."""
        return self.images[0].url if self.images else None

    @property
    def b64_json(self) -> Optional[str]:
        """Shortcut: base64 data of the first generated image."""
        return self.images[0].b64_json if self.images else None

    def __repr__(self) -> str:
        return f"<ImageResponse images={len(self.images)}>"


@dataclass
class VideoResponse:
    """Response from a video generation call."""
    url: str
    model: str
    duration: int

    def __repr__(self) -> str:
        return f"<VideoResponse url={self.url!r} duration={self.duration}s>"


@dataclass
class ApiKeyInfo:
    id: int
    name: str
    key_prefix: str
    expires_at: Optional[str]
    last_used: Optional[str]
    revoked: bool
    total_requests: int
    created_at: str

    def __repr__(self) -> str:
        return f"<ApiKeyInfo id={self.id} name={self.name!r} prefix={self.key_prefix!r}>"
