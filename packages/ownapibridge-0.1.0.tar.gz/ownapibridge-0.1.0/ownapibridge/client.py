"""
OABClient — main entry point for the ownAPIbridge Python SDK.
"""
from __future__ import annotations

import json
from typing import Generator, Iterator, Optional

import urllib.request
import urllib.error

from .exceptions import AuthenticationError, ModelNotFoundError, ProviderError, OABError
from .models import (
    ChatResponse, ModelInfo, ImageResult, ImageResponse, VideoResponse, ApiKeyInfo
)

_DEFAULT_BASE_URL = "http://localhost:8000"


class _HttpClient:
    """Minimal HTTP client using stdlib only — no external dependencies."""

    def __init__(self, api_key: str, base_url: str):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")

    def _headers(self) -> dict:
        return {
            "Content-Type": "application/json",
            "X-API-Key": self.api_key,
        }

    def get(self, path: str) -> dict:
        url = self.base_url + path
        req = urllib.request.Request(url, headers=self._headers())
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            self._raise_for_status(e.code, e.read().decode())

    def post(self, path: str, body: dict, timeout: int = 120) -> dict:
        url = self.base_url + path
        data = json.dumps(body).encode()
        req = urllib.request.Request(url, data=data, headers=self._headers(), method="POST")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            self._raise_for_status(e.code, e.read().decode())

    def stream_post(self, path: str, body: dict) -> Generator[str, None, None]:
        """POST and yield SSE text chunks."""
        url = self.base_url + path
        data = json.dumps(body).encode()
        req = urllib.request.Request(url, data=data, headers=self._headers(), method="POST")
        try:
            with urllib.request.urlopen(req, timeout=300) as resp:
                buffer = ""
                while True:
                    chunk = resp.read(1).decode("utf-8", errors="replace")
                    if not chunk:
                        break
                    buffer += chunk
                    if "\n" in buffer:
                        lines = buffer.split("\n")
                        buffer = lines[-1]
                        for line in lines[:-1]:
                            line = line.strip()
                            if not line.startswith("data: "):
                                continue
                            data_str = line[6:]
                            if data_str == "[DONE]":
                                return
                            try:
                                parsed = json.loads(data_str)
                                if parsed.get("error"):
                                    raise ProviderError(parsed["error"])
                                content = (
                                    parsed.get("choices", [{}])[0]
                                    .get("delta", {})
                                    .get("content", "")
                                )
                                if content:
                                    yield content
                            except (json.JSONDecodeError, IndexError):
                                pass
        except urllib.error.HTTPError as e:
            self._raise_for_status(e.code, e.read().decode())

    @staticmethod
    def _raise_for_status(status: int, body: str):
        try:
            detail = json.loads(body).get("detail", body)
        except Exception:
            detail = body
        if status == 401:
            raise AuthenticationError(f"Authentication failed: {detail}", status_code=status)
        if status == 404:
            raise ModelNotFoundError(f"Not found: {detail}", status_code=status)
        if status == 503:
            raise ProviderError(f"Provider error: {detail}", status_code=status)
        raise OABError(f"API error ({status}): {detail}", status_code=status)


class ChatResource:
    def __init__(self, http: _HttpClient):
        self._http = http

    def create(
        self,
        model: str,
        messages: list[dict],
        temperature: float = 0.7,
        max_tokens: int = 2048,
        system: Optional[str] = None,
    ) -> ChatResponse:
        """
        Send a chat request and return the full response.

        Args:
            model: Model ID (e.g. "claude-sonnet-4", "gpt-4o")
            messages: List of {"role": "user"|"assistant", "content": "..."}
            temperature: Sampling temperature 0–2 (default 0.7)
            max_tokens: Max tokens in the response (default 2048)
            system: Optional system prompt override

        Returns:
            ChatResponse with .content, .input_tokens, .output_tokens
        """
        data = self._http.post("/v1/chat/completions", {
            "model": model,
            "messages": messages,
            "stream": False,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "system": system,
        })
        choice = data["choices"][0]
        usage = data.get("usage", {})
        return ChatResponse(
            content=choice["message"]["content"],
            model=data.get("model", model),
            input_tokens=usage.get("prompt_tokens", 0),
            output_tokens=usage.get("completion_tokens", 0),
            total_tokens=usage.get("total_tokens", 0),
        )

    def stream(
        self,
        model: str,
        messages: list[dict],
        temperature: float = 0.7,
        max_tokens: int = 2048,
        system: Optional[str] = None,
    ) -> Iterator[str]:
        """
        Stream a chat response, yielding text chunks as they arrive.

        Usage:
            for chunk in client.chat.stream(model="gpt-4o", messages=[...]):
                print(chunk, end="", flush=True)
        """
        yield from self._http.stream_post("/v1/chat/completions", {
            "model": model,
            "messages": messages,
            "stream": True,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "system": system,
        })


class ModelsResource:
    def __init__(self, http: _HttpClient):
        self._http = http

    def list(self) -> list[ModelInfo]:
        """
        Return the curated list of available models.

        Returns:
            List of ModelInfo objects
        """
        data = self._http.get("/v1/models")
        return [
            ModelInfo(
                id=m["id"],
                name=m["name"],
                description=m["description"],
                provider=m["provider"],
                category=m["category"],
                category_label=m["category_label"],
                badge=m.get("badge"),
                aa_score=m.get("aa_score"),
                speed_tps=m.get("speed_tps"),
                price_per_1m_input=m["price_per_1m_input"],
                price_per_1m_output=m["price_per_1m_output"],
                context_length=m["context_length"],
                supports_streaming=m["supports_streaming"],
                open_weight=m["open_weight"],
                available=m["available"],
                model_type=m.get("model_type", "text"),
            )
            for m in data
        ]


class ImagesResource:
    def __init__(self, http: _HttpClient):
        self._http = http

    def generate(
        self,
        model: str,
        prompt: str,
        size: str = "1024x1024",
        quality: str = "standard",
        n: int = 1,
    ) -> ImageResponse:
        """
        Generate one or more images from a text prompt.

        Args:
            model: Image model ID (e.g. "dall-e-3", "flux-1-1-pro")
            prompt: Text description of the image
            size: Image dimensions, e.g. "1024x1024", "1792x1024"
            quality: "standard" or "hd"
            n: Number of images to generate (1–4)

        Returns:
            ImageResponse with .url shortcut and .images list

        Example:
            image = client.images.generate(
                model="dall-e-3",
                prompt="A red fox in the snow, photorealistic"
            )
            print(image.url)
        """
        data = self._http.post(
            "/v1/images/generations",
            {"model": model, "prompt": prompt, "size": size, "quality": quality, "n": n},
            timeout=180,
        )
        return ImageResponse(
            created=data.get("created", 0),
            images=[
                ImageResult(
                    url=img.get("url"),
                    b64_json=img.get("b64_json"),
                    revised_prompt=img.get("revised_prompt"),
                )
                for img in data.get("data", [])
            ],
        )


class VideosResource:
    def __init__(self, http: _HttpClient):
        self._http = http

    def generate(
        self,
        model: str,
        prompt: str,
        duration: int = 5,
        aspect_ratio: str = "16:9",
    ) -> VideoResponse:
        """
        Generate a video from a text prompt.

        Args:
            model: Video model ID (e.g. "runway-gen3-alpha-turbo", "kling-v1-5")
            prompt: Text description of the video
            duration: Length in seconds (3–10)
            aspect_ratio: "16:9", "9:16", or "1:1"

        Returns:
            VideoResponse with .url, .model, .duration

        Example:
            video = client.videos.generate(
                model="kling-v1-5",
                prompt="A timelapse of a flower blooming in a garden"
            )
            print(video.url)
        """
        data = self._http.post(
            "/v1/videos/generations",
            {"model": model, "prompt": prompt, "duration": duration, "aspect_ratio": aspect_ratio},
            timeout=360,
        )
        return VideoResponse(
            url=data["url"],
            model=data["model"],
            duration=data["duration"],
        )


class OABClient:
    """
    ownAPIbridge API client.

    Args:
        api_key: Your API key (starts with sk-oab-)
        base_url: Base URL of the ownAPIbridge server (default: http://localhost:8000)

    Resources:
        client.chat      — Text generation (create + stream)
        client.models    — List available models
        client.images    — Image generation
        client.videos    — Video generation

    Example:
        from ownapibridge import OABClient

        client = OABClient(
            api_key="sk-oab-your-key-here",
            base_url="https://your-server.com"
        )

        response = client.chat.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "What is the capital of France?"}]
        )
        print(response.content)  # "Paris"
    """

    def __init__(self, api_key: str, base_url: str = _DEFAULT_BASE_URL):
        if not api_key:
            raise ValueError("api_key must not be empty")
        self._http = _HttpClient(api_key=api_key, base_url=base_url)
        self.chat = ChatResource(self._http)
        self.models = ModelsResource(self._http)
        self.images = ImagesResource(self._http)
        self.videos = VideosResource(self._http)

    def __repr__(self) -> str:
        return f"OABClient(base_url={self._http.base_url!r})"
